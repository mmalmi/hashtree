import { describe, expect, test } from "vitest";

import { FlagSet, Flags, Segment, Stack, State } from "../src/index.js";

import { Pair } from "./pair.js";

describe("TCP/FIPS TypeScript state machine", () => {
  test("reservation changes preserve existing streams and TIME-WAIT limits", () => {
    const pair = new Pair({ maxConnections: 2, maxConnectionsPerPeer: 1, timeWaitMs: 50 });
    let eligible = true;
    for (const stack of [pair.a, pair.b]) stack.setConnectionReservation(1, () => eligible);
    const [client, server] = pair.connect();
    pair.b.connect("half-open", 443, pair.now);
    pair.b.drainOutbound();
    eligible = false;
    expect(() => pair.b.connect("new-peer", 443, pair.now)).toThrow(/connection limit/i);
    expect(pair.a.write(client, new TextEncoder().encode("request"), pair.now)).toBe(7);
    expect(pair.b.write(server, new TextEncoder().encode("reply"), pair.now)).toBe(5);
    pair.settle();
    expect(new TextDecoder().decode(pair.b.read(server, 16, pair.now))).toBe("request");
    expect(new TextDecoder().decode(pair.a.read(client, 16, pair.now))).toBe("reply");
    pair.a.close(client, pair.now);
    pair.settle();
    pair.b.close(server, pair.now);
    pair.settle();
    expect(pair.a.state(client)).toBe(State.TimeWait);
    expect(() => pair.a.connect("new-peer", 443, pair.now)).toThrow(/connection limit/i);
    pair.advance(50);
    pair.settle();
    expect(pair.a.state(client)).toBeUndefined();
    expect(() => pair.a.connect("new-peer", 443, pair.now)).not.toThrow();
  });

  test("handshake, bidirectional stream, and orderly close", () => {
    const pair = new Pair();
    const [client, server] = pair.connect();

    expect(pair.a.write(client, new TextEncoder().encode("hello from ts"), pair.now)).toBe(13);
    expect(pair.b.write(server, new TextEncoder().encode("hello back"), pair.now)).toBe(10);
    pair.settle();
    expect(new TextDecoder().decode(pair.b.read(server, 1024, pair.now))).toBe("hello from ts");
    expect(new TextDecoder().decode(pair.a.read(client, 1024, pair.now))).toBe("hello back");

    pair.a.close(client, pair.now);
    pair.settle();
    expect(pair.b.state(server)).toBe(State.CloseWait);
    expect(pair.b.isReadClosed(server)).toBe(true);
    pair.b.close(server, pair.now);
    pair.settle();
    pair.advance(60_000);
    pair.settle();
    expect(pair.a.state(client)).toBeUndefined();
    expect(pair.b.state(server)).toBeUndefined();
  });

  test("per-peer limit counts active and TIME-WAIT state until expiry", () => {
    const pair = new Pair({ maxConnectionsPerPeer: 1, timeWaitMs: 50 });
    const [client, server] = pair.connect();
    expect(() => pair.a.connect("b", 443, pair.now)).toThrow(/connection limit/i);
    pair.a.close(client, pair.now);
    pair.settle();
    pair.b.close(server, pair.now);
    pair.settle();
    expect(pair.a.state(client)).toBe(State.TimeWait);
    expect(() => pair.a.connect("b", 443, pair.now)).toThrow(/connection limit/i);

    pair.advance(50);
    pair.settle();
    expect(() => pair.a.connect("b", 443, pair.now)).not.toThrow();
  });

  test("per-peer limit counts FIN-WAIT-2 until ACK-without-FIN deadline", () => {
    const pair = new Pair({ maxConnectionsPerPeer: 1, finWait2Ms: 50 });
    const [client] = pair.connect();
    pair.a.close(client, pair.now);
    pair.settle();
    expect(pair.a.state(client)).toBe(State.FinWait2);
    expect(() => pair.a.connect("b", 443, pair.now)).toThrow(/connection limit/i);

    pair.advance(49);
    pair.settle();
    expect(pair.a.state(client)).toBe(State.FinWait2);
    expect(() => pair.a.connect("b", 443, pair.now)).toThrow(/connection limit/i);

    pair.advance(1);
    pair.settle();
    expect(pair.a.state(client)).toBeUndefined();
    expect(() => pair.a.connect("b", 443, pair.now)).not.toThrow();
  });

  test("abort after zero-window close deadline resets peer and releases capacity", () => {
    const pair = new Pair({ mss: 8, receiveBuffer: 8, maxConnectionsPerPeer: 1 });
    const [client, server] = pair.connect();
    pair.a.write(client, new Uint8Array(8).fill(0x55), pair.now);
    pair.settle();
    pair.a.close(client, pair.now);

    pair.advance(50);
    pair.settle();
    expect(pair.a.state(client)).toBe(State.Established);
    expect(() => pair.a.connect("b", 443, pair.now)).toThrow(/connection limit/i);

    const unrelated = pair.a.connect("c", 443, pair.now);
    pair.a.abort(client);
    expect(pair.a.state(client)).toBeUndefined();
    const outbound = pair.a.drainOutbound();
    const resetOutbound = outbound.filter((item) => item.peer === "b");
    const unrelatedOutbound = outbound.filter((item) => item.peer === "c");
    expect(resetOutbound).toHaveLength(1);
    expect(unrelatedOutbound).toHaveLength(1);
    const reset = Segment.decode(resetOutbound[0]!.bytes);
    expect(reset.flags.bits).toBe(Flags.Rst);
    expect(reset.ack).toBeUndefined();
    expect(reset.window).toBe(0);

    pair.b.input("a", resetOutbound[0]!.bytes, pair.now);
    expect(pair.b.state(server)).toBeUndefined();
    const replacement = pair.a.connect("b", 443, pair.now);
    const replacementSyn = pair.a.drainOutbound();
    expect(replacementSyn).toHaveLength(1);
    expect(Segment.decode(replacementSyn[0]!.bytes).flags.has(Flags.Syn)).toBe(true);

    expect(() => pair.a.abort(client)).toThrow(/unknown connection/i);
    expect(pair.a.state(unrelated)).toBe(State.SynSent);
    expect(pair.a.state(replacement)).toBe(State.SynSent);
    expect(pair.a.drainOutbound()).toHaveLength(0);
  });

  test("RST validation survives stale tuple reuse and challenges an in-window guess", () => {
    const pair = new Pair();
    pair.b.listen(443);
    const oldClient = pair.a.connectFromWithIsn("b", 50_000, 443, 100, pair.now);
    pair.settle();
    const oldServer = pair.b.accept(443)!;

    pair.a.abort(oldClient);
    const staleReset = pair.a.drainOutbound()[0]!.bytes;
    pair.b.abort(oldServer);
    pair.b.drainOutbound();

    const newClient = pair.a.connectFromWithIsn("b", 50_000, 443, 1_000_000, pair.now);
    pair.settle();
    const newServer = pair.b.accept(443)!;
    pair.b.input("a", staleReset, pair.now);
    expect(pair.b.state(newServer)).toBe(State.Established);
    expect(pair.b.drainOutbound()).toHaveLength(0);

    pair.b.input("a", reset(50_000, 443, 1_000_002), pair.now);
    expect(pair.b.state(newServer)).toBe(State.Established);
    const challenge = pair.b.drainOutbound();
    expect(challenge).toHaveLength(1);
    const challengeSegment = Segment.decode(challenge[0]!.bytes);
    expect(challengeSegment.flags.bits).toBe(Flags.Ack);
    expect(challengeSegment.ack).toBe(1_000_001);

    pair.b.input("a", reset(50_000, 443, 1_000_001 + 0xffff), pair.now);
    expect(pair.b.state(newServer)).toBe(State.Established);
    expect(pair.b.drainOutbound()).toHaveLength(0);

    pair.a.abort(newClient);
    const exact = pair.a.drainOutbound();
    expect(exact).toHaveLength(1);
    pair.b.input("a", exact[0]!.bytes, pair.now);
    expect(pair.b.state(newServer)).toBeUndefined();
  });

  test("SYN-SENT ignores an unacknowledged RST but accepts a closed-port RST", () => {
    const pair = new Pair();
    const client = pair.a.connectFromWithIsn("b", 50_000, 443, 100, pair.now);
    const syn = pair.a.drainOutbound()[0]!.bytes;
    pair.a.input("b", reset(443, 50_000, 0), pair.now);
    expect(pair.a.state(client)).toBe(State.SynSent);
    expect(pair.a.drainOutbound()).toHaveLength(0);

    pair.b.input("a", syn, pair.now);
    const rejection = pair.b.drainOutbound();
    expect(rejection).toHaveLength(1);
    const rejectionSegment = Segment.decode(rejection[0]!.bytes);
    expect(rejectionSegment.flags.has(Flags.Rst)).toBe(true);
    expect(rejectionSegment.flags.has(Flags.Ack)).toBe(true);
    expect(rejectionSegment.ack).toBe(101);
    pair.a.input("b", rejection[0]!.bytes, pair.now);
    expect(pair.a.state(client)).toBeUndefined();
  });

  test("lost SYN and first payload recover via RTO", () => {
    const pair = new Pair();
    pair.b.listen(443);
    const client = pair.a.connect("b", 443, pair.now);
    let droppedSyn = false;
    pair.stepWith((fromA, bytes) => {
      if (fromA && !droppedSyn) {
        droppedSyn = true;
        return [];
      }
      return [bytes];
    });
    expect(pair.a.state(client)).toBe(State.SynSent);
    pair.advance(1000);
    pair.settle();
    const server = pair.b.accept(443)!;

    const payload = new Uint8Array(4096).fill(0x5a);
    expect(pair.a.write(client, payload, pair.now)).toBe(payload.length);
    let droppedData = false;
    pair.stepWith((fromA, bytes) => {
      if (fromA && Segment.decode(bytes).payload.length > 0 && !droppedData) {
        droppedData = true;
        return [];
      }
      return [bytes];
    });
    pair.settle();
    const received = [...pair.b.read(server, payload.length, pair.now)];
    pair.advance(1000);
    pair.settle();
    while (received.length < payload.length) {
      received.push(...pair.b.read(server, payload.length, pair.now));
      if (received.length < payload.length) {
        pair.advance(1000);
        pair.settle();
      }
    }
    expect(Uint8Array.from(received)).toEqual(payload);
  });

  test("reverse-order duplicates reassemble exactly once", () => {
    const pair = new Pair({ mss: 256 });
    const [client, server] = pair.connect();
    const payload = Uint8Array.from({ length: 2048 }, (_, index) => index % 251);
    pair.a.write(client, payload, pair.now);
    pair.a.poll(pair.now);
    for (const outbound of pair.a.drainOutbound().reverse()) {
      pair.b.input("a", outbound.bytes, pair.now);
      pair.b.input("a", outbound.bytes, pair.now);
    }
    pair.settle();
    expect(pair.b.read(server, payload.length, pair.now)).toEqual(payload);
  });

  test("receive window reopens after application reads", () => {
    const pair = new Pair({ mss: 8, receiveBuffer: 16 });
    const [client, server] = pair.connect();
    const payload = Uint8Array.from({ length: 64 }, (_, index) => index);
    pair.a.write(client, payload, pair.now);
    pair.settle();
    const received = [...pair.b.read(server, 16, pair.now)];
    for (let attempt = 0; received.length < payload.length && attempt < 16; attempt += 1) {
      pair.settle();
      received.push(...pair.b.read(server, 16, pair.now));
    }
    expect(Uint8Array.from(received)).toEqual(payload);
  });

  test("byte sequence wraparound remains ordered", () => {
    const pair = new Pair();
    pair.b.listen(443);
    const client = pair.a.connectFromWithIsn("b", 50_000, 443, 0xffff_ffff - 8, pair.now);
    pair.settle();
    const server = pair.b.accept(443)!;
    const payload = new TextEncoder().encode("crosses the sequence wrap");
    pair.a.write(client, payload, pair.now);
    pair.settle();
    expect(pair.b.read(server, 1024, pair.now)).toEqual(payload);
  });

  test("close waits for flow-controlled bytes before FIN", () => {
    const pair = new Pair({ mss: 8, receiveBuffer: 16 });
    const [client, server] = pair.connect();
    const payload = Uint8Array.from({ length: 64 }, (_, index) => index);
    pair.a.write(client, payload, pair.now);
    pair.a.close(client, pair.now);
    pair.settle();

    const received: number[] = [];
    for (let attempt = 0; attempt < 8; attempt += 1) {
      received.push(...pair.b.read(server, 16, pair.now));
      pair.settle();
      if (pair.b.isReadClosed(server)) break;
    }
    expect(Uint8Array.from(received)).toEqual(payload);
    expect(pair.b.isReadClosed(server)).toBe(true);
    expect(pair.b.state(server)).toBe(State.CloseWait);
  });

  test("zero-window probe recovers a lost window update", () => {
    const pair = new Pair({ mss: 8, receiveBuffer: 16 });
    const [client, server] = pair.connect();
    const payload = Uint8Array.from({ length: 64 }, (_, index) => index);
    pair.a.write(client, payload, pair.now);
    pair.settle();

    const received = [...pair.b.read(server, 16, pair.now)];
    let droppedUpdate = false;
    pair.stepWith((fromA, bytes) => {
      if (!fromA && !droppedUpdate) {
        droppedUpdate = true;
        return [];
      }
      return [bytes];
    });
    expect(droppedUpdate).toBe(true);
    pair.advance(1000);
    pair.settle();
    for (let attempt = 0; received.length < payload.length && attempt < 8; attempt += 1) {
      received.push(...pair.b.read(server, 16, pair.now));
      pair.settle();
    }
    expect(Uint8Array.from(received)).toEqual(payload);
  });

  test("closed-port RST and retry limit remove connections", () => {
    const pair = new Pair({ initialRtoMs: 200, maxRetransmissions: 1 });
    const reset = pair.a.connect("b", 443, pair.now);
    pair.settle();
    expect(pair.a.state(reset)).toBeUndefined();

    const timedOut = pair.a.connect("b", 444, pair.now);
    pair.a.drainOutbound();
    pair.advance(200);
    pair.a.poll(pair.now);
    expect(pair.a.state(timedOut)).toBeUndefined();
  });

  test("triple duplicate ACK fast-retransmits without waiting for RTO", () => {
    const pair = new Pair({ mss: 128 });
    const [client, server] = pair.connect();
    pair.a.write(client, new Uint8Array(2048).fill(0x11), pair.now);
    pair.settle();
    pair.b.read(server, 4096, pair.now);
    pair.settle();

    const payload = Uint8Array.from({ length: 2048 }, (_, index) => index % 251);
    pair.a.write(client, payload, pair.now);
    const packets = pair.a.drainOutbound();
    expect(packets.length).toBeGreaterThanOrEqual(4);
    const first = Segment.decode(packets[0]!.bytes);
    for (const outbound of packets.slice(1)) pair.b.input("a", outbound.bytes, pair.now);
    for (const outbound of pair.b.drainOutbound()) pair.a.input("b", outbound.bytes, pair.now);
    const retransmits = pair.a.drainOutbound();
    expect(
      retransmits.some((outbound) => {
        const segment = Segment.decode(outbound.bytes);
        return segment.seq === first.seq && toHex(segment.payload) === toHex(first.payload);
      }),
    ).toBe(true);
    for (const outbound of retransmits) pair.b.input("a", outbound.bytes, pair.now);
    pair.settle();
    expect(pair.b.read(server, payload.length, pair.now)).toEqual(payload);
  });

  test("lost FIN is retransmitted", () => {
    const pair = new Pair();
    const [client, server] = pair.connect();
    pair.a.close(client, pair.now);
    let dropped = false;
    pair.stepWith((fromA, bytes) => {
      if (fromA && Segment.decode(bytes).flags.has(Flags.Fin) && !dropped) {
        dropped = true;
        return [];
      }
      return [bytes];
    });
    expect(dropped).toBe(true);
    expect(pair.b.state(server)).toBe(State.Established);
    pair.advance(1000);
    pair.settle();
    expect(pair.b.state(server)).toBe(State.CloseWait);
  });
});

const toHex = (bytes: Uint8Array): string => Buffer.from(bytes).toString("hex");

const reset = (sourcePort: number, destinationPort: number, sequence: number): Uint8Array =>
  new Segment({
    srcPort: sourcePort,
    dstPort: destinationPort,
    seq: sequence,
    flags: new FlagSet(Flags.Rst),
  }).encode();
