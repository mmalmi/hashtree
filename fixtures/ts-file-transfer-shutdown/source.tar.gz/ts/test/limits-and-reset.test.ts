import { expect, test } from "vitest";

import {
  FIPS_VERSION,
  FlagSet,
  Flags,
  Segment,
  Stack,
  TcpOptionKind,
} from "../src/index.js";

test("unsupported version is reset and connection count is bounded", () => {
  const server = new Stack({}, 1);
  server.listen(443);
  const syn = new Segment({
    srcPort: 50_000,
    dstPort: 443,
    seq: 1234,
    flags: new FlagSet(Flags.Syn),
    options: [
      { kind: TcpOptionKind.MaxSegmentSize, value: 1024 },
      { kind: TcpOptionKind.FipsVersion, version: FIPS_VERSION + 1, reserved: 0 },
    ],
  });
  server.input("peer", syn.encode(), 0);
  const reset = server.drainOutbound();
  expect(reset).toHaveLength(1);
  expect(Segment.decode(reset[0]!.bytes).flags.has(Flags.Rst)).toBe(true);

  const reserved = new Segment({
    srcPort: 50_001,
    dstPort: 443,
    seq: 5678,
    flags: new FlagSet(Flags.Syn),
    options: [{ kind: TcpOptionKind.FipsVersion, version: FIPS_VERSION, reserved: 1 }],
  });
  server.input("other", reserved.encode(), 0);
  expect(Segment.decode(server.drainOutbound()[0]!.bytes).flags.has(Flags.Rst)).toBe(true);

  const client = new Stack({ maxConnections: 1 }, 2);
  client.connect("a", 443, 0);
  expect(() => client.connect("b", 443, 0)).toThrow(/connection limit/i);
});

test("send-buffer acceptance is bounded", () => {
  const client = new Stack({ sendBuffer: 10 }, 1);
  const server = new Stack({ sendBuffer: 10 }, 2);
  server.listen(443);
  const id = client.connect("server", 443, 0);
  for (let step = 0; step < 4; step += 1) {
    for (const packet of client.drainOutbound()) server.input("client", packet.bytes, 0);
    for (const packet of server.drainOutbound()) client.input("server", packet.bytes, 0);
  }
  expect(client.write(id, new Uint8Array(100).fill(7), 0)).toBe(10);
});

test("one peer SYN flood cannot consume another peer's capacity", () => {
  const server = new Stack({ maxConnections: 2, maxConnectionsPerPeer: 1 }, 3);
  server.listen(443);
  server.input("flooder", syn(50_000), 0);
  expect(server.drainOutbound()).toHaveLength(1);
  for (let sourcePort = 50_001; sourcePort < 50_020; sourcePort += 1) {
    expect(() => server.input("flooder", syn(sourcePort), 0)).toThrow(/connection limit/i);
    expect(server.drainOutbound()).toHaveLength(0);
  }
  expect(() => server.input("healthy", syn(51_000), 0)).not.toThrow();
  expect(server.drainOutbound()).toHaveLength(1);
});

test("FIN-WAIT-2 retention must be a bounded positive duration", () => {
  expect(() => new Stack({ finWait2Ms: 0 }, 4)).toThrow(/FIN-WAIT-2 duration/i);
  expect(() => new Stack({ finWait2Ms: Number.MAX_SAFE_INTEGER + 1 }, 4)).toThrow(
    /FIN-WAIT-2 duration/i,
  );
});

test("SYN-RECEIVED requires an acceptable RST sequence", () => {
  const server = new Stack({ maxConnections: 1 }, 5);
  server.listen(443);
  server.input("peer", syn(50_000), 0);
  server.drainOutbound();

  server.input("peer", reset(50_000, 443, 1_000_000), 0);
  expect(() => server.input("other", syn(50_001), 0)).toThrow(/connection limit/i);

  server.input("peer", reset(50_000, 443, 50_001), 0);
  expect(() => server.input("other", syn(50_001), 0)).not.toThrow();
});

const syn = (sourcePort: number): Uint8Array =>
  new Segment({
    srcPort: sourcePort,
    dstPort: 443,
    seq: sourcePort,
    flags: new FlagSet(Flags.Syn),
    options: [
      { kind: TcpOptionKind.MaxSegmentSize, value: 1024 },
      { kind: TcpOptionKind.FipsVersion, version: FIPS_VERSION, reserved: 0 },
    ],
  }).encode();

const reset = (sourcePort: number, destinationPort: number, sequence: number): Uint8Array =>
  new Segment({
    srcPort: sourcePort,
    dstPort: destinationPort,
    seq: sequence,
    flags: new FlagSet(Flags.Rst),
  }).encode();
