#![forbid(unsafe_code)]

//! Drive TCP/FIPS segments through an embedded [`fips_core::FipsEndpoint`].

use std::error::Error;
use std::fmt;
use std::sync::Arc;

use fips_core::discovery::local::LocalInstanceCapability;
use fips_core::{
    FipsEndpoint, FipsEndpointError, FipsEndpointServiceDatagram, FipsEndpointServiceReceiver,
    IdentityError, LocalServiceRegistrationError, PeerIdentity,
};
use fips_tcp::{Config, ConnectionId, MarkerStatus, SendMarker, Stack, StackError, State};

mod peer;
use peer::PeerKey;

/// Bounded aggregate of one received FIPS service batch.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ReceiveReport {
    /// Total datagrams drained from the bounded FIPS receiver batch.
    pub datagrams: usize,
    /// Datagrams accepted or intentionally ignored by the TCP state machine.
    pub processed: usize,
    /// Datagrams rejected by bounded TCP wire decoding.
    pub malformed: usize,
    /// Datagrams rejected by connection limits or authenticated-peer admission.
    pub connection_limited: usize,
    /// Other isolated TCP state-machine errors.
    pub other_errors: usize,
}

impl ReceiveReport {
    /// Total isolated errors in this batch.
    pub fn rejected(self) -> usize {
        self.malformed + self.connection_limited + self.other_errors
    }
}

pub struct FipsTcpEndpoint {
    endpoint: Arc<FipsEndpoint>,
    receiver: FipsEndpointServiceReceiver,
    fsp_service_port: u16,
    stack: Stack<PeerKey>,
    receive_batch: Vec<FipsEndpointServiceDatagram>,
}

impl FipsTcpEndpoint {
    /// Bind one FSP service and open its numerically matching TCP listener.
    pub async fn bind(
        endpoint: Arc<FipsEndpoint>,
        fsp_service_port: u16,
        config: Config,
        isn_seed: u64,
    ) -> Result<Self, AdapterError> {
        let stack = Self::listening_stack(fsp_service_port, config, isn_seed)?;
        let receiver = endpoint.register_service_receiver(fsp_service_port).await?;
        Ok(Self {
            endpoint,
            receiver,
            fsp_service_port,
            stack,
            receive_batch: Vec::new(),
        })
    }

    /// Bind one FSP service and advertise it to authenticated same-host peers.
    ///
    /// FIPS publishes the capability only after it owns the service port and
    /// withdraws it when this adapter's receiver is dropped.
    pub async fn bind_with_capability(
        endpoint: Arc<FipsEndpoint>,
        capability: LocalInstanceCapability,
        config: Config,
        isn_seed: u64,
    ) -> Result<Self, CapabilityBindError> {
        let fsp_service_port = capability
            .fsp_port
            .ok_or(LocalServiceRegistrationError::ServiceCapabilityMissingPort)?;
        let stack = Self::listening_stack(fsp_service_port, config, isn_seed)?;
        let receiver = endpoint
            .register_service_receiver_with_capability(capability)
            .await?;
        Ok(Self {
            endpoint,
            receiver,
            fsp_service_port,
            stack,
            receive_batch: Vec::new(),
        })
    }

    fn listening_stack(
        fsp_service_port: u16,
        config: Config,
        isn_seed: u64,
    ) -> Result<Stack<PeerKey>, AdapterError> {
        if fsp_service_port == 0 {
            return Err(AdapterError::InvalidServicePort);
        }
        let mut stack = Stack::new(config, isn_seed);
        stack.listen(fsp_service_port)?;
        Ok(stack)
    }

    pub fn accept(&mut self) -> Option<ConnectionId> {
        self.stack.accept(self.fsp_service_port)
    }

    /// Reserve existing table capacity using authenticated FIPS identities.
    /// This is only allocation priority; application authorization remains above
    /// TCP. Existing streams are unchanged, and zero disables the reservation.
    pub fn set_connection_reservation(
        &mut self,
        slots: usize,
        eligible: Arc<dyn Fn(&PeerIdentity) -> bool + Send + Sync>,
    ) -> Result<(), AdapterError> {
        self.stack
            .set_connection_reservation(slots, Arc::new(move |peer| eligible(&peer.0)))?;
        Ok(())
    }

    pub async fn connect(
        &mut self,
        peer: PeerIdentity,
        now_ms: u64,
    ) -> Result<ConnectionId, AdapterError> {
        let id = self
            .stack
            .connect(peer.into(), self.fsp_service_port, now_ms)?;
        if let Err(error) = self.flush().await {
            // `connect` retained a SYN-SENT entry before emitting its initial
            // segment. If FIPS rejects that segment, the caller never receives
            // the ID and therefore cannot release the hidden connection. A
            // SYN-SENT close removes it immediately; preserve the send error
            // even if rollback unexpectedly fails.
            let _ = self.stack.close(id, now_ms);
            return Err(error);
        }
        Ok(id)
    }

    pub async fn write(
        &mut self,
        id: ConnectionId,
        bytes: &[u8],
        now_ms: u64,
    ) -> Result<usize, AdapterError> {
        let accepted = self.stack.write(id, bytes, now_ms)?;
        self.flush().await?;
        Ok(accepted)
    }

    /// Accept payload and return an opaque cumulative TCP-ACK boundary.
    pub async fn write_with_marker(
        &mut self,
        id: ConnectionId,
        bytes: &[u8],
        now_ms: u64,
    ) -> Result<(usize, SendMarker), AdapterError> {
        let result = self.stack.write_with_marker(id, bytes, now_ms)?;
        self.flush().await?;
        Ok(result)
    }

    pub fn marker_status(&self, marker: &SendMarker) -> MarkerStatus {
        self.stack.marker_status(marker)
    }

    pub async fn read(
        &mut self,
        id: ConnectionId,
        max: usize,
        now_ms: u64,
    ) -> Result<Vec<u8>, AdapterError> {
        let bytes = self.stack.read(id, max, now_ms)?;
        self.flush().await?;
        Ok(bytes)
    }

    pub async fn close(&mut self, id: ConnectionId, now_ms: u64) -> Result<(), AdapterError> {
        self.stack.close(id, now_ms)?;
        self.flush().await
    }

    /// Abort a stream after an application-level graceful shutdown deadline.
    pub async fn abort(&mut self, id: ConnectionId) -> Result<(), AdapterError> {
        self.stack.abort(id)?;
        self.flush().await
    }

    /// Reclaim all streams for an authenticated peer, including half-open SYNs.
    pub async fn abort_peer(&mut self, peer: PeerIdentity) -> Result<usize, AdapterError> {
        let count = self.stack.abort_peer(&peer.into())?;
        self.flush().await?;
        Ok(count)
    }

    /// Earliest TCP timer deadline, using the clock supplied to stream operations.
    /// Recompute after every operation; `None` means no timer is needed.
    pub fn next_poll_at(&self, now_ms: u64) -> Option<u64> {
        self.stack.next_poll_at(now_ms)
    }

    pub async fn poll(&mut self, now_ms: u64) -> Result<(), AdapterError> {
        self.stack.poll(now_ms);
        self.flush().await
    }

    /// Wait for a bounded input batch without advancing TCP or sending packets.
    ///
    /// This wait is cancellation safe and retains the batch until a receive
    /// method processes it. Event loops can select this readiness future, then
    /// process the selected receive outside the cancellable selection.
    pub async fn wait_for_input(&mut self) -> Result<(), AdapterError> {
        if self.receive_batch.is_empty() {
            self.receiver
                .recv_batch_into(&mut self.receive_batch, 64)
                .await
                .ok_or(AdapterError::Closed)?;
        }
        Ok(())
    }

    /// Await one FIPS service batch and return its datagram count.
    ///
    /// Individual invalid or over-capacity segments are isolated within the
    /// batch. Use [`Self::receive_report`] to observe their bounded aggregate.
    pub async fn receive(&mut self, now_ms: u64) -> Result<usize, AdapterError> {
        Ok(self.receive_report(now_ms).await?.datagrams)
    }

    /// Feed one complete bounded FIPS batch into TCP and report isolated errors.
    pub async fn receive_report(&mut self, now_ms: u64) -> Result<ReceiveReport, AdapterError> {
        self.receive_report_filtered(now_ms, |_| true).await
    }

    /// Feed one bounded FIPS batch into TCP after checking each authenticated peer.
    ///
    /// Rejected datagrams never enter TCP, allocate connection state, or cause
    /// responses. They count toward [`ReceiveReport::connection_limited`]. The
    /// predicate applies to every datagram, including existing connections.
    pub async fn receive_report_filtered(
        &mut self,
        now_ms: u64,
        mut admitted: impl FnMut(&PeerIdentity) -> bool,
    ) -> Result<ReceiveReport, AdapterError> {
        self.receive_report_filtered_datagrams(now_ms, |peer, _| admitted(peer))
            .await
    }

    /// Inspect authenticated carrier identities and TCP bytes before admission.
    ///
    /// Like `receive_report_filtered`, rejection cannot allocate TCP state or
    /// emit a response. Bytes are untrusted and must be decoded before using
    /// fields to admit a new service client. The batch remains bounded to 64.
    pub async fn receive_report_filtered_datagrams(
        &mut self,
        now_ms: u64,
        admitted: impl FnMut(&PeerIdentity, &[u8]) -> bool,
    ) -> Result<ReceiveReport, AdapterError> {
        self.receive_report_filtered_datagrams_with_clock(|| now_ms, admitted)
            .await
    }

    /// Like `receive_report_filtered_datagrams`, sampling time after the wait.
    ///
    /// Use this in event loops that may wait indefinitely for input. The injected
    /// clock is called once per received batch, immediately before TCP processing,
    /// so retransmission deadlines and RTT samples use arrival rather than wait time.
    pub async fn receive_report_filtered_datagrams_with_clock(
        &mut self,
        clock: impl FnOnce() -> u64,
        mut admitted: impl FnMut(&PeerIdentity, &[u8]) -> bool,
    ) -> Result<ReceiveReport, AdapterError> {
        self.wait_for_input().await?;
        let count = self.receive_batch.len();
        let now_ms = clock();
        let mut report = ReceiveReport {
            datagrams: count,
            ..ReceiveReport::default()
        };
        for datagram in self.receive_batch.drain(..) {
            debug_assert_eq!(datagram.destination_port, self.fsp_service_port);
            if !admitted(&datagram.source_peer, datagram.data.as_slice()) {
                report.connection_limited += 1;
                continue;
            }
            match self.stack.input(
                datagram.source_peer.into(),
                datagram.data.as_slice(),
                now_ms,
            ) {
                Ok(()) => report.processed += 1,
                Err(StackError::Wire(_)) => report.malformed += 1,
                Err(StackError::ConnectionLimit) => report.connection_limited += 1,
                Err(_) => report.other_errors += 1,
            }
        }
        debug_assert_eq!(report.datagrams, report.processed + report.rejected());
        self.flush().await?;
        Ok(report)
    }

    pub fn state(&self, id: ConnectionId) -> Option<State> {
        self.stack.state(id)
    }

    pub fn is_read_closed(&self, id: ConnectionId) -> bool {
        self.stack.is_read_closed(id)
    }

    /// Return the authenticated FIPS identity bound to this stream.
    pub fn peer(&self, id: ConnectionId) -> Option<PeerIdentity> {
        self.stack.peer(id).map(|peer| peer.0)
    }

    /// Return the stream's internal `(local, remote)` TCP ports.
    pub fn ports(&self, id: ConnectionId) -> Option<(u16, u16)> {
        self.stack.ports(id)
    }

    async fn flush(&mut self) -> Result<(), AdapterError> {
        for outbound in self.stack.drain_outbound() {
            self.endpoint
                .send_datagram(
                    outbound.peer.0,
                    self.fsp_service_port,
                    self.fsp_service_port,
                    outbound.bytes,
                )
                .await?;
        }
        Ok(())
    }
}

#[derive(Debug)]
pub enum AdapterError {
    Closed,
    InvalidServicePort,
    Fips(FipsEndpointError),
    Identity(IdentityError),
    Tcp(StackError),
}

impl fmt::Display for AdapterError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Closed => formatter.write_str("FIPS endpoint service receiver closed"),
            Self::InvalidServicePort => formatter.write_str("FIPS service port must be non-zero"),
            Self::Fips(error) => write!(formatter, "FIPS endpoint error: {error}"),
            Self::Identity(error) => write!(formatter, "FIPS identity error: {error}"),
            Self::Tcp(error) => write!(formatter, "TCP/FIPS error: {error}"),
        }
    }
}

impl Error for AdapterError {}

impl From<FipsEndpointError> for AdapterError {
    fn from(error: FipsEndpointError) -> Self {
        Self::Fips(error)
    }
}

impl From<StackError> for AdapterError {
    fn from(error: StackError) -> Self {
        Self::Tcp(error)
    }
}

impl From<IdentityError> for AdapterError {
    fn from(error: IdentityError) -> Self {
        Self::Identity(error)
    }
}

/// Failure to prepare TCP state or register a capability-advertised FSP port.
#[derive(Debug)]
#[non_exhaustive]
pub enum CapabilityBindError {
    Adapter(AdapterError),
    Registration(LocalServiceRegistrationError),
}

impl fmt::Display for CapabilityBindError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Adapter(error) => error.fmt(formatter),
            Self::Registration(error) => error.fmt(formatter),
        }
    }
}

impl Error for CapabilityBindError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Adapter(error) => Some(error),
            Self::Registration(error) => Some(error),
        }
    }
}

impl From<AdapterError> for CapabilityBindError {
    fn from(error: AdapterError) -> Self {
        Self::Adapter(error)
    }
}

impl From<LocalServiceRegistrationError> for CapabilityBindError {
    fn from(error: LocalServiceRegistrationError) -> Self {
        Self::Registration(error)
    }
}
