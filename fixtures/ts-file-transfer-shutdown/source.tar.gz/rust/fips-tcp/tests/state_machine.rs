use fips_tcp::{Config, ConnectionId, MarkerStatus, State};

mod support;
use support::Pair;

impl Pair {
    fn connect(&mut self) -> (ConnectionId, ConnectionId) {
        self.b.listen(443).unwrap();
        let client = self.a.connect("b".to_string(), 443, self.now).unwrap();
        self.settle();
        assert_eq!(self.a.state(client), Some(State::Established));
        let server = self.b.accept(443).expect("server should accept");
        assert_eq!(self.b.state(server), Some(State::Established));
        (client, server)
    }
}

#[test]
fn handshake_bidirectional_stream_and_orderly_close() {
    let mut pair = Pair::new(Config::default());
    let (client, server) = pair.connect();

    assert_eq!(
        pair.a.write(client, b"hello from rust", pair.now).unwrap(),
        15
    );
    assert_eq!(pair.b.write(server, b"hello back", pair.now).unwrap(), 10);
    pair.settle();
    assert_eq!(
        pair.b.read(server, 1024, pair.now).unwrap(),
        b"hello from rust"
    );
    assert_eq!(pair.a.read(client, 1024, pair.now).unwrap(), b"hello back");

    pair.a.close(client, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.b.state(server), Some(State::CloseWait));
    assert!(pair.b.is_read_closed(server));
    pair.b.close(server, pair.now).unwrap();
    pair.settle();
    pair.advance(60_000);
    pair.settle();
    assert_eq!(pair.a.state(client), None);
    assert_eq!(pair.b.state(server), None);
}

#[test]
fn per_peer_limit_counts_active_and_time_wait_until_expiry() {
    let mut pair = Pair::new(Config {
        max_connections_per_peer: 1,
        time_wait_ms: 50,
        ..Config::default()
    });
    let (client, server) = pair.connect();
    assert!(pair.a.connect("b".to_string(), 443, pair.now).is_err());
    pair.a.close(client, pair.now).unwrap();
    pair.settle();
    pair.b.close(server, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.a.state(client), Some(State::TimeWait));
    assert!(pair.a.connect("b".to_string(), 443, pair.now).is_err());

    pair.advance(50);
    pair.settle();
    pair.a
        .connect("b".to_string(), 443, pair.now)
        .expect("expired TIME-WAIT must release per-peer capacity");
}

#[test]
fn reservation_changes_preserve_existing_streams_and_time_wait_limits() {
    use std::sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    };
    let eligible = Arc::new(AtomicBool::new(true));
    let mut pair = Pair::new(Config {
        max_connections: 2,
        max_connections_per_peer: 1,
        time_wait_ms: 50,
        ..Config::default()
    });
    for stack in [&mut pair.a, &mut pair.b] {
        let eligible = eligible.clone();
        stack
            .set_connection_reservation(1, Arc::new(move |_| eligible.load(Ordering::Relaxed)))
            .unwrap();
    }
    let (client, server) = pair.connect();
    pair.b.connect("half-open".into(), 443, pair.now).unwrap();
    pair.b.drain_outbound();
    eligible.store(false, Ordering::Relaxed);
    assert!(pair.b.connect("new-peer".into(), 443, pair.now).is_err());
    assert_eq!(pair.a.write(client, b"request", pair.now).unwrap(), 7);
    assert_eq!(pair.b.write(server, b"reply", pair.now).unwrap(), 5);
    pair.settle();
    assert_eq!(pair.b.read(server, 16, pair.now).unwrap(), b"request");
    assert_eq!(pair.a.read(client, 16, pair.now).unwrap(), b"reply");
    pair.a.close(client, pair.now).unwrap();
    pair.settle();
    pair.b.close(server, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.a.state(client), Some(State::TimeWait));
    assert!(pair.a.connect("new-peer".into(), 443, pair.now).is_err());
    pair.advance(50);
    pair.settle();
    assert_eq!(pair.a.state(client), None);
    pair.a.connect("new-peer".into(), 443, pair.now).unwrap();
}

#[test]
fn per_peer_limit_counts_fin_wait_2_until_ack_without_fin_deadline() {
    let mut pair = Pair::new(Config {
        max_connections_per_peer: 1,
        fin_wait_2_ms: 50,
        ..Config::default()
    });
    let (client, _server) = pair.connect();
    pair.a.close(client, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.a.state(client), Some(State::FinWait2));
    assert!(pair.a.connect("b".to_string(), 443, pair.now).is_err());

    pair.advance(49);
    pair.settle();
    assert_eq!(pair.a.state(client), Some(State::FinWait2));
    assert!(pair.a.connect("b".to_string(), 443, pair.now).is_err());

    pair.advance(1);
    pair.settle();
    assert_eq!(pair.a.state(client), None);
    pair.a
        .connect("b".to_string(), 443, pair.now)
        .expect("expired FIN-WAIT-2 must release per-peer capacity");
}

#[test]
fn marker_waits_for_zero_window_buffered_payload_and_zero_length_is_a_barrier() {
    let mut pair = Pair::new(Config {
        mss: 8,
        receive_buffer: 8,
        ..Config::default()
    });
    let (client, server) = pair.connect();
    pair.a.write(client, &[0x11; 8], pair.now).unwrap();
    pair.settle();

    let (accepted, marker) = pair
        .a
        .write_with_marker(client, &[0x22; 8], pair.now)
        .unwrap();
    assert_eq!(accepted, 8);
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Pending);
    assert!(pair.a.drain_outbound().is_empty());
    let (accepted, barrier) = pair.a.write_with_marker(client, &[], pair.now).unwrap();
    assert_eq!(accepted, 0);
    assert_eq!(pair.a.marker_status(&barrier), MarkerStatus::Pending);

    assert_eq!(pair.b.read(server, 8, pair.now).unwrap(), [0x11; 8]);
    pair.settle();
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Acked);
    assert_eq!(pair.a.marker_status(&barrier), MarkerStatus::Acked);
    let (_, empty_after_ack) = pair.a.write_with_marker(client, &[], pair.now).unwrap();
    assert_eq!(pair.a.marker_status(&empty_after_ack), MarkerStatus::Acked);
}

#[test]
fn marker_tracks_partial_wraparound_acks_without_retransmit_or_other_stream_noise() {
    let mut pair = Pair::new(Config {
        mss: 8,
        initial_rto_ms: 200,
        ..Config::default()
    });
    pair.b.listen(443).unwrap();
    let initial = u32::MAX - 8;
    let client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, initial, pair.now)
        .unwrap();
    pair.settle();
    pair.b.accept(443).unwrap();
    let other = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_001, 443, 100, pair.now)
        .unwrap();
    pair.settle();
    pair.b.accept(443).unwrap();

    let (accepted, marker) = pair
        .a
        .write_with_marker(client, &[0x33; 12], pair.now)
        .unwrap();
    assert_eq!(accepted, 12);
    pair.a.drain_outbound();
    for byte in 0..4 {
        pair.a.write(other, &[byte; 4], pair.now).unwrap();
        pair.settle();
        assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Pending);
    }

    pair.advance(200);
    pair.a.poll(pair.now);
    assert!(!pair.a.drain_outbound().is_empty());
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Pending);
    let payload_start = initial.wrapping_add(1);
    let partial = ack(443, 50_000, payload_start.wrapping_add(5));
    pair.a.input("b".to_string(), &partial, pair.now).unwrap();
    for _ in 0..3 {
        pair.a.input("b".to_string(), &partial, pair.now).unwrap();
    }
    pair.a.drain_outbound();
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Pending);

    pair.a
        .input(
            "b".to_string(),
            &ack(443, 50_000, payload_start.wrapping_add(12)),
            pair.now,
        )
        .unwrap();
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Acked);
    let (_, later) = pair
        .a
        .write_with_marker(client, &[0x44; 4], pair.now)
        .unwrap();
    pair.a.drain_outbound();
    assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Acked);
    assert_eq!(pair.a.marker_status(&later), MarkerStatus::Pending);
    pair.a
        .input(
            "b".to_string(),
            &ack(443, 50_000, payload_start.wrapping_add(16)),
            pair.now,
        )
        .unwrap();
    assert_eq!(pair.a.marker_status(&later), MarkerStatus::Acked);
}

#[test]
fn marker_is_gone_after_abort_and_tuple_reuse_cannot_revive_it() {
    let mut pair = Pair::new(Config::default());
    pair.b.listen(443).unwrap();
    let old_client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, 100, pair.now)
        .unwrap();
    pair.settle();
    let old_server = pair.b.accept(443).unwrap();
    let (_, old_marker) = pair
        .a
        .write_with_marker(old_client, &[0x55; 4], pair.now)
        .unwrap();
    assert_eq!(
        pair.b.marker_status(&old_marker),
        MarkerStatus::ConnectionGone
    );
    pair.a.abort(old_client).unwrap();
    pair.a.drain_outbound();
    pair.b.abort(old_server).unwrap();
    pair.b.drain_outbound();
    assert_eq!(
        pair.a.marker_status(&old_marker),
        MarkerStatus::ConnectionGone
    );

    let new_client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, 1_000_000, pair.now)
        .unwrap();
    pair.settle();
    pair.b.accept(443).unwrap();
    let (_, new_marker) = pair
        .a
        .write_with_marker(new_client, &[0x66; 16], pair.now)
        .unwrap();
    pair.settle();
    assert_eq!(pair.a.marker_status(&new_marker), MarkerStatus::Acked);
    assert_eq!(
        pair.a.marker_status(&old_marker),
        MarkerStatus::ConnectionGone
    );
}

#[test]
fn abort_after_zero_window_close_deadline_resets_peer_and_releases_capacity() {
    let mut pair = Pair::new(Config {
        mss: 8,
        receive_buffer: 8,
        max_connections_per_peer: 1,
        ..Config::default()
    });
    let (client, server) = pair.connect();
    pair.a.write(client, &[0x55; 8], pair.now).unwrap();
    pair.settle();
    pair.a.close(client, pair.now).unwrap();

    pair.advance(50);
    pair.settle();
    assert_eq!(pair.a.state(client), Some(State::Established));
    assert!(pair.a.connect("b".to_string(), 443, pair.now).is_err());

    let unrelated = pair.a.connect("c".to_string(), 443, pair.now).unwrap();
    pair.a.abort(client).unwrap();
    assert_eq!(pair.a.state(client), None);
    let outbound = pair.a.drain_outbound();
    let reset_outbound: Vec<_> = outbound.iter().filter(|item| item.peer == "b").collect();
    let unrelated_outbound: Vec<_> = outbound.iter().filter(|item| item.peer == "c").collect();
    assert_eq!(reset_outbound.len(), 1, "abort must emit exactly one reset");
    assert_eq!(
        unrelated_outbound.len(),
        1,
        "another tuple must be preserved"
    );
    let reset = fips_tcp::wire::Segment::decode(&reset_outbound[0].bytes).unwrap();
    assert_eq!(reset.flags, fips_tcp::wire::Flags::RST);
    assert_eq!(reset.ack, None);
    assert_eq!(reset.window, 0);

    pair.b
        .input("a".to_string(), &reset_outbound[0].bytes, pair.now)
        .unwrap();
    assert_eq!(pair.b.state(server), None);
    let replacement = pair
        .a
        .connect("b".to_string(), 443, pair.now)
        .expect("abort must release per-peer capacity immediately");
    let replacement_syn = pair.a.drain_outbound();
    assert_eq!(replacement_syn.len(), 1);
    assert!(
        fips_tcp::wire::Segment::decode(&replacement_syn[0].bytes)
            .unwrap()
            .flags
            .contains(fips_tcp::wire::Flags::SYN)
    );

    assert!(matches!(
        pair.a.abort(client),
        Err(fips_tcp::StackError::UnknownConnection)
    ));
    assert_eq!(pair.a.state(unrelated), Some(State::SynSent));
    assert_eq!(pair.a.state(replacement), Some(State::SynSent));
    assert!(pair.a.drain_outbound().is_empty());
}

#[test]
fn reset_validation_survives_stale_tuple_reuse_and_challenges_in_window_guess() {
    let mut pair = Pair::new(Config::default());
    pair.b.listen(443).unwrap();
    let old_client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, 100, pair.now)
        .unwrap();
    pair.settle();
    let old_server = pair.b.accept(443).unwrap();

    pair.a.abort(old_client).unwrap();
    let stale_reset = pair.a.drain_outbound().remove(0).bytes;
    pair.b.abort(old_server).unwrap();
    pair.b.drain_outbound();

    let new_client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, 1_000_000, pair.now)
        .unwrap();
    pair.settle();
    let new_server = pair.b.accept(443).unwrap();
    pair.b
        .input("a".to_string(), &stale_reset, pair.now)
        .unwrap();
    assert_eq!(pair.b.state(new_server), Some(State::Established));
    assert!(pair.b.drain_outbound().is_empty());

    let in_window = reset(50_000, 443, 1_000_002);
    pair.b.input("a".to_string(), &in_window, pair.now).unwrap();
    assert_eq!(pair.b.state(new_server), Some(State::Established));
    let challenge = pair.b.drain_outbound();
    assert_eq!(challenge.len(), 1);
    let challenge = fips_tcp::wire::Segment::decode(&challenge[0].bytes).unwrap();
    assert_eq!(challenge.flags, fips_tcp::wire::Flags::ACK);
    assert_eq!(challenge.ack, Some(1_000_001));

    let outside = reset(50_000, 443, 1_000_001 + u32::from(u16::MAX));
    pair.b.input("a".to_string(), &outside, pair.now).unwrap();
    assert_eq!(pair.b.state(new_server), Some(State::Established));
    assert!(pair.b.drain_outbound().is_empty());

    pair.a.abort(new_client).unwrap();
    let exact = pair.a.drain_outbound();
    assert_eq!(exact.len(), 1);
    pair.b
        .input("a".to_string(), &exact[0].bytes, pair.now)
        .unwrap();
    assert_eq!(pair.b.state(new_server), None);
}

#[test]
fn syn_sent_ignores_unacknowledged_reset_but_accepts_closed_port_reset() {
    let mut pair = Pair::new(Config::default());
    let client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, 100, pair.now)
        .unwrap();
    let syn = pair.a.drain_outbound().remove(0).bytes;
    pair.a
        .input("b".to_string(), &reset(443, 50_000, 0), pair.now)
        .unwrap();
    assert_eq!(pair.a.state(client), Some(State::SynSent));
    assert!(pair.a.drain_outbound().is_empty());

    pair.b.input("a".to_string(), &syn, pair.now).unwrap();
    let rejection = pair.b.drain_outbound();
    assert_eq!(rejection.len(), 1);
    let rejection_segment = fips_tcp::wire::Segment::decode(&rejection[0].bytes).unwrap();
    assert!(rejection_segment.flags.contains(fips_tcp::wire::Flags::RST));
    assert!(rejection_segment.flags.contains(fips_tcp::wire::Flags::ACK));
    assert_eq!(rejection_segment.ack, Some(101));
    pair.a
        .input("b".to_string(), &rejection[0].bytes, pair.now)
        .unwrap();
    assert_eq!(pair.a.state(client), None);
}

#[test]
fn lost_syn_and_first_payload_recover_via_rto() {
    let mut pair = Pair::new(Config::default());
    pair.b.listen(443).unwrap();
    let client = pair.a.connect("b".to_string(), 443, pair.now).unwrap();

    let mut dropped_syn = false;
    pair.step_with(|from_a, bytes| {
        if from_a && !dropped_syn {
            dropped_syn = true;
            Vec::new()
        } else {
            vec![bytes]
        }
    });
    assert_eq!(pair.a.state(client), Some(State::SynSent));
    pair.advance(1_000);
    pair.settle();
    let server = pair
        .b
        .accept(443)
        .expect("retransmitted SYN should connect");

    let payload = vec![0x5a; 4096];
    assert_eq!(
        pair.a.write(client, &payload, pair.now).unwrap(),
        payload.len()
    );
    let mut dropped_data = false;
    pair.step_with(|from_a, bytes| {
        let segment = fips_tcp::wire::Segment::decode(&bytes).unwrap();
        if from_a && !segment.payload.is_empty() && !dropped_data {
            dropped_data = true;
            Vec::new()
        } else {
            vec![bytes]
        }
    });
    pair.settle();
    assert!(pair.b.read(server, payload.len(), pair.now).unwrap().len() < payload.len());
    pair.advance(1_000);
    pair.settle();
    let mut received = Vec::new();
    while received.len() < payload.len() {
        received.extend(pair.b.read(server, payload.len(), pair.now).unwrap());
        if received.len() < payload.len() {
            pair.advance(1_000);
            pair.settle();
        }
    }
    assert_eq!(received, payload);
}

fn reset(source_port: u16, destination_port: u16, sequence: u32) -> Vec<u8> {
    let mut reset = fips_tcp::wire::Segment::new(source_port, destination_port, sequence);
    reset.flags = fips_tcp::wire::Flags::RST;
    reset.encode().unwrap()
}

fn ack(source_port: u16, destination_port: u16, acknowledgment: u32) -> Vec<u8> {
    let mut ack = fips_tcp::wire::Segment::new(source_port, destination_port, 0);
    ack.flags = fips_tcp::wire::Flags::ACK;
    ack.ack = Some(acknowledgment);
    ack.encode().unwrap()
}

#[test]
fn reverse_order_and_duplicate_segments_reassemble_once() {
    let config = Config {
        mss: 256,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let (client, server) = pair.connect();
    let payload: Vec<u8> = (0..2048).map(|index| (index % 251) as u8).collect();
    pair.a.write(client, &payload, pair.now).unwrap();

    pair.a.poll(pair.now);
    let mut packets = pair.a.drain_outbound();
    packets.reverse();
    for outbound in packets {
        pair.b
            .input("a".to_string(), &outbound.bytes, pair.now)
            .unwrap();
        pair.b
            .input("a".to_string(), &outbound.bytes, pair.now)
            .unwrap();
    }
    pair.settle();
    assert_eq!(
        pair.b.read(server, payload.len(), pair.now).unwrap(),
        payload
    );
}

#[test]
fn receive_window_reopens_after_application_reads() {
    let config = Config {
        mss: 8,
        receive_buffer: 16,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let (client, server) = pair.connect();
    let payload: Vec<u8> = (0..64).collect();
    pair.a.write(client, &payload, pair.now).unwrap();
    pair.settle();

    let first = pair.b.read(server, 16, pair.now).unwrap();
    assert_eq!(first, payload[..16]);
    pair.settle();
    let mut received = first;
    for _ in 0..16 {
        let part = pair.b.read(server, 16, pair.now).unwrap();
        received.extend(part);
        pair.settle();
        if received.len() == payload.len() {
            break;
        }
    }
    assert_eq!(received, payload);
}

#[test]
fn byte_sequence_wraparound_is_ordered_correctly() {
    let mut pair = Pair::new(Config::default());
    pair.b.listen(443).unwrap();
    let client = pair
        .a
        .connect_from_with_isn("b".to_string(), 50_000, 443, u32::MAX - 8, pair.now)
        .unwrap();
    pair.settle();
    let server = pair.b.accept(443).unwrap();
    let payload = b"crosses the sequence wrap";
    pair.a.write(client, payload, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.b.read(server, 1024, pair.now).unwrap(), payload);
}

#[test]
fn close_waits_for_flow_controlled_bytes_before_fin() {
    let config = Config {
        mss: 8,
        receive_buffer: 16,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let (client, server) = pair.connect();
    let payload: Vec<u8> = (0..64).collect();
    pair.a.write(client, &payload, pair.now).unwrap();
    pair.a.close(client, pair.now).unwrap();
    pair.settle();

    let mut received = Vec::new();
    for _ in 0..8 {
        received.extend(pair.b.read(server, 16, pair.now).unwrap());
        pair.settle();
        if pair.b.is_read_closed(server) {
            break;
        }
    }
    assert_eq!(received, payload);
    assert!(pair.b.is_read_closed(server));
    assert_eq!(pair.b.state(server), Some(State::CloseWait));
}

#[test]
fn zero_window_probe_recovers_a_lost_window_update() {
    let config = Config {
        mss: 8,
        receive_buffer: 16,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let (client, server) = pair.connect();
    let payload: Vec<u8> = (0..64).collect();
    pair.a.write(client, &payload, pair.now).unwrap();
    pair.settle();

    let mut received = pair.b.read(server, 16, pair.now).unwrap();
    let mut dropped_update = false;
    pair.step_with(|from_a, bytes| {
        if !from_a && !dropped_update {
            dropped_update = true;
            Vec::new()
        } else {
            vec![bytes]
        }
    });
    assert!(
        dropped_update,
        "receiver should advertise its reopened window"
    );
    pair.advance(1_000);
    pair.settle();

    for _ in 0..8 {
        received.extend(pair.b.read(server, 16, pair.now).unwrap());
        pair.settle();
        if received.len() == payload.len() {
            break;
        }
    }
    assert_eq!(received, payload);
}

#[test]
fn closed_port_rst_and_retry_limit_remove_connections() {
    let config = Config {
        initial_rto_ms: 200,
        max_retransmissions: 1,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let client = pair.a.connect("b".to_string(), 443, pair.now).unwrap();
    pair.settle();
    assert_eq!(pair.a.state(client), None, "closed port should reset SYN");

    let client = pair.a.connect("b".to_string(), 444, pair.now).unwrap();
    pair.a.drain_outbound();
    pair.advance(200);
    pair.a.poll(pair.now);
    assert_eq!(
        pair.a.state(client),
        None,
        "retry limit should close connection"
    );
}

#[test]
fn triple_duplicate_ack_fast_retransmits_without_waiting_for_rto() {
    let config = Config {
        mss: 128,
        ..Config::default()
    };
    let mut pair = Pair::new(config);
    let (client, server) = pair.connect();
    pair.a.write(client, &[0x11; 2048], pair.now).unwrap();
    pair.settle();
    pair.b.read(server, 4096, pair.now).unwrap();
    pair.settle();

    let payload: Vec<u8> = (0..2048).map(|index| (index % 251) as u8).collect();
    pair.a.write(client, &payload, pair.now).unwrap();
    let packets = pair.a.drain_outbound();
    assert!(
        packets.len() >= 4,
        "warm connection should have a larger cwnd"
    );
    let first = fips_tcp::wire::Segment::decode(&packets[0].bytes).unwrap();
    for outbound in packets.into_iter().skip(1) {
        pair.b
            .input("a".to_string(), &outbound.bytes, pair.now)
            .unwrap();
    }
    for outbound in pair.b.drain_outbound() {
        pair.a
            .input("b".to_string(), &outbound.bytes, pair.now)
            .unwrap();
    }
    let retransmits = pair.a.drain_outbound();
    assert!(retransmits.iter().any(|outbound| {
        let segment = fips_tcp::wire::Segment::decode(&outbound.bytes).unwrap();
        segment.seq == first.seq && segment.payload == first.payload
    }));
    for outbound in retransmits {
        pair.b
            .input("a".to_string(), &outbound.bytes, pair.now)
            .unwrap();
    }
    pair.settle();
    assert_eq!(
        pair.b.read(server, payload.len(), pair.now).unwrap(),
        payload
    );
}

#[test]
fn lost_fin_is_retransmitted() {
    let mut pair = Pair::new(Config::default());
    let (client, server) = pair.connect();
    pair.a.close(client, pair.now).unwrap();
    let mut dropped = false;
    pair.step_with(|from_a, bytes| {
        let segment = fips_tcp::wire::Segment::decode(&bytes).unwrap();
        if from_a && segment.flags.contains(fips_tcp::wire::Flags::FIN) && !dropped {
            dropped = true;
            Vec::new()
        } else {
            vec![bytes]
        }
    });
    assert!(dropped);
    assert_eq!(pair.b.state(server), Some(State::Established));
    pair.advance(1_000);
    pair.settle();
    assert_eq!(pair.b.state(server), Some(State::CloseWait));
}

#[test]
fn timed_out_small_segment_flight_recovers_on_ack_progress() {
    #[derive(serde::Deserialize)]
    #[serde(rename_all = "camelCase")]
    struct RecoveryVector {
        initial_sequence: u32,
        warmup_bytes: usize,
        chunk_bytes: usize,
        chunk_count: usize,
        dropped_poll_deltas_ms: Vec<u64>,
        recovery_poll_delta_ms: u64,
        max_recovery_pump_steps: usize,
        expected_payload_bytes: usize,
    }
    let vectors: Vec<RecoveryVector> =
        serde_json::from_str(include_str!("../protocol/recovery-vectors.json")).unwrap();
    for vector in vectors {
        let mut pair = Pair::new(Config::default());
        pair.b.listen(443).unwrap();
        let client = pair
            .a
            .connect_from_with_isn(
                "b".to_string(),
                50_000,
                443,
                vector.initial_sequence,
                pair.now,
            )
            .unwrap();
        pair.settle();
        let server = pair.b.accept(443).unwrap();
        pair.a
            .write(client, &vec![0; vector.warmup_bytes], pair.now)
            .unwrap();
        pair.settle();
        assert_eq!(
            pair.b
                .read(server, vector.warmup_bytes, pair.now)
                .unwrap()
                .len(),
            vector.warmup_bytes
        );
        pair.settle();
        let payload: Vec<u8> = (0..vector.chunk_count)
            .flat_map(|index| vec![index as u8; vector.chunk_bytes])
            .collect();
        assert_eq!(payload.len(), vector.expected_payload_bytes);
        for segment in payload.chunks(vector.chunk_bytes) {
            assert_eq!(
                pair.a.write(client, segment, pair.now).unwrap(),
                segment.len()
            );
        }
        let (_, marker) = pair.a.write_with_marker(client, &[], pair.now).unwrap();
        let lost = pair.a.drain_outbound();
        assert_eq!(
            lost.len(),
            vector.chunk_count,
            "all small writes must be in the lost flight"
        );
        for delta in vector.dropped_poll_deltas_ms {
            pair.advance(delta);
            pair.a.poll(pair.now);
            assert_eq!(pair.a.drain_outbound().len(), 1);
        }
        pair.advance(vector.recovery_poll_delta_ms);
        pair.a.poll(pair.now);
        assert!(vector.chunk_count <= vector.max_recovery_pump_steps);
        for _ in 0..vector.chunk_count {
            let repair = pair.a.drain_outbound();
            assert_eq!(repair.len(), 1, "one repair follows each advancing ACK");
            pair.b
                .input("a".to_string(), &repair[0].bytes, pair.now)
                .unwrap();
            let acknowledgments = pair.b.drain_outbound();
            assert_eq!(acknowledgments.len(), 1);
            pair.a
                .input("b".to_string(), &acknowledgments[0].bytes, pair.now)
                .unwrap();
        }
        assert!(pair.a.drain_outbound().is_empty());
        assert_eq!(pair.a.marker_status(&marker), MarkerStatus::Acked);
        assert_eq!(
            pair.b.read(server, payload.len(), pair.now).unwrap(),
            payload
        );
        pair.settle();
        pair.a.write(client, b"new first", pair.now).unwrap();
        pair.a.write(client, b"new second", pair.now).unwrap();
        let next_flight = pair.a.drain_outbound();
        assert_eq!(next_flight.len(), 2);
        pair.b
            .input("a".to_string(), &next_flight[0].bytes, pair.now)
            .unwrap();
        for acknowledgment in pair.b.drain_outbound() {
            pair.a
                .input("b".to_string(), &acknowledgment.bytes, pair.now)
                .unwrap();
        }
        assert!(
            pair.a.drain_outbound().is_empty(),
            "completed boundary must not repair a later normal flight"
        );
    }
}

#[test]
fn timed_out_flight_repair_respects_ack_window_and_retry_bounds() {
    for window in [0, u16::MAX] {
        let mut pair = Pair::new(Config {
            max_retransmissions: 2,
            ..Config::default()
        });
        let (client, _server) = pair.connect();
        pair.a.write(client, b"first", pair.now).unwrap();
        pair.a.write(client, b"second", pair.now).unwrap();
        let lost = pair.a.drain_outbound();
        let first = fips_tcp::wire::Segment::decode(&lost[0].bytes).unwrap();
        pair.advance(200);
        pair.a.poll(pair.now);
        assert_eq!(pair.a.drain_outbound().len(), 1);
        let mut partial = fips_tcp::wire::Segment::decode(&ack(
            first.dst_port,
            first.src_port,
            first.seq.wrapping_add(1),
        ))
        .unwrap();
        partial.window = window;
        pair.a
            .input("b".to_string(), &partial.encode().unwrap(), pair.now)
            .unwrap();
        assert!(
            pair.a.drain_outbound().is_empty(),
            "an exhausted segment cannot get another repair"
        );
    }

    let mut pair = Pair::new(Config::default());
    let (client, server) = pair.connect();
    pair.a.write(client, b"first", pair.now).unwrap();
    pair.a.write(client, b"second", pair.now).unwrap();
    let lost = pair.a.drain_outbound();
    let first = fips_tcp::wire::Segment::decode(&lost[0].bytes).unwrap();
    pair.advance(200);
    pair.a.poll(pair.now);
    let repair = pair.a.drain_outbound();
    for acknowledgment in [first.seq, first.seq.wrapping_add(100_000)] {
        pair.a
            .input(
                "b".to_string(),
                &ack(first.dst_port, first.src_port, acknowledgment),
                pair.now,
            )
            .unwrap();
        assert!(
            pair.a.drain_outbound().is_empty(),
            "non-advancing or invalid ACK cannot drive repair"
        );
    }
    pair.b
        .input("a".to_string(), &repair[0].bytes, pair.now)
        .unwrap();
    let mut closed = fips_tcp::wire::Segment::decode(&pair.b.drain_outbound()[0].bytes).unwrap();
    closed.window = 0;
    pair.a
        .input("b".to_string(), &closed.encode().unwrap(), pair.now)
        .unwrap();
    assert!(
        pair.a.drain_outbound().is_empty(),
        "newly closed window must suppress full repair"
    );
    pair.b.read(server, 5, pair.now).unwrap();
    for reopened in pair.b.drain_outbound() {
        pair.a
            .input("b".to_string(), &reopened.bytes, pair.now)
            .unwrap();
    }
    assert!(
        pair.a.drain_outbound().is_empty(),
        "window update alone cannot drive repair"
    );
    pair.advance(400);
    pair.settle();
    assert_eq!(pair.b.read(server, 6, pair.now).unwrap(), b"second");
}
