# Changelog

## nvpn-fips-tcp-endpoint 0.2.50 - 2026-10-28

- Use FIPS core 0.4.115 for the verified allocation improvement.
  Preserve TCP core 0.2.6 and the TCP/FIPS wire format.
- Commit release tooling with pinned inputs and source/package verification.

## nvpn-fips-tcp-endpoint 0.2.42 - 2026-10-21

- Use FIPS core 0.4.107 for authenticated Bluetooth identity reconnection.
  Keep TCP core 0.2.6 and the wire format.

## nvpn-fips-tcp-endpoint 0.2.41 - 2026-10-18

- Use FIPS core 0.4.106 to retain the refreshed WebRTC and mDNS fixes alongside
  native socket protection. Keep TCP core 0.2.6 and the wire format.

## nvpn-fips-tcp-endpoint 0.2.40 - 2026-10-18

- Use FIPS core 0.4.105 for handshake reply hardening, failed tree announcement
  recovery, and DNS query screening. Keep TCP core 0.2.6 and the wire format.

## nvpn-fips-tcp-endpoint 0.2.38 - 2026-10-18

- Use FIPS core 0.4.103 for routing-role status, recovery from lost initial
  connection messages, and reuse of successful discovery signature checks.
  Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.37 - 2026-10-17

- Use FIPS core 0.4.102 for negotiated client-only routing and older-peer
  compatibility. Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.36 - 2026-10-14

- Use FIPS core 0.4.101 for confirmed fallback recovery after a lost initial UDP
  handshake reply and to retain received packets across bounded processing turns.
  Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.35 - 2026-10-14

- Use FIPS core 0.4.100 for lower mobile idle work, ordered startup delivery,
  and preservation of incoming packets during successful or failed sends.
  Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.34 - 2026-10-13

- Use FIPS core 0.4.99 so applications can provide protected carrier sockets and
  host name resolution. Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.33 - 2026-10-12

- Use FIPS core 0.4.98 to avoid discovery timer wakeups when no event is pending.
  Preserve TCP core 0.2.6 and the TCP/FIPS wire format.

## nvpn-fips-tcp-endpoint 0.2.31 - 2026-10-10

- Require FIPS core 0.4.96 for bounded handshake retries and control processing.
  Preserve TCP core 0.2.5 and the TCP/FIPS wire format.

## nvpn-fips-tcp 0.2.5 / @fips/tcp 0.2.4 - 2026-10-08

- Apply the existing transmission limit to retries triggered by duplicate
  acknowledgments and duplicate connection requests. Suppressed retries do not
  extend the timeout, and the final permitted transmission can still be acknowledged.
- Verify matching Rust and TypeScript behavior with shared sequence-wrap and
  retry-budget vectors, plus live delivery and continued streaming in both directions.

## nvpn-fips-tcp-endpoint 0.2.30 - 2026-10-08

- Retain authenticated peer identities through TCP processing instead of
  repeatedly encoding and parsing them for each segment. Preserve canonical
  identity matching, per-peer limits, and reserved connection classification.
- Require FIPS core 0.4.95 and TCP core 0.2.5 for bounded idle control handling,
  acknowledgment recovery, and retransmission attempts. Preserve the TCP/FIPS wire format.

## nvpn-fips-tcp 0.2.4 / @fips/tcp 0.2.3 - 2026-10-08

- Avoid unnecessary retransmission when a receiver advertises more buffer
  space. Reset the duplicate-acknowledgment count when a window update or
  data/control acknowledgment interrupts the sequence of loss signals.
- Preserve shrinking-window loss signals required by deployed FIPS receivers.
  Document this compatibility difference from standard TCP in the reference.
- Include the existing fixes for RTT backoff during cumulative recovery and
  reopening a stream after its reset packet is lost, plus bounded connection
  reservations for authenticated peers.
- Verify Rust and TypeScript parity with shared normal/wrapping sequence
  vectors, live bidirectional interoperability, and a direct smoltcp comparison
  of window-update and genuine-loss behavior. Preserve the wire format.

## nvpn-fips-tcp-endpoint 0.2.29 - 2026-10-04

- Require FIPS core 0.4.94 so concurrent discovery requests from distinct
  origins are admitted independently within the existing ingress bounds.
- Preserve TCP/FIPS wire bytes and the 0.2.3 stream state machine.

## nvpn-fips-tcp 0.2.3 / nvpn-fips-tcp-endpoint 0.2.28 - 2026-10-04

- Add peer-wide abort helpers that reuse existing stream reset behavior and
  reclaim half-open connections before an application reuses an admission slot.
- Preserve the TCP/FIPS wire format and ordinary stream behavior.

## nvpn-fips-tcp-endpoint 0.2.27 - 2026-10-04

- Expose authenticated peer identity and untrusted datagram bytes to admission
  filters before TCP state allocation. Keep the original identity-only API.

## Endpoint 0.2.23 - 2026-10-02

- Allow applications to reject authenticated peers before incoming datagrams
  allocate TCP state, while preserving bounded batch processing.
- Require FIPS core 0.4.90 for handshake reply windows, admitted lookup route
  retention, and persistent identity error handling. TCP/FIPS wire bytes and
  the published 0.2.2 state machine are unchanged.

## Endpoint 0.2.22 - 2026-10-01

- Require FIPS core 0.4.89. TCP/FIPS wire bytes and the published 0.2.2
  state machine are unchanged.

## Endpoint 0.2.21 - 2026-09-30

- Require FIPS core 0.4.88 to maintain pending Bloom deadlines incrementally.
  TCP/FIPS wire bytes and the published 0.2.2 state machine remain unchanged.

## Endpoint 0.2.20 - 2026-09-30

- Require FIPS core 0.4.87 to share Bloom-filter aggregation across peers.
  TCP/FIPS wire bytes and the published 0.2.2 state machine remain unchanged.

## Endpoint 0.2.19 - 2026-09-30

- Require FIPS core 0.4.86 for linear peer snapshots and routing recovery under
  load. TCP/FIPS wire bytes and the published 0.2.2 state machine remain unchanged.

## Endpoint 0.2.18 - 2026-09-28

- Require FIPS core 0.4.83 for connection lifecycle, discovery, and identity
  recovery improvements. TCP/FIPS wire bytes and the published 0.2.2 state
  machine remain unchanged.

## Endpoint 0.2.17 - 2026-09-15

- Require FIPS core 0.4.82 for recovery of unanswered sparse traffic and
  interrupted UDP path handshakes.

## Endpoint 0.2.16 - 2026-09-10

- Require FIPS core 0.4.81 so prepared crypto buffers reserve space for the
  admitted packet batch, reducing singleton control-traffic allocations.
- Recover routed-session rekey through bounded coordinate rediscovery after
  topology changes clear cached coordinates while the data route still works.
- TCP/FIPS v1 wire bytes and the `nvpn-fips-tcp` 0.2.2 state machine are unchanged.

## TCP 0.2.2 / endpoint 0.2.14 - 2026-09-09

- Recover the rest of a timed-out TCP flight through advancing acknowledgments,
  bounded to one repair per ACK and the existing retry limit. Many small writes
  lost during a transit outage no longer wait for a separate, increasing timeout
  for every missing segment. Rust and TypeScript retain matching behavior.
- Preserve receive-window checks, sequence wrap, RTT sampling, and wire bytes.
  Shared outage vectors and bidirectional Rust/TypeScript checks exercise recovery.
- Require FIPS core 0.4.78 for retained service-route recovery after transit returns
  and quiet operation when no advert relays are configured.

## 0.2.13 - 2026-09-09

- Require FIPS core 0.4.77 so future-dated signed peer ratings cannot prevent
  corrected scores from taking effect. This also retains the UDP receive-error
  backoff introduced in endpoint 0.2.12.
- TCP/FIPS v1 wire bytes and the `nvpn-fips-tcp` 0.2.1 state machine are unchanged.

## 0.2.11 - 2026-09-07

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.75 so reliable
  streams recover when a same-identity recipient restarts while the sender
  retains its previous encrypted session.
- TCP/FIPS v1 wire bytes and the `nvpn-fips-tcp` 0.2.1 state machine are unchanged.

## 0.2.10 - 2026-09-06

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.74 for bounded
  replay bookkeeping, full-width counter checks, and authenticated direct-path updates.
  New data bursts get the existing delivery-feedback window before triggering
  fallback; repeated sends cannot conceal stalled receiver reports.
- Verify the TypeScript adapter against the published `@fips/core` 0.0.42 runtime,
  including authenticated carrier confirmation, FSP delivery reports, and
  session-relative millisecond timestamps.
- TCP/FIPS v1 wire bytes and the `nvpn-fips-tcp` 0.2.1 state machine are unchanged.

## 0.2.9 - 2026-09-04

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.73 so reliable
  streams inherit the routing, transport cleanup, and BLE identity hardening.
- TCP/FIPS v1 wire bytes, runtime behavior, and the dependency-free
  `nvpn-fips-tcp` 0.2.1 state machine are unchanged.

## 0.2.8 - 2026-08-31

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.72 so release
  verification uses the corrected configured-peer cache fixtures.
- TCP/FIPS v1 wire bytes, runtime behavior, and the dependency-free
  `nvpn-fips-tcp` 0.2.1 state machine are unchanged.

## 0.2.7 - 2026-08-31

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.71 so reliable
  FIPS streams reuse validated configured-peer identities during liveness
  recovery.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.6 - 2026-08-31

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.70 so reliable
  FIPS streams retry recovered direct paths promptly across repeated outages.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.5 - 2026-08-31

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.69 so reliable
  FIPS streams retain direct recovery across consecutive outages and stale
  receiver-report feedback.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.4 - 2026-08-28

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.68 so reliable
  FIPS streams share repeated roaming, rekey, and live-rebind recovery fixes.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.3 - 2026-08-28

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.67 so reliable
  FIPS streams retain prompt direct-path recovery across live network rebinds.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.2 - 2026-08-28

- Update `nvpn-fips-tcp-endpoint` to `nvpn-fips-core` 0.4.66 so reliable
  FIPS streams share the app's exact roaming-recovery implementation.
- TCP/FIPS v1 wire bytes and the dependency-free `nvpn-fips-tcp` 0.2.1
  state machine are unchanged.

## 0.2.1 - 2026-08-25

- Publish the Rust crates as `nvpn-fips-tcp` and
  `nvpn-fips-tcp-endpoint`, while preserving the existing `fips_tcp` and
  `fips_tcp_endpoint` Rust import names.
- Target `nvpn-fips-core 0.4.65` from the
  [Nostr VPN FIPS implementation](https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/fips),
  which descends from the
  [original FIPS implementation](https://github.com/jmcorgan/fips).

## 0.2.0 - 2026-07-15

- Harden TCP connection admission, reset validation, retransmission, flow
  control, bounded close lifecycles, and failed-connect rollback.
- Add cumulative payload-acknowledgement markers without changing TCP/FIPS v1
  wire bytes.
- Add bidirectional smoltcp interoperability coverage and matching Rust and
  TypeScript lifecycle tests.
- Let the Rust endpoint adapter advertise a generic same-host FIPS capability
  only after it owns the FSP service port, then withdraw it with the receiver.
  Ordinary binds remain standalone and do not require local rendezvous.
- Require `fips-core 0.4.0` for the fixed-UDP authenticated capability API.

## 0.1.0 - 2026-07-14

- First public Rust TCP/FIPS state-machine and endpoint-adapter releases.
