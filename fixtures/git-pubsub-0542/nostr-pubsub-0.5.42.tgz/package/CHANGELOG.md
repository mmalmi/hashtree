# Changelog

## 0.5.42

Index `MemoryEventStore` by ID, author, kind, and author+kind in block-ordered query storage with inline cached expiration checks, eliminating full-store scans and front-of-array shifts during event admission and cache queries. Share the runtime's bounded complete-body signature verification cache across local cache replays, durable sources, and relay deliveries while still rejecting any tampered row.

Fix NIP-42 `auth-required` live subscriptions failing to re-authenticate after a relay disconnect/reconnect, wait for local cache replay before `settle` completes a read, clamp far-future query deadlines against 32-bit timer overflow, group interleaved relay scopes into minimal batched `REQ`s with debounced teardown, and coalesce queued FIPS-TCP records into bounded writes during peer replay bursts.

## 0.5.41

Combined index and relay reads now deliver relay events to background readers even when another subscription is still writing them. Indexes added at runtime honor their filter support. Exact-ID completion tracks unexpired results across the whole read, and empty background queries release their subscriptions. A corrupt index row marks its source incomplete while valid rows remain available.

Scoped reads reuse their relay URLs throughout delivery. Background writes reuse the verified event, and reads with an explicit empty relay list skip relay batching and its request-size limits.

## 0.5.40

Recognize a matching authenticated peer ID when a FIPS adapter exposes an x-only source. Update the TCP dependency to 0.2.6 for x-only file-transfer and service adapters.

## 0.5.39

Use the authenticated x-only Nostr peer ID from FIPS for subscription admission. Streams and callbacks retain the peer key configured by the application. Older runtimes can supply the same identity through their compressed source key.

## 0.5.38

Fix signed reads over FIPS when WebRTC promotion presents the same authenticated Nostr identity with a different compressed-key encoding. Pubsub uses the configured peer identity for streams, event sources, and revocation.

## 0.5.36

Add `RuntimeSource.durable` for sources whose events already persist elsewhere, such as a local event index. The runtime verifies and delivers their events without admitting them to its store, so they are not stored twice and live relay events do not queue behind their writes.

## 0.5.35

Add read options for apps that combine a slow local store with several sources. `persist: 'background'` delivers verified source and relay events before store admission and reports history without draining unrelated writes; events are still persisted. `settle` ends history after a number of sources finish plus a grace period, or as soon as every requested id arrived, which counts as a complete answer. `onSource` reports each source's completion, and a source can implement `supports(filters)` to skip queries it cannot answer instead of being reported unavailable.

## 0.5.34

Add a runnable relay query to the npm README and move the full TypeScript documentation into a linked guide.

## 0.5.33

Add `NostrRuntime.queryTransientRelay` for bounded, verified queries on one caller-selected relay. It uses the shared connection, returns partial results on timeout, and keeps candidates out of local replay and storage.

## 0.5.32

Preserve independent publication retries when sending the same event to different destinations. Relay history can fall back to a replica after an incomplete response. The SimplePool publisher returns after the first positive acknowledgment. Profile replacement ignores incidental `d` tags, and repeated deliveries use one slot in limited memory queries.

Persistent adapters must round-trip the full pending row, including optional `additionalScopes`. Adapters shared by multiple writers can implement `updatePending` in a storage transaction.

## 0.5.31

Keep paused deliveries pending and continue with enabled rows at the same relay. Only eligible deliveries count toward the automatic send limit or enter broadcast inventory comparisons.

## 0.5.30

Add a durable per-relay outbox API with independent acknowledgements, missing-event comparison and persistent rate-limit deadlines. Expose structured rate-limit replies from the relay transport.


## 0.5.29 - 2026-11-11

- Accept kind 1060 message envelopes that name no recipient. `createPrivateRelayPublisher`, the private pending lane and the anonymous FIPS publisher used to require exactly one `p` tag on kind 1060; they now also send a message with no `p` tag when it has exactly one `["v","2"]` and one non-empty `header` tag, the shape `nostr-double-ratchet` 0.0.184 produces. Messages with one `p` are sent exactly as before, including ones already queued. Kinds 1059 and 21111 are unchanged: exactly one `p`.
- The refusal text is now "Private publisher requires a private encrypted envelope" instead of "…a recipient-specific encrypted event".
- Matching, subscriptions, forwarding and serving are unchanged. A receiver finds a message without a `p` through an `authors` filter on the sender key; `#p` filters keep working for messages that carry the tag.
- A message without a `p` has the same shape as shared group ciphertext, so the private lane no longer quarantines shared group ciphertext that carries a `header`. Header-less kind 1060 records are still quarantined; hosts keep shared group ciphertext out of the queue themselves, as `nostr-double-ratchet` does by event id.
- Remove `createAnonymousRelayDiscovery` and its `AnonymousRelayDiscovery` types. Profile, relay-list, device and invite lookups go through the ordinary runtime, so an author batch uses one connection per relay instead of one per author. Replace `discovery.query`/`discovery.subscribe` with the account runtime's `query`/`subscribe`. `splitRelayDiscoveryFilters` and `isRelayDiscoveryFilter` are unchanged and still scope FIPS endpoints.
- Add `rankRelays`, `relayListEntries` and `normalizeRelayUrl` for ranking the relays that followed authors announce in NIP-65 lists, by popularity or by coverage, above a minimum number of announcing authors. The helpers are pure and add no dependency; nothing connects to a suggested relay unless the application passes it on.

## 0.5.28 - 2026-11-11

- Use `nostr-pubsub-reconcile` 0.1.2, which hashes Negentropy range fingerprints synchronously and deduplicates records without a string key per record. Catch-up over a 100,000-record window builds its snapshot about five times faster and completes five to ten times faster. Frames and the exported API are unchanged.

## 0.5.27 - 2026-11-10

- Restore runtime behavior that the published 0.5.24 package contained but this repository's source did not, and that 0.5.25 and 0.5.26 therefore dropped. `publish` again answers once an event is durably queued while delivery, retries and shutdown continue behind it; pass `queue: false` or `requireAck` to wait for the remote receipt itself. `isolated` subscriptions again deliver per source through their own relay requests, and `observeConnections` again reports peers with an established FIPS service stream.
- Move from 0.5.24 directly to this version; 0.5.25 and 0.5.26 lack the behavior above. It keeps the 0.5.25 private receipt fix and the 0.5.26 performance work.

## 0.5.26 - 2026-11-10

- Keep `MemoryEventStore` in query order as it changes, so admitting or querying an event no longer sorts the whole store. Admission at 15,000 stored events measured about five times faster; results and eviction are unchanged.
- Compute each relay filter key once per connection instead of for every delivered event.
- Skip peer-order encoding and sorting for peers with a single TCP stream, and skip repeated mesh expiry passes within one timestamp.
- Measure each mesh event's encoded size once, and reuse text codecs and a shared allocation-free UTF-8 ordering for filter normalization and peer selection. Wire bytes are unchanged.

## 0.5.23 - 2026-11-04

- Reuse the immutable event size and UTF-8 codecs for repeated peer inventory and event records.
- Pin the compatible Negentropy 0.1.1 library with faster ID comparisons and an optional single-fingerprint opening for repeated feed comparisons.

## 0.5.22 - 2026-11-04

- Keep viewed posts, profiles, and search filters local on browser peer sources. An optional background feed can fetch recent public events globally or in batches from a signed follow list. Explicit publishing retains its peer delivery path.

## 0.5.21 - 2026-10-30

- Add the shared per-source `HistoryCursor`, with bounded inclusive pagination, dense timestamp handling, partial-page retry, and cancellation-safe page tokens. Existing runtime and query behavior is unchanged.

## 0.5.20 - 2026-10-28

- Add bounded, signature-checked event snapshots and atomic IndexedDB persistence for explicitly selected announcement scopes.
- Restore peer discovery from local announcements before network responses, with ordinary local REQ replay, expiry, deterministic replacement, and bounded live writes.
- Keep private discovery caches local; callers select which public events may be replayed.

## 0.5.19 - 2026-10-20

- Restrict every identified receiver EVENT and INV export to explicit public authors. Public profiles, endpoint adverts and future kinds fetched privately cannot escape through broad requests, stale cache or retained exact-ID replay. Preserve full public-gossip and trusted-sibling roles.

## 0.5.18 - 2026-10-20

- Add fresh anonymous FIPS publication operations with provider-bound remote OK receipts and one-subject lookup scopes. Keep identified receivers from exporting private cache or retained replay.
- Recheck peer authorization immediately before queued TCP datagrams leave the endpoint.
- Preserve bounded encrypted owner proofs on invite responses from registered
  devices, while rejecting plaintext, duplicate and misplaced proof tags.
- Isolate targeted profile and relay-list author lookups alongside public device
  and invite discovery, so private peer name hydration cannot reveal a contact.
- Share exact filter partitioning across hosts, splitting mixed public lookup
  kinds and multi-author batches without widening subscription intersections.

## 0.5.17 - 2026-10-20

- Keep durable private queue ownership outside each disposable send operation,
  including hosts which return ordinary local queue acceptance before delivery.
- Add a relay-only `nostr-pubsub/private-relays` entry point so browser bundlers
  can consume privacy transports without loading optional FIPS adapters.

## 0.5.16 - 2026-10-20

- Add an encrypted-event publisher with fresh relay connections and anonymous
  authentication for every event and retry, separate from account reception.
- Add public device and invite discovery isolated by each author or device key;
  reject unscoped or combined identity lookups.
- Keep private sends and public reception in separate durable retry lanes and
  quarantine retired shared group traffic without deleting local records.
- Await required relay authentication before completing query setup, and handle
  canceled anonymous scopes without unhandled authentication rejections.

## 0.5.15 - 2026-10-08

- Update the shared TCP/FIPS transport to 0.2.3 so receiver buffer-space updates
  do not trigger unnecessary retransmission or preserve stale duplicate ACKs.

## 0.5.14 - 2026-10-02

- Add opt-in NIP-77 gap recovery alongside immediate cache reads and ordinary
  live relay requests, using the same socket and verified event admission.
- Bound capability lookup, inventory, missing IDs, frames, rounds, concurrency
  and deadlines; unsupported or failing relays retain ordinary subscriptions.
- Preserve requested historical windows and cancellation without claiming
  all-history sync or uploading local-only events.

## 0.5.13 - 2026-09-30

- Default relay requests to at most 20 exact OR filters so ordinary batches work
  with common relay limits. Larger batches remain an explicit application option.
- Cover rejected over-limit history and explicit larger limits with real socket
  tests; retain exact recipient matching and bounded subscription teardown.

## 0.5.12 - 2026-09-30

- Wait for event admissions queued during earlier cache writes before completing
  history. Queries retain all received events even when relay EOSE arrives while
  the persistent index is busy; cancellation and deadlines remain prompt.

## 0.5.11 - 2026-09-30

- Keep requested peer responses eligible during finite CPU/transport backlogs
  while trying alternate providers. The first valid requested response wins;
  unanswered work expires after ten seconds and remains capacity-bounded.

- Reject unadmitted peer datagrams before TCP allocates connection state, and
  treat a remote half-close released by a concurrent reset as already closed.

- Batch distinct FIPS interests as exact OR filters within the configured peer
  filter and frame bounds. Preserve independent local matching, recent history,
  and cancellation while sharing live/history interests on the same connection.
- Coalesce peer subscription changes across worker tasks and retire empty
  batches immediately. Async source subscription failures propagate to queries
  instead of leaking pending interests or claiming complete history.
- Exercise 512 peer interests and deliveries under a 128-subscription carrier
  cap, including recipient isolation, bounded teardown, frame limits, and aborts.

## 0.5.10 - 2026-09-30

- Enforce explicit relay/source delivery scopes and optional local-echo exclusion
  before event deduplication. Concurrent copies retain their separate source
  evidence while sharing one durable admission.

- Allow explicitly requested network history to return superseded replaceable
  versions without changing the latest-value cache or bypassing deletion and
  expiration checks.

- Report incomplete history when durable event admission fails, including every
  overlapping query sharing the failed write. Relay EOSE cannot hide an index error.

## 0.5.9 - 2026-09-30

- Coalesce relay subscription removals across worker tasks, retiring empty
  batches immediately so closing hundreds of interests does not send hundreds
  of replacement requests. Surviving interests retain exact local matching.

## 0.5.8 - 2026-09-30

- Bound FIPS historical queries by their configured observation window even
  when the caller allows a later overall deadline; empty peer history remains
  explicitly incomplete and does not delay relay-backed app queries.

## 0.5.7 - 2026-09-30

- Add a shared browser/worker Nostr runtime with exact-filter relay batching,
  explicit historical completion, overlapping reconnect recovery, authenticated
  relay support, scoped publication, and truthful remote acknowledgments.
- Add an application-owned persistent event store/outbox contract with
  replacement, expiration, and authorized deletion handling.
- Coalesce concurrent peer connection attempts and share matching live/history
  interests so application startup does not exhaust TCP or peer subscription bounds.
- Serve bounded retained local event history over the existing FIPS node,
  alongside other services such as Hashtree file sharing.
- Exercise 1,200 live interests over real relay sockets without widening
  recipient filters or duplicating matching deliveries.

## 0.5.6 - 2026-08-19

- Treat an authenticated TCP/FIPS stream that closes between a cleanup state
  check and its queued abort as already released, while preserving abort
  failures for connections that remain retained. This removes spurious
  `unknown connection` errors during simultaneous pubsub stream convergence.

## 0.5.5 - 2026-07-26

- Add an opaque exact-object verification boundary for shared
  `SimplePool` transports, allowing one injected synchronous verifier such as
  `nostr-wasm` to provide canonical admission without a duplicate Schnorr pass
  or trust in a spoofable public verification marker.

## 0.5.4 - 2026-07-26

- Reuse private canonical verification admission across adjacent protocol
  layers, avoiding duplicate Schnorr verification while rejecting spoofed
  public verification markers.

## 0.5.3 - 2026-07-26

- Add cancellable asynchronous batch verification admission for immutable
  events checked by an external or worker trust boundary, preserving the
  canonical verified-event fast path without repeating Schnorr verification.

## 0.5.2 - 2026-07-18

- Add the shared `SimplePoolNostrRelayTransport` browser relay carrier with
  boundary verification, bounded historical query completion, live
  subscriptions, and at-least-one-relay publication success.

## 0.5.1 - 2026-07-18

- Preserve a negative backend priority in the owned router when a relay is the
  only successful publish route instead of incorrectly flooring it at zero.

## 0.5.0 - 2026-07-18

- Replace the raw-datagram FIPS relay bridge with the reliable FIPS-TCP
  `nostr.pubsub/1` client on port 7368; `localPeerId` is now required for
  deterministic simultaneous-stream ownership.
- Use compatible grouped `INV`, one-event `WANT`, and ordinary addressed
  `EVENT` for both bounded historical replay and new live events, with global
  event-ID deduplication and alternate-provider retry.
- Add matching historical and live routers for Hashtree/local indexes, FIPS
  peers, and traditional Nostr relays; remove the legacy route `bus` alias and
  obsolete `FipsNostrRelayService` API.
- Add the owned `NostrPubsubRouter` for applications that need one reusable
  query/publish/live provider rather than one-shot route helper calls.
- Add shared Rust-process wire vectors and real FIPS-TCP coverage for all five
  `REQ`/`INV`/`WANT`/`EVENT`/`CLOSE` messages.

## 0.4.0 - 2026-07-18

- Split the read-only `NostrEventReader` and write-only `NostrEventPublisher`
  contracts while preserving the combined `EventBus` API and routed `bus` alias.
- Give source routes explicit dataset identities: replicas fail over within one
  dataset, while additive datasets are queried concurrently and merged.
- Deduplicate verified events with complete provenance, deterministic ordering,
  one global result limit, isolated source failures, and per-route/per-dataset
  outcome reporting.
- Propagate cancellation and one absolute deadline through routed and in-memory
  queries without activating any relay or changing publication policy.
- Honor NIP-01 OR semantics by applying each filter's limit independently and
  reserving `QueryOptions.limit` for the router-wide result cap.

## 0.3.1 - 2026-07-16

- Retry a local subscription's `REQ` after an initially unavailable FIPS route
  later reconnects, while keeping replay delivery valid during the pending send.
- Close a late successful `REQ` when its local subscription or peer admission was
  removed before the send completed.

## 0.3.0 - 2026-07-16

- Add `FipsNostrPubsubClient`, the shared browser `nostr.pubsub/1`
  `REQ`/`EVENT`/`CLOSE` carrier for signed Nostr events.
- Keep peer admission application-owned and explicit; connected peers are never
  inferred, and subscriptions refresh when admitted standalone links reconnect.
- Bound replay, subscriptions, filters, peers, frames, and pending work; failed
  publications remain retryable and invalid or non-admitted traffic is dropped.
- Match the native FSP datagram maximum exactly: accept 65,525 bytes and reject
  65,526, with a real Rust process roundtrip gate.
- Include TypeScript sources referenced by the published declaration and source
  maps so clean-installed artifacts are self-contained.

## 0.2.0 - 2026-07-16

- Add the bounded `FipsInvWantStream` and `FipsInvWantTcpDriver` over the
  shared TCP/FIPS v1 stack.
- Cover partial and coalesced records, queue and peer bounds, close/reset
  lifecycle, reconnects, and real Rust-to-TypeScript process interoperability.
- Match Rust simultaneous-connect ordering by normalizing compressed and
  x-only transport identities to their canonical npub ordering key.
- Keep authenticated capability discovery explicit; no fallback provider
  namespace or unauthenticated peer inference is introduced.

## 0.1.5 - 2026-07-13

- Add the authenticated FIPS Nostr relay adapter and shared Rust/TypeScript
  interoperability vectors.
