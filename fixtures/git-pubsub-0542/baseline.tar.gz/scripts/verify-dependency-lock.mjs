import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const manifest = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
const lockfile = await readFile(new URL('pnpm-lock.yaml', root), 'utf8');

// Hashtree v0.5.27 source 9eb201a26dd6a0a914f9a480b6a33621ca9e635e
// SHA256SUMS digest 5f1c177f3cf7f0aebe8ba6eb42a4932242b1ca8fc13cf2f98a8fc67a200c877e
// Hashtree v0.5.42 (core) source 42ab7c8bae8a94823e286addfa9d5ca1e8332053
// SHA256SUMS digest 9ed3352632e459c424ac334abb3b2ed9a568c6b85366a7f7a6d67f3428181563
// Hashtree v0.5.46 (dexie) source 82e2ecc057e01ea9fb1614c918b47780502bb7a6
// Hashtree v0.5.50 (worker/pubsub) source 53eb24ab06b195d45c97a051c9cb1725ac07235a
// Hashtree v0.5.40 (nostr) source 1d67d07b3f2fd38038f3c9340ab5e1462b5961d0
const releases = {
  "@fips/browser": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-browser-0.0.23.tgz",
    "sha512-FFcSEhlFbRs8Msg8b8e4S0u2ZTdyXVkiIZeD+fuq1wUpTqt0ONCUqLvfvvx9hQyPwHdlzAsjWxfRUYA4CQ5FAQ=="
  ],
  "@fips/core": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-core-0.0.58.tgz",
    "sha512-UW0PHboZgifo806XxYYjNGgPsKYDMA59YQSvFD0j1k5lhAofX1Yfx+kH38mTYWeTNJQKSr7cMaWqM1Ue2pSV8g=="
  ],
  "@fips/tcp": [
    "https://github.com/mmalmi/fips-tcp/releases/download/fips-tcp-ts-v0.2.6/fips-tcp-0.2.6.tgz",
    "sha512-lXQHNwTZEyXGYWqzRlNyKpb2UgNWJOon6HljbY1F1Ey49Q9IoE/kdF84gaTkrCpMPS8M/A6y5FTaFPOLl60+bw=="
  ],
  "@fips/transport-webrtc": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-transport-webrtc-0.0.62.tgz",
    "sha512-X4fGxJvosbK62DqW9Zp8mkzMmmH8grVMxKSbtsqgWRCHNIP1nBKQdvmjeYjVG3/KTTVTZXETRQFLSM9ZS2WW7A=="
  ],
  "@fips/transport-websocket": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-transport-websocket-0.0.16.tgz",
    "sha512-2KUDBS9/UQ+g+vguCf5hSZBShFGZW9ffXCYXx8jQI9yL9Q8rj8mxd+bnOrv5qAVG8ymbqErI2oVCkyLkpT9cvw=="
  ],
  "@hashtree/collection": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-collection-0.2.11.tgz",
    "sha512-FI6cVBneXSgOEAEeZH6Yv12eC+pZpG2kTCHc9Bt4+bW6Vu0nVNo5V3Gtt5Dk9p8l7G47sq/R9CBbo6A0D+dVwA=="
  ],
  "@hashtree/core": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.42/hashtree-core-0.4.2.tgz",
    "sha512-9gPIe39QJoCUtVo8VhbDOX5bHAtGlJ2EZlQJqKh3l9++2CY1Njg2LINXQWBgKRqB0P2LBKoDpyYz1XIBoJ/SMw=="
  ],
  "@hashtree/dexie": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.46/hashtree-dexie-0.1.15.tgz",
    "sha512-YPn2gh0QQQRMcZY3zYmkycLqBjKJhA8GEmWq2/LPSbD0441YEQPCkWvTfAgRUsXA+gvjxB51tvqev1caXylp8A=="
  ],
  "@hashtree/fips-transport": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.52/hashtree-fips-transport-0.5.3.tgz",
    "sha512-aCyAsJwA6uIePNYa7JJtkv/75xcFG/M11LB2llNAiS1qLOz1v3c681XkfHBRmeUqGWoBwyJMBHXmjvQB+vq/Mw=="
  ],
  "@hashtree/git": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-git-0.1.10.tgz",
    "sha512-fhSXJCF6h6iG9d3PYFehptTDAYda8fCgfy/DhunKiRzj8UAsDa1LufFOf4l+EC4QdsBXi3btr+U6F1SNRIK4cA=="
  ],
  "@hashtree/index": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-index-0.1.15.tgz",
    "sha512-EnXs4hE0fxCzQfruEsjO9YVBTpzb3Rr1k1vF6p7gLgpZ2oIEg4DEv/pZji9uj7/qJYqOa+EsZTjA0lT0SZozdA=="
  ],
  "@hashtree/mesh": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-mesh-0.3.3.tgz",
    "sha512-fiLvKjbEO1J/fuj6wcLGjI3RPsPrGgSuc2O+QqN/vX3OSHI7uPS+feH49vFduUMHYM79Yvsrq6MV2XDUiGq59A=="
  ],
  "@hashtree/nostr": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.40/hashtree-nostr-0.2.7.tgz",
    "sha512-ah0pS1PDckTkz/QntsNn9D9aFPcJWb7BDjBvaVtY9gaWryiWMvXv0QaGbTU5aGIqRd32BLmnojNDXHPJ/IkIhQ=="
  ],
  // Worker 0.4.31 preserves relay caching and adds optional verified graph bootstrap.
  "@hashtree/worker": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.51/hashtree-worker-0.4.32.tgz",
    "sha512-AEhXXwW93xzYxPiHjNWJVBgaVjAkz5YWrf8Yl+H5aIw0Faem5Jm+1RLz62JcBCUTabwx67RekWvzcR8ZTzQAKA=="
  ],
  // Iris Kit runtime-v0.2.19 hashtree-app source 03a894d0ad476bf5b5b0fa5013b1f369c5f04398
  "@iris/hashtree-app": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.19/iris-hashtree-app-0.1.13.tgz",
    "sha512-YLHBiSlUh1PpcXJQrQNo+6p2vRT6INIwTUTaYqc4h3WvhtNq/Blj9vT91dCxk/XHKNxcgnKKTqgEXE56GVgyeQ=="
  ],
  "@iris/release-tools": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.12/iris-release-tools-0.1.2.tgz",
    "sha512-ZytyQLbDUYz/IcQ2rvUZZeFvT7FqwhRB3brZtuMwH7ILP/Jvui+ldDnKR8dNxxmIr02+PPyuv+VWKlRyaXCMbg=="
  ],
  "@iris/profile-events": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.15/iris-profile-events-0.2.0.tgz",
    "sha512-B6groCtJFzoSCQ66ovQhDkAHcSWtN/JBNyojYmxUOGm6wgi3p1oLZ5btbGby/qzMsBFLOh9uIJ4kJBVVuxHKeQ=="
  ],
  // Iris Kit runtime-v0.2.18 svelte-ui source cd78e25
  "@iris/svelte-ui": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.18/iris-svelte-ui-0.1.7.tgz",
    "sha512-ucMoZ+SyxpOosGQvAUXuPbhkXhjHjQhPr5qOh85MjdALFITAicYXKT0vN6ZdngINrNQxWjSks42Ek1xcq2ZOUA=="
  ],
  "nostr-social-graph": [
    "https://github.com/mmalmi/nostr-social-graph/releases/download/v4.2.5/nostr-social-graph-4.2.5.tgz",
    "sha512-SbIf1758zSgdkOWWuxNrHmphzfEn5Y4kbD2LPkBI/sl4CrEifpzfXjNt621YD9FRElk+HTt7+HBk7Ht2HU1iyA=="
  ],
  "@hashtree/nostr-pubsub": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.50/hashtree-nostr-pubsub-0.1.10.tgz",
    "sha512-rRVrnrgSCtMLx60hLTBxGp4cz6GOnKkPp6QIvEKZ97F5CWWJK5fry5sGB/2VuHffTKD/IQ31cggZK5WOvm/FCQ=="
  ],
  "@iris/identity": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.9/iris-identity-0.4.0.tgz",
    "sha512-ZZ7qRjOXl+7fLqsSrWEn9eOysrsbXDsHQz6uxZZw+4wnw3qZXi3xHVdWAia7ykTmFm3euDjNHA+raG33xjacWg=="
  ],
  "nostr-pubsub": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.41/nostr-pubsub-0.5.41.tgz",
    "sha512-nNBicaF8OX/theZABn59InRqdFwOQd7skySfJrwcdONOmXzeXH/S88qkv4i9oWnx0jASqmtv91O5eh+LVX1dwg=="
  ],
  "nostr-pubsub-reconcile": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-reconcile-ts-v0.1.2/nostr-pubsub-reconcile-0.1.2.tgz",
    "sha512-w2N8AE2bL5h7H0tOuTONOTprHS4/SVCP93lyipA/mekk+RogF3fZFh+s2lxLEDvW5tSjIJcBdX1lguX7wD5+2g=="
  ]
};

const declared = { ...manifest.dependencies, ...manifest.devDependencies };
for (const [name, specifier] of Object.entries(declared)) {
  const verifiedArchive = name === '@iris/svelte-ui' && specifier === releases[name][0];
  if (/^(?:file|link|workspace):/.test(specifier) && !verifiedArchive) {
    throw new Error(`${name} must not depend on a mutable workspace`);
  }
}
if (/\b(?:file|link):\.\.\//.test(lockfile)) {
  throw new Error('Lockfile must not resolve mutable sibling workspaces');
}
// Published runtime archives name plain registry versions of each other. An override
// must point a runtime package at its verified archive so every copy stays on it.
const scopedReleaseOverrides = {
  "@hashtree/nostr-pubsub>nostr-pubsub": releases["nostr-pubsub"][0],
  "@hashtree/worker>nostr-pubsub": releases["nostr-pubsub"][0],
  "@hashtree/fips-transport>nostr-pubsub": releases["nostr-pubsub"][0]
};
for (const [name, specifier] of Object.entries(manifest.pnpm?.overrides ?? {})) {
  const verified = releases[name]?.[0] === specifier || scopedReleaseOverrides[name] === specifier;
  if ((name.startsWith('@fips/') || name.startsWith('@hashtree/')) && !verified) {
    throw new Error(`${name} override bypasses the immutable release graph`);
  }
}

for (const [name, [url]] of Object.entries(releases)) {
  if (name in declared && declared[name] !== url) {
    throw new Error(`${name} must use immutable release ${url}`);
  }
}

const expected = Object.entries(releases)
  .map(([name, [url, integrity]]) => [name, url, integrity]);

for (const [name, url, integrity] of expected) {
  if (url.startsWith('file:')) {
    const archive = await readFile(new URL(url.slice(5), root));
    const actualIntegrity = `sha512-${createHash('sha512').update(archive).digest('base64')}`;
    if (actualIntegrity !== integrity) throw new Error(`${name} archive differs from its verified Iris Kit commit`);
  }
  const quotedKey = `  '${name}@${url}':`;
  const plainKey = `  ${name}@${url}:`;
  const start = Math.max(lockfile.indexOf(quotedKey), lockfile.indexOf(plainKey));
  const end = lockfile.indexOf('\n\n', start);
  const entry = start >= 0 ? lockfile.slice(start, end < 0 ? undefined : end) : '';
  if (!entry.includes(`tarball: ${url}`) || !entry.includes(`integrity: ${integrity}`)) {
    throw new Error(`${name} lock entry is missing its verified release integrity`);
  }
  if (name === '@fips/transport-webrtc') {
    const version = entry.match(/^    version: (\S+)$/m)?.[1];
    const selector = `${name}@${version}`;
    const workspace = await readFile(new URL('pnpm-workspace.yaml', root), 'utf8');
    const hash = lockfile.split(`\n  '${selector}':\n    hash: `)[1]?.split('\n')[0];
    if (!workspace.includes(`\n  '${selector}': patches/fips-transport-webrtc-bounded-replay.patch\n`) ||
        !hash || !lockfile.includes(`\n  '${name}@${url}(patch_hash=${hash})':\n`)) {
      throw new Error('WebRTC discovery must use the bounded advert replay patch for its installed version');
    }
  }
}

for (const script of ['build:git', 'test:unit', 'test:e2e:git']) {
  if (!manifest.scripts?.[script]?.startsWith('pnpm run verify:dependency-lock')) {
    throw new Error(`${script} must verify immutable dependency integrity first`);
  }
}

// Reject a second, unverified copy of a runtime package, including registry versions.
const verifiedPackages = new Set(expected.map(([name, url]) => `${name}@${url}`));
const packageSection = lockfile.split('\npackages:\n')[1].split('\nsnapshots:\n')[0];
for (const [, key] of packageSection.matchAll(/^  '?([^'\n]+?)'?:$/gm)) {
  if (/^(?:@(?:hashtree|fips|iris)\/|nostr-(?:pubsub(?:-reconcile)?|social-graph)@)/.test(key) && !verifiedPackages.has(key)) {
    throw new Error(`Unverified runtime package in lockfile: ${key}`);
  }
}

console.log('Verified immutable Iris Git runtime release integrity');
