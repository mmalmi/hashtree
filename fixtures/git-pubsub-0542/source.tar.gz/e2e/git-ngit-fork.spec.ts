import { test, expect, type Page } from './fixtures';
import type { BrowserContext } from '@playwright/test';
import { finalizeEvent, getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  ensureLoggedIn,
  flushPendingPublishes,
  gotoGitApp,
  setupPageErrorHandler,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';

const AUTHOR_SECRET_KEY = Uint8Array.from({ length: 32 }, (_, index) => index + 41);
const AUTHOR_PUBKEY = getPublicKey(AUTHOR_SECRET_KEY);
const AUTHOR_NPUB = nip19.npubEncode(AUTHOR_PUBKEY);
const GRASP_HOST = 'grasp-fork.e2e.test';
const GRASP_CORS = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*' };

function createdAt() {
  return Math.floor(Date.now() / 1000) + 2;
}

async function publishEvent(relayUrl: string, event: ReturnType<typeof finalizeEvent>): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const ws = new WebSocket(relayUrl);
    const timeout = setTimeout(() => {
      ws.close();
      reject(new Error(`Timed out publishing event ${event.id}`));
    }, 10000);
    ws.on('open', () => ws.send(JSON.stringify(['EVENT', event])));
    ws.on('message', (data) => {
      const parsed = JSON.parse(data.toString());
      if (parsed[0] === 'OK' && parsed[1] === event.id) {
        clearTimeout(timeout);
        ws.close();
        if (parsed[2] === true) resolve();
        else reject(new Error(parsed[3] || `Relay rejected event ${event.id}`));
      }
    });
    ws.on('error', (err) => { clearTimeout(timeout); reject(err); });
  });
}

function createGraspFixture(repoName: string) {
  const work = mkdtempSync(join(tmpdir(), 'iris-git-ngit-fork-e2e-'));
  const repo = join(work, 'repo');
  const git = (...args: string[]) => execFileSync(
    'git',
    ['-c', 'commit.gpgsign=false', '-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.com', ...args],
    { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
  ).trim();

  execFileSync('git', ['init', '-q', '-b', 'main', repo]);
  git('config', 'uploadpack.allowFilter', 'true');
  git('config', 'uploadpack.allowAnySHA1InWant', 'true');
  mkdirSync(join(repo, 'src'), { recursive: true });

  writeFileSync(join(repo, 'README.md'), '# Grasp Fork Fixture\n\nVersion 1.\n');
  writeFileSync(join(repo, 'src/app.ts'), 'export const version = 1;\n');
  git('add', '-A');
  git('commit', '-qm', 'Initial grasp commit');
  const firstCommit = git('rev-parse', 'HEAD');

  writeFileSync(join(repo, 'README.md'), '# Grasp Fork Fixture\n\nVersion 2.\n');
  writeFileSync(join(repo, 'src/app.ts'), 'export const version = 2;\n');
  git('add', '-A');
  git('commit', '-qm', 'Second grasp commit');
  const secondCommit = git('rev-parse', 'HEAD');
  git('tag', '-a', 'v1.0.0', '-m', 'Release v1.0.0');

  git('checkout', '-qb', 'feature/extra');
  writeFileSync(join(repo, 'src/feature.ts'), 'export const extra = true;\n');
  git('add', 'src/feature.ts');
  git('commit', '-qm', 'Feature branch commit');
  git('checkout', '-q', 'main');

  return {
    repo,
    firstCommit,
    secondCommit,
    cloneUrl: `https://${GRASP_HOST}/${AUTHOR_NPUB}/${repoName}.git`,
    remove: () => rmSync(work, { recursive: true, force: true }),
  };
}

async function routeGraspServer(
  context: BrowserContext,
  repoDir: string,
  options: { isOffline?: () => boolean; rejectFullFetchAsTooLarge?: () => boolean } = {},
) {
  await context.route(`https://${GRASP_HOST}/**`, (route) => {
    const request = route.request();
    if (request.method() === 'OPTIONS') {
      return route.fulfill({ status: 204, headers: GRASP_CORS });
    }
    if (options.isOffline?.()) {
      return route.fulfill({ status: 503, headers: GRASP_CORS, body: 'server offline' });
    }
    const body = request.postDataBuffer() ?? Buffer.alloc(0);
    const bodyText = body.toString('utf8');
    if (
      options.rejectFullFetchAsTooLarge?.() &&
      bodyText.includes('command=fetch') &&
      !bodyText.includes('deepen ')
    ) {
      return route.fulfill({
        status: 200,
        headers: {
          ...GRASP_CORS,
          'content-type': 'application/x-git-upload-pack-result',
          'content-length': String(80 * 1024 * 1024),
        },
        body: Buffer.alloc(0),
      });
    }
    const output = execFileSync('git', ['upload-pack', '--stateless-rpc', repoDir], {
      input: body,
      env: { ...process.env, GIT_PROTOCOL: 'version=2' },
      maxBuffer: 64 * 1024 * 1024,
    });
    return route.fulfill({
      status: 200,
      headers: { ...GRASP_CORS, 'content-type': 'application/x-git-upload-pack-result' },
      body: output,
    });
  });
}

async function prepareUser(page: Page, relayUrl: string) {
  setupPageErrorHandler(page);
  await gotoGitApp(page);
  await waitForAppReady(page);
  await useLocalRelay(page, relayUrl);
  await ensureLoggedIn(page);
  await waitForRelayConnected(page);
}

async function getLoggedInNpub(page: Page): Promise<string> {
  const npub = await page.evaluate(() => (
    (window as { __nostrStore?: { getState?: () => { npub?: string | null } } }).__nostrStore?.getState?.().npub ?? null
  ));
  if (!npub) throw new Error('Missing logged-in npub');
  return npub;
}

test.describe('Forking ngit repositories to Hashtree', () => {
  test('forks an ngit repo with full history, branches, tags, and provenance to Hashtree', async ({ browser, relayUrl }, testInfo) => {
    test.setTimeout(120_000);
    const repoName = `ngit-fork-src-${Date.now()}`;
    const forkName = `ngit-fork-copy-${Date.now()}`;
    const fixture = createGraspFixture(repoName);

    await publishEvent(relayUrl, finalizeEvent({
      kind: 30617,
      created_at: createdAt(),
      tags: [
        ['d', repoName],
        ['name', repoName],
        ['clone', fixture.cloneUrl],
        ['r', fixture.firstCommit, 'euc'],
      ],
      content: '',
    }, AUTHOR_SECRET_KEY));

    let graspOffline = false;
    const context = await browser.newContext();
    await routeGraspServer(context, fixture.repo, { isOffline: () => graspOffline });

    try {
      const page = await context.newPage();
      await prepareUser(page, relayUrl);
      const viewerNpub = await getLoggedInNpub(page);

      await page.goto(`/git.html#/${AUTHOR_NPUB}/${repoName}`);
      const notice = page.getByTestId('ngit-repo-notice');
      await expect(notice).toHaveAttribute('data-status', 'ready', { timeout: 30000 });
      await expect(page.getByText('Version 2.')).toBeAttached({ timeout: 30000 });

      const forkBtn = page.getByTestId('fork-folder-btn');
      await expect(forkBtn).toBeVisible({ timeout: 15000 });
      await forkBtn.click();

      const forkModal = page.locator('.fixed.inset-0').filter({ hasText: 'Fork to Hashtree' });
      await expect(forkModal).toBeVisible({ timeout: 10000 });
      await page.screenshot({ path: testInfo.outputPath('ngit-fork-modal.png') });
      await forkModal.locator('input').fill(forkName);
      await forkModal.getByRole('button', { name: /^Fork$/ }).click();

      await page.waitForURL(new RegExp(`#/${viewerNpub}/${encodeURIComponent(forkName)}(?:\\?|$)`), { timeout: 60000 });
      await expect(forkModal).not.toBeVisible({ timeout: 15000 });
      await flushPendingPublishes(page);

      // Cut off the original Grasp server completely to prove the Hashtree fork is 100% self-contained.
      graspOffline = true;

      await expect(page.getByTestId('ngit-repo-notice')).toHaveCount(0);
      await expect(page.getByTestId('blossom-push-btn')).toBeAttached({ timeout: 15000 });
      await expect(page.getByText('Version 2.')).toBeAttached({ timeout: 30000 });

      // Verify full history, branches, tags, and oldest commit blob are readable offline from Hashtree.
      const gitState = await page.evaluate(async ({ firstCommit }) => {
        const { useCurrentDirCid } = await import('/src/stores/index.ts');
        const { getLog, getRefs, getFileAtCommit } = await import('/src/utils/git.ts');
        const cid = useCurrentDirCid();
        if (!cid) return null;
        const [log, refs, oldReadme] = await Promise.all([
          getLog(cid, { depth: 10 }),
          getRefs(cid),
          getFileAtCommit(cid, 'README.md', firstCommit),
        ]);
        return {
          encrypted: !!cid.key,
          commits: log.map((c) => c.oid),
          branches: refs.branches,
          tags: refs.tags,
          oldReadme: oldReadme ? new TextDecoder().decode(oldReadme) : null,
        };
      }, { firstCommit: fixture.firstCommit });

      expect(gitState?.encrypted).toBe(true);
      expect(gitState?.commits).toEqual([fixture.secondCommit, fixture.firstCommit]);
      expect(gitState?.branches).toEqual(['feature/extra', 'main']);
      expect(gitState?.tags).toEqual(['v1.0.0']);
      expect(gitState?.oldReadme).toContain('Version 1.');

      // Verify sidebar "Forked from" links back to the original ngit repo route.
      const originLink = page.getByTestId('repo-project-sidebar').getByRole('link', { name: /^Forked from / });
      await expect(originLink).toContainText(repoName, { timeout: 30000 });
      await expect(originLink).toHaveAttribute('href', `#/${AUTHOR_NPUB}/${repoName}`);

      // Verify NIP-34 repo announcement carries htree:// clone, EUC, personal-fork, and nostr:// forked-from.
      const announcement = await page.evaluate(async ({ ownerNpub, name }) => {
        const { watchRepoAnnouncement } = await import('/src/nip34.ts');
        return new Promise<{
          cloneUrls: string[];
          earliestUniqueCommit: string | null;
          forkedFrom: string | null;
          isPersonalFork: boolean;
        } | null>((resolve) => {
          let latest: {
            cloneUrls: string[];
            earliestUniqueCommit: string | null;
            forkedFrom: string | null;
            isPersonalFork: boolean;
          } | null = null;
          const stop = watchRepoAnnouncement(ownerNpub, name, (next) => { latest = next; });
          setTimeout(() => { stop(); resolve(latest); }, 1500);
        });
      }, { ownerNpub: viewerNpub, name: forkName });

      expect(announcement?.isPersonalFork).toBe(true);
      expect(announcement?.earliestUniqueCommit).toBe(fixture.firstCommit);
      expect(announcement?.forkedFrom).toBe(`nostr://${AUTHOR_NPUB}/${repoName}`);
      expect(announcement?.cloneUrls).toContain(`htree://${viewerNpub}/${forkName}`);

      await page.screenshot({ path: testInfo.outputPath('ngit-forked-hashtree-repo.png') });
    } finally {
      await context.close();
      fixture.remove();
    }
  });

  test('offers a shallow snapshot fallback when full history exceeds the browser limit', async ({ browser, relayUrl }, testInfo) => {
    test.setTimeout(120_000);
    const repoName = `ngit-large-src-${Date.now()}`;
    const forkName = `ngit-large-copy-${Date.now()}`;
    const fixture = createGraspFixture(repoName);

    await publishEvent(relayUrl, finalizeEvent({
      kind: 30617,
      created_at: createdAt(),
      tags: [
        ['d', repoName],
        ['name', repoName],
        ['clone', fixture.cloneUrl],
        ['r', fixture.firstCommit, 'euc'],
      ],
      content: '',
    }, AUTHOR_SECRET_KEY));

    let graspOffline = false;
    const context = await browser.newContext();
    await routeGraspServer(context, fixture.repo, {
      isOffline: () => graspOffline,
      rejectFullFetchAsTooLarge: () => true,
    });

    try {
      const page = await context.newPage();
      await prepareUser(page, relayUrl);
      const viewerNpub = await getLoggedInNpub(page);

      await page.goto(`/git.html#/${AUTHOR_NPUB}/${repoName}`);
      await expect(page.getByTestId('ngit-repo-notice')).toHaveAttribute('data-status', 'ready', { timeout: 30000 });

      await page.getByTestId('fork-folder-btn').click();
      const forkModal = page.locator('.fixed.inset-0').filter({ hasText: 'Fork to Hashtree' });
      await expect(forkModal).toBeVisible({ timeout: 10000 });
      await page.screenshot({ path: testInfo.outputPath('ngit-fork-modal.png') });
      await forkModal.locator('input').fill(forkName);
      await forkModal.getByRole('button', { name: /^Fork$/ }).click();

      // Full fetch fails with size limit -> inline shallow snapshot fallback appears.
      const shallowBtn = forkModal.getByTestId('fork-shallow-btn');
      await expect(shallowBtn).toBeVisible({ timeout: 30000 });
      await page.screenshot({ path: testInfo.outputPath('ngit-fork-shallow-fallback.png') });
      await shallowBtn.click();

      await page.waitForURL(new RegExp(`#/${viewerNpub}/${encodeURIComponent(forkName)}(?:\\?|$)`), { timeout: 60000 });
      await expect(forkModal).not.toBeVisible({ timeout: 15000 });

      graspOffline = true;
      await expect(page.getByText('Version 2.')).toBeAttached({ timeout: 30000 });

      const log = await page.evaluate(async () => {
        const { useCurrentDirCid } = await import('/src/stores/index.ts');
        const { getLog } = await import('/src/utils/git.ts');
        const cid = useCurrentDirCid();
        return cid ? (await getLog(cid, { depth: 10 })).map((c) => c.oid) : [];
      });
      expect(log).toEqual([fixture.secondCommit]);
    } finally {
      await context.close();
      fixture.remove();
    }
  });
});
