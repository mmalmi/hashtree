<script lang="ts" module>
  /**
   * Modal for forking a directory as a new tree
   */
  import type { CID } from '@hashtree/core';

  export interface ForkTarget {
    dirCid: CID;
    suggestedName: string;
    isExternalNgit?: boolean;
  }

  let show = $state(false);
  let forkTarget = $state<ForkTarget | null>(null);
  let modalInput = $state('');

  export function open(dirCid: CID, suggestedName: string, options?: { isExternalNgit?: boolean }) {
    forkTarget = { dirCid, suggestedName, isExternalNgit: options?.isExternalNgit };
    modalInput = suggestedName;
    show = true;
  }

  export function close() {
    show = false;
    forkTarget = null;
    modalInput = '';
  }
</script>

<script lang="ts">
  import type { TreeVisibility } from '@hashtree/core';
  import { forkTree } from '../../actions/tree';
  import { nostrStore } from '../../nostr';
  import VisibilityPicker from '@iris/hashtree-app/VisibilityPicker.svelte';

  let isForking = $state(false);
  let statusText = $state('Forking...');
  let error = $state('');
  let canFallbackShallow = $state(false);
  let abortController: AbortController | null = null;
  let inputRef: HTMLInputElement | undefined = $state();
  let visibility = $state<TreeVisibility>('public');
  let isLoggedIn = $derived(!!$nostrStore.npub);
  let isExternalNgit = $derived(!!forkTarget?.isExternalNgit);

  // Reset modal state when opened or closed
  $effect(() => {
    if (show) {
      visibility = 'public';
      error = '';
      canFallbackShallow = false;
      statusText = 'Forking...';
    } else {
      abortController?.abort();
      abortController = null;
    }
  });

  // Focus input when modal opens
  $effect(() => {
    if (show && inputRef) {
      inputRef.focus();
      inputRef.select();
    }
  });

  async function handleFork(ngitMode: 'full' | 'shallow' = 'full') {
    if (!forkTarget || !modalInput.trim()) return;

    const name = modalInput.trim();
    if (!name) {
      error = 'Name is required';
      return;
    }

    if (!isLoggedIn) {
      error = 'Please sign in to fork repositories.';
      return;
    }

    abortController?.abort();
    const controller = new AbortController();
    abortController = controller;
    isForking = true;
    error = '';
    canFallbackShallow = false;
    statusText = isExternalNgit
      ? (ngitMode === 'shallow' ? 'Fetching latest snapshot...' : 'Fetching Git history...')
      : 'Forking...';

    try {
      const result = await forkTree(forkTarget.dirCid, name, visibility, {
        ngitMode,
        signal: controller.signal,
        onProgress: (status) => { statusText = status; },
      });
      if (controller.signal.aborted) return;
      if (result.success) {
        close();
      } else {
        canFallbackShallow = !!result.tooLarge && ngitMode === 'full';
        error = result.error || 'Failed to create fork. Please try again.';
      }
    } catch (e) {
      if (controller.signal.aborted) return;
      console.error('Fork error:', e);
      error = e instanceof Error ? e.message : 'Failed to create fork';
    } finally {
      if (abortController === controller) {
        abortController = null;
        isForking = false;
      }
    }
  }

  function handleKeyDown(e: KeyboardEvent) {
    if (e.key === 'Enter' && !isForking) {
      e.preventDefault();
      handleFork();
    }
  }
</script>

{#if show && forkTarget}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onclick={close}>
    <div class="bg-surface-1 rounded-lg shadow-lg p-6 w-full max-w-md mx-4" onclick={(e) => e.stopPropagation()}>
      <h2 class="text-lg font-semibold mb-2">{isExternalNgit ? 'Fork to Hashtree' : 'Fork as New Folder'}</h2>
      <p class="text-text-2 text-sm mb-4">
        {#if isExternalNgit}
          Create an editable Hashtree copy of this repository with its Git history.
        {:else}
          Create a new top-level folder with a copy of this directory's contents.
        {/if}
      </p>

      <div class="mb-4">
        <label for="fork-name" class="block text-sm font-medium text-text-2 mb-1">
          {isExternalNgit ? 'Repository name' : 'Folder name'}
        </label>
        <input
          bind:this={inputRef}
          id="fork-name"
          type="text"
          bind:value={modalInput}
          onkeydown={handleKeyDown}
          placeholder={isExternalNgit ? 'Enter repository name...' : 'Enter folder name...'}
          class="w-full px-3 py-2 bg-surface-2 border border-surface-3 rounded text-text-1 placeholder:text-text-3 focus:outline-none focus:border-accent"
          disabled={isForking}
        />
      </div>

      <div class="mb-4">
        <VisibilityPicker value={visibility} onchange={(v) => visibility = v} />
      </div>

      {#if !isLoggedIn}
        <p class="text-text-3 text-sm mb-4">Sign in to fork repositories.</p>
      {/if}

      {#if error}
        <div class="text-danger text-sm mb-4 space-y-2">
          <p class="m-0">{error}</p>
          {#if canFallbackShallow}
            <button
              type="button"
              onclick={() => handleFork('shallow')}
              class="btn-ghost px-3 py-1.5 text-sm text-accent"
              data-testid="fork-shallow-btn"
              disabled={isForking}
            >
              Fork latest snapshot instead
            </button>
          {/if}
        </div>
      {/if}

      <div class="flex justify-end gap-2">
        <button
          onclick={close}
          class="btn-ghost px-4 py-2"
        >
          Cancel
        </button>
        <button
          onclick={() => handleFork('full')}
          class="btn-primary px-4 py-2"
          disabled={isForking || !modalInput.trim() || !isLoggedIn}
        >
          {#if isForking}
            <span class="i-lucide-loader-2 animate-spin mr-2"></span>
            {statusText}
          {:else}
            <span class="i-lucide-git-fork mr-2"></span>
            Fork
          {/if}
        </button>
      </div>
    </div>
  </div>
{/if}
