export interface UnifiedDiffFile {
  path: string;
  status: 'added' | 'deleted' | 'modified';
  oldText?: string;
  newText?: string;
  oldBytes?: Uint8Array;
  newBytes?: Uint8Array;
  oldMode?: string;
  newMode?: string;
}

export interface UnifiedDiffStats {
  additions: number;
  deletions: number;
  files: number;
}

export interface UnifiedDiffRenderedFile {
  path: string;
  status: UnifiedDiffFile['status'];
  text: string;
  patch: string;
  additions: number;
  deletions: number;
  isBinary: boolean;
}

export interface UnifiedDiffResult {
  text: string;
  stats: UnifiedDiffStats;
  files: UnifiedDiffRenderedFile[];
}

type DiffOp =
  | { type: 'context'; line: string }
  | { type: 'add'; line: string }
  | { type: 'remove'; line: string };

const DEFAULT_FILE_MODE = '100644';
const MAX_MYERS_EDIT_DISTANCE = 1024;
const DEFAULT_CONTEXT_LINES = 3;

export function escapeDiffHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export function colorizeDiffHtml(diff: string): string {
  return diff.split('\n').map(line => {
    const escaped = escapeDiffHtml(line);
    if (line.startsWith('+') && !line.startsWith('+++')) {
      return `<span class="text-success">${escaped}</span>`;
    }
    if (line.startsWith('-') && !line.startsWith('---')) {
      return `<span class="text-error">${escaped}</span>`;
    }
    if (line.startsWith('@@')) {
      return `<span class="text-accent">${escaped}</span>`;
    }
    if (
      line.startsWith('diff --git') ||
      line.startsWith('index ') ||
      line.startsWith('Binary files') ||
      line.startsWith('new file mode') ||
      line.startsWith('deleted file mode') ||
      line.startsWith('---') ||
      line.startsWith('+++')
    ) {
      return `<span class="text-text-3">${escaped}</span>`;
    }
    return escaped;
  }).join('\n');
}

export function buildUnifiedDiff(files: UnifiedDiffFile[]): UnifiedDiffResult {
  const parts: string[] = [];
  const renderedFiles: UnifiedDiffRenderedFile[] = [];
  const stats: UnifiedDiffStats = {
    additions: 0,
    deletions: 0,
    files: files.length,
  };

  for (const file of files) {
    const rendered = renderFileDiff(file);
    renderedFiles.push(rendered);
    parts.push(rendered.text);
    stats.additions += rendered.additions;
    stats.deletions += rendered.deletions;
  }

  return {
    text: parts.filter(Boolean).join('\n'),
    stats,
    files: renderedFiles,
  };
}

function renderFileDiff(file: UnifiedDiffFile): UnifiedDiffRenderedFile {
  const { path, status } = file;
  const oldLines = status === 'added' ? [] : file.oldText !== undefined ? splitLines(file.oldText) : null;
  const newLines = status === 'deleted' ? [] : file.newText !== undefined ? splitLines(file.newText) : null;

  if (oldLines === null || newLines === null) {
    const patch = status === 'added'
      ? `Binary files /dev/null and b/${path} differ`
      : status === 'deleted'
        ? `Binary files a/${path} and /dev/null differ`
        : `Binary files a/${path} and b/${path} differ`;
    return { path, status, text: `diff --git a/${path} b/${path}\n${patch}`, patch, additions: 0, deletions: 0, isBinary: true };
  }

  const operations = diffLines(oldLines, newLines);
  let additions = 0;
  let deletions = 0;
  for (const op of operations) {
    if (op.type === 'add') additions += 1;
    else if (op.type === 'remove') deletions += 1;
  }

  const headerLines = status === 'added'
    ? [`new file mode ${file.newMode ?? DEFAULT_FILE_MODE}`, '--- /dev/null', `+++ b/${path}`]
    : status === 'deleted'
      ? [`deleted file mode ${file.oldMode ?? DEFAULT_FILE_MODE}`, `--- a/${path}`, '+++ /dev/null']
      : [`--- a/${path}`, `+++ b/${path}`];
  const patch = [...headerLines, renderHunks(oldLines, newLines, operations)].join('\n');

  return { path, status, text: `diff --git a/${path} b/${path}\n${patch}`, patch, additions, deletions, isBinary: false };
}

function renderHunks(oldLines: string[], newLines: string[], operations: DiffOp[]): string {
  if (operations.length === 0) {
    const oldStart = oldLines.length === 0 ? 0 : 1;
    const newStart = newLines.length === 0 ? 0 : 1;
    return `@@ -${formatRange(oldStart, oldLines.length)} +${formatRange(newStart, newLines.length)} @@`;
  }

  const ranges = buildHunkRanges(operations, DEFAULT_CONTEXT_LINES);
  const hunks: string[] = [];
  let cursor = 0;
  let oldLine = 1;
  let newLine = 1;

  for (const [start, end] of ranges) {
    while (cursor < start) {
      const op = operations[cursor++];
      if (op.type !== 'add') oldLine += 1;
      if (op.type !== 'remove') newLine += 1;
    }
    const startOld = oldLine;
    const startNew = newLine;
    const body: string[] = [];
    let oldCount = 0;
    let newCount = 0;

    while (cursor <= end) {
      const op = operations[cursor++];
      if (op.type === 'context') {
        body.push(` ${op.line}`);
        oldCount += 1;
        newCount += 1;
        oldLine += 1;
        newLine += 1;
      } else if (op.type === 'add') {
        body.push(`+${op.line}`);
        newCount += 1;
        newLine += 1;
      } else {
        body.push(`-${op.line}`);
        oldCount += 1;
        oldLine += 1;
      }
    }

    const oldStart = oldCount === 0 ? 0 : startOld;
    const newStart = newCount === 0 ? 0 : startNew;
    hunks.push(`@@ -${formatRange(oldStart, oldCount)} +${formatRange(newStart, newCount)} @@\n${body.join('\n')}`);
  }

  return hunks.join('\n');
}

function buildHunkRanges(operations: DiffOp[], contextLines: number): Array<[number, number]> {
  const ranges: Array<[number, number]> = [];
  let rangeStart = -1;
  let rangeEnd = -1;

  for (let index = 0; index < operations.length; index += 1) {
    if (operations[index].type === 'context') continue;
    const nextStart = Math.max(0, index - contextLines);
    const nextEnd = Math.min(operations.length - 1, index + contextLines);
    if (rangeStart < 0) {
      rangeStart = nextStart;
      rangeEnd = nextEnd;
    } else if (nextStart <= rangeEnd + 1) {
      rangeEnd = Math.max(rangeEnd, nextEnd);
    } else {
      ranges.push([rangeStart, rangeEnd]);
      rangeStart = nextStart;
      rangeEnd = nextEnd;
    }
  }

  if (rangeStart >= 0) ranges.push([rangeStart, rangeEnd]);
  return ranges.length > 0 ? ranges : [[0, operations.length - 1]];
}

function formatRange(start: number, count: number): string {
  if (count === 0) return `${start},0`;
  if (count === 1) return String(start);
  return `${start},${count}`;
}

function splitLines(text: string): string[] {
  if (!text) return [];
  const parts = text.replace(/\r\n/g, '\n').split('\n');
  if (parts[parts.length - 1] === '') parts.pop();
  return parts;
}

function diffLines(oldLines: string[], newLines: string[]): DiffOp[] {
  let prefix = 0;
  while (prefix < oldLines.length && prefix < newLines.length && oldLines[prefix] === newLines[prefix]) {
    prefix += 1;
  }

  let oldSuffix = oldLines.length;
  let newSuffix = newLines.length;
  while (oldSuffix > prefix && newSuffix > prefix && oldLines[oldSuffix - 1] === newLines[newSuffix - 1]) {
    oldSuffix -= 1;
    newSuffix -= 1;
  }

  const operations: DiffOp[] = [];
  for (let i = 0; i < prefix; i += 1) {
    operations.push({ type: 'context', line: oldLines[i] });
  }

  const oldMiddle = oldLines.slice(prefix, oldSuffix);
  const newMiddle = newLines.slice(prefix, newSuffix);
  for (const op of diffMiddle(oldMiddle, newMiddle)) operations.push(op);

  for (let i = oldSuffix; i < oldLines.length; i += 1) {
    operations.push({ type: 'context', line: oldLines[i] });
  }

  return operations;
}

/** Myers O((N+M)D) shortest edit script with integer-interned line IDs. */
function diffMiddle(oldLines: string[], newLines: string[]): DiffOp[] {
  const n = oldLines.length;
  const m = newLines.length;
  if (n === 0) return newLines.map((line) => ({ type: 'add', line }));
  if (m === 0) return oldLines.map((line) => ({ type: 'remove', line }));

  const lineIds = new Map<string, number>();
  let nextId = 1;
  const intern = (lines: string[]) => {
    const out = new Int32Array(lines.length);
    for (let i = 0; i < lines.length; i++) {
      let id = lineIds.get(lines[i]);
      if (id === undefined) {
        id = nextId++;
        lineIds.set(lines[i], id);
      }
      out[i] = id;
    }
    return out;
  };
  const a = intern(oldLines);
  const b = intern(newLines);

  const maxD = Math.min(n + m, MAX_MYERS_EDIT_DISTANCE);
  const v = new Int32Array(2 * maxD + 1);
  const trace: Int32Array[] = [];

  for (let d = 0; d <= maxD; d++) {
    // Save v[k] for k in [-d..d] prior to step d for exact backtracking.
    trace.push(v.slice(maxD - d, maxD + d + 1));
    for (let k = -d; k <= d; k += 2) {
      const down = k === -d || (k !== d && v[k - 1 + maxD] < v[k + 1 + maxD]);
      let x = down ? v[k + 1 + maxD] : v[k - 1 + maxD] + 1;
      let y = x - k;
      while (x < n && y < m && a[x] === b[y]) {
        x++;
        y++;
      }
      v[k + maxD] = x;
      if (x >= n && y >= m) {
        return backtrackMyers(oldLines, newLines, trace, d);
      }
    }
  }

  return [
    ...oldLines.map((line) => ({ type: 'remove' as const, line })),
    ...newLines.map((line) => ({ type: 'add' as const, line })),
  ];
}

function backtrackMyers(
  oldLines: string[],
  newLines: string[],
  trace: Int32Array[],
  finalD: number,
): DiffOp[] {
  const reversed: DiffOp[] = [];
  let x = oldLines.length;
  let y = newLines.length;

  for (let d = finalD; d > 0; d--) {
    const prev = trace[d];
    const k = x - y;
    const prevK = k === -d || (k !== d && prev[k - 1 + d] < prev[k + 1 + d]) ? k + 1 : k - 1;
    const prevX = prev[prevK + d];
    const prevY = prevX - prevK;

    while (x > prevX && y > prevY) {
      x--;
      y--;
      reversed.push({ type: 'context', line: oldLines[x] });
    }
    if (prevK === k + 1) {
      y--;
      reversed.push({ type: 'add', line: newLines[y] });
    } else {
      x--;
      reversed.push({ type: 'remove', line: oldLines[x] });
    }
  }

  while (x > 0 && y > 0) {
    x--;
    y--;
    reversed.push({ type: 'context', line: oldLines[x] });
  }

  reversed.reverse();
  return reversed;
}
