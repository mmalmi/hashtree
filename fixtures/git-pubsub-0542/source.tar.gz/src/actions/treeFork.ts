import { get } from 'svelte/store';
import { toHex, type CID, type TreeVisibility } from '@hashtree/core';
import { nostrStore } from '../nostr';
import { getTree } from '../store';
import { buildHtreeUrl, getStoredRepoAnnouncement, publishRepoAnnouncement } from '../nip34';
import { getRootCommit } from '../utils/git';
import { navigate } from '../lib/router.svelte';
import { parseRoute } from '../utils/route';
import { ignoreGeneratedProjectMetaInGitStatus, setProjectForkOrigin } from '../stores/projectMeta';
import { externalTreeKeysStore, isExternalTreeKey } from '../lib/externalTrees';
import { ngitRepoOriginUrl } from '../ngit/links';

export interface ForkTreeOptions {
  ngitMode?: 'full' | 'shallow';
  onProgress?: (status: string) => void;
  signal?: AbortSignal;
}

export interface ForkTreeResult {
  success: boolean;
  linkKey?: string;
  tooLarge?: boolean;
  error?: string;
}

export async function forkTree(
  dirCid: CID,
  name: string,
  visibility: TreeVisibility = 'public',
  options: ForkTreeOptions = {},
): Promise<ForkTreeResult> {
  if (!name) return { success: false };

  const { saveHashtree } = await import('../nostr');
  const { storeLinkKey } = await import('../stores/trees');
  const tree = getTree();

  const nostrState = nostrStore.getState();
  if (!nostrState.npub || !nostrState.pubkey) {
    return { success: false, error: 'Please sign in to fork repositories.' };
  }

  const route = parseRoute();
  const sourceOwnerNpub = route.npub;
  const sourceTreeName = route.treeName;
  const sourceRepoName = sourceTreeName
    ? [sourceTreeName, ...route.path].filter(Boolean).join('/')
    : null;
  const isExternalNgit = isExternalTreeKey(get(externalTreeKeysStore), sourceOwnerNpub, sourceTreeName);

  let forkOriginUrl: string | null = null;
  let forkAnnouncementEuc: string | undefined;
  let publishForkAnnouncement = false;
  let forkMetadataApplied = false;
  let finalCid = dirCid;

  if (isExternalNgit) {
    if (!sourceOwnerNpub || !sourceTreeName) {
      return { success: false, error: 'Source repository is unavailable.' };
    }
    const mode = options.ngitMode ?? 'full';
    const stageLabels = {
      fetching: mode === 'shallow' ? 'Fetching latest snapshot...' : 'Fetching Git history...',
      indexing: 'Indexing Git pack...',
      saving: 'Saving to Hashtree...',
    };
    const { importActiveNgitRepoForFork } = await import('../ngit/session');
    try {
      const { imported, announcement } = await importActiveNgitRepoForFork(sourceOwnerNpub, sourceTreeName, {
        mode,
        signal: options.signal,
        onProgress: (stage) => options.onProgress?.(stageLabels[stage]),
      });
      finalCid = imported.rootCid;
      forkAnnouncementEuc = announcement.earliestUniqueCommit
        ?? (imported.shallow.length === 0 ? await getRootCommit(finalCid) : null)
        ?? undefined;
      if (sourceOwnerNpub !== nostrState.npub) {
        forkOriginUrl = ngitRepoOriginUrl(sourceOwnerNpub, sourceTreeName);
      }
      publishForkAnnouncement = visibility === 'public';
    } catch (error) {
      if (error instanceof Error && error.name === 'GitResponseTooLargeError') {
        return {
          success: false,
          tooLarge: true,
          error: 'Full history exceeds the browser size limit. You can fork the latest commit snapshot instead.',
        };
      }
      throw error;
    }
  } else {
    try {
      const sourceAnnouncement = sourceOwnerNpub && sourceRepoName
        // What this device already holds; the fork does not wait for a relay.
        ? await getStoredRepoAnnouncement(sourceOwnerNpub, sourceRepoName).catch(() => null)
        : null;
      const sourceRootCommit = sourceAnnouncement?.earliestUniqueCommit ?? await getRootCommit(dirCid);
      const shouldAnnotateFork = (
        !!sourceOwnerNpub &&
        !!sourceRepoName &&
        sourceOwnerNpub !== nostrState.npub &&
        !!sourceRootCommit
      );

      if (shouldAnnotateFork && sourceOwnerNpub && sourceRepoName) {
        forkOriginUrl = buildHtreeUrl(sourceOwnerNpub, sourceRepoName);
        forkAnnouncementEuc = sourceRootCommit ?? undefined;
        publishForkAnnouncement = visibility === 'public';
      }
    } catch (error) {
      console.warn('[Fork] Failed to resolve fork origin metadata', error);
    }
  }

  const shouldReencryptFork = visibility !== 'public' && !finalCid.key;

  if (forkOriginUrl && !finalCid.key) {
    try {
      finalCid = await setProjectForkOrigin(finalCid, forkOriginUrl);
      forkMetadataApplied = true;
    } catch (error) {
      console.warn('[Fork] Failed to annotate fork origin metadata before re-encryption', error);
    }
  }

  if (shouldReencryptFork) {
    console.log('[Fork] Source is unencrypted, re-encrypting...');

    const rebuildWithEncryption = async (oldCid: CID): Promise<CID> => {
      if (oldCid.key) return oldCid;

      const isDir = await tree.isDirectory(oldCid);
      if (isDir) {
        const entries = await tree.listDirectory(oldCid);
        const newEntries = [];
        for (const entry of entries) {
          const newChildCid = await rebuildWithEncryption(entry.cid);
          newEntries.push({
            name: entry.name,
            cid: newChildCid,
            size: entry.size,
            type: entry.type ?? 0,
            meta: entry.meta,
          });
        }
        return (await tree.putDirectory(newEntries, {})).cid;
      }

      const data = await tree.readFile(oldCid);
      if (!data) return oldCid;
      return (await tree.putFile(data, {})).cid;
    };

    finalCid = await rebuildWithEncryption(finalCid);
    console.log('[Fork] Re-encryption complete');
  }

  if (forkOriginUrl && !forkMetadataApplied) {
    try {
      finalCid = await setProjectForkOrigin(finalCid, forkOriginUrl);
      forkMetadataApplied = true;
    } catch (error) {
      console.warn('[Fork] Failed to annotate fork origin metadata', error);
    }
  }

  if (forkOriginUrl && forkMetadataApplied) {
    try {
      finalCid = await ignoreGeneratedProjectMetaInGitStatus(finalCid);
    } catch (error) {
      console.warn('[Fork] Failed to hide generated fork metadata from git status', error);
    }
  }

  options.onProgress?.('Publishing to Hashtree...');

  nostrStore.setSelectedTree({
    id: '',
    name,
    pubkey: nostrState.pubkey,
    labels: isExternalNgit ? ['git'] : undefined,
    rootHash: toHex(finalCid.hash),
    rootKey: finalCid.key ? toHex(finalCid.key) : undefined,
    visibility,
    created_at: Math.floor(Date.now() / 1000),
  });

  const result = await saveHashtree(name, finalCid, {
    visibility,
    ...(isExternalNgit ? { labels: ['git'] } : {}),
  });

  if (result.linkKey) {
    storeLinkKey(nostrState.npub, name, result.linkKey);
  }

  if (result.success && isExternalNgit) {
    const { clearNgitSession } = await import('../ngit/session');
    clearNgitSession(nostrState.npub, name);
  }

  if (result.success && publishForkAnnouncement) {
    try {
      const published = await publishRepoAnnouncement(name, {
        personalFork: !!forkOriginUrl,
        earliestUniqueCommit: forkAnnouncementEuc,
        forkedFrom: forkOriginUrl ?? undefined,
      });
      if (!published) {
        console.warn('[Fork] Failed to publish personal fork announcement', { name });
      }
    } catch (error) {
      console.warn('[Fork] Failed to publish personal fork announcement', error);
    }
  }

  if (result.success) {
    const linkKeyParam = result.linkKey ? `?k=${result.linkKey}` : '';
    navigate(`/${encodeURIComponent(nostrState.npub)}/${encodeURIComponent(name)}${linkKeyParam}`);
  }
  return result;
}
