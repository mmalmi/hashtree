import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { chmodSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { HashTree, LinkType, MemoryStore, toHex, type CID, type TreeEntry } from '@hashtree/core';

let tree: HashTree;
vi.mock('../src/store', () => ({
  getTree: () => tree,
  decodeAsText: (data: Uint8Array) => new TextDecoder().decode(data),
}));
const historyCache = vi.hoisted(() => ({ readPublicFileHistory: vi.fn() }));
vi.mock('../src/utils/publicGitFileHistory', () => historyCache);
import { getCommitCountFast, getCommitInfo } from '../src/utils/wasmGit/logHistory';
import { getFileLastCommits } from '../src/utils/wasmGit/logFileHistory';
import { diffBranchesNative, getCommitViewDataNative } from '../src/utils/wasmGit/logDiff';

let repo: string;
let root: CID;
let head: string;
let mergeRoot: CID;
let revertedRoot: CID;
let revertedHead: string;
let looseHead: string;
const expectedLastChange = new Map<string, string>();
const packHashes = new Set<string>();
let fullPackReads = 0;
let rangeBytes = 0;
let failNextPackRead = false;
// Small chunks so the pack spans several of them, as real packs do.
const CHUNK_SIZE = 256;
const packSizes = new Map<string, number>();
const packReads: Array<{ pack: string; start: number; bytes: number }> = [];

beforeAll(async () => {
  repo = mkdtempSync(join(tmpdir(), 'iris-git-history-'));
  const git = (...args: string[]) => execFileSync('git', ['-c', 'commit.gpgsign=false', ...args], { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  git('init', '-b', 'master');
  git('config', 'user.name', 'Test');
  git('config', 'user.email', 'test@example.com');
  for (let i = 0; i < 3; i++) {
    writeFileSync(join(repo, 'file.txt'), `revision ${i}\n` + 'content\n'.repeat(10000));
    git('add', '.');
    git('commit', '-m', `commit ${i}`);
  }
  head = git('rev-parse', 'HEAD');
  git('checkout', '-b', 'side', 'HEAD~1');
  writeFileSync(join(repo, 'side.txt'), 'side branch');
  git('add', '.');
  git('commit', '-m', 'unreachable from master');
  mkdirSync(join(repo, 'nested'));
  writeFileSync(join(repo, 'nested/run'), 'script');
  git('add', '.');
  git('commit', '-m', 'add script');
  git('branch', 'script-nonexec');
  chmodSync(join(repo, 'nested/run'), 0o755);
  git('update-index', '--chmod=+x', 'nested/run');
  git('commit', '-m', 'mark script executable');
  git('checkout', '-b', 'merged', 'master');
  git('merge', '--no-ff', 'side', '-m', 'merge side');
  const mergeHead = git('rev-parse', 'HEAD');
  for (const path of ['file.txt', 'side.txt', 'nested', 'nested/run']) {
    expectedLastChange.set(path, git('log', '-1', '--format=%H', '--', path));
  }
  git('checkout', 'master');
  git('repack', '-ad');
  // Overlapping packs are valid and common after incremental hashtree pushes.
  looseHead = git('commit-tree', mergeHead + '^{tree}', '-p', mergeHead, '-m', 'loose tip');
  const changed = git('commit-tree', 'HEAD~1^{tree}', '-p', head, '-m', 'replace file');
  revertedHead = git('commit-tree', 'HEAD^{tree}', '-p', changed, '-m', 'restore file');
  const packDir = join(repo, '.git/objects/pack');
  for (const name of readdirSync(packDir)) {
    writeFileSync(join(packDir, `pack-duplicate.${name.split('.').at(-1)}`), readFileSync(join(packDir, name)));
  }
  tree = new HashTree({ store: new MemoryStore(), chunkSize: CHUNK_SIZE });
  async function upload(path: string): Promise<CID> {
    const entries: TreeEntry[] = [];
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.name === 'hooks' || entry.name === 'logs') continue;
      if (entry.isDirectory()) {
        entries.push({ name: entry.name, cid: await upload(join(path, entry.name)), type: LinkType.Dir, size: 0 });
      } else {
        const file = await tree.putFile(new Uint8Array(readFileSync(join(path, entry.name))));
        entries.push({ name: entry.name, cid: file.cid, type: LinkType.File, size: file.size });
        if (entry.name.endsWith('.pack')) {
          packHashes.add(toHex(file.cid.hash));
          packSizes.set(toHex(file.cid.hash), file.size);
        }
      }
    }
    return (await tree.putDirectory(entries)).cid;
  }
  const gitCid = await upload(join(repo, '.git'));
  root = (await tree.putDirectory([{ name: '.git', cid: gitCid, type: LinkType.Dir, size: 0 }])).cid;
  async function detachedRoot(oid: string) {
    const detached = await tree.putFile(new TextEncoder().encode(oid));
    const git = await tree.putDirectory((await tree.listDirectory(gitCid)).map(entry =>
      entry.name === 'HEAD' ? { ...entry, cid: detached.cid, size: detached.size } : entry));
    return (await tree.putDirectory([{ name: '.git', cid: git.cid, type: LinkType.Dir, size: 0 }])).cid;
  }
  mergeRoot = await detachedRoot(looseHead);
  revertedRoot = await detachedRoot(revertedHead);

  const read = tree.readFile.bind(tree);
  vi.spyOn(tree, 'readFile').mockImplementation(async cid => {
    if (packHashes.has(toHex(cid.hash))) fullPackReads++;
    return read(cid);
  });
  const range = tree.readFileRange.bind(tree);
  vi.spyOn(tree, 'readFileRange').mockImplementation(async (cid, start, end) => {
    const pack = toHex(cid.hash);
    if (packHashes.has(pack) && failNextPackRead) {
      failNextPackRead = false;
      throw new Error('Blob retrieval timed out');
    }
    const data = await range(cid, start, end);
    rangeBytes += data?.length ?? 0;
    if (packHashes.has(pack) && data) packReads.push({ pack, start, bytes: data.length });
    return data;
  });
});
afterAll(() => rmSync(repo, { recursive: true, force: true }));

describe('packed repository history', () => {
  it('reads a loose tip without fetching pack indexes or data', async () => {
    expect(await getCommitInfo(mergeRoot, looseHead)).toMatchObject({ message: 'loose tip' });
    expect(rangeBytes).toBe(0);
    expect(fullPackReads).toBe(0);
  });
  it('reads a packed commit without downloading the entire pack', async () => {
    failNextPackRead = true;
    expect(await getCommitInfo(root, head)).toBeNull();
    expect(await getCommitInfo(root, head)).toMatchObject({ oid: head, message: 'commit 2' });
    expect(fullPackReads).toBe(0);
    expect(rangeBytes).toBeGreaterThan(0);
    const pack = packReads[0].pack;
    expect(packSizes.get(pack)).toBeGreaterThan(CHUNK_SIZE * 2);
    const bytesRead = packReads.filter(read => read.pack === pack).reduce((sum, read) => sum + read.bytes, 0);
    expect(bytesRead).toBeLessThan(packSizes.get(pack)!);
  });
  it('counts reachable commits once across overlapping packs and other branches', async () => {
    expect(await getCommitCountFast(root)).toBe(3);
    expect(fullPackReads).toBe(0);
  });
  it('walks file history reading each stored pack chunk at most once', async () => {
    const commits = await getFileLastCommits(root, ['file.txt', 'side.txt']);
    expect(commits.get('file.txt')).toMatchObject({ oid: head, message: 'commit 2' });
    expect(commits.has('side.txt')).toBe(false);
    // Commits, trees and their delta bases are served from cached chunks.
    const chunks = packReads.map(read => `${read.pack}:${read.start}`);
    expect(new Set(chunks).size).toBe(chunks.length);
    expect(Math.max(...packReads.map(read => read.bytes))).toBeLessThanOrEqual(CHUNK_SIZE);
    expect(fullPackReads).toBe(0);
  });
  it('matches git log for merged files, directories, and mode-only changes', async () => {
    const rows = await getFileLastCommits(mergeRoot, ['file.txt', 'side.txt', 'nested']);
    const nested = await getFileLastCommits(mergeRoot, ['run'], 'nested');
    for (const [path, oid] of expectedLastChange) {
      const row = path === 'nested/run' ? nested.get('run') : rows.get(path);
      expect(row?.oid, path).toBe(oid);
    }
  });
  it('reuses public row history only when its commit is reached for that path', async () => {
    expect(historyCache.readPublicFileHistory).not.toHaveBeenCalled();
    const directory = 'public directory';
    const rows = await getFileLastCommits(root, ['file.txt'], '', undefined, undefined, directory);
    historyCache.readPublicFileHistory.mockResolvedValue({ head, rows });

    const onProgress = vi.fn();
    expect(await getFileLastCommits(root, ['file.txt'], '', onProgress, undefined, directory)).toEqual(rows);
    expect(onProgress).toHaveBeenCalledExactlyOnceWith('file.txt', rows.get('file.txt'));

    const merged = await getFileLastCommits(mergeRoot, ['file.txt', 'side.txt'], '', undefined, undefined, directory);
    expect(merged.get('file.txt')?.oid).toBe(expectedLastChange.get('file.txt'));
    expect(merged.get('side.txt')?.oid).toBe(expectedLastChange.get('side.txt'));

    // This commit has exactly the saved root tree, but the file changed and
    // was then restored. The most recent change is the restore commit.
    const restored = await getFileLastCommits(revertedRoot, ['file.txt'], '', undefined, undefined, directory);
    expect(restored.get('file.txt')?.oid).toBe(revertedHead);
  });
  it('stops delivering rows when the listing is left', async () => {
    const controller = new AbortController();
    const onProgress = vi.fn(() => controller.abort());
    const rows = await getFileLastCommits(mergeRoot, ['file.txt', 'side.txt', 'nested'], '', onProgress, controller.signal);
    expect(onProgress).toHaveBeenCalledTimes(1);
    expect(rows.size).toBe(1);
  });
  it('diffs branches and loads commit views natively without full-pack reads', async () => {
    const ffDiff = await diffBranchesNative(root, 'master', 'merged');
    expect(ffDiff.error).toBeUndefined();
    expect(ffDiff.canFastForward).toBe(true);
    expect(ffDiff.stats.files).toEqual(['nested/run', 'side.txt']);
    expect(ffDiff.diff).toContain('+side branch');

    const divergedDiff = await diffBranchesNative(root, 'master', 'side');
    expect(divergedDiff.canFastForward).toBe(false);
    expect(divergedDiff.stats.files).toContain('side.txt');

    const missing = await diffBranchesNative(root, 'master', 'does-not-exist');
    expect(missing.error).toContain('Branch or ref not found');

    const view = await getCommitViewDataNative(root, head);
    expect(view?.commit.oid).toBe(head);
    expect(view?.stats).toEqual({ additions: 1, deletions: 1, files: 1 });
    expect(fullPackReads).toBe(0);
  });
  it('preserves executable modes in branch comparisons', async () => {
    const added = await diffBranchesNative(root, 'master', 'merged');
    expect(added.diff).toContain('diff --git a/nested/run b/nested/run\nnew file mode 100755');

    const changed = await diffBranchesNative(root, 'script-nonexec', 'side');
    expect(changed.stats).toEqual({ additions: 0, deletions: 0, files: ['nested/run'] });
    expect(changed.diff).toBe('diff --git a/nested/run b/nested/run\nold mode 100644\nnew mode 100755');
    const removed = await diffBranchesNative(root, 'merged', 'master');
    expect(removed.diff).toContain('diff --git a/nested/run b/nested/run\ndeleted file mode 100755');
  });
});
