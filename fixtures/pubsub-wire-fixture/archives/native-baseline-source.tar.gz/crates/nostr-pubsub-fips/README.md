# nostr-pubsub-fips

Reliable authenticated Nostr pubsub over FIPS.

`FipsPubsubClient` carries normal Nostr `REQ`, `EVENT`, and `CLOSE` JSON frames
as bounded records over `fips-tcp`, using FIPS service port `7368` and
capability `nostr.pubsub/1`. There is no raw-FSP datagram fallback and this
crate opens no Nostr relay socket.

The Rust dependencies are published as `nvpn-fips-core`, `nvpn-fips-tcp`, and
`nvpn-fips-tcp-endpoint`. Source imports abbreviate these names locally.
Version `0.5.47` requires `nostr-pubsub` `0.1.19` or later and uses FIPS
core `0.4.115`, TCP `0.2.6`, and TCP endpoint `0.2.50`.

Every high-level client keeps one bounded default subscription for signed
`fips-overlay-v1` kind `37195` endpoint adverts. It publishes its FIPS-generated
local advert into replay, refreshes it at half its signed TTL (capped at 30
minutes), ingests received adverts through FIPS's normal validator, and gossips
them over matching FIPS subscriptions. This works with an empty Nostr relay
list. Applications with a social-graph policy should use
`FipsPubsubClient::start_with_policies` with `FipsPubsubPolicy::client_policies()`
to apply one shared trust projection to peer preference and event admission.
Admission runs before local delivery, replay retention, or forwarding.
The existing `start_with_policy` remains available for event admission alone.

Trust entrypoints come from application configuration through
`FipsPubsubPolicyOptions::reputation.trusted_raters`, which accepts public keys
in hex or npub form and defaults to an empty set. No person's identity is
chosen automatically. This projection consumes signed machine ratings; it does
not import personal follow lists or grant access to application data. Positive
service ratings do not authorize a peer to rate others.

`FipsPubsubClient::start_with_reputation(endpoint, options, reputation_options)`
also manages the bounded rating subscription and paced local publication. It
uses one slot from `max_active_subscriptions`, subscribes only to the local root
and configured raters, and releases its task and subscription with the client.
Local observations update preference even when publication fails. The default
evaluation interval is one minute, and both publication batches and replay are
bounded. `reputation_error_count()` exposes failed updates or publications.
Ratings are retained in memory and recover through available peer replay; use
the policy facade directly when the application needs durable rating storage.

Applications sharing a client through `Arc` must call
`client.shutdown_shared().await` before stopping its FIPS endpoint. It closes
subscriptions, rejects new publication/query/subscription work, and joins every
owned task even while providers retain the client. Concurrent shutdown callers
wait for completion; a cancelled caller leaves unfinished joins available to
the next caller. The consuming `shutdown().await` remains available. Client
shutdown leaves the application-owned endpoint running.

The high-level client uses the same bounded quality selector as the lower-level
mesh. With a peer policy, direct connections and inventory fanout prefer higher
scores while retaining `unknown_peer_reserve` exploration slots (one by default).
Equal-quality live recipients rotate deterministically by event and local identity;
connection selection stays stable rather than reconnecting for each event.
Explicit routed identities keep priority if admitted by the policy. Changing
shared policy state updates existing connections and subscriptions; rejected
peers release their pubsub state while application-owned FIPS links stay intact.
Without a peer policy, the original identity-ordered connection selection and
event-dependent fanout remain unchanged.

Repeated pubsub service connection attempts are spaced at least three seconds
apart per selected peer, including attempts triggered by new outgoing frames.
The first attempt remains immediate. This monotonic retry bound avoids busy
reconnect loops when a reachable FIPS peer has no pubsub service or repeatedly
closes its stream. It does not penalize the peer's transport reputation.
Retained subscriptions replay when the service returns. A one-shot query can
still reach its configured timeout during recovery: the default 500 ms query
window is shorter than the retry interval, so applications needing that
recovery window should configure `query_timeout` accordingly.

Applications can supply known service identities in
`FipsPubsubClientOptions::routed_peers`, then replace that bounded roster using
`set_routed_peers` as authorized devices join or leave. These destinations take
priority within the connection limit and use ordinary authenticated FIPS
routing. Intermediate nodes need no pubsub service or matching subscription.
The roster provides identities, not physical addresses or a separate routing
protocol; the endpoint still needs a working route. Restricting peer transports
and routed identities cannot be combined because the endpoint API does not
expose every transport along an indirect path.
The supplied roster must fit the outgoing connection capacity; temporarily unreachable
configured identities retain their slots until the application removes them.

Public providers can opt in with `max_inbound_routed_peers` (default `0`).
Those slots are reserved within `max_connected_peers`, leaving the remainder
for the selected outgoing roster. Only an authenticated initial service SYN
can reserve a public slot. Inbound clients receive requested events without
receiving the provider's own subscriptions. Disconnects release all TCP and
pubsub state for that identity; abandoned clients expire after 30 idle seconds.
Promoting an inbound client into the selected roster reconnects it and replays
local subscriptions. This option cannot be combined with transport restrictions.

The routed-provider test also supports a separate, unchanged `0.5.16` client:
build `tests/previous-client/Cargo.toml`, then run
`public_provider_serves_unknown_late_client_through_transit` with
`NOSTR_PUBSUB_PREVIOUS_CLIENT` set to that fixture's absolute executable path.
Both the default closed provider and the opt-in provider run over real UDP
through a transit endpoint with no pubsub service.

Endpoints participating in FIPS same-host rendezvous also discover local
`nostr.pubsub/1` providers automatically, including providers reached through
an anchor that runs no pubsub service. The exact service port must match.
Explicit routed identities retain priority; discovered providers and direct
peers share the remaining connection limit and application peer policy.
Service withdrawal removes discovered candidates, and a provider's new startup
epoch resets its stream. Transport-restricted clients use only eligible direct
links, since an indirect route cannot prove every transport it traverses.
Discovery does not grant access to application data or alter endpoint links.

Live mesh delivery is inventory-first. For every new event, providers send a
small `INV` containing every matching open `REQ` subscription ID for that peer.
A receiver dedupes the event ID across all peers and all of its live
subscriptions, sends one one-event `WANT` to one provider, and receives one
ordinary subscription `EVENT`. That verified event is then delivered once to
every matching local subscription.
Alternate providers are retained within fixed bounds and selected if the first
request does not complete. `CLOSE` retains its normal subscription semantics.

Recent events are kept in a bounded replay cache so a `REQ` or reconnected TCP
peer can receive inventories for the live window. The same `INV`/`WANT` flow
also works for historical events. For a large stored set, a reconciliation
layer such as NIP-77 Negentropy can identify the missing IDs first and then use
the same event transfer path more efficiently.

`set_replay_source(Some(store))` attaches an application-owned local `EventBus`
for historical `REQ` queries and exact-ID `WANT` reads beyond the memory window.
Attach only a store containing events peers may read. The application controls
durable ingestion, retention and restart recovery; Hashtree event indexes can
implement this interface. Storage reads run outside the transport loop, with
four concurrent queries, a queue bounded by `max_connected_peers`, and the
existing `query_timeout`. Responses recheck current subscriptions, event policy
and the attached source. Detaching the source suppresses pending responses;
client shutdown cancels and joins the query workers.

An explicit local publish retries a payload that has left this replay window,
while duplicate incoming gossip stays suppressed. Durable application outboxes
should pace retry batches within `max_replay_events` so payloads remain
available while peers request them; the client itself is not a durable store.

The package also exports the lower-level `FipsInvWantTcpDriver` for non-Nostr
mesh protocols, plus transport-neutral FIPS peerfinding and reputation
adapters. It targets the FIPS `0.4.x` endpoint API.

## Private provider operations

Use `FipsAnonymousPublisher::start` with a fresh random endpoint and explicit
public provider identities, then consume it with `publish_once(event, timeout)`.
Each event, recipient copy and retry needs a different endpoint. Success is an
exact-event `OK` from an explicitly selected provider, never a local cache report.
An older or unavailable provider leaves application-owned durable queues pending.
The caller owns endpoint shutdown. Network addresses and timing remain observable.

Public providers opt in with `accept_anonymous_publications: true` and bounded
`max_inbound_routed_peers`. Verified submissions enter policy/cache/fanout without
promoting inbound clients into the outgoing provider roster. Receipts acknowledge
remote admission, not durable storage or final recipient decryption.

Use `start_receive_only` on identified receivers. Private envelopes can be
received but cannot be exported through cache, inventory, exact-ID or external
retained replay requests. `start_receive_only_with_public_authors` additionally
permits explicit own/public service authors, never private contacts. Public peer
profiles, authorization, invites and endpoint-advert lookups use a separate fresh
`start_anonymous_discovery` endpoint with a fixed `FipsDiscoveryScope`. Disable
identity-coupled built-in endpoint discovery before binding; route own adverts
and public peer lookups through their separate application transports. These
roles preserve the existing full client for trusted sibling/live/public services.

### Durable public discovery

Attach an application-owned local `EventBus` with
`client.set_peer_announcement_store(Some(store.clone())).await`. This restores
its signed kind-37195 announcements through the normal FIPS validator and
retains the default public stream plus the current local advert. App-specific
streams can use `FipsPeerfinder::with_store` with their configured scope.

Attach that store, or a composition of local indexes, with `set_replay_source`
to serve ordinary peer requests after restart. Never use a network-fetching
router or a private contact-discovery cache as the public replay source.
The core crate's optional `file-store` adapter provides bounded atomic native
storage. After stopping consumers, await `FileEventBus::close` to finish an
owned write and release the writer lease before reopening the same path.
