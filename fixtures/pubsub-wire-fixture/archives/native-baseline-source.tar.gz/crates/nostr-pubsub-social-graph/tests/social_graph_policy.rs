use std::sync::{Arc, RwLock};

use nostr::{EventBuilder, Keys, Kind, ToBech32};
use nostr_pubsub::{
    CAP_HASHTREE_FETCH, EventBus, EventSource, EventSourceKind, Filter, InMemoryEventBus,
    PolicyDecision, PubsubPolicy, QueryOptions, RouteQuerySource, RoutedQueryOptions,
    SourceCandidate, SourceHealth, SourceId, SourcePolicyContext, SourceRoute, VerifiedEvent,
    query_routes_with_policy,
};
use nostr_pubsub_social_graph::{
    DEFAULT_SOCIAL_GRAPH_ENTRYPOINT_NPUB, GraphDistanceAction, InMemoryServiceReputation,
    MeshPeerPolicy, SocialGraphPolicy, SocialGraphPolicyConfig,
};
use nostr_social_graph::{NostrEvent, SocialGraph, SocialGraphBackend};

#[test]
fn default_social_graph_entrypoint_seed_is_exposed_for_cold_start() {
    assert_eq!(
        DEFAULT_SOCIAL_GRAPH_ENTRYPOINT_NPUB,
        "npub1g53mukxnjkcmr94fhryzkqutdz2ukq4ks0gvy5af25rgmwsl4ngq43drvk"
    );
}

#[tokio::test]
async fn bus_prioritizes_graph_authors_and_throttles_unknown_authors() {
    let Fixture {
        graph,
        friend,
        unknown,
        ..
    } = fixture();
    let bus = InMemoryEventBus::with_policy(Arc::new(SocialGraphPolicy::new(
        graph,
        SocialGraphPolicyConfig::default(),
    )));

    let trusted = bus
        .publish(
            signed_text_note(&friend, "trusted"),
            EventSource::peer("peer"),
        )
        .await
        .unwrap();
    let unknown = bus
        .publish(
            signed_text_note(&unknown, "unknown"),
            EventSource::peer("peer"),
        )
        .await
        .unwrap();

    assert!(trusted.accepted);
    assert!(unknown.accepted);
    assert!(trusted.priority > unknown.priority);
    assert_eq!(trusted.reason, None);
    assert_eq!(
        unknown.reason.as_deref(),
        Some("author outside social graph")
    );
}

#[tokio::test]
async fn bus_can_drop_authors_outside_the_social_graph() {
    let Fixture { graph, unknown, .. } = fixture();
    let config = SocialGraphPolicyConfig {
        outside_graph_action: GraphDistanceAction::Drop,
        ..SocialGraphPolicyConfig::default()
    };
    let bus = InMemoryEventBus::with_policy(Arc::new(SocialGraphPolicy::new(graph, config)));

    let report = bus
        .publish(
            signed_text_note(&unknown, "drop"),
            EventSource::peer("peer"),
        )
        .await
        .unwrap();
    assert!(!report.accepted);
    assert_eq!(
        report.reason.as_deref(),
        Some("author outside social graph")
    );

    let queried = bus
        .query(vec![Filter::new()], QueryOptions::default())
        .await
        .unwrap();
    assert!(queried.events.is_empty());
}

#[tokio::test]
async fn service_reputation_can_boost_useful_sources_outside_the_human_graph() {
    let Fixture { graph, unknown, .. } = fixture();
    let unknown_id = unknown.public_key().to_hex();
    let unknown_npub = unknown.public_key().to_bech32().unwrap();
    let reputation = Arc::new(InMemoryServiceReputation::default());
    reputation.boost_source(&unknown_id, Some(CAP_HASHTREE_FETCH), 250);
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default())
        .with_service_reputation(reputation);
    let capabilities = vec![CAP_HASHTREE_FETCH.to_string()];
    let candidate = SourceCandidate {
        source: EventSource::peer(&unknown_npub),
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let decision = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: None,
            capabilities: &capabilities,
        })
        .await
        .unwrap();

    assert!(matches!(decision, PolicyDecision::Allow { priority } if priority > 0));
}

#[tokio::test]
async fn service_reputation_can_throttle_socially_near_sources_with_bad_history() {
    let Fixture { graph, friend, .. } = fixture();
    let friend_id = friend.public_key().to_hex();
    let reputation = Arc::new(InMemoryServiceReputation::default());
    reputation.throttle_source(&friend_id, None, -250, "recent invalid responses");
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default())
        .with_service_reputation(reputation);
    let candidate = SourceCandidate {
        source: EventSource::peer(&friend_id),
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let decision = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: None,
            capabilities: &[],
        })
        .await
        .unwrap();

    assert!(matches!(decision, PolicyDecision::Throttle { priority, .. } if priority < 0));
    assert!(
        matches!(decision, PolicyDecision::Throttle { reason, .. } if reason.contains("recent invalid responses"))
    );
}

#[test]
fn mesh_peer_policy_keeps_good_unknown_and_malicious_distinct() {
    let Fixture {
        graph,
        friend,
        unknown,
        overmuted,
    } = fixture();
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default());

    let good = policy
        .select_mesh_peer(&friend.public_key().to_bech32().unwrap())
        .unwrap()
        .expect("known-good peer remains eligible");
    let unknown = policy
        .select_mesh_peer(&unknown.public_key().to_bech32().unwrap())
        .unwrap()
        .expect("unknown peer remains eligible for exploration");
    let malicious = policy
        .select_mesh_peer(&overmuted.public_key().to_bech32().unwrap())
        .unwrap();

    assert!(good.quality_score.is_some_and(|score| score > 0));
    assert!(unknown.is_unknown());
    assert_eq!(malicious, None);
}

#[test]
fn global_behavior_reputation_can_classify_an_unknown_mesh_peer() {
    let Fixture { graph, unknown, .. } = fixture();
    let unknown_npub = unknown.public_key().to_bech32().unwrap();
    let reputation = Arc::new(InMemoryServiceReputation::default());
    reputation.throttle_source(&unknown_npub, None, -250, "repeated unanswered inventories");
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default())
        .with_service_reputation(reputation);

    let malicious = policy
        .select_mesh_peer(&unknown_npub)
        .unwrap()
        .expect("downranked peer stays available as a last resort");

    assert!(malicious.quality_score.is_some_and(|score| score < 0));
}

#[tokio::test]
async fn source_policy_uses_candidate_author_pubkey() {
    let Fixture {
        graph,
        friend,
        unknown,
        ..
    } = fixture();
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default());
    let candidate = SourceCandidate {
        source: EventSource::peer("candidate"),
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let trusted = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: Some(&friend.public_key().to_hex()),
            capabilities: &[],
        })
        .await
        .unwrap();
    let unknown = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: Some(&unknown.public_key().to_hex()),
            capabilities: &[],
        })
        .await
        .unwrap();

    assert!(matches!(trusted, PolicyDecision::Allow { .. }));
    assert!(matches!(unknown, PolicyDecision::Throttle { .. }));
}

#[tokio::test]
async fn source_policy_infers_fips_peer_npub_source_id_when_author_is_missing() {
    let Fixture { graph, friend, .. } = fixture();
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default());
    let friend_npub = friend.public_key().to_bech32().unwrap();
    let fips_candidate = SourceCandidate {
        source: EventSource {
            id: SourceId::new(friend_npub),
            kind: EventSourceKind::FipsEndpoint,
            url: None,
        },
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };
    let relay_candidate = SourceCandidate {
        source: EventSource::relay("wss://relay.example"),
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let trusted = policy
        .check_source(SourcePolicyContext {
            candidate: &fips_candidate,
            author_pubkey: None,
            capabilities: &[],
        })
        .await
        .unwrap();
    let relay = policy
        .check_source(SourcePolicyContext {
            candidate: &relay_candidate,
            author_pubkey: None,
            capabilities: &[],
        })
        .await
        .unwrap();

    assert!(matches!(trusted, PolicyDecision::Allow { priority } if priority > 0));
    assert_eq!(relay, PolicyDecision::Allow { priority: 0 });
}

#[tokio::test]
async fn source_policy_drops_overmuted_fips_peer_without_author_hint() {
    let Fixture {
        graph, overmuted, ..
    } = fixture();
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default());
    let candidate = SourceCandidate {
        source: EventSource {
            id: SourceId::new(overmuted.public_key().to_bech32().unwrap()),
            kind: EventSourceKind::FipsEndpoint,
            url: None,
        },
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let decision = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: None,
            capabilities: &[],
        })
        .await
        .unwrap();

    assert_eq!(
        decision,
        PolicyDecision::drop("author overmuted by social graph")
    );
}

#[tokio::test]
async fn routed_query_can_apply_graph_policy_to_peer_source_ids_without_author_hint() {
    let Fixture {
        graph,
        friend,
        unknown,
        ..
    } = fixture();
    let friend_id = friend.public_key().to_hex();
    let unknown_id = unknown.public_key().to_hex();
    let friend_bus = InMemoryEventBus::new();
    let unknown_bus = InMemoryEventBus::new();
    let friend_event = signed_text_note(&friend, "trusted peer route");
    let unknown_event = signed_text_note(&unknown, "unknown peer route");
    friend_bus
        .publish(friend_event.clone(), EventSource::peer(&friend_id))
        .await
        .unwrap();
    unknown_bus
        .publish(unknown_event.clone(), EventSource::peer(&unknown_id))
        .await
        .unwrap();
    let routes = vec![
        RouteQuerySource::new(SourceRoute::fips_peer(unknown_id, 100), &unknown_bus),
        RouteQuerySource::new(SourceRoute::fips_peer(friend_id, 0), &friend_bus),
    ];
    let policy = SocialGraphPolicy::new(graph, SocialGraphPolicyConfig::default());

    let report = query_routes_with_policy(
        &routes,
        vec![Filter::new().kind(Kind::TextNote)],
        RoutedQueryOptions {
            query: QueryOptions { limit: Some(1) },
        },
        None,
        &policy,
        None,
    )
    .await
    .unwrap();

    assert_eq!(report.events.len(), 1);
    assert_eq!(
        report.events[0].event.as_event().id,
        friend_event.as_event().id
    );
    assert_eq!(report.attempts.len(), 1);
    assert_eq!(report.attempts[0].route.id, friend.public_key().to_hex());
}

#[tokio::test]
async fn overmuted_authors_are_dropped_before_distance_checks() {
    let Fixture {
        graph, overmuted, ..
    } = fixture();
    let bus = InMemoryEventBus::with_policy(Arc::new(SocialGraphPolicy::new(
        graph,
        SocialGraphPolicyConfig::default(),
    )));

    let report = bus
        .publish(
            signed_text_note(&overmuted, "overmuted"),
            EventSource::peer("peer"),
        )
        .await
        .unwrap();

    assert!(!report.accepted);
    assert_eq!(
        report.reason.as_deref(),
        Some("author overmuted by social graph")
    );
}

#[tokio::test]
async fn root_mutelist_drops_event_authors_when_overmute_heuristic_is_disabled() {
    let RootMuteFixture { graph, bad_actor } = root_muted_fixture();
    let bus = InMemoryEventBus::with_policy(Arc::new(SocialGraphPolicy::new(
        graph,
        SocialGraphPolicyConfig {
            drop_overmuted: false,
            ..SocialGraphPolicyConfig::default()
        },
    )));

    let report = bus
        .publish(
            signed_text_note(&bad_actor, "root-muted"),
            EventSource::peer("peer"),
        )
        .await
        .unwrap();

    assert!(!report.accepted);
    assert_eq!(
        report.reason.as_deref(),
        Some("author muted by social graph root")
    );
}

#[tokio::test]
async fn root_mutelist_drops_fips_peer_sources_when_overmute_heuristic_is_disabled() {
    let RootMuteFixture { graph, bad_actor } = root_muted_fixture();
    let policy = SocialGraphPolicy::new(
        graph,
        SocialGraphPolicyConfig {
            drop_overmuted: false,
            ..SocialGraphPolicyConfig::default()
        },
    );
    let candidate = SourceCandidate {
        source: EventSource {
            id: SourceId::new(bad_actor.public_key().to_bech32().unwrap()),
            kind: EventSourceKind::FipsEndpoint,
            url: None,
        },
        priority: 0,
        reason: None,
        freshness_hint: None,
        health: SourceHealth::default(),
    };

    let decision = policy
        .check_source(SourcePolicyContext {
            candidate: &candidate,
            author_pubkey: None,
            capabilities: &[],
        })
        .await
        .unwrap();

    assert_eq!(
        decision,
        PolicyDecision::drop("author muted by social graph root")
    );
}

struct Fixture {
    graph: Arc<RwLock<SocialGraph>>,
    friend: Keys,
    unknown: Keys,
    overmuted: Keys,
}

struct RootMuteFixture {
    graph: Arc<RwLock<SocialGraph>>,
    bad_actor: Keys,
}

fn fixture() -> Fixture {
    let keys = graph_keys();
    let root_pk = keys.root.public_key().to_hex();
    let mut graph = SocialGraph::new(&root_pk);
    seed_graph(&mut graph, &keys).unwrap();

    Fixture {
        graph: Arc::new(RwLock::new(graph)),
        friend: keys.friend,
        unknown: keys.unknown,
        overmuted: keys.overmuted,
    }
}

fn root_muted_fixture() -> RootMuteFixture {
    let root = Keys::generate();
    let bad_actor = Keys::generate();
    let root_pk = root.public_key().to_hex();
    let bad_actor_pk = bad_actor.public_key().to_hex();
    let mut graph = SocialGraph::new(&root_pk);
    graph.handle_event(
        &follow_event(&root_pk, 1_000, vec![&bad_actor_pk]),
        true,
        1.0,
    );
    graph.handle_event(&mute_event(&root_pk, 1_001, vec![&bad_actor_pk]), true, 1.0);

    RootMuteFixture {
        graph: Arc::new(RwLock::new(graph)),
        bad_actor,
    }
}

struct GraphKeys {
    root: Keys,
    friend: Keys,
    friend_of_friend: Keys,
    muter: Keys,
    unknown: Keys,
    overmuted: Keys,
}

fn graph_keys() -> GraphKeys {
    let root = Keys::generate();
    let friend = Keys::generate();
    let friend_of_friend = Keys::generate();
    let muter = Keys::generate();
    let unknown = Keys::generate();
    let overmuted = Keys::generate();

    GraphKeys {
        root,
        friend,
        friend_of_friend,
        muter,
        unknown,
        overmuted,
    }
}

fn seed_graph<B>(graph: &mut B, keys: &GraphKeys) -> Result<(), B::Error>
where
    B: SocialGraphBackend,
{
    let root_pk = keys.root.public_key().to_hex();
    let friend_pk = keys.friend.public_key().to_hex();
    let friend_of_friend_pk = keys.friend_of_friend.public_key().to_hex();
    let muter_pk = keys.muter.public_key().to_hex();
    let overmuted_pk = keys.overmuted.public_key().to_hex();

    graph.handle_event(
        &follow_event(&root_pk, 1_000, vec![&friend_pk, &muter_pk]),
        true,
        1.0,
    )?;
    graph.handle_event(
        &follow_event(&friend_pk, 1_100, vec![&friend_of_friend_pk]),
        true,
        1.0,
    )?;
    graph.handle_event(
        &mute_event(&friend_pk, 1_200, vec![&overmuted_pk]),
        true,
        1.0,
    )?;
    graph.handle_event(
        &mute_event(&muter_pk, 1_201, vec![&overmuted_pk]),
        true,
        1.0,
    )?;
    Ok(())
}

fn signed_text_note(keys: &Keys, content: &str) -> VerifiedEvent {
    let event = EventBuilder::new(Kind::TextNote, content)
        .sign_with_keys(keys)
        .unwrap();
    VerifiedEvent::try_from(event).unwrap()
}

fn follow_event(pubkey: &str, created_at: u64, followed: Vec<&str>) -> NostrEvent {
    graph_event(pubkey, 3, created_at, followed)
}

fn mute_event(pubkey: &str, created_at: u64, muted: Vec<&str>) -> NostrEvent {
    graph_event(pubkey, 10_000, created_at, muted)
}

fn graph_event(pubkey: &str, kind: u32, created_at: u64, tagged: Vec<&str>) -> NostrEvent {
    NostrEvent {
        created_at,
        content: String::new(),
        tags: tagged
            .into_iter()
            .map(|pk| vec!["p".to_string(), pk.to_string()])
            .collect(),
        kind,
        pubkey: pubkey.to_string(),
        id: format!("{pubkey}:{kind}:{created_at}"),
        sig: "00".repeat(64),
    }
}
