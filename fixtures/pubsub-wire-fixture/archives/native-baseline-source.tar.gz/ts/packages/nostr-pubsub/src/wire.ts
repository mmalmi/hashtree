import type { NostrEvent, NostrFilter, NostrVerifiedEvent, SourceId } from './types.js';
import { PubsubError, verifyNostrEvent } from './types.js';
import {
  PubsubPeerSubscriptionStore,
  type PubsubPeerSubscription,
  type PubsubSubscriptionUpdate,
} from './subscription.js';

/** Maximum encoded Nostr frame carried in one reliable TCP record. */
export const FIPS_NOSTR_PUBSUB_MAX_FRAME_BYTES = 65_525;
export const DEFAULT_FIPS_PUBSUB_MAX_FRAME_BYTES = FIPS_NOSTR_PUBSUB_MAX_FRAME_BYTES;
export const FIPS_NOSTR_PUBSUB_SERVICE_PORT = 7368;

export type FipsPubsubWireMessage =
  | { type: 'req'; subscriptionId: string; filters: NostrFilter[] }
  | { type: 'sync'; action: 'open' | 'step' | 'reply' | 'end' | 'decline'; subscriptionId: string; payload: string }
  | { type: 'close'; subscriptionId: string }
  | { type: 'event'; event: NostrVerifiedEvent; subscriptionId?: string }
  | {
      type: 'inv';
      subscriptionIds: string[];
      eventId: string;
      eventKind: number;
      payloadBytes: number;
      hopLimit: number;
    }
  | { type: 'want'; eventId: string }
  | { type: 'ok'; eventId: string; accepted: boolean; message: string };

const frameEncoder = new TextEncoder();
const frameDecoder = new TextDecoder('utf-8', { fatal: true });

export class FipsPubsubWireCodec {
  readonly maxFrameBytes: number;

  constructor(maxFrameBytes = DEFAULT_FIPS_PUBSUB_MAX_FRAME_BYTES) {
    if (!Number.isSafeInteger(maxFrameBytes) || maxFrameBytes <= 0) {
      throw PubsubError.validation('FIPS pubsub max frame bytes must be a positive safe integer');
    }
    this.maxFrameBytes = maxFrameBytes;
  }

  encodeFrame(message: FipsPubsubWireMessage): Uint8Array {
    const wireMessage = encodeWireMessage(message);
    const frame = frameEncoder.encode(JSON.stringify(wireMessage));
    this.checkFrameSize(frame.byteLength);
    return frame;
  }

  decodeFrame(frame: Uint8Array): FipsPubsubWireMessage {
    this.checkFrameSize(frame.byteLength);
    if (frame.byteLength === 0) throw invalidFrame('frame is empty');

    let value: unknown;
    try {
      const json = frameDecoder.decode(frame);
      value = JSON.parse(json) as unknown;
    } catch (error) {
      throw invalidFrame(`invalid JSON: ${errorMessage(error)}`);
    }
    return decodeWireMessage(value);
  }

  private checkFrameSize(frameBytes: number): void {
    if (frameBytes > this.maxFrameBytes) {
      throw invalidFrame(`frame has ${frameBytes} bytes, limit is ${this.maxFrameBytes}`);
    }
  }
}

export interface FipsPubsubInbound {
  message: FipsPubsubWireMessage;
  subscriptionUpdate: PubsubSubscriptionUpdate;
}

export class FipsPubsubWireAdapter {
  constructor(
    readonly codec = new FipsPubsubWireCodec(),
    readonly subscriptions = new PubsubPeerSubscriptionStore(),
  ) {}

  /** Drop subscriptions retained for a transport peer that disconnected. */
  disconnectPeer(peerId: SourceId): PubsubPeerSubscription[] {
    return this.subscriptions.removePeer(peerId);
  }

  decodeInbound(peerId: SourceId, frame: Uint8Array): FipsPubsubInbound {
    return this.applyInbound(peerId, this.codec.decodeFrame(frame));
  }

  applyInbound(peerId: SourceId, message: FipsPubsubWireMessage): FipsPubsubInbound {
    let subscriptionUpdate: PubsubSubscriptionUpdate = 'ignored';
    if (message.type === 'req') {
      this.subscriptions.upsertFilters(peerId, message.subscriptionId, message.filters);
      subscriptionUpdate = 'subscribed';
    } else if (message.type === 'close') {
      this.subscriptions.remove(peerId, message.subscriptionId);
      subscriptionUpdate = 'closed';
    }
    return { message, subscriptionUpdate };
  }

  encodeOutbound(message: FipsPubsubWireMessage): Uint8Array {
    return this.codec.encodeFrame(message);
  }
}

function encodeWireMessage(message: FipsPubsubWireMessage): unknown[] {
  switch (message.type) {
    case 'req':
      if (message.filters.length === 0) {
        throw invalidFrame('REQ requires at least one filter');
      }
      return ['REQ', message.subscriptionId, ...message.filters.map(normalizeFilter)];
    case 'sync': {
      const frame = ['FEED-SYNC/1', message.action, message.subscriptionId, message.payload];
      decodeFeedSync(frame);
      return frame;
    }
    case 'close':
      return ['CLOSE', message.subscriptionId];
    case 'event': {
      const event = verifyNostrEvent(message.event);
      const wireEvent = {
        content: event.content,
        created_at: event.created_at,
        id: event.id,
        kind: event.kind,
        pubkey: event.pubkey,
        sig: event.sig,
        tags: event.tags,
      };
      return message.subscriptionId === undefined
        ? ['EVENT', wireEvent]
        : ['EVENT', message.subscriptionId, wireEvent];
    }
    case 'inv':
      validateInventory(message);
      return [
        'INV',
        message.subscriptionIds,
        message.eventId,
        message.eventKind,
        message.payloadBytes,
        message.hopLimit,
      ];
    case 'ok':
      validateEventId(message.eventId, 'OK');
      return ['OK', message.eventId, message.accepted, message.message];
    case 'want':
      validateEventId(message.eventId, 'WANT');
      return ['WANT', message.eventId];
  }
}

function decodeFeedSync(frame: unknown[]): Extract<FipsPubsubWireMessage, { type: 'sync' }> {
  const [, action, subscriptionId, payload] = frame;
  if (frame.length !== 4 || (action !== 'open' && action !== 'step' && action !== 'reply' && action !== 'end' && action !== 'decline') ||
    typeof subscriptionId !== 'string' || !/^wf1-ts-[0-9a-z]{1,12}$/.test(subscriptionId) || typeof payload !== 'string' ||
    (action === 'end' || action === 'decline' ? payload !== '' : (payload.length > 16_384 || !/^(?:[0-9a-f]{2})+$/.test(payload)))) {
    throw invalidFrame('Invalid public feed sync frame');
  }
  return { type: 'sync', action, subscriptionId, payload };
}

function decodeWireMessage(value: unknown): FipsPubsubWireMessage {
  if (!Array.isArray(value)) throw invalidFrame('message must be a JSON array');
  const [messageType] = value;
  if (typeof messageType !== 'string') throw invalidFrame('message type must be a string');

  if (messageType === 'FEED-SYNC/1') return decodeFeedSync(value);
  if (messageType === 'REQ') {
    if (value.length < 3 || typeof value[1] !== 'string') {
      throw invalidFrame('REQ requires an id and at least one filter');
    }
    return {
      type: 'req',
      subscriptionId: value[1],
      filters: value.slice(2).map(normalizeFilter),
    };
  }
  if (messageType === 'CLOSE') {
    if (value.length !== 2 || typeof value[1] !== 'string') {
      throw invalidFrame('CLOSE requires exactly an id');
    }
    return { type: 'close', subscriptionId: value[1] };
  }
  if (messageType === 'OK') {
    if (value.length !== 4 || typeof value[2] !== 'boolean' || typeof value[3] !== 'string') throw invalidFrame('OK requires event id, status and message');
    validateEventId(value[1], 'OK');
    return { type: 'ok', eventId: value[1] as string, accepted: value[2], message: value[3] };
  }
  if (messageType === 'EVENT') {
    if (value.length === 2) {
      return { type: 'event', event: verifyNostrEvent(value[1] as NostrEvent) };
    }
    if (value.length === 3 && typeof value[1] === 'string') {
      return {
        type: 'event',
        subscriptionId: value[1],
        event: verifyNostrEvent(value[2] as NostrEvent),
      };
    }
    throw invalidFrame('EVENT requires an event and optional subscription id');
  }
  if (messageType === 'INV') {
    if (value.length !== 6) {
      throw invalidFrame(
        'INV requires subscription ids, event id, kind, byte size, and hop limit',
      );
    }
    const [, subscriptionIds, eventId, eventKind, payloadBytes, hopLimit] = value;
    const message = {
      type: 'inv' as const,
      subscriptionIds,
      eventId,
      eventKind,
      payloadBytes,
      hopLimit,
    };
    validateInventory(message);
    return message;
  }
  if (messageType === 'WANT') {
    if (value.length !== 2 || typeof value[1] !== 'string') {
      throw invalidFrame('WANT requires exactly an event id');
    }
    validateEventId(value[1], 'WANT');
    return { type: 'want', eventId: value[1] };
  }
  throw invalidFrame(`unsupported Nostr message type ${messageType}`);
}

function validateInventory(message: {
  subscriptionIds: unknown;
  eventId: unknown;
  eventKind: unknown;
  payloadBytes: unknown;
  hopLimit: unknown;
}): asserts message is {
  subscriptionIds: string[];
  eventId: string;
  eventKind: number;
  payloadBytes: number;
  hopLimit: number;
} {
  if (
    !Array.isArray(message.subscriptionIds) ||
    message.subscriptionIds.length === 0 ||
    message.subscriptionIds.some((id) => typeof id !== 'string')
  ) {
    throw invalidFrame('INV requires at least one string subscription id');
  }
  if (new Set(message.subscriptionIds).size !== message.subscriptionIds.length) {
    throw invalidFrame('INV subscription ids must be unique');
  }
  validateEventId(message.eventId, 'INV');
  validateUnsigned(message.eventKind, 0xffff, 'INV event kind');
  validateUnsigned(message.payloadBytes, 0xffff_ffff, 'INV payload bytes');
  validateUnsigned(message.hopLimit, 0xff, 'INV hop limit');
  if (message.hopLimit === 0) throw invalidFrame('INV hop limit must be greater than zero');
}

function validateEventId(value: unknown, messageType: string): asserts value is string {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw invalidFrame(`${messageType} event id is invalid`);
  }
}

function validateUnsigned(value: unknown, maximum: number, field: string): asserts value is number {
  if (!Number.isSafeInteger(value) || (value as number) < 0 || (value as number) > maximum) {
    throw invalidFrame(`${field} must be an unsigned integer in range`);
  }
}

function normalizeFilter(value: unknown): NostrFilter {
  if (!isRecord(value)) throw invalidFrame('REQ filters must be JSON objects');
  const filter: NostrFilter = {};
  const knownKeys = new Set(['ids', 'authors', 'kinds', 'search', 'since', 'until', 'limit']);

  const tagKeys = Object.keys(value)
    .filter((key) => key.startsWith('#'))
    .sort();
  for (const key of tagKeys) {
    if (!/^#[A-Za-z]$/.test(key)) throw invalidFrame(`invalid generic filter tag ${key}`);
    filter[key as `#${string}`] = normalizeStringArray(value[key], key);
  }
  if ('ids' in value) filter.ids = normalizeHexArray(value.ids, 'ids');
  if ('authors' in value) filter.authors = normalizeHexArray(value.authors, 'authors');
  if ('kinds' in value) filter.kinds = normalizeIntegerArray(value.kinds, 'kinds');
  if ('search' in value) {
    if (typeof value.search !== 'string') throw invalidFrame('filter search must be a string');
    filter.search = value.search;
  }
  for (const key of ['since', 'until', 'limit'] as const) {
    if (!(key in value)) continue;
    const number = value[key];
    if (!isNonNegativeSafeInteger(number)) {
      throw invalidFrame(`filter ${key} must be a non-negative safe integer`);
    }
    filter[key] = number;
  }

  for (const key of Object.keys(value)) {
    if (!knownKeys.has(key) && !key.startsWith('#')) {
      throw invalidFrame(`unsupported filter field ${key}`);
    }
  }
  return Object.fromEntries(
    Object.entries(filter).sort(([left], [right]) => compareUtf8(left, right)),
  ) as NostrFilter;
}

function normalizeStringArray(value: unknown, field: string): string[] {
  if (!Array.isArray(value) || value.some((item) => typeof item !== 'string')) {
    throw invalidFrame(`filter ${field} must be a string array`);
  }
  return [...new Set(value as string[])].sort(compareUtf8);
}

function normalizeHexArray(value: unknown, field: string): string[] {
  const values = normalizeStringArray(value, field);
  if (values.some((item) => !/^[0-9a-f]{64}$/.test(item))) {
    throw invalidFrame(`filter ${field} must contain 64-character lowercase hex values`);
  }
  return values;
}

function normalizeIntegerArray(value: unknown, field: string): number[] {
  if (
    !Array.isArray(value) ||
    value.some(
      (item) => !isNonNegativeSafeInteger(item) || (field === 'kinds' && item > 65_535),
    )
  ) {
    throw invalidFrame(`filter ${field} must be a non-negative integer array`);
  }
  return [...new Set(value as number[])].sort((left, right) => left - right);
}

function isNonNegativeSafeInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function compareUtf8(left: string, right: string): number {
  const encoder = new TextEncoder();
  const leftBytes = encoder.encode(left);
  const rightBytes = encoder.encode(right);
  const sharedLength = Math.min(leftBytes.length, rightBytes.length);
  for (let index = 0; index < sharedLength; index += 1) {
    if (leftBytes[index] !== rightBytes[index]) return leftBytes[index] - rightBytes[index];
  }
  return leftBytes.length - rightBytes.length;
}

function invalidFrame(message: string): PubsubError {
  return PubsubError.validation(`invalid FIPS pubsub frame: ${message}`);
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
