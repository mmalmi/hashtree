import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const OTHER = 'npub1g53mukxnjkcmr94fhryzkqutdz2ukq4ks0gvy5af25rgmwsl4ngq43drvk';

async function load(hash: string) {
  vi.resetModules();
  vi.stubGlobal('window', { location: { hash } });
  const priority = await import('../src/lib/routeRootPriority');
  const { treeRootRegistry } = await import('@hashtree/worker/tree-root');
  return { ...priority, treeRootRegistry };
}

function settled(promise: Promise<void>): () => boolean {
  let done = false;
  void promise.then(() => { done = true; });
  return () => done;
}

describe('route root priority', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllGlobals();
  });

  it('does not hold back listings for owners the page is not showing', async () => {
    const { whenRoutePageSettled, whenRouteRootResolved } = await load(`#/${OWNER}/repo`);
    const root = settled(whenRouteRootResolved(OTHER));
    const page = settled(whenRoutePageSettled(OTHER));
    await vi.advanceTimersByTimeAsync(0);
    expect(root()).toBe(true);
    expect(page()).toBe(true);
  });

  it('waits for the open tree root, then for tracked content loads', async () => {
    const { markBackendReady, trackContentLoad, treeRootRegistry, whenRoutePageSettled, whenRouteRootResolved } = await load(`#/${OWNER}/repo`);
    markBackendReady();
    const root = settled(whenRouteRootResolved(OWNER));
    const page = settled(whenRoutePageSettled(OWNER));
    await vi.advanceTimersByTimeAsync(500);
    expect(root()).toBe(false);

    treeRootRegistry.setFromResolver(OWNER, 'repo', new Uint8Array(32).fill(1), 1, { visibility: 'public' });
    let finishLoad!: () => void;
    void trackContentLoad(new Promise<void>((resolve) => { finishLoad = resolve; }));
    await vi.advanceTimersByTimeAsync(1000);
    expect(root()).toBe(true);
    expect(page()).toBe(false);

    finishLoad();
    await vi.advanceTimersByTimeAsync(1000);
    expect(page()).toBe(true);
  });

  it('does not wait on a page that has already loaded', async () => {
    const { treeRootRegistry, whenRoutePageSettled } = await load(`#/${OWNER}/repo`);
    treeRootRegistry.setFromResolver(OWNER, 'repo', new Uint8Array(32).fill(1), 1, { visibility: 'public' });
    const page = settled(whenRoutePageSettled(OWNER));
    await vi.advanceTimersByTimeAsync(0);
    expect(page()).toBe(true);
  });

  it('starts the root timeout only once the backend is ready', async () => {
    // The registry outlives module reloads, so this test uses its own tree.
    const { markBackendReady, whenRouteRootResolved } = await load(`#/${OWNER}/unresolved-repo`);
    const root = settled(whenRouteRootResolved(OWNER));
    await vi.advanceTimersByTimeAsync(5000);
    expect(root()).toBe(false);
    markBackendReady();
    await vi.advanceTimersByTimeAsync(1500);
    expect(root()).toBe(false);
    await vi.advanceTimersByTimeAsync(1000);
    expect(root()).toBe(true);
  });

  it('gives up waiting after a bounded time', async () => {
    const { markBackendReady, trackContentLoad, whenRoutePageSettled } = await load(`#/${OWNER}/repo`);
    markBackendReady();
    void trackContentLoad(new Promise<void>(() => {}));
    const page = settled(whenRoutePageSettled(OWNER));
    await vi.advanceTimersByTimeAsync(2000);
    expect(page()).toBe(false);
    await vi.advanceTimersByTimeAsync(7000);
    expect(page()).toBe(true);
  });
});
