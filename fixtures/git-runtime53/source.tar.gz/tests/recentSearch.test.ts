import { beforeEach, expect, it, vi } from 'vitest';
import { getRecentHistory, historyProvider } from '../src/lib/search/historyProvider';
import { getRecentsSync } from '../src/stores/recents';

vi.mock('../src/stores/recents', () => ({ getRecentsSync: vi.fn() }));

beforeEach(() => {
  vi.mocked(getRecentsSync).mockReturnValue([
    { type: 'tree', label: 'Garden plans', path: '/owner/garden', timestamp: 5 },
    { type: 'tree', label: 'Old Budget Plans', path: '/owner/archive', timestamp: 4 },
    { type: 'file', label: 'Budget.md', path: '/owner/plans/Budget.md', timestamp: 3 },
    { type: 'tree', label: 'Budget Plans', path: '/owner/budget', timestamp: 2 },
    { type: 'tree', label: '2026', path: '/owner/2026', timestamp: 1 },
  ]);
});

it('ranks matching titles before partial paths and requires every search term', async () => {
  const results = await historyProvider.search('Budget plans', 10);
  expect(results.map((result) => result.label)).toEqual([
    'Budget Plans', 'Old Budget Plans', 'Budget.md',
  ]);
  expect((await historyProvider.search('plans budget', 1))[0]?.label).toBe('Old Budget Plans');
  expect((await historyProvider.search('2026', 1))[0]?.label).toBe('2026');
  expect((await getRecentHistory(1))[0]?.label).toBe('Garden plans');
});

it('reopens a recent file with its encoded tree name, file path and link key', async () => {
  vi.mocked(getRecentsSync).mockReturnValue([{
    type: 'file',
    label: 'Budget #1?.md',
    path: '/owner/plans/2026/notes/Budget #1?.md',
    treeName: 'plans/2026',
    npub: 'owner',
    linkKey: 'test-key',
    timestamp: 1,
  }]);
  const path = '/owner/plans%2F2026/notes/Budget%20%231%3F.md?k=test-key';
  expect((await historyProvider.search('budget', 1))[0]?.path).toBe(path);
  expect((await getRecentHistory(1))[0]?.path).toBe(path);
});
