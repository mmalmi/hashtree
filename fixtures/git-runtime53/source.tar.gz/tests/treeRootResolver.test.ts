import { expect, it, vi } from 'vitest';
import { treeRootRegistry } from '@hashtree/worker/tree-root';
import { updateSubscriptionCache } from '../src/stores/treeRootResolver';
import { subscriptionState } from '../src/stores/treeRootShared';
import { syncNativeTreeRootCache } from '../src/lib/nativeTreeRootCache';

vi.mock('../src/nostr', () => ({nostrStore: {}}));
vi.mock('../src/refResolver', () => ({}));
vi.mock('../src/stores/route', () => ({routeStore: {}}));
vi.mock('../src/stores/treeRootWorker', () => ({}));
vi.mock('../src/lib/nativeTreeRootCache', () => ({syncNativeTreeRootCache: vi.fn(async () => true)}));

it('keeps a dirty local root visible when a prior root arrives from a subscription', () => {
  const owner = 'test-owner';
  const name = 'project';
  const key = owner + '/' + name;
  const local = new Uint8Array(32).fill(1);
  const stale = new Uint8Array(32).fill(2);
  const notify = vi.fn();
  treeRootRegistry.setLocal(owner, name, local);
  subscriptionState.set(key, {decryptedKey: undefined, listeners: new Set([notify]),
    unsubscribeResolver: null, unsubscribeWorker: null, workerHydrateRetryTimer: null});
  try {
    updateSubscriptionCache(key, stale, undefined, {updatedAt: 1});
    expect(treeRootRegistry.getByKey(key)?.hash).toEqual(local);
    expect(notify).not.toHaveBeenCalled();
    expect(syncNativeTreeRootCache).not.toHaveBeenCalled();
    updateSubscriptionCache(key, local);
    expect(notify).toHaveBeenCalledWith(local, undefined, expect.anything(), expect.anything());
  } finally {
    treeRootRegistry.cancelPendingPublish(owner, name);
    treeRootRegistry.delete(owner, name);
    subscriptionState.delete(key);
  }
});
