import { fileURLToPath } from 'node:url';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createPublishPlan } from '../scripts/publish-iris-build.mjs';

const gate = fileURLToPath(import.meta.url);
beforeEach(() => {
  vi.stubEnv('IRIS_NATIVE_RELEASE_GATE', gate);
  vi.stubEnv('HTREE_BIN', 'htree');
});
afterEach(() => vi.unstubAllEnvs());

describe('publish-iris-build', () => {
  it('supports the git portable publish plan', () => {
    expect(createPublishPlan('git')).toMatchObject({
      name: 'git', appName: 'Iris Git', distDir: 'iris-git', treeName: 'git',
    });
  });

  it('verifies the selected directory and tree through the native release gate', () => {
    const plan = createPublishPlan('git');
    expect(plan.command).toEqual([
      process.execPath, gate, '--dist', plan.distPath, '--tree', 'git', '--htree', 'htree',
    ]);
    expect(plan.distPath).toMatch(/iris-git$/);
  });
});
