import { describe, expect, it } from 'vitest';
import {
  canHighlightCode,
  getCodeLanguage,
  MAX_HIGHLIGHT_CHARS,
  MAX_HIGHLIGHT_LINE_LENGTH,
  MAX_HIGHLIGHT_LINES,
  splitBalancedHtmlLines,
} from '../src/utils/codeHighlight';

describe('codeHighlight', () => {
  it('disables Prism automatic DOM highlighting before Prism is lazy-loaded', () => {
    expect((globalThis as { Prism?: { manual?: boolean } }).Prism?.manual).toBe(true);
  });

  it('detects common language extensions and special filenames', () => {
    expect(getCodeLanguage('main.rs')).toBe('rust');
    expect(getCodeLanguage('App.svelte')).toBe('markup');
    expect(getCodeLanguage('Dockerfile.prod')).toBe('docker');
    expect(getCodeLanguage('Makefile')).toBe('clike');
  });

  it('skips syntax highlighting for huge, too-many-line, or minified files', () => {
    expect(canHighlightCode('const x = 1;\n')).toBe(true);
    expect(canHighlightCode('')).toBe(false);
    expect(canHighlightCode('a'.repeat(MAX_HIGHLIGHT_CHARS + 1))).toBe(false);
    expect(canHighlightCode('a'.repeat(MAX_HIGHLIGHT_LINE_LENGTH + 1))).toBe(false);
    expect(canHighlightCode('x\n'.repeat(MAX_HIGHLIGHT_LINES))).toBe(false);
  });

  it('closes and reopens multi-line Prism spans across line breaks', () => {
    const html = '<span class="token comment">/* line 1\n * line 2\n */</span>\nconst x = 1;';
    expect(splitBalancedHtmlLines(html)).toEqual([
      '<span class="token comment">/* line 1</span>',
      '<span class="token comment"> * line 2</span>',
      '<span class="token comment"> */</span>',
      'const x = 1;',
    ]);
  });

  it('preserves nested spans across line breaks', () => {
    const html = '<span class="token template-string"><span class="token string">`a\nb`</span></span>';
    expect(splitBalancedHtmlLines(html)).toEqual([
      '<span class="token template-string"><span class="token string">`a</span></span>',
      '<span class="token template-string"><span class="token string">b`</span></span>',
    ]);
  });
});
