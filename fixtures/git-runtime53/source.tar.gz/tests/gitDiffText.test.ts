import { describe, expect, it } from 'vitest';
import { buildUnifiedDiff, colorizeDiffHtml } from '../src/utils/gitDiffText';
import { canHighlightCode, getCodeLanguage, splitBalancedHtmlLines } from '../src/utils/codeHighlight';

describe('buildUnifiedDiff', () => {
  it('renders added files as unified diffs with stats', () => {
    const result = buildUnifiedDiff([
      {
        path: 'README.md',
        status: 'added',
        newText: 'hello\nworld\n',
      },
    ]);

    expect(result.text).toContain('diff --git a/README.md b/README.md');
    expect(result.text).toContain('new file mode 100644');
    expect(result.text).toContain('@@ -0,0 +1,2 @@');
    expect(result.text).toContain('+hello');
    expect(result.text).toContain('+world');
    expect(result.stats).toEqual({ additions: 2, deletions: 0, files: 1 });
  });

  it('renders modified files as unified diffs with stats', () => {
    const result = buildUnifiedDiff([
      {
        path: 'src/app.ts',
        status: 'modified',
        oldText: 'one\ntwo\nthree\n',
        newText: 'one\nTWO\nthree\nfour\n',
      },
    ]);

    expect(result.text).toContain('diff --git a/src/app.ts b/src/app.ts');
    expect(result.text).toContain('@@ -1,3 +1,4 @@');
    expect(result.text).toContain('-two');
    expect(result.text).toContain('+TWO');
    expect(result.text).toContain('+four');
    expect(result.stats).toEqual({ additions: 2, deletions: 1, files: 1 });
  });

  it('limits modified diffs to hunks around changed lines', () => {
    const oldText = Array.from({ length: 12 }, (_, index) => `line ${index + 1}`).join('\n') + '\n';
    const newLines = Array.from({ length: 12 }, (_, index) => `line ${index + 1}`);
    newLines[1] = 'LINE 2';
    newLines[9] = 'LINE 10';
    const newText = newLines.join('\n') + '\n';

    const result = buildUnifiedDiff([
      {
        path: 'src/chunked.ts',
        status: 'modified',
        oldText,
        newText,
      },
    ]);

    expect(result.text).toContain('@@ -1,5 +1,5 @@');
    expect(result.text).toContain('@@ -7,6 +7,6 @@');
    expect(result.text).toContain('-line 2');
    expect(result.text).toContain('+LINE 2');
    expect(result.text).toContain('-line 10');
    expect(result.text).toContain('+LINE 10');
    expect(result.text).not.toContain('\n line 6\n');
    expect(result.stats).toEqual({ additions: 2, deletions: 2, files: 1 });
  });

  it('renders deleted files as unified diffs with stats', () => {
    const result = buildUnifiedDiff([
      {
        path: 'docs/old.md',
        status: 'deleted',
        oldText: 'legacy\ncopy\n',
      },
    ]);

    expect(result.text).toContain('diff --git a/docs/old.md b/docs/old.md');
    expect(result.text).toContain('deleted file mode 100644');
    expect(result.text).toContain('@@ -1,2 +0,0 @@');
    expect(result.text).toContain('-legacy');
    expect(result.text).toContain('-copy');
    expect(result.stats).toEqual({ additions: 0, deletions: 2, files: 1 });
  });

  it('falls back to a binary notice for non-text changes', () => {
    const result = buildUnifiedDiff([
      {
        path: 'image.png',
        status: 'modified',
        oldBytes: new Uint8Array([0, 255, 1, 2]),
        newBytes: new Uint8Array([0, 255, 1, 3]),
      },
    ]);

    expect(result.text).toContain('diff --git a/image.png b/image.png');
    expect(result.text).toContain('Binary files a/image.png and b/image.png differ');
    expect(result.stats).toEqual({ additions: 0, deletions: 0, files: 1 });
  });

  it('keeps mode metadata alongside content changes', () => {
    const result = buildUnifiedDiff([{ path: 'run', status: 'modified', oldMode: '100644', newMode: '100755', oldText: 'before\n', newText: 'after\n' }]);
    expect(result.text).toContain('old mode 100644\nnew mode 100755\n--- a/run\n+++ b/run');
    expect(result.stats).toEqual({ additions: 1, deletions: 1, files: 1 });
    expect(colorizeDiffHtml(result.text)).toContain('<span class="text-text-3">old mode 100644</span>');
  });

  it('renders a mode-only binary change without claiming the content changed', () => {
    const bytes = new Uint8Array([0, 255]);
    const result = buildUnifiedDiff([{ path: 'run', status: 'modified', oldMode: '100644', newMode: '100755', oldBytes: bytes, newBytes: bytes.slice() }]);
    expect(result.text).toBe('diff --git a/run b/run\nold mode 100644\nnew mode 100755');
    expect(result.stats).toEqual({ additions: 0, deletions: 0, files: 1 });
  });

  for (const status of ['added', 'deleted'] as const) {
    it(`keeps executable modes for ${status} binary files`, () => {
      const result = buildUnifiedDiff([{ path: 'run', status, oldMode: '100755', newMode: '100755' }]);
      expect(result.text).toContain(`${status === 'added' ? 'new' : 'deleted'} file mode 100755`);
      expect(result.text).toContain('Binary files');
    });
  }

  it('computes minimal hunks for scattered edits in large files beyond the old LCS cap', () => {
    const oldLines = Array.from({ length: 2800 }, (_, i) => `export const line_${i} = ${i};`);
    const newLines = [...oldLines];
    newLines[15] = 'export const line_15 = 1500;';
    newLines[2785] = 'export const line_2785 = 278500;';

    const result = buildUnifiedDiff([
      {
        path: 'src/large.ts',
        status: 'modified',
        oldText: oldLines.join('\n') + '\n',
        newText: newLines.join('\n') + '\n',
      },
    ]);

    expect(result.stats).toEqual({ additions: 2, deletions: 2, files: 1 });
    expect(result.text).toContain('@@ -13,7 +13,7 @@');
    expect(result.text).toContain('@@ -2783,7 +2783,7 @@');
    expect(result.text).not.toContain('line_1000');
  });

  it('escapes HTML and colorizes unified diff lines', () => {
    const html = colorizeDiffHtml([
      'diff --git a/a.ts b/a.ts',
      '@@ -1,2 +1,2 @@',
      '-const x = "<old>";',
      '+const x = "<new>";',
      ' unchanged & safe',
    ].join('\n'));

    expect(html).toContain('<span class="text-text-3">diff --git a/a.ts b/a.ts</span>');
    expect(html).toContain('<span class="text-accent">@@ -1,2 +1,2 @@</span>');
    expect(html).toContain('<span class="text-error">-const x = "&lt;old&gt;";</span>');
    expect(html).toContain('<span class="text-success">+const x = "&lt;new&gt;";</span>');
    expect(html).toContain(' unchanged &amp; safe');
  });
});

describe('code highlight helpers', () => {
  it('balances multi-line Prism span tags across newlines', () => {
    const html = '<span class="token comment">/* line 1\n * line 2\n */</span>\n<span class="token keyword">const</span> x = 1;';
    expect(splitBalancedHtmlLines(html)).toEqual([
      '<span class="token comment">/* line 1</span>',
      '<span class="token comment"> * line 2</span>',
      '<span class="token comment"> */</span>',
      '<span class="token keyword">const</span> x = 1;',
    ]);
  });

  it('skips syntax highlighting for oversized or minified files', () => {
    expect(canHighlightCode('const ok = 1;\n')).toBe(true);
    expect(canHighlightCode('a'.repeat(5000))).toBe(false);
    expect(canHighlightCode('x\n'.repeat(3500))).toBe(false);
    expect(getCodeLanguage('Dockerfile.prod')).toBe('docker');
    expect(getCodeLanguage('index.ts')).toBe('typescript');
  });
});
