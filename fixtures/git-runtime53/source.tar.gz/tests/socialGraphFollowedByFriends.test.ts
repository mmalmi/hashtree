import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const state = vi.hoisted(() => ({ adapter: null as Record<string, unknown> | null }));

vi.mock('../src/workerAdapter', () => ({ getWorkerAdapter: () => state.adapter }));
vi.mock('../src/nostr/store', () => ({
  nostrStore: { getState: () => ({ pubkey: '0'.repeat(64) }) },
}));

const TARGET = '1'.repeat(64);
const FRIEND = '2'.repeat(64);
const OTHER_FRIEND = '3'.repeat(64);
const STRANGER = '4'.repeat(64);

type GraphModule = typeof import('../src/utils/socialGraph');
let api: GraphModule;
let followers: string[];
let friends: () => Promise<string[]>;
let notifyGraphVersion: (version: number) => void;

async function settle() {
  await vi.advanceTimersByTimeAsync(150);
}

/** What the profile line ends up showing: components re-read on every graph version change. */
async function shown(): Promise<Set<string>> {
  let version = -1;
  while (version !== api.socialGraphStore.getState().version) {
    version = api.socialGraphStore.getState().version;
    api.getFollowedByFriends(TARGET);
    await settle();
  }
  return api.getFollowedByFriends(TARGET);
}

beforeEach(async () => {
  vi.resetModules();
  vi.useFakeTimers();
  followers = [FRIEND, STRANGER];
  friends = async () => [FRIEND];
  state.adapter = {
    onSocialGraphVersion: (callback: (version: number) => void) => { notifyGraphVersion = callback; },
    getFollowers: vi.fn(async () => followers),
    getFollowedByFriends: vi.fn(() => friends()),
    fetchUserFollows: vi.fn(),
    fetchUserFollowers: vi.fn(),
  };
  api = await import('../src/utils/socialGraph');
  api.setupVersionCallback();
});

afterEach(() => {
  vi.clearAllTimers();
  vi.useRealTimers();
});

describe('followed by friends', () => {
  it('lists the viewer\'s follows, not every known follower', async () => {
    api.getFollowers(TARGET);
    await settle();
    expect(api.getFollowers(TARGET)).toEqual(new Set([FRIEND, STRANGER]));

    api.getFollowedByFriends(TARGET);
    await settle();
    expect(api.getFollowedByFriends(TARGET)).toEqual(new Set([FRIEND]));
    expect(api.getFollowers(TARGET)).toEqual(new Set([FRIEND, STRANGER]));
  });

  it('stays empty when the worker cannot answer, whatever the followers list holds', async () => {
    friends = async () => { throw new Error('socialGraph.getFollowedByFriends is not a function'); };
    api.getFollowers(TARGET);
    await settle();

    api.getFollowedByFriends(TARGET);
    await settle();
    expect(api.getFollowedByFriends(TARGET)).toEqual(new Set());
  });

  it('asks again for an open profile when the graph has grown', async () => {
    api.fetchUserFollowers(TARGET);
    notifyGraphVersion(1);
    expect(await shown()).toEqual(new Set([FRIEND]));

    friends = async () => [FRIEND, OTHER_FRIEND];
    notifyGraphVersion(api.socialGraphStore.getState().version + 1);
    expect(await shown()).toEqual(new Set([FRIEND, OTHER_FRIEND]));

    // Settled: an unchanged graph is not asked again.
    const ask = state.adapter!.getFollowedByFriends as ReturnType<typeof vi.fn>;
    const asked = ask.mock.calls.length;
    await shown();
    expect(ask.mock.calls.length).toBe(asked);
  });
});
