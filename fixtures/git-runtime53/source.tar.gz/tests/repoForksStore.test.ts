import { beforeEach, describe, expect, it, vi } from 'vitest';

const announcement = {
  id: '1'.repeat(64),
  address: `30617:${'a'.repeat(64)}:alpha`,
  ownerPubkey: 'a'.repeat(64),
  ownerNpub: 'npub1owner',
  repoName: 'alpha',
  createdAt: 1,
  description: '',
  cloneUrls: ['htree://npub1owner/alpha'],
  webUrls: [],
  earliestUniqueCommit: 'euc-1',
  isPersonalFork: false,
  forkedFrom: null,
};

const shared = vi.hoisted(() => {
  const stopSource = vi.fn();
  const stopForks = vi.fn();
  const sourceListeners: Array<(value: unknown) => void> = [];
  const watchRepoAnnouncement = vi.fn((_npub: string, _repo: string, onChange: (value: unknown) => void) => {
    sourceListeners.push(onChange);
    return stopSource;
  });
  const watchEvents = vi.fn(() => stopForks);

  return {
    stopSource,
    stopForks,
    sourceListeners,
    watchRepoAnnouncement,
    watchEvents,
    reset() {
      stopSource.mockReset();
      stopForks.mockReset();
      sourceListeners.length = 0;
      watchRepoAnnouncement.mockClear();
      watchEvents.mockClear();
    },
  };
});

vi.mock('../src/lib/nostrLive', () => ({
  watchEvents: shared.watchEvents,
}));

vi.mock('../src/nip34', () => ({
  buildRepoAddress: (_ownerNpub: string, repoName: string) => `30617:${'a'.repeat(64)}:${repoName}`,
  watchRepoAnnouncement: shared.watchRepoAnnouncement,
}));

describe('repo fork store subscription lifecycle', () => {
  beforeEach(() => {
    vi.resetModules();
    shared.reset();
  });

  it('shows a count before any relay answers and starts watching forks when the announcement arrives', async () => {
    const { createRepoForkStatsStore } = await import('../src/stores/repoForks');
    const store = createRepoForkStatsStore('npub1owner', 'alpha');
    let stats: { count: number; earliestUniqueCommit: string | null } | undefined;
    const unsubscribe = store.subscribe((value) => { stats = value; });

    expect(stats).toMatchObject({ count: 0, earliestUniqueCommit: null });
    expect(shared.watchEvents).not.toHaveBeenCalled();

    shared.sourceListeners[0](announcement);
    expect(stats).toMatchObject({ count: 0, earliestUniqueCommit: 'euc-1' });
    expect(shared.watchEvents).toHaveBeenCalledTimes(1);
    expect(shared.watchEvents.mock.calls[0][0]).toMatchObject({ '#r': ['euc-1'] });

    unsubscribe();
    store.destroy();
  });

  it('shares one live subscription and replaces it after the last store is destroyed', async () => {
    const { createRepoForkStatsStore } = await import('../src/stores/repoForks');
    const first = createRepoForkStatsStore('npub1owner', 'alpha');
    const second = createRepoForkStatsStore('npub1owner', 'alpha');

    expect(shared.watchRepoAnnouncement).toHaveBeenCalledTimes(1);
    shared.sourceListeners[0](announcement);
    expect(shared.watchEvents).toHaveBeenCalledTimes(1);

    first.destroy();
    expect(shared.stopSource).not.toHaveBeenCalled();
    expect(shared.stopForks).not.toHaveBeenCalled();

    second.destroy();
    expect(shared.stopSource).toHaveBeenCalledTimes(1);
    expect(shared.stopForks).toHaveBeenCalledTimes(1);

    // The announcement seen earlier is enough to watch forks again at once.
    const replacement = createRepoForkStatsStore('npub1owner', 'alpha');
    expect(shared.watchRepoAnnouncement).toHaveBeenCalledTimes(2);
    expect(shared.watchEvents).toHaveBeenCalledTimes(2);
    replacement.destroy();
    expect(shared.stopSource).toHaveBeenCalledTimes(2);
    expect(shared.stopForks).toHaveBeenCalledTimes(2);
  });

  it('does not watch forks for an announcement arriving after its only store was destroyed', async () => {
    const { createRepoForkStatsStore } = await import('../src/stores/repoForks');
    const store = createRepoForkStatsStore('npub1owner', 'alpha');
    store.destroy();
    shared.sourceListeners[0](announcement);

    expect(shared.watchEvents).not.toHaveBeenCalled();
  });
});
