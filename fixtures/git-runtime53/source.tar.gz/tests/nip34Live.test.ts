import { beforeEach, describe, expect, it, vi } from 'vitest';
import { finalizeEvent, getPublicKey, nip19, type Event, type Filter } from 'nostr-tools';

type Request = { filters: Filter[]; handlers: Record<string, (value?: unknown) => void>; stopped: boolean };
const fixture = vi.hoisted(() => ({
  requests: [] as Request[],
  publish: vi.fn(),
}));
vi.mock('../src/nostr', () => ({
  nostr: {
    signer: {},
    publish: fixture.publish,
    subscribe: (filters: Filter[]) => {
      const request: Request = { filters, handlers: {}, stopped: false };
      fixture.requests.push(request);
      return {
        on: (name: string, handler: (value?: unknown) => void) => { request.handlers[name] = handler; },
        stop: () => { request.stopped = true; },
      };
    },
  },
  nostrStore: { getState: () => ({}) },
  pubkeyToNpub: (pubkey: string) => nip19.npubEncode(pubkey),
  npubToPubkey: (npub: string) => nip19.decode(npub).data,
}));
vi.mock('../src/lib/workerInit', () => ({ getWorkerAdapter: () => null, waitForWorkerAdapter: async () => null }));
vi.mock('@hashtree/worker/tree-root', () => ({ treeRootRegistry: { get: () => undefined } }));

import { publishInBackground, registerEventSource, registerPublishTarget } from '../src/lib/nostrLive';
import { buildRepoAddress, watchRepoItems, watchThread, type Issue, type LiveItems, type LiveThread } from '../src/nip34';

const ownerSecret = new Uint8Array(32).fill(1);
const guestSecret = new Uint8Array(32).fill(2);
const owner = getPublicKey(ownerSecret);
const npub = nip19.npubEncode(owner);
const address = buildRepoAddress(npub, 'repo');
const issue = (title: string, created_at: number, secret = guestSecret): Event => finalizeEvent({
  kind: 1621, created_at, content: '', tags: [['a', address], ['subject', title]],
}, secret);
const status = (kind: number, target: Event, created_at: number, secret = ownerSecret): Event => finalizeEvent({
  kind, created_at, content: '', tags: [['e', target.id]],
}, secret);
const comment = (target: Event, content: string, created_at: number): Event => finalizeEvent({
  kind: 1, created_at, content, tags: [['e', target.id, '', 'root'], ['a', address]],
}, guestSecret);
const requestFor = (match: (filter: Filter) => boolean) => fixture.requests.find(r => !r.stopped && match(r.filters[0]))!;
const tick = () => new Promise(resolve => setTimeout(resolve, 0));
const titles = (state: LiveItems<Issue>) => state.items.map(item => `${item.title}:${item.status}`);

beforeEach(() => {
  fixture.requests.length = 0;
  fixture.publish.mockReset();
  fixture.publish.mockResolvedValue({ accepted: true, queued: false });
});

describe('live issue and pull request lists', () => {
  it('shows each item as it arrives, in an order which does not jump, and "empty" only after history', async () => {
    const states: LiveItems<Issue>[] = [];
    const stop = watchRepoItems<Issue>(npub, 'repo', 1621, state => states.push(state));
    const list = requestFor(filter => filter.kinds?.[0] === 1621);
    expect(list.filters[0]).toMatchObject({ kinds: [1621], '#a': [address] });

    const first = issue('first', 10);
    list.handlers.event(first);
    await tick();
    expect(titles(states.at(-1)!)).toEqual(['first:open']);
    expect(states.at(-1)!.historyDone).toBe(false);

    list.handlers.event(issue('newest', 30));
    list.handlers.event(issue('middle', 20));
    await tick();
    expect(titles(states.at(-1)!)).toEqual(['newest:open', 'middle:open', 'first:open']);

    // Statuses are asked for as items arrive and apply the moment they do.
    await vi.waitFor(() => expect(requestFor(filter => filter['#e']?.includes(first.id) ?? false)).toBeDefined());
    const statuses = requestFor(filter => filter['#e']?.includes(first.id) ?? false);
    statuses.handlers.event(status(1632, first, 12, guestSecret)); // not the owner
    await tick();
    expect(titles(states.at(-1)!)).toContain('first:open');
    statuses.handlers.event(status(1632, first, 12));
    statuses.handlers.event(status(1630, first, 11)); // older: does not reopen
    await tick();
    expect(titles(states.at(-1)!)).toEqual(['newest:open', 'middle:open', 'first:closed']);

    list.handlers.history({ complete: false, reason: 'timeout' });
    await tick();
    expect(states.at(-1)!.historyDone).toBe(true);

    stop();
    expect(fixture.requests.every(request => request.stopped)).toBe(true);
  });

  it('shows something written here at once, without waiting for any relay, and removes it if it cannot be handed over', async () => {
    let fail!: (error: Error) => void;
    fixture.publish.mockReturnValue(new Promise((_resolve, reject) => { fail = reject; }));
    const logged = vi.spyOn(console, 'error').mockImplementation(() => {});
    const states: LiveItems<Issue>[] = [];
    const stop = watchRepoItems<Issue>(npub, 'repo', 1621, state => states.push(state));
    const failed = vi.fn();

    publishInBackground(issue('mine', 40), failed);
    await tick();
    expect(titles(states.at(-1)!)).toEqual(['mine:open']);
    expect(failed).not.toHaveBeenCalled();

    fail(new Error('storage unavailable'));
    await tick();
    expect(failed).toHaveBeenCalledOnce();
    expect(titles(states.at(-1)!)).toEqual([]);
    stop();
    logged.mockRestore();
  });

  it('shows something written before the list was opened', async () => {
    const mine = issue('earlier', 50);
    publishInBackground(mine);
    const states: LiveItems<Issue>[] = [];
    const stop = watchRepoItems<Issue>(npub, 'repo', 1621, state => states.push(state));
    await tick();
    expect(titles(states.at(-1)!)).toEqual(['earlier:open']);
    stop();
  });
});

describe('live issue page', () => {
  it('shows the issue, its status and comments as they arrive and "not found" only after history', async () => {
    const target = issue('subject', 10);
    const states: LiveThread<Issue>[] = [];
    const watch = watchThread<Issue>(target.id, 1621, owner, state => states.push(state));
    const item = requestFor(filter => filter.ids?.[0] === target.id);
    const comments = requestFor(filter => filter.kinds?.[0] === 1);
    const statuses = requestFor(filter => filter.kinds?.includes(1632) ?? false);

    comments.handlers.event(comment(target, 'second', 30));
    await tick();
    expect(states.at(-1)).toMatchObject({ item: null, historyDone: false });

    item.handlers.event(target);
    comments.handlers.event(comment(target, 'first', 20));
    statuses.handlers.event(status(1632, target, 15));
    await tick();
    expect(states.at(-1)!.item).toMatchObject({ title: 'subject', status: 'closed' });
    expect(states.at(-1)!.comments.map(each => each.content)).toEqual(['first', 'second']);

    // A choice made here shows at once and gives way to a newer status.
    watch.setLocalStatus('open');
    await tick();
    expect(states.at(-1)!.item?.status).toBe('open');
    watch.stop();
  });

  it('reports a missing issue only once history has ended', async () => {
    const states: LiveThread<Issue>[] = [];
    const watch = watchThread<Issue>('f'.repeat(64), 1621, owner, state => states.push(state));
    await tick();
    expect(states).toEqual([]);
    requestFor(filter => filter.ids?.[0] === 'f'.repeat(64)).handlers.history({ complete: true, reason: 'eose' });
    await tick();
    expect(states.at(-1)).toMatchObject({ item: null, historyDone: true });
    watch.stop();
  });
});

describe('extra event sources', () => {
  it('adds matching events from a registered source and stops it with the watch', async () => {
    const seenFilters: Filter[][] = [];
    let stopped = 0;
    const unregister = registerEventSource((filters, deliver) => {
      seenFilters.push(filters);
      deliver(issue('from repo relay', 50));
      deliver(finalizeEvent({ kind: 1, created_at: 51, content: 'unrelated', tags: [] }, guestSecret));
      return () => { stopped++; };
    });
    const states: LiveItems<Issue>[] = [];
    const stopWatch = watchRepoItems<Issue>(npub, 'repo', 1621, state => states.push(state));
    await tick();
    expect(seenFilters[0]).toEqual([{ kinds: [1621], '#a': [address] }]);
    // Earlier tests' local writes may also be listed.
    expect(states.at(-1)!.items.map(each => each.title)).toContain('from repo relay');
    stopWatch();
    expect(stopped).toBeGreaterThan(0);
    unregister();
  });
});

describe('late event sources', () => {
  it('also read for watches that were already open', async () => {
    const states: LiveItems<Issue>[] = [];
    const stopWatch = watchRepoItems<Issue>(npub, 'repo', 1621, state => states.push(state));
    await tick();
    const unregister = registerEventSource((_filters, deliver) => {
      deliver(issue('arrived late', 60));
      return () => {};
    });
    await tick();
    expect(states.at(-1)!.items.map(each => each.title)).toContain('arrived late');
    stopWatch();
    unregister();
  });
});

describe('NIP-22 replies and extra publish targets', () => {
  it('shows NIP-22 comments next to kind 1 replies', async () => {
    const target = issue('nip22', 70);
    const states: LiveThread<Issue>[] = [];
    const watch = watchThread<Issue>(target.id, 1621, owner, state => states.push(state));
    const comments = requestFor(filter => filter.kinds?.[0] === 1);
    expect(comments.filters).toEqual([
      { kinds: [1], '#e': [target.id] },
      { kinds: [1111], '#E': [target.id] },
    ]);
    const nip22 = finalizeEvent({
      kind: 1111, created_at: 80, content: 'from ngit',
      tags: [['E', target.id, ''], ['K', '1621'], ['P', owner], ['e', target.id, ''], ['k', '1621'], ['p', owner]],
    }, guestSecret);
    comments.handlers.event(comment(target, 'from iris', 75));
    comments.handlers.event(nip22);
    await tick();
    expect(states.at(-1)!.comments.map(each => [each.content, each.replyTo])).toEqual([
      ['from iris', target.id],
      ['from ngit', target.id],
    ]);
    watch.stop();
  });

  it('hands each published event to registered targets once the backend has it', async () => {
    const sent: string[] = [];
    const unregister = registerPublishTarget(event => sent.push(event.id));
    const event = issue('sent along', 90);
    publishInBackground(event);
    await tick();
    expect(sent).toEqual([event.id]);

    fixture.publish.mockRejectedValueOnce(new Error('offline'));
    publishInBackground(issue('not sent', 91));
    await tick();
    expect(sent).toEqual([event.id]);
    unregister();
  });
});
