import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { HashTree, LinkType, MemoryStore, type CID } from '@hashtree/core';

let tree: HashTree;
vi.mock('../src/store', () => ({ getTree: () => tree }));

import { getGitRepoAnnouncementOpenLink, parseGitRepoAnnouncement } from '../src/lib/gitRepoAnnouncements';
import { getExternalTreeRoot, isExternalTreeKey, readExternalBlock, registerExternalBlocks, setExternalTreeRoot, subscribeExternalTreeRoots, externalTreeKeysStore } from '../src/lib/externalTrees';
import { graspCloneUrls, isGraspCloneUrl, isNgitOnlyRepo, ngitCloneCommand, ngitRepoHref, ngitRepoOriginUrl, parseNgitForkOriginLink } from '../src/ngit/links';
import { fetchRequest, parseFetchResponse, parseLsRefsResponse, pktLine } from '../src/ngit/protocol';
import { signedHeadFromState } from '../src/ngit/repoState';
import { gitObjectId, readSingleObjectPack } from '../src/ngit/packObject';
import { importNgitRepo, type IndexedPack } from '../src/ngit/importRepo';
import { OverlayStore } from '../src/ngit/overlay';
import { fetchPack, GitResponseTooLargeError } from '../src/ngit/transport';
import { readGitObject, setMissingGitObjectSource } from '../src/utils/wasmGit/logPacks';
import { getHead } from '../src/utils/wasmGit/logHead';
import { getLog } from '../src/utils/wasmGit/logHistory';
import { getFileAtCommit } from '../src/utils/wasmGit/logDiff';
import { getRefs } from '../src/utils/wasmGit/branch';
import { get } from 'svelte/store';

const NPUB = 'npub15qydau2hjma6ngxkl2cyar74wzyjshvl65za5k5rl69264ar2exs5cyejr';
const encoder = new TextEncoder();
const decoder = new TextDecoder();

let work: string;
let repo: string;
const commits: string[] = [];

function git(cwd: string, ...args: string[]): string {
  return execFileSync('git', ['-c', 'commit.gpgsign=false', '-c', 'user.name=Test', '-c', 'user.email=t@example.com', ...args], {
    cwd,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
}

/** A grasp server stand-in: `git upload-pack` in protocol v2 stateless mode. */
function gitServer(routes: Record<string, string | number>, requests: string[] = []): typeof fetch {
  return (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);
    requests.push(url);
    const host = new URL(url).host;
    const target = routes[host];
    if (typeof target === 'number') return new Response('nope', { status: target });
    const output = execFileSync('git', ['upload-pack', '--stateless-rpc', target], {
      input: Buffer.from(init!.body as Uint8Array),
      env: { ...process.env, GIT_PROTOCOL: 'version=2' },
      maxBuffer: 64 * 1024 * 1024,
    });
    return new Response(new Uint8Array(output), { status: 200, headers: { 'content-type': 'application/x-git-upload-pack-result' } });
  }) as typeof fetch;
}

async function indexPackWithGit(pack: Uint8Array): Promise<IndexedPack> {
  const dir = mkdtempSync(join(work, 'idx-'));
  git(dir, 'init', '-q');
  writeFileSync(join(dir, 'in.pack'), pack);
  const name = git(dir, 'index-pack', '-o', join(dir, 'out.idx'), join(dir, 'in.pack')).split(/\s+/).pop()!;
  return { name, pack, idx: new Uint8Array(readFileSync(join(dir, 'out.idx'))) };
}

function newTree(): HashTree {
  return new HashTree({ store: new MemoryStore() });
}

beforeAll(() => {
  work = mkdtempSync(join(tmpdir(), 'iris-git-ngit-'));
  repo = join(work, 'repo');
  execFileSync('git', ['init', '-q', '-b', 'main', repo]);
  git(repo, 'config', 'uploadpack.allowFilter', 'true');
  git(repo, 'config', 'uploadpack.allowAnySHA1InWant', 'true');
  execFileSync('mkdir', ['-p', join(repo, 'src/lib'), join(repo, 'docs')]);
  for (let i = 1; i <= 5; i++) {
    writeFileSync(join(repo, 'README.md'), `# Demo\n\nVersion ${i}\n`);
    if (i === 1) {
      writeFileSync(join(repo, 'src/main.ts'), 'export const main = 1;\n');
      writeFileSync(join(repo, 'src/lib/util.ts'), 'export const util = 2;\n');
      writeFileSync(join(repo, 'docs/guide.md'), 'Guide\n');
    }
    git(repo, 'add', '-A');
    git(repo, 'commit', '-qm', `Commit ${i}`);
    commits.push(git(repo, 'rev-parse', 'HEAD'));
  }
});

afterAll(() => {
  setMissingGitObjectSource(null);
  rmSync(work, { recursive: true, force: true });
});

describe('ngit links', () => {
  it('accepts only grasp-shaped https clone URLs', () => {
    expect(isGraspCloneUrl(`https://relay.ngit.dev/${NPUB}/ngit.git`)).toBe(true);
    expect(isGraspCloneUrl(`http://relay.ngit.dev/${NPUB}/ngit.git`)).toBe(false);
    expect(isGraspCloneUrl(`https://relay.ngit.dev/${NPUB}/ngit`)).toBe(false);
    expect(isGraspCloneUrl('https://github.com/iris/example.git')).toBe(false);
    expect(isGraspCloneUrl(`https://user:pw@relay.ngit.dev/${NPUB}/ngit.git`)).toBe(false);
    expect(graspCloneUrls([
      'https://github.com/iris/example.git',
      ` https://relay.ngit.dev/${NPUB}/ngit.git`,
      `https://relay.ngit.dev/${NPUB}/ngit.git`,
      `https://gitnostr.com/${NPUB}/ngit.git`,
    ])).toEqual([`https://relay.ngit.dev/${NPUB}/ngit.git`, `https://gitnostr.com/${NPUB}/ngit.git`]);
  });

  it('opens ngit-only repos in the app and keeps Hashtree and forge repos as they were', () => {
    const grasp = `https://relay.ngit.dev/${NPUB}/ngit.git`;
    const ngit = { ownerNpub: NPUB, repoName: 'ngit', cloneUrls: [grasp], webUrls: ['https://gitworkshop.dev/x'] };
    expect(isNgitOnlyRepo(ngit)).toBe(true);
    expect(ngitRepoHref(ngit)).toBe(`#/${NPUB}/ngit`);
    expect(getGitRepoAnnouncementOpenLink(ngit)).toEqual({ href: `#/${NPUB}/ngit`, external: false });

    const both = { ...ngit, cloneUrls: [grasp, `htree://${NPUB}/ngit`] };
    expect(isNgitOnlyRepo(both)).toBe(false);
    expect(getGitRepoAnnouncementOpenLink(both)).toEqual({ href: `#/${NPUB}/ngit`, external: false });

    const forge = { ...ngit, cloneUrls: ['https://github.com/iris/example.git'], webUrls: [] };
    expect(getGitRepoAnnouncementOpenLink(forge)).toEqual({ href: 'https://github.com/iris/example', external: true });
    expect(ngitRepoHref({ ...ngit, repoName: 'a/b' })).toBeNull();
    expect(ngitCloneCommand(NPUB, 'ngit')).toBe(`git clone nostr://${NPUB}/ngit`);
    expect(ngitRepoOriginUrl(NPUB, 'ngit')).toBe(`nostr://${NPUB}/ngit`);
    expect(parseNgitForkOriginLink(`nostr://${NPUB}/ngit`)).toEqual({
      href: `#/${NPUB}/ngit`,
      label: `${NPUB}/ngit`,
      npub: NPUB,
      repoName: 'ngit',
    });
    expect(parseNgitForkOriginLink(`htree://${NPUB}/ngit`)).toBeNull();
    expect(parseNgitForkOriginLink('nostr://not-an-npub/ngit')).toBeNull();
  });

  it('preserves reserved characters in fork provenance repository names', () => {
    for (const repoName of ['repo#notes?draft', '100% ready', 'kahvi-\u00e4']) {
      const origin = ngitRepoOriginUrl(NPUB, repoName);
      expect(parseNgitForkOriginLink(origin)).toEqual({
        href: `#/${NPUB}/${encodeURIComponent(repoName)}`,
        label: `${NPUB}/${repoName}`,
        npub: NPUB,
        repoName,
      });
    }
  });

  it('reads repo relays from announcements', () => {
    const parsed = parseGitRepoAnnouncement({
      pubkey: 'a'.repeat(64),
      tags: [['d', 'ngit'], ['relays', 'wss://relay.ngit.dev', 'wss://gitnostr.com'], ['clone', `https://relay.ngit.dev/${NPUB}/ngit.git`]],
    });
    expect(parsed?.relays).toEqual(['wss://relay.ngit.dev', 'wss://gitnostr.com']);
  });
});

describe('git protocol v2', () => {
  it('frames requests and rejects unsafe arguments', () => {
    expect(decoder.decode(pktLine('done\n'))).toBe('0009done\n');
    const request = decoder.decode(fetchRequest({ wants: ['a'.repeat(40)], deepen: 1, filter: 'blob:none' }));
    expect(request).toContain('command=fetch\n');
    expect(request).toContain(`want ${'a'.repeat(40)}\n`);
    expect(request).toContain('deepen 1\n');
    expect(request).toContain('filter blob:none\n');
    expect(request.endsWith('0009done\n0000')).toBe(true);
    expect(() => fetchRequest({ wants: ['HEAD\nwant x'] })).toThrow();
    expect(() => fetchRequest({ wants: ['a'.repeat(40)], filter: 'blob:none\ndone' })).toThrow();
    expect(() => fetchRequest({ wants: ['a'.repeat(40)], deepen: 0 })).toThrow();
  });

  it('parses refs, shallow lines, pack data and server errors', () => {
    const sha = 'b'.repeat(40);
    const refs = parseLsRefsResponse(new Uint8Array([
      ...pktLine(`${sha} HEAD symref-target:refs/heads/main\n`),
      ...pktLine(`${sha} refs/heads/main\n`),
      ...encoder.encode('0000'),
    ]));
    expect(refs.headTarget).toBe('refs/heads/main');
    expect(refs.refs.get('refs/heads/main')).toBe(sha);

    const packData = new Uint8Array(40);
    packData.set(encoder.encode('PACK'));
    const band = (n: number, data: Uint8Array) => {
      const line = new Uint8Array(data.length + 5);
      line.set(encoder.encode((data.length + 5).toString(16).padStart(4, '0')));
      line[4] = n;
      line.set(data, 5);
      return line;
    };
    const response = parseFetchResponse(new Uint8Array([
      ...pktLine('shallow-info\n'),
      ...pktLine(`shallow ${sha}\n`),
      ...encoder.encode('0001'),
      ...pktLine('packfile\n'),
      ...band(2, encoder.encode('progress')),
      ...band(1, packData.subarray(0, 20)),
      ...band(1, packData.subarray(20)),
      ...encoder.encode('0000'),
    ]));
    expect(response.shallow).toEqual([sha]);
    expect(response.pack).toEqual(packData);

    expect(() => parseFetchResponse(new Uint8Array([...pktLine('packfile\n'), ...band(3, encoder.encode('boom')), ...encoder.encode('0000')])))
      .toThrow('boom');
    expect(() => parseLsRefsResponse(pktLine('ERR access denied\n'))).toThrow('access denied');
  });
});

describe('signed repository state', () => {
  it('takes HEAD from the owner state event only', () => {
    const sha = 'c'.repeat(40);
    const event = { kind: 30618, pubkey: 'a'.repeat(64), created_at: 1, tags: [['d', 'ngit'], ['HEAD', 'ref: refs/heads/main'], ['refs/heads/main', sha]] };
    expect(signedHeadFromState(event, 'a'.repeat(64), 'ngit')).toEqual({ ref: 'refs/heads/main', sha });
    expect(signedHeadFromState(event, 'b'.repeat(64), 'ngit')).toBeNull();
    expect(signedHeadFromState(event, 'a'.repeat(64), 'other')).toBeNull();
    expect(signedHeadFromState({ ...event, tags: [['d', 'ngit'], ['HEAD', 'ref: refs/heads/main']] }, 'a'.repeat(64), 'ngit')).toBeNull();
  });
});

describe('single-object packs', () => {
  it('reads and verifies a lazily fetched object', async () => {
    const blob = git(repo, 'rev-parse', `${commits[1]}:README.md`);
    const { pack } = await fetchPack('https://grasp.test/x/r.git', { wants: [blob], deepen: 1, filter: 'tree:0' }, {
      fetchImpl: gitServer({ 'grasp.test': repo }),
      maxBytes: 1 << 20,
    });
    const object = await readSingleObjectPack(pack, blob);
    expect(object.type).toBe('blob');
    expect(decoder.decode(object.content)).toBe('# Demo\n\nVersion 2\n');
    await expect(readSingleObjectPack(pack, 'd'.repeat(40))).rejects.toThrow('id mismatch');
    expect(await gitObjectId('blob', object.content)).toBe(blob);
  });
});

describe('importing an ngit repo', () => {
  const url = `https://grasp.test/${NPUB}/repo.git`;

  it('builds a browsable tree with recent history and loads old files on demand', async () => {
    tree = newTree();
    const requests: string[] = [];
    const fetchImpl = gitServer({ 'grasp.test': repo }, requests);
    const result = await importNgitRepo({ cloneUrls: [url], tree, indexPack: indexPackWithGit, fetchImpl, historyDepth: 3 });

    expect(result.headSha).toBe(commits[4]);
    expect(result.branch).toBe('main');
    expect(result.signed).toBe(false);
    expect(result.sourceUrl).toBe(url);
    expect(result.shallow).toEqual([commits[2]]);
    expect(requests.every((request) => request === `${url}/git-upload-pack`)).toBe(true);

    const names = (await tree.listDirectory(result.rootCid)).map((entry) => entry.name).sort();
    expect(names).toEqual(['.git', 'README.md', 'docs', 'src']);
    const readme = await tree.resolvePath(result.rootCid, 'README.md');
    expect(decoder.decode((await tree.readFile(readme!.cid))!)).toBe('# Demo\n\nVersion 5\n');
    const util = await tree.resolvePath(result.rootCid, 'src/lib/util.ts');
    expect(util?.type).toBe(LinkType.File);

    // The app's own git readers work on the result.
    expect(await getHead(result.rootCid)).toBe(commits[4]);
    const log = await getLog(result.rootCid, { depth: 10 });
    expect(log.map((commit) => commit.oid)).toEqual([commits[4], commits[3], commits[2]]);

    // History has no file contents until asked for.
    const oldBlob = git(repo, 'rev-parse', `${commits[3]}:README.md`);
    expect(await readGitObject(tree, result.gitDirCid, oldBlob)).toBeNull();
    const asked: string[] = [];
    setMissingGitObjectSource(async (_gitDir: CID, sha: string) => {
      asked.push(sha);
      const { pack } = await fetchPack(url, { wants: [sha], deepen: 1, filter: 'tree:0' }, { fetchImpl, maxBytes: 1 << 20 });
      return readSingleObjectPack(pack, sha);
    });
    try {
      const old = await getFileAtCommit(result.rootCid, commits[3], 'README.md');
      expect(decoder.decode(old!)).toBe('# Demo\n\nVersion 4\n');
      expect(asked).toContain(oldBlob);
    } finally {
      setMissingGitObjectSource(null);
    }
  });

  it('uses the signed HEAD and skips a server that fails', async () => {
    tree = newTree();
    const result = await importNgitRepo({
      cloneUrls: [`https://down.test/${NPUB}/repo.git`, url],
      signedHead: Promise.resolve({ ref: 'refs/heads/main', sha: commits[4] }),
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'down.test': 503, 'grasp.test': repo }),
      historyDepth: 2,
    });
    expect(result.signed).toBe(true);
    expect(result.sourceUrl).toBe(url);
  });

  it('does not wait for a signed state lookup that has not answered', async () => {
    tree = newTree();
    const result = await importNgitRepo({
      cloneUrls: [url],
      signedHead: new Promise(() => {}),
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'grasp.test': repo }),
      historyDepth: 1,
    });
    expect(result.signed).toBeNull();
    expect(result.headSha).toBe(commits[4]);
  });

  it('marks HEAD unsigned when no server has the signed commit', async () => {
    tree = newTree();
    const result = await importNgitRepo({
      cloneUrls: [url],
      signedHead: { ref: 'refs/heads/main', sha: 'e'.repeat(40) },
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'grasp.test': repo }),
      historyDepth: 1,
    });
    expect(result.signed).toBe(false);
    expect(result.headSha).toBe(commits[4]);
  });

  it('refuses packs above the size limit', async () => {
    tree = newTree();
    await expect(importNgitRepo({
      cloneUrls: [url],
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'grasp.test': repo }),
      maxPackBytes: 600,
    })).rejects.toBeInstanceOf(GitResponseTooLargeError);
  });

  it('imports complete self-contained encrypted history, branches, and tags for full forks', async () => {
    // Add a feature branch, lightweight tag, and annotated tag to the fixture repo.
    const forkFixture = join(work, 'fork-fixture');
    execFileSync('git', ['clone', '-q', repo, forkFixture]);
    git(forkFixture, 'config', 'uploadpack.allowFilter', 'true');
    git(forkFixture, 'tag', 'v1.0');
    git(forkFixture, 'tag', '-a', 'v1.0-annotated', '-m', 'Annotated release');
    git(forkFixture, 'checkout', '-qb', 'feature/extra');
    writeFileSync(join(forkFixture, 'feature.txt'), 'branch content\n');
    git(forkFixture, 'add', 'feature.txt');
    git(forkFixture, 'commit', '-qm', 'Feature commit');
    const featureSha = git(forkFixture, 'rev-parse', 'HEAD');
    git(forkFixture, 'checkout', '-q', 'main');

    tree = newTree();
    const stages: string[] = [];
    const result = await importNgitRepo({
      cloneUrls: [url],
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'grasp.test': forkFixture }),
      mode: 'full',
      encrypted: true,
      onProgress: (stage) => stages.push(stage),
    });

    expect(stages).toEqual(['fetching', 'indexing', 'saving']);
    expect(result.rootCid.key).toBeDefined();
    expect(result.gitDirCid.key).toBeDefined();
    expect(result.shallow).toEqual([]);
    expect(await getHead(result.rootCid)).toBe(commits[4]);

    // All commits and historical blobs are present locally without any missing-object source.
    const log = await getLog(result.rootCid, { depth: 20 });
    expect(log.map((commit) => commit.oid)).toEqual([...commits].reverse());
    const oldestReadme = await getFileAtCommit(result.rootCid, commits[0], 'README.md');
    expect(decoder.decode(oldestReadme!)).toBe('# Demo\n\nVersion 1\n');
    const featureFile = await getFileAtCommit(result.rootCid, featureSha, 'feature.txt');
    expect(decoder.decode(featureFile!)).toBe('branch content\n');

    // Branches and both lightweight + annotated tags resolve cleanly.
    const refs = await getRefs(result.rootCid);
    expect(refs.currentBranch).toBe('main');
    expect(refs.branches).toEqual(['feature/extra', 'main']);
    expect(refs.tags).toEqual(['v1.0', 'v1.0-annotated']);
    expect(refs.tagsByCommit[commits[4]]).toEqual(['v1.0', 'v1.0-annotated']);

    // Fork config uses remote "upstream" rather than claiming origin is still the grasp server.
    const configEntry = await tree.resolvePath(result.rootCid, '.git/config');
    expect(decoder.decode((await tree.readFile(configEntry!.cid))!)).toContain('[remote "upstream"]');
  });

  it('imports a self-contained encrypted 1-commit snapshot in shallow fork fallback mode', async () => {
    tree = newTree();
    const result = await importNgitRepo({
      cloneUrls: [url],
      tree,
      indexPack: indexPackWithGit,
      fetchImpl: gitServer({ 'grasp.test': repo }),
      mode: 'shallow',
      encrypted: true,
    });

    expect(result.rootCid.key).toBeDefined();
    expect(result.shallow).toEqual([commits[4]]);
    const log = await getLog(result.rootCid, { depth: 10 });
    expect(log.map((commit) => commit.oid)).toEqual([commits[4]]);
    const headReadme = await getFileAtCommit(result.rootCid, commits[4], 'README.md');
    expect(decoder.decode(headReadme!)).toBe('# Demo\n\nVersion 5\n');
    const shallowEntry = await tree.resolvePath(result.rootCid, '.git/shallow');
    expect(decoder.decode((await tree.readFile(shallowEntry!.cid))!).trim()).toBe(commits[4]);
  });
});

describe('external trees', () => {
  it('serves overlay blocks and roots until they are removed', async () => {
    const store = new OverlayStore();
    const overlayTree = new HashTree({ store });
    const { cid } = await overlayTree.putFile(encoder.encode('hello'), { unencrypted: true });
    const stop = registerExternalBlocks((hex) => store.read(hex));
    expect(readExternalBlock(cid.hash)).not.toBeNull();
    stop();
    expect(readExternalBlock(cid.hash)).toBeNull();

    const seen: Array<CID | null> = [];
    const unsubscribe = subscribeExternalTreeRoots((key, root) => {
      if (key === `${NPUB}/repo`) seen.push(root);
    });
    setExternalTreeRoot(NPUB, 'repo', cid);
    expect(getExternalTreeRoot(`${NPUB}/repo`)).toBe(cid);
    expect(isExternalTreeKey(get(externalTreeKeysStore), NPUB, 'repo')).toBe(true);
    setExternalTreeRoot(NPUB, 'repo', null);
    expect(getExternalTreeRoot(`${NPUB}/repo`)).toBeNull();
    expect(isExternalTreeKey(get(externalTreeKeysStore), NPUB, 'repo')).toBe(false);
    expect(seen).toEqual([cid, null]);
    unsubscribe();
  });
});

describe('collaboration on repos announced outside Hashtree', () => {
  it('treats a marked repo as public and leaves Hashtree visibility first', async () => {
    const { markExternalRepoPublic, collaborationVisibility, externalPublicReposStore, isExternalRepoPublic } = await import('../src/lib/externalTrees');
    expect(isExternalRepoPublic(NPUB, 'announced')).toBe(false);
    markExternalRepoPublic(NPUB, 'announced');
    const keys = get(externalPublicReposStore);
    expect(isExternalRepoPublic(NPUB, 'announced')).toBe(true);
    expect(collaborationVisibility(undefined, keys, NPUB, 'announced')).toBe('public');
    expect(collaborationVisibility(undefined, keys, NPUB, 'other')).toBeUndefined();
    expect(collaborationVisibility('private', keys, NPUB, 'announced')).toBe('private');
  });

  it('links a repo that fails to load to its web page, else its clone URL', async () => {
    const { getGitRepoAnnouncementExternalUrl } = await import('../src/lib/gitRepoAnnouncements');
    const grasp = `https://relay.ngit.dev/${NPUB}/ngit.git`;
    expect(getGitRepoAnnouncementExternalUrl({ cloneUrls: [grasp], webUrls: ['https://gitworkshop.dev/x/ngit'] })).toBe('https://gitworkshop.dev/x/ngit');
    expect(getGitRepoAnnouncementExternalUrl({ cloneUrls: [grasp], webUrls: [] })).toBe(grasp);
  });
});
