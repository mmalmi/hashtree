// Opt-in cold-reader benchmark. Uses the same Git readers as the browser and an
// existing checkout as the backing store, with fixed 256 KiB pack chunks.
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { closeSync, openSync, readdirSync, readFileSync, readSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { LinkType, type CID } from '@hashtree/core';
import { expect, it, vi } from 'vitest';
import { getFileLastCommits } from '../src/utils/wasmGit/logFileHistory';
import { getLog } from '../src/utils/wasmGit/logHistory';

const repo = process.env.GIT_PERF_REPO;
const chunkSize = 256 * 1024;
let reader: ReturnType<typeof localReader>;
vi.mock('../src/store', () => ({ getTree: () => reader }));

function fileCid(path: string) {
  return { hash: createHash('sha256').update(path).digest(), path };
}
type LocalCid = ReturnType<typeof fileCid>;

function localReader(gitDir: string, revision: string) {
  const stats = { bytes: 0, listings: 0 };
  function entry(path: string, name: string) {
    const stat = statSync(path, { throwIfNoEntry: false });
    if (!stat) return null;
    return { name, cid: fileCid(path), type: stat.isDirectory() ? LinkType.Dir : LinkType.File, size: stat.size };
  }
  return {
    stats,
    async resolvePath(dir: LocalCid, name: string) {
      return entry(name === '.git' ? gitDir : join(dir.path, name), name);
    },
    async listDirectory(dir: LocalCid) {
      stats.listings++;
      return readdirSync(dir.path).map(name => entry(join(dir.path, name), name));
    },
    async readFile(file: LocalCid) {
      const data = file.path === join(gitDir, 'HEAD') ? Buffer.from(revision) : readFileSync(file.path);
      stats.bytes += data.length;
      return data;
    },
    async getTreeNode(file: LocalCid) {
      const { size } = statSync(file.path);
      return { links: Array.from({ length: Math.ceil(size / chunkSize) }, (_, i) => ({
        type: LinkType.Blob, size: Math.min(chunkSize, size - i * chunkSize),
      })) };
    },
    async readFileRange(file: LocalCid, start: number, end: number) {
      const fd = openSync(file.path, 'r');
      try {
        const data = Buffer.alloc(end - start);
        const bytes = readSync(fd, data, 0, data.length, start);
        stats.bytes += bytes;
        return data.subarray(0, bytes);
      } finally {
        closeSync(fd);
      }
    },
  };
}

it.skipIf(!repo)('measures history and checks every visible root entry against Git', async () => {
  const git = (...args: string[]) => execFileSync('git', ['-C', repo!, '--literal-pathspecs', ...args], { encoding: 'utf8' });
  const revision = git('rev-parse', '--verify', '--end-of-options', (process.env.GIT_PERF_REV ?? 'HEAD') + '^{commit}').trim();
  const gitDir = git('rev-parse', '--path-format=absolute', '--git-common-dir').trim();
  reader = localReader(gitDir, revision);
  const root: CID = fileCid(repo!);
  const names = git('ls-tree', '-z', '--name-only', revision).split('\0').filter(Boolean);
  const cpu = process.cpuUsage();
  const start = performance.now();
  const [tip] = await getLog(root, { depth: 1 });
  const headMs = performance.now() - start;
  const headBytes = reader.stats.bytes;
  const commits = await getLog(root, { depth: 50 });
  const historyMs = performance.now() - start;
  const historyBytes = reader.stats.bytes;
  const rowsStart = performance.now();
  let firstRowMs: number | undefined;
  const rows = await getFileLastCommits(root, names, '', () => { firstRowMs ??= performance.now() - rowsStart; });
  const rowsMs = performance.now() - rowsStart;
  const usage = process.cpuUsage(cpu);
  const wrongRows = names.filter(name => rows.get(name)?.oid !== git('log', '-1', '--format=%H', revision, '--', name).trim());
  const result = { revision, rows: rows.size, wrongRows: wrongRows.length, headMs, headBytes, historyMs, historyBytes,
    firstRowMs, rowsMs, cpuMs: (usage.user + usage.system) / 1000, ...reader.stats };
  process.stdout.write('Git history benchmark ' + JSON.stringify(result) + '\n');
  expect(tip.oid).toBe(revision);
  expect(commits.length).toBe(Math.min(50, Number(git('rev-list', '--count', revision))));
  expect(wrongRows).toEqual([]);
}, 120_000);
