import { nip19 } from 'nostr-tools';
import { htreeSearchHref, isHtreeSearchInput } from '../src/lib/htreeSearchLink';
import { HTREE_APP_URL } from '../src/lib/shareUrls';
import { describe, expect, it } from 'vitest';
import { buildRepoCodeHref, buildRepoTabHref } from '../src/lib/gitRefNavigation';

describe('git ref navigation', () => {
  it('builds branch and tag tab links at the repo root', () => {
    expect(buildRepoTabHref('npub1owner', 'projects/hashtree', 'branches'))
      .toBe('#/npub1owner/projects/hashtree?tab=branches');

    expect(buildRepoTabHref('npub1owner', 'projects/hashtree', 'tags', 'abc123'))
      .toBe('#/npub1owner/projects/hashtree?tab=tags&k=abc123');
  });

  it('builds code links that preserve link keys and refs', () => {
    expect(buildRepoCodeHref('npub1owner', 'projects/hashtree'))
      .toBe('#/npub1owner/projects/hashtree');

    expect(buildRepoCodeHref('npub1owner', 'projects/hashtree', { ref: 'master', linkKey: 'abc123' }))
      .toBe('#/npub1owner/projects/hashtree?ref=master&k=abc123');
  });

  it('encodes nested path segments and ref names safely', () => {
    expect(buildRepoCodeHref('npub1owner', 'repos/my repo', { ref: 'release/v1.0.0' }))
      .toBe('#/npub1owner/repos/my%20repo?ref=release%2Fv1.0.0');
  });
});

describe('Hashtree links in search', () => {
  const owner = nip19.npubEncode('ab'.repeat(32));
  const base = `htree://${owner}/projects/my%20repo`;
  const route = `#/${owner}/projects/my%20repo`;
  const key = 'ab'.repeat(33);

  it('opens public, private and keyed Git URLs using the repository route', () => {
    expect(htreeSearchHref(base)).toBe(route);
    expect(htreeSearchHref(base + '#private')).toBe(route);
    for (const length of [64, 66]) {
      for (const delimiter of ['?', '#']) {
        expect(htreeSearchHref(base + delimiter + 'k=' + key.slice(0, length).toUpperCase()))
          .toBe(route + '?k=' + key.slice(0, length));
      }
    }
    expect(htreeSearchHref('htree://self/tree', owner)).toBe(`#/${owner}/tree`);
    expect(htreeSearchHref('htree://self/tree')).toBeNull();
    expect(htreeSearchHref('htree://' + 'ab'.repeat(32) + '/tree')).toBe(`#/${owner}/tree`);
    expect(htreeSearchHref(HTREE_APP_URL + route + '?k=' + key)).toBe(route + '?k=' + key);
  });

  it('keeps malformed and incomplete links out of search and navigation', () => {
    for (const input of [
      'htree:', 'htree:/', 'htree://', 'htree://bad/tree', `htree://${owner}/`, base + '#',
      base + '#/unrelated', base + '?k=', base + '#k=wrong', base + '#link-visible',
      base + '?k=' + key + '#private', base + '#k=' + key + '#extra',
      base + '?k=' + key + '&k=' + key, base + '?other=value', base + '/%2e%2e',
      base + '/a%2fb', base + '/%zz', base + '//file', HTREE_APP_URL + route + '?k=invalid',
    ]) {
      expect(isHtreeSearchInput(input)).toBe(true);
      expect(htreeSearchHref(input)).toBeNull();
    }
    expect(isHtreeSearchInput('file history')).toBe(false);
  });
});
