import { describe, expect, it, vi } from 'vitest';
import { LinkType, type CID } from '@hashtree/core';
import { fitsBackgroundGitBudget } from '../src/utils/gitSnapshotBudget';

const { listDirectory } = vi.hoisted(() => ({ listDirectory: vi.fn() }));
vi.mock('../src/store', () => ({ getTree: () => ({ listDirectory }) }));
const root: CID = { hash: new Uint8Array(32) };
const entry = (size: number, type = LinkType.Blob) => ({ size, type, cid: root });

describe('automatic Git snapshot reads', () => {
  it('declines a large pack or a wide directory using metadata alone', async () => {
    listDirectory.mockResolvedValueOnce([entry(0, LinkType.Dir)]).mockResolvedValueOnce([entry(250_000_000)]);
    expect(await fitsBackgroundGitBudget(root)).toBe(false);
    listDirectory.mockResolvedValueOnce(Array(513).fill(entry(1)));
    expect(await fitsBackgroundGitBudget(root)).toBe(false);
  });
  it('adds sizes across directories and accepts small checkouts', async () => {
    listDirectory.mockResolvedValueOnce([entry(5_000_000), entry(0, LinkType.Dir)]).mockResolvedValueOnce([entry(4_000_000)]);
    expect(await fitsBackgroundGitBudget(root)).toBe(false);
    listDirectory.mockResolvedValueOnce([entry(80), entry(0, LinkType.Dir)]).mockResolvedValueOnce([entry(120)]);
    expect(await fitsBackgroundGitBudget(root)).toBe(true);
  });
  it('stops on navigation or unavailable directory metadata', async () => {
    listDirectory.mockClear();
    expect(await fitsBackgroundGitBudget(root, AbortSignal.abort())).toBe(false);
    expect(listDirectory).not.toHaveBeenCalled();
    listDirectory.mockRejectedValueOnce(new Error('unavailable'));
    expect(await fitsBackgroundGitBudget(root)).toBe(false);
  });
});
