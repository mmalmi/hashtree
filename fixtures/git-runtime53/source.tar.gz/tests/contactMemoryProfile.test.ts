import { beforeEach, expect, it, vi } from 'vitest';
import { finalizeEvent, getPublicKey, type Event, type EventTemplate } from 'nostr-tools';
const fixture = vi.hoisted(() => ({
  requests: [] as Array<{kinds:number[], authors:string[], handlers:Record<string,(event?:unknown)=>void>}>,
  pubkey: '',
  adapter: null as null | {queryEvents: ReturnType<typeof vi.fn>},
  relays: ['wss://example.invalid'],
  nostr: {signer: {} as object | undefined, subscribe: vi.fn(), signEvent: vi.fn(), publish: vi.fn()},
}));
vi.mock('../src/nostr/client', () => ({nostr: fixture.nostr, getNostrRelayUrls: () => fixture.relays}));
vi.mock('../src/workerAdapter', () => ({getWorkerAdapter: () => fixture.adapter}));
vi.mock('../src/nostr', () => ({nostr: fixture.nostr, nostrStore: {getState: () => ({pubkey:fixture.pubkey})}}));
import { createProfileStore, getProfileSync } from '../src/stores/profile';
import { followPubkey, getFollowsSync, unfollowPubkey } from '../src/stores/follows';
import { contactMemory } from '../src/stores/contactMemory';
let secret: Uint8Array;
let sequence = 0;
const contact='b'.repeat(64), existing='c'.repeat(64);
const head = (tags:string[][],created_at=20): Event => finalizeEvent({kind:3,tags,created_at,content:'{"keep":"this"}'},secret);
async function requestAfter(start:number) {
  await vi.waitFor(() => expect(fixture.requests.slice(start).some(r=>r.kinds.includes(3))).toBe(true));
  return fixture.requests.slice(start).find(r=>r.kinds.includes(3))!;
}
beforeEach(() => {
  vi.useRealTimers(); fixture.requests=[]; fixture.adapter=null; fixture.relays=['wss://example.invalid']; fixture.nostr.signEvent.mockReset(); fixture.nostr.publish.mockReset();
  secret=new Uint8Array(32);secret[31]=++sequence;fixture.pubkey=getPublicKey(secret);fixture.nostr.signer={};
  const values = new Map<string,string>();
  vi.stubGlobal('localStorage', {getItem:(key:string)=>values.get(key)??null,setItem:(key:string,value:string)=>values.set(key,value)});
  fixture.nostr.subscribe.mockImplementation((filter) => {
    const request={...filter,handlers:{}};fixture.requests.push(request);
    return {on:(type:string,callback:(event:unknown)=>void) => {request.handlers[type]=callback;},stop:()=>{request.handlers.close?.();}};
  });
  fixture.nostr.signEvent.mockImplementation(async (draft:EventTemplate) => finalizeEvent(draft,secret));
  fixture.nostr.publish.mockResolvedValue({accepted:true,queued:false});
});
const shown = () => getFollowsSync(fixture.pubkey)?.follows ?? [];
const signedTags = () => fixture.nostr.signEvent.mock.calls.at(-1)?.[0].tags;
const signedTimes = (count:number) => vi.waitFor(() => expect(fixture.nostr.signEvent).toHaveBeenCalledTimes(count));
const settle = () => new Promise(resolve => setTimeout(resolve, 20));
it('follows at once, builds on the newest list seen, keeps its tags and content, and saves the name seen before follow', async () => {
  const unsubscribe=createProfileStore(contact).subscribe(()=>{});
  // Profile lookups are batched, so the request follows a moment later.
  const profile=await vi.waitFor(() => { const request=fixture.requests.find(r=>r.kinds.includes(0)); expect(request).toBeDefined(); return request!; });
  profile.handlers.event({pubkey:contact,created_at:20,content:JSON.stringify({name:'Bob'})});
  expect(getProfileSync(contact)?.name).toBe('Bob');
  const started=fixture.requests.length;
  // Nothing has answered yet: the choice shows, and nothing is published from nothing.
  expect(await followPubkey(contact)).toBe(true);
  expect(shown()).toEqual([contact]);
  const own=await requestAfter(started);
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  profile.handlers.event({pubkey:contact,created_at:30,content:JSON.stringify({name:'Robert'})});
  const tags=[['p',existing,'wss://example.invalid','friend'],['t','music'],['client','iris']];
  own.handlers.event(head(tags));
  await signedTimes(1);
  expect(fixture.nostr.signEvent.mock.calls[0][0]).toMatchObject({content:'{"keep":"this"}',tags:[...tags,['p',contact]]});
  await vi.waitFor(() => expect(fixture.nostr.publish).toHaveBeenCalledTimes(1));
  expect(shown()).toEqual([existing,contact]);
  expect(contactMemory.get(fixture.pubkey,contact)?.accepted_name).toBe('Bob');
  expect(getProfileSync(contact)?.name).toBe('Robert');
  own.handlers.event(head(tags)); // A stale relay cannot erase the locally signed list.
  expect(shown()).toEqual([existing,contact]);
  expect(await unfollowPubkey(contact)).toBe(true);
  expect(shown()).toEqual([existing]);
  await signedTimes(2);
  expect(signedTags()).toEqual(tags);
  expect(fixture.nostr.signEvent.mock.calls[1][0].content).toBe('{"keep":"this"}');
  unsubscribe();
});
it('neither waits for nor fails on a relay which never accepts the list', async () => {
  fixture.nostr.publish.mockReturnValue(new Promise(()=>{}));
  const other='e'.repeat(64);
  expect(await followPubkey(contact)).toBe(true);
  (await requestAfter(0)).handlers.event(head([['p',existing]]));
  await signedTimes(1);
  expect(await followPubkey(other)).toBe(true);
  expect(shown()).toEqual([existing,contact,other]);
  await signedTimes(2);
  expect(signedTags()).toEqual([['p',existing],['p',contact],['p',other]]);
});
it('does not publish a list built from nothing while its absence is not established', async () => {
  expect(await followPubkey(contact)).toBe(true);
  const own=await requestAfter(0);
  own.handlers.history({complete:false,reason:'timeout'});
  for (const request of fixture.requests.filter(r=>r.kinds.includes(3))) request.handlers.history?.({complete:false,reason:'unavailable'});
  await settle();
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  expect(shown()).toEqual([contact]);
  // The list arriving later is the one built on.
  own.handlers.event(head([['p',existing]]));
  await signedTimes(1);
  expect(signedTags()).toEqual([['p',existing],['p',contact]]);
});
it('publishes a first list once every source has answered that none exists', async () => {
  expect(await followPubkey(contact)).toBe(true);
  (await requestAfter(0)).handlers.history({complete:true,reason:'eose'});
  await signedTimes(1);
  expect(signedTags()).toEqual([['p',contact]]);
});
it('applies the same choice to a newer list which a slow relay delivers afterwards', async () => {
  expect(await followPubkey(contact)).toBe(true);
  const own=await requestAfter(0);
  own.handlers.event(head([['p','d'.repeat(64)]],10));
  await signedTimes(1);
  const first=await fixture.nostr.signEvent.mock.results[0].value as Event;
  own.handlers.event(head([['p',existing],['client','iris']],20));
  await signedTimes(2);
  expect(signedTags()).toEqual([['p',existing],['client','iris'],['p',contact]]);
  expect(fixture.nostr.signEvent.mock.calls[1][0].created_at).toBeGreaterThan(first.created_at);
  own.handlers.event(head([['p','d'.repeat(64)]],15));
  await settle();
  expect(fixture.nostr.signEvent).toHaveBeenCalledTimes(2);
  expect(shown()).toEqual([existing,contact]);
});
it('never builds on an unsigned list or takes its place as empty', async () => {
  expect(await followPubkey(contact)).toBe(true);
  const own=await requestAfter(0);
  own.handlers.event({...JSON.parse(JSON.stringify(head([['p',existing]]))),sig:'0'.repeat(128)});
  own.handlers.history({complete:true,reason:'eose'});
  await settle();
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
});
it('drops the choice when the account changes while signing', async () => {
  let finish!: (event:Event)=>void;
  fixture.nostr.signEvent.mockImplementationOnce((draft:EventTemplate) => new Promise<Event>(resolve => {finish=()=>resolve(finalizeEvent(draft,secret));}));
  const account=fixture.pubkey;
  expect(await followPubkey(contact)).toBe(true);
  (await requestAfter(0)).handlers.event(head([['p',existing]]));
  await signedTimes(1);
  fixture.pubkey='d'.repeat(64);
  finish(undefined as never);
  await settle();
  expect(fixture.nostr.publish).not.toHaveBeenCalled();
  expect(getFollowsSync(account)?.follows).toEqual([existing]);
});
it('takes the choice back when signing is refused', async () => {
  fixture.nostr.signEvent.mockRejectedValueOnce(new Error('refused'));
  const logged=vi.spyOn(console,'error').mockImplementation(()=>{});
  expect(await followPubkey(contact)).toBe(true);
  (await requestAfter(0)).handlers.event(head([['p',existing]]));
  await vi.waitFor(() => expect(shown()).toEqual([existing]));
  expect(fixture.nostr.publish).not.toHaveBeenCalled();
  logged.mockRestore();
});
it('signs one list for choices made together', async () => {
  const other='e'.repeat(64);
  expect(await followPubkey(contact)).toBe(true);
  expect(await followPubkey(other)).toBe(true);
  expect(shown()).toEqual([contact,other]);
  (await requestAfter(0)).handlers.event(head([['p',existing],['client','iris']]));
  await signedTimes(1);
  await settle();
  expect(fixture.nostr.signEvent).toHaveBeenCalledTimes(1);
  expect(signedTags()).toEqual([['p',existing],['client','iris'],['p',contact],['p',other]]);
});
