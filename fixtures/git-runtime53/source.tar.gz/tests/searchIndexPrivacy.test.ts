import { afterEach, expect, it, vi } from 'vitest';

const { publish } = vi.hoisted(() => ({ publish: vi.fn() }));

vi.mock('../src/nostr/store', () => ({
  nostrStore: { getState: () => ({ npub: 'signed-in-user', isLoggedIn: true }) },
}));
vi.mock('../src/refResolver', () => ({ getRefResolver: () => ({ publish }) }));
vi.mock('../src/store', async () => {
  const { MemoryStore } = await import('@hashtree/core');
  return { localStore: new MemoryStore() };
});
vi.mock('@hashtree/dexie', async () => {
  const { MemoryStore } = await import('@hashtree/core');
  const store = new MemoryStore();
  return { DexieStore: vi.fn(function () { return store; }) };
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.clearAllMocks();
});

it('persists people search locally without using the shared store or publishing on Nostr', async () => {
  vi.useFakeTimers();
  const saved = new Map([
    ['searchIndexVersion', '2'],
    ['searchIndexRoot', JSON.stringify({ hash: '11'.repeat(32), key: '22'.repeat(32) })],
  ]);
  vi.stubGlobal('localStorage', {
    getItem: (key: string) => saved.get(key) ?? null,
    setItem: (key: string, value: string) => saved.set(key, value),
    removeItem: (key: string) => saved.delete(key),
  });
  const { localStore } = await import('../src/store');
  const sharedGet = vi.spyOn(localStore, 'get');
  const sharedPut = vi.spyOn(localStore, 'put');
  const { indexUsers, searchUsers } = await import('../src/stores/searchIndex');
  const person = { pubkey: 'ab'.repeat(32), name: 'Search Example' };
  await indexUsers([person]);
  await vi.waitFor(async () => {
    expect(await searchUsers('example')).toEqual([expect.objectContaining(person)]);
  });
  await vi.advanceTimersByTimeAsync(5000);

  expect(publish).not.toHaveBeenCalled();
  expect(sharedGet).not.toHaveBeenCalled();
  expect(sharedPut).not.toHaveBeenCalled();

  vi.resetModules();
  const reloaded = await import('../src/stores/searchIndex');
  expect(await reloaded.searchUsers('example')).toEqual([expect.objectContaining(person)]);
  await vi.advanceTimersByTimeAsync(5000);
  expect(publish).not.toHaveBeenCalled();
});
