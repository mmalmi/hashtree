import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { CID } from '@hashtree/core';

const mocks = vi.hoisted(() => ({
  external: true,
  owner: 'source-owner',
  tree: {
    isDirectory: vi.fn(), listDirectory: vi.fn(), readFile: vi.fn(),
    putFile: vi.fn(), putDirectory: vi.fn(),
  },
  imported: vi.fn(), saved: vi.fn(), selected: vi.fn(), announced: vi.fn(),
  navigate: vi.fn(), storeKey: vi.fn(), annotate: vi.fn(), excludeMeta: vi.fn(),
}));
vi.mock('../src/nostr', () => ({
  nostrStore: { getState: () => ({ npub: 'reader', pubkey: 'reader-key' }), setSelectedTree: mocks.selected },
  saveHashtree: mocks.saved,
}));
vi.mock('../src/store', () => ({ getTree: () => mocks.tree }));
vi.mock('../src/nip34', () => ({
  buildHtreeUrl: () => 'htree://source-owner/source',
  getStoredRepoAnnouncement: async () => ({ earliestUniqueCommit: 'root-commit' }),
  publishRepoAnnouncement: mocks.announced,
}));
vi.mock('../src/utils/git', () => ({ getRootCommit: async () => 'root-commit' }));
vi.mock('../src/lib/router.svelte', () => ({ navigate: mocks.navigate }));
vi.mock('../src/utils/route', () => ({ parseRoute: () => ({ npub: mocks.owner, treeName: 'source', path: [] }) }));
vi.mock('../src/stores/projectMeta', () => ({ setProjectForkOrigin: mocks.annotate, ignoreGeneratedProjectMetaInGitStatus: mocks.excludeMeta }));
vi.mock('../src/lib/externalTrees', () => ({
  externalTreeKeysStore: { subscribe: (callback: (value: object) => void) => { callback({}); return () => {}; } },
  isExternalTreeKey: () => mocks.external,
}));
vi.mock('../src/ngit/links', () => ({ ngitRepoOriginUrl: () => 'nostr://source-owner/source' }));
vi.mock('../src/stores/trees', () => ({ storeLinkKey: mocks.storeKey }));
vi.mock('../src/ngit/session', () => ({ importActiveNgitRepoForFork: mocks.imported, clearNgitSession: vi.fn() }));
import { forkTree } from '../src/actions/treeFork';

const cid = (value: number, encrypted = true): CID => ({
  hash: new Uint8Array(32).fill(value),
  ...(encrypted ? { key: new Uint8Array(32).fill(value + 1) } : {}),
});
const root = cid(1);
const noPublication = () => {
  expect(mocks.saved).not.toHaveBeenCalled();
  expect(mocks.selected).not.toHaveBeenCalled();
  expect(mocks.announced).not.toHaveBeenCalled();
  expect(mocks.navigate).not.toHaveBeenCalled();
};
beforeEach(() => {
  vi.resetAllMocks();
  mocks.external = true;
  mocks.owner = 'source-owner';
  mocks.imported.mockResolvedValue({ imported: { rootCid: root, shallow: [] }, announcement: { earliestUniqueCommit: 'root-commit' } });
  mocks.saved.mockResolvedValue({ success: true });
  mocks.announced.mockResolvedValue(true);
  mocks.annotate.mockImplementation(async (value: CID) => value);
  mocks.excludeMeta.mockImplementation(async (value: CID) => value);
});

describe('fork cancellation', () => {
  it('does not begin an import when already cancelled', async () => {
    const controller = new AbortController();
    controller.abort();
    await expect(forkTree(root, 'copy', 'public', { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(mocks.imported).not.toHaveBeenCalled();
    noPublication();
  });

  it('stops when an import completes after cancellation', async () => {
    const controller = new AbortController();
    mocks.imported.mockImplementationOnce(async () => {
      controller.abort();
      return { imported: { rootCid: root, shallow: [] }, announcement: { earliestUniqueCommit: 'root-commit' } };
    });
    await expect(forkTree(root, 'copy', 'public', { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    noPublication();
  });

  it('stops at the publication boundary', async () => {
    const controller = new AbortController();
    await expect(forkTree(root, 'copy', 'public', {
      signal: controller.signal, onProgress: () => controller.abort(),
    })).rejects.toMatchObject({ name: 'AbortError' });
    noPublication();
  });

  it('stops when the last metadata operation completes after cancellation', async () => {
    const controller = new AbortController();
    mocks.excludeMeta.mockImplementationOnce(async (value: CID) => { controller.abort(); return value; });
    await expect(forkTree(root, 'copy', 'public', { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    noPublication();
  });

  for (const stage of ['listing', 'reading', 'writing'] as const) {
    it(`stops recursive encryption after cancellation during ${stage}`, async () => {
      mocks.external = false;
      mocks.owner = 'reader'; // Own unencrypted tree: no fork metadata work.
      const controller = new AbortController();
      const source = cid(1, false), nested = cid(2, false), file = cid(3, false), sibling = cid(4, false);
      mocks.tree.isDirectory.mockImplementation(async (value: CID) => value.hash[0] < 3);
      mocks.tree.listDirectory.mockImplementation(async (value: CID) => {
        if (stage === 'listing') controller.abort();
        return value.hash[0] === 1
          ? [{ name: 'nested', cid: nested, size: 0, type: 1 }, { name: 'later', cid: sibling, size: 1, type: 0 }]
          : [{ name: 'file', cid: file, size: 1, type: 0 }];
      });
      mocks.tree.readFile.mockImplementation(async () => {
        if (stage === 'reading') controller.abort();
        return new Uint8Array([7]);
      });
      mocks.tree.putFile.mockImplementation(async () => { controller.abort(); return { cid: cid(5) }; });
      mocks.tree.putDirectory.mockResolvedValue({ cid: cid(6) });
      await expect(forkTree(source, 'private-copy', 'private', { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
      expect(mocks.tree.isDirectory.mock.calls.map(([value]) => value.hash[0])).not.toContain(4);
      expect(mocks.tree.putFile).toHaveBeenCalledTimes(stage === 'writing' ? 1 : 0);
      expect(mocks.tree.putDirectory).not.toHaveBeenCalled();
      if (stage === 'listing') expect(mocks.tree.readFile).not.toHaveBeenCalled();
      noPublication();
    });
  }

  it('retains a completed save access key but stops announcement and navigation after cancellation', async () => {
    const controller = new AbortController();
    mocks.saved.mockImplementationOnce(async () => { controller.abort(); return { success: true, linkKey: 'synthetic-key' }; });
    await expect(forkTree(root, 'copy', 'public', { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(mocks.storeKey).toHaveBeenCalledWith('reader', 'copy', 'synthetic-key');
    expect(mocks.announced).not.toHaveBeenCalled();
    expect(mocks.navigate).not.toHaveBeenCalled();
  });

  it('keeps normal fork publication and navigation', async () => {
    expect(await forkTree(root, 'copy')).toEqual({ success: true });
    expect(mocks.saved).toHaveBeenCalledOnce();
    expect(mocks.announced).toHaveBeenCalledOnce();
    expect(mocks.navigate).toHaveBeenCalledWith('/reader/copy');
  });
});
