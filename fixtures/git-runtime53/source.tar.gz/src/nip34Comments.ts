import type { Event as NostrEvent } from 'nostr-tools';
import { nostr, nostrStore, pubkeyToNpub } from './nostr';
import { KIND_COMMENT, KIND_TEXT_NOTE } from './utils/constants';
import { publishNip34Event, type Comment } from './nip34';
import { GitCollaborationPrivacyError } from './lib/gitCollaboration';

export function parseCommentEvent(event: NostrEvent, targetEventId: string): Comment | null {
  if (!event.id || !event.pubkey) return null;
  return {
    id: event.id,
    content: event.content || '',
    author: pubkeyToNpub(event.pubkey),
    authorPubkey: event.pubkey,
    created_at: event.created_at || 0,
    // A NIP-22 comment names its parent in its `e` tag; a kind 1 note marks it "reply".
    replyTo: (event.kind === KIND_COMMENT
      ? event.tags.find(t => t[0] === 'e')?.[1]
      : event.tags.find(t => t[0] === 'e' && t[3] === 'reply')?.[1]) || targetEventId,
  };
}

/**
 * Add a comment. Returns once its signed event is queued locally.
 */
export async function addComment(
  targetEventId: string,
  targetAuthorPubkey: string,
  content: string,
  repoAddress: string,
  onPublishFailure?: (error: Error) => void,
): Promise<Comment | null> {
  const state = nostrStore.getState();
  if (!state.pubkey || !nostr.signer) return null;

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_TEXT_NOTE;
  event.content = content;
  event.tags = [
    ['e', targetEventId, '', 'root'],
    ['p', targetAuthorPubkey],
    ['a', repoAddress],
  ];

  try {
    const signedEvent = await publishNip34Event(event, onPublishFailure);

    return {
      id: signedEvent.id,
      content,
      author: state.npub!,
      authorPubkey: state.pubkey,
      created_at: event.created_at || Math.floor(Date.now() / 1000),
      replyTo: targetEventId,
    };
  } catch (e) {
    if (e instanceof GitCollaborationPrivacyError) throw e;
    console.error('Failed to add comment:', e);
    return null;
  }
}
