import Dexie, { type Table } from 'dexie';
import type { CommitInfo } from './wasmGit/logTypes';

type FileCommit = Pick<CommitInfo, 'oid' | 'message' | 'timestamp'>;
interface DirectoryHistory {
  directory: string;
  head: string;
  rows: Map<string, FileCommit>;
  savedAt: number;
}

let database: Dexie | undefined;
function historyTable(): Table<DirectoryHistory, string> {
  if (!database) {
    database = new Dexie('iris-git-public-file-history');
    database.version(1).stores({ directories: 'directory, savedAt' });
  }
  return database.table('directories');
}

export async function readPublicFileHistory(directory: string): Promise<DirectoryHistory | undefined> {
  try {
    const saved = await historyTable().get(directory);
    return saved?.rows instanceof Map ? saved : undefined;
  } catch {
    return undefined;
  }
}

function fitsBudget(rows: Map<string, FileCommit>) {
  let characters = 0;
  for (const [name, commit] of rows) characters += name.length + commit.message.length + commit.oid.length;
  return characters <= 64 * 1024;
}

export async function savePublicFileHistory(directory: string, head: string, rows: Map<string, FileCommit>) {
  // Keep at most 16 small directory snapshots. Full messages remain available
  // from Git even when a directory exceeds the local cache budget.
  if (!rows.size || rows.size > 256 || !fitsBudget(rows)) return;
  try {
    const table = historyTable();
    await table.db.transaction('rw', table, async () => {
      const previous = await table.get(directory);
      if (previous?.head === head && previous.rows instanceof Map) {
        // Concurrent listings or transient misses can supply different subsets.
        if ([...rows.keys()].every(name => previous.rows.has(name))) return;
        const combined = new Map([...previous.rows, ...rows]);
        if (combined.size <= 256 && fitsBudget(combined)) rows = combined;
      }
      await table.put({ directory, head, rows, savedAt: Date.now() });
      const oldest = await table.orderBy('savedAt').reverse().offset(16).primaryKeys();
      if (oldest.length) await table.bulkDelete(oldest);
    });
  } catch {
    // Browsing works when storage is disabled or full.
  }
}
