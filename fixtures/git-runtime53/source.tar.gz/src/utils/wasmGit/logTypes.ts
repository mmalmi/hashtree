export interface CommitInfo {
  oid: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent: string[];
}

export interface GitObject {
  type: string;
  content: Uint8Array;
}

export interface ParsedCommit {
  tree: string;
  parents: string[];
  author: string;
  email: string;
  timestamp: number;
  message: string;
}

export interface ParsedTag {
  object: string;
  type: string;
}

export interface CommitDetails extends CommitInfo {
  tree: string;
}

export interface CommitTreeEntry {
  name: string;
  data: Uint8Array;
  isDir: boolean;
}

export interface DiffEntry {
  path: string;
  status: 'added' | 'deleted' | 'modified';
  oldHash?: string;
  newHash?: string;
  oldMode?: string;
  newMode?: string;
}

export function isIncompleteLog(commits: CommitInfo[], depth: number): boolean {
  if (!commits.length || commits.length >= depth) return false;
  const found = new Set(commits.map(commit => commit.oid));
  return commits.some(commit => commit.parent.some(parent => !found.has(parent)));
}
