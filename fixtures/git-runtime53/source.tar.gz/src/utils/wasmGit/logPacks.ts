import type { CID, TreeEntry, TreeNode } from '@hashtree/core';
import { fromHex, LinkType, toHex } from '@hashtree/core';
import { unzlibSync } from 'fflate';
import { LRUCache } from '../lruCache';
import { getTree } from '../../store';
import type { GitObject } from './logTypes';

// Commits, trees and deltas are small: inflating them in place avoids a stream
// round trip per object. Larger inputs keep the main thread free.
const SYNC_INFLATE_LIMIT = 256 * 1024;

async function decompressZlib(data: Uint8Array): Promise<Uint8Array> {
  if (data.length <= SYNC_INFLATE_LIMIT) {
    try {
      return unzlibSync(data);
    } catch {
      // Fall through to the streaming decoder.
    }
  }
  const stream = new Blob([new Uint8Array(data)]).stream()
    .pipeThrough(new DecompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function hex(bytes: Uint8Array & { toHex?: () => string }): string {
  return bytes.toHex?.() ?? toHex(bytes);
}

export function gitDirCacheKey(gitDirCid: CID): string {
  return gitDirCid.key ? `${hex(gitDirCid.hash)}:${hex(gitDirCid.key)}` : hex(gitDirCid.hash);
}

interface PackIndexData {
  findOffset(hash: Uint8Array): number | undefined;
  sortedOffsets: Float64Array;
}

interface IndexedPack {
  file: TreeEntry;
  index: PackIndexData;
}

const packIndexCache = new LRUCache<string, Promise<PackIndexData | null>>(64);
const gitObjectCache = new LRUCache<string, Promise<GitObject | null>>(512);

async function readPackIndex(tree: ReturnType<typeof getTree>, idxEntry: TreeEntry): Promise<PackIndexData | null> {
  try {
    const idxData = idxEntry.size > 64 * 1024
      ? await readFileSpan(tree, idxEntry, 0, idxEntry.size)
      : await tree.readFile(idxEntry.cid);
    if (!idxData) return null;

    const view = new DataView(idxData.buffer, idxData.byteOffset, idxData.byteLength);

    // Check magic number (0xff744f63 for v2)
    if (view.getUint32(0) !== 0xff744f63) {
      return null;
    }

    // Version should be 2
    if (view.getUint32(4) !== 2) {
      return null;
    }

    // Total object count is the last entry in the fanout table.
    const numObjects = view.getUint32(8 + 255 * 4);

    // Git already sorts the 20-byte names and indexes them by first byte.
    // Search those bytes in place instead of building a JS string and Map entry per object.
    const namesStart = 8 + 256 * 4;
    const offsetsStart = namesStart + numObjects * 24; // names followed by CRCs
    const largeOffsetsStart = offsetsStart + numObjects * 4;
    if (largeOffsetsStart + 40 > view.byteLength) return null;

    function offsetAt(index: number): number {
      const offset = view.getUint32(offsetsStart + index * 4);
      if (offset < 0x80000000) return offset;
      const pos = largeOffsetsStart + (offset - 0x80000000) * 8;
      if (pos + 8 > view.byteLength - 40) throw new Error('Invalid large pack offset');
      const large = Number(view.getBigUint64(pos));
      if (!Number.isSafeInteger(large)) throw new Error('Pack offset exceeds safe integer range');
      return large;
    }

    const sortedOffsets = new Float64Array(numObjects);
    for (let i = 0; i < numObjects; i++) sortedOffsets[i] = offsetAt(i);
    sortedOffsets.sort();

    function findOffset(hash: Uint8Array): number | undefined {
      const prefix = hash[0];
      let lo = prefix === 0 ? 0 : view.getUint32(8 + (prefix - 1) * 4);
      let hi = view.getUint32(8 + prefix * 4);
      while (lo < hi) {
        const mid = Math.floor((lo + hi) / 2);
        const start = namesStart + mid * 20;
        let diff = 0;
        for (let i = 0; i < 20 && diff === 0; i++) diff = view.getUint8(start + i) - hash[i];
        if (diff === 0) return offsetAt(mid);
        if (diff < 0) lo = mid + 1;
        else hi = mid;
      }
      return undefined;
    }

    return { findOffset, sortedOffsets };
  } catch {
    return null;
  }
}

interface RepoPacks {
  ready: IndexedPack[];
  loading: Promise<IndexedPack | null>[];
}

const repoPacks = new LRUCache<string, Promise<RepoPacks>>(16);

async function loadPacks(tree: ReturnType<typeof getTree>, gitDirCid: CID, key: string): Promise<RepoPacks> {
  const packs: RepoPacks = { ready: [], loading: [] };
  const directory = await tree.resolvePath(gitDirCid, 'objects/pack');
  if (directory?.type !== LinkType.Dir) return packs;
  const files = await tree.listDirectory(directory.cid);
  const byName = new Map(files.map(file => [file.name, file]));
  for (const idx of files) {
    if (!idx.name.endsWith('.idx')) continue;
    const file = byName.get(idx.name.slice(0, -4) + '.pack');
    if (!file || file.type === LinkType.Dir) continue;
    const indexKey = gitDirCacheKey(idx.cid);
    let pending = packIndexCache.get(indexKey);
    if (!pending) {
      pending = readPackIndex(tree, idx);
      packIndexCache.set(indexKey, pending);
    }
    packs.loading.push(pending.then(index => {
      if (!index) {
        packIndexCache.delete(indexKey);
        repoPacks.delete(key);
        return null;
      }
      const pack = { file, index };
      packs.ready.push(pack);
      return pack;
    }));
  }
  void Promise.all(packs.loading).then(() => { packs.loading = []; });
  return packs;
}

/** Use the first index that contains the object, even while unrelated indexes are downloading. */
async function locatePackedObject(packs: RepoPacks, hash: Uint8Array) {
  for (const pack of packs.ready) {
    const offset = pack.index.findOffset(hash);
    if (offset !== undefined) return { pack, offset };
  }
  if (!packs.loading.length) return null;
  return new Promise<{ pack: IndexedPack; offset: number } | null>(resolve => {
    let remaining = packs.loading.length;
    for (const pending of packs.loading) {
      void pending.then(pack => {
        const offset = pack?.index.findOffset(hash);
        if (pack && offset !== undefined) resolve({ pack, offset });
        if (--remaining === 0) resolve(null);
      });
    }
  });
}

/**
 * Apply git delta instructions to a base object
 */
function applyDelta(base: Uint8Array, delta: Uint8Array): Uint8Array {
  let pos = 0;

  // Skip base size (variable length encoded, not needed for our purposes)
  let shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  // Read result size (variable length)
  let resultSize = 0;
  shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    resultSize |= (byte & 0x7f) << shift;
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  const result = new Uint8Array(resultSize);
  let resultPos = 0;

  while (pos < delta.length && resultPos < resultSize) {
    const cmd = delta[pos++];

    if (cmd & 0x80) {
      // Copy from base
      let copyOffset = 0;
      let copySize = 0;

      if (cmd & 0x01) copyOffset = delta[pos++];
      if (cmd & 0x02) copyOffset |= delta[pos++] << 8;
      if (cmd & 0x04) copyOffset |= delta[pos++] << 16;
      if (cmd & 0x08) copyOffset |= delta[pos++] << 24;

      if (cmd & 0x10) copySize = delta[pos++];
      if (cmd & 0x20) copySize |= delta[pos++] << 8;
      if (cmd & 0x40) copySize |= delta[pos++] << 16;

      if (copySize === 0) copySize = 0x10000;

      result.set(base.subarray(copyOffset, copyOffset + copySize), resultPos);
      resultPos += copySize;
    } else if (cmd > 0) {
      // Insert new data
      result.set(delta.subarray(pos, pos + cmd), resultPos);
      pos += cmd;
      resultPos += cmd;
    }
  }

  return result;
}

// Pack data is read one stored chunk at a time and kept in a small cache, so
// a history walk fetches each chunk it touches once, and nothing else. hashtree
// reads the chunks of a range one after another; asking for them separately
// lets cold data arrive in a round of parallel downloads instead of a chain.
const FALLBACK_BLOCK_SIZE = 2 * 1024 * 1024;
const MAX_CACHED_PACK_BYTES = 32 * 1024 * 1024;
const MAX_CACHED_CHUNKS_PER_READ = 64;
const MAX_CONCURRENT_PACK_CHUNK_READS = 8;
const MAX_FILE_NODE_DEPTH = 4;

let activePackChunkReads = 0;
const packChunkWaiters: Array<() => void> = [];

async function withPackChunkSlot<T>(task: () => Promise<T>): Promise<T> {
  if (activePackChunkReads >= MAX_CONCURRENT_PACK_CHUNK_READS) {
    await new Promise<void>(resolve => packChunkWaiters.push(resolve));
  }
  activePackChunkReads++;
  try {
    return await task();
  } finally {
    activePackChunkReads--;
    packChunkWaiters.shift()?.();
  }
}

interface ChunkSpan {
  start: number;
  end: number;
}

const fileNodeCache = new Map<string, Promise<TreeNode | null>>();

function getFileNode(tree: ReturnType<typeof getTree>, cid: CID): Promise<TreeNode | null> {
  const key = gitDirCacheKey(cid);
  let node = fileNodeCache.get(key);
  if (!node) {
    node = tree.getTreeNode(cid).catch(() => null);
    fileNodeCache.set(key, node);
    if (fileNodeCache.size > 256) fileNodeCache.delete(fileNodeCache.keys().next().value!);
  }
  return node;
}

/** Stored chunks overlapping [start, end), in order. Empty when the layout is unknown. */
async function findStoredChunks(
  tree: ReturnType<typeof getTree>,
  cid: CID,
  base: number,
  start: number,
  end: number,
  depth = 0
): Promise<ChunkSpan[]> {
  const node = await getFileNode(tree, cid);
  if (!node) return [];

  const spans: ChunkSpan[] = [];
  let position = base;
  for (const link of node.links) {
    if (!link.size) return [];
    const linkStart = position;
    position += link.size;
    if (position <= start) continue;
    if (linkStart >= end) break;

    const inner = link.type !== LinkType.Blob && depth < MAX_FILE_NODE_DEPTH
      ? await findStoredChunks(tree, { hash: link.hash, key: link.key }, linkStart, start, end, depth + 1)
      : [];
    if (inner.length > 0) spans.push(...inner);
    else spans.push({ start: linkStart, end: position });
  }
  return spans;
}

/** Spans to read for [start, end): the stored chunks, or fixed blocks when those are unknown. */
async function getReadSpans(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  start: number,
  end: number
): Promise<ChunkSpan[]> {
  const stored = await findStoredChunks(tree, file.cid, 0, start, end).catch(() => []);
  if (stored.length > 0) return stored;

  const spans: ChunkSpan[] = [];
  const first = Math.floor(start / FALLBACK_BLOCK_SIZE) * FALLBACK_BLOCK_SIZE;
  for (let from = first; from < end; from += FALLBACK_BLOCK_SIZE) {
    spans.push({ start: from, end: Math.min(from + FALLBACK_BLOCK_SIZE, file.size > 0 ? file.size : end) });
  }
  return spans;
}

async function readSpan(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  span: ChunkSpan
): Promise<Uint8Array | null> {
  const data = await withPackChunkSlot(() => tree.readFileRange(file.cid, span.start, span.end));
  return data && data.length === span.end - span.start ? data : null;
}

const packChunkCache = new Map<string, { data: Promise<Uint8Array | null>; bytes: number }>();
let packChunkCacheBytes = 0;

function readCachedChunk(
  tree: ReturnType<typeof getTree>,
  pack: TreeEntry,
  span: ChunkSpan
): Promise<Uint8Array | null> {
  const key = `${gitDirCacheKey(pack.cid)}:${span.start}`;
  const cached = packChunkCache.get(key);
  if (cached) {
    // Refresh recency.
    packChunkCache.delete(key);
    packChunkCache.set(key, cached);
    return cached.data;
  }

  const entry = { data: readSpan(tree, pack, span).catch(() => null), bytes: span.end - span.start };
  packChunkCache.set(key, entry);
  packChunkCacheBytes += entry.bytes;
  // Failed reads are retried by the next caller.
  void entry.data.then(data => {
    if (!data && packChunkCache.get(key) === entry) {
      packChunkCache.delete(key);
      packChunkCacheBytes -= entry.bytes;
    }
  });
  for (const [oldKey, old] of packChunkCache) {
    if (packChunkCacheBytes <= MAX_CACHED_PACK_BYTES || old === entry) break;
    packChunkCache.delete(oldKey);
    packChunkCacheBytes -= old.bytes;
  }
  return entry.data;
}

/** Copy [start, end) out of consecutive spans that cover it. */
function assembleRange(
  spans: ChunkSpan[],
  parts: Array<Uint8Array | null>,
  start: number,
  end: number
): Uint8Array | null {
  if (parts.length === 0 || parts.some(part => !part)) return null;
  if (spans[0].start > start || spans[spans.length - 1].end < end) return null;
  if (parts.length === 1) {
    return parts[0]!.subarray(start - spans[0].start, end - spans[0].start);
  }

  const data = new Uint8Array(end - start);
  for (let i = 0; i < spans.length; i++) {
    const from = Math.max(start, spans[i].start);
    const to = Math.min(end, spans[i].end);
    data.set(parts[i]!.subarray(from - spans[i].start, to - spans[i].start), from - start);
  }
  return data;
}

/** Read a whole range with its chunks fetched under the shared concurrency limit, bypassing the cache. */
async function readFileSpan(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  start: number,
  end: number
): Promise<Uint8Array | null> {
  const spans = await getReadSpans(tree, file, start, end);
  const parts = await Promise.all(spans.map(span => readSpan(tree, file, span)));
  return assembleRange(spans, parts, start, end);
}

const lastPackChunk = new WeakMap<TreeEntry, ChunkSpan>();

async function readPackRange(
  tree: ReturnType<typeof getTree>,
  pack: TreeEntry,
  start: number,
  end: number
): Promise<Uint8Array | null> {
  const last = lastPackChunk.get(pack);
  if (last && start >= last.start && end <= last.end) {
    const bytes = await readCachedChunk(tree, pack, last);
    return bytes?.subarray(start - last.start, end - last.start) ?? null;
  }
  const spans = await getReadSpans(tree, pack, start, end);
  if (spans.length === 1) lastPackChunk.set(pack, spans[0]);
  if (spans.length > MAX_CACHED_CHUNKS_PER_READ) {
    // A large blob: read it directly rather than flushing the chunk cache.
    return readFileSpan(tree, pack, start, end);
  }
  const parts = await Promise.all(spans.map(span => readCachedChunk(tree, pack, span)));
  return assembleRange(spans, parts, start, end);
}

// Resolved pack objects by offset. Trees are stored as long delta chains, so
// without this every tree read would re-apply the chain from its base.
const MAX_CACHED_PACK_OBJECTS = 4096;
const MAX_CACHED_PACK_OBJECT_SIZE = 256 * 1024;
const packObjectCache = new Map<string, { pending: Promise<GitObject | null>; settled: boolean }>();

async function readFromPackUncached(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  pack: IndexedPack,
  offset: number,
  depth: number,
  activeOffsets?: Set<number>
): Promise<{ type: string; content: Uint8Array } | null> {
  if (depth > 50) return null;
  try {
    const end = getPackObjectEnd(pack.file.size, pack.index.sortedOffsets, offset);
    if (end <= offset) return null;
    const data = await readPackRange(tree, pack.file, offset, end);
    if (!data) return null;
    return await readPackObjectAtOffset(data, offset, tree, gitDirCid, pack, depth, activeOffsets);
  } catch {
    return null;
  }
}

/**
 * Read object from pack file at given offset (with delta resolution)
 */
async function readFromPack(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  pack: IndexedPack,
  offset: number,
  depth = 0,
  activeOffsets?: Set<number>
): Promise<{ type: string; content: Uint8Array } | null> {
  // Prevent infinite recursion
  if (depth > 50) return null;

  const key = `${gitDirCacheKey(pack.file.cid)}:${offset}`;
  const cached = packObjectCache.get(key);
  const nextActive = activeOffsets ? new Set(activeOffsets) : new Set<number>();
  if (nextActive.has(offset)) return null;
  nextActive.add(offset);
  if (cached) {
    if (cached.settled || !activeOffsets?.size) return cached.pending;
    // A recursive delta read must not await another in-flight root: two
    // malformed deltas can otherwise await each other before either ancestry
    // guard runs. Traverse with this chain's guard; byte reads stay cached.
    return readFromPackUncached(tree, gitDirCid, pack, offset, depth, nextActive);
  }
  const pending = readFromPackUncached(tree, gitDirCid, pack, offset, depth, nextActive);
  const entry = { pending, settled: false };
  packObjectCache.set(key, entry);
  if (packObjectCache.size > MAX_CACHED_PACK_OBJECTS) {
    packObjectCache.delete(packObjectCache.keys().next().value!);
  }
  // Keep only successful, small results: failures are retried and large blobs
  // stay out of memory.
  void pending.then(object => {
    entry.settled = true;
    if ((!object || object.content.length > MAX_CACHED_PACK_OBJECT_SIZE) && packObjectCache.get(key) === entry) {
      packObjectCache.delete(key);
    }
  });
  return pending;
}

function getPackObjectEnd(packSize: number, sortedOffsets: Float64Array, offset: number): number {
  const packTrailerLength = 20;
  const packEnd = Math.max(12, packSize - packTrailerLength);

  let lo = 0;
  let hi = sortedOffsets.length;

  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (sortedOffsets[mid] <= offset) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }

  return lo < sortedOffsets.length ? Math.min(sortedOffsets[lo], packEnd) : packEnd;
}

async function readPackObjectAtOffset(
  packData: Uint8Array,
  offset: number,
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  pack: IndexedPack,
  depth = 0,
  activeOffsets?: Set<number>
): Promise<{ type: string; content: Uint8Array } | null> {
  if (depth > 50) return null;

  let pos = 0;
  let byte = packData[pos++];
  const type = (byte >> 4) & 7;
  let size = byte & 15;
  let shift = 4;

  while (byte & 0x80) {
    byte = packData[pos++];
    size |= (byte & 0x7f) << shift;
    shift += 7;
  }

  const typeNames = ['', 'commit', 'tree', 'blob', 'tag', '', 'ofs_delta', 'ref_delta'];
  const objectEnd = packData.length;

  if (objectEnd <= pos) {
    return null;
  }

  if (type === 6) {
    let negOffset = 0;
    byte = packData[pos++];
    negOffset = byte & 0x7f;
    while (byte & 0x80) {
      byte = packData[pos++];
      negOffset = ((negOffset + 1) << 7) | (byte & 0x7f);
    }
    const baseOffset = offset - negOffset;
    if (activeOffsets?.has(baseOffset)) return null;

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);
    const baseObj = await readFromPack(tree, gitDirCid, pack, baseOffset, depth + 1, activeOffsets);
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  if (type === 7) {
    const baseShaBytes = packData.subarray(pos, pos + 20);
    pos += 20;

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);

    const baseOffset = pack.index.findOffset(baseShaBytes);
    let baseObj: { type: string; content: Uint8Array } | null = null;
    if (baseOffset !== undefined) {
      if (activeOffsets?.has(baseOffset)) return null;
      baseObj = await readFromPack(tree, gitDirCid, pack, baseOffset, depth + 1, activeOffsets);
    } else {
      baseObj = await readGitObject(tree, gitDirCid, toHex(baseShaBytes));
    }
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  const compressedData = packData.subarray(pos, objectEnd);
  const decompressed = await decompressZlib(compressedData);
  return { type: typeNames[type], content: decompressed.subarray(0, size) };
}

// Loose object directories are listed once per git directory, so a fully
// packed repository answers every loose lookup without touching the store.
const looseDirCache = new LRUCache<string, Promise<Map<string, TreeEntry>>>(512);

function listLooseDir(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  path: string,
  directoryCid?: CID,
): Promise<Map<string, TreeEntry>> {
  const key = `${gitDirCacheKey(gitDirCid)}:${path}`;
  let listing = looseDirCache.get(key);
  if (!listing) {
    listing = (async () => {
      const dir = directoryCid ? { cid: directoryCid, type: LinkType.Dir } : await tree.resolvePath(gitDirCid, path);
      if (dir?.type !== LinkType.Dir) return new Map<string, TreeEntry>();
      return new Map((await tree.listDirectory(dir.cid)).map(entry => [entry.name, entry]));
    })();
    looseDirCache.set(key, listing);
    // A failed listing is retried by the next lookup.
    listing.catch(() => looseDirCache.delete(key));
  }
  return listing;
}

async function findLooseObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<CID | null> {
  const prefix = sha.slice(0, 2);
  const fanout = (await listLooseDir(tree, gitDirCid, 'objects')).get(prefix);
  if (!fanout || fanout.type !== LinkType.Dir) return null;
  const entry = (await listLooseDir(tree, gitDirCid, `objects/${prefix}`, fanout.cid)).get(sha.slice(2));
  return entry && entry.type !== LinkType.Dir ? entry.cid : null;
}

async function readLooseObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string,
): Promise<GitObject | null> {
  try {
    const cid = await findLooseObject(tree, gitDirCid, sha);
    if (!cid) return null;
    const compressed = await tree.readFile(cid);
    if (!compressed) return null;
    const data = await decompressZlib(compressed);
    const end = data.indexOf(0);
    if (end < 0) return null;
    const header = new TextDecoder().decode(data.subarray(0, end));
    return { type: header.split(' ')[0], content: data.subarray(end + 1) };
  } catch {
    return null;
  }
}

async function readGitObjectInternal(tree: ReturnType<typeof getTree>, gitDirCid: CID, sha: string): Promise<GitObject | null> {
  const key = gitDirCacheKey(gitDirCid);
  let pending = repoPacks.get(key);
  const checkedLoose = !pending;
  if (!pending) {
    // Recent commits are often loose. They can be displayed before downloading any indexes.
    const loose = await readLooseObject(tree, gitDirCid, sha);
    if (loose) return loose;
    pending = repoPacks.get(key);
    if (!pending) {
      pending = loadPacks(tree, gitDirCid, key);
      repoPacks.set(key, pending);
      pending.catch(() => repoPacks.delete(key));
    }
  }

  const match = await locatePackedObject(await pending, fromHex(sha));
  if (match) {
    const object = await readFromPack(tree, gitDirCid, match.pack, match.offset);
    if (object) return object;
  }
  return checkedLoose ? null : readLooseObject(tree, gitDirCid, sha);
}

/** Asked for an object that the repository's packs and loose objects do not have. */
export type MissingGitObjectSource = (gitDirCid: CID, sha: string) => Promise<GitObject | null>;

let missingGitObjectSource: MissingGitObjectSource | null = null;

/** A partial clone sets this to fetch omitted objects on demand. */
export function setMissingGitObjectSource(source: MissingGitObjectSource | null): void {
  missingGitObjectSource = source;
}

async function readGitObjectWithFallback(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<GitObject | null> {
  const object = await readGitObjectInternal(tree, gitDirCid, sha);
  if (object || !missingGitObjectSource) return object;
  return missingGitObjectSource(gitDirCid, sha);
}

/**
 * Read and parse a git object from hashtree (loose or packed)
 */
export async function readGitObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<GitObject | null> {
  const cacheKey = `${gitDirCacheKey(gitDirCid)}:${sha}`;
  const cached = gitObjectCache.get(cacheKey);
  if (cached) return cached;

  const pending = readGitObjectWithFallback(tree, gitDirCid, sha);
  gitObjectCache.set(cacheKey, pending);
  try {
    const object = await pending;
    if (object && object.content.length <= MAX_CACHED_PACK_OBJECT_SIZE) return object;
    if (gitObjectCache.get(cacheKey) === pending) gitObjectCache.delete(cacheKey);
    return object;
  } catch (error) {
    if (gitObjectCache.get(cacheKey) === pending) gitObjectCache.delete(cacheKey);
    throw error;
  }
}
