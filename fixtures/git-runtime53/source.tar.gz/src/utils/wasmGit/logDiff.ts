import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { decodeAsText, getTree } from '../../store';
import { buildUnifiedDiff, type UnifiedDiffFile, type UnifiedDiffRenderedFile } from '../gitDiffText';
import { getErrorMessage } from '../errorMessage';
import { getCommitInfo, resolveRevisionToCommit } from './logHistory';
import { getParsedCommitFromSha } from './logObjects';
import { readGitObject } from './logPacks';
import { readTreeEntries, getTreeEntryAtPath, parseGitTree } from './logTrees';
import type { CommitTreeEntry, DiffEntry } from './logTypes';

const BLOB_READ_CONCURRENCY = 8;
const MAX_ANCESTOR_WALK = 5000;

async function collectTreeFiles(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  prefix: string,
  status: 'added' | 'deleted',
  result: DiffEntry[]
): Promise<void> {
  const entries = await readTreeEntries(tree, gitDirCid, treeSha);
  const subdirs: Array<{ hash: string; path: string }> = [];

  for (const [name, entry] of entries) {
    const path = prefix ? `${prefix}/${name}` : name;
    if (entry.mode === '40000') {
      subdirs.push({ hash: entry.hash, path });
    } else if (status === 'added') {
      result.push({ path, status, newHash: entry.hash, newMode: entry.mode });
    } else {
      result.push({ path, status, oldHash: entry.hash, oldMode: entry.mode });
    }
  }

  if (subdirs.length > 0) {
    await Promise.all(
      subdirs.map(sub => collectTreeFiles(tree, gitDirCid, sub.hash, sub.path, status, result))
    );
  }
}

async function diffTreeObjects(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  fromTreeSha: string,
  toTreeSha: string,
  prefix: string,
  result: DiffEntry[]
): Promise<void> {
  if (fromTreeSha === toTreeSha) return;

  const [fromEntries, toEntries] = await Promise.all([
    readTreeEntries(tree, gitDirCid, fromTreeSha),
    readTreeEntries(tree, gitDirCid, toTreeSha),
  ]);

  const names = new Set([...fromEntries.keys(), ...toEntries.keys()]);
  const tasks: Promise<void>[] = [];

  for (const name of names) {
    const fromEntry = fromEntries.get(name);
    const toEntry = toEntries.get(name);
    const path = prefix ? `${prefix}/${name}` : name;

    if (!fromEntry && toEntry) {
      if (toEntry.mode === '40000') {
        tasks.push(collectTreeFiles(tree, gitDirCid, toEntry.hash, path, 'added', result));
      } else {
        result.push({ path, status: 'added', newHash: toEntry.hash, newMode: toEntry.mode });
      }
      continue;
    }

    if (fromEntry && !toEntry) {
      if (fromEntry.mode === '40000') {
        tasks.push(collectTreeFiles(tree, gitDirCid, fromEntry.hash, path, 'deleted', result));
      } else {
        result.push({ path, status: 'deleted', oldHash: fromEntry.hash, oldMode: fromEntry.mode });
      }
      continue;
    }

    if (!fromEntry || !toEntry) continue;
    if (fromEntry.hash === toEntry.hash && fromEntry.mode === toEntry.mode) continue;

    if (fromEntry.mode === '40000' && toEntry.mode === '40000') {
      tasks.push(diffTreeObjects(tree, gitDirCid, fromEntry.hash, toEntry.hash, path, result));
      continue;
    }

    if (fromEntry.mode === '40000') {
      tasks.push(collectTreeFiles(tree, gitDirCid, fromEntry.hash, path, 'deleted', result));
      result.push({ path, status: 'added', newHash: toEntry.hash, newMode: toEntry.mode });
      continue;
    }

    if (toEntry.mode === '40000') {
      result.push({ path, status: 'deleted', oldHash: fromEntry.hash, oldMode: fromEntry.mode });
      tasks.push(collectTreeFiles(tree, gitDirCid, toEntry.hash, path, 'added', result));
      continue;
    }

    result.push({
      path,
      status: 'modified',
      oldHash: fromEntry.hash,
      newHash: toEntry.hash,
      oldMode: fromEntry.mode,
      newMode: toEntry.mode,
    });
  }

  if (tasks.length > 0) await Promise.all(tasks);
}

async function resolveGitDir(tree: ReturnType<typeof getTree>, rootCid: CID): Promise<CID | null> {
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  return gitDirResult?.type === LinkType.Dir ? gitDirResult.cid : null;
}

async function readBlobBytes(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string | undefined,
  mode?: string,
): Promise<Uint8Array | null> {
  if (!sha) return null;
  // Gitlinks name commits in another repository; their objects are not blobs
  // in this repository and need no network fetch to render a short diff.
  if (mode === '160000') return new TextEncoder().encode(`Subproject commit ${sha}\n`);
  const obj = await readGitObject(tree, gitDirCid, sha);
  if (!obj || obj.type !== 'blob') throw new Error('Git blob unavailable');
  return obj.content;
}

/**
 * Load old/new blob bytes directly by the blob SHAs returned from tree diffing,
 * avoiding redundant root-to-file tree traversals and bounding concurrency.
 */
async function readDiffEntries(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  diffEntries: DiffEntry[],
): Promise<UnifiedDiffFile[]> {
  if (diffEntries.length === 0) return [];
  const files = new Array<UnifiedDiffFile>(diffEntries.length);
  let next = 0;
  const workerCount = Math.min(BLOB_READ_CONCURRENCY, diffEntries.length);
  await Promise.all(Array.from({ length: workerCount }, async () => {
    while (next < diffEntries.length) {
      const index = next++;
      const entry = diffEntries[index];
      const [oldBytes, newBytes] = await Promise.all([
        entry.status !== 'added' ? readBlobBytes(tree, gitDirCid, entry.oldHash, entry.oldMode) : Promise.resolve(null),
        entry.status !== 'deleted' ? readBlobBytes(tree, gitDirCid, entry.newHash, entry.newMode) : Promise.resolve(null),
      ]);
      files[index] = {
        path: entry.path,
        status: entry.status,
        oldMode: entry.oldMode,
        newMode: entry.newMode,
        oldBytes: oldBytes ?? undefined,
        newBytes: newBytes ?? undefined,
        oldText: oldBytes ? decodeAsText(oldBytes) ?? undefined : undefined,
        newText: newBytes ? decodeAsText(newBytes) ?? undefined : undefined,
      };
    }
  }));
  return files;
}

async function isAncestorWithGitDir(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  ancestorSha: string,
  descendantSha: string,
): Promise<boolean> {
  const target = ancestorSha.toLowerCase();
  const start = descendantSha.toLowerCase();
  if (target === start) return true;

  const visited = new Set<string>([start]);
  const queue = [start];

  while (queue.length > 0 && visited.size < MAX_ANCESTOR_WALK) {
    const batch = queue.splice(0, 16);
    const parsed = await Promise.all(batch.map(sha => getParsedCommitFromSha(tree, gitDirCid, sha)));
    for (const commit of parsed) {
      if (!commit) continue;
      for (const parent of commit.parents) {
        const normalized = parent.toLowerCase();
        if (normalized === target) return true;
        if (!visited.has(normalized)) {
          visited.add(normalized);
          queue.push(normalized);
        }
      }
    }
  }
  return false;
}

/** Check whether `ancestorSha` is reachable from `descendantSha` via parent links. */
export async function isAncestorCommit(
  rootCid: CID,
  ancestorSha: string,
  descendantSha: string,
): Promise<boolean> {
  const tree = getTree();
  const gitDirCid = await resolveGitDir(tree, rootCid);
  return gitDirCid ? isAncestorWithGitDir(tree, gitDirCid, ancestorSha, descendantSha) : false;
}

async function diffCommitShas(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  fromSha: string,
  toSha: string,
): Promise<DiffEntry[]> {
  const [fromParsed, toParsed] = await Promise.all([
    getParsedCommitFromSha(tree, gitDirCid, fromSha),
    getParsedCommitFromSha(tree, gitDirCid, toSha),
  ]);
  if (!fromParsed || !toParsed) throw new Error('Git commit unavailable');
  const result: DiffEntry[] = [];
  await diffTreeObjects(tree, gitDirCid, fromParsed.tree, toParsed.tree, '', result);
  result.sort((a, b) => a.path.localeCompare(b.path));
  return result;
}

export async function diffBranchesNative(
  rootCid: CID,
  baseBranch: string,
  headBranch: string,
): Promise<{
  diff: string;
  stats: { additions: number; deletions: number; files: string[] };
  canFastForward: boolean;
  error?: string;
}> {
  const empty = { diff: '', stats: { additions: 0, deletions: 0, files: [] as string[] } };
  const tree = getTree();
  const gitDirCid = await resolveGitDir(tree, rootCid);
  if (!gitDirCid) return { ...empty, canFastForward: false, error: 'Not a git repository' };

  const [baseSha, headSha] = await Promise.all([
    resolveRevisionToCommit(rootCid, baseBranch),
    resolveRevisionToCommit(rootCid, headBranch),
  ]);
  if (!baseSha || !headSha) {
    return { ...empty, canFastForward: false, error: `Branch or ref not found: ${!baseSha ? baseBranch : headBranch}` };
  }
  if (baseSha === headSha) return { ...empty, canFastForward: true };

  try {
    const [diffEntries, canFastForward] = await Promise.all([
      diffCommitShas(tree, gitDirCid, baseSha, headSha),
      isAncestorWithGitDir(tree, gitDirCid, baseSha, headSha),
    ]);
    const { text, stats, files } = buildUnifiedDiff(await readDiffEntries(tree, gitDirCid, diffEntries));
    return {
      diff: text,
      stats: { additions: stats.additions, deletions: stats.deletions, files: files.map(file => file.path) },
      canFastForward,
    };
  } catch (error) {
    return { ...empty, canFastForward: false, error: getErrorMessage(error) };
  }
}

export async function getCommitDiffEntries(rootCid: CID, ref: string): Promise<DiffEntry[]> {
  const tree = getTree();
  const gitDirCid = await resolveGitDir(tree, rootCid);
  const commit = gitDirCid ? await getCommitInfo(rootCid, ref) : null;
  if (!gitDirCid || !commit) return [];
  if (!commit.parent[0]) {
    const result: DiffEntry[] = [];
    await collectTreeFiles(tree, gitDirCid, commit.tree, '', 'added', result);
    result.sort((a, b) => a.path.localeCompare(b.path));
    return result;
  }
  return diffCommitShas(tree, gitDirCid, commit.parent[0], commit.oid);
}

/**
 * Get diff between two commits
 * Native implementation - no wasm-git needed
 */
export async function getDiff(
  rootCid: CID,
  fromCommit: string,
  toCommit: string
): Promise<DiffEntry[]> {
  const tree = getTree();
  const startTime = performance.now();
  const gitDirCid = await resolveGitDir(tree, rootCid);
  if (!gitDirCid) return [];

  try {
    const [fromSha, toSha] = await Promise.all([
      resolveRevisionToCommit(rootCid, fromCommit),
      resolveRevisionToCommit(rootCid, toCommit),
    ]);
    if (!fromSha || !toSha) return [];

    const result = await diffCommitShas(tree, gitDirCid, fromSha, toSha);
    const elapsed = performance.now() - startTime;
    if (elapsed >= 50) {
      console.log(`[git perf] getDiff completed in ${elapsed.toFixed(0)} ms (files=${result.length})`);
    }
    return result;
  } catch (err) {
    console.error('[git] getDiff failed:', err);
    return [];
  }
}

export async function getCommitViewDataNative(rootCid: CID, commitRef: string): Promise<{
  commit: {
    oid: string;
    message: string;
    author: string;
    email: string;
    timestamp: number;
    parent: string[];
  };
  diffText: string;
  stats: { additions: number; deletions: number; files: number };
  files: Array<UnifiedDiffRenderedFile & {
    canViewFile: boolean;
    viewCommit: string | null;
  }>;
} | null> {
  const tree = getTree();
  const [gitDirCid, commit] = await Promise.all([
    resolveGitDir(tree, rootCid),
    getCommitInfo(rootCid, commitRef),
  ]);
  if (!gitDirCid || !commit) return null;

  let diffEntries: DiffEntry[];
  if (!commit.parent[0]) {
    diffEntries = [];
    await collectTreeFiles(tree, gitDirCid, commit.tree, '', 'added', diffEntries);
    diffEntries.sort((a, b) => a.path.localeCompare(b.path));
  } else {
    diffEntries = await diffCommitShas(tree, gitDirCid, commit.parent[0], commit.oid);
  }

  const { text, stats, files } = buildUnifiedDiff(await readDiffEntries(tree, gitDirCid, diffEntries));
  return {
    commit: {
      oid: commit.oid,
      message: commit.message,
      author: commit.author,
      email: commit.email,
      timestamp: commit.timestamp,
      parent: commit.parent,
    },
    diffText: text,
    stats,
    files: files.map((file) => ({
      ...file,
      canViewFile: file.status !== 'deleted',
      viewCommit: file.status === 'deleted' ? null : commit.oid,
    })),
  };
}

/**
 * Get file content at a specific commit
 * Native implementation - no wasm-git needed
 */
export async function getFileAtCommit(
  rootCid: CID,
  commitSha: string,
  filePath: string
): Promise<Uint8Array | null> {
  const htree = getTree();

  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  try {
    const resolvedSha = await resolveRevisionToCommit(rootCid, commitSha);
    if (!resolvedSha) return null;

    const commit = await getParsedCommitFromSha(htree, gitDirResult.cid, resolvedSha);
    if (!commit) return null;

    const entry = await getTreeEntryAtPath(htree, gitDirResult.cid, commit.tree, filePath);
    if (!entry || isTreeMode(entry.mode)) return null;

    const blobObj = await readGitObject(htree, gitDirResult.cid, entry.hash);
    if (!blobObj || blobObj.type !== 'blob') return null;
    return blobObj.content;
  } catch (err) {
    console.error('[git] getFileAtCommit failed:', err);
    return null;
  }
}

function isTreeMode(mode: string): boolean {
  return mode === '40000' || mode === '040000';
}

async function collectCommitTreeEntries(
  htree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  prefix: string,
  entries: CommitTreeEntry[]
): Promise<void> {
  const treeObj = await readGitObject(htree, gitDirCid, treeSha);
  if (!treeObj || treeObj.type !== 'tree') return;

  for (const entry of parseGitTree(treeObj.content)) {
    const entryPath = prefix ? `${prefix}/${entry.name}` : entry.name;

    if (isTreeMode(entry.mode)) {
      entries.push({ name: entryPath, data: new Uint8Array(0), isDir: true });
      await collectCommitTreeEntries(htree, gitDirCid, entry.hash, entryPath, entries);
      continue;
    }

    const blobObj = await readGitObject(htree, gitDirCid, entry.hash);
    if (!blobObj || blobObj.type !== 'blob') continue;
    entries.push({ name: entryPath, data: blobObj.content, isDir: false });
  }
}

export async function getCommitTreeEntries(rootCid: CID, ref: string): Promise<CommitTreeEntry[]> {
  const htree = getTree();

  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return [];
  }

  const resolvedSha = await resolveRevisionToCommit(rootCid, ref);
  if (!resolvedSha) return [];

  const commit = await getParsedCommitFromSha(htree, gitDirResult.cid, resolvedSha);
  if (!commit) return [];

  const entries: CommitTreeEntry[] = [];
  await collectCommitTreeEntries(htree, gitDirResult.cid, commit.tree, '', entries);
  return entries;
}
