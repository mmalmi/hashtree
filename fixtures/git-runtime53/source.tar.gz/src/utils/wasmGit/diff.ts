/**
 * Branch merge conflict check using wasm-git.
 * Fast-forward checks and branch diffs run natively via logDiff.ts.
 */
import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { getTree } from '../../store';
import { withWasmGitLock, loadWasmGit, copyToWasmFS, createRepoPath, fixBareConfig, rmRf } from './core';

export interface BranchDiffStats {
  additions: number;
  deletions: number;
  files: string[];
}

export interface BranchDiffResult {
  diff: string;
  stats: BranchDiffStats;
  canFastForward: boolean;
  error?: string;
}

/**
 * Check if non-fast-forward branches can be merged without conflicts
 */
export async function canMergeWasm(
  rootCid: CID,
  baseBranch: string,
  headBranch: string
): Promise<{ canMerge: boolean; conflicts: string[]; isFastForward: boolean; error?: string }> {
  return withWasmGitLock(async () => {
    const tree = getTree();

    const gitDirResult = await tree.resolvePath(rootCid, '.git');
    if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
      return { canMerge: false, conflicts: [], isFastForward: false, error: 'Not a git repository' };
    }

    const module = await loadWasmGit();
    const repoPath = createRepoPath();
    const originalCwd = module.FS.cwd();

    try {
      module.FS.mkdir(repoPath);
      module.FS.chdir(repoPath);

      await copyToWasmFS(module, rootCid, '.');
      fixBareConfig(module);

      let isFastForward = false;
      try {
        const mergeBase = (module.callWithOutput(['merge-base', baseBranch, headBranch]) || '').trim();
        const baseCommit = (module.callWithOutput(['rev-parse', baseBranch]) || '').trim();
        isFastForward = !!mergeBase && mergeBase === baseCommit;
      } catch {
        isFastForward = false;
      }

      if (isFastForward) {
        return { canMerge: true, conflicts: [], isFastForward: true };
      }

      try {
        module.callWithOutput(['checkout', baseBranch]);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        return { canMerge: false, conflicts: [], isFastForward: false, error: `Failed to checkout ${baseBranch}: ${errorMsg}` };
      }

      try {
        module.callWithOutput(['merge', '--no-commit', '--no-ff', headBranch]);
        try {
          module.callWithOutput(['merge', '--abort']);
        } catch {
          // Ignore abort errors
        }
        return { canMerge: true, conflicts: [], isFastForward: false };
      } catch {
        const conflicts: string[] = [];
        try {
          const statusOutput = module.callWithOutput(['status', '--porcelain']) || '';
          for (const line of statusOutput.split('\n')) {
            if (/^(UU|AA|DD|AU|UA|DU|UD)/.test(line)) {
              const file = line.slice(3).trim();
              if (file) conflicts.push(file);
            }
          }
        } catch {
          // Can't get status
        }

        try {
          module.callWithOutput(['merge', '--abort']);
        } catch {
          // Ignore abort errors
        }

        return { canMerge: conflicts.length === 0, conflicts, isFastForward: false };
      }
    } catch (err) {
      console.error('[wasm-git] canMerge failed:', err);
      return { canMerge: false, conflicts: [], isFastForward: false, error: err instanceof Error ? err.message : String(err) };
    } finally {
      try {
        module.FS.chdir(originalCwd);
      } catch {
        // Ignore
      }
      rmRf(module, repoPath);
    }
  });
}
