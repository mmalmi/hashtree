import { LinkType, type CID } from '@hashtree/core';
import { getTree } from '../../store';
import { readPublicFileHistory } from '../publicGitFileHistory';
import { getHead } from './logHead';
import { getParsedCommitFromSha } from './logObjects';
import { getTreeEntryAtPath, readTreeEntries } from './logTrees';
import type { CommitInfo } from './logTypes';

type FileCommit = Pick<CommitInfo, 'oid' | 'message' | 'timestamp'>;

export async function getFileLastCommits(
  rootCid: CID,
  filenames: string[],
  subpath = '',
  onProgress?: (filename: string, commit: FileCommit) => void,
  signal?: AbortSignal,
  publicDirectory?: string,
): Promise<Map<string, FileCommit>> {
  const result = new Map<string, FileCommit>();
  const names = [...new Set(filenames)].filter(name => name !== '.git');
  if (!names.length || signal?.aborted) return result;

  const startTime = performance.now();
  const tree = getTree();
  const previous = publicDirectory ? readPublicFileHistory(publicDirectory) : undefined;
  const gitDir = await tree.resolvePath(rootCid, '.git');
  if (gitDir?.type !== LinkType.Dir) return result;
  const gitCid = gitDir.cid;

  async function readDirectory(oid: string) {
    const commit = await getParsedCommitFromSha(tree, gitCid, oid);
    if (!commit) throw new Error('Commit unavailable');
    const entry = await getTreeEntryAtPath(tree, gitCid, commit.tree, subpath);
    return { oid, commit, directory: entry?.mode === '40000' ? entry.hash : null };
  }
  const entriesFor = (sha: string | null) => sha ? readTreeEntries(tree, gitCid, sha) : null;

  // Parent commit IDs form a chain, but their tree reads are independent.
  // Look ahead on linear stretches only. Merges still choose a parent per path.
  const upcoming = new Map<string, ReturnType<typeof readDirectory>>();
  let active = true;
  let savedHead: string | undefined;
  async function warmFirstParents(oid: string) {
    for (let i = 0; i < 8 && active && !signal?.aborted && upcoming.size < 8; i++) {
      if (oid === savedHead || upcoming.has(oid)) return;
      const pending = readDirectory(oid);
      upcoming.set(oid, pending);
      const snapshot = await pending;
      if (!active || signal?.aborted) return;
      void entriesFor(snapshot.directory)?.catch(() => {});
      if (snapshot.commit.parents.length !== 1) return;
      oid = snapshot.commit.parents[0];
    }
  }

  try {
    const [head, saved] = await Promise.all([getHead(rootCid), previous]);
    savedHead = saved?.head;
    if (!head || signal?.aborted) return result;
    // A matching blob alone cannot prove a last change (it may have been
    // reverted). Reuse rows only at a commit reached by Git's path history.
    function applySaved(oid: string, remaining: string[]) {
      if (oid !== saved?.head) return remaining;
      return remaining.filter(name => {
        const info = saved.rows.get(name);
        if (!info || signal?.aborted) return true;
        result.set(name, info);
        onProgress?.(name, info);
        return false;
      });
    }

    const unresolved = applySaved(head, names);
    if (!unresolved.length || signal?.aborted) return result;
    const tip = await readDirectory(head);
    // The tip tree and first parent can arrive independently.
    const headEntriesPromise = Promise.resolve(entriesFor(tip.directory));
    // A parent read may fail or stall before we await the tip.
    void headEntriesPromise.catch(() => {});
    let lastYield = performance.now();
    let frontier = [{ snapshot: tip, names: unresolved }];

    // Each name follows the first parent with the same entry (Git's path-limited
    // history). Until its last change is found, that entry still matches HEAD.
    while (frontier.length && !signal?.aborted) {
      if (performance.now() - lastYield >= 12) {
        await new Promise(resolve => setTimeout(resolve, 0));
        lastYield = performance.now();
        if (signal?.aborted) break;
      }
      const next: typeof frontier = [];
      const completed = await Promise.allSettled(frontier.map(async ({ snapshot, names: remaining }) => {
        if (snapshot.oid !== head) remaining = applySaved(snapshot.oid, remaining);
        if (!remaining.length) return;
        for (const parentOid of snapshot.commit.parents) {
          if (!remaining.length || signal?.aborted) break;
          if (snapshot.commit.parents.length === 1 && !upcoming.has(parentOid)) {
            void warmFirstParents(parentOid).catch(() => {});
          }
          const parent = await (upcoming.get(parentOid) ?? readDirectory(parentOid));
          upcoming.delete(parentOid);
          if (parent.directory === snapshot.directory) {
            next.push({ snapshot: parent, names: remaining });
            return;
          }

          const [headEntries, entries] = await Promise.all([headEntriesPromise, entriesFor(parent.directory)]);
          const unchanged: string[] = [];
          const changed: string[] = [];
          for (const name of remaining) {
            const current = headEntries?.get(name);
            const previous = entries?.get(name);
            if (current?.hash === previous?.hash && current?.mode === previous?.mode) {
              unchanged.push(name);
            } else {
              changed.push(name);
            }
          }
          if (unchanged.length) next.push({ snapshot: parent, names: unchanged });
          remaining = changed;
        }

        const headEntries = await headEntriesPromise;
        const { message, timestamp, parents } = snapshot.commit;
        const info = { oid: snapshot.oid, message, timestamp };
        for (const name of remaining) {
          if (signal?.aborted) return;
          if (!parents.length && !headEntries?.has(name)) continue;
          result.set(name, info);
          onProgress?.(name, info);
        }
      }));
      for (const branch of completed) {
        if (branch.status === 'rejected') console.error('[git] Incomplete file history:', branch.reason);
      }
      frontier = next;
    }
    console.log(`[git perf] getFileLastCommits completed in ${(performance.now() - startTime).toFixed(0)} ms`);
  } catch (err) {
    console.error('[git] getFileLastCommits failed:', err);
  } finally {
    active = false;
  }
  return result;
}
