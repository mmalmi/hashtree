import type { CID } from '@hashtree/core';
import { LRUCache } from '../lruCache';
import { getTree } from '../../store';
import { readGitObject } from './logPacks';

const textDecoder = new TextDecoder();
const HEX = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, '0'));

export function parseGitTree(content: Uint8Array): Array<{ mode: string; name: string; hash: string }> {
  const entries: Array<{ mode: string; name: string; hash: string }> = [];
  let pos = 0;

  while (pos < content.length) {
    // Find space (separates mode from name)
    let spacePos = pos;
    while (spacePos < content.length && content[spacePos] !== 0x20) spacePos++;
    const mode = textDecoder.decode(content.subarray(pos, spacePos));

    // Find null (separates name from hash)
    let nullPos = spacePos + 1;
    while (nullPos < content.length && content[nullPos] !== 0) nullPos++;
    const name = textDecoder.decode(content.subarray(spacePos + 1, nullPos));

    // Hash is 20 bytes after null
    let hash = '';
    const hashEnd = Math.min(nullPos + 21, content.length);
    for (let i = nullPos + 1; i < hashEnd; i++) hash += HEX[content[i]];

    entries.push({ mode, name, hash });
    pos = nullPos + 21;
  }

  return entries;
}

// Tree objects are immutable, so cache parsed entry maps by tree SHA.
type TreeEntries = Map<string, { hash: string; mode: string }>;
const treeEntriesCache = new LRUCache<string, TreeEntries>(512);
const treeEntriesPendingCache = new Map<string, Promise<TreeEntries>>();

export async function readTreeEntries(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string
): Promise<TreeEntries> {
  const cached = treeEntriesCache.get(treeSha);
  if (cached) {
    return cached;
  }

  const pending = treeEntriesPendingCache.get(treeSha);
  if (pending) {
    return pending;
  }

  const loadPromise = (async () => {
    const obj = await readGitObject(tree, gitDirCid, treeSha);
    if (!obj || obj.type !== 'tree') {
      throw new Error('Git tree unavailable');
    }

    const entries = new Map<string, { hash: string; mode: string }>();
    for (const entry of parseGitTree(obj.content)) {
      entries.set(entry.name, { hash: entry.hash, mode: entry.mode });
    }
    treeEntriesCache.set(treeSha, entries);
    return entries;
  })();

  treeEntriesPendingCache.set(treeSha, loadPromise);

  try {
    return await loadPromise;
  } finally {
    treeEntriesPendingCache.delete(treeSha);
  }
}

export function getTreeEntriesMap(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string
): Promise<TreeEntries> {
  return readTreeEntries(tree, gitDirCid, treeSha).catch(() => new Map());
}

export async function getTreeEntryAtPath(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  path: string,
): Promise<{ hash: string; mode: string } | null> {
  let entry = { hash: treeSha, mode: '40000' };
  if (!path) return entry;
  for (const part of path.split('/')) {
    if (entry.mode !== '40000') return null;
    const entries = await readTreeEntries(tree, gitDirCid, entry.hash);
    const child = entries.get(part);
    if (!child) return null;
    entry = child;
  }
  return entry;
}
