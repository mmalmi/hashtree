/**
 * Git utilities. Read-only history paths prefer native hashtree readers and
 * fall back to wasm-git only when needed; write paths still use wasm-git.
 */
import type { CID } from '@hashtree/core';
import { LinkType, toHex } from '@hashtree/core';
import { getTree } from '../store';
import type { UnifiedDiffRenderedFile } from './gitDiffText';
import { fitsBackgroundGitBudget } from './gitSnapshotBudget';
import { LRUCache } from './lruCache';
import { trackContentLoad } from '../lib/routeRootPriority';
import type { GitRefsResult } from './wasmGit';
import { isIncompleteLog } from './wasmGit/logTypes';
import type { GitStatusResult } from './wasmGit/status';
export { runGitCommand, type RunGitCommandOptions, type RunGitCommandResult } from './gitCommands';
export { applyGitChanges, checkoutCommit } from './gitTreeWrites';

export function cidCacheKey(cid: CID | null | undefined): string | null {
  if (!cid) return null;
  return cid.key ? `${toHex(cid.hash)}:${toHex(cid.key)}` : toHex(cid.hash);
}

/**
 * Cache for file commit info, keyed by git repo hash
 * Each entry maps full file paths to their commit info
 */
type FileCommitInfo = { oid: string; message: string; timestamp: number };
const fileCommitsCache = new LRUCache<string, Map<string, FileCommitInfo>>(20);

/**
 * Cache for git log (commits), keyed by "hash:depth"
 */
type CommitLog = Array<{
  oid: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent: string[];
}>;
const gitLogCache = new LRUCache<string, CommitLog>(20);
const pendingLogs = new Map<string, Promise<CommitLog>>();

/**
 * Cache for HEAD commit SHA, keyed by git repo hash
 */
const gitHeadCache = new LRUCache<string, string | null>(20);

/**
 * Cache for git refs info, keyed by git repo hash
 */
const gitRefsCache = new LRUCache<string, GitRefsResult>(20);
const pendingRefs = new Map<string, Promise<GitRefsResult>>();

/**
 * Cache for git status, keyed by git repo hash
 */
const gitStatusCache = new LRUCache<string, GitStatusResult>(20);

export interface GitRefsProgressOptions {
  onCurrentBranch?: (branch: string) => void;
  onBranches?: (refs: Pick<GitRefsResult, 'branches' | 'currentBranch'>) => void;
  onRefNames?: (refs: Omit<GitRefsResult, 'tagsByCommit'>) => void;
}

export interface CloneOptions {
  url: string;
  /** Optional branch/ref to checkout (default: default branch) */
  ref?: string;
  /** Shallow clone depth (default: full clone) */
  depth?: number;
  /** Progress callback */
  onProgress?: (phase: string, loaded: number, total: number) => void;
}

export interface CloneResult {
  /** Root CID of the cloned repository */
  rootCid: CID;
  /** Current branch/ref */
  ref: string;
}

/**
 * Clone a git repository into hashtree storage
 * Note: Clone functionality requires network access and CORS proxy
 */
export async function cloneRepo(_options: CloneOptions): Promise<CloneResult> {
  // Clone is complex with wasm-git - requires CORS proxy setup
  // For now, throw not implemented
  throw new Error('Clone not yet implemented with wasm-git. Upload a git repo folder instead.');
}

/**
 * Get commit log for a repository
 * Results are cached by git repo hash for fast navigation
 * Uses the native hashtree reader first, with a wasm-git fallback
 */
export async function getLog(rootCid: CID, options?: { depth?: number }): Promise<CommitLog>;
export async function getLog(rootCid: CID, options: { depth?: number; debug: true }): Promise<{ commits: CommitLog; debug: string[] }>;
export async function getLog(rootCid: CID, options?: { depth?: number; debug?: boolean }): Promise<CommitLog | { commits: CommitLog; debug: string[] }> {
  const depth = options?.depth ?? 20;
  const cacheKey = `${cidCacheKey(rootCid)}:${depth}`;
  if (options?.debug) return readLog(rootCid, depth, cacheKey);
  const cached = gitLogCache.get(cacheKey) ?? pendingLogs.get(cacheKey);
  if (cached) return cached;

  const pending = readLog(rootCid, depth, cacheKey).then(result => result.commits);
  pendingLogs.set(cacheKey, pending);
  try {
    return await pending;
  } finally {
    pendingLogs.delete(cacheKey);
  }
}

async function readLog(rootCid: CID, depth: number, cacheKey: string) {
  const debugInfo: string[] = [];
  try {
    const { getLog, getLogWasm, getHead } = await import('./wasmGit');
    debugInfo.push('Using native git reader');
    let commits = await getLog(rootCid, { depth });
    debugInfo.push(`Found ${commits.length} commits`);

    const incomplete = isIncompleteLog(commits, depth);
    if (incomplete || (!commits.length && await getHead(rootCid))) {
      const gitDir = await getTree().resolvePath(rootCid, '.git');
      if (gitDir?.type === LinkType.Dir && await fitsBackgroundGitBudget(gitDir.cid)) {
        debugInfo.push('Trying wasm-git for the incomplete log');
        const recovered = await getLogWasm(rootCid, { depth });
        if (recovered.length > commits.length) commits = recovered;
      }
    }

    // Leave incomplete reads retryable while their objects are arriving.
    if (commits.length > 0 && !isIncompleteLog(commits, depth)) {
      gitLogCache.set(cacheKey, commits);
    } else {
      gitLogCache.delete(cacheKey);
    }

    return { commits, debug: debugInfo };
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    debugInfo.push(`git reader failed: ${message}`);
    return { commits: [], debug: debugInfo };
  }
}

/**
 * Get branches and tags
 * Results are cached by git repo hash
 * Uses the native hashtree ref reader
 */
export async function getRefs(
  rootCid: CID,
  options: GitRefsProgressOptions = {},
): Promise<GitRefsResult> {
  const cacheKey = cidCacheKey(rootCid)!;

  // Check cache first
  const cached = gitRefsCache.get(cacheKey);
  if (cached) {
    if (cached.currentBranch) {
      options.onCurrentBranch?.(cached.currentBranch);
    }
    options.onBranches?.({ branches: cached.branches, currentBranch: cached.currentBranch });
    options.onRefNames?.({
      branches: cached.branches,
      currentBranch: cached.currentBranch,
      tags: cached.tags,
    });
    return cached;
  }

  // The history dialog needs the final refs already loading for the toolbar.
  // Callers requesting progress still receive every stage of their own read.
  const active = pendingRefs.get(cacheKey);
  if (active && !options.onCurrentBranch && !options.onBranches && !options.onRefNames) return active;
  const pending = readRefs(rootCid, options, cacheKey);
  pendingRefs.set(cacheKey, pending);
  try {
    return await pending;
  } finally {
    if (pendingRefs.get(cacheKey) === pending) pendingRefs.delete(cacheKey);
  }
}

async function readRefs(rootCid: CID, options: GitRefsProgressOptions, cacheKey: string): Promise<GitRefsResult> {
  try {
    const { getRefs } = await import('./wasmGit');
    const result = await getRefs(rootCid, options);
    if (result.branches.length > 0 || result.tags.length > 0 || result.currentBranch) {
      gitRefsCache.set(cacheKey, result);
    } else {
      gitRefsCache.delete(cacheKey);
    }
    return result;
  } catch {
    return { branches: [], currentBranch: null, tags: [], tagsByCommit: {} };
  }
}

/**
 * Backward-compatible alias for older call sites.
 */
export async function getBranches(rootCid: CID): Promise<GitRefsResult> {
  return getRefs(rootCid);
}

/**
 * Get current HEAD commit SHA
 * Results are cached by git repo hash
 * Uses wasm-git (libgit2)
 */
export async function getHead(rootCid: CID): Promise<string | null> {
  const cacheKey = cidCacheKey(rootCid)!;

  // Check cache first
  if (gitHeadCache.has(cacheKey)) {
    return gitHeadCache.get(cacheKey) ?? null;
  }

  try {
    const { getHead } = await import('./wasmGit');
    const result = await getHead(rootCid);
    if (result) {
      gitHeadCache.set(cacheKey, result);
    } else {
      gitHeadCache.delete(cacheKey);
    }
    return result;
  } catch {
    return null;
  }
}

/**
 * Get the first-parent root commit SHA for a repository.
 * This is used as the NIP-34 earliest-unique-commit tag for app-created forks.
 */
export async function getRootCommit(rootCid: CID): Promise<string | null> {
  try {
    const { getRootCommit } = await import('./wasmGit');
    return await getRootCommit(rootCid);
  } catch {
    return null;
  }
}

/**
 * Resolve a git revision/ref to a commit SHA using the native ref reader.
 */
export async function resolveRevision(rootCid: CID, revision: string): Promise<string | null> {
  const repoError = await ensureGitRepo(rootCid);
  if (repoError) {
    return null;
  }

  try {
    const { resolveRevisionToCommit } = await import('./wasmGit/log');
    return await resolveRevisionToCommit(rootCid, revision);
  } catch {
    return null;
  }
}

/**
 * Get git status (staged, unstaged, untracked files)
 * Results are cached by git repo hash
 * Uses wasm-git (libgit2)
 */
export async function getStatus(rootCid: CID) {
  const cacheKey = toHex(rootCid.hash);

  // Check cache first
  const cached = gitStatusCache.get(cacheKey);
  if (cached) {
    console.log('[git] getStatus CACHE HIT for:', cacheKey.slice(0, 16), 'hasChanges:', cached.hasChanges);
    return cached;
  }

  console.log('[git] getStatus CACHE MISS for:', cacheKey.slice(0, 16), '- calling wasm-git');
  try {
    const { getStatusWasm } = await import('./wasmGit');
    const result = await getStatusWasm(rootCid);
    console.log('[git] getStatus result: hasChanges:', result.hasChanges, 'staged:', result.staged.length, 'unstaged:', result.unstaged.length, 'untracked:', result.untracked.length);
    gitStatusCache.set(cacheKey, result);
    return result;
  } catch (e) {
    console.error('[git] getStatus error:', e);
    return { staged: [], unstaged: [], untracked: [], hasChanges: false };
  }
}

/**
 * Create a new branch
 * Uses wasm-git (libgit2)
 * Returns the updated .git files that must be persisted to hashtree
 */
export async function createBranch(rootCid: CID, branchName: string, checkout: boolean = true): Promise<{
  success: boolean;
  error?: string;
  gitFiles?: Array<{ name: string; data: Uint8Array; isDir: boolean }>;
}> {
  const { createBranchWasm } = await import('./wasmGit');
  return await createBranchWasm(rootCid, branchName, checkout);
}

/**
 * Stage files and create a commit
 * Returns the updated .git directory files to be saved back to hashtree
 */
export async function commit(
  rootCid: CID,
  message: string,
  authorName: string,
  authorEmail: string,
  filesToStage?: string[]
) {
  const { commitWasm } = await import('./wasmGit');
  return await commitWasm(rootCid, message, authorName, authorEmail, filesToStage);
}

/**
 * Get diff between two commits
 * Native implementation - reads git objects directly from hashtree
 */
export async function getDiff(rootCid: CID, fromCommit: string, toCommit: string): Promise<{
  entries: Array<{ path: string; status: 'added' | 'deleted' | 'modified'; oldHash?: string; newHash?: string }>;
}> {
  const { getDiff } = await import('./wasmGit');
  const entries = await getDiff(rootCid, fromCommit, toCommit);
  return { entries };
}

type CommitViewData = {
  commit: {
    oid: string;
    message: string;
    author: string;
    email: string;
    timestamp: number;
    parent: string[];
  };
  diffText: string;
  stats: { additions: number; deletions: number; files: number };
  files: Array<UnifiedDiffRenderedFile & {
    canViewFile: boolean;
    viewCommit: string | null;
  }>;
};
const commitViewCache = new LRUCache<string, CommitViewData>(10);
const pendingCommitViews = new Map<string, Promise<CommitViewData | null>>();

export async function getCommitViewData(rootCid: CID, commitRef: string): Promise<CommitViewData | null> {
  const cacheKey = `${cidCacheKey(rootCid)}:${commitRef}`;
  const cached = commitViewCache.get(cacheKey);
  if (cached) return cached;
  const inflight = pendingCommitViews.get(cacheKey);
  if (inflight) return inflight;

  const pending = import('./wasmGit')
    .then(({ getCommitViewDataNative }) => getCommitViewDataNative(rootCid, commitRef))
    .then((result) => {
      if (result) commitViewCache.set(cacheKey, result);
      return result;
    });
  pendingCommitViews.set(cacheKey, pending);
  try {
    return await pending;
  } finally {
    pendingCommitViews.delete(cacheKey);
  }
}

/**
 * Check if a directory contains a .git folder (is a git repo)
 * This check is lightweight - doesn't load wasm-git
 */
export async function isGitRepo(rootCid: CID): Promise<boolean> {
  const tree = getTree();

  try {
    // Check for .git directory
    const gitDirResult = await tree.resolvePath(rootCid, '.git');
    if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
      return false;
    }

    // Check for HEAD file inside .git
    const headResult = await tree.resolvePath(gitDirResult.cid, 'HEAD');
    return headResult !== null && headResult.type !== LinkType.Dir;
  } catch {
    return false;
  }
}

export async function waitForGitRepo(
  rootCid: CID,
  options?: {
    attempts?: number;
    delayMs?: number;
  },
): Promise<boolean> {
  const attempts = Math.max(1, options?.attempts ?? 20);
  const delayMs = Math.max(0, options?.delayMs ?? 500);

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await isGitRepo(rootCid)) {
      return true;
    }
    if (attempt < attempts - 1 && delayMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  return false;
}

async function ensureGitRepo(
  rootCid: CID,
  options?: {
    attempts?: number;
    delayMs?: number;
  },
): Promise<string | null> {
  const ready = await waitForGitRepo(rootCid, options);
  return ready ? null : 'Not a git repository';
}

/**
 * Get file content at a specific commit
 * Native implementation - reads git objects directly from hashtree
 */
export async function getFileAtCommit(
  rootCid: CID,
  filepath: string,
  commitHash: string
): Promise<Uint8Array | null> {
  const { getFileAtCommit } = await import('./wasmGit');
  return getFileAtCommit(rootCid, commitHash, filepath);
}

/**
 * Get blame information for a file
 */
export async function getBlame(_rootCid: CID, _filepath: string) {
  // TODO: Implement with wasm-git blame command
  return null;
}

/**
 * Initialize a git repository in a directory
 * Returns files for the .git directory to be added to the tree
 */
export async function initGitRepo(
  rootCid: CID,
  authorName: string,
  authorEmail: string,
  commitMessage: string = 'Initial commit'
): Promise<Array<{ name: string; data: Uint8Array; isDir: boolean }>> {
  const { initRepoWasm } = await import('./wasmGit');
  return await initRepoWasm(rootCid, authorName, authorEmail, commitMessage);
}

/**
 * Get last commit info for files in a directory
 * Returns a map of filename -> commit info
 * Results are cached by git repo hash for fast navigation between subdirectories
 * @param rootCid - The root CID of the git repository
 * @param filenames - Array of filenames (base names only, not full paths)
 * @param subpath - Optional subdirectory path relative to git root (e.g., 'src' or 'src/utils')
 */
export async function getFileLastCommits(
  rootCid: CID,
  filenames: string[],
  subpath?: string,
  onProgress?: (filename: string, commitInfo: FileCommitInfo) => void,
  signal?: AbortSignal,
  publicDirectory?: string,
): Promise<Map<string, FileCommitInfo>> {
  const cacheKey = cidCacheKey(rootCid)!;
  const result = new Map<string, FileCommitInfo>();

  if (signal?.aborted) return result;
  const cachedData = fileCommitsCache.get(cacheKey) ?? new Map<string, FileCommitInfo>();
  fileCommitsCache.set(cacheKey, cachedData);
  const uncachedFiles: string[] = [];

  for (const filename of filenames) {
    if (filename === '.git') continue;
    const fullPath = subpath ? `${subpath}/${filename}` : filename;
    const cached = cachedData.get(fullPath);
    if (cached) {
      result.set(filename, cached);
      onProgress?.(filename, cached);
    } else {
      uncachedFiles.push(filename);
    }
  }

  // If all files are cached, return early
  if (uncachedFiles.length === 0) {
    return result;
  }

  // Fetch uncached files using native implementation (no wasm needed)
  try {
    const { getFileLastCommits } = await import('./wasmGit');

    const handleProgress = (filename: string, commitInfo: FileCommitInfo) => {
      if (signal?.aborted || result.has(filename)) return;
      result.set(filename, commitInfo);
      const fullPath = subpath ? `${subpath}/${filename}` : filename;
      cachedData.set(fullPath, commitInfo);
      onProgress?.(filename, commitInfo);
    };

    const freshData = await trackContentLoad(getFileLastCommits(rootCid, uncachedFiles, subpath, handleProgress, signal, publicDirectory));

    // Add fresh data to result and cache
    for (const [filename, commitInfo] of freshData) {
      handleProgress(filename, commitInfo);
    }
  } catch {
    // Silently fail for uncached files
  }

  return result;
}

/**
 * Get diff between two branches natively from git objects (no wasm-git copy).
 * Returns diff output, stats, and whether fast-forward is possible.
 */
export async function diffBranches(rootCid: CID, baseBranch: string, headBranch: string) {
  const repoError = await ensureGitRepo(rootCid);
  if (repoError) {
    return { diff: '', stats: { additions: 0, deletions: 0, files: [] }, canFastForward: false, error: repoError };
  }

  const { diffBranchesNative } = await import('./wasmGit');
  return await diffBranchesNative(rootCid, baseBranch, headBranch);
}

/**
 * Check if branches can be merged without conflicts.
 * Fast-forward merges resolve natively without copying the repository into wasm-git.
 */
export async function canMerge(rootCid: CID, baseBranch: string, headBranch: string) {
  const repoError = await ensureGitRepo(rootCid);
  if (repoError) {
    return { canMerge: false, conflicts: [], isFastForward: false, error: repoError };
  }

  const { canMergeWasm, isAncestorCommit } = await import('./wasmGit');
  const { resolveRevisionToCommit } = await import('./wasmGit/log');
  if (typeof isAncestorCommit === 'function' && typeof resolveRevisionToCommit === 'function') {
    const [baseSha, headSha] = await Promise.all([
      resolveRevisionToCommit(rootCid, baseBranch),
      resolveRevisionToCommit(rootCid, headBranch),
    ]);
    if (baseSha && headSha && await isAncestorCommit(rootCid, baseSha, headSha)) {
      return { canMerge: true, conflicts: [], isFastForward: true };
    }
  }
  return await canMergeWasm(rootCid, baseBranch, headBranch);
}

/**
 * Merge head branch into base branch
 * Returns updated .git files to be persisted
 */
export async function mergeBranches(
  rootCid: CID,
  baseBranch: string,
  headBranch: string,
  commitMessage: string,
  authorName: string = 'User',
  authorEmail: string = 'user@example.com'
) {
  const repoError = await ensureGitRepo(rootCid);
  if (repoError) {
    return { success: false, error: repoError };
  }

  const { mergeWasm } = await import('./wasmGit');
  return await mergeWasm(rootCid, baseBranch, headBranch, commitMessage, authorName, authorEmail);
}
