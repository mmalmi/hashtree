import { LinkType, type CID } from '@hashtree/core';
import { getTree } from '../store';

// wasm-git copies files into a second, in-memory filesystem. Only start that
// automatically if directory metadata establishes that the entire copy is small.
export async function fitsBackgroundGitBudget(root: CID, signal?: AbortSignal): Promise<boolean> {
  const tree = getTree();
  const directories = [root];
  let bytes = 0;
  let entries = 0;
  let listed = 0;
  try {
    while (directories.length) {
      if (signal?.aborted || ++listed > 32) return false;
      const children = await tree.listDirectory(directories.pop()!, signal);
      entries += children.length;
      if (entries > 512) return false;
      for (const child of children) {
        if (child.size > 8 * 1024 * 1024 - bytes) return false;
        if (child.type === LinkType.Dir) directories.push(child.cid);
        else bytes += child.size;
      }
    }
    return !signal?.aborted;
  } catch {
    return false;
  }
}
