export const MAX_HIGHLIGHT_CHARS = 128 * 1024;
export const MAX_HIGHLIGHT_LINES = 3000;
export const MAX_HIGHLIGHT_LINE_LENGTH = 4000;

// Prevent Prism's built-in auto-highlighter from clobbering Svelte's line-numbered
// DOM when the prismHighlight chunk is lazy-loaded after DOMContentLoaded.
const prismGlobal = globalThis as { Prism?: { manual?: boolean } };
if (prismGlobal.Prism) prismGlobal.Prism.manual = true;
else prismGlobal.Prism = { manual: true };

const EXT_TO_LANG: Record<string, string> = {
  js: 'javascript', mjs: 'javascript', cjs: 'javascript',
  ts: 'typescript', mts: 'typescript', cts: 'typescript',
  jsx: 'jsx', tsx: 'tsx', json: 'json', md: 'markdown',
  py: 'python', rs: 'rust', go: 'go',
  c: 'c', h: 'c', cpp: 'cpp', cc: 'cpp', cxx: 'cpp', hpp: 'cpp', hxx: 'cpp',
  java: 'java', sh: 'bash', bash: 'bash', zsh: 'bash',
  sql: 'sql', yaml: 'yaml', yml: 'yaml', toml: 'toml',
  ini: 'ini', cfg: 'ini', conf: 'ini',
  diff: 'diff', patch: 'diff', rb: 'ruby', php: 'php',
  swift: 'swift', kt: 'kotlin', kts: 'kotlin', scala: 'scala',
  html: 'markup', htm: 'markup', xml: 'markup', svg: 'markup',
  css: 'css', scss: 'css', sass: 'css',
  dockerfile: 'docker', svelte: 'markup', vue: 'markup',
};

export function getCodeLanguage(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  const base = filename.toLowerCase();
  if (base === 'dockerfile' || base.startsWith('dockerfile.')) return 'docker';
  if (base === 'nginx.conf' || base.endsWith('.nginx')) return 'nginx';
  if (base === 'makefile' || base === 'gnumakefile') return 'clike';
  return EXT_TO_LANG[ext] || 'clike';
}

/** Skip regex syntax highlighting on large or minified files to avoid main-thread freezes. */
export function canHighlightCode(content: string): boolean {
  if (!content || content.length > MAX_HIGHLIGHT_CHARS) return false;
  let lineCount = 1;
  let lineStart = 0;
  for (let i = 0; i < content.length; i++) {
    if (content.charCodeAt(i) === 10) {
      if (i - lineStart > MAX_HIGHLIGHT_LINE_LENGTH) return false;
      lineCount++;
      if (lineCount > MAX_HIGHLIGHT_LINES) return false;
      lineStart = i + 1;
    }
  }
  return content.length - lineStart <= MAX_HIGHLIGHT_LINE_LENGTH;
}

const SPAN_TAG_RE = /<span\b[^>]*>|<\/span>/g;

/**
 * Split Prism HTML on newlines while closing and reopening spans that cross lines
 * (such as block comments or template strings) so every line is valid, styled HTML.
 */
export function splitBalancedHtmlLines(html: string): string[] {
  const rawLines = html.split('\n');
  const openTags: string[] = [];
  const balanced = new Array<string>(rawLines.length);

  for (let i = 0; i < rawLines.length; i++) {
    const line = rawLines[i];
    const prefix = openTags.length > 0 ? openTags.join('') : '';
    SPAN_TAG_RE.lastIndex = 0;
    let match: RegExpExecArray | null;
    while ((match = SPAN_TAG_RE.exec(line)) !== null) {
      if (match[0] === '</span>') openTags.pop();
      else openTags.push(match[0]);
    }
    const suffix = openTags.length > 0 ? '</span>'.repeat(openTags.length) : '';
    balanced[i] = prefix + line + suffix;
  }

  return balanced;
}
