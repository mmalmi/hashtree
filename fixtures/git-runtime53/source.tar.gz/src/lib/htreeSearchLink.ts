import { parseHtreeUrl } from '@hashtree/git';
import { nip19 } from 'nostr-tools';
import { buildRepoCodeHref } from './gitRefNavigation';
import { HTREE_APP_URL } from './shareUrls';
import { isLinkKeyHex } from './treeKeys';

// Even an incomplete or malformed repository link may contain an access key.
export function isHtreeSearchInput(input: string): boolean {
  return /^\s*htree:/i.test(input) || /[?#&]k=/i.test(input);
}

export function htreeSearchHref(input: string, currentNpub?: string | null): string | null {
  const uri = input.trim().replace(/^htree:\/\//i, 'htree://');
  if (!uri.startsWith('htree://')) return null;

  // Links from the Share menu already contain an Iris Git route.
  const [address, fragment, extraFragment] = uri.split('#');
  if (extraFragment !== undefined) return null;
  if (address.replace(/\/$/, '') === HTREE_APP_URL && fragment?.startsWith('/')) {
    const query = fragment.indexOf('?');
    const keys = new URLSearchParams(query < 0 ? '' : fragment.slice(query + 1)).getAll('k');
    if (keys.length > 1 || (keys.length === 1 && !isLinkKeyHex(keys[0]))) return null;
    return '#' + fragment;
  }

  try {
    // The Git transport uses #k=. Accept ?k= as an alias at the search boundary.
    const query = address.indexOf('?');
    if (query !== -1 && (fragment !== undefined || !address.slice(query + 1).startsWith('k='))) return null;
    if (fragment === '') return null;
    const parsed = parseHtreeUrl(query < 0 ? uri : address.replace('?', '#'));
    if (parsed.autoGenerateLinkKey) return null;

    let npub = parsed.identifier;
    if (npub === 'self') npub = currentNpub ?? '';
    if (/^[0-9a-f]{64}$/i.test(npub)) npub = nip19.npubEncode(npub);
    const owner = nip19.decode(npub);
    if (owner.type !== 'npub' || owner.data.length !== 64) return null;

    const parts = parsed.repo.replace(/\/$/, '').split('/').map(decodeURIComponent);
    if (parts.some(part => !part.trim() || part === '.' || part === '..' || /[\/\\\x00-\x1f\x7f]/.test(part))) return null;
    return buildRepoCodeHref(nip19.npubEncode(owner.data), parts.join('/'), { linkKey: parsed.linkKey });
  } catch {
    return null;
  }
}
