/**
 * Live reads and background publication.
 *
 * Nothing on screen waits for a relay to answer. A read is an open
 * subscription: each event is handed over the moment it arrives and "history"
 * only says that the absence of an event may now be shown. A write is shown at
 * once and handed to the backend, which stores it, sends it to every relay and
 * retries the ones which are down.
 */
import { matchFilters, type Event, type Filter } from 'nostr-tools';
import { nostr } from '../nostr';

const MAX_LOCAL_EVENTS = 200;
/** Events written on this page, so every open and later view shows them at once. */
const localEvents = new Map<string, Event>();
const localListeners = new Set<(event: Event, removed: boolean) => void>();

function matches(filters: Filter[], event: Event): boolean {
  try {
    return matchFilters(filters.map(({ limit: _limit, ...rest }) => rest), event);
  } catch {
    return false;
  }
}

function notifyLocal(event: Event, removed: boolean): void {
  for (const listener of [...localListeners]) listener(event, removed);
}

/**
 * More places to read from, beside the configured relays. A source is called
 * once per watch, including watches already open when it is registered, and
 * returns a function that ends its reads. It must only deliver signed,
 * verified events.
 */
export type EventSource = (filters: Filter[], deliver: (event: Event) => void) => () => void;

interface OpenWatch {
  filters: Filter[];
  deliver: (event: Event) => void;
  sourceStops: Map<EventSource, () => void>;
}

const eventSources = new Set<EventSource>();
const openWatches = new Set<OpenWatch>();
const MAX_SOURCED_EVENTS = 2000;
/** Verified events extra sources delivered, which the backend does not store. */
const sourcedEvents = new Map<string, Event>();

function rememberSourced(event: Event): void {
  if (sourcedEvents.has(event.id)) return;
  sourcedEvents.set(event.id, event);
  if (sourcedEvents.size > MAX_SOURCED_EVENTS) sourcedEvents.delete(sourcedEvents.keys().next().value!);
}

/** An event an extra source delivered on this page, by id. */
export function findSourcedEvent(id: string): Event | null {
  return sourcedEvents.get(id) ?? null;
}

export function registerEventSource(source: EventSource): () => void {
  eventSources.add(source);
  for (const watch of openWatches) watch.sourceStops.set(source, source(watch.filters, watch.deliver));
  return () => {
    eventSources.delete(source);
    for (const watch of openWatches) {
      watch.sourceStops.get(source)?.();
      watch.sourceStops.delete(source);
    }
  };
}

export interface WatchHandlers {
  event(event: Event): void;
  /** Stored history has been delivered. Called once; later events still arrive. */
  history?(): void;
  /** An event shown from this page could not be handed over for publication. */
  removed?(id: string): void;
}

/** Returns a function that ends the watch. Events written here may be delivered before it returns. */
export function watchEvents(filters: Filter | Filter[], handlers: WatchHandlers): () => void {
  const list = Array.isArray(filters) ? filters : [filters];
  const seen = new Set<string>();
  let stopped = false;
  let historyDone = false;

  const deliver = (event: Event) => {
    if (stopped || seen.has(event.id)) return;
    seen.add(event.id);
    handlers.event(event);
  };
  const onLocal = (event: Event, removed: boolean) => {
    if (stopped || !matches(list, event)) return;
    if (!removed) return deliver(event);
    seen.delete(event.id);
    handlers.removed?.(event.id);
  };

  localListeners.add(onLocal);
  for (const event of [...localEvents.values()]) {
    if (matches(list, event)) deliver(event);
  }

  const subscription = nostr.subscribe(list);
  subscription.on('event', deliver);
  subscription.on('history', () => {
    if (stopped || historyDone) return;
    historyDone = true;
    handlers.history?.();
  });
  const openWatch: OpenWatch = {
    filters: list,
    deliver: (event) => {
      if (!matches(list, event)) return;
      rememberSourced(event);
      deliver(event);
    },
    sourceStops: new Map(),
  };
  for (const source of eventSources) openWatch.sourceStops.set(source, source(list, openWatch.deliver));
  openWatches.add(openWatch);

  return () => {
    if (stopped) return;
    stopped = true;
    localListeners.delete(onLocal);
    subscription.stop();
    openWatches.delete(openWatch);
    for (const stop of openWatch.sourceStops.values()) stop();
    openWatch.sourceStops.clear();
  };
}

/**
 * More places to send events published here, beside the configured relays.
 * Called once per event after the backend has accepted it; best effort.
 */
export type PublishTarget = (event: Event) => void;

const publishTargets = new Set<PublishTarget>();

export function registerPublishTarget(target: PublishTarget): () => void {
  publishTargets.add(target);
  return () => publishTargets.delete(target);
}

function sendToTargets(event: Event): void {
  for (const target of publishTargets) {
    try {
      target(event);
    } catch (error) {
      console.warn('[nostr] Extra publish target failed:', error);
    }
  }
}

function rememberLocal(event: Event): void {
  localEvents.set(event.id, event);
  if (localEvents.size > MAX_LOCAL_EVENTS) localEvents.delete(localEvents.keys().next().value!);
  notifyLocal(event, false);
}

async function enqueue(event: Event): Promise<void> {
  const receipt = await nostr.publish(event) as { accepted?: boolean; queued?: boolean } | undefined;
  if (receipt?.accepted === false && receipt.queued === false) {
    throw new Error('The event was not accepted for publication.');
  }
}

/** The backend acknowledges its local outbox before waiting for remote delivery. */
export async function publishStoredEvent(event: Event): Promise<void> {
  await enqueue(event);
  rememberLocal(event);
  sendToTargets(event);
}

/**
 * Show a signed event everywhere on this page now and publish it without
 * waiting. A relay being down is not a failure: the backend keeps the event and
 * retries. `onFailure` runs only when the event could not be handed over at all.
 */
export function publishInBackground(event: Event, onFailure?: (error: Error) => void): void {
  rememberLocal(event);
  void enqueue(event).then(() => sendToTargets(event), (error) => {
    localEvents.delete(event.id);
    notifyLocal(event, true);
    console.error('[nostr] Could not publish event:', error);
    onFailure?.(error instanceof Error ? error : new Error(String(error)));
  });
}

/** Collect calls made close together into one. */
export function createBatcher<T>(flush: (items: T[]) => void, delayMs = 50) {
  let queued: T[] = [];
  let timer: ReturnType<typeof setTimeout> | undefined;
  return {
    add(item: T) {
      queued.push(item);
      timer ??= setTimeout(() => {
        timer = undefined;
        const items = queued;
        queued = [];
        flush(items);
      }, delayMs);
    },
    cancel() {
      clearTimeout(timer);
      timer = undefined;
      queued = [];
    },
  };
}
