import type { Event, EventTemplate } from 'nostr-tools';
import { nostr } from '../nostr';
import { publishInBackground } from './nostrLive';

/** Sign, show locally and publish without waiting for a relay. */
export async function publishEvent(
  event: Event | EventTemplate,
  onFailure?: (error: Error) => void,
): Promise<Event> {
  const signed = 'sig' in event ? event : await nostr.signEvent(event);
  publishInBackground(signed, onFailure);
  return signed;
}
