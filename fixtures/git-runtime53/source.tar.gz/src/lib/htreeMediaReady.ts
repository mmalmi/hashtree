import { writable } from 'svelte/store';

/**
 * False only while a first-visit service worker install is in progress.
 * /htree/ URLs are answered by the service worker, so embedded documents
 * that would otherwise load the app shell in their place wait for this.
 */
export const htreeMediaReady = writable(true);
