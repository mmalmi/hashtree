import { treeRootRegistry } from '@hashtree/worker/tree-root';
import { parseRoute } from '../utils/route';

const ROUTE_ROOT_WAIT_MS = 2000;
const BACKEND_WAIT_MS = 15000;
const CONTENT_SETTLE_MS = 800;
const CONTENT_WAIT_MS = 6000;

/**
 * Background work is held back while the open page loads.
 *
 * The worker hands relay events over one at a time and stores each one, which
 * also slows reads from the same store. Listing every tree an owner has at the
 * same moment as the one root the page needs puts that root behind hundreds of
 * unrelated events, and the same burst then stalls the page's own content
 * reads. Owner-wide listings therefore wait here.
 */

let contentLoads = 0;
const idleListeners = new Set<() => void>();
// After a root arrives from the network, content loads need a moment to start.
let quietUntil = 0;

/** Mark work the open page is waiting on, such as reading Git history. */
export function trackContentLoad<T>(work: Promise<T>): Promise<T> {
  contentLoads++;
  return work.finally(() => {
    contentLoads--;
    if (contentLoads === 0) {
      for (const listener of [...idleListeners]) listener();
    }
  });
}

// The wait for a root only makes sense once the backend can ask relays for it.
let backendReady = false;
const backendReadyListeners = new Set<() => void>();

/** Called when the storage and relay backend has started. */
export function markBackendReady(): void {
  backendReady = true;
  for (const listener of [...backendReadyListeners]) listener();
  backendReadyListeners.clear();
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Resolves once the tree root for the open page is known, or after a short wait. */
export function whenRouteRootResolved(npub: string): Promise<void> {
  const route = parseRoute();
  const treeName = route.treeName;
  if (route.npub !== npub || !treeName || treeRootRegistry.get(npub, treeName)) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    const finish = () => {
      clearTimeout(timer);
      backendReadyListeners.delete(startRootWait);
      unsubscribe();
      resolve();
    };
    const startRootWait = () => {
      clearTimeout(timer);
      timer = setTimeout(finish, ROUTE_ROOT_WAIT_MS);
    };
    let timer = setTimeout(finish, BACKEND_WAIT_MS);
    if (backendReady) startRootWait();
    else backendReadyListeners.add(startRootWait);
    const unsubscribe = treeRootRegistry.subscribe(npub, treeName, (record) => {
      if (!record) return;
      quietUntil = Date.now() + CONTENT_SETTLE_MS;
      finish();
    });
  });
}

/**
 * Resolves once the open page has its root and its tracked content loads have
 * gone quiet. Pages that are not showing one of this owner's trees, and pages
 * that have already loaded, do not wait.
 */
export async function whenRoutePageSettled(npub: string): Promise<void> {
  const route = parseRoute();
  if (route.npub !== npub || !route.treeName) return;

  await whenRouteRootResolved(npub);
  const deadline = Date.now() + CONTENT_WAIT_MS;
  for (;;) {
    const settle = quietUntil - Date.now();
    if (settle > 0) await delay(settle);
    if (contentLoads === 0 || Date.now() >= deadline) return;
    await Promise.race([
      new Promise<void>((resolve) => {
        const listener = () => {
          idleListeners.delete(listener);
          resolve();
        };
        idleListeners.add(listener);
      }),
      delay(Math.max(0, deadline - Date.now())),
    ]);
  }
}
