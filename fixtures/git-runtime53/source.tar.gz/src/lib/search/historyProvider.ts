/**
 * History search provider
 *
 * Ranks matches against the local recents store.
 */

import { getRecentsSync, type RecentItem } from '../../stores/recents';
import type { SearchProvider, SearchResult } from './types';

/** Record a history visit (no-op in web - recents store handles this) */
export async function recordHistoryVisit(
  _path: string,
  _label: string,
  _entryType: string,
  _npub?: string,
  _treeName?: string
): Promise<void> {
  // History recording is handled by the recents store in the web app
}

function normalize(text: string): string {
  return text.normalize('NFC').toLowerCase().trim();
}

/** Rank complete title matches first and use recency to break ties. */
function searchHistory(query: string, limit: number): SearchResult[] {
  const text = normalize(query);
  if (!text) return [];

  const terms = text.match(/[\p{L}\p{M}\p{N}]+/gu) ?? [text];
  const matches: Array<{ item: RecentItem; score: number }> = [];
  for (const item of getRecentsSync()) {
    const title = normalize(item.label);
    if (title === text) {
      matches.push({ item, score: 1 });
    } else if (title.includes(text)) {
      matches.push({ item, score: 0.98 });
    } else if (terms.every((term) => title.includes(term))) {
      matches.push({ item, score: 0.95 });
    } else {
      const location = normalize(item.path);
      const treeName = normalize(item.treeName ?? '');
      if (terms.every((term) => title.includes(term) || treeName.includes(term) || location.includes(term))) {
        matches.push({ item, score: 0.8 });
      }
    }
  }
  return matches
    .sort((a, b) => b.score - a.score || b.item.timestamp - a.item.timestamp)
    .slice(0, limit)
    .map(({ item, score }) => toSearchResult(item, score));
}

function recentPath(item: RecentItem): string {
  let path = item.path;
  if (item.npub && item.treeName) {
    // Recents store the decoded tree name and file path together.
    const root = `/${item.npub}/${item.treeName}`;
    if (path === root || path.startsWith(root + '/')) {
      const suffix = path.slice(root.length);
      const parts = suffix.split('/').filter(Boolean);
      path = '/' + [item.npub, item.treeName, ...parts].map(encodeURIComponent).join('/');
    }
  }
  if (item.linkKey) {
    path += `${path.includes('?') ? '&' : '?'}k=${encodeURIComponent(item.linkKey)}`;
  }
  return path;
}

function toSearchResult(item: RecentItem, score: number): SearchResult {
  return {
    id: `history:${item.path}`,
    type: mapEntryType(item.type),
    label: item.label,
    sublabel: formatTimeAgo(item.timestamp),
    path: recentPath(item),
    score,
    icon: getIconForType(item.type),
    timestamp: item.timestamp,
  };
}

/** Map entry type to SearchResult type */
function mapEntryType(entryType: string): SearchResult['type'] {
  switch (entryType) {
    case 'video':
      return 'video';
    case 'user':
      return 'user';
    case 'tree':
    case 'dir':
      return 'tree';
    case 'file':
      return 'file';
    default:
      return 'history';
  }
}

/** Get icon class for entry type */
function getIconForType(entryType: string): string {
  switch (entryType) {
    case 'video':
      return 'i-lucide-play-circle';
    case 'user':
      return 'i-lucide-user';
    case 'tree':
    case 'dir':
      return 'i-lucide-folder';
    case 'file':
      return 'i-lucide-file';
    case 'app':
      return 'i-lucide-layout-grid';
    case 'hash':
      return 'i-lucide-link';
    default:
      return 'i-lucide-clock';
  }
}

/** Format timestamp as relative time */
function formatTimeAgo(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;

  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  return new Date(timestamp).toLocaleDateString();
}

/** History search provider */
export const historyProvider: SearchProvider = {
  id: 'history',
  name: 'History',
  priority: 10, // Show history first

  isAvailable(): boolean {
    return true;
  },

  async search(query: string, limit: number): Promise<SearchResult[]> {
    return searchHistory(query, limit);
  },
};

/** Get recent history without search (for empty query) */
export async function getRecentHistory(limit: number): Promise<SearchResult[]> {
  return getRecentsSync().slice(0, limit).map((item) => toSearchResult(item, 1));
}
