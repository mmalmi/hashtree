/**
 * Trees that come from outside Hashtree, kept in memory on this page (for
 * example a git repository fetched from another server).
 *
 * A feature registers here:
 * - blocks, which every tree read checks before the backend;
 * - roots, which a /npub/tree route uses when no Hashtree root is known.
 *
 * The backend never sees these blocks, so nothing here is stored, uploaded or
 * published. Pages show external trees read-only.
 */
import { toHex, type CID, type Hash } from '@hashtree/core';
import { writable, type Readable } from 'svelte/store';

export type ExternalBlockReader = (hashHex: string) => Uint8Array | null;

const blockReaders = new Set<ExternalBlockReader>();

export function registerExternalBlocks(reader: ExternalBlockReader): () => void {
  blockReaders.add(reader);
  return () => blockReaders.delete(reader);
}

export function readExternalBlock(hash: Hash): Uint8Array | null {
  if (blockReaders.size === 0) return null;
  const hashHex = toHex(hash);
  for (const read of blockReaders) {
    const data = read(hashHex);
    if (data) return data;
  }
  return null;
}

function treeKey(npub: string, treeName: string): string {
  return `${npub}/${treeName}`;
}

const roots = new Map<string, CID>();
const rootListeners = new Set<(key: string, root: CID | null) => void>();
const externalKeys = writable<ReadonlySet<string>>(new Set());

/** Keys (`npub/treeName`) that have an external root. */
export const externalTreeKeysStore: Readable<ReadonlySet<string>> = { subscribe: externalKeys.subscribe };

export function setExternalTreeRoot(npub: string, treeName: string, root: CID | null): void {
  const key = treeKey(npub, treeName);
  if (root) roots.set(key, root);
  else if (!roots.delete(key)) return;
  externalKeys.set(new Set(roots.keys()));
  for (const listener of [...rootListeners]) listener(key, root);
}

/** The external root for a resolver key (`npub/treeName`). */
export function getExternalTreeRoot(key: string): CID | null {
  return roots.get(key) ?? null;
}

export function subscribeExternalTreeRoots(listener: (key: string, root: CID | null) => void): () => void {
  rootListeners.add(listener);
  return () => rootListeners.delete(listener);
}

const publicRepos = writable<ReadonlySet<string>>(new Set());
let publicRepoKeys: ReadonlySet<string> = new Set();

/**
 * Repos known to be public outside Hashtree (an owner-signed public
 * announcement), so issues and comments may be published for them even
 * without a Hashtree root.
 */
export const externalPublicReposStore: Readable<ReadonlySet<string>> = { subscribe: publicRepos.subscribe };

export function markExternalRepoPublic(npub: string, treeName: string): void {
  const key = treeKey(npub, treeName);
  if (publicRepoKeys.has(key)) return;
  publicRepoKeys = new Set([...publicRepoKeys, key]);
  publicRepos.set(publicRepoKeys);
}

export function isExternalRepoPublic(npub: string, treeName: string): boolean {
  return publicRepoKeys.has(treeKey(npub, treeName));
}

/** `public` for such a repo, else the visibility Hashtree reported. */
export function collaborationVisibility<T extends string>(
  visibility: T | undefined,
  keys: ReadonlySet<string>,
  npub: string | null | undefined,
  repoName: string | null | undefined,
): T | 'public' | undefined {
  if (visibility || !npub || !repoName) return visibility;
  return keys.has(treeKey(npub, repoName.split('/')[0])) ? 'public' : undefined;
}

export function isExternalTreeKey(
  keys: ReadonlySet<string>,
  npub: string | null | undefined,
  treeName: string | null | undefined,
): boolean {
  return !!npub && !!treeName && keys.has(treeKey(npub, treeName));
}
