
import { nostr, nostrStore, npubToPubkey } from './nostr';
import {
  isNewerGitRepoAnnouncement,
  parseGitRepoAnnouncement,
  type GitRepoAnnouncement,
} from './lib/gitRepoAnnouncements';
import { KIND_REPO_ANNOUNCEMENT } from './utils/constants';
import { buildHtreeUrl, publishNip34Event } from './nip34';
import { watchEvents } from './lib/nostrLive';
import { getWorkerAdapter } from './lib/workerInit';

export async function publishRepoAnnouncement(
  repoName: string,
  options: {
    description?: string;
    webUrl?: string;
    maintainers?: string[];
    earliestUniqueCommit?: string;
    personalFork?: boolean;
    forkedFrom?: string;
  } = {}
): Promise<boolean> {
  const state = nostrStore.getState();
  if (!state.pubkey || !state.npub || !nostr.signer) return false;

  const htreeUrl = buildHtreeUrl(state.npub, repoName);

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_REPO_ANNOUNCEMENT;
  event.content = '';
  event.tags = [
    ['d', repoName],
    ['name', repoName],
    ['clone', htreeUrl],
  ];

  if (options.description) event.tags.push(['description', options.description]);
  if (options.webUrl) event.tags.push(['web', options.webUrl]);
  if (options.earliestUniqueCommit) event.tags.push(['r', options.earliestUniqueCommit, 'euc']);
  if (options.personalFork) event.tags.push(['t', 'personal-fork']);
  if (options.forkedFrom) event.tags.push(['forked-from', options.forkedFrom]);

  const maintainerPubkeys = (options.maintainers || [])
    .map(maintainerNpub => npubToPubkey(maintainerNpub))
    .filter((maintainerPubkey): maintainerPubkey is string => !!maintainerPubkey);
  if (maintainerPubkeys.length > 0) {
    event.tags.push(['maintainers', ...maintainerPubkeys]);
  }

  try {
    await publishNip34Event(event);
    return true;
  } catch (e) {
    console.error('Failed to publish repo announcement:', e);
    return false;
  }
}

function repoAnnouncementFilter(pubkey: string, repoName: string) {
  return { kinds: [KIND_REPO_ANNOUNCEMENT], authors: [pubkey], '#d': [repoName], limit: 20 };
}

/**
 * Watch a repository's announcement. `onChange` is called with each newer
 * version as it arrives. Returns a function that ends the watch.
 */
export function watchRepoAnnouncement(
  npub: string,
  repoName: string,
  onChange: (announcement: GitRepoAnnouncement) => void,
): () => void {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) return () => {};

  let latest: GitRepoAnnouncement | null = null;
  return watchEvents(repoAnnouncementFilter(pubkey, repoName), {
    event: (event) => {
      const parsed = parseGitRepoAnnouncement(event);
      if (!parsed || !isNewerGitRepoAnnouncement(parsed, latest)) return;
      latest = parsed;
      onChange(parsed);
    },
  });
}

/** The newest announcement already stored on this device. Asks no relay. */
export async function getStoredRepoAnnouncement(npub: string, repoName: string): Promise<GitRepoAnnouncement | null> {
  const pubkey = npubToPubkey(npub);
  const backend = getWorkerAdapter();
  if (!pubkey || !backend?.queryEvents) return null;

  const result = await backend.queryEvents([repoAnnouncementFilter(pubkey, repoName)], { cache: 'cache-only' });
  let latest: GitRepoAnnouncement | null = null;
  for (const event of result.events) {
    const parsed = parseGitRepoAnnouncement(event);
    if (parsed && isNewerGitRepoAnnouncement(parsed, latest)) latest = parsed;
  }
  return latest;
}
