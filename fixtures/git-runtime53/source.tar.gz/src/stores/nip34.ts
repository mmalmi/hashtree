/**
 * Stores for NIP-34 Pull Requests and Issues
 */
import { writable, type Readable } from 'svelte/store';
import { LRUCache } from '../utils/lruCache';
import { KIND_ISSUE, KIND_PULL_REQUEST } from '../utils/constants';
import {
  watchRepoItems,
  type LiveItems,
  type PullRequest,
  type Issue,
  type ItemStatus,
} from '../nip34';

export interface PullRequestsState {
  items: PullRequest[];
  loading: boolean;
  error: string | null;
  filter: ItemStatus | 'all';
}

export interface IssuesState {
  items: Issue[];
  loading: boolean;
  error: string | null;
  filter: ItemStatus | 'all';
}

export interface RepoTabCounts {
  pullRequests: number | null;
  issues: number | null;
  loading: boolean;
  error: string | null;
  updatedAt: number;
}

type RepoItem = PullRequest | Issue;
type RepoItemKind = typeof KIND_PULL_REQUEST | typeof KIND_ISSUE;

/**
 * One live watch per repository and kind, shared by the list and the tab count.
 * It runs while something shows it; what it has seen stays for the next visit.
 */
interface RepoItemsFeed {
  state: LiveItems<RepoItem>;
  listeners: Set<(state: LiveItems<RepoItem>) => void>;
  stop?: () => void;
}

const repoItemFeeds = new LRUCache<string, RepoItemsFeed>(100);

function subscribeRepoItems<T extends RepoItem>(
  npub: string,
  repoName: string,
  kind: RepoItemKind,
  listener: (state: LiveItems<T>) => void,
): () => void {
  const key = `${kind}:${npub}/${repoName}`;
  let feed = repoItemFeeds.get(key);
  if (!feed) {
    feed = { state: { items: [], historyDone: false }, listeners: new Set() };
    repoItemFeeds.set(key, feed);
  }
  const current = feed;
  const typed = listener as (state: LiveItems<RepoItem>) => void;

  current.listeners.add(typed);
  // Items seen on an earlier visit show at once; absence is confirmed afresh.
  if (!current.stop) current.state = { items: current.state.items, historyDone: false };
  typed(current.state);
  if (!current.stop) {
    current.stop = watchRepoItems<RepoItem>(npub, repoName, kind, (state) => {
      current.state = state;
      for (const each of [...current.listeners]) each(state);
    }, current.state.items);
  }

  return () => {
    current.listeners.delete(typed);
    if (current.listeners.size > 0) return;
    current.stop?.();
    current.stop = undefined;
  };
}

function createEmptyRepoTabCountsState(loading: boolean): RepoTabCounts {
  return {
    pullRequests: null,
    issues: null,
    loading,
    error: null,
    updatedAt: 0,
  };
}

export function countRepoTabItems<T extends { status: ItemStatus }>(items: T[]): number {
  return items.reduce((count, item) => (
    item.status === 'open' || item.status === 'draft'
      ? count + 1
      : count
  ), 0);
}

export function formatRepoTabCount(count: number): string {
  return count.toLocaleString();
}

/** A count appears with its first item, or as zero once history shows there are none. */
function countWhenKnown(state: LiveItems<RepoItem>): number | null {
  return state.items.length > 0 || state.historyDone ? countRepoTabItems(state.items) : null;
}

export function createRepoTabCountsStore(npub: string | null, repoName: string | null): Readable<RepoTabCounts> & {
  destroy: () => void;
} {
  if (!npub || !repoName) {
    return { subscribe: writable(createEmptyRepoTabCountsState(false)).subscribe, destroy: () => {} };
  }

  const { subscribe } = writable<RepoTabCounts>(createEmptyRepoTabCountsState(true), (set) => {
    let pullRequests: LiveItems<RepoItem> = { items: [], historyDone: false };
    let issues: LiveItems<RepoItem> = { items: [], historyDone: false };
    const emit = () => set({
      pullRequests: countWhenKnown(pullRequests),
      issues: countWhenKnown(issues),
      loading: !pullRequests.historyDone || !issues.historyDone,
      error: null,
      updatedAt: Date.now(),
    });
    const stops = [
      subscribeRepoItems<PullRequest>(npub, repoName, KIND_PULL_REQUEST, (state) => { pullRequests = state; emit(); }),
      subscribeRepoItems<Issue>(npub, repoName, KIND_ISSUE, (state) => { issues = state; emit(); }),
    ];
    return () => stops.forEach(stop => stop());
  });

  return { subscribe, destroy: () => {} };
}

function createRepoItemsStore<T extends RepoItem>(
  npub: string | null,
  repoName: string | null,
  kind: RepoItemKind,
): Readable<{ items: T[]; loading: boolean; error: string | null; filter: ItemStatus | 'all' }> & {
  setFilter: (filter: ItemStatus | 'all') => void;
} {
  const idle = { items: [] as T[], loading: false, error: null, filter: 'all' as ItemStatus | 'all' };
  if (!npub || !repoName) {
    return { subscribe: writable(idle).subscribe, setFilter: () => {} };
  }

  // The watch runs while the list is on screen.
  const { subscribe, update } = writable({ ...idle, loading: true }, () => subscribeRepoItems<T>(
    npub, repoName, kind,
    state => update(s => ({ ...s, items: state.items, loading: !state.historyDone })),
  ));

  return {
    subscribe,
    setFilter: filter => update(s => ({ ...s, filter })),
  };
}

/**
 * Pull requests of a repository, live. `loading` only means that an empty list
 * is not yet known to be empty: items show as they arrive.
 */
export function createPullRequestsStore(npub: string | null, repoName: string | null) {
  return createRepoItemsStore<PullRequest>(npub, repoName, KIND_PULL_REQUEST);
}

/** Issues of a repository, live. See createPullRequestsStore. */
export function createIssuesStore(npub: string | null, repoName: string | null) {
  return createRepoItemsStore<Issue>(npub, repoName, KIND_ISSUE);
}

/**
 * Filter items by status
 */
export function filterByStatus<T extends { status: ItemStatus }>(
  items: T[],
  filter: ItemStatus | 'all'
): T[] {
  if (filter === 'all') return items;
  return items.filter(item => item.status === filter);
}

/**
 * Count items by status
 */
export function countByStatus<T extends { status: ItemStatus }>(items: T[]): Record<ItemStatus | 'all', number> {
  const counts: Record<ItemStatus | 'all', number> = {
    all: items.length,
    open: 0,
    merged: 0,
    closed: 0,
    draft: 0,
  };

  for (const item of items) {
    counts[item.status]++;
  }

  return counts;
}
