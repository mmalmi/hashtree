<script lang="ts">
  import { tick } from 'svelte';
  import { SvelteURLSearchParams } from 'svelte/reactivity';
  import { canHighlightCode, getCodeLanguage } from '../../utils/codeHighlight';

  const CHUNK_SIZE = 100;

  interface Props {
    content: string;
    filename: string;
  }

  let { content, filename }: Props = $props();

  let language = $derived(getCodeLanguage(filename));
  let plainLines = $derived(content.split('\n'));
  let highlightedLines = $state.raw<string[] | null>(null);

  // Lazy-load Prism only when a highlightable code file is actually opened.
  // Plain lines render immediately with zero delay.
  $effect(() => {
    const text = content;
    const lang = language;
    highlightedLines = null;
    if (!canHighlightCode(text)) return;

    let cancelled = false;
    void import('../../utils/prismHighlight').then(({ highlightCodeToLines }) => {
      if (cancelled) return;
      highlightedLines = highlightCodeToLines(text, lang);
    }).catch(() => {});
    return () => { cancelled = true; };
  });

  function parseLineRange(search: string): { start: number; end: number } | null {
    const lineParam = new URLSearchParams(search).get('L');
    const match = lineParam?.match(/^(\d+)(?:-(\d+))?$/);
    if (!match) return null;
    const start = parseInt(match[1], 10);
    const end = match[2] ? parseInt(match[2], 10) : start;
    return { start: Math.min(start, end), end: Math.max(start, end) };
  }

  function getQueryFromHash(): string {
    const hash = window.location.hash;
    const qIndex = hash.indexOf('?');
    return qIndex >= 0 ? hash.slice(qIndex + 1) : '';
  }

  let highlightedRange = $state<{ start: number; end: number } | null>(null);
  let selectedLine = $state<number | null>(null);

  $effect(() => {
    function updateFromHash() {
      highlightedRange = parseLineRange(getQueryFromHash());
    }
    updateFromHash();
    window.addEventListener('hashchange', updateFromHash);
    return () => window.removeEventListener('hashchange', updateFromHash);
  });

  $effect(() => {
    const range = highlightedRange;
    if (!range) return;
    tick().then(() => {
      document.querySelector(`[data-line="${range.start}"]`)?.scrollIntoView({ block: 'center' });
    });
  });

  let chunks = $derived.by(() => {
    const lines = highlightedLines ?? plainLines;
    const isHtml = highlightedLines !== null;
    const result: Array<{ startLine: number; lines: string[]; isHtml: boolean }> = [];
    for (let i = 0; i < lines.length; i += CHUNK_SIZE) {
      result.push({ startLine: i + 1, lines: lines.slice(i, i + CHUNK_SIZE), isHtml });
    }
    return result;
  });

  function isLineHighlighted(lineNum: number): boolean {
    if (!highlightedRange) return false;
    return lineNum >= highlightedRange.start && lineNum <= highlightedRange.end;
  }

  function selectLine(lineNum: number, shiftKey: boolean) {
    const hash = window.location.hash;
    const qIndex = hash.indexOf('?');
    const basePath = qIndex >= 0 ? hash.slice(0, qIndex) : hash;
    const currentParams = new SvelteURLSearchParams(qIndex >= 0 ? hash.slice(qIndex + 1) : '');

    if (shiftKey && selectedLine !== null) {
      currentParams.set('L', `${Math.min(selectedLine, lineNum)}-${Math.max(selectedLine, lineNum)}`);
    } else {
      selectedLine = lineNum;
      currentParams.set('L', String(lineNum));
    }
    window.location.hash = `${basePath}?${currentParams.toString()}`;
  }

  function lineNumberFromEvent(event: Event): number | null {
    const target = event.target as HTMLElement | null;
    const lineNumEl = target?.closest?.('.line-number');
    if (!lineNumEl) return null;
    const lineAttr = lineNumEl.parentElement?.getAttribute('data-line');
    const lineNum = lineAttr ? Number.parseInt(lineAttr, 10) : NaN;
    return Number.isFinite(lineNum) ? lineNum : null;
  }

  function handleCodeClick(event: MouseEvent) {
    const lineNum = lineNumberFromEvent(event);
    if (lineNum !== null) selectLine(lineNum, event.shiftKey);
  }

  function handleCodeKeyDown(event: KeyboardEvent) {
    if (event.key !== 'Enter') return;
    const lineNum = lineNumberFromEvent(event);
    if (lineNum !== null) selectLine(lineNum, event.shiftKey);
  }
</script>

<!-- eslint-disable svelte/no-at-html-tags, svelte/no-unused-svelte-ignore -->
<!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
<pre class="code-viewer" onclick={handleCodeClick} onkeydown={handleCodeKeyDown}><code class="language-{language}">{#each chunks as chunk (chunk.startLine)}<div class="code-chunk" class:code-chunk-deferred={chunks.length > 2}>{#each chunk.lines as line, offset (chunk.startLine + offset)}{@const lineNum = chunk.startLine + offset}<span
  class="code-line"
  class:line-highlighted={isLineHighlighted(lineNum)}
  data-line={lineNum}
><span class="line-number" role="button" tabindex="0">{lineNum}</span><span class="line-content">{#if chunk.isHtml}{@html line || '&nbsp;'}{:else}{line || '\u00a0'}{/if}</span></span>{/each}</div>{/each}</code></pre>
<!-- eslint-enable svelte/no-at-html-tags, svelte/no-unused-svelte-ignore -->

<style>
  .code-viewer {
    margin: 0;
    padding: 0;
    font-size: 0.875rem;
    line-height: 1.5;
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace;
    color: var(--text-1, #f1f1f1);
    background: transparent;
  }

  .code-viewer code {
    font-family: inherit;
    display: block;
    white-space: normal;
  }

  .code-chunk-deferred {
    content-visibility: auto;
    contain-intrinsic-size: auto 131.25rem;
  }

  .code-line {
    display: flex;
    align-items: flex-start;
  }

  .code-line.line-highlighted {
    background: rgba(118, 71, 254, 0.15);
  }

  .line-number {
    flex: 0 0 3.5em;
    padding-right: 1em;
    text-align: right;
    color: var(--text-3, #666);
    user-select: none;
    cursor: pointer;
  }

  .line-number:hover {
    color: var(--text-1, #f1f1f1);
  }

  .line-content {
    flex: 1 1 auto;
    min-width: 0;
    display: block;
    white-space: pre-wrap;
    word-break: break-word;
  }

  :global(.code-viewer .token.comment),
  :global(.code-viewer .token.prolog),
  :global(.code-viewer .token.doctype),
  :global(.code-viewer .token.cdata) {
    color: #6a737d;
  }

  :global(.code-viewer .token) {
    display: inline;
  }

  :global(.code-viewer .token.punctuation) {
    color: #aab1bb;
  }

  :global(.code-viewer .token.property),
  :global(.code-viewer .token.tag),
  :global(.code-viewer .token.boolean),
  :global(.code-viewer .token.number),
  :global(.code-viewer .token.constant),
  :global(.code-viewer .token.symbol),
  :global(.code-viewer .token.deleted) {
    color: #f97583;
  }

  :global(.code-viewer .token.selector),
  :global(.code-viewer .token.attr-name),
  :global(.code-viewer .token.string),
  :global(.code-viewer .token.char),
  :global(.code-viewer .token.builtin),
  :global(.code-viewer .token.inserted) {
    color: #9ecbff;
  }

  :global(.code-viewer .token.operator),
  :global(.code-viewer .token.entity),
  :global(.code-viewer .token.url),
  :global(.code-viewer .language-css .token.string),
  :global(.code-viewer .style .token.string) {
    color: #79b8ff;
  }

  :global(.code-viewer .token.atrule),
  :global(.code-viewer .token.attr-value),
  :global(.code-viewer .token.keyword) {
    color: #b392f0;
  }

  :global(.code-viewer .token.function),
  :global(.code-viewer .token.class-name) {
    color: #ffab70;
  }

  :global(.code-viewer .token.regex),
  :global(.code-viewer .token.important),
  :global(.code-viewer .token.variable) {
    color: #ffab70;
  }
</style>
