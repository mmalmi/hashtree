<script lang="ts">
  /**
   * DirectoryActions - empty state with upload zone and README display
   * Port of React DirectoryActions component
   */
  import { getTree } from '../../store';
  import { nostrStore } from '../../nostr';
  import { routeStore, currentDirCidStore, treeRootStore, createTreesStore, directoryEntriesStore, createGitInfoStore, permalinkSnapshotStore, resolvingPathStore } from '../../stores';
  import FolderActions from '../FolderActions.svelte';
  import GitRepoView from '../Git/GitRepoView.svelte';
  import { uploadFiles } from '../../stores/upload';
  import { LinkType, toHex, type CID, type TreeEntry as HashTreeEntry } from '@hashtree/core';
  import { findNearestGitRootPath } from '../../utils/gitRoot';
  import { hasAmbiguousEmptyGitRootHint } from '../../utils/gitViewContext';
  import ViewerHeader from './ViewerHeader.svelte';
  import { buildSitesHref, findDirectorySiteEntry } from '../../lib/siteHref';
  import { buildTreeEventPermalink } from '../../lib/treeEventSnapshots';
  import { externalTreeKeysStore, isExternalTreeKey } from '../../lib/externalTrees';

  let route = $derived($routeStore);
  let permalinkSnapshot = $derived($permalinkSnapshotStore);
  let rootCid = $derived($treeRootStore);
  let rootHash = $derived(rootCid?.hash ?? null);
  let currentDirCid = $derived($currentDirCidStore);
  let currentPath = $derived(route.path);
  let dirEntries = $derived($directoryEntriesStore);
  let resolvingPath = $derived($resolvingPathStore);
  // Detect stale entries while a navigation is still in flight: entries are
  // "for" loadedHashKey, so when currentDirCid changes we should treat the
  // store as still loading until the new entries land.
  let currentDirHashKey = $derived(currentDirCid?.hash ? toHex(currentDirCid.hash) : null);
  let entriesAreStale = $derived(
    currentDirHashKey !== null && dirEntries.loadedHashKey !== currentDirHashKey
  );

  const emptyEntries: HashTreeEntry[] = [];
  let entries = $derived(resolvingPath || entriesAreStale ? emptyEntries : dirEntries.entries);
  let entriesLoading = $derived(dirEntries.loading || resolvingPath || entriesAreStale);

  let viewedNpub = $derived(route.npub ?? permalinkSnapshot.snapshot?.npub ?? null);
  let currentTreeName = $derived(route.treeName ?? permalinkSnapshot.snapshot?.treeName ?? null);
  let userNpub = $derived($nostrStore.npub);
  let isLoggedIn = $derived($nostrStore.isLoggedIn);

  // Get current tree for visibility info
  let targetNpub = $derived(viewedNpub || userNpub);
  let treesStore = $derived(createTreesStore(targetNpub));
  let trees = $derived($treesStore);

  let currentTree = $derived(currentTreeName ? trees.find(t => t.name === currentTreeName) : null);

  // Trees shown from outside Hashtree (lib/externalTrees) are read-only.
  let isExternalTree = $derived(isExternalTreeKey($externalTreeKeysStore, route.npub, route.treeName));
  let canEdit = $derived((!viewedNpub || viewedNpub === userNpub || !isLoggedIn) && !isExternalTree);

  let hasGitDir = $derived(entries.some(e => e.name === '.git' && e.type === LinkType.Dir));
  let currentPathKey = $derived(currentPath.join('/'));
  let treeCidKey = $derived(rootCid ? `${toHex(rootCid.hash)}:${rootCid.key ? toHex(rootCid.key) : ''}` : null);
  let linkKey = $derived(route.params.get('k'));
  let treeScope = $derived(
    !route.isPermalink && route.npub && route.treeName
      ? JSON.stringify([route.npub, route.treeName, linkKey])
      : treeCidKey
  );
  let gitRootFromUrl = $derived(route.params.get('g'));
  function includesGitRoot(directory: string, root: string): boolean {
    return root === '' || directory === root || directory.startsWith(root + '/');
  }

  let routeGitRootHint = $derived(
    gitRootFromUrl !== null &&
    !hasAmbiguousEmptyGitRootHint(gitRootFromUrl, currentPath) &&
    includesGitRoot(currentPathKey, gitRootFromUrl)
      ? gitRootFromUrl : null
  );
  let detectedGitRoot = $state.raw<{ scope: string; tree: string; directory: string; path: string | null } | null>(null);
  let detectedGitRootPath = $derived(detectedGitRoot?.scope === treeScope ? detectedGitRoot?.path ?? null : null);
  // The last confirmed root still applies while moving within that repository.
  let effectiveGitRootPath = $derived(
    routeGitRootHint ??
    (hasGitDir ? currentPathKey : null) ??
    (detectedGitRootPath !== null && includesGitRoot(currentPathKey, detectedGitRootPath)
      ? detectedGitRootPath : null)
  );
  let gitMetadataReady = $derived(effectiveGitRootPath !== null || (
    detectedGitRoot?.scope === treeScope && detectedGitRoot?.tree === treeCidKey &&
    detectedGitRoot?.directory === currentPathKey
  ));

  $effect(() => {
    const scope = treeScope;
    const tree = treeCidKey;
    const cid = rootCid;
    const path = currentPath;
    const directory = currentPathKey;
    if (!scope || !tree || !cid || !currentDirCid || entriesLoading) return;

    if (hasGitDir) {
      detectedGitRoot = { scope, tree, directory, path: directory };
      return;
    }
    if (routeGitRootHint !== null) return;

    let cancelled = false;
    void findNearestGitRootPath(cid, path).catch(() => null).then(gitRootPath => {
      if (!cancelled) detectedGitRoot = { scope, tree, directory, path: gitRootPath };
    });
    return () => { cancelled = true; };
  });

  let resolvedGitRoot = $state.raw<{ scope: string; path: string; cid: CID | null } | null>(null);
  let gitRootCid = $derived.by(() => {
    if (!gitMetadataReady) return null;
    if (effectiveGitRootPath === '') return rootCid;
    if (!resolvingPath && (effectiveGitRootPath === null || effectiveGitRootPath === currentPathKey)) {
      return currentDirCid;
    }
    if (resolvedGitRoot?.scope === treeScope && resolvedGitRoot.path === effectiveGitRootPath) {
      return resolvedGitRoot.cid;
    }
    return null;
  });

  $effect(() => {
    const tree = rootCid;
    const scope = treeScope;
    const path = effectiveGitRootPath;
    if (!tree || !scope || !path) return;

    let cancelled = false;
    void getTree().resolvePath(tree, path).catch(() => null).then(result => {
      if (!cancelled) resolvedGitRoot = { scope, path, cid: result?.cid ?? null };
    });
    return () => { cancelled = true; };
  });

  // Full git info (branches, etc) - loaded async once metadata CID is ready
  let gitInfoStore = $derived(createGitInfoStore(
    gitMetadataReady ? gitRootCid : null,
    undefined,
    { retryRepoDetection: true },
  ));
  let gitInfo = $derived($gitInfoStore);

  // Show actions if we have a tree OR we're in a tree context (empty tree that hasn't been created yet)
  let hasTreeContext = $derived(rootHash !== null || (route.treeName !== null && canEdit));

  let isDraggingOver = $state(false);
  let fileInputRef: HTMLInputElement | undefined = $state();

  function openFilePicker() {
    fileInputRef?.click();
  }

  async function handleFileInputChange(e: Event) {
    const input = e.target as HTMLInputElement;
    const files = input.files;
    if (files && files.length > 0) {
      await uploadFiles(files);
    }
    // Reset input so same file can be selected again
    input.value = '';
  }

  // Handle external file drop
  async function handleFileDrop(e: DragEvent) {
    e.preventDefault();
    isDraggingOver = false;
    if (!canEdit) return;

    const files = e.dataTransfer?.files;
    if (files && files.length > 0) {
      await uploadFiles(files);
    }
  }

  function handleFileDragOver(e: DragEvent) {
    if (!canEdit) return;
    if (e.dataTransfer?.types.includes('Files')) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      isDraggingOver = true;
    }
  }

  function handleFileDragLeave(e: DragEvent) {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    if (
      e.clientX < rect.left ||
      e.clientX > rect.right ||
      e.clientY < rect.top ||
      e.clientY > rect.bottom
    ) {
      isDraggingOver = false;
    }
  }

  // Check if should hide actions (locked link-visible/private)
  let hideActions = $derived(
    rootCid?.hash && !rootCid?.key && currentTree &&
    (currentTree.visibility === 'link-visible' || currentTree.visibility === 'private')
  );

  // Build back URL (parent directory or tree list)
  let backUrl = $derived.by(() => {
    if (route.isPermalink && route.params.get('snapshot') === '1' && permalinkSnapshot.snapshot) {
      if (currentPath.length > 0) {
        return buildTreeEventPermalink(permalinkSnapshot.snapshot, currentPath.slice(0, -1), route.params.get('k'));
      }
      return viewedNpub ? `#/${encodeURIComponent(viewedNpub)}` : '#/';
    }
    const parts: string[] = [];
    if (route.npub && route.treeName) {
      // In a tree - go to parent dir or tree list
      if (currentPath.length > 0) {
        // In a subdirectory - go to parent
        parts.push(route.npub, route.treeName, ...currentPath.slice(0, -1));
      } else {
        // At tree root - go to tree list
        parts.push(route.npub);
      }
    }
    const linkKeySuffix = route.params.get('k') ? `?k=${route.params.get('k')}` : '';
    return '#/' + parts.map(encodeURIComponent).join('/') + linkKeySuffix;
  });

  // Use the actual current path/back URL during navigation so the breadcrumb
  // and back button reflect the user's chosen target immediately. Older code
  // cached the previous path while resolvingPath=true, which caused the
  // breadcrumb to briefly show the old location and then jump to the new one.
  let gitViewPath = $derived(currentPath);
  let gitViewBackUrl = $derived(backUrl);

  let directoryScroll: HTMLDivElement | undefined = $state();
  $effect.pre(() => {
    currentPathKey;
    if (directoryScroll) directoryScroll.scrollTop = 0;
  });

  // Get current directory name
  let currentDirName = $derived.by(() => {
    if (currentPath.length > 0) {
      return currentPath[currentPath.length - 1];
    }
    return currentTreeName || '';
  });

  let siteEntryName = $derived(findDirectorySiteEntry(entries.filter((entry) => entry.type !== LinkType.Dir)));
  let openSiteHref = $derived.by(() => {
    if (!siteEntryName || !currentDirCid) return '';
    return buildSitesHref({
      route,
      siteRootCid: currentDirCid,
      siteRootPath: currentPath,
      entryPath: siteEntryName,
      autoReloadMutable: true,
    });
  });

</script>

<!-- Every resolved directory renders as a repository listing. -->
{#if currentDirCid}
  <div class="flex flex-col h-full">
    <div class="flex-1 overflow-auto" bind:this={directoryScroll}>
      <GitRepoView
        dirCid={resolvingPath ? null : currentDirCid}
        {gitRootCid}
        gitRootPath={effectiveGitRootPath}
        loadGitMetadata={gitMetadataReady}
        {entries}
        {entriesLoading}
        {canEdit}
        currentBranch={gitInfo.currentBranch}
        branches={gitInfo.branches}
        tags={gitInfo.tags}
        tagsByCommit={gitInfo.tagsByCommit}
        gitBranchNamesLoading={gitInfo.branchNamesLoading}
        gitTagNamesLoading={gitInfo.tagNamesLoading}
        gitInfoLoading={gitInfo.loading}
        backUrl={gitViewBackUrl}
        displayPath={gitViewPath}
        npub={viewedNpub}
        isPermalink={route.isPermalink}
        {rootCid}
        visibility={currentTree?.visibility}
      />
    </div>
  </div>
{:else}
  <div
    class="flex flex-col h-full"
    role="region"
    aria-label="Directory content"
    ondragover={handleFileDragOver}
    ondragleave={handleFileDragLeave}
    ondrop={handleFileDrop}
  >
    <!-- Header with back button, avatar, visibility, folder name -->
    <ViewerHeader
      {backUrl}
      npub={viewedNpub}
      isPermalink={route.isPermalink}
      {rootCid}
      visibility={currentTree?.visibility}
      icon="i-lucide-folder-open text-warning"
      name={currentDirName}
    >
      {#snippet actions()}
        {#if openSiteHref}
          <a
            href={openSiteHref}
            target="_blank"
            rel="noreferrer"
            class="btn-ghost no-underline"
            data-testid="directory-open-site"
          >
            Open Site
          </a>
        {/if}
      {/snippet}
    </ViewerHeader>
    <!-- Action buttons - hide when viewing locked link-visible/private directory -->
    {#if hasTreeContext && !hideActions}
      <div class="p-3 shrink-0">
        <FolderActions dirCid={currentDirCid} dirName={currentDirName} {canEdit} />
      </div>
    {/if}

  <!-- Upload drop zone -->
  {#if hasTreeContext && canEdit}
    <div
      class="flex-1 mx-3 mb-3 flex items-center justify-center cursor-pointer transition-colors border border-surface-3 rounded-lg {isDraggingOver ? 'bg-surface-1/50' : 'hover:bg-surface-1/50'}"
      onclick={openFilePicker}
      role="button"
      tabindex="0"
      onkeydown={(e) => { if (e.key === 'Enter' || e.key === ' ') openFilePicker(); }}
    >
      <div class="flex flex-col items-center text-text-3">
        <span class="i-lucide-plus text-4xl mb-2"></span>
        <span class="text-sm">Drop or click to add</span>
      </div>
      <input
        bind:this={fileInputRef}
        type="file"
        multiple
        class="hidden"
        onchange={handleFileInputChange}
      />
    </div>
  {/if}
  </div>
{/if}
