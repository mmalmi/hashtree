<script lang="ts">
  import { navigate } from '../lib/router.svelte';
  import { nostrStore, generateNewKey } from '../nostr';
  import { Avatar } from './User';

  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let sessionReady = $derived($nostrStore.sessionReady);
  let npub = $derived($nostrStore.npub);
  let pubkey = $derived($nostrStore.pubkey);

  function goToProfile() {
    if (!npub) return;
    navigate(`/${npub}/profile`);
  }

  async function handleGenerate() {
    await generateNewKey();
  }
</script>

{#if isLoggedIn && pubkey}
  <!-- Logged in: just show avatar that links to profile (double-click for accounts) -->
  <button
    onclick={goToProfile}
    ondblclick={() => navigate('/users')}
    class="bg-transparent border-none cursor-pointer p-0"
    title="My profile (double-click to switch profiles)"
  >
    <Avatar pubkey={pubkey} size={36} />
  </button>
{:else if !sessionReady}
  <div
    class="w-9 h-9 rounded-full bg-surface-2 animate-pulse"
    aria-label="Restoring profile"
  ></div>
{:else}
  <div class="flex flex-wrap gap-2">
    <button onclick={handleGenerate} class="btn-success text-sm">Create profile</button>
    <button onclick={() => navigate('/users')} class="btn-ghost text-sm">Sign in</button>
  </div>
{/if}
