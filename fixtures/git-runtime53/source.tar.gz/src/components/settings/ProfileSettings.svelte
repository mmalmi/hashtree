<script lang="ts">
  import SharedProfileSettings from '@iris/svelte-ui/ProfileSettings.svelte';
  import { copyToClipboard } from '@iris/svelte-ui/clipboard';
  import { accountsStore } from '../../accounts';
  import { getNsec, loginWithSavedProfile } from '../../nostr/auth';
  import { nostrStore } from '../../nostr';
  import { Avatar, Name } from '../User';

  let activeProfileId = $derived($nostrStore.isLoggedIn ? $nostrStore.pubkey : null);
  let canCopySecretKey = $derived($nostrStore.isLoggedIn && Boolean(getNsec()));
  let profiles = $derived.by(() => {
    const saved = $accountsStore.accounts.map(({ pubkey, npub }) => ({ id: pubkey, publicKey: npub }));
    const npub = $nostrStore.npub;
    if (activeProfileId && npub && !saved.some(profile => profile.id === activeProfileId)) {
      saved.unshift({ id: activeProfileId, publicKey: npub });
    }
    return saved;
  });

  async function signInWithProfile(profileId: string) {
    const account = accountsStore.getState().accounts.find(account => account.pubkey === profileId);
    if (!account || !await loginWithSavedProfile(account)) {
      throw new Error('Could not sign in with this saved profile.');
    }
  }

  async function copySecretKey(profileId: string) {
    const { pubkey, isLoggedIn } = nostrStore.getState();
    const key = isLoggedIn && pubkey === profileId ? getNsec() : null;
    if (!key || await copyToClipboard(key) !== 'copied') {
      throw new Error('Could not copy the private key.');
    }
  }
</script>

{#if $nostrStore.sessionReady}
  <SharedProfileSettings
    {profiles}
    {activeProfileId}
    onSwitchProfile={signInWithProfile}
    onCopySecretKey={canCopySecretKey ? copySecretKey : undefined}
    signInHref="#/users"
    manageProfilesHref={activeProfileId ? '#/users' : undefined}
  >
    {#snippet profileAvatar(profile)}
      <Avatar pubkey={profile.id} size={40} />
    {/snippet}
    {#snippet profileName(profile)}
      <Name pubkey={profile.id} />
    {/snippet}
  </SharedProfileSettings>
{:else}
  <p class="text-sm text-text-3" role="status">Loading profiles…</p>
{/if}
