<script lang="ts">
  import SharedSettingsLayout from '@iris/hashtree-app/SettingsLayout.svelte';
  import { nostrStore } from '../../nostr';
  import { logout } from '../../nostr/auth';
  import { currentPath, navigate } from '../../lib/router.svelte';
  import AppSettings from './AppSettings.svelte';
  import P2PSettings from './P2PSettings.svelte';
  import ProfileSettings from './ProfileSettings.svelte';
  import ServersSettings from './ServersSettings.svelte';
  import StorageSettings from './StorageSettings.svelte';
  import TransportUsageSettings from './TransportUsageSettings.svelte';

  function signOut() {
    if (!nostrStore.getState().isLoggedIn) return;
    logout();
    window.location.reload();
  }
</script>

<SharedSettingsLayout
  currentPath={$currentPath}
  {navigate}
  profileSettings={ProfileSettings}
  onSignOut={$nostrStore.isLoggedIn ? signOut : undefined}
  appSettings={AppSettings}
  storageSettings={StorageSettings}
  trafficSettings={TransportUsageSettings}
  serversSettings={ServersSettings}
  p2pSettings={P2PSettings}
/>
