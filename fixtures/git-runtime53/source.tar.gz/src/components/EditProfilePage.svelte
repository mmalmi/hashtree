<script lang="ts">
  import { nip19, type Event } from 'nostr-tools';
  import PublicProfileEditor from '@iris/svelte-ui/PublicProfileEditor.svelte';
  import { readOwnProfileHead, saveOwnRawProfileEdits } from '@iris/hashtree-app/profileEdits';
  import { nostr, nostrStore } from '../nostr';
  import { getNewAccountProfile } from '../nostr/auth';
  import { invalidateProfile } from '../stores/profile';
  import { getNostrRelayUrls } from '../nostr/client';
  import { waitForSettingsLoaded } from '../stores/settings';
  import { waitForWorkerAdapter } from '../lib/workerInit';
  import { BackButton } from './ui';

  const sources = { async query(pubkey: string) {
    await waitForSettingsLoaded();
    const adapter = await waitForWorkerAdapter();
    const relays = getNostrRelayUrls();
    if (!adapter?.queryEvents || !relays.length) throw new Error('Connect to your Nostr relays to edit your public profile.');
    const result = await adapter.queryEvents([{ kinds: [0], authors: [pubkey], limit: 1 }], {
      cache: 'network-only', relays, sources: [], deadline: Date.now() + 8000,
    });
    const initial = getNewAccountProfile(pubkey);
    return initial ? { ...result, events: [...result.events, initial] } : result;
  } };

  let { npub }: { npub?: string } = $props();
  let owner = $derived.by(() => {
    if (!npub) return '';
    try {
      const address = nip19.decode(npub);
      return address.type === 'npub' ? address.data : '';
    } catch { return ''; }
  });
  let own = $derived(Boolean(owner && $nostrStore.isLoggedIn && $nostrStore.pubkey === owner));
  let profile = $state.raw<Event | null | undefined>(undefined);
  let error = $state('');
  let attempt = $state(0);

  $effect(() => {
    if (owner && $nostrStore.pubkey && $nostrStore.pubkey !== owner) window.location.hash = `/${npub}`;
  });

  $effect(() => {
    const pubkey = owner;
    void attempt;
    profile = undefined;
    error = '';
    if (!own) return;
    let active = true;
    void readOwnProfileHead(nostr, pubkey, sources).then(event => {
      if (active) profile = event;
    }).catch(cause => {
      if (active) error = cause instanceof Error ? cause.message : 'Could not load your public profile.';
    });
    return () => { active = false; };
  });

  function close() { window.location.hash = `/${npub}/profile`; }

  async function save(edits: Readonly<Record<string, string | undefined>>, base: Event | null) {
    if (!own) throw new Error('Sign in to edit your profile.');
    const pubkey = owner;
    const signed = await saveOwnRawProfileEdits(nostr, pubkey, base, edits, sources);
    invalidateProfile(signed.pubkey);
    if (own && owner === pubkey) close();
    return signed;
  }
</script>

{#if own}
  <div class="flex-1 flex flex-col min-h-0 bg-surface-0 overflow-y-auto">
    <header class="sticky top-0 z-10 bg-surface-1 border-b border-surface-3 px-4 py-3 flex items-center gap-3">
      <BackButton onclick={close} />
      <h1 class="text-lg font-semibold">Edit Profile</h1>
    </header>
    <div class="p-4 mx-auto w-full max-w-2xl">
      {#key owner}
        <PublicProfileEditor event={profile} onsaveraw={save} oncancel={close} blockedReason={error} />
        {#if error}<button class="mt-3 btn-secondary" onclick={() => attempt++}>Try again</button>{/if}
      {/key}
    </div>
  </div>
{:else}
  <div class="flex-1 flex items-center justify-center bg-surface-0">Sign in to edit your profile.</div>
{/if}
