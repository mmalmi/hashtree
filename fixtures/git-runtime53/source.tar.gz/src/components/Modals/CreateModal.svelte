<script lang="ts" module>
  /**
   * Modal for creating new files, repositories, or trees
   */
  import type { TreeVisibility } from '@hashtree/core';

  export type ModalType = 'file' | 'folder' | 'tree' | 'repository';

  let show = $state(false);
  let modalType = $state<ModalType>('file');
  let treeVisibility = $state<TreeVisibility>('public');
  let modalInput = $state('');

  export function open(type: ModalType, visibility: TreeVisibility = 'public') {
    modalType = type;
    treeVisibility = visibility;
    modalInput = '';
    show = true;
  }

  export function close() {
    show = false;
    modalInput = '';
  }

  export function setVisibility(v: TreeVisibility) {
    treeVisibility = v;
  }
</script>

<script lang="ts">
  import { createFile, createGitRepository, createTree } from '../../actions';
  import VisibilityPicker from '@iris/hashtree-app/VisibilityPicker.svelte';

  let isCreating = $state(false);
  let inputRef = $state<HTMLInputElement | null>(null);

  // Focus input when modal opens
  $effect(() => {
    if (show && inputRef) {
      inputRef.focus();
    }
  });

  // 'folder' creates a repository inside the current tree; 'repository' creates a new tree.
  let isFolder = $derived(modalType === 'folder');
  let isTree = $derived(modalType === 'tree');
  let isRepository = $derived(modalType === 'repository');

  let title = $derived(
    isTree ? 'New Folder' : isRepository || isFolder ? 'New Repository' : 'New File'
  );
  let placeholder = $derived(
    isTree ? 'Folder name...' : isRepository || isFolder ? 'Repository name...' : 'File name...'
  );

  async function handleSubmit(e?: Event) {
    e?.preventDefault();
    const name = modalInput.trim();
    if (!name || isCreating) return;

    if (isRepository) {
      isCreating = true;
      const { createGitRepositoryTree } = await import('../../actions/tree');
      await createGitRepositoryTree(name, treeVisibility);
      isCreating = false;
      close();
    } else if (isTree) {
      isCreating = true;
      await createTree(name, treeVisibility);
      isCreating = false;
      close();
    } else if (isFolder) {
      isCreating = true;
      await createGitRepository(name);
      isCreating = false;
      close();
    } else {
      createFile(name, '');
      close();
    }
  }

  function handleKeyDown(e: KeyboardEvent) {
    if (e.key === 'Escape') close();
    if (e.key === 'Enter') handleSubmit();
  }
</script>

{#if show}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div
    class="fixed inset-0 z-50 flex items-center justify-center bg-black/70"
    onclick={close}
  >
    <div
      class="bg-surface-1 rounded-lg shadow-lg p-6 w-full max-w-md mx-4"
      onclick={(e) => e.stopPropagation()}
      onkeydown={handleKeyDown}
    >
      <h2 class="text-lg font-semibold mb-4">{title}</h2>
      <form onsubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
        <input
          bind:this={inputRef}
          type="text"
          bind:value={modalInput}
          placeholder={placeholder}
          class="input w-full mb-4"
        />

        <!-- Visibility picker for new trees -->
        {#if isTree || isRepository}
          <div class="mt-4 mb-4">
            <VisibilityPicker value={treeVisibility} onchange={setVisibility} />
          </div>
        {/if}

        <div class="flex justify-end gap-2">
          <button type="button" onclick={close} class="btn-ghost">Cancel</button>
          <button type="submit" class="btn-success" disabled={isCreating}>
            {isCreating ? 'Creating...' : 'Create'}
          </button>
        </div>
      </form>
    </div>
  </div>
{/if}
