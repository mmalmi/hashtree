<script lang="ts">
  import ProxyImg from '@iris/svelte-ui/ProxyImg.svelte';
  import { settingsStore } from '../../stores/settings';
  import Minidenticon from './Minidenticon.svelte';

  interface Props {
    kind: 'banner' | 'picture';
    src?: string;
    pubkey: string;
  }

  let { kind, src, pubkey }: Props = $props();
  let picture = $derived(kind === 'picture');
  let label = $derived(picture ? 'Profile picture' : 'Profile banner');
  let thumbnailFailed = $state(false);
  let previewFailed = $state(false);
  let expanded = $state(false);
  let dialog: HTMLDialogElement;

  function expand() {
    previewFailed = false;
    expanded = true;
    dialog.showModal();
  }
</script>

{#if src && !thumbnailFailed}
  <button
    type="button"
    class={picture ? 'thumbnail picture' : 'thumbnail banner'}
    aria-haspopup="dialog"
    aria-label={`Expand profile ${kind}`}
    onclick={expand}
  >
    <ProxyImg {src} alt="" width={picture ? 160 : 1200} height={picture ? 160 : 320}
      square={picture} imgProxy={$settingsStore.imgproxy} loadOriginalIfProxyFails={true}
      class="block size-full object-cover" onError={() => thumbnailFailed = true} />
  </button>
{:else if picture}
  <Minidenticon seed={pubkey} size={80} class="border-4 border-surface-0" />
{/if}

<dialog
  bind:this={dialog}
  aria-label={label}
  onclose={() => expanded = false}
  onpointerup={(event) => { if (event.target === dialog) dialog.close(); }}
>
  {#if expanded}
    {#if previewFailed}
      <p role="status">This image couldn’t be loaded.</p>
    {:else}
      <ProxyImg {src} alt={label} loading="eager" loadTimeoutMs={0} imgProxy={$settingsStore.imgproxy} loadOriginalIfProxyFails={true}
        class={picture ? 'preview enlarged-picture' : 'preview'} onError={() => previewFailed = true} />
    {/if}
  {/if}
  <button type="button" class="close" aria-label="Close image" onclick={() => dialog.close()}>
    <span class="i-lucide-x text-xl" aria-hidden="true"></span>
  </button>
</dialog>

<style>
  .thumbnail { display: block; overflow: hidden; padding: 0; background: transparent; cursor: zoom-in; }
  .banner { width: 100%; height: 100%; border: 0; }
  .picture { width: 80px; height: 80px; border: 4px solid rgb(var(--surface-0)); border-radius: 50%; }
  .thumbnail:focus-visible { outline: 3px solid #916dfe; outline-offset: -4px; }

  dialog[open] {
    position: fixed; inset: 0; display: grid; place-items: center; margin: 0;
    width: 100%; height: 100%; max-width: none; max-height: none; box-sizing: border-box;
    padding: 56px 16px; border: 0; background: transparent; color: white;
  }
  dialog::backdrop { background: rgb(0 0 0 / 90%); }
  dialog :global(.preview) {
    display: block; width: auto; height: auto; max-width: 100%; max-height: calc(100dvh - 112px);
    object-fit: contain;
  }
  dialog :global(.enlarged-picture) { min-width: min(320px, 100%); }
  .close {
    position: absolute; top: max(12px, env(safe-area-inset-top)); right: max(12px, env(safe-area-inset-right));
    display: grid; place-items: center; width: 44px; height: 44px; border-radius: 50%;
    background: #252525; color: white;
  }
  .close:hover, .close:focus-visible { background: #404040; }
</style>
