<script lang="ts">
  /**
   * Tab navigation for repository views (Code, Pull Requests, Issues, Releases)
   * Uses query params (?tab=pulls, ?tab=issues, ?tab=releases) to avoid conflicts with directory names
   */
  import { routeStore } from '../../stores';
  import type { RepoChildTabId } from './repoSection';
  import { createRepoTabCountsStore, formatRepoTabCount } from '../../stores/nip34';

  interface RepoTab {
    id: RepoChildTabId;
    label: string;
    icon: string;
    query: string;
    count: number | null;
  }

  interface Props {
    npub: string;
    repoName: string;
    activeTab: RepoChildTabId;
    loadCounts?: boolean;
  }

  let { npub, repoName, activeTab, loadCounts = true }: Props = $props();
  let route = $derived($routeStore);
  let canLoadCounts = $derived(loadCounts && !route.params.has('k'));
  let repoTabCountsStore = $derived(createRepoTabCountsStore(canLoadCounts ? npub : null, repoName));
  let repoTabCounts = $derived($repoTabCountsStore);

  let tabs = $derived.by((): RepoTab[] => [
    { id: 'code', label: 'Code', icon: 'i-lucide-code', query: '', count: null },
    {
      id: 'pulls',
      label: 'Pull Requests',
      icon: 'i-lucide-git-pull-request',
      query: '?tab=pulls',
      count: repoTabCounts.pullRequests,
    },
    {
      id: 'issues',
      label: 'Issues',
      icon: 'i-lucide-circle-dot',
      query: '?tab=issues',
      count: repoTabCounts.issues,
    },
    { id: 'releases', label: 'Releases', icon: 'i-lucide-tag', query: '?tab=releases', count: null },
  ]);

  function getHref(tab: RepoTab): string {
    const linkKey = route.params.get('k');
    if (!linkKey) {
      return `#/${npub}/${repoName}${tab.query}`;
    }
    const separator = tab.query ? '&' : '?';
    return `#/${npub}/${repoName}${tab.query}${separator}k=${linkKey}`;
  }

  function shouldShowCount(tab: RepoTab): boolean {
    return tab.id === 'pulls' || tab.id === 'issues';
  }

  function getDisplayedCount(tab: RepoTab): string {
    return formatRepoTabCount(tab.count ?? 0);
  }
</script>

<nav aria-label="Repository" class="shrink-0 overflow-x-auto scrollbar-hide px-2 sm:px-4 b-b-1 b-b-solid b-b-surface-3" data-testid="repo-tab-nav">
  <div class="flex items-center gap-1 min-w-max">
    {#each tabs as tab (tab.id)}
      <a
        href={getHref(tab)}
        aria-current={activeTab === tab.id ? 'page' : undefined}
        class="shrink-0 flex items-center gap-1.5 px-2 py-3 sm:gap-2 sm:px-3 text-sm font-medium transition-colors b-b-2 b-b-solid -mb-px no-underline {
          activeTab === tab.id
            ? 'b-b-accent text-text-1'
            : 'b-b-transparent text-text-2 hover:text-text-1 hover:b-b-surface-3'
        }"
      >
        <span class="{tab.icon} hidden sm:inline-block" aria-hidden="true"></span>
        <span>{tab.label}</span>
        {#if shouldShowCount(tab)}
          <span
            class="min-w-5 rounded-full bg-surface-2 px-1.5 py-0.5 text-center text-xs leading-none tabular-nums {
              activeTab === tab.id ? 'text-text-1' : 'text-text-2'
            }"
          >
            {getDisplayedCount(tab)}
          </span>
        {/if}
      </a>
    {/each}
  </div>
</nav>
