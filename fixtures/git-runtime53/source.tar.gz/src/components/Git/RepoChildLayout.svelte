<script lang="ts">
  import type { CID, TreeVisibility } from '@hashtree/core';
  import type { Snippet } from 'svelte';
  import RepoHeader from './RepoHeader.svelte';
  import RepoTabNav from './RepoTabNav.svelte';
  import { getDefaultRepoSectionLabel, type RepoChildTabId } from './repoSection';

  interface Props {
    npub: string;
    repoName: string;
    backUrl: string;
    activeTab?: RepoChildTabId;
    rootCid?: CID | null;
    visibility?: TreeVisibility;
    isPermalink?: boolean;
    contentMaxWidthClass?: string;
    sectionLabel?: string;
    sectionHref?: string;
    children?: Snippet;
  }

  let {
    npub,
    repoName,
    backUrl,
    activeTab = 'code',
    rootCid = null,
    visibility,
    isPermalink = false,
    contentMaxWidthClass = 'max-w-7xl',
    sectionLabel,
    sectionHref,
    children,
  }: Props = $props();

  let resolvedSectionLabel = $derived(sectionLabel ?? getDefaultRepoSectionLabel(activeTab));
</script>

<div class="flex min-h-0 min-w-0 flex-1 flex-col bg-surface-0">
  <RepoTabNav
    {npub}
    {repoName}
    {activeTab}
    loadCounts={visibility === 'public' || (visibility === undefined && activeTab !== 'releases')}
  />

  <div class="mx-auto w-full max-w-7xl px-3 py-3">
    <RepoHeader
      {backUrl}
      {npub}
      {rootCid}
      {visibility}
      {repoName}
      {isPermalink}
      sectionLabel={resolvedSectionLabel}
      {sectionHref}
    />
  </div>

  <div class={`mx-auto flex w-full ${contentMaxWidthClass} flex-1 flex-col`}>
    {@render children?.()}
  </div>
</div>
