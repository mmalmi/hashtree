<script lang="ts">
  import { LinkType, type CID, type TreeEntry } from '@hashtree/core';
  import { untrack } from 'svelte';
  import { savePublicFileHistory } from '../../utils/publicGitFileHistory';
  import type { Readable } from 'svelte/store';
  import { SvelteMap } from 'svelte/reactivity';
  import { decodeAsText, getTree } from '../../store';
  import type { CIConfig, CIStatus } from '../../stores/ci';
  import type { CommitInfo } from '../../stores/git';
  import { getFileLastCommits, getHead } from '../../utils/git';
  import FileTable from './FileTable.svelte';
  import ReadmePanel from '../Viewer/ReadmePanel.svelte';

  const PRIORITY_FILE_COMMIT_COUNT = 24;

  interface FileCommitInfo {
    oid: string;
    message: string;
    timestamp: number;
  }

  interface Props {
    gitCid: CID | null;
    gitSubpath: string;
    entries: TreeEntry[];
    entriesLoading: boolean;
    publicHistoryDirectory?: string;
    onHistorySettled: (cid: CID) => void;
    buildEntryHref: (entry: TreeEntry) => string;
    buildCommitHref: (commitOid: string) => string;
    latestCommit: CommitInfo | null;
    latestCommitTags: string[];
    commitsLoading: boolean;
    parentHref: string | null;
    ciStatus: CIStatus | null;
    ciStatusStore: Readable<CIStatus> | null;
    repoPath: string;
    ciConfig: CIConfig | null;
    canEdit: boolean;
  }

  let {
    gitCid,
    gitSubpath,
    entries,
    entriesLoading,
    onHistorySettled,
    publicHistoryDirectory,
    buildEntryHref,
    buildCommitHref,
    latestCommit,
    latestCommitTags,
    commitsLoading,
    parentHref,
    ciStatus,
    ciStatusStore,
    repoPath,
    ciConfig,
    canEdit,
  }: Props = $props();

  let fileCommits = $state.raw(new SvelteMap<string, FileCommitInfo>());
  let sortedEntries = $derived([...entries].sort((a, b) =>
    Number(b.type === LinkType.Dir) - Number(a.type === LinkType.Dir) || a.name.localeCompare(b.name)
  ));

  $effect(() => {
    const cid = gitCid;
    // Visibility can arrive after the listing. Keep its active walk and save
    // the complete result if this directory is confirmed public when it ends.
    const publicDirectory = untrack(() => publicHistoryDirectory);
    const subpath = gitSubpath;
    const filenames = sortedEntries.filter(entry => entry.name !== '.git').map(entry => entry.name);
    const rows = new SvelteMap<string, FileCommitInfo>();
    fileCommits = rows;
    if (!cid || entriesLoading) return;
    if (!filenames.length) {
      onHistorySettled(cid);
      return;
    }

    const controller = new AbortController();
    const load = (names: string[]) => getFileLastCommits(cid, names, subpath, (name, commit) => {
      rows.set(name, commit);
    }, controller.signal, publicDirectory);

    void load(filenames).then(async result => {
      if (controller.signal.aborted) return;
      const missing = filenames.slice(0, PRIORITY_FILE_COMMIT_COUNT).filter(name => !result.has(name));
      if (missing.length) {
        await new Promise(resolve => setTimeout(resolve, 300));
        if (controller.signal.aborted) return;
        for (const [name, info] of await load(missing)) result.set(name, info);
      }
      const directory = publicHistoryDirectory;
      if (directory && result.size && !controller.signal.aborted) {
        const head = await getHead(cid);
        if (head && !controller.signal.aborted && directory === publicHistoryDirectory) {
          await savePublicFileHistory(directory, head, result);
        }
      }
    }).catch(() => {}).finally(() => {
      if (!controller.signal.aborted) onHistorySettled(cid);
    });

    return () => controller.abort();
  });

  let readmeContent = $state<string | null>(null);

  $effect(() => {
    readmeContent = null;
    const readmeEntry = entries.find(
      e => e.name.toLowerCase() === 'readme.md' && e.type !== LinkType.Dir,
    );
    if (!readmeEntry) return;

    let cancelled = false;
    getTree().readFile(readmeEntry.cid).then(data => {
      if (!cancelled && data) {
        const text = decodeAsText(data);
        if (text) readmeContent = text;
      }
    });
    return () => {
      cancelled = true;
    };
  });
</script>

<div class="b-1 b-surface-3 b-solid rounded-lg overflow-hidden bg-surface-0" data-testid="file-list" aria-busy={entriesLoading}>
  <FileTable
    entries={sortedEntries}
    {entriesLoading}
    {fileCommits}
    {buildEntryHref}
    {buildCommitHref}
    {latestCommit}
    {latestCommitTags}
    {commitsLoading}
    {parentHref}
    {ciStatus}
    {ciStatusStore}
    {repoPath}
    {ciConfig}
  />
</div>

{#if readmeContent}
  <ReadmePanel content={readmeContent} {entries} {canEdit} />
{/if}
