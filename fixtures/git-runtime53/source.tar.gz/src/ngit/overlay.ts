/**
 * In-memory block stores for imported repos. Tree reads see them through
 * lib/externalTrees; the backend never stores or uploads them.
 */
import { HashTree, toHex, type Hash, type Store } from '@hashtree/core';
import { NGIT_MAX_CACHED_REPOS } from './config';

export class OverlayStore implements Store {
  private blocks = new Map<string, Uint8Array>();
  bytes = 0;

  async put(hash: Hash, data: Uint8Array): Promise<boolean> {
    const key = toHex(hash);
    if (!this.blocks.has(key)) {
      this.blocks.set(key, data);
      this.bytes += data.length;
    }
    return true;
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    return this.blocks.get(toHex(hash)) ?? null;
  }

  async has(hash: Hash): Promise<boolean> {
    return this.blocks.has(toHex(hash));
  }

  async delete(hash: Hash): Promise<boolean> {
    const key = toHex(hash);
    const data = this.blocks.get(key);
    if (!data) return false;
    this.blocks.delete(key);
    this.bytes -= data.length;
    return true;
  }

  read(hashHex: string): Uint8Array | null {
    return this.blocks.get(hashHex) ?? null;
  }
}

export interface Overlay {
  store: OverlayStore;
  tree: HashTree;
}

const overlays = new Map<string, Overlay>();

/** A new store for `key`. The oldest stores are dropped past the limit; `onEvict` gets their keys. */
export function createOverlay(key: string, onEvict: (key: string) => void): Overlay {
  overlays.delete(key);
  const store = new OverlayStore();
  const overlay = { store, tree: new HashTree({ store }) };
  overlays.set(key, overlay);
  while (overlays.size > NGIT_MAX_CACHED_REPOS) {
    const oldest = overlays.keys().next().value!;
    overlays.delete(oldest);
    onEvict(oldest);
  }
  return overlay;
}

export function dropOverlay(key: string): void {
  overlays.delete(key);
}

export function readOverlayBlock(hashHex: string): Uint8Array | null {
  for (const overlay of overlays.values()) {
    const data = overlay.store.read(hashHex);
    if (data) return data;
  }
  return null;
}
