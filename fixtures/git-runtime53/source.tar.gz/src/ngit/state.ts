/** What pages show about the current route's ngit repo. Kept apart so pages do not load the fetch code. */
import { writable, type Readable } from 'svelte/store';

export interface NgitRepoView {
  key: string;
  npub: string;
  repoName: string;
  status: 'loading' | 'ready' | 'error';
  /** Grasp server the files come from. */
  sourceHost: string;
  /** The repo's web page, or a browser URL for its clone URL: where to go if loading here fails. */
  webUrl: string | null;
  error?: string;
  branch?: string;
  /** HEAD is the commit the maintainer signed; unset until that is known. */
  signed?: boolean;
  /** Older history was not fetched. */
  partialHistory?: boolean;
}

const current = writable<NgitRepoView | null>(null);

export const ngitRepoStore: Readable<NgitRepoView | null> = { subscribe: current.subscribe };

export function setNgitRepoView(view: NgitRepoView | null): void {
  current.set(view);
}

export async function retryNgitRepo(key: string): Promise<void> {
  const { retryNgitRepo: retry } = await import('./session');
  retry(key);
}
