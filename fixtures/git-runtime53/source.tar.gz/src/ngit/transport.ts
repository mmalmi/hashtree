/**
 * Git smart HTTP (protocol version 2) to grasp servers, straight from the page.
 * Requests carry no cookies or referrer.
 */
import {
  fetchRequest,
  lsRefsRequest,
  parseFetchResponse,
  parseLsRefsResponse,
  type FetchRequest,
  type FetchResponse,
  type RemoteRefs,
} from './protocol';

export interface GitHttpOptions {
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
  /** The request fails once the response is larger. */
  maxBytes: number;
}

async function readLimited(response: Response, maxBytes: number): Promise<Uint8Array> {
  const declared = Number(response.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > maxBytes) throw new GitResponseTooLargeError();
  if (!response.body) return new Uint8Array(await response.arrayBuffer());
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxBytes) {
      void reader.cancel();
      throw new GitResponseTooLargeError();
    }
    chunks.push(value);
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
}

export class GitResponseTooLargeError extends Error {
  constructor() {
    super('The repository is too large to show here');
    this.name = 'GitResponseTooLargeError';
  }
}

export function uploadPackEndpoint(cloneUrl: string): string {
  return `${cloneUrl.replace(/\/+$/, '')}/git-upload-pack`;
}

async function uploadPack(cloneUrl: string, body: Uint8Array, options: GitHttpOptions): Promise<Uint8Array> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const response = await fetchImpl(uploadPackEndpoint(cloneUrl), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-git-upload-pack-request',
      Accept: 'application/x-git-upload-pack-result',
      'Git-Protocol': 'version=2',
    },
    body: body as BodyInit,
    signal: options.signal,
    credentials: 'omit',
    referrerPolicy: 'no-referrer',
    cache: 'no-store',
  });
  if (!response.ok) throw new Error(`Git server answered ${response.status}`);
  return readLimited(response, options.maxBytes);
}

export async function lsRefs(
  cloneUrl: string,
  options: GitHttpOptions,
  lsOptions?: { includeTags?: boolean },
): Promise<RemoteRefs> {
  return parseLsRefsResponse(await uploadPack(cloneUrl, lsRefsRequest(lsOptions), options));
}

export async function fetchPack(cloneUrl: string, request: FetchRequest, options: GitHttpOptions): Promise<FetchResponse> {
  return parseFetchResponse(await uploadPack(cloneUrl, fetchRequest(request), options));
}
