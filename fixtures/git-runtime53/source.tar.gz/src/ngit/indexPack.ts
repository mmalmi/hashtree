/**
 * Build a pack index (.idx) with libgit2's indexer, which wasm-git already
 * bundles for iris-git's write paths. Loaded only when an ngit repo is opened.
 */
import type { IndexedPack } from './importRepo';

const PACK_INDEX = /^pack-([0-9a-f]{40})\.idx$/;

export async function indexPackWithWasmGit(pack: Uint8Array): Promise<IndexedPack> {
  const { createRepoPath, loadWasmGit, rmRf, withWasmGitLock } = await import('../utils/wasmGit/core');
  return withWasmGitLock(async () => {
    const module = await loadWasmGit();
    const dir = createRepoPath('ngit');
    const originalCwd = module.FS.cwd();
    try {
      module.FS.mkdir(dir);
      module.FS.chdir(dir);
      module.callWithOutput(['init', '.']);
      module.FS.writeFile('incoming.pack', pack);
      module.callWithOutput(['index-pack', 'incoming.pack']);
      const idxName = module.FS.readdir('.').find((name) => PACK_INDEX.test(name));
      const name = idxName?.match(PACK_INDEX)?.[1];
      if (!idxName || !name) throw new Error('Could not index the pack');
      return {
        name,
        idx: module.FS.readFile(idxName) as Uint8Array,
        pack: module.FS.readFile(`pack-${name}.pack`) as Uint8Array,
      };
    } finally {
      try {
        module.FS.chdir(originalCwd);
      } finally {
        rmRf(module, dir);
      }
    }
  });
}
