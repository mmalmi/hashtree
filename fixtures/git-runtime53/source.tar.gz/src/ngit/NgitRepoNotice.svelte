<script lang="ts">
  /** Where the current ngit repo's files come from, and whether loading them worked. */
  import { routeStore } from '../stores/route';
  import { NGIT_HISTORY_DEPTH } from './config';
  import { ngitRepoStore, retryNgitRepo } from './state';

  let route = $derived($routeStore);
  let repo = $derived(
    $ngitRepoStore && $ngitRepoStore.key === `${route.npub}/${route.treeName}` ? $ngitRepoStore : null
  );
</script>

{#if repo}
  <div
    class="flex flex-wrap items-center gap-x-2 gap-y-1 px-4 py-2 text-sm text-text-3 bg-surface-1 b-b-1 b-b-solid b-b-surface-3"
    data-testid="ngit-repo-notice"
    data-status={repo.status}
  >
    {#if repo.status === 'loading'}
      <span class="i-lucide-loader-2 animate-spin shrink-0" aria-hidden="true"></span>
      <span>Loading from {repo.sourceHost}…</span>
      {#if repo.webUrl}
        <span aria-hidden="true">·</span>
        <a href={repo.webUrl} target="_blank" rel="noopener noreferrer" class="text-accent hover:underline" data-testid="ngit-repo-web-link">Web page</a>
      {/if}
    {:else if repo.status === 'error'}
      <span class="i-lucide-alert-circle shrink-0 text-danger" aria-hidden="true"></span>
      <span class="min-w-0 break-words">Could not load from {repo.sourceHost}: {repo.error}</span>
      <button type="button" class="btn-ghost h-7 px-2 text-sm" onclick={() => retryNgitRepo(repo!.key)}>Retry</button>
      {#if repo.webUrl}
        <a href={repo.webUrl} target="_blank" rel="noopener noreferrer" class="text-accent hover:underline" data-testid="ngit-repo-web-link">Open web page</a>
      {/if}
    {:else}
      <span class="i-lucide-git-fork shrink-0" aria-hidden="true"></span>
      <span>Read-only copy from {repo.sourceHost}</span>
      {#if repo.signed === false}
        <span aria-hidden="true">·</span>
        <span title="The maintainer has not signed this branch tip">Unsigned branch tip</span>
      {/if}
      {#if repo.partialHistory}
        <span aria-hidden="true">·</span>
        <span>Last {NGIT_HISTORY_DEPTH} commits</span>
      {/if}
      {#if repo.webUrl}
        <span aria-hidden="true">·</span>
        <a href={repo.webUrl} target="_blank" rel="noopener noreferrer" class="text-accent hover:underline" data-testid="ngit-repo-web-link">Web page</a>
      {/if}
    {/if}
  </div>
{/if}
