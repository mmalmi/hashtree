/**
 * Copy an ngit repo from a grasp server into an in-memory Hashtree directory
 * shaped like the repos iris-git already shows: the files of HEAD plus `.git`
 * with packs, refs and a `shallow` list. Nothing is published.
 *
 * Two fetches run at once: the latest snapshot with file contents, and recent
 * history without file contents. Older file versions load on demand.
 */
import { LinkType, type CID, type DirEntry, type HashTree } from '@hashtree/core';
import { readGitObject } from '../utils/wasmGit/logPacks';
import { parseCommit } from '../utils/wasmGit/logObjects';
import { parseGitTree } from '../utils/wasmGit/logTrees';
import { NGIT_HISTORY_DEPTH, NGIT_MAX_PACK_BYTES } from './config';
import { fetchPack, lsRefs, type GitHttpOptions } from './transport';
import type { RemoteRefs } from './protocol';
import type { SignedHead } from './repoState';

export type NgitImportMode = 'browse' | 'full' | 'shallow';
export type NgitImportStage = 'fetching' | 'indexing' | 'saving';

export interface IndexedPack {
  /** Pack checksum, as in `pack-<name>.pack`. */
  name: string;
  pack: Uint8Array;
  idx: Uint8Array;
}

export interface NgitImportOptions {
  cloneUrls: readonly string[];
  /**
   * The maintainer's signed HEAD. A lookup still running when the first server
   * answers is not waited for: that server's HEAD is loaded instead.
   */
  signedHead?: SignedHead | null | Promise<SignedHead | null>;
  tree: HashTree;
  indexPack(pack: Uint8Array): Promise<IndexedPack>;
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
  historyDepth?: number;
  maxPackBytes?: number;
  /**
   * - `browse` (default): fast shallow snapshot + blobless history for in-memory viewing.
   * - `full`: complete self-contained history with all branches and tags (for forking).
   * - `shallow`: self-contained 1-commit snapshot with all HEAD blobs (large-repo fork fallback).
   */
  mode?: NgitImportMode;
  /** Encrypt blocks with Hashtree CHK encryption (used when persisting to backend). */
  encrypted?: boolean;
  onProgress?: (stage: NgitImportStage) => void;
}

export interface NgitImport {
  rootCid: CID;
  gitDirCid: CID;
  sourceUrl: string;
  branch: string;
  headSha: string;
  /** HEAD matches the maintainer's signed repository state; null when that was not known in time. */
  signed: boolean | null;
  /** Commits whose parents were not fetched. */
  shallow: string[];
  downloadedBytes: number;
}

const encoder = new TextEncoder();
const READ_CONCURRENCY = 16;

interface Target {
  url: string;
  ref: string;
  sha: string;
  signed: boolean | null;
  remote: RemoteRefs;
}

const PENDING = Symbol('pending');

/** The value if the promise has already settled, without waiting for it. */
function settledValue<T>(promise: Promise<T>): Promise<T | typeof PENDING> {
  return Promise.race([promise, Promise.resolve(PENDING)]);
}

async function chooseTarget(options: NgitImportOptions, http: GitHttpOptions): Promise<Target> {
  const errors: string[] = [];
  let unsigned: Target | null = null;
  const includeTags = options.mode === 'full';
  const signedHead = Promise.resolve(options.signedHead ?? null).catch(() => null);
  for (const url of options.cloneUrls) {
    try {
      const remote = await lsRefs(url, http, includeTags ? { includeTags: true } : undefined);
      const signed = await settledValue(signedHead);
      const ref = remote.headTarget;
      const sha = remote.refs.get('HEAD') ?? (ref ? remote.refs.get(ref) : undefined);
      if (signed === PENDING) {
        if (sha) return { url, ref: ref ?? 'refs/heads/main', sha, signed: null, remote };
        continue;
      }
      if (signed && [...remote.refs.values()].includes(signed.sha)) {
        return { url, ref: signed.ref, sha: signed.sha, signed: true, remote };
      }
      if (sha && !unsigned) unsigned = { url, ref: ref ?? 'refs/heads/main', sha, signed: false, remote };
      if (!signed && unsigned) return unsigned;
    } catch (error) {
      if (options.signal?.aborted) throw error;
      errors.push(error instanceof Error ? error.message : String(error));
    }
  }
  if (unsigned) return unsigned;
  throw new Error(errors[0] ?? 'No git server answered');
}

function limiter(concurrency: number) {
  let active = 0;
  const queue: Array<() => void> = [];
  return async <T>(task: () => Promise<T>): Promise<T> => {
    if (active >= concurrency) await new Promise<void>((resolve) => queue.push(resolve));
    active++;
    try {
      return await task();
    } finally {
      active--;
      queue.shift()?.();
    }
  };
}

type FileMap = Map<string, Uint8Array | FileMap>;

async function putFileMap(tree: HashTree, files: FileMap, putOpts: { unencrypted?: boolean }): Promise<CID> {
  const entries: DirEntry[] = [];
  for (const [name, value] of files) {
    if (value instanceof Uint8Array) {
      const { cid, size } = await tree.putFile(value, putOpts);
      entries.push({ name, cid, size, type: LinkType.File });
    } else {
      const cid = await putFileMap(tree, value, putOpts);
      entries.push({ name, cid, size: 0, type: LinkType.Dir });
    }
  }
  return (await tree.putDirectory(entries, putOpts)).cid;
}

function buildPackedRefs(target: Target, mode: NgitImportMode): string {
  const lines = ['# pack-refs with: peeled fully-peeled sorted'];
  if (mode !== 'full') {
    lines.push(`${target.sha} ${target.ref}`);
    return `${lines.join('\n')}\n`;
  }

  const refNames = new Set<string>([target.ref]);
  for (const name of target.remote.refs.keys()) {
    if (name.startsWith('refs/heads/') || name.startsWith('refs/tags/')) refNames.add(name);
  }
  for (const name of [...refNames].sort()) {
    if (name === target.ref) {
      lines.push(`${target.sha} ${name}`);
      continue;
    }
    const adv = target.remote.advertised?.get(name) ?? target.remote.refs.get(name);
    const peeled = target.remote.refs.get(name);
    if (!adv) continue;
    lines.push(`${adv} ${name}`);
    if (peeled && peeled !== adv) lines.push(`^${peeled}`);
  }
  return `${lines.join('\n')}\n`;
}

function gitDirFiles(target: Target, packs: IndexedPack[], shallow: string[], mode: NgitImportMode): FileMap {
  const branch = target.ref;
  const packFiles: FileMap = new Map();
  for (const pack of packs) {
    packFiles.set(`pack-${pack.name}.pack`, pack.pack);
    packFiles.set(`pack-${pack.name}.idx`, pack.idx);
  }
  const remoteName = mode === 'browse' ? 'origin' : 'upstream';
  const files: FileMap = new Map<string, Uint8Array | FileMap>([
    ['HEAD', encoder.encode(`ref: ${branch}\n`)],
    ['config', encoder.encode(`[core]\n\trepositoryformatversion = 0\n\tbare = false\n[remote "${remoteName}"]\n\turl = ${target.url}\n`)],
    ['packed-refs', encoder.encode(buildPackedRefs(target, mode))],
    ['refs', new Map([['heads', new Map()], ['tags', new Map()]])],
    ['objects', new Map([['pack', packFiles]])],
  ]);
  if (shallow.length > 0) files.set('shallow', encoder.encode(`${shallow.join('\n')}\n`));
  return files;
}

/** The files of a git tree, as Hashtree directory entries. Submodules are left out. */
async function gitTreeEntries(
  tree: HashTree,
  gitDirCid: CID,
  treeSha: string,
  run: ReturnType<typeof limiter>,
  putOpts: { unencrypted?: boolean },
): Promise<DirEntry[]> {
  const object = await run(() => readGitObject(tree, gitDirCid, treeSha));
  if (!object || object.type !== 'tree') throw new Error(`Missing git tree ${treeSha}`);
  const entries = await Promise.all(parseGitTree(object.content).map(async (entry): Promise<DirEntry | null> => {
    if (entry.mode === '40000') {
      const children = await gitTreeEntries(tree, gitDirCid, entry.hash, run, putOpts);
      const { cid } = await tree.putDirectory(children, putOpts);
      return { name: entry.name, cid, size: 0, type: LinkType.Dir };
    }
    if (entry.mode === '160000') return null;
    const blob = await run(() => readGitObject(tree, gitDirCid, entry.hash));
    if (!blob || blob.type !== 'blob') throw new Error(`Missing git blob ${entry.hash}`);
    const { cid, size } = await tree.putFile(blob.content, putOpts);
    return { name: entry.name, cid, size, type: LinkType.File };
  }));
  return entries.filter((entry): entry is DirEntry => !!entry);
}

function fullFetchWants(target: Target): string[] {
  const wants = new Set<string>([target.sha]);
  const source = target.remote.advertised ?? target.remote.refs;
  for (const [name, sha] of source) {
    if (name.startsWith('refs/heads/') || name.startsWith('refs/tags/')) wants.add(sha);
  }
  return [...wants];
}

export async function importNgitRepo(options: NgitImportOptions): Promise<NgitImport> {
  const mode: NgitImportMode = options.mode ?? 'browse';
  const putOpts = options.encrypted ? {} : { unencrypted: true };
  const maxBytes = options.maxPackBytes ?? NGIT_MAX_PACK_BYTES;
  const http: GitHttpOptions = { fetchImpl: options.fetchImpl, signal: options.signal, maxBytes };

  options.onProgress?.('fetching');
  const target = await chooseTarget(options, http);

  const packs: IndexedPack[] = [];
  let shallow: string[] = [];
  let downloadedBytes = 0;

  if (mode === 'full') {
    const full = await fetchPack(target.url, { wants: fullFetchWants(target) }, http);
    downloadedBytes = full.pack.length;
    shallow = full.shallow;
    options.onProgress?.('indexing');
    packs.push(await options.indexPack(full.pack));
  } else if (mode === 'shallow') {
    const snapshot = await fetchPack(target.url, { wants: [target.sha], deepen: 1 }, http);
    downloadedBytes = snapshot.pack.length;
    shallow = snapshot.shallow;
    options.onProgress?.('indexing');
    packs.push(await options.indexPack(snapshot.pack));
  } else {
    const depth = options.historyDepth ?? NGIT_HISTORY_DEPTH;
    const [snapshot, history] = await Promise.all([
      fetchPack(target.url, { wants: [target.sha], deepen: 1 }, http),
      // History is optional: a server without `filter` still shows the snapshot.
      depth > 1
        ? fetchPack(target.url, { wants: [target.sha], deepen: depth, filter: 'blob:none' }, http).catch((error) => {
          if (options.signal?.aborted) throw error;
          return null;
        })
        : Promise.resolve(null),
    ]);
    downloadedBytes = snapshot.pack.length + (history?.pack.length ?? 0);
    shallow = history ? history.shallow : snapshot.shallow;
    options.onProgress?.('indexing');
    packs.push(await options.indexPack(snapshot.pack));
    if (history) packs.push(await options.indexPack(history.pack));
  }

  options.onProgress?.('saving');
  const { tree } = options;
  const gitDirCid = await putFileMap(tree, gitDirFiles(target, packs, shallow, mode), putOpts);
  const commit = await readGitObject(tree, gitDirCid, target.sha);
  const parsed = commit?.type === 'commit' ? parseCommit(commit.content) : null;
  if (!parsed) throw new Error('The git server did not send the requested commit');

  const workTree = await gitTreeEntries(tree, gitDirCid, parsed.tree, limiter(READ_CONCURRENCY), putOpts);
  const rootCid = (await tree.putDirectory([
    ...workTree.filter((entry) => entry.name !== '.git'),
    { name: '.git', cid: gitDirCid, size: 0, type: LinkType.Dir },
  ], putOpts)).cid;

  return {
    rootCid,
    gitDirCid,
    sourceUrl: target.url,
    branch: target.ref.replace(/^refs\/heads\//, ''),
    headSha: target.sha,
    signed: target.signed,
    shallow,
    downloadedBytes,
  };
}
