/**
 * Which NIP-34 repos iris-git opens natively, and where to.
 *
 * Grasp servers serve git at https://<host>/<npub>/<repo>.git and allow reads
 * from any web page (CORS). GitHub, Codeberg and most other forges do not, so
 * only grasp clone URLs are used.
 */
import { NGIT_ENABLED } from './config';

const NPUB_SEGMENT = /^npub1[02-9ac-hj-np-z]{58}$/;

export interface NgitRepoCandidate {
  ownerNpub: string;
  repoName: string;
  cloneUrls: readonly string[];
}

export function isGraspCloneUrl(value: string): boolean {
  let url: URL;
  try {
    url = new URL(value.trim());
  } catch {
    return false;
  }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) return false;
  const parts = url.pathname.split('/').filter(Boolean);
  return parts.length === 2 && NPUB_SEGMENT.test(parts[0]) && /^[^/]+\.git$/.test(parts[1]) && parts[1] !== '.git';
}

/** Grasp clone URLs of a repo, in announcement order, without duplicates. */
export function graspCloneUrls(cloneUrls: readonly string[]): string[] {
  const urls: string[] = [];
  for (const raw of cloneUrls) {
    const url = raw.trim();
    if (isGraspCloneUrl(url) && !urls.includes(url)) urls.push(url);
  }
  return urls;
}

/** A repo with grasp clone URLs and no Hashtree clone URL. Hashtree repos keep their own path. */
export function isNgitOnlyRepo(repo: NgitRepoCandidate): boolean {
  if (!repo.repoName || repo.repoName.includes('/')) return false;
  if (repo.cloneUrls.some((url) => url.trim().startsWith('htree://'))) return false;
  return graspCloneUrls(repo.cloneUrls).length > 0;
}

/** In-app link for an ngit repo, or null when the feature is off or the repo is not one. */
export function ngitRepoHref(repo: NgitRepoCandidate): string | null {
  if (!NGIT_ENABLED || !isNgitOnlyRepo(repo)) return null;
  return `#/${repo.ownerNpub}/${encodeURIComponent(repo.repoName)}`;
}

export function ngitCloneCommand(ownerNpub: string, repoName: string): string {
  return `git clone ${ngitRepoOriginUrl(ownerNpub, repoName)}`;
}

export function ngitRepoOriginUrl(ownerNpub: string, repoName: string): string {
  return `nostr://${ownerNpub}/${encodeURIComponent(repoName)}`;
}

export function parseNgitForkOriginLink(value: string): {
  href: string;
  label: string;
  npub: string;
  repoName: string;
} | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    return null;
  }
  if (url.protocol !== 'nostr:' || !NPUB_SEGMENT.test(url.hostname)) return null;
  let repoParts: string[];
  try {
    repoParts = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);
  } catch {
    return null;
  }
  if (repoParts.length === 0) return null;
  const npub = url.hostname;
  const repoName = repoParts.join('/');
  return {
    href: `#/${[npub, ...repoParts].map(encodeURIComponent).join('/')}`,
    label: `${npub}/${repoName}`,
    npub,
    repoName,
  };
}

export function graspHost(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}
