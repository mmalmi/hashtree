/**
 * Native browsing of ngit repositories (NIP-34 repos served by grasp git servers).
 *
 * Set NGIT_ENABLED to false to turn it off: repo cards then link to the repo's
 * web page again and no grasp server or repo relay is contacted.
 *
 * To remove the feature: delete src/ngit/, then the lines that import from it
 * (search for "ngit/"). The hooks they use are generic and can stay:
 * lib/externalTrees.ts (in-memory trees, repos public outside Hashtree), the
 * event-source and publish-target hooks in lib/nostrLive.ts, and the
 * missing-object hook in utils/wasmGit/logPacks.ts.
 */
export const NGIT_ENABLED = true;

/** Commits of history fetched (without file contents) besides the latest snapshot. */
export const NGIT_HISTORY_DEPTH = 100;

/** Larger packs are not loaded; the page links to the repo's web page instead. */
export const NGIT_MAX_PACK_BYTES = 64 * 1024 * 1024;

/** Imported repos kept in memory at once. */
export const NGIT_MAX_CACHED_REPOS = 4;
