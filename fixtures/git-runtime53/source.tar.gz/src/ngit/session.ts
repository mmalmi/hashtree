/**
 * Opens ngit repos on their usual /npub/repo route.
 *
 * When the route's repo announcement has grasp clone URLs and no Hashtree
 * clone URL, the repo is fetched from a grasp server into memory and shown
 * through the same views as Hashtree repos. Its issues and pull requests are
 * also read from the relays the announcement names.
 *
 * Only the route's announcement is looked up on the viewer's own relays. Grasp
 * servers and repo relays are contacted only for repos announced that way.
 */
import { get } from 'svelte/store';
import type { Event, Filter } from 'nostr-tools';
import { treeRootRegistry } from '@hashtree/worker/tree-root';
import type { CID } from '@hashtree/core';
import { getTree } from '../store';
import { routeStore } from '../stores/route';
import { getStoredRepoAnnouncement, watchRepoAnnouncement } from '../nip34RepoAnnouncements';
import { publishToRelaysDirectly, queryRelaysDirectly } from '../nostr/directQuery';
import { markExternalRepoPublic, registerExternalBlocks, setExternalTreeRoot } from '../lib/externalTrees';
import { findSourcedEvent, registerEventSource, registerPublishTarget } from '../lib/nostrLive';
import { getGitRepoAnnouncementExternalUrl, type GitRepoAnnouncement } from '../lib/gitRepoAnnouncements';
import { gitDirCacheKey, readGitObject, setMissingGitObjectSource } from '../utils/wasmGit/logPacks';
import { parseCommit } from '../utils/wasmGit/logObjects';
import type { GitObject } from '../utils/wasmGit/logTypes';
import { graspCloneUrls, graspHost, isNgitOnlyRepo } from './links';
import { createOverlay, dropOverlay, readOverlayBlock } from './overlay';
import { importNgitRepo, type NgitImport, type NgitImportStage } from './importRepo';
import { indexPackWithWasmGit } from './indexPack';
import { readSingleObjectPack } from './packObject';
import { KIND_REPO_STATE, signedHeadFromState, type SignedHead } from './repoState';
import { fetchPack } from './transport';
import { setNgitRepoView, type NgitRepoView } from './state';


interface Session {
  view: NgitRepoView;
  announcement: GitRepoAnnouncement;
  signedHead?: Promise<SignedHead | null>;
}

interface LazyRepo {
  url: string;
  /** Objects not to fetch one by one: parents of the oldest fetched commits. */
  skip: Set<string>;
  pending: Map<string, Promise<GitObject | null>>;
}

const STATE_LOOKUP_MS = 2500;
const PUBLISH_TIMEOUT_MS = 10_000;
/** A server that has not sent the repo by then is reported as failed. */
const LOAD_TIMEOUT_MS = 90_000;
const RELAY_LISTEN_MS = 8000;
const MAX_REPO_RELAYS = 4;
const LAZY_OBJECT_MAX_BYTES = 32 * 1024 * 1024;
const LAZY_CONCURRENCY = 4;

const sessions = new Map<string, Session>();
const lazyRepos = new Map<string, LazyRepo>();
const announcementListeners = new Set<() => void>();
let currentKey: string | null = null;
let stopAnnouncementWatch: (() => void) | null = null;

function publish(session: Session): void {
  if (sessions.get(session.view.key) !== session) return;
  if (currentKey === session.view.key) setNgitRepoView(session.view);
}

/** Secure relays, or plain ones on this machine (local development and tests). */
const REPO_RELAY = /^(wss:\/\/[^\s/]+|ws:\/\/(localhost|127\.0\.0\.1)(:\d+)?)(\/[^\s]*)?$/;

function repoRelays(announcement: GitRepoAnnouncement): string[] {
  return [...new Set(announcement.relays.filter((relay) => REPO_RELAY.test(relay)))].slice(0, MAX_REPO_RELAYS);
}

function lookupSignedHead(announcement: GitRepoAnnouncement): Promise<SignedHead | null> {
  const relays = repoRelays(announcement);
  if (relays.length === 0) return Promise.resolve(null);
  return new Promise((resolve) => {
    let newest: { createdAt: number; head: SignedHead } | null = null;
    queryRelaysDirectly(
      relays,
      [{ kinds: [KIND_REPO_STATE], authors: [announcement.ownerPubkey], '#d': [announcement.repoName] }],
      (event) => {
        const head = signedHeadFromState(event, announcement.ownerPubkey, announcement.repoName);
        if (head && (!newest || event.created_at > newest.createdAt)) newest = { createdAt: event.created_at, head };
      },
      STATE_LOOKUP_MS,
      () => resolve(newest?.head ?? null),
    );
  });
}

let lazyActive = 0;
const lazyQueue: Array<() => void> = [];

async function withLazySlot<T>(task: () => Promise<T>): Promise<T> {
  if (lazyActive >= LAZY_CONCURRENCY) await new Promise<void>((resolve) => lazyQueue.push(resolve));
  lazyActive++;
  try {
    return await task();
  } finally {
    lazyActive--;
    lazyQueue.shift()?.();
  }
}

/** Old file versions (for diffs) and other objects outside the fetched packs, one request each. */
function readMissingObject(gitDirCid: CID, sha: string): Promise<GitObject | null> {
  const repo = lazyRepos.get(gitDirCacheKey(gitDirCid));
  if (!repo || repo.skip.has(sha)) return Promise.resolve(null);
  let pending = repo.pending.get(sha);
  if (!pending) {
    pending = withLazySlot(async () => {
      const { pack } = await fetchPack(repo.url, { wants: [sha], deepen: 1, filter: 'tree:0' }, { maxBytes: LAZY_OBJECT_MAX_BYTES });
      return readSingleObjectPack(pack, sha);
    }).catch(() => {
      repo.skip.add(sha);
      repo.pending.delete(sha);
      return null;
    });
    repo.pending.set(sha, pending);
  }
  return pending;
}

async function boundaryParents(tree: Parameters<typeof readGitObject>[0], gitDirCid: CID, shallow: string[]): Promise<Set<string>> {
  const parents = new Set<string>();
  for (const sha of shallow) {
    const object = await readGitObject(tree, gitDirCid, sha);
    const commit = object?.type === 'commit' ? parseCommit(object.content) : null;
    for (const parent of commit?.parents ?? []) parents.add(parent);
  }
  return parents;
}

function evict(key: string): void {
  const session = sessions.get(key);
  if (!session) return;
  sessions.delete(key);
  setExternalTreeRoot(session.view.npub, session.view.repoName, null);
  if (currentKey === key) setNgitRepoView(null);
}

async function load(session: Session): Promise<void> {
  const { view, announcement } = session;
  const cloneUrls = graspCloneUrls(announcement.cloneUrls);
  try {
    const overlay = createOverlay(view.key, evict);
    const signedHead = session.signedHead ?? (session.signedHead = lookupSignedHead(announcement));
    const result = await importNgitRepo({
      cloneUrls,
      signedHead,
      tree: overlay.tree,
      indexPack: indexPackWithWasmGit,
      signal: AbortSignal.timeout(LOAD_TIMEOUT_MS),
    });
    if (sessions.get(view.key) !== session) return;
    lazyRepos.set(gitDirCacheKey(result.gitDirCid), {
      url: result.sourceUrl,
      skip: await boundaryParents(overlay.tree, result.gitDirCid, result.shallow),
      pending: new Map(),
    });
    session.view = {
      ...view,
      status: 'ready',
      sourceHost: graspHost(result.sourceUrl),
      branch: result.branch,
      signed: result.signed ?? undefined,
      partialHistory: result.shallow.length > 0,
    };
    setExternalTreeRoot(view.npub, view.repoName, result.rootCid);
    if (result.signed === null) {
      // The files did not wait for the relays; the signed state is compared when it arrives.
      void signedHead.then((head) => {
        if (sessions.get(view.key) !== session || session.view.status !== 'ready') return;
        session.view = { ...session.view, signed: !!head && head.sha === result.headSha };
        publish(session);
      });
    }
  } catch (error) {
    if (sessions.get(view.key) !== session) return;
    dropOverlay(view.key);
    const timedOut = error instanceof DOMException && error.name === 'TimeoutError';
    session.view = {
      ...view,
      status: 'error',
      error: timedOut ? 'the server did not answer in time' : error instanceof Error ? error.message : String(error),
    };
  }
  publish(session);
}

function start(npub: string, repoName: string, announcement: GitRepoAnnouncement): void {
  const key = `${npub}/${repoName}`;
  // An owner-signed public announcement: issues and comments may be published for it.
  markExternalRepoPublic(npub, repoName);
  const cloneUrls = graspCloneUrls(announcement.cloneUrls);
  const session: Session = {
    announcement,
    view: {
      key,
      npub,
      repoName,
      status: 'loading',
      sourceHost: graspHost(cloneUrls[0]),
      webUrl: getGitRepoAnnouncementExternalUrl(announcement),
    },
  };
  sessions.set(key, session);
  publish(session);
  for (const listener of [...announcementListeners]) listener();
  void load(session);
}

/** Load the current route's repo again after an error. */
export function retryNgitRepo(key: string): void {
  const session = sessions.get(key);
  if (!session || session.view.status !== 'error') return;
  sessions.delete(key);
  start(session.view.npub, session.view.repoName, session.announcement);
}

/**
 * Import the currently loaded ngit repository directly into the persistent
 * Hashtree backend (CHK-encrypted) for forking.
 */
export async function importActiveNgitRepoForFork(
  npub: string,
  repoName: string,
  options: {
    mode: 'full' | 'shallow';
    onProgress?: (stage: NgitImportStage) => void;
    signal?: AbortSignal;
  },
): Promise<{ imported: NgitImport; announcement: GitRepoAnnouncement }> {
  const session = sessions.get(`${npub}/${repoName}`);
  if (!session) throw new Error('Source repository is not loaded');
  const cloneUrls = graspCloneUrls(session.announcement.cloneUrls);
  if (cloneUrls.length === 0) throw new Error('No grasp clone URL available for this repository');

  const signal = options.signal
    ? AbortSignal.any([options.signal, AbortSignal.timeout(LOAD_TIMEOUT_MS)])
    : AbortSignal.timeout(LOAD_TIMEOUT_MS);
  const imported = await importNgitRepo({
    cloneUrls,
    signedHead: session.signedHead ?? lookupSignedHead(session.announcement),
    tree: getTree(),
    indexPack: indexPackWithWasmGit,
    mode: options.mode,
    encrypted: true,
    onProgress: options.onProgress,
    signal,
  });
  return { imported, announcement: session.announcement };
}

/** Drop any read-only external ngit session for `npub/repoName` once a Hashtree repo takes over. */
export function clearNgitSession(npub: string, repoName: string): void {
  const key = `${npub}/${repoName}`;
  dropOverlay(key);
  evict(key);
}

function onRoute(npub: string | null, treeName: string | null, isPermalink: boolean): void {
  const key = !isPermalink && npub && treeName ? `${npub}/${treeName}` : null;
  if (key === currentKey) return;
  currentKey = key;
  stopAnnouncementWatch?.();
  stopAnnouncementWatch = null;
  const session = key ? sessions.get(key) : undefined;
  setNgitRepoView(session?.view ?? null);
  if (!key || session || !npub || !treeName) return;

  const consider = (announcement: GitRepoAnnouncement) => {
    if (currentKey !== key || sessions.has(key) || !isNgitOnlyRepo(announcement)) return;
    // A Hashtree repo of the same name is shown as it is.
    if (treeRootRegistry.getByKey(key)?.hash) return;
    start(npub, treeName, announcement);
  };
  void getStoredRepoAnnouncement(npub, treeName).then((stored) => {
    if (stored) consider(stored);
  }).catch(() => {});
  stopAnnouncementWatch = watchRepoAnnouncement(npub, treeName, consider);
}

const ADDRESS = /^30617:([0-9a-f]{64}):(.+)$/;

/** Repo relays for watches of an ngit repo's issues, pull requests, statuses and comments. */
function relaysForFilters(filters: Filter[]): string[] {
  const relays = new Set<string>();
  const add = (session: Session | undefined) => {
    if (session) for (const relay of repoRelays(session.announcement)) relays.add(relay);
  };
  for (const filter of filters) {
    for (const address of (filter as Record<string, unknown>)['#a'] as string[] | undefined ?? []) {
      const match = address.match(ADDRESS);
      if (!match) continue;
      for (const session of sessions.values()) {
        if (session.announcement.ownerPubkey === match[1] && session.announcement.repoName === match[2]) add(session);
      }
    }
    const byEvent = filter.ids || (filter as Record<string, unknown>)['#e'] || (filter as Record<string, unknown>)['#E'];
    if (byEvent && currentKey) add(sessions.get(currentKey));
  }
  return [...relays];
}

function watchRepoRelays(filters: Filter[], deliver: (event: Event) => void): () => void {
  let stopQuery: (() => void) | null = null;
  const tryStart = () => {
    if (stopQuery) return;
    const relays = relaysForFilters(filters);
    if (relays.length === 0) return;
    announcementListeners.delete(tryStart);
    stopQuery = queryRelaysDirectly(relays, filters, deliver, RELAY_LISTEN_MS);
  };
  announcementListeners.add(tryStart);
  tryStart();
  return () => {
    announcementListeners.delete(tryStart);
    stopQuery?.();
  };
}

function sessionForAddress(address: string): Session | undefined {
  const match = address.match(ADDRESS);
  if (!match) return undefined;
  for (const session of sessions.values()) {
    if (session.announcement.ownerPubkey === match[1] && session.announcement.repoName === match[2]) return session;
  }
  return undefined;
}

/**
 * The repo relays an event published here belongs on: those of each ngit repo
 * it names, or, for a status or reply that names only its item, those of the
 * repo that item belongs to.
 */
function relaysForPublishedEvent(event: Event): string[] {
  const relays = new Set<string>();
  const add = (session: Session | undefined) => {
    if (session) for (const relay of repoRelays(session.announcement)) relays.add(relay);
  };
  for (const tag of event.tags) {
    if ((tag[0] === 'a' || tag[0] === 'A') && tag[1]) add(sessionForAddress(tag[1]));
  }
  if (relays.size > 0) return [...relays];
  for (const tag of event.tags) {
    if ((tag[0] !== 'e' && tag[0] !== 'E') || !tag[1]) continue;
    const target = findSourcedEvent(tag[1]);
    for (const targetTag of target?.tags ?? []) {
      if (targetTag[0] === 'a' && targetTag[1]) add(sessionForAddress(targetTag[1]));
    }
  }
  return [...relays];
}

function sendToRepoRelays(event: Event): void {
  const relays = relaysForPublishedEvent(event);
  if (relays.length === 0) return;
  void publishToRelaysDirectly(relays, event, PUBLISH_TIMEOUT_MS).then((results) => {
    const failed = results.filter((result) => !result.ok);
    if (failed.length === results.length) {
      console.warn('[ngit] No repo relay accepted the event:', failed.map((result) => `${result.relay}: ${result.message}`).join(', '));
    }
  });
}

let initialized = false;

export function initNgitSessions(): void {
  if (initialized) return;
  initialized = true;
  registerExternalBlocks(readOverlayBlock);
  setMissingGitObjectSource(readMissingObject);
  registerEventSource(watchRepoRelays);
  registerPublishTarget(sendToRepoRelays);
  routeStore.subscribe((route) => onRoute(route.npub, route.treeName, route.isPermalink));
  const route = get(routeStore);
  onRoute(route.npub, route.treeName, route.isPermalink);
}
