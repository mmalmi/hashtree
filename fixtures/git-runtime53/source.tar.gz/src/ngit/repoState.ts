/**
 * NIP-34 repository state (kind 30618): the branch tips the maintainer signed.
 */
export const KIND_REPO_STATE = 30618;

const SHA1 = /^[0-9a-f]{40}$/;

export interface RepoStateEvent {
  kind: number;
  pubkey: string;
  created_at: number;
  tags: string[][];
}

export interface SignedHead {
  /** For example `refs/heads/main`. */
  ref: string;
  sha: string;
}

/** The branch HEAD names and its commit, when the state event has both. */
export function signedHeadFromState(event: RepoStateEvent, ownerPubkey: string, repoName: string): SignedHead | null {
  if (event.kind !== KIND_REPO_STATE || event.pubkey !== ownerPubkey) return null;
  if (!event.tags.some((tag) => tag[0] === 'd' && tag[1] === repoName)) return null;
  const head = event.tags.find((tag) => tag[0] === 'HEAD')?.[1]?.match(/^ref: (refs\/heads\/\S+)$/)?.[1];
  if (!head) return null;
  const sha = event.tags.find((tag) => tag[0] === head)?.[1];
  return sha && SHA1.test(sha) ? { ref: head, sha } : null;
}
