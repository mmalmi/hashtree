import { NGIT_ENABLED } from './config';

/** Start opening ngit repos natively. Does nothing when the feature is off. */
export async function initNgit(): Promise<void> {
  if (!NGIT_ENABLED) return;
  const { initNgitSessions } = await import('./session');
  initNgitSessions();
}
