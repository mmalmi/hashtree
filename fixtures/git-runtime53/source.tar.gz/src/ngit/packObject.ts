/**
 * Read the one object of a pack fetched by its id (a lazily loaded file).
 * Such a pack has no delta, because a delta needs a base in the same pack.
 */
import { unzlibSync } from 'fflate';
import type { GitObject } from '../utils/wasmGit/logTypes';

const OBJECT_TYPES: Record<number, string> = { 1: 'commit', 2: 'tree', 3: 'blob', 4: 'tag' };
const encoder = new TextEncoder();

export async function gitObjectId(type: string, content: Uint8Array): Promise<string> {
  const header = encoder.encode(`${type} ${content.length}\0`);
  const data = new Uint8Array(header.length + content.length);
  data.set(header);
  data.set(content, header.length);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-1', data));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

export async function readSingleObjectPack(pack: Uint8Array, expectedId: string): Promise<GitObject> {
  const view = new DataView(pack.buffer, pack.byteOffset, pack.byteLength);
  if (pack.length < 34 || view.getUint32(0) !== 0x5041434b) throw new Error('Not a pack');
  const version = view.getUint32(4);
  if (version !== 2 && version !== 3) throw new Error('Unsupported pack version');
  if (view.getUint32(8) !== 1) throw new Error('Expected one object');

  let offset = 12;
  let byte = pack[offset++];
  const type = OBJECT_TYPES[(byte >> 4) & 7];
  let size = byte & 15;
  let shift = 4;
  while (byte & 0x80) {
    if (offset >= pack.length || shift > 35) throw new Error('Invalid pack object header');
    byte = pack[offset++];
    size += (byte & 0x7f) * 2 ** shift;
    shift += 7;
  }
  if (!type) throw new Error('Unexpected delta object');

  const content = unzlibSync(pack.subarray(offset, pack.length - 20));
  if (content.length !== size) throw new Error('Pack object size mismatch');
  if (await gitObjectId(type, content) !== expectedId) throw new Error('Pack object id mismatch');
  return { type, content };
}
