/**
 * Git wire protocol version 2: pkt-line framing, ls-refs and fetch.
 * https://git-scm.com/docs/protocol-v2
 */

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const SHA1 = /^[0-9a-f]{40}$/;
const MAX_PKT_LEN = 65520;

export function pktLine(text: string): Uint8Array {
  const body = encoder.encode(text);
  const length = body.length + 4;
  if (length > MAX_PKT_LEN) throw new Error('pkt-line too long');
  const line = new Uint8Array(length);
  line.set(encoder.encode(length.toString(16).padStart(4, '0')));
  line.set(body, 4);
  return line;
}

const FLUSH = encoder.encode('0000');
const DELIM = encoder.encode('0001');

function concat(parts: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function commandRequest(command: string, args: string[]): Uint8Array {
  return concat([
    pktLine(`command=${command}\n`),
    pktLine('agent=iris-git\n'),
    pktLine('object-format=sha1\n'),
    DELIM,
    ...args.map((arg) => pktLine(`${arg}\n`)),
    FLUSH,
  ]);
}

export function lsRefsRequest(options?: { includeTags?: boolean }): Uint8Array {
  const args = ['symrefs', 'peel', 'ref-prefix HEAD', 'ref-prefix refs/heads/'];
  if (options?.includeTags) args.push('ref-prefix refs/tags/');
  return commandRequest('ls-refs', args);
}

export interface FetchRequest {
  wants: string[];
  /** Fetch only this many commits of history. */
  deepen?: number;
  /** For example `blob:none`. */
  filter?: string;
}

export function fetchRequest(request: FetchRequest): Uint8Array {
  if (request.wants.length === 0) throw new Error('Nothing to fetch');
  const args = ['no-progress', 'ofs-delta'];
  for (const want of request.wants) {
    if (!SHA1.test(want)) throw new Error('Invalid object id');
    args.push(`want ${want}`);
  }
  if (request.deepen !== undefined) {
    if (!Number.isInteger(request.deepen) || request.deepen < 1) throw new Error('Invalid depth');
    args.push(`deepen ${request.deepen}`);
  }
  if (request.filter) {
    if (!/^[a-z:0-9]+$/.test(request.filter)) throw new Error('Invalid filter');
    args.push(`filter ${request.filter}`);
  }
  args.push('done');
  return commandRequest('fetch', args);
}

export type PktLine =
  | { kind: 'data'; data: Uint8Array }
  | { kind: 'flush' | 'delim' | 'end' };

export function* readPktLines(buffer: Uint8Array): Generator<PktLine> {
  let offset = 0;
  while (offset < buffer.length) {
    if (offset + 4 > buffer.length) throw new Error('Truncated git response');
    const length = parseInt(decoder.decode(buffer.subarray(offset, offset + 4)), 16);
    if (!Number.isFinite(length)) throw new Error('Invalid git response');
    if (length === 0) yield { kind: 'flush' };
    else if (length === 1) yield { kind: 'delim' };
    else if (length === 2) yield { kind: 'end' };
    else {
      if (length < 4 || offset + length > buffer.length) throw new Error('Truncated git response');
      const data = buffer.subarray(offset + 4, offset + length);
      if (data.length >= 4 && decoder.decode(data.subarray(0, 4)) === 'ERR ') {
        throw new Error(`Git server error: ${decoder.decode(data.subarray(4)).trim()}`);
      }
      yield { kind: 'data', data };
      offset += length;
      continue;
    }
    offset += 4;
  }
}

function lineText(data: Uint8Array): string {
  return decoder.decode(data).replace(/\n$/, '');
}

export interface RemoteRefs {
  /** Ref name to commit id (tags peeled). */
  refs: Map<string, string>;
  /** Raw advertised object id per ref before peeling (for `want` and `packed-refs`). */
  advertised?: Map<string, string>;
  /** Branch HEAD points to, for example `refs/heads/main`. */
  headTarget: string | null;
}

export function parseLsRefsResponse(buffer: Uint8Array): RemoteRefs {
  const refs = new Map<string, string>();
  const advertised = new Map<string, string>();
  let headTarget: string | null = null;
  for (const line of readPktLines(buffer)) {
    if (line.kind !== 'data') continue;
    const [sha, name, ...attributes] = lineText(line.data).split(' ');
    if (!sha || !name || !SHA1.test(sha)) continue;
    let target = sha;
    for (const attribute of attributes) {
      if (attribute.startsWith('peeled:') && SHA1.test(attribute.slice(7))) target = attribute.slice(7);
      if (name === 'HEAD' && attribute.startsWith('symref-target:')) headTarget = attribute.slice(14);
    }
    advertised.set(name, sha);
    refs.set(name, target);
  }
  return { refs, advertised, headTarget };
}

export interface FetchResponse {
  pack: Uint8Array;
  /** Commits whose parents were left out (`deepen`). */
  shallow: string[];
}

export function parseFetchResponse(buffer: Uint8Array): FetchResponse {
  const shallow: string[] = [];
  const pack: Uint8Array[] = [];
  let section: string | null = null;
  for (const line of readPktLines(buffer)) {
    if (line.kind !== 'data') {
      if (line.kind === 'delim') section = null;
      continue;
    }
    if (section === null) {
      section = lineText(line.data);
      continue;
    }
    if (section === 'shallow-info') {
      const [kind, sha] = lineText(line.data).split(' ');
      if (kind === 'shallow' && sha && SHA1.test(sha)) shallow.push(sha);
    } else if (section === 'packfile') {
      const band = line.data[0];
      if (band === 1) pack.push(line.data.subarray(1));
      else if (band === 3) throw new Error(`Git server error: ${decoder.decode(line.data.subarray(1)).trim()}`);
    }
  }
  const packBytes = concat(pack);
  if (packBytes.length < 32 || decoder.decode(packBytes.subarray(0, 4)) !== 'PACK') {
    throw new Error('Git server sent no pack');
  }
  return { pack: packBytes, shallow };
}
