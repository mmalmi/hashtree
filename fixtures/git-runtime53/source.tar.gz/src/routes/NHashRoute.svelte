<script lang="ts">
  import { onMount } from 'svelte';
  import FileBrowser from '../components/FileBrowser.svelte';
  import Viewer from '../components/Viewer/Viewer.svelte';
  import { nostrStore } from '../nostr';
  import { isViewingFileStore, currentHash } from '../stores';
  import { nhashDecode } from '@hashtree/core';
  import { getQueryParamsFromHash } from '../lib/router.svelte';

  interface Props {
    nhash: string;
  }

  let { nhash }: Props = $props();

  let hash = $derived($currentHash);
  let isViewingFile = $derived($isViewingFileStore);
  let isValid = $state(true);

  // Check if fullscreen mode from URL
  let isFullscreen = $derived.by(() => {
    return getQueryParamsFromHash(hash).get('fullscreen') === '1';
  });
  let showGitFileSidebar = $derived(isViewingFile && !isFullscreen);

  onMount(() => {
    nostrStore.setSelectedTree(null);

    try {
      nhashDecode(nhash); // Validate
      isValid = true;
    } catch {
      isValid = false;
    }
  });
</script>

{#if isValid}
  <!-- Desktop file sidebar for file views -->
  {#if showGitFileSidebar}
    <div class="hidden lg:flex lg:w-80 shrink-0 flex-col min-h-0 b-r-1 b-r-solid b-r-surface-3/60 bg-surface-0">
      <FileBrowser />
    </div>
  {/if}
  <div class="flex flex-1 flex-col min-w-0 min-h-0 bg-surface-1/30">
    <Viewer />
  </div>
{:else}
  <div class="p-4 text-muted">Invalid nhash format</div>
{/if}
