<script lang="ts">
  import { onMount } from 'svelte';
  import GitHome from '../components/Git/GitHome.svelte';
  import { nostrStore } from '../nostr';

  onMount(() => {
    // Clear selected tree when on home route
    nostrStore.setSelectedTree(null);
  });
</script>

<GitHome />
