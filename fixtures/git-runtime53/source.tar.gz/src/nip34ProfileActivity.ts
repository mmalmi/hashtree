import type { Event as NostrEvent } from 'nostr-tools';
import {
  KIND_ISSUE,
  KIND_PULL_REQUEST,
  KIND_TEXT_NOTE,
} from './utils/constants';
import {
  getRepoReferenceFromTags,
  getTargetEventIdFromTags,
  parseIssueEvent,
  parsePullRequestEvent,
  type GitProfileActivityItem,
  type RepoReference,
} from './nip34';
import { StatusTracker } from './nip34Live';
import { createBatcher, watchEvents } from './lib/nostrLive';
import { npubToPubkey } from './nostr';

export interface ProfileGitActivityState {
  /** Newest first. */
  items: GitProfileActivityItem[];
  /** Stored history has been delivered: an empty list now means no activity. */
  historyDone: boolean;
}

type WorkItem = Extract<GitProfileActivityItem, { type: 'pr' | 'issue' }>;
interface CommentCandidate { id: string; content: string; created_at: number; targetEventId: string; repoRef: RepoReference }
interface CommentTarget { targetType: 'issue' | 'pr'; targetTitle: string }

function parseWorkItem(event: NostrEvent): WorkItem | null {
  const repoRef = getRepoReferenceFromTags(event.tags);
  if (!repoRef) return null;

  if (event.kind === KIND_PULL_REQUEST) {
    const pr = parsePullRequestEvent(event);
    return pr && {
      ...repoRef, id: pr.id, type: 'pr', title: pr.title, status: 'open', labels: pr.labels,
      branch: pr.branch, targetBranch: pr.targetBranch, created_at: pr.created_at,
    };
  }
  if (event.kind === KIND_ISSUE) {
    const issue = parseIssueEvent(event);
    return issue && {
      ...repoRef, id: issue.id, type: 'issue', title: issue.title, status: 'open', labels: issue.labels,
      created_at: issue.created_at,
    };
  }
  return null;
}

/**
 * Watch somebody's pull requests, issues and comments. `onChange` is called as
 * each piece arrives: an item is listed as soon as it can be shown, its status
 * and a comment's subject follow when they arrive. Returns a function that ends
 * the watch.
 */
export function watchProfileGitActivity(
  npub: string,
  limit: number,
  onChange: (state: ProfileGitActivityState) => void,
): () => void {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) {
    onChange({ items: [], historyDone: true });
    return () => {};
  }

  const queryLimit = Math.max(limit * 4, 40);
  const workItems = new Map<string, WorkItem>();
  const comments = new Map<string, CommentCandidate>();
  const targets = new Map<string, CommentTarget>();
  const requestedTargets = new Set<string>();
  const stops: Array<() => void> = [];
  let pendingHistories = 2;
  let stopped = false;
  let scheduled = false;

  const emit = () => {
    if (scheduled || stopped) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (stopped) return;
      const items: GitProfileActivityItem[] = [...workItems.values()]
        .map(item => ({ ...item, status: statuses.get(item.id) }));
      for (const comment of comments.values()) {
        const target = targets.get(comment.targetEventId);
        if (!target) continue;
        items.push({
          ...comment.repoRef, id: comment.id, type: 'comment', content: comment.content,
          targetEventId: comment.targetEventId, ...target, created_at: comment.created_at,
        });
      }
      onChange({
        items: items
          .sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id))
          .slice(0, limit),
        historyDone: pendingHistories === 0,
      });
    });
  };
  const historyDone = () => {
    pendingHistories -= 1;
    emit();
  };
  const statuses = new StatusTracker(emit);

  const addTarget = (event: NostrEvent) => {
    const item = parseWorkItem(event) ?? (
      event.kind === KIND_PULL_REQUEST ? parsePullRequestEvent(event) : parseIssueEvent(event)
    );
    if (!item || targets.has(event.id)) return;
    targets.set(event.id, {
      targetType: event.kind === KIND_PULL_REQUEST ? 'pr' : 'issue',
      targetTitle: item.title,
    });
    emit();
  };

  // The subjects of comments are asked for as the comments arrive.
  const targetBatch = createBatcher<string>((ids) => {
    if (stopped) return;
    pendingHistories += 1;
    stops.push(watchEvents({ ids, kinds: [KIND_PULL_REQUEST, KIND_ISSUE] }, {
      event: addTarget,
      history: historyDone,
    }));
  });

  statuses.start();
  stops.push(
    watchEvents({ authors: [pubkey], kinds: [KIND_PULL_REQUEST, KIND_ISSUE], limit: queryLimit }, {
      event: (event) => {
        const item = parseWorkItem(event);
        if (!item || workItems.has(item.id)) return;
        workItems.set(item.id, item);
        statuses.track(item.id, item.repoOwnerPubkey);
        addTarget(event);
        emit();
      },
      history: historyDone,
    }),
    watchEvents({ authors: [pubkey], kinds: [KIND_TEXT_NOTE], limit: queryLimit * 2 }, {
      event: (event) => {
        const targetEventId = getTargetEventIdFromTags(event.tags);
        const repoRef = getRepoReferenceFromTags(event.tags);
        if (!event.id || !targetEventId || !repoRef || comments.has(event.id)) return;
        comments.set(event.id, {
          id: event.id, content: event.content || '', created_at: event.created_at || 0, targetEventId, repoRef,
        });
        if (!targets.has(targetEventId) && !requestedTargets.has(targetEventId)) {
          requestedTargets.add(targetEventId);
          targetBatch.add(targetEventId);
        }
        emit();
      },
      history: historyDone,
    }),
  );

  return () => {
    stopped = true;
    targetBatch.cancel();
    statuses.stop();
    for (const stop of stops) stop();
  };
}
