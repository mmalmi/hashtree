import { isBrowserSignerSession, requestBrowserSigner, restoreBrowserSigner } from '@iris/identity/browserSigner';
import type { NostrIdentityEventSigner } from '@iris/identity/signers';
import type { Account } from '../accounts';
/**
 * Nostr Authentication and Encryption
 */
import { finalizeEvent, generateSecretKey, getPublicKey, nip19, nip44, type Event } from 'nostr-tools';
import { nostr, getAccountProvider, createNsecSigner, createExtensionSigner } from './client';
import { nostrStore } from './store';
import {
  initHashtreeBackend,
  getWorkerAdapter,
  waitForWorkerAdapter,
} from '../lib/workerInit';
import {
  accountsStore,
  initAccountsStore,
  hasExplicitSignOut,
  createAccountFromNsec,
  createExtensionAccount,
  saveActiveAccountToStorage,
} from '../accounts';
import { stopHashtreeBackend } from '../store';
import { needsMigrations, runMigrations } from '../migrations';

// Storage keys
const STORAGE_KEY_NSEC = 'hashtree:nsec';
const STORAGE_KEY_LOGIN_TYPE = 'hashtree:loginType';
const DRIVE_ROOT_NAME = 'main';

// Private key (only set for nsec login)
let secretKey: Uint8Array | null = null;
let newAccountProfile: Event | null = null;

export function getNewAccountProfile(pubkey: string): Event | null {
  return newAccountProfile?.pubkey === pubkey ? newAccountProfile : null;
}

let bootstrapPubkey: string | null = null;
let bootstrapSecretKey: Uint8Array | null = null;
let bootstrapUsedForLogin = false;
const isTestMode = !!import.meta.env.VITE_TEST_MODE;

export interface RestoreSessionOptions {
  autoCreate?: boolean;
}

type DefaultTree = {
  name: string;
  visibility: 'public' | 'link-visible' | 'private';
};

const CLASSIC_DEFAULT_TREES: readonly DefaultTree[] = [
  { name: 'public', visibility: 'public' },
  { name: 'link', visibility: 'link-visible' },
  { name: 'private', visibility: 'private' },
];

const DRIVE_DEFAULT_TREES: readonly DefaultTree[] = [
  { name: DRIVE_ROOT_NAME, visibility: 'private' },
];

/**
 * Get the secret key for decryption (only available for nsec login)
 */
export function getSecretKey(): Uint8Array | null {
  return secretKey;
}

/**
 * Get the nsec string (only available for nsec login)
 */
export function getNsec(): string | null {
  if (!secretKey) return null;
  return nip19.nsecEncode(secretKey);
}

/**
 * Initialize or update backend with user identity.
 */
async function initOrUpdateBackendIdentity(pubkey: string, nsecHex?: string): Promise<void> {
  const adapter = getWorkerAdapter();
  if (adapter) {
    await adapter.setIdentity(pubkey, nsecHex);
  } else {
    await initHashtreeBackend({ pubkey, nsec: nsecHex });
    const readyAdapter = getWorkerAdapter();
    if (readyAdapter) {
      await readyAdapter.setIdentity(pubkey, nsecHex);
    }
  }
}

/**
 * Initialize the backend early for read-only access.
 * This avoids waiting on login flows before connecting to relays.
 */
export async function initReadonlyBackend(): Promise<void> {
  if (getWorkerAdapter()) return;
  if (secretKey) {
    const pubkey = getPublicKey(secretKey);
    const nsecHex = Array.from(secretKey).map(b => b.toString(16).padStart(2, '0')).join('');
    await initHashtreeBackend({ pubkey, nsec: nsecHex });
    return;
  }
  ensureBootstrapIdentity();
  const nsecHex = bootstrapSecretKey
    ? Array.from(bootstrapSecretKey).map(b => b.toString(16).padStart(2, '0')).join('')
    : undefined;
  if (!bootstrapPubkey) return;
  await initHashtreeBackend({ pubkey: bootstrapPubkey, nsec: nsecHex });
}

export async function initReadonlyWorker(): Promise<void> {
  return initReadonlyBackend();
}

/**
 * Wait for window.nostr to be available
 */
export async function waitForNostrExtension(timeoutMs = 2000): Promise<boolean> {
  if (window.nostr) return true;

  return new Promise((resolve) => {
    const startTime = Date.now();
    const checkInterval = setInterval(() => {
      if (window.nostr) {
        clearInterval(checkInterval);
        resolve(true);
      } else if (Date.now() - startTime > timeoutMs) {
        clearInterval(checkInterval);
        resolve(false);
      }
    }, 100);
  });
}

/**
 * Try to restore session from localStorage
 */
export async function restoreSession(options: RestoreSessionOptions = {}): Promise<boolean> {
  const { autoCreate = true } = options;
  const t0 = performance.now();
  const logT = (msg: string) => console.log(`[restoreSession] ${msg}: ${Math.round(performance.now() - t0)}ms`);

  initAccountsStore();
  logT('initAccountsStore');
  if (hasExplicitSignOut()) return false;

  // Migrate legacy single account to multi-account storage if needed
  const legacyLoginType = localStorage.getItem(STORAGE_KEY_LOGIN_TYPE);
  const legacyNsec = localStorage.getItem(STORAGE_KEY_NSEC);
  const accountsState = accountsStore.getState();

  if (accountsState.accounts.length === 0 && (legacyLoginType || legacyNsec)) {
    if (legacyLoginType === 'nsec' && legacyNsec) {
      const account = createAccountFromNsec(legacyNsec);
      if (account) {
        accountsStore.addAccount(account);
        accountsStore.setActiveAccount(account.pubkey);
        saveActiveAccountToStorage(account.pubkey);
      }
    }
  }

  const activeAccount = accountsState.accounts.find(
    a => a.pubkey === accountsState.activeAccountPubkey
  );

  if (activeAccount && (
    activeAccount.type === 'extension' || activeAccount.type === 'nip46'
    || (activeAccount.type === 'nsec' && activeAccount.nsec)
  )) {
    logT('found activeAccount');
    const restored = await loginWithSavedProfile(activeAccount, { restoring: true });
    if (restored && activeAccount.type !== 'nip46') await ensureTestDefaultFolders();
    return restored;
  }

  if (legacyLoginType === 'extension') {
    const result = await loginWithExtension();
    if (result) {
      await ensureTestDefaultFolders();
    }
    return result;
  } else if (legacyLoginType === 'nsec' && legacyNsec) {
    const result = await loginWithNsec(legacyNsec);
    if (result) {
      await ensureTestDefaultFolders();
    }
    return result;
  }

  if (!autoCreate) {
    logT('no stored session');
    return false;
  }

  logT('calling generateInitialKey');
  await generateInitialKey();
  await ensureTestDefaultFolders();
  logT('generateInitialKey done');
  return true;
}

export async function loginWithSavedProfile(account: Account, { restoring = false } = {}): Promise<boolean> {
  if (account.type === 'nip46') {
    const session = account.remoteSigner;
    if (!isBrowserSignerSession(session) || session.pubkey !== account.pubkey) return false;
    return activateExternalSigner(account, restoreBrowserSigner(session));
  }
  if (account.type === 'extension') {
    return loginWithExtension(restoring ? undefined : account.pubkey);
  }
  return account.type === 'nsec' && account.nsec ? loginWithNsec(account.nsec, !restoring) : false;
}

async function activateExternalSigner(account: Account, signer: NostrIdentityEventSigner): Promise<boolean> {
  const pk = account.pubkey;
  const previous = nostr.signer;
  nostr.signer = signer;
  try {
    await initOrUpdateBackendIdentity(pk);
  } catch (error) {
    if (nostr.signer === signer) nostr.signer = previous;
    throw error;
  }
  if (nostr.signer !== signer) return false;
  nostrStore.setPubkey(pk);
  nostrStore.setNpub(nip19.npubEncode(pk));
  nostrStore.setIsLoggedIn(true);
  secretKey = null;

  localStorage.setItem(STORAGE_KEY_LOGIN_TYPE, account.type);
  localStorage.removeItem(STORAGE_KEY_NSEC);

  accountsStore.addAccount(account);
  accountsStore.setActiveAccount(pk);
  saveActiveAccountToStorage(pk);

  // Run migrations in background (delay to allow relays to connect)
  if (needsMigrations()) {
    const npub = nip19.npubEncode(pk);
    setTimeout(() => runMigrations(npub), 5000);
  }
  return true;
}

export async function loginWithRemoteSigner(): Promise<boolean> {
  const session = await requestBrowserSigner({ name: 'Iris Git', permissions: 'sign_event,nip44_encrypt,nip44_decrypt' });
  if (!session) return false;
  return activateExternalSigner({
    ...createExtensionAccount(session.pubkey), type: 'nip46', remoteSigner: session,
  }, restoreBrowserSigner(session));
}

/**
 * Login with NIP-07 browser extension
 */
export async function loginWithExtension(expectedPubkey?: string): Promise<boolean> {
  try {
    const extensionAvailable = await waitForNostrExtension();
    if (!extensionAvailable) {
      throw new Error('No nostr extension found');
    }

    const signer = createExtensionSigner();
    const pubkey = await signer.getPublicKey();
    if (expectedPubkey && pubkey !== expectedPubkey) return false;
    return await activateExternalSigner(createExtensionAccount(pubkey), signer);
  } catch (e) {
    console.error('Extension login failed:', e);
    return false;
  }
}

/**
 * Login with nsec
 */
export async function loginWithNsec(nsec: string, save = true): Promise<boolean> {
  try {
    const decoded = nip19.decode(nsec);
    if (decoded.type !== 'nsec') {
      throw new Error('Invalid nsec');
    }

    secretKey = decoded.data as Uint8Array;
    const pk = getPublicKey(secretKey);

    const signer = createNsecSigner(nsec);
    nostr.signer = signer;

    nostrStore.setPubkey(pk);
    nostrStore.setNpub(nip19.npubEncode(pk));
    nostrStore.setIsLoggedIn(true);

    if (save) {
      localStorage.setItem(STORAGE_KEY_LOGIN_TYPE, 'nsec');
      localStorage.setItem(STORAGE_KEY_NSEC, nsec);

      const account = createAccountFromNsec(nsec);
      if (account) accountsStore.addAccount(account);
      accountsStore.setActiveAccount(pk);
      saveActiveAccountToStorage(pk);
    }

    const nsecHex = Array.from(secretKey).map(b => b.toString(16).padStart(2, '0')).join('');
    await initOrUpdateBackendIdentity(pk, nsecHex);

    // Run migrations in background (delay to allow relays to connect)
    if (needsMigrations()) {
      const npub = nip19.npubEncode(pk);
      setTimeout(() => runMigrations(npub), 5000);
    }

    return true;
  } catch (e) {
    console.error('Nsec login failed:', e);
    return false;
  }
}

/**
 * Generate new keypair
 */
async function applySecretKey(
  nextKey: Uint8Array,
  defaultTrees: readonly DefaultTree[] = CLASSIC_DEFAULT_TREES,
): Promise<{ nsec: string; npub: string }> {
  secretKey = nextKey;
  const pk = getPublicKey(nextKey);
  const nsec = nip19.nsecEncode(nextKey);

  const signer = createNsecSigner(nsec);
  nostr.signer = signer;

  const npubStr = nip19.npubEncode(pk);
  // Sign before exposing the new account. Even a queued first edit in the
  // same second must outrank this default if the relay receives it later.
  const initial = finalizeEvent({
    kind: 0, tags: [], created_at: Math.floor(Date.now() / 1000) - 1,
    content: JSON.stringify({ lud16: `${npubStr}@npub.cash` }),
  }, nextKey);
  newAccountProfile = initial;
  nostrStore.setPubkey(pk);
  nostrStore.setNpub(npubStr);
  nostrStore.setIsLoggedIn(true);

  localStorage.setItem(STORAGE_KEY_LOGIN_TYPE, 'nsec');
  localStorage.setItem(STORAGE_KEY_NSEC, nsec);

  const account = createAccountFromNsec(nsec);
  if (account) {
    accountsStore.addAccount(account);
    accountsStore.setActiveAccount(pk);
    saveActiveAccountToStorage(pk);
  }

  const nsecHex = Array.from(nextKey).map(b => b.toString(16).padStart(2, '0')).join('');
  await initOrUpdateBackendIdentity(pk, nsecHex);

  if (nostr.signer === signer) {
    void nostr.publish(initial, () => {
      if (nostr.signer !== signer) throw new Error('Profile changed before the initial setup was saved.');
    }).catch(e => console.error('Failed to publish initial profile:', e));
    await createDefaultTrees(defaultTrees);
  }

  return { nsec, npub: npubStr };
}

async function generateInitialKey(): Promise<{ nsec: string; npub: string }> {
  ensureBootstrapIdentity();
  if (bootstrapSecretKey && !bootstrapUsedForLogin) {
    const nextKey = bootstrapSecretKey;
    bootstrapUsedForLogin = true;
    return applySecretKey(nextKey);
  }
  return applySecretKey(generateSecretKey());
}

export async function generateNewKey(): Promise<{ nsec: string; npub: string }> {
  return applySecretKey(generateSecretKey());
}

export async function createDriveProfile(): Promise<{ nsec: string; npub: string }> {
  return applySecretKey(generateSecretKey(), DRIVE_DEFAULT_TREES);
}

/**
 * Create default folders for a new user
 */
async function createDefaultFolders() {
  await createDefaultTrees(CLASSIC_DEFAULT_TREES);
}

async function createDefaultTrees(defaults: readonly DefaultTree[]) {
  const signer = nostr.signer;
  try {
    const waitMs = isTestMode ? 15000 : 5000;
    let adapter = await waitForWorkerAdapter(waitMs);
    if (!adapter && isTestMode) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      adapter = await waitForWorkerAdapter(10000);
    }
    if (!adapter) {
      throw new Error('Backend not ready');
    }

    const { createTree } = await import('../actions');
    const { getLocalRootCache } = await import('../treeRootCache');
    const state = nostrStore.getState();
    if (!state.npub) return;

    for (const { name, visibility } of defaults) {
      if (nostr.signer !== signer) return;
      if (getLocalRootCache(state.npub, name)) continue;
      await createTree(name, visibility, true);
    }
  } catch (e) {
    console.error('Failed to create default folders:', e);
  }
}

async function ensureTestDefaultFolders(): Promise<void> {
  if (!isTestMode) return;

  const state = nostrStore.getState();
  if (!state.npub) return;

  const { getLocalRootCache } = await import('../treeRootCache');
  const defaults = ['public', 'link', 'private'];
  if (defaults.some(name => getLocalRootCache(state.npub!, name))) {
    return;
  }

  const { getRefResolver } = await import('../refResolver');
  const resolver = getRefResolver();

  const entries = await new Promise<{ key: string }[]>((resolve) => {
    let resolved = false;
    const unsub = resolver.list?.(state.npub!, (list) => {
      if (resolved) return;
      resolved = true;
      setTimeout(() => unsub?.(), 0);
      resolve(list);
    });

    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        unsub?.();
        resolve([]);
      }
    }, 1500);
  });

  if (entries.length > 0) return;
  await createDefaultFolders();
}

/**
 * Logout
 */
export function logout() {
  saveActiveAccountToStorage(null);
  localStorage.removeItem(STORAGE_KEY_LOGIN_TYPE);
  localStorage.removeItem(STORAGE_KEY_NSEC);

  secretKey = null;
  nostr.signer = undefined;
  accountsStore.setActiveAccount(null);
  nostrStore.setIsLoggedIn(false);
  nostrStore.setPubkey(null);
  nostrStore.setNpub(null);
  nostrStore.setSelectedTree(null);

  stopHashtreeBackend();
}

// ============================================================================
// NIP-44 Encryption/Decryption
// Works with both nsec login (direct) and extension login (via window.nostr)
// ============================================================================

/**
 * Encrypt plaintext for a recipient using NIP-44
 * Works with both nsec and extension login
 */
export async function encrypt(recipientPubkey: string, plaintext: string): Promise<string> {
  if (secretKey) {
    // Direct encryption with secret key
    const conversationKey = nip44.v2.utils.getConversationKey(secretKey, recipientPubkey);
    return nip44.v2.encrypt(plaintext, conversationKey);
  }

  // Extension encryption
  const nostr = getAccountProvider();
  if (!nostr?.nip44?.encrypt) {
    throw new Error('NIP-44 encryption not available');
  }
  return nostr.nip44.encrypt(recipientPubkey, plaintext);
}

/**
 * Decrypt ciphertext from a sender using NIP-44
 * Works with both nsec and extension login
 */
export async function decrypt(senderPubkey: string, ciphertext: string): Promise<string> {
  if (secretKey) {
    // Direct decryption with secret key
    const conversationKey = nip44.v2.utils.getConversationKey(secretKey, senderPubkey);
    return nip44.v2.decrypt(ciphertext, conversationKey);
  }

  // Extension decryption
  const nostr = getAccountProvider();
  if (!nostr?.nip44?.decrypt) {
    throw new Error('NIP-44 decryption not available');
  }
  return nostr.nip44.decrypt(senderPubkey, ciphertext);
}
function ensureBootstrapIdentity(): void {
  if (!bootstrapPubkey || !bootstrapSecretKey) {
    const tempKey = generateSecretKey();
    bootstrapSecretKey = tempKey;
    bootstrapPubkey = getPublicKey(tempKey);
  }
}
