import { defineConfig, devices } from '@playwright/test';
import os from 'os';
import { getPublicKey } from 'nostr-tools';
import { BOOTSTRAP_SECKEY_HEX, FOLLOW2_SECKEY_HEX } from './e2e/nostr-test-keys';

// Workers: use PW_WORKERS env var, or default to 100% of CPU cores.
// PW_WORKERS can be a number (4) or percentage (100%).
const workersEnv = process.env.PW_WORKERS;
const maxWorkersEnv = process.env.PW_MAX_WORKERS;
const maxWorkers = Number.isFinite(Number(maxWorkersEnv)) ? Number(maxWorkersEnv) : 32;
const cpuCount = os.cpus().length || 1;
const resolveWorkers = (): number | string => {
  if (!workersEnv) {
    return Math.min(cpuCount, maxWorkers);
  }
  if (/^\d+$/.test(workersEnv)) {
    return parseInt(workersEnv, 10);
  }
  const percentMatch = workersEnv.match(/^(\d+)%$/);
  if (percentMatch) {
    const percent = Math.max(1, Math.min(100, parseInt(percentMatch[1], 10)));
    const computed = Math.max(1, Math.floor((cpuCount * percent) / 100));
    return Math.min(computed, maxWorkers);
  }
  return workersEnv;
};
const workers = resolveWorkers();

const slowSpecs = [
  'e2e/livestream-viewer.spec.ts',
];
const integrationSpecs = [
  'e2e/anchor-links.spec.ts',
  'e2e/compression.spec.ts',
  'e2e/explorer.test.ts',
  'e2e/git-basic.spec.ts',
  'e2e/git-branch-compare.spec.ts',
  'e2e/git-commit-status.spec.ts',
  'e2e/git-commit-view.spec.ts',
  'e2e/git-file-bar.spec.ts',
  'e2e/git-perf.spec.ts',
  'e2e/git-pr-interop.spec.ts',
  'e2e/git-status-edit.spec.ts',
  'e2e/link-visible-tree.spec.ts',
  'e2e/nip34-pull-requests.spec.ts',
  'e2e/search-navigation.spec.ts',
  'e2e/viewer-actions.spec.ts',
];
const fastMode = process.env.E2E_FAST === '1';
const browserFipsOnly = process.env.PW_BROWSER_FIPS_ONLY === '1';

function hexToBytes(hex: string): Uint8Array {
  const normalized = hex.trim();
  if (normalized.length % 2 !== 0) throw new Error('Invalid hex length');
  const out = new Uint8Array(normalized.length / 2);
  for (let i = 0; i < out.length; i += 1) {
    const offset = i * 2;
    const value = Number.parseInt(normalized.slice(offset, offset + 2), 16);
    if (Number.isNaN(value)) throw new Error('Invalid hex value');
    out[i] = value;
  }
  return out;
}

const testBootstrapPubkey = process.env.VITE_TEST_BOOTSTRAP_PUBKEY ?? getPublicKey(hexToBytes(BOOTSTRAP_SECKEY_HEX));
process.env.VITE_TEST_BOOTSTRAP_PUBKEY = testBootstrapPubkey;
const testGitDiscoveryFallbackPubkey = process.env.VITE_TEST_GIT_DISCOVERY_FALLBACK_PUBKEY ?? getPublicKey(hexToBytes(FOLLOW2_SECKEY_HEX));
process.env.VITE_TEST_GIT_DISCOVERY_FALLBACK_PUBKEY = testGitDiscoveryFallbackPubkey;
const testBlossomUrl = process.env.PW_TEST_BLOSSOM_URL ?? 'http://127.0.0.1:18780';
process.env.PW_TEST_BLOSSOM_URL = testBlossomUrl;
const testBlossomAddress = new URL(testBlossomUrl);
const testBlossomRoot = `${os.tmpdir()}/iris-git-e2e-blossom-${process.pid}`;
const appPort = process.env.PW_APP_PORT ?? '5173';
const appBaseUrl = `http://localhost:${appPort}`;
const relayPort = process.env.PW_RELAY_PORT ?? '4736';
const relayBaseUrl = `ws://localhost:${relayPort}`;
process.env.VITE_TEST_RELAY = relayBaseUrl;

/**
 * Playwright E2E test configuration.
 *
 * The webServer config below automatically starts the dev server before tests.
 * No need to manually run `pnpm dev` first - just run `pnpm test:e2e`.
 */
export default defineConfig({
  testDir: './e2e',
  globalSetup: browserFipsOnly ? undefined : './e2e/global-setup.ts',
  testIgnore: fastMode ? [...slowSpecs, ...integrationSpecs] : undefined,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0, // Retry once on CI to handle flaky tests
  workers,
  reporter: 'list',
  timeout: 60000, // 60s global timeout for parallel stability
  expect: { timeout: 20000 }, // 20s for expect assertions
  use: {
    baseURL: appBaseUrl,
    trace: 'off',
    actionTimeout: 20000,
    navigationTimeout: 60000,
    launchOptions: {
      args: ['--disable-features=WebRtcHideLocalIpsWithMdns'],
    },
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: [
    ...(browserFipsOnly ? [] : [{
      command: 'bash e2e/htree-blossom.sh',
      url: `${testBlossomUrl.replace(/\/$/, '')}/health`,
      reuseExistingServer: !process.env.CI,
      timeout: 120000,
      env: {
        HTREE_ADDR: `${testBlossomAddress.hostname}:${testBlossomAddress.port || '80'}`,
        HTREE_CONFIG_DIR: testBlossomRoot,
        HTREE_DATA_DIR: `${testBlossomRoot}-data`,
      },
    }]),
    {
      command: 'node e2e/relay/index.js',
      env: { RELAY_PORT: relayPort },
      url: `http://localhost:${relayPort}`,
      reuseExistingServer: !process.env.CI,
      timeout: 5000,
    },
    {
      command: `pnpm exec vite --config vite.git.config.ts --port ${appPort} --strictPort`,
      url: appBaseUrl,
      // Avoid silently reusing a non-test Vite instance (e.g. maps dev server).
      // Fresh app server startup is slower but deterministic for E2E.
      reuseExistingServer: false,
      timeout: 120000,
      env: {
        // Test mode: local relay, no Blossom, others pool disabled
        VITE_TEST_MODE: 'true',
        VITE_TEST_RELAY: relayBaseUrl,
        VITE_TEST_BOOTSTRAP_PUBKEY: testBootstrapPubkey,
        VITE_TEST_GIT_DISCOVERY_FALLBACK_PUBKEY: testGitDiscoveryFallbackPubkey,
        CHOKIDAR_USEPOLLING: '1',
        CHOKIDAR_INTERVAL: '100',
      },
    },
  ],
});
