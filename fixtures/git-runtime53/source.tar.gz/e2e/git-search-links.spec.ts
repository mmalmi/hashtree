import { expect, test, type Page } from './fixtures';
import { configureBlossomServers, ensureLoggedIn, flushPendingPublishes, gotoGitApp, useLocalRelay, waitForRelayConnected } from './test-utils';

async function pasteInSearch(page: Page, text: string) {
  const input = page.getByPlaceholder('Search', { exact: true });
  await input.focus();
  await input.press('ControlOrMeta+a');
  await page.evaluate(value => navigator.clipboard.writeText(value), text);
  await input.press('ControlOrMeta+v');
}

test('paste opens public and link-visible repositories for a fresh reader and keeps keys out of search', async ({ page, browser }, testInfo) => {
  test.setTimeout(120000);
  // Both the signing identity and the access key belong only to this local fixture.
  await gotoGitApp(page);
  await useLocalRelay(page);
  await ensureLoggedIn(page);
  await waitForRelayConnected(page);
  await configureBlossomServers(page);
  const fixture = await page.evaluate(async () => {
    const { getTree } = await import('/src/store.ts');
    const { initializeDirectoryAsGitRepo } = await import('/src/actions/tree.ts');
    const { saveHashtree, nostrStore } = await import('/src/nostr/index.ts');
    const { getWorkerAdapter } = await import('/src/lib/workerInit.ts');
    const tree = getTree();
    const npub = nostrStore.getState().npub!;
    const repos = [];
    for (const visibility of ['public', 'link-visible'] as const) {
      const name = visibility + '-' + crypto.randomUUID();
      const message = 'Read repository ' + name;
      const file = await tree.putFile(new TextEncoder().encode('# ' + message));
      const dir = await tree.putDirectory([{ name: 'README.md', cid: file.cid, size: file.size, type: 0 }]);
      const root = await initializeDirectoryAsGitRepo(dir.cid);
      const pushed = await getWorkerAdapter()!.pushToBlossom(root.hash, root.key);
      if (pushed.failed) throw new Error('Could not upload test repository');
      const result = await saveHashtree(name, root, { visibility, labels: ['git'] });
      if (!result.success || (visibility === 'link-visible' && !result.linkKey)) throw new Error('Could not publish test repository');
      repos.push({ name, message, key: result.linkKey });
    }
    return { npub, repos };
  });
  await flushPendingPublishes(page);

  const reader = await browser.newContext({ permissions: ['clipboard-read', 'clipboard-write'] });
  try {
    const visitor = await reader.newPage();
    const key = fixture.repos[1].key!;
    const leaks = new Set<string>();
    const check = (channel: string, value: string) => { if (value.includes(key)) leaks.add(channel); };
    visitor.on('console', message => check('console', message.text()));
    visitor.on('pageerror', error => check('error', error.message));
    visitor.on('request', request => {
      check('HTTP', request.url() + (request.postData() ?? '') + JSON.stringify(request.headers()));
    });
    visitor.on('websocket', socket => socket.on('framesent', frame => check('relay', frame.payload.toString())));
    await gotoGitApp(visitor);
    await useLocalRelay(visitor);
    await configureBlossomServers(visitor);
    await waitForRelayConnected(visitor);
    const input = visitor.getByPlaceholder('Search', { exact: true });
    await visitor.evaluate(async () => {
      const { registerProvider } = await import('/src/lib/search/index.ts');
      const calls: string[] = [];
      Object.assign(window, { testSearchQueries: calls });
      registerProvider({ id: 'probe', name: 'Probe', priority: 0, isAvailable: () => true,
        search: async (query: string) => { calls.push(query); return []; } });
    });

    for (const repo of fixture.repos) {
      const address = fixture.npub + '/' + repo.name;
      const suffix = repo.key ? '?k=' + repo.key : '';
      await pasteInSearch(visitor, 'htree://' + address + suffix);
      await expect.poll(() => new URL(visitor.url()).hash === '#/' + address + suffix).toBe(true);
      await expect(input).toHaveValue('');
      await expect(visitor.getByTestId('file-list').getByText('README.md', { exact: true })).toBeVisible();
      await expect(visitor.getByRole('heading', { name: repo.message })).toBeVisible();
      await visitor.screenshot({ path: testInfo.outputPath(repo.key ? 'link-visible.png' : 'public.png') });
    }

    const previousUrl = visitor.url();
    const malformed = 'htree://invalid-owner/repo?k=' + key;
    await pasteInSearch(visitor, malformed);
    await expect(input).toHaveValue(malformed);
    await input.press('Enter');
    // Leave the malformed link in place for a full search debounce.
    await visitor.waitForTimeout(250);
    expect(visitor.url() === previousUrl).toBe(true);
    await pasteInSearch(visitor, 'files');
    await expect(visitor.getByRole('button', { name: 'Files Browse your files' })).toBeVisible();
    expect(await visitor.evaluate(() => (window as unknown as { testSearchQueries: string[] }).testSearchQueries)).toEqual(['files']);
    expect(Array.from(leaks)).toEqual([]);
  } finally {
    await reader.close();
  }
});
