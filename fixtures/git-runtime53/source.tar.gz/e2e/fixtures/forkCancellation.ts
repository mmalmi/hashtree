import type { BrowserContext } from '@playwright/test';

// Hold real source operations at their completion boundary. This exercises the
// Svelte modal and forkTree without replacing import results, storage, or publication.
declare global {
  interface Window {
    __forkCancellation: {
      phase: 'import' | 'publication';
      entered: number;
      completed: number;
      wait: () => Promise<void>;
      release: (call: number) => void;
      releaseAll: () => void;
    };
  }
}

export async function installForkCancellationBarrier(context: BrowserContext, phase: 'import' | 'publication') {
  await context.addInitScript((phase) => {
    const pending = new Map<number, () => void>();
    const fixture: Window['__forkCancellation'] = {
      phase, entered: 0, completed: 0,
      wait: () => new Promise<void>(resolve => { pending.set(++fixture.entered, resolve); }),
      release: call => { pending.get(call)?.(); pending.delete(call); },
      releaseAll: () => { for (const resolve of pending.values()) resolve(); pending.clear(); },
    };
    window.__forkCancellation = fixture;
  }, phase);

  const modules = [
    {
      file: '/src/ngit/session.ts',
      name: 'importActiveNgitRepoForFork',
      body: `const result = await original(...args);
        if (window.__forkCancellation?.phase === 'import') {
          await window.__forkCancellation.wait();
          // A completed old import can still report late progress.
          args[2]?.onProgress?.('fetching');
        }
        return result;`,
    },
    {
      file: '/src/stores/projectMeta.ts',
      name: 'ignoreGeneratedProjectMetaInGitStatus',
      body: `const result = await original(...args);
        if (window.__forkCancellation?.phase === 'publication') await window.__forkCancellation.wait();
        return result;`,
    },
    {
      file: '/src/actions/treeFork.ts',
      name: 'forkTree',
      body: `try { return await original(...args); }
        finally { window.__forkCancellation.completed++; }`,
    },
  ];
  for (const { file, name, body } of modules) {
    await context.route(`**${file}*`, route => {
      if (new URL(route.request().url()).searchParams.has('fork-cancel-original')) return route.continue();
      const original = JSON.stringify(file + '?fork-cancel-original');
      return route.fulfill({ contentType: 'application/javascript', body: `
        export * from ${original};
        import { ${name} as original } from ${original};
        export async function ${name}(...args) { ${body} }
      ` });
    });
  }
}
