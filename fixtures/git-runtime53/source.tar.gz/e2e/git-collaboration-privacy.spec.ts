import { finalizeEvent, generateSecretKey, nip19, Relay } from 'nostr-tools';
import { test, expect } from './fixtures';
import { ensureLoggedIn, flushPendingPublishes, gotoGitApp, useLocalRelay, waitForRelayConnected } from './test-utils';

test.describe('Git collaboration privacy', () => {
  test.setTimeout(120000);
  for (const visibility of ['private', 'link-visible', 'unknown'] as const) {
    test(`blocks publishing for ${visibility} repositories`, async ({ page }, testInfo) => {
      await gotoGitApp(page);
      await useLocalRelay(page);
      await ensureLoggedIn(page);
      await waitForRelayConnected(page);

      const fixture = await page.evaluate(async (visibility) => {
        const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
        const { nostr, nostrStore } = await import('/src/nostr/index.ts');
        const { buildRepoAddress } = await import('/src/nip34.ts');
        const repoName = `privacy-${visibility}-${Date.now()}`;
        const npub = nostrStore.getState().npub!;
        let linkKey: string | undefined;
        if (visibility !== 'unknown') {
          const repo = await createGitRepositoryTree(repoName, visibility);
          if (!repo.success) throw new Error('Could not create repository fixture');
          linkKey = repo.linkKey;
        }
        // Simulate historical public discussions, written directly to the local
        // test relay before the guard existed. They must now be read-only.
        const seed = async (kind: number) => {
          const event = await nostr.signEvent({ kind, created_at: 1, content: 'Existing discussion', tags: [
            ['a', buildRepoAddress(npub, repoName)], ['subject', 'Existing discussion'],
          ] });
          await nostr.publish(event);
          return event.id;
        };
        return { npub, repoName, linkKey, issueId: await seed(1621), prId: await seed(1618) };
      }, visibility);
      await flushPendingPublishes(page);
      const base = `/git.html#/${fixture.npub}/${fixture.repoName}`;
      const key = fixture.linkKey ? `&k=${fixture.linkKey}` : '';
      const reason = visibility === 'unknown'
        ? 'Publishing is unavailable until repository visibility is confirmed.'
        : 'Issues, pull requests and comments are currently available only for public repositories.';

      await page.goto(`${base}?tab=issues${key}`);
      await expect(page.getByRole('button', { name: 'New Issue', exact: true })).toBeDisabled();
      await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();
      await expect(page.getByText('Existing discussion', { exact: true })).toBeVisible();
      await page.screenshot({ path: testInfo.outputPath(`${visibility}-issues.png`) });

      await page.goto(`${base}?tab=pulls${key}`);
      await expect(page.getByRole('button', { name: 'New Pull Request', exact: true })).toBeDisabled();
      await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();

      for (const [tab, id] of [['issues', fixture.issueId], ['pulls', fixture.prId]]) {
        await page.goto(`${base}?tab=${tab}&id=${id}${key}`);
        await expect(page.getByRole('heading', { name: 'Existing discussion' })).toBeVisible();
        await expect(page.getByPlaceholder('Leave a comment (markdown supported)...')).toHaveCount(0);
        await expect(page.getByRole('button', { name: 'Close', exact: true })).toHaveCount(0);
        await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();
      }
      await page.screenshot({ path: testInfo.outputPath(`${visibility}-discussion.png`) });

      const blocked = await page.evaluate(async ({ npub, repoName, issueId }) => {
        const { nostr } = await import('/src/nostr/index.ts');
        const { createIssue, createPullRequest, addComment, updateStatus, buildRepoAddress } = await import('/src/nip34.ts');
        const { npubToPubkey } = await import('/src/nostr/index.ts');
        const publish = nostr.publish;
        const broadcasts: number[] = [];
        nostr.publish = async event => { broadcasts.push(event.kind); throw new Error('Unexpected broadcast'); };
        try {
          const outcomes = [];
          for (const operation of [
            () => createIssue(npub, repoName, 'Do not publish', 'Private content'),
            () => createPullRequest(npub, repoName, 'Do not publish', 'Private content'),
            () => addComment(issueId, npubToPubkey(npub)!, 'Private reply', buildRepoAddress(npub, repoName)),
            () => updateStatus(issueId, npubToPubkey(npub)!, 'closed'),
          ]) {
            try { await operation(); outcomes.push(false); } catch { outcomes.push(true); }
          }
          return { outcomes, broadcasts };
        } finally {
          nostr.publish = publish;
        }
      }, fixture);
      expect(blocked).toEqual({ outcomes: [true, true, true, true], broadcasts: [] });

      // Directly opening a dialog must not restore its submit action.
      await page.evaluate(async ({ npub, repoName }) => {
        const { open } = await import('/src/components/Git/NewIssueModal.svelte');
        open({ npub, repoName });
      }, fixture);
      await page.getByLabel('Title', { exact: true }).fill('Do not publish');
      await expect(page.getByRole('button', { name: 'Create Issue', exact: true })).toBeDisabled();
      await page.getByRole('button', { name: 'Cancel', exact: true }).click();
      await page.evaluate(async ({ npub, repoName }) => {
        const { open } = await import('/src/components/Git/NewPullRequestModal.svelte');
        open({ npub, repoName, branches: ['main', 'feature'] });
      }, fixture);
      await page.getByLabel('Title', { exact: true }).fill('Do not publish');
      await expect(page.getByRole('button', { name: 'Create Pull Request', exact: true })).toBeDisabled();

      if (visibility === 'link-visible') {
        expect(fixture.linkKey).toMatch(/^[0-9a-f]{66}$/);
        await page.goto(base + '?tab=issues');
        await page.reload();
        await expect.poll(() => {
          const query = new URL(page.url()).hash.split('?')[1];
          return new URLSearchParams(query).get('k');
        }).toBe(fixture.linkKey);
      }
    });
  }

  test('the repository owner can close a contributor issue and its author sees the saved status', async ({ browser, page, relayUrl }, testInfo) => {
    await gotoGitApp(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await waitForRelayConnected(page);
    const repo = await page.evaluate(async () => {
      const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
      const { buildRepoAddress } = await import('/src/nip34.ts');
      const { npub, treeName, success } = await createGitRepositoryTree(`issue-roles-${Date.now()}`, 'public');
      if (!success || !npub || !treeName) throw new Error('Could not create repository fixture');
      return { npub, treeName, address: buildRepoAddress(npub, treeName) };
    });
    await flushPendingPublishes(page);

    const contributor = generateSecretKey();
    const issue = finalizeEvent({
      kind: 1621,
      created_at: Math.floor(Date.now() / 1000),
      tags: [['a', repo.address], ['subject', 'Contributor issue']],
      content: '',
    }, contributor);
    const relay = await Relay.connect(relayUrl);
    try {
      await relay.publish(issue);
    } finally {
      relay.close();
    }

    const issueUrl = `/git.html#/${repo.npub}/${repo.treeName}?tab=issues&id=${issue.id}`;
    await page.goto(issueUrl);
    await expect(page.getByRole('heading', { name: 'Contributor issue' })).toBeVisible();
    const statusRelay = await Relay.connect(relayUrl);
    let publishedClosedStatus = false;
    const statusSubscription = statusRelay.subscribe([{
      kinds: [1632],
      authors: [nip19.decode(repo.npub).data as string],
      '#e': [issue.id],
    }], { onevent: () => { publishedClosedStatus = true; } });
    try {
      await page.getByRole('button', { name: 'Close', exact: true }).click();
      // Tree flushing does not wait for NIP-34 delivery. Reload only after the
      // relay has received this owner's status event, including on slower CI.
      await expect.poll(() => publishedClosedStatus).toBe(true);
    } finally {
      statusSubscription.close();
      statusRelay.close();
    }
    await page.reload();
    await expect(page.getByRole('button', { name: 'Reopen', exact: true })).toBeVisible();
    await page.screenshot({ path: testInfo.outputPath('issue-owner.png') });

    const contributorContext = await browser.newContext();
    try {
      const viewer = await contributorContext.newPage();
      await gotoGitApp(viewer);
      await useLocalRelay(viewer);
      const signedInAs = await viewer.evaluate(async (key) => {
        const { loginWithNsec, nostrStore } = await import('/src/nostr/index.ts');
        if (!await loginWithNsec(key)) throw new Error('Contributor login failed');
        return nostrStore.getState().pubkey;
      }, nip19.nsecEncode(contributor));
      expect(signedInAs).toBe(issue.pubkey);
      await waitForRelayConnected(viewer);
      await viewer.goto(issueUrl);
      await expect(viewer.getByRole('heading', { name: 'Contributor issue' })).toBeVisible();
      await expect(viewer.getByText('Closed', { exact: true })).toBeVisible();
      await expect(viewer.getByRole('button', { name: 'Comment', exact: true })).toBeVisible();
      await expect(viewer.getByRole('button', { name: 'Reopen', exact: true })).toHaveCount(0);
      await viewer.screenshot({ path: testInfo.outputPath('issue-contributor.png') });
    } finally {
      await contributorContext.close();
    }
  });

  test('public repositories still publish issues, comments, PRs and status changes', async ({ page }) => {
    await gotoGitApp(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await waitForRelayConnected(page);
    const repo = await page.evaluate(async () => {
      const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
      return createGitRepositoryTree(`public-collaboration-${Date.now()}`, 'public');
    });
    expect(repo.success).toBe(true);
    await flushPendingPublishes(page);
    const base = `/git.html#/${repo.npub}/${repo.treeName}`;
    await page.goto(`${base}?tab=issues`);
    await expect(page.getByRole('button', { name: 'New Issue', exact: true })).toBeEnabled();
    await page.getByRole('button', { name: 'New Issue', exact: true }).click();
    await page.getByLabel('Title', { exact: true }).fill('Public issue');
    await page.getByRole('button', { name: 'Create Issue', exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    // A created issue opens at once, before any relay has it.
    await expect(page).toHaveURL(/tab=issues&id=[0-9a-f]{64}/);
    await expect(page.getByRole('heading', { name: 'Public issue' })).toBeVisible();
    await page.getByPlaceholder('Leave a comment (markdown supported)...').fill('Public reply');
    await page.getByRole('button', { name: 'Comment', exact: true }).click();
    await expect(page.getByText('Public reply', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Close', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Reopen', exact: true })).toBeVisible();

    const pr = await page.evaluate(async ({ npub, treeName }) => {
      const { createPullRequest } = await import('/src/nip34.ts');
      return createPullRequest(npub!, treeName!, 'Public pull request', 'Public change', { branch: 'feature' });
    }, repo);
    expect(pr).toBeTruthy();
    await page.goto(`${base}?tab=pulls`);
    await expect(page.getByRole('button', { name: 'New Pull Request', exact: true })).toBeEnabled();
    await expect(page.getByText('Public pull request', { exact: true })).toBeVisible();
  });
});
