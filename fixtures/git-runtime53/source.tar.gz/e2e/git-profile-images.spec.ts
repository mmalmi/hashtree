import { finalizeEvent, generateSecretKey, nip19, Relay } from 'nostr-tools';
import { test, expect } from './fixtures';
import { ensureLoggedIn, gotoGitApp, useLocalRelay } from './test-utils.js';

test('incoming public profile events use the browser event index', async ({ page, relayUrl }) => {
  const profile = finalizeEvent({
    kind: 0, created_at: Math.floor(Date.now() / 1000), tags: [],
    content: JSON.stringify({ name: 'Cached public profile' }),
  }, generateSecretKey());
  const relay = await Relay.connect(relayUrl);
  try {
    await relay.publish(profile);
  } finally {
    relay.close();
  }

  await page.goto(`/git.html#/${nip19.npubEncode(profile.pubkey)}/profile`);
  await expect(page.getByRole('heading', { name: 'Cached public profile' })).toBeVisible();
  await expect.poll(() => page.evaluate(async (eventId) => {
    const request = indexedDB.open('hashtree-worker-nostr-index');
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    try {
      const stores = db.objectStoreNames;
      if (!stores.contains('events')) return 'missing browser event index';
      const tx = db.transaction(['events', 'state']);
      const event = tx.objectStore('events').get(eventId);
      const roots = tx.objectStore('state').get('roots');
      await new Promise<void>((resolve, reject) => {
        tx.oncomplete = () => resolve();
        tx.onabort = () => reject(tx.error);
      });
      return { eventId: event.result?.event.id, portableRoot: roots.result?.value.root ?? null };
    } finally {
      db.close();
    }
  }, profile.id)).toEqual({ eventId: profile.id, portableRoot: null });

  const cachedId = await page.evaluate(async (eventId) => {
    const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
    const result = await getWorkerAdapter()?.queryEvents?.([{ ids: [eventId] }], { cache: 'cache-only' });
    return result?.events[0]?.id;
  }, profile.id);
  expect(cachedId).toBe(profile.id);
});

test('profile images open uncropped and restore focus when dismissed', async ({ page, relayUrl }, testInfo) => {
  await gotoGitApp(page);
  await useLocalRelay(page);
  await ensureLoggedIn(page);
  await page.evaluate(async () => {
    const { nostrStore } = await import('/src/nostr/index.ts');
    location.hash = '/' + nostrStore.getState().npub;
  });

  const banner = page.getByRole('button', { name: 'Expand profile banner' });
  const picture = page.getByRole('button', { name: 'Expand profile picture' });
  await expect(page.getByTestId('profile-avatar')).toBeVisible();
  await expect(picture).toHaveCount(0);
  await expect(banner).toHaveCount(0);
  const profile = finalizeEvent({
    kind: 0, created_at: Math.floor(Date.now() / 1000), tags: [],
    content: JSON.stringify({ name: 'Image test', picture: '/iris-git-icon-192.png', banner: '/git-demo-poster.png' }),
  }, generateSecretKey());
  const relay = await Relay.connect(relayUrl);
  try {
    await relay.publish(profile);
  } finally {
    relay.close();
  }
  await page.goto(`/git.html#/${nip19.npubEncode(profile.pubkey)}`);

  const dialog = page.getByRole('dialog');
  await banner.focus();
  await page.keyboard.press('Enter');
  await expect(dialog).toHaveAccessibleName('Profile banner');
  const image = dialog.getByRole('img');
  await expect(image).toHaveAttribute('src', '/git-demo-poster.png');
  await expect.poll(() => image.evaluate(img => (img as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
  await expect(image).toHaveCSS('object-fit', 'contain');
  await page.screenshot({ path: testInfo.outputPath('profile-banner.png') });
  await page.keyboard.press('Escape');
  await expect(dialog).toHaveCount(0);
  await expect(banner).toBeFocused();

  await page.setViewportSize({ width: 390, height: 844 });
  await picture.click();
  await expect(dialog).toHaveAccessibleName('Profile picture');
  await expect(image).toHaveAttribute('src', '/iris-git-icon-192.png');
  await expect.poll(() => image.evaluate(img => (img as HTMLImageElement).naturalWidth)).toBe(192);
  const bounds = await image.boundingBox();
  expect(bounds!.width).toBeGreaterThan(80);
  expect(bounds!.width).toBeLessThanOrEqual(390);
  await page.screenshot({ path: testInfo.outputPath('profile-picture-mobile.png') });
  await dialog.getByRole('button', { name: 'Close image' }).click();
  await expect(picture).toBeFocused();

  await banner.click();
  await dialog.click({ position: { x: 15, y: 90 } });
  await expect(dialog).toHaveCount(0);
  await expect(banner).toBeFocused();
});
