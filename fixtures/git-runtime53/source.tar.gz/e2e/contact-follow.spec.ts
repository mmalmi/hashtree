import { test, expect } from './fixtures';
import { nip19 } from 'nostr-tools';
import { ensureLoggedIn, waitForAppReady, waitForRelayConnected } from './test-utils';

const existing = '11'.repeat(32);
const concurrent = '33'.repeat(32);
const contact = '22'.repeat(32);
const tags = [['p', existing, 'wss://hint.invalid', 'Saved name'], ['client', 'iris-test']];
const content = '{"keep":"contact metadata"}';

test('public follow and unfollow preserve relay contact metadata through the real worker', async ({ page }) => {
  await page.goto('/git.html#/');
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);
  await waitForRelayConnected(page);
  await page.evaluate(async ({ tags, content }) => {
    const { nostr } = await import('/src/nostr/client.ts');
    await nostr.publishEvent({ kind: 3, tags, content, created_at: Math.floor(Date.now() / 1000) - 120 });
  }, { tags, content });

  const latest = () => page.evaluate(async () => {
    const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
    const { getNostrRelayUrls } = await import('/src/nostr/client.ts');
    const { nostrStore } = await import('/src/nostr/index.ts');
    const adapter = getWorkerAdapter();
    const pubkey = nostrStore.getState().pubkey;
    if (!adapter?.queryEvents || !pubkey) throw new Error('Signed-in worker not ready');
    const result = await adapter.queryEvents([{ kinds: [3], authors: [pubkey] }], {
      cache: 'network-only', relays: getNostrRelayUrls(), deadline: Date.now() + 10_000,
    });
    const head = result.events.sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id))[0];
    return { complete: result.complete, tags: head?.tags, content: head?.content };
  });
  await expect.poll(latest).toEqual({ complete: true, tags, content });
  const concurrentTags = [...tags, ['p', concurrent, '', 'New from another device']];
  expect(await page.evaluate(async ({ contact, concurrent, concurrentTags, content }) => {
    const { nostr, nostrStore } = await import('/src/nostr/index.ts');
    const { followPubkey, getFollowsSync } = await import('/src/stores/follows.ts');
    const sign = nostr.signEvent.bind(nostr);
    nostr.signEvent = async draft => {
      if (draft.kind !== 3) return sign(draft);
      nostr.signEvent = sign;
      const remote = await sign({ kind: 3, content, tags: concurrentTags, created_at: Math.floor(Date.now() / 1000) - 60 });
      await nostr.publish(remote);
      const deadline = Date.now() + 10000;
      while (!getFollowsSync(nostrStore.getState().pubkey!)?.follows.includes(concurrent)) {
        if (Date.now() >= deadline) throw new Error('The live follow subscription did not observe the concurrent update.');
        await new Promise(resolve => setTimeout(resolve, 25));
      }
      return sign(draft);
    };
    return followPubkey(contact);
  }, { contact, concurrent, concurrentTags, content })).toBe(true);
  await expect.poll(latest).toEqual({ complete: true, tags: [...concurrentTags, ['p', contact]], content });
  const ownNpub = await page.evaluate(async () => {
    const { nostrStore } = await import('/src/nostr/index.ts');
    return nostrStore.getState().npub;
  });
  await page.evaluate(npub => { window.location.hash = `/${npub}/follows`; }, ownNpub);
  const badge = page.locator('[data-testid="social-distance-badge"][title="Following"]').first();
  await expect(badge).toBeVisible();
  await expect(badge).toHaveCSS('background-color', 'rgb(10, 132, 255)');
  const geometry = await badge.evaluate(element => {
    const check = element.getBoundingClientRect();
    if (!element.parentElement) throw new Error('Avatar wrapper missing');
    const avatar = element.parentElement.getBoundingClientRect();
    return { checkX: check.x + check.width / 2, checkY: check.y + check.height / 2,
      avatarX: avatar.x + avatar.width / 2, avatarY: avatar.y + avatar.height / 2 };
  });
  expect(geometry.checkX).toBeGreaterThan(geometry.avatarX);
  expect(geometry.checkY).toBeLessThan(geometry.avatarY);
  await page.evaluate(npub => { window.location.hash = `/${npub}/profile`; }, nip19.npubEncode(contact));
  const profileAvatar = page.locator('[data-testid="profile-avatar"]:visible');
  const profileHeader = profileAvatar.locator('..');
  const explanation = profileHeader.getByTestId('profile-follow-explanation');
  await expect(explanation).toContainText(/You follow them|Followed by/);
  await expect(explanation.getByTestId('social-distance-badge')).toHaveCount(1);
  await expect(profileAvatar).toBeVisible();
  await expect(profileAvatar.getByTestId('social-distance-badge')).toHaveCount(0);
  await expect(profileHeader.locator('h1').getByTestId('social-distance-badge')).toHaveCount(0);
  await expect(profileHeader.getByTestId('social-distance-badge')).toHaveCount(1);
  await page.screenshot({path:test.info().outputPath('profile-social-badge.png')});
  expect(await page.evaluate(async contact => {
    const { unfollowPubkey } = await import('/src/stores/follows.ts');
    return unfollowPubkey(contact);
  }, contact)).toBe(true);
  await expect.poll(latest).toEqual({ complete: true, tags: concurrentTags, content });
});

test('public profile editor previews and publishes exact JSON numbers and preserves them on unrelated edits', async ({ page }, testInfo) => {
  await page.goto('/git.html#/');
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);
  await waitForRelayConnected(page);
  const owner = await page.evaluate(async () => (await import('/src/nostr/index.ts')).nostrStore.getState().npub);
  await page.evaluate(npub => { window.location.hash = `/${npub}/edit`; }, owner);
  await expect(page.getByLabel('Lightning address', { exact: true })).toHaveValue(`${owner}@npub.cash`);
  await page.getByLabel('Lightning address', { exact: true }).fill('first@example.com');
  await page.getByRole('button', { name: 'Review changes' }).click();
  await page.getByRole('button', { name: 'Publish profile' }).click();
  await expect(page).toHaveURL(new RegExp(`${owner}/profile$`));
  const tags = [['client', 'profile-editor-test', '', 'metadata']];
  const oldInteger = '9007199254740995';
  const newInteger = '900719925474099312345678901';
  const decimal = '0.123456789012345678901234567890';
  const nested = `{"levels":[${newInteger},{"gain":${decimal},"tiny":1.234567890123456789e-401}]}`;
  const untouched = '98765.432109876543210987654321';
  const npub = await page.evaluate(async ({ tags, oldInteger, untouched }) => {
    const { nostr, nostrStore } = await import('/src/nostr/index.ts');
    await nostr.publishEvent({
      kind: 0, tags,
      content: `{"name":"Mika","color":"blue","counter":${oldInteger},"untouched":${untouched}}`,
      created_at: Math.floor(Date.now() / 1000) + 2,
    });
    return nostrStore.getState().npub;
  }, { tags, oldInteger, untouched });
  const openEditor = () => page.evaluate(npub => { window.location.hash = `/${npub}/edit`; }, npub);
  const latest = () => page.evaluate(async () => {
    const { nostr, nostrStore } = await import('/src/nostr/index.ts');
    return nostr.fetchEvent({ kinds: [0], authors: [nostrStore.getState().pubkey!] });
  });
  await openEditor();
  await expect(page.getByLabel('Username', { exact: true })).toHaveValue('Mika');
  await page.getByText('Event tags (1)', { exact: true }).click();
  await expect(page.getByText(JSON.stringify(tags[0]), { exact: true })).toBeVisible();
  await page.getByText('Custom fields (3)', { exact: true }).click();
  const keys = page.getByLabel('Field name', { exact: true });
  const values = page.getByLabel('Value', { exact: true });
  await expect(keys.nth(1)).toHaveValue('counter');
  await expect(values.nth(1)).toHaveValue(oldInteger);
  await values.nth(1).fill(newInteger);
  await page.getByRole('button', { name: 'Add field' }).click();
  await keys.last().fill('instrument');
  await page.getByRole('combobox', { name: 'Value type', exact: true }).last().selectOption('JSON');
  await values.last().fill(nested);
  await page.getByRole('button', { name: 'Add field' }).click();
  await keys.last().fill('ratio');
  await page.getByRole('combobox', { name: 'Value type', exact: true }).last().selectOption('JSON');
  await values.last().fill(decimal);
  await page.getByRole('button', { name: 'Review changes' }).click();
  const review = page.getByRole('region', { name: 'Review profile changes' });
  await expect(review.locator('del')).toHaveText(oldInteger);
  const nestedPreview = review.locator('ins').filter({ hasText: 'levels' });
  await expect(nestedPreview).toContainText(decimal);
  await expect(nestedPreview).toContainText('1.234567890123456789e-401');
  await expect(review.getByText(decimal, { exact: true })).toBeVisible();
  await expect(review.getByText(newInteger, { exact: true })).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath('public-profile-changes.png') });
  await review.getByRole('button', { name: 'Publish profile' }).click();
  await expect(page).toHaveURL(new RegExp(`${npub}/profile$`));
  await expect.poll(async () => (await latest())?.content).toContain(nested);
  await openEditor();
  await page.getByLabel('Bio', { exact: true }).fill('A small edit');
  await page.getByRole('button', { name: 'Review changes' }).click();
  await expect(review.locator('dt')).toHaveText('Bio');
  await review.getByRole('button', { name: 'Publish profile' }).click();
  await expect(page).toHaveURL(new RegExp(`${npub}/profile$`));
  await expect.poll(async () => (await latest())?.content).toContain('A small edit');
  const head = await latest();
  const { verifyEvent } = await import('nostr-tools');
  expect(head && verifyEvent(head)).toBe(true);
  expect(head!.tags).toEqual(tags);
  expect(head!.content).toContain(`"counter":${newInteger}`);
  expect(head!.content).toContain(nested);
  expect(head!.content).toContain(`"ratio":${decimal}`);
  expect(head!.content).toContain(`"untouched":${untouched}`);
  expect(JSON.parse(head!.content).color).toBe('blue');
});
