import { test, expect, type Page } from './fixtures';
import type { BrowserContext } from '@playwright/test';
import { finalizeEvent, getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
    ensureLoggedIn,
  gotoGitApp,
  setupPageErrorHandler,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';
import { FOLLOW_SECKEY, FOLLOW2_SECKEY } from './nostr-test-keys';

const DISCOVERED_REPO_AUTHOR_PUBKEY = getPublicKey(FOLLOW_SECKEY);
const DISCOVERED_REPO_AUTHOR_NPUB = nip19.npubEncode(DISCOVERED_REPO_AUTHOR_PUBKEY);
let nextEventCreatedAt = Math.floor(Date.now() / 1000);

function createdAt(): number {
  nextEventCreatedAt += 1;
  return nextEventCreatedAt;
}

function pubkeyForIndex(index: number): string {
  return index.toString(16).padStart(64, '0');
}

async function publishEvent(relayUrl: string, event: Record<string, unknown>): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const socket = new WebSocket(relayUrl);
    const timeout = setTimeout(() => {
      socket.close();
      reject(new Error('Timed out publishing event'));
    }, 5000);

    socket.on('open', () => {
      socket.send(JSON.stringify(['EVENT', event]));
    });

    socket.on('message', data => {
      try {
        const msg = JSON.parse(data.toString());
        if (Array.isArray(msg) && msg[0] === 'OK' && msg[1] === (event as { id?: string }).id) {
          clearTimeout(timeout);
          socket.close();
          resolve();
        }
      } catch {
        // Ignore non-JSON relay messages.
      }
    });

    socket.on('error', err => {
      clearTimeout(timeout);
      reject(err);
    });
  });
}

async function prepareUser(page: Page) {
  setupPageErrorHandler(page);
  await gotoGitApp(page);
  await waitForAppReady(page);
  await useLocalRelay(page);
  await ensureLoggedIn(page);
  await waitForRelayConnected(page);
}

async function publishFallbackSeedFollows(relayUrl: string, ownerPubkey: string): Promise<void> {
  const followTags = Array.from({ length: 388 }, (_, index) => ['p', pubkeyForIndex(index + 1000)]);
  followTags.push(['p', ownerPubkey]);
  const followEvent = finalizeEvent({
    kind: 3,
    content: '',
    tags: followTags,
    created_at: createdAt(),
  }, FOLLOW2_SECKEY);

  await publishEvent(relayUrl, followEvent);
}

async function publishHtreeRepoAnnouncement(relayUrl: string, repoName: string): Promise<string> {
  const cloneUrl = `htree://${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`;
  const announcement = finalizeEvent({
    kind: 30617,
    content: '',
    tags: [
      ['d', repoName],
      ['clone', cloneUrl],
      ['r', '0'.repeat(40), 'euc'],
    ],
    created_at: createdAt(),
  }, FOLLOW_SECKEY);

  await publishEvent(relayUrl, announcement);
  return `#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`;
}

async function publishExternalRepoAnnouncement(
  relayUrl: string,
  repoName: string,
  cloneUrl: string,
  webUrl?: string,
): Promise<void> {
  const tags: string[][] = [
    ['d', repoName],
    ['clone', cloneUrl],
  ];
  if (webUrl) {
    tags.push(['web', webUrl]);
  }

  const announcement = finalizeEvent({
    kind: 30617,
    content: '',
    tags,
    created_at: createdAt(),
  }, FOLLOW_SECKEY);

  await publishEvent(relayUrl, announcement);
}

async function followPubkeyDirect(page: Page, pubkey: string): Promise<boolean> {
  return page.evaluate(async (targetPubkey: string) => {
    const { followPubkey } = await import('/src/stores/index.ts');
    return followPubkey(targetPubkey);
  }, pubkey);
}

const GRASP_HOST = 'grasp.e2e.test';
const GRASP_CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'Content-Type, Git-Protocol',
  'access-control-allow-methods': 'GET, POST',
};

/** A git repo served the way a grasp server does: git upload-pack, protocol v2. */
function createGraspFixture(repoName: string) {
  const work = mkdtempSync(join(tmpdir(), 'iris-git-ngit-e2e-'));
  const repo = join(work, 'repo');
  const git = (...args: string[]) => execFileSync('git', ['-c', 'commit.gpgsign=false', '-c', 'user.name=E2E', '-c', 'user.email=e2e@example.com', ...args], { cwd: repo });
  execFileSync('git', ['init', '-q', '-b', 'main', repo]);
  git('config', 'uploadpack.allowFilter', 'true');
  git('config', 'uploadpack.allowAnySHA1InWant', 'true');
  mkdirSync(join(repo, 'src'));
  writeFileSync(join(repo, 'README.md'), '# Grasp fixture\n\nServed by an ngit grasp server.\n');
  writeFileSync(join(repo, 'src/index.ts'), 'export const answer = 42;\n');
  git('add', '-A');
  git('commit', '-qm', 'First commit');
  writeFileSync(join(repo, 'README.md'), '# Grasp fixture\n\nServed by an ngit grasp server, second edition.\n');
  git('commit', '-qam', 'Second commit');
  return {
    repo,
    cloneUrl: `https://${GRASP_HOST}/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}.git`,
    remove: () => rmSync(work, { recursive: true, force: true }),
  };
}

async function routeGraspServer(context: BrowserContext, repo: string): Promise<string[]> {
  const requests: string[] = [];
  await context.route(`https://${GRASP_HOST}/**`, async (route) => {
    const request = route.request();
    if (request.method() === 'OPTIONS') {
      await route.fulfill({ status: 204, headers: GRASP_CORS });
      return;
    }
    requests.push(request.url());
    const body = execFileSync('git', ['upload-pack', '--stateless-rpc', repo], {
      input: request.postDataBuffer() ?? Buffer.alloc(0),
      env: { ...process.env, GIT_PROTOCOL: 'version=2' },
    });
    await route.fulfill({ status: 200, headers: { ...GRASP_CORS, 'content-type': 'application/x-git-upload-pack-result' }, body });
  });
  return requests;
}

async function queryRelay(relayUrl: string, filter: Record<string, unknown>): Promise<Array<{ content: string; tags: string[][] }>> {
  return new Promise((resolve) => {
    const socket = new WebSocket(relayUrl);
    const events: Array<{ content: string; tags: string[][] }> = [];
    const done = () => {
      clearTimeout(timeout);
      socket.close();
      resolve(events);
    };
    const timeout = setTimeout(done, 5000);
    socket.on('open', () => socket.send(JSON.stringify(['REQ', 'q', filter])));
    socket.on('message', (data) => {
      const message = JSON.parse(data.toString());
      if (message[0] === 'EVENT') events.push(message[2]);
      if (message[0] === 'EOSE') done();
    });
    socket.on('error', done);
  });
}

test.describe('Git home discovery', () => {
  test('shows latest updated repositories from followed users instead of a hardcoded suggestion', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `followed-repo-${Date.now()}`;
    const expectedHref = await publishHtreeRepoAnnouncement(relayUrl, repoName);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      expect(await followPubkeyDirect(viewerPage, DISCOVERED_REPO_AUTHOR_PUBKEY)).toBe(true);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      await expect(section.getByRole('heading', { name: 'Updated Repositories' })).toBeVisible({ timeout: 30000 });
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', expectedHref);
      await expect(viewerPage.getByRole('heading', { name: 'Suggested Repository' })).not.toBeVisible();
      await expect(viewerPage.getByRole('link', { name: /^hashtree$/ })).not.toBeVisible();
    } finally {
      await viewerContext.close();
    }
  });

  test('shows fallback seed followed repositories when the user has no follows', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `seed-followed-repo-${Date.now()}`;
    const expectedHref = await publishHtreeRepoAnnouncement(relayUrl, repoName);
    await publishFallbackSeedFollows(relayUrl, DISCOVERED_REPO_AUTHOR_PUBKEY);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      await expect(section.getByRole('heading', { name: 'Updated Repositories' })).toBeVisible({ timeout: 30000 });
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', expectedHref);
    } finally {
      await viewerContext.close();
    }
  });

  test('opens forge-hosted discovered repositories externally', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `external-followed-repo-${Date.now()}`;
    const cloneUrl = `https://github.com/iris-e2e/${repoName}.git`;
    const webUrl = `https://github.com/iris-e2e/${repoName}`;
    await publishFallbackSeedFollows(relayUrl, DISCOVERED_REPO_AUTHOR_PUBKEY);
    await publishExternalRepoAnnouncement(relayUrl, repoName, cloneUrl, webUrl);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', webUrl);
      await expect(repoLink).toHaveAttribute('target', '_blank');
      await expect(repoLink.getByTitle('Opens externally')).toBeVisible();
    } finally {
      await viewerContext.close();
    }
  });
  test('opens ngit repositories in the app from their grasp server', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `ngit-followed-repo-${Date.now()}`;
    const fixture = createGraspFixture(repoName);

    await publishFallbackSeedFollows(relayUrl, DISCOVERED_REPO_AUTHOR_PUBKEY);
    await publishExternalRepoAnnouncement(relayUrl, repoName, fixture.cloneUrl, `https://gitworkshop.dev/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`);

    const viewerContext = await browser.newContext();
    const gitRequests = await routeGraspServer(viewerContext, fixture.repo);
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', `#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`);
      await expect(repoLink).not.toHaveAttribute('target', '_blank');
      await repoLink.click();

      const notice = viewerPage.getByTestId('ngit-repo-notice');
      await expect(notice).toHaveAttribute('data-status', 'ready', { timeout: 30000 });
      await expect(notice).toContainText(`Read-only copy from ${GRASP_HOST}`);
      await expect(viewerPage.getByTestId('ngit-repo-web-link')).toHaveAttribute('href', `https://gitworkshop.dev/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`);
      // Attached rather than visible: under parallel load the dev server can serve the
      // page's layout CSS late, which squeezes the column without changing its content.
      await expect(viewerPage.getByText('Served by an ngit grasp server, second edition.')).toBeAttached({ timeout: 30000 });
      await expect(viewerPage.getByRole('link', { name: 'src' }).first()).toBeAttached();
      await expect(viewerPage.getByTestId('fork-folder-btn')).toBeAttached();
      await expect(viewerPage.getByTestId('blossom-push-btn')).toHaveCount(0);
      expect(gitRequests.length).toBeGreaterThan(0);
      expect(gitRequests.every((url) => url === `${fixture.cloneUrl}/git-upload-pack`)).toBe(true);
    } finally {
      await viewerContext.close();
      fixture.remove();
    }
  });

  test('links an ngit repository to its web page when its server fails', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `ngit-down-repo-${Date.now()}`;
    const cloneUrl = `https://${GRASP_HOST}/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}.git`;
    await publishExternalRepoAnnouncement(relayUrl, repoName, cloneUrl);

    const viewerContext = await browser.newContext();
    await viewerContext.route(`https://${GRASP_HOST}/**`, (route) => route.fulfill({ status: 503, headers: GRASP_CORS, body: 'down' }));
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);
      await viewerPage.goto(`/git.html#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`);
      const notice = viewerPage.getByTestId('ngit-repo-notice');
      await expect(notice).toHaveAttribute('data-status', 'error', { timeout: 30000 });
      await expect(notice.getByTestId('ngit-repo-web-link')).toHaveAttribute('href', cloneUrl);
    } finally {
      await viewerContext.close();
    }
  });

  test('reads and posts issues and replies on an ngit repository\'s own relays', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `ngit-issues-repo-${Date.now()}`;
    // A relay namespace the app is not configured with stands in for the repo's relay.
    const repoRelay = `${relayUrl}-repo`;
    const address = `30617:${DISCOVERED_REPO_AUTHOR_PUBKEY}:${repoName}`;
    const fixture = createGraspFixture(repoName);
    await publishEvent(relayUrl, finalizeEvent({
      kind: 30617,
      content: '',
      tags: [['d', repoName], ['clone', fixture.cloneUrl], ['relays', repoRelay]],
      created_at: createdAt(),
    }, FOLLOW_SECKEY));
    const remoteIssue = finalizeEvent({
      kind: 1621,
      content: 'Reported with ngit',
      tags: [['a', address], ['p', DISCOVERED_REPO_AUTHOR_PUBKEY], ['subject', 'Issue only on the repo relay']],
      created_at: createdAt(),
    }, FOLLOW2_SECKEY);
    await publishEvent(repoRelay, remoteIssue);
    await publishEvent(repoRelay, finalizeEvent({
      kind: 1111,
      content: 'NIP-22 reply from ngit',
      tags: [['E', remoteIssue.id, ''], ['K', '1621'], ['P', remoteIssue.pubkey], ['e', remoteIssue.id, ''], ['k', '1621'], ['p', remoteIssue.pubkey]],
      created_at: createdAt(),
    }, FOLLOW_SECKEY));

    const viewerContext = await browser.newContext();
    await routeGraspServer(viewerContext, fixture.repo);
    try {
      const page = await viewerContext.newPage();
      await prepareUser(page);
      await page.goto(`/git.html#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}?tab=issues`);
      await page.getByText('Issue only on the repo relay').first().click({ timeout: 30000 });
      await expect(page.getByText('NIP-22 reply from ngit')).toBeVisible({ timeout: 30000 });

      await page.getByPlaceholder('Leave a comment (markdown supported)...').fill('Reply from iris-git');
      await page.getByRole('button', { name: 'Comment', exact: true }).click();
      await expect(page.getByText('Reply from iris-git', { exact: true })).toBeVisible();
      await expect.poll(async () => (await queryRelay(repoRelay, { kinds: [1], '#e': [remoteIssue.id] }))
        .map(event => event.content), { timeout: 20000 }).toContain('Reply from iris-git');

      await page.goto(`/git.html#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}?tab=issues`);
      await expect(page.getByRole('button', { name: 'New Issue', exact: true })).toBeEnabled({ timeout: 30000 });
      await page.getByRole('button', { name: 'New Issue', exact: true }).click();
      await page.getByLabel('Title', { exact: true }).fill('Issue from iris-git');
      await page.getByRole('button', { name: 'Create Issue', exact: true }).click();
      await expect(page.getByRole('heading', { name: 'Issue from iris-git' })).toBeVisible({ timeout: 15000 });
      await expect.poll(async () => (await queryRelay(repoRelay, { kinds: [1621], '#a': [address] }))
        .map(event => event.tags.find(tag => tag[0] === 'subject')?.[1]), { timeout: 20000 }).toContain('Issue from iris-git');
    } finally {
      await viewerContext.close();
      fixture.remove();
    }
  });
});
