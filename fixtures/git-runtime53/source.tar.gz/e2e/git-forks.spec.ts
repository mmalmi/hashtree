import { randomUUID } from 'node:crypto';
import { startLocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { waitForCurrentRepoLoaded as waitForRepoReadiness } from './test-utils/gitForkReadiness';
import { test, expect, type Page } from './fixtures';
import {
  configureExplicitGitFipsPair,
  createRepositoryInCurrentDirectory,
  ensureLoggedIn,
  flushPendingPublishes,
  gotoGitApp,
  setupPageErrorHandler,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';

type RepoAnnouncementSnapshot = {
  address: string;
  cloneUrls: string[];
  earliestUniqueCommit: string | null;
  forkedFrom: string | null;
  isPersonalFork: boolean;
} | null;

type RepoMetadataSnapshot = {
  path: string;
  content: string;
} | null;

async function prepareUser(page: Page, options: { relay: string; seed: string }) {
  await page.addInitScript(({ relay, seed }) => {
    window.__testRelayUrl = relay;
    window.__testFipsWebsocketSeedUrls = [seed];
  }, options);
  setupPageErrorHandler(page);
  await gotoGitApp(page);
  await waitForAppReady(page);
  await useLocalRelay(page, options.relay);
  await ensureLoggedIn(page);
  await waitForRelayConnected(page);
}

async function getLoggedInNpub(page: Page): Promise<string> {
  const npub = await page.evaluate(() => (
    (window as { __nostrStore?: { getState?: () => { npub?: string | null } } }).__nostrStore?.getState?.().npub ?? null
  ));

  if (!npub) {
    throw new Error('Failed to resolve logged-in npub');
  }

  return npub;
}

async function npubToPubkey(page: Page, npub: string): Promise<string> {
  const pubkey = await page.evaluate(async (value: string) => {
    const { npubToPubkey } = await import('/src/nostr/index.ts');
    return npubToPubkey(value);
  }, npub);

  if (!pubkey) {
    throw new Error(`Failed to decode npub: ${npub}`);
  }

  return pubkey;
}

async function followPubkeyDirect(page: Page, pubkey: string): Promise<boolean> {
  return page.evaluate(async (targetPubkey: string) => {
    const { followPubkey } = await import('/src/stores/index.ts');
    return followPubkey(targetPubkey);
  }, pubkey);
}

async function getGitFipsPubkey(page: Page, timeoutMs: number = 30000): Promise<string> {
  const handle = await page.waitForFunction(
    async () => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      return getGitFipsRuntime()?.getStats().localXOnlyPubkey || false;
    },
    undefined,
    { timeout: timeoutMs, polling: 250 },
  );
  return handle.jsonValue() as Promise<string>;
}

async function fetchRepoAnnouncementSnapshot(page: Page, npub: string, repoName: string): Promise<RepoAnnouncementSnapshot> {
  return page.evaluate(async ({ ownerNpub, repositoryName }) => {
    const { watchRepoAnnouncement } = await import('/src/nip34.ts');
    type Announcement = Parameters<Parameters<typeof watchRepoAnnouncement>[2]>[0];
    // The announcement is watched live: take the newest one seen after a moment.
    const announcement = await new Promise<Announcement | null>((resolve) => {
      let latest: Announcement | null = null;
      const stop = watchRepoAnnouncement(ownerNpub, repositoryName, (next) => { latest = next; });
      setTimeout(() => { stop(); resolve(latest); }, 1500);
    });
    if (!announcement) {
      return null;
    }

    return {
      address: announcement.address,
      cloneUrls: announcement.cloneUrls,
      earliestUniqueCommit: announcement.earliestUniqueCommit,
      forkedFrom: announcement.forkedFrom,
      isPersonalFork: announcement.isPersonalFork,
    };
  }, { ownerNpub: npub, repositoryName: repoName });
}

async function waitForRepoAnnouncement(
  page: Page,
  npub: string,
  repoName: string,
  predicate: (snapshot: NonNullable<RepoAnnouncementSnapshot>) => boolean,
  timeoutMs: number = 30000,
): Promise<NonNullable<RepoAnnouncementSnapshot>> {
  const startedAt = Date.now();

  while (Date.now() - startedAt < timeoutMs) {
    const announcement = await fetchRepoAnnouncementSnapshot(page, npub, repoName);
    if (announcement && predicate(announcement)) {
      return announcement;
    }
    await page.waitForTimeout(500);
  }

  throw new Error(`Timed out waiting for repo announcement for ${npub}/${repoName}`);
}

async function publishSameEucRepoAnnouncement(page: Page, repoName: string, earliestUniqueCommit: string): Promise<boolean> {
  return page.evaluate(async ({ repositoryName, euc }) => {
    const { publishRepoAnnouncement } = await import('/src/nip34.ts');
    return publishRepoAnnouncement(repositoryName, { earliestUniqueCommit: euc });
  }, { repositoryName: repoName, euc: earliestUniqueCommit });
}

async function readRepoMetadataFile(page: Page): Promise<RepoMetadataSnapshot> {
  return page.evaluate(async () => {
    const { useCurrentDirCid } = await import('/src/stores/index.ts');
    const { decodeAsText, getTree } = await import('/src/store.ts');

    const repoCid = useCurrentDirCid();
    if (!repoCid) {
      return null;
    }

    const tree = getTree();
    for (const path of ['.hashtree/project.toml', '.hashtree/meta.toml']) {
      try {
        const entry = await tree.resolvePath(repoCid, path);
        if (!entry) {
          continue;
        }

        const data = await tree.readFile(entry.cid);
        if (!data) {
          continue;
        }

        return {
          path,
          content: decodeAsText(data) ?? new TextDecoder().decode(data),
        };
      } catch {
        // Try the next candidate metadata path.
      }
    }

    return null;
  });
}

async function waitForRepoMetadataFile(
  page: Page,
  predicate: (snapshot: NonNullable<RepoMetadataSnapshot>) => boolean = () => true,
  timeoutMs: number = 30000,
): Promise<NonNullable<RepoMetadataSnapshot>> {
  const startedAt = Date.now();

  while (Date.now() - startedAt < timeoutMs) {
    const metadata = await readRepoMetadataFile(page);
    if (metadata && predicate(metadata)) {
      return metadata;
    }
    await page.waitForTimeout(500);
  }

  throw new Error(`Timed out waiting for repo metadata on ${page.url()}`);
}

async function waitForCurrentRepoLoaded(page: Page, npub: string, repoName: string, timeoutMs: number = 90000) {
  await waitForRepoReadiness(page, npub, repoName, waitForAppReady, timeoutMs);
  await expect(page.getByTestId('fork-folder-btn')).toBeVisible({ timeout: timeoutMs });
}

async function forkCurrentRepo(page: Page, forkName: string) {
  const forkButton = page.getByTestId('fork-folder-btn');
  await expect(forkButton).toBeVisible({ timeout: 30000 });
  await forkButton.click();

  const forkModal = page.locator('.fixed.inset-0').filter({ hasText: 'Fork as New Folder' });
  await expect(forkModal).toBeVisible({ timeout: 10000 });
  await forkModal.locator('input').fill(forkName);
  await forkModal.getByRole('button', { name: /^Fork$/ }).click();
  await expect(forkModal).not.toBeVisible({ timeout: 60000 });
}

test.describe('Git forks', () => {
  let seed: Awaited<ReturnType<typeof startLocalFipsWebSocketSeed>>;
  test.beforeEach(async () => { seed = await startLocalFipsWebSocketSeed(); });
  test.afterEach(async () => { await seed?.close(); });

  test('forking another user repo writes metadata and lists same-EUC repo announcements', async ({ page, browser, relayUrl }, testInfo) => {
    test.setTimeout(120_000);
    const options = { relay: relayUrl + '/' + randomUUID(), seed: seed.url };
    await prepareUser(page, options);
    const ownerNpub = await getLoggedInNpub(page);

    const sourceRepoName = `fork-source-${Date.now()}`;
    await createRepositoryInCurrentDirectory(page, sourceRepoName);
    await flushPendingPublishes(page);

    const sourceAnnouncement = await waitForRepoAnnouncement(
      page,
      ownerNpub,
      sourceRepoName,
      announcement => !announcement.isPersonalFork && !!announcement.earliestUniqueCommit,
    );
    const sourceEuc = sourceAnnouncement.earliestUniqueCommit;
    if (!sourceEuc) {
      throw new Error('Source repo announcement did not include an EUC');
    }

    const sourceRepoUrl = new URL(`/git.html#/${ownerNpub}/${sourceRepoName}`, page.url()).toString();
    await page.goto(sourceRepoUrl);
    await waitForAppReady(page);
    await waitForCurrentRepoLoaded(page, ownerNpub, sourceRepoName);

    const forkStats = page.getByTestId('repo-forks-button');
    await expect(forkStats).toContainText('Forks', { timeout: 15000 });
    await expect(forkStats).toContainText('0', { timeout: 15000 });
    await forkStats.click();
    await expect(page.getByTestId('repo-forks-empty')).toBeVisible({ timeout: 15000 });
    await forkStats.click();

    const viewerContext = await browser.newContext();
    let operationFailed = false;
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage, options);
      const viewerNpub = await getLoggedInNpub(viewerPage);
      expect(viewerNpub).not.toBe(ownerNpub);
      const ownerPubkey = await npubToPubkey(viewerPage, ownerNpub);
      const viewerPubkey = await npubToPubkey(page, viewerNpub);

      const [viewerFollowedOwner, ownerFollowedViewer] = await Promise.all([
        followPubkeyDirect(viewerPage, ownerPubkey),
        followPubkeyDirect(page, viewerPubkey),
      ]);
      expect(viewerFollowedOwner).toBe(true);
      expect(ownerFollowedViewer).toBe(true);

      const [ownerFipsPubkey, viewerFipsPubkey] = await Promise.all([
        getGitFipsPubkey(page),
        getGitFipsPubkey(viewerPage),
      ]);
      expect(ownerFipsPubkey).not.toBe(ownerPubkey);
      expect(viewerFipsPubkey).not.toBe(viewerPubkey);

      await viewerPage.goto(sourceRepoUrl);
      await waitForAppReady(viewerPage);
      // Full navigation creates a new runtime; install the explicit fixture
      // route on that runtime before checking the remote repository.
      await configureExplicitGitFipsPair(page, viewerPage);
      await waitForCurrentRepoLoaded(viewerPage, ownerNpub, sourceRepoName);

      const forkRepoName = `fork-copy-${Date.now()}`;
      await forkCurrentRepo(viewerPage, forkRepoName);
      await viewerPage.waitForURL(new RegExp(`${encodeURIComponent(forkRepoName)}(?:\\?|$)`), { timeout: 30000 });
      await waitForAppReady(viewerPage);
      await waitForCurrentRepoLoaded(viewerPage, viewerNpub, forkRepoName);
      await flushPendingPublishes(viewerPage);

      const metadata = await waitForRepoMetadataFile(
        viewerPage,
        snapshot => snapshot.path === '.hashtree/project.toml' && snapshot.content.includes(`forked_from = "htree://${ownerNpub}/${sourceRepoName}"`),
      );
      expect(metadata.path).toBe('.hashtree/project.toml');
      expect(metadata.content).toContain(`forked_from = "htree://${ownerNpub}/${sourceRepoName}"`);

      const forkAnnouncement = await waitForRepoAnnouncement(
        viewerPage,
        viewerNpub,
        forkRepoName,
        () => true,
      );
      expect(forkAnnouncement.isPersonalFork).toBe(true);
      expect(forkAnnouncement.earliestUniqueCommit).toBe(sourceEuc);
      expect(forkAnnouncement.forkedFrom).toBe(`htree://${ownerNpub}/${sourceRepoName}`);
      expect(forkAnnouncement.cloneUrls).toContain(`htree://${viewerNpub}/${forkRepoName}`);

      const sameEucRepoName = `same-euc-${Date.now()}`;
      expect(await publishSameEucRepoAnnouncement(viewerPage, sameEucRepoName, sourceEuc)).toBe(true);
      const sameEucAnnouncement = await waitForRepoAnnouncement(
        viewerPage,
        viewerNpub,
        sameEucRepoName,
        announcement => announcement.earliestUniqueCommit === sourceEuc,
      );
      expect(sameEucAnnouncement.isPersonalFork).toBe(false);

      const repoSidebar = viewerPage.getByTestId('repo-project-sidebar');
      const originLink = repoSidebar.getByRole('link', { name: /^Forked from / });
      await expect(originLink).toContainText(sourceRepoName, { timeout: 30000 });
      await expect(originLink).not.toContainText(ownerNpub);
      await expect(originLink).toHaveAttribute('title', `${ownerNpub}/${sourceRepoName}`);
      await expect(originLink).toHaveAttribute('href', `#/${ownerNpub}/${sourceRepoName}`);
      await expect(viewerPage.getByTestId('repo-releases-sidebar')).toContainText('None yet');
      await viewerPage.emulateMedia({ colorScheme: 'dark' });
      await viewerPage.getByTestId('repo-sidebar').screenshot({ path: testInfo.outputPath('fork-sidebar.png') });

      await page.goto(sourceRepoUrl);
      await waitForAppReady(page);
      await waitForCurrentRepoLoaded(page, ownerNpub, sourceRepoName);
      await expect(forkStats).toContainText('2', { timeout: 30000 });
      await forkStats.click();
      const forksPopover = page.getByTestId('repo-forks-popover');
      await expect(forksPopover).toBeVisible({ timeout: 15000 });

      const forkLink = forksPopover.getByTestId('repo-fork-link').filter({ hasText: forkRepoName }).first();
      await expect(forkLink).toBeVisible({ timeout: 30000 });
      await expect(forkLink).toContainText(viewerNpub);
      await expect(forkLink).toHaveAttribute('href', `#/${viewerNpub}/${forkRepoName}`);

      const sameEucLink = forksPopover.getByTestId('repo-fork-link').filter({ hasText: sameEucRepoName }).first();
      await expect(sameEucLink).toBeVisible({ timeout: 30000 });
      await expect(sameEucLink).toContainText(viewerNpub);
      await expect(sameEucLink).toHaveAttribute('href', `#/${viewerNpub}/${sameEucRepoName}`);
    } catch (error) {
      operationFailed = true;
      throw error;
    } finally {
      try {
        await viewerContext.close();
      } catch (error) {
        if (!operationFailed) throw error;
        console.error('Viewer context cleanup also failed:', error);
      }
    }
  });
});
