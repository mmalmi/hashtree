import { test, expect } from './fixtures';
import { gotoGitApp, waitForAppReady } from './test-utils.js';
import { README_NAME, SUBDIR_NAME, SUBFILE_NAME, uploadGitRepo } from './git-file-bar.helpers';

for (const { name, width, height } of [
  { name: 'mobile', width: 390, height: 844 },
  { name: 'desktop', width: 1440, height: 900 },
]) {
  test(`repository navigation keeps its layout on ${name}`, async ({ page }, testInfo) => {
    test.slow();
    await page.setViewportSize({ width, height });
    await gotoGitApp(page);
    const { npub, repoName } = await uploadGitRepo(page);
    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const nav = page.getByTestId('repo-tab-nav');
    const header = page.getByTestId('repo-header-row');
    const list = page.getByTestId('file-list');
    const folder = list.getByRole('link', { name: SUBDIR_NAME, exact: true });
    const file = list.getByRole('link', { name: SUBFILE_NAME, exact: true });
    await expect(folder).toBeVisible();
    const navBox = await nav.boundingBox();
    const headerBox = await header.boundingBox();
    const latestCommit = list.locator('thead').getByText('Test User');
    await expect(latestCommit).toBeVisible();
    const navElement = await nav.elementHandle();

    // Keep the requested path unresolved until the loading frame is checked.
    await page.evaluate(async (subdir) => {
      const { getTree } = await import('/src/store.ts');
      const tree = getTree();
      const resolve = tree.resolvePath.bind(tree);
      let resume!: () => void;
      const blocked = new Promise<void>(done => { resume = done; });
      document.addEventListener('test:resume-directory', () => {
        tree.resolvePath = resolve;
        resume();
      }, { once: true });
      tree.resolvePath = async (cid, path) => {
        if (Array.isArray(path) && path.at(-1) === subdir) await blocked;
        return resolve(cid, path);
      };
    }, SUBDIR_NAME);

    await folder.click();
    await expect(page).toHaveURL(new RegExp(`/${SUBDIR_NAME}\\?`));
    await expect(nav).toBeVisible({ timeout: 3000 });
    expect(await navElement.evaluate(element => element.isConnected)).toBe(true);
    expect(await nav.boundingBox()).toEqual(navBox);
    await expect(list).toHaveAttribute('aria-busy', 'true');
    await expect(latestCommit).toBeVisible();
    await expect(list.getByRole('link', { name: README_NAME, exact: true })).toHaveCount(0);
    await expect(list.getByText('Empty directory')).toHaveCount(0);
    await page.screenshot({ path: testInfo.outputPath('directory-loading.png') });
    await page.evaluate(() => document.dispatchEvent(new Event('test:resume-directory')));
    await expect(file).toBeVisible();
    await expect(list).toHaveAttribute('aria-busy', 'false');
    expect(await navElement.evaluate(element => element.isConnected)).toBe(true);

    const tabs = [
      { name: 'Pull Requests', tab: 'pulls' },
      { name: 'Issues', tab: 'issues' },
      { name: 'Releases', tab: 'releases' },
      { name: 'Code', tab: null },
    ];
    for (const { name: label, tab } of tabs) {
      await nav.getByRole('link', { name: new RegExp(`^${label}`, 'i') }).click();
      if (tab) await expect(page).toHaveURL(new RegExp(`tab=${tab}`));
      else await expect(folder).toBeVisible();
      await expect(nav.getByRole('link', { name: new RegExp(`^${label}`, 'i') })).toHaveAttribute('aria-current', 'page');
      await expect(nav.getByRole('link')).toHaveCount(tabs.length);
      expect(await nav.evaluate(element => element.scrollWidth)).toBe(navBox?.width);
      expect(await nav.boundingBox()).toEqual(navBox);
      expect(await header.boundingBox()).toMatchObject({ x: headerBox?.x, y: headerBox?.y });
      if (tab) await page.screenshot({ path: testInfo.outputPath(`repository-${tab}.png`) });
    }
    await page.screenshot({ path: testInfo.outputPath('repository-code.png') });
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(width);
  });
}
