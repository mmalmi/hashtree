import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import test from 'node:test';

for (const method of ['CONNECT', 'UPGRADE']) {
  test(`deny proxy closes a reset ${method} socket without forwarding`, () => {
    // Use a real local HTTP connection. Inject the reset after Node transfers
    // the socket to CONNECT/UPGRADE, where its HTTP parser stops owning errors.
    const child = spawnSync(process.execPath, ['--input-type=module', '-e', `
      import assert from 'node:assert/strict';
      import http from 'node:http';
      import net from 'node:net';
      import { syncBuiltinESMExports } from 'node:module';
      const original = http.createServer;
      let resetSocket;
      http.createServer = (...args) => {
        const server = original(...args);
        server.on(${JSON.stringify(method === 'CONNECT' ? 'connect' : 'upgrade')}, (_request, socket) => {
          resetSocket = socket;
          queueMicrotask(() => socket.emit('error', Object.assign(new Error('fixture reset'), {code: 'ECONNRESET'})));
        });
        return server;
      };
      syncBuiltinESMExports();
      const { createDenyProxy } = await import('./scripts/isolatedBrowser.ts');
      const boundary = await createDenyProxy();
      const address = new URL(boundary.url);
      const client = net.connect(Number(address.port), address.hostname);
      client.on('error', () => client.destroy());
      const timer = setTimeout(() => { throw new Error('reset connection did not close'); }, 2000);
      await new Promise((resolve) => {
        client.on('close', resolve);
        client.on('data', () => {});
        client.on('connect', () => client.write(${JSON.stringify(method === 'CONNECT' ? 'CONNECT blocked.invalid:443 HTTP/1.1\r\nHost: blocked.invalid:443\r\n\r\n' : 'GET http://blocked.invalid/ HTTP/1.1\r\nHost: blocked.invalid\r\nConnection: Upgrade\r\nUpgrade: websocket\r\n\r\n')}));
      });
      clearTimeout(timer);
      assert(resetSocket?.destroyed);
      assert.deepEqual(boundary.rejected, [{method: ${JSON.stringify(method)}, target: ${JSON.stringify(method === 'CONNECT' ? 'blocked.invalid:443' : 'http://blocked.invalid/')}}]);
      await boundary.close();
    `], { encoding: 'utf8', timeout: 5000 });
    assert.equal(child.status, 0, `${child.error ?? ''}\n${child.stdout}\n${child.stderr}`);
  });
}
