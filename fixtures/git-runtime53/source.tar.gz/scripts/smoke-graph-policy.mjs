import {createDenyProxy, assertWorkerNetworkBlocked} from './isolatedBrowser.ts';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { WebSocket } from 'ws';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { chromium, expect } from '@playwright/test';
import { SocialGraph } from 'nostr-social-graph';
import { createNamedGraphFixture } from 'nostr-social-graph/testing/namedGraph';
import { finalizeEvent, getPublicKey } from 'nostr-tools/pure';
import { createGraphPolicyRelay } from './graph-policy-relay.mjs';

const app = process.argv[2];
assert(['maps', 'git', 'video', 'docs', 'calendar', 'boards'].includes(app), 'Specify the built app');
const root = path.resolve(app === 'git' ? 'iris-git' : `dist-${app}`);
const bootstrap = '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';
const key = new Uint8Array(32).fill(42), owner = getPublicKey(key);
const friend = getPublicKey(new Uint8Array(32).fill(43));
const muted = getPublicKey(new Uint8Array(32).fill(44));
const lists = (created_at, follows = friend, mutes = muted) => [3, 10000].map(kind => finalizeEvent({ kind, created_at, content: '', tags: [['p', kind === 3 ? follows : mutes]] }, key));
const seedEvents = lists(100), events = lists(300), liveEvents = lists(400, muted, friend);
const seed = new SocialGraph(bootstrap); seed.addFollower(bootstrap, owner); seed.handleEvent(seedEvents, true);
// Match the minimum viable public mobile projection, using synthetic identities.
for (let i = 0; i < 10_000; i++) seed.addFollower(bootstrap, (i + 100_000).toString(16).padStart(64, '0'));
const snapshot = await createNamedGraphFixture(bootstrap, await seed.toBinary());
const publicHosts = ['relay.ditto.pub', 'relay.damus.io', 'relay.primal.net', 'relay.nostr.band', 'relay.snort.social', 'temp.iris.to', 'nos.lol', 'graph-relay.iris.to'];
let bundledGraphReads = 0;
const server = createServer(async (request, response) => {
  const pathname = new URL(request.url, 'http://localhost').pathname;
  if (pathname === '/__fixture') { response.end('<!doctype html><title>Settings fixture</title>'); return; }
  const filename = path.resolve(root, `.${pathname === '/' ? '/index.html' : pathname}`);
  if (!filename.startsWith(`${root}${path.sep}`)) { response.writeHead(403).end(); return; }
  try {
    let bytes = await readFile(filename);
    if (/^socialGraph.*\.bin$/.test(path.basename(filename))) bundledGraphReads++;
    // Only the loopback fixture trusts this disposable signer. The worker still
    // verifies the real kind-30064 signature and each immutable CHK block.
    if (filename.endsWith('.js')) bytes = Buffer.from(bytes.toString().replaceAll(
      'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0', snapshot.publisher));
    // Route worker sockets through the same isolated relay as page sockets.
    // Page WebSocket interception cannot cover these dedicated worker sockets.
    if (/^hashtree\.worker-.*\.js$/.test(path.basename(filename))) bytes = Buffer.concat([Buffer.from(`
      const FixtureWebSocket = globalThis.WebSocket;
      globalThis.WebSocket = class extends FixtureWebSocket {
        constructor(url, protocols) {
          const upstream = new URL(url, self.location.href);
          super(${JSON.stringify(publicHosts)}.includes(upstream.hostname)
            ? ${JSON.stringify(publicRelay.url('public'))} + '?upstream=' + encodeURIComponent(upstream.href) : url, protocols);
        }
      };
`), bytes]);
    const type = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.wasm': 'application/wasm' }[path.extname(filename)];
    response.writeHead(200, { 'content-type': type ?? 'application/octet-stream', 'cache-control': 'no-store' }); response.end(bytes);
  } catch { response.writeHead(404).end(); }
}).listen(0, '127.0.0.1');
await once(server, 'listening');
const origin = `http://127.0.0.1:${server.address().port}`;
const relay = await createGraphPolicyRelay(events);
const publicRelay = await createGraphPolicyRelay([], snapshot.event);
const boundary = await createDenyProxy();
const browser = await chromium.launch({ headless: true, proxy: { server: boundary.url, bypass: '127.0.0.1,localhost,[::1]' } });

async function saved(page) {
  const bytes = await page.evaluate(async () => {
    const db = await new Promise((resolve, reject) => {
      const request = indexedDB.open('hashtree-social-graph');
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    try {
      if (!db.objectStoreNames.contains('socialGraph')) return null;
      return await new Promise((resolve, reject) => {
        const request = db.transaction('socialGraph').objectStore('socialGraph').get('main');
        request.onsuccess = () => {
          if (!request.result) { resolve(null); return; }
          // Transfer one compact string: millions of protocol array entries block
          // the Node process that also serves this fixture's relay.
          const data = request.result.data; let binary = '';
          for (let offset = 0; offset < data.length; offset += 8192) {
            binary += String.fromCharCode(...data.subarray(offset, offset + 8192));
          }
          resolve(btoa(binary));
        };
        request.onerror = () => reject(request.error);
      });
    } finally { db.close(); }
  });
  return bytes ? SocialGraph.fromBinary(owner, new Uint8Array(Buffer.from(bytes, 'base64'))) : null;
}
async function assertSaved(page, expected = events, partial = false) {
  await expect.poll(async () => {
    const graph = await saved(page);
    return expected.map(event => graph?.getListRevision(owner, event.kind)?.id);
  }, { timeout: 15000 }).toEqual(expected.map(event => event.id));
  const graph = await saved(page);
  assert.deepEqual([...graph.getMutedByUser(owner)], [expected[1].tags[0][1]]);
  assert.equal(graph.getListRevision(owner, 3).complete, !partial);
  assert.equal(graph.getListRevision(owner, 10000).complete, true);
}
async function ready(page) {
  await page.waitForFunction(() => window.__getWorkerAdapter?.()?.ready, undefined, { timeout: 15000 });
}
async function retainSettings(page, relays, held) {
  await page.evaluate(async ({ relays, held }) => {
    const db = await new Promise((resolve, reject) => {
      const request = indexedDB.open('hashtree-settings', 10);
      request.onupgradeneeded = () => request.result.createObjectStore('settings', { keyPath: 'key' });
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    await new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      tx.objectStore('settings').put({ key: 'network', value: { relays, blossomServers: [], negentropyEnabled: true } });
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    });
    if (!held) { db.close(); return; }
    let waiting = true;
    const tx = db.transaction('settings', 'readwrite');
    function keepAlive() { const request = tx.objectStore('settings').get('network'); request.onsuccess = () => { if (waiting) keepAlive(); }; }
    keepAlive();
    window.__releaseSettings = () => new Promise(resolve => { waiting = false; tx.oncomplete = () => { db.close(); resolve(); }; });
  }, { relays, held });
}
async function retainGraph(page) {
  const graph = new SocialGraph(bootstrap); graph.addFollower(bootstrap, owner); graph.handleEvent(events, true); graph.markListIncomplete(owner, 3);
  await page.evaluate(async bytes => {
    const db = await new Promise((resolve, reject) => {
      const request = indexedDB.open('hashtree-social-graph', 10);
      request.onupgradeneeded = () => request.result.createObjectStore('socialGraph', { keyPath: 'id' });
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    try { await new Promise((resolve, reject) => {
      const tx = db.transaction('socialGraph', 'readwrite');
      tx.objectStore('socialGraph').put({ id: 'main', data: new Uint8Array(bytes), updatedAt: Date.now() });
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    }); } finally { db.close(); }
  }, [...await graph.toBinary()]);
}

const modes = ['delayed-custom', 'default-then-custom', 'unsupported-retained', 'empty-retained'];
if (process.argv[3]) assert(modes.includes(process.argv[3]), 'Unknown fixture mode');
try {
  for (const mode of process.argv[3] ? [process.argv[3]] : modes) {
    const recordStart = relay.records.length;
    const bundledStart = bundledGraphReads;
    const records = () => relay.records.slice(recordStart);
    const sync = () => records().filter(record => record.neg);
    const custom = relay.url(mode.includes('unsupported') ? 'unsupported' : 'custom');
    const retained = mode.endsWith('retained');
    const context = await browser.newContext({ serviceWorkers: 'allow' });
    const boundaryPage = await context.newPage(); await assertWorkerNetworkBlocked(boundaryPage, boundary); await boundaryPage.close();
    const publicStart = publicRelay.records.length;
    let httpRequests = 0;
    const sockets = [], protocolErrors = [];
    let legacyReads = 0;
    const nameReads = () => publicRelay.records.slice(publicStart)
      .flatMap(record => record.requests).filter(filters => filters.some(f => f.kinds?.includes(30064))).length;
    await context.route('https://graph-api.iris.to/**', route => { legacyReads++; return route.abort(); });
    await context.route(/^https:\/\/cdn\.iris\.to\/[0-9a-f]{64}\.bin$/, async route => {
      const data = await snapshot.readBlock(new URL(route.request().url()).pathname.slice(1, -4));
      if (!data) return route.abort();
      httpRequests++;
      return route.fulfill({contentType: 'application/octet-stream', body: Buffer.from(data),
        headers: {'access-control-allow-origin': '*'}});
    });
    // Page and dedicated-worker routes share actual local protocol I/O, behind
    // the independently enforced deny proxy and local OS network boundary.
    await context.routeWebSocket(/^wss:/, route => {
      sockets.push(route.url());
      if (!publicHosts.includes(new URL(route.url()).hostname)) { route.close(); return; }
      let closed = false; const queued = [];
      const socket = new WebSocket(publicRelay.url('public') + '?upstream=' + encodeURIComponent(route.url()));
      socket.on('open', () => { for (const data of queued) socket.send(data); queued.length = 0; });
      route.onMessage(data => {
        let frame; try { frame = JSON.parse(String(data)); } catch { return; }
        const text = JSON.stringify(frame);
        if (socket.readyState === 1) socket.send(text); else if (socket.readyState === 0) queued.push(text);
      });
      socket.on('message', data => { if (!closed) route.send(data.toString()); });
      socket.on('error', error => { protocolErrors.push(String(error)); if (!closed) route.close(); });
      socket.on('close', () => { if (!closed) { closed = true; route.close(); } });
      route.onClose(() => { closed = true; socket.close(); });
    });
    await context.addInitScript(() => {
      window.__policyMessages = [];
      const OriginalWorker = window.Worker;
      window.Worker = class extends OriginalWorker {
        postMessage(message, ...args) {
          if (message?.type === 'init' || message?.type === 'setRelays') {
            const config = message.config ?? message;
            window.__policyMessages.push({ type: message.type, relays: config.relays, graphBootstrap: config.graphBootstrap });
          }
          return super.postMessage(message, ...args);
        }
      };
    });
    const blocker = await context.newPage(); await blocker.goto(`${origin}/__fixture`);
    if (mode !== 'default-then-custom') await retainSettings(blocker, mode === 'empty-retained' ? [] : [custom], mode === 'delayed-custom');
    if (retained) await retainGraph(blocker);
    const page = await context.newPage();
    try {
      await page.goto(origin, { waitUntil: 'domcontentloaded' });
      if (mode === 'delayed-custom') {
        await page.waitForTimeout(800); // Negative assertion spans the removed 500ms fallback window.
        assert.equal(httpRequests, 0, 'No fixed HTTP while saved settings are pending');
        assert.deepEqual(sockets, [], 'No default socket while saved settings are pending');
        assert.deepEqual(await page.evaluate(() => window.__policyMessages), [], 'No worker starts before settings');
        await blocker.evaluate(() => window.__releaseSettings());
      }
      await ready(page);
      assert.equal((await page.evaluate(() => window.__policyMessages)).find(message => message.type === 'init').graphBootstrap, mode === 'default-then-custom');
      if (mode === 'default-then-custom') {
        await expect.poll(() => httpRequests, { timeout: 10000 }).toBeGreaterThan(0);
        await assertSaved(page, seedEvents);
        assert(bundledGraphReads > bundledStart, 'Fresh public startup must load the bundled graph asset');
        const defaults = (await page.evaluate(() => window.__policyMessages)).find(message => message.type === 'init').relays;
        assert.equal(defaults[0], 'wss://relay.ditto.pub', 'Ditto must enter the effective default graph selection');
        const expected = defaults.slice(0, 3).map(url => new URL(url).href).sort();
        await expect.poll(() => [...new Set(publicRelay.records.slice(publicStart).filter(record => record.neg)
          .map(record => new URL(record.path, origin).searchParams.get('upstream')))].sort(), { timeout: 10000 }).toEqual(expected);
        assert.deepEqual(publicRelay.records.slice(publicStart).flatMap(record => record.errors), []);

        await page.evaluate(custom => { for (const store of window.__settingsStoreInstances) store.setNetworkSettings({ relays: [custom] }); }, custom);
        await expect.poll(() => page.evaluate(() => window.__policyMessages.at(-1))).toMatchObject({ type: 'setRelays', relays: [custom], graphBootstrap: false });
      }
      await page.evaluate(owner => window.__getWorkerAdapter().setSocialGraphRoot(owner), owner);
      if (mode !== 'empty-retained') {
        await expect.poll(() => sync().some(record => record.filters.some(filter => filter.kinds?.includes(3) && filter.kinds?.includes(10000) && filter.authors?.includes(owner))), { timeout: 10000 }).toBe(true);
        await expect.poll(() => sync().every(record => record.closed), { timeout: 10000 }).toBe(true);
      }
      if (retained) {
        assert.equal(sync().flatMap(record => record.requests).length, 0, 'Unsupported NEG must not fall back to REQ');
        if (mode === 'empty-retained') assert.equal(sync().length, 0);
        await assertSaved(page, events, true);
      } else {
        await expect.poll(() => page.evaluate(owner => window.__getWorkerAdapter().getFollows(owner), owner), { timeout: 10000 }).toEqual([friend]);
        await expect.poll(() => events.every(event => sync().some(record => record.servedIds.includes(event.id))), { timeout: 10000 }).toBe(true);
        await assertSaved(page);
        const requested = sync().flatMap(record => record.requests);
        assert(requested.length > 0, 'Real NEG must lead to exact missing-ID fetches');
        assert(requested.every(filters => filters.every(filter => Array.isArray(filter.ids) && Object.keys(filter).every(key => key === 'ids'))), 'Graph catch-up must use exact-ID requests only');
        assert(relay.publishLive(liveEvents) >= 2, 'A live subscription must remain after bounded reconciliation closes');
        await expect.poll(() => page.evaluate(owner => window.__getWorkerAdapter().getFollows(owner), owner)).toEqual([muted]);
        await assertSaved(page, liveEvents);
      }
      const beforeReload = httpRequests;
      const bundledBeforeReload = bundledGraphReads;
      await page.reload({ waitUntil: 'domcontentloaded' }); await ready(page);
      await assertSaved(page, retained ? events : liveEvents, retained);
      assert.equal(httpRequests, beforeReload, 'Retained graph must not trigger HTTP replacement');
      assert.equal(bundledGraphReads, bundledBeforeReload, 'Retained graph must not fetch the bundled seed again');
      assert.equal((await page.evaluate(() => window.__policyMessages)).find(message => message.type === 'init').graphBootstrap, false);
      assert.equal(legacyReads, 0, 'Applications must not use the graph API');
      if (mode !== 'default-then-custom') {
        assert.equal(bundledGraphReads, bundledStart, 'Private and retained modes must not fetch the bundled seed');
        assert.equal(httpRequests, 0);
        assert.equal(nameReads(), 0, 'Private and retained modes must not resolve the public snapshot');
      } else assert(nameReads() > 0);
      assert.deepEqual(protocolErrors, []); assert.deepEqual(records().flatMap(record => record.errors), []);
      console.log(`${app}: ${mode} PASS; signed follow/mute IDs and cache preserved; HTTP=${httpRequests}; NEG sockets=${sync().length}`);
    } finally { await context.close(); }
  }
} finally {
  await browser.close(); await boundary.close(); await publicRelay.close(); await relay.close(); await new Promise(resolve => server.close(resolve));
}
