# @hashtree/worker

Modular browser worker for hashtree blob caching and Blossom connectivity.

Runs hashtree storage operations in a Web Worker to keep the main thread free. Handles IndexedDB caching, Blossom server uploads/downloads, connectivity probing, and P2P data exchange.

## Install

```bash
npm install https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.23/hashtree-worker-0.4.13.tgz
```

The npm registry version is older than this runtime archive. With npm 12+, add
`--allow-remote=all`. See [SDK installation](https://github.com/mmalmi/hashtree/blob/master/ts/README.md#install) and
[API reference](https://github.com/mmalmi/hashtree/blob/master/ts/API.md).

## Usage

With Vite, import the packaged worker entry using `?worker` (enable `vite/client`
types in your app). This example stores a raw local blob; it does not upload it.

```typescript
import { HashtreeWorkerClient } from '@hashtree/worker';
import HashtreeWorker from '@hashtree/worker/entry?worker';

const client = new HashtreeWorkerClient(HashtreeWorker, { storeName: 'my-app' });
await client.init();
try {
  const data = new TextEncoder().encode('Hello, worker!');
  const { hashHex } = await client.putBlob(data, 'text/plain', false);
  const { data: blob } = await client.getBlob(hashHex);
  if (!blob) throw new Error('Blob is unavailable');
  console.log(new TextDecoder().decode(blob));
} finally {
  await client.close();
}
```

## Retained Nostr events and gap recovery

`RelayWorkerClient` accepts an optional `reconciliation: {}` configuration for
bounded NIP-77 recovery on compatible relays. It compares against the worker's
existing persistent event store; normal subscriptions remain independent.
Reconciliation is off unless configured. Numeric bounds from
`RuntimeReconciliationOptions` can be supplied, but fetch functions cannot cross
the worker boundary.

Use `await client.ingestEvents(cachedSignedEvents)` to seed that store from an
existing application cache before opening a recovery subscription. Imports are
signature-checked and follow the runtime's deletion, expiration and replacement
rules. They do not sign, publish, or enter the outgoing queue. Each call accepts
up to 128 events and 2 MiB; split larger caches into bounded batches.

## Plain Worker + FIPS WebRTC

Browser mesh traffic runs through FIPS. FIPS owns Nostr discovery, signaling,
and WebRTC links; the worker only exchanges Hashtree request/response frames
through the provider interface:

```typescript
import { HashtreeWorkerClient } from '@hashtree/worker';
import { DexieStore } from '@hashtree/dexie';
import { createBrowserHashtreeFipsProvider } from '@hashtree/fips-transport/browser';

const client = new HashtreeWorkerClient(HashtreeWorker, {
  storeName: 'demo-worker',
});
const provider = await createBrowserHashtreeFipsProvider({
  deviceSecretKey,
  relays: ['wss://relay.damus.io'],
  localStore: new DexieStore('demo-fips-provider'),
});
client.setP2PProvider(provider);
await client.init();

// Before discarding the worker client:
await provider.stop();
await client.close();
```

There is no direct Hashtree WebRTC signaling or data-channel stack in this
package. `@fips/transport-webrtc` is the browser WebRTC underlay.

## Aggregate providers and local files

A provider may omit `listPeerIds` when its `fetch(hashHex, peerId, htl)` already
owns discovery. The worker then calls it with an undefined peer ID under the
existing read deadline. Keep a pending or failed discovery distinct from an
explicit missing-file result.

Use `client.putFile(data, { upload: false })` to create an encrypted local file
without uploading it. Upload defaults to false. The returned secret `nhash`
allows readers to decrypt the file; peer serving exposes only its ciphertext.
`putBlob(data, mimeType, false)` remains a raw local operation and does not grant
peer access.

For public data or already-encrypted blocks, use
`client.putBlock(data, { peerShare: true })` or
`client.putBlocks(blocks, { peerShare: true })`. These explicitly allow peers to
read the exact supplied bytes without changing their hashes or encrypting them.
The permission persists across restarts after every supplied hash validates;
unrelated cached blocks remain private. Upload is a separate option and defaults
to false. Use `putFile` for files that still need encryption.

`client.getBlobForPeer(hashHex, { sourceIds: ['blossom'] })` limits a privacy-checked
peer read to local authorized content and the configured Blossom source. An
empty source list permits only authorized local content. Denied or missing
content returns null; operational failures reject the promise.

## Relay Worker Client

If you are using `@hashtree/worker/relay-entry?worker` and need relay-backed tree-root
metadata or subscription calls, use the dedicated relay wrapper:

```typescript
import { RelayWorkerClient } from '@hashtree/worker/relay-client';
import HashtreeWorker from '@hashtree/worker/relay-entry?worker';

const client = new RelayWorkerClient(HashtreeWorker, {
  storeName: 'demo-sites-worker',
  relays: ['wss://relay.damus.io'],
  blossomServers: [{ url: 'https://upload.example', read: false, write: true }],
  pubkey: '336f319763657d6b0e65a5b5876719e8c8dcdcf9396852be71ee26b73368b29b',
});

// Created with createBrowserHashtreeFipsProvider(...) as above.
client.setP2PProvider(fipsProvider);
await client.init();
const root = await client.getTreeRootInfo('npub1example', 'sites/example');
const stop = client.onTreeRootUpdate((update) => {
  console.log(update.treeName, update.visibility);
});
```

Social graph follow/mute reconciliation uses the configured relays by default and
is separate from signed public Hashtree discovery. Metadata-only consumers can set
`graphReconciliation: false`. Public seeding defaults off; an app may explicitly
allow it for its unchanged shipped public relay set:

```typescript
const graphClient = new RelayWorkerClient(HashtreeWorker, {
  storeName: 'demo-social-worker',
  pubkey: '336f319763657d6b0e65a5b5876719e8c8dcdcf9396852be71ee26b73368b29b',
  relays: ['wss://relay.damus.io'], // This app's complete shipped default set.
  graphBootstrap: true,
});
await graphClient.init();
// Omitting graphBootstrap on a settings update revokes public seed permission.
// Configured-relay follow/mute reconciliation continues on this custom relay.
await graphClient.setRelays(['wss://relay.example']);
// Restore permission only when the complete shipped default set is restored.
await graphClient.setRelays(['wss://relay.damus.io'], { graphBootstrap: true });
```

A relay change, identity change, graph root change, or close cancels pending public
seeding. Root changes immediately restart reconciliation and the live follow/mute
subscription for the new root;
setting the same root again leaves an allowed initial seed in progress. Retained
local snapshots take priority, including partial lists and unreadable stored
bytes. Persistence compares the previously observed snapshot atomically and stops
writing if another tab has replaced it. Raw `setRelays` messages use a flat
`graphBootstrap` boolean alongside `relays`; absent means false.

Apps with Vite can make packaged discovery available before the signed update by
passing the SDK's frozen asset and receipt. The worker fetches this asset only
when `graphBootstrap` is true and no graph was retained, verifies its hash, root,
counts and mobile size budget, then loads the signed update in the background.
It merges current local follow/mute revisions into the update before installation.
An unavailable or rejected update leaves packaged discovery usable. An untouched
packaged seed is not saved as user state, so a later visit can retry signed
discovery. Real local changes and accepted signed snapshots remain durable.

```typescript
import graphUrl from 'nostr-social-graph/data/socialGraph.bin?url';
import graphReceipt from 'nostr-social-graph/data/socialGraph.json';
import type { MobileGraphReceipt } from 'nostr-social-graph/mobileGraphSnapshot';

const fallback = {
  url: new URL(graphUrl, window.location.href).href,
  receipt: graphReceipt as MobileGraphReceipt,
};
// Add graphBootstrapFallback: fallback to the graphClient configuration above.
```

The receipt's scoring root may differ from the worker's public discovery root;
verification uses the receipt root before adopting the viewer's root. Public
packaged seeds must contain 10,000–30,000 reachable users and fit in 4 MiB.
Graph-disabled apps should omit this option and avoid importing the asset.

When bridging a resolved or persisted root through the `setTreeRootCache` protocol
message, send `source: 'remote'` with its original `updatedAt` Unix timestamp in
seconds. This preserves replacement ordering across cache hydration and offline
restarts. Current local edits use `source: 'local-write'`; omitting `source` keeps
that existing local-write behavior. Remote timestamps must be nonnegative safe
integers. Hydration does not verify an event signature; the caller remains
responsible for accepting only trusted root observations.

## Browser Runtime Defaults

When the app runs inside Iris or another shell that injects `window.__HTREE_SERVER_URL__`
(or the launch URL carries `htree_server`), the main app-facing API should be
`createHtreeRuntime(...)`:

```typescript
import {
  HashtreeWorkerClient,
  createHtreeRuntime,
} from '@hashtree/worker';
import HashtreeWorker from '@hashtree/worker/entry?worker';

const DEFAULT_RELAYS = [
  'wss://relay.damus.io',
  'wss://relay.primal.net',
];

const DEFAULT_BLOSSOM_SERVERS = [
  { url: 'https://upload.example', read: false, write: true },
  { url: 'https://cdn.example', read: true, write: false },
];

const runtime = createHtreeRuntime({
  appId: 'my-app',
  relays: DEFAULT_RELAYS,
  blossomServers: DEFAULT_BLOSSOM_SERVERS,
});

const workerClient = new HashtreeWorkerClient(HashtreeWorker, {
  ...runtime.getWorkerConfig({
    storeName: 'my-app-worker',
  }),
});

await workerClient.init();

const mediaUrl = runtime.urls.media('htree://nhash1example/video.mp4', {
  clientScoped: true,
  mimeType: 'video/mp4',
});

await runtime.media.ensureReady({
  registerMediaPort: (port) => workerClient.registerMediaPort(port),
});
```

## Embedding In A Custom Worker

If you already have your own worker and do not want `@hashtree/worker` to own the whole
worker entrypoint, attach the protocol handler yourself:

```typescript
import { attachHashtreeWorker } from '@hashtree/worker/worker';

attachHashtreeWorker(self);

self.addEventListener('message', (event) => {
  if (event.data?.type === 'my-custom-message') {
    // Your own worker logic.
  }
});
```

If you want stricter isolation, attach it to a dedicated `MessagePort` instead of `self`.
That lets a larger worker multiplex hashtree traffic without sharing one global message
channel.

Behavior:

- In plain web mode, `runtime.endpoints` keeps your configured public relays and Blossom servers.
- In native child runtimes, `runtime.endpoints` and `runtime.getWorkerConfig()` switch transport defaults to the local daemon endpoints.
- `runtime.urls.media(...)` handles `/htree/...` URL generation plus the per-client `htree_c` and optional `htree_t` query params.
- `runtime.media.ensureReady(...)` handles the common page-side service-worker/media-port handshake.

## Transport Notes

- If you expect media or files to keep working through the worker, daemon, or FIPS peers, app-facing URLs should stay in `htree://...` or `/htree/...` form. Raw `https://` Blossom URLs bypass the runtime routing and will fail when a client intentionally has no direct Blossom access.
- The worker installs a P2P read route only while a provider is configured. Remote routes default to HTL 10; pass HTL 0 only for an exact authenticated local route. The worker forwards HTL unchanged and never decrements it.
- Every returned blob is SHA-256 verified before caching or returning. A read returns `null` only when every completed route explicitly reports `NoResult`; corruption, timeout, cancellation, and transport failure reject the read.
- Slow routes are bounded and hedged. A hedge may win, but a route timeout remains an error rather than a synthetic not-found.
- After bytes or fragments start flowing, prefer idle/progress-based expiry over total wall-clock deadlines. That keeps large media transfers alive without giving malicious peers an unlimited pin.
- For realistic verification, test cold direct navigation with requester-side Blossom disabled and assert that artwork/audio loads from `/htree/...` without any fallback requests to default Blossom servers.

## Cache Budget

`RelayWorkerClient.setStorageMaxBytes(bytes)` sets the shared block cache budget (default 1 GiB). Eviction checks run after initialization and persisted event/index changes as well as blob writes, coalesced over five seconds. Superseded index blocks and disposable cached files can be reclaimed; blocks reachable from current event and pending-publication roots remain protected, so durable data can exceed the budget.

Set `WorkerConfig.indexedEventCache` to `true` for browsing clients that need a
local relay cache. The worker stores signed events and their time, author, kind
and tag indexes in IndexedDB. Queries also include events retained by previous
versions. Deletions and replacements cover both stores, and pending publications
continue to use their portable outbox. The local event history is durable and
separate from the disposable file-block budget. The default event store uses
the portable Hashtree indexes.

## Service Worker Client Keys

If your service worker intercepts `/htree/...` media requests and forwards them to a worker over `MessagePort`, use a stable per-tab client key:

- `createHtreeRuntime(...)` generates it once per tab/webview.
- `runtime.urls.media(..., { clientScoped: true })` appends it as the `htree_c` query param.
- `runtime.media.ensureReady(...)` sends the same key in `REGISTER_WORKER_PORT` and `PING_WORKER_PORT`.

That lets the service worker map fetches back to the correct worker port when multiple tabs or isolated child webviews are active at once, without falling back to a single global port.

## Exports

### Public social graph updates

The relay worker retains its IndexedDB graph across root changes. With the optional
`nostr-social-graph` 4.x peer installed, it also reconciles signed public follow
lists (kind 3) and mute lists (kind 10000) against the configured relays. Each pass
rotates through at most 500 authors and uses a 2 MiB transfer budget, every 15
minutes. Relays without NIP-77 use bounded ordinary requests. Prefer a relay with
NIP-77 support when selecting public graph relays to avoid repeated event downloads.

Set `graphReconciliation: false` in the relay worker configuration to disable this
optional catch-up and fresh cold bootstrap. Existing live subscriptions remain
available. Saved graphs are loaded first; snapshots never replace a retained
personal crawl, and signed revision IDs survive restart. Private contacts and
encrypted list content do not enter this public graph.

- `@hashtree/worker` — `createHtreeRuntime`, `resolveRuntimeEndpoints`, and `HashtreeWorkerClient`
- `@hashtree/worker/relay-client` — `RelayWorkerClient` plus relay-backed tree-root metadata types
- `@hashtree/worker/worker` — `attachHashtreeWorker(...)` for embedding the worker protocol into a custom worker
- `@hashtree/worker/entry` — Worker entry point
- `@hashtree/worker/protocol` — Shared message types between main thread and worker

## License

MIT
