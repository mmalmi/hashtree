// @ts-nocheck
import type { RuntimeEventInfo, RuntimeCompletion, RuntimePublishResult, RuntimeQueryOptions, RuntimeQueryResult, RuntimeSource, RuntimeReconciliationOptions } from 'nostr-pubsub';
/**
 * Worker Protocol Types
 *
 * Message types for communication between main thread and hashtree worker.
 * Worker owns: HashTree and Nostr (via nostr-tools)
 * Main thread owns: UI, NIP-07 extension access (signing/encryption)
 */

import type { CID } from '@hashtree/core';
import type { BlossomBandwidthStats } from '@hashtree/core/worker';

// Re-export common types from hashtree's worker protocol
export type {
  NostrFilter,
  UnsignedEvent,
  SignedEvent,
  SocialGraphEvent,
  BlossomBandwidthStats,
  BlossomBandwidthServerStats,
} from '@hashtree/core/worker';

// Tree visibility levels
export type TreeVisibility = 'public' | 'link-visible' | 'private';

export interface TreeRootInfo {
  hash: Uint8Array;
  key?: Uint8Array;
  visibility: TreeVisibility;
  labels?: string[];
  updatedAt: number;
  snapshotNhash?: string;
  encryptedKey?: string;
  keyId?: string;
  selfEncryptedKey?: string;
  selfEncryptedLinkKey?: string;
}

// Extended peer stats with pool classification for apps that group peers.
export interface PeerStats {
  peerId: string;
  pubkey: string;
  connected: boolean;
  pool: 'follows' | 'other';
  requestsSent: number;
  requestsReceived: number;
  responsesSent: number;
  responsesReceived: number;
  bytesSent: number;
  bytesReceived: number;
  forwardedRequests: number;
  forwardedResolved: number;
  forwardedSuppressed: number;
}

// ============================================================================
// Main Thread → Worker Messages
// ============================================================================

export type WorkerRequest =
  | { type: 'attachNostrSource'; id: string; sourceId: string; port: MessagePort; publishAcceptance?: RuntimeSource['publishAcceptance'] }
  | { type: 'detachNostrSource'; id: string; sourceId: string }
  | { type: 'cancelNostrQuery'; id: string; requestId: string }
  | { type: 'query'; id: string; filters: NostrFilter[]; options?: Omit<RuntimeQueryOptions, 'signal'> }
  // Lifecycle
  | { type: 'init'; id: string; config: WorkerConfig; p2pProviderEnabled?: boolean; p2pPeerListSupported?: boolean }
  | { type: 'close'; id: string }
  | { type: 'setP2PProviderState'; id: string; enabled: boolean; peerListSupported?: boolean }
  | { type: 'setIdentity'; id: string; pubkey: string; nsec?: string }

  // Store operations (low-level hash-based)
  | { type: 'get'; id: string; hash: Uint8Array }
  | { type: 'put'; id: string; hash: Uint8Array; data: Uint8Array }
  | { type: 'has'; id: string; hash: Uint8Array }
  | { type: 'delete'; id: string; hash: Uint8Array }

  // Tree operations (high-level CID-based)
  | { type: 'readFile'; id: string; cid: CID }
  | { type: 'readFileRange'; id: string; cid: CID; start: number; end?: number }
  | { type: 'readFileStream'; id: string; cid: CID }
  | { type: 'writeFile'; id: string; parentCid: CID | null; path: string; data: Uint8Array }
  | { type: 'deleteFile'; id: string; parentCid: CID; path: string }
  | { type: 'listDir'; id: string; cid: CID }
  | { type: 'resolveRoot'; id: string; npub: string; path?: string }

  // Tree root cache and subscriptions
  | {
      type: 'setTreeRootCache';
      id: string;
      npub: string;
      treeName: string;
      hash: Uint8Array;
      key?: Uint8Array;
      visibility: TreeVisibility;
      /** Remote hydration preserves its original timestamp and cannot force a newer root out. */
      source?: 'local-write' | 'remote';
      /** Original Unix seconds; required for remote hydration. */
      updatedAt?: number;
      labels?: string[];
      encryptedKey?: string;
      keyId?: string;
      selfEncryptedKey?: string;
      selfEncryptedLinkKey?: string;
    }
  | { type: 'getTreeRootInfo'; id: string; npub: string; treeName: string }
  | { type: 'mergeTreeRootKey'; id: string; npub: string; treeName: string; hash: Uint8Array; key: Uint8Array }
  | { type: 'subscribeTreeRoots'; id: string; pubkey: string }
  | { type: 'unsubscribeTreeRoots'; id: string; pubkey: string }

  // Nostr subscriptions
  | { type: 'subscribe'; id: string; filters: NostrFilter[] }
  | { type: 'unsubscribe'; id: string; subId: string }
  | { type: 'publish'; id: string; event: SignedEvent }
  | { type: 'ingestEvents'; id: string; events: SignedEvent[] }

  // Media streaming (service worker registers a MessagePort)
  | { type: 'registerMediaPort'; port: MessagePort; debug?: boolean }

  // Stats
  | { type: 'getPeerStats'; id: string }
  | { type: 'getRelayStats'; id: string }
  | { type: 'getStorageStats'; id: string }

  // Blossom configuration
  | { type: 'setBlossomServers'; id: string; servers: BlossomServerConfig[] }

  // Storage configuration
  | { type: 'setStorageMaxBytes'; id: string; maxBytes: number }

  // Relay configuration
  | { type: 'setRelays'; id: string; relays: string[]; graphBootstrap?: boolean }

  // Blossom upload
  | { type: 'pushToBlossom'; id: string; cidHash: Uint8Array; cidKey?: Uint8Array; treeName?: string }
  | { type: 'startBlossomSession'; id: string; sessionId: string; totalChunks: number }
  | { type: 'endBlossomSession'; id: string }

  // Republish cached events
  | { type: 'republishTrees'; id: string; prefix?: string }
  | { type: 'republishTree'; id: string; pubkey: string; treeName: string }

  // Heartbeat
  | { type: 'ping'; id: string }

  // SocialGraph
  | { type: 'initSocialGraph'; id: string; rootPubkey?: string }
  | { type: 'setSocialGraphRoot'; id: string; pubkey: string }
  | { type: 'handleSocialGraphEvents'; id: string; events: SocialGraphEvent[] }
  | { type: 'getFollowDistance'; id: string; pubkey: string }
  | { type: 'isFollowing'; id: string; follower: string; followed: string }
  | { type: 'getFollows'; id: string; pubkey: string }
  | { type: 'getFollowers'; id: string; pubkey: string }
  | { type: 'getFollowedByFriends'; id: string; pubkey: string }
  | { type: 'getSocialGraphSize'; id: string }
  | { type: 'fetchUserFollows'; id: string; pubkey: string }
  | { type: 'fetchUserFollowers'; id: string; pubkey: string }

  // NIP-07 responses (main thread → worker, after signing/encryption)
  | { type: 'signed'; id: string; event?: SignedEvent; error?: string }
  | { type: 'encrypted'; id: string; ciphertext?: string; error?: string }
  | { type: 'decrypted'; id: string; plaintext?: string; error?: string }

  // FIPS-backed P2P provider responses (main thread → worker)
  | { type: 'p2pFetchResult'; id: string; requestId: string; data?: Uint8Array; error?: string }
  | { type: 'p2pPeerListResult'; id: string; requestId: string; peerIds?: string[]; error?: string };

/** Blossom server configuration */
export interface BlossomServerConfig {
  url: string;
  read?: boolean;  // Whether to read from this server (default true)
  write?: boolean; // Whether to write to this server
  preferBatchReads?: boolean; // Prefer POST /blob/batch over raw /{hash}.bin reads
}

export interface WorkerConfig {
  relays: string[];
  blossomServers?: BlossomServerConfig[];  // Blossom servers with read/write config
  pubkey: string;  // User's pubkey (required - user always logged in)
  nsec?: string;  // Hex-encoded secret key (only for nsec login, not extension)
  /** Keep incoming events in local IndexedDB indexes; existing portable history and the outbox stay readable. */
  indexedEventCache?: boolean;
  storeName?: string;  // IndexedDB database name, defaults to 'hashtree-worker'
  /** Set false to disable bounded public follow/mute catch-up on the configured relays. */
  graphReconciliation?: boolean;
  /** Allow signed public discovery only when no graph is retained. Defaults to false. */
  graphBootstrap?: boolean;
  /** App-bundled seed, verified against its shipped receipt before the signed update.
   * Ignored unless graphBootstrap is true and no local graph is retained. */
  graphBootstrapFallback?: {
    url: string;
    receipt: import('nostr-social-graph/mobileGraphSnapshot').MobileGraphReceipt;
  };
  /** Opt-in background NIP-77 recovery against the worker's retained event store. */
  reconciliation?: Omit<RuntimeReconciliationOptions, 'fetch'>;
}

// ============================================================================
// Worker → Main Thread Messages
// ============================================================================

export type WorkerResponse =
  // Lifecycle
  | { type: 'ready' }
  | { type: 'pong'; id: string }
  | { type: 'error'; id?: string; error: string }

  // Generic responses
  | { type: 'result'; id: string; data?: Uint8Array; error?: string }
  | { type: 'bool'; id: string; value: boolean; error?: string }
  | { type: 'cid'; id: string; cid?: CID; error?: string }
  | { type: 'void'; id: string; error?: string; receipt?: RuntimePublishResult }

  // Tree operations
  | { type: 'dirListing'; id: string; entries?: DirEntry[]; error?: string }
  | { type: 'streamChunk'; id: string; chunk: Uint8Array; done: boolean }

  // Nostr events
  | { type: 'event'; subId: string; event: SignedEvent; info?: RuntimeEventInfo }
  | { type: 'eose'; subId: string; status?: RuntimeCompletion }
  | { type: 'nostrStatus'; subId: string; status: RuntimeCompletion }
  | { type: 'nostrQuery'; id: string; result?: RuntimeQueryResult; error?: string }

  // Stats
  | { type: 'peerStats'; id: string; stats: PeerStats[] }
  | { type: 'relayStats'; id: string; stats: RelayStats[] }
  | { type: 'storageStats'; id: string; items: number; bytes: number }

  // Blossom notifications
  | { type: 'blossomBandwidth'; stats: BlossomBandwidthStats }
  | { type: 'blossomUploadError'; hash: string; error: string }
  | { type: 'blossomUploadProgress'; progress: BlossomUploadProgress }
  | { type: 'blossomPushResult'; id: string; pushed: number; skipped: number; failed: number; error?: string; errors?: string[] }

  // Republish result
  | { type: 'republishResult'; id: string; count: number; error?: string; encryptionErrors?: string[] }

  // Background Blossom push progress (for automatic pushes)
  | { type: 'blossomPushStarted'; treeName: string; totalChunks: number }
  | { type: 'blossomPushProgress'; treeName: string; current: number; total: number }
  | { type: 'blossomPushComplete'; treeName: string; pushed: number; skipped: number; failed: number }

  // Tree root updates (worker → main thread notification)
  | { type: 'treeRootUpdate'; npub: string; treeName: string; hash: Uint8Array; key?: Uint8Array; visibility: TreeVisibility; labels?: string[]; updatedAt: number; snapshotNhash?: string; encryptedKey?: string; keyId?: string; selfEncryptedKey?: string; selfEncryptedLinkKey?: string }
  | { type: 'treeRootInfo'; id: string; record?: TreeRootInfo; error?: string }

  // SocialGraph responses
  | { type: 'socialGraphInit'; id: string; version: number; size: number; error?: string }
  | { type: 'socialGraphVersion'; version: number }
  | { type: 'followDistance'; id: string; distance: number; error?: string }
  | { type: 'isFollowingResult'; id: string; result: boolean; error?: string }
  | { type: 'pubkeyList'; id: string; pubkeys: string[]; error?: string }
  | { type: 'socialGraphSize'; id: string; size: number; error?: string }
  | { type: 'ack'; id: string; error?: string }

  // NIP-07 requests (worker → main thread, needs extension)
  | { type: 'signEvent'; id: string; event: UnsignedEvent }
  | { type: 'nip44Encrypt'; id: string; pubkey: string; plaintext: string }
  | { type: 'nip44Decrypt'; id: string; pubkey: string; ciphertext: string }

  // FIPS-backed P2P provider requests (worker → main thread)
  | { type: 'p2pFetch'; requestId: string; hashHex: string; htl: number; peerId?: string }
  | { type: 'p2pPeerList'; requestId: string };

export interface DirEntry {
  name: string;
  isDir: boolean;
  size?: number;
  cid?: CID;
}

export interface RelayStats {
  url: string;
  connected: boolean;
  eventsReceived: number;
  eventsSent: number;
}

/** Per-server upload status */
export interface BlossomServerStatus {
  url: string;
  uploaded: number;  // Number of chunks uploaded to this server
  failed: number;    // Number of chunks failed on this server
  skipped: number;   // Number of chunks already existed on this server
}

/** Overall blossom upload progress */
export interface BlossomUploadProgress {
  sessionId: string;           // Unique session identifier
  totalChunks: number;         // Total chunks to upload
  processedChunks: number;     // Chunks processed (uploaded + skipped + failed)
  servers: BlossomServerStatus[];  // Per-server status
}

// ============================================================================
// Service Worker ↔ Worker Messages (via MessagePort)
// ============================================================================

// Request by direct CID (for cached/known content)
export interface MediaRequestByCid {
  type: 'media';
  requestId: string;
  cid: string;  // hex encoded CID hash
  start: number;
  end?: number;
  mimeType?: string;
}

// Request by npub/path (supports live streaming via tree root updates)
export interface MediaRequestByPath {
  type: 'mediaByPath';
  requestId: string;
  npub: string;
  path: string;  // e.g., "public/video.webm"
  start: number;
  end?: number;
  mimeType?: string;
}

export type MediaRequest = MediaRequestByCid | MediaRequestByPath;

export type MediaResponse =
  | { type: 'headers'; requestId: string; totalSize: number; mimeType: string; isLive?: boolean }
  | { type: 'chunk'; requestId: string; data: Uint8Array }
  | { type: 'done'; requestId: string }
  | { type: 'error'; requestId: string; message: string };

// ============================================================================
// Helper functions
// ============================================================================

let requestIdCounter = 0;

export function generateRequestId(): string {
  return `req_${Date.now()}_${++requestIdCounter}`;
}
