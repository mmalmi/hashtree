import { NostrEventStore, type StoredNostrEvent } from '@hashtree/nostr';
import { verifyEvent } from 'nostr-tools/pure';
import {
  cloneNostrEvent,
  filtersMatchNostrEvents,
  markNostrEventVerifiedAndFreeze,
  type NostrEventReaderContract,
  type NostrEvent,
  type NostrFilter,
  type NostrReaderQueryEvent,
  type NostrVerifiedEvent,
} from './nostrTypes.js';
import { QueryCancellation, isCancellationError } from './cancellation.js';
import {
  normalizeGlobalLimit,
  planFilterQuery,
  validateHashtreeNostrFilters,
} from './filterQuery.js';
import { GuardedReplicaStore } from './guardedStore.js';
import {
  normalizeRootProvider,
  snapshotRoots,
  type RootReplicaSnapshot,
} from './roots.js';
import {
  HashtreeNostrReplicaCorruptError,
  HashtreeNostrReplicaUnavailableError,
  type HashtreeNostrEventBatchVerifier,
  type HashtreeNostrEventReaderOptions,
  type HashtreeNostrEventVerificationContext,
  type HashtreeNostrPartitionReport,
  type HashtreeNostrQueryOptions,
  type HashtreeNostrQueryReport,
  type HashtreeNostrReplicaAttempt,
} from './types.js';

interface PartitionResult {
  events: NostrVerifiedEvent[];
  report: HashtreeNostrPartitionReport;
}

interface VerifierCancellation {
  signal?: AbortSignal;
  dispose(): void;
}

const DEFAULT_LOCAL_INDEX_PRIORITY = 300;
const DEFAULT_MAX_CONCURRENT_PARTITIONS = 8;
const MAX_CONCURRENT_PARTITIONS = 64;

export class HashtreeNostrEventReader implements NostrEventReaderContract {
  private readonly store;
  private readonly rootProvider;
  private readonly source;
  private readonly priority;
  private readonly maxConcurrentPartitions;
  private readonly verifyEvents;

  constructor(options: HashtreeNostrEventReaderOptions) {
    this.store = options.store;
    this.rootProvider = normalizeRootProvider(options.roots);
    this.source = options.source ?? {
      id: options.sourceId ?? 'hashtree-nostr',
      kind: 'local-index' as const,
    };
    this.priority = options.priority ?? DEFAULT_LOCAL_INDEX_PRIORITY;
    this.maxConcurrentPartitions = normalizePartitionConcurrency(
      options.maxConcurrentPartitions,
    );
    this.verifyEvents = options.verifyEvents ?? verifyNostrEventBatch;
  }

  async query(
    filters: NostrFilter[],
    options: HashtreeNostrQueryOptions = {},
  ): Promise<HashtreeNostrQueryReport> {
    validateHashtreeNostrFilters(filters);
    const limit = normalizeGlobalLimit(options.limit);
    const cancellation = new QueryCancellation(options);
    const roots = await snapshotRoots(
      this.rootProvider,
      this.store,
      filters,
      cancellation,
    );
    const partitions = groupPartitions(roots);
    const reports = new Array<HashtreeNostrPartitionReport>(partitions.length);
    let merged: NostrVerifiedEvent[] = [];
    let nextPartition = 0;
    const workerCount = Math.min(this.maxConcurrentPartitions, partitions.length);
    await Promise.all(Array.from({ length: workerCount }, async () => {
      while (nextPartition < partitions.length) {
        const partitionIndex = nextPartition;
        nextPartition += 1;
        const result = await this.queryPartition(
          partitions[partitionIndex]!,
          filters,
          limit,
          cancellation,
        );
        reports[partitionIndex] = result.report;
        merged = mergeVerifiedEvents(merged, result.events, limit);
      }
    }));
    cancellation.throwIfCancelled();

    const events: NostrReaderQueryEvent[] = merged.map((event) => ({
      event,
      source: this.source,
      priority: this.priority,
    }));

    return {
      events,
      complete: reports.every((report) => report.status !== 'unavailable'),
      partitions: reports,
    };
  }

  private async queryPartition(
    replicas: RootReplicaSnapshot[],
    filters: NostrFilter[],
    limit: number | undefined,
    cancellation: QueryCancellation,
  ): Promise<PartitionResult> {
    const partitionId = replicas[0]!.partitionId;
    const attempts: HashtreeNostrReplicaAttempt[] = [];

    for (const replica of replicas) {
      cancellation.throwIfCancelled();
      try {
        const events = await this.queryReplica(replica, filters, limit, cancellation);
        const status = events.length === 0 ? 'empty' : 'complete';
        attempts.push({
          partitionId,
          replicaId: replica.replicaId,
          status,
          eventCount: events.length,
        });
        return {
          events,
          report: {
            partitionId,
            status,
            selectedReplicaId: replica.replicaId,
            eventCount: events.length,
            attempts,
          },
        };
      } catch (error) {
        if (isCancellationError(error) || cancellation.signal?.aborted) throw error;
        if (error instanceof HashtreeNostrVerifierUnavailableError) throw error;
        const status = error instanceof HashtreeNostrReplicaCorruptError
          ? 'corrupt'
          : 'unavailable';
        attempts.push({
          partitionId,
          replicaId: replica.replicaId,
          status,
          eventCount: 0,
          reason: errorMessage(error),
        });
      }
    }

    return {
      events: [],
      report: {
        partitionId,
        status: 'unavailable',
        eventCount: 0,
        attempts,
      },
    };
  }

  private async queryReplica(
    replica: RootReplicaSnapshot,
    filters: NostrFilter[],
    limit: number | undefined,
    cancellation: QueryCancellation,
  ): Promise<NostrVerifiedEvent[]> {
    if (replica.root === null || limit === 0) return [];

    const guardedStore = new GuardedReplicaStore(replica.store, cancellation);
    const eventStore = new NostrEventStore(guardedStore);
    const effectiveFilters = filters.length === 0 ? [{}] : filters;

    let storedEvents: StoredNostrEvent[];
    try {
      const groups = await Promise.all(effectiveFilters.map(async (filter) => {
        const plan = planFilterQuery(filter, limit);
        if (plan.impossible) return [];
        return await eventStore.query(replica.root, plan.query, plan.options);
      }));
      storedEvents = dedupeStoredEvents(groups.flat());
    } catch (error) {
      if (isCancellationError(error) || cancellation.signal?.aborted) throw error;
      if (error instanceof HashtreeNostrReplicaUnavailableError) throw error;
      throw new HashtreeNostrReplicaCorruptError(
        'Hashtree Nostr replica contains unreadable index data',
        { cause: error },
      );
    }

    cancellation.throwIfCancelled();
    let candidates: NostrEvent[];
    let verificationBatch: readonly NostrEvent[];
    try {
      candidates = storedEvents.map((event) => cloneNostrEvent(event));
      verificationBatch = Object.freeze(candidates.map((event) => cloneNostrEvent(event)));
    } catch (error) {
      throw invalidReplicaEvent(error);
    }

    const verifierCancellation = createVerifierCancellation(cancellation);
    let validity: readonly boolean[];
    try {
      cancellation.throwIfCancelled();
      validity = await cancellation.wait(Promise.resolve(this.verifyEvents(
        verificationBatch,
        Object.freeze({
          signal: verifierCancellation.signal,
          deadline: cancellation.deadline,
        }),
      )));
      cancellation.throwIfCancelled();
    } catch (error) {
      cancellation.throwIfCancelled();
      if (isCancellationError(error) || cancellation.signal?.aborted) throw error;
      throw new HashtreeNostrVerifierUnavailableError(error);
    } finally {
      verifierCancellation.dispose();
    }

    try {
      assertValidVerificationResult(validity, candidates.length);
      return candidates
        .map((event) => markNostrEventVerifiedAndFreeze(event))
        .filter((event) => filtersMatchNostrEvents(filters, event));
    } catch (error) {
      throw invalidReplicaEvent(error);
    }
  }
}

class HashtreeNostrVerifierUnavailableError extends Error {
  constructor(cause: unknown) {
    super('Hashtree Nostr event verifier is unavailable', { cause });
    this.name = 'HashtreeNostrVerifierUnavailableError';
  }
}

const verifyNostrEventBatch: HashtreeNostrEventBatchVerifier = (events, context) => {
  const validity: boolean[] = [];
  for (const event of events) {
    throwIfVerifierCancelled(context);
    validity.push(verifyEvent(event));
  }
  return validity;
};

function createVerifierCancellation(
  cancellation: QueryCancellation,
): VerifierCancellation {
  if (cancellation.deadline === undefined) {
    return {
      signal: cancellation.signal,
      dispose() {},
    };
  }

  const controller = new AbortController();
  const sourceSignal = cancellation.signal;
  const deadline = cancellation.deadline;
  const abortFromSource = () => controller.abort(sourceSignal?.reason);
  sourceSignal?.addEventListener('abort', abortFromSource, { once: true });
  if (sourceSignal?.aborted) abortFromSource();
  const timer = setTimeout(
    () => controller.abort(verifierDeadlineError()),
    Math.max(0, deadline - Date.now()),
  );

  return {
    signal: controller.signal,
    dispose() {
      clearTimeout(timer);
      sourceSignal?.removeEventListener('abort', abortFromSource);
      if (!controller.signal.aborted && Date.now() >= deadline) {
        controller.abort(verifierDeadlineError());
      }
    },
  };
}

function invalidReplicaEvent(cause: unknown): HashtreeNostrReplicaCorruptError {
  return new HashtreeNostrReplicaCorruptError(
    'Hashtree Nostr replica contains an event with an invalid id or signature',
    { cause },
  );
}

function verifierDeadlineError(): DOMException {
  return new DOMException('The query deadline elapsed', 'TimeoutError');
}

function throwIfVerifierCancelled(
  context: HashtreeNostrEventVerificationContext,
): void {
  if (context.signal?.aborted) {
    throw context.signal.reason
      ?? new DOMException('The query was aborted', 'AbortError');
  }
  if (context.deadline !== undefined && Date.now() >= context.deadline) {
    throw verifierDeadlineError();
  }
}

function assertValidVerificationResult(
  validity: readonly boolean[],
  eventCount: number,
): void {
  if (
    !Array.isArray(validity)
    || validity.length !== eventCount
  ) {
    throw new TypeError(
      'Hashtree Nostr event verifier must return one boolean per event',
    );
  }
  for (let index = 0; index < eventCount; index += 1) {
    const valid = validity[index];
    if (typeof valid !== 'boolean') {
      throw new TypeError(
        'Hashtree Nostr event verifier must return one boolean per event',
      );
    }
    if (!valid) {
      throw new Error('invalid Nostr event id or signature');
    }
  }
}

function groupPartitions(roots: RootReplicaSnapshot[]): RootReplicaSnapshot[][] {
  const partitions = new Map<string, RootReplicaSnapshot[]>();
  for (const root of roots) {
    const replicas = partitions.get(root.partitionId) ?? [];
    replicas.push(root);
    partitions.set(root.partitionId, replicas);
  }
  return [...partitions.values()];
}

function dedupeStoredEvents(events: StoredNostrEvent[]): StoredNostrEvent[] {
  const byId = new Map<string, StoredNostrEvent>();
  for (const event of events) {
    const current = byId.get(event.id);
    if (!current || compareEventPayload(event, current) < 0) byId.set(event.id, event);
  }
  return [...byId.values()];
}

function mergeVerifiedEvents(
  retained: NostrVerifiedEvent[],
  incoming: NostrVerifiedEvent[],
  limit: number | undefined,
): NostrVerifiedEvent[] {
  const byId = new Map<string, NostrVerifiedEvent>();
  for (const event of retained) {
    byId.set(event.id, event);
  }
  for (const event of incoming) {
    const current = byId.get(event.id);
    if (!current || compareEventPayload(event, current) < 0) byId.set(event.id, event);
  }
  const ordered = [...byId.values()].sort(compareNewestFirst);
  return limit === undefined ? ordered : ordered.slice(0, limit);
}

function normalizePartitionConcurrency(configured: number | undefined): number {
  if (configured === undefined) return DEFAULT_MAX_CONCURRENT_PARTITIONS;
  if (!Number.isFinite(configured)) {
    throw new RangeError('Hashtree Nostr partition concurrency must be finite');
  }
  return Math.min(
    MAX_CONCURRENT_PARTITIONS,
    Math.max(1, Math.floor(configured)),
  );
}

function compareNewestFirst(left: NostrVerifiedEvent, right: NostrVerifiedEvent): number {
  if (left.created_at !== right.created_at) return left.created_at > right.created_at ? -1 : 1;
  return left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
}

function compareEventPayload(left: StoredNostrEvent, right: StoredNostrEvent): number {
  const leftPayload = JSON.stringify(left);
  const rightPayload = JSON.stringify(right);
  return leftPayload < rightPayload ? -1 : leftPayload > rightPayload ? 1 : 0;
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Unknown replica failure';
}
