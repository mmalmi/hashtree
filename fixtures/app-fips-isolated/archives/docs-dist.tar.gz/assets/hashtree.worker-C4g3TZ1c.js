function e(r){return new Worker(""+new URL("hashtree.worker-5rCMr7z8.js",import.meta.url).href,{name:r==null?void 0:r.name})}export{e as default};
