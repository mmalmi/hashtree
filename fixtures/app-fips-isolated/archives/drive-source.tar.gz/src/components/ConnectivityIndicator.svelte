<script lang="ts">
  /**
   * Simplified connectivity indicator - network icon with count
   * Red: not connected, Yellow: relays only, Green: peers, Blue: follows peers
   * Shows "offline" text when browser is offline
   * Clicking navigates to settings
   */
  import { appStore } from '../store';
  import { nostrStore } from '../nostr';
  import { getNativeDaemonRelayUrl } from '../nostr/client';
  import {
    HEADER_CONNECTIVITY_WARNING_STARTUP_GRACE_MS,
    shouldShowHeaderConnectivityIndicator,
  } from '../lib/headerConnectivity';

  interface Props {
    showAlways?: boolean;
  }

  let { showAlways = false }: Props = $props();

  let peerCount = $derived($appStore.peerCount);
  let peersList = $derived($appStore.peers);
  let connectedRelays = $derived($nostrStore.connectedRelays);
  let transportRelays = $derived($nostrStore.transportRelays);
  let configuredRelays = $derived($nostrStore.relays);
  let configuredRelayCount = $derived(configuredRelays.length);
  let transportRelayCount = $derived(transportRelays.length);
  const nativeDaemonRelayUrl = getNativeDaemonRelayUrl();

  let displayRelays = $derived.by(() => {
    if (connectedRelays > 0) return connectedRelays;
    if (transportRelayCount > 0) return transportRelayCount;
    return configuredRelayCount;
  });

  // Count peers in follows pool
  let followsPeers = $derived(peersList.filter(p => p.pool === 'follows' && p.state === 'connected').length);

  // Track browser online/offline status
  let isOnline = $state(typeof navigator !== 'undefined' ? navigator.onLine : true);
  let startupGraceElapsed = $state(false);

  $effect(() => {
    const timer = window.setTimeout(() => {
      startupGraceElapsed = true;
    }, HEADER_CONNECTIVITY_WARNING_STARTUP_GRACE_MS);
    const handleOnline = () => { isOnline = true; };
    const handleOffline = () => { isOnline = false; };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  });

  // Color logic: red = offline/none, yellow = relays only/connecting, green = peers, blue = follows peers
  let color = $derived.by(() => {
    if (!isOnline) return '#f85149'; // red when offline
    if (connectedRelays === 0) return configuredRelayCount > 0 ? '#d29922' : '#f85149'; // yellow if connecting
    if (peerCount === 0) return '#d29922'; // yellow
    if (followsPeers > 0) return '#58a6ff'; // blue - connected to follows
    return '#3fb950'; // green - connected to other peers
  });

  let title = $derived.by(() => {
    const connectedTransportRelays = transportRelays.filter(
      (relay: { status: string; url: string }) => relay.status === 'connected'
    );
    const primaryTransport = connectedTransportRelays[0]?.url ?? transportRelays[0]?.url ?? null;
    const isDaemonTransport = primaryTransport === nativeDaemonRelayUrl;

    if (!isOnline) return 'Offline';
    if (connectedRelays === 0) {
      if (primaryTransport) {
        return isDaemonTransport
          ? `Connecting via embedded daemon relay (${primaryTransport})`
          : `Connecting to ${primaryTransport}`;
      }
      return configuredRelayCount > 0
        ? `Connecting to ${configuredRelayCount} configured relay${configuredRelayCount !== 1 ? 's' : ''}`
        : 'No relays configured';
    }
    if (peerCount === 0) {
      return isDaemonTransport && primaryTransport
        ? `Embedded daemon relay connected (${primaryTransport}), no peers`
        : `${connectedRelays} relay${connectedRelays !== 1 ? 's' : ''}, no peers`;
    }
    if (followsPeers > 0) {
      return `${followsPeers} follow${followsPeers !== 1 ? 's' : ''}, ${peerCount - followsPeers} other, ${connectedRelays} relay${connectedRelays !== 1 ? 's' : ''}`;
    }
    return `${peerCount} peer${peerCount !== 1 ? 's' : ''}, ${connectedRelays} relay${connectedRelays !== 1 ? 's' : ''}`;
  });

  // Total connections = relays + peers (show configured relays while connecting)
  let totalConnections = $derived(displayRelays + peerCount);
  let showIndicator = $derived(shouldShowHeaderConnectivityIndicator({
    showConnectivityInHeader: showAlways,
    connectedRelays,
    connectedPeers: peerCount,
    startupGraceElapsed,
  }));
</script>

{#if showIndicator}
  <a
    href="#/settings/network"
    class="flex min-h-9 items-center justify-center rounded-full px-2 text-sm no-underline hover:bg-surface-2"
    data-testid="connectivity-indicator"
    aria-label={showAlways ? title : 'Offline'}
    {title}
  >
    {#if showAlways}
      <span class="flex flex-col items-center">
        <span
          data-testid="peer-indicator-dot"
          class="i-lucide-wifi"
          style="color: {color}"
        ></span>
        <span data-testid="peer-count" class="text-xs -mt-1" style="color: {color}">{totalConnections}</span>
      </span>
      {#if !isOnline}
        <span class="ml-1 text-xs text-danger">offline</span>
      {/if}
    {:else}
      <span class="flex items-center gap-1.5 text-xs font-medium text-danger">
        <span class="i-lucide-wifi-off text-base"></span>
        <span>Offline</span>
      </span>
    {/if}
  </a>
{/if}
