import type { NostrIdentityId } from './protocolTypes';
import { isUuid } from './protocolJson';

export function nostrIdentityRosterOpDTag(profileId: NostrIdentityId, clientNonce: string): string {
  return `iris-profile/${profileId}/roster-op/${clientNonce}`;
}

export function nostrIdentityFacetAcceptanceDTag(profileId: NostrIdentityId, clientNonce: string): string {
  return `iris-profile/${profileId}/facet-acceptance/${clientNonce}`;
}

export function shareRosterCheckpointDTag(shareId: NostrIdentityId, clientNonce: string): string {
  return `iris-drive/share/${shareId}/roster-checkpoint/${clientNonce}`;
}

export function shareMemberRosterOpDTag(shareId: NostrIdentityId, clientNonce: string): string {
  return `iris-drive/share/${shareId}/member-roster-op/${clientNonce}`;
}

export function parseNostrIdentityRosterOpDTag(dTag: string): { profileId: NostrIdentityId; nonce: string } {
  const rest = dTag.startsWith('iris-profile/') ? dTag.slice('iris-profile/'.length) : '';
  const split = rest.indexOf('/roster-op/');
  if (split <= 0) {
    throw new Error(`invalid NostrIdentity roster d tag: ${dTag}`);
  }
  const profileId = rest.slice(0, split);
  const nonce = rest.slice(split + '/roster-op/'.length);
  if (!isUuid(profileId) || !nonce || nonce.includes('/')) {
    throw new Error(`invalid NostrIdentity roster d tag: ${dTag}`);
  }
  return { profileId, nonce };
}

export function parseNostrIdentityFacetAcceptanceDTag(dTag: string): { profileId: NostrIdentityId; nonce: string } {
  const rest = dTag.startsWith('iris-profile/') ? dTag.slice('iris-profile/'.length) : '';
  const split = rest.indexOf('/facet-acceptance/');
  if (split <= 0) {
    throw new Error(`invalid NostrIdentity facet acceptance d tag: ${dTag}`);
  }
  const profileId = rest.slice(0, split);
  const nonce = rest.slice(split + '/facet-acceptance/'.length);
  if (!isUuid(profileId) || !nonce || nonce.includes('/')) {
    throw new Error(`invalid NostrIdentity facet acceptance d tag: ${dTag}`);
  }
  return { profileId, nonce };
}

export function parseShareRosterCheckpointDTag(dTag: string): { shareId: NostrIdentityId; nonce: string } {
  const rest = dTag.startsWith('iris-drive/share/') ? dTag.slice('iris-drive/share/'.length) : '';
  const split = rest.indexOf('/roster-checkpoint/');
  if (split <= 0) {
    throw new Error(`invalid share roster checkpoint d tag: ${dTag}`);
  }
  const shareId = rest.slice(0, split);
  const nonce = rest.slice(split + '/roster-checkpoint/'.length);
  if (!isUuid(shareId) || !nonce || nonce.includes('/')) {
    throw new Error(`invalid share roster checkpoint d tag: ${dTag}`);
  }
  return { shareId, nonce };
}

export function parseShareMemberRosterOpDTag(dTag: string): { shareId: NostrIdentityId; nonce: string } {
  const rest = dTag.startsWith('iris-drive/share/') ? dTag.slice('iris-drive/share/'.length) : '';
  const split = rest.indexOf('/member-roster-op/');
  if (split <= 0) {
    throw new Error(`invalid share member roster d tag: ${dTag}`);
  }
  const shareId = rest.slice(0, split);
  const nonce = rest.slice(split + '/member-roster-op/'.length);
  if (!isUuid(shareId) || !nonce || nonce.includes('/')) {
    throw new Error(`invalid share member roster d tag: ${dTag}`);
  }
  return { shareId, nonce };
}
