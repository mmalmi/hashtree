import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { chromium } from '@playwright/test';
import { generateSecretKey, getPublicKey, nip19 } from 'nostr-tools';

const MIME_TYPES = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.ico', 'image/x-icon'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.mjs', 'application/javascript; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.wasm', 'application/wasm'],
  ['.webmanifest', 'application/manifest+json; charset=utf-8'],
]);

function contentTypeFor(filePath) {
  return MIME_TYPES.get(path.extname(filePath)) ?? 'application/octet-stream';
}

function shouldIgnoreConsoleError(text) {
  if (/^Failed to load resource: the server responded with a status of 404\b/.test(text)) {
    return true;
  }
  if (/^Failed to load resource: the server responded with a status of 416\b/.test(text)) {
    return true;
  }
  if (/^WebSocket connection to 'wss?:\/\/[^']+' failed:/.test(text)) {
    return true;
  }
  if (/^WebSocket is already in CLOSING or CLOSED state\.?$/.test(text)) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: No connected relays available for publish')) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: rate-limited:')) {
    return true;
  }
  if (text.startsWith('Failed to publish initial profile: NDKPublishError: Not enough relays received the event')) {
    return true;
  }
  return false;
}

function safeJoin(rootDir, requestPath, entryHtml) {
  const normalized = requestPath === '/' ? `/${entryHtml}` : requestPath;
  const fullPath = path.resolve(rootDir, `.${normalized}`);
  if (!fullPath.startsWith(rootDir + path.sep) && fullPath !== path.join(rootDir, entryHtml)) {
    throw new Error(`Refusing to serve path outside root: ${requestPath}`);
  }
  return fullPath;
}

async function startServer(rootDir, entryHtml = 'index.html') {
  const server = http.createServer(async (req, res) => {
    try {
      const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1');
      const filePath = safeJoin(rootDir, decodeURIComponent(requestUrl.pathname), entryHtml);
      const body = await readFile(filePath);
      res.writeHead(200, {
        'content-type': contentTypeFor(filePath),
        'cache-control': 'no-store',
      });
      res.end(body);
    } catch (error) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(error instanceof Error ? error.message : 'not found');
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });

  const address = server.address();
  if (!address || typeof address === 'string') {
    server.close();
    throw new Error('Failed to determine portable smoke server address');
  }

  return {
    server,
    url: `http://127.0.0.1:${address.port}/${entryHtml}#/`,
  };
}

export async function runPortableSmoke({ distDir, title, appName, screenshotPath, validatePage, entryHtml = 'index.html' }) {
  const { server, url } = await startServer(distDir, entryHtml);
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const key = generateSecretKey();
  const pubkey = getPublicKey(key);
  const nsec = nip19.nsecEncode(key);
  await page.addInitScript(({ pubkey, nsec }) => {
    if (sessionStorage.getItem('portable-session-seeded')) return;
    sessionStorage.setItem('portable-session-seeded', '1');
    localStorage.setItem('hashtree:nsec', nsec);
    localStorage.setItem('hashtree:loginType', 'nsec');
    localStorage.setItem('hashtree:activeAccount', pubkey);
    localStorage.setItem('hashtree:accounts', JSON.stringify([{ pubkey, nsec, type: 'nsec', addedAt: 100 }]));
  }, { pubkey, nsec });
  const documentResponses = [];
  const localResponseFailures = [];
  const pageErrors = [];
  const consoleErrors = [];
  const smokeOrigin = new URL(url).origin;

  page.on('response', (response) => {
    if (response.request().resourceType() === 'document') {
      documentResponses.push(response.url());
    }
    if (response.status() < 400) {
      return;
    }
    let responseUrl;
    try {
      responseUrl = new URL(response.url());
    } catch {
      return;
    }
    if (responseUrl.origin !== smokeOrigin) {
      return;
    }
    if (responseUrl.pathname.startsWith('/htree/')) {
      return;
    }
    // A static localhost host has no optional native Drive bridge.
    if (response.status() === 404 && responseUrl.pathname === '/api/iris-drive/share-action') return;
    localResponseFailures.push(`${response.status()} ${response.request().resourceType()} ${response.url()}`);
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.stack || error.message);
  });
  page.on('console', (message) => {
    if (message.type() === 'error') {
      const text = message.text();
      if (shouldIgnoreConsoleError(text)) {
        return;
      }
      consoleErrors.push(text);
    }
  });

  try {
    const response = await page.goto(url, { waitUntil: 'load', timeout: 60000 });
    if (!response || response.status() !== 200) {
      throw new Error(`Portable build returned ${response?.status() ?? 'no response'} for ${url}`);
    }

    await page.waitForTimeout(3000);
    await page.screenshot({ path: screenshotPath, fullPage: true });

    const actualTitle = await page.title();
    if (actualTitle !== title) {
      throw new Error(`Portable build loaded unexpected title "${actualTitle}"`);
    }

    if (documentResponses.length > 2) {
      throw new Error(`Portable build reloaded unexpectedly (${documentResponses.length} document responses)`);
    }

    if (localResponseFailures.length > 0) {
      throw new Error(`Portable build hit local asset failures:\n${localResponseFailures.join('\n')}`);
    }

    const headerText = (await page.locator('header').textContent().catch(() => '')).toLowerCase();
    const hasAppHeader = headerText.includes(appName.toLowerCase());
    const hasLogin = await page.getByRole('button', { name: /^Login$/ }).isVisible().catch(() => false);
    if (!hasAppHeader && !hasLogin) {
      const bodyPreview = (await page.locator('body').innerText()).slice(0, 500);
      throw new Error(`Portable build did not render the ${appName} shell. Body preview: ${bodyPreview}`);
    }

    if (typeof validatePage === 'function') {
      await validatePage(page);
    }

    if (pageErrors.length > 0) {
      throw new Error(`Portable build hit page errors:\n${pageErrors.join('\n')}`);
    }

    if (consoleErrors.length > 0) {
      throw new Error(`Portable build logged console errors:\n${consoleErrors.join('\n')}`);
    }

    await page.evaluate(async () => { await navigator.serviceWorker.ready; });
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    const sessionBeforeOffline = await page.evaluate(() => ({
      secretKey: localStorage.getItem('hashtree:nsec'),
      loginType: localStorage.getItem('hashtree:loginType'),
      activeAccount: localStorage.getItem('hashtree:activeAccount'),
    }));
    if (sessionBeforeOffline.secretKey !== nsec) throw new Error('Portable build lost the existing secret key');
    await page.getByTestId('header-user-avatar').waitFor({ state: 'visible' });
    await page.context().setOffline(true);
    const offlineResponse = await page.reload({ waitUntil: 'load', timeout: 30000 });
    if (!offlineResponse || offlineResponse.status() !== 200) {
      throw new Error('Portable build could not reload its cached app shell offline');
    }
    await page.getByTestId('header-user-avatar').waitFor({ state: 'visible' });
    if (await page.title() !== title) throw new Error('Offline reload lost the application title');
    const restored = await page.evaluate(() => ({
      secretKey: localStorage.getItem('hashtree:nsec'),
      loginType: localStorage.getItem('hashtree:loginType'),
      activeAccount: localStorage.getItem('hashtree:activeAccount'),
    }));
    if (JSON.stringify(restored) !== JSON.stringify(sessionBeforeOffline)) {
      throw new Error('Offline reload changed the existing login session');
    }
    if (pageErrors.length > 0) {
      throw new Error(`Offline portable build hit page errors:\n${pageErrors.join('\n')}`);
    }

    console.log(`Portable Iris ${appName} smoke passed: ${url}`);
    console.log(`Screenshot: ${screenshotPath}`);
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
}
