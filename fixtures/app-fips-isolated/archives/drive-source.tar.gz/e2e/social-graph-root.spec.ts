import { test, expect, type Page } from './fixtures';
import { finalizeEvent, getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import { disableOthersPool, setupPageErrorHandler, waitForAppReady, ensureLoggedIn, presetLocalRelayInDB, waitForRelayConnected } from './test-utils.js';
import { FOLLOW_SECKEY_HEX, BOOTSTRAP_SECKEY, FOLLOW_SECKEY } from './nostr-test-keys';

let relayUrl = '';
test.beforeEach(({ relayUrl: testRelayUrl }) => {
  relayUrl = testRelayUrl;
});
const BOOTSTRAP_PUBKEY = getPublicKey(BOOTSTRAP_SECKEY);
const BOOTSTRAP_NPUB = nip19.npubEncode(BOOTSTRAP_PUBKEY);
const FOLLOW_PUBKEY = getPublicKey(FOLLOW_SECKEY);

async function currentWorkerRootDistance(page: Page) {
  return page.evaluate(async () => {
    const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
    const { nostrStore } = await import('/src/nostr/index.ts');
    const pubkey = nostrStore.getState().pubkey;
    const adapter = getWorkerAdapter();
    return {
      pubkey,
      distance: pubkey && adapter ? await adapter.getFollowDistance(pubkey) : null,
    };
  });
}

async function publishEvent(event: Record<string, unknown>): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const socket = new WebSocket(relayUrl);
    const timeout = setTimeout(() => {
      socket.close();
      reject(new Error('Timed out publishing event'));
    }, 2000);

    socket.on('open', () => {
      socket.send(JSON.stringify(['EVENT', event]));
    });

    socket.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (Array.isArray(msg) && msg[0] === 'OK' && msg[1] === (event as { id?: string }).id) {
          clearTimeout(timeout);
          socket.close();
          resolve();
        }
      } catch {
        // ignore parse errors
      }
    });

    socket.on('error', (err) => {
      clearTimeout(timeout);
      reject(err);
    });
  });
}

async function seedKnownFollowers(): Promise<void> {
  const now = Math.floor(Date.now() / 1000);
  const followerKey = Buffer.from(FOLLOW_SECKEY_HEX, 'hex');

  const followEvent = finalizeEvent({
    kind: 3,
    content: '',
    tags: [['p', BOOTSTRAP_PUBKEY]],
    created_at: now,
    pubkey: FOLLOW_PUBKEY,
  }, followerKey);

  await publishEvent(followEvent);
}

/**
 * Test that social graph root is set correctly on login and account switch
 */
test.describe('Social graph root', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  test('should set root when app loads with logged in user', async ({ page }) => {
    await page.goto('/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);

    // Read the real worker graph; the legacy getSocialGraph shim is only a local cache.
    const initialPubkey = (await currentWorkerRootDistance(page)).pubkey;
    expect(initialPubkey).toMatch(/^[a-f0-9]{64}$/);
    await expect.poll(() => currentWorkerRootDistance(page), { timeout: 10000 })
      .toEqual({ pubkey: initialPubkey, distance: 0 });

    // Exercise the production account-switch path without setting the graph root in the test.
    expect(FOLLOW_PUBKEY).not.toBe(initialPubkey);
    expect(await page.evaluate(async (nsec) => {
      const { loginWithNsec } = await import('/src/nostr.ts');
      return loginWithNsec(nsec);
    }, nip19.nsecEncode(FOLLOW_SECKEY))).toBe(true);
    await expect.poll(() => currentWorkerRootDistance(page), { timeout: 10000 })
      .toEqual({ pubkey: FOLLOW_PUBKEY, distance: 0 });
  });

  test('should show me as known follower when I follow someone', async ({ page }) => {
    test.setTimeout(60000);

    const logs: string[] = [];
    page.on('console', (msg) => {
      const text = msg.text();
      if (text.includes('[Worker]') || text.includes('[socialGraph]')) {
        logs.push(text);
        console.log(text); // Print immediately
      }
    });

    // Capture page errors
    page.on('pageerror', (err) => {
      console.log('[PAGE ERROR]:', err.message);
    });

    // Clear storage to start fresh
    await page.goto('/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await page.evaluate(() => {
      localStorage.clear();
      indexedDB.deleteDatabase('hashtree-social-graph');
    });
    await page.reload();
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 20000);

    // Close any modals
    const backdrop = page.locator('.fixed.inset-0.z-50');
    if (await backdrop.isVisible().catch(() => false)) {
      await backdrop.click({ position: { x: 5, y: 5 }, force: true });
    }

    // The standalone shell has an account menu, not the legacy profile-avatar link.
    const { pubkey: myPubkey } = await currentWorkerRootDistance(page);
    expect(myPubkey).toMatch(/^[a-f0-9]{64}$/);
    expect(myPubkey).not.toBe(BOOTSTRAP_PUBKEY);

    // Navigate to a known user (different from self) using in-page navigation
    // This is a valid npub (verified checksum)
    const testNpub = BOOTSTRAP_NPUB;
    console.log('Navigating to test user:', testNpub);

    // Use search to navigate (more realistic user flow)
    await page.fill('input[placeholder*="Search"]', testNpub);
    await page.keyboard.press('Enter');

    // Wait for URL to contain the test npub
    await page.waitForURL(new RegExp(testNpub.slice(0, 20)), { timeout: 10000 });
    console.log('Current URL:', page.url());

    // Wait for profile to load - check for Follow button or profile name
    await page.waitForSelector('button:has-text("Follow"), h1', { timeout: 10000 });

    // Verify we're on someone else's profile
    // Check for Follow button (would only appear on someone else's profile)
    const followButton = page.getByRole('button', { name: 'Follow', exact: true });
    const editButton = page.getByRole('button', { name: 'Edit Profile' });

    const hasFollowBtn = await followButton.isVisible().catch(() => false);
    const hasEditBtn = await editButton.isVisible().catch(() => false);

    console.log('Has Follow button:', hasFollowBtn);
    console.log('Has Edit Profile button:', hasEditBtn);

    // Get page content for debugging
    const profileName = await page.locator('h1').first().textContent().catch(() => 'unknown');
    console.log('Profile name shown:', profileName);

    // Wait for Known Followers text to appear (indicates profile loaded)
    // Use first() to avoid strict mode violation when there are multiple matches
    const followersText = page.locator('text=Known Followers').first();
    await followersText.waitFor({ state: 'visible', timeout: 10000 });

    // Get the known followers count before following
    const getFollowersCount = async () => {
      const text = await followersText.textContent();
      const match = text?.match(/(\d+)/);
      return match ? parseInt(match[1]) : 0;
    };

    const followersBefore = await getFollowersCount();
    console.log('Followers before:', followersBefore);

    // Take screenshot
    await page.screenshot({ path: 'e2e/screenshots/before-follow.png', fullPage: true });

    // Follow the user
    await expect(followButton).toBeVisible();
    console.log('Clicking follow button...');
    await followButton.click();

    // Wait for the social graph to update - poll for count increase
    // The fix should make this happen immediately after publish
    await page.waitForFunction(
      (beforeCount) => {
        const text = document.body.textContent || '';
        const match = text.match(/(\d+)\s*Known Followers/);
        const currentCount = match ? parseInt(match[1]) : 0;
        console.log('[Test] Checking followers count:', currentCount, 'before was:', beforeCount);
        return currentCount > beforeCount;
      },
      followersBefore,
      { timeout: 10000 }
    );

    console.log('=== Logs after follow ===');
    logs.slice(-10).forEach(log => console.log(log));

    // Get final count
    const followersAfter = await getFollowersCount();
    console.log('Followers after:', followersAfter);

    // After following, I should be counted as a known follower
    // For a new account following someone, the count goes from 0 to 1
    expect(followersAfter).toBeGreaterThan(followersBefore);
  });

  test('should show known followers on direct profile navigation', async ({ page }) => {
    test.slow(); // This test needs time for social graph to load from relays
    const logs: string[] = [];
    page.on('console', (msg) => {
      const text = msg.text();
      if (text.includes('[Worker]') || text.includes('[socialGraph]')) {
        logs.push(text);
        console.log(text);
      }
    });

    await seedKnownFollowers();

    // Login first
    await page.goto('/');
    await presetLocalRelayInDB(page, relayUrl);
    await page.reload();
    await waitForAppReady(page);
    await disableOthersPool(page);
    await waitForRelayConnected(page, 30000);
    await ensureLoggedIn(page, 20000);
    await page.waitForFunction(() => (window as any).__testHelpers?.followPubkey, { timeout: 10000 });
    await page.evaluate((pk) => (window as any).__testHelpers?.followPubkey?.(pk), FOLLOW_PUBKEY);

    // Wait for login
    await page.waitForFunction(() => {
      const nostrStore = (window as any).__nostrStore;
      return nostrStore?.getState()?.pubkey?.length === 64;
    }, { timeout: 15000 });

    // Navigate directly to bootstrap user's profile
    await page.goto(`/#/${BOOTSTRAP_NPUB}`);
    await waitForRelayConnected(page, 30000);
    await page.evaluate(async (pubkey) => {
      const { fetchUserFollowers } = await import('/src/utils/socialGraph');
      fetchUserFollowers(pubkey);
    }, BOOTSTRAP_PUBKEY);

    // Wait for profile to load - "Known Followers" should appear
    await page.waitForSelector('text=Known Followers', { timeout: 15000 });

    // Get initial followers count
    // The format is: "<count> Known Followers"
    const getFollowersCount = async () => {
      const text = await page.locator('text=Known Followers').first().textContent();
      // Match count before "Known Followers" - format is "<count> Known Followers"
      const match = text?.match(/(\d+)\s*Known Followers/);
      return match ? parseInt(match[1]) : 0;
    };

    const initialCount = await getFollowersCount();
    console.log('Initial followers count:', initialCount);

    // Wait for known followers to become > 0 as social graph loads
    // The social graph needs to receive kind:3 events from people who follow this user
    const countResult = await page.waitForFunction(() => {
      const text = document.body.textContent || '';
      const match = text.match(/(\d+)\s*Known Followers/);
      return match ? parseInt(match[1]) : 0;
    }, { timeout: 30000, polling: 1000 }).catch(() => null);

    const count = countResult ? await countResult.jsonValue() : 0;
    console.log('Current followers count:', count);
    expect(count).toBeGreaterThan(0);
  });
});
