import { saveTextFile } from './test-utils.js';
import { expect, test, type Browser, type Page } from './fixtures';
import {
  addFileViaTreeAPI,
  clearAllStorage,
  configureBlossomServers,
  flushPendingPublishes,
  getTestBlossomUrl,
  navigateToPublicFolder,
  presetLocalRelayInDB,
  setupPageErrorHandler,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseNostrIdentityRosterOpEvent } from '../src/drive/protocolProfileEvents';
import { generateSecretKey, getPublicKey, nip19 } from 'nostr-tools';
import { irisDriveAvailable, runIdriveJson } from './native-idrive';

function configureNativeBlossom(configDir: string): void {
  runIdriveJson(configDir, ['blossom-servers', 'remove', 'https://upload.iris.to']);
  runIdriveJson(configDir, ['blossom-servers', 'add', getTestBlossomUrl()]);
}

type StoredNostrIdentitySessionForTest = {
  schema: 1;
  profileId: string;
  appKeyNsec: string;
  status: 'active';
  rosterOps: Array<{
    op_id: string;
    signer_pubkey: string;
    content: unknown;
    event_json: string;
  }>;
  createdAt: number;
  label?: string;
};

function readNativeNostrIdentitySession(configDir: string, label = 'native-e2e'): StoredNostrIdentitySessionForTest {
  const nsec = fs.readFileSync(path.join(configDir, 'key'), 'utf8').trim();
  const rosterStore = JSON.parse(
    fs.readFileSync(path.join(configDir, 'profile-roster-events.json'), 'utf8'),
  ) as { profile_id?: string; events?: string[] };
  const profileId = rosterStore.profile_id;
  if (!profileId) {
    throw new Error('Native profile roster store is missing profile_id');
  }
  const rosterOps = (rosterStore.events ?? []).map((eventJson) => {
    const event = JSON.parse(eventJson);
    return parseNostrIdentityRosterOpEvent(event);
  });
  if (rosterOps.length === 0) {
    throw new Error('Native profile roster store is missing NostrIdentity roster ops');
  }

  return {
    schema: 1,
    profileId,
    appKeyNsec: nsec,
    status: 'active',
    rosterOps,
    createdAt: Math.floor(Date.now() / 1000),
    label,
  };
}

async function prepareFreshPage(
  page: Page,
  relayUrl: string,
  nsec?: string,
  nostrIdentitySession?: StoredNostrIdentitySessionForTest,
): Promise<void> {
  setupPageErrorHandler(page);
  await page.goto('/');
  await clearAllStorage(page);
  await presetLocalRelayInDB(page, relayUrl);
  if (nsec) {
    await page.evaluate(({ secret, session }) => {
      localStorage.setItem('hashtree:loginType', 'nsec');
      localStorage.setItem('hashtree:nsec', secret);
      if (session) {
        localStorage.setItem('iris:identity:session', JSON.stringify(session));
      }
    }, { secret: nsec, session: nostrIdentitySession ?? null });
  }
  await page.reload({ waitUntil: 'domcontentloaded' });
  await waitForAppReady(page, 60000);
  if (nsec) {
    await page.waitForFunction(() => {
      const store = (window as any).__nostrStore;
      return store?.getState?.().pubkey?.length === 64;
    }, { timeout: 30000 });
  }
  await useLocalRelay(page, relayUrl);
  await configureBlossomServers(page);
  await waitForRelayConnected(page, 30000);
}

async function createFileWithContent(page: Page, fileName: string, content: string): Promise<void> {
  await page.getByRole('button', { name: 'New File' }).click();
  const nameInput = page.locator('input[placeholder="File name..."]');
  await expect(nameInput).toBeVisible({ timeout: 10000 });
  await nameInput.fill(fileName);
  const modal = page.locator('.fixed.inset-0').filter({ has: nameInput }).last();
  await modal.getByRole('button', { name: 'Create' }).click();

  const editor = page.locator('textarea');
  await expect(editor).toBeVisible({ timeout: 30000 });
  await editor.fill(content);

  await saveTextFile(page, 30_000);
  await page.getByRole('button', { name: 'Done' }).click();
  await expect(editor).not.toBeVisible({ timeout: 30000 });
}

async function createPrivateDriveTree(page: Page): Promise<void> {
  await page.evaluate(async () => {
    const { createTree } = await import('/src/actions');
    const { getTreeRootSync } = await import('/src/stores');
    const rootScope = (): string | null => {
      const stored = JSON.parse(localStorage.getItem('iris:identity:session') ?? 'null');
      if (stored?.status === 'active' && typeof stored.profileId === 'string') {
        return stored.profileId;
      }
      return (window as any).__nostrStore?.getState?.().npub ?? null;
    };
    const hasMainRoot = (): boolean => {
      const scope = rootScope();
      return !!scope && !!getTreeRootSync(scope, 'main')?.hash;
    };
    if (hasMainRoot()) return;
    const result = await createTree('main', 'private', true);
    if (!result.success && !hasMainRoot()) {
      throw new Error('Failed to create private main drive');
    }
  });
  await flushPendingPublishes(page);
}

async function pushCurrentRootToBlossom(page: Page, treeName: string): Promise<void> {
  await page.evaluate(async (targetTree: string) => {
    const { getTreeRootSync } = await import('/src/stores');
    const npub = (window as any).__nostrStore?.getState?.().npub;
    const root = npub ? getTreeRootSync(npub, targetTree) : null;
    if (!root?.hash) {
      throw new Error(`No root for ${targetTree}`);
    }
    const adapter = (window as any).__getWorkerAdapter?.() ?? (window as any).__workerAdapter;
    if (!adapter?.pushToBlossom) {
      throw new Error('Worker adapter has no pushToBlossom');
    }
    const result = await adapter.pushToBlossom(root.hash, root.key, targetTree);
    if (result.failed > 0) {
      throw new Error(`Blossom push failed: ${JSON.stringify(result)}`);
    }
  }, treeName);
}

async function waitForRemoteTreeRoot(page: Page, npub: string, treeName: string): Promise<void> {
  await page.evaluate(async ({ owner, tree, timeout }) => {
    const { waitForTreeRoot } = await import('/src/stores');
    const root = await waitForTreeRoot(owner, tree, timeout);
    if (!root?.hash) {
      throw new Error(`Timed out waiting for tree root ${owner}/${tree}`);
    }
  }, { owner: npub, tree: treeName, timeout: 60000 });
}

async function waitForRemoteTreeRootHash(
  page: Page,
  npub: string,
  treeName: string,
  expectedRootHash: string,
): Promise<void> {
  await page.evaluate(async ({ owner, tree }) => {
    const { refreshDriveRootResolverKey } = await import('/src/stores/treeRootResolver.ts');
    refreshDriveRootResolverKey(`${owner}/${tree}`);
  }, { owner: npub, tree: treeName });

  await expect.poll(
    () => page.evaluate(async ({ owner, tree }) => {
      const { getTreeRootSync } = await import('/src/stores');
      const toHex = (bytes: Uint8Array): string => Array.from(bytes)
        .map((byte) => byte.toString(16).padStart(2, '0'))
        .join('');
      const root = getTreeRootSync(owner, tree);
      if (root?.hash) return toHex(root.hash);
      return null;
    }, { owner: npub, tree: treeName }),
    { timeout: 60000, intervals: [500, 1000, 2000] },
  ).toBe(expectedRootHash);
}

type RelayDriveRootDiagnostic = {
  id: string;
  pubkey: string;
  created_at: number;
  root_hash: string | null;
  app_key_seq: number | null;
  dck_generation: number | null;
  d: string | null;
};

async function fetchRelayDriveRootHashes(
  page: Page,
  relayUrl: string,
  profileId: string,
  treeName: string,
): Promise<RelayDriveRootDiagnostic[]> {
  return page.evaluate(async ({ relay, profile, tree }) => {
    const { driveRootDTag, KIND_DRIVE_ROOT, parseDriveRootEventParts } = await import('/src/drive/protocol');
    const dTag = driveRootDTag(profile, tree);

    return new Promise<RelayDriveRootDiagnostic[]>((resolve, reject) => {
      const events: RelayDriveRootDiagnostic[] = [];
      const subId = `drive-root-${Math.random().toString(36).slice(2)}`;
      const socket = new WebSocket(relay);
      const timeout = window.setTimeout(() => {
        socket.close();
        resolve(events);
      }, 3000);

      socket.onopen = () => {
        socket.send(JSON.stringify(['REQ', subId, {
          kinds: [KIND_DRIVE_ROOT],
          '#d': [dTag],
          limit: 50,
        }]));
      };
      socket.onmessage = (message) => {
        const data = JSON.parse(String(message.data));
        if (data[0] === 'EVENT') {
          const event = data[2];
          let rootHash: string | null = null;
          let appKeySeq: number | null = null;
          let dckGeneration: number | null = null;
          try {
            const { content } = parseDriveRootEventParts(event);
            rootHash = content.root_hash ?? null;
            appKeySeq = typeof content?.app_key_seq === 'number' ? content.app_key_seq : null;
            dckGeneration = typeof content?.dck_generation === 'number' ? content.dck_generation : null;
          } catch {
            rootHash = null;
          }
          events.push({
            id: event.id,
            pubkey: event.pubkey,
            created_at: event.created_at,
            root_hash: rootHash,
            app_key_seq: appKeySeq,
            dck_generation: dckGeneration,
            d: event.tags?.find((tag: string[]) => tag[0] === 'd')?.[1] ?? null,
          });
        }
        if (data[0] === 'EOSE') {
          window.clearTimeout(timeout);
          socket.send(JSON.stringify(['CLOSE', subId]));
          socket.close();
          resolve(events);
        }
      };
      socket.onerror = () => {
        window.clearTimeout(timeout);
        reject(new Error(`relay websocket error: ${relay}`));
      };
    });
  }, { relay: relayUrl, profile: profileId, tree: treeName });
}

// Observe existing requests only: no cache reads, prefetch, provider changes, or retries.
async function observeInteropReads(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const evidence = { messages: [] as Record<string, unknown>[], dropped: 0 };
    (window as any).__interopReadEvidence = evidence;
    const record = (value: Record<string, unknown>) => {
      if (evidence.messages.length === 128) { evidence.messages.shift(); evidence.dropped += 1; }
      evidence.messages.push({ at: Date.now(), ...value });
    };
    const hex = (bytes?: Uint8Array) => bytes ? Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('') : null;
    const watched = new WeakSet<Worker>();
    const requests = new Set<string>();
    const original = Worker.prototype.postMessage;
    Worker.prototype.postMessage = function(message: any, ...args: any[]) {
      if (!message || typeof message !== 'object') return Reflect.apply(original, this, [message, ...args]);
      if (!watched.has(this)) {
        watched.add(this);
        this.addEventListener('message', ({ data }) => {
          if (!data || typeof data !== 'object') return;
          if (data.type === 'treeRootUpdate' || data.type === 'treeRootInfo') {
            const root = data.record ?? data;
            record({ direction: 'from-worker', type: data.type, npub: root.npub, treeName: root.treeName,
              hashHex: hex(root.hash), keyBytes: root.key?.byteLength ?? 0, updatedAt: root.updatedAt, visibility: root.visibility });
          } else if (data.type === 'p2pFetch' || requests.delete(data.id)) {
            record({ direction: 'from-worker', type: data.type, id: data.id, requestId: data.requestId,
              hashHex: data.hashHex, peerId: data.peerId, error: data.error, bytes: data.data?.byteLength ?? null });
          }
        });
      }
      if (['get', 'getBlob', 'readFile', 'listDir', 'resolvePath'].includes(message.type)) {
        if (requests.size >= 128) requests.delete(requests.values().next().value!);
        requests.add(message.id);
        record({ direction: 'to-worker', type: message.type, id: message.id,
          hashHex: hex(message.hash ?? message.cid?.hash), keyBytes: message.cid?.key?.byteLength ?? 0, path: message.path });
      } else if (message.type === 'p2pFetchResult') {
        record({ direction: 'to-worker', type: message.type, requestId: message.requestId,
          bytes: message.data?.byteLength ?? 0, error: message.error });
      }
      return Reflect.apply(original, this, [message, ...args]);
    };
  });
}

async function interopSnapshot(page: Page, owner: string, treeName: string) {
  return page.evaluate(async ({ owner, treeName }) => {
    const { getTreeRootSync } = await import('/src/stores');
    const { treeRootRegistry } = await import('/src/TreeRootRegistry.ts');
    const { directoryEntriesStore } = await import('/src/stores/directoryEntries.ts');
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const { blossomLogStore } = await import('/src/stores/blossomLog.ts');
    const hex = (bytes?: Uint8Array) => bytes ? Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('') : null;
    const root = getTreeRootSync(owner, treeName);
    const record = treeRootRegistry.get(owner, treeName);
    let directory: unknown;
    directoryEntriesStore.subscribe(state => { directory = {
      loadedHashKey: state.loadedHashKey, loading: state.loading, isDirectory: state.isDirectory,
      entries: state.entries.map(entry => entry.name),
    }; })();
    return { at: Date.now(), route: location.hash, rootHash: hex(root?.hash), keyBytes: root?.key?.byteLength ?? 0,
      registry: record ? { hashHex: hex(record.hash), keyBytes: record.key?.byteLength ?? 0,
        source: record.source, dirty: record.dirty, updatedAt: record.updatedAt, visibility: record.visibility } : null,
      adapterPresent: !!(window as any).__getWorkerAdapter?.(), peers: getDriveFipsRuntime()?.getStats(),
      directory, blossom: blossomLogStore.getAll(), reads: (window as any).__interopReadEvidence ?? null };
  }, { owner, treeName });
}

async function readTreeFile(page: Page, npub: string, treeName: string, fileName: string): Promise<string | null> {
  return page.evaluate(async ({ owner, treeName: targetTree, fileName: targetFile }) => {
    const { getTreeRootSync } = await import('/src/stores');
    const { getTree } = await import('/src/store');
    const root = getTreeRootSync(owner, targetTree);
    const evidence = (window as any).__interopReadEvidence;
    const attempt = { at: Date.now(), rootHash: root?.hash ? Array.from(root.hash, b => b.toString(16).padStart(2, '0')).join('') : null,
      keyBytes: root?.key?.byteLength ?? 0, stage: 'root', error: null as string | null, bytes: null as number | null };
    if (evidence) {
      if (evidence.messages.length === 128) { evidence.messages.shift(); evidence.dropped += 1; }
      evidence.messages.push(attempt);
    }
    if (!root?.hash) return null;
    const tree = getTree();
    attempt.stage = 'resolvePath';
    const entry = await tree.resolvePath(root, targetFile).catch(error => { attempt.error = String(error); return null; });
    if (!entry?.cid) { attempt.stage = 'entry-missing'; return null; }
    attempt.stage = 'readFile';
    const data = await tree.readFile(entry.cid).catch(error => { attempt.error = String(error); return null; });
    attempt.stage = data ? 'read-complete' : 'data-missing';
    attempt.bytes = data?.byteLength ?? null;
    return data ? new TextDecoder().decode(data) : null;
  }, { owner: npub, treeName, fileName });
}

async function expectTreeFile(
  page: Page,
  npub: string,
  treeName: string,
  fileName: string,
  expectedContent: string,
  expectedRootHash?: string,
): Promise<void> {
  await page.goto(`/#/${encodeURIComponent(npub)}/${encodeURIComponent(treeName)}`);
  await waitForAppReady(page, 60000);
  await waitForRemoteTreeRoot(page, npub, treeName);
  if (expectedRootHash) {
    await waitForRemoteTreeRootHash(page, npub, treeName, expectedRootHash);
  }
  await expect.poll(
    () => readTreeFile(page, npub, treeName, fileName),
    { timeout: 90000, intervals: [1000, 2000, 3000] },
  ).toBe(expectedContent);
}

function generateNsec(): { nsec: string; npub: string } {
  const secret = generateSecretKey();
  return {
    nsec: nip19.nsecEncode(secret),
    npub: nip19.npubEncode(getPublicKey(secret)),
  };
}

async function waitForNativeFiles(
  configDir: string,
  relayUrl: string,
  expected: Array<{ fileName: string; content: string }>,
  diagnostics?: Record<string, unknown>,
): Promise<void> {
  const expectedFiles = expected.map(({ fileName, content }) => ({
    fileName,
    present: true,
    size: Buffer.byteLength(content),
    expectedSize: Buffer.byteLength(content),
  }));
  const deadline = Date.now() + 90000;
  let last: unknown = null;

  while (Date.now() < deadline) {
    const sync = runIdriveJson(configDir, ['sync', '--relay', relayUrl, '--timeout', '5']);
    const listing = runIdriveJson(configDir, ['list']);
    const status = runIdriveJson(configDir, ['status']);
    const files = expected.map(({ fileName, content }) => {
      const file = listing.files.find((entry: any) => entry.path === fileName);
      return {
        fileName,
        present: !!file,
        size: file?.size ?? -1,
        expectedSize: Buffer.byteLength(content),
      };
    });
    last = {
      files,
      sync: {
        profile_roster_ops_seen: sync.profile_roster_ops_seen,
        profile_roster_ops_applied: sync.profile_roster_ops_applied,
        drive_root_events_seen: sync.drive_root_events_seen,
        drive_root_events_applied: sync.drive_root_events_applied,
        drive_root_events_skipped: sync.drive_root_events_skipped,
        files_root_event_seen: sync.files_root_event_seen,
        files_root_event_outcome: sync.files_root_event_outcome,
        fips_download: sync.fips_download,
        fips_download_error: sync.fips_download_error,
        blossom_download: sync.blossom_download,
        blossom_download_error: sync.blossom_download_error,
        materialized_root_cid: sync.materialized_root_cid,
        blossom_servers: sync.blossom_servers,
      },
      profile: status.profile,
      drives: status.drives,
      listing,
      diagnostics,
    };
    if (JSON.stringify(files) === JSON.stringify(expectedFiles)) {
      for (const { fileName, content } of expected) {
        const output = path.join(configDir, 'interop-read');
        runIdriveJson(configDir, ['provider', 'read', fileName, output]);
        expect(fs.readFileSync(output)).toEqual(Buffer.from(content));
      }
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }

  throw new Error(`Native files did not converge:\n${JSON.stringify(last, null, 2)}`);
}

test.describe('Iris Drive web interop', () => {
  test.setTimeout(180000);

  test('native idrive publish is readable from drive web', async ({ page, relayUrl }) => {
    test.skip(!irisDriveAvailable(), 'iris-drive repo not available');

    const configDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-drive-native-web-'));
    const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-drive-native-work-'));
    const fileName = 'native-web.txt';
    const content = `native to web ${Date.now()}`;

    try {
      configureNativeBlossom(configDir);
      const init = runIdriveJson(configDir, ['init', '--label', 'native-e2e']);
      fs.writeFileSync(path.join(workDir, fileName), content);
      runIdriveJson(configDir, ['import', workDir]);
      const publish = runIdriveJson(configDir, ['publish', '--relay', relayUrl, '--timeout', '2']);
      expect(publish.published_files_root).toBe(true);
      expect(publish.drive_iris_to_url).toBe(`https://drive.iris.to/#/${init.profile_id}/main`);

      const identitySession = readNativeNostrIdentitySession(configDir);
      await prepareFreshPage(page, relayUrl, identitySession.appKeyNsec, identitySession);
      await expectTreeFile(page, init.profile_id, 'main', fileName, content);
    } finally {
      fs.rmSync(configDir, { recursive: true, force: true });
      fs.rmSync(workDir, { recursive: true, force: true });
    }
  });

  test('web publish is readable from a second web profile', async ({ page, browser, relayUrl }, testInfo) => {
    const owner = generateNsec();
    const fileName = 'web-web.txt';
    const content = `web to web ${Date.now()}`;
    const diagnostics: Record<string, unknown> = {};
    await observeInteropReads(page);

    await prepareFreshPage(page, relayUrl, owner.nsec);
    await navigateToPublicFolder(page, { timeoutMs: 60000 });
    await createFileWithContent(page, fileName, content);
    await flushPendingPublishes(page);
    await pushCurrentRootToBlossom(page, 'public');
    diagnostics.ownerAfterPush = await interopSnapshot(page, owner.npub, 'public');

    const context = await (browser as Browser).newContext();
    const viewer = await context.newPage();
    try {
      await observeInteropReads(viewer);
      await prepareFreshPage(viewer, relayUrl);
      await expectTreeFile(viewer, owner.npub, 'public', fileName, content);
    } finally {
      try {
        diagnostics.ownerFinal = await interopSnapshot(page, owner.npub, 'public').catch(error => ({ error: String(error) }));
        diagnostics.viewerFinal = await interopSnapshot(viewer, owner.npub, 'public').catch(error => ({ error: String(error) }));
        await testInfo.attach('cross-profile-read-path', { contentType: 'application/json', body: Buffer.from(JSON.stringify(diagnostics)) });
      } finally {
        await context.close();
      }
    }
  });

  test('drive web publish is readable from native idrive', async ({ page, relayUrl }) => {
    test.skip(!irisDriveAvailable(), 'iris-drive repo not available');

    const configDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-drive-web-native-'));
    const fileName = 'web-native.txt';
    const content = `web to native ${Date.now()}`;

    try {
      configureNativeBlossom(configDir);
      runIdriveJson(configDir, ['init', '--label', 'native-e2e']);
      const identitySession = readNativeNostrIdentitySession(configDir);
      await prepareFreshPage(page, relayUrl, identitySession.appKeyNsec, identitySession);
      await createPrivateDriveTree(page);
      const profileId = identitySession.profileId;
      await page.goto(`/#/${encodeURIComponent(profileId)}/main`);
      await waitForAppReady(page, 60000);
      await waitForRemoteTreeRoot(page, profileId, 'main');
      const secret = nip19.decode(identitySession.appKeyNsec);
      if (secret.type !== 'nsec') throw new Error('Expected native AppKey secret');
      const author = getPublicKey(secret.data);
      const rootsBefore = await fetchRelayDriveRootHashes(page, relayUrl, profileId, 'main');
      const previousSequence = Math.max(0, ...rootsBefore
        .filter((event) => event.pubkey === author)
        .map((event) => event.app_key_seq ?? 0));
      await addFileViaTreeAPI(page, [], fileName, content);
      await flushPendingPublishes(page);
      // Publication adds causal metadata to the visible tree. Check the signed
      // author advance, then let the native reader verify its durable file bytes.
      let relayRoots: RelayDriveRootDiagnostic[] = [];
      await expect.poll(async () => {
        relayRoots = await fetchRelayDriveRootHashes(page, relayUrl, profileId, 'main');
        return relayRoots.some((event) => event.pubkey === author
          && (event.app_key_seq ?? 0) > previousSequence
          && event.root_hash !== null
          && !rootsBefore.some((previous) => previous.root_hash === event.root_hash));
      }, { timeout: 30000, intervals: [500, 1000, 2000] }).toBe(true);

      await waitForNativeFiles(configDir, relayUrl, [
        { fileName, content },
      ], { previousSequence, relayRoots });
    } finally {
      fs.rmSync(configDir, { recursive: true, force: true });
    }
  });

});
