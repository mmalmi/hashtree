import { createNostrIdentitySignerFromSecretKey, createNostrIdentitySignerFromNip07, type NostrIdentityEventSigner } from '@iris/identity/signers'
import { setNostrSigner } from './nostr'
import { generateSecretKey, getPublicKey, nip19 } from 'nostr-tools'
import { writable, derived } from 'svelte/store'
import { saveLocalProfile, clearLocalProfile, getLocalProfile } from './profile'

// Helper functions
function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('')
}

function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2)
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16)
  }
  return bytes
}

export interface Identity {
  pubkey: string
  signer: NostrIdentityEventSigner
  displayName: string | null
  isNip07: boolean
}

const IDENTITY_STORAGE_KEY = 'iris-meet-identity'

export const identity = writable<Identity | null>(null)

export const isLoggedIn = derived(identity, $identity => $identity !== null)

export function parseNsecFromHash(): string | null {
  const hash = window.location.hash
  if (!hash || hash.length < 2) return null

  const nsec = hash.slice(1)
  if (!nsec.startsWith('nsec1')) return null

  try {
    const decoded = nip19.decode(nsec)
    if (decoded.type === 'nsec') {
      return bytesToHex(decoded.data as Uint8Array)
    }
  } catch {
    return null
  }
  return null
}

export function generateNewIdentity(): { privkey: string; pubkey: string; nsec: string } {
  const privkeyBytes = generateSecretKey()
  const privkey = bytesToHex(privkeyBytes)
  const pubkey = getPublicKey(privkeyBytes)
  const nsec = nip19.nsecEncode(privkeyBytes)
  return { privkey, pubkey, nsec }
}

export function loadStoredIdentity(): string | null {
  try {
    return localStorage.getItem(IDENTITY_STORAGE_KEY)
  } catch {
    return null
  }
}

export function saveIdentity(privkeyHex: string): void {
  try {
    localStorage.setItem(IDENTITY_STORAGE_KEY, privkeyHex)
  } catch {
    console.warn('Failed to save identity to localStorage')
  }
}

export function clearStoredIdentity(): void {
  try {
    localStorage.removeItem(IDENTITY_STORAGE_KEY)
  } catch {
    console.warn('Failed to clear identity from localStorage')
  }
}

export async function loginWithPrivkey(privkeyHex: string, displayName: string | null = null): Promise<void> {
  const signer = createNostrIdentitySignerFromSecretKey(hexToBytes(privkeyHex))
  const pubkey = await signer.getPublicKey()

  setNostrSigner(signer)

  identity.set({
    pubkey,
    signer,
    displayName,
    isNip07: false,
  })

  // Save local profile rumor for display in UI and sending to peers
  if (displayName) {
    saveLocalProfile(pubkey, displayName)
  }

  saveIdentity(privkeyHex)
}

export async function loginWithNip07(displayName: string | null = null): Promise<void> {
  if (!window.nostr) {
    throw new Error('No NIP-07 extension found')
  }

  const signer = createNostrIdentitySignerFromNip07(window.nostr)
  const pubkey = await signer.getPublicKey()

  setNostrSigner(signer)

  identity.set({
    pubkey,
    signer,
    displayName,
    isNip07: true,
  })

  // Save marker to remember NIP-07 login
  saveIdentity('nip07')
}

export async function autoLogin(displayName: string | null = null): Promise<boolean> {
  // Check for stored identity (user's own identity, NOT from URL hash)
  // URL hash contains meeting nsec, not user identity
  const storedValue = loadStoredIdentity()
  if (storedValue) {
    // Restore displayName from local profile if not provided
    if (!displayName) {
      const localProfile = getLocalProfile()
      displayName = localProfile?.display_name || localProfile?.name || null
    }

    if (storedValue === 'nip07') {
      // Try to re-authenticate with NIP-07 extension
      if (hasNip07()) {
        try {
          await loginWithNip07(displayName)
          return true
        } catch {
          // Extension may have been removed or user denied access
          clearStoredIdentity()
          return false
        }
      } else {
        // Extension no longer available
        clearStoredIdentity()
        return false
      }
    } else {
      // It's a privkey
      await loginWithPrivkey(storedValue, displayName)
      return true
    }
  }

  return false
}

export function logout(): void {
  setNostrSigner(undefined)
  identity.set(null)
  clearStoredIdentity()
  clearLocalProfile()
}

export function hasNip07(): boolean {
  return typeof window !== 'undefined' && !!window.nostr
}
