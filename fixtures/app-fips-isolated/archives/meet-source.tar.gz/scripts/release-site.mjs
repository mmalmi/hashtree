import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { resolveHtreeCommand } from './hashtreePaths.mjs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const appDir = path.resolve(__dirname, '..')
const distDir = path.join(appDir, 'dist')
const defaultWorkerCompatibilityDate = '2026-03-26'

/**
 * @typedef {{
 *   dryRun: boolean
 *   skipCloudflare: boolean
 *   pagesOnly: boolean
 *   treeName: string
 *   branch: string | undefined
 *   pagesProject: string | undefined
 *   workerName: string | undefined
 *   routes: string[]
 *   domains: string[]
 *   workerCompatibilityDate: string
 * }} ReleaseOptions
 * @typedef {{ id: string, label: string, command: string[], cwd: string }} ReleaseStep
 * @typedef {{ status: number, stdout: string, stderr: string }} StepResult
 * @typedef {{
 *   dryRun?: false
 *   publish: { nhash: string, publishedRef: string }
 *   pagesUrl: string | null
 *   pagesProject: string | null
 *   workerName: string | null
 *   routes: string[]
 *   domains: string[]
 *   treeName: string
 * }} ReleaseResult
 * @typedef {{ dryRun: true, steps: ReleaseStep[] }} DryRunResult
 */

const profile = {
  appName: 'Iris Meet',
  distDir: 'dist',
  treeName: 'meet',
  defaultWorkerName: 'iris-meet',
  defaultDomains: ['meet.iris.to'],
  workerScript: 'scripts/https-static-assets-worker.mjs',
}

/** @param {...string} args @returns {string[]} */
function wranglerPagesCommand(...args) {
  return ['npx', 'wrangler@4', ...args]
}

/** @param {...string} args @returns {string[]} */
function wranglerWorkerAssetsCommand(...args) {
  return ['npx', 'wrangler@4', 'deploy', ...args]
}

/** @param {ReleaseOptions} options @returns {string[]} */
function workerAssetsDeployCommand(options) {
  const workerName = options.workerName
  if (!workerName) throw new Error('Worker deployment requires a service name')
  if (profile.workerScript) {
    return [
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      profile.workerScript,
      '--assets',
      profile.distDir,
      '--name',
      workerName,
      '--compatibility-date',
      options.workerCompatibilityDate,
      '--wrangler-version',
      '4',
    ]
  }

  return wranglerWorkerAssetsCommand(
    '--assets',
    profile.distDir,
    '--name',
    workerName,
    '--compatibility-date',
    options.workerCompatibilityDate,
    '--keep-vars',
  )
}

/** @param {string[]} args @param {string} flag @returns {string} */
function takeArgValue(args, flag) {
  const value = args.shift()
  if (!value) throw new Error(`Missing value for ${flag}`)
  return value
}

/**
 * @param {string[]} argv
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {ReleaseOptions}
 */
export function parseArgs(argv, env = process.env) {
  const args = [...argv].filter((arg, index) => !(arg === '--' && index === 0))

  let pagesProject
  let workerName = env.CF_WORKER_NAME ?? profile.defaultWorkerName
  let treeName = profile.treeName
  let branch
  let dryRun = false
  let skipCloudflare = false
  let pagesOnly = false
  const routes = []
  const domains = []
  let workerCompatibilityDate = env.CF_WORKER_COMPATIBILITY_DATE ?? defaultWorkerCompatibilityDate

  while (args.length > 0) {
    const arg = args.shift()
    if (arg === '--') {
      continue
    }
    if (arg === '--pages-project') {
      pagesProject = takeArgValue(args, arg)
      continue
    }
    if (arg === '--worker-name') {
      workerName = takeArgValue(args, arg)
      continue
    }
    if (arg === '--tree') {
      treeName = takeArgValue(args, arg)
      continue
    }
    if (arg === '--route') {
      routes.push(takeArgValue(args, arg))
      continue
    }
    if (arg === '--domain') {
      domains.push(takeArgValue(args, arg))
      continue
    }
    if (arg === '--branch') {
      branch = takeArgValue(args, arg)
      continue
    }
    if (arg === '--compatibility-date') {
      workerCompatibilityDate = takeArgValue(args, arg)
      continue
    }
    if (arg === '--dry-run') {
      dryRun = true
      continue
    }
    if (arg === '--skip-cloudflare' || arg === '--skip-pages') {
      skipCloudflare = true
      continue
    }
    if (arg === '--pages-only') {
      pagesOnly = true
      continue
    }
    throw new Error(`Unknown argument: ${arg}`)
  }

  return {
    dryRun,
    skipCloudflare,
    pagesOnly,
    treeName,
    branch,
    pagesProject: pagesProject ?? env.CF_PAGES_PROJECT ?? undefined,
    workerName: pagesOnly ? undefined : workerName,
    routes,
    domains: pagesOnly ? [] : (domains.length > 0 ? domains : profile.defaultDomains),
    workerCompatibilityDate,
  }
}

/** @param {ReleaseOptions} options @returns {{ steps: ReleaseStep[] }} */
export function createReleasePlan(options) {
  if (!options.skipCloudflare && !options.workerName && !options.pagesProject) {
    throw new Error('Missing Cloudflare target. Pass --worker-name, --pages-project, or set CF_WORKER_NAME / CF_PAGES_PROJECT.')
  }
  if (options.workerName && options.branch) {
    throw new Error('--branch is only supported for Pages deployments')
  }

  const steps = [
    {
      id: 'install',
      label: `Install ${profile.appName} from frozen lockfile`,
      command: ['pnpm', 'install', '--frozen-lockfile'],
      cwd: appDir,
    },
    {
      id: 'build',
      label: `Build ${profile.appName}`,
      command: ['pnpm', 'run', 'build'],
      cwd: appDir,
    },
    {
      id: 'test-unit',
      label: `Test ${profile.appName} portable config`,
      command: ['pnpm', 'run', 'test'],
      cwd: appDir,
    },
    {
      id: 'test-smoke',
      label: `Smoke-test ${profile.appName} portable build`,
      command: ['pnpm', 'run', 'smoke:portable'],
      cwd: appDir,
    },
    { id: 'test-check', label: 'Check Iris Meet types', command: ['pnpm', 'run', 'check'], cwd: appDir },
    { id: 'test-calls', label: 'Test Iris Meet signaling and calls', command: ['pnpm', 'run', 'test:e2e'], cwd: appDir },
    { id: 'test-offline', label: 'Test Iris Meet offline session', command: ['pnpm', 'run', 'test:offline'], cwd: appDir },
    {
      id: 'publish',
      label: `Publish ${profile.appName} to hashtree`,
      command: resolveHtreeCommand('add', '.', '--publish', options.treeName),
      cwd: distDir,
    },
  ]

  if (!options.skipCloudflare) {
    let deployCommand
    if (options.workerName) {
      deployCommand = workerAssetsDeployCommand(options)
    } else {
      if (!options.pagesProject) throw new Error('Pages deployments require a project name')
      deployCommand = wranglerPagesCommand(
          'pages',
          'deploy',
          profile.distDir,
          '--project-name',
          options.pagesProject,
        )
    }

    if (options.workerName) {
      for (const route of options.routes) {
        deployCommand.push('--route', route)
      }
      for (const domain of options.domains) {
        deployCommand.push('--domain', domain)
      }
    }
    if (options.pagesProject && options.branch) {
      deployCommand.push('--branch', options.branch)
    }

    steps.push({
      id: 'deploy',
      label: options.workerName
        ? `Deploy ${profile.appName} to Cloudflare Worker`
        : `Deploy ${profile.appName} to Cloudflare Pages`,
      command: deployCommand,
      cwd: appDir,
    })
  }

  return { steps }
}

/** @param {ReleaseStep} step @returns {StepResult} */
function defaultRunner(step) {
  const [command, ...args] = step.command
  console.log(`\n==> ${step.label}`)
  console.log(`$ ${[command, ...args].join(' ')}`)
  const result = spawnSync(command, args, {
    cwd: step.cwd,
    encoding: 'utf8',
    stdio: 'pipe',
  })

  if (result.stdout) {
    process.stdout.write(result.stdout)
  }
  if (result.stderr) {
    process.stderr.write(result.stderr)
  }

  return {
    status: result.status ?? 1,
    stdout: result.stdout ?? '',
    stderr: result.stderr ?? '',
  }
}

function ensureDistExists() {
  if (!existsSync(distDir)) {
    throw new Error(`Build output directory not found: ${distDir}`)
  }
}

/** @param {string} output @returns {{ nhash: string, publishedRef: string }} */
export function parsePublishOutput(output) {
  const nhashMatch = output.match(/nhash1[ac-hj-np-z02-9]+/i)
  if (!nhashMatch) {
    throw new Error('Publish succeeded but no nhash was found in htree output')
  }

  const publishedMatch = output.match(/^\s*published:\s+(\S+)\s*$/im)
  if (!publishedMatch) {
    throw new Error('Publish succeeded but no mutable ref was found in htree output')
  }

  return {
    nhash: nhashMatch[0],
    publishedRef: publishedMatch[1],
  }
}

/** @param {string} output @returns {string | null} */
function parsePagesOutput(output) {
  const pagesUrlMatch = output.match(/https:\/\/[^\s]+\.pages\.dev(?:\/[^\s]*)?/i)
  return pagesUrlMatch ? pagesUrlMatch[0] : null
}

/**
 * @param {ReleaseOptions} options
 * @param {(step: ReleaseStep) => StepResult} [runner]
 * @returns {ReleaseResult | DryRunResult}
 */
export function runRelease(options, runner = defaultRunner) {
  const plan = createReleasePlan(options)

  if (options.dryRun) {
    return { dryRun: true, steps: plan.steps }
  }

  let publishOutput = ''
  let deployOutput = ''
  for (const step of plan.steps) {
    const result = runner(step)
    if (result.status !== 0) {
      throw new Error(`${step.label} failed with exit code ${result.status}`)
    }
    if (step.id === 'build') {
      ensureDistExists()
    }
    if (step.id === 'publish') {
      publishOutput = `${result.stdout}\n${result.stderr}`
    }
    if (step.id === 'deploy') {
      deployOutput = `${result.stdout}\n${result.stderr}`
    }
  }

  return {
    publish: parsePublishOutput(publishOutput),
    pagesUrl: deployOutput ? parsePagesOutput(deployOutput) : null,
    pagesProject: options.skipCloudflare || options.workerName ? null : options.pagesProject ?? null,
    workerName: options.skipCloudflare ? null : options.workerName ?? null,
    routes: options.skipCloudflare || !options.workerName ? [] : options.routes,
    domains: options.skipCloudflare || !options.workerName ? [] : options.domains,
    treeName: options.treeName,
  }
}

export function usage() {
  return `Usage: node ./scripts/release-site.mjs [options]

Build once, test the built output, publish to hashtree, then deploy that same
directory to Cloudflare Workers Static Assets or Cloudflare Pages.

Options:
  --worker-name <name>    Cloudflare Worker service name for static assets
  --pages-project <name>  Cloudflare Pages project name
  --tree <name>           hashtree mutable tree name override
  --route <pattern>       Worker route, for example meet.iris.to/*
  --domain <hostname>     Worker custom domain, for example meet.iris.to
  --branch <name>         Pages branch/preview deployment target
  --pages-only            disable the built-in/default Worker target and use Pages
  --compatibility-date    Worker compatibility date override
  --skip-cloudflare       publish to hashtree only
  --skip-pages            alias for --skip-cloudflare
  --dry-run               print planned steps without running them
`
}

/** @param {ReleaseResult} result */
function printSummary(result) {
  console.log(`\n${profile.appName} release complete.`)
  console.log(`Hashtree immutable URL: htree://${result.publish.nhash}/index.html`)
  console.log(`Hashtree mutable URL: htree://${result.publish.publishedRef}`)
  console.log(`Hashtree owner URL: htree://${result.publish.publishedRef}`)
  if (result.workerName) {
    console.log(`Worker service: ${result.workerName}`)
  }
  for (const route of result.routes) {
    console.log(`Worker route: ${route}`)
  }
  for (const domain of result.domains) {
    console.log(`Worker custom domain: ${domain}`)
  }
  if (result.pagesProject) {
    console.log(`Pages project: ${result.pagesProject}`)
  }
  if (result.pagesUrl) {
    console.log(`Pages deployment: ${result.pagesUrl}`)
  }
  console.log(`Tree name: ${result.treeName}`)
}

function isMainModule() {
  if (!process.argv[1]) {
    return false
  }
  return path.resolve(process.argv[1]) === __filename
}

if (isMainModule()) {
  try {
    const parsed = parseArgs(process.argv.slice(2))
    const result = runRelease(parsed)
    if (result.dryRun) {
      console.log(usage())
      for (const step of result.steps) {
        console.log(`${step.label}: ${step.command.join(' ')} (cwd: ${step.cwd})`)
      }
    } else {
      printSummary(result)
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error))
    process.exit(1)
  }
}
