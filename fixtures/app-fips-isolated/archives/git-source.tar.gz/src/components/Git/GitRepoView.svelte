<script lang="ts">
  import { LinkType, toHex, type CID, type TreeEntry, type TreeVisibility } from '@hashtree/core';
  import type { Readable } from 'svelte/store';
  import { SvelteURLSearchParams } from 'svelte/reactivity';
  import { getTree } from '../../store';
  import { routeStore } from '../../stores';
  import { createGitLogStore, createGitStatusStore } from '../../stores/git';
  import { createCIStatusStore, loadCIConfig, type CIStatus, type CIConfig } from '../../stores/ci';
  import { open as openGitHistoryModal } from '../Modals/GitHistoryModal.svelte';
  import { open as openGitCommitModal } from '../Modals/GitCommitModal.svelte';
  import FolderActions from '../FolderActions.svelte';
  import RepoTabNav from './RepoTabNav.svelte';
  import RepoHeader from './RepoHeader.svelte';
  import RepoSidebar from './RepoSidebar.svelte';
  import type { GitStatusResult } from '../../utils/wasmGit';
  import type { CommitInfo } from '../../stores/git';
  import { buildRepoTabHref } from '../../lib/gitRefNavigation';
  import { resolveGitRootPathParam, resolveGitViewContext, splitGitRootPath } from '../../utils/gitViewContext';
  import RepoBranchToolbar from './RepoBranchToolbar.svelte';
  import RepoContentPanel from './RepoContentPanel.svelte';

  interface Props {
    dirCid: CID;
    gitRootCid: CID | null;
    gitRootPath: string | null;
    loadGitMetadata?: boolean;
    entries: TreeEntry[];
    entriesLoading?: boolean;
    canEdit: boolean;
    currentBranch: string | null;
    branches: string[];
    tags: string[];
    tagsByCommit: Record<string, string[]>;
    gitBranchNamesLoading?: boolean;
    gitTagNamesLoading?: boolean;
    gitInfoLoading?: boolean;
    backUrl: string;
    displayPath?: string[];
    npub?: string | null;
    isPermalink?: boolean;
    rootCid?: CID | null;
    visibility?: TreeVisibility;
  }

  let {
    dirCid,
    gitRootCid,
    gitRootPath,
    loadGitMetadata = true,
    entries,
    entriesLoading = false,
    canEdit,
    currentBranch,
    branches,
    tags,
    tagsByCommit,
    gitBranchNamesLoading = false,
    gitTagNamesLoading = false,
    gitInfoLoading = false,
    backUrl,
    displayPath = undefined,
    npub = null,
    isPermalink = false,
    rootCid = null,
    visibility,
  }: Props = $props();

  let gitCid = $derived(loadGitMetadata ? (gitRootCid ?? dirCid) : null);

  let route = $derived($routeStore);
  let routePath = $derived(route.path);
  let currentPath = $derived(displayPath ?? routePath);
  let folderActionDirCid = $derived(gitRootCid ?? (currentPath.length === 0 ? dirCid : null));
  let gitRootPathParam = $derived(resolveGitRootPathParam(gitRootPath, currentPath));
  let gitRootParts = $derived(splitGitRootPath(gitRootPathParam) ?? []);
  let folderActionDirName = $derived.by(() => {
    if (gitRootCid) {
      return gitRootParts.at(-1) ?? route.treeName ?? 'repository';
    }
    return currentPath.at(-1) ?? route.treeName ?? 'repository';
  });
  let gitViewContext = $derived.by(() => resolveGitViewContext({
    treeName: route.treeName,
    gitRootPath,
    fallbackGitRootParts: gitRootPath === null ? currentPath : [],
    currentPath,
  }));

  let repoPath = $derived.by(() => {
    const gitPath = gitViewContext.rootParts;
    if (!route.treeName) return '';
    if (gitPath.length === 0) return route.treeName;
    return `${route.treeName}/${gitPath.join('/')}`;
  });

  let gitLogStore = $derived(createGitLogStore(gitCid, 1, repoPath));
  let commits = $state<CommitInfo[]>([]);
  let headOid = $state<string | null>(null);
  let commitsLoading = $state(true);

  let totalCommitCount = $state<number | null>(null);

  $effect(() => {
    const cid = gitCid;
    const metadataLoading = gitInfoLoading;
    totalCommitCount = null;
    if (!cid || metadataLoading) {
      return;
    }
    let cancelled = false;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;

    import('../../utils/wasmGit').then(({ getCommitCountFast }) => {
      const load = async (attempt = 0) => {
        if (cancelled) return;
        const count = await getCommitCountFast(cid).catch(() => 0);
        if (cancelled) return;
        if (count > 0) {
          totalCommitCount = count;
        } else if (attempt < 2) {
          retryTimer = setTimeout(() => void load(attempt + 1), 1500 * (attempt + 1));
        }
      };
      void load();
    });

    return () => {
      cancelled = true;
      clearTimeout(retryTimer);
    };
  });

  let latestCommit = $derived(commits.length > 0 ? commits[0] : null);

  let ciConfig = $state<CIConfig | null>(null);
  let ciStatus = $state<CIStatus | null>(null);
  let ciStatusStore = $state<Readable<CIStatus> | null>(null);

  $effect(() => {
    const store = gitLogStore;
    const unsub = store.subscribe(value => {
      commits = value.commits;
      headOid = value.headOid;
      commitsLoading = value.loading;
    });
    return unsub;
  });

  let switchingToRef = $state<string | null>(null);
  let switchingToRefTimer: ReturnType<typeof setTimeout> | null = null;
  const SWITCHING_REF_TIMEOUT_MS = 8000;

  let selectedTag = $derived.by(() => {
    if (currentBranch || !headOid) return null;
    const matchingTags = tagsByCommit[headOid] ?? [];
    return matchingTags[0] ?? null;
  });

  let branchDisplay = $derived(
    switchingToRef
    || currentBranch
    || (gitBranchNamesLoading ? 'loading' : (headOid ? headOid.slice(0, 7) : (loadGitMetadata ? 'detached' : 'loading')))
  );

  $effect(() => {
    if (switchingToRef && (currentBranch === switchingToRef || selectedTag === switchingToRef)) {
      switchingToRef = null;
      if (switchingToRefTimer) {
        clearTimeout(switchingToRefTimer);
        switchingToRefTimer = null;
      }
    }
  });

  let lastUrlRefApplied = $state<string | null>(null);
  $effect(() => {
    if (!loadGitMetadata) return;
    const targetRef = route.params.get('ref') || route.params.get('branch');
    const availableRefs = new Set([...branches, ...tags]);

    if (!targetRef || targetRef === currentBranch || targetRef === selectedTag || !availableRefs.has(targetRef)) {
      if (lastUrlRefApplied !== null && lastUrlRefApplied !== targetRef) {
        lastUrlRefApplied = null;
      }
      return;
    }

    if (switchingToRef) return;
    if (lastUrlRefApplied === targetRef) return;

    lastUrlRefApplied = targetRef;
    handleRefSelect(targetRef);
  });

  let gitSubpath = $derived.by(() => {
    const resolvedGitRootParts = gitRootPath !== null
      ? (gitRootPath === '' ? [] : gitRootPath.split('/'))
      : currentPath;

    if (gitRootPath === null) {
      return '';
    }

    if (currentPath.length <= resolvedGitRootParts.length) {
      return '';
    }

    return currentPath.slice(resolvedGitRootParts.length).join('/');
  });

  let gitStatusStore = $derived(canEdit && !gitInfoLoading ? createGitStatusStore(gitCid) : createGitStatusStore(null));
  let gitStatus = $state<GitStatusResult>({ staged: [], unstaged: [], untracked: [], hasChanges: false });
  let statusLoading = $state(true);

  let gitCidKey = $derived(
    gitCid
      ? `${toHex(gitCid.hash)}:${gitCid.key ? toHex(gitCid.key) : ''}`
      : null
  );
  let lastGitCidKey: string | null = null;

  $effect(() => {
    const store = gitStatusStore;

    if (lastGitCidKey !== gitCidKey) {
      gitStatus = { staged: [], unstaged: [], untracked: [], hasChanges: false };
      statusLoading = true;
      lastGitCidKey = gitCidKey;
    }

    const unsub = store.subscribe(value => {
      gitStatus = value.status;
      statusLoading = value.loading;
    });
    return unsub;
  });

  let totalChanges = $derived(
    gitStatus.staged.length +
    gitStatus.unstaged.length +
    gitStatus.untracked.length
  );

  function buildQueryString(): string {
    const params: string[] = [];
    if (route.params.get('k')) params.push(`k=${route.params.get('k')}`);
    params.push(`g=${encodeURIComponent(gitRootPathParam)}`);
    return params.length > 0 ? '?' + params.join('&') : '';
  }

  function buildEntryHref(entry: TreeEntry): string {
    const parts: string[] = [];
    const suffix = buildQueryString();

    if (route.npub && route.treeName) {
      parts.push(route.npub, route.treeName, ...currentPath, entry.name);
      return '#/' + parts.map(encodeURIComponent).join('/') + suffix;
    }

    parts.push(...currentPath, entry.name);
    return '#/' + parts.map(encodeURIComponent).join('/') + suffix;
  }

  function buildCommitHref(commitOid: string): string {
    const parts: string[] = [];
    const params = new SvelteURLSearchParams();

    params.set('commit', commitOid);
    if (route.params.get('k')) params.set('k', route.params.get('k')!);

    params.set('g', gitRootPathParam);

    if (route.npub && route.treeName) {
      parts.push(route.npub, route.treeName, ...currentPath);
    }
    const basePath = '#/' + parts.map(encodeURIComponent).join('/');
    return `${basePath}?${params.toString()}`;
  }

  function openHistory() {
    if (!gitCid) return;
    openGitHistoryModal({
      dirCid: gitCid,
      canEdit,
      onCheckout: canEdit ? handleCheckout : undefined,
      repoPath,
      gitRootPath: gitRootPathParam,
    });
  }

  function openCommit() {
    if (!gitCid) return;
    openGitCommitModal({ dirCid: gitCid, onCommit: handleCommit });
  }

  let branchesHref = $derived.by(() => {
    if (!route.npub || !repoPath) return null;
    return buildRepoTabHref(route.npub, repoPath, 'branches', route.params.get('k') ?? undefined);
  });

  let tagsHref = $derived.by(() => {
    if (!route.npub || !repoPath) return null;
    return buildRepoTabHref(route.npub, repoPath, 'tags', route.params.get('k') ?? undefined);
  });

  let parentHref = $derived.by(() => {
    if (currentPath.length === 0) return null;
    const parts: string[] = [];
    const parentPath = currentPath.slice(0, -1);
    const suffix = buildQueryString();

    if (route.npub && route.treeName) {
      parts.push(route.npub, route.treeName, ...parentPath);
      return '#/' + parts.map(encodeURIComponent).join('/') + suffix;
    }

    parts.push(...parentPath);
    return '#/' + parts.map(encodeURIComponent).join('/') + suffix;
  });

  let repoHeaderPathSegments = $derived.by(() => {
    const relativePathParts = gitViewContext.relativePathParts;
    const suffix = buildQueryString();

    return relativePathParts.map((part, index) => {
      const isCurrentSegment = index === relativePathParts.length - 1;
      const visiblePath = [...gitViewContext.rootParts, ...relativePathParts.slice(0, index + 1)];
      const parts: string[] = [];

      if (!isCurrentSegment) {
        if (route.npub && route.treeName) {
          parts.push(route.npub, route.treeName, ...visiblePath);
        } else {
          parts.push(...visiblePath);
        }
      }

      return {
        label: part,
        href: isCurrentSegment ? undefined : '#/' + parts.map(encodeURIComponent).join('/') + suffix,
      };
    });
  });

  $effect(() => {
    ciConfig = null;
    const cid = gitCid;
    if (!cid) return;
    let cancelled = false;
    loadCIConfig(cid).then(result => {
      if (!cancelled) ciConfig = result;
    }).catch(() => {
      if (!cancelled) ciConfig = null;
    });
    return () => {
      cancelled = true;
    };
  });

  $effect(() => {
    ciStatus = null;
    ciStatusStore = null;
    const commit = headOid ?? latestCommit?.oid ?? null;
    const path = repoPath;
    if (!ciConfig || !commit || !path) return;
    if (!ciConfig.runners || ciConfig.runners.length === 0) return;
    const store = createCIStatusStore(path, commit, ciConfig.runners);
    ciStatusStore = store;
    const unsub = store.subscribe(value => {
      ciStatus = value;
    });
    return () => {
      ciStatusStore = null;
      unsub();
    };
  });

  async function handleRefSelect(ref: string) {
    if (!gitCid) return;
    if (ref === currentBranch || ref === selectedTag || switchingToRef) return;

    switchingToRef = ref;
    if (switchingToRefTimer) clearTimeout(switchingToRefTimer);
    switchingToRefTimer = setTimeout(() => {
      if (switchingToRef === ref) {
        console.warn('[GitRepoView] switchingToRef timeout, clearing', ref);
        switchingToRef = null;
      }
      switchingToRefTimer = null;
    }, SWITCHING_REF_TIMEOUT_MS);

    try {
      const { checkoutCommit } = await import('../../utils/git');
      const { autosaveIfOwn } = await import('../../nostr');
      const { getCurrentRootCid } = await import('../../actions/route');

      const treeRootCid = getCurrentRootCid();
      if (!treeRootCid) return;

      const newDirCid = await checkoutCommit(gitCid, ref);

      const gitPath = gitRootParts;

      let newRootCid;
      if (gitPath.length === 0) {
        newRootCid = newDirCid;
      } else {
        const tree = getTree();
        const parentPath = gitPath.slice(0, -1);
        const dirName = gitPath[gitPath.length - 1];
        newRootCid = await tree.setEntry(
          treeRootCid,
          parentPath,
          dirName,
          newDirCid,
          0,
          LinkType.Dir
        );
      }

      autosaveIfOwn(newRootCid);
    } catch (err) {
      console.error('Failed to switch ref:', err);
      switchingToRef = null;
      if (switchingToRefTimer) {
        clearTimeout(switchingToRefTimer);
        switchingToRefTimer = null;
      }
    }
  }

  function getGitPath(): string[] {
    return gitRootParts;
  }

  async function handleCommit(newDirCid: CID): Promise<void> {
    if (!gitCid) return;
    const { autosaveIfOwn } = await import('../../nostr');
    const { getCurrentRootCid } = await import('../../actions/route');

    const treeRootCid = getCurrentRootCid();
    if (!treeRootCid) return;

    const gitPath = getGitPath();
    let newRootCid;
    if (gitPath.length === 0) {
      newRootCid = newDirCid;
    } else {
      const tree = getTree();
      const parentPath = gitPath.slice(0, -1);
      const dirName = gitPath[gitPath.length - 1];
      newRootCid = await tree.setEntry(
        treeRootCid,
        parentPath,
        dirName,
        newDirCid,
        0,
        LinkType.Dir
      );
    }

    autosaveIfOwn(newRootCid);
  }

  async function handleCheckout(commitSha: string): Promise<void> {
    if (!gitCid) return;
    const { checkoutCommit } = await import('../../utils/git');
    const { autosaveIfOwn } = await import('../../nostr');
    const { getCurrentRootCid } = await import('../../actions/route');

    const treeRootCid = getCurrentRootCid();
    if (!treeRootCid) return;

    const newDirCid = await checkoutCommit(gitCid, commitSha);

    const gitPath = getGitPath();
    let newRootCid;
    if (gitPath.length === 0) {
      newRootCid = newDirCid;
    } else {
      const tree = getTree();
      const parentPath = gitPath.slice(0, -1);
      const dirName = gitPath[gitPath.length - 1];
      newRootCid = await tree.setEntry(
        treeRootCid,
        parentPath,
        dirName,
        newDirCid,
        0,
        LinkType.Dir
      );
    }

    autosaveIfOwn(newRootCid);
  }

</script>

{#if route.npub && route.treeName}
  <RepoTabNav npub={route.npub} repoName={repoPath} activeTab="code" showReleasesTab={true} />
{/if}

<div class="mx-auto flex w-full max-w-7xl flex-col gap-4 p-3">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <RepoHeader
      {backUrl}
      repoName={repoPath}
      {npub}
      {visibility}
      {isPermalink}
      {rootCid}
      pathSegments={repoHeaderPathSegments}
    />

    <div class="flex max-w-full min-w-0 items-center justify-end max-sm:w-full max-sm:justify-start">
      <FolderActions dirCid={folderActionDirCid} dirName={folderActionDirName} {canEdit} />
    </div>
  </div>

  <div class="flex flex-col gap-4 lg:flex-row lg:items-start">
    <div class="min-w-0 flex-1 flex flex-col gap-4" data-testid="repo-main-column">
      <RepoBranchToolbar
        {gitCid}
        {branches}
        {currentBranch}
        {branchDisplay}
        {canEdit}
        ownerNpub={route.npub}
        {repoPath}
        {gitBranchNamesLoading}
        {gitTagNamesLoading}
        {switchingToRef}
        {branchesHref}
        {tagsHref}
        {tags}
        {statusLoading}
        {totalChanges}
        {totalCommitCount}
        {visibility}
        linkKey={route.params.get('k')}
        onRefSelect={handleRefSelect}
        onCommit={openCommit}
        onHistory={openHistory}
      />

      <RepoContentPanel
        {gitCid}
        {gitSubpath}
        {entries}
        {entriesLoading}
        loadFileHistory={!gitInfoLoading}
        {buildEntryHref}
        {buildCommitHref}
        {latestCommit}
        latestCommitTags={latestCommit ? (tagsByCommit[latestCommit.oid] ?? []) : []}
        commitsLoading={!loadGitMetadata || commitsLoading}
        {parentHref}
        {ciStatus}
        {ciStatusStore}
        {repoPath}
        {ciConfig}
        {canEdit}
      />
    </div>

    {#if route.npub && repoPath}
      <RepoSidebar npub={route.npub} repoName={repoPath} repoCid={gitCid} />
    {/if}
  </div>
</div>
