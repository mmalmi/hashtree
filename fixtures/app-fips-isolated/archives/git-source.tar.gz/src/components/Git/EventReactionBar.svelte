<script lang="ts">
  import { nostrStore } from '../../nostr';
  import {
    DEFAULT_EVENT_REACTION_EMOJIS,
    type EventReactionSummary,
  } from '../../lib/eventReactions';
  import {
    createEventReactionsStore,
    type EventReactionsState,
  } from '../../stores/eventReactions';
  import Dropdown from '../ui/Dropdown.svelte';

  interface Props {
    targetEventId: string;
    targetKind: number;
    targetAuthorPubkey: string;
    compact?: boolean;
    className?: string;
  }

  let {
    targetEventId,
    targetKind,
    targetAuthorPubkey,
    compact = false,
    className = '',
  }: Props = $props();

  let currentUserPubkey = $derived($nostrStore.pubkey);
  let canReact = $derived(!!currentUserPubkey);
  let reactionsStore = $derived(createEventReactionsStore(targetEventId, targetKind, targetAuthorPubkey));
  let reactionsState = $state<EventReactionsState>({
    items: [],
    loading: true,
    error: null,
    pendingEmoji: null,
  });
  let pickerOpen = $state(false);

  $effect(() => {
    const store = reactionsStore;
    const unsub = store.subscribe((value) => {
      reactionsState = value;
    });

    return () => {
      unsub();
      store.destroy();
    };
  });

  let showBar = $derived(reactionsState.items.length > 0 || canReact);

  function userReacted(summary: EventReactionSummary): boolean {
    return !!currentUserPubkey && summary.reactorPubkeys.includes(currentUserPubkey);
  }

  async function toggleReaction(emoji: string) {
    pickerOpen = false;
    await reactionsStore.toggleReaction(emoji);
  }
</script>

{#if showBar}
  <div class={`flex flex-wrap items-center gap-2 ${className}`.trim()}>
    {#each reactionsState.items as reaction (reaction.emoji)}
      <button
        onclick={() => canReact && toggleReaction(reaction.emoji)}
        disabled={!canReact || reactionsState.pendingEmoji !== null}
        class="inline-flex items-center gap-1 rounded-full border px-2 py-1 text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-60 {
          userReacted(reaction)
            ? 'border-accent/40 bg-accent/12 text-accent'
            : 'border-surface-3 bg-surface-1 text-text-2 hover:border-surface-4 hover:bg-surface-2 hover:text-text-1'
        } {compact ? 'text-xs' : ''}"
        title={userReacted(reaction) ? `Remove ${reaction.emoji} reaction` : `React with ${reaction.emoji}`}
        aria-label={`${reaction.emoji} reaction (${reaction.count})`}
      >
        <span>{reaction.emoji}</span>
        <span class="font-medium">{reaction.count}</span>
      </button>
    {/each}

    {#if canReact}
      <Dropdown bind:open={pickerOpen} onClose={() => pickerOpen = false} align="left">
        {#snippet trigger()}
          <button
            onclick={() => pickerOpen = !pickerOpen}
            disabled={reactionsState.pendingEmoji !== null}
            class="inline-flex items-center gap-1 rounded-full border border-surface-3 bg-surface-1 px-2 py-1 text-sm text-text-2 transition-colors hover:border-surface-4 hover:bg-surface-2 hover:text-text-1 disabled:cursor-not-allowed disabled:opacity-60 {compact ? 'text-xs' : ''}"
            title="Add reaction"
            aria-label="Add reaction"
          >
            <span>🙂</span>
            <span class="i-lucide-plus text-xs"></span>
          </button>
        {/snippet}

        <div class="grid grid-cols-4 gap-1 rounded-lg border border-surface-3 bg-surface-1 p-2">
          {#each DEFAULT_EVENT_REACTION_EMOJIS as emoji (emoji)}
            <button
              onclick={() => toggleReaction(emoji)}
              class="flex h-10 w-10 items-center justify-center rounded-md bg-surface-2 text-lg transition-colors hover:bg-surface-3 {userReacted({ emoji, count: 0, reactorPubkeys: reactionsState.items.find(item => item.emoji === emoji)?.reactorPubkeys || [] }) ? 'ring-1 ring-accent/50' : ''}"
              title={`React with ${emoji}`}
              aria-label={`React with ${emoji}`}
            >
              {emoji}
            </button>
          {/each}
        </div>
      </Dropdown>
    {/if}
  </div>

  {#if reactionsState.error}
    <div class="mt-2 text-xs text-danger">{reactionsState.error}</div>
  {/if}
{/if}
