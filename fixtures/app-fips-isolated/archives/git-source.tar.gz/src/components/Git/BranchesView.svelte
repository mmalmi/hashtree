<script lang="ts">
  import { currentDirCidStore, createTreesStore, routeStore, treeRootStore, type TreeEntry } from '../../stores';
  import { createGitInfoStore, type GitInfo } from '../../stores/git';
  import RepoChildLayout from './RepoChildLayout.svelte';
  import { buildRepoCodeHref } from '../../lib/gitRefNavigation';

  interface Props {
    npub: string;
    repoName: string;
  }

  const emptyGitInfo: GitInfo = {
    isRepo: false,
    currentBranch: null,
    branches: [],
    tags: [],
    tagsByCommit: {},
    branchNamesLoading: true,
    tagNamesLoading: true,
    loading: true,
  };

  let { npub, repoName }: Props = $props();

  let route = $derived($routeStore);
  let rootCid = $derived($treeRootStore);
  let dirCid = $derived($currentDirCidStore);
  let linkKey = $derived(route.params.get('k') ?? undefined);

  let gitInfoStore = $derived(dirCid ? createGitInfoStore(dirCid, repoName, { retryRepoDetection: true }) : null);
  let gitInfo = $state<GitInfo>(emptyGitInfo);

  $effect(() => {
    const store = gitInfoStore;
    if (!store) {
      gitInfo = emptyGitInfo;
      return;
    }

    const unsub = store.subscribe((value) => {
      gitInfo = value;
    });

    return unsub;
  });

  let treesStore = $derived(createTreesStore(npub));
  let trees = $state<TreeEntry[]>([]);

  $effect(() => {
    const store = treesStore;
    const unsub = store.subscribe((value) => {
      trees = value;
    });
    return unsub;
  });

  let baseTreeName = $derived(repoName.split('/')[0]);
  let currentTree = $derived(trees.find((tree) => tree.name === baseTreeName));
  let backUrl = $derived(buildRepoCodeHref(npub, repoName, { linkKey }));

  function getBrowseHref(branch: string): string {
    if (branch === gitInfo.currentBranch) {
      return backUrl;
    }
    return buildRepoCodeHref(npub, repoName, { ref: branch, linkKey });
  }
</script>

<RepoChildLayout
  {backUrl}
  {npub}
  {repoName}
  {rootCid}
  activeTab="code"
  contentMaxWidthClass="max-w-5xl"
  sectionLabel="Branches"
  visibility={currentTree?.visibility}
>
  <div class="mx-3 mb-4 flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg b-1 b-solid b-surface-3 bg-surface-0">
    <div class="flex items-center justify-between px-4 py-3 bg-surface-1 b-b-1 b-b-solid b-b-surface-3">
      <div class="text-sm text-text-3">
        {gitInfo.branches.length} branch{gitInfo.branches.length !== 1 ? 'es' : ''}
      </div>
    </div>

    <div class="flex-1 overflow-auto">
      {#if gitInfo.branchNamesLoading}
        <div class="flex items-center justify-center py-12 text-text-3">
          <span class="i-lucide-loader-2 animate-spin mr-2"></span>
          Loading branches...
        </div>
      {:else if gitInfo.branches.length === 0}
        <div class="flex flex-col items-center justify-center py-12 text-text-3">
          <span class="i-lucide-git-branch text-4xl mb-4 opacity-50"></span>
          <span class="text-lg mb-2">No branches found</span>
          <span class="text-sm">This repository has not published any branch refs yet.</span>
        </div>
      {:else}
        <div class="divide-y divide-surface-3">
          {#each gitInfo.branches as branch (branch)}
            <div class="px-4 py-3 flex items-center gap-3 transition-colors hover:bg-surface-1">
              <div class="text-text-3">
                <span class="i-lucide-git-branch"></span>
              </div>
              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-2 flex-wrap">
                  <span class="font-medium text-text-1 break-all">{branch}</span>
                  {#if branch === gitInfo.currentBranch}
                    <span class="px-2 py-0.5 text-xs rounded-full bg-accent/10 text-accent">Current</span>
                  {/if}
                </div>
              </div>
              <a
                href={getBrowseHref(branch)}
                class="btn-ghost shrink-0 h-8 px-3 text-sm no-underline"
              >
                Browse files
              </a>
            </div>
          {/each}
        </div>
      {/if}
    </div>
  </div>
</RepoChildLayout>
