<script lang="ts">
  /**
   * ReleaseDetailView - Shows a single release with notes and assets.
   * Layout matches TreeRoute: FileBrowser on left, content on right.
   */
  import { routeStore, createTreesStore, type TreeEntry } from '../../stores';
  import { nostrStore } from '../../nostr';
  import {
    createReleaseDetailStore,
    deleteRelease,
    buildReleaseTreeName,
    getReleaseAssetDownloadUrl,
    isPubliclyVisibleRelease,
    resolveReleaseAssetMarkdownLink,
    type ReleaseAsset,
  } from '../../stores/releases';
  import { formatBytes } from '../../store';
  import { open as openReleaseModal } from './ReleaseModal.svelte';
  import RepoChildLayout from './RepoChildLayout.svelte';
  import MarkdownViewer from '../Viewer/MarkdownViewer.svelte';

  interface Props {
    npub: string;
    repoName: string;
    releaseId: string;
  }

  let { npub, repoName, releaseId }: Props = $props();

  let route = $derived($routeStore);

  let treesStore = $derived(createTreesStore(npub));
  let trees = $state<TreeEntry[]>([]);

  $effect(() => {
    const store = treesStore;
    const unsub = store.subscribe(value => {
      trees = value;
    });
    return unsub;
  });

  let baseTreeName = $derived(repoName.split('/')[0]);
  let currentTree = $derived(trees.find(t => t.name === baseTreeName));

  let releaseTreeName = $derived(buildReleaseTreeName(repoName));
  let releaseTree = $derived(trees.find(t => t.name === releaseTreeName));
  let releaseVisibility = $derived(releaseTree?.visibility ?? currentTree?.visibility ?? 'public');
  let releaseLinkKey = $derived(releaseTree?.linkKey ?? currentTree?.linkKey ?? route.params.get('k') ?? undefined);

  let isOwner = $derived($nostrStore.npub === npub);
  let releaseDetailStore = $derived(createReleaseDetailStore(npub, repoName, releaseId));
  let releaseState = $derived($releaseDetailStore);
  let loading = $derived(releaseState.loading);
  let release = $derived(
    releaseState.item && (isPubliclyVisibleRelease(releaseState.item) || isOwner)
      ? releaseState.item
      : null
  );
  let error = $derived(
    releaseState.item?.draft && !releaseState.item.draftPointer && !isOwner
      ? 'Release not found'
      : releaseState.error
  );

  function getBackHref(): string {
    const linkKeySuffix = route.params.get('k') ? `?k=${route.params.get('k')}&tab=releases` : '?tab=releases';
    return `#/${npub}/${repoName}${linkKeySuffix}`;
  }

  function formatDate(timestamp: number | undefined): string {
    if (!timestamp) return 'unknown';
    return new Date(timestamp * 1000).toLocaleString();
  }

  function getAssetDownloadHref(asset: ReleaseAsset): string {
    if (!release) return '#';
    return getReleaseAssetDownloadUrl(
      npub,
      repoName,
      release.entryPath ?? release.id,
      asset.path,
      releaseLinkKey,
      asset.cid,
      asset.name,
    );
  }

  function getReleaseNoteLinkHref(href: string): string | null {
    if (!release) return null;
    const asset = resolveReleaseAssetMarkdownLink(href, release.assets);
    return asset ? getAssetDownloadHref(asset) : null;
  }

  async function handleDelete() {
    if (!release) return;
    if (releaseVisibility === 'link-visible' && !releaseLinkKey) {
      alert('Link key missing. Open the repo with the shared link to delete this release.');
      return;
    }
    const confirmed = window.confirm(`Delete release "${release.title}"? This cannot be undone.`);
    if (!confirmed) return;

    const success = await deleteRelease(
      npub,
      repoName,
      release.entryPath ?? release.id,
      releaseVisibility as 'public' | 'link-visible' | 'private',
      releaseLinkKey ?? undefined
    );

    if (success) {
      window.location.hash = getBackHref();
    } else {
      alert('Failed to delete release');
    }
  }

  function handleEdit() {
    if (!release) return;
    openReleaseModal({
      npub,
      repoName,
      visibility: releaseVisibility as 'public' | 'link-visible' | 'private',
      linkKey: releaseLinkKey ?? undefined,
      release,
      onSave: () => releaseDetailStore.refresh(),
    });
  }
</script>

<!-- Right panel with release detail - shown on mobile -->
<RepoChildLayout
  backUrl={getBackHref()}
  {npub}
  {repoName}
  contentMaxWidthClass="max-w-5xl"
  sectionHref={getBackHref()}
  sectionLabel="Releases"
  showTabNav={false}
  visibility={currentTree?.visibility}
>
  <div class="mx-3 mb-4 flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg b-1 b-solid b-surface-3 bg-surface-0">
    <div class="flex-1 overflow-auto">
      {#if loading}
        <div class="flex items-center justify-center py-12 text-text-3">
          <span class="i-lucide-loader-2 animate-spin mr-2"></span>
          Loading release...
        </div>
      {:else if error}
        <div class="flex flex-col items-center justify-center py-12 text-danger">
          <span class="i-lucide-alert-circle text-2xl mb-2"></span>
          <span>{error}</span>
          <button onclick={() => releaseDetailStore.refresh()} class="btn-ghost mt-4">
            Try again
          </button>
          <a href={getBackHref()} class="btn-ghost mt-4">
            <span class="i-lucide-arrow-left mr-2"></span>
            Back to releases
          </a>
        </div>
      {:else if release}
        <div class="p-4 b-b-1 b-b-solid b-b-surface-3">
          <div class="flex items-start gap-3">
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2 mb-2 flex-wrap">
                <h1 class="text-xl font-semibold text-text-1">{release.title}</h1>
                {#if release.latest}
                  <span class="px-2 py-0.5 text-xs rounded-full bg-success/15 text-success">Latest</span>
                {/if}
                {#if release.draft || release.unpromoted}
                  <span class="px-2 py-0.5 text-xs rounded-full bg-warning/10 text-warning">Draft</span>
                {/if}
                {#if release.prerelease}
                  <span class="px-2 py-0.5 text-xs rounded-full bg-accent/10 text-accent">Pre-release</span>
                {/if}
              </div>
              <div class="text-sm text-text-3 flex items-center gap-2 flex-wrap">
                {#if release.tag}
                  <span class="font-mono text-xs bg-surface-2 px-1 rounded">{release.tag}</span>
                {/if}
                <span>published {formatDate(release.published_at ?? release.created_at)}</span>
                {#if release.commit}
                  <span class="font-mono text-xs bg-surface-2 px-1 rounded">{release.commit.slice(0, 7)}</span>
                {/if}
              </div>
            </div>

            {#if isOwner}
              <div class="flex gap-2">
                <button onclick={handleEdit} class="btn-ghost text-sm">
                  <span class="i-lucide-pencil mr-1"></span>
                  Edit
                </button>
                <button onclick={handleDelete} class="btn-ghost text-sm text-danger">
                  <span class="i-lucide-trash-2 mr-1"></span>
                  Delete
                </button>
              </div>
            {/if}
          </div>
        </div>

        <div class="p-4 b-b-1 b-b-solid b-b-surface-3">
          {#if release.notes}
            <MarkdownViewer
              content={release.notes}
              padded={false}
              contentClass="prose prose-sm max-w-none text-text-2"
              resolveLinkHref={getReleaseNoteLinkHref}
            />
          {:else}
            <div class="text-text-3 text-sm">No release notes provided.</div>
          {/if}
        </div>

        <div class="p-4">
          <h2 class="text-sm font-medium text-text-2 mb-3">
            Assets {release.assets.length > 0 ? `(${release.assets.length})` : ''}
          </h2>
          {#if release.assets.length > 0}
            <div class="flex flex-col gap-2">
              {#each release.assets as asset (asset.name)}
                <a
                  href={getAssetDownloadHref(asset)}
                  class="flex items-center justify-between bg-surface-1 rounded-md px-3 py-2 text-sm text-text-1 hover:text-accent"
                  download
                >
                  <span class="truncate">{asset.name}</span>
                  <span class="text-text-3 text-xs">{formatBytes(asset.size)}</span>
                </a>
              {/each}
            </div>
          {:else}
            <div class="text-text-3 text-sm">No assets uploaded.</div>
          {/if}
        </div>
      {/if}
    </div>
  </div>
</RepoChildLayout>
