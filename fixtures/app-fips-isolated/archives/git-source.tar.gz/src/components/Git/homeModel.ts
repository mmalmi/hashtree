import type { TreeEntry } from '../../stores';
import type { FollowedRepoAnnouncement } from '../../stores/gitRepoDiscovery';
import type { FavoriteRepoRef } from '../../lib/gitFavorites';

export interface GitHomeRepo extends TreeEntry {
  labelSet: Set<string>;
}

export interface GitHomeFavoriteRepoCard {
  key: string;
  href: string;
  name: string;
  ownerPubkey?: string;
  metaLabel: string;
  accentIcon: 'bookmark' | 'heart';
  updatedAt?: number;
  external?: boolean;
}

export function buildGitHomeRepos(trees: TreeEntry[]): GitHomeRepo[] {
  return trees
    .filter(tree => (tree.labels ?? []).includes('git'))
    .sort((a, b) => {
      const createdAtDiff = (b.createdAt ?? 0) - (a.createdAt ?? 0);
      if (createdAtDiff !== 0) {
        return createdAtDiff;
      }
      return a.name.localeCompare(b.name);
    })
    .map(tree => ({
      ...tree,
      labelSet: new Set(tree.labels ?? []),
    }));
}

export function buildGitHomeFavoriteRepoCards(
  favorites: FavoriteRepoRef[],
): GitHomeFavoriteRepoCard[] {
  return favorites.map(repo => ({
    key: repo.address,
    href: repo.href,
    name: repo.repoName,
    ownerPubkey: repo.ownerPubkey,
    metaLabel: 'Liked repository',
    accentIcon: 'heart',
  }));
}

export function buildGitHomeDiscoveredRepoCards(
  repos: FollowedRepoAnnouncement[],
): GitHomeFavoriteRepoCard[] {
  return repos.map(repo => ({
    key: repo.address,
    href: repo.href,
    name: repo.repoName,
    ownerPubkey: repo.ownerPubkey,
    metaLabel: 'Updated repository',
    accentIcon: 'bookmark',
    updatedAt: repo.updatedAt,
    external: repo.external,
  }));
}
