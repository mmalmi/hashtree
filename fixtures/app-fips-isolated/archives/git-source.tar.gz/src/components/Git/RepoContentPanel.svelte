<script lang="ts">
  import { LinkType, type CID, type TreeEntry } from '@hashtree/core';
  import type { Readable } from 'svelte/store';
  import { decodeAsText, getTree } from '../../store';
  import type { CIConfig, CIStatus } from '../../stores/ci';
  import type { CommitInfo } from '../../stores/git';
  import { getFileLastCommits } from '../../utils/git';
  import FileTable from './FileTable.svelte';
  import ReadmePanel from '../Viewer/ReadmePanel.svelte';

  const PRIORITY_FILE_COMMIT_COUNT = 24;

  interface FileCommitInfo {
    oid: string;
    message: string;
    timestamp: number;
  }

  interface Props {
    gitCid: CID | null;
    gitSubpath: string;
    entries: TreeEntry[];
    entriesLoading: boolean;
    loadFileHistory: boolean;
    buildEntryHref: (entry: TreeEntry) => string;
    buildCommitHref: (commitOid: string) => string;
    latestCommit: CommitInfo | null;
    latestCommitTags: string[];
    commitsLoading: boolean;
    parentHref: string | null;
    ciStatus: CIStatus | null;
    ciStatusStore: Readable<CIStatus> | null;
    repoPath: string;
    ciConfig: CIConfig | null;
    canEdit: boolean;
  }

  let {
    gitCid,
    gitSubpath,
    entries,
    entriesLoading,
    loadFileHistory,
    buildEntryHref,
    buildCommitHref,
    latestCommit,
    latestCommitTags,
    commitsLoading,
    parentHref,
    ciStatus,
    ciStatusStore,
    repoPath,
    ciConfig,
    canEdit,
  }: Props = $props();

  let fileCommits = $state<Map<string, FileCommitInfo>>(new Map());
  let prioritizedEntryNames = $derived.by(() => {
    const sorted = [...entries].sort((a, b) => {
      const aIsDir = a.type === LinkType.Dir;
      const bIsDir = b.type === LinkType.Dir;
      if (aIsDir && !bIsDir) return -1;
      if (!aIsDir && bIsDir) return 1;
      return a.name.localeCompare(b.name);
    });
    return sorted.filter((entry) => entry.name !== '.git').map((entry) => entry.name);
  });

  $effect(() => {
    const cid = gitCid;
    const filenames = prioritizedEntryNames;
    const subpath = gitSubpath;
    const canLoadHistory = loadFileHistory;

    if (!cid || filenames.length === 0 || !canLoadHistory) {
      fileCommits = new Map();
      return;
    }

    let cancelled = false;
    let loadedFileCommits = new Map<string, FileCommitInfo>();
    fileCommits = loadedFileCommits;
    const priorityFilenames = filenames.slice(0, PRIORITY_FILE_COMMIT_COUNT);

    const mergeFileCommit = (filename: string, commitInfo: FileCommitInfo) => {
      const existing = loadedFileCommits.get(filename);
      const isSameCommit = existing
        && existing.oid === commitInfo.oid
        && existing.message === commitInfo.message
        && existing.timestamp === commitInfo.timestamp;
      if (isSameCommit) return;
      // eslint-disable-next-line svelte/prefer-svelte-reactivity -- replace the Map instance so row updates propagate
      const next = new Map(loadedFileCommits);
      next.set(filename, commitInfo);
      loadedFileCommits = next;
      fileCommits = next;
    };

    const loadBatch = async (batchFilenames: string[]) => {
      if (batchFilenames.length === 0) return;
      const result = await getFileLastCommits(
        cid,
        batchFilenames,
        subpath || undefined,
        (filename, commitInfo) => {
          if (!cancelled) mergeFileCommit(filename, commitInfo);
        },
      );

      if (cancelled) return;
      for (const [filename, commitInfo] of result) {
        mergeFileCommit(filename, commitInfo);
      }
    };

    void (async () => {
      await loadBatch(filenames);
      if (cancelled) return;
      const missingPriorityFilenames = priorityFilenames.filter((filename) => !loadedFileCommits.has(filename));
      if (missingPriorityFilenames.length > 0) {
        await loadBatch(missingPriorityFilenames);
      }
    })().catch(() => {});

    return () => {
      cancelled = true;
    };
  });

  let readmeContent = $state<string | null>(null);

  $effect(() => {
    readmeContent = null;
    const readmeEntry = entries.find(
      e => e.name.toLowerCase() === 'readme.md' && e.type !== LinkType.Dir,
    );
    if (!readmeEntry) return;

    let cancelled = false;
    getTree().readFile(readmeEntry.cid).then(data => {
      if (!cancelled && data) {
        const text = decodeAsText(data);
        if (text) readmeContent = text;
      }
    });
    return () => {
      cancelled = true;
    };
  });
</script>

<div class="b-1 b-surface-3 b-solid rounded-lg overflow-hidden bg-surface-0" data-testid="file-list">
  <FileTable
    {entries}
    {entriesLoading}
    {fileCommits}
    {buildEntryHref}
    {buildCommitHref}
    {latestCommit}
    {latestCommitTags}
    {commitsLoading}
    {parentHref}
    {ciStatus}
    {ciStatusStore}
    {repoPath}
    {ciConfig}
  />
</div>

{#if readmeContent}
  <ReadmePanel content={readmeContent} {entries} {canEdit} />
{/if}
