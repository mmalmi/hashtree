<script lang="ts">
  import type { CID, TreeVisibility } from '@hashtree/core';
  import { SvelteURLSearchParams } from 'svelte/reactivity';
  import { routeStore } from '../../stores';
  import { npubToPubkey } from '../../nostr';
  import VisibilityIcon from '../VisibilityIcon.svelte';
  import { Avatar, Name } from '../User';

  interface RepoHeaderPathSegment {
    label: string;
    href?: string;
  }

  interface Props {
    backUrl: string;
    repoName: string;
    npub?: string | null;
    visibility?: TreeVisibility;
    isPermalink?: boolean;
    rootCid?: CID | null;
    sectionLabel?: string;
    sectionHref?: string;
    pathSegments?: RepoHeaderPathSegment[];
  }

  let {
    backUrl,
    repoName,
    npub = null,
    visibility,
    isPermalink = false,
    rootCid = null,
    sectionLabel,
    sectionHref,
    pathSegments = [],
  }: Props = $props();

  let route = $derived($routeStore);
  let ownerPubkey = $derived(npubToPubkey(npub || '') || '');
  let repoParts = $derived(repoName.split('/').filter(Boolean));
  let repoHeaderName = $derived(repoParts.at(-1) ?? repoName);
  let displayPathSegments = $derived(pathSegments.filter(segment => segment.label.trim().length > 0));
  // Highlight the trailing breadcrumb (the active view) and dim the rest:
  // reponame is dimmed when a path segment or sectionLabel follows it, the
  // last path segment is dimmed when sectionLabel follows it, etc.
  let hasSection = $derived(!!sectionLabel);
  let isRepoNameActive = $derived(displayPathSegments.length === 0 && !hasSection);
  let lastPathSegmentIndex = $derived(hasSection ? -1 : displayPathSegments.length - 1);
  let repoRootHref = $derived.by(() => {
    if (!npub || !repoName) return backUrl;
    const params = new SvelteURLSearchParams();
    const linkKey = route.params.get('k');
    if (linkKey) params.set('k', linkKey);
    const query = params.toString();
    return `#/${[npub, ...repoParts].map(encodeURIComponent).join('/')}${query ? `?${query}` : ''}`;
  });
</script>

<div class="flex min-w-0 flex-1 flex-col justify-center gap-1" data-testid="repo-header-row">
  <div class="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
    <a href={backUrl} class="btn-circle btn-ghost h-8 w-8 min-h-8 min-w-8 no-underline inline-flex items-center justify-center shrink-0" title="Back">
      <span class="i-lucide-chevron-left text-lg"></span>
    </a>
    {#if npub && ownerPubkey}
      <a
        href="#/{npub}/profile"
        class="inline-flex min-w-0 max-w-full items-center gap-1.5 text-sm leading-tight text-text-2 hover:opacity-80"
        aria-label="View repo owner profile"
      >
        <Avatar pubkey={ownerPubkey} size={20} showBadge={true} />
        <Name pubkey={ownerPubkey} class="min-w-0 truncate text-sm leading-none text-text-2 hover:text-accent hover:underline" />
      </a>
      <span class="shrink-0 text-text-3">/</span>
    {:else if isPermalink}
      {#if rootCid?.key}
        <span class="relative inline-flex items-center shrink-0 text-text-2" title="Encrypted snapshot link">
          <span class="i-lucide-link"></span>
          <span class="i-lucide-lock absolute -bottom-0.5 -right-1.5 text-[0.6em]"></span>
        </span>
      {:else}
        <span class="i-lucide-globe text-text-2 shrink-0" title="Public snapshot link"></span>
      {/if}
    {/if}
    {#if visibility}
      <VisibilityIcon {visibility} class="text-text-2 shrink-0" />
    {/if}
    <div class="flex min-w-0 flex-wrap items-center gap-x-1 gap-y-1 text-sm font-medium leading-tight" data-testid="repo-header-path">
      <a
        href={repoRootHref}
        class="min-w-0 max-w-full break-all no-underline {isRepoNameActive ? 'text-text-1' : 'text-text-2'} hover:text-accent hover:underline"
      >
        {repoHeaderName}
      </a>
      {#each displayPathSegments as segment, index (`${segment.label}-${index}`)}
        {@const isActive = index === lastPathSegmentIndex}
        <span class="flex min-w-0 max-w-full items-center gap-1">
          <span class="shrink-0 text-text-3">/</span>
          {#if segment.href}
            <a
              href={segment.href}
              class="min-w-0 max-w-full break-all no-underline {isActive ? 'text-text-1' : 'text-text-2'} hover:text-accent hover:underline"
            >
              {segment.label}
            </a>
          {:else}
            <span class="min-w-0 max-w-full break-all {isActive ? 'text-text-1' : 'text-text-2'}">
              {segment.label}
            </span>
          {/if}
        </span>
      {/each}
      {#if sectionLabel}
        <span class="flex min-w-0 max-w-full items-center gap-1">
          <span class="shrink-0 text-text-3">/</span>
          {#if sectionHref}
            <a
              href={sectionHref}
              class="min-w-0 max-w-full break-all no-underline text-text-1 hover:text-accent hover:underline"
            >
              {sectionLabel}
            </a>
          {:else}
            <span class="min-w-0 max-w-full break-all text-text-1">
              {sectionLabel}
            </span>
          {/if}
        </span>
      {/if}
    </div>
  </div>
</div>
