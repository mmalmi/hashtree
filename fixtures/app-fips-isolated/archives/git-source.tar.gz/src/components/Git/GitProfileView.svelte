<script lang="ts">
  import ContactPreferences from "../User/ContactPreferences.svelte";
  import { nip19 } from 'nostr-tools';
  import { nostrStore } from '../../nostr';
  import { createProfileStore } from '../../stores/profile';
  import { createFollowsStore, followPubkey, unfollowPubkey } from '../../stores/follows';
  import { createTreesStore, type TreeEntry } from '../../stores';
  import { createFavoriteReposStore } from '../../stores';
  import { open as openCreateModal } from '../Modals/CreateModal.svelte';
  import { Avatar, Name, FollowedBy } from '../User';
  import CopyText from '@iris/svelte-ui/CopyText.svelte';
  import ProxyImg from '../ProxyImg.svelte';
  import ShareButton from '../ShareButton.svelte';
  import RepoCard from './RepoCard.svelte';
  import { buildGitHomeRepos } from './homeModel';
  import { filterOwnedFavoriteRepos, type FavoriteRepoRef } from '../../lib/gitFavorites';
  import { encodeEventId, fetchProfileGitActivity, type GitProfileActivityItem } from '../../nip34';
  import { getFollowsMe, getFollowers, fetchUserFollows, fetchUserFollowers, socialGraphStore } from '../../utils/socialGraph';
  import { formatTimeAgo, shortNpub } from '../../utils/format';
  import ItemStatusBadge from './ItemStatusBadge.svelte';

  interface Props {
    npub: string;
  }

  let { npub }: Props = $props();

  let myPubkey = $derived($nostrStore.pubkey);
  let myNpub = $derived($nostrStore.npub);
  let isLoggedIn = $derived($nostrStore.isLoggedIn);

  let pubkeyHex = $derived.by(() => {
    try {
      const decoded = nip19.decode(npub);
      return decoded.data as string;
    } catch {
      return '';
    }
  });

  let isOwnProfile = $derived(myPubkey === pubkeyHex);

  let profileStore = $derived(createProfileStore(npub));
  let profile = $state<{
    name?: string;
    display_name?: string;
    about?: string;
    banner?: string;
    picture?: string;
    nip05?: string;
    website?: string;
  } | null>(null);

  $effect(() => {
    const store = profileStore;
    const unsub = store.subscribe(value => {
      profile = value ?? null;
    });
    return unsub;
  });

  let myFollowsStore = $derived(myPubkey ? createFollowsStore(myPubkey) : null);
  let myFollows = $state<string[]>([]);

  $effect(() => {
    if (!myFollowsStore) {
      myFollows = [];
      return;
    }
    const unsub = myFollowsStore.subscribe(value => {
      myFollows = value?.follows || [];
    });
    return () => {
      unsub();
      myFollowsStore?.destroy();
    };
  });

  let profileFollowsStore = $derived(pubkeyHex ? createFollowsStore(pubkeyHex) : null);
  let profileFollows = $state<string[]>([]);

  $effect(() => {
    if (!profileFollowsStore) {
      profileFollows = [];
      return;
    }
    const unsub = profileFollowsStore.subscribe(value => {
      profileFollows = value?.follows || [];
    });
    return () => {
      unsub();
      profileFollowsStore?.destroy();
    };
  });

  let graphVersion = $derived($socialGraphStore.version);

  let isFollowing = $derived.by(() => {
    graphVersion;
    return myFollows.includes(pubkeyHex);
  });

  let followsMe = $derived.by(() => {
    graphVersion;
    return getFollowsMe(pubkeyHex);
  });

  let knownFollowers = $derived.by(() => {
    graphVersion;
    return getFollowers(pubkeyHex);
  });

  $effect(() => {
    if (pubkeyHex) {
      fetchUserFollows(pubkeyHex);
      fetchUserFollowers(pubkeyHex);
    }
  });

  let treesStore = $derived(createTreesStore(npub));
  let trees = $state<TreeEntry[]>([]);
  let repoSearch = $state('');

  $effect(() => {
    const store = treesStore;
    repoSearch = '';
    const unsub = store.subscribe(value => {
      trees = value;
    });
    return unsub;
  });

  let repos = $derived(buildGitHomeRepos(trees));
  let repoQuery = $derived(repoSearch.trim().toLowerCase());
  let filteredRepos = $derived(repos.filter(repo => repo.name.toLowerCase().includes(repoQuery)));

  let favoriteReposStore = $derived(pubkeyHex ? createFavoriteReposStore(pubkeyHex) : null);
  let favoriteRepos = $state<FavoriteRepoRef[]>([]);

  $effect(() => {
    if (!favoriteReposStore) {
      favoriteRepos = [];
      return;
    }

    const unsub = favoriteReposStore.subscribe(value => {
      favoriteRepos = value?.repos || [];
    });

    return () => {
      unsub();
      favoriteReposStore?.destroy();
    };
  });

  let visibleFavoriteRepos = $derived(
    npub ? filterOwnedFavoriteRepos(npub, repos.map(repo => repo.name), favoriteRepos) : [],
  );
  let gitActivity = $state<GitProfileActivityItem[]>([]);
  let gitActivityLoading = $state(false);
  let gitActivityError = $state<string | null>(null);

  $effect(() => {
    let cancelled = false;

    if (!npub) {
      gitActivity = [];
      gitActivityLoading = false;
      gitActivityError = null;
      return;
    }

    gitActivityLoading = true;
    gitActivityError = null;

    fetchProfileGitActivity(npub, 12)
      .then(items => {
        if (cancelled) return;
        gitActivity = items;
      })
      .catch(err => {
        if (cancelled) return;
        console.error('Failed to load git profile activity:', err);
        gitActivity = [];
        gitActivityError = err instanceof Error ? err.message : 'Failed to load activity';
      })
      .finally(() => {
        if (!cancelled) {
          gitActivityLoading = false;
        }
      });

    return () => {
      cancelled = true;
    };
  });

  let bannerError = $state(false);
  let followLoading = $state(false);
  let followError = $state('');
  $effect(() => { pubkeyHex; myPubkey; followError = ''; });

  function navigate(path: string) {
    window.location.hash = path;
  }

  async function handleFollow() {
    followLoading = true;
    followError = '';
    const updated = await (isFollowing ? unfollowPubkey(pubkeyHex) : followPubkey(pubkeyHex));
    if (!updated) followError = 'Could not update follows. Try again when connected.';
    followLoading = false;
  }

  function createRepository() {
    if (!myNpub) {
      alert('Please sign in to create a repository');
      return;
    }
    openCreateModal('repository');
  }

  function getActivityHref(item: GitProfileActivityItem): string {
    const eventId = item.type === 'comment' ? item.targetEventId : item.id;
    const encodedId = encodeEventId(eventId);
    const tab = item.type === 'comment'
      ? (item.targetType === 'issue' ? 'issues' : 'pulls')
      : (item.type === 'issue' ? 'issues' : 'pulls');
    return `#/${item.repoOwnerNpub}/${item.repoName}?tab=${tab}&id=${encodedId}`;
  }

  function getActivityRepoLabel(item: GitProfileActivityItem): string {
    if (item.repoOwnerPubkey === pubkeyHex) {
      return item.repoName;
    }

    return `${shortNpub(item.repoOwnerNpub)}/${item.repoName}`;
  }

  function getCommentPreview(content: string): string {
    const normalized = content.replace(/\s+/g, ' ').trim();
    if (!normalized) {
      return '';
    }

    return normalized.length > 160 ? `${normalized.slice(0, 157)}...` : normalized;
  }
</script>

<div class="flex-1 flex flex-col min-h-0 bg-surface-0 overflow-y-auto">
  <div class="h-32 md:h-40 bg-surface-2 relative shrink-0">
    {#if profile?.banner && !bannerError}
      <ProxyImg
        src={profile.banner}
        alt=""
        width={1200}
        height={320}
        class="w-full h-full object-cover"
        onerror={() => bannerError = true}
      />
    {/if}
  </div>

  <div class="px-4 pb-8 -mt-12 relative">
    <div class="mb-3" data-testid="profile-avatar">
      <Avatar pubkey={pubkeyHex} showBadge={false} size={80} class="border-4 border-surface-0" />
    </div>

    <div class="flex items-center justify-between gap-2">
      <div class="flex items-center gap-2 min-w-0">
        <h1 class="text-xl font-bold text-text-1 m-0 truncate">
          <Name pubkey={pubkeyHex} />
        </h1>
        {#if isOwnProfile}
          <span class="shrink-0 text-xs text-text-2">You</span>
        {/if}
        {#if !isOwnProfile && followsMe}
          <span class="shrink-0 text-xs bg-surface-2 text-text-2 px-2 py-0.5 rounded">
            Follows you
          </span>
        {/if}
      </div>
      <div class="flex items-center gap-2 shrink-0">
        {#if isLoggedIn && isOwnProfile}
          <button
            onclick={() => navigate('/users')}
            class="btn-ghost"
            title="Switch user"
          >
            Switch User
          </button>
          <button
            onclick={() => navigate(`/${npub}/edit`)}
            class="btn-ghost"
          >
            Edit Profile
          </button>
        {/if}
        {#if isLoggedIn && !isOwnProfile}
          <button
            onclick={handleFollow}
            title="Your follow list is public"
            disabled={followLoading}
            class={isFollowing ? 'btn-ghost' : 'btn-success'}
          >
            {followLoading ? '...' : isFollowing ? 'Unfollow' : 'Follow'}
          </button>
        {/if}
        <ShareButton url={window.location.href} />
      </div>
    </div>

    <CopyText
      text={npub}
      displayText={npub.slice(0, 8) + '...' + npub.slice(-4)}
      class="text-sm mt-1"
      testId="copy-npub"
    />

    {#if profile?.nip05}
      <div class="text-sm text-accent mt-1">{profile.nip05}</div>
    {/if}

    {#if !isOwnProfile && pubkeyHex}
      <FollowedBy pubkey={pubkeyHex} class="mt-2" />
      <ContactPreferences pubkey={pubkeyHex} />
      {#if followError}<p class="text-sm text-red-400 mt-2" role="alert">{followError}</p>{/if}
    {/if}

    {#if profile?.about}
      <p class="text-sm text-text-2 mt-3 whitespace-pre-wrap break-words">
        {profile.about}
      </p>
    {/if}

    <div class="flex gap-4 mt-4 text-sm">
      <a href="#/{npub}/follows" class="text-text-3 hover:text-text-1 no-underline">
        <span class="font-bold text-text-1">{profileFollows.length}</span> Following
      </a>
      <a href="#/{npub}/followers" class="text-text-3 hover:text-text-1 no-underline">
        <span class="font-bold text-text-1">{knownFollowers.size}</span> Known Followers
      </a>
    </div>

    {#if profile?.website}
      <a
        href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`}
        target="_blank"
        rel="noopener noreferrer"
        class="text-sm text-accent mt-3 inline-block hover:underline"
      >
        {profile.website}
      </a>
    {/if}

    <div class="mt-8 flex items-center justify-between gap-3">
      <div>
        <div class="inline-flex items-center gap-2 rounded-full border border-surface-3 bg-surface-1 px-3 py-1 text-xs uppercase tracking-[0.22em] text-text-3">
          <span class="i-lucide-git-branch-plus text-sm"></span>
          Git Trees
        </div>
        <h2 class="mt-4 mb-2 text-3xl font-semibold text-text-1">Repositories</h2>
        <p class="m-0 max-w-2xl text-sm text-text-2">
          Published repositories tagged with <code>git</code> appear here.
        </p>
      </div>
    </div>

    {#if repos.length > 5 || repoSearch}
      <div class="relative mt-6 max-w-md">
        <span class="i-lucide-search absolute left-3 top-1/2 -translate-y-1/2 text-text-3 pointer-events-none" aria-hidden="true"></span>
        <input
          type="search"
          bind:value={repoSearch}
          aria-label="Filter repositories"
          placeholder="Filter repositories..."
          class="w-full rounded-lg border border-surface-3 bg-surface-1 py-2 pl-10 pr-3 text-sm text-text-1 placeholder:text-text-3 focus:border-accent focus:outline-none"
        />
      </div>
    {/if}

    <div class="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {#if isOwnProfile}
        <div
          onclick={createRepository}
          onkeydown={(event) => (event.key === 'Enter' || event.key === ' ') && createRepository()}
          class="rounded-2xl border border-dashed border-surface-3 bg-surface-1/70 p-5 min-h-44 flex flex-col justify-between cursor-pointer hover:border-accent hover:bg-surface-1 transition-colors"
          role="button"
          tabindex="0"
        >
          <div class="h-12 w-12 rounded-xl bg-accent/12 text-accent border border-accent/20 flex items-center justify-center">
            <span class="i-lucide-plus text-xl"></span>
          </div>
          <div class="space-y-2">
            <div class="text-[0.65rem] uppercase tracking-[0.24em] text-text-3">Create</div>
            <div class="text-lg font-semibold text-text-1">New Repository</div>
            <div class="text-sm text-text-2">Start a top-level git tree with an initial commit.</div>
          </div>
        </div>
      {/if}

      {#each filteredRepos as repo (repo.name)}
        {@const linkKeySuffix = repo.linkKey ? `?k=${repo.linkKey}` : ''}
        <RepoCard
          href="#/{npub}/{repo.name}{linkKeySuffix}"
          name={repo.name}
          visibility={repo.visibility}
          createdAt={repo.createdAt}
        />
      {/each}
    </div>

    {#if repoQuery && filteredRepos.length === 0}
      <p class="mt-6 text-sm text-text-2" role="status">No repositories match your search.</p>
    {:else if repos.length === 0}
      <div class="mt-8 rounded-2xl border border-surface-3 bg-surface-1/40 p-6 text-sm text-text-2">
        {#if isOwnProfile}
          No repositories yet. Create one here or push an existing repo with <code>git-remote-htree</code> so it gets a <code>git</code> label.
        {:else}
          No published repositories yet.
        {/if}
      </div>
    {/if}

    <div class="mt-10 flex items-center justify-between gap-3">
      <div>
        <div class="inline-flex items-center gap-2 rounded-full border border-surface-3 bg-surface-1 px-3 py-1 text-xs uppercase tracking-[0.22em] text-text-3">
          <span class="i-lucide-activity text-sm"></span>
          Activity
        </div>
        <h2 class="mt-4 mb-2 text-3xl font-semibold text-text-1">Recent Activity</h2>
        <p class="m-0 max-w-2xl text-sm text-text-2">
          Issues, pull requests, and comments this profile has published from the git app.
        </p>
      </div>
    </div>

    {#if gitActivityLoading}
      <div class="mt-6 rounded-2xl border border-surface-3 bg-surface-1/40 p-6 text-sm text-text-2 flex items-center gap-2">
        <span class="i-lucide-loader-2 animate-spin"></span>
        Loading activity...
      </div>
    {:else if gitActivityError}
      <div class="mt-6 rounded-2xl border border-danger/30 bg-danger/5 p-6 text-sm text-danger">
        Failed to load profile activity: {gitActivityError}
      </div>
    {:else if gitActivity.length > 0}
      <div class="mt-6 space-y-3" data-testid="git-profile-activity">
        {#each gitActivity as item (item.id)}
          {@const href = getActivityHref(item)}
          <a
            href={href}
            class="block rounded-2xl border border-surface-3 bg-surface-1/40 p-4 no-underline transition-colors hover:border-accent/40 hover:bg-surface-1"
          >
            <div class="flex items-start gap-3">
              <div class="mt-0.5 h-10 w-10 shrink-0 rounded-xl border border-surface-3 bg-surface-0 flex items-center justify-center text-text-2">
                <span class={item.type === 'comment' ? 'i-lucide-message-square text-lg' : item.type === 'pr' ? 'i-lucide-git-pull-request text-lg' : 'i-lucide-circle-dot text-lg'}></span>
              </div>

              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-2 flex-wrap">
                  {#if item.type === 'comment'}
                    <span class="inline-flex items-center gap-1 rounded-full bg-surface-2 px-2.5 py-1 text-xs font-medium text-text-2">
                      <span class="i-lucide-message-square text-sm"></span>
                      Comment
                    </span>
                  {:else if item.type === 'pr'}
                    <ItemStatusBadge status={item.status} type="pr" />
                  {:else}
                    <ItemStatusBadge status={item.status} type="issue" />
                  {/if}

                  <span class="text-xs uppercase tracking-[0.18em] text-text-3">{formatTimeAgo(item.created_at)}</span>
                </div>

                {#if item.type === 'comment'}
                  <div class="mt-2 text-base font-medium text-text-1 break-words">
                    Commented on {item.targetType === 'pr' ? 'pull request' : 'issue'}: {item.targetTitle}
                  </div>
                  {#if getCommentPreview(item.content)}
                    <p class="mt-2 mb-0 text-sm text-text-2 break-words">
                      {getCommentPreview(item.content)}
                    </p>
                  {/if}
                {:else}
                  <div class="mt-2 text-base font-medium text-text-1 break-words">{item.title}</div>

                  {#if item.type === 'pr' && item.branch}
                    <div class="mt-2 flex items-center gap-2 flex-wrap text-xs text-text-3">
                      <span class="font-mono rounded bg-surface-2 px-2 py-1 text-text-2">{item.branch}</span>
                      <span class="i-lucide-arrow-right"></span>
                      <span class="font-mono rounded bg-surface-2 px-2 py-1 text-text-2">{item.targetBranch || 'main'}</span>
                    </div>
                  {/if}
                {/if}

                <div class="mt-3 flex items-center gap-2 flex-wrap text-xs text-text-3">
                  <span class="i-lucide-folder-git-2 text-sm"></span>
                  <span class="rounded-full bg-surface-2 px-2 py-0.5 font-mono text-[0.7rem] text-text-2">
                    {getActivityRepoLabel(item)}
                  </span>

                  {#if item.type !== 'comment'}
                    {#each item.labels.slice(0, 3) as label (label)}
                      <span class="rounded-full bg-accent/10 px-2 py-0.5 text-[0.7rem] text-accent">{label}</span>
                    {/each}
                  {/if}
                </div>
              </div>

              <span class="i-lucide-arrow-up-right shrink-0 text-text-3"></span>
            </div>
          </a>
        {/each}
      </div>
    {:else}
      <div class="mt-6 rounded-2xl border border-surface-3 bg-surface-1/40 p-6 text-sm text-text-2">
        {#if isOwnProfile}
          Open an issue, send a pull request, or comment on a repo discussion and it will show up here.
        {:else}
          No git activity yet.
        {/if}
      </div>
    {/if}

    <div class="mt-10 flex items-center justify-between gap-3">
      <div>
        <div class="inline-flex items-center gap-2 rounded-full border border-surface-3 bg-surface-1 px-3 py-1 text-xs uppercase tracking-[0.22em] text-text-3">
          <span class="i-lucide-heart text-sm"></span>
          Likes
        </div>
        <h2 class="mt-4 mb-2 text-3xl font-semibold text-text-1">Liked Repositories</h2>
        <p class="m-0 max-w-2xl text-sm text-text-2">
          Public repositories this profile has liked from the git app.
        </p>
      </div>
    </div>

    {#if visibleFavoriteRepos.length > 0}
      <div class="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {#each visibleFavoriteRepos as repo (repo.address)}
          <RepoCard
            href={repo.href}
            name={repo.repoName}
            ownerPubkey={repo.ownerPubkey}
            metaLabel="Liked repository"
            accentIcon="heart"
          />
        {/each}
      </div>
    {:else}
      <div class="mt-8 rounded-2xl border border-surface-3 bg-surface-1/40 p-6 text-sm text-text-2">
        {#if isOwnProfile}
          Like a public repository and it will appear here.
        {:else}
          No liked repositories yet.
        {/if}
      </div>
    {/if}
  </div>
</div>
