<script lang="ts">
  import type { CID, TreeVisibility } from '@hashtree/core';
  import { nostrStore } from '../../nostr';
  import {
    createFavoriteRepoStatsStore,
    createFavoriteReposStore,
    createRepoForkStatsStore,
    toggleFavoriteRepo,
    type RepoForkListItem,
  } from '../../stores';
  import type { FavoriteRepoRef } from '../../lib/gitFavorites';
  import { buildRepoAddress } from '../../nip34';
  import BranchDropdown from './BranchDropdown.svelte';
  import CodeDropdown from './CodeDropdown.svelte';

  interface Props {
    gitCid: CID | null;
    branches: string[];
    currentBranch: string | null;
    branchDisplay: string;
    canEdit: boolean;
    ownerNpub: string | null;
    repoPath: string;
    gitBranchNamesLoading: boolean;
    gitTagNamesLoading: boolean;
    switchingToRef: string | null;
    branchesHref: string | null;
    tagsHref: string | null;
    tags: string[];
    statusLoading: boolean;
    totalChanges: number;
    totalCommitCount: number | null;
    visibility?: TreeVisibility;
    linkKey?: string | null;
    onRefSelect: (ref: string) => void | Promise<void>;
    onCommit: () => void;
    onHistory: () => void;
  }

  let {
    gitCid,
    branches,
    currentBranch,
    branchDisplay,
    canEdit,
    ownerNpub,
    repoPath,
    gitBranchNamesLoading,
    gitTagNamesLoading,
    switchingToRef,
    branchesHref,
    tagsHref,
    tags,
    statusLoading,
    totalChanges,
    totalCommitCount,
    visibility,
    linkKey = null,
    onRefSelect,
    onCommit,
    onHistory,
  }: Props = $props();

  let userNpub = $derived($nostrStore.npub);
  let favoriteReposStore = $derived(userNpub ? createFavoriteReposStore(userNpub) : null);
  let favoriteRepos = $state<FavoriteRepoRef[]>([]);

  $effect(() => {
    const store = favoriteReposStore;
    if (!store) {
      favoriteRepos = [];
      return;
    }
    const unsub = store.subscribe(value => {
      favoriteRepos = value?.repos || [];
    });
    return () => {
      unsub();
      store.destroy();
    };
  });

  let repoAddress = $derived.by(() => {
    if (!ownerNpub || !repoPath) return null;
    return buildRepoAddress(ownerNpub, repoPath);
  });
  let isPublicRepo = $derived(!!ownerNpub && !linkKey && visibility !== 'private' && visibility !== 'link-visible');
  let canFavoriteRepo = $derived(!!repoAddress && isPublicRepo);
  let isFavorited = $derived(repoAddress ? favoriteRepos.some(repo => repo.address === repoAddress) : false);
  let favoriteLoading = $state(false);
  let favoriteOptimisticState = $state<boolean | null>(null);
  let favoriteOptimisticCount = $state<number | null>(null);
  let favoriteRepoStatsStore = $derived(
    ownerNpub && repoPath ? createFavoriteRepoStatsStore(ownerNpub, repoPath) : null,
  );
  let favoriteRepoCount = $state(0);
  let displayedIsFavorited = $derived(favoriteOptimisticState ?? isFavorited);
  let displayedFavoriteCount = $derived(favoriteOptimisticCount ?? favoriteRepoCount);
  let repoForkStatsStore = $derived(
    isPublicRepo && ownerNpub && repoPath ? createRepoForkStatsStore(ownerNpub, repoPath) : null,
  );
  let repoForkCount = $state(0);
  let repoForks = $state<RepoForkListItem[]>([]);
  let repoForkEuc = $state<string | null>(null);
  let showRepoForkList = $state(false);

  $effect(() => {
    repoAddress;
    favoriteOptimisticState = null;
    favoriteOptimisticCount = null;
    showRepoForkList = false;
  });

  $effect(() => {
    if (favoriteOptimisticState !== null && isFavorited === favoriteOptimisticState) {
      favoriteOptimisticState = null;
    }
  });

  $effect(() => {
    if (favoriteOptimisticCount !== null && favoriteRepoCount === favoriteOptimisticCount) {
      favoriteOptimisticCount = null;
    }
  });

  $effect(() => {
    const store = favoriteRepoStatsStore;
    if (!store) {
      favoriteRepoCount = 0;
      return;
    }
    const unsub = store.subscribe(value => {
      favoriteRepoCount = value?.count || 0;
    });
    return () => {
      unsub();
      store.destroy();
    };
  });

  $effect(() => {
    const store = repoForkStatsStore;
    if (!store) {
      repoForkCount = 0;
      repoForks = [];
      repoForkEuc = null;
      return;
    }
    const unsub = store.subscribe(value => {
      repoForkCount = value?.count || 0;
      repoForks = value?.forks || [];
      repoForkEuc = value?.earliestUniqueCommit ?? null;
    });
    return () => {
      unsub();
      store.destroy();
    };
  });

  async function handleFavoriteToggle() {
    if (!ownerNpub) return;
    if (!userNpub) {
      alert('Please sign in to like public repositories');
      return;
    }

    const nextFavorited = !displayedIsFavorited;
    const nextFavoriteCount = Math.max(0, displayedFavoriteCount + (nextFavorited ? 1 : -1));
    favoriteOptimisticState = nextFavorited;
    favoriteOptimisticCount = nextFavoriteCount;
    favoriteLoading = true;
    try {
      await toggleFavoriteRepo(ownerNpub, repoPath);
    } catch (err) {
      favoriteOptimisticState = null;
      favoriteOptimisticCount = null;
      console.error('Failed to update repository like:', err);
    } finally {
      favoriteLoading = false;
    }
  }

  function buildForkHref(fork: RepoForkListItem): string {
    return `#/${[fork.ownerNpub, ...fork.repoName.split('/').filter(Boolean)].map(encodeURIComponent).join('/')}`;
  }
</script>

<div class="flex flex-wrap items-center gap-3 text-sm">
  {#if gitCid}
    <BranchDropdown
      {branches}
      {currentBranch}
      {branchDisplay}
      {canEdit}
      dirCid={gitCid}
      npub={ownerNpub ?? undefined}
      {repoPath}
      onRefSelect={onRefSelect}
      loading={!!switchingToRef || (gitBranchNamesLoading && branches.length === 0)}
    />
  {:else}
    <button class="btn-ghost flex items-center gap-1 px-3 h-9 text-sm" disabled>
      <span class="i-lucide-loader-2 animate-spin"></span>
      <span>Loading repo</span>
    </button>
  {/if}

  {#if branchesHref}
    <a href={branchesHref} class="flex items-center gap-1.5 text-sm text-text-2 hover:text-text-1 no-underline">
      <span class="i-lucide-git-branch text-text-3"></span>
      <span>{gitCid ? (gitBranchNamesLoading ? 'Loading branches...' : `${branches.length} branch${branches.length !== 1 ? 'es' : ''}`) : 'Detecting branches...'}</span>
    </a>
  {:else}
    <span class="flex items-center gap-1.5 text-sm text-text-2">
      <span class="i-lucide-git-branch text-text-3"></span>
      <span>{gitCid ? (gitBranchNamesLoading ? 'Loading branches...' : `${branches.length} branch${branches.length !== 1 ? 'es' : ''}`) : 'Detecting branches...'}</span>
    </span>
  {/if}

  {#if gitCid}
    {#if tagsHref}
      <a href={tagsHref} class="flex items-center gap-1.5 text-sm text-text-2 hover:text-text-1 no-underline">
        <span class="i-lucide-tag text-text-3"></span>
        <span>{gitTagNamesLoading ? 'Loading tags...' : `${tags.length} tag${tags.length !== 1 ? 's' : ''}`}</span>
      </a>
    {:else}
      <span class="flex items-center gap-1.5 text-sm text-text-2">
        <span class="i-lucide-tag text-text-3"></span>
        <span>{gitTagNamesLoading ? 'Loading tags...' : `${tags.length} tag${tags.length !== 1 ? 's' : ''}`}</span>
      </span>
    {/if}
  {/if}

  {#if canEdit}
    {#if !gitCid || statusLoading}
      <span class="text-text-3 text-xs flex items-center gap-1">
        <span class="i-lucide-loader-2 animate-spin"></span>
      </span>
    {:else if totalChanges > 0}
      <button onclick={onCommit} class="btn-ghost flex items-center gap-1 px-2 h-8 text-sm" title="{totalChanges} uncommitted change{totalChanges !== 1 ? 's' : ''}">
        <span class="i-lucide-git-commit text-warning"></span>
        <span class="text-warning">{totalChanges}</span>
        <span class="hidden sm:inline">uncommitted</span>
      </button>
    {:else}
      <span class="text-text-3 text-xs flex items-center gap-1" title="No uncommitted changes">
        <span class="i-lucide-check-circle text-success"></span>
        <span class="hidden sm:inline">clean</span>
      </span>
    {/if}
  {/if}

  <div class="flex-1"></div>

  <button onclick={onHistory} class="flex items-center gap-1.5 text-sm text-text-2 hover:text-accent bg-transparent b-0 cursor-pointer" disabled={!gitCid}>
    <span class="i-lucide-history text-text-3"></span>
    {#if gitCid && totalCommitCount !== null}
      <span>{totalCommitCount} commits</span>
    {:else}
      <span>Commits</span>
    {/if}
  </button>

  {#if ownerNpub}
    {#if canFavoriteRepo}
      <button
        onclick={handleFavoriteToggle}
        class={`btn-ghost flex items-center gap-2 px-3 h-9 ${displayedIsFavorited ? 'text-accent border-accent/30 bg-accent/10 hover:bg-accent/15' : ''}`}
        disabled={favoriteLoading}
        title={displayedIsFavorited ? 'Remove your like from this repository' : 'Like this repository'}
      >
        <span class={`i-lucide-heart ${displayedIsFavorited ? 'fill-current' : ''}`}></span>
        <span>{displayedIsFavorited ? 'Liked' : 'Like'}</span>
        <span class="text-xs text-text-2">{displayedFavoriteCount}</span>
      </button>
    {/if}

    {#if isPublicRepo}
      <div class="relative">
        <button
          type="button"
          data-testid="repo-forks-button"
          onclick={() => { showRepoForkList = !showRepoForkList; }}
          class="flex items-center gap-2 px-3 h-9 rounded-lg border border-surface-3 bg-surface-1 text-sm text-text-2 hover:text-accent hover:border-accent/30 hover:bg-accent/5 cursor-pointer"
          title="Forks discovered by matching NIP-34 EUC announcements"
          aria-haspopup="menu"
          aria-expanded={showRepoForkList}
        >
          <span class="i-lucide-git-fork"></span>
          <span>Forks</span>
          <span class="text-xs text-text-2">{repoForkCount}</span>
        </button>

        {#if showRepoForkList}
          <div data-testid="repo-forks-popover" class="absolute right-0 top-full mt-1 w-[420px] max-w-[90vw] bg-surface-1 b-1 b-surface-3 b-solid rounded-lg shadow-lg z-50 overflow-hidden">
            <div class="flex items-center justify-between gap-3 b-b-1 b-b-surface-3 b-b-solid px-3 py-2">
              <span class="text-sm font-medium text-text-1">Forks</span>
              {#if repoForkEuc}
                <span class="max-w-40 truncate font-mono text-[11px] text-text-3" title={repoForkEuc}>euc {repoForkEuc.slice(0, 12)}</span>
              {/if}
            </div>

            {#if repoForks.length === 0}
              <div data-testid="repo-forks-empty" class="px-3 py-4 text-sm text-text-3">No forks found</div>
            {:else}
              <div class="max-h-80 overflow-y-auto py-1" role="menu">
                {#each repoForks as fork (fork.address)}
                  <a data-testid="repo-fork-link" role="menuitem" href={buildForkHref(fork)} class="flex min-w-0 items-center gap-3 px-3 py-2 text-sm text-text-1 no-underline hover:bg-surface-2">
                    <span class="i-lucide-git-fork shrink-0 text-text-3"></span>
                    <span class="min-w-0 flex-1">
                      <span class="block truncate font-medium">{fork.repoName}</span>
                      <span class="block truncate text-xs text-text-3">{fork.ownerNpub}</span>
                    </span>
                    <span class="i-lucide-chevron-right shrink-0 text-text-3"></span>
                  </a>
                {/each}
              </div>
            {/if}
          </div>
        {/if}
      </div>
    {/if}

    <CodeDropdown npub={ownerNpub} {repoPath} />
  {/if}
</div>
