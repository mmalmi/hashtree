<script lang="ts">
  /**
   * Tab navigation for repository views (Code, Pull Requests, Issues, optional Releases)
   * Uses query params (?tab=pulls, ?tab=issues, ?tab=releases) to avoid conflicts with directory names
   */
  import { routeStore } from '../../stores';
  import { createRepoTabCountsStore, formatRepoTabCount, type RepoTabCounts } from '../../stores/nip34';

  type RepoTabId = 'code' | 'pulls' | 'issues' | 'releases';

  interface RepoTab {
    id: RepoTabId;
    label: string;
    icon: string;
    query: string;
    count: number | null;
  }

  interface Props {
    npub: string;
    repoName: string;
    activeTab: RepoTabId;
    showReleasesTab?: boolean;
  }

  let { npub, repoName, activeTab, showReleasesTab = false }: Props = $props();
  let route = $derived($routeStore);
  let repoTabCountsStore = $derived(createRepoTabCountsStore(npub, repoName));
  let repoTabCounts = $state<RepoTabCounts>({
    pullRequests: null,
    issues: null,
    loading: true,
    error: null,
    updatedAt: 0,
  });

  $effect(() => {
    const store = repoTabCountsStore;
    const unsub = store.subscribe(value => {
      repoTabCounts = value;
    });

    return () => {
      unsub();
      store.destroy();
    };
  });

  let allTabs = $derived.by((): RepoTab[] => [
    { id: 'code', label: 'Code', icon: 'i-lucide-code', query: '', count: null },
    {
      id: 'pulls',
      label: 'Pull Requests',
      icon: 'i-lucide-git-pull-request',
      query: '?tab=pulls',
      count: repoTabCounts.pullRequests,
    },
    {
      id: 'issues',
      label: 'Issues',
      icon: 'i-lucide-circle-dot',
      query: '?tab=issues',
      count: repoTabCounts.issues,
    },
    { id: 'releases', label: 'Releases', icon: 'i-lucide-tag', query: '?tab=releases', count: null },
  ]);
  let tabs = $derived(showReleasesTab ? allTabs : allTabs.filter(tab => tab.id !== 'releases'));

  function getHref(tab: RepoTab): string {
    const linkKey = route.params.get('k');
    if (!linkKey) {
      return `#/${npub}/${repoName}${tab.query}`;
    }
    const separator = tab.query ? '&' : '?';
    return `#/${npub}/${repoName}${tab.query}${separator}k=${linkKey}`;
  }

  function shouldShowCount(tab: RepoTab): boolean {
    return tab.id === 'pulls' || tab.id === 'issues';
  }

  function getDisplayedCount(tab: RepoTab): string {
    return formatRepoTabCount(tab.count ?? 0);
  }
</script>

<div class="overflow-x-auto scrollbar-hide px-4 b-b-1 b-b-solid b-b-surface-3" data-testid="repo-tab-nav">
  <div class="flex items-center gap-1 min-w-max">
    {#each tabs as tab (tab.id)}
      <a
        href={getHref(tab)}
        class="shrink-0 flex items-center gap-2 px-3 py-3 text-sm transition-colors b-b-2 b-b-solid -mb-px no-underline {
          activeTab === tab.id
            ? 'b-b-accent text-text-1 font-medium'
            : 'b-b-transparent text-text-2 hover:text-text-1 hover:b-b-surface-3'
        }"
      >
        <span class="{tab.icon}"></span>
        <span>{tab.label}</span>
        {#if shouldShowCount(tab)}
          <span
            class="min-w-5 rounded-full bg-surface-2 px-1.5 py-0.5 text-center text-xs leading-none {
              repoTabCounts.loading && tab.count === null ? 'opacity-70 ' : ''
            }{
              activeTab === tab.id ? 'text-text-1' : 'text-text-2'
            }"
          >
            {getDisplayedCount(tab)}
          </span>
        {/if}
      </a>
    {/each}
  </div>
</div>
