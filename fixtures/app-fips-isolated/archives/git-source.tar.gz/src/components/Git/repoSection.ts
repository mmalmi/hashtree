export type RepoChildTabId = 'code' | 'pulls' | 'issues' | 'releases';

export function getDefaultRepoSectionLabel(activeTab: RepoChildTabId): string | undefined {
  if (activeTab === 'pulls') {
    return 'pull requests';
  }

  if (activeTab === 'issues') {
    return 'issues';
  }

  return undefined;
}
