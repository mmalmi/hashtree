export const GIT_REMOTE_HTREE_INSTALL_COMMAND = `curl -fsSL https://github.com/mmalmi/hashtree/releases/download/v0.3.1/install.sh -o /tmp/install-hashtree.sh
# Inspect the installer, then run it:
sh /tmp/install-hashtree.sh`;
export const GIT_REMOTE_HTREE_INSTALL_DOCS_URL = 'https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/hashtree/README.md?anchor=installation';
