/**
 * NIP-34: Git Repositories
 * Handles pull requests, issues, and their statuses for git repositories
 * Uses htree://npub/reponame style repository addresses
 */
import { assertPublicGitCollaboration, GitCollaborationPrivacyError } from './lib/gitCollaboration';
import { waitForWorkerAdapter } from './lib/workerInit';
import { buildHtreeUrl as buildHtreeUrlLib, type HtreeUrlOptions } from '@hashtree/git';
import { nostr, nostrStore, pubkeyToNpub, npubToPubkey } from './nostr';
import type { Event as NostrEvent, EventTemplate, Filter as NostrFilter } from 'nostr-tools';
import {
  KIND_REPO_ANNOUNCEMENT,
  KIND_PULL_REQUEST,
  KIND_ISSUE,
  KIND_STATUS_OPEN,
  KIND_STATUS_APPLIED,
  KIND_STATUS_CLOSED,
  KIND_STATUS_DRAFT,
} from './utils/constants';
export { addComment, fetchComments } from './nip34Comments';
export { decodeEventId, encodeEventId } from './nip34EventIds';
export { fetchProfileGitActivity } from './nip34ProfileActivity';
export { fetchRepoAnnouncement, publishRepoAnnouncement } from './nip34RepoAnnouncements';

export async function fetchEventsViaSubscribe(filter: NostrFilter, timeoutMs = 5000): Promise<NostrEvent[]> {
  const backend = await waitForWorkerAdapter(timeoutMs);
  if (!backend?.queryEvents) throw new Error('Event storage is not ready.');
  const result = await backend.queryEvents([filter], { deadline: Date.now() + timeoutMs });
  // Public activity lists show available verified events, including offline history.
  // A peer which cannot complete its history must not hide the other sources' items.
  return result.events;
}

export async function publishNip34Event(event: EventTemplate | NostrEvent): Promise<NostrEvent> {
  await assertPublicGitCollaboration(event);
  const signed = 'sig' in event ? event : await nostr.signEvent(event);
  // An extension signing prompt may remain open while visibility changes.
  await assertPublicGitCollaboration(signed);
  await nostr.publish(signed);
  return signed;
}

// Status types for PRs and Issues
export type ItemStatus = 'open' | 'merged' | 'closed' | 'draft';

export interface PullRequest {
  id: string; // Event ID
  eventId: string; // Same as id for Nostr compatibility
  title: string;
  description: string;
  author: string; // npub
  authorPubkey: string; // hex pubkey
  status: ItemStatus;
  branch?: string; // Source branch
  targetBranch?: string; // Target branch (usually main)
  commitTip?: string; // Commit hash at tip
  cloneUrl?: string; // Where to clone from
  created_at: number;
  updated_at: number;
  labels: string[];
}

export interface Issue {
  id: string; // Event ID
  eventId: string; // Same as id for Nostr compatibility
  title: string;
  description: string;
  author: string; // npub
  authorPubkey: string; // hex pubkey
  status: ItemStatus;
  created_at: number;
  updated_at: number;
  labels: string[];
}

export interface Comment {
  id: string;
  content: string;
  author: string; // npub
  authorPubkey: string; // hex pubkey
  created_at: number;
  replyTo?: string; // Event ID this is replying to
}

export interface RepoReference {
  repoAddress: string;
  repoName: string;
  repoOwnerPubkey: string;
  repoOwnerNpub: string;
}

export interface GitProfileIssueActivity extends RepoReference {
  id: string;
  type: 'issue';
  title: string;
  status: ItemStatus;
  labels: string[];
  created_at: number;
}

export interface GitProfilePullRequestActivity extends RepoReference {
  id: string;
  type: 'pr';
  title: string;
  status: ItemStatus;
  labels: string[];
  branch?: string;
  targetBranch?: string;
  created_at: number;
}

export interface GitProfileCommentActivity extends RepoReference {
  id: string;
  type: 'comment';
  content: string;
  targetEventId: string;
  targetType: 'issue' | 'pr';
  targetTitle: string;
  created_at: number;
}

export type GitProfileActivityItem =
  | GitProfileIssueActivity
  | GitProfilePullRequestActivity
  | GitProfileCommentActivity;

/**
 * Build the NIP-34 repository address tag (a-tag)
 * Format: 30617:<owner-pubkey>:<repo-name>
 */
export function buildRepoAddress(npub: string, repoName: string): string {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) throw new Error('Invalid npub');
  return `${KIND_REPO_ANNOUNCEMENT}:${pubkey}:${repoName}`;
}

/**
 * Build htree:// clone URL for the repository
 * @param npub - Owner's npub
 * @param repoName - Repository name
 * @param options - Optional visibility settings
 * @param options.visibility - Tree visibility: 'public', 'link-visible', or 'private'
 * @param options.linkKey - Link key for link-visible trees (hex string)
 */
export function buildHtreeUrl(npub: string, repoName: string, options?: HtreeUrlOptions): string {
  return buildHtreeUrlLib(npub, repoName, options);
}

/**
 * Parse an a-tag to extract owner pubkey and repo name
 */
export function parseRepoAddress(aTag: string): { pubkey: string; repoName: string } | null {
  const parts = aTag.split(':');
  if (parts.length !== 3 || parts[0] !== String(KIND_REPO_ANNOUNCEMENT)) {
    return null;
  }
  return { pubkey: parts[1], repoName: parts[2] };
}

export function getRepoReferenceFromTags(tags: string[][]): RepoReference | null {
  for (const tag of tags) {
    if (tag[0] !== 'a' || !tag[1]) continue;
    const parsed = parseRepoAddress(tag[1]);
    if (!parsed) continue;
    return {
      repoAddress: tag[1],
      repoName: parsed.repoName,
      repoOwnerPubkey: parsed.pubkey,
      repoOwnerNpub: pubkeyToNpub(parsed.pubkey),
    };
  }

  return null;
}

export function getTargetEventIdFromTags(tags: string[][]): string | null {
  const rootTarget = tags.find(tag => tag[0] === 'e' && tag[3] === 'root')?.[1];
  if (rootTarget) {
    return rootTarget;
  }

  const replyTarget = tags.find(tag => tag[0] === 'e' && tag[3] === 'reply')?.[1];
  if (replyTarget) {
    return replyTarget;
  }

  return tags.find(tag => tag[0] === 'e')?.[1] ?? null;
}

/**
 * Get the status kind from a status string
 */
function statusToKind(status: ItemStatus): number {
  switch (status) {
    case 'open': return KIND_STATUS_OPEN;
    case 'merged': return KIND_STATUS_APPLIED;
    case 'closed': return KIND_STATUS_CLOSED;
    case 'draft': return KIND_STATUS_DRAFT;
    default: return KIND_STATUS_OPEN;
  }
}

/**
 * Get status string from a kind number
 */
function kindToStatus(kind: number): ItemStatus {
  switch (kind) {
    case KIND_STATUS_OPEN: return 'open';
    case KIND_STATUS_APPLIED: return 'merged';
    case KIND_STATUS_CLOSED: return 'closed';
    case KIND_STATUS_DRAFT: return 'draft';
    default: return 'open';
  }
}

/**
 * Fetch pull requests for a repository from Nostr
 */
export async function fetchPullRequests(npub: string, repoName: string): Promise<PullRequest[]> {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) return [];

  const repoAddress = buildRepoAddress(npub, repoName);

  // Fetch PR events that reference this repo
  const filter: NostrFilter = {
    kinds: [KIND_PULL_REQUEST as number],
    '#a': [repoAddress],
  };

  const events = await fetchEventsViaSubscribe(filter);
  const prs: PullRequest[] = [];

  for (const event of events) {
    const pr = parsePullRequestEvent(event);
    if (pr) {
      prs.push(pr);
    }
  }

  const statuses = await fetchLatestStatuses(prs.map(pr => ({
    eventId: pr.eventId,
    repoOwnerPubkey: pubkey,
  })));

  for (const pr of prs) {
    pr.status = statuses.get(pr.eventId) ?? 'open';
  }

  // Sort by created_at descending (newest first)
  return prs.sort((a, b) => b.created_at - a.created_at);
}

/**
 * Fetch issues for a repository from Nostr
 */
export async function fetchIssues(npub: string, repoName: string): Promise<Issue[]> {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) return [];

  const repoAddress = buildRepoAddress(npub, repoName);

  // Fetch issue events that reference this repo
  const filter: NostrFilter = {
    kinds: [KIND_ISSUE as number],
    '#a': [repoAddress],
  };

  const events = await fetchEventsViaSubscribe(filter);
  const issues: Issue[] = [];

  for (const event of events) {
    const issue = parseIssueEvent(event);
    if (issue) {
      issues.push(issue);
    }
  }

  const statuses = await fetchLatestStatuses(issues.map(issue => ({
    eventId: issue.eventId,
    repoOwnerPubkey: pubkey,
  })));

  for (const issue of issues) {
    issue.status = statuses.get(issue.eventId) ?? 'open';
  }

  // Sort by created_at descending (newest first)
  return issues.sort((a, b) => b.created_at - a.created_at);
}

/**
 * Fetch the latest status for PRs or issues in a single query.
 */
export async function fetchLatestStatuses(
  targets: Array<{ eventId: string; repoOwnerPubkey: string }>
): Promise<Map<string, ItemStatus>> {
  const ownersByEventId = new Map<string, string>();
  for (const target of targets) {
    if (!target.eventId || !target.repoOwnerPubkey) continue;
    ownersByEventId.set(target.eventId, target.repoOwnerPubkey);
  }

  if (ownersByEventId.size === 0) {
    return new Map();
  }

  const filter: NostrFilter = {
    kinds: [KIND_STATUS_OPEN, KIND_STATUS_APPLIED, KIND_STATUS_CLOSED, KIND_STATUS_DRAFT],
    '#e': Array.from(ownersByEventId.keys()),
    limit: Math.max(ownersByEventId.size * 8, 32),
  };

  const events = await fetchEventsViaSubscribe(filter, 3000);
  const latestStatuses = new Map<string, { kind: number; created_at: number }>();

  for (const event of events) {
    const targetEventId = getTargetEventIdFromTags(event.tags);
    if (!targetEventId) continue;

    const repoOwnerPubkey = ownersByEventId.get(targetEventId);
    if (!repoOwnerPubkey) continue;

    const isFromMaintainer = event.pubkey === repoOwnerPubkey;
    if (!isFromMaintainer) continue;

    const currentLatest = latestStatuses.get(targetEventId);
    if (!currentLatest || (event.created_at ?? 0) > currentLatest.created_at) {
      latestStatuses.set(targetEventId, {
        kind: event.kind!,
        created_at: event.created_at ?? 0,
      });
    }
  }

  const statuses = new Map<string, ItemStatus>();
  for (const [eventId, latest] of latestStatuses) {
    statuses.set(eventId, kindToStatus(latest.kind));
  }

  return statuses;
}

/**
 * Parse a PR event into a PullRequest object
 */
export function parsePullRequestEvent(event: NostrEvent): PullRequest | null {
  if (!event.id || !event.pubkey) return null;

  const tags = event.tags;
  const title = tags.find(t => t[0] === 'subject')?.[1] || tags.find(t => t[0] === 'title')?.[1] || 'Untitled PR';
  const branch = tags.find(t => t[0] === 'branch')?.[1];
  const targetBranch = tags.find(t => t[0] === 'target-branch')?.[1] || 'main';
  const commitTip = tags.find(t => t[0] === 'c')?.[1]; // commit tip
  const cloneUrl = tags.find(t => t[0] === 'clone')?.[1];
  const labels = tags.filter(t => t[0] === 't').map(t => t[1]);

  return {
    id: event.id,
    eventId: event.id,
    title,
    description: event.content || '',
    author: pubkeyToNpub(event.pubkey),
    authorPubkey: event.pubkey,
    status: 'open', // Will be updated by status fetch
    branch,
    targetBranch,
    commitTip,
    cloneUrl,
    created_at: event.created_at || 0,
    updated_at: event.created_at || 0, // TODO: track updates
    labels,
  };
}

/**
 * Parse an issue event into an Issue object
 */
export function parseIssueEvent(event: NostrEvent): Issue | null {
  if (!event.id || !event.pubkey) return null;

  const tags = event.tags;
  const title = tags.find(t => t[0] === 'subject')?.[1] || tags.find(t => t[0] === 'title')?.[1] || 'Untitled Issue';
  const labels = tags.filter(t => t[0] === 't').map(t => t[1]);

  return {
    id: event.id,
    eventId: event.id,
    title,
    description: event.content || '',
    author: pubkeyToNpub(event.pubkey),
    authorPubkey: event.pubkey,
    status: 'open', // Will be updated by status fetch
    created_at: event.created_at || 0,
    updated_at: event.created_at || 0,
    labels,
  };
}

/**
 * Create a new pull request
 */
export async function createPullRequest(
  npub: string,
  repoName: string,
  title: string,
  description: string,
  options: {
    branch?: string;
    targetBranch?: string;
    commitTip?: string;
    labels?: string[];
    /** Custom clone URL for cross-repo PRs (npub/path or nhash format) */
    cloneUrl?: string;
  } = {}
): Promise<PullRequest | null> {
  const state = nostrStore.getState();
  if (!state.pubkey || !nostr.signer) return null;

  const repoAddress = buildRepoAddress(npub, repoName);
  // Use custom clone URL if provided (for cross-repo PRs), otherwise default to target repo
  const cloneUrl = options.cloneUrl || buildHtreeUrl(npub, repoName);

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_PULL_REQUEST;
  event.content = description;
  event.tags = [
    ['a', repoAddress],
    ['p', npubToPubkey(npub)!], // Notify repo owner
    ['subject', title],
    ['clone', cloneUrl],
  ];

  if (options.branch) {
    event.tags.push(['branch', options.branch]);
  }
  if (options.targetBranch) {
    event.tags.push(['target-branch', options.targetBranch]);
  }
  if (options.commitTip) {
    event.tags.push(['c', options.commitTip]);
  }
  for (const label of options.labels || []) {
    event.tags.push(['t', label]);
  }

  try {
    const signedEvent = await publishNip34Event(event);

    return {
      id: signedEvent.id,
      eventId: signedEvent.id,
      title,
      description,
      author: state.npub!,
      authorPubkey: state.pubkey,
      status: 'open',
      branch: options.branch,
      targetBranch: options.targetBranch || 'main',
      commitTip: options.commitTip,
      cloneUrl,
      created_at: event.created_at || Math.floor(Date.now() / 1000),
      updated_at: event.created_at || Math.floor(Date.now() / 1000),
      labels: options.labels || [],
    };
  } catch (e) {
    if (e instanceof GitCollaborationPrivacyError) throw e;
    console.error('Failed to create pull request:', e);
    return null;
  }
}

/**
 * Create a new issue
 */
export async function createIssue(
  npub: string,
  repoName: string,
  title: string,
  description: string,
  options: {
    labels?: string[];
  } = {}
): Promise<Issue | null> {
  const state = nostrStore.getState();
  if (!state.pubkey || !nostr.signer) return null;

  const repoAddress = buildRepoAddress(npub, repoName);

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_ISSUE;
  event.content = description;
  event.tags = [
    ['a', repoAddress],
    ['p', npubToPubkey(npub)!], // Notify repo owner
    ['subject', title],
  ];

  for (const label of options.labels || []) {
    event.tags.push(['t', label]);
  }

  try {
    const signedEvent = await publishNip34Event(event);

    return {
      id: signedEvent.id,
      eventId: signedEvent.id,
      title,
      description,
      author: state.npub!,
      authorPubkey: state.pubkey,
      status: 'open',
      created_at: event.created_at || Math.floor(Date.now() / 1000),
      updated_at: event.created_at || Math.floor(Date.now() / 1000),
      labels: options.labels || [],
    };
  } catch (e) {
    if (e instanceof GitCollaborationPrivacyError) throw e;
    console.error('Failed to create issue:', e);
    return null;
  }
}

/**
 * Update the status of a PR or issue
 */
export async function updateStatus(
  targetEventId: string,
  targetAuthorPubkey: string,
  newStatus: ItemStatus
): Promise<boolean> {
  const state = nostrStore.getState();
  if (!state.pubkey || !nostr.signer) return false;

  const statusKind = statusToKind(newStatus);

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = statusKind;
  event.content = '';
  event.tags = [
    ['e', targetEventId],
    ['p', targetAuthorPubkey],
  ];

  try {
    await publishNip34Event(event);
    return true;
  } catch (e) {
    if (e instanceof GitCollaborationPrivacyError) throw e;
    console.error('Failed to update status:', e);
    return false;
  }
}
