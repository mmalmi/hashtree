import { DEFAULT_PUBLIC_RELAYS } from './defaultRelays';

function normalizedRelay(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (!['ws:', 'wss:'].includes(url.protocol)) return null;
    return url.href.replace(/\/$/, '');
  } catch {
    return null;
  }
}

/** Fixed public graph bootstrap is only allowed with the shipped relay set. */
export function shouldBootstrapPublicGraph(relays: readonly string[]): boolean {
  const normalized = relays.map(normalizedRelay);
  if (normalized.some(relay => relay === null)) return false;
  const actual = new Set(normalized);
  const defaults = new Set(DEFAULT_PUBLIC_RELAYS.map(normalizedRelay));
  return actual.size === defaults.size && [...defaults].every(relay => actual.has(relay));
}
