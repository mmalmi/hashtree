import { DEFAULT_PUBLIC_RELAYS as SHARED_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
const RELAY_NOS_LOL = 'wss://nos.lol';

// nos.lol is the standard fallback when an author has no NIP-65 relay list.
// Keep it in the app defaults so a fresh browser can discover public tree roots
// that have not propagated to every shared Iris relay yet.
export const DEFAULT_PUBLIC_RELAYS = Array.from(new Set([
  ...SHARED_PUBLIC_RELAYS,
  RELAY_NOS_LOL,
]));

export const DEFAULT_E2E_PRODUCTION_RELAYS = [...DEFAULT_PUBLIC_RELAYS];
