import type { TreeVisibility } from '@hashtree/core';
import { parseHtreeUrl } from '@hashtree/git';
import { HASHTREE_ROOT_KINDS, parseHashtreeRootEvent } from '@hashtree/nostr';
import { treeRootRegistry } from '@hashtree/worker/tree-root';
import { nip19, type Event, type EventTemplate, type Filter } from 'nostr-tools';
import { waitForWorkerAdapter } from './workerInit';
import { KIND_ISSUE, KIND_PULL_REQUEST, KIND_REPO_ANNOUNCEMENT, KIND_TEXT_NOTE } from '../utils/constants';

export function getGitCollaborationDisabledReason(visibility?: TreeVisibility): string | null {
  if (visibility === 'public') return null;
  if (!visibility) return 'Publishing is unavailable until repository visibility is confirmed.';
  return 'Issues, pull requests and comments are currently available only for public repositories.';
}

export class GitCollaborationPrivacyError extends Error {}

function unavailable(visibility?: TreeVisibility): never {
  throw new GitCollaborationPrivacyError(getGitCollaborationDisabledReason(visibility) ??
    'Repository visibility could not be confirmed.');
}

async function queryEvents(filter: Filter): Promise<Event[]> {
  try {
    const backend = await waitForWorkerAdapter(5000);
    if (!backend?.queryEvents) return unavailable();
    // The backend returns verified events from its storage and network sources.
    return (await backend.queryEvents([filter], { deadline: Date.now() + 5000 })).events;
  } catch {
    return unavailable();
  }
}

function repoAddresses(event: EventTemplate): string[] {
  return [...new Set(event.tags.filter(tag => tag[0] === 'a').map(tag => tag[1]))];
}

async function assertPublicRepo(address: string): Promise<void> {
  const match = /^30617:([0-9a-f]{64}):(.+)$/.exec(address);
  if (!match) return unavailable();
  const [, pubkey, repoName] = match;
  const treeName = repoName.split('/')[0];
  const npub = nip19.npubEncode(pubkey);
  const assertLocalPrivacy = () => {
    const record = treeRootRegistry.get(npub, treeName);
    if (record && record.visibility !== 'public') unavailable(record.visibility);
  };
  assertLocalPrivacy();

  // Registry entries can default to public before metadata arrives. Require an
  // actual owner-authored root event, including for repositories in subdirectories.
  const events = await queryEvents({ kinds: [...HASHTREE_ROOT_KINDS], authors: [pubkey], '#d': [treeName] });
  const latest = events
    .filter(event => event.pubkey === pubkey && HASHTREE_ROOT_KINDS.some(kind => kind === event.kind) &&
      event.tags.find(tag => tag[0] === 'd')?.[1] === treeName)
    .sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id))[0];
  if (!latest) return unavailable();
  let root;
  try {
    root = parseHashtreeRootEvent(latest);
  } catch {
    return unavailable();
  }
  if (!root || root.visibility !== 'public') return unavailable(root?.visibility);
  assertLocalPrivacy();
}

/** Guard all collaboration writes, including callers bypassing the dialogs. */
export async function assertPublicGitCollaboration(event: EventTemplate): Promise<void> {
  // Repository announcement publishing is separate from collaboration writes.
  if (event.kind === KIND_REPO_ANNOUNCEMENT) return;
  const addresses = repoAddresses(event);
  if (event.kind === KIND_PULL_REQUEST) {
    // A public destination must not expose a private fork or a secret clone URL.
    for (const cloneUrl of event.tags.filter(tag => tag[0] === 'clone').flatMap(tag => tag.slice(1))) {
      try {
        const source = parseHtreeUrl(cloneUrl.startsWith('npub1') ? `htree://${cloneUrl}` : cloneUrl);
        if (source.visibility !== 'public') return unavailable(source.visibility);
        const owner = nip19.decode(source.identifier);
        if (owner.type !== 'npub') return unavailable();
        addresses.push(`30617:${owner.data}:${source.repo}`);
      } catch (error) {
        if (error instanceof GitCollaborationPrivacyError) throw error;
        return unavailable();
      }
    }
  }
  const isStatus = event.kind >= 1630 && event.kind <= 1633;
  if (event.kind === KIND_TEXT_NOTE || isStatus) {
    const targetId = event.tags.find(tag => tag[0] === 'e')?.[1];
    if (!targetId) return unavailable();
    const targets = await queryEvents({ ids: [targetId] });
    const target = targets.find(item => item.id === targetId &&
      (item.kind === KIND_ISSUE || item.kind === KIND_PULL_REQUEST));
    if (!target) return unavailable();
    const targetAddresses = repoAddresses(target);
    if (!targetAddresses.length || addresses.some(address => !targetAddresses.includes(address))) return unavailable();
    addresses.push(...targetAddresses);
  }
  if (!addresses.length) return unavailable();
  for (const address of new Set(addresses)) await assertPublicRepo(address);
}
