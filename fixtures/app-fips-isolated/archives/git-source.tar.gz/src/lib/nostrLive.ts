/**
 * Live reads and background publication.
 *
 * Nothing on screen waits for a relay to answer. A read is an open
 * subscription: each event is handed over the moment it arrives and "history"
 * only says that the absence of an event may now be shown. A write is shown at
 * once and handed to the backend, which stores it, sends it to every relay and
 * retries the ones which are down.
 */
import { matchFilters, type Event, type Filter } from 'nostr-tools';
import { nostr } from '../nostr';

const MAX_LOCAL_EVENTS = 200;
/** Events written on this page, so every open and later view shows them at once. */
const localEvents = new Map<string, Event>();
const localListeners = new Set<(event: Event, removed: boolean) => void>();

function matches(filters: Filter[], event: Event): boolean {
  try {
    return matchFilters(filters.map(({ limit: _limit, ...rest }) => rest), event);
  } catch {
    return false;
  }
}

function notifyLocal(event: Event, removed: boolean): void {
  for (const listener of [...localListeners]) listener(event, removed);
}

export interface WatchHandlers {
  event(event: Event): void;
  /** Stored history has been delivered. Called once; later events still arrive. */
  history?(): void;
  /** An event shown from this page could not be handed over for publication. */
  removed?(id: string): void;
}

/** Returns a function that ends the watch. Events written here may be delivered before it returns. */
export function watchEvents(filters: Filter | Filter[], handlers: WatchHandlers): () => void {
  const list = Array.isArray(filters) ? filters : [filters];
  const seen = new Set<string>();
  let stopped = false;
  let historyDone = false;

  const deliver = (event: Event) => {
    if (stopped || seen.has(event.id)) return;
    seen.add(event.id);
    handlers.event(event);
  };
  const onLocal = (event: Event, removed: boolean) => {
    if (stopped || !matches(list, event)) return;
    if (!removed) return deliver(event);
    seen.delete(event.id);
    handlers.removed?.(event.id);
  };

  localListeners.add(onLocal);
  for (const event of [...localEvents.values()]) {
    if (matches(list, event)) deliver(event);
  }

  const subscription = nostr.subscribe(list);
  subscription.on('event', deliver);
  subscription.on('history', () => {
    if (stopped || historyDone) return;
    historyDone = true;
    handlers.history?.();
  });

  return () => {
    if (stopped) return;
    stopped = true;
    localListeners.delete(onLocal);
    subscription.stop();
  };
}

function rememberLocal(event: Event): void {
  localEvents.set(event.id, event);
  if (localEvents.size > MAX_LOCAL_EVENTS) localEvents.delete(localEvents.keys().next().value!);
  notifyLocal(event, false);
}

async function enqueue(event: Event): Promise<void> {
  const receipt = await nostr.publish(event) as { accepted?: boolean; queued?: boolean } | undefined;
  if (receipt?.accepted === false && receipt.queued === false) {
    throw new Error('The event was not accepted for publication.');
  }
}

/** The backend acknowledges its local outbox before waiting for remote delivery. */
export async function publishStoredEvent(event: Event): Promise<void> {
  await enqueue(event);
  rememberLocal(event);
}

/**
 * Show a signed event everywhere on this page now and publish it without
 * waiting. A relay being down is not a failure: the backend keeps the event and
 * retries. `onFailure` runs only when the event could not be handed over at all.
 */
export function publishInBackground(event: Event, onFailure?: (error: Error) => void): void {
  rememberLocal(event);
  void enqueue(event).catch((error) => {
    localEvents.delete(event.id);
    notifyLocal(event, true);
    console.error('[nostr] Could not publish event:', error);
    onFailure?.(error instanceof Error ? error : new Error(String(error)));
  });
}

/** Collect calls made close together into one. */
export function createBatcher<T>(flush: (items: T[]) => void, delayMs = 50) {
  let queued: T[] = [];
  let timer: ReturnType<typeof setTimeout> | undefined;
  return {
    add(item: T) {
      queued.push(item);
      timer ??= setTimeout(() => {
        timer = undefined;
        const items = queued;
        queued = [];
        flush(items);
      }, delayMs);
    },
    cancel() {
      clearTimeout(timer);
      timer = undefined;
      queued = [];
    },
  };
}
