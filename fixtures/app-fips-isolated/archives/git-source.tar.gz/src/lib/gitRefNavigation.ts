export type RepoRefTab = 'branches' | 'tags';

function buildRepoBaseHref(npub: string, repoName: string): string {
  const parts = [npub, ...repoName.split('/').filter(Boolean)];
  return '#/' + parts.map(encodeURIComponent).join('/');
}

export function buildRepoTabHref(
  npub: string,
  repoName: string,
  tab: RepoRefTab,
  linkKey?: string,
): string {
  const params = new URLSearchParams();
  params.set('tab', tab);
  if (linkKey) {
    params.set('k', linkKey);
  }
  return `${buildRepoBaseHref(npub, repoName)}?${params.toString()}`;
}

export function buildRepoCodeHref(
  npub: string,
  repoName: string,
  options: {
    ref?: string;
    linkKey?: string;
  } = {},
): string {
  const params = new URLSearchParams();
  if (options.ref) {
    params.set('ref', options.ref);
  }
  if (options.linkKey) {
    params.set('k', options.linkKey);
  }
  const query = params.toString();
  const baseHref = buildRepoBaseHref(npub, repoName);
  return query ? `${baseHref}?${query}` : baseHref;
}
