import { encryptKeyForLink, fromHex, toHex } from '@hashtree/core';

// Link secrets and XOR masks are opaque. Only the unmasked object key has a suite.
export function isLinkKeyHex(value: string | null | undefined): value is string {
  return typeof value === 'string' && /^(?:[0-9a-f]{2}){32,33}$/i.test(value);
}

export function recoverLinkSecret(contentKey: Uint8Array, maskedKeyHex: string): string {
  if (!isLinkKeyHex(maskedKeyHex)) throw new Error('Invalid masked root key');
  return toHex(encryptKeyForLink(contentKey, fromHex(maskedKeyHex)));
}
