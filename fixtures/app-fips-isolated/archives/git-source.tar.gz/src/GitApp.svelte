<script lang="ts">
  import { onMount } from 'svelte';
  import Logo from './components/Logo.svelte';
  import Header from './components/Header.svelte';
  import NostrLogin from './components/NostrLogin.svelte';
  import SettingsShortcut from '@iris/hashtree-app/SettingsShortcut.svelte';
  import ConnectivityIndicator from './components/ConnectivityIndicator.svelte';
  import BandwidthIndicator from './components/BandwidthIndicator.svelte';
  import SearchInput from './components/SearchInput.svelte';
  import MobileSearch from './components/MobileSearch.svelte';
  import Toast from './components/Toast.svelte';
  import Router from './components/Router.svelte';
  import { currentPath, initRouter, getQueryParams } from './lib/router.svelte';
  import { settingsStore } from './stores/settings';
  import { appStore } from './store';
  import { nostrStore } from './nostr';

  import CreateModal from './components/Modals/CreateModal.svelte';
  import RenameModal from './components/Modals/RenameModal.svelte';
  import ForkModal from './components/Modals/ForkModal.svelte';
  import ExtractModal from './components/Modals/ExtractModal.svelte';
  import GitignoreModal from './components/Modals/GitignoreModal.svelte';
  import GitHistoryModal from './components/Modals/GitHistoryModal.svelte';
  import GitCommitModal from './components/Modals/GitCommitModal.svelte';
  import CIRunsModal from './components/Modals/CIRunsModal.svelte';
  import ShareModal from './components/Modals/ShareModal.svelte';
  import CollaboratorsModal from './components/Modals/CollaboratorsModal.svelte';
  import UnsavedChangesModal from './components/Modals/UnsavedChangesModal.svelte';
  import NewPullRequestModal from './components/Git/NewPullRequestModal.svelte';
  import NewIssueModal from './components/Git/NewIssueModal.svelte';
  import ReleaseModal from './components/Git/ReleaseModal.svelte';
  import BlossomPushModal from './components/Modals/BlossomPushModal.svelte';

  function isFullscreen(): boolean {
    const params = getQueryParams();
    return params.get('fullscreen') === '1';
  }

  function clearFullscreen() {
    const hash = window.location.hash.split('?')[0];
    const params = getQueryParams();
    params.delete('fullscreen');
    const queryString = params.toString();
    window.location.hash = queryString ? `${hash}?${queryString}` : hash;
  }

  let fullscreen = $derived(isFullscreen());
  let showConnectivity = $derived($settingsStore.display.showConnectivity ?? false);
  let showBandwidth = $derived($settingsStore.display.showBandwidth ?? false);
  let totalConnections = $derived($nostrStore.connectedRelays + $appStore.peerCount);
  let showConnectivityWarning = $derived(totalConnections === 0);

  onMount(() => {
    initRouter();
  });

  function handleLogoClick(e: MouseEvent) {
    if (fullscreen) {
      e.preventDefault();
      clearFullscreen();
    } else if (window.location.hash === '#/' || window.location.hash === '' || window.location.hash === '#') {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
</script>

<div class="h-full flex flex-col bg-surface-0">
  <Header>
    <div class="flex items-center shrink-0">
      <a href="#/" onclick={handleLogoClick} class="no-underline">
        <Logo app="git" />
      </a>
    </div>
    <div class="flex-1 hidden md:flex justify-center px-4">
      <SearchInput />
    </div>
    <div class="flex-1 md:hidden"></div>
    <div class="flex items-center gap-2 md:gap-3 shrink-0">
      <MobileSearch />
      {#if showBandwidth}
        <BandwidthIndicator />
      {/if}
      {#if showConnectivity || showConnectivityWarning}
        <ConnectivityIndicator />
      {/if}
      <SettingsShortcut />
      <NostrLogin />
    </div>
  </Header>

  <div class="flex-1 flex flex-col min-h-0">
    <Router currentPath={$currentPath} />
  </div>

  <CreateModal />
  <RenameModal />
  <ForkModal />
  <ExtractModal />
  <GitignoreModal />
  <GitHistoryModal />
  <GitCommitModal />
  <CIRunsModal />
  <ShareModal />
  <CollaboratorsModal />
  <UnsavedChangesModal />
  <NewPullRequestModal />
  <NewIssueModal />
  <ReleaseModal />
  <BlossomPushModal />
  <Toast />
</div>
