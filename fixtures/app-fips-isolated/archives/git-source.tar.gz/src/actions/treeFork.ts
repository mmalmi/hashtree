import { toHex, type CID, type TreeVisibility } from '@hashtree/core';
import { nostrStore } from '../nostr';
import { getTree } from '../store';
import { buildHtreeUrl, fetchRepoAnnouncement, publishRepoAnnouncement } from '../nip34';
import { getRootCommit } from '../utils/git';
import { navigate } from '../lib/router.svelte';
import { parseRoute } from '../utils/route';
import { ignoreGeneratedProjectMetaInGitStatus, setProjectForkOrigin } from '../stores/projectMeta';

export async function forkTree(
  dirCid: CID,
  name: string,
  visibility: TreeVisibility = 'public',
): Promise<{ success: boolean; linkKey?: string }> {
  if (!name) return { success: false };

  const { saveHashtree } = await import('../nostr');
  const { storeLinkKey } = await import('../stores/trees');
  const tree = getTree();

  const nostrState = nostrStore.getState();
  if (!nostrState.npub || !nostrState.pubkey) return { success: false };

  let forkOriginUrl: string | null = null;
  let forkAnnouncementEuc: string | undefined;
  let forkMetadataApplied = false;

  try {
    const route = parseRoute();
    const sourceOwnerNpub = route.npub;
    const sourceTreeName = route.treeName;
    const sourceRepoName = sourceTreeName
      ? [sourceTreeName, ...route.path].filter(Boolean).join('/')
      : null;
    const sourceAnnouncement = sourceOwnerNpub && sourceRepoName
      ? await fetchRepoAnnouncement(sourceOwnerNpub, sourceRepoName).catch(() => null)
      : null;
    const sourceRootCommit = sourceAnnouncement?.earliestUniqueCommit ?? await getRootCommit(dirCid);
    const shouldAnnotateFork = (
      !!sourceOwnerNpub &&
      !!sourceRepoName &&
      sourceOwnerNpub !== nostrState.npub &&
      !!sourceRootCommit
    );

    if (shouldAnnotateFork && sourceOwnerNpub && sourceRepoName) {
      forkOriginUrl = buildHtreeUrl(sourceOwnerNpub, sourceRepoName);
      forkAnnouncementEuc = sourceRootCommit ?? undefined;
    }
  } catch (error) {
    console.warn('[Fork] Failed to resolve fork origin metadata', error);
  }

  const shouldReencryptFork = visibility !== 'public' && !dirCid.key;
  let finalCid = dirCid;

  if (forkOriginUrl && !finalCid.key) {
    try {
      finalCid = await setProjectForkOrigin(finalCid, forkOriginUrl);
      forkMetadataApplied = true;
    } catch (error) {
      console.warn('[Fork] Failed to annotate fork origin metadata before re-encryption', error);
    }
  }

  if (shouldReencryptFork) {
    console.log('[Fork] Source is unencrypted, re-encrypting...');

    const rebuildWithEncryption = async (oldCid: CID): Promise<CID> => {
      if (oldCid.key) return oldCid;

      const isDir = await tree.isDirectory(oldCid);
      if (isDir) {
        const entries = await tree.listDirectory(oldCid);
        const newEntries = [];
        for (const entry of entries) {
          const newChildCid = await rebuildWithEncryption(entry.cid);
          newEntries.push({
            name: entry.name,
            cid: newChildCid,
            size: entry.size,
            type: entry.type ?? 0,
            meta: entry.meta,
          });
        }
        return (await tree.putDirectory(newEntries, {})).cid;
      }

      const data = await tree.readFile(oldCid);
      if (!data) return oldCid;
      return (await tree.putFile(data, {})).cid;
    };

    finalCid = await rebuildWithEncryption(finalCid);
    console.log('[Fork] Re-encryption complete');
  }

  if (forkOriginUrl && !forkMetadataApplied) {
    try {
      finalCid = await setProjectForkOrigin(finalCid, forkOriginUrl);
      forkMetadataApplied = true;
    } catch (error) {
      console.warn('[Fork] Failed to annotate fork origin metadata', error);
    }
  }

  if (forkOriginUrl && forkMetadataApplied) {
    try {
      finalCid = await ignoreGeneratedProjectMetaInGitStatus(finalCid);
    } catch (error) {
      console.warn('[Fork] Failed to hide generated fork metadata from git status', error);
    }
  }

  nostrStore.setSelectedTree({
    id: '',
    name,
    pubkey: nostrState.pubkey,
    rootHash: toHex(finalCid.hash),
    rootKey: finalCid.key ? toHex(finalCid.key) : undefined,
    visibility,
    created_at: Math.floor(Date.now() / 1000),
  });

  const result = await saveHashtree(name, finalCid, { visibility });

  if (result.linkKey) {
    storeLinkKey(nostrState.npub, name, result.linkKey);
  }

  if (result.success && forkOriginUrl) {
    try {
      const published = await publishRepoAnnouncement(name, {
        personalFork: true,
        earliestUniqueCommit: forkAnnouncementEuc,
        forkedFrom: forkOriginUrl,
      });
      if (!published) {
        console.warn('[Fork] Failed to publish personal fork announcement', { name });
      }
    } catch (error) {
      console.warn('[Fork] Failed to publish personal fork announcement', error);
    }
  }

  if (result.success) {
    const linkKeyParam = result.linkKey ? `?k=${result.linkKey}` : '';
    navigate(`/${encodeURIComponent(nostrState.npub)}/${encodeURIComponent(name)}${linkKeyParam}`);
  }
  return result;
}
