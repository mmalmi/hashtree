/**
 * Tree operations - create, fork, verify trees
 */
import { navigate } from '../lib/router.svelte';
import { parseRoute } from '../utils/route';
import { LinkType, toHex, verifyTree, type CID } from '@hashtree/core';
import { autosaveIfOwn, linkKeyUtils, nostrStore, saveHashtree } from '../nostr';
import { nip19 } from 'nostr-tools';
import { localStore, getTree } from '../store';
import { getCurrentRootCid, getCurrentPathFromUrl } from './route';
import { updateLocalRootCache } from '../treeRootCache';
import { getRootCommit, initGitRepo } from '../utils/git';
import { publishRepoAnnouncement } from '../nip34';
import { getProfileSync } from '../stores/profile';
export { forkTree } from './treeFork';

type DirectoryEntryInput = { name: string; cid: CID; size: number; type?: LinkType };

function getGitAuthorIdentity() {
  const nostrState = nostrStore.getState();
  const profile = nostrState.pubkey ? getProfileSync(nostrState.pubkey) : undefined;
  return {
    authorName: profile?.display_name || profile?.name || profile?.username || 'Anonymous',
    authorEmail: profile?.nip05 || 'anon@hashtree.local',
  };
}

async function buildGitDirectoryCid(
  repoRootCid: CID,
  authorName: string,
  authorEmail: string,
  commitMessage: string = 'Initial commit'
): Promise<CID> {
  const tree = getTree();
  const gitFiles = await initGitRepo(repoRootCid, authorName, authorEmail, commitMessage);
  const dirMap = new Map<string, Array<{ name: string; cid: CID; size: number; type: LinkType }>>();
  dirMap.set('.git', []);

  for (const file of gitFiles) {
    if (file.isDir) {
      dirMap.set(file.name, []);
    }
  }

  for (const file of gitFiles) {
    if (file.isDir) continue;

    const { cid, size } = await tree.putFile(file.data);
    const parentDir = file.name.substring(0, file.name.lastIndexOf('/'));
    const fileName = file.name.substring(file.name.lastIndexOf('/') + 1);
    const entries = dirMap.get(parentDir);
    if (entries) {
      entries.push({ name: fileName, cid, size, type: LinkType.Blob });
    }
  }

  const sortedDirs = Array.from(dirMap.keys())
    .filter(dirPath => dirPath !== '.git')
    .sort((a, b) => b.split('/').length - a.split('/').length);

  for (const dirPath of sortedDirs) {
    const entries = dirMap.get(dirPath) || [];
    const { cid } = await tree.putDirectory(entries);
    const parentDir = dirPath.substring(0, dirPath.lastIndexOf('/'));
    const dirName = dirPath.substring(dirPath.lastIndexOf('/') + 1);
    const parentEntries = dirMap.get(parentDir);
    if (parentEntries) {
      parentEntries.push({ name: dirName, cid, size: 0, type: LinkType.Dir });
    }
  }

  const gitEntries = dirMap.get('.git') || [];
  return (await tree.putDirectory(gitEntries)).cid;
}

export async function initializeDirectoryAsGitRepo(
  dirCid: CID,
  commitMessage: string = 'Initial commit'
): Promise<CID> {
  const tree = getTree();
  const { authorName, authorEmail } = getGitAuthorIdentity();
  const gitDirCid = await buildGitDirectoryCid(dirCid, authorName, authorEmail, commitMessage);
  return tree.setEntry(dirCid, [], '.git', gitDirCid, 0, LinkType.Dir);
}

// Helper to initialize a virtual tree (when rootCid is null but we're in a tree route)
export async function initVirtualTree(entries: DirectoryEntryInput[]): Promise<CID | null> {
  const route = parseRoute();
  if (!route.npub || !route.treeName) return null;

  const tree = getTree();
  const nostrState = nostrStore.getState();

  let routePubkey: string;
  try {
    const decoded = nip19.decode(route.npub);
    if (decoded.type !== 'npub') return null;
    routePubkey = decoded.data as string;
  } catch {
    return null;
  }

  const isOwnTree = routePubkey === nostrState.pubkey;
  if (!isOwnTree) return null; // Can only create in own trees

  // Create new encrypted tree with the entries (using DirEntry format)
  const dirEntries = entries.map(e => ({
    name: e.name,
    cid: e.cid,
    size: e.size,
    type: e.type ?? LinkType.Blob,
  }));
  const { cid: newRootCid } = await tree.putDirectory(dirEntries);

  // Preserve current tree's visibility when updating
  const currentVisibility = nostrState.selectedTree?.visibility ?? 'public';

  // Update UI state immediately (uses hex for storage)
  nostrStore.setSelectedTree({
    id: '',
    name: route.treeName,
    pubkey: routePubkey,
    labels: nostrState.selectedTree?.labels,
    rootHash: toHex(newRootCid.hash),
    rootKey: newRootCid.key ? toHex(newRootCid.key) : undefined,
    visibility: currentVisibility,
    created_at: Math.floor(Date.now() / 1000),
  });

  // Save to Nostr (fire-and-forget, also updates local cache)
  void saveHashtree(route.treeName, newRootCid, { visibility: currentVisibility });

  return newRootCid;
}

// Create new folder
export async function createFolder(name: string) {
  if (!name) return;

  const rootCid = getCurrentRootCid();
  const tree = getTree();
  const currentPath = getCurrentPathFromUrl();

  // putDirectory returns CID (encrypted by default)
  const { cid: emptyDirCid } = await tree.putDirectory([]);

  if (rootCid) {
    // Add to existing tree
    const newRootCid = await tree.setEntry(
      rootCid,
      currentPath,
      name,
      emptyDirCid,
      0,
      LinkType.Dir
    );
    // Publish to nostr - resolver will pick up the update
    autosaveIfOwn(newRootCid);
  } else {
    // Initialize virtual tree with this folder
    await initVirtualTree([{ name, cid: emptyDirCid, size: 0, type: LinkType.Dir }]);
  }
}

export async function createGitRepository(name: string) {
  if (!name) return;

  const rootCid = getCurrentRootCid();
  const tree = getTree();
  const currentPath = getCurrentPathFromUrl();
  const { cid: emptyDirCid } = await tree.putDirectory([]);
  const repoRootCid = await initializeDirectoryAsGitRepo(emptyDirCid);

  if (rootCid) {
    const newRootCid = await tree.setEntry(
      rootCid,
      currentPath,
      name,
      repoRootCid,
      0,
      LinkType.Dir
    );
    autosaveIfOwn(newRootCid);
  } else {
    await initVirtualTree([{ name, cid: repoRootCid, size: 0, type: LinkType.Dir }]);
  }
}

export async function createGitRepositoryTree(
  name: string,
  visibility: import('@hashtree/core').TreeVisibility = 'public'
): Promise<{ success: boolean; npub?: string; treeName?: string; linkKey?: string }> {
  if (!name) return { success: false };

  const { saveHashtree } = await import('../nostr');
  const { storeLinkKey } = await import('../stores/trees');

  const tree = getTree();
  const nostrState = nostrStore.getState();

  if (!nostrState.isLoggedIn || !nostrState.npub || !nostrState.pubkey) {
    return { success: false };
  }

  const linkKey = visibility === 'link-visible'
    ? linkKeyUtils.generateLinkKey()
    : undefined;

  const { cid: emptyDirCid } = await tree.putDirectory([]);
  const repoRootCid = await initializeDirectoryAsGitRepo(emptyDirCid);

  nostrStore.setSelectedTree({
    id: '',
    name,
    pubkey: nostrState.pubkey,
    labels: ['git'],
    rootHash: toHex(repoRootCid.hash),
    rootKey: repoRootCid.key ? toHex(repoRootCid.key) : undefined,
    visibility,
    created_at: Math.floor(Date.now() / 1000),
  });

  const result = await saveHashtree(name, repoRootCid, { visibility, labels: ['git'], linkKey });

  if (result.linkKey) {
    storeLinkKey(nostrState.npub, name, result.linkKey);
  }

  if (result.success) {
    try {
      const earliestUniqueCommit = await getRootCommit(repoRootCid) ?? undefined;
      const published = await publishRepoAnnouncement(name, { earliestUniqueCommit });
      if (!published) {
        console.warn('[Git] Failed to publish repo announcement', { name });
      }
    } catch (error) {
      console.warn('[Git] Failed to publish repo announcement', error);
    }
  }

  if (result.success) {
    const linkKeyParam = result.linkKey ? `?k=${result.linkKey}` : '';
    navigate(`/${nostrState.npub}/${encodeURIComponent(name)}${linkKeyParam}`);
  }

  return { success: result.success, npub: nostrState.npub, treeName: name, linkKey: result.linkKey };
}

// Create new Yjs document folder (folder with .yjs config file)
export async function createDocument(name: string) {
  if (!name) return;

  const rootCid = getCurrentRootCid();
  const tree = getTree();
  const currentPath = getCurrentPathFromUrl();

  // Create .yjs config file with owner's npub as first editor
  const nostrState = nostrStore.getState();
  const ownerNpub = nostrState.npub || '';
  const yjsContent = new TextEncoder().encode(ownerNpub ? ownerNpub + '\n' : '');
  const { cid: yjsFileCid, size: yjsFileSize } = await tree.putFile(yjsContent);

  // Create directory with .yjs file inside
  const { cid: docDirCid } = await tree.putDirectory([
    { name: '.yjs', cid: yjsFileCid, size: yjsFileSize, type: LinkType.Blob }
  ]);

  if (rootCid) {
    // Add to existing tree
    const newRootCid = await tree.setEntry(
      rootCid,
      currentPath,
      name,
      docDirCid,
      0,
      LinkType.Dir
    );
    // Publish to nostr
    autosaveIfOwn(newRootCid);

    // Update local cache for subsequent saves (visibility is preserved from selectedTree)
    const route = parseRoute();
    const nostrState = nostrStore.getState();
    if (nostrState.npub && route.treeName) {
      updateLocalRootCache(nostrState.npub, route.treeName, newRootCid.hash, newRootCid.key, nostrState.selectedTree?.visibility);
    }
  } else {
    // Initialize virtual tree with this document folder
    await initVirtualTree([{ name, cid: docDirCid, size: 0, type: LinkType.Dir }]);
  }
}

// Create a new tree (top-level folder on nostr or local)
// Creates encrypted trees by default
// Set skipNavigation=true to create without navigating (for batch creation)
export async function createTree(name: string, visibility: import('@hashtree/core').TreeVisibility = 'public', skipNavigation = false): Promise<{ success: boolean; linkKey?: string }> {
  if (!name) return { success: false };

  const { saveHashtree } = await import('../nostr');
  const { storeLinkKey } = await import('../stores/trees');

  const tree = getTree();
  // Create encrypted empty directory (default)
  const { cid: rootCid } = await tree.putDirectory([]);

  const nostrState = nostrStore.getState();

  // If logged in, publish to nostr
  if (nostrState.isLoggedIn && nostrState.npub && nostrState.pubkey) {
    // Set selectedTree BEFORE saving so updates work (only if we're navigating)
    if (!skipNavigation) {
      nostrStore.setSelectedTree({
        id: '', // Will be set by actual nostr event
        name,
        pubkey: nostrState.pubkey,
        rootHash: toHex(rootCid.hash),
        rootKey: rootCid.key ? toHex(rootCid.key) : undefined,
        visibility,
        created_at: Math.floor(Date.now() / 1000),
      });
    }

    // Save to Nostr (also updates local cache immediately for subsequent operations)
    const result = await saveHashtree(name, rootCid, { visibility });

    // For link-visible trees, store link key locally and append to URL
    if (result.linkKey) {
      storeLinkKey(nostrState.npub, name, result.linkKey);
    }

    if (!skipNavigation) {
      const linkKeyParam = result.linkKey ? `?k=${result.linkKey}` : '';
      navigate(`/${encodeURIComponent(nostrState.npub)}/${encodeURIComponent(name)}${linkKeyParam}`);
    }
    return result;
  }

  // Not logged in - can't create trees without nostr
  return { success: false };
}

// Create a new standalone document tree with a .yjs config file.
export async function createDocumentTree(
  name: string,
  visibility: import('@hashtree/core').TreeVisibility = 'public'
): Promise<{ success: boolean; npub?: string; treeName?: string; linkKey?: string }> {
  if (!name) return { success: false };

  const { saveHashtree } = await import('../nostr');
  const { storeLinkKey } = await import('../stores/trees');

  const tree = getTree();
  const nostrState = nostrStore.getState();

  if (!nostrState.isLoggedIn || !nostrState.npub || !nostrState.pubkey) {
    return { success: false };
  }

  const treeName = `docs/${name}`;
  const linkKey = visibility === 'link-visible'
    ? linkKeyUtils.generateLinkKey()
    : undefined;

  // Create .yjs config file with owner's npub as first editor
  const yjsContent = new TextEncoder().encode(nostrState.npub + '\n');
  const { cid: yjsFileCid, size: yjsFileSize } = await tree.putFile(yjsContent);

  // Create root directory with .yjs file inside
  const { cid: rootCid } = await tree.putDirectory([
    { name: '.yjs', cid: yjsFileCid, size: yjsFileSize, type: LinkType.Blob }
  ]);

  // Set selectedTree for updates
  nostrStore.setSelectedTree({
    id: '',
    name: treeName,
    pubkey: nostrState.pubkey,
    labels: ['docs'],
    rootHash: toHex(rootCid.hash),
    rootKey: rootCid.key ? toHex(rootCid.key) : undefined,
    visibility,
    created_at: Math.floor(Date.now() / 1000),
  });

  // Save to Nostr with docs label (also updates local cache)
  const publishPromise = saveHashtree(treeName, rootCid, { visibility, labels: ['docs'], linkKey });
  let result: { success: boolean; linkKey?: string };
  if (import.meta.env.VITE_TEST_MODE) {
    void publishPromise;
    result = { success: true, linkKey };
  } else {
    result = await publishPromise;
  }

  // Store link key for link-visible documents
  if (result.linkKey) {
    storeLinkKey(nostrState.npub, treeName, result.linkKey);
  }

  return { success: true, npub: nostrState.npub, treeName, linkKey: result.linkKey };
}

// Verify tree
export async function verifyCurrentTree(): Promise<{ valid: boolean; missing: number }> {
  const rootCid = getCurrentRootCid();
  if (!rootCid) return { valid: false, missing: 0 };

  const { valid, missing } = await verifyTree(localStore, rootCid.hash);
  return { valid, missing: missing.length };
}

// Clear store
export function clearStore() {
  localStore.clear();
  navigate('/');
}
