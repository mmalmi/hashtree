export { DEFAULT_IGNORE_PATTERNS } from '@iris/hashtree-app/gitignore';
