/**
 * Social Graph integration using Unified Worker
 * Provides follow distance calculations and trust indicators
 * Heavy operations happen in worker, main thread keeps sync cache for UI
 */
import { writable, get } from 'svelte/store';
import { getWorkerAdapter } from '../workerAdapter';
import { nostrStore } from '../nostr/store';
import { LRUCache } from './lruCache';

// ============================================================================
// Sync Caches (for immediate UI access) - Using LRU eviction
// ============================================================================

// Cache size limits to prevent memory bloat
const CACHE_MAX_SIZE = 1000;
const FOLLOWING_CACHE_MAX_SIZE = 5000; // Larger since it's checked frequently

const followDistanceCache = new LRUCache<string, number>(CACHE_MAX_SIZE);
const isFollowingCache = new LRUCache<string, boolean>(FOLLOWING_CACHE_MAX_SIZE);
const followsCache = new LRUCache<string, Set<string>>(CACHE_MAX_SIZE);
const followersCache = new LRUCache<string, Set<string>>(CACHE_MAX_SIZE);

// Track pending fetches to avoid duplicate requests and flickering
const pendingFollowersFetches = new Set<string>();
const pendingProfileFollows = new Set<string>();
const pendingProfileFollowers = new Set<string>();

// ============================================================================
// Svelte Store
// ============================================================================

interface SocialGraphState {
  version: number;
}

function createSocialGraphStore() {
  const { subscribe, update } = writable<SocialGraphState>({
    version: 0,
  });

  // Debounce version increments to prevent cascade re-renders
  let pendingIncrement = false;
  let incrementTimeout: ReturnType<typeof setTimeout> | null = null;

  const flushIncrement = () => {
    if (pendingIncrement) {
      update(state => ({ ...state, version: state.version + 1 }));
      pendingIncrement = false;
    }
    incrementTimeout = null;
  };

  return {
    subscribe,
    setVersion: (version: number) => {
      update(state => ({ ...state, version }));
      // Note: Don't clear caches here - they use LRU eviction and will be
      // refreshed on access. Clearing on every version update causes flicker.
    },
    incrementVersion: () => {
      // Debounce: batch multiple increments into one update after 100ms idle
      pendingIncrement = true;
      if (incrementTimeout) clearTimeout(incrementTimeout);
      incrementTimeout = setTimeout(flushIncrement, 100);
    },
    getState: (): SocialGraphState => get(socialGraphStore),
  };
}

export const socialGraphStore = createSocialGraphStore();

// ============================================================================
// Version callback setup (called after worker ready)
// ============================================================================

export function setupVersionCallback() {
  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.onSocialGraphVersion((version) => {
      socialGraphStore.setVersion(version);
    });
    flushPendingProfileFetches();
  }
}

// ============================================================================
// Public API (sync where possible, async fallback)
// ============================================================================

/**
 * Get follow distance (sync, returns cached or 1000)
 */
export function getFollowDistance(pubkey: string | null | undefined): number {
  if (!pubkey) return 1000;

  const cached = followDistanceCache.get(pubkey);
  if (cached !== undefined) return cached;

  // Trigger async fetch
  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.getFollowDistance(pubkey)
      .then(d => {
        followDistanceCache.set(pubkey, d);
        socialGraphStore.incrementVersion();
      })
      .catch(() => {});
  }
  return 1000;
}

/**
 * Check if one user follows another (sync)
 */
export function isFollowing(
  follower: string | null | undefined,
  followedUser: string | null | undefined
): boolean {
  if (!follower || !followedUser) return false;

  const key = `${follower}:${followedUser}`;
  const cached = isFollowingCache.get(key);
  if (cached !== undefined) return cached;

  // Trigger async fetch
  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.isFollowing(follower, followedUser)
      .then(r => {
        isFollowingCache.set(key, r);
        socialGraphStore.incrementVersion();
      })
      .catch(() => {});
  }
  return false;
}

/**
 * Get users followed by a user (sync)
 */
export function getFollows(pubkey: string | null | undefined): Set<string> {
  if (!pubkey) return new Set();

  const cached = followsCache.get(pubkey);
  if (cached) return cached;

  // Trigger async fetch
  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.getFollows(pubkey)
      .then(arr => {
        followsCache.set(pubkey, new Set(arr));
        socialGraphStore.incrementVersion();
      })
      .catch(() => {});
  }
  return new Set();
}

// Track version at which we last fetched followers for each pubkey
const followersFetchedAtVersion = new LRUCache<string, number>(CACHE_MAX_SIZE);
// Track pubkeys we're actively watching (profile views)
const watchedFollowersPubkeys = new Set<string>();

/**
 * Get followers of a user (sync)
 * Returns cached value immediately, triggers background fetch if not cached
 * or if version changed since last fetch for watched pubkeys.
 */
export function getFollowers(pubkey: string | null | undefined): Set<string> {
  if (!pubkey) return new Set();

  const cached = followersCache.get(pubkey);
  const currentVersion = socialGraphStore.getState().version;
  const lastFetchedVersion = followersFetchedAtVersion.get(pubkey) ?? -1;
  const isWatched = watchedFollowersPubkeys.has(pubkey);

  // If we have cache and (not watched OR version hasn't changed), use cache
  if (cached && (!isWatched || lastFetchedVersion >= currentVersion)) {
    return cached;
  }

  // Avoid duplicate fetches
  if (pendingFollowersFetches.has(pubkey)) {
    return cached || new Set();
  }

  // Trigger async fetch
  const adapter = getWorkerAdapter();
  if (adapter) {
    const requestVersion = currentVersion;
    pendingFollowersFetches.add(pubkey);
    adapter.getFollowers(pubkey)
      .then(arr => {
        followersCache.set(pubkey, new Set(arr));
        pendingFollowersFetches.delete(pubkey);
        followersFetchedAtVersion.set(pubkey, requestVersion);
        // Only increment version if data actually changed
        const oldSize = cached?.size ?? 0;
        const resolvedVersion = socialGraphStore.getState().version;
        if (arr.length !== oldSize || requestVersion < resolvedVersion) {
          socialGraphStore.incrementVersion();
        }
      })
      .catch(() => {
        pendingFollowersFetches.delete(pubkey);
      });
  }
  return cached || new Set();
}

/**
 * Get users who follow a given pubkey (from friends)
 */
export function getFollowedByFriends(pubkey: string | null | undefined): Set<string> {
  if (!pubkey) return new Set();

  const cached = followersCache.get(pubkey);
  if (cached) return cached;

  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.getFollowedByFriends(pubkey)
      .then(arr => {
        followersCache.set(pubkey, new Set(arr));
        socialGraphStore.incrementVersion();
      })
      .catch(() => {});
  }
  return new Set();
}

/**
 * Check if a user follows the current logged-in user
 */
export function getFollowsMe(pubkey: string | null | undefined): boolean {
  const myPubkey = nostrStore.getState().pubkey;
  if (!pubkey || !myPubkey) return false;
  return isFollowing(pubkey, myPubkey);
}

/**
 * Fetch a user's follow list when visiting their profile.
 * Only fetches if we don't already have their follow list.
 * Call this when a ProfileView mounts.
 */
export function fetchUserFollows(pubkey: string | null | undefined): void {
  if (!pubkey) return;
  const adapter = getWorkerAdapter();
  if (adapter) {
    adapter.fetchUserFollows(pubkey);
  } else {
    pendingProfileFollows.add(pubkey);
  }
}

/**
 * Fetch followers of a user when visiting their profile.
 * Subscribes to kind:3 events with #p tag mentioning this user.
 * Call this when a ProfileView mounts.
 */
export function fetchUserFollowers(pubkey: string | null | undefined): void {
  if (!pubkey) return;
  const adapter = getWorkerAdapter();
  if (adapter) {
    // Mark as watched so we re-fetch on version changes
    watchedFollowersPubkeys.add(pubkey);
    // Invalidate version tracking so next getFollowers call fetches fresh
    followersFetchedAtVersion.delete(pubkey);
    adapter.fetchUserFollowers(pubkey);
  } else {
    // Track intent to fetch once worker is ready.
    watchedFollowersPubkeys.add(pubkey);
    followersFetchedAtVersion.delete(pubkey);
    pendingProfileFollowers.add(pubkey);
  }
}

function flushPendingProfileFetches(): void {
  if (pendingProfileFollows.size === 0 && pendingProfileFollowers.size === 0) return;
  const adapter = getWorkerAdapter();
  if (!adapter) return;
  for (const pubkey of pendingProfileFollows) {
    adapter.fetchUserFollows(pubkey);
  }
  pendingProfileFollows.clear();
  for (const pubkey of pendingProfileFollowers) {
    adapter.fetchUserFollowers(pubkey);
  }
  pendingProfileFollowers.clear();
}

/**
 * Stop watching followers for a pubkey (call when leaving profile view)
 */
export function unwatchUserFollowers(pubkey: string | null | undefined): void {
  if (!pubkey) return;
  watchedFollowersPubkeys.delete(pubkey);
}
