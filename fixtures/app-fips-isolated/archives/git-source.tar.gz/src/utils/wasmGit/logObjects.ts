import type { CID } from '@hashtree/core';
import { getTree } from '../../store';
import { isFullSha, readPackedRefs, readRefSha } from './refs';
import { getHead } from './logHead';
import { readGitObject } from './logPacks';
import type { ParsedCommit, ParsedTag } from './logTypes';

const parsedCommitCache = new Map<string, ParsedCommit | null>();

export function parseCommit(content: Uint8Array): ParsedCommit | null {
  const text = new TextDecoder().decode(content);
  const lines = text.split('\n');

  let tree = '';
  const parents: string[] = [];
  let author = '';
  let email = '';
  let timestamp = 0;
  let messageStart = -1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line === '') {
      messageStart = i + 1;
      break;
    }

    if (line.startsWith('tree ')) {
      tree = line.slice(5);
    } else if (line.startsWith('parent ')) {
      parents.push(line.slice(7));
    } else if (line.startsWith('author ')) {
      // Format: "author Name <email> timestamp timezone"
      const match = line.match(/^author (.+) <(.+)> (\d+)/);
      if (match) {
        author = match[1];
        email = match[2];
        timestamp = parseInt(match[3], 10);
      }
    }
  }

  const message = messageStart >= 0 ? lines.slice(messageStart).join('\n').trim() : '';

  return { tree, parents, author, email, timestamp, message };
}

function parseTag(content: Uint8Array): ParsedTag | null {
  const text = new TextDecoder().decode(content);
  const lines = text.split('\n');

  let object = '';
  let type = '';

  for (const line of lines) {
    if (line === '') break;
    if (line.startsWith('object ')) {
      object = line.slice(7).trim();
    } else if (line.startsWith('type ')) {
      type = line.slice(5).trim();
    }
  }

  if (!isFullSha(object) || !type) {
    return null;
  }

  return { object: object.toLowerCase(), type };
}

export async function getParsedCommitFromSha(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<ParsedCommit | null> {
  if (parsedCommitCache.has(sha)) {
    return parsedCommitCache.get(sha) ?? null;
  }

  const obj = await readGitObject(tree, gitDirCid, sha);
  if (!obj || obj.type !== 'commit') {
    return null;
  }

  const parsed = parseCommit(obj.content);
  parsedCommitCache.set(sha, parsed);
  return parsed;
}

async function peelObjectToCommit(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string,
  seen = new Set<string>()
): Promise<string | null> {
  const normalizedSha = sha.toLowerCase();
  if (seen.has(normalizedSha)) {
    return null;
  }
  seen.add(normalizedSha);

  const obj = await readGitObject(tree, gitDirCid, normalizedSha);
  if (!obj) {
    return null;
  }

  if (obj.type === 'commit') {
    return normalizedSha;
  }

  if (obj.type !== 'tag') {
    return null;
  }

  const parsed = parseTag(obj.content);
  if (!parsed) {
    return null;
  }

  if (parsed.type === 'commit') {
    return parsed.object;
  }

  return peelObjectToCommit(tree, gitDirCid, parsed.object, seen);
}

export async function resolveNamedRefToCommit(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  rootCid: CID,
  ref: string
): Promise<string | null> {
  const candidates = ref.startsWith('refs/')
    ? [ref]
    : [`refs/heads/${ref}`, `refs/tags/${ref}`];

  const packedRefs = await readPackedRefs(tree, gitDirCid);

  for (const candidate of candidates) {
    const isBranchRef = candidate.startsWith('refs/heads/');
    const looseSha = await readRefSha(tree, gitDirCid, candidate);
    if (looseSha) {
      if (isBranchRef) {
        return looseSha;
      }
      const peeled = await peelObjectToCommit(tree, gitDirCid, looseSha);
      if (peeled) {
        return peeled;
      }
    }

    const packed = packedRefs.get(candidate);
    if (packed?.peeled) {
      return packed.peeled;
    }
    if (packed?.sha) {
      if (isBranchRef) {
        return packed.sha;
      }
      const peeled = await peelObjectToCommit(tree, gitDirCid, packed.sha);
      if (peeled) {
        return peeled;
      }
    }
  }

  if (ref === 'HEAD') {
    return getHead(rootCid);
  }

  return null;
}
