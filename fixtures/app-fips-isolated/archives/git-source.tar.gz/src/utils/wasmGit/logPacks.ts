import type { CID, TreeEntry, TreeNode } from '@hashtree/core';
import { LinkType, toHex } from '@hashtree/core';
import { unzlibSync } from 'fflate';
import { getTree } from '../../store';
import type { GitObject } from './logTypes';

// Commits, trees and deltas are small: inflating them in place avoids a stream
// round trip per object. Larger inputs keep the main thread free.
const SYNC_INFLATE_LIMIT = 256 * 1024;

async function decompressZlib(data: Uint8Array): Promise<Uint8Array> {
  if (data.length <= SYNC_INFLATE_LIMIT) {
    try {
      return unzlibSync(data);
    } catch {
      // Fall through to the streaming decoder.
    }
  }
  const stream = new Blob([new Uint8Array(data)]).stream()
    .pipeThrough(new DecompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export function gitDirCacheKey(gitDirCid: CID): string {
  return gitDirCid.key ? `${toHex(gitDirCid.hash)}:${toHex(gitDirCid.key)}` : toHex(gitDirCid.hash);
}

const HEX = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, '0'));

interface PackIndexData {
  shas: string[];
  offsets: number[];
  sortedOffsets: number[];
  shaToOffset: Map<string, number>;
}

// Cache for pack indexes and successfully read objects per git directory
const packIndexCache = new Map<string, Map<string, Promise<PackIndexData | null>>>();
const gitObjectCache = new Map<string, Map<string, Promise<GitObject | null>>>();

/**
 * Load pack index file (.idx) and return the SHA -> offset mapping
 */
export function loadPackIndex(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  idxName: string
): Promise<PackIndexData | null> {
  // Concurrent lookups share one load; failed loads are retried.
  const cacheKey = gitDirCacheKey(gitDirCid);
  let dirCache = packIndexCache.get(cacheKey);
  if (!dirCache) {
    dirCache = new Map();
    packIndexCache.set(cacheKey, dirCache);
  }
  const cache = dirCache;
  let pending = cache.get(idxName);
  if (!pending) {
    pending = readPackIndex(tree, gitDirCid, idxName);
    cache.set(idxName, pending);
    void pending.then(index => {
      if (!index && cache.get(idxName) === pending) cache.delete(idxName);
    });
  }
  return pending;
}

async function readPackIndex(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  idxName: string
): Promise<PackIndexData | null> {
  try {
    const idxEntry = (await getPackEntries(tree, gitDirCid)).find(entry => entry.name === idxName);
    if (!idxEntry || idxEntry.type === LinkType.Dir) {
      return null;
    }

    const idxData = idxEntry.size > 0
      ? await readFileSpan(tree, idxEntry, 0, idxEntry.size)
      : await tree.readFile(idxEntry.cid);
    if (!idxData) return null;

    const view = new DataView(idxData.buffer, idxData.byteOffset, idxData.byteLength);

    // Check magic number (0xff744f63 for v2)
    if (view.getUint32(0) !== 0xff744f63) {
      return null;
    }

    // Version should be 2
    if (view.getUint32(4) !== 2) {
      return null;
    }

    // Total object count is the last entry in the fanout table.
    const numObjects = view.getUint32(8 + 255 * 4);

    // SHA table starts after fanout (offset 8 + 256*4 = 1032)
    const shaOffset = 8 + 256 * 4;
    const shas: string[] = [];
    for (let i = 0; i < numObjects; i++) {
      let sha = '';
      const start = shaOffset + i * 20;
      for (let j = start; j < start + 20; j++) sha += HEX[idxData[j]];
      shas.push(sha);
    }

    // CRC table (skip it) - numObjects * 4 bytes
    const crcOffset = shaOffset + numObjects * 20;

    // Offset table starts after CRC
    const offsetOffset = crcOffset + numObjects * 4;
    const offsets: number[] = [];
    const largeOffsetEntries: Array<{ index: number; largeIndex: number }> = [];
    for (let i = 0; i < numObjects; i++) {
      const rawOffset = view.getUint32(offsetOffset + i * 4);
      if (rawOffset & 0x80000000) {
        offsets.push(0);
        largeOffsetEntries.push({ index: i, largeIndex: rawOffset & 0x7fffffff });
      } else {
        offsets.push(rawOffset);
      }
    }

    if (largeOffsetEntries.length > 0) {
      const largeOffsetTableOffset = offsetOffset + numObjects * 4;
      for (const { index, largeIndex } of largeOffsetEntries) {
        const entryOffset = largeOffsetTableOffset + largeIndex * 8;
        if (entryOffset + 8 > idxData.byteLength) {
          return null;
        }
        const high = view.getUint32(entryOffset);
        const low = view.getUint32(entryOffset + 4);
        const fullOffset = (BigInt(high) << 32n) | BigInt(low);
        if (fullOffset > BigInt(Number.MAX_SAFE_INTEGER)) {
          return null;
        }
        offsets[index] = Number(fullOffset);
      }
    }

    // Build SHA -> offset map for fast lookups
    const shaToOffset = new Map<string, number>();
    for (let i = 0; i < shas.length; i++) {
      shaToOffset.set(shas[i], offsets[i]);
    }

    const sortedOffsets = [...offsets].sort((a, b) => a - b);

    return { shas, offsets, sortedOffsets, shaToOffset };
  } catch {
    return null;
  }
}

// Directory entries also carry the pack size needed for the final object range.
const packDirCache = new Map<string, Promise<TreeEntry[]>>();

function getPackEntries(tree: ReturnType<typeof getTree>, gitDirCid: CID): Promise<TreeEntry[]> {
  const key = gitDirCacheKey(gitDirCid);
  let entries = packDirCache.get(key);
  if (!entries) {
    entries = (async () => {
      const directory = await tree.resolvePath(gitDirCid, 'objects/pack');
      if (!directory || directory.type !== LinkType.Dir) return [];
      return tree.listDirectory(directory.cid);
    })();
    packDirCache.set(key, entries);
    // A failed listing is retried by the next lookup.
    entries.catch(() => packDirCache.delete(key));
  }
  return entries;
}

/** Find an object in the pack indexes without reading any pack data. */
async function findInPack(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<{ packName: string; offset: number } | null> {
  const entries = await getPackEntries(tree, gitDirCid);
  const idxFileNames = entries.filter(entry => entry.name.endsWith('.idx')).map(entry => entry.name);
  // Fetch every index together; lookups then go through them in order.
  const indexes = await Promise.all(idxFileNames.map(idxName => loadPackIndex(tree, gitDirCid, idxName)));

  for (let i = 0; i < idxFileNames.length; i++) {
    const idxName = idxFileNames[i];
    const idx = indexes[i];
    if (!idx) continue;

    // Use the shaToOffset map for O(1) lookup instead of O(n) indexOf
    const offset = idx.shaToOffset.get(sha);
    if (offset !== undefined) {
      const packName = idxName.replace('.idx', '.pack');
      return { packName, offset };
    }
  }

  return null;
}

/**
 * Apply git delta instructions to a base object
 */
function applyDelta(base: Uint8Array, delta: Uint8Array): Uint8Array {
  let pos = 0;

  // Skip base size (variable length encoded, not needed for our purposes)
  let shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  // Read result size (variable length)
  let resultSize = 0;
  shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    resultSize |= (byte & 0x7f) << shift;
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  const result = new Uint8Array(resultSize);
  let resultPos = 0;

  while (pos < delta.length && resultPos < resultSize) {
    const cmd = delta[pos++];

    if (cmd & 0x80) {
      // Copy from base
      let copyOffset = 0;
      let copySize = 0;

      if (cmd & 0x01) copyOffset = delta[pos++];
      if (cmd & 0x02) copyOffset |= delta[pos++] << 8;
      if (cmd & 0x04) copyOffset |= delta[pos++] << 16;
      if (cmd & 0x08) copyOffset |= delta[pos++] << 24;

      if (cmd & 0x10) copySize = delta[pos++];
      if (cmd & 0x20) copySize |= delta[pos++] << 8;
      if (cmd & 0x40) copySize |= delta[pos++] << 16;

      if (copySize === 0) copySize = 0x10000;

      result.set(base.subarray(copyOffset, copyOffset + copySize), resultPos);
      resultPos += copySize;
    } else if (cmd > 0) {
      // Insert new data
      result.set(delta.subarray(pos, pos + cmd), resultPos);
      pos += cmd;
      resultPos += cmd;
    }
  }

  return result;
}

// Pack data is read one stored chunk at a time and kept in a small cache, so
// a history walk fetches each chunk it touches once, and nothing else. hashtree
// reads the chunks of a range one after another; asking for them separately
// lets cold data arrive in a round of parallel downloads instead of a chain.
const FALLBACK_BLOCK_SIZE = 2 * 1024 * 1024;
const MAX_CACHED_PACK_BYTES = 32 * 1024 * 1024;
const MAX_CACHED_CHUNKS_PER_READ = 64;
const MAX_PARALLEL_CHUNK_READS = 16;
const MAX_FILE_NODE_DEPTH = 4;

interface ChunkSpan {
  start: number;
  end: number;
}

const fileNodeCache = new Map<string, Promise<TreeNode | null>>();

function getFileNode(tree: ReturnType<typeof getTree>, cid: CID): Promise<TreeNode | null> {
  const key = toHex(cid.hash);
  let node = fileNodeCache.get(key);
  if (!node) {
    node = tree.getTreeNode(cid).catch(() => null);
    fileNodeCache.set(key, node);
    if (fileNodeCache.size > 256) fileNodeCache.delete(fileNodeCache.keys().next().value!);
  }
  return node;
}

/** Stored chunks overlapping [start, end), in order. Empty when the layout is unknown. */
async function findStoredChunks(
  tree: ReturnType<typeof getTree>,
  cid: CID,
  base: number,
  start: number,
  end: number,
  depth = 0
): Promise<ChunkSpan[]> {
  const node = await getFileNode(tree, cid);
  if (!node) return [];

  const spans: ChunkSpan[] = [];
  let position = base;
  for (const link of node.links) {
    if (!link.size) return [];
    const linkStart = position;
    position += link.size;
    if (position <= start) continue;
    if (linkStart >= end) break;

    const inner = link.type !== LinkType.Blob && depth < MAX_FILE_NODE_DEPTH
      ? await findStoredChunks(tree, { hash: link.hash, key: link.key }, linkStart, start, end, depth + 1)
      : [];
    if (inner.length > 0) spans.push(...inner);
    else spans.push({ start: linkStart, end: position });
  }
  return spans;
}

/** Spans to read for [start, end): the stored chunks, or fixed blocks when those are unknown. */
async function getReadSpans(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  start: number,
  end: number
): Promise<ChunkSpan[]> {
  const stored = await findStoredChunks(tree, file.cid, 0, start, end).catch(() => []);
  if (stored.length > 0) return stored;

  const spans: ChunkSpan[] = [];
  const first = Math.floor(start / FALLBACK_BLOCK_SIZE) * FALLBACK_BLOCK_SIZE;
  for (let from = first; from < end; from += FALLBACK_BLOCK_SIZE) {
    spans.push({ start: from, end: Math.min(from + FALLBACK_BLOCK_SIZE, file.size > 0 ? file.size : end) });
  }
  return spans;
}

async function readSpan(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  span: ChunkSpan
): Promise<Uint8Array | null> {
  const data = await tree.readFileRange(file.cid, span.start, span.end);
  return data && data.length === span.end - span.start ? data : null;
}

const packChunkCache = new Map<string, { data: Promise<Uint8Array | null>; bytes: number }>();
let packChunkCacheBytes = 0;

function readCachedChunk(
  tree: ReturnType<typeof getTree>,
  pack: TreeEntry,
  span: ChunkSpan
): Promise<Uint8Array | null> {
  const key = `${toHex(pack.cid.hash)}:${span.start}`;
  const cached = packChunkCache.get(key);
  if (cached) {
    // Refresh recency.
    packChunkCache.delete(key);
    packChunkCache.set(key, cached);
    return cached.data;
  }

  const entry = { data: readSpan(tree, pack, span).catch(() => null), bytes: span.end - span.start };
  packChunkCache.set(key, entry);
  packChunkCacheBytes += entry.bytes;
  // Failed reads are retried by the next caller.
  void entry.data.then(data => {
    if (!data && packChunkCache.get(key) === entry) {
      packChunkCache.delete(key);
      packChunkCacheBytes -= entry.bytes;
    }
  });
  for (const [oldKey, old] of packChunkCache) {
    if (packChunkCacheBytes <= MAX_CACHED_PACK_BYTES || old === entry) break;
    packChunkCache.delete(oldKey);
    packChunkCacheBytes -= old.bytes;
  }
  return entry.data;
}

/** Copy [start, end) out of consecutive spans that cover it. */
function assembleRange(
  spans: ChunkSpan[],
  parts: Array<Uint8Array | null>,
  start: number,
  end: number
): Uint8Array | null {
  if (parts.length === 0 || parts.some(part => !part)) return null;
  if (spans[0].start > start || spans[spans.length - 1].end < end) return null;
  if (parts.length === 1) {
    return parts[0]!.subarray(start - spans[0].start, end - spans[0].start);
  }

  const data = new Uint8Array(end - start);
  for (let i = 0; i < spans.length; i++) {
    const from = Math.max(start, spans[i].start);
    const to = Math.min(end, spans[i].end);
    data.set(parts[i]!.subarray(from - spans[i].start, to - spans[i].start), from - start);
  }
  return data;
}

/** Read a whole range with its chunks fetched in parallel, bypassing the cache. */
async function readFileSpan(
  tree: ReturnType<typeof getTree>,
  file: TreeEntry,
  start: number,
  end: number
): Promise<Uint8Array | null> {
  const spans = await getReadSpans(tree, file, start, end);
  const parts: Array<Uint8Array | null> = new Array(spans.length).fill(null);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(MAX_PARALLEL_CHUNK_READS, spans.length) }, async () => {
    while (next < spans.length) {
      const i = next++;
      parts[i] = await readSpan(tree, file, spans[i]);
    }
  }));
  return assembleRange(spans, parts, start, end);
}

async function readPackRange(
  tree: ReturnType<typeof getTree>,
  pack: TreeEntry,
  start: number,
  end: number
): Promise<Uint8Array | null> {
  const spans = await getReadSpans(tree, pack, start, end);
  if (spans.length > MAX_CACHED_CHUNKS_PER_READ) {
    // A large blob: read it directly rather than flushing the chunk cache.
    return readFileSpan(tree, pack, start, end);
  }
  const parts = await Promise.all(spans.map(span => readCachedChunk(tree, pack, span)));
  return assembleRange(spans, parts, start, end);
}

// Resolved pack objects by offset. Trees are stored as long delta chains, so
// without this every tree read would re-apply the chain from its base.
const MAX_CACHED_PACK_OBJECTS = 4096;
const MAX_CACHED_PACK_OBJECT_SIZE = 256 * 1024;
const packObjectCache = new Map<string, Promise<{ type: string; content: Uint8Array } | null>>();

async function readFromPackUncached(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string,
  offset: number,
  depth: number
): Promise<{ type: string; content: Uint8Array } | null> {
  if (depth > 50) return null;
  try {
    const idx = await loadPackIndex(tree, gitDirCid, packName.replace('.pack', '.idx'));
    if (!idx) return null;
    const pack = (await getPackEntries(tree, gitDirCid)).find(entry => entry.name === packName);
    if (!pack || pack.type === LinkType.Dir) return null;
    const end = getPackObjectEnd(pack.size, idx.sortedOffsets, offset);
    if (end <= offset) return null;
    const data = await readPackRange(tree, pack, offset, end);
    if (!data) return null;
    return await readPackObjectAtOffset(data, offset, idx, tree, gitDirCid, packName, depth);
  } catch {
    return null;
  }
}

/**
 * Read object from pack file at given offset (with delta resolution)
 */
async function readFromPack(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string,
  offset: number,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  // Prevent infinite recursion
  if (depth > 50) return null;

  const key = `${gitDirCacheKey(gitDirCid)}:${packName}:${offset}`;
  const cached = packObjectCache.get(key);
  if (cached) return cached;

  const pending = readFromPackUncached(tree, gitDirCid, packName, offset, depth);

  packObjectCache.set(key, pending);
  if (packObjectCache.size > MAX_CACHED_PACK_OBJECTS) {
    packObjectCache.delete(packObjectCache.keys().next().value!);
  }
  // Keep only successful, small results: failures are retried and large blobs
  // stay out of memory.
  void pending.then(object => {
    if ((!object || object.content.length > MAX_CACHED_PACK_OBJECT_SIZE) && packObjectCache.get(key) === pending) {
      packObjectCache.delete(key);
    }
  });
  return pending;
}

function getPackObjectEnd(packSize: number, sortedOffsets: number[], offset: number): number {
  const packTrailerLength = 20;
  const packEnd = Math.max(12, packSize - packTrailerLength);

  let lo = 0;
  let hi = sortedOffsets.length;

  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (sortedOffsets[mid] <= offset) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }

  return lo < sortedOffsets.length ? Math.min(sortedOffsets[lo], packEnd) : packEnd;
}

async function readPackObjectAtOffset(
  packData: Uint8Array,
  offset: number,
  idx: PackIndexData,
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  if (depth > 50) return null;

  let pos = 0;
  let byte = packData[pos++];
  const type = (byte >> 4) & 7;
  let size = byte & 15;
  let shift = 4;

  while (byte & 0x80) {
    byte = packData[pos++];
    size |= (byte & 0x7f) << shift;
    shift += 7;
  }

  const typeNames = ['', 'commit', 'tree', 'blob', 'tag', '', 'ofs_delta', 'ref_delta'];
  const objectEnd = packData.length;

  if (objectEnd <= pos) {
    return null;
  }

  if (type === 6) {
    let negOffset = 0;
    byte = packData[pos++];
    negOffset = byte & 0x7f;
    while (byte & 0x80) {
      byte = packData[pos++];
      negOffset = ((negOffset + 1) << 7) | (byte & 0x7f);
    }
    const baseOffset = offset - negOffset;

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);
    const baseObj = await readFromPack(tree, gitDirCid, packName, baseOffset, depth + 1);
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  if (type === 7) {
    const baseShaBytes = packData.subarray(pos, pos + 20);
    pos += 20;
    const baseSha = Array.from(baseShaBytes).map(b => b.toString(16).padStart(2, '0')).join('');

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);

    const baseOffset = idx.shaToOffset.get(baseSha);
    let baseObj: { type: string; content: Uint8Array } | null = null;
    if (baseOffset !== undefined) {
      // Named bases may sit anywhere in the pack; the depth limit guards against cycles.
      baseObj = await readFromPackUncached(tree, gitDirCid, packName, baseOffset, depth + 1);
    } else {
      baseObj = await readGitObject(tree, gitDirCid, baseSha);
    }
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  const compressedData = packData.subarray(pos, objectEnd);
  const decompressed = await decompressZlib(compressedData);
  return { type: typeNames[type], content: decompressed.slice(0, size) };
}

// Loose object directories are listed once per git directory, so a fully
// packed repository answers every loose lookup without touching the store.
const looseDirCache = new Map<string, Promise<Map<string, TreeEntry>>>();

function listLooseDir(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  path: string
): Promise<Map<string, TreeEntry>> {
  const key = `${gitDirCacheKey(gitDirCid)}:${path}`;
  let listing = looseDirCache.get(key);
  if (!listing) {
    listing = (async () => {
      const dir = await tree.resolvePath(gitDirCid, path);
      if (!dir || dir.type !== LinkType.Dir) return new Map<string, TreeEntry>();
      return new Map((await tree.listDirectory(dir.cid)).map(entry => [entry.name, entry]));
    })();
    looseDirCache.set(key, listing);
    // A failed listing is retried by the next lookup.
    listing.catch(() => looseDirCache.delete(key));
  }
  return listing;
}

/**
 * List every loose-object directory up front. A history walk reads loose
 * commits and trees one after another; with the directories already listed
 * each of those costs one request instead of two.
 */
export async function prefetchLooseObjectDirs(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID
): Promise<void> {
  const fanout = [...await listLooseDir(tree, gitDirCid, 'objects')]
    .filter(([name, entry]) => /^[0-9a-f]{2}$/.test(name) && entry.type === LinkType.Dir)
    .map(([name]) => name);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(24, fanout.length) }, async () => {
    while (next < fanout.length) {
      await listLooseDir(tree, gitDirCid, `objects/${fanout[next++]}`).catch(() => {});
    }
  }));
}

async function findLooseObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<CID | null> {
  const prefix = sha.slice(0, 2);
  const fanout = (await listLooseDir(tree, gitDirCid, 'objects')).get(prefix);
  if (!fanout || fanout.type !== LinkType.Dir) return null;
  const entry = (await listLooseDir(tree, gitDirCid, `objects/${prefix}`)).get(sha.slice(2));
  return entry && entry.type !== LinkType.Dir ? entry.cid : null;
}

/**
 * Read and parse a git object from hashtree (loose or packed)
 * Internal version with depth tracking for delta resolution
 */
export async function readGitObjectInternal(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  // Prevent infinite recursion
  if (depth > 50) return null;

  // Pack indexes are held in memory, so a packed object is found without
  // touching the store. Only objects no pack has are looked up as loose files.
  const packInfo = await findInPack(tree, gitDirCid, sha);
  if (packInfo) {
    const packed = await readFromPack(tree, gitDirCid, packInfo.packName, packInfo.offset, depth);
    if (packed) return packed;
  }

  // Loose object: .git/objects/<sha[0:2]>/<sha[2:]>
  try {
    const looseCid = await findLooseObject(tree, gitDirCid, sha);
    if (looseCid) {
      const compressedData = await tree.readFile(looseCid);
      if (compressedData) {
        // Decompress the object
        const decompressed = await decompressZlib(compressedData);

        // Parse: "<type> <size>\0<content>"
        const nullIndex = decompressed.indexOf(0);
        if (nullIndex !== -1) {
          const header = new TextDecoder().decode(decompressed.slice(0, nullIndex));
          const [type] = header.split(' ');
          const content = decompressed.slice(nullIndex + 1);
          return { type, content };
        }
      }
    }
  } catch {
    // Not available as a loose object either.
  }

  return null;
}

/**
 * Read and parse a git object from hashtree (loose or packed)
 */
export async function readGitObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<GitObject | null> {
  const cacheKey = gitDirCacheKey(gitDirCid);
  let dirCache = gitObjectCache.get(cacheKey);
  if (!dirCache) {
    dirCache = new Map();
    gitObjectCache.set(cacheKey, dirCache);
  }

  const cached = dirCache.get(sha);
  if (cached) {
    return await cached;
  }

  const pending = readGitObjectInternal(tree, gitDirCid, sha, 0);
  dirCache.set(sha, pending);
  try {
    const object = await pending;
    if (!object) dirCache.delete(sha);
    return object;
  } catch (error) {
    dirCache.delete(sha);
    throw error;
  }
}
