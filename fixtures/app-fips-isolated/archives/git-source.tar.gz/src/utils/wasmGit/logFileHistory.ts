import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { getTree } from '../../store';
import { getHead } from './logHead';
import { getParsedCommitFromSha } from './logObjects';
import { getSubtreeSha, getTreeEntryAtPath } from './logTrees';
import type { ParsedCommit } from './logTypes';
import { copyGitDirToWasmFS, createRepoPath, loadWasmGit, rmRf, withWasmGitLock } from './core';

export async function getFileLastCommitsWasm(
  rootCid: CID,
  filenames: string[],
  subpath?: string
): Promise<Map<string, { oid: string; message: string; timestamp: number }>> {
  return withWasmGitLock(async () => {
    const tree = getTree();
    const result = new Map<string, { oid: string; message: string; timestamp: number }>();

    if (filenames.length === 0) return result;

    // Check for .git directory
    const gitDirResult = await tree.resolvePath(rootCid, '.git');
    if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
      return result;
    }

    const module = await loadWasmGit();
    const repoPath = createRepoPath();
    const originalCwd = module.FS.cwd();

    try {
      module.FS.mkdir(repoPath);

      try {
        module.FS.writeFile('/home/web_user/.gitconfig', '[user]\nname = Reader\nemail = reader@example.com\n');
      } catch {
        // May already exist
      }

      module.FS.chdir(repoPath);

      // Only copy .git directory - git log only needs history, not working tree
      await copyGitDirToWasmFS(module, rootCid, '.');

      // For each file, get the last commit that touched it
      for (const filename of filenames) {
        // Skip .git directory
        if (filename === '.git') continue;

        try {
          // Build the full path relative to git root
          const fullPath = subpath ? `${subpath}/${filename}` : filename;
          // Run git log -1 -- <fullPath> to get last commit for this file
          const output = module.callWithOutput(['log', '-1', '--', fullPath]);

          if (!output || output.trim() === '') continue;

          // Parse same format as getLog
          const lines = output.split('\n');
          let oid = '';
          let timestamp = 0;
          const messageLines: string[] = [];
          let inMessage = false;

          for (const line of lines) {
            if (line.startsWith('commit ')) {
              oid = line.substring(7).trim();
            } else if (line.startsWith('Date: ')) {
              const dateStr = line.substring(6).trim();
              const date = new Date(dateStr);
              if (!isNaN(date.getTime())) {
                timestamp = Math.floor(date.getTime() / 1000);
              }
            } else if (line === '') {
              if (oid && !inMessage) {
                inMessage = true;
              }
            } else if (inMessage) {
              messageLines.push(line.replace(/^    /, ''));
            }
          }

          if (oid) {
            result.set(filename, {
              oid,
              message: messageLines.join('\n').trim(),
              timestamp,
            });
          }
        } catch {
          // Skip files with errors
        }
      }

      return result;
    } catch (err) {
      console.error('[wasm-git] getFileLastCommits failed:', err);
      return result;
    } finally {
      try {
        module.FS.chdir(originalCwd);
        rmRf(module, repoPath);
      } catch {
        // Ignore
      }
    }
  });
}

/**
 * Get last commit info for each file/directory by tracing through commit history
 * Native implementation - no wasm-git needed
 * Uses path-based lookups to avoid walking entire trees (O(depth) vs O(files) per path)
 */
export async function getFileLastCommits(
  rootCid: CID,
  filenames: string[],
  subpath?: string,
  onProgress?: (filename: string, commitInfo: { oid: string; message: string; timestamp: number }) => void
): Promise<Map<string, { oid: string; message: string; timestamp: number }>> {
  const startTime = performance.now();
  const htree = getTree();
  const result = new Map<string, { oid: string; message: string; timestamp: number }>();

  if (filenames.length === 0) {
    return result;
  }

  // Check for .git directory
  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return result;
  }

  try {
    // Build full paths to search for (files and directories)
    const targetNames = filenames.filter(f => f !== '.git');
    const targetPaths = new Map<string, string>(); // fullPath -> filename
    for (const f of targetNames) {
      const fullPath = subpath ? `${subpath}/${f}` : f;
      targetPaths.set(fullPath, f);
    }

    // Get commit history
    const headSha = await getHead(rootCid);
    if (!headSha) return result;

    // Walk through commits, comparing each with its parent to find when files changed
    const visited = new Set<string>();
    const queue = [headSha];
    const foundEntries = new Set<string>();

    // Cache for path lookups: commitTreeSha:path -> hash or 'dir' or null
    const pathLookupCache = new Map<string, { hash: string; mode: string } | 'dir' | null>();

    // Helper to get path entry with caching
    const getPathEntry = async (treeSha: string, path: string) => {
      const cacheKey = `${treeSha}:${path}`;
      if (pathLookupCache.has(cacheKey)) {
        return pathLookupCache.get(cacheKey)!;
      }
      const entry = await getTreeEntryAtPath(htree, gitDirResult.cid, treeSha, path);
      pathLookupCache.set(cacheKey, entry);
      return entry;
    };

    // Helper to get subtree SHA with caching
    const subtreeShaCache = new Map<string, string | null>();
    const getSubtree = async (treeSha: string, path: string) => {
      const cacheKey = `${treeSha}:${path}`;
      if (subtreeShaCache.has(cacheKey)) {
        return subtreeShaCache.get(cacheKey)!;
      }
      const sha = await getSubtreeSha(htree, gitDirResult.cid, treeSha, path);
      subtreeShaCache.set(cacheKey, sha);
      return sha;
    };

    // For loose object repos, batch load commits in parallel
    const BATCH_SIZE = 20;

    while (queue.length > 0 && foundEntries.size < targetPaths.size) {
      // Take a batch of commits to process
      const batch: string[] = [];
      while (batch.length < BATCH_SIZE && queue.length > 0 && foundEntries.size < targetPaths.size) {
        const sha = queue.shift()!;
        if (!visited.has(sha)) {
          visited.add(sha);
          batch.push(sha);
        }
      }
      if (batch.length === 0) break;

      // Load all commits in parallel
      const parsedCommits = await Promise.all(
        batch.map(async (sha) => {
          const parsed = await getParsedCommitFromSha(htree, gitDirResult.cid, sha);
          return parsed ? { sha, commit: parsed } : null;
        })
      );
      const resolvedCommits = parsedCommits.filter((c): c is { sha: string; commit: ParsedCommit } => c !== null);

      // Load parent commits to get their tree SHAs
      const parentShas = resolvedCommits
        .flatMap(c => c.commit.parents)
        .filter((parent, index, arr) => !visited.has(parent) && arr.indexOf(parent) === index);
      const parentCommits = await Promise.all(
        parentShas.map(async (sha) => {
          const parsed = await getParsedCommitFromSha(htree, gitDirResult.cid, sha);
          return parsed ? [sha, parsed] as const : null;
        })
      );
      const parentCommitMap = new Map<string, ParsedCommit>();
      for (const entry of parentCommits) {
        if (entry) {
          parentCommitMap.set(entry[0], entry[1]);
        }
      }

      // Now process each commit
      for (const { sha, commit } of resolvedCommits) {
        if (foundEntries.size >= targetPaths.size) break;

        let parentTreeSha: string | null = null;
        if (commit.parents.length > 0) {
          const parentCommit = parentCommitMap.get(commit.parents[0]);
          if (parentCommit) {
            parentTreeSha = parentCommit.tree;
          }
        }

        const unresolvedTargets = Array.from(targetPaths.entries())
          .filter(([targetPath]) => !foundEntries.has(targetPath));

        const targetResults = await Promise.all(unresolvedTargets.map(async ([targetPath, filename]) => {
          const currentEntry = await getPathEntry(commit.tree, targetPath);
          if (currentEntry === null) {
            return null;
          }

          if (currentEntry === 'dir') {
            const [currentSubtreeSha, parentSubtreeSha] = await Promise.all([
              getSubtree(commit.tree, targetPath),
              parentTreeSha ? getSubtree(parentTreeSha, targetPath) : Promise.resolve(null),
            ]);

            if (!currentSubtreeSha || currentSubtreeSha === parentSubtreeSha) {
              return null;
            }

            return {
              targetPath,
              filename,
              commitInfo: {
                oid: sha,
                message: commit.message,
                timestamp: commit.timestamp,
              },
            };
          }

          const parentEntry = parentTreeSha ? await getPathEntry(parentTreeSha, targetPath) : null;
          if (parentEntry && parentEntry !== 'dir' && currentEntry.hash === parentEntry.hash) {
            return null;
          }

          return {
            targetPath,
            filename,
            commitInfo: {
              oid: sha,
              message: commit.message,
              timestamp: commit.timestamp,
            },
          };
        }));

        for (const entry of targetResults) {
          if (!entry || foundEntries.has(entry.targetPath)) continue;
          result.set(entry.filename, entry.commitInfo);
          onProgress?.(entry.filename, entry.commitInfo);
          foundEntries.add(entry.targetPath);
        }

        for (const parent of commit.parents) {
          if (!visited.has(parent)) {
            queue.push(parent);
          }
        }
      }
      // end for commit in resolvedCommits
    } // end while queue

    console.log(`[git perf] getFileLastCommits completed in ${(performance.now() - startTime).toFixed(0)} ms`);
    return result;
  } catch (err) {
    console.error('[git] getFileLastCommits failed:', err);
    return result;
  }
}
