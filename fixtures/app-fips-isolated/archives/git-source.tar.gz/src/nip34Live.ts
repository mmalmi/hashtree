/**
 * Live NIP-34 reads: pull requests, issues, their statuses and comments are
 * shown as each event arrives. No list or page waits for a relay to finish.
 */
import type { Event as NostrEvent } from 'nostr-tools';
import { createBatcher, watchEvents } from './lib/nostrLive';
import { npubToPubkey } from './nostr';
import {
  KIND_ISSUE,
  KIND_PULL_REQUEST,
  KIND_STATUS_APPLIED,
  KIND_STATUS_CLOSED,
  KIND_STATUS_DRAFT,
  KIND_STATUS_OPEN,
  KIND_TEXT_NOTE,
} from './utils/constants';
import {
  buildRepoAddress,
  getTargetEventIdFromTags,
  kindToStatus,
  parseCommentEvent,
  parseIssueEvent,
  parsePullRequestEvent,
  type Comment,
  type Issue,
  type ItemStatus,
  type PullRequest,
} from './nip34';

const STATUS_KINDS = [KIND_STATUS_OPEN, KIND_STATUS_APPLIED, KIND_STATUS_CLOSED, KIND_STATUS_DRAFT];
const STATUS_FILTER_SIZE = 200;
const EVENT_ID = /^[0-9a-f]{64}$/;

/** Run at most once per turn of the event loop, however many events arrived in it. */
function coalesce(run: () => void): () => void {
  let scheduled = false;
  return () => {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      run();
    });
  };
}

/**
 * The newest maintainer status of each tracked pull request or issue. Items may
 * be added at any time; a status applies the moment it arrives.
 */
export class StatusTracker {
  private readonly owners = new Map<string, string>();
  private readonly heads = new Map<string, { created_at: number; id: string; status: ItemStatus }>();
  private readonly stops: Array<() => void> = [];
  private readonly batch = createBatcher<string>(ids => this.watch(ids));
  private running = false;
  private readonly onChange: () => void;

  constructor(onChange: () => void) {
    this.onChange = onChange;
  }

  track(eventId: string, repoOwnerPubkey: string): void {
    if (!eventId || !repoOwnerPubkey || this.owners.has(eventId)) return;
    this.owners.set(eventId, repoOwnerPubkey);
    if (this.running) this.batch.add(eventId);
  }

  get(eventId: string): ItemStatus {
    return this.heads.get(eventId)?.status ?? 'open';
  }

  /** Show a status the viewer just set, until a newer one arrives. */
  setLocal(eventId: string, status: ItemStatus | null, created_at = Math.floor(Date.now() / 1000)): void {
    if (status) this.heads.set(eventId, { created_at, id: '', status });
    else this.heads.delete(eventId);
    this.onChange();
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.watch([...this.owners.keys()]);
  }

  stop(): void {
    this.running = false;
    this.batch.cancel();
    for (const stop of this.stops.splice(0)) stop();
  }

  private watch(ids: string[]): void {
    if (!this.running) return;
    for (let offset = 0; offset < ids.length; offset += STATUS_FILTER_SIZE) {
      this.stops.push(watchEvents(
        { kinds: STATUS_KINDS, '#e': ids.slice(offset, offset + STATUS_FILTER_SIZE) },
        { event: event => this.apply(event) },
      ));
    }
  }

  private apply(event: NostrEvent): void {
    const targetId = getTargetEventIdFromTags(event.tags);
    if (!targetId || event.pubkey !== this.owners.get(targetId)) return;
    const current = this.heads.get(targetId);
    const created_at = event.created_at ?? 0;
    if (current && (created_at < current.created_at ||
      (created_at === current.created_at && current.id && event.id >= current.id))) return;
    this.heads.set(targetId, { created_at, id: event.id, status: kindToStatus(event.kind) });
    this.onChange();
  }
}

export interface LiveItems<T> {
  /** Newest first. An item keeps its place relative to the others as more arrive. */
  items: T[];
  /** Stored history has been delivered: an empty list now means there is nothing. */
  historyDone: boolean;
}

/**
 * Watch the pull requests or issues of a repository. `onChange` is called with
 * every addition and status change. Returns a function that ends the watch.
 */
export function watchRepoItems<T extends PullRequest | Issue>(
  npub: string,
  repoName: string,
  kind: typeof KIND_PULL_REQUEST | typeof KIND_ISSUE,
  onChange: (state: LiveItems<T>) => void,
  initial: T[] = [],
): () => void {
  const ownerPubkey = npubToPubkey(npub);
  if (!ownerPubkey) {
    onChange({ items: [], historyDone: true });
    return () => {};
  }

  const parse = (kind === KIND_PULL_REQUEST ? parsePullRequestEvent : parseIssueEvent) as (event: NostrEvent) => T | null;
  const items = new Map<string, T>();
  let historyDone = false;

  const emit = coalesce(() => {
    onChange({
      items: [...items.values()]
        .map(item => ({ ...item, status: statuses.get(item.eventId) }))
        .sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id)),
      historyDone,
    });
  });
  const statuses = new StatusTracker(emit);
  const add = (item: T) => {
    if (items.has(item.id)) return;
    items.set(item.id, item);
    statuses.track(item.eventId, ownerPubkey);
    emit();
  };

  for (const item of initial) add(item);
  statuses.start();
  const stop = watchEvents({ kinds: [kind], '#a': [buildRepoAddress(npub, repoName)] }, {
    event: (event) => {
      const item = parse(event);
      if (item) add(item);
    },
    history: () => {
      historyDone = true;
      emit();
    },
    removed: (id) => {
      if (items.delete(id)) emit();
    },
  });

  return () => {
    stop();
    statuses.stop();
  };
}

export interface LiveThread<T> {
  item: T | null;
  /** Oldest first. */
  comments: Comment[];
  /** Stored history has been delivered: a missing item now means it was not found. */
  historyDone: boolean;
}

/**
 * Watch one pull request or issue with its status and comments. The item is
 * shown when it arrives and comments as each one arrives.
 */
export function watchThread<T extends PullRequest | Issue>(
  eventId: string,
  kind: typeof KIND_PULL_REQUEST | typeof KIND_ISSUE,
  repoOwnerPubkey: string | null,
  onChange: (state: LiveThread<T>) => void,
): { stop: () => void; setLocalStatus: (status: ItemStatus | null) => void } {
  if (!EVENT_ID.test(eventId)) {
    onChange({ item: null, comments: [], historyDone: true });
    return { stop: () => {}, setLocalStatus: () => {} };
  }

  const parse = (kind === KIND_PULL_REQUEST ? parsePullRequestEvent : parseIssueEvent) as (event: NostrEvent) => T | null;
  const comments = new Map<string, Comment>();
  let item: T | null = null;
  let historyDone = false;

  const emit = coalesce(() => {
    onChange({
      item: item && { ...item, status: statuses.get(eventId) },
      comments: [...comments.values()].sort((a, b) => a.created_at - b.created_at || a.id.localeCompare(b.id)),
      historyDone,
    });
  });
  const statuses = new StatusTracker(emit);
  if (repoOwnerPubkey) statuses.track(eventId, repoOwnerPubkey);
  statuses.start();

  const stops = [
    watchEvents({ ids: [eventId] }, {
      event: (event) => {
        if (item || event.id !== eventId) return;
        item = parse(event);
        emit();
      },
      history: () => {
        historyDone = true;
        emit();
      },
    }),
    watchEvents({ kinds: [KIND_TEXT_NOTE], '#e': [eventId] }, {
      event: (event) => {
        const comment = parseCommentEvent(event, eventId);
        if (!comment) return;
        comments.set(comment.id, comment);
        emit();
      },
      removed: (id) => {
        if (comments.delete(id)) emit();
      },
    }),
  ];

  return {
    stop: () => {
      for (const stop of stops) stop();
      statuses.stop();
    },
    setLocalStatus: status => statuses.setLocal(eventId, status),
  };
}
