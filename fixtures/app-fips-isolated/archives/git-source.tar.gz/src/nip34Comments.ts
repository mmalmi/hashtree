import type { Filter as NostrFilter } from 'nostr-tools';
import { nostr, nostrStore, pubkeyToNpub } from './nostr';
import { KIND_TEXT_NOTE } from './utils/constants';
import { fetchEventsViaSubscribe, publishNip34Event, type Comment } from './nip34';
import { GitCollaborationPrivacyError } from './lib/gitCollaboration';

export async function fetchComments(targetEventId: string): Promise<Comment[]> {
  const filter: NostrFilter = {
    kinds: [KIND_TEXT_NOTE],
    '#e': [targetEventId],
  };

  const events = await fetchEventsViaSubscribe(filter);
  const comments: Comment[] = [];

  for (const event of events) {
    if (!event.id || !event.pubkey) continue;

    const replyTo = event.tags.find(t => t[0] === 'e' && t[3] === 'reply')?.[1] || targetEventId;

    comments.push({
      id: event.id,
      content: event.content || '',
      author: pubkeyToNpub(event.pubkey),
      authorPubkey: event.pubkey,
      created_at: event.created_at || 0,
      replyTo,
    });
  }

  return comments.sort((a, b) => a.created_at - b.created_at);
}

export async function addComment(
  targetEventId: string,
  targetAuthorPubkey: string,
  content: string,
  repoAddress: string
): Promise<Comment | null> {
  const state = nostrStore.getState();
  if (!state.pubkey || !nostr.signer) return null;

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_TEXT_NOTE;
  event.content = content;
  event.tags = [
    ['e', targetEventId, '', 'root'],
    ['p', targetAuthorPubkey],
    ['a', repoAddress],
  ];

  try {
    const signedEvent = await publishNip34Event(event);

    return {
      id: signedEvent.id,
      content,
      author: state.npub!,
      authorPubkey: state.pubkey,
      created_at: event.created_at || Math.floor(Date.now() / 1000),
      replyTo: targetEventId,
    };
  } catch (e) {
    if (e instanceof GitCollaborationPrivacyError) throw e;
    console.error('Failed to add comment:', e);
    return null;
  }
}
