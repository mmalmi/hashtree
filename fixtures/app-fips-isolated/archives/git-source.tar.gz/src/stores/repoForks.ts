import { writable } from 'svelte/store';
import { type NostrEvent, nostr } from '../nostr';
import { fetchRepoAnnouncement, buildRepoAddress } from '../nip34';
import { type GitRepoAnnouncement, isNewerGitRepoAnnouncement, parseGitRepoAnnouncement } from '../lib/gitRepoAnnouncements';
import { LRUCache } from '../utils/lruCache';
import { KeyedEventEmitter } from '../utils/keyedEventEmitter';
import { KIND_REPO_ANNOUNCEMENT } from '../utils/constants';

export interface RepoForkStats {
  address: string;
  count: number;
  updatedAt: number;
  earliestUniqueCommit: string | null;
  forks: RepoForkListItem[];
}

export interface RepoForkListItem {
  address: string;
  ownerPubkey: string;
  ownerNpub: string;
  repoName: string;
  cloneUrls: string[];
  forkedFrom: string | null;
  createdAt: number;
  earliestUniqueCommit: string | null;
  isPersonalFork: boolean;
}

const repoForkStatsCache = new LRUCache<string, RepoForkStats>(200);
const repoForkStatsEmitter = new KeyedEventEmitter<string, RepoForkStats>();
const repoForkSourceCache = new Map<string, GitRepoAnnouncement | null>();
const repoForkAnnouncementCache = new Map<string, Map<string, GitRepoAnnouncement>>();
const activeRepoForkSubscriptions = new Map<string, { stop: () => void }>();
const repoForkSubscriberCounts = new Map<string, number>();

function getRepoForkAnnouncementMap(repoAddress: string): Map<string, GitRepoAnnouncement> {
  let announcements = repoForkAnnouncementCache.get(repoAddress);
  if (!announcements) {
    announcements = new Map();
    repoForkAnnouncementCache.set(repoAddress, announcements);
  }

  return announcements;
}

function rebuildRepoForkStats(repoAddress: string): void {
  const sourceAnnouncement = repoForkSourceCache.get(repoAddress);
  const announcements = [...getRepoForkAnnouncementMap(repoAddress).values()];
  const earliestUniqueCommit = sourceAnnouncement?.earliestUniqueCommit ?? null;
  const forks = announcements
    .filter(announcement => (
      !!earliestUniqueCommit &&
      announcement.earliestUniqueCommit === earliestUniqueCommit &&
      announcement.address !== sourceAnnouncement?.address
    ))
    .sort((a, b) => (
      b.createdAt - a.createdAt ||
      a.ownerNpub.localeCompare(b.ownerNpub) ||
      a.repoName.localeCompare(b.repoName) ||
      a.address.localeCompare(b.address)
    ))
    .map(announcement => ({
      address: announcement.address,
      ownerPubkey: announcement.ownerPubkey,
      ownerNpub: announcement.ownerNpub,
      repoName: announcement.repoName,
      cloneUrls: announcement.cloneUrls,
      forkedFrom: announcement.forkedFrom,
      createdAt: announcement.createdAt,
      earliestUniqueCommit: announcement.earliestUniqueCommit,
      isPersonalFork: announcement.isPersonalFork,
    }));

  const snapshot: RepoForkStats = {
    address: repoAddress,
    count: forks.length,
    updatedAt: announcements.reduce(
      (latest, announcement) => Math.max(latest, announcement.createdAt),
      sourceAnnouncement?.createdAt || 0,
    ),
    earliestUniqueCommit,
    forks,
  };

  repoForkStatsCache.set(repoAddress, snapshot);
  repoForkStatsEmitter.notify(repoAddress, snapshot);
}

function applyRepoForkAnnouncement(repoAddress: string, announcement: GitRepoAnnouncement): void {
  const announcements = getRepoForkAnnouncementMap(repoAddress);
  const current = announcements.get(announcement.address);
  if (!isNewerGitRepoAnnouncement(announcement, current)) {
    return;
  }

  announcements.set(announcement.address, announcement);

  if (announcement.address === repoAddress) {
    repoForkSourceCache.set(repoAddress, announcement);
  }

  rebuildRepoForkStats(repoAddress);
}

async function fetchRepoForkStats(ownerNpub: string, repoName: string): Promise<void> {
  let repoAddress = '';
  try {
    repoAddress = buildRepoAddress(ownerNpub, repoName);
  } catch {
    return;
  }

  if (!repoAddress || activeRepoForkSubscriptions.has(repoAddress)) {
    return;
  }

  const sourceAnnouncement = await fetchRepoAnnouncement(ownerNpub, repoName);
  // Another store may have completed the same async setup, or every consumer
  // may have navigated away while the source announcement was loading.
  if ((repoForkSubscriberCounts.get(repoAddress) ?? 0) === 0 || activeRepoForkSubscriptions.has(repoAddress)) {
    return;
  }

  repoForkSourceCache.set(repoAddress, sourceAnnouncement);
  if (sourceAnnouncement) {
    getRepoForkAnnouncementMap(repoAddress).set(sourceAnnouncement.address, sourceAnnouncement);
  }
  rebuildRepoForkStats(repoAddress);

  if (!sourceAnnouncement?.earliestUniqueCommit) {
    return;
  }

  const sub = nostr.subscribe(
    {
      kinds: [KIND_REPO_ANNOUNCEMENT],
      '#r': [sourceAnnouncement.earliestUniqueCommit],
    },
    { closeAfterHistory: false },
  );

  sub.on('event', (event: NostrEvent) => {
    const announcement = parseGitRepoAnnouncement(event);
    if (!announcement || announcement.earliestUniqueCommit !== sourceAnnouncement.earliestUniqueCommit) {
      return;
    }

    applyRepoForkAnnouncement(repoAddress, announcement);
  });

  activeRepoForkSubscriptions.set(repoAddress, { stop: () => sub.stop() });
}

export function createRepoForkStatsStore(ownerNpub?: string, repoName?: string) {
  let repoAddress = '';
  if (ownerNpub && repoName) {
    try {
      repoAddress = buildRepoAddress(ownerNpub, repoName);
    } catch {
      repoAddress = '';
    }
  }

  const { subscribe: storeSubscribe, set } = writable<RepoForkStats | undefined>(
    repoAddress ? repoForkStatsCache.get(repoAddress) : undefined,
  );

  if (repoAddress && ownerNpub && repoName) {
    repoForkSubscriberCounts.set(repoAddress, (repoForkSubscriberCounts.get(repoAddress) ?? 0) + 1);
    const unsubscribe = repoForkStatsEmitter.subscribe(repoAddress, set);
    const cached = repoForkStatsCache.get(repoAddress);
    if (cached) {
      set(cached);
    }
    void fetchRepoForkStats(ownerNpub, repoName);

    let destroyed = false;

    return {
      subscribe: storeSubscribe,
      destroy: () => {
        if (destroyed) return;
        destroyed = true;
        unsubscribe();

        const remaining = Math.max(0, (repoForkSubscriberCounts.get(repoAddress) ?? 1) - 1);
        if (remaining > 0) {
          repoForkSubscriberCounts.set(repoAddress, remaining);
          return;
        }

        repoForkSubscriberCounts.delete(repoAddress);
        activeRepoForkSubscriptions.get(repoAddress)?.stop();
        activeRepoForkSubscriptions.delete(repoAddress);
      },
    };
  }

  return {
    subscribe: storeSubscribe,
    destroy: () => {},
  };
}
