import { writable, type Readable } from 'svelte/store';
import { onCacheUpdate } from '../treeRootCache';
import { getErrorMessage } from '../utils/errorMessage';
import { buildReleaseTreeName } from './releaseHelpers';
import { invalidateTreeRoot, subscribeToTreeRoot } from './treeRoot';
import {
  fetchReleaseDetailResult,
  type ReleaseDetailState,
} from './releases';

export function createReleaseDetailStore(
  npub: string | null,
  repoPath: string | null,
  releaseId: string | null,
  treeName?: string | null
): Readable<ReleaseDetailState> & { refresh: () => Promise<void> } {
  const { subscribe, set, update } = writable<ReleaseDetailState>({
    item: null,
    loading: true,
    error: null,
  });

  const releaseTreeName: string | null = treeName ?? (repoPath ? buildReleaseTreeName(repoPath) : null);
  let refreshSequence = 0;
  let resolverHasFiredForKey = false;
  let forcedRefreshAfterMiss = false;

  async function refresh(): Promise<void> {
    if (!npub || !repoPath || !releaseId) {
      set({ item: null, loading: false, error: null });
      return;
    }

    const sequence = ++refreshSequence;
    update(state => ({ ...state, loading: true, error: null }));

    try {
      const result = await fetchReleaseDetailResult(npub, repoPath, releaseId, treeName ?? undefined);
      if (sequence !== refreshSequence) return;

      if (result.status === 'missing-root') {
        update(state => ({ item: state.item, loading: !state.item, error: null }));
        return;
      }

      if (result.status === 'not-found') {
        if (!forcedRefreshAfterMiss && npub && releaseTreeName) {
          forcedRefreshAfterMiss = true;
          void invalidateTreeRoot(npub, releaseTreeName);
          update(state => ({ item: state.item, loading: !state.item, error: null }));
          return;
        }

        if (!resolverHasFiredForKey) {
          update(state => ({ item: state.item, loading: !state.item, error: null }));
          return;
        }

        set({ item: null, loading: false, error: 'Release not found' });
        return;
      }

      forcedRefreshAfterMiss = false;
      set({ item: result.item, loading: false, error: null });
    } catch (err) {
      if (sequence !== refreshSequence) return;
      set({ item: null, loading: false, error: getErrorMessage(err) });
    }
  }

  if (npub && repoPath && releaseId) {
    void refresh();
  } else {
    set({ item: null, loading: false, error: null });
  }

  if (npub && releaseTreeName) {
    subscribeToTreeRoot(npub, releaseTreeName, () => {
      resolverHasFiredForKey = true;
      void refresh();
    });
    onCacheUpdate((owner, treeName) => {
      if (owner === npub && treeName === releaseTreeName) {
        void refresh();
      }
    });
  }

  return { subscribe, refresh };
}
