/**
 * Settings store with Dexie persistence (Svelte version)
 */
import { writable, get } from 'svelte/store';
import Dexie, { type Table } from 'dexie';
import {
  DEFAULT_EDITOR_SETTINGS,
  DEFAULT_DISPLAY_SETTINGS,
  DEFAULT_IMGPROXY_SETTINGS,
  DEFAULT_NETWORK_SETTINGS,
  DEFAULT_STORAGE_SETTINGS,
  DEFAULT_UPLOAD_SETTINGS,
  applyProductionNetworkFallback,
  isTestMode,
} from './settingsDefaults';
import type {
  BlossomServerConfig,
  DisplaySettings,
  EditorSettings,
  ImgproxySettings,
  NetworkSettings,
  StorageSettings,
  UploadSettings,
} from './settingsDefaults';

export * from './settingsDefaults';

// Dexie database for settings persistence
class SettingsDB extends Dexie {
  settings!: Table<{ key: string; value: unknown }>;

  constructor() {
    super('hashtree-settings');
    this.version(1).stores({
      settings: '&key',
    });
  }
}

const db = new SettingsDB();

export interface SettingsState {
  // Imgproxy settings
  imgproxy: ImgproxySettings;

  display: DisplaySettings;

  // Upload settings
  upload: UploadSettings;

  // Editor settings
  editor: EditorSettings;

  // Network settings
  network: NetworkSettings;
  networkLoaded: boolean;

  // Storage settings
  storage: StorageSettings;
  storageLoaded: boolean;

}

function createSettingsStore() {
  const { subscribe, update } = writable<SettingsState>({
    // Imgproxy settings
    imgproxy: DEFAULT_IMGPROXY_SETTINGS,

    display: DEFAULT_DISPLAY_SETTINGS,

    // Upload settings
    upload: DEFAULT_UPLOAD_SETTINGS,

    // Editor settings
    editor: DEFAULT_EDITOR_SETTINGS,

    // Network settings
    network: DEFAULT_NETWORK_SETTINGS,
    networkLoaded: false,

    // Storage settings
    storage: DEFAULT_STORAGE_SETTINGS,
    storageLoaded: false,

  });

  return {
    subscribe,

    setDisplaySettings: (display: Partial<DisplaySettings>) => {
      update(state => {
        const updated = { ...state.display, ...display };
        db.settings.put({ key: 'display', value: updated }).catch(console.error);
        return { ...state, display: updated };
      });
    },

    resetDisplaySettings: () => {
      update(state => {
        db.settings.put({ key: 'display', value: DEFAULT_DISPLAY_SETTINGS }).catch(console.error);
        return { ...state, display: DEFAULT_DISPLAY_SETTINGS };
      });
    },

    setUploadSettings: (upload: Partial<UploadSettings>) => {
      update(state => {
        const updated = { ...state.upload, ...upload };
        db.settings.put({ key: 'upload', value: updated }).catch(console.error);
        return { ...state, upload: updated };
      });
    },

    setEditorSettings: (editor: Partial<EditorSettings>) => {
      update(state => {
        const updated = { ...state.editor, ...editor };
        db.settings.put({ key: 'editor', value: updated }).catch(console.error);
        return { ...state, editor: updated };
      });
    },

    setImgproxySettings: (imgproxy: Partial<ImgproxySettings>) => {
      update(state => {
        const updated = { ...state.imgproxy, ...imgproxy };
        db.settings.put({ key: 'imgproxy', value: updated }).catch(console.error);
        return { ...state, imgproxy: updated };
      });
    },

    resetImgproxySettings: () => {
      update(state => {
        db.settings.put({ key: 'imgproxy', value: DEFAULT_IMGPROXY_SETTINGS }).catch(console.error);
        return { ...state, imgproxy: DEFAULT_IMGPROXY_SETTINGS };
      });
    },

    setNetworkSettings: (network: Partial<NetworkSettings>) => {
      update(state => {
        const updated = { ...state.network, ...network };
        db.settings.put({ key: 'network', value: updated }).catch(console.error);
        return { ...state, network: updated };
      });
    },

    resetNetworkSettings: () => {
      update(state => {
        db.settings.put({ key: 'network', value: DEFAULT_NETWORK_SETTINGS }).catch(console.error);
        return { ...state, network: DEFAULT_NETWORK_SETTINGS };
      });
    },

    setStorageSettings: (storage: Partial<StorageSettings>) => {
      update(state => {
        const updated = { ...state.storage, ...storage };
        db.settings.put({ key: 'storage', value: updated }).catch(console.error);
        return { ...state, storage: updated };
      });
    },

    resetStorageSettings: () => {
      update(state => {
        db.settings.put({ key: 'storage', value: DEFAULT_STORAGE_SETTINGS }).catch(console.error);
        return { ...state, storage: DEFAULT_STORAGE_SETTINGS };
      });
    },

    // Get current state synchronously
    getState: (): SettingsState => get(settingsStore),

    // Set state directly
    setState: (newState: Partial<SettingsState>) => {
      update(state => ({ ...state, ...newState }));
    },
  };
}

export const settingsStore = createSettingsStore();

// Load settings from Dexie on startup
async function loadSettings() {
  try {
    const [displayRow, uploadRow, editorRow, networkRow, imgproxyRow, storageRow] = await Promise.all([
      db.settings.get('display'),
      db.settings.get('upload'),
      db.settings.get('editor'),
      db.settings.get('network'),
      db.settings.get('imgproxy'),
      db.settings.get('storage'),
    ]);

    const updates: Partial<SettingsState> = { networkLoaded: true, storageLoaded: true };

    if (displayRow?.value) {
      const display = displayRow.value as DisplaySettings;
      updates.display = {
        showConnectivity: display.showConnectivity ?? DEFAULT_DISPLAY_SETTINGS.showConnectivity,
        showBandwidth: display.showBandwidth ?? DEFAULT_DISPLAY_SETTINGS.showBandwidth,
      };
    }

    if (uploadRow?.value) {
      const upload = uploadRow.value as UploadSettings;
      updates.upload = {
        gitignoreBehavior: upload.gitignoreBehavior ?? DEFAULT_UPLOAD_SETTINGS.gitignoreBehavior,
      };
    }

    if (editorRow?.value) {
      const editor = editorRow.value as EditorSettings;
      updates.editor = {
        autoSave: editor.autoSave ?? DEFAULT_EDITOR_SETTINGS.autoSave,
      };
    }

    if (networkRow !== undefined) {
      const network = (networkRow.value ?? {}) as NetworkSettings;
      // Handle backwards compatibility: convert old string[] format to BlossomServerConfig[]
      let blossomServers = DEFAULT_NETWORK_SETTINGS.blossomServers;
      if (network.blossomServers && Array.isArray(network.blossomServers)) {
        blossomServers = network.blossomServers.map(s =>
          typeof s === 'string' ? { url: s, read: true, write: false } : { ...s, read: s.read ?? true }
        );
      }
      const nextNetwork = {
        relays: Array.isArray(network.relays) ? network.relays : [],
        blossomServers,
        negentropyEnabled: network.negentropyEnabled ?? DEFAULT_NETWORK_SETTINGS.negentropyEnabled,
      };
      updates.network = isTestMode ? nextNetwork : applyProductionNetworkFallback(nextNetwork);
    } else if (isTestMode) {
      updates.network = DEFAULT_NETWORK_SETTINGS;
    }

    if (imgproxyRow?.value) {
      const imgproxy = imgproxyRow.value as ImgproxySettings;
      updates.imgproxy = {
        enabled: imgproxy.enabled ?? DEFAULT_IMGPROXY_SETTINGS.enabled,
        url: imgproxy.url ?? DEFAULT_IMGPROXY_SETTINGS.url,
        key: imgproxy.key ?? DEFAULT_IMGPROXY_SETTINGS.key,
        salt: imgproxy.salt ?? DEFAULT_IMGPROXY_SETTINGS.salt,
      };
    }

    if (storageRow?.value) {
      const storage = storageRow.value as StorageSettings;
      updates.storage = {
        maxBytes: storage.maxBytes ?? DEFAULT_STORAGE_SETTINGS.maxBytes,
      };
    }

    settingsStore.setState(updates);
  } catch (err) {
    console.error('[settings] error loading:', err);
    // Unknown persisted network policy is not permission to contact defaults.
    settingsStore.setState({ network: { ...get(settingsStore).network, relays: [] } });
    settingsStore.setState({ networkLoaded: true, storageLoaded: true });
  }
}

// Promise that resolves when settings are loaded
let settingsLoadedResolve: (() => void) | null = null;
const settingsLoadedPromise = new Promise<void>((resolve) => {
  settingsLoadedResolve = resolve;
});

// Initialize on module load
loadSettings().then(() => {
  settingsLoadedResolve?.();
});

/**
 * Wait for settings to be loaded from IndexedDB.
 * Use this before initializing components that need correct settings from the start.
 */
export function waitForSettingsLoaded(): Promise<void> {
  return settingsLoadedPromise;
}

// Expose for e2e tests to configure settings without module duplication issues
// Track all store instances to handle Vite module duplication
if (typeof window !== 'undefined') {
  type SettingsStoreInstance = { setNetworkSettings: (settings: Partial<NetworkSettings>) => void };
  const win = window as unknown as {
    __settingsStoreInstances?: SettingsStoreInstance[];
    __configureBlossomServers?: (servers: BlossomServerConfig[]) => void;
  };

  // Register this store instance
  if (!win.__settingsStoreInstances) {
    win.__settingsStoreInstances = [];
  }
  win.__settingsStoreInstances.push(settingsStore);

  // Update all instances when called
  win.__configureBlossomServers = (servers: BlossomServerConfig[]) => {
    for (const store of win.__settingsStoreInstances || []) {
      store.setNetworkSettings({ blossomServers: servers });
    }
  };
}
