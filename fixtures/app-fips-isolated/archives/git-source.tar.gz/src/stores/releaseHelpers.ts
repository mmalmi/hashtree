import type { CID } from '@hashtree/core';
import { getNhashFileUrl, getNpubFileUrl } from '../lib/mediaUrl';

const RELEASES_SUFFIX = 'releases';

function normalizeRepoPath(repoPath: string): string {
  return repoPath.replace(/^\/+/, '').replace(/\/+$/, '');
}

interface ReleaseAssetLinkCandidate {
  name: string;
  path: string;
}

function hasUriScheme(value: string): boolean {
  return /^[a-zA-Z][a-zA-Z\d+.-]*:/.test(value);
}

function splitReferencePath(value: string): string {
  const queryIndex = value.indexOf('?');
  const hashIndex = value.indexOf('#');
  const suffixIndex = [queryIndex, hashIndex].filter(index => index >= 0).sort((a, b) => a - b)[0];
  return suffixIndex === undefined ? value : value.slice(0, suffixIndex);
}

function decodePathSegment(segment: string): string {
  try {
    return decodeURIComponent(segment);
  } catch {
    return segment;
  }
}

function normalizeAssetReferencePath(value: string): string | null {
  const trimmed = value.trim();
  if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('//') || hasUriScheme(trimmed)) {
    return null;
  }

  const path = splitReferencePath(trimmed).replace(/^\/+/, '');
  const segments: string[] = [];
  for (const segment of path.split('/')) {
    if (!segment || segment === '.') continue;
    if (segment === '..') return null;
    segments.push(decodePathSegment(segment));
  }

  return segments.length > 0 ? segments.join('/') : null;
}

export function resolveReleaseAssetMarkdownLink<T extends ReleaseAssetLinkCandidate>(
  href: string,
  assets: readonly T[],
): T | null {
  const normalizedHref = normalizeAssetReferencePath(href);
  if (!normalizedHref) return null;

  return assets.find((asset) => {
    const assetPath = normalizeAssetReferencePath(asset.path);
    const assetName = normalizeAssetReferencePath(asset.name);
    const assetPathFromName = normalizeAssetReferencePath(`assets/${asset.name}`);

    return normalizedHref === assetPath
      || normalizedHref === assetName
      || normalizedHref === assetPathFromName;
  }) ?? null;
}

export function buildReleaseTreeName(repoPath: string): string {
  const clean = normalizeRepoPath(repoPath);
  return clean ? `${RELEASES_SUFFIX}/${clean}` : RELEASES_SUFFIX;
}

export function getReleaseAssetUrl(
  npub: string,
  repoPath: string,
  releaseId: string,
  assetPath: string,
  linkKey?: string,
): string {
  const url = getNpubFileUrl(npub, buildReleaseTreeName(repoPath), `${releaseId}/${assetPath}`);
  if (!linkKey) return url;
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}k=${encodeURIComponent(linkKey)}`;
}

export function getReleaseAssetDownloadUrl(
  npub: string,
  repoPath: string,
  releaseId: string,
  assetPath: string,
  linkKey?: string,
  assetCid?: CID,
  assetName?: string,
): string {
  const fileName = assetName ?? assetPath.split('/').filter(Boolean).at(-1) ?? 'file';
  const baseUrl = assetCid
    ? getNhashFileUrl(assetCid, fileName)
    : getReleaseAssetUrl(npub, repoPath, releaseId, assetPath, linkKey);
  const separator = baseUrl.includes('?') ? '&' : '?';
  return `${baseUrl}${separator}download=1`;
}

export function sanitizeReleaseId(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return '';
  const cleaned = trimmed
    .replace(/[\\/]/g, '-')
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^[-.]+|[-.]+$/g, '');
  return cleaned.slice(0, 80);
}

export function isListedReleaseEntryName(name: string): boolean {
  return name !== 'latest' && name !== 'draft';
}
