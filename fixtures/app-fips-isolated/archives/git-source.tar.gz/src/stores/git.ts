/**
 * Git-related stores for detecting and interacting with git repos
 */
import { writable, get, type Readable } from 'svelte/store';
import { toHex, type CID } from '@hashtree/core';
import { isGitRepo, getRefs, getLog, getStatus, getHead } from '../utils/git';
import { nostrStore } from '../nostr';
import { LRUCache } from '../utils/lruCache';

type GitStatusResult = Awaited<ReturnType<typeof getStatus>>;

export interface GitInfo {
  isRepo: boolean;
  currentBranch: string | null;
  branches: string[];
  tags: string[];
  tagsByCommit: Record<string, string[]>;
  branchNamesLoading: boolean;
  tagNamesLoading: boolean;
  loading: boolean;
}

export interface CommitInfo {
  oid: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent: string[];
}

// Cache for git info stores by repoPath:CID (LRU to prevent unbounded growth)
const gitInfoStoreCache = new LRUCache<string, Readable<GitInfo>>(5);
const GIT_INFO_MAX_RETRIES = 60;
const GIT_INFO_RETRY_DELAY_MS = 1500;

function cidCacheKey(cid: CID): string {
  return cid.key ? `${toHex(cid.hash)}:${toHex(cid.key)}` : toHex(cid.hash);
}

function hasGitRefs(info: Pick<GitInfo, 'currentBranch' | 'branches' | 'tags'>): boolean {
  return !!info.currentBranch || info.branches.length > 0 || info.tags.length > 0;
}

interface GitInfoStoreOptions {
  retryRepoDetection?: boolean;
}

/**
 * Create a store to detect if a directory is a git repo and get basic info
 * Cached by repoPath:CID to avoid re-fetching when navigating within the same repo
 */
export function createGitInfoStore(
  dirCid: CID | null,
  repoPath?: string,
  options: GitInfoStoreOptions = {},
): Readable<GitInfo> {
  if (!dirCid) {
    return {
      subscribe: writable<GitInfo>({
        isRepo: false,
        currentBranch: null,
        branches: [],
        tags: [],
        tagsByCommit: {},
        branchNamesLoading: false,
        tagNamesLoading: false,
        loading: false,
      }).subscribe,
    };
  }

  const cacheKey = `${repoPath ?? ''}:${cidCacheKey(dirCid)}`;
  if (gitInfoStoreCache.has(cacheKey)) {
    return gitInfoStoreCache.get(cacheKey)!;
  }

  const { subscribe, set } = writable<GitInfo>({
    isRepo: false,
    currentBranch: null,
    branches: [],
    tags: [],
    tagsByCommit: {},
    branchNamesLoading: true,
    tagNamesLoading: true,
    loading: true,
  });

  const store = { subscribe };

  // Cache and start loading
  gitInfoStoreCache.set(cacheKey, store);

  {
    let retryCount = 0;
    let lastConnectedRelays = nostrStore.getState().connectedRelays;

    const emptyRepoState: GitInfo = {
      isRepo: true,
      currentBranch: null,
      branches: [],
      tags: [],
      tagsByCommit: {},
      branchNamesLoading: false,
      tagNamesLoading: false,
      loading: false,
    };

    const scheduleRetry = () => {
      retryCount += 1;
      setTimeout(load, GIT_INFO_RETRY_DELAY_MS);
    };

    const load = async () => {
      let discoveredRefs: GitInfo | null = null;
      try {
        const connectedRelays = nostrStore.getState().connectedRelays;
        if (connectedRelays > 0 && lastConnectedRelays === 0) {
          retryCount = 0;
        }
        lastConnectedRelays = connectedRelays;

        const repoDetected = await isGitRepo(dirCid);
        if (!repoDetected) {
          if (options.retryRepoDetection && retryCount < GIT_INFO_MAX_RETRIES) {
            set({ isRepo: false, currentBranch: null, branches: [], tags: [], tagsByCommit: {}, branchNamesLoading: true, tagNamesLoading: true, loading: true });
            scheduleRetry();
            return;
          }

          gitInfoStoreCache.delete(cacheKey);
          set({ isRepo: false, currentBranch: null, branches: [], tags: [], tagsByCommit: {}, branchNamesLoading: false, tagNamesLoading: false, loading: false });
          return;
        }

        const refs = await getRefs(dirCid, {
          onCurrentBranch: (currentBranch) => {
            const partialValue: GitInfo = {
              isRepo: true,
              currentBranch,
              branches: [currentBranch],
              tags: [],
              tagsByCommit: {},
              branchNamesLoading: true,
              tagNamesLoading: true,
              loading: true,
            };
            discoveredRefs = partialValue;
            set(partialValue);
          },
          onBranches: (branchRefs) => {
            const partialValue: GitInfo = {
              isRepo: true,
              ...branchRefs,
              tags: [],
              tagsByCommit: {},
              branchNamesLoading: false,
              tagNamesLoading: true,
              loading: true,
            };
            if (hasGitRefs(partialValue)) {
              discoveredRefs = partialValue;
              set(partialValue);
            }
          },
          onRefNames: (refNames) => {
            const partialValue: GitInfo = {
              isRepo: true,
              ...refNames,
              tagsByCommit: {},
              branchNamesLoading: false,
              tagNamesLoading: false,
              loading: true,
            };
            if (hasGitRefs(partialValue)) {
              discoveredRefs = partialValue;
              set(partialValue);
            }
          },
        });
        const nextValue: GitInfo = {
          isRepo: true,
          currentBranch: refs.currentBranch,
          branches: refs.branches,
          tags: refs.tags,
          tagsByCommit: refs.tagsByCommit,
          branchNamesLoading: false,
          tagNamesLoading: false,
          loading: false,
        };

        if (!hasGitRefs(nextValue) && retryCount < GIT_INFO_MAX_RETRIES) {
          set({ ...nextValue, loading: true });
          scheduleRetry();
          return;
        }

        if (!hasGitRefs(nextValue)) {
          gitInfoStoreCache.delete(cacheKey);
        }

        set(nextValue);
      } catch (err) {
        console.error('Error getting git branches:', err);
        if (retryCount < GIT_INFO_MAX_RETRIES) {
          set(discoveredRefs ? { ...(discoveredRefs as GitInfo), loading: true } : { ...emptyRepoState, branchNamesLoading: true, tagNamesLoading: true, loading: true });
          scheduleRetry();
          return;
        }

        gitInfoStoreCache.delete(cacheKey);
        set(emptyRepoState);
      }
    };

    void load();
  }

  return store;
}

// Cache for git log stores by repoPath:CID:depth (LRU to prevent unbounded growth)
const gitLogStoreCache = new LRUCache<string, Readable<{
  commits: CommitInfo[];
  headOid: string | null;
  loading: boolean;
  error: string | null;
}>>(5);
const GIT_LOG_PREVIEW_DEPTH = 10;

function getGitLogStageDepths(depth: number): number[] {
  const stageDepths = new Set<number>([1]);
  if (depth > 1) {
    stageDepths.add(Math.min(depth, GIT_LOG_PREVIEW_DEPTH));
    stageDepths.add(depth);
  }
  return Array.from(stageDepths).sort((a, b) => a - b);
}

/**
 * Create a store to get commit history for a git repo
 * Cached by repoPath:CID:depth to avoid re-fetching when navigating within the same repo
 */
export function createGitLogStore(dirCid: CID | null, depth = 20, repoPath?: string): Readable<{
  commits: CommitInfo[];
  headOid: string | null;
  loading: boolean;
  error: string | null;
}> {
  if (!dirCid) {
    return { subscribe: writable({ commits: [], headOid: null, loading: false, error: null }).subscribe };
  }

  const cacheKey = `${repoPath ?? ''}:${cidCacheKey(dirCid)}:${depth}`;
  if (gitLogStoreCache.has(cacheKey)) {
    return gitLogStoreCache.get(cacheKey)!;
  }

  const store = writable<{
    commits: CommitInfo[];
    headOid: string | null;
    loading: boolean;
    error: string | null;
  }>({
    commits: [],
    headOid: null,
    loading: true,
    error: null,
  });
  const { subscribe, set } = store;

  // Cache immediately
  const cachedStore = { subscribe };
  gitLogStoreCache.set(cacheKey, cachedStore);

  {
    const MAX_RETRIES = 60;
    const RETRY_DELAY_MS = 1500;
    let retryCount = 0;
    let lastConnectedRelays = nostrStore.getState().connectedRelays;

    const load = async () => {
      try {
        const connectedRelays = nostrStore.getState().connectedRelays;
        if (connectedRelays > 0 && lastConnectedRelays === 0) {
          retryCount = 0;
        }
        lastConnectedRelays = connectedRelays;

        const headPromise = getHead(dirCid).catch(() => null);
        void headPromise.then((headOid) => {
          if (!headOid) return;
          const existing = get(store);
          if (existing.headOid === headOid) return;
          set({ ...existing, headOid });
        });

        const stageDepths = getGitLogStageDepths(depth);
        for (const stageDepth of stageDepths.slice(0, -1)) {
          const stagedCommits = await getLog(dirCid, { depth: stageDepth });
          if (stagedCommits.length === 0) {
            continue;
          }

          const existing = get(store);
          if (stagedCommits.length <= existing.commits.length) {
            continue;
          }

          set({
            commits: stagedCommits,
            headOid: existing.headOid,
            loading: true,
            error: null,
          });
        }

        const [commits, headOid] = await Promise.all([
          getLog(dirCid, { depth }),
          headPromise,
        ]);
        const existing = get(store);
        const finalCommits = commits.length > 0 ? commits : existing.commits;
        const finalHeadOid = headOid ?? existing.headOid;

        if ((finalCommits.length === 0 || !finalHeadOid) && retryCount < MAX_RETRIES) {
          retryCount += 1;
          setTimeout(load, RETRY_DELAY_MS);
          return;
        }

        set({ commits: finalCommits, headOid: finalHeadOid ?? null, loading: false, error: null });
      } catch (err) {
        const existing = get(store);
        set({
          commits: existing.commits,
          headOid: existing.headOid,
          loading: false,
          error: err instanceof Error ? err.message : 'Failed to load git log',
        });
      }
    };

    void load();
  }

  return cachedStore;
}

/**
 * Create a store to get git status (staged, unstaged, untracked files)
 */
export function createGitStatusStore(dirCid: CID | null): Readable<{
  status: GitStatusResult;
  loading: boolean;
  error: string | null;
}> & { refresh: () => void } {
  const emptyStatus: GitStatusResult = { staged: [], unstaged: [], untracked: [], hasChanges: false };
  const { subscribe, set } = writable<{
    status: GitStatusResult;
    loading: boolean;
    error: string | null;
  }>({
    status: emptyStatus,
    loading: true,
    error: null,
  });

  const currentCid = dirCid;

  function load() {
    if (!currentCid) {
      set({ status: emptyStatus, loading: false, error: null });
      return;
    }

    set({ status: emptyStatus, loading: true, error: null });

    getStatus(currentCid).then((status) => {
      set({ status, loading: false, error: null });
    }).catch((err) => {
      set({
        status: emptyStatus,
        loading: false,
        error: err instanceof Error ? err.message : 'Failed to get git status',
      });
    });
  }

  // Initial load
  load();

  return {
    subscribe,
    refresh: () => load(),
  };
}
