import { LinkType, type CID, type TreeVisibility } from '@hashtree/core';
import { saveHashtree } from '../nostr';
import { getTree } from '../store';
import { buildReleaseTreeName, sanitizeReleaseId } from './releaseHelpers';
import { waitForTreeRoot } from './treeRoot';
import {
  ensureUniqueReleaseId,
  splitReleaseEntryPath,
  toReleaseSummary,
  withEntryPath,
  type ReleaseAssetMeta,
  type ReleaseRecord,
  type ReleaseSummary,
  type SaveReleaseOptions,
} from './releases';

export async function saveRelease(options: SaveReleaseOptions): Promise<ReleaseSummary | null> {
  const title = options.title.trim();
  if (!title) return null;
  if (options.visibility === 'link-visible' && !options.linkKey) {
    throw new Error('Missing link key for link-visible release tree');
  }

  const treeName = options.treeName ?? buildReleaseTreeName(options.repoPath);
  const tree = getTree();
  const rootCid = await waitForTreeRoot(options.npub, treeName, 5000);
  const existingIds = new Set(options.existingIds ?? []);
  if (!options.releaseId && rootCid) {
    const entries = await tree.listDirectory(rootCid);
    entries.forEach(entry => existingIds.add(entry.name));
  }

  let releaseId = options.releaseId?.trim() ?? '';
  if (!releaseId) {
    const base = sanitizeReleaseId(options.tag ?? title) || `release-${Date.now()}`;
    releaseId = ensureUniqueReleaseId(base, existingIds);
  }
  const releasePathSegments = splitReleaseEntryPath(releaseId);
  if (releasePathSegments.length === 0) {
    throw new Error('Release id must not be empty');
  }
  const releaseName = releasePathSegments[releasePathSegments.length - 1];
  const releaseParentPath = releasePathSegments.slice(0, -1);
  const recordId = options.recordId?.trim() || releaseId;

  const now = Math.floor(Date.now() / 1000);
  const created_at = options.createdAt ?? now;
  const published_at = options.draft ? undefined : (options.publishedAt ?? now);
  const notes = options.notes?.trim() ?? '';
  const notesFile = notes ? 'notes.md' : undefined;
  let notesEntry: { cid: CID; size: number } | null = null;
  if (notesFile) {
    const notesBytes = new TextEncoder().encode(notes);
    notesEntry = await tree.putFile(notesBytes);
  }

  const assetMap = new Map<string, { cid: CID; size: number }>();
  const existingAssets = options.existingAssets ?? [];
  for (const asset of existingAssets) {
    if (asset.cid) {
      assetMap.set(asset.name, { cid: asset.cid, size: asset.size });
    }
  }

  for (const file of options.assets ?? []) {
    const data = new Uint8Array(await file.arrayBuffer());
    const result = await tree.putFile(data);
    assetMap.set(file.name, { cid: result.cid, size: result.size });
  }

  let assetsDirEntry: { cid: CID } | null = null;
  const assetMeta: ReleaseAssetMeta[] = [];
  if (assetMap.size > 0) {
    const assetEntries = Array.from(assetMap.entries()).map(([name, info]) => {
      assetMeta.push({ name, path: `assets/${name}`, size: info.size });
      return { name, cid: info.cid, size: info.size, type: LinkType.File };
    });
    const assetsDir = await tree.putDirectory(assetEntries);
    assetsDirEntry = { cid: assetsDir.cid };
  }

  const record: ReleaseRecord = {
    id: recordId,
    title,
    tag: options.tag?.trim() || undefined,
    commit: options.commit?.trim() || undefined,
    created_at,
    published_at,
    draft: options.draft ?? false,
    prerelease: options.prerelease ?? false,
    notes_file: notesFile,
    assets: assetMeta.length > 0 ? assetMeta : undefined,
  };

  const recordBytes = new TextEncoder().encode(JSON.stringify(record, null, 2));
  const recordEntry = await tree.putFile(recordBytes);
  const releaseEntries = [
    { name: 'release.json', cid: recordEntry.cid, size: recordEntry.size, type: LinkType.File },
  ];
  if (notesEntry) {
    releaseEntries.push({ name: notesFile!, cid: notesEntry.cid, size: notesEntry.size, type: LinkType.File });
  }
  if (assetsDirEntry) {
    releaseEntries.push({ name: 'assets', cid: assetsDirEntry.cid, size: 0, type: LinkType.Dir });
  }

  const releaseDir = await tree.putDirectory(releaseEntries);
  const meta = { release: toReleaseSummary(record, releaseId) };

  let newRootCid: CID;
  if (rootCid) {
    newRootCid = await tree.setEntry(rootCid, releaseParentPath, releaseName, releaseDir.cid, 0, LinkType.Dir, meta);
  } else {
    if (releaseParentPath.length > 0) {
      throw new Error('Cannot create a nested release path without an existing release tree');
    }
    const root = await tree.putDirectory([
      { name: releaseName, cid: releaseDir.cid, size: 0, type: LinkType.Dir, meta },
    ]);
    newRootCid = root.cid;
  }

  const visibility = options.visibility ?? 'public';
  const result = await saveHashtree(treeName, newRootCid, { visibility, linkKey: options.linkKey });
  if (!result.success) {
    throw new Error('Failed to publish release tree');
  }

  return withEntryPath(toReleaseSummary(record, releaseId), releaseId);
}

export async function deleteRelease(
  npub: string,
  repoPath: string,
  releaseId: string,
  visibility: TreeVisibility = 'public',
  linkKey?: string,
  treeName?: string
): Promise<boolean> {
  if (visibility === 'link-visible' && !linkKey) return false;
  const resolvedTreeName = treeName ?? buildReleaseTreeName(repoPath);
  const rootCid = await waitForTreeRoot(npub, resolvedTreeName, 5000);
  if (!rootCid) return false;

  const tree = getTree();
  const releasePathSegments = splitReleaseEntryPath(releaseId);
  if (releasePathSegments.length === 0) return false;
  const releaseName = releasePathSegments[releasePathSegments.length - 1];
  const releaseParentPath = releasePathSegments.slice(0, -1);
  const newRootCid = await tree.removeEntry(rootCid, releaseParentPath, releaseName);
  const result = await saveHashtree(resolvedTreeName, newRootCid, { visibility, linkKey });
  return result.success;
}
