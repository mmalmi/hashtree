/**
 * Tracks which app variant is currently running
 * Set by the main entry point (main-git.ts)
 */
export type AppType = 'git';

export interface FolderCreationBehavior {
  actionLabel: string;
  modalTitle: string;
  placeholder: string;
  createsGitRepo: boolean;
}

let currentAppType: AppType = 'git';

const GIT_FOLDER_CREATION_BEHAVIOR: FolderCreationBehavior = {
  actionLabel: 'New Repository',
  modalTitle: 'New Repository',
  placeholder: 'Repository name...',
  createsGitRepo: true,
};

export function setAppType(type: AppType) {
  currentAppType = type;
}

export function getAppType(): AppType {
  return currentAppType;
}

export function isFilesApp(): boolean {
  return false;
}

export function isGitApp(): boolean {
  return currentAppType === 'git';
}

export function supportsDocumentFeatures(): boolean {
  return false;
}

export function supportsGitFeatures(): boolean {
  return currentAppType === 'git';
}

export function shouldAssumeGitRepoDuringDetection(): boolean {
  return currentAppType === 'git';
}

export function shouldShowGenericFileBrowser(): boolean {
  return false;
}

export function shouldOpenSourceCodeLinkInNewTab(): boolean {
  return false;
}

export function getFolderCreationBehavior(): FolderCreationBehavior {
  return GIT_FOLDER_CREATION_BEHAVIOR;
}
