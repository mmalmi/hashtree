import 'virtual:uno.css';
import GitApp from './GitApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker, isFirstServiceWorkerInstall, retryMediaAfterServiceWorkerInstall } from './lib/swInit';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { initHtreeApi } from './lib/htreeApi';
import { waitForRelayConnection } from './lib/workerInit';
import { nostrStore } from './nostr/store';
import { htreeMediaReady } from './lib/htreeMediaReady';

async function restoreAppSession() {
  try {
    const restored = await restoreSession();
    if (!restored) {
      await initReadonlyBackend();
    }
  } finally {
    nostrStore.setSessionReady(true);
  }
}

async function init() {
  mount(GitApp, {
    target: document.getElementById('app')!,
  });
  // A returning visitor already has a controlling service worker, so this
  // resolves at once. On a first visit it is still installing and caching the
  // app, which takes seconds: the backend starts alongside instead of after it.
  const firstInstall = isFirstServiceWorkerInstall();
  const swPromise = initServiceWorker();
  if (firstInstall) {
    htreeMediaReady.set(false);
    void swPromise
      .then(retryMediaAfterServiceWorkerInstall)
      .catch(() => {})
      .finally(() => htreeMediaReady.set(true));
  } else {
    await swPromise;
  }
  const htreePromise = initHtreeApi();
  // The UI uses sessionReady to show a neutral placeholder until the worker
  // identity is initialized.
  const restorePromise = restoreAppSession();
  await Promise.all([restorePromise, htreePromise]);
  await waitForRelayConnection();
}

init();
if (import.meta.env.DEV && import.meta.env.VITE_TEST_MODE) {
  void import('./lib/testHelpers').then(({ setupTestHelpers }) => setupTestHelpers());
}
