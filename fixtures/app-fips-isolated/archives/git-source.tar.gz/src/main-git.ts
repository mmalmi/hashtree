import 'virtual:uno.css';
import GitApp from './GitApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker } from './lib/swInit';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { setAppType } from './appType';
import { initHtreeApi } from './lib/htreeApi';
import { waitForRelayConnection } from './lib/workerInit';
import { nostrStore } from './nostr/store';

setAppType('git');

async function restoreAppSession() {
  try {
    const restored = await restoreSession();
    if (!restored) {
      await initReadonlyBackend();
    }
  } finally {
    nostrStore.setSessionReady(true);
  }
}

async function init() {
  mount(GitApp, {
    target: document.getElementById('app')!,
  });
  const swPromise = initServiceWorker();
  await swPromise;
  const htreePromise = initHtreeApi();
  // Keep worker identity initialization after service-worker setup. The UI
  // uses sessionReady to show a neutral placeholder until this completes.
  const restorePromise = restoreAppSession();
  await Promise.all([restorePromise, htreePromise]);
  await waitForRelayConnection();
}

init();
if (import.meta.env.DEV && import.meta.env.VITE_TEST_MODE) {
  void import('./lib/testHelpers').then(({ setupTestHelpers }) => setupTestHelpers());
}
