import { beforeEach, describe, expect, it, vi } from 'vitest';
import { get } from 'svelte/store';
import { HashTree, LinkType, MemoryStore, type CID } from '@hashtree/core';

const getTree = vi.fn();
const waitForTreeRoot = vi.fn();
const subscribeToTreeRoot = vi.fn();
const invalidateTreeRoot = vi.fn();
const saveHashtree = vi.fn();
const cacheListeners = new Set<(npub: string, treeName: string) => void>();
const treeRootListeners = new Map<string, Set<(hash: Uint8Array | null, encryptionKey?: Uint8Array) => void>>();

vi.mock('../src/store', () => ({
  getTree,
  decodeAsText: (data: Uint8Array) => new TextDecoder().decode(data),
}));

vi.mock('../src/stores/treeRoot', () => ({
  waitForTreeRoot,
  subscribeToTreeRoot,
  invalidateTreeRoot,
}));

vi.mock('../src/nostr', () => ({
  saveHashtree,
}));

vi.mock('../src/treeRootCache', () => ({
  onCacheUpdate: (listener: (npub: string, treeName: string) => void) => {
    cacheListeners.add(listener);
    return () => {
      cacheListeners.delete(listener);
    };
  },
}));

describe('createReleaseDetailStore', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    cacheListeners.clear();
    treeRootListeners.clear();
    invalidateTreeRoot.mockResolvedValue(undefined);
    subscribeToTreeRoot.mockImplementation((npub: string, treeName: string, callback: (hash: Uint8Array | null, encryptionKey?: Uint8Array) => void) => {
      const key = `${npub}/${treeName}`;
      let listeners = treeRootListeners.get(key);
      if (!listeners) {
        listeners = new Set();
        treeRootListeners.set(key, listeners);
      }
      listeners.add(callback);
      return () => {
        const current = treeRootListeners.get(key);
        current?.delete(callback);
        if (current && current.size === 0) {
          treeRootListeners.delete(key);
        }
      };
    });
  });

  it('reloads a release when its tree root appears after the initial miss', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.14',
      title: 'v0.2.14',
      created_at: 1,
      published_at: 2,
      assets: [
        { name: 'hashtree-aarch64-apple-darwin.tar.gz', path: 'assets/hashtree-aarch64-apple-darwin.tar.gz', size: 10 },
      ],
    })));
    const notes = await tree.putFile(new TextEncoder().encode('Built from the local release artifacts.'));
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size },
      { name: 'notes.md', cid: notes.cid, size: notes.size },
    ]);
    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.14', cid: releaseDir.cid, size: 0, type: LinkType.Dir },
    ]);

    let currentRoot: CID | null = null;
    let resolveInitialLookup!: () => void;
    const initialLookupSettled = new Promise<void>(resolve => {
      resolveInitialLookup = resolve;
    });
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(async () => {
      if (waitForTreeRoot.mock.calls.length === 1) {
        resolveInitialLookup();
      }
      return currentRoot;
    });

    const { buildReleaseTreeName, createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v0.2.14');

    await initialLookupSettled;
    await Promise.resolve();
    expect(get(detailStore)).toMatchObject({
      item: null,
      loading: true,
      error: null,
    });

    currentRoot = releaseRoot.cid;
    for (const listener of cacheListeners) {
      listener('npub1owner', buildReleaseTreeName('hashtree'));
    }

    await vi.waitFor(() => {
      expect(get(detailStore).item?.id).toBe('v0.2.14');
    });
    expect(get(detailStore)).toMatchObject({
      loading: false,
      error: null,
    });
  });

  it('reports a missing release after the release tree root is known', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.14',
      title: 'v0.2.14',
      created_at: 1,
      published_at: 2,
    })));
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size },
    ]);
    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.14', cid: releaseDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid);

    const { buildReleaseTreeName, createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v9.9.9');

    // Until the resolver subscription confirms the tree root, a not-found
    // is treated as transient. Simulate the resolver firing.
    const releaseTreeName = buildReleaseTreeName('hashtree');
    await vi.waitFor(() => {
      expect(treeRootListeners.has(`npub1owner/${releaseTreeName}`)).toBe(true);
    });
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(releaseRoot.cid.hash);
    }

    await vi.waitFor(() => {
      expect(invalidateTreeRoot).toHaveBeenCalledWith('npub1owner', releaseTreeName);
    });
    expect(get(detailStore)).toMatchObject({
      item: null,
      loading: true,
      error: null,
    });

    // The forced revalidation has now had a chance to confirm the same root.
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(releaseRoot.cid.hash);
    }

    await vi.waitFor(() => {
      expect(get(detailStore).loading).toBe(false);
    });
    expect(get(detailStore)).toMatchObject({
      item: null,
      error: 'Release not found',
    });
  });

  it('marks a release detail as an htree draft when it is newer than latest', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.3',
      title: 'v0.2.3',
      created_at: 100,
      published_at: 100,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.4-rc.1',
      title: 'v0.2.4-rc.1',
      created_at: 200,
      published_at: 200,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);

    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.4-rc.1', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.3', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid);

    const { createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v0.2.4-rc.1');

    await vi.waitFor(() => {
      expect(get(detailStore).loading).toBe(false);
    });

    expect(get(detailStore).item).toMatchObject({
      id: 'v0.2.4-rc.1',
      unpromoted: true,
    });
  });

  it('loads and marks a release detail targeted by the htree draft pointer', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.3',
      title: 'v0.2.3',
      created_at: 100,
      published_at: 100,
      draft: false,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.4',
      title: 'v0.2.4',
      created_at: 200,
      published_at: 200,
      draft: true,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);

    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.4', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.3', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'draft', cid: draftDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid);

    const { createReleaseDetailStore, isPubliclyVisibleRelease } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v0.2.4');

    await vi.waitFor(() => {
      expect(get(detailStore).loading).toBe(false);
    });

    const release = get(detailStore).item;
    expect(release).toMatchObject({
      id: 'v0.2.4',
      draft: true,
      draftPointer: true,
    });
    expect(isPubliclyVisibleRelease(release!)).toBe(true);
  });

  it('revalidates a stale release root before missing a direct draft pointer route', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const oldRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v4.0.37',
      title: 'v4.0.37',
      created_at: 100,
      published_at: 100,
      draft: false,
    })));
    const oldDir = await tree.putDirectory([
      { name: 'release.json', cid: oldRecord.cid, size: oldRecord.size, type: LinkType.File },
    ]);
    const staleRoot = await tree.putDirectory([
      { name: 'latest', cid: oldDir.cid, size: 0, type: LinkType.Dir },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v4.0.40',
      title: 'v4.0.40',
      tag: 'v4.0.40',
      created_at: 200,
      published_at: 200,
      draft: true,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'latest', cid: oldDir.cid, size: 0, type: LinkType.Dir },
      { name: 'draft', cid: draftDir.cid, size: 0, type: LinkType.Dir },
    ]);

    let currentRoot = staleRoot.cid;
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(async () => currentRoot);

    const { buildReleaseTreeName, createReleaseDetailStore, isPubliclyVisibleRelease } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'nostr-vpn', 'draft');
    const releaseTreeName = buildReleaseTreeName('nostr-vpn');

    await vi.waitFor(() => {
      expect(invalidateTreeRoot).toHaveBeenCalledWith('npub1owner', releaseTreeName);
    });
    expect(get(detailStore)).toMatchObject({ item: null, loading: true, error: null });

    currentRoot = freshRoot.cid;
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(freshRoot.cid.hash);
    }

    await vi.waitFor(() => {
      expect(get(detailStore).item?.id).toBe('v4.0.40');
    });
    expect(get(detailStore).item).toMatchObject({
      id: 'v4.0.40',
      entryPath: 'draft',
      draft: true,
      draftPointer: true,
    });
    expect(isPubliclyVisibleRelease(get(detailStore).item!)).toBe(true);
  });

  it('loads release details when the tree entry path differs from release metadata id', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.3',
      title: 'v0.2.3',
      created_at: 100,
      published_at: 100,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.4',
      title: 'v0.2.4',
      tag: 'v0.2.4',
      created_at: 200,
      published_at: 200,
    })));
    const draftNotes = await tree.putFile(new TextEncoder().encode('Draft staged from a custom release path.'));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
      { name: 'notes.md', cid: draftNotes.cid, size: draftNotes.size, type: LinkType.File },
    ]);

    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.4-draft', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.3', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid);

    const { createReleasesStore, fetchReleaseDetail } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'hashtree');

    await vi.waitFor(() => {
      expect(get(releasesStore).items.length).toBe(2);
    });

    const draftSummary = get(releasesStore).items.find(item => item.id === 'v0.2.4');
    expect(draftSummary).toMatchObject({
      id: 'v0.2.4',
      entryPath: 'v0.2.4-draft',
      unpromoted: true,
    });

    await expect(fetchReleaseDetail('npub1owner', 'hashtree', 'v0.2.4-draft')).resolves.toMatchObject({
      id: 'v0.2.4',
      entryPath: 'v0.2.4-draft',
      notes: 'Draft staged from a custom release path.',
    });
    await expect(fetchReleaseDetail('npub1owner', 'hashtree', 'v0.2.4')).resolves.toMatchObject({
      id: 'v0.2.4',
      entryPath: 'v0.2.4-draft',
    });
  });

  it('keeps loading when the release id is missing but the resolver has not yet confirmed the tree root', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.3.13',
      title: 'v0.3.13',
      created_at: 1,
      published_at: 2,
    })));
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size },
    ]);
    // Stale cache: only v0.3.12 is in the locally-cached tree root, even
    // though the resolver knows about v0.3.13.
    const stalePastRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.3.12',
      title: 'v0.3.12',
      created_at: 0,
      published_at: 0,
    })));
    const stalePastDir = await tree.putDirectory([
      { name: 'release.json', cid: stalePastRecord.cid, size: stalePastRecord.size },
    ]);
    const staleRoot = await tree.putDirectory([
      { name: 'v0.3.12', cid: stalePastDir.cid, size: 0, type: LinkType.Dir },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'v0.3.12', cid: stalePastDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.3.13', cid: releaseDir.cid, size: 0, type: LinkType.Dir },
    ]);

    let currentRoot = staleRoot.cid;
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(async () => currentRoot);

    const { createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v0.3.13');

    // First refresh sees the stale root and would say "Release not found"
    // — but the resolver hasn't fired yet, so the store should stay loading
    // instead of declaring the verdict prematurely.
    await vi.waitFor(() => {
      expect(waitForTreeRoot).toHaveBeenCalled();
    });
    await Promise.resolve();
    await Promise.resolve();
    expect(get(detailStore)).toMatchObject({ loading: true, error: null });

    // Resolver delivers the fresh root and the store finds the release.
    currentRoot = freshRoot.cid;
    const releaseTreeName = 'releases/hashtree';
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(freshRoot.cid.hash);
    }

    await vi.waitFor(() => {
      expect(get(detailStore).item?.id).toBe('v0.3.13');
    });
  });

  it('ignores stale release detail lookups after a newer root loads the release', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const staleRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.13',
      title: 'v0.2.13',
      created_at: 1,
      published_at: 1,
    })));
    const staleDir = await tree.putDirectory([
      { name: 'release.json', cid: staleRecord.cid, size: staleRecord.size },
    ]);
    const staleRoot = await tree.putDirectory([
      { name: 'v0.2.13', cid: staleDir.cid, size: 0, type: LinkType.Dir },
    ]);

    const freshRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.14',
      title: 'v0.2.14',
      created_at: 2,
      published_at: 2,
    })));
    const freshDir = await tree.putDirectory([
      { name: 'release.json', cid: freshRecord.cid, size: freshRecord.size },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'v0.2.14', cid: freshDir.cid, size: 0, type: LinkType.Dir },
    ]);

    const pendingRoots: Array<(cid: CID | null) => void> = [];
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(() => new Promise<CID | null>(resolve => {
      pendingRoots.push(resolve);
    }));

    const { buildReleaseTreeName, createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'hashtree', 'v0.2.14');

    await vi.waitFor(() => {
      expect(pendingRoots.length).toBe(1);
    });

    for (const listener of cacheListeners) {
      listener('npub1owner', buildReleaseTreeName('hashtree'));
    }

    await vi.waitFor(() => {
      expect(pendingRoots.length).toBe(2);
    });

    pendingRoots[1](freshRoot.cid);
    await vi.waitFor(() => {
      expect(get(detailStore).item?.id).toBe('v0.2.14');
    });

    pendingRoots[0](staleRoot.cid);
    await Promise.resolve();

    expect(get(detailStore)).toMatchObject({
      item: expect.objectContaining({ id: 'v0.2.14' }),
      loading: false,
      error: null,
    });
  });

  it('loads release details when the release entry is a directory link misreported as a file', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.20',
      title: 'v0.2.20',
      created_at: 10,
      published_at: 11,
      assets: [
        { name: 'Iris-macos-arm64.zip', path: 'assets/Iris-macos-arm64.zip', size: 123 },
      ],
    })));
    const asset = await tree.putFile(new TextEncoder().encode('zip bytes'));
    const assetsDir = await tree.putDirectory([
      { name: 'Iris-macos-arm64.zip', cid: asset.cid, size: asset.size, type: LinkType.File },
    ]);
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size, type: LinkType.File },
      { name: 'assets', cid: assetsDir.cid, size: 0, type: LinkType.Dir },
    ]);
    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.20', cid: releaseDir.cid, size: 0, type: LinkType.File },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid);

    const { createReleaseDetailStore } = await import('../src/stores/releases');
    const detailStore = createReleaseDetailStore('npub1owner', 'iris-chromium', 'v0.2.20');

    await vi.waitFor(() => {
      expect(get(detailStore).item?.id).toBe('v0.2.20');
    });
    expect(get(detailStore).item?.assets).toEqual([
      expect.objectContaining({
        name: 'Iris-macos-arm64.zip',
        path: 'assets/Iris-macos-arm64.zip',
      }),
    ]);
  });

});
