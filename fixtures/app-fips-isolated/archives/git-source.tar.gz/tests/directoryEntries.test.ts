import { beforeEach, describe, expect, it, vi } from 'vitest';
import { writable } from 'svelte/store';
import { LinkType, type CID, type TreeEntry } from '@hashtree/core';

type Deferred<T> = {
  promise: Promise<T>;
  resolve: (value: T) => void;
};

function deferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

const olderEntries = deferred<TreeEntry[]>();
const tree = {
  isDirectory: vi.fn(async () => true),
  listDirectory: vi.fn((location: CID) => (
    location.hash[0] === 1
      ? olderEntries.promise
      : Promise.resolve([{
        name: 'new.txt',
        cid: { hash: new Uint8Array(32).fill(9) },
        size: 1,
        type: LinkType.Blob,
      } as TreeEntry])
  )),
};

vi.mock('../src/store', () => ({
  getTree: () => tree,
  appStore: {
    subscribe: (listener: (state: { peerCount: number }) => void) => {
      listener({ peerCount: 0 });
      return () => {};
    },
  },
}));

describe('directory entries', () => {
  beforeEach(() => {
    tree.isDirectory.mockClear();
    tree.listDirectory.mockClear();
  });

  it('does not let an older slow directory read replace a newer root', async () => {
    const { createDirectoryEntriesStore } = await import('../src/stores/directoryEntries');
    const locations = writable<CID | null>(null);
    const states: Array<{ entries: TreeEntry[]; loadedHashKey: string | null }> = [];
    const store = createDirectoryEntriesStore(locations);
    const unsubscribe = store.subscribe((state) => states.push(state));

    locations.set({ hash: new Uint8Array(32).fill(1) });
    await Promise.resolve();
    locations.set({ hash: new Uint8Array(32).fill(2) });
    await vi.waitFor(() => {
      expect(states.at(-1)?.entries.map((entry) => entry.name)).toEqual(['new.txt']);
    });

    olderEntries.resolve([{
      name: 'old.txt',
      cid: { hash: new Uint8Array(32).fill(8) },
      size: 1,
      type: LinkType.Blob,
    } as TreeEntry]);
    await Promise.resolve();
    await Promise.resolve();

    expect(states.at(-1)?.entries.map((entry) => entry.name)).toEqual(['new.txt']);
    expect(states.at(-1)?.loadedHashKey).toBe('02'.repeat(32));
    unsubscribe();
  });
});
