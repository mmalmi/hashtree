import { beforeEach, describe, expect, it, vi } from 'vitest';
import { get } from 'svelte/store';
import { HashTree, LinkType, MemoryStore, type CID } from '@hashtree/core';

const getTree = vi.fn();
const waitForTreeRoot = vi.fn();
const subscribeToTreeRoot = vi.fn();
const invalidateTreeRoot = vi.fn();
const saveHashtree = vi.fn();
const cacheListeners = new Set<(npub: string, treeName: string) => void>();
const treeRootListeners = new Map<string, Set<(hash: Uint8Array | null, encryptionKey?: Uint8Array) => void>>();

vi.mock('../src/store', () => ({
  getTree,
  decodeAsText: (data: Uint8Array) => new TextDecoder().decode(data),
}));

vi.mock('../src/stores/treeRoot', () => ({
  waitForTreeRoot,
  subscribeToTreeRoot,
  invalidateTreeRoot,
}));

vi.mock('../src/nostr', () => ({
  saveHashtree,
}));

vi.mock('../src/treeRootCache', () => ({
  onCacheUpdate: (listener: (npub: string, treeName: string) => void) => {
    cacheListeners.add(listener);
    return () => {
      cacheListeners.delete(listener);
    };
  },
}));

describe('createReleasesStore freshness', () => {
  beforeEach(async () => {
    const { clearReleaseListCacheForTests } = await import('../src/stores/releases');
    clearReleaseListCacheForTests();
    vi.clearAllMocks();
    cacheListeners.clear();
    treeRootListeners.clear();
    invalidateTreeRoot.mockResolvedValue(undefined);
    subscribeToTreeRoot.mockImplementation((npub: string, treeName: string, callback: (hash: Uint8Array | null, encryptionKey?: Uint8Array) => void) => {
      const key = `${npub}/${treeName}`;
      let listeners = treeRootListeners.get(key);
      if (!listeners) {
        listeners = new Set();
        treeRootListeners.set(key, listeners);
      }
      listeners.add(callback);
      return () => {
        const current = treeRootListeners.get(key);
        current?.delete(callback);
        if (current && current.size === 0) {
          treeRootListeners.delete(key);
        }
      };
    });
  });

  it('keeps a previously seen newer draft release when navigation briefly reloads a stale root', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v4.0.87',
      title: 'v4.0.87',
      created_at: 100,
      published_at: 100,
      draft: false,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v4.0.89',
      title: 'v4.0.89',
      created_at: 200,
      published_at: 200,
      draft: true,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);

    const staleRoot = await tree.putDirectory([
      { name: 'v4.0.87', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'v4.0.89', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v4.0.87', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
    ]);

    let currentRoot: CID | null = freshRoot.cid;
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(async () => currentRoot);

    const { buildReleaseTreeName, createReleasesStore } = await import('../src/stores/releases');
    const firstStore = createReleasesStore('npub1owner', 'nostr-vpn');

    await vi.waitFor(() => {
      expect(get(firstStore).items.map(item => item.id)).toEqual(['v4.0.89', 'v4.0.87']);
    });

    currentRoot = staleRoot.cid;
    const secondStore = createReleasesStore('npub1owner', 'nostr-vpn');

    await vi.waitFor(() => {
      expect(get(secondStore).items.map(item => item.id)).toEqual(['v4.0.89', 'v4.0.87']);
    });

    const releaseTreeName = buildReleaseTreeName('nostr-vpn');
    await vi.waitFor(() => {
      expect(invalidateTreeRoot).toHaveBeenCalledWith('npub1owner', releaseTreeName);
    });

    currentRoot = freshRoot.cid;
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(freshRoot.cid.hash, freshRoot.cid.key);
    }

    await vi.waitFor(() => {
      expect(get(secondStore).items.map(item => item.id)).toEqual(['v4.0.89', 'v4.0.87']);
    });
  });

  it('reloads the releases list when a fresher tree root arrives after a cached stale root', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const release014Record = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.14',
      title: 'v0.2.14',
      created_at: 1,
      published_at: 2,
    })));
    const release014Dir = await tree.putDirectory([
      { name: 'release.json', cid: release014Record.cid, size: release014Record.size },
    ]);
    const staleRoot = await tree.putDirectory([
      { name: 'v0.2.14', cid: release014Dir.cid, size: 0, type: LinkType.Dir },
    ]);

    const release016Record = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.16',
      title: 'v0.2.16',
      created_at: 3,
      published_at: 4,
    })));
    const release016Dir = await tree.putDirectory([
      { name: 'release.json', cid: release016Record.cid, size: release016Record.size },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'v0.2.16', cid: release016Dir.cid, size: 0, type: LinkType.Dir },
    ]);

    let currentRoot: CID | null = staleRoot.cid;
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(async () => currentRoot);

    const { buildReleaseTreeName, createReleasesStore } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'hashtree');

    await vi.waitFor(() => {
      expect(get(releasesStore).loading).toBe(false);
    });
    expect(get(releasesStore).items.map(item => item.id)).toEqual(['v0.2.14']);

    currentRoot = freshRoot.cid;
    const releaseTreeName = buildReleaseTreeName('hashtree');
    for (const listener of treeRootListeners.get(`npub1owner/${releaseTreeName}`) ?? []) {
      listener(freshRoot.cid.hash, freshRoot.cid.key);
    }

    await vi.waitFor(() => {
      expect(get(releasesStore).items.map(item => item.id)).toEqual(['v0.2.16']);
    });
  });
});
