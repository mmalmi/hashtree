import { describe, expect, it } from 'vitest';
import {
  DEFAULT_GIT_DISCOVERY_AUTHOR_LIMIT,
  DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_PUBKEY,
  limitGitRepoDiscoveryAuthors,
  selectGitRepoDiscoveryFollowSource,
} from '../src/stores/gitRepoDiscovery';

const userPubkey = '1'.repeat(64);
const followedPubkey = '2'.repeat(64);
const fallbackFollowedPubkey = '3'.repeat(64);

function pubkeyForIndex(index: number): string {
  return index.toString(16).padStart(64, '0');
}

describe('gitRepoDiscovery', () => {
  it('uses the logged-in user follow list when it is non-empty', () => {
    const source = selectGitRepoDiscoveryFollowSource(
      userPubkey,
      [followedPubkey],
      [fallbackFollowedPubkey],
    );

    expect(source.type).toBe('user');
    expect(source.pubkey).toBe(userPubkey);
    expect(source.follows).toEqual([followedPubkey]);
  });

  it('falls back to the seed npub follow list when the user has no follows', () => {
    const source = selectGitRepoDiscoveryFollowSource(
      userPubkey,
      [],
      [fallbackFollowedPubkey],
    );

    expect(source.type).toBe('fallback');
    expect(source.pubkey).toBe(DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_PUBKEY);
    expect(source.follows).toEqual([fallbackFollowedPubkey]);
  });

  it('dedupes and excludes the logged-in user from discovered authors', () => {
    expect(limitGitRepoDiscoveryAuthors(
      [followedPubkey, userPubkey, followedPubkey, fallbackFollowedPubkey],
      userPubkey,
      2,
    )).toEqual([followedPubkey, fallbackFollowedPubkey]);
  });

  it('keeps late seed follows that appear after the old 50-author cap', () => {
    const lateFollowedPubkey = pubkeyForIndex(388);
    const follows = [
      ...Array.from({ length: 388 }, (_, index) => pubkeyForIndex(index + 1000)),
      lateFollowedPubkey,
    ];

    expect(limitGitRepoDiscoveryAuthors(
      follows,
      userPubkey,
      DEFAULT_GIT_DISCOVERY_AUTHOR_LIMIT,
    )).toContain(lateFollowedPubkey);
    expect(limitGitRepoDiscoveryAuthors(
      follows,
      userPubkey,
      50,
    )).not.toContain(lateFollowedPubkey);
  });
});
