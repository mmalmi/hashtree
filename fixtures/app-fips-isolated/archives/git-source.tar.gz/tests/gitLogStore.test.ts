import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { CID } from '@hashtree/core';

type MockNostrState = {
  connectedRelays: number;
};

type MockCommit = {
  oid: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent: string[];
};

const shared = vi.hoisted(() => {
  let nostrState: MockNostrState = { connectedRelays: 1 };
  const subscribers = new Set<(state: MockNostrState) => void>();

  const isGitRepo = vi.fn();
  const getRefs = vi.fn();
  const getLog = vi.fn();
  const getStatus = vi.fn();
  const getHead = vi.fn();

  const nostrStore = {
    getState() {
      return nostrState;
    },
    subscribe(callback: (state: MockNostrState) => void) {
      subscribers.add(callback);
      callback(nostrState);
      return () => {
        subscribers.delete(callback);
      };
    },
  };

  const reset = () => {
    nostrState = { connectedRelays: 1 };
    subscribers.clear();
    isGitRepo.mockReset();
    getRefs.mockReset();
    getLog.mockReset();
    getStatus.mockReset();
    getHead.mockReset();
  };

  return {
    reset,
    nostrStore,
    isGitRepo,
    getRefs,
    getLog,
    getStatus,
    getHead,
  };
});

vi.mock('../src/utils/git', () => ({
  isGitRepo: (...args: unknown[]) => shared.isGitRepo(...args),
  getRefs: (...args: unknown[]) => shared.getRefs(...args),
  getLog: (...args: unknown[]) => shared.getLog(...args),
  getStatus: (...args: unknown[]) => shared.getStatus(...args),
  getHead: (...args: unknown[]) => shared.getHead(...args),
}));

vi.mock('../src/nostr', () => ({
  nostrStore: shared.nostrStore,
}));

function cid(byte: number): CID {
  return { hash: new Uint8Array([byte]), key: undefined } as CID;
}

function commit(index: number): MockCommit {
  const oid = index.toString(16).padStart(40, '0');
  return {
    oid,
    message: `Commit ${index}`,
    author: 'Test User',
    email: 'test@example.com',
    timestamp: 1000 - index,
    parent: index < 50 ? [(index + 1).toString(16).padStart(40, '0')] : [],
  };
}

function cloneLogState<T extends { commits: MockCommit[]; headOid: string | null; loading: boolean; error: string | null }>(value: T): T {
  return {
    ...value,
    commits: value.commits.map((entry) => ({
      ...entry,
      parent: [...entry.parent],
    })),
  };
}

async function flushMicrotasks(): Promise<void> {
  await Promise.resolve();
  await Promise.resolve();
}

describe('git log store', () => {
  beforeEach(() => {
    vi.resetModules();
    shared.reset();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('publishes preview commits before the full history finishes', async () => {
    const latestCommit = [commit(1)];
    const previewCommits = Array.from({ length: 10 }, (_, index) => commit(index + 1));
    const fullCommits = Array.from({ length: 50 }, (_, index) => commit(index + 1));
    let resolveFullLog: ((commits: MockCommit[]) => void) | null = null;

    shared.getLog.mockImplementation((_dirCid: CID, options?: { depth?: number }) => {
      const depth = options?.depth ?? 20;
      if (depth === 1) {
        return Promise.resolve(latestCommit);
      }
      if (depth === 10) {
        return Promise.resolve(previewCommits);
      }
      if (depth === 50) {
        return new Promise<MockCommit[]>((resolve) => {
          resolveFullLog = resolve;
        });
      }
      return Promise.resolve([]);
    });
    shared.getHead.mockResolvedValue(fullCommits[0]!.oid);

    const { createGitLogStore } = await import('../src/stores/git');
    const values: Array<ReturnType<typeof cloneLogState>> = [];
    const unsubscribe = createGitLogStore(cid(1), 50, 'iris-chromium').subscribe((value) => {
      values.push(cloneLogState(value));
    });

    await flushMicrotasks();

    expect(shared.getLog.mock.calls.map(([, options]) => options?.depth ?? 20)).toEqual([1, 10, 50]);
    expect(values.at(-1)).toMatchObject({
      commits: previewCommits,
      headOid: fullCommits[0]!.oid,
      loading: true,
      error: null,
    });

    resolveFullLog?.(fullCommits);
    await flushMicrotasks();

    expect(values.at(-1)).toMatchObject({
      commits: fullCommits,
      headOid: fullCommits[0]!.oid,
      loading: false,
      error: null,
    });

    unsubscribe();
  });
});
