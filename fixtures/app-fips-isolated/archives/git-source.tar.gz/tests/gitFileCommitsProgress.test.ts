import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { CID } from '@hashtree/core';

const wasmGetFileLastCommits = vi.fn();

vi.mock('../src/store', () => ({
  getTree: vi.fn(),
  decodeAsText: vi.fn(),
}));

vi.mock('../src/utils/wasmGit', () => ({
  getFileLastCommits: (...args: unknown[]) => wasmGetFileLastCommits(...args),
}));

function cid(byte: number): CID {
  return { hash: new Uint8Array([byte]), key: undefined } as CID;
}

describe('getFileLastCommits progress', () => {
  beforeEach(() => {
    vi.resetModules();
    wasmGetFileLastCommits.mockReset();
  });

  it('streams file commit progress without duplicating the final result', async () => {
    const commitA = { oid: 'a'.repeat(40), message: 'Commit A', timestamp: 123 };
    const commitB = { oid: 'b'.repeat(40), message: 'Commit B', timestamp: 456 };
    let resolveFetch: (() => void) | null = null;

    wasmGetFileLastCommits.mockImplementation(
      async (
        _rootCid: CID,
        _filenames: string[],
        _subpath: string | undefined,
        onProgress?: (filename: string, commitInfo: { oid: string; message: string; timestamp: number }) => void
      ) => {
        onProgress?.('alpha.ts', commitA);
        await new Promise<void>((resolve) => {
          resolveFetch = resolve;
        });
        return new Map([
          ['alpha.ts', commitA],
          ['beta.ts', commitB],
        ]);
      }
    );

    const progress: Array<{ filename: string; oid: string }> = [];
    const { getFileLastCommits } = await import('../src/utils/git');
    const pending = getFileLastCommits(cid(1), ['alpha.ts', 'beta.ts'], undefined, (filename, commitInfo) => {
      progress.push({ filename, oid: commitInfo.oid });
    });

    await vi.waitFor(() => {
      expect(progress).toEqual([
        { filename: 'alpha.ts', oid: commitA.oid },
      ]);
    });

    resolveFetch?.();
    const result = await pending;

    expect(progress).toEqual([
      { filename: 'alpha.ts', oid: commitA.oid },
      { filename: 'beta.ts', oid: commitB.oid },
    ]);
    expect(Array.from(result.entries())).toEqual([
      ['alpha.ts', commitA],
      ['beta.ts', commitB],
    ]);
  });
});
