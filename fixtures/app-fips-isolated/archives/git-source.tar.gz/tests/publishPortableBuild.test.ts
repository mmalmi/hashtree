import { describe, expect, it } from 'vitest';
import { createPublishPlan } from '../scripts/publish-iris-build.mjs';

describe('publish-iris-build', () => {
  it('supports the git portable publish plan', () => {
    expect(createPublishPlan('git')).toMatchObject({
      name: 'git',
      appName: 'Iris Git',
      distDir: 'iris-git',
      treeName: 'git',
    });
  });

  it('publishes the selected tree name from the matching dist directory', () => {
    const command = createPublishPlan('git').command;
    expect(command.slice(-4)).toEqual(['add', '.', '--publish', 'git']);

    if (command[0] === 'cargo') {
      expect(command).toEqual([
        'cargo',
        'run',
        '--manifest-path',
        expect.stringContaining('/rust/Cargo.toml'),
        '-p',
        'hashtree-cli',
        '--bin',
        'htree',
        '--',
        'add',
        '.',
        '--publish',
        'git',
      ]);
    } else {
      expect(command).toEqual(['htree', 'add', '.', '--publish', 'git']);
    }

    expect(createPublishPlan('git').distDir).toMatch(/iris-git$/);
  });
});
