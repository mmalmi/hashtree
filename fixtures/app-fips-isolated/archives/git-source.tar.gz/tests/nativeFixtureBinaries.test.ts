import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';

import {
  EXPECTED_HTREE_VERSION,
  resolveNativeFixtureBinaries,
} from '../e2e/native-binaries.js';

const tempDirs: string[] = [];

function tempDir(): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-git-native-bins-'));
  tempDirs.push(dir);
  return dir;
}

function executable(dir: string, name: string, body: string): string {
  const file = path.join(dir, name);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, `#!/bin/sh\n${body}\n`);
  fs.chmodSync(file, 0o755);
  return file;
}

afterEach(() => {
  for (const dir of tempDirs.splice(0)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

describe('released native fixture binaries', () => {
  it('pins the latest immutable Hashtree CLI release', () => {
    expect(EXPECTED_HTREE_VERSION).toBe('0.2.142');
  });

  it('uses explicit inputs and requires the pinned htree release', () => {
    const binDir = tempDir();
    const htree = executable(binDir, 'htree', `echo 'htree ${EXPECTED_HTREE_VERSION}'`);
    const gitRemoteHtree = executable(binDir, 'git-remote-htree', 'exit 0');

    expect(resolveNativeFixtureBinaries({
      PATH: '',
      HTREE_BIN: htree,
      GIT_REMOTE_HTREE_BIN: gitRemoteHtree,
    })).toEqual({ htree, gitRemoteHtree });
  });

  it('resolves installed PATH binaries without consulting a sibling Rust checkout', () => {
    const root = tempDir();
    const pathBin = path.join(root, 'path-bin');
    const siblingTarget = path.join(root, 'hashtree', 'rust', 'target', 'release');
    const htree = executable(pathBin, 'htree', `echo 'htree ${EXPECTED_HTREE_VERSION}'`);
    const gitRemoteHtree = executable(pathBin, 'git-remote-htree', 'exit 0');
    executable(siblingTarget, 'htree', `echo 'htree ${EXPECTED_HTREE_VERSION}'`);
    executable(siblingTarget, 'git-remote-htree', 'exit 0');

    expect(resolveNativeFixtureBinaries({
      PATH: pathBin,
      HASHTREE_RUST_DIR: path.join(root, 'hashtree', 'rust'),
    })).toEqual({ htree, gitRemoteHtree });
  });

  it('fails clearly instead of falling back to Cargo or a sibling checkout', () => {
    const root = tempDir();
    const siblingTarget = path.join(root, 'hashtree', 'rust', 'target', 'release');
    executable(siblingTarget, 'htree', `echo 'htree ${EXPECTED_HTREE_VERSION}'`);
    executable(siblingTarget, 'git-remote-htree', 'exit 0');

    expect(() => resolveNativeFixtureBinaries({
      PATH: path.join(root, 'empty-path'),
      HASHTREE_RUST_DIR: path.join(root, 'hashtree', 'rust'),
    })).toThrow(/HTREE_BIN.*PATH/);
  });

  it('rejects an installed htree with the wrong version', () => {
    const binDir = tempDir();
    executable(binDir, 'htree', 'echo \'htree 0.2.87\'');
    executable(binDir, 'git-remote-htree', 'exit 0');

    expect(() => resolveNativeFixtureBinaries({ PATH: binDir })).toThrow(
      `expected htree ${EXPECTED_HTREE_VERSION}, got htree 0.2.87`,
    );
  });

  it('fails clearly when git-remote-htree is not installed', () => {
    const binDir = tempDir();
    executable(binDir, 'htree', `echo 'htree ${EXPECTED_HTREE_VERSION}'`);

    expect(() => resolveNativeFixtureBinaries({ PATH: binDir })).toThrow(
      /GIT_REMOTE_HTREE_BIN.*git-remote-htree.*PATH/,
    );
  });

  it('keeps the process harness free of Cargo and checkout discovery', () => {
    const root = path.resolve(import.meta.dirname, '..');
    const e2eDir = path.join(root, 'e2e');
    const harness = fs.readdirSync(e2eDir)
      .filter((file) => /\.(?:ts|js|sh)$/.test(file))
      .map((file) => fs.readFileSync(path.join(e2eDir, file), 'utf8'))
      .join('\n');
    expect(harness).not.toMatch(/\bcargo\s+(?:build|run)\b/i);
    expect(harness).not.toContain('rust-target');

    for (const file of ['e2e/global-setup.ts', 'e2e/htree-blossom.sh']) {
      const source = fs.readFileSync(path.join(root, file), 'utf8');
      expect(source).not.toContain('HASHTREE_RUST_DIR');
    }
    expect(fs.readFileSync(path.join(root, 'e2e/htree-blossom.sh'), 'utf8'))
      .toContain(`EXPECTED_HTREE_VERSION="${EXPECTED_HTREE_VERSION}"`);

    const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');
    expect(readme).toContain(
      `cargo install hashtree-cli --version ${EXPECTED_HTREE_VERSION} --locked --features fips-webrtc`,
    );
  });
});
