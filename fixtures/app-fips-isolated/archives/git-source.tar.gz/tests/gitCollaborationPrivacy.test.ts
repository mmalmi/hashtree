import { beforeEach, describe, expect, it, vi } from 'vitest';
import { finalizeEvent, getPublicKey, nip19, type Event, type EventTemplate } from 'nostr-tools';

const mocks = vi.hoisted(() => ({
  queryEvents: vi.fn(),
  signEvent: vi.fn(),
  publish: vi.fn(),
  getState: vi.fn(),
  getRoot: vi.fn(),
}));
vi.mock('../src/nostr', () => ({
  nostr: { signer: {}, signEvent: mocks.signEvent, publish: mocks.publish },
  nostrStore: { getState: mocks.getState },
  pubkeyToNpub: (pubkey: string) => nip19.npubEncode(pubkey),
  npubToPubkey: (npub: string) => nip19.decode(npub).data,
}));
vi.mock('../src/lib/workerInit', () => ({
  waitForWorkerAdapter: async () => ({ queryEvents: mocks.queryEvents }),
}));
vi.mock('@hashtree/worker/tree-root', () => ({
  treeRootRegistry: { get: mocks.getRoot },
}));

import { addComment, buildRepoAddress, createIssue, createPullRequest, publishNip34Event, updateStatus } from '../src/nip34';

const secret = new Uint8Array(32).fill(1);
const pubkey = getPublicKey(secret);
const npub = nip19.npubEncode(pubkey);
const repoName = 'projects/example';
let roots: Event[];
let issue: Event;

function root(visibility: 'public' | 'private' | 'link-visible', created_at = 1): Event {
  return finalizeEvent({
    kind: 30064, created_at, content: '',
    tags: [['d', 'projects'], ['hash', 'a'.repeat(64)], ['l', 'hashtree'],
      ...(visibility === 'private' ? [['selfEncryptedKey', 'encrypted']] : []),
      ...(visibility === 'link-visible' ? [['encryptedKey', 'encrypted']] : []),
    ],
  }, secret);
}

beforeEach(() => {
  vi.clearAllMocks();
  roots = [root('public')];
  issue = finalizeEvent({ kind: 1621, created_at: 1, content: 'Existing issue', tags: [['a', buildRepoAddress(npub, repoName)]] }, secret);
  mocks.getState.mockReturnValue({ pubkey, npub });
  mocks.getRoot.mockReturnValue(undefined);
  mocks.signEvent.mockImplementation(async (event: EventTemplate) => finalizeEvent(event, secret));
  mocks.publish.mockResolvedValue(undefined);
  mocks.queryEvents.mockImplementation(async (filters) => ({
    events: filters[0].ids ? [issue].filter(event => filters[0].ids.includes(event.id)) : roots,
  }));
});

const operations = {
  issue: () => createIssue(npub, repoName, 'Title', 'Body'),
  'pull request': () => createPullRequest(npub, repoName, 'Title', 'Body'),
  comment: () => addComment(issue.id, pubkey, 'Reply', buildRepoAddress(npub, repoName)),
  status: () => updateStatus(issue.id, pubkey, 'closed'),
};

describe('Git collaboration privacy at publication', () => {
  for (const [name, publish] of Object.entries(operations)) {
    it(`publishes a ${name} for a confirmed public repository`, async () => {
      expect(await publish()).toBeTruthy();
      expect(mocks.publish).toHaveBeenCalledOnce();
      expect(mocks.queryEvents).toHaveBeenCalledWith(
        [expect.objectContaining({ authors: [pubkey], '#d': ['projects'] })], expect.anything(),
      );
    });

    for (const visibility of ['private', 'link-visible', 'unknown'] as const) {
      it(`blocks a ${name} when visibility is ${visibility}`, async () => {
        roots = visibility === 'unknown' ? [] : [root(visibility)];
        await expect(publish()).rejects.toThrow(/public|visibility/i);
        expect(mocks.signEvent).not.toHaveBeenCalled();
        expect(mocks.publish).not.toHaveBeenCalled();
      });
    }
  }

  it('does not treat a default public cache entry as confirmation', async () => {
    roots = [];
    mocks.getRoot.mockReturnValue({ visibility: 'public' });
    await expect(operations.issue()).rejects.toThrow(/visibility/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('honors a local privacy change even when the relay still has the public root', async () => {
    mocks.getRoot.mockReturnValue({ visibility: 'private' });
    await expect(operations.issue()).rejects.toThrow(/public/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('uses the newest root, not an older public announcement', async () => {
    roots = [root('public'), root('private', 2)];
    await expect(operations.issue()).rejects.toThrow(/public/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('rechecks privacy after an asynchronous signing prompt', async () => {
    mocks.signEvent.mockImplementationOnce(async (event: EventTemplate) => {
      roots = [root('private', 2)];
      return finalizeEvent(event, secret);
    });
    await expect(operations.issue()).rejects.toThrow(/public/i);
    expect(mocks.signEvent).toHaveBeenCalledOnce();
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('blocks direct publication without a repository reference', async () => {
    await expect(publishNip34Event({ kind: 1621, created_at: 1, content: 'Secret', tags: [] })).rejects.toThrow();
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('checks the actual comment target, not just the supplied repository address', async () => {
    const otherAddress = buildRepoAddress(npub, 'other');
    await expect(addComment(issue.id, pubkey, 'Secret', otherAddress)).rejects.toThrow();
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('blocks status updates whose original issue cannot be resolved', async () => {
    await expect(updateStatus('f'.repeat(64), pubkey, 'closed')).rejects.toThrow();
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('fails closed if visibility lookup fails', async () => {
    mocks.queryEvents.mockRejectedValue(new Error('offline'));
    await expect(operations.issue()).rejects.toThrow(/visibility/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it.each(['#private', `#k=${'b'.repeat(64)}`])('blocks a protected PR source URL (%s)', async (fragment) => {
    await expect(createPullRequest(npub, repoName, 'Title', 'Body', {
      cloneUrl: `htree://${npub}/fork${fragment}`,
    })).rejects.toThrow(/public/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('blocks an unresolved PR source even when the destination is public', async () => {
    await expect(createPullRequest(npub, repoName, 'Title', 'Body', {
      cloneUrl: `${npub}/unknown-fork`,
    })).rejects.toThrow(/visibility/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });

  it('does not accept another owner or tree as evidence of public visibility', async () => {
    roots = [finalizeEvent({ kind: 30064, created_at: 1, content: '', tags: [['d', 'other'], ['hash', 'a'.repeat(64)]] }, secret)];
    await expect(operations.issue()).rejects.toThrow(/visibility/i);
    expect(mocks.publish).not.toHaveBeenCalled();
  });
});
