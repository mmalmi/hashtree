import { afterEach, describe, expect, it, vi } from 'vitest';
import { fromHex, nhashEncode } from '@hashtree/core';
import {
  buildReleaseTreeName,
  getReleaseAssetDownloadUrl,
  isListedReleaseEntryName,
  resolveReleaseAssetMarkdownLink,
  sanitizeReleaseId,
} from '../src/stores/releaseHelpers';
import { get } from 'svelte/store';
import { HashTree, LinkType, MemoryStore, type CID } from '@hashtree/core';

const getTree = vi.fn();
const waitForTreeRoot = vi.fn();
const subscribeToTreeRoot = vi.fn();
const invalidateTreeRoot = vi.fn();
const cacheListeners = new Set<(npub: string, treeName: string) => void>();

vi.mock('../src/store', async () => {
  const actual = await vi.importActual<typeof import('../src/store')>('../src/store');
  return {
    ...actual,
    getTree,
  };
});

vi.mock('../src/stores/treeRoot', () => ({
  waitForTreeRoot,
  subscribeToTreeRoot,
  invalidateTreeRoot,
}));

vi.mock('../src/treeRootCache', () => ({
  onCacheUpdate: (listener: (npub: string, treeName: string) => void) => {
    cacheListeners.add(listener);
    return () => {
      cacheListeners.delete(listener);
    };
  },
}));

describe('releases store helpers', () => {
  afterEach(async () => {
    vi.unstubAllGlobals();
    const { clearReleaseListCacheForTests } = await import('../src/stores/releases');
    clearReleaseListCacheForTests();
    vi.clearAllMocks();
    cacheListeners.clear();
  });

  it('shows available releases while an older release stalls, and retains them on failure', async () => {
    const tree = new HashTree({ store: new MemoryStore() });
    const record = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v2', title: 'v2', created_at: 200,
    })));
    const release = await tree.putDirectory([
      { name: 'release.json', cid: record.cid, size: record.size, type: LinkType.File },
    ]);
    const missing = { hash: new Uint8Array(32).fill(77) };
    const root = await tree.putDirectory([
      { name: 'v1', cid: missing, size: 0, type: LinkType.Dir },
      { name: 'v2', cid: release.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: release.cid, size: 0, type: LinkType.Dir },
    ]);
    let rejectMissing!: (error: Error) => void;
    const blocked = new Promise<never>((_, reject) => { rejectMissing = reject; });
    const resolve = tree.resolvePath.bind(tree);
    vi.spyOn(tree, 'resolvePath').mockImplementation((cid, path) =>
      cid.hash.every(byte => byte === 77) ? blocked : resolve(cid, path),
    );
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(root.cid);
    const { createReleasesStore } = await import('../src/stores/releases');
    const releases = createReleasesStore('npub1owner', 'partial');
    await vi.waitFor(() => {
      expect(get(releases).items).toMatchObject([{ id: 'v2', latest: true }]);
    });
    rejectMissing(new Error('Blob retrieval timed out'));
    await vi.waitFor(() => expect(get(releases).loading).toBe(false));
    expect(get(releases).items).toMatchObject([{ id: 'v2', latest: true }]);
    expect(get(releases).error).toBe('Some releases could not be loaded.');
  });

  it('builds the repo release tree name under releases/<repo>', () => {
    expect(buildReleaseTreeName('nostr-vpn')).toBe('releases/nostr-vpn');
    expect(buildReleaseTreeName('/nostr-vpn/')).toBe('releases/nostr-vpn');
  });

  it('builds release asset urls on the app /htree route instead of upload.iris.to', async () => {
    vi.resetModules();
    vi.stubGlobal('window', {
      location: {
        protocol: 'https:',
        hostname: 'git.iris.to',
        search: '',
      },
    });
    const storage = new Map<string, string>();
    vi.stubGlobal('sessionStorage', {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => {
        storage.set(key, value);
      },
    });
    vi.stubGlobal('crypto', {
      randomUUID: () => 'test-media-client',
    });

    const { getReleaseAssetUrl } = await import('../src/stores/releaseHelpers');
    const url = getReleaseAssetUrl(
      'npub1example',
      'nostr-vpn',
      'v0.3.3',
      'assets/nostr-vpn-v0.3.3-macos-arm64.zip',
    );

    expect(url).toBe(
      '/htree/npub1example/releases%2Fnostr-vpn/v0.3.3/assets/nostr-vpn-v0.3.3-macos-arm64.zip?htree_c=test-media-client',
    );
    expect(url).not.toContain('upload.iris.to');
  });

  it('preserves the link key on release asset urls', async () => {
    vi.resetModules();
    vi.stubGlobal('window', {
      location: {
        protocol: 'https:',
        hostname: 'git.iris.to',
        search: '',
      },
    });
    const storage = new Map<string, string>();
    vi.stubGlobal('sessionStorage', {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => {
        storage.set(key, value);
      },
    });
    vi.stubGlobal('crypto', {
      randomUUID: () => 'test-media-client',
    });

    const { getReleaseAssetUrl } = await import('../src/stores/releaseHelpers');
    const url = getReleaseAssetUrl(
      'npub1example',
      'nostr-vpn',
      'v0.3.3',
      'assets/nostr-vpn-v0.3.3-macos-arm64.zip',
      'ab'.repeat(32),
    );

    expect(url).toBe(
      '/htree/npub1example/releases%2Fnostr-vpn/v0.3.3/assets/nostr-vpn-v0.3.3-macos-arm64.zip?htree_c=test-media-client&k=' + 'ab'.repeat(32),
    );
  });

  it('builds release asset download urls that preserve client and link keys', async () => {
    vi.resetModules();
    vi.stubGlobal('window', {
      location: {
        protocol: 'https:',
        hostname: 'git.iris.to',
        search: '',
      },
    });
    const storage = new Map<string, string>();
    vi.stubGlobal('sessionStorage', {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => {
        storage.set(key, value);
      },
    });
    vi.stubGlobal('crypto', {
      randomUUID: () => 'test-media-client',
    });

    const url = getReleaseAssetDownloadUrl(
      'npub1example',
      'nostr-vpn',
      'v0.3.3',
      'assets/nostr-vpn-v0.3.3-macos-arm64.zip',
      'ab'.repeat(32),
    );

    expect(url).toBe(
      '/htree/npub1example/releases%2Fnostr-vpn/v0.3.3/assets/nostr-vpn-v0.3.3-macos-arm64.zip?htree_c=test-media-client&k=' + 'ab'.repeat(32) + '&download=1',
    );
  });

  it('prefers immutable nhash download urls when the release asset cid is known', () => {
    const assetCid = {
      hash: fromHex('1'.repeat(64)),
      key: fromHex('2'.repeat(64)),
    };

    const url = getReleaseAssetDownloadUrl(
      'npub1example',
      'nostr-vpn',
      'v0.3.3',
      'assets/nostr-vpn-v0.3.3-macos-arm64.zip',
      undefined,
      assetCid,
      'nostr-vpn-v0.3.3-macos-arm64.zip',
    );

    expect(url).toBe(
      `/htree/${nhashEncode(assetCid)}/nostr-vpn-v0.3.3-macos-arm64.zip?htree_c=test-media-client&download=1`,
    );
  });

  it('matches release-note links to release assets by path or filename', () => {
    const assets = [
      { name: 'iris-chat-v3.1.0-macos-arm64.dmg', path: 'assets/iris-chat-v3.1.0-macos-arm64.dmg', size: 10 },
      { name: 'space file.zip', path: 'assets/space file.zip', size: 20 },
    ];

    expect(resolveReleaseAssetMarkdownLink('assets/iris-chat-v3.1.0-macos-arm64.dmg', assets)).toBe(assets[0]);
    expect(resolveReleaseAssetMarkdownLink('./assets/iris-chat-v3.1.0-macos-arm64.dmg?download=1', assets)).toBe(assets[0]);
    expect(resolveReleaseAssetMarkdownLink('iris-chat-v3.1.0-macos-arm64.dmg', assets)).toBe(assets[0]);
    expect(resolveReleaseAssetMarkdownLink('/assets/space%20file.zip', assets)).toBe(assets[1]);
    expect(resolveReleaseAssetMarkdownLink('../assets/iris-chat-v3.1.0-macos-arm64.dmg', assets)).toBeNull();
    expect(resolveReleaseAssetMarkdownLink('https://example.com/iris-chat-v3.1.0-macos-arm64.dmg', assets)).toBeNull();
  });

  it('sanitizes release ids for tree entries', () => {
    expect(sanitizeReleaseId(' v0.2.27 beta / 1 ')).toBe('v0.2.27-beta-1');
  });

  it('hides synthetic latest and draft pointers from raw release entry listings', () => {
    expect(isListedReleaseEntryName('v0.2.27')).toBe(true);
    expect(isListedReleaseEntryName('latest')).toBe(false);
    expect(isListedReleaseEntryName('draft')).toBe(false);
  });

  it('marks htree draft releases as unpromoted without hiding older stable releases', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.3',
      title: 'v0.2.3',
      created_at: 100,
      published_at: 100,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.4-rc.1',
      title: 'v0.2.4-rc.1',
      created_at: 200,
      published_at: 200,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);

    const oldRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.2',
      title: 'v0.2.2',
      created_at: 50,
      published_at: 50,
    })));
    const oldDir = await tree.putDirectory([
      { name: 'release.json', cid: oldRecord.cid, size: oldRecord.size, type: LinkType.File },
    ]);

    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.4-rc.1', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.3', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.2', cid: oldDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid as CID);

    const { createReleasesStore } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'hashtree');

    await vi.waitFor(() => {
      expect(get(releasesStore).loading).toBe(false);
    });

    const releases = get(releasesStore).items;
    expect(releases.map(item => item.id)).toEqual(['v0.2.4-rc.1', 'v0.2.3', 'v0.2.2']);
    expect(releases[0]).toMatchObject({ id: 'v0.2.4-rc.1', unpromoted: true });
    expect(releases[1]).toMatchObject({ id: 'v0.2.3', latest: true });
    expect(releases[2]).not.toHaveProperty('unpromoted');
  });

  it('marks the release targeted by the htree draft pointer and does not duplicate it', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const stableRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.3',
      title: 'v0.2.3',
      created_at: 100,
      published_at: 100,
      draft: false,
    })));
    const stableDir = await tree.putDirectory([
      { name: 'release.json', cid: stableRecord.cid, size: stableRecord.size, type: LinkType.File },
    ]);

    const draftRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.2.4',
      title: 'v0.2.4',
      created_at: 200,
      published_at: 200,
      draft: true,
    })));
    const draftDir = await tree.putDirectory([
      { name: 'release.json', cid: draftRecord.cid, size: draftRecord.size, type: LinkType.File },
    ]);

    const releaseRoot = await tree.putDirectory([
      { name: 'v0.2.4', cid: draftDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.2.3', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'latest', cid: stableDir.cid, size: 0, type: LinkType.Dir },
      { name: 'draft', cid: draftDir.cid, size: 0, type: LinkType.Dir },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid as CID);

    const { createReleasesStore, isPubliclyVisibleRelease } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'hashtree');

    await vi.waitFor(() => {
      expect(get(releasesStore).loading).toBe(false);
    });

    const releases = get(releasesStore).items;
    expect(releases.map(item => item.id)).toEqual(['v0.2.4', 'v0.2.3']);
    expect(releases[0]).toMatchObject({
      id: 'v0.2.4',
      draft: true,
      draftPointer: true,
    });
    expect(isPubliclyVisibleRelease(releases[0])).toBe(true);
    expect(releases[1]).toMatchObject({ id: 'v0.2.3', latest: true });
  });

  it('lists releases even when the release entry is a directory link misreported as a file', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v149.0.7801.0',
      title: 'v149.0.7801.0',
      created_at: 100,
      published_at: 101,
    })));
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size, type: LinkType.File },
    ]);
    const releaseRoot = await tree.putDirectory([
      { name: 'v149.0.7801.0', cid: releaseDir.cid, size: 0, type: LinkType.File },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid as CID);

    const { createReleasesStore } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'iris-chromium');

    await vi.waitFor(() => {
      expect(get(releasesStore).loading).toBe(false);
    });
    expect(get(releasesStore).items.map(item => item.id)).toEqual(['v149.0.7801.0']);
  });

  it('does not let a stale initial refresh clobber a fresher subscription-triggered refresh', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const staleRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.3.12',
      title: 'v0.3.12',
      created_at: 1,
      published_at: 1,
    })));
    const staleDir = await tree.putDirectory([
      { name: 'release.json', cid: staleRecord.cid, size: staleRecord.size },
    ]);
    const staleRoot = await tree.putDirectory([
      { name: 'v0.3.12', cid: staleDir.cid, size: 0, type: LinkType.Dir },
    ]);

    const freshRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v0.3.13',
      title: 'v0.3.13',
      created_at: 2,
      published_at: 2,
    })));
    const freshDir = await tree.putDirectory([
      { name: 'release.json', cid: freshRecord.cid, size: freshRecord.size },
    ]);
    const freshRoot = await tree.putDirectory([
      { name: 'v0.3.13', cid: freshDir.cid, size: 0, type: LinkType.Dir },
      { name: 'v0.3.12', cid: staleDir.cid, size: 0, type: LinkType.Dir },
    ]);

    const treeRootListeners = new Set<() => void>();
    const pendingRoots: Array<(cid: CID | null) => void> = [];
    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockImplementation(() => new Promise<CID | null>(resolve => {
      pendingRoots.push(resolve);
    }));
    subscribeToTreeRoot.mockImplementation((_npub: string, _treeName: string, callback: () => void) => {
      treeRootListeners.add(callback);
      return () => {
        treeRootListeners.delete(callback);
      };
    });

    const { createReleasesStore } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'squirreldisk');

    // Initial refresh kicked off; subscription was added.
    await vi.waitFor(() => {
      expect(pendingRoots.length).toBe(1);
      expect(treeRootListeners.size).toBe(1);
    });

    // Subscription fires (resolver delivered current value), triggering a
    // second refresh while the first is still pending.
    for (const cb of treeRootListeners) cb();
    await vi.waitFor(() => {
      expect(pendingRoots.length).toBe(2);
    });

    // The second refresh resolves first with the fresh root.
    pendingRoots[1](freshRoot.cid);
    await vi.waitFor(() => {
      expect(get(releasesStore).items.map(i => i.id)).toEqual(['v0.3.13', 'v0.3.12']);
    });

    // The first (stale) refresh resolves later. Without the sequence guard,
    // its items would land last and the listing would regress to v0.3.12.
    pendingRoots[0](staleRoot.cid);
    await Promise.resolve();
    await Promise.resolve();
    expect(get(releasesStore).items.map(i => i.id)).toEqual(['v0.3.13', 'v0.3.12']);
  });

  it('parses ISO release timestamps from release.json into unix seconds', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });

    const releaseRecord = await tree.putFile(new TextEncoder().encode(JSON.stringify({
      id: 'v149.0.7801.0',
      title: 'v149.0.7801.0',
      created_at: '2026-04-20T08:16:30Z',
      published_at: '2026-04-20T08:16:30Z',
    })));
    const releaseDir = await tree.putDirectory([
      { name: 'release.json', cid: releaseRecord.cid, size: releaseRecord.size, type: LinkType.File },
    ]);
    const releaseRoot = await tree.putDirectory([
      { name: 'v149.0.7801.0', cid: releaseDir.cid, size: 0, type: LinkType.File },
    ]);

    getTree.mockReturnValue(tree);
    waitForTreeRoot.mockResolvedValue(releaseRoot.cid as CID);

    const { createReleasesStore } = await import('../src/stores/releases');
    const releasesStore = createReleasesStore('npub1owner', 'iris-chromium');

    await vi.waitFor(() => {
      expect(get(releasesStore).loading).toBe(false);
    });

    const [release] = get(releasesStore).items;
    const expectedTimestamp = Math.floor(Date.parse('2026-04-20T08:16:30Z') / 1000);
    expect(release.created_at).toBe(expectedTimestamp);
    expect(release.published_at).toBe(expectedTimestamp);
  });
});
