import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { getAppBrand } from '../src/lib/appBrand';

const root = process.cwd();
const publicDir = path.join(root, 'public');

function read(relativePath: string): string {
  return fs.readFileSync(path.join(root, relativePath), 'utf8');
}

describe('iris-git app branding', () => {
  it('defines the Git icon set', () => {
    const brand = getAppBrand();

    expect(brand).toMatchObject({
      id: 'git',
      label: 'Git',
      displayName: 'Iris Git',
      iconSvg: 'iris-git-icon.svg',
    });
    expect(fs.existsSync(path.join(publicDir, brand.iconSvg))).toBe(true);
    expect(fs.existsSync(path.join(publicDir, brand.appleTouchPng))).toBe(true);
    expect(fs.existsSync(path.join(publicDir, brand.pwa192Png))).toBe(true);
    expect(fs.existsSync(path.join(publicDir, brand.pwa512Png))).toBe(true);
  });

  it('points the html entry to the Git favicon svg', () => {
    const source = read('git.html');
    const brand = getAppBrand();

    expect(source).toContain(`type="image/svg+xml" href="%BASE_URL%${brand.iconSvg}"`);
    expect(source).not.toContain('iris-favicon.png');
  });

  it('uses a product-cased browser page title', () => {
    const source = read('git.html');

    expect(source).toContain('<title>Iris Git</title>');
  });

  it('keeps the shared header logo on the app name', () => {
    const source = read('src/components/Logo.svelte');

    expect(source).toContain('>{brand.label}</span>');
    expect(source).not.toContain('>iris <span');
  });

  it('uses Git install icons in the portable build config', () => {
    const source = read('vite.git.config.ts');

    expect(source).toContain("const brand = getAppBrand('git')");
    expect(source).toContain('includeAssets: [brand.iconSvg, brand.appleTouchPng]');
    expect(source).toContain("icons: getAppPwaIcons('git')");
    expect(source).not.toContain("'iris-logo.png'");
  });
});
