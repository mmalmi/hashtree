import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { CID } from '@hashtree/core';

type MockNostrState = {
  connectedRelays: number;
};

type MockGitRefsResult = {
  branches: string[];
  currentBranch: string | null;
  tags: string[];
  tagsByCommit: Record<string, string[]>;
};

const shared = vi.hoisted(() => {
  let nostrState: MockNostrState = { connectedRelays: 1 };
  const subscribers = new Set<(state: MockNostrState) => void>();

  const isGitRepo = vi.fn();
  const getRefs = vi.fn();
  const getLog = vi.fn();
  const getStatus = vi.fn();
  const getHead = vi.fn();

  const nostrStore = {
    getState() {
      return nostrState;
    },
    subscribe(callback: (state: MockNostrState) => void) {
      subscribers.add(callback);
      callback(nostrState);
      return () => {
        subscribers.delete(callback);
      };
    },
    __setState(next: Partial<MockNostrState>) {
      nostrState = { ...nostrState, ...next };
      for (const callback of Array.from(subscribers)) {
        callback(nostrState);
      }
    },
  };

  const reset = () => {
    nostrState = { connectedRelays: 1 };
    subscribers.clear();
    isGitRepo.mockReset();
    getRefs.mockReset();
    getLog.mockReset();
    getStatus.mockReset();
    getHead.mockReset();
  };

  return {
    reset,
    nostrStore,
    isGitRepo,
    getRefs,
    getLog,
    getStatus,
    getHead,
  };
});

vi.mock('../src/utils/git', () => ({
  isGitRepo: (...args: unknown[]) => shared.isGitRepo(...args),
  getRefs: (...args: unknown[]) => shared.getRefs(...args),
  getLog: (...args: unknown[]) => shared.getLog(...args),
  getStatus: (...args: unknown[]) => shared.getStatus(...args),
  getHead: (...args: unknown[]) => shared.getHead(...args),
}));

vi.mock('../src/nostr', () => ({
  nostrStore: shared.nostrStore,
}));

function cid(byte: number): CID {
  return { hash: new Uint8Array([byte]), key: undefined } as CID;
}

async function flushMicrotasks(): Promise<void> {
  await Promise.resolve();
  await Promise.resolve();
}

function cloneInfo<T extends MockGitRefsResult & { isRepo: boolean; loading: boolean }>(value: T): T {
  return {
    ...value,
    branches: [...value.branches],
    tags: [...value.tags],
    tagsByCommit: { ...value.tagsByCommit },
  };
}

describe('git info store', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.resetModules();
    shared.reset();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('publishes branch and tag names before tag targets finish resolving', async () => {
    let finishTagNames!: () => void;
    const tagNamesPending = new Promise<void>((resolve) => {
      finishTagNames = resolve;
    });
    let finishTagResolution!: () => void;
    const tagResolutionPending = new Promise<void>((resolve) => {
      finishTagResolution = resolve;
    });

    shared.isGitRepo.mockResolvedValue(true);
    shared.getRefs.mockImplementation(async (_cid: CID, options?: {
      onBranches?: (refs: Pick<MockGitRefsResult, 'branches' | 'currentBranch'>) => void;
      onRefNames?: (refs: Omit<MockGitRefsResult, 'tagsByCommit'>) => void;
    }): Promise<MockGitRefsResult> => {
      options?.onBranches?.({
        branches: ['master'],
        currentBranch: 'master',
      });
      await tagNamesPending;
      options?.onRefNames?.({
        branches: ['master'],
        currentBranch: 'master',
        tags: ['v0.2.22'],
      });
      await tagResolutionPending;
      return {
        branches: ['master'],
        currentBranch: 'master',
        tags: ['v0.2.22'],
        tagsByCommit: {
          a317269c6e4d63d6cf0f66a0a0268b65df6390a5: ['v0.2.22'],
        },
      };
    });

    const { createGitInfoStore } = await import('../src/stores/git');
    const values: Array<ReturnType<typeof cloneInfo> & {
      branchNamesLoading?: boolean;
      tagNamesLoading?: boolean;
    }> = [];
    const unsubscribe = createGitInfoStore(cid(3), 'fast-refs').subscribe((value) => {
      values.push(cloneInfo(value));
    });

    await flushMicrotasks();
    expect(values.at(-1)).toMatchObject({
      isRepo: true,
      currentBranch: 'master',
      branches: ['master'],
      tags: [],
      tagsByCommit: {},
      branchNamesLoading: false,
      tagNamesLoading: true,
      loading: true,
    });

    finishTagNames();
    await flushMicrotasks();
    expect(values.at(-1)).toMatchObject({
      branches: ['master'],
      tags: ['v0.2.22'],
      branchNamesLoading: false,
      tagNamesLoading: false,
      loading: true,
    });

    finishTagResolution();
    await flushMicrotasks();
    expect(values.at(-1)).toMatchObject({
      branchNamesLoading: false,
      tagNamesLoading: false,
      loading: false,
      tagsByCommit: {
        a317269c6e4d63d6cf0f66a0a0268b65df6390a5: ['v0.2.22'],
      },
    });

    unsubscribe();
  });

  it('keeps retrying while repo refs are still hydrating', async () => {
    let attempts = 0;
    shared.isGitRepo.mockResolvedValue(true);
    shared.getRefs.mockImplementation(async (): Promise<MockGitRefsResult> => {
      attempts += 1;
      if (attempts < 3) {
        return {
          branches: [],
          currentBranch: null,
          tags: [],
          tagsByCommit: {},
        };
      }

      return {
        branches: ['master'],
        currentBranch: 'master',
        tags: ['v0.2.22'],
        tagsByCommit: {
          a317269c6e4d63d6cf0f66a0a0268b65df6390a5: ['v0.2.22'],
        },
      };
    });

    const { createGitInfoStore } = await import('../src/stores/git');
    const values: Array<ReturnType<typeof cloneInfo>> = [];
    const unsubscribe = createGitInfoStore(cid(1), 'hashtree').subscribe((value) => {
      values.push(cloneInfo(value));
    });

    await flushMicrotasks();
    expect(shared.getRefs).toHaveBeenCalledTimes(1);
    expect(values.at(-1)).toMatchObject({
      isRepo: true,
      currentBranch: null,
      branches: [],
      tags: [],
      loading: true,
    });

    await vi.advanceTimersByTimeAsync(1500);
    expect(shared.getRefs).toHaveBeenCalledTimes(2);
    expect(values.at(-1)).toMatchObject({
      isRepo: true,
      currentBranch: null,
      branches: [],
      tags: [],
      loading: true,
    });

    await vi.advanceTimersByTimeAsync(1500);
    expect(shared.getRefs).toHaveBeenCalledTimes(3);
    expect(values.at(-1)).toMatchObject({
      isRepo: true,
      currentBranch: 'master',
      branches: ['master'],
      tags: ['v0.2.22'],
      loading: false,
    });

    unsubscribe();
  });

  it('retries repo detection when a repo view loads before HEAD is readable', async () => {
    let detectionAttempts = 0;
    shared.isGitRepo.mockImplementation(async () => {
      detectionAttempts += 1;
      return detectionAttempts >= 3;
    });
    shared.getRefs.mockResolvedValue({
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v0.2.22'],
      tagsByCommit: {
        a317269c6e4d63d6cf0f66a0a0268b65df6390a5: ['v0.2.22'],
      },
    });

    const { createGitInfoStore } = await import('../src/stores/git');
    const values: Array<ReturnType<typeof cloneInfo>> = [];
    const unsubscribe = createGitInfoStore(cid(2), 'hashtree', { retryRepoDetection: true }).subscribe((value) => {
      values.push(cloneInfo(value));
    });

    await flushMicrotasks();
    expect(shared.isGitRepo).toHaveBeenCalledTimes(1);
    expect(shared.getRefs).toHaveBeenCalledTimes(0);
    expect(values.at(-1)).toMatchObject({
      isRepo: false,
      currentBranch: null,
      branches: [],
      tags: [],
      loading: true,
    });

    await vi.advanceTimersByTimeAsync(1500);
    expect(shared.isGitRepo).toHaveBeenCalledTimes(2);
    expect(shared.getRefs).toHaveBeenCalledTimes(0);
    expect(values.at(-1)).toMatchObject({
      isRepo: false,
      currentBranch: null,
      branches: [],
      tags: [],
      loading: true,
    });

    await vi.advanceTimersByTimeAsync(1500);
    expect(shared.isGitRepo).toHaveBeenCalledTimes(3);
    expect(shared.getRefs).toHaveBeenCalledTimes(1);
    expect(values.at(-1)).toMatchObject({
      isRepo: true,
      currentBranch: 'master',
      branches: ['master'],
      tags: ['v0.2.22'],
      loading: false,
    });

    unsubscribe();
  });
});
