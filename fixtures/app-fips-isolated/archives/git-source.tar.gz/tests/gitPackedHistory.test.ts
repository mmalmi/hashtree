import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { HashTree, LinkType, MemoryStore, toHex, type CID, type TreeEntry } from '@hashtree/core';

let tree: HashTree;
vi.mock('../src/store', () => ({ getTree: () => tree }));
import { getCommitCountFast, getCommitInfo } from '../src/utils/wasmGit/logHistory';

let repo: string;
let root: CID;
let head: string;
const packHashes = new Set<string>();
let fullPackReads = 0;
let rangeBytes = 0;

beforeAll(async () => {
  repo = mkdtempSync(join(tmpdir(), 'iris-git-history-'));
  const git = (...args: string[]) => execFileSync('git', ['-c', 'commit.gpgsign=false', ...args], { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  git('init', '-b', 'master');
  git('config', 'user.name', 'Test');
  git('config', 'user.email', 'test@example.com');
  for (let i = 0; i < 3; i++) {
    writeFileSync(join(repo, 'file.txt'), `revision ${i}\n` + 'content\n'.repeat(10000));
    git('add', '.');
    git('commit', '-m', `commit ${i}`);
  }
  head = git('rev-parse', 'HEAD');
  git('checkout', '-b', 'side', 'HEAD~1');
  writeFileSync(join(repo, 'side.txt'), 'side branch');
  git('add', '.');
  git('commit', '-m', 'unreachable from master');
  git('checkout', 'master');
  git('repack', '-ad');
  // Overlapping packs are valid and common after incremental hashtree pushes.
  const packDir = join(repo, '.git/objects/pack');
  for (const name of readdirSync(packDir)) {
    writeFileSync(join(packDir, `pack-duplicate.${name.split('.').at(-1)}`), readFileSync(join(packDir, name)));
  }
  tree = new HashTree({ store: new MemoryStore() });
  async function upload(path: string): Promise<CID> {
    const entries: TreeEntry[] = [];
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.name === 'hooks' || entry.name === 'logs') continue;
      if (entry.isDirectory()) {
        entries.push({ name: entry.name, cid: await upload(join(path, entry.name)), type: LinkType.Dir, size: 0 });
      } else {
        const file = await tree.putFile(new Uint8Array(readFileSync(join(path, entry.name))));
        entries.push({ name: entry.name, cid: file.cid, type: LinkType.File, size: file.size });
        if (entry.name.endsWith('.pack')) packHashes.add(toHex(file.cid.hash));
      }
    }
    return (await tree.putDirectory(entries)).cid;
  }
  const gitCid = await upload(join(repo, '.git'));
  root = (await tree.putDirectory([{ name: '.git', cid: gitCid, type: LinkType.Dir, size: 0 }])).cid;
  const read = tree.readFile.bind(tree);
  vi.spyOn(tree, 'readFile').mockImplementation(async cid => {
    if (packHashes.has(toHex(cid.hash))) fullPackReads++;
    return read(cid);
  });
  const range = tree.readFileRange.bind(tree);
  vi.spyOn(tree, 'readFileRange').mockImplementation(async (cid, start, end) => {
    const data = await range(cid, start, end);
    rangeBytes += data?.length ?? 0;
    return data;
  });
});
afterAll(() => rmSync(repo, { recursive: true, force: true }));

describe('packed repository history', () => {
  it('reads a packed commit without downloading the entire pack', async () => {
    vi.mocked(tree.readFileRange).mockRejectedValueOnce(new Error('Blob retrieval timed out'));
    expect(await getCommitInfo(root, head)).toBeNull();
    expect(await getCommitInfo(root, head)).toMatchObject({ oid: head, message: 'commit 2' });
    expect(fullPackReads).toBe(0);
    expect(rangeBytes).toBeGreaterThan(0);
  });
  it('counts reachable commits once across overlapping packs and other branches', async () => {
    expect(await getCommitCountFast(root)).toBe(3);
    expect(fullPackReads).toBe(0);
  });
});
