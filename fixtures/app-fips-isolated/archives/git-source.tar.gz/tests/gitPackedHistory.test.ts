import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { HashTree, LinkType, MemoryStore, toHex, type CID, type TreeEntry } from '@hashtree/core';

let tree: HashTree;
vi.mock('../src/store', () => ({ getTree: () => tree }));
import { getCommitCountFast, getCommitInfo } from '../src/utils/wasmGit/logHistory';
import { getFileLastCommits } from '../src/utils/wasmGit/logFileHistory';

let repo: string;
let root: CID;
let head: string;
const packHashes = new Set<string>();
let fullPackReads = 0;
let rangeBytes = 0;
let failNextPackRead = false;
// Small chunks so the pack spans several of them, as real packs do.
const CHUNK_SIZE = 256;
const packSizes = new Map<string, number>();
const packReads: Array<{ pack: string; start: number; bytes: number }> = [];

beforeAll(async () => {
  repo = mkdtempSync(join(tmpdir(), 'iris-git-history-'));
  const git = (...args: string[]) => execFileSync('git', ['-c', 'commit.gpgsign=false', ...args], { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  git('init', '-b', 'master');
  git('config', 'user.name', 'Test');
  git('config', 'user.email', 'test@example.com');
  for (let i = 0; i < 3; i++) {
    writeFileSync(join(repo, 'file.txt'), `revision ${i}\n` + 'content\n'.repeat(10000));
    git('add', '.');
    git('commit', '-m', `commit ${i}`);
  }
  head = git('rev-parse', 'HEAD');
  git('checkout', '-b', 'side', 'HEAD~1');
  writeFileSync(join(repo, 'side.txt'), 'side branch');
  git('add', '.');
  git('commit', '-m', 'unreachable from master');
  git('checkout', 'master');
  git('repack', '-ad');
  // Overlapping packs are valid and common after incremental hashtree pushes.
  const packDir = join(repo, '.git/objects/pack');
  for (const name of readdirSync(packDir)) {
    writeFileSync(join(packDir, `pack-duplicate.${name.split('.').at(-1)}`), readFileSync(join(packDir, name)));
  }
  tree = new HashTree({ store: new MemoryStore(), chunkSize: CHUNK_SIZE });
  async function upload(path: string): Promise<CID> {
    const entries: TreeEntry[] = [];
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.name === 'hooks' || entry.name === 'logs') continue;
      if (entry.isDirectory()) {
        entries.push({ name: entry.name, cid: await upload(join(path, entry.name)), type: LinkType.Dir, size: 0 });
      } else {
        const file = await tree.putFile(new Uint8Array(readFileSync(join(path, entry.name))));
        entries.push({ name: entry.name, cid: file.cid, type: LinkType.File, size: file.size });
        if (entry.name.endsWith('.pack')) {
          packHashes.add(toHex(file.cid.hash));
          packSizes.set(toHex(file.cid.hash), file.size);
        }
      }
    }
    return (await tree.putDirectory(entries)).cid;
  }
  const gitCid = await upload(join(repo, '.git'));
  root = (await tree.putDirectory([{ name: '.git', cid: gitCid, type: LinkType.Dir, size: 0 }])).cid;
  const read = tree.readFile.bind(tree);
  vi.spyOn(tree, 'readFile').mockImplementation(async cid => {
    if (packHashes.has(toHex(cid.hash))) fullPackReads++;
    return read(cid);
  });
  const range = tree.readFileRange.bind(tree);
  vi.spyOn(tree, 'readFileRange').mockImplementation(async (cid, start, end) => {
    const pack = toHex(cid.hash);
    if (packHashes.has(pack) && failNextPackRead) {
      failNextPackRead = false;
      throw new Error('Blob retrieval timed out');
    }
    const data = await range(cid, start, end);
    rangeBytes += data?.length ?? 0;
    if (packHashes.has(pack) && data) packReads.push({ pack, start, bytes: data.length });
    return data;
  });
});
afterAll(() => rmSync(repo, { recursive: true, force: true }));

describe('packed repository history', () => {
  it('reads a packed commit without downloading the entire pack', async () => {
    failNextPackRead = true;
    expect(await getCommitInfo(root, head)).toBeNull();
    expect(await getCommitInfo(root, head)).toMatchObject({ oid: head, message: 'commit 2' });
    expect(fullPackReads).toBe(0);
    expect(rangeBytes).toBeGreaterThan(0);
    const pack = packReads[0].pack;
    expect(packSizes.get(pack)).toBeGreaterThan(CHUNK_SIZE * 2);
    const bytesRead = packReads.filter(read => read.pack === pack).reduce((sum, read) => sum + read.bytes, 0);
    expect(bytesRead).toBeLessThan(packSizes.get(pack)!);
  });
  it('counts reachable commits once across overlapping packs and other branches', async () => {
    expect(await getCommitCountFast(root)).toBe(3);
    expect(fullPackReads).toBe(0);
  });
  it('walks file history reading each stored pack chunk at most once', async () => {
    const commits = await getFileLastCommits(root, ['file.txt', 'side.txt']);
    expect(commits.get('file.txt')).toMatchObject({ oid: head, message: 'commit 2' });
    expect(commits.has('side.txt')).toBe(false);
    // Commits, trees and their delta bases are served from cached chunks.
    const chunks = packReads.map(read => `${read.pack}:${read.start}`);
    expect(new Set(chunks).size).toBe(chunks.length);
    expect(Math.max(...packReads.map(read => read.bytes))).toBeLessThanOrEqual(CHUNK_SIZE);
    expect(fullPackReads).toBe(0);
  });
});
