import { describe, expect, it, vi } from 'vitest';
import { LinkType, type CID, type TreeEntry } from '@hashtree/core';
import { getRefs } from '../src/utils/wasmGit/branch';
import { parsePackedRefs, type GitTreeReader } from '../src/utils/wasmGit/refs';

function cid(label: string): CID {
  return { hash: new TextEncoder().encode(label), key: undefined } as CID;
}

type Node =
  | {
      type: 'dir';
      entries: Map<string, CID>;
    }
  | {
      type: 'file';
      content: Uint8Array;
    };

function createFakeTree(nodes: Map<CID, Node>): GitTreeReader {
  return {
    async resolvePath(startCid, path) {
      const parts = path.split('/').filter(Boolean);
      let currentCid = startCid;

      for (const part of parts) {
        const node = nodes.get(currentCid);
        if (!node || node.type !== 'dir') return null;
        const nextCid = node.entries.get(part);
        if (!nextCid) return null;
        currentCid = nextCid;
      }

      const node = nodes.get(currentCid);
      if (!node) return null;
      return {
        cid: currentCid,
        type: node.type === 'dir' ? LinkType.Dir : LinkType.Blob,
      };
    },

    async readFile(fileCid) {
      const node = nodes.get(fileCid);
      return node?.type === 'file' ? node.content : null;
    },

    async listDirectory(dirCid) {
      const node = nodes.get(dirCid);
      if (!node || node.type !== 'dir') return [];

      const entries: TreeEntry[] = [];
      for (const [name, childCid] of node.entries.entries()) {
        const child = nodes.get(childCid);
        if (!child) continue;
        entries.push({
          name,
          cid: childCid,
          size: child.type === 'file' ? child.content.length : 0,
          type: child.type === 'dir' ? LinkType.Dir : LinkType.Blob,
        });
      }
      return entries;
    },
  };
}

function file(content: string): Node {
  return {
    type: 'file',
    content: new TextEncoder().encode(content),
  };
}

function dir(entries: Array<[string, CID]>): Node {
  return {
    type: 'dir',
    entries: new Map(entries),
  };
}

describe('git refs reader', () => {
  it('parses packed refs and preserves peeled annotated-tag commits', () => {
    const refs = parsePackedRefs(`
# pack-refs with: peeled fully-peeled sorted
1111111111111111111111111111111111111111 refs/heads/main
2222222222222222222222222222222222222222 refs/tags/v1.0.0
^3333333333333333333333333333333333333333
4444444444444444444444444444444444444444 refs/tags/releases/v0.9.0
`.trim());

    expect(refs.get('refs/heads/main')).toEqual({
      sha: '1111111111111111111111111111111111111111',
    });
    expect(refs.get('refs/tags/v1.0.0')).toEqual({
      sha: '2222222222222222222222222222222222222222',
      peeled: '3333333333333333333333333333333333333333',
    });
    expect(refs.get('refs/tags/releases/v0.9.0')).toEqual({
      sha: '4444444444444444444444444444444444444444',
    });
  });

  it('merges loose and packed refs, keeps nested names, and groups tags by commit', async () => {
    const rootCid = cid('root');
    const gitCid = cid('git');
    const headCid = cid('head');
    const packedRefsCid = cid('packed-refs');
    const refsCid = cid('refs');
    const headsCid = cid('heads');
    const headsReleaseCid = cid('heads-release');
    const tagsCid = cid('tags');

    const mainHeadCid = cid('main-head');
    const releaseHeadCid = cid('release-head');
    const looseTagCid = cid('tag-v1');

    const nodes = new Map<CID, Node>([
      [rootCid, dir([['.git', gitCid]])],
      [gitCid, dir([
        ['HEAD', headCid],
        ['packed-refs', packedRefsCid],
        ['refs', refsCid],
      ])],
      [headCid, file('ref: refs/heads/release/v1\n')],
      [packedRefsCid, file(`
# pack-refs with: peeled fully-peeled sorted
cccccccccccccccccccccccccccccccccccccccc refs/heads/hotfix/packed
dddddddddddddddddddddddddddddddddddddddd refs/tags/v1.0.0
eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee refs/tags/releases/v0.9.0
^9999999999999999999999999999999999999999
`.trim())],
      [refsCid, dir([
        ['heads', headsCid],
        ['tags', tagsCid],
      ])],
      [headsCid, dir([
        ['main', mainHeadCid],
        ['release', headsReleaseCid],
      ])],
      [headsReleaseCid, dir([
        ['v1', releaseHeadCid],
      ])],
      [mainHeadCid, file('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')],
      [releaseHeadCid, file('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n')],
      [tagsCid, dir([
        ['v1.0.0', looseTagCid],
      ])],
      [looseTagCid, file('ffffffffffffffffffffffffffffffffffffffff\n')],
    ]);

    const resolveRevisionToCommit = vi.fn(async (_repoCid: CID, revision: string) => {
      if (revision === 'refs/tags/v1.0.0') {
        return 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';
      }
      if (revision === 'refs/tags/releases/v0.9.0') {
        return '9999999999999999999999999999999999999999';
      }
      return null;
    });

    const refs = await getRefs(rootCid, {
      tree: createFakeTree(nodes),
      resolveRevisionToCommit,
    });

    expect(refs.currentBranch).toBe('release/v1');
    expect(refs.branches).toEqual(['hotfix/packed', 'main', 'release/v1']);
    expect(refs.tags).toEqual(['releases/v0.9.0', 'v1.0.0']);
    expect(refs.tagsByCommit).toEqual({
      '9999999999999999999999999999999999999999': ['releases/v0.9.0'],
      'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb': ['v1.0.0'],
    });
    expect(resolveRevisionToCommit).toHaveBeenCalledTimes(1);
    expect(resolveRevisionToCommit).toHaveBeenCalledWith(rootCid, 'refs/tags/v1.0.0');
  });

  it('reports ref names before annotated tag resolution completes', async () => {
    const rootCid = cid('early-root');
    const gitCid = cid('early-git');
    const headCid = cid('early-head');
    const packedRefsCid = cid('early-packed-refs');
    const nodes = new Map<CID, Node>([
      [rootCid, dir([['.git', gitCid]])],
      [gitCid, dir([
        ['HEAD', headCid],
        ['packed-refs', packedRefsCid],
      ])],
      [headCid, file('ref: refs/heads/master\n')],
      [packedRefsCid, file(`
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa refs/heads/master
bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb refs/tags/v1.0.0
`.trim())],
    ]);

    let finishTagResolution!: (commit: string) => void;
    const tagResolution = new Promise<string>((resolve) => {
      finishTagResolution = resolve;
    });
    const onRefNames = vi.fn();

    const refsPromise = getRefs(rootCid, {
      tree: createFakeTree(nodes),
      onRefNames,
      resolveRevisionToCommit: async () => tagResolution,
    });

    await vi.waitFor(() => expect(onRefNames).toHaveBeenCalledWith({
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v1.0.0'],
    }));

    finishTagResolution('cccccccccccccccccccccccccccccccccccccccc');
    await expect(refsPromise).resolves.toMatchObject({
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v1.0.0'],
      tagsByCommit: {
        cccccccccccccccccccccccccccccccccccccccc: ['v1.0.0'],
      },
    });
  });

  it('reports loose ref names without reading each ref file first', async () => {
    const rootCid = cid('loose-root');
    const gitCid = cid('loose-git');
    const headCid = cid('loose-head');
    const refsCid = cid('loose-refs');
    const headsCid = cid('loose-heads');
    const tagsCid = cid('loose-tags');
    const branchCid = cid('loose-branch');
    const tagCid = cid('loose-tag');
    const nodes = new Map<CID, Node>([
      [rootCid, dir([['.git', gitCid]])],
      [gitCid, dir([
        ['HEAD', headCid],
        ['refs', refsCid],
      ])],
      [headCid, file('ref: refs/heads/master\n')],
      [refsCid, dir([
        ['heads', headsCid],
        ['tags', tagsCid],
      ])],
      [headsCid, dir([['master', branchCid]])],
      [tagsCid, dir([['v1.0.0', tagCid]])],
      [branchCid, file('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')],
      [tagCid, file('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n')],
    ]);
    const baseTree = createFakeTree(nodes);
    const readFile = vi.fn(baseTree.readFile.bind(baseTree));
    const onRefNames = vi.fn();
    let finishTagResolution!: (commit: string) => void;
    const tagResolution = new Promise<string>((resolve) => {
      finishTagResolution = resolve;
    });

    const refsPromise = getRefs(rootCid, {
      tree: { ...baseTree, readFile },
      onRefNames,
      resolveRevisionToCommit: async () => tagResolution,
    });

    await vi.waitFor(() => expect(onRefNames).toHaveBeenCalledWith({
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v1.0.0'],
    }));
    expect(readFile).toHaveBeenCalledWith(headCid);
    expect(readFile).not.toHaveBeenCalledWith(branchCid);
    expect(readFile).not.toHaveBeenCalledWith(tagCid);

    finishTagResolution('cccccccccccccccccccccccccccccccccccccccc');
    await refsPromise;
  });

  it('reports branches before the tag directory finishes loading', async () => {
    const rootCid = cid('split-root');
    const gitCid = cid('split-git');
    const headCid = cid('split-head');
    const refsCid = cid('split-refs');
    const headsCid = cid('split-heads');
    const tagsCid = cid('split-tags');
    const branchCid = cid('split-branch');
    const nodes = new Map<CID, Node>([
      [rootCid, dir([['.git', gitCid]])],
      [gitCid, dir([
        ['HEAD', headCid],
        ['refs', refsCid],
      ])],
      [headCid, file('ref: refs/heads/master\n')],
      [refsCid, dir([
        ['heads', headsCid],
        ['tags', tagsCid],
      ])],
      [headsCid, dir([['master', branchCid]])],
      [tagsCid, dir([])],
      [branchCid, file('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')],
    ]);
    const baseTree = createFakeTree(nodes);
    let finishTags!: () => void;
    const tagsPending = new Promise<void>((resolve) => {
      finishTags = resolve;
    });
    const onBranches = vi.fn();

    const refsPromise = getRefs(rootCid, {
      tree: {
        ...baseTree,
        async resolvePath(startCid, path) {
          if (startCid === gitCid && path === 'refs/tags') {
            await tagsPending;
          }
          return baseTree.resolvePath(startCid, path);
        },
      },
      onBranches,
      resolveRevisionToCommit: async () => null,
    } as Parameters<typeof getRefs>[1] & {
      onBranches: (refs: { branches: string[]; currentBranch: string | null }) => void;
    });

    await vi.waitFor(() => expect(onBranches).toHaveBeenCalledWith({
      branches: ['master'],
      currentBranch: 'master',
    }));

    finishTags();
    await refsPromise;
  });

  it('reports the symbolic HEAD before branch directories finish loading', async () => {
    const rootCid = cid('head-first-root');
    const gitCid = cid('head-first-git');
    const headCid = cid('head-first-head');
    const refsCid = cid('head-first-refs');
    const headsCid = cid('head-first-heads');
    const branchCid = cid('head-first-branch');
    const nodes = new Map<CID, Node>([
      [rootCid, dir([['.git', gitCid]])],
      [gitCid, dir([
        ['HEAD', headCid],
        ['refs', refsCid],
      ])],
      [headCid, file('ref: refs/heads/master\n')],
      [refsCid, dir([['heads', headsCid]])],
      [headsCid, dir([['master', branchCid]])],
      [branchCid, file('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')],
    ]);
    const baseTree = createFakeTree(nodes);
    let finishBranchDirectories!: () => void;
    const branchDirectoriesPending = new Promise<void>((resolve) => {
      finishBranchDirectories = resolve;
    });
    const onCurrentBranch = vi.fn();

    const refsPromise = getRefs(rootCid, {
      tree: {
        ...baseTree,
        async resolvePath(startCid, path) {
          if (
            startCid === gitCid
            && (path === 'refs/heads' || path === 'packed-refs')
          ) {
            await branchDirectoriesPending;
          }
          return baseTree.resolvePath(startCid, path);
        },
      },
      onCurrentBranch,
      resolveRevisionToCommit: async () => null,
    });

    await vi.waitFor(() => expect(onCurrentBranch).toHaveBeenCalledWith('master'));

    finishBranchDirectories();
    await refsPromise;
  });
});
