import { describe, expect, it } from 'vitest';

import {
  DEFAULT_E2E_PRODUCTION_RELAYS,
  DEFAULT_PUBLIC_RELAYS,
} from '../src/lib/defaultRelays';

describe('production relay defaults', () => {
  it('include the nos.lol discovery fallback used by public repository roots', () => {
    expect(DEFAULT_PUBLIC_RELAYS).toContain('wss://nos.lol');
    expect(DEFAULT_PUBLIC_RELAYS.slice(0, 3)).toEqual([
      'wss://relay.ditto.pub', 'wss://relay.damus.io', 'wss://relay.primal.net',
    ]);
    expect(DEFAULT_E2E_PRODUCTION_RELAYS).toEqual(DEFAULT_PUBLIC_RELAYS);
    expect(new Set(DEFAULT_PUBLIC_RELAYS).size).toBe(DEFAULT_PUBLIC_RELAYS.length);
  });
});
