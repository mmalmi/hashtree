import { describe, expect, it } from 'vitest';
import { buildRepoCodeHref, buildRepoTabHref } from '../src/lib/gitRefNavigation';

describe('git ref navigation', () => {
  it('builds branch and tag tab links at the repo root', () => {
    expect(buildRepoTabHref('npub1owner', 'projects/hashtree', 'branches'))
      .toBe('#/npub1owner/projects/hashtree?tab=branches');

    expect(buildRepoTabHref('npub1owner', 'projects/hashtree', 'tags', 'abc123'))
      .toBe('#/npub1owner/projects/hashtree?tab=tags&k=abc123');
  });

  it('builds code links that preserve link keys and refs', () => {
    expect(buildRepoCodeHref('npub1owner', 'projects/hashtree'))
      .toBe('#/npub1owner/projects/hashtree');

    expect(buildRepoCodeHref('npub1owner', 'projects/hashtree', { ref: 'master', linkKey: 'abc123' }))
      .toBe('#/npub1owner/projects/hashtree?ref=master&k=abc123');
  });

  it('encodes nested path segments and ref names safely', () => {
    expect(buildRepoCodeHref('npub1owner', 'repos/my repo', { ref: 'release/v1.0.0' }))
      .toBe('#/npub1owner/repos/my%20repo?ref=release%2Fv1.0.0');
  });
});
