import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  parsePublishOutput,
  runAllReleases,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

describe('release-site', () => {
  it('uses the built-in Worker default for git', () => {
    const parsed = parseArgs(['git']);
    expect(parsed.workerName).toBe('iris-git');
    expect(parsed.treeName).toBe('git');
    expect(parsed.routes).toEqual(['git.iris.to/*']);
    expect(parsed.domains).toEqual([]);
  });

  it('uses the profile-specific Worker env var without production routes or domains', () => {
    const parsed = parseArgs(['git'], { CF_WORKER_NAME_GIT: 'iris-git-preview' });
    expect(parsed.workerName).toBe('iris-git-preview');
    expect(parsed.treeName).toBe('git');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports explicitly switching git back to Pages', () => {
    const parsed = parseArgs(['git', '--pages-only'], { CF_PAGES_PROJECT_GIT: 'git-iris-to' });
    expect(parsed.workerName).toBeUndefined();
    expect(parsed.pagesProject).toBe('git-iris-to');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports the all profile without per-site overrides', () => {
    const parsed = parseArgs(['all', '--branch', 'main', '--skip-cloudflare']);
    expect(parsed.profileName).toBe('all');
    expect(parsed.branch).toBe('main');
    expect(parsed.skipCloudflare).toBe(true);
  });

  it('rejects single-target Worker overrides for the all profile', () => {
    expect(() => parseArgs(['all', '--worker-name', 'iris-git'])).toThrow(
      '--worker-name is not supported with the all profile',
    );
  });

  it('supports the git release profile', () => {
    const git = createReleasePlan({
      profileName: 'git',
      pagesProject: 'git-iris-to',
      treeName: 'git',
      skipCloudflare: false,
    });
    expect(git.profile.distDir).toBe('iris-git');
  });

  it('adds the built-in production route for the git Worker release', () => {
    const plan = createReleasePlan({
      profileName: 'git',
      workerName: 'iris-git',
      routes: ['git.iris.to/*'],
      domains: [],
      treeName: 'git',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'iris-git',
      '--name',
      'iris-git',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--route',
      'git.iris.to/*',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'iris-git',
      '--name',
      'iris-git',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-git',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'iris-git',
        binding: 'ASSETS',
        run_worker_first: true,
        html_handling: 'none',
      },
    });
  });

  it('builds a Worker release plan in build-test-publish-deploy order', () => {
    const plan = createReleasePlan({
      profileName: 'git',
      workerName: 'iris-git',
      routes: ['git.iris.to/*'],
      domains: [],
      treeName: 'git',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.map((step) => step.id)).toEqual([
      'install',
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'publish',
      'deploy',
    ]);
  });

  it('starts every release from a frozen install before the verified build', () => {
    const plan = createReleasePlan({
      profileName: 'git',
      workerName: 'iris-git',
      routes: ['git.iris.to/*'],
      domains: [],
      treeName: 'git',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.slice(0, 2).map(({ id, command }) => ({ id, command }))).toEqual([
      {
        id: 'install',
        command: ['pnpm', 'install', '--frozen-lockfile'],
      },
      {
        id: 'build',
        command: ['pnpm', 'run', 'build:git'],
      },
    ]);
  });

  it('builds a Pages release plan when only a Pages project is configured', () => {
    const plan = createReleasePlan({
      profileName: 'git',
      pagesProject: 'git-iris-to',
      treeName: 'git',
      branch: 'main',
      skipCloudflare: false,
    });

    expect(plan.steps.at(-1)?.command).toEqual([
      'npx',
      `wrangler@${wranglerVersion}`,
      'pages',
      'deploy',
      'iris-git',
      '--project-name',
      'git-iris-to',
      '--branch',
      'main',
    ]);
  });

  it('stops before publish when a test step fails', async () => {
    const calls = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-2') {
        return { status: 1, stdout: '', stderr: 'smoke failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(
      runRelease(
        {
          profileName: 'git',
          workerName: 'iris-git',
          treeName: 'git',
          skipCloudflare: false,
          workerCompatibilityDate: '2026-03-19',
        },
        runner,
        { buildOutputExists: () => true },
      ),
    ).rejects.toThrow('Test Iris Git (2/4) failed with exit code 1');
    expect(calls).toEqual(['install', 'build', 'test-1', 'test-2']);
  });

  it('runs hashtree publish and Cloudflare deploy in parallel after tests', async () => {
    let activeReleaseSteps = 0;
    let maxActiveReleaseSteps = 0;
    const calls = [];
    const runner = vi.fn(async (step) => {
      calls.push(step.id);
      if (step.id === 'publish' || step.id === 'deploy') {
        activeReleaseSteps += 1;
        maxActiveReleaseSteps = Math.max(maxActiveReleaseSteps, activeReleaseSteps);
        await new Promise((resolve) => setTimeout(resolve, 10));
        activeReleaseSteps -= 1;
        if (step.id === 'publish') {
          return {
            status: 0,
            stdout: 'published: npub1example/git\nnhash1ace',
            stderr: '',
          };
        }
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await runRelease(
      {
        profileName: 'git',
        workerName: 'iris-git',
        treeName: 'git',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(calls).toEqual(['install', 'build', 'test-1', 'test-2', 'test-3', 'test-4', 'publish', 'deploy']);
    expect(maxActiveReleaseSteps).toBe(2);
  });

  it('returns parsed hashtree and Worker target on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/git\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'git',
        workerName: 'iris-git',
        treeName: 'git',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/git',
    });
    expect(result.workerName).toBe('iris-git');
    expect(result.pagesProject).toBeNull();
    expect(result.pagesUrl).toBeNull();
  });

  it('returns parsed hashtree and Pages URLs on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/git\nnhash1ace',
          stderr: '',
        };
      }
      if (step.id === 'deploy') {
        return {
          status: 0,
          stdout: 'Deploying... https://git-iris-to.pages.dev',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'git',
        pagesProject: 'git-iris-to',
        treeName: 'git',
        skipCloudflare: false,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/git',
    });
    expect(result.pagesUrl).toBe('https://git-iris-to.pages.dev');
  });

  it('runs all profiles sequentially', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/git\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runAllReleases(
      {
        profileName: 'all',
        skipCloudflare: true,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles.map((profile) => profile.profile.name)).toEqual(['git']);
  });

  it('parses htree publish output defensively', () => {
    expect(parsePublishOutput('published: npub1foo/git\nnhash1ace')).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/git',
    });
    expect(
      parsePublishOutput(
        [
          '2026-03-19T21:46:47Z ERROR nostr_relay_pool::pool::internal: transient publish warning',
          'published: npub1foo/git',
          'nhash1ace',
        ].join('\n'),
      ),
    ).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/git',
    });
    expect(() => parsePublishOutput('published: npub1foo/git')).toThrow(
      'Publish succeeded but no nhash was found in htree output',
    );
  });
});
