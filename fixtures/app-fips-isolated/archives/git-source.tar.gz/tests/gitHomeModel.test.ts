import { describe, expect, it } from 'vitest';
import type { TreeEntry } from '../src/stores';
import { buildGitHomeDiscoveredRepoCards, buildGitHomeFavoriteRepoCards, buildGitHomeRepos } from '../src/components/Git/homeModel';
import type { FavoriteRepoRef } from '../src/lib/gitFavorites';
import type { FollowedRepoAnnouncement } from '../src/stores/gitRepoDiscovery';

function tree(overrides: Partial<TreeEntry> & { name: string; labels?: string[] }): TreeEntry {
  return {
    key: `npub1test/${overrides.name}`,
    name: overrides.name,
    hash: new Uint8Array(32),
    hashHex: '00'.repeat(32),
    visibility: 'public',
    ...overrides,
  };
}

describe('buildGitHomeRepos', () => {
  it('keeps only trees tagged as git repos and sorts newest first', () => {
    const repos = buildGitHomeRepos([
      tree({ name: 'notes', createdAt: 30, labels: ['docs'] }),
      tree({ name: 'old-repo', createdAt: 10, labels: ['git'] }),
      tree({ name: 'new-repo', createdAt: 20, labels: ['hashtree', 'git'] }),
      tree({ name: 'misc', createdAt: 40 }),
    ]);

    expect(repos.map(repo => repo.name)).toEqual(['new-repo', 'old-repo']);
  });

  it('falls back to alphabetical order when timestamps are missing', () => {
    const repos = buildGitHomeRepos([
      tree({ name: 'zeta', labels: ['git'] }),
      tree({ name: 'alpha', labels: ['git'] }),
    ]);

    expect(repos.map(repo => repo.name)).toEqual(['alpha', 'zeta']);
  });
});

describe('buildGitHomeFavoriteRepoCards', () => {
  it('maps liked repositories to heart cards', () => {
    const cards = buildGitHomeFavoriteRepoCards([
      {
        address: '30617:abc:repo',
        href: '#/npub1owner/repo',
        ownerNpub: 'npub1owner',
        ownerPubkey: 'abc',
        repoName: 'repo',
      } satisfies FavoriteRepoRef,
    ]);

    expect(cards).toEqual([
      {
        key: '30617:abc:repo',
        href: '#/npub1owner/repo',
        name: 'repo',
        ownerPubkey: 'abc',
        metaLabel: 'Liked repository',
        accentIcon: 'heart',
      },
    ]);
  });

  it('does not create a fallback suggestion when there are no liked repos', () => {
    expect(buildGitHomeFavoriteRepoCards([])).toEqual([]);
  });
});

describe('buildGitHomeDiscoveredRepoCards', () => {
  it('maps followed repo announcements to bookmark cards with update time', () => {
    const cards = buildGitHomeDiscoveredRepoCards([
      {
        address: '30617:abc:repo',
        href: '#/npub1owner/repo',
        ownerNpub: 'npub1owner',
        ownerPubkey: 'abc',
        repoName: 'repo',
        external: false,
        updatedAt: 123,
      } satisfies FollowedRepoAnnouncement,
    ]);

    expect(cards).toEqual([
      {
        key: '30617:abc:repo',
        href: '#/npub1owner/repo',
        name: 'repo',
        ownerPubkey: 'abc',
        metaLabel: 'Updated repository',
        accentIcon: 'bookmark',
        updatedAt: 123,
        external: false,
      },
    ]);
  });

  it('keeps external repo cards marked for browser links', () => {
    const cards = buildGitHomeDiscoveredRepoCards([
      {
        address: '30617:abc:external',
        href: 'https://github.com/iris/example',
        ownerNpub: 'npub1owner',
        ownerPubkey: 'abc',
        repoName: 'external',
        external: true,
        updatedAt: 456,
      } satisfies FollowedRepoAnnouncement,
    ]);

    expect(cards[0]).toMatchObject({
      href: 'https://github.com/iris/example',
      external: true,
    });
  });
});
