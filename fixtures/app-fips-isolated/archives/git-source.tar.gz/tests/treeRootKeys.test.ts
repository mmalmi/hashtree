import { describe, expect, it, vi } from 'vitest';
import { encryptObject, decryptObject, toHex, visibilityHex, type EncryptionMode } from '@hashtree/core';
import { decryptEncryptionKey, recoverMissingLinkKeyForOwner } from '../src/stores/treeRootKeys';
import { restoreTreeLinkKey } from '../src/utils/route';
import { isLinkKeyHex } from '../src/lib/treeKeys';
import { nip19 } from 'nostr-tools';

const owner = 'ab'.repeat(32);
const decrypt = vi.hoisted(() => vi.fn());
const publish = vi.hoisted(() => vi.fn().mockResolvedValue({ success: true }));
vi.mock('../src/nostr', () => ({ decrypt }));
vi.mock('../src/refResolver', () => ({ getRefResolver: () => ({ publish, list: (_npub: string, callback: (entries: never[]) => void) => { callback([]); } }) }));
vi.mock('../src/stores/treeRootShared', () => ({ getNostrState: () => ({ pubkey: owner }) }));

describe('tree root key recovery', () => {
  const plaintext = new TextEncoder().encode('ref: refs/heads/main\n');

  it.each<EncryptionMode>(['legacy-chk', 'chk-v1', 'rnd-v1'])('reads %s with a shared URL and owner recovery', async mode => {
    const { key, ciphertext } = await encryptObject(plaintext, mode);
    const link = 'ff'.repeat(key.length);
    const encryptedKey = visibilityHex.encryptKeyForLink(toHex(key), link);
    const info = { visibility: 'link-visible' as const, encryptedKey, selfEncryptedLinkKey: 'owner-wrap' };
    decrypt.mockResolvedValue(link);
    for (const linkInUrl of [link, null]) {
      const recovered = await decryptEncryptionKey(info, undefined, linkInUrl);
      expect(recovered).toEqual(key);
      expect(await decryptObject(ciphertext, recovered!)).toEqual(plaintext);
    }
    decrypt.mockResolvedValue(toHex(key));
    expect(await decryptEncryptionKey({ visibility: 'private', selfEncryptedKey: 'wrap' }, undefined, null)).toEqual(key);
    expect(await decryptEncryptionKey(undefined, undefined, toHex(key))).toEqual(key);
  });

  it('retains an existing 32-byte sharing link when migrating a versioned CHK root', async () => {
    const { key } = await encryptObject(plaintext);
    const link = 'ef'.repeat(32);
    const hash = new Uint8Array(32);
    const resolverKey = nip19.npubEncode(owner) + '/sample';
    const encryptedKey = visibilityHex.encryptKeyForLink(toHex(key), link);
    decrypt.mockResolvedValue(toHex(key));
    const replaceState = vi.fn();
    vi.stubGlobal('window', { location: { hash: '#/' + resolverKey }, history: { replaceState } });
    try {
      await recoverMissingLinkKeyForOwner({
        resolverKey, hash, visibilityInfo: { visibility: 'link-visible', encryptedKey, selfEncryptedKey: 'wrap' },
      });
      expect(replaceState).toHaveBeenCalledWith(null, '', '#/' + resolverKey + '?k=' + link);
      expect(publish).toHaveBeenCalledWith(resolverKey, { hash, key }, expect.objectContaining({ linkKey: new Uint8Array(32).fill(0xef) }));
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('does not put a recovered secret on a different tree after navigation', () => {
    const resolverKey = nip19.npubEncode(owner) + '/first';
    const replaceState = vi.fn();
    vi.stubGlobal('window', { location: { hash: '#/' + nip19.npubEncode(owner) + '/second' }, history: { replaceState } });
    try {
      expect(restoreTreeLinkKey(resolverKey, 'ff'.repeat(33))).toBe(false);
      expect(replaceState).not.toHaveBeenCalled();
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('accepts opaque link secrets but rejects unsupported object keys and malformed hex', async () => {
    const opaque = 'fe'.repeat(33);
    expect(isLinkKeyHex(opaque)).toBe(true);
    expect(await decryptEncryptionKey(undefined, undefined, opaque)).toBeUndefined();
    for (const invalid of ['0'.repeat(65), 'zz'.repeat(32), '12'.repeat(34)]) {
      expect(isLinkKeyHex(invalid)).toBe(false);
      expect(await decryptEncryptionKey(undefined, undefined, invalid)).toBeUndefined();
    }
  });
});
