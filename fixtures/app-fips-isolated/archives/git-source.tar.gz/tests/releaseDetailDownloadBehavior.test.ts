import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const releaseDetailViewSource = fs.readFileSync(
  path.resolve(process.cwd(), 'src', 'components', 'Git', 'ReleaseDetailView.svelte'),
  'utf8',
);

describe('release detail download behavior', () => {
  it('uses plain attachment links instead of page-managed asset streaming', () => {
    expect(releaseDetailViewSource).toContain('getReleaseAssetDownloadUrl');
    expect(releaseDetailViewSource).toContain('href={getAssetDownloadHref(asset)}');
    expect(releaseDetailViewSource).toContain('download');
    expect(releaseDetailViewSource).not.toContain('showSaveFilePicker');
    expect(releaseDetailViewSource).not.toContain('fetch(downloadHref)');
    expect(releaseDetailViewSource).not.toContain('response.blob()');
  });
});
