// @vitest-environment happy-dom
import { describe, expect, it, vi } from 'vitest';

vi.mock('../src/lib/mediaUrl', () => ({
  getNpubFileUrl: (npub: string, tree: string, path: string) =>
    `/htree/${npub}/${encodeURIComponent(tree)}/${path}?htree_c=test`,
}));
vi.mock('../src/utils/imgproxy', () => ({ generateProxyUrlAsync: vi.fn() }));

import { renderMarkdownHtml } from '../src/lib/markdown';

const routeContext = { npub: 'npub1owner', treeName: 'nostr-vpn', basePath: [] };

function fragment(html: string) {
  const template = document.createElement('template');
  template.innerHTML = html;
  return template.content;
}

describe('repository README images', () => {
  it('resolves HTML and Markdown images against the repository', async () => {
    const result = fragment(await renderMarkdownHtml(
      '<p align="center"><img src="icon.svg" alt="logo" width="112"></p>\n\n![screenshot](docs/screen.png)',
      { routeContext },
    ));
    expect(Array.from(result.querySelectorAll('img'), img => img.getAttribute('src'))).toEqual([
      '/htree/npub1owner/nostr-vpn/icon.svg?htree_c=test',
      '/htree/npub1owner/nostr-vpn/docs/screen.png?htree_c=test',
    ]);
    expect(result.querySelector('img')?.getAttribute('width')).toBe('112');
  });

  it('resolves nested HTML images and preserves suffixes', async () => {
    const result = fragment(await renderMarkdownHtml(
      '<p><img src="../assets/logo%20mark.svg?raw=1#logo"></p>',
      { routeContext: { ...routeContext, basePath: ['docs'] } },
    ));
    expect(result.querySelector('img')?.getAttribute('src')).toBe(
      '/htree/npub1owner/nostr-vpn/assets/logo mark.svg?htree_c=test&raw=1#logo',
    );
  });

  it('keeps the remote image policy for embedded HTML', async () => {
    const result = fragment(await renderMarkdownHtml('<p><img src="https://example.com/logo.png" alt="remote"></p>', { routeContext }));
    expect(result.querySelector('img')).toBeNull();
    expect(result.textContent).toContain('remote image blocked');
  });
});
