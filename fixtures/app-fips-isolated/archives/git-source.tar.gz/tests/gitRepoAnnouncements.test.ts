import { describe, expect, it } from 'vitest';
import {
  getGitRepoAnnouncementOpenLink,
  parseForkOriginLink,
  parseGitRepoAnnouncement,
  toBrowserGitRepoUrl,
} from '../src/lib/gitRepoAnnouncements';

describe('git repo announcement helpers', () => {
  it('parses personal fork announcements and earliest unique commit tags', () => {
    const parsed = parseGitRepoAnnouncement({
      id: 'f'.repeat(64),
      pubkey: 'a'.repeat(64),
      created_at: 42,
      content: '',
      tags: [
        ['d', 'alpha'],
        ['description', 'Forked repo'],
        ['clone', 'htree://npub1owner/alpha'],
        ['r', '0123456789abcdef', 'euc'],
        ['t', 'personal-fork'],
      ],
    });

    expect(parsed?.repoName).toBe('alpha');
    expect(parsed?.description).toBe('Forked repo');
    expect(parsed?.earliestUniqueCommit).toBe('0123456789abcdef');
    expect(parsed?.isPersonalFork).toBe(true);
    expect(parsed?.address).toBe(`30617:${'a'.repeat(64)}:alpha`);
  });

  it('collects multiple clone URLs from one clone tag', () => {
    const parsed = parseGitRepoAnnouncement({
      id: 'f'.repeat(64),
      pubkey: 'a'.repeat(64),
      created_at: 42,
      content: '',
      tags: [
        ['d', 'soapbox-weekly-pulse'],
        [
          'clone',
          'https://git.shakespeare.diy/npub1owner/soapbox-weekly-pulse.git',
          'https://relay.ngit.dev/npub1owner/soapbox-weekly-pulse.git',
        ],
      ],
    });

    expect(parsed?.cloneUrls).toEqual([
      'https://git.shakespeare.diy/npub1owner/soapbox-weekly-pulse.git',
      'https://relay.ngit.dev/npub1owner/soapbox-weekly-pulse.git',
    ]);
  });

  it('parses htree fork origin links into local repo hrefs', () => {
    const parsed = parseForkOriginLink('htree://npub1example/repositories/demo');

    expect(parsed).toEqual({
      href: '#/npub1example/repositories/demo',
      label: 'npub1example/repositories/demo',
      npub: 'npub1example',
      repoName: 'repositories/demo',
    });
  });

  it('opens htree clone URLs internally and external repo URLs in the browser', () => {
    expect(getGitRepoAnnouncementOpenLink({
      cloneUrls: ['htree://npub1example/repositories/demo'],
      webUrls: [],
    })).toEqual({
      href: '#/npub1example/repositories/demo',
      external: false,
    });

    expect(getGitRepoAnnouncementOpenLink({
      cloneUrls: ['https://github.com/iris/example.git'],
      webUrls: ['https://github.com/iris/example'],
    })).toEqual({
      href: 'https://github.com/iris/example',
      external: true,
    });

    expect(getGitRepoAnnouncementOpenLink({
      cloneUrls: ['https://git.shakespeare.diy/npub1owner/soapbox-weekly-pulse.git'],
      webUrls: ['https://git.shakespeare.diy/projects/soapbox-weekly-pulse'],
    })).toEqual({
      href: 'https://git.shakespeare.diy/projects/soapbox-weekly-pulse',
      external: true,
    });
  });

  it('converts common clone URL formats to browser URLs', () => {
    expect(toBrowserGitRepoUrl('https://github.com/iris/example.git')).toBe('https://github.com/iris/example');
    expect(toBrowserGitRepoUrl('git@github.com:iris/example.git')).toBe('https://github.com/iris/example');
    expect(toBrowserGitRepoUrl('ssh://git@github.com/iris/example.git')).toBe('https://github.com/iris/example');
  });

  it('keeps unknown https clone URLs exactly as published', () => {
    expect(toBrowserGitRepoUrl('https://git.shakespeare.diy/npub1owner/soapbox-weekly-pulse.git')).toBe(
      'https://git.shakespeare.diy/npub1owner/soapbox-weekly-pulse.git',
    );
    expect(toBrowserGitRepoUrl('git@git.shakespeare.diy:npub1owner/soapbox-weekly-pulse.git')).toBeNull();
  });
});
