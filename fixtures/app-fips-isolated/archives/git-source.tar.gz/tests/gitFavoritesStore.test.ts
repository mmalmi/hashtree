import { beforeEach, describe, expect, it, vi } from 'vitest';

const shared = vi.hoisted(() => {
  const stop = vi.fn();
  const on = vi.fn();
  const subscribe = vi.fn(() => ({ on, stop }));

  return {
    stop,
    on,
    subscribe,
    reset() {
      stop.mockReset();
      on.mockReset();
      subscribe.mockClear();
    },
  };
});

vi.mock('../src/nostr', () => ({
  nostr: { subscribe: shared.subscribe, signer: null },
  nostrStore: { getState: () => ({ pubkey: '' }) },
  npubToPubkey: () => '',
}));

vi.mock('../src/nip34', () => ({
  buildRepoAddress: (_ownerNpub: string, repoName: string) => `30617:${'a'.repeat(64)}:${repoName}`,
}));

describe('git favorite store subscription lifecycle', () => {
  beforeEach(() => {
    vi.resetModules();
    shared.reset();
  });

  it('shares and replaces the author reaction subscription after the last consumer leaves', async () => {
    const { createFavoriteReposStore } = await import('../src/stores/gitFavorites');
    const pubkey = 'b'.repeat(64);
    const first = createFavoriteReposStore(pubkey);
    const second = createFavoriteReposStore(pubkey);

    expect(shared.subscribe).toHaveBeenCalledTimes(1);
    first.destroy();
    expect(shared.stop).not.toHaveBeenCalled();

    second.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(1);

    const replacement = createFavoriteReposStore(pubkey);
    expect(shared.subscribe).toHaveBeenCalledTimes(2);
    replacement.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(2);
  });

  it('shares and replaces the repository count subscription after the last consumer leaves', async () => {
    const { createFavoriteRepoStatsStore } = await import('../src/stores/gitFavorites');
    const first = createFavoriteRepoStatsStore('npub1owner', 'alpha');
    const second = createFavoriteRepoStatsStore('npub1owner', 'alpha');

    expect(shared.subscribe).toHaveBeenCalledTimes(1);
    first.destroy();
    expect(shared.stop).not.toHaveBeenCalled();

    second.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(1);

    const replacement = createFavoriteRepoStatsStore('npub1owner', 'alpha');
    expect(shared.subscribe).toHaveBeenCalledTimes(2);
    replacement.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(2);
  });
});
