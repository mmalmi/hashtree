import { describe, expect, test } from 'vitest';
import { identityFromSecretKey, toHex } from '@fips/core';
import { nip19 } from 'nostr-tools';
import {
  IRIS_GIT_FIPS_DISCOVERY_SCOPE,
  GitFipsRuntime,
  compressedPubkeyHexToNpub,
  compressedPubkeyHexToXOnly,
  irisGitFipsDiscoveryScope,
} from '../src/lib/gitFipsRuntime';

describe('git FIPS runtime helpers', () => {
  test('uses the shared FIPS overlay topic', () => {
    expect(IRIS_GIT_FIPS_DISCOVERY_SCOPE).toBe('fips-overlay-v1');
    expect(irisGitFipsDiscoveryScope('A'.repeat(64))).toBe('fips-overlay-v1');
    expect(irisGitFipsDiscoveryScope()).toBe('fips-overlay-v1');
  });

  test('maps compressed FIPS peer ids to native npubs', async () => {
    const secret = new Uint8Array(32);
    secret[31] = 1;
    const identity = await identityFromSecretKey(secret);
    const compressed = toHex(identity.publicKey);
    const xOnly = toHex(identity.xOnlyPubkey);

    expect(compressedPubkeyHexToXOnly(compressed)).toBe(xOnly);
    expect(compressedPubkeyHexToNpub(compressed)).toBe(nip19.npubEncode(xOnly));
    expect(() => compressedPubkeyHexToXOnly(xOnly)).toThrow(/invalid compressed FIPS peer id/);
  });

  test('keeps remote blob routes explicit and defaults them to HTL 10', async () => {
    const secret = new Uint8Array(32);
    secret[31] = 2;
    const identity = await identityFromSecretKey(secret);
    const peerId = toHex(identity.publicKey);
    const runtime = new GitFipsRuntime({ identity, relays: ['wss://relay.example'], blobRoutes: [{ peerId }] });

    expect(runtime.getStats().blobRoutes).toEqual([{ peerId, htl: 10 }]);
    runtime.setBlobRoutes([{ peerId, htl: 0 }]);
    expect(runtime.getStats().blobRoutes).toEqual([{ peerId, htl: 0 }]);
  });
});
