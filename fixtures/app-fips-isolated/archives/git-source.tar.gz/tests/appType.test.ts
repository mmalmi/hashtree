import { describe, expect, it } from 'vitest';
import {
  getAppType,
  isFilesApp,
  isGitApp,
  shouldOpenSourceCodeLinkInNewTab,
  shouldShowGenericFileBrowser,
  supportsDocumentFeatures,
  supportsGitFeatures,
} from '../src/appType';

describe('app capabilities', () => {
  it('defaults to the Git app shell', () => {
    expect(getAppType()).toBe('git');
    expect(isGitApp()).toBe(true);
    expect(isFilesApp()).toBe(false);
  });

  it('enables git features and keeps generic document features disabled', () => {
    expect(supportsDocumentFeatures()).toBe(false);
    expect(supportsGitFeatures()).toBe(true);
  });

  it('hides the generic file browser and keeps source links in-tab', () => {
    expect(shouldShowGenericFileBrowser()).toBe(false);
    expect(shouldOpenSourceCodeLinkInNewTab()).toBe(false);
  });
});
