import { describe, expect, it, vi } from 'vitest';
import type { CID } from '@hashtree/core';

const wasmGetRefs = vi.hoisted(() => vi.fn());

vi.mock('../src/utils/wasmGit', () => ({
  getRefs: (...args: unknown[]) => wasmGetRefs(...args),
}));

function cid(byte: number): CID {
  return { hash: new Uint8Array([byte]), key: undefined } as CID;
}

describe('git refs facade', () => {
  it('forwards staged ref discovery callbacks to the native reader', async () => {
    const onCurrentBranch = vi.fn();
    const onBranches = vi.fn();
    const onRefNames = vi.fn();
    const result = {
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v1.0.0'],
      tagsByCommit: { aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: ['v1.0.0'] },
    };

    wasmGetRefs.mockImplementationOnce(async (_rootCid: CID, options?: {
      onCurrentBranch?: (branch: string) => void;
      onBranches?: (refs: Pick<typeof result, 'branches' | 'currentBranch'>) => void;
      onRefNames?: (refs: Omit<typeof result, 'tagsByCommit'>) => void;
    }) => {
      options?.onCurrentBranch?.('master');
      options?.onBranches?.({ branches: ['master'], currentBranch: 'master' });
      options?.onRefNames?.({ branches: ['master'], currentBranch: 'master', tags: ['v1.0.0'] });
      return result;
    });

    const { getRefs } = await import('../src/utils/git');
    await getRefs(cid(241), { onCurrentBranch, onBranches, onRefNames });

    expect(onCurrentBranch).toHaveBeenCalledWith('master');
    expect(onBranches).toHaveBeenCalledWith({ branches: ['master'], currentBranch: 'master' });
    expect(onRefNames).toHaveBeenCalledWith({
      branches: ['master'],
      currentBranch: 'master',
      tags: ['v1.0.0'],
    });
  });
});
