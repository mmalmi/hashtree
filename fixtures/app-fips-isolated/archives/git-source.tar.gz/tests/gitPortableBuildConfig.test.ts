import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { gitPortableBuild, portableAssetBase, sanitizePortableHtml } from '../portableViteConfig';
import { shouldInterceptHtreeRequestForWorker } from '../src/lib/swRoutePolicy';

describe('git portable build config', () => {
  it('serves informational pages as app assets inside a portable htree path', () => {
    for (const file of ['about.html', 'iris-git-vs-github.html', 'quickstart.html', 'how-it-works.html', 'learn.css']) {
      expect(shouldInterceptHtreeRequestForWorker(`/htree/npub1publisher/git/${file}`, null, null, 'document')).toBe(false);
    }
    expect(shouldInterceptHtreeRequestForWorker('/htree/npub1publisher/git/README.md', null, null, 'document')).toBe(true);
    expect(shouldInterceptHtreeRequestForWorker('/htree/npub1publisher/git/about.html', 'private-client', null, 'document')).toBe(true);
  });
  it('uses a relative asset base for git builds served from htree trees', () => {
    expect(portableAssetBase).toBe('./');
    expect(gitPortableBuild.outDir).toBe('iris-git');
    expect(gitPortableBuild.modulePreload).toBe(false);
  });

  it('strips module preload and crossorigin hints for htree webviews', () => {
    const sanitized = sanitizePortableHtml(`
      <script type="module" crossorigin src="./assets/main.js"></script>
      <link rel="modulepreload" crossorigin href="./assets/vendor.js">
      <link rel="stylesheet" crossorigin href="./assets/main.css">
    `);

    expect(sanitized).not.toContain('modulepreload');
    expect(sanitized).not.toContain('crossorigin');
    expect(sanitized).toContain('<script type="module" src="./assets/main.js"></script>');
    expect(sanitized).toContain('<link rel="stylesheet" href="./assets/main.css">');
  });

  it('leaves released Svelte source packages to the Svelte plugin in dev', () => {
    const source = fs.readFileSync(path.resolve(import.meta.dirname, '../vite.git.config.ts'), 'utf8');
    expect(source).toMatch(/optimizeDeps:\s*\{\s*noDiscovery:\s*true,/s);
    expect(source).toMatch(/include:\s*\[[^\]]*'dexie'[^\]]*'qrcode'/s);
  });
});
