import { beforeEach, describe, expect, it, vi } from 'vitest';

const shared = vi.hoisted(() => {
  const stop = vi.fn();
  const on = vi.fn();
  const subscribe = vi.fn(() => ({ on, stop }));
  const fetchRepoAnnouncement = vi.fn();

  return {
    stop,
    on,
    subscribe,
    fetchRepoAnnouncement,
    reset() {
      stop.mockReset();
      on.mockReset();
      subscribe.mockClear();
      fetchRepoAnnouncement.mockReset();
      fetchRepoAnnouncement.mockResolvedValue({
        id: '1'.repeat(64),
        address: `30617:${'a'.repeat(64)}:alpha`,
        ownerPubkey: 'a'.repeat(64),
        ownerNpub: 'npub1owner',
        repoName: 'alpha',
        createdAt: 1,
        description: '',
        cloneUrls: ['htree://npub1owner/alpha'],
        webUrls: [],
        earliestUniqueCommit: 'euc-1',
        isPersonalFork: false,
        forkedFrom: null,
      });
    },
  };
});

vi.mock('../src/nostr', () => ({
  nostr: { subscribe: shared.subscribe },
}));

vi.mock('../src/nip34', () => ({
  buildRepoAddress: (_ownerNpub: string, repoName: string) => `30617:${'a'.repeat(64)}:${repoName}`,
  fetchRepoAnnouncement: shared.fetchRepoAnnouncement,
}));

describe('repo fork store subscription lifecycle', () => {
  beforeEach(() => {
    vi.resetModules();
    shared.reset();
  });

  it('shares one live subscription and replaces it after the last store is destroyed', async () => {
    const { createRepoForkStatsStore } = await import('../src/stores/repoForks');
    const first = createRepoForkStatsStore('npub1owner', 'alpha');
    const second = createRepoForkStatsStore('npub1owner', 'alpha');

    await vi.waitFor(() => expect(shared.subscribe).toHaveBeenCalledTimes(1));
    first.destroy();
    expect(shared.stop).not.toHaveBeenCalled();

    second.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(1);

    const replacement = createRepoForkStatsStore('npub1owner', 'alpha');
    await vi.waitFor(() => expect(shared.subscribe).toHaveBeenCalledTimes(2));
    replacement.destroy();
    expect(shared.stop).toHaveBeenCalledTimes(2);
  });

  it('does not install a subscription after its only store was destroyed during setup', async () => {
    let resolveAnnouncement!: (value: unknown) => void;
    shared.fetchRepoAnnouncement.mockReturnValueOnce(new Promise(resolve => {
      resolveAnnouncement = resolve;
    }));

    const { createRepoForkStatsStore } = await import('../src/stores/repoForks');
    const store = createRepoForkStatsStore('npub1owner', 'alpha');
    store.destroy();
    resolveAnnouncement({
      address: `30617:${'a'.repeat(64)}:alpha`,
      earliestUniqueCommit: 'euc-1',
    });

    await Promise.resolve();
    await Promise.resolve();
    expect(shared.subscribe).not.toHaveBeenCalled();
  });
});
