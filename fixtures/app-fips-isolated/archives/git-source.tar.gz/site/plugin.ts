import { readFileSync } from 'node:fs';
import type { Plugin } from 'vite';
import { pages, renderPage, discoveryFiles } from './pages.mjs';

export function informationPages(): Plugin {
  function files(): Record<string, string> {
    return {
      ...Object.fromEntries(pages.map(page => [page.file, renderPage(page)])),
      ...discoveryFiles(),
      'learn.css': readFileSync(new URL('./styles.css', import.meta.url), 'utf8'),
    };
  }
  return {
    name: 'git-information-pages',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const name = new URL(req.url ?? '/', 'http://localhost').pathname.slice(1);
        const output = files();
        if (!Object.hasOwn(output, name)) return next();
        const type = name.endsWith('.html') ? 'text/html' : name.endsWith('.css') ? 'text/css' : name.endsWith('.xml') ? 'application/xml' : 'text/plain';
        res.setHeader('Content-Type', `${type}; charset=utf-8`);
        res.end(output[name]);
      });
    },
    generateBundle() {
      for (const [fileName, source] of Object.entries(files())) {
        this.emitFile({ type: 'asset', fileName, source });
      }
    },
  };
}
