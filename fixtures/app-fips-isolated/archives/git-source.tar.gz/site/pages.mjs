import { GIT_REMOTE_HTREE_INSTALL_COMMAND } from '../src/components/Git/codeDropdownCopy.js';

const origin = 'https://git.iris.to';
const owner = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const source = `${origin}/#/${owner}/iris-git`;
const hashtree = `${origin}/#/${owner}/hashtree`;
const helperDocs = `${hashtree}/rust/crates/git-remote-htree/README.md`;
const agentGuide = 'https://github.com/mmalmi/hashtree/blob/master/docs/agents.md';
const agentPlugin = 'https://github.com/mmalmi/hashtree/blob/master/plugins/hashtree-git/README.md';
const githubDocs = 'https://docs.github.com/en';
const reviewed = '2026-10-02';
const cargoInstallCommand = 'cargo install --locked hashtree-cli@0.3.1 git-remote-htree@0.3.0';

function escape(value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

const code = (value) => `<pre tabindex="0"><code>${escape(value)}</code></pre>`;
const link = (href, label) => `<a href="${escape(href)}">${label}</a>`;

export const pages = [
  {
    file: 'about.html',
    reviewed: '2026-11-02',
    label: 'About',
    title: 'Iris Git — Git hosting without signup',
    heading: 'Git hosting without signup',
    eyebrow: 'Iris Git / Hashtree Git',
    description: 'Iris Git is an open-source Git app built on Nostr and Hashtree. Browse repositories, collaborate, and use ordinary Git commands with htree:// remotes.',
    intro: 'Publish code from your terminal. Browse repositories, issues, and pull requests in your browser. No hosting account required.',
    body: `
      <div class="actions">${link('./about.html#install', 'Install Git helper <span aria-hidden="true">↓</span>')}${link('./#/', 'Open Iris Git <span aria-hidden="true">↗</span>')}</div>
      <section id="install" class="getting-started" aria-labelledby="install-heading">
        <h2 id="install-heading">1. Install</h2>
        <p>Add the Hashtree helper to your existing Git tools.</p>
        <fieldset class="install-methods">
          <legend class="visually-hidden">Installation method</legend>
          <input class="visually-hidden" type="radio" name="install-method" id="install-cargo" aria-controls="install-cargo-panel" checked>
          <label for="install-cargo">Cargo</label>
          <input class="visually-hidden" type="radio" name="install-method" id="install-prebuilt" aria-controls="install-prebuilt-panel">
          <label for="install-prebuilt">Pre-built</label>
          <div id="install-cargo-panel" class="install-panel">
            <p>Build from source with Rust.</p>
            ${code(cargoInstallCommand)}
            <p class="note">Requires ${link('https://rustup.rs/', 'Rust and Cargo')}. Installs the CLI and Git remote helper.</p>
          </div>
          <div id="install-prebuilt-panel" class="install-panel">
            <p>Install pre-built tools for macOS or Linux.</p>
            ${code(GIT_REMOTE_HTREE_INSTALL_COMMAND)}
            <p class="note">Installs the CLI and Git remote helper. No Rust installation required.</p>
          </div>
        </fieldset>
        <h2>2. Push your first repository</h2>
        <p>In an existing Git repository, choose a name and publish:</p>
        ${code('git remote add hashtree htree://self/my-project\ngit push hashtree HEAD')}
        <p class="note">This publishes your code publicly. Your existing remotes stay in place. ${link('./quickstart.html', 'Full quickstart and private repository options →')}</p>
      </section>
      <section class="demo" aria-labelledby="demo-heading">
        <h2 id="demo-heading">See it in action</h2>
        <video controls playsinline preload="none" poster="./git-demo-poster.png" width="1280" height="720" aria-label="Hashtree Git demonstration" src="./git-demo.mp4">
          ${link('./git-demo.mp4', 'Watch the Git demo')}
        </video>
        <p class="note">A two-minute demo of creating and pushing a repository. Use the installation steps above to get started.</p>
      </section>
      <section class="split">
        <div><h2>Familiar Git.</h2><p>Commits, branches, clones, fetches, and pushes still use Git. Install <code>git-remote-htree</code> to add <code>htree://</code> remotes to your existing workflow.</p></div>
        <div><h2>A different home.</h2><p>Nostr keys identify publishers. Hashtree stores repository data by its content and retrieves it from storage servers or peers. A repository name is tied to its publisher’s public key.</p></div>
      </section>
      <section><h2>Keep control of your code</h2><p>Your signing key is your identity. Keep a backup of it and your repositories, and choose who stores and serves your data.</p><p>${link('./how-it-works.html', 'How it works →')} · ${link('./iris-git-vs-github.html', 'Compare with GitHub →')}</p></section>`,
  },
  {
    file: 'iris-git-vs-github.html',
    label: 'GitHub comparison',
    title: 'Iris Git / Hashtree Git vs GitHub — a practical comparison',
    heading: 'Iris Git vs GitHub',
    eyebrow: 'Compare / Hashtree Git',
    description: 'Compare Iris Git and Hashtree Git with GitHub: identity, hosting, Git workflows, collaboration, private repositories, automation, costs, and tradeoffs.',
    intro: 'GitHub brings hosting and development tools together in a managed platform. Iris Git puts a browser interface over Git repositories published through Nostr and Hashtree, with keys and storage you can manage yourself.',
    body: `
      <p class="note">Written by the Iris Git project. “Hashtree Git” refers to the underlying Git remote helper and storage, while Iris Git is the browser app.</p>
      <section class="split"><div><h2>Choose Iris Git when…</h2><p>You want production Git hosting built for developers and coding agents. Use standard Git commands, automate clone, fetch, and push without a separate platform API, and control your signing identity and storage.</p></div><div><h2>Choose GitHub when…</h2><p>You want integrated project management, code review, automation, and organization controls. Its managed service is a practical fit for teams already relying on GitHub workflows.</p></div></section>
      <section><h2>The practical differences</h2><div class="table-wrap" tabindex="0" role="region" aria-label="Iris Git and GitHub feature comparison"><table><caption>Iris Git / Hashtree Git and GitHub, reviewed October 2, 2026</caption><thead><tr><th scope="col">What matters</th><th scope="col">Iris Git / Hashtree Git</th><th scope="col">GitHub</th></tr></thead><tbody>
        <tr><th scope="row">Identity</th><td data-label="Iris Git / Hashtree Git">Nostr signing keys. The CLI can create an identity locally; no GitHub account is needed.</td><td data-label="GitHub">A GitHub account for hosting and contributing. Public code can be browsed without signing in.</td></tr>
        <tr><th scope="row">Hosting</th><td data-label="Iris Git / Hashtree Git">Content-addressed data on Blossom storage servers or peers. Signed Nostr events publish repository roots.</td><td data-label="GitHub">GitHub-hosted repositories; GitHub Enterprise Server is a separate self-hosted option.</td></tr>
        <tr><th scope="row">Command line</th><td data-label="Iris Git / Hashtree Git">Normal Git commands with the additional <code>git-remote-htree</code> helper and <code>htree://</code> URLs.</td><td data-label="GitHub">Normal Git commands over HTTPS or SSH.</td></tr>
        <tr><th scope="row">Collaboration</th><td data-label="Iris Git / Hashtree Git">Browser support for issues, pull requests, forks, and releases. Nostr is used for collaboration events.</td><td data-label="GitHub">Issues, pull requests, reviews, releases, and project planning in one platform.</td></tr>
        <tr><th scope="row">Private code</th><td data-label="Iris Git / Hashtree Git">The Git helper supports public, link-visible, and author-only private repositories. These are different from team access roles.</td><td data-label="GitHub">Private repositories with account and team access controls; advanced controls vary by plan.</td></tr>
        <tr><th scope="row">Automation</th><td data-label="Iris Git / Hashtree Git">The app displays Hashtree CI results from configured runners. Evaluate runner setup and workflow support before migrating.</td><td data-label="GitHub">GitHub Actions with GitHub-hosted or self-hosted runners.</td></tr>
        <tr><th scope="row">Costs</th><td data-label="Iris Git / Hashtree Git">Open-source software. Storage, relay, and runner providers may have their own costs and limits.</td><td data-label="GitHub">Free and paid plans; metered services and limits depend on usage and plan.</td></tr>
        <tr><th scope="row">Availability</th><td data-label="Iris Git / Hashtree Git">Depends on reachable relays and copies of the data. A content hash alone does not keep a repository online.</td><td data-label="GitHub">Managed by GitHub for its cloud service, or by your organization for Enterprise Server.</td></tr>
      </tbody></table></div></section>
      <section><h2>You can use both</h2><p>A Hashtree remote can sit beside a GitHub remote. Start with a public test repository, push a branch, then clone it into a fresh directory and compare the history. This lets you evaluate Hashtree without moving your entire project.</p><p>${link('./quickstart.html', 'Add your first Hashtree remote →')}</p></section>
      <section><h2>What does not transfer with Git?</h2><p>Pushing commits transfers Git history. It does not migrate GitHub issues, review discussions, project boards, secrets, access rules, or Actions configuration into a working replacement. Plan these separately if you move a project.</p></section>
      <section><h2>Is decentralized storage automatically private?</h2><p>No. Public repository keys are shared so others can read the code. Link-visible repositories can be read by anyone holding the secret link; author-only private repositories use a different access model. Avoid sharing a signing key among collaborators.</p><p>${link('./how-it-works.html', 'Understand identity, storage, and visibility →')}</p></section>
      <section class="sources"><h2>Sources and scope</h2><p>This compares the current Iris Git browser app and Hashtree helper with GitHub’s documented services. It is not a performance benchmark or a claim of feature parity.</p><ul><li>${link(source, 'Iris Git source')} and ${link(helperDocs, 'Git remote helper documentation')}</li><li>${link(`${githubDocs}/get-started/start-your-journey/what-is-github`, 'What is GitHub?')} and ${link(`${githubDocs}/account-and-profile/how-tos/account-management/creating-an-account-on-github`, 'GitHub accounts')}</li><li>${link(`${githubDocs}/get-started/learning-about-github/githubs-plans`, 'GitHub plans and Enterprise hosting')}</li><li>${link(`${githubDocs}/actions/get-started/understand-github-actions`, 'GitHub Actions and runners')}</li></ul></section>`,
  },
  {
    file: 'quickstart.html',
    reviewed: '2026-10-26',
    label: 'Quickstart',
    title: 'Iris Git quickstart — clone and push with Hashtree Git',
    heading: 'Your first Hashtree remote',
    eyebrow: 'Iris Git / Quickstart',
    description: 'Install git-remote-htree, clone a repository, and add a Hashtree remote to an existing Git project. A practical Iris Git quickstart for developers and agents.',
    intro: 'Keep using Git. The git-remote-htree helper adds support for htree:// URLs, so your terminal and coding tools can work with Hashtree repositories.',
    body: `
      <section><h2>1. Install the helper</h2><p>You need Git and ${link('https://rustup.rs/', 'Rust and Cargo')}. Build the CLI and Git remote helper with Cargo.</p>${code(cargoInstallCommand)}<p>Cargo installs the tools to its bin directory, usually <code>~/.cargo/bin</code>. Make sure it is on your <code>PATH</code>.</p><p>A compatible pre-built installer is being prepared. ${link('./about.html#install', 'Installation options →')}</p></section>
      <section><h2>2. Clone a public repository</h2><p>In Iris Git, open a repository and choose <strong>Code</strong> to copy its clone command. For example, this is the Hashtree source repository:</p>${code(`git clone htree://${owner}/hashtree`)}<p>Cloning needs access to repository announcements and a server or peer holding the data.</p></section>
      <section><h2>3. Add a remote to your own project</h2><p>In an existing Git repository with at least one commit, use an unused remote name and choose a repository name. This example publishes a <strong>public</strong> repository called <code>my-project</code>:</p>${code('git remote add hashtree htree://self/my-project\ngit push hashtree HEAD')}<p><code>self</code> refers to the CLI’s local signing identity. If there is no identity yet, the helper creates one. This may be different from the account signed into your browser. Keep a secure backup of your signing keys.</p><p>Your existing <code>origin</code> remote stays in place. To publish later commits, run <code>git push hashtree HEAD</code> again.</p></section>
      <section><h2>4. Check the result</h2><p>Open the published repository in ${link('./#/', 'Iris Git')}. Use its <strong>Code</strong> menu to clone it into a fresh directory. Compare <code>git log -1</code> in both copies to confirm the expected commit is available.</p><p>For direct peer-to-peer sharing, run <code>htree start</code> in another terminal. Git operations use the local daemon when it is running. Keep an available copy of your data; publishing a name alone is not a backup.</p></section>
      <section><h2>For humans and coding agents</h2><p>Use the same Git commands with your own signing identity. The ${link(agentGuide, 'complete first-use guide')} walks through a first push, shareable URL, and an independent clone. For an installable skill and supported agent setup, see ${link('./agents.html', 'Git for agents')}.</p></section>
      <section><h2>Private or link-visible repositories?</h2><p>Choose visibility before the first push. The ${link(helperDocs, 'helper documentation')} covers <code>#private</code> and <code>#link-visible</code>, including the extra key setup for secret links. Anyone with a link-visible repository’s secret link can read it.</p><p>${link('./how-it-works.html', 'Read how it works →')} · ${link('./iris-git-vs-github.html', 'Compare with GitHub →')}</p></section>`,
  },
  {
    file: 'agents.html',
    label: 'For agents',
    reviewed: '2026-10-26',
    title: 'Iris Git for AI agents — Git without signup',
    heading: 'Give your agent a place to publish.',
    eyebrow: 'Iris Git / Humans and agents',
    description: 'Publish and clone Git repositories without a hosting account. Set up Hashtree Git for humans, Codex, Claude, Grok Build, and Hermes with a reusable agent skill.',
    intro: 'Publish code, share a repository link, and let another person or agent clone it. No email, phone number, or hosting account is needed. Your local key is your publishing identity.',
    body: `
      <div class="actions">${link(agentGuide, 'First push and clone <span aria-hidden="true">→</span>')}${link(agentPlugin, 'Install the agent plugin <span aria-hidden="true">↗</span>')}</div>
      <section><h2>Ordinary Git, from any terminal</h2><p>Install <code>htree</code> and <code>git-remote-htree</code>, then add a remote to a repository you want to publish. This example publishes its committed history publicly:</p>${code('git remote add hashtree htree://self/my-project\ngit push hashtree HEAD')}<p>Your existing remotes stay in place. The helper creates a local identity if needed. ${link('./quickstart.html', 'See installation and visibility options →')}</p></section>
      <section><h2>Prove another agent can read it</h2><ol class="steps"><li><strong>Publish under your own key.</strong> Choose an unused repository name. Keep the key in persistent private storage, outside the repository.</li><li><strong>Share the public address.</strong> Use your <code>npub…</code> identity in the clone URL. <code>self</code> means the current agent’s identity and is not a shareable address.</li><li><strong>Clone with a fresh profile.</strong> On another machine, or with separate configuration and storage, clone the public URL. Compare the commit and read a known file.</li></ol><p>The ${link(agentGuide, 'step-by-step guide')} includes exact commands, separate profiles, fork collaboration, and recovery from common errors.</p></section>
      <section><h2>Bring it to your agent</h2><p>The Hashtree Git plugin packages a reusable skill for using the existing command line tools. Follow the ${link(agentPlugin, 'installation guide')} for Codex, Claude Code, Grok Build, and Hermes. The same workflow can be taught to other agents with terminal access.</p><p>For OpenAI dots or Grok Bot, use the command line where their execution environment permits it, or a connected computer. Installing this package does not imply a listing in a hosted app directory. No separate MCP server is needed for the terminal workflow.</p></section>
      <section class="split"><div><h2>Message your agent</h2><p>Iris Chat provides private messaging for people and agents. Send a request from your phone and have the agent reply with its repository link.</p><p>${link('https://chat.iris.to/', 'Open Iris Chat →')} · ${link('https://github.com/irislib/iris-chat-rs', 'CLI and source')}</p></div><div><h2>Connect your machines</h2><p>Nostr VPN connects approved devices in a private network without a VPN provider account. Use it when an agent needs access to a service on your own machine.</p><p>${link('https://nostrvpn.org/', 'Explore Nostr VPN →')} · ${link('https://github.com/mmalmi/nostr-vpn', 'CLI and source')}</p></div></section>
      <section><h2>Your keys, your choices</h2><p>Give each writer its own identity and publish contributions through separate forks. Choose public, secret-link, or author-only visibility before publishing. A secret link grants read access and must stay private.</p><p>Storage and relay operators set their own access and retention policies. Keep a local copy and verify that the data you publish remains available. ${link('./how-it-works.html', 'How identity, storage, and privacy work →')}</p><p>${link('./llms.txt', 'Documentation index for agents')}</p></section>`,
  },
  {
    file: 'how-it-works.html',
    label: 'How it works',
    title: 'How Iris Git works — Hashtree storage, Nostr identity, and privacy',
    heading: 'Git, with a different foundation.',
    eyebrow: 'Iris Git / How it works',
    description: 'How Iris Git and Hashtree Git use Git history, content-addressed storage, Nostr signing keys, relays, and peers. Understand privacy and availability tradeoffs.',
    intro: 'Git tracks changes. Hashtree stores repository data. Nostr connects a repository name to a signed update from its publisher. Iris Git brings these pieces into a browser.',
    body: `
      <section><h2>From a commit to another computer</h2><ol class="steps"><li><strong>Commit with Git.</strong> Your repository keeps ordinary Git commits, branches, and history.</li><li><strong>Store with Hashtree.</strong> The remote helper stores repository data as content-addressed trees. Data can be fetched from Blossom servers or peers.</li><li><strong>Publish with Nostr.</strong> Signed events announce the repository root under a public key and a repository name. Relays help other clients find those updates.</li><li><strong>Read with either client.</strong> Iris Git displays the repository in a browser. A Git client with <code>git-remote-htree</code> can clone or fetch it.</li></ol></section>
      <section><h2>Identity and integrity</h2><p>A signing key controls publication under its corresponding public key. Content hashes let clients verify the data they retrieve. These checks do not establish that a publisher is trustworthy or that the code is safe to run.</p><p>Keep signing keys separate from repository files and protect their backups. Each collaborator should use their own identity-specific remote. Sharing one private key can cause later pushes to overwrite another person’s published refs.</p></section>
      <section><h2>Visibility is a separate choice</h2><dl class="definitions"><div><dt>Public</dt><dd>Other people can read the repository. Internal storage encryption does not make public code confidential.</dd></div><div><dt>Link-visible</dt><dd>Encrypted data shared through a secret URL. Anyone who obtains that URL can read the repository; protect it like a credential.</dd></div><div><dt>Private</dt><dd>The Git helper’s author-only encrypted mode. This is not the same access model as a GitHub organization with team roles.</dd></div></dl><p>Encryption of repository data does not promise anonymity or hide all network metadata. A recipient can retain data they have already downloaded.</p></section>
      <section><h2>Who keeps the code online?</h2><p>Someone must retain and serve the data. Relays carry announcements; they do not automatically keep every repository’s files. Storage servers and peers supply the content, and their retention policies and reachability matter.</p><p>You can use the Hashtree daemon for peer-to-peer sharing. The browser uses Nostr-discovered FIPS WebRTC connections. Connections still need a working network path; decentralization does not remove networking or storage dependencies.</p><p>Keep independent backups and test a fresh clone. Losing every available copy of data cannot be repaired from its hash.</p></section>
      <section><h2>Where the web app fits</h2><p>git.iris.to is a convenient hosted interface. The Git remote helper can work without opening that site, but it still needs the configured relays and data providers. Browser browsing, public discovery, and Git transport are different parts of the system.</p><p>Iris Git also uses Nostr events for collaboration and can display results from configured Hashtree CI runners. Test your project’s review, access, and automation requirements before changing hosts.</p></section>
      <section class="sources"><h2>Read the implementation</h2><ul><li>${link(source, 'Iris Git source')}</li><li>${link(hashtree, 'Hashtree source and architecture')}</li><li>${link(helperDocs, 'Git remote helper: setup, visibility, identities, and P2P')}</li></ul><p>${link('./quickstart.html', 'Try the quickstart →')} · ${link('./iris-git-vs-github.html', 'Compare with GitHub →')}</p></section>`,
  },
];

export function renderPage(page) {
  const url = `${origin}/${page.file}`;
  const reviewDate = page.reviewed ?? reviewed;
  const reviewLabel = new Intl.DateTimeFormat('en-US', {
    month: 'long', day: 'numeric', year: 'numeric', timeZone: 'UTC',
  }).format(new Date(`${reviewDate}T00:00:00Z`));
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'TechArticle',
    headline: page.heading,
    description: page.description,
    url,
    dateModified: reviewDate,
    inLanguage: 'en',
    author: { '@type': 'Organization', name: 'Iris Git', url: `${origin}/about.html` },
    about: { '@type': 'SoftwareSourceCode', name: 'Iris Git', codeRepository: source },
  };
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escape(page.title)}</title>
  <meta name="description" content="${escape(page.description)}">
  <meta name="theme-color" content="#101714">
  <link rel="canonical" href="${url}">
  <meta property="og:type" content="article">
  <meta property="og:site_name" content="Iris Git">
  <meta property="og:title" content="${escape(page.title)}">
  <meta property="og:description" content="${escape(page.description)}">
  <meta property="og:url" content="${url}">
  <meta property="og:image" content="${origin}/iris-git-icon-512.png">
  <meta name="twitter:card" content="summary">
  <link rel="icon" type="image/svg+xml" href="./iris-git-icon.svg">
  <link rel="stylesheet" href="./learn.css">
  <script type="application/ld+json">${JSON.stringify(schema).replaceAll('<', '\\u003c')}</script>
</head>
<body>
  <a class="skip" href="./${page.file}#main">Skip to content</a>
  <header class="site-header"><a class="brand" href="./about.html"><img src="./iris-git-icon.svg" alt="" width="32" height="32">Iris Git</a><nav aria-label="Main navigation">${pages.map((item) => `<a href="./${item.file}"${page.file === item.file ? ' aria-current="page"' : ''}>${item.label}</a>`).join('')}<a class="open-app" href="./#/">Open app <span aria-hidden="true">↗</span></a></nav></header>
  <main id="main"><div class="hero"><p class="eyebrow">${page.eyebrow}</p><h1>${page.heading}</h1><p class="intro">${page.intro}</p></div>${page.body}</main>
  <footer><a class="brand" href="./about.html">Iris Git</a><p>Open source. Built on Nostr &amp; Hashtree.</p><p>Reviewed <time datetime="${reviewDate}">${reviewLabel}</time> · ${link(source, 'Source code')}</p></footer>
</body>
</html>
`;
}

export function discoveryFiles() {
  const urls = [`${origin}/`, ...pages.map((page) => `${origin}/${page.file}`)];
  return {
    'robots.txt': `User-agent: *\nAllow: /\n\nSitemap: ${origin}/sitemap.xml\n`,
    'sitemap.xml': `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((url) => `  <url><loc>${url}</loc></url>`).join('\n')}\n</urlset>\n`,
    'llms.txt': `# Iris Git\n\n> Git repositories for humans and agents, published with Nostr identities and Hashtree storage. No hosting account is required.\n\n## Guides\n\n${pages.map((page) => `- [${page.label}](${origin}/${page.file}): ${page.description}`).join('\n')}\n\n## Command line and agent setup\n\n- [First push and independent clone](${agentGuide}): Canonical walkthrough, identity persistence, visibility, and collaboration.\n- [Agent plugin](${agentPlugin}): Install the Hashtree Git skill for supported terminal agents.\n- [Git helper documentation](${helperDocs}): Installation and command details.\n\n## Related tools\n\n- [Iris Chat](https://github.com/irislib/iris-chat-rs): Private messaging with native apps and a command line interface.\n- [Nostr VPN](https://nostrvpn.org/): Private networking for approved devices without a VPN provider account.\n\nPublic repositories are public. Secret links grant read access; never publish those links or signing keys. Storage availability depends on reachable copies and provider policies.\n`,
  };
}
