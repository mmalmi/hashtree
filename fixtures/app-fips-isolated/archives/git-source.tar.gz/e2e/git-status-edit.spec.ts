import { test, expect } from './fixtures';
import { setupPageErrorHandler, navigateToPublicFolder, gotoGitApp, createPlainFolderInCurrentDirectory, enterFolder, ensureGitRepoInitialized, flushPendingPublishes } from './test-utils.js';


test.describe('Git status after file edit', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });

  // Note: "should show uncommitted after editing a file" test was removed as it's
  // a subset of the comprehensive test in git-commit.spec.ts

  test('should show uncommitted after adding a new file in subdirectory', { timeout: 90000 }, async ({ page }) => {
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder for our test repo
    await createPlainFolderInCurrentDirectory(page, 'subdir-test');

    // Navigate into the folder
    await enterFolder(page, 'subdir-test');

    // Create initial files with a src/ subdirectory
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Create README.md
      const readmeContent = new TextEncoder().encode('# Subdir Test\n');
      const { cid: readmeCid, size: readmeSize } = await tree.putFile(readmeContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', readmeCid, readmeSize, LinkType.Blob);

      // Create src directory
      const { cid: emptyDir } = await tree.putDirectory([]);
      rootCid = await tree.setEntry(rootCid, route.path, 'src', emptyDir, 0, LinkType.Dir);

      // Create src/main.js
      const mainContent = new TextEncoder().encode('console.log("hello");');
      const { cid: mainCid, size: mainSize } = await tree.putFile(mainContent);
      rootCid = await tree.setEntry(rootCid, [...route.path, 'src'], 'main.js', mainCid, mainSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for files to appear
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' })).toBeVisible({ timeout: 15000 });
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'src' })).toBeVisible({ timeout: 5000 });

    // Git Init
    await ensureGitRepoInitialized(page);
    await flushPendingPublishes(page);

    // Verify git repo detected and clean
    const cleanIndicator = page.locator('text=clean');
    await expect(cleanIndicator).toBeVisible({ timeout: 30000 });
    console.log('[test] Git status shows clean after initial commit');

    // Now add a NEW file (not just edit existing) at root level
    console.log('[test] Adding new file...');
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Add a new file
      const newContent = new TextEncoder().encode('New file content');
      const { cid: newCid, size: newSize } = await tree.putFile(newContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'newfile.txt', newCid, newSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });
    await flushPendingPublishes(page);

    // Wait for new file to appear
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'newfile.txt' })).toBeVisible({ timeout: 15000 });

    // Wait for uncommitted indicator
    console.log('[test] Waiting for uncommitted indicator after adding file...');
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });
    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });
    console.log('[test] SUCCESS: uncommitted indicator visible after adding new file');
  });

  test('should show uncommitted when editing file inside subdirectory', { timeout: 90000 }, async ({ page }) => {
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder for our test repo
    await createPlainFolderInCurrentDirectory(page, 'edit-in-subdir-test');

    // Navigate into the folder
    await enterFolder(page, 'edit-in-subdir-test');

    // Create files with a src/ subdirectory
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Create src directory
      const { cid: emptyDir } = await tree.putDirectory([]);
      rootCid = await tree.setEntry(rootCid, route.path, 'src', emptyDir, 0, LinkType.Dir);

      // Create src/main.js
      const mainContent = new TextEncoder().encode('console.log("original");');
      const { cid: mainCid, size: mainSize } = await tree.putFile(mainContent);
      rootCid = await tree.setEntry(rootCid, [...route.path, 'src'], 'main.js', mainCid, mainSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for files to appear
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'src' })).toBeVisible({ timeout: 15000 });

    // Git Init
    await ensureGitRepoInitialized(page);
    await flushPendingPublishes(page);

    // Verify git repo detected and clean
    const cleanIndicator = page.locator('text=clean');
    await expect(cleanIndicator).toBeVisible({ timeout: 30000 });
    console.log('[test] Git status shows clean after initial commit');

    // Navigate into src/ subdirectory
    const srcLink = page.locator('[data-testid="file-list"] a').filter({ hasText: 'src' }).first();
    await srcLink.click();
    await page.waitForURL(/src/, { timeout: 10000 });

    // Verify we're in the subdirectory and can see main.js
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'main.js' })).toBeVisible({ timeout: 15000 });

    // Status should still show clean (we're in subdirectory, git root is parent)
    await expect(cleanIndicator).toBeVisible({ timeout: 10000 });
    console.log('[test] Git status shows clean in subdirectory');

    // Now EDIT main.js while in the subdirectory
    console.log('[test] Editing main.js in subdirectory...');
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Modify main.js with new content (route.path should be ["edit-in-subdir-test", "src"])
      const updatedContent = new TextEncoder().encode('console.log("modified!");');
      const { cid: updatedCid, size: updatedSize } = await tree.putFile(updatedContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'main.js', updatedCid, updatedSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for the uncommitted changes indicator to appear
    console.log('[test] Waiting for uncommitted indicator...');
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });

    // Take screenshot for debugging
    await page.screenshot({ path: 'e2e/screenshots/git-status-subdir-edit.png' });

    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });
    console.log('[test] SUCCESS: uncommitted indicator visible after editing file in subdirectory');
  });

  test('should show uncommitted after using FileEditor to edit a file', { timeout: 120000 }, async ({ page }) => {
    // This test uses the actual FileEditor UI component to edit a file,
    // matching what the user does when clicking on a file and editing via autosave
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder for our test repo
    await createPlainFolderInCurrentDirectory(page, 'editor-test');

    // Navigate into the folder
    await enterFolder(page, 'editor-test');

    // Create initial file via the tree API
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Create test.txt - a text file that can be edited
      const content = new TextEncoder().encode('Original content\n');
      const { cid, size } = await tree.putFile(content);
      rootCid = await tree.setEntry(rootCid, route.path, 'test.txt', cid, size, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for file to appear
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'test.txt' })).toBeVisible({ timeout: 15000 });

    // Git Init
    await ensureGitRepoInitialized(page);
    await flushPendingPublishes(page);

    // Verify git repo detected and clean
    const cleanIndicator = page.locator('text=clean');
    await expect(cleanIndicator).toBeVisible({ timeout: 30000 });
    console.log('[test] Git status shows clean after initial commit');

    // Record the current URL (directory view with ?g= param)
    const dirUrl = page.url();
    console.log('[test] Directory URL:', dirUrl);

    // Click on test.txt to view it
    const fileLink = page.locator('[data-testid="file-list"] a').filter({ hasText: 'test.txt' }).first();
    await fileLink.click();
    await page.waitForURL(/test\.txt/, { timeout: 10000 });
    console.log('[test] Navigated to file');

    // Wait for the file content to load
    await expect(page.locator('pre').filter({ hasText: 'Original content' })).toBeVisible({ timeout: 10000 });
    console.log('[test] File content loaded');

    // Click Edit button to enter edit mode
    const editBtn = page.locator('[data-testid="viewer-edit"]');
    await expect(editBtn).toBeVisible({ timeout: 5000 });
    await editBtn.click({ force: true });
    console.log('[test] Clicked Edit button');
    await page.waitForURL(/edit=1/, { timeout: 10000 });

    // Wait for the FileEditor to appear (textarea)
    const textarea = page.locator('textarea');
    await expect(textarea).toBeVisible({ timeout: 5000 });
    console.log('[test] FileEditor visible');

    // Enable autosave if not already enabled
    const autosaveCheckbox = page.locator('input[type="checkbox"]').filter({ has: page.locator('text=Autosave') });
    // Check if autosave label is visible and checkbox is present
    const autosaveLabel = page.locator('label').filter({ hasText: 'Autosave' });
    if (await autosaveLabel.isVisible()) {
      const checkbox = autosaveLabel.locator('input[type="checkbox"]');
      const isChecked = await checkbox.isChecked();
      if (!isChecked) {
        await checkbox.click();
        console.log('[test] Enabled autosave');
      } else {
        console.log('[test] Autosave already enabled');
      }
    }

    // Clear and type new content
    await textarea.fill('Modified content - this file was edited!\n');
    console.log('[test] Typed new content');

    // Wait for autosave debounce (1 second + some buffer)
    await page.waitForTimeout(1500);
    console.log('[test] Waited for autosave');

    // Click Done to exit edit mode (stays on file view)
    const doneBtn = page.getByRole('button', { name: 'Done' });
    await doneBtn.click();
    console.log('[test] Clicked Done - exited edit mode');

    // Wait for edit mode to exit (textarea should be gone)
    await expect(page.locator('textarea')).not.toBeVisible({ timeout: 5000 });
    console.log('[test] Edit mode exited');

    // Now navigate back to the directory view by clicking the back button
    const backBtn = page.locator('[data-testid="viewer-back"]');
    await expect(backBtn).toBeVisible({ timeout: 5000 });
    await backBtn.click();
    console.log('[test] Clicked back button');

    // Wait for directory view (should not have test.txt in the URL path)
    await page.waitForFunction(
      () => !window.location.hash.includes('test.txt'),
      undefined,
      { timeout: 10000 }
    );
    console.log('[test] Back at directory view');

    // Take screenshot for debugging
    await page.screenshot({ path: 'e2e/screenshots/git-status-editor-test.png' });

    // NOW check for the uncommitted indicator
    // This is the critical test - after editing via FileEditor, status should show "uncommitted"
    console.log('[test] Checking for uncommitted indicator...');
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });

    // Wait for the git status to update - may need to reload or wait for reactivity
    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });
    console.log('[test] SUCCESS: uncommitted indicator visible after using FileEditor');

    // Verify the count shows 1 change
    await expect(uncommittedBtn).toContainText(/1/);
  });

  test('should show uncommitted after forking and editing a git repo', { timeout: 120000 }, async ({ page }) => {
    // This test verifies that forked git repos maintain the index file
    // and git status correctly shows changes after editing
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder for our source repo
    await createPlainFolderInCurrentDirectory(page, 'fork-source-test');

    // Navigate into the folder
    await enterFolder(page, 'fork-source-test');

    // Create initial files via the tree API
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Create README.md
      const readmeContent = new TextEncoder().encode('# Fork Test\n\nOriginal content.');
      const { cid: readmeCid, size: readmeSize } = await tree.putFile(readmeContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', readmeCid, readmeSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for file to appear
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' })).toBeVisible({ timeout: 15000 });

    await ensureGitRepoInitialized(page);
    await flushPendingPublishes(page);

    // Verify git repo detected and clean
    const cleanIndicator = page.locator('text=clean');
    await expect(cleanIndicator).toBeVisible({ timeout: 30000 });
    console.log('[test] Source repo: Git status shows clean after initial commit');

    // Now FORK this repo using the Fork button
    const forkBtn = page.locator('button[title="Fork as new top-level folder"]:visible').first();
    await expect(forkBtn).toBeVisible({ timeout: 15000 });
    await forkBtn.click();

    // Wait for fork modal
    const forkModal = page.locator('.fixed.inset-0').filter({ hasText: 'Fork as New Folder' });
    await expect(forkModal).toBeVisible({ timeout: 5000 });

    // Enter name for forked repo
    const forkNameInput = forkModal.locator('input');
    await forkNameInput.fill('fork-dest-test');

    // Click Fork button
    const confirmForkBtn = forkModal.getByRole('button', { name: /fork/i }).last();
    await confirmForkBtn.click();

    // Wait for navigation to forked repo
    await page.waitForURL(/fork-dest-test/, { timeout: 15000 });
    console.log('[test] Forked to fork-dest-test');

    // Wait for forked repo to load
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' })).toBeVisible({ timeout: 15000 });
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: '.git' })).toBeVisible({ timeout: 5000 });
    console.log('[test] Forked repo loaded with files');

    // Verify git status shows clean in forked repo
    const forkedCleanIndicator = page.locator('text=clean');
    await expect(forkedCleanIndicator).toBeVisible({ timeout: 30000 });
    console.log('[test] Forked repo: Git status shows clean (index copied correctly)');

    // Now EDIT a file in the forked repo
    console.log('[test] Editing README.md in forked repo...');
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Modify README.md with new content
      const updatedContent = new TextEncoder().encode('# Fork Test\n\nModified content in fork!');
      const { cid: updatedCid, size: updatedSize } = await tree.putFile(updatedContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', updatedCid, updatedSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for the uncommitted changes indicator to appear
    console.log('[test] Waiting for uncommitted indicator in forked repo...');
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });

    // Take screenshot for debugging if this fails
    await page.screenshot({ path: 'e2e/screenshots/git-status-forked-edit.png' });

    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });
    console.log('[test] SUCCESS: uncommitted indicator visible after editing forked repo');

    // Verify the count shows 1 change
    await expect(uncommittedBtn).toContainText(/1/);
  });
});
