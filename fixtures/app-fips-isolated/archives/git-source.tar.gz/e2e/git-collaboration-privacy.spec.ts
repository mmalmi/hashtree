import { test, expect } from './fixtures';
import { ensureLoggedIn, flushPendingPublishes, gotoGitApp, useLocalRelay, waitForRelayConnected } from './test-utils';

test.describe('Git collaboration privacy', () => {
  test.setTimeout(120000);
  for (const visibility of ['private', 'link-visible', 'unknown'] as const) {
    test(`blocks publishing for ${visibility} repositories`, async ({ page }, testInfo) => {
      await gotoGitApp(page);
      await useLocalRelay(page);
      await ensureLoggedIn(page);
      await waitForRelayConnected(page);

      const fixture = await page.evaluate(async (visibility) => {
        const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
        const { nostr, nostrStore } = await import('/src/nostr/index.ts');
        const { buildRepoAddress } = await import('/src/nip34.ts');
        const repoName = `privacy-${visibility}-${Date.now()}`;
        const npub = nostrStore.getState().npub!;
        let linkKey: string | undefined;
        if (visibility !== 'unknown') {
          const repo = await createGitRepositoryTree(repoName, visibility);
          if (!repo.success) throw new Error('Could not create repository fixture');
          linkKey = repo.linkKey;
        }
        // Simulate historical public discussions, written directly to the local
        // test relay before the guard existed. They must now be read-only.
        const seed = async (kind: number) => {
          const event = await nostr.signEvent({ kind, created_at: 1, content: 'Existing discussion', tags: [
            ['a', buildRepoAddress(npub, repoName)], ['subject', 'Existing discussion'],
          ] });
          await nostr.publish(event);
          return event.id;
        };
        return { npub, repoName, linkKey, issueId: await seed(1621), prId: await seed(1618) };
      }, visibility);
      await flushPendingPublishes(page);
      const base = `/git.html#/${fixture.npub}/${fixture.repoName}`;
      const key = fixture.linkKey ? `&k=${fixture.linkKey}` : '';
      const reason = visibility === 'unknown'
        ? 'Publishing is unavailable until repository visibility is confirmed.'
        : 'Issues, pull requests and comments are currently available only for public repositories.';

      await page.goto(`${base}?tab=issues${key}`);
      await expect(page.getByRole('button', { name: 'New Issue', exact: true })).toBeDisabled();
      await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();
      await expect(page.getByText('Existing discussion', { exact: true })).toBeVisible();
      await page.screenshot({ path: testInfo.outputPath(`${visibility}-issues.png`) });

      await page.goto(`${base}?tab=pulls${key}`);
      await expect(page.getByRole('button', { name: 'New Pull Request', exact: true })).toBeDisabled();
      await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();

      for (const [tab, id] of [['issues', fixture.issueId], ['pulls', fixture.prId]]) {
        await page.goto(`${base}?tab=${tab}&id=${id}${key}`);
        await expect(page.getByRole('heading', { name: 'Existing discussion' })).toBeVisible();
        await expect(page.getByPlaceholder('Leave a comment (markdown supported)...')).toHaveCount(0);
        await expect(page.getByRole('button', { name: 'Close', exact: true })).toHaveCount(0);
        await expect(page.getByRole('status').filter({ hasText: reason })).toBeVisible();
      }
      await page.screenshot({ path: testInfo.outputPath(`${visibility}-discussion.png`) });

      const blocked = await page.evaluate(async ({ npub, repoName, issueId }) => {
        const { nostr } = await import('/src/nostr/index.ts');
        const { createIssue, createPullRequest, addComment, updateStatus, buildRepoAddress } = await import('/src/nip34.ts');
        const { npubToPubkey } = await import('/src/nostr/index.ts');
        const publish = nostr.publish;
        const broadcasts: number[] = [];
        nostr.publish = async event => { broadcasts.push(event.kind); throw new Error('Unexpected broadcast'); };
        try {
          const outcomes = [];
          for (const operation of [
            () => createIssue(npub, repoName, 'Do not publish', 'Private content'),
            () => createPullRequest(npub, repoName, 'Do not publish', 'Private content'),
            () => addComment(issueId, npubToPubkey(npub)!, 'Private reply', buildRepoAddress(npub, repoName)),
            () => updateStatus(issueId, npubToPubkey(npub)!, 'closed'),
          ]) {
            try { await operation(); outcomes.push(false); } catch { outcomes.push(true); }
          }
          return { outcomes, broadcasts };
        } finally {
          nostr.publish = publish;
        }
      }, fixture);
      expect(blocked).toEqual({ outcomes: [true, true, true, true], broadcasts: [] });

      // Directly opening a dialog must not restore its submit action.
      await page.evaluate(async ({ npub, repoName }) => {
        const { open } = await import('/src/components/Git/NewIssueModal.svelte');
        open({ npub, repoName });
      }, fixture);
      await page.getByLabel('Title', { exact: true }).fill('Do not publish');
      await expect(page.getByRole('button', { name: 'Create Issue', exact: true })).toBeDisabled();
      await page.getByRole('button', { name: 'Cancel', exact: true }).click();
      await page.evaluate(async ({ npub, repoName }) => {
        const { open } = await import('/src/components/Git/NewPullRequestModal.svelte');
        open({ npub, repoName, branches: ['main', 'feature'] });
      }, fixture);
      await page.getByLabel('Title', { exact: true }).fill('Do not publish');
      await expect(page.getByRole('button', { name: 'Create Pull Request', exact: true })).toBeDisabled();

      if (visibility === 'link-visible') {
        expect(fixture.linkKey).toMatch(/^[0-9a-f]{66}$/);
        await page.goto(base + '?tab=issues');
        await page.reload();
        await expect.poll(() => {
          const query = new URL(page.url()).hash.split('?')[1];
          return new URLSearchParams(query).get('k');
        }).toBe(fixture.linkKey);
      }
    });
  }

  test('public repositories still publish issues, comments, PRs and status changes', async ({ page }) => {
    await gotoGitApp(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await waitForRelayConnected(page);
    const repo = await page.evaluate(async () => {
      const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
      return createGitRepositoryTree(`public-collaboration-${Date.now()}`, 'public');
    });
    expect(repo.success).toBe(true);
    await flushPendingPublishes(page);
    const base = `/git.html#/${repo.npub}/${repo.treeName}`;
    await page.goto(`${base}?tab=issues`);
    await expect(page.getByRole('button', { name: 'New Issue', exact: true })).toBeEnabled();
    await page.getByRole('button', { name: 'New Issue', exact: true }).click();
    await page.getByLabel('Title', { exact: true }).fill('Public issue');
    await page.getByRole('button', { name: 'Create Issue', exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    const issue = await page.evaluate(async ({ npub, treeName }) => {
      const { fetchIssues } = await import('/src/nip34.ts');
      return (await fetchIssues(npub!, treeName!)).find(issue => issue.title === 'Public issue');
    }, repo);
    expect(issue).toBeTruthy();
    await page.goto(`${base}?tab=issues&id=${issue!.id}`);
    await page.getByPlaceholder('Leave a comment (markdown supported)...').fill('Public reply');
    await page.getByRole('button', { name: 'Comment', exact: true }).click();
    await expect(page.getByText('Public reply', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Close', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Reopen', exact: true })).toBeVisible();

    const pr = await page.evaluate(async ({ npub, treeName }) => {
      const { createPullRequest } = await import('/src/nip34.ts');
      return createPullRequest(npub!, treeName!, 'Public pull request', 'Public change', { branch: 'feature' });
    }, repo);
    expect(pr).toBeTruthy();
    await page.goto(`${base}?tab=pulls`);
    await expect(page.getByRole('button', { name: 'New Pull Request', exact: true })).toBeEnabled();
    await expect(page.getByText('Public pull request', { exact: true })).toBeVisible();
  });
});
