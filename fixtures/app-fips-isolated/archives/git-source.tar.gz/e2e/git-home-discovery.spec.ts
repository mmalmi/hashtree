import { test, expect, type Page } from './fixtures';
import { finalizeEvent, getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import {
  gotoGitApp,
  setupPageErrorHandler,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';
import { FOLLOW_SECKEY, FOLLOW2_SECKEY } from './nostr-test-keys';

const DISCOVERED_REPO_AUTHOR_PUBKEY = getPublicKey(FOLLOW_SECKEY);
const DISCOVERED_REPO_AUTHOR_NPUB = nip19.npubEncode(DISCOVERED_REPO_AUTHOR_PUBKEY);
let nextEventCreatedAt = Math.floor(Date.now() / 1000);

function createdAt(): number {
  nextEventCreatedAt += 1;
  return nextEventCreatedAt;
}

function pubkeyForIndex(index: number): string {
  return index.toString(16).padStart(64, '0');
}

async function publishEvent(relayUrl: string, event: Record<string, unknown>): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const socket = new WebSocket(relayUrl);
    const timeout = setTimeout(() => {
      socket.close();
      reject(new Error('Timed out publishing event'));
    }, 5000);

    socket.on('open', () => {
      socket.send(JSON.stringify(['EVENT', event]));
    });

    socket.on('message', data => {
      try {
        const msg = JSON.parse(data.toString());
        if (Array.isArray(msg) && msg[0] === 'OK' && msg[1] === (event as { id?: string }).id) {
          clearTimeout(timeout);
          socket.close();
          resolve();
        }
      } catch {
        // Ignore non-JSON relay messages.
      }
    });

    socket.on('error', err => {
      clearTimeout(timeout);
      reject(err);
    });
  });
}

async function prepareUser(page: Page) {
  setupPageErrorHandler(page);
  await gotoGitApp(page);
  await waitForAppReady(page);
  await useLocalRelay(page);
  await page.waitForFunction(() => {
    const state = (window as any).__nostrStore?.getState();
    return state?.sessionReady && state.isLoggedIn && state.pubkey?.length === 64;
  }, undefined, { timeout: 30_000 });
  await waitForRelayConnected(page);
}

async function publishFallbackSeedFollows(relayUrl: string, ownerPubkey: string): Promise<void> {
  const followTags = Array.from({ length: 388 }, (_, index) => ['p', pubkeyForIndex(index + 1000)]);
  followTags.push(['p', ownerPubkey]);
  const followEvent = finalizeEvent({
    kind: 3,
    content: '',
    tags: followTags,
    created_at: createdAt(),
  }, FOLLOW2_SECKEY);

  await publishEvent(relayUrl, followEvent);
}

async function publishHtreeRepoAnnouncement(relayUrl: string, repoName: string): Promise<string> {
  const cloneUrl = `htree://${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`;
  const announcement = finalizeEvent({
    kind: 30617,
    content: '',
    tags: [
      ['d', repoName],
      ['clone', cloneUrl],
      ['r', '0'.repeat(40), 'euc'],
    ],
    created_at: createdAt(),
  }, FOLLOW_SECKEY);

  await publishEvent(relayUrl, announcement);
  return `#/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}`;
}

async function publishExternalRepoAnnouncement(
  relayUrl: string,
  repoName: string,
  cloneUrl: string,
  webUrl?: string,
): Promise<void> {
  const tags: string[][] = [
    ['d', repoName],
    ['clone', cloneUrl],
  ];
  if (webUrl) {
    tags.push(['web', webUrl]);
  }

  const announcement = finalizeEvent({
    kind: 30617,
    content: '',
    tags,
    created_at: createdAt(),
  }, FOLLOW_SECKEY);

  await publishEvent(relayUrl, announcement);
}

async function followPubkeyDirect(page: Page, pubkey: string): Promise<boolean> {
  return page.evaluate(async (targetPubkey: string) => {
    const { followPubkey } = await import('/src/stores/index.ts');
    return followPubkey(targetPubkey);
  }, pubkey);
}

test.describe('Git home discovery', () => {
  test('shows latest updated repositories from followed users instead of a hardcoded suggestion', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `followed-repo-${Date.now()}`;
    const expectedHref = await publishHtreeRepoAnnouncement(relayUrl, repoName);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      expect(await followPubkeyDirect(viewerPage, DISCOVERED_REPO_AUTHOR_PUBKEY)).toBe(true);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      await expect(section.getByRole('heading', { name: 'Updated Repositories' })).toBeVisible({ timeout: 30000 });
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', expectedHref);
      await expect(viewerPage.getByRole('heading', { name: 'Suggested Repository' })).not.toBeVisible();
      await expect(viewerPage.getByRole('link', { name: /^hashtree$/ })).not.toBeVisible();
    } finally {
      await viewerContext.close();
    }
  });

  test('shows fallback seed followed repositories when the user has no follows', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `seed-followed-repo-${Date.now()}`;
    const expectedHref = await publishHtreeRepoAnnouncement(relayUrl, repoName);
    await publishFallbackSeedFollows(relayUrl, DISCOVERED_REPO_AUTHOR_PUBKEY);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      await expect(section.getByRole('heading', { name: 'Updated Repositories' })).toBeVisible({ timeout: 30000 });
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', expectedHref);
    } finally {
      await viewerContext.close();
    }
  });

  test('opens non-htree discovered repositories externally', async ({ browser, relayUrl }) => {
    test.setTimeout(120000);
    const repoName = `external-followed-repo-${Date.now()}`;
    const cloneUrl = `https://git.shakespeare.diy/${DISCOVERED_REPO_AUTHOR_NPUB}/${repoName}.git`;
    const webUrl = `https://git.shakespeare.diy/projects/${repoName}`;
    await publishFallbackSeedFollows(relayUrl, DISCOVERED_REPO_AUTHOR_PUBKEY);
    await publishExternalRepoAnnouncement(relayUrl, repoName, cloneUrl, webUrl);

    const viewerContext = await browser.newContext();
    try {
      const viewerPage = await viewerContext.newPage();
      await prepareUser(viewerPage);

      const section = viewerPage.getByTestId('git-home-followed-repos');
      const repoLink = section.getByRole('link', { name: new RegExp(repoName) }).first();
      await expect(repoLink).toBeVisible({ timeout: 30000 });
      await expect(repoLink).toHaveAttribute('href', webUrl);
      await expect(repoLink).toHaveAttribute('target', '_blank');
      await expect(repoLink.getByTitle('Opens externally')).toBeVisible();
    } finally {
      await viewerContext.close();
    }
  });
});
