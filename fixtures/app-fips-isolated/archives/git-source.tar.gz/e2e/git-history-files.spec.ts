import { test, expect } from './fixtures';
import {
  setupPageErrorHandler,
  gotoGitApp,
  waitForAppReady,
} from './test-utils.js';
import { ensureGitSession } from './git-history.helpers';

function installGitHistoryBeforeEach() {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });
}

test.describe('Git history file metadata', () => {
  installGitHistoryBeforeEach();

  test('checkout commit should restore files from that commit', async ({ page }) => {
    test.setTimeout(120000);
    page.setDefaultTimeout(60000);

    await ensureGitSession(page);

    // Import Node.js modules
    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    // Create a git repo with two commits, checkout the first commit
    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-checkout-test-'));

    try {
      // Initialize git repo
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      // First commit: create initial file
      await fs.writeFile(path.join(tmpDir, 'file.txt'), 'Version 1\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Initial commit"', { cwd: tmpDir });

      // Get first commit SHA
      const firstCommit = execSync('git rev-parse HEAD', { cwd: tmpDir }).toString().trim();

      // Second commit: modify file and add another
      await fs.writeFile(path.join(tmpDir, 'file.txt'), 'Version 2\n');
      await fs.writeFile(path.join(tmpDir, 'file2.txt'), 'New file\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Second commit"', { cwd: tmpDir });

      // Read all files
      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            result.push({ type: 'dir', path: relativePath });
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const allEntries = await getAllEntries(tmpDir);
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      // Upload repo and test checkoutCommit
      const result = await page.evaluate(async ({ files, dirs, commitSha }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const tree = getTree();

        // Create root directory and upload all files
        let { cid: rootCid } = await tree.putDirectory([]);

        // Create directories
        const dirPaths = new Set<string>(dirs);
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          rootCid = await tree.setEntry(rootCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        // Add files
        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          rootCid = await tree.setEntry(rootCid, parts, name, fileCid, size, LinkType.Blob);
        }

        // List files before checkout (should have both file.txt and file2.txt)
        const entriesBefore = await tree.listDirectory(rootCid);
        const filesBefore = entriesBefore.filter(e => e.type !== LinkType.Dir && e.name !== '.git').map(e => e.name);

        // Read file.txt content before checkout
        const file1Before = await tree.resolvePath(rootCid, 'file.txt');
        const file1ContentBefore = file1Before ? new TextDecoder().decode(await tree.readFile(file1Before.cid) || new Uint8Array()) : '';

        // Test checkoutCommit
        const { checkoutCommit } = await import('/src/utils/git.ts');

        try {
          const newRootCid = await checkoutCommit(rootCid, commitSha);

          // List files after checkout (should only have file.txt, no file2.txt)
          const entriesAfter = await tree.listDirectory(newRootCid);
          const filesAfter = entriesAfter.filter(e => e.type !== LinkType.Dir && e.name !== '.git').map(e => e.name);

          // Read file.txt content after checkout
          const file1After = await tree.resolvePath(newRootCid, 'file.txt');
          const file1ContentAfter = file1After ? new TextDecoder().decode(await tree.readFile(file1After.cid) || new Uint8Array()) : '';

          // Check if file2.txt exists
          const file2After = await tree.resolvePath(newRootCid, 'file2.txt');

          return {
            success: true,
            filesBefore: filesBefore.sort(),
            filesAfter: filesAfter.sort(),
            file1ContentBefore,
            file1ContentAfter,
            file2ExistsAfter: file2After !== null,
            error: null
          };
        } catch (err) {
          return {
            success: false,
            filesBefore: [],
            filesAfter: [],
            file1ContentBefore: '',
            file1ContentAfter: '',
            file2ExistsAfter: true,
            error: err instanceof Error ? err.message : String(err)
          };
        }
      }, { files: allFiles, dirs: allDirs, commitSha: firstCommit });

      console.log('Checkout result:', JSON.stringify(result, null, 2));
      expect(result.success).toBe(true);
      expect(result.error).toBeNull();

      // Before checkout: both files should exist, file.txt should be "Version 2"
      expect(result.filesBefore).toContain('file.txt');
      expect(result.filesBefore).toContain('file2.txt');
      expect(result.file1ContentBefore.trim()).toBe('Version 2');

      // After checkout to first commit: only file.txt should exist, content should be "Version 1"
      expect(result.filesAfter).toContain('file.txt');
      expect(result.file2ExistsAfter).toBe(false);
      expect(result.file1ContentAfter.trim()).toBe('Version 1');

    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });
  test('git directory listing should show last commit info for files', async ({ page }) => {
    test.slow(); // This test involves git operations that take time
    // Capture console logs for debugging
    const logs: string[] = [];
    page.on('console', msg => {
      if (msg.text().includes('[wasm-git]') || msg.text().includes('fileCommits')) {
        logs.push(msg.text());
      }
    });

    await ensureGitSession(page);

    // Create a real git repo with commits using CLI
    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-file-commits-'));

    try {
      // Initialize git repo and create commits
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      // Create first commit with README
      await fs.writeFile(path.join(tmpDir, 'README.md'), '# Test Repo\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Add README"', { cwd: tmpDir });

      // Create second commit with src directory
      await fs.mkdir(path.join(tmpDir, 'src'));
      await fs.writeFile(path.join(tmpDir, 'src', 'index.ts'), 'export const x = 1;\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Add src directory"', { cwd: tmpDir });

      // Read all files and directories
      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            result.push({ type: 'dir', path: relativePath });
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const allEntries = await getAllEntries(tmpDir);
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      // Upload and test getFileLastCommits
      const result = await page.evaluate(async ({ files, dirs }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const tree = getTree();

        // Create root directory and upload all files
        let { cid: rootCid } = await tree.putDirectory([]);

        // Create directories
        const dirPaths = new Set<string>(dirs);
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          rootCid = await tree.setEntry(rootCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        // Add files
        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          rootCid = await tree.setEntry(rootCid, parts, name, fileCid, size, LinkType.Blob);
        }

        // List root directory entries
        const entries = await tree.listDirectory(rootCid);
        const entryNames = entries.map(e => e.name);

        // Test getFileLastCommits
        const { getFileLastCommits } = await import('/src/utils/git.ts');
        const fileCommits = await getFileLastCommits(rootCid, entryNames);

        return {
          entryNames,
          fileCommitsSize: fileCommits.size,
          fileCommitsKeys: Array.from(fileCommits.keys()),
          readmeCommit: fileCommits.get('README.md'),
          srcCommit: fileCommits.get('src'),
        };
      }, { files: allFiles, dirs: allDirs });

      console.log('File commits result:', JSON.stringify(result, null, 2));
      console.log('Console logs:', logs);

      // Verify we got commit info for files and directories
      expect(result.fileCommitsSize).toBeGreaterThan(0);
      expect(result.fileCommitsKeys).toContain('README.md');
      expect(result.fileCommitsKeys).toContain('src'); // Directory should also have commit info
      expect(result.readmeCommit?.message).toContain('Add README');
      expect(result.srcCommit?.message).toContain('Add src');

      // Now test the UI - publish as a top-level git tree and open it in the git app
      const ownerNpub = await page.evaluate(() => {
        const store = (window as NostrStoreWindow).__nostrStore;
        return store?.getState?.().npub ?? null;
      });
      expect(ownerNpub).toBeTruthy();
      await page.evaluate(async ({ files, dirs, repoName }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const { saveHashtree } = await import('/src/nostr/index.ts');

        const tree = getTree();

        // Create the git repo directory
        let { cid: repoCid } = await tree.putDirectory([]);

        // Create directories
        const dirPaths = new Set<string>(dirs);
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          repoCid = await tree.setEntry(repoCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        // Add files
        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          repoCid = await tree.setEntry(repoCid, parts, name, fileCid, size, LinkType.Blob);
        }

        await saveHashtree(repoName, repoCid, { visibility: 'public', labels: ['git'] });
      }, { files: allFiles, dirs: allDirs, repoName: 'test-git-repo' });

      await page.evaluate(({ npub, repoName }) => {
        window.location.hash = `#/${npub}/${repoName}`;
      }, { npub: ownerNpub, repoName: 'test-git-repo' });
      await page.waitForURL(/test-git-repo/, { timeout: 15000 });
      await waitForAppReady(page, 30000);

      // Set larger viewport to see commit message column
      await page.setViewportSize({ width: 1200, height: 800 });

      // Check that the README row exists
      const readmeRow = page.locator('tr').filter({ hasText: 'README.md' });
      await expect(readmeRow).toBeVisible({ timeout: 15000 });

      // The commit message or relative time should appear in the table
      // Look for "Add README" text or time like "just now" or "ago"
      const commitCell = page.locator('td').filter({ hasText: /Add README|just now|ago/ });
      await expect(commitCell.first()).toBeVisible({ timeout: 15000 });

    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });
});
