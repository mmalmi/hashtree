import { test, expect } from './fixtures';
import { setupPageErrorHandler, navigateToPublicFolder, safeReload, waitForAppReady, gotoGitApp, createRepositoryInCurrentDirectory, enterFolder, ensureGitRepoInitialized, waitForCurrentDirectoryEntries } from './test-utils.js';

test.describe('Git commit features', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });

  test('should be able to add files and commit them via commit modal', { timeout: 90000 }, async ({ page }) => {
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder for our test repo
    await createRepositoryInCurrentDirectory(page, 'commit-test-repo');

    // Navigate into the folder
    await enterFolder(page, 'commit-test-repo');

    // Create initial files via the tree API
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Create README.md
      const readmeContent = new TextEncoder().encode('# Commit Test Repo\n\nThis is a test repo for commit functionality.');
      const { cid: readmeCid, size: readmeSize } = await tree.putFile(readmeContent);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', readmeCid, readmeSize, LinkType.Blob);

      // Create a src directory with a file
      const { cid: emptyDir } = await tree.putDirectory([]);
      rootCid = await tree.setEntry(rootCid, route.path, 'src', emptyDir, 0, LinkType.Dir);

      const mainContent = new TextEncoder().encode('console.log("Hello from commit test!");');
      const { cid: mainCid, size: mainSize } = await tree.putFile(mainContent);
      rootCid = await tree.setEntry(rootCid, [...route.path, 'src'], 'main.js', mainCid, mainSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    // Wait for files to appear
    await waitForCurrentDirectoryEntries(page, ['README.md', 'src']);
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' })).toBeVisible({ timeout: 15000 });

    await ensureGitRepoInitialized(page);

    // Verify .git directory was created and commits button appears
    const gitDir = page.locator('[data-testid="file-list"] a').filter({ hasText: '.git' }).first();
    await expect(gitDir).toHaveCount(1, { timeout: 20000 });

    const commitsBtn = page.getByRole('button', { name: /commits/i });
    await expect(commitsBtn).toBeVisible({ timeout: 20000 });

    // Verify initial commit was created (should show "1 commits" or similar)
    await expect(commitsBtn).toContainText(/1/, { timeout: 10000 });

    // Now add a new file to create uncommitted changes
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // Add a new file
      const newFileContent = new TextEncoder().encode('export const VERSION = "1.0.0";');
      const { cid: newFileCid, size: newFileSize } = await tree.putFile(newFileContent);
      rootCid = await tree.setEntry(rootCid, [...route.path, 'src'], 'version.js', newFileCid, newFileSize, LinkType.Blob);

      // Modify README.md
      const updatedReadme = new TextEncoder().encode('# Commit Test Repo\n\nThis is a test repo for commit functionality.\n\n## Added\n- version.js');
      const { cid: updatedReadmeCid, size: updatedReadmeSize } = await tree.putFile(updatedReadme);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', updatedReadmeCid, updatedReadmeSize, LinkType.Blob);

      autosaveIfOwn(rootCid);
    });

    await waitForCurrentDirectoryEntries(page, ['README.md', 'src']);

    // Wait for the uncommitted changes indicator to appear
    // It should show something like "2 uncommitted" or a warning colored number
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });
    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });

    // Click to open commit modal
    await uncommittedBtn.click();

    // Commit modal should be visible
    const commitModal = page.locator('.fixed.inset-0').filter({ hasText: 'Commit Changes' });
    await expect(commitModal).toBeVisible({ timeout: 5000 });

    // Should show the changed entries with checkboxes
    await expect(commitModal.locator('text=README.md').first()).toBeVisible({ timeout: 5000 });
    await expect(commitModal.locator('text=src/').first()).toBeVisible({ timeout: 5000 });
    await expect(commitModal.locator('text=/\\d+ of \\d+ selected/')).toBeVisible({ timeout: 5000 });

    // Enter a commit message
    const commitMessageInput = commitModal.locator('textarea[placeholder*="Describe"]');
    await expect(commitMessageInput).toBeVisible({ timeout: 5000 });
    await commitMessageInput.fill('Add version.js and update README');

    // Click the Commit button
    const commitBtn = commitModal.getByRole('button', { name: 'Commit' });
    await expect(commitBtn).toBeEnabled({ timeout: 5000 });
    await commitBtn.click();

    // Wait for commit to complete (modal should close)
    await expect(commitModal).not.toBeVisible({ timeout: 30000 });

    // Reload to ensure git info and commit count refresh after commit
    await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: 60000 });
    await waitForAppReady(page, 60000);
    await page.waitForURL(/commit-test-repo/, { timeout: 10000 });
    await waitForCurrentDirectoryEntries(page, ['.git', 'README.md', 'src'], 30000);

    // Verify commits count increased to 2 (this proves the commit worked)
    const updatedCommitsBtn = page.getByRole('button', { name: /commits/i });
    await expect(updatedCommitsBtn).toContainText(/2/, { timeout: 30000 });

    // Note: Status refresh after commit may have timing issues
    // The important verification is that commit count increased
    // Status refresh is handled separately from the commit flow

    // Open git history modal to verify our commit is there
    await updatedCommitsBtn.click();

    // Git history modal should show our commit message
    const historyModal = page.locator('.fixed.inset-0').filter({ hasText: 'Commit History' });
    await expect(historyModal).toBeVisible({ timeout: 5000 });
    await expect(historyModal.locator('text=Add version.js and update README')).toBeVisible({ timeout: 10000 });

    // Close modal
    await page.keyboard.press('Escape');
    await expect(historyModal).not.toBeVisible({ timeout: 5000 });
  });

  test('git status should show correct filename (not truncated)', { timeout: 60000 }, async ({ page }) => {
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder and init as git repo
    await createRepositoryInCurrentDirectory(page, 'filename-test');

    // Navigate into folder
    await enterFolder(page, 'filename-test');

    // Create initial file and init git
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      const content = new TextEncoder().encode('initial');
      const { cid, size } = await tree.putFile(content);
      rootCid = await tree.setEntry(rootCid, route.path, 'test.txt', cid, size, LinkType.Blob);
      autosaveIfOwn(rootCid);
    });

    await waitForCurrentDirectoryEntries(page, ['test.txt']);
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'test.txt' })).toBeVisible({ timeout: 15000 });

    await ensureGitRepoInitialized(page);

    // Now add a file starting with 'a' (regression test for filename truncation bug)
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      // File starting with 'a' to test for truncation bug
      const content = new TextEncoder().encode('test content');
      const { cid, size } = await tree.putFile(content);
      rootCid = await tree.setEntry(rootCid, route.path, 'asdf.txt', cid, size, LinkType.Blob);
      autosaveIfOwn(rootCid);
    });

    await waitForCurrentDirectoryEntries(page, ['asdf.txt']);
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'asdf.txt' })).toBeVisible({ timeout: 15000 });

    // Wait for uncommitted indicator
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });
    await expect(uncommittedBtn).toBeVisible({ timeout: 30000 });

    // Open commit modal
    await uncommittedBtn.click();
    const commitModal = page.locator('.fixed.inset-0').filter({ hasText: 'Commit Changes' });
    await expect(commitModal).toBeVisible({ timeout: 5000 });

    // CRITICAL: Verify filename shows as "asdf.txt" not "sdf.txt" (truncated)
    // This is a regression test for a bug where the first character was being cut off
    await expect(commitModal.locator('text=asdf.txt')).toBeVisible({ timeout: 5000 });

    // Verify the actual filename in the entry
    const fileText = await commitModal.locator('button').filter({ hasText: /\.txt/ }).first().textContent();
    expect(fileText).toContain('asdf.txt');

    await page.keyboard.press('Escape');
  });

  test('git status shows changes count correctly', { timeout: 60000 }, async ({ page }) => {
    test.slow();
    await navigateToPublicFolder(page);

    // Create a folder and init as git repo
    await createRepositoryInCurrentDirectory(page, 'status-test-repo');

    // Navigate into folder
    await enterFolder(page, 'status-test-repo');

    // Create a file
    await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRouteSync } = await import('/src/stores/index.ts');
      const route = getRouteSync();

      const tree = getTree();
      let rootCid = getCurrentRootCid();
      if (!rootCid) return;

      const content = new TextEncoder().encode('# Status Test Repo');
      const { cid, size } = await tree.putFile(content);
      rootCid = await tree.setEntry(rootCid, route.path, 'README.md', cid, size, LinkType.Blob);
      autosaveIfOwn(rootCid);
    });

    // Wait for file and init git
    await waitForCurrentDirectoryEntries(page, ['README.md']);
    await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' })).toBeVisible({ timeout: 15000 });

    await ensureGitRepoInitialized(page);
    await expect(page.getByRole('button', { name: /commits/i })).toBeVisible({ timeout: 20000 });

    // Verify git features are working - commits button should show at least 1 commit
    const commitsBtn = page.getByRole('button', { name: /commits/i });
    await expect(commitsBtn).toContainText(/\d+/, { timeout: 10000 });

    // If there are uncommitted changes shown, clicking it should open the commit modal
    const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i });
    const hasUncommitted = await uncommittedBtn.isVisible().catch(() => false);

    if (hasUncommitted) {
      // Click to verify the commit modal opens and shows changes
      await uncommittedBtn.click();
      const commitModal = page.locator('.fixed.inset-0').filter({ hasText: 'Commit Changes' });
      await expect(commitModal).toBeVisible({ timeout: 5000 });

      // Should show file count in footer (new UI: "X of Y file(s) selected")
      await expect(commitModal.locator('text=/\\d+ of \\d+ file/')).toBeVisible({ timeout: 5000 });

      // Close modal
      await page.keyboard.press('Escape');
      await expect(commitModal).not.toBeVisible({ timeout: 5000 });
    }
  });

});
