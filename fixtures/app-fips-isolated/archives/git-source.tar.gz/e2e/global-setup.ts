import { installNativeFixtureEnvironment } from './native-binaries.js';

export default async function globalSetup(): Promise<void> {
  const { htree, gitRemoteHtree } = installNativeFixtureEnvironment();
  console.log(`[native fixture] ${htree}`);
  console.log(`[native fixture] ${gitRemoteHtree}`);
}
