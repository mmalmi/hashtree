import { test, expect } from './fixtures';
import {
  setupPageErrorHandler,
  gotoGitApp,
} from './test-utils.js';
import { ensureGitSession } from './git-history.helpers';

function installGitHistoryBeforeEach() {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });
}

test.describe('Git history features', () => {
  installGitHistoryBeforeEach();

  test('git history should return commits from uploaded git repo', async ({ page }) => {
    test.setTimeout(120000);
    page.setDefaultTimeout(60000);

    // Capture wasm-git debug logs
    const wasmGitLogs: string[] = [];
    page.on('console', msg => {
      const text = msg.text();
      if (text.includes('[wasm-git]')) {
        wasmGitLogs.push(text);
      }
    });

    await ensureGitSession(page);

    // Create a real git repo with commits using CLI
    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-history-test-'));

    try {
      // Initialize git repo and create commits
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      // Create first commit
      await fs.writeFile(path.join(tmpDir, 'README.md'), '# Test Repo\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Initial commit"', { cwd: tmpDir });

      // Create second commit
      await fs.writeFile(path.join(tmpDir, 'file.txt'), 'Hello World\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Add file.txt"', { cwd: tmpDir });

      // Read all files and directories from the git repo
      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            // Add the directory itself
            result.push({ type: 'dir', path: relativePath });
            // Recursively get contents
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const shouldIncludePath = (entryPath: string) => {
        if (!entryPath.startsWith('.git/')) return true;
        if (entryPath === '.git/HEAD' || entryPath === '.git/config' || entryPath === '.git/packed-refs') return true;
        if (entryPath.startsWith('.git/objects/')) return true;
        if (entryPath.startsWith('.git/refs/')) return true;
        return false;
      };

      const allEntries = (await getAllEntries(tmpDir)).filter((entry) => shouldIncludePath(entry.path));
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      // Upload and test getLog
      const result = await page.evaluate(async ({ files, dirs }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const tree = getTree();

        // Create root directory
        let { cid: rootCid } = await tree.putDirectory([]);

        // Collect all directory paths from both explicit dirs and parent dirs of files
        const dirPaths = new Set<string>(dirs);
        for (const dir of dirs) {
          const parts = dir.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        // Create directories (including empty ones)
        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          rootCid = await tree.setEntry(rootCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        // Add files
        let objectFilePath = '';
        let objectFileOriginalSize = 0;
        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          rootCid = await tree.setEntry(rootCid, parts, name, fileCid, size, LinkType.Blob);
          // Track first git object file for verification
          if (file.path.includes('.git/objects/') && !file.path.endsWith('/info') && !file.path.endsWith('/pack')) {
            if (!objectFilePath) {
              objectFilePath = file.path;
              objectFileOriginalSize = data.length;
            }
          }
        }

        // Verify round-trip of a git object file
        let verifyInfo = '';
        if (objectFilePath) {
          const result = await tree.resolvePath(rootCid, objectFilePath);
          if (result) {
            const readBack = await tree.readFile(result.cid);
            if (readBack) {
              verifyInfo = `Object file ${objectFilePath}: original=${objectFileOriginalSize} bytes, readBack=${readBack.length} bytes`;
              if (objectFileOriginalSize !== readBack.length) {
                verifyInfo += ` MISMATCH!`;
              }
            } else {
              verifyInfo = `Object file ${objectFilePath}: readFile returned null`;
            }
          } else {
            verifyInfo = `Object file ${objectFilePath}: resolvePath returned null`;
          }
        }

        // Test getLog
        const { getLog } = await import('/src/utils/git.ts');

        try {
          const result = await getLog(rootCid, { debug: true });
          const commits = result.commits;
          const debug = result.debug;
          return {
            success: true,
            commitCount: commits.length,
            commits: commits.map((c) => ({
              message: c.message?.trim() || '',
              author: c.author || ''
            })),
            error: null,
            debug,
            verifyInfo
          };
        } catch (err) {
          return {
            success: false,
            commitCount: 0,
            commits: [],
            error: err instanceof Error ? err.message : String(err),
            debug: []
          };
        }
      }, { files: allFiles, dirs: allDirs });

      // Verify we got commits
      console.log('Git history result:', JSON.stringify(result, null, 2));
      console.log('Wasm-git logs:', wasmGitLogs);
      expect(result.success).toBe(true);
      expect(result.error).toBeNull();
      expect(result.commitCount).toBeGreaterThanOrEqual(2);
      expect(result.commits.some((c: {message: string}) => c.message.includes('Initial commit'))).toBe(true);
      expect(result.commits.some((c: {message: string}) => c.message.includes('Add file.txt'))).toBe(true);

    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });

  test('packed git repos should load history and commit view without wasm fallback', async ({ page }) => {
    test.setTimeout(120000);
    page.setDefaultTimeout(60000);

    await ensureGitSession(page);

    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-packed-history-test-'));

    try {
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      await fs.writeFile(path.join(tmpDir, 'README.md'), '# Packed Repo\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Initial commit"', { cwd: tmpDir });

      await fs.mkdir(path.join(tmpDir, 'src'));
      await fs.writeFile(path.join(tmpDir, 'README.md'), '# Packed Repo\n\nupdated\n');
      await fs.writeFile(path.join(tmpDir, 'src', 'index.ts'), 'export const version = 1;\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Add src and update README"', { cwd: tmpDir });

      await fs.writeFile(path.join(tmpDir, 'src', 'index.ts'), 'export const version = 2;\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Update src/index.ts"', { cwd: tmpDir });

      execSync('git gc --aggressive --prune=now', { cwd: tmpDir });

      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            result.push({ type: 'dir', path: relativePath });
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const shouldIncludePath = (entryPath: string) => {
        if (!entryPath.startsWith('.git/')) return true;
        if (entryPath === '.git/HEAD' || entryPath === '.git/config' || entryPath === '.git/packed-refs') return true;
        if (entryPath.startsWith('.git/objects/')) return true;
        if (entryPath.startsWith('.git/refs/')) return true;
        return false;
      };

      const allEntries = (await getAllEntries(tmpDir)).filter((entry) => shouldIncludePath(entry.path));
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      const result = await page.evaluate(async ({ files, dirs }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const { getHead, getLog, getCommitViewData } = await import('/src/utils/git.ts');

        const tree = getTree();
        let { cid: rootCid } = await tree.putDirectory([]);

        const dirPaths = new Set<string>(dirs);
        for (const dir of dirs) {
          const parts = dir.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          rootCid = await tree.setEntry(rootCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          rootCid = await tree.setEntry(rootCid, parts, name, fileCid, size, LinkType.Blob);
        }

        const logResult = await getLog(rootCid, { depth: 10, debug: true });
        const commits = logResult.commits;
        const debug = logResult.debug;
        const head = await getHead(rootCid);
        const commitView = await getCommitViewData(rootCid, 'HEAD');

        return {
          commitCount: commits.length,
          commitMessages: commits.map((commit) => commit.message?.trim() || ''),
          debug,
          head,
          commitView: commitView ? {
            oid: commitView.commit.oid,
            message: commitView.commit.message.trim(),
            stats: commitView.stats,
            diffText: commitView.diffText,
          } : null,
        };
      }, { files: allFiles, dirs: allDirs });

      expect(result.debug).toContain('Using native git reader');
      expect(result.debug).not.toContain('Fast log empty with HEAD present, falling back to wasm-git slow path');
      expect(result.debug.some((line: string) => line.startsWith('Slow path found'))).toBe(false);
      expect(result.head).toMatch(/^[a-f0-9]{40}$/);
      expect(result.commitCount).toBe(3);
      expect(result.commitMessages).toContain('Initial commit');
      expect(result.commitMessages).toContain('Add src and update README');
      expect(result.commitMessages).toContain('Update src/index.ts');
      expect(result.commitView?.oid).toBe(result.head);
      expect(result.commitView?.message).toBe('Update src/index.ts');
      expect(result.commitView?.stats.files).toBe(1);
      expect(result.commitView?.diffText).toContain('src/index.ts');
      expect(result.commitView?.diffText).toContain('-export const version = 1;');
      expect(result.commitView?.diffText).toContain('+export const version = 2;');
    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });
});
