import { test, expect } from './fixtures';
import {
  setupPageErrorHandler,
  gotoGitApp,
  waitForAppReady,
} from './test-utils.js';
import { ensureGitSession } from './git-history.helpers';

function installGitHistoryBeforeEach() {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });
}

test.describe('Git history scroll and logging', () => {
  installGitHistoryBeforeEach();

  test('git history modal should infinite scroll to load more commits', { timeout: 120000 }, async ({ page }) => {
    test.slow(); // Creating 60 commits and uploading large repo takes time
    page.setDefaultTimeout(60000);

    await ensureGitSession(page);

    // Create a git repo with many commits (more than initial load of 50)
    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-infinite-scroll-test-'));

    try {
      // Initialize git repo
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      // Create 60 commits (more than initial load of 50)
      for (let i = 1; i <= 60; i++) {
        await fs.writeFile(path.join(tmpDir, `file${i}.txt`), `Content ${i}\n`);
        execSync('git add .', { cwd: tmpDir });
        execSync(`git commit -m "Commit ${i}"`, { cwd: tmpDir });
      }

      // Read all files
      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            result.push({ type: 'dir', path: relativePath });
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const allEntries = await getAllEntries(tmpDir);
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      // Upload repo to hashtree as a top-level git tree
      const ownerNpub = await page.evaluate(() => {
        const store = (window as NostrStoreWindow).__nostrStore;
        return store?.getState?.().npub ?? null;
      });
      expect(ownerNpub).toBeTruthy();
      const rootCidHex = await page.evaluate(async ({ files, dirs, repoName }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const { saveHashtree } = await import('/src/nostr/index.ts');

        const tree = getTree();

        // Create the git repo directory
        let repoCid = (await tree.putDirectory([])).cid;

        // Create directories
        const dirPaths = new Set<string>(dirs);
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const { cid: emptyDir } = await tree.putDirectory([]);
          repoCid = await tree.setEntry(repoCid, parts, name, emptyDir, 0, LinkType.Dir);
        }

        // Add files
        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const data = new Uint8Array(file.content);
          const { cid: fileCid, size } = await tree.putFile(data);
          repoCid = await tree.setEntry(repoCid, parts, name, fileCid, size, LinkType.Blob);
        }

        await saveHashtree(repoName, repoCid, { visibility: 'public', labels: ['git'] });

        // Return repoCid hash for verification
        return Array.from(repoCid.hash).map(b => b.toString(16).padStart(2, '0')).join('');
      }, { files: allFiles, dirs: allDirs, repoName: 'infinite-scroll-repo' });

      expect(rootCidHex).not.toBeNull();

      await page.evaluate(({ npub, repoName }) => {
        window.location.hash = `#/${npub}/${repoName}`;
      }, { npub: ownerNpub, repoName: 'infinite-scroll-repo' });
      await page.waitForURL(/infinite-scroll-repo/, { timeout: 15000 });
      await waitForAppReady(page, 30000);

      // Click the commits button to open the git history modal
      const commitsButton = page.locator('button:has-text("commits"), button:has(.i-lucide-history)').first();
      await expect(commitsButton).toBeVisible({ timeout: 15000 });
      await commitsButton.click();

      // Wait for the modal to appear
      const modal = page.locator('[data-testid="git-history-modal"]');
      await expect(modal).toBeVisible({ timeout: 10000 });

      // Wait for initial commits to load
      await page.waitForFunction(() => {
        // Or count commit items by looking for commit hashes (7 char hex)
        const commitItems = document.querySelectorAll('[data-testid="git-history-modal"] .font-mono');
        return commitItems.length > 0;
      }, undefined, { timeout: 15000 });

      // The staged loader should show some commits quickly, then finish the first page.
      const initialCount = await page.evaluate(() => {
        // Count timeline dots which represent commits
        const dots = document.querySelectorAll('[data-testid="git-history-modal"] .rounded-full.bg-accent, [data-testid="git-history-modal"] .rounded-full.bg-success');
        return dots.length;
      });

      expect(initialCount).toBeGreaterThan(0);
      expect(initialCount).toBeLessThanOrEqual(50);

      await page.waitForFunction(() => {
        const dots = document.querySelectorAll('[data-testid="git-history-modal"] .rounded-full.bg-accent, [data-testid="git-history-modal"] .rounded-full.bg-success');
        return dots.length === 50;
      }, undefined, { timeout: 15000 });

      // Scroll to the bottom of the modal content
      const scrollContainer = modal.locator('.overflow-auto');
      await scrollContainer.evaluate((el) => {
        el.scrollTo({ top: el.scrollHeight, behavior: 'instant' });
      });

      // Wait for more commits to load automatically (infinite scroll behavior)
      // This should trigger without clicking a "Load more" button
      await page.waitForFunction(() => {
        const dots = document.querySelectorAll('[data-testid="git-history-modal"] .rounded-full.bg-accent, [data-testid="git-history-modal"] .rounded-full.bg-success');
        return dots.length > 50;
      }, undefined, { timeout: 15000 });

      // Verify we now have all 60 commits loaded
      const finalCount = await page.evaluate(() => {
        const dots = document.querySelectorAll('[data-testid="git-history-modal"] .rounded-full.bg-accent, [data-testid="git-history-modal"] .rounded-full.bg-success');
        return dots.length;
      });

      expect(finalCount).toBe(60);

      // Verify the "Load more" button is NOT visible (we're using infinite scroll, not button)
      const loadMoreButton = modal.locator('button:has-text("Load more")');
      await expect(loadMoreButton).not.toBeVisible();

    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });

  test('wasm-git should not spam console with git output', { timeout: 120000 }, async ({ page }) => {
    test.setTimeout(120000);
    page.setDefaultTimeout(60000);
    // Capture ALL console messages to check for git output spam
    const consoleLogs: string[] = [];
    page.on('console', msg => {
      consoleLogs.push(msg.text());
    });

    await ensureGitSession(page);

    // Create a real git repo with commits
    const fs = await import('fs/promises');
    const path = await import('path');
    const { execSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-spam-test-'));

    try {
      // Initialize git repo and create commits
      execSync('git init', { cwd: tmpDir });
      execSync('git config user.email "test@example.com"', { cwd: tmpDir });
      execSync('git config user.name "Test User"', { cwd: tmpDir });

      await fs.writeFile(path.join(tmpDir, 'README.md'), '# Test\n');
      execSync('git add .', { cwd: tmpDir });
      execSync('git commit -m "Initial commit"', { cwd: tmpDir });

      // Read git repo files
      interface FileEntry { type: 'file'; path: string; content: number[]; }
      interface DirEntry { type: 'dir'; path: string; }
      type Entry = FileEntry | DirEntry;

      const getAllEntries = async (dir: string, base = ''): Promise<Entry[]> => {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const result: Entry[] = [];
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            result.push({ type: 'dir', path: relativePath });
            result.push(...await getAllEntries(fullPath, relativePath));
          } else {
            const content = await fs.readFile(fullPath);
            result.push({ type: 'file', path: relativePath, content: Array.from(content) });
          }
        }
        return result;
      };

      const allEntries = await getAllEntries(tmpDir);
      const allFiles = allEntries.filter((e): e is FileEntry => e.type === 'file');
      const allDirs = allEntries.filter((e): e is DirEntry => e.type === 'dir').map(d => d.path);

      // Call git operations that would previously spam the console
      await page.evaluate(async ({ files, dirs }) => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const tree = getTree();

        let { cid: rootCid } = await tree.putDirectory([]);

        const dirPaths = new Set<string>(dirs);
        for (const file of files) {
          const parts = file.path.split('/');
          for (let i = 1; i < parts.length; i++) {
            dirPaths.add(parts.slice(0, i).join('/'));
          }
        }
        const sortedDirs = Array.from(dirPaths).sort((a, b) =>
          a.split('/').length - b.split('/').length
        );

        for (const dir of sortedDirs) {
          const parts = dir.split('/');
          const name = parts.pop()!;
          const parentPath = parts;
          const { cid: emptyCid } = await tree.putDirectory([]);
          rootCid = await tree.setEntry(rootCid, parentPath, name, emptyCid, 0, LinkType.Dir);
        }

        for (const file of files) {
          const parts = file.path.split('/');
          const name = parts.pop()!;
          const parentPath = parts;
          const content = new Uint8Array(file.content);
          const { cid: fileCid } = await tree.putFile(content);
          rootCid = await tree.setEntry(rootCid, parentPath, name, fileCid, content.length, LinkType.Blob);
        }

        // Call getLog which uses wasm-git
        const { getLog, getHead } = await import('/src/utils/git.ts');
        const head = await getHead(rootCid);
        const commits = await getLog(rootCid, { depth: 10 });

        return { head, commitCount: commits.length };
      }, { files: allFiles, dirs: allDirs });

      // Check console logs for git command output spam
      // Git output typically contains "commit", "Author:", "Date:" lines
      const gitOutputSpam = consoleLogs.filter(log =>
        // Match typical git log/status output patterns that shouldn't appear
        (log.includes('Author:') && log.includes('<') && log.includes('>')) ||
        (log.match(/^commit [a-f0-9]{40}$/)) ||
        (log.startsWith('Date:') && log.includes('20')) ||
        (log.includes('Initialized empty Git repository')) ||
        (log.match(/^\s+\w.*commit/i) && !log.includes('['))  // Commit message lines (indented)
      );

      // Should not have any git output spam
      if (gitOutputSpam.length > 0) {
        console.log('Found git output spam:', gitOutputSpam);
      }
      expect(gitOutputSpam.length).toBe(0);

    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });
});
