import { test, expect } from './fixtures';
import { waitForAppReady, ensureLoggedIn, useLocalRelay, presetProductionRelaysInDB, gotoGitApp, safeGoto, createRepositoryInCurrentDirectory } from './test-utils';

const PROD_REPO_URL = '/git.html#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/hashtree';

function shouldUseProductionRelays(): boolean {
  return process.env.E2E_PRODUCTION_RELAYS === '1';
}

async function expectRepoLoaded(page: import('@playwright/test').Page): Promise<void> {
  const repoColumn = page.getByTestId('repo-main-column');
  await expect(page.getByTestId('repo-header-row')).toBeVisible({ timeout: 90000 });
  await expect(repoColumn.locator('table').first()).toBeVisible({ timeout: 90000 });
  await expect(repoColumn.getByRole('link', { name: /^(docs|rust|ts)$/ }).first()).toBeVisible({ timeout: 90000 });

  const commitLink = page.getByTestId('file-list').locator('a[href*="?commit="]').first();
  await expect(commitLink).toBeVisible({ timeout: 60000 });
  await expect(page.getByText('No commits yet')).not.toBeVisible({ timeout: 5000 });
}

async function createLocalGitRepo(page: import('@playwright/test').Page): Promise<{
  npub: string;
  treeUrl: string;
  repoName: string;
}> {
  await ensureLoggedIn(page);
  await useLocalRelay(page);

  const npub = await page.evaluate(() => (window as any).__nostrStore?.getState?.()?.npub || '');
  const repoName = `tree-loading-${Date.now()}`;
  await createRepositoryInCurrentDirectory(page, repoName, 30000);
  await page.waitForURL(new RegExp(`/git\\.html#/${npub}/${encodeURIComponent(repoName)}`), { timeout: 30000 });
  return {
    npub,
    treeUrl: `/git.html#/${npub}/${repoName}`,
    repoName,
  };
}

async function expectLocalRepoResolved(
  page: import('@playwright/test').Page,
  npub: string,
  repoName: string,
): Promise<void> {
  await page.waitForFunction(
    async ({ pub, repositoryName }) => {
      const { useCurrentDirCid, getRouteSync } = await import('/src/stores/index.ts');
      const { getTreeRootSync } = await import('/src/stores/treeRoot.ts');
      const { getRootCommit, isGitRepo } = await import('/src/utils/git.ts');
      const route = getRouteSync();
      const dirCid = useCurrentDirCid();
      if (route.npub !== pub || route.treeName !== repositoryName || route.path.length !== 0) {
        return false;
      }
      if (!getTreeRootSync(pub, repositoryName) || !dirCid || !(await isGitRepo(dirCid))) {
        return false;
      }
      return !!(await getRootCommit(dirCid));
    },
    { pub: npub, repositoryName: repoName },
    { timeout: 30000, polling: 500 }
  );
}

/**
 * Test tree loading with production relays.
 * Run with: pnpm exec playwright test e2e/tree-loading.spec.ts --config=playwright.production.config.ts
 */
test('measure tree loading time', async ({ page }) => {
  test.setTimeout(120000);
  const gitAppPrefix = '/git.html';

  await gotoGitApp(page);
  if (shouldUseProductionRelays()) {
    await presetProductionRelaysInDB(page);
    await page.reload();
    await waitForAppReady(page);
    const startTime = Date.now();
    await safeGoto(page, PROD_REPO_URL);

    await expectRepoLoaded(page);

    const loadTime = Date.now() - startTime;
    console.log(`\n\nTree loading time: ${loadTime}ms\n\n`);

    await page.screenshot({ path: '/tmp/tree-loaded.png', fullPage: true });

    expect(loadTime).toBeLessThan(120000);
    return;
  }

  const { npub, treeUrl, repoName } = await createLocalGitRepo(page);
  await safeGoto(page, `${gitAppPrefix}#/`);
  const startTime = Date.now();
  await safeGoto(page, treeUrl);
  await expectLocalRepoResolved(page, npub, repoName);

  const loadTime = Date.now() - startTime;
  console.log(`\n\nTree loading time (test mode): ${loadTime}ms\n\n`);

  await page.screenshot({ path: '/tmp/tree-loaded.png', fullPage: true });

  expect(loadTime).toBeLessThan(15000);
});

test('direct nav loads repo on first page load', async ({ page }) => {
  test.setTimeout(120000);
  await gotoGitApp(page);
  if (shouldUseProductionRelays()) {
    await presetProductionRelaysInDB(page);
    await page.reload();
    await waitForAppReady(page);

    await safeGoto(page, PROD_REPO_URL);
    await waitForAppReady(page);

    await expectRepoLoaded(page);
    return;
  }

  const { npub, treeUrl, repoName } = await createLocalGitRepo(page);
  await safeGoto(page, '/git.html#/');
  await safeGoto(page, treeUrl);
  await waitForAppReady(page);
  await expectLocalRepoResolved(page, npub, repoName);
});
