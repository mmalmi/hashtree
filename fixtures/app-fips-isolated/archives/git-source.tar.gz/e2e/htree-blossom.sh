#!/usr/bin/env bash
set -euo pipefail

ADDR="${HTREE_ADDR:-127.0.0.1:18780}"
CONFIG_DIR="${HTREE_CONFIG_DIR:-/tmp/htree-e2e-blossom}"
DATA_DIR="${HTREE_DATA_DIR:-/tmp/htree-e2e-blossom-data}"

mkdir -p "${CONFIG_DIR}" "${DATA_DIR}"

cat > "${CONFIG_DIR}/config.toml" <<EOF
[server]
bind_address = "${ADDR}"
enable_auth = false
public_writes = true
enable_webrtc = false
stun_port = 0

[storage]
data_dir = "${DATA_DIR}"
max_size_gb = 1

[nostr]
relays = []
allowed_npubs = []
crawl_depth = 0
db_max_size_gb = 1
spambox_max_size_gb = 0

[blossom]
servers = []
read_servers = []
write_servers = []
max_upload_mb = 50

[sync]
enabled = false
EOF

export HTREE_CONFIG_DIR="${CONFIG_DIR}"

HTREE_BIN="${HTREE_BIN:-$(command -v htree || true)}"
EXPECTED_HTREE_VERSION="0.2.142"
if [[ -z "${HTREE_BIN}" || ! -x "${HTREE_BIN}" ]]; then
  echo "Set HTREE_BIN or install htree ${EXPECTED_HTREE_VERSION} on PATH." >&2
  exit 1
fi
if [[ "$("${HTREE_BIN}" --version)" != "htree ${EXPECTED_HTREE_VERSION}" ]]; then
  echo "Iris Git process gates require htree ${EXPECTED_HTREE_VERSION}." >&2
  exit 1
fi

exec "${HTREE_BIN}" start --addr "${ADDR}"
