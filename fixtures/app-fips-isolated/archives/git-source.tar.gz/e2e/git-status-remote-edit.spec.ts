import { test, expect } from './fixtures';
import { setupPageErrorHandler, waitForAppReady, configureBlossomServers, useLocalRelay, waitForRelayConnected, gotoGitApp, evaluateWithRetry } from './test-utils.js';
import { execSync } from 'child_process';
import { nip19 } from 'nostr-tools';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { ensureGitRemoteHtree, resolveNpubFromKeysFile, waitForTreeEvent } from './git-status-edit.helpers';


test.describe('Git remote status after file edit', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });

  // This test verifies that repos pushed via git-remote-htree have a valid index file
  // and git status works when viewing from the browser via nostr.
  test('should show uncommitted in git-remote-htree pushed repo after edit', { timeout: 180000 }, async ({ page }) => {
    test.setTimeout(240000);
    const gitRemoteHtree = ensureGitRemoteHtree();

    // Capture browser console logs for debugging wasm-git
    const consoleLogs: string[] = [];
    page.on('console', msg => {
      const text = msg.text();
      // Capture wasm-git and git status related logs
      if (text.includes('[wasm-git]') || text.includes('[git]') || text.includes('wasm-git') ||
          text.includes('hasChanges') || text.includes('Index file')) {
        consoleLogs.push(text);
        console.log('[browser]', text);
      }
    });

    // Create temp directory for the test
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'git-status-htree-'));
    const testRepoDir = path.join(tempDir, 'test-repo');
    const configDir = path.join(tempDir, '.hashtree');
    const dataDir = path.join(tempDir, 'data');
    fs.mkdirSync(testRepoDir);
    fs.mkdirSync(configDir, { recursive: true });
    fs.mkdirSync(dataDir, { recursive: true });

    await waitForAppReady(page);
    await page.evaluate(async () => {
      const { waitForSettingsLoaded } = await import('/src/stores/settings');
      await waitForSettingsLoaded();
    });
    await useLocalRelay(page);
    await waitForRelayConnected(page, 30000);
    await configureBlossomServers(page);
    const relayUrls = await page.evaluate(async () => {
      const { settingsStore } = await import('/src/stores/settings');
      return settingsStore.getState().network.relays;
    });
    const blossomUrls = await page.evaluate(async () => {
      const { settingsStore } = await import('/src/stores/settings');
      return settingsStore.getState().network.blossomServers.map(s => s.url);
    });
    if (!relayUrls.length) {
      throw new Error('No relays configured for test');
    }
    if (!blossomUrls.length) {
      throw new Error('No blossom servers configured for test');
    }

    const env = {
      ...process.env,
      HOME: tempDir,
      PATH: `${path.dirname(gitRemoteHtree)}:${process.env.PATH}`,
      HTREE_CONFIG_DIR: configDir,
      HTREE_DATA_DIR: dataDir,
      NOSTR_RELAYS: relayUrls.join(','),
      NOSTR_PREFER_LOCAL: '0',
      HTREE_PREFER_LOCAL_RELAY: '0',
      HTREE_PREFER_LOCAL_DAEMON: '0',
    };

    // Create .hashtree config pointing to real relays/blossoms
    const relaysToml = relayUrls.map(url => `"${url}"`).join(', ');
    const blossomToml = blossomUrls.map(url => `"${url}"`).join(', ');
    fs.writeFileSync(path.join(configDir, 'config.toml'), `
[server]
enable_auth = false
enable_webrtc = false
stun_port = 0

[nostr]
relays = [${relaysToml}]
crawl_depth = 0

[blossom]
read_servers = [${blossomToml}]
write_servers = [${blossomToml}]
max_upload_mb = 50

[sync]
enabled = false
`);

    try {
      // Create test repo with unique name to avoid conflicts
      const repoName = `test-${Date.now()}`;
      console.log('[test] Creating test repo:', repoName);
      execSync('git init -b master', { cwd: testRepoDir, env });
      execSync('git config user.email "test@test.com"', { cwd: testRepoDir, env });
      execSync('git config user.name "Test User"', { cwd: testRepoDir, env });

      // Add test files
      fs.writeFileSync(path.join(testRepoDir, 'README.md'), '# Test Repo\n\nOriginal content.');
      fs.writeFileSync(path.join(testRepoDir, 'hello.txt'), 'Hello, World!');

      execSync('git add -A', { cwd: testRepoDir, env });
      execSync('git commit -m "Initial commit"', { cwd: testRepoDir, env });

      // Add htree remote using "self" - this auto-generates keys locally
      console.log('[test] Adding htree://self remote...');
      execSync(`git remote add htree htree://self/${repoName}`, { cwd: testRepoDir, env });

      // Push to htree - this publishes to nostr relays and blossom
      console.log('[test] Pushing to htree://self...');
      const pushOutput = execSync('git push htree HEAD:master 2>&1', {
        cwd: testRepoDir,
        env,
        encoding: 'utf-8',
        timeout: 120000,
      });
      console.log('[test] Push output:', pushOutput);

      // Extract npub from push output
      const npubMatch = pushOutput.match(/npub1[a-z0-9]{58}/);
      const keysPath = path.join(tempDir, '.hashtree', 'keys');
      const npub = npubMatch?.[0] || resolveNpubFromKeysFile(keysPath);
      if (!npub) {
        throw new Error('Could not resolve npub from push output or keys file');
      }
      console.log('[test] Published to npub:', npub);

      const decoded = nip19.decode(npub);
      if (decoded.type !== 'npub') {
        throw new Error('Could not decode npub for relay lookup');
      }
      const ownerPubkey = decoded.data as string;

      const relayUrl = relayUrls[0];
      if (!relayUrl) {
        throw new Error('No relay URL available for tree lookup');
      }

      console.log('[test] Waiting for tree event to appear on relay...');
      let treeEvent = await waitForTreeEvent(relayUrl, ownerPubkey, repoName, 60000);
      if (!treeEvent) {
        console.log('[test] Tree event not found yet, retrying...');
        treeEvent = await waitForTreeEvent(relayUrl, ownerPubkey, repoName, 60000);
      }
      if (!treeEvent) {
        throw new Error('Tree event not found on relay after publish');
      }
      const { hashHex, keyHex } = treeEvent;
      console.log('[test] Tree event ready:', {
        hashPrefix: hashHex.slice(0, 12),
        hasKey: !!keyHex,
      });

      // Navigate directly to the pushed repo URL
      // This is the REAL flow - browser fetches from nostr/blossom
      const repoUrl = `/git.html#/${npub}/${repoName}`;
      console.log('[test] Navigating to:', repoUrl);

      await page.waitForFunction(
        () => (window as any).__nostrStore?.getState?.().connectedRelays > 0,
        undefined,
        { timeout: 30000 }
      );

      // Navigate directly to the repo tree with retry mechanism
      // Nostr events may take time to propagate to relays
      console.log('[test] Navigating to tree:', repoUrl);

      let treeLoaded = false;
      const sidebarReadme = page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' });

      const resolveTreeRoot = async () => page.evaluate(async ({ ownerNpub, treeName }) => {
        const { waitForTreeRoot } = await import('/src/stores/treeRoot.ts');
        const root = await waitForTreeRoot(ownerNpub, treeName, 120000);
        return !!root;
      }, { ownerNpub: npub, treeName: repoName });

      await page.goto(repoUrl, { waitUntil: 'domcontentloaded' });
      await waitForAppReady(page, 60000);
      await configureBlossomServers(page);
      await waitForRelayConnected(page, 30000);
      await evaluateWithRetry(page, async ({ ownerNpub, treeName, hashHex: hashHexArg, keyHex: keyHexArg }) => {
        const { updateSubscriptionCache } = await import('/src/stores/treeRoot.ts');
        const fromHex = (hex: string) => {
          const bytes = new Uint8Array(hex.length / 2);
          for (let i = 0; i < bytes.length; i++) {
            bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
          }
          return bytes;
        };
        updateSubscriptionCache(
          `${ownerNpub}/${treeName}`,
          fromHex(hashHexArg),
          keyHexArg ? fromHex(keyHexArg) : undefined
        );
      }, { ownerNpub: npub, treeName: repoName, hashHex, keyHex });

      let resolved = await resolveTreeRoot();
      if (!resolved) {
        console.log('[test] Resolver not ready - retrying after reload...');
        await page.reload({ waitUntil: 'domcontentloaded' });
        await waitForAppReady(page, 60000);
        await configureBlossomServers(page);
        await waitForRelayConnected(page, 30000);
        resolved = await resolveTreeRoot();
      }

      if (resolved) {
        await expect(sidebarReadme).toBeVisible({ timeout: 20000 });
        treeLoaded = true;
        console.log('[test] Tree loaded via resolver');
      }

      if (!treeLoaded) {
        // Take screenshot for debugging
        await page.screenshot({ path: 'e2e/screenshots/git-status-htree-failed.png' }).catch(() => {});
        throw new Error('Tree failed to load from relays');
      }

      console.log('[test] README.md visible in sidebar - repo loaded from network');

      // Wait for .git directory in sidebar
      const sidebarGit = page.locator('[data-testid="file-list"] a').filter({ hasText: '.git' });
      await expect(sidebarGit).toBeVisible({ timeout: 10000 });
      console.log('[test] .git directory visible in sidebar');

      // Log current URL
      console.log('[test] Current URL:', page.url());

      // Take screenshot to see the state
      await page.screenshot({ path: 'e2e/screenshots/git-status-htree-in-repo.png' });

      // Wait for the directory toolbar to appear - look for the Commits button (git repo)
      // The Commits button appears when git repo is detected
      const commitsBtn = page.getByRole('button', { name: /commits/i });
      // Network-loaded repos can take longer to hydrate git metadata under full-suite CPU load.
      await expect(commitsBtn).toBeVisible({ timeout: 120000 });
      console.log('[test] Git repo detected - Commits button visible');

      // Take screenshot
      await page.screenshot({ path: 'e2e/screenshots/git-status-htree-toolbar.png' });

      // Take screenshot to see what status is showing
      await page.screenshot({ path: 'e2e/screenshots/git-status-htree-initial.png' });

      // Log browser console for debugging
      console.log('[test] Browser console logs:');
      for (const log of consoleLogs) {
        console.log('  ', log);
      }

      // Verify git status is working by checking the console output
      // The wasm-git output should show hasChanges: false for a freshly pushed repo
      const hasCleanStatus = consoleLogs.some(log =>
        log.includes('hasChanges: false') || log.includes('git status output: ""')
      );

      if (!hasCleanStatus) {
        console.log('[test] WARNING: Could not verify clean status from console logs');
        // This is not a failure - the status may still be loading
      } else {
        console.log('[test] SUCCESS: Git status shows clean (hasChanges: false)');
      }

      // Verify that the index file was found (not the "No .git/index found" warning)
      const hasIndex = consoleLogs.some(log => log.includes('Index file size:'));
      const noIndexWarning = consoleLogs.some(log => log.includes('No .git/index found'));

      if (noIndexWarning) {
        throw new Error('FAIL: No index file found - git-remote-htree should generate index during push');
      }

      if (hasIndex) {
        console.log('[test] SUCCESS: Index file exists - git-remote-htree correctly generated it');
      }

      // The key assertion: verify no uncommitted changes are detected initially
      // This validates that the index file is working correctly
      const hasUncommittedChanges = consoleLogs.some(log =>
        log.includes('hasChanges: true') ||
        (log.includes('getStatus result:') && !log.includes('hasChanges: false'))
      );

      if (hasUncommittedChanges) {
        throw new Error('FAIL: Uncommitted changes detected in freshly pushed repo - index file may be corrupt');
      }

      console.log('[test] SUCCESS: git-remote-htree pushed repo shows correct git status (clean)');

      // ==== PART 2: Fork the repo and verify index is preserved ====
      console.log('[test] Forking the htree pushed repo...');

      // Click Fork button
      const forkBtn = page.locator('button[title="Fork as new top-level folder"]:visible').first();
      await expect(forkBtn).toBeVisible({ timeout: 10000 });
      await forkBtn.click();

      // Wait for fork modal
      const forkModal = page.locator('.fixed.inset-0').filter({ hasText: 'Fork as New Folder' });
      await expect(forkModal).toBeVisible({ timeout: 5000 });

      // Enter name for forked repo
      const forkNameInput = forkModal.locator('input');
      const forkedRepoName = `forked-${repoName}`;
      await forkNameInput.fill(forkedRepoName);

      // Click Fork button in modal
      const confirmForkBtn = forkModal.getByRole('button', { name: /fork/i }).last();
      await confirmForkBtn.click();

      // Wait for navigation to forked repo
      await page.waitForURL(new RegExp(forkedRepoName), { timeout: 15000 });
      console.log(`[test] Forked to ${forkedRepoName}`);

      // Wait for forked repo to load
      const forkedReadme = page.locator('[data-testid="file-list"] a').filter({ hasText: 'README.md' });
      await expect(forkedReadme).toBeVisible({ timeout: 15000 });
      const forkedGit = page.locator('[data-testid="file-list"] a').filter({ hasText: '.git' });
      await expect(forkedGit).toBeVisible({ timeout: 5000 });
      console.log('[test] Forked repo loaded with files');

      // Verify git status shows clean in forked repo
      const forkedCleanIndicator = page.locator('text=clean');
      await expect(forkedCleanIndicator).toBeVisible({ timeout: 30000 });
      console.log('[test] Forked repo: Git status shows clean (index copied correctly)');

      // Clear console logs for edit detection
      consoleLogs.length = 0;

      // ==== PART 3: Edit a file and verify uncommitted shows ====
      console.log('[test] Editing README.md in forked htree repo...');
      await page.evaluate(async () => {
        const { getTree, LinkType } = await import('/src/store.ts');
        const { autosaveIfOwn } = await import('/src/nostr/index.ts');
        const { getCurrentRootCid } = await import('/src/actions/route.ts');
        const { getRouteSync } = await import('/src/stores/index.ts');
        const route = getRouteSync();

        const tree = getTree();
        let rootCid = getCurrentRootCid();
        if (!rootCid) return;

        // Modify README.md with new content
        const updatedContent = new TextEncoder().encode('# Test Repo\n\nModified content in forked htree repo!');
        const { cid: updatedCid, size: updatedSize } = await tree.putFile(updatedContent);
        rootCid = await tree.setEntry(rootCid, route.path, 'README.md', updatedCid, updatedSize, LinkType.Blob);

        autosaveIfOwn(rootCid);
      });

      // Wait for the uncommitted changes indicator to appear
      console.log('[test] Waiting for uncommitted indicator in forked htree repo...');
      const uncommittedBtn = page.locator('button').filter({ hasText: /uncommitted/i }).first();

      // Take screenshot for debugging
      await page.screenshot({ path: 'e2e/screenshots/git-status-htree-forked-edit.png' });

      // Log console output for debugging
      console.log('[test] Console logs after edit:');
      for (const log of consoleLogs) {
        console.log('  ', log);
      }

      await expect(uncommittedBtn).toBeVisible({ timeout: 60000 });
      console.log('[test] SUCCESS: uncommitted indicator visible after editing forked htree repo');

      // Verify the count shows 1 change
      await expect.poll(
        async () => (await uncommittedBtn.textContent())?.replace(/\s+/g, ' ').trim() ?? '',
        { timeout: 60000, intervals: [1000, 2000] }
      ).toMatch(/1\s+uncommitted/i);
      console.log('[test] SUCCESS: uncommitted count shows 1 change');

    } finally {
      // Cleanup
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch {
        // Ignore cleanup errors
      }
    }
  });
});
