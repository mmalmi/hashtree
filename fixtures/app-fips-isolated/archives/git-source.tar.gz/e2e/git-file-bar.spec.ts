import { test, expect } from './fixtures';
import { setupPageErrorHandler, waitForAppReady, gotoGitApp } from './test-utils.js';
import {
  DIRECTORY_ACTIONS_ADD_FILES_SELECTOR,
  GENERIC_SIDEBAR_SELECTOR,
  README_NAME,
  SUBDIR_NAME,
  SUBFILE_NAME,
  installFlashTracker,
  installRepoEmptyDirectoryFlashTracker,
  installRepoHeaderMismatchTracker,
  installSidebarFlashTracker,
  uploadGitRepo,
} from './git-file-bar.helpers';

test.describe('Git file bar', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
    await waitForAppReady(page);
  });

  test('repo pages constrain the main column and keep file-view git path context', async ({ page }) => {
    test.slow();

    await page.setViewportSize({ width: 1800, height: 900 });

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const repoColumn = page.getByTestId('repo-main-column');
    await expect(repoColumn).toBeVisible({ timeout: 30000 });
    const repoColumnBox = await repoColumn.boundingBox();
    expect(repoColumnBox?.width ?? 0).toBeLessThanOrEqual(1290);

    const repoProjectSidebar = page.getByTestId('repo-project-sidebar');
    await expect(repoProjectSidebar).toContainText('Temporary repository for git view tests.');
    await expect(repoProjectSidebar.getByRole('link', { name: 'example.com/git-file-bar' })).toBeVisible({ timeout: 30000 });

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();
    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );

    await expect(page.getByTestId('repo-header-path')).toContainText(`${repoName} / ${SUBDIR_NAME}`);

    const fileCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBFILE_NAME }).first();
    await expect(fileCell).toBeVisible({ timeout: 30000 });
    await fileCell.click();
    await page.waitForFunction(
      (name) => window.location.hash.includes(encodeURIComponent(name)),
      SUBFILE_NAME,
      { timeout: 15000 }
    );

    await expect(page.getByTestId('viewer-context')).toHaveText(`${repoName} / ${SUBDIR_NAME} / ${SUBFILE_NAME}`);

    const sidebarFileBrowser = page.locator(GENERIC_SIDEBAR_SELECTOR);
    await expect(sidebarFileBrowser).toHaveCount(1);

    const fileColumn = page.getByTestId('repo-file-column');
    await expect(fileColumn).toBeVisible({ timeout: 30000 });
    const fileColumnBox = await fileColumn.boundingBox();
    expect(fileColumnBox?.width ?? 0).toBeGreaterThan(1290);
  });

  test('repo header shows the current subdirectory path without horizontal overflow on mobile', async ({ page }) => {
    test.slow();

    await page.setViewportSize({ width: 390, height: 844 });

    const repoName = `git-header-wrap-long-repo-name-${Date.now()}`;
    const { npub } = await uploadGitRepo(page, repoName);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();
    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );

    const repoHeaderPath = page.getByTestId('repo-header-path');
    await expect(repoHeaderPath).toContainText(`${repoName} / ${SUBDIR_NAME}`);

    const wrapsWithoutOverflow = await repoHeaderPath.evaluate((element) => {
      return element.scrollWidth <= element.clientWidth + 1;
    });
    expect(wrapsWithoutOverflow).toBe(true);
  });

  test('repo header does not switch to the target subdir before the directory listing catches up', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);
    const targetHeaderText = `${repoName} / ${SUBDIR_NAME}`;

    await installRepoHeaderMismatchTracker(page, targetHeaderText, [README_NAME, SUBDIR_NAME]);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();

    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );
    await expect(page.getByTestId('repo-header-path')).toContainText(targetHeaderText);
    await expect(repoFileList.locator('tbody')).toContainText(SUBFILE_NAME, { timeout: 30000 });

    const mismatch = await page.evaluate(() => {
      const trackerWindow = window as Window & {
        __repoHeaderMismatchTracker?: { mismatchDetected: boolean; samples: Array<{ headerText: string; fileListText: string }> };
      };
      return trackerWindow.__repoHeaderMismatchTracker ?? { mismatchDetected: false, samples: [] };
    });

    expect(mismatch.mismatchDetected, JSON.stringify(mismatch.samples, null, 2)).toBe(false);
  });

  test('shows commit info when viewing a file in git repo', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}/${README_NAME}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const gitBar = page.locator('[data-testid="git-file-bar"]');
    await expect(gitBar).toBeVisible({ timeout: 60000 });
    await expect(gitBar.locator('button[title*="history" i]')).toBeVisible({ timeout: 60000 });
    await expect(gitBar.getByText(/\d+\s+(second|minute|hour|day|week|month|year)s?\s+ago/i)).toBeVisible();
  });

  test('keeps the file browser sidebar off repo pages but shows it on git file pages', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const sidebarFileBrowser = page.locator(GENERIC_SIDEBAR_SELECTOR);
    await expect(sidebarFileBrowser).toHaveCount(0);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const readmeCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: README_NAME }).first();
    await expect(readmeCell).toBeVisible({ timeout: 30000 });
    await readmeCell.click();
    await page.waitForFunction(
      (name) => window.location.hash.includes(encodeURIComponent(name)),
      README_NAME,
      { timeout: 15000 }
    );

    await expect(sidebarFileBrowser).toHaveCount(1);
    await expect(page.locator('[data-testid="viewer-header"]')).toBeVisible({ timeout: 30000 });
  });

  test('markdown fullscreen hides the git file tree and restores it on exit', async ({ page }) => {
    test.slow();

    await page.setViewportSize({ width: 1440, height: 900 });

    const { repoName, npub } = await uploadGitRepo(page);
    await page.goto(`/git.html#/${npub}/public/${repoName}/${README_NAME}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const sidebarFileBrowser = page.locator(GENERIC_SIDEBAR_SELECTOR);
    const fullscreenButton = page.getByTestId('viewer-fullscreen');
    const markdownHeading = page.getByRole('heading', { name: 'Git File Bar' });

    await expect(sidebarFileBrowser).toHaveCount(1);
    await expect(markdownHeading).toBeVisible({ timeout: 30000 });

    await fullscreenButton.click();
    await page.waitForFunction(() => new URLSearchParams(window.location.hash.split('?')[1] || '').get('fullscreen') === '1');

    await expect(sidebarFileBrowser).toHaveCount(0);
    await expect(markdownHeading).toBeVisible();

    await fullscreenButton.click();
    await page.waitForFunction(() => new URLSearchParams(window.location.hash.split('?')[1] || '').get('fullscreen') !== '1');

    await expect(sidebarFileBrowser).toHaveCount(1);
  });

  test('direct repository links never flash the generic file browser sidebar', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);
    await installSidebarFlashTracker(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}`);
    await waitForAppReady(page);

    await expect(page.getByRole('button', { name: /commits/i })).toBeVisible({ timeout: 60000 });
    await expect(page.locator(GENERIC_SIDEBAR_SELECTOR)).toHaveCount(0);
    await page.waitForTimeout(250);

    const sidebarFlashed = await page.evaluate(() => {
      return (window as { __sidebarFlashSeen?: boolean }).__sidebarFlashSeen === true;
    });
    expect(sidebarFlashed).toBe(false);
  });

  test('direct repository links never flash empty directory before repo entries load', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);
    await installRepoEmptyDirectoryFlashTracker(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}`);
    await waitForAppReady(page);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    await expect(repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: README_NAME }).first()).toBeVisible({ timeout: 60000 });
    await expect(repoFileList.locator('tbody')).not.toContainText('Empty directory');

    const emptyDirectoryFlashed = await page.evaluate(() => {
      return (window as Window & { __repoEmptyDirectoryFlashSeen?: boolean }).__repoEmptyDirectoryFlashSeen === true;
    });
    expect(emptyDirectoryFlashed).toBe(false);
  });

  test('git permalinks for subdirectory files do not render the generic file browser sidebar', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();
    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );

    const fileCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBFILE_NAME }).first();
    await expect(fileCell).toBeVisible({ timeout: 30000 });
    await fileCell.click();
    await page.waitForFunction(
      (name) => window.location.hash.includes(encodeURIComponent(name)),
      SUBFILE_NAME,
      { timeout: 15000 }
    );

    const permalinkLink = page.getByTestId('viewer-permalink');
    await expect(permalinkLink).toBeVisible({ timeout: 30000 });

    const permalinkHref = await permalinkLink.getAttribute('href');
    expect(permalinkHref).toBeTruthy();
    expect(permalinkHref).toMatch(/^#\/nhash1/);

    await page.goto(`/git.html${permalinkHref}`);
    await waitForAppReady(page);

    const sidebarFileBrowser = page.locator(GENERIC_SIDEBAR_SELECTOR);
    await expect(sidebarFileBrowser).toHaveCount(1);
    await expect(page.locator('[data-testid="viewer-header"]')).toBeVisible({ timeout: 30000 });
    await expect(page.getByText('hello from subdir')).toBeVisible({ timeout: 30000 });
  });

  test('clicking a git permalink does not flash directory actions before file view resolves', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);
    await installFlashTracker(page, DIRECTORY_ACTIONS_ADD_FILES_SELECTOR, 'add-files');

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const repoFileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();
    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );

    const fileCell = repoFileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBFILE_NAME }).first();
    await expect(fileCell).toBeVisible({ timeout: 30000 });
    await fileCell.click();
    await page.waitForFunction(
      (name) => window.location.hash.includes(encodeURIComponent(name)),
      SUBFILE_NAME,
      { timeout: 15000 }
    );

    const permalinkLink = page.getByTestId('viewer-permalink');
    await expect(permalinkLink).toBeVisible({ timeout: 30000 });

    await permalinkLink.click();
    await page.waitForFunction(() => window.location.hash.startsWith('#/nhash1'), undefined, { timeout: 15000 });
    await waitForAppReady(page);
    await expect(page.locator(GENERIC_SIDEBAR_SELECTOR)).toHaveCount(1);

    const addFilesFlashed = await page.evaluate(() => {
      const trackerWindow = window as Window & { __flashTracker?: Record<string, boolean> };
      return trackerWindow.__flashTracker?.['add-files'] === true;
    });
    expect(addFilesFlashed).toBe(false);
  });

  test('clicking history opens git history modal', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}/${README_NAME}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const gitBar = page.locator('[data-testid="git-file-bar"]');
    await expect(gitBar).toBeVisible({ timeout: 60000 });
    await expect(gitBar.locator('button[title*="history" i]')).toBeVisible({ timeout: 60000 });
    await gitBar.locator('button[title*="history" i]').click();
    await expect(page.locator('[data-testid="git-history-modal"]')).toBeVisible({ timeout: 10000 });
  });

  test('shows git bar when viewing file in subdirectory via navigation', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);

    await page.goto(`/git.html#/${npub}/public/${repoName}?g=${encodeURIComponent(repoName)}`);
    await waitForAppReady(page);

    const fileList = page.locator('[data-testid="file-list"]').last();
    const dirCell = fileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBDIR_NAME }).first();
    await expect(dirCell).toBeVisible({ timeout: 30000 });
    await dirCell.click();
    await page.waitForFunction(
      (dir) => window.location.hash.includes(encodeURIComponent(dir)),
      SUBDIR_NAME,
      { timeout: 15000 }
    );

    const fileCell = fileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBFILE_NAME }).first();
    await expect(fileCell).toBeVisible({ timeout: 30000 });
    await fileCell.click();
    await page.waitForFunction(
      (name) => window.location.hash.includes(encodeURIComponent(name)),
      SUBFILE_NAME,
      { timeout: 15000 }
    );

    const gitBar = page.locator('[data-testid="git-file-bar"]');
    await expect(gitBar).toBeVisible({ timeout: 60000 });
    await expect(gitBar.getByText(/\d+\s+(second|minute|hour|day|week|month|year)s?\s+ago/i)).toBeVisible();
  });

  test('direct deep links into repo subdirectories still use git UI without flashing directory actions', async ({ page }) => {
    test.slow();

    const { repoName, npub } = await uploadGitRepo(page);
    await installFlashTracker(page, DIRECTORY_ACTIONS_ADD_FILES_SELECTOR, 'add-files');

    await page.goto(`/git.html#/${npub}/public/${repoName}/${SUBDIR_NAME}`);
    await waitForAppReady(page);

    await expect(page.getByRole('button', { name: /commits/i })).toBeVisible({ timeout: 60000 });

    const fileList = page.locator('[data-testid="file-list"]').last();
    const fileCell = fileList.locator('tbody tr td:nth-child(2)').filter({ hasText: SUBFILE_NAME }).first();
    await expect(fileCell).toBeVisible({ timeout: 30000 });
    await fileCell.click();

    const gitBar = page.locator('[data-testid="git-file-bar"]');
    await expect(gitBar).toBeVisible({ timeout: 60000 });
    await expect(page.locator(GENERIC_SIDEBAR_SELECTOR)).toHaveCount(1);

    const addFilesFlashed = await page.evaluate(() => {
      const trackerWindow = window as Window & { __flashTracker?: Record<string, boolean> };
      return trackerWindow.__flashTracker?.['add-files'] === true;
    });
    expect(addFilesFlashed).toBe(false);
  });
});
