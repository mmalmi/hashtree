import { createHash } from 'node:crypto';
import { decryptObject, objectKeyFromHex } from '@hashtree/core';
import { test, expect } from './fixtures';
import { configureBlossomServers, ensureLoggedIn, getTestBlossomUrl, gotoGitApp, waitForWorkerAdapter } from './test-utils';

test('uploads file and streamed content with versioned keys to Blossom', async ({ page, request }) => {
  await gotoGitApp(page);
  await ensureLoggedIn(page);
  await waitForWorkerAdapter(page);
  await configureBlossomServers(page);

  const repo = await page.evaluate(async () => {
    const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
    return createGitRepositoryTree('upload-' + crypto.randomUUID());
  });
  expect(repo.success).toBe(true);

  for (const streamed of [false, true]) {
    const text = 'Iris Git upload ' + crypto.randomUUID();
    const name = 'upload.txt';
    if (streamed) {
      await page.locator('label[title="Add files"] input[type="file"]').first().setInputFiles({
        name, mimeType: 'text/plain', buffer: Buffer.from(text),
      });
      await expect(page).toHaveURL(/\/upload\.txt(?:\?|$)/);
    }
    const result = await page.evaluate(async ({ streamed, text, name, repo }) => {
      const { getWorkerAdapter } = await import('/src/lib/workerInit.ts');
      const { getTree } = await import('/src/store.ts');
      const adapter = getWorkerAdapter()!;
      let cid;
      if (streamed) {
        const { getTreeRootSync } = await import('/src/stores/treeRoot.ts');
        const root = getTreeRootSync(repo.npub, repo.treeName);
        if (!root) throw new Error('Missing repository root after upload');
        cid = (await getTree().resolvePath(root, name))?.cid;
        if (!cid) throw new Error('Uploaded file is absent from the repository');
      } else {
        cid = await adapter.writeFile(null, name, new TextEncoder().encode(text));
      }
      const push = await adapter.pushToBlossom(cid.hash, cid.key);
      const hex = (bytes: Uint8Array) => Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
      return { hash: hex(cid.hash), key: hex(cid.key!), push };
    }, { streamed, text, name, repo });
    expect(result.key).toMatch(/^01[0-9a-f]{64}$/);
    expect(result.push.failed, result.push.errors?.join('\n')).toBe(0);
    const blob = await request.get(getTestBlossomUrl() + '/' + result.hash);
    expect(blob.ok()).toBe(true);
    const ciphertext = await blob.body();
    expect(createHash('sha256').update(ciphertext).digest('hex')).toBe(result.hash);
    const plaintext = await decryptObject(ciphertext, objectKeyFromHex(result.key));
    expect(new TextDecoder().decode(plaintext)).toBe(text);
  }
});
