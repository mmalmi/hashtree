import { type Page } from './fixtures';
import { evaluateWithRetry, navigateToPublicFolder } from './test-utils.js';
import * as fs from 'fs/promises';
import * as path from 'path';
import * as os from 'os';
import { execSync } from 'child_process';

export const SUBDIR_NAME = 'subdir';
export const SUBFILE_NAME = 'file.txt';
export const README_NAME = 'README.md';
export const GENERIC_SIDEBAR_SELECTOR = '[data-testid="file-list"][aria-label="File list"]';
export const DIRECTORY_ACTIONS_ADD_FILES_SELECTOR = '[title="Add files"]';

function shouldIncludeGitPath(relativePath: string): boolean {
  if (!relativePath.startsWith('.git/')) {
    return true;
  }

  return (
    relativePath === '.git/HEAD' ||
    relativePath === '.git/packed-refs' ||
    relativePath.startsWith('.git/refs/') ||
    relativePath.startsWith('.git/objects/')
  );
}

async function createTempGitRepo(): Promise<string> {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'git-file-bar-'));
  execSync('git init', { cwd: tmpDir });
  execSync('git config user.email "test@example.com"', { cwd: tmpDir });
  execSync('git config user.name "Test User"', { cwd: tmpDir });

  await fs.mkdir(path.join(tmpDir, SUBDIR_NAME), { recursive: true });
  await fs.mkdir(path.join(tmpDir, '.hashtree'), { recursive: true });
  await fs.writeFile(path.join(tmpDir, README_NAME), '# Git File Bar\n');
  await fs.writeFile(path.join(tmpDir, SUBDIR_NAME, SUBFILE_NAME), 'hello from subdir\n');
  await fs.writeFile(
    path.join(tmpDir, '.hashtree', 'project.toml'),
    [
      '[project]',
      'about = "Temporary repository for git view tests."',
      'homepage = "https://example.com/git-file-bar"',
      '',
    ].join('\n'),
  );

  execSync('git add .', { cwd: tmpDir });
  execSync('git commit -m "Initial commit"', { cwd: tmpDir });
  return tmpDir;
}

async function collectRepoFiles(rootDir: string, basePath = ''): Promise<Array<{ relativePath: string; content: number[] }>> {
  const entries = await fs.readdir(rootDir, { withFileTypes: true });
  const files: Array<{ relativePath: string; content: number[] }> = [];

  for (const entry of entries) {
    const fullPath = path.join(rootDir, entry.name);
    const relativePath = basePath ? `${basePath}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      if (relativePath.startsWith('.git/') && !relativePath.startsWith('.git/refs') && !relativePath.startsWith('.git/objects')) {
        continue;
      }
      files.push(...await collectRepoFiles(fullPath, relativePath));
      continue;
    }

    if (entry.isFile()) {
      if (!shouldIncludeGitPath(relativePath)) {
        continue;
      }
      const content = await fs.readFile(fullPath);
      files.push({ relativePath, content: Array.from(content) });
    }
  }

  return files;
}

export async function uploadGitRepo(page: Page, repoName = `git-bar-${Date.now()}`): Promise<{ repoName: string; npub: string }> {
  await navigateToPublicFolder(page, { requireRelay: false });

  const npub = await page.evaluate(() => {
    const appWindow = window as Window & {
      __nostrStore?: { getState?: () => { npub?: string } };
    };
    return appWindow.__nostrStore?.getState?.()?.npub || '';
  });
  const repoPath = await createTempGitRepo();
  const files = await collectRepoFiles(repoPath);

  await evaluateWithRetry(page, async ({ repoName, files }) => {
    const { uploadFilesWithPaths } = await import('/src/stores/upload.ts');
    const filesWithPaths = files.map((entry: { relativePath: string; content: number[] }) => {
      const name = entry.relativePath.split('/').pop() || 'file';
      const data = new Uint8Array(entry.content);
      const file = new File([data], name);
      return { file, relativePath: `${repoName}/${entry.relativePath}` };
    });
    await uploadFilesWithPaths(filesWithPaths);
  }, { repoName, files });

  await page.waitForFunction(
    async ({ repoName, expectedNames }) => {
      const { getRouteSync, getTreeRootSync } = await import('/src/stores/index.ts');
      const { getTree } = await import('/src/store.ts');
      const route = getRouteSync();
      const root = getTreeRootSync(route.npub, route.treeName);
      if (!root) return false;
      const repository = await getTree().resolvePath(root, [repoName]);
      if (!repository) return false;
      const entries = await getTree().listDirectory(repository.cid);
      const names = new Set(entries.map((entry: { name: string }) => entry.name));
      return expectedNames.every((name) => names.has(name));
    },
    { repoName, expectedNames: [README_NAME, SUBDIR_NAME, '.git'] },
    { timeout: 30_000 },
  );

  return { repoName, npub };
}

export async function installFlashTracker(page: Page, selector: string, key: string): Promise<void> {
  await page.addInitScript(({ selector, key }: { selector: string; key: string }) => {
    const trackerWindow = window as Window & { __flashTracker?: Record<string, boolean> };
    trackerWindow.__flashTracker ??= {};
    trackerWindow.__flashTracker[key] = false;

    const markIfSidebarVisible = () => {
      if (document.querySelector(selector)) {
        trackerWindow.__flashTracker![key] = true;
      }
    };

    const startTracking = () => {
      markIfSidebarVisible();
      const observer = new MutationObserver(() => {
        markIfSidebarVisible();
      });
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        attributes: true,
      });
    };

    if (document.documentElement) {
      startTracking();
    } else {
      document.addEventListener('DOMContentLoaded', startTracking, { once: true });
    }
  }, { selector, key });
}

export async function installSidebarFlashTracker(page: Page): Promise<void> {
  await installFlashTracker(page, GENERIC_SIDEBAR_SELECTOR, 'sidebar');
}

export async function installRepoEmptyDirectoryFlashTracker(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const trackerWindow = window as Window & { __repoEmptyDirectoryFlashSeen?: boolean };
    trackerWindow.__repoEmptyDirectoryFlashSeen = false;

    const normalize = (value: string | null | undefined): string =>
      (value ?? '').replace(/\s+/g, ' ').trim();

    const checkForFlash = () => {
      const fileListBody = document.querySelector('[data-testid="repo-main-column"] [data-testid="file-list"] tbody');
      if (!fileListBody) {
        return;
      }

      if (normalize(fileListBody.textContent).includes('Empty directory')) {
        trackerWindow.__repoEmptyDirectoryFlashSeen = true;
      }
    };

    const startTracking = () => {
      checkForFlash();
      const observer = new MutationObserver(() => {
        checkForFlash();
      });
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        characterData: true,
      });
    };

    if (document.documentElement) {
      startTracking();
    } else {
      document.addEventListener('DOMContentLoaded', startTracking, { once: true });
    }
  });
}

export async function installRepoHeaderMismatchTracker(
  page: Page,
  targetHeaderText: string,
  staleFileListText: string[],
): Promise<void> {
  await page.addInitScript(
    ({ targetHeaderText, staleFileListText }: { targetHeaderText: string; staleFileListText: string[] }) => {
      const trackerWindow = window as Window & {
        __repoHeaderMismatchTracker?: { mismatchDetected: boolean; samples: Array<{ headerText: string; fileListText: string }> };
      };

      const normalize = (value: string | null | undefined): string =>
        (value ?? '').replace(/\s+/g, ' ').trim();

      const readHeaderText = (): string =>
        normalize(document.querySelector('[data-testid="repo-header-path"]')?.textContent);

      const readFileListText = (): string =>
        normalize(document.querySelector('[data-testid="file-list"] tbody')?.textContent);

      const checkForMismatch = () => {
        const headerText = readHeaderText();
        if (headerText !== targetHeaderText) {
          return;
        }

        const fileListText = readFileListText();
        const staleVisible = staleFileListText.some((text) => fileListText.includes(text));
        if (!staleVisible) {
          return;
        }

        trackerWindow.__repoHeaderMismatchTracker ??= {
          mismatchDetected: false,
          samples: [],
        };
        trackerWindow.__repoHeaderMismatchTracker.mismatchDetected = true;
        trackerWindow.__repoHeaderMismatchTracker.samples.push({ headerText, fileListText });
      };

      const startTracking = () => {
        trackerWindow.__repoHeaderMismatchTracker = {
          mismatchDetected: false,
          samples: [],
        };

        checkForMismatch();

        const observer = new MutationObserver(() => {
          checkForMismatch();
        });

        observer.observe(document.documentElement, {
          subtree: true,
          childList: true,
          characterData: true,
        });
      };

      if (document.documentElement) {
        startTracking();
      } else {
        document.addEventListener('DOMContentLoaded', startTracking, { once: true });
      }
    },
    { targetHeaderText, staleFileListText },
  );
}
