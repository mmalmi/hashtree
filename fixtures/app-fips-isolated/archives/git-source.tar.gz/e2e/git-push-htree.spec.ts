/**
 * E2E test: Git push to htree:// remote and view in ts browser
 *
 * Flow:
 * 1. Create temp data directory for htree
 * 2. Start htree daemon (generates identity)
 * 3. Create a small test repo
 * 4. Add htree remote using daemon's npub and push
 * 5. Open ts browser and navigate to the pushed tree
 * 6. Verify files are visible
 * 7. Cleanup
 *
 * Run with: npx playwright test git-push-htree --project=chromium
 */

import { test, expect } from './fixtures';
import { spawn, execSync, ChildProcess } from 'child_process';
import * as dgram from 'node:dgram';
import { stripVTControlCharacters } from 'node:util';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { identityFromSecretKey, toHex } from '@fips/core';
import { nip19, getPublicKey } from 'nostr-tools';
import { resolveNativeFixtureBinaries } from './native-binaries.js';
import {
  configureExplicitGitFipsRoute,
  ensureLoggedIn,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';
import { BOOTSTRAP_SECKEY } from './nostr-test-keys.js';
import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';

const BROWSER_NSEC = nip19.nsecEncode(BOOTSTRAP_SECKEY);
const BROWSER_NPUB = nip19.npubEncode(getPublicKey(BOOTSTRAP_SECKEY));
const BROWSER_FIPS_SECKEY = new Uint8Array(32);
BROWSER_FIPS_SECKEY[BROWSER_FIPS_SECKEY.length - 1] = 7;
const BROWSER_FIPS_SECRET_HEX = Array.from(
  BROWSER_FIPS_SECKEY,
  (byte) => byte.toString(16).padStart(2, '0'),
).join('');
const BROWSER_FIPS_NPUB = nip19.npubEncode(getPublicKey(BROWSER_FIPS_SECKEY));
const NATIVE_SECKEY = new Uint8Array(32);
NATIVE_SECKEY[NATIVE_SECKEY.length - 1] = 5;

async function reserveUdpLoopbackAddress(): Promise<string> {
  return new Promise((resolve, reject) => {
    const socket = dgram.createSocket('udp4');
    socket.once('error', reject);
    socket.bind(0, '127.0.0.1', () => {
      const address = socket.address();
      socket.close(() => resolve(`${address.address}:${address.port}`));
    });
  });
}

test.describe('Git push to htree:// and view in browser', () => {
  // Serial mode keeps the native daemon and its temporary repository isolated.
  test.describe.configure({ mode: 'serial', timeout: 180000 });
  test.setTimeout(180000);

  let tempDir: string;
  let htreeProcess: ChildProcess | null = null;
  let npub: string | null = null;
  let htreeBin: string;
  let gitRemoteHtree: string;
  let nativeFipsPeerId: string;
  let fipsRendezvousAddr: string;
  let htreeOutput = '';
  let seed: LocalFipsWebSocketSeed;

  const deriveNpubFromKeys = (keysPath: string): string | null => {
    if (!fs.existsSync(keysPath)) return null;
    const raw = fs.readFileSync(keysPath, 'utf-8').trim();
    if (!raw) return null;
    try {
      if (raw.startsWith('nsec')) {
        const decoded = nip19.decode(raw);
        if (decoded.type === 'nsec') {
          const sk = decoded.data as Uint8Array;
          const pk = getPublicKey(sk);
          return nip19.npubEncode(pk);
        }
      }
    } catch {
      // fall through
    }
    if (/^[0-9a-f]{64}$/i.test(raw)) {
      const bytes = new Uint8Array(raw.match(/.{1,2}/g)?.map(byte => parseInt(byte, 16)) || []);
      if (bytes.length === 32) {
        const pk = getPublicKey(bytes);
        return nip19.npubEncode(pk);
      }
    }
    return null;
  };

  test.beforeAll(async () => {
    test.setTimeout(180000);
    seed = await startLocalFipsWebSocketSeed();
    nativeFipsPeerId = toHex((await identityFromSecretKey(NATIVE_SECKEY)).publicKey);
    fipsRendezvousAddr = await reserveUdpLoopbackAddress();
    // Create temp directory for htree data
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'htree-test-'));
    console.log(`Using temp directory: ${tempDir}`);

    ({ htree: htreeBin, gitRemoteHtree } = resolveNativeFixtureBinaries());
  });

  test.afterAll(async () => {
    // Kill htree daemon
    if (htreeProcess) {
      console.log('Stopping htree daemon...');
      htreeProcess.kill('SIGTERM');
      htreeProcess = null;
    }
    await seed?.close();
    // Cleanup temp directory
    if (tempDir && fs.existsSync(tempDir)) {
      console.log(`Cleaning up temp directory: ${tempDir}`);
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('push repo to htree:// and view in browser', async ({ page, relayUrl }) => {
    // Verify binaries exist
    expect(fs.existsSync(htreeBin)).toBe(true);
    expect(fs.existsSync(gitRemoteHtree)).toBe(true);

    // Environment setup - use temp dir for all data
    const configDir = path.join(tempDir, '.hashtree');
    fs.mkdirSync(configDir, { recursive: true });
    fs.writeFileSync(path.join(configDir, 'keys'), nip19.nsecEncode(NATIVE_SECKEY));
    const localRelay = relayUrl;
    const blossomUrl = process.env.PW_TEST_BLOSSOM_URL ?? 'http://127.0.0.1:18780';
    fs.writeFileSync(path.join(configDir, 'config.toml'), [
      '[server]',
      'enable_auth = false',
      'enable_webrtc = false',
      'stun_port = 0',
      'enable_fips = true',
      'enable_fips_udp = false',
      'enable_fips_webrtc = true',
      'enable_multicast = false',
      'fips_discovery_scope = "fips-overlay-v1"',
      `fips_local_rendezvous_addr = "${fipsRendezvousAddr}"`,
      `fips_relays = ["${localRelay}"]`,
      `fips_websocket_seed_urls = ["${seed.url}"]`,
      `fips_peers = [{ npub = "${BROWSER_FIPS_NPUB}" }]`,
      '',
      '[nostr]',
      `relays = ["${localRelay}"]`,
      'crawl_depth = 0',
      '',
      '[blossom]',
      `read_servers = ["${blossomUrl}"]`,
      `write_servers = ["${blossomUrl}"]`,
      '',
    ].join('\n'));

    const env = {
      ...process.env,
      HOME: tempDir,
      NOSTR_RELAYS: localRelay,
      HTREE_PREFER_LOCAL_RELAY: '0',
      HTREE_PREFER_LOCAL_DAEMON: '0',
      PATH: `${path.dirname(gitRemoteHtree)}:${process.env.PATH}`,
      HTREE_DATA_DIR: path.join(tempDir, 'data'),
      HTREE_CONFIG_DIR: configDir,
    };

    // Create the data directory
    fs.mkdirSync(path.join(tempDir, 'data'), { recursive: true });

    // Start htree daemon FIRST to generate identity
    console.log('Starting htree daemon...');
    htreeProcess = spawn(htreeBin, ['start', '--addr', '127.0.0.1:0'], {
      env: { ...env, RUST_LOG: 'info' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    // Capture output and wait for startup, extract npub
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('htree daemon startup timeout'));
      }, 30000);

      const outputHandler = (data: Buffer) => {
        const text = stripVTControlCharacters(data.toString());
        htreeOutput += text;
        console.log('[htree]', text.trim());

        if (text.includes('built without the webrtc feature')) {
          clearTimeout(timeout);
          reject(new Error('Iris Git process gate requires htree built with fips-webrtc'));
          return;
        }

        // Ignore peer-discovery logs; only the daemon's own identity owns the repo.
        const npubMatch = text.match(/Identity:\s+(npub1[a-z0-9]{58})/);
        if (npubMatch && !npub) {
          npub = npubMatch[1];
          console.log(`Found npub: ${npub}`);
        }

        // Look for startup indicator
        if (text.includes('Web UI:')) {
          clearTimeout(timeout);
          resolve();
        }
      };

      htreeProcess!.stdout?.on('data', outputHandler);
      htreeProcess!.stderr?.on('data', outputHandler);

      htreeProcess!.on('error', (err) => {
        clearTimeout(timeout);
        reject(err);
      });

      htreeProcess!.on('exit', (code) => {
        if (code !== 0 && code !== null) {
          clearTimeout(timeout);
          reject(new Error(`htree exited with code ${code}`));
        }
      });
    });

    if (!npub) {
      const keyPath = path.join(tempDir, '.hashtree', 'keys');
      npub = deriveNpubFromKeys(keyPath);
      if (npub) {
        console.log(`Derived npub from keys file: ${npub}`);
      }
    }
    if (!npub) {
      throw new Error('Could not get npub from htree daemon');
    }
    await expect.poll(() => htreeOutput.includes(
      `local_addr=${fipsRendezvousAddr}`,
    ), { timeout: 30000 }).toBe(true);

    // Now create test repo and push using the daemon's identity
    const testRepoDir = path.join(tempDir, 'test-repo');
    fs.mkdirSync(testRepoDir);

    console.log('Creating test repo...');
    execSync('git init -b master', { cwd: testRepoDir });
    execSync('git config user.email "test@test.com"', { cwd: testRepoDir });
    execSync('git config user.name "Test User"', { cwd: testRepoDir });

    // Add some test files
    fs.writeFileSync(path.join(testRepoDir, 'README.md'), '# Test Repository\n\nThis is a test.');
    fs.writeFileSync(path.join(testRepoDir, 'hello.txt'), 'Hello, World!');
    fs.mkdirSync(path.join(testRepoDir, 'src'));
    fs.writeFileSync(path.join(testRepoDir, 'src', 'main.rs'), 'fn main() {\n    println!("Hello!");\n}\n');

    execSync('git add -A', { cwd: testRepoDir });
    execSync('git commit -m "Initial commit"', { cwd: testRepoDir });

    // Add htree remote using the npub from daemon
    console.log(`Adding htree remote with npub: ${npub}...`);
    execSync(`git remote add htree htree://${npub}/test-repo`, { cwd: testRepoDir, env });

    console.log('Pushing to htree...');
    execSync('git push htree HEAD:master', {
      cwd: testRepoDir,
      env,
      stdio: 'inherit',
    });

    // Wait for Nostr event to propagate to relays
    console.log('Waiting for Nostr event propagation...');
    await new Promise(resolve => setTimeout(resolve, 5000));

    await page.addInitScript(({ nsec, fipsSecretKeyHex, websocketSeedUrl }) => {
      localStorage.setItem('hashtree:loginType', 'nsec');
      localStorage.setItem('hashtree:nsec', nsec);
      localStorage.setItem('iris-git:test-fips-secret-key', fipsSecretKeyHex);
      window.__testFipsWebsocketSeedUrls = [websocketSeedUrl];
    }, { nsec: BROWSER_NSEC, fipsSecretKeyHex: BROWSER_FIPS_SECRET_HEX, websocketSeedUrl: seed.url });

    // Open Iris Git with independent deterministic Nostr and FIPS identities.
    console.log('Opening Iris Git...');
    let serverReady = false;
    try {
      await page.goto('/git.html', { waitUntil: 'domcontentloaded', timeout: 30000 });
      serverReady = true;
    } catch {
      // Retry once in case the dev server is still starting under load
      try {
        await page.goto('/git.html', { waitUntil: 'domcontentloaded', timeout: 30000 });
        serverReady = true;
      } catch {
        throw new Error('Dev server not running at the configured Playwright base URL');
      }
    }
    if (serverReady) {
      await waitForAppReady(page, 30000);
      await useLocalRelay(page, localRelay);
      await ensureLoggedIn(page, 30000);
      await waitForRelayConnected(page, 30000);
    }

    await expect.poll(async () => page.evaluate(() => (
      (window as { __nostrStore?: { getState?: () => { npub?: string | null } } })
        .__nostrStore?.getState?.().npub ?? null
    )), { timeout: 30000, intervals: [100, 250, 500] }).toBe(BROWSER_NPUB);

    await expect.poll(async () => page.evaluate(async () => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      return getGitFipsRuntime()?.getStats().localNpub ?? null;
    }), { timeout: 30000, intervals: [100, 250, 500] }).toBe(BROWSER_FIPS_NPUB);

    // Navigate to the pushed tree
    const treeUrl = `/git.html#/${npub}/test-repo`;
    console.log(`Navigating to: ${treeUrl}`);
    await page.goto(treeUrl, { waitUntil: 'domcontentloaded' });
    await waitForAppReady(page, 30000);

    await configureExplicitGitFipsRoute(page, nativeFipsPeerId);
    const configuredRoutes = await page.evaluate(async () => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      const runtime = getGitFipsRuntime();
      if (!runtime) throw new Error('git FIPS runtime is not active');
      return runtime.getStats().blobRoutes;
    });
    expect(configuredRoutes).toEqual([{ peerId: nativeFipsPeerId, htl: 10 }]);

    // FSP sessions are established lazily by the first endpoint request. Route
    // navigation starts the remote block fetch; then require that request to
    // produce an authenticated session, not merely a connected WebRTC link.
    await expect.poll(async () => page.evaluate(async (daemonNpub: string) => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      const peer = getGitFipsRuntime()?.getStats().peers.find(candidate => candidate.npub === daemonNpub);
      return !!peer?.connected && peer.sessionsEstablished > 0;
    }, npub), { timeout: 60000, intervals: [250, 500, 1000] }).toBe(true);

    const fileList = page.getByTestId('file-list');
    await expect(fileList.getByRole('link', { name: 'README.md', exact: true })).toBeVisible({ timeout: 60000 });
    await expect(fileList.getByRole('link', { name: 'hello.txt', exact: true })).toBeVisible({ timeout: 60000 });
    await expect(fileList.getByRole('link', { name: 'src', exact: true })).toBeVisible({ timeout: 60000 });
    await expect(page.getByTestId('fork-folder-btn')).toBeVisible({ timeout: 30000 });
  });
});
