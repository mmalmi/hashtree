import { test, expect, type Page } from './fixtures';
import { setupPageErrorHandler, waitForAppReady, presetProductionRelaysInDB, useLocalRelay, gotoGitApp, createRepositoryInCurrentDirectory } from './test-utils.js';

const GIT_APP_PREFIX = '/git.html';
const REPO_OWNER_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';

function shouldUseProductionRelays(): boolean {
  return process.env.E2E_PRODUCTION_RELAYS === '1';
}

async function createLocalGitRepo(page: Page): Promise<{ repoName: string; npub: string }> {
  const npub = await page.evaluate(() => (window as any).__nostrStore?.getState?.()?.npub || '');
  const repoName = `git-perf-${Date.now()}`;
  await createRepositoryInCurrentDirectory(page, repoName, 30000);
  return { repoName, npub };
}

test.describe('Git performance', () => {
  test('measure git operations on hashtree repo', async ({ page }) => {
    test.slow(); // This test needs more time

    setupPageErrorHandler(page);

    // Collect console logs
    const perfLogs: string[] = [];
    const allLogs: string[] = [];
    page.on('console', msg => {
      const text = msg.text();
      allLogs.push(text);
      if (text.includes('[git perf]') || text.includes('[git]') || text.includes('getCommitCountFast')) {
        perfLogs.push(text);
        console.log(text);
      }
    });

    await gotoGitApp(page);
    if (shouldUseProductionRelays()) {
      await presetProductionRelaysInDB(page);
      await page.reload();
      await waitForAppReady(page);
      // Navigate to hashtree repo with production config
      console.log('Navigating to hashtree repo...');
      await page.goto(`${GIT_APP_PREFIX}#/${REPO_OWNER_NPUB}/hashtree`);
    } else {
      await waitForAppReady(page);
      console.log('Using local relay for git perf test...');
      await useLocalRelay(page);
      const { repoName, npub } = await createLocalGitRepo(page);
      console.log('Navigating to local git repo...');
      await page.goto(`${GIT_APP_PREFIX}#/${npub}/${repoName}`);
    }

    await waitForAppReady(page);

    // The connectivity indicator is hidden by default; wait for the shared header controls instead.
    console.log('Waiting for app header...');
    await expect(page.getByTestId('header-settings-link')).toBeVisible({ timeout: 30000 });

    // Wait for git repo view to appear (directory listing table)
    console.log('Waiting for directory listing...');
    await expect(page.locator('[data-testid="file-list"] table').first()).toBeVisible({ timeout: 60000 });

    // Wait for file last commits to complete by polling our collected logs.
    // The commit-count fast path is opportunistic, so don't fail if its log is absent.
    console.log('Waiting for file commit info (file last commits)...');
    const startTime = Date.now();

    // Poll until we see the file-commit completion log.
    let fileCommitsTime = '';
    let commitCountTime = '';

    await expect.poll(() => {
      if (!fileCommitsTime) {
        const fileLog = perfLogs.find(log => log.includes('getFileLastCommits completed'));
        if (fileLog) {
          const match = fileLog.match(/completed in (\d+) ms/);
          if (match) fileCommitsTime = match[1];
        }
      }

      if (!commitCountTime) {
        const countLog = perfLogs.find(log => log.includes('getCommitCountFast completed'));
        if (countLog) {
          const match = countLog.match(/completed in (\d+) ms/);
          if (match) commitCountTime = match[1];
        }
      }

      const commitInfoVisible = page.locator('[data-testid="file-list"] a[href*="?commit="]').first().isVisible();
      return Promise.resolve(commitInfoVisible).then((visible) => visible || Boolean(fileCommitsTime));
    }, { timeout: 90000, intervals: [500, 1000, 2000, 3000] }).toBe(true);

    const loadTime = Date.now() - startTime;
    console.log(`\nFile commit info completed in: ${fileCommitsTime || 'N/A'}ms`);
    console.log(`Commit count completed in: ${commitCountTime || 'N/A'}ms`);
    console.log(`Total wait time: ${loadTime}ms`);

    // Print all perf logs
    console.log('\n=== Performance Logs ===');
    for (const log of perfLogs) {
      console.log(log);
    }
    console.log('========================\n');

    // Print summary
    console.log('Total logs collected:', allLogs.length);
    console.log('Perf logs collected:', perfLogs.length);
  });
});
