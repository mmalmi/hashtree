import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

export const EXPECTED_HTREE_VERSION = '0.2.142';

export type NativeFixtureBinaries = {
  htree: string;
  gitRemoteHtree: string;
};

function isExecutable(file: string): boolean {
  try {
    if (!fs.statSync(file).isFile()) return false;
    if (process.platform !== 'win32') fs.accessSync(file, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

function commandNames(command: string): string[] {
  if (process.platform !== 'win32') return [command];
  return (process.env.PATHEXT ?? '.EXE;.CMD;.BAT')
    .split(';')
    .map((extension) => `${command}${extension.toLowerCase()}`);
}

function findOnPath(command: string, pathValue = ''): string | null {
  for (const dir of pathValue.split(path.delimiter)) {
    if (!dir) continue;
    for (const name of commandNames(command)) {
      const candidate = path.resolve(dir, name);
      if (isExecutable(candidate)) return candidate;
    }
  }
  return null;
}

function resolveBinary(
  env: NodeJS.ProcessEnv,
  envName: 'HTREE_BIN' | 'GIT_REMOTE_HTREE_BIN',
  command: 'htree' | 'git-remote-htree',
): string {
  const explicit = env[envName]?.trim();
  const resolved = explicit
    ? (explicit.includes('/') || explicit.includes('\\')
        ? path.resolve(explicit)
        : findOnPath(explicit, env.PATH))
    : findOnPath(command, env.PATH);

  if (!resolved || !isExecutable(resolved)) {
    throw new Error(
      `Native Iris Git gate requires ${envName} or an executable ${command} on PATH; `
      + 'the gate never builds Cargo sources or discovers sibling checkouts.',
    );
  }
  return resolved;
}

function verifyHtreeVersion(htree: string, env: NodeJS.ProcessEnv): void {
  const result = spawnSync(htree, ['--version'], {
    encoding: 'utf8',
    env: { ...process.env, ...env },
  });
  if (result.error || result.status !== 0) {
    const detail = result.error?.message ?? `${result.stdout ?? ''}${result.stderr ?? ''}`.trim();
    throw new Error(`Unable to verify ${htree}: ${detail || `exit ${result.status}`}`);
  }

  const actual = `${result.stdout ?? ''}${result.stderr ?? ''}`.trim();
  const expected = `htree ${EXPECTED_HTREE_VERSION}`;
  if (actual !== expected) {
    throw new Error(`Native Iris Git gate expected ${expected}, got ${actual || '(empty version output)'}`);
  }
}

export function resolveNativeFixtureBinaries(
  env: NodeJS.ProcessEnv = process.env,
): NativeFixtureBinaries {
  const htree = resolveBinary(env, 'HTREE_BIN', 'htree');
  const gitRemoteHtree = resolveBinary(env, 'GIT_REMOTE_HTREE_BIN', 'git-remote-htree');
  verifyHtreeVersion(htree, env);
  return { htree, gitRemoteHtree };
}

export function installNativeFixtureEnvironment(
  env: NodeJS.ProcessEnv = process.env,
): NativeFixtureBinaries {
  const binaries = resolveNativeFixtureBinaries(env);
  env.HTREE_BIN = binaries.htree;
  env.GIT_REMOTE_HTREE_BIN = binaries.gitRemoteHtree;
  env.PATH = [
    path.dirname(binaries.gitRemoteHtree),
    path.dirname(binaries.htree),
    env.PATH,
  ].filter(Boolean).join(path.delimiter);
  return binaries;
}
