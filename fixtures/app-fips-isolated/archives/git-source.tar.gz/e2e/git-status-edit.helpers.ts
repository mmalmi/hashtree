import { HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import { getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import * as fs from 'fs';
import { resolveNativeFixtureBinaries } from './native-binaries.js';

export function ensureGitRemoteHtree(): string {
  return resolveNativeFixtureBinaries().gitRemoteHtree;
}

export function resolveNpubFromKeysFile(keysPath: string): string | null {
  if (!fs.existsSync(keysPath)) return null;
  const content = fs.readFileSync(keysPath, 'utf-8');
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const [secret] = trimmed.split(/\s+/);
    if (!secret) continue;
    try {
      if (secret.startsWith('nsec1')) {
        const decoded = nip19.decode(secret);
        if (decoded.type === 'nsec') {
          const pubkey = getPublicKey(decoded.data as Uint8Array);
          return nip19.npubEncode(pubkey);
        }
      } else if (/^[0-9a-fA-F]{64}$/.test(secret)) {
        const bytes = Uint8Array.from(secret.match(/.{2}/g)!.map(b => parseInt(b, 16)));
        const pubkey = getPublicKey(bytes);
        return nip19.npubEncode(pubkey);
      }
    } catch {
      // Try next entry
    }
  }
  return null;
}

export async function waitForTreeEvent(
  relayUrl: string,
  pubkey: string,
  treeName: string,
  timeoutMs = 30000
): Promise<{ hashHex: string; keyHex?: string } | null> {
  return new Promise((resolve) => {
    const socket = new WebSocket(relayUrl);
    const subId = `tree-${Math.random().toString(16).slice(2)}`;
    const timeout = setTimeout(() => {
      socket.close();
      resolve(null);
    }, timeoutMs);

    const cleanup = () => {
      clearTimeout(timeout);
      socket.close();
    };

    socket.on('open', () => {
      socket.send(JSON.stringify([
        'REQ',
        subId,
        { kinds: [...HASHTREE_ROOT_KINDS], authors: [pubkey], '#l': ['hashtree'], '#d': [treeName] },
      ]));
    });

    socket.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (Array.isArray(msg) && msg[0] === 'EVENT' && msg[1] === subId) {
          const event = msg[2];
          const tags = Array.isArray(event?.tags) ? event.tags : [];
          const hashHex = tags.find((t: string[]) => t[0] === 'hash')?.[1];
          const keyHex = tags.find((t: string[]) => t[0] === 'key')?.[1];
          cleanup();
          resolve(hashHex ? { hashHex, keyHex } : null);
        }
      } catch {
        // ignore parse errors
      }
    });

    socket.on('error', () => {
      cleanup();
      resolve(null);
    });
  });
}
