import { test, expect } from './fixtures';
import { gotoGitApp, waitForAppReady } from './test-utils.js';

test.describe('Git startup status UI', () => {
  test('waits before showing an offline warning', async ({ page }) => {
    await gotoGitApp(page);
    await page.evaluate(async () => {
      const { settingsStore } = await import('/src/stores/settings.ts');
      settingsStore.setDisplaySettings({ showConnectivity: true });
      window.dispatchEvent(new Event('offline'));
    });

    const indicator = page.locator('[data-testid="connectivity-indicator"]');
    await expect(indicator).toBeVisible();
    const offlineLabel = indicator.getByText('offline', { exact: true });
    await expect(offlineLabel).toHaveCount(0);
    await page.waitForTimeout(4_500);
    await expect(offlineLabel).toHaveCount(0);
    await expect(offlineLabel).toBeVisible({ timeout: 1_500 });
  });

  test('does not flash signed-out prompts while restoring a saved account', async ({ page }) => {
    await gotoGitApp(page);
    await page.addInitScript(() => {
      const tracked = window as Window & { __signedOutFlashes?: string[] };
      tracked.__signedOutFlashes = [];
      const scan = () => {
        const text = document.body?.innerText ?? '';
        for (const prompt of ['Login (Extension)', 'Sign in to see and create your repositories.']) {
          if (text.includes(prompt) && !tracked.__signedOutFlashes?.includes(prompt)) {
            tracked.__signedOutFlashes?.push(prompt);
          }
        }
      };
      new MutationObserver(scan).observe(document, {
        childList: true,
        subtree: true,
        characterData: true,
      });
    });

    await page.reload({ waitUntil: 'domcontentloaded' });
    await waitForAppReady(page);
    const flashes = await page.evaluate(() => (
      (window as Window & { __signedOutFlashes?: string[] }).__signedOutFlashes ?? []
    ));
    expect(flashes).toEqual([]);
  });
});
