import { test, expect } from './fixtures';
import {
    ensureLoggedIn,
  flushPendingPublishes,
  gotoGitApp,
  setupPageErrorHandler,
  useLocalRelay,
  waitForRelayConnected,
} from './test-utils.js';

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function createTopLevelRepository(page: import('@playwright/test').Page, repoName: string) {
  await page.getByRole('button', { name: /New Repository/ }).first().click();
  await page.getByPlaceholder('Repository name...').fill(repoName);
  await page.getByRole('button', { name: 'Create', exact: true }).click();
  await page.waitForURL(new RegExp(`/git\\.html#\\/npub.*\\/${repoName}`), { timeout: 30000 });
}

async function waitForProfileActivityEvents(
  page: import('@playwright/test').Page,
  created: { npub: string; issueTitle: string; prTitle: string; commentText: string },
) {
  await expect.poll(async () => page.evaluate(async (expected) => {
    const { fetchProfileGitActivity } = await import('/src/nip34.ts');
    const items = await fetchProfileGitActivity(expected.npub, 12);
    return {
      issue: items.some(item => item.type === 'issue' && item.title === expected.issueTitle),
      pr: items.some(item => item.type === 'pr' && item.title === expected.prTitle),
      comment: items.some(item => item.type === 'comment' && item.content.includes(expected.commentText)),
    };
  }, created), {
    timeout: 20000,
    intervals: [500, 1000, 2000],
  }).toEqual({ issue: true, pr: true, comment: true });
}

test.describe('Git profile activity', () => {
  test('profile shows issues, pull requests, and comments', { timeout: 90000 }, async ({ page }) => {
    setupPageErrorHandler(page);

    await gotoGitApp(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await waitForRelayConnected(page);

    const repoName = `profile-activity-${Date.now()}`;
    await createTopLevelRepository(page, repoName);
    await flushPendingPublishes(page);

    const created = await page.evaluate(async (currentRepoName: string) => {
      const npub = (window as { __nostrStore?: { getState?: () => { npub?: string } } }).__nostrStore?.getState?.().npub;
      if (!npub) {
        throw new Error('Missing logged-in npub');
      }

      const { addComment, buildRepoAddress, createIssue, createPullRequest } = await import('/src/nip34.ts');

      const issueTitle = `Issue ${currentRepoName}`;
      const prTitle = `PR ${currentRepoName}`;
      const commentText = `Comment ${currentRepoName}`;

      const issue = await createIssue(npub, currentRepoName, issueTitle, 'Track profile activity rendering');
      if (!issue) {
        throw new Error('Failed to create issue');
      }

      const pr = await createPullRequest(npub, currentRepoName, prTitle, 'Ship profile activity rendering', {
        branch: 'activity-feed',
        targetBranch: 'master',
      });
      if (!pr) {
        throw new Error('Failed to create pull request');
      }

      const comment = await addComment(issue.id, issue.authorPubkey, commentText, buildRepoAddress(npub, currentRepoName));
      if (!comment) {
        throw new Error('Failed to create comment');
      }

      return {
        npub,
        issueTitle,
        prTitle,
        commentText,
      };
    }, repoName);

    await waitForProfileActivityEvents(page, created);
    await page.goto(`/git.html#/${created.npub}`);

    const activitySection = page.getByTestId('git-profile-activity');
    const issueCard = activitySection.locator('a').filter({
      hasText: new RegExp(`Open[\\s\\S]*${escapeRegExp(created.issueTitle)}`),
    }).first();
    const prCard = activitySection.locator('a').filter({
      hasText: new RegExp(`Open[\\s\\S]*${escapeRegExp(created.prTitle)}`),
    }).first();
    const commentCard = activitySection.locator('a').filter({
      hasText: `Commented on issue: ${created.issueTitle}`,
    }).first();

    await expect(page.getByRole('heading', { name: 'Recent Activity' })).toBeVisible({ timeout: 15000 });
    await expect(activitySection).toBeVisible({ timeout: 15000 });
    await expect(issueCard).toBeVisible({ timeout: 15000 });
    await expect(prCard).toBeVisible({ timeout: 15000 });
    await expect(commentCard).toBeVisible({ timeout: 15000 });
    await expect(activitySection.getByText(created.commentText, { exact: false })).toBeVisible({ timeout: 15000 });

    await page.screenshot({ path: 'e2e/screenshots/git-profile-activity.png', fullPage: false });

    await commentCard.click();
    await expect(page.getByRole('heading', { name: created.issueTitle })).toBeVisible({ timeout: 15000 });
    await expect(page.getByText(created.commentText, { exact: false })).toBeVisible({ timeout: 15000 });
  });

  test('issue comments remain visible after refresh', { timeout: 90000 }, async ({ page }) => {
    setupPageErrorHandler(page);

    await gotoGitApp(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await waitForRelayConnected(page);

    const repoName = `issue-comment-refresh-${Date.now()}`;
    const issueTitle = `Issue ${repoName}`;
    const commentText = `Comment ${repoName}`;

    await createTopLevelRepository(page, repoName);
    await flushPendingPublishes(page);

    await page.goto(`/git.html#/${page.url().match(/npub1[a-z0-9]+/)?.[0]}/${repoName}?tab=issues`);
    await expect(page.getByRole('button', { name: /New Issue/i })).toBeVisible({ timeout: 15000 });

    await page.getByRole('button', { name: /New Issue/i }).click();
    await expect(page.getByRole('heading', { name: 'New Issue' })).toBeVisible({ timeout: 5000 });
    await page.locator('#issue-title').fill(issueTitle);
    await page.locator('#issue-description').fill('Verify issue comments survive a refresh');
    await page.getByRole('button', { name: 'Create Issue' }).click();

    const issueLink = page.getByRole('link', { name: new RegExp(escapeRegExp(issueTitle)) }).first();
    await expect(issueLink).toBeVisible({ timeout: 15000 });
    await issueLink.click();
    await expect(page.getByRole('heading', { name: issueTitle })).toBeVisible({ timeout: 15000 });

    await page.getByPlaceholder(/Leave a comment/i).fill(commentText);
    await page.getByRole('button', { name: 'Comment' }).click();
    await expect(page.getByText(commentText, { exact: false })).toBeVisible({ timeout: 15000 });

    await page.reload({ waitUntil: 'domcontentloaded' });
    await expect(page.getByRole('heading', { name: issueTitle })).toBeVisible({ timeout: 15000 });
    await expect(page.getByText(commentText, { exact: false })).toBeVisible({ timeout: 15000 });
  });
});
