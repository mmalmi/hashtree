import type { Page } from '@playwright/test';
import { existsSync, readFileSync } from 'fs';
import { getPublicKey, nip19 } from 'nostr-tools';
import { ensureLoggedIn, waitForAppReady } from './test-utils.js';
import { resolveNativeFixtureBinaries } from './native-binaries.js';

export type NostrStoreWindow = Window & {
  __nostrStore?: {
    getState?: () => { npub?: string | null };
  };
};

export function ensureGitRemoteHtreeBinary(): string {
  return resolveNativeFixtureBinaries().gitRemoteHtree;
}

export function resolveNpubFromKeysFile(keysPath: string): string | null {
  if (!existsSync(keysPath)) return null;
  const content = readFileSync(keysPath, 'utf-8');
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const [secret] = trimmed.split(/\s+/);
    if (!secret) continue;
    try {
      if (secret.startsWith('nsec1')) {
        const decoded = nip19.decode(secret);
        if (decoded.type === 'nsec') {
          const pubkey = getPublicKey(decoded.data as Uint8Array);
          return nip19.npubEncode(pubkey);
        }
      } else if (/^[0-9a-fA-F]{64}$/.test(secret)) {
        const bytes = Uint8Array.from(secret.match(/.{2}/g)!.map(byte => parseInt(byte, 16)));
        const pubkey = getPublicKey(bytes);
        return nip19.npubEncode(pubkey);
      }
    } catch {
      // Try next key entry.
    }
  }
  return null;
}

export async function readCurrentGitHistory(page: Page) {
  return page.evaluate(async () => {
    const { getTree, LinkType } = await import('/src/store.ts');
    const { useCurrentDirCid } = await import('/src/stores/index.ts');
    const { getCommitViewData, getHead, getLog } = await import('/src/utils/git.ts');

    const rootCid = useCurrentDirCid();
    if (!rootCid) {
      throw new Error('No current repo directory CID');
    }
    const tree = getTree();

    const logResult = await getLog(rootCid, { depth: 20, debug: true });
    const commits = logResult.commits;
    const head = await getHead(rootCid);
    const commitView = await getCommitViewData(rootCid, 'HEAD');

    const packDir = await tree.resolvePath(rootCid, '.git/objects/pack');
    const packEntries = packDir && packDir.type === LinkType.Dir
      ? (await tree.listDirectory(packDir.cid)).map((entry: { name: string }) => entry.name)
      : [];

    return {
      commitCount: commits.length,
      commitMessages: commits.map(commit => commit.message.trim()),
      debug: logResult.debug,
      head,
      packEntries,
      commitView: commitView ? {
        oid: commitView.commit.oid,
        message: commitView.commit.message.trim(),
        stats: commitView.stats,
        diffText: commitView.diffText,
      } : null,
    };
  });
}

export async function ensureGitSession(page: Page) {
  await waitForAppReady(page);
  await ensureLoggedIn(page);
  await waitForAppReady(page);
}
