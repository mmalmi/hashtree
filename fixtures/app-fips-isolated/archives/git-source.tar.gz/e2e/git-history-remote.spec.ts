import { test, expect } from './fixtures';
import {
  setupPageErrorHandler,
  configureBlossomServers,
  ensureLoggedIn,
  gotoGitApp,
  useLocalRelay,
  waitForAppReady,
  waitForRelayConnected,
} from './test-utils.js';
import {
  ensureGitRemoteHtreeBinary,
  ensureGitSession,
  readCurrentGitHistory,
  resolveNpubFromKeysFile,
} from './git-history.helpers';

function installGitHistoryBeforeEach() {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await gotoGitApp(page);
  });
}

test.describe('Git history remote compatibility', () => {
  installGitHistoryBeforeEach();

  test('git-remote-htree packed repos should keep Iris Git history compatible', async ({ page, relayUrl }) => {
    test.setTimeout(180000);
    page.setDefaultTimeout(60000);

    await ensureGitSession(page);

    const fs = await import('fs/promises');
    const path = await import('path');
    const { spawnSync } = await import('child_process');
    const os = await import('os');

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'iris-git-remote-pack-'));
    const sourceDir = path.join(tmpDir, 'source');
    const configDir = path.join(tmpDir, '.hashtree');
    const dataDir = path.join(tmpDir, 'data');
    const repoName = `iris-git-pack-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const blossomUrl = process.env.PW_TEST_BLOSSOM_URL ?? 'http://127.0.0.1:18780';

    const gitRemoteHtree = ensureGitRemoteHtreeBinary();

    const env = {
      ...process.env,
      HOME: tmpDir,
      PATH: `${path.dirname(gitRemoteHtree)}:${process.env.PATH}`,
      NOSTR_RELAYS: relayUrl,
      HTREE_CONFIG_DIR: configDir,
      HTREE_DATA_DIR: dataDir,
      HTREE_PREFER_LOCAL_RELAY: '0',
      HTREE_PREFER_LOCAL_DAEMON: '0',
      HTREE_GIT_PACK_CHECKPOINT_MIN_OBJECTS: '1',
    };

    const git = (args: string[], cwd: string) => {
      const result = spawnSync('git', args, {
        cwd,
        env,
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      const output = `${result.stdout ?? ''}${result.stderr ?? ''}`;
      if (result.status !== 0) {
        throw new Error(`git ${args.join(' ')} failed with exit ${result.status}\n${output}`);
      }
      return output;
    };

    try {
      await fs.mkdir(sourceDir, { recursive: true });
      await fs.mkdir(dataDir, { recursive: true });
      await fs.mkdir(configDir, { recursive: true });
      await fs.writeFile(path.join(configDir, 'config.toml'), [
        '[server]',
        'enable_auth = false',
        '',
        '[nostr]',
        `relays = ["${relayUrl}"]`,
        '',
        '[blossom]',
        `read_servers = ["${blossomUrl}"]`,
        `write_servers = ["${blossomUrl}"]`,
        '',
      ].join('\n'));

      await useLocalRelay(page, relayUrl);
      await configureBlossomServers(page, blossomUrl);
      await waitForRelayConnected(page, 30000);

      git(['init', '-b', 'master'], sourceDir);
      git(['config', 'user.email', 'pack-test@example.com'], sourceDir);
      git(['config', 'user.name', 'Pack Test'], sourceDir);

      await fs.writeFile(path.join(sourceDir, 'README.md'), '# Remote Helper Pack Test\n');
      git(['add', 'README.md'], sourceDir);
      git(['commit', '-m', 'Initial commit'], sourceDir);

      await fs.mkdir(path.join(sourceDir, 'src'));
      await fs.writeFile(path.join(sourceDir, 'src', 'index.ts'), 'export const version = 1;\n');
      await fs.writeFile(path.join(sourceDir, 'README.md'), '# Remote Helper Pack Test\n\nfirst update\n');
      git(['add', 'README.md', 'src/index.ts'], sourceDir);
      git(['commit', '-m', 'Add source file'], sourceDir);

      await fs.writeFile(path.join(sourceDir, 'src', 'index.ts'), 'export const version = 2;\n');
      git(['add', 'src/index.ts'], sourceDir);
      git(['commit', '-m', 'Update source version'], sourceDir);

      const remoteUrl = `htree://self/${repoName}`;
      git(['remote', 'add', 'origin', remoteUrl], sourceDir);
      const pushOutput = git(['push', 'origin', 'HEAD:master'], sourceDir);
      const npub = pushOutput.match(/npub1[a-z0-9]{58}/)?.[0] ?? resolveNpubFromKeysFile(path.join(configDir, 'keys'));
      if (!npub) {
        throw new Error(`Could not resolve published repo npub\n${pushOutput}`);
      }

      await page.goto(`/git.html#/${npub}/${repoName}`, { waitUntil: 'domcontentloaded' });
      await waitForAppReady(page, 60000);
      await useLocalRelay(page, relayUrl);
      await configureBlossomServers(page, blossomUrl);
      await waitForRelayConnected(page, 30000);

      const fileList = page.locator('[data-testid="file-list"]').first();
      await expect(fileList.getByRole('link', { name: 'README.md', exact: true })).toBeVisible({ timeout: 60000 });
      await expect(fileList.getByRole('link', { name: '.git', exact: true })).toBeVisible({ timeout: 30000 });

      const result = await readCurrentGitHistory(page);

      expect(result.packEntries.some((name: string) => name.endsWith('.pack'))).toBe(true);
      expect(result.packEntries.some((name: string) => name.endsWith('.idx'))).toBe(true);
      expect(result.debug).toContain('Using native git reader');
      expect(result.debug).not.toContain('Fast log empty with HEAD present, falling back to wasm-git slow path');
      expect(result.debug.some((line: string) => line.startsWith('Slow path found'))).toBe(false);
      expect(result.head).toMatch(/^[a-f0-9]{40}$/);
      expect(result.commitCount).toBe(3);
      expect(result.commitMessages).toContain('Initial commit');
      expect(result.commitMessages).toContain('Add source file');
      expect(result.commitMessages).toContain('Update source version');
      expect(result.commitView?.oid).toBe(result.head);
      expect(result.commitView?.message).toBe('Update source version');
      expect(result.commitView?.stats.files).toBe(1);
      expect(result.commitView?.diffText).toContain('src/index.ts');
      expect(result.commitView?.diffText).toContain('-export const version = 1;');
      expect(result.commitView?.diffText).toContain('+export const version = 2;');
    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true });
    }
  });

  test('git history modal should handle repos without commits gracefully', async ({ page }) => {
    test.setTimeout(60000);
    page.setDefaultTimeout(60000);

    await waitForAppReady(page, 60000);
    await ensureLoggedIn(page, 60000);

    // Test getLog with a minimal .git structure that has no actual commits
    const result = await page.evaluate(async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const tree = getTree();

      // Create minimal .git structure with HEAD pointing to non-existent ref
      const headContent = new TextEncoder().encode('ref: refs/heads/main\n');
      const { cid: headCid } = await tree.putFile(headContent);
      const { cid: emptyDir } = await tree.putDirectory([]);

      // Build .git/refs/heads (empty - no actual branch files)
      const { cid: headsDir } = await tree.putDirectory([]);

      // Build .git/refs directory
      let { cid: refsDir } = await tree.putDirectory([]);
      refsDir = await tree.setEntry(refsDir, [], 'heads', headsDir, 0, LinkType.Dir);

      // Build .git directory
      let { cid: gitDir } = await tree.putDirectory([]);
      gitDir = await tree.setEntry(gitDir, [], 'HEAD', headCid, headContent.length, LinkType.Blob);
      gitDir = await tree.setEntry(gitDir, [], 'refs', refsDir, 0, LinkType.Dir);
      gitDir = await tree.setEntry(gitDir, [], 'objects', emptyDir, 0, LinkType.Dir);

      // Build root with .git directory
      let { cid: rootCid } = await tree.putDirectory([]);
      rootCid = await tree.setEntry(rootCid, [], '.git', gitDir, 0, LinkType.Dir);

      // Try to get log - should not throw, should return empty array
      const { getLog } = await import('/src/utils/git.ts');

      try {
        const commits = await getLog(rootCid);
        return {
          success: true,
          commits,
          error: null
        };
      } catch (err) {
        return {
          success: false,
          commits: null,
          error: err instanceof Error ? err.message : String(err)
        };
      }
    });

    // getLog should succeed and return empty array (not throw)
    expect(result.success).toBe(true);
    expect(result.commits).toEqual([]);
    expect(result.error).toBeNull();
  });
});
