import { expect, test, type Page } from './fixtures';
import { randomUUID } from 'node:crypto';
import { startLocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { evaluateWithRetry, waitForAppReady, waitForWorkerAdapter } from './test-utils';
import { getPublicKey, nip19 } from 'nostr-tools';
import { BOOTSTRAP_SECKEY, FOLLOW_SECKEY, FOLLOW2_SECKEY } from './nostr-test-keys';

const FIPS_DEVICE_SECKEY = new Uint8Array(32);
FIPS_DEVICE_SECKEY[FIPS_DEVICE_SECKEY.length - 1] = 9;
const FIPS_DEVICE_SECRET_HEX = Array.from(FIPS_DEVICE_SECKEY, (byte) => byte.toString(16).padStart(2, '0')).join('');
const FIPS_DEVICE_PUBKEY = getPublicKey(FIPS_DEVICE_SECKEY);

async function waitForInitialGitFipsIdentity(page: Page): Promise<void> {
  await expect.poll(async () => evaluateWithRetry(page, async () => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    const stats = getGitFipsRuntime()?.getStats();
    return !!stats?.active && stats.localXOnlyPubkey.length === 64;
  }, undefined, 5).catch(() => false), { timeout: 60_000, intervals: [100, 250, 500] }).toBe(true);
}

test('git worker reads a missing block through the FIPS provider bridge', async ({ page }) => {
  await page.goto('/git.html');
  await waitForAppReady(page);
  await waitForWorkerAdapter(page);
  await waitForInitialGitFipsIdentity(page);

  const result = await evaluateWithRetry(page, async () => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => {
        get(hash: Uint8Array): Promise<Uint8Array | null>;
        setP2PProvider(provider: {
          fetch(hashHex: string, peerId?: string, htl?: number): Promise<Uint8Array | null>;
          listPeerIds(): string[];
        } | null): void;
        webrtcProxy?: unknown;
      } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');

    const expected = new TextEncoder().encode(`git-fips-provider-${crypto.randomUUID()}`);
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', expected));
    const hashHex = Array.from(digest, (byte) => byte.toString(16).padStart(2, '0')).join('');
    const providerPeerId = `02` + '4'.repeat(64);
    const requests: Array<{ hashHex: string; peerId?: string; htl?: number }> = [];
    adapter.setP2PProvider({
      fetch: async (requestedHashHex, peerId, htl) => {
        requests.push({ hashHex: requestedHashHex, peerId, htl });
        return requestedHashHex === hashHex ? expected.slice() : null;
      },
      listPeerIds: () => [providerPeerId],
    });

    const loaded = await adapter.get(digest);
    return {
      loaded: loaded ? new TextDecoder().decode(loaded) : null,
      expected: new TextDecoder().decode(expected),
      providerPeerId,
      requests,
      legacyProxyActive: adapter.webrtcProxy != null,
    };
  }, undefined, 5);

  expect(result.loaded).toBe(result.expected);
  expect(result.requests).toEqual([{
    hashHex: expect.stringMatching(/^[0-9a-f]{64}$/),
    peerId: result.providerPeerId,
    htl: 10,
  }]);
  expect(result.legacyProxyActive).toBe(false);
});

test('Nostr account switches preserve the independent FIPS device identity', async ({ page }) => {
  await page.addInitScript((secretKeyHex: string) => {
    localStorage.setItem('iris-git:test-fips-secret-key', secretKeyHex);
  }, FIPS_DEVICE_SECRET_HEX);
  await page.goto('/git.html');
  await waitForAppReady(page);
  await waitForWorkerAdapter(page);
  await waitForInitialGitFipsIdentity(page);

  const identities: Array<{ pubkey: string; nsec: string }> = [FOLLOW_SECKEY, FOLLOW2_SECKEY].map((secret) => ({
    pubkey: getPublicKey(secret),
    nsec: nip19.nsecEncode(secret),
  }));
  const peerIds: string[] = [];

  for (const identity of identities) {
    const switched = await evaluateWithRetry(page, async ({ nsec, pubkey }) => {
      const { loginWithNsec } = await import('/src/nostr/index.ts');
      if (!await loginWithNsec(nsec, false)) return null;

      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      const adapter = (window as typeof window & {
        __getWorkerAdapter?: () => { getFollowDistance(pubkey: string): Promise<number> } | null;
        __nostrStore?: { getState?: () => { pubkey?: string | null } };
      }).__getWorkerAdapter?.();
      if (!adapter) throw new Error('worker adapter is not ready after account switch');
      const stats = getGitFipsRuntime()?.getStats();
      return {
        nostrPubkey: (window as typeof window & {
          __nostrStore?: { getState?: () => { pubkey?: string | null } };
        }).__nostrStore?.getState?.().pubkey ?? null,
        fipsPubkey: stats?.localXOnlyPubkey ?? null,
        fipsPeerId: stats?.localPeerId ?? null,
        workerRootDistance: await adapter.getFollowDistance(pubkey),
      };
    }, identity, 5);

    expect(switched).toEqual({
      nostrPubkey: identity.pubkey,
      fipsPubkey: FIPS_DEVICE_PUBKEY,
      fipsPeerId: expect.stringMatching(/^(02|03)[0-9a-f]{64}$/),
      workerRootDistance: 0,
    });
    expect(switched!.fipsPubkey).not.toBe(switched!.nostrPubkey);
    peerIds.push(switched!.fipsPeerId!);
  }

  expect(peerIds[1]).toBe(peerIds[0]);
});

test('connected Git browsers exchange events and cached files on the same peer connection', async ({ browser, relayUrl }) => {
  // Two additional reload phases keep the original 60-second peer deadline.
  test.setTimeout(360_000);
  const diagnostics: string[] = [];
  const peerRelayUrl = `${relayUrl}/${randomUUID()}`;
  const seed = await startLocalFipsWebSocketSeed();
  const contexts = await Promise.all([browser.newContext(), browser.newContext()]);
  try {
    const pages = await Promise.all(contexts.map(async (context, index) => {
      const nsec = nip19.nsecEncode(index === 0 ? BOOTSTRAP_SECKEY : FOLLOW_SECKEY);
      await context.addInitScript(({ secret, relay, seedUrl }) => {
        localStorage.setItem('hashtree:loginType', 'nsec');
        localStorage.setItem('hashtree:nsec', secret);
        // Stale adverts from earlier tests and public seed peers must not consume
        // these two browsers' connection slots. Exercise their real local WebRTC link.
        window.__testRelayUrl = relay;
        window.__testFipsWebsocketSeedUrls = [seedUrl];
      }, { secret: nsec, relay: peerRelayUrl, seedUrl: seed.url });
      const page = await context.newPage();
      page.on('console', message => { if (['error', 'warning'].includes(message.type())) diagnostics.push(message.text()); });
      await page.goto('/git.html');
      await waitForAppReady(page);
      await waitForWorkerAdapter(page);
      return page;
    }));

    await Promise.all(pages.map((page) => expect.poll(async () => evaluateWithRetry(page, async () => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      return getGitFipsRuntime()?.getStats().localPeerId ?? '';
    }, undefined, 5).catch(() => ''), { timeout: 60_000, intervals: [250, 500] }).not.toBe('')));
    const localPeerIds = await Promise.all(pages.map((page) => evaluateWithRetry(page, async () => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      return getGitFipsRuntime()?.getStats().localPeerId ?? '';
    }, undefined, 5)));
    expect(localPeerIds[0]).not.toBe(localPeerIds[1]);

    await Promise.all(pages.map((page, index) => expect.poll(async () => evaluateWithRetry(page, async (targetPeerId) => {
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      return getGitFipsRuntime()?.getStats().peers.some((peer) => (
        peer.connected && peer.peerId === targetPeerId
      )) ?? false;
    }, localPeerIds[index === 0 ? 1 : 0], 5).catch(() => false), {
      timeout: 60_000,
      intervals: [250, 500],
    }).toBe(true)));

    // Event and file traffic must succeed after their server backends are disabled.
    await Promise.all(pages.map(page => evaluateWithRetry(page, async () => {
      const adapter = window.__getWorkerAdapter?.();
      if (!adapter) throw new Error('worker not ready');
      await adapter.setRelays([]);
      await adapter.setBlossomServers([]);
    }, undefined, 5)));

    const signedEvent = await evaluateWithRetry(pages[0], async () => {
      const { nostr } = await import('/src/nostr/client.ts');
      const event = await nostr.signEvent({ kind: 1, content: `peer-note-${crypto.randomUUID()}` });
      const receipt = await nostr.publish(event);
      return { ...event, receipt };
    }, undefined, 5);
    const receivedEvent = await evaluateWithRetry(pages[1], async (eventId) => {
      const adapter = window.__getWorkerAdapter?.();
      if (!adapter?.queryEvents) throw new Error('event reader not ready');
      return adapter.queryEvents([{ ids: [eventId] }], { deadline: Date.now() + 10_000 });
    }, signedEvent.id, 5);
    expect(receivedEvent.events.map(event => event.id), JSON.stringify({ receipt: signedEvent.receipt, result: receivedEvent, diagnostics })).toContain(signedEvent.id);

    const block = await evaluateWithRetry(pages[0], async () => {
      const adapter = (window as typeof window & {
        __getWorkerAdapter?: () => { put(hash: Uint8Array, data: Uint8Array): Promise<boolean> } | null;
      }).__getWorkerAdapter?.();
      if (!adapter) throw new Error('source worker adapter is not ready');
      const text = `git-fips-e2e-${crypto.randomUUID()}`;
      const bytes = new TextEncoder().encode(text);
      const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
      const stored = await adapter.put(digest, bytes);
      if (!stored) throw new Error('source block was not stored');
      return { hash: Array.from(digest), text };
    }, undefined, 5);

    const result = await evaluateWithRetry(pages[1], async ({ hash }) => {
      const adapter = (window as typeof window & {
        __getWorkerAdapter?: () => { get(hash: Uint8Array): Promise<Uint8Array | null> } | null;
      }).__getWorkerAdapter?.();
      if (!adapter) throw new Error('reader worker adapter is not ready');
      const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
      let fetchError: string | null = null;
      let loaded: string | null = null;
      try {
        const bytes = await adapter.get(new Uint8Array(hash));
        loaded = bytes ? new TextDecoder().decode(bytes) : null;
      } catch (error) {
        fetchError = error instanceof Error ? error.message : String(error);
      }
      return {
        fetchError,
        loaded,
        providerPeerIds: await getGitFipsRuntime()?.getP2PProvider().listPeerIds() ?? [],
      };
    }, block, 5);

    expect(result).toEqual({
      fetchError: null,
      loaded: block.text,
      providerPeerIds: expect.arrayContaining([localPeerIds[0]]),
    });

    // Prove live recovery before closing either browser. Each new random block
    // is created after its sender reloads and is fetched from that exact peer,
    // with no worker cache or HTTP fallback on the receiving path.
    for (const endpoint of [0, 1]) {
      const sender = pages[endpoint], receiver = pages[1 - endpoint];
      await sender.reload();
      await waitForAppReady(sender);
      await waitForWorkerAdapter(sender);
      await Promise.all(pages.map((page, index) => expect.poll(async () => evaluateWithRetry(page, async (targetPeerId) => {
        const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
        const stats = getGitFipsRuntime()?.getStats();
        return {
          localPeerId: stats?.localPeerId ?? '',
          connected: stats?.peers.some(peer => peer.connected && peer.peerId === targetPeerId) ?? false,
        };
      }, localPeerIds[1 - index], 5).catch(() => null), {
        timeout: 60_000, intervals: [250, 500],
      }).toEqual({ localPeerId: localPeerIds[index], connected: true })));
      await Promise.all(pages.map(page => evaluateWithRetry(page, async () => {
        const adapter = window.__getWorkerAdapter?.();
        if (!adapter) throw new Error('worker not ready after reload');
        await adapter.setRelays([]);
        await adapter.setBlossomServers([]);
      }, undefined, 5)));
      const fresh = await evaluateWithRetry(sender, async () => {
        const adapter = (window as typeof window & {
          __getWorkerAdapter?: () => { put(hash: Uint8Array, data: Uint8Array): Promise<boolean> } | null;
        }).__getWorkerAdapter?.();
        if (!adapter) throw new Error('source worker not ready after reload');
        const data = crypto.getRandomValues(new Uint8Array(32_000));
        const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
        if (!await adapter.put(hash, data)) throw new Error('fresh source block was not stored');
        return {
          hashHex: Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join(''),
          bytes: data.length,
        };
      }, undefined, 5);
      const recovered = await evaluateWithRetry(receiver, async ({ fresh, peerId }) => {
        const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
        const runtime = getGitFipsRuntime();
        if (!runtime) throw new Error('receiver runtime not ready after reload');
        const provider = runtime.getP2PProvider();
        const data = await provider.fetch(fresh.hashHex, peerId, 0);
        return {
          providerPeerIds: await provider.listPeerIds(),
          bytes: data?.length ?? 0,
          hashHex: data ? Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new Uint8Array(data))),
            byte => byte.toString(16).padStart(2, '0')).join('') : null,
        };
      }, { fresh, peerId: localPeerIds[endpoint] }, 5);
      expect(recovered.providerPeerIds).toContain(localPeerIds[endpoint]);
      expect(recovered.bytes).toBe(fresh.bytes);
      expect(recovered.hashHex).toBe(fresh.hashHex);
      console.log('PEER_RELOAD_RECOVERY', JSON.stringify({
        app: 'iris-git', endpoint, reloaded: true, identityPreserved: true,
        peerRecovered: true, receiverPath: 'targeted-p2p-provider',
        freshHash: fresh.hashHex, bytes: recovered.bytes,
      }));
    }

    // The receiver keeps both kinds of data and its account after rebuilding
    // the worker. Its original peer and all network access can disappear.
    const savedKey = await pages[1].evaluate(() => localStorage.getItem('hashtree:nsec'));
    await contexts[0].close();
    await pages[1].reload();
    await waitForAppReady(pages[1]);
    await waitForWorkerAdapter(pages[1]);
    await contexts[1].setOffline(true);
    const retained = await pages[1].evaluate(async ({ id, hash }) => {
      const adapter = window.__getWorkerAdapter?.();
      if (!adapter) throw new Error('receiver worker not ready');
      const events = await adapter.queryEvents([{ ids: [id] }], { cache: 'cache-only' });
      const bytes = await adapter.get(new Uint8Array(hash));
      return {
        events: events.events.map(event => event.id),
        text: bytes ? new TextDecoder().decode(bytes) : null,
        secret: localStorage.getItem('hashtree:nsec'),
      };
    }, { id: signedEvent.id, hash: block.hash });
    expect(retained).toEqual({ events: [signedEvent.id], text: block.text, secret: savedKey });
  } finally {
    await Promise.all(contexts.map((context) => context.close()));
    await seed.close();
  }
});
