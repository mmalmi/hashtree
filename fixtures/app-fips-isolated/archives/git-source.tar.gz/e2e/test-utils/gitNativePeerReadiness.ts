import { expect, type Page } from '../fixtures';

/** A routed endpoint is authenticated by FSP, even when its carrier is a seed. */
export async function configureNativeGitFipsRoute(page: Page, peerId: string, timeoutMs = 60_000) {
  await page.evaluate(async (remotePeerId: string) => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    const runtime = getGitFipsRuntime();
    const adapter = window.__getWorkerAdapter?.();
    if (!runtime || !adapter) throw new Error('Git FIPS runtime or worker adapter is not ready');
    runtime.setBlobRoutes([{ peerId: remotePeerId, htl: 10 }]);
    adapter.setP2PProvider(runtime.getP2PProvider());
  }, peerId);

  // A carrier must be ready, but the exact native destination need not be an
  // adjacent WebRTC peer. The end-to-end probe below authenticates that target.
  await expect.poll(() => page.evaluate(async () => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    return (getGitFipsRuntime()?.getP2PProvider().listConnectedPeerIds().length ?? 0) > 0;
  }), { timeout: timeoutMs, intervals: [250] }).toBe(true);

  const proof = await page.evaluate(async (remotePeerId: string) => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    const runtime = getGitFipsRuntime();
    const adapter = window.__getWorkerAdapter?.();
    if (!runtime || !adapter) throw new Error('Git FIPS runtime or worker adapter is not ready');
    const hash = crypto.getRandomValues(new Uint8Array(32));
    const hashHex = Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join('');
    // Worker.has checks the same hashtree-worker Dexie store used by this
    // provider. A cache hit must not satisfy network readiness, even if this
    // fresh random hash collided.
    const cachedBefore = await adapter.has(hash);
    if (cachedBefore) throw new Error('Native readiness probe hash is already cached');
    const win = window as typeof window & { __gitNativePeerProbe?: Record<string, unknown> };
    const result: Record<string, unknown> = { targetPeerId: remotePeerId, hash: hashHex,
      cachedBefore, htl: 0, startedAt: Date.now() };
    win.__gitNativePeerProbe = result;
    try {
      // An explicit peer argument forbids provider substitution. HTL=0 asks
      // that endpoint's local store only. A valid MISSING reply proves a live
      // authenticated TCP/FIPS exchange; timeouts and errors propagate.
      const bytes = await runtime.getP2PProvider().fetch(hashHex, remotePeerId, 0);
      result.missing = bytes === null;
      result.finishedAt = Date.now();
      if (bytes !== null) throw new Error('Fresh native readiness probe unexpectedly returned content');
      return result;
    } catch (error) {
      result.error = String(error);
      throw error;
    }
  }, peerId);
  expect(proof).toMatchObject({ targetPeerId: peerId, cachedBefore: false, htl: 0, missing: true });
  await expect.poll(() => page.evaluate(async (remotePeerId: string) => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    return getGitFipsRuntime()?.getStats().peers.some(peer => (
      peer.peerId === remotePeerId && peer.sessionsEstablished > 0
    )) === true;
  }, peerId), { timeout: timeoutMs, intervals: [250] }).toBe(true);
  return proof;
}

/** Failure observer: reads counters and the probe record, without any retry. */
export async function readNativeGitFipsDiagnostics(page: Page) {
  return page.evaluate(async () => {
    const { getGitFipsRuntime } = await import('/src/lib/gitFipsRuntime.ts');
    const runtime = getGitFipsRuntime();
    const provider = runtime?.getP2PProvider();
    return {
      probe: (window as typeof window & { __gitNativePeerProbe?: unknown }).__gitNativePeerProbe ?? null,
      runtime: runtime?.getStats() ?? null,
      adjacentPeerIds: provider?.listConnectedPeerIds() ?? [],
      seedTransport: provider?.webSocketTransport?.stats() ?? null,
    };
  });
}
