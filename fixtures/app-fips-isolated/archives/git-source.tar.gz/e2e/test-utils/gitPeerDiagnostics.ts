import type { Page } from '@playwright/test';

/** Read already-loaded state only: never retry resolution, fetch blocks, or repair routes. */
export async function readGitPeerFailureState(page: Page): Promise<unknown> {
  return page.evaluate(async () => {
    const [{ getRouteSync, useCurrentDirCid }, { getCurrentRootCid }, { getGitFipsRuntime }] = await Promise.all([
      import('/src/stores/index.ts'),
      import('/src/actions/route.ts'),
      import('/src/lib/gitFipsRuntime.ts'),
    ]);
    const summarizeCid = (value: { hash: Uint8Array; key?: Uint8Array } | null) => value ? {
      hash: Array.from(value.hash, byte => byte.toString(16).padStart(2, '0')).join(''),
      hasKey: Boolean(value.key),
    } : null;
    const route = getRouteSync();
    const runtime = getGitFipsRuntime()?.getStats();
    const win = window as typeof window & {
      __gitForkReadinessTrace?: unknown[];
      __getWorkerAdapter?: () => { ready?: boolean } | null;
      __nostrStore?: { getState?: () => { connectedRelays?: number } };
    };
    return {
      // Query values can contain link keys; preserve names, never their values.
      urlPath: location.pathname,
      route: { npub: route.npub, treeName: route.treeName, path: route.path.slice(0, 16), parameterNames: [...route.params.keys()] },
      rootCid: summarizeCid(getCurrentRootCid()),
      directoryCid: summarizeCid(useCurrentDirCid()),
      readinessTrace: win.__gitForkReadinessTrace ?? [],
      workerReady: win.__getWorkerAdapter?.()?.ready ?? null,
      connectedRelays: win.__nostrStore?.getState?.().connectedRelays ?? null,
      fips: runtime ? {
        active: runtime.active,
        localPeerId: runtime.localPeerId,
        connectedPeerIds: runtime.connectedPeerIds.slice(0, 16),
        blobRoutes: runtime.blobRoutes.slice(0, 16),
        peers: runtime.peers.slice(0, 16),
      } : null,
    };
  });
}
