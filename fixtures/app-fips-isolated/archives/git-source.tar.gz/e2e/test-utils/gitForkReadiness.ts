import type { Page } from '@playwright/test';

export async function waitForCurrentRepoLoaded(
  page: Page,
  npub: string,
  repoName: string,
  waitForAppReady: (page: Page) => Promise<void>,
  timeoutMs: number = 90000,
) {
  const startedAt = Date.now();
  const expectedPath = `/git.html#/${npub}/${repoName}`;
  while (Date.now() - startedAt < timeoutMs) {
    const url = new URL(page.url());
    if (url.pathname !== '/git.html' || !url.hash.startsWith(`#/${npub}/${repoName}`)) {
      await page.goto(expectedPath, { waitUntil: 'domcontentloaded' });
      await waitForAppReady(page);
    }

    const loaded = await page.evaluate(async ({ ownerNpub, repositoryName }) => {
      const { getRouteSync, useCurrentDirCid } = await import('/src/stores/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRootCommit, isGitRepo } = await import('/src/utils/git.ts');

      const route = getRouteSync();
      const dirCid = useCurrentDirCid();
      const rootCid = getCurrentRootCid();
      const summarizeCid = (value: typeof dirCid) => value ? {
        hash: Array.from(value.hash, byte => byte.toString(16).padStart(2, '0')).join(''),
        hasKey: Boolean(value.key),
      } : null;
      const win = window as typeof window & { __gitForkReadinessTrace?: Array<Record<string, unknown>> };
      const sample: Record<string, unknown> = {
        at: Date.now(), expected: { npub: ownerNpub, treeName: repositoryName },
        route: { npub: route.npub, treeName: route.treeName, path: route.path.slice(0, 16) },
        rootCid: summarizeCid(rootCid), directoryCid: summarizeCid(dirCid), stage: 'root-and-directory',
      };
      const trace = win.__gitForkReadinessTrace ??= [];
      trace.push(sample);
      if (trace.length > 32) trace.shift();
      if (!rootCid || !dirCid) {
        sample.result = 'missing-cid';
        return false;
      }

      if (
        route.npub !== ownerNpub ||
        route.treeName !== repositoryName ||
        route.path.length !== 0
      ) {
        sample.result = 'route-mismatch';
        return false;
      }

      sample.stage = 'is-git-repository';
      const isRepo = await isGitRepo(dirCid);
      sample.isRepo = isRepo;
      if (!isRepo) {
        sample.result = 'not-git-repository';
        return false;
      }
      sample.stage = 'root-commit';
      const rootCommit = await getRootCommit(dirCid);
      sample.rootCommit = rootCommit;
      sample.result = rootCommit ? 'ready' : 'missing-root-commit';
      return !!rootCommit;
    }, { ownerNpub: npub, repositoryName: repoName });

    if (loaded) {
      return;
    }
    await page.waitForTimeout(750);
  }

  throw new Error(`Repository readiness did not complete within ${timeoutMs}ms: ${npub}/${repoName}`);
}

