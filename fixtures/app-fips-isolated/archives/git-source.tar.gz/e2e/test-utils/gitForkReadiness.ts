import type { Page } from '@playwright/test';

export async function waitForCurrentRepoLoaded(
  page: Page,
  npub: string,
  repoName: string,
  waitForAppReady: (page: Page) => Promise<void>,
  timeoutMs: number = 90000,
) {
  const startedAt = Date.now();
  const expectedPath = `/git.html#/${npub}/${repoName}`;
  while (Date.now() - startedAt < timeoutMs) {
    const url = new URL(page.url());
    if (url.pathname !== '/git.html' || !url.hash.startsWith(`#/${npub}/${repoName}`)) {
      await page.goto(expectedPath, { waitUntil: 'domcontentloaded' });
      await waitForAppReady(page);
    }

    const loaded = await page.evaluate(async ({ ownerNpub, repositoryName }) => {
      const { getRouteSync, useCurrentDirCid } = await import('/src/stores/index.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { getRootCommit, isGitRepo } = await import('/src/utils/git.ts');

      const route = getRouteSync();
      const dirCid = useCurrentDirCid();
      if (!getCurrentRootCid() || !dirCid) {
        return false;
      }

      if (
        route.npub !== ownerNpub ||
        route.treeName !== repositoryName ||
        route.path.length !== 0 ||
        !(await isGitRepo(dirCid))
      ) {
        return false;
      }

      return !!(await getRootCommit(dirCid));
    }, { ownerNpub: npub, repositoryName: repoName });

    if (loaded) {
      return;
    }
    await page.waitForTimeout(750);
  }

  throw new Error(`Repository readiness did not complete within ${timeoutMs}ms: ${npub}/${repoName}`);
}

