import { test as base, expect, type Browser } from '../fixtures';
import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from './localFipsWebSocketSeed';

// A private, process-owned rendezvous seed makes these peer fixtures self-contained.
export const test = base.extend<{ fipsSeed: LocalFipsWebSocketSeed }>({
  fipsSeed: async ({}, use) => {
    const seed = await startLocalFipsWebSocketSeed();
    try { await use(seed); } finally { await seed.close(); }
  },
  context: async ({ context, fipsSeed }, use) => {
    await context.addInitScript((url: string) => { window.__testFipsWebsocketSeedUrls = [url]; }, fipsSeed.url);
    await use(context);
  },
  browser: async ({ browser, fipsSeed }, use) => {
    const create = browser.newContext.bind(browser);
    const wrapped = new Proxy(browser, {
      get(target, prop, receiver) {
        if (prop === 'newContext') return async (options?: Parameters<Browser['newContext']>[0]) => {
          const context = await create(options);
          await context.addInitScript((url: string) => { window.__testFipsWebsocketSeedUrls = [url]; }, fipsSeed.url);
          return context;
        };
        return Reflect.get(target, prop, receiver);
      },
    });
    await use(wrapped as Browser);
  },
});
export { expect };
export type { Page } from '../fixtures';
