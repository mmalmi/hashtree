import path from 'node:path';
import assert from 'node:assert/strict';
import { expect } from '@playwright/test';
import { fileURLToPath } from 'node:url';
import { runPortableSmoke } from './portable-smoke-lib.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');

runPortableSmoke({
  distDir: path.join(appDir, 'iris-git'),
  title: 'Iris Git',
  appName: 'git',
  screenshotPath: path.join(appDir, 'test-results', 'git-iris-portable-smoke.png'),
  validatePage: async (page) => {
    const appUrl = page.url();
    const reader = await page.context().browser().newContext({ javaScriptEnabled: false });
    try {
      const guide = await reader.newPage();
      for (const width of [1280, 390]) {
        await guide.setViewportSize({ width, height: 900 });
        for (const file of ['about.html', 'iris-git-vs-github.html', 'quickstart.html', 'agents.html', 'how-it-works.html']) {
          const response = await guide.goto(new URL(file, appUrl).href);
          assert.equal(response?.status(), 200);
          await expect(guide.locator('h1')).toBeVisible();
          assert.ok((await guide.locator('main').innerText()).length > 900);
          assert.equal(await guide.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
          if (file === 'about.html') {
            await expect(guide.locator('.actions a').first()).toHaveText('Install Git helper ↓');
            await guide.getByRole('link', { name: 'Install Git helper', exact: false }).click();
            await expect(guide.getByRole('heading', { name: '1. Install', exact: true })).toBeInViewport();
            await expect(guide.locator('#install pre').first()).toContainText('cargo install --locked hashtree-cli@0.3.1 git-remote-htree@0.3.0');
            await guide.locator('label[for="install-cargo"]').click();
            await expect(guide.getByRole('radio', { name: 'Cargo', exact: true })).toBeChecked();
            await expect(guide.locator('#install-cargo-panel')).toBeVisible();
            await expect(guide.locator('#install-cargo-panel code')).toHaveText('cargo install --locked hashtree-cli@0.3.1 git-remote-htree@0.3.0');
            await expect(guide.locator('#install-prebuilt-panel')).toBeHidden();
            await guide.locator('#install').screenshot({ path: path.join(appDir, 'test-results', `git-install-cargo-${width}.png`) });
            await guide.keyboard.press('ArrowLeft');
            await expect(guide.getByRole('radio', { name: 'Pre-built', exact: true })).toBeChecked();
            await expect(guide.locator('#install-prebuilt-panel')).toBeVisible();
            await expect(guide.locator('#install-cargo-panel')).toBeHidden();
            await guide.evaluate(() => scrollTo(0, 0));
            await guide.screenshot({ path: path.join(appDir, 'test-results', `git-about-${width}.png`), fullPage: true });
          }
          if (file === 'agents.html') {
            await guide.screenshot({ path: path.join(appDir, 'test-results', `git-agents-${width}.png`), fullPage: true });
          }
        }
      }
      await guide.getByRole('link', { name: 'GitHub comparison', exact: true }).click();
      await expect(guide.getByRole('heading', { name: 'Iris Git vs GitHub', exact: true })).toBeVisible();
      await guide.getByRole('link', { name: 'Open app', exact: false }).click();
      await expect(guide.getByRole('link', { name: 'About Iris Git', exact: true })).toBeVisible();
    } finally {
      await reader.close();
    }
    await expect(page.getByRole('button', { name: 'My Profile (double-click for users)' })).toBeVisible();
    const existingKey = await page.evaluate(() => localStorage.getItem('hashtree:nsec'));
    assert.match(existingKey ?? '', /^nsec1/);
    await page.evaluate(async () => { await navigator.serviceWorker.ready; });
    await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
    await page.context().setOffline(true);
    await page.reload();
    await page.goto(new URL('./', page.url()).href);
    await expect(page.getByRole('button', { name: 'My Profile (double-click for users)' })).toBeVisible();
    assert.equal(await page.evaluate(() => localStorage.getItem('hashtree:nsec')), existingKey);
    await page.getByRole('link', { name: 'About Iris Git', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Git hosting without signup', exact: true })).toBeVisible();
    await page.getByRole('link', { name: 'GitHub comparison', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Iris Git vs GitHub', exact: true })).toBeVisible();
    await page.getByRole('link', { name: 'Open app', exact: false }).click();
    await expect(page.getByRole('button', { name: 'My Profile (double-click for users)' })).toBeVisible();
    assert.equal(await page.evaluate(() => localStorage.getItem('hashtree:nsec')), existingKey);
  },
}).catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
