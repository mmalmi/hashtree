import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import test from 'node:test';
import { Window } from 'happy-dom';

const dist = new URL('../iris-git/', import.meta.url);
const files = ['about.html', 'iris-git-vs-github.html', 'quickstart.html', 'agents.html', 'how-it-works.html'];

test('information pages ship readable HTML, metadata, and matching structured data', () => {
  for (const file of files) {
    const html = readFileSync(new URL(file, dist), 'utf8');
    const window = new Window();
    window.document.write(html);
    const doc = window.document;
    assert.equal(doc.querySelectorAll('h1').length, 1, file);
    assert.ok(doc.querySelector('main').textContent.length > 900, file);
    assert.ok(doc.title.includes('Iris Git'), file);
    assert.ok(doc.querySelector('meta[name="description"]').content.length > 60, file);
    assert.equal(doc.querySelector('link[rel="canonical"]').getAttribute('href'), `https://git.iris.to/${file}`);
    assert.equal(doc.querySelector('meta[property="og:url"]').content, `https://git.iris.to/${file}`);
    assert.equal(doc.querySelectorAll('script:not([type="application/ld+json"])').length, 0, file);
    assert.equal(doc.querySelector('meta[name="robots"]')?.content.includes('noindex') ?? false, false);
    const data = JSON.parse(doc.querySelector('script[type="application/ld+json"]').textContent);
    assert.equal(data.headline, doc.querySelector('h1').textContent);
    assert.equal(data.url, `https://git.iris.to/${file}`);
    assert.equal(doc.querySelector('time').getAttribute('datetime'), data.dateModified);
  }
});

test('all page navigation and assets resolve in the portable build, including under a path prefix', () => {
  for (const file of files) {
    const window = new Window();
    window.document.write(readFileSync(new URL(file, dist), 'utf8'));
    for (const el of window.document.querySelectorAll('a[href], link[rel="stylesheet"], link[rel="icon"]')) {
      const href = el.getAttribute('href');
      if (/^https?:/.test(href)) continue;
      assert.ok(href.startsWith('./'), `${file}: ${href} must be portable`);
      const url = new URL(href, `https://example.test/portable/${file}`);
      assert.ok(url.pathname.startsWith('/portable/'), `${file}: ${href}`);
      const target = url.pathname.slice('/portable/'.length) || 'index.html';
      assert.ok(existsSync(new URL(target, dist)), `${file}: missing ${target}`);
    }
  }
});

test('sitemap lists each public information page and robots permits crawling', () => {
  const sitemap = readFileSync(new URL('sitemap.xml', dist), 'utf8');
  const window = new Window();
  const xml = new window.DOMParser().parseFromString(sitemap, 'application/xml');
  const urls = Array.from(xml.querySelectorAll('loc'), (el) => el.textContent);
  assert.deepEqual(urls.sort(), ['https://git.iris.to/', ...files.map((file) => `https://git.iris.to/${file}`)].sort());
  assert.ok(urls.every((url) => !url.includes('#')));
  const robots = readFileSync(new URL('robots.txt', dist), 'utf8');
  assert.match(robots, /User-agent: \*\s+Allow: \//);
  assert.match(robots, /Sitemap: https:\/\/git\.iris\.to\/sitemap\.xml/);
});

test('agent documentation index links to readable guides and the maintained plugin', () => {
  const index = readFileSync(new URL('llms.txt', dist), 'utf8');
  for (const file of files) assert.ok(index.includes(`https://git.iris.to/${file}`), file);
  assert.ok(index.includes('https://github.com/mmalmi/hashtree/blob/master/docs/agents.md'));
  assert.ok(index.includes('https://github.com/mmalmi/hashtree/blob/master/plugins/hashtree-git/README.md'));
});

test('app has a discovery link without JavaScript and the installed app caches information pages', () => {
  const html = readFileSync(new URL('index.html', dist), 'utf8');
  assert.match(html, /<noscript>[\s\S]*href="\.\/about\.html"/);
  const sw = readFileSync(new URL('sw.js', dist), 'utf8');
  for (const file of [...files, 'learn.css']) assert.ok(sw.includes(file), `${file} must be precached`);
});
