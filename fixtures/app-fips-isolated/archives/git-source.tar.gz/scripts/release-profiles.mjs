export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  git: {
    name: 'git',
    appName: 'Iris Git',
    distDir: 'iris-git',
    treeName: 'git',
    defaultWorkerName: 'iris-git',
    defaultRoutes: ['git.iris.to/*'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_GIT',
    pagesProjectEnv: 'CF_PAGES_PROJECT_GIT',
    buildCommand: ['pnpm', 'run', 'build:git'],
    testCommands: [
      ['node', '--test', './scripts/test-git-info-pages.mjs'],
      ['pnpm', 'run', 'test:e2e:git'],
      ['pnpm', 'exec', 'vitest', 'run', 'tests/gitPortableBuildConfig.test.ts'],
      ['node', './scripts/smoke-git-iris-portable.mjs'],
      ['node', './scripts/smoke-graph-policy.mjs', 'git'],
    ],
  },
};

export const releaseProfileNames = ['git'];
