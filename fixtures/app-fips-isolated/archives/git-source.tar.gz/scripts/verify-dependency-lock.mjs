import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const manifest = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
const lockfile = await readFile(new URL('pnpm-lock.yaml', root), 'utf8');

// Hashtree v0.5.27 source 9eb201a26dd6a0a914f9a480b6a33621ca9e635e
// SHA256SUMS digest 5f1c177f3cf7f0aebe8ba6eb42a4932242b1ca8fc13cf2f98a8fc67a200c877e
const releases = {
  "@fips/browser": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-browser-0.0.19.tgz",
    "sha512-f2TqiQ+XKSupPtYnjtHBSWSVocVa8RT26xivVf4FbcipH6t/bOSCBuHuWoY2crozj7MRrtqImGsq/reulVy+Ng=="
  ],
  "@fips/core": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-core-0.0.54.tgz",
    "sha512-Ugzc8fdCr634XcExsGRC8oQpC5ZgJdiejt71N8auSlhJxFhf5tZcdR+dlbSYrlvQDh73jvyBkfXVeqQquR/Z6A=="
  ],
  "@fips/tcp": [
    "https://github.com/mmalmi/fips-tcp/releases/download/fips-tcp-v0.2.4/fips-tcp-0.2.3.tgz",
    "sha512-0j7ucAgb7SFLkHHKMjJmR4v29psVmGoShiSgpba5IgJqAT/lJGTTKlHoAItKie+oNsiPGf/ww4YMuLTRYov2TA=="
  ],
  "@fips/transport-webrtc": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-transport-webrtc-0.0.58.tgz",
    "sha512-JLhrH4onQBbMkuJgApyc9ADLUVDegPywVSA9+UnrSI9zkftIKwGD7fKBKigq5pCW3NQkoLG8KxJPiHTLvsswag=="
  ],
  "@fips/transport-websocket": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-transport-websocket-0.0.12.tgz",
    "sha512-vblFMNIcC4wWSAHrnnAP39spJZeaUTJpNesWGMzx7AJJqT0yt94j0wSCoujiXsXGLbDXajI6OkrPkgOcQSCNGA=="
  ],
  "@hashtree/collection": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-collection-0.2.11.tgz",
    "sha512-FI6cVBneXSgOEAEeZH6Yv12eC+pZpG2kTCHc9Bt4+bW6Vu0nVNo5V3Gtt5Dk9p8l7G47sq/R9CBbo6A0D+dVwA=="
  ],
  "@hashtree/core": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-core-0.4.0.tgz",
    "sha512-hdqjU1MoGjc55BL5WM93jgVxW7cYOWCWHcYUl5glUT8boEinFfmlmnhyjGp7TNwWgxZKQ7Rgag9XiyDnRUGBUA=="
  ],
  "@hashtree/dexie": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-dexie-0.1.13.tgz",
    "sha512-i34YCDwA+d4puwtC2f+4NreOLRC/RRTOe3PDHXctJvaqg2Ig+xpGcb2I1cbjjCY0cVJ8/BTemNYrH0LfXckPwQ=="
  ],
  "@hashtree/fips-transport": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.38/hashtree-fips-transport-0.5.0.tgz",
    "sha512-1hUDOllGMrhtcfs9YosXqdNE7VVqEhe45uHB92AK4UTrlTFitin6NVWTdGnDVNBImPA2doPkJSmBdlBMF4N17A=="
  ],
  "@hashtree/git": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-git-0.1.10.tgz",
    "sha512-fhSXJCF6h6iG9d3PYFehptTDAYda8fCgfy/DhunKiRzj8UAsDa1LufFOf4l+EC4QdsBXi3btr+U6F1SNRIK4cA=="
  ],
  "@hashtree/index": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-index-0.1.15.tgz",
    "sha512-EnXs4hE0fxCzQfruEsjO9YVBTpzb3Rr1k1vF6p7gLgpZ2oIEg4DEv/pZji9uj7/qJYqOa+EsZTjA0lT0SZozdA=="
  ],
  "@hashtree/mesh": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-mesh-0.3.3.tgz",
    "sha512-fiLvKjbEO1J/fuj6wcLGjI3RPsPrGgSuc2O+QqN/vX3OSHI7uPS+feH49vFduUMHYM79Yvsrq6MV2XDUiGq59A=="
  ],
  "@hashtree/nostr": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.40/hashtree-nostr-0.2.7.tgz",
    "sha512-ah0pS1PDckTkz/QntsNn9D9aFPcJWb7BDjBvaVtY9gaWryiWMvXv0QaGbTU5aGIqRd32BLmnojNDXHPJ/IkIhQ=="
  ],
  // Worker graph policy: public product 8bf1de1272a39fb0616c22133d429ac21d12094f (v0.5.35).
  "@hashtree/worker": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.41/hashtree-worker-0.4.25.tgz",
    "sha512-viUPl2JUtrfJENEWZPvaTtT5x73Pvj5EmHn7qjsTP5T01uOg0tDm7xJww3cf6x23LILi6drOh97ss0WWYq/KVA=="
  ],
  // Iris Kit runtime-v0.2.7 source e2c82fbb882a464ade57b60b70f44336244337a9
  "@iris/hashtree-app": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.8/iris-hashtree-app-0.1.7.tgz",
    "sha512-EgmybUbEREH5efTJ2l6IjWyZ4ZTdYn8ncKPX8S6x63hhpgIVwaPaPj7Qvo+P9c11e91o+x8zDW05McyIG94hnA=="
  ],
  "@iris/release-tools": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.6/iris-release-tools-0.1.1.tgz",
    "sha512-bBFZ0hyyf+6uAmYE8IKpo5vV8BH2zLy9mQEq/LY9wmv6Aa7CvKn+4fHI21TyO2jTV2rjkV0/mF8vW0dtVs7HNA=="
  ],
  "@iris/svelte-ui": [
    "file:vendor/iris-svelte-ui-3d26f8c.tgz",
    "sha512-pmwjeuzSlGbrBlO5QByjNDFvC0L8OgOTZI2XbyUUxU3mJW7v5pNUFPNFSqT2o5VC6gtqATNk5khYu9Iacwk3qw=="
  ],
  "nostr-social-graph": [
    "https://github.com/mmalmi/nostr-social-graph/releases/download/v4.0.4/nostr-social-graph-4.0.4.tgz",
    "sha512-7lMB0fYsjIBQwn/03lY8+0gq41rzifG4hmp5iczjrdBZ/FWQQvkkrH2HGtL80lMhkYr5+UqV63DaBdtoaReDtA=="
  ],
  "@hashtree/nostr-pubsub": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-nostr-pubsub-0.1.9.tgz",
    "sha512-7QfJ1LwAYb8ThdA/ECXJQYxh7BjQk/gTQS+XAfnZvzjxx5YSDRjGj+7bqLtbDdIAPDuIA9dUNYCfH8oj9RLdPQ=="
  ],
  "@iris/identity": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.6/iris-identity-0.3.1.tgz",
    "sha512-HwLi00j/Buf85f//Q4FsKCzvDcidul2U+rNIkfwHZjusNPfJaw6p/Yk4nlKXGkpN4W+TGVj1tZmHGj9Tz8UBAg=="
  ],
  "nostr-pubsub": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.24/nostr-pubsub-0.5.24.tgz",
    "sha512-IYAPHnhLlYpIkUbG0jPCJC3lxXz3In72kqDdmBSpFN0RvP74HpyLhEWBzSP/YA5XRt/1TnqoxeQ2JXL2Q5SYhQ=="
  ],
  "nostr-pubsub-reconcile": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-reconcile-ts-v0.1.1/nostr-pubsub-reconcile-0.1.1.tgz",
    "sha512-hrwY11Np7ufQaqMBQyHJvOjN+fjCfFQ0kTQDzVgALay0ogmP7RLAvDtQmx7U3KOGrGKGoZKLnbeKfsNLCykB+Q=="
  ]
};

const declared = { ...manifest.dependencies, ...manifest.devDependencies };
for (const [name, specifier] of Object.entries(declared)) {
  const verifiedArchive = name === '@iris/svelte-ui' && specifier === releases[name][0];
  if (/^(?:file|link|workspace):/.test(specifier) && !verifiedArchive) {
    throw new Error(`${name} must not depend on a mutable workspace`);
  }
}
if (/\b(?:file|link):\.\.\//.test(lockfile)) {
  throw new Error('Lockfile must not resolve mutable sibling workspaces');
}
// Published runtime archives use exact registry versions; preserve our verified tarball graph.
const workerReleaseOverrides = {
  "@hashtree/fips-transport>@hashtree/core": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-core-0.4.0.tgz",
  "@hashtree/worker>@hashtree/core": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-core-0.4.0.tgz",
  "@hashtree/worker>@hashtree/dexie": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-dexie-0.1.13.tgz",
  "@hashtree/worker>@hashtree/mesh": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-mesh-0.3.3.tgz",
  "@hashtree/worker>@hashtree/nostr": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.40/hashtree-nostr-0.2.7.tgz",
  "@hashtree/worker>@hashtree/nostr-pubsub": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-nostr-pubsub-0.1.9.tgz",
  "@hashtree/nostr>@hashtree/collection": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-collection-0.2.11.tgz",
  "@hashtree/nostr>@hashtree/core": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-core-0.4.0.tgz",
  "@hashtree/nostr>@hashtree/index": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-index-0.1.15.tgz",
  "@hashtree/nostr-pubsub>@hashtree/nostr": "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.40/hashtree-nostr-0.2.7.tgz"
};
for (const [name, specifier] of Object.entries(manifest.pnpm?.overrides ?? {})) {
  const verifiedWorkerOverride = workerReleaseOverrides[name] === specifier;
  const verifiedFipsOverride = name.startsWith('@fips/') && releases[name]?.[0] === specifier;
  if ((name.startsWith('@fips/') || name.startsWith('@hashtree/')) && !verifiedFipsOverride && !verifiedWorkerOverride) {
    throw new Error(`${name} override bypasses the immutable release graph`);
  }
}

for (const [name, [url]] of Object.entries(releases)) {
  if (name in declared && declared[name] !== url) {
    throw new Error(`${name} must use immutable release ${url}`);
  }
}

// Some published dependencies intentionally pin an older release.
const transitiveReleases = [
  [
    "nostr-pubsub-reconcile",
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-reconcile-ts-v0.1.0/nostr-pubsub-reconcile-0.1.0.tgz",
    "sha512-F1UToi75yYrZpt5KFocPUlQH4MeU/J9A/aJBndWUuDvzx1WdQtF99tNxD3KnH2x81R4oaT721hf5OcTdSv8hRg=="
  ],
  [
    "nostr-pubsub",
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.20/nostr-pubsub-0.5.20.tgz",
    "sha512-1Cwdk2LR4oCtxiOR1t5+KmdrzDUKrqZfbIZzpXrOR0g+Ex3DCZ33him/qPWU/iYTChPl9eUgi1ZdhL0KdQWZWQ=="
  ],
  [
    "nostr-pubsub",
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.15/nostr-pubsub-0.5.15.tgz",
    "sha512-59CecbZTYxPjY0zBBvZwhbQsC9bwTkTYBKUG2v+tePw90KfUmzEolQus/CzwYns4MJNeQHq4oVYXfw7cVvDMbA=="
  ],
  [
    "@fips/core",
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-core-0.0.54.tgz",
    "sha512-Ugzc8fdCr634XcExsGRC8oQpC5ZgJdiejt71N8auSlhJxFhf5tZcdR+dlbSYrlvQDh73jvyBkfXVeqQquR/Z6A=="
  ]
];
const expected = Object.entries(releases)
  .map(([name, [url, integrity]]) => [name, url, integrity])
  .concat(transitiveReleases);

for (const [name, url, integrity] of expected) {
  if (url.startsWith('file:')) {
    const archive = await readFile(new URL(url.slice(5), root));
    const actualIntegrity = `sha512-${createHash('sha512').update(archive).digest('base64')}`;
    if (actualIntegrity !== integrity) throw new Error(`${name} archive differs from its verified Iris Kit commit`);
  }
  const quotedKey = `  '${name}@${url}':`;
  const plainKey = `  ${name}@${url}:`;
  const start = Math.max(lockfile.indexOf(quotedKey), lockfile.indexOf(plainKey));
  const end = lockfile.indexOf('\n\n', start);
  const entry = start >= 0 ? lockfile.slice(start, end < 0 ? undefined : end) : '';
  if (!entry.includes(`tarball: ${url}`) || !entry.includes(`integrity: ${integrity}`)) {
    throw new Error(`${name} lock entry is missing its verified release integrity`);
  }
}

for (const script of ['build:git', 'test:unit', 'test:e2e:git']) {
  if (!manifest.scripts?.[script]?.startsWith('pnpm run verify:dependency-lock')) {
    throw new Error(`${script} must verify immutable dependency integrity first`);
  }
}

// Reject a second, unverified copy of a runtime package, including registry versions.
const verifiedPackages = new Set(expected.map(([name, url]) => `${name}@${url}`));
const packageSection = lockfile.split('\npackages:\n')[1].split('\nsnapshots:\n')[0];
for (const [, key] of packageSection.matchAll(/^  '?([^'\n]+?)'?:$/gm)) {
  if (/^(?:@(?:hashtree|fips|iris)\/|nostr-(?:pubsub(?:-reconcile)?|social-graph)@)/.test(key) && !verifiedPackages.has(key)) {
    throw new Error(`Unverified runtime package in lockfile: ${key}`);
  }
}

console.log('Verified immutable Iris Git runtime release integrity');
