import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const manifest = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
const lockfile = await readFile(new URL('pnpm-lock.yaml', root), 'utf8');

// Hashtree v0.5.27 source 9eb201a26dd6a0a914f9a480b6a33621ca9e635e
// SHA256SUMS digest 5f1c177f3cf7f0aebe8ba6eb42a4932242b1ca8fc13cf2f98a8fc67a200c877e
// Hashtree v0.5.42 (core, dexie) source 42ab7c8bae8a94823e286addfa9d5ca1e8332053
// SHA256SUMS digest 9ed3352632e459c424ac334abb3b2ed9a568c6b85366a7f7a6d67f3428181563
// Hashtree v0.5.44 (worker) source 934ff13ed98598057e79bf5448f56b0c948e20c9
// SHA256SUMS digest 183e88616583d362d5aede57a08b93e6ac1eeade15276d15c39e8816ca6a26ea
// Hashtree v0.5.40 (nostr) source 1d67d07b3f2fd38038f3c9340ab5e1462b5961d0
const releases = {
  "@fips/browser": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.62/fips-browser-0.0.22.tgz",
    "sha512-/bCzxQoLHE7sOaHKj+beKGZNej6ja5nifG1+enn8PKFqm7KfjmhzZp8RqIgafIkT6MRoQVuIOzv8CMM9WuOmKQ=="
  ],
  "@fips/core": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.62/fips-core-0.0.57.tgz",
    "sha512-POUsLcusLEBc8gNXRrqP9FPYSUUbaxX3DzvtejEg6rNBaleVCPt3K445DUUj3p6J6vZDag+zolD4bZ9HFoxPHw=="
  ],
  "@fips/tcp": [
    "https://github.com/mmalmi/fips-tcp/releases/download/fips-tcp-v0.2.4/fips-tcp-0.2.3.tgz",
    "sha512-0j7ucAgb7SFLkHHKMjJmR4v29psVmGoShiSgpba5IgJqAT/lJGTTKlHoAItKie+oNsiPGf/ww4YMuLTRYov2TA=="
  ],
  "@fips/transport-webrtc": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.62/fips-transport-webrtc-0.0.61.tgz",
    "sha512-/peMttxBn/uvNfZjMxNf4IRHCs1SawCnIhu6XrGnyMc093acToT7C8R480eCPkNqRq8Q+QTD3J7CE4bR6Tz0OA=="
  ],
  "@fips/transport-websocket": [
    "https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.62/fips-transport-websocket-0.0.15.tgz",
    "sha512-lIY8SHl7ebkQnIHH+kW3Dlh/E1HU1QU0rCs5oB2SneGRm+7fZ6uy8L9FFoJ6/QGwuBERmEetvkZAfBD89EXJyQ=="
  ],
  "@hashtree/collection": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-collection-0.2.11.tgz",
    "sha512-FI6cVBneXSgOEAEeZH6Yv12eC+pZpG2kTCHc9Bt4+bW6Vu0nVNo5V3Gtt5Dk9p8l7G47sq/R9CBbo6A0D+dVwA=="
  ],
  "@hashtree/core": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.42/hashtree-core-0.4.2.tgz",
    "sha512-9gPIe39QJoCUtVo8VhbDOX5bHAtGlJ2EZlQJqKh3l9++2CY1Njg2LINXQWBgKRqB0P2LBKoDpyYz1XIBoJ/SMw=="
  ],
  "@hashtree/dexie": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.42/hashtree-dexie-0.1.14.tgz",
    "sha512-uQ+3Hs3Mdg8yteM9DqIw43+bEGSxhZNj4n8ydIwV/iMz8hBc2+W4o0YrEr/iw2ufxAUF5XHR2ZYfJx00CVVmAQ=="
  ],
  "@hashtree/fips-transport": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.38/hashtree-fips-transport-0.5.0.tgz",
    "sha512-1hUDOllGMrhtcfs9YosXqdNE7VVqEhe45uHB92AK4UTrlTFitin6NVWTdGnDVNBImPA2doPkJSmBdlBMF4N17A=="
  ],
  "@hashtree/git": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-git-0.1.10.tgz",
    "sha512-fhSXJCF6h6iG9d3PYFehptTDAYda8fCgfy/DhunKiRzj8UAsDa1LufFOf4l+EC4QdsBXi3btr+U6F1SNRIK4cA=="
  ],
  "@hashtree/index": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-index-0.1.15.tgz",
    "sha512-EnXs4hE0fxCzQfruEsjO9YVBTpzb3Rr1k1vF6p7gLgpZ2oIEg4DEv/pZji9uj7/qJYqOa+EsZTjA0lT0SZozdA=="
  ],
  "@hashtree/mesh": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-mesh-0.3.3.tgz",
    "sha512-fiLvKjbEO1J/fuj6wcLGjI3RPsPrGgSuc2O+QqN/vX3OSHI7uPS+feH49vFduUMHYM79Yvsrq6MV2XDUiGq59A=="
  ],
  "@hashtree/nostr": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.40/hashtree-nostr-0.2.7.tgz",
    "sha512-ah0pS1PDckTkz/QntsNn9D9aFPcJWb7BDjBvaVtY9gaWryiWMvXv0QaGbTU5aGIqRd32BLmnojNDXHPJ/IkIhQ=="
  ],
  // Worker 0.4.28: 0.4.26 (concurrent chunk reads, shared blob reads, events forwarded before root
  // persistence) plus a working followed-by-friends answer and follow distances that follow
  // follow-list changes.
  "@hashtree/worker": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.44/hashtree-worker-0.4.28.tgz",
    "sha512-VnQFGoeu/uEVWFVCIlcpEGW0SRrFt0lXr9fCMFEHdF3h4fKAPDgtyXF+nRls71zYbKQi5I60814knHFEolrHvw=="
  ],
  // Iris Kit runtime-v0.2.7 source e2c82fbb882a464ade57b60b70f44336244337a9
  "@iris/hashtree-app": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.8/iris-hashtree-app-0.1.7.tgz",
    "sha512-EgmybUbEREH5efTJ2l6IjWyZ4ZTdYn8ncKPX8S6x63hhpgIVwaPaPj7Qvo+P9c11e91o+x8zDW05McyIG94hnA=="
  ],
  "@iris/release-tools": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.6/iris-release-tools-0.1.1.tgz",
    "sha512-bBFZ0hyyf+6uAmYE8IKpo5vV8BH2zLy9mQEq/LY9wmv6Aa7CvKn+4fHI21TyO2jTV2rjkV0/mF8vW0dtVs7HNA=="
  ],
  "@iris/svelte-ui": [
    "file:vendor/iris-svelte-ui-3d26f8c.tgz",
    "sha512-pmwjeuzSlGbrBlO5QByjNDFvC0L8OgOTZI2XbyUUxU3mJW7v5pNUFPNFSqT2o5VC6gtqATNk5khYu9Iacwk3qw=="
  ],
  "nostr-social-graph": [
    "https://github.com/mmalmi/nostr-social-graph/releases/download/v4.0.4/nostr-social-graph-4.0.4.tgz",
    "sha512-7lMB0fYsjIBQwn/03lY8+0gq41rzifG4hmp5iczjrdBZ/FWQQvkkrH2HGtL80lMhkYr5+UqV63DaBdtoaReDtA=="
  ],
  "@hashtree/nostr-pubsub": [
    "https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27/hashtree-nostr-pubsub-0.1.9.tgz",
    "sha512-7QfJ1LwAYb8ThdA/ECXJQYxh7BjQk/gTQS+XAfnZvzjxx5YSDRjGj+7bqLtbDdIAPDuIA9dUNYCfH8oj9RLdPQ=="
  ],
  "@iris/identity": [
    "https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.9/iris-identity-0.4.0.tgz",
    "sha512-ZZ7qRjOXl+7fLqsSrWEn9eOysrsbXDsHQz6uxZZw+4wnw3qZXi3xHVdWAia7ykTmFm3euDjNHA+raG33xjacWg=="
  ],
  "nostr-pubsub": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.28/nostr-pubsub-0.5.28.tgz",
    "sha512-gEiYZyhVP1AKJjVS78+4EZihffGcyMu/jZUYaymsBmVOWtw2+Mk5g4QiUSwZnxUjh/5wuVI096yy/fXDJoEwXw=="
  ],
  "nostr-pubsub-reconcile": [
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-reconcile-ts-v0.1.2/nostr-pubsub-reconcile-0.1.2.tgz",
    "sha512-w2N8AE2bL5h7H0tOuTONOTprHS4/SVCP93lyipA/mekk+RogF3fZFh+s2lxLEDvW5tSjIJcBdX1lguX7wD5+2g=="
  ]
};

const declared = { ...manifest.dependencies, ...manifest.devDependencies };
for (const [name, specifier] of Object.entries(declared)) {
  const verifiedArchive = name === '@iris/svelte-ui' && specifier === releases[name][0];
  if (/^(?:file|link|workspace):/.test(specifier) && !verifiedArchive) {
    throw new Error(`${name} must not depend on a mutable workspace`);
  }
}
if (/\b(?:file|link):\.\.\//.test(lockfile)) {
  throw new Error('Lockfile must not resolve mutable sibling workspaces');
}
// Published runtime archives name plain registry versions of each other. An override
// must point a runtime package at its verified archive so every copy stays on it.
const scopedReleaseOverrides = {
  "@hashtree/fips-transport>nostr-pubsub": releases["nostr-pubsub"][0]
};
for (const [name, specifier] of Object.entries(manifest.pnpm?.overrides ?? {})) {
  const verified = releases[name]?.[0] === specifier || scopedReleaseOverrides[name] === specifier;
  if ((name.startsWith('@fips/') || name.startsWith('@hashtree/')) && !verified) {
    throw new Error(`${name} override bypasses the immutable release graph`);
  }
}

for (const [name, [url]] of Object.entries(releases)) {
  if (name in declared && declared[name] !== url) {
    throw new Error(`${name} must use immutable release ${url}`);
  }
}

// Some published dependencies intentionally pin an older release.
const transitiveReleases = [
  [
    "nostr-pubsub-reconcile",
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-reconcile-ts-v0.1.0/nostr-pubsub-reconcile-0.1.0.tgz",
    "sha512-F1UToi75yYrZpt5KFocPUlQH4MeU/J9A/aJBndWUuDvzx1WdQtF99tNxD3KnH2x81R4oaT721hf5OcTdSv8hRg=="
  ],
  [
    "nostr-pubsub",
    "https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.15/nostr-pubsub-0.5.15.tgz",
    "sha512-59CecbZTYxPjY0zBBvZwhbQsC9bwTkTYBKUG2v+tePw90KfUmzEolQus/CzwYns4MJNeQHq4oVYXfw7cVvDMbA=="
  ]
];
const expected = Object.entries(releases)
  .map(([name, [url, integrity]]) => [name, url, integrity])
  .concat(transitiveReleases);

for (const [name, url, integrity] of expected) {
  if (url.startsWith('file:')) {
    const archive = await readFile(new URL(url.slice(5), root));
    const actualIntegrity = `sha512-${createHash('sha512').update(archive).digest('base64')}`;
    if (actualIntegrity !== integrity) throw new Error(`${name} archive differs from its verified Iris Kit commit`);
  }
  const quotedKey = `  '${name}@${url}':`;
  const plainKey = `  ${name}@${url}:`;
  const start = Math.max(lockfile.indexOf(quotedKey), lockfile.indexOf(plainKey));
  const end = lockfile.indexOf('\n\n', start);
  const entry = start >= 0 ? lockfile.slice(start, end < 0 ? undefined : end) : '';
  if (!entry.includes(`tarball: ${url}`) || !entry.includes(`integrity: ${integrity}`)) {
    throw new Error(`${name} lock entry is missing its verified release integrity`);
  }
}

for (const script of ['build:git', 'test:unit', 'test:e2e:git']) {
  if (!manifest.scripts?.[script]?.startsWith('pnpm run verify:dependency-lock')) {
    throw new Error(`${script} must verify immutable dependency integrity first`);
  }
}

// Reject a second, unverified copy of a runtime package, including registry versions.
const verifiedPackages = new Set(expected.map(([name, url]) => `${name}@${url}`));
const packageSection = lockfile.split('\npackages:\n')[1].split('\nsnapshots:\n')[0];
for (const [, key] of packageSection.matchAll(/^  '?([^'\n]+?)'?:$/gm)) {
  if (/^(?:@(?:hashtree|fips|iris)\/|nostr-(?:pubsub(?:-reconcile)?|social-graph)@)/.test(key) && !verifiedPackages.has(key)) {
    throw new Error(`Unverified runtime package in lockfile: ${key}`);
  }
}

console.log('Verified immutable Iris Git runtime release integrity');
