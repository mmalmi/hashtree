import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { marked } from 'marked';

import {
  GIT_REMOTE_HTREE_INSTALL_COMMAND,
  GIT_REMOTE_HTREE_INSTALL_DOCS_URL,
} from '../src/components/Git/codeDropdownCopy.js';
import { repoRoot, resolveHashtreeRepoRoot, resolveReferenceFile } from './hashtreePaths.mjs';

function resolveHashtreeCcReference(...segments) {
  const candidates = [
    process.env.HASHTREE_CC_REPO_ROOT,
    path.resolve(repoRoot, '..', 'hashtree-cc'),
    path.join(repoRoot, 'hashtree-cc'),
    resolveReferenceFile(...segments),
  ].filter(Boolean);

  for (const candidateRoot of candidates) {
    const candidatePath =
      candidateRoot === resolveReferenceFile(...segments)
        ? candidateRoot
        : path.join(candidateRoot, ...segments);
    if (existsSync(candidatePath)) {
      return candidatePath;
    }
  }

  return path.resolve(repoRoot, '..', 'hashtree-cc', ...segments);
}

const checks = [
  {
    label: 'root README install section',
    path: resolveReferenceFile('README.md'),
    mustInclude: [
      GIT_REMOTE_HTREE_INSTALL_COMMAND,
    ],
  },
  {
    label: 'git-remote-htree README install section',
    path: resolveReferenceFile('rust', 'crates', 'git-remote-htree', 'README.md'),
    mustInclude: [
      GIT_REMOTE_HTREE_INSTALL_COMMAND,
    ],
  },
  {
    label: 'hashtree.cc developers install section',
    path: resolveHashtreeCcReference('apps', 'hashtree-cc', 'src', 'components', 'Developers.svelte'),
    mustInclude: [
      GIT_REMOTE_HTREE_INSTALL_COMMAND,
    ],
  },
  {
    label: 'Code dropdown docs link',
    path: new URL('../src/components/Git/codeDropdownCopy.js', import.meta.url),
    mustInclude: [
      GIT_REMOTE_HTREE_INSTALL_DOCS_URL,
    ],
  },
];

let failed = false;

for (const check of checks) {
  const content = readFileSync(check.path, 'utf8');
  for (const needle of check.mustInclude) {
    if (!content.includes(needle)) {
      console.error(`[git-install-copy] Missing ${JSON.stringify(needle)} in ${check.label}`);
      failed = true;
    }
  }
}

if (failed) {
  process.exit(1);
}

const docsUrl = new URL(GIT_REMOTE_HTREE_INSTALL_DOCS_URL);
const [docsPath, docsQuery] = docsUrl.hash.slice(1).split('?');
assert.equal(docsUrl.origin, 'https://git.iris.to');
assert.ok(docsPath.endsWith('/hashtree/README.md'), 'Install help must link to the hashtree README');
assert.equal(new URLSearchParams(docsQuery).get('anchor'), 'installation');

const hashtreeRoot = resolveHashtreeRepoRoot();
assert.ok(hashtreeRoot, 'Set HASHTREE_REPO_ROOT to check the install-help destination');
const hashtreeReadme = readFileSync(path.join(hashtreeRoot, 'README.md'), 'utf8');
assert.ok(
  marked.lexer(hashtreeReadme).some(token => token.type === 'heading' && token.text === 'Installation'),
  'The linked hashtree README must have an Installation heading',
);

console.log('[git-install-copy] Install copy and the hashtree README Installation link are valid.');
