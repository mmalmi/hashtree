# Iris Git

Git repositories on Nostr and hashtree.
Browser P2P traffic uses Nostr-discovered FIPS WebRTC on the shared `fips-overlay-v1` fabric.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-git>
Live: <https://git.iris.to/>

## Web App

```bash
pnpm install
pnpm run dev
pnpm run build
pnpm run preview
```

This standalone app uses immutable shared Iris package releases.

Product information lives on separate static pages: `/about.html`,
`/iris-git-vs-github.html`, `/quickstart.html`, `/agents.html`, and `/how-it-works.html`.
Edit their shared content and template in `site/pages.mjs` and styles in
`site/styles.css`. Vite serves them in development and emits complete HTML,
`robots.txt`, `sitemap.xml`, and `llms.txt` in the portable build. Review the comparison's
sources and date when changing product claims.

The landing page reuses the Git demo from `hashtree-cc`, identified by
`nhash1qqsqmafutt4u7g4x7cyx0w0k84gs7txg54v7sygkm3aspld3h7ehhyg9ypzx8wcsnd63spv9d3scr4zst2s48mv0yl36lj2c02a6vlms607nkqysxg5`.
`public/git-demo.mp4` is a 720p H.264/AAC copy with fast-start metadata; the poster
is its frame at 40 seconds. It loads only when the visitor starts playback.

## Git remote helper

Build the compatible CLI and Git remote helper with Cargo:

```sh
cargo install --locked hashtree-cli@0.3.1 git-remote-htree@0.3.0
```

## Testing

```bash
pnpm run test:unit
pnpm run test:e2e
pnpm run test:git:iris
```

`test:git:iris` builds the portable Git app and runs the portable smoke test against that exact output.
Native process gates require `htree 0.2.142` built with its `fips-webrtc` feature and
`git-remote-htree` on `PATH`, or explicit `HTREE_BIN` and `GIT_REMOTE_HTREE_BIN` paths:

```sh
cargo install hashtree-cli --version 0.2.142 --locked --features fips-webrtc
```

The gates never build or discover a sibling Rust checkout.

On Apple Silicon macOS, the published fixture tools can be used without replacing
an existing installation. The archive below is from Hashtree source commit
`bf132d40a71f28a171a1eab3defa2c874539bf1b` and includes `fips-webrtc` support:

```sh
mkdir -p .local/native-fixtures/0.2.142
curl -fL https://github.com/mmalmi/hashtree/releases/download/v0.2.142/hashtree-aarch64-apple-darwin.tar.gz -o .local/native-fixtures/0.2.142/archive.tar.gz
echo 'a9658d5d3b36a09192218dc4bfd3a507ad7d8774af60ffbe2a4be10e83730322  .local/native-fixtures/0.2.142/archive.tar.gz' | shasum -a 256 -c -
tar -xzf .local/native-fixtures/0.2.142/archive.tar.gz -C .local/native-fixtures/0.2.142
export HTREE_BIN="$PWD/.local/native-fixtures/0.2.142/hashtree/htree"
export GIT_REMOTE_HTREE_BIN="$PWD/.local/native-fixtures/0.2.142/hashtree/git-remote-htree"
```

## Release

```bash
node ./scripts/release-site.mjs git --dry-run
pnpm run release:git:iris
pnpm run release:all:iris
```

The release script builds once, runs focused tests against the built `iris-git` directory, publishes that directory root to the mutable hashtree `git` tree, and then deploys the same artifact to Cloudflare Worker static assets. If build or tests fail, publish and deploy do not run.

Defaults:

- Worker service: `iris-git`
- Worker route: `git.iris.to/*`
- Hashtree tree: `git`

Set `CF_WORKER_NAME_GIT`, `CF_PAGES_PROJECT_GIT`, or `CF_WORKER_COMPATIBILITY_DATE` only when overriding the default release target.
