# Changelog

## 0.1.18 - 2026-10-04

- Recover file-sharing connections after a browser reload or temporary route failure.
- Preserve verified cached files for sharing and offline use after restarting the app.

## 0.1.17 - 2026-10-01

- Make known peer routes available without waiting for unrelated discovery probes.
- Keep peer connections and transfers working when a delayed connection offer arrives.
- Update the shared contact graph to version 2.0.3.

## 0.1.16 - 2026-10-01

- Update shared peer networking to recover cleanly from rejected handshakes, malformed packets, route failures, and transport restarts.
- Use corrected routing filters, bounded route retries, and native-compatible link feedback to reduce unnecessary background traffic.

## 0.1.15 - 2026-09-30

- Recover peer connections sooner when handshake messages or connection answers are lost.

## 0.1.14 - 2026-09-30

- Restore file sharing when a background worker restarts during startup.
- Route larger peer connection offers over paths that can carry them.
- Resume peer connections promptly after authenticated signaling recovers.

## 0.1.12 - 2026-09-30

- Keep the installed app and existing secret-key session available on a full offline reload.
- Open exact event details as soon as the event arrives, without an unrelated history timeout.

- Replace NDK with one shared pubsub runtime and common identity signers, preserving existing account keys and offline repositories.
- Share public event history and repository blocks through the same authenticated peer connections.
- Pin nostr-pubsub 0.5.12 and Hashtree runtime 0.5.10 with verified release checksums.
- Keep the native/browser repository test independent of public seed availability.

## 0.1.11 - 2026-09-07

- Upgrade to Hashtree runtime 0.5.7, which validates remote content hashes and
  sizes before returning or caching data.
- Pin native test and publishing tools to Hashtree CLI 0.2.142.
- Remove redundant browser navigation waits while retaining session and directory
  readiness checks.
- Keep one complete clone/install dropdown journey, removing its duplicate repository setup.

## 0.1.10 - 2026-07-20

- Upgrade to FIPS TypeScript 0.0.29 and Hashtree FIPS transport 0.4.6 for
  direct FSP negotiation with legacy FMP fallback.
- Bootstrap browser peers through authenticated WebSocket seeds before moving
  WebRTC offers and answers onto FSP port 257.
- Pin native process fixtures to Hashtree CLI 0.2.114 so their daemon exercises
  the same FIPS 0.4.19 transport and WebRTC feature as the browser runtime.

## 0.1.9 - 2026-07-17

- Make the followed-repository process gate exercise the live follow update
  directly instead of rebuilding the same state through a relay reload race.

## 0.1.8 - 2026-07-17

- Pin browser/native process fixtures to the immutable Hashtree CLI 0.2.100
  release while preserving the Hashtree TypeScript 0.5.1 blob wire and router
  boundary.

## 0.1.7 - 2026-07-17

- Bound repository-fork and repository-like subscriptions to active views,
  share one subscription per query, and replay history on revisit instead of
  leaking every viewed repository subscription for the lifetime of the app.

## 0.1.6 - 2026-07-17

- Prevent a slower directory read for an older repository root from replacing
  entries already loaded for a newer root during checkout or navigation.

## 0.1.5 - 2026-07-17

- Upgrade to the immutable Hashtree TypeScript 0.5.1 runtime and its shared
  adaptive `BlobRouter`, keeping repository writes explicit while local,
  authenticated P2P, and Blossom reads use one bounded route contract.
- Widen the shared Iris Hashtree app helpers to the core 0.3 contract without
  copying router or storage behavior into Iris Git.
- Preserve the frozen HTL 10 and browser/native blob wire while surfacing
  provider, timeout, and corruption failures instead of treating them as
  repository misses.
- Pin browser/native process fixtures to the immutable Hashtree CLI 0.2.99 release,
  whose packaged binaries include the required FIPS WebRTC transport, instead of
  accepting an older local binary.
- Settle correlated worker acknowledgements and require the named provider's
  authenticated FIPS session before enabling its HTL 10 test route.

## 0.1.4 - 2026-07-16

- Upgrade to the immutable FIPS TypeScript 0.0.26 runtime so persisted browser
  identities recover cleanly across reloads and stale handshake epochs cannot
  displace the fresh authenticated link.

- Pin the shared Hashtree worker to the exact-provider runtime, preserving HTL
  10 without inferring routes from arbitrary connected peers.
- Preserve repository status across equivalent CID object replacements, avoid
  impossible Blossom writes, and make release publication verification fail
  closed.
- Require the registry Hashtree CLI's `fips-webrtc` feature in native process
  gates, select only the daemon's own advertised identity, and fail immediately
  when Git publication fails.

## 0.1.3 - 2026-07-16

- Replace local and vendored substrate dependencies with immutable FIPS, Hashtree, Iris Kit, and social-graph releases.
- Make remote blob providers explicit, default remote routes to HTL 10, and preserve serve-only behavior when no route is configured.
- Forward the shared worker HTL and provider state without a product-local carrier or implicit connected-peer fallback.
- Isolate native browser fixtures and add registry-only Rust/WebRTC/Git interoperability coverage.
