# Experiments

## Browser navigation setup — 2026-09-08

Five existing Chromium navigation and upload cases waited about 25 seconds
for a redirect and public-tree link that Git home does not provide. The helper
now checks the current route immediately and reads the link only when visible.
It waits for session restoration before login and retains directory, action,
and relay readiness checks.

| Measurement | Before | After |
| --- | --- | --- |
| Median case duration | 27.6 s | 3.1 s |
| Case duration range | 26.8–27.7 s | 2.8–4.7 s |

All five focused cases passed without retries. These measurements describe
those cases, not an estimate of the entire suite's duration.

The clone/install dropdown had two independent real repository setups followed
by the same shared assertions. Both passed in 43.0 s and 42.8 s during the
release gate. One complete journey now retains every assertion and removes
the duplicate setup and its roughly 43-second execution cost.
