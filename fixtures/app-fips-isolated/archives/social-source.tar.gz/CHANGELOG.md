# Changelog

## 0.1.19 - 2026-10-04

- Restore direct peer connections after another browser reloads.
- Keep downloaded public files available to peers after restarting the app.

## 0.1.18 - 2026-10-03

- Keep profile privacy reminders in tooltips instead of repeating them beside name changes, name history, and private details.

## 0.1.17 - 2026-10-03

- Recover missing relay events with bounded optional reconciliation while keeping live updates and cached offline reading available.
- Use the published nostr-pubsub 0.5.14 runtime and shared reconciliation codec.

## 0.1.16 - 2026-10-02

- Keep the app logo and navigation icons available after an offline reload.
- Keep saved Likes available when profile views refresh.

## 0.1.15 - 2026-10-01

- Keep peer connections and transfers working when a delayed connection offer arrives.
- Sync private contact details between linked devices through encrypted sessions, with saved changes retried after reconnecting.
- Keep the media viewer available offline.

## 0.1.14 - 2026-10-01

- Include recent and cached posts in For You, retaining fresh posts as slower archive reads finish.
- Preserve the reading position during feed updates and retry interrupted refreshes.
- Disable browser autocomplete in search inputs.

## 0.1.13 - 2026-10-01

- Paint navigation in its final position before JavaScript loads and open cached pages immediately.
- Load database, search, notification, and overlay code only when needed.
- Remove unused icon dependencies, consolidate Nostr imports, and update compatible runtime and development dependencies.

## 0.1.11 - 2026-10-01

- Open hashtags in post search and preserve search queries in shared links and browser history.
- Format articles with headings, lists, quotes, tables, links, images, and code blocks.
- Add optional browser notifications for replies, mentions, reposts, reactions, and zaps.

## 0.1.10 - 2026-10-01

- Load recent posts on profile pages and keep mention-only posts out of reply filters.
- Preserve browser history when returning quickly to Home.
- Show when people search is still loading alongside cached results.
- Show the full mutual follower count and open followers with people you follow first.
- Remove the redundant Open profile action from profile pages.

## 0.1.9 - 2026-10-01

- Show people selected in search under Recent, with the latest selection first.
- Keep profile visits out of search history, and keep Recent separate for each account.
- Improve profile spacing and show people results from the first typed character.

## 0.1.8 - 2026-10-01

- Add a private Favorites tab in Home for posts from people you have starred.
- Keep remembered contact names until you approve a name change.
- Match Iris Client's checkmark size and show profile checkmarks beside the follow explanation.
- Show people and post suggestions before searching.

## 0.1.7 - 2026-10-01

- Recover recent posts after prolonged index read failures and refresh cached profiles in the background.
- Restore account-relative social graph checkmarks beside names.
- Preserve drafts across reloads and add mention suggestions, quote posts, and public post reports.
- Add content preferences, muted people management, account key backup, and peer connection status.
- Support Nostr extension login and signing through the shared Iris identity package.
- Add Nostr Wallet Connect payments and saved feed filters.

## 0.1.6 - 2026-09-30

- Reduce unnecessary routing traffic and recover peer sessions reliably with the audited FIPS runtime.
- Close canceled peer connections promptly and preserve usable routes during retries.

## 0.1.5 - 2026-09-30

- Recover peer sessions after packet loss and retry connection replies when routes recover.

## 0.1.4 - 2026-09-30

- Route larger peer connection offers over paths that can carry them.
- Resume peer connections promptly after authenticated signaling recovers.

## 0.1.3 - 2026-09-30

- Keep subscription batches within public message server limits.

## Site update - 2026-09-08

- Restore locally stored follows and mute lists even when another archive is unavailable.

- Overlap four ordered reads in the cold first-post probe, sharing the feed
  concurrency limit and releasing the first post without waiting for unused reads.
- Load optional routes and the wallet on navigation intent instead of during
  initial Home loading.

## 0.1.2 - 2026-09-07

- Upgrade to Hashtree runtime 0.5.7, which validates remote content hashes and
  sizes before returning or caching data.
- Keep the initial home feed read open until the visible page fills, painting
  delayed posts as they arrive and preserving the page when navigating Back.
- Read all followed authors in bounded batches and preserve continuation state
  when a read is incomplete.
- Allow release dry runs before build output exists.
- Add a worker-isolated Coco Cashu wallet with trusted mint management,
  Lightning mint/melt flows, token send/receive/reclaim, durable payment
  intents, bounded fee review, replay protection, and signed NIP-57 zaps.
- Match Iris Client's restrained wallet layout with a plain centered balance,
  pill actions, tabbed activity and mints, and no decorative payment copy.
- Place the desktop read-only indicator beside the account controls instead of
  interrupting primary navigation.
- Center card-style dialogs at desktop and mobile sizes with viewport-safe
  scrolling, while keeping the media viewer fullscreen.
- Give profile hero avatars an opaque circular backing that follows the hero
  surface in both light and dark themes.
- Cache consensus BTC exchange rates from Coinbase and Kraken, expose a primary
  display currency, and format wallet balances and post zap totals consistently
  while retaining the last real rate offline.
- Move scrolling to one viewport-wide page root so wheel and touch input work
  across the whole shell while desktop and mobile chrome stays pinned, with
  exact route-keyed restoration for the retained navigation stack.
- Keep a bounded five-view navigation stack mounted so Back/Forward restores
  the same component instances, form state, and per-view scroll positions,
  while pausing media, observers, polling, and overlays in hidden views.
- Move Home feed traversal, decoding, signature verification, filtering,
  sorting, and progressive pagination into the resident Hashtree worker, with
  incremental snapshots and non-blocking verifier warmup for faster first data.
- Reuse bounded immutable profile and post-search catalogs between queries and
  prewarm their authenticated routers so repeated searches avoid redundant
  block reads and ranking work.
- Serve the last real application shell immediately on repeat navigations,
  transactionally rotate its pinned main/worker graph, and keep lazy assets in
  a bounded LRU for reliable offline startup without placeholder content.
- Apply the same 600-effective-line ceiling to TypeScript, JavaScript, and
  Svelte, remove every file-size exception, and split oversized application,
  index, search, catalog, and smoke-test modules into focused units.
- Preserve the suggested starter Home feed and visible card anchor across route
  restoration and background reranking, removing cumulative drift in repeated
  Home/Profile/Back cycles without freezing fresh data.
- Paint a lightweight Iris shell immediately on cold navigation by bundling
  critical application CSS into the HTML response.
- Cache fingerprinted browser assets immutably so repeat visits do not block on
  needless stylesheet and script revalidation.
- Mount the application before restoring the saved live-event overlay, and
  verify its Nostr signatures in the background worker instead of blocking the
  browser's main thread.
- Run independent release checks concurrently on isolated browser ports while
  keeping the timing-sensitive publication proof single-worker.
- Resolve inline mention names through every authenticated profile source,
  progressively replacing stale or nameless kind-0 records with the newest
  signed event instead of treating a generated fallback label as final.
- Restore visible views already present in the route stack without rebuilding
  abandoned async work, while retaining the selected custom feed on reload.
- Ignore stale `imeta` media whose exact URL was removed from ordinary post
  content while preserving tag-only NIP-68 picture-first posts, and verify
  removed composer attachments stay removed.

## 0.1.1 - 2026-07-20

- Upgrade to immutable FIPS TypeScript 0.0.29 and Hashtree FIPS transport
  0.4.6 for direct FSP negotiation with legacy FMP fallback and authenticated
  WebSocket bootstrap before WebRTC link negotiation.
