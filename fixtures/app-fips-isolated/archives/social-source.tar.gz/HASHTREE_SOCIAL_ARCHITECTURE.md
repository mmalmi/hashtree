# Hashtree-first Iris Social

This document defines the target data boundary for Iris Social. It is intentionally
location-neutral: an index publisher may run on a laptop, a large archive host, or
several independent hosts without changing the browser application.

## Invariants

- Signed Nostr events remain the source records.
- Immutable Hashtree roots provide durable history, indexes, and reproducible reads.
- Signed `npub/tree` references announce mutable snapshots; a root is never trusted
  merely because it came from a domain or relay.
- `nostr-pubsub` provides a low-latency tail, not history or an offline mailbox.
- The browser uses one shared FIPS node for Hashtree reads and live event traffic.
- Live peers are explicitly admitted. Discovery does not grant application trust.
- The application remains useful offline and does not require a search or feed API.
- Compatible index publishers can be queried together. Publisher identity and social
  policy remain visible inputs rather than hidden server behavior.
- Archive advancement is append-only at the signed-event boundary: every
  signature-valid event in the accepted baseline root must remain in its successor.
  Equal counts are not evidence of monotonicity.
- Profile, post, reaction, and other content backfill never schedules an author that
  the selected social-graph snapshot classifies as overmuted. Graph-control records
  needed to establish follow/mute consensus do not authorize content backfill.

## Data flow

1. An archive follows a configured social-graph root and ingests valid public Nostr
   events from relays and authenticated pubsub peers.
   It expands the graph independently from content backfill, freezes a versioned graph
   snapshot, and derives an eligible-author frontier after direct-mute and closest-hop
   overmute consensus have been applied.
2. It stores raw events and derived indexes as immutable Hashtree data structures.
3. It publishes advancing catalog roots under signed, named trees.
4. A browser resolves one or more trusted catalogs, fetches only the blocks needed for
   its query, verifies every block, and caches them locally.
5. Scoped `nostr-pubsub` subscriptions add new events to a bounded local overlay.
6. When a newer durable catalog contains an overlay event, the local duplicate can be
   pruned without changing the visible result.

## Event routing

The browser owns one `nostr-pubsub` router. Its durable source is one Hashtree adapter
instance whose per-query root snapshot can contain many root descriptors. Distinct
partition IDs are additive archive/catalog shards; descriptors with the same partition
ID are ordered replicas of one logical dataset. Shared and personal roots may select
different block stores through the same adapter, so adding an index root does not create
another router or adapter instance. A second adapter is justified only by different
trust or query semantics, not by another root.

The bounded live overlay is a separate additive dataset. No relay content reader is
registered: relays carry only scoped mutable-root discovery and detached publication.
During rollout, exact-ID availability comparisons run after browser idle time, never
change displayed state, require durable-dataset provenance, and classify unavailable,
truncated, or incomplete durable reads as inconclusive rather than as a match.

## Archive and event projections

The initial trusted graph covers at least these event kinds:

- `0`: profile metadata
- `1`: short text notes
- `3`: follow lists
- `5`: deletion requests
- `6` and `16`: reposts
- `7`: reactions
- `20`: picture-first posts
- `1111`: comments
- `9735`: zap receipts
- `10000` and relevant `30000` lists: mute and categorized people lists
- `30023`: long-form content

The durable event collection keeps raw signed events by ID and derives indexes for
author/time, kind/time, and the `e`, `p`, `a`, and `t` tags. Replaceable and addressable
events use deterministic timestamp-and-ID winners. Kind-5 tombstones are retained so a
later-arriving target cannot reappear. Raw history remains separate from visible-event
projections so indexing policy can be audited or rebuilt.
For replaceable/addressable ties, the lexically lowest event ID wins as required by
NIP-01; ordinary chronological result ordering remains newest-first.

## Search catalogs

Search is published as a small versioned catalog that points to immutable ranked-search
segments. A catalog identifies its publisher, source event root, schema, generation
time, covered kinds/time range, and segment roots. Readers reject incompatible schemas
and can query several compatible catalogs concurrently.

People ranking uses:

- exact and prefix matches for display name, name, NIP-05, npub, and pubkey;
- Unicode compatibility and accent folding;
- bounded typo tolerance;
- social distance and friends-following as tie-breakers after lexical relevance;
- mute/overmute policy as an explicit viewer or publisher filter.

Post ranking uses BM25F-style field scoring over content, title/summary, hashtags, and
author identifiers. Exact hashtags and quoted phrases retain their semantics. Search
supports kind, author, and time filters, deterministic deduplication across publishers,
bounded top-k work, and partial results when one publisher is unavailable.

Segments are immutable. A publisher appends compact segments during ingestion and
periodically compacts them; readers never need a monolithic index download. Catalog
publication is checkpointed so history backfill does not publish a new root for every
author.

## Live subscriptions

The browser never subscribes to the archive's entire live firehose. It maintains a
small replaceable subscription set for:

- the viewer, their follows, and graph/list updates;
- authors visible in the active feed or profile;
- `e`/`a` thread targets and `e`/`p` engagement targets in the active view;
- a bounded recent replay window after reconnection.

Subscription scopes are replaced as navigation changes. Startup and connection failure
use bounded backoff and recover on later connectivity. All received events are verified,
deduplicated, passed through the same replacement/deletion rules as snapshots, and
bounded before persistence.

## Personal offline state

Each browser keeps a small personal collection containing locally signed events, pending
publishes, and recent live events. Publishing persists first, then races admitted pubsub
peers and configured relays. A failed publish remains in the outbox for later retry.

This personal collection can grow into a user-published Hashtree index containing their
own posts, profile/list state, reactions, and deletions. The personal root can be queried
alongside larger public catalogs without a special server code path.

## Rollout gates

1. Ship snapshot/live overlay semantics and scoped live transport while continuing to
   read the established durable indexes.
2. Run a separately capped archive publisher and verify event-kind coverage, root
   advancement, restart recovery, disk growth, and query correctness. A broad-crawl
   candidate must name the exact graph snapshot and overmute threshold, contain at
   least 100,000 eligible authors, contain no valid content event from an overmuted
   author, and retain every valid event ID from the accepted archive root.
3. Publish ranked people/post catalog candidates and compare them against the established
   indexes in shadow reads.
4. Add people/posts search UI and federated catalog reads.
5. Switch default catalog references only after browser end-to-end tests and production
   smoke checks pass; keep the previous signed roots usable for rollback.
6. Increase graph depth first, then content/history depth after the eligible-author
   census passes. Raise storage caps from measured ingestion and compaction rates;
   never publish a partially covered crawl merely because a size limit was reached.

Every meaningful green slice may be deployed independently; no phase requires replacing
the whole data plane at once.

### Browser social-graph snapshot

The anonymous browser seed is a bounded projection of the same frozen full graph used
by the archive census. It is not downloaded from an API or copied from an ambient
package file. Refresh it only from an explicit `htree socialgraph snapshot` binary,
its lowercase SHA-256, and the matching
`iris-social/social-graph-crawl-census@2` report:

```sh
htree socialgraph snapshot --out full-socialGraph.bin --max-distance 4
GRAPH_SHA256="$(sha256sum full-socialGraph.bin | cut -d' ' -f1)"
pnpm census:social-graph -- \
  --social-graph-file full-socialGraph.bin \
  --social-graph-root <64-hex-root> \
  --social-graph-sha256 "$GRAPH_SHA256" \
  --max-distance 4 \
  --min-eligible-authors 100000 > census.json
pnpm refresh:social-graph-snapshot -- \
  --source full-socialGraph.bin \
  --source-sha256 "$GRAPH_SHA256" \
  --census-report census.json
```

The refresh verifies the census by recomputing it from the exact source, then applies
the Iris Client-compatible 300,000-edge, 1,000-edges-per-node projection. It requires
at least 100,000 eligible source authors, at least 30,000 projected users, preserves
every root direct follow, and caps the browser snapshot at 2,500,000 bytes. It writes
the compact snapshot, direct-follow frontier, generated browser constants, and a
canonical provenance manifest. `pnpm build` verifies all four artifacts and fails on
mixed, stale, or manually replaced bytes; normal builds never regenerate metadata or
bless a changed binary.

### Graph-first broad crawl

Graph expansion and content backfill are separate jobs. A graph-only pass reads kind-3
and kind-10000 lists through the target distance and writes a versioned
`socialGraph.bin`; it does not add those authors' posts, profiles, reactions, or history
to the public archive. Some graph-control lists can be needed before an identity can be
classified by closest-hop mute consensus. That classification never grants content
eligibility.

Before every content pass, run `pnpm census:social-graph` with the exact graph root and
SHA-256. The command fixes the Iris overmute threshold at 1.0, reports counts by follow
distance, fails below the operator's eligible-author floor, and can write a
distance-then-pubkey ordered newline allowlist. The content/history crawler must either
receive only that allowlist or apply the same threshold-1.0 predicate to the same frozen
snapshot before it schedules authors. It must not warm or expand the graph in the same
invocation, and graph-list subscriptions remain outside the content epoch so an author
cannot become overmuted while an old content subscription stays open.

The production census uses report format `iris-social/social-graph-crawl-census@2`.
It binds the graph root, graph snapshot SHA-256, selected distance, threshold, eligible
count, and the exact eligible-author file SHA-256. The bundled content runner recomputes
the census from the snapshot immediately before it starts Hashtree, requires at least
100,000 authors, and serves only that bound file from a temporary loopback listener.
It runs the crawl with no graph warmup and with the external allowlist taking precedence
over graph traversal. Content advances in 64-author logical chunks against one checkpoint
root. Each invocation receives one extra sentinel author; the runner stops only after the
logical chunk's checkpoint report and checkpoint-root file agree, while the sentinel is
still pending. A graph/hash-bound resume manifest then advances atomically. This bounds
the released CLI's per-process report memory without changing Hashtree or sharding the
archive, and a crash can only repeat one idempotent chunk. This keeps graph expansion and
content scheduling in separate epochs without adding a persistent API.

A location-neutral production sequence is:

```sh
htree socialgraph warm --secs 3600 --crawl-depth 3 --full-graph-recrawl
htree socialgraph snapshot --out socialGraph.bin --max-distance 3
sha256sum socialGraph.bin
node census-social-graph.mjs \
  --social-graph-file socialGraph.bin \
  --social-graph-root <64-hex-root> \
  --social-graph-sha256 <64-hex-sha256> \
  --max-distance 3 \
  --min-eligible-authors 100000 \
  --write-eligible-authors eligible-authors.txt > census.json
node run-broad-archive-content.mjs \
  --htree /path/to/verified/htree \
  --data-dir /path/to/isolated/data \
  --social-graph-file socialGraph.bin \
  --census-report census.json \
  --eligible-authors eligible-authors.txt
```

If depth 3 is below the floor, only the graph warm/snapshot/census phase is repeated at
depth 4. A failed census never writes a production allowlist, and the content runner
does not publish an event-index or search-catalog pointer.

The first broad production pass remains held until the selected allowlist contains at
least 100,000 eligible authors. Its candidate immutable root must then pass both the
zero-overmuted-event gate and append-only containment of the accepted baseline before
any catalog pointer changes.

### Separate Market pilot

`src/server/marketArchivePolicy.ts` prepares a finite, opt-in Market index. It does
not expand an existing archive pass or replace its checkpoint. The only admitted
content kinds are public listings (30402), reviews (7368), and deletion records
(5). Profile and follow data keep their existing `npub/nostr-event-index`
references. Clients query these indexes **and** live relays through the same
verified reducers; an expired newest listing must remain a tombstone rather than
revealing an older version.

The pilot allows at most 64 explicit authors, three secure relays, and a fixed
31-day window. Each native invocation processes one author, with four pages by
default, 512 events, 2 MiB of input, and an eight-second timeout per fetch. The
optional private configuration field `maxPagesPerAuthor` accepts only `4` or `8`;
the reviewed two-relay pilot can explicitly select `8`. A full 64-author
pass therefore admits at most 32,768 received events / 128 MiB of event input.
The operation owner must enforce the generated 120-second runtime, one-core CPU,
1 GiB memory and zero-swap limits. At the maximum author count, that is at most
128 minutes of invocation time, excluding separate verification/publication.
Bounded receipt failure is a stop, not permission to widen the window or skip
an unavailable relay.

The pinned native strict reader counts pages across **all** required relays,
including exact-timestamp boundary probes, older-interval reads and capacity/count
probes. Even one event inside the window can require three calls per relay; a
short page is not proof of complete coverage. The eight-page override changes
only this request budget: event/byte/time/CPU/memory bounds, strict relay coverage,
signed readback and publication gates stay the same. Its eight fetch deadlines
total at most 64 seconds within the unchanged 120-second invocation guard; neither
four nor eight pages guarantees coverage of every allowed 31-day window. Selecting
the override changes the namespace, authority hash and native arguments. Prepare
a fresh authority and stage from the reviewed source commit; never edit or reuse
the failed four-page stage to claim eight-page coverage.

The pinned native writer records `coverage_head` for strict runs too. Market
publication requires that original head and its exact content-addressed receipt
bytes: policy, author ordinal, frozen window, previous/final roots and received
event count must match, and **every** required relay must report complete.
Optional pubsub observations cannot substitute for a relay obligation. The
publisher loads these proofs only through the explicit Market authority path;
legacy strict archive validation keeps its existing behavior. Missing, modified
or partial proofs stop publication. Never strip a head or relabel a strict
checkpoint as best-effort to pass the gate.

Preparation runs from the exact reviewed source commit and frozen dependency
lock. New stages use native `htree` 0.3.0 from
`9eb201a26dd6a0a914f9a480b6a33621ca9e635e`. Its Nostr index writer and the
TypeScript writer both produce CHK-v1 seed roots. Existing stages keep their
frozen authority, executable and seed root, including 0.2.151 stages.

Production admission for the new writer requires a separately qualified native
executable with recorded source, build provenance and payload SHA-256. The
0.3.0 parity check used a test build. Production use remains held pending that
qualification. The preparation CLI checks the executable against its reviewed
production payload list before writing a new stage. That list is currently empty.
No binary is downloaded or qualified by this helper. The private JSON input has
the following shape (all paths and actual identity selection remain operational
configuration, never repository defaults):

```json
{
  "format": "iris-social/market-archive-config@1",
  "since": 1798675200,
  "until": 1798761600,
  "relays": ["wss://relay.example"],
  "directory": "/absolute/isolated/staging-parent",
  "protectedDirectories": ["/absolute/existing/archive", "/absolute/existing/daemon"],
  "rendezvousPort": 32111,
  "native": {
    "path": "/absolute/verified/htree",
    "version": "0.3.0",
    "sha256": "<64 lowercase hex characters>",
    "sourceCommit": "9eb201a26dd6a0a914f9a480b6a33621ca9e635e"
  },
  "sourceCommit": "<full reviewed iris-social source commit>",
  "profileIndexRefs": ["<existing public npub>/nostr-event-index"]
}
```

Provide a newline-terminated lowercase-hex author list and 1–16 genuine signed
events from those authors in that interval (at most 256 KiB combined). At least
one must be a listing or review. Fixture keys are for local tests only.

```sh
node scripts/verify-dependency-lock.mjs
node --import tsx scripts/prepare-market-index.ts \
  --config /absolute/private/config.json \
  --authors /absolute/private/authors.txt \
  --seed /absolute/private/signed-events.json
```

This creates an exclusive `market-reviews-v1-<scope hash>` directory containing
the authority, author list, signed seed and isolated native configuration.
The example rendezvous port is illustrative: the operation owner must choose
and reserve an unused non-default loopback port at staging admission. The
pinned native catch-up starts pubsub even with `[sync].enabled = false`, and
its FIPS dependency rejects port zero. The generated configuration therefore
also empties FIPS relay discovery, WebSocket seeds, static peers, Ethernet and
pubsub peer lists; disables UDP, WebRTC and LAN discovery; and pins the selected
`127.0.0.1` rendezvous instead of the host's shared port 21211. Direct catch-up
relays still come from the explicit frozen policy. Changing this port changes
the namespace and authority; never patch an already staged configuration.
Preparation never queries a relay, executes the native binary, starts a service,
or publishes a pointer. A symlink, changed binary, overlapping protected path,
or previously created namespace fails closed. The stage remains for inspection
if a later operation fails.

The production owner then admits a single pilot under its generated operation
lock. Import the seed using the pinned binary's `nostr-index import --events`
with the generated `HTREE_CONFIG_DIR`, `HTREE_DATA_DIR`, and `--data-dir`, and
require the returned root to equal `seed.root`. Keep the source/config/binary
hashes, before/after checkpoints, exit status and protected-file proofs in the
existing `iris-social/archive-catchup-run@1` receipt format. Use
`buildMarketCatchupCommand` to obtain the exact bounded argument list. Record its
physical-space floor once at admission and retain that same floor for every
continuation in this stage: at least 10 GiB remains free, with a 256 MiB write
allowance and a separate 64 MiB reserve. The free-space guard is not a filesystem
quota; measure actual stage growth and stop at the allowance. Do not readmit
another allowance or add an automatic recurring timer to complete a stalled pass.

Publication uses `scripts/publish-archive-checkpoint.ts` and its existing locks,
durable outbox, signature checks, checkpoint lineage, four semantic canaries,
relay confirmations and signed readback. A separate tree is accepted only when
`marketAuthorityFile` is the generated `authority.json`, pinned in
`protectedFiles` with `nativeAuthoritySha256`; its tree, policy, checkpoint,
authors, operation lock and `<stage>/publication` outbox must match exactly.
Market candidates additionally require one-author successful receipts and a
complete, signature-verified read of the whole bounded public corpus. Include
listing, review, deletion and expired-winner semantics in the canary proof;
expected IDs refer to the retained winners after legitimate replacements.
Native seed-root compatibility and real public readback remain deployment gates,
not claims made by the local policy tests.

No current archive pointer, service, author checkpoint, identity or data is
changed by preparation. Before publication, rollback means stopping the isolated
pilot and retaining its stage and receipts. After publication, remove the new
client reference to return to the previous index set; retain both signed roots
and their data. Production ownership includes the exact source/binary receipts,
measured pilot growth, public fetch verification, and explicit acceptance before
any client starts using the additional reference.
