import { readFile, realpath, rm, stat } from 'node:fs/promises';
import { isAbsolute, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { nhashDecode, nhashEncode, type CID, type Hash, type Store } from '@hashtree/core';
import {
  assertPortableFilesystemStore,
  FilesystemBlockStore,
  writeJsonAtomic,
} from '../src/server/filesystemBlockStore';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import { acquireExclusiveFileLock } from '../src/server/exclusiveFileLock';
import {
  assertCliPathsOutsideDirectory,
  assertDisjointMutableCliPaths,
  type NamedCliPath,
} from '../src/server/cliPathSafety';
import {
  createPostSearchPointerTemplate,
  isPostSearchPointerHandoff,
  POST_SEARCH_POINTER_HANDOFF_FORMAT,
  type PostSearchPointerHandoff,
} from '../src/server/postSearchPointer';
import type { PostSearchSnapshotReader } from '../src/server/postSearchProjection';
import { HashtreeNostrSnapshotReader } from '../src/server/postSearchSnapshotReader';
import {
  POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
  FilePostSearchV5RoutedBuilderStateStore,
  type PostSearchV5RoutedBuilderState,
  type PostSearchV5RoutedBuilderStateStore,
} from '../src/server/postSearchV5RoutedBuilderState';
import {
  PostSearchV5RoutedCatalogBuilder,
  type PostSearchV5RoutedBuilderProgress,
} from '../src/server/postSearchV5RoutedCatalogBuilder';
import {
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  readPostSearchV5RoutedCatalog,
} from '../src/server/postSearchV5RoutedCatalog';
import { POST_SEARCH_V5_RUN_MAX_DOCUMENTS } from '../src/server/postSearchV5Run';

export const POST_SEARCH_V5_ROUTED_CLI_EVENT_FORMAT =
  'iris-social/post-search-v5-routed-catalog-operation@1' as const;

const DEFAULT_STORE_TIMEOUT_MS = 30_000;
const DEFAULT_SOURCE_READ_BATCH = 16;
const MAX_BATCH_BYTES = 1024 * 1024 * 1024;
const HEX_64 = /^[0-9a-f]{64}$/;
const TREE_NAME = /^[a-z0-9][a-z0-9._-]{0,127}$/;

const HELP = `Build and fully verify the scalable Iris Social routed post-search catalog.

Required:
  --snapshot-root <nhash>       Exact immutable Hashtree Nostr archive root
  --state-file <absolute path> Fsynced resumable builder state
  --handoff-file <absolute>    Exact unsigned pointer handoff output
  --publisher-id <hex pubkey>  Nostr pubkey that will sign the pointer
  --tree-name <name>           Mutable Hashtree pointer tree/ref name

Store (choose exactly one):
  --store-url <http(s) URL>    Production daemon source/output block API
  --offline-store <absolute>   Portable hashtree-fs source/output CAS

Optional:
  --store-auth-file <absolute> auth.cookie or JSON credentials; URL only
  --store-timeout-ms <ms>      Default 30000; URL only
  --source-read-batch <count>  Concurrent immutable reads; default 16
  --batch-size <count>         Durable run batch; default 5000, max 5000
  --batch-max-bytes <bytes>    Default 67108864, max 1073741824
  --progress-events <count>    Progress interval; default 1000

The builder streams the immutable snapshot, checkpoints only complete bounded
batches, performs deterministic leveled compaction, and fully verifies every
linked routed run before writing an unsigned handoff. It never signs, pins,
publishes, resolves a mutable ref, reads a secret key, or opens daemon LMDB.
Blocks must be retained before the existing publish:post-search command is run.`;

export interface PostSearchV5RoutedCatalogCliOptions {
  snapshotRoot: string;
  storeUrl?: string;
  offlineStore?: string;
  storeAuthFile?: string;
  storeTimeoutMs?: number;
  stateFile: string;
  handoffFile: string;
  publisherId: string;
  treeName: string;
  sourceReadBatch?: number;
  batchSize?: number;
  batchMaxBytes?: number;
  progressEvents?: number;
}

export interface PostSearchV5RoutedCatalogCliResult extends Record<string, unknown> {
  format: typeof POST_SEARCH_V5_ROUTED_CLI_EVENT_FORMAT;
  operation: 'build';
  status: 'verified';
  catalogFormat: typeof POST_SEARCH_V5_ROUTED_CATALOG_FORMAT;
  builderStateFormat: typeof POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT;
  catalogRoot: string;
  sourceRoot: string;
  publisherId: string;
  generatedAt: number;
  documentCount: number;
  runCount: number;
  reachableNodeCount: number;
  maxReachableNodes: number;
  resumed: boolean;
  handoffStatus: 'unsigned-handoff';
  publicationPerformed: false;
}

export interface PostSearchV5RoutedCatalogCliDependencies {
  store?: Store;
  snapshotReader?: PostSearchSnapshotReader;
  stateStore?: PostSearchV5RoutedBuilderStateStore;
  now?: () => number;
  emit?: (record: Record<string, unknown>) => void;
}

export function parsePostSearchV5RoutedCatalogArguments(
  rawArgs: readonly string[],
): PostSearchV5RoutedCatalogCliOptions {
  const args = rawArgs[0] === '--' ? rawArgs.slice(1) : rawArgs;
  const values = new Map<string, string>();
  const known = new Set([
    '--snapshot-root', '--store-url', '--offline-store', '--store-auth-file',
    '--store-timeout-ms', '--state-file', '--handoff-file', '--publisher-id',
    '--tree-name', '--source-read-batch', '--batch-size', '--batch-max-bytes',
    '--progress-events',
  ]);
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid post-search v5 routed argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (key === '--snapshot-store' || key === '--output-store') {
      throw new Error('Direct daemon data directories are unsupported; use --store-url');
    }
    if (!known.has(key)) {throw new Error(`Unknown post-search v5 routed argument: ${key}`);}
    if (values.has(key)) {throw new Error(`Duplicate post-search v5 routed argument: ${key}`);}
    values.set(key, value.trim());
  }

  const storeUrlValue = values.get('--store-url');
  const offlineStoreValue = values.get('--offline-store');
  if (Boolean(storeUrlValue) === Boolean(offlineStoreValue)) {
    throw new Error('Choose exactly one of --store-url or --offline-store');
  }
  const storeAuthFile = values.get('--store-auth-file');
  const storeTimeoutMs = optionalInteger(values, '--store-timeout-ms', 1);
  if ((storeAuthFile || storeTimeoutMs !== undefined) && !storeUrlValue) {
    throw new Error('--store-auth-file and --store-timeout-ms require --store-url');
  }
  const publisherId = required(values, '--publisher-id').toLowerCase();
  if (!HEX_64.test(publisherId)) {
    throw new Error('--publisher-id must be 64 lowercase hexadecimal characters');
  }
  const treeName = required(values, '--tree-name');
  if (!TREE_NAME.test(treeName)) {throw new Error('Invalid --tree-name');}
  return {
    snapshotRoot: canonicalPublicNhash(required(values, '--snapshot-root'), '--snapshot-root'),
    storeUrl: storeUrlValue ? normalizedStoreUrl(storeUrlValue) : undefined,
    offlineStore: offlineStoreValue
      ? absolutePath(offlineStoreValue, '--offline-store')
      : undefined,
    storeAuthFile: storeAuthFile ? absolutePath(storeAuthFile, '--store-auth-file') : undefined,
    storeTimeoutMs,
    stateFile: absolutePath(required(values, '--state-file'), '--state-file'),
    handoffFile: absolutePath(required(values, '--handoff-file'), '--handoff-file'),
    publisherId,
    treeName,
    sourceReadBatch: optionalInteger(values, '--source-read-batch', 1, 1_024),
    batchSize: optionalInteger(
      values,
      '--batch-size',
      1,
      POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
    ),
    batchMaxBytes: optionalInteger(values, '--batch-max-bytes', 1, MAX_BATCH_BYTES),
    progressEvents: optionalInteger(values, '--progress-events', 1),
  };
}

export async function runPostSearchV5RoutedCatalogOperation(
  options: PostSearchV5RoutedCatalogCliOptions,
  dependencies: PostSearchV5RoutedCatalogCliDependencies = {},
): Promise<PostSearchV5RoutedCatalogCliResult> {
  const emit = dependencies.emit ?? (() => undefined);
  const offlineDirectory = options.offlineStore
    ? await validateOfflineStore(options.offlineStore)
    : undefined;
  await validatePostSearchV5RoutedPaths(options, offlineDirectory);
  const store = dependencies.store ?? await createStore(options, offlineDirectory);
  const lock = await acquireExclusiveFileLock(options.stateFile, 'Post-search v5 routed builder');
  try {
    // A failed retry must not leave an older candidate looking publishable.
    await rm(options.handoffFile, { force: true });
    emit(operationEvent('start', {
      sourceRoot: options.snapshotRoot,
      publisherId: options.publisherId,
      batchSize: options.batchSize ?? POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
    }));
    const stateStore = new ReportingStateStore(
      dependencies.stateStore ?? new FilePostSearchV5RoutedBuilderStateStore(options.stateFile),
      emit,
    );
    const result = await new PostSearchV5RoutedCatalogBuilder({
      snapshotRoot: nhashDecode(options.snapshotRoot),
      snapshotReader: dependencies.snapshotReader
        ?? new HashtreeNostrSnapshotReader(
          store,
          options.sourceReadBatch ?? DEFAULT_SOURCE_READ_BATCH,
        ),
      outputStore: store,
      stateStore,
      publisherId: options.publisherId,
      batchSize: options.batchSize,
      batchMaxBytes: options.batchMaxBytes,
      progressEvents: options.progressEvents,
      now: dependencies.now,
      onProgress: (progress) => emit(progressEvent(progress)),
    }).build();
    const catalog = await readPostSearchV5RoutedCatalog(
      new StrictReadOnlyStore(store),
      result.catalogRoot,
      { maxReachableNodeCount: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT },
    );
    if (catalog.manifest.publisherId !== options.publisherId
      || catalog.manifest.source.eventRoot !== options.snapshotRoot) {
      throw new Error('Verified post-search v5 routed catalog metadata does not match the build');
    }
    const handoff = pointerHandoff(options, result.catalogRoot, result.state.generatedAt);
    await writeJsonAtomic(options.handoffFile, handoff);
    const response: PostSearchV5RoutedCatalogCliResult = {
      format: POST_SEARCH_V5_ROUTED_CLI_EVENT_FORMAT,
      operation: 'build',
      status: 'verified',
      catalogFormat: POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
      builderStateFormat: POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
      catalogRoot: nhashEncode(result.catalogRoot),
      sourceRoot: options.snapshotRoot,
      publisherId: options.publisherId,
      generatedAt: result.state.generatedAt,
      documentCount: catalog.manifest.scoring.documentCount,
      runCount: catalog.manifest.runs.length,
      reachableNodeCount: catalog.manifest.reachableNodeCount,
      maxReachableNodes: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
      resumed: result.resumed,
      handoffStatus: 'unsigned-handoff',
      publicationPerformed: false,
    };
    emit(response);
    return response;
  } finally {
    await lock.release();
  }
}

class ReportingStateStore implements PostSearchV5RoutedBuilderStateStore {
  constructor(
    private readonly delegate: PostSearchV5RoutedBuilderStateStore,
    private readonly emit: (record: Record<string, unknown>) => void,
  ) {}

  async load(): Promise<PostSearchV5RoutedBuilderState | null> {
    return await this.delegate.load();
  }

  async save(state: PostSearchV5RoutedBuilderState): Promise<void> {
    await this.delegate.save(state);
    this.emit(operationEvent('checkpoint', {
      status: state.status,
      completedKinds: state.completedKinds.length,
      batchCount: state.batches.length,
      documentCount: state.batches.reduce((sum, batch) => sum + batch.documentCount, 0),
      activeRunCount: state.leveledRuns.runs.length,
      catalogRoot: state.catalogRoot,
    }));
  }
}

class StrictReadOnlyStore implements Store {
  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array | null> {return await this.source.get(hash);}
  async has(hash: Hash): Promise<boolean> {return await this.source.has(hash);}
  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Post-search v5 routed verification is read-only');
  }
  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Post-search v5 routed verification is read-only');
  }
}

function pointerHandoff(
  options: PostSearchV5RoutedCatalogCliOptions,
  catalogRoot: CID,
  createdAt: number,
): PostSearchPointerHandoff {
  const handoff: PostSearchPointerHandoff = {
    format: POST_SEARCH_POINTER_HANDOFF_FORMAT,
    status: 'unsigned-handoff',
    publisherId: options.publisherId,
    catalogRoot: nhashEncode(catalogRoot),
    sourceEventRoot: options.snapshotRoot,
    treeName: options.treeName,
    unsignedEvent: createPostSearchPointerTemplate({
      catalogRoot,
      sourceEventRoot: options.snapshotRoot,
      treeName: options.treeName,
      createdAt,
    }),
    signedEvent: null,
    publication: {
      required: true,
      transport: 'nostr-replaceable-event',
      blockAvailability: 'required-before-event',
    },
  };
  if (!isPostSearchPointerHandoff(handoff)) {
    throw new Error('Refusing invalid post-search v5 routed pointer handoff');
  }
  return handoff;
}

function progressEvent(progress: PostSearchV5RoutedBuilderProgress): Record<string, unknown> {
  return operationEvent('progress', progress as unknown as Record<string, unknown>);
}

function operationEvent(
  phase: 'start' | 'progress' | 'checkpoint',
  details: Record<string, unknown>,
): Record<string, unknown> {
  return {
    format: POST_SEARCH_V5_ROUTED_CLI_EVENT_FORMAT,
    operation: 'build',
    phase,
    ...details,
  };
}

async function createStore(
  options: PostSearchV5RoutedCatalogCliOptions,
  offlineDirectory?: string,
): Promise<Store> {
  if (options.storeUrl) {
    return new HttpBlockStore(options.storeUrl, {
      credentials: await loadCredentials(options.storeAuthFile),
      timeoutMs: options.storeTimeoutMs ?? DEFAULT_STORE_TIMEOUT_MS,
    });
  }
  return new FilesystemBlockStore(offlineDirectory!);
}

async function loadCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const username = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const password = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (username !== undefined || password !== undefined)) {
    throw new Error('Choose an auth file or store auth environment variables, not both');
  }
  if (path) {
    try {return parseHttpBlockStoreCredentials(await readFile(path, 'utf8'));} catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!username || !password) {
    throw new Error('Daemon store requires an auth file or both store auth environment variables');
  }
  return { username, password };
}

async function validateOfflineStore(path: string): Promise<string> {
  if (resolve(path) === sep) {throw new Error('--offline-store cannot be the filesystem root');}
  const canonical = await realpath(path);
  if (!(await stat(canonical)).isDirectory()) {
    throw new Error('--offline-store must be a directory');
  }
  await assertPortableFilesystemStore(canonical);
  return canonical;
}

export async function validatePostSearchV5RoutedPaths(
  options: PostSearchV5RoutedCatalogCliOptions,
  offlineStore = options.offlineStore,
): Promise<void> {
  const paths: NamedCliPath[] = [
    { label: '--state-file', path: options.stateFile },
    { label: '--state-file lock', path: `${options.stateFile}.lock` },
    { label: '--handoff-file', path: options.handoffFile },
  ];
  if (options.storeAuthFile) {
    paths.push({ label: '--store-auth-file', path: options.storeAuthFile });
  }
  if (offlineStore) {
    paths.push({ label: '--offline-store', path: offlineStore });
  }
  const canonical = await assertDisjointMutableCliPaths(
    paths,
    new Set(['--state-file', '--state-file lock', '--handoff-file']),
  );
  if (offlineStore) {assertCliPathsOutsideDirectory(canonical, '--offline-store');}
}

function canonicalPublicNhash(value: string, option: string): string {
  try {
    const root = nhashDecode(value);
    if (root.key !== undefined || nhashEncode(root) !== value) {throw new Error('noncanonical');}
    return value;
  } catch {throw new Error(`${option} must be a canonical public nhash`);}
}

function normalizedStoreUrl(value: string): string {
  let url: URL;
  try {url = new URL(value);} catch {throw new Error('--store-url must be an HTTP(S) URL');}
  if (!['http:', 'https:'].includes(url.protocol)
    || url.username || url.password || url.search || url.hash) {
    throw new Error('--store-url must be an uncredentialed HTTP(S) URL');
  }
  return url.toString().replace(/\/$/, '');
}

function absolutePath(value: string, option: string): string {
  if (!isAbsolute(value)) {throw new Error(`${option} must be an absolute path`);}
  return resolve(value);
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {throw new Error(`Missing required post-search v5 routed argument: ${key}`);}
  return value;
}

function optionalInteger(
  values: ReadonlyMap<string, string>,
  key: string,
  minimum: number,
  maximum = Number.MAX_SAFE_INTEGER,
): number | undefined {
  if (!values.has(key)) {return undefined;}
  const value = Number(required(values, key));
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${key} must be an integer from ${minimum} through ${maximum}`);
  }
  return value;
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const emit = (record: Record<string, unknown>): void => {
    process.stdout.write(`${JSON.stringify(record)}\n`);
  };
  try {
    await runPostSearchV5RoutedCatalogOperation(
      parsePostSearchV5RoutedCatalogArguments(process.argv.slice(2)),
      { emit },
    );
  } catch (error) {
    process.stderr.write(`${JSON.stringify({
      format: POST_SEARCH_V5_ROUTED_CLI_EVENT_FORMAT,
      operation: 'build',
      phase: 'failed',
      error: error instanceof Error ? error.message : String(error),
    })}\n`);
    process.exitCode = 1;
  }
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === filename) {void main();}
