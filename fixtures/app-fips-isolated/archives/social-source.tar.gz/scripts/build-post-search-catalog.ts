import { readFile } from 'node:fs/promises';
import type { Store } from '@hashtree/core';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import {
  assertPortableFilesystemStore,
  FilesystemBlockStore,
  FilePostSearchBuilderStateStore,
  writeJsonAtomic,
} from '../src/server/filesystemBlockStore';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import {
  HashtreeNostrSnapshotReader,
  POST_SEARCH_BUILDER_STATE_FORMAT,
  PostSearchCatalogBuilder,
} from '../src/server/postSearchCatalogBuilder';
import { POST_SEARCH_AUTHOR_TERMS_PROJECTION } from '../src/lib/postSearch';

const HELP = `Build an auditable Iris Social post-search catalog.

Required:
  --snapshot-root <nhash>       Immutable Hashtree Nostr event-index root
  --state-file <path>          New @4 atomic resumable builder state
  --handoff-file <path>        New @1 unsigned Nostr pointer handoff JSON
  --publisher-id <hex pubkey>  Nostr pubkey that will sign the pointer
  --tree-name <name>           Mutable Hashtree tree/ref name

Store (choose exactly one):
  --store-url <http(s) URL>     Production daemon store API; source and output
                                share the daemon-owned database
  --offline-store <directory>  Offline/test hashtree-fs CAS; LMDB is rejected

Optional:
  --store-auth-file <path>     Hashtree auth.cookie (username:password) or
                                JSON {"username":"...","password":"..."};
                                only valid with --store-url
  --store-timeout-ms <ms>      Per-request timeout for daemon store access;
                                default 30000
  --segment-documents <count>  Hard segment maximum; default 25000
  --segment-bytes <bytes>      Default 67108864
  --checkpoint-documents <n>   Durable flush interval; default 5000
  --progress-documents <n>     Durable telemetry interval; default 250

For --store-url, credentials are required from --store-auth-file or the paired
IRIS_HASHTREE_STORE_USERNAME and IRIS_HASHTREE_STORE_PASSWORD environment
variables. Credentials are never accepted as CLI values or printed.

This command never reads Nostr secret keys or publishes to relays. In daemon
mode, catalog blocks are written through the live store owner before handoff.
Use state, handoff, and tree names distinct from earlier builds; builder state
@4 rejects legacy state, resumes exact durable kind cursors, indexes verified
same-snapshot name/display_name/nip05 terms, and writes a v4 catalog with
bounded term routing plus corpus-global BM25F scoring state.
Sign the exact unsignedEvent, then publish it through the operator's existing
Nostr/Hashtree release path. Offline output must first be imported into a
published Hashtree store; never publish its pointer before its blocks.`;

type CliOptions = {
  snapshotRoot: string;
  storeUrl?: string;
  offlineStore?: string;
  storeAuthFile?: string;
  storeTimeoutMs?: number;
  stateFile: string;
  handoffFile: string;
  publisherId: string;
  treeName: string;
  segmentDocuments?: number;
  segmentBytes?: number;
  checkpointDocuments?: number;
  progressDocuments?: number;
};

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseArguments(process.argv.slice(2));
  const snapshotRoot = nhashDecode(options.snapshotRoot);
  if (nhashEncode(snapshotRoot) !== options.snapshotRoot) {
    throw new Error('--snapshot-root must be a canonical nhash');
  }
  const store = await createStore(options);
  const builder = new PostSearchCatalogBuilder({
    snapshotRoot,
    snapshotReader: new HashtreeNostrSnapshotReader(store),
    outputStore: store,
    stateStore: new FilePostSearchBuilderStateStore(options.stateFile),
    publisherId: options.publisherId,
    treeName: options.treeName,
    segmentMaxDocuments: options.segmentDocuments,
    segmentMaxBytes: options.segmentBytes,
    checkpointDocuments: options.checkpointDocuments,
    progressDocuments: options.progressDocuments,
    onProgress: (progress) => {
      process.stdout.write(`post-search progress ${JSON.stringify(progress)}\n`);
    },
  });
  const result = await builder.build();
  await writeJsonAtomic(options.handoffFile, result.handoff);
  process.stdout.write(`${JSON.stringify({
    catalogRoot: nhashEncode(result.catalogRoot),
    sourceEventRoot: result.handoff.sourceEventRoot,
    documents: result.state.segments.reduce((sum, segment) => sum + segment.documentCount, 0),
    segments: result.state.segments.length,
    resumed: result.resumed,
    handoffStatus: result.handoff.status,
    builderStateFormat: POST_SEARCH_BUILDER_STATE_FORMAT,
    authorTermsProjection: POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  })}\n`);
}

function parseArguments(args: string[]): CliOptions {
  const values = new Map<string, string>();
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid builder argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate builder argument: ${key}`);
    }
    values.set(key, value);
  }
  const known = new Set([
    '--snapshot-root',
    '--store-url',
    '--offline-store',
    '--store-auth-file',
    '--store-timeout-ms',
    '--state-file',
    '--handoff-file',
    '--publisher-id',
    '--tree-name',
    '--segment-documents',
    '--segment-bytes',
    '--checkpoint-documents',
    '--progress-documents',
  ]);
  for (const key of values.keys()) {
    if (key === '--snapshot-store' || key === '--output-store') {
      throw new Error(
        'Direct daemon data directories are unsupported; use --store-url. '
        + 'Use --offline-store only for a portable hashtree-fs CAS.',
      );
    }
    if (!known.has(key)) {
      throw new Error(`Unknown builder argument: ${key}`);
    }
  }
  const storeUrl = values.get('--store-url');
  const offlineStore = values.get('--offline-store');
  if (Boolean(storeUrl) === Boolean(offlineStore)) {
    throw new Error('Choose exactly one of --store-url or --offline-store');
  }
  const storeAuthFile = values.get('--store-auth-file');
  if (storeAuthFile && !storeUrl) {
    throw new Error('--store-auth-file requires --store-url');
  }
  const storeTimeoutMs = optionalInteger(values, '--store-timeout-ms');
  if (storeTimeoutMs && !storeUrl) {
    throw new Error('--store-timeout-ms requires --store-url');
  }
  return {
    snapshotRoot: required(values, '--snapshot-root'),
    storeUrl,
    offlineStore,
    storeAuthFile,
    storeTimeoutMs,
    stateFile: required(values, '--state-file'),
    handoffFile: required(values, '--handoff-file'),
    publisherId: required(values, '--publisher-id'),
    treeName: required(values, '--tree-name'),
    segmentDocuments: optionalInteger(values, '--segment-documents'),
    segmentBytes: optionalInteger(values, '--segment-bytes'),
    checkpointDocuments: optionalInteger(values, '--checkpoint-documents'),
    progressDocuments: optionalInteger(values, '--progress-documents'),
  };
}

async function createStore(options: CliOptions): Promise<Store> {
  if (options.storeUrl) {
    return new HttpBlockStore(options.storeUrl, {
      credentials: await loadStoreCredentials(options.storeAuthFile),
      timeoutMs: options.storeTimeoutMs,
    });
  }
  const directory = options.offlineStore as string;
  await assertPortableFilesystemStore(directory);
  return new FilesystemBlockStore(directory);
}

async function loadStoreCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const environmentUsername = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const environmentPassword = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (environmentUsername !== undefined || environmentPassword !== undefined)) {
    throw new Error('Choose either --store-auth-file or store auth environment variables');
  }
  if (path) {
    try {
      return parseHttpBlockStoreCredentials(await readFile(path, 'utf8'));
    } catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!environmentUsername || !environmentPassword) {
    throw new Error(
      'Daemon store writes require --store-auth-file or both store auth environment variables',
    );
  }
  return { username: environmentUsername, password: environmentPassword };
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key)?.trim();
  if (!value) {
    throw new Error(`Missing required builder argument: ${key}`);
  }
  return value;
}

function optionalInteger(values: ReadonlyMap<string, string>, key: string): number | undefined {
  const raw = values.get(key);
  if (raw === undefined) {
    return undefined;
  }
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`${key} must be a positive integer`);
  }
  return value;
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`post-search builder failed: ${message}\n`);
  process.exitCode = 1;
});
