#!/usr/bin/env python3
"""Render an inert systemd fixture plan or run one tiny, separately admitted probe.

No service-management, installation, account, publisher or network operation is
implemented here. Fleet must review/admit the exact placement and execute the
rendered commands under its own bounded supervisor. Rendering is side-effect free.
"""
import argparse
import json
import os
from pathlib import Path
import re
import sys
import time

CASES = ('anchor', 'positive', 'negative')
FIELDS = ('Id', 'Description', 'InvocationID', 'LoadState', 'ActiveState', 'SubState', 'Transient', 'FragmentPath',
          'DropInPaths', 'User', 'Group', 'NoNewPrivileges', 'Restart',
          'After', 'Requires', 'ExecConditionEx', 'ExecCondition', 'ExecStart',
          'Result', 'ExecMainPID', 'ControlPID', 'ControlGroup', 'MemoryMax',
          'MemorySwapMax', 'TasksMax', 'TimeoutStartUSec', 'TimeoutStopUSec')


def placement(root, user, uid, gid):
    if not re.fullmatch(r'/run/iris-archive-credential-fixture-[a-z0-9-]{1,40}', root):
        raise ValueError('exact task-exclusive /run placement required')
    if not re.fullmatch(r'[a-z_][a-z0-9_-]{0,30}', user) or uid <= 0 or gid <= 0:
        raise ValueError('existing unprivileged account identity required')
    return Path(root)


def render(root, user, uid, gid):
    home = placement(root, user, uid, gid)
    prefix = home.name
    units = {case: f'{prefix}-{case}.service' for case in CASES}
    probe = ['/usr/bin/python3', '-I', '-S', '-B', str(home / 'probe.py'),
             'probe', '--root', root, '--user', user, '--uid', str(uid), '--gid', str(gid)]
    properties = ['Type=oneshot', 'RemainAfterExit=yes', 'Restart=no',
                  f'User={user}', f'Group={gid}', 'NoNewPrivileges=yes',
                  'CapabilityBoundingSet=', 'PrivateNetwork=yes', 'ProtectSystem=strict',
                  'ProtectHome=yes', f'ReadWritePaths={root}', 'UMask=0077',
                  'MemoryMax=33554432', 'MemorySwapMax=0', 'TasksMax=8',
                  'TimeoutStartSec=10', 'TimeoutStopSec=3', 'KillMode=control-group',
                  'SendSIGKILL=yes', 'CollectMode=inactive', 'StandardOutput=null',
                  'StandardError=journal', 'LimitCORE=0', 'LimitFSIZE=65536']
    commands = []
    for case in CASES:
        extra = []
        if case != 'anchor':
            condition = probe + ['--case', case, '--phase', 'condition']
            # Only credentials differ. Do not use the broader '+' prefix.
            extra.append('ExecCondition=' + ('!' if case == 'positive' else '') + ' '.join(condition))
        if case == 'positive':
            extra += [f'After={units["anchor"]}', f'Requires={units["anchor"]}']
        argv = ['/usr/bin/systemd-run', '--quiet', '--unit=' + units[case],
                '--description=' + prefix + ':' + case]
        argv += ['--property=' + item for item in properties + extra]
        argv += probe + ['--case', case, '--phase', 'start']
        commands.append({'case': case, 'argv': argv, 'timeout_seconds': 15,
                         'expected_command_success': case != 'negative',
                         'show': ['/usr/bin/systemctl', 'show', units[case],
                                  '--property=' + ','.join(FIELDS)]})
    return {'format': 'iris-social/credential-fixture-plan@1', 'execution_admitted': False,
            'root': root, 'account': {'name': user, 'uid': uid, 'gid': gid}, 'units': units,
            'limits': {'overall_seconds_including_cleanup': 75, 'exercise_seconds': 45,
                       'cleanup_seconds': 20, 'memory_max_per_unit': 33554432,
                       'maximum_concurrent_probe_processes': 1, 'tasks_max_per_unit': 8,
                       'fixture_disk_max_bytes': 1048576, 'evidence_output_max_bytes': 65536},
            'layout': {'root': 'root:root0755', 'probe.py': 'root:root0444 exact source SHA',
                       'private': 'root:root0700', 'private/challenge': 'root:root0400, fixture-only constant',
                       'observed': 'root:root0755',
                       'observed/<case>': f'{uid}:{gid}0700, exactly the three named cases'},
            'commands': commands,
            'cleanup': {'stop': ['/usr/bin/systemctl', 'stop', units['positive'], units['negative'], units['anchor']],
                        'reset_failed': ['/usr/bin/systemctl', 'reset-failed', *units.values()],
                        'required_proofs': ['all exact owned units inactive or not-found',
                                            'recorded cgroups empty/absent and recorded probe PIDs gone',
                                            'source, challenge, probe records and unit outputs captured before file retirement',
                                            'remove only exact owned files/directories; no recursive deletion or production edits']}}


def status():
    fields = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    return {'pid': os.getpid(), 'euid': os.geteuid(), 'egid': os.getegid(),
            'no_new_privileges': int(fields['NoNewPrivs'].strip()),
            'invocation_id': os.environ.get('INVOCATION_ID'), 'monotonic_ns': time.monotonic_ns()}


def evaluate(row, phase, case, uid, gid):
    identity = (row['euid'], row['egid'])
    common = row['no_new_privileges'] == 1 and bool(re.fullmatch('[a-f0-9]{32}', row['invocation_id'] or ''))
    if phase == 'condition':
        if case == 'positive':
            return 0 if common and identity == (0, 0) and row['private_read'] else 255
        # Intentionally fail the no-'!' condition so systemd retains its failed
        # transient unit for explicit exit-status evidence; ExecStart must not run.
        return 255 if (common and identity == (uid, gid) and row['private_read'] is False
                       and row['private_error'] == 'PermissionError') else 254
    return 0 if (common and identity == (uid, gid) and row['private_read'] is False
                 and row['private_error'] == 'PermissionError' and case != 'negative') else 255


def probe(root, user, uid, gid, case, phase):
    home = placement(root, user, uid, gid)
    if phase == 'condition' and case == 'anchor':
        raise ValueError('anchor has no condition')
    row = status()
    row.update(case=case, phase=phase, private_read=False, private_error=None)
    try:
        row['private_read'] = (home / 'private/challenge').read_bytes() == b'fixture-only\n'
    except PermissionError:
        row['private_error'] = 'PermissionError'
    row['planned_exit'] = evaluate(row, phase, case, uid, gid)
    # The root proof goes into root-only storage. Unprivileged proofs cannot
    # alter it, and every result is exclusive: retries cannot replace evidence.
    parent = home / 'private' if row['euid'] == 0 else home / 'observed' / case
    output = parent / f'{case}-{phase}.json'
    raw = (json.dumps(row, sort_keys=True) + '\n').encode()
    if len(raw) > 4096:
        raise ValueError('probe output exceeds bound')
    with output.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return row['planned_exit']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('render', 'probe'))
    parser.add_argument('--root', required=True)
    parser.add_argument('--user', required=True)
    parser.add_argument('--uid', required=True, type=int)
    parser.add_argument('--gid', required=True, type=int)
    parser.add_argument('--case', choices=CASES)
    parser.add_argument('--phase', choices=('condition', 'start'))
    args = parser.parse_args()
    if args.mode == 'render':
        print(json.dumps(render(args.root, args.user, args.uid, args.gid), indent=2))
    else:
        if args.case is None or args.phase is None:
            parser.error('probe requires --case and --phase')
        sys.exit(probe(args.root, args.user, args.uid, args.gid, args.case, args.phase))
