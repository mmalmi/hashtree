# Outer supervisor for the accepted r3 controller

This is a separately reviewed maintenance payload, not installation or trial
authorization. It wraps the unchanged controller and its control/protection
children. The archive service, native process, publisher and persistent boot
recovery retain their existing cgroups and limits. The wrapper never runs a
native command, resets controller state, replays publication or installs files.

Render locally using the exact retained private `binding.candidate.json`:

```sh
python3 -B scripts/archive_diagnostic_supervisor.py render --binding "$r3_binding"
```

The result supplies exact target paths and file bytes for `plan.json` and a
single runtime unit under `/run/systemd/system`. Its source path and private
evidence directory are under `versions/<existing-operation>/supervision`.
The renderer binds its own source hash, the r3 controller hash and the exact
r3 binding. It refuses a different binding, including changed whitespace.
Source contains no host identity or deployment path; those remain in the
private rendered packet. The runtime source, plan and unit must be sealed
together in the owner's immutable placement manifest.

No r3 binding change is required. The wrapper is an additional supervisor,
not a changed controller or guard. Existing r3 inputs remain:

| Input | SHA256 |
| --- | --- |
| Controller | `145a93e84c99e3dcd0f1241c599cfe66287ea44732ea677af7221e76a9131d96` |
| Binding | `6fda08a009367a651edd3d18fa5bd66750b0c5271426e3afc02f84f9ed5cf02b` |
| Recovery unit | `7c72a57ca87ef49d63ee4a2de9d30fa3fa98ebe7bd5a297fcf4e12bebbc19e0e` |
| Additive service condition | `6d75f39d97e47093d0578a33f0881aad00735b8a498071f446dcb8b78cbace24` |

Changing those bytes, the selected publisher configuration, original unit
settings or retained executables needs a new explicit review. Do not silently
regenerate r3 to make admission pass. Reuse the accepted 63 controller tests
and the independently qualified credential fixture for unchanged inputs.

## Limits and deadline accounting

The new unit has CPUQuota50%, MemoryMax256MiB, no swap, TasksMax32,
NoNewPrivileges, UMask0077, no core dumps and no restart. It runs as root because
r3 preserves existing file ownership and changes reviewed systemd metadata.
It deliberately does not claim an unprivileged filesystem boundary. Its
resource limits do not apply to the archive or persistent recovery services.

| Stage | Bound |
| --- | --- |
| Original boundary admission | 900 seconds from existing r3 initialization |
| Original supervision/claim expiry | 7,200 seconds from that initialization |
| Controller poll budget on entry | Remaining original supervision time, rounded down; at most 7,200 seconds |
| Last control-call margin | 1,200 seconds; no new admission allowance |
| Manager start limit | 8,420 seconds, including 20 seconds for wrapper/child closure |
| One recovery call | 300 seconds of polling plus 1,200 seconds for completion of control calls |
| Final audit | 180 seconds |
| Manager stop/closure limit | 1,740 seconds, including 60 seconds for process and evidence closure |
| Maximum running-unit envelope | 10,160 seconds (2h49m20s) |

The conservative call margin allocates 24 systemctl calls at r3's20-second
timeout, six protection calls at its90-second timeout, and180 seconds for local
file checks/scheduling. This is a completion allowance, not a promise that slow
storage will complete. Every wrapper child also has a monotonic timeout.
The unchanged r3 guard checks its original wall-clock deadline immediately
before claiming; the extra completion/recovery time cannot renew that claim.

The unit uses `Type=oneshot` and `TimeoutStartSec`, since `RuntimeMaxSec` does not
bound oneshot activation. Both timeout failure modes are `kill`, and its normal
kill signal is SIGKILL, so a second graceful-stop interval cannot silently extend
the envelope. Only this unit's cgroup is killed. r3's durable transactions and
independently enabled recovery handle interruption; the archive service is never
stopped by the wrapper. `ExecStopPost` runs the separately bounded closure helper,
including after failed start. These are documented systemd semantics, not a
substitute for checking effective settings on the admitted target. See
[systemd v259 service documentation](https://github.com/systemd/systemd/blob/v259/man/systemd.service.xml).

The root owner must ensure the persistent recovery unit and mounts are already
ready before starting this unit. `Requisite` refuses an absent recovery unit;
the wrapper does not pull it into a new activation. There is no new mount job,
service ordering dependency, timer or enablement link in this payload. The
unit deliberately omits `WorkingDirectory` and the other directory directives
that implicitly require mounts. System services therefore use the default `/`;
see [systemd v259 execution dependencies and working-directory defaults](https://github.com/systemd/systemd/blob/v259/man/systemd.exec.xml).
The wrapper invokes absolute controller/binding paths. Every controller child
(`run`, `recover`, `audit`) receives `subprocess` cwd from `controller_cwd`, derived
from the exact unchanged r3 binding root and sealed in the new plan. This preserves
the previously qualified controller/protection environment without asking systemd
to add a mount dependency. The wrapper itself retains the default `/`.

The retained controller uses bound roots, and the protection script/launcher
derive their installation root from `__file__`. However, the retained source of
their `pool_read.py` helper and proof of absolute member/external-blob paths were
not acquired. This payload makes no new transitive cwd-independence claim: it
preserves the existing cwd instead. A focused inert child test starts from `/`,
uses the explicit archive cwd for a relative data read, and imports a helper
relative to its script location. No real controller, guard or database reader runs.
The running-unit envelope begins at ExecStart, not at a queued systemd request.
Fleet must bound the start request and initial job observation to20 seconds:
if ExecStart has not begun, cancel/stop only this exact owned supervisor job and
inspect its state; do not retry. A non-running queued job is not a completed trial.

Output from each of `run`, `recover`, and `audit` is merged and capped at128KiB.
Overflow terminates only that owned child process group and records a failure.
Each JSON evidence file is at most64KiB. The exact seven runtime paths consume
at most640KiB of file contents, with a1MiB evidence allocation reservation.
Wrapper stdout goes to null; a validation failure emits one bounded error record
to the journal (at most4KiB after JSON escaping). Fleet must independently capture unit results
and cgroup/PID closure in its existing private evidence location with its own
bounded capture. r3's existing durable state/control writes are separate from
this evidence allowance; no database copy, scan, native build or relay probe is
added. Fresh free-space, memory and CPU reservations remain Fleet's entry gate.

## Recovery-first installation order

Everything below remains proposed until Fleet separately admits placement and
the trial. Do not start it on the strength of source tests or this document.

1. Verify exact r3 inputs, current service/timer/mount settings, retained binary
   provenance disposition and current durable claim/deadline state. Preserve any
   existing operation. An expired/consumed operation cannot be recreated or
   reset to make this payload runnable. For an operation that has never been
   initialized, only the separately authorized r3 `init` captures ownership and
   starts its original900/7200-second clocks; this wrapper never calls `init`.
2. Follow r3's existing order: initialize ownership before installation, install
   the exact recovery unit and enablement link first, then the additive service
   condition. Reload systemd and start the recovery unit's same-boot probe.
   Independently verify loaded bytes, ordering, effective credentials, mounts,
   writable paths and armed recovery. Do not rerun the accepted credential test
   just because this supervisor is new.
3. Stage the wrapper source and plan root-owned0400, their task-exclusive
   supervision directory root-owned0700, and an empty root-owned0700 evidence
   directory. Place the exact new runtime unit root-owned0644 at its rendered
   absent path. Never overwrite a file or delete an old claim. Its source path
   is root-only; the separate native staging paths remain service-traversable.
4. Reload and verify the new unit's complete effective settings and lack of
   foreign drop-ins. Its cgroup must be distinct from the archive and recovery
   units, with no PartOf/BindsTo/stop-propagation relationship to the archive.
   Record the installed file digests, existing boot ID, unit identity and the
   ownership inventory before the single bounded start request. The source
   renderer does not execute any of these operations.

The wrapper checks root identity, NoNewPrivileges, exact unit/source/plan/controller
bytes, the dedicated systemd cgroup and invocation, private output ownership and
an empty evidence directory. Entry requires the original unconsumed same-boot
parking/boundary state and an unexpired admission window. It durably writes
`claim.json` before invoking r3. That claim is never replaced, even after an
execution failure. A repeated start or another invocation cannot consume it.

## Held-state and completion handling

The closure helper belongs to the same systemd invocation and writes an exclusive
`close-claim.json`. It verifies the original controller identity and deadlines.
If r3 is already restored/aborted, it audits only: the restored timer may already
have started an ordinary baseline crawl. Otherwise it invokes r3 `recover` once,
then audits only if recovery exited successfully. It never retries `run`, calls
`replay-publication`, edits pending events or broadens the recovery authority.

On active native work, pending publication, foreign changes or failed restoration,
the original r3 behavior holds state for Fleet. A missing, partial, failed or
timed-out closure record is also incomplete, never success. Fleet owns the same
recovery obligation after the outer unit exits: inspect the exact state/claims,
preserve pending signed bytes and their original authorities, and use the
already specified no-native replay/recovery path only within separate authority.
Do not add another diagnostic launch, reset a deadline, stop native work, or make
relay availability a trial/restoration gate. Uninterruptible kernel I/O can delay
process disappearance after a kill; report that as incomplete closure.

`restoration_verified` requires a successful independent controller audit and a
terminal, timer-healthy state without a recovery obligation. It does not assert
a diagnostic native exit or a performance improvement. Match r3's actual admitted
invocation to the native receipt, or retain an explicit unmatched/unconfirmed
observation. The overall unit can remain failed even after successful restoration;
preserve both facts rather than masking the original failure with the audit.

## Exact retirement criteria

No cleanup executor is provided. Fleet retires only reviewed, task-exclusive
paths after collecting evidence and independently confirming restoration,
original timer state and claims, and no supervisor/closure children. Check the
recorded cgroup is empty/absent and recorded PIDs are gone; a leader exit or a
successful stop command alone is insufficient. If held, preserve the guard,
recovery unit, wrapper source/plan, claims and all state for Fleet's follow-up.

Retain an immutable copy of the seven possible evidence files listed in the
plan (`claim.json`, `run.log`, `run-result.json`, `close-claim.json`, `recover.log`,
`audit.log`, `close-result.json`) with their actual lengths/hashes; absent files
remain recorded as absent. Never remove the retained claims to enable a retry.
Capture the source, plan, installed unit, effective settings, results and exact
created-path inventory before any retirement. Verify root ownership, regular-file
types, no symlink substitutions and matching captured hashes immediately before
removing only the new runtime unit. Reload and verify it is unloaded. No restart
or stop command may target the archive service.

After the original r3 acceptance, follow its existing order to retire its exact
additive condition and recovery link/unit; their hashes and ownership remain
unchanged. The wrapper's source/plan and seven evidence files are small retained
audit inputs, not automatic cleanup targets. Empty task-only staging directories
may be removed only after explicitly authorized retirement of their inventoried
contents. Preserve r3 controller state/plans, receipts, executables, original
drop-ins/timer links and all shared data. Any unexpected path, hash, owner,
remaining process or failed audit leaves an explicit cleanup hold with Fleet.

Focused local checks for this new wrapper:

```sh
python3 -B tests/test_archive_diagnostic_supervisor.py --binding "$r3_binding" -v
```

These test original deadlines, durable single-use claims, terminal audit-only
closure, failed recovery disposition, output overflow and owned-process timeouts.
The r2 correction adds only focused no-implicit-mount and explicit-child-cwd
coverage; reuse the accepted r1 tests for unchanged behavior.
They do not execute systemd, r3, a native executable, publisher or production I/O.
Target effective unit qualification, retained-ELF provenance acceptance and
current production admission remain separate gates.
