import { createHash } from 'node:crypto';
import { readFile, realpath, rm, stat } from 'node:fs/promises';
import { isAbsolute, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { nhashDecode, nhashEncode, type Store } from '@hashtree/core';
import { runReferencedEventClosure } from '../src/server/referencedEventClosure';
import { FileReferencedEventClosureJournal } from '../src/server/referencedEventClosureJournal';
import {
  createReferencedEventClosureRelayPolicy,
  NostrRelayReferencedEventClosureResolver,
  type ReferencedEventClosureRelayPolicy,
  type ReferencedEventClosureRelayQueryClient,
} from '../src/server/referencedEventClosureRelayResolver';
import { HashtreeReferencedEventClosureSource } from '../src/server/referencedEventClosureSource';
import type { ReferencedEventClosureLimits } from '../src/server/referencedEventClosureTypes';
import {
  assertCliPathsOutsideDirectory,
  assertDisjointMutableCliPaths,
  type NamedCliPath,
} from '../src/server/cliPathSafety';
import { acquireExclusiveFileLock } from '../src/server/exclusiveFileLock';
import {
  assertPortableFilesystemStore,
  FilesystemBlockStore,
  writeJsonAtomic,
} from '../src/server/filesystemBlockStore';

export const REFERENCED_EVENT_CLOSURE_HANDOFF_FORMAT =
  'iris-social/referenced-event-closure-handoff@1' as const;
export const REFERENCED_EVENT_CLOSURE_OPERATION_FORMAT =
  'iris-social/referenced-event-closure-operation@1' as const;

const HEX_64 = /^[0-9a-f]{64}$/;
const DEFAULT_LIMITS: ReferencedEventClosureLimits = {
  maxDepth: 2,
  maxReferences: 250_000,
  maxAcceptedEvents: 250_000,
  maxAcceptedBytes: 512 * 1024 * 1024,
  maxEventBytes: 1024 * 1024,
  sourceBatchSize: 512,
  resolutionBatchSize: 128,
  maxResolverCandidates: 512,
};

const HELP = `Build a resumable additive archive closure for referenced Nostr events.

Required immutable inputs:
  --offline-store <absolute dir>       Portable hashtree-fs CAS; never daemon LMDB
  --source-root <canonical nhash>      Exact immutable broad-archive event root
  --eligible-authors <absolute file>  Exact canonical newline author artifact
  --overmuted-authors <absolute file> Exact canonical newline exclusion artifact
  --relay <ws(s) URL>                 Exact relay set (required; repeatable)

Required durable outputs:
  --journal-file <absolute file>      Fsynced append-only resume journal
  --handoff-file <absolute file>      Atomic verified additive-root handoff

Bounded relay policy:
  --relay-timeout-ms <n>              EOSE deadline per open subscription (30000)
  --batch-timeout-ms <n>              Whole resolver-batch deadline (180000)
  --relay-concurrency <n>             Concurrent subscriptions (8)
  --id-batch-size <n>                 IDs in each immutable filter (64)
  --filters-per-request <n>           Filters in each NIP-01 REQ (16)

Bounded closure policy:
  --max-depth <n>                     Reference closure depth (2)
  --max-references <n>                Discovered reference cap (250000)
  --max-accepted-events <n>           Accepted event cap (250000)
  --max-accepted-bytes <n>            Accepted byte cap (536870912)
  --max-event-bytes <n>               Per-event byte cap (1048576)
  --source-batch-size <n>             Durable source scan batch (512)
  --resolution-batch-size <n>         References resolved per batch (128)
  --max-resolver-candidates <n>       Unique candidate cap per batch (512)

ID references are queried in immutable ID batches. Each address reference is
queried by one exact kind+author+#d filter. Absence is recorded only after every
relay subscription sends EOSE; timeout, disconnect, CLOSED, or relay failure is
retryable and leaves that journal batch unadvanced. This command never signs,
pins, publishes, opens daemon LMDB, or changes the browser relay policy.`;

export type ReferencedEventClosureCliOptions = {
  offlineStore: string;
  sourceRoot: string;
  eligibleAuthorsFile: string;
  overmutedAuthorsFile: string;
  journalFile: string;
  handoffFile: string;
  relays: string[];
  relayTimeoutMs: number;
  batchTimeoutMs: number;
  relayConcurrency: number;
  idBatchSize: number;
  filtersPerRequest: number;
  limits: ReferencedEventClosureLimits;
};

export type ReferencedEventClosureHandoff = {
  format: typeof REFERENCED_EVENT_CLOSURE_HANDOFF_FORMAT;
  status: 'verified';
  complete: true;
  additive: true;
  sourceRoot: string;
  closureConfigurationSha256: string;
  resolverPolicySha256: string;
  eligibleAuthorsArtifactSha256: string;
  overmutedAuthorsArtifactSha256: string;
  eligibleAuthorsSha256: string;
  overmutedAuthorsSha256: string;
  eligibleAuthorCount: number;
  overmutedAuthorCount: number;
  relayPolicy: ReferencedEventClosureRelayPolicy;
  limits: ReferencedEventClosureLimits;
  batches: Array<{ root: string; eventIds: string[] }>;
  counters: Record<string, number>;
  publicationPerformed: false;
};

export type ReferencedEventClosureCliDependencies = {
  store?: Store;
  relayClient?: ReferencedEventClosureRelayQueryClient;
  emit?: (record: Record<string, unknown>) => void;
};

export function parseReferencedEventClosureArguments(
  rawArgs: readonly string[],
): ReferencedEventClosureCliOptions {
  const args = rawArgs[0] === '--' ? rawArgs.slice(1) : rawArgs;
  const values = new Map<string, string>();
  const relays: string[] = [];
  const known = new Set([
    '--offline-store', '--source-root', '--eligible-authors', '--overmuted-authors',
    '--journal-file', '--handoff-file', '--relay', '--relay-timeout-ms',
    '--batch-timeout-ms', '--relay-concurrency', '--id-batch-size',
    '--filters-per-request', '--max-depth', '--max-references',
    '--max-accepted-events', '--max-accepted-bytes', '--max-event-bytes',
    '--source-batch-size', '--resolution-batch-size', '--max-resolver-candidates',
  ]);
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid referenced-event closure argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (key === '--store-url' || key === '--data-dir') {
      throw new Error('Only an explicit portable --offline-store is supported');
    }
    if (!known.has(key)) {
      throw new Error(`Unknown referenced-event closure argument: ${key}`);
    }
    if (key === '--relay') {
      relays.push(value.trim());
    } else if (values.has(key)) {
      throw new Error(`Duplicate referenced-event closure argument: ${key}`);
    } else {
      values.set(key, value.trim());
    }
  }
  if (relays.length === 0) {
    throw new Error('At least one explicit --relay is required');
  }
  const limits = {
    maxDepth: integer(values, '--max-depth', DEFAULT_LIMITS.maxDepth, 16),
    maxReferences: integer(values, '--max-references', DEFAULT_LIMITS.maxReferences),
    maxAcceptedEvents: integer(
      values,
      '--max-accepted-events',
      DEFAULT_LIMITS.maxAcceptedEvents,
    ),
    maxAcceptedBytes: integer(values, '--max-accepted-bytes', DEFAULT_LIMITS.maxAcceptedBytes),
    maxEventBytes: integer(values, '--max-event-bytes', DEFAULT_LIMITS.maxEventBytes),
    sourceBatchSize: integer(values, '--source-batch-size', DEFAULT_LIMITS.sourceBatchSize),
    resolutionBatchSize: integer(
      values,
      '--resolution-batch-size',
      DEFAULT_LIMITS.resolutionBatchSize,
    ),
    maxResolverCandidates: integer(
      values,
      '--max-resolver-candidates',
      DEFAULT_LIMITS.maxResolverCandidates,
    ),
  };
  if (limits.maxResolverCandidates < limits.resolutionBatchSize) {
    throw new Error('--max-resolver-candidates must cover --resolution-batch-size');
  }
  return {
    offlineStore: absolute(required(values, '--offline-store'), '--offline-store'),
    sourceRoot: canonicalNhash(required(values, '--source-root')),
    eligibleAuthorsFile: absolute(
      required(values, '--eligible-authors'),
      '--eligible-authors',
    ),
    overmutedAuthorsFile: absolute(
      required(values, '--overmuted-authors'),
      '--overmuted-authors',
    ),
    journalFile: absolute(required(values, '--journal-file'), '--journal-file'),
    handoffFile: absolute(required(values, '--handoff-file'), '--handoff-file'),
    relays,
    relayTimeoutMs: integer(values, '--relay-timeout-ms', 30_000, 600_000),
    batchTimeoutMs: integer(values, '--batch-timeout-ms', 180_000, 3_600_000),
    relayConcurrency: integer(values, '--relay-concurrency', 8, 256),
    idBatchSize: integer(values, '--id-batch-size', 64, 1_000),
    filtersPerRequest: integer(values, '--filters-per-request', 16, 256),
    limits,
  };
}

export async function runReferencedEventClosureOperation(
  options: ReferencedEventClosureCliOptions,
  dependencies: ReferencedEventClosureCliDependencies = {},
): Promise<ReferencedEventClosureHandoff> {
  const emit = dependencies.emit ?? (() => undefined);
  const offlineStore = await validateOfflineStore(options.offlineStore);
  await validateReferencedEventClosurePaths(options, offlineStore);
  const lock = await acquireExclusiveFileLock(
    options.journalFile,
    'Referenced-event closure journal',
  );
  try {
    await rm(options.handoffFile, { force: true });
    const [eligibleText, overmutedText] = await Promise.all([
      readFile(options.eligibleAuthorsFile, 'utf8'),
      readFile(options.overmutedAuthorsFile, 'utf8'),
    ]);
    const eligibleAuthors = parseAuthorArtifact(eligibleText, 'Eligible', false);
    const overmutedAuthors = parseAuthorArtifact(overmutedText, 'Overmuted', true);
    if ([...overmutedAuthors].some((pubkey) => eligibleAuthors.has(pubkey))) {
      throw new Error('Eligible and overmuted author artifacts must be disjoint');
    }
    const store = dependencies.store ?? new FilesystemBlockStore(offlineStore);
    const sourceRoot = nhashDecode(options.sourceRoot);
    if (!(await store.has(sourceRoot.hash))) {
      throw new Error('Referenced-event closure source root is absent from the portable store');
    }
    const relayPolicy = createReferencedEventClosureRelayPolicy({
      relays: options.relays,
      idBatchSize: options.idBatchSize,
      maxFiltersPerRequest: options.filtersPerRequest,
      maxConcurrentRequests: options.relayConcurrency,
      requestTimeoutMs: options.relayTimeoutMs,
      batchTimeoutMs: options.batchTimeoutMs,
      maxCandidates: options.limits.maxResolverCandidates,
      maxEventBytes: options.limits.maxEventBytes,
    });
    const resolver = new NostrRelayReferencedEventClosureResolver(
      relayPolicy,
      dependencies.relayClient,
    );
    emit(operationEvent('start', {
      sourceRoot: options.sourceRoot,
      eligibleAuthorCount: eligibleAuthors.size,
      overmutedAuthorCount: overmutedAuthors.size,
      resolverPolicySha256: resolver.configurationSha256,
    }));
    const result = await (async () => {
      try {
        return await runReferencedEventClosure(store, {
          source: new HashtreeReferencedEventClosureSource(store, sourceRoot),
          resolver,
          journal: new FileReferencedEventClosureJournal(options.journalFile),
          eligibleAuthors,
          overmutedAuthors,
          limits: options.limits,
        });
      } finally {
        await resolver.close();
      }
    })();
    const handoff: ReferencedEventClosureHandoff = {
      format: REFERENCED_EVENT_CLOSURE_HANDOFF_FORMAT,
      status: 'verified',
      complete: true,
      additive: true,
      sourceRoot: result.sourceRoot,
      closureConfigurationSha256: result.configurationSha256,
      resolverPolicySha256: result.resolverPolicySha256,
      eligibleAuthorsArtifactSha256: sha256(eligibleText),
      overmutedAuthorsArtifactSha256: sha256(overmutedText),
      eligibleAuthorsSha256: result.eligibleAuthorsSha256,
      overmutedAuthorsSha256: result.overmutedAuthorsSha256,
      eligibleAuthorCount: eligibleAuthors.size,
      overmutedAuthorCount: overmutedAuthors.size,
      relayPolicy,
      limits: result.limits,
      batches: result.batches,
      counters: result.counters,
      publicationPerformed: false,
    };
    await writeJsonAtomic(options.handoffFile, handoff);
    emit(handoff);
    return handoff;
  } finally {
    await lock.release();
  }
}

export async function validateReferencedEventClosurePaths(
  options: ReferencedEventClosureCliOptions,
  offlineStore = options.offlineStore,
): Promise<void> {
  const paths: NamedCliPath[] = [
    { label: '--offline-store', path: offlineStore },
    { label: '--eligible-authors', path: options.eligibleAuthorsFile },
    { label: '--overmuted-authors', path: options.overmutedAuthorsFile },
    { label: '--journal-file', path: options.journalFile },
    { label: '--journal-file lock', path: `${options.journalFile}.lock` },
    { label: '--handoff-file', path: options.handoffFile },
  ];
  const canonical = await assertDisjointMutableCliPaths(
    paths,
    new Set(['--journal-file', '--journal-file lock', '--handoff-file']),
  );
  assertCliPathsOutsideDirectory(canonical, '--offline-store');
}

export function parseAuthorArtifact(
  text: string,
  label: string,
  allowEmpty: boolean,
): Set<string> {
  if (text === '' && allowEmpty) {
    return new Set();
  }
  if (!text.endsWith('\n') || text.trimEnd() !== text.slice(0, -1)) {
    throw new Error(`${label} author artifact must be canonical newline-delimited text`);
  }
  const authors = text.slice(0, -1).split('\n');
  if (authors.length === 0 || authors.some((author) => !HEX_64.test(author))) {
    throw new Error(`${label} author artifact contains an invalid pubkey`);
  }
  if (new Set(authors).size !== authors.length) {
    throw new Error(`${label} author artifact contains a duplicate pubkey`);
  }
  return new Set(authors);
}

async function validateOfflineStore(path: string): Promise<string> {
  if (resolve(path) === sep) {
    throw new Error('--offline-store cannot be the filesystem root');
  }
  const canonical = await realpath(path);
  if (!(await stat(canonical)).isDirectory()) {
    throw new Error('--offline-store must be a directory');
  }
  await assertPortableFilesystemStore(canonical);
  return canonical;
}

function operationEvent(phase: 'start', details: Record<string, unknown>): Record<string, unknown> {
  return {
    format: REFERENCED_EVENT_CLOSURE_OPERATION_FORMAT,
    operation: 'build',
    phase,
    ...details,
  };
}

function canonicalNhash(value: string): string {
  try {
    const root = nhashDecode(value);
    if (nhashEncode(root) !== value) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error('--source-root must be a canonical nhash');
  }
}

function absolute(value: string, option: string): string {
  if (!isAbsolute(value)) {
    throw new Error(`${option} must be an absolute path`);
  }
  return resolve(value);
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {
    throw new Error(`Missing required referenced-event closure argument: ${key}`);
  }
  return value;
}

function integer(
  values: ReadonlyMap<string, string>,
  key: string,
  fallback: number,
  maximum = Number.MAX_SAFE_INTEGER,
): number {
  if (!values.has(key)) {
    return fallback;
  }
  const value = Number(required(values, key));
  if (!Number.isSafeInteger(value) || value <= 0 || value > maximum) {
    throw new Error(`${key} must be an integer from 1 through ${maximum}`);
  }
  return value;
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const emit = (record: Record<string, unknown>): void => {
    process.stdout.write(`${JSON.stringify(record)}\n`);
  };
  try {
    await runReferencedEventClosureOperation(
      parseReferencedEventClosureArguments(process.argv.slice(2)),
      { emit },
    );
  } catch (error) {
    process.stderr.write(`${JSON.stringify({
      format: REFERENCED_EVENT_CLOSURE_OPERATION_FORMAT,
      operation: 'build',
      phase: 'failed',
      retryable: error instanceof Error && 'retryable' in error && error.retryable === true,
      error: error instanceof Error ? error.message : String(error),
    })}\n`);
    process.exitCode = 1;
  }
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === filename) {
  void main();
}
