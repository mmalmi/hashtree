import { execFileSync, spawnSync } from 'node:child_process';
import { lstat, mkdir, readFile, readdir } from 'node:fs/promises';
import { resolve, join, dirname, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { nhashEncode } from '@hashtree/core';
import { parseHashtreeRootEvent } from '@hashtree/nostr';
import { finalizeEvent, getPublicKey, verifyEvent } from 'nostr-tools/pure';
import { decode } from 'nostr-tools/nip19';
import type { RawEvent } from '../src/lib/nostr';
import { canonical, digest, publishArchiveCandidate, retryArchiveCurrentDelivery, readJson,
  type ArchiveCheckpoint, type ArchiveRunReceipt, type ArchivePublication, type ArchiveRepairReceipt,
  type ArchiveLineageReceipt, type ArchiveRelayRemovalReceipt, type ArchiveSourceModeReceipt,
  type ArchiveKindExpansionReceipt, type ArchiveCommitBatchReceipt, type ArchiveSourceCoverageProof } from '../src/server/archiveCheckpointOutbox';
import { archiveReadStore, archiveReceiptChain, validateArchiveCandidate, verifyArchiveAppend } from '../src/server/archiveCheckpointVerification';
import { MAX_ARCHIVE_REPAIR_RECEIPTS, selectArchiveRepairs, validateArchiveRepairHistory,
  validateArchiveRepairReceipt, verifyArchiveRepairEvidence } from '../src/server/archiveCheckpointRepair';
import { readArchivePointerHeads, sendArchivePointer } from '../src/server/archivePublicationRelay';
import { validateArchiveRelayRemovalReceipt } from '../src/server/archiveCheckpointRelayPolicy';
import { ARCHIVE_COVERAGE_MAX_BYTES, parseArchiveSourceCoverage,
  isArchiveKindExpansionReceipt, validateArchiveKindExpansionReceipt, validateArchiveSourceModeReceipt } from '../src/server/archiveCheckpointSourceCoverage';
import { isArchiveCommitBatchReceipt, validateArchiveCommitBatchReceipt } from '../src/server/archiveCheckpointSourceCoverage';
import { assertMarketArchivePlan, validateMarketNativeReceipt, verifyMarketIndexReadback, type MarketArchivePlan } from '../src/server/marketArchivePolicy';

interface Config {
  format: 'iris-social/archive-publisher-config@1';
  outboxDirectory: string;
  operationLock: string;
  nativeAuthoritySha256: string;
  /** Only a separately prepared Market tree may opt into this additional authority. */
  marketAuthorityFile?: string;
  priorNativeReceiptFiles?: Record<string, string>;
  repairReceiptFiles?: Record<string, string>;
  relayRemovalReceiptFiles?: Record<string, string>;
  sourceModeReceiptFiles?: Record<string, string>;
  kindExpansionReceiptFiles?: Record<string, string>;
  commitBatchReceiptFiles?: Record<string, string>;
  sourceCoverageDirectory?: string;
  checkpointFile: string;
  authorsFile: string;
  expectedPolicy: ArchiveCheckpoint['policy'];
  publisher: string;
  treeName: string;
  keysFile: string;
  keysFileSha256: string;
  protectedFiles: Record<string, string>;
  protectionCommand: string[];
  initialEventFile: string;
  initialEventSha256: string;
  firstSemanticReceiptFile: string;
  firstSemanticReceiptSha256: string;
  relays: string[];
  minimumConfirmedRelays?: number;
  readEndpoint: string;
}

interface SemanticReceipt {
  root: string;
  passed: boolean;
  checks: Array<{ passed: boolean; complete: boolean; verifiedSignatures: boolean; freshRequired: boolean;
    historicalWanted: Array<{ id: string }>; freshWanted: Array<{ id: string }>;
    missingHistorical: unknown[]; missingFresh: unknown[] }>;
}

async function boundedFile(file: string, expected?: string, maxBytes = 8 * 1024 * 1024) {
  const metadata = await lstat(file);
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size > maxBytes) {throw new Error('Invalid publication input file');}
  const bytes = await readFile(file);
  if (bytes.length > maxBytes || (expected && digest(bytes) !== expected)) {throw new Error('Publication input digest changed');}
  return bytes;
}

/** The established archive needs no new configuration; other tree names require an exact isolated Market authority. */
export async function loadMarketPublisherPlan(config: Pick<Config,'treeName'|'marketAuthorityFile'|'nativeAuthoritySha256'|'expectedPolicy'|'checkpointFile'|'authorsFile'|'operationLock'|'outboxDirectory'|'protectedFiles'>):Promise<MarketArchivePlan|null> {
  if(config.treeName==='nostr-event-index'){
    if(config.marketAuthorityFile){throw new Error('Market authority cannot replace the existing archive');}
    return null;
  }
  if(!config.marketAuthorityFile||!isAbsolute(config.marketAuthorityFile)||config.protectedFiles?.[config.marketAuthorityFile]!==config.nativeAuthoritySha256){throw new Error('Separate Market publication requires a protected authority');}
  const bytes=await boundedFile(config.marketAuthorityFile,config.nativeAuthoritySha256,512*1024);
  const plan:MarketArchivePlan={...JSON.parse(bytes.toString()),authoritySha256:config.nativeAuthoritySha256};
  assertMarketArchivePlan(plan);
  if(plan.format!=='iris-social/market-archive-plan@1'||config.treeName!==plan.publication.treeName||
    canonical(config.expectedPolicy)!==canonical(plan.policy)||config.checkpointFile!==plan.paths.checkpoint||config.authorsFile!==plan.paths.authors||
    config.operationLock!==plan.paths.operationLock||config.outboxDirectory!==join(plan.paths.root,'publication')){throw new Error('Market publisher must use its exact isolated policy and paths');}
  return plan;
}

/** Exact immutable failed receipts retained across a reviewed native upgrade. */
export async function loadPriorNativeReceipts(pins: Record<string, string> = {}): Promise<ArchiveRunReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > 64) {
    throw new Error('Invalid prior native receipt pins');
  }
  return await Promise.all(Object.entries(pins).map(async ([file, sha]) => {
    if (!isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid prior native receipt pin');
    }
    const receipt: ArchiveRunReceipt = JSON.parse((await boundedFile(file, sha, 1024 * 1024)).toString());
    if (receipt.format !== 'iris-social/archive-catchup-run@1' || !Number.isSafeInteger(receipt.exitCode)
      || receipt.exitCode === 0 || !receipt.originalAndPoolPinsUnchanged
      || !/^[a-f0-9]{64}$/.test(receipt.authoritySha256)) {
      throw new Error('Prior native receipt must be a protected failed prefix');
    }
    return receipt;
  }));
}

/** One explicit relay-policy edge, independently pinned and never inferred from a native receipt. */
export async function loadArchiveRelayRemovalReceipts(pins: Record<string, string> = {}): Promise<ArchiveRelayRemovalReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > 1) {
    throw new Error('Invalid relay removal receipt pins');
  }
  return await Promise.all(Object.entries(pins).map(async ([file, sha]) => {
    if (!isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid relay removal receipt pin');
    }
    for (let parent = dirname(file); ; parent = dirname(parent)) {
      const metadata = await lstat(parent);
      if (!metadata.isDirectory() || metadata.isSymbolicLink()) {throw new Error('Relay removal pin has a symlink ancestor');}
      if (dirname(parent) === parent) {break;}
    }
    const receipt: ArchiveRelayRemovalReceipt = JSON.parse((await boundedFile(file, sha, 1024 * 1024)).toString());
    validateArchiveRelayRemovalReceipt(receipt);
    return receipt;
  }));
}

async function directDirectory(directory: string): Promise<void> {
  if (!isAbsolute(directory)) {throw new Error('Expected an absolute coverage directory');}
  for (let current = directory; ; current = dirname(current)) {
    const metadata = await lstat(current);
    if (!metadata.isDirectory() || metadata.isSymbolicLink()) {throw new Error('Coverage directory has a symlink ancestor');}
    if (dirname(current) === current) {break;}
  }
}

export async function loadArchiveSourceModeReceipts(pins: Record<string, string> = {}): Promise<ArchiveSourceModeReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > 1) {
    throw new Error('Invalid source mode receipt pins');
  }
  return await Promise.all(Object.entries(pins).map(async ([file, sha]) => {
    if (!isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid source mode receipt pin');
    }
    await directDirectory(dirname(file));
    const receipt: ArchiveSourceModeReceipt = JSON.parse((await boundedFile(file, sha, 1024 * 1024)).toString());
    validateArchiveSourceModeReceipt(receipt);
    return receipt;
  }));
}

/** Load only this publication's content-addressed author receipts, stopping at its prior committed head. */
export async function loadArchiveKindExpansionReceipts(pins: Record<string, string> = {}): Promise<ArchiveKindExpansionReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > 1) {
    throw new Error('Invalid kind expansion receipt pins');
  }
  return await Promise.all(Object.entries(pins).map(async ([file, sha]) => {
    if (!isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid kind expansion receipt pin');
    }
    await directDirectory(dirname(file));
    const receipt: ArchiveKindExpansionReceipt = JSON.parse((await boundedFile(file, sha, 1024 * 1024)).toString());
    validateArchiveKindExpansionReceipt(receipt);
    return receipt;
  }));
}

/** Physical batching may change only at a separately pinned, already published checkpoint. */
export async function loadArchiveCommitBatchReceipts(pins: Record<string, string> = {}): Promise<ArchiveCommitBatchReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > 1) {
    throw new Error('Invalid commit batch receipt pins');
  }
  return await Promise.all(Object.entries(pins).map(async ([file, sha]) => {
    if (!isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid commit batch receipt pin');
    }
    await directDirectory(dirname(file));
    const receipt: ArchiveCommitBatchReceipt = JSON.parse((await boundedFile(file, sha, 1024 * 1024)).toString());
    validateArchiveCommitBatchReceipt(receipt);
    return receipt;
  }));
}

/** Explicit policy edges account for their own coverage head; ordinary publications stop at the prior head. */
export async function loadArchiveCandidateCoverage(directory: string, run: ArchiveRunReceipt,
  previous: ArchiveCheckpoint | null, lineage: ArchiveLineageReceipt[], {strictCoverage=false}: {strictCoverage?:boolean} = {}): Promise<ArchiveSourceCoverageProof[]> {
  if (run.after.policy.source_mode !== 'best-effort' && !(strictCoverage && run.after.coverage_head !== undefined)) {return [];}
  const expansion = lineage.find(isArchiveKindExpansionReceipt);
  if (expansion) {validateArchiveKindExpansionReceipt(expansion);}
  const batching = lineage.find(isArchiveCommitBatchReceipt);
  if (batching) {validateArchiveCommitBatchReceipt(batching);}
  if (batching && expansion) {throw new Error('Multiple archive coverage transitions');}
  return await loadArchiveSourceCoverage(directory, run.after.coverage_head ?? '',
    expansion ? null : batching?.after.coverage_head ?? previous?.coverage_head ?? null);
}

/** Load only this publication's content-addressed author receipts, stopping at its prior committed head. */
export async function loadArchiveSourceCoverage(directory: string, head: string, previousHead: string | null = null): Promise<ArchiveSourceCoverageProof[]> {
  const valid = (value: unknown) => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
  if (!valid(head) || (previousHead !== null && !valid(previousHead))) {throw new Error('Invalid source coverage head');}
  await directDirectory(directory);
  const proofs: ArchiveSourceCoverageProof[] = [];
  let cursor: string | null = head;
  while (cursor !== previousHead) {
    if (!cursor || proofs.length >= 64) {throw new Error('Source coverage chain is missing or exceeds 64 authors');}
    const bytes = await boundedFile(join(directory, `${cursor}.json`), cursor, ARCHIVE_COVERAGE_MAX_BYTES);
    const raw = bytes.toString('utf8');
    if (!Buffer.from(raw).equals(bytes)) {throw new Error('Source coverage is not valid UTF-8');}
    const proof = { sha256: cursor, raw }, receipt = parseArchiveSourceCoverage(proof);
    proofs.unshift(proof); cursor = receipt.previous_head;
  }
  return proofs;
}

/** Bounded historical repairs: exact wrappers, native results, snapshots, events and executables. */
export async function loadArchiveRepairReceipts(pins: Record<string, string> = {},
  protectedFiles: Record<string, string> = {}): Promise<ArchiveRepairReceipt[]> {
  if (!pins || typeof pins !== 'object' || Array.isArray(pins) || Object.keys(pins).length > MAX_ARCHIVE_REPAIR_RECEIPTS) {
    throw new Error('Invalid archive repair receipt pins');
  }
  const pinned = async (file: string, sha: string, maxBytes = 1024 * 1024) => {
    if (typeof file !== 'string' || !isAbsolute(file) || typeof sha !== 'string' || !/^[a-f0-9]{64}$/.test(sha)) {
      throw new Error('Invalid archive repair file pin');
    }
    for (let parent = dirname(file); ; parent = dirname(parent)) {
      const metadata = await lstat(parent);
      if (!metadata.isDirectory() || metadata.isSymbolicLink()) {throw new Error('Archive repair pin has a symlink ancestor');}
      if (dirname(parent) === parent) {break;}
    }
    return await boundedFile(file, sha, maxBytes);
  };
  const receipts: ArchiveRepairReceipt[] = [], checkedExecutables = new Set<string>();
  // Historical receipts can share a large executable; verify it once and keep reads sequential.
  for (const [file, sha] of Object.entries(pins)) {
    const receipt: ArchiveRepairReceipt = JSON.parse((await pinned(file, sha)).toString());
    validateArchiveRepairReceipt(receipt);
    if (protectedFiles[receipt.tool.binaryFile] !== receipt.tool.binarySha256) {
      throw new Error('Archive repair executable is not protected');
    }
    // The executable may exceed the receipt/event bound; protection pins its exact bytes.
    if (!checkedExecutables.has(receipt.tool.binaryFile)) {
      await pinned(receipt.tool.binaryFile, receipt.tool.binarySha256, 128 * 1024 * 1024);
      checkedExecutables.add(receipt.tool.binaryFile);
    }
    const before = JSON.parse((await pinned(receipt.before.checkpointFile, receipt.before.checkpointSha256)).toString());
    const event: RawEvent = JSON.parse((await pinned(receipt.eventFile, receipt.eventFileSha256)).toString());
    const native = JSON.parse((await pinned(receipt.nativeRepairReceiptFile, receipt.nativeRepairReceiptSha256)).toString());
    if (canonical(before) !== canonical(receipt.before.state) || canonical(event) !== canonical(receipt.event)
      || native.format !== 'nostr-index/id-repair@1' || native.status !== 'complete'
      || native.beforeRoot !== receipt.before.state.root || native.afterRoot !== receipt.after.state.root
      || native.checkpointSha256 !== receipt.before.checkpointSha256 || native.eventFileSha256 !== receipt.eventFileSha256
      || native.eventCid !== receipt.eventCid || native.absentByIdBefore !== true || native.verifiedAfter !== true
      || canonical(native.event) !== canonical({ id: event.id, pubkey: event.pubkey, kind: event.kind, created_at: event.created_at })) {
      throw new Error('Archive repair evidence files do not match the pinned wrapper');
    }
    receipts.push(receipt);
  }
  validateArchiveRepairHistory(receipts);
  return receipts;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.includes('--help')) {
    console.log('Publish a durable native archive checkpoint: --config <private JSON> --receipt <native run JSON>. Locks, verifies, persists one signed event, then requires the configured minimum relay acknowledgements and signed readbacks (default two). Use --retry-current-delivery with --config only to resend the current signed pointer without reading signing keys or starting native work.');
    return;
  }
  const value = (key: string) => { const index = args.indexOf(key); if (index < 0 || !args[index + 1]) {throw new Error(`Missing ${key}`);} return resolve(args[index + 1]); };
  const retryDelivery = args.includes('--retry-current-delivery');
  if (retryDelivery && args.includes('--receipt')) {throw new Error('Delivery retry does not accept a native receipt');}
  const configFile = value('--config'), receiptFile = retryDelivery ? null : value('--receipt');
  const configBytes = await boundedFile(configFile);
  const config: Config = JSON.parse(configBytes.toString());
  const marketPlan=await loadMarketPublisherPlan(config);
  if (config.format !== 'iris-social/archive-publisher-config@1'
    || ![config.publisher, config.nativeAuthoritySha256, config.keysFileSha256, config.initialEventSha256,
      config.firstSemanticReceiptSha256].every(value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value))
    || !config.operationLock || config.protectionCommand.length < 1
    || Object.keys(config.protectedFiles).length === 0) { throw new Error('Invalid publisher authority'); }
  if (!args.includes('--locked')) {
    await mkdir(config.outboxDirectory, { recursive: true, mode: 0o700 });
    const outer = args.includes('--operation-lock-held') ? [] : ['--nonblock', config.operationLock, 'flock'];
    const result = spawnSync('flock', [...outer, '--nonblock', join(config.outboxDirectory, 'publication.lock'),
      process.execPath, fileURLToPath(import.meta.url), '--config', configFile,
      ...(retryDelivery ? ['--retry-current-delivery'] : ['--receipt', receiptFile!]), '--locked'], { stdio: 'inherit' });
    if (result.error) {throw result.error;}
    if (result.status !== 0) {throw new Error(`Locked publisher exited ${result.status ?? 'without status'}`);}
    return;
  }
  const verify = (event: RawEvent) => verifyEvent(JSON.parse(JSON.stringify(event)));
  const trustedRepairs = await loadArchiveRepairReceipts(config.repairReceiptFiles, config.protectedFiles);
  const protection = async () => {
    for (const [file, sha] of Object.entries(config.protectedFiles)) {
      const repairBinary = trustedRepairs.some(receipt => receipt.tool.binaryFile === file);
      await boundedFile(file, sha, (repairBinary ? 128 : 8) * 1024 * 1024);
    }
    execFileSync(config.protectionCommand[0], config.protectionCommand.slice(1), {
      stdio: ['ignore', 'ignore', 'pipe'], timeout: 60_000, maxBuffer: 1024 * 1024,
    });
  };
  if (retryDelivery && Object.hasOwn(config.protectedFiles, config.keysFile)) {
    throw new Error('Delivery retry cannot read a protected signing-key file');
  }
  await protection();
  if (retryDelivery) {
    const result = await retryArchiveCurrentDelivery({ directory: config.outboxDirectory,
      publisher: config.publisher, treeName: config.treeName, relays: config.relays,
      minimumConfirmedRelays: config.minimumConfirmedRelays, verify, checkProtection: protection,
      readHeads: relay => readArchivePointerHeads(relay, config.publisher, config.treeName), send: sendArchivePointer });
    console.log(JSON.stringify(result));
    return;
  }
  if (!receiptFile) {throw new Error('Missing native receipt');}
  const trustedPriorRuns = await loadPriorNativeReceipts(config.priorNativeReceiptFiles);
  const trustedRelayRemovals = await loadArchiveRelayRemovalReceipts(config.relayRemovalReceiptFiles);
  const trustedSourceModes = await loadArchiveSourceModeReceipts(config.sourceModeReceiptFiles);
  const trustedKindExpansions = await loadArchiveKindExpansionReceipts(config.kindExpansionReceiptFiles);
  const trustedCommitBatches = await loadArchiveCommitBatchReceipts(config.commitBatchReceiptFiles);
  const stateBytes = await boundedFile(config.checkpointFile);
  const state: ArchiveCheckpoint = JSON.parse(stateBytes.toString());
  const receiptBytes = await boundedFile(receiptFile);
  const run: ArchiveRunReceipt = JSON.parse(receiptBytes.toString());
  const current = await readJson<ArchivePublication>(join(config.outboxDirectory, 'current.json'));
  const receipts: ArchiveLineageReceipt[] = [...trustedPriorRuns, ...trustedRelayRemovals, ...trustedSourceModes, ...trustedKindExpansions, ...trustedCommitBatches];
  if (canonical(run.before) !== canonical(current?.candidate.state ?? null) && (current || run.before?.next_author !== 0)
    && current?.candidate.checkpointSha256 !== digest(stateBytes)) {
    const directory = dirname(receiptFile);
    const files = await Promise.all((await readdir(directory)).filter(name => /^(pilot|resume-pilot|continue)-.*\.json$/.test(name))
      .map(async name => ({ name, time: (await lstat(join(directory, name))).mtimeMs })));
    for (const file of files.sort((a, b) => b.time - a.time).slice(0, 256)) {
      receipts.push(JSON.parse((await boundedFile(join(directory, file.name))).toString()));
    }
  }
  const intermediateRuns = current?.candidate.checkpointSha256 === digest(stateBytes) ? []
    : archiveReceiptChain(run, current?.candidate.state ?? null, receipts);
  const repairReceipts = selectArchiveRepairs(state, run.after, trustedRepairs);
  // Coverage proves the unchanged native interval; the separately pinned repair changes only its final root.
  const sourceCoverage = await loadArchiveCandidateCoverage(config.sourceCoverageDirectory ?? '', run,
    current?.candidate.state ?? null, intermediateRuns, {strictCoverage:!!marketPlan});
  const candidate = { state, run, checkpointSha256: digest(stateBytes), receiptSha256: digest(receiptBytes), intermediateRuns,
    ...(repairReceipts.length ? { repairReceipts } : {}), ...(sourceCoverage.length ? { sourceCoverage } : {}) };
  const initialEvent: RawEvent = JSON.parse((await boundedFile(config.initialEventFile, config.initialEventSha256)).toString());
  const initialRoot = verify(initialEvent) ? parseHashtreeRootEvent(initialEvent) : null;
  if (!initialRoot || initialEvent.pubkey !== config.publisher || initialRoot.treeName !== config.treeName
    || nhashEncode(initialRoot.rootCid) !== config.expectedPolicy.base_root) {throw new Error('Initial signed pointer does not bind the historical base');}
  const authors = (await boundedFile(config.authorsFile, config.expectedPolicy.authors_sha256)).toString().trimEnd().split('\n');
  if (authors.length !== config.expectedPolicy.author_count || new Set(authors).size !== authors.length
    || authors.some(author => !/^[a-f0-9]{64}$/.test(author))) {throw new Error('Invalid frozen author list');}
  const semantic: SemanticReceipt = JSON.parse((await boundedFile(config.firstSemanticReceiptFile, config.firstSemanticReceiptSha256)).toString());
  if (!semantic.passed || semantic.checks.length < 4 || semantic.checks.some(check => !check.passed || !check.complete
    || !check.verifiedSignatures || check.missingHistorical.length || (check.freshRequired && check.missingFresh.length))) {
    throw new Error('First-cutover semantic acceptance is incomplete');
  }
  const canaryIds = [...new Set(semantic.checks.flatMap(check => [
    ...check.historicalWanted, ...(check.freshRequired ? check.freshWanted : []),
  ].map(event => event.id)))];
  if (canaryIds.length < 4 || canaryIds.some(id => !/^[a-f0-9]{64}$/.test(id))) {throw new Error('Missing signed semantic canaries');}
  const keyBytes = await boundedFile(config.keysFile, config.keysFileSha256, 8192);
  const keys = keyBytes.toString().match(/\bnsec1[023456789acdefghjklmnpqrstuvwxyz]+\b/g) ?? [];
  keyBytes.fill(0);
  if (keys.length !== 1) {throw new Error('Expected exactly one existing publication identity');}
  // Decoder errors may echo their input; never forward signing material to logs.
  const decoded = (() => {
    try { return decode(keys[0]); }
    catch { throw new Error('Existing publication identity cannot be decoded'); }
  })();
  if (decoded.type !== 'nsec') {throw new Error('Publication identity is not an nsec');}
  try {
    if (getPublicKey(decoded.data) !== config.publisher) {throw new Error('Publication identity mismatch');}
    const result = await publishArchiveCandidate({ directory: config.outboxDirectory,
      authoritySha256: digest(configBytes), publisher: config.publisher, treeName: config.treeName,
      relays: config.relays, minimumConfirmedRelays: config.minimumConfirmedRelays, initialEvent, candidate, verify,
      sign: async template => finalizeEvent(template, decoded.data),
      readHeads: relay => readArchivePointerHeads(relay, config.publisher, config.treeName),
      send: sendArchivePointer, checkProtection: protection,
      checkCandidate: async (next, current) => {
        if(marketPlan){
          for(const run of [...(next.intermediateRuns??[]),next.run]){
            if(run.format!=='iris-social/archive-catchup-run@1'){throw new Error('Market publication cannot change its finite policy');}
            validateMarketNativeReceipt(marketPlan,run as ArchiveRunReceipt,
              (next.sourceCoverage??[]).filter(proof=>proof.sha256===run.after.coverage_head));
          }
        }
        const [start, end] = validateArchiveCandidate(next, config.expectedPolicy, config.nativeAuthoritySha256,
          current?.candidate.state ?? null, Math.floor(Date.now() / 1000), trustedPriorRuns, trustedRepairs, trustedRelayRemovals,
          { sourceModeReceipts: trustedSourceModes, kindExpansionReceipts: trustedKindExpansions,
            commitBatchReceipts: trustedCommitBatches, authors, strictCoverage:!!marketPlan });
        if (!current && semantic.root !== next.state.root) {throw new Error('First-cutover receipt targets another root');}
        const checkpointBytes = await boundedFile(config.checkpointFile);
        if (digest(checkpointBytes) !== next.checkpointSha256 || canonical(JSON.parse(checkpointBytes.toString())) !== canonical(next.state)) {
          throw new Error('Checkpoint changed during publication');
        }
        const signal = AbortSignal.timeout(300_000);
        const { store, network } = archiveReadStore(config.readEndpoint, signal);
        await verifyArchiveAppend(store, next.state.root, current?.candidate.state.root ?? config.expectedPolicy.base_root,
          authors.slice(start, end), canaryIds, signal, progress => {
            console.error(JSON.stringify({ type: 'archive-verification', ...progress, ...network }));
          });
        if(marketPlan){await verifyMarketIndexReadback(store,next.state.root,marketPlan,canaryIds,signal);}
        for (const repair of next.repairReceipts ?? []) {
          if (!authors.slice(start, end).includes(repair.event.pubkey)) {throw new Error('Archive repair author is outside this native batch');}
          await verifyArchiveRepairEvidence(store, repair, current!.candidate.state.root, signal);
        }
      },
    });
    console.log(JSON.stringify({ eventId: result.event.id, checkpointSha256: result.candidate.checkpointSha256,
      nextAuthor: result.candidate.state.next_author, confirmedRelays: result.confirmedRelays }));
  } finally { decoded.data.fill(0); }
}

// The operational bundle is an entry point; imports do not start publication.
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error instanceof Error ? error.message : 'Publication failed'); process.exitCode = 1; });
}
