import { readFile } from 'node:fs/promises';
import { nhashDecode } from '@hashtree/core';
import { writeJsonAtomic } from '../src/server/filesystemBlockStore';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import {
  assertIrisSocialArchivePublicationKinds,
  gateNostrArchiveCoverage,
  parseNostrArchiveCoverageThresholdInputs,
  reportNostrArchiveCoverage,
  validateNostrArchiveCoverageThresholds,
  type NostrArchiveCoverageGateResult,
  type NostrArchiveCoverageThresholds,
} from '../src/server/nostrArchiveCoverage';
import {
  loopbackPostSearchDaemonUrl,
  parsePostSearchHandoff,
  pinAndPublishPostSearchCatalog,
  signPostSearchHandoff,
  type PostSearchPinResult,
} from '../src/server/postSearchCatalogPublisher';
import { HashtreeNostrSnapshotReader } from '../src/server/postSearchSnapshotReader';
import {
  POST_SEARCH_KINDS,
} from '../src/lib/postSearch';
import {
  verifyPostSearchCatalog,
  type PostSearchCatalogVerification,
} from './verify-post-search-catalog';

const DEFAULT_STORE_TIMEOUT_MS = 30_000;

const HELP = `Audit, sign, and publish an exact Iris Social post-search pointer handoff.

Required:
  --handoff-file <path>          Builder-produced pointer handoff JSON
  --identity-key-file <path>     Hashtree identity nsec file; never printed
  --daemon-url <URL>             Plain loopback HTTP Hashtree daemon URL
  --daemon-auth-file <path>      auth.cookie or JSON credentials; never printed
  --min-catalog-documents <n>    Minimum visible searchable catalog documents
  --verification-query <text>   Query that must return a signed catalog hit;
                                  repeat for independent production probes
  --min-latest-post-created-at <unix>
                                Newest valid kind-1 post must reach this timestamp
  --min-valid-events <count>     Minimum valid source events across required kinds
  --min-distinct-authors <count> Minimum distinct signature-valid source authors
  --min-kind-valid <kind>:<min>  Required kind and its minimum valid event count;
                                  repeat exactly once for every required kind

Required archive kinds: 0,1,3,5,6,7,16,20,1111,9735,10000,30000,30023.
Additional operator-selected kinds are allowed and gated identically.

Optional:
  --store-timeout-ms <ms>        Per-block archive audit timeout; default 30000

The handoff's exact immutable sourceEventRoot is re-read through the loopback
daemon and must pass every explicit coverage threshold before the identity key
is read. Only then is the catalog DAG pinned and its signed pointer published.
This command never opens the daemon-owned LMDB store.`;

export interface PostSearchPublicationCliOptions {
  handoffFile: string;
  identityKeyFile: string;
  daemonUrl: string;
  daemonAuthFile: string;
  storeTimeoutMs: number;
  minCatalogDocuments: number;
  verificationQueries: string[];
  minLatestPostCreatedAt: number;
  requiredKinds: number[];
  thresholds: NostrArchiveCoverageThresholds;
}

export interface PostSearchPublicationDependencies {
  readTextFile?: (path: string) => Promise<string>;
  writeJsonFile?: (path: string, value: unknown) => Promise<void>;
  fetch?: typeof fetch;
}

export interface PostSearchPublicationResult {
  accepted: true;
  eventId: string;
  publisherId: string;
  treeName: string;
  catalogRoot: string;
  catalog: PostSearchCatalogVerification;
  coverage: NostrArchiveCoverageGateResult;
  pin: PostSearchPinResult;
}

export async function publishPostSearchCatalogFromHandoff(
  options: PostSearchPublicationCliOptions,
  dependencies: PostSearchPublicationDependencies = {},
): Promise<PostSearchPublicationResult> {
  assertIrisSocialArchivePublicationKinds(options.requiredKinds, options.thresholds);
  validateNostrArchiveCoverageThresholds(options.requiredKinds, options.thresholds);
  const daemonUrl = loopbackPostSearchDaemonUrl(options.daemonUrl);
  const readTextFile = dependencies.readTextFile ?? readUtf8File;
  const writeJsonFile = dependencies.writeJsonFile ?? writeJsonAtomic;
  const handoffValue = parseJson(
    await readTextFile(options.handoffFile),
    'Invalid post-search pointer handoff JSON',
  );
  const parsedHandoff = parsePostSearchHandoff(handoffValue);
  const credentials = parseHttpBlockStoreCredentials(
    await readTextFile(options.daemonAuthFile),
  );
  const store = new HttpBlockStore(daemonUrl, {
    credentials,
    fetch: dependencies.fetch,
    timeoutMs: options.storeTimeoutMs,
  });
  const catalog = await verifyPostSearchCatalog({
    catalogRoot: parsedHandoff.catalogRoot,
    expectedPublisher: parsedHandoff.publisherId,
    expectedSourceRoot: parsedHandoff.sourceEventRoot,
    minDocuments: options.minCatalogDocuments,
    requiredKinds: [...POST_SEARCH_KINDS],
    queries: options.verificationQueries,
  }, store);
  const report = await reportNostrArchiveCoverage(
    new HashtreeNostrSnapshotReader(store),
    nhashDecode(parsedHandoff.sourceEventRoot),
    options.requiredKinds,
  );
  const coverage = gateNostrArchiveCoverage(report, options.thresholds);
  if (!coverage.passed) {
    throw new Error(`source archive coverage gates failed: ${coverage.failures.join('; ')}`);
  }
  const latestPostCreatedAt = report.kinds.find((kind) => kind.kind === 1)?.maxCreatedAt ?? null;
  if (latestPostCreatedAt === null || latestPostCreatedAt < options.minLatestPostCreatedAt) {
    throw new Error(
      `source archive latest valid kind-1 post ${latestPostCreatedAt ?? 'missing'} `
      + `< ${options.minLatestPostCreatedAt}`,
    );
  }

  // The identity is deliberately inaccessible until the immutable source audit passes.
  const encodedSecretKey = await readTextFile(options.identityKeyFile);
  const { handoff, event } = signPostSearchHandoff(handoffValue, encodedSecretKey);
  const pin = await pinAndPublishPostSearchCatalog(
    event,
    handoff.catalogRoot,
    daemonUrl,
    credentials,
    { fetch: dependencies.fetch },
  );
  await writeJsonFile(options.handoffFile, {
    ...handoff,
    status: 'signed-handoff',
    signedEvent: event,
  });
  return {
    accepted: true,
    eventId: event.id,
    publisherId: event.pubkey,
    treeName: handoff.treeName,
    catalogRoot: handoff.catalogRoot,
    catalog,
    coverage,
    pin,
  };
}

export function parsePostSearchPublicationArguments(
  args: readonly string[],
): PostSearchPublicationCliOptions {
  const normalized = args[0] === '--' ? args.slice(1) : [...args];
  const values = new Map<string, string>();
  const kindThresholds: string[] = [];
  const verificationQueries: string[] = [];
  const known = new Set([
    '--handoff-file',
    '--identity-key-file',
    '--daemon-url',
    '--daemon-auth-file',
    '--min-catalog-documents',
    '--verification-query',
    '--min-latest-post-created-at',
    '--store-timeout-ms',
    '--min-valid-events',
    '--min-distinct-authors',
    '--min-kind-valid',
  ]);
  for (let index = 0; index < normalized.length; index += 2) {
    const key = normalized[index];
    const value = normalized[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid publisher argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown publisher argument: ${key}`);
    }
    if (key === '--min-kind-valid') {
      kindThresholds.push(value);
      continue;
    }
    if (key === '--verification-query') {
      const query = value.trim();
      if (!query) {
        throw new Error('--verification-query must not be empty');
      }
      verificationQueries.push(query);
      continue;
    }
    if (values.has(key)) {
      throw new Error(`Duplicate publisher argument: ${key}`);
    }
    values.set(key, value.trim());
  }
  const daemonUrl = loopbackPostSearchDaemonUrl(required(values, '--daemon-url'));
  const coverage = parseNostrArchiveCoverageThresholdInputs({
    requiredKinds: [],
    minValidEvents: values.get('--min-valid-events'),
    minDistinctAuthors: values.get('--min-distinct-authors'),
    minKindValid: kindThresholds,
    inferRequiredKindsFromMinimums: true,
  });
  assertIrisSocialArchivePublicationKinds(coverage.requiredKinds, coverage.thresholds);
  if (verificationQueries.length === 0) {
    throw new Error('Missing required publisher argument: --verification-query');
  }
  return {
    handoffFile: required(values, '--handoff-file'),
    identityKeyFile: required(values, '--identity-key-file'),
    daemonUrl,
    daemonAuthFile: required(values, '--daemon-auth-file'),
    minCatalogDocuments: positiveInteger(
      required(values, '--min-catalog-documents'),
      '--min-catalog-documents',
    ),
    verificationQueries,
    minLatestPostCreatedAt: positiveInteger(
      required(values, '--min-latest-post-created-at'),
      '--min-latest-post-created-at',
    ),
    storeTimeoutMs: values.has('--store-timeout-ms')
      ? positiveInteger(required(values, '--store-timeout-ms'), '--store-timeout-ms')
      : DEFAULT_STORE_TIMEOUT_MS,
    requiredKinds: coverage.requiredKinds,
    thresholds: coverage.thresholds,
  };
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parsePostSearchPublicationArguments(process.argv.slice(2));
  const result = await publishPostSearchCatalogFromHandoff(options);
  process.stdout.write(`${JSON.stringify(result)}\n`);
}

async function readUtf8File(path: string): Promise<string> {
  return await readFile(path, 'utf8');
}

function parseJson(value: string, message: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    throw new Error(message);
  }
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key)?.trim();
  if (!value) {
    throw new Error(`Missing required publisher argument: ${key}`);
  }
  return value;
}

function positiveInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`post-search publisher failed: ${message}\n`);
    process.exitCode = 1;
  });
}
