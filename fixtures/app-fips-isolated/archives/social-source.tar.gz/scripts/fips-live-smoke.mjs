import { chromium } from '@playwright/test';
import { finalizeEvent, generateSecretKey } from 'nostr-tools';

const compressedPeerPattern = /^(02|03)[0-9a-f]{64}$/i;
const baseUrl = process.env.FIPS_SMOKE_BASE_URL?.trim() || 'http://127.0.0.1:4191/';
const peerId = process.env.FIPS_SMOKE_PEER?.trim().toLowerCase() || '';
const relays = (process.env.FIPS_SMOKE_RELAYS || 'wss://temp.iris.to,wss://relay.primal.net')
  .split(/[\s,]+/)
  .map((relay) => relay.trim())
  .filter(Boolean);

if (!compressedPeerPattern.test(peerId)) {
  throw new Error('FIPS_SMOKE_PEER must be one compressed FIPS identity');
}
if (relays.length === 0) {
  throw new Error('FIPS_SMOKE_RELAYS must contain at least one discovery relay');
}

const event = finalizeEvent({
  kind: 1,
  created_at: Math.floor(Date.now() / 1_000),
  tags: [['client', 'Iris Social FIPS smoke']],
  content: `Iris Social FIPS live smoke ${crypto.randomUUID()}`,
}, generateSecretKey());

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage();
  await page.addInitScript(({ admittedPeer, discoveryRelays }) => {
    window.__IRIS_SOCIAL_RUNTIME_OVERRIDES__ = {
      fipsDiscoveryApp: 'iris-social-v1',
      fipsPeers: [admittedPeer],
      relays: discoveryRelays,
    };
  }, { admittedPeer: peerId, discoveryRelays: relays });
  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });

  const eventId = await page.evaluate(async (signedEvent) => {
    const { getLiveNostrPubsub } = await import('/src/lib/fipsP2P.ts');
    const deadline = Date.now() + 30_000;
    let lastError = 'Live Nostr pubsub did not start';
    while (Date.now() < deadline) {
      try {
        const service = await getLiveNostrPubsub();
        if (service) {
          await service.refreshPeers();
          await service.idle();
          await service.publish(signedEvent);
          return signedEvent.id;
        }
      } catch (error) {
        lastError = error instanceof Error ? error.message : String(error);
      }
      await new Promise((resolve) => setTimeout(resolve, 1_000));
    }
    throw new Error(lastError);
  }, event);

  process.stdout.write(`${JSON.stringify({ eventId })}\n`);
} finally {
  await browser.close();
}
