import type { Store } from '@hashtree/core';
import type { ProfileSearchV3CurrentStateReader } from '../src/server/profileSearchV3CatalogBuilder';

export const PROFILE_SEARCH_V3_CLI_EVENT_FORMAT =
  'iris-social/profile-search-v3-catalog-operation@1' as const;
export const PROFILE_SEARCH_V3_HANDOFF_FORMAT =
  'iris-social/profile-search-v3-catalog-handoff@1' as const;

export const PROFILE_SEARCH_V3_CLI_HELP = `Build or verify an immutable Iris Social Profile Search v3 catalog.

Common required:
  --source-root <nhash>                    Exact immutable Hashtree Nostr root
  --rank-decisions-file <absolute path>   Canonical rank decision JSONL
  --expected-rank-decisions-sha256 <hex>  Independently supplied decision digest
  --max-reachable-nodes <count>           Explicit verification/cutover capacity

Store (choose exactly one):
  --store-url <http(s) URL>                Production daemon source/output API
  --offline-store <absolute directory>    Portable hashtree-fs source/output CAS

Build mode required:
  --state-file <absolute path>             Fsynced resumable builder state
  --scratch-parent <absolute directory>   Dedicated bounded-sort scratch parent

Verify-only mode:
  --verify-only <catalog nhash>            Strictly verify an existing catalog

Optional:
  --store-auth-file <path>                 auth.cookie or JSON credentials; URL only
  --store-timeout-ms <ms>                  Default 30000; URL only

Build mode optional:
  --source-read-batch <count>              Default 16
  --generated-at <unix seconds>            Exact value; omitted resumes persisted value
  --sort-chunk-postings <count>
  --profile-buffer-entries <count>
  --profile-buffer-bytes <bytes>
  --sort-merge-fan-in <2..128>

The rank file is canonical newline-delimited JSON: one header followed by
strictly pubkey-sorted explicit eligible/excluded records. Its embedded digest,
the independently supplied digest, and the digest recomputed from every record
must agree. Build resume accepts only the exact source, digest, configuration,
and (when supplied) generatedAt already bound into the state file.

This command never signs, pins, publishes, resolves a mutable ref, reads a
Nostr secret key, or opens daemon LMDB. Production access is exclusively via
the authenticated block API; offline mode accepts only a portable CAS.
Progress and the final verified handoff are one canonical JSON object per line.`;

export interface ProfileSearchV3CatalogCliOptions {
  sourceRoot: string;
  storeUrl?: string;
  offlineStore?: string;
  storeAuthFile?: string;
  storeTimeoutMs?: number;
  rankDecisionsFile: string;
  expectedRankDecisionsSha256: string;
  maxReachableNodes: number;
  verifyOnly?: string;
  sourceReadBatch?: number;
  stateFile?: string;
  scratchParent?: string;
  generatedAt?: number;
  sortChunkPostings?: number;
  profileBufferEntries?: number;
  profileBufferBytes?: number;
  sortMergeFanIn?: number;
}

export interface ProfileSearchV3CatalogHandoff {
  [key: string]: unknown;
  format: typeof PROFILE_SEARCH_V3_HANDOFF_FORMAT;
  operation: 'build' | 'verify';
  status: 'verified';
  catalogRoot: string;
  sourceRoot: string;
  eligibleRanksSha256: string;
  generatedAt: number;
  profileCount: number;
  postingCount: number;
  pageCount: number;
  runCount: number;
  reachableNodeCount: number;
  maxReachableNodes: number;
  resumed: boolean | null;
  publicationPerformed: false;
}

export interface ProfileSearchV3CliDependencies {
  store?: Store;
  snapshotReader?: ProfileSearchV3CurrentStateReader;
  emit?: (record: Record<string, unknown>) => void;
}
