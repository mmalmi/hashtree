import { randomBytes } from 'node:crypto';
import {
  mkdir,
  open,
  readFile,
  rename,
  rm,
} from 'node:fs/promises';
import { dirname, isAbsolute, resolve } from 'node:path';
import {
  createProfileSearchV3RankDecisionArtifacts,
  type ProfileSearchV3RankDecisionArtifactReport,
} from '../src/server/profileSearchV3RankDecisionArtifacts';

const HELP = `Derive canonical Profile Search v3 rank decisions from the exact crawl census.

Required:
  --social-graph-file <absolute path> Exact socialGraph.bin snapshot
  --census-report <absolute path>     Exact validated broad-archive census JSON
  --eligible-authors <absolute path>  Exact frozen eligible-author allowlist
  --output-file <absolute path>       Canonical eligible/excluded JSONL
  --report-file <absolute path>       Atomic artifact handoff JSON

Every identity in the snapshot receives a decision. Crawl-selected identities
use frozen follow distance as rank; overmuted, unreachable, and distance-capped
identities are explicit exclusions. This command performs no network access,
signing, pinning, publication, LMDB access, or service mutation.`;

export interface ProfileSearchV3RankDecisionCliOptions {
  socialGraphFile: string;
  censusReportFile: string;
  eligibleAuthorsFile: string;
  outputFile: string;
  reportFile: string;
}

export function parseProfileSearchV3RankDecisionArguments(
  rawArgs: readonly string[],
): ProfileSearchV3RankDecisionCliOptions {
  const args = rawArgs[0] === '--' ? rawArgs.slice(1) : [...rawArgs];
  const known = new Set([
    '--social-graph-file',
    '--census-report',
    '--eligible-authors',
    '--output-file',
    '--report-file',
  ]);
  const values = new Map<string, string>();
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid rank-decision argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown rank-decision argument: ${key}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate rank-decision argument: ${key}`);
    }
    values.set(key, value);
  }
  const options = {
    socialGraphFile: absolute(values, '--social-graph-file'),
    censusReportFile: absolute(values, '--census-report'),
    eligibleAuthorsFile: absolute(values, '--eligible-authors'),
    outputFile: absolute(values, '--output-file'),
    reportFile: absolute(values, '--report-file'),
  };
  if (new Set(Object.values(options)).size !== Object.keys(options).length) {
    throw new Error('Rank-decision input and output paths must differ');
  }
  return options;
}

export async function runProfileSearchV3RankDecisionOperation(
  options: ProfileSearchV3RankDecisionCliOptions,
): Promise<ProfileSearchV3RankDecisionArtifactReport> {
  assertDistinctPaths(options);
  const [snapshotBytes, eligibleAuthorsText, censusText] = await Promise.all([
    readFile(options.socialGraphFile),
    readFile(options.eligibleAuthorsFile, 'utf8'),
    readFile(options.censusReportFile, 'utf8'),
  ]);
  let census: unknown;
  try {
    census = JSON.parse(censusText) as unknown;
  } catch {
    throw new Error('Profile-search v3 census report is not valid JSON');
  }
  const artifacts = await createProfileSearchV3RankDecisionArtifacts(
    new Uint8Array(snapshotBytes),
    eligibleAuthorsText,
    census,
  );
  await writeFsyncedTextAtomic(options.outputFile, artifacts.rankDecisionsText);
  const writtenRanks = await readFile(options.outputFile, 'utf8');
  if (writtenRanks !== artifacts.rankDecisionsText) {
    throw new Error('Written profile-search v3 rank decisions changed');
  }
  await writeFsyncedTextAtomic(
    options.reportFile,
    `${JSON.stringify(artifacts.report, null, 2)}\n`,
  );
  const writtenReport = JSON.parse(await readFile(options.reportFile, 'utf8')) as unknown;
  if (JSON.stringify(writtenReport) !== JSON.stringify(artifacts.report)) {
    throw new Error('Written profile-search v3 rank-decision report changed');
  }
  return artifacts.report;
}

function absolute(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {
    throw new Error(`Missing required rank-decision argument: ${key}`);
  }
  if (!isAbsolute(value)) {
    throw new Error(`${key} must be an absolute path`);
  }
  return resolve(value);
}

function assertDistinctPaths(options: ProfileSearchV3RankDecisionCliOptions): void {
  const paths = Object.values(options).map((path) => resolve(path));
  if (new Set(paths).size !== paths.length) {
    throw new Error('Rank-decision input and output paths must differ');
  }
}

async function writeFsyncedTextAtomic(path: string, text: string): Promise<void> {
  const target = resolve(path);
  const directory = dirname(target);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const temporary = `${target}.tmp-${process.pid}-${randomBytes(8).toString('hex')}`;
  try {
    const file = await open(temporary, 'wx', 0o600);
    try {
      await file.writeFile(text);
      await file.sync();
    } finally {
      await file.close();
    }
    await rename(temporary, target);
    const handle = await open(directory, 'r');
    try {
      await handle.sync();
    } finally {
      await handle.close();
    }
  } finally {
    await rm(temporary, { force: true });
  }
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  try {
    const report = await runProfileSearchV3RankDecisionOperation(
      parseProfileSearchV3RankDecisionArguments(process.argv.slice(2)),
    );
    process.stdout.write(`${JSON.stringify(report)}\n`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Profile-search v3 rank-decision derivation failed: ${message}\n`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main();
}
