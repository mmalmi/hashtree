#!/usr/bin/env python3
"""One native diagnostic admission; no native build or publication implementation.

Linux/systemd adapter plus a filesystem state machine. All deployment identities
and paths come from a separately reviewed, SHA256-bound private binding. Run this
from an independent supervisor, not an interactive shell. A nonzero/held result
requires the named recovery owner; a parked timer is never a healthy result.
"""
import argparse
import base64
import contextlib
import copy
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import time
import uuid

sys.dont_write_bytecode = True
CONTROLS = ('authority.json', 'publication/publisher-config.json', 'publication/launcher.json')
JOURNAL = 'receipts/continuation-batch.json'
MAX_INPUT = 8 * 1024 * 1024
TERMINAL = ('restored', 'aborted')


class Hold(RuntimeError):
    pass


def require(ok, reason):
    if not ok:
        raise Hold(reason)


def control_names(binding):
    # Select only the separately reviewed binding path, never a path learned
    # from the mutable launcher. Historical config bytes remain untouched when
    # the publisher uses a versioned config.
    selected = binding.get('publisher_config')
    require(isinstance(selected, str) and re.fullmatch(
        r'(?:publication|versions/[a-zA-Z0-9][a-zA-Z0-9._-]*)/publisher-config\.json', selected) is not None,
        'publisher config binding invalid')
    return (CONTROLS[0], selected, CONTROLS[2])


def publication_controls(binding, raw):
    names = control_names(binding)
    authority, config, launcher = [json.loads(raw[n]) for n in names]
    require(config['nativeAuthoritySha256'] == sha(raw[names[0]])
            and launcher['configSha256'] == sha(raw[names[1]]), 'control chain broken')
    require(launcher['configFile'] == str(Path(binding['root']) / names[1]), 'publisher config path changed')
    bundle = binding['publisher_bundle']
    require(launcher['bundleFile'] == bundle['path'] and launcher['bundleSha256'] == bundle['sha256'],
            'publisher bundle binding changed')
    require(config['protectedFiles'].get(bundle['path']) == bundle['sha256']
            and file_sha(bundle['path']) == bundle['sha256'], 'publisher bundle protection changed')
    return authority, config, launcher


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def direct(path):
    path = Path(path)
    require(path.is_absolute() and all(not p.is_symlink() for p in (path, *path.parents)), 'non-direct path')
    info = path.stat()
    require(stat.S_ISREG(info.st_mode), 'non-regular input')
    return {'uid': info.st_uid, 'gid': info.st_gid, 'mode': stat.S_IMODE(info.st_mode)}


def read(path):
    direct(path)
    require(Path(path).stat().st_size <= MAX_INPUT, 'input exceeds bound')
    with Path(path).open('rb') as stream:
        raw = stream.read(MAX_INPUT + 1)
    require(len(raw) <= MAX_INPUT, 'input grew past bound')
    return raw


def read_state(path, binding_sha, owner):
    value = json.loads(read(path))
    fields = {'format', 'binding_sha256', 'owner', 'phase', 'launch_consumed', 'original_timer', 'boot_id'}
    phases = {'parking', 'boundary', 'activating', 'ready', 'launch-uncertain', 'running',
              'restoring', 'restoring-timer', 'held', *TERMINAL}
    require(isinstance(value, dict) and fields <= set(value), 'malformed controller state')
    require(value['format'] == 'iris-social/diagnostic-control@1' and value['binding_sha256'] == binding_sha
            and value['owner'] == owner, 'controller identity drift')
    require(value['phase'] in phases and type(value['launch_consumed']) is bool
            and isinstance(value['boot_id'], str), 'malformed controller phase/claim')
    timer = value['original_timer']
    require(isinstance(timer, dict) and set(timer) == {'active', 'enabled'} and type(timer['active']) is bool
            and timer['enabled'] in ('enabled', 'disabled'), 'malformed original timer')
    if value['phase'] == 'held':
        require(value.get('resume_phase') in phases - {'held'}, 'malformed recovery phase')
    return value


def file_sha(path):
    direct(path)
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable(path, raw, metadata=None):
    path = Path(path)
    require(len(raw) <= MAX_INPUT, 'output exceeds bound')
    require(path.parent.is_dir() and all(not p.is_symlink() for p in (path, *path.parents)), 'non-direct output')
    metadata = metadata or {'uid': os.getuid(), 'gid': os.getgid(), 'mode': 0o600}
    temp = path.with_name('.' + path.name + '-' + uuid.uuid4().hex)
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, metadata['mode'])
    try:
        with os.fdopen(fd, 'wb') as stream:
            if (os.getuid(), os.getgid()) != (metadata['uid'], metadata['gid']):
                os.fchown(stream.fileno(), metadata['uid'], metadata['gid'])
            os.fchmod(stream.fileno(), metadata['mode'])
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        sync_directory(path.parent)
    finally:
        if temp.exists():
            temp.unlink()


@contextlib.contextmanager
def locked(path, create=False):
    path = Path(path)
    if create and not path.exists():
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
        sync_directory(path.parent)
    direct(path)
    with path.open('r+b') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Hold('operation owned by another process')
        yield


class Systemd:
    def __init__(self, binding):
        self.b = binding

    def command(self, *args):
        # Bounded control output; never attach native stdout/stderr here.
        result = subprocess.run(['/usr/bin/systemctl', *args], capture_output=True,
                                text=True, timeout=20)
        require(len(result.stdout) + len(result.stderr) <= 65536, 'systemd output bound')
        require(result.returncode == 0, 'systemd control failed')
        return result.stdout.strip()

    def properties(self, unit, names):
        result = self.command('show', unit, *['--property=' + n for n in names])
        values = dict(line.split('=', 1) for line in result.splitlines() if '=' in line)
        require(set(names) <= set(values), 'incomplete service state')
        return values

    def timer(self):
        d = self.properties(self.b['timer'], ['ActiveState', 'UnitFileState'])
        require(d['ActiveState'] in ('active', 'inactive'), 'timer is transitioning')
        require(d['UnitFileState'] in ('enabled', 'disabled'), 'reviewed enabled/disabled timer required')
        return {'active': d['ActiveState'] == 'active', 'enabled': d['UnitFileState']}

    def boot_id(self):
        return read('/proc/sys/kernel/random/boot_id').decode().strip()

    def initial_timer_evidence(self, original):
        require(self.timer_links() == self.b['timer_links'], 'initial timer symlink snapshot changed')
        require((original['enabled'] == 'enabled') == bool(self.b['timer_links']), 'initial timer enablement snapshot inconsistent')
        for unit, settings in self.b['unit_settings'].items():
            for path in [settings['fragment'], *settings['dropins']]:
                require(file_sha(path) == self.b['pinned_files'][path], 'original unit/condition changed')
            d = self.properties(unit, ['FragmentPath', 'DropInPaths'])
            require(d['FragmentPath'] == settings['fragment']
                    and sorted(shlex.split(d['DropInPaths'])) == sorted(settings['dropins']), 'initialize before installing temporary guard')

    def maintenance_ready(self):
        for path, body in systemd_payloads(self.b, self.b['_binding_sha']).items():
            require(read(path) == body.encode(), 'maintenance unit/drop-in changed')
        for unit, settings in self.b['unit_settings'].items():
            for path in [settings['fragment'], *settings['dropins']]:
                require(file_sha(path) == self.b['pinned_files'][path], 'original unit/condition changed')
            d = self.properties(unit, ['FragmentPath', 'DropInPaths'])
            expected = settings['dropins'] + ([self.b['maintenance']['service_dropin']] if unit == self.b['service'] else [])
            require(d['FragmentPath'] == settings['fragment'] and sorted(shlex.split(d['DropInPaths'])) == sorted(expected), 'unrelated unit setting/drop-in drift')
        link = Path(self.b['maintenance']['boot_enable_link'])
        require(link.is_symlink() and os.readlink(link) == self.b['maintenance']['boot_unit_path']
                and link.lstat().st_uid == link.lstat().st_gid == 0
                and all(not p.is_symlink() for p in link.parents), 'independent boot recovery is not enabled exactly')
        require(self.properties(self.b['maintenance']['boot_unit'], ['UnitFileState', 'Restart']) ==
                {'UnitFileState': 'enabled', 'Restart': 'no'}, 'boot recovery settings drift')
        active = self.properties(self.b['maintenance']['boot_unit'], ['ActiveState'])['ActiveState']
        explicit_recovery = self.b.get('_mode') in ('recover', 'replay-publication', 'audit')
        require(active == 'active' or (self.b.get('_mode') == 'boot-recover' and active == 'activating')
                or (explicit_recovery and active in ('inactive', 'failed')), 'independent recovery must be armed first')

    def timer_links(self):
        found, count = [], 0
        fragment = self.b['unit_settings'][self.b['timer']]['fragment']
        for root in self.b['timer_link_roots']:
            for parent, dirs, names in os.walk(root, followlinks=False):
                count += len(dirs) + len(names)
                require(count <= 20000, 'systemd metadata inventory bound')
                for name in dirs + names:
                    path = Path(parent) / name
                    if path.is_symlink():
                        target = os.readlink(path)
                        resolved = os.path.normpath(os.path.join(parent, target))
                        if name == self.b['timer'] or resolved == fragment:
                            st = path.lstat()
                            found.append({'path': str(path), 'target': target, 'uid': st.st_uid, 'gid': st.st_gid})
        return sorted(found, key=lambda row: row['path'])

    def change_timer_links(self, enabled):
        expected = self.b['timer_links']
        current = self.timer_links()
        require(all(row in expected for row in current), 'changed/unrelated timer enablement symlink')
        for row in expected:
            path = Path(row['path'])
            require(all(not p.is_symlink() for p in path.parents), 'timer link parent changed')
            if path.exists() or path.is_symlink():
                require(path.is_symlink() and os.readlink(path) == row['target']
                        and path.lstat().st_uid == row['uid'] and path.lstat().st_gid == row['gid'], 'timer link replaced or changed')
            if enabled:
                if not path.exists() and not path.is_symlink():
                    os.symlink(row['target'], path)
                    os.lchown(path, row['uid'], row['gid'])
                    sync_directory(path.parent)
            elif path.is_symlink():
                require(os.readlink(path) == row['target'] and path.lstat().st_uid == row['uid']
                        and path.lstat().st_gid == row['gid'], 'timer symlink changed')
                path.unlink()
                sync_directory(path.parent)
        self.command('daemon-reload')
        require(self.timer_links() == (expected if enabled else []), 'timer enablement links differ')

    def park(self, original):
        require(self.timer()['enabled'] in (original['enabled'], 'disabled'), 'timer enablement drift')
        # Durable across reboot; restore the original enablement only with the
        # baseline executable. Stopping an enabled timer alone is insufficient.
        self.change_timer_links(False)
        self.command('stop', self.b['timer'])

    def restore_timer(self, original):
        require(self.timer()['enabled'] in ('disabled', original['enabled']), 'timer enablement drift')
        if self.b.get('_mode') == 'recover':
            # Baseline + current-boot restoration stamp is durable before this
            # call. Its boot probe is a no-op and cannot contend for our lock.
            self.command('reset-failed', self.b['maintenance']['boot_unit'])
            self.command('start', self.b['maintenance']['boot_unit'])
        self.change_timer_links(original['enabled'] == 'enabled')
        self.command('start' if original['active'] else 'stop', self.b['timer'])
        require(self.timer() == original, 'timer restoration failed')

    def service(self):
        d = self.properties(self.b['service'], ['ActiveState', 'Job', 'InvocationID', 'Restart'])
        require(d['Restart'] == 'no', 'automatic service restart would violate one admission')
        active, queued = d['ActiveState'] not in ('inactive', 'failed'), d['Job'] not in ('', '0')
        return {'active': active, 'queued': queued, 'busy': active or queued,
                'invocation': d['InvocationID']}

    def launch(self):
        # At most one request. A crash/timeout before the caller records the
        # response is ambiguous and never authorizes a retry of this command.
        self.command('start', '--no-block', self.b['service'])

    def guard(self):
        # Existing protection program; no relay availability check is added.
        with open(os.devnull, 'wb') as sink:
            result = subprocess.run(self.b['protection_command'], stdout=sink, stderr=sink, timeout=90)
        require(result.returncode == 0, 'existing protection check failed')


class Controller:
    def __init__(self, binding, binding_sha, backend, now=time.time, fault=lambda _: None):
        self.b, self.binding_sha, self.backend = binding, binding_sha, backend
        self.control_names = control_names(binding)
        self.now, self.fault = now, fault
        self.root, self.home = Path(binding['root']), Path(binding['state_directory'])
        self.state_path = self.home / 'state.json'
        self.operation = self.root / 'receipts/operation.lock'
        self.s = read_state(self.state_path, binding_sha, binding['recovery_owner']) if self.state_path.exists() else None
        spec = importlib.util.spec_from_file_location('sealed_continuation', binding['continuation']['path'])
        require(file_sha(binding['continuation']['path']) == binding['continuation']['sha256'], 'continuation changed')
        self.continuation = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.continuation)

    def save(self, **values):
        self.s.update(values)
        durable(self.state_path, encode(self.s))

    def controls(self):
        return {name: read(self.root / name) for name in self.control_names}

    def expected(self):
        return self.s.get('expected_controls', self.b['expected_controls'])

    def check_controls(self):
        raw = self.controls()
        require({k: sha(v) for k, v in raw.items()} == self.expected(), 'control drift; preserve foreign work')
        a, c, launcher = publication_controls(self.b, raw)
        require(a['recurringMaxAuthors'] == 8, 'current eight-author bound required')
        command = a['command']
        require(command.count('--index-commit-batch-size') == 1 and command[command.index('--index-commit-batch-size') + 1] == '1024', 'current commit batch changed')
        require(c['operationLock'] == launcher['operationLock'] == str(self.operation), 'operation lock changed')
        require(file_sha(a['binary']['path']) == a['binary']['sha256'], 'active executable changed')
        return raw, a, c, launcher

    def snapshot(self, config):
        paths = {'checkpoint': config['checkpointFile'], 'current': str(Path(config['outboxDirectory']) / 'current.json'),
                 'journal': str(self.root / JOURNAL)}
        raw = {k: read(p) for k, p in paths.items()}
        pending = Path(config['outboxDirectory']) / 'pending.json'
        return paths, raw, {k: json.loads(v) for k, v in raw.items()}, pending

    def start(self):
        if self.s:
            return
        original = self.backend.timer()
        self.backend.initial_timer_evidence(original)
        self.s = {'format': 'iris-social/diagnostic-control@1', 'binding_sha256': self.binding_sha,
                  'owner': self.b['recovery_owner'], 'phase': 'parking', 'launch_consumed': False,
                  'boot_id': self.backend.boot_id(),
                  'original_timer': original, 'started_at': self.now(),
                  'admission_deadline': self.now() + self.b['admission_seconds'],
                  'supervision_deadline': self.now() + self.b['supervision_seconds']}
        self.save()

    def prefix(self, values, authority_sha):
        state, current, journal = values['checkpoint'], values['current'], values['journal']
        published = current['candidate']['state']
        if journal is None:
            require(state == published, 'completed unpublished receipt needs original publisher')
            return []
        require(journal['authoritySha256'] == authority_sha and journal['maxAuthors'] == 8, 'continuation authority/bound changed')
        require(journal['begin'] == published and 0 <= journal['attempts'] <= 64, 'continuation intent mismatch')
        require(not any(k in journal for k in ('relayRemoval', 'sourceMode', 'kindExpansion', 'commitBatch')), 'policy transition still in progress')
        count = published['policy']['author_count']
        start = 0 if published['next_author'] == count else published['next_author']
        require(journal['targetAuthor'] == min(start + 8, count), 'continuation endpoint mismatch')
        position = self.continuation.ordinal(published, state)
        require(position < journal['targetAuthor'], 'completed unpublished batch needs original publisher')
        require(journal['inFlight'] is None, 'orphaned native intent must be recorded first')
        if state == published:
            return []
        receipts = list(self.continuation.recent_receipts(self.root / 'receipts'))
        chain, cursor = [], state
        while cursor != published:
            require(len(chain) < 64, 'failed prefix exceeds bound')
            matches = [(p, r) for p, r in receipts if r.get('after') == cursor and r.get('before') != cursor]
            require(len(matches) == 1, 'failed prefix missing or ambiguous')
            path, receipt = matches[0]
            require(type(receipt.get('exitCode')) is int and receipt['exitCode'] != 0
                    and receipt.get('originalAndPoolPinsUnchanged') is True
                    and receipt.get('authoritySha256') == authority_sha, 'untrusted failed prefix')
            before = receipt['before']
            require(self.continuation.ordinal(published, before) < self.continuation.ordinal(published, cursor), 'non-advancing failed prefix')
            chain.insert(0, (path, read(path)))
            cursor = before
        return chain

    def recover_orphan(self, values, authority_sha):
        journal, state = values['journal'], values['checkpoint']
        if not journal or not journal.get('inFlight'):
            return
        before = journal['inFlight']['before']
        published = values['current']['candidate']['state']
        clean = copy.deepcopy(journal)
        clean['inFlight'] = None
        self.prefix(dict(values, checkpoint=before, journal=clean), authority_sha)
        begin = self.continuation.ordinal(published, before)
        end = self.continuation.ordinal(published, state)
        require(begin <= end < journal['targetAuthor'], 'orphan reached full endpoint; original owner review required')
        require(journal['inFlight']['maxAuthors'] == journal['targetAuthor'] - begin, 'orphan span changed')
        require(begin != end or before == state, 'same-author durable checkpoint drift')
        receipt = {'format': 'iris-social/archive-catchup-run@1', 'mode': 'continue', 'exitCode': 1,
                   'nativeExitCode': None, 'recoveredAfterInterruption': True, 'before': before, 'after': state,
                   'authoritySha256': authority_sha, 'originalAndPoolPinsUnchanged': True, 'publicationAttempted': False}
        # The original launcher may have saved a native receipt just before it
        # died. Do not manufacture a competing receipt for an identical edge.
        matches = [(p, r) for p, r in self.continuation.recent_receipts(self.root / 'receipts')
                   if r.get('before') == before and r.get('after') == state]
        require(len(matches) <= 1, 'ambiguous orphan receipt')
        if matches:
            path, existing = matches[0]
            require(type(existing.get('exitCode')) is int and existing['exitCode'] != 0
                    and existing.get('authoritySha256') == authority_sha
                    and existing.get('originalAndPoolPinsUnchanged') is True, 'orphan receipt requires original publisher/owner')
        else:
            raw = encode(receipt)
            path = self.root / 'receipts' / ('continue-recovered-diagnostic-' + sha(raw) + '.json')
            durable(path, raw, direct(self.root / JOURNAL))
        clean['latestReceipt'] = str(path)
        durable(self.root / JOURNAL, encode(clean), direct(self.root / JOURNAL))

    def prepare_transition(self, direction):
        raw, a, config, launcher = self.check_controls()
        paths, data, values, pending = self.snapshot(config)
        if pending.exists():
            self.save(publication_hold={'pending_file': str(pending), 'pending_sha256': file_sha(pending),
                                        'native_authority_sha256': sha(raw[self.control_names[0]]),
                                        'publisher_config_sha256': sha(raw[self.control_names[1]])})
        require(not pending.exists(), 'pending signed publication retains original authority')
        if direction == 'activate':
            require(self.now() < self.s['admission_deadline'], 'boundary admission deadline passed')
            require(values['journal'] is None and values['checkpoint'] == values['current']['candidate']['state'], 'await completed durable boundary')
            require(a['binary']['sha256'] == self.b['baseline']['sha256'], 'baseline binding changed')
            prefix = []
        else:
            self.recover_orphan(values, sha(raw[self.control_names[0]]))
            paths, data, values, pending = self.snapshot(config)
            prefix = self.prefix(values, sha(raw[self.control_names[0]]))
        self.backend.guard()
        target = self.b['diagnostic'] if direction == 'activate' else self.b['baseline']
        require(file_sha(target['path']) == target['sha256'], 'retained executable drift')
        na, nc, nl = copy.deepcopy(a), copy.deepcopy(config), copy.deepcopy(launcher)
        require(na['command'][0] == na['binary']['path'], 'native command mismatch')
        require(na['filePins'].pop(na['binary']['path']) == na['binary']['sha256'], 'native file pin mismatch')
        na['binary'].update({k: target[k] for k in ('path', 'sha256', 'sourceCommit', 'buildArtifactPath')})
        na['command'][0] = target['path']
        na['filePins'][target['path']] = target['sha256']
        nc['nativeAuthoritySha256'] = sha(encode(na))
        require(nc['protectedFiles'][str(self.root / self.control_names[0])] == sha(raw[self.control_names[0]]), 'protected authority mismatch')
        nc['protectedFiles'][str(self.root / self.control_names[0])] = nc['nativeAuthoritySha256']
        prior = dict(nc.get('priorNativeReceiptFiles', {}))
        for path, receipt in prefix:
            # Hash-bound originals remain protected; no large data reads/copies.
            prior[str(path)] = sha(receipt)
        require(len(prior) <= 64, 'trusted prefix capacity exceeded')
        if prefix:
            nc['priorNativeReceiptFiles'] = prior
        nl['configSha256'] = sha(encode(nc))
        journal = values['journal']
        new_journal = None if journal is None else dict(journal, authoritySha256=nc['nativeAuthoritySha256'])
        originals = dict(raw, **{JOURNAL: data['journal']})
        replacements = dict(zip(self.control_names, map(encode, (na, nc, nl))))
        replacements[JOURNAL] = encode(new_journal)
        plan = {'direction': direction, 'binding_sha256': self.binding_sha,
                'inputs': {paths[k]: sha(data[k]) for k in ('checkpoint', 'current')},
                'pending_path': str(pending), 'files': {name: {'old': base64.b64encode(originals[name]).decode(),
                    'new': base64.b64encode(replacements[name]).decode(), 'metadata': direct(self.root / name)} for name in originals}}
        plan_raw = encode(plan)
        durable(self.home / (direction + '.json'), plan_raw)
        self.save(plans=dict(self.s.get('plans', {}), **{direction: sha(plan_raw)}))
        self.fault(direction + ':prepared')

    def apply_transition(self, direction):
        plan_raw = read(self.home / (direction + '.json'))
        require(self.s.get('plans', {}).get(direction) == sha(plan_raw), 'transition plan binding missing or changed')
        plan = json.loads(plan_raw)
        require(plan['binding_sha256'] == self.binding_sha and plan['direction'] == direction, 'transition plan changed')
        require(set(plan['files']) == set(self.control_names) | {JOURNAL}, 'unexpected mutation paths')
        require(not Path(plan['pending_path']).exists(), 'pending publication appeared; preserve authority')
        require(all(file_sha(p) == h for p, h in plan['inputs'].items()), 'durable frontier changed; preserve')
        for name, row in plan['files'].items():
            require(read(self.root / name) in (base64.b64decode(row['old']), base64.b64decode(row['new'])), 'foreign control edit during transition')
        for name, row in plan['files'].items():
            new = base64.b64decode(row['new'])
            if read(self.root / name) != new:
                durable(self.root / name, new, row['metadata'])
            self.fault(direction + ':' + name)
        self.backend.guard()
        require(all(file_sha(p) == h for p, h in plan['inputs'].items()), 'frontier changed during transition')
        expected = {n: sha(base64.b64decode(plan['files'][n]['new'])) for n in self.control_names}
        self.save(expected_controls=expected, phase='ready' if direction == 'activate' else 'restoring-timer')
        self.fault(direction + ':committed')

    def transition(self, direction):
        # Queued starts are excluded by the installed ExecCondition while the
        # phase is activating/restoring. Never cancel a service job or stop an
        # active service to obtain this boundary.
        require(not self.backend.service()['active'], 'service still owns operation')
        with locked(self.operation):
            require(not self.backend.service()['active'], 'service became active')
            if not (self.home / (direction + '.json')).exists():
                self.prepare_transition(direction)
            self.apply_transition(direction)

    def hold(self, reason):
        self.save(phase='held', reason=reason, held_at=self.now(), timer_healthy=False,
                  recovery_required=True, resume_phase=self.s['phase'])
        return 'held'

    def admission_evidence(self):
        path = self.home / 'service-admission.json'
        if not path.exists():
            return None
        claim = json.loads(read(path))
        require(isinstance(claim, dict) and {'binding_sha256', 'owner', 'controls_sha256', 'invocation_id', 'boot_id'} <= set(claim), 'malformed service admission')
        require(claim['binding_sha256'] == self.binding_sha and claim['owner'] == self.b['recovery_owner']
                and claim['controls_sha256'] == self.expected()
                and re.fullmatch('[0-9a-f]{32}', claim['invocation_id']) is not None, 'foreign/malformed service admission')
        digest = file_sha(path)
        require(self.s.get('admission_sha256', digest) == digest, 'durable admission changed')
        if self.s.get('admission_sha256') != digest:
            self.save(diagnostic_invocation_id=claim['invocation_id'], diagnostic_boot_id=claim['boot_id'], admission_sha256=digest)
        return claim

    def native_result(self, claim):
        if claim is None:
            return 'no-native-admission-observed'
        path = self.root / 'receipts' / ('continue-' + claim['invocation_id'] + '.json')
        if not path.exists():
            return 'service-admitted-native-exit-unconfirmed'
        raw = read(path)
        receipt = json.loads(raw)
        require(receipt.get('format') == 'iris-social/archive-catchup-run@1'
                and receipt.get('invocation') == claim['invocation_id']
                and receipt.get('authoritySha256') == claim['controls_sha256'][self.control_names[0]]
                and type(receipt.get('exitCode')) is int
                and receipt.get('originalAndPoolPinsUnchanged') is True, 'native result does not bind the admitted invocation')
        self.save(native_result={'path': str(path), 'sha256': sha(raw), 'exit_code': receipt['exitCode']})
        return 'native-receipt-observed'

    def step(self, recover=False):
        if self.s is None:
            require(not recover, 'no operation to recover')
            self.start()
        self.backend.maintenance_ready()
        if self.s['phase'] in TERMINAL:
            if recover:
                self.save(finish_phase=self.s['phase'], phase='restoring-timer')
            else:
                self.audit()
                return self.s['phase']
        if self.s['phase'] == 'held':
            if not recover:
                return 'held'
            resume = self.s['resume_phase']
            self.save(phase='restoring-timer' if resume in TERMINAL else resume,
                      finish_phase=resume if resume in TERMINAL else self.s.get('finish_phase', 'restored'), recovery_required=True)
        phase = self.s['phase']
        if phase == 'parking':
            self.backend.park(self.s['original_timer'])
            self.check_controls()
            self.save(phase='boundary')
            phase = 'boundary'
        if phase != 'restoring-timer':
            require(self.backend.timer() == {'active': False, 'enabled': 'disabled'}, 'timer park/enablement mismatch')
        if phase == 'boundary':
            if recover or self.now() >= self.s['admission_deadline']:
                self.check_controls()
                self.save(phase='restoring-timer', finish_phase='aborted',
                          reason='no activation before admission deadline or recovery-only request')
                phase = 'restoring-timer'
            elif self.backend.service()['busy']:
                return 'waiting'
            else:
                with locked(self.operation):
                    _, _, config, _ = self.check_controls()
                    _, _, values, pending = self.snapshot(config)
                    if pending.exists() or values['journal'] is not None or values['checkpoint'] != values['current']['candidate']['state']:
                        return 'waiting'
                self.save(phase='activating')
                phase = 'activating'
        if phase == 'activating':
            self.transition('activate')
            phase = 'ready'
        if phase == 'ready':
            if recover or self.now() >= self.s['supervision_deadline']:
                self.save(phase='restoring')
                phase = 'restoring'
            else:
                require(not self.backend.service()['busy'], 'unexpected service before launch')
                with locked(self.operation):
                    self.check_controls()
                    self.backend.guard()
                    require(not self.s['launch_consumed'], 'launch allowance already consumed')
                    self.save(phase='launch-uncertain', launch_consumed=True,
                              before_invocation=self.backend.service()['invocation'], launch_requested_at=self.now())
                self.fault('launch:consumed')
                self.backend.launch()
                self.fault('launch:returned')
                self.save(phase='running')
                return 'waiting'
        if phase == 'launch-uncertain':
            status = self.backend.service()
            claim = self.admission_evidence()
            if status['active'] or claim:
                self.save(phase='running')
                phase = 'running'
            elif recover:
                # The verified persistent guard makes delayed/queued requests
                # harmless: disarm before changing any controls. This records
                # no observed native admission, never an inferred completion.
                self.save(phase='restoring', launch_revoked=True, observation='no-native-admission-observed')
                phase = 'restoring'
            else:
                return self.hold('launch outcome uncertain; owner must settle queued start before restoration; never relaunch')
        if phase == 'running':
            status = self.backend.service()
            claim = self.admission_evidence()
            if status['active'] or (status['queued'] and not recover):
                if self.now() >= self.s['supervision_deadline']:
                    return self.hold('supervision deadline; active service untouched, future timer parked')
                return 'waiting'
            if not claim and not recover:
                return self.hold('service ended without durable diagnostic admission; skipped/uncertain, not a completed native run')
            self.save(phase='restoring', launch_revoked=True,
                      observation=self.native_result(claim))
            phase = 'restoring'
        if phase == 'restoring':
            self.transition('restore')
            phase = 'restoring-timer'
        if phase == 'restoring-timer':
            self.audit(restoring=True)
            self.save(restored_boot_id=self.backend.boot_id())
            self.backend.restore_timer(self.s['original_timer'])
            finish = self.s.get('finish_phase', 'restored')
            self.save(phase=finish, timer_healthy=True, recovery_required=False, restored_at=self.now())
            self.audit()
            return finish
        raise Hold('unknown controller phase')

    def audit(self, restoring=False):
        _, authority, _, _ = self.check_controls()
        require(authority['binary']['sha256'] == self.b['baseline']['sha256'], 'baseline not restored')
        self.backend.guard()
        if restoring:
            require(self.s.get('finish_phase') == 'aborted' or not self.backend.service()['active'], 'service active before restoration complete')
        else:
            require(self.backend.timer() == self.s['original_timer'], 'original timer not restored')

    def replay_publication(self, seconds, publish=None):
        """Explicit same-owner recovery; never start the guarded service/native.

        Reuse current continuation's exact pending/terminal-receipt branch and
        the existing publisher bundle. Both native callbacks reject. A timeout
        preserves the original authority and signed transaction for that owner.
        """
        require(self.s is not None and self.s['phase'] == 'held', 'publication replay requires a held owner operation')
        self.backend.maintenance_ready()
        require(not self.backend.service()['active'], 'existing service still active')
        with locked(self.operation):
            _, authority, config, launcher = self.check_controls()
            self.backend.guard()
            _, _, values, pending = self.snapshot(config)
            require(pending.exists() or values['checkpoint'] != values['current']['candidate']['state'], 'no pending/unpublished transaction to replay')
            def no_native(*_):
                raise Hold('publication recovery cannot admit or invoke native work')
            def original_publish(receipt):
                require(file_sha(launcher['bundleFile']) == launcher['bundleSha256'], 'publisher bundle changed')
                with open(os.devnull, 'wb') as sink:
                    result = subprocess.run(['/usr/bin/node', launcher['bundleFile'], '--config', launcher['configFile'],
                        '--receipt', str(receipt), '--operation-lock-held'], stdin=subprocess.DEVNULL,
                        stdout=sink, stderr=sink, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}, timeout=min(seconds, 900))
                require(result.returncode == 0, 'original publisher did not complete; pending transaction retained')
            result = self.continuation.continue_once(self.root / 'receipts', config['checkpointFile'], config['outboxDirectory'],
                config['nativeAuthoritySha256'], authority['recurringMaxAuthors'], no_native, publish or original_publish, no_native)
            self.save(publication_recovery={'result': result, 'at': self.now(), 'native_invoked': False})
            return result


def systemd_payloads(binding, binding_sha):
    """Exact proposed persistent files; rendering does not install anything."""
    p = binding['maintenance']
    command = '/usr/bin/python3 -B ' + binding['implementation_path']
    common = ' --binding ' + p['binding_file'] + ' --sha256 ' + binding_sha
    mounts = list(dict.fromkeys([binding['root'], binding['state_directory'], *binding['recovery_mounts']]))
    boot = ('[Unit]\nDescription=Bounded archive diagnostic recovery\n'
            'Before=' + binding['service'] + '\nRequiresMountsFor=' + ' '.join(mounts) + '\n'
            '[Service]\nType=oneshot\nRemainAfterExit=yes\nRestart=no\nNoNewPrivileges=yes\nUMask=0077\n'
            'ExecStart=' + command + ' boot-recover' + common + ' --seconds=300\n'
            'TimeoutStartSec=480\nTimeoutStopSec=20\n[Install]\nWantedBy=multi-user.target\n')
    gate = ('[Unit]\nRequires=' + p['boot_unit'] + '\nAfter=' + p['boot_unit'] + '\n'
            '[Service]\nExecCondition=!' + command + ' admit' + common + '\n')
    return {p['boot_unit_path']: boot, p['service_dropin']: gate}


def service_admission(binding, binding_sha, invocation, boot_id=None, fault=lambda _: None, now=None):
    """ExecCondition: atomically admit at most one diagnostic service attempt.

    Separate lock/file from the supervisor: systemd must not wait on the lock
    held by its own caller. The shared operation lock excludes control writes.
    Queued/manual starts all pass through this same condition. A consumed claim
    is never retried, including a crash between this guard and native ExecStart.
    """
    clock = time.time if now is None else now
    home = Path(binding['state_directory'])
    with locked(home / 'admission.lock', create=True), locked(Path(binding['root']) / 'receipts/operation.lock'):
        boot_id = boot_id or read('/proc/sys/kernel/random/boot_id').decode().strip()
        def reject(reason):
            durable(home / 'last-admission-rejection.json', encode({'binding_sha256': binding_sha,
                'owner': binding['recovery_owner'], 'invocation_id': invocation, 'boot_id': boot_id,
                'reason': reason, 'native_started': False, 'rejected_at': clock()}))
            return False
        state = read_state(home / 'state.json', binding_sha, binding['recovery_owner'])
        raw = {name: read(Path(binding['root']) / name) for name in control_names(binding)}
        authority, _, _ = publication_controls(binding, raw)
        controls = {k: sha(v) for k, v in raw.items()}
        require(controls == state.get('expected_controls', binding['expected_controls']), 'service controls drift')
        if state['phase'] in (*TERMINAL, 'restoring-timer'):
            return authority['binary']['sha256'] == binding['baseline']['sha256']
        if state['phase'] not in ('launch-uncertain', 'running') or not state['launch_consumed'] or state.get('launch_revoked'):
            return reject('diagnostic admission is not armed; service skipped')
        if state['boot_id'] != boot_id:
            return reject('diagnostic allowance belongs to a prior boot; recovery required')
        require(authority['binary']['sha256'] == binding['diagnostic']['sha256'], 'diagnostic authority mismatch')
        claim = home / 'service-admission.json'
        if claim.exists():
            return reject('diagnostic service admission already consumed; service skipped')
        require(re.fullmatch('[0-9a-f]{32}', invocation or '') is not None, 'systemd invocation identity required')
        # The supervisor can die after consuming its request. Enforce its
        # original finite window at the actual service claim, under the same
        # coordination lock; a delayed queued/manual start cannot renew it.
        deadline = state.get('supervision_deadline')
        require(type(deadline) in (int, float) and math.isfinite(deadline), 'invalid original supervision deadline')
        admitted_at = clock()
        require(type(admitted_at) in (int, float) and math.isfinite(admitted_at), 'invalid admission clock')
        if admitted_at >= deadline:
            return reject('original supervision deadline expired; diagnostic service skipped')
        durable(claim, encode({'binding_sha256': binding_sha, 'owner': binding['recovery_owner'],
                              'invocation_id': invocation, 'boot_id': boot_id, 'admitted_at': admitted_at, 'controls_sha256': controls}))
        fault('service-admission:durable')
        return True


def validate_binding(binding, raw, expected_sha, verify_artifacts=True):
    require(sha(raw) == expected_sha and binding['format'] == 'iris-social/diagnostic-binding@1', 'binding mismatch')
    require(re.fullmatch('[a-z0-9-]{1,64}', binding['operation_id']) is not None, 'operation ID invalid')
    require(isinstance(binding['recovery_owner'], str) and bool(binding['recovery_owner']), 'one recovery owner required')
    require(1 <= binding['admission_seconds'] <= 21600 and 1 <= binding['supervision_seconds'] <= 86400, 'time bound invalid')
    require(1 <= binding['poll_seconds'] <= 30, 'poll bound invalid')
    for name in ('root', 'state_directory'):
        p = Path(binding[name])
        require(p.is_absolute() and p.is_dir() and all(not x.is_symlink() for x in (p, *p.parents)), 'private direct directory required')
    require(set(binding['expected_controls']) == set(control_names(binding)), 'control set mismatch')
    require(all(re.fullmatch('[a-f0-9]{64}', digest) for digest in binding['expected_controls'].values()), 'control digest invalid')
    bundle = binding['publisher_bundle']
    require(set(bundle) == {'path', 'sha256'} and Path(bundle['path']).is_absolute()
            and '..' not in Path(bundle['path']).parts and Path(bundle['path']).is_relative_to(binding['root'])
            and re.fullmatch('[a-f0-9]{64}', bundle['sha256']) is not None, 'publisher bundle binding invalid')
    require(binding['pinned_files'].get(bundle['path']) == bundle['sha256'], 'publisher bundle must be pinned')
    for name in ('service', 'timer'):
        require(re.fullmatch('[a-zA-Z0-9_.@-]+\.' + name, binding[name]) is not None, 'systemd unit name invalid')
    require(binding['provenance_limit'] == 'compiler-and-resolved-feature-identity-incomplete', 'retained provenance limit required')
    require(bool(binding['pinned_files']), 'reviewed implementation/evidence pins required')
    for path, digest in binding['pinned_files'].items():
        require(file_sha(path) == digest, 'pinned input changed')
    require(str(Path(__file__).resolve()) in binding['pinned_files'], 'controller source must be pinned')
    require(binding['continuation']['path'] in binding['pinned_files'], 'continuation source must be pinned')
    require(len(binding['protection_command']) >= 1 and binding['protection_command'][0].startswith('/'), 'absolute protection command required')
    require(binding['implementation_path'] == str(Path(__file__).resolve()), 'installed implementation path mismatch')
    maintenance = binding['maintenance']
    require(set(binding['unit_settings']) == {binding['service'], binding['timer']}, 'unit settings required')
    require(re.fullmatch('[a-zA-Z0-9_-]+\.service', maintenance['boot_unit']) is not None, 'boot recovery name invalid')
    for path in [binding['root'], binding['state_directory'], binding['implementation_path'], *maintenance.values(), *binding['recovery_mounts']]:
        require(not any(c.isspace() or c in '%$\\;"' for c in path), 'systemd payload escaping requires simple pinned paths')
    for settings in binding['unit_settings'].values():
        require(all(p in binding['pinned_files'] for p in [settings['fragment'], *settings['dropins']]), 'unit source files must be pinned')
    # Reject a review binding that would create an ordering cycle among these
    # three units. The new recovery unit never requires the guarded service.
    nodes = {binding['service'], binding['timer'], maintenance['boot_unit']}
    edges = {n: set() for n in nodes}
    edges[maintenance['boot_unit']].add(binding['service'])
    for unit, settings in binding['unit_settings'].items():
        edges[unit].update(set(settings.get('before', [])) & nodes)
        for predecessor in set(settings.get('after', [])) & nodes:
            edges[predecessor].add(unit)
    def visit(node, ancestors):
        require(node not in ancestors, 'recovery/service ordering cycle')
        for successor in edges[node]:
            visit(successor, ancestors | {node})
    for node in nodes:
        visit(node, set())
    for target in ('baseline', 'diagnostic'):
        item = binding[target]
        if verify_artifacts:
            require(file_sha(item['path']) == item['sha256'] and file_sha(item['buildArtifactPath']) == item['sha256'], 'sealed ELF changed')
        require(re.fullmatch('[0-9a-f]{40}', item['sourceCommit']) is not None, 'source commit missing')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'render-systemd', 'init', 'run', 'recover', 'boot-recover', 'admit', 'audit', 'replay-publication'))
    parser.add_argument('--binding', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--seconds', type=int, default=300, help='bounded active supervision per invocation')
    args = parser.parse_args()
    require(1 <= args.seconds <= 86400, 'supervision bound invalid')
    raw = read(args.binding)
    binding = json.loads(raw)
    validate_binding(binding, raw, args.sha256, verify_artifacts=args.mode != 'admit')
    if args.mode == 'render-systemd':
        print(json.dumps(systemd_payloads(binding, args.sha256)))
        return 0
    if args.mode == 'validate':
        print(json.dumps({'valid': True, 'provenance_limit': binding['provenance_limit']}))
        return 0
    require(sys.platform == 'linux' and os.geteuid() == 0, 'production adapter requires Linux owner execution')
    binding['_binding_sha'] = args.sha256
    binding['_mode'] = args.mode
    if args.mode == 'admit':
        # ExecCondition status1 skips this start; never execute a substitute
        # native command or change publication behavior here.
        try:
            return 0 if service_admission(binding, args.sha256, os.environ.get('INVOCATION_ID')) else 1
        except (Hold, OSError, ValueError):
            print(json.dumps({'service_skipped': True, 'native_started': False, 'owner': binding['recovery_owner']}))
            return 1
    if args.mode == 'boot-recover':
        # No write/lock is needed to arm the same-boot recovery oneshot before
        # the maintenance run. Avoid an After=/supervisor-lock dependency cycle.
        probe = Controller(binding, args.sha256, Systemd(binding))
        require(probe.s is not None, 'boot recovery requires initialized durable ownership')
        same_boot = probe.s['boot_id'] == probe.backend.boot_id() and probe.s['phase'] != 'held'
        restored_here = probe.s.get('restored_boot_id') == probe.backend.boot_id() and probe.s['phase'] in (*TERMINAL, 'restoring-timer')
        if same_boot or restored_here:
            probe.backend.maintenance_ready()
            print(json.dumps({'same_boot': True, 'no_new_admission': True}))
            return 0
    with locked(Path(binding['state_directory']) / 'supervisor.lock', create=True):
        controller = Controller(binding, args.sha256, Systemd(binding))
        if args.mode == 'replay-publication':
            result = controller.replay_publication(args.seconds)
            print(json.dumps({'publication_recovered': True, 'native_invoked': False, 'result': result,
                              'restoration_pending': True, 'owner': binding['recovery_owner']}))
            return 0
        if args.mode == 'init':
            controller.start()
            print(json.dumps({'initialized': True, 'owner': binding['recovery_owner'], 'no_activation': True}))
            return 0
        require(controller.s is not None, 'init durable ownership before installing/arming temporary units')
        if args.mode == 'audit':
            require(controller.s is not None and controller.s['phase'] in TERMINAL, 'restoration not complete')
            controller.audit()
            print(json.dumps({'verified': True, 'phase': controller.s['phase']}))
            return 0
        deadline = time.monotonic() + args.seconds
        while True:
            try:
                result = controller.step(recover=args.mode in ('recover', 'boot-recover'))
            except (Hold, AssertionError, OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                if controller.s is None:
                    raise
                result = controller.hold(str(error))
            if result in (*TERMINAL, 'held'):
                print(json.dumps({'phase': controller.s['phase'], 'reason': controller.s.get('reason'),
                                  'owner': binding['recovery_owner'], 'launch_consumed': controller.s['launch_consumed'],
                                  'timer_healthy': controller.s.get('timer_healthy', False)}))
                return 0 if result in TERMINAL else 75
            if time.monotonic() >= deadline:
                controller.hold('active supervision exhausted; same owner must recover, timer remains parked')
                print(json.dumps({'phase': 'held', 'owner': binding['recovery_owner'], 'timer_healthy': False}))
                return 75
            time.sleep(min(binding['poll_seconds'], max(0, deadline - time.monotonic())))


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Hold, OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'error': str(error), 'healthy': False}))
        sys.exit(75)
