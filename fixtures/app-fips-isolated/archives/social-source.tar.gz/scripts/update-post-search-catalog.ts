import { readFile, stat } from 'node:fs/promises';
import type { Store } from '@hashtree/core';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import type { RawEvent } from '../src/lib/nostr';
import {
  assertPortableFilesystemStore,
  FilePostSearchTailBuilderStateStore,
  FilesystemBlockStore,
  writeJsonAtomic,
} from '../src/server/filesystemBlockStore';
import {
  HashtreeNostrSnapshotReader,
  POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
  PostSearchCatalogTailBuilder,
  PostSearchFullRebuildRequiredError,
} from '../src/server/postSearchCatalogBuilder';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';

const DEFAULT_MAX_TAIL_BYTES = 64 * 1024 * 1024;
const DEFAULT_MAX_TAIL_EVENTS = 10_000;
const TAIL_FILE_OVERHEAD_BYTES = 1024 * 1024;

const HELP = `Append an exact bounded archive batch to an Iris Social v4 post-search catalog.

Required:
  --base-catalog-root <nhash>  Complete authenticated v4 catalog root
  --snapshot-root <nhash>      Immutable target event-index root
  --tail-events-file <path>    Exact accepted batch as JSON array or JSONL
  --state-file <path>          New @1 atomic resumable tail state
  --handoff-file <path>        New @1 unsigned Nostr pointer handoff JSON
  --publisher-id <hex pubkey>  Publisher identity of the base catalog
  --tree-name <name>           Mutable Hashtree tree/ref name

Store (choose exactly one):
  --store-url <http(s) URL>     Production daemon store API
  --offline-store <directory>  Offline/test hashtree-fs CAS; LMDB is rejected

Optional:
  --store-auth-file <path>     Hashtree auth.cookie or credential JSON
  --store-timeout-ms <ms>      Per-request timeout; default 30000
  --max-tail-events <count>    Exact batch cap; default 10000
  --max-tail-bytes <bytes>     Decoded event cap; default 67108864
  --max-event-bytes <bytes>    Per-event cap; default 1048576
  --max-deletion-events <n>    Existing deletion scan cap; default 250000
  --segment-documents <count>  Appended segment cap; default 5000
  --segment-bytes <bytes>      Appended segment byte cap; default 33554432

The tail file must be the exact batch used by NostrEventStore.build to derive
--snapshot-root from the base catalog's source root. The updater replays and
hash-checks that transition before reusing immutable segments. New deletions,
profile changes, or addressable supersession fail closed and require the full
snapshot builder. This command never reads secret keys, pins, or publishes.`;

type CliOptions = {
  baseCatalogRoot: string;
  snapshotRoot: string;
  tailEventsFile: string;
  stateFile: string;
  handoffFile: string;
  publisherId: string;
  treeName: string;
  storeUrl?: string;
  offlineStore?: string;
  storeAuthFile?: string;
  storeTimeoutMs?: number;
  maxTailEvents?: number;
  maxTailBytes?: number;
  maxEventBytes?: number;
  maxDeletionEvents?: number;
  segmentDocuments?: number;
  segmentBytes?: number;
};

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseArguments(process.argv.slice(2));
  const baseCatalogRoot = canonicalRoot(options.baseCatalogRoot, '--base-catalog-root');
  const snapshotRoot = canonicalRoot(options.snapshotRoot, '--snapshot-root');
  const tailEvents = await readTailEvents(
    options.tailEventsFile,
    options.maxTailEvents ?? DEFAULT_MAX_TAIL_EVENTS,
    options.maxTailBytes ?? DEFAULT_MAX_TAIL_BYTES,
  );
  const store = await createStore(options);
  const builder = new PostSearchCatalogTailBuilder({
    baseCatalogRoot,
    targetSnapshotRoot: snapshotRoot,
    tailEvents,
    snapshotReader: new HashtreeNostrSnapshotReader(store),
    outputStore: store,
    stateStore: new FilePostSearchTailBuilderStateStore(options.stateFile),
    publisherId: options.publisherId,
    treeName: options.treeName,
    maxTailEvents: options.maxTailEvents,
    maxTailBytes: options.maxTailBytes,
    maxEventBytes: options.maxEventBytes,
    maxDeletionEvents: options.maxDeletionEvents,
    segmentMaxDocuments: options.segmentDocuments,
    segmentMaxBytes: options.segmentBytes,
    onProgress: (progress) => {
      process.stdout.write(`post-search tail progress ${JSON.stringify(progress)}\n`);
    },
  });
  const result = await builder.build();
  await writeJsonAtomic(options.handoffFile, result.handoff);
  process.stdout.write(`${JSON.stringify({
    catalogRoot: nhashEncode(result.catalogRoot),
    sourceEventRoot: result.handoff.sourceEventRoot,
    appendedDocuments: result.state.processedDocuments,
    appendedSegments: result.state.appendedSegments.length,
    resumed: result.resumed,
    handoffStatus: result.handoff.status,
    tailBuilderStateFormat: POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
  })}\n`);
}

function parseArguments(args: string[]): CliOptions {
  const values = new Map<string, string>();
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid tail updater argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate tail updater argument: ${key}`);
    }
    values.set(key, value);
  }
  const known = new Set([
    '--base-catalog-root', '--snapshot-root', '--tail-events-file', '--state-file',
    '--handoff-file', '--publisher-id', '--tree-name', '--store-url', '--offline-store',
    '--store-auth-file', '--store-timeout-ms', '--max-tail-events', '--max-tail-bytes',
    '--max-event-bytes', '--max-deletion-events', '--segment-documents', '--segment-bytes',
  ]);
  for (const key of values.keys()) {
    if (!known.has(key)) {
      throw new Error(`Unknown tail updater argument: ${key}`);
    }
  }
  const storeUrl = values.get('--store-url');
  const offlineStore = values.get('--offline-store');
  if (Boolean(storeUrl) === Boolean(offlineStore)) {
    throw new Error('Choose exactly one of --store-url or --offline-store');
  }
  const storeAuthFile = values.get('--store-auth-file');
  if (storeAuthFile && !storeUrl) {
    throw new Error('--store-auth-file requires --store-url');
  }
  const storeTimeoutMs = optionalInteger(values, '--store-timeout-ms');
  if (storeTimeoutMs && !storeUrl) {
    throw new Error('--store-timeout-ms requires --store-url');
  }
  return {
    baseCatalogRoot: required(values, '--base-catalog-root'),
    snapshotRoot: required(values, '--snapshot-root'),
    tailEventsFile: required(values, '--tail-events-file'),
    stateFile: required(values, '--state-file'),
    handoffFile: required(values, '--handoff-file'),
    publisherId: required(values, '--publisher-id'),
    treeName: required(values, '--tree-name'),
    storeUrl,
    offlineStore,
    storeAuthFile,
    storeTimeoutMs,
    maxTailEvents: optionalInteger(values, '--max-tail-events'),
    maxTailBytes: optionalInteger(values, '--max-tail-bytes'),
    maxEventBytes: optionalInteger(values, '--max-event-bytes'),
    maxDeletionEvents: optionalInteger(values, '--max-deletion-events'),
    segmentDocuments: optionalInteger(values, '--segment-documents'),
    segmentBytes: optionalInteger(values, '--segment-bytes'),
  };
}

async function readTailEvents(path: string, maxEvents: number, maxBytes: number): Promise<RawEvent[]> {
  const fileSize = (await stat(path)).size;
  const maxFileBytes = maxBytes + TAIL_FILE_OVERHEAD_BYTES + maxEvents * 2;
  if (!Number.isSafeInteger(fileSize) || fileSize > maxFileBytes) {
    throw new Error('Tail events file exceeds bounded input size');
  }
  const raw = await readFile(path, 'utf8');
  let values: unknown;
  try {
    const trimmed = raw.trim();
    values = trimmed.startsWith('[')
      ? JSON.parse(trimmed)
      : trimmed.split(/\r?\n/u).filter(Boolean).map((line) => JSON.parse(line));
  } catch {
    throw new Error('Tail events file must contain a JSON array or one JSON event per line');
  }
  if (!Array.isArray(values) || values.length > maxEvents) {
    throw new Error('Tail events file exceeds maxTailEvents');
  }
  return values as RawEvent[];
}

async function createStore(options: CliOptions): Promise<Store> {
  if (options.storeUrl) {
    return new HttpBlockStore(options.storeUrl, {
      credentials: await loadStoreCredentials(options.storeAuthFile),
      timeoutMs: options.storeTimeoutMs,
    });
  }
  const directory = options.offlineStore as string;
  await assertPortableFilesystemStore(directory);
  return new FilesystemBlockStore(directory);
}

async function loadStoreCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const environmentUsername = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const environmentPassword = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (environmentUsername !== undefined || environmentPassword !== undefined)) {
    throw new Error('Choose either --store-auth-file or store auth environment variables');
  }
  if (path) {
    try {
      return parseHttpBlockStoreCredentials(await readFile(path, 'utf8'));
    } catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!environmentUsername || !environmentPassword) {
    throw new Error(
      'Daemon store writes require --store-auth-file or both store auth environment variables',
    );
  }
  return { username: environmentUsername, password: environmentPassword };
}

function canonicalRoot(value: string, name: string) {
  const root = nhashDecode(value);
  if (nhashEncode(root) !== value) {
    throw new Error(`${name} must be a canonical nhash`);
  }
  return root;
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key)?.trim();
  if (!value) {
    throw new Error(`Missing required tail updater argument: ${key}`);
  }
  return value;
}

function optionalInteger(values: ReadonlyMap<string, string>, key: string): number | undefined {
  const raw = values.get(key);
  if (raw === undefined) {
    return undefined;
  }
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`${key} must be a positive integer`);
  }
  return value;
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  if (error instanceof PostSearchFullRebuildRequiredError) {
    process.stderr.write(`post-search tail requires full rebuild: ${message}\n`);
    process.exitCode = 2;
    return;
  }
  process.stderr.write(`post-search tail updater failed: ${message}\n`);
  process.exitCode = 1;
});
