import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { verifyPrivateRuntimePins } from './verify-dependency-lock.mjs';

// Run after pnpm install --frozen-lockfile. Runtime target is Node >=22.13 on Linux.
const [output, ...extra] = process.argv.slice(2);
if (!output || extra.length) throw new Error('Use node scripts/build-forward-archive.mjs OUTPUT_DIRECTORY');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const { build, version } = createRequire(require.resolve('vite/package.json'))('esbuild');
const manifest = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
const lockfile = await readFile(join(root, 'pnpm-lock.yaml'), 'utf8');
verifyPrivateRuntimePins(manifest, lockfile);
const directory = resolve(output);
await mkdir(directory, { recursive: true });
const result = await build({
  absWorkingDir: root,
  entryPoints: ['scripts/forward-archive-inbox.ts', 'scripts/publish-archive-checkpoint.ts'],
  bundle: true,
  platform: 'node',
  target: 'node22',
  format: 'esm',
  outExtension: { '.js': '.mjs' },
  outdir: directory,
  metafile: true,
  banner: { js: 'import {createRequire as bundleRequire} from "node:module";const require=bundleRequire(import.meta.url);' },
  define: { 'process.env.WS_NO_BUFFER_UTIL': '"1"', 'process.env.WS_NO_UTF_8_VALIDATE': '"1"' },
});
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const artifacts = [];
for (const [name, info] of Object.entries(result.metafile.outputs)) {
  const file = resolve(root, name);
  artifacts.push({ file, sha256: hash(await readFile(file)), bytes: info.bytes });
}
await writeFile(join(directory, 'build-evidence.json'), JSON.stringify({
  node: process.version, esbuild: version, target: 'node22', lockSha256: hash(lockfile), artifacts,
}, null, 2));
console.log(JSON.stringify(artifacts));
