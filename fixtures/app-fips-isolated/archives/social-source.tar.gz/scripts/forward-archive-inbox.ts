import { readFileSync, lstatSync } from 'node:fs';
import { open, link, unlink, readFile } from 'node:fs/promises';
import { basename, dirname, isAbsolute, join, resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { acquireExclusiveFileLock } from '../src/server/exclusiveFileLock';
import { canonical, digest } from '../src/server/archiveCheckpointOutbox';
import { APP_KINDS } from '../src/server/forwardArchive/events';
import { follow, readGraphWindow, readWindow } from '../src/server/forwardArchive/relay';
import { graphLane, isPrivateMuteWitness, isUnexpired, MAX_GRAPH_AUTHORS_BYTES, parseGraphAuthors } from '../src/server/forwardArchive/graphPolicy';
import { PublishedReplacementReader } from '../src/server/forwardArchive/publishedReplacement';
import { PROFILE_FAST_LANE_KINDS, replacementKey } from '../src/server/forwardArchive/replacement';
import { validateForwardEvidence, type NativeForwardReceipt } from '../src/server/archiveForwardReceipt';
import { ForwardState, InboxCapacityError, configDigest, type Config, type IndexedReplacement } from '../src/server/forwardArchive/state';

const now = () => Math.floor(Date.now() / 1000);

function ownedDirectory(path: string) {
  const stat = lstatSync(path);
  if (!stat.isDirectory() || stat.uid !== process.getuid?.() || stat.mode & 0o077) {
    throw new Error('Forward inbox needs an owned private directory');
  }
}

function readConfig(path: string): Config {
  const stat = lstatSync(path);
  if (!stat.isFile() || stat.size > 8192) {
    throw new Error('Invalid forward inbox config');
  }
  const config = JSON.parse(readFileSync(path, 'utf8')) as Omit<Config, 'graph'> & {
    graph?: { authorsFile: string; sha256: string };
  };
  const keys = config.graph === undefined ? ['since', 'sources']
    : config.retention === undefined ? ['graph', 'since', 'sources'] : ['graph', 'retention', 'since', 'sources'];
  if (
    canonical(Object.keys(config).sort()) !== canonical(keys) ||
    !Number.isSafeInteger(config.since) ||
    config.since <= 0 ||
    config.since > now() ||
    !Array.isArray(config.sources) ||
    config.sources.length < 1 ||
    config.sources.length > 4 ||
    new Set(config.sources).size !== config.sources.length
  ) {
    throw new Error('Invalid forward inbox config');
  }
  for (const raw of config.sources) {
    const url = new URL(raw);
    if (url.protocol !== 'wss:' || url.username || url.password || url.search || url.hash) {
      throw new Error('Invalid forward source URL');
    }
  }
  const { graph, ...base } = config;
  if (graph === undefined) {return base;}
  const retention = config.retention;
  if (retention !== undefined) {
    if (!retention || canonical(Object.keys(retention).sort()) !== canonical(['publicationFile', 'publisher', 'readEndpoint', 'treeName'])
      || typeof retention.publicationFile !== 'string' || !isAbsolute(retention.publicationFile)
      || typeof retention.publisher !== 'string' || !/^[a-f0-9]{64}$/.test(retention.publisher)
      || typeof retention.treeName !== 'string' || !retention.treeName || typeof retention.readEndpoint !== 'string') {
      throw new Error('Invalid archived replacement authority');
    }
    const url = new URL(retention.readEndpoint);
    if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
      throw new Error('Existing archive slot requires a public HTTPS block endpoint');
    }
  }
  if (!graph || canonical(Object.keys(graph).sort()) !== canonical(['authorsFile', 'sha256'])
    || typeof graph.authorsFile !== 'string' || !isAbsolute(graph.authorsFile)
    || typeof graph.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(graph.sha256)) {
    throw new Error('Invalid forward graph config');
  }
  const authorsStat = lstatSync(graph.authorsFile);
  if (!authorsStat.isFile() || authorsStat.size > MAX_GRAPH_AUTHORS_BYTES) {
    throw new Error('Invalid forward graph author file');
  }
  const bytes = readFileSync(graph.authorsFile);
  if (digest(bytes) !== graph.sha256) {throw new Error('Forward graph author digest differs');}
  return { ...base, graph: { sha256: graph.sha256, authors: parseGraphAuthors(bytes) } };
}

/** Atomic, immutable input for the sole archive writer, committed to exact bytes. */
export async function exportBatch(state: ForwardState, directory: string) {
  ownedDirectory(directory);
  const pending = state.prepare();
  if (!pending) {
    return { empty: true };
  }
  const bytes = Buffer.from(canonical(pending.batch));
  const destination = join(directory, pending.sha256 + '.json');
  const temporary = join(directory, '.' + randomUUID() + '.tmp');
  const file = await open(temporary, 'wx', 0o600);
  try {
    try {
      await file.writeFile(bytes);
      await file.sync();
    } finally {
      await file.close();
    }
    try {
      await link(temporary, destination);
    } catch (error) {
      if (
        (error as NodeJS.ErrnoException).code !== 'EEXIST' ||
        !lstatSync(destination).isFile() ||
        !(await readFile(destination)).equals(bytes)
      ) {
        throw new Error('Forward export path contains different bytes');
      }
    }
  } finally {
    await unlink(temporary);
  }
  const dir = await open(directory, 'r');
  try {
    await dir.sync();
  } finally {
    await dir.close();
  }
  return { sha256: pending.sha256, file: destination, count: pending.batch.events.length };
}

// A coverage worker already pauses between requests. During that pause, a
// completed page can have first use of space released by the archive writer.
// Each worker holds just its current response and releases it on its next turn.
export class ReadyReplay {
  private readonly waiting = new Map<() => void, string | undefined>();

  constructor(private readonly state: ForwardState) {}

  private lastAck() {
    return this.state.get<{ batchSha256: string }>('acknowledged')?.batchSha256;
  }

  beforeIntake() {
    if (!this.waiting.size) {return;}
    const acknowledged = this.lastAck();
    for (const [attempt, previous] of this.waiting) {
      if (previous !== acknowledged) {
        this.waiting.delete(attempt);
        attempt();
      }
    }
  }

  record(attempt: () => void): (() => void) | undefined {
    this.beforeIntake();
    const previous = this.lastAck();
    try {
      attempt();
    } catch (error) {
      if (!(error instanceof InboxCapacityError)) {throw error;}
      let failure: unknown = error;
      const retry = () => {
        try {attempt(); failure = undefined;} catch (cause) {failure = cause;}
      };
      this.waiting.set(retry, previous);
      return () => {
        try {this.beforeIntake();} finally {this.waiting.delete(retry);}
        if (failure) {throw failure;}
      };
    }
  }
}

export async function collect(state: ForwardState, signal: AbortSignal) {
  const pause = (ms: number) => delay(ms, undefined, { signal }).catch(() => {});
  const ready = new ReadyReplay(state);
  const archive = state.config.retention && new PublishedReplacementReader(state.config.retention, signal);
  const indexed = async (event: Parameters<ForwardState['enqueue']>[0]) => {
    const graph = state.config.graph;
    if (!archive || !graph) {return;}
    const coordinate = replacementKey(event);
    if (!coordinate || state.queuedReplacement(coordinate) || !isUnexpired(event, now())) {return;}
    if (!graphLane(event, graph.authors) && !(graph.authors.has(event.pubkey) && isPrivateMuteWitness(event))) {return;}
    return archive.get(event);
  };
  const ingest = (relay: string, events: Parameters<ForwardState['ingest']>[1]) => {
    ready.beforeIntake();
    state.ingest(relay, events);
  };
  const ingestSample = (relay: string, events: Parameters<ForwardState['ingest']>[1]) => {
    for (const event of events) {
      try {ingest(relay, [event]);} catch (error) {
        if (!(error instanceof InboxCapacityError)) {throw error;}
      }
    }
  };
  const ingestGraphSample = async (relay: string, events: Parameters<ForwardState['ingest']>[1]) => {
    const graph = state.config.graph!;
    if (!archive) {ingestSample(relay, events); return;}
    for (const event of events) {
      if (signal.aborted) {return;}
      const lane = graphLane(event, graph.authors);
      if ((!lane && !(graph.authors.has(event.pubkey) && isPrivateMuteWitness(event))) || !isUnexpired(event, now())) {continue;}
      try {
        const previous = replacementKey(event) ? await indexed(event) : undefined;
        if (!signal.aborted) {
          ready.beforeIntake();
          state.ingest(relay, [event], previous && new Map([[event.id, previous]]));
        }
      } catch (error) {
        if (!(error instanceof InboxCapacityError)) {throw error;}
      }
    }
  };
  const loop = async (name: string, interval: number, work: () => Promise<void | (() => void)>) => {
    while (!signal.aborted) {
      try {
        let finish;
        try {finish = await work();} finally {await pause(interval);}
        finish?.();
      } catch (error) {
        console.error(name, error instanceof Error ? error.message.slice(0, 160) : 'failed');
      }
    }
  };
  await Promise.all(
    state.config.sources.flatMap((relay) => {
      let position = 0,
        overlapPosition = 0;
      const live = state.config.graph ? ingestSample : ingest;
      const polls = state.config.retention ? [true, false, 'metadata'] as const : [true, false] as const;
      const graphPolls = state.config.graph ? polls.map(mode =>
        loop(mode === 'metadata' ? 'graph metadata' : mode ? 'graph text' : 'graph public', mode === true ? 1200 : 2400, async () => {
          const authors = state.graphAuthors(relay, mode, mode === 'metadata' ? 16 : 32);
          const until = now();
          const since = mode === 'metadata' ? 0 : Math.max(state.config.since, until - 86400);
          const kinds = mode === 'metadata' ? PROFILE_FAST_LANE_KINDS : mode ? [1] : undefined;
          const page = await readGraphWindow(relay, { authors, kinds, since, until });
          if (signal.aborted) {return;}
          await ingestGraphSample(relay, page.events);
        })) : [];
      return [
        ...graphPolls,
        loop('live', 2500, async () => {
          let proofs = Promise.resolve(), pending = 0;
          await follow(relay, state.config.since, (event) => {
            if (!archive || !replacementKey(event)) {live(relay, [event]); return;}
            // The overlap pass recovers events beyond the bounded live queue.
            if (pending >= 8) {return;}
            pending++;
            proofs = proofs.then(() => ingestGraphSample(relay, [event]))
              .catch(() => console.error('Live archive replacement lookup failed'))
              .finally(() => {pending--;});
          }, signal);
          await proofs;
        }),
        loop('coverage', 400, async () => {
          const kind = APP_KINDS[position++ % APP_KINDS.length],
            window = state.window(relay, kind, now());
          if (window) {
            const page = await readWindow(relay, window);
            const previous = new Map<string, IndexedReplacement>();
            if (archive) {
              for (const event of page.events) {
                const match = await indexed(event);
                if (match) {previous.set(event.id, match);}
              }
            }
            if (!signal.aborted) {return ready.record(() => state.record(relay, window, page, previous));}
          }
        }),
        loop('overlap', 6000, async () => {
          const until = now(),
            since = Math.max(state.config.since, until - 600);
          const page = await readWindow(relay, {
            kind: APP_KINDS[overlapPosition++ % APP_KINDS.length],
            since,
            until,
          });
          if (archive) {await ingestGraphSample(relay, page.events);}
          else {ingest(relay, page.events);}
        }),
        loop('deletion replay', 400, async () => {
          const window = state.deletionWindow(relay, now());
          if (window) {
            const page = await readWindow(relay, window);
            return ready.record(() => state.recordDeletion(relay, window, page));
          }
        }),
      ];
    }),
  );
}

async function main() {
  const [mode, configFile, rawState, directory, ...extra] = process.argv.slice(2);
  if (
    !['init', 'migrate', 'run', 'status', 'export', 'ack'].includes(mode) ||
    !configFile ||
    !rawState ||
    (['export', 'ack', 'migrate'].includes(mode) ? !directory : !!directory) ||
    extra.length
  ) {
    throw new Error(
      'Use init|run|status CONFIG STATE, migrate CONFIG NEW_STATE LEGACY_STATE, export CONFIG STATE PRIVATE_OUTPUT_DIRECTORY, or ack CONFIG STATE NATIVE_RECEIPT',
    );
  }
  const config = readConfig(configFile),
    stateFile = resolve(rawState);
  ownedDirectory(dirname(stateFile));
  if (basename(stateFile) !== 'archive-forward-inbox.sqlite') {
    throw new Error('Use the dedicated archive-forward-inbox.sqlite');
  }
  if (mode === 'migrate') {
    const legacy = resolve(directory);
    ownedDirectory(dirname(legacy));
    if (legacy === stateFile || basename(legacy) !== basename(stateFile) || !lstatSync(legacy).isFile()) {
      throw new Error('Migration needs a separate regular legacy inbox');
    }
    const legacyLock = await acquireExclusiveFileLock(legacy, 'forward-inbox');
    try {
      const stateLock = await acquireExclusiveFileLock(stateFile, 'forward-inbox');
      try {
        console.log(JSON.stringify({ queued: ForwardState.migrateLegacy(stateFile, config, legacy),
          authority: configDigest(config) }));
      } finally {await stateLock.release();}
    } finally {await legacyLock.release();}
    return;
  }
  if (mode !== 'init' && !lstatSync(stateFile).isFile()) {
    throw new Error('Expected a regular inbox database');
  }
  // SQLite serializes short export transactions with the one long-running collector.
  const lock =
    mode === 'init' || mode === 'run' ? await acquireExclusiveFileLock(stateFile, 'forward-inbox') : null;
  let state: ForwardState | undefined;
  try {
    state = new ForwardState(stateFile, config, mode === 'init', mode === 'status');
    if (mode === 'ack') {
      const stat = lstatSync(directory);
      if (!stat.isFile() || stat.size > 128 * 1024) {
        throw new Error('Invalid native forward receipt file');
      }
      const bytes = readFileSync(directory),
        receipt: NativeForwardReceipt = JSON.parse(bytes.toString());
      const acknowledged=state.get<{batchSha256:string;nativeReceiptSha256:string;root:string}>('acknowledged');
      if(acknowledged?.batchSha256===receipt.batchSha256 && acknowledged.nativeReceiptSha256===digest(bytes)) {
        console.log(JSON.stringify({acknowledged:receipt.batchSha256,root:acknowledged.root}));
        return;
      }
      const pending = state.prepare();
      if (!pending) {
        throw new Error('No forward batch is pending');
      }
      validateForwardEvidence(
        { batch: pending.batch, receipt },
        { configSha256: configDigest(config), since: config.since, graphAuthorsSha256: config.graph?.sha256,
          retention: !!config.retention },
        now(),
      );
      state.acknowledge(receipt.batchSha256, digest(bytes), receipt.after.root);
      console.log(JSON.stringify({ acknowledged: receipt.batchSha256, root: receipt.after.root }));
      return;
    }
    if (mode === 'export') {
      console.log(JSON.stringify(await exportBatch(state, directory)));
      return;
    }
    if (mode !== 'run') {
      console.log(JSON.stringify(state.status()));
      return;
    }
    const stop = new AbortController(),
      shutdown = () => stop.abort();
    process.once('SIGTERM', shutdown);
    process.once('SIGINT', shutdown);
    try {
      await collect(state, stop.signal);
    } finally {
      process.removeListener('SIGTERM', shutdown);
      process.removeListener('SIGINT', shutdown);
    }
  } finally {
    state?.db.close();
    await lock?.release();
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : 'Forward inbox failed');
    process.exitCode = 1;
  });
}
