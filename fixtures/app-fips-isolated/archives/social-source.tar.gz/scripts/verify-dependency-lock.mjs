import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

const searchAssets = {
  'search-tag-head.json': '7abebd58ec9bf8b94322a362236ee0a983cf0dae1cf590efcea60c98777a8442',
  'search-minilm-gpu.onnx': '92c024a385492196a88dd8043617176929952ece58f763683c3eeec7902856d4',
  'search-minilm-q8.onnx': 'b190f50dd46296b9895ae8f274c3455762d08610f8788f4a9bd15019f4f7160c',
  'search-tokenizer.json': '2fc687b11de0bc1b3d8348f92e3b49ef1089a621506c7661fbf3248fcd54947e',
  'tokenizer_config.json': '9261e7d79b44c8195c1cada2b453e55b00aeb81e907a6664974b4d7776172ab3',
  'search-keywords.bin': '445e2f19b506873911325f594bb620dd156ac0c7ced05e1dbfba34a7814ed866',
};

const releases = {
  '@iris/profile-events': {
    url: 'https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.15/iris-profile-events-0.2.0.tgz',
    integrity: 'sha512-B6groCtJFzoSCQ66ovQhDkAHcSWtN/JBNyojYmxUOGm6wgi3p1oLZ5btbGby/qzMsBFLOh9uIJ4kJBVVuxHKeQ==',
    version: '0.2.0',
  },
  '@iris/svelte-ui': {
    url: 'https://github.com/mmalmi/iris-kit/releases/download/runtime-v0.2.18/iris-svelte-ui-0.1.7.tgz',
    integrity: 'sha512-ucMoZ+SyxpOosGQvAUXuPbhkXhjHjQhPr5qOh85MjdALFITAicYXKT0vN6ZdngINrNQxWjSks42Ek1xcq2ZOUA==',
    version: '0.1.7',
  },
  '@fips/core': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-core-0.0.58.tgz',
    integrity: 'sha512-UW0PHboZgifo806XxYYjNGgPsKYDMA59YQSvFD0j1k5lhAofX1Yfx+kH38mTYWeTNJQKSr7cMaWqM1Ue2pSV8g==',
    version: '0.0.58',
  },
  '@fips/transport-webrtc': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-transport-webrtc-0.0.62.tgz',
    integrity: 'sha512-X4fGxJvosbK62DqW9Zp8mkzMmmH8grVMxKSbtsqgWRCHNIP1nBKQdvmjeYjVG3/KTTVTZXETRQFLSM9ZS2WW7A==',
    version: '0.0.62',
  },
  '@fips/transport-websocket': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.63/fips-transport-websocket-0.0.16.tgz',
    integrity: 'sha512-2KUDBS9/UQ+g+vguCf5hSZBShFGZW9ffXCYXx8jQI9yL9Q8rj8mxd+bnOrv5qAVG8ymbqErI2oVCkyLkpT9cvw==',
    version: '0.0.16',
  },
  'nostr-social-graph': {
    url: 'https://github.com/mmalmi/nostr-social-graph/releases/download/v4.2.5/nostr-social-graph-4.2.5.tgz',
    integrity: 'sha512-SbIf1758zSgdkOWWuxNrHmphzfEn5Y4kbD2LPkBI/sl4CrEifpzfXjNt621YD9FRElk+HTt7+HBk7Ht2HU1iyA==',
    version: '4.2.5',
  },
  '@hashtree/worker': {
    url: 'https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.41/hashtree-worker-0.4.25.tgz',
    integrity: 'sha512-viUPl2JUtrfJENEWZPvaTtT5x73Pvj5EmHn7qjsTP5T01uOg0tDm7xJww3cf6x23LILi6drOh97ss0WWYq/KVA==',
    version: '0.4.25',
  },
  'nostr-pubsub': {
    url: 'https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.42/nostr-pubsub-0.5.42.tgz',
    integrity: 'sha512-kuEV8FVRU3zPtwTgG95JhztEkPBPV4wQ8Jv+pD6EHF/UfKS/3RpsB/q/+yd6ms9CM/obdbh6xNItOUrSvvBusw==',
    version: '0.5.42',
  },
  'nostr-double-ratchet': {
    url: 'https://registry.npmjs.org/nostr-double-ratchet/-/nostr-double-ratchet-0.0.183.tgz',
    integrity: 'sha512-CPvJzniY+nItLVEQpH4jaRnmU7AMkD3kAN5yByXMgmm4MNChAk8X8HY8oJIw1riX/gW3/WKD8c+eUtSgu98DDA==',
    version: '0.0.183',
  },
};

export function verifyPrivateRuntimePins(manifest, lockfile) {
  const packages = lockfile.split('\npackages:\n')[1]?.split('\nsnapshots:')[0] ?? '';
  for (const [name, url] of Object.entries(manifest.dependencies)) {
    if (!name.startsWith('@hashtree/')) continue;
    if (manifest.pnpm?.overrides?.[name] !== url) throw new Error(`${name} override must match its release`);
    const entry = packages.split('\n\n').find(block => block.startsWith(`  '${name}@${url}':\n`));
    if (!entry?.includes(`tarball: ${url}}`) || !/resolution: \{integrity: sha512-[A-Za-z0-9+/]{86}==,/.test(entry)) {
      throw new Error(`${name} needs a SHA-512 integrity pin for its release tarball`);
    }
  }
  for (const [name, release] of Object.entries(releases)) {
    if ((manifest.dependencies?.[name] ?? manifest.devDependencies?.[name]) !== release.url) throw new Error(`${name} must use its verified immutable release`);
    const override = manifest.pnpm?.overrides?.[name];
    if (override !== undefined && override !== release.url && override !== `$${name}`) throw new Error(`${name} override must match its verified release`);
    const registry = new URL(release.url).hostname === 'registry.npmjs.org';
    const ref = `${name}@${registry ? release.version : release.url}`;
    const start = Math.max(packages.indexOf(`  '${ref}':`), packages.indexOf(`  ${ref}:`));
    const end = packages.indexOf('\n\n', start);
    const entry = start < 0 ? '' : packages.slice(start, end < 0 ? undefined : end);
    if (!entry.includes(`integrity: ${release.integrity}`)) throw new Error(`${name} lock integrity must match its verified release`);
    if (!registry && !entry.split('\n').includes(`    version: ${release.version}`)) throw new Error(`${name} lock package version must match its verified release`);
    const entries = packages.split('\n').filter(line => line.startsWith(`  ${name}@`) || line.startsWith(`  '${name}@`));
    if (entries.length !== 1) throw new Error(`${name} must have one verified runtime instance`);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const root = new URL('../', import.meta.url);
  verifyPrivateRuntimePins(JSON.parse(await readFile(new URL('package.json', root), 'utf8')),
    await readFile(new URL('pnpm-lock.yaml', root), 'utf8'));
  for (const [name, expected] of Object.entries(searchAssets)) {
    const bytes = await readFile(new URL(`src/lib/post-search/model/${name}`, root));
    if (createHash('sha256').update(bytes).digest('hex') !== expected) {
      throw new Error(`Search asset integrity mismatch: ${name}`);
    }
  }
  console.log('Verified immutable private runtime releases, overrides, and search assets');
}
