import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

const releases = {
  '@fips/core': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-core-0.0.54.tgz',
    integrity: 'sha512-Ugzc8fdCr634XcExsGRC8oQpC5ZgJdiejt71N8auSlhJxFhf5tZcdR+dlbSYrlvQDh73jvyBkfXVeqQquR/Z6A==',
    version: '0.0.54',
  },
  '@fips/transport-webrtc': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-transport-webrtc-0.0.58.tgz',
    integrity: 'sha512-JLhrH4onQBbMkuJgApyc9ADLUVDegPywVSA9+UnrSI9zkftIKwGD7fKBKigq5pCW3NQkoLG8KxJPiHTLvsswag==',
    version: '0.0.58',
  },
  '@fips/transport-websocket': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.59/fips-transport-websocket-0.0.12.tgz',
    integrity: 'sha512-vblFMNIcC4wWSAHrnnAP39spJZeaUTJpNesWGMzx7AJJqT0yt94j0wSCoujiXsXGLbDXajI6OkrPkgOcQSCNGA==',
    version: '0.0.12',
  },
  'nostr-social-graph': {
    url: 'https://github.com/mmalmi/nostr-social-graph/releases/download/v4.0.4/nostr-social-graph-4.0.4.tgz',
    integrity: 'sha512-7lMB0fYsjIBQwn/03lY8+0gq41rzifG4hmp5iczjrdBZ/FWQQvkkrH2HGtL80lMhkYr5+UqV63DaBdtoaReDtA==',
    version: '4.0.4',
  },
  '@hashtree/worker': {
    url: 'https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.41/hashtree-worker-0.4.25.tgz',
    integrity: 'sha512-viUPl2JUtrfJENEWZPvaTtT5x73Pvj5EmHn7qjsTP5T01uOg0tDm7xJww3cf6x23LILi6drOh97ss0WWYq/KVA==',
    version: '0.4.25',
  },
  'nostr-pubsub': {
    url: 'https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.24/nostr-pubsub-0.5.24.tgz',
    integrity: 'sha512-IYAPHnhLlYpIkUbG0jPCJC3lxXz3In72kqDdmBSpFN0RvP74HpyLhEWBzSP/YA5XRt/1TnqoxeQ2JXL2Q5SYhQ==',
    version: '0.5.24',
  },
  'nostr-double-ratchet': {
    url: 'https://registry.npmjs.org/nostr-double-ratchet/-/nostr-double-ratchet-0.0.183.tgz',
    integrity: 'sha512-CPvJzniY+nItLVEQpH4jaRnmU7AMkD3kAN5yByXMgmm4MNChAk8X8HY8oJIw1riX/gW3/WKD8c+eUtSgu98DDA==',
    version: '0.0.183',
  },
};

export function verifyPrivateRuntimePins(manifest, lockfile) {
  const packages = lockfile.split('\nsnapshots:')[0];
  for (const [name, url] of Object.entries(manifest.dependencies)) {
    if (!name.startsWith('@hashtree/')) continue;
    if (manifest.pnpm?.overrides?.[name] !== url) throw new Error(`${name} override must match its release`);
    const entry = packages.split('\n\n').find(block => block.startsWith(`  '${name}@${url}':\n`));
    if (!entry?.includes(`tarball: ${url}}`) || !/resolution: \{integrity: sha512-[A-Za-z0-9+/]{86}==,/.test(entry)) {
      throw new Error(`${name} needs a SHA-512 integrity pin for its release tarball`);
    }
  }
  for (const [name, release] of Object.entries(releases)) {
    if ((manifest.dependencies?.[name] ?? manifest.devDependencies?.[name]) !== release.url) throw new Error(`${name} must use its verified immutable release`);
    const override = manifest.pnpm?.overrides?.[name];
    if (override !== undefined && override !== release.url && override !== `$${name}`) throw new Error(`${name} override must match its verified release`);
    const registry = new URL(release.url).hostname === 'registry.npmjs.org';
    const ref = `${name}@${registry ? release.version : release.url}`;
    const start = Math.max(packages.indexOf(`  '${ref}':`), packages.indexOf(`  ${ref}:`));
    const end = packages.indexOf('\n\n', start);
    const entry = start < 0 ? '' : packages.slice(start, end < 0 ? undefined : end);
    if (!entry.includes(`integrity: ${release.integrity}`)) throw new Error(`${name} lock integrity must match its verified release`);
    const entries = packages.split('\n').filter(line => line.startsWith(`  ${name}@`) || line.startsWith(`  '${name}@`));
    if (entries.length !== 1) throw new Error(`${name} must have one verified runtime instance`);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const root = new URL('../', import.meta.url);
  verifyPrivateRuntimePins(JSON.parse(await readFile(new URL('package.json', root), 'utf8')),
    await readFile(new URL('pnpm-lock.yaml', root), 'utf8'));
  console.log('Verified immutable private runtime releases and overrides');
}
