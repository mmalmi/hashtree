"""Prepare an additive launcher patch; output must be a new review file."""
import hashlib
from pathlib import Path
import sys

source, destination = map(Path, sys.argv[1:])
text = source.read_text()
start = "    result = continue_once(receipts, state_path, launcher['outboxDirectory'],\n"
old = start + "                           digest(here/'authority.json'), a['recurringMaxAuthors'], invoke_native, publish, admit_native)\n"
assert text.count(old) == 1, "Launcher continuation call differs; review the source"
new = """    def historical():
        return continue_once(receipts, state_path, launcher['outboxDirectory'],
                             digest(here/'authority.json'), a['recurringMaxAuthors'], invoke_native, publish, admit_native)
    if launcher.get('forward'):
        import importlib.util
        forward_config = launcher['forward']
        assert digest(forward_config['moduleFile']) == forward_config['moduleSha256']
        spec = importlib.util.spec_from_file_location('archive_forward_continuation', forward_config['moduleFile'])
        forward_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(forward_module)
        def protect_forward():
            check_pins(); check_units(); check_july_retention()
        commands = forward_module.ForwardCommands(forward_config, a, protect_forward)
        result = forward_module.continue_with_forward(
            receipts, state_path, launcher['outboxDirectory'], digest(here/'authority.json'),
            historical, commands, publish, admit_native)
    else:
        result = historical()
"""
patched = text.replace(old, new)
compile(patched, str(destination), "exec")
with destination.open("x") as output:
    output.write(patched)
print(hashlib.sha256(patched.encode()).hexdigest())
