# One archive diagnostic admission

This controller is a proposed maintenance operation. Source tests do not admit a
production run. The established production owner must review the exact binding,
persistent unit files, available room, and recovery disposition before installing
anything. It does not compile a native executable, change publisher policy, or
provide a performance benchmark.

Use the two retained, hash-bound executables and their historical qualification.
The native diagnostic records at most eight backing Pool batches per process,
not eight authors or a selected slow projection. Its additional stderr is at most
24,144 bytes. An unrecorded or non-slow call is an unmatched observation. Exact
compiler and resolved-feature identity remains incomplete; this controller does
not turn the source comparison into a reproducible-build claim.

## Binding and private staging

The JSON binding format is `iris-social/diagnostic-binding@1`. Keep it private.
`--sha256` is the digest of its exact bytes. Required inputs are:

- `operation_id`, one durable `recovery_owner`, the existing archive `root`, a
  new task-exclusive `state_directory`, and the installed `implementation_path`.
- `baseline` and `diagnostic`, each with `path`, `buildArtifactPath`, `sha256`,
  and full `sourceCommit`. Preserve the baseline executable; never overwrite it.
- Explicit `publisher_config`: the selected root-relative
  `publication/publisher-config.json` or
  `versions/<reviewed-version>/publisher-config.json`. Exact hashes for
  `authority.json`, that selected config, and `publication/launcher.json` in
  `expected_controls`. The launcher must name precisely the bound path; it
  cannot select a different file. Old bindings without this field are refused.
- `publisher_bundle` with the exact absolute `path` and `sha256`, also present
  in `pinned_files`. The launcher and selected config's `protectedFiles` must
  match this independent pin, and the actual bundle bytes are checked during
  control review and service admission.
- The current `continuation` path/hash, existing `protection_command`, and
  `pinned_files` for the controller, continuation, original unit files/drop-ins,
  current protection/launcher scripts and retained qualification evidence.
- The existing `service`, `timer`, and `unit_settings`: fragment, drop-ins, and
  original `before`/`after` relationships for both units. The service must use
  `Restart=no`. Preserve existing mount conditions and ExecCondition entries.
- Exact `timer_links` records (`path`, raw `target`, `uid`, `gid`) and the bounded
  `timer_link_roots` inventory scopes. The initial enabled/active pair is captured
  durably by `init`. Changed, extra or foreign links/settings are refused.
- `maintenance`: unique `boot_unit`, `boot_unit_path`, `boot_enable_link`,
  `service_dropin`, and `binding_file`; `recovery_mounts` containing the storage
  mount paths required by the existing service/protection checks.
- Finite `admission_seconds`, `supervision_seconds`, and `poll_seconds`;
  `provenance_limit: "compiler-and-resolved-feature-identity-incomplete"`.

The source/executable staging directory must be traversable by the original
service account. The separate state directory and binding are root-owned/private.
Do not place the executable beneath a root-only directory that the original
ExecStart user cannot traverse. No data-store copy, eviction or native build is
part of staging. Recheck exact source/artifact pins and target room at admission.

## Proposed install and bounded run

The following commands use owner-supplied absolute paths and the reviewed digest:

```sh
python3 -B "$controller" validate --binding "$binding" --sha256 "$binding_sha"
python3 -B "$controller" render-systemd --binding "$binding" --sha256 "$binding_sha"
python3 -B "$controller" init --binding "$binding" --sha256 "$binding_sha"
```

Rendering returns the exact proposed file paths/text without installing them.
After review, install the recovery unit first and its exact enablement link under
`multi-user.target`, then the additive service drop-in. Never replace an existing
file at those task-exclusive paths. Reload systemd and start the recovery unit
before starting the controller. `init` precedes these installs so interrupted
installation retains the original timer state and named owner. Until installation
is complete and independently verified, `run` cannot pause the timer or activate
the candidate. A same-boot recovery-unit start is a read-only probe; it cannot
race a legitimate controller into restoring its candidate.

The drop-in appends `ExecCondition=!/usr/bin/python3 ... admit`; it does not clear
the condition list or change ExecStart. `!` changes credentials only, preserving
the original unit's capability and filesystem restrictions and NoNewPrivileges.
The guard performs bound file checks and claim writes, with no publisher/native
execution. The separate recovery oneshot runs as root with NoNewPrivileges and
UMask0077. It needs access to the reviewed control files and local systemd manager;
it remains privileged. Its start/stop bounds are480/20 seconds, with300 seconds
of active supervision. Existing service resource limits/mounts are preserved.

Run the controller from the production owner's independent maintenance unit:

```sh
python3 -B "$controller" run --binding "$binding" --sha256 "$binding_sha" --seconds 7200
```

Its outer unit must bound the controller and its protection/control children,
without stopping or placing the normal archive service in that unit's cgroup.
`--seconds` bounds polling; individual protection/systemd calls have finite
timeouts. Include their completion margin in the outer unit timeout. The existing
archive service retains its own timeout and120-second failure ExecStopPost delay.

The timer's exact boot links are temporarily removed and its future firings
stopped. A running archive operation finishes untouched. At a completed durable
boundary, the controller changes only native executable/source bindings and the
required forward control/receipt hashes. The ordinary eight-author endpoint and
1,024-event commit setting remain intact. No relay-health gate is added.

Before requesting a start, the controller commits its single launch allowance.
The service guard then claims at most one actual systemd invocation under the
existing operation lock, binding the boot ID and all three current controls.
Immediately before that durable claim it checks the original finite supervision
deadline. Delayed starts at or after expiry are rejected even if the supervisor
died after consuming its request; restoration and baseline starts remain allowed.
Queued/manual starts use this same guard. A crash after a claim never permits a
second diagnostic attempt. `service-admission.json` identifies the actual admitted
invocation; `last-admission-rejection.json` and exit status1 explicitly identify a
skipped start. Only the matching native receipt proves a native exit. A guard claim
or systemd success alone is not a completed crawl.

## Restoration, failures and reboot

Successful native work is followed by a forward transition to the retained
baseline. Checkpoint, outbox and receipt progress are never copied backward.
Partial failures retain current eight-author continuation and trusted failed-prefix
receipts. Interrupted control writes finish from their hash-bound transaction plan;
foreign changes stop recovery without overwriting them.
Only the explicitly selected publisher config participates in these transitions.
An unselected historical base config remains byte-for-byte unchanged, including
when forward restoration adds failed-prefix receipt pins to the selected config.

The independently enabled boot unit runs `boot-recover`, never `run`. It restores
before activation, after interrupted activation, during/after a diagnostic attempt,
and between baseline/timer restoration. It does not depend on the disabled timer.
The guard prevents queued starts from slipping through a transition. On explicit
recovery, an unobserved launch is durably revoked before restoring controls; late
starts can then run only the baseline. This is not inferred native acceptance.

```sh
python3 -B "$controller" recover --binding "$binding" --sha256 "$binding_sha" --seconds 300
python3 -B "$controller" audit --binding "$binding" --sha256 "$binding_sha"
```

Exit75 / `phase=held` means restoration is incomplete. The state names the same
recovery owner, exact resume phase, admission, and reason. A parked timer is
explicitly unhealthy. Supervision expiry never kills the active native run. A
failed boot recovery unit remains visible to systemd and prevents the guarded
service from bypassing recovery; there is no new general monitor or reboot loop.

If a signed publication is pending, preserve its bytes and original native and
publisher authorities. The state records their hashes. The owner can retry the
existing publisher independently of the guarded service:

```sh
python3 -B "$controller" replay-publication --binding "$binding" --sha256 "$binding_sha" --seconds 900
python3 -B "$controller" recover --binding "$binding" --sha256 "$binding_sha" --seconds 300
```

Replay uses the sealed current continuation's pending/terminal-publication branch
and existing publisher bundle while holding the operation lock. Both native
callbacks reject. Errors/timeouts retain the signed transaction and held state;
no second diagnostic process is allowed. Normal one-relay confirmation policy is
unchanged. Explicit recovery also works when the boot recovery unit has failed.

## Acceptance and retirement

Verify independently: baseline executable hash and controls/protection; retained
latest checkpoint/receipt lineage; actual admitted invocation and native receipt
(or explicit unmatched/unconfirmed result); exact original timer enablement and
active state. After restoration the temporary condition permits ordinary baseline
runs. Public relay observations are separate from restoration acceptance.

The same owner retires only these task-exclusive installed files after acceptance:
verify their generated hashes and the boot link's exact target/ownership, remove
the additive guard, reload systemd, detach/stop the now-unreferenced recovery unit,
then remove its exact enablement link/unit file and reload. Preserve state/plans,
receipt/evidence hashes and source for audit. Do not remove original drop-ins,
timer links, executables, shared data, or another owner's files. Cleanup has not
been performed by the source-only preparation.

Run the synthetic suite with the exact current continuation snapshot:

```sh
python3 -B tests/test_archive_diagnostic_controller.py --continuation "$sealed_continuation" -v
```

These tests exercise real filesystem transactions and the real continuation
functions with synthetic records; systemd/native/publisher side effects are
substituted. Target unit loading, effective `!` execution restrictions and real
power-loss behavior still require the production owner's review/qualification.
