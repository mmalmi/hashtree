import { open, readFile, rename, unlink } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildSocialGraphSnapshotArtifacts } from '../src/server/socialGraphSnapshotArtifacts';

const REPOSITORY_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUTPUTS = {
  snapshot: resolve(REPOSITORY_ROOT, 'public/socialGraph.bin'),
  frontier: resolve(REPOSITORY_ROOT, 'public/socialGraphFrontier.bin'),
  provenance: resolve(REPOSITORY_ROOT, 'public/socialGraphSnapshot.provenance.json'),
  generatedModule: resolve(REPOSITORY_ROOT, 'src/lib/socialGraphSnapshot.generated.ts'),
};

const HELP = `Refresh the compact browser social graph from an exact, censused full snapshot.

Required:
  --source <path|->               Full nostr-social-graph binary snapshot (or stdin)
  --source-sha256 <lower-hex>     Exact SHA-256 supplied by the snapshot producer
  --census-report <path>          iris-social/social-graph-crawl-census@2 report

Alternative for a protected source stream:
  --census-report-base64 <base64> Exact census report bytes supplied as one argument

The source should be produced by htree socialgraph snapshot and censused with
pnpm census:social-graph. This command never downloads a URL, crawls relays,
publishes, or changes a server. It verifies and projects the exact supplied graph,
then installs the snapshot, frontier, provenance, and generated metadata together.`;

type CliOptions = {
  source: string;
  sourceSha256: string;
  censusReport?: string;
  censusReportBase64?: string;
};

export function parseRefreshSocialGraphArguments(args: readonly string[]): CliOptions {
  const values = new Map<string, string>();
  const normalized = args[0] === '--' ? args.slice(1) : [...args];
  const known = new Set([
    '--source',
    '--source-sha256',
    '--census-report',
    '--census-report-base64',
  ]);
  for (let index = 0; index < normalized.length; index += 2) {
    const key = normalized[index];
    const value = normalized[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid social graph refresh argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown social graph refresh argument: ${key}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate social graph refresh argument: ${key}`);
    }
    values.set(key, value);
  }
  const censusReport = values.get('--census-report')?.trim();
  const censusReportBase64 = values.get('--census-report-base64');
  if (Boolean(censusReport) === Boolean(censusReportBase64)) {
    throw new Error('Choose exactly one of --census-report or --census-report-base64');
  }
  return {
    source: required(values, '--source'),
    sourceSha256: required(values, '--source-sha256'),
    censusReport,
    censusReportBase64,
  };
}

async function writeAtomically(path: string, bytes: Uint8Array | string): Promise<void> {
  const temporary = `${path}.tmp-${process.pid}`;
  const handle = await open(temporary, 'wx', 0o644);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } catch (error) {
    await handle.close().catch(() => {});
    await unlink(temporary).catch(() => {});
    throw error;
  }
  await handle.close();
  await rename(temporary, path);
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseRefreshSocialGraphArguments(process.argv.slice(2));
  const [sourceBytes, censusReportBytes] = await Promise.all([
    options.source === '-' ? readStandardInput() : readFile(options.source),
    options.censusReportBase64 !== undefined
      ? Promise.resolve(decodeCanonicalBase64(options.censusReportBase64))
      : readFile(options.censusReport as string),
  ]);
  const artifacts = await buildSocialGraphSnapshotArtifacts(
    sourceBytes,
    censusReportBytes,
    { expectedSourceSha256: options.sourceSha256 },
  );

  // Each rename is atomic. A process interruption can leave a mixed generation,
  // but the prebuild verifier rejects it instead of silently blessing it.
  await writeAtomically(OUTPUTS.snapshot, artifacts.snapshotBytes);
  await writeAtomically(OUTPUTS.frontier, artifacts.frontierBytes);
  await writeAtomically(OUTPUTS.provenance, artifacts.provenanceJson);
  await writeAtomically(OUTPUTS.generatedModule, artifacts.generatedModule);
  process.stdout.write(`${JSON.stringify(artifacts.provenance)}\n`);
}

async function readStandardInput(): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of process.stdin) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

function decodeCanonicalBase64(value: string): Buffer {
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    throw new Error('--census-report-base64 must be canonical base64');
  }
  return Buffer.from(value, 'base64');
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key)?.trim();
  if (!value) {
    throw new Error(`Missing required social graph refresh argument: ${key}`);
  }
  return value;
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Social graph refresh failed: ${message}\n`);
    process.exitCode = 1;
  });
}
