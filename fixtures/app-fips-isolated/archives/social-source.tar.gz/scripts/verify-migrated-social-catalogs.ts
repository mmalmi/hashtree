import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BlossomStore,
  HashTree,
  nhashDecode,
  nhashEncode,
  toHex,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import { BTree, SearchIndex } from '@hashtree/index';
import { NostrEventStore, type StoredNostrEvent } from '@hashtree/nostr';
import { verifyEvent } from 'nostr-tools/pure';

const PROFILE_SEARCH_PREFIX = 'p:';
const DEFAULT_TIMEOUT_MS = 15_000;
const EVENT_SAMPLE_LIMIT = 8;
const PROFILE_SCAN_LIMIT = 128;

const HELP = `Verify the migrated Iris Social catalogs through one read-only Blossom endpoint.

Required:
  --event-root <nhash>            Immutable nostr-event-index root
  --profiles-root <nhash>         Immutable profiles-by-pubkey root
  --profile-search-root <nhash>   Immutable profile-search root
  --blossom-url <http(s) URL>     The only block source to use

Optional:
  --timeout-ms <ms>               Per-block timeout; default 15000

The verifier resolves no mutable refs and performs no writes. It exercises the
event indexes by time, id, author+kind, and tag, then discovers and verifies a
real profile through both profile catalogs.`;

type Options = {
  eventRoot: CID;
  profilesRoot: CID;
  profileSearchRoot: CID;
  blossomUrl: string;
  timeoutMs: number;
};

class StrictReadOnlyStore implements Store {
  readonly hashes = new Set<string>();
  reads = 0;

  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array> {
    this.reads += 1;
    this.hashes.add(toHex(hash));
    const block = await this.source.get(hash);
    if (!block) {
      throw new Error(`Missing or corrupt Hashtree block: ${toHex(hash)}`);
    }
    return block;
  }

  async has(hash: Hash): Promise<boolean> {
    await this.get(hash);
    return true;
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Migrated Social verification is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Migrated Social verification is read-only');
  }
}

function parseRoot(value: string, option: string): CID {
  const root = nhashDecode(value);
  if (nhashEncode(root) !== value) {
    throw new Error(`${option} must be a canonical nhash`);
  }
  return root;
}

function parseUrl(value: string): string {
  const url = new URL(value);
  if (!['http:', 'https:'].includes(url.protocol)
    || url.username
    || url.password
    || url.search
    || url.hash) {
    throw new Error('--blossom-url must be an uncredentialed http(s) base URL');
  }
  return url.toString().replace(/\/+$/, '');
}

function parsePositiveInteger(value: string, option: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${option} must be a positive integer`);
  }
  return parsed;
}

function parseArguments(args: string[]): Options {
  const normalized = args[0] === '--' ? args.slice(1) : args;
  const values = new Map<string, string>();
  const known = new Set([
    '--event-root',
    '--profiles-root',
    '--profile-search-root',
    '--blossom-url',
    '--timeout-ms',
  ]);

  for (let index = 0; index < normalized.length; index += 2) {
    const key = normalized[index];
    const value = normalized[index + 1];
    if (!key || !known.has(key) || !value || value.startsWith('--') || values.has(key)) {
      throw new Error(`Invalid argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    values.set(key, value.trim());
  }

  const required = (key: string): string => {
    const value = values.get(key);
    if (!value) {
      throw new Error(`Missing required argument: ${key}`);
    }
    return value;
  };

  return {
    eventRoot: parseRoot(required('--event-root'), '--event-root'),
    profilesRoot: parseRoot(required('--profiles-root'), '--profiles-root'),
    profileSearchRoot: parseRoot(required('--profile-search-root'), '--profile-search-root'),
    blossomUrl: parseUrl(required('--blossom-url')),
    timeoutMs: values.has('--timeout-ms')
      ? parsePositiveInteger(required('--timeout-ms'), '--timeout-ms')
      : DEFAULT_TIMEOUT_MS,
  };
}

function requireValidEvents(events: StoredNostrEvent[], label: string): void {
  if (events.length === 0) {
    throw new Error(`${label} returned no events`);
  }
  for (const event of events) {
    if (!verifyEvent(event)) {
      throw new Error(`${label} returned invalid event ${event.id}`);
    }
  }
}

function profileQueries(event: StoredNostrEvent): string[] {
  let profile: unknown;
  try {
    profile = JSON.parse(event.content);
  } catch {
    return [];
  }
  if (!profile || typeof profile !== 'object') {
    return [];
  }
  const record = profile as Record<string, unknown>;
  const fields = ['display_name', 'displayName', 'name', 'nip05'];
  const queries = new Set<string>();
  for (const field of fields) {
    const value = record[field];
    if (typeof value !== 'string') {
      continue;
    }
    const cleaned = value.trim().replace(/^@/, '');
    if (cleaned.length >= 3 && cleaned.length <= 80) {
      queries.add(cleaned);
    }
    for (const word of cleaned.split(/[^\p{L}\p{N}_@.-]+/u)) {
      if (word.length >= 3 && word.length <= 40) {
        queries.add(word);
      }
    }
  }
  return [...queries];
}

async function verifyEventCatalog(root: CID, store: Store): Promise<Record<string, unknown>> {
  const events = new NostrEventStore(store);
  const recent = await events.query(root, { kinds: 1 }, {
    limit: EVENT_SAMPLE_LIMIT,
    strict: true,
  });
  requireValidEvents(recent, 'recent kind-1 query');

  const sample = recent[0]!;
  const byId = await events.query(root, { ids: sample.id }, { limit: 1, strict: true });
  requireValidEvents(byId, 'event-id query');
  if (byId[0]?.id !== sample.id) {
    throw new Error('event-id query returned a different event');
  }

  const byAuthorKind = await events.query(root, {
    authors: sample.pubkey,
    kinds: sample.kind,
  }, { limit: EVENT_SAMPLE_LIMIT, strict: true });
  requireValidEvents(byAuthorKind, 'author+kind query');
  if (!byAuthorKind.some((event) => event.id === sample.id)) {
    throw new Error('author+kind query omitted the sampled recent event');
  }

  const taggedSample = recent.find((event) => event.tags.some(
    (tag) => ['a', 'e', 'p', 't'].includes(tag[0] ?? '') && Boolean(tag[1]),
  ));
  if (!taggedSample) {
    throw new Error('recent kind-1 sample contains no event suitable for a strict tag-index query');
  }
  const tag = taggedSample.tags.find(
    (candidate) => ['a', 'e', 'p', 't'].includes(candidate[0] ?? '') && Boolean(candidate[1]),
  )!;
  const byTag = await events.query(root, { tags: { [tag[0]!]: tag[1]! } }, {
    limit: EVENT_SAMPLE_LIMIT,
    strict: true,
  });
  requireValidEvents(byTag, 'tag query');
  if (!byTag.some((event) => event.id === taggedSample.id)) {
    throw new Error('tag query omitted the sampled tagged event');
  }
  const tagCheck = { name: tag[0], value: tag[1], eventId: taggedSample.id };

  return {
    recentCount: recent.length,
    sampledEventId: sample.id,
    sampledAuthor: sample.pubkey,
    authorKindCount: byAuthorKind.length,
    tagCheck,
  };
}

async function verifyProfileCatalogs(
  profilesRoot: CID,
  profileSearchRoot: CID,
  store: Store,
): Promise<Record<string, unknown>> {
  const tree = new HashTree({ store });
  const profiles = new BTree(store);
  const search = new SearchIndex(store);
  let scanned = 0;

  for await (const [pubkey, eventCid] of profiles.linksEntries(profilesRoot)) {
    scanned += 1;
    if (scanned > PROFILE_SCAN_LIMIT) {
      break;
    }
    const bytes = await tree.readFile(eventCid);
    if (!bytes) {
      throw new Error(`Missing profile event for ${pubkey}`);
    }
    let event: StoredNostrEvent;
    try {
      event = JSON.parse(new TextDecoder().decode(bytes)) as StoredNostrEvent;
    } catch {
      throw new Error(`Invalid profile event JSON for ${pubkey}`);
    }
    if (event.kind !== 0 || event.pubkey !== pubkey || !verifyEvent(event)) {
      throw new Error(`Invalid signed profile event for ${pubkey}`);
    }

    for (const query of profileQueries(event)) {
      const options = { limit: 64, scanLimit: 256 };
      const [inline, linked] = await Promise.all([
        search.search(profileSearchRoot, PROFILE_SEARCH_PREFIX, query, options),
        search.searchLinks(profileSearchRoot, PROFILE_SEARCH_PREFIX, query, options),
      ]);
      const inlineMatch = inline.find((result) => result.id.toLowerCase() === pubkey);
      const linkedMatch = linked.find((result) => result.id.toLowerCase() === pubkey);
      if (!inlineMatch && !linkedMatch) {
        continue;
      }
      if (linkedMatch) {
        const linkedBytes = await tree.readFile(linkedMatch.cid);
        if (!linkedBytes) {
          throw new Error(`Missing linked profile search event for ${pubkey}`);
        }
        const linkedEvent = JSON.parse(new TextDecoder().decode(linkedBytes)) as StoredNostrEvent;
        if (linkedEvent.kind !== 0 || linkedEvent.pubkey !== pubkey || !verifyEvent(linkedEvent)) {
          throw new Error(`Invalid linked profile search event for ${pubkey}`);
        }
      }
      return {
        scannedProfiles: scanned,
        pubkey,
        profileEventId: event.id,
        query,
        inlineMatches: inline.length,
        linkedMatches: linked.length,
      };
    }
  }

  throw new Error(`No searchable real profile found in the first ${PROFILE_SCAN_LIMIT} profiles`);
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseArguments(process.argv.slice(2));
  const store = new StrictReadOnlyStore(new BlossomStore({
    servers: [{ url: options.blossomUrl, read: true, write: false }],
    getTimeoutMs: options.timeoutMs,
  }));
  const [eventCatalog, profileCatalogs] = await Promise.all([
    verifyEventCatalog(options.eventRoot, store),
    verifyProfileCatalogs(options.profilesRoot, options.profileSearchRoot, store),
  ]);
  process.stdout.write(`${JSON.stringify({
    format: 'iris-social/migrated-catalog-verification@1',
    blossomUrl: options.blossomUrl,
    roots: {
      event: nhashEncode(options.eventRoot),
      profiles: nhashEncode(options.profilesRoot),
      profileSearch: nhashEncode(options.profileSearchRoot),
    },
    eventCatalog,
    profileCatalogs,
    blockReads: store.reads,
    distinctBlocks: store.hashes.size,
  })}\n`);
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && path.resolve(process.argv[1]) === filename) {
  main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`migrated Social catalog verification failed: ${message}\n`);
    process.exitCode = 1;
  });
}
