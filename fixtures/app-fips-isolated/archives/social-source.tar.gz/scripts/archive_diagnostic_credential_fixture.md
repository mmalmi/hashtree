# Independent credential fixture: source and plan only

This fixture tests systemd's credential-only `!` command prefix on three new,
transient units. It does not load or modify the archive service, its drop-ins,
the diagnostic controller, publisher, accounts, databases or network services.
No execution or placement is admitted by this document or the plan renderer.
The source is separate from the accepted diagnostic controller packet.

The production owner must first bind the exact target, unused `/run` directory,
existing unprivileged account name/UID/GID, source SHA, interpreter and systemd
tool paths/hashes/versions, and independent supervising operation/deadline.
No runtime download, account creation, container, VM or native build is needed.
The three generated unit names and their task description establish ownership;
all must be absent before entry. The selected account's existing identity must
match exactly; never create or modify an account to make the fixture pass.

Rendering is pure and prints JSON containing argument arrays, not shell text:

```sh
python3 -B scripts/archive_diagnostic_credential_fixture.py render \
  --root "$reviewed_root" --user "$existing_user" --uid "$uid" --gid "$gid"
```

The owner must seal that concrete output before admitting execution. The source
does not execute its rendered commands. A synthetic local rendering is not a
placement authorization. No `systemctl daemon-reload`, unit-file write or
enablement is involved: `systemd-run` creates only the three transient units.

## Entry and limits

Use the owner's independent supervisor, with an absolute 75-second deadline
covering entry, exercise and closure; no retry or deadline renewal. Reserve the
last 20 seconds for cleanup. Run cases serially, with at most one probe process.
Each unit has `MemoryMax=32MiB`, `MemorySwapMax=0`, `TasksMax=8`, no core dump,
64KiB per-file limit, 10-second start and 3-second stop limits, and `Restart=no`.
Finished positive/anchor oneshots retain unit state but no running probe.
The supervisor must still clean them up; `RemainAfterExit` is deliberate.

Entry must establish at least 32MiB available memory and 1MiB free `/run` space
above the host's configured reserves, and no constrained-resource conflict.
The owner must enforce a 1MiB total fixture allocation and 64KiB captured-output
budget. These total limits belong to the supervisor; the per-unit limits do not
bound manager memory or all filesystem allocation. On a bound/failure, skip all
remaining cases and enter cleanup. No competing performance work is allowed.

Create only the admitted absent directory, then the exact rendered layout:
root-owned0755 parent; root-owned0444 `probe.py` matching the source SHA;
root-owned0700 `private`; root-owned0400 `private/challenge` containing the
literal `fixture-only\n`; root-owned0755 `observed`; and three0700 case
directories owned by the existing UID/GID. Verify direct paths, ownership and
modes before starting any unit. Retain an exact created-path inventory.

## Exercise and acceptance

1. Run the rendered `anchor` command, with its15-second call timeout. Require
   command exit0 and loaded transient active/exited unit, correct account,
   `NoNewPrivileges=yes`, and the rendered limits. Save its exact `show` output.
   The probe must report the expected unprivileged UID/GID, `NoNewPrivs=1`,
   denial of the root-only challenge, and a valid systemd invocation ID.
2. Run `positive`. Its `After` and `Requires` must contain only the named anchor
   for this fixture dependency, in addition to systemd's automatic dependencies.
   Require loaded transient active/exited state, correct effective settings and
   `ExecConditionEx` credential flag `no-setuid` from the `!` prefix. The root-only
   `positive-condition.json` must show UID/GID0, `NoNewPrivs=1`, and successful
   challenge access. The unprivileged `positive-start.json` must show the exact
   selected UID/GID, `NoNewPrivs=1`, and `PermissionError` for that same challenge.
   Match each proof PID/invocation against the corresponding recorded systemd
   execution data. Require anchor-start < positive-condition < positive-start
   monotonic timestamps. Both positive proofs must share one invocation ID.
3. Run `negative`, which uses the same condition without `!`. Require a nonzero
   command result, loaded transient failed unit, `Result=exit-code`, condition
   exit255 and no `negative-start.json`. Its condition proof must show the
   selected unprivileged UID/GID, `NoNewPrivs=1`, and `PermissionError`; code254
   means the fixture's prerequisites failed and is not a successful negative.
   Default `CollectMode=inactive` retains this failed unit for inspection.

Read only the named probe files and bounded `show` fields. Preserve complete
bounded command exit/output and probe evidence. A successful helper or a unit
load alone is insufficient. Unexpected settings, absent evidence, skipped cases,
failed probes, missing ordering or unsupported property syntax fail qualification.
There is no fallback to `+`, root ExecStart or a production unit.

## Closure

In all outcomes, first verify each unit's transient flag and exact task
description/source/identity against the admitted plan. Stop only those three
owned names, in the rendered order; never stop a production service. A failed
stop is not closure evidence and is not by itself proof of a leak: independently
inspect all recorded PIDs and cgroups and unit states within the same deadline.
Accept closure only when every unit is inactive/not-found, every recorded probe
PID has exited and every recorded cgroup is empty/absent. Reset the exact failed
unit names and confirm no loaded task unit remains; do not reset unrelated units.

Capture source/layout hashes, probe JSON, effective unit fields, command results,
failure classification and independent closure proof into the owner's private
evidence location. Then retire only the exact inventoried fixture files and
empty directories, checking their ownership/types first. No recursive deletion,
glob cleanup, account change or persistent-unit editing. If a path changed or
closure is uncertain, preserve it, record the exact remaining owner/hold and
report incomplete cleanup. Never report success merely because the deadline
expired. The supervising owner must retain enough authority to complete closure
after its child command fails; shell lifetime alone is not supervision.

Even a passing fixture establishes only effective transient-unit loading,
ordering and credential behavior on that exact runtime. It does not admit the
persistent diagnostic recovery/guard, qualify real power loss, or establish
retained ELF/compiler provenance.

Reference: systemd's `systemd.service` command-prefix documentation and
`src/shared/bus-unit-util.c` handling of `ExecCondition`/`no-setuid`. Installed
version support remains a target qualification fact, not inferred from current
upstream documentation.
