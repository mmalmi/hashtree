import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { resolveHtreeCommand } from './hashtreePaths.mjs';
import { nip19 } from 'nostr-tools';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');
const defaultWorkerCompatibilityDate = '2026-04-01';
const defaultSmokePort = '43180';
const wranglerVersion = '4.112.0';
const compressedFipsPeerPattern = /^(02|03)[0-9a-f]{64}$/i;
const defaultReleaseDataDir = path.join(os.tmpdir(), 'iris-social-release-hashtree');

export const releaseProfile = {
  appName: 'iris social',
  distDir: 'dist',
  treeName: 'social',
  defaultWorkerName: 'iris-social',
  defaultDomains: ['social.iris.to'],
  workerScript: 'scripts/https-static-assets-worker.mjs',
  buildCommand: ['pnpm', 'run', 'build'],
  testCommands: [
    ['pnpm', 'run', 'check'],
    ['pnpm', 'run', 'test:unit'],
    [
      'pnpm',
      'exec',
      'playwright',
      'test',
      'tests/initial-paint.spec.ts',
      'tests/idle-cpu.spec.ts',
      'tests/smoke.spec.ts',
      'tests/favorites-feed-ui.spec.ts',
      'tests/private-contact-sync-ui.spec.ts',
      'tests/recent-searches.spec.ts',
      'tests/public-graph-bootstrap.spec.ts',
      'tests/social-worker-profile-snapshot-browser.spec.ts',
    ],
    [
      'pnpm',
      'exec',
      'playwright',
      'test',
      'tests/fips-p2p.spec.ts',
      'tests/personal-event-index-publication.spec.ts',
      '--workers=1',
    ],
  ],
};

function browserPort(value, label) {
  const raw = `${value}`;
  const port = Number(raw);
  if (!/^\d+$/.test(raw) || !Number.isSafeInteger(port) || port < 1 || port > 65_535) {
    throw new Error(`${label} must be an integer port between 1 and 65535`);
  }
  return `${port}`;
}

function releaseBrowserPorts(env) {
  const smoke = browserPort(
    env.PLAYWRIGHT_SMOKE_PORT ?? env.PLAYWRIGHT_PORT ?? defaultSmokePort,
    'Smoke port',
  );
  const runtime = browserPort(env.PLAYWRIGHT_RUNTIME_PORT ?? Number(smoke) + 1, 'Runtime port');
  const fips = browserPort(env.PLAYWRIGHT_FIPS_PORT ?? Number(smoke) + 2, 'FIPS port');
  if (new Set([smoke, runtime, fips]).size !== 3) {
    throw new Error('Release browser gates require distinct smoke, runtime, and FIPS ports');
  }
  return { smoke, runtime, fips };
}

function wranglerWorkerAssetsCommand(...args) {
  return ['npx', `wrangler@${wranglerVersion}`, 'deploy', ...args];
}

function workerAssetsDeployCommand(options) {
  if (releaseProfile.workerScript) {
    return [
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      releaseProfile.workerScript,
      '--assets',
      releaseProfile.distDir,
      '--name',
      options.workerName,
      '--compatibility-date',
      options.workerCompatibilityDate,
      '--wrangler-version',
      wranglerVersion,
    ];
  }

  return wranglerWorkerAssetsCommand(
    '--assets',
    releaseProfile.distDir,
    '--name',
    options.workerName,
    '--compatibility-date',
    options.workerCompatibilityDate,
    '--keep-vars',
  );
}

export function parseArgs(argv, env = process.env) {
  const args = [...argv].filter((arg, index) => !(arg === '--' && index === 0));
  let workerName;
  let treeName;
  let dryRun = false;
  let skipCloudflare = false;
  const domains = [];
  const routes = [];
  let workerCompatibilityDate;

  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '-h' || arg === '--help') return { help: true };
    if (arg === '--') continue;
    if (arg === '--worker-name') {
      workerName = args.shift();
      continue;
    }
    if (arg === '--tree') {
      treeName = args.shift();
      continue;
    }
    if (arg === '--domain') {
      domains.push(args.shift());
      continue;
    }
    if (arg === '--route') {
      routes.push(args.shift());
      continue;
    }
    if (arg === '--compatibility-date') {
      workerCompatibilityDate = args.shift();
      continue;
    }
    if (arg === '--skip-cloudflare') {
      skipCloudflare = true;
      continue;
    }
    if (arg === '--dry-run') {
      dryRun = true;
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  assertSocialReleaseTargets(domains, routes);
  return {
    dryRun,
    skipCloudflare,
    treeName: treeName ?? releaseProfile.treeName,
    workerName: workerName ?? env.CF_WORKER_NAME_SOCIAL ?? releaseProfile.defaultWorkerName,
    domains: domains.length > 0 ? domains : releaseProfile.defaultDomains,
    routes,
    workerCompatibilityDate:
      workerCompatibilityDate ?? env.CF_WORKER_COMPATIBILITY_DATE ?? defaultWorkerCompatibilityDate,
  };
}

function assertSocialReleaseTargets(domains = [], routes = []) {
  for (const target of [...domains, ...routes]) {
    const host = target.replace(/^https?:\/\//, '').split('/')[0].toLowerCase();
    if (host === 'iris.to' || host === '*.iris.to') {
      throw new Error('Iris Social releases must target social.iris.to; iris.to belongs to Iris Client');
    }
  }
}

export function createReleasePlan(options, env = process.env) {
  assertSocialReleaseTargets(options.domains, options.routes);
  const distDir = path.join(appDir, releaseProfile.distDir);
  const releaseDataDir = env.HTREE_RELEASE_DATA_DIR
    ?? path.join(defaultReleaseDataDir, randomUUID());
  const cleanupDirs = env.HTREE_RELEASE_DATA_DIR ? [] : [releaseDataDir];
  const browserPorts = releaseBrowserPorts(env);
  const steps = [
    {
      id: 'build',
      label: `Build ${releaseProfile.appName}`,
      command: releaseProfile.buildCommand,
      cwd: appDir,
    },
    ...releaseProfile.testCommands.map((command, index) => {
      const smokeTestEnv = command.includes('tests/smoke.spec.ts')
        ? {
            CI: '1',
            PLAYWRIGHT_USE_PREVIEW: '1',
            PLAYWRIGHT_PORT: browserPorts.smoke,
            PLAYWRIGHT_RUNTIME_PORT: browserPorts.runtime,
          }
        : command.includes('tests/personal-event-index-publication.spec.ts')
          ? {
              CI: '1',
              PLAYWRIGHT_USE_PREVIEW: '0',
              PLAYWRIGHT_PORT: browserPorts.fips,
            }
        : undefined;
      return {
        id: `test-${index + 1}`,
        label: `Test ${releaseProfile.appName} (${index + 1}/${releaseProfile.testCommands.length})`,
        command,
        cwd: appDir,
        env: smokeTestEnv,
        parallelGroup: index < 2 ? 'release-static-gates' : 'release-browser-gates',
      };
    }),
    {
      id: 'publish',
      label: `Publish ${releaseProfile.appName} to hashtree`,
      command: resolveHtreeCommand('add', '.', '--publish', options.treeName),
      cwd: distDir,
      // Site publication should not share an LMDB environment with a long-running
      // local daemon. A daemon map resize can otherwise invalidate the release
      // process's mapping even though the immutable site DAG is healthy.
      env: {
        HTREE_DATA_DIR: releaseDataDir,
      },
    },
  ];

  if (!options.skipCloudflare) {
    const deployCommand = workerAssetsDeployCommand(options);
    for (const route of options.routes ?? []) deployCommand.push('--route', route);
    for (const domain of options.domains ?? []) deployCommand.push('--domain', domain);
    steps.push({
      id: 'deploy',
      label: `Deploy ${releaseProfile.appName} to Cloudflare Worker`,
      command: deployCommand,
      cwd: appDir,
    });
  }

  return { profile: releaseProfile, distDir, steps, cleanupDirs };
}

function defaultRunner(step) {
  const [command, ...args] = step.command;
  console.log(`\n==> ${step.label}`);
  console.log(`$ ${[command, ...args].join(' ')}`);
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: step.cwd,
      env: { ...process.env, ...(step.env ?? {}) },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';

    child.stdout?.setEncoding('utf8');
    child.stdout?.on('data', (chunk) => {
      stdout += chunk;
      process.stdout.write(chunk);
    });

    child.stderr?.setEncoding('utf8');
    child.stderr?.on('data', (chunk) => {
      stderr += chunk;
      process.stderr.write(chunk);
    });

    child.on('error', reject);
    child.on('close', (code, signal) => {
      if (signal) {
        const signalMessage = `Process exited with signal ${signal}\n`;
        stderr += signalMessage;
        process.stderr.write(signalMessage);
      }
      resolve({ status: code ?? 1, stdout, stderr });
    });
  });
}

function ensureDistExists(distDir) {
  if (!existsSync(distDir)) {
    throw new Error(`Build output directory not found: ${distDir}`);
  }
}

export function prepareGeneratedReleaseDataDir(dataDir) {
  mkdirSync(dataDir, { recursive: true });
  // `htree` normally starts a detached self-update check on every fresh data
  // directory. That helper has no role in a one-shot site release and can race
  // the parent while both initialize the same new pool member. A fresh sentinel
  // keeps the release single-process without changing normal CLI update policy.
  writeFileSync(path.join(dataDir, 'last-update-check'), '');
}

export function parsePublishOutput(output) {
  const nhashMatch = output.match(/nhash1[ac-hj-np-z02-9]+/iu);
  if (!nhashMatch) {
    throw new Error('Publish succeeded but no nhash was found in htree output');
  }
  return nhashMatch[0];
}

export function requireReleaseFipsPeers(env = process.env) {
  const peers = `${env.VITE_FIPS_PEERS ?? ''}`
    .split(/[\s,]+/)
    .map((peer) => peer.trim())
    .filter(Boolean);
  const invalid = peers.find((peer) => !compressedFipsPeerPattern.test(peer));
  if (invalid) {
    throw new Error(`VITE_FIPS_PEERS contains an invalid compressed FIPS identity: ${invalid}`);
  }
  return peers;
}

export function requireReleaseTreeReference(environmentVariable, env = process.env) {
  const reference = `${env[environmentVariable] ?? ''}`.trim();
  const [npub, treeName, ...extraPath] = reference.split('/');
  if (!npub || !treeName || extraPath.length > 0) {
    throw new Error(`${environmentVariable} must be an explicit npub/tree reference for release`);
  }
  try {
    const decoded = nip19.decode(npub);
    if (decoded.type !== 'npub' || typeof decoded.data !== 'string') {
      throw new Error('not an npub');
    }
  } catch {
    throw new Error(`${environmentVariable} must start with a valid npub`);
  }
  return reference;
}

export function requireReleaseEventIndex(env = process.env) {
  return requireReleaseTreeReference('VITE_NOSTR_EVENT_INDEX', env);
}

export function requireReleaseProfileIndexes(env = process.env) {
  return {
    profileIndex: requireReleaseTreeReference('VITE_PROFILE_INDEX', env),
    profileSearchIndex: requireReleaseTreeReference('VITE_PROFILE_SEARCH_INDEX', env),
  };
}

export function requireReleasePostSearchIndexes(env = process.env) {
  const primary = `${env.VITE_POST_SEARCH_INDEX ?? ''}`.trim();
  const federated = requireOptionalReleaseTreeReferences('VITE_POST_SEARCH_INDEXES', env);
  if (!primary) {
    if (`${env.IRIS_ALLOW_UNCONFIGURED_POST_SEARCH ?? ''}` === '1') {
      return federated;
    }
    throw new Error(
      'VITE_POST_SEARCH_INDEX is required for release; set '
      + 'IRIS_ALLOW_UNCONFIGURED_POST_SEARCH=1 only for an intentional staged rollout',
    );
  }
  return [...new Set([
    requireReleaseTreeReference('VITE_POST_SEARCH_INDEX', env),
    ...federated,
  ])];
}

/**
 * The broad archive, routed people search, routed post search, and relationship
 * catalog are one source-bound activation set. Shadow releases may omit the two
 * new roots, but production activation must never ship only half of the pair.
 */
export function requireReleaseCompleteCatalogIndexes(env = process.env) {
  const profileSearch = `${env.VITE_PROFILE_SEARCH_V3_INDEX ?? ''}`.trim();
  const relationships = `${env.VITE_SOCIAL_RELATIONSHIP_INDEX ?? ''}`.trim();
  const required = `${env.IRIS_REQUIRE_COMPLETE_CATALOGS ?? ''}` === '1';
  if (!required && !profileSearch && !relationships) {
    return null;
  }
  if (!profileSearch || !relationships) {
    throw new Error(
      'VITE_PROFILE_SEARCH_V3_INDEX and VITE_SOCIAL_RELATIONSHIP_INDEX '
      + 'must be activated together',
    );
  }
  return {
    profileSearchIndex: requireReleaseTreeReference('VITE_PROFILE_SEARCH_V3_INDEX', env),
    relationshipIndex: requireReleaseTreeReference('VITE_SOCIAL_RELATIONSHIP_INDEX', env),
  };
}

export function requireOptionalReleaseTreeReferences(environmentVariable, env = process.env) {
  const raw = `${env[environmentVariable] ?? ''}`.trim();
  if (!raw) return [];
  return [...new Set(raw.split(/[\s,]+/).filter(Boolean))].map((reference) => (
    requireReleaseTreeReference(environmentVariable, { [environmentVariable]: reference })
  ));
}

export async function runRelease(options, runner = defaultRunner, env = process.env) {
  if (!options.dryRun) {
    requireReleaseFipsPeers(env);
    requireReleaseEventIndex(env);
    requireReleaseProfileIndexes(env);
    requireOptionalReleaseTreeReferences('VITE_PROFILE_SEARCH_INDEXES', env);
    requireOptionalReleaseTreeReferences('VITE_PROFILE_SEARCH_V3_INDEXES', env);
    requireReleasePostSearchIndexes(env);
    requireReleaseCompleteCatalogIndexes(env);
  }
  const plan = createReleasePlan(options, env);
  let publishedNhash = null;

  try {
    for (let index = 0; index < plan.steps.length;) {
      const step = plan.steps[index];
      if (step.parallelGroup) {
        const parallelSteps = [];
        while (plan.steps[index]?.parallelGroup === step.parallelGroup) {
          parallelSteps.push(plan.steps[index]);
          index += 1;
        }
        if (options.dryRun) {
          for (const parallelStep of parallelSteps) {
            console.log(`\n==> ${parallelStep.label}`);
            console.log(`$ ${parallelStep.command.join(' ')}`);
          }
          continue;
        }
        const outcomes = await Promise.all(parallelSteps.map(async (parallelStep) => {
          try {
            return { step: parallelStep, result: await runner(parallelStep), error: null };
          } catch (error) {
            return { step: parallelStep, result: null, error };
          }
        }));
        const thrown = outcomes.find((outcome) => outcome.error);
        if (thrown) {
          throw thrown.error;
        }
        const failed = outcomes.find((outcome) => outcome.result.status !== 0);
        if (failed) {
          throw new Error(`${failed.step.label} failed with exit code ${failed.result.status}`);
        }
        continue;
      }
      if (step.id === 'publish' && !options.dryRun) {
        ensureDistExists(plan.distDir);
        const generatedDataDir = step.env?.HTREE_DATA_DIR;
        if (generatedDataDir && plan.cleanupDirs.includes(generatedDataDir)) {
          prepareGeneratedReleaseDataDir(generatedDataDir);
        }
      }
      if (options.dryRun) {
        console.log(`\n==> ${step.label}`);
        console.log(`$ ${step.command.join(' ')}`);
        index += 1;
        continue;
      }

      const result = await runner(step);
      if (result.status !== 0) {
        throw new Error(`${step.label} failed with exit code ${result.status}`);
      }
      if (step.id === 'publish') {
        publishedNhash = parsePublishOutput(`${result.stdout}\n${result.stderr}`);
      }
      index += 1;
    }
  } finally {
    for (const cleanupDir of plan.cleanupDirs) {
      rmSync(cleanupDir, { force: true, recursive: true });
    }
  }

  if (publishedNhash) {
    console.log(`\nHashtree URL: htree://${publishedNhash}/index.html`);
  }
  if (!options.skipCloudflare) {
    console.log(`Worker URL target: https://${(options.domains?.[0]) || releaseProfile.defaultDomains[0]}/`);
  }
}

function printHelp() {
  console.log(`Usage: node ./scripts/release-site.mjs [options]

Options:
  --worker-name <name>          Cloudflare Worker name (default: ${releaseProfile.defaultWorkerName})
  --tree <name>                 hashtree publish name (default: ${releaseProfile.treeName})
  --domain <hostname>           Worker custom domain (default: ${releaseProfile.defaultDomains[0]})
  --route <pattern>             Optional Worker route, for example social.iris.to/*
  --compatibility-date <date>   Wrangler compatibility date (default: ${defaultWorkerCompatibilityDate})
  --skip-cloudflare             Only build/test/publish to hashtree
  --dry-run                     Print commands without running them
  -h, --help                    Show this message

Environment:
  VITE_FIPS_PEERS               Comma/space-separated admitted compressed peer ids (required)
  VITE_NOSTR_EVENT_INDEX        Signed npub/tree archive reference (required)
  VITE_PROFILE_INDEX            Signed npub/tree profile catalog reference (required)
  VITE_PROFILE_SEARCH_INDEX     Signed npub/tree profile-search reference (required)
  VITE_PROFILE_SEARCH_INDEXES   Optional federated npub/tree profile-search refs
  VITE_PROFILE_SEARCH_V3_INDEX  Primary routed v3 profile-search ref
  VITE_PROFILE_SEARCH_V3_INDEXES
                                Optional federated routed v3 profile-search refs
  VITE_POST_SEARCH_INDEX        Primary signed npub/tree post-search ref (required by default)
  VITE_POST_SEARCH_INDEXES      Optional federated npub/tree post-search refs
  VITE_SOCIAL_RELATIONSHIP_INDEX
                                Source-bound routed follows/followers catalog
  IRIS_REQUIRE_COMPLETE_CATALOGS=1
                                Require routed profile + relationship roots
  IRIS_ALLOW_UNCONFIGURED_POST_SEARCH=1
                                Explicit staged-rollout opt-out when no primary post search exists
`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    printHelp();
    process.exit(0);
  }

  runRelease(options).catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  });
}
