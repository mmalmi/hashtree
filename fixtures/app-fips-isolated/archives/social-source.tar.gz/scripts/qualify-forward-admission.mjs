// Exercise the collector's live and replay paths against a retained loopback
// relay. The separate archive connection simulates successful native ACKs.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {once} from 'node:events';
import {mkdtemp, readFile, rm, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {pathToFileURL} from 'node:url';

const [bundle, pin, mode] = process.argv.slice(2);
assert(['baseline','candidate'].includes(mode));
const bytes = await readFile(bundle);
assert.equal(createHash('sha256').update(bytes).digest('hex'), pin);
const dir = await mkdtemp(join(tmpdir(),'forward-admission-'));
let server, archive, collector, shutdown, collecting;
try {
  const exposed = join(dir,'probe.mjs');
  await writeFile(exposed, Buffer.concat([bytes, Buffer.from(
    '\nconst FixtureServer=require_websocket_server(); export {FixtureServer,ForwardState,generateSecretKey,finalizeEvent};\n'
  )]), {mode:0o600});
  const {FixtureServer, ForwardState, ReadyReplay, generateSecretKey, finalizeEvent, collect} = await import(pathToFileURL(exposed).href);
  server = new FixtureServer({host:'127.0.0.1',port:0});
  await once(server,'listening');
  const since = Math.floor(Date.now()/1000)-2400;
  const sources = ['a','b','c'].map(s => 'ws://127.0.0.1:'+server.address().port+'/'+s);
  const config = {since,sources};
  const keys = Array.from({length:473},generateSecretKey);
  let serial = 0;
  const signed = (kind, sec) => finalizeEvent({kind,created_at:since+sec,tags:[],
    content:JSON.stringify({fixture:serial,padding:'x'.repeat(650)})},keys[serial++ % keys.length]);
  const initial = Array.from({length:2048},(_,i) => signed(i<2040?7368:i<2045?30402:38383, Math.floor(i/2)));
  const hot = Array.from({length:32},()=>signed(7368,2350));
  const rare = signed(30406,20), live = new Map();
  let releaseResponse, stage, reads = 0, finished = 0;
  server.on('connection',(socket,request) => {
    socket.on('close',()=>live.delete(socket));
    socket.on('message',data => {
      const [type,id,filter] = JSON.parse(data.toString());
      if (type==='REQ' && filter.limit===0) {live.set(socket,{path:request.url,id}); return;}
      if (type!=='REQ' && type!=='COUNT') {return;}
      const match = request.url==='/a' && filter.kinds[0]===rare.kind &&
        filter.since<=rare.created_at && filter.until>=rare.created_at;
      if (type==='COUNT') {socket.send(JSON.stringify(['COUNT',id,{count:match?1:0}])); return;}
      const reply = () => {
        if (match) {
          socket.once('close',()=>{finished++;});
          socket.send(JSON.stringify(['EVENT',id,rare]));
        }
        socket.send(JSON.stringify(['EOSE',id]));
      };
      if (match) {reads++;}
      if (match && stage==='in-flight') {releaseResponse=reply;} else {reply();}
    });
  });
  const until = async (check,label) => {
    for (let i=0;i<1500;i++) {if (check()) {return;} await delay(10);}
    throw new Error('Timed out waiting for '+label);
  };
  const results = [];
  for (const timing of ['ready','in-flight']) {
    const file = join(dir,timing+'.sqlite');
    archive = new ForwardState(file,config,true);
    archive.transaction(()=>{for (const event of initial) {archive.enqueue(event);}});
    const queued = () => archive.db.prepare('SELECT count(*) n FROM queue').get().n;
    const accepted = () => new Set(archive.db.prepare('SELECT id FROM queue UNION ALL SELECT id FROM seen').all().map(row=>row.id));
    const start = () => {
      collector = new ForwardState(file,config);
      shutdown = new AbortController();
      collecting = collect(collector,shutdown.signal);
    };
    const stop = async () => {
      shutdown.abort(); await collecting; collector.db.close(); collector=undefined;
    };
    const pending = archive.prepare();
    assert.equal(pending.batch.events.length,32);
    // Restart after a failed read. The next process must rediscover the event
    // through its durable cursor; no callback from this process can survive.
    stage='ready'; let previous=finished;
    start(); await until(()=>finished>previous,'initial completed replay'); await stop();
    assert.equal(queued(),2048);
    assert(!accepted().has(rare.id));
    assert.equal(archive.window(sources[0],rare.kind,since+1800).since,since);
    stage=timing; previous=finished; releaseResponse=undefined;
    start();
    await until(()=>timing==='ready'?finished>previous:!!releaseResponse,'retry after restart');
    const sender=[...live].find(([,v])=>v.path==='/b');
    assert(sender,'independent live review source is connected');
    archive.acknowledge(pending.sha256,'c'.repeat(64),'simulated-native');
    for (const event of hot) {sender[0].send(JSON.stringify(['EVENT',sender[1].id,event]));}
    await until(()=>queued()===2048,'refill');
    if (releaseResponse) {releaseResponse(); await until(()=>finished>previous,'in-flight replay completion');}
    const ids=accepted(), rareAdmitted=ids.has(rare.id);
    assert.equal(rareAdmitted, mode==='candidate' && timing==='ready');
    assert.equal(ids.size,2080);
    assert(initial.every(e=>ids.has(e.id)));
    assert.equal(hot.filter(e=>ids.has(e.id)).length,32-Number(rareAdmitted));
    if (!rareAdmitted) {assert.equal(archive.window(sources[0],rare.kind,since+1800).since,since);}
    await stop(); archive.db.close(); archive=undefined;
    results.push({timing,rareAdmitted,hotAdmitted:32-Number(rareAdmitted),queued:2048,seen:32,initialPreserved:2048});
  }
  // Repeat the adverse arrival order at each of the 64 original drain points.
  // This part models the completed-response timing deterministically. The two
  // runs above exercised it through collect(), WebSockets and real timers.
  const file = join(dir,'continuous.sqlite');
  archive=new ForwardState(file,config,true);
  archive.transaction(()=>{for (const event of initial) {archive.enqueue(event);}});
  const expected=new Set(initial.map(event=>event.id));
  let rareAdmissions=0, reviewAdmissions=0, scheduler, outstanding;
  for (let round=0; round<64; round++) {
    if (round%8===0) {
      collector?.db.close();
      collector=new ForwardState(file,config);
      scheduler=ReadyReplay && new ReadyReplay(collector);
    }
    const window=collector.window(sources[0],30406,since+60+round);
    const item=outstanding??=signed(30406,round);
    const page={status:'observed',events:[item]};
    const attempt=()=>collector.record(sources[0],window,page);
    const finish=scheduler ? scheduler.record(attempt) : undefined;
    if (!scheduler) {assert.throws(attempt,/capacity reached/);}
    const pending=archive.prepare();
    assert.equal(pending.batch.events.length,32);
    archive.acknowledge(pending.sha256,'d'.repeat(64),'simulated-native');
    for (let i=0;i<32;i++) {
      const review=signed(7368,2350);
      scheduler?.beforeIntake();
      try {
        collector.ingest(sources[1],[review]);
        expected.add(review.id); reviewAdmissions++;
      } catch (error) {assert.match(error.message,/capacity reached/);}
    }
    if (finish) {finish();}
    if (archive.db.prepare('SELECT id FROM queue WHERE id=?').get(item.id)) {
      expected.add(item.id); rareAdmissions++; outstanding=undefined;
    }
    assert.equal(archive.db.prepare('SELECT count(*) n FROM queue').get().n,2048);
  }
  assert.equal(rareAdmissions,mode==='candidate'?64:0);
  assert.equal(reviewAdmissions,2048-rareAdmissions);
  assert.deepEqual(new Set(archive.db.prepare('SELECT id FROM queue UNION ALL SELECT id FROM seen').all().map(row=>row.id)),expected);
  console.log(JSON.stringify({pin,mode,node:process.version,fixture:{kinds:[2040,5,3],authors:473,sources:3},
    restartBeforeEachDrain:true,actualCollector:true,loopbackOnly:true,simulatedArchiveAck:true,reads,results,
    continuousReadyReplay:{drained:2048,rounds:64,collectorSessions:8,rareAdmissions,reviewAdmissions,
      conservedAcceptedIds:expected.size,queued:2048,deterministicReadyResponseTiming:true}}));
} finally {
  shutdown?.abort();
  await collecting;
  collector?.db.close(); archive?.db.close();
  for (const socket of server?.clients??[]) {socket.terminate();}
  if (server) {await new Promise(done=>server.close(done));}
  await rm(dir,{recursive:true,force:true});
}
