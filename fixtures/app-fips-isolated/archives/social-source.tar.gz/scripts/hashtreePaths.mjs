import { existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const appDir = path.resolve(__dirname, '..');
export const workspaceRoot = path.resolve(appDir, '..');

function firstExistingPath(candidates, predicate = existsSync) {
  for (const candidate of candidates) {
    if (!candidate) continue;
    if (predicate(candidate)) return candidate;
  }
  return null;
}

export function resolveHashtreeRepoRoot() {
  return firstExistingPath(
    [
      process.env.HASHTREE_REPO_ROOT,
      path.join(workspaceRoot, 'hashtree'),
    ],
    (candidate) => existsSync(path.join(candidate, 'rust', 'Cargo.toml')),
  );
}

export function resolveHashtreeRustDir() {
  const hashtreeRepoRoot = resolveHashtreeRepoRoot();
  return firstExistingPath(
    [
      process.env.HASHTREE_RUST_DIR,
      hashtreeRepoRoot ? path.join(hashtreeRepoRoot, 'rust') : null,
    ],
    (candidate) => existsSync(path.join(candidate, 'Cargo.toml')),
  );
}

export function resolveHtreeCommand(...args) {
  if (process.env.HTREE_BIN) {
    return [process.env.HTREE_BIN, ...args];
  }

  const rustDir = resolveHashtreeRustDir();
  if (rustDir) {
    return [
      'cargo',
      'run',
      '--manifest-path',
      path.join(rustDir, 'Cargo.toml'),
      '-p',
      'hashtree-cli',
      '--bin',
      'htree',
      '--',
      ...args,
    ];
  }

  return ['htree', ...args];
}

export function resolveNativePublishCommand(distDir, treeName, { dryRun, env }) {
  const gate = env.IRIS_NATIVE_RELEASE_GATE?.trim();
  if ((!gate && !dryRun) || (gate && (!path.isAbsolute(gate)
    || (!dryRun && !statSync(gate, { throwIfNoEntry: false })?.isFile())))) {
    throw new Error('Set IRIS_NATIVE_RELEASE_GATE to the absolute path of the pinned Iris Sites gate');
  }
  const publisher = env.HTREE_BIN ? [env.HTREE_BIN] : resolveHtreeCommand();
  if (publisher.length !== 1 && !dryRun) {
    throw new Error('Set HTREE_BIN to the verified standalone Hashtree publisher');
  }
  return [
    process.execPath, gate || '<IRIS_NATIVE_RELEASE_GATE>',
    '--dist', distDir, '--tree', treeName,
    '--htree', publisher.length === 1 ? publisher[0] : '<HTREE_BIN>',
  ];
}
