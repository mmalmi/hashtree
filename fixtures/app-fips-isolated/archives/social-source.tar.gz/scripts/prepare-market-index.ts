import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { lstat, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { canonical } from '../src/server/archiveCheckpointOutbox';
import { createMarketArchivePlan, MARKET_ARCHIVE_LIMITS, type MarketArchiveConfig } from '../src/server/marketArchivePolicy';

// Populate only after independent production artifact qualification for the pinned source.
// A matching test import qualifies the writer format, not its executable for production.
const qualifiedNativePayloads: ReadonlySet<string> = new Set();

/** Stage only. This command never starts services, queries relays or publishes roots. */
export async function prepareMarketIndexFiles(configFile:string,authorsFile:string,seedFile:string,now?:number,
  trustedPayloads:ReadonlySet<string> = qualifiedNativePayloads) {
  const bounded=async(file:string,max:number)=>{
    const info=await lstat(file);
    if(!info.isFile()||info.isSymbolicLink()||info.size>max){throw new Error('Invalid or oversized preparation input');}
    const bytes=await readFile(file);if(bytes.length>max){throw new Error('Preparation input grew beyond its limit');}return bytes;
  };
  const config:MarketArchiveConfig=JSON.parse((await bounded(configFile,16*1024)).toString());
  const authors=(await bounded(authorsFile,MARKET_ARCHIVE_LIMITS.authors*65)).toString();
  const seeds=JSON.parse((await bounded(seedFile,MARKET_ARCHIVE_LIMITS.seedBytes)).toString());
  const plan=await createMarketArchivePlan(config,authors,seeds,now);
  // Verify the exact executable before producing a usable deployment authority.
  const metadata=await lstat(plan.native.path);
  if(!metadata.isFile()||metadata.isSymbolicLink()||metadata.size>512*1024*1024){throw new Error('Invalid pinned native binary');}
  const digest=createHash('sha256');let bytes=0;
  for await(const chunk of createReadStream(plan.native.path)){bytes+=chunk.length;if(bytes>512*1024*1024){throw new Error('Native binary exceeds its bound');}digest.update(chunk);}
  if(digest.digest('hex')!==plan.native.sha256){throw new Error('Pinned native binary checksum differs');}
  if(!trustedPayloads.has(plan.native.sha256)){
    throw new Error('New Market staging requires a production-qualified native payload for the pinned writer');
  }
  for(let parent=dirname(plan.paths.root);;parent=dirname(parent)){
    const info=await lstat(parent);
    if(!info.isDirectory()||info.isSymbolicLink()){throw new Error('Staging requires direct existing parent directories');}
    if(dirname(parent)===parent){break;}
  }
  // Exclusive creation also prevents accidentally reusing a previous crawl.
  await mkdir(plan.paths.root,{mode:0o700});
  await mkdir(plan.paths.config,{mode:0o700});await mkdir(plan.paths.receipts,{mode:0o700});
  const {authoritySha256,...authority}=plan;
  await writeFile(join(plan.paths.root,'authority.json'),canonical(authority),{flag:'wx',mode:0o600});
  await writeFile(join(plan.paths.root,'authority.sha256'),`${authoritySha256}\n`,{flag:'wx',mode:0o600});
  await writeFile(plan.paths.authors,plan.authorText,{flag:'wx',mode:0o600});
  await writeFile(plan.paths.seed,JSON.stringify(plan.seed.events),{flag:'wx',mode:0o600});
  await writeFile(join(plan.paths.config,'config.toml'),plan.isolatedConfig.text,{flag:'wx',mode:0o600});
  return plan;
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const values=new Map<string,string>();
  for(let i=2;i<process.argv.length;i+=2){const flag=process.argv[i],value=process.argv[i+1];if(!['--config','--authors','--seed'].includes(flag)||!value||values.has(flag)){throw new Error('Usage: prepare-market-index --config config.json --authors authors.txt --seed signed-events.json');}values.set(flag,value);}
  if(values.size!==3){throw new Error('Usage: prepare-market-index --config config.json --authors authors.txt --seed signed-events.json');}
  const plan=await prepareMarketIndexFiles(values.get('--config')!,values.get('--authors')!,values.get('--seed')!);
  console.log(JSON.stringify({directory:plan.paths.root,authoritySha256:plan.authoritySha256,seedRoot:plan.seed.root,authors:plan.authors.length,measurements:plan.measurements,publication:'disabled'}));
}
