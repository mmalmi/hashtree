import { spawn } from 'node:child_process';
import { readdir } from 'node:fs/promises';
import { createServer } from 'node:net';

const compose = ['compose', '-f', 'tests/wallet-integration/compose.yml', '-p', 'iris-social-wallet-test'];
let cleanupPromise;

function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'inherit', ...options });
    child.once('error', reject);
    child.once('exit', (code) => code === 0
      ? resolve()
      : reject(new Error(`${command} exited with ${code ?? 'no status'}`)));
  });
}

async function waitForMint() {
  const deadline = Date.now() + 45_000;
  while (Date.now() < deadline) {
    try {
      const response = await fetch('http://127.0.0.1:3338/v1/info');
      if (response.ok) return;
    } catch {
      // The container is still starting.
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error('Local Cashu mint did not become ready.');
}

async function availablePort() {
  const server = createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const port = typeof address === 'object' && address ? address.port : null;
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  if (!port) throw new Error('Could not reserve a Playwright preview port.');
  return port;
}

async function builtWalletWorker() {
  const assets = await readdir('dist/assets');
  const matches = assets.filter((name) => /^wallet\.worker-[a-z0-9_-]+\.js$/i.test(name));
  if (matches.length !== 1) {
    throw new Error(`Expected one built wallet worker, found ${matches.length}.`);
  }
  return `/assets/${matches[0]}`;
}

function cleanup() {
  cleanupPromise ??= run('docker', [
    ...compose,
    'down',
    '--volumes',
    '--remove-orphans',
  ]).catch(() => undefined);
  return cleanupPromise;
}

function cleanupOnSignal(signal) {
  void cleanup().finally(() => {
    process.removeAllListeners(signal);
    process.kill(process.pid, signal);
  });
}

process.once('SIGINT', () => cleanupOnSignal('SIGINT'));
process.once('SIGTERM', () => cleanupOnSignal('SIGTERM'));

try {
  await run('docker', [...compose, 'up', '-d']);
  await waitForMint();
  await run('pnpm', ['exec', 'tsx', 'tests/wallet-integration/coco-flow.ts']);
  await run('pnpm', ['build']);
  const workerAsset = await builtWalletWorker();
  const previewPort = await availablePort();
  await run('pnpm', [
    'exec',
    'playwright',
    'test',
    'tests/wallet-integration/browser-worker.spec.ts',
    '--project=chromium',
    '--workers=1',
    '--reporter=line',
  ], {
    env: {
      ...process.env,
      IRIS_WALLET_INTEGRATION: '1',
      IRIS_WALLET_WORKER_ASSET: workerAsset,
      PLAYWRIGHT_PORT: String(previewPort),
      PLAYWRIGHT_USE_PREVIEW: '1',
    },
  });
} finally {
  await cleanup();
}
