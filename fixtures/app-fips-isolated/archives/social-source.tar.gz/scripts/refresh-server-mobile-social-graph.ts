import { readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildServerMobileSnapshotArtifacts } from '../src/server/serverMobileSocialGraphSnapshot';

// Exact local producer inputs only. This command does not crawl or download.
const [snapshot, manifest, snapshotSha256, manifestSha256, ...extra] = process.argv.slice(2);
if (!snapshot || !manifest || !snapshotSha256 || !manifestSha256 || extra.length) {
  throw new Error('Usage: refresh-server-mobile-social-graph.ts SNAPSHOT MANIFEST SNAPSHOT_SHA256 MANIFEST_SHA256');
}
const artifacts = await buildServerMobileSnapshotArtifacts(await readFile(snapshot), await readFile(manifest), snapshotSha256, manifestSha256);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
for (const [name, bytes] of [
  ['public/socialGraph.bin', artifacts.snapshotBytes],
  ['public/socialGraphFrontier.bin', artifacts.frontierBytes],
  ['public/socialGraphSnapshot.provenance.json', artifacts.provenanceJson],
  ['src/lib/socialGraphSnapshot.generated.ts', artifacts.generatedModule],
] as const) {
  const path = resolve(root, name), temporary = `${path}.tmp-${process.pid}`;
  await writeFile(temporary, bytes, { flag: 'wx' });
  await rename(temporary, path);
}
process.stdout.write(`${JSON.stringify(artifacts.provenance)}\n`);
