import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import { SocialGraph } from 'nostr-social-graph';
import {
  gateNostrArchiveCoverage,
  parseNostrArchiveCoverageThresholdInputs,
  reportNostrArchiveCoverage,
  reportNostrArchiveMonotonicity,
  type NostrArchiveCoverageThresholds,
} from '../src/server/nostrArchiveCoverage';
import { reportNostrArchiveOvermute } from '../src/server/nostrArchiveOvermute';
import { HashtreeNostrSnapshotReader } from '../src/server/postSearchSnapshotReader';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';

const DEFAULT_STORE_TIMEOUT_MS = 30_000;

const HELP = `Verify an exact immutable Hashtree Nostr archive source root.

Required:
  --snapshot-root <nhash>          Canonical immutable Nostr event-index root
  --baseline-root <nhash>          Canonical immutable root that candidate must contain
  --store-url <http(s) URL>        Hashtree daemon block store
  --eligible-authors <path>        Exact frozen overmute-free author allowlist
  --social-graph-file <path>       Supplied socialGraph.bin snapshot
  --social-graph-root <hex>        Root identity used for distance and direct-mute policy
  --social-graph-sha256 <hex>      Exact lowercase SHA-256 of socialGraph.bin
  --required-kind <kind>           Kind to scan; repeat for every required kind
  --min-valid-events <count>       Minimum aggregate signature-valid events
  --min-distinct-authors <count>   Minimum aggregate signature-valid authors
  --min-kind-valid <kind>:<count>  Minimum valid events for one required kind;
                                   repeat exactly once per required kind

Authentication (choose one):
  --store-auth-file <path>         auth.cookie or JSON credentials file
  IRIS_HASHTREE_STORE_USERNAME and IRIS_HASHTREE_STORE_PASSWORD

Optional:
  --store-timeout-ms <ms>          Per-request timeout; default 30000
  --min-eligible-graph-authors <n> Fail if the supplied graph has fewer eligible authors;
                                   disabled when omitted (production target: 100000)

The command reads only the exact immutable root. It does not resolve mutable
references, mutate or pin blocks, publish events, read secret keys, or sign.
Thresholds are mandatory operator inputs. Invalid signatures count as invalid
events and never satisfy event, author, timestamp, or baseline containment gates.`;

export interface NostrArchiveCoverageCliOptions {
  snapshotRoot: string;
  baselineRoot: string;
  storeUrl: string;
  eligibleAuthorsFile: string;
  socialGraphFile: string;
  socialGraphRoot: string;
  socialGraphSha256: string;
  minEligibleGraphAuthors?: number;
  storeAuthFile?: string;
  storeTimeoutMs: number;
  requiredKinds: number[];
  thresholds: NostrArchiveCoverageThresholds;
}

export function parseNostrArchiveCoverageArguments(
  args: readonly string[],
): NostrArchiveCoverageCliOptions {
  const normalized = args[0] === '--' ? args.slice(1) : [...args];
  const singles = new Map<string, string>();
  const requiredKinds: string[] = [];
  const kindThresholds: string[] = [];
  const known = new Set([
    '--snapshot-root',
    '--baseline-root',
    '--store-url',
    '--eligible-authors',
    '--social-graph-file',
    '--social-graph-root',
    '--social-graph-sha256',
    '--min-eligible-graph-authors',
    '--store-auth-file',
    '--store-timeout-ms',
    '--required-kind',
    '--min-valid-events',
    '--min-distinct-authors',
    '--min-kind-valid',
  ]);

  for (let index = 0; index < normalized.length; index += 2) {
    const key = normalized[index];
    const value = normalized[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid archive coverage argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown archive coverage argument: ${key}`);
    }
    if (key === '--required-kind') {
      requiredKinds.push(value);
      continue;
    }
    if (key === '--min-kind-valid') {
      kindThresholds.push(value);
      continue;
    }
    if (singles.has(key)) {
      throw new Error(`Duplicate archive coverage argument: ${key}`);
    }
    singles.set(key, value.trim());
  }

  const root = required(singles, '--snapshot-root');
  const baselineRoot = required(singles, '--baseline-root');
  parseCanonicalRoot(root, '--snapshot-root');
  parseCanonicalRoot(baselineRoot, '--baseline-root');
  const socialGraphFile = required(singles, '--social-graph-file');
  const socialGraphRoot = parseSocialGraphRoot(required(singles, '--social-graph-root'));
  const socialGraphSha256 = parseSha256(required(singles, '--social-graph-sha256'));
  const coverage = parseNostrArchiveCoverageThresholdInputs({
    requiredKinds,
    minValidEvents: singles.get('--min-valid-events'),
    minDistinctAuthors: singles.get('--min-distinct-authors'),
    minKindValid: kindThresholds,
  });
  return {
    snapshotRoot: root,
    baselineRoot,
    storeUrl: required(singles, '--store-url'),
    eligibleAuthorsFile: required(singles, '--eligible-authors'),
    socialGraphFile,
    socialGraphRoot,
    socialGraphSha256,
    minEligibleGraphAuthors: singles.has('--min-eligible-graph-authors')
      ? parsePositiveInteger(
        required(singles, '--min-eligible-graph-authors'),
        '--min-eligible-graph-authors',
      )
      : undefined,
    storeAuthFile: singles.get('--store-auth-file') || undefined,
    storeTimeoutMs: singles.has('--store-timeout-ms')
      ? parsePositiveInteger(required(singles, '--store-timeout-ms'), '--store-timeout-ms')
      : DEFAULT_STORE_TIMEOUT_MS,
    requiredKinds: coverage.requiredKinds,
    thresholds: coverage.thresholds,
  };
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseNostrArchiveCoverageArguments(process.argv.slice(2));
  const root = parseCanonicalRoot(options.snapshotRoot, '--snapshot-root');
  const baselineRoot = parseCanonicalRoot(options.baselineRoot, '--baseline-root');
  const credentials = await loadStoreCredentials(options.storeAuthFile);
  const eligibleAuthors = parseEligibleAuthorsText(
    await readFile(options.eligibleAuthorsFile, 'utf8'),
  );
  const store = new HttpBlockStore(options.storeUrl, {
    credentials,
    timeoutMs: options.storeTimeoutMs,
  });
  const reader = new HashtreeNostrSnapshotReader(store);
  const report = await reportNostrArchiveCoverage(
    reader,
    root,
    options.requiredKinds,
  );
  const result = gateNostrArchiveCoverage(report, options.thresholds);
  const monotonicity = await reportNostrArchiveMonotonicity(
    reader,
    baselineRoot,
    root,
    options.requiredKinds,
    { eligibleAuthors },
  );
  const socialGraph = await loadSocialGraph(
    options.socialGraphFile,
    options.socialGraphRoot,
    options.socialGraphSha256,
  );
  const overmute = await reportNostrArchiveOvermute(
    reader,
    root,
    options.requiredKinds,
    socialGraph,
    {
      socialGraphSha256: options.socialGraphSha256,
      minEligibleGraphAuthors: options.minEligibleGraphAuthors,
    },
  );
  const failures = [
    ...result.failures,
    ...monotonicity.failures.map((failure) => `monotonicity: ${failure}`),
    ...overmute.failures.map((failure) => `overmute: ${failure}`),
  ];
  const gated = {
    ...result,
    monotonicity,
    overmute,
    passed: failures.length === 0,
    failures,
  };
  process.stdout.write(`${JSON.stringify(gated)}\n`);
  if (!gated.passed) {
    throw new Error(`coverage gates failed: ${gated.failures.join('; ')}`);
  }
}

export function parseEligibleAuthorsText(text: string): Set<string> {
  if (!text.endsWith('\n') || text.trimEnd() !== text.slice(0, -1)) {
    throw new Error('Eligible author file must be canonical newline-delimited text');
  }
  const authors = text.slice(0, -1).split('\n');
  const unique = new Set(authors);
  if (
    authors.length === 0
    || unique.size !== authors.length
    || authors.some((author) => !/^[0-9a-f]{64}$/.test(author))
  ) {
    throw new Error('Eligible author file must contain unique lowercase hex pubkeys');
  }
  return unique;
}

async function loadSocialGraph(
  path: string,
  root: string,
  expectedSha256: string,
): Promise<SocialGraph> {
  let bytes: Uint8Array;
  try {
    bytes = new Uint8Array(await readFile(path));
  } catch {
    throw new Error('Unable to read --social-graph-file');
  }
  const actualSha256 = createHash('sha256').update(bytes).digest('hex');
  if (actualSha256 !== expectedSha256) {
    throw new Error(
      `--social-graph-file SHA-256 mismatch: expected ${expectedSha256}, got ${actualSha256}`,
    );
  }
  try {
    return await SocialGraph.fromBinary(root, bytes);
  } catch {
    throw new Error('Unable to decode a valid snapshot from --social-graph-file');
  }
}

async function loadStoreCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const username = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const password = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (username !== undefined || password !== undefined)) {
    throw new Error('Choose either --store-auth-file or store auth environment variables');
  }
  if (path) {
    try {
      return parseHttpBlockStoreCredentials(await readFile(path, 'utf8'));
    } catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!username || !password) {
    throw new Error(
      'Hashtree store access requires --store-auth-file or both store auth environment variables',
    );
  }
  return { username, password };
}

function parseCanonicalRoot(value: string, name: '--snapshot-root' | '--baseline-root') {
  try {
    const root = nhashDecode(value);
    if (nhashEncode(root) !== value) {
      throw new Error('non-canonical');
    }
    return root;
  } catch {
    throw new Error(`${name} must be a canonical nhash`);
  }
}

function parseSocialGraphRoot(value: string): string {
  if (!/^[0-9a-f]{64}$/.test(value)) {
    throw new Error('--social-graph-root must be a lowercase 64-character hex pubkey');
  }
  return value;
}

function parseSha256(value: string): string {
  if (!/^[0-9a-f]{64}$/.test(value)) {
    throw new Error('--social-graph-sha256 must be lowercase 64-character hex');
  }
  return value;
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {
    throw new Error(`Missing required archive coverage argument: ${key}`);
  }
  return value;
}

function parsePositiveInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Nostr archive coverage failed: ${message}\n`);
    process.exitCode = 1;
  });
}
