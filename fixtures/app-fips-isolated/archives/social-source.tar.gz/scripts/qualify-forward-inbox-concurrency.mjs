// Isolated CLI qualification: loopback TLS relay and synthetic native receipts.
// Does not run the native archive, publish data, or use an existing inbox/key.
import assert from 'node:assert/strict';
import {spawn, execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {once} from 'node:events';
import {readFile, writeFile, mkdir, realpath, mkdtemp, rm} from 'node:fs/promises';
import {createServer} from 'node:https';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {setTimeout as delay} from 'node:timers/promises';
import {pathToFileURL} from 'node:url';

const [rawBaseline, baselineSha, rawCandidate, candidateSha] = process.argv.slice(2);
assert(rawBaseline && rawCandidate && /^[a-f0-9]{64}$/.test(baselineSha) && /^[a-f0-9]{64}$/.test(candidateSha),
  'Use BASELINE_BUNDLE BASELINE_SHA256 CANDIDATE_BUNDLE CANDIDATE_SHA256');
const baseline = await realpath(rawBaseline), candidate = await realpath(rawCandidate);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const bytes = await readFile(candidate);
assert.equal(hash(bytes), candidateSha);
assert.equal(hash(await readFile(baseline)), baselineSha);
const directory = await realpath(await mkdtemp(join(tmpdir(), 'forward-concurrency-')));
const children = new Set(), live = new Map();
let server, sockets, guard, writer;
try {
  const exposed = join(directory, 'collector-probe.mjs');
  await writeFile(exposed, Buffer.concat([bytes, Buffer.from(`
const QualificationWebSocketServer = require_websocket_server();
export {ForwardState, finalizeEvent, generateSecretKey, canonical, digest, configDigest, QualificationWebSocketServer};
`)]), {mode:0o600, flag:'wx'});
  const {ForwardState, finalizeEvent, generateSecretKey, canonical, digest, configDigest, QualificationWebSocketServer}
    = await import(pathToFileURL(exposed).href);
  const certificate = join(directory, 'loopback.crt'), secret = join(directory, 'loopback.key');
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
    '-subj', '/CN=127.0.0.1', '-addext', 'subjectAltName=IP:127.0.0.1', '-keyout', secret, '-out', certificate],
  {stdio:'ignore', timeout:15000});
  server = createServer({key:await readFile(secret), cert:await readFile(certificate)});
  sockets = new QualificationWebSocketServer({server});
  sockets.on('connection', socket => {
    socket.on('message', data => {
      const [type, id, filter] = JSON.parse(data.toString());
      if (type === 'REQ' && filter.limit === 0) {live.set(socket, id);}
      else if (type === 'COUNT') {socket.send(JSON.stringify(['COUNT', id, {count:0}]));}
      else if (type === 'REQ') {socket.send(JSON.stringify(['EOSE', id]));}
    });
    socket.on('close', () => live.delete(socket));
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const config = {since:Math.floor(Date.now()/1000)-120, sources:[`wss://127.0.0.1:${server.address().port}`]};
  const configFile = join(directory, 'config.json'), stateFile = join(directory, 'archive-forward-inbox.sqlite');
  const batchDirectory = join(directory, 'batches');
  await mkdir(batchDirectory, {mode:0o700});
  await writeFile(configFile, JSON.stringify(config), {mode:0o600});
  const wrapper = join(directory, 'cli-wrapper.mjs');
  await writeFile(wrapper, `import {pathToFileURL} from 'node:url';
const [bundle, ...args] = process.argv.slice(2);
process.argv = [process.execPath, bundle, ...args];
process.send('starting');
process.disconnect();
await import(pathToFileURL(bundle).href);
`, {mode:0o600});
  let commands = 0;
  function cli(bundle, mode, ...args) {
    commands++;
    const child = spawn(process.execPath, [wrapper, bundle, mode, configFile, stateFile, ...args], {
      env:{...process.env, NODE_EXTRA_CA_CERTS:certificate}, stdio:['ignore','pipe','pipe','ipc'],
    });
    children.add(child);
    let stdout = '', stderr = '';
    child.stdout.on('data', data => {stdout += data;});
    child.stderr.on('data', data => {stderr += data;});
    const starting = once(child, 'message');
    const done = once(child, 'exit').then(([code, signal]) => {
      children.delete(child);
      return {code, signal, stdout, stderr};
    });
    return {child, starting, done, stderr:() => stderr};
  }
  async function successful(job) {
    const result = await job.done;
    assert.equal(result.code, 0, result.stderr);
    assert(!result.stderr.includes('database is locked'), result.stderr);
    return JSON.parse(result.stdout.trim());
  }
  async function until(check, label) {
    for (let i=0; i<100; i++) {if (await check()) {return;} await delay(50);}
    throw new Error('Timed out: '+label);
  }
  await successful(cli(baseline, 'init'));
  const key = generateSecretKey();
  const event = i => finalizeEvent({kind:7368, created_at:Math.floor(Date.now()/1000), tags:[], content:`fixture-${i}`}, key);
  const initial = [event(0), event(1), event(2)];
  const existing = new ForwardState(stateFile, config);
  for (const item of initial) {existing.enqueue(item);}
  existing.db.close();
  const first = await successful(cli(baseline, 'export', batchDirectory));
  const inputBytes = await readFile(first.file), batch = JSON.parse(inputBytes);
  assert.equal(hash(inputBytes), first.sha256);
  // A valid test root; no native store is read or written by this receipt fixture.
  const root = 'nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq2mctkg';
  const before = {version:2, root, next_author:8, events_received:3};
  const bridge = {format:'hashtree/nostr-index-catchup-forward@1', batchSha256:first.sha256,
    before, historicalState:before, afterRoot:root};
  const receipt = {format:'hashtree/nostr-index-forward-receipt@1', batchSha256:first.sha256,
    configSha256:configDigest(config), since:config.since, before,
    after:{...before, coverage_head:digest(canonical(bridge)+'\n')}, coverageBridge:bridge,
    counts:{input:3,indexed:3,superseded:0}, events:batch.events.map(item => ({id:item.id,status:'indexed',retainedId:item.id}))};
  const receiptFile = join(directory, 'synthetic-native-receipt.json');
  await writeFile(receiptFile, JSON.stringify(receipt), {mode:0o600});

  guard = new DatabaseSync(stateFile);
  guard.exec('BEGIN EXCLUSIVE');
  writer = cli(candidate, 'run');
  const opening = [cli(candidate, 'status'), cli(candidate, 'export', batchDirectory)];
  await Promise.all([writer.starting, ...opening.map(job => job.starting)]);
  await delay(250);
  for (const job of [writer, ...opening]) {assert.equal(job.child.exitCode, null, job.stderr());}
  guard.exec('COMMIT');
  const [openedStatus, openedExport] = await Promise.all(opening.map(successful));
  assert.equal(openedStatus.queued, 3);
  assert.deepEqual(openedExport, first);
  await until(() => live.size === 1, 'live subscription');
  const additional = Array.from({length:80}, (_, i) => event(i+3));
  const feeding = (async () => {
    for (const item of additional) {
      for (const [socket, id] of live) {socket.send(JSON.stringify(['EVENT',id,item]));}
      await delay(30);
    }
  })();
  await delay(100);
  const overlapping = [cli(candidate, 'status'), cli(candidate, 'export', batchDirectory), cli(candidate, 'ack', receiptFile)];
  const overlapResults = await Promise.all(overlapping.map(successful));
  assert.equal(overlapResults[2].acknowledged, first.sha256);
  for (let round=0; round<4; round++) {
    await Promise.all([cli(candidate,'status'),cli(candidate,'export',batchDirectory)].map(successful));
    assert.equal(writer.child.exitCode, null, writer.stderr());
  }
  await feeding;
  await until(async () => (await successful(cli(candidate, 'status'))).queued === additional.length, 'all live input retained');
  assert.deepEqual(await successful(cli(candidate, 'ack', receiptFile)), overlapResults[2]);
  writer.child.kill('SIGTERM');
  const stopped = await writer.done;
  assert.equal(stopped.code, 0, stopped.stderr);
  assert(!stopped.stderr.includes('database is locked'), stopped.stderr);
  const status = await successful(cli(candidate, 'status'));
  assert.equal(status.since, config.since);
  assert.equal(status.authority, configDigest(config));
  assert.equal(status.queued, 80);
  assert.equal(status.lanes.length, 10);
  assert.equal(status.selection.deletionTargets, 'observed-forward-events');
  assert.equal(guard.prepare('SELECT count(*) n FROM seen').get().n, 3);
  const retained = guard.prepare('SELECT id FROM queue UNION ALL SELECT id FROM seen').all().map(row => row.id).sort();
  assert.deepEqual(retained, [...initial,...additional].map(item => item.id).sort());
  assert.equal(guard.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
  assert.equal(guard.prepare('PRAGMA journal_mode').get().journal_mode, 'delete');
  const configured = new ForwardState(stateFile, config);
  assert.equal(configured.db.prepare('PRAGMA synchronous').get().synchronous, 2);
  configured.db.close();

  guard.exec('BEGIN EXCLUSIVE');
  const bounded = cli(candidate, 'status');
  await bounded.starting;
  const start = Date.now(), rejected = await bounded.done, elapsed = Date.now()-start;
  assert.equal(rejected.code, 1);
  assert(rejected.stderr.includes('database is locked'));
  assert(elapsed >= 4500 && elapsed < 7500, `Unbounded lock wait: ${elapsed}ms`);
  guard.exec('COMMIT');
  assert.equal((await successful(cli(candidate, 'status'))).queued, 80);
  console.log(JSON.stringify({passed:true,node:process.version,sqlite:guard.prepare('select sqlite_version() version').get().version,
    baselineSha256:baselineSha,candidateSha256:candidateSha,commands,events:83,acknowledged:3,queued:80,
    existingPendingBytesPreserved:true,concurrentRunStatusExportAck:true,duplicateAck:true,
    busyFailureMs:elapsed,integrity:'ok',journal:'delete',synchronous:'full',productionTouched:false,nativeReceipt:'synthetic'}));
} finally {
  try {guard?.close();} catch { /* Close also rolls back a held fixture lock. */ }
  for (const child of children) {child.kill('SIGTERM');}
  await Promise.all([...children].map(child => once(child, 'exit')));
  for (const socket of sockets?.clients ?? []) {socket.terminate();}
  if (server) {await new Promise(resolve => server.close(resolve));}
  await rm(directory, {recursive:true,force:true});
}
