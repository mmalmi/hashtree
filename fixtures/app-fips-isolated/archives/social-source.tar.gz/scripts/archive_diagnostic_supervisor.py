#!/usr/bin/env python3
"""Source-only preparation of an independently bounded r3 maintenance supervisor.

`render` is inert. `run` and `close` are for separately admitted Linux/systemd
execution only. They never install units, initialize controller state, publish,
start native work directly, or retire files. The accepted controller is unchanged.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import sys
import time


CONTROLLER_SHA = '145a93e84c99e3dcd0f1241c599cfe66287ea44732ea677af7221e76a9131d96'
BINDING_SHA = '6fda08a009367a651edd3d18fa5bd66750b0c5271426e3afc02f84f9ed5cf02b'
CALL_MARGIN = 1200  # 24 x 20s systemctl + 6 x 90s protection + 180s local I/O.
RECOVERY_SECONDS = 300
AUDIT_SECONDS = 180
START_LIMIT = 8420  # <=7200 + CALL_MARGIN, then 20s child/result closure.
STOP_LIMIT = 1740  # <=300 + CALL_MARGIN + 180 audit + 60s closure.
LOG_BYTES = 131072  # One merged stdout/stderr stream per command; three maximum.
JSON_BYTES = 65536
TERMINAL = ('restored', 'aborted')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def direct(path, directory=False):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'absolute direct path required')
    require(all(not item.is_symlink() for item in (path, *path.parents)), 'symlink refused')
    info = path.stat()
    require(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode), 'wrong path type')
    return info


def read(path, limit=JSON_BYTES):
    require(direct(path).st_size <= limit, 'input exceeds bound')
    with Path(path).open('rb') as stream:
        raw = stream.read(limit + 1)
    require(len(raw) <= limit, 'input grew past bound')
    return raw


def exclusive(path, value):
    raw = encode(value)
    require(len(raw) <= JSON_BYTES, 'evidence exceeds bound')
    # No replacement, retries, or removal of a previous supervisor claim.
    with Path(path).open('xb') as stream:
        os.chmod(path, 0o600)
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def render(binding_raw, source_sha):
    require(sha(binding_raw) == BINDING_SHA, 'only the accepted r3 binding is supported')
    require(re.fullmatch('[a-f0-9]{64}', source_sha), 'supervisor source digest required')
    b = json.loads(binding_raw)
    require(b['pinned_files'][b['implementation_path']] == CONTROLLER_SHA, 'controller pin changed')
    require((b['admission_seconds'], b['supervision_seconds'], b['poll_seconds']) == (900, 7200, 5), 'r3 time limits changed')
    home = Path(b['implementation_path']).parent / 'supervision'
    unit = 'iris-social-archive-supervisor-' + b['operation_id'] + '.service'
    plan = {'format': 'iris-social/archive-supervisor@1', 'binding_sha256': BINDING_SHA,
            'binding_file': b['maintenance']['binding_file'], 'controller': b['implementation_path'],
            'controller_sha256': CONTROLLER_SHA, 'controller_cwd': b['root'],
            'recovery_owner': b['recovery_owner'],
            'state_file': str(Path(b['state_directory']) / 'state.json'),
            'admission_file': str(Path(b['state_directory']) / 'service-admission.json'),
            'source': str(home / 'archive_diagnostic_supervisor.py'), 'source_sha256': source_sha,
            'plan_file': str(home / 'plan.json'), 'evidence_directory': str(home / 'evidence'),
            'unit': unit, 'unit_file': '/run/systemd/system/' + unit,
            'recovery_unit': b['maintenance']['boot_unit'], 'archive_service': b['service'],
            'limits': {'cpu_quota_percent': 50, 'memory_bytes': 268435456, 'swap_bytes': 0,
                       'tasks': 32, 'start_seconds': START_LIMIT, 'stop_seconds': STOP_LIMIT,
                       'maximum_total_seconds': START_LIMIT + STOP_LIMIT,
                       'controller_call_margin_seconds': CALL_MARGIN, 'recovery_seconds': RECOVERY_SECONDS,
                       'audit_seconds': AUDIT_SECONDS, 'per_command_output_bytes': LOG_BYTES,
                       'supervisor_evidence_bytes': 1048576},
            'runtime_files': ['claim.json', 'run.log', 'run-result.json', 'close-claim.json',
                              'recover.log', 'audit.log', 'close-result.json']}
    raw = encode(plan)
    args = f'/usr/bin/python3 -I -S -B {plan["source"]}'
    common = f' --plan {plan["plan_file"]} --sha256 {sha(raw)}'
    for value in (args, common, unit, str(home)):
        require(not any(c in value for c in '\n\r%$\\;\"'), 'unsafe systemd token')
    # No dependency on the archive service: stopping this maintenance unit must
    # never stop that service or move its processes into our resource domain.
    body = ('[Unit]\nDescription=One bounded archive diagnostic supervisor\n'
            f'Requisite={plan["recovery_unit"]}\nAfter={plan["recovery_unit"]}\n'
            '[Service]\nType=oneshot\nUser=root\nGroup=root\nRestart=no\n'
            'NoNewPrivileges=yes\nUMask=0077\nCPUAccounting=yes\nCPUQuota=50%\n'
            'MemoryAccounting=yes\nMemoryMax=268435456\nMemorySwapMax=0\nTasksMax=32\n'
            'OOMPolicy=stop\nKillMode=control-group\nKillSignal=SIGKILL\nSendSIGKILL=yes\nLimitCORE=0\n'
            'TimeoutStartFailureMode=kill\nTimeoutStopFailureMode=kill\n'
            'StandardInput=null\nStandardOutput=null\nStandardError=journal\n'
            f'TimeoutStartSec={START_LIMIT}\nTimeoutStopSec={STOP_LIMIT}\n'
            f'ExecStart={args} run{common}\nExecStopPost={args} close{common}\n')
    return {'format': 'iris-social/archive-supervisor-payload@1', 'execution_admitted': False,
            'binding_change_required': False, 'plan_sha256': sha(raw),
            'files': {plan['plan_file']: raw.decode(), plan['unit_file']: body}, 'plan': plan}


def run_budget(state, plan, now, boot_id, admission_exists):
    require(state['format'] == 'iris-social/diagnostic-control@1'
            and state['binding_sha256'] == BINDING_SHA and state['owner'] == plan['recovery_owner'], 'state identity changed')
    require(state['phase'] in ('parking', 'boundary') and state['launch_consumed'] is False
            and not state.get('launch_revoked') and not admission_exists, 'existing claim/transition requires owner recovery')
    require(state['boot_id'] == boot_id, 'prior-boot state requires recovery')
    started, admission, supervision = (state[k] for k in ('started_at', 'admission_deadline', 'supervision_deadline'))
    require(all(type(v) in (int, float) and math.isfinite(v) for v in (started, admission, supervision, now)), 'invalid original deadline')
    # r3 calls time.time() separately for these fields. Permit that small skew;
    # never manufacture, extend or persist a replacement deadline.
    require(900 <= admission - started <= 902 and 7200 <= supervision - started <= 7202,
            'original deadline interval changed')
    require(started <= now < admission < supervision, 'original admission window expired or clock moved backward')
    return min(7200, max(1, math.floor(supervision - now)))


def bounded_command(argv, log_path, timeout, output_limit=LOG_BYTES, *, cwd=None):
    """Bound an owned process group and merged output; no service management.

    Children have a fresh session. Only that captured group is signalled, even
    when its leader exits while a descendant retains the output pipe. systemd
    supplies the independent cgroup/time/memory bound if this wrapper fails.
    """
    started = time.monotonic()
    cause, captured, proc = None, 0, None
    cleanup_errors = []
    with Path(log_path).open('xb') as log:
        os.chmod(log_path, 0o600)
        proc = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, start_new_session=True,
                                env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(proc.stdout, selectors.EVENT_READ)
                eof = False
                while not (eof and proc.poll() is not None):
                    remaining = timeout - (time.monotonic() - started)
                    if remaining <= 0:
                        cause = 'timeout'
                        break
                    for key, _ in selector.select(min(remaining, 0.1)):
                        chunk = os.read(key.fd, 16384)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            eof = True
                            continue
                        room = output_limit - captured
                        log.write(chunk[:room])
                        captured += min(room, len(chunk))
                        if len(chunk) > room:
                            cause = 'output-limit'
                            break
                    if cause:
                        break
        finally:
            # Also dispose of descendants that closed stdout before their
            # leader exited. Never infer group closure from leader exit alone.
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'operation': 'term-owned-group', 'errno': error.errno})
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'operation': 'kill-owned-group', 'errno': error.errno})
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                cleanup_errors.append({'operation': 'reap-owned-child', 'timeout': True})
            proc.stdout.close()
            log.flush()
            os.fsync(log.fileno())
    return {'argv': argv, 'exit_code': proc.returncode, 'bound': cause, 'captured_bytes': captured,
            'seconds': time.monotonic() - started, 'pid': proc.pid,
            'log_sha256': sha(Path(log_path).read_bytes()), 'cleanup_errors': cleanup_errors}


def successful(result):
    return result['exit_code'] == 0 and result['bound'] is None and not result.get('cleanup_errors')


def controller_command(plan, mode, seconds):
    require(mode in ('run', 'recover', 'audit'), 'supervisor cannot initialize, admit or replay publication')
    return ['/usr/bin/python3', '-B', plan['controller'], mode, '--binding', plan['binding_file'],
            '--sha256', BINDING_SHA, '--seconds', str(seconds)]


def load_execution(plan_path, expected_sha):
    require(sys.platform == 'linux' and os.geteuid() == 0, 'separate Linux owner admission required')
    raw = read(plan_path)
    require(sha(raw) == expected_sha, 'supervisor plan changed')
    plan = json.loads(raw)
    binding = read(plan['binding_file'])
    regenerated = render(binding, sha(read(Path(__file__).resolve())))
    require(plan == regenerated['plan'] and str(Path(__file__).resolve()) == plan['source']
            and str(plan_path) == plan['plan_file'], 'not the exact installed supervisor')
    require(sha(read(plan['controller'])) == CONTROLLER_SHA, 'controller changed')
    require(read(plan['unit_file']) == regenerated['files'][plan['unit_file']].encode(), 'supervisor unit changed')
    for path in (plan_path, plan['binding_file'], plan['source'], plan['unit_file']):
        info = direct(path)
        require(info.st_uid == info.st_gid == 0 and not info.st_mode & 0o022, 'owner-only installed input required')
    evidence = Path(plan['evidence_directory'])
    info = direct(evidence, directory=True)
    require(info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o700, 'private evidence directory required')
    invocation = os.environ.get('INVOCATION_ID', '')
    require(re.fullmatch('[a-f0-9]{32}', invocation), 'systemd invocation required')
    status = Path('/proc/self/status').read_text()
    require(re.search(r'^NoNewPrivs:\s+1$', status, re.M), 'NoNewPrivileges required')
    cgroup = Path('/proc/self/cgroup').read_text()
    require(cgroup.strip().endswith('/' + plan['unit']), 'dedicated supervisor cgroup required')
    return plan, evidence, invocation


def execute(mode, plan, evidence, invocation):
    state = json.loads(read(plan['state_file']))
    claim_path = evidence / 'claim.json'
    if mode == 'run':
        require(not any(evidence.iterdir()), 'supervisor evidence already exists; no repeat')
        boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        seconds = run_budget(state, plan, time.time(), boot, Path(plan['admission_file']).exists())
        exclusive(claim_path, {'invocation': invocation, 'binding_sha256': BINDING_SHA,
                              'owner': plan['recovery_owner'], 'state_canonical_sha256': sha(encode(state)),
                              'admission_deadline': state['admission_deadline'],
                              'supervision_deadline': state['supervision_deadline'], 'seconds': seconds})
        result = bounded_command(controller_command(plan, 'run', seconds), evidence / 'run.log',
                                 seconds + CALL_MARGIN, cwd=plan['controller_cwd'])
        exclusive(evidence / 'run-result.json', result)
        return 0 if successful(result) else 75

    claim = json.loads(read(claim_path))
    require(claim['invocation'] == invocation and claim['binding_sha256'] == BINDING_SHA
            and claim['owner'] == plan['recovery_owner'], 'closure belongs to another invocation')
    require(state['binding_sha256'] == BINDING_SHA and state['owner'] == plan['recovery_owner']
            and all(state[k] == claim[k] for k in ('admission_deadline', 'supervision_deadline')),
            'controller identity/deadline drift; preserve state for owner')
    exclusive(evidence / 'close-claim.json', {'invocation': invocation, 'owner': plan['recovery_owner']})
    result = {'owner': plan['recovery_owner'], 'invocation': invocation, 'restoration_verified': False,
              'publication_replayed': False, 'service_result': os.environ.get('SERVICE_RESULT'),
              'recover': None, 'audit': None}
    if state['phase'] not in TERMINAL:
        result['recover'] = bounded_command(controller_command(plan, 'recover', RECOVERY_SECONDS),
                                            evidence / 'recover.log', RECOVERY_SECONDS + CALL_MARGIN,
                                            cwd=plan['controller_cwd'])
    # Do not turn an already-restored operation back into a recovery transition:
    # its timer may already have started a normal baseline service invocation.
    if result['recover'] is None or successful(result['recover']):
        result['audit'] = bounded_command(controller_command(plan, 'audit', AUDIT_SECONDS),
                                          evidence / 'audit.log', AUDIT_SECONDS, cwd=plan['controller_cwd'])
        after = json.loads(read(plan['state_file']))
        result['restoration_verified'] = (successful(result['audit']) and after['phase'] in TERMINAL
                                           and after.get('timer_healthy') is True
                                           and after.get('recovery_required') is False)
    result['held_owner_followup_required'] = not result['restoration_verified']
    exclusive(evidence / 'close-result.json', result)
    return 0 if result['restoration_verified'] else 75


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('render', 'run', 'close'))
    parser.add_argument('--binding')
    parser.add_argument('--plan')
    parser.add_argument('--sha256')
    args = parser.parse_args()
    if args.mode == 'render':
        require(args.binding is not None, 'render needs the retained r3 binding')
        print(json.dumps(render(read(args.binding), sha(Path(__file__).read_bytes())), indent=2))
        return 0
    require(args.plan and args.sha256, 'execution needs exact sealed plan')
    plan, evidence, invocation = load_execution(args.plan, args.sha256)
    return execute(args.mode, plan, evidence, invocation)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        # Missing/partial evidence is failure, never a healthy held operation.
        # Fleet retains independent inspection/recovery authority; no retry.
        print(json.dumps({'healthy': False, 'supervisor_error': type(error).__name__,
                          'reason': str(error)[:512]}), file=sys.stderr)
        sys.exit(75)
