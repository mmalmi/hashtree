import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BlossomStore,
  HashTree,
  fromHex,
  nhashDecode,
  nhashEncode,
  objectKeyFromHex,
  toHex,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import { BTree, SearchIndex } from '@hashtree/index';
import { verifyEvent, type Event } from 'nostr-tools/pure';

const PROFILE_SEARCH_PREFIX = 'p:';
const DEFAULT_TIMEOUT_MS = 15_000;
const SEARCH_LIMIT = 64;
const SEARCH_SCAN_LIMIT = 128;

const HELP = `Verify immutable Iris Social profile catalogs through Blossom.

Required:
  --profile-search-root <root>       Canonical nhash or 64-hex hash[:key]
  --profiles-by-pubkey-root <root>  Canonical nhash or 64-hex hash[:key]
  --blossom-url <http(s) URL>       Read-only Blossom/CDN base URL
  --expected-pubkey <hex>           Expected 64-hex profile pubkey
  --query <text>                     Search query; repeat at least once

Optional:
  --timeout-ms <ms>                  Per-block read timeout; default 15000

The command uses only immutable roots. It never resolves mutable refs, writes
blocks, signs events, or publishes anything.`;

export type ProfileCatalogCliOptions = {
  profileSearchRoot: string;
  profilesByPubkeyRoot: string;
  blossomUrl: string;
  expectedPubkey: string;
  queries: string[];
  timeoutMs: number;
};

export type ProfileCatalogVerification = {
  profileSearchRoot: string;
  profilesByPubkeyRoot: string;
  blossomUrl: string;
  expectedPubkey: string;
  queries: Array<{ query: string; matches: number }>;
  profileEventId: string;
};

class StrictReadOnlyStore implements Store {
  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array> {
    const block = await this.source.get(hash);
    if (!block) {
      throw new Error(`Missing or corrupt Hashtree block: ${toHex(hash)}`);
    }
    return block;
  }

  async has(hash: Hash): Promise<boolean> {
    await this.get(hash);
    return true;
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Profile catalog verification is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Profile catalog verification is read-only');
  }
}

export function parseImmutableCatalogRoot(value: string): CID {
  const trimmed = value.trim();
  if (trimmed.startsWith('nhash1')) {
    const root = nhashDecode(trimmed);
    if (nhashEncode(root) !== trimmed) {
      throw new Error('Immutable catalog nhash must use canonical encoding');
    }
    return root;
  }

  const parts = trimmed.split(':');
  if (parts.length > 2 || !/^[0-9a-f]{64}$/.test(parts[0] ?? '')) {
    throw new Error('Immutable catalog root must be a canonical nhash or 64-hex hash[:key]');
  }
  if (parts[1] !== undefined && !/^[0-9a-f]+$/.test(parts[1])) {
    throw new Error('Immutable catalog root key must use lowercase hex characters');
  }
  return parts[1]
    ? { hash: fromHex(parts[0]!), key: objectKeyFromHex(parts[1]) }
    : { hash: fromHex(parts[0]!) };
}

function parseBlossomUrl(value: string): string {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error('--blossom-url must be a valid http(s) URL');
  }
  if (!['http:', 'https:'].includes(parsed.protocol)
    || parsed.username
    || parsed.password
    || parsed.search
    || parsed.hash) {
    throw new Error('--blossom-url must be an uncredentialed http(s) base URL');
  }
  return parsed.toString().replace(/\/+$/, '');
}

function parsePositiveInteger(value: string, option: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${option} must be a positive integer`);
  }
  return parsed;
}

export function parseProfileCatalogArguments(args: string[]): ProfileCatalogCliOptions {
  const normalizedArgs = args[0] === '--' ? args.slice(1) : args;
  const singleValues = new Map<string, string>();
  const queries: string[] = [];
  const known = new Set([
    '--profile-search-root',
    '--profiles-by-pubkey-root',
    '--blossom-url',
    '--expected-pubkey',
    '--query',
    '--timeout-ms',
  ]);

  for (let index = 0; index < normalizedArgs.length; index += 2) {
    const key = normalizedArgs[index];
    const value = normalizedArgs[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid profile catalog argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown profile catalog argument: ${key}`);
    }
    if (key === '--query') {
      if (!value.trim()) {
        throw new Error('--query must not be empty');
      }
      queries.push(value.trim());
      continue;
    }
    if (singleValues.has(key)) {
      throw new Error(`Duplicate profile catalog argument: ${key}`);
    }
    singleValues.set(key, value.trim());
  }

  const required = (key: string): string => {
    const value = singleValues.get(key);
    if (!value) {
      throw new Error(`Missing required profile catalog argument: ${key}`);
    }
    return value;
  };
  const expectedPubkey = required('--expected-pubkey').toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(expectedPubkey)) {
    throw new Error('--expected-pubkey must be 64 hex characters');
  }
  if (queries.length === 0) {
    throw new Error('At least one --query is required');
  }

  return {
    profileSearchRoot: required('--profile-search-root'),
    profilesByPubkeyRoot: required('--profiles-by-pubkey-root'),
    blossomUrl: parseBlossomUrl(required('--blossom-url')),
    expectedPubkey,
    queries,
    timeoutMs: singleValues.has('--timeout-ms')
      ? parsePositiveInteger(required('--timeout-ms'), '--timeout-ms')
      : DEFAULT_TIMEOUT_MS,
  };
}

function requireMatchingSearchEntry(value: string, expectedPubkey: string, query: string): void {
  let parsed: unknown;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new Error(`Profile search returned invalid JSON for query ${JSON.stringify(query)}`);
  }
  const pubkey = parsed && typeof parsed === 'object' && 'pubkey' in parsed
    ? String(parsed.pubkey).toLowerCase()
    : '';
  if (pubkey !== expectedPubkey) {
    throw new Error(`Profile search entry pubkey mismatch for query ${JSON.stringify(query)}`);
  }
}

function parseAndVerifyProfileEvent(bytes: Uint8Array, expectedPubkey: string): Event {
  let event: unknown;
  try {
    event = JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    throw new Error('profiles-by-pubkey points to invalid event JSON');
  }
  if (!event || typeof event !== 'object') {
    throw new Error('profiles-by-pubkey points to a non-object event');
  }
  const candidate = event as Event;
  if (candidate.kind !== 0 || candidate.pubkey !== expectedPubkey || !verifyEvent(candidate)) {
    throw new Error('profiles-by-pubkey event must be a valid signed matching kind-0 event');
  }
  return candidate;
}

export async function verifyProfileCatalog(
  options: ProfileCatalogCliOptions,
  source?: Store,
): Promise<ProfileCatalogVerification> {
  const profileSearchRoot = parseImmutableCatalogRoot(options.profileSearchRoot);
  const profilesByPubkeyRoot = parseImmutableCatalogRoot(options.profilesByPubkeyRoot);
  const store = new StrictReadOnlyStore(source ?? new BlossomStore({
    servers: [{ url: options.blossomUrl, read: true, write: false }],
    getTimeoutMs: options.timeoutMs,
  }));
  const search = new SearchIndex(store);
  const tree = new HashTree({ store });
  const queryResults = [];

  for (const query of options.queries) {
    const searchOptions = { limit: SEARCH_LIMIT, scanLimit: SEARCH_SCAN_LIMIT };
    const [inlineResults, linkedResults] = await Promise.all([
      search.search(profileSearchRoot, PROFILE_SEARCH_PREFIX, query, searchOptions),
      search.searchLinks(profileSearchRoot, PROFILE_SEARCH_PREFIX, query, searchOptions),
    ]);
    const inlineMatch = inlineResults.find(
      (result) => result.id.toLowerCase() === options.expectedPubkey,
    );
    const linkedMatch = linkedResults.find(
      (result) => result.id.toLowerCase() === options.expectedPubkey,
    );
    if (!inlineMatch && !linkedMatch) {
      throw new Error(
        `Expected pubkey ${options.expectedPubkey} was not found for query ${JSON.stringify(query)}`,
      );
    }
    if (inlineMatch) {
      requireMatchingSearchEntry(inlineMatch.value, options.expectedPubkey, query);
    }
    if (linkedMatch) {
      const bytes = await tree.readFile(linkedMatch.cid);
      if (!bytes) {
        throw new Error(`Profile search link is missing for query ${JSON.stringify(query)}`);
      }
      parseAndVerifyProfileEvent(bytes, options.expectedPubkey);
    }
    queryResults.push({
      query,
      matches: new Set([
        ...inlineResults.map((result) => result.id.toLowerCase()),
        ...linkedResults.map((result) => result.id.toLowerCase()),
      ]).size,
    });
  }

  const profileCid = await new BTree(store).getLink(profilesByPubkeyRoot, options.expectedPubkey);
  if (!profileCid) {
    throw new Error(`profiles-by-pubkey has no entry for ${options.expectedPubkey}`);
  }
  const profileBytes = await tree.readFile(profileCid);
  if (!profileBytes) {
    throw new Error(`profiles-by-pubkey event is missing for ${options.expectedPubkey}`);
  }
  const event = parseAndVerifyProfileEvent(profileBytes, options.expectedPubkey);

  return {
    profileSearchRoot: nhashEncode(profileSearchRoot),
    profilesByPubkeyRoot: nhashEncode(profilesByPubkeyRoot),
    blossomUrl: options.blossomUrl,
    expectedPubkey: options.expectedPubkey,
    queries: queryResults,
    profileEventId: event.id,
  };
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const result = await verifyProfileCatalog(parseProfileCatalogArguments(process.argv.slice(2)));
  process.stdout.write(`${JSON.stringify(result)}\n`);
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && path.resolve(process.argv[1]) === filename) {
  main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`profile catalog verification failed: ${message}\n`);
    process.exitCode = 1;
  });
}
