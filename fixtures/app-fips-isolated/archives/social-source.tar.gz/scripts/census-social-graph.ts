import { readFile, writeFile } from 'node:fs/promises';
import { SocialGraph } from 'nostr-social-graph';
import {
  type NostrSocialGraphCensus,
} from '../src/server/nostrArchiveOvermute';
import {
  createBroadArchiveCensusArtifacts,
  type BroadArchiveCensusReport,
} from '../src/server/broadArchiveRollout';

const HELP = `Census an exact social-graph snapshot and optionally write its eligible author allowlist.

Required:
  --social-graph-file <path>       socialGraph.bin snapshot
  --social-graph-root <hex>        Root identity used for follow distance and mute policy
  --social-graph-sha256 <hex>      Exact lowercase SHA-256 of the snapshot

Optional:
  --max-distance <n>               Include eligible authors through this follow distance
  --min-eligible-authors <n>       Fail if the selected eligible set is smaller
  --write-eligible-authors <path>  Write newline-delimited eligible pubkeys for Hashtree

The overmute threshold is fixed at 1.0 to match Iris Client. Output ordering is
distance first and pubkey second, so a bounded Hashtree author limit keeps the
closest eligible identities. The output never contains overmuted authors.`;

export interface SocialGraphCensusCliOptions {
  socialGraphFile: string;
  socialGraphRoot: string;
  socialGraphSha256: string;
  maxDistance?: number;
  minEligibleAuthors?: number;
  eligibleAuthorFile?: string;
}

export type SelectedSocialGraphCensus = BroadArchiveCensusReport;

export function parseSocialGraphCensusArguments(
  args: readonly string[],
): SocialGraphCensusCliOptions {
  const normalized = args[0] === '--' ? args.slice(1) : [...args];
  const values = new Map<string, string>();
  const known = new Set([
    '--social-graph-file',
    '--social-graph-root',
    '--social-graph-sha256',
    '--max-distance',
    '--min-eligible-authors',
    '--write-eligible-authors',
  ]);

  for (let index = 0; index < normalized.length; index += 2) {
    const key = normalized[index];
    const value = normalized[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid social graph census argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown social graph census argument: ${key}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate social graph census argument: ${key}`);
    }
    values.set(key, value.trim());
  }

  return {
    socialGraphFile: required(values, '--social-graph-file'),
    socialGraphRoot: parseHex(required(values, '--social-graph-root'), '--social-graph-root'),
    socialGraphSha256: parseHex(
      required(values, '--social-graph-sha256'),
      '--social-graph-sha256',
    ),
    maxDistance: values.has('--max-distance')
      ? parseNonNegativeInteger(required(values, '--max-distance'), '--max-distance')
      : undefined,
    minEligibleAuthors: values.has('--min-eligible-authors')
      ? parsePositiveInteger(
        required(values, '--min-eligible-authors'),
        '--min-eligible-authors',
      )
      : undefined,
    eligibleAuthorFile: values.get('--write-eligible-authors') || undefined,
  };
}

export function selectEligibleSocialGraphAuthors(
  graph: SocialGraph,
  census: NostrSocialGraphCensus,
  maxDistance?: number,
): string[] {
  if (maxDistance !== undefined && (!Number.isSafeInteger(maxDistance) || maxDistance < 0)) {
    throw new Error('Maximum social graph distance must be a non-negative integer');
  }
  return census.eligiblePubkeys.filter((pubkey) => (
    maxDistance === undefined || graph.getFollowDistance(pubkey) <= maxDistance
  ));
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseSocialGraphCensusArguments(process.argv.slice(2));
  const bytes = new Uint8Array(await readFile(options.socialGraphFile));
  const artifacts = await createBroadArchiveCensusArtifacts(bytes, {
    socialGraphRoot: options.socialGraphRoot,
    socialGraphSha256: options.socialGraphSha256,
    maxDistance: options.maxDistance,
    minEligibleAuthors: options.minEligibleAuthors,
  });
  if (options.eligibleAuthorFile) {
    await writeFile(options.eligibleAuthorFile, artifacts.eligibleAuthorsText, { mode: 0o600 });
  }
  process.stdout.write(`${JSON.stringify(artifacts.report)}\n`);
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {
    throw new Error(`Missing required social graph census argument: ${key}`);
  }
  return value;
}

function parseHex(value: string, name: string): string {
  if (!/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`${name} must be lowercase 64-character hex`);
  }
  return value;
}

function parseNonNegativeInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new Error(`${name} must be a non-negative integer`);
  }
  return parsed;
}

function parsePositiveInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Social graph census failed: ${message}\n`);
    process.exitCode = 1;
  });
}
