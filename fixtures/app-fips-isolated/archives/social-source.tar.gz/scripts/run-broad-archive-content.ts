import { execFile as execFileCallback } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createServer, type Server } from 'node:http';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import { readCompletedStagingState } from '../src/server/nativeStagingState';
import {
  parseNativeNostrCrawlState,
  type NativeNostrCrawlState,
} from '../src/server/nativeNostrCrawlState';
import {
  BROAD_ARCHIVE_HTREE_VERSION,
  BROAD_ARCHIVE_KINDS,
  BROAD_ARCHIVE_MIN_ELIGIBLE_AUTHORS,
  PROFILE_FAST_LANE_KINDS,
  buildBroadArchiveContentArguments,
  validateBroadArchiveCensusArtifacts,
  type BroadArchiveCensusReport,
} from '../src/server/broadArchiveRollout';
import { runNativeBroadArchiveIndex } from './run-native-broad-archive-index';

export { runNativeBroadArchiveIndex } from './run-native-broad-archive-index';

const execFile = promisify(execFileCallback);
const DEFAULT_MAX_LIVE_MIB = 2_097_152;
const DEFAULT_PER_AUTHOR_EVENT_LIMIT = 65_536;
const DEFAULT_PER_AUTHOR_LIVE_BYTES = 67_108_864;
const DEFAULT_RELAY_EVENT_MAX_BYTES = 1_048_576;
const DEFAULT_AUTHOR_BATCH_SIZE = 16;
const DEFAULT_PROFILE_AUTHOR_BATCH_SIZE = 8;
const MAX_AUTHOR_BATCH_SIZE = 64;
const MAX_PROFILE_AUTHOR_BATCH_SIZE = 8;
const DEFAULT_PROFILE_MAX_AUTHORS_PER_PROCESS = 1_024;
const MAX_PROFILE_MAX_AUTHORS_PER_PROCESS = 1_024;
const DEFAULT_CHECKPOINT_AUTHORS = 16;
const DEFAULT_INDEX_COMMIT_BATCH_SIZE = 32_768;
const DEFAULT_INCREMENTAL_PROJECTION_COMMIT_BATCH_SIZE = 256;
const MAX_INCREMENTAL_PROJECTION_COMMIT_BATCH_SIZE = 1_024;
const DEFAULT_BTREE_ORDER = 256;
const DEFAULT_BTREE_UPDATE_CONCURRENCY = 4;
const DEFAULT_PROJECTION_AUTHORS = 64;
const DEFAULT_PROJECTION_EVENT_LIMIT = 65_536;

export type BroadArchivePhase = 'combined' | 'fetch' | 'project';

const HELP = `Run one resumable native Hashtree crawl against one exact graph census.

Required:
  --htree <path>                  Verified htree binary
  --data-dir <path>               Isolated Iris Social HTREE_DATA_DIR
  --social-graph-file <path>      Exact socialGraph.bin used by the census
  --census-report <path>          JSON @2 census report
  --eligible-authors <path>       Exact newline allowlist bound by the report
  --relay <url>                   Exact relay set (required; repeatable)

Optional:
  --home <path>                   HOME for the isolated htree identity/config
  --expected-htree-version <v>    Exact required version (default: ${BROAD_ARCHIVE_HTREE_VERSION})
  --author-batch-size <n>         Native relay batch size (default: 16; profile-only: 8; max: 64/8)
  --checkpoint-authors <n>        Native durable checkpoint cadence (default: 16; profile-only: 8)
  --max-authors-per-process <n>   Reopen profile-only native process mappings after n authors (default/max: 1024)
  --index-commit-batch-size <n>   Events per bounded Hashtree index commit (default: 32768; incremental projection default: 256, max: 1024)
  --btree-order <n>               Maximum children per Hashtree B-tree node (default: 256)
  --btree-update-concurrency <n>  Dense B-tree subtree workers (default: 4)
  --phase <combined|fetch|project> Run relay fetch+projection together, fetch only, or projection only
  --staging-data-dir <path>        Separate Hashtree store for fetch state and event blobs
  --projection-authors <n>        Authors combined per projection batch (default: 64)
  --projection-event-limit <n>    Soft event bound per projection batch (default: 65536)
  --projection-follow             Keep projection waiting for a live fetch pass
  --bulk-project-staged           Build staged data through the disk-backed bulk projector
  --max-live-mib <n>              Archive live-byte cap (default: 2097152 = 2 TiB)
  --per-author-event-limit <n>    Retained events per author (default: 65536)
  --per-author-live-bytes <n>     Per-author byte safety cap (default: 67108864)
  --relay-event-max-bytes <n>     Maximum accepted relay event (default: 1048576)
  --profile-only                  Keep latest kind 0, 3, and 10000 per author for the profile fast lane
  --dry-run                       Verify every artifact and print the command only

Fetch state lives in DATA_DIR/nostr-stage/crawl-state.json. The independent
projection/publication watermark remains DATA_DIR/nostr-index/crawl-state.json.
Both phases resume durably; the staging queue contains only content-addressed
event CIDs and is not a second query index.`;

export type BroadArchiveContentCliOptions = {
  htreePath: string;
  dataDir: string;
  socialGraphFile: string;
  censusReportFile: string;
  eligibleAuthorsFile: string;
  home?: string;
  relays: string[];
  expectedHtreeVersion: string;
  authorBatchSize: number;
  checkpointAuthors: number;
  maxAuthorsPerProcess?: number;
  indexCommitBatchSize: number;
  btreeOrder: number;
  btreeUpdateConcurrency: number;
  phase: BroadArchivePhase;
  stagingDataDir?: string;
  projectionAuthors: number;
  projectionEventLimit: number;
  projectionFollow: boolean;
  bulkProjectStaged: boolean;
  maxLiveMiB: number;
  perAuthorEventLimit: number;
  perAuthorLiveBytes: number;
  relayEventMaxBytes: number;
  profileOnly: boolean;
  dryRun: boolean;
};

export function parseBroadArchiveContentArguments(
  args: readonly string[],
): BroadArchiveContentCliOptions {
  const normalized = args[0] === '--' ? args.slice(1) : [...args];
  const values = new Map<string, string>();
  const relays: string[] = [];
  let dryRun = false;
  let profileOnly = false;
  let projectionFollow = false;
  let bulkProjectStaged = false;
  const known = new Set([
    '--htree', '--data-dir', '--social-graph-file', '--census-report',
    '--eligible-authors', '--home', '--relay', '--expected-htree-version',
    '--author-batch-size', '--checkpoint-authors', '--max-live-mib', '--per-author-event-limit',
    '--max-authors-per-process',
    '--per-author-live-bytes', '--relay-event-max-bytes', '--index-commit-batch-size',
    '--btree-order', '--btree-update-concurrency',
    '--phase', '--projection-authors', '--projection-event-limit',
    '--staging-data-dir',
  ]);

  for (let index = 0; index < normalized.length;) {
    const key = normalized[index];
    if (key === '--dry-run') {
      if (dryRun) {throw new Error('Duplicate broad archive argument: --dry-run');}
      dryRun = true;
      index += 1;
      continue;
    }
    if (key === '--profile-only') {
      if (profileOnly) {throw new Error('Duplicate broad archive argument: --profile-only');}
      profileOnly = true;
      index += 1;
      continue;
    }
    if (key === '--projection-follow') {
      if (projectionFollow) {throw new Error('Duplicate broad archive argument: --projection-follow');}
      projectionFollow = true;
      index += 1;
      continue;
    }
    if (key === '--bulk-project-staged') {
      if (bulkProjectStaged) {throw new Error('Duplicate broad archive argument: --bulk-project-staged');}
      bulkProjectStaged = true;
      index += 1;
      continue;
    }
    const value = normalized[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid broad archive argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {throw new Error(`Unknown broad archive argument: ${key}`);}
    if (key === '--relay') {
      relays.push(value.trim());
    } else {
      if (values.has(key)) {throw new Error(`Duplicate broad archive argument: ${key}`);}
      values.set(key, value.trim());
    }
    index += 2;
  }

  const normalizedRelays = [...new Set(relays.filter(Boolean))];
  if (normalizedRelays.length === 0) {
    throw new Error('At least one explicit --relay is required for an auditable crawl');
  }
  const perAuthorLiveBytes = positiveInteger(
    values.get('--per-author-live-bytes'),
    DEFAULT_PER_AUTHOR_LIVE_BYTES,
    '--per-author-live-bytes',
  );
  if (perAuthorLiveBytes > DEFAULT_PER_AUTHOR_LIVE_BYTES) {
    throw new Error('--per-author-live-bytes exceeds the 64 MiB rollout safety bound');
  }
  const authorBatchSize = positiveInteger(
    values.get('--author-batch-size'),
    profileOnly ? DEFAULT_PROFILE_AUTHOR_BATCH_SIZE : DEFAULT_AUTHOR_BATCH_SIZE,
    '--author-batch-size',
  );
  const maxAuthorBatchSize = profileOnly
    ? MAX_PROFILE_AUTHOR_BATCH_SIZE
    : MAX_AUTHOR_BATCH_SIZE;
  if (authorBatchSize > maxAuthorBatchSize) {
    const scope = profileOnly ? 'profile-only ' : '';
    throw new Error(
      `--author-batch-size exceeds the ${scope}rollout safety bound of ${maxAuthorBatchSize}`,
    );
  }
  const maxAuthorsPerProcess = values.has('--max-authors-per-process') || profileOnly
    ? positiveInteger(
      values.get('--max-authors-per-process'),
      DEFAULT_PROFILE_MAX_AUTHORS_PER_PROCESS,
      '--max-authors-per-process',
    )
    : undefined;
  if (maxAuthorsPerProcess !== undefined && !profileOnly) {
    throw new Error('--max-authors-per-process requires --profile-only');
  }
  if (
    maxAuthorsPerProcess !== undefined
    && maxAuthorsPerProcess > MAX_PROFILE_MAX_AUTHORS_PER_PROCESS
  ) {
    throw new Error(
      '--max-authors-per-process exceeds the profile-only rollout safety bound of '
      + MAX_PROFILE_MAX_AUTHORS_PER_PROCESS,
    );
  }
  const phase = values.get('--phase') ?? 'combined';
  if (phase !== 'combined' && phase !== 'fetch' && phase !== 'project') {
    throw new Error('--phase must be combined, fetch, or project');
  }
  if (phase !== 'project' && projectionFollow) {
    throw new Error('--projection-follow requires --phase project');
  }
  if (phase !== 'project' && bulkProjectStaged) {
    throw new Error('--bulk-project-staged requires --phase project');
  }
  const indexCommitBatchSize = positiveInteger(
    values.get('--index-commit-batch-size'),
    phase === 'project' && !bulkProjectStaged
      ? DEFAULT_INCREMENTAL_PROJECTION_COMMIT_BATCH_SIZE
      : DEFAULT_INDEX_COMMIT_BATCH_SIZE,
    '--index-commit-batch-size',
  );
  if (
    phase === 'project'
    && !bulkProjectStaged
    && indexCommitBatchSize > MAX_INCREMENTAL_PROJECTION_COMMIT_BATCH_SIZE
  ) {
    throw new Error(
      '--index-commit-batch-size exceeds the incremental projection '
      + `rollout safety bound of ${MAX_INCREMENTAL_PROJECTION_COMMIT_BATCH_SIZE}`,
    );
  }
  const stagingDataDir = values.get('--staging-data-dir') || undefined;
  if (phase !== 'combined' && !stagingDataDir) {
    throw new Error('--staging-data-dir is required for fetch and project phases');
  }
  return {
    htreePath: required(values, '--htree'),
    dataDir: required(values, '--data-dir'),
    socialGraphFile: required(values, '--social-graph-file'),
    censusReportFile: required(values, '--census-report'),
    eligibleAuthorsFile: required(values, '--eligible-authors'),
    home: values.get('--home') || undefined,
    relays: normalizedRelays,
    expectedHtreeVersion: values.get('--expected-htree-version') || BROAD_ARCHIVE_HTREE_VERSION,
    authorBatchSize,
    checkpointAuthors: positiveInteger(
      values.get('--checkpoint-authors'),
      profileOnly ? DEFAULT_PROFILE_AUTHOR_BATCH_SIZE : DEFAULT_CHECKPOINT_AUTHORS,
      '--checkpoint-authors',
    ),
    maxAuthorsPerProcess,
    indexCommitBatchSize,
    btreeOrder: positiveInteger(values.get('--btree-order'), DEFAULT_BTREE_ORDER, '--btree-order'),
    btreeUpdateConcurrency: positiveInteger(
      values.get('--btree-update-concurrency'),
      DEFAULT_BTREE_UPDATE_CONCURRENCY,
      '--btree-update-concurrency',
    ),
    phase,
    stagingDataDir,
    projectionAuthors: positiveInteger(
      values.get('--projection-authors'), DEFAULT_PROJECTION_AUTHORS, '--projection-authors',
    ),
    projectionEventLimit: positiveInteger(
      values.get('--projection-event-limit'), DEFAULT_PROJECTION_EVENT_LIMIT,
      '--projection-event-limit',
    ),
    projectionFollow,
    bulkProjectStaged,
    maxLiveMiB: positiveInteger(values.get('--max-live-mib'), DEFAULT_MAX_LIVE_MIB, '--max-live-mib'),
    perAuthorEventLimit: positiveInteger(
      values.get('--per-author-event-limit'), DEFAULT_PER_AUTHOR_EVENT_LIMIT,
      '--per-author-event-limit',
    ),
    perAuthorLiveBytes,
    relayEventMaxBytes: positiveInteger(
      values.get('--relay-event-max-bytes'), DEFAULT_RELAY_EVENT_MAX_BYTES,
      '--relay-event-max-bytes',
    ),
    profileOnly,
    dryRun,
  };
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parseBroadArchiveContentArguments(process.argv.slice(2));
  await requireHtreeVersion(options.htreePath, options.expectedHtreeVersion);
  const [snapshotBytes, eligibleAuthorsText, reportJson] = await Promise.all([
    readFile(options.socialGraphFile),
    readFile(options.eligibleAuthorsFile, 'utf8'),
    readFile(options.censusReportFile, 'utf8'),
  ]);
  const report = JSON.parse(reportJson) as BroadArchiveCensusReport;
  const authors = await validateBroadArchiveCensusArtifacts(
    snapshotBytes,
    eligibleAuthorsText,
    report,
    BROAD_ARCHIVE_MIN_ELIGIBLE_AUTHORS,
  );
  const effectiveAllowlist = buildEffectiveAllowlist(
    authors,
    eligibleAuthorsText,
    options.profileOnly,
  );

  if (options.dryRun) {
    const url = `http://127.0.0.1:0/eligible/${effectiveAllowlist.sha256}`;
    printPlan(
      options,
      report,
      effectiveAllowlist.sha256,
      buildBroadArchivePhaseArguments(options, url, authors.length),
    );
    return;
  }

  const allowlist = await serveAllowlist(effectiveAllowlist.text, effectiveAllowlist.sha256);
  try {
    const args = buildBroadArchivePhaseArguments(options, allowlist.url, authors.length);
    printPlan(options, report, effectiveAllowlist.sha256, args);
    await runNativeBroadArchiveIndex(options, args);
  } finally {
    await closeServer(allowlist.server);
  }
  if (options.phase === 'fetch') {
    const state = await readCompletedStagingState(
      options.stagingDataDir!,
      authors.length,
      effectiveAllowlist.sha256,
    );
    process.stdout.write(`${JSON.stringify({
      format: 'iris-social/broad-archive-fetch-complete@1',
      authorCount: authors.length,
      crawlConfigSha256: hashCrawlConfig(options),
      socialGraphSha256: report.socialGraphSha256,
      eligibleAuthorsSha256: report.eligibleAuthorsSha256,
      effectiveAllowlistSha256: effectiveAllowlist.sha256,
      eventsSeen: state.events_seen,
      eventsSelected: state.events_selected,
      liveBytesSelected: state.live_bytes_selected,
      stagingStateFile: join(options.stagingDataDir!, 'nostr-stage', 'crawl-state.json'),
    })}\n`);
    return;
  }
  const root = await readLatestBroadArchiveRoot(options.dataDir);
  const state = await readCompletedNativeCrawlState(
    options.dataDir,
    root,
    authors.length,
    effectiveAllowlist.sha256,
  );
  process.stdout.write(`${JSON.stringify({
    format: options.profileOnly
      ? 'iris-social/profile-index-complete@1'
      : 'iris-social/broad-archive-content-complete@2',
    root,
    authorCount: authors.length,
    crawlConfigSha256: hashCrawlConfig(options),
    socialGraphSha256: report.socialGraphSha256,
    eligibleAuthorsSha256: report.eligibleAuthorsSha256,
    effectiveAllowlistSha256: effectiveAllowlist.sha256,
    eventsSeen: state.events_seen,
    eventsSelected: state.events_selected,
    liveBytesSelected: state.live_bytes_selected,
    nativeStateFile: join(options.dataDir, 'nostr-index', 'crawl-state.json'),
  })}\n`);
}

export function buildEffectiveAllowlist(
  authors: readonly string[],
  censusText: string,
  profileOnly: boolean,
): { text: string; sha256: string } {
  const text = profileOnly
    ? `${[...authors].sort().join('\n')}\n`
    : censusText;
  return {
    text,
    sha256: createHash('sha256').update(text).digest('hex'),
  };
}

export function buildBroadArchivePhaseArguments(
  options: BroadArchiveContentCliOptions,
  allowlistUrl: string,
  authorCount: number,
): string[] {
  const args = buildBroadArchiveContentArguments({
    allowlistUrl,
    authorCount,
    authorBatchSize: options.authorBatchSize,
    checkpointAuthors: options.checkpointAuthors,
    indexCommitBatchSize: options.indexCommitBatchSize,
    btreeOrder: options.btreeOrder,
    btreeUpdateConcurrency: options.btreeUpdateConcurrency,
    maxLiveMiB: options.maxLiveMiB,
    perAuthorEventLimit: options.perAuthorEventLimit,
    perAuthorLiveBytes: options.perAuthorLiveBytes,
    relayEventMaxBytes: options.relayEventMaxBytes,
    relays: options.relays,
    profileOnly: options.profileOnly,
  });
  if (options.maxAuthorsPerProcess !== undefined) {
    args.push('--max-authors-per-run', String(options.maxAuthorsPerProcess));
  }
  if (options.phase === 'fetch') {
    args.push('--stage-only', '--staging-data-dir', options.stagingDataDir!);
  } else if (options.phase === 'project') {
    args.push(
      '--project-staged',
      '--staging-data-dir', options.stagingDataDir!,
      '--projection-authors', String(options.projectionAuthors),
      '--projection-event-limit', String(options.projectionEventLimit),
    );
    if (options.projectionFollow) {args.push('--projection-follow');}
    if (options.bulkProjectStaged) {args.push('--bulk-project-staged');}
  }
  return args;
}

export function hashCrawlConfig(options: BroadArchiveContentCliOptions): string {
  const relayPageSize = 1_000;
  return createHash('sha256').update(JSON.stringify({
    format: 'iris-social/broad-archive-crawl-config@5',
    htreeVersion: options.expectedHtreeVersion,
    relays: options.relays,
    kinds: options.profileOnly ? PROFILE_FAST_LANE_KINDS : BROAD_ARCHIVE_KINDS,
    perAuthorKindEventLimit: options.profileOnly ? 1 : null,
    profileOnly: options.profileOnly,
    phase: options.phase,
    stagingDataDir: options.stagingDataDir ?? null,
    projectionAuthors: options.projectionAuthors,
    projectionEventLimit: options.projectionEventLimit,
    bulkProjectStaged: options.bulkProjectStaged,
    authorOrder: options.profileOnly ? 'pubkey-lexicographic-v1' : 'census-distance',
    fullAuthorHistory: true,
    authorBatchSize: options.authorBatchSize,
    indexCommitBatchSize: options.indexCommitBatchSize,
    btreeOrder: options.btreeOrder,
    btreeUpdateConcurrency: options.btreeUpdateConcurrency,
    concurrentBatches: 4,
    fetchTimeoutSecs: 30,
    relayPageSize,
    maxRelayPages: Math.ceil(options.perAuthorEventLimit / relayPageSize) + 1,
    maxLiveMiB: options.maxLiveMiB,
    perAuthorEventLimit: options.perAuthorEventLimit,
    perAuthorLiveBytes: options.perAuthorLiveBytes,
    relayEventMaxBytes: options.relayEventMaxBytes,
  })).digest('hex');
}

export async function readLatestBroadArchiveRoot(dataDir: string): Promise<string> {
  const raw = (await readFile(join(dataDir, 'nostr-index', 'latest-root.txt'), 'utf8')).trim();
  try {
    return nhashEncode(nhashDecode(raw));
  } catch {
    throw new Error('native broad archive crawl did not leave a canonical latest root');
  }
}

export async function readCompletedNativeCrawlState(
  dataDir: string,
  expectedRoot: string,
  expectedAuthorCount: number,
  expectedAllowlistSha256: string,
): Promise<NativeNostrCrawlState> {
  let value: unknown;
  try {
    value = JSON.parse(await readFile(
      join(dataDir, 'nostr-index', 'crawl-state.json'),
      'utf8',
    ));
  } catch {
    throw new Error('native broad archive crawl state is missing or invalid');
  }
  const state = parseNativeNostrCrawlState(value);
  if (state.next_author !== expectedAuthorCount
    || state.policy.author_count !== expectedAuthorCount) {
    throw new Error('native broad archive crawl did not complete the exact author allowlist');
  }
  if (state.root !== expectedRoot) {
    throw new Error('native broad archive crawl state does not match its final root');
  }
  if (state.policy.author_allowlist_sha256 !== expectedAllowlistSha256) {
    throw new Error('native broad archive crawl state does not match the author allowlist');
  }
  if (state.policy.require_all_relays) {
    throw new Error('native broad archive crawl still requires every configured relay');
  }
  return state;
}

async function requireHtreeVersion(path: string, expected: string): Promise<void> {
  const { stdout } = await execFile(path, ['--version'], { encoding: 'utf8' });
  const actual = stdout.trim();
  if (actual !== `htree ${expected}`) {
    throw new Error(`expected htree ${expected}, got ${actual || '<empty>'}`);
  }
}

async function serveAllowlist(text: string, sha256: string): Promise<{ server: Server; url: string }> {
  const route = `/eligible/${sha256}`;
  const server = createServer((request, response) => {
    if (request.method !== 'GET' || request.url !== route) {
      response.writeHead(404).end();
      return;
    }
    response.writeHead(200, {
      'cache-control': 'no-store',
      'content-length': Buffer.byteLength(text),
      'content-type': 'text/plain; charset=utf-8',
    });
    response.end(text);
  });
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  if (!address || typeof address === 'string') {
    await closeServer(server);
    throw new Error('failed to bind the broad archive allowlist server');
  }
  return { server, url: `http://127.0.0.1:${address.port}${route}` };
}

function printPlan(
  options: BroadArchiveContentCliOptions,
  report: BroadArchiveCensusReport,
  effectiveAllowlistSha256: string,
  args: string[],
): void {
  process.stdout.write(`${JSON.stringify({
    format: options.profileOnly
      ? 'iris-social/profile-index-run@1'
      : 'iris-social/broad-archive-content-run@3',
    dryRun: options.dryRun,
    htreeVersion: options.expectedHtreeVersion,
    dataDir: options.dataDir,
    crawlConfigSha256: hashCrawlConfig(options),
    socialGraphSha256: report.socialGraphSha256,
    eligibleAuthorsSha256: report.eligibleAuthorsSha256,
    effectiveAllowlistSha256,
    authorCount: report.selectedEligibleAuthors,
    authorBatchSize: options.authorBatchSize,
    checkpointAuthors: options.checkpointAuthors,
    maxAuthorsPerProcess: options.maxAuthorsPerProcess ?? null,
    indexCommitBatchSize: options.indexCommitBatchSize,
    btreeOrder: options.btreeOrder,
    btreeUpdateConcurrency: options.btreeUpdateConcurrency,
    phase: options.phase,
    stagingDataDir: options.stagingDataDir ?? null,
    projectionAuthors: options.projectionAuthors,
    projectionEventLimit: options.projectionEventLimit,
    projectionFollow: options.projectionFollow,
    bulkProjectStaged: options.bulkProjectStaged,
    profileOnly: options.profileOnly,
    command: [options.htreePath, ...args],
  })}\n`);
}

async function closeServer(server: Server): Promise<void> {
  if (!server.listening) {return;}
  await new Promise<void>((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {throw new Error(`Missing required broad archive argument: ${key}`);}
  return value;
}

function positiveInteger(value: string | undefined, fallback: number, name: string): number {
  if (value === undefined) {return fallback;}
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

function isDirectExecution(): boolean {
  const entry = process.argv[1];
  if (!entry) {return false;}
  try {
    return import.meta.url === new URL(`file://${entry}`).href;
  } catch {
    return false;
  }
}

if (isDirectExecution()) {
  main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Broad archive content failed: ${message}\n`);
    process.exitCode = 1;
  });
}
