#!/usr/bin/env python3
"""Generate archive graph-forward controls from a captured, clean boundary.

This command only writes a local review packet. Fleet owns the current writer,
the predecessor checks, and installation at the live archive boundary.
"""

import argparse
import hashlib
import json
import re
from pathlib import Path, PurePosixPath


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load(directory, name):
    return json.loads((directory / name).read_bytes())


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def absolute_path(value):
    require(re.fullmatch(r"/[A-Za-z0-9_./-]+", value)
            and ".." not in PurePosixPath(value).parts,
            "Expected a simple absolute production path")
    return PurePosixPath(value)


def generate(snapshot, qualification, version_dir, inbox_dir, serving_sha):
    authority, launcher, publisher, legacy, current, locations, tested, shadow_config = (
        load(snapshot, name) for name in (
            "authority.json", "launcher.json", "publisher.json", "legacy-config.json",
            "current.json", "locations.json", "tested-authority.json", "tested-config.json",
        )
    )
    authority_path = str(absolute_path(locations["authority.json"]))
    launcher_path = str(absolute_path(locations["launcher.json"]))
    unit_path = str(absolute_path(locations["collector.service"]))
    old_authority_sha = digest((snapshot / "authority.json").read_bytes())
    old_publisher_sha = digest((snapshot / "publisher.json").read_bytes())
    writer = authority["command"][0]
    require(authority["filePins"].get(writer) == serving_sha,
            "Serving writer differs from the qualified predecessor")
    require(launcher["configFile"] == locations["publisher.json"]
            and launcher["configSha256"] == old_publisher_sha
            and publisher["nativeAuthoritySha256"] == old_authority_sha
            and publisher["protectedFiles"].get(authority_path) == old_authority_sha,
            "Predecessor publication pins disagree")
    require(launcher["operationLock"] == publisher["operationLock"]
            and launcher["outboxDirectory"] == publisher["outboxDirectory"],
            "Predecessor writer or outbox differs")
    require(current["candidate"]["state"]["policy"] == publisher["expectedPolicy"],
            "Signed predecessor uses a different historical policy")
    require(set(legacy) in ({"since", "sources"}, {"graph", "since", "sources"})
            and all(legacy[key] == shadow_config[key] for key in ("since", "sources"))
            and launcher["forward"]["configSha256"] == publisher["forward"]["configSha256"]
            and launcher["forward"]["since"] == publisher["forward"]["since"] == legacy["since"],
            "The serving collector differs from the tested relay configuration")
    graph_sha = qualification["graphBinding"]["authorFileSha256"]
    new_forward_sha = qualification["forwardConfigAuthority"]
    require(graph_sha == shadow_config["graph"]["sha256"]
            and new_forward_sha == tested["authority"], "Graph qualification pins disagree")
    if "graph" in legacy:
        require(legacy["graph"]["sha256"] == graph_sha, "Preceding graph authority differs")

    old_forward = launcher["forward"]
    old_inbox = absolute_path(old_forward["stateFile"])
    require(inbox_dir != old_inbox.parent, "Graph intake needs a separate inbox directory")
    new_inbox = inbox_dir / old_inbox.name
    new_publisher_path = version_dir / "publisher-config.json"
    new_config_path = version_dir / "forward-config.json"
    checksum_path = version_dir / "collector.sha256"
    new_writer = version_dir / "htree"
    authors = version_dir / "forward-authors.tsv"
    collector = version_dir / "forward-archive-inbox.mjs"
    config_data = {**legacy, "graph": {"authorsFile": str(authors), "sha256": graph_sha}}
    if "retention" in shadow_config:
        retention = {
            "publicationFile": str(absolute_path(publisher["outboxDirectory"]) / "current.json"),
            "publisher": publisher["publisher"],
            "readEndpoint": publisher["readEndpoint"],
            "treeName": publisher["treeName"],
        }
        require(retention == shadow_config["retention"], "Replacement lookup qualification differs")
        config_data["retention"] = retention
    config = encode(config_data)
    artifact_digests = {item["name"]: item["sha256"] for item in qualification["artifacts"]}
    artifacts = {
        str(new_writer): qualification["nativeSha256"],
        str(authors): graph_sha,
        str(new_config_path): digest(config),
        **{str(version_dir / name): artifact_digests[name] for name in (
            "forward-archive-inbox.mjs", "publish-archive-checkpoint.mjs", "archive_forward_continuation.py",
        )},
    }
    checksums = "".join(f"{artifacts[str(path)]}  {path}\n" for path in (collector, new_config_path, authors)).encode()
    artifacts[str(checksum_path)] = digest(checksums)
    authority["command"][0] = str(new_writer)
    if "retention" in config_data:
        authority["environment"]["HTREE_ARCHIVE_PRIVATE_MUTE_WATERMARKS"] = "1"
    authority["binary"].update(path=str(new_writer), buildArtifactPath=qualification["nativeBuildArtifact"],
                               sourceCommit=qualification["hashtreeSource"], sha256=qualification["nativeSha256"])
    authority["filePins"].update(artifacts)
    new_authority = encode(authority)
    publisher["nativeAuthoritySha256"] = digest(new_authority)
    publisher["sourceCommit"] = qualification["irisSocialSource"]
    # The launcher checks the executable through the pinned authority. The
    # publisher's bounded file reader is for configs and smaller artifacts.
    publisher["protectedFiles"].update({authority_path: digest(new_authority), **{
        path: sha for path, sha in artifacts.items() if path != str(new_writer)
    }})
    publisher["forward"].update(configSha256=new_forward_sha, graphAuthorsSha256=graph_sha)
    if "retention" in config_data:
        publisher["forward"]["retention"] = True
    new_publisher = encode(publisher)

    module = version_dir / "archive_forward_continuation.py"
    bundle = version_dir / "publish-archive-checkpoint.mjs"
    old_collector = old_forward["collectorFile"]
    old_config_path = old_forward["configFile"]
    launcher.update(bundleFile=str(bundle), bundleSha256=artifacts[str(bundle)],
                    configFile=str(new_publisher_path), configSha256=digest(new_publisher))
    old_forward.update(collectorFile=str(collector), collectorSha256=artifacts[str(collector)],
                       configFile=str(new_config_path), configFileSha256=digest(config), configSha256=new_forward_sha,
                       graphAuthorsSha256=graph_sha, stateFile=str(new_inbox), batchDirectory=str(inbox_dir / "batches"),
                       moduleFile=str(module), moduleSha256=artifacts[str(module)])
    new_launcher = encode(launcher)

    unit = (snapshot / "collector.service").read_text()
    old_exec = f"ExecStart=/usr/bin/node {old_collector} run {old_config_path} {old_inbox}"
    new_exec = f"ExecStart=/usr/bin/node {collector} run {new_config_path} {new_inbox}"
    sha_check = "ExecStartPre=/usr/bin/sha256sum --check --status "
    replacements = {
        "ExecStart=": (old_exec, new_exec),
        "ExecStartPre=": (sha_check + str(PurePosixPath(old_collector).with_name("collector.sha256")),
                          sha_check + str(checksum_path)),
        "ReadWritePaths=": (f"ReadWritePaths={old_inbox.parent}", f"ReadWritePaths={inbox_dir}"),
        "WorkingDirectory=": (f"WorkingDirectory={PurePosixPath(old_config_path).parent}", f"WorkingDirectory={version_dir}"),
    }
    for key, (old, new) in replacements.items():
        require([line for line in unit.splitlines() if line.startswith(key)] == [old],
                f"Serving collector unit differs at {key}")
        unit = unit.replace(old + "\n", new + "\n")

    generated = {
        "authority.json": (authority_path, new_authority),
        "launcher.json": (launcher_path, new_launcher),
        "publisher-config.json": (str(new_publisher_path), new_publisher),
        "forward-config.json": (str(new_config_path), config),
        "collector.sha256": (str(checksum_path), checksums),
        "collector.service": (unit_path, unit.encode()),
    }
    plan = {
        "expectedPredecessorEventId": current["event"]["id"],
        "expectedPredecessorCheckpointSha256": current["candidate"]["checkpointSha256"],
        "expectedPredecessorFiles": {locations[name]: digest((snapshot / name).read_bytes()) for name in (
            "authority.json", "launcher.json", "publisher.json", "collector.service", "legacy-config.json",
        )},
        "generated": {name: {"destination": destination, "sha256": digest(raw)}
                      for name, (destination, raw) in generated.items()},
        "artifactPins": artifacts,
        "migrationCommand": ["/usr/bin/node", str(collector), "migrate", str(new_config_path), str(new_inbox), str(old_inbox)],
    }
    return generated, plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("qualification", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--version-dir", required=True, type=absolute_path)
    parser.add_argument("--inbox-dir", required=True, type=absolute_path)
    parser.add_argument("--serving-sha256", required=True)
    args = parser.parse_args()
    generated, plan = generate(args.snapshot, json.loads(args.qualification.read_bytes()),
                               args.version_dir, args.inbox_dir, args.serving_sha256)
    args.output.mkdir(mode=0o700, exist_ok=False)
    for name, (_, raw) in generated.items():
        with (args.output / name).open("xb") as artifact:
            artifact.write(raw)
    (args.output / "plan.json").write_bytes(encode(plan))


if __name__ == "__main__":
    main()
