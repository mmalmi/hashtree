import { readFile } from 'node:fs/promises';
import {
  HashTree,
  nhashDecode,
  nhashEncode,
  toHex,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import { RANKED_SEARCH_SEGMENT_FORMAT, RankedSearchIndex } from '@hashtree/index';
import {
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_KINDS,
  FederatedPostSearch,
  readPostSearchCatalog,
} from '../src/lib/postSearch';
import { readPostSearchCatalogFormat } from '../src/lib/postSearchCatalogFormat';
import { PostSearchV5RoutedSearch } from '../src/lib/postSearchV5RoutedSearch';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import {
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  readPostSearchV5RoutedCatalog,
} from '../src/server/postSearchV5RoutedCatalog';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MIN_DOCUMENTS = 1;
const QUERY_LIMIT = 10;
const HEX_64 = /^[0-9a-f]{64}$/;

const HELP = `Verify a complete immutable Iris Social post-search catalog (v4 or routed v6).

Required:
  --catalog-root <nhash>          Canonical immutable catalog root
  --expected-publisher <hex>     Expected pointer publisher pubkey
  --expected-source-root <nhash> Exact immutable Nostr archive snapshot root
  --store-url <http(s) URL>      Read-only-capable Hashtree daemon store API
  --store-auth-file <path>       Hashtree auth.cookie or JSON credentials
  --query <text>                 Query that must return a signed hit; repeatable

Optional:
  --min-documents <count>        Minimum visible document count; default 1
  --required-kind <kind>         Required covered kind; repeatable, defaults to all
  --timeout-ms <ms>              Per-block daemon timeout; default 30000

The verifier is read-only. It validates v4 manifests and segment descriptors,
walks every reachable hash-verified catalog block, then runs real federated
queries. It never signs, pins, publishes, or resolves a mutable Nostr ref.`;

export type PostSearchCatalogVerificationOptions = {
  catalogRoot: string;
  expectedPublisher: string;
  expectedSourceRoot: string;
  minDocuments: number;
  requiredKinds: number[];
  queries: string[];
};

export type PostSearchCatalogVerification = {
  catalogFormat: string;
  catalogRoot: string;
  sourceEventRoot: string;
  publisherId: string;
  documents: number;
  segments: number;
  coveredKinds: number[];
  dagBlocks: number;
  dagBytes: number;
  queries: Array<{
    query: string;
    matches: number;
    topEventIds: string[];
  }>;
};

type CliOptions = PostSearchCatalogVerificationOptions & {
  storeUrl: string;
  storeAuthFile: string;
  timeoutMs: number;
};

class StrictReadOnlyStore implements Store {
  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array> {
    const data = await this.source.get(hash);
    if (!data) {
      throw new Error(`Missing post-search catalog DAG block: ${toHex(hash)}`);
    }
    return data;
  }

  async has(hash: Hash): Promise<boolean> {
    await this.get(hash);
    return true;
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Post-search catalog verification is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Post-search catalog verification is read-only');
  }
}

export async function verifyPostSearchCatalog(
  options: PostSearchCatalogVerificationOptions,
  source: Store,
): Promise<PostSearchCatalogVerification> {
  const catalogRoot = parseCanonicalNhash(options.catalogRoot, 'catalog root');
  parseCanonicalNhash(options.expectedSourceRoot, 'source event root');
  const expectedPublisher = options.expectedPublisher.trim().toLowerCase();
  if (!HEX_64.test(expectedPublisher)) {
    throw new Error('Expected post-search publisher must be 64 lowercase hex characters');
  }
  if (!Number.isSafeInteger(options.minDocuments) || options.minDocuments <= 0) {
    throw new Error('Minimum post-search document count must be a positive integer');
  }
  const requiredKinds = normalizeKinds(options.requiredKinds);
  const queries = normalizeQueries(options.queries);
  const store = new StrictReadOnlyStore(source);
  const format = await readPostSearchCatalogFormat(store, catalogRoot);
  if (format === POST_SEARCH_V5_ROUTED_CATALOG_FORMAT) {
    return await verifyRoutedPostSearchCatalog({
      ...options,
      expectedPublisher,
      requiredKinds,
      queries,
    }, store, catalogRoot);
  }
  if (format !== POST_SEARCH_CATALOG_FORMAT) {
    throw new Error(`Unsupported post-search catalog format: ${format}`);
  }
  const catalog = await readPostSearchCatalog(store, catalogRoot);

  if (catalog.manifest.format !== POST_SEARCH_CATALOG_FORMAT) {
    throw new Error('Post-search candidate is not a v4 catalog');
  }
  if (catalog.manifest.publisherId !== expectedPublisher) {
    throw new Error('Post-search catalog publisher does not match the expected identity');
  }
  if (catalog.manifest.source.eventRoot !== options.expectedSourceRoot) {
    throw new Error('Post-search catalog source root does not match the immutable snapshot');
  }

  const documents = catalog.segments.reduce(
    (sum, segment) => safeAdd(sum, segment.documentCount, 'document count'),
    0,
  );
  if (documents !== catalog.manifest.source.coverage.eventCount) {
    throw new Error('Post-search catalog coverage does not match its segments');
  }
  if (documents < options.minDocuments) {
    throw new Error(`Post-search catalog contains only ${documents} documents`);
  }
  const coveredKinds = [...new Set(catalog.segments.flatMap((segment) => segment.kinds))]
    .sort((left, right) => left - right);
  const missingKinds = requiredKinds.filter((kind) => !coveredKinds.includes(kind));
  if (missingKinds.length > 0) {
    throw new Error(`Post-search catalog is missing required kinds: ${missingKinds.join(', ')}`);
  }

  const index = new RankedSearchIndex(store);
  for (const segment of catalog.segments) {
    const manifest = await index.readManifest(segment.root);
    if (
      manifest.format !== RANKED_SEARCH_SEGMENT_FORMAT
      || manifest.documentCount !== segment.documentCount
    ) {
      throw new Error(`Post-search ranked segment is inconsistent: ${segment.entry}`);
    }
  }

  const dag = await measureDag(store, catalogRoot);

  const search = new FederatedPostSearch(store);
  const queryResults = [];
  for (const query of queries) {
    const response = await search.search(
      [{ publisherId: expectedPublisher, root: catalogRoot }],
      query,
      { limit: QUERY_LIMIT },
    );
    if (response.failures.length > 0 || response.searchedPublishers !== 1) {
      throw new Error(`Post-search catalog query failed: ${JSON.stringify(query)}`);
    }
    if (response.results.length === 0) {
      throw new Error(`Post-search catalog query returned no hits: ${JSON.stringify(query)}`);
    }
    queryResults.push({
      query,
      matches: response.results.length,
      topEventIds: response.results.map((result) => result.event.id),
    });
  }

  return {
    catalogFormat: catalog.manifest.format,
    catalogRoot: nhashEncode(catalogRoot),
    sourceEventRoot: catalog.manifest.source.eventRoot,
    publisherId: catalog.manifest.publisherId,
    documents,
    segments: catalog.segments.length,
    coveredKinds,
    dagBlocks: dag.blocks,
    dagBytes: dag.bytes,
    queries: queryResults,
  };
}

async function verifyRoutedPostSearchCatalog(
  options: PostSearchCatalogVerificationOptions & {
    expectedPublisher: string;
    requiredKinds: number[];
    queries: string[];
  },
  store: Store,
  catalogRoot: CID,
): Promise<PostSearchCatalogVerification> {
  const catalog = await readPostSearchV5RoutedCatalog(store, catalogRoot, {
    maxReachableNodeCount: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  });
  if (catalog.manifest.publisherId !== options.expectedPublisher) {
    throw new Error('Post-search catalog publisher does not match the expected identity');
  }
  if (catalog.manifest.source.eventRoot !== options.expectedSourceRoot) {
    throw new Error('Post-search catalog source root does not match the immutable snapshot');
  }
  const documents = catalog.manifest.runs.reduce(
    (sum, run) => safeAdd(sum, run.documentCount, 'document count'),
    0,
  );
  if (documents !== catalog.manifest.source.coverage.eventCount
    || documents !== catalog.manifest.scoring.documentCount) {
    throw new Error('Post-search routed catalog coverage does not match its runs');
  }
  if (documents < options.minDocuments) {
    throw new Error(`Post-search catalog contains only ${documents} documents`);
  }
  const coveredKinds = [...new Set(catalog.manifest.runs.flatMap((run) => run.kinds))]
    .sort((left, right) => left - right);
  const missingKinds = options.requiredKinds.filter((kind) => !coveredKinds.includes(kind));
  if (missingKinds.length > 0) {
    throw new Error(`Post-search catalog is missing required kinds: ${missingKinds.join(', ')}`);
  }

  const search = new PostSearchV5RoutedSearch(store);
  const queryResults = [];
  for (const query of options.queries) {
    const response = await search.search(catalog, query, { limit: QUERY_LIMIT });
    if (response.results.length === 0) {
      throw new Error(`Post-search catalog query returned no hits: ${JSON.stringify(query)}`);
    }
    queryResults.push({
      query,
      matches: response.results.length,
      topEventIds: response.results.map((result) => result.event.id),
    });
  }
  const dag = await measureDag(store, catalogRoot);
  return {
    catalogFormat: catalog.manifest.format,
    catalogRoot: nhashEncode(catalogRoot),
    sourceEventRoot: catalog.manifest.source.eventRoot,
    publisherId: catalog.manifest.publisherId,
    documents,
    segments: catalog.manifest.runs.length,
    coveredKinds,
    dagBlocks: dag.blocks,
    dagBytes: dag.bytes,
    queries: queryResults,
  };
}

async function measureDag(store: Store, root: CID): Promise<{ blocks: number; bytes: number }> {
  let blocks = 0;
  let bytes = 0;
  for await (const block of new HashTree({ store }).walkBlocks(root)) {
    blocks = safeAdd(blocks, 1, 'DAG block count');
    bytes = safeAdd(bytes, block.data.byteLength, 'DAG byte count');
  }
  if (blocks === 0 || bytes === 0) {throw new Error('Post-search catalog DAG is empty');}
  return { blocks, bytes };
}

export function parsePostSearchCatalogArguments(args: string[]): CliOptions {
  const normalizedArgs = args[0] === '--' ? args.slice(1) : args;
  const singles = new Map<string, string>();
  const queries: string[] = [];
  const requiredKinds: number[] = [];
  const known = new Set([
    '--catalog-root',
    '--expected-publisher',
    '--expected-source-root',
    '--store-url',
    '--store-auth-file',
    '--query',
    '--min-documents',
    '--required-kind',
    '--timeout-ms',
  ]);

  for (let index = 0; index < normalizedArgs.length; index += 2) {
    const key = normalizedArgs[index];
    const value = normalizedArgs[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid post-search verifier argument near ${key ?? '<end>'}\n\n${HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown post-search verifier argument: ${key}`);
    }
    if (key === '--query') {
      queries.push(value);
      continue;
    }
    if (key === '--required-kind') {
      requiredKinds.push(parseNonNegativeInteger(value, '--required-kind'));
      continue;
    }
    if (singles.has(key)) {
      throw new Error(`Duplicate post-search verifier argument: ${key}`);
    }
    singles.set(key, value.trim());
  }

  const required = (key: string): string => {
    const value = singles.get(key);
    if (!value) {
      throw new Error(`Missing required post-search verifier argument: ${key}`);
    }
    return value;
  };
  if (queries.length === 0) {
    throw new Error('At least one post-search verifier query is required');
  }
  return {
    catalogRoot: required('--catalog-root'),
    expectedPublisher: required('--expected-publisher').toLowerCase(),
    expectedSourceRoot: required('--expected-source-root'),
    storeUrl: parseStoreUrl(required('--store-url')),
    storeAuthFile: required('--store-auth-file'),
    queries,
    minDocuments: singles.has('--min-documents')
      ? parsePositiveInteger(required('--min-documents'), '--min-documents')
      : DEFAULT_MIN_DOCUMENTS,
    requiredKinds: requiredKinds.length > 0 ? normalizeKinds(requiredKinds) : [...POST_SEARCH_KINDS],
    timeoutMs: singles.has('--timeout-ms')
      ? parsePositiveInteger(required('--timeout-ms'), '--timeout-ms')
      : DEFAULT_TIMEOUT_MS,
  };
}

function parseCanonicalNhash(value: string, name: string): CID {
  const trimmed = value.trim();
  try {
    const root = nhashDecode(trimmed);
    if (nhashEncode(root) !== trimmed) {
      throw new Error('non-canonical');
    }
    return root;
  } catch {
    throw new Error(`Post-search ${name} must be a canonical nhash`);
  }
}

function parseStoreUrl(value: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error('--store-url must be a valid HTTP(S) URL');
  }
  if (
    !['http:', 'https:'].includes(url.protocol)
    || url.username
    || url.password
    || url.search
    || url.hash
  ) {
    throw new Error('--store-url must be an uncredentialed HTTP(S) URL');
  }
  return url.toString().replace(/\/$/, '');
}

function normalizeQueries(values: readonly string[]): string[] {
  const queries = [...new Set(values.map((value) => value.trim()).filter(Boolean))];
  if (queries.length === 0) {
    throw new Error('At least one post-search verifier query is required');
  }
  return queries;
}

function normalizeKinds(values: readonly number[]): number[] {
  const kinds = [...new Set(values.map((value) => {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new Error('Required post-search kinds must be non-negative integers');
    }
    return value;
  }))].sort((left, right) => left - right);
  if (kinds.length === 0) {
    throw new Error('At least one required post-search kind is required');
  }
  return kinds;
}

function parsePositiveInteger(value: string, option: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${option} must be a positive integer`);
  }
  return parsed;
}

function parseNonNegativeInteger(value: string, option: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new Error(`${option} must be a non-negative integer`);
  }
  return parsed;
}

function safeAdd(left: number, right: number, name: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Invalid post-search ${name}`);
  }
  return result;
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${HELP}\n`);
    return;
  }
  const options = parsePostSearchCatalogArguments(process.argv.slice(2));
  const credentials = parseHttpBlockStoreCredentials(await readFile(options.storeAuthFile, 'utf8'));
  const verification = await verifyPostSearchCatalog(options, new HttpBlockStore(options.storeUrl, {
    credentials,
    timeoutMs: options.timeoutMs,
  }));
  process.stdout.write(`${JSON.stringify(verification)}\n`);
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`post-search verifier failed: ${message}\n`);
    process.exitCode = 1;
  });
}
