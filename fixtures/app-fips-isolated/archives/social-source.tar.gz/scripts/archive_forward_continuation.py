"""Drain bounded forward input after the existing historical publication boundary.

The caller holds its existing operation.lock. The historical continuation module
and its attempt limits remain authoritative for unfinished historical work.

Rollback: before the first forward import the original launcher/binary can be
restored. After any forward commit, keep compatible native and publication code
to finish owned pending work. Stop collection and set forward.drainEnabled=false
to disable new drains while preserving the inbox, roots and historical progress.
Do not restore an older checkpoint or assume old code can read a forward bridge.
"""
if not __debug__:
    raise RuntimeError("Forward continuation requires Python assertions")

import hashlib
import json
from pathlib import Path
import subprocess
import time

from continuation import read, durable, PUBLICATION_MAX_BYTES

MAX_FORWARD_BATCHES = 8
MAX_FORWARD_EVENTS = 256
FORWARD_ADMISSION_SECONDS = 60


def digest(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frontier(state):
    return {key: value for key, value in state.items() if key not in ("root", "coverage_head")}


class ForwardCommands:
    def __init__(self, config, authority, protect):
        self.config = config
        self.authority = authority
        self.protect = protect
        assert isinstance(config.get("drainEnabled", True), bool)
        assert digest(config["collectorFile"]) == config["collectorSha256"]
        assert digest(config["configFile"]) == config["configFileSha256"]
        self.graph = read(Path(config["configFile"]), 8192).get("graph")
        if self.graph is not None:
            assert self.graph["sha256"] == config["graphAuthorsSha256"]
            assert digest(self.graph["authorsFile"]) == self.graph["sha256"]
        index = authority["command"].index("nostr-index")
        self.native = authority["command"][:index] + ["nostr-index", "append-forward"]
        command = authority["command"]
        self.authors = command[command.index("--authors-file") + 1]
        self.floor = command[command.index("--min-free-bytes") + 1]
        self.index = Path(authority["environment"]["HTREE_DATA_DIR"]) / "nostr-index"

    def collector(self, action, *args):
        self.protect()
        assert digest(self.config["collectorFile"]) == self.config["collectorSha256"]
        assert digest(self.config["configFile"]) == self.config["configFileSha256"]
        command = ["/usr/bin/node", self.config["collectorFile"], action,
                   self.config["configFile"], self.config["stateFile"], *map(str, args)]
        result = subprocess.run(command, check=True, stdin=subprocess.DEVNULL,
                                capture_output=True, text=True, timeout=60,
                                env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
        return json.loads(result.stdout)

    def export(self):
        return self.collector("export", self.config["batchDirectory"])

    def receipt_path(self, batch):
        return self.index / "catchup-forward" / (batch["sha256"] + ".json")

    def append(self, batch):
        self.protect()
        command = self.native + [
            "--batch", batch["file"], "--batch-sha256", batch["sha256"],
            "--config-sha256", self.config["configSha256"],
            "--since", str(self.config["since"]), "--authors-file", self.authors,
            "--min-free-bytes", self.floor,
        ]
        if self.graph is not None:
            assert digest(self.graph["authorsFile"]) == self.graph["sha256"]
            command += ["--graph-authors-file", self.graph["authorsFile"],
                        "--graph-authors-sha256", self.graph["sha256"]]
        log = Path(self.config["batchDirectory"]) / ("forward-" + batch["sha256"] + ".log")
        with log.open("ab") as output:
            subprocess.run(command, check=True, stdin=subprocess.DEVNULL,
                           stdout=output, stderr=subprocess.STDOUT,
                           env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8",
                                **self.authority["environment"]})
        self.protect()
        return self.receipt_path(batch)

    def acknowledge(self, receipt):
        return self.collector("ack", receipt)


def continue_with_forward(receipts, checkpoint_file, outbox_directory, authority_sha,
                          historical, forward, publish, admit_native):
    """Finish owned recovery, or do historical work before a finite forward drain.

    Time bounds admission only: never interrupt an in-flight native commit, ack or
    signed publication. A restart recovers at most its one owned batch and returns;
    it cannot repeatedly reset the drain budget without doing historical work.
    """
    receipts, checkpoint_file, outbox = Path(receipts), Path(checkpoint_file), Path(outbox_directory)
    intent_path = receipts / "forward-batch.json"
    intent = read(intent_path)
    if intent is not None:
        result = finish_forward(receipts, checkpoint_file, outbox, authority_sha,
                                forward, publish, admit_native, intent_path, intent)
        result["drain"] = {"batches": 1, "events": batch_count(intent["batch"]), "stop": "recovered"}
        return result
    if forward.config.get("drainEnabled", True) is False:
        return {**historical(), "drain": {"batches": 0, "events": 0, "stop": "disabled"}}
    batches, events = 0, 0

    def drain(limit):
        nonlocal batches, events
        started = time.monotonic()
        result = None
        stop = "batch-limit"
        while batches < limit:
            if time.monotonic() - started >= FORWARD_ADMISSION_SECONDS:
                stop = "deadline"
                break
            if events >= MAX_FORWARD_EVENTS:
                stop = "event-limit"
                break
            state = read(checkpoint_file)
            current = read(outbox / "current.json", PUBLICATION_MAX_BYTES)
            # Native's active-author cursor is a hard dependency of its new command.
            if (read(receipts / "continuation-batch.json") is not None or
                    (checkpoint_file.parent / "catchup-append.json").exists() or
                    read(outbox / "pending.json", PUBLICATION_MAX_BYTES) is not None or
                    not current or current["candidate"]["state"] != state):
                stop = "historical-unfinished"
                break
            batch = forward.export()
            if batch.get("empty"):
                stop = "empty"
                break
            count = batch_count(batch)
            if events + count > MAX_FORWARD_EVENTS:
                stop = "event-limit"
                break
            if time.monotonic() - started >= FORWARD_ADMISSION_SECONDS:
                stop = "deadline"
                break
            admit_native()
            if time.monotonic() - started >= FORWARD_ADMISSION_SECONDS:
                stop = "deadline"
                break
            intent = {"format": "iris-social/archive-forward-intent@1",
                      "authoritySha256": authority_sha,
                      "configSha256": forward.config["configSha256"],
                      "since": forward.config["since"], "before": state, "batch": batch}
            durable(intent_path, intent)
            result = finish_forward(receipts, checkpoint_file, outbox, authority_sha,
                                    forward, publish, admit_native, intent_path, intent)
            batches += 1
            events += count
        return result, stop

    if "graphAuthorsSha256" in forward.config:
        # At a clean signed boundary, give the recent queue one turn before
        # a slow historical author. Historical work still gets its own turn.
        drain(1)
    history_result = historical()
    result, stop = drain(MAX_FORWARD_BATCHES)
    result = history_result if result is None else result
    result = {**result, "drain": {"batches": batches, "events": events, "stop": stop,
                                  "admissionSeconds": FORWARD_ADMISSION_SECONDS}}
    if batches:
        result["historical"] = history_result
    return result


def batch_count(batch):
    assert digest(batch["file"]) == batch["sha256"], "Pending forward input changed"
    payload = read(Path(batch["file"]), 4 * 1024 * 1024)
    count = len(payload["events"])
    assert 1 <= count <= 32 and batch["count"] == count, "Invalid forward batch count"
    return count


def finish_forward(receipts, checkpoint_file, outbox, authority_sha, forward,
                   publish, admit_native, intent_path, intent):

    assert intent["format"] == "iris-social/archive-forward-intent@1"
    assert intent["authoritySha256"] == authority_sha
    assert intent["configSha256"] == forward.config["configSha256"]
    assert intent["since"] == forward.config["since"]
    assert read(receipts / "continuation-batch.json") is None, "Historical intent conflicts with forward recovery"
    assert not (checkpoint_file.parent / "catchup-append.json").exists(), "Historical partial append still exists"
    batch = intent["batch"]
    batch_count(batch)
    path = forward.receipt_path(batch)
    receipt = read(path, 128 * 1024)
    state = read(checkpoint_file)
    current = read(outbox / "current.json", PUBLICATION_MAX_BYTES)
    pending = read(outbox / "pending.json", PUBLICATION_MAX_BYTES)
    if receipt is None:
        assert not pending, "Resolve signed publication before importing another batch"
        assert current and current["candidate"]["state"] == intent["before"]
        # A native pending transaction may already have advanced the checkpoint.
        # Only replaying that same batch is allowed to finish its durable receipt.
        if state != intent["before"]:
            assert (checkpoint_file.parent / "catchup-forward-pending.json").is_file()
        admit_native()
        path = forward.append(batch)
        receipt = read(path, 128 * 1024)

    assert receipt and receipt["format"] == "hashtree/nostr-index-forward-receipt@1"
    assert receipt["batchSha256"] == batch["sha256"]
    assert receipt["configSha256"] == intent["configSha256"] and receipt["since"] == intent["since"]
    assert receipt["before"] == intent["before"]
    assert frontier(receipt["before"]) == frontier(receipt["after"]), "Forward import changed historical progress"
    state = read(checkpoint_file)
    assert receipt["after"] == state, "Forward receipt is behind the checkpoint"
    assert current and current["candidate"]["state"] in (intent["before"], state)
    if pending:
        assert pending["candidate"]["state"] == state
        assert pending["candidate"]["receiptSha256"] == digest(path)
    # Native receipt is durable before inbox deletion. Repeated ack is idempotent.
    forward.acknowledge(path)
    if current["candidate"]["state"] != state or pending:
        publish(path)
    confirmed = read(outbox / "current.json", PUBLICATION_MAX_BYTES)
    assert confirmed and confirmed["candidate"]["state"] == state, "Forward publication is incomplete"
    assert read(outbox / "pending.json", PUBLICATION_MAX_BYTES) is None
    durable(intent_path, None)
    return {"action": "forward-appended-and-published", "receipt": str(path),
            "batchSha256": batch["sha256"], "nextAuthor": state["next_author"]}
