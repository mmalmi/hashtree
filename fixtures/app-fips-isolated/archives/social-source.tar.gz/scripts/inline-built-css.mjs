import { Buffer } from 'node:buffer';

function assetSourceText(asset) {
  if (typeof asset.source === 'string') {
    return asset.source;
  }
  return Buffer.from(asset.source).toString('utf8');
}

function localAssetName(href) {
  if (/^(?:[a-z]+:)?\/\//i.test(href)) {
    return null;
  }
  return href
    .replace(/^\.\//, '')
    .replace(/^\//, '')
    .split(/[?#]/, 1)[0];
}

export function inlineBuiltStyles(html, bundle) {
  const inlinedAssets = new Set();
  const output = html.replace(/<link\b[^>]*\brel=["']stylesheet["'][^>]*>/gi, (tag) => {
    const href = tag.match(/\bhref=["']([^"']+\.css(?:[?#][^"']*)?)["']/i)?.[1];
    const fileName = href ? localAssetName(href) : null;
    const asset = fileName ? bundle[fileName] : null;
    if (!asset || asset.type !== 'asset') {
      return tag;
    }

    inlinedAssets.add(fileName);
    const css = assetSourceText(asset).replace(/<\/style/gi, '<\\/style');
    return `<style data-iris-bundled-css>${css}</style>`;
  });

  return { html: output, inlinedAssets };
}

export function inlineBuiltCss() {
  return {
    name: 'iris-inline-built-css',
    enforce: 'post',
    generateBundle(_options, bundle) {
      const indexAsset = bundle['index.html'];
      if (!indexAsset || indexAsset.type !== 'asset') {
        throw new Error('Vite did not emit index.html');
      }

      const result = inlineBuiltStyles(assetSourceText(indexAsset), bundle);
      if (result.inlinedAssets.size === 0) {
        throw new Error('Vite did not link a stylesheet into index.html');
      }

      indexAsset.source = result.html;
      for (const fileName of result.inlinedAssets) {
        delete bundle[fileName];
      }
    },
  };
}
