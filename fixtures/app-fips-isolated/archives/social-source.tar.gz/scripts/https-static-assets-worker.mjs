function forwardedScheme(request) {
  const forwardedProto = request.headers.get('x-forwarded-proto');
  if (forwardedProto) return forwardedProto.toLowerCase();

  const visitor = request.headers.get('cf-visitor');
  if (!visitor) return '';
  try {
    const parsed = JSON.parse(visitor);
    return typeof parsed.scheme === 'string' ? parsed.scheme.toLowerCase() : '';
  } catch {
    return '';
  }
}

function shouldRedirectToHttps(request, url) {
  const scheme = forwardedScheme(request);
  if (request.cf && !request.cf.tlsVersion) return true;
  return scheme === 'http' || (!scheme && url.protocol === 'http:');
}

function isNostrAppRoute(pathname) {
  const [identifier, section, extra] = pathname.replace(/^\/+|\/+$/g, '').split('/');
  if (!identifier || extra) return false;
  if (/^(?:note1|nevent1|naddr1)/.test(identifier)) return !section;
  if (/^(?:npub1|nprofile1)/.test(identifier)) {
    return !section || ['replies', 'media', 'likes', 'follows', 'followers'].includes(section);
  }
  if (identifier === 'favicon.svg') return false;
  if (/^[a-z0-9_.]{3,15}$/.test(identifier)) return !section;
  return false;
}

function isFingerprintedAsset(pathname) {
  return /^\/assets\/(?:.+\/)?[^/]+-[a-z0-9_-]{8,}\.[a-z0-9]+$/i.test(pathname);
}

async function fetchAsset(request, env) {
  const response = await env.ASSETS.fetch(request);
  if (!response.ok || !isFingerprintedAsset(new URL(request.url).pathname)) {
    return response;
  }

  const cachedResponse = new Response(response.body, response);
  cachedResponse.headers.set('cache-control', 'public, max-age=31536000, immutable');
  return cachedResponse;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (shouldRedirectToHttps(request, url)) {
      url.protocol = 'https:';
      url.port = '';
      return Response.redirect(url.toString(), 308);
    }

    if (
      env.IRIS_ASSET_RELEASE_ID
      && (url.pathname === '/' || url.pathname === '/index.html' || isNostrAppRoute(url.pathname))
    ) {
      url.pathname = '/';
      url.searchParams.set('__iris_release', env.IRIS_ASSET_RELEASE_ID);
      return await fetchAsset(new Request(url, request), env);
    }

    return await fetchAsset(request, env);
  },
};
