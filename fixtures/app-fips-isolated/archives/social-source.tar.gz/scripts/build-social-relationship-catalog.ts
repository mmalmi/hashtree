import { mkdir, open, realpath, rm, stat } from 'node:fs/promises';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  nhashDecode,
  nhashEncode,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import {
  acquireExclusiveFileLock,
} from '../src/server/exclusiveFileLock';
import {
  assertPortableFilesystemStore,
  FilesystemBlockStore,
  writeJsonAtomic,
} from '../src/server/filesystemBlockStore';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import {
  readSocialRelationshipCatalog,
  SOCIAL_RELATIONSHIP_MAX_REACHABLE_NODES,
} from '../src/server/socialRelationshipCatalog';
import {
  buildSocialRelationshipCatalog,
} from '../src/server/socialRelationshipCatalogBuilder';
import { HashtreeNostrSnapshotReader } from '../src/server/postSearchSnapshotReader';
import {
  parseNativeNostrCrawlState,
  type NativeNostrCrawlState,
} from '../src/server/nativeNostrCrawlState';
import type { SocialRelationshipCatalogLookup } from '../src/lib/socialRelationshipCatalogReader';
import {
  SOCIAL_RELATIONSHIP_CLI_EVENT_FORMAT,
  SOCIAL_RELATIONSHIP_CLI_HELP,
  SOCIAL_RELATIONSHIP_HANDOFF_FORMAT,
  SOCIAL_RELATIONSHIP_MAX_ELIGIBLE_AUTHORS,
  parseSocialRelationshipEligibleAuthors,
  type ParsedSocialRelationshipEligibleAuthors,
  type SocialRelationshipCatalogCliDependencies,
  type SocialRelationshipCatalogCliOptions,
  type SocialRelationshipCatalogHandoff,
} from './social-relationship-catalog-cli-contract';
export {
  SOCIAL_RELATIONSHIP_CLI_EVENT_FORMAT,
  SOCIAL_RELATIONSHIP_HANDOFF_FORMAT,
  parseSocialRelationshipEligibleAuthors,
  type ParsedSocialRelationshipEligibleAuthors,
  type SocialRelationshipCatalogCliDependencies,
  type SocialRelationshipCatalogCliOptions,
  type SocialRelationshipCatalogHandoff,
} from './social-relationship-catalog-cli-contract';

const DEFAULT_SOURCE_TIMEOUT_MS = 30_000;
const DEFAULT_SOURCE_READ_BATCH = 16;
const DEFAULT_SORT_CHUNK_EDGES = 32_768;
const DEFAULT_MERGE_FAN_IN = 32;
const DEFAULT_WRITE_BUFFER_BYTES = 1_048_576;
const MAX_ELIGIBLE_FILE_BYTES = SOCIAL_RELATIONSHIP_MAX_ELIGIBLE_AUTHORS * 65;
const MAX_CREDENTIAL_FILE_BYTES = 65_536;
const MAX_CRAWL_STATE_BYTES = 512 * 1024;
const MAX_SORT_CHUNK_EDGES = 1_000_000;
const MAX_WRITE_BUFFER_BYTES = 64 * 1_048_576;
const MAX_GENERATED_AT_SECONDS = 10_000_000_000;
const RESERVED_SCRATCH = '.iris-social-social-relationship-scratch';
const HEX_64 = /^[0-9a-f]{64}$/;
const strictTextDecoder = new TextDecoder('utf-8', { fatal: true });

export function parseSocialRelationshipCatalogArguments(
  rawArgs: readonly string[],
): SocialRelationshipCatalogCliOptions {
  const args = rawArgs[0] === '--' ? rawArgs.slice(1) : rawArgs;
  const values = new Map<string, string>();
  const known = new Set([
    '--archive-root', '--crawl-state', '--eligible-authors',
    '--expected-eligible-authors-sha256',
    '--store-url', '--offline-store', '--store-auth-file', '--store-timeout-ms',
    '--output-file', '--max-reachable-nodes', '--verify-only', '--scratch-parent',
    '--generated-at', '--source-read-batch', '--sort-chunk-edges', '--merge-fan-in',
    '--write-buffer-bytes',
  ]);
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid social relationship argument near ${key ?? '<end>'}\n\n${SOCIAL_RELATIONSHIP_CLI_HELP}`);
    }
    if (!known.has(key)) {throw new Error(`Unknown social relationship argument: ${key}`);}
    if (values.has(key)) {throw new Error(`Duplicate social relationship argument: ${key}`);}
    values.set(key, value.trim());
  }

  const verifyOnly = values.get('--verify-only');
  const buildOnly = [
    '--scratch-parent', '--generated-at', '--source-read-batch', '--sort-chunk-edges',
    '--merge-fan-in', '--write-buffer-bytes',
  ].filter((key) => values.has(key));
  if (verifyOnly && buildOnly.length > 0) {
    throw new Error(`${buildOnly.join(', ')} are only valid in build mode`);
  }
  if (!verifyOnly) {
    required(values, '--scratch-parent');
    required(values, '--generated-at');
  }
  const storeUrlValue = values.get('--store-url');
  const offlineStoreValue = values.get('--offline-store');
  if (Boolean(storeUrlValue) === Boolean(offlineStoreValue)) {
    throw new Error('Choose exactly one of --store-url or --offline-store');
  }
  const storeAuthFile = values.get('--store-auth-file');
  const storeTimeoutMs = optionalBoundedInteger(values, '--store-timeout-ms', 1);
  if ((storeAuthFile || storeTimeoutMs !== undefined) && !storeUrlValue) {
    throw new Error('--store-auth-file and --store-timeout-ms require --store-url');
  }

  return {
    archiveRoot: canonicalImmutableNhash(required(values, '--archive-root'), '--archive-root'),
    crawlStateFile: requiredAbsolutePath(values, '--crawl-state'),
    eligibleAuthorsFile: requiredAbsolutePath(values, '--eligible-authors'),
    expectedEligibleAuthorsSha256: sha256Hex(
      required(values, '--expected-eligible-authors-sha256'),
      '--expected-eligible-authors-sha256',
    ),
    storeUrl: storeUrlValue ? storeUrl(storeUrlValue) : undefined,
    offlineStore: offlineStoreValue
      ? absolutePath(offlineStoreValue, '--offline-store')
      : undefined,
    storeAuthFile: storeAuthFile
      ? absolutePath(storeAuthFile, '--store-auth-file')
      : undefined,
    storeTimeoutMs,
    outputFile: requiredAbsolutePath(values, '--output-file'),
    maxReachableNodes: boundedInteger(
      required(values, '--max-reachable-nodes'),
      1,
      SOCIAL_RELATIONSHIP_MAX_REACHABLE_NODES,
      '--max-reachable-nodes',
    ),
    verifyOnly: verifyOnly
      ? canonicalPublicNhash(verifyOnly, '--verify-only')
      : undefined,
    scratchParent: values.has('--scratch-parent')
      ? requiredAbsolutePath(values, '--scratch-parent')
      : undefined,
    generatedAt: optionalBoundedInteger(
      values,
      '--generated-at',
      0,
      MAX_GENERATED_AT_SECONDS,
    ),
    sourceReadBatch: optionalBoundedInteger(values, '--source-read-batch', 1, 256),
    sortChunkEdges: optionalBoundedInteger(
      values,
      '--sort-chunk-edges',
      1,
      MAX_SORT_CHUNK_EDGES,
    ),
    mergeFanIn: optionalBoundedInteger(values, '--merge-fan-in', 2, 128),
    writeBufferBytes: optionalBoundedInteger(
      values,
      '--write-buffer-bytes',
      256,
      MAX_WRITE_BUFFER_BYTES,
    ),
  };
}

export async function runSocialRelationshipCatalogOperation(
  options: SocialRelationshipCatalogCliOptions,
  dependencies: SocialRelationshipCatalogCliDependencies = {},
): Promise<SocialRelationshipCatalogHandoff> {
  const emit = dependencies.emit ?? (() => undefined);
  const buildMode = !options.verifyOnly;
  const offlineDirectory = options.offlineStore
    ? await validateOfflineStorePath(options.offlineStore, buildMode)
    : undefined;
  await validateOperationPaths(options, offlineDirectory);
  // A failed retry must not leave an older successful handoff at the requested path.
  await rm(options.outputFile, { force: true });
  const eligible = parseSocialRelationshipEligibleAuthors(
    await readBoundedUtf8File(
      options.eligibleAuthorsFile,
      MAX_ELIGIBLE_FILE_BYTES,
      'eligible-author file',
    ),
    options.expectedEligibleAuthorsSha256,
  );
  const crawlState = parseNativeNostrCrawlState(JSON.parse(await readBoundedUtf8File(
    options.crawlStateFile,
    MAX_CRAWL_STATE_BYTES,
    'native crawl state',
  )));
  const archiveRoot = immutableCid(options.archiveRoot, '--archive-root');
  const publicSourceRoot = nhashEncode({ hash: new Uint8Array(archiveRoot.hash) });
  const store = dependencies.store ?? await createStore(options, offlineDirectory);
  const readOnlyStore = new StrictReadOnlyStore(store);
  emit(operationEvent(buildMode ? 'build' : 'verify', 'start', {
    sourceRoot: publicSourceRoot,
    eligibleAuthorsSha256: eligible.fileSha256,
    eligiblePubkeysSha256: eligible.eligiblePubkeysSha256,
    eligibleAuthorCount: eligible.authors.size,
    maxReachableNodes: options.maxReachableNodes,
  }));
  await validateCompletedArchive(
    readOnlyStore,
    archiveRoot,
    eligible,
    crawlState,
    options.archiveRoot,
  );
  emit(operationEvent(buildMode ? 'build' : 'verify', 'source-verified', {
    sourceRoot: publicSourceRoot,
    authorCount: crawlState.policy.author_count,
    eventsSelected: crawlState.events_selected,
  }));

  let catalog: SocialRelationshipCatalogLookup;
  if (options.verifyOnly) {
    catalog = await readSocialRelationshipCatalog(
      readOnlyStore,
      nhashDecode(options.verifyOnly),
      {
        expectedSourceRoot: archiveRoot,
        expectedEligiblePubkeysSha256: eligible.eligiblePubkeysSha256,
        eligiblePubkeys: eligible.authors,
        maxReachableNodeCount: options.maxReachableNodes,
      },
    );
  } else {
    const scratchRoot = join(options.scratchParent!, RESERVED_SCRATCH);
    const lock = await acquireExclusiveFileLock(
      scratchRoot,
      'social relationship catalog scratch',
    );
    try {
      const result = await buildSocialRelationshipCatalog({
        snapshotRoot: archiveRoot,
        snapshotReader: dependencies.snapshotReader
          ?? new HashtreeNostrSnapshotReader(
            store,
            options.sourceReadBatch ?? DEFAULT_SOURCE_READ_BATCH,
          ),
        outputStore: store,
        eligiblePubkeys: eligible.authors,
        workspaceDirectory: options.scratchParent!,
        generatedAt: options.generatedAt!,
        sortChunkEdges: options.sortChunkEdges ?? DEFAULT_SORT_CHUNK_EDGES,
        mergeFanIn: options.mergeFanIn ?? DEFAULT_MERGE_FAN_IN,
        writeBufferBytes: options.writeBufferBytes ?? DEFAULT_WRITE_BUFFER_BYTES,
        maxReachableNodeCount: options.maxReachableNodes,
      });
      catalog = await readSocialRelationshipCatalog(readOnlyStore, result.build.root, {
        expectedSourceRoot: archiveRoot,
        expectedEligiblePubkeysSha256: eligible.eligiblePubkeysSha256,
        eligiblePubkeys: eligible.authors,
        maxReachableNodeCount: options.maxReachableNodes,
      });
    } finally {
      await lock.release();
    }
  }
  const handoff = catalogHandoff(
    buildMode ? 'build' : 'verify',
    catalog,
    crawlState,
    eligible,
    options,
  );
  await writeJsonAtomic(options.outputFile, handoff);
  emit(handoff);
  return handoff;
}

async function validateCompletedArchive(
  store: Store,
  root: CID,
  eligible: ParsedSocialRelationshipEligibleAuthors,
  state: NativeNostrCrawlState,
  encodedRoot: string,
): Promise<void> {
  if (state.next_author !== state.policy.author_count || state.root === null) {
    throw new Error('Social relationship source crawl must be complete');
  }
  if (state.root !== encodedRoot) {
    throw new Error('Social relationship source root differs from native crawl state');
  }
  if (state.policy.author_count !== eligible.authors.size) {
    throw new Error('Social relationship eligible author count differs from source archive');
  }
  if (state.policy.author_allowlist_sha256 !== eligible.fileSha256) {
    throw new Error('Social relationship eligible-author digest differs from source archive');
  }
  if (!state.policy.require_all_relays) {
    throw new Error('Social relationship source crawl must require every configured relay');
  }
  await new HashtreeNostrSnapshotReader(store).validateArchiveSnapshot(root);
}

function catalogHandoff(
  operation: 'build' | 'verify',
  catalog: SocialRelationshipCatalogLookup,
  crawlState: NativeNostrCrawlState,
  eligible: ParsedSocialRelationshipEligibleAuthors,
  options: SocialRelationshipCatalogCliOptions,
): SocialRelationshipCatalogHandoff {
  const counts = { ...catalog.manifest.counts };
  return {
    format: SOCIAL_RELATIONSHIP_HANDOFF_FORMAT,
    operation,
    status: 'verified',
    catalogRoot: nhashEncode(catalog.root),
    sourceRoot: catalog.manifest.sourceRoot,
    sourceCrawlComplete: true,
    sourceAuthorCount: crawlState.policy.author_count,
    sourceEventsSeen: crawlState.events_seen,
    sourceEventsSelected: crawlState.events_selected,
    sourceLiveBytesSelected: crawlState.live_bytes_selected,
    eligibleAuthorsSha256: eligible.fileSha256,
    eligiblePubkeysSha256: eligible.eligiblePubkeysSha256,
    generatedAt: catalog.manifest.generatedAt,
    counts,
    relationshipEdges: counts.relationshipEdges,
    countEntries: counts.countEntries,
    reachableNodeCount: catalog.manifest.reachableNodeCount,
    maxReachableNodes: options.maxReachableNodes,
    buildBounds: operation === 'build' ? {
      sourceReadBatch: options.sourceReadBatch ?? DEFAULT_SOURCE_READ_BATCH,
      sortChunkEdges: options.sortChunkEdges ?? DEFAULT_SORT_CHUNK_EDGES,
      mergeFanIn: options.mergeFanIn ?? DEFAULT_MERGE_FAN_IN,
      writeBufferBytes: options.writeBufferBytes ?? DEFAULT_WRITE_BUFFER_BYTES,
    } : null,
    publicationPerformed: false,
  };
}

function operationEvent(
  operation: 'build' | 'verify',
  phase: 'start' | 'source-verified',
  details: Record<string, unknown>,
): Record<string, unknown> {
  return { format: SOCIAL_RELATIONSHIP_CLI_EVENT_FORMAT, operation, phase, ...details };
}

class StrictReadOnlyStore implements Store {
  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array | null> {
    return await this.source.get(hash);
  }

  async has(hash: Hash): Promise<boolean> {
    return await this.source.has(hash);
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Social relationship verification is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Social relationship verification is read-only');
  }
}

async function createStore(
  options: SocialRelationshipCatalogCliOptions,
  offlineDirectory?: string,
): Promise<Store> {
  if (options.storeUrl) {
    return new HttpBlockStore(options.storeUrl, {
      credentials: await loadStoreCredentials(options.storeAuthFile),
      timeoutMs: options.storeTimeoutMs ?? DEFAULT_SOURCE_TIMEOUT_MS,
    });
  }
  return new FilesystemBlockStore(offlineDirectory!);
}

async function loadStoreCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const username = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const password = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (username !== undefined || password !== undefined)) {
    throw new Error('Choose auth file or store auth environment variables, not both');
  }
  if (path) {
    try {
      return parseHttpBlockStoreCredentials(await readBoundedUtf8File(
        path,
        MAX_CREDENTIAL_FILE_BYTES,
        'credential file',
      ));
    } catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!username || !password) {
    throw new Error(
      'Daemon store requires --store-auth-file or both store auth environment variables',
    );
  }
  return { username, password };
}

async function readBoundedUtf8File(
  path: string,
  maximumBytes: number,
  label: string,
): Promise<string> {
  const file = await open(path, 'r');
  try {
    const initial = await file.stat();
    if (!initial.isFile()) {throw new Error(`Social relationship ${label} must be a file`);}
    if (initial.size > maximumBytes) {
      throw new Error(`Social relationship ${label} exceeds capacity`);
    }
    const bytes = Buffer.alloc(Math.min(maximumBytes + 1, initial.size + 1));
    let offset = 0;
    while (offset < bytes.length) {
      const result = await file.read(bytes, offset, bytes.length - offset, null);
      if (result.bytesRead === 0) {break;}
      offset += result.bytesRead;
    }
    const final = await file.stat();
    if (offset > maximumBytes) {throw new Error(`Social relationship ${label} exceeds capacity`);}
    if (final.size !== offset) {
      throw new Error(`Social relationship ${label} changed while being read`);
    }
    try {return strictTextDecoder.decode(bytes.subarray(0, offset));} catch {
      throw new Error(`Social relationship ${label} must be valid UTF-8`);
    }
  } finally {
    await file.close();
  }
}

async function validateOfflineStorePath(path: string, create: boolean): Promise<string> {
  if (resolve(path) === sep) {throw new Error('--offline-store cannot be the filesystem root');}
  if (create) {await mkdir(path, { recursive: true, mode: 0o700 });}
  let canonical: string;
  try {
    canonical = await realpath(path);
    if (!(await stat(canonical)).isDirectory()) {
      throw new Error('--offline-store must be a directory');
    }
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error('--offline-store does not exist in verify-only mode');
    }
    throw error;
  }
  await assertPortableFilesystemStore(canonical);
  return canonical;
}

async function validateOperationPaths(
  options: SocialRelationshipCatalogCliOptions,
  offlineStore: string | undefined,
): Promise<void> {
  const output = await canonicalProspectivePath(options.outputFile);
  const eligible = await canonicalProspectivePath(options.eligibleAuthorsFile);
  const crawlState = await canonicalProspectivePath(options.crawlStateFile);
  const auth = options.storeAuthFile
    ? await canonicalProspectivePath(options.storeAuthFile)
    : null;
  if (output === eligible || output === crawlState || (auth && output === auth)) {
    throw new Error('--output-file must not replace an input or credentials file');
  }
  if (offlineStore && inside(output, offlineStore)) {
    throw new Error('--output-file cannot be inside --offline-store');
  }
  if (offlineStore && inside(eligible, offlineStore)) {
    throw new Error('--eligible-authors cannot be inside --offline-store');
  }
  if (!options.verifyOnly) {
    const scratchParent = await canonicalProspectivePath(options.scratchParent!);
    if (scratchParent === sep) {
      throw new Error('--scratch-parent cannot be the filesystem root');
    }
    const scratchRoot = resolve(scratchParent, RESERVED_SCRATCH);
    if (offlineStore && overlaps(offlineStore, scratchRoot)) {
      throw new Error('--offline-store and relationship scratch must be disjoint');
    }
    for (const [label, path] of [
      ['--eligible-authors', eligible],
      ['--crawl-state', crawlState],
      ['--output-file', output],
      ['--store-auth-file', auth],
    ] as const) {
      if (path && inside(path, scratchRoot)) {
        throw new Error(`${label} cannot be inside relationship scratch`);
      }
    }
  }
  try {
    if ((await stat(output)).isDirectory()) {
      throw new Error('--output-file must not be a directory');
    }
  } catch (error) {
    if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) {throw error;}
  }
}

async function canonicalProspectivePath(path: string): Promise<string> {
  const target = resolve(path);
  try {return await realpath(target);} catch (error) {
    if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) {throw error;}
  }
  const parent = dirname(target);
  return parent === target
    ? target
    : join(await canonicalProspectivePath(parent), basename(target));
}

function overlaps(left: string, right: string): boolean {
  return inside(left, right) || inside(right, left);
}

function inside(candidate: string, directory: string): boolean {
  const path = relative(resolve(directory), resolve(candidate));
  return path === '' || (!path.startsWith(`..${sep}`) && path !== '..' && !isAbsolute(path));
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {throw new Error(`Missing required social relationship argument: ${key}`);}
  return value;
}

function requiredAbsolutePath(values: ReadonlyMap<string, string>, key: string): string {
  return absolutePath(required(values, key), key);
}

function absolutePath(value: string, key: string): string {
  if (!isAbsolute(value)) {throw new Error(`${key} must be an absolute path`);}
  return resolve(value);
}

function optionalBoundedInteger(
  values: ReadonlyMap<string, string>,
  key: string,
  minimum: number,
  maximum = Number.MAX_SAFE_INTEGER,
): number | undefined {
  return values.has(key) ? boundedInteger(required(values, key), minimum, maximum, key) : undefined;
}

function boundedInteger(raw: string, minimum: number, maximum: number, key: string): number {
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${key} must be an integer from ${minimum} through ${maximum}`);
  }
  return value;
}

function immutableCid(value: string, key: string): CID {
  try {
    const cid = nhashDecode(value);
    if (nhashEncode(cid) !== value) {
      throw new Error('noncanonical');
    }
    return cid;
  } catch {
    throw new Error(`${key} must be a canonical immutable nhash`);
  }
}

function canonicalImmutableNhash(value: string, key: string): string {
  immutableCid(value, key);
  return value;
}

function canonicalPublicNhash(value: string, key: string): string {
  const cid = immutableCid(value, key);
  if (cid.key !== undefined) {throw new Error(`${key} must be a canonical public nhash`);}
  return value;
}

function sha256Hex(value: unknown, key: string): string {
  if (typeof value !== 'string' || !HEX_64.test(value)) {
    throw new Error(`${key} must be 64 lowercase hexadecimal characters`);
  }
  return value;
}

function storeUrl(value: string): string {
  let url: URL;
  try {url = new URL(value);} catch {throw new Error('--store-url must be an HTTP(S) URL');}
  if (!['http:', 'https:'].includes(url.protocol)
    || url.username || url.password || url.search || url.hash) {
    throw new Error('--store-url must be an uncredentialed HTTP(S) URL');
  }
  return url.toString().replace(/\/$/, '');
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${SOCIAL_RELATIONSHIP_CLI_HELP}\n`);
    return;
  }
  const emit = (record: Record<string, unknown>): void => {
    process.stdout.write(`${JSON.stringify(record)}\n`);
  };
  try {
    await runSocialRelationshipCatalogOperation(
      parseSocialRelationshipCatalogArguments(process.argv.slice(2)),
      { emit },
    );
  } catch (error) {
    process.stderr.write(`${JSON.stringify({
      format: SOCIAL_RELATIONSHIP_CLI_EVENT_FORMAT,
      operation: 'unknown',
      phase: 'failed',
      error: error instanceof Error ? error.message : String(error),
    })}\n`);
    process.exitCode = 1;
  }
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === filename) {void main();}
