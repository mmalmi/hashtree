import { createHash } from 'node:crypto';
import type { Store } from '@hashtree/core';
import type { SocialRelationshipCatalogCounts } from '../src/lib/socialRelationshipCatalogReader';
import { socialRelationshipEligiblePubkeysSha256 } from '../src/server/socialRelationshipCatalog';
import type { SocialRelationshipCurrentStateReader } from '../src/server/socialRelationshipCatalogBuilder';

export const SOCIAL_RELATIONSHIP_CLI_EVENT_FORMAT =
  'iris-social/social-relationship-catalog-operation@1' as const;
export const SOCIAL_RELATIONSHIP_HANDOFF_FORMAT =
  'iris-social/social-relationship-catalog-handoff@2' as const;
export const SOCIAL_RELATIONSHIP_MAX_ELIGIBLE_AUTHORS = 500_000;
const HEX_64 = /^[0-9a-f]{64}$/;

export const SOCIAL_RELATIONSHIP_CLI_HELP = `Build or verify an authenticated Iris Social relationship catalog.

Common required:
  --archive-root <nhash>                     Exact completed native Nostr index root
  --crawl-state <absolute path>               Hashtree crawl-state.json for that root
  --eligible-authors <absolute path>         Exact frozen newline allowlist
  --expected-eligible-authors-sha256 <hex>   Independent allowlist file digest
  --output-file <absolute path>              Atomic verified handoff/report
  --max-reachable-nodes <count>              Explicit verification capacity

Store (choose exactly one):
  --store-url <http(s) URL>                   Authenticated daemon block API
  --offline-store <absolute directory>       Portable hashtree-fs source/output CAS

Build mode required:
  --scratch-parent <absolute directory>      Dedicated external-sort scratch parent
  --generated-at <unix seconds>              Exact reproducible catalog timestamp

Verify-only mode:
  --verify-only <catalog nhash>               Strictly verify an existing public catalog

Optional:
  --store-auth-file <absolute path>           auth.cookie or JSON credentials; URL only
  --store-timeout-ms <ms>                     Default 30000; URL only

Build mode optional and bounded:
  --source-read-batch <1..256>                Default 16
  --sort-chunk-edges <1..1000000>             Default 32768
  --merge-fan-in <2..128>                     Default 32
  --write-buffer-bytes <256..67108864>         Default 1048576

The source must be one ordinary NostrEventStore root from a completed native
Hashtree socialgraph crawl. Its durable state root, author count, and allowlist
digest must match the independently supplied root and canonical file. The catalog excludes an author's muted
targets and requires both endpoints to be in that allowlist.

This command never signs, pins, publishes, resolves a mutable ref, reads a Nostr
secret key, opens daemon LMDB, or changes a service. Verification wraps the CAS
as read-only. JSON progress and the final handoff never expose an archive link key.`;

export interface SocialRelationshipCatalogCliOptions {
  archiveRoot: string;
  crawlStateFile: string;
  eligibleAuthorsFile: string;
  expectedEligibleAuthorsSha256: string;
  storeUrl?: string;
  offlineStore?: string;
  storeAuthFile?: string;
  storeTimeoutMs?: number;
  outputFile: string;
  maxReachableNodes: number;
  verifyOnly?: string;
  scratchParent?: string;
  generatedAt?: number;
  sourceReadBatch?: number;
  sortChunkEdges?: number;
  mergeFanIn?: number;
  writeBufferBytes?: number;
}

export interface ParsedSocialRelationshipEligibleAuthors {
  authors: ReadonlySet<string>;
  fileSha256: string;
  eligiblePubkeysSha256: string;
}

export interface SocialRelationshipCatalogHandoff {
  [key: string]: unknown;
  format: typeof SOCIAL_RELATIONSHIP_HANDOFF_FORMAT;
  operation: 'build' | 'verify';
  status: 'verified';
  catalogRoot: string;
  sourceRoot: string;
  sourceCrawlComplete: true;
  sourceAuthorCount: number;
  sourceEventsSeen: number;
  sourceEventsSelected: number;
  sourceLiveBytesSelected: number;
  eligibleAuthorsSha256: string;
  eligiblePubkeysSha256: string;
  generatedAt: number;
  counts: SocialRelationshipCatalogCounts;
  relationshipEdges: number;
  countEntries: number;
  reachableNodeCount: number;
  maxReachableNodes: number;
  buildBounds: {
    sourceReadBatch: number;
    sortChunkEdges: number;
    mergeFanIn: number;
    writeBufferBytes: number;
  } | null;
  publicationPerformed: false;
}

export interface SocialRelationshipCatalogCliDependencies {
  store?: Store;
  snapshotReader?: SocialRelationshipCurrentStateReader;
  emit?: (record: Record<string, unknown>) => void;
}

export function parseSocialRelationshipEligibleAuthors(
  raw: string,
  rawExpectedSha256: string,
): ParsedSocialRelationshipEligibleAuthors {
  if (!HEX_64.test(rawExpectedSha256)) {
    throw new Error('expected eligible-author digest must be 64 lowercase hexadecimal characters');
  }
  if (!raw.endsWith('\n') || raw.includes('\r')) {
    throw new Error('Social relationship eligible authors must be canonical LF-terminated text');
  }
  const records = raw.slice(0, -1).split('\n');
  if (records.length === 0 || records.length > SOCIAL_RELATIONSHIP_MAX_ELIGIBLE_AUTHORS) {
    throw new Error('Social relationship eligible author count exceeds capacity');
  }
  const authors = new Set<string>();
  for (const [index, value] of records.entries()) {
    if (!value) {throw new Error(`Blank social relationship eligible author at line ${index + 1}`);}
    if (!HEX_64.test(value)) {
      throw new Error(`Invalid social relationship eligible author at line ${index + 1}`);
    }
    if (authors.has(value)) {
      throw new Error(`Duplicate social relationship eligible author at line ${index + 1}`);
    }
    authors.add(value);
  }
  const fileSha256 = createHash('sha256').update(raw).digest('hex');
  if (fileSha256 !== rawExpectedSha256) {
    throw new Error(
      `Social relationship eligible-author digest mismatch: expected ${rawExpectedSha256}, got ${fileSha256}`,
    );
  }
  return {
    authors,
    fileSha256,
    eligiblePubkeysSha256: socialRelationshipEligiblePubkeysSha256(authors),
  };
}
