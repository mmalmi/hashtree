import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifySocialGraphSnapshotArtifacts } from '../src/server/socialGraphSnapshotArtifacts';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

async function main(): Promise<void> {
  const [snapshot, frontier, provenance, generatedModule] = await Promise.all([
    readFile(resolve(root, 'public/socialGraph.bin')),
    readFile(resolve(root, 'public/socialGraphFrontier.bin')),
    readFile(resolve(root, 'public/socialGraphSnapshot.provenance.json'), 'utf8'),
    readFile(resolve(root, 'src/lib/socialGraphSnapshot.generated.ts'), 'utf8'),
  ]);
  const verified = await verifySocialGraphSnapshotArtifacts(
    snapshot,
    frontier,
    provenance,
    generatedModule,
  );
  process.stdout.write(`${JSON.stringify({
    sourceSha256: verified.source.sha256,
    sourceUsers: verified.source.reachableUsers,
    eligibleUsers: verified.source.eligibleUsers,
    snapshotSha256: verified.snapshot.sha256,
    snapshotBytes: verified.snapshot.bytes,
    snapshotUsers: verified.snapshot.users,
    frontierSha256: verified.frontier.sha256,
    frontierAuthors: verified.frontier.authors,
  })}\n`);
}

void main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`Social graph snapshot verification failed: ${message}\n`);
  process.exitCode = 1;
});
