// Rebuild public profile links from a signed archive publication and the
// app's public starter graph. Normal builds use the committed immutable output.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { HashTree, fromHex, nhashEncode, objectKeyFromHex, toHex } from '@hashtree/core';
import { BTree } from '@hashtree/index';
import { NostrEventStore, replaceableKey } from '@hashtree/nostr';
import { nip19, verifyEvent } from 'nostr-tools';

const source = new URL('../src/lib/profileArchiveHints.json', import.meta.url);
const publication = process.argv[2]
  ? JSON.parse(await readFile(process.argv[2], 'utf8'))
  : JSON.parse(await readFile(source, 'utf8')).publication;
const tag = name => publication.tags.find(([key]) => key === name)?.[1];
const owner = nip19.decode('npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0').data;
if (!verifyEvent(publication) || publication.pubkey !== owner || publication.kind !== 30064 ||
    tag('d') !== 'nostr-event-index' || tag('l') !== 'hashtree') {
  throw new Error('Invalid public archive publication');
}
const graph = JSON.parse(await readFile(new URL('../public/socialGraphSnapshot.provenance.json', import.meta.url), 'utf8'));
const frontier = await readFile(new URL('../public/socialGraphFrontier.bin', import.meta.url));
if (frontier.length !== graph.frontier.authors * 32 ||
    createHash('sha256').update(frontier).digest('hex') !== graph.frontier.sha256) {
  throw new Error('Invalid public starter graph');
}
const authors = new Set([graph.root]);
for (let offset = 0; offset < frontier.length; offset += 32) {
  authors.add(frontier.subarray(offset, offset + 32).toString('hex'));
}
const requests = new Map();
async function fetchBlock(hash) {
  const response = await fetch('https://cdn.iris.to/' + hash, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) { throw new Error('Missing archive block ' + hash); }
  const data = new Uint8Array(await response.arrayBuffer());
  if (createHash('sha256').update(data).digest('hex') !== hash) { throw new Error('Invalid archive block'); }
  return data;
}
const store = {
  get(hash) {
    const key = toHex(hash);
    if (!requests.has(key)) { requests.set(key, fetchBlock(key)); }
    return requests.get(key);
  },
};
const root = { hash: fromHex(tag('hash')), key: objectKeyFromHex(tag('key')) };
const { replaceable } = await new NostrEventStore(store).getManifest(root);
if (!replaceable) { throw new Error('The snapshot lacks a replaceable-event index'); }
const index = new BTree(store);
const tree = new HashTree({ store });
const events = new NostrEventStore(store);
const links = {};
async function collect(pubkey) {
  const cid = await index.getLink(replaceable, replaceableKey(pubkey, 0));
  if (!cid) { return; }
  const event = events.decodeEvent(await tree.readFile(cid));
  if (event.pubkey !== pubkey || event.kind !== 0 || !verifyEvent(event)) { throw new Error('Invalid profile for ' + pubkey); }
  links[pubkey] = nhashEncode(cid);
}
const sorted = [...authors].sort();
for (let offset = 0; offset < sorted.length; offset += 6) {
  await Promise.all(sorted.slice(offset, offset + 6).map(collect));
}
const sortedLinks = Object.fromEntries(sorted.filter(key => links[key]).map(key => [key, links[key]]));
await writeFile(source, JSON.stringify({ publication, links: sortedLinks }, null, 2) + '\n');
console.log('Verified signed profile links', Object.keys(links).length, 'of', authors.size);
