import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import {
  parseNativeNostrCrawlState,
  type NativeNostrCrawlState,
} from '../src/server/nativeNostrCrawlState';

type NativeBroadArchiveProcessOptions = {
  htreePath: string;
  dataDir: string;
  home?: string;
  maxAuthorsPerProcess?: number;
};

export async function runNativeBroadArchiveIndex(
  options: NativeBroadArchiveProcessOptions,
  args: readonly string[],
): Promise<void> {
  let previousNextAuthor = -1;
  while (true) {
    await runNativeProcess(options, args);
    if (options.maxAuthorsPerProcess === undefined) {
      return;
    }

    const state = await readNativeCrawlState(options.dataDir);
    if (state.next_author >= state.policy.author_count) {
      return;
    }
    if (state.next_author <= previousNextAuthor) {
      throw new Error(
        `native profile process did not advance its durable author cursor from ${previousNextAuthor}`,
      );
    }
    previousNextAuthor = state.next_author;
    process.stdout.write(`${JSON.stringify({
      format: 'iris-social/profile-index-process-recycle@1',
      nextAuthor: state.next_author,
      authorCount: state.policy.author_count,
      maxAuthorsPerProcess: options.maxAuthorsPerProcess,
    })}\n`);
  }
}

async function runNativeProcess(
  options: NativeBroadArchiveProcessOptions,
  args: readonly string[],
): Promise<void> {
  const child = spawn(options.htreePath, [...args], {
    env: {
      ...process.env,
      HTREE_DATA_DIR: options.dataDir,
      ...(options.home ? { HOME: options.home } : {}),
    },
    stdio: 'inherit',
  });
  await new Promise<void>((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(signal
          ? `native broad archive crawl exited on ${signal}`
          : `native broad archive crawl exited with status ${code ?? 1}`));
      }
    });
  });
}

async function readNativeCrawlState(dataDir: string): Promise<NativeNostrCrawlState> {
  let value: unknown;
  try {
    value = JSON.parse(await readFile(
      join(dataDir, 'nostr-index', 'crawl-state.json'),
      'utf8',
    ));
  } catch {
    throw new Error('native broad archive crawl state is missing or invalid');
  }
  return parseNativeNostrCrawlState(value);
}
