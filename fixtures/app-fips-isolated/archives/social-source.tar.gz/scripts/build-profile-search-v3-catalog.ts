import { readFile, realpath, stat } from 'node:fs/promises';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  nhashDecode,
  nhashEncode,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import {
  assertPortableFilesystemStore,
  FilesystemBlockStore,
} from '../src/server/filesystemBlockStore';
import {
  HttpBlockStore,
  parseHttpBlockStoreCredentials,
  type HttpBlockStoreCredentials,
} from '../src/server/httpBlockStore';
import {
  PROFILE_SEARCH_V3_RANK_DECISION_FORMAT,
  ProfileSearchV3CatalogBuilder,
  profileSearchV3RankDecisionsSha256,
  type ProfileSearchV3RankDecisions,
} from '../src/server/profileSearchV3CatalogBuilder';
import {
  acquireProfileSearchV3CatalogBuilderStateLock,
  FileProfileSearchV3CatalogBuilderStateStore,
  type ProfileSearchV3CatalogBuilderState,
  type ProfileSearchV3CatalogBuilderStateStore,
} from '../src/server/profileSearchV3CatalogBuilderState';
import {
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
} from '../src/server/profileSearchV3RoutedRun';
import { readProfileSearchV3Catalog } from '../src/server/profileSearchV3Catalog';
import { HashtreeNostrSnapshotReader } from '../src/server/postSearchSnapshotReader';
import {
  PROFILE_SEARCH_V3_CLI_EVENT_FORMAT,
  PROFILE_SEARCH_V3_CLI_HELP,
  PROFILE_SEARCH_V3_HANDOFF_FORMAT,
  type ProfileSearchV3CatalogCliOptions,
  type ProfileSearchV3CatalogHandoff,
  type ProfileSearchV3CliDependencies,
} from './profile-search-v3-catalog-cli-contract';
export {
  PROFILE_SEARCH_V3_CLI_EVENT_FORMAT,
  PROFILE_SEARCH_V3_HANDOFF_FORMAT,
  type ProfileSearchV3CatalogCliOptions,
  type ProfileSearchV3CatalogHandoff,
  type ProfileSearchV3CliDependencies,
} from './profile-search-v3-catalog-cli-contract';

const DEFAULT_SOURCE_TIMEOUT_MS = 30_000;
const DEFAULT_SOURCE_READ_BATCH = 16;
const HEX_64 = /^[0-9a-f]{64}$/;
const RANK_HEADER_KEYS = ['format', 'eligibleRanksSha256', 'recordCount'];
const RANK_RECORD_KEYS = ['pubkey', 'decision', 'rankHint'];

export function parseProfileSearchV3CatalogArguments(
  rawArgs: readonly string[],
): ProfileSearchV3CatalogCliOptions {
  const args = rawArgs[0] === '--' ? rawArgs.slice(1) : rawArgs;
  const values = new Map<string, string>();
  const known = new Set([
    '--source-root', '--store-url', '--offline-store', '--store-auth-file',
    '--store-timeout-ms', '--rank-decisions-file',
    '--expected-rank-decisions-sha256', '--max-reachable-nodes', '--verify-only',
    '--source-read-batch', '--state-file', '--scratch-parent', '--generated-at',
    '--sort-chunk-postings', '--profile-buffer-entries', '--profile-buffer-bytes',
    '--sort-merge-fan-in',
  ]);
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!key?.startsWith('--') || value === undefined || value.startsWith('--')) {
      throw new Error(`Invalid profile-search v3 argument near ${key ?? '<end>'}\n\n${PROFILE_SEARCH_V3_CLI_HELP}`);
    }
    if (!known.has(key)) {
      throw new Error(`Unknown profile-search v3 argument: ${key}`);
    }
    if (values.has(key)) {
      throw new Error(`Duplicate profile-search v3 argument: ${key}`);
    }
    values.set(key, value.trim());
  }

  const verifyOnly = values.get('--verify-only');
  const buildOnly = [
    '--source-read-batch', '--state-file', '--scratch-parent', '--generated-at',
    '--sort-chunk-postings', '--profile-buffer-entries', '--profile-buffer-bytes',
    '--sort-merge-fan-in',
  ].filter((key) => values.has(key));
  if (verifyOnly && buildOnly.length > 0) {
    throw new Error(`${buildOnly.join(', ')} are only valid in build mode`);
  }
  if (!verifyOnly) {
    for (const key of ['--state-file', '--scratch-parent']) {
      required(values, key);
    }
  }
  const storeUrlValue = values.get('--store-url');
  const offlineStoreValue = values.get('--offline-store');
  if (Boolean(storeUrlValue) === Boolean(offlineStoreValue)) {
    throw new Error('Choose exactly one of --store-url or --offline-store');
  }
  const storeAuthFile = values.get('--store-auth-file');
  const storeTimeoutMs = optionalBoundedInteger(values, '--store-timeout-ms', 1);
  if ((storeAuthFile || storeTimeoutMs !== undefined) && !storeUrlValue) {
    throw new Error('--store-auth-file and --store-timeout-ms require --store-url');
  }

  return {
    sourceRoot: canonicalPublicNhash(required(values, '--source-root'), '--source-root'),
    storeUrl: storeUrlValue ? storeUrl(storeUrlValue) : undefined,
    offlineStore: offlineStoreValue
      ? absolutePath(offlineStoreValue, '--offline-store')
      : undefined,
    storeAuthFile: storeAuthFile
      ? absolutePath(storeAuthFile, '--store-auth-file')
      : undefined,
    storeTimeoutMs,
    rankDecisionsFile: requiredAbsolutePath(values, '--rank-decisions-file'),
    expectedRankDecisionsSha256: sha256(
      required(values, '--expected-rank-decisions-sha256'),
      '--expected-rank-decisions-sha256',
    ),
    maxReachableNodes: boundedInteger(
      required(values, '--max-reachable-nodes'),
      1,
      PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
      '--max-reachable-nodes',
    ),
    verifyOnly: verifyOnly
      ? canonicalPublicNhash(verifyOnly, '--verify-only')
      : undefined,
    sourceReadBatch: optionalBoundedInteger(values, '--source-read-batch', 1, 1_024),
    stateFile: values.has('--state-file')
      ? requiredAbsolutePath(values, '--state-file')
      : undefined,
    scratchParent: values.has('--scratch-parent')
      ? requiredAbsolutePath(values, '--scratch-parent')
      : undefined,
    generatedAt: optionalBoundedInteger(values, '--generated-at', 0),
    sortChunkPostings: optionalBoundedInteger(values, '--sort-chunk-postings', 1),
    profileBufferEntries: optionalBoundedInteger(values, '--profile-buffer-entries', 1),
    profileBufferBytes: optionalBoundedInteger(values, '--profile-buffer-bytes', 1),
    sortMergeFanIn: optionalBoundedInteger(values, '--sort-merge-fan-in', 2, 128),
  };
}

export function parseProfileSearchV3RankDecisions(
  raw: string,
  expectedSha256: string,
): ProfileSearchV3RankDecisions {
  const expected = sha256(expectedSha256, 'expected rank-decision digest');
  if (!raw.endsWith('\n') || raw.includes('\r')) {
    throw new Error('Profile-search v3 rank decisions must be canonical LF-terminated JSONL');
  }
  const lines = raw.slice(0, -1).split('\n');
  if (lines.length < 2 || lines.some((line) => !line)) {
    throw new Error('Profile-search v3 rank decisions require one header and records');
  }
  const header = parseJsonObject(lines[0]!, 'rank-decision header');
  exactKeys(header, RANK_HEADER_KEYS, 'rank-decision header');
  if (header.format !== PROFILE_SEARCH_V3_RANK_DECISION_FORMAT
    || !Number.isSafeInteger(header.recordCount)
    || Number(header.recordCount) <= 0
    || header.recordCount !== lines.length - 1
    || JSON.stringify(header) !== lines[0]) {
    throw new Error('Invalid or noncanonical profile-search v3 rank-decision header');
  }
  const embedded = sha256(header.eligibleRanksSha256, 'embedded rank-decision digest');
  const decisions = new Map<string, number | null>();
  let previous = '';
  for (let index = 1; index < lines.length; index += 1) {
    const line = lines[index]!;
    const record = parseJsonObject(line, `rank-decision record ${index}`);
    exactKeys(record, RANK_RECORD_KEYS, `rank-decision record ${index}`);
    if (JSON.stringify(record) !== line
      || typeof record.pubkey !== 'string'
      || !HEX_64.test(record.pubkey)) {
      throw new Error(`Invalid or noncanonical profile-search v3 rank-decision record ${index}`);
    }
    if (record.pubkey === previous) {
      throw new Error(`Duplicate profile-search v3 rank decision for ${record.pubkey}`);
    }
    if (record.pubkey < previous) {
      throw new Error('Profile-search v3 rank decisions are not strictly pubkey sorted');
    }
    const rank = parseRankDecision(record, index);
    decisions.set(record.pubkey, rank);
    previous = record.pubkey;
  }
  const computed = profileSearchV3RankDecisionsSha256(decisions);
  if (embedded !== expected || computed !== expected) {
    throw new Error(
      `Profile-search v3 rank-decision digest mismatch: expected ${expected}, `
      + `embedded ${embedded}, computed ${computed}`,
    );
  }
  return decisions;
}

export async function runProfileSearchV3CatalogOperation(
  options: ProfileSearchV3CatalogCliOptions,
  dependencies: ProfileSearchV3CliDependencies = {},
): Promise<ProfileSearchV3CatalogHandoff> {
  const emit = dependencies.emit ?? (() => undefined);
  let offlineDirectory: string | undefined;
  if (options.offlineStore) {
    offlineDirectory = await validateOfflineStorePath(options.offlineStore, !options.verifyOnly);
  }
  if (!options.verifyOnly) {
    await validateBuildPaths(offlineDirectory, options.stateFile!, options.scratchParent!);
  }
  const decisions = parseProfileSearchV3RankDecisions(
    await readFile(options.rankDecisionsFile, 'utf8'),
    options.expectedRankDecisionsSha256,
  );
  const sourceRoot = nhashDecode(options.sourceRoot);
  const store = dependencies.store ?? await createStore(options, offlineDirectory);
  emit(operationEvent(options.verifyOnly ? 'verify' : 'build', 'start', {
    sourceRoot: options.sourceRoot,
    eligibleRanksSha256: options.expectedRankDecisionsSha256,
    decisionCount: decisions.size,
    maxReachableNodes: options.maxReachableNodes,
  }));

  if (options.verifyOnly) {
    const catalog = await readProfileSearchV3Catalog(
      new StrictReadOnlyStore(store),
      nhashDecode(options.verifyOnly),
      {
        expectedSourceRoot: sourceRoot,
        expectedEligibleRanksSha256: options.expectedRankDecisionsSha256,
        maxReachableNodeCount: options.maxReachableNodes,
      },
    );
    const handoff = catalogHandoff('verify', catalog, options.maxReachableNodes, null);
    emit(handoff);
    return handoff;
  }

  const stateLock = await acquireProfileSearchV3CatalogBuilderStateLock(options.stateFile!);
  let scratchLock: Awaited<ReturnType<
    typeof acquireProfileSearchV3CatalogBuilderStateLock
  >> | null = null;
  try {
    scratchLock = await acquireProfileSearchV3CatalogBuilderStateLock(join(
      options.scratchParent!,
      '.iris-social-profile-search-v3-scratch',
    ));
    const stateStore = new ReportingProfileStateStore(
      new FileProfileSearchV3CatalogBuilderStateStore(options.stateFile!),
      emit,
    );
    const result = await new ProfileSearchV3CatalogBuilder({
      snapshotRoot: sourceRoot,
      snapshotReader: dependencies.snapshotReader
        ?? new HashtreeNostrSnapshotReader(
          store,
          options.sourceReadBatch ?? DEFAULT_SOURCE_READ_BATCH,
        ),
      outputStore: store,
      stateStore,
      rankDecisions: decisions,
      workspaceDirectory: options.scratchParent!,
      generatedAt: options.generatedAt,
      sortChunkPostings: options.sortChunkPostings,
      profileBufferEntries: options.profileBufferEntries,
      profileBufferBytes: options.profileBufferBytes,
      sortMergeFanIn: options.sortMergeFanIn,
    }).build();
    const verified = await readProfileSearchV3Catalog(
      new StrictReadOnlyStore(store),
      result.catalog.root,
      {
        expectedSourceRoot: sourceRoot,
        expectedEligibleRanksSha256: options.expectedRankDecisionsSha256,
        maxReachableNodeCount: options.maxReachableNodes,
      },
    );
    const handoff = catalogHandoff('build', verified, options.maxReachableNodes, result.resumed);
    emit(handoff);
    return handoff;
  } finally {
    try {
      await scratchLock?.release();
    } finally {
      await stateLock.release();
    }
  }
}

class ReportingProfileStateStore implements ProfileSearchV3CatalogBuilderStateStore {
  constructor(
    private readonly delegate: ProfileSearchV3CatalogBuilderStateStore,
    private readonly emit: (record: Record<string, unknown>) => void,
  ) {}

  async load(): Promise<ProfileSearchV3CatalogBuilderState | null> {
    return await this.delegate.load();
  }

  async save(state: ProfileSearchV3CatalogBuilderState): Promise<void> {
    await this.delegate.save(state);
    const totals = state.completedPartitions.reduce((value, partition) => ({
      profiles: value.profiles + partition.profileCount,
      postings: value.postings + partition.postingCount,
      reachableNodes: value.reachableNodes + partition.reachableNodeCount,
    }), { profiles: 0, postings: 0, reachableNodes: 0 });
    this.emit(operationEvent('build', 'checkpoint', {
      status: state.status,
      generatedAt: state.generatedAt,
      completedPartitions: state.completedPartitions.length,
      nonEmptyRuns: state.completedPartitions.filter((partition) => partition.root).length,
      profileCount: totals.profiles,
      postingCount: totals.postings,
      reachableNodeCount: totals.reachableNodes,
      catalogRoot: state.catalogRoot,
    }));
  }
}

class StrictReadOnlyStore implements Store {
  constructor(private readonly source: Store) {}

  async get(hash: Hash): Promise<Uint8Array | null> {
    return await this.source.get(hash);
  }

  async has(hash: Hash): Promise<boolean> {
    return await this.source.has(hash);
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Profile-search v3 verification is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Profile-search v3 verification is read-only');
  }
}

function catalogHandoff(
  operation: 'build' | 'verify',
  catalog: Awaited<ReturnType<typeof readProfileSearchV3Catalog>>,
  maxReachableNodes: number,
  resumed: boolean | null,
): ProfileSearchV3CatalogHandoff {
  return {
    format: PROFILE_SEARCH_V3_HANDOFF_FORMAT,
    operation,
    status: 'verified',
    catalogRoot: nhashEncode(catalog.root),
    sourceRoot: catalog.manifest.sourceRoot,
    eligibleRanksSha256: catalog.manifest.eligibleRanksSha256,
    generatedAt: catalog.manifest.generatedAt,
    profileCount: catalog.manifest.runs.reduce((sum, run) => sum + run.profileCount, 0),
    postingCount: catalog.manifest.runs.reduce((sum, run) => sum + run.postingCount, 0),
    pageCount: catalog.manifest.runs.reduce((sum, run) => sum + run.pageCount, 0),
    runCount: catalog.manifest.runs.length,
    reachableNodeCount: catalog.manifest.reachableNodeCount,
    maxReachableNodes,
    resumed,
    publicationPerformed: false,
  };
}

function operationEvent(
  operation: 'build' | 'verify',
  phase: 'start' | 'checkpoint',
  details: Record<string, unknown>,
): Record<string, unknown> {
  return { format: PROFILE_SEARCH_V3_CLI_EVENT_FORMAT, operation, phase, ...details };
}

async function createStore(
  options: ProfileSearchV3CatalogCliOptions,
  offlineDirectory?: string,
): Promise<Store> {
  if (options.storeUrl) {
    return new HttpBlockStore(options.storeUrl, {
      credentials: await loadStoreCredentials(options.storeAuthFile),
      timeoutMs: options.storeTimeoutMs ?? DEFAULT_SOURCE_TIMEOUT_MS,
    });
  }
  return new FilesystemBlockStore(offlineDirectory!);
}

async function loadStoreCredentials(path?: string): Promise<HttpBlockStoreCredentials> {
  const username = process.env.IRIS_HASHTREE_STORE_USERNAME;
  const password = process.env.IRIS_HASHTREE_STORE_PASSWORD;
  if (path && (username !== undefined || password !== undefined)) {
    throw new Error('Choose auth file or store auth environment variables, not both');
  }
  if (path) {
    try {
      return parseHttpBlockStoreCredentials(await readFile(path, 'utf8'));
    } catch {
      throw new Error('Unable to read valid credentials from --store-auth-file');
    }
  }
  if (!username || !password) {
    throw new Error(
      'Daemon store requires --store-auth-file or both store auth environment variables',
    );
  }
  return { username, password };
}

async function validateOfflineStorePath(path: string, create: boolean): Promise<string> {
  if (resolve(path) === sep) {
    throw new Error('--offline-store cannot be the filesystem root');
  }
  if (create) {
    const { mkdir } = await import('node:fs/promises');
    await mkdir(path, { recursive: true, mode: 0o700 });
  }
  let canonical: string;
  try {
    canonical = await realpath(path);
    if (!(await stat(canonical)).isDirectory()) {
      throw new Error('--offline-store must be a directory');
    }
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error('--offline-store does not exist in verify-only mode');
    }
    throw error;
  }
  await assertPortableFilesystemStore(canonical);
  return canonical;
}

async function validateBuildPaths(
  offlineStore: string | undefined,
  stateFile: string,
  scratchParent: string,
): Promise<void> {
  const scratch = await canonicalProspectivePath(scratchParent);
  const state = await canonicalProspectivePath(stateFile);
  if (scratch === sep) {
    throw new Error('--scratch-parent cannot be the filesystem root');
  }
  if (offlineStore && overlaps(offlineStore, scratch)) {
    throw new Error('--offline-store and --scratch-parent must be disjoint');
  }
  if (offlineStore && inside(state, offlineStore)) {
    throw new Error('--state-file cannot be inside --offline-store');
  }
  if (state === resolve(scratch, '.iris-social-profile-search-v3-scratch')) {
    throw new Error('--state-file cannot replace the reserved scratch directory');
  }
  try {
    if ((await stat(state)).isDirectory()) {
      throw new Error('--state-file must not be a directory');
    }
  } catch (error) {
    if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) {
      throw error;
    }
  }
}

async function canonicalProspectivePath(path: string): Promise<string> {
  const target = resolve(path);
  try {
    return await realpath(target);
  } catch (error) {
    if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) {
      throw error;
    }
  }
  const parent = dirname(target);
  if (parent === target) {
    return target;
  }
  return join(await canonicalProspectivePath(parent), basename(target));
}

function overlaps(left: string, right: string): boolean {
  return inside(left, right) || inside(right, left);
}

function inside(candidate: string, directory: string): boolean {
  const path = relative(resolve(directory), resolve(candidate));
  return path === '' || (!path.startsWith(`..${sep}`) && path !== '..' && !isAbsolute(path));
}

function parseRankDecision(record: Record<string, unknown>, index: number): number | null {
  if (record.decision === 'excluded' && record.rankHint === null) {
    return null;
  }
  if (record.decision === 'eligible'
    && Number.isSafeInteger(record.rankHint)
    && Number(record.rankHint) >= 0) {
    return Number(record.rankHint);
  }
  throw new Error(`Invalid profile-search v3 rank-decision record ${index}`);
}

function parseJsonObject(line: string, label: string): Record<string, unknown> {
  let value: unknown;
  try {
    value = JSON.parse(line);
  } catch {
    throw new Error(`Invalid profile-search v3 ${label} JSON`);
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value as Record<string, unknown>;
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[], label: string): void {
  const actual = Object.keys(value);
  if (actual.length !== keys.length || actual.some((key, index) => key !== keys[index])) {
    throw new Error(`Invalid profile-search v3 ${label} keys`);
  }
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key);
  if (!value) {
    throw new Error(`Missing required profile-search v3 argument: ${key}`);
  }
  return value;
}

function requiredAbsolutePath(values: ReadonlyMap<string, string>, key: string): string {
  return absolutePath(required(values, key), key);
}

function absolutePath(value: string, key: string): string {
  if (!isAbsolute(value)) {
    throw new Error(`${key} must be an absolute path`);
  }
  return resolve(value);
}

function optionalBoundedInteger(
  values: ReadonlyMap<string, string>,
  key: string,
  minimum: number,
  maximum = Number.MAX_SAFE_INTEGER,
): number | undefined {
  return values.has(key) ? boundedInteger(required(values, key), minimum, maximum, key) : undefined;
}

function boundedInteger(raw: string, minimum: number, maximum: number, key: string): number {
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${key} must be an integer from ${minimum} through ${maximum}`);
  }
  return value;
}

function canonicalPublicNhash(value: string, key: string): string {
  try {
    const root: CID = nhashDecode(value);
    if (root.key !== undefined || nhashEncode(root) !== value) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error(`${key} must be a canonical public nhash`);
  }
}

function sha256(value: unknown, key: string): string {
  if (typeof value !== 'string' || !HEX_64.test(value)) {
    throw new Error(`${key} must be 64 lowercase hexadecimal characters`);
  }
  return value;
}

function storeUrl(value: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error('--store-url must be an HTTP(S) URL');
  }
  if (!['http:', 'https:'].includes(url.protocol)
    || url.username || url.password || url.search || url.hash) {
    throw new Error('--store-url must be an uncredentialed HTTP(S) URL');
  }
  return url.toString().replace(/\/$/, '');
}

async function main(): Promise<void> {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    process.stdout.write(`${PROFILE_SEARCH_V3_CLI_HELP}\n`);
    return;
  }
  const emit = (record: Record<string, unknown>): void => {
    process.stdout.write(`${JSON.stringify(record)}\n`);
  };
  try {
    await runProfileSearchV3CatalogOperation(
      parseProfileSearchV3CatalogArguments(process.argv.slice(2)),
      { emit },
    );
  } catch (error) {
    process.stderr.write(`${JSON.stringify({
      format: PROFILE_SEARCH_V3_CLI_EVENT_FORMAT,
      operation: 'unknown',
      phase: 'failed',
      error: error instanceof Error ? error.message : String(error),
    })}\n`);
    process.exitCode = 1;
  }
}

const filename = fileURLToPath(import.meta.url);
if (process.argv[1] && resolve(process.argv[1]) === filename) {
  void main();
}
