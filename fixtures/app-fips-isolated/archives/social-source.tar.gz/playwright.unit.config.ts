import { defineConfig } from '@playwright/test';
import { browserTests } from './playwright.browser-tests';

export default defineConfig({
  testDir: './tests',
  outputDir: './tmp/test-results-unit',
  testIgnore: browserTests,
  timeout: 30_000,
  workers: 4,
});
