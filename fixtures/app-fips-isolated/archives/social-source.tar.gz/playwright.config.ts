import { defineConfig, devices } from '@playwright/test';
import { browserTests } from './playwright.browser-tests';

const usePreviewServer = process.env.PLAYWRIGHT_USE_PREVIEW !== '0';
const playwrightPort = process.env.PLAYWRIGHT_PORT ?? '4180';
const baseURL = `http://127.0.0.1:${playwrightPort}`;
const navigationPerformanceTest = /navigation-performance\.spec\.ts/;
const appShellServiceWorkerTest = /app-shell-service-worker\.spec\.ts/;
// This cache/transport probe imports the source modules to inspect the running
// peer. Keep it on Vite's module server while UI checks exercise the built app.
const sourceRuntimeTest = /(?:fips-p2p|archive-engagement-ui|home-feed-stability-ui|relay-reconciliation-ui)\.spec\.ts/;
const runtimePort = process.env.PLAYWRIGHT_RUNTIME_PORT ?? `${Number(playwrightPort) + 1}`;
const runtimeBaseURL = `http://127.0.0.1:${runtimePort}`;

export default defineConfig({
  testDir: './tests',
  testMatch: browserTests,
  timeout: 30_000,
  expect: {
    timeout: 20_000,
  },
  use: {
    baseURL,
    trace: 'on-first-retry',
  },
  webServer: [{
    command: usePreviewServer
      ? `pnpm preview --host 127.0.0.1 --port ${playwrightPort}`
      : `pnpm dev --host 127.0.0.1 --port ${playwrightPort}`,
    url: baseURL,
    reuseExistingServer: !process.env.CI,
    timeout: 30_000,
  }, ...(usePreviewServer ? [{
    command: `pnpm dev --host 127.0.0.1 --port ${runtimePort} --strictPort`,
    url: runtimeBaseURL,
    reuseExistingServer: !process.env.CI,
    timeout: 30_000,
  }] : [])],
  projects: [
    {
      name: 'chromium',
      testIgnore: [navigationPerformanceTest, appShellServiceWorkerTest,
        ...(usePreviewServer ? [sourceRuntimeTest] : [])],
      use: { ...devices['Desktop Chrome'] },
    },
    ...(usePreviewServer ? [{
      name: 'source-runtime',
      testMatch: sourceRuntimeTest,
      use: { ...devices['Desktop Chrome'], baseURL: runtimeBaseURL },
    }] : []),
    {
      name: 'app-shell-service-worker',
      dependencies: ['chromium'],
      testMatch: appShellServiceWorkerTest,
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'navigation-performance',
      dependencies: ['app-shell-service-worker'],
      testMatch: navigationPerformanceTest,
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
