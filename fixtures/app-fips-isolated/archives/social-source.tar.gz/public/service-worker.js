importScripts(new URL('browser-notifications.js', self.registration.scope).href);

const CACHE_PREFIX = 'iris-social-app-shell-';
const CACHE_VERSION = 'v1';
const CORE_ASSET_CACHE = `${CACHE_PREFIX}core-${CACHE_VERSION}`;
const PREVIOUS_CORE_ASSET_CACHE = `${CACHE_PREFIX}previous-core-${CACHE_VERSION}`;
const ASSET_CACHE = `${CACHE_PREFIX}assets-${CACHE_VERSION}`;
const PAGE_CACHE = `${CACHE_PREFIX}page-${CACHE_VERSION}`;
const PAGE_FALLBACK_KEY = new URL('__offline_app_shell__', self.registration.scope).href;
const MAX_ASSET_ENTRIES = 48;
const APP_SHELL_INSTALL_TIMEOUT_MS = 15_000;
const MAX_CORE_ASSET_GRAPH_DEPTH = 8;
const NAVIGATION_NETWORK_TIMEOUT_MS = 5_000;
const HASHED_ASSET_PATTERN = /(?:^|\/)[a-z0-9][a-z0-9_.-]*-[a-z0-9_-]{8,}\.(?:css|js|mjs|wasm|woff2?)$/i;
const HASHED_ASSET_REFERENCE_PATTERN = /(?:^|[^a-z0-9_.-])((?:\.\/)?(?:assets\/)?[a-z0-9][a-z0-9_.-]*-[a-z0-9_-]{8,}\.(?:css|js|mjs|wasm|woff2?))/gi;
const SOCIAL_GRAPH_SNAPSHOT_REFERENCE_PATTERN = /(?:^|["'])((?:\.\/|\/)?socialGraph\.bin\?v=[0-9a-f]{16})(?=["'])/gi;
const SHELL_IMAGE_PATHS = new Set(['favicon.svg', 'iris-icons.svg']);
const PROFILE_SECTIONS = new Set(['replies', 'media', 'likes', 'follows', 'followers']);
let appShellUpdateQueue = Promise.resolve();
let nextAppShellUpdateSequence = 0;
let committedAppShellUpdateSequence = 0;

function scopeRelativePath(url) {
  const scopeURL = new URL(self.registration.scope);
  if (url.origin !== scopeURL.origin || !url.pathname.startsWith(scopeURL.pathname)) return null;
  return url.pathname.slice(scopeURL.pathname.length).replace(/^\/+|\/+$/g, '');
}

function isAppNavigation(request) {
  if (request.method !== 'GET' || request.mode !== 'navigate') return false;
  const path = scopeRelativePath(new URL(request.url));
  if (path === null) return false;
  if (!path || path === 'index.html') return true;

  const segments = path.split('/');
  if (segments.length > 2) return false;
  let identifier;
  try {
    identifier = decodeURIComponent(segments[0]);
  } catch {
    return false;
  }
  const section = segments[1];
  if (/^(?:note1|nevent1|naddr1)/.test(identifier)) return !section;
  if (/^(?:npub1|nprofile1)/.test(identifier)) {
    return !section || PROFILE_SECTIONS.has(section);
  }
  return !section && /^[a-z0-9_.]{3,15}$/.test(identifier);
}

function isImmutableAsset(request) {
  if (request.method !== 'GET' || request.headers.has('range')) return false;
  const url = new URL(request.url);
  const path = scopeRelativePath(url);
  if (path === null || url.search || !path.startsWith('assets/')) return false;
  if (!HASHED_ASSET_PATTERN.test(path)) return false;
  return !['document', 'image', 'audio', 'video'].includes(request.destination);
}

function isVersionedSocialGraphSnapshot(request) {
  if (request.method !== 'GET' || request.headers.has('range')) return false;
  const url = new URL(request.url);
  const path = scopeRelativePath(url);
  return path === 'socialGraph.bin'
    && /^\?v=[0-9a-f]{16}$/i.test(url.search)
    && !['document', 'image', 'audio', 'video'].includes(request.destination);
}

function isShellImage(request) {
  if (request.method !== 'GET' || request.headers.has('range')) return false;
  const url = new URL(request.url);
  return !url.search && SHELL_IMAGE_PATHS.has(scopeRelativePath(url));
}

function isSafeResponse(response) {
  return response.ok
    && response.status === 200
    && response.type !== 'error'
    && response.type !== 'opaque'
    && !response.redirected
    && !/\b(?:no-store|private)\b/i.test(response.headers.get('cache-control') ?? '');
}

function hasExpectedAssetType(response, url) {
  const contentType = response.headers.get('content-type')?.toLowerCase() ?? '';
  const pathname = new URL(url).pathname;
  const extension = pathname.split('.').pop()?.toLowerCase();
  if (SHELL_IMAGE_PATHS.has(scopeRelativePath(new URL(url)))) {
    return contentType.startsWith('image/svg+xml');
  }
  if (pathname.endsWith('/socialGraph.bin')) {
    return contentType.startsWith('application/octet-stream');
  }
  if (extension === 'css') return contentType.startsWith('text/css');
  if (extension === 'wasm') return contentType.startsWith('application/wasm');
  if (extension === 'woff' || extension === 'woff2') {
    return contentType.startsWith('font/') || contentType.includes('font-woff');
  }
  return contentType.includes('javascript') || contentType.includes('ecmascript');
}

function isSafeAppShellResponse(response) {
  if (!isSafeResponse(response)) return false;
  return response.headers.get('content-type')?.toLowerCase().startsWith('text/html') ?? false;
}

function isUsableNavigationResponse(response) {
  return response.ok
    && response.status === 200
    && response.type !== 'error'
    && response.type !== 'opaque'
    && (response.headers.get('content-type')?.toLowerCase().startsWith('text/html') ?? false);
}

async function trimAssetCache(cache) {
  const keys = await cache.keys();
  const overflow = keys.length - MAX_ASSET_ENTRIES;
  if (overflow <= 0) return;
  await Promise.all(keys.slice(0, overflow).map((request) => cache.delete(request)));
}

async function storeAsset(request, response) {
  if (!isSafeResponse(response) || !hasExpectedAssetType(response, request.url)) return;
  const cache = await caches.open(ASSET_CACHE);
  await cache.put(request, response);
  await trimAssetCache(cache);
}

async function touchRuntimeAsset(request, response) {
  const cache = await caches.open(ASSET_CACHE);
  await cache.delete(request);
  await cache.put(request, response);
  await trimAssetCache(cache);
}

async function cacheFirstAsset(request, event) {
  // Core assets are warmed with URL-only requests. Use the same key so Vary:
  // Origin cannot turn a precached immutable module into an offline miss.
  const core = await caches.match(request.url, { cacheName: CORE_ASSET_CACHE });
  if (core) return core;
  const previousCore = await caches.match(request.url, { cacheName: PREVIOUS_CORE_ASSET_CACHE });
  if (previousCore) return previousCore;
  const cached = await caches.match(request, { cacheName: ASSET_CACHE });
  if (cached) {
    event.waitUntil(touchRuntimeAsset(request, cached.clone()));
    return cached;
  }

  const response = await fetch(request);
  if (isSafeResponse(response) && hasExpectedAssetType(response, request.url)) {
    event.waitUntil(storeAsset(request, response.clone()));
  }
  return response;
}

async function storeAppShell(response) {
  if (!isSafeAppShellResponse(response)) return;
  const cache = await caches.open(PAGE_CACHE);
  await cache.put(PAGE_FALLBACK_KEY, response);
}

function referencedAssetUrls(source, baseURL) {
  const urls = new Set();
  for (const match of source.matchAll(HASHED_ASSET_REFERENCE_PATTERN)) {
    try {
      const url = new URL(match[1], baseURL);
      const request = new Request(url.href);
      if (isImmutableAsset(request)) urls.add(url.href);
    } catch {
      // Ignore strings that merely resemble an asset reference.
    }
  }
  for (const match of source.matchAll(SOCIAL_GRAPH_SNAPSHOT_REFERENCE_PATTERN)) {
    try {
      const url = new URL(match[1], baseURL);
      const request = new Request(url.href);
      if (isVersionedSocialGraphSnapshot(request)) urls.add(url.href);
    } catch {
      // Ignore malformed strings that resemble the generated snapshot URL.
    }
  }
  return urls;
}

function isHashtreeWorkerAsset(url) {
  return /\/hashtree\.worker-[a-z0-9_-]{8,}\.js$/i.test(new URL(url).pathname);
}

function isResidentWorkerGraphEntry(url) {
  const path = new URL(url).pathname;
  return isHashtreeWorkerAsset(url)
    || /\/workerClient-[a-z0-9_-]{8,}\.js$/i.test(path);
}

async function cacheReferencedAssets(source, baseURL, signal) {
  const assets = [];
  const seen = new Set();
  let complete = true;
  let foundWorker = false;
  let pending = [
    ...referencedAssetUrls(source, baseURL),
    ...[...SHELL_IMAGE_PATHS].map((name) => new URL(name, self.registration.scope).href),
  ].map((url) => ({
    followWorkerGraph: false,
    url,
  }));

  // Cache the document entry and the resident data worker graph. Other UI
  // chunks remain genuinely lazy and are cached after their first real use.
  for (
    let depth = 0;
    depth < MAX_CORE_ASSET_GRAPH_DEPTH && pending.length > 0;
    depth += 1
  ) {
    const current = pending.filter(({ url }) => !seen.has(url));
    current.forEach(({ url }) => seen.add(url));
    const discovered = await Promise.all(current.map(async ({ followWorkerGraph, url }) => {
      try {
        const request = new Request(url);
        const response = await fetch(request, { signal });
        if (!isSafeResponse(response) || !hasExpectedAssetType(response, url)) {
          complete = false;
          return [];
        }
        if (isHashtreeWorkerAsset(url)) foundWorker = true;
        const nested = /\.(?:js|mjs)$/i.test(new URL(url).pathname)
          ? referencedAssetUrls(await response.clone().text(), url)
          : new Set();
        assets.push({ request, response });
        return [...nested]
          .filter((nestedUrl) => followWorkerGraph || isResidentWorkerGraphEntry(nestedUrl))
          .map((nestedUrl) => ({
            followWorkerGraph: followWorkerGraph || isHashtreeWorkerAsset(nestedUrl),
            url: nestedUrl,
          }));
      } catch {
        complete = false;
        return [];
      }
    }));
    pending = discovered.flat().filter(({ url }) => !seen.has(url));
  }
  if (pending.length > 0) complete = false;
  if (!complete || seen.size === 0 || !foundWorker) return null;
  return { assets, urls: seen };
}

async function commitCoreAssets(assets) {
  const cache = await caches.open(CORE_ASSET_CACHE);
  for (const { request, response } of assets) {
    await cache.put(request, response);
  }
  return cache;
}

async function removeSupersededCoreAssets(cache, currentUrls) {
  const keys = await cache.keys();
  await Promise.all(keys.map((request) => (
    currentUrls.has(request.url) ? false : cache.delete(request)
  )));
}

async function retainPreviousCoreAssets(nextUrls) {
  const current = await caches.open(CORE_ASSET_CACHE);
  const currentRequests = await current.keys();
  if (
    currentRequests.length === 0
    || (currentRequests.length === nextUrls.size
      && currentRequests.every((request) => nextUrls.has(request.url)))
  ) return;

  // A warm navigation is mounting the previous shell while its replacement
  // downloads. Keep that whole graph available, even after the new shell is
  // committed. Retain only one previous generation, and do not rotate it on
  // unchanged revalidations.
  const previous = await caches.open(PREVIOUS_CORE_ASSET_CACHE);
  for (const request of currentRequests) {
    const response = await current.match(request);
    if (response) await previous.put(request, response);
  }
  await removeSupersededCoreAssets(previous, new Set(currentRequests.map(({ url }) => url)));
}

async function updateAppShellOnce(response, signal) {
  if (!isSafeAppShellResponse(response)) return false;
  const shellSource = await response.clone().text();
  const cachedAssets = await cacheReferencedAssets(
    shellSource,
    self.registration.scope,
    signal,
  );
  if (!cachedAssets) return false;
  await retainPreviousCoreAssets(cachedAssets.urls);
  const coreCache = await commitCoreAssets(cachedAssets.assets);
  await storeAppShell(response.clone());
  await removeSupersededCoreAssets(coreCache, cachedAssets.urls);
  return true;
}

function enqueueAppShellUpdate(responsePromise, signal, sequence = ++nextAppShellUpdateSequence) {
  const pending = appShellUpdateQueue.then(async () => {
    const response = await responsePromise;
    if (!response || sequence < committedAppShellUpdateSequence) return;
    if (await updateAppShellOnce(response, signal)) {
      committedAppShellUpdateSequence = sequence;
    }
  });
  appShellUpdateQueue = pending.catch(() => undefined);
  return pending;
}

function updateAppShell(response, signal) {
  return enqueueAppShellUpdate(Promise.resolve(response.clone()), signal);
}

async function warmAppShell() {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), APP_SHELL_INSTALL_TIMEOUT_MS);
  try {
    const response = await fetch(self.registration.scope, {
      cache: 'no-store',
      signal: controller.signal,
    });
    await updateAppShell(response, controller.signal);
  } catch {
    // A later successful navigation will populate the same real app shell.
  } finally {
    clearTimeout(timeoutId);
  }
}

async function cacheFirstNavigation(request, event) {
  const sequence = ++nextAppShellUpdateSequence;
  const networkController = new AbortController();
  const networkTimeout = setTimeout(
    () => networkController.abort(),
    NAVIGATION_NETWORK_TIMEOUT_MS,
  );
  const networkResult = fetch(request, {
    cache: 'no-store',
    signal: networkController.signal,
  }).then(
    (response) => ({ response, updateResponse: response.clone() }),
    () => ({ response: null, updateResponse: null }),
  ).finally(() => clearTimeout(networkTimeout));
  const updateController = new AbortController();
  const updateTimeout = setTimeout(
    () => updateController.abort(),
    APP_SHELL_INSTALL_TIMEOUT_MS,
  );
  // Queue before awaiting the network so idle observers also wait for a
  // pending revalidation, including one started by an instant cached visit.
  event.waitUntil(enqueueAppShellUpdate(
    networkResult.then(({ updateResponse }) => updateResponse),
    updateController.signal,
    sequence,
  ).catch(() => undefined).finally(() => clearTimeout(updateTimeout)));

  const cached = await caches.match(PAGE_FALLBACK_KEY, { cacheName: PAGE_CACHE });
  if (cached) return cached;

  const { response } = await networkResult;
  if (response && isUsableNavigationResponse(response)) {
    return response;
  }

  // Installation or another tab may have completed a shell while this first
  // navigation was waiting for its network response.
  const fallback = await caches.match(PAGE_FALLBACK_KEY, { cacheName: PAGE_CACHE });
  if (fallback) return fallback;
  return response ?? Response.error();
}

async function activateLatestWorker() {
  const cacheNames = await caches.keys();
  await Promise.all(cacheNames.map((cacheName) => (
    cacheName.startsWith(CACHE_PREFIX)
      && cacheName !== ASSET_CACHE
      && cacheName !== CORE_ASSET_CACHE
      && cacheName !== PREVIOUS_CORE_ASSET_CACHE
      && cacheName !== PAGE_CACHE
      ? caches.delete(cacheName)
      : Promise.resolve(false)
  )));
  const assetCache = await caches.open(ASSET_CACHE);
  await trimAssetCache(assetCache);
  await clients.claim();
}

self.addEventListener('install', (event) => {
  event.waitUntil(Promise.all([warmAppShell(), self.skipWaiting()]));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(activateLatestWorker());
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    event.waitUntil(self.skipWaiting());
    return;
  }
  if (event.data?.type === 'WAIT_FOR_APP_SHELL_IDLE') {
    event.waitUntil(appShellUpdateQueue.then(() => {
      event.ports[0]?.postMessage({ type: 'APP_SHELL_IDLE' });
    }));
  }
});

self.addEventListener('fetch', (event) => {
  if (isAppNavigation(event.request)) {
    event.respondWith(cacheFirstNavigation(event.request, event));
    return;
  }
  if (isImmutableAsset(event.request) || isShellImage(event.request)) {
    event.respondWith(cacheFirstAsset(event.request, event));
    return;
  }
  if (isVersionedSocialGraphSnapshot(event.request)) {
    event.respondWith(cacheFirstAsset(event.request, event));
  }
});
