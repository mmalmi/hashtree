// Background notifications share no account secrets with the service worker.
const PUSH_CACHE_NAME = 'iris-social-notifications-v1';
const PUSH_POLICY_URL = new URL('__notification_policy__', self.registration.scope).href;
const PUSH_EVENT_PREFIX = new URL('__notification_event__/', self.registration.scope).href;
const PUBLIC_PUSH_KINDS = new Set([1, 6, 7, 9735]);
const HEX_EVENT_ID = /^[0-9a-f]{64}$/;

async function readPushPolicy() {
  const response = await (await caches.open(PUSH_CACHE_NAME)).match(PUSH_POLICY_URL);
  return response ? await response.json() : null;
}
function admittedPushEvent(data, policy) {
  const event = data?.event;
  return policy?.enabled && HEX_EVENT_ID.test(policy.pubkey)
    && event && HEX_EVENT_ID.test(event.id) && HEX_EVENT_ID.test(event.pubkey)
    && event.pubkey !== policy.pubkey && PUBLIC_PUSH_KINDS.has(event.kind)
    && Array.isArray(policy.kinds) && policy.kinds.includes(event.kind)
    && typeof event.content === 'string' && event.content.length <= 65_536
    && typeof event.sig === 'string' && /^[0-9a-f]{128}$/.test(event.sig)
    && Array.isArray(event.tags) && event.tags.length <= 2_000
    && event.tags.every(tag => Array.isArray(tag) && tag.every(value => typeof value === 'string'))
    && event.tags.some(tag => tag[0] === 'p' && tag[1] === policy.pubkey) ? event : null;
}
function pushReplyParentId(event) {
  if (event.kind !== 1) return null;
  const marker = tag => (tag[3] ?? '').trim().toLowerCase();
  const refs = event.tags.filter(tag => tag[0] === 'e' && HEX_EVENT_ID.test(tag[1]) && ['', 'root', 'reply'].includes(marker(tag)));
  return (refs.find(tag => marker(tag) === 'reply') ?? refs.at(-1))?.[1] ?? null;
}
function pushHref(event) {
  const target = event.kind === 1 ? event.id : event.tags.filter(tag => tag[0] === 'e').at(-1)?.[1];
  return new URL(HEX_EVENT_ID.test(target ?? '') ? `#/thread/${target}` : '#/notifications', self.registration.scope).href;
}

self.addEventListener('push', event => {
  event.waitUntil((async () => {
    let data;
    try { data = event.data?.json(); } catch { return; }
    const policy = await readPushPolicy();
    const note = admittedPushEvent(data, policy);
    if (!note) {
      const details = data?.event;
      if (!policy?.enabled || !HEX_EVENT_ID.test(policy.pubkey)
        || !HEX_EVENT_ID.test(details?.id ?? '') || !HEX_EVENT_ID.test(details?.author ?? '')
        || !PUBLIC_PUSH_KINDS.has(details?.kind) || !policy.kinds?.includes(details.kind)
        || details.pubkey !== undefined || details.sig !== undefined || details.tags !== undefined
        || details.content !== undefined) return;
      // The service's >4KiB Details envelope has no recipient or signature.
      // Never attribute it to this account, reveal its preview, use its event
      // target or admit it to the event cache. A generic alert stays useful
      // while an old endpoint delivery can disclose no prior-account content.
      await self.registration.showNotification('New activity on Iris', {
        body: 'Open Iris to check notifications.',
        icon: new URL('favicon.png', self.registration.scope).href,
        tag: `iris-activity-${policy.pubkey}`,
        data: { url: new URL('#/notifications', self.registration.scope).href, pubkey: policy.pubkey },
      });
      return;
    }
    const cache = await caches.open(PUSH_CACHE_NAME);
    // A bounded inbox lets a cold app verify and admit the pushed event before
    // rendering its destination, without relying on a second server delivery.
    await cache.put(`${PUSH_EVENT_PREFIX}${note.id}`, Response.json(note));
    const pending = (await cache.keys()).filter(request => request.url.startsWith(PUSH_EVENT_PREFIX));
    await Promise.all(pending.slice(0, Math.max(0, pending.length - 32)).map(request => cache.delete(request)));
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const titles = { 1: 'New reply or mention', 6: 'New repost', 7: 'New reaction', 9735: 'New zap' };
    await self.registration.showNotification(titles[note.kind], {
      body: policy.previews && typeof data.body === 'string' ? data.body.slice(0, 240) : 'Open Iris to view it.',
      icon: new URL('favicon.png', self.registration.scope).href,
      tag: `iris-${policy.pubkey}-${note.id}`,
      data: { url: pushHref(note), pubkey: policy.pubkey, parentId: pushReplyParentId(note) },
    }).finally(() => {
      // The visible thread can now dismiss the alert that was just shown.
      clients.forEach(client => client.postMessage({ type: 'IRIS_PUSH_RECEIVED' }));
    });
  })().catch(() => undefined));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil((async () => {
    const policy = await readPushPolicy();
    const data = event.notification.data;
    if (!policy?.enabled || data?.pubkey !== policy.pubkey) return;
    const fallback = new URL('#/notifications', self.registration.scope);
    let destination = fallback;
    try {
      const candidate = new URL(data.url, self.registration.scope);
      if (candidate.origin === fallback.origin && candidate.pathname === fallback.pathname
        && /^#\/(?:notifications|thread\/[0-9a-f]{64})$/.test(candidate.hash)) destination = candidate;
    } catch { /* Invalid and external URLs stay inside notifications. */ }
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const client = clients.find(item => new URL(item.url).origin === destination.origin);
    if (client) {
      const navigated = await client.navigate(destination.href);
      if (navigated) { await navigated.focus(); return; }
    }
    await self.clients.openWindow(destination.href);
  })().catch(() => undefined));
});
