# Iris Client Feature Checklist

Based on a local scan of `~/src/iris-client`:

- Feed sources: `src/shared/components/feed/*`, `src/pages/home/feed/components/HomeFeed.tsx`, `tests/for-you-feed.spec.ts`
- Profile sources: `tests/view-profile.spec.ts`, `tests/profile-follows-list.spec.ts`, `tests/profile-search.spec.ts`, `tests/profile-qr.spec.ts`, `tests/profile-dropdown.spec.ts`
- Thread sources: `src/pages/thread/index.tsx`, `tests/thread-view.spec.ts`, `tests/reply-post.spec.ts`
- Reaction sources: `src/shared/components/event/reactions/*`, `tests/like-post.spec.ts`, `tests/repost.spec.ts`
- Media sources: `src/shared/components/embed/media/*`, `src/shared/components/media/MediaModal.tsx`

Legend:

- `[x]` clearly present in `iris-social`
- `[ ]` present in `iris-client`, but not yet in `iris-social` or not clearly implemented

## Feed

- [x] Home/latest feed
- [x] Follows-based feed loading
- [x] Feed cards with author, timestamp, text, and engagement pills
- [x] Create post from the main feed
- [x] Optimistic post insertion
- [x] Load more / pagination button
- [x] Mentions rendered in note text
- [x] Hashtags rendered in note text
- [x] Custom emoji rendered in note text
- [x] External links rendered in note text
- [x] Inline media embeds inside feed items
- [x] For-you / algorithmic feed
- [x] Notifications feed
- [x] Feed tabs / feed switching UI
- [x] New events button / live refresh affordance
- [x] Media-only feed
- [x] Feed editor / custom relay-feed definitions
- [x] Display-as selector / alternate feed layouts

## Profile

- [x] Profile route by `npub`
- [x] Profile hero with avatar, banner, display name, and bio
- [x] Posts tab
- [x] Replies tab with NIP-10/NIP-22 reply classification and quote preservation
- [x] Media tab limited to authored posts/replies with supported embeds
- [x] Follows tab
- [x] Followers tab
- [x] Open another user's follows/followers without following them first
- [x] Open profiles from feed author rows
- [x] Open profiles from mentions
- [x] Personal nostr index lookup in addition to the main index when viewing a profile
- [x] Profile search
- [x] Profile QR
- [x] Profile dropdown / action menu
- [x] Follow / unfollow controls
- [x] Edit own profile metadata with offline persistence and retry
- [x] Rich profile actions beyond viewing

## Thread

- [x] Detect shared post references in note text
- [x] Dedicated thread / post-detail route
- [x] Open a note into standalone detail view
- [x] Replied-to context
- [x] Replies list / reply tree
- [x] Reply composer on thread view
- [n] Relevant-people / side-column thread extras
- [x] Longform / `naddr` thread support

## Reaction

- [x] Like button on notes
- [x] Publish like reactions to connected relays
- [x] Optimistic like state
- [x] Optimistic like count update
- [x] Indexed reaction counts
- [x] Merge indexed reaction counts across main index and personal profile index
- [x] Zap totals display
- [x] Reply / comment action
- [x] Repost action
- [x] Share action
- [x] Like / repost / zap detail lists
- [x] Zap action
- [x] Zap-all action
- [x] Reaction dropdown / overflow menu
- [n] Relay list / relay detail for reactions

## Media

- [x] Inline image embeds
- [x] Inline video embeds
- [x] Inline audio embeds
- [x] YouTube embeds
- [x] Hashtree-backed attachment loading
- [x] Hashtree file download button
- [x] Multiple embeds rendered in one note (up to 4)
- [x] Media modal / lightbox
- [x] Swipeable gallery / carousel
- [x] Sidebar event view inside media modal
- [x] Dedicated thumbnail/grid media browsing
- [x] Sensitive media is hidden behind an explicit reveal for NIP-36 warnings and `#nsfw`
- [x] Upload media from composer
- [x] Upload progress UI (check ~/src/iris-apps for ref)
- [x] Upload media / attachments to hashtree, use hashtree urls
- [x] Media server settings / media publishing pipeline
