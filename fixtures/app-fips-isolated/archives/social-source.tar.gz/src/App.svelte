<script lang="ts">
  import AppContactMemory from "./lib/components/AppContactMemory.svelte";
  import type { CID } from "@hashtree/core";
  import { createKnownNotesCache } from "./lib/appDataUtils";
  import { createHomeFeedSeenBatcher } from "./lib/homeFeedSeen";
  import { PROFILE_SEARCH_DROPDOWN_LIMIT, PROFILE_SEARCH_PAGE_LIMIT } from "./lib/appViewerHydrators";
  import {
    createBoundedHydrationScheduler,
    createRouteHydrationPromiseCache,
  } from "./lib/boundedHydrationScheduler";
  import { DebouncedTask } from "./lib/debouncedTask";
  import { resolvePreferredProfile } from "./lib/appProfiles";
  import { createAppFeedPreferences } from "./lib/appFeedPreferences";
  import { createAppHomeFeedSnapshots } from "./lib/appHomeFeedSnapshots";
  import { createAppScrollController } from "./lib/appScrollController";
  import { createAppHistoryNavigation } from "./lib/appHistoryNavigation";
  import { createAppRouteTransitionController } from "./lib/appRouteTransitionController";
  import { createAppMediaController } from "./lib/appMediaController";
  import {
    createAppBrowserState,
    reportAppError as reportError,
  } from "./lib/appBrowserState";
  import { registerAppLifecycle } from "./lib/appLifecycle";
  import { createAppViewStateController } from "./lib/appViewStateController";
  import { createAppInfiniteScrollController } from "./lib/appInfiniteScrollController";
  import { createAppProfileCacheController } from "./lib/appProfileCacheController";
  import {
    createAppReferencedNoteController,
    noteHasMedia,
  } from "./lib/appReferencedNoteController";
  import { createAppEngagementController } from "./lib/appEngagementController";
  import { createAppThreadHydrationController } from "./lib/appThreadHydrationController";
  import { createAppDataHydrationControllers } from "./lib/appDataHydrationControllers";
  import { createAppShadowReadController } from "./lib/appShadowReadController";
  import { createAppRouteHydrationControllers } from "./lib/appRouteHydrationControllers";
  import { createAppUserActionControllers } from "./lib/appUserActionControllers";
  import { createAppShellActions } from "./lib/appShellActions";
  import {
    AppReactiveProjection,
    createInitialAppReactiveProjection,
    type AppReactiveProjectionServices,
  } from "./lib/components/app-projection";
  import { createAppState } from "./lib/appState";
  import { createReactiveDeps } from "./lib/reactiveState";
  import type { RouteRenderCache } from "./lib/appStack";
  import {
    AppShell,
    type AppShellView,
  } from "./lib/components/app-shell";
  import type { Route } from "./lib/appRoute";
  import type {
    ShadowReadObservation,
    ShadowReadScope,
  } from "./lib/shadowReadComparator";
  import { getRootNhash } from "./lib/nostrIndex";
  import type { RawEvent } from "./lib/nostr";
  import type { ReferencedNotePreview } from "./lib/referencedNote";
  import { createThreadReplyDraftStore, getBrowserDraftStorage } from "./lib/threadReplyDrafts";

  const {
    routeState,
    homeState,
    profileState,
    threadState,
    searchState,
    accountState,
    viewerState,
    engagementState,
    notificationState,
    mediaState,
    overlayState,
    runtimeState,
    combinedState: appState,
  } = createAppState();
  let appProjection = createInitialAppReactiveProjection();
  const {
    consumeViewerOverride,
    readNotificationsSeenAt,
    saveNotificationsSeenAt,
    stripTransientQueryParams,
  } = createAppBrowserState(appState);

  const pendingShadowReadObservations = new Map<ShadowReadScope, ShadowReadObservation>();
  const pendingLiveViewEvents = new Map<string, RawEvent>();
  const profileSearchDebounce = new DebouncedTask(240);
  const knownNotesCache = createKnownNotesCache(2048);
  const homeFeedSeenBatcher = createHomeFeedSeenBatcher();
  knownNotesCache.cache(...$overlayState.localPostsByAuthor.values()); // Prime before first card opens.
  const referencedNotePreviewCache = new Map<string, ReferencedNotePreview>();
  const referencedNotePreviewPromises = createRouteHydrationPromiseCache<ReferencedNotePreview | null>();
  const visibleNoteHydrationScheduler = createBoundedHydrationScheduler({ concurrency: 4 });
  const createScrollOffsetTracker = (initialValue = 0) => {
    let value = initialValue;
    return {
      get: () => value,
      set: (nextValue: number) => {
        value = nextValue;
      },
    };
  };
  const homeFeedScroll = createScrollOffsetTracker();
  const profileFeedScroll = createScrollOffsetTracker();
  const threadReplyScroll = createScrollOffsetTracker();
  const threadReplyDrafts = createThreadReplyDraftStore(50, getBrowserDraftStorage());
  const {
    cacheKnownNotes,
    getCachedProfiles, getCanonicalKnownNoteByRef, getSharedProfileRecord,
    hydrateAccountProfiles,
    mergeCachedProfiles,
    prependLocalPost,
    pruneTombstonedLocalPosts,
    snapshotKnownProfileNotes, snapshotLocalPostSearchEvents,
  } = createAppProfileCacheController({ state: appState, knownNotesCache });
  const {
    getKnownNoteByRef,
    getThreadReferenceEvents,
    resolveReferencedNote,
  } = createAppReferencedNoteController({
    state: appState,
    knownNotesCache,
    previewCache: referencedNotePreviewCache,
    previewPromises: referencedNotePreviewPromises,
    scheduler: visibleNoteHydrationScheduler,
    cacheKnownNotes,
    getResolvedProfiles: () => appProjection.identity.baseResolvedProfilesByPubkey,
    mergeCachedProfiles,
  });
  const {
    clearOptimisticLike,
    hydrateNoteEngagements, ensureVisibleNoteEngagements,
    prependThreadReply,
    seedEmptyEngagements,
    seedNewEmptyEngagements,
    setOptimisticLike,
  } = createAppEngagementController({
    state: appState,
    scheduler: visibleNoteHydrationScheduler,
  });
  const {
    runProfileHydrationWithShadow,
    scheduleCurrentFeedShadowComparison,
    scheduleShadowReadComparison,
  } = createAppShadowReadController({
    state: appState,
    pendingObservations: pendingShadowReadObservations,
  });
  const viewStateController = createAppViewStateController({
    state: appState,
    homeFeedScroll,
    profileFeedScroll,
    threadReplyScroll,
    threadReplyDrafts,
    getActiveAccountPubkey: () => $accountState.activeAccount?.pubkey ?? null,
    getActiveFeedSourcePubkey: () => $homeState.activeFeedSource?.pubkey ?? null,
    getKnownNoteByRef,
    closeDetailSheet: () => userActions.noteInteractions.closeDetailSheet(),
    closeMedia: () => handleCloseMedia(),
  });
  $: viewStateController.restoreAccountDrafts($accountState.activeAccount?.pubkey ?? null);

  const {
    activeThreadReplyDraftKey,
    applyPendingNavigationState,
    clearNotificationsState,
    clearProfileViewState,
    clearRootBoundState,
    clearThreadReplyDraft,
    clearThreadViewState,
    loadAccountSheet,
    loadSearchPage,
    persistActiveThreadReplyDraft,
    primeThreadPreview,
    resetActiveAccountUiState,
    resetHomeFeedPagination,
    resetProfileFeedPagination,
    resetProfileSocialPagination,
    resetThreadReplyPagination,
    restoreLiveRouteState,
    restoreThreadReplyDraft,
  } = viewStateController;
  const {
    hydrateThread,
    hydrateThreadRepliesPage,
  } = createAppThreadHydrationController({
    state: appState,
    applyCachedRoot,
    cacheKnownNotes,
    clearProfileViewState,
    getKnownNoteByRef,
    hydrateNoteEngagements,
    mergeCachedProfiles,
    reportError,
    resetThreadReplyPagination,
    scheduleShadowReadComparison,
    seedEmptyEngagements,
  });
  const {
    applyProfileSocialSnapshot,
    applyViewerFollows,
    feedHydrators,
    hydrateNextHomeFeedPage,
    profileDataHydrators, profileHydrators, projectContactsEvent, viewerHydrators,
  } = createAppDataHydrationControllers({
    state: appState,
    homeFeedSeenBatcher,
    cacheKnownNotes,
    clearProfileViewState,
    clearThreadViewState,
    getCachedProfiles,
    getForYouOverlayInteractions: (authors, limit) => (
      getForYouOverlayInteractions(authors, limit)
    ),
    getKnownNoteByRef,
    hydrateNoteEngagements,
    mergeCachedProfiles,
    noteHasMedia,
    reportError,
    restartCurrentViewLoad,
    saveNotificationsSeenAt,
    scheduleHomeFeedSnapshotWrite: (feed) => scheduleHomeFeedSnapshotWrite(feed),
    seedEmptyEngagements,
    seedNewEmptyEngagements,
    updateProfileNotesLoading,
  });

  const { paginationLoaders, routeLoader } = createAppRouteHydrationControllers({
    state: appState,
    feedHydrators,
    profileDataHydrators,
    profileHydrators,
    viewerHydrators,
    homeFeedScroll,
    profileFeedScroll,
    threadReplyScroll,
    applyProfileSocialSnapshot,
    clearProfileViewState,
    clearRootBoundState,
    clearThreadViewState,
    getHomeFeedHasMore: () => appProjection.live.homeFeedHasMore,
    getProfileFeedHasMore: () => appProjection.live.profileFeedHasMore,
    getProfileSocialHasMore: () => appProjection.view.profileSocialHasMore,
    hydrateNextHomeFeedPage,
    hydrateThread,
    hydrateThreadRepliesPage,
    reportError,
    runProfileHydrationWithShadow,
    scheduleCurrentFeedShadowComparison,
    scheduleShadowReadComparison,
    updateProfileNotesLoading,
  });

  function updateProfileNotesLoading(nextLoading: boolean): void {
    const shouldResumeQueuedLoad = $profileState.profileNotesLoading && !nextLoading;
    profileState.profileNotesLoading = nextLoading;
    if (shouldResumeQueuedLoad) {
      queueMicrotask(() => {
        void paginationLoaders.resumeQueuedProfileNotesLoad();
      });
    }
  }
  const userActions = createAppUserActionControllers({
    state: appState,
    pendingLiveViewEvents,
    threadReplyDrafts,
    activeThreadReplyDraftKey,
    applyProfileSocialSnapshot,
    applyViewerFollows,
    cacheKnownNotes,
    cancelProfileSearchDebounce: () => profileSearchDebounce.cancel(),
    cancelRemoteSearch: () => viewerHydrators.cancelRemoteSearch(),
    clearOptimisticLike,
    clearThreadReplyDraft,
    getKnownNoteByRef,
    getProfileEditorBlockedReason: () => appProjection.view.profileEditorBlockedReason,
    hydrateAccountProfiles,
    loadSearchPage,
    mergeCachedProfiles,
    navigateHome,
    navigateProfile,
    navigateThread,
    navigateToHref,
    noteHasMedia,
    persistActiveThreadReplyDraft,
    prependLocalPost,
    prependThreadReply,
    projectContactsEvent,
    pruneTombstonedLocalPosts,
    reportError,
    resetActiveAccountUiState,
    resolveProfile: (pubkey) => resolvePreferredProfile(
      pubkey,
      appProjection.identity.baseResolvedProfilesByPubkey.get(pubkey) ?? null,
    ),
    restartCurrentViewLoad,
    scheduleRemoteSearch,
    scrollPageToTopInstant: () => scrollPageToTopInstant(),
    seedNewEmptyEngagements,
    setOptimisticLike,
  });
  const {
    getForYouOverlayInteractions,
    getForYouRankingAuthors,
    getLiveHomeAuthors,
    liveEventMatchesCurrentHomeFeed,
    resetLiveHomeFeedBuffer,
    scheduleLiveViewRefresh,
    applyViewerOverride,
    closeSearchSheet, warmSearchResources, applySearchRoute,
  } = userActions;

  const feedPreferences = createAppFeedPreferences(createReactiveDeps(appState, {
    resetHomeFeedPagination,
    resetLiveHomeFeedBuffer,
    restartCurrentViewLoad,
    restartCurrentViewLoadAndWait,
  }));
  const {
    handleRefreshHome,
    initializeFeedSources,
  } = feedPreferences;

  const { restoreHomeFeedSnapshot, scheduleHomeFeedSnapshotWrite } =
    createAppHomeFeedSnapshots(createReactiveDeps(appState, {
      homeFeedSeenBatcher,
      cacheKnownNotes,
      noteHasMedia,
      seedEmptyEngagements,
    }));

  const scrollController = createAppScrollController(createReactiveDeps(appState, {
    handleRefreshHome,
  }));
  const {
    applyPendingRouteScroll,
    cancelPendingRouteScrollRestores,
    captureVisibleHomeFeedAnchor, captureVisibleProfileFeedAnchor,
    handleActivePrimaryNavigation,
    persistCurrentRouteScroll,
    persistCurrentRouteScrollIfNeeded,
    restorePresentedRouteScroll,
    scheduleCurrentRouteScrollPersistence, scheduleVisibleHomeAnchorRestore,
    scheduleVisibleProfileAnchorRestore,
    scrollPageToTopInstant,
  } = scrollController;

  const historyNavigation = createAppHistoryNavigation(createReactiveDeps(appState, {
    handleActivePrimaryNavigation,
    handleRefreshHome,
    handleRouteLocationChange,
    navigateHomeBeforeCompose: () => historyNavigation.navigateHome(),
    persistCurrentRouteScrollIfNeeded,
    primeThreadPreview,
  }));

  function navigateHome(): void { historyNavigation.navigateHome(); }
  function navigateThread(target: string): void { historyNavigation.navigateThread(target); }
  function navigateProfile(pubkey: string): void { historyNavigation.navigateProfile(pubkey); }
  function navigateToHref(href: string): void { historyNavigation.navigateToHref(href); }
  const {
    handleDocumentNavigationClick,
  } = historyNavigation;

  const routeTransitions = createAppRouteTransitionController(createReactiveDeps(appState, {
    get activeFeedSourcePubkey() { return $homeState.activeFeedSource?.pubkey ?? null; },
    threadReplyDrafts,
    applyPendingNavigationState,
    applySearchRoute,
    cancelCurrentViewLoad,
    invalidateCurrentViewLoad: () => { runtimeState.loadToken += 1; },
    cancelPendingRouteScrollRestores,
    closeSearchSheet,
    resetHomeFeedPagination,
    resetLiveHomeFeedBuffer,
    resetProfileFeedPagination,
    resetProfileSocialPagination,
    resetThreadReplyPagination,
    restartCurrentViewLoad,
    restorePresentedRouteScroll,
    restoreHomeFeedSnapshot,
    restoreLiveRouteState,
    restoreThreadReplyDraft, getSharedProfileRecord, snapshotKnownProfileNotes,
    stripTransientQueryParams,
    warmSearchResources,
    loadAccountSheet,
  }));

  function syncRouteStack(nextRoute: Route): void { routeTransitions.syncRouteStack(nextRoute); }
  function applyCurrentRouteCache(cache: RouteRenderCache): void {
    routeTransitions.applyCurrentRouteCache(cache);
  }
  function replaceNonCanonicalIdentifierRoute(nextRoute: Route): Route {
    return routeTransitions.replaceNonCanonicalIdentifierRoute(nextRoute);
  }
  function handleRouteLocationChange(
    options: { fromPopState?: boolean; replaceCurrentView?: boolean } = {},
  ): void {
    routeTransitions.handleRouteLocationChange(options);
  }

  const mediaController = createAppMediaController({
    state: appState,
    getCurrentProfile: () => appProjection.identity.currentProfile,
    navigateProfile,
    navigateThread,
    resolveProfile: (pubkey) => resolvePreferredProfile(
      pubkey,
      appProjection.identity.currentProfile?.pubkey === pubkey
        ? appProjection.identity.currentProfile
        : null,
      appProjection.identity.baseResolvedProfilesByPubkey.get(pubkey) ?? null,
    ),
  });
  const {
    handleCloseMedia,
  } = mediaController;

  const infiniteScrollController = createAppInfiniteScrollController({
    state: appState,
    homeFeedScroll,
    profileFeedScroll,
    threadReplyScroll,
    hydrateNotificationsPage: ({ root, pubkey, token, before, limit }) => (
      viewerHydrators.hydrateNotifications(root, pubkey, token, {
        append: true,
        before,
        limit,
      })
    ),
    loadMoreFeed,
    loadMoreProfileNotes,
    loadMoreProfileSocial,
    loadMoreThreadReplies,
    getHomeFeedHasMore: () => appProjection.live.homeFeedHasMore,
    getProfileFeedHasMore: () => appProjection.live.profileFeedHasMore,
    getProfileSocialHasMore: () => appProjection.view.profileSocialHasMore,
  });
  function markHomeNoteSeen(event: RawEvent, presentedEvent: RawEvent | null): void {
    if (!$accountState.activeAccount) {
      return;
    }
    homeFeedSeenBatcher.mark($accountState.activeAccount.pubkey, [
      event.id,
      ...(presentedEvent && presentedEvent.id !== event.id ? [presentedEvent.id] : []),
    ]);
  }
  function applyCachedRoot(nextRoot: CID): boolean {
    const nextRootNhash = getRootNhash(nextRoot);
    const changed = nextRootNhash !== $runtimeState.rootNhash;
    runtimeState.root = nextRoot;
    runtimeState.rootNhash = nextRootNhash;
    runtimeState.rootError = '';
    return changed;
  }


  function scheduleRemoteSearch(query: string): void {
    profileSearchDebounce.cancel();
    viewerHydrators.cancelRemoteSearch();
    const requestId = ++searchState.searchRequestId;
    if (!query.trim()) {
      searchState.searchLoading = false;
      searchState.searchRemoteProfiles = [];
      return;
    }

    const limit = $routeState.route.kind === 'search'
      ? PROFILE_SEARCH_PAGE_LIMIT
      : PROFILE_SEARCH_DROPDOWN_LIMIT;
    searchState.searchLoading = true;
    profileSearchDebounce.schedule(() => {
      void viewerHydrators.hydrateRemoteSearch(query, requestId, limit);
    });
  }

  async function runCurrentViewLoad(token: number): Promise<void> {
    await routeLoader.runCurrentViewLoad(token);
  }

  function cancelCurrentViewLoad(): void {
    visibleNoteHydrationScheduler.cancelPending();
    profileHydrators.cancelPendingProfileHydrations();
    profileDataHydrators.cancelPendingProfileRecordHydration();
    referencedNotePreviewPromises.clear();
    runtimeState.loadToken += 1;
  }

  function restartCurrentViewLoad(): void {
    cancelCurrentViewLoad();
    const token = runtimeState.loadToken;
    void runCurrentViewLoad(token);
  }

  async function restartCurrentViewLoadAndWait(): Promise<number> {
    cancelCurrentViewLoad();
    const token = runtimeState.loadToken;
    await runCurrentViewLoad(token);
    return token;
  }

  async function loadMoreFeed(): Promise<void> {
    await paginationLoaders.loadMoreFeed();
  }

  async function loadMoreProfileNotes(): Promise<void> {
    await paginationLoaders.loadMoreProfileNotes();
  }

  async function loadMoreProfileSocial(): Promise<void> {
    await paginationLoaders.loadMoreProfileSocial();
  }

  async function loadMoreThreadReplies(): Promise<void> {
    await paginationLoaders.loadMoreThreadReplies();
  }

  registerAppLifecycle({
    state: appState,
    homeFeedSeenBatcher,
    pendingLiveViewEvents,
    pendingShadowReadObservations,
    profileSearchDebounce,
    visibleNoteHydrationScheduler,
    applyCachedRoot,
    applySearchRoute,
    applyViewerOverride,
    cacheKnownNotes,
    clearRootBoundState,
    consumeViewerOverride,
    handleDocumentNavigationClick,
    handleRouteLocationChange,
    initializeFeedSources,
    loadAccountSheet,
    persistCurrentRouteScroll,
    persistCurrentRouteScrollIfNeeded,
    pruneTombstonedLocalPosts,
    readNotificationsSeenAt,
    replaceNonCanonicalIdentifierRoute,
    reportError,
    resetHomeFeedPagination,
    resetLiveHomeFeedBuffer,
    resetProfileFeedPagination,
    restartCurrentViewLoad,
    restoreHomeFeedSnapshot,
    scheduleCurrentRouteScrollPersistence,
    scheduleLiveViewRefresh,
    seedEmptyEngagements,
    stripTransientQueryParams,
    syncRouteStack,
    warmSearchResources,
  });

  const projectionServices: AppReactiveProjectionServices = {
    applyCurrentRouteCache,
    applyPendingRouteScroll,
    captureVisibleHomeFeedAnchor, captureVisibleProfileFeedAnchor,
    getForYouOverlayInteractions,
    getForYouRankingAuthors,
    getCanonicalKnownNoteByRef, getKnownNoteByRef,
    getLiveHomeAuthors,
    getThreadReferenceEvents,
    hydrateAccountProfiles, ensureVisibleNoteEngagements,
    liveEventMatchesCurrentHomeFeed,
    scheduleVisibleHomeAnchorRestore, scheduleVisibleProfileAnchorRestore, snapshotKnownProfileNotes,
    snapshotLocalPostSearchEvents,
  };

  let appShellView: AppShellView;
  $: appShellView = {
    ...appProjection.view,
    threadReplyDrafts,
    infiniteScroll: {
      home: infiniteScrollController.homeFeedInfiniteScroll,
      notifications: infiniteScrollController.notificationsInfiniteScroll,
      profileFeed: infiniteScrollController.profileFeedInfiniteScroll,
      profileSocial: infiniteScrollController.profileSocialInfiniteScroll,
      threadReplies: infiniteScrollController.threadRepliesInfiniteScroll,
    },
    resolveReferencedNote,
  };

  const appShellActions = createAppShellActions({
    state: appState,
    user: userActions,
    feed: feedPreferences,
    history: historyNavigation,
    media: mediaController,
    scroll: scrollController,
    infinite: infiniteScrollController,
    loadAccountSheet,
    loadSearchPage,
    loadMoreFeed,
    loadMoreProfileNotes,
    loadMoreThreadReplies,
    cachePresentedHomeNote: (event) => cacheKnownNotes([event]),
    markHomeNoteSeen,
  });
</script>

<AppContactMemory {appState} viewerPubkey={$accountState.activeAccount?.pubkey ?? null}
  resetHomeFeedPagination={viewStateController.resetHomeFeedPagination} {restartCurrentViewLoad} />

<AppReactiveProjection
  {routeState}
  {homeState}
  {profileState}
  {threadState}
  {searchState}
  {accountState}
  {viewerState}
  {engagementState}
  {notificationState}
  {mediaState}
  {overlayState}
  {runtimeState}
  services={projectionServices}
  bind:projection={appProjection}
/>

<AppShell
  {routeState}
  {homeState}
  {threadState}
  {searchState}
  {accountState}
  {viewerState}
  {engagementState}
  {notificationState}
  {mediaState}
  {runtimeState}
  view={appShellView}
  actions={appShellActions}
/>
