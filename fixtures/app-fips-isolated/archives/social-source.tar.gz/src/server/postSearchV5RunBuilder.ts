import { HashTree, sha256, type Store } from '@hashtree/core';
import type { RankedSearchDocument } from '@hashtree/index';
import { POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES } from './postSearchV5PackedPage';
import { encodePostSearchV5RunManifest } from './postSearchV5RunManifest';
import {
  postSearchV5TermStatistics,
  tokenizePostSearchV5Field,
} from './postSearchV5RunRecords';
import {
  buildPostSearchV5Branch,
  postSearchV5BlobEntry,
  postSearchV5DirectoryEntry,
  postSearchV5PageName,
  postSearchV5ReachableHashes,
  type PostSearchV5BucketEntry,
} from './postSearchV5RunStorage';
import {
  POST_SEARCH_V5_MAX_FIELDS,
  POST_SEARCH_V5_MAX_TOKENS_PER_FIELD,
  POST_SEARCH_V5_NORMALIZATION,
  POST_SEARCH_V5_POSTING_PART_SEPARATOR,
  POST_SEARCH_V5_RUN_DEFAULT_MAX_DOCUMENTS,
  POST_SEARCH_V5_RUN_FORMAT,
  POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
  POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES,
  POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES,
  type PostSearchV5Posting,
  type PostSearchV5RunBuild,
  type PostSearchV5RunBuildOptions,
  type PostSearchV5RunManifest,
} from './postSearchV5RunTypes';
import {
  comparePostSearchV5Strings,
  postSearchV5BoundedNumber,
  postSearchV5NonEmptyString,
  postSearchV5PositiveInteger,
  postSearchV5PositiveNumber,
} from './postSearchV5RunValidation';

interface NormalizedField {
  name: string;
  boost: number;
  lengthNormalization: number;
}

const encoder = new TextEncoder();

export async function buildPostSearchV5Run(
  store: Store,
  input: Iterable<RankedSearchDocument>,
  options: PostSearchV5RunBuildOptions,
): Promise<PostSearchV5RunBuild> {
  const config = normalizeOptions(options);
  const documents = collectBoundedDocuments(input, config.maxDocuments)
    .sort((left, right) => comparePostSearchV5Strings(left.id, right.id));
  validateDocuments(documents, config.maxDocuments);
  const documentEntries: PostSearchV5BucketEntry[] = [];
  const postingsByTerm = new Map<string, PostSearchV5Posting[]>();
  const totals = new Map(config.fields.map((field) => [field.name, 0]));
  const populated = new Map(config.fields.map((field) => [field.name, 0]));
  let storedValueCount = 0;
  let tokenOccurrenceCount = 0;
  let postingCount = 0;

  for (const document of documents) {
    const lengths: Record<string, number> = Object.create(null) as Record<string, number>;
    const documentPostings = new Map<string, PostSearchV5Posting>();
    for (const field of config.fields) {
      const tokenized = tokenizePostSearchV5Field(
        document.fields[field.name],
        config.maxTokensPerField,
      );
      lengths[field.name] = tokenized.length;
      totals.set(field.name, (totals.get(field.name) ?? 0) + tokenized.length);
      if (tokenized.length > 0) {
        populated.set(field.name, (populated.get(field.name) ?? 0) + 1);
      }
      tokenOccurrenceCount += tokenized.occurrences.length;
      if (tokenOccurrenceCount > POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES) {
        throw new Error(`Post-search v5 run exceeds ${POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES} token occurrences`);
      }
      for (const occurrence of tokenized.occurrences) {
        const posting = documentPostings.get(occurrence.term)
          ?? { id: document.id, fields: Object.create(null) as PostSearchV5Posting['fields'] };
        const postingField = posting.fields[field.name] ?? { frequency: 0, positions: [] };
        postingField.frequency += 1;
        postingField.positions.push(occurrence.position);
        posting.fields[field.name] = postingField;
        documentPostings.set(occurrence.term, posting);
      }
    }
    if (document.value !== undefined) {
      storedValueCount += 1;
    }
    documentEntries.push({
      bucketKey: document.id,
      key: document.id,
      value: JSON.stringify(
        document.value === undefined ? { lengths } : { lengths, value: document.value },
      ),
    });
    postingCount += documentPostings.size;
    for (const [term, posting] of documentPostings) {
      const postings = postingsByTerm.get(term) ?? [];
      postings.push(posting);
      postingsByTerm.set(term, postings);
    }
  }

  const postingEntries: PostSearchV5BucketEntry[] = [];
  const termEntries: PostSearchV5BucketEntry[] = [];
  for (const term of [...postingsByTerm.keys()].sort(comparePostSearchV5Strings)) {
    const postings = postingsByTerm.get(term) ?? [];
    const parts = splitPostingParts(postings);
    for (let index = 0; index < parts.length; index += 1) {
      postingEntries.push({
        bucketKey: term,
        key: `${term}${POST_SEARCH_V5_POSTING_PART_SEPARATOR}${postSearchV5PageName(index)}`,
        value: parts[index]!,
      });
    }
    termEntries.push({
      bucketKey: term,
      key: term,
      value: JSON.stringify({ ...postSearchV5TermStatistics(postings), postingParts: parts.length }),
    });
  }

  const tree = new HashTree({ store });
  const [documentBranch, postingBranch, termBranch] = await Promise.all([
    buildPostSearchV5Branch(store, tree, 'documents', documentEntries),
    buildPostSearchV5Branch(store, tree, 'postings', postingEntries),
    buildPostSearchV5Branch(store, tree, 'terms', termEntries),
  ]);
  const baseHashes = await postSearchV5ReachableHashes(tree, [
    documentBranch.root,
    postingBranch.root,
    termBranch.root,
  ]);
  const fields = config.fields.map((field) => ({
    ...field,
    totalLength: totals.get(field.name) ?? 0,
    populatedDocumentCount: populated.get(field.name) ?? 0,
  }));
  const pageCount = documentBranch.pageCount + postingBranch.pageCount + termBranch.pageCount;
  const manifest: PostSearchV5RunManifest = {
    format: POST_SEARCH_V5_RUN_FORMAT,
    normalization: POST_SEARCH_V5_NORMALIZATION,
    documentCount: documents.length,
    termCount: termEntries.length,
    postingCount,
    storedValueCount,
    tokenOccurrenceCount,
    k1: config.k1,
    maxTokensPerField: config.maxTokensPerField,
    fields,
    pages: {
      documents: documentBranch.pageCount,
      postings: postingBranch.pageCount,
      terms: termBranch.pageCount,
      total: pageCount,
    },
    entries: {
      documents: documentBranch.entryCount,
      postings: postingBranch.entryCount,
      terms: termBranch.entryCount,
    },
    reachableNodeCount: baseHashes.size + 2,
  };
  const manifestBytes = encodePostSearchV5RunManifest(manifest);
  const manifestHash = await sha256(manifestBytes);
  await store.put(manifestHash, manifestBytes);
  const root = (await tree.putDirectory([
    postSearchV5DirectoryEntry('documents', documentBranch.root),
    postSearchV5BlobEntry('manifest.json', { hash: manifestHash }, manifestBytes.length),
    postSearchV5DirectoryEntry('postings', postingBranch.root),
    postSearchV5DirectoryEntry('terms', termBranch.root),
  ], { unencrypted: true })).cid;
  const actualReachable = (await postSearchV5ReachableHashes(tree, [root])).size;
  if (actualReachable !== manifest.reachableNodeCount) {
    throw new Error('Post-search v5 run reachable node count was not stable');
  }
  return { root, manifest };
}

function splitPostingParts(postings: readonly PostSearchV5Posting[]): string[] {
  const records = postings.map((posting) => JSON.stringify(posting));
  const parts: string[] = [];
  let part: string[] = [];
  let bytes = 2;
  for (const record of records) {
    const recordBytes = encoder.encode(record).length + (part.length > 0 ? 1 : 0);
    if (part.length > 0
      && bytes + recordBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      parts.push(`[${part.join(',')}]`);
      part = [];
      bytes = 2;
    }
    if (bytes + encoder.encode(record).length > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      throw new Error(`Post-search v5 posting is too large: ${postings[parts.length]?.id ?? ''}`);
    }
    part.push(record);
    bytes += encoder.encode(record).length + (part.length > 1 ? 1 : 0);
  }
  if (part.length > 0) {
    parts.push(`[${part.join(',')}]`);
  }
  return parts;
}

function normalizeOptions(options: PostSearchV5RunBuildOptions): {
  fields: NormalizedField[];
  k1: number;
  maxTokensPerField: number;
  maxDocuments: number;
} {
  const fields = Object.entries(options.fields).sort(([left], [right]) =>
    comparePostSearchV5Strings(left, right)).map(([name, field]) => ({
    name: postSearchV5NonEmptyString(name, 'field name'),
    boost: postSearchV5PositiveNumber(field.boost ?? 1, `field ${name} boost`),
    lengthNormalization: postSearchV5BoundedNumber(
      field.lengthNormalization ?? 0.75,
      0,
      1,
      `field ${name} normalization`,
    ),
  }));
  if (fields.length === 0 || fields.length > POST_SEARCH_V5_MAX_FIELDS) {
    throw new Error(`Post-search v5 runs require 1-${POST_SEARCH_V5_MAX_FIELDS} fields`);
  }
  const maxTokensPerField = postSearchV5PositiveInteger(
    options.maxTokensPerField ?? POST_SEARCH_V5_MAX_TOKENS_PER_FIELD,
    'maxTokensPerField',
  );
  if (maxTokensPerField > POST_SEARCH_V5_MAX_TOKENS_PER_FIELD) {
    throw new Error(`Post-search v5 maxTokensPerField exceeds ${POST_SEARCH_V5_MAX_TOKENS_PER_FIELD}`);
  }
  const maxDocuments = postSearchV5PositiveInteger(
    options.maxDocuments ?? POST_SEARCH_V5_RUN_DEFAULT_MAX_DOCUMENTS,
    'maxDocuments',
  );
  if (maxDocuments > POST_SEARCH_V5_RUN_MAX_DOCUMENTS) {
    throw new Error(`Post-search v5 maxDocuments exceeds ${POST_SEARCH_V5_RUN_MAX_DOCUMENTS}`);
  }
  return {
    fields,
    k1: postSearchV5PositiveNumber(options.k1 ?? 1.2, 'k1'),
    maxTokensPerField,
    maxDocuments,
  };
}

function validateDocuments(documents: readonly RankedSearchDocument[], maximum: number): void {
  if (documents.length === 0 || documents.length > maximum) {
    throw new Error(`Post-search v5 run requires 1-${maximum} documents`);
  }
  let previous: string | undefined;
  for (const document of documents) {
    postSearchV5NonEmptyString(document.id, 'document id');
    if (document.id === previous) {
      throw new Error(`Duplicate post-search v5 document id: ${document.id}`);
    }
    if (document.value !== undefined && typeof document.value !== 'string') {
      throw new Error(`Invalid post-search v5 document value: ${document.id}`);
    }
    let rawBytes = Buffer.byteLength(document.id, 'utf8')
      + (document.value === undefined ? 0 : Buffer.byteLength(document.value, 'utf8'));
    if (rawBytes > POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES) {
      throw new Error(`Post-search v5 raw document exceeds its byte bound: ${document.id}`);
    }
    if (!document.fields || typeof document.fields !== 'object'
      || Array.isArray(document.fields)) {
      throw new Error(`Invalid post-search v5 document fields: ${document.id}`);
    }
    for (const [fieldName, rawValue] of Object.entries(document.fields)) {
      rawBytes += Buffer.byteLength(fieldName, 'utf8');
      const values = typeof rawValue === 'string' ? [rawValue] : rawValue;
      if (!Array.isArray(values) || values.some((value) => typeof value !== 'string')) {
        throw new Error(`Invalid post-search v5 document field: ${document.id}`);
      }
      for (const value of values) {
        rawBytes += Buffer.byteLength(value, 'utf8');
        if (rawBytes > POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES) {
          throw new Error(`Post-search v5 raw document exceeds its byte bound: ${document.id}`);
        }
      }
    }
    previous = document.id;
  }
}

function collectBoundedDocuments(
  input: Iterable<RankedSearchDocument>,
  maximum: number,
): RankedSearchDocument[] {
  const documents: RankedSearchDocument[] = [];
  for (const document of input) {
    if (documents.length >= maximum) {
      throw new Error(`Post-search v5 run requires 1-${maximum} documents`);
    }
    documents.push(document);
  }
  return documents;
}
