import { randomBytes } from 'node:crypto';
import { mkdir, open, readFile, rename, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import { POST_SEARCH_KINDS } from '../lib/postSearchCatalogConstants';
import {
  parsePostSearchV5LeveledRunState,
  postSearchV5RunCatalog,
  type PostSearchV5LeveledRunState,
} from './postSearchV5LeveledRuns';
import type { PostSearchDeletionReport, PostSearchKindReport } from './postSearchProjection';

export const POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT =
  'iris-social/post-search-v5-routed-builder-state@1' as const;

const HEX_64 = /^[0-9a-f]{64}$/;
const STATE_KEYS = [
  'batches', 'catalogRoot', 'completedKinds', 'configurationSha256', 'deletionReport',
  'format', 'generatedAt', 'kindReports', 'leveledRuns', 'publisherId', 'sourceEventRoot',
  'status',
] as const;
const BATCH_KEYS = ['batch', 'documentCount', 'kind', 'since', 'until'] as const;
const DELETION_KEYS = [
  'addressTombstones', 'exactTombstones', 'invalid', 'scanned', 'valid',
] as const;
const REPORT_KEYS = [
  'addressDeleted', 'exactDeleted', 'invalid', 'scanned', 'superseded', 'visible',
] as const;

export interface PostSearchV5RoutedSourceBatch {
  batch: number;
  documentCount: number;
  kind: number;
  since: number;
  until: number;
}

export interface PostSearchV5RoutedBuilderState {
  format: typeof POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT;
  status: 'building' | 'complete';
  configurationSha256: string;
  sourceEventRoot: string;
  publisherId: string;
  generatedAt: number;
  completedKinds: number[];
  batches: PostSearchV5RoutedSourceBatch[];
  leveledRuns: PostSearchV5LeveledRunState;
  deletionReport: PostSearchDeletionReport;
  kindReports: Record<string, PostSearchKindReport>;
  catalogRoot: string | null;
}

export interface PostSearchV5RoutedBuilderStateStore {
  load(): Promise<PostSearchV5RoutedBuilderState | null>;
  /** A successful save must be durable before it resolves. */
  save(state: PostSearchV5RoutedBuilderState): Promise<void>;
}

export class FilePostSearchV5RoutedBuilderStateStore
implements PostSearchV5RoutedBuilderStateStore {
  private readonly path: string;

  constructor(path: string) {
    this.path = resolve(path);
  }

  async load(): Promise<PostSearchV5RoutedBuilderState | null> {
    let value: unknown;
    try {
      value = JSON.parse(await readFile(this.path, 'utf8'));
    } catch (error) {
      if (isErrno(error, 'ENOENT')) {return null;}
      throw error;
    }
    return parsePostSearchV5RoutedBuilderState(value);
  }

  async save(state: PostSearchV5RoutedBuilderState): Promise<void> {
    const validated = parsePostSearchV5RoutedBuilderState(state);
    await writeFsyncedJsonAtomic(this.path, validated);
  }
}

export function parsePostSearchV5RoutedBuilderState(
  value: unknown,
): PostSearchV5RoutedBuilderState {
  if (!isRecord(value)
    || !hasExactKeys(value, STATE_KEYS)
    || value.format !== POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT
    || (value.status !== 'building' && value.status !== 'complete')
    || typeof value.configurationSha256 !== 'string'
    || !HEX_64.test(value.configurationSha256)
    || !isCanonicalPublicNhash(value.sourceEventRoot)
    || typeof value.publisherId !== 'string'
    || !HEX_64.test(value.publisherId)
    || !nonNegativeInteger(value.generatedAt)
    || !Array.isArray(value.completedKinds)
    || !Array.isArray(value.batches)
    || !isRecord(value.kindReports)
    || (value.catalogRoot !== null && !isCanonicalPublicNhash(value.catalogRoot))) {
    throw new Error('Invalid post-search v5 routed builder state');
  }
  const completedKinds = parseCompletedKinds(value.completedKinds);
  const batches = value.batches.map((batch, index) => parseBatch(batch, index));
  const leveledRuns = parsePostSearchV5LeveledRunState(value.leveledRuns);
  const runCatalog = postSearchV5RunCatalog(leveledRuns);
  const documentCount = batches.reduce((sum, batch) => safeAdd(sum, batch.documentCount), 0);
  if (leveledRuns.nextBatch !== batches.length || runCatalog.documentCount !== documentCount) {
    throw new Error('Post-search v5 routed builder batches do not match durable runs');
  }
  const deletionReport = parseDeletionReport(value.deletionReport);
  const kindReports: Record<string, PostSearchKindReport> = {};
  for (const [kind, report] of Object.entries(value.kindReports)) {
    if (!POST_SEARCH_KINDS.includes(Number(kind) as (typeof POST_SEARCH_KINDS)[number])) {
      throw new Error('Invalid post-search v5 routed builder kind report');
    }
    kindReports[kind] = parseKindReport(report, kind);
  }
  const catalogRoot = value.catalogRoot as string | null;
  if ((value.status === 'complete') !== (catalogRoot !== null)
    || (value.status === 'complete' && completedKinds.length !== POST_SEARCH_KINDS.length)) {
    throw new Error('Post-search v5 routed builder completion state is inconsistent');
  }
  return {
    format: POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
    status: value.status,
    configurationSha256: value.configurationSha256,
    sourceEventRoot: value.sourceEventRoot,
    publisherId: value.publisherId,
    generatedAt: value.generatedAt,
    completedKinds,
    batches,
    leveledRuns,
    deletionReport,
    kindReports,
    catalogRoot,
  };
}

function parseCompletedKinds(value: unknown[]): number[] {
  const kinds = value.map(Number);
  if (kinds.some((kind, index) => kind !== POST_SEARCH_KINDS[index])) {
    throw new Error('Post-search v5 routed completed kinds are not a canonical prefix');
  }
  return kinds;
}

function parseBatch(value: unknown, index: number): PostSearchV5RoutedSourceBatch {
  if (!isRecord(value) || !hasExactKeys(value, BATCH_KEYS)
    || value.batch !== index
    || !positiveInteger(value.documentCount)
    || !POST_SEARCH_KINDS.includes(Number(value.kind) as (typeof POST_SEARCH_KINDS)[number])
    || !nonNegativeInteger(value.since)
    || !nonNegativeInteger(value.until)
    || Number(value.since) > Number(value.until)) {
    throw new Error(`Invalid post-search v5 routed source batch ${index}`);
  }
  return {
    batch: index,
    documentCount: value.documentCount,
    kind: Number(value.kind),
    since: value.since,
    until: value.until,
  };
}

function parseReport(
  value: unknown,
  keys: readonly string[],
  label: string,
): Record<string, number> {
  if (!isRecord(value) || !hasExactKeys(value, keys)
    || keys.some((key) => !nonNegativeInteger(value[key]))) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return Object.fromEntries(keys.map((key) => [key, Number(value[key])]));
}

function parseDeletionReport(value: unknown): PostSearchDeletionReport {
  const parsed = parseReport(value, DELETION_KEYS, 'deletion report');
  return {
    scanned: parsed.scanned!,
    invalid: parsed.invalid!,
    valid: parsed.valid!,
    exactTombstones: parsed.exactTombstones!,
    addressTombstones: parsed.addressTombstones!,
  };
}

function parseKindReport(value: unknown, kind: string): PostSearchKindReport {
  const parsed = parseReport(value, REPORT_KEYS, `kind ${kind} report`);
  return {
    scanned: parsed.scanned!,
    invalid: parsed.invalid!,
    exactDeleted: parsed.exactDeleted!,
    addressDeleted: parsed.addressDeleted!,
    superseded: parsed.superseded!,
    visible: parsed.visible!,
  };
}

function isCanonicalPublicNhash(value: unknown): value is string {
  if (typeof value !== 'string') {return false;}
  try {
    const root = nhashDecode(value);
    return root.key === undefined && nhashEncode(root) === value;
  } catch {
    return false;
  }
}

function positiveInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && Number(value) > 0;
}

function nonNegativeInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && Number(value) >= 0;
}

function safeAdd(left: number, right: number): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error('Post-search v5 routed builder state exceeds integer capacity');
  }
  return result;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasExactKeys(value: Record<string, unknown>, expected: readonly string[]): boolean {
  const actual = Object.keys(value).sort();
  const wanted = [...expected].sort();
  return actual.length === wanted.length
    && actual.every((key, index) => key === wanted[index]);
}

function isErrno(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code;
}

async function syncDirectory(path: string): Promise<void> {
  const handle = await open(path, 'r');
  try {await handle.sync();} finally {await handle.close();}
}

async function writeFsyncedJsonAtomic(path: string, value: unknown): Promise<void> {
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const temporary = `${path}.tmp-${process.pid}-${randomBytes(8).toString('hex')}`;
  try {
    const handle = await open(temporary, 'wx', 0o600);
    try {
      await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`);
      await handle.sync();
    } finally {
      await handle.close();
    }
    await rename(temporary, path);
    await syncDirectory(directory);
  } finally {
    await rm(temporary, { force: true });
  }
}
