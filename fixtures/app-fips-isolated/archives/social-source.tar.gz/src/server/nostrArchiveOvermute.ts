import { nhashEncode, type CID } from '@hashtree/core';
import type { SocialGraph } from 'nostr-social-graph';
import type { NostrArchiveCoverageReader } from './nostrArchiveCoverage';
import { verifyPostSearchEvent } from './postSearchProjection';

export const NOSTR_ARCHIVE_OVERMUTE_FORMAT = 'iris-social/nostr-archive-overmute@1';
export const NOSTR_ARCHIVE_OVERMUTE_THRESHOLD = 1;
const MAX_OVERMUTED_EVENT_SAMPLES = 8;
const SHA256_HEX = /^[0-9a-f]{64}$/;

export interface NostrArchiveOvermuteOptions {
  socialGraphSha256: string;
  threshold?: number;
  /** Omit to leave the graph-size floor disabled. */
  minEligibleGraphAuthors?: number;
}

export interface NostrArchiveSocialGraphReport {
  root: string;
  sha256: string;
  threshold: number;
  authorsScanned: number;
  eligibleAuthors: number;
  overmutedAuthors: number;
  minEligibleAuthors: number | null;
}

export interface NostrSocialGraphDistanceCensus {
  distance: number;
  authors: number;
  eligibleAuthors: number;
  overmutedAuthors: number;
}

export interface NostrSocialGraphCensus {
  root: string;
  threshold: number;
  reachableAuthors: number;
  eligibleAuthors: number;
  overmutedAuthors: number;
  byDistance: NostrSocialGraphDistanceCensus[];
  eligiblePubkeys: string[];
  overmutedPubkeys: Set<string>;
}

export interface NostrArchiveOvermutedEventSample {
  id: string;
  kind: number;
  pubkey: string;
}

export interface NostrArchiveOvermuteCandidateReport {
  sourceRoot: string;
  requiredKinds: number[];
  scanned: number;
  valid: number;
  invalid: number;
  overmutedValid: number;
  overmutedEventSamples: NostrArchiveOvermutedEventSample[];
}

export interface NostrArchiveOvermuteReport {
  format: typeof NOSTR_ARCHIVE_OVERMUTE_FORMAT;
  socialGraph: NostrArchiveSocialGraphReport;
  candidate: NostrArchiveOvermuteCandidateReport;
  passed: boolean;
  failures: string[];
}

/**
 * Match nostr-social-graph / Iris Client overmute semantics without changing
 * the supplied in-memory graph for archive authors absent from the snapshot.
 */
export function isNostrSocialGraphAuthorOvermuted(
  graph: SocialGraph,
  pubkey: string,
  threshold = NOSTR_ARCHIVE_OVERMUTE_THRESHOLD,
): boolean {
  const normalizedThreshold = validateThreshold(threshold);
  if (pubkey === graph.getRoot()) {
    return false;
  }

  const { ids } = graph.getInternalData();
  if (!ids.has(pubkey)) {
    return false;
  }
  const muters = graph.getUserMutedBy(pubkey);
  if (muters.size === 0) {
    return false;
  }
  if (muters.has(graph.getRoot())) {
    return true;
  }

  const nearestOpinion = Object.entries(graph.stats(pubkey))
    .sort(([left], [right]) => Number(left) - Number(right))
    .map(([, counts]) => counts)
    .find(({ followers, muters: count }) => followers + count > 0);
  return nearestOpinion
    ? nearestOpinion.muters * normalizedThreshold > nearestOpinion.followers
    : false;
}

/**
 * Build a deterministic, read-only crawl census. The eligible list is the only
 * author set that content/history jobs may schedule; the overmuted set includes
 * known unreachable identities too so the immutable archive gate fails closed.
 */
export function censusNostrSocialGraph(
  graph: SocialGraph,
  threshold = NOSTR_ARCHIVE_OVERMUTE_THRESHOLD,
): NostrSocialGraphCensus {
  const normalizedThreshold = validateThreshold(threshold);
  const byDistance = new Map<number, NostrSocialGraphDistanceCensus>();
  const eligibleAuthors: Array<{ distance: number; pubkey: string }> = [];
  const overmutedPubkeys = new Set<string>();
  const { ids } = graph.getInternalData();

  for (const [, pubkey] of ids) {
    const overmuted = isNostrSocialGraphAuthorOvermuted(
      graph,
      pubkey,
      normalizedThreshold,
    );
    if (overmuted) {
      overmutedPubkeys.add(pubkey);
    }
    const distance = graph.getFollowDistance(pubkey);
    if (!Number.isSafeInteger(distance) || distance < 0 || distance >= 1_000) {
      continue;
    }
    const row = byDistance.get(distance) ?? {
      distance,
      authors: 0,
      eligibleAuthors: 0,
      overmutedAuthors: 0,
    };
    row.authors = increment(row.authors, `social graph distance ${distance} authors`);
    if (overmuted) {
      row.overmutedAuthors = increment(
        row.overmutedAuthors,
        `social graph distance ${distance} overmuted authors`,
      );
    } else {
      row.eligibleAuthors = increment(
        row.eligibleAuthors,
        `social graph distance ${distance} eligible authors`,
      );
      eligibleAuthors.push({ distance, pubkey });
    }
    byDistance.set(distance, row);
  }

  eligibleAuthors.sort((left, right) => (
    left.distance - right.distance
      || (left.pubkey < right.pubkey ? -1 : left.pubkey > right.pubkey ? 1 : 0)
  ));
  const distances = [...byDistance.values()].sort((left, right) => (
    left.distance - right.distance
  ));
  return {
    root: graph.getRoot(),
    threshold: normalizedThreshold,
    reachableAuthors: distances.reduce((sum, row) => sum + row.authors, 0),
    eligibleAuthors: distances.reduce((sum, row) => sum + row.eligibleAuthors, 0),
    overmutedAuthors: distances.reduce((sum, row) => sum + row.overmutedAuthors, 0),
    byDistance: distances,
    eligiblePubkeys: eligibleAuthors.map(({ pubkey }) => pubkey),
    overmutedPubkeys,
  };
}

/**
 * Read-only candidate gate: census the supplied graph, then stream only the
 * selected immutable archive root and reject signature-valid events authored
 * by identities that graph considers overmuted.
 */
export async function reportNostrArchiveOvermute(
  reader: NostrArchiveCoverageReader,
  sourceRoot: CID,
  requiredKinds: readonly number[],
  graph: SocialGraph,
  options: NostrArchiveOvermuteOptions,
): Promise<NostrArchiveOvermuteReport> {
  const kinds = normalizeRequiredKinds(requiredKinds);
  const threshold = validateThreshold(
    options.threshold ?? NOSTR_ARCHIVE_OVERMUTE_THRESHOLD,
  );
  const socialGraphSha256 = validateSha256(options.socialGraphSha256);
  const minimum = validateOptionalMinimum(options.minEligibleGraphAuthors);
  const census = censusNostrSocialGraph(graph, threshold);
  const socialGraph: NostrArchiveSocialGraphReport = {
    root: census.root,
    sha256: socialGraphSha256,
    threshold: census.threshold,
    authorsScanned: census.reachableAuthors,
    eligibleAuthors: census.eligibleAuthors,
    overmutedAuthors: census.overmutedAuthors,
    minEligibleAuthors: minimum,
  };
  const candidate: NostrArchiveOvermuteCandidateReport = {
    sourceRoot: nhashEncode(sourceRoot),
    requiredKinds: kinds,
    scanned: 0,
    valid: 0,
    invalid: 0,
    overmutedValid: 0,
    overmutedEventSamples: [],
  };

  await reader.validateSnapshot?.(sourceRoot);
  await reader.validateArchiveSnapshot?.(sourceRoot);
  for (const kind of kinds) {
    for await (const event of reader.streamKind(sourceRoot, kind)) {
      candidate.scanned = increment(candidate.scanned, 'candidate scanned');
      if (event.kind !== kind || !verifyPostSearchEvent(event)) {
        candidate.invalid = increment(candidate.invalid, 'candidate invalid');
        continue;
      }
      candidate.valid = increment(candidate.valid, 'candidate valid');
      if (!census.overmutedPubkeys.has(event.pubkey)) {
        continue;
      }
      candidate.overmutedValid = increment(
        candidate.overmutedValid,
        'candidate overmuted valid',
      );
      if (candidate.overmutedEventSamples.length < MAX_OVERMUTED_EVENT_SAMPLES) {
        candidate.overmutedEventSamples.push({
          id: event.id,
          kind: event.kind,
          pubkey: event.pubkey,
        });
      }
    }
  }

  const failures: string[] = [];
  if (minimum !== null && socialGraph.eligibleAuthors < minimum) {
    failures.push(`social graph eligible authors ${socialGraph.eligibleAuthors} < ${minimum}`);
  }
  if (candidate.overmutedValid > 0) {
    failures.push(candidateOvermuteFailure(candidate));
  }
  return {
    format: NOSTR_ARCHIVE_OVERMUTE_FORMAT,
    socialGraph,
    candidate,
    passed: failures.length === 0,
    failures,
  };
}

function candidateOvermuteFailure(report: NostrArchiveOvermuteCandidateReport): string {
  const first = report.overmutedEventSamples[0];
  const noun = report.overmutedValid === 1 ? 'event' : 'events';
  const authorNoun = report.overmutedValid === 1 ? 'author' : 'authors';
  const sample = report.overmutedEventSamples
    .map(({ pubkey, id }) => `${pubkey}/${id}`)
    .join(',');
  if (!first) {
    throw new Error('Missing overmuted archive event diagnostic');
  }
  return `candidate contains ${report.overmutedValid} signature-valid ${noun} from overmuted `
    + `${authorNoun}: ${sample}`;
}

function normalizeRequiredKinds(values: readonly number[]): number[] {
  const kinds = [...new Set(values.map((value) => {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new Error('Nostr archive required kind must be a non-negative integer');
    }
    return value;
  }))].sort((left, right) => left - right);
  if (kinds.length === 0) {
    throw new Error('At least one Nostr archive required kind is required');
  }
  return kinds;
}

function validateThreshold(value: number): number {
  if (!Number.isFinite(value) || value < 0) {
    throw new Error('Nostr archive overmute threshold must be a non-negative finite number');
  }
  return value;
}

function validateOptionalMinimum(value: number | undefined): number | null {
  if (value === undefined) {
    return null;
  }
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error('Minimum eligible social graph authors must be a positive integer');
  }
  return value;
}

function validateSha256(value: string): string {
  if (!SHA256_HEX.test(value)) {
    throw new Error('Social graph SHA-256 must be lowercase 64-character hex');
  }
  return value;
}

function increment(value: number, name: string): number {
  const result = value + 1;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Invalid Nostr archive ${name}`);
  }
  return result;
}
