import {
  nhashDecode,
  nhashEncode,
  type CID,
  type Store,
} from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import {
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_DOCUMENT_FORMAT,
  POST_SEARCH_KINDS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
  buildPostSearchSegment,
  writePostSearchCatalog,
} from '../lib/postSearch';
import {
  createPostSearchKindReport,
  isSelectedPostSearchWinner,
  scanPostSearchDeletions,
  selectPostSearchAddressableWinners,
  verifyPostSearchEvent,
  visiblePostSearchEvent,
  type PostSearchDeletionReport,
  type PostSearchEventVerifier,
  type PostSearchKindReport,
  type PostSearchKindCursor,
  type PostSearchSnapshotReader,
} from './postSearchProjection';
import { createPostSearchBuilderProgress, type PostSearchBuilderProgress } from './postSearchBuilderProgress';
import {
  deserializePostSearchSegment,
  postSearchCoverageFromSegments,
  serializePostSearchSegment,
} from './postSearchBuilderSegments';
import {
  POST_SEARCH_BUILDER_STATE_FORMAT,
  isPostSearchBuilderState,
  type PostSearchBuilderState,
  type PostSearchBuilderStateStore,
} from './postSearchBuilderState';
import {
  POST_SEARCH_AUTHOR_DELETION_POLICY,
  POST_SEARCH_AUTHOR_METADATA_MAX_BYTES,
  POST_SEARCH_AUTHOR_TERM_MAX_BYTES,
  POST_SEARCH_AUTHOR_TERMS_MAX_BYTES,
  PostSearchAuthorTermsResolver,
} from './postSearchAuthorTerms';
import {
  POST_SEARCH_POINTER_HANDOFF_FORMAT,
  createPostSearchPointerTemplate,
  validateSignedPostSearchPointer,
  type PostSearchPointerHandoff,
  type PostSearchPointerSigner,
} from './postSearchPointer';
export { HashtreeNostrSnapshotReader } from './postSearchSnapshotReader';
export {
  POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
  PostSearchCatalogTailBuilder,
  PostSearchFullRebuildRequiredError,
  isPostSearchTailBuilderState,
} from './postSearchCatalogTailBuilder';
export type {
  PostSearchCatalogTailBuildResult,
  PostSearchCatalogTailBuilderOptions,
  PostSearchTailBuilderState,
  PostSearchTailBuilderStateStore,
  PostSearchTailProgress,
} from './postSearchCatalogTailBuilder';

export type { PostSearchBuilderProgress } from './postSearchBuilderProgress';
export {
  POST_SEARCH_BUILDER_STATE_FORMAT,
  isPostSearchBuilderState,
} from './postSearchBuilderState';
export type {
  PostSearchBuilderState,
  PostSearchBuilderStateStore,
} from './postSearchBuilderState';
export type { PersistedPostSearchSegment } from './postSearchBuilderSegments';
export {
  POST_SEARCH_POINTER_CONTENT_FORMAT,
  POST_SEARCH_POINTER_HANDOFF_FORMAT,
  createPostSearchPointerTemplate,
} from './postSearchPointer';
export type {
  PostSearchPointerHandoff,
  PostSearchPointerSigner,
  PostSearchPointerTemplate,
} from './postSearchPointer';

const DEFAULT_SEGMENT_MAX_DOCUMENTS = 25_000;
const DEFAULT_SEGMENT_MAX_BYTES = 64 * 1024 * 1024;
// Avoid 1k segment fanout while bounding in-memory loss below the 25k hard maximum.
const DEFAULT_CHECKPOINT_DOCUMENTS = 5_000;
const DEFAULT_PROGRESS_DOCUMENTS = 250;
const HEX_64 = /^[0-9a-f]{64}$/;
const textEncoder = new TextEncoder();

export interface PostSearchCatalogBuilderOptions {
  snapshotRoot: CID;
  snapshotReader: PostSearchSnapshotReader;
  outputStore: Store;
  stateStore: PostSearchBuilderStateStore;
  publisherId: string;
  treeName: string;
  segmentMaxDocuments?: number;
  segmentMaxBytes?: number;
  checkpointDocuments?: number;
  progressDocuments?: number;
  now?: () => number;
  verifyEvent?: PostSearchEventVerifier;
  signer?: PostSearchPointerSigner;
  onProgress?: (progress: PostSearchBuilderProgress) => void;
}

export interface PostSearchCatalogBuildResult {
  catalogRoot: CID;
  handoff: PostSearchPointerHandoff;
  state: PostSearchBuilderState;
  resumed: boolean;
}

export class PostSearchCatalogBuilder {
  private readonly options: Required<Pick<
    PostSearchCatalogBuilderOptions,
    | 'segmentMaxDocuments'
    | 'segmentMaxBytes'
    | 'checkpointDocuments'
    | 'progressDocuments'
    | 'now'
    | 'verifyEvent'
  >> & PostSearchCatalogBuilderOptions;
  private readonly sourceEventRoot: string;
  private readonly configurationKey: string;
  private readonly authorTermsResolver: PostSearchAuthorTermsResolver;

  constructor(options: PostSearchCatalogBuilderOptions) {
    validatePublisherId(options.publisherId);
    validateTreeName(options.treeName);
    const segmentMaxDocuments = positiveInteger(
      options.segmentMaxDocuments ?? DEFAULT_SEGMENT_MAX_DOCUMENTS,
      'segmentMaxDocuments',
    );
    this.options = {
      ...options,
      segmentMaxDocuments,
      segmentMaxBytes: positiveInteger(
        options.segmentMaxBytes ?? DEFAULT_SEGMENT_MAX_BYTES,
        'segmentMaxBytes',
      ),
      checkpointDocuments: Math.min(segmentMaxDocuments, positiveInteger(
        options.checkpointDocuments ?? DEFAULT_CHECKPOINT_DOCUMENTS,
        'checkpointDocuments',
      )),
      progressDocuments: positiveInteger(
        options.progressDocuments ?? DEFAULT_PROGRESS_DOCUMENTS,
        'progressDocuments',
      ),
      now: options.now ?? (() => Math.floor(Date.now() / 1_000)),
      verifyEvent: options.verifyEvent ?? verifyPostSearchEvent,
    };
    this.sourceEventRoot = nhashEncode(options.snapshotRoot);
    this.authorTermsResolver = new PostSearchAuthorTermsResolver({
      snapshotRoot: options.snapshotRoot,
      snapshotReader: options.snapshotReader,
      verifyEvent: this.options.verifyEvent,
    });
    this.configurationKey = JSON.stringify({
      builderStateFormat: POST_SEARCH_BUILDER_STATE_FORMAT,
      catalogFormat: POST_SEARCH_CATALOG_FORMAT,
      documentFormat: POST_SEARCH_DOCUMENT_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
      visibleProjection: POST_SEARCH_VISIBLE_PROJECTION,
      authorTermsProjection: POST_SEARCH_AUTHOR_TERMS_PROJECTION,
      buildOptions: POST_SEARCH_BUILD_OPTIONS,
      authorMetadataMaxBytes: POST_SEARCH_AUTHOR_METADATA_MAX_BYTES,
      authorTermMaxBytes: POST_SEARCH_AUTHOR_TERM_MAX_BYTES,
      authorTermsMaxBytes: POST_SEARCH_AUTHOR_TERMS_MAX_BYTES,
      authorDeletionPolicy: POST_SEARCH_AUTHOR_DELETION_POLICY,
      replaceableWinnerPolicy: 'created-at-desc-event-id-asc@1',
      segmentMaxDocuments: this.options.segmentMaxDocuments,
      segmentMaxBytes: this.options.segmentMaxBytes,
      checkpointDocuments: this.options.checkpointDocuments,
      progressDocuments: this.options.progressDocuments,
      treeName: options.treeName,
    });
  }

  async build(): Promise<PostSearchCatalogBuildResult> {
    await this.options.snapshotReader.validateSnapshot?.(this.options.snapshotRoot);
    const loaded = await this.options.stateStore.load();
    const reusable = loaded && this.isReusableState(loaded) && await this.hasPersistedRoots(loaded);
    const restoredLegacyProgress = Boolean(reusable && !loaded.progress);
    if (reusable && !loaded.progress) {
      this.setProgress(
        loaded,
        loaded.status === 'complete' ? 'complete' : 'idle',
        null,
        0,
        0,
        loaded.segments.reduce((sum, segment) => sum + segment.documentCount, 0),
      );
    }
    if (reusable && loaded.status === 'complete' && loaded.catalogRoot && loaded.handoff) {
      let changed = restoredLegacyProgress;
      if (loaded.handoff.status === 'unsigned-handoff' && this.options.signer) {
        loaded.handoff = await this.createHandoff(
          nhashDecode(loaded.catalogRoot),
          loaded.generatedAt,
        );
        changed = true;
      }
      if (changed) {
        await this.saveState(loaded);
      }
      return {
        catalogRoot: nhashDecode(loaded.catalogRoot),
        handoff: loaded.handoff,
        state: loaded,
        resumed: true,
      };
    }

    const state = reusable ? loaded : this.initialState();
    const needsProjection = POST_SEARCH_KINDS.some((kind) =>
      !state.completedKinds.includes(kind));
    let deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>> | null = null;
    if (needsProjection) {
      this.setProgress(state, 'scanning-deletions', 5, 0, 0, 0);
      await this.saveState(state);
      let deletionWork = 0;
      let deletionSavedWork = 0;
      deletions = await scanPostSearchDeletions(
        this.options.snapshotReader,
        this.options.snapshotRoot,
        this.options.verifyEvent,
        (report) => {
          deletionWork += 1;
          if (deletionWork - deletionSavedWork < this.options.progressDocuments) {
            return;
          }
          deletionSavedWork = deletionWork;
          this.setProgress(state, 'scanning-deletions', 5, report.scanned, report.valid, 0);
          return this.saveState(state);
        },
      );
      state.deletionReport = deletions.report;
      state.status = 'building';
      state.catalogRoot = null;
      state.handoff = null;
      this.setProgress(
        state,
        'scanning-deletions',
        5,
        deletions.report.scanned,
        deletions.report.valid,
        0,
      );
      await this.saveState(state);
    }

    for (const kind of POST_SEARCH_KINDS) {
      if (state.completedKinds.includes(kind)) {
        continue;
      }
      if (!deletions) {
        throw new Error('Missing post-search deletion projection for incomplete kinds');
      }
      const report = await this.buildKind(kind, deletions, state);
      state.kindReports[String(kind)] = report;
      state.completedKinds.push(kind);
      this.setProgress(
        state,
        'idle',
        null,
        report.scanned,
        report.visible,
        state.progress?.persisted ?? 0,
      );
      await this.saveState(state);
    }

    const segments = state.segments.map(deserializePostSearchSegment);
    const catalogRoot = await writePostSearchCatalog(this.options.outputStore, {
      publisherId: this.options.publisherId,
      generatedAt: state.generatedAt,
      source: {
        eventRoot: this.sourceEventRoot,
        projection: POST_SEARCH_VISIBLE_PROJECTION,
        coverage: postSearchCoverageFromSegments(segments),
      },
      segments,
    });
    const handoff = await this.createHandoff(catalogRoot, state.generatedAt);
    state.status = 'complete';
    state.catalogRoot = nhashEncode(catalogRoot);
    state.handoff = handoff;
    this.setProgress(
      state,
      'complete',
      null,
      Object.values(state.kindReports).reduce((sum, report) => sum + report.scanned, 0),
      segments.reduce((sum, segment) => sum + segment.documentCount, 0),
      segments.reduce((sum, segment) => sum + segment.documentCount, 0),
    );
    await this.saveState(state);
    return { catalogRoot, handoff, state, resumed: Boolean(reusable) };
  }

  private async buildKind(
    kind: number,
    deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>>,
    state: PostSearchBuilderState,
  ): Promise<PostSearchKindReport> {
    const reportKey = String(kind);
    const persistedCursor = state.kindCursors[reportKey] ?? null;
    const mayResumeFromCursor = kind < 30_000 || kind >= 40_000;
    const resumeCursor = mayResumeFromCursor ? persistedCursor : null;
    let durableDocuments = state.segments
      .filter((segment) => segment.kinds.length === 1 && segment.kinds[0] === kind)
      .reduce((sum, segment) => sum + segment.documentCount, 0);
    let persistedReport = resumeCursor ? state.kindReports[reportKey] : null;
    if (resumeCursor && state.durableKindReports !== true) {
      persistedReport = await this.rebuildDurableKindReport(
        kind,
        resumeCursor,
        deletions,
      );
      if (persistedReport.visible !== durableDocuments) {
        throw new Error(
          `Rebuilt post-search kind ${kind} report does not match durable segment documents`,
        );
      }
    } else if (resumeCursor && persistedReport?.visible !== durableDocuments) {
      throw new Error(`Post-search kind ${kind} report does not match its durable cursor`);
    }
    const report = persistedReport
      ? { ...persistedReport }
      : createPostSearchKindReport();
    let durableReport = persistedReport
      ? { ...persistedReport }
      : createPostSearchKindReport();
    const persistedDocuments = resumeCursor ? 0 : durableDocuments;
    let phase: PostSearchBuilderProgress['phase'] = kind >= 30_000 && kind < 40_000
      ? 'selecting-winners'
      : 'building-segments';
    let work = 0;
    let reportedWork = 0;
    const emitLiveProgress = (): void => {
      reportedWork = work;
      this.options.onProgress?.(createPostSearchBuilderProgress(
        phase,
        kind,
        report.scanned,
        report.visible,
        durableDocuments,
        positiveInteger(this.options.now(), 'progress updatedAt', true),
      ));
    };
    const saveDurableProgress = (): Promise<void> => {
      state.durableKindReports = true;
      state.kindReports[reportKey] = { ...durableReport };
      this.setProgress(
        state,
        phase,
        kind,
        durableReport.scanned,
        durableReport.visible,
        durableDocuments,
      );
      return this.saveState(state);
    };
    const recordWork = (): void => {
      work += 1;
      if (work - reportedWork >= this.options.progressDocuments) {
        emitLiveProgress();
      }
    };
    await saveDurableProgress();
    const winners = phase === 'selecting-winners'
      ? await selectPostSearchAddressableWinners(
          this.options.snapshotReader,
          this.options.snapshotRoot,
          kind,
          deletions,
          report,
          this.options.verifyEvent,
          recordWork,
        )
      : null;
    if (winners) {
      phase = 'building-segments';
      emitLiveProgress();
    }
    let batch: RawEvent[] = [];
    let batchBytes = 0;
    let batchCursor: PostSearchKindCursor | null = null;
    let batchReport: PostSearchKindReport | null = null;

    const flush = async (): Promise<void> => {
      if (batch.length === 0) {
        return;
      }
      if (!batchCursor || !batchReport) {
        throw new Error(`Post-search kind ${kind} batch is missing its durable cursor report`);
      }
      const authorNames = await this.authorTermsResolver.resolve(batch, deletions);
      const segment = await buildPostSearchSegment(this.options.outputStore, batch, { authorNames });
      state.segments.push(serializePostSearchSegment(segment));
      durableDocuments += batch.length;
      if (mayResumeFromCursor) {
        state.kindCursors[reportKey] = batchCursor;
      }
      durableReport = { ...batchReport };
      await saveDurableProgress();
      batch = [];
      batchBytes = 0;
      batchCursor = null;
      batchReport = null;
    };

    for await (const event of this.options.snapshotReader.streamKind(
      this.options.snapshotRoot,
      kind,
      resumeCursor ? { after: resumeCursor } : {},
    )) {
      const visible = winners
        ? isSelectedPostSearchWinner(event, winners, this.options.verifyEvent)
        : visiblePostSearchEvent(event, deletions, report, this.options.verifyEvent);
      if (visible) {
        report.visible += 1;
        if (resumeCursor || report.visible > persistedDocuments) {
          const eventBytes = textEncoder.encode(JSON.stringify(event)).length;
          if (batch.length > 0 && batchBytes + eventBytes > this.options.segmentMaxBytes) {
            await flush();
          }
          batch.push(event);
          batchBytes += eventBytes;
          batchCursor = { createdAt: event.created_at, eventId: event.id };
          batchReport = { ...report };
          if (batch.length >= this.options.checkpointDocuments
            || batch.length >= this.options.segmentMaxDocuments) {
            await flush();
          }
        }
      }
      recordWork();
    }
    await flush();
    if (work !== reportedWork) {
      emitLiveProgress();
    }
    if (report.visible < persistedDocuments) {
      throw new Error(`Persisted post-search kind ${kind} progress exceeds the immutable snapshot`);
    }
    return report;
  }

  private async rebuildDurableKindReport(
    kind: number,
    cursor: PostSearchKindCursor,
    deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>>,
  ): Promise<PostSearchKindReport> {
    const report = createPostSearchKindReport();
    for await (const event of this.options.snapshotReader.streamKind(
      this.options.snapshotRoot,
      kind,
    )) {
      if (visiblePostSearchEvent(event, deletions, report, this.options.verifyEvent)) {
        report.visible += 1;
      }
      if (event.created_at === cursor.createdAt && event.id === cursor.eventId) {
        return report;
      }
    }
    throw new Error(`Post-search kind ${kind} durable cursor is missing from the immutable snapshot`);
  }

  private async createHandoff(catalogRoot: CID, createdAt: number): Promise<PostSearchPointerHandoff> {
    const unsignedEvent = createPostSearchPointerTemplate({
      catalogRoot,
      sourceEventRoot: this.sourceEventRoot,
      treeName: this.options.treeName,
      createdAt,
    });
    const signedEvent = this.options.signer
      ? await this.options.signer.sign(structuredClone(unsignedEvent))
      : null;
    if (signedEvent) {
      validateSignedPostSearchPointer(
        signedEvent,
        this.options.publisherId,
        this.options.treeName,
        catalogRoot,
        unsignedEvent,
      );
    }
    return {
      format: POST_SEARCH_POINTER_HANDOFF_FORMAT,
      status: signedEvent ? 'signed-handoff' : 'unsigned-handoff',
      publisherId: this.options.publisherId,
      catalogRoot: nhashEncode(catalogRoot),
      sourceEventRoot: this.sourceEventRoot,
      treeName: this.options.treeName,
      unsignedEvent,
      signedEvent,
      publication: {
        required: true,
        transport: 'nostr-replaceable-event',
        blockAvailability: 'required-before-event',
      },
    };
  }


  private initialState(): PostSearchBuilderState {
    const generatedAt = positiveInteger(this.options.now(), 'generatedAt', true);
    return {
      format: POST_SEARCH_BUILDER_STATE_FORMAT,
      durableKindReports: true,
      status: 'building',
      sourceEventRoot: this.sourceEventRoot,
      publisherId: this.options.publisherId,
      treeName: this.options.treeName,
      configurationKey: this.configurationKey,
      generatedAt,
      completedKinds: [],
      segments: [],
      kindCursors: {},
      deletionReport: emptyDeletionReport(),
      kindReports: {},
      progress: createPostSearchBuilderProgress('idle', null, 0, 0, 0, generatedAt),
      catalogRoot: null,
      handoff: null,
    };
  }

  private isReusableState(state: PostSearchBuilderState): boolean {
    return isPostSearchBuilderState(state)
      && state.sourceEventRoot === this.sourceEventRoot
      && state.publisherId === this.options.publisherId
      && state.treeName === this.options.treeName
      && state.configurationKey === this.configurationKey;
  }

  private setProgress(
    state: PostSearchBuilderState,
    phase: PostSearchBuilderProgress['phase'],
    currentKind: number | null,
    scanned: number,
    accepted: number,
    persisted: number,
  ): void {
    state.progress = createPostSearchBuilderProgress(
      phase,
      currentKind,
      scanned,
      accepted,
      persisted,
      positiveInteger(this.options.now(), 'progress updatedAt', true),
    );
  }

  private async saveState(state: PostSearchBuilderState): Promise<void> {
    await this.options.stateStore.save(state);
    if (state.progress) {
      this.options.onProgress?.({ ...state.progress });
    }
  }

  private async hasPersistedRoots(state: PostSearchBuilderState): Promise<boolean> {
    const roots = state.segments.flatMap((segment) => [
      nhashDecode(segment.root),
      ...(segment.routingRoot ? [nhashDecode(segment.routingRoot)] : []),
    ]);
    if (state.catalogRoot) {
      roots.push(nhashDecode(state.catalogRoot));
    }
    return (await Promise.all(roots.map(async (root) => await this.options.outputStore.has(root.hash))))
      .every(Boolean);
  }
}

function emptyDeletionReport(): PostSearchDeletionReport {
  return { scanned: 0, invalid: 0, valid: 0, exactTombstones: 0, addressTombstones: 0 };
}

function validatePublisherId(value: string): string {
  if (!HEX_64.test(value)) {
    throw new Error('Post search builder publisherId must be a lowercase Nostr pubkey');
  }
  return value;
}

function validateTreeName(value: string): string {
  if (!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(value)) {
    throw new Error('Invalid post search pointer tree name');
  }
  return value;
}

function positiveInteger(value: number, name: string, allowZero = false): number {
  if (!Number.isInteger(value) || (allowZero ? value < 0 : value <= 0)) {
    throw new Error(`Invalid post search builder ${name}`);
  }
  return value;
}
