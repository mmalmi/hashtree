import { nhashDecode, nhashEncode } from '@hashtree/core';

export const NATIVE_NOSTR_CRAWL_STATE_VERSION = 1 as const;
const SHA256_HEX = /^[0-9a-f]{64}$/;

export interface NativeNostrCrawlPolicy {
  base_root: string | null;
  author_allowlist_sha256: string;
  author_count: number;
  relays: string[];
  require_all_relays: boolean;
  max_events_seen: number | null;
  max_authors: number;
  max_follow_distance: number;
  max_live_bytes: number;
  author_batch_size: number;
  checkpoint_authors: number;
  per_author_event_limit: number;
  per_author_live_bytes: number;
  fetch_timeout_millis: number;
  relay_event_max_bytes: number;
  global_relay_scan: boolean;
  full_author_history: boolean;
  negentropy_only: boolean;
  relay_page_size: number;
  max_relay_pages: number;
  kinds: number[];
}

export interface NativeNostrCrawlState {
  version: typeof NATIVE_NOSTR_CRAWL_STATE_VERSION;
  author_allowlist_source: string;
  policy: NativeNostrCrawlPolicy;
  next_author: number;
  root: string | null;
  events_seen: number;
  events_selected: number;
  live_bytes_selected: number;
}

/** Validate Hashtree's durable socialgraph-index resume state at an app boundary. */
export function parseNativeNostrCrawlState(value: unknown): NativeNostrCrawlState {
  const state = record(value, 'native Nostr crawl state');
  if (state.version !== NATIVE_NOSTR_CRAWL_STATE_VERSION) {
    throw new Error('Unsupported native Nostr crawl state version');
  }
  const rawPolicy = record(state.policy, 'native Nostr crawl policy');
  const policy: NativeNostrCrawlPolicy = {
    base_root: optionalRoot(rawPolicy.base_root, 'native crawl base root'),
    author_allowlist_sha256: sha256(
      rawPolicy.author_allowlist_sha256,
      'native crawl author allowlist SHA-256',
    ),
    author_count: positiveInteger(rawPolicy.author_count, 'native crawl author count'),
    relays: stringArray(rawPolicy.relays, 'native crawl relays'),
    require_all_relays: booleanValue(
      rawPolicy.require_all_relays,
      'native crawl all-relay requirement',
    ),
    max_events_seen: optionalNonNegativeInteger(
      rawPolicy.max_events_seen,
      'native crawl max events seen',
    ),
    max_authors: positiveInteger(rawPolicy.max_authors, 'native crawl max authors'),
    max_follow_distance: nonNegativeInteger(
      rawPolicy.max_follow_distance,
      'native crawl max follow distance',
    ),
    max_live_bytes: positiveInteger(rawPolicy.max_live_bytes, 'native crawl max live bytes'),
    author_batch_size: positiveInteger(
      rawPolicy.author_batch_size,
      'native crawl author batch size',
    ),
    checkpoint_authors: positiveInteger(
      rawPolicy.checkpoint_authors,
      'native crawl checkpoint authors',
    ),
    per_author_event_limit: positiveInteger(
      rawPolicy.per_author_event_limit,
      'native crawl per-author event limit',
    ),
    per_author_live_bytes: positiveInteger(
      rawPolicy.per_author_live_bytes,
      'native crawl per-author live bytes',
    ),
    fetch_timeout_millis: positiveInteger(
      rawPolicy.fetch_timeout_millis,
      'native crawl fetch timeout',
    ),
    relay_event_max_bytes: positiveInteger(
      rawPolicy.relay_event_max_bytes,
      'native crawl relay event max bytes',
    ),
    global_relay_scan: booleanValue(rawPolicy.global_relay_scan, 'native crawl global scan'),
    full_author_history: booleanValue(
      rawPolicy.full_author_history,
      'native crawl full author history',
    ),
    negentropy_only: booleanValue(rawPolicy.negentropy_only, 'native crawl negentropy mode'),
    relay_page_size: positiveInteger(rawPolicy.relay_page_size, 'native crawl relay page size'),
    max_relay_pages: positiveInteger(rawPolicy.max_relay_pages, 'native crawl max relay pages'),
    kinds: integerArray(rawPolicy.kinds, 'native crawl kinds'),
  };
  const nextAuthor = nonNegativeInteger(state.next_author, 'native crawl next author');
  if (nextAuthor > policy.author_count) {
    throw new Error('Native crawl cursor exceeds its author count');
  }
  return {
    version: NATIVE_NOSTR_CRAWL_STATE_VERSION,
    author_allowlist_source: nonEmptyString(
      state.author_allowlist_source,
      'native crawl author allowlist source',
    ),
    policy,
    next_author: nextAuthor,
    root: optionalRoot(state.root, 'native crawl root'),
    events_seen: nonNegativeInteger(state.events_seen, 'native crawl events seen'),
    events_selected: nonNegativeInteger(state.events_selected, 'native crawl events selected'),
    live_bytes_selected: nonNegativeInteger(
      state.live_bytes_selected,
      'native crawl live bytes selected',
    ),
  };
}

function optionalRoot(value: unknown, label: string): string | null {
  if (value === null) {return null;}
  if (typeof value !== 'string') {throw new Error(`${label} must be null or a canonical nhash`);}
  try {
    if (nhashEncode(nhashDecode(value)) !== value) {throw new Error('noncanonical');}
    return value;
  } catch {
    throw new Error(`${label} must be null or a canonical nhash`);
  }
}

function record(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`${label} must be an object`);
  }
  return value as Record<string, unknown>;
}

function nonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || !value) {throw new Error(`${label} must be non-empty`);}
  return value;
}

function sha256(value: unknown, label: string): string {
  if (typeof value !== 'string' || !SHA256_HEX.test(value)) {
    throw new Error(`${label} must be lowercase hexadecimal`);
  }
  return value;
}

function positiveInteger(value: unknown, label: string): number {
  const result = nonNegativeInteger(value, label);
  if (result === 0) {throw new Error(`${label} must be positive`);}
  return result;
}

function nonNegativeInteger(value: unknown, label: string): number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {
    throw new Error(`${label} must be a non-negative integer`);
  }
  return Number(value);
}

function optionalNonNegativeInteger(value: unknown, label: string): number | null {
  return value === null ? null : nonNegativeInteger(value, label);
}

function booleanValue(value: unknown, label: string): boolean {
  if (typeof value !== 'boolean') {throw new Error(`${label} must be boolean`);}
  return value;
}

function stringArray(value: unknown, label: string): string[] {
  if (!Array.isArray(value) || value.length === 0
    || value.some((entry) => typeof entry !== 'string' || !entry)) {
    throw new Error(`${label} must be a non-empty string array`);
  }
  return [...value] as string[];
}

function integerArray(value: unknown, label: string): number[] {
  if (!Array.isArray(value) || value.length === 0) {
    throw new Error(`${label} must be a non-empty integer array`);
  }
  return value.map((entry) => nonNegativeInteger(entry, label));
}
