import type { Store } from '@hashtree/core';
import type { RankedSearchDocument, RankedSearchFieldManifest } from '@hashtree/index';
import { POST_SEARCH_BUILD_OPTIONS } from '../lib/postSearchCatalogConstants';
import { POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES } from './postSearchV5PackedPage';
import {
  createPostSearchV5RoutedRunWriter,
  readPostSearchV5RoutedRun,
  type PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRun';
import {
  POST_SEARCH_V5_RUN_DEFAULT_MAX_DOCUMENTS,
  POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
  POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES,
  POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES,
  tokenizePostSearchV5Field,
  type PostSearchV5Posting,
  type PostSearchV5TermStats,
} from './postSearchV5Run';

const K1 = 1.2;
const encoder = new TextEncoder();

type MutablePosting = PostSearchV5Posting;

export interface PostSearchV5RoutedBaseRunBuildOptions {
  maxDocuments?: number;
  maxTokenOccurrences?: number;
  maxReachableNodeCount?: number;
}

/**
 * Build one bounded level-0 routed run. Documents are retained only for this
 * source batch; the writer persists canonical packed pages rather than one
 * durable block per event.
 */
export async function buildPostSearchV5RoutedBaseRun(
  store: Store,
  input: Iterable<RankedSearchDocument>,
  options: PostSearchV5RoutedBaseRunBuildOptions = {},
): Promise<PostSearchV5RoutedRunLookup> {
  const maximumDocuments = boundedMaximum(
    options.maxDocuments ?? POST_SEARCH_V5_RUN_DEFAULT_MAX_DOCUMENTS,
    POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
    'document count',
  );
  const maximumOccurrences = boundedMaximum(
    options.maxTokenOccurrences ?? POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES,
    POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES,
    'token occurrence count',
  );
  const documents = collectDocuments(input, maximumDocuments);
  const fields = Object.entries(POST_SEARCH_BUILD_OPTIONS.fields)
    .sort(([left], [right]) => compareText(left, right));
  const totals = new Map(fields.map(([name]) => [name, 0]));
  const populated = new Map(fields.map(([name]) => [name, 0]));
  const postingsByTerm = new Map<string, MutablePosting[]>();
  const writer = createPostSearchV5RoutedRunWriter(store);
  let storedValueCount = 0;
  let tokenOccurrenceCount = 0;

  for (const document of documents) {
    const lengths: Record<string, number> = Object.create(null) as Record<string, number>;
    const documentPostings = new Map<string, MutablePosting>();
    for (const [name] of fields) {
      const tokenized = tokenizePostSearchV5Field(
        document.fields[name],
        POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
      );
      lengths[name] = tokenized.length;
      totals.set(name, safeAdd(totals.get(name) ?? 0, tokenized.length, 'field length'));
      if (tokenized.length > 0) {
        populated.set(name, safeAdd(populated.get(name) ?? 0, 1, 'populated documents'));
      }
      tokenOccurrenceCount = safeAdd(
        tokenOccurrenceCount,
        tokenized.occurrences.length,
        'token occurrences',
      );
      if (tokenOccurrenceCount > maximumOccurrences) {
        throw new Error('Post-search v5 routed base run exceeds its token occurrence capacity');
      }
      for (const occurrence of tokenized.occurrences) {
        const posting = documentPostings.get(occurrence.term)
          ?? { id: document.id, fields: Object.create(null) as MutablePosting['fields'] };
        const postingField = posting.fields[name] ?? { frequency: 0, positions: [] };
        postingField.frequency += 1;
        postingField.positions.push(occurrence.position);
        posting.fields[name] = postingField;
        documentPostings.set(occurrence.term, posting);
      }
    }
    if (document.value !== undefined) {storedValueCount += 1;}
    await writer.appendDocument(document.id, document.value === undefined
      ? { lengths }
      : { lengths, value: document.value });
    for (const [term, posting] of documentPostings) {
      const postings = postingsByTerm.get(term) ?? [];
      postings.push(posting);
      postingsByTerm.set(term, postings);
    }
  }

  let postingCount = 0;
  let postingPartCount = 0;
  for (const term of [...postingsByTerm.keys()].sort(compareText)) {
    const postings = postingsByTerm.get(term)!;
    const parts = splitPostingParts(postings);
    for (let part = 0; part < parts.length; part += 1) {
      await writer.appendPosting(term, part, parts[part]!);
    }
    await writer.appendTerm(term, termStatistics(postings, parts.length));
    postingCount = safeAdd(postingCount, postings.length, 'posting count');
    postingPartCount = safeAdd(postingPartCount, parts.length, 'posting part count');
  }
  const manifestFields: RankedSearchFieldManifest[] = fields.map(([name, options]) => ({
    name,
    boost: options.boost,
    lengthNormalization: options.lengthNormalization,
    totalLength: totals.get(name) ?? 0,
    populatedDocumentCount: populated.get(name) ?? 0,
  }));
  const built = await writer.finish({
    documentCount: documents.length,
    termCount: postingsByTerm.size,
    postingCount,
    storedValueCount,
    tokenOccurrenceCount,
    k1: K1,
    maxTokensPerField: POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
    fields: manifestFields,
    maxReachableNodeCount: options.maxReachableNodeCount,
  });
  return await readPostSearchV5RoutedRun(store, built.root, {
    expected: {
      documentCount: documents.length,
      termCount: postingsByTerm.size,
      postingCount,
      postingPartCount,
      storedValueCount,
      tokenOccurrenceCount,
      reachableNodeCount: built.manifest.reachableNodeCount,
    },
    maxReachableNodeCount: options.maxReachableNodeCount,
  });
}

function collectDocuments(
  input: Iterable<RankedSearchDocument>,
  maximum: number,
): RankedSearchDocument[] {
  const documents: RankedSearchDocument[] = [];
  for (const document of input) {
    if (documents.length >= maximum) {
      throw new Error(`Post-search v5 routed base run requires 1-${maximum} documents`);
    }
    assertRawDocument(document);
    documents.push(document);
  }
  if (documents.length === 0) {
    throw new Error(`Post-search v5 routed base run requires 1-${maximum} documents`);
  }
  documents.sort((left, right) => compareText(left.id, right.id));
  for (let index = 1; index < documents.length; index += 1) {
    if (documents[index - 1]!.id === documents[index]!.id) {
      throw new Error(`Duplicate post-search v5 routed document id: ${documents[index]!.id}`);
    }
  }
  return documents;
}

function assertRawDocument(document: RankedSearchDocument): void {
  if (!document || typeof document.id !== 'string' || document.id.length === 0
    || !document.fields || typeof document.fields !== 'object' || Array.isArray(document.fields)
    || (document.value !== undefined && typeof document.value !== 'string')) {
    throw new Error('Invalid post-search v5 routed source document');
  }
  let bytes = encoder.encode(document.id).length
    + (document.value === undefined ? 0 : encoder.encode(document.value).length);
  for (const [name, raw] of Object.entries(document.fields)) {
    bytes += encoder.encode(name).length;
    const values = typeof raw === 'string' ? [raw] : raw;
    if (!Array.isArray(values) || values.some((value) => typeof value !== 'string')) {
      throw new Error(`Invalid post-search v5 routed source document field: ${document.id}`);
    }
    for (const value of values) {bytes += encoder.encode(value).length;}
  }
  if (bytes > POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES) {
    throw new Error(`Post-search v5 routed source document exceeds its byte bound: ${document.id}`);
  }
}

function splitPostingParts(postings: readonly PostSearchV5Posting[]): PostSearchV5Posting[][] {
  const parts: PostSearchV5Posting[][] = [];
  let part: PostSearchV5Posting[] = [];
  let bytes = 2;
  for (const posting of postings) {
    const postingBytes = encoder.encode(JSON.stringify(posting)).length;
    const required = postingBytes + (part.length === 0 ? 0 : 1);
    if (part.length > 0 && bytes + required > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      parts.push(part);
      part = [];
      bytes = 2;
    }
    if (bytes + postingBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      throw new Error(`Post-search v5 routed posting exceeds its page bound: ${posting.id}`);
    }
    part.push(posting);
    bytes += postingBytes + (part.length === 1 ? 0 : 1);
  }
  if (part.length > 0) {parts.push(part);}
  return parts;
}

function termStatistics(
  postings: readonly PostSearchV5Posting[],
  postingParts: number,
): PostSearchV5TermStats {
  const fieldSets = new Map<string, { fields: string[]; documentFrequency: number }>();
  for (const posting of postings) {
    const fields = Object.keys(posting.fields).sort(compareText);
    const key = JSON.stringify(fields);
    const current = fieldSets.get(key) ?? { fields, documentFrequency: 0 };
    current.documentFrequency += 1;
    fieldSets.set(key, current);
  }
  return {
    documentFrequency: postings.length,
    fieldSets: [...fieldSets.values()].sort((left, right) =>
      compareText(JSON.stringify(left.fields), JSON.stringify(right.fields))),
    postingParts,
  };
}

function boundedMaximum(value: number, maximum: number, label: string): number {
  if (!Number.isSafeInteger(value) || value <= 0 || value > maximum) {
    throw new Error(`Invalid post-search v5 routed base run ${label}`);
  }
  return value;
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Post-search v5 routed base run ${label} exceeds capacity`);
  }
  return result;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
