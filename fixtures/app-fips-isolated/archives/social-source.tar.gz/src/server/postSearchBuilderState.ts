import { nhashDecode } from '@hashtree/core';
import type { PostSearchDeletionReport, PostSearchKindCursor, PostSearchKindReport } from './postSearchProjection';
import { isPostSearchBuilderProgress, type PostSearchBuilderProgress } from './postSearchBuilderProgress';
import type { PostSearchPointerHandoff } from './postSearchPointer';
import type { PersistedPostSearchSegment } from './postSearchBuilderSegments';

export const POST_SEARCH_BUILDER_STATE_FORMAT = 'iris-social/post-search-builder-state@4' as const;

const HEX_64 = /^[0-9a-f]{64}$/;

export interface PostSearchBuilderState {
  format: typeof POST_SEARCH_BUILDER_STATE_FORMAT;
  /** Absent only in @4 states written before report/cursor durability was enforced. */
  durableKindReports?: true;
  status: 'building' | 'complete';
  sourceEventRoot: string;
  publisherId: string;
  treeName: string;
  configurationKey: string;
  generatedAt: number;
  completedKinds: number[];
  segments: PersistedPostSearchSegment[];
  kindCursors: Record<string, PostSearchKindCursor>;
  deletionReport: PostSearchDeletionReport;
  kindReports: Record<string, PostSearchKindReport>;
  /** Absent only in builder states written before progress telemetry was introduced. */
  progress?: PostSearchBuilderProgress;
  catalogRoot: string | null;
  handoff: PostSearchPointerHandoff | null;
}

export interface PostSearchBuilderStateStore {
  load(): Promise<PostSearchBuilderState | null>;
  save(state: PostSearchBuilderState): Promise<void>;
}

export function isPostSearchBuilderState(value: unknown): value is PostSearchBuilderState {
  if (!isObject(value)
    || value.format !== POST_SEARCH_BUILDER_STATE_FORMAT
    || (value.durableKindReports !== undefined && value.durableKindReports !== true)
    || (value.status !== 'building' && value.status !== 'complete')
    || typeof value.sourceEventRoot !== 'string'
    || typeof value.publisherId !== 'string'
    || typeof value.treeName !== 'string'
    || typeof value.configurationKey !== 'string'
    || !Number.isInteger(value.generatedAt)
    || !Array.isArray(value.completedKinds)
    || !Array.isArray(value.segments)
    || !isObject(value.kindCursors)
    || !isObject(value.kindReports)
    || (value.progress !== undefined && !isPostSearchBuilderProgress(value.progress))) {
    return false;
  }
  try {
    nhashDecode(value.sourceEventRoot);
    value.segments.forEach((rawSegment) => {
      const segment = rawSegment as PersistedPostSearchSegment;
      nhashDecode(segment.root);
      if (segment.routingRoot !== null) {
        nhashDecode(segment.routingRoot);
      }
      if (!Number.isInteger(segment.routingMappingCount) || segment.routingMappingCount < 0) {
        throw new Error('invalid routing mapping count');
      }
    });
    Object.values(value.kindCursors).forEach((rawCursor) => {
      if (!isPostSearchKindCursor(rawCursor)) {
        throw new Error('invalid post search kind cursor');
      }
    });
    if (value.catalogRoot !== null) {
      nhashDecode(String(value.catalogRoot));
    }
    return true;
  } catch {
    return false;
  }
}

function isPostSearchKindCursor(value: unknown): value is PostSearchKindCursor {
  return isObject(value)
    && Number.isSafeInteger(value.createdAt)
    && Number(value.createdAt) >= 0
    && typeof value.eventId === 'string'
    && HEX_64.test(value.eventId);
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
