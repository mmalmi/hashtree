import { createHash } from 'node:crypto';
import { isAbsolute, join, relative, resolve, sep } from 'node:path';
import { MemoryStore, nhashDecode, nhashEncode, type CID, type Store } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import { HashtreeNostrEventReader } from '@hashtree/nostr-pubsub';
import { verifyEvent, type Event } from 'nostr-tools/pure';
import { decode } from 'nostr-tools/nip19';
import { canonical, type ArchiveCheckpoint, type ArchiveRunReceipt, type ArchiveSourceCoverageProof } from './archiveCheckpointOutbox';
import { validateArchiveCandidate } from './archiveCheckpointVerification';

/** Separate from the broad archive: never expand an in-progress crawl in place. */
export const MARKET_ARCHIVE_KINDS = [5, 7368, 30402] as const;
export const MARKET_ARCHIVE_LIMITS = Object.freeze({
  authors:64, relays:3, windowSeconds:31*86400, seedEvents:16, seedBytes:256*1024,
  eventBytes:64*1024, pageSize:128, pagesPerAuthor:4, eventsPerAuthor:512,
  bytesPerAuthor:2*1024*1024, fetchSeconds:8, commitEvents:128,
  authorsPerRun:1, runtimeSeconds:120, memoryBytes:1024**3,
  growthBytes:256*1024*1024, minimumFreeBytes:10*1024**3, reserveBytes:64*1024*1024,
});
// New authorities bind the current writer. Existing authorities keep their recorded executable.
export const MARKET_NATIVE_VERSION = '0.3.0';
export const MARKET_NATIVE_SOURCE = '9eb201a26dd6a0a914f9a480b6a33621ca9e635e';
export function marketArchiveConfig(rendezvousPort:number):string {
  // Native catch-up always starts a pubsub endpoint. Port zero is rejected by
  // the pinned FIPS config validator, so the operation owner reserves a private
  // non-default loopback port instead of joining the well-known rendezvous.
  if(!Number.isInteger(rendezvousPort)||rendezvousPort<1024||rendezvousPort>65535||rendezvousPort===21211){throw new Error('Reserve an isolated non-default loopback rendezvous port');}
  return `[updater]
auto_check = false
auto_install = false
[sync]
enabled = false
sync_own = false
sync_followed = false
[storage]
evict_orphans = false
[server]
enable_fips = false
fips_discovery_scope = "iris-market-index-isolated"
fips_local_rendezvous_addr = "127.0.0.1:${rendezvousPort}"
fips_relays = []
fips_websocket_seed_urls = []
fips_peers = []
fips_open_discovery_max_pending = 0
enable_fips_udp = false
fips_udp_public = false
enable_fips_webrtc = false
enable_fips_lan_discovery = false
fips_ethernet_interfaces = []
fetch_from_fips_peers = false
[nostr]
relays = []
bootstrap_follows = []
decentralized_pubsub = false
fips_pubsub_peers = []
fips_trusted_raters = []
`;
}

export interface MarketArchiveConfig {
  format:'iris-social/market-archive-config@1';
  since:number; until:number; relays:string[];
  directory:string; protectedDirectories:string[];
  rendezvousPort:number;
  /** Total relay requests, including boundary probes; omitted retains four. */
  maxPagesPerAuthor?:4|8;
  native:{path:string;version:string;sha256:string;sourceCommit:string};
  sourceCommit:string; profileIndexRefs:string[];
}
export interface MarketArchivePlan {
  format:'iris-social/market-archive-plan@1'; namespace:string; authoritySha256:string;
  sourceCommit:string; native:MarketArchiveConfig['native']; until:number;
  paths:{root:string;data:string;config:string;authors:string;seed:string;checkpoint:string;operationLock:string;receipts:string};
  protectedDirectories:string[];
  isolatedConfig:{text:string;sha256:string};
  policy:ArchiveCheckpoint['policy'];
  authors:string[]; authorText:string;
  seed:{root:string;events:Event[];eventIds:string[];sha256:string};
  bounds:{authors:number;maxEvents:number;maxInputBytes:number;authorsPerRun:number;runtimeSeconds:number;memoryBytes:number;growthBytes:number;minimumFreeBytes:number;reserveBytes:number};
  measurements:{seedEvents:number;seedJsonBytes:number;seedIndexBlocks:number;seedIndexBytes:number};
  publication:{automatic:false;treeName:string;profileIndexRefs:string[];requiredKinds:number[];requires:string[]};
}
const hash=(value:string|Uint8Array)=>createHash('sha256').update(value).digest('hex');
const key=(value:unknown)=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const integer=(value:unknown):value is number=>Number.isSafeInteger(value)&&Number(value)>=0;
const within=(parent:string,path:string)=>{const part=relative(parent,path);return part===''||(part!=='..'&&!part.startsWith(`..${sep}`)&&!isAbsolute(part));};

function absolutePath(input:string):string {
  if(typeof input!=='string'||!isAbsolute(input)||input.includes('\0')||resolve(input)==='/'){throw new Error('Use an explicit non-root staging path');}
  return resolve(input);
}
function profileRef(input:string):string {
  if(typeof input!=='string'||input.length>256){throw new Error('Invalid profile index reference');}
  const [pubkey,...parts]=input.split('/');
  if(decode(pubkey).type!=='npub'||parts.length!==1||parts[0]!=='nostr-event-index'){throw new Error('Use an existing public profile index reference');}
  return input;
}
function signedPublicRecord(input:Event,authors:Set<string>,since:number,until:number):Event {
  if(!input||!(MARKET_ARCHIVE_KINDS as readonly number[]).includes(input.kind)){throw new Error('Market seed permits only public kinds 5, 7368 and 30402');}
  if(!authors.has(input.pubkey)){throw new Error('Event author is outside the pinned allowlist');}
  if(!integer(input.created_at)||input.created_at<since||input.created_at>until){throw new Error('Event is outside the finite time window');}
  let event:Event;
  try{event={id:input.id,pubkey:input.pubkey,created_at:input.created_at,kind:input.kind,content:input.content,tags:input.tags.map(tag=>[...tag]),sig:input.sig};}
  catch{throw new Error('Invalid event shape');}
  if(Buffer.byteLength(JSON.stringify(event))>MARKET_ARCHIVE_LIMITS.eventBytes){throw new Error('Event exceeds the public record budget');}
  if(!verifyEvent(event)){throw new Error('Invalid public event signature');}
  return event;
}

/** Pure preparation: signed fixtures may test this function, but are never fetched or published. */
export async function createMarketArchivePlan(config:MarketArchiveConfig,authorText:string,seeds:Event[],now=Math.floor(Date.now()/1000)):Promise<MarketArchivePlan> {
  const limits=MARKET_ARCHIVE_LIMITS;
  if(config?.format!=='iris-social/market-archive-config@1'){throw new Error('Unknown Market archive configuration');}
  const maxPagesPerAuthor=config.maxPagesPerAuthor===undefined?limits.pagesPerAuthor:config.maxPagesPerAuthor;
  if(maxPagesPerAuthor!==4&&maxPagesPerAuthor!==8){throw new Error('Choose the reviewed limit of four or eight pages per author');}
  if(!integer(config.since)||!integer(config.until)||config.until<=config.since||config.until-config.since>limits.windowSeconds||config.until>now+300){throw new Error('Choose a finite window of at most 31 days');}
  if(typeof authorText!=='string'||Buffer.byteLength(authorText)>limits.authors*65||!authorText.endsWith('\n')){throw new Error('Provide a bounded newline-delimited public author list');}
  const authors=authorText.slice(0,-1).split('\n');
  if(!authors.length||authors.length>limits.authors||authors.some(author=>!key(author))||new Set(authors).size!==authors.length){throw new Error('Authors must be unique lowercase public keys');}
  if(!Array.isArray(config.relays)||!config.relays.length||config.relays.length>limits.relays){throw new Error('Choose one to three public relays');}
  const relays=[...new Set(config.relays.map(value=>{const url=new URL(value);if(url.protocol!=='wss:'||url.username||url.password||url.hash){throw new Error('Use secure public relay URLs');}return url.href;}))].sort();
  const directory=absolutePath(config.directory);
  if(!Array.isArray(config.protectedDirectories)||!config.protectedDirectories.length||config.protectedDirectories.length>16){throw new Error('Identify existing protected archive directories');}
  const protectedDirectories=[...new Set(config.protectedDirectories.map(absolutePath))].sort();
  if(protectedDirectories.some(path=>within(path,directory)||within(directory,path))){throw new Error('Staging must not overlap an existing archive');}
  if(!key(config.native?.sha256)||config.native.version!==MARKET_NATIVE_VERSION||config.native.sourceCommit!==MARKET_NATIVE_SOURCE||!/^[a-f0-9]{40}$/.test(config.sourceCommit)){throw new Error('Pin the verified native binary and full source commits');}
  const native={path:absolutePath(config.native.path),version:config.native.version,sha256:config.native.sha256,sourceCommit:config.native.sourceCommit};
  const configText=marketArchiveConfig(config.rendezvousPort),isolatedConfig={text:configText,sha256:hash(configText)};
  if(!Array.isArray(config.profileIndexRefs)||!config.profileIndexRefs.length||config.profileIndexRefs.length>4){throw new Error('Retain an existing profile/follow index reference');}
  const profileIndexRefs=[...new Set(config.profileIndexRefs.map(profileRef))].sort();
  if(!Array.isArray(seeds)||!seeds.length||seeds.length>limits.seedEvents){throw new Error('Provide one to sixteen genuine signed seed events');}
  const allowed=new Set(authors),events=seeds.map(event=>signedPublicRecord(event,allowed,config.since,config.until));
  if(!events.some(event=>event.kind===30402||event.kind===7368)){throw new Error('A Market listing or review must seed the index');}
  const seedJson=JSON.stringify(events);
  if(Buffer.byteLength(seedJson)>limits.seedBytes){throw new Error('Seed exceeds its byte budget');}
  const store=new MemoryStore(),eventStore=new NostrEventStore(store),root=await eventStore.build(null,events);
  if(!root){throw new Error('The seed index is empty');}
  const seedRoot=nhashEncode(root),retained=await eventStore.query(root,{}, {limit:limits.seedEvents+1,strict:true});
  const seed={root:seedRoot,events,eventIds:retained.map(event=>event.id).sort(),sha256:hash(seedJson)};
  const policy:ArchiveCheckpoint['policy']={base_root:seedRoot,authors_sha256:hash(authorText),author_count:authors.length,
    initial_since:config.since,overlap_secs:0,relays,kinds:[...MARKET_ARCHIVE_KINDS],page_size:limits.pageSize,
    max_pages_per_author:maxPagesPerAuthor,max_events_per_author:limits.eventsPerAuthor,
    max_bytes_per_author:limits.bytesPerAuthor,fetch_timeout_secs:limits.fetchSeconds,index_commit_batch_size:limits.commitEvents};
  const namespace=`market-reviews-v1-${hash(canonical({policy,until:config.until,native,sourceCommit:config.sourceCommit,configSha256:isolatedConfig.sha256})).slice(0,20)}`;
  const rootPath=join(directory,namespace);
  const body:Omit<MarketArchivePlan,'authoritySha256'>={format:'iris-social/market-archive-plan@1',namespace,sourceCommit:config.sourceCommit,native,until:config.until,
    paths:{root:rootPath,data:join(rootPath,'data'),config:join(rootPath,'config'),authors:join(rootPath,'authors.txt'),seed:join(rootPath,'seed-events.json'),checkpoint:join(rootPath,'data/nostr-index/catchup-state.json'),operationLock:join(rootPath,'operation.lock'),receipts:join(rootPath,'receipts')},
    protectedDirectories,isolatedConfig,policy,authors,authorText,seed,
    bounds:{authors:authors.length,maxEvents:authors.length*limits.eventsPerAuthor,maxInputBytes:authors.length*limits.bytesPerAuthor,authorsPerRun:limits.authorsPerRun,
      runtimeSeconds:limits.runtimeSeconds,memoryBytes:limits.memoryBytes,growthBytes:limits.growthBytes,minimumFreeBytes:limits.minimumFreeBytes,reserveBytes:limits.reserveBytes},
    measurements:{seedEvents:events.length,seedJsonBytes:Buffer.byteLength(seedJson),seedIndexBlocks:store.size,seedIndexBytes:store.totalBytes},
    publication:{automatic:false,treeName:`nostr-${namespace}`,profileIndexRefs,requiredKinds:[...MARKET_ARCHIVE_KINDS],requires:[
      'Native import root equals the signed seed root before catch-up starts.',
      'Successful bounded receipt, identical policy/authority, and retained prior checkpoint.',
      'Signed candidate readback includes retained seeds, deletion and expired winning records.',
      'Existing publisher signs only this separate tree; required relay and public Hashtree readback pass.',
      'Existing archive pointers, services, identities and retained data remain unchanged.',
    ]}};
  return {...body,authoritySha256:hash(canonical(body))};
}

export function assertMarketArchivePlan(plan:MarketArchivePlan):void {
  const {authoritySha256,...body}=plan;
  if(!key(authoritySha256)||hash(canonical(body))!==authoritySha256){throw new Error('Market archive authority changed');}
}

/** Compile one finite native invocation; the owner admits it under an exclusive operation lock. */
export function buildMarketCatchupCommand(plan:MarketArchivePlan,{availableBytes,seedRoot}:{availableBytes:number;seedRoot:string}) {
  assertMarketArchivePlan(plan);
  if(seedRoot!==plan.seed.root){throw new Error('Native seed import differs from the verified seed root');}
  if(!integer(availableBytes)||availableBytes<plan.bounds.minimumFreeBytes+plan.bounds.growthBytes+plan.bounds.reserveBytes){throw new Error('Insufficient measured staging capacity');}
  const floor=Math.max(plan.bounds.minimumFreeBytes,availableBytes-plan.bounds.growthBytes);
  const p=plan.policy,args=['--data-dir',plan.paths.data,'nostr-index','catch-up','--root',p.base_root,'--authors-file',plan.paths.authors,
    '--since',String(p.initial_since),'--until',String(plan.until),'--overlap-secs','0','--source-mode','strict',
    ...p.relays.flatMap(relay=>['--relay',relay]),...p.kinds.flatMap(kind=>['--kind',String(kind)]),
    '--page-size',String(p.page_size),'--max-pages-per-author',String(p.max_pages_per_author),'--max-events-per-author',String(p.max_events_per_author),
    '--max-bytes-per-author',String(p.max_bytes_per_author),'--fetch-timeout-secs',String(p.fetch_timeout_secs),
    '--index-commit-batch-size',String(p.index_commit_batch_size),'--max-authors-per-run','1','--min-free-bytes',String(floor)];
  return {executable:plan.native.path,args,env:{HTREE_CONFIG_DIR:plan.paths.config,HTREE_DATA_DIR:plan.paths.data},
    systemd:{CPUQuota:'100%',MemoryMax:String(plan.bounds.memoryBytes),MemorySwapMax:'0',RuntimeMaxSec:String(plan.bounds.runtimeSeconds)},operationLock:plan.paths.operationLock};
}

export function validateMarketNativeReceipt(plan:MarketArchivePlan,receipt:ArchiveRunReceipt,sourceCoverage:ArchiveSourceCoverageProof[]=[]):ArchiveCheckpoint {
  assertMarketArchivePlan(plan);const state=receipt?.after;
  if(receipt?.format!=='iris-social/archive-catchup-run@1'||receipt.exitCode!==0||receipt.authoritySha256!==plan.authoritySha256||!receipt.originalAndPoolPinsUnchanged||
    !state||canonical(state.policy)!==canonical(plan.policy)||state.pass_since!==plan.policy.initial_since||state.pass_until!==plan.until||
    !integer(state.next_author)||state.next_author<1||state.next_author>plan.authors.length||!integer(state.events_received)||state.events_received>plan.bounds.maxEvents){throw new Error('Market publication requires a matching successful finite checkpoint');}
  const previous=receipt.before?.next_author===0?null:receipt.before;
  if(state.next_author-(receipt.before?.next_author??0)!==1||state.events_received-(receipt.before?.events_received??0)>MARKET_ARCHIVE_LIMITS.eventsPerAuthor){throw new Error('Market receipt exceeds its one-author budget');}
  // The pinned native writer always persists a coverage receipt, including in
  // strict mode. Keep that evidence intact instead of accepting a stripped head.
  if(!key(state.coverage_head)||(previous&&!key(previous.coverage_head))||sourceCoverage.length!==1){throw new Error('Market receipt requires its exact native source coverage');}
  validateArchiveCandidate({state,run:receipt,sourceCoverage,checkpointSha256:hash(canonical(state)),receiptSha256:hash(canonical(receipt))},plan.policy,plan.authoritySha256,previous,plan.until,[],[],[],{authors:plan.authors,strictCoverage:true});
  return state;
}

/** Read every record in this small separate corpus; never call a partial read a verified index. */
export async function verifyMarketIndexReadback(store:Store,root:string|CID,plan:MarketArchivePlan,wanted:readonly string[],signal?:AbortSignal) {
  assertMarketArchivePlan(plan);const cid=typeof root==='string'?nhashDecode(root):root;
  const reader=new HashtreeNostrEventReader({store,roots:cid,maxConcurrentPartitions:1});
  const report=await reader.query([{}],{limit:plan.bounds.maxEvents+plan.seed.events.length+1,deadline:Date.now()+30000,signal});
  if(!report.complete||report.events.length>plan.bounds.maxEvents+plan.seed.events.length){throw new Error('Market index readback is incomplete or exceeds its scope');}
  const authors=new Set(plan.authors),ids=new Set<string>();let bytes=0;
  for(const item of report.events){
    let event:Event;try{event=signedPublicRecord(item.event,authors,plan.policy.initial_since,plan.until);}catch{throw new Error('Market index contains records outside its signed public scope');}
    bytes+=Buffer.byteLength(JSON.stringify(event));if(bytes>plan.bounds.maxInputBytes+MARKET_ARCHIVE_LIMITS.seedBytes){throw new Error('Market index exceeds its byte budget');}ids.add(event.id);
  }
  if(wanted.some(id=>!key(id)||!ids.has(id))){throw new Error('Market index readback is missing a required signed event');}
  return{root:nhashEncode(cid),complete:true,verifiedEventIds:[...ids].sort(),eventBytes:bytes};
}
