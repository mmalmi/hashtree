import type { CID, Store } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import type { PostSearchPointerHandoff, PostSearchPointerSigner } from './postSearchPointer';
import type { PostSearchEventVerifier, PostSearchSnapshotReader } from './postSearchProjection';
import type {
  PostSearchTailBuilderState,
  PostSearchTailBuilderStateStore,
} from './postSearchTailBuilderState';

export interface PostSearchCatalogTailBuilderOptions {
  baseCatalogRoot: CID;
  targetSnapshotRoot: CID;
  /** Exact accepted batch used to derive targetSnapshotRoot from the base snapshot. */
  tailEvents: readonly RawEvent[];
  snapshotReader: PostSearchSnapshotReader;
  outputStore: Store;
  stateStore: PostSearchTailBuilderStateStore;
  publisherId: string;
  treeName: string;
  maxTailEvents?: number;
  maxTailBytes?: number;
  maxEventBytes?: number;
  maxDeletionEvents?: number;
  segmentMaxDocuments?: number;
  segmentMaxBytes?: number;
  now?: () => number;
  verifyEvent?: PostSearchEventVerifier;
  signer?: PostSearchPointerSigner;
  signal?: AbortSignal;
  onProgress?: (progress: PostSearchTailProgress) => void;
}

export interface PostSearchTailProgress {
  phase: 'validating-tail' | 'scanning-deletions' | 'building-segments' | 'writing-catalog' | 'complete';
  tailEvents: number;
  searchableDocuments: number;
  persistedDocuments: number;
}

export interface PostSearchCatalogTailBuildResult {
  catalogRoot: CID;
  handoff: PostSearchPointerHandoff;
  state: PostSearchTailBuilderState;
  resumed: boolean;
}
