import type { CID } from '@hashtree/core';
import type {
  RankedSearchBuildOptions,
  RankedSearchFieldManifest,
  RankedTermStats,
} from '@hashtree/index';

export const POST_SEARCH_V5_RUN_FORMAT = 'iris-social/packed-post-search-run@1' as const;
export const POST_SEARCH_V5_RUN_DEFAULT_MAX_DOCUMENTS = 5_000;
export const POST_SEARCH_V5_RUN_MAX_DOCUMENTS = 5_000;
export const POST_SEARCH_V5_RUN_MAX_TOKEN_OCCURRENCES = 1_000_000;
export const POST_SEARCH_V5_RUN_MAX_MANIFEST_BYTES = 65_536;
export const POST_SEARCH_V5_RUN_MAX_RAW_DOCUMENT_BYTES = 1_048_576;
export const POST_SEARCH_V5_MAX_FIELDS = 32;
export const POST_SEARCH_V5_MAX_TOKENS_PER_FIELD = 4_096;

export const POST_SEARCH_V5_NORMALIZATION = 'NFKC-lowercase@1' as const;
export const POST_SEARCH_V5_POSTING_PART_SEPARATOR = '\0';
export const POST_SEARCH_V5_PAGE_NAME = /^\d{6}$/;

export interface PostSearchV5RunManifest {
  format: typeof POST_SEARCH_V5_RUN_FORMAT;
  normalization: typeof POST_SEARCH_V5_NORMALIZATION;
  documentCount: number;
  termCount: number;
  postingCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
  k1: number;
  maxTokensPerField: number;
  fields: RankedSearchFieldManifest[];
  pages: { documents: number; postings: number; terms: number; total: number };
  entries: { documents: number; postings: number; terms: number };
  reachableNodeCount: number;
}

export interface PostSearchV5StoredDocument {
  lengths: Record<string, number>;
  value?: string;
}

export interface PostSearchV5Posting {
  id: string;
  fields: Record<string, { frequency: number; positions: number[] }>;
}

export interface PostSearchV5TermStats extends RankedTermStats {
  postingParts: number;
}

export interface PostSearchV5RecordManifest {
  fields: RankedSearchFieldManifest[];
  maxTokensPerField: number;
}

export interface PostSearchV5Run {
  root: CID;
  manifest: PostSearchV5RunManifest;
  getDocument(id: string): PostSearchV5StoredDocument | null;
  getTerm(term: string): PostSearchV5TermStats | null;
  getPostings(term: string): readonly PostSearchV5Posting[];
}

/** Lazy authenticated lookup. Each read touches one of sixteen hash buckets, never the vocabulary. */
export interface PostSearchV5RunLookup {
  root: CID;
  manifest: PostSearchV5RunManifest;
  getDocument(id: string): Promise<PostSearchV5StoredDocument | null>;
  getTerm(term: string): Promise<PostSearchV5TermStats | null>;
  getPostings(term: string): Promise<readonly PostSearchV5Posting[]>;
}

export interface PostSearchV5RunBuildOptions extends RankedSearchBuildOptions {
  maxDocuments?: number;
}

export type PostSearchV5RunBuild = {
  root: CID;
  manifest: PostSearchV5RunManifest;
};
