import { nhashDecode, nhashEncode, type CID, type Store } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import type { RawEvent } from '../lib/nostr';
import {
  closureCurrentStateCoordinate,
  closureReferenceKey,
  closureReferenceMatchesEvent,
  extractReferencedEventClosureReferences,
  getVerifiedKind6ClosureTarget,
  matchingClosureReferenceKeys,
  newestClosureEvent,
  normalizeClosureEvent,
  retainIndexableClosureBatch,
  verifyClosureEvent,
} from './referencedEventClosureReferences';
import {
  closureSha256,
  hashClosurePubkeySet,
  normalizeClosureLimits,
  replayClosureJournal,
  resultFromClosureState,
} from './referencedEventClosureState';
import {
  REFERENCED_EVENT_CLOSURE_FORMAT,
  REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT,
  type CandidateSelection,
  type ReferencedEventClosureBatch,
  type ReferencedEventClosureJournal,
  type ReferencedEventClosureReference,
  type ReferencedEventClosureResult,
  type ReplayedClosureState,
  type RunReferencedEventClosureOptions,
} from './referencedEventClosureTypes';

export * from './referencedEventClosureTypes';
export * from './referencedEventClosureReferences';

export async function runReferencedEventClosure(
  store: Store,
  options: RunReferencedEventClosureOptions,
): Promise<ReferencedEventClosureResult> {
  const limits = normalizeClosureLimits(options.limits);
  const eligibleAuthorsSha256 = hashClosurePubkeySet(options.eligibleAuthors, 'eligible');
  const overmutedAuthorsSha256 = hashClosurePubkeySet(
    options.overmutedAuthors,
    'overmuted',
    true,
  );
  const sourceRoot = nhashEncode(options.source.root);
  const resolverPolicySha256 = normalizeResolverPolicySha256(
    options.resolver.configurationSha256,
  );
  const configurationSha256 = closureSha256(JSON.stringify({
    format: REFERENCED_EVENT_CLOSURE_FORMAT,
    sourceRoot,
    eligibleAuthorsSha256,
    overmutedAuthorsSha256,
    resolverPolicySha256,
    limits,
  }));
  const entries = await options.journal.load();
  const state = replayClosureJournal(entries, {
    configurationSha256,
    sourceRoot,
    eligibleAuthorsSha256,
    overmutedAuthorsSha256,
    resolverPolicySha256,
    limits,
  });
  if (entries.length === 0) {
    await options.journal.append({
      format: REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT,
      type: 'init',
      sequence: 0,
      configurationSha256,
      sourceRoot,
      eligibleAuthorsSha256,
      overmutedAuthorsSha256,
      resolverPolicySha256,
      limits,
    });
  }
  state.acceptedCoordinates = await validateRetainedBatches(store, state.batches);
  if (state.complete) {
    return resultFromClosureState(state);
  }

  if (!state.sourceComplete) {
    await scanSource(store, options, state);
  }
  while (state.queueCursor < state.queue.length) {
    await resolveQueueBatch(store, options, state);
  }
  state.complete = true;
  state.sequence += 1;
  await options.journal.append({
    format: REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT,
    type: 'complete',
    sequence: state.sequence,
    counters: { ...state.counters },
  });
  return resultFromClosureState(state);
}

function normalizeResolverPolicySha256(value: string): string {
  if (!/^[0-9a-f]{64}$/.test(value)) {
    throw new Error('Referenced-event closure resolver policy digest is invalid');
  }
  return value;
}

async function scanSource(
  store: Store,
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
): Promise<void> {
  let ordinal = 0;
  let batch: RawEvent[] = [];
  for await (const event of options.source.streamEvents()) {
    if (ordinal < state.sourceProcessed) {
      if (ordinal === state.sourceProcessed - 1 && event.id !== state.sourceBoundaryEventId) {
        throw new Error('Referenced-event closure source resume boundary changed');
      }
      ordinal += 1;
      continue;
    }
    if (Buffer.byteLength(JSON.stringify(event)) > state.limits.maxEventBytes) {
      throw new Error('Referenced-event closure source event exceeds the event byte limit');
    }
    if (!verifyClosureEvent(event) || !options.eligibleAuthors.has(event.pubkey)) {
      throw new Error('Referenced-event closure source contains an invalid or ineligible event');
    }
    batch.push(event);
    ordinal += 1;
    if (batch.length >= state.limits.sourceBatchSize) {
      await commitSourceBatch(store, options, state, batch, ordinal, false);
      batch = [];
    }
  }
  if (ordinal < state.sourceProcessed) {
    throw new Error('Referenced-event closure source is shorter than its resume checkpoint');
  }
  await commitSourceBatch(store, options, state, batch, ordinal, true);
}

async function commitSourceBatch(
  store: Store,
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
  sourceEvents: readonly RawEvent[],
  sourceProcessed: number,
  sourceComplete: boolean,
): Promise<void> {
  const addedReferences: ReferencedEventClosureReference[] = [];
  const embedded: Array<{ event: RawEvent; depth: number }> = [];
  for (const event of sourceEvents) {
    addedReferences.push(...discoverReferences(state, event, 1));
    const target = getVerifiedKind6ClosureTarget(event);
    if (target) {
      embedded.push({ event: target, depth: 1 });
    }
  }
  const existing = await options.source.resolveExisting(embedded.map(({ event, depth }) => ({
    type: 'id' as const,
    value: event.id,
    depth,
  })));
  const existingIds = new Set(existing.map(({ id }) => id));
  const selected = selectEmbeddedCandidates(embedded, existingIds, options, state);
  const accepted = await storeAcceptedBatch(store, options, state, selected.events);
  for (const { event, depth } of accepted.events) {
    addedReferences.push(...discoverReferences(state, event, depth + 1));
  }
  state.sourceProcessed = sourceProcessed;
  state.sourceBoundaryEventId = sourceEvents.at(-1)?.id ?? state.sourceBoundaryEventId;
  state.sourceComplete = sourceComplete;
  state.counters.sourceEventsScanned = sourceProcessed;
  state.counters.excludedOvermuted += selected.excludedOvermuted;
  state.counters.invalidCandidates += selected.invalidCandidates;
  state.counters.supersededBatchEvents += accepted.superseded;
  state.counters.unrepresentableCurrentState += accepted.unrepresentableCurrentState;
  applyAcceptedBatch(state, accepted.batch, accepted.events);
  await appendCheckpoint(options.journal, state, 'source', addedReferences, accepted.batch);
}

async function resolveQueueBatch(
  store: Store,
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
): Promise<void> {
  const references = state.queue.slice(
    state.queueCursor,
    state.queueCursor + state.limits.resolutionBatchSize,
  );
  const needSourceLookup = references.filter((reference) => !closureStateHasReference(state, reference));
  const local = await options.source.resolveExisting(needSourceLookup);
  const locallyResolved = matchingClosureReferenceKeys(needSourceLookup, local);
  const unresolved = needSourceLookup.filter(
    (reference) => !locallyResolved.has(closureReferenceKey(reference)),
  );
  const candidates = unresolved.length === 0 ? [] : await options.resolver.resolve(unresolved);
  if (candidates.length > state.limits.maxResolverCandidates) {
    throw new Error('Referenced-event closure resolver exceeded its candidate bound');
  }
  const selected = selectResolvedCandidates(unresolved, candidates, options, state);
  const accepted = await storeAcceptedBatch(store, options, state, selected.events);
  const addedReferences: ReferencedEventClosureReference[] = [];
  for (const { event, depth } of accepted.events) {
    addedReferences.push(...discoverReferences(state, event, depth + 1));
  }
  state.queueCursor += references.length;
  state.counters.referencesProcessed += references.length;
  state.counters.excludedOvermuted += selected.excludedOvermuted;
  state.counters.invalidCandidates += selected.invalidCandidates;
  state.counters.unmatchedCandidates += selected.unmatchedCandidates;
  state.counters.unresolvedReferences += selected.unresolvedReferences;
  state.counters.supersededBatchEvents += accepted.superseded;
  state.counters.unrepresentableCurrentState += accepted.unrepresentableCurrentState;
  applyAcceptedBatch(state, accepted.batch, accepted.events);
  await appendCheckpoint(options.journal, state, 'resolve', addedReferences, accepted.batch);
}

function closureStateHasReference(
  state: ReplayedClosureState,
  reference: ReferencedEventClosureReference,
): boolean {
  return reference.type === 'id'
    ? state.acceptedEventIds.has(reference.value)
    : state.acceptedCoordinates.has(reference.value);
}

function selectEmbeddedCandidates(
  candidates: Array<{ event: RawEvent; depth: number }>,
  existingIds: ReadonlySet<string>,
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
): CandidateSelection {
  const selected: Array<{ event: RawEvent; depth: number }> = [];
  let excludedOvermuted = 0;
  let invalidCandidates = 0;
  for (const candidate of candidates) {
    if (!verifyClosureEvent(candidate.event)) {
      invalidCandidates += 1;
    } else if (options.overmutedAuthors.has(candidate.event.pubkey)) {
      excludedOvermuted += 1;
    } else if (!existingIds.has(candidate.event.id) && !state.acceptedEventIds.has(candidate.event.id)) {
      selected.push(candidate);
    }
  }
  return {
    events: selected,
    excludedOvermuted,
    invalidCandidates,
    unmatchedCandidates: 0,
    unresolvedReferences: 0,
  };
}

function selectResolvedCandidates(
  references: readonly ReferencedEventClosureReference[],
  rawCandidates: readonly RawEvent[],
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
): CandidateSelection {
  const candidates = new Map<string, RawEvent>();
  let invalidCandidates = 0;
  let unmatchedCandidates = 0;
  for (const raw of rawCandidates) {
    let event: RawEvent;
    try {
      event = normalizeClosureEvent(raw);
    } catch {
      invalidCandidates += 1;
      continue;
    }
    if (!verifyClosureEvent(event)) {
      invalidCandidates += 1;
      continue;
    }
    if (!references.some((reference) => closureReferenceMatchesEvent(reference, event))) {
      unmatchedCandidates += 1;
      continue;
    }
    const existing = candidates.get(event.id);
    if (!existing) {
      candidates.set(event.id, event);
    }
  }

  const selected = new Map<string, { event: RawEvent; depth: number }>();
  let excludedOvermuted = 0;
  let unresolvedReferences = 0;
  for (const reference of references) {
    const matches = [...candidates.values()].filter((event) => closureReferenceMatchesEvent(reference, event));
    const event = reference.type === 'coordinate' ? newestClosureEvent(matches) : matches[0];
    if (!event) {
      unresolvedReferences += 1;
      continue;
    }
    if (options.overmutedAuthors.has(event.pubkey)) {
      excludedOvermuted += 1;
      continue;
    }
    if (!state.acceptedEventIds.has(event.id)) {
      const existing = selected.get(event.id);
      if (!existing || reference.depth < existing.depth) {
        selected.set(event.id, { event, depth: reference.depth });
      }
    }
  }
  return {
    events: [...selected.values()],
    excludedOvermuted,
    invalidCandidates,
    unmatchedCandidates,
    unresolvedReferences,
  };
}

async function storeAcceptedBatch(
  store: Store,
  options: RunReferencedEventClosureOptions,
  state: ReplayedClosureState,
  candidates: Array<{ event: RawEvent; depth: number }>,
): Promise<{
  batch: ReferencedEventClosureBatch | null;
  events: Array<{ event: RawEvent; depth: number }>;
  superseded: number;
  unrepresentableCurrentState: number;
}> {
  const batchWinners = retainIndexableClosureBatch(candidates);
  const superseded = candidates.length - batchWinners.length;
  let unrepresentableCurrentState = 0;
  const representable = batchWinners.filter(({ event }) => {
    if (
      event.kind >= 30_000
      && event.kind < 40_000
      && closureCurrentStateCoordinate(event) === null
    ) {
      unrepresentableCurrentState += 1;
      return false;
    }
    return true;
  });
  const idReferences = representable.map(({ event, depth }) => ({
    type: 'id' as const,
    value: event.id,
    depth,
  }));
  const coordinates = representable.flatMap(({ event, depth }) => {
    const coordinate = closureCurrentStateCoordinate(event);
    return coordinate ? [{ type: 'coordinate' as const, value: coordinate, depth }] : [];
  });
  const sourceEvents = await options.source.resolveExisting([...idReferences, ...coordinates]);
  const sourceIds = new Set(sourceEvents.map((event) => event.id));
  const sourceCoordinates = matchingClosureReferenceKeys(coordinates, sourceEvents);
  const retained = representable.filter(({ event }) => {
    const coordinate = closureCurrentStateCoordinate(event);
    if (sourceIds.has(event.id) || state.acceptedEventIds.has(event.id)) {
      return false;
    }
    if (
      coordinate
      && (
        state.acceptedCoordinates.has(coordinate)
        || sourceCoordinates.has(closureReferenceKey({ type: 'coordinate', value: coordinate }))
      )
    ) {
      unrepresentableCurrentState += 1;
      return false;
    }
    return true;
  });
  if (retained.length === 0) {
    return { batch: null, events: [], superseded, unrepresentableCurrentState };
  }
  if (state.counters.acceptedEvents + retained.length > state.limits.maxAcceptedEvents) {
    throw new Error('Referenced-event closure accepted-event limit exceeded');
  }
  let bytes = 0;
  for (const { event } of retained) {
    const size = Buffer.byteLength(JSON.stringify(event));
    if (size > state.limits.maxEventBytes) {
      throw new Error('Referenced-event closure candidate exceeds the event byte limit');
    }
    bytes += size;
  }
  if (state.counters.acceptedEventBytes + bytes > state.limits.maxAcceptedBytes) {
    throw new Error('Referenced-event closure accepted-byte limit exceeded');
  }
  const root = await new NostrEventStore(store).build(null, retained.map(({ event }) => event));
  if (!root) {
    throw new Error('Referenced-event closure failed to build a non-empty event batch');
  }
  state.counters.acceptedEvents += retained.length;
  state.counters.acceptedEventBytes += bytes;
  return {
    batch: { root: nhashEncode(root), eventIds: retained.map(({ event }) => event.id) },
    events: retained,
    superseded,
    unrepresentableCurrentState,
  };
}

function discoverReferences(
  state: ReplayedClosureState,
  event: RawEvent,
  depth: number,
): ReferencedEventClosureReference[] {
  const added: ReferencedEventClosureReference[] = [];
  for (const reference of extractReferencedEventClosureReferences(event, depth)) {
    const key = closureReferenceKey(reference);
    if (state.seenReferenceKeys.has(key)) {
      continue;
    }
    if (state.seenReferenceKeys.size >= state.limits.maxReferences) {
      throw new Error('Referenced-event closure reference limit exceeded');
    }
    state.seenReferenceKeys.add(key);
    added.push(reference);
    if (reference.depth > state.limits.maxDepth) {
      state.counters.depthLimitedReferences += 1;
      continue;
    }
    state.queue.push(reference);
    state.counters.referencesDiscovered += 1;
  }
  return added;
}

function applyAcceptedBatch(
  state: ReplayedClosureState,
  batch: ReferencedEventClosureBatch | null,
  accepted: Array<{ event: RawEvent }>,
): void {
  if (!batch) {
    return;
  }
  for (const { event } of accepted) {
    state.acceptedEventIds.add(event.id);
    const coordinate = closureCurrentStateCoordinate(event);
    if (coordinate) {
      state.acceptedCoordinates.add(coordinate);
    }
  }
  state.batches.push(batch);
}

async function appendCheckpoint(
  journal: ReferencedEventClosureJournal,
  state: ReplayedClosureState,
  phase: 'source' | 'resolve',
  addedReferences: ReferencedEventClosureReference[],
  acceptedBatch: ReferencedEventClosureBatch | null,
): Promise<void> {
  state.sequence += 1;
  await journal.append({
    format: REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT,
    type: 'checkpoint',
    sequence: state.sequence,
    phase,
    sourceProcessed: state.sourceProcessed,
    sourceBoundaryEventId: state.sourceBoundaryEventId,
    sourceComplete: state.sourceComplete,
    queueCursor: state.queueCursor,
    addedReferences,
    acceptedBatch,
    counters: { ...state.counters },
  });
}

async function validateRetainedBatches(
  store: Store,
  batches: readonly ReferencedEventClosureBatch[],
): Promise<Set<string>> {
  const events = new NostrEventStore(store);
  const coordinates = new Set<string>();
  for (const batch of batches) {
    const root = parseRoot(batch.root);
    if (!(await store.has(root.hash))) {
      throw new Error('Referenced-event closure journal batch root is missing');
    }
    const indexed = await Promise.all(batch.eventIds.map(async (id) => await events.getById(root, id)));
    if (indexed.some((event, index) => event?.id !== batch.eventIds[index] || !verifyClosureEvent(event!))) {
      throw new Error('Referenced-event closure journal batch is invalid');
    }
    for (const event of indexed) {
      const coordinate = closureCurrentStateCoordinate(event!);
      if (coordinate && coordinates.has(coordinate)) {
        throw new Error('Referenced-event closure batches contain a duplicate coordinate');
      }
      if (coordinate) {
        coordinates.add(coordinate);
      }
    }
  }
  return coordinates;
}

function parseRoot(value: string): CID {
  return nhashDecode(value);
}
