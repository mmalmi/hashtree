import { createHash, randomBytes } from 'node:crypto';
import {
  access,
  mkdir,
  readFile,
  rename,
  rm,
  writeFile,
} from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { toHex, type Hash, type Store } from '@hashtree/core';
import {
  isPostSearchBuilderState,
  type PostSearchBuilderState,
  type PostSearchBuilderStateStore,
} from './postSearchBuilderState';
import {
  isPostSearchTailBuilderState,
  type PostSearchTailBuilderState,
  type PostSearchTailBuilderStateStore,
} from './postSearchTailBuilderState';

/** Offline/test adapter compatible with Rust hashtree-fs's two-level CAS layout. */
export class FilesystemBlockStore implements Store {
  private readonly root: string;

  constructor(root: string) {
    this.root = resolve(root);
  }

  async put(hash: Hash, data: Uint8Array): Promise<boolean> {
    const expected = toHex(hash);
    const actual = createHash('sha256').update(data).digest('hex');
    if (actual !== expected) {
      throw new Error(`Refusing Hashtree block with hash mismatch: ${expected}`);
    }
    if (await this.has(hash)) {
      return false;
    }
    const path = this.primaryPath(expected);
    await mkdir(dirname(path), { recursive: true });
    const temporary = `${path}.tmp-${process.pid}-${randomBytes(8).toString('hex')}`;
    try {
      await writeFile(temporary, data, { flag: 'wx', mode: 0o644 });
      await rename(temporary, path);
      return true;
    } finally {
      await rm(temporary, { force: true });
    }
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    const expected = toHex(hash);
    for (const path of this.paths(hash)) {
      try {
        const data = new Uint8Array(await readFile(path));
        const actual = createHash('sha256').update(data).digest('hex');
        if (actual !== expected) {
          throw new Error(`Corrupt Hashtree filesystem block: ${expected}`);
        }
        return data;
      } catch (error) {
        if (!isMissingFile(error)) {
          throw error;
        }
      }
    }
    return null;
  }

  async has(hash: Hash): Promise<boolean> {
    for (const path of this.paths(hash)) {
      try {
        await access(path);
        return true;
      } catch (error) {
        if (!isMissingFile(error)) {
          throw error;
        }
      }
    }
    return false;
  }

  async delete(hash: Hash): Promise<boolean> {
    let removed = false;
    for (const path of this.paths(hash)) {
      try {
        await rm(path);
        removed = true;
      } catch (error) {
        if (!isMissingFile(error)) {
          throw error;
        }
      }
    }
    return removed;
  }

  private paths(hash: Hash): string[] {
    const hex = toHex(hash);
    return [this.primaryPath(hex), join(this.root, hex.slice(0, 2), hex.slice(2))];
  }

  private primaryPath(hex: string): string {
    return join(this.root, hex.slice(0, 2), hex.slice(2, 4), hex.slice(4));
  }
}

/** Refuse the LMDB directory used by a running Hashtree daemon. */
export async function assertPortableFilesystemStore(root: string): Promise<void> {
  const directory = resolve(root);
  for (const marker of ['data.mdb', 'lock.mdb']) {
    try {
      await access(join(directory, marker));
      throw new Error(
        'Offline filesystem store cannot open an LMDB directory; use the daemon HTTP store API',
      );
    } catch (error) {
      if (!isMissingFile(error)) {
        throw error;
      }
    }
  }
}

export class FilePostSearchBuilderStateStore implements PostSearchBuilderStateStore {
  private readonly path: string;

  constructor(path: string) {
    this.path = resolve(path);
  }

  async load(): Promise<PostSearchBuilderState | null> {
    let value: unknown;
    try {
      value = JSON.parse(await readFile(this.path, 'utf8'));
    } catch (error) {
      if (isMissingFile(error)) {
        return null;
      }
      throw error;
    }
    if (!isPostSearchBuilderState(value)) {
      throw new Error('Invalid persisted post search builder state');
    }
    return value;
  }

  async save(state: PostSearchBuilderState): Promise<void> {
    await writeJsonAtomic(this.path, state);
  }
}

export class FilePostSearchTailBuilderStateStore implements PostSearchTailBuilderStateStore {
  private readonly path: string;

  constructor(path: string) {
    this.path = resolve(path);
  }

  async load(): Promise<PostSearchTailBuilderState | null> {
    let value: unknown;
    try {
      value = JSON.parse(await readFile(this.path, 'utf8'));
    } catch (error) {
      if (isMissingFile(error)) {
        return null;
      }
      throw error;
    }
    if (!isPostSearchTailBuilderState(value)) {
      throw new Error('Invalid persisted post search tail builder state');
    }
    return value;
  }

  async save(state: PostSearchTailBuilderState): Promise<void> {
    await writeJsonAtomic(this.path, state);
  }
}

export async function writeJsonAtomic(path: string, value: unknown): Promise<void> {
  const target = resolve(path);
  await mkdir(dirname(target), { recursive: true });
  const temporary = `${target}.tmp-${process.pid}-${randomBytes(8).toString('hex')}`;
  try {
    await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx', mode: 0o644 });
    await rename(temporary, target);
  } finally {
    await rm(temporary, { force: true });
  }
}

function isMissingFile(error: unknown): boolean {
  return error instanceof Error && 'code' in error && error.code === 'ENOENT';
}
