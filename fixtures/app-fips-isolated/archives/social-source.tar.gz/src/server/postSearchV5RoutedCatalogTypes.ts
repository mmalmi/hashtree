import type { CID } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import {
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
} from '../lib/postSearchCatalogConstants';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import { POST_SEARCH_V5_OVERLAY_STORE_FORMAT } from './postSearchV5OverlayStore';
import {
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  type PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRun';

export const POST_SEARCH_V5_ROUTED_CATALOG_FORMAT =
  'iris-social/routed-post-search-catalog@6' as const;
export const POST_SEARCH_V5_ROUTED_CATALOG_MAX_LEVEL = 52;
export const POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS_PER_LEVEL = 2;
export const POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS =
  (POST_SEARCH_V5_ROUTED_CATALOG_MAX_LEVEL + 1)
  * POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS_PER_LEVEL;
export const POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT = 9_000_000;
/** Mirrors the authenticated daemon pin-tree hard cap without importing Node-only archive tooling. */
export const POST_SEARCH_V5_ROUTED_CATALOG_DAEMON_HARD_LIMIT = 10_000_000;
export const POST_SEARCH_V5_ROUTED_CATALOG_OPEN_CONCURRENCY = 4;
export const POST_SEARCH_V5_ROUTED_CATALOG_OVERLAY_ENTRY = 'visibility-overlay' as const;

export interface PostSearchV5RoutedCoverage {
  eventCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchV5RoutedSourceSnapshot {
  eventRoot: string;
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  coverage: PostSearchV5RoutedCoverage;
}

export interface PostSearchV5RoutedCatalogRunDescriptor {
  entry: string;
  root: string;
  level: number;
  oldestBatch: number;
  newestBatchExclusive: number;
  documentCount: number;
  postingCount: number;
  postingPartCount: number;
  termCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
  pageCount: number;
  reachableNodeCount: number;
  kinds: number[];
  since: number;
  until: number;
}

export interface PostSearchV5RoutedCatalogRunInput
  extends Omit<PostSearchV5RoutedCatalogRunDescriptor, 'entry' | 'root'> {
  root: CID;
}

export interface PostSearchV5RoutedCatalogOverlayDescriptor {
  entry: typeof POST_SEARCH_V5_ROUTED_CATALOG_OVERLAY_ENTRY;
  root: string;
  exactTombstoneCount: number;
  coordinateStateCount: number;
  addressWinnerCount: number;
  addressDeletionCount: number;
  pageCount: number;
  reachableNodeCount: number;
}

export interface PostSearchV5RoutedCatalogOverlayInput
  extends Omit<PostSearchV5RoutedCatalogOverlayDescriptor, 'entry' | 'root'> {
  root: CID;
}

export interface PostSearchV5RoutedScoringManifest {
  documentCount: number;
  k1: number;
  maxTokensPerField: number;
  fields: RankedSearchFieldManifest[];
}

export interface PostSearchV5RoutedCatalogManifest {
  format: typeof POST_SEARCH_V5_ROUTED_CATALOG_FORMAT;
  publisherId: string;
  generatedAt: number;
  batchSize: number;
  source: PostSearchV5RoutedSourceSnapshot;
  compatibility: {
    runFormat: typeof POST_SEARCH_V5_ROUTED_RUN_FORMAT;
    packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
    pageRouterFormat: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
    overlayFormat: typeof POST_SEARCH_V5_OVERLAY_STORE_FORMAT;
    normalization: typeof POST_SEARCH_NORMALIZATION;
  };
  scoring: PostSearchV5RoutedScoringManifest;
  runs: PostSearchV5RoutedCatalogRunDescriptor[];
  overlay: PostSearchV5RoutedCatalogOverlayDescriptor | null;
  reachableNodeCount: number;
}

export interface PostSearchV5RoutedCatalogInput {
  publisherId: string;
  generatedAt: number;
  batchSize: number;
  source: PostSearchV5RoutedSourceSnapshot;
  runs: readonly PostSearchV5RoutedCatalogRunInput[];
  overlay: PostSearchV5RoutedCatalogOverlayInput | null;
  maxReachableNodeCount?: number;
}

export interface PostSearchV5RoutedCatalogBuild {
  root: CID;
  manifest: PostSearchV5RoutedCatalogManifest;
}

export interface PostSearchV5RoutedCatalogLookup extends PostSearchV5RoutedCatalogBuild {
  runs: PostSearchV5RoutedRunLookup[];
  overlayRoot: CID | null;
}

export interface PostSearchV5RoutedCatalogEnvelope extends PostSearchV5RoutedCatalogBuild {
  runRoots: CID[];
  overlayRoot: CID | null;
}
