import type { RankedSearchFieldManifest } from '@hashtree/index';
import {
  POST_SEARCH_V5_MAX_FIELDS,
  POST_SEARCH_V5_MAX_TOKENS_PER_FIELD,
  POST_SEARCH_V5_NORMALIZATION,
  POST_SEARCH_V5_RUN_FORMAT,
  POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
  POST_SEARCH_V5_RUN_MAX_MANIFEST_BYTES,
  type PostSearchV5RunManifest,
} from './postSearchV5RunTypes';
import {
  assertPostSearchV5ExactKeys,
  equalPostSearchV5Bytes,
  postSearchV5BoundedNumber,
  postSearchV5Integer,
  postSearchV5NonEmptyString,
  postSearchV5Object,
  postSearchV5PositiveInteger,
  postSearchV5PositiveNumber,
} from './postSearchV5RunValidation';

const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export function parsePostSearchV5RunManifest(bytes: Uint8Array): PostSearchV5RunManifest {
  if (bytes.length === 0 || bytes.length > POST_SEARCH_V5_RUN_MAX_MANIFEST_BYTES) {
    throw new Error('Invalid post-search v5 run manifest byte length');
  }
  let raw: unknown;
  try {
    raw = JSON.parse(decoder.decode(bytes));
  } catch {
    throw new Error('Invalid post-search v5 run manifest JSON');
  }
  const value = postSearchV5Object(raw, 'run manifest');
  assertPostSearchV5ExactKeys(value, [
    'documentCount', 'entries', 'fields', 'format', 'k1', 'maxTokensPerField',
    'normalization', 'pages', 'postingCount', 'reachableNodeCount', 'storedValueCount',
    'termCount', 'tokenOccurrenceCount',
  ], 'run manifest');
  if (value.format !== POST_SEARCH_V5_RUN_FORMAT
    || value.normalization !== POST_SEARCH_V5_NORMALIZATION) {
    throw new Error('Unsupported post-search v5 run manifest');
  }
  const fields = parseManifestFields(value.fields);
  const pages = parseCounts(value.pages, ['documents', 'postings', 'terms', 'total'], 'pages');
  const entries = parseCounts(value.entries, ['documents', 'postings', 'terms'], 'entries');
  const manifest: PostSearchV5RunManifest = {
    format: POST_SEARCH_V5_RUN_FORMAT,
    normalization: POST_SEARCH_V5_NORMALIZATION,
    documentCount: postSearchV5PositiveInteger(value.documentCount, 'documentCount'),
    termCount: postSearchV5Integer(value.termCount, 'termCount'),
    postingCount: postSearchV5Integer(value.postingCount, 'postingCount'),
    storedValueCount: postSearchV5Integer(value.storedValueCount, 'storedValueCount'),
    tokenOccurrenceCount: postSearchV5Integer(
      value.tokenOccurrenceCount,
      'tokenOccurrenceCount',
    ),
    k1: postSearchV5PositiveNumber(value.k1, 'k1'),
    maxTokensPerField: postSearchV5PositiveInteger(
      value.maxTokensPerField,
      'maxTokensPerField',
    ),
    fields,
    pages: { ...pages, total: pages.total! } as PostSearchV5RunManifest['pages'],
    entries: entries as PostSearchV5RunManifest['entries'],
    reachableNodeCount: postSearchV5PositiveInteger(
      value.reachableNodeCount,
      'reachableNodeCount',
    ),
  };
  if (manifest.documentCount > POST_SEARCH_V5_RUN_MAX_DOCUMENTS
    || manifest.maxTokensPerField > POST_SEARCH_V5_MAX_TOKENS_PER_FIELD
    || manifest.storedValueCount > manifest.documentCount
    || manifest.entries.documents !== manifest.documentCount
    || manifest.entries.terms !== manifest.termCount
    || manifest.pages.total !== manifest.pages.documents
      + manifest.pages.postings + manifest.pages.terms
    || (manifest.termCount === 0) !== (manifest.postingCount === 0)) {
    throw new Error('Inconsistent post-search v5 run manifest');
  }
  if (!equalPostSearchV5Bytes(bytes, encodePostSearchV5RunManifest(manifest))) {
    throw new Error('Non-canonical post-search v5 run manifest');
  }
  return manifest;
}

function parseManifestFields(raw: unknown): RankedSearchFieldManifest[] {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > POST_SEARCH_V5_MAX_FIELDS) {
    throw new Error('Invalid post-search v5 manifest fields');
  }
  const fields = raw.map((item, index) => {
    const value = postSearchV5Object(item, `manifest field ${index}`);
    assertPostSearchV5ExactKeys(value, [
      'boost', 'lengthNormalization', 'name', 'populatedDocumentCount', 'totalLength',
    ], `manifest field ${index}`);
    return {
      name: postSearchV5NonEmptyString(value.name, `manifest field ${index} name`),
      boost: postSearchV5PositiveNumber(value.boost, `manifest field ${index} boost`),
      lengthNormalization: postSearchV5BoundedNumber(
        value.lengthNormalization,
        0,
        1,
        `manifest field ${index} normalization`,
      ),
      totalLength: postSearchV5Integer(
        value.totalLength,
        `manifest field ${index} totalLength`,
      ),
      populatedDocumentCount: postSearchV5Integer(
        value.populatedDocumentCount,
        `manifest field ${index} populated count`,
      ),
    };
  });
  if (fields.some((field, index) => index > 0 && field.name <= fields[index - 1]!.name)) {
    throw new Error('Non-canonical post-search v5 manifest fields');
  }
  return fields;
}

function parseCounts(
  raw: unknown,
  keys: readonly string[],
  label: string,
): Record<string, number> {
  const value = postSearchV5Object(raw, label);
  assertPostSearchV5ExactKeys(value, keys, label);
  return Object.fromEntries(keys.map((key) => [
    key,
    postSearchV5Integer(value[key], `${label}.${key}`),
  ]));
}

export function encodePostSearchV5RunManifest(
  manifest: PostSearchV5RunManifest,
): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length > POST_SEARCH_V5_RUN_MAX_MANIFEST_BYTES) {
    throw new Error('Post-search v5 run manifest is too large');
  }
  return bytes;
}
