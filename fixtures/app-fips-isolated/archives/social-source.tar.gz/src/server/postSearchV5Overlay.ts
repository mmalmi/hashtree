import type { RawEvent } from '../lib/nostr';
import {
  normalizePostSearchV5OverlayBounds,
  type PostSearchV5OverlayBounds,
} from './postSearchV5OverlayBounds';

export {
  POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS,
  normalizePostSearchV5OverlayBounds,
} from './postSearchV5OverlayBounds';
export type { PostSearchV5OverlayBounds } from './postSearchV5OverlayBounds';

export const POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT = 'iris-social/post-search-v5-visibility-overlay@1' as const;

const EVENT_DELETION_KIND = 5;
const ADDRESSABLE_POST_KIND = 30_023;
const HEX_64 = /^[0-9a-f]{64}$/;
const UTF8 = new TextEncoder();

export interface PostSearchV5EventReference {
  readonly eventId: string;
  readonly createdAt: number;
}

export interface PostSearchV5ExactTombstone extends PostSearchV5EventReference {
  /** The target event's author. An exact deletion never applies to another author. */
  readonly pubkey: string;
  readonly targetEventId: string;
}

export interface PostSearchV5CoordinateState {
  readonly coordinate: string;
  readonly winner: PostSearchV5EventReference | null;
  readonly deletion: PostSearchV5EventReference | null;
}

/**
 * Compact authenticated visibility state for immutable post-search segments.
 * It intentionally contains no event bodies, author names, or other profile fields.
 */
export interface PostSearchV5VisibilityOverlay {
  readonly format: typeof POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT;
  readonly bounds: PostSearchV5OverlayBounds;
  readonly exactTombstones: readonly PostSearchV5ExactTombstone[];
  readonly coordinates: readonly PostSearchV5CoordinateState[];
}

export interface PostSearchV5OverlayMutation {
  readonly overlay: PostSearchV5VisibilityOverlay;
  readonly changed: boolean;
  readonly exactTombstonesChanged: number;
  readonly coordinatesChanged: number;
  /** Overlay changes never require rewriting existing post-text segments. */
  readonly postTextReindexRequired: false;
}

export type PostSearchV5Visibility =
  | 'visible'
  | 'exact-deleted'
  | 'address-deleted'
  | 'superseded';

type MutableCoordinateState = {
  coordinate: string;
  winner: PostSearchV5EventReference | null;
  deletion: PostSearchV5EventReference | null;
};

export function createPostSearchV5VisibilityOverlay(bounds: Partial<PostSearchV5OverlayBounds> = {}): PostSearchV5VisibilityOverlay {
  return freezeOverlay(normalizePostSearchV5OverlayBounds(bounds), [], []);
}

/** Apply verified archive events without retaining their content or tags. */
export function updatePostSearchV5VisibilityOverlay(
  overlay: PostSearchV5VisibilityOverlay,
  events: Iterable<RawEvent>,
): PostSearchV5OverlayMutation {
  assertOverlay(overlay);
  let exact: Map<string, PostSearchV5ExactTombstone> | null = null;
  let coordinates: Map<string, MutableCoordinateState> | null = null;
  let exactTombstonesChanged = 0;
  let coordinatesChanged = 0;

  for (const rawEvent of events) {
    const event = normalizeEventIdentity(rawEvent);
    if (event.kind !== EVENT_DELETION_KIND && event.kind !== ADDRESSABLE_POST_KIND) {
      continue;
    }
    exact ??= exactMap(overlay.exactTombstones);
    coordinates ??= coordinateMap(overlay.coordinates);
    if (event.kind === EVENT_DELETION_KIND) {
      const changed = applyDeletion(event, exact, coordinates, overlay.bounds);
      exactTombstonesChanged += changed.exact;
      coordinatesChanged += changed.coordinates;
      continue;
    }
    const coordinate = postSearchCoordinate(event);
    if (!coordinate) {
      continue;
    }
    assertCoordinateSize(coordinate, overlay.bounds);
    const previous = coordinates.get(coordinate);
    const winner = reference(event);
    const nextWinner = !previous?.winner || isNewerReference(winner, previous.winner)
      ? winner
      : previous.winner;
    const next = normalizeCoordinateState({
      coordinate,
      winner: nextWinner,
      deletion: previous?.deletion ?? null,
    });
    if (!sameCoordinateState(previous, next)) {
      assertCoordinateCapacity(coordinates, coordinate, overlay.bounds);
      coordinatesChanged += 1;
      setCoordinate(coordinates, next);
    }
  }

  const changed = exactTombstonesChanged > 0 || coordinatesChanged > 0;
  const next = changed && exact && coordinates
    ? overlayFromMaps(overlay.bounds, exact, coordinates)
    : overlay;
  return {
    overlay: next,
    changed,
    exactTombstonesChanged,
    coordinatesChanged,
    postTextReindexRequired: false,
  };
}

/** Commutative compaction of independently built overlay shards. */
export function mergePostSearchV5VisibilityOverlays(
  overlays: readonly PostSearchV5VisibilityOverlay[],
): PostSearchV5VisibilityOverlay {
  if (overlays.length === 0) {
    return createPostSearchV5VisibilityOverlay();
  }
  const first = overlays[0];
  if (!first) {
    throw new Error('Missing first post-search v5 overlay');
  }
  assertOverlay(first);
  const bounds = first.bounds;
  const exact = new Map<string, PostSearchV5ExactTombstone>();
  const coordinates = new Map<string, MutableCoordinateState>();

  for (const overlay of overlays) {
    assertOverlay(overlay);
    if (!sameBounds(bounds, overlay.bounds)) {
      throw new Error('Post-search v5 overlays have different bounds');
    }
    for (const tombstone of overlay.exactTombstones) {
      const key = exactKey(tombstone.pubkey, tombstone.targetEventId);
      if (!exact.has(key) && exact.size >= bounds.maxExactTombstones) {
        throw new Error('Post-search v5 overlay exceeds maxExactTombstones');
      }
      exact.set(key, newerReference(tombstone, exact.get(key)) as PostSearchV5ExactTombstone);
    }
    for (const state of overlay.coordinates) {
      const previous = coordinates.get(state.coordinate);
      assertCoordinateCapacity(coordinates, state.coordinate, bounds);
      coordinates.set(state.coordinate, {
        coordinate: state.coordinate,
        winner: newerReference(state.winner, previous?.winner),
        deletion: newerReference(state.deletion, previous?.deletion),
      });
    }
  }
  for (const [coordinate, state] of coordinates) {
    setCoordinate(coordinates, normalizeCoordinateState(state));
    if (!coordinates.get(coordinate)) {
      coordinates.delete(coordinate);
    }
  }
  return overlayFromMaps(bounds, exact, coordinates);
}

/** Rebuild a canonical minimal overlay; useful as a compaction verification gate. */
export function compactPostSearchV5VisibilityOverlay(overlay: PostSearchV5VisibilityOverlay): PostSearchV5VisibilityOverlay {
  return mergePostSearchV5VisibilityOverlays([overlay]);
}

export function getPostSearchV5EventVisibility(
  overlay: PostSearchV5VisibilityOverlay,
  rawEvent: Pick<RawEvent, 'id' | 'pubkey' | 'created_at' | 'kind' | 'tags'>,
): PostSearchV5Visibility {
  const event = normalizeEventIdentity(rawEvent);
  const exact = findExact(overlay.exactTombstones, event.pubkey, event.id);
  if (exact) {
    return 'exact-deleted';
  }
  const coordinate = postSearchCoordinate(event);
  if (!coordinate) {
    return 'visible';
  }
  const state = findCoordinate(overlay.coordinates, coordinate);
  if (state?.deletion && event.created_at <= state.deletion.createdAt) {
    return 'address-deleted';
  }
  if (state?.winner && isNewerReference(state.winner, reference(event))) {
    return 'superseded';
  }
  return 'visible';
}

export function isPostSearchV5EventVisible(
  overlay: PostSearchV5VisibilityOverlay,
  event: Pick<RawEvent, 'id' | 'pubkey' | 'created_at' | 'kind' | 'tags'>,
): boolean {
  return getPostSearchV5EventVisibility(overlay, event) === 'visible';
}

export function serializePostSearchV5VisibilityOverlay(overlay: PostSearchV5VisibilityOverlay): string {
  assertOverlay(overlay);
  const serialized = JSON.stringify(freezeOverlay(overlay.bounds, overlay.exactTombstones, overlay.coordinates));
  if (UTF8.encode(serialized).byteLength > overlay.bounds.maxSerializedBytes) {
    throw new Error('Post-search v5 overlay exceeds maxSerializedBytes');
  }
  return serialized;
}

export function parsePostSearchV5VisibilityOverlay(
  input: string | Uint8Array,
  expectedBounds: Partial<PostSearchV5OverlayBounds> = {},
): PostSearchV5VisibilityOverlay {
  const bounds = normalizePostSearchV5OverlayBounds(expectedBounds);
  const bytes = typeof input === 'string' ? UTF8.encode(input) : input;
  if (bytes.byteLength > bounds.maxSerializedBytes) {
    throw new Error('Post-search v5 overlay exceeds maxSerializedBytes');
  }
  const text = typeof input === 'string' ? input : new TextDecoder('utf-8', { fatal: true }).decode(input);
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    throw new Error('Invalid post-search v5 overlay JSON');
  }
  const overlay = parseOverlayValue(value, bounds);
  if (serializePostSearchV5VisibilityOverlay(overlay) !== text) {
    throw new Error('Post-search v5 overlay is not canonically serialized');
  }
  return overlay;
}

function applyDeletion(
  event: RawEvent,
  exact: Map<string, PostSearchV5ExactTombstone>,
  coordinates: Map<string, MutableCoordinateState>,
  bounds: PostSearchV5OverlayBounds,
): { exact: number; coordinates: number } {
  const targets = new Set<string>();
  let exactChanged = 0;
  let coordinatesChanged = 0;
  for (const tag of event.tags) {
    const target = tag[1];
    if (tag[0] === 'e' && target && HEX_64.test(target.toLowerCase())) {
      const targetEventId = target.toLowerCase();
      const semanticKey = `e:${targetEventId}`;
      assertDeletionTargetCapacity(targets, semanticKey, bounds);
      if (targets.has(semanticKey)) {
        continue;
      }
      targets.add(semanticKey);
      const tombstone = freezeExact({
        pubkey: event.pubkey,
        targetEventId,
        eventId: event.id,
        createdAt: event.created_at,
      });
      const key = exactKey(event.pubkey, targetEventId);
      const previous = exact.get(key);
      const next = newerReference(tombstone, previous) as PostSearchV5ExactTombstone;
      if (next !== previous) {
        if (!previous && exact.size >= bounds.maxExactTombstones) {
          throw new Error('Post-search v5 overlay exceeds maxExactTombstones');
        }
        exact.set(key, next);
        exactChanged += 1;
      }
      continue;
    }
    if (tag[0] !== 'a' || !target) {
      continue;
    }
    const coordinate = normalizeAddressCoordinate(target);
    if (!coordinate || coordinate.pubkey !== event.pubkey) {
      continue;
    }
    assertCoordinateSize(coordinate.value, bounds);
    const semanticKey = `a:${coordinate.value}`;
    assertDeletionTargetCapacity(targets, semanticKey, bounds);
    if (targets.has(semanticKey)) {
      continue;
    }
    targets.add(semanticKey);
    const previous = coordinates.get(coordinate.value);
    const deletion = reference(event);
    const next = normalizeCoordinateState({
      coordinate: coordinate.value,
      winner: previous?.winner ?? null,
      deletion: newerReference(deletion, previous?.deletion),
    });
    if (!sameCoordinateState(previous, next)) {
      assertCoordinateCapacity(coordinates, coordinate.value, bounds);
      setCoordinate(coordinates, next);
      coordinatesChanged += 1;
    }
  }
  return { exact: exactChanged, coordinates: coordinatesChanged };
}

function overlayFromMaps(
  bounds: PostSearchV5OverlayBounds,
  exact: ReadonlyMap<string, PostSearchV5ExactTombstone>,
  coordinates: ReadonlyMap<string, MutableCoordinateState>,
): PostSearchV5VisibilityOverlay {
  if (exact.size > bounds.maxExactTombstones) {
    throw new Error('Post-search v5 overlay exceeds maxExactTombstones');
  }
  if (coordinates.size > bounds.maxCoordinates) {
    throw new Error('Post-search v5 overlay exceeds maxCoordinates');
  }
  return freezeOverlay(
    bounds,
    [...exact.values()].sort(compareExact),
    [...coordinates.values()].sort((left, right) => compareText(left.coordinate, right.coordinate)),
  );
}

function freezeOverlay(
  bounds: PostSearchV5OverlayBounds,
  exact: readonly PostSearchV5ExactTombstone[],
  coordinates: readonly PostSearchV5CoordinateState[],
): PostSearchV5VisibilityOverlay {
  return Object.freeze({
    format: POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT,
    bounds: normalizePostSearchV5OverlayBounds(bounds),
    exactTombstones: Object.freeze(exact.map(freezeExact)),
    coordinates: Object.freeze(coordinates.map((state) => Object.freeze({
      coordinate: state.coordinate,
      winner: freezeReference(state.winner),
      deletion: freezeReference(state.deletion),
    }))),
  });
}

function parseOverlayValue(value: unknown, expectedBounds: PostSearchV5OverlayBounds): PostSearchV5VisibilityOverlay {
  if (!isRecord(value) || value.format !== POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT
    || !sameBounds(value.bounds, expectedBounds)
    || !Array.isArray(value.exactTombstones) || !Array.isArray(value.coordinates)) {
    throw new Error('Invalid post-search v5 overlay');
  }
  const exact = value.exactTombstones.map(parseExact);
  const coordinates = value.coordinates.map((state) => parseCoordinate(state, expectedBounds));
  const overlay = freezeOverlay(expectedBounds, exact, coordinates);
  assertOverlay(overlay);
  return overlay;
}

function parseExact(value: unknown): PostSearchV5ExactTombstone {
  if (!isRecord(value) || !isCanonicalHex(value.pubkey) || !isCanonicalHex(value.targetEventId)
    || !isCanonicalHex(value.eventId) || !isTimestamp(value.createdAt)) {
    throw new Error('Invalid post-search v5 exact tombstone');
  }
  return freezeExact({
    pubkey: value.pubkey,
    targetEventId: value.targetEventId,
    eventId: value.eventId,
    createdAt: value.createdAt,
  });
}

function parseCoordinate(value: unknown, bounds: PostSearchV5OverlayBounds): PostSearchV5CoordinateState {
  if (!isRecord(value) || typeof value.coordinate !== 'string') {
    throw new Error('Invalid post-search v5 coordinate state');
  }
  const normalized = normalizeAddressCoordinate(value.coordinate);
  if (!normalized || normalized.value !== value.coordinate) {
    throw new Error('Invalid post-search v5 coordinate');
  }
  assertCoordinateSize(value.coordinate, bounds);
  return Object.freeze({
    coordinate: value.coordinate,
    winner: parseReference(value.winner),
    deletion: parseReference(value.deletion),
  });
}

function assertOverlay(overlay: PostSearchV5VisibilityOverlay): void {
  if (overlay.format !== POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT) {
    throw new Error('Unsupported post-search v5 overlay format');
  }
  normalizePostSearchV5OverlayBounds(overlay.bounds);
  if (overlay.exactTombstones.length > overlay.bounds.maxExactTombstones
    || overlay.coordinates.length > overlay.bounds.maxCoordinates) {
    throw new Error('Post-search v5 overlay exceeds configured bounds');
  }
  let previousExact = '';
  for (const tombstone of overlay.exactTombstones) {
    const parsed = parseExact(tombstone);
    const key = exactKey(parsed.pubkey, parsed.targetEventId);
    if (key <= previousExact) {
      throw new Error('Post-search v5 exact tombstones are not unique and sorted');
    }
    previousExact = key;
  }
  let previousCoordinate = '';
  for (const state of overlay.coordinates) {
    const parsed = parseCoordinate(state, overlay.bounds);
    if (parsed.coordinate <= previousCoordinate || (!parsed.winner && !parsed.deletion)) {
      throw new Error('Post-search v5 coordinates are not canonical and sorted');
    }
    const normalized = normalizeCoordinateState(parsed);
    if (!sameCoordinateState(parsed, normalized)) {
      throw new Error('Post-search v5 coordinate state is not compact');
    }
    previousCoordinate = parsed.coordinate;
  }
}

function normalizeCoordinateState(state: MutableCoordinateState): MutableCoordinateState {
  let winner = state.winner;
  if (winner && state.deletion && winner.createdAt <= state.deletion.createdAt) {
    winner = null;
  }
  return { coordinate: state.coordinate, winner, deletion: state.deletion };
}

function normalizeAddressCoordinate(value: string): { value: string; pubkey: string } | null {
  const first = value.indexOf(':');
  const second = value.indexOf(':', first + 1);
  if (first <= 0 || second < 0) {
    return null;
  }
  const kind = Number(value.slice(0, first));
  const pubkey = value.slice(first + 1, second).toLowerCase();
  const dTag = value.slice(second + 1);
  if (kind !== ADDRESSABLE_POST_KIND || !HEX_64.test(pubkey)) {
    return null;
  }
  return { value: `${kind}:${pubkey}:${dTag}`, pubkey };
}

function postSearchCoordinate(event: Pick<RawEvent, 'kind' | 'pubkey' | 'tags'>): string | null {
  if (event.kind !== ADDRESSABLE_POST_KIND) {
    return null;
  }
  const dTag = event.tags.find((tag) => tag[0] === 'd')?.[1] ?? '';
  return `${ADDRESSABLE_POST_KIND}:${event.pubkey}:${dTag}`;
}

function normalizeEventIdentity<T extends Pick<RawEvent, 'id' | 'pubkey' | 'created_at' | 'kind' | 'tags'>>(
  event: T,
): T & { id: string; pubkey: string } {
  const id = event.id.toLowerCase();
  const pubkey = event.pubkey.toLowerCase();
  if (!HEX_64.test(id) || !HEX_64.test(pubkey) || !isTimestamp(event.created_at)
    || !Number.isSafeInteger(event.kind) || event.kind < 0 || !Array.isArray(event.tags)) {
    throw new Error('Invalid post-search v5 overlay event identity');
  }
  return { ...event, id, pubkey };
}

function assertDeletionTargetCapacity(targets: ReadonlySet<string>, target: string, bounds: PostSearchV5OverlayBounds): void {
  if (!targets.has(target) && targets.size >= bounds.maxDeletionTargetsPerEvent) {
    throw new Error('Post-search v5 deletion exceeds maxDeletionTargetsPerEvent');
  }
}

function assertCoordinateSize(coordinate: string, bounds: PostSearchV5OverlayBounds): void {
  if (UTF8.encode(coordinate).byteLength > bounds.maxCoordinateBytes) {
    throw new Error('Post-search v5 coordinate exceeds maxCoordinateBytes');
  }
}

function assertCoordinateCapacity(
  coordinates: ReadonlyMap<string, MutableCoordinateState>, coordinate: string, bounds: PostSearchV5OverlayBounds,
): void {
  if (!coordinates.has(coordinate) && coordinates.size >= bounds.maxCoordinates) {
    throw new Error('Post-search v5 overlay exceeds maxCoordinates');
  }
}

function newerReference<T extends PostSearchV5EventReference>(
  candidate: T | null | undefined,
  existing: T | null | undefined,
): T | null {
  if (!candidate) {
    return existing ?? null;
  }
  return !existing || isNewerReference(candidate, existing) ? candidate : existing;
}

function isNewerReference(candidate: PostSearchV5EventReference, existing: PostSearchV5EventReference): boolean {
  return candidate.createdAt > existing.createdAt
    || (candidate.createdAt === existing.createdAt && candidate.eventId < existing.eventId);
}

function reference(event: Pick<RawEvent, 'id' | 'created_at'>): PostSearchV5EventReference {
  return Object.freeze({ eventId: event.id, createdAt: event.created_at });
}

function freezeReference(value: PostSearchV5EventReference | null): PostSearchV5EventReference | null {
  return value ? Object.freeze({ eventId: value.eventId, createdAt: value.createdAt }) : null;
}

function freezeExact(value: PostSearchV5ExactTombstone): PostSearchV5ExactTombstone {
  return Object.freeze({
    pubkey: value.pubkey,
    targetEventId: value.targetEventId,
    eventId: value.eventId,
    createdAt: value.createdAt,
  });
}

function parseReference(value: unknown): PostSearchV5EventReference | null {
  if (value === null) {
    return null;
  }
  if (!isRecord(value) || !isCanonicalHex(value.eventId) || !isTimestamp(value.createdAt)) {
    throw new Error('Invalid post-search v5 event reference');
  }
  return Object.freeze({ eventId: value.eventId, createdAt: value.createdAt });
}

function exactMap(values: readonly PostSearchV5ExactTombstone[]): Map<string, PostSearchV5ExactTombstone> {
  return new Map(values.map((value) => [exactKey(value.pubkey, value.targetEventId), value]));
}

function coordinateMap(values: readonly PostSearchV5CoordinateState[]): Map<string, MutableCoordinateState> {
  return new Map(values.map((value) => [value.coordinate, { ...value }]));
}

function setCoordinate(
  values: Map<string, MutableCoordinateState>,
  state: MutableCoordinateState,
): void {
  if (!state.winner && !state.deletion) {
    values.delete(state.coordinate);
  } else {
    values.set(state.coordinate, state);
  }
}

function findExact(
  values: readonly PostSearchV5ExactTombstone[],
  pubkey: string,
  eventId: string,
): PostSearchV5ExactTombstone | null {
  return binaryFind(values, exactKey(pubkey, eventId), (value) => exactKey(value.pubkey, value.targetEventId));
}

function findCoordinate(
  values: readonly PostSearchV5CoordinateState[],
  coordinate: string,
): PostSearchV5CoordinateState | null {
  return binaryFind(values, coordinate, (value) => value.coordinate);
}

function binaryFind<T>(values: readonly T[], wanted: string, key: (value: T) => string): T | null {
  let low = 0;
  let high = values.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const value = values[middle];
    if (!value) {
      return null;
    }
    const comparison = compareText(key(value), wanted);
    if (comparison === 0) {
      return value;
    }
    if (comparison < 0) {
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return null;
}

function exactKey(pubkey: string, eventId: string): string {
  return `${pubkey}:${eventId}`;
}

function compareExact(left: PostSearchV5ExactTombstone, right: PostSearchV5ExactTombstone): number {
  return compareText(exactKey(left.pubkey, left.targetEventId), exactKey(right.pubkey, right.targetEventId));
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function sameCoordinateState(
  left: PostSearchV5CoordinateState | undefined,
  right: PostSearchV5CoordinateState,
): boolean {
  return left?.coordinate === right.coordinate
    && sameReference(left.winner, right.winner)
    && sameReference(left.deletion, right.deletion);
}

function sameReference(
  left: PostSearchV5EventReference | null | undefined,
  right: PostSearchV5EventReference | null | undefined,
): boolean {
  return (left?.eventId ?? null) === (right?.eventId ?? null)
    && (left?.createdAt ?? null) === (right?.createdAt ?? null);
}

function sameBounds(left: unknown, right: PostSearchV5OverlayBounds): boolean {
  return isRecord(left)
    && left.maxExactTombstones === right.maxExactTombstones
    && left.maxCoordinates === right.maxCoordinates
    && left.maxDeletionTargetsPerEvent === right.maxDeletionTargetsPerEvent
    && left.maxCoordinateBytes === right.maxCoordinateBytes
    && left.maxSerializedBytes === right.maxSerializedBytes;
}

function isTimestamp(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
}

function isCanonicalHex(value: unknown): value is string {
  return typeof value === 'string' && HEX_64.test(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
