import type { PostSearchV5PackedPageEntry } from './postSearchV5PackedPage';
import { boundedKey } from './postSearchV5PageRouterCodec';
import {
  openPostSearchV5PageRouter,
  type PostSearchV5PageRouter,
  type PostSearchV5RoutedPage,
} from './postSearchV5PageRouter';
import {
  parsePostSearchV5StoredDocument,
  parsePostSearchV5TermStats,
  type PostSearchV5Posting,
  type PostSearchV5StoredDocument,
  type PostSearchV5TermStats,
} from './postSearchV5Run';
import {
  encodePostSearchV5RoutedDocument,
  encodePostSearchV5RoutedTermStats,
  parsePostSearchV5RoutedPostingKey,
  parsePostSearchV5RoutedPostingPart,
  postSearchV5PostingKey,
  postSearchV5RoutedPostingTerm,
} from './postSearchV5RoutedRunRecords';
import type {
  PostSearchV5RoutedRunEnvelope,
  PostSearchV5RoutedRunLookup,
  PostSearchV5RoutedRunManifest,
} from './postSearchV5RoutedRunTypes';
import {
  assertPostSearchV5RoutedCanonicalRaw,
  comparePostSearchV5RoutedText,
} from './postSearchV5RoutedRunValidation';
import type { Store } from '@hashtree/core';

export async function openPostSearchV5RoutedEnvelope(
  store: Store,
  envelope: PostSearchV5RoutedRunEnvelope,
): Promise<PostSearchV5RoutedRunLookup> {
  const documentRouter = await openPostSearchV5PageRouter(
    store,
    envelope.roots.documents,
    envelope.manifest.branches.documents,
  );
  const postingRouter = envelope.roots.postings && envelope.manifest.branches.postings
    ? await openPostSearchV5PageRouter(
        store,
        envelope.roots.postings,
        envelope.manifest.branches.postings,
      )
    : null;
  const termRouter = envelope.roots.terms && envelope.manifest.branches.terms
    ? await openPostSearchV5PageRouter(
        store,
        envelope.roots.terms,
        envelope.manifest.branches.terms,
      )
    : null;
  return {
    root: envelope.root,
    manifest: envelope.manifest,
    getDocument: createDocumentLookup(documentRouter, envelope.manifest),
    getTerm: async (term) => termRouter
      ? await lookupTerm(termRouter, term, envelope.manifest)
      : null,
    streamPostings: (term) => streamTermPostings(
      postingRouter,
      termRouter,
      term,
      envelope.manifest,
    ),
    streamDocuments: () => streamDocuments(documentRouter, envelope.manifest),
    streamTerms: () => streamTerms(termRouter, envelope.manifest),
    streamTermsByPrefix: (prefix) => streamTermsByPrefix(
      termRouter,
      envelope.manifest,
      prefix,
    ),
  };
}

export async function* streamPostSearchV5RoutedBranchEntries(
  router: PostSearchV5PageRouter,
): AsyncGenerator<PostSearchV5PackedPageEntry> {
  for await (const routed of router.rangePages(router.minKey, router.maxKey)) {
    for (const entry of routed.page.entries) {
      yield entry;
    }
  }
}

function createDocumentLookup(
  router: PostSearchV5PageRouter,
  manifest: PostSearchV5RoutedRunManifest,
): PostSearchV5RoutedRunLookup['getDocument'] {
  // Retain only one authenticated page (at most 1 MiB encoded), never the corpus.
  // Keep raw entries private and parse each result so callers cannot mutate the cache.
  let cached: PostSearchV5RoutedPage | null = null;
  return async (id) => {
    boundedKey(id, 'document id');
    const page = cached && id >= cached.descriptor.minKey && id <= cached.descriptor.maxKey
      ? cached
      : await router.lookupPage(id);
    cached = page;
    const entries = page?.page.entries ?? [];
    let low = 0;
    let high = entries.length;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      if (entries[middle]![0] < id) {
        low = middle + 1;
      } else {
        high = middle;
      }
    }
    const entry = entries[low];
    if (!entry || entry[0] !== id) {
      return null;
    }
    const parsed = parsePostSearchV5StoredDocument(id, entry[1], manifest);
    assertPostSearchV5RoutedCanonicalRaw(
      entry[1],
      encodePostSearchV5RoutedDocument(parsed, manifest),
      `document ${id}`,
    );
    return parsed;
  };
}

async function lookupTerm(
  router: PostSearchV5PageRouter,
  term: string,
  manifest: PostSearchV5RoutedRunManifest,
): Promise<PostSearchV5TermStats | null> {
  const normalized = postSearchV5RoutedPostingTerm(term);
  const page = await router.lookupPage(normalized);
  const entry = page?.page.entries.find(([key]) => key === normalized);
  if (!entry) {
    return null;
  }
  const parsed = parsePostSearchV5TermStats(entry[1], normalized, manifest);
  assertPostSearchV5RoutedCanonicalRaw(
    entry[1],
    encodePostSearchV5RoutedTermStats(parsed),
    `term ${normalized}`,
  );
  return parsed;
}

async function* streamDocuments(
  router: PostSearchV5PageRouter,
  manifest: PostSearchV5RoutedRunManifest,
): AsyncGenerator<[string, PostSearchV5StoredDocument]> {
  for await (const [id, raw] of streamPostSearchV5RoutedBranchEntries(router)) {
    const document = parsePostSearchV5StoredDocument(id, raw, manifest);
    assertPostSearchV5RoutedCanonicalRaw(
      raw,
      encodePostSearchV5RoutedDocument(document, manifest),
      `document ${id}`,
    );
    yield [id, document];
  }
}

async function* streamTerms(
  router: PostSearchV5PageRouter | null,
  manifest: PostSearchV5RoutedRunManifest,
): AsyncGenerator<[string, PostSearchV5TermStats]> {
  if (!router) {
    return;
  }
  for await (const [term, raw] of streamPostSearchV5RoutedBranchEntries(router)) {
    const stats = parsePostSearchV5TermStats(raw, term, manifest);
    assertPostSearchV5RoutedCanonicalRaw(
      raw,
      encodePostSearchV5RoutedTermStats(stats),
      `term ${term}`,
    );
    yield [term, stats];
  }
}

async function* streamTermsByPrefix(
  router: PostSearchV5PageRouter | null,
  manifest: PostSearchV5RoutedRunManifest,
  rawPrefix: string,
): AsyncGenerator<[string, PostSearchV5TermStats]> {
  if (!router) {
    return;
  }
  const prefix = postSearchV5RoutedPostingTerm(rawPrefix);
  for await (const routed of router.rangePages(prefix, `${prefix}\uffff`)) {
    for (const [term, raw] of routed.page.entries) {
      if (!term.startsWith(prefix)) {
        continue;
      }
      const stats = parsePostSearchV5TermStats(raw, term, manifest);
      assertPostSearchV5RoutedCanonicalRaw(
        raw,
        encodePostSearchV5RoutedTermStats(stats),
        `term ${term}`,
      );
      yield [term, stats];
    }
  }
}

async function* streamTermPostings(
  postingRouter: PostSearchV5PageRouter | null,
  termRouter: PostSearchV5PageRouter | null,
  rawTerm: string,
  manifest: PostSearchV5RoutedRunManifest,
): AsyncGenerator<PostSearchV5Posting> {
  if (!postingRouter || !termRouter) {
    return;
  }
  const term = postSearchV5RoutedPostingTerm(rawTerm);
  const stats = await lookupTerm(termRouter, term, manifest);
  if (!stats) {
    return;
  }
  const minimum = postSearchV5PostingKey(term, 0);
  const maximum = postSearchV5PostingKey(term, stats.postingParts - 1);
  let part = 0;
  let previousId: string | null = null;
  for await (const routed of postingRouter.rangePages(minimum, maximum)) {
    for (const [key, raw] of routed.page.entries) {
      if (comparePostSearchV5RoutedText(key, minimum) < 0
        || comparePostSearchV5RoutedText(key, maximum) > 0) {
        continue;
      }
      const parsedKey = parsePostSearchV5RoutedPostingKey(key);
      if (parsedKey.term !== term || parsedKey.part !== part) {
        throw new Error(`Post-search v5 routed posting parts are not contiguous: ${term}`);
      }
      const postings = parsePostSearchV5RoutedPostingPart(raw, key, manifest);
      for (const posting of postings) {
        if (previousId !== null
          && comparePostSearchV5RoutedText(previousId, posting.id) >= 0) {
          throw new Error(`Post-search v5 routed postings are duplicate or out of order: ${term}`);
        }
        previousId = posting.id;
        yield posting;
      }
      part += 1;
    }
  }
  if (part !== stats.postingParts) {
    throw new Error(`Post-search v5 routed posting coverage mismatch: ${term}`);
  }
}
