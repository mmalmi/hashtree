import {
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  type CID,
  type Store,
} from '@hashtree/core';
import { readPostSearchV5PageRouter } from './postSearchV5PageRouter';
import {
  assertPostSearchV5RoutedExpected,
  bindPostSearchV5RoutedBranchLink,
  parsePostSearchV5RoutedRunManifest,
} from './postSearchV5RoutedRunManifest';
import { openPostSearchV5RoutedEnvelope } from './postSearchV5RoutedRunLookup';
import {
  POST_SEARCH_V5_ROUTED_RUN_MAX_MANIFEST_BYTES,
  type PostSearchV5RoutedRunEnvelope,
  type PostSearchV5RoutedRunLookup,
  type PostSearchV5RoutedRunReadOptions,
} from './postSearchV5RoutedRunTypes';
import {
  assertPostSearchV5RoutedCanonicalLink,
  assertPostSearchV5RoutedExactLinkNames,
  equalPostSearchV5RoutedBytes,
  postSearchV5RoutedPositiveInteger,
  postSearchV5RoutedPublicCid,
  readPostSearchV5RoutedPublicBlock,
} from './postSearchV5RoutedRunValidation';
import { verifyPostSearchV5RoutedRunRecords } from './postSearchV5RoutedRunVerifier';

const MANIFEST_ENTRY = 'manifest.json';
const ROOT_MAX_BYTES = 65_536;

export async function openPostSearchV5RoutedRun(
  store: Store,
  root: CID,
): Promise<PostSearchV5RoutedRunLookup> {
  return await openPostSearchV5RoutedEnvelope(store, await readEnvelope(store, root));
}

/** Full bounded structural verification; no corpus-sized arrays or maps are retained. */
export async function readPostSearchV5RoutedRun(
  store: Store,
  root: CID,
  options: PostSearchV5RoutedRunReadOptions = {},
): Promise<PostSearchV5RoutedRunLookup> {
  const envelope = await readEnvelope(store, root);
  assertPostSearchV5RoutedExpected(envelope.manifest, options.expected ?? {});
  const maximum = options.maxReachableNodeCount === undefined
    ? Number.MAX_SAFE_INTEGER
    : postSearchV5RoutedPositiveInteger(
        options.maxReachableNodeCount,
        'maxReachableNodeCount',
      );
  if (envelope.manifest.reachableNodeCount > maximum) {
    throw new Error('Post-search v5 routed run exceeds its reachable-node capacity');
  }
  await Promise.all([
    readPostSearchV5PageRouter(
      store,
      envelope.roots.documents,
      envelope.manifest.branches.documents,
    ),
    envelope.roots.postings && envelope.manifest.branches.postings
      ? readPostSearchV5PageRouter(
          store,
          envelope.roots.postings,
          envelope.manifest.branches.postings,
        )
      : Promise.resolve(null),
    envelope.roots.terms && envelope.manifest.branches.terms
      ? readPostSearchV5PageRouter(
          store,
          envelope.roots.terms,
          envelope.manifest.branches.terms,
        )
      : Promise.resolve(null),
  ]);
  const lookup = await openPostSearchV5RoutedEnvelope(store, envelope);
  await verifyPostSearchV5RoutedRunRecords(lookup, store, envelope.roots.postings);
  return lookup;
}

async function readEnvelope(
  store: Store,
  root: CID,
): Promise<PostSearchV5RoutedRunEnvelope> {
  const rootBytes = await readPostSearchV5RoutedPublicBlock(
    store,
    root,
    ROOT_MAX_BYTES,
    'run root',
  );
  let node;
  try {
    node = decodeTreeNode(rootBytes);
  } catch {
    throw new Error('Post-search v5 routed run root is not a directory');
  }
  if (node.type !== LinkType.Dir
    || !equalPostSearchV5RoutedBytes(encodeTreeNode(node), rootBytes)) {
    throw new Error('Post-search v5 routed run root is not a canonical directory');
  }
  node.links.forEach(assertPostSearchV5RoutedCanonicalLink);
  const manifestLink = node.links.find((link) => link.name === MANIFEST_ENTRY);
  if (!manifestLink || manifestLink.type !== LinkType.Blob) {
    throw new Error('Post-search v5 routed run manifest link is missing');
  }
  const manifestBytes = await readPostSearchV5RoutedPublicBlock(
    store,
    { hash: manifestLink.hash },
    POST_SEARCH_V5_ROUTED_RUN_MAX_MANIFEST_BYTES,
    'run manifest',
  );
  if (manifestLink.size !== manifestBytes.length) {
    throw new Error('Post-search v5 routed run manifest link size is inconsistent');
  }
  const manifest = parsePostSearchV5RoutedRunManifest(manifestBytes);
  const expectedNames = manifest.termCount === 0
    ? ['documents', MANIFEST_ENTRY]
    : ['documents', MANIFEST_ENTRY, 'postings', 'terms'];
  assertPostSearchV5RoutedExactLinkNames(node.links, expectedNames);
  const documents = bindPostSearchV5RoutedBranchLink(
    node.links,
    'documents',
    manifest.branches.documents,
  );
  const postings = manifest.branches.postings
    ? bindPostSearchV5RoutedBranchLink(node.links, 'postings', manifest.branches.postings)
    : null;
  const terms = manifest.branches.terms
    ? bindPostSearchV5RoutedBranchLink(node.links, 'terms', manifest.branches.terms)
    : null;
  return {
    root: postSearchV5RoutedPublicCid(root, 'run root'),
    manifest,
    roots: { documents, postings, terms },
  };
}
