const ABSOLUTE_MAX_RECORDS = 2_000_000;
const ABSOLUTE_MAX_DELETION_TARGETS = 16_384;
const ABSOLUTE_MAX_COORDINATE_BYTES = 16 * 1024;
const ABSOLUTE_MAX_SERIALIZED_BYTES = 256 * 1024 * 1024;

export interface PostSearchV5OverlayBounds {
  readonly maxExactTombstones: number;
  readonly maxCoordinates: number;
  readonly maxDeletionTargetsPerEvent: number;
  readonly maxCoordinateBytes: number;
  readonly maxSerializedBytes: number;
}

export const POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS: PostSearchV5OverlayBounds = Object.freeze({
  maxExactTombstones: 250_000,
  maxCoordinates: 250_000,
  maxDeletionTargetsPerEvent: 1_024,
  maxCoordinateBytes: 4 * 1024,
  maxSerializedBytes: 64 * 1024 * 1024,
});

export function normalizePostSearchV5OverlayBounds(
  input: Partial<PostSearchV5OverlayBounds>,
): PostSearchV5OverlayBounds {
  const bounds: PostSearchV5OverlayBounds = {
    maxExactTombstones: input.maxExactTombstones
      ?? POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS.maxExactTombstones,
    maxCoordinates: input.maxCoordinates ?? POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS.maxCoordinates,
    maxDeletionTargetsPerEvent: input.maxDeletionTargetsPerEvent
      ?? POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS.maxDeletionTargetsPerEvent,
    maxCoordinateBytes: input.maxCoordinateBytes
      ?? POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS.maxCoordinateBytes,
    maxSerializedBytes: input.maxSerializedBytes
      ?? POST_SEARCH_V5_DEFAULT_OVERLAY_BOUNDS.maxSerializedBytes,
  };
  assertBound(bounds.maxExactTombstones, ABSOLUTE_MAX_RECORDS, 'maxExactTombstones');
  assertBound(bounds.maxCoordinates, ABSOLUTE_MAX_RECORDS, 'maxCoordinates');
  assertBound(
    bounds.maxDeletionTargetsPerEvent,
    ABSOLUTE_MAX_DELETION_TARGETS,
    'maxDeletionTargetsPerEvent',
  );
  assertBound(bounds.maxCoordinateBytes, ABSOLUTE_MAX_COORDINATE_BYTES, 'maxCoordinateBytes');
  assertBound(bounds.maxSerializedBytes, ABSOLUTE_MAX_SERIALIZED_BYTES, 'maxSerializedBytes');
  return Object.freeze(bounds);
}

export function parsePostSearchV5OverlayBounds(value: unknown): PostSearchV5OverlayBounds {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Invalid post-search v5 visibility overlay bounds');
  }
  const bounds = value as Record<string, unknown>;
  return normalizePostSearchV5OverlayBounds({
    maxExactTombstones: boundValue(bounds.maxExactTombstones, 'maxExactTombstones'),
    maxCoordinates: boundValue(bounds.maxCoordinates, 'maxCoordinates'),
    maxDeletionTargetsPerEvent: boundValue(
      bounds.maxDeletionTargetsPerEvent,
      'maxDeletionTargetsPerEvent',
    ),
    maxCoordinateBytes: boundValue(bounds.maxCoordinateBytes, 'maxCoordinateBytes'),
    maxSerializedBytes: boundValue(bounds.maxSerializedBytes, 'maxSerializedBytes'),
  });
}

function boundValue(value: unknown, name: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < 1) {
    throw new Error(`Invalid post-search v5 ${name}`);
  }
  return value as number;
}

function assertBound(value: number, maximum: number, name: string): void {
  if (!Number.isSafeInteger(value) || value < 1 || value > maximum) {
    throw new Error(`Invalid post-search v5 ${name}`);
  }
}
