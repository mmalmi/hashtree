/** Hashtree daemon's authenticated full-DAG traversal safety limit. */
export const HASHTREE_PIN_TREE_NODE_LIMIT = 10_000_000;
