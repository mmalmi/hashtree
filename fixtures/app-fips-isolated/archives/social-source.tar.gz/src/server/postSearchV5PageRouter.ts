import {
  HashTree,
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  sha256,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';
import {
  POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
  decodePostSearchV5PackedPage,
  type PostSearchV5PackedPage,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import {
  POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN,
  POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES,
  asAsync,
  assertCanonicalLink,
  assertExpected,
  assertNodeDescriptor,
  assertPublicCid,
  boundedKey,
  boundedInteger,
  canEncodeInternal,
  canEncodeLeaf,
  checkedPageKind,
  childName,
  compareText,
  containingChild,
  encodeIndex,
  equalBytes,
  fromWireNode,
  fromWirePage,
  internalIndex,
  intersects,
  isRecord,
  leafIndex,
  nodeSummary,
  parseIndex,
  publicCid,
  queryKey,
  readPublicBlock,
  safeAdd,
  toWireNode,
  toWirePage,
  type PageRouterIndex,
  type WireNodeDescriptor,
  type WirePageDescriptor,
} from './postSearchV5PageRouterCodec';

export {
  POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
  POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN,
  POST_SEARCH_V5_PAGE_ROUTER_MAX_HEIGHT,
  POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES,
} from './postSearchV5PageRouterCodec';

const INDEX_ENTRY = 'index.json';

export interface PostSearchV5PageDescriptor {
  minKey: string;
  maxKey: string;
  root: CID;
  byteLength: number;
  entryCount: number;
}

export interface PostSearchV5PageRouterSummary {
  root: CID;
  pageKind: PostSearchV5PackedPageKind;
  minKey: string;
  maxKey: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
}

export interface PostSearchV5RoutedPage {
  descriptor: PostSearchV5PageDescriptor;
  page: PostSearchV5PackedPage;
}

export interface PostSearchV5PageRouter extends PostSearchV5PageRouterSummary {
  lookupPage(key: string): Promise<PostSearchV5RoutedPage | null>;
  rangePages(minKey: string, maxKey: string): AsyncGenerator<PostSearchV5RoutedPage>;
}

export interface PostSearchV5VerifiedPageRouter extends PostSearchV5PageRouterSummary {
  verifiedPageCount: number;
  verifiedReachableNodeCount: number;
}

export type PostSearchV5PageRouterExpected = Partial<Omit<
  PostSearchV5PageRouterSummary,
  'root'
>>;

interface LoadedNode {
  index: PageRouterIndex;
}

interface BuildState {
  store: Store;
  tree: HashTree;
  pageKind: PostSearchV5PackedPageKind;
}

export interface PostSearchV5PageRouterWriter {
  append(descriptor: PostSearchV5PageDescriptor): Promise<void>;
  appendPage(bytes: Uint8Array): Promise<PostSearchV5PageDescriptor>;
  finish(): Promise<PostSearchV5PageRouterSummary>;
}

type PageRouterWriterStatus = 'idle' | 'appending' | 'finishing' | 'finished' | 'failed';

class BoundedPageRouterWriter implements PostSearchV5PageRouterWriter {
  private readonly pendingPages: PostSearchV5PageDescriptor[] = [];
  private readonly levels: PostSearchV5PageRouterSummary[][] = [];
  private previous: PostSearchV5PageDescriptor | null = null;
  private status: PageRouterWriterStatus = 'idle';

  constructor(private readonly state: BuildState) {}

  append(raw: PostSearchV5PageDescriptor): Promise<void> {
    return this.performAppend(async () => {
      const descriptor = await validatePageDescriptor(
        this.state.store,
        this.state.pageKind,
        raw,
      );
      await this.appendDescriptor(descriptor);
    });
  }

  appendPage(rawBytes: Uint8Array): Promise<PostSearchV5PageDescriptor> {
    return this.performAppend(async () => {
      if (!(rawBytes instanceof Uint8Array)) {
        throw new Error('Invalid post-search v5 packed page bytes');
      }
      const bytes = new Uint8Array(rawBytes);
      const page = decodePostSearchV5PackedPage(bytes);
      if (page.kind !== this.state.pageKind) {
        throw new Error('Post-search v5 routed page kind is inconsistent');
      }
      const first = page.entries[0];
      const last = page.entries.at(-1);
      if (!first || !last) {
        throw new Error('Post-search v5 routed page coverage is inconsistent');
      }
      const hash = await sha256(bytes);
      await this.state.store.put(hash, bytes);
      const descriptor: PostSearchV5PageDescriptor = {
        minKey: first[0],
        maxKey: last[0],
        root: { hash: new Uint8Array(hash) },
        byteLength: bytes.length,
        entryCount: page.entries.length,
      };
      await this.appendDescriptor(descriptor);
      return descriptor;
    });
  }

  private performAppend<T>(operation: () => Promise<T>): Promise<T> {
    const stateError = this.operationError('append');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'appending';
    return operation().then(
      (result) => {
        this.status = 'idle';
        return result;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  finish(): Promise<PostSearchV5PageRouterSummary> {
    const stateError = this.operationError('finish');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'finishing';
    return this.finishOnce().then(
      (summary) => {
        this.status = 'finished';
        return summary;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private async appendDescriptor(descriptor: PostSearchV5PageDescriptor): Promise<void> {
    if (this.previous && compareText(this.previous.maxKey, descriptor.minKey) >= 0) {
      throw new Error('Post-search v5 page descriptors overlap or are out of order');
    }
    if (this.pendingPages.length > 0
      && !canEncodeLeaf(this.state.pageKind, [...this.pendingPages, descriptor])) {
      await this.flushPages();
    }
    if (!canEncodeLeaf(this.state.pageKind, [descriptor])) {
      throw new Error('Post-search v5 page descriptor cannot fit a bounded router block');
    }
    this.pendingPages.push(descriptor);
    this.previous = descriptor;
    if (this.pendingPages.length === POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN) {
      await this.flushPages();
    }
  }

  private async finishOnce(): Promise<PostSearchV5PageRouterSummary> {
    if (!this.previous) {
      throw new Error('Post-search v5 page router requires at least one page');
    }
    await this.flushPages();

    while (true) {
      const occupied = this.levels
        .map((nodes, level) => ({ nodes, level }))
        .filter(({ nodes }) => nodes.length > 0);
      if (occupied.length === 1 && occupied[0]!.nodes.length === 1) {
        return occupied[0]!.nodes[0]!;
      }
      const lowest = occupied[0];
      if (!lowest) {
        throw new Error('Post-search v5 page router builder lost its root');
      }
      this.levels[lowest.level] = [];
      await this.emit(lowest.level + 1, await writeInternalNode(this.state, lowest.nodes));
    }
  }

  private async emit(level: number, node: PostSearchV5PageRouterSummary): Promise<void> {
    const pending = this.levels[level] ?? [];
    this.levels[level] = pending;
    if (pending.length > 0 && !canEncodeInternal([...pending, node])) {
      this.levels[level] = [];
      await this.emit(level + 1, await writeInternalNode(this.state, pending));
    }
    const target = this.levels[level] ?? [];
    target.push(node);
    this.levels[level] = target;
    if (target.length === POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN) {
      this.levels[level] = [];
      await this.emit(level + 1, await writeInternalNode(this.state, target));
    }
  }

  private async flushPages(): Promise<void> {
    if (this.pendingPages.length === 0) {
      return;
    }
    const children = this.pendingPages.splice(0);
    await this.emit(0, await writeLeafNode(this.state, children));
  }

  private operationError(operation: 'append' | 'finish'): Error | null {
    if (this.status === 'failed') {
      return new Error('Post-search v5 page router writer has failed');
    }
    if (this.status === 'finished' || this.status === 'finishing') {
      return operation === 'finish'
        ? new Error('Post-search v5 page router writer finish may only be called once')
        : new Error('Post-search v5 page router writer cannot append after finish');
    }
    if (this.status !== 'idle') {
      return new Error(`Post-search v5 page router writer cannot ${operation} while another operation is in progress`);
    }
    return null;
  }
}

/** Create an incremental router writer. Callers must await each append before the next operation. */
export function createPostSearchV5PageRouterWriter(
  store: Store,
  pageKind: PostSearchV5PackedPageKind,
): PostSearchV5PageRouterWriter {
  return new BoundedPageRouterWriter({
    store,
    tree: new HashTree({ store }),
    pageKind: checkedPageKind(pageKind),
  });
}

/**
 * Build a deterministic authenticated router with bounded memory. Descriptors are
 * consumed once in sorted order and only one bounded pending group is retained
 * per tree height.
 */
export async function writePostSearchV5PageRouter(
  store: Store,
  pageKind: PostSearchV5PackedPageKind,
  descriptors: Iterable<PostSearchV5PageDescriptor> | AsyncIterable<PostSearchV5PageDescriptor>,
): Promise<PostSearchV5PageRouterSummary> {
  const writer = createPostSearchV5PageRouterWriter(store, pageKind);
  for await (const raw of asAsync(descriptors)) {
    await writer.append(raw);
  }
  return await writer.finish();
}

/** Open the root strictly, then verify only the logarithmic path(s) a query touches. */
export async function openPostSearchV5PageRouter(
  store: Store,
  root: CID,
  expected: PostSearchV5PageRouterExpected = {},
): Promise<PostSearchV5PageRouter> {
  const loaded = await readNode(store, root);
  const summary = nodeSummary(root, loaded.index);
  assertExpected(summary, expected);
  return {
    ...summary,
    lookupPage: async (key) => await lookupPage(store, loaded, queryKey(key, 'lookup key')),
    rangePages: (minKey, maxKey) => rangePages(
      store,
      loaded,
      queryKey(minKey, 'range minimum'),
      queryKey(maxKey, 'range maximum'),
    ),
  };
}

/** Traverse and verify the complete public DAG for a publication/capacity gate. */
export async function readPostSearchV5PageRouter(
  store: Store,
  root: CID,
  expected: PostSearchV5PageRouterExpected = {},
): Promise<PostSearchV5VerifiedPageRouter> {
  const rootNode = await readNode(store, root);
  const summary = nodeSummary(root, rootNode.index);
  assertExpected(summary, expected);
  const verified = await verifyLoadedSubtree(store, rootNode, null);
  if (verified.reachableNodeCount !== summary.reachableNodeCount) {
    throw new Error('Post-search v5 page router reachable-node count is inconsistent');
  }
  if (verified.pageCount !== summary.pageCount) {
    throw new Error('Post-search v5 page router page count is inconsistent');
  }
  return {
    ...summary,
    verifiedPageCount: verified.pageCount,
    verifiedReachableNodeCount: verified.reachableNodeCount,
  };
}

async function writeLeafNode(
  state: BuildState,
  children: readonly PostSearchV5PageDescriptor[],
): Promise<PostSearchV5PageRouterSummary> {
  const wireChildren = children.map(toWirePage);
  const index = leafIndex(state.pageKind, wireChildren);
  const entries = children.map((child, indexValue) => ({
    name: childName('leaf', indexValue),
    cid: child.root,
    size: child.byteLength,
    type: LinkType.Blob as const,
  }));
  return await writeNode(state, index, entries);
}

async function writeInternalNode(
  state: BuildState,
  children: readonly PostSearchV5PageRouterSummary[],
): Promise<PostSearchV5PageRouterSummary> {
  if (children.some((child) => child.pageKind !== state.pageKind)) {
    throw new Error('Post-search v5 page router child page kinds are inconsistent');
  }
  const index = internalIndex(state.pageKind, children.map(toWireNode));
  const entries = children.map((child, indexValue) => ({
    name: childName('internal', indexValue),
    cid: child.root,
    size: child.reachableNodeCount,
    type: LinkType.Dir as const,
  }));
  return await writeNode(state, index, entries);
}

async function writeNode(
  state: BuildState,
  index: PageRouterIndex,
  childEntries: Array<{
    name: string;
    cid: CID;
    size: number;
    type: LinkType.Blob | LinkType.Dir;
  }>,
): Promise<PostSearchV5PageRouterSummary> {
  const bytes = encodeIndex(index);
  const indexHash = await sha256(bytes);
  await state.store.put(indexHash, bytes);
  const indexRoot = { hash: indexHash };
  const root = (await state.tree.putDirectory([{
    name: INDEX_ENTRY,
    cid: indexRoot,
    size: bytes.length,
    type: LinkType.Blob,
  }, ...childEntries], { unencrypted: true })).cid;
  return nodeSummary(root, index);
}

async function lookupPage(
  store: Store,
  initial: LoadedNode,
  key: string,
): Promise<PostSearchV5RoutedPage | null> {
  let node = initial;
  while (true) {
    const index = node.index;
    const childIndex = containingChild(index.children, key);
    if (childIndex < 0) {
      return null;
    }
    if (index.kind === 'leaf') {
      const child = index.children[childIndex]!;
      return await readRoutedPage(store, index.pageKind, fromWirePage(child));
    }
    const child = index.children[childIndex]!;
    const descriptor = fromWireNode(child, index.pageKind);
    node = await readNode(store, descriptor.root);
    assertNodeDescriptor(node.index, descriptor);
  }
}

async function* rangePages(
  store: Store,
  initial: LoadedNode,
  minKey: string,
  maxKey: string,
): AsyncGenerator<PostSearchV5RoutedPage> {
  if (compareText(minKey, maxKey) > 0) {
    throw new Error('Post-search v5 page router range minimum exceeds maximum');
  }
  yield* visitRange(store, initial, minKey, maxKey);
}

async function* visitRange(
  store: Store,
  node: LoadedNode,
  minKey: string,
  maxKey: string,
): AsyncGenerator<PostSearchV5RoutedPage> {
  const index = node.index;
  for (const child of index.children) {
    if (!intersects(child.minKey, child.maxKey, minKey, maxKey)) {
      continue;
    }
    if (index.kind === 'leaf') {
      const leafChild = child as WirePageDescriptor;
      yield await readRoutedPage(store, index.pageKind, fromWirePage(leafChild));
    } else {
      const descriptor = fromWireNode(child as WireNodeDescriptor, index.pageKind);
      const loaded = await readNode(store, descriptor.root);
      assertNodeDescriptor(loaded.index, descriptor);
      yield* visitRange(store, loaded, minKey, maxKey);
    }
  }
}

async function verifyLoadedSubtree(
  store: Store,
  node: LoadedNode,
  expected: PostSearchV5PageRouterSummary | null,
): Promise<{ pageCount: number; reachableNodeCount: number }> {
  if (expected) {
    assertNodeDescriptor(node.index, expected);
  }
  let pageCount = 0;
  let reachableNodeCount = 2;
  if (node.index.kind === 'leaf') {
    for (const raw of node.index.children) {
      const descriptor = fromWirePage(raw);
      await readRoutedPage(store, node.index.pageKind, descriptor);
      pageCount = safeAdd(pageCount, 1);
      reachableNodeCount = safeAdd(reachableNodeCount, 1);
    }
  } else {
    for (const raw of node.index.children) {
      const descriptor = fromWireNode(raw, node.index.pageKind);
      const child = await readNode(store, descriptor.root);
      const verified = await verifyLoadedSubtree(store, child, descriptor);
      pageCount = safeAdd(pageCount, verified.pageCount);
      reachableNodeCount = safeAdd(reachableNodeCount, verified.reachableNodeCount);
    }
  }
  return { pageCount, reachableNodeCount };
}

async function readNode(store: Store, root: CID): Promise<LoadedNode> {
  const bytes = await readPublicBlock(store, root, POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES,
    'router node');
  let treeNode;
  try {
    treeNode = decodeTreeNode(bytes);
  } catch {
    throw new Error('Post-search v5 page router node is not a directory');
  }
  if (treeNode.type !== LinkType.Dir || !equalBytes(encodeTreeNode(treeNode), bytes)) {
    throw new Error('Post-search v5 page router node is not a canonical directory');
  }
  if (treeNode.links.length < 2
    || treeNode.links.length > POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN + 1) {
    throw new Error('Post-search v5 page router directory link count is invalid');
  }
  const names = new Set<string>();
  for (const link of treeNode.links) {
    assertCanonicalLink(link);
    if (!link.name || names.has(link.name)) {
      throw new Error('Post-search v5 page router directory has unnamed or duplicate links');
    }
    names.add(link.name);
  }
  const indexLink = treeNode.links.find((link) => link.name === INDEX_ENTRY);
  if (!indexLink || indexLink.type !== LinkType.Blob) {
    throw new Error('Post-search v5 page router metadata link is missing');
  }
  const indexBytes = await readPublicBlock(
    store,
    { hash: indexLink.hash },
    POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES,
    'router metadata',
  );
  if (indexLink.size !== indexBytes.length) {
    throw new Error('Post-search v5 page router metadata link size is inconsistent');
  }
  const index = parseIndex(indexBytes);
  assertDirectoryBindings(treeNode.links, index);
  return { index };
}

function assertDirectoryBindings(links: readonly Link[], index: PageRouterIndex): void {
  const expectedNames = new Set([
    INDEX_ENTRY,
    ...index.children.map((_child, childIndex) => childName(index.kind, childIndex)),
  ]);
  if (links.length !== expectedNames.size) {
    throw new Error('Post-search v5 page router contains missing or unbound links');
  }
  for (const link of links) {
    if (!expectedNames.has(link.name!)) {
      throw new Error(`Post-search v5 page router contains an unbound link: ${link.name}`);
    }
  }
  index.children.forEach((child, childIndex) => {
    const name = childName(index.kind, childIndex);
    const link = links.find((candidate) => candidate.name === name);
    const root = publicCid(child.root, `router child ${name}`);
    const expectedType = index.kind === 'leaf' ? LinkType.Blob : LinkType.Dir;
    const expectedSize = index.kind === 'leaf'
      ? (child as WirePageDescriptor).byteLength
      : (child as WireNodeDescriptor).reachableNodeCount;
    if (!link || link.type !== expectedType || link.size !== expectedSize
      || !equalBytes(link.hash, root.hash)) {
      throw new Error(`Post-search v5 page router child link is inconsistent: ${name}`);
    }
  });
}

async function validatePageDescriptor(
  store: Store,
  pageKind: PostSearchV5PackedPageKind,
  raw: PostSearchV5PageDescriptor,
): Promise<PostSearchV5PageDescriptor> {
  if (!isRecord(raw)) {
    throw new Error('Invalid post-search v5 page descriptor');
  }
  const descriptor: PostSearchV5PageDescriptor = {
    minKey: boundedKey(raw.minKey, 'page minimum'),
    maxKey: boundedKey(raw.maxKey, 'page maximum'),
    root: assertPublicCid(raw.root, 'page root'),
    byteLength: boundedInteger(raw.byteLength, 1, POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
      'page byteLength'),
    entryCount: boundedInteger(raw.entryCount, 1, POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
      'page entryCount'),
  };
  if (compareText(descriptor.minKey, descriptor.maxKey) > 0) {
    throw new Error('Post-search v5 page descriptor minimum exceeds maximum');
  }
  await readRoutedPage(store, pageKind, descriptor);
  return descriptor;
}

async function readRoutedPage(
  store: Store,
  pageKind: PostSearchV5PackedPageKind,
  descriptor: PostSearchV5PageDescriptor,
): Promise<PostSearchV5RoutedPage> {
  const bytes = await readPublicBlock(store, descriptor.root,
    POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES, 'packed page');
  if (bytes.length !== descriptor.byteLength) {
    throw new Error('Post-search v5 routed page byte length is inconsistent');
  }
  const page = decodePostSearchV5PackedPage(bytes);
  if (page.kind !== pageKind) {
    throw new Error('Post-search v5 routed page kind is inconsistent');
  }
  const first = page.entries[0];
  const last = page.entries.at(-1);
  if (page.entries.length !== descriptor.entryCount || !first || !last
    || first[0] !== descriptor.minKey || last[0] !== descriptor.maxKey) {
    throw new Error('Post-search v5 routed page coverage is inconsistent');
  }
  return { descriptor, page };
}
