import type { CID } from '@hashtree/core';
import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from '../lib/nostr';

const EVENT_DELETION_KIND = 5;
const ADDRESSABLE_KIND_MIN = 30_000;
const ADDRESSABLE_KIND_MAX = 40_000;
const HEX_64 = /^[0-9a-f]{64}$/;

export interface PostSearchSnapshotReader {
  validateSnapshot?(root: CID): Promise<void>;
  streamKind(
    root: CID,
    kind: number,
    options?: PostSearchKindStreamOptions,
  ): AsyncIterable<RawEvent>;
  getReplaceable?(root: CID, pubkey: string, kind: number): Promise<RawEvent | null>;
  getReplaceables?(
    root: CID,
    pubkeys: readonly string[],
    kind: number,
  ): Promise<ReadonlyMap<string, RawEvent | null>>;
  getParameterizedReplaceable?(
    root: CID,
    pubkey: string,
    kind: number,
    dTag: string,
  ): Promise<RawEvent | null>;
}

export interface PostSearchKindCursor {
  createdAt: number;
  eventId: string;
}

export interface PostSearchKindStreamOptions {
  /** Resume strictly after this event in newest-first by-kind-time order. */
  after?: PostSearchKindCursor;
}

export interface PostSearchDeletionReport {
  scanned: number;
  invalid: number;
  valid: number;
  exactTombstones: number;
  addressTombstones: number;
}

export interface PostSearchDeletionProjection {
  exact: Set<string>;
  address: Map<string, { createdAt: number; eventId: string }>;
  report: PostSearchDeletionReport;
}

export interface PostSearchKindReport {
  scanned: number;
  invalid: number;
  exactDeleted: number;
  addressDeleted: number;
  superseded: number;
  visible: number;
}

export type PostSearchEventVerifier = (event: RawEvent) => boolean;
export type PostSearchProgressObserver<T> = (report: Readonly<T>) => void | Promise<void>;
export type PostSearchDeletionAuthorPredicate = (pubkey: string) => boolean;

export function verifyPostSearchEvent(event: RawEvent): boolean {
  try {
    return verifyEvent({
      id: event.id,
      pubkey: event.pubkey,
      created_at: event.created_at,
      kind: event.kind,
      tags: event.tags.map((tag) => [...tag]),
      content: event.content,
      sig: event.sig,
    });
  } catch {
    return false;
  }
}

export async function scanPostSearchDeletions(
  reader: PostSearchSnapshotReader,
  root: CID,
  verify: PostSearchEventVerifier = verifyPostSearchEvent,
  onEventProcessed?: PostSearchProgressObserver<PostSearchDeletionReport>,
  includeAuthor?: PostSearchDeletionAuthorPredicate,
): Promise<PostSearchDeletionProjection> {
  const exact = new Set<string>();
  const address = new Map<string, { createdAt: number; eventId: string }>();
  const report: PostSearchDeletionReport = {
    scanned: 0,
    invalid: 0,
    valid: 0,
    exactTombstones: 0,
    addressTombstones: 0,
  };

  for await (const event of reader.streamKind(root, EVENT_DELETION_KIND)) {
    report.scanned += 1;
    if (event.kind !== EVENT_DELETION_KIND || !verify(event)) {
      report.invalid += 1;
      await onEventProcessed?.(report);
      continue;
    }
    report.valid += 1;
    if (includeAuthor && !includeAuthor(event.pubkey)) {
      await onEventProcessed?.(report);
      continue;
    }
    for (const tag of event.tags) {
      const target = tag[1];
      const exactTarget = target?.toLowerCase();
      if (tag[0] === 'e' && exactTarget && HEX_64.test(exactTarget)) {
        exact.add(exactDeletionKey(exactTarget, event.pubkey));
        continue;
      }
      if (tag[0] !== 'a' || !target) {
        continue;
      }
      const coordinate = normalizeAddressCoordinate(target);
      if (!coordinate || coordinate.pubkey !== event.pubkey) {
        continue;
      }
      const existing = address.get(coordinate.value);
      if (!existing || isNewer(event, existing)) {
        address.set(coordinate.value, { createdAt: event.created_at, eventId: event.id });
      }
    }
    await onEventProcessed?.(report);
  }
  report.exactTombstones = exact.size;
  report.addressTombstones = address.size;
  return { exact, address, report };
}

export function createPostSearchKindReport(): PostSearchKindReport {
  return {
    scanned: 0,
    invalid: 0,
    exactDeleted: 0,
    addressDeleted: 0,
    superseded: 0,
    visible: 0,
  };
}

export function visiblePostSearchEvent(
  event: RawEvent,
  deletions: PostSearchDeletionProjection,
  report: PostSearchKindReport,
  verify: PostSearchEventVerifier = verifyPostSearchEvent,
): boolean {
  report.scanned += 1;
  if (!verify(event)) {
    report.invalid += 1;
    return false;
  }
  if (isPostSearchExactDeleted(event, deletions)) {
    report.exactDeleted += 1;
    return false;
  }
  const coordinate = postSearchEventCoordinate(event);
  const addressDeletion = coordinate ? deletions.address.get(coordinate) : null;
  if (addressDeletion && event.created_at <= addressDeletion.createdAt) {
    report.addressDeleted += 1;
    return false;
  }
  return true;
}

export function isPostSearchExactDeleted(
  event: Pick<RawEvent, 'id' | 'pubkey'>,
  deletions: PostSearchDeletionProjection,
): boolean {
  return deletions.exact.has(exactDeletionKey(event.id, event.pubkey));
}

export function isPostSearchAddressDeleted(
  event: Pick<RawEvent, 'kind' | 'pubkey' | 'created_at' | 'tags'>,
  deletions: PostSearchDeletionProjection,
): boolean {
  const coordinate = event.kind === 0
    ? `0:${event.pubkey}:`
    : postSearchEventCoordinate(event);
  const deletion = coordinate ? deletions.address.get(coordinate) : null;
  return Boolean(deletion && event.created_at <= deletion.createdAt);
}

/** Select addressable winners without retaining full event bodies in memory. */
export async function selectPostSearchAddressableWinners(
  reader: PostSearchSnapshotReader,
  root: CID,
  kind: number,
  deletions: PostSearchDeletionProjection,
  report: PostSearchKindReport,
  verify: PostSearchEventVerifier = verifyPostSearchEvent,
  onEventProcessed?: PostSearchProgressObserver<PostSearchKindReport>,
): Promise<Map<string, { createdAt: number; eventId: string }>> {
  const winners = new Map<string, { createdAt: number; eventId: string }>();
  for await (const event of reader.streamKind(root, kind)) {
    if (visiblePostSearchEvent(event, deletions, report, verify)) {
      const coordinate = postSearchEventCoordinate(event);
      const existing = coordinate ? winners.get(coordinate) : null;
      if (coordinate && (!existing || isNewer(event, existing))) {
        if (existing) {
          report.superseded += 1;
        }
        winners.set(coordinate, { createdAt: event.created_at, eventId: event.id });
      } else if (coordinate) {
        report.superseded += 1;
      }
    }
    await onEventProcessed?.(report);
  }
  return winners;
}

export function isSelectedPostSearchWinner(
  event: RawEvent,
  winners: ReadonlyMap<string, { eventId: string }>,
  verify: PostSearchEventVerifier = verifyPostSearchEvent,
): boolean {
  if (!verify(event)) {
    return false;
  }
  const coordinate = postSearchEventCoordinate(event);
  return coordinate !== null && winners.get(coordinate)?.eventId === event.id;
}

export function postSearchEventCoordinate(
  event: Pick<RawEvent, 'kind' | 'pubkey' | 'tags'>,
): string | null {
  if (event.kind < ADDRESSABLE_KIND_MIN || event.kind >= ADDRESSABLE_KIND_MAX) {
    return null;
  }
  const dTag = event.tags.find((tag) => tag[0] === 'd')?.[1] ?? '';
  return `${event.kind}:${event.pubkey}:${dTag}`;
}

function exactDeletionKey(eventId: string, pubkey: string): string {
  return `${eventId.toLowerCase()}:${pubkey.toLowerCase()}`;
}

function normalizeAddressCoordinate(
  value: string,
): { value: string; pubkey: string } | null {
  const first = value.indexOf(':');
  const second = value.indexOf(':', first + 1);
  if (first <= 0 || second < 0) {
    return null;
  }
  const kind = Number(value.slice(0, first));
  const pubkey = value.slice(first + 1, second).toLowerCase();
  if (!Number.isInteger(kind)
    || (kind !== 0 && (kind < ADDRESSABLE_KIND_MIN || kind >= ADDRESSABLE_KIND_MAX))
    || !HEX_64.test(pubkey)) {
    return null;
  }
  return { value: `${kind}:${pubkey}:${value.slice(second + 1)}`, pubkey };
}

function isNewer(
  event: RawEvent,
  existing: { createdAt: number; eventId: string },
): boolean {
  return event.created_at > existing.createdAt
    || (event.created_at === existing.createdAt && event.id < existing.eventId);
}
