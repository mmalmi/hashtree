import {
  nhashDecode,
  nhashEncode,
  sha256,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';
import {
  POST_SEARCH_V5_PACKED_PAGE_FORMAT,
  POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import type {
  PostSearchV5PageDescriptor,
  PostSearchV5PageRouterExpected,
  PostSearchV5PageRouterSummary,
} from './postSearchV5PageRouter';

export const POST_SEARCH_V5_PAGE_ROUTER_FORMAT =
  'iris-social/post-search-v5-page-router@1' as const;
export const POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES = 1_048_576;
export const POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN = 128;
export const POST_SEARCH_V5_PAGE_ROUTER_MAX_HEIGHT = 52;

const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export interface WirePageDescriptor {
  minKey: string;
  maxKey: string;
  root: string;
  byteLength: number;
  entryCount: number;
}

export interface WireNodeDescriptor {
  minKey: string;
  maxKey: string;
  root: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
}

export interface PageRouterLeafIndex {
  format: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
  packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  pageKind: PostSearchV5PackedPageKind;
  kind: 'leaf';
  height: 0;
  minKey: string;
  maxKey: string;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
  children: WirePageDescriptor[];
}

export interface PageRouterInternalIndex {
  format: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
  packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  pageKind: PostSearchV5PackedPageKind;
  kind: 'internal';
  height: number;
  minKey: string;
  maxKey: string;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
  children: WireNodeDescriptor[];
}

export type PageRouterIndex = PageRouterLeafIndex | PageRouterInternalIndex;

export function leafIndex(
  pageKind: PostSearchV5PackedPageKind,
  children: WirePageDescriptor[],
): PageRouterLeafIndex {
  assertOrderedChildren(children);
  return {
    format: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    pageKind,
    kind: 'leaf',
    height: 0,
    minKey: children[0]!.minKey,
    maxKey: children.at(-1)!.maxKey,
    pageCount: children.length,
    routerNodeCount: 2,
    reachableNodeCount: children.length + 2,
    children,
  };
}

export function internalIndex(
  pageKind: PostSearchV5PackedPageKind,
  children: WireNodeDescriptor[],
): PageRouterInternalIndex {
  assertOrderedChildren(children);
  const height = children[0]!.height + 1;
  if (height > POST_SEARCH_V5_PAGE_ROUTER_MAX_HEIGHT
    || children.some((child) => child.height !== height - 1)) {
    throw new Error('Post-search v5 page router child heights are inconsistent');
  }
  return {
    format: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    pageKind,
    kind: 'internal',
    height,
    minKey: children[0]!.minKey,
    maxKey: children.at(-1)!.maxKey,
    pageCount: sum(children, 'pageCount'),
    routerNodeCount: safeAdd(2, sum(children, 'routerNodeCount')),
    reachableNodeCount: safeAdd(2, sum(children, 'reachableNodeCount')),
    children,
  };
}

export function parseIndex(bytes: Uint8Array): PageRouterIndex {
  const text = decodeUtf8(bytes, 'router metadata');
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error('Invalid post-search v5 page router metadata JSON');
  }
  if (!isRecord(raw) || raw.kind !== 'leaf' && raw.kind !== 'internal') {
    throw new Error('Invalid post-search v5 page router metadata schema');
  }
  assertExactKeys(raw, [
    'format', 'packedPageFormat', 'pageKind', 'kind', 'height', 'minKey', 'maxKey',
    'pageCount', 'routerNodeCount', 'reachableNodeCount', 'children',
  ], 'metadata');
  if (raw.format !== POST_SEARCH_V5_PAGE_ROUTER_FORMAT
    || raw.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || !isPageKind(raw.pageKind)
    || !Array.isArray(raw.children)
    || raw.children.length < 1
    || raw.children.length > POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN) {
    throw new Error('Invalid post-search v5 page router metadata format or children');
  }
  const index = raw.kind === 'leaf' ? parseLeafIndex(raw) : parseInternalIndex(raw);
  if (!equalBytes(encodeIndex(index), bytes)) {
    throw new Error('Post-search v5 page router metadata is not canonical');
  }
  return index;
}

function parseLeafIndex(raw: Record<string, unknown>): PageRouterLeafIndex {
  if (raw.height !== 0) {
    throw new Error('Post-search v5 page router leaf height is invalid');
  }
  const children = (raw.children as unknown[]).map(parseWirePage);
  const canonical = leafIndex(checkedPageKind(raw.pageKind), children);
  assertDeclaredIndex(raw, canonical);
  return canonical;
}

function parseInternalIndex(raw: Record<string, unknown>): PageRouterInternalIndex {
  const children = (raw.children as unknown[]).map(parseWireNode);
  const canonical = internalIndex(checkedPageKind(raw.pageKind), children);
  assertDeclaredIndex(raw, canonical);
  return canonical;
}

function parseWirePage(value: unknown, index: number): WirePageDescriptor {
  if (!isRecord(value)) {
    throw new Error(`Invalid post-search v5 routed page descriptor at ${index}`);
  }
  assertExactKeys(
    value,
    ['minKey', 'maxKey', 'root', 'byteLength', 'entryCount'],
    `page descriptor ${index}`,
  );
  const descriptor = {
    minKey: boundedKey(value.minKey, `page ${index} minimum`),
    maxKey: boundedKey(value.maxKey, `page ${index} maximum`),
    root: nhashEncode(publicCid(value.root, `page ${index} root`)),
    byteLength: boundedInteger(
      value.byteLength,
      1,
      POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
      `page ${index} byteLength`,
    ),
    entryCount: boundedInteger(
      value.entryCount,
      1,
      POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
      `page ${index} entryCount`,
    ),
  };
  if (compareText(descriptor.minKey, descriptor.maxKey) > 0) {
    throw new Error(`Post-search v5 page ${index} minimum exceeds maximum`);
  }
  return descriptor;
}

function parseWireNode(value: unknown, index: number): WireNodeDescriptor {
  if (!isRecord(value)) {
    throw new Error(`Invalid post-search v5 router child descriptor at ${index}`);
  }
  assertExactKeys(value, [
    'minKey', 'maxKey', 'root', 'height', 'pageCount', 'routerNodeCount',
    'reachableNodeCount',
  ], `node descriptor ${index}`);
  const descriptor = {
    minKey: boundedKey(value.minKey, `node ${index} minimum`),
    maxKey: boundedKey(value.maxKey, `node ${index} maximum`),
    root: nhashEncode(publicCid(value.root, `node ${index} root`)),
    height: boundedInteger(
      value.height,
      0,
      POST_SEARCH_V5_PAGE_ROUTER_MAX_HEIGHT,
      `node ${index} height`,
    ),
    pageCount: positiveInteger(value.pageCount, `node ${index} pageCount`),
    routerNodeCount: positiveInteger(value.routerNodeCount, `node ${index} routerNodeCount`),
    reachableNodeCount: positiveInteger(
      value.reachableNodeCount,
      `node ${index} reachableNodeCount`,
    ),
  };
  if (compareText(descriptor.minKey, descriptor.maxKey) > 0) {
    throw new Error(`Post-search v5 node ${index} minimum exceeds maximum`);
  }
  return descriptor;
}

function assertDeclaredIndex(
  raw: Record<string, unknown>,
  canonical: PageRouterIndex,
): void {
  for (const key of [
    'pageKind', 'height', 'minKey', 'maxKey', 'pageCount', 'routerNodeCount',
    'reachableNodeCount',
  ] as const) {
    if (raw[key] !== canonical[key]) {
      throw new Error(`Post-search v5 page router declared ${key} is inconsistent`);
    }
  }
}

function assertOrderedChildren(
  children: ReadonlyArray<{ minKey: string; maxKey: string }>,
): void {
  if (children.length < 1 || children.length > POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN) {
    throw new Error('Post-search v5 page router child count is invalid');
  }
  let previous: { minKey: string; maxKey: string } | undefined;
  for (const child of children) {
    boundedKey(child.minKey, 'child minimum');
    boundedKey(child.maxKey, 'child maximum');
    if (compareText(child.minKey, child.maxKey) > 0
      || previous && compareText(previous.maxKey, child.minKey) >= 0) {
      throw new Error('Post-search v5 page router children overlap or are out of order');
    }
    previous = child;
  }
}

export function assertNodeDescriptor(
  index: PageRouterIndex,
  expected: PostSearchV5PageRouterSummary,
): void {
  for (const key of [
    'pageKind', 'height', 'minKey', 'maxKey', 'pageCount', 'routerNodeCount',
    'reachableNodeCount',
  ] as const) {
    if (index[key] !== expected[key]) {
      throw new Error(`Post-search v5 page router child ${key} does not match its bound link`);
    }
  }
}

export function assertExpected(
  summary: PostSearchV5PageRouterSummary,
  expected: PostSearchV5PageRouterExpected,
): void {
  for (const key of [
    'pageKind', 'height', 'minKey', 'maxKey', 'pageCount', 'routerNodeCount',
    'reachableNodeCount',
  ] as const) {
    if (expected[key] !== undefined && expected[key] !== summary[key]) {
      throw new Error(`Post-search v5 page router expected ${key} does not match`);
    }
  }
}

export function nodeSummary(
  root: CID,
  index: PageRouterIndex,
): PostSearchV5PageRouterSummary {
  return {
    root,
    pageKind: index.pageKind,
    minKey: index.minKey,
    maxKey: index.maxKey,
    height: index.height,
    pageCount: index.pageCount,
    routerNodeCount: index.routerNodeCount,
    reachableNodeCount: index.reachableNodeCount,
  };
}

export function toWirePage(descriptor: PostSearchV5PageDescriptor): WirePageDescriptor {
  return {
    minKey: descriptor.minKey,
    maxKey: descriptor.maxKey,
    root: nhashEncode(descriptor.root),
    byteLength: descriptor.byteLength,
    entryCount: descriptor.entryCount,
  };
}

export function fromWirePage(descriptor: WirePageDescriptor): PostSearchV5PageDescriptor {
  return {
    minKey: descriptor.minKey,
    maxKey: descriptor.maxKey,
    root: publicCid(descriptor.root, 'page root'),
    byteLength: descriptor.byteLength,
    entryCount: descriptor.entryCount,
  };
}

export function toWireNode(summary: PostSearchV5PageRouterSummary): WireNodeDescriptor {
  return {
    minKey: summary.minKey,
    maxKey: summary.maxKey,
    root: nhashEncode(summary.root),
    height: summary.height,
    pageCount: summary.pageCount,
    routerNodeCount: summary.routerNodeCount,
    reachableNodeCount: summary.reachableNodeCount,
  };
}

export function fromWireNode(
  descriptor: WireNodeDescriptor,
  pageKind: PostSearchV5PackedPageKind,
): PostSearchV5PageRouterSummary {
  return {
    root: publicCid(descriptor.root, 'router child root'),
    pageKind,
    minKey: descriptor.minKey,
    maxKey: descriptor.maxKey,
    height: descriptor.height,
    pageCount: descriptor.pageCount,
    routerNodeCount: descriptor.routerNodeCount,
    reachableNodeCount: descriptor.reachableNodeCount,
  };
}

export function canEncodeLeaf(
  pageKind: PostSearchV5PackedPageKind,
  children: readonly PostSearchV5PageDescriptor[],
): boolean {
  return children.length <= POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN
    && encodedLength(leafIndex(pageKind, children.map(toWirePage)))
      <= POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES;
}

export function canEncodeInternal(
  children: readonly PostSearchV5PageRouterSummary[],
): boolean {
  if (children.length === 0) {
    return false;
  }
  return children.length <= POST_SEARCH_V5_PAGE_ROUTER_MAX_CHILDREN
    && encodedLength(internalIndex(children[0]!.pageKind, children.map(toWireNode)))
      <= POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES;
}

export function encodeIndex(index: PageRouterIndex): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(index));
  if (bytes.length > POST_SEARCH_V5_PAGE_ROUTER_MAX_METADATA_BYTES) {
    throw new Error('Post-search v5 page router metadata exceeds 1 MiB');
  }
  return bytes;
}

function encodedLength(index: PageRouterIndex): number {
  return encoder.encode(JSON.stringify(index)).length;
}

export function childName(kind: PageRouterIndex['kind'], index: number): string {
  return `${kind === 'leaf' ? 'page' : 'node'}-${index.toString().padStart(3, '0')}`;
}

export function containingChild(
  children: ReadonlyArray<{ minKey: string; maxKey: string }>,
  key: string,
): number {
  let low = 0;
  let high = children.length - 1;
  while (low <= high) {
    const middle = (low + high) >>> 1;
    const child = children[middle]!;
    if (compareText(key, child.minKey) < 0) {
      high = middle - 1;
    } else if (compareText(key, child.maxKey) > 0) {
      low = middle + 1;
    } else {
      return middle;
    }
  }
  return -1;
}

export function intersects(
  leftMin: string,
  leftMax: string,
  rightMin: string,
  rightMax: string,
): boolean {
  return compareText(leftMax, rightMin) >= 0 && compareText(leftMin, rightMax) <= 0;
}

export async function readPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  assertPublicCid(root, label);
  const bytes = await store.get(root.hash);
  if (!bytes) {
    throw new Error(`Missing post-search v5 ${label} block`);
  }
  if (bytes.length > maximum) {
    throw new Error(`Post-search v5 ${label} block exceeds its byte bound`);
  }
  const actual = await sha256(bytes);
  if (!equalBytes(actual, root.hash)) {
    throw new Error(`Post-search v5 ${label} block hash mismatch`);
  }
  return bytes;
}

export function assertCanonicalLink(link: Link): void {
  if (!(link.hash instanceof Uint8Array) || link.hash.length !== 32
    || link.key !== undefined || typeof link.name !== 'string'
    || !Number.isSafeInteger(link.size) || link.size < 0
    || link.meta !== undefined) {
    throw new Error('Post-search v5 page router contains an invalid or encrypted link');
  }
}

export function assertPublicCid(value: unknown, label: string): CID {
  if (!isRecord(value) || !(value.hash instanceof Uint8Array) || value.hash.length !== 32) {
    throw new Error(`Invalid post-search v5 ${label} CID`);
  }
  if (value.key !== undefined) {
    throw new Error(`Encrypted post-search v5 ${label} CIDs are unsupported`);
  }
  return { hash: new Uint8Array(value.hash) };
}

export function publicCid(value: unknown, label: string): CID {
  if (typeof value !== 'string') {
    return assertPublicCid(value, label);
  }
  let decoded: CID;
  try {
    decoded = nhashDecode(value);
  } catch {
    throw new Error(`Invalid post-search v5 ${label} nhash`);
  }
  return assertPublicCid(decoded, label);
}

export function boundedKey(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  const bytes = encoder.encode(value);
  if (bytes.length > POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES
    || decodeUtf8(bytes, label) !== value) {
    throw new Error(`Post-search v5 ${label} exceeds its canonical key bound`);
  }
  return value;
}

export function queryKey(value: unknown, label: string): string {
  return boundedKey(value, label);
}

export function boundedInteger(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (!Number.isSafeInteger(value)
    || (value as number) < minimum
    || (value as number) > maximum) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value as number;
}

function positiveInteger(value: unknown, label: string): number {
  return boundedInteger(value, 1, Number.MAX_SAFE_INTEGER, label);
}

function sum<T extends Record<K, number>, K extends keyof T>(
  values: readonly T[],
  key: K,
): number {
  return values.reduce((total, value) => safeAdd(total, value[key]), 0);
}

export function safeAdd(left: number, right: number): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error('Post-search v5 page router count exceeds safe integer capacity');
  }
  return result;
}

function decodeUtf8(bytes: Uint8Array, label: string): string {
  try {
    const value = decoder.decode(bytes);
    if (!equalBytes(encoder.encode(value), bytes)) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error(`Invalid UTF-8 in post-search v5 ${label}`);
  }
}

function assertExactKeys(
  value: Record<string, unknown>,
  expected: readonly string[],
  label: string,
): void {
  const actual = Object.keys(value).sort();
  const wanted = [...expected].sort();
  if (actual.length !== wanted.length
    || actual.some((key, index) => key !== wanted[index])) {
    throw new Error(`Post-search v5 page router ${label} has missing or unbound fields`);
  }
}

export async function* asAsync<T>(
  values: Iterable<T> | AsyncIterable<T>,
): AsyncGenerator<T> {
  if (!values || typeof values !== 'object'
    || !(Symbol.iterator in values) && !(Symbol.asyncIterator in values)) {
    throw new Error('Post-search v5 page router descriptors are not iterable');
  }
  for await (const value of values) {
    yield value;
  }
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isPageKind(value: unknown): value is PostSearchV5PackedPageKind {
  return value === 'documents' || value === 'postings'
    || value === 'terms' || value === 'visibility';
}

export function checkedPageKind(value: unknown): PostSearchV5PackedPageKind {
  if (!isPageKind(value)) {
    throw new Error(`Invalid post-search v5 page router kind: ${String(value)}`);
  }
  return value;
}

export function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

export function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
