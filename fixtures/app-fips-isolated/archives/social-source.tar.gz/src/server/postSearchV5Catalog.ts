import {
  HashTree,
  LinkType,
  nhashDecode,
  nhashEncode,
  type CID,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import {
  POST_SEARCH_KINDS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
} from '../lib/postSearchCatalogConstants';
import {
  HASHTREE_PIN_TREE_NODE_LIMIT,
} from './hashtreePinCapacity';
import {
  POST_SEARCH_V5_PACKED_PAGE_FORMAT,
} from './postSearchV5PackedPage';
import {
  POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
  readPostSearchV5VisibilityOverlay,
} from './postSearchV5OverlayStore';
import {
  POST_SEARCH_V5_RUN_FORMAT,
  readPostSearchV5Run,
} from './postSearchV5Run';

export { POST_SEARCH_V5_RUN_FORMAT } from './postSearchV5Run';

export const POST_SEARCH_V5_CATALOG_FORMAT =
  'iris-social/packed-post-search-catalog@5' as const;
export const POST_SEARCH_V5_PIN_PLANNING_LIMIT = 9_000_000;
export const POST_SEARCH_V5_MAX_LEVEL = 52;
export const POST_SEARCH_V5_MAX_RUNS_PER_LEVEL = 2;
export const POST_SEARCH_V5_MAX_ACTIVE_RUNS =
  (POST_SEARCH_V5_MAX_LEVEL + 1) * POST_SEARCH_V5_MAX_RUNS_PER_LEVEL;

const MANIFEST_ENTRY = 'manifest.json';
const OVERLAY_ENTRY = 'visibility-overlay';
const MANIFEST_MAX_BYTES = 256 * 1024;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const SUPPORTED_KINDS = new Set<number>(POST_SEARCH_KINDS);

export interface PostSearchV5Coverage {
  eventCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchV5SourceSnapshot {
  eventRoot: string;
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  coverage: PostSearchV5Coverage;
}

export interface PostSearchV5RunDescriptor {
  entry: string;
  level: number;
  oldestBatch: number;
  newestBatchExclusive: number;
  documentCount: number;
  postingCount: number;
  termCount: number;
  pageCount: number;
  /** Includes the run root, its page indexes, and every reachable packed page. */
  reachableNodeCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchV5RunInput extends Omit<PostSearchV5RunDescriptor, 'entry'> {
  root: CID;
}

export interface PostSearchV5OverlayDescriptor {
  entry: typeof OVERLAY_ENTRY;
  exactTombstoneCount: number;
  coordinateStateCount: number;
  addressWinnerCount: number;
  addressDeletionCount: number;
  pageCount: number;
  /** Includes the overlay root, its page indexes, and every reachable packed page. */
  reachableNodeCount: number;
}

export interface PostSearchV5OverlayInput extends Omit<PostSearchV5OverlayDescriptor, 'entry'> {
  root: CID;
}

export interface PostSearchV5CatalogManifest {
  format: typeof POST_SEARCH_V5_CATALOG_FORMAT;
  publisherId: string;
  generatedAt: number;
  batchSize: number;
  source: PostSearchV5SourceSnapshot;
  compatibility: {
    runFormat: typeof POST_SEARCH_V5_RUN_FORMAT;
    packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
    overlayFormat: typeof POST_SEARCH_V5_OVERLAY_STORE_FORMAT;
    normalization: typeof POST_SEARCH_NORMALIZATION;
  };
  runs: PostSearchV5RunDescriptor[];
  overlay: PostSearchV5OverlayDescriptor | null;
}

export interface PostSearchV5CatalogInput {
  publisherId: string;
  generatedAt: number;
  batchSize: number;
  source: PostSearchV5SourceSnapshot;
  runs: readonly PostSearchV5RunInput[];
  overlay: PostSearchV5OverlayInput | null;
}

export interface PostSearchV5Catalog {
  root: CID;
  manifest: PostSearchV5CatalogManifest;
  runs: Array<PostSearchV5RunDescriptor & { root: CID }>;
  overlay: (PostSearchV5OverlayDescriptor & { root: CID }) | null;
}

export interface PostSearchV5PinCapacityEstimate {
  catalogNodes: number;
  runNodes: number;
  overlayNodes: number;
  estimatedReachableNodes: number;
  planningLimit: number;
  daemonHardLimit: number;
}

type PostSearchV5CapacitySource = Pick<PostSearchV5CatalogInput, 'runs' | 'overlay'> | Pick<
  PostSearchV5CatalogManifest,
  'runs' | 'overlay'
>;

/**
 * Sum each independently measured run DAG. Cross-run deduplication can only make
 * the daemon traversal smaller, so this remains a safe publication estimate.
 */
export function gatePostSearchV5CatalogCapacity(
  source: PostSearchV5CapacitySource,
  planningLimit = POST_SEARCH_V5_PIN_PLANNING_LIMIT,
): PostSearchV5PinCapacityEstimate {
  if (!Number.isSafeInteger(planningLimit)
    || planningLimit <= 0
    || planningLimit > HASHTREE_PIN_TREE_NODE_LIMIT) {
    throw new Error('Post-search v5 pin planning limit is invalid');
  }
  const runNodes = source.runs.reduce(
    (sum, candidate) => safeAdd(sum, nonNegativeInteger(
      candidate.reachableNodeCount,
      'run reachableNodeCount',
    )),
    0,
  );
  const overlayNodes = source.overlay
    ? nonNegativeInteger(source.overlay.reachableNodeCount, 'overlay reachableNodeCount')
    : 0;
  // One catalog directory and one bounded single-block manifest.
  const catalogNodes = 2;
  const estimatedReachableNodes = safeAdd(
    safeAdd(catalogNodes, runNodes),
    overlayNodes,
  );
  const estimate = {
    catalogNodes,
    runNodes,
    overlayNodes,
    estimatedReachableNodes,
    planningLimit,
    daemonHardLimit: HASHTREE_PIN_TREE_NODE_LIMIT,
  };
  if (estimatedReachableNodes >= planningLimit) {
    throw new Error(
      'Post-search v5 catalog exceeds the authenticated full-DAG pin planning capacity: '
      + `${estimatedReachableNodes} estimated reachable nodes >= ${planningLimit} planning limit `
      + `(${HASHTREE_PIN_TREE_NODE_LIMIT} daemon hard limit)`,
    );
  }
  return estimate;
}

export async function writePostSearchV5Catalog(
  store: Store,
  input: PostSearchV5CatalogInput,
): Promise<CID> {
  // Reject a declared over-capacity layout before doing expensive child reads.
  gatePostSearchV5CatalogCapacity(input);
  const publisherId = publisher(input.publisherId);
  const generatedAt = nonNegativeInteger(input.generatedAt, 'generatedAt');
  const batchSize = positiveInteger(input.batchSize, 'batchSize');
  const runs = await validateRunInputs(store, input.runs, batchSize);
  const source = sourceSnapshot(input.source, runs);
  const overlay = await validateOverlayInput(store, input.overlay);
  gatePostSearchV5CatalogCapacity({ runs, overlay });

  const manifest: PostSearchV5CatalogManifest = {
    format: POST_SEARCH_V5_CATALOG_FORMAT,
    publisherId,
    generatedAt,
    batchSize,
    source,
    compatibility: {
      runFormat: POST_SEARCH_V5_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      overlayFormat: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
    },
    runs: runs.map(({ root: _root, ...descriptor }) => descriptor),
    overlay: overlay ? (({ root: _root, ...descriptor }) => descriptor)(overlay) : null,
  };
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length > MANIFEST_MAX_BYTES) {
    throw new Error('Post-search v5 catalog manifest exceeds its authenticated reader capacity');
  }
  const tree = new HashTree({ store });
  const manifestFile = await tree.putFile(bytes);
  const entries: TreeEntry[] = [{
    name: MANIFEST_ENTRY,
    cid: manifestFile.cid,
    size: manifestFile.size,
    type: LinkType.File,
  }];
  for (const run of runs) {
    entries.push({
      name: run.entry,
      cid: run.root,
      size: run.reachableNodeCount,
      type: LinkType.Dir,
    });
  }
  if (overlay) {
    entries.push({
      name: overlay.entry,
      cid: overlay.root,
      size: overlay.reachableNodeCount,
      type: LinkType.Dir,
    });
  }
  return (await tree.putDirectory(entries)).cid;
}

export async function readPostSearchV5Catalog(
  store: Store,
  root: CID,
): Promise<PostSearchV5Catalog> {
  const tree = new HashTree({ store });
  const entries = await tree.listDirectory(root);
  const manifestEntry = entries.find((entry) => entry.name === MANIFEST_ENTRY);
  if (!manifestEntry || manifestEntry.type !== LinkType.File) {
    throw new Error('Post-search v5 catalog manifest is missing');
  }
  const bytes = await tree.readFile(manifestEntry.cid, { maxBytes: MANIFEST_MAX_BYTES });
  if (!bytes) {
    throw new Error('Post-search v5 catalog manifest is unreadable');
  }
  const manifest = parsePostSearchV5CatalogManifest(decodeUtf8(bytes));
  const expectedEntries = new Set([
    MANIFEST_ENTRY,
    ...manifest.runs.map((run) => run.entry),
    ...(manifest.overlay ? [manifest.overlay.entry] : []),
  ]);
  for (const entry of entries) {
    if (!expectedEntries.has(entry.name)) {
      throw new Error(`Post-search v5 catalog contains an unbound root link: ${entry.name}`);
    }
  }
  if (manifest.overlay && !entries.some((entry) => entry.name === manifest.overlay!.entry)) {
    throw new Error('Post-search v5 visibility overlay is missing');
  }
  if (entries.length !== expectedEntries.size) {
    throw new Error('Post-search v5 catalog root entries are inconsistent');
  }
  const byName = new Map(entries.map((entry) => [entry.name, entry]));
  const runs = manifest.runs.map((descriptor) => {
    const entry = byName.get(descriptor.entry);
    if (!entry || entry.type !== LinkType.Dir || entry.size !== descriptor.reachableNodeCount) {
      throw new Error(`Post-search v5 catalog run is missing or inconsistent: ${descriptor.entry}`);
    }
    return { ...descriptor, root: entry.cid };
  });
  let overlay: (PostSearchV5OverlayDescriptor & { root: CID }) | null = null;
  if (manifest.overlay) {
    const entry = byName.get(manifest.overlay.entry);
    if (!entry || entry.type !== LinkType.Dir || entry.size !== manifest.overlay.reachableNodeCount) {
      throw new Error('Post-search v5 visibility overlay is missing or inconsistent');
    }
    overlay = { ...manifest.overlay, root: entry.cid };
  }
  gatePostSearchV5CatalogCapacity(manifest);
  return { root, manifest, runs, overlay };
}

export function parsePostSearchV5CatalogManifest(raw: string): PostSearchV5CatalogManifest {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Invalid post-search v5 catalog JSON');
  }
  if (!isObject(value) || value.format !== POST_SEARCH_V5_CATALOG_FORMAT) {
    throw new Error('Unsupported post-search v5 catalog format');
  }
  if (!isObject(value.compatibility)
    || value.compatibility.runFormat !== POST_SEARCH_V5_RUN_FORMAT
    || value.compatibility.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || value.compatibility.overlayFormat !== POST_SEARCH_V5_OVERLAY_STORE_FORMAT
    || value.compatibility.normalization !== POST_SEARCH_NORMALIZATION) {
    throw new Error('Incompatible post-search v5 catalog');
  }
  if (!Array.isArray(value.runs) || value.runs.length > POST_SEARCH_V5_MAX_ACTIVE_RUNS) {
    throw new Error('Invalid post-search v5 catalog runs');
  }
  const batchSize = positiveInteger(value.batchSize, 'batchSize');
  const runs = value.runs.map((candidate, index) => parseRunDescriptor(candidate, index));
  assertRunLayout(runs, batchSize);
  const source = sourceSnapshot(value.source, runs);
  const overlay = value.overlay === null ? null : parseOverlayDescriptor(value.overlay);
  const manifest: PostSearchV5CatalogManifest = {
    format: POST_SEARCH_V5_CATALOG_FORMAT,
    publisherId: publisher(value.publisherId),
    generatedAt: nonNegativeInteger(value.generatedAt, 'generatedAt'),
    batchSize,
    source,
    compatibility: {
      runFormat: POST_SEARCH_V5_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      overlayFormat: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
    },
    runs,
    overlay,
  };
  gatePostSearchV5CatalogCapacity(manifest);
  return manifest;
}

async function validateRunInputs(
  store: Store,
  values: readonly PostSearchV5RunInput[],
  batchSize: number,
): Promise<Array<PostSearchV5RunDescriptor & { root: CID }>> {
  if (!Array.isArray(values) || values.length > POST_SEARCH_V5_MAX_ACTIVE_RUNS) {
    throw new Error('Invalid post-search v5 catalog runs');
  }
  const runs = values.map((candidate, index) => ({
    ...parseRunDescriptor({
      ...candidate,
      entry: runEntry(
        candidate.level,
        candidate.oldestBatch,
        candidate.newestBatchExclusive,
      ),
    }, index),
    root: candidate.root,
  })).sort(compareRunRanges);
  assertRunLayout(runs, batchSize);
  for (const run of runs) {
    const verified = await readPostSearchV5Run(store, run.root);
    const countsMatch = verified.manifest.documentCount === run.documentCount
      && verified.manifest.postingCount === run.postingCount
      && verified.manifest.termCount === run.termCount
      && verified.manifest.pages.total === run.pageCount
      && verified.manifest.reachableNodeCount === run.reachableNodeCount;
    if (!countsMatch) {
      throw new Error(`Post-search v5 catalog run descriptor is unverified: ${run.entry}`);
    }
  }
  return runs;
}

function parseRunDescriptor(value: unknown, index: number): PostSearchV5RunDescriptor {
  if (!isObject(value)) {
    throw new Error(`Invalid post-search v5 run descriptor at ${index}`);
  }
  const level = boundedLevel(value.level);
  const oldestBatch = nonNegativeInteger(value.oldestBatch, 'run oldestBatch');
  const newestBatchExclusive = positiveInteger(
    value.newestBatchExclusive,
    'run newestBatchExclusive',
  );
  if (newestBatchExclusive !== oldestBatch + 2 ** level
    || oldestBatch % (2 ** level) !== 0) {
    throw new Error('Post-search v5 run has a non-canonical source batch range');
  }
  if (value.entry !== runEntry(level, oldestBatch, newestBatchExclusive)) {
    throw new Error(`Invalid post-search v5 run entry at ${index}`);
  }
  const documentCount = positiveInteger(value.documentCount, 'run documentCount');
  const postingCount = nonNegativeInteger(value.postingCount, 'run postingCount');
  const termCount = nonNegativeInteger(value.termCount, 'run termCount');
  const pageCount = positiveInteger(value.pageCount, 'run pageCount');
  const reachableNodeCount = positiveInteger(
    value.reachableNodeCount,
    'run reachableNodeCount',
  );
  if (reachableNodeCount <= pageCount) {
    throw new Error('Post-search v5 run reachableNodeCount must include its root and pages');
  }
  const since = nullableTimestamp(value.since, 'run since');
  const until = nullableTimestamp(value.until, 'run until');
  if (since === null || until === null || since > until) {
    throw new Error('Post-search v5 run has an invalid time range');
  }
  return {
    entry: runEntry(level, oldestBatch, newestBatchExclusive),
    level,
    oldestBatch,
    newestBatchExclusive,
    documentCount,
    postingCount,
    termCount,
    pageCount,
    reachableNodeCount,
    kinds: kinds(value.kinds),
    since,
    until,
  };
}

async function validateOverlayInput(
  store: Store,
  value: PostSearchV5OverlayInput | null,
): Promise<(PostSearchV5OverlayDescriptor & { root: CID }) | null> {
  if (value === null) {
    return null;
  }
  const descriptor = parseOverlayDescriptor({ ...value, entry: OVERLAY_ENTRY });
  await readPostSearchV5VisibilityOverlay(store, value.root, {
    exactTombstoneCount: descriptor.exactTombstoneCount,
    coordinateStateCount: descriptor.coordinateStateCount,
    addressWinnerCount: descriptor.addressWinnerCount,
    addressDeletionCount: descriptor.addressDeletionCount,
    pageCount: descriptor.pageCount,
    reachableNodeCount: descriptor.reachableNodeCount,
  });
  return { ...descriptor, root: value.root };
}

function parseOverlayDescriptor(value: unknown): PostSearchV5OverlayDescriptor {
  if (!isObject(value) || value.entry !== OVERLAY_ENTRY) {
    throw new Error('Invalid post-search v5 visibility overlay descriptor');
  }
  const pageCount = positiveInteger(value.pageCount, 'overlay pageCount');
  const reachableNodeCount = positiveInteger(
    value.reachableNodeCount,
    'overlay reachableNodeCount',
  );
  if (reachableNodeCount <= pageCount) {
    throw new Error('Post-search v5 overlay reachableNodeCount must include its root and pages');
  }
  const exactTombstoneCount = nonNegativeInteger(
    value.exactTombstoneCount,
    'overlay exactTombstoneCount',
  );
  const coordinateStateCount = nonNegativeInteger(
    value.coordinateStateCount,
    'overlay coordinateStateCount',
  );
  const addressWinnerCount = nonNegativeInteger(
    value.addressWinnerCount,
    'overlay addressWinnerCount',
  );
  const addressDeletionCount = nonNegativeInteger(
    value.addressDeletionCount,
    'overlay addressDeletionCount',
  );
  if (
    addressWinnerCount > coordinateStateCount
    || addressDeletionCount > coordinateStateCount
  ) {
    throw new Error('Post-search v5 overlay address counts exceed coordinate state count');
  }
  return {
    entry: OVERLAY_ENTRY,
    exactTombstoneCount,
    coordinateStateCount,
    addressWinnerCount,
    addressDeletionCount,
    pageCount,
    reachableNodeCount,
  };
}

function sourceSnapshot(
  value: unknown,
  runs: readonly PostSearchV5RunDescriptor[],
): PostSearchV5SourceSnapshot {
  if (!isObject(value) || value.projection !== POST_SEARCH_VISIBLE_PROJECTION) {
    throw new Error('Invalid post-search v5 source snapshot');
  }
  const eventRoot = canonicalNhash(value.eventRoot);
  const expected = coverageForRuns(runs);
  const coverage = coverageValue(value.coverage);
  if (JSON.stringify(coverage) !== JSON.stringify(expected)) {
    throw new Error('Post-search v5 source coverage does not match its active runs');
  }
  return { eventRoot, projection: POST_SEARCH_VISIBLE_PROJECTION, coverage };
}

function coverageForRuns(runs: readonly PostSearchV5RunDescriptor[]): PostSearchV5Coverage {
  if (runs.length === 0) {
    return { eventCount: 0, kinds: [], since: null, until: null };
  }
  return {
    eventCount: runs.reduce((sum, candidate) => safeAdd(sum, candidate.documentCount), 0),
    kinds: [...new Set(runs.flatMap((candidate) => candidate.kinds))]
      .sort((left, right) => left - right),
    since: Math.min(...runs.map((candidate) => candidate.since as number)),
    until: Math.max(...runs.map((candidate) => candidate.until as number)),
  };
}

function coverageValue(value: unknown): PostSearchV5Coverage {
  if (!isObject(value)) {
    throw new Error('Invalid post-search v5 source coverage');
  }
  const eventCount = nonNegativeInteger(value.eventCount, 'source coverage eventCount');
  const parsedKinds = kinds(value.kinds);
  const since = nullableTimestamp(value.since, 'source coverage since');
  const until = nullableTimestamp(value.until, 'source coverage until');
  if ((eventCount === 0) !== (since === null && until === null && parsedKinds.length === 0)
    || (since !== null && until !== null && since > until)) {
    throw new Error('Invalid post-search v5 source coverage shape');
  }
  return { eventCount, kinds: parsedKinds, since, until };
}

function assertRunLayout(
  runs: readonly PostSearchV5RunDescriptor[],
  batchSize?: number,
): void {
  const countsByLevel = new Map<number, number>();
  let nextBatch = 0;
  for (const run of runs) {
    if (run.oldestBatch !== nextBatch) {
      throw new Error('Post-search v5 run source ranges contain an overlap or gap');
    }
    const countAtLevel = (countsByLevel.get(run.level) ?? 0) + 1;
    if (countAtLevel > POST_SEARCH_V5_MAX_RUNS_PER_LEVEL) {
      throw new Error(`Post-search v5 catalog has too many active runs at level ${run.level}`);
    }
    if (batchSize !== undefined) {
      const capacity = batchSize * (run.newestBatchExclusive - run.oldestBatch);
      if (!Number.isSafeInteger(capacity) || run.documentCount > capacity) {
        throw new Error('Post-search v5 run exceeds its source batch document capacity');
      }
    }
    countsByLevel.set(run.level, countAtLevel);
    nextBatch = run.newestBatchExclusive;
  }
}

function runEntry(level: number, oldestBatch: number, newestBatchExclusive: number): string {
  return `run-${boundedLevel(level).toString().padStart(2, '0')}`
    + `-${oldestBatch}-${newestBatchExclusive}`;
}

function boundedLevel(value: unknown): number {
  const level = nonNegativeInteger(value, 'run level');
  if (level > POST_SEARCH_V5_MAX_LEVEL) {
    throw new Error(`Post-search v5 run level exceeds ${POST_SEARCH_V5_MAX_LEVEL}`);
  }
  return level;
}

function publisher(value: unknown): string {
  if (typeof value !== 'string' || !value.trim() || value.length > 256) {
    throw new Error('Invalid post-search v5 publisher id');
  }
  return value.trim();
}

function kinds(value: unknown): number[] {
  if (!Array.isArray(value)
    || !value.every((kind) => Number.isInteger(kind) && SUPPORTED_KINDS.has(kind as number))) {
    throw new Error('Invalid post-search v5 kinds');
  }
  return [...new Set(value as number[])].sort((left, right) => left - right);
}

function canonicalNhash(value: unknown): string {
  if (typeof value !== 'string') {
    throw new Error('Invalid post-search v5 source event root');
  }
  try {
    const decoded = nhashDecode(value);
    if (nhashEncode(decoded) !== value) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error('Invalid post-search v5 source event root');
  }
}

function nullableTimestamp(value: unknown, name: string): number | null {
  return value === null ? null : nonNegativeInteger(value, name);
}

function positiveInteger(value: unknown, name: string): number {
  const result = nonNegativeInteger(value, name);
  if (result === 0) {
    throw new Error(`Invalid ${name}`);
  }
  return result;
}

function nonNegativeInteger(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}

function safeAdd(left: number, right: number): number {
  const sum = left + right;
  if (!Number.isSafeInteger(sum) || sum < 0) {
    throw new Error('Post-search v5 count exceeds the safe integer range');
  }
  return sum;
}

function compareRunRanges(left: PostSearchV5RunDescriptor, right: PostSearchV5RunDescriptor): number {
  return left.oldestBatch - right.oldestBatch;
}

function decodeUtf8(bytes: Uint8Array): string {
  try {
    return decoder.decode(bytes);
  } catch {
    throw new Error('Post-search v5 catalog manifest is not valid UTF-8');
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
