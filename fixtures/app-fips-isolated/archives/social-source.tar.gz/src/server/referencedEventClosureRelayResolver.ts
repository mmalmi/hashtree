import { createHash, randomBytes } from 'node:crypto';
import WebSocket, { type RawData } from 'ws';
import type { RawEvent } from '../lib/nostr';
import { closureSha256 } from './referencedEventClosureState';
import { verifyClosureEvent } from './referencedEventClosureReferences';
import type {
  ReferencedEventClosureReference,
  ReferencedEventClosureResolver,
} from './referencedEventClosureTypes';

export const REFERENCED_EVENT_CLOSURE_RELAY_POLICY_FORMAT =
  'iris-social/referenced-event-closure-relay-policy@1' as const;

const HEX_64 = /^[0-9a-f]{64}$/;

export type ReferencedEventClosureRelayPolicy = {
  format: typeof REFERENCED_EVENT_CLOSURE_RELAY_POLICY_FORMAT;
  relays: string[];
  idBatchSize: number;
  maxFiltersPerRequest: number;
  maxConcurrentRequests: number;
  requestTimeoutMs: number;
  batchTimeoutMs: number;
  maxCandidates: number;
  maxEventBytes: number;
};

export type ReferencedEventClosureRelayPolicyInput = Omit<
  ReferencedEventClosureRelayPolicy,
  'format'
>;

export type ReferencedEventClosureRelayFilter = {
  ids?: string[];
  kinds?: number[];
  authors?: string[];
  since?: number;
  until?: number;
  '#d'?: string[];
  limit?: number;
};

export type ReferencedEventClosureRelayRequest = {
  filters: ReferencedEventClosureRelayFilter[];
  requiredIds: string[];
};

export type RelayQueryOptions = {
  signal: AbortSignal;
  timeoutMs: number;
  maxEventBytes: number;
  onEvent(event: RawEvent): void;
};

export interface ReferencedEventClosureRelayQueryClient {
  /** Resolves only after the relay sends EOSE for this open subscription. */
  query(
    relay: string,
    filters: readonly ReferencedEventClosureRelayFilter[],
    options: RelayQueryOptions,
  ): Promise<void>;
  close(): Promise<void>;
}

export class RetryableRelayResolutionError extends Error {
  readonly retryable = true;

  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'RetryableRelayResolutionError';
  }
}

export class RelayResolutionLimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RelayResolutionLimitError';
  }
}

export function createReferencedEventClosureRelayPolicy(
  input: ReferencedEventClosureRelayPolicyInput,
): ReferencedEventClosureRelayPolicy {
  const relays = input.relays.map(normalizeRelayUrl).sort();
  if (relays.length === 0 || new Set(relays).size !== relays.length) {
    throw new Error('Referenced-event closure requires a non-empty unique relay set');
  }
  const policy: ReferencedEventClosureRelayPolicy = {
    format: REFERENCED_EVENT_CLOSURE_RELAY_POLICY_FORMAT,
    relays,
    idBatchSize: positiveInteger(input.idBatchSize, 'id batch size', 1_000),
    maxFiltersPerRequest: positiveInteger(
      input.maxFiltersPerRequest,
      'filters per request',
      256,
    ),
    maxConcurrentRequests: positiveInteger(
      input.maxConcurrentRequests,
      'concurrent requests',
      256,
    ),
    requestTimeoutMs: positiveInteger(input.requestTimeoutMs, 'request timeout', 600_000),
    batchTimeoutMs: positiveInteger(input.batchTimeoutMs, 'batch timeout', 3_600_000),
    maxCandidates: positiveInteger(input.maxCandidates, 'candidate limit', 1_000_000),
    maxEventBytes: positiveInteger(input.maxEventBytes, 'event byte limit', 16 * 1024 * 1024),
  };
  if (policy.batchTimeoutMs < policy.requestTimeoutMs) {
    throw new Error('Referenced-event closure batch timeout must cover one request timeout');
  }
  return policy;
}

export function hashReferencedEventClosureRelayPolicy(
  policy: ReferencedEventClosureRelayPolicy,
): string {
  return closureSha256(JSON.stringify(policy));
}

export function planReferencedEventClosureRelayRequests(
  references: readonly ReferencedEventClosureReference[],
  policy: Pick<ReferencedEventClosureRelayPolicy, 'idBatchSize' | 'maxFiltersPerRequest'>,
): ReferencedEventClosureRelayRequest[] {
  const filters: ReferencedEventClosureRelayFilter[] = [];
  const ids = [...new Set(
    references.filter(({ type }) => type === 'id').map(({ value }) => value),
  )];
  for (let offset = 0; offset < ids.length; offset += policy.idBatchSize) {
    const batch = ids.slice(offset, offset + policy.idBatchSize);
    filters.push({ ids: batch, limit: batch.length });
  }
  for (const reference of references) {
    if (reference.type !== 'coordinate') {
      continue;
    }
    const coordinate = parseAddressCoordinate(reference.value);
    filters.push({
      kinds: [coordinate.kind],
      authors: [coordinate.pubkey],
      '#d': [coordinate.identifier],
      limit: 1,
    });
  }
  const idFilterCount = Math.ceil(ids.length / policy.idBatchSize);
  const requests: ReferencedEventClosureRelayRequest[] = [];
  for (let offset = 0; offset < idFilterCount; offset += policy.maxFiltersPerRequest) {
    const requestFilters = filters.slice(offset, offset + policy.maxFiltersPerRequest);
    requests.push({
      filters: requestFilters,
      requiredIds: requestFilters.flatMap((filter) => filter.ids ?? []),
    });
  }
  for (
    let offset = idFilterCount;
    offset < filters.length;
    offset += policy.maxFiltersPerRequest
  ) {
    requests.push({
      filters: filters.slice(offset, offset + policy.maxFiltersPerRequest),
      requiredIds: [],
    });
  }
  return requests;
}

export class NostrRelayReferencedEventClosureResolver
implements ReferencedEventClosureResolver {
  readonly configurationSha256: string;
  private readonly client: ReferencedEventClosureRelayQueryClient;

  constructor(
    readonly policy: ReferencedEventClosureRelayPolicy,
    client?: ReferencedEventClosureRelayQueryClient,
  ) {
    this.configurationSha256 = hashReferencedEventClosureRelayPolicy(policy);
    this.client = client ?? new WebSocketRelayQueryClient(policy.maxEventBytes);
  }

  async resolve(references: readonly ReferencedEventClosureReference[]): Promise<RawEvent[]> {
    const requests = planReferencedEventClosureRelayRequests(references, this.policy);
    const states = requests.map((request) => ({
      ...request,
      foundIds: new Set<string>(),
      controller: new AbortController(),
      satisfied: false,
    }));
    const tasks = states.flatMap((state) => (
      this.policy.relays.map((relay) => ({ relay, state }))
    ));
    const candidates = new Map<string, RawEvent>();
    const controller = new AbortController();
    let firstError: unknown;
    const fail = (error: unknown): void => {
      if (firstError === undefined) {
        firstError = error;
        controller.abort(error);
      }
    };
    const timer = setTimeout(() => fail(new RetryableRelayResolutionError(
      `Relay resolution batch timed out after ${this.policy.batchTimeoutMs}ms`,
    )), this.policy.batchTimeoutMs);
    let cursor = 0;
    const worker = async (): Promise<void> => {
      while (!controller.signal.aborted) {
        const index = cursor;
        cursor += 1;
        const task = tasks[index];
        if (!task) {
          return;
        }
        if (task.state.satisfied) {
          continue;
        }
        try {
          await this.client.query(task.relay, task.state.filters, {
            signal: AbortSignal.any([controller.signal, task.state.controller.signal]),
            timeoutMs: this.policy.requestTimeoutMs,
            maxEventBytes: this.policy.maxEventBytes,
            onEvent: (event) => {
              addCandidate(candidates, event, this.policy.maxCandidates);
              retainVerifiedIdMatch(task.state, event);
            },
          });
        } catch (error) {
          if (!(error instanceof SatisfiedIdRequestError)) {
            fail(error);
          }
        }
      }
    };
    try {
      await Promise.all(Array.from(
        { length: Math.min(tasks.length, this.policy.maxConcurrentRequests) },
        worker,
      ));
    } finally {
      clearTimeout(timer);
    }
    if (firstError !== undefined) {
      if (firstError instanceof RelayResolutionLimitError) {
        throw firstError;
      }
      if (firstError instanceof RetryableRelayResolutionError) {
        throw firstError;
      }
      throw new RetryableRelayResolutionError(
        'A relay failed before every open subscription reached EOSE',
        { cause: firstError },
      );
    }
    return [...candidates.values()];
  }

  async close(): Promise<void> {
    await this.client.close();
  }
}

type RelayRequestState = ReferencedEventClosureRelayRequest & {
  foundIds: Set<string>;
  controller: AbortController;
  satisfied: boolean;
};

class SatisfiedIdRequestError extends Error {
  constructor() {
    super('Every immutable ID in this relay request has a verified exact match');
    this.name = 'SatisfiedIdRequestError';
  }
}

function retainVerifiedIdMatch(state: RelayRequestState, event: RawEvent): void {
  if (state.requiredIds.length === 0 || !state.requiredIds.includes(event.id)
    || !verifyClosureEvent(event)) {
    return;
  }
  state.foundIds.add(event.id);
  if (state.foundIds.size === state.requiredIds.length) {
    state.satisfied = true;
    state.controller.abort(new SatisfiedIdRequestError());
  }
}

/** Persistent relay connections with multiplexed NIP-01 subscriptions. */
export class WebSocketRelayQueryClient implements ReferencedEventClosureRelayQueryClient {
  private readonly connections = new Map<string, RelayConnection>();

  constructor(private readonly maxEventBytes: number) {}

  async query(
    relay: string,
    filters: readonly ReferencedEventClosureRelayFilter[],
    options: RelayQueryOptions,
  ): Promise<void> {
    let connection = this.connections.get(relay);
    if (!connection) {
      connection = new RelayConnection(relay, this.maxEventBytes);
      this.connections.set(relay, connection);
    }
    await connection.query(filters, options);
  }

  async close(): Promise<void> {
    await Promise.all([...this.connections.values()].map(async (connection) => {
      await connection.close();
    }));
    this.connections.clear();
  }
}

type ActiveSubscription = {
  onEvent(event: RawEvent): void;
  resolve(): void;
  reject(error: Error): void;
  timer: ReturnType<typeof setTimeout>;
  signal: AbortSignal;
  abort(): void;
  maxEventBytes: number;
};

class RelayConnection {
  private socket?: WebSocket;
  private connecting?: Promise<WebSocket>;
  private readonly active = new Map<string, ActiveSubscription>();
  private closing = false;

  constructor(private readonly relay: string, private readonly maxPayload: number) {}

  async query(
    filters: readonly ReferencedEventClosureRelayFilter[],
    options: RelayQueryOptions,
  ): Promise<void> {
    if (filters.length === 0) {
      return;
    }
    const socket = await this.connectedSocket(options.signal);
    const subscriptionId = `closure-${randomBytes(12).toString('hex')}`;
    await new Promise<void>((resolve, reject) => {
      const abort = (): void => finish(abortReason(options.signal));
      const timer = setTimeout(() => finish(new RetryableRelayResolutionError(
        `Relay ${this.relay} did not send EOSE within ${options.timeoutMs}ms`,
      )), options.timeoutMs);
      const finish = (error?: Error): void => {
        const active = this.active.get(subscriptionId);
        if (!active) {
          return;
        }
        this.active.delete(subscriptionId);
        clearTimeout(active.timer);
        active.signal.removeEventListener('abort', active.abort);
        this.sendClose(subscriptionId);
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      };
      this.active.set(subscriptionId, {
        onEvent: options.onEvent,
        resolve: () => finish(),
        reject: (error) => finish(error),
        timer,
        signal: options.signal,
        abort,
        maxEventBytes: options.maxEventBytes,
      });
      options.signal.addEventListener('abort', abort, { once: true });
      try {
        socket.send(JSON.stringify(['REQ', subscriptionId, ...filters]));
      } catch (error) {
        finish(retryableRelayError(this.relay, 'could not send REQ', error));
      }
    });
  }

  async close(): Promise<void> {
    this.closing = true;
    this.failActive(new RetryableRelayResolutionError(`Relay ${this.relay} client closed`));
    const socket = this.socket;
    this.socket = undefined;
    this.connecting = undefined;
    if (socket && socket.readyState < WebSocket.CLOSING) {
      socket.close(1000);
    }
  }

  private async connectedSocket(signal: AbortSignal): Promise<WebSocket> {
    if (signal.aborted) {
      throw abortReason(signal);
    }
    if (this.socket?.readyState === WebSocket.OPEN) {
      return this.socket;
    }
    if (!this.connecting) {
      this.connecting = this.connect();
    }
    return await raceAbort(this.connecting, signal);
  }

  private async connect(): Promise<WebSocket> {
    this.closing = false;
    const socket = new WebSocket(this.relay, { maxPayload: this.maxPayload + 4_096 });
    this.socket = socket;
    socket.on('message', (data) => this.handleMessage(data));
    socket.on('close', () => this.handleDisconnect('closed'));
    socket.on('error', (error) => this.handleDisconnect('failed', error));
    try {
      await new Promise<void>((resolve, reject) => {
        const open = (): void => {
          cleanup();
          resolve();
        };
        const error = (cause: Error): void => {
          cleanup();
          reject(retryableRelayError(this.relay, 'connection failed', cause));
        };
        const close = (): void => {
          cleanup();
          reject(new RetryableRelayResolutionError(
            `Relay ${this.relay} closed before connection`,
          ));
        };
        const cleanup = (): void => {
          socket.off('open', open);
          socket.off('error', error);
          socket.off('close', close);
        };
        socket.once('open', open);
        socket.once('error', error);
        socket.once('close', close);
      });
      return socket;
    } finally {
      this.connecting = undefined;
    }
  }

  private handleMessage(data: RawData): void {
    let message: unknown;
    try {
      message = JSON.parse(rawDataText(data));
    } catch (error) {
      this.handleDisconnect('sent invalid JSON', error);
      return;
    }
    if (!Array.isArray(message) || typeof message[0] !== 'string') {
      return;
    }
    const subscriptionId = typeof message[1] === 'string' ? message[1] : '';
    const subscription = this.active.get(subscriptionId);
    if (!subscription) {
      return;
    }
    if (message[0] === 'EOSE') {
      subscription.resolve();
      return;
    }
    if (message[0] === 'CLOSED') {
      subscription.reject(new RetryableRelayResolutionError(
        `Relay ${this.relay} closed subscription before EOSE`,
      ));
      return;
    }
    if (message[0] !== 'EVENT') {
      return;
    }
    const event = message[2];
    const eventBytes = Buffer.byteLength(JSON.stringify(event));
    if (eventBytes > subscription.maxEventBytes || !isRawEventShape(event)) {
      subscription.reject(new RetryableRelayResolutionError(
        `Relay ${this.relay} sent an invalid or oversized event candidate`,
      ));
      return;
    }
    try {
      subscription.onEvent(event);
    } catch (error) {
      subscription.reject(error instanceof Error ? error : new Error(String(error)));
    }
  }

  private handleDisconnect(action: string, cause?: unknown): void {
    if (this.socket?.readyState !== WebSocket.OPEN) {
      this.socket = undefined;
    }
    if (!this.closing) {
      this.failActive(retryableRelayError(this.relay, action, cause));
    }
  }

  private failActive(error: Error): void {
    for (const subscription of [...this.active.values()]) {
      subscription.reject(error);
    }
  }

  private sendClose(subscriptionId: string): void {
    if (this.socket?.readyState !== WebSocket.OPEN) {
      return;
    }
    try {
      this.socket.send(JSON.stringify(['CLOSE', subscriptionId]));
    } catch {
      // The completed query has already made its EOSE/failure decision.
    }
  }
}

function addCandidate(candidates: Map<string, RawEvent>, event: RawEvent, maximum: number): void {
  const serialized = JSON.stringify(event);
  const key = createHash('sha256').update(serialized).digest('hex');
  if (candidates.has(key)) {
    return;
  }
  if (candidates.size >= maximum) {
    throw new RelayResolutionLimitError('Referenced-event closure relay candidate limit exceeded');
  }
  candidates.set(key, event);
}

function parseAddressCoordinate(value: string): {
  kind: number;
  pubkey: string;
  identifier: string;
} {
  const first = value.indexOf(':');
  const second = value.indexOf(':', first + 1);
  const kind = Number(value.slice(0, first));
  const pubkey = value.slice(first + 1, second);
  const identifier = value.slice(second + 1);
  if (first <= 0 || second <= first + 1 || !Number.isSafeInteger(kind)
    || kind < 30_000 || kind >= 40_000 || !HEX_64.test(pubkey)) {
    throw new Error('Invalid referenced-event closure address coordinate');
  }
  return { kind, pubkey, identifier };
}

function normalizeRelayUrl(value: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error('Referenced-event closure relay must be a WebSocket URL');
  }
  if (!['ws:', 'wss:'].includes(url.protocol) || url.username || url.password
    || url.search || url.hash) {
    throw new Error('Referenced-event closure relay must be an uncredentialed WebSocket URL');
  }
  return url.toString().replace(/\/$/, '');
}

function positiveInteger(value: number, name: string, maximum: number): number {
  if (!Number.isSafeInteger(value) || value <= 0 || value > maximum) {
    throw new Error(`Referenced-event closure ${name} must be from 1 through ${maximum}`);
  }
  return value;
}

function isRawEventShape(value: unknown): value is RawEvent {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function rawDataText(data: RawData): string {
  if (typeof data === 'string') {
    return data;
  }
  if (Array.isArray(data)) {
    return Buffer.concat(data).toString('utf8');
  }
  return Buffer.isBuffer(data)
    ? data.toString('utf8')
    : Buffer.from(new Uint8Array(data)).toString('utf8');
}

function retryableRelayError(relay: string, action: string, cause?: unknown): Error {
  return new RetryableRelayResolutionError(`Relay ${relay} ${action}`, {
    cause: cause instanceof Error ? cause : undefined,
  });
}

function abortReason(signal: AbortSignal): Error {
  return signal.reason instanceof Error
    ? signal.reason
    : new RetryableRelayResolutionError('Relay resolution was aborted');
}

async function raceAbort<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) {
    throw abortReason(signal);
  }
  return await new Promise<T>((resolve, reject) => {
    const abort = (): void => reject(abortReason(signal));
    signal.addEventListener('abort', abort, { once: true });
    void promise.then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
  });
}
