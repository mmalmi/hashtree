import { CollectionSource } from '@hashtree/collection';
import { HashTree, nhashEncode, toHex, type CID, type Hash, type Store } from '@hashtree/core';
import {
  MANIFEST_BY_KIND_TIME,
  MANIFEST_PARAMETERIZED_REPLACEABLE,
  MANIFEST_REPLACEABLE,
  NostrEventStore,
  decodeStoredNostrEventMsgpack,
  replaceableKey,
} from '@hashtree/nostr';
import type { RawEvent } from '../lib/nostr';
import {
  isAddressableEventKind,
  isReplaceableEventKind,
} from '../lib/socialRepository';
import type {
  PostSearchKindStreamOptions,
  PostSearchSnapshotReader,
} from './postSearchProjection';

const DEFAULT_SNAPSHOT_READ_BATCH = 16;
// Remote point traversals multiply immutable B-tree latency. Larger batches use
// a bounded request-local cache so concurrent exact lookups coalesce reads of
// shared immutable B-tree ancestors without scanning unrelated archive rows.
const REPLACEABLE_SHARED_TRAVERSAL_MIN_KEYS = 32;
const REPLACEABLE_SHARED_TRAVERSAL_CACHE_BLOCKS = 256;
const MAX_U64 = (1n << 64n) - 1n;
const HEX_64 = /^[0-9a-f]{64}$/;

export class HashtreeNostrSnapshotReader implements PostSearchSnapshotReader {
  private readonly store: Store;
  private readonly events: NostrEventStore;
  private readonly tree: HashTree;
  private readonly readBatchSize: number;
  private collectionSource: {
    root: string;
    value: ReturnType<NostrEventStore['getCollectionSource']>;
  } | null = null;

  constructor(store: Store, readBatchSize = DEFAULT_SNAPSHOT_READ_BATCH) {
    this.store = store;
    this.events = new NostrEventStore(store);
    this.tree = new HashTree({ store });
    if (!Number.isSafeInteger(readBatchSize) || readBatchSize <= 0) {
      throw new Error('Invalid post search snapshot read batch');
    }
    this.readBatchSize = readBatchSize;
  }

  async validateSnapshot(root: CID): Promise<void> {
    const manifest = await this.events.getManifest(root);
    if (!manifest.byId || !manifest.byKindTime || !manifest.replaceable) {
      throw new Error('Hashtree Nostr snapshot is missing by-id, by-kind-time, or replaceable indexes');
    }
  }

  async validateArchiveSnapshot(root: CID): Promise<void> {
    const manifest = await this.events.getManifest(root);
    if (Object.values(manifest).some((index) => index === null)) {
      throw new Error('Hashtree Nostr archive is missing an app-required event index');
    }
  }

  async getReplaceable(root: CID, pubkey: string, kind: number): Promise<RawEvent | null> {
    return await this.events.getReplaceable(root, pubkey, kind) as RawEvent | null;
  }

  async getParameterizedReplaceable(
    root: CID,
    pubkey: string,
    kind: number,
    dTag: string,
  ): Promise<RawEvent | null> {
    return await this.events.getParameterizedReplaceable(root, pubkey, kind, dTag) as RawEvent | null;
  }

  async getReplaceables(
    root: CID,
    pubkeys: readonly string[],
    kind: number,
  ): Promise<ReadonlyMap<string, RawEvent | null>> {
    const uniquePubkeys = [...new Set(pubkeys)];
    if (!Number.isInteger(kind) || kind < 0) {
      throw new Error('kind must be a non-negative integer');
    }
    for (const pubkey of uniquePubkeys) {
      if (!HEX_64.test(pubkey)) {
        throw new Error('pubkey must be a lowercase 64-character hex string');
      }
    }
    const results = new Map<string, RawEvent | null>(
      uniquePubkeys.map((pubkey) => [pubkey, null]),
    );
    if (uniquePubkeys.length === 0) {
      return results;
    }
    const source = await this.getCollectionSource(root);
    const useSharedTraversal = uniquePubkeys.length >= REPLACEABLE_SHARED_TRAVERSAL_MIN_KEYS;
    const lookupSource = useSharedTraversal
      ? new CollectionSource(
        createCoalescingReadStore(
          this.store,
          REPLACEABLE_SHARED_TRAVERSAL_CACHE_BLOCKS,
        ),
        source.manifest,
      )
      : source;
    const lookupPubkeys = useSharedTraversal ? [...uniquePubkeys].sort() : uniquePubkeys;
    const matches: Array<{ pubkey: string; cid: CID }> = [];
    let lookupCursor = 0;
    const lookup = async (): Promise<void> => {
      while (lookupCursor < lookupPubkeys.length) {
        const pubkey = lookupPubkeys[lookupCursor++];
        const cid = await lookupSource.getIndexLink(
          MANIFEST_REPLACEABLE,
          replaceableKey(pubkey, kind),
        );
        if (cid) {
          matches.push({ pubkey, cid });
        }
      }
    };
    await Promise.all(Array.from(
      { length: Math.min(this.readBatchSize, lookupPubkeys.length) },
      lookup,
    ));

    let readCursor = 0;
    const read = async (): Promise<void> => {
      while (readCursor < matches.length) {
        const { pubkey, cid } = matches[readCursor++];
        const data = await this.tree.readFile(cid);
        if (!data) {
          throw new Error('Stored Nostr event blob is missing');
        }
        results.set(pubkey, decodeStoredNostrEventMsgpack(data) as RawEvent);
      }
    };
    await Promise.all(Array.from(
      { length: Math.min(this.readBatchSize, matches.length) },
      read,
    ));
    return results;
  }

  async *streamKind(
    root: CID,
    kind: number,
    options: PostSearchKindStreamOptions = {},
  ): AsyncIterable<RawEvent> {
    const source = await this.getCollectionSource(root);
    const afterKey = options.after ? kindCursorKey(kind, options.after) : null;
    let batch: CID[] = [];
    const readBatch = async (): Promise<RawEvent[]> => {
      const result = await Promise.all(batch.map(async (cid) => {
        const data = await this.tree.readFile(cid);
        if (!data) {
          throw new Error('Post-search snapshot event blob is missing');
        }
        return decodeStoredNostrEventMsgpack(data) as RawEvent;
      }));
      batch = [];
      return result;
    };

    for await (const { key, cid } of source.streamQueryIndex(MANIFEST_BY_KIND_TIME, {
      prefix: `${kind.toString(16).padStart(8, '0')}:`,
    })) {
      if (afterKey && key <= afterKey) {
        continue;
      }
      batch.push(cid);
      if (batch.length < this.readBatchSize) {
        continue;
      }
      for (const event of await readBatch()) {
        yield event;
      }
    }
    for (const event of await readBatch()) {
      yield event;
    }
  }

  /**
   * Stream one kind's replaceable/addressable winners in stable coordinate order.
   * This reads the immutable current-state indexes directly so archive gates can
   * accept a newer winner without pretending the superseded event still exists.
   */
  async *streamCurrentState(
    root: CID,
    kind: number,
  ): AsyncIterable<{ coordinate: string; event: RawEvent }> {
    const replaceable = isReplaceableEventKind(kind);
    const addressable = isAddressableEventKind(kind);
    if (!replaceable && !addressable) {
      throw new Error(`Kind ${kind} does not have a current-state coordinate`);
    }
    const source = await this.getCollectionSource(root);
    const indexName = replaceable ? MANIFEST_REPLACEABLE : MANIFEST_PARAMETERIZED_REPLACEABLE;
    const kindHex = kind.toString(16).padStart(8, '0');
    let batch: Array<{ coordinate: string; cid: CID }> = [];
    const readBatch = async (): Promise<Array<{ coordinate: string; event: RawEvent }>> => {
      const result = await Promise.all(batch.map(async ({ coordinate, cid }) => {
        const data = await this.tree.readFile(cid);
        if (!data) {
          throw new Error('Nostr current-state event blob is missing');
        }
        return { coordinate, event: decodeStoredNostrEventMsgpack(data) as RawEvent };
      }));
      batch = [];
      return result;
    };

    for await (const { key, cid } of source.streamQueryIndex(indexName, { prefix: '' })) {
      const firstSeparator = key.indexOf(':');
      const secondSeparator = key.indexOf(':', firstSeparator + 1);
      const indexedKind = secondSeparator < 0
        ? key.slice(firstSeparator + 1)
        : key.slice(firstSeparator + 1, secondSeparator);
      if (indexedKind !== kindHex) {
        continue;
      }
      const pubkey = key.slice(0, firstSeparator);
      if (!HEX_64.test(pubkey)
        || firstSeparator !== 64
        || (replaceable && secondSeparator >= 0)
        || (addressable && secondSeparator < 0)) {
        throw new Error(`Kind ${kind} current-state index has a malformed coordinate`);
      }
      const dTag = addressable ? key.slice(secondSeparator + 1) : '';
      batch.push({ coordinate: `${kind}:${pubkey}:${dTag}`, cid });
      if (batch.length < this.readBatchSize) {
        continue;
      }
      for (const entry of await readBatch()) {
        yield entry;
      }
    }
    for (const entry of await readBatch()) {
      yield entry;
    }
  }

  private getCollectionSource(root: CID): ReturnType<NostrEventStore['getCollectionSource']> {
    const encodedRoot = nhashEncode(root);
    if (!this.collectionSource || this.collectionSource.root !== encodedRoot) {
      this.collectionSource = {
        root: encodedRoot,
        value: this.events.getCollectionSource(root),
      };
    }
    return this.collectionSource.value;
  }
}

function createCoalescingReadStore(store: Store, maxBlocks: number): Store {
  const reads = new Map<string, Promise<Uint8Array | null>>();

  return {
    put: async (hash, data) => await store.put(hash, data),
    get: async (hash: Hash): Promise<Uint8Array | null> => {
      const key = toHex(hash);
      let pending = reads.get(key);
      if (pending) {
        reads.delete(key);
        reads.set(key, pending);
      } else {
        pending = store.get(hash).catch((error: unknown) => {
          if (reads.get(key) === pending) {
            reads.delete(key);
          }
          throw error;
        });
        reads.set(key, pending);
        while (reads.size > maxBlocks) {
          const oldest = reads.keys().next().value;
          if (oldest === undefined) {
            break;
          }
          reads.delete(oldest);
        }
      }
      const data = await pending;
      return data ? new Uint8Array(data) : null;
    },
    has: async (hash) => await store.has(hash),
    delete: async (hash) => await store.delete(hash),
    ...(store.watch ? {
      watch: (hash: Hash, callback: (data: Uint8Array) => void) => (
        store.watch!(hash, callback)
      ),
    } : {}),
  };
}

function kindCursorKey(
  kind: number,
  cursor: NonNullable<PostSearchKindStreamOptions['after']>,
): string {
  if (!Number.isSafeInteger(cursor.createdAt)
    || cursor.createdAt < 0
    || !HEX_64.test(cursor.eventId)) {
    throw new Error('Invalid post search kind cursor');
  }
  const timestamp = (MAX_U64 - BigInt(cursor.createdAt)).toString(16).padStart(16, '0');
  return `${kind.toString(16).padStart(8, '0')}:${timestamp}:${cursor.eventId}`;
}
