import type { CID } from '@hashtree/core';
import type { ProfileRecord, RawEvent } from '../lib/nostr';
import type { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import type { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';

export const PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT =
  'iris-social/routed-profile-search-run@3' as const;
export const PROFILE_SEARCH_V3_NORMALIZATION = 'NFKD-accent-folded-lowercase@1' as const;
export const PROFILE_SEARCH_V3_RANK_POLICY = 'lower-frozen-social-rank-first@1' as const;
export const PROFILE_SEARCH_V3_MAX_POSTINGS_PER_PROFILE = 512;
export const PROFILE_SEARCH_V3_MAX_QUERY_RESULTS = 100;
export const PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES = 1_024;
export const PROFILE_SEARCH_V3_MAX_REACHABLE_NODES = 9_000_000;

export type ProfileSearchV3PostingMode =
  | 'identifier'
  | 'nip05'
  | 'identity'
  | 'word'
  | 'prefix'
  | 'trigram';

export interface ProfileSearchV3Posting {
  mode: ProfileSearchV3PostingMode;
  term: string;
  rankHint: number;
  pubkey: string;
}

export interface ProfileSearchV3StoredProfile {
  event: RawEvent;
  profile: ProfileRecord;
  rankHint: number;
}

export interface ProfileSearchV3Hit extends ProfileSearchV3StoredProfile {
  textScore: number;
  matchedModes: ProfileSearchV3PostingMode[];
}

export interface ProfileSearchV3BranchManifest {
  pageKind: 'documents' | 'postings';
  entryCount: number;
  minKey: string;
  maxKey: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
}

export interface ProfileSearchV3RoutedRunManifest {
  format: typeof PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT;
  packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  pageRouterFormat: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
  normalization: typeof PROFILE_SEARCH_V3_NORMALIZATION;
  rankPolicy: typeof PROFILE_SEARCH_V3_RANK_POLICY;
  profileCount: number;
  postingCount: number;
  minimumRankHint: number;
  maximumRankHint: number;
  branches: {
    profiles: ProfileSearchV3BranchManifest;
    postings: ProfileSearchV3BranchManifest;
  };
  reachableNodeCount: number;
}

export interface ProfileSearchV3RoutedRunBuild {
  root: CID;
  manifest: ProfileSearchV3RoutedRunManifest;
}

export interface ProfileSearchV3RoutedRunExpected {
  profileCount?: number;
  postingCount?: number;
  pageCount?: number;
  reachableNodeCount?: number;
}

export interface ProfileSearchV3RoutedRunReadOptions {
  expected?: ProfileSearchV3RoutedRunExpected;
  maxReachableNodeCount?: number;
}

export interface ProfileSearchV3RoutedRunLookup extends ProfileSearchV3RoutedRunBuild {
  getProfile(pubkeyOrNpub: string): Promise<ProfileSearchV3StoredProfile | null>;
  search(query: string, limit?: number): Promise<ProfileSearchV3Hit[]>;
  streamProfiles(): AsyncGenerator<ProfileSearchV3StoredProfile>;
  streamPostings(): AsyncGenerator<ProfileSearchV3Posting>;
}

export interface ProfileSearchV3RoutedRunWriter {
  /** Returns false when the author is absent from the supplied eligible-rank snapshot. */
  appendProfile(event: RawEvent): Promise<boolean>;
  appendPosting(posting: ProfileSearchV3Posting): Promise<void>;
  finish(options?: { maxReachableNodeCount?: number }): Promise<ProfileSearchV3RoutedRunBuild>;
}

export interface ProfileSearchV3RunEnvelope extends ProfileSearchV3RoutedRunBuild {
  roots: { profiles: CID; postings: CID };
}
