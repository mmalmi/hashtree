import {
  POST_SEARCH_V5_MAX_FIELDS,
  parsePostSearchV5Posting,
  type PostSearchV5Posting,
  type PostSearchV5RecordManifest,
  type PostSearchV5StoredDocument,
  type PostSearchV5TermStats,
} from './postSearchV5Run';
import {
  POST_SEARCH_V5_POSTING_PART_WIDTH,
  type PostSearchV5CurrentTermBuild,
  type PostSearchV5RoutedRunManifest,
} from './postSearchV5RoutedRunTypes';
import {
  addPostSearchV5Routed,
  assertPostSearchV5RoutedCanonicalRaw,
  comparePostSearchV5RoutedText,
  isPostSearchV5RoutedRecord,
  postSearchV5RoutedNonEmptyString,
  postSearchV5RoutedNonNegativeInteger,
  postSearchV5RoutedPositiveInteger,
} from './postSearchV5RoutedRunValidation';

const POSTING_SEPARATOR = '\0';

export function postSearchV5PostingKey(term: string, part: number): string {
  const normalizedTerm = postSearchV5RoutedPostingTerm(term);
  postSearchV5RoutedNonNegativeInteger(part, 'posting part');
  const suffix = part.toString().padStart(POST_SEARCH_V5_POSTING_PART_WIDTH, '0');
  if (suffix.length !== POST_SEARCH_V5_POSTING_PART_WIDTH) {
    throw new Error('Post-search v5 posting part exceeds its fixed-width capacity');
  }
  return `${normalizedTerm}${POSTING_SEPARATOR}${suffix}`;
}

export function postSearchV5RoutedPostingTerm(value: unknown): string {
  const term = postSearchV5RoutedNonEmptyString(value, 'term');
  if (term.includes(POSTING_SEPARATOR)) {
    throw new Error('Invalid post-search v5 routed term');
  }
  return term;
}

export function parsePostSearchV5RoutedPostingKey(
  key: string,
): { term: string; part: number } {
  const separator = key.lastIndexOf(POSTING_SEPARATOR);
  const term = key.slice(0, separator);
  const suffix = key.slice(separator + 1);
  if (separator <= 0 || key.indexOf(POSTING_SEPARATOR) !== separator
    || suffix.length !== POST_SEARCH_V5_POSTING_PART_WIDTH
    || !/^\d{16}$/.test(suffix)) {
    throw new Error(`Invalid post-search v5 routed posting key: ${key}`);
  }
  const part = Number(suffix);
  if (!Number.isSafeInteger(part) || postSearchV5PostingKey(term, part) !== key) {
    throw new Error(`Invalid post-search v5 routed posting key: ${key}`);
  }
  return { term, part };
}

export function normalizePostSearchV5RoutedDocument(
  id: string,
  input: PostSearchV5StoredDocument,
): { document: PostSearchV5StoredDocument; raw: string } {
  postSearchV5RoutedNonEmptyString(id, 'document id');
  if (!isPostSearchV5RoutedRecord(input) || !isPostSearchV5RoutedRecord(input.lengths)
    || input.value !== undefined && typeof input.value !== 'string') {
    throw new Error(`Invalid post-search v5 routed document: ${id}`);
  }
  const lengths: Record<string, number> = Object.create(null) as Record<string, number>;
  for (const field of Object.keys(input.lengths).sort(comparePostSearchV5RoutedText)) {
    lengths[postSearchV5RoutedNonEmptyString(field, `document ${id} field`)] =
      postSearchV5RoutedNonNegativeInteger(
        input.lengths[field],
        `document ${id} field length`,
      );
  }
  const fieldCount = Object.keys(lengths).length;
  if (fieldCount === 0 || fieldCount > POST_SEARCH_V5_MAX_FIELDS) {
    throw new Error(`Post-search v5 routed document requires 1-${POST_SEARCH_V5_MAX_FIELDS} fields: ${id}`);
  }
  const document = input.value === undefined ? { lengths } : { lengths, value: input.value };
  return { document, raw: JSON.stringify(document) };
}

export function normalizePostSearchV5RoutedPosting(
  input: PostSearchV5Posting,
  label: string,
): { posting: PostSearchV5Posting } {
  if (!isPostSearchV5RoutedRecord(input) || !isPostSearchV5RoutedRecord(input.fields)) {
    throw new Error(`Invalid post-search v5 routed posting: ${label}`);
  }
  const id = postSearchV5RoutedNonEmptyString(input.id, `${label} id`);
  const fields: PostSearchV5Posting['fields'] = Object.create(null) as PostSearchV5Posting['fields'];
  for (const name of Object.keys(input.fields).sort(comparePostSearchV5RoutedText)) {
    const field = input.fields[name];
    if (!isPostSearchV5RoutedRecord(field) || !Array.isArray(field.positions)) {
      throw new Error(`Invalid post-search v5 routed posting field: ${label}`);
    }
    const frequency = postSearchV5RoutedPositiveInteger(field.frequency, `${label} frequency`);
    const positions = field.positions.map((position) =>
      postSearchV5RoutedNonNegativeInteger(position, `${label} position`));
    if (positions.length !== frequency || positions.some((position, index) =>
      index > 0 && position <= positions[index - 1]!)) {
      throw new Error(`Invalid post-search v5 routed posting positions: ${label}`);
    }
    fields[postSearchV5RoutedNonEmptyString(name, `${label} field`)] = {
      frequency,
      positions,
    };
  }
  const fieldCount = Object.keys(fields).length;
  if (fieldCount === 0 || fieldCount > POST_SEARCH_V5_MAX_FIELDS) {
    throw new Error(`Post-search v5 routed posting requires 1-${POST_SEARCH_V5_MAX_FIELDS} fields: ${label}`);
  }
  return { posting: { id, fields } };
}

export function normalizePostSearchV5RoutedTermStats(
  input: PostSearchV5TermStats,
): PostSearchV5TermStats {
  if (!isPostSearchV5RoutedRecord(input) || !Array.isArray(input.fieldSets)) {
    throw new Error('Invalid post-search v5 routed term statistics');
  }
  const fieldSets = input.fieldSets.map((raw, index) => {
    if (!isPostSearchV5RoutedRecord(raw) || !Array.isArray(raw.fields)) {
      throw new Error(`Invalid post-search v5 routed term field set ${index}`);
    }
    const fields = raw.fields.map((field) =>
      postSearchV5RoutedNonEmptyString(field, 'term field'))
      .sort(comparePostSearchV5RoutedText);
    if (new Set(fields).size !== fields.length || fields.length === 0) {
      throw new Error('Invalid post-search v5 routed term field set fields');
    }
    return {
      fields,
      documentFrequency: postSearchV5RoutedPositiveInteger(
        raw.documentFrequency,
        'term field-set frequency',
      ),
    };
  }).sort((left, right) => comparePostSearchV5RoutedText(
    JSON.stringify(left.fields),
    JSON.stringify(right.fields),
  ));
  const normalized = {
    documentFrequency: postSearchV5RoutedPositiveInteger(
      input.documentFrequency,
      'term document frequency',
    ),
    fieldSets,
    postingParts: postSearchV5RoutedPositiveInteger(input.postingParts, 'term posting parts'),
  };
  if (fieldSets.reduce((sum, fieldSet) => addPostSearchV5Routed(
    sum,
    fieldSet.documentFrequency,
    'term field-set total',
  ), 0) !== normalized.documentFrequency) {
    throw new Error('Post-search v5 routed term field-set frequencies are inconsistent');
  }
  return normalized;
}

export function postSearchV5RoutedTermStats(
  current: PostSearchV5CurrentTermBuild,
): PostSearchV5TermStats {
  return {
    documentFrequency: current.postingCount,
    fieldSets: [...current.fieldSets.values()].sort((left, right) =>
      comparePostSearchV5RoutedText(
        JSON.stringify(left.fields),
        JSON.stringify(right.fields),
      )),
    postingParts: current.partCount,
  };
}

export function parsePostSearchV5RoutedPostingPart(
  raw: string,
  key: string,
  manifest: PostSearchV5RoutedRunManifest,
): PostSearchV5Posting[] {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error(`Invalid post-search v5 routed posting part JSON: ${key}`);
  }
  if (!Array.isArray(value) || value.length === 0) {
    throw new Error(`Invalid post-search v5 routed posting part: ${key}`);
  }
  const postings = value.map((record, index) =>
    parsePostSearchV5Posting(record, `${key}[${index}]`, manifest));
  assertPostSearchV5RoutedCanonicalRaw(
    raw,
    JSON.stringify(postings.map((posting) =>
      normalizePostSearchV5RoutedPosting(posting, key).posting)),
    `posting part ${key}`,
  );
  return postings;
}

export function encodePostSearchV5RoutedDocument(
  document: PostSearchV5StoredDocument,
  manifest: PostSearchV5RecordManifest,
): string {
  const lengths: Record<string, number> = Object.create(null) as Record<string, number>;
  for (const field of manifest.fields) {
    lengths[field.name] = document.lengths[field.name]!;
  }
  return JSON.stringify(
    document.value === undefined ? { lengths } : { lengths, value: document.value },
  );
}

export function encodePostSearchV5RoutedTermStats(stats: PostSearchV5TermStats): string {
  return JSON.stringify(normalizePostSearchV5RoutedTermStats(stats));
}
