import { createHash, randomUUID } from 'node:crypto';
import { link, lstat, mkdir, open, readFile, rename, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { nhashDecode, toHex } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import { ArchivePointerReadError } from './archivePublicationRelay';

export interface ArchiveCheckpoint {
  version: number;
  policy: { base_root: string; authors_sha256: string; author_count: number;
    initial_since: number; overlap_secs: number; relays: string[]; kinds: number[];
    page_size: number; max_pages_per_author: number; max_events_per_author: number;
    max_bytes_per_author: number; fetch_timeout_secs: number; index_commit_batch_size: number;
    source_mode?: 'best-effort' };
  root: string;
  pass_since: number;
  pass_until: number;
  next_author: number;
  events_received: number;
  coverage_head?: string;
}

export interface ArchiveRunReceipt {
  format: string;
  exitCode: number;
  before: ArchiveCheckpoint | null;
  after: ArchiveCheckpoint;
  authoritySha256: string;
  originalAndPoolPinsUnchanged: boolean;
}

/** An explicitly authorized source removal; this edge covers no new authors. */
export interface ArchiveRelayRemovalReceipt {
  format: 'iris-social/archive-relay-removal@1';
  completed: true;
  before: ArchiveCheckpoint;
  after: ArchiveCheckpoint;
  beforeCheckpointSha256: string;
  afterCheckpointSha256: string;
  previousNativeAuthoritySha256: string;
  removedRelays: string[];
}

export interface ArchiveSourceModeReceipt {
  format: 'iris-social/archive-source-mode@1';
  completed: true;
  before: ArchiveCheckpoint;
  after: ArchiveCheckpoint;
  beforeCheckpointSha256: string;
  afterCheckpointSha256: string;
  previousNativeAuthoritySha256: string;
}

/** Exact native receipt bytes, without any local filesystem path. */
export interface ArchiveSourceCoverageProof { sha256: string; raw: string }

/** A kind superset retains the index, but replays every author from the original floor. */
export interface ArchiveKindExpansionReceipt extends Omit<ArchiveSourceModeReceipt, 'format'> {
  format: 'iris-social/archive-kind-expansion@1';
}

/** Physical batching only: retain the original evidence and explicitly bind its identical coverage to the new policy. */
export interface ArchiveCommitBatchReceipt extends Omit<ArchiveSourceModeReceipt, 'format'> {
  format: 'iris-social/archive-commit-batch@1';
  coverageRebind: { before: ArchiveSourceCoverageProof; after: ArchiveSourceCoverageProof };
}

export type ArchiveLineageReceipt = ArchiveRunReceipt | ArchiveRelayRemovalReceipt | ArchiveSourceModeReceipt | ArchiveKindExpansionReceipt | ArchiveCommitBatchReceipt;

export interface ArchiveCandidate {
  state: ArchiveCheckpoint;
  run: ArchiveRunReceipt;
  checkpointSha256: string;
  receiptSha256: string;
  intermediateRuns?: ArchiveLineageReceipt[];
  repairReceipts?: ArchiveRepairReceipt[];
  sourceCoverage?: ArchiveSourceCoverageProof[];
}

/** Separately pinned evidence; never substitutes for the original native run. */
export interface ArchiveRepairReceipt {
  format: 'iris-social/archive-projection-repair@1';
  completed: boolean;
  exitCode: number;
  nativeAuthoritySha256: string;
  nativeRunReceiptSha256: string;
  nativeRepairReceiptFile: string;
  nativeRepairReceiptSha256: string;
  tool: { sourceCommit: string; binaryFile: string; binarySha256: string };
  before: { state: ArchiveCheckpoint; checkpointSha256: string; checkpointFile: string };
  after: { state: ArchiveCheckpoint; checkpointSha256: string };
  originalAndPoolPinsUnchanged: boolean;
  eventFile: string;
  eventFileSha256: string;
  event: RawEvent;
  eventCid: string;
}

export interface ArchivePublication {
  format: 'iris-social/archive-publication@1';
  candidate: ArchiveCandidate;
  event: RawEvent;
  priorEvent: RawEvent;
  confirmedRelays: string[];
  /** Absent on legacy receipts, which require two confirmations. */
  delivery?: ArchiveInitialDelivery;
}

export interface ArchiveRelayDelivery {
  relay: string;
  status: 'confirmed' | 'unconfirmed';
  stage: 'prior' | 'send' | 'readback' | 'final';
}

export interface ArchiveInitialDelivery {
  minimumConfirmedRelays: number;
  relays: string[];
  outcomes: ArchiveRelayDelivery[];
}

export interface ArchiveDeliveryReceipt {
  format: 'iris-social/archive-current-delivery@1';
  currentSha256: string;
  eventId: string;
  minimumConfirmedRelays: number;
  quorumConfirmed: boolean;
  allRelaysConfirmed: boolean;
  confirmedRelays: string[];
  outcomes: ArchiveRelayDelivery[];
}

interface Pending extends Omit<ArchivePublication, 'confirmedRelays' | 'delivery'> {
  authoritySha256: string;
  minimumConfirmedRelays?: number;
}

export interface ArchivePublicationOptions {
  directory: string;
  authoritySha256: string;
  publisher: string;
  treeName: string;
  relays: string[];
  /** Omitted retains the original two-relay publication policy. */
  minimumConfirmedRelays?: number;
  initialEvent: RawEvent;
  candidate: ArchiveCandidate;
  verify: (event: RawEvent) => boolean;
  sign: (template: Omit<RawEvent, 'id' | 'pubkey' | 'sig'>) => Promise<RawEvent>;
  readHeads: (relay: string) => Promise<RawEvent[]>;
  send: (relay: string, event: RawEvent) => Promise<void>;
  checkCandidate: (candidate: ArchiveCandidate, previous: ArchivePublication | null) => Promise<void>;
  checkProtection: () => Promise<void>;
  now?: () => number;
  fault?: (phase: 'saved-pending' | 'saved-receipt' | 'saved-current') => void;
}

export function canonical(value: unknown): string {
  if (Array.isArray(value)) {return `[${value.map(canonical).join(',')}]`;}
  if (value && typeof value === 'object') {return `{${Object.entries(value)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, entry]) => `${JSON.stringify(key)}:${canonical(entry)}`).join(',')}}`;}
  return JSON.stringify(value);
}

export function digest(value: string | Uint8Array): string {
  return createHash('sha256').update(value).digest('hex');
}

export async function readJson<T>(file: string): Promise<T | null> {
  try { return JSON.parse(await readFile(file, 'utf8')) as T; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {return null;}
    throw error;
  }
}

async function syncDirectory(directory: string): Promise<void> {
  const fd = await open(directory, 'r');
  try { await fd.sync(); } finally { await fd.close(); }
}

export async function writeDurable(file: string, value: unknown): Promise<void> {
  const temporary = `${file}.${randomUUID()}.tmp`;
  const fd = await open(temporary, 'wx', 0o600);
  try { await fd.writeFile(`${JSON.stringify(value, null, 2)}\n`); await fd.sync(); }
  finally { await fd.close(); }
  await rename(temporary, file);
  await syncDirectory(join(file, '..'));
}

function rootTags(rootText: string, treeName: string): string[][] {
  const root = nhashDecode(rootText);
  return [['d', treeName], ['l', 'hashtree'], ['hash', toHex(root.hash)],
    ...(root.key ? [['key', toHex(root.key)]] : [])];
}

function validHead(event: RawEvent, options: ArchiveDeliveryOptions): boolean {
  try { return options.verify(event) && event.pubkey === options.publisher
    && [30064, 30078].includes(event.kind)
    && event.tags.filter(tag => tag[0] === 'd').length === 1
    && event.tags.some(tag => tag[0] === 'd' && tag[1] === options.treeName); }
  catch { return false; }
}

function newest(events: RawEvent[]): RawEvent | undefined {
  return events.sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id))[0];
}

export type ArchiveDeliveryOptions = Pick<ArchivePublicationOptions,
  'directory' | 'publisher' | 'treeName' | 'relays' | 'minimumConfirmedRelays'
  | 'verify' | 'readHeads' | 'send' | 'checkProtection'>;

function minimumConfirmations(options: ArchiveDeliveryOptions): number {
  const minimum = options.minimumConfirmedRelays === undefined ? 2 : options.minimumConfirmedRelays;
  if (![1, 2].includes(minimum) || new Set(options.relays).size !== options.relays.length
    || options.relays.length < minimum || options.relays.length > 16) {
    throw new Error('Invalid publication relay confirmation policy');
  }
  return minimum;
}

function validateCurrent(current: ArchivePublication, options: ArchiveDeliveryOptions): void {
  const minimum = minimumConfirmations(options);
  const delivery = current.delivery;
  const required = delivery?.minimumConfirmedRelays ?? 2;
  if (current.format !== 'iris-social/archive-publication@1' || !validHead(current.event, options)
    || canonical(current.event.tags) !== canonical(rootTags(current.candidate.state.root, options.treeName))
    || new Set(current.confirmedRelays).size !== current.confirmedRelays.length
    || new Set(current.confirmedRelays.filter(relay => options.relays.includes(relay))).size < Math.max(minimum, required)
    || (delivery && (![1, 2].includes(required) || canonical(delivery.relays) !== canonical(options.relays)
      || new Set(delivery.relays).size !== delivery.relays.length
      || delivery.outcomes.length !== delivery.relays.length
      || delivery.outcomes.some((outcome, index) => outcome.relay !== delivery.relays[index]
        || !['confirmed', 'unconfirmed'].includes(outcome.status)
        || !['prior', 'send', 'readback', 'final'].includes(outcome.stage))
      || canonical(delivery.outcomes.filter(outcome => outcome.status === 'confirmed').map(outcome => outcome.relay))
        !== canonical(current.confirmedRelays)))) {
    throw new Error('Invalid committed publication receipt');
  }
}

class CompetingHead extends Error {
  constructor() { super('Canonical pointer changed; refusing to overwrite another publication'); }
}

/** A failed endpoint is quarantined for this finite operation, never permanently. */
class DeliveryAttempt {
  readonly failed = new Set<string>();
  readonly outcomes = new Map<string, ArchiveRelayDelivery>();
  constructor(readonly options: ArchiveDeliveryOptions) {
    for (const relay of options.relays) { this.outcomes.set(relay, { relay, status: 'unconfirmed', stage: 'prior' }); }
  }
  async map<T>(action: (relay: string) => Promise<T>): Promise<T[]> {
    // Never release the caller's lock while another relay operation is still running.
    const results = await Promise.allSettled(this.options.relays.map(action));
    const failure = results.find(result => result.status === 'rejected');
    if (failure?.status === 'rejected') { throw failure.reason; }
    return results.map(result => (result as PromiseFulfilledResult<T>).value);
  }
  private fail(relay: string, stage: ArchiveRelayDelivery['stage']): void {
    this.failed.add(relay);
    this.outcomes.set(relay, { relay, status: 'unconfirmed', stage });
  }
  async read(relay: string, expected: RawEvent[], stage: ArchiveRelayDelivery['stage']): Promise<RawEvent | undefined> {
    if (this.failed.has(relay)) { return undefined; }
    let events: RawEvent[] = [], complete = true;
    try {
      events = await this.options.readHeads(relay);
    } catch (error) {
      if (error instanceof ArchivePointerReadError) { events = error.observedHeads; }
      complete = false;
    }
    const verified = events.filter(event => validHead(event, this.options));
    const oldestExpected = Math.min(...expected.map(event => event.created_at));
    if (verified.some(head => !expected.some(event => event.id === head.id)
      && head.created_at >= oldestExpected)) { throw new CompetingHead(); }
    if (!complete || verified.length !== events.length) { this.fail(relay, stage); return undefined; }
    return newest(verified);
  }
  async send(relay: string, event: RawEvent): Promise<boolean> {
    if (this.failed.has(relay)) { return false; }
    try { await this.options.send(relay, event); }
    catch { this.fail(relay, 'send'); return false; }
    const head = await this.read(relay, [event], 'readback');
    if (!head || canonical(head) !== canonical(event)) { this.fail(relay, 'readback'); return false; }
    this.outcomes.set(relay, { relay, status: 'confirmed', stage: 'readback' });
    return true;
  }
  async heads(expected: RawEvent[], repair?: RawEvent): Promise<string[]> {
    const heads = await this.map(relay => this.read(relay, expected, 'prior'));
    // Finish conflict inspection of all reachable sources before replaying a predecessor.
    const results = await this.map(async relay => {
      const head = heads[this.options.relays.indexOf(relay)];
      if (head && expected.some(event => canonical(event) === canonical(head))) { return relay; }
      if (repair && !this.failed.has(relay) && await this.send(relay, repair)) { return relay; }
      return null;
    });
    const confirmed = results.filter((relay): relay is string => relay !== null);
    if (confirmed.length < minimumConfirmations(this.options)) {
      throw new Error(minimumConfirmations(this.options) === 2
        ? 'Two independent signed pointer readbacks are required'
        : 'At least one independent signed pointer readback is required');
    }
    return confirmed;
  }
  async deliver(event: RawEvent): Promise<string[]> {
    const outcomes = await this.map(async relay => await this.send(relay, event) ? relay : null);
    return outcomes.filter((relay): relay is string => relay !== null);
  }
  async final(event: RawEvent, acknowledged: string[]): Promise<string[]> {
    const outcomes = await this.map(async relay => {
      const head = await this.read(relay, [event], 'final');
      if (head && canonical(head) === canonical(event) && acknowledged.includes(relay)) {
        this.outcomes.set(relay, { relay, status: 'confirmed', stage: 'final' }); return relay;
      }
      if (!this.failed.has(relay)) { this.outcomes.set(relay, { relay, status: 'unconfirmed', stage: 'final' }); }
      return null;
    });
    return outcomes.filter((relay): relay is string => relay !== null);
  }
  result(): ArchiveRelayDelivery[] { return this.options.relays.map(relay => this.outcomes.get(relay)!); }
}

async function publicationBytes(file: string): Promise<Buffer> {
  const metadata = await lstat(file);
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size > 40 * 1024 * 1024) {
    throw new Error('Invalid bounded publication file');
  }
  const bytes = await readFile(file);
  if (bytes.length > 40 * 1024 * 1024) { throw new Error('Publication file exceeds its bound'); }
  return bytes;
}

async function readPublication<T>(file: string): Promise<T | null> {
  try { return JSON.parse((await publicationBytes(file)).toString()) as T; }
  catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') { return null; } throw error; }
}

/** Never overwrite initial delivery evidence, including recovery after saved-receipt. */
async function savePublicationReceipt(file: string, result: ArchivePublication,
  options: ArchiveDeliveryOptions): Promise<ArchivePublication> {
  try {
    const existing: ArchivePublication = JSON.parse((await publicationBytes(file)).toString());
    validateCurrent(existing, options);
    if (canonical(existing.event) !== canonical(result.event) || canonical(existing.priorEvent) !== canonical(result.priorEvent)
      || canonical(existing.candidate) !== canonical(result.candidate)
      || (existing.delivery?.minimumConfirmedRelays ?? 2) !== (result.delivery?.minimumConfirmedRelays ?? 2)) {
      throw new Error('Immutable publication receipt conflicts with pending event');
    }
    const fd = await open(file, 'r');
    try { await fd.sync(); } finally { await fd.close(); }
    await syncDirectory(join(file, '..'));
    return existing;
  } catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') { throw error; } }
  const temporary = `${file}.${randomUUID()}.tmp`;
  const fd = await open(temporary, 'wx', 0o600);
  try { await fd.writeFile(`${JSON.stringify(result, null, 2)}\n`); await fd.sync(); }
  finally { await fd.close(); }
  try { await link(temporary, file); await syncDirectory(join(file, '..')); }
  finally { await unlink(temporary); }
  return result;
}

/** Caller holds the same publication/operation locks. Does not sign or start native work.
 * The immutable current receipt is the retry source; this bounded latest-only ledger is expendable.
 * Older missed replaceable pointers are superseded by delivering the latest committed pointer.
 */
export async function retryArchiveCurrentDelivery(options: ArchiveDeliveryOptions): Promise<ArchiveDeliveryReceipt> {
  minimumConfirmations(options);
  const currentFile = join(options.directory, 'current.json');
  if (await readPublication(join(options.directory, 'pending.json'))) { throw new Error('Pending publication must be resolved before current delivery retry'); }
  const bytes = await publicationBytes(currentFile);
  const current: ArchivePublication = JSON.parse(bytes.toString());
  validateCurrent(current, options);
  await options.checkProtection();
  const attempt = new DeliveryAttempt(options);
  const heads = await attempt.map(relay => attempt.read(relay, [current.event], 'prior'));
  const outcomes = await attempt.map(async relay => {
    const head = heads[options.relays.indexOf(relay)];
    // Historical ACK evidence plus a fresh exact readback needs no additional EVENT.
    if (head && canonical(head) === canonical(current.event) && current.confirmedRelays.includes(relay)) {
      attempt.outcomes.set(relay, { relay, status: 'confirmed', stage: 'readback' }); return relay;
    }
    return await attempt.send(relay, current.event) ? relay : null;
  });
  await options.checkProtection();
  if (!(await publicationBytes(currentFile)).equals(bytes)) { throw new Error('Committed publication changed during delivery retry'); }
  const result: ArchiveDeliveryReceipt = { format: 'iris-social/archive-current-delivery@1',
    currentSha256: digest(bytes), eventId: current.event.id,
    minimumConfirmedRelays: current.delivery?.minimumConfirmedRelays ?? 2,
    quorumConfirmed: outcomes.filter(Boolean).length >= (current.delivery?.minimumConfirmedRelays ?? 2),
    allRelaysConfirmed: outcomes.every(Boolean),
    confirmedRelays: outcomes.filter((relay): relay is string => relay !== null), outcomes: attempt.result() };
  await writeDurable(join(options.directory, 'current-delivery.json'), result);
  return result;
}

/** Caller holds its process lock. Only the durable outbox and receipts are written. */
export async function publishArchiveCandidate(options: ArchivePublicationOptions): Promise<ArchivePublication> {
  const minimum = minimumConfirmations(options);
  const attempt = new DeliveryAttempt(options);
  await mkdir(options.directory, { recursive: true, mode: 0o700 });
  await syncDirectory(join(options.directory, '..'));
  const pendingFile = join(options.directory, 'pending.json');
  const currentFile = join(options.directory, 'current.json');
  const current = await readPublication<ArchivePublication>(currentFile);
  let pending = await readPublication<Pending>(pendingFile);
  const prior = current?.event ?? options.initialEvent;
  if (!validHead(prior, options)) {throw new Error('Invalid prior signed pointer');}
  if (current) { validateCurrent(current, options); }
  await options.checkProtection();
  // A crash after current.json was committed needs only outbox cleanup.
  if (pending && current?.event.id === pending.event.id) {
    if (canonical(current.event) !== canonical(pending.event)) {throw new Error('Committed outbox mismatch');}
    await unlink(pendingFile); await syncDirectory(options.directory); pending = null;
  }
  if (current?.candidate.checkpointSha256 === options.candidate.checkpointSha256) {
    await attempt.heads([current.event], minimum === 1 ? current.event : undefined);
    return current;
  }
  if (pending) {
    if ((pending.minimumConfirmedRelays ?? 2) !== minimum || pending.authoritySha256 !== options.authoritySha256
      || canonical(pending.candidate) !== canonical(options.candidate)
      || canonical(pending.priorEvent) !== canonical(prior)
      || !validHead(pending.event, options)
      || pending.event.kind !== 30064 || pending.event.content !== ''
      || pending.event.created_at <= prior.created_at
      || canonical(pending.event.tags) !== canonical(rootTags(pending.candidate.state.root, options.treeName))) {
      throw new Error('Pending publication does not match the exact candidate and authority');
    }
  }
  await options.checkCandidate(options.candidate, current);
  await attempt.heads([prior, ...(pending ? [pending.event] : [])], minimum === 1 ? prior : undefined);
  if (!pending) {
    const now = options.now?.() ?? Math.floor(Date.now() / 1000);
    if (prior.created_at > now + 300) {throw new Error('Prior pointer timestamp is too far in the future');}
    const template = { kind: 30064, created_at: Math.max(now, prior.created_at + 1), content: '',
      tags: rootTags(options.candidate.state.root, options.treeName) };
    const expectedTemplate = canonical(template);
    const event = await options.sign(structuredClone(template));
    if (!validHead(event, options) || canonical({ kind: event.kind, created_at: event.created_at,
      content: event.content, tags: event.tags }) !== expectedTemplate) {throw new Error('Signer changed the event template');}
    pending = { format: 'iris-social/archive-publication@1', authoritySha256: options.authoritySha256,
      candidate: options.candidate, priorEvent: prior, event,
      ...(options.minimumConfirmedRelays !== undefined ? { minimumConfirmedRelays: minimum } : {}) };
    await writeDurable(pendingFile, pending);
    options.fault?.('saved-pending');
  }
  const event = pending.event;
  await options.checkProtection();
  const acknowledged = await attempt.deliver(event);
  if (acknowledged.length < minimum) {throw new Error('Publication unconfirmed; durable signed event retained for identical retry');}
  // Any observed competing pointer remains fatal. Only destinations with ACK plus
  // an exact final signed readback count towards the durable publication frontier.
  const confirmedRelays = await attempt.final(event, acknowledged);
  if (confirmedRelays.length < minimum) {throw new Error('Publication unconfirmed; durable signed event retained for identical retry');}
  await options.checkProtection();
  let result: ArchivePublication = { format: 'iris-social/archive-publication@1',
    candidate: pending.candidate, event, priorEvent: prior, confirmedRelays,
    ...(options.minimumConfirmedRelays !== undefined ? { delivery: { minimumConfirmedRelays: minimum,
      relays: [...options.relays], outcomes: attempt.result() } } : {}) };
  await mkdir(join(options.directory, 'receipts'), { recursive: true });
  await syncDirectory(options.directory);
  result = await savePublicationReceipt(join(options.directory, 'receipts', `${event.id}.json`), result, options);
  options.fault?.('saved-receipt');
  await writeDurable(currentFile, result);
  options.fault?.('saved-current');
  await unlink(pendingFile); await syncDirectory(options.directory);
  return result;
}
