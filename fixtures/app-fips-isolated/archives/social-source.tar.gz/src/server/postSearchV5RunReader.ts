import { HashTree, LinkType, type CID, type Store, type TreeEntry } from '@hashtree/core';
import { parsePostSearchV5RunManifest } from './postSearchV5RunManifest';
import {
  parsePostSearchV5Posting,
  parsePostSearchV5PostingKey,
  parsePostSearchV5StoredDocument,
  parsePostSearchV5TermStats,
  postSearchV5PostingTerm,
  postSearchV5TermStatistics,
} from './postSearchV5RunRecords';
import {
  assertPostSearchV5ExactNames,
  postSearchV5ReachableHashes,
  postSearchV5RequiredEntry,
  readPostSearchV5Branch,
  readPostSearchV5BucketEntries,
  readPostSearchV5RawBlock,
  type PostSearchV5ReadBranch,
} from './postSearchV5RunStorage';
import type {
  PostSearchV5Posting,
  PostSearchV5Run,
  PostSearchV5RunLookup,
  PostSearchV5RunManifest,
  PostSearchV5StoredDocument,
  PostSearchV5TermStats,
} from './postSearchV5RunTypes';
import {
  assertPostSearchV5PublicCid,
  comparePostSearchV5Strings,
  parsePostSearchV5JsonArray,
} from './postSearchV5RunValidation';

interface ParsedPostings {
  byTerm: Map<string, PostSearchV5Posting[]>;
  partCounts: Map<string, number>;
}

interface OpenedRoot {
  tree: HashTree;
  rootEntries: TreeEntry[];
  manifest: PostSearchV5RunManifest;
}

export async function readPostSearchV5Run(store: Store, root: CID): Promise<PostSearchV5Run> {
  const opened = await openRoot(store, root);
  const { tree, rootEntries, manifest } = opened;
  const documentEntries = await readPostSearchV5Branch(tree, store, postSearchV5RequiredEntry(
    rootEntries,
    'documents',
    LinkType.Dir,
  ).cid, 'documents');
  const postingEntries = await readPostSearchV5Branch(tree, store, postSearchV5RequiredEntry(
    rootEntries,
    'postings',
    LinkType.Dir,
  ).cid, 'postings');
  const termEntries = await readPostSearchV5Branch(tree, store, postSearchV5RequiredEntry(
    rootEntries,
    'terms',
    LinkType.Dir,
  ).cid, 'terms');
  validateBranchCounts(manifest, documentEntries, postingEntries, termEntries);
  const documents = parseDocuments(documentEntries, manifest);
  const postings = parsePostings(postingEntries, manifest, documents);
  const terms = parseTerms(termEntries, manifest, postings);
  const reachableNodeCount = (await postSearchV5ReachableHashes(tree, [root])).size;
  if (reachableNodeCount !== manifest.reachableNodeCount) {
    throw new Error('Post-search v5 run reachable node count mismatch');
  }
  return {
    root,
    manifest,
    getDocument: (id) => documents.get(id) ?? null,
    getTerm: (term) => terms.get(term) ?? null,
    getPostings: (term) => postings.byTerm.get(term) ?? [],
  };
}

export async function openPostSearchV5Run(
  store: Store,
  root: CID,
): Promise<PostSearchV5RunLookup> {
  const { tree, rootEntries, manifest } = await openRoot(store, root);
  const branch = (name: 'documents' | 'postings' | 'terms') =>
    postSearchV5RequiredEntry(rootEntries, name, LinkType.Dir).cid;
  return {
    root,
    manifest,
    getDocument: async (id) => {
      const entries = await readPostSearchV5BucketEntries(
        tree,
        store,
        branch('documents'),
        'documents',
        id,
      );
      const found = entries.find(([key]) => key === id);
      return found ? parsePostSearchV5StoredDocument(found[0], found[1], manifest) : null;
    },
    getTerm: async (term) => {
      const entries = await readPostSearchV5BucketEntries(
        tree,
        store,
        branch('terms'),
        'terms',
        term,
      );
      const found = entries.find(([key]) => key === term);
      return found ? parsePostSearchV5TermStats(found[1], term, manifest) : null;
    },
    getPostings: async (term) => {
      const entries = await readPostSearchV5BucketEntries(
        tree,
        store,
        branch('postings'),
        'postings',
        term,
      );
      const matches = entries.filter(([key]) => postSearchV5PostingTerm(key) === term)
        .sort(([left], [right]) => comparePostSearchV5Strings(left, right));
      const postings: PostSearchV5Posting[] = [];
      for (let index = 0; index < matches.length; index += 1) {
        const [key, raw] = matches[index]!;
        if (parsePostSearchV5PostingKey(key).part !== index) {
          throw new Error(`Non-contiguous post-search v5 posting parts: ${term}`);
        }
        postings.push(...parsePostSearchV5JsonArray(raw, `postings ${key}`).map(
          (value, recordIndex) =>
            parsePostSearchV5Posting(value, `${key}[${recordIndex}]`, manifest),
        ));
      }
      const ids = postings.map((posting) => posting.id);
      if (new Set(ids).size !== ids.length
        || ids.some((id, index) => index > 0 && id <= ids[index - 1]!)) {
        throw new Error(`Invalid post-search v5 posting order: ${term}`);
      }
      return postings;
    },
  };
}

async function openRoot(store: Store, root: CID): Promise<OpenedRoot> {
  assertPostSearchV5PublicCid(root, 'run root');
  const tree = new HashTree({ store });
  const rootEntries = await tree.listDirectory(root);
  assertPostSearchV5ExactNames(
    rootEntries,
    ['documents', 'manifest.json', 'postings', 'terms'],
    'run root',
  );
  const manifestEntry = postSearchV5RequiredEntry(
    rootEntries,
    'manifest.json',
    LinkType.Blob,
  );
  const manifestBytes = await readPostSearchV5RawBlock(store, manifestEntry.cid, 'manifest');
  if (manifestEntry.size !== manifestBytes.length) {
    throw new Error('Post-search v5 manifest link size mismatch');
  }
  return { tree, rootEntries, manifest: parsePostSearchV5RunManifest(manifestBytes) };
}

function parseDocuments(
  branch: PostSearchV5ReadBranch,
  manifest: PostSearchV5RunManifest,
): Map<string, PostSearchV5StoredDocument> {
  const documents = new Map<string, PostSearchV5StoredDocument>();
  let storedValueCount = 0;
  const totals = new Map(manifest.fields.map((field) => [field.name, 0]));
  const populated = new Map(manifest.fields.map((field) => [field.name, 0]));
  for (const [id, raw] of branch.entries) {
    const document = parsePostSearchV5StoredDocument(id, raw, manifest);
    for (const field of manifest.fields) {
      const length = document.lengths[field.name]!;
      totals.set(field.name, (totals.get(field.name) ?? 0) + length);
      if (length > 0) {
        populated.set(field.name, (populated.get(field.name) ?? 0) + 1);
      }
    }
    if (document.value !== undefined) {
      storedValueCount += 1;
    }
    documents.set(id, document);
  }
  if (documents.size !== manifest.documentCount
    || storedValueCount !== manifest.storedValueCount) {
    throw new Error('Post-search v5 document coverage mismatch');
  }
  for (const field of manifest.fields) {
    if (totals.get(field.name) !== field.totalLength
      || populated.get(field.name) !== field.populatedDocumentCount) {
      throw new Error(`Post-search v5 field coverage mismatch: ${field.name}`);
    }
  }
  return documents;
}

function parsePostings(
  branch: PostSearchV5ReadBranch,
  manifest: PostSearchV5RunManifest,
  documents: ReadonlyMap<string, PostSearchV5StoredDocument>,
): ParsedPostings {
  const postings = new Map<string, PostSearchV5Posting[]>();
  const partIndexes = new Map<string, number[]>();
  let postingCount = 0;
  let tokenOccurrenceCount = 0;
  for (const [key, raw] of branch.entries.sort(([left], [right]) =>
    comparePostSearchV5Strings(left, right))) {
    const { term, part } = parsePostSearchV5PostingKey(key);
    const records = parsePostSearchV5JsonArray(raw, `postings ${key}`).map((value, index) =>
      parsePostSearchV5Posting(value, `${key}[${index}]`, manifest, documents));
    const existing = postings.get(term) ?? [];
    existing.push(...records);
    postings.set(term, existing);
    const indexes = partIndexes.get(term) ?? [];
    indexes.push(part);
    partIndexes.set(term, indexes);
    postingCount += records.length;
    tokenOccurrenceCount += records.reduce((total, posting) => total
      + Object.values(posting.fields).reduce((sum, field) => sum + field.frequency, 0), 0);
  }
  for (const [term, indexes] of partIndexes) {
    if (indexes.some((part, index) => part !== index)) {
      throw new Error(`Non-contiguous post-search v5 posting parts: ${term}`);
    }
    const ids = postings.get(term)?.map((posting) => posting.id) ?? [];
    if (new Set(ids).size !== ids.length
      || ids.some((id, index) => index > 0 && id <= ids[index - 1]!)) {
      throw new Error(`Invalid post-search v5 posting order: ${term}`);
    }
  }
  if (postingCount !== manifest.postingCount
    || tokenOccurrenceCount !== manifest.tokenOccurrenceCount) {
    throw new Error('Post-search v5 posting coverage mismatch');
  }
  return {
    byTerm: postings,
    partCounts: new Map([...partIndexes].map(([term, indexes]) => [term, indexes.length])),
  };
}

function parseTerms(
  branch: PostSearchV5ReadBranch,
  manifest: PostSearchV5RunManifest,
  postings: ParsedPostings,
): Map<string, PostSearchV5TermStats> {
  const terms = new Map<string, PostSearchV5TermStats>();
  for (const [term, raw] of branch.entries) {
    const actualPostings = postings.byTerm.get(term);
    if (!actualPostings) {
      throw new Error(`Post-search v5 term has no postings: ${term}`);
    }
    const actual = postSearchV5TermStatistics(actualPostings);
    const parsed = parsePostSearchV5TermStats(raw, term, manifest);
    if (parsed.documentFrequency !== actual.documentFrequency
      || JSON.stringify(parsed.fieldSets) !== JSON.stringify(actual.fieldSets)
      || parsed.postingParts !== postings.partCounts.get(term)) {
      throw new Error(`Post-search v5 term statistics mismatch: ${term}`);
    }
    terms.set(term, parsed);
  }
  if (terms.size !== manifest.termCount || terms.size !== postings.byTerm.size) {
    throw new Error('Post-search v5 term coverage mismatch');
  }
  return terms;
}

function validateBranchCounts(
  manifest: PostSearchV5RunManifest,
  documents: PostSearchV5ReadBranch,
  postings: PostSearchV5ReadBranch,
  terms: PostSearchV5ReadBranch,
): void {
  const pageTotal = documents.pageCount + postings.pageCount + terms.pageCount;
  if (documents.pageCount !== manifest.pages.documents
    || postings.pageCount !== manifest.pages.postings
    || terms.pageCount !== manifest.pages.terms
    || pageTotal !== manifest.pages.total
    || documents.entries.length !== manifest.entries.documents
    || postings.entries.length !== manifest.entries.postings
    || terms.entries.length !== manifest.entries.terms) {
    throw new Error('Post-search v5 run page coverage mismatch');
  }
}
