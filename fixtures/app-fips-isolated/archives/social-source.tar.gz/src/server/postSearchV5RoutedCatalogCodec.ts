import {
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  nhashEncode,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import {
  POST_SEARCH_KINDS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
} from '../lib/postSearchCatalogConstants';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import {
  POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
  readPostSearchV5VisibilityOverlay,
} from './postSearchV5OverlayStore';
import {
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  type PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRun';
import {
  POST_SEARCH_V5_ROUTED_CATALOG_DAEMON_HARD_LIMIT,
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_LEVEL,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS_PER_LEVEL,
  POST_SEARCH_V5_ROUTED_CATALOG_OVERLAY_ENTRY as OVERLAY_ENTRY,
  POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  type PostSearchV5RoutedCatalogEnvelope,
  type PostSearchV5RoutedCatalogManifest,
  type PostSearchV5RoutedCatalogOverlayDescriptor,
  type PostSearchV5RoutedCatalogOverlayInput,
  type PostSearchV5RoutedCatalogRunDescriptor,
  type PostSearchV5RoutedCatalogRunInput,
  type PostSearchV5RoutedCoverage,
  type PostSearchV5RoutedScoringManifest,
  type PostSearchV5RoutedSourceSnapshot,
} from './postSearchV5RoutedCatalogTypes';
import {
  addPostSearchV5RoutedCatalog as safeAdd,
  assertPostSearchV5RoutedCatalogCanonicalLink as assertCanonicalLink,
  assertPostSearchV5RoutedCatalogExactKeys as exactKeys,
  comparePostSearchV5RoutedCatalogText as compareText,
  equalPostSearchV5RoutedCatalogBytes as equalBytes,
  postSearchV5RoutedCatalogBoundedNumber as boundedNumber,
  postSearchV5RoutedCatalogNonEmptyString as nonEmptyString,
  postSearchV5RoutedCatalogNonNegativeInteger as nonNegativeInteger,
  postSearchV5RoutedCatalogNullableInteger as nullableInteger,
  postSearchV5RoutedCatalogObject as objectValue,
  postSearchV5RoutedCatalogPositiveInteger as positiveInteger,
  postSearchV5RoutedCatalogPositiveNumber as positiveNumber,
  postSearchV5RoutedCatalogPublicCid as publicCid,
  postSearchV5RoutedCatalogPublicNhash as publicNhash,
  postSearchV5RoutedCatalogPublisher as publisher,
  readPostSearchV5RoutedCatalogPublicBlock as readPublicBlock,
  samePostSearchV5RoutedCatalogStrings as sameStrings,
} from './postSearchV5RoutedCatalogValidation';

const MANIFEST_ENTRY = 'manifest.json';
const ROOT_MAX_BYTES = 65_536;
const MANIFEST_MAX_BYTES = 256 * 1_024;
const SUPPORTED_KINDS = new Set<number>(POST_SEARCH_KINDS);
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export async function readPostSearchV5RoutedCatalogEnvelope(store: Store, root: CID): Promise<PostSearchV5RoutedCatalogEnvelope> {
  const rootBytes = await readPublicBlock(store, root, ROOT_MAX_BYTES, 'catalog root');
  let node;
  try {node = decodeTreeNode(rootBytes);} catch {
    throw new Error('Post-search v5 routed catalog root is not a directory');
  }
  if (node.type !== LinkType.Dir || !equalBytes(rootBytes, encodeTreeNode(node))) {
    throw new Error('Post-search v5 routed catalog root is not a canonical directory');
  }
  node.links.forEach(assertCanonicalLink);
  const manifestLink = node.links.find((link) => link.name === MANIFEST_ENTRY);
  if (!manifestLink || manifestLink.type !== LinkType.Blob) {
    throw new Error('Post-search v5 routed catalog manifest link is missing');
  }
  const bytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    MANIFEST_MAX_BYTES,
    'catalog manifest',
  );
  if (bytes.length !== manifestLink.size) {
    throw new Error('Post-search v5 routed catalog manifest link size is inconsistent');
  }
  const manifest = parseManifest(bytes);
  const names = node.links.map((link) => link.name!).sort(compareText);
  const expected = [MANIFEST_ENTRY, ...manifest.runs.map((run) => run.entry),
    ...(manifest.overlay ? [manifest.overlay.entry] : [])].sort(compareText);
  if (!sameStrings(names, expected)) {
    throw new Error('Post-search v5 routed catalog has missing or unbound root links');
  }
  const runRoots = manifest.runs.map((run) => boundLink(node.links, run));
  const overlayRoot = manifest.overlay ? boundLink(node.links, manifest.overlay) : null;
  return { root: publicCid(root, 'catalog root'), manifest, runRoots, overlayRoot };
}
function parseManifest(bytes: Uint8Array): PostSearchV5RoutedCatalogManifest {
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {
    throw new Error('Invalid post-search v5 routed catalog manifest JSON');
  }
  const raw = objectValue(value, 'catalog manifest');
  exactKeys(raw, ['batchSize', 'compatibility', 'format', 'generatedAt', 'overlay',
    'publisherId', 'reachableNodeCount', 'runs', 'scoring', 'source'], 'catalog manifest');
  const compatibility = objectValue(raw.compatibility, 'compatibility');
  exactKeys(compatibility, ['normalization', 'overlayFormat', 'packedPageFormat',
    'pageRouterFormat', 'runFormat'], 'compatibility');
  if (raw.format !== POST_SEARCH_V5_ROUTED_CATALOG_FORMAT
    || compatibility.runFormat !== POST_SEARCH_V5_ROUTED_RUN_FORMAT
    || compatibility.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || compatibility.pageRouterFormat !== POST_SEARCH_V5_PAGE_ROUTER_FORMAT
    || compatibility.overlayFormat !== POST_SEARCH_V5_OVERLAY_STORE_FORMAT
    || compatibility.normalization !== POST_SEARCH_NORMALIZATION
    || !Array.isArray(raw.runs)
    || raw.runs.length > POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS) {
    throw new Error('Unsupported or invalid post-search v5 routed catalog manifest');
  }
  const batchSize = positiveInteger(raw.batchSize, 'batchSize');
  const roots = new Set<string>();
  const runs = raw.runs.map((run, index) => parseRunDescriptor(run, index, roots));
  assertRunLayout(runs, batchSize);
  const overlay = raw.overlay === null ? null : parseOverlay(raw.overlay);
  const manifest: PostSearchV5RoutedCatalogManifest = {
    format: POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
    publisherId: publisher(raw.publisherId),
    generatedAt: nonNegativeInteger(raw.generatedAt, 'generatedAt'),
    batchSize,
    source: sourceSnapshot(raw.source, runs),
    compatibility: {
      runFormat: POST_SEARCH_V5_ROUTED_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
      overlayFormat: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
    },
    scoring: parseScoring(raw.scoring),
    runs,
    overlay,
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'reachableNodeCount'),
  };
  if (manifest.reachableNodeCount !== capacity(runs, overlay, capacityLimit())
    || !equalBytes(bytes, encodeManifest(manifest))) {
    throw new Error('Inconsistent or noncanonical post-search v5 routed catalog manifest');
  }
  return manifest;
}

export function runDescriptor(
  input: PostSearchV5RoutedCatalogRunInput,
  index: number,
): PostSearchV5RoutedCatalogRunDescriptor {
  const level = boundedLevel(input.level);
  const oldestBatch = nonNegativeInteger(input.oldestBatch, `run ${index} oldestBatch`);
  const newestBatchExclusive = positiveInteger(
    input.newestBatchExclusive,
    `run ${index} newestBatchExclusive`,
  );
  const descriptor = parseRunDescriptor({
    ...input,
    entry: runEntry(level, oldestBatch, newestBatchExclusive),
    root: nhashEncode(publicCid(input.root, `run ${index} root`)),
  }, index, new Set());
  return descriptor;
}

function parseRunDescriptor(
  value: unknown,
  index: number,
  roots: Set<string>,
): PostSearchV5RoutedCatalogRunDescriptor {
  const raw = objectValue(value, `run ${index}`);
  exactKeys(raw, ['documentCount', 'entry', 'kinds', 'level', 'newestBatchExclusive',
    'oldestBatch', 'pageCount', 'postingCount', 'postingPartCount', 'reachableNodeCount',
    'root', 'since', 'storedValueCount', 'termCount', 'tokenOccurrenceCount', 'until'],
  `run ${index}`);
  const level = boundedLevel(raw.level);
  const oldestBatch = nonNegativeInteger(raw.oldestBatch, `run ${index} oldestBatch`);
  const newestBatchExclusive = positiveInteger(
    raw.newestBatchExclusive,
    `run ${index} newestBatchExclusive`,
  );
  const root = nhashEncode(publicNhash(raw.root, `run ${index} root`));
  if (roots.has(root)) {throw new Error('Post-search v5 routed catalog has a duplicate run');}
  roots.add(root);
  const descriptor: PostSearchV5RoutedCatalogRunDescriptor = {
    entry: nonEmptyString(raw.entry, `run ${index} entry`),
    root,
    level,
    oldestBatch,
    newestBatchExclusive,
    documentCount: positiveInteger(raw.documentCount, `run ${index} documentCount`),
    postingCount: nonNegativeInteger(raw.postingCount, `run ${index} postingCount`),
    postingPartCount: nonNegativeInteger(raw.postingPartCount, `run ${index} postingPartCount`),
    termCount: nonNegativeInteger(raw.termCount, `run ${index} termCount`),
    storedValueCount: nonNegativeInteger(raw.storedValueCount, `run ${index} storedValueCount`),
    tokenOccurrenceCount: nonNegativeInteger(
      raw.tokenOccurrenceCount,
      `run ${index} tokenOccurrenceCount`,
    ),
    pageCount: positiveInteger(raw.pageCount, `run ${index} pageCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `run ${index} reachableNodeCount`),
    kinds: kinds(raw.kinds),
    since: nonNegativeInteger(raw.since, `run ${index} since`),
    until: nonNegativeInteger(raw.until, `run ${index} until`),
  };
  if (descriptor.entry !== runEntry(level, oldestBatch, newestBatchExclusive)
    || newestBatchExclusive !== oldestBatch + 2 ** level
    || oldestBatch % (2 ** level) !== 0
    || descriptor.since > descriptor.until) {
    throw new Error(`Invalid post-search v5 routed catalog run layout at ${index}`);
  }
  return descriptor;
}

export function scoringManifest(runs: readonly PostSearchV5RoutedRunLookup[]): PostSearchV5RoutedScoringManifest {
  if (runs.length === 0) {return { documentCount: 0, k1: 1.2, maxTokensPerField: 4_096, fields: [] };}
  const first = runs[0]!.manifest;
  const fields = first.fields.map(({ name, boost, lengthNormalization }) => ({
    name, boost, lengthNormalization, totalLength: 0, populatedDocumentCount: 0,
  }));
  let documentCount = 0;
  for (const run of runs) {
    if (run.manifest.k1 !== first.k1
      || run.manifest.maxTokensPerField !== first.maxTokensPerField
      || !sameFieldSchema(run.manifest.fields, first.fields)) {
      throw new Error('Post-search v5 routed runs use incompatible scoring schemas');
    }
    documentCount = safeAdd(documentCount, run.manifest.documentCount, 'document count');
    run.manifest.fields.forEach((field, index) => {
      fields[index]!.totalLength = safeAdd(
        fields[index]!.totalLength,
        field.totalLength,
        'field total length',
      );
      fields[index]!.populatedDocumentCount = safeAdd(
        fields[index]!.populatedDocumentCount,
        field.populatedDocumentCount,
        'field populated count',
      );
    });
  }
  return { documentCount, k1: first.k1, maxTokensPerField: first.maxTokensPerField, fields };
}

function parseScoring(value: unknown): PostSearchV5RoutedScoringManifest {
  const raw = objectValue(value, 'scoring');
  exactKeys(raw, ['documentCount', 'fields', 'k1', 'maxTokensPerField'], 'scoring');
  if (!Array.isArray(raw.fields)) {throw new Error('Invalid post-search v5 routed scoring fields');}
  const fields = raw.fields.map((field, index) => {
    const item = objectValue(field, `scoring field ${index}`);
    exactKeys(item, ['boost', 'lengthNormalization', 'name', 'populatedDocumentCount',
      'totalLength'], `scoring field ${index}`);
    return {
      name: nonEmptyString(item.name, `scoring field ${index} name`),
      boost: positiveNumber(item.boost, `scoring field ${index} boost`),
      lengthNormalization: boundedNumber(
        item.lengthNormalization,
        0,
        1,
        `scoring field ${index} normalization`,
      ),
      totalLength: nonNegativeInteger(item.totalLength, `scoring field ${index} totalLength`),
      populatedDocumentCount: nonNegativeInteger(
        item.populatedDocumentCount,
        `scoring field ${index} populatedDocumentCount`,
      ),
    };
  });
  if (new Set(fields.map((field) => field.name)).size !== fields.length
    || fields.some((field) => field.populatedDocumentCount > (raw.documentCount as number))) {
    throw new Error('Invalid post-search v5 routed scoring fields');
  }
  return {
    documentCount: nonNegativeInteger(raw.documentCount, 'scoring documentCount'),
    k1: positiveNumber(raw.k1, 'scoring k1'),
    maxTokensPerField: positiveInteger(raw.maxTokensPerField, 'scoring maxTokensPerField'),
    fields,
  };
}

export function assertRunsMatchCatalog(
  manifest: PostSearchV5RoutedCatalogManifest,
  runs: readonly PostSearchV5RoutedRunLookup[],
): void {
  runs.forEach((run, index) => assertRunDescriptor(manifest.runs[index]!, run, index));
  if (JSON.stringify(scoringManifest(runs)) !== JSON.stringify(manifest.scoring)) {
    throw new Error('Post-search v5 routed catalog scoring does not match its runs');
  }
}

export function assertRunDescriptor(
  descriptor: PostSearchV5RoutedCatalogRunDescriptor,
  run: PostSearchV5RoutedRunLookup,
  index: number,
): void {
  const pageCount = run.manifest.branches.documents.pageCount
    + (run.manifest.branches.postings?.pageCount ?? 0)
    + (run.manifest.branches.terms?.pageCount ?? 0);
  if (descriptor.root !== nhashEncode(run.root)
    || descriptor.pageCount !== pageCount
    || descriptor.storedValueCount !== run.manifest.storedValueCount
    || descriptor.tokenOccurrenceCount !== run.manifest.tokenOccurrenceCount) {
    throw new Error(`Post-search v5 routed run descriptor is unverified at ${index}`);
  }
}

export function runExpected(run: PostSearchV5RoutedCatalogRunDescriptor) {
  return {
    documentCount: run.documentCount,
    termCount: run.termCount,
    postingCount: run.postingCount,
    postingPartCount: run.postingPartCount,
    storedValueCount: run.storedValueCount,
    tokenOccurrenceCount: run.tokenOccurrenceCount,
    pageCount: run.pageCount,
    reachableNodeCount: run.reachableNodeCount,
  };
}

export async function verifiedOverlay(
  store: Store,
  input: PostSearchV5RoutedCatalogOverlayInput | null,
): Promise<PostSearchV5RoutedCatalogOverlayDescriptor | null> {
  if (!input) {return null;}
  const descriptor = parseOverlay({
    ...input,
    entry: OVERLAY_ENTRY,
    root: nhashEncode(publicCid(input.root, 'overlay root')),
  });
  await readPostSearchV5VisibilityOverlay(store, input.root, overlayExpected(descriptor));
  return descriptor;
}

function parseOverlay(value: unknown): PostSearchV5RoutedCatalogOverlayDescriptor {
  const raw = objectValue(value, 'overlay');
  exactKeys(raw, ['addressDeletionCount', 'addressWinnerCount', 'coordinateStateCount',
    'entry', 'exactTombstoneCount', 'pageCount', 'reachableNodeCount', 'root'], 'overlay');
  if (raw.entry !== OVERLAY_ENTRY) {throw new Error('Invalid post-search v5 routed overlay entry');}
  const coordinateStateCount = nonNegativeInteger(raw.coordinateStateCount, 'coordinateStateCount');
  const descriptor: PostSearchV5RoutedCatalogOverlayDescriptor = {
    entry: OVERLAY_ENTRY,
    root: nhashEncode(publicNhash(raw.root, 'overlay root')),
    exactTombstoneCount: nonNegativeInteger(raw.exactTombstoneCount, 'exactTombstoneCount'),
    coordinateStateCount,
    addressWinnerCount: nonNegativeInteger(raw.addressWinnerCount, 'addressWinnerCount'),
    addressDeletionCount: nonNegativeInteger(raw.addressDeletionCount, 'addressDeletionCount'),
    pageCount: positiveInteger(raw.pageCount, 'overlay pageCount'),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'overlay reachableNodeCount'),
  };
  if (descriptor.addressWinnerCount > coordinateStateCount
    || descriptor.addressDeletionCount > coordinateStateCount) {
    throw new Error('Invalid post-search v5 routed overlay counts');
  }
  return descriptor;
}

export function overlayExpected(value: PostSearchV5RoutedCatalogOverlayDescriptor) {
  return {
    exactTombstoneCount: value.exactTombstoneCount,
    coordinateStateCount: value.coordinateStateCount,
    addressWinnerCount: value.addressWinnerCount,
    addressDeletionCount: value.addressDeletionCount,
    pageCount: value.pageCount,
    reachableNodeCount: value.reachableNodeCount,
  };
}

export function sourceSnapshot(
  value: unknown,
  runs: readonly PostSearchV5RoutedCatalogRunDescriptor[],
): PostSearchV5RoutedSourceSnapshot {
  const raw = objectValue(value, 'source');
  exactKeys(raw, ['coverage', 'eventRoot', 'projection'], 'source');
  if (raw.projection !== POST_SEARCH_VISIBLE_PROJECTION) {
    throw new Error('Invalid post-search v5 routed source projection');
  }
  const coverage = coverageValue(raw.coverage);
  const expected = coverageForRuns(runs);
  if (JSON.stringify(coverage) !== JSON.stringify(expected)) {
    throw new Error('Post-search v5 routed source coverage does not match its active runs');
  }
  return {
    eventRoot: nhashEncode(publicNhash(raw.eventRoot, 'source event root')),
    projection: POST_SEARCH_VISIBLE_PROJECTION,
    coverage,
  };
}

function coverageForRuns(
  runs: readonly PostSearchV5RoutedCatalogRunDescriptor[],
): PostSearchV5RoutedCoverage {
  if (runs.length === 0) {return { eventCount: 0, kinds: [], since: null, until: null };}
  return {
    eventCount: runs.reduce((sum, run) => safeAdd(sum, run.documentCount, 'coverage'), 0),
    kinds: [...new Set(runs.flatMap((run) => run.kinds))].sort((left, right) => left - right),
    since: Math.min(...runs.map((run) => run.since)),
    until: Math.max(...runs.map((run) => run.until)),
  };
}

function coverageValue(value: unknown): PostSearchV5RoutedCoverage {
  const raw = objectValue(value, 'coverage');
  exactKeys(raw, ['eventCount', 'kinds', 'since', 'until'], 'coverage');
  const coverage = {
    eventCount: nonNegativeInteger(raw.eventCount, 'coverage eventCount'),
    kinds: kinds(raw.kinds),
    since: nullableInteger(raw.since, 'coverage since'),
    until: nullableInteger(raw.until, 'coverage until'),
  };
  if ((coverage.eventCount === 0) !== (coverage.since === null && coverage.until === null
    && coverage.kinds.length === 0)
    || (coverage.since !== null && coverage.until !== null && coverage.since > coverage.until)) {
    throw new Error('Invalid post-search v5 routed source coverage');
  }
  return coverage;
}

export function assertRunLayout(
  runs: readonly PostSearchV5RoutedCatalogRunDescriptor[],
  batchSize: number,
): void {
  const counts = new Map<number, number>();
  let nextBatch = 0;
  for (const run of runs) {
    if (run.oldestBatch !== nextBatch) {
      throw new Error('Post-search v5 routed run ranges contain an overlap or gap');
    }
    const count = (counts.get(run.level) ?? 0) + 1;
    if (count > POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS_PER_LEVEL) {
      throw new Error(`Post-search v5 routed catalog has too many runs at level ${run.level}`);
    }
    const capacity = batchSize * (run.newestBatchExclusive - run.oldestBatch);
    if (!Number.isSafeInteger(capacity) || run.documentCount > capacity) {
      throw new Error('Post-search v5 routed run exceeds its source batch capacity');
    }
    counts.set(run.level, count);
    nextBatch = run.newestBatchExclusive;
  }
}

export function capacity(
  runs: readonly PostSearchV5RoutedCatalogRunDescriptor[],
  overlay: PostSearchV5RoutedCatalogOverlayDescriptor | null,
  maximum: number,
): number {
  const reachable = runs.reduce(
    (sum, run) => safeAdd(sum, run.reachableNodeCount, 'reachability'),
    2,
  ) + (overlay?.reachableNodeCount ?? 0);
  if (!Number.isSafeInteger(reachable) || reachable >= maximum) {
    throw new Error('Post-search v5 routed catalog exceeds its reachable-node capacity');
  }
  return reachable;
}

export function capacityLimit(value?: number): number {
  const maximum = value === undefined
    ? POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT
    : positiveInteger(value, 'maxReachableNodeCount');
  if (maximum > POST_SEARCH_V5_ROUTED_CATALOG_DAEMON_HARD_LIMIT) {
    throw new Error('Post-search v5 routed catalog capacity exceeds the daemon hard limit');
  }
  return maximum;
}

function boundLink(
  links: readonly Link[],
  descriptor: { entry: string; root: string; reachableNodeCount: number },
): CID {
  const link = links.find((candidate) => candidate.name === descriptor.entry);
  const root = publicNhash(descriptor.root, `${descriptor.entry} root`);
  if (!link || link.type !== LinkType.Dir || link.size !== descriptor.reachableNodeCount
    || !equalBytes(link.hash, root.hash)) {
    throw new Error(`Post-search v5 routed catalog link is inconsistent: ${descriptor.entry}`);
  }
  return root;
}

function runEntry(level: number, oldest: number, newest: number): string {
  return `run-${level.toString().padStart(2, '0')}-${oldest}-${newest}`;
}

function boundedLevel(value: unknown): number {
  const level = nonNegativeInteger(value, 'run level');
  if (level > POST_SEARCH_V5_ROUTED_CATALOG_MAX_LEVEL) {
    throw new Error('Post-search v5 routed run level exceeds capacity');
  }
  return level;
}

function kinds(value: unknown): number[] {
  if (!Array.isArray(value)
    || !value.every((kind) => Number.isInteger(kind) && SUPPORTED_KINDS.has(kind as number))) {
    throw new Error('Invalid post-search v5 routed kinds');
  }
  return [...new Set(value as number[])].sort((left, right) => left - right);
}

function sameFieldSchema(
  left: readonly RankedSearchFieldManifest[],
  right: readonly RankedSearchFieldManifest[],
): boolean {
  return left.length === right.length && left.every((field, index) => {
    const other = right[index];
    return other?.name === field.name && other.boost === field.boost
      && other.lengthNormalization === field.lengthNormalization;
  });
}

export function encodeManifest(manifest: PostSearchV5RoutedCatalogManifest): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length === 0 || bytes.length > MANIFEST_MAX_BYTES) {
    throw new Error('Post-search v5 routed catalog manifest exceeds its byte capacity');
  }
  return bytes;
}
