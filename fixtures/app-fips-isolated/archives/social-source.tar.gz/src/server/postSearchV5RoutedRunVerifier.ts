import type { CID, Store } from '@hashtree/core';
import { openPostSearchV5PageRouter } from './postSearchV5PageRouter';
import {
  parsePostSearchV5RoutedPostingKey,
  parsePostSearchV5RoutedPostingPart,
  postSearchV5RoutedTermStats,
} from './postSearchV5RoutedRunRecords';
import { streamPostSearchV5RoutedBranchEntries } from './postSearchV5RoutedRunLookup';
import type {
  PostSearchV5CurrentTermBuild,
  PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRunTypes';
import {
  addPostSearchV5Routed,
  comparePostSearchV5RoutedText,
} from './postSearchV5RoutedRunValidation';

const VERIFY_DOCUMENT_LENGTH_CACHE_ENTRIES = 4_096;

export async function verifyPostSearchV5RoutedRunRecords(
  lookup: PostSearchV5RoutedRunLookup,
  store: Store,
  postingRoot: CID | null,
): Promise<void> {
  await verifyDocuments(lookup);
  await verifyTermsAndPostings(lookup, store, postingRoot);
}

async function verifyDocuments(lookup: PostSearchV5RoutedRunLookup): Promise<void> {
  const totals = new Map(lookup.manifest.fields.map((field) => [field.name, 0]));
  const populated = new Map(lookup.manifest.fields.map((field) => [field.name, 0]));
  let documentCount = 0;
  let storedValueCount = 0;
  for await (const [_id, document] of lookup.streamDocuments()) {
    documentCount = addPostSearchV5Routed(documentCount, 1, 'document count');
    if (document.value !== undefined) {
      storedValueCount = addPostSearchV5Routed(
        storedValueCount,
        1,
        'stored value count',
      );
    }
    for (const field of lookup.manifest.fields) {
      const length = document.lengths[field.name]!;
      totals.set(
        field.name,
        addPostSearchV5Routed(totals.get(field.name) ?? 0, length, 'field total'),
      );
      if (length > 0) {
        populated.set(
          field.name,
          addPostSearchV5Routed(
            populated.get(field.name) ?? 0,
            1,
            'field populated count',
          ),
        );
      }
    }
  }
  if (documentCount !== lookup.manifest.documentCount
    || storedValueCount !== lookup.manifest.storedValueCount
    || lookup.manifest.fields.some((field) => field.totalLength !== totals.get(field.name)
      || field.populatedDocumentCount !== populated.get(field.name))) {
    throw new Error('Post-search v5 routed document coverage mismatch');
  }
}

async function verifyTermsAndPostings(
  lookup: PostSearchV5RoutedRunLookup,
  store: Store,
  postingRoot: CID | null,
): Promise<void> {
  if (lookup.manifest.termCount === 0) {
    return;
  }
  if (!postingRoot) {
    throw new Error('Post-search v5 routed run posting root is missing');
  }
  const postingRouter = await openPostSearchV5PageRouter(
    store,
    postingRoot,
    lookup.manifest.branches.postings!,
  );
  const postingEntries = streamPostSearchV5RoutedBranchEntries(postingRouter);
  const postingIterator = postingEntries[Symbol.asyncIterator]();
  let postingEntry = await postingIterator.next();
  let termCount = 0;
  let postingCount = 0;
  let postingPartCount = 0;
  let tokenOccurrenceCount = 0;
  const documentLengths = new Map<string, Readonly<Record<string, number>>>();
  for await (const [term, declared] of lookup.streamTerms()) {
    termCount = addPostSearchV5Routed(termCount, 1, 'term count');
    const aggregate: PostSearchV5CurrentTermBuild = {
      term,
      partCount: 0,
      postingCount: 0,
      previousPostingId: null,
      fieldSets: new Map(),
    };
    while (!postingEntry.done) {
      const [key, raw] = postingEntry.value;
      const parsedKey = parsePostSearchV5RoutedPostingKey(key);
      if (comparePostSearchV5RoutedText(parsedKey.term, term) < 0) {
        throw new Error(`Post-search v5 routed postings have no term record: ${parsedKey.term}`);
      }
      if (parsedKey.term !== term) {
        break;
      }
      if (parsedKey.part !== aggregate.partCount) {
        throw new Error(`Post-search v5 routed posting parts are not contiguous: ${term}`);
      }
      const records = parsePostSearchV5RoutedPostingPart(raw, key, lookup.manifest);
      for (const posting of records) {
        if (aggregate.previousPostingId !== null
          && comparePostSearchV5RoutedText(aggregate.previousPostingId, posting.id) >= 0) {
          throw new Error(`Post-search v5 routed postings are duplicate or out of order: ${term}`);
        }
        aggregate.previousPostingId = posting.id;
        const lengths = await verifiedPostingDocumentLengths(
          lookup,
          posting.id,
          documentLengths,
        );
        for (const [field, record] of Object.entries(posting.fields)) {
          if (record.positions.some((position) => position >= lengths[field]!)) {
            throw new Error(`Out-of-range post-search v5 routed posting position: ${key}`);
          }
        }
        aggregate.postingCount = addPostSearchV5Routed(
          aggregate.postingCount,
          1,
          'term posting count',
        );
        postingCount = addPostSearchV5Routed(postingCount, 1, 'posting count');
        const fields = Object.keys(posting.fields);
        const fieldSetKey = JSON.stringify(fields);
        const fieldSet = aggregate.fieldSets.get(fieldSetKey)
          ?? { fields, documentFrequency: 0 };
        fieldSet.documentFrequency = addPostSearchV5Routed(
          fieldSet.documentFrequency,
          1,
          'field-set frequency',
        );
        aggregate.fieldSets.set(fieldSetKey, fieldSet);
        tokenOccurrenceCount = addPostSearchV5Routed(
          tokenOccurrenceCount,
          Object.values(posting.fields).reduce(
            (sum, field) => addPostSearchV5Routed(sum, field.frequency, 'token count'),
            0,
          ),
          'token occurrence count',
        );
      }
      aggregate.partCount = addPostSearchV5Routed(
        aggregate.partCount,
        1,
        'term posting part count',
      );
      postingPartCount = addPostSearchV5Routed(
        postingPartCount,
        1,
        'posting part count',
      );
      postingEntry = await postingIterator.next();
    }
    if (aggregate.partCount === 0
      || JSON.stringify(postSearchV5RoutedTermStats(aggregate)) !== JSON.stringify(declared)) {
      throw new Error(`Post-search v5 routed term statistics mismatch: ${term}`);
    }
  }
  if (!postingEntry.done
    || termCount !== lookup.manifest.termCount
    || postingCount !== lookup.manifest.postingCount
    || postingPartCount !== lookup.manifest.postingPartCount
    || tokenOccurrenceCount !== lookup.manifest.tokenOccurrenceCount) {
    throw new Error('Post-search v5 routed term or posting coverage mismatch');
  }
}

async function verifiedPostingDocumentLengths(
  lookup: PostSearchV5RoutedRunLookup,
  id: string,
  cache: Map<string, Readonly<Record<string, number>>>,
): Promise<Readonly<Record<string, number>>> {
  const cached = cache.get(id);
  if (cached) {
    cache.delete(id);
    cache.set(id, cached);
    return cached;
  }
  const document = await lookup.getDocument(id);
  if (!document) {
    throw new Error(`Invalid post-search v5 routed posting document: ${id}`);
  }
  const lengths = { ...document.lengths };
  cache.set(id, lengths);
  while (cache.size > VERIFY_DOCUMENT_LENGTH_CACHE_ENTRIES) {
    const oldest = cache.keys().next().value;
    if (oldest === undefined) {
      break;
    }
    cache.delete(oldest);
  }
  return lengths;
}
