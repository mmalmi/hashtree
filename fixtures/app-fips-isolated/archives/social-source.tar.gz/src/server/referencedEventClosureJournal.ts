import { mkdir, open, readFile, truncate } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import type {
  ReferencedEventClosureJournal,
  ReferencedEventClosureJournalEntry,
} from './referencedEventClosureTypes';

/** Append-only fsynced state. A torn final record is discarded before resume. */
export class FileReferencedEventClosureJournal implements ReferencedEventClosureJournal {
  private readonly path: string;
  private loaded = false;

  constructor(path: string) {
    this.path = resolve(path);
  }

  async load(): Promise<unknown[]> {
    let bytes: Buffer;
    try {
      bytes = await readFile(this.path);
    } catch (error) {
      if (isErrno(error, 'ENOENT')) {
        this.loaded = true;
        return [];
      }
      throw error;
    }
    let text = bytes.toString('utf8');
    if (text && !text.endsWith('\n')) {
      const boundary = text.lastIndexOf('\n');
      const retainedBytes = boundary < 0 ? 0 : Buffer.byteLength(text.slice(0, boundary + 1));
      await truncate(this.path, retainedBytes);
      text = boundary < 0 ? '' : text.slice(0, boundary + 1);
      await syncFile(this.path);
    }
    this.loaded = true;
    return text.split('\n').filter(Boolean).map((line) => {
      try {
        return JSON.parse(line) as unknown;
      } catch {
        throw new Error('Referenced-event closure journal contains invalid JSON');
      }
    });
  }

  async append(entry: ReferencedEventClosureJournalEntry): Promise<void> {
    if (!this.loaded) {
      throw new Error('Referenced-event closure journal must be loaded before append');
    }
    const directory = dirname(this.path);
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const file = await open(this.path, 'a', 0o600);
    try {
      await file.writeFile(`${JSON.stringify(entry)}\n`);
      await file.sync();
    } finally {
      await file.close();
    }
  }
}

async function syncFile(path: string): Promise<void> {
  const file = await open(path, 'r');
  try {
    await file.sync();
  } finally {
    await file.close();
  }
}

function isErrno(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code;
}
