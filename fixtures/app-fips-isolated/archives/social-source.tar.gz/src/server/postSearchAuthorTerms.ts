import type { CID } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import {
  isPostSearchAddressDeleted,
  isPostSearchExactDeleted,
  type PostSearchDeletionProjection,
  type PostSearchEventVerifier,
  type PostSearchSnapshotReader,
} from './postSearchProjection';

const textEncoder = new TextEncoder();
const AUTHOR_TERM_RESOLVE_CONCURRENCY = 8;
// A production archive currently spans tens of thousands of social-graph
// authors. Keep their tiny normalized identity projections resident for the
// lifetime of one build so every segment does not repeat random profile-index
// reads through the Hashtree daemon.
const AUTHOR_TERM_CACHE_ENTRIES = 65_536;

export const POST_SEARCH_AUTHOR_METADATA_MAX_BYTES = 64 * 1_024;
export const POST_SEARCH_AUTHOR_TERM_MAX_BYTES = 256;
export const POST_SEARCH_AUTHOR_TERMS_MAX_BYTES = 768;
export const POST_SEARCH_AUTHOR_DELETION_POLICY = 'kind0-exact-and-coordinate-deletions@1' as const;

export class PostSearchAuthorTermsResolver {
  private readonly cache = new Map<string, readonly string[]>();

  constructor(private readonly options: {
    snapshotRoot: CID;
    snapshotReader: PostSearchSnapshotReader;
    verifyEvent: PostSearchEventVerifier;
  }) {
    if (!options.snapshotReader.getReplaceable && !options.snapshotReader.getReplaceables) {
      throw new Error('Post-search v2 requires same-snapshot replaceable profile lookup');
    }
  }

  async resolve(
    events: readonly RawEvent[],
    deletions: PostSearchDeletionProjection,
  ): Promise<Record<string, readonly string[]>> {
    const pubkeys = [...new Set(events.map((event) => event.pubkey))];
    const uncached = pubkeys.filter((pubkey) => !this.cache.has(pubkey));
    if (uncached.length > 0 && this.options.snapshotReader.getReplaceables) {
      const profiles = await this.options.snapshotReader.getReplaceables(
        this.options.snapshotRoot,
        uncached,
        0,
      );
      for (const pubkey of uncached) {
        this.remember(pubkey, this.project(pubkey, profiles.get(pubkey) ?? null, deletions));
      }
    } else if (uncached.length > 0) {
      let cursor = 0;
      const run = async (): Promise<void> => {
        while (cursor < uncached.length) {
          const pubkey = uncached[cursor++];
          await this.resolveOne(pubkey, deletions);
        }
      };
      await Promise.all(Array.from(
        { length: Math.min(AUTHOR_TERM_RESOLVE_CONCURRENCY, uncached.length) },
        run,
      ));
    }

    const authorNames: Record<string, readonly string[]> = {};
    for (const pubkey of pubkeys) {
      const terms = this.cache.get(pubkey) ?? [];
      this.remember(pubkey, terms);
      if (terms.length > 0) {
        authorNames[pubkey] = terms;
      }
    }
    return authorNames;
  }

  private async resolveOne(
    pubkey: string,
    deletions: PostSearchDeletionProjection,
  ): Promise<readonly string[]> {
    const cached = this.cache.get(pubkey);
    if (cached) {
      this.cache.delete(pubkey);
      this.cache.set(pubkey, cached);
      return cached;
    }

    const event = await this.options.snapshotReader.getReplaceable!(
      this.options.snapshotRoot,
      pubkey,
      0,
    );
    const terms = this.project(pubkey, event, deletions);
    this.remember(pubkey, terms);
    return terms;
  }

  private project(
    pubkey: string,
    event: RawEvent | null,
    deletions: PostSearchDeletionProjection,
  ): readonly string[] {
    return event
      && event.kind === 0
      && event.pubkey === pubkey
      && this.options.verifyEvent(event)
      && !isPostSearchExactDeleted(event, deletions)
      && !isPostSearchAddressDeleted(event, deletions)
      ? parseAuthorTerms(event.content)
      : [];
  }

  private remember(pubkey: string, terms: readonly string[]): void {
    this.cache.delete(pubkey);
    this.cache.set(pubkey, terms);
    while (this.cache.size > AUTHOR_TERM_CACHE_ENTRIES) {
      const oldest = this.cache.keys().next().value;
      if (oldest === undefined) {
        break;
      }
      this.cache.delete(oldest);
    }
  }
}

export function parseAuthorTerms(content: string): readonly string[] {
  if (textEncoder.encode(content).byteLength > POST_SEARCH_AUTHOR_METADATA_MAX_BYTES) {
    return [];
  }
  let value: unknown;
  try {
    value = JSON.parse(content);
  } catch {
    return [];
  }
  if (!isObject(value) || Array.isArray(value)) {
    return [];
  }

  const terms: string[] = [];
  const seen = new Set<string>();
  let totalBytes = 0;
  for (const field of ['name', 'display_name', 'nip05']) {
    const raw = value[field];
    if (typeof raw !== 'string') {
      continue;
    }
    const term = raw.normalize('NFKC').replace(/\s+/gu, ' ').trim();
    const bytes = textEncoder.encode(term).byteLength;
    const dedupeKey = term.toLowerCase();
    if (
      !term
      || bytes > POST_SEARCH_AUTHOR_TERM_MAX_BYTES
      || totalBytes + bytes > POST_SEARCH_AUTHOR_TERMS_MAX_BYTES
      || seen.has(dedupeKey)
    ) {
      continue;
    }
    seen.add(dedupeKey);
    terms.push(term);
    totalBytes += bytes;
  }
  return terms;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
