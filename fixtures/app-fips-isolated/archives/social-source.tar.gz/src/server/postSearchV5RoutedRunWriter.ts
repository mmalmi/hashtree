import { HashTree, LinkType, sha256, type Store, type TreeEntry } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import {
  createPostSearchV5PackedBranchWriter,
  type PostSearchV5PackedBranchWriter,
} from './postSearchV5PackedBranch';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import {
  POST_SEARCH_V5_MAX_TOKENS_PER_FIELD,
  type PostSearchV5Posting,
  type PostSearchV5StoredDocument,
  type PostSearchV5TermStats,
} from './postSearchV5Run';
import {
  encodePostSearchV5RoutedRunManifest,
  postSearchV5RoutedBranchEntry,
  postSearchV5RoutedBranchManifest,
  validatePostSearchV5RoutedFields,
} from './postSearchV5RoutedRunManifest';
import {
  normalizePostSearchV5RoutedDocument,
  normalizePostSearchV5RoutedPosting,
  normalizePostSearchV5RoutedTermStats,
  postSearchV5PostingKey,
  postSearchV5RoutedPostingTerm,
  postSearchV5RoutedTermStats,
} from './postSearchV5RoutedRunRecords';
import {
  POST_SEARCH_V5_ROUTED_NORMALIZATION,
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  type PostSearchV5CurrentTermBuild,
  type PostSearchV5RoutedRunBuild,
  type PostSearchV5RoutedRunFinishInput,
  type PostSearchV5RoutedRunManifest,
  type PostSearchV5RoutedRunWriter,
  type PostSearchV5RoutedWriterFieldState,
} from './postSearchV5RoutedRunTypes';
import {
  addPostSearchV5Routed,
  comparePostSearchV5RoutedText,
  isPostSearchV5RoutedRecord,
  postSearchV5RoutedNonNegativeInteger,
  postSearchV5RoutedPositiveInteger,
  postSearchV5RoutedPositiveNumber,
  samePostSearchV5RoutedNumbers,
  samePostSearchV5RoutedStrings,
} from './postSearchV5RoutedRunValidation';

const MANIFEST_ENTRY = 'manifest.json';
type RunWriterStatus = 'idle' | 'appending' | 'finishing' | 'finished' | 'failed';

class BoundedRoutedRunWriter implements PostSearchV5RoutedRunWriter {
  private readonly documents: PostSearchV5PackedBranchWriter;
  private readonly postings: PostSearchV5PackedBranchWriter;
  private readonly terms: PostSearchV5PackedBranchWriter;
  private readonly documentTotals = new Map<string, number>();
  private readonly documentPopulated = new Map<string, number>();
  private readonly postingFieldNames = new Set<string>();
  private documentFields: string[] | null = null;
  private maximumDocumentLengths = new Map<string, number>();
  private maximumPostingPositions = new Map<string, number>();
  private currentTerm: PostSearchV5CurrentTermBuild | null = null;
  private documentCount = 0;
  private termCount = 0;
  private postingCount = 0;
  private storedValueCount = 0;
  private tokenOccurrenceCount = 0;
  private status: RunWriterStatus = 'idle';

  constructor(private readonly store: Store) {
    this.documents = createPostSearchV5PackedBranchWriter(store, 'documents');
    this.postings = createPostSearchV5PackedBranchWriter(store, 'postings');
    this.terms = createPostSearchV5PackedBranchWriter(store, 'terms');
  }

  appendDocument(id: string, document: PostSearchV5StoredDocument): Promise<void> {
    return this.performAppend(async () => {
      if (this.postingCount > 0 || this.termCount > 0 || this.currentTerm) {
        throw new Error('Post-search v5 routed run documents must precede postings');
      }
      const normalized = normalizePostSearchV5RoutedDocument(id, document);
      await this.documents.append(id, normalized.raw);
      this.documentCount = addPostSearchV5Routed(this.documentCount, 1, 'document count');
      if (normalized.document.value !== undefined) {
        this.storedValueCount = addPostSearchV5Routed(
          this.storedValueCount,
          1,
          'stored value count',
        );
      }
      const fields = Object.keys(normalized.document.lengths);
      if (this.documentFields
        && !samePostSearchV5RoutedStrings(this.documentFields, fields)) {
        throw new Error('Post-search v5 routed run documents have inconsistent fields');
      }
      this.documentFields ??= fields;
      for (const field of fields) {
        const length = normalized.document.lengths[field]!;
        this.documentTotals.set(field, addPostSearchV5Routed(
          this.documentTotals.get(field) ?? 0,
          length,
          `field ${field} total`,
        ));
        if (length > 0) {
          this.documentPopulated.set(field, addPostSearchV5Routed(
            this.documentPopulated.get(field) ?? 0,
            1,
            `field ${field} populated count`,
          ));
        }
        this.maximumDocumentLengths.set(
          field,
          Math.max(this.maximumDocumentLengths.get(field) ?? 0, length),
        );
      }
    });
  }

  appendPosting(
    term: string,
    part: number,
    postings: readonly PostSearchV5Posting[],
  ): Promise<void> {
    return this.performAppend(async () => {
      if (!this.documentFields) {
        throw new Error('Post-search v5 routed run requires documents before postings');
      }
      const normalizedTerm = postSearchV5RoutedPostingTerm(term);
      const current = this.preparePostingPart(normalizedTerm, part);
      if (!Array.isArray(postings) || postings.length === 0) {
        throw new Error('Post-search v5 routed posting parts require at least one posting');
      }
      const normalized = postings.map((posting, index) =>
        normalizePostSearchV5RoutedPosting(
          posting,
          `${normalizedTerm} part ${part} posting ${index}`,
        ));
      let previousId = current.previousPostingId;
      for (const posting of normalized) {
        if (previousId !== null
          && comparePostSearchV5RoutedText(previousId, posting.posting.id) >= 0) {
          throw new Error(`Post-search v5 routed postings are duplicate or out of order: ${term}`);
        }
        previousId = posting.posting.id;
      }
      const raw = JSON.stringify(normalized.map((posting) => posting.posting));
      await this.postings.append(postSearchV5PostingKey(normalizedTerm, part), raw);
      this.currentTerm ??= current;
      this.currentTerm.partCount = addPostSearchV5Routed(
        this.currentTerm.partCount,
        1,
        'posting part count',
      );
      this.currentTerm.previousPostingId = previousId;
      for (const item of normalized) {
        this.currentTerm.postingCount = addPostSearchV5Routed(
          this.currentTerm.postingCount,
          1,
          'term posting count',
        );
        this.postingCount = addPostSearchV5Routed(this.postingCount, 1, 'posting count');
        const fields = Object.keys(item.posting.fields);
        if (fields.some((field) => !this.documentFields!.includes(field))) {
          throw new Error('Post-search v5 routed run posting fields do not match documents');
        }
        const fieldSetKey = JSON.stringify(fields);
        const fieldSet = this.currentTerm.fieldSets.get(fieldSetKey)
          ?? { fields, documentFrequency: 0 };
        fieldSet.documentFrequency = addPostSearchV5Routed(
          fieldSet.documentFrequency,
          1,
          'field-set frequency',
        );
        this.currentTerm.fieldSets.set(fieldSetKey, fieldSet);
        for (const field of fields) {
          this.postingFieldNames.add(field);
          const record = item.posting.fields[field]!;
          this.tokenOccurrenceCount = addPostSearchV5Routed(
            this.tokenOccurrenceCount,
            record.frequency,
            'token occurrence count',
          );
          this.maximumPostingPositions.set(
            field,
            Math.max(
              this.maximumPostingPositions.get(field) ?? 0,
              record.positions.at(-1) ?? 0,
            ),
          );
        }
      }
    });
  }

  appendTerm(term: string, stats: PostSearchV5TermStats): Promise<void> {
    return this.performAppend(async () => {
      const normalizedTerm = postSearchV5RoutedPostingTerm(term);
      const current = this.currentTerm;
      if (!current || current.term !== normalizedTerm) {
        throw new Error(`Post-search v5 routed term has no matching posting group: ${term}`);
      }
      const actual = postSearchV5RoutedTermStats(current);
      const normalized = normalizePostSearchV5RoutedTermStats(stats);
      if (JSON.stringify(normalized) !== JSON.stringify(actual)) {
        throw new Error(`Post-search v5 routed term statistics mismatch: ${term}`);
      }
      await this.terms.append(normalizedTerm, JSON.stringify(normalized));
      this.termCount = addPostSearchV5Routed(this.termCount, 1, 'term count');
      this.currentTerm = null;
    });
  }

  finish(input: PostSearchV5RoutedRunFinishInput): Promise<PostSearchV5RoutedRunBuild> {
    const stateError = this.operationError('finish');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'finishing';
    return this.finishOnce(input).then(
      (result) => {
        this.status = 'finished';
        return result;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private performAppend<T>(operation: () => Promise<T>): Promise<T> {
    const stateError = this.operationError('append');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'appending';
    return operation().then(
      (result) => {
        this.status = 'idle';
        return result;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private preparePostingPart(term: string, part: number): PostSearchV5CurrentTermBuild {
    postSearchV5RoutedNonNegativeInteger(part, 'posting part');
    if (part > Number.MAX_SAFE_INTEGER || postSearchV5PostingKey(term, part).length === 0) {
      throw new Error('Invalid post-search v5 posting part');
    }
    if (!this.currentTerm) {
      if (part !== 0) {
        throw new Error(`Post-search v5 routed posting parts are not contiguous: ${term}`);
      }
      return {
        term,
        partCount: 0,
        postingCount: 0,
        previousPostingId: null,
        fieldSets: new Map(),
      };
    }
    if (this.currentTerm.term !== term || part !== this.currentTerm.partCount) {
      throw new Error(`Post-search v5 routed posting parts are not contiguous: ${term}`);
    }
    return this.currentTerm;
  }

  private async finishOnce(
    input: PostSearchV5RoutedRunFinishInput,
  ): Promise<PostSearchV5RoutedRunBuild> {
    if (this.currentTerm) {
      throw new Error(`Post-search v5 routed posting group has no term record: ${this.currentTerm.term}`);
    }
    const fields = validateFinish(input, this);
    const [documents, postings, terms] = await Promise.all([
      this.documents.finish(),
      this.postings.finish(),
      this.terms.finish(),
    ]);
    if (!documents) {
      throw new Error('Post-search v5 routed run requires documents');
    }
    if ((postings === null) !== (terms === null)) {
      throw new Error('Post-search v5 routed postings and terms must both be present or absent');
    }
    const branches = {
      documents: postSearchV5RoutedBranchManifest(documents),
      postings: postings ? postSearchV5RoutedBranchManifest(postings) : null,
      terms: terms ? postSearchV5RoutedBranchManifest(terms) : null,
    };
    const reachableNodeCount = addPostSearchV5Routed(
      2,
      addPostSearchV5Routed(
        documents.reachableNodeCount,
        addPostSearchV5Routed(
          postings?.reachableNodeCount ?? 0,
          terms?.reachableNodeCount ?? 0,
          'branch reachable count',
        ),
        'branch reachable count',
      ),
      'run reachable count',
    );
    const maximum = input.maxReachableNodeCount === undefined
      ? Number.MAX_SAFE_INTEGER
      : postSearchV5RoutedPositiveInteger(
          input.maxReachableNodeCount,
          'maxReachableNodeCount',
        );
    if (reachableNodeCount > maximum) {
      throw new Error('Post-search v5 routed run exceeds its reachable-node capacity');
    }
    const manifest: PostSearchV5RoutedRunManifest = {
      format: POST_SEARCH_V5_ROUTED_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
      normalization: POST_SEARCH_V5_ROUTED_NORMALIZATION,
      documentCount: this.documentCount,
      termCount: this.termCount,
      postingCount: this.postingCount,
      postingPartCount: postings?.entryCount ?? 0,
      storedValueCount: this.storedValueCount,
      tokenOccurrenceCount: this.tokenOccurrenceCount,
      k1: input.k1,
      maxTokensPerField: input.maxTokensPerField,
      fields,
      branches,
      reachableNodeCount,
    };
    const manifestBytes = encodePostSearchV5RoutedRunManifest(manifest);
    const manifestHash = await sha256(manifestBytes);
    await this.store.put(manifestHash, manifestBytes);
    const tree = new HashTree({ store: this.store });
    const entries: TreeEntry[] = [
      postSearchV5RoutedBranchEntry('documents', documents),
      {
        name: MANIFEST_ENTRY,
        cid: { hash: manifestHash },
        size: manifestBytes.length,
        type: LinkType.Blob,
      },
    ];
    if (postings && terms) {
      entries.push(
        postSearchV5RoutedBranchEntry('postings', postings),
        postSearchV5RoutedBranchEntry('terms', terms),
      );
    }
    const root = (await tree.putDirectory(entries, { unencrypted: true })).cid;
    return { root, manifest };
  }

  private operationError(operation: 'append' | 'finish'): Error | null {
    if (this.status === 'failed') {
      return new Error('Post-search v5 routed run writer has failed');
    }
    if (this.status === 'finished' || this.status === 'finishing') {
      return operation === 'finish'
        ? new Error('Post-search v5 routed run writer finish may only be called once')
        : new Error('Post-search v5 routed run writer cannot append after finish');
    }
    if (this.status !== 'idle') {
      return new Error(`Post-search v5 routed run writer cannot ${operation} while another operation is in progress`);
    }
    return null;
  }

  fieldState(): PostSearchV5RoutedWriterFieldState {
    return {
      documentFields: this.documentFields,
      totals: this.documentTotals,
      populated: this.documentPopulated,
      postingFields: this.postingFieldNames,
      maxLengths: this.maximumDocumentLengths,
      maxPositions: this.maximumPostingPositions,
    };
  }

  counters(): readonly number[] {
    return [
      this.documentCount,
      this.termCount,
      this.postingCount,
      this.storedValueCount,
      this.tokenOccurrenceCount,
    ];
  }
}

function validateFinish(
  input: PostSearchV5RoutedRunFinishInput,
  writer: BoundedRoutedRunWriter,
): RankedSearchFieldManifest[] {
  if (!isPostSearchV5RoutedRecord(input)) {
    throw new Error('Invalid post-search v5 routed run finish input');
  }
  const declared = [
    postSearchV5RoutedPositiveInteger(input.documentCount, 'documentCount'),
    postSearchV5RoutedNonNegativeInteger(input.termCount, 'termCount'),
    postSearchV5RoutedNonNegativeInteger(input.postingCount, 'postingCount'),
    postSearchV5RoutedNonNegativeInteger(input.storedValueCount, 'storedValueCount'),
    postSearchV5RoutedNonNegativeInteger(input.tokenOccurrenceCount, 'tokenOccurrenceCount'),
  ];
  if (!samePostSearchV5RoutedNumbers(declared, writer.counters())) {
    throw new Error('Post-search v5 routed run declared counters do not match appended records');
  }
  postSearchV5RoutedPositiveNumber(input.k1, 'k1');
  const maxTokens = postSearchV5RoutedPositiveInteger(
    input.maxTokensPerField,
    'maxTokensPerField',
  );
  if (maxTokens > POST_SEARCH_V5_MAX_TOKENS_PER_FIELD) {
    throw new Error('Post-search v5 routed run maxTokensPerField exceeds its bound');
  }
  const fields = validatePostSearchV5RoutedFields(input.fields, input.documentCount);
  const state = writer.fieldState();
  const names = fields.map((field) => field.name);
  if (!state.documentFields || !samePostSearchV5RoutedStrings(names, state.documentFields)
    || [...state.postingFields].some((field) => !names.includes(field))) {
    throw new Error('Post-search v5 routed run fields do not match appended records');
  }
  for (const field of fields) {
    if (field.totalLength !== (state.totals.get(field.name) ?? 0)
      || field.populatedDocumentCount !== (state.populated.get(field.name) ?? 0)
      || (state.maxLengths.get(field.name) ?? 0) > maxTokens
      || (state.maxPositions.get(field.name) ?? 0) >= maxTokens) {
      throw new Error(`Post-search v5 routed run field totals or bounds mismatch: ${field.name}`);
    }
  }
  return fields;
}

export function createPostSearchV5RoutedRunWriter(
  store: Store,
): PostSearchV5RoutedRunWriter {
  return new BoundedRoutedRunWriter(store);
}
