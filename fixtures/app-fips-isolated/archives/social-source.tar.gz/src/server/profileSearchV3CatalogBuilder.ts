import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
import {
  nhashDecode,
  nhashEncode,
  type CID,
  type Store,
} from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import {
  PROFILE_SEARCH_V3_CATALOG_FORMAT,
  PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY,
  readProfileSearchV3Catalog,
  writeProfileSearchV3Catalog,
  type ProfileSearchV3CatalogLookup,
  type ProfileSearchV3CatalogRunInput,
} from './profileSearchV3Catalog';
import {
  isPostSearchAddressDeleted,
  isPostSearchExactDeleted,
  scanPostSearchDeletions,
  verifyPostSearchEvent,
  type PostSearchEventVerifier,
  type PostSearchSnapshotReader,
} from './postSearchProjection';
import {
  PROFILE_SEARCH_V3_NORMALIZATION,
  PROFILE_SEARCH_V3_RANK_POLICY,
  PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
  createProfileSearchV3RoutedRunWriter,
  profileSearchV3PostingsForEvent,
  readProfileSearchV3RoutedRun,
  type ProfileSearchV3Posting,
} from './profileSearchV3RoutedRun';
import {
  PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT,
  type ProfileSearchV3CatalogBuilderState,
  type ProfileSearchV3CatalogBuilderStateStore,
  type ProfileSearchV3CompletedPartition,
} from './profileSearchV3CatalogBuilderState';
import { ProfilePartitionWorkspace } from './profileSearchV3PartitionWorkspace';

export const PROFILE_SEARCH_V3_RANK_DECISION_FORMAT =
  'iris-social/profile-search-v3-rank-decisions@1' as const;
export const PROFILE_SEARCH_V3_PARTITION_COUNT = 16;

const DEFAULT_SORT_CHUNK_POSTINGS = 32_768;
const DEFAULT_PROFILE_BUFFER_ENTRIES = 1_024;
const DEFAULT_PROFILE_BUFFER_BYTES = 1_048_576;
const DEFAULT_SORT_MERGE_FAN_IN = 32;
const NIBBLES = [...'0123456789abcdef'];
const HEX_64 = /^[0-9a-f]{64}$/;

/** Null is an explicit graph-policy exclusion; missing authors are also ineligible. */
export type ProfileSearchV3RankDecisions = ReadonlyMap<string, number | null>;

export interface ProfileSearchV3CurrentStateReader extends PostSearchSnapshotReader {
  streamCurrentState(
    root: CID,
    kind: 0,
  ): AsyncIterable<{ coordinate: string; event: RawEvent }>;
}

export interface ProfileSearchV3CatalogBuilderOptions {
  snapshotRoot: CID;
  snapshotReader: ProfileSearchV3CurrentStateReader;
  outputStore: Store;
  stateStore: ProfileSearchV3CatalogBuilderStateStore;
  rankDecisions: ProfileSearchV3RankDecisions;
  /** Isolated scratch space. It is rebuilt, not trusted as durable state. */
  workspaceDirectory: string;
  generatedAt?: number;
  sortChunkPostings?: number;
  profileBufferEntries?: number;
  /** Per-partition buffered JSON bytes; all 16 buffers remain independently bounded. */
  profileBufferBytes?: number;
  sortMergeFanIn?: number;
  verifyEvent?: PostSearchEventVerifier;
  /** Required when injecting a non-default verifier so restart state binds its semantics. */
  verificationPolicy?: string;
}

export interface ProfileSearchV3CatalogBuilderResult {
  catalog: ProfileSearchV3CatalogLookup;
  state: ProfileSearchV3CatalogBuilderState;
  resumed: boolean;
}

interface PendingWinner {
  coordinate: string;
  event: RawEvent;
}

export class ProfileSearchV3CatalogBuilder {
  private readonly sourceRoot: string;
  private readonly eligibleRanksSha256: string;
  private readonly configurationSha256: string;
  private readonly eligibleRanks: ReadonlyMap<string, number>;
  private readonly generatedAt: number;
  private readonly sortChunkPostings: number;
  private readonly profileBufferEntries: number;
  private readonly profileBufferBytes: number;
  private readonly sortMergeFanIn: number;
  private readonly verifyEvent: PostSearchEventVerifier;
  private readonly workspaceDirectory: string;
  private readonly requestedGeneratedAt: number | null;

  constructor(private readonly options: ProfileSearchV3CatalogBuilderOptions) {
    if (options.snapshotRoot.key !== undefined) {
      throw new Error('Profile-search v3 source snapshot must be public');
    }
    this.sourceRoot = nhashEncode(options.snapshotRoot);
    this.eligibleRanks = eligibleRanks(options.rankDecisions);
    this.eligibleRanksSha256 = profileSearchV3RankDecisionsSha256(options.rankDecisions);
    this.requestedGeneratedAt = options.generatedAt ?? null;
    this.generatedAt = nonNegativeInteger(
      options.generatedAt ?? Math.floor(Date.now() / 1_000),
      'generatedAt',
    );
    this.sortChunkPostings = positiveInteger(
      options.sortChunkPostings ?? DEFAULT_SORT_CHUNK_POSTINGS,
      'sortChunkPostings',
    );
    this.profileBufferEntries = positiveInteger(
      options.profileBufferEntries ?? DEFAULT_PROFILE_BUFFER_ENTRIES,
      'profileBufferEntries',
    );
    this.profileBufferBytes = positiveInteger(
      options.profileBufferBytes ?? DEFAULT_PROFILE_BUFFER_BYTES,
      'profileBufferBytes',
    );
    this.sortMergeFanIn = boundedInteger(
      options.sortMergeFanIn ?? DEFAULT_SORT_MERGE_FAN_IN,
      2,
      128,
      'sortMergeFanIn',
    );
    this.verifyEvent = options.verifyEvent ?? verifyPostSearchEvent;
    const verificationPolicy = options.verifyEvent
      ? requiredPolicy(options.verificationPolicy, 'verificationPolicy')
      : 'nostr-tools-verify-event@1';
    this.workspaceDirectory = join(
      resolve(options.workspaceDirectory),
      '.iris-social-profile-search-v3-scratch',
    );
    this.configurationSha256 = digest(JSON.stringify({
      stateFormat: PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT,
      rankDecisionFormat: PROFILE_SEARCH_V3_RANK_DECISION_FORMAT,
      runFormat: PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
      catalogFormat: PROFILE_SEARCH_V3_CATALOG_FORMAT,
      normalization: PROFILE_SEARCH_V3_NORMALIZATION,
      rankPolicy: PROFILE_SEARCH_V3_RANK_POLICY,
      winnerPolicy: 'created-at-desc-event-id-asc@1',
      deletionPolicy: 'verified-author-bound-kind-5@1',
      visibilityPolicy: 'newest-unprojectable-suppresses-older@1',
      partitionPolicy: PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY,
      verificationPolicy,
      sortPolicy: 'bounded-external-jsonl-merge@1',
      sortChunkPostings: this.sortChunkPostings,
      profileBufferEntries: this.profileBufferEntries,
      profileBufferBytes: this.profileBufferBytes,
      sortMergeFanIn: this.sortMergeFanIn,
    }));
  }

  async build(): Promise<ProfileSearchV3CatalogBuilderResult> {
    await this.options.snapshotReader.validateSnapshot?.(this.options.snapshotRoot);
    const loaded = await this.options.stateStore.load();
    const reusable = loaded !== null && this.matchesBuild(loaded);
    if (loaded && !reusable) {
      throw new Error('Profile-search v3 builder state belongs to another source or configuration');
    }
    const state = reusable ? loaded : this.initialState();
    if (!reusable) {await this.options.stateStore.save(state);}
    if (state.status === 'building'
      && state.completedPartitions.some((partition) => partition.root === null)) {
      // A non-empty run proves its own contents. An empty marker has no DAG proof,
      // so interrupted builds rescan that partition instead of trusting local JSON.
      state.completedPartitions = state.completedPartitions.filter(
        (partition) => partition.root !== null,
      );
      await this.options.stateStore.save(state);
    }
    await this.verifyCompletedPartitions(state);
    if (state.status === 'complete') {
      const catalog = await readProfileSearchV3Catalog(
        this.options.outputStore,
        nhashDecode(state.catalogRoot!),
        {
          expectedSourceRoot: this.options.snapshotRoot,
          expectedEligibleRanksSha256: this.eligibleRanksSha256,
        },
      );
      this.assertCatalogCoversState(catalog, state);
      return { catalog, state, resumed: true };
    }

    const completed = new Set(state.completedPartitions.map((partition) => partition.nibble));
    const workspace = new ProfilePartitionWorkspace(this.workspaceDirectory, {
      profileBufferEntries: this.profileBufferEntries,
      profileBufferBytes: this.profileBufferBytes,
      postingBufferEntries: this.sortChunkPostings,
      mergeFanIn: this.sortMergeFanIn,
    });
    await workspace.reset();
    try {
      const deletions = await scanPostSearchDeletions(
        this.options.snapshotReader,
        this.options.snapshotRoot,
        this.verifyEvent,
        undefined,
        (pubkey) => this.eligibleRanks.has(pubkey),
      );
      await this.stageCurrentProfiles(workspace, completed, deletions);
      await workspace.finishStaging();
      for (const nibble of NIBBLES) {
        if (completed.has(nibble)) {continue;}
        const partition = await this.buildPartition(workspace, nibble);
        state.completedPartitions.push(partition);
        state.completedPartitions.sort((left, right) => compareText(left.nibble, right.nibble));
        // The run was strictly read above; this durable save is the restart boundary.
        await this.options.stateStore.save(state);
      }

      const runs = await this.loadCatalogRuns(state);
      const catalog = await writeProfileSearchV3Catalog(this.options.outputStore, {
        generatedAt: state.generatedAt,
        sourceRoot: this.options.snapshotRoot,
        eligibleRanksSha256: this.eligibleRanksSha256,
        runs,
      });
      const verified = await readProfileSearchV3Catalog(
        this.options.outputStore,
        catalog.root,
        {
          expectedSourceRoot: this.options.snapshotRoot,
          expectedEligibleRanksSha256: this.eligibleRanksSha256,
        },
      );
      if (verified.manifest.runs.length !== runs.length) {
        throw new Error('Profile-search v3 catalog omitted a completed non-empty partition');
      }
      state.status = 'complete';
      state.catalogRoot = nhashEncode(verified.root);
      await this.options.stateStore.save(state);
      return { catalog: verified, state, resumed: reusable };
    } finally {
      await workspace.cleanup();
    }
  }

  private async stageCurrentProfiles(
    workspace: ProfilePartitionWorkspace,
    completed: ReadonlySet<string>,
    deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>>,
  ): Promise<void> {
    let pending: PendingWinner | null = null;
    for await (const entry of this.options.snapshotReader.streamCurrentState(
      this.options.snapshotRoot,
      0,
    )) {
      assertCurrentStateEntry(entry);
      if (pending && entry.coordinate < pending.coordinate) {
        throw new Error('Profile-search v3 current-state stream is not coordinate sorted');
      }
      if (!pending || entry.coordinate !== pending.coordinate) {
        if (pending) {await this.stageWinner(workspace, completed, deletions, pending.event);}
        pending = { coordinate: entry.coordinate, event: entry.event };
      } else if (isNewerReplaceable(entry.event, pending.event)) {
        pending = { coordinate: entry.coordinate, event: entry.event };
      }
    }
    if (pending) {await this.stageWinner(workspace, completed, deletions, pending.event);}
  }

  private async stageWinner(
    workspace: ProfilePartitionWorkspace,
    completed: ReadonlySet<string>,
    deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>>,
    event: RawEvent,
  ): Promise<void> {
    const nibble = event.pubkey[0]!;
    if (completed.has(nibble)) {return;}
    const rankHint = this.eligibleRanks.get(event.pubkey);
    if (rankHint === undefined
      || !this.verifyEvent(event)
      || isPostSearchExactDeleted(event, deletions)
      || isPostSearchAddressDeleted(event, deletions)) {
      return;
    }
    let postings: ProfileSearchV3Posting[];
    try {
      postings = profileSearchV3PostingsForEvent(event, rankHint);
    } catch {
      // Projection is intentionally after NIP-01 winner selection: no older identity resurrection.
      return;
    }
    await workspace.appendProfile(nibble, event);
    for (const posting of postings) {await workspace.appendPosting(nibble, posting);}
  }

  private async buildPartition(
    workspace: ProfilePartitionWorkspace,
    nibble: string,
  ): Promise<ProfileSearchV3CompletedPartition> {
    const profileCount = workspace.profileCount(nibble);
    if (profileCount === 0) {
      return { nibble, root: null, profileCount: 0, postingCount: 0, reachableNodeCount: 0 };
    }
    const writer = createProfileSearchV3RoutedRunWriter(
      this.options.outputStore,
      this.eligibleRanks,
    );
    let appendedProfiles = 0;
    let previousPubkey = '';
    for await (const event of workspace.streamProfiles(nibble)) {
      if (event.pubkey <= previousPubkey || event.pubkey[0] !== nibble) {
        throw new Error(`Profile-search v3 staged partition ${nibble} is not strictly sorted`);
      }
      previousPubkey = event.pubkey;
      if (!await writer.appendProfile(event)) {
        throw new Error('Profile-search v3 staged profile lost its eligibility decision');
      }
      appendedProfiles += 1;
    }
    if (appendedProfiles !== profileCount) {
      throw new Error(`Profile-search v3 staged partition ${nibble} profile count changed`);
    }
    let postingCount = 0;
    for await (const posting of workspace.streamSortedPostings(nibble)) {
      await writer.appendPosting(posting);
      postingCount += 1;
    }
    const built = await writer.finish();
    const verified = await readProfileSearchV3RoutedRun(this.options.outputStore, built.root, {
      expected: {
        profileCount,
        postingCount,
        reachableNodeCount: built.manifest.reachableNodeCount,
      },
    });
    if (verified.manifest.branches.profiles.minKey[0] !== nibble
      || verified.manifest.branches.profiles.maxKey[0] !== nibble) {
      throw new Error(`Profile-search v3 run escaped partition ${nibble}`);
    }
    return {
      nibble,
      root: nhashEncode(verified.root),
      profileCount,
      postingCount,
      reachableNodeCount: verified.manifest.reachableNodeCount,
    };
  }

  private async verifyCompletedPartitions(state: ProfileSearchV3CatalogBuilderState): Promise<void> {
    for (const partition of state.completedPartitions) {
      if (!partition.root) {continue;}
      const run = await readProfileSearchV3RoutedRun(
        this.options.outputStore,
        nhashDecode(partition.root),
        { expected: {
          profileCount: partition.profileCount,
          postingCount: partition.postingCount,
          reachableNodeCount: partition.reachableNodeCount,
        } },
      );
      if (run.manifest.branches.profiles.minKey[0] !== partition.nibble
        || run.manifest.branches.profiles.maxKey[0] !== partition.nibble) {
        throw new Error(`Profile-search v3 durable partition ${partition.nibble} is misrouted`);
      }
    }
  }

  private async loadCatalogRuns(
    state: ProfileSearchV3CatalogBuilderState,
  ): Promise<ProfileSearchV3CatalogRunInput[]> {
    if (state.completedPartitions.length !== PROFILE_SEARCH_V3_PARTITION_COUNT) {
      throw new Error('Profile-search v3 cannot publish before every partition is durable');
    }
    const runs: ProfileSearchV3CatalogRunInput[] = [];
    for (const partition of state.completedPartitions) {
      if (!partition.root) {continue;}
      const run = await readProfileSearchV3RoutedRun(
        this.options.outputStore,
        nhashDecode(partition.root),
        { expected: {
          profileCount: partition.profileCount,
          postingCount: partition.postingCount,
          reachableNodeCount: partition.reachableNodeCount,
        } },
      );
      runs.push({
        run,
        rangeStart: `${partition.nibble}${'0'.repeat(63)}`,
        rangeEnd: `${partition.nibble}${'f'.repeat(63)}`,
      });
    }
    if (runs.length === 0) {
      throw new Error('Profile-search v3 cannot publish an empty profile catalog');
    }
    return runs;
  }

  private assertCatalogCoversState(
    catalog: ProfileSearchV3CatalogLookup,
    state: ProfileSearchV3CatalogBuilderState,
  ): void {
    const nonEmpty = state.completedPartitions.filter((partition) => partition.root !== null);
    if (state.completedPartitions.length !== PROFILE_SEARCH_V3_PARTITION_COUNT
      || catalog.manifest.runs.length !== nonEmpty.length
      || nonEmpty.some((partition, index) =>
        catalog.manifest.runs[index]?.root !== partition.root)) {
      throw new Error('Profile-search v3 complete state is not covered by its catalog');
    }
  }

  private matchesBuild(state: ProfileSearchV3CatalogBuilderState): boolean {
    return state.configurationSha256 === this.configurationSha256
      && state.sourceRoot === this.sourceRoot
      && state.eligibleRanksSha256 === this.eligibleRanksSha256
      && (this.requestedGeneratedAt === null || state.generatedAt === this.requestedGeneratedAt);
  }

  private initialState(): ProfileSearchV3CatalogBuilderState {
    return {
      format: PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT,
      status: 'building',
      configurationSha256: this.configurationSha256,
      sourceRoot: this.sourceRoot,
      eligibleRanksSha256: this.eligibleRanksSha256,
      generatedAt: this.generatedAt,
      completedPartitions: [],
      catalogRoot: null,
    };
  }
}

/** Stable across Map insertion order and includes every explicit exclusion decision. */
export function profileSearchV3RankDecisionsSha256(
  decisions: ProfileSearchV3RankDecisions,
): string {
  validateRankDecisions(decisions);
  const hash = createHash('sha256');
  hash.update(`${PROFILE_SEARCH_V3_RANK_DECISION_FORMAT}\n`);
  for (const [pubkey, rank] of [...decisions].sort(([left], [right]) => compareText(left, right))) {
    hash.update(`${JSON.stringify(rank === null
      ? [pubkey, 'excluded', null]
      : [pubkey, 'eligible', rank])}\n`);
  }
  return hash.digest('hex');
}

function eligibleRanks(decisions: ProfileSearchV3RankDecisions): ReadonlyMap<string, number> {
  validateRankDecisions(decisions);
  return new Map([...decisions].filter(
    (entry): entry is [string, number] => entry[1] !== null,
  ));
}

function validateRankDecisions(decisions: ProfileSearchV3RankDecisions): void {
  if (!(decisions instanceof Map)) {
    throw new Error('Profile-search v3 rank decisions must be a map');
  }
  for (const [pubkey, rank] of decisions) {
    if (!HEX_64.test(pubkey)
      || (rank !== null && (!Number.isSafeInteger(rank) || rank < 0))) {
      throw new Error('Invalid profile-search v3 rank decision');
    }
  }
}

function requiredPolicy(value: unknown, label: string): string {
  if (typeof value !== 'string' || !/^[a-z0-9][a-z0-9._@/-]{0,127}$/.test(value)) {
    throw new Error(`Invalid profile-search v3 builder ${label}`);
  }
  return value;
}

function assertCurrentStateEntry(
  entry: { coordinate: string; event: RawEvent },
): void {
  if (!entry || typeof entry !== 'object'
    || !entry.event || typeof entry.event !== 'object'
    || entry.event.kind !== 0
    || !HEX_64.test(entry.event.pubkey)
    || entry.coordinate !== `0:${entry.event.pubkey}:`
    || !Number.isSafeInteger(entry.event.created_at)
    || entry.event.created_at < 0
    || !HEX_64.test(entry.event.id)) {
    throw new Error('Invalid profile-search v3 current-state entry');
  }
}

function isNewerReplaceable(candidate: RawEvent, existing: RawEvent): boolean {
  return candidate.created_at > existing.created_at
    || (candidate.created_at === existing.created_at && candidate.id < existing.id);
}

function digest(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function nonNegativeInteger(value: unknown, label: string): number {
  return boundedInteger(value, 0, Number.MAX_SAFE_INTEGER, label);
}

function positiveInteger(value: unknown, label: string): number {
  return boundedInteger(value, 1, Number.MAX_SAFE_INTEGER, label);
}

function boundedInteger(value: unknown, minimum: number, maximum: number, label: string): number {
  if (!Number.isSafeInteger(value) || Number(value) < minimum || Number(value) > maximum) {
    throw new Error(`Invalid profile-search v3 builder ${label}`);
  }
  return Number(value);
}
