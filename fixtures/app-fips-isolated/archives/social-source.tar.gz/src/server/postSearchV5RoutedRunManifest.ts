import { LinkType, type CID, type Link, type TreeEntry } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import {
  POST_SEARCH_V5_PACKED_PAGE_FORMAT,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import type { PostSearchV5PackedBranchSummary } from './postSearchV5PackedBranch';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import { POST_SEARCH_V5_MAX_FIELDS, POST_SEARCH_V5_MAX_TOKENS_PER_FIELD } from './postSearchV5Run';
import {
  POST_SEARCH_V5_ROUTED_NORMALIZATION,
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  POST_SEARCH_V5_ROUTED_RUN_MAX_MANIFEST_BYTES,
  type PostSearchV5RoutedBranchManifest,
  type PostSearchV5RoutedRunExpected,
  type PostSearchV5RoutedRunManifest,
} from './postSearchV5RoutedRunTypes';
import {
  addPostSearchV5Routed,
  assertPostSearchV5RoutedExactKeys,
  comparePostSearchV5RoutedText,
  equalPostSearchV5RoutedBytes,
  isPostSearchV5RoutedRecord,
  parsePostSearchV5RoutedJsonObject,
  postSearchV5RoutedBoundedNumber,
  postSearchV5RoutedNonEmptyString,
  postSearchV5RoutedNonNegativeInteger,
  postSearchV5RoutedObject,
  postSearchV5RoutedPositiveInteger,
  postSearchV5RoutedPositiveNumber,
} from './postSearchV5RoutedRunValidation';

const encoder = new TextEncoder();

export function parsePostSearchV5RoutedRunManifest(
  bytes: Uint8Array,
): PostSearchV5RoutedRunManifest {
  const raw = parsePostSearchV5RoutedJsonObject(bytes, 'run manifest');
  assertPostSearchV5RoutedExactKeys(raw, [
    'branches', 'documentCount', 'fields', 'format', 'k1', 'maxTokensPerField',
    'normalization', 'packedPageFormat', 'pageRouterFormat', 'postingCount',
    'postingPartCount', 'reachableNodeCount', 'storedValueCount', 'termCount',
    'tokenOccurrenceCount',
  ], 'run manifest');
  if (raw.format !== POST_SEARCH_V5_ROUTED_RUN_FORMAT
    || raw.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || raw.pageRouterFormat !== POST_SEARCH_V5_PAGE_ROUTER_FORMAT
    || raw.normalization !== POST_SEARCH_V5_ROUTED_NORMALIZATION) {
    throw new Error('Unsupported post-search v5 routed run manifest');
  }
  const documentCount = postSearchV5RoutedPositiveInteger(raw.documentCount, 'documentCount');
  const fields = validatePostSearchV5RoutedFields(
    raw.fields as RankedSearchFieldManifest[],
    documentCount,
  );
  const branchesValue = postSearchV5RoutedObject(raw.branches, 'branches');
  assertPostSearchV5RoutedExactKeys(
    branchesValue,
    ['documents', 'postings', 'terms'],
    'branches',
  );
  const documents = parseBranch(branchesValue.documents, 'documents');
  const postings = branchesValue.postings === null
    ? null : parseBranch(branchesValue.postings, 'postings');
  const terms = branchesValue.terms === null
    ? null : parseBranch(branchesValue.terms, 'terms');
  const manifest: PostSearchV5RoutedRunManifest = {
    format: POST_SEARCH_V5_ROUTED_RUN_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
    normalization: POST_SEARCH_V5_ROUTED_NORMALIZATION,
    documentCount,
    termCount: postSearchV5RoutedNonNegativeInteger(raw.termCount, 'termCount'),
    postingCount: postSearchV5RoutedNonNegativeInteger(raw.postingCount, 'postingCount'),
    postingPartCount: postSearchV5RoutedNonNegativeInteger(
      raw.postingPartCount,
      'postingPartCount',
    ),
    storedValueCount: postSearchV5RoutedNonNegativeInteger(
      raw.storedValueCount,
      'storedValueCount',
    ),
    tokenOccurrenceCount: postSearchV5RoutedNonNegativeInteger(
      raw.tokenOccurrenceCount,
      'tokenOccurrenceCount',
    ),
    k1: postSearchV5RoutedPositiveNumber(raw.k1, 'k1'),
    maxTokensPerField: postSearchV5RoutedPositiveInteger(
      raw.maxTokensPerField,
      'maxTokensPerField',
    ),
    fields,
    branches: { documents, postings, terms },
    reachableNodeCount: postSearchV5RoutedPositiveInteger(
      raw.reachableNodeCount,
      'reachableNodeCount',
    ),
  };
  const expectedReachable = addPostSearchV5Routed(2, addPostSearchV5Routed(
    documents.reachableNodeCount,
    addPostSearchV5Routed(
      postings?.reachableNodeCount ?? 0,
      terms?.reachableNodeCount ?? 0,
      'manifest branch reachability',
    ),
    'manifest branch reachability',
  ), 'manifest reachability');
  if (manifest.maxTokensPerField > POST_SEARCH_V5_MAX_TOKENS_PER_FIELD
    || manifest.storedValueCount > documentCount
    || documents.entryCount !== documentCount
    || (postings === null) !== (terms === null)
    || (manifest.termCount === 0) !== (terms === null)
    || (manifest.postingCount === 0) !== (manifest.termCount === 0)
    || (manifest.tokenOccurrenceCount === 0) !== (manifest.termCount === 0)
    || (terms?.entryCount ?? 0) !== manifest.termCount
    || (postings?.entryCount ?? 0) !== manifest.postingPartCount
    || manifest.reachableNodeCount !== expectedReachable) {
    throw new Error('Inconsistent post-search v5 routed run manifest');
  }
  if (!equalPostSearchV5RoutedBytes(bytes, encodePostSearchV5RoutedRunManifest(manifest))) {
    throw new Error('Post-search v5 routed run manifest is not canonical');
  }
  return manifest;
}

function parseBranch(
  value: unknown,
  kind: PostSearchV5PackedPageKind,
): PostSearchV5RoutedBranchManifest {
  const raw = postSearchV5RoutedObject(value, `${kind} branch`);
  assertPostSearchV5RoutedExactKeys(raw, [
    'entryCount', 'height', 'maxKey', 'minKey', 'pageCount', 'pageKind',
    'reachableNodeCount', 'routerNodeCount',
  ], `${kind} branch`);
  if (raw.pageKind !== kind) {
    throw new Error(`Invalid post-search v5 routed ${kind} page kind`);
  }
  const branch = {
    pageKind: kind,
    entryCount: postSearchV5RoutedPositiveInteger(raw.entryCount, `${kind} entryCount`),
    minKey: postSearchV5RoutedNonEmptyString(raw.minKey, `${kind} minKey`),
    maxKey: postSearchV5RoutedNonEmptyString(raw.maxKey, `${kind} maxKey`),
    height: postSearchV5RoutedNonNegativeInteger(raw.height, `${kind} height`),
    pageCount: postSearchV5RoutedPositiveInteger(raw.pageCount, `${kind} pageCount`),
    routerNodeCount: postSearchV5RoutedPositiveInteger(
      raw.routerNodeCount,
      `${kind} routerNodeCount`,
    ),
    reachableNodeCount: postSearchV5RoutedPositiveInteger(
      raw.reachableNodeCount,
      `${kind} reachableNodeCount`,
    ),
  };
  if (comparePostSearchV5RoutedText(branch.minKey, branch.maxKey) > 0
    || branch.reachableNodeCount !== branch.pageCount + branch.routerNodeCount) {
    throw new Error(`Inconsistent post-search v5 routed ${kind} branch`);
  }
  return branch;
}

export function validatePostSearchV5RoutedFields(
  input: readonly RankedSearchFieldManifest[],
  documentCount: number,
): RankedSearchFieldManifest[] {
  if (!Array.isArray(input) || input.length < 1 || input.length > POST_SEARCH_V5_MAX_FIELDS) {
    throw new Error('Invalid post-search v5 routed run fields');
  }
  const fields = input.map((field, index) => {
    if (!isPostSearchV5RoutedRecord(field)) {
      throw new Error(`Invalid post-search v5 routed run field ${index}`);
    }
    const parsed = {
      name: postSearchV5RoutedNonEmptyString(field.name, `field ${index} name`),
      boost: postSearchV5RoutedPositiveNumber(field.boost, `field ${index} boost`),
      lengthNormalization: postSearchV5RoutedBoundedNumber(
        field.lengthNormalization,
        0,
        1,
        `field ${index} lengthNormalization`,
      ),
      totalLength: postSearchV5RoutedNonNegativeInteger(
        field.totalLength,
        `field ${index} totalLength`,
      ),
      populatedDocumentCount: postSearchV5RoutedNonNegativeInteger(
        field.populatedDocumentCount,
        `field ${index} populatedDocumentCount`,
      ),
    };
    if (parsed.totalLength < parsed.populatedDocumentCount
      || parsed.populatedDocumentCount > documentCount) {
      throw new Error(`Invalid post-search v5 routed run field totals: ${parsed.name}`);
    }
    return parsed;
  });
  if (fields.some((field, index) => index > 0 && field.name <= fields[index - 1]!.name)) {
    throw new Error('Post-search v5 routed run fields are not canonically ordered');
  }
  return fields;
}

export function postSearchV5RoutedBranchManifest(
  summary: PostSearchV5PackedBranchSummary,
): PostSearchV5RoutedBranchManifest {
  return {
    pageKind: summary.pageKind,
    entryCount: summary.entryCount,
    minKey: summary.minKey,
    maxKey: summary.maxKey,
    height: summary.height,
    pageCount: summary.pageCount,
    routerNodeCount: summary.routerNodeCount,
    reachableNodeCount: summary.reachableNodeCount,
  };
}

export function postSearchV5RoutedBranchEntry(
  name: string,
  summary: PostSearchV5PackedBranchSummary,
): TreeEntry {
  return {
    name,
    cid: summary.root,
    size: summary.reachableNodeCount,
    type: LinkType.Dir,
  };
}

export function bindPostSearchV5RoutedBranchLink(
  links: readonly Link[],
  name: string,
  branch: PostSearchV5RoutedBranchManifest,
): CID {
  const link = links.find((candidate) => candidate.name === name);
  if (!link || link.type !== LinkType.Dir || link.size !== branch.reachableNodeCount) {
    throw new Error(`Post-search v5 routed run ${name} link is inconsistent`);
  }
  return { hash: new Uint8Array(link.hash) };
}

export function assertPostSearchV5RoutedExpected(
  manifest: PostSearchV5RoutedRunManifest,
  expected: PostSearchV5RoutedRunExpected,
): void {
  const values = {
    documentCount: manifest.documentCount,
    termCount: manifest.termCount,
    postingCount: manifest.postingCount,
    postingPartCount: manifest.postingPartCount,
    storedValueCount: manifest.storedValueCount,
    tokenOccurrenceCount: manifest.tokenOccurrenceCount,
    pageCount: postSearchV5RoutedTotalPageCount(manifest),
    reachableNodeCount: manifest.reachableNodeCount,
  };
  for (const key of Object.keys(values) as Array<keyof typeof values>) {
    if (expected[key] !== undefined && expected[key] !== values[key]) {
      throw new Error(`Post-search v5 routed run expected ${key} does not match`);
    }
  }
}

function postSearchV5RoutedTotalPageCount(manifest: PostSearchV5RoutedRunManifest): number {
  return addPostSearchV5Routed(
    manifest.branches.documents.pageCount,
    addPostSearchV5Routed(
      manifest.branches.postings?.pageCount ?? 0,
      manifest.branches.terms?.pageCount ?? 0,
      'page count',
    ),
    'page count',
  );
}

export function encodePostSearchV5RoutedRunManifest(
  manifest: PostSearchV5RoutedRunManifest,
): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length === 0 || bytes.length > POST_SEARCH_V5_ROUTED_RUN_MAX_MANIFEST_BYTES) {
    throw new Error('Post-search v5 routed run manifest exceeds its byte bound');
  }
  return bytes;
}
