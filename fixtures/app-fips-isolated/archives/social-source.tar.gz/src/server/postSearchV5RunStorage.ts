import {
  HashTree,
  LinkType,
  sha256,
  toHex,
  type CID,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import {
  POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES,
  decodePostSearchV5PackedPage,
  writePostSearchV5PackedPage,
  type PostSearchV5PackedPageEntry,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import { postSearchV5PostingTerm } from './postSearchV5RunRecords';
import {
  assertPostSearchV5PublicCid,
  comparePostSearchV5Strings,
} from './postSearchV5RunValidation';

const BUCKET_NAME = /^[0-9a-f]$/;
const encoder = new TextEncoder();

export interface PostSearchV5BranchBuild {
  root: CID;
  pageCount: number;
  entryCount: number;
}

export interface PostSearchV5BucketEntry {
  bucketKey: string;
  key: string;
  value: string;
}

export interface PostSearchV5ReadBranch {
  entries: PostSearchV5PackedPageEntry[];
  pageCount: number;
}

export async function buildPostSearchV5Branch(
  store: Store,
  tree: HashTree,
  kind: PostSearchV5PackedPageKind,
  entries: readonly PostSearchV5BucketEntry[],
): Promise<PostSearchV5BranchBuild> {
  const buckets = new Map<string, PostSearchV5PackedPageEntry[]>();
  for (const entry of entries) {
    const hash = await sha256(encoder.encode(entry.bucketKey));
    const bucket = (hash[0]! >>> 4).toString(16);
    const bucketEntries = buckets.get(bucket) ?? [];
    bucketEntries.push([entry.key, entry.value]);
    buckets.set(bucket, bucketEntries);
  }
  const branchEntries: TreeEntry[] = [];
  let pageCount = 0;
  for (const bucket of [...buckets.keys()].sort(comparePostSearchV5Strings)) {
    const pages = packEntries(buckets.get(bucket) ?? []);
    const pageLinks: TreeEntry[] = [];
    for (let index = 0; index < pages.length; index += 1) {
      const written = await writePostSearchV5PackedPage(store, kind, pages[index]!);
      pageLinks.push(postSearchV5BlobEntry(
        postSearchV5PageName(index),
        written.root,
        written.byteLength,
      ));
      pageCount += 1;
    }
    const bucketRoot = (await tree.putDirectory(pageLinks, { unencrypted: true })).cid;
    branchEntries.push(postSearchV5DirectoryEntry(bucket, bucketRoot));
  }
  const root = (await tree.putDirectory(branchEntries, { unencrypted: true })).cid;
  return { root, pageCount, entryCount: entries.length };
}

function packEntries(
  entries: readonly PostSearchV5PackedPageEntry[],
): PostSearchV5PackedPageEntry[][] {
  const sorted = [...entries].sort(([left], [right]) =>
    comparePostSearchV5Strings(left, right));
  const pages: PostSearchV5PackedPageEntry[][] = [];
  let page: PostSearchV5PackedPageEntry[] = [];
  let bytes = 20;
  for (const entry of sorted) {
    const keyBytes = encoder.encode(entry[0]).length;
    const valueBytes = encoder.encode(entry[1]).length;
    if (keyBytes === 0 || keyBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES
      || valueBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      throw new Error(`Post-search v5 run entry exceeds packed page bounds: ${entry[0]}`);
    }
    const entryBytes = 8 + keyBytes + valueBytes;
    if (page.length > 0 && (page.length === POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES
      || bytes + entryBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES)) {
      pages.push(page);
      page = [];
      bytes = 20;
    }
    if (bytes + entryBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
      throw new Error(`Post-search v5 run entry cannot fit a packed page: ${entry[0]}`);
    }
    page.push(entry);
    bytes += entryBytes;
  }
  if (page.length > 0) {
    pages.push(page);
  }
  return pages;
}

export async function readPostSearchV5Branch(
  tree: HashTree,
  store: Store,
  root: CID,
  kind: PostSearchV5PackedPageKind,
): Promise<PostSearchV5ReadBranch> {
  assertPostSearchV5PublicCid(root, `${kind} branch`);
  const buckets = await tree.listDirectory(root);
  const entries: PostSearchV5PackedPageEntry[] = [];
  let pageCount = 0;
  for (const bucket of buckets) {
    if (!BUCKET_NAME.test(bucket.name) || bucket.type !== LinkType.Dir) {
      throw new Error(`Invalid post-search v5 ${kind} bucket`);
    }
    if (bucket.size !== 0) {
      throw new Error(`Invalid post-search v5 ${kind} bucket size`);
    }
    assertPostSearchV5PublicCid(bucket.cid, `${kind} bucket`);
    const pages = await tree.listDirectory(bucket.cid);
    for (let index = 0; index < pages.length; index += 1) {
      const pageEntry = pages[index]!;
      if (pageEntry.name !== postSearchV5PageName(index)
        || pageEntry.type !== LinkType.Blob) {
        throw new Error(`Invalid post-search v5 ${kind} page link`);
      }
      const pageBytes = await readPostSearchV5RawBlock(store, pageEntry.cid, `${kind} page`);
      if (pageEntry.size !== pageBytes.length) {
        throw new Error(`Post-search v5 ${kind} page link size mismatch`);
      }
      const page = decodePostSearchV5PackedPage(pageBytes);
      if (page.kind !== kind) {
        throw new Error(`Mismatched post-search v5 ${kind} page kind`);
      }
      for (const entry of page.entries) {
        const logicalKey = kind === 'postings' ? postSearchV5PostingTerm(entry[0]) : entry[0];
        const hash = await sha256(encoder.encode(logicalKey));
        if ((hash[0]! >>> 4).toString(16) !== bucket.name) {
          throw new Error(`Post-search v5 ${kind} entry is in the wrong bucket`);
        }
        entries.push(entry);
      }
      pageCount += 1;
    }
  }
  const keys = entries.map(([key]) => key);
  if (new Set(keys).size !== keys.length) {
    throw new Error(`Duplicate post-search v5 ${kind} entry`);
  }
  return { entries, pageCount };
}

export async function readPostSearchV5BucketEntries(
  tree: HashTree,
  store: Store,
  branchRoot: CID,
  kind: PostSearchV5PackedPageKind,
  logicalKey: string,
): Promise<PostSearchV5PackedPageEntry[]> {
  assertPostSearchV5PublicCid(branchRoot, `${kind} branch`);
  const hash = await sha256(encoder.encode(logicalKey));
  const bucketName = (hash[0]! >>> 4).toString(16);
  const resolved = await tree.resolvePath(branchRoot, bucketName);
  if (!resolved) {
    return [];
  }
  if (resolved.type !== LinkType.Dir) {
    throw new Error(`Invalid post-search v5 ${kind} bucket`);
  }
  assertPostSearchV5PublicCid(resolved.cid, `${kind} bucket`);
  const pageLinks = await tree.listDirectory(resolved.cid);
  const entries: PostSearchV5PackedPageEntry[] = [];
  for (let index = 0; index < pageLinks.length; index += 1) {
    const link = pageLinks[index]!;
    if (link.name !== postSearchV5PageName(index) || link.type !== LinkType.Blob) {
      throw new Error(`Invalid post-search v5 ${kind} page link`);
    }
    const bytes = await readPostSearchV5RawBlock(store, link.cid, `${kind} page`);
    if (link.size !== bytes.length) {
      throw new Error(`Post-search v5 ${kind} page link size mismatch`);
    }
    const page = decodePostSearchV5PackedPage(bytes);
    if (page.kind !== kind) {
      throw new Error(`Mismatched post-search v5 ${kind} page kind`);
    }
    for (const entry of page.entries) {
      const entryLogicalKey = kind === 'postings' ? postSearchV5PostingTerm(entry[0]) : entry[0];
      const entryHash = await sha256(encoder.encode(entryLogicalKey));
      if ((entryHash[0]! >>> 4).toString(16) !== bucketName) {
        throw new Error(`Post-search v5 ${kind} entry is in the wrong bucket`);
      }
      entries.push(entry);
    }
  }
  const keys = entries.map(([key]) => key);
  if (new Set(keys).size !== keys.length) {
    throw new Error(`Duplicate post-search v5 ${kind} entry`);
  }
  return entries;
}

export async function readPostSearchV5RawBlock(
  store: Store,
  cid: CID,
  label: string,
): Promise<Uint8Array> {
  assertPostSearchV5PublicCid(cid, label);
  const bytes = await store.get(cid.hash);
  if (!bytes) {
    throw new Error(`Missing post-search v5 ${label}`);
  }
  if (toHex(await sha256(bytes)) !== toHex(cid.hash)) {
    throw new Error(`Post-search v5 ${label} hash mismatch`);
  }
  return bytes;
}

export async function postSearchV5ReachableHashes(
  tree: HashTree,
  roots: readonly CID[],
): Promise<Set<string>> {
  const hashes = new Set<string>();
  for (const root of roots) {
    for await (const block of tree.walkBlocks(root)) {
      hashes.add(toHex(block.hash));
    }
  }
  return hashes;
}

export function postSearchV5RequiredEntry(
  entries: readonly TreeEntry[],
  name: string,
  type: LinkType,
): TreeEntry {
  const entry = entries.find((candidate) => candidate.name === name);
  if (!entry || entry.type !== type || (type === LinkType.Dir && entry.size !== 0)) {
    throw new Error(`Missing or invalid post-search v5 run branch: ${name}`);
  }
  assertPostSearchV5PublicCid(entry.cid, name);
  return entry;
}

export function assertPostSearchV5ExactNames(
  entries: readonly TreeEntry[],
  expected: readonly string[],
  label: string,
): void {
  const names = entries.map((entry) => entry.name).sort(comparePostSearchV5Strings);
  if (JSON.stringify(names)
    !== JSON.stringify([...expected].sort(comparePostSearchV5Strings))) {
    throw new Error(`Unbound or missing post-search v5 ${label} links`);
  }
}

export function postSearchV5DirectoryEntry(name: string, cid: CID): TreeEntry {
  return { name, cid, size: 0, type: LinkType.Dir };
}

export function postSearchV5BlobEntry(name: string, cid: CID, size: number): TreeEntry {
  return { name, cid, size, type: LinkType.Blob };
}

export function postSearchV5PageName(index: number): string {
  return index.toString().padStart(6, '0');
}
