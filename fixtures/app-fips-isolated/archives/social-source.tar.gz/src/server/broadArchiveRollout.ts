import { createHash } from 'node:crypto';
import { SocialGraph } from 'nostr-social-graph';
import {
  censusNostrSocialGraph,
  NOSTR_ARCHIVE_OVERMUTE_THRESHOLD,
  type NostrSocialGraphCensus,
} from './nostrArchiveOvermute';

export const BROAD_ARCHIVE_CENSUS_FORMAT = 'iris-social/social-graph-crawl-census@2';
export const BROAD_ARCHIVE_MIN_ELIGIBLE_AUTHORS = 100_000;
export const BROAD_ARCHIVE_HTREE_VERSION = '0.2.134';
export const BROAD_ARCHIVE_KINDS = [
  0, 1, 3, 5, 6, 7, 16, 20, 1_111, 9_735, 10_000, 30_000, 30_023,
] as const;
export const PROFILE_FAST_LANE_KINDS = [0, 3, 10_000] as const;

type PublicCensus = Omit<NostrSocialGraphCensus, 'eligiblePubkeys' | 'overmutedPubkeys'>;

export type BroadArchiveCensusReport = {
  format: typeof BROAD_ARCHIVE_CENSUS_FORMAT;
  socialGraphRoot: string;
  socialGraphSha256: string;
  overmuteThreshold: typeof NOSTR_ARCHIVE_OVERMUTE_THRESHOLD;
  maxDistance: number | null;
  requiredEligibleAuthors: number | null;
  selectedEligibleAuthors: number;
  eligibleAuthorsSha256: string;
  eligibleAuthorsBytes: number;
  census: PublicCensus;
};

export type BroadArchiveCensusOptions = {
  socialGraphRoot: string;
  socialGraphSha256: string;
  maxDistance?: number;
  minEligibleAuthors?: number;
};

export type BroadArchiveCensusArtifacts = {
  report: BroadArchiveCensusReport;
  eligibleAuthorsText: string;
};

export type BroadArchiveContentOptions = {
  allowlistUrl: string;
  authorCount: number;
  authorBatchSize: number;
  checkpointAuthors: number;
  indexCommitBatchSize: number;
  btreeOrder: number;
  btreeUpdateConcurrency: number;
  maxLiveMiB: number;
  perAuthorEventLimit: number;
  perAuthorLiveBytes: number;
  relayEventMaxBytes: number;
  relays?: readonly string[];
  profileOnly?: boolean;
};

export async function createBroadArchiveCensusArtifacts(
  bytes: Uint8Array,
  options: BroadArchiveCensusOptions,
): Promise<BroadArchiveCensusArtifacts> {
  requireHex(options.socialGraphRoot, 'social graph root');
  requireHex(options.socialGraphSha256, 'social graph SHA-256');
  requireOptionalNonNegativeInteger(options.maxDistance, 'maximum social graph distance');
  requireOptionalPositiveInteger(options.minEligibleAuthors, 'minimum eligible authors');

  const actualSha256 = sha256(bytes);
  if (actualSha256 !== options.socialGraphSha256) {
    throw new Error(
      `social graph SHA-256 mismatch: expected ${options.socialGraphSha256}, got ${actualSha256}`,
    );
  }

  const graph = await SocialGraph.fromBinary(options.socialGraphRoot, bytes);
  const census = censusNostrSocialGraph(graph);
  const selected = census.eligiblePubkeys.filter((pubkey) => (
    options.maxDistance === undefined || graph.getFollowDistance(pubkey) <= options.maxDistance
  ));
  if (
    options.minEligibleAuthors !== undefined
    && selected.length < options.minEligibleAuthors
  ) {
    throw new Error(
      `selected eligible social graph authors ${selected.length} < ${options.minEligibleAuthors}`,
    );
  }

  const eligibleAuthorsText = `${selected.join('\n')}\n`;
  const {
    eligiblePubkeys: _eligiblePubkeys,
    overmutedPubkeys: _overmutedPubkeys,
    ...publicCensus
  } = census;
  return {
    eligibleAuthorsText,
    report: {
      format: BROAD_ARCHIVE_CENSUS_FORMAT,
      socialGraphRoot: options.socialGraphRoot,
      socialGraphSha256: options.socialGraphSha256,
      overmuteThreshold: NOSTR_ARCHIVE_OVERMUTE_THRESHOLD,
      maxDistance: options.maxDistance ?? null,
      requiredEligibleAuthors: options.minEligibleAuthors ?? null,
      selectedEligibleAuthors: selected.length,
      eligibleAuthorsSha256: sha256(eligibleAuthorsText),
      eligibleAuthorsBytes: Buffer.byteLength(eligibleAuthorsText),
      census: publicCensus,
    },
  };
}

/** Recompute eligibility from the exact snapshot before scheduling content. */
export async function validateBroadArchiveCensusArtifacts(
  snapshotBytes: Uint8Array,
  eligibleAuthorsText: string,
  value: unknown,
  minimumEligibleAuthors = BROAD_ARCHIVE_MIN_ELIGIBLE_AUTHORS,
): Promise<string[]> {
  const report = parseBroadArchiveCensusReport(value);
  const actualSnapshotSha256 = sha256(snapshotBytes);
  if (actualSnapshotSha256 !== report.socialGraphSha256) {
    throw new Error(
      `social graph SHA-256 mismatch: expected ${report.socialGraphSha256}, got ${actualSnapshotSha256}`,
    );
  }
  const actualAllowlistSha256 = sha256(eligibleAuthorsText);
  if (actualAllowlistSha256 !== report.eligibleAuthorsSha256) {
    throw new Error(
      `eligible author allowlist SHA-256 mismatch: expected ${report.eligibleAuthorsSha256}, got ${actualAllowlistSha256}`,
    );
  }
  if (report.selectedEligibleAuthors < minimumEligibleAuthors) {
    throw new Error(
      `selected eligible social graph authors ${report.selectedEligibleAuthors} < ${minimumEligibleAuthors}`,
    );
  }

  const expected = await createBroadArchiveCensusArtifacts(snapshotBytes, {
    socialGraphRoot: report.socialGraphRoot,
    socialGraphSha256: report.socialGraphSha256,
    maxDistance: report.maxDistance ?? undefined,
    minEligibleAuthors: report.requiredEligibleAuthors ?? undefined,
  });
  if (expected.eligibleAuthorsText !== eligibleAuthorsText) {
    throw new Error('eligible author allowlist does not match the exact social graph census');
  }
  if (JSON.stringify(expected.report) !== JSON.stringify(report)) {
    throw new Error('social graph census report does not match the exact snapshot');
  }
  return eligibleAuthorsText.trimEnd().split('\n');
}

export function buildBroadArchiveContentArguments(
  options: BroadArchiveContentOptions,
): string[] {
  requireHttpLoopbackUrl(options.allowlistUrl);
  requirePositiveInteger(options.authorCount, 'author count');
  requirePositiveInteger(options.authorBatchSize, 'author batch size');
  requirePositiveInteger(options.checkpointAuthors, 'checkpoint author cadence');
  requirePositiveInteger(options.indexCommitBatchSize, 'index commit batch size');
  requirePositiveInteger(options.btreeOrder, 'B-tree order');
  requirePositiveInteger(options.btreeUpdateConcurrency, 'B-tree update concurrency');
  requirePositiveInteger(options.maxLiveMiB, 'maximum live MiB');
  requirePositiveInteger(options.perAuthorEventLimit, 'per-author event limit');
  requirePositiveInteger(options.perAuthorLiveBytes, 'per-author live bytes');
  requirePositiveInteger(options.relayEventMaxBytes, 'relay event maximum bytes');
  const relayPageSize = 1_000;
  const maxRelayPages = Math.ceil(options.perAuthorEventLimit / relayPageSize) + 1;

  const args = [
    'socialgraph', 'index',
    '--crawl-depth', '0',
    '--max-follow-distance', '0',
    '--max-authors', String(options.authorCount),
    '--max-live-mb', String(options.maxLiveMiB),
    '--per-author-event-limit', String(options.perAuthorEventLimit),
    '--per-author-live-bytes', String(options.perAuthorLiveBytes),
    '--author-batch-size', String(options.authorBatchSize),
    '--checkpoint-authors', String(options.checkpointAuthors),
    '--index-commit-batch-size', String(options.indexCommitBatchSize),
    '--btree-order', String(options.btreeOrder),
    '--btree-update-concurrency', String(options.btreeUpdateConcurrency),
    '--concurrent-batches', '4',
    '--fetch-timeout-secs', '30',
    '--relay-event-max-bytes', String(options.relayEventMaxBytes),
    '--full-author-history',
    '--author-allowlist-url', options.allowlistUrl,
    '--relay-page-size', String(relayPageSize),
    '--max-relay-pages', String(maxRelayPages),
  ];
  if (options.profileOnly) {
    args.push('--per-author-kind-event-limit', '1');
  }
  const kinds = options.profileOnly ? PROFILE_FAST_LANE_KINDS : BROAD_ARCHIVE_KINDS;
  for (const kind of kinds) {
    args.push('--kind', String(kind));
  }
  for (const relay of options.relays ?? []) {
    args.push('--relay', relay);
  }
  return args;
}

function parseBroadArchiveCensusReport(value: unknown): BroadArchiveCensusReport {
  if (!value || typeof value !== 'object') {
    throw new Error('social graph census report must be an object');
  }
  const report = value as Partial<BroadArchiveCensusReport>;
  if (report.format !== BROAD_ARCHIVE_CENSUS_FORMAT) {
    throw new Error(`social graph census report must use ${BROAD_ARCHIVE_CENSUS_FORMAT}`);
  }
  if (report.overmuteThreshold !== NOSTR_ARCHIVE_OVERMUTE_THRESHOLD) {
    throw new Error('social graph census report must use overmute threshold 1.0');
  }
  requireHex(report.socialGraphRoot, 'social graph root');
  requireHex(report.socialGraphSha256, 'social graph SHA-256');
  requireHex(report.eligibleAuthorsSha256, 'eligible author allowlist SHA-256');
  requirePositiveInteger(report.selectedEligibleAuthors, 'selected eligible authors');
  requirePositiveInteger(report.eligibleAuthorsBytes, 'eligible author allowlist bytes');
  requireOptionalNonNegativeInteger(report.maxDistance ?? undefined, 'maximum social graph distance');
  requireOptionalPositiveInteger(report.requiredEligibleAuthors ?? undefined, 'minimum eligible authors');
  if (!report.census || typeof report.census !== 'object') {
    throw new Error('social graph census report is missing its census');
  }
  return report as BroadArchiveCensusReport;
}

function sha256(value: Uint8Array | string): string {
  return createHash('sha256').update(value).digest('hex');
}

function requireHex(value: unknown, name: string): asserts value is string {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`${name} must be lowercase 64-character hex`);
  }
}

function requirePositiveInteger(value: unknown, name: string): asserts value is number {
  if (!Number.isSafeInteger(value) || Number(value) <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
}

function requireOptionalPositiveInteger(value: unknown, name: string): void {
  if (value !== undefined) {
    requirePositiveInteger(value, name);
  }
}

function requireOptionalNonNegativeInteger(value: unknown, name: string): void {
  if (value !== undefined && (!Number.isSafeInteger(value) || Number(value) < 0)) {
    throw new Error(`${name} must be a non-negative integer`);
  }
}

function requireHttpLoopbackUrl(value: string): void {
  const url = new URL(value);
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1') {
    throw new Error('author allowlist URL must use loopback HTTP');
  }
}
