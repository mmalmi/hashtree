import { nhashDecode, nhashEncode, type Store } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import { HashtreeNostrEventReader } from '@hashtree/nostr-pubsub';
import { verifyEvent } from 'nostr-tools/pure';
import { canonical, type ArchiveCandidate, type ArchiveCheckpoint, type ArchiveRepairReceipt } from './archiveCheckpointOutbox';

const sha256 = (value: unknown): value is string => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
export const MAX_ARCHIVE_REPAIR_RECEIPTS = 64;

export function validateArchiveRepairReceipt(receipt: ArchiveRepairReceipt): void {
  if (receipt.format !== 'iris-social/archive-projection-repair@1' || receipt.completed !== true || receipt.exitCode !== 0
    || receipt.originalAndPoolPinsUnchanged !== true || !receipt.before?.state || !receipt.after?.state
    || !receipt.tool || !/^[a-f0-9]{40}$/.test(receipt.tool.sourceCommit)
    || ![receipt.nativeAuthoritySha256, receipt.nativeRunReceiptSha256, receipt.nativeRepairReceiptSha256,
      receipt.before.checkpointSha256, receipt.after.checkpointSha256, receipt.tool.binarySha256,
      receipt.eventFileSha256].every(sha256)
    || receipt.event?.kind !== 1 || !verifyEvent(JSON.parse(JSON.stringify(receipt.event)))) {
    throw new Error('Invalid completed archive repair receipt');
  }
  const before = receipt.before.state, after = receipt.after.state;
  if (before.root === after.root || canonical({ ...before, root: after.root }) !== canonical(after)) {
    throw new Error('Archive repair may change only the checkpoint root');
  }
  nhashDecode(before.root); nhashDecode(after.root); nhashDecode(receipt.eventCid);
}

/** Historical evidence stays bounded and cannot be repeated under another wrapper path. */
export function validateArchiveRepairHistory(trusted: readonly ArchiveRepairReceipt[]): void {
  if (!Array.isArray(trusted) || trusted.length > MAX_ARCHIVE_REPAIR_RECEIPTS) {
    throw new Error('Too many archive repair receipts');
  }
  const seen = new Set<string>();
  for (const receipt of trusted) {
    validateArchiveRepairReceipt(receipt);
    if (seen.has(receipt.nativeRepairReceiptSha256)) {throw new Error('Duplicate archive repair evidence');}
    seen.add(receipt.nativeRepairReceiptSha256);
  }
}

/** Historic pins remain usable evidence without attaching to later ordinary batches. */
export function selectArchiveRepairs(state: ArchiveCheckpoint, native: ArchiveCheckpoint,
  trusted: readonly ArchiveRepairReceipt[]): ArchiveRepairReceipt[] {
  validateArchiveRepairHistory(trusted);
  if (canonical(state) === canonical(native)) {return [];}
  const matches = trusted.filter(receipt => canonical(receipt.before.state) === canonical(native)
    && canonical(receipt.after.state) === canonical(state));
  if (matches.length !== 1) {throw new Error('Checkpoint root change needs one exact pinned repair');}
  return matches;
}

export function validateArchiveRepairLineage(candidate: ArchiveCandidate, authoritySha256: string,
  trusted: readonly ArchiveRepairReceipt[]): void {
  validateArchiveRepairHistory(trusted);
  if (candidate.repairReceipts?.length !== 1) {throw new Error('Only one explicit archive repair is supported');}
  const receipt = candidate.repairReceipts[0];
  if (!trusted.some(value => canonical(value) === canonical(receipt))) {throw new Error('Archive repair receipt is not pinned');}
  validateArchiveRepairReceipt(receipt);
  if (receipt.nativeAuthoritySha256 !== authoritySha256 || receipt.nativeRunReceiptSha256 !== candidate.receiptSha256
    || canonical(receipt.before.state) !== canonical(candidate.run.after)
    || canonical(receipt.after.state) !== canonical(candidate.state)
    || receipt.after.checkpointSha256 !== candidate.checkpointSha256) {
    throw new Error('Archive repair does not bind the exact native receipt and checkpoint');
  }
}

/** Prove the one repaired ID is the identical signed event already in the old author projection. */
export async function verifyArchiveRepairEvidence(store: Store, receipt: ArchiveRepairReceipt,
  previousRoot: string, signal: AbortSignal): Promise<void> {
  validateArchiveRepairReceipt(receipt);
  const expected = receipt.event, serialized = canonical(expected), eventStore = new NostrEventStore(store);
  const query = async (root: string, filters: Parameters<HashtreeNostrEventReader['query']>[0], limit: number) => {
    signal.throwIfAborted();
    const reader = new HashtreeNostrEventReader({ store, roots: nhashDecode(root) });
    const result = await reader.query(filters, { limit, signal, deadline: Date.now() + 30_000 });
    if (!result.complete || result.events.some(({ event }) => !verifyEvent(JSON.parse(JSON.stringify(event))))) {
      throw new Error('Archive repair evidence is incomplete or invalid');
    }
    return result.events.map(({ event }) => event);
  };
  const authorKey = `${expected.pubkey}:00000001:${((1n << 64n) - 1n - BigInt(expected.created_at)).toString(16).padStart(16, '0')}:${expected.id}`;
  for (const root of new Set([previousRoot, receipt.before.state.root])) {
    const events = await query(root, [{ authors: [expected.pubkey], kinds: [1], since: expected.created_at, until: expected.created_at }], 32);
    if (!events.some(event => canonical(event) === serialized)
      || (await query(root, [{ ids: [expected.id] }], 1)).length !== 0) {
      throw new Error('Archive repair did not restore a missing original author event');
    }
    const source = await eventStore.getCollectionSource(nhashDecode(root));
    const cid = await source.getIndexLink('by-author-kind-time', authorKey);
    if (!cid || nhashEncode(cid) !== receipt.eventCid) {throw new Error('Archive repair original event CID differs');}
  }
  const repaired = await query(receipt.after.state.root, [{ ids: [expected.id] }], 1);
  const source = await eventStore.getCollectionSource(nhashDecode(receipt.after.state.root));
  const cid = await source.get(expected.id);
  if (repaired.length !== 1 || canonical(repaired[0]) !== serialized || !cid || nhashEncode(cid) !== receipt.eventCid) {
    throw new Error('Archive repair did not restore the identical signed event');
  }
  signal.throwIfAborted();
}
