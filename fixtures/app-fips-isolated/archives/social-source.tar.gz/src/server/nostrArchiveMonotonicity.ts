import { nhashEncode, type CID } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import {
  getSocialEventCoordinate,
  isAddressableEventKind,
  isNewerReplaceableEvent,
  isReplaceableEventKind,
} from '../lib/socialRepository';
import type { PostSearchSnapshotReader } from './postSearchProjection';
import { verifyPostSearchEvent } from './postSearchProjection';

export const NOSTR_ARCHIVE_MONOTONICITY_FORMAT = 'iris-social/nostr-archive-monotonicity@3';
const MAX_MISSING_EVENT_ID_SAMPLES = 8;
const HEX_64 = /^[0-9a-f]{64}$/;

export interface NostrArchiveCoverageReader extends PostSearchSnapshotReader {
  validateArchiveSnapshot?(root: CID): Promise<void>;
  streamCurrentState?(
    root: CID,
    kind: number,
  ): AsyncIterable<{ coordinate: string; event: RawEvent }>;
}

export interface NostrArchiveKindMonotonicity {
  kind: number;
  policy: 'event-id-containment' | 'current-state-winner';
  baselineScanned: number;
  baselineValid: number;
  baselineInvalid: number;
  baselineExcludedAuthors: number;
  candidateScanned: number;
  candidateValid: number;
  candidateInvalid: number;
  candidateExcludedAuthors: number;
  retainedValid: number;
  missingValid: number;
  missingEventIds: string[];
}

export interface NostrArchiveMonotonicityAggregate {
  baselineScanned: number;
  baselineValid: number;
  baselineInvalid: number;
  baselineExcludedAuthors: number;
  candidateScanned: number;
  candidateValid: number;
  candidateInvalid: number;
  candidateExcludedAuthors: number;
  retainedValid: number;
  missingValid: number;
}

export interface NostrArchiveMonotonicityReport {
  format: typeof NOSTR_ARCHIVE_MONOTONICITY_FORMAT;
  baselineRoot: string;
  candidateRoot: string;
  requiredKinds: number[];
  kinds: NostrArchiveKindMonotonicity[];
  aggregate: NostrArchiveMonotonicityAggregate;
  passed: boolean;
  failures: string[];
}

export interface NostrArchiveMonotonicityOptions {
  /** Compare only authors in the exact overmute-free publication allowlist. */
  eligibleAuthors?: ReadonlySet<string>;
}

/**
 * Non-replaceable streams retain every valid baseline event ID. Replaceable
 * and addressable streams instead retain each coordinate at the same or a
 * newer NIP-01 winner, matching the immutable Hashtree index's actual model.
 */
export async function reportNostrArchiveMonotonicity(
  reader: NostrArchiveCoverageReader,
  baselineRoot: CID,
  candidateRoot: CID,
  requiredKinds: readonly number[],
  options: NostrArchiveMonotonicityOptions = {},
): Promise<NostrArchiveMonotonicityReport> {
  const kinds = normalizeRequiredKinds(requiredKinds);
  validateEligibleAuthors(options.eligibleAuthors);
  await validateArchiveRoot(reader, baselineRoot);
  if (nhashEncode(candidateRoot) !== nhashEncode(baselineRoot)) {
    await validateArchiveRoot(reader, candidateRoot);
  }

  const reports: NostrArchiveKindMonotonicity[] = [];
  const failures: string[] = [];
  for (const kind of kinds) {
    const report = await reportKindMonotonicity(
      reader,
      baselineRoot,
      candidateRoot,
      kind,
      options.eligibleAuthors,
    );
    reports.push(report);
    if (report.missingValid > 0) {
      failures.push(monotonicityFailure(report));
    }
  }

  return {
    format: NOSTR_ARCHIVE_MONOTONICITY_FORMAT,
    baselineRoot: nhashEncode(baselineRoot),
    candidateRoot: nhashEncode(candidateRoot),
    requiredKinds: kinds,
    kinds: reports,
    aggregate: aggregateMonotonicity(reports),
    passed: failures.length === 0,
    failures,
  };
}

async function validateArchiveRoot(reader: NostrArchiveCoverageReader, root: CID): Promise<void> {
  await reader.validateSnapshot?.(root);
  await reader.validateArchiveSnapshot?.(root);
}

async function reportKindMonotonicity(
  reader: NostrArchiveCoverageReader,
  baselineRoot: CID,
  candidateRoot: CID,
  kind: number,
  eligibleAuthors: ReadonlySet<string> | undefined,
): Promise<NostrArchiveKindMonotonicity> {
  const currentStatePolicy = isReplaceableEventKind(kind) || isAddressableEventKind(kind);
  const report: NostrArchiveKindMonotonicity = {
    kind,
    policy: currentStatePolicy ? 'current-state-winner' : 'event-id-containment',
    baselineScanned: 0,
    baselineValid: 0,
    baselineInvalid: 0,
    baselineExcludedAuthors: 0,
    candidateScanned: 0,
    candidateValid: 0,
    candidateInvalid: 0,
    candidateExcludedAuthors: 0,
    retainedValid: 0,
    missingValid: 0,
    missingEventIds: [],
  };
  if (currentStatePolicy) {
    await reportCurrentStateMonotonicity(
      reader,
      baselineRoot,
      candidateRoot,
      kind,
      report,
      eligibleAuthors,
    );
    return report;
  }
  const baseline = validKindEvents(
    reader,
    baselineRoot,
    kind,
    report,
    'baseline',
    eligibleAuthors,
  );
  const candidate = validKindEvents(
    reader,
    candidateRoot,
    kind,
    report,
    'candidate',
    eligibleAuthors,
  );
  let baselineEntry = await baseline.next();
  let candidateEntry = await candidate.next();

  while (!baselineEntry.done || !candidateEntry.done) {
    if (baselineEntry.done) {
      candidateEntry = await candidate.next();
      continue;
    }
    if (candidateEntry.done) {
      recordMissingBaselineEvent(report, baselineEntry.value.id);
      baselineEntry = await baseline.next();
      continue;
    }

    const order = compareArchiveEvents(baselineEntry.value, candidateEntry.value);
    if (order === 0) {
      report.retainedValid = increment(report.retainedValid, `kind ${kind} retained valid`);
      baselineEntry = await baseline.next();
      candidateEntry = await candidate.next();
    } else if (order < 0) {
      recordMissingBaselineEvent(report, baselineEntry.value.id);
      baselineEntry = await baseline.next();
    } else {
      candidateEntry = await candidate.next();
    }
  }
  return report;
}

async function reportCurrentStateMonotonicity(
  reader: NostrArchiveCoverageReader,
  baselineRoot: CID,
  candidateRoot: CID,
  kind: number,
  report: NostrArchiveKindMonotonicity,
  eligibleAuthors: ReadonlySet<string> | undefined,
): Promise<void> {
  if (!reader.streamCurrentState) {
    throw new Error(`Kind ${kind} monotonicity requires a current-state index stream`);
  }
  const baseline = validCurrentStateEvents(
    reader,
    baselineRoot,
    kind,
    report,
    'baseline',
    eligibleAuthors,
  );
  const candidate = validCurrentStateEvents(
    reader,
    candidateRoot,
    kind,
    report,
    'candidate',
    eligibleAuthors,
  );
  let baselineEntry = await baseline.next();
  let candidateEntry = await candidate.next();

  while (!baselineEntry.done || !candidateEntry.done) {
    if (baselineEntry.done) {
      candidateEntry = await candidate.next();
      continue;
    }
    if (candidateEntry.done) {
      recordMissingBaselineEvent(report, baselineEntry.value.event.id);
      baselineEntry = await baseline.next();
      continue;
    }

    const order = compareText(baselineEntry.value.coordinate, candidateEntry.value.coordinate);
    if (order === 0) {
      const baselineEvent = baselineEntry.value.event;
      const candidateEvent = candidateEntry.value.event;
      if (candidateEvent.id === baselineEvent.id
        || isNewerReplaceableEvent(candidateEvent, baselineEvent)) {
        report.retainedValid = increment(report.retainedValid, `kind ${kind} retained valid`);
      } else {
        recordMissingBaselineEvent(report, baselineEvent.id);
      }
      baselineEntry = await baseline.next();
      candidateEntry = await candidate.next();
    } else if (order < 0) {
      recordMissingBaselineEvent(report, baselineEntry.value.event.id);
      baselineEntry = await baseline.next();
    } else {
      candidateEntry = await candidate.next();
    }
  }
}

async function* validCurrentStateEvents(
  reader: NostrArchiveCoverageReader,
  root: CID,
  kind: number,
  report: NostrArchiveKindMonotonicity,
  source: 'baseline' | 'candidate',
  eligibleAuthors: ReadonlySet<string> | undefined,
): AsyncGenerator<{ coordinate: string; event: RawEvent }> {
  let previousCoordinate: string | null = null;
  for await (const entry of reader.streamCurrentState!(root, kind)) {
    const scannedKey = source === 'baseline' ? 'baselineScanned' : 'candidateScanned';
    const validKey = source === 'baseline' ? 'baselineValid' : 'candidateValid';
    const invalidKey = source === 'baseline' ? 'baselineInvalid' : 'candidateInvalid';
    report[scannedKey] = increment(report[scannedKey], `kind ${kind} ${source} scanned`);
    if (previousCoordinate !== null && compareText(previousCoordinate, entry.coordinate) >= 0) {
      throw new Error(`Kind ${kind} ${source} current-state stream is not strictly ordered`);
    }
    previousCoordinate = entry.coordinate;
    if (eligibleAuthors && !eligibleAuthors.has(entry.event.pubkey)) {
      recordExcludedAuthor(report, source, kind);
      continue;
    }
    if (!isValidKindEvent(entry.event, kind)
      || getSocialEventCoordinate(entry.event) !== entry.coordinate) {
      report[invalidKey] = increment(report[invalidKey], `kind ${kind} ${source} invalid`);
      continue;
    }
    report[validKey] = increment(report[validKey], `kind ${kind} ${source} valid`);
    yield entry;
  }
}

async function* validKindEvents(
  reader: PostSearchSnapshotReader,
  root: CID,
  kind: number,
  report: NostrArchiveKindMonotonicity,
  source: 'baseline' | 'candidate',
  eligibleAuthors: ReadonlySet<string> | undefined,
): AsyncGenerator<RawEvent> {
  let previous: RawEvent | null = null;
  for await (const event of reader.streamKind(root, kind)) {
    const scannedKey = source === 'baseline' ? 'baselineScanned' : 'candidateScanned';
    const validKey = source === 'baseline' ? 'baselineValid' : 'candidateValid';
    const invalidKey = source === 'baseline' ? 'baselineInvalid' : 'candidateInvalid';
    report[scannedKey] = increment(report[scannedKey], `kind ${kind} ${source} scanned`);
    if (eligibleAuthors && !eligibleAuthors.has(event.pubkey)) {
      recordExcludedAuthor(report, source, kind);
      continue;
    }
    if (!isValidKindEvent(event, kind)) {
      report[invalidKey] = increment(report[invalidKey], `kind ${kind} ${source} invalid`);
      continue;
    }
    assertComparableArchiveEvent(event, kind, source);
    if (previous && compareArchiveEvents(previous, event) >= 0) {
      throw new Error(`Kind ${kind} ${source} valid event stream is not strictly ordered`);
    }
    report[validKey] = increment(report[validKey], `kind ${kind} ${source} valid`);
    previous = event;
    yield event;
  }
}

function assertComparableArchiveEvent(
  event: RawEvent,
  kind: number,
  source: 'baseline' | 'candidate',
): void {
  if (!Number.isSafeInteger(event.created_at)
    || event.created_at < 0
    || !HEX_64.test(event.id)) {
    throw new Error(`Kind ${kind} ${source} valid event has unsupported ordering fields`);
  }
}

function compareArchiveEvents(left: RawEvent, right: RawEvent): number {
  if (left.created_at !== right.created_at) {
    return left.created_at > right.created_at ? -1 : 1;
  }
  if (left.id === right.id) {
    return 0;
  }
  return left.id < right.id ? -1 : 1;
}

function recordMissingBaselineEvent(
  report: NostrArchiveKindMonotonicity,
  eventId: string,
): void {
  report.missingValid = increment(report.missingValid, `kind ${report.kind} missing valid`);
  if (report.missingEventIds.length < MAX_MISSING_EVENT_ID_SAMPLES) {
    report.missingEventIds.push(eventId);
  }
}

function recordExcludedAuthor(
  report: NostrArchiveKindMonotonicity,
  source: 'baseline' | 'candidate',
  kind: number,
): void {
  const key = source === 'baseline'
    ? 'baselineExcludedAuthors'
    : 'candidateExcludedAuthors';
  report[key] = increment(report[key], `kind ${kind} ${source} excluded author events`);
}

function monotonicityFailure(report: NostrArchiveKindMonotonicity): string {
  if (report.policy === 'current-state-winner') {
    if (report.missingValid === 1) {
      return `kind ${report.kind} regressed or dropped 1 signature-valid current-state `
        + `coordinate; baseline event: ${report.missingEventIds[0]}`;
    }
    return `kind ${report.kind} regressed or dropped ${report.missingValid} signature-valid `
      + `current-state coordinates; first baseline event IDs: ${report.missingEventIds.join(',')}`;
  }
  if (report.missingValid === 1) {
    return `kind ${report.kind} dropped 1 signature-valid baseline event: `
      + report.missingEventIds[0];
  }
  return `kind ${report.kind} dropped ${report.missingValid} signature-valid baseline events; `
    + `first IDs: ${report.missingEventIds.join(',')}`;
}

function aggregateMonotonicity(
  kinds: readonly NostrArchiveKindMonotonicity[],
): NostrArchiveMonotonicityAggregate {
  return kinds.reduce<NostrArchiveMonotonicityAggregate>((aggregate, report) => ({
    baselineScanned: add(aggregate.baselineScanned, report.baselineScanned, 'baseline scanned'),
    baselineValid: add(aggregate.baselineValid, report.baselineValid, 'baseline valid'),
    baselineInvalid: add(aggregate.baselineInvalid, report.baselineInvalid, 'baseline invalid'),
    baselineExcludedAuthors: add(
      aggregate.baselineExcludedAuthors,
      report.baselineExcludedAuthors,
      'baseline excluded-author events',
    ),
    candidateScanned: add(
      aggregate.candidateScanned,
      report.candidateScanned,
      'candidate scanned',
    ),
    candidateValid: add(aggregate.candidateValid, report.candidateValid, 'candidate valid'),
    candidateInvalid: add(
      aggregate.candidateInvalid,
      report.candidateInvalid,
      'candidate invalid',
    ),
    candidateExcludedAuthors: add(
      aggregate.candidateExcludedAuthors,
      report.candidateExcludedAuthors,
      'candidate excluded-author events',
    ),
    retainedValid: add(aggregate.retainedValid, report.retainedValid, 'retained valid'),
    missingValid: add(aggregate.missingValid, report.missingValid, 'missing valid'),
  }), {
    baselineScanned: 0,
    baselineValid: 0,
    baselineInvalid: 0,
    baselineExcludedAuthors: 0,
    candidateScanned: 0,
    candidateValid: 0,
    candidateInvalid: 0,
    candidateExcludedAuthors: 0,
    retainedValid: 0,
    missingValid: 0,
  });
}

function validateEligibleAuthors(authors: ReadonlySet<string> | undefined): void {
  if (!authors) {
    return;
  }
  if (authors.size === 0 || [...authors].some((author) => !HEX_64.test(author))) {
    throw new Error('Nostr archive monotonicity eligible authors are invalid');
  }
}

function isValidKindEvent(event: RawEvent, expectedKind: number): boolean {
  return event.kind === expectedKind && verifyPostSearchEvent(event);
}

function normalizeRequiredKinds(values: readonly number[]): number[] {
  const kinds = [...new Set(values.map((value) => {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new Error('Nostr archive required kind must be a non-negative integer');
    }
    return value;
  }))].sort((left, right) => left - right);
  if (kinds.length === 0) {
    throw new Error('At least one Nostr archive required kind is required');
  }
  return kinds;
}

function increment(value: number, name: string): number {
  return add(value, 1, name);
}

function add(left: number, right: number, name: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Invalid Nostr archive ${name}`);
  }
  return result;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
