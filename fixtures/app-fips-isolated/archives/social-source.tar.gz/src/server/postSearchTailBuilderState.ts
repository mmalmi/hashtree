import { nhashDecode, nhashEncode } from '@hashtree/core';
import type { PersistedPostSearchSegment } from './postSearchBuilderSegments';
import {
  isPostSearchPointerHandoff,
  type PostSearchPointerHandoff,
} from './postSearchPointer';

export const POST_SEARCH_TAIL_BUILDER_STATE_FORMAT =
  'iris-social/post-search-tail-builder-state@1' as const;

export interface PostSearchTailBuilderState {
  format: typeof POST_SEARCH_TAIL_BUILDER_STATE_FORMAT;
  status: 'building' | 'complete';
  baseCatalogRoot: string;
  baseEventRoot: string;
  targetEventRoot: string;
  publisherId: string;
  treeName: string;
  configurationKey: string;
  generatedAt: number;
  tailEventCount: number;
  tailBytes: number;
  processedDocuments: number;
  appendedSegments: PersistedPostSearchSegment[];
  catalogRoot: string | null;
  handoff: PostSearchPointerHandoff | null;
}

export interface PostSearchTailBuilderStateStore {
  load(): Promise<PostSearchTailBuilderState | null>;
  save(state: PostSearchTailBuilderState): Promise<void>;
}

export function isPostSearchTailBuilderState(value: unknown): value is PostSearchTailBuilderState {
  if (!isObject(value)
    || value.format !== POST_SEARCH_TAIL_BUILDER_STATE_FORMAT
    || (value.status !== 'building' && value.status !== 'complete')
    || !canonicalRoot(value.baseCatalogRoot)
    || !canonicalRoot(value.baseEventRoot)
    || !canonicalRoot(value.targetEventRoot)
    || typeof value.publisherId !== 'string'
    || typeof value.treeName !== 'string'
    || typeof value.configurationKey !== 'string'
    || !nonNegativeInteger(value.generatedAt)
    || !nonNegativeInteger(value.tailEventCount)
    || !nonNegativeInteger(value.tailBytes)
    || !nonNegativeInteger(value.processedDocuments)
    || !Array.isArray(value.appendedSegments)) {
    return false;
  }
  try {
    for (const raw of value.appendedSegments) {
      const segment = raw as PersistedPostSearchSegment;
      nhashDecode(segment.root);
      if (segment.routingRoot) {
        nhashDecode(segment.routingRoot);
      }
      if (!nonNegativeInteger(segment.documentCount)) {
        return false;
      }
    }
    if (value.catalogRoot !== null && !canonicalRoot(value.catalogRoot)) {
      return false;
    }
    if (value.status === 'complete') {
      return value.catalogRoot !== null
        && isPostSearchPointerHandoff(value.handoff)
        && value.handoff.catalogRoot === value.catalogRoot
        && value.handoff.sourceEventRoot === value.targetEventRoot
        && value.handoff.publisherId === value.publisherId
        && value.handoff.treeName === value.treeName;
    }
    return value.catalogRoot === null && value.handoff === null;
  } catch {
    return false;
  }
}

function canonicalRoot(value: unknown): value is string {
  if (typeof value !== 'string') {
    return false;
  }
  try {
    return nhashEncode(nhashDecode(value)) === value;
  } catch {
    return false;
  }
}

function nonNegativeInteger(value: unknown): boolean {
  return Number.isSafeInteger(value) && Number(value) >= 0;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
