import { realpath, stat } from 'node:fs/promises';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';

export type NamedCliPath = {
  label: string;
  path: string;
};

/** Resolve existing symlinks while preserving a not-yet-created final path. */
export async function canonicalProspectiveCliPath(path: string): Promise<string> {
  const target = resolve(path);
  try {
    return await realpath(target);
  } catch (error) {
    if (!isErrno(error, 'ENOENT')) {
      throw error;
    }
  }
  const parent = dirname(target);
  return parent === target
    ? target
    : join(await canonicalProspectiveCliPath(parent), basename(target));
}

/** Fail before a mutable artifact or lock can replace any other named path. */
export async function assertDisjointMutableCliPaths(
  paths: readonly NamedCliPath[],
  mutableLabels: ReadonlySet<string>,
): Promise<Map<string, string>> {
  const canonical = new Map<string, string>();
  for (const entry of paths) {
    if (canonical.has(entry.label)) {
      throw new Error(`Duplicate CLI path label: ${entry.label}`);
    }
    canonical.set(entry.label, await canonicalProspectiveCliPath(entry.path));
  }

  for (let left = 0; left < paths.length; left += 1) {
    for (let right = left + 1; right < paths.length; right += 1) {
      const first = paths[left];
      const second = paths[right];
      if (
        canonical.get(first.label) === canonical.get(second.label)
        && (mutableLabels.has(first.label) || mutableLabels.has(second.label))
      ) {
        throw new Error(`${first.label} and ${second.label} must be different paths`);
      }
    }
  }

  for (const entry of paths) {
    if (!mutableLabels.has(entry.label)) {
      continue;
    }
    const path = canonical.get(entry.label)!;
    try {
      if ((await stat(path)).isDirectory()) {
        throw new Error(`${entry.label} must not be a directory`);
      }
    } catch (error) {
      if (!isErrno(error, 'ENOENT')) {
        throw error;
      }
    }
  }
  return canonical;
}

export function assertCliPathsOutsideDirectory(
  paths: ReadonlyMap<string, string>,
  directoryLabel: string,
): void {
  const directory = paths.get(directoryLabel);
  if (!directory) {
    return;
  }
  for (const [label, path] of paths) {
    if (label !== directoryLabel && isInside(path, directory)) {
      throw new Error(`${label} must not be inside ${directoryLabel}`);
    }
  }
}

function isInside(candidate: string, directory: string): boolean {
  const path = relative(resolve(directory), resolve(candidate));
  return path === '' || (!path.startsWith(`..${sep}`) && path !== '..' && !isAbsolute(path));
}

function isErrno(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code;
}
