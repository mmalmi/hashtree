import { nhashDecode, nhashEncode } from '@hashtree/core';
import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from '../lib/nostr';
import type { HttpBlockStoreCredentials } from './httpBlockStore';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_PIN_TIMEOUT_MS = 600_000;

export interface HashtreePinResult {
  indexedHashes: number;
  totalSize: number;
  alreadyPinned: boolean;
}

export async function publishSignedNostrEventToHashtree(
  event: RawEvent,
  daemonUrl: string,
  options: {
    fetch?: typeof fetch;
    timeoutMs?: number;
    label?: string;
    acknowledgementLabel?: string;
  } = {},
): Promise<void> {
  const label = options.label ?? 'Nostr event';
  const acknowledgementLabel = options.acknowledgementLabel ?? label;
  if (!verifyEvent(event)) {
    throw new Error(`Refusing to publish an invalid ${label} event`);
  }
  const baseUrl = loopbackHashtreeDaemonUrl(daemonUrl, `${label} publication`);
  const response = await (options.fetch ?? fetch)(`${baseUrl}/api/nostr/events`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(event),
    signal: AbortSignal.timeout(positiveInteger(options.timeoutMs ?? DEFAULT_TIMEOUT_MS)),
  });
  if (response.status !== 202) {
    throw new Error(`Hashtree daemon rejected ${label} with HTTP ${response.status}`);
  }
  let result: unknown;
  try {
    result = await response.json();
  } catch {
    throw new Error(
      `Hashtree daemon returned an invalid ${acknowledgementLabel} publish acknowledgement`,
    );
  }
  if (
    typeof result !== 'object'
    || result === null
    || (result as Record<string, unknown>).accepted !== true
  ) {
    throw new Error(
      `Hashtree daemon returned an invalid ${acknowledgementLabel} publish acknowledgement`,
    );
  }
}

/** Authenticated loopback full-DAG validation/indexing/retention gate. */
export async function pinHashtreeTree(
  root: string,
  daemonUrl: string,
  credentials: HttpBlockStoreCredentials,
  options: {
    fetch?: typeof fetch;
    timeoutMs?: number;
    label?: string;
    acknowledgementLabel?: string;
  } = {},
): Promise<HashtreePinResult> {
  const label = options.label ?? 'Hashtree tree';
  const acknowledgementLabel = options.acknowledgementLabel ?? label;
  let canonicalRoot: string;
  try {
    canonicalRoot = nhashEncode(nhashDecode(root));
  } catch {
    throw new Error(`Invalid ${label} root`);
  }
  if (canonicalRoot !== root) {
    throw new Error(`Invalid ${label} root`);
  }

  const baseUrl = loopbackHashtreeDaemonUrl(daemonUrl, `${label} publication`);
  const response = await (options.fetch ?? fetch)(`${baseUrl}/api/pin-tree`, {
    method: 'POST',
    headers: {
      authorization: basicAuthorization(credentials),
      'content-type': 'application/json',
    },
    body: JSON.stringify({ nhash: canonicalRoot }),
    signal: AbortSignal.timeout(positiveInteger(options.timeoutMs ?? DEFAULT_PIN_TIMEOUT_MS)),
  });
  if (response.status !== 200) {
    const capacity = response.status === 413
      ? ' (authenticated full-DAG capacity exceeded)'
      : '';
    throw new Error(
      `Hashtree daemon rejected ${label} pin with HTTP ${response.status}${capacity}`,
    );
  }

  let result: unknown;
  try {
    result = await response.json();
  } catch {
    throw new Error(
      `Hashtree daemon returned an invalid ${acknowledgementLabel} pin acknowledgement`,
    );
  }
  if (typeof result !== 'object' || result === null) {
    throw new Error(
      `Hashtree daemon returned an invalid ${acknowledgementLabel} pin acknowledgement`,
    );
  }
  const acknowledgement = result as Record<string, unknown>;
  if (
    acknowledgement.success !== true
    || acknowledgement.nhash !== canonicalRoot
    || !Number.isSafeInteger(acknowledgement.indexed_hashes)
    || (acknowledgement.indexed_hashes as number) <= 0
    || !Number.isSafeInteger(acknowledgement.total_size)
    || (acknowledgement.total_size as number) < 0
    || typeof acknowledgement.already_pinned !== 'boolean'
  ) {
    throw new Error(
      `Hashtree daemon returned an invalid ${acknowledgementLabel} pin acknowledgement`,
    );
  }
  return {
    indexedHashes: acknowledgement.indexed_hashes as number,
    totalSize: acknowledgement.total_size as number,
    alreadyPinned: acknowledgement.already_pinned,
  };
}

export function loopbackHashtreeDaemonUrl(value: string, label = 'Hashtree publication'): string {
  const url = new URL(value);
  const loopback = url.hostname === '127.0.0.1'
    || url.hostname === 'localhost'
    || url.hostname === '[::1]';
  if (
    url.protocol !== 'http:'
    || !loopback
    || url.username
    || url.password
    || url.search
    || url.hash
    || (url.pathname !== '/' && url.pathname !== '')
  ) {
    throw new Error(`${label} requires a plain loopback HTTP daemon URL`);
  }
  return url.origin;
}

function positiveInteger(value: number): number {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error('Invalid Hashtree daemon publication timeout');
  }
  return value;
}

function basicAuthorization(credentials: HttpBlockStoreCredentials): string {
  if (!credentials.username
    || credentials.username.includes(':')
    || /[\r\n]/.test(credentials.username)
    || !credentials.password
    || /[\r\n]/.test(credentials.password)) {
    throw new Error('Invalid Hashtree daemon Basic-auth credentials');
  }
  return `Basic ${Buffer.from(
    `${credentials.username}:${credentials.password}`,
    'utf8',
  ).toString('base64')}`;
}
