import { createReadStream } from 'node:fs';
import { appendFile, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createInterface } from 'node:readline';

export type ExternalLineSortOptions = {
  chunkEntries: number;
  mergeFanIn: number;
  writeBufferBytes: number;
  emptyError?: string;
};

/** Deterministic bounded-memory UTF-8 line sorter with duplicate elimination. */
export class ExternalLineSorter {
  private readonly buffer: string[] = [];
  private readonly chunks: string[] = [];
  private chunkIndex = 0;

  constructor(
    private readonly directory: string,
    private readonly options: ExternalLineSortOptions,
  ) {}

  async append(value: string): Promise<void> {
    if (!value || value.includes('\n') || value.includes('\r')) {
      throw new Error('Invalid external-sort line');
    }
    this.buffer.push(value);
    if (this.buffer.length >= this.options.chunkEntries) {await this.flushChunk();}
  }

  async finish(): Promise<string> {
    await mkdir(this.directory, { recursive: true });
    await this.flushChunk();
    if (this.chunks.length === 0) {
      throw new Error(this.options.emptyError ?? 'External sort has no entries');
    }
    let files = [...this.chunks];
    let pass = 0;
    while (files.length > 1) {
      const next: string[] = [];
      for (let index = 0; index < files.length; index += this.options.mergeFanIn) {
        const group = files.slice(index, index + this.options.mergeFanIn);
        const output = join(
          this.directory,
          `merge-${pass.toString().padStart(3, '0')}-${next.length.toString().padStart(6, '0')}.txt`,
        );
        await mergeSortedLineFiles(group, output, this.options.writeBufferBytes);
        next.push(output);
      }
      for (const file of files) {await rm(file, { force: true });}
      files = next;
      pass += 1;
    }
    return files[0]!;
  }

  private async flushChunk(): Promise<void> {
    if (this.buffer.length === 0) {return;}
    await mkdir(this.directory, { recursive: true });
    this.buffer.sort();
    const path = join(
      this.directory,
      `chunk-${this.chunkIndex.toString().padStart(6, '0')}.txt`,
    );
    this.chunkIndex += 1;
    const deduped = this.buffer.filter((value, index) => (
      index === 0 || value !== this.buffer[index - 1]
    ));
    await writeFile(path, `${deduped.join('\n')}\n`, 'utf8');
    this.buffer.length = 0;
    this.chunks.push(path);
  }
}

export async function mergeSortedLineFiles(
  files: string[],
  output: string,
  writeBufferBytes: number,
): Promise<void> {
  const iterators = files.map((file) => lineIterator(file));
  const heads = await Promise.all(iterators.map(async (iterator) => await iterator.next()));
  const writer = new BufferedLineWriter(output, writeBufferBytes);
  await writer.open();
  let previous = '';
  try {
    while (true) {
      let selected = -1;
      for (let index = 0; index < heads.length; index += 1) {
        const head = heads[index]!;
        if (head.done) {continue;}
        if (selected < 0 || head.value < heads[selected]!.value) {selected = index;}
      }
      if (selected < 0) {break;}
      const value = heads[selected]!.value;
      if (value !== previous) {
        await writer.append(value);
        previous = value;
      }
      heads[selected] = await iterators[selected]!.next();
    }
  } finally {
    await writer.close();
  }
}

export class BufferedLineWriter {
  private readonly lines: string[] = [];
  private bytes = 0;
  private opened = false;

  constructor(private readonly path: string, private readonly maximumBytes: number) {
    if (!Number.isSafeInteger(maximumBytes) || maximumBytes <= 0) {
      throw new Error('Invalid external-sort write buffer');
    }
  }

  async open(): Promise<void> {
    await writeFile(this.path, '', 'utf8');
    this.opened = true;
  }

  async append(line: string): Promise<void> {
    if (!this.opened || !line || line.includes('\n') || line.includes('\r')) {
      throw new Error('Invalid buffered external-sort line');
    }
    const bytes = Buffer.byteLength(line, 'utf8') + 1;
    if (this.lines.length > 0 && this.bytes + bytes > this.maximumBytes) {await this.flush();}
    if (bytes > this.maximumBytes) {throw new Error('External-sort line exceeds write buffer');}
    this.lines.push(line);
    this.bytes += bytes;
  }

  async close(): Promise<void> {
    if (!this.opened) {return;}
    await this.flush();
    this.opened = false;
  }

  private async flush(): Promise<void> {
    if (this.lines.length === 0) {return;}
    await appendFile(this.path, `${this.lines.join('\n')}\n`, 'utf8');
    this.lines.length = 0;
    this.bytes = 0;
  }
}

export async function* lineIterator(path: string): AsyncGenerator<string> {
  const input = createReadStream(path, { encoding: 'utf8' });
  const lines = createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of lines) {
      if (line) {yield line;}
    }
  } finally {
    lines.close();
    input.destroy();
  }
}
