import {
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  type CID,
  type Store,
} from '@hashtree/core';
import { normalizePubkey } from '../lib/nostr';
import {
  normalizeProfileSearchText,
  projectProfileSearchIdentity,
} from '../lib/profileSearchIdentity';
import { profileSearchRank } from '../lib/profileSearchRanking';
import {
  openPostSearchV5PageRouter,
  readPostSearchV5PageRouter,
  type PostSearchV5PageRouter,
} from './postSearchV5PageRouter';
import {
  assertCanonicalLink,
  assertExactLinkNames,
  assertExpected,
  boundBranchLink,
  boundedInteger,
  boundedPrefix,
  boundedTerm,
  compareMode,
  compareText,
  parseManifest,
  parsePostingKey,
  parseStoredProfile,
  positiveInteger,
  postingPrefix,
  profileSearchV3PostingKey,
  profileSearchV3PostingsForIdentity,
  publicCid,
  queryTrigrams,
  readPublicBlock,
  safeAdd,
  searchWords,
  strictPubkey,
  uniqueRoutes,
} from './profileSearchV3RoutedRunCodec';
import {
  PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES,
  PROFILE_SEARCH_V3_MAX_QUERY_RESULTS,
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
  type ProfileSearchV3Hit,
  type ProfileSearchV3Posting,
  type ProfileSearchV3PostingMode,
  type ProfileSearchV3RoutedRunLookup,
  type ProfileSearchV3RoutedRunReadOptions,
  type ProfileSearchV3RunEnvelope,
  type ProfileSearchV3StoredProfile,
} from './profileSearchV3RoutedRunTypes';

const MANIFEST_ENTRY = 'manifest.json';
const PROFILE_ENTRY = 'profiles';
const POSTING_ENTRY = 'postings';
const ROOT_MAX_BYTES = 65_536;
const MANIFEST_MAX_BYTES = 65_536;
const PROFILE_CACHE_ENTRIES = 64;
const MAX_QUERY_TRIGRAMS = 12;

export async function openProfileSearchV3RoutedRun(
  store: Store,
  root: CID,
): Promise<ProfileSearchV3RoutedRunLookup> {
  return await openEnvelope(store, await readEnvelope(store, root));
}

/** Full authenticated DAG and signed-profile verification with bounded retained state. */
export async function readProfileSearchV3RoutedRun(
  store: Store,
  root: CID,
  options: ProfileSearchV3RoutedRunReadOptions = {},
): Promise<ProfileSearchV3RoutedRunLookup> {
  const envelope = await readEnvelope(store, root);
  assertExpected(envelope.manifest, options.expected ?? {});
  const maximum = options.maxReachableNodeCount === undefined
    ? PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
    : positiveInteger(options.maxReachableNodeCount, 'maxReachableNodeCount');
  if (envelope.manifest.reachableNodeCount > maximum) {
    throw new Error('Profile-search v3 run exceeds its reachable-node capacity');
  }
  await Promise.all([
    readPostSearchV5PageRouter(store, envelope.roots.profiles,
      envelope.manifest.branches.profiles),
    readPostSearchV5PageRouter(store, envelope.roots.postings,
      envelope.manifest.branches.postings),
  ]);
  const lookup = await openEnvelope(store, envelope);
  const verifiedProfileRouter = await openPostSearchV5PageRouter(
    store,
    envelope.roots.profiles,
    envelope.manifest.branches.profiles,
  );
  await verifyRun(lookup, verifiedProfileRouter);
  return lookup;
}

async function openEnvelope(
  store: Store,
  envelope: ProfileSearchV3RunEnvelope,
): Promise<ProfileSearchV3RoutedRunLookup> {
  const profileRouter = await openPostSearchV5PageRouter(
    store,
    envelope.roots.profiles,
    envelope.manifest.branches.profiles,
  );
  const postingRouter = await openPostSearchV5PageRouter(
    store,
    envelope.roots.postings,
    envelope.manifest.branches.postings,
  );
  const getProfile = async (value: string) => {
    const pubkey = normalizePubkey(value);
    return pubkey ? await lookupProfile(profileRouter, pubkey) : null;
  };
  return {
    root: envelope.root,
    manifest: envelope.manifest,
    getProfile,
    search: async (query, limit = 20) => await searchRun(
      profileRouter,
      postingRouter,
      query,
      limit,
    ),
    streamProfiles: () => streamProfiles(profileRouter),
    streamPostings: () => streamPostings(postingRouter),
  };
}

async function readEnvelope(store: Store, root: CID): Promise<ProfileSearchV3RunEnvelope> {
  const rootBytes = await readPublicBlock(store, root, ROOT_MAX_BYTES, 'run root');
  let node;
  try {node = decodeTreeNode(rootBytes);} catch {
    throw new Error('Profile-search v3 run root is not a directory');
  }
  if (node.type !== LinkType.Dir || !equalBytes(encodeTreeNode(node), rootBytes)) {
    throw new Error('Profile-search v3 run root is not a canonical directory');
  }
  node.links.forEach(assertCanonicalLink);
  assertExactLinkNames(node.links, [MANIFEST_ENTRY, PROFILE_ENTRY, POSTING_ENTRY]);
  const manifestLink = node.links.find((link) => link.name === MANIFEST_ENTRY);
  if (!manifestLink || manifestLink.type !== LinkType.Blob) {
    throw new Error('Profile-search v3 run manifest link is missing');
  }
  const manifestBytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    MANIFEST_MAX_BYTES,
    'run manifest',
  );
  if (manifestLink.size !== manifestBytes.length) {
    throw new Error('Profile-search v3 run manifest link size is inconsistent');
  }
  const manifest = parseManifest(manifestBytes);
  return {
    root: publicCid(root, 'run root'),
    manifest,
    roots: {
      profiles: boundBranchLink(node.links, PROFILE_ENTRY, manifest.branches.profiles),
      postings: boundBranchLink(node.links, POSTING_ENTRY, manifest.branches.postings),
    },
  };
}

async function searchRun(
  profileRouter: PostSearchV5PageRouter,
  postingRouter: PostSearchV5PageRouter,
  rawQuery: string,
  rawLimit: number,
): Promise<ProfileSearchV3Hit[]> {
  const limit = boundedInteger(rawLimit, 1, PROFILE_SEARCH_V3_MAX_QUERY_RESULTS, 'query limit');
  const directPubkey = normalizePubkey(rawQuery);
  if (directPubkey) {
    const direct = await lookupProfile(profileRouter, directPubkey);
    return direct ? [{ ...direct, textScore: 14_000, matchedModes: ['identifier'] }] : [];
  }
  const query = boundedTerm(normalizeProfileSearchText(rawQuery), 'query');
  if (!query) {return [];}
  const candidates = new Map<string, Set<ProfileSearchV3PostingMode>>();
  const routeLimit = Math.min(PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES, Math.max(32, limit * 8));
  // Probe the longest word first: it is normally the most selective and avoids
  // a common first name exhausting the bounded candidate budget before a rarer
  // surname can contribute candidates.
  const words = searchWords(query).sort((left, right) => right.length - left.length
    || compareText(left, right));
  const primaryRoutes = uniqueRoutes([
    { mode: 'nip05', term: query },
    { mode: 'identity', term: query },
    ...(words.length === 1 ? [{ mode: 'word' as const, term: words[0]! }] : []),
    ...words.flatMap((word) => [
      { mode: 'word' as const, term: word },
      { mode: 'prefix' as const, term: boundedPrefix(word) },
    ]),
  ]);
  for (const route of primaryRoutes) {
    await collectRoute(postingRouter, route, routeLimit, candidates);
    if (candidates.size >= PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES) {break;}
  }
  if (candidates.size < routeLimit) {
    for (const gram of queryTrigrams(query).slice(0, MAX_QUERY_TRIGRAMS)) {
      await collectRoute(
        postingRouter,
        { mode: 'trigram', term: gram },
        Math.max(16, limit * 4),
        candidates,
      );
      if (candidates.size >= PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES) {break;}
    }
  }
  const hits: ProfileSearchV3Hit[] = [];
  for (const [pubkey, modes] of candidates) {
    const stored = await lookupProfile(profileRouter, pubkey);
    if (!stored) {continue;}
    const textScore = profileSearchRank(stored.profile, rawQuery).textScore;
    if (textScore > 0) {
      hits.push({ ...stored, textScore, matchedModes: [...modes].sort(compareMode) });
    }
  }
  hits.sort((left, right) => (
    right.textScore - left.textScore
    || left.rankHint - right.rankHint
    || right.event.created_at - left.event.created_at
    || compareText(left.event.pubkey, right.event.pubkey)
  ));
  return hits.slice(0, limit);
}

async function collectRoute(
  router: PostSearchV5PageRouter,
  route: { mode: ProfileSearchV3PostingMode; term: string },
  limit: number,
  candidates: Map<string, Set<ProfileSearchV3PostingMode>>,
): Promise<void> {
  if (!route.term) {return;}
  const prefix = postingPrefix(route.mode, route.term);
  let read = 0;
  for await (const routed of router.rangePages(prefix, `${prefix}\uffff`)) {
    for (const [key, value] of routed.page.entries) {
      if (!key.startsWith(prefix)) {continue;}
      if (value !== '') {throw new Error('Profile-search v3 posting value is not canonical');}
      const posting = parsePostingKey(key);
      const modes = candidates.get(posting.pubkey) ?? new Set<ProfileSearchV3PostingMode>();
      modes.add(posting.mode);
      candidates.set(posting.pubkey, modes);
      read += 1;
      if (read >= limit || candidates.size >= PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES) {return;}
    }
  }
}

async function lookupProfile(
  router: PostSearchV5PageRouter,
  pubkey: string,
  verifySignature = true,
): Promise<ProfileSearchV3StoredProfile | null> {
  const normalized = strictPubkey(pubkey, 'profile pubkey');
  const page = await router.lookupPage(normalized);
  const entry = page?.page.entries.find(([key]) => key === normalized);
  return entry ? parseStoredProfile(entry[1], normalized, verifySignature) : null;
}

async function* streamProfiles(
  router: PostSearchV5PageRouter,
): AsyncGenerator<ProfileSearchV3StoredProfile> {
  for await (const routed of router.rangePages(router.minKey, router.maxKey)) {
    for (const [pubkey, raw] of routed.page.entries) {yield parseStoredProfile(raw, pubkey, true);}
  }
}

async function* streamPostings(
  router: PostSearchV5PageRouter,
): AsyncGenerator<ProfileSearchV3Posting> {
  for await (const routed of router.rangePages(router.minKey, router.maxKey)) {
    for (const [key, value] of routed.page.entries) {
      if (value !== '') {throw new Error('Profile-search v3 posting value is not canonical');}
      yield parsePostingKey(key);
    }
  }
}

async function verifyRun(
  lookup: ProfileSearchV3RoutedRunLookup,
  verifiedProfileRouter: PostSearchV5PageRouter,
): Promise<void> {
  const coverage = new Map<string, { expected: number; seen: number; rankHint: number }>();
  let profileCount = 0;
  let minimumRankHint = Number.MAX_SAFE_INTEGER;
  let maximumRankHint = 0;
  for await (const profile of lookup.streamProfiles()) {
    profileCount = safeAdd(profileCount, 1, 'verified profile count');
    minimumRankHint = Math.min(minimumRankHint, profile.rankHint);
    maximumRankHint = Math.max(maximumRankHint, profile.rankHint);
    coverage.set(profile.event.pubkey, {
      expected: profileSearchV3PostingsForIdentity(
        profile.event,
        profile.rankHint,
        projectProfileSearchIdentity(profile.event)!,
      ).length,
      seen: 0,
      rankHint: profile.rankHint,
    });
  }
  if (profileCount !== lookup.manifest.profileCount
    || minimumRankHint !== lookup.manifest.minimumRankHint
    || maximumRankHint !== lookup.manifest.maximumRankHint) {
    throw new Error('Profile-search v3 profile coverage mismatch');
  }
  const cache = new Map<string, { rankHint: number; postingKeys: ReadonlySet<string> }>();
  let postingCount = 0;
  for await (const posting of lookup.streamPostings()) {
    postingCount = safeAdd(postingCount, 1, 'verified posting count');
    const counts = coverage.get(posting.pubkey);
    if (!counts) {throw new Error('Profile-search v3 posting document is missing');}
    counts.seen = safeAdd(counts.seen, 1, 'per-profile posting coverage');
    if (counts.seen > counts.expected) {
      throw new Error('Profile-search v3 profile posting coverage exceeds its projection');
    }
    let projection = cache.get(posting.pubkey);
    if (!projection) {
      // The complete profile branch was hash-checked and every signature was
      // verified in the pass above. Re-reading one immutable profile here does
      // not repeat Schnorr verification for every posting in a large index.
      const profile = await lookupProfile(verifiedProfileRouter, posting.pubkey, false);
      if (!profile) {throw new Error('Profile-search v3 posting document is missing');}
      projection = {
        rankHint: profile.rankHint,
        postingKeys: new Set(profileSearchV3PostingsForIdentity(
          profile.event,
          profile.rankHint,
          projectProfileSearchIdentity(profile.event)!,
        ).map(profileSearchV3PostingKey)),
      };
      cache.set(posting.pubkey, projection);
      if (cache.size > PROFILE_CACHE_ENTRIES) {cache.delete(cache.keys().next().value!);}
    }
    if (counts.rankHint !== posting.rankHint || projection.rankHint !== posting.rankHint) {
      throw new Error('Profile-search v3 posting rank does not match its profile');
    }
    if (!projection.postingKeys.has(profileSearchV3PostingKey(posting))) {
      throw new Error('Profile-search v3 posting is not derived from its signed profile');
    }
  }
  if (postingCount !== lookup.manifest.postingCount) {
    throw new Error('Profile-search v3 posting coverage mismatch');
  }
  for (const { expected, seen } of coverage.values()) {
    if (seen !== expected) {
      throw new Error('Profile-search v3 profile posting coverage is incomplete');
    }
  }
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {return false;}
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
