import { createHash } from 'node:crypto';
import { nhashDecode, nhashEncode, type CID, type Store } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import { createPostSearchDocument } from '../lib/postSearchCatalog';
import {
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_KINDS,
  POST_SEARCH_VISIBLE_PROJECTION,
} from '../lib/postSearchCatalogConstants';
import {
  POST_SEARCH_AUTHOR_DELETION_POLICY,
  PostSearchAuthorTermsResolver,
} from './postSearchAuthorTerms';
import {
  createPostSearchKindReport,
  isSelectedPostSearchWinner,
  scanPostSearchDeletions,
  selectPostSearchAddressableWinners,
  verifyPostSearchEvent,
  visiblePostSearchEvent,
  type PostSearchDeletionProjection,
  type PostSearchEventVerifier,
  type PostSearchKindReport,
  type PostSearchSnapshotReader,
} from './postSearchProjection';
import {
  POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
  parsePostSearchV5RoutedBuilderState,
  type PostSearchV5RoutedBuilderState,
  type PostSearchV5RoutedBuilderStateStore,
  type PostSearchV5RoutedSourceBatch,
} from './postSearchV5RoutedBuilderState';
import { buildPostSearchV5RoutedBaseRun } from './postSearchV5RoutedBaseRunBuilder';
import {
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  openPostSearchV5RoutedCatalog,
  writePostSearchV5RoutedCatalog,
  type PostSearchV5RoutedCatalogLookup,
  type PostSearchV5RoutedCatalogRunInput,
  type PostSearchV5RoutedCoverage,
} from './postSearchV5RoutedCatalog';
import { compactPostSearchV5RoutedRuns } from './postSearchV5RoutedCompactor';
import {
  appendPostSearchV5BatchRun,
  completePostSearchV5Compaction,
  createPostSearchV5LeveledRunState,
  planPostSearchV5Publication,
  postSearchV5RunCatalog,
} from './postSearchV5LeveledRuns';
import {
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  openPostSearchV5RoutedRun,
  type PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRun';
import { POST_SEARCH_V5_RUN_MAX_DOCUMENTS } from './postSearchV5Run';

const DEFAULT_BATCH_SIZE = 5_000;
const DEFAULT_BATCH_MAX_BYTES = 64 * 1024 * 1024;
const DEFAULT_PROGRESS_EVENTS = 1_000;
const ADDRESSABLE_KIND_MIN = 30_000;
const ADDRESSABLE_KIND_MAX = 40_000;
const HEX_64 = /^[0-9a-f]{64}$/;
const encoder = new TextEncoder();

export type PostSearchV5RoutedBuilderPhase =
  | 'scanning-deletions'
  | 'selecting-winners'
  | 'building-runs'
  | 'compacting'
  | 'writing-catalog'
  | 'complete';

export interface PostSearchV5RoutedBuilderProgress {
  phase: PostSearchV5RoutedBuilderPhase;
  kind: number | null;
  scanned: number;
  visible: number;
  persistedDocuments: number;
  batchCount: number;
  updatedAt: number;
}

export interface PostSearchV5RoutedCatalogBuilderOptions {
  snapshotRoot: CID;
  snapshotReader: PostSearchSnapshotReader;
  outputStore: Store;
  stateStore: PostSearchV5RoutedBuilderStateStore;
  publisherId: string;
  batchSize?: number;
  batchMaxBytes?: number;
  progressEvents?: number;
  now?: () => number;
  verifyEvent?: PostSearchEventVerifier;
  onProgress?: (progress: PostSearchV5RoutedBuilderProgress) => void;
}

export interface PostSearchV5RoutedCatalogBuildResult {
  catalogRoot: CID;
  catalog: PostSearchV5RoutedCatalogLookup;
  state: PostSearchV5RoutedBuilderState;
  resumed: boolean;
}

export class PostSearchV5RoutedCatalogBuilder {
  private readonly options: PostSearchV5RoutedCatalogBuilderOptions & {
    batchSize: number;
    batchMaxBytes: number;
    progressEvents: number;
    now: () => number;
    verifyEvent: PostSearchEventVerifier;
  };
  private readonly sourceEventRoot: string;
  private readonly configurationSha256: string;
  private readonly authorTerms: PostSearchAuthorTermsResolver;

  constructor(options: PostSearchV5RoutedCatalogBuilderOptions) {
    if (!HEX_64.test(options.publisherId)) {
      throw new Error('Invalid post-search v5 routed builder publisherId');
    }
    const batchSize = boundedPositiveInteger(
      options.batchSize ?? DEFAULT_BATCH_SIZE,
      POST_SEARCH_V5_RUN_MAX_DOCUMENTS,
      'batchSize',
    );
    const batchMaxBytes = boundedPositiveInteger(
      options.batchMaxBytes ?? DEFAULT_BATCH_MAX_BYTES,
      1024 * 1024 * 1024,
      'batchMaxBytes',
    );
    this.options = {
      ...options,
      batchSize,
      batchMaxBytes,
      progressEvents: boundedPositiveInteger(
        options.progressEvents ?? DEFAULT_PROGRESS_EVENTS,
        Number.MAX_SAFE_INTEGER,
        'progressEvents',
      ),
      now: options.now ?? (() => Math.floor(Date.now() / 1_000)),
      verifyEvent: options.verifyEvent ?? verifyPostSearchEvent,
    };
    this.sourceEventRoot = nhashEncode(publicCid(options.snapshotRoot, 'snapshotRoot'));
    this.configurationSha256 = sha256(JSON.stringify({
      stateFormat: POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
      catalogFormat: POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
      runFormat: POST_SEARCH_V5_ROUTED_RUN_FORMAT,
      visibleProjection: POST_SEARCH_VISIBLE_PROJECTION,
      authorTermsProjection: POST_SEARCH_AUTHOR_TERMS_PROJECTION,
      authorDeletionPolicy: POST_SEARCH_AUTHOR_DELETION_POLICY,
      buildOptions: POST_SEARCH_BUILD_OPTIONS,
      batchSize,
      batchMaxBytes,
    }));
    this.authorTerms = new PostSearchAuthorTermsResolver({
      snapshotRoot: options.snapshotRoot,
      snapshotReader: options.snapshotReader,
      verifyEvent: this.options.verifyEvent,
    });
  }

  async build(): Promise<PostSearchV5RoutedCatalogBuildResult> {
    await this.options.snapshotReader.validateSnapshot?.(this.options.snapshotRoot);
    const loaded = await this.options.stateStore.load();
    const reusable = loaded
      && this.isReusableState(loaded)
      && await this.hasPersistedRoots(loaded);
    if (reusable && loaded.status === 'complete' && loaded.catalogRoot) {
      const catalogRoot = nhashDecode(loaded.catalogRoot);
      const catalog = await openPostSearchV5RoutedCatalog(this.options.outputStore, catalogRoot);
      return { catalogRoot, catalog, state: loaded, resumed: true };
    }
    const state = reusable ? loaded : this.initialState();
    const resumed = Boolean(reusable);
    const deletions = await this.scanDeletions(state);
    for (const kind of POST_SEARCH_KINDS) {
      if (state.completedKinds.includes(kind)) {continue;}
      await this.buildKind(kind, deletions, state);
      state.completedKinds.push(kind);
      await this.save(state);
    }
    this.emit('writing-catalog', null, 0, 0, state);
    const catalog = await this.writeCatalog(state);
    state.status = 'complete';
    state.catalogRoot = nhashEncode(catalog.root);
    await this.save(state);
    this.emit('complete', null, 0, state.batches.reduce(
      (sum, batch) => safeAdd(sum, batch.documentCount, 'document count'), 0,
    ), state);
    return { catalogRoot: catalog.root, catalog, state, resumed };
  }

  private async scanDeletions(
    state: PostSearchV5RoutedBuilderState,
  ): Promise<PostSearchDeletionProjection> {
    this.emit('scanning-deletions', 5, 0, 0, state);
    let processed = 0;
    const deletions = await scanPostSearchDeletions(
      this.options.snapshotReader,
      this.options.snapshotRoot,
      this.options.verifyEvent,
      (report) => {
        processed += 1;
        if (processed % this.options.progressEvents === 0) {
          this.emit('scanning-deletions', 5, report.scanned, 0, state);
        }
      },
    );
    state.deletionReport = { ...deletions.report };
    await this.save(state);
    return deletions;
  }

  private async buildKind(
    kind: number,
    deletions: PostSearchDeletionProjection,
    state: PostSearchV5RoutedBuilderState,
  ): Promise<void> {
    const report = createPostSearchKindReport();
    const durableDocuments = state.batches
      .filter((batch) => batch.kind === kind)
      .reduce((sum, batch) => safeAdd(sum, batch.documentCount, 'durable documents'), 0);
    let winners: Map<string, { createdAt: number; eventId: string }> | null = null;
    let processed = 0;
    if (kind >= ADDRESSABLE_KIND_MIN && kind < ADDRESSABLE_KIND_MAX) {
      this.emit('selecting-winners', kind, 0, 0, state);
      winners = await selectPostSearchAddressableWinners(
        this.options.snapshotReader,
        this.options.snapshotRoot,
        kind,
        deletions,
        report,
        this.options.verifyEvent,
        () => {
          processed += 1;
          if (processed % this.options.progressEvents === 0) {
            this.emit('selecting-winners', kind, report.scanned, report.visible, state);
          }
        },
      );
    }
    let batch: RawEvent[] = [];
    let batchBytes = 0;
    let visibleOrdinal = 0;
    const flush = async (): Promise<void> => {
      if (batch.length === 0) {return;}
      await this.persistBatch(batch, kind, report, deletions, state);
      batch = [];
      batchBytes = 0;
    };
    for await (const event of this.options.snapshotReader.streamKind(
      this.options.snapshotRoot,
      kind,
    )) {
      const visible = winners
        ? isSelectedPostSearchWinner(event, winners, this.options.verifyEvent)
        : visiblePostSearchEvent(event, deletions, report, this.options.verifyEvent);
      if (visible) {
        report.visible += 1;
        visibleOrdinal += 1;
        if (visibleOrdinal > durableDocuments) {
          const bytes = encoder.encode(JSON.stringify(event)).length;
          if (bytes > this.options.batchMaxBytes) {
            throw new Error(`Post-search v5 routed event exceeds batchMaxBytes: ${event.id}`);
          }
          if (batch.length > 0 && (batch.length >= this.options.batchSize
            || batchBytes + bytes > this.options.batchMaxBytes)) {
            await flush();
          }
          batch.push(event);
          batchBytes += bytes;
        }
      }
      processed += 1;
      if (processed % this.options.progressEvents === 0) {
        this.emit('building-runs', kind, report.scanned, report.visible, state);
      }
    }
    await flush();
    if (report.visible < durableDocuments) {
      throw new Error(`Post-search v5 routed durable kind ${kind} exceeds immutable snapshot`);
    }
    state.kindReports[String(kind)] = { ...report };
  }

  private async persistBatch(
    events: readonly RawEvent[],
    kind: number,
    report: PostSearchKindReport,
    deletions: PostSearchDeletionProjection,
    state: PostSearchV5RoutedBuilderState,
  ): Promise<void> {
    await this.compactUntilAppendable(state);
    const authorNames = await this.authorTerms.resolve(events, deletions);
    const documents = events.map((event) =>
      createPostSearchDocument(event, authorNames[event.pubkey]));
    const run = await buildPostSearchV5RoutedBaseRun(
      this.options.outputStore,
      documents,
      { maxDocuments: this.options.batchSize },
    );
    const batch = state.batches.length;
    state.leveledRuns = appendPostSearchV5BatchRun(state.leveledRuns, {
      batch,
      root: nhashEncode(run.root),
      documentCount: events.length,
    });
    const timestamps = events.map((event) => event.created_at);
    state.batches.push({
      batch,
      documentCount: events.length,
      kind,
      since: Math.min(...timestamps),
      until: Math.max(...timestamps),
    });
    state.kindReports[String(kind)] = { ...report };
    await this.save(state);
    await this.compactAll(state);
    this.emit('building-runs', kind, report.scanned, report.visible, state);
  }

  private async compactUntilAppendable(state: PostSearchV5RoutedBuilderState): Promise<void> {
    while (!planPostSearchV5Publication(state.leveledRuns).canAppendBatch) {
      if (!await this.compactOne(state)) {
        throw new Error('Post-search v5 routed compaction cannot admit the next source batch');
      }
    }
  }

  private async compactAll(state: PostSearchV5RoutedBuilderState): Promise<void> {
    while (await this.compactOne(state)) {
      // Drain the deterministic binary carry before reading another source batch.
    }
  }

  private async compactOne(state: PostSearchV5RoutedBuilderState): Promise<boolean> {
    const task = planPostSearchV5Publication(state.leveledRuns).runnableTasks[0];
    if (!task) {return false;}
    this.emit('compacting', null, 0, 0, state);
    const output = await compactPostSearchV5RoutedRuns(
      this.options.outputStore,
      nhashDecode(task.inputRoots[0]),
      nhashDecode(task.inputRoots[1]),
      {
        maxDocumentCount: task.documentCount,
        maxInputReachableNodeCount: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
        maxOutputReachableNodeCount: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
      },
    );
    state.leveledRuns = completePostSearchV5Compaction(state.leveledRuns, {
      task,
      outputRoot: nhashEncode(output.root),
    }).state;
    await this.save(state);
    return true;
  }

  private async writeCatalog(
    state: PostSearchV5RoutedBuilderState,
  ): Promise<PostSearchV5RoutedCatalogLookup> {
    const active = postSearchV5RunCatalog(state.leveledRuns).runsNewestFirst;
    const runs: PostSearchV5RoutedCatalogRunInput[] = [];
    for (const descriptor of active) {
      const run = await openPostSearchV5RoutedRun(
        this.options.outputStore,
        nhashDecode(descriptor.root),
      );
      runs.push(this.catalogRun(descriptor, run, state.batches));
    }
    const built = await writePostSearchV5RoutedCatalog(this.options.outputStore, {
      publisherId: this.options.publisherId,
      generatedAt: state.generatedAt,
      batchSize: this.options.batchSize,
      source: {
        eventRoot: this.sourceEventRoot,
        projection: POST_SEARCH_VISIBLE_PROJECTION,
        coverage: coverage(state.batches),
      },
      runs,
      overlay: null,
      maxReachableNodeCount: POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
    });
    return await openPostSearchV5RoutedCatalog(this.options.outputStore, built.root);
  }

  private catalogRun(
    descriptor: ReturnType<typeof postSearchV5RunCatalog>['runsNewestFirst'][number],
    run: PostSearchV5RoutedRunLookup,
    batches: readonly PostSearchV5RoutedSourceBatch[],
  ): PostSearchV5RoutedCatalogRunInput {
    if (run.manifest.documentCount !== descriptor.documentCount
      || run.manifest.storedValueCount !== descriptor.documentCount) {
      throw new Error(`Post-search v5 routed run ${descriptor.id} lost stored documents`);
    }
    const source = coverage(batches.slice(
      descriptor.oldestBatch,
      descriptor.newestBatchExclusive,
    ));
    if (source.eventCount !== descriptor.documentCount
      || source.since === null || source.until === null) {
      throw new Error(`Post-search v5 routed run ${descriptor.id} source coverage is inconsistent`);
    }
    return {
      root: run.root,
      level: descriptor.level,
      oldestBatch: descriptor.oldestBatch,
      newestBatchExclusive: descriptor.newestBatchExclusive,
      documentCount: run.manifest.documentCount,
      postingCount: run.manifest.postingCount,
      postingPartCount: run.manifest.postingPartCount,
      termCount: run.manifest.termCount,
      storedValueCount: run.manifest.storedValueCount,
      tokenOccurrenceCount: run.manifest.tokenOccurrenceCount,
      pageCount: branchPageCount(run),
      reachableNodeCount: run.manifest.reachableNodeCount,
      kinds: source.kinds,
      since: source.since,
      until: source.until,
    };
  }

  private initialState(): PostSearchV5RoutedBuilderState {
    return {
      format: POST_SEARCH_V5_ROUTED_BUILDER_STATE_FORMAT,
      status: 'building',
      configurationSha256: this.configurationSha256,
      sourceEventRoot: this.sourceEventRoot,
      publisherId: this.options.publisherId,
      generatedAt: boundedNonNegativeInteger(this.options.now(), 'generatedAt'),
      completedKinds: [],
      batches: [],
      leveledRuns: createPostSearchV5LeveledRunState(this.options.batchSize),
      deletionReport: {
        scanned: 0,
        invalid: 0,
        valid: 0,
        exactTombstones: 0,
        addressTombstones: 0,
      },
      kindReports: {},
      catalogRoot: null,
    };
  }

  private isReusableState(state: PostSearchV5RoutedBuilderState): boolean {
    try {
      const parsed = parsePostSearchV5RoutedBuilderState(state);
      return parsed.configurationSha256 === this.configurationSha256
        && parsed.sourceEventRoot === this.sourceEventRoot
        && parsed.publisherId === this.options.publisherId;
    } catch {
      return false;
    }
  }

  private async hasPersistedRoots(state: PostSearchV5RoutedBuilderState): Promise<boolean> {
    try {
      const runs = postSearchV5RunCatalog(state.leveledRuns).runsNewestFirst;
      const opened = await Promise.all(runs.map(async (run) =>
        await openPostSearchV5RoutedRun(this.options.outputStore, nhashDecode(run.root))));
      if (opened.some((run, index) =>
        run.manifest.documentCount !== runs[index]!.documentCount)) {
        return false;
      }
      if (state.status === 'complete' && state.catalogRoot) {
        const catalog = await openPostSearchV5RoutedCatalog(
          this.options.outputStore,
          nhashDecode(state.catalogRoot),
        );
        return catalog.manifest.publisherId === state.publisherId
          && catalog.manifest.source.eventRoot === state.sourceEventRoot;
      }
      return true;
    } catch {
      return false;
    }
  }

  private async save(state: PostSearchV5RoutedBuilderState): Promise<void> {
    await this.options.stateStore.save(parsePostSearchV5RoutedBuilderState(state));
  }

  private emit(
    phase: PostSearchV5RoutedBuilderPhase,
    kind: number | null,
    scanned: number,
    visible: number,
    state: PostSearchV5RoutedBuilderState,
  ): void {
    this.options.onProgress?.({
      phase,
      kind,
      scanned,
      visible,
      persistedDocuments: state.batches.reduce(
        (sum, batch) => safeAdd(sum, batch.documentCount, 'persisted documents'), 0,
      ),
      batchCount: state.batches.length,
      updatedAt: boundedNonNegativeInteger(this.options.now(), 'progress updatedAt'),
    });
  }
}

function coverage(batches: readonly PostSearchV5RoutedSourceBatch[]): PostSearchV5RoutedCoverage {
  if (batches.length === 0) {
    return { eventCount: 0, kinds: [], since: null, until: null };
  }
  return {
    eventCount: batches.reduce(
      (sum, batch) => safeAdd(sum, batch.documentCount, 'coverage events'), 0,
    ),
    kinds: [...new Set(batches.map((batch) => batch.kind))].sort((a, b) => a - b),
    since: Math.min(...batches.map((batch) => batch.since)),
    until: Math.max(...batches.map((batch) => batch.until)),
  };
}

function branchPageCount(run: PostSearchV5RoutedRunLookup): number {
  return run.manifest.branches.documents.pageCount
    + (run.manifest.branches.postings?.pageCount ?? 0)
    + (run.manifest.branches.terms?.pageCount ?? 0);
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

function publicCid(cid: CID, label: string): CID {
  if (!(cid.hash instanceof Uint8Array) || cid.hash.length !== 32 || cid.key !== undefined) {
    throw new Error(`Invalid public post-search v5 routed ${label}`);
  }
  return { hash: new Uint8Array(cid.hash) };
}

function boundedPositiveInteger(value: number, maximum: number, label: string): number {
  if (!Number.isSafeInteger(value) || value <= 0 || value > maximum) {
    throw new Error(`Invalid post-search v5 routed builder ${label}`);
  }
  return value;
}

function boundedNonNegativeInteger(value: number, label: string): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid post-search v5 routed builder ${label}`);
  }
  return value;
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Post-search v5 routed builder ${label} exceeds capacity`);
  }
  return result;
}
