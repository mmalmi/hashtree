import type { CID } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import {
  POST_SEARCH_V5_PACKED_PAGE_FORMAT,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import type {
  PostSearchV5Posting,
  PostSearchV5RecordManifest,
  PostSearchV5StoredDocument,
  PostSearchV5TermStats,
} from './postSearchV5Run';

export const POST_SEARCH_V5_ROUTED_RUN_FORMAT =
  'iris-social/routed-post-search-run@2' as const;
export const POST_SEARCH_V5_POSTING_PART_WIDTH = 16;
export const POST_SEARCH_V5_ROUTED_RUN_MAX_MANIFEST_BYTES = 65_536;
export const POST_SEARCH_V5_ROUTED_NORMALIZATION = 'NFKC-lowercase@1' as const;

export interface PostSearchV5RoutedBranchManifest {
  pageKind: PostSearchV5PackedPageKind;
  entryCount: number;
  minKey: string;
  maxKey: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
}

export interface PostSearchV5RoutedRunManifest extends PostSearchV5RecordManifest {
  format: typeof POST_SEARCH_V5_ROUTED_RUN_FORMAT;
  packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  pageRouterFormat: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
  normalization: typeof POST_SEARCH_V5_ROUTED_NORMALIZATION;
  documentCount: number;
  termCount: number;
  postingCount: number;
  postingPartCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
  k1: number;
  fields: RankedSearchFieldManifest[];
  branches: {
    documents: PostSearchV5RoutedBranchManifest;
    postings: PostSearchV5RoutedBranchManifest | null;
    terms: PostSearchV5RoutedBranchManifest | null;
  };
  reachableNodeCount: number;
}

export interface PostSearchV5RoutedRunFinishInput {
  documentCount: number;
  termCount: number;
  postingCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
  k1: number;
  maxTokensPerField: number;
  fields: readonly RankedSearchFieldManifest[];
  maxReachableNodeCount?: number;
}

export interface PostSearchV5RoutedRunBuild {
  root: CID;
  manifest: PostSearchV5RoutedRunManifest;
}

export interface PostSearchV5RoutedRunWriter {
  appendDocument(id: string, document: PostSearchV5StoredDocument): Promise<void>;
  appendPosting(
    term: string,
    part: number,
    postings: readonly PostSearchV5Posting[],
  ): Promise<void>;
  appendTerm(term: string, stats: PostSearchV5TermStats): Promise<void>;
  finish(input: PostSearchV5RoutedRunFinishInput): Promise<PostSearchV5RoutedRunBuild>;
}

export interface PostSearchV5RoutedRunLookup extends PostSearchV5RoutedRunBuild {
  getDocument(id: string): Promise<PostSearchV5StoredDocument | null>;
  getTerm(term: string): Promise<PostSearchV5TermStats | null>;
  streamPostings(term: string): AsyncGenerator<PostSearchV5Posting>;
  streamDocuments(): AsyncGenerator<[string, PostSearchV5StoredDocument]>;
  streamTerms(): AsyncGenerator<[string, PostSearchV5TermStats]>;
  streamTermsByPrefix(prefix: string): AsyncGenerator<[string, PostSearchV5TermStats]>;
}

export interface PostSearchV5RoutedRunExpected {
  documentCount?: number;
  termCount?: number;
  postingCount?: number;
  postingPartCount?: number;
  storedValueCount?: number;
  tokenOccurrenceCount?: number;
  pageCount?: number;
  reachableNodeCount?: number;
}

export interface PostSearchV5RoutedRunReadOptions {
  expected?: PostSearchV5RoutedRunExpected;
  maxReachableNodeCount?: number;
}

export interface PostSearchV5RoutedRunEnvelope extends PostSearchV5RoutedRunBuild {
  roots: {
    documents: CID;
    postings: CID | null;
    terms: CID | null;
  };
}

export interface PostSearchV5CurrentTermBuild {
  term: string;
  partCount: number;
  postingCount: number;
  previousPostingId: string | null;
  fieldSets: Map<string, { fields: string[]; documentFrequency: number }>;
}

export interface PostSearchV5RoutedWriterFieldState {
  documentFields: string[] | null;
  totals: ReadonlyMap<string, number>;
  populated: ReadonlyMap<string, number>;
  postingFields: ReadonlySet<string>;
  maxLengths: ReadonlyMap<string, number>;
  maxPositions: ReadonlyMap<string, number>;
}
