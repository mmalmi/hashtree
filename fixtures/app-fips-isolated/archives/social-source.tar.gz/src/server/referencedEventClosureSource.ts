import type { CID, Store } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import type { RawEvent } from '../lib/nostr';
import type {
  ReferencedEventClosureReference,
  ReferencedEventClosureSource,
} from './referencedEventClosureTypes';

/** Read-only adapter for one immutable broad Nostr root. */
export class HashtreeReferencedEventClosureSource implements ReferencedEventClosureSource {
  readonly root: CID;
  private readonly events: NostrEventStore;

  constructor(store: Store, root: CID) {
    this.root = root;
    this.events = new NostrEventStore(store);
  }

  async *streamEvents(): AsyncIterable<RawEvent> {
    yield* this.events.streamRecent(this.root);
  }

  async resolveExisting(
    references: readonly ReferencedEventClosureReference[],
  ): Promise<RawEvent[]> {
    const resolved = await Promise.all(references.map(async (reference) => {
      if (reference.type === 'id') {
        return await this.events.getById(this.root, reference.value);
      }
      const coordinate = parseCoordinate(reference.value);
      if (!coordinate) {
        return null;
      }
      if (coordinate.kind === 0 || coordinate.kind === 3
        || (coordinate.kind >= 10_000 && coordinate.kind < 20_000)) {
        return await this.events.getReplaceable(this.root, coordinate.pubkey, coordinate.kind);
      }
      return await this.events.getParameterizedReplaceable(
        this.root,
        coordinate.pubkey,
        coordinate.kind,
        coordinate.identifier,
      );
    }));
    const unique = new Map<string, RawEvent>();
    for (const event of resolved) {
      if (event) {
        unique.set(event.id, event);
      }
    }
    return [...unique.values()];
  }
}

function parseCoordinate(
  value: string,
): { kind: number; pubkey: string; identifier: string } | null {
  const first = value.indexOf(':');
  const second = value.indexOf(':', first + 1);
  if (first <= 0 || second <= first + 1) {
    return null;
  }
  const kind = Number(value.slice(0, first));
  const pubkey = value.slice(first + 1, second);
  const replaceable = kind === 0 || kind === 3 || (kind >= 10_000 && kind < 20_000);
  const addressable = kind >= 30_000 && kind < 40_000;
  if (!Number.isSafeInteger(kind) || (!replaceable && !addressable)) {
    return null;
  }
  return { kind, pubkey, identifier: value.slice(second + 1) };
}
