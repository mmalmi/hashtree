import { nhashEncode, type CID } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import type { NostrArchiveCoverageReader } from './nostrArchiveMonotonicity';
import type { PostSearchSnapshotReader } from './postSearchProjection';
import { verifyPostSearchEvent } from './postSearchProjection';

export {
  NOSTR_ARCHIVE_MONOTONICITY_FORMAT,
  reportNostrArchiveMonotonicity,
} from './nostrArchiveMonotonicity';
export type {
  NostrArchiveCoverageReader,
  NostrArchiveKindMonotonicity,
  NostrArchiveMonotonicityAggregate,
  NostrArchiveMonotonicityReport,
} from './nostrArchiveMonotonicity';

export const NOSTR_ARCHIVE_COVERAGE_FORMAT = 'iris-social/nostr-archive-coverage@1';
export const IRIS_SOCIAL_ARCHIVE_REQUIRED_KINDS = Object.freeze([
  0,
  1,
  3,
  5,
  6,
  7,
  16,
  20,
  1_111,
  9_735,
  10_000,
  30_000,
  30_023,
]);

export interface NostrArchiveKindCoverage {
  kind: number;
  total: number;
  valid: number;
  invalid: number;
  distinctAuthors: number;
  minCreatedAt: number | null;
  maxCreatedAt: number | null;
}

export interface NostrArchiveCoverageAggregate {
  total: number;
  valid: number;
  invalid: number;
  distinctAuthors: number;
  minCreatedAt: number | null;
  maxCreatedAt: number | null;
}

export interface NostrArchiveCoverageReport {
  format: typeof NOSTR_ARCHIVE_COVERAGE_FORMAT;
  sourceRoot: string;
  requiredKinds: number[];
  kinds: NostrArchiveKindCoverage[];
  aggregate: NostrArchiveCoverageAggregate;
}

export interface NostrArchiveCoverageThresholds {
  minValidEvents: number;
  minDistinctAuthors: number;
  minValidEventsByKind: ReadonlyMap<number, number>;
}

export interface SerializableNostrArchiveCoverageThresholds {
  minValidEvents: number;
  minDistinctAuthors: number;
  minValidEventsByKind: Array<{ kind: number; minimum: number }>;
}

export interface NostrArchiveCoverageGateResult {
  report: NostrArchiveCoverageReport;
  thresholds: SerializableNostrArchiveCoverageThresholds;
  passed: boolean;
  failures: string[];
}

export interface NostrArchiveCoverageThresholdInputs {
  requiredKinds: readonly string[];
  minValidEvents?: string;
  minDistinctAuthors?: string;
  minKindValid: readonly string[];
  inferRequiredKindsFromMinimums?: boolean;
}

export interface ParsedNostrArchiveCoverageThresholds {
  requiredKinds: number[];
  thresholds: NostrArchiveCoverageThresholds;
}

/** Parse the mandatory threshold inputs shared by audit and publication CLIs. */
export function parseNostrArchiveCoverageThresholdInputs(
  inputs: NostrArchiveCoverageThresholdInputs,
): ParsedNostrArchiveCoverageThresholds {
  const minimums = new Map<number, number>();
  for (const value of inputs.minKindValid) {
    const { kind, minimum } = parseKindMinimum(value);
    if (minimums.has(kind)) {
      throw new Error(`Duplicate archive coverage minimum for kind ${kind}`);
    }
    minimums.set(kind, minimum);
  }
  const configuredKinds = inputs.requiredKinds.map((value) => (
    parseIntegerString(value, '--required-kind', false)
  ));
  const inferredKinds = inputs.inferRequiredKindsFromMinimums && configuredKinds.length === 0
    ? [...minimums.keys()]
    : configuredKinds;
  const requiredKinds = normalizeRequiredKinds(inferredKinds);
  const minValidEvents = parseRequiredPositiveInteger(
    inputs.minValidEvents,
    '--min-valid-events',
  );
  const minDistinctAuthors = parseRequiredPositiveInteger(
    inputs.minDistinctAuthors,
    '--min-distinct-authors',
  );
  const thresholds = { minValidEvents, minDistinctAuthors, minValidEventsByKind: minimums };
  normalizeThresholds(requiredKinds, thresholds);
  return { requiredKinds, thresholds };
}

export function assertIrisSocialArchivePublicationKinds(
  requiredKinds: readonly number[],
  thresholds: NostrArchiveCoverageThresholds,
): void {
  const configuredKinds = new Set(normalizeRequiredKinds(requiredKinds));
  for (const kind of IRIS_SOCIAL_ARCHIVE_REQUIRED_KINDS) {
    if (!configuredKinds.has(kind) || !thresholds.minValidEventsByKind.has(kind)) {
      throw new Error(`Missing publication coverage minimum for Iris Social archive kind ${kind}`);
    }
  }
}

/** Audit only the immutable by-kind-time streams selected by the operator. */
export async function reportNostrArchiveCoverage(
  reader: NostrArchiveCoverageReader,
  sourceRoot: CID,
  requiredKinds: readonly number[],
): Promise<NostrArchiveCoverageReport> {
  const kinds = normalizeRequiredKinds(requiredKinds);
  await reader.validateSnapshot?.(sourceRoot);
  await reader.validateArchiveSnapshot?.(sourceRoot);
  const aggregateAuthors = new Set<string>();
  const reports: NostrArchiveKindCoverage[] = [];

  for (const kind of kinds) {
    const report = await reportKind(reader, sourceRoot, kind, aggregateAuthors);
    reports.push(report);
  }

  return {
    format: NOSTR_ARCHIVE_COVERAGE_FORMAT,
    sourceRoot: nhashEncode(sourceRoot),
    requiredKinds: kinds,
    kinds: reports,
    aggregate: aggregateCoverage(reports, aggregateAuthors.size),
  };
}

export function gateNostrArchiveCoverage(
  report: NostrArchiveCoverageReport,
  thresholds: NostrArchiveCoverageThresholds,
): NostrArchiveCoverageGateResult {
  const normalized = validateNostrArchiveCoverageThresholds(report.requiredKinds, thresholds);
  const failures: string[] = [];
  if (report.aggregate.valid < normalized.minValidEvents) {
    failures.push(
      `aggregate valid events ${report.aggregate.valid} < ${normalized.minValidEvents}`,
    );
  }
  if (report.aggregate.distinctAuthors < normalized.minDistinctAuthors) {
    failures.push(
      `aggregate distinct authors ${report.aggregate.distinctAuthors} `
      + `< ${normalized.minDistinctAuthors}`,
    );
  }
  for (const { kind, minimum } of normalized.minValidEventsByKind) {
    const kindReport = report.kinds.find((candidate) => candidate.kind === kind);
    if (!kindReport || kindReport.valid < minimum) {
      failures.push(`kind ${kind} valid events ${kindReport?.valid ?? 0} < ${minimum}`);
    }
  }
  return {
    report,
    thresholds: normalized,
    passed: failures.length === 0,
    failures,
  };
}

export function validateNostrArchiveCoverageThresholds(
  requiredKinds: readonly number[],
  thresholds: NostrArchiveCoverageThresholds,
): SerializableNostrArchiveCoverageThresholds {
  return normalizeThresholds(requiredKinds, thresholds);
}

async function reportKind(
  reader: PostSearchSnapshotReader,
  root: CID,
  kind: number,
  aggregateAuthors: Set<string>,
): Promise<NostrArchiveKindCoverage> {
  const authors = new Set<string>();
  const report: NostrArchiveKindCoverage = {
    kind,
    total: 0,
    valid: 0,
    invalid: 0,
    distinctAuthors: 0,
    minCreatedAt: null,
    maxCreatedAt: null,
  };
  for await (const event of reader.streamKind(root, kind)) {
    report.total = increment(report.total, `kind ${kind} total`);
    if (!isValidKindEvent(event, kind)) {
      report.invalid = increment(report.invalid, `kind ${kind} invalid`);
      continue;
    }
    report.valid = increment(report.valid, `kind ${kind} valid`);
    authors.add(event.pubkey);
    aggregateAuthors.add(event.pubkey);
    report.minCreatedAt = minTimestamp(report.minCreatedAt, event.created_at);
    report.maxCreatedAt = maxTimestamp(report.maxCreatedAt, event.created_at);
  }
  report.distinctAuthors = authors.size;
  return report;
}

function isValidKindEvent(event: RawEvent, expectedKind: number): boolean {
  return event.kind === expectedKind && verifyPostSearchEvent(event);
}

function aggregateCoverage(
  kinds: readonly NostrArchiveKindCoverage[],
  distinctAuthors: number,
): NostrArchiveCoverageAggregate {
  return kinds.reduce<NostrArchiveCoverageAggregate>((aggregate, report) => ({
    total: add(aggregate.total, report.total, 'aggregate total'),
    valid: add(aggregate.valid, report.valid, 'aggregate valid'),
    invalid: add(aggregate.invalid, report.invalid, 'aggregate invalid'),
    distinctAuthors,
    minCreatedAt: minTimestamp(aggregate.minCreatedAt, report.minCreatedAt),
    maxCreatedAt: maxTimestamp(aggregate.maxCreatedAt, report.maxCreatedAt),
  }), {
    total: 0,
    valid: 0,
    invalid: 0,
    distinctAuthors,
    minCreatedAt: null,
    maxCreatedAt: null,
  });
}

function normalizeRequiredKinds(values: readonly number[]): number[] {
  const kinds = [...new Set(values.map((value) => nonNegativeInteger(value, 'required kind')))]
    .sort((left, right) => left - right);
  if (kinds.length === 0) {
    throw new Error('At least one Nostr archive required kind is required');
  }
  return kinds;
}

function normalizeThresholds(
  requiredKinds: readonly number[],
  thresholds: NostrArchiveCoverageThresholds,
): SerializableNostrArchiveCoverageThresholds {
  const kinds = normalizeRequiredKinds(requiredKinds);
  const configured = new Map<number, number>();
  for (const [kindValue, minimumValue] of thresholds.minValidEventsByKind) {
    const kind = nonNegativeInteger(kindValue, 'threshold kind');
    const minimum = positiveInteger(minimumValue, `kind ${kind} minimum valid events`);
    if (configured.has(kind)) {
      throw new Error(`Duplicate Nostr archive minimum for kind ${kind}`);
    }
    configured.set(kind, minimum);
  }
  for (const kind of kinds) {
    if (!configured.has(kind)) {
      throw new Error(`Missing Nostr archive minimum valid events for required kind ${kind}`);
    }
  }
  for (const kind of configured.keys()) {
    if (!kinds.includes(kind)) {
      throw new Error(`Nostr archive minimum configured for non-required kind ${kind}`);
    }
  }
  return {
    minValidEvents: positiveInteger(thresholds.minValidEvents, 'minimum valid events'),
    minDistinctAuthors: positiveInteger(
      thresholds.minDistinctAuthors,
      'minimum distinct authors',
    ),
    minValidEventsByKind: kinds.map((kind) => ({ kind, minimum: configured.get(kind)! })),
  };
}

function minTimestamp(left: number | null, right: number | null): number | null {
  if (right === null) {
    return left;
  }
  return left === null ? right : Math.min(left, right);
}

function maxTimestamp(left: number | null, right: number | null): number | null {
  if (right === null) {
    return left;
  }
  return left === null ? right : Math.max(left, right);
}

function increment(value: number, name: string): number {
  return add(value, 1, name);
}

function add(left: number, right: number, name: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Invalid Nostr archive ${name}`);
  }
  return result;
}

function nonNegativeInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Nostr archive ${name} must be a non-negative integer`);
  }
  return value;
}

function positiveInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`Nostr archive ${name} must be a positive integer`);
  }
  return value;
}

function parseKindMinimum(value: string): { kind: number; minimum: number } {
  const match = /^(\d+):(\d+)$/.exec(value.trim());
  if (!match) {
    throw new Error('--min-kind-valid must use <kind>:<positive-count> syntax');
  }
  return {
    kind: parseIntegerString(match[1], '--min-kind-valid kind', false),
    minimum: parseIntegerString(match[2], '--min-kind-valid count', true),
  };
}

function parseRequiredPositiveInteger(value: string | undefined, name: string): number {
  if (value === undefined || value.trim() === '') {
    throw new Error(`Missing required archive coverage argument: ${name}`);
  }
  return parseIntegerString(value, name, true);
}

function parseIntegerString(value: string, name: string, positive: boolean): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || (positive ? parsed <= 0 : parsed < 0)) {
    throw new Error(`${name} must be a ${positive ? 'positive' : 'non-negative'} integer`);
  }
  return parsed;
}
