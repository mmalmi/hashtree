import { sha256, type CID, type Link, type Store } from '@hashtree/core';

const decoder = new TextDecoder('utf-8', { fatal: true });

export function isPostSearchV5RoutedRecord(
  value: unknown,
): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function postSearchV5RoutedObject(
  value: unknown,
  label: string,
): Record<string, unknown> {
  if (!isPostSearchV5RoutedRecord(value)) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function postSearchV5RoutedNonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function postSearchV5RoutedNonNegativeInteger(
  value: unknown,
  label: string,
): number {
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value as number;
}

export function postSearchV5RoutedPositiveInteger(value: unknown, label: string): number {
  const parsed = postSearchV5RoutedNonNegativeInteger(value, label);
  if (parsed === 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return parsed;
}

export function postSearchV5RoutedPositiveNumber(value: unknown, label: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function postSearchV5RoutedBoundedNumber(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isFinite(value)
    || value < minimum || value > maximum) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function addPostSearchV5Routed(
  left: number,
  right: number,
  label: string,
): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post-search v5 routed ${label} exceeds capacity`);
  }
  return result;
}

export function samePostSearchV5RoutedStrings(
  left: readonly string[],
  right: readonly string[],
): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

export function samePostSearchV5RoutedNumbers(
  left: readonly number[],
  right: readonly number[],
): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

export function comparePostSearchV5RoutedText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

export function equalPostSearchV5RoutedBytes(
  left: Uint8Array,
  right: Uint8Array,
): boolean {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}

export function assertPostSearchV5RoutedExactKeys(
  value: Record<string, unknown>,
  expected: readonly string[],
  label: string,
): void {
  const keys = Object.keys(value).sort(comparePostSearchV5RoutedText);
  const wanted = [...expected].sort(comparePostSearchV5RoutedText);
  if (!samePostSearchV5RoutedStrings(keys, wanted)) {
    throw new Error(`Invalid post-search v5 routed ${label} fields`);
  }
}

export function postSearchV5RoutedPublicCid(value: unknown, label: string): CID {
  if (!isPostSearchV5RoutedRecord(value)
    || !(value.hash instanceof Uint8Array)
    || value.hash.length !== 32) {
    throw new Error(`Invalid post-search v5 routed ${label} CID`);
  }
  if (value.key !== undefined) {
    throw new Error(`Encrypted post-search v5 routed ${label} CIDs are unsupported`);
  }
  return { hash: new Uint8Array(value.hash) };
}

export async function readPostSearchV5RoutedPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  const cid = postSearchV5RoutedPublicCid(root, label);
  const bytes = await store.get(cid.hash);
  if (!bytes) {
    throw new Error(`Missing post-search v5 routed ${label} block`);
  }
  if (bytes.length > maximum) {
    throw new Error(`Post-search v5 routed ${label} exceeds its byte bound`);
  }
  const actual = await sha256(bytes);
  if (!equalPostSearchV5RoutedBytes(actual, cid.hash)) {
    throw new Error(`Post-search v5 routed ${label} hash mismatch`);
  }
  return bytes;
}

export function assertPostSearchV5RoutedCanonicalLink(link: Link): void {
  if (!(link.hash instanceof Uint8Array) || link.hash.length !== 32
    || link.key !== undefined || typeof link.name !== 'string' || !link.name
    || !Number.isSafeInteger(link.size) || link.size < 0 || link.meta !== undefined) {
    throw new Error('Post-search v5 routed run contains an invalid or encrypted link');
  }
}

export function assertPostSearchV5RoutedExactLinkNames(
  links: readonly Link[],
  expected: readonly string[],
): void {
  const names = links.map((link) => link.name!).sort(comparePostSearchV5RoutedText);
  const wanted = [...expected].sort(comparePostSearchV5RoutedText);
  if (!samePostSearchV5RoutedStrings(names, wanted)) {
    throw new Error('Post-search v5 routed run has missing or unbound root links');
  }
}

export function assertPostSearchV5RoutedCanonicalRaw(
  raw: string,
  canonical: string,
  label: string,
): void {
  if (raw !== canonical) {
    throw new Error(`Post-search v5 routed ${label} is not canonical`);
  }
}

export function parsePostSearchV5RoutedJsonObject(
  bytes: Uint8Array,
  label: string,
): Record<string, unknown> {
  try {
    return postSearchV5RoutedObject(JSON.parse(decoder.decode(bytes)), label);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid post-search v5 routed ${label} JSON`);
    }
    throw error;
  }
}
