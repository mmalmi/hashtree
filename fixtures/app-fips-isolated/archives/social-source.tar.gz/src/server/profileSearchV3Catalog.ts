import {
  HashTree,
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  nhashDecode,
  nhashEncode,
  sha256,
  type CID,
  type Link,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import { normalizePubkey } from '../lib/nostr';
import {
  PROFILE_SEARCH_V3_MAX_QUERY_RESULTS,
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
  PROFILE_SEARCH_V3_NORMALIZATION,
  PROFILE_SEARCH_V3_RANK_POLICY,
  PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
  openProfileSearchV3RoutedRun,
  readProfileSearchV3RoutedRun,
  type ProfileSearchV3Hit,
  type ProfileSearchV3RoutedRunBuild,
  type ProfileSearchV3RoutedRunLookup,
} from './profileSearchV3RoutedRun';

export const PROFILE_SEARCH_V3_CATALOG_FORMAT =
  'iris-social/routed-profile-search-catalog@3' as const;
export const PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY = 'first-hex-nibble@1' as const;
export const PROFILE_SEARCH_V3_CATALOG_MAX_RUNS = 16;
export const PROFILE_SEARCH_V3_CATALOG_SEARCH_CONCURRENCY = 8;

const MANIFEST_ENTRY = 'manifest.json';
const ROOT_MAX_BYTES = 65_536;
const MANIFEST_MAX_BYTES = 256 * 1_024;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export interface ProfileSearchV3CatalogRunDescriptor {
  entry: string;
  root: string;
  rangeStart: string;
  rangeEnd: string;
  minimumPubkey: string;
  maximumPubkey: string;
  profileCount: number;
  postingCount: number;
  pageCount: number;
  reachableNodeCount: number;
  minimumRankHint: number;
  maximumRankHint: number;
}

export interface ProfileSearchV3CatalogManifest {
  format: typeof PROFILE_SEARCH_V3_CATALOG_FORMAT;
  generatedAt: number;
  sourceRoot: string;
  /** SHA-256 of canonical eligible `(pubkey, rankHint, exclusion-decision)` records. */
  eligibleRanksSha256: string;
  compatibility: {
    runFormat: typeof PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT;
    normalization: typeof PROFILE_SEARCH_V3_NORMALIZATION;
    rankPolicy: typeof PROFILE_SEARCH_V3_RANK_POLICY;
    partitionPolicy: typeof PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY;
  };
  runs: ProfileSearchV3CatalogRunDescriptor[];
  reachableNodeCount: number;
}

export interface ProfileSearchV3CatalogBuild {
  root: CID;
  manifest: ProfileSearchV3CatalogManifest;
}

export interface ProfileSearchV3CatalogLookup extends ProfileSearchV3CatalogBuild {
  runs: ProfileSearchV3RoutedRunLookup[];
  getProfile(pubkeyOrNpub: string): ReturnType<ProfileSearchV3RoutedRunLookup['getProfile']>;
  search(query: string, limit?: number): Promise<ProfileSearchV3Hit[]>;
}

export interface ProfileSearchV3CatalogInput {
  generatedAt: number;
  sourceRoot: CID;
  eligibleRanksSha256: string;
  runs: readonly ProfileSearchV3CatalogRunInput[];
  maxReachableNodeCount?: number;
}

export interface ProfileSearchV3CatalogRunInput {
  run: ProfileSearchV3RoutedRunBuild;
  /** Fixed inclusive lower bound for this immutable pubkey partition. */
  rangeStart: string;
  /** Fixed inclusive upper bound for this immutable pubkey partition. */
  rangeEnd: string;
}

interface CatalogEnvelope extends ProfileSearchV3CatalogBuild {
  runRoots: CID[];
}

export async function writeProfileSearchV3Catalog(
  store: Store,
  input: ProfileSearchV3CatalogInput,
): Promise<ProfileSearchV3CatalogBuild> {
  if (!isRecord(input)) {throw new Error('Invalid profile-search v3 catalog input');}
  const generatedAt = nonNegativeInteger(input.generatedAt, 'generatedAt');
  const sourceRoot = nhashEncode(publicCid(input.sourceRoot, 'sourceRoot'));
  const eligibleRanksSha256 = strictSha256(
    input.eligibleRanksSha256,
    'eligibleRanksSha256',
  );
  if (!Array.isArray(input.runs) || input.runs.length === 0
    || input.runs.length > PROFILE_SEARCH_V3_CATALOG_MAX_RUNS) {
    throw new Error('Invalid profile-search v3 catalog runs');
  }
  const maximum = input.maxReachableNodeCount === undefined
    ? PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
    : positiveInteger(input.maxReachableNodeCount, 'maxReachableNodeCount');
  const roots = new Set<string>();
  const descriptors: ProfileSearchV3CatalogRunDescriptor[] = [];
  for (let index = 0; index < input.runs.length; index += 1) {
    const rawCandidate: unknown = input.runs[index];
    if (!isRecord(rawCandidate) || !isRecord(rawCandidate.run)
      || !isRecord(rawCandidate.run.manifest)) {
      throw new Error(`Invalid profile-search v3 catalog run ${index}`);
    }
    const candidate = rawCandidate as unknown as ProfileSearchV3CatalogRunInput;
    const verified = await readProfileSearchV3RoutedRun(store, candidate.run.root, {
      expected: {
        profileCount: candidate.run.manifest.profileCount,
        postingCount: candidate.run.manifest.postingCount,
        reachableNodeCount: candidate.run.manifest.reachableNodeCount,
      },
    });
    const root = nhashEncode(publicCid(candidate.run.root, `run ${index} root`));
    if (roots.has(root)) {throw new Error('Profile-search v3 catalog contains a duplicate run');}
    roots.add(root);
    descriptors.push(runDescriptor(index, root, verified, candidate));
  }
  assertOrderedDisjointRunRanges(descriptors);
  const reachableNodeCount = descriptors.reduce(
    (total, run) => safeAdd(total, run.reachableNodeCount, 'catalog reachability'),
    2,
  );
  if (reachableNodeCount > maximum || reachableNodeCount > PROFILE_SEARCH_V3_MAX_REACHABLE_NODES) {
    throw new Error('Profile-search v3 catalog exceeds its reachable-node capacity');
  }
  const manifest: ProfileSearchV3CatalogManifest = {
    format: PROFILE_SEARCH_V3_CATALOG_FORMAT,
    generatedAt,
    sourceRoot,
    eligibleRanksSha256,
    compatibility: {
      runFormat: PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
      normalization: PROFILE_SEARCH_V3_NORMALIZATION,
      rankPolicy: PROFILE_SEARCH_V3_RANK_POLICY,
      partitionPolicy: PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY,
    },
    runs: descriptors,
    reachableNodeCount,
  };
  const manifestBytes = encodeManifest(manifest);
  const manifestHash = await sha256(manifestBytes);
  await store.put(manifestHash, manifestBytes);
  const entries: TreeEntry[] = [{
    name: MANIFEST_ENTRY,
    cid: { hash: manifestHash },
    size: manifestBytes.length,
    type: LinkType.Blob,
  }, ...descriptors.map((run, index): TreeEntry => ({
    name: run.entry,
    cid: input.runs[index]!.run.root,
    size: run.reachableNodeCount,
    type: LinkType.Dir,
  }))];
  const root = (await new HashTree({ store }).putDirectory(entries, { unencrypted: true })).cid;
  return { root, manifest };
}

export async function openProfileSearchV3Catalog(
  store: Store,
  root: CID,
): Promise<ProfileSearchV3CatalogLookup> {
  return await openEnvelope(store, await readEnvelope(store, root));
}

/** Verify the catalog and each complete public run DAG before publication/cutover. */
export async function readProfileSearchV3Catalog(
  store: Store,
  root: CID,
  options: {
    maxReachableNodeCount?: number;
    expectedSourceRoot?: CID;
    expectedEligibleRanksSha256?: string;
  } = {},
): Promise<ProfileSearchV3CatalogLookup> {
  const envelope = await readEnvelope(store, root);
  if (options.expectedSourceRoot
    && envelope.manifest.sourceRoot !== nhashEncode(publicCid(options.expectedSourceRoot, 'sourceRoot'))) {
    throw new Error('Profile-search v3 catalog sourceRoot does not match the expected snapshot');
  }
  if (options.expectedEligibleRanksSha256
    && envelope.manifest.eligibleRanksSha256 !== strictSha256(
      options.expectedEligibleRanksSha256,
      'expectedEligibleRanksSha256',
    )) {
    throw new Error('Profile-search v3 catalog eligibleRanksSha256 does not match');
  }
  const maximum = options.maxReachableNodeCount === undefined
    ? PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
    : positiveInteger(options.maxReachableNodeCount, 'maxReachableNodeCount');
  if (envelope.manifest.reachableNodeCount > maximum) {
    throw new Error('Profile-search v3 catalog exceeds its reachable-node capacity');
  }
  const runs: ProfileSearchV3RoutedRunLookup[] = [];
  for (let index = 0; index < envelope.runRoots.length; index += 1) {
    const descriptor = envelope.manifest.runs[index]!;
    const run = await readProfileSearchV3RoutedRun(store, envelope.runRoots[index]!, {
      expected: {
        profileCount: descriptor.profileCount,
        postingCount: descriptor.postingCount,
        pageCount: descriptor.pageCount,
        reachableNodeCount: descriptor.reachableNodeCount,
      },
    });
    assertDescriptorMatchesRun(descriptor, run, index);
    runs.push(run);
  }
  return catalogLookup(envelope, runs);
}

async function openEnvelope(
  store: Store,
  envelope: CatalogEnvelope,
): Promise<ProfileSearchV3CatalogLookup> {
  const runs = await mapWithConcurrency(
    envelope.runRoots,
    PROFILE_SEARCH_V3_CATALOG_SEARCH_CONCURRENCY,
    async (root) => await openProfileSearchV3RoutedRun(store, root),
  );
  return catalogLookup(envelope, runs);
}

function catalogLookup(
  envelope: CatalogEnvelope,
  runs: ProfileSearchV3RoutedRunLookup[],
): ProfileSearchV3CatalogLookup {
  const getProfile = async (value: string) => {
    const pubkey = normalizePubkey(value);
    if (!pubkey) {return null;}
    const index = envelope.manifest.runs.findIndex((run) =>
      run.rangeStart <= pubkey && pubkey <= run.rangeEnd);
    return index < 0 ? null : await runs[index]!.getProfile(pubkey);
  };
  return {
    root: envelope.root,
    manifest: envelope.manifest,
    runs,
    getProfile,
    search: async (query, rawLimit = 20) => {
      const limit = boundedInteger(rawLimit, 1, PROFILE_SEARCH_V3_MAX_QUERY_RESULTS, 'query limit');
      const directPubkey = normalizePubkey(query);
      if (directPubkey) {
        const direct = await getProfile(directPubkey);
        return direct ? [{ ...direct, textScore: 14_000, matchedModes: ['identifier'] }] : [];
      }
      const batches = await mapWithConcurrency(
        runs,
        PROFILE_SEARCH_V3_CATALOG_SEARCH_CONCURRENCY,
        async (run) => await run.search(query, limit),
      );
      const hits: ProfileSearchV3Hit[] = batches.flat();
      hits.sort((left, right) => (
        right.textScore - left.textScore
        || left.rankHint - right.rankHint
        || right.event.created_at - left.event.created_at
        || compareText(left.event.pubkey, right.event.pubkey)
      ));
      return hits.slice(0, limit);
    },
  };
}

async function readEnvelope(store: Store, root: CID): Promise<CatalogEnvelope> {
  const rootBytes = await readPublicBlock(store, root, ROOT_MAX_BYTES, 'catalog root');
  let node;
  try {node = decodeTreeNode(rootBytes);} catch {
    throw new Error('Profile-search v3 catalog root is not a directory');
  }
  if (node.type !== LinkType.Dir || !equalBytes(rootBytes, encodeTreeNode(node))) {
    throw new Error('Profile-search v3 catalog root is not a canonical directory');
  }
  node.links.forEach(assertCanonicalLink);
  const manifestLink = node.links.find((link) => link.name === MANIFEST_ENTRY);
  if (!manifestLink || manifestLink.type !== LinkType.Blob) {
    throw new Error('Profile-search v3 catalog manifest link is missing');
  }
  const manifestBytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    MANIFEST_MAX_BYTES,
    'catalog manifest',
  );
  if (manifestLink.size !== manifestBytes.length) {
    throw new Error('Profile-search v3 catalog manifest link size is inconsistent');
  }
  const manifest = parseManifest(manifestBytes);
  const expectedNames = [MANIFEST_ENTRY, ...manifest.runs.map((run) => run.entry)]
    .sort(compareText);
  const names = node.links.map((link) => link.name!).sort(compareText);
  if (!sameStrings(names, expectedNames)) {
    throw new Error('Profile-search v3 catalog has missing or unbound root links');
  }
  const runRoots = manifest.runs.map((run) => {
    const link = node.links.find((candidate) => candidate.name === run.entry);
    const declared = publicNhash(run.root, `${run.entry} root`);
    if (!link || link.type !== LinkType.Dir || link.size !== run.reachableNodeCount
      || !equalBytes(link.hash, declared.hash)) {
      throw new Error(`Profile-search v3 catalog run link is inconsistent: ${run.entry}`);
    }
    return declared;
  });
  return { root: publicCid(root, 'catalog root'), manifest, runRoots };
}

function runDescriptor(
  index: number,
  root: string,
  run: ProfileSearchV3RoutedRunLookup,
  input: Pick<ProfileSearchV3CatalogRunInput, 'rangeStart' | 'rangeEnd'>,
): ProfileSearchV3CatalogRunDescriptor {
  const descriptor: ProfileSearchV3CatalogRunDescriptor = {
    entry: `run-${index.toString().padStart(4, '0')}`,
    root,
    rangeStart: strictPubkey(input.rangeStart, `run ${index} rangeStart`),
    rangeEnd: strictPubkey(input.rangeEnd, `run ${index} rangeEnd`),
    minimumPubkey: strictPubkey(run.manifest.branches.profiles.minKey, `run ${index} minimumPubkey`),
    maximumPubkey: strictPubkey(run.manifest.branches.profiles.maxKey, `run ${index} maximumPubkey`),
    profileCount: run.manifest.profileCount,
    postingCount: run.manifest.postingCount,
    pageCount: run.manifest.branches.profiles.pageCount + run.manifest.branches.postings.pageCount,
    reachableNodeCount: run.manifest.reachableNodeCount,
    minimumRankHint: run.manifest.minimumRankHint,
    maximumRankHint: run.manifest.maximumRankHint,
  };
  assertRunInsideDeclaredRange(descriptor, index);
  return descriptor;
}

function parseManifest(bytes: Uint8Array): ProfileSearchV3CatalogManifest {
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {
    throw new Error('Invalid profile-search v3 catalog manifest JSON');
  }
  const raw = objectValue(value, 'catalog manifest');
  exactKeys(raw, [
    'format', 'generatedAt', 'sourceRoot', 'eligibleRanksSha256', 'compatibility', 'runs',
    'reachableNodeCount',
  ],
    'catalog manifest');
  const compatibility = objectValue(raw.compatibility, 'compatibility');
  exactKeys(
    compatibility,
    ['runFormat', 'normalization', 'rankPolicy', 'partitionPolicy'],
    'compatibility',
  );
  if (raw.format !== PROFILE_SEARCH_V3_CATALOG_FORMAT
    || compatibility.runFormat !== PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT
    || compatibility.normalization !== PROFILE_SEARCH_V3_NORMALIZATION
    || compatibility.rankPolicy !== PROFILE_SEARCH_V3_RANK_POLICY
    || compatibility.partitionPolicy !== PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY
    || !Array.isArray(raw.runs) || raw.runs.length === 0
    || raw.runs.length > PROFILE_SEARCH_V3_CATALOG_MAX_RUNS) {
    throw new Error('Unsupported or invalid profile-search v3 catalog manifest');
  }
  const roots = new Set<string>();
  const runs = raw.runs.map((candidate, index) => parseRunDescriptor(candidate, index, roots));
  assertOrderedDisjointRunRanges(runs);
  const manifest: ProfileSearchV3CatalogManifest = {
    format: PROFILE_SEARCH_V3_CATALOG_FORMAT,
    generatedAt: nonNegativeInteger(raw.generatedAt, 'generatedAt'),
    sourceRoot: nhashEncode(publicNhash(raw.sourceRoot, 'sourceRoot')),
    eligibleRanksSha256: strictSha256(raw.eligibleRanksSha256, 'eligibleRanksSha256'),
    compatibility: {
      runFormat: PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
      normalization: PROFILE_SEARCH_V3_NORMALIZATION,
      rankPolicy: PROFILE_SEARCH_V3_RANK_POLICY,
      partitionPolicy: PROFILE_SEARCH_V3_CATALOG_PARTITION_POLICY,
    },
    runs,
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'reachableNodeCount'),
  };
  const expectedReachable = runs.reduce(
    (total, run) => safeAdd(total, run.reachableNodeCount, 'catalog reachability'),
    2,
  );
  if (manifest.reachableNodeCount !== expectedReachable
    || manifest.reachableNodeCount > PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
    || !equalBytes(bytes, encodeManifest(manifest))) {
    throw new Error('Inconsistent or noncanonical profile-search v3 catalog manifest');
  }
  return manifest;
}

function parseRunDescriptor(
  value: unknown,
  index: number,
  roots: Set<string>,
): ProfileSearchV3CatalogRunDescriptor {
  const raw = objectValue(value, `run ${index}`);
  exactKeys(raw, [
    'entry', 'root', 'rangeStart', 'rangeEnd', 'minimumPubkey', 'maximumPubkey',
    'profileCount', 'postingCount', 'pageCount', 'reachableNodeCount', 'minimumRankHint',
    'maximumRankHint',
  ], `run ${index}`);
  const root = nhashEncode(publicNhash(raw.root, `run ${index} root`));
  if (roots.has(root)) {throw new Error('Profile-search v3 catalog contains a duplicate run');}
  roots.add(root);
  const descriptor: ProfileSearchV3CatalogRunDescriptor = {
    entry: nonEmptyString(raw.entry, `run ${index} entry`),
    root,
    rangeStart: strictPubkey(raw.rangeStart, `run ${index} rangeStart`),
    rangeEnd: strictPubkey(raw.rangeEnd, `run ${index} rangeEnd`),
    minimumPubkey: strictPubkey(raw.minimumPubkey, `run ${index} minimumPubkey`),
    maximumPubkey: strictPubkey(raw.maximumPubkey, `run ${index} maximumPubkey`),
    profileCount: positiveInteger(raw.profileCount, `run ${index} profileCount`),
    postingCount: positiveInteger(raw.postingCount, `run ${index} postingCount`),
    pageCount: positiveInteger(raw.pageCount, `run ${index} pageCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `run ${index} reachableNodeCount`),
    minimumRankHint: nonNegativeInteger(raw.minimumRankHint, `run ${index} minimumRankHint`),
    maximumRankHint: nonNegativeInteger(raw.maximumRankHint, `run ${index} maximumRankHint`),
  };
  if (descriptor.entry !== `run-${index.toString().padStart(4, '0')}`
    || descriptor.minimumRankHint > descriptor.maximumRankHint) {
    throw new Error(`Invalid profile-search v3 catalog run layout at ${index}`);
  }
  assertRunInsideDeclaredRange(descriptor, index);
  return descriptor;
}

function encodeManifest(manifest: ProfileSearchV3CatalogManifest): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length === 0 || bytes.length > MANIFEST_MAX_BYTES) {
    throw new Error('Profile-search v3 catalog manifest exceeds its byte capacity');
  }
  return bytes;
}

async function readPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  const cid = publicCid(root, label);
  const bytes = await store.get(cid.hash);
  if (!bytes) {throw new Error(`Missing profile-search v3 ${label} block`);}
  if (bytes.length > maximum) {throw new Error(`Profile-search v3 ${label} exceeds its byte bound`);}
  const actual = await sha256(bytes);
  if (!equalBytes(actual, cid.hash)) {throw new Error(`Profile-search v3 ${label} hash mismatch`);}
  return bytes;
}

function publicNhash(value: unknown, label: string): CID {
  if (typeof value !== 'string') {throw new Error(`Invalid profile-search v3 ${label}`);}
  let cid: CID;
  try {cid = nhashDecode(value);} catch {throw new Error(`Invalid profile-search v3 ${label}`);}
  const normalized = publicCid(cid, label);
  if (nhashEncode(normalized) !== value) {throw new Error(`Noncanonical profile-search v3 ${label}`);}
  return normalized;
}

function publicCid(value: unknown, label: string): CID {
  if (!isRecord(value) || !(value.hash instanceof Uint8Array) || value.hash.length !== 32) {
    throw new Error(`Invalid profile-search v3 ${label} CID`);
  }
  if (value.key !== undefined) {throw new Error(`Encrypted profile-search v3 ${label} CIDs are unsupported`);}
  return { hash: new Uint8Array(value.hash) };
}

function assertCanonicalLink(link: Link): void {
  if (!(link.hash instanceof Uint8Array) || link.hash.length !== 32 || link.key !== undefined
    || typeof link.name !== 'string' || !link.name || !Number.isSafeInteger(link.size)
    || link.size < 0 || link.meta !== undefined) {
    throw new Error('Profile-search v3 catalog contains an invalid or encrypted link');
  }
}

function assertOrderedDisjointRunRanges(
  runs: readonly ProfileSearchV3CatalogRunDescriptor[],
): void {
  for (let index = 1; index < runs.length; index += 1) {
    if (runs[index - 1]!.rangeEnd >= runs[index]!.rangeStart) {
      throw new Error('Profile-search v3 catalog run pubkey ranges overlap or are out of order');
    }
  }
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  work: (value: T) => Promise<R>,
): Promise<R[]> {
  const result = new Array<R>(values.length);
  let nextIndex = 0;
  const workers = Array.from(
    { length: Math.min(concurrency, values.length) },
    async () => {
      while (nextIndex < values.length) {
        const index = nextIndex;
        nextIndex += 1;
        result[index] = await work(values[index]!);
      }
    },
  );
  await Promise.all(workers);
  return result;
}

function assertRunInsideDeclaredRange(
  run: ProfileSearchV3CatalogRunDescriptor,
  index: number,
): void {
  const nibble = run.rangeStart[0]!;
  const expectedStart = `${nibble}${'0'.repeat(63)}`;
  const expectedEnd = `${nibble}${'f'.repeat(63)}`;
  if (run.rangeStart > run.rangeEnd
    || run.rangeStart !== expectedStart
    || run.rangeEnd !== expectedEnd
    || run.minimumPubkey > run.maximumPubkey
    || run.minimumPubkey < run.rangeStart
    || run.maximumPubkey > run.rangeEnd) {
    throw new Error(`Invalid profile-search v3 catalog run range at ${index}`);
  }
}

function assertDescriptorMatchesRun(
  descriptor: ProfileSearchV3CatalogRunDescriptor,
  run: ProfileSearchV3RoutedRunLookup,
  index: number,
): void {
  if (descriptor.minimumPubkey !== run.manifest.branches.profiles.minKey
    || descriptor.maximumPubkey !== run.manifest.branches.profiles.maxKey
    || descriptor.minimumRankHint !== run.manifest.minimumRankHint
    || descriptor.maximumRankHint !== run.manifest.maximumRankHint) {
    throw new Error(`Profile-search v3 catalog run descriptor is inconsistent at ${index}`);
  }
}

function strictPubkey(value: unknown, label: string): string {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`Invalid profile-search v3 catalog ${label}`);
  }
  return value;
}

function strictSha256(value: unknown, label: string): string {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`Invalid profile-search v3 catalog ${label}`);
  }
  return value;
}

function exactKeys(value: Record<string, unknown>, expected: readonly string[], label: string): void {
  const keys = Object.keys(value).sort(compareText);
  const wanted = [...expected].sort(compareText);
  if (!sameStrings(keys, wanted)) {throw new Error(`Invalid profile-search v3 ${label} fields`);}
}

function objectValue(value: unknown, label: string): Record<string, unknown> {
  if (!isRecord(value)) {throw new Error(`Invalid profile-search v3 ${label}`);}
  return value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function nonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

function nonNegativeInteger(value: unknown, label: string): number {
  return boundedInteger(value, 0, Number.MAX_SAFE_INTEGER, label);
}

function positiveInteger(value: unknown, label: string): number {
  return boundedInteger(value, 1, Number.MAX_SAFE_INTEGER, label);
}

function boundedInteger(value: unknown, minimum: number, maximum: number, label: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < minimum || (value as number) > maximum) {
    throw new Error(`Invalid profile-search v3 catalog ${label}`);
  }
  return value as number;
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {throw new Error(`Profile-search v3 ${label} exceeds capacity`);}
  return result;
}

function sameStrings(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {return false;}
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
