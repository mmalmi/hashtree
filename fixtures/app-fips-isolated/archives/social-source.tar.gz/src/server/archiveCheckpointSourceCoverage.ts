import { nhashDecode } from '@hashtree/core';
import { decode } from 'nostr-tools/nip19';
import { canonical, digest, type ArchiveCheckpoint, type ArchiveLineageReceipt,
  type ArchiveRelayRemovalReceipt, type ArchiveSourceModeReceipt, type ArchiveKindExpansionReceipt,
  type ArchiveCommitBatchReceipt, type ArchiveSourceCoverageProof } from './archiveCheckpointOutbox';
import { isArchiveRelayRemovalReceipt } from './archiveCheckpointRelayPolicy';

// Match the native writer; the publication's 64-author limit bounds total raw evidence to 16 MiB.
export const ARCHIVE_COVERAGE_MAX_BYTES = 256 * 1024;
const SHA = /^[a-f0-9]{64}$/;
function validPeer(id: string): boolean {
  if (/^[a-f0-9]{64}$/i.test(id)) {return true;}
  try {
    const key = decode(id.startsWith('nostr:') ? id.slice(6) : id);
    return key.type === 'npub' || (key.type === 'nprofile' && SHA.test(key.data.pubkey));
  } catch {return false;}
}
export interface ArchiveSourceValidationOptions {
  /** Explicitly reviewed native versions may record all-source coverage in strict mode. */
  strictCoverage?: boolean;
  sourceModeReceipts?: readonly ArchiveSourceModeReceipt[];
  kindExpansionReceipts?: readonly ArchiveKindExpansionReceipt[];
  commitBatchReceipts?: readonly ArchiveCommitBatchReceipt[];
  authors?: readonly string[];
}
export interface ArchiveSourceCoverageReceipt {
  format: 'hashtree/nostr-index-catchup-coverage@1';
  previous_head: string | null;
  policy_sha256: string;
  pass_since: number;
  pass_until: number;
  author: string;
  ordinal: number;
  before_root: string;
  after_root: string;
  events_received: number;
  sources: Array<{ relay: string; status: 'complete' | 'failed' | 'skipped'; error?: string }>;
  // Peer query observations supplement events, never relay completeness.
  pubsub?: { status: 'observed' | 'unavailable'; events: number; added_events: number;
    sources: Record<string, number>; event_ids_sha256: string };
}

export function isArchiveSourceModeReceipt(receipt: ArchiveLineageReceipt): receipt is ArchiveSourceModeReceipt {
  return receipt.format === 'iris-social/archive-source-mode@1';
}
export function isArchiveKindExpansionReceipt(receipt: ArchiveLineageReceipt): receipt is ArchiveKindExpansionReceipt {
  return receipt.format === 'iris-social/archive-kind-expansion@1';
}
export function isArchiveCommitBatchReceipt(receipt: ArchiveLineageReceipt): receipt is ArchiveCommitBatchReceipt {
  return receipt.format === 'iris-social/archive-commit-batch@1';
}
export function isArchivePolicyTransition(receipt: ArchiveLineageReceipt): receipt is ArchiveRelayRemovalReceipt | ArchiveSourceModeReceipt | ArchiveKindExpansionReceipt | ArchiveCommitBatchReceipt {
  return isArchiveRelayRemovalReceipt(receipt) || isArchiveSourceModeReceipt(receipt)
    || isArchiveKindExpansionReceipt(receipt) || isArchiveCommitBatchReceipt(receipt);
}

/** No source, root, frontier or window changes; the separately pinned edge accounts for the hash rebind. */
export function validateArchiveCommitBatchReceipt(receipt: ArchiveCommitBatchReceipt, authors?: readonly string[]): void {
  const { before, after } = receipt;
  const validBatch = (value: number) => Number.isSafeInteger(value) && value >= 1 && value <= 65536;
  if (receipt.format !== 'iris-social/archive-commit-batch@1' || receipt.completed !== true
    || ![receipt.beforeCheckpointSha256, receipt.afterCheckpointSha256, receipt.previousNativeAuthoritySha256]
      .every(value => typeof value === 'string' && SHA.test(value))
    || receipt.beforeCheckpointSha256 === receipt.afterCheckpointSha256
    || before?.version !== 2 || after?.version !== 2 || !before.policy || !after.policy
    || before.policy.source_mode !== 'best-effort' || after.policy.source_mode !== 'best-effort'
    || !validBatch(before.policy.index_commit_batch_size) || !validBatch(after.policy.index_commit_batch_size)
    || before.policy.index_commit_batch_size === after.policy.index_commit_batch_size
    || canonical({ ...after.policy, index_commit_batch_size: before.policy.index_commit_batch_size }) !== canonical(before.policy)
    || canonical({ ...after, policy: before.policy, coverage_head: before.coverage_head }) !== canonical(before)
    || !Number.isSafeInteger(before.next_author) || before.next_author < 1 || before.next_author >= before.policy.author_count
    || !receipt.coverageRebind || canonical(Object.keys(receipt.coverageRebind).sort()) !== canonical(['after', 'before'])) {
    throw new Error('Invalid archive commit batch receipt');
  }
  const oldProof = receipt.coverageRebind.before, newProof = receipt.coverageRebind.after;
  const oldCoverage = parseArchiveSourceCoverage(oldProof), newCoverage = parseArchiveSourceCoverage(newProof);
  if (oldProof.sha256 !== before.coverage_head || newProof.sha256 !== after.coverage_head
    || oldCoverage.policy_sha256 !== digest(canonical(before.policy))
    || newCoverage.policy_sha256 !== digest(canonical(after.policy))
    || canonical({ ...newCoverage, policy_sha256: oldCoverage.policy_sha256 }) !== canonical(oldCoverage)
    || oldCoverage.after_root !== before.root || oldCoverage.ordinal + 1 !== before.next_author
    || oldCoverage.pass_since !== before.pass_since || oldCoverage.pass_until !== before.pass_until
    || oldCoverage.events_received > before.events_received
    || canonical(oldCoverage.sources.map(source => source.relay)) !== canonical(before.policy.relays)
    || (authors && (authors.length !== before.policy.author_count || oldCoverage.author !== authors[oldCoverage.ordinal]))) {
    throw new Error('Commit batch transition must preserve exact saved source coverage');
  }
}

export function validateArchiveKindExpansionReceipt(receipt: ArchiveKindExpansionReceipt): void {
  const { before, after } = receipt;
  const validKinds = (kinds: number[]) => Array.isArray(kinds) && kinds.includes(5)
    && kinds.every((kind, index) => Number.isSafeInteger(kind) && kind >= 0 && kind <= 65535
      && !(kind >= 20000 && kind < 30000) && (index === 0 || kinds[index - 1] < kind));
  if (receipt.format !== 'iris-social/archive-kind-expansion@1' || receipt.completed !== true
    || ![receipt.beforeCheckpointSha256, receipt.afterCheckpointSha256, receipt.previousNativeAuthoritySha256]
      .every(value => typeof value === 'string' && SHA.test(value))
    || receipt.beforeCheckpointSha256 === receipt.afterCheckpointSha256
    || before?.version !== 2 || after?.version !== 2 || !before.policy || !after.policy
    || before.policy.source_mode !== 'best-effort' || after.policy.source_mode !== 'best-effort'
    || !validKinds(before.policy.kinds) || !validKinds(after.policy.kinds)
    || after.policy.kinds.length <= before.policy.kinds.length
    || !before.policy.kinds.every(kind => after.policy.kinds.includes(kind))
    || canonical({ ...after.policy, kinds: before.policy.kinds }) !== canonical(before.policy)
    || after.next_author !== 0 || Object.hasOwn(after, 'coverage_head')
    || after.pass_since !== before.policy.initial_since) {
    throw new Error('Invalid archive kind expansion receipt');
  }
  const { coverage_head: _head, ...prior } = before;
  if (canonical({ ...after, policy: before.policy, next_author: before.next_author, pass_since: before.pass_since }) !== canonical(prior)) {
    throw new Error('Kind expansion must preserve the exact accumulated checkpoint');
  }
  nhashDecode(after.root);
}

export function validateArchiveSourceModeReceipt(receipt: ArchiveSourceModeReceipt): void {
  const { before, after } = receipt;
  if (receipt.format !== 'iris-social/archive-source-mode@1' || receipt.completed !== true
    || ![receipt.beforeCheckpointSha256, receipt.afterCheckpointSha256, receipt.previousNativeAuthoritySha256]
      .every(value => typeof value === 'string' && SHA.test(value))
    || receipt.beforeCheckpointSha256 === receipt.afterCheckpointSha256
    || before?.version !== 2 || after?.version !== 2 || !before.policy || !after.policy
    || before.policy.source_mode !== undefined || after.policy.source_mode !== 'best-effort'
    || before.coverage_head !== undefined || after.coverage_head !== undefined
    || canonical({ ...after, policy: before.policy }) !== canonical(before)) {
    throw new Error('Invalid archive source mode receipt');
  }
  const { source_mode: _mode, ...policy } = after.policy;
  if (canonical(policy) !== canonical(before.policy)) {throw new Error('Source mode may change only source_mode');}
}

/** Native emits compact UTF-8 JSON plus newline; roundtrip rejects duplicate keys and alternate numeric encodings. */
export function parseArchiveSourceCoverage(proof: ArchiveSourceCoverageProof): ArchiveSourceCoverageReceipt {
  if (!proof || typeof proof.raw !== 'string' || Buffer.byteLength(proof.raw) > ARCHIVE_COVERAGE_MAX_BYTES
    || canonical(Object.keys(proof).sort()) !== canonical(['raw', 'sha256'])
    || typeof proof.sha256 !== 'string' || !SHA.test(proof.sha256) || digest(proof.raw) !== proof.sha256) {
    throw new Error('Invalid archive source coverage hash or bytes');
  }
  const value = JSON.parse(proof.raw) as ArchiveSourceCoverageReceipt;
  const fields = ['format', 'previous_head', 'policy_sha256', 'pass_since', 'pass_until', 'author', 'ordinal',
    'before_root', 'after_root', 'events_received', 'sources'];
  if (value && Object.hasOwn(value, 'pubsub')) {fields.push('pubsub');}
  if (!value || canonical(Object.keys(value).sort()) !== canonical(fields.sort())
    || proof.raw !== `${JSON.stringify(value)}\n` || value.format !== 'hashtree/nostr-index-catchup-coverage@1'
    || (value.previous_head !== null && (typeof value.previous_head !== 'string' || !SHA.test(value.previous_head)))
    || typeof value.policy_sha256 !== 'string' || !SHA.test(value.policy_sha256)
    || typeof value.author !== 'string' || !SHA.test(value.author)
    || ![value.pass_since, value.pass_until, value.ordinal, value.events_received]
      .every(number => Number.isSafeInteger(number) && number >= 0)
    || value.pass_since > value.pass_until || !Array.isArray(value.sources) || !value.sources.length) {
    throw new Error('Invalid archive source coverage receipt');
  }
  nhashDecode(value.before_root); nhashDecode(value.after_root);
  for (const source of value.sources) {
    if (!source || typeof source.relay !== 'string'
      || !['complete', 'failed', 'skipped'].includes(source.status)
      || canonical(Object.keys(source).sort()) !== canonical((source.status === 'complete'
        ? ['relay', 'status'] : ['error', 'relay', 'status']).sort())
      || (source.status !== 'complete' && (typeof source.error !== 'string' || !source.error.length
        || Array.from(source.error).length > 256))) {
      throw new Error('Invalid archive source outcome');
    }
  }
  if (!value.sources.some(source => source.status === 'complete')) {throw new Error('Author has no completed source');}
  if (Object.hasOwn(value, 'pubsub')) {
    const peer = value.pubsub;
    if (!peer || canonical(Object.keys(peer).sort()) !== canonical(['added_events', 'event_ids_sha256', 'events', 'sources', 'status'])
      || !['observed', 'unavailable'].includes(peer.status)
      || ![peer.events, peer.added_events].every(count => Number.isSafeInteger(count) && count >= 0)
      || peer.added_events > peer.events || peer.added_events > value.events_received || peer.events > 128
      || typeof peer.event_ids_sha256 !== 'string' || !SHA.test(peer.event_ids_sha256)
      || !peer.sources || Array.isArray(peer.sources) || typeof peer.sources !== 'object'
      || Object.entries(peer.sources).some(([id, count]) => !validPeer(id) || !Number.isSafeInteger(count) || count <= 0 || count > peer.events)
      || Object.values(peer.sources).reduce((sum, count) => sum + count, 0) !== peer.events
      || (peer.events === 0 && peer.event_ids_sha256 !== digest(''))
      || (peer.status === 'unavailable' && peer.events !== 0)) {
      throw new Error('Invalid archive pubsub observation');
    }
  }
  return value;
}

/** Every proof advances one exact author and binds its full frozen window, source outcomes and root change. */
export function validateArchiveCoverageStep(before: ArchiveCheckpoint | null, after: ArchiveCheckpoint,
  range: [number, number], proofs: readonly ArchiveSourceCoverageProof[], authors?: readonly string[], strictCoverage = false): void {
  const strict = after.policy.source_mode === undefined;
  if (strict && (!strictCoverage || (after.coverage_head === undefined && before?.coverage_head === undefined && !proofs.length))) {
    if (after.coverage_head !== undefined || before?.coverage_head !== undefined || proofs.length) {
      throw new Error('Strict checkpoint cannot carry best-effort source coverage');
    }
    return;
  }
  if ((!strict && (after.policy.source_mode !== 'best-effort' || !before))
    || (before && before.policy.source_mode !== after.policy.source_mode)
    || !authors || authors.length !== after.policy.author_count
    || (before?.coverage_head !== undefined && !SHA.test(before.coverage_head))
    || (after.coverage_head !== undefined && !SHA.test(after.coverage_head))
    || proofs.length !== range[1] - range[0] || proofs.length > 64) {
    throw new Error('Checkpoint requires exact author coverage');
  }
  const relays = after.policy.relays;
  if (!relays.length || canonical(relays) !== canonical([...new Set(relays)].sort())) {
    throw new Error('Invalid coverage source set');
  }
  let head = before?.coverage_head ?? null, root = before?.root ?? after.policy.base_root, received = 0;
  for (const [index, proof] of proofs.entries()) {
    const receipt = parseArchiveSourceCoverage(proof);
    if (receipt.previous_head !== head || receipt.before_root !== root
      || receipt.policy_sha256 !== digest(canonical(after.policy))
      || receipt.pass_since !== after.pass_since || receipt.pass_until !== after.pass_until
      || receipt.ordinal !== range[0] + index || receipt.author !== authors[receipt.ordinal]
      || canonical(receipt.sources.map(source => source.relay)) !== canonical(relays)
      || (strict && receipt.sources.some(source => source.status !== 'complete'))
      || (receipt.pubsub && receipt.pubsub.events > after.policy.max_events_per_author)) {
      throw new Error('Source coverage does not match the exact native author step');
    }
    received += receipt.events_received;
    if (!Number.isSafeInteger(received)) {throw new Error('Source coverage event count overflow');}
    root = receipt.after_root; head = proof.sha256;
  }
  if (head !== (after.coverage_head ?? null) || root !== after.root || received !== after.events_received - (before?.events_received ?? 0)) {
    throw new Error('Source coverage does not match the committed checkpoint');
  }
}
