import { nhashDecode, toHex, type Store } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import { HashtreeNostrEventReader } from '@hashtree/nostr-pubsub';
import { verifyEvent } from 'nostr-tools/pure';
import { canonical, digest, type ArchiveCandidate, type ArchiveCheckpoint, type ArchiveRunReceipt,
  type ArchiveLineageReceipt, type ArchiveRelayRemovalReceipt } from './archiveCheckpointOutbox';
import type { ArchiveRepairReceipt } from './archiveCheckpointOutbox';
import { validateArchiveRepairHistory, validateArchiveRepairLineage } from './archiveCheckpointRepair';
import { validateArchiveRelayRemovalReceipt } from './archiveCheckpointRelayPolicy';
import { isArchivePolicyTransition, isArchiveSourceModeReceipt, validateArchiveSourceModeReceipt,
  isArchiveKindExpansionReceipt, validateArchiveKindExpansionReceipt,
  isArchiveCommitBatchReceipt, validateArchiveCommitBatchReceipt,
  validateArchiveCoverageStep, type ArchiveSourceValidationOptions } from './archiveCheckpointSourceCoverage';

export function archiveReceiptChain(run: ArchiveRunReceipt, previous: ArchiveCheckpoint | null,
  receipts: ArchiveRunReceipt[]): ArchiveRunReceipt[];
export function archiveReceiptChain(run: ArchiveRunReceipt, previous: ArchiveCheckpoint | null,
  receipts: ArchiveLineageReceipt[]): ArchiveLineageReceipt[];
export function archiveReceiptChain(run: ArchiveRunReceipt, previous: ArchiveCheckpoint | null,
  receipts: ArchiveLineageReceipt[]): ArchiveLineageReceipt[] {
  const chain: ArchiveLineageReceipt[] = [];
  let cursor = run.before;
  const initial = (state: ArchiveCheckpoint | null) => !previous && state?.next_author === 0
    && state.events_received === 0 && state.root === run.after.policy.base_root;
  while (canonical(cursor) !== canonical(previous) && !initial(cursor)) {
    if (chain.length >= 65) { throw new Error('Native receipt chain exceeds publication batch'); }
    const parent = receipts.find(receipt => canonical(receipt.after) === canonical(cursor)
      && canonical(receipt.before) !== canonical(receipt.after));
    if (!parent) { throw new Error('Missing durable native receipt chain'); }
    chain.unshift(parent); cursor = parent.before;
    if (chain.filter(isArchivePolicyTransition).length > 1
      || chain.filter(receipt => !isArchivePolicyTransition(receipt)).length > 64) {
      throw new Error('Native receipt chain exceeds publication batch');
    }
  }
  return chain;
}

export function validateArchiveCandidate(candidate: ArchiveCandidate, policy: ArchiveCheckpoint['policy'],
  authoritySha256: string, previous: ArchiveCheckpoint | null, now: number,
  trustedPriorRuns: readonly ArchiveRunReceipt[] = [], trustedRepairs: readonly ArchiveRepairReceipt[] = [],
  trustedRelayRemovals: readonly ArchiveRelayRemovalReceipt[] = [],
  sourceOptions: ArchiveSourceValidationOptions = {}): [number, number] {
  validateArchiveRepairHistory(trustedRepairs);
  if (candidate.repairReceipts !== undefined && !Array.isArray(candidate.repairReceipts)) {throw new Error('Invalid archive repair lineage');}
  if (candidate.repairReceipts?.length) {
    if (!previous) {throw new Error('Archive repair requires a previous published checkpoint');}
    const range = validateArchiveCandidate({ ...candidate, state: candidate.run.after, repairReceipts: undefined },
      policy, authoritySha256, previous, now, trustedPriorRuns, [], trustedRelayRemovals, sourceOptions);
    validateArchiveRepairLineage(candidate, authoritySha256, trustedRepairs);
    return range;
  }
  const { state, run } = candidate;
  if (trustedPriorRuns.length > 64) {throw new Error('Too many trusted prior native receipts');}
  if (trustedRelayRemovals.length > 1) {throw new Error('Too many trusted relay removal receipts');}
  const sourceModes = sourceOptions.sourceModeReceipts ?? [];
  if (sourceModes.length > 1) {throw new Error('Too many trusted source mode receipts');}
  const kindExpansions = sourceOptions.kindExpansionReceipts ?? [];
  if (kindExpansions.length > 1) {throw new Error('Too many trusted kind expansion receipts');}
  const commitBatches = sourceOptions.commitBatchReceipts ?? [];
  if (commitBatches.length > 1) {throw new Error('Too many trusted commit batch receipts');}
  if (candidate.sourceCoverage !== undefined && !Array.isArray(candidate.sourceCoverage)) {
    throw new Error('Invalid source coverage proof count');
  }
  const proofs = candidate.sourceCoverage ?? [];
  if (!Array.isArray(proofs) || proofs.length > 64) {throw new Error('Invalid source coverage proof count');}
  let covered = 0;
  const checkCoverage = (before: ArchiveCheckpoint | null, after: ArchiveCheckpoint, range: [number, number]) => {
    const count = after.policy.source_mode === 'best-effort' || (sourceOptions.strictCoverage && after.coverage_head !== undefined) ? range[1] - range[0] : 0;
    validateArchiveCoverageStep(before, after, range, proofs.slice(covered, covered + count), sourceOptions.authors, sourceOptions.strictCoverage);
    covered += count;
  };
  const finish = (range: [number, number]): [number, number] => {
    if (covered !== proofs.length) {throw new Error('Unexpected archive source coverage proofs');}
    return range;
  };
  const trusted = new Set(trustedPriorRuns.map(receipt => canonical(receipt)));
  if (candidate.intermediateRuns?.length) {
    let cursor = previous;
    let start = 0;
    let end = 0;
    let started = false;
    const runs = [...candidate.intermediateRuns, run];
    const transitions = candidate.intermediateRuns.filter(isArchivePolicyTransition);
    const transition = transitions[0];
    if (transitions.length > 1 || runs.length - transitions.length > 65 || run.exitCode !== 0) {
      throw new Error('Invalid native receipt chain');
    }
    if (transition) {
      const trustedTransitions = isArchiveKindExpansionReceipt(transition) ? kindExpansions
        : isArchiveCommitBatchReceipt(transition) ? commitBatches
        : isArchiveSourceModeReceipt(transition) ? sourceModes : trustedRelayRemovals;
      if (isArchiveSourceModeReceipt(transition)) {validateArchiveSourceModeReceipt(transition);}
      else if (isArchiveKindExpansionReceipt(transition)) {
        validateArchiveKindExpansionReceipt(transition);
        if (runs[0] !== transition) {throw new Error('Kind expansion requires a published checkpoint boundary');}
      }
      else if (isArchiveCommitBatchReceipt(transition)) {
        validateArchiveCommitBatchReceipt(transition, sourceOptions.authors);
        if (runs[0] !== transition) {throw new Error('Commit batching requires a published checkpoint boundary');}
      }
      else {validateArchiveRelayRemovalReceipt(transition);}
      if (!previous || !trustedTransitions.some(receipt => canonical(receipt) === canonical(transition))
        || canonical(transition.after.policy) !== canonical(policy)) {
        throw new Error('Untrusted archive policy transition');
      }
    }
    let beforeTransition = !!transition;
    for (const [index, receipt] of runs.entries()) {
      if (isArchivePolicyTransition(receipt)) {
        if (canonical(receipt.before) !== canonical(cursor)
          || (!isArchiveSourceModeReceipt(receipt) && receipt.after.pass_until !== state.pass_until)) {
          throw new Error('Policy transition does not continue the exact native checkpoint');
        }
        end = receipt.after.next_author; cursor = receipt.after; beforeTransition = false;
        continue;
      }
      if (!Number.isSafeInteger(receipt.exitCode) || receipt.after.pass_until !== state.pass_until) {
        throw new Error('Native receipt chain crosses unrelated passes');
      }
      const intermediate = index < runs.length - 1;
      if (beforeTransition && (!intermediate || receipt.exitCode === 0 || !trusted.has(canonical(receipt))
        || receipt.authoritySha256 !== transition!.previousNativeAuthoritySha256)) {
        throw new Error('Policy transition requires an exact protected failed native prefix');
      }
      // Only an exact, separately digest-pinned failed prefix may cross an
      // executable upgrade. The terminal success must use the live authority.
      const acceptedAuthority = beforeTransition ? transition!.previousNativeAuthoritySha256
        : !transition && intermediate && receipt.exitCode !== 0 && trusted.has(canonical(receipt))
          ? receipt.authoritySha256 : authoritySha256;
      const acceptedPolicy = beforeTransition ? transition!.before.policy : policy;
      const range = validateArchiveStep({ ...candidate, state: receipt.after,
        run: { ...receipt, exitCode: 0 }, intermediateRuns: undefined }, acceptedPolicy, acceptedAuthority, cursor, now,
      intermediate);
      checkCoverage(cursor, receipt.after, range);
      if (!started) {start = range[0]; started = true;}
      end = range[1]; cursor = receipt.after;
    }
    if (canonical(cursor) !== canonical(state) || end - start > 64) { throw new Error('Native receipt chain exceeds publication batch'); }
    return finish([start, end]);
  }
  const range = validateArchiveStep(candidate, policy, authoritySha256, previous, now, false);
  checkCoverage(previous, state, range);
  return finish(range);
}

function validateArchiveStep(candidate: ArchiveCandidate, policy: ArchiveCheckpoint['policy'],
  authoritySha256: string, previous: ArchiveCheckpoint | null, now: number, intermediate: boolean): [number, number] {
  const { state, run } = candidate;
  const initialEmpty = !previous && run.before?.version === 2 && canonical(run.before.policy) === canonical(policy)
    && run.before.root === policy.base_root && run.before.next_author === 0 && run.before.events_received === 0
    && run.before.pass_since === policy.initial_since && run.before.pass_until === state.pass_until;
  if (run.format !== 'iris-social/archive-catchup-run@1' || run.exitCode !== 0
    || !run.originalAndPoolPinsUnchanged || run.authoritySha256 !== authoritySha256
    || (previous && canonical(previous.policy) !== canonical(policy))
    || canonical(run.after) !== canonical(state) || (!initialEmpty && canonical(run.before) !== canonical(previous))) {
    throw new Error('Native receipt does not continue the last published checkpoint');
  }
  const emptyRollover = intermediate && previous?.next_author === policy.author_count
    && state.next_author === 0 && state.root === previous.root && state.events_received === previous.events_received;
  if (state.version !== 2 || canonical(state.policy) !== canonical(policy)
    || !Number.isSafeInteger(state.next_author) || state.next_author < (emptyRollover ? 0 : 1) || state.next_author > policy.author_count
    || !Number.isSafeInteger(state.pass_since) || !Number.isSafeInteger(state.pass_until)
    || state.pass_since < policy.initial_since || state.pass_since > state.pass_until || state.pass_until > now
    || !Number.isSafeInteger(state.events_received) || state.events_received < (previous?.events_received ?? 0)) {
    throw new Error('Invalid native checkpoint policy or frontier');
  }
  let start = 0;
  if (!previous) {
    if (state.pass_since !== policy.initial_since) {throw new Error('First pass must start at original gap floor');}
  } else if (state.pass_until === previous.pass_until) {
    if (state.pass_since !== previous.pass_since || state.next_author <= previous.next_author) {
      throw new Error('Native checkpoint did not advance its fixed author prefix');
    }
    start = previous.next_author;
  } else if (previous.next_author !== policy.author_count || state.pass_until <= previous.pass_until
    || state.pass_since !== Math.max(policy.initial_since, previous.pass_until - policy.overlap_secs)) {
    throw new Error('Invalid catchup pass rollover');
  }
  if (state.next_author - start > 64) {throw new Error('Publication batch exceeds 64 authors');}
  nhashDecode(state.root); nhashDecode(policy.base_root);
  return [start, state.next_author];
}

interface ArchiveReadFailure {
  blockHash: string;
  reason: 'http' | 'request-budget' | 'byte-budget' | 'hash-mismatch' | 'transport' | 'aborted' | 'timeout';
  httpStatus?: number;
}

export function archiveReadStore(endpoint: string, signal: AbortSignal,
  limits = { requests: 4096, bytes: 64 * 1024 * 1024, blockBytes: 2 * 1024 * 1024 }) {
  const origin = new URL(endpoint);
  if (!['https:', 'http:'].includes(origin.protocol) || origin.username || origin.password || origin.search || origin.hash) {
    throw new Error('Invalid archive read endpoint');
  }
  // Shared cached reads are run-wide evidence, not attribution to one author.
  const network = { requests: 0, bytes: 0, failures: [] as ArchiveReadFailure[], omittedFailures: 0 };
  const cache = new Map<string, Promise<Uint8Array>>();
  const store: Store = {
    async put() { throw new Error('Archive verification is read-only'); },
    async delete() { throw new Error('Archive verification is read-only'); },
    async has(hash) { await this.get(hash); return true; },
    async get(hash) {
      const key = toHex(hash);
      let pending = cache.get(key);
      if (!pending) {
        pending = (async () => {
          const failure: ArchiveReadFailure = { blockHash: key, reason: 'transport' };
          try {
            signal.throwIfAborted();
            if (++network.requests > limits.requests) {
              failure.reason = 'request-budget';
              throw new Error('Archive request budget exceeded');
            }
            const response = await fetch(`${endpoint.replace(/\/$/, '')}/${key}.bin`, {
              signal: AbortSignal.any([signal, AbortSignal.timeout(15_000)]),
            });
            if (!response.ok || !response.body) {
              failure.reason = 'http'; failure.httpStatus = response.status;
              await response.body?.cancel(); throw new Error(`Archive read HTTP ${response.status}`);
            }
            const reader = response.body.getReader();
            const chunks: Uint8Array[] = [];
            let length = 0;
            try {
              while (true) {
                const { done, value } = await reader.read();
                if (done) {break;}
                length += value.length; network.bytes += value.length;
                if (length > limits.blockBytes || network.bytes > limits.bytes) {
                  failure.reason = 'byte-budget';
                  throw new Error('Archive byte budget exceeded');
                }
                chunks.push(value);
              }
            } finally { await reader.cancel(); }
            const bytes = Buffer.concat(chunks);
            if (digest(bytes) !== key) {
              failure.reason = 'hash-mismatch';
              throw new Error('Archive raw block hash mismatch');
            }
            return bytes;
          } catch (error) {
            if (failure.reason === 'transport') {
              if (signal.aborted) {failure.reason = 'aborted';}
              else if (error instanceof DOMException && error.name === 'TimeoutError') {failure.reason = 'timeout';}
            }
            // Never retain exception messages, URLs, abort reasons or bodies.
            if (network.failures.length < 4) {network.failures.push(failure);}
            else {network.omittedFailures++;}
            throw error;
          }
        })();
        cache.set(key, pending);
      }
      return await pending;
    },
  };
  return { store, network };
}

export interface ArchiveVerificationProgress {
  phase: 'manifest' | 'authors' | 'retention' | 'complete' | 'failed';
  elapsedMs: number;
  manifestMs: number;
  authorsMs: number;
  retentionMs: number;
  authorsChecked: number;
  retentionBatchesChecked: number;
  retainedIds: number;
}

/** Four workers, ordered results, no new work after failure, and all workers drained. */
async function verifyInParallel<T, R>(items: T[], verify: (item: T, index: number) => Promise<R>, fail: (error: unknown) => void) {
  const results = new Array<R>(items.length);
  let next = 0, failed = false;
  let failure: unknown;
  await Promise.all(Array.from({ length: Math.min(4, items.length) }, async () => {
    while (!failed && next < items.length) {
      const index = next++;
      try { results[index] = await verify(items[index], index); }
      catch (error) {
        if (!failed) { failed = true; failure = error; fail(error); }
      }
    }
  }));
  if (failed) {throw failure;}
  return results;
}

function safeArchiveReaderReason(reason?: string): string {
  // Reader reports can contain arbitrary Error.message text. Only known fixed
  // descriptions may enter operational logs; never copy a nested cause.
  const safe = [
    'Unable to read a Hashtree replica block',
    'Unable to check a Hashtree replica block',
    'Hashtree Nostr replica contains unreadable index data',
    'Hashtree Nostr replica contains an event with an invalid id or signature',
  ];
  if (reason && safe.includes(reason)) {return reason;}
  if (/^Hashtree replica is missing block [0-9a-f]{64}$/.test(reason ?? '')) {return 'Hashtree replica is missing block';}
  return 'Other reader failure';
}

interface ArchiveQueryContext {
  rootRole: 'previous' | 'candidate';
  /** Zero-based offset in the supplied author batch, not completion order. */
  authorOffset?: number;
  retentionBatchOffset?: number;
}

/** Standard production reader, bounded exact author and ID queries; no archive walk. */
export async function verifyArchiveAppend(store: Store, candidateRoot: string, previousRoot: string,
  authors: string[], canaryIds: string[], signal: AbortSignal,
  progress?: (value: ArchiveVerificationProgress) => void) {
  const started = performance.now(), cancellation = new AbortController();
  const verificationSignal = AbortSignal.any([signal, cancellation.signal]);
  const reads = new Set<Promise<unknown>>();
  let stopped = false, complete = false, authorsChecked = 0, retentionBatchesChecked = 0, retainedIds = 0;
  const times = { manifest: 0, authors: 0, retention: 0 };
  let measuredPhase: keyof typeof times = 'manifest', phaseStarted = started;
  const report = (phase: ArchiveVerificationProgress['phase']) => {
    const now = performance.now();
    times[measuredPhase] += now - phaseStarted;
    if (phase === 'manifest' || phase === 'authors' || phase === 'retention') {measuredPhase = phase;}
    phaseStarted = now;
    progress?.({ phase, elapsedMs: Math.round(now - started), manifestMs: Math.round(times.manifest),
      authorsMs: Math.round(times.authors), retentionMs: Math.round(times.retention),
      authorsChecked, retentionBatchesChecked, retainedIds });
  };
  const fail = (error: unknown) => { stopped = true; cancellation.abort(error); };
  const read = <T>(operation: () => Promise<T>): Promise<T> => {
    verificationSignal.throwIfAborted();
    if (stopped) {throw new Error('Archive verification stopped');}
    const pending = Promise.resolve().then(operation);
    reads.add(pending);
    void pending.then(() => reads.delete(pending), () => reads.delete(pending));
    return pending;
  };
  const tracked: Store = {
    get: hash => read(() => store.get(hash)), has: hash => read(() => store.has(hash)),
    async put() {throw new Error('Archive verification is read-only');},
    async delete() {throw new Error('Archive verification is read-only');},
  };
  try {
    report('manifest');
    const manifest = await new NostrEventStore(tracked).getManifest(nhashDecode(candidateRoot));
    verificationSignal.throwIfAborted();
    if (Object.values(manifest).some(value => value === null)) {throw new Error('Candidate archive index is incomplete');}
    const makeReader = (value: string) => new HashtreeNostrEventReader({ store: tracked, roots: {
      snapshot: () => [{ root: nhashDecode(value), partitionId: 'publication-exact-root' }],
    } });
    const reader = makeReader(candidateRoot), before = makeReader(previousRoot);
    const query = async (source: typeof reader, filters: Parameters<typeof reader.query>[0], limit: number,
      context: ArchiveQueryContext) => {
      verificationSignal.throwIfAborted();
      const result = await source.query(filters, { limit, signal: verificationSignal, deadline: Date.now() + 30_000 });
      if (!result.complete) {
        const attempts = result.partitions.flatMap(partition => partition.attempts);
        const diagnostic = { ...context, attempts: attempts.slice(0, 4).map(attempt => ({
          status: attempt.status, reason: safeArchiveReaderReason(attempt.reason),
        })), omittedAttempts: Math.max(0, attempts.length - 4) };
        throw new Error(`Archive query incomplete; publication held ${JSON.stringify(diagnostic)}`);
      }
      if (result.events.some(({ event }) => !verifyEvent(JSON.parse(JSON.stringify(event))))) {
        throw new Error('Archive query returned an invalid signed event');
      }
      return result.events.map(item => item.event);
    };
    report('authors');
    const pairs = await verifyInParallel(authors, async (author, authorOffset) => {
      const old = await query(before, [{ authors: [author], kinds: [1] }], 3, { rootRole: 'previous', authorOffset });
      const newest = await query(reader, [{ authors: [author], kinds: [1] }], 3, { rootRole: 'candidate', authorOffset });
      if (old.length && !newest.length) {throw new Error('Previously nonempty author became empty');}
      authorsChecked++;
      return [...old, ...newest];
    }, fail);
    const retained = new Set(canaryIds);
    for (const events of pairs) {for (const event of events) {retained.add(event.id);}}
    const ids = [...retained];
    retainedIds = ids.length;
    report('retention');
    const batches: string[][] = [];
    // The reader resolves IDs sequentially within each query. Small batches
    // keep all four existing workers useful even for a short retained-ID set.
    for (let offset = 0; offset < ids.length; offset += 8) {batches.push(ids.slice(offset, offset + 8));}
    await verifyInParallel(batches, async (wanted, retentionBatchOffset) => {
      const found = new Set((await query(reader, [{ ids: wanted }], wanted.length,
        { rootRole: 'candidate', retentionBatchOffset })).map(event => event.id));
      if (wanted.some(id => !found.has(id))) {throw new Error('Archive append lost a baseline or newly queried event');}
      retentionBatchesChecked++;
    }, fail);
    verificationSignal.throwIfAborted();
    complete = true;
  } catch (error) { fail(error); throw error; }
  finally {
    stopped = true;
    // Reader cancellation races its Store.get. Drain those underlying reads as
    // well as the worker promises before the publication lock may be released.
    await Promise.allSettled([...reads]);
    report(complete ? 'complete' : 'failed');
  }
  // Success is decided only after cleanup/reporting. Keep this outside finally
  // so cancellation cannot replace an earlier verification failure.
  verificationSignal.throwIfAborted();
  return { authors: authors.length, retainedIds };
}
