import { createHash } from 'node:crypto';
import { SocialGraph } from 'nostr-social-graph';
import {
  BROAD_ARCHIVE_CENSUS_FORMAT,
  validateBroadArchiveCensusArtifacts,
  type BroadArchiveCensusReport,
} from './broadArchiveRollout';
import { censusNostrSocialGraph } from './nostrArchiveOvermute';
import {
  PROFILE_SEARCH_V3_RANK_DECISION_FORMAT,
  profileSearchV3RankDecisionsSha256,
  type ProfileSearchV3RankDecisions,
} from './profileSearchV3CatalogBuilder';

export const PROFILE_SEARCH_V3_RANK_DECISION_ARTIFACTS_FORMAT =
  'iris-social/profile-search-v3-rank-decision-artifacts@1' as const;
export const PROFILE_SEARCH_V3_GRAPH_RANK_POLICY = 'follow-distance@1' as const;
export const PROFILE_SEARCH_V3_GRAPH_EXCLUSION_POLICY =
  'all-nonselected-graph-identities@1' as const;

const HEX_64 = /^[0-9a-f]{64}$/;

export interface ProfileSearchV3RankDecisionArtifactReport {
  format: typeof PROFILE_SEARCH_V3_RANK_DECISION_ARTIFACTS_FORMAT;
  censusFormat: typeof BROAD_ARCHIVE_CENSUS_FORMAT;
  socialGraphRoot: string;
  socialGraphSha256: string;
  eligibleAuthorsSha256: string;
  overmuteThreshold: number;
  maxDistance: number | null;
  rankPolicy: typeof PROFILE_SEARCH_V3_GRAPH_RANK_POLICY;
  exclusionPolicy: typeof PROFILE_SEARCH_V3_GRAPH_EXCLUSION_POLICY;
  recordCount: number;
  eligibleCount: number;
  excludedCount: number;
  reachableCount: number;
  reachableOvermutedCount: number;
  distanceExcludedCount: number;
  unreachableCount: number;
  allGraphOvermutedCount: number;
  rankDecisionsSha256: string;
  rankDecisionsFileSha256: string;
};

export interface ProfileSearchV3RankDecisionArtifacts {
  decisions: ProfileSearchV3RankDecisions;
  rankDecisionsText: string;
  report: ProfileSearchV3RankDecisionArtifactReport;
}

/**
 * Bind Profile Search v3 visibility and social rank to the exact crawl census.
 * Every graph identity receives a decision: selected authors get their frozen
 * follow distance, while overmuted, unreachable, and distance-capped identities
 * are explicit exclusions.
 */
export async function createProfileSearchV3RankDecisionArtifacts(
  snapshotBytes: Uint8Array,
  eligibleAuthorsText: string,
  rawReport: unknown,
): Promise<ProfileSearchV3RankDecisionArtifacts> {
  const eligibleAuthors = await validateBroadArchiveCensusArtifacts(
    snapshotBytes,
    eligibleAuthorsText,
    rawReport,
    1,
  );
  const report = rawReport as BroadArchiveCensusReport;
  const graph = await SocialGraph.fromBinary(report.socialGraphRoot, snapshotBytes);
  const { ids } = graph.getInternalData();
  const eligible = new Set(eligibleAuthors);
  const decisions = new Map<string, number | null>();

  // Recompute overmute policy from the exact snapshot through the same census
  // path used to validate the crawl allowlist.
  const census = censusNostrSocialGraph(graph, report.overmuteThreshold);
  for (const [, pubkey] of ids) {
    if (!HEX_64.test(pubkey) || decisions.has(pubkey)) {
      throw new Error('Profile-search v3 graph contains an invalid or duplicate identity');
    }
    const overmuted = census.overmutedPubkeys.has(pubkey);
    if (!eligible.has(pubkey)) {
      decisions.set(pubkey, null);
      continue;
    }
    const distance = graph.getFollowDistance(pubkey);
    if (overmuted
      || !Number.isSafeInteger(distance)
      || distance < 0
      || distance >= 1_000
      || (report.maxDistance !== null && distance > report.maxDistance)) {
      throw new Error('Profile-search v3 eligible identity violates the frozen graph policy');
    }
    decisions.set(pubkey, distance);
  }

  if (decisions.size === 0
    || eligible.size !== eligibleAuthors.length
    || eligible.size !== [...decisions.values()].filter((rank) => rank !== null).length
    || eligibleAuthors.some((pubkey) => !decisions.has(pubkey))) {
    throw new Error('Profile-search v3 decisions do not cover the exact eligible allowlist');
  }
  const rankDecisionsSha256 = profileSearchV3RankDecisionsSha256(decisions);
  const rankDecisionsText = encodeRankDecisions(decisions, rankDecisionsSha256);
  return {
    decisions,
    rankDecisionsText,
    report: {
      format: PROFILE_SEARCH_V3_RANK_DECISION_ARTIFACTS_FORMAT,
      censusFormat: BROAD_ARCHIVE_CENSUS_FORMAT,
      socialGraphRoot: report.socialGraphRoot,
      socialGraphSha256: report.socialGraphSha256,
      eligibleAuthorsSha256: report.eligibleAuthorsSha256,
      overmuteThreshold: report.overmuteThreshold,
      maxDistance: report.maxDistance,
      rankPolicy: PROFILE_SEARCH_V3_GRAPH_RANK_POLICY,
      exclusionPolicy: PROFILE_SEARCH_V3_GRAPH_EXCLUSION_POLICY,
      recordCount: decisions.size,
      eligibleCount: eligible.size,
      excludedCount: decisions.size - eligible.size,
      reachableCount: report.census.reachableAuthors,
      reachableOvermutedCount: report.census.overmutedAuthors,
      distanceExcludedCount: report.census.eligibleAuthors - eligible.size,
      unreachableCount: decisions.size - report.census.reachableAuthors,
      allGraphOvermutedCount: census.overmutedPubkeys.size,
      rankDecisionsSha256,
      rankDecisionsFileSha256: sha256(rankDecisionsText),
    },
  };
}

function encodeRankDecisions(
  decisions: ProfileSearchV3RankDecisions,
  rankDecisionsSha256: string,
): string {
  const records = [...decisions].sort(([left], [right]) => compareText(left, right));
  return `${[
    JSON.stringify({
      format: PROFILE_SEARCH_V3_RANK_DECISION_FORMAT,
      eligibleRanksSha256: rankDecisionsSha256,
      recordCount: records.length,
    }),
    ...records.map(([pubkey, rankHint]) => JSON.stringify({
      pubkey,
      decision: rankHint === null ? 'excluded' : 'eligible',
      rankHint,
    })),
  ].join('\n')}\n`;
}

function sha256(value: string | Uint8Array): string {
  return createHash('sha256').update(value).digest('hex');
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
