import {
  HashTree,
  LinkType,
  sha256,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';
import {
  branchEntry,
  branchManifest,
  checkedRankHint,
  encodeManifest,
  encodeStoredProfile,
  normalizePosting,
  positiveInteger,
  profileSearchV3PostingKey,
  safeAdd,
  validateEligibleRanks,
  validateSignedProfileEvent,
} from './profileSearchV3RoutedRunCodec';
import {
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
  PROFILE_SEARCH_V3_NORMALIZATION,
  PROFILE_SEARCH_V3_RANK_POLICY,
  PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
  type ProfileSearchV3Posting,
  type ProfileSearchV3RoutedRunBuild,
  type ProfileSearchV3RoutedRunManifest,
  type ProfileSearchV3RoutedRunWriter,
} from './profileSearchV3RoutedRunTypes';
import {
  createPostSearchV5PackedBranchWriter,
  type PostSearchV5PackedBranchWriter,
} from './postSearchV5PackedBranch';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';

export {
  PROFILE_SEARCH_V3_MAX_POSTINGS_PER_PROFILE,
  PROFILE_SEARCH_V3_MAX_QUERY_CANDIDATES,
  PROFILE_SEARCH_V3_MAX_QUERY_RESULTS,
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
  PROFILE_SEARCH_V3_NORMALIZATION,
  PROFILE_SEARCH_V3_RANK_POLICY,
  PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
  type ProfileSearchV3BranchManifest,
  type ProfileSearchV3Hit,
  type ProfileSearchV3Posting,
  type ProfileSearchV3PostingMode,
  type ProfileSearchV3RoutedRunBuild,
  type ProfileSearchV3RoutedRunExpected,
  type ProfileSearchV3RoutedRunLookup,
  type ProfileSearchV3RoutedRunManifest,
  type ProfileSearchV3RoutedRunReadOptions,
  type ProfileSearchV3RoutedRunWriter,
  type ProfileSearchV3StoredProfile,
} from './profileSearchV3RoutedRunTypes';
export {
  profileSearchV3PostingKey,
  profileSearchV3PostingsForEvent,
} from './profileSearchV3RoutedRunCodec';
export {
  openProfileSearchV3RoutedRun,
  readProfileSearchV3RoutedRun,
} from './profileSearchV3RoutedRunReader';

const MANIFEST_ENTRY = 'manifest.json';
const PROFILE_ENTRY = 'profiles';
const POSTING_ENTRY = 'postings';

type WriterStatus = 'idle' | 'appending' | 'finishing' | 'finished' | 'failed';

class BoundedProfileRunWriter implements ProfileSearchV3RoutedRunWriter {
  private readonly profiles: PostSearchV5PackedBranchWriter;
  private readonly postings: PostSearchV5PackedBranchWriter;
  private profileCount = 0;
  private postingCount = 0;
  private minimumRankHint = Number.MAX_SAFE_INTEGER;
  private maximumRankHint = 0;
  private postingsStarted = false;
  private status: WriterStatus = 'idle';

  constructor(
    private readonly store: Store,
    private readonly eligibleRanks: ReadonlyMap<string, number>,
  ) {
    validateEligibleRanks(eligibleRanks);
    this.profiles = createPostSearchV5PackedBranchWriter(store, 'documents');
    this.postings = createPostSearchV5PackedBranchWriter(store, 'postings');
  }

  appendProfile(event: RawEvent): Promise<boolean> {
    return this.performAppend(async () => {
      if (this.postingsStarted) {
        throw new Error('Profile-search v3 profiles must precede postings');
      }
      const normalized = validateSignedProfileEvent(event);
      const rankHint = this.eligibleRanks.get(normalized.event.pubkey);
      if (rankHint === undefined) {
        return false;
      }
      checkedRankHint(rankHint);
      await this.profiles.append(
        normalized.event.pubkey,
        encodeStoredProfile(normalized.event, rankHint),
      );
      this.profileCount = safeAdd(this.profileCount, 1, 'profile count');
      this.minimumRankHint = Math.min(this.minimumRankHint, rankHint);
      this.maximumRankHint = Math.max(this.maximumRankHint, rankHint);
      return true;
    });
  }

  appendPosting(raw: ProfileSearchV3Posting): Promise<void> {
    return this.performAppend(async () => {
      if (this.profileCount === 0) {
        throw new Error('Profile-search v3 requires profiles before postings');
      }
      this.postingsStarted = true;
      const posting = normalizePosting(raw);
      const eligibleRank = this.eligibleRanks.get(posting.pubkey);
      if (eligibleRank === undefined || eligibleRank !== posting.rankHint) {
        throw new Error('Profile-search v3 posting author is not eligible at its declared rank');
      }
      await this.postings.append(profileSearchV3PostingKey(posting), '');
      this.postingCount = safeAdd(this.postingCount, 1, 'posting count');
    });
  }

  finish(options: { maxReachableNodeCount?: number } = {}): Promise<ProfileSearchV3RoutedRunBuild> {
    const stateError = this.operationError('finish');
    if (stateError) {return Promise.reject(stateError);}
    this.status = 'finishing';
    return this.finishOnce(options).then(
      (result) => {
        this.status = 'finished';
        return result;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private async finishOnce(
    options: { maxReachableNodeCount?: number },
  ): Promise<ProfileSearchV3RoutedRunBuild> {
    if (this.profileCount === 0 || this.postingCount === 0) {
      throw new Error('Profile-search v3 run requires at least one profile and posting');
    }
    const [profiles, postings] = await Promise.all([
      this.profiles.finish(),
      this.postings.finish(),
    ]);
    if (!profiles || !postings) {
      throw new Error('Profile-search v3 run branches are missing');
    }
    const branches = {
      profiles: branchManifest(profiles),
      postings: branchManifest(postings),
    };
    const reachableNodeCount = safeAdd(
      2,
      safeAdd(profiles.reachableNodeCount, postings.reachableNodeCount, 'branch reachability'),
      'run reachability',
    );
    const maximum = options.maxReachableNodeCount === undefined
      ? PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
      : positiveInteger(options.maxReachableNodeCount, 'maxReachableNodeCount');
    if (reachableNodeCount > maximum || reachableNodeCount > PROFILE_SEARCH_V3_MAX_REACHABLE_NODES) {
      throw new Error('Profile-search v3 run exceeds its reachable-node capacity');
    }
    const manifest: ProfileSearchV3RoutedRunManifest = {
      format: PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
      normalization: PROFILE_SEARCH_V3_NORMALIZATION,
      rankPolicy: PROFILE_SEARCH_V3_RANK_POLICY,
      profileCount: this.profileCount,
      postingCount: this.postingCount,
      minimumRankHint: this.minimumRankHint,
      maximumRankHint: this.maximumRankHint,
      branches,
      reachableNodeCount,
    };
    const manifestBytes = encodeManifest(manifest);
    const manifestHash = await sha256(manifestBytes);
    await this.store.put(manifestHash, manifestBytes);
    const tree = new HashTree({ store: this.store });
    const entries: TreeEntry[] = [
      branchEntry(PROFILE_ENTRY, profiles),
      { name: MANIFEST_ENTRY, cid: { hash: manifestHash }, size: manifestBytes.length,
        type: LinkType.Blob },
      branchEntry(POSTING_ENTRY, postings),
    ];
    const root = (await tree.putDirectory(entries, { unencrypted: true })).cid;
    return { root, manifest };
  }

  private performAppend<T>(operation: () => Promise<T>): Promise<T> {
    const stateError = this.operationError('append');
    if (stateError) {return Promise.reject(stateError);}
    this.status = 'appending';
    return operation().then(
      (result) => {
        this.status = 'idle';
        return result;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private operationError(operation: 'append' | 'finish'): Error | null {
    if (this.status === 'failed') {return new Error('Profile-search v3 writer has failed');}
    if (this.status === 'finished' || this.status === 'finishing') {
      return operation === 'finish'
        ? new Error('Profile-search v3 writer finish may only be called once')
        : new Error('Profile-search v3 writer cannot append after finish');
    }
    if (this.status !== 'idle') {
      return new Error(`Profile-search v3 writer cannot ${operation} concurrently`);
    }
    return null;
  }
}

export function createProfileSearchV3RoutedRunWriter(
  store: Store,
  eligibleRanks: ReadonlyMap<string, number>,
): ProfileSearchV3RoutedRunWriter {
  return new BoundedProfileRunWriter(store, eligibleRanks);
}
