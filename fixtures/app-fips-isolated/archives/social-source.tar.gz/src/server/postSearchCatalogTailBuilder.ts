import { nhashDecode, nhashEncode, type CID } from '@hashtree/core';
import { NostrEventStore } from '@hashtree/nostr';
import type { RawEvent } from '../lib/nostr';
import {
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_DOCUMENT_FORMAT,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
  PostSearchCatalogCapacityError,
  buildPostSearchSegment,
  extendPostSearchCatalog,
  readPostSearchCatalog,
} from '../lib/postSearch';
import {
  deserializePostSearchSegment,
  serializePostSearchSegment,
} from './postSearchBuilderSegments';
import {
  POST_SEARCH_AUTHOR_DELETION_POLICY,
  POST_SEARCH_AUTHOR_METADATA_MAX_BYTES,
  POST_SEARCH_AUTHOR_TERM_MAX_BYTES,
  POST_SEARCH_AUTHOR_TERMS_MAX_BYTES,
  PostSearchAuthorTermsResolver,
} from './postSearchAuthorTerms';
import {
  POST_SEARCH_POINTER_HANDOFF_FORMAT,
  createPostSearchPointerTemplate,
  validateSignedPostSearchPointer,
  type PostSearchPointerHandoff,
} from './postSearchPointer';
import {
  createPostSearchKindReport,
  scanPostSearchDeletions,
  verifyPostSearchEvent,
  visiblePostSearchEvent,
  type PostSearchEventVerifier,
} from './postSearchProjection';
import {
  POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
  isPostSearchTailBuilderState,
  type PostSearchTailBuilderState,
} from './postSearchTailBuilderState';
import {
  abortableNonDeletingStore,
  compareSearchDocuments,
  encodedEventBytes,
  isTailEventEnvelope,
  nonNegativeInteger,
  positiveInteger,
  safeAdd,
  throwIfAborted,
  validateTailPublisherId,
  validateTailTreeName,
} from './postSearchTailBuilderHelpers';
import type {
  PostSearchCatalogTailBuilderOptions,
  PostSearchCatalogTailBuildResult,
  PostSearchTailProgress,
} from './postSearchTailBuilderTypes';
export {
  POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
  isPostSearchTailBuilderState,
} from './postSearchTailBuilderState';
export type {
  PostSearchTailBuilderState,
  PostSearchTailBuilderStateStore,
} from './postSearchTailBuilderState';
export type {
  PostSearchCatalogTailBuilderOptions,
  PostSearchCatalogTailBuildResult,
  PostSearchTailProgress,
} from './postSearchTailBuilderTypes';

const DEFAULT_MAX_TAIL_EVENTS = 10_000;
const DEFAULT_MAX_TAIL_BYTES = 64 * 1024 * 1024;
const DEFAULT_MAX_EVENT_BYTES = 1024 * 1024;
const DEFAULT_MAX_DELETION_EVENTS = 250_000;
const DEFAULT_SEGMENT_MAX_DOCUMENTS = 5_000;
const DEFAULT_SEGMENT_MAX_BYTES = 32 * 1024 * 1024;
const SEARCHABLE_APPEND_KINDS = new Set([1, 20, 1_111]);
const ADDRESSABLE_SEARCH_KIND = 30_023;
const EVENT_DELETION_KIND = 5;
const PROFILE_KIND = 0;
const HEX_64 = /^[0-9a-f]{64}$/;

export class PostSearchFullRebuildRequiredError extends Error {
  readonly code = 'POST_SEARCH_FULL_REBUILD_REQUIRED';

  constructor(message: string) {
    super(message);
    this.name = 'PostSearchFullRebuildRequiredError';
  }
}

/**
 * Append-only v4 catalog updater.
 *
 * It first replays the exact accepted archive batch and requires the resulting
 * immutable root to equal targetSnapshotRoot. Mutations that could make a base
 * segment stale fail closed with PostSearchFullRebuildRequiredError, allowing
 * the caller to schedule the compatible full snapshot builder instead.
 */
export class PostSearchCatalogTailBuilder {
  private readonly options: PostSearchCatalogTailBuilderOptions & {
    maxTailEvents: number;
    maxTailBytes: number;
    maxEventBytes: number;
    maxDeletionEvents: number;
    segmentMaxDocuments: number;
    segmentMaxBytes: number;
    now: () => number;
    verifyEvent: PostSearchEventVerifier;
  };
  private readonly baseCatalogRoot: string;
  private readonly targetEventRoot: string;

  constructor(options: PostSearchCatalogTailBuilderOptions) {
    validateTailPublisherId(options.publisherId);
    validateTailTreeName(options.treeName);
    this.options = {
      ...options,
      maxTailEvents: positiveInteger(options.maxTailEvents ?? DEFAULT_MAX_TAIL_EVENTS, 'maxTailEvents'),
      maxTailBytes: positiveInteger(options.maxTailBytes ?? DEFAULT_MAX_TAIL_BYTES, 'maxTailBytes'),
      maxEventBytes: positiveInteger(options.maxEventBytes ?? DEFAULT_MAX_EVENT_BYTES, 'maxEventBytes'),
      maxDeletionEvents: positiveInteger(
        options.maxDeletionEvents ?? DEFAULT_MAX_DELETION_EVENTS,
        'maxDeletionEvents',
      ),
      segmentMaxDocuments: positiveInteger(
        options.segmentMaxDocuments ?? DEFAULT_SEGMENT_MAX_DOCUMENTS,
        'segmentMaxDocuments',
      ),
      segmentMaxBytes: positiveInteger(
        options.segmentMaxBytes ?? DEFAULT_SEGMENT_MAX_BYTES,
        'segmentMaxBytes',
      ),
      now: options.now ?? (() => Math.floor(Date.now() / 1_000)),
      verifyEvent: options.verifyEvent ?? verifyPostSearchEvent,
    };
    this.baseCatalogRoot = nhashEncode(options.baseCatalogRoot);
    this.targetEventRoot = nhashEncode(options.targetSnapshotRoot);
  }

  async build(): Promise<PostSearchCatalogTailBuildResult> {
    throwIfAborted(this.options.signal);
    const baseCatalog = await readPostSearchCatalog(
      this.options.outputStore,
      this.options.baseCatalogRoot,
      this.options.signal,
    );
    if (baseCatalog.manifest.publisherId !== this.options.publisherId) {
      throw new Error('Tail builder publisher does not match the base catalog');
    }
    if (baseCatalog.manifest.format !== POST_SEARCH_CATALOG_FORMAT) {
      throw new Error('Tail builder requires an authenticated v4 base catalog');
    }
    const baseEventRoot = baseCatalog.manifest.source.eventRoot;
    await this.options.snapshotReader.validateSnapshot?.(nhashDecode(baseEventRoot));
    await this.options.snapshotReader.validateSnapshot?.(this.options.targetSnapshotRoot);

    const prepared = await this.prepareTail(nhashDecode(baseEventRoot));
    this.assertImmediateTailSafety(prepared.events);
    const configurationKey = this.configurationKey(baseEventRoot);
    const loaded = await this.options.stateStore.load();
    const reusable = Boolean(
      loaded
      && this.isReusableState(
        loaded,
        baseEventRoot,
        baseCatalog.manifest.generatedAt,
        configurationKey,
        prepared,
      )
      && await this.hasPersistedRoots(loaded),
    );
    const state = reusable
      ? loaded as PostSearchTailBuilderState
      : this.initialState(
          baseEventRoot,
          baseCatalog.manifest.generatedAt,
          configurationKey,
          prepared,
        );

    if (state.status === 'complete' && state.catalogRoot && state.handoff) {
      this.validateCompletedHandoff(state);
      if (state.handoff.status === 'unsigned-handoff' && this.options.signer) {
        state.handoff = await this.createHandoff(
          nhashDecode(state.catalogRoot),
          state.generatedAt,
        );
        this.validateCompletedHandoff(state);
        await this.options.stateStore.save(state);
      }
      return {
        catalogRoot: nhashDecode(state.catalogRoot),
        handoff: state.handoff,
        state,
        resumed: true,
      };
    }

    this.progress('scanning-deletions', prepared.events.length, 0, state.processedDocuments);
    let deletionEvents = 0;
    const deletions = await scanPostSearchDeletions(
      this.options.snapshotReader,
      this.options.targetSnapshotRoot,
      this.options.verifyEvent,
      () => {
        deletionEvents += 1;
        throwIfAborted(this.options.signal);
        if (deletionEvents > this.options.maxDeletionEvents) {
          throw new Error('Tail builder deletion scan exceeds maxDeletionEvents');
        }
      },
    );
    const documents = await this.selectAppendOnlyDocuments(
      prepared.events,
      deletions,
      nhashDecode(baseEventRoot),
    );
    if (state.processedDocuments > documents.length) {
      throw new Error('Persisted tail progress exceeds the exact searchable batch');
    }
    const persistedCount = state.appendedSegments.reduce(
      (sum, segment) => safeAdd(sum, segment.documentCount, 'persisted tail documents'),
      0,
    );
    if (persistedCount !== state.processedDocuments) {
      throw new Error('Persisted tail segments do not match their document cursor');
    }

    const authorTerms = new PostSearchAuthorTermsResolver({
      snapshotRoot: this.options.targetSnapshotRoot,
      snapshotReader: this.options.snapshotReader,
      verifyEvent: this.options.verifyEvent,
    });
    let cursor = state.processedDocuments;
    while (cursor < documents.length) {
      throwIfAborted(this.options.signal);
      const kind = documents[cursor].kind;
      const batch: RawEvent[] = [];
      let batchBytes = 0;
      while (cursor + batch.length < documents.length
        && documents[cursor + batch.length].kind === kind
        && batch.length < this.options.segmentMaxDocuments) {
        const event = documents[cursor + batch.length];
        const bytes = encodedEventBytes(event);
        if (bytes > this.options.segmentMaxBytes) {
          throw new Error(`Tail event ${event.id} exceeds segmentMaxBytes`);
        }
        if (batch.length > 0 && batchBytes + bytes > this.options.segmentMaxBytes) {
          break;
        }
        batch.push(event);
        batchBytes += bytes;
      }
      if (batch.length === 0) {
        throw new Error('Tail event exceeds segmentMaxBytes');
      }
      const names = await authorTerms.resolve(batch, deletions);
      throwIfAborted(this.options.signal);
      const segment = await buildPostSearchSegment(this.options.outputStore, batch, {
        authorNames: names,
      });
      state.appendedSegments.push(serializePostSearchSegment(segment));
      state.processedDocuments = safeAdd(
        state.processedDocuments,
        batch.length,
        'tail processed documents',
      );
      cursor += batch.length;
      await this.options.stateStore.save(state);
      this.progress(
        'building-segments',
        prepared.events.length,
        documents.length,
        state.processedDocuments,
      );
    }

    throwIfAborted(this.options.signal);
    this.progress(
      'writing-catalog',
      prepared.events.length,
      documents.length,
      state.processedDocuments,
    );
    let catalogRoot: CID;
    try {
      catalogRoot = await extendPostSearchCatalog(this.options.outputStore, {
        base: baseCatalog,
        publisherId: this.options.publisherId,
        generatedAt: state.generatedAt,
        eventRoot: this.targetEventRoot,
        appendedSegments: state.appendedSegments.map(deserializePostSearchSegment),
        signal: this.options.signal,
      });
    } catch (error) {
      if (error instanceof PostSearchCatalogCapacityError) {
        throw new PostSearchFullRebuildRequiredError(
          'Post search catalog segment or manifest capacity requires compaction',
        );
      }
      throw error;
    }
    const handoff = await this.createHandoff(catalogRoot, state.generatedAt);
    state.status = 'complete';
    state.catalogRoot = nhashEncode(catalogRoot);
    state.handoff = handoff;
    this.validateCompletedHandoff(state);
    await this.options.stateStore.save(state);
    this.progress('complete', prepared.events.length, documents.length, state.processedDocuments);
    return { catalogRoot, handoff, state, resumed: reusable };
  }

  private async prepareTail(baseEventRoot: CID): Promise<{ events: RawEvent[]; bytes: number }> {
    this.progress('validating-tail', this.options.tailEvents.length, 0, 0);
    if (this.options.tailEvents.length > this.options.maxTailEvents) {
      throw new Error('Tail event batch exceeds maxTailEvents');
    }
    const seen = new Set<string>();
    let bytes = 0;
    const events = this.options.tailEvents.map((event) => {
      throwIfAborted(this.options.signal);
      if (!isTailEventEnvelope(event)) {
        throw new Error('Tail event has an invalid Nostr envelope');
      }
      const eventBytes = encodedEventBytes(event);
      if (eventBytes > this.options.maxEventBytes) {
        throw new Error(`Tail event ${event.id} exceeds maxEventBytes`);
      }
      bytes = safeAdd(bytes, eventBytes, 'tail event bytes');
      if (bytes > this.options.maxTailBytes) {
        throw new Error('Tail event batch exceeds maxTailBytes');
      }
      if (!HEX_64.test(event.id) || seen.has(event.id)) {
        throw new Error('Tail event ids must be unique lowercase hex');
      }
      if (!this.options.verifyEvent(event)) {
        throw new Error(`Tail event signature verification failed: ${event.id}`);
      }
      seen.add(event.id);
      return structuredClone(event);
    });

    const replayStore = abortableNonDeletingStore(this.options.outputStore, this.options.signal);
    const replayed = await new NostrEventStore(replayStore).build(baseEventRoot, events);
    throwIfAborted(this.options.signal);
    if (!replayed || nhashEncode(replayed) !== this.targetEventRoot) {
      throw new Error('Tail events do not exactly derive targetSnapshotRoot from the base snapshot');
    }
    return { events, bytes };
  }

  private async selectAppendOnlyDocuments(
    events: readonly RawEvent[],
    deletions: Awaited<ReturnType<typeof scanPostSearchDeletions>>,
    baseEventRoot: CID,
  ): Promise<RawEvent[]> {
    const candidates: RawEvent[] = [];
    const addressableCoordinates = new Set<string>();
    for (const event of events) {
      throwIfAborted(this.options.signal);
      if (event.kind === ADDRESSABLE_SEARCH_KIND) {
        const dTag = event.tags.find((tag) => tag[0] === 'd')?.[1] ?? '';
        const coordinate = `${event.pubkey}:${dTag}`;
        if (!dTag || addressableCoordinates.has(coordinate)
          || !this.options.snapshotReader.getParameterizedReplaceable) {
          throw new PostSearchFullRebuildRequiredError(
            'Addressable tail cannot prove an append-only winner',
          );
        }
        addressableCoordinates.add(coordinate);
        const existing = await this.options.snapshotReader.getParameterizedReplaceable(
          baseEventRoot,
          event.pubkey,
          event.kind,
          dTag,
        );
        const winner = await this.options.snapshotReader.getParameterizedReplaceable(
          this.options.targetSnapshotRoot,
          event.pubkey,
          event.kind,
          dTag,
        );
        if (existing || winner?.id !== event.id) {
          throw new PostSearchFullRebuildRequiredError(
            'Addressable tail supersedes an existing or same-batch coordinate',
          );
        }
        candidates.push(event);
      } else if (SEARCHABLE_APPEND_KINDS.has(event.kind)) {
        candidates.push(event);
      }
    }
    const report = createPostSearchKindReport();
    return candidates
      .filter((event) => visiblePostSearchEvent(
        event,
        deletions,
        report,
        this.options.verifyEvent,
      ))
      .sort(compareSearchDocuments);
  }

  private assertImmediateTailSafety(events: readonly RawEvent[]): void {
    if (events.some((event) => event.kind === EVENT_DELETION_KIND)) {
      throw new PostSearchFullRebuildRequiredError(
        'A new deletion can invalidate immutable base segments',
      );
    }
    if (events.some((event) => event.kind === PROFILE_KIND)) {
      throw new PostSearchFullRebuildRequiredError(
        'A profile change requires reprojecting base author terms',
      );
    }
  }

  private configurationKey(baseEventRoot: string): string {
    return JSON.stringify({
      format: POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
      catalogFormat: POST_SEARCH_CATALOG_FORMAT,
      documentFormat: POST_SEARCH_DOCUMENT_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
      visibleProjection: POST_SEARCH_VISIBLE_PROJECTION,
      authorTermsProjection: POST_SEARCH_AUTHOR_TERMS_PROJECTION,
      buildOptions: POST_SEARCH_BUILD_OPTIONS,
      authorMetadataMaxBytes: POST_SEARCH_AUTHOR_METADATA_MAX_BYTES,
      authorTermMaxBytes: POST_SEARCH_AUTHOR_TERM_MAX_BYTES,
      authorTermsMaxBytes: POST_SEARCH_AUTHOR_TERMS_MAX_BYTES,
      authorDeletionPolicy: POST_SEARCH_AUTHOR_DELETION_POLICY,
      baseEventRoot,
      maxTailEvents: this.options.maxTailEvents,
      maxTailBytes: this.options.maxTailBytes,
      maxEventBytes: this.options.maxEventBytes,
      maxDeletionEvents: this.options.maxDeletionEvents,
      segmentMaxDocuments: this.options.segmentMaxDocuments,
      segmentMaxBytes: this.options.segmentMaxBytes,
    });
  }

  private initialState(
    baseEventRoot: string,
    baseGeneratedAt: number,
    configurationKey: string,
    prepared: { events: readonly RawEvent[]; bytes: number },
  ): PostSearchTailBuilderState {
    return {
      format: POST_SEARCH_TAIL_BUILDER_STATE_FORMAT,
      status: 'building',
      baseCatalogRoot: this.baseCatalogRoot,
      baseEventRoot,
      targetEventRoot: this.targetEventRoot,
      publisherId: this.options.publisherId,
      treeName: this.options.treeName,
      configurationKey,
      generatedAt: Math.max(
        nonNegativeInteger(this.options.now(), 'generatedAt'),
        safeAdd(baseGeneratedAt, 1, 'tail generatedAt'),
      ),
      tailEventCount: prepared.events.length,
      tailBytes: prepared.bytes,
      processedDocuments: 0,
      appendedSegments: [],
      catalogRoot: null,
      handoff: null,
    };
  }

  private isReusableState(
    state: PostSearchTailBuilderState,
    baseEventRoot: string,
    baseGeneratedAt: number,
    configurationKey: string,
    prepared: { events: readonly RawEvent[]; bytes: number },
  ): boolean {
    return isPostSearchTailBuilderState(state)
      && state.baseCatalogRoot === this.baseCatalogRoot
      && state.baseEventRoot === baseEventRoot
      && state.targetEventRoot === this.targetEventRoot
      && state.publisherId === this.options.publisherId
      && state.treeName === this.options.treeName
      && state.configurationKey === configurationKey
      && state.generatedAt > baseGeneratedAt
      && state.tailEventCount === prepared.events.length
      && state.tailBytes === prepared.bytes;
  }

  private async hasPersistedRoots(state: PostSearchTailBuilderState): Promise<boolean> {
    const roots = state.appendedSegments.flatMap((segment) => [
      nhashDecode(segment.root),
      ...(segment.routingRoot ? [nhashDecode(segment.routingRoot)] : []),
    ]);
    if (state.catalogRoot) {
      roots.push(nhashDecode(state.catalogRoot));
    }
    for (const root of roots) {
      throwIfAborted(this.options.signal);
      if (!await this.options.outputStore.has(root.hash)) {
        return false;
      }
    }
    return true;
  }

  private async createHandoff(catalogRoot: CID, createdAt: number): Promise<PostSearchPointerHandoff> {
    const unsignedEvent = createPostSearchPointerTemplate({
      catalogRoot,
      sourceEventRoot: this.targetEventRoot,
      treeName: this.options.treeName,
      createdAt,
    });
    const signedEvent = this.options.signer
      ? await this.options.signer.sign(structuredClone(unsignedEvent))
      : null;
    if (signedEvent) {
      validateSignedPostSearchPointer(
        signedEvent,
        this.options.publisherId,
        this.options.treeName,
        catalogRoot,
        unsignedEvent,
      );
    }
    return {
      format: POST_SEARCH_POINTER_HANDOFF_FORMAT,
      status: signedEvent ? 'signed-handoff' : 'unsigned-handoff',
      publisherId: this.options.publisherId,
      catalogRoot: nhashEncode(catalogRoot),
      sourceEventRoot: this.targetEventRoot,
      treeName: this.options.treeName,
      unsignedEvent,
      signedEvent,
      publication: {
        required: true,
        transport: 'nostr-replaceable-event',
        blockAvailability: 'required-before-event',
      },
    };
  }

  private validateCompletedHandoff(state: PostSearchTailBuilderState): void {
    if (!state.catalogRoot || !state.handoff
      || state.handoff.format !== POST_SEARCH_POINTER_HANDOFF_FORMAT
      || state.handoff.publisherId !== this.options.publisherId
      || state.handoff.catalogRoot !== state.catalogRoot
      || state.handoff.sourceEventRoot !== this.targetEventRoot
      || state.handoff.treeName !== this.options.treeName
      || (state.handoff.status === 'signed-handoff') !== Boolean(state.handoff.signedEvent)
      || state.handoff.publication?.required !== true
      || state.handoff.publication?.transport !== 'nostr-replaceable-event'
      || state.handoff.publication?.blockAvailability !== 'required-before-event') {
      throw new Error('Persisted tail handoff does not match its completed state');
    }
    const expected = createPostSearchPointerTemplate({
      catalogRoot: nhashDecode(state.catalogRoot),
      sourceEventRoot: this.targetEventRoot,
      treeName: this.options.treeName,
      createdAt: state.generatedAt,
    });
    if (JSON.stringify(state.handoff.unsignedEvent) !== JSON.stringify(expected)) {
      throw new Error('Persisted tail handoff unsigned event is inconsistent');
    }
    if (state.handoff.signedEvent) {
      validateSignedPostSearchPointer(
        state.handoff.signedEvent,
        this.options.publisherId,
        this.options.treeName,
        nhashDecode(state.catalogRoot),
        state.handoff.unsignedEvent,
      );
    }
  }

  private progress(
    phase: PostSearchTailProgress['phase'],
    tailEvents: number,
    searchableDocuments: number,
    persistedDocuments: number,
  ): void {
    this.options.onProgress?.({ phase, tailEvents, searchableDocuments, persistedDocuments });
  }
}
