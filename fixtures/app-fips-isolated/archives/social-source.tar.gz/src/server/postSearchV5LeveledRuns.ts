import { nhashDecode, nhashEncode } from '@hashtree/core';

export const POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT =
  'iris-social/post-search-v5-leveled-runs@1' as const;

export interface PostSearchV5LeveledRun {
  id: string;
  level: number;
  oldestBatch: number;
  newestBatchExclusive: number;
  root: string;
  documentCount: number;
  compactedFromRoots: [string, string] | null;
}

export interface PostSearchV5CompactionTask {
  id: string;
  outputLevel: number;
  oldestBatch: number;
  newestBatchExclusive: number;
  inputRunIds: [string, string];
  inputRoots: [string, string];
  documentCount: number;
}

export interface PostSearchV5LeveledRunState {
  format: typeof POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT;
  batchSize: number;
  nextBatch: number;
  runs: PostSearchV5LeveledRun[];
  tasks: PostSearchV5CompactionTask[];
}

export interface PostSearchV5BatchRunInput {
  batch: number;
  root: string;
  documentCount: number;
}

export interface PostSearchV5CompactionCompletion {
  task: PostSearchV5CompactionTask;
  outputRoot: string;
}

export interface PostSearchV5CompactionTransition {
  state: PostSearchV5LeveledRunState;
  replayed: boolean;
}

export interface PostSearchV5RunCatalog {
  batchSize: number;
  batchCount: number;
  documentCount: number;
  /** Query order. A newer ingestion range always precedes an older one. */
  runsNewestFirst: PostSearchV5LeveledRun[];
}

export interface PostSearchV5PublicationPlan {
  /** False means finish a level-0 carry before admitting another source batch. */
  canAppendBatch: boolean;
  /** Every active level has at most the two immutable inputs of one carry. */
  publishable: boolean;
  /** Tasks whose output will not create a third run at its destination level. */
  runnableTasks: PostSearchV5CompactionTask[];
}

export const POST_SEARCH_V5_MAX_PUBLISHED_RUNS_PER_LEVEL = 2;

const STATE_KEYS = ['batchSize', 'format', 'nextBatch', 'runs', 'tasks'] as const;
const RUN_KEYS = [
  'compactedFromRoots',
  'documentCount',
  'id',
  'level',
  'newestBatchExclusive',
  'oldestBatch',
  'root',
] as const;
const TASK_KEYS = [
  'documentCount',
  'id',
  'inputRoots',
  'inputRunIds',
  'newestBatchExclusive',
  'oldestBatch',
  'outputLevel',
] as const;

export function createPostSearchV5LeveledRunState(
  batchSize = 5_000,
): PostSearchV5LeveledRunState {
  positiveSafeInteger(batchSize, 'batchSize');
  return {
    format: POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT,
    batchSize,
    nextBatch: 0,
    runs: [],
    tasks: [],
  };
}

/** Add exactly the next durable source batch and expose every independent carry task. */
export function appendPostSearchV5BatchRun(
  rawState: unknown,
  input: PostSearchV5BatchRunInput,
): PostSearchV5LeveledRunState {
  const state = parsePostSearchV5LeveledRunState(rawState);
  if (!isObject(input) || !hasExactKeys(input, ['batch', 'documentCount', 'root'])) {
    throw new Error('Invalid post search v5 batch run input');
  }
  nonNegativeSafeInteger(input.batch, 'batch');
  positiveSafeInteger(input.documentCount, 'documentCount');
  if (input.batch !== state.nextBatch) {
    throw new Error(`Expected post search v5 batch ${state.nextBatch}, received ${input.batch}`);
  }
  if (input.documentCount > state.batchSize) {
    throw new Error('Post search v5 batch exceeds the configured batchSize');
  }
  const root = canonicalRoot(input.root, 'batch root');
  const newestBatchExclusive = safeAdd(input.batch, 1, 'next batch');
  const runs = [...state.runs, createRun({
    level: 0,
    oldestBatch: input.batch,
    newestBatchExclusive,
    root,
    documentCount: input.documentCount,
    compactedFromRoots: null,
  })];
  return canonicalState(state.batchSize, newestBatchExclusive, runs);
}

/**
 * Atomically replace the task's two immutable input runs with its output.
 * Replaying the just-persisted completion is idempotent while that output run
 * remains active; any stale or root-mismatched completion fails closed.
 */
export function completePostSearchV5Compaction(
  rawState: unknown,
  completion: PostSearchV5CompactionCompletion,
): PostSearchV5CompactionTransition {
  const state = parsePostSearchV5LeveledRunState(rawState);
  const suppliedTask = parseTask(completion?.task);
  const outputRoot = canonicalRoot(completion?.outputRoot, 'compaction output root');
  const task = state.tasks.find((candidate) => candidate.id === suppliedTask.id);
  if (!task) {
    const existing = state.runs.find((run) => run.id === runId(
      suppliedTask.outputLevel,
      suppliedTask.oldestBatch,
      suppliedTask.newestBatchExclusive,
    ));
    if (existing
      && sameTask(suppliedTask, taskForCompletedRun(suppliedTask, existing))
      && existing.root === outputRoot
      && existing.documentCount === suppliedTask.documentCount
      && sameStringPair(existing.compactedFromRoots, suppliedTask.inputRoots)) {
      return { state, replayed: true };
    }
    throw new Error(`Unknown or stale post search v5 compaction task ${suppliedTask.id}`);
  }
  if (!sameTask(task, suppliedTask)) {
    throw new Error(`Post search v5 compaction task ${task.id} input binding changed`);
  }

  const inputIds = new Set(task.inputRunIds);
  const inputs = state.runs.filter((run) => inputIds.has(run.id));
  if (inputs.length !== 2
    || inputs[0].root !== task.inputRoots[0]
    || inputs[1].root !== task.inputRoots[1]) {
    throw new Error(`Post search v5 compaction task ${task.id} inputs are unavailable`);
  }
  const output = createRun({
    level: task.outputLevel,
    oldestBatch: task.oldestBatch,
    newestBatchExclusive: task.newestBatchExclusive,
    root: outputRoot,
    documentCount: task.documentCount,
    compactedFromRoots: [...task.inputRoots],
  });
  const runs = state.runs.filter((run) => !inputIds.has(run.id));
  runs.push(output);
  runs.sort(compareRuns);
  return {
    state: canonicalState(state.batchSize, state.nextBatch, runs),
    replayed: false,
  };
}

/** Validate and clone a persisted state, rejecting non-canonical ordering or metadata. */
export function parsePostSearchV5LeveledRunState(
  value: unknown,
): PostSearchV5LeveledRunState {
  if (!isObject(value)
    || !hasExactKeys(value, STATE_KEYS)
    || value.format !== POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT) {
    throw new Error('Invalid post search v5 leveled-run state envelope');
  }
  positiveSafeInteger(value.batchSize, 'batchSize');
  nonNegativeSafeInteger(value.nextBatch, 'nextBatch');
  if (!Array.isArray(value.runs) || !Array.isArray(value.tasks)) {
    throw new Error('Invalid post search v5 leveled-run state collections');
  }
  const runs = value.runs.map(parseRun);
  const tasks = value.tasks.map(parseTask);
  assertExactCoverage(runs, value.nextBatch);
  let totalDocuments = 0;
  for (const run of runs) {
    const maximumDocuments = safeMultiply(
      value.batchSize,
      levelSpan(run.level),
      'run document capacity',
    );
    if (run.documentCount > maximumDocuments) {
      throw new Error('Post search v5 run exceeds its configured source batch capacity');
    }
    totalDocuments = safeAdd(totalDocuments, run.documentCount, 'state document count');
  }
  if (!sameRuns(runs, [...runs].sort(compareRuns))) {
    throw new Error('Post search v5 runs are not in canonical oldest-first order');
  }
  const expectedTasks = planTasks(runs);
  if (!sameTasks(tasks, expectedTasks)) {
    throw new Error('Post search v5 compaction tasks are not the canonical active plan');
  }
  return {
    format: POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT,
    batchSize: value.batchSize,
    nextBatch: value.nextBatch,
    runs,
    tasks,
  };
}

export function isPostSearchV5LeveledRunState(
  value: unknown,
): value is PostSearchV5LeveledRunState {
  try {
    parsePostSearchV5LeveledRunState(value);
    return true;
  } catch {
    return false;
  }
}

/** Canonical JSON is useful for atomic restart checkpoints and byte-level identity checks. */
export function encodePostSearchV5LeveledRunState(rawState: unknown): string {
  return JSON.stringify(parsePostSearchV5LeveledRunState(rawState));
}

export function decodePostSearchV5LeveledRunState(serialized: string): PostSearchV5LeveledRunState {
  if (typeof serialized !== 'string') {
    throw new Error('Post search v5 leveled-run state must be serialized JSON');
  }
  let value: unknown;
  try {
    value = JSON.parse(serialized);
  } catch {
    throw new Error('Post search v5 leveled-run state is not valid JSON');
  }
  const state = parsePostSearchV5LeveledRunState(value);
  if (JSON.stringify(state) !== serialized) {
    throw new Error('Post search v5 leveled-run state JSON is not canonical');
  }
  return state;
}

export function postSearchV5RunCatalog(rawState: unknown): PostSearchV5RunCatalog {
  const state = parsePostSearchV5LeveledRunState(rawState);
  const publication = planPostSearchV5Publication(state);
  if (!publication.publishable) {
    throw new Error('Post search v5 active runs exceed the bounded publication layout');
  }
  return {
    batchSize: state.batchSize,
    batchCount: state.nextBatch,
    documentCount: state.runs.reduce(
      (sum, run) => safeAdd(sum, run.documentCount, 'catalog document count'),
      0,
    ),
    runsNewestFirst: [...state.runs].reverse(),
  };
}

/**
 * Apply LSM backpressure without blocking a fresh tail on an unrelated large
 * carry. Two inputs may remain published while their replacement builds.
 */
export function planPostSearchV5Publication(
  rawState: unknown,
): PostSearchV5PublicationPlan {
  const state = parsePostSearchV5LeveledRunState(rawState);
  const counts = new Map<number, number>();
  for (const run of state.runs) {
    counts.set(run.level, (counts.get(run.level) ?? 0) + 1);
  }
  const reservedOutputs = new Map(counts);
  const runnableTasks: PostSearchV5CompactionTask[] = [];
  for (const task of state.tasks) {
    const activeAndReserved = reservedOutputs.get(task.outputLevel) ?? 0;
    if (activeAndReserved >= POST_SEARCH_V5_MAX_PUBLISHED_RUNS_PER_LEVEL) {
      continue;
    }
    runnableTasks.push(task);
    reservedOutputs.set(task.outputLevel, activeAndReserved + 1);
  }
  return {
    canAppendBatch: (counts.get(0) ?? 0) < POST_SEARCH_V5_MAX_PUBLISHED_RUNS_PER_LEVEL,
    publishable: [...counts.values()].every(
      (count) => count <= POST_SEARCH_V5_MAX_PUBLISHED_RUNS_PER_LEVEL,
    ),
    runnableTasks,
  };
}

function canonicalState(
  batchSize: number,
  nextBatch: number,
  runs: PostSearchV5LeveledRun[],
): PostSearchV5LeveledRunState {
  const state: PostSearchV5LeveledRunState = {
    format: POST_SEARCH_V5_LEVELED_RUN_STATE_FORMAT,
    batchSize,
    nextBatch,
    runs: runs.map(cloneRun),
    tasks: planTasks(runs),
  };
  return parsePostSearchV5LeveledRunState(state);
}

function planTasks(runs: readonly PostSearchV5LeveledRun[]): PostSearchV5CompactionTask[] {
  const byStart = new Map(runs.map((run) => [`${run.level}:${run.oldestBatch}`, run]));
  const tasks: PostSearchV5CompactionTask[] = [];
  for (const older of runs) {
    const span = levelSpan(older.level);
    if (older.oldestBatch % (span * 2) !== 0) {
      continue;
    }
    const newer = byStart.get(`${older.level}:${older.newestBatchExclusive}`);
    if (!newer || newer.newestBatchExclusive !== older.oldestBatch + span * 2) {
      continue;
    }
    const documentCount = safeAdd(
      older.documentCount,
      newer.documentCount,
      'compaction document count',
    );
    const outputLevel = older.level + 1;
    tasks.push({
      id: taskId(outputLevel, older.oldestBatch, newer.newestBatchExclusive),
      outputLevel,
      oldestBatch: older.oldestBatch,
      newestBatchExclusive: newer.newestBatchExclusive,
      inputRunIds: [older.id, newer.id],
      inputRoots: [older.root, newer.root],
      documentCount,
    });
  }
  return tasks.sort(compareTasks);
}

function parseRun(value: unknown): PostSearchV5LeveledRun {
  if (!isObject(value) || !hasExactKeys(value, RUN_KEYS)) {
    throw new Error('Invalid post search v5 run');
  }
  nonNegativeSafeInteger(value.level, 'run level');
  nonNegativeSafeInteger(value.oldestBatch, 'run oldestBatch');
  positiveSafeInteger(value.newestBatchExclusive, 'run newestBatchExclusive');
  positiveSafeInteger(value.documentCount, 'run documentCount');
  const span = levelSpan(value.level);
  if (value.oldestBatch % span !== 0
    || value.newestBatchExclusive !== value.oldestBatch + span) {
    throw new Error('Post search v5 run is not an aligned power-of-two source range');
  }
  const expectedId = runId(value.level, value.oldestBatch, value.newestBatchExclusive);
  if (value.id !== expectedId) {
    throw new Error('Post search v5 run id is not canonical');
  }
  if (value.compactedFromRoots !== null && !isStringPair(value.compactedFromRoots)) {
    throw new Error('Invalid post search v5 run compaction provenance');
  }
  if ((value.level === 0) !== (value.compactedFromRoots === null)) {
    throw new Error('Post search v5 run compaction provenance does not match its level');
  }
  return {
    id: expectedId,
    level: value.level,
    oldestBatch: value.oldestBatch,
    newestBatchExclusive: value.newestBatchExclusive,
    root: canonicalRoot(value.root, 'run root'),
    documentCount: value.documentCount,
    compactedFromRoots: value.compactedFromRoots === null
      ? null
      : [
          canonicalRoot(value.compactedFromRoots[0], 'run older provenance root'),
          canonicalRoot(value.compactedFromRoots[1], 'run newer provenance root'),
        ],
  };
}

function parseTask(value: unknown): PostSearchV5CompactionTask {
  if (!isObject(value) || !hasExactKeys(value, TASK_KEYS)) {
    throw new Error('Invalid post search v5 compaction task');
  }
  positiveSafeInteger(value.outputLevel, 'task outputLevel');
  nonNegativeSafeInteger(value.oldestBatch, 'task oldestBatch');
  positiveSafeInteger(value.newestBatchExclusive, 'task newestBatchExclusive');
  positiveSafeInteger(value.documentCount, 'task documentCount');
  if (!isStringPair(value.inputRunIds) || !isStringPair(value.inputRoots)) {
    throw new Error('Invalid post search v5 compaction task inputs');
  }
  const span = levelSpan(value.outputLevel);
  if (value.oldestBatch % span !== 0
    || value.newestBatchExclusive !== value.oldestBatch + span) {
    throw new Error('Post search v5 compaction task range is not canonical');
  }
  const expectedId = taskId(
    value.outputLevel,
    value.oldestBatch,
    value.newestBatchExclusive,
  );
  if (value.id !== expectedId) {
    throw new Error('Post search v5 compaction task id is not canonical');
  }
  const childLevel = value.outputLevel - 1;
  const half = span / 2;
  const expectedInputRunIds = [
    runId(childLevel, value.oldestBatch, value.oldestBatch + half),
    runId(childLevel, value.oldestBatch + half, value.newestBatchExclusive),
  ];
  if (value.inputRunIds[0] !== expectedInputRunIds[0]
    || value.inputRunIds[1] !== expectedInputRunIds[1]) {
    throw new Error('Post search v5 compaction task input ids are not canonical');
  }
  return {
    id: expectedId,
    outputLevel: value.outputLevel,
    oldestBatch: value.oldestBatch,
    newestBatchExclusive: value.newestBatchExclusive,
    inputRunIds: [value.inputRunIds[0], value.inputRunIds[1]],
    inputRoots: [
      canonicalRoot(value.inputRoots[0], 'task older input root'),
      canonicalRoot(value.inputRoots[1], 'task newer input root'),
    ],
    documentCount: value.documentCount,
  };
}

function assertExactCoverage(runs: readonly PostSearchV5LeveledRun[], nextBatch: number): void {
  let cursor = 0;
  for (const run of runs) {
    if (run.oldestBatch !== cursor) {
      throw new Error('Post search v5 run source ranges contain an overlap, gap, or duplicate');
    }
    cursor = run.newestBatchExclusive;
  }
  if (cursor !== nextBatch) {
    throw new Error('Post search v5 runs do not exactly cover all durable source batches');
  }
}

function createRun(input: Omit<PostSearchV5LeveledRun, 'id'>): PostSearchV5LeveledRun {
  return {
    id: runId(input.level, input.oldestBatch, input.newestBatchExclusive),
    ...input,
  };
}

function taskForCompletedRun(
  task: PostSearchV5CompactionTask,
  output: PostSearchV5LeveledRun,
): PostSearchV5CompactionTask {
  return {
    ...task,
    outputLevel: output.level,
    oldestBatch: output.oldestBatch,
    newestBatchExclusive: output.newestBatchExclusive,
    documentCount: output.documentCount,
  };
}

function runId(level: number, oldestBatch: number, newestBatchExclusive: number): string {
  return `run:${level}:${oldestBatch}:${newestBatchExclusive}`;
}

function taskId(level: number, oldestBatch: number, newestBatchExclusive: number): string {
  return `compact:${level}:${oldestBatch}:${newestBatchExclusive}`;
}

function levelSpan(level: number): number {
  const span = 2 ** level;
  if (!Number.isSafeInteger(span)) {
    throw new Error('Post search v5 run level exceeds safe source range capacity');
  }
  return span;
}

function compareRuns(a: PostSearchV5LeveledRun, b: PostSearchV5LeveledRun): number {
  return a.oldestBatch - b.oldestBatch;
}

function compareTasks(a: PostSearchV5CompactionTask, b: PostSearchV5CompactionTask): number {
  return a.oldestBatch - b.oldestBatch || a.outputLevel - b.outputLevel;
}

function sameRuns(
  left: readonly PostSearchV5LeveledRun[],
  right: readonly PostSearchV5LeveledRun[],
): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function sameTask(left: PostSearchV5CompactionTask, right: PostSearchV5CompactionTask): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function sameTasks(
  left: readonly PostSearchV5CompactionTask[],
  right: readonly PostSearchV5CompactionTask[],
): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function cloneRun(run: PostSearchV5LeveledRun): PostSearchV5LeveledRun {
  return { ...run };
}

function canonicalRoot(value: unknown, label: string): string {
  if (typeof value !== 'string') {
    throw new Error(`Invalid post search v5 ${label}`);
  }
  try {
    if (nhashEncode(nhashDecode(value)) !== value) {
      throw new Error('non-canonical');
    }
    return value;
  } catch {
    throw new Error(`Invalid or non-canonical post search v5 ${label}`);
  }
}

function positiveSafeInteger(value: unknown, label: string): asserts value is number {
  if (!Number.isSafeInteger(value) || Number(value) <= 0) {
    throw new Error(`Invalid positive post search v5 ${label}`);
  }
}

function nonNegativeSafeInteger(value: unknown, label: string): asserts value is number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {
    throw new Error(`Invalid non-negative post search v5 ${label}`);
  }
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post search v5 ${label} exceeds safe integer capacity`);
  }
  return result;
}

function safeMultiply(left: number, right: number, label: string): number {
  const result = left * right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post search v5 ${label} exceeds safe integer capacity`);
  }
  return result;
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  const actual = Object.keys(value).sort();
  return actual.length === keys.length && actual.every((key, index) => key === keys[index]);
}

function isStringPair(value: unknown): value is [string, string] {
  return Array.isArray(value)
    && value.length === 2
    && value.every((entry) => typeof entry === 'string');
}

function sameStringPair(
  left: [string, string] | null,
  right: [string, string],
): boolean {
  return left !== null && left[0] === right[0] && left[1] === right[1];
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
