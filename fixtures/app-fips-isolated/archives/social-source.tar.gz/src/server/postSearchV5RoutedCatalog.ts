import { HashTree, LinkType, sha256, type Store, type TreeEntry } from '@hashtree/core';
import {
  POST_SEARCH_NORMALIZATION,
} from '../lib/postSearchCatalogConstants';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import {
  POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
  readPostSearchV5VisibilityOverlay,
} from './postSearchV5OverlayStore';
import {
  POST_SEARCH_V5_ROUTED_RUN_FORMAT,
  openPostSearchV5RoutedRun,
  readPostSearchV5RoutedRun,
  type PostSearchV5RoutedRunLookup,
} from './postSearchV5RoutedRun';
import {
  assertRunDescriptor,
  assertRunLayout,
  assertRunsMatchCatalog,
  capacity,
  capacityLimit,
  encodeManifest,
  overlayExpected,
  readPostSearchV5RoutedCatalogEnvelope,
  runDescriptor,
  runExpected,
  scoringManifest,
  sourceSnapshot,
  verifiedOverlay,
} from './postSearchV5RoutedCatalogCodec';
import {
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS,
  POST_SEARCH_V5_ROUTED_CATALOG_OPEN_CONCURRENCY,
  type PostSearchV5RoutedCatalogBuild,
  type PostSearchV5RoutedCatalogInput,
  type PostSearchV5RoutedCatalogLookup,
  type PostSearchV5RoutedCatalogManifest,
  type PostSearchV5RoutedCatalogRunDescriptor,
} from './postSearchV5RoutedCatalogTypes';
import {
  isPostSearchV5RoutedCatalogRecord,
  mapPostSearchV5RoutedCatalogWithConcurrency,
  postSearchV5RoutedCatalogNonNegativeInteger,
  postSearchV5RoutedCatalogPositiveInteger,
  postSearchV5RoutedCatalogPublisher,
} from './postSearchV5RoutedCatalogValidation';

const MANIFEST_ENTRY = 'manifest.json';

export async function writePostSearchV5RoutedCatalog(
  store: Store,
  input: PostSearchV5RoutedCatalogInput,
): Promise<PostSearchV5RoutedCatalogBuild> {
  if (!isPostSearchV5RoutedCatalogRecord(input)) {
    throw new Error('Invalid post-search v5 routed catalog input');
  }
  const maximum = capacityLimit(input.maxReachableNodeCount);
  const batchSize = postSearchV5RoutedCatalogPositiveInteger(input.batchSize, 'batchSize');
  const rawRuns = [...input.runs].sort((left, right) =>
    left.oldestBatch - right.oldestBatch);
  if (rawRuns.length > POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS) {
    throw new Error('Invalid post-search v5 routed catalog runs');
  }
  const runs: PostSearchV5RoutedCatalogRunDescriptor[] = [];
  const lookups: PostSearchV5RoutedRunLookup[] = [];
  for (let index = 0; index < rawRuns.length; index += 1) {
    const candidate = rawRuns[index]!;
    const descriptor = runDescriptor(candidate, index);
    const verified = await readPostSearchV5RoutedRun(store, candidate.root, {
      expected: runExpected(descriptor),
    });
    assertRunDescriptor(descriptor, verified, index);
    runs.push(descriptor);
    lookups.push(verified);
  }
  assertRunLayout(runs, batchSize);
  const source = sourceSnapshot(input.source, runs);
  const scoring = scoringManifest(lookups);
  const overlay = await verifiedOverlay(store, input.overlay);
  const reachableNodeCount = capacity(runs, overlay, maximum);
  const manifest: PostSearchV5RoutedCatalogManifest = {
    format: POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
    publisherId: postSearchV5RoutedCatalogPublisher(input.publisherId),
    generatedAt: postSearchV5RoutedCatalogNonNegativeInteger(
      input.generatedAt,
      'generatedAt',
    ),
    batchSize,
    source,
    compatibility: {
      runFormat: POST_SEARCH_V5_ROUTED_RUN_FORMAT,
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
      overlayFormat: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
    },
    scoring,
    runs,
    overlay,
    reachableNodeCount,
  };
  const manifestBytes = encodeManifest(manifest);
  const manifestHash = await sha256(manifestBytes);
  await store.put(manifestHash, manifestBytes);
  const entries: TreeEntry[] = [{
    name: MANIFEST_ENTRY,
    cid: { hash: manifestHash },
    size: manifestBytes.length,
    type: LinkType.Blob,
  }, ...runs.map((run, index): TreeEntry => ({
    name: run.entry,
    cid: rawRuns[index]!.root,
    size: run.reachableNodeCount,
    type: LinkType.Dir,
  }))];
  if (overlay && input.overlay) {
    entries.push({
      name: overlay.entry,
      cid: input.overlay.root,
      size: overlay.reachableNodeCount,
      type: LinkType.Dir,
    });
  }
  const root = (await new HashTree({ store }).putDirectory(
    entries,
    { unencrypted: true },
  )).cid;
  return { root, manifest };
}

export async function openPostSearchV5RoutedCatalog(
  store: Store,
  root: import('@hashtree/core').CID,
): Promise<PostSearchV5RoutedCatalogLookup> {
  const envelope = await readPostSearchV5RoutedCatalogEnvelope(store, root);
  const runs = await mapPostSearchV5RoutedCatalogWithConcurrency(
    envelope.runRoots,
    POST_SEARCH_V5_ROUTED_CATALOG_OPEN_CONCURRENCY,
    async (runRoot) => await openPostSearchV5RoutedRun(store, runRoot),
  );
  assertRunsMatchCatalog(envelope.manifest, runs);
  return { ...envelope, runs };
}

/** Full structural verification of every linked run and overlay before publication. */
export async function readPostSearchV5RoutedCatalog(
  store: Store,
  root: import('@hashtree/core').CID,
  options: { maxReachableNodeCount?: number } = {},
): Promise<PostSearchV5RoutedCatalogLookup> {
  const envelope = await readPostSearchV5RoutedCatalogEnvelope(store, root);
  const maximum = capacityLimit(options.maxReachableNodeCount);
  if (envelope.manifest.reachableNodeCount > maximum) {
    throw new Error('Post-search v5 routed catalog exceeds its reachable-node capacity');
  }
  const runs = await mapPostSearchV5RoutedCatalogWithConcurrency(
    envelope.runRoots,
    POST_SEARCH_V5_ROUTED_CATALOG_OPEN_CONCURRENCY,
    async (runRoot, index) => await readPostSearchV5RoutedRun(store, runRoot, {
      expected: runExpected(envelope.manifest.runs[index]!),
    }),
  );
  assertRunsMatchCatalog(envelope.manifest, runs);
  if (envelope.overlayRoot && envelope.manifest.overlay) {
    await readPostSearchV5VisibilityOverlay(
      store,
      envelope.overlayRoot,
      overlayExpected(envelope.manifest.overlay),
    );
  }
  return { ...envelope, runs };
}

export {
  POST_SEARCH_V5_ROUTED_CATALOG_DAEMON_HARD_LIMIT,
  POST_SEARCH_V5_ROUTED_CATALOG_FORMAT,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_LEVEL,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS,
  POST_SEARCH_V5_ROUTED_CATALOG_MAX_RUNS_PER_LEVEL,
  POST_SEARCH_V5_ROUTED_CATALOG_OPEN_CONCURRENCY,
  POST_SEARCH_V5_ROUTED_CATALOG_PIN_PLANNING_LIMIT,
  type PostSearchV5RoutedCatalogBuild,
  type PostSearchV5RoutedCatalogInput,
  type PostSearchV5RoutedCatalogLookup,
  type PostSearchV5RoutedCatalogManifest,
  type PostSearchV5RoutedCatalogOverlayDescriptor,
  type PostSearchV5RoutedCatalogOverlayInput,
  type PostSearchV5RoutedCatalogRunDescriptor,
  type PostSearchV5RoutedCatalogRunInput,
  type PostSearchV5RoutedCoverage,
  type PostSearchV5RoutedScoringManifest,
  type PostSearchV5RoutedSourceSnapshot,
} from './postSearchV5RoutedCatalogTypes';
