import {
  nhashDecode,
  nhashEncode,
  sha256,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';

export async function readPostSearchV5RoutedCatalogPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  const cid = postSearchV5RoutedCatalogPublicCid(root, label);
  const bytes = await store.get(cid.hash);
  if (!bytes) {
    throw new Error(`Missing post-search v5 routed ${label} block`);
  }
  if (bytes.length > maximum) {
    throw new Error(`Post-search v5 routed ${label} exceeds capacity`);
  }
  if (!equalPostSearchV5RoutedCatalogBytes(await sha256(bytes), cid.hash)) {
    throw new Error(`Post-search v5 routed ${label} hash mismatch`);
  }
  return bytes;
}

export function postSearchV5RoutedCatalogPublicNhash(value: unknown, label: string): CID {
  if (typeof value !== 'string') {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  let cid: CID;
  try {
    cid = nhashDecode(value);
  } catch {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  const result = postSearchV5RoutedCatalogPublicCid(cid, label);
  if (nhashEncode(result) !== value) {
    throw new Error(`Noncanonical post-search v5 routed ${label}`);
  }
  return result;
}

export function postSearchV5RoutedCatalogPublicCid(value: unknown, label: string): CID {
  if (!isPostSearchV5RoutedCatalogRecord(value)
    || !(value.hash instanceof Uint8Array)
    || value.hash.length !== 32
    || value.key !== undefined) {
    throw new Error(`Invalid or encrypted post-search v5 routed ${label} CID`);
  }
  return { hash: new Uint8Array(value.hash) };
}

export function assertPostSearchV5RoutedCatalogCanonicalLink(link: Link): void {
  if (!(link.hash instanceof Uint8Array) || link.hash.length !== 32
    || link.key !== undefined || typeof link.name !== 'string' || !link.name
    || !Number.isSafeInteger(link.size) || link.size < 0 || link.meta !== undefined) {
    throw new Error('Post-search v5 routed catalog contains an invalid or encrypted link');
  }
}

export async function mapPostSearchV5RoutedCatalogWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  work: (value: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let cursor = 0;
  await Promise.all(Array.from({
    length: Math.min(concurrency, values.length),
  }, async () => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await work(values[index]!, index);
    }
  }));
  return results;
}

export function assertPostSearchV5RoutedCatalogExactKeys(
  value: Record<string, unknown>,
  expected: readonly string[],
  label: string,
): void {
  if (!samePostSearchV5RoutedCatalogStrings(
    Object.keys(value).sort(comparePostSearchV5RoutedCatalogText),
    [...expected].sort(comparePostSearchV5RoutedCatalogText),
  )) {
    throw new Error(`Invalid post-search v5 routed ${label} fields`);
  }
}

export function postSearchV5RoutedCatalogObject(
  value: unknown,
  label: string,
): Record<string, unknown> {
  if (!isPostSearchV5RoutedCatalogRecord(value)) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function isPostSearchV5RoutedCatalogRecord(
  value: unknown,
): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function postSearchV5RoutedCatalogPublisher(value: unknown): string {
  const result = postSearchV5RoutedCatalogNonEmptyString(value, 'publisherId').trim();
  if (!result || result.length > 256) {
    throw new Error('Invalid post-search v5 routed publisherId');
  }
  return result;
}

export function postSearchV5RoutedCatalogNonEmptyString(
  value: unknown,
  label: string,
): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function postSearchV5RoutedCatalogNullableInteger(
  value: unknown,
  label: string,
): number | null {
  return value === null ? null : postSearchV5RoutedCatalogNonNegativeInteger(value, label);
}

export function postSearchV5RoutedCatalogNonNegativeInteger(
  value: unknown,
  label: string,
): number {
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value as number;
}

export function postSearchV5RoutedCatalogPositiveInteger(
  value: unknown,
  label: string,
): number {
  const result = postSearchV5RoutedCatalogNonNegativeInteger(value, label);
  if (result === 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return result;
}

export function postSearchV5RoutedCatalogPositiveNumber(
  value: unknown,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function postSearchV5RoutedCatalogBoundedNumber(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isFinite(value)
    || value < minimum || value > maximum) {
    throw new Error(`Invalid post-search v5 routed ${label}`);
  }
  return value;
}

export function addPostSearchV5RoutedCatalog(
  left: number,
  right: number,
  label: string,
): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post-search v5 routed ${label} exceeds capacity`);
  }
  return result;
}

export function samePostSearchV5RoutedCatalogStrings(
  left: readonly string[],
  right: readonly string[],
): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

export function comparePostSearchV5RoutedCatalogText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

export function equalPostSearchV5RoutedCatalogBytes(
  left: Uint8Array,
  right: Uint8Array,
): boolean {
  return left.length === right.length
    && left.every((value, index) => value === right[index]);
}
