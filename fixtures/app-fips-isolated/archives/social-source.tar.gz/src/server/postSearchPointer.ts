import { nhashDecode, nhashEncode, toHex, type CID } from '@hashtree/core';
import {
  HASHTREE_LABEL,
  HASHTREE_ROOT_KIND,
  parseHashtreeRootEvent,
} from '@hashtree/nostr';
import type { RawEvent } from '../lib/nostr';
import { verifyPostSearchEvent } from './postSearchProjection';

export const POST_SEARCH_POINTER_HANDOFF_FORMAT = 'iris-social/post-search-pointer-handoff@1' as const;
export const POST_SEARCH_POINTER_CONTENT_FORMAT = 'iris-social/post-search-pointer@1' as const;
const HEX_64 = /^[0-9a-f]{64}$/;
const HEX_128 = /^[0-9a-f]{128}$/;
const TREE_NAME = /^[a-z0-9][a-z0-9._-]{0,127}$/;

export interface PostSearchPointerTemplate {
  kind: typeof HASHTREE_ROOT_KIND;
  created_at: number;
  tags: string[][];
  content: string;
}

export interface PostSearchPointerSigner {
  sign(template: PostSearchPointerTemplate): Promise<RawEvent>;
}

export interface PostSearchPointerHandoff {
  format: typeof POST_SEARCH_POINTER_HANDOFF_FORMAT;
  status: 'signed-handoff' | 'unsigned-handoff';
  publisherId: string;
  catalogRoot: string;
  sourceEventRoot: string;
  treeName: string;
  unsignedEvent: PostSearchPointerTemplate;
  signedEvent: RawEvent | null;
  publication: {
    required: true;
    transport: 'nostr-replaceable-event';
    blockAvailability: 'required-before-event';
  };
}

export function createPostSearchPointerTemplate(options: {
  catalogRoot: CID;
  sourceEventRoot: string;
  treeName: string;
  createdAt: number;
}): PostSearchPointerTemplate {
  const tags = [
    ['d', validateTreeName(options.treeName)],
    ['hash', toHex(options.catalogRoot.hash)],
    ['l', HASHTREE_LABEL],
    ['l', 'iris-social-post-search'],
    ['source', options.sourceEventRoot],
  ];
  if (options.catalogRoot.key) {
    tags.splice(2, 0, ['key', toHex(options.catalogRoot.key)]);
  }
  return {
    kind: HASHTREE_ROOT_KIND,
    created_at: nonNegativeInteger(options.createdAt, 'createdAt'),
    tags,
    content: JSON.stringify({
      format: POST_SEARCH_POINTER_CONTENT_FORMAT,
      catalogRoot: nhashEncode(options.catalogRoot),
      sourceEventRoot: options.sourceEventRoot,
    }),
  };
}

export function validateSignedPostSearchPointer(
  event: RawEvent,
  publisherId: string,
  treeName: string,
  root: CID,
  unsignedEvent: PostSearchPointerTemplate,
): void {
  if (!verifyPostSearchEvent(event) || event.pubkey !== publisherId) {
    throw new Error('Post search pointer signer returned an invalid event or publisher');
  }
  if (event.kind !== unsignedEvent.kind
    || event.created_at !== unsignedEvent.created_at
    || event.content !== unsignedEvent.content
    || JSON.stringify(event.tags) !== JSON.stringify(unsignedEvent.tags)) {
    throw new Error('Signed post search pointer does not exactly match the unsigned template');
  }
  const parsed = parseHashtreeRootEvent(event);
  if (!parsed
    || parsed.treeName !== treeName
    || toHex(parsed.rootCid.hash) !== toHex(root.hash)
    || toHex(parsed.rootCid.key ?? new Uint8Array()) !== toHex(root.key ?? new Uint8Array())) {
    throw new Error('Signed post search pointer does not match the catalog root');
  }
}

export function isPostSearchPointerHandoff(value: unknown): value is PostSearchPointerHandoff {
  if (!isObject(value)
    || value.format !== POST_SEARCH_POINTER_HANDOFF_FORMAT
    || (value.status !== 'signed-handoff' && value.status !== 'unsigned-handoff')
    || typeof value.publisherId !== 'string'
    || !HEX_64.test(value.publisherId)
    || !canonicalRoot(value.catalogRoot)
    || !canonicalRoot(value.sourceEventRoot)
    || typeof value.treeName !== 'string'
    || !TREE_NAME.test(value.treeName)
    || !isPostSearchPointerTemplate(value.unsignedEvent)
    || !isObject(value.publication)
    || value.publication.required !== true
    || value.publication.transport !== 'nostr-replaceable-event'
    || value.publication.blockAvailability !== 'required-before-event') {
    return false;
  }
  const signedEvent = value.signedEvent;
  return value.status === 'signed-handoff'
    ? isRawEventShape(signedEvent)
    : signedEvent === null;
}

function isPostSearchPointerTemplate(value: unknown): value is PostSearchPointerTemplate {
  return isObject(value)
    && value.kind === HASHTREE_ROOT_KIND
    && Number.isSafeInteger(value.created_at)
    && Number(value.created_at) >= 0
    && Array.isArray(value.tags)
    && value.tags.every((tag) => Array.isArray(tag)
      && tag.every((item) => typeof item === 'string'))
    && typeof value.content === 'string';
}

function isRawEventShape(value: unknown): value is RawEvent {
  return isObject(value)
    && typeof value.id === 'string'
    && HEX_64.test(value.id)
    && typeof value.pubkey === 'string'
    && HEX_64.test(value.pubkey)
    && isPostSearchPointerTemplate(value)
    && typeof value.sig === 'string'
    && HEX_128.test(value.sig);
}

function canonicalRoot(value: unknown): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  try {
    return nhashEncode(nhashDecode(value)) === value;
  } catch {
    return false;
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function validateTreeName(value: string): string {
  if (!TREE_NAME.test(value)) {
    throw new Error('Invalid post search pointer tree name');
  }
  return value;
}

function nonNegativeInteger(value: number, name: string): number {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`Invalid post search pointer ${name}`);
  }
  return value;
}
