import { createHash } from 'node:crypto';
import { toHex, type Hash, type Store } from '@hashtree/core';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_RETRY_DELAYS_MS = [250, 1_000, 4_000] as const;
const RETRYABLE_STATUS_CODES = new Set([429, 500, 502, 503, 504]);

export interface HttpBlockStoreCredentials {
  username: string;
  password: string;
}

/** Parse either a JSON credentials object or Hashtree's username:password auth.cookie. */
export function parseHttpBlockStoreCredentials(raw: string): HttpBlockStoreCredentials {
  const value = raw.trim();
  if (!value) {
    throw new Error('Invalid Hashtree store credentials file');
  }

  if (value.startsWith('{')) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(value);
    } catch {
      throw new Error('Invalid Hashtree store credentials file');
    }
    if (typeof parsed !== 'object' || parsed === null) {
      throw new Error('Invalid Hashtree store credentials file');
    }
    const credentials = parsed as Record<string, unknown>;
    if (typeof credentials.username !== 'string' || typeof credentials.password !== 'string') {
      throw new Error('Invalid Hashtree store credentials file');
    }
    const result = { username: credentials.username, password: credentials.password };
    validateCredentials(result);
    return result;
  }

  const parts = value.split(':');
  if (parts.length !== 2) {
    throw new Error('Invalid Hashtree store credentials file');
  }
  const result = { username: parts[0], password: parts[1] };
  validateCredentials(result);
  return result;
}

export interface HttpBlockStoreOptions {
  credentials: HttpBlockStoreCredentials;
  fetch?: typeof fetch;
  retryDelaysMs?: readonly number[];
  timeoutMs?: number;
}

/**
 * Store adapter for a daemon that owns the backing database. Reads use the
 * public hash endpoint; mutations use its strictly authenticated endpoint.
 */
export class HttpBlockStore implements Store {
  private readonly baseUrl: string;
  private readonly authorization: string;
  private readonly fetchImpl: typeof fetch;
  private readonly retryDelaysMs: readonly number[];
  private readonly timeoutMs: number;

  constructor(baseUrl: string, options: HttpBlockStoreOptions) {
    const url = new URL(baseUrl);
    if ((url.protocol !== 'http:' && url.protocol !== 'https:')
      || url.username
      || url.password
      || url.search
      || url.hash) {
      throw new Error('Hashtree store URL must be an HTTP(S) URL without credentials or query');
    }
    validateCredentials(options.credentials);
    this.baseUrl = url.toString().replace(/\/$/, '');
    this.authorization = `Basic ${Buffer.from(
      `${options.credentials.username}:${options.credentials.password}`,
      'utf8',
    ).toString('base64')}`;
    this.fetchImpl = options.fetch ?? fetch;
    this.retryDelaysMs = (options.retryDelaysMs ?? DEFAULT_RETRY_DELAYS_MS)
      .map((delay) => nonNegativeInteger(delay, 'retry delay'));
    this.timeoutMs = positiveInteger(options.timeoutMs ?? DEFAULT_TIMEOUT_MS, 'timeoutMs');
  }

  async put(hash: Hash, data: Uint8Array): Promise<boolean> {
    const expected = toHex(hash);
    if (sha256Hex(data) !== expected) {
      throw new Error(`Refusing Hashtree block with hash mismatch: ${expected}`);
    }
    const response = await this.request(expected, {
      method: 'PUT',
      headers: {
        authorization: this.authorization,
        'content-type': 'application/octet-stream',
      },
      body: new Uint8Array(data).buffer,
    });
    if (response.status !== 200 && response.status !== 201) {
      throw statusError('PUT', response.status);
    }
    const result = await parsePutResponse(response);
    if (result.hash !== expected || result.stored !== true) {
      throw new Error('Hashtree store PUT returned an invalid acknowledgement');
    }
    return response.status === 201;
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    const expected = toHex(hash);
    const response = await this.request(expected);
    if (response.status === 404) {
      return null;
    }
    if (response.status !== 200) {
      throw statusError('GET', response.status);
    }
    const data = new Uint8Array(await response.arrayBuffer());
    if (sha256Hex(data) !== expected) {
      throw new Error(`Hashtree store GET returned corrupt block: ${expected}`);
    }
    return data;
  }

  async has(hash: Hash): Promise<boolean> {
    const response = await this.request(toHex(hash), { method: 'HEAD' });
    if (response.status === 200) {
      return true;
    }
    if (response.status === 404) {
      return false;
    }
    throw statusError('HEAD', response.status);
  }

  async delete(hash: Hash): Promise<boolean> {
    const response = await this.request(toHex(hash), {
      method: 'DELETE',
      headers: { authorization: this.authorization },
    });
    if (response.status === 200) {
      return true;
    }
    if (response.status === 404) {
      return false;
    }
    throw statusError('DELETE', response.status);
  }

  private async request(hash: string, init: RequestInit = {}): Promise<Response> {
    const url = `${this.baseUrl}/__iris/store/${hash}`;
    const method = init.method ?? 'GET';
    for (let attempt = 0; ; attempt += 1) {
      try {
        const response = await this.fetchImpl(url, {
          ...init,
          signal: AbortSignal.timeout(this.timeoutMs),
        });
        const delay = this.retryDelaysMs[attempt];
        if (!RETRYABLE_STATUS_CODES.has(response.status) || delay === undefined) {
          return response;
        }
        await response.body?.cancel().catch(() => undefined);
        await sleep(delay);
      } catch (error) {
        const delay = this.retryDelaysMs[attempt];
        if (!isRetryableRequestError(error)) {
          throw error;
        }
        if (delay === undefined) {
          throw new Error(
            `Hashtree store ${method} ${hash} failed after ${attempt + 1} attempts `
            + `(${this.timeoutMs}ms timeout): ${requestErrorName(error)}`,
            { cause: error },
          );
        }
        await sleep(delay);
      }
    }
  }
}

async function parsePutResponse(response: Response): Promise<{ hash?: unknown; stored?: unknown }> {
  try {
    const value: unknown = await response.json();
    return typeof value === 'object' && value !== null ? value : {};
  } catch {
    throw new Error('Hashtree store PUT returned an invalid acknowledgement');
  }
}

function validateCredentials(credentials: HttpBlockStoreCredentials): void {
  if (!credentials.username
    || credentials.username.includes(':')
    || /[\r\n]/.test(credentials.username)
    || !credentials.password
    || /[\r\n]/.test(credentials.password)) {
    throw new Error('Invalid Hashtree store Basic-auth credentials');
  }
}

function statusError(method: string, status: number): Error {
  return new Error(`Hashtree store ${method} failed with HTTP ${status}`);
}

function sha256Hex(data: Uint8Array): string {
  return createHash('sha256').update(data).digest('hex');
}

function positiveInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`Invalid Hashtree HTTP store ${name}`);
  }
  return value;
}

function nonNegativeInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid Hashtree HTTP store ${name}`);
  }
  return value;
}

function isRetryableRequestError(error: unknown): error is Error {
  return error instanceof Error && (
    error.name === 'AbortError'
    || error.name === 'TimeoutError'
    || error instanceof TypeError
  );
}

function requestErrorName(error: Error): string {
  return error.name || error.constructor.name || 'request error';
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
