import { randomUUID } from 'node:crypto';
import { mkdir, open, readFile, rm, stat } from 'node:fs/promises';
import { hostname } from 'node:os';
import { dirname, resolve } from 'node:path';

export const EXCLUSIVE_FILE_LOCK_FORMAT = 'iris-social/exclusive-file-lock@1' as const;

export interface ExclusiveFileLock {
  path: string;
  release(): Promise<void>;
}

/** Serialize one local writer without treating a crashed process as a permanent lock. */
export async function acquireExclusiveFileLock(
  targetPath: string,
  rawLabel: string,
): Promise<ExclusiveFileLock> {
  const label = validLabel(rawLabel);
  const path = `${resolve(targetPath)}.lock`;
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  let token = '';
  for (let attempt = 0; attempt < 3; attempt += 1) {
    token = randomUUID();
    try {
      const file = await open(path, 'wx', 0o600);
      try {
        await file.writeFile(`${JSON.stringify({
          format: EXCLUSIVE_FILE_LOCK_FORMAT,
          label,
          host: hostname(),
          pid: process.pid,
          token,
          startedAt: new Date().toISOString(),
        })}\n`);
        await file.sync();
      } finally {
        await file.close();
      }
      await syncDirectory(directory);
      break;
    } catch (error) {
      if (!isErrno(error, 'EEXIST')) {throw error;}
    }

    const owner = await readLockOwner(path);
    if (owner) {
      if (owner.host !== hostname()) {
        throw new Error(`${label} is locked on host ${owner.host}`);
      }
      if (processIsAlive(owner.pid)) {
        throw new Error(`${label} is locked: ${path}`);
      }
    } else {
      const ageMs = await fileAgeMs(path);
      if (ageMs === null) {continue;}
      if (ageMs < 30_000) {
        throw new Error(`${label} lock is still being initialized`);
      }
    }
    await rm(path, { force: true });
  }
  if (!token || (await readLockOwner(path))?.token !== token) {
    throw new Error(`Failed to acquire ${label} lock`);
  }

  let released = false;
  return {
    path,
    async release() {
      if (released) {return;}
      let owner: unknown;
      try {
        owner = JSON.parse(await readFile(path, 'utf8'));
      } catch (error) {
        if (isErrno(error, 'ENOENT')) {
          released = true;
          return;
        }
        throw error;
      }
      if (!isRecord(owner) || owner.token !== token) {
        throw new Error(`${label} lock ownership changed`);
      }
      await rm(path);
      await syncDirectory(directory);
      released = true;
    },
  };
}

function validLabel(value: string): string {
  if (!value || value.length > 128 || /[\r\n]/.test(value)) {
    throw new Error('Invalid exclusive lock label');
  }
  return value;
}

async function readLockOwner(
  path: string,
): Promise<{ pid: number; host: string; token: string } | null> {
  try {
    const value: unknown = JSON.parse(await readFile(path, 'utf8'));
    if (!isRecord(value)
      || value.format !== EXCLUSIVE_FILE_LOCK_FORMAT
      || !Number.isSafeInteger(value.pid)
      || Number(value.pid) <= 0
      || typeof value.host !== 'string'
      || typeof value.token !== 'string') {
      return null;
    }
    return { pid: Number(value.pid), host: value.host, token: value.token };
  } catch (error) {
    if (isErrno(error, 'ENOENT') || error instanceof SyntaxError) {return null;}
    throw error;
  }
}

function processIsAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return isErrno(error, 'EPERM');
  }
}

async function fileAgeMs(path: string): Promise<number | null> {
  try {
    return Math.max(0, Date.now() - (await stat(path)).mtimeMs);
  } catch (error) {
    if (isErrno(error, 'ENOENT')) {return null;}
    throw error;
  }
}

async function syncDirectory(path: string): Promise<void> {
  const handle = await open(path, 'r');
  try {await handle.sync();} finally {await handle.close();}
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isErrno(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code;
}
