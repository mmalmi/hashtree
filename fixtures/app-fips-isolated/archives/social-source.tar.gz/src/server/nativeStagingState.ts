import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

export type NativeStagingState = {
  version: number;
  next_author: number;
  events_seen: number;
  events_selected: number;
  live_bytes_selected: number;
  policy: {
    author_count: number;
    author_allowlist_sha256: string;
    require_all_relays: boolean;
  };
};

export async function readCompletedStagingState(
  dataDir: string,
  expectedAuthorCount: number,
  expectedAllowlistSha256: string,
): Promise<NativeStagingState> {
  let value: unknown;
  try {
    value = JSON.parse(await readFile(
      join(dataDir, 'nostr-stage', 'crawl-state.json'),
      'utf8',
    ));
  } catch {
    throw new Error('native broad archive staging state is missing or invalid');
  }
  if (!value || typeof value !== 'object') {
    throw new Error('native broad archive staging state is missing or invalid');
  }
  const state = value as Partial<NativeStagingState>;
  if (state.version !== 1
    || !Number.isSafeInteger(state.next_author)
    || !Number.isSafeInteger(state.events_seen)
    || !Number.isSafeInteger(state.events_selected)
    || !Number.isSafeInteger(state.live_bytes_selected)
    || !state.policy || typeof state.policy !== 'object') {
    throw new Error('native broad archive staging state is missing or invalid');
  }
  if (state.next_author !== expectedAuthorCount
    || state.policy.author_count !== expectedAuthorCount) {
    throw new Error('native broad archive fetch did not complete the exact author allowlist');
  }
  if (state.policy.author_allowlist_sha256 !== expectedAllowlistSha256) {
    throw new Error('native broad archive staging state does not match the author allowlist');
  }
  if (state.policy.require_all_relays) {
    throw new Error('native broad archive staging still requires every configured relay');
  }
  return state as NativeStagingState;
}
