import { DEFAULT_MAX_LINKS, HashTree, LinkType, nhashDecode, nhashEncode, sha256,
  type CID, type Store, type TreeEntry } from '@hashtree/core';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT, POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES, POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
  postSearchV5PackedPageEntryByteLength, readPostSearchV5PackedPage,
  writePostSearchV5PackedPage, type PostSearchV5PackedPageEntry } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT, parsePostSearchV5VisibilityOverlay,
  serializePostSearchV5VisibilityOverlay,
  type PostSearchV5CoordinateState,
  type PostSearchV5EventReference, type PostSearchV5ExactTombstone,
  type PostSearchV5VisibilityOverlay } from './postSearchV5Overlay';
import { normalizePostSearchV5OverlayBounds, parsePostSearchV5OverlayBounds,
  type PostSearchV5OverlayBounds } from './postSearchV5OverlayBounds';
export const POST_SEARCH_V5_OVERLAY_STORE_FORMAT =
  'iris-social/post-search-v5-overlay-store@1' as const;
export const POST_SEARCH_V5_OVERLAY_MANIFEST_MAX_BYTES = 1_048_576;
export const POST_SEARCH_V5_OVERLAY_MAX_PAGES = 8_192;
const MANIFEST_ENTRY = 'manifest.json';
const PAGE_ENTRY_PREFIX = 'page-';
const EMPTY_PAGE_KEY = '~empty';
const EMPTY_PAGE_VALUE = 'visibility-overlay';
const MIN_PACKED_PAGE_BYTES = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES
  + postSearchV5PackedPageEntryByteLength('x', '');
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
export interface PostSearchV5OverlayPageDescriptor {
  root: string; entryCount: number; byteLength: number;
}
export interface PostSearchV5OverlayStoreManifest {
  format: typeof POST_SEARCH_V5_OVERLAY_STORE_FORMAT;
  overlayFormat: typeof POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT;
  packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  bounds: PostSearchV5OverlayBounds; maxPageBytes: number;
  exactTombstoneCount: number; coordinateStateCount: number;
  addressWinnerCount: number; addressDeletionCount: number;
  pageCount: number; reachableNodeCount: number;
  pages: PostSearchV5OverlayPageDescriptor[];
}
export interface PostSearchV5WrittenVisibilityOverlay {
  root: CID; exactTombstoneCount: number; coordinateStateCount: number;
  addressWinnerCount: number; addressDeletionCount: number;
  pageCount: number; reachableNodeCount: number;
}
export interface PostSearchV5ReadVisibilityOverlay
  extends PostSearchV5WrittenVisibilityOverlay {
  overlay: PostSearchV5VisibilityOverlay; manifest: PostSearchV5OverlayStoreManifest;
}
export type PostSearchV5OverlayStoreExpected =
  Partial<Omit<PostSearchV5WrittenVisibilityOverlay, 'root'>>;
export interface PostSearchV5OverlayStoreWriteOptions {
  maxPageBytes?: number;
}
type VisibilityRecord = PostSearchV5PackedPageEntry;
export async function writePostSearchV5VisibilityOverlay(
  store: Store,
  overlay: PostSearchV5VisibilityOverlay,
  options: PostSearchV5OverlayStoreWriteOptions = {},
): Promise<PostSearchV5WrittenVisibilityOverlay> {
  serializePostSearchV5VisibilityOverlay(overlay);
  const maxPageBytes = pageByteLimit(options.maxPageBytes);
  const pageDescriptors: PostSearchV5OverlayPageDescriptor[] = [];
  const pageEntries: TreeEntry[] = [];
  let pending: VisibilityRecord[] = [];
  let pendingBytes = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES;
  const flush = async (): Promise<void> => {
    if (pending.length === 0) {
      return;
    }
    if (pageDescriptors.length >= POST_SEARCH_V5_OVERLAY_MAX_PAGES) {
      throw new Error('Post-search v5 visibility overlay exceeds its page-count bound');
    }
    const written = await writePostSearchV5PackedPage(store, 'visibility', pending);
    if (written.byteLength !== pendingBytes || written.byteLength > maxPageBytes) {
      throw new Error('Post-search v5 visibility page batching size is inconsistent');
    }
    const descriptor = {
      root: nhashEncode(written.root),
      entryCount: written.entryCount,
      byteLength: written.byteLength,
    };
    pageDescriptors.push(descriptor);
    pageEntries.push({
      name: pageEntryName(pageDescriptors.length - 1),
      cid: written.root,
      size: written.byteLength,
      type: LinkType.File,
    });
    pending = [];
    pendingBytes = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES;
  };
  const append = async (record: VisibilityRecord): Promise<void> => {
    const recordBytes = packedEntryBytes(record);
    if (POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES + recordBytes > maxPageBytes) {
      throw new Error('Post-search v5 visibility record exceeds the configured page byte limit');
    }
    if (pending.length >= POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES
      || pendingBytes + recordBytes > maxPageBytes) {
      await flush();
    }
    pending.push(record);
    pendingBytes += recordBytes;
  };
  for (const state of overlay.coordinates) {
    await append(coordinateRecord(state));
  }
  for (const tombstone of overlay.exactTombstones) {
    await append(exactRecord(tombstone));
  }
  if (pending.length === 0 && pageDescriptors.length === 0) {
    await append([EMPTY_PAGE_KEY, EMPTY_PAGE_VALUE]);
  }
  await flush();
  const exactTombstoneCount = overlay.exactTombstones.length;
  const coordinateStateCount = overlay.coordinates.length;
  const addressWinnerCount = overlay.coordinates.reduce(
    (count, state) => count + (state.winner ? 1 : 0),
    0,
  );
  const addressDeletionCount = overlay.coordinates.reduce(
    (count, state) => count + (state.deletion ? 1 : 0),
    0,
  );
  const pageCount = pageDescriptors.length;
  const reachableNodeCount = pageCount + 1
    + canonicalDirectoryNodeCount(pageCount + 1);
  const manifest: PostSearchV5OverlayStoreManifest = {
    format: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
    overlayFormat: POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    bounds: normalizePostSearchV5OverlayBounds(overlay.bounds),
    maxPageBytes,
    exactTombstoneCount,
    coordinateStateCount,
    addressWinnerCount,
    addressDeletionCount,
    pageCount,
    reachableNodeCount,
    pages: pageDescriptors,
  };
  const manifestBytes = encoder.encode(JSON.stringify(manifest));
  if (manifestBytes.length > POST_SEARCH_V5_OVERLAY_MANIFEST_MAX_BYTES) {
    throw new Error('Post-search v5 visibility overlay manifest exceeds its byte bound');
  }
  const manifestRoot = await writePublicBlock(store, manifestBytes);
  const tree = new HashTree({ store });
  const root = (await tree.putDirectory([{
    name: MANIFEST_ENTRY,
    cid: manifestRoot,
    size: manifestBytes.length,
    type: LinkType.File,
  }, ...pageEntries], { unencrypted: true })).cid;
  return {
    root,
    exactTombstoneCount,
    coordinateStateCount,
    addressWinnerCount,
    addressDeletionCount,
    pageCount,
    reachableNodeCount,
  };
}
export async function readPostSearchV5VisibilityOverlay(
  store: Store,
  root: CID,
  expected: PostSearchV5OverlayStoreExpected = {},
): Promise<PostSearchV5ReadVisibilityOverlay> {
  assertPublicCid(root, 'visibility overlay root');
  await readPublicBlock(store, root, Number.MAX_SAFE_INTEGER, 'visibility overlay root');
  const tree = new HashTree({ store });
  if (!(await tree.isDirectory(root))) {
    throw new Error('Post-search v5 visibility overlay root is not a directory');
  }
  const entries = await tree.listDirectory(root);
  assertUniqueRootEntries(entries);
  const manifestEntry = entries.find((entry) => entry.name === MANIFEST_ENTRY);
  if (!manifestEntry || manifestEntry.type !== LinkType.File || manifestEntry.meta !== undefined) {
    throw new Error('Post-search v5 visibility overlay manifest link is missing or invalid');
  }
  assertPublicCid(manifestEntry.cid, 'visibility overlay manifest');
  const manifestBytes = await readPublicBlock(
    store,
    manifestEntry.cid,
    POST_SEARCH_V5_OVERLAY_MANIFEST_MAX_BYTES,
    'visibility overlay manifest',
  );
  if (manifestEntry.size !== manifestBytes.length) {
    throw new Error('Post-search v5 visibility overlay manifest link size is inconsistent');
  }
  const manifestText = decodeUtf8(manifestBytes, 'visibility overlay manifest');
  const manifest = parsePostSearchV5OverlayStoreManifest(manifestText);
  const declaredPackedBytes = manifest.pages.reduce(
    (sum, page) => safeAdd(sum, page.byteLength),
    0,
  );
  if (declaredPackedBytes > manifest.bounds.maxSerializedBytes) {
    throw new Error('Post-search v5 visibility pages exceed the overlay byte budget');
  }
  const expectedEntryNames = new Set([
    MANIFEST_ENTRY,
    ...manifest.pages.map((_page, index) => pageEntryName(index)),
  ]);
  if (entries.length !== expectedEntryNames.size) {
    throw new Error('Post-search v5 visibility overlay root contains missing or unbound links');
  }
  for (const entry of entries) {
    if (!expectedEntryNames.has(entry.name)) {
      throw new Error(`Post-search v5 visibility overlay has an unbound root link: ${entry.name}`);
    }
  }
  const entriesByName = new Map(entries.map((entry) => [entry.name, entry]));
  const exactTombstones: PostSearchV5ExactTombstone[] = [];
  const coordinates: PostSearchV5CoordinateState[] = [];
  let previousKey: string | null = null;
  let previousPage: { byteLength: number; entryCount: number } | null = null;
  let sawEmptyMarker = false;
  for (let pageIndex = 0; pageIndex < manifest.pages.length; pageIndex += 1) {
    const descriptor = manifest.pages[pageIndex]!;
    const name = pageEntryName(pageIndex);
    const entry = entriesByName.get(name);
    if (!entry || entry.type !== LinkType.File || entry.meta !== undefined
      || entry.size !== descriptor.byteLength
      || nhashEncode(entry.cid) !== descriptor.root) {
      throw new Error(`Post-search v5 visibility page link is missing or inconsistent: ${name}`);
    }
    const page = await readPostSearchV5PackedPage(store, entry.cid);
    if (page.kind !== 'visibility' || page.entries.length !== descriptor.entryCount) {
      throw new Error(`Post-search v5 visibility page is corrupt: ${name}`);
    }
    const pageBytes = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES + page.entries.reduce(
      (sum, pageEntry) => sum + packedEntryBytes(pageEntry),
      0,
    );
    if (pageBytes !== descriptor.byteLength || pageBytes > manifest.maxPageBytes) {
      throw new Error(`Post-search v5 visibility page byte count is inconsistent: ${name}`);
    }
    const first = page.entries[0]!;
    if (previousPage
      && previousPage.entryCount < POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES
      && previousPage.byteLength + packedEntryBytes(first) <= manifest.maxPageBytes) {
      throw new Error('Post-search v5 visibility pages are not canonically byte-packed');
    }
    for (const record of page.entries) {
      if (previousKey !== null && compareText(previousKey, record[0]) >= 0) {
        throw new Error('Post-search v5 visibility records are not globally unique and sorted');
      }
      previousKey = record[0];
      if (record[0] === EMPTY_PAGE_KEY) {
        if (record[1] !== EMPTY_PAGE_VALUE) {
          throw new Error('Invalid post-search v5 empty visibility marker');
        }
        sawEmptyMarker = true;
      } else if (record[0].startsWith('a:')) {
        if (coordinates.length >= manifest.coordinateStateCount
          || encoder.encode(record[0].slice(2)).length > manifest.bounds.maxCoordinateBytes) {
          throw new Error('Post-search v5 coordinate records exceed their declared bounds');
        }
        coordinates.push(parseCoordinateRecord(record));
      } else if (record[0].startsWith('e:')) {
        if (exactTombstones.length >= manifest.exactTombstoneCount) {
          throw new Error('Post-search v5 exact records exceed their declared count');
        }
        exactTombstones.push(parseExactRecord(record));
      } else {
        throw new Error('Invalid post-search v5 visibility record key');
      }
    }
    previousPage = { byteLength: descriptor.byteLength, entryCount: descriptor.entryCount };
  }
  const recordCount = exactTombstones.length + coordinates.length;
  if (sawEmptyMarker !== (recordCount === 0)
    || (sawEmptyMarker && (manifest.pageCount !== 1 || manifest.pages[0]?.entryCount !== 1))) {
    throw new Error('Post-search v5 empty visibility marker is inconsistent');
  }
  const overlayText = JSON.stringify({
    format: POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT,
    bounds: manifest.bounds,
    exactTombstones,
    coordinates,
  });
  const overlay = parsePostSearchV5VisibilityOverlay(overlayText, manifest.bounds);
  const actualCounts = overlayCounts(overlay);
  assertManifestCounts(manifest, actualCounts);
  let actualReachableNodeCount = 0;
  for await (const _block of tree.walkBlocks(root)) {
    actualReachableNodeCount += 1;
  }
  if (actualReachableNodeCount !== manifest.reachableNodeCount) {
    throw new Error('Post-search v5 visibility overlay reachable-node count is inconsistent');
  }
  const result: PostSearchV5ReadVisibilityOverlay = {
    root,
    overlay,
    manifest,
    ...actualCounts,
    pageCount: manifest.pageCount,
    reachableNodeCount: manifest.reachableNodeCount,
  };
  assertExpectedCounts(result, expected);
  return result;
}
export function parsePostSearchV5OverlayStoreManifest(
  raw: string,
): PostSearchV5OverlayStoreManifest {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Invalid post-search v5 visibility overlay manifest JSON');
  }
  if (!isRecord(value)
    || value.format !== POST_SEARCH_V5_OVERLAY_STORE_FORMAT
    || value.overlayFormat !== POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT
    || value.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || !Array.isArray(value.pages)) {
    throw new Error('Unsupported post-search v5 visibility overlay manifest');
  }
  const bounds = parsePostSearchV5OverlayBounds(value.bounds);
  const maxPageBytes = pageByteLimit(value.maxPageBytes);
  const exactTombstoneCount = nonNegativeInteger(value.exactTombstoneCount, 'exactTombstoneCount');
  const coordinateStateCount = nonNegativeInteger(value.coordinateStateCount, 'coordinateStateCount');
  const addressWinnerCount = nonNegativeInteger(value.addressWinnerCount, 'addressWinnerCount');
  const addressDeletionCount = nonNegativeInteger(value.addressDeletionCount, 'addressDeletionCount');
  const pageCount = positiveInteger(value.pageCount, 'pageCount');
  const reachableNodeCount = positiveInteger(value.reachableNodeCount, 'reachableNodeCount');
  if (pageCount > POST_SEARCH_V5_OVERLAY_MAX_PAGES || value.pages.length !== pageCount) {
    throw new Error('Post-search v5 visibility overlay manifest page count is invalid');
  }
  if (exactTombstoneCount > bounds.maxExactTombstones
    || coordinateStateCount > bounds.maxCoordinates
    || addressWinnerCount > coordinateStateCount
    || addressDeletionCount > coordinateStateCount) {
    throw new Error('Post-search v5 visibility overlay manifest counts exceed their bounds');
  }
  const pages = value.pages.map((candidate, index) => parsePageDescriptor(candidate, index, maxPageBytes));
  const entryCount = pages.reduce((sum, page) => safeAdd(sum, page.entryCount), 0);
  const storedRecordCount = safeAdd(exactTombstoneCount, coordinateStateCount);
  if (entryCount !== storedRecordCount && !(storedRecordCount === 0 && entryCount === 1)) {
    throw new Error('Post-search v5 visibility overlay page record count is inconsistent');
  }
  const expectedReachable = pageCount + 1 + canonicalDirectoryNodeCount(pageCount + 1);
  if (reachableNodeCount !== expectedReachable) {
    throw new Error('Post-search v5 visibility overlay reachable-node count is invalid');
  }
  const manifest: PostSearchV5OverlayStoreManifest = {
    format: POST_SEARCH_V5_OVERLAY_STORE_FORMAT,
    overlayFormat: POST_SEARCH_V5_VISIBILITY_OVERLAY_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    bounds,
    maxPageBytes,
    exactTombstoneCount,
    coordinateStateCount,
    addressWinnerCount,
    addressDeletionCount,
    pageCount,
    reachableNodeCount,
    pages,
  };
  if (JSON.stringify(manifest) !== raw) {
    throw new Error('Post-search v5 visibility overlay manifest is not canonical');
  }
  return manifest;
}
function exactRecord(tombstone: PostSearchV5ExactTombstone): VisibilityRecord {
  return [`e:${tombstone.pubkey}:${tombstone.targetEventId}`,
    JSON.stringify([tombstone.eventId, tombstone.createdAt])];
}
function coordinateRecord(state: PostSearchV5CoordinateState): VisibilityRecord {
  return [`a:${state.coordinate}`,
    JSON.stringify([referenceTuple(state.winner), referenceTuple(state.deletion)])];
}
function referenceTuple(reference: PostSearchV5EventReference | null): [string, number] | null {
  return reference ? [reference.eventId, reference.createdAt] : null;
}
function parseExactRecord(record: VisibilityRecord): PostSearchV5ExactTombstone {
  if (record[0].length !== 2 + 64 + 1 + 64 || record[0][66] !== ':') {
    throw new Error('Invalid post-search v5 exact visibility record key');
  }
  const value = parseCanonicalJson(record[1], 'exact visibility record');
  const reference = parseReferenceTuple(value, 'exact visibility record');
  return { pubkey: record[0].slice(2, 66), targetEventId: record[0].slice(67),
    eventId: reference.eventId, createdAt: reference.createdAt };
}
function parseCoordinateRecord(record: VisibilityRecord): PostSearchV5CoordinateState {
  const value = parseCanonicalJson(record[1], 'coordinate visibility record');
  if (!Array.isArray(value) || value.length !== 2) {
    throw new Error('Invalid post-search v5 coordinate visibility record');
  }
  return { coordinate: record[0].slice(2),
    winner: value[0] === null ? null : parseReferenceTuple(value[0], 'coordinate winner'),
    deletion: value[1] === null ? null : parseReferenceTuple(value[1], 'coordinate deletion') };
}
function parseReferenceTuple(value: unknown, label: string): PostSearchV5EventReference {
  if (!Array.isArray(value) || value.length !== 2
    || typeof value[0] !== 'string'
    || !Number.isSafeInteger(value[1]) || (value[1] as number) < 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return { eventId: value[0], createdAt: value[1] as number };
}
function parseCanonicalJson(raw: string, label: string): unknown {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error(`Invalid post-search v5 ${label} JSON`);
  }
  if (JSON.stringify(value) !== raw) {
    throw new Error(`Post-search v5 ${label} is not canonical JSON`);
  }
  return value;
}
function overlayCounts(overlay: PostSearchV5VisibilityOverlay): Omit<
  PostSearchV5WrittenVisibilityOverlay,
  'root' | 'pageCount' | 'reachableNodeCount'
> {
  return {
    exactTombstoneCount: overlay.exactTombstones.length,
    coordinateStateCount: overlay.coordinates.length,
    addressWinnerCount: overlay.coordinates.filter((state) => state.winner !== null).length,
    addressDeletionCount: overlay.coordinates.filter((state) => state.deletion !== null).length,
  };
}
function assertManifestCounts(
  manifest: PostSearchV5OverlayStoreManifest,
  actual: ReturnType<typeof overlayCounts>,
): void {
  for (const key of [
    'exactTombstoneCount',
    'coordinateStateCount',
    'addressWinnerCount',
    'addressDeletionCount',
  ] as const) {
    if (manifest[key] !== actual[key]) {
      throw new Error(`Post-search v5 visibility overlay ${key} is inconsistent`);
    }
  }
}
function assertExpectedCounts(
  actual: PostSearchV5ReadVisibilityOverlay,
  expected: PostSearchV5OverlayStoreExpected,
): void {
  for (const key of [
    'exactTombstoneCount',
    'coordinateStateCount',
    'addressWinnerCount',
    'addressDeletionCount',
    'pageCount',
    'reachableNodeCount',
  ] as const) {
    if (expected[key] !== undefined && expected[key] !== actual[key]) {
      throw new Error(`Post-search v5 visibility overlay does not match expected ${key}`);
    }
  }
}
function parsePageDescriptor(
  value: unknown,
  index: number,
  maxPageBytes: number,
): PostSearchV5OverlayPageDescriptor {
  if (!isRecord(value)) {
    throw new Error(`Invalid post-search v5 visibility page descriptor at ${index}`);
  }
  const root = canonicalPublicNhash(value.root, `visibility page ${index}`);
  const entryCount = positiveInteger(value.entryCount, `page ${index} entryCount`);
  const byteLength = positiveInteger(value.byteLength, `page ${index} byteLength`);
  if (entryCount > POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES || byteLength > maxPageBytes) {
    throw new Error(`Post-search v5 visibility page descriptor exceeds its bounds at ${index}`);
  }
  return { root: nhashEncode(root), entryCount, byteLength };
}
function packedEntryBytes(entry: VisibilityRecord): number {
  return postSearchV5PackedPageEntryByteLength(entry[0], entry[1]);
}
function pageByteLimit(value: unknown): number {
  const normalized = value === undefined ? POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES : value;
  if (!Number.isSafeInteger(normalized)
    || (normalized as number) < MIN_PACKED_PAGE_BYTES
    || (normalized as number) > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
    throw new Error('Invalid post-search v5 visibility overlay page byte limit');
  }
  return normalized as number;
}
function pageEntryName(index: number): string {
  return `${PAGE_ENTRY_PREFIX}${index.toString().padStart(8, '0')}`;
}
function canonicalDirectoryNodeCount(entryCount: number): number {
  if (entryCount <= DEFAULT_MAX_LINKS) {
    return 1;
  }
  let nodes = 0;
  let spans = entryCount;
  while (spans > DEFAULT_MAX_LINKS) {
    spans = Math.ceil(spans / DEFAULT_MAX_LINKS);
    nodes += spans;
  }
  return nodes + 1;
}
async function writePublicBlock(store: Store, bytes: Uint8Array): Promise<CID> {
  const hash = await sha256(bytes);
  await store.put(hash, bytes);
  return { hash };
}
async function readPublicBlock(
  store: Store,
  root: CID,
  maxBytes: number,
  label: string,
): Promise<Uint8Array> {
  assertPublicCid(root, label);
  const bytes = await store.get(root.hash);
  if (!bytes) {
    throw new Error(`Missing post-search v5 ${label} block`);
  }
  if (bytes.length > maxBytes) {
    throw new Error(`Post-search v5 ${label} exceeds its byte bound`);
  }
  if (!equalBytes(await sha256(bytes), root.hash)) {
    throw new Error(`Post-search v5 ${label} block hash mismatch`);
  }
  return bytes;
}
function canonicalPublicNhash(value: unknown, label: string): CID {
  if (typeof value !== 'string') {
    throw new Error(`Invalid post-search v5 ${label} root`);
  }
  let root: CID;
  try {
    root = nhashDecode(value);
  } catch {
    throw new Error(`Invalid post-search v5 ${label} root`);
  }
  assertPublicCid(root, label);
  if (nhashEncode(root) !== value) {
    throw new Error(`Noncanonical post-search v5 ${label} root`);
  }
  return root;
}
function assertPublicCid(root: CID, label: string): void {
  if (!(root?.hash instanceof Uint8Array) || root.hash.length !== 32 || root.key !== undefined) {
    throw new Error(`Invalid public post-search v5 ${label} CID`);
  }
}
function assertUniqueRootEntries(entries: readonly TreeEntry[]): void {
  const names = new Set<string>();
  for (const entry of entries) {
    if (names.has(entry.name)) {
      throw new Error(`Duplicate post-search v5 visibility overlay root link: ${entry.name}`);
    }
    names.add(entry.name);
  }
}
function decodeUtf8(bytes: Uint8Array, label: string): string {
  try {
    const value = decoder.decode(bytes);
    if (!equalBytes(encoder.encode(value), bytes)) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error(`Invalid UTF-8 in post-search v5 ${label}`);
  }
}
function positiveInteger(value: unknown, name: string): number {
  if (!Number.isSafeInteger(value) || (value as number) <= 0) {
    throw new Error(`Invalid post-search v5 visibility overlay ${name}`);
  }
  return value as number;
}
function nonNegativeInteger(value: unknown, name: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new Error(`Invalid post-search v5 visibility overlay ${name}`);
  }
  return value as number;
}
function safeAdd(left: number, right: number): number {
  const sum = left + right;
  if (!Number.isSafeInteger(sum)) {
    throw new Error('Post-search v5 visibility overlay count overflow');
  }
  return sum;
}
function compareText(left: string, right: string): number { return left < right ? -1 : left > right ? 1 : 0; }
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
