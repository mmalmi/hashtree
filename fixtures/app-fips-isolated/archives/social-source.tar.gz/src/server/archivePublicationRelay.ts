import { randomUUID } from 'node:crypto';
import WebSocket from 'ws';
import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from '../lib/nostr';

/** Valid heads observed before an incomplete response are conflict evidence, never confirmation. */
export class ArchivePointerReadError extends Error {
  constructor(readonly observedHeads: RawEvent[], message = 'Archive pointer read did not complete') {
    super(message);
  }
}

/** One finite Nostr request, resolved only by EOSE or exact positive OK. */
function exchange(url: string, request: unknown[], done: (message: unknown[]) => boolean,
  collect?: (message: unknown[]) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url, { handshakeTimeout: 15_000, maxPayload: 1024 * 1024 });
    const timer = setTimeout(() => finish(new Error('Relay request deadline exceeded')), 20_000);
    let settled = false;
    const finish = (error?: Error) => {
      if (settled) {return;}
      settled = true; clearTimeout(timer); socket.terminate();
      if (error) {reject(error);} else {resolve();}
    };
    socket.on('open', () => socket.send(JSON.stringify(request)));
    socket.on('error', () => finish(new Error('Relay transport failed')));
    socket.on('close', () => finish(new Error('Relay closed before acknowledgement')));
    socket.on('message', raw => {
      if (settled) {return;}
      try {
        const message: unknown = JSON.parse(raw.toString());
        if (!Array.isArray(message)) {throw new Error('Invalid relay response');}
        collect?.(message);
        if (done(message)) {finish();}
      } catch (error) { finish(error instanceof Error ? error : new Error('Invalid relay response')); }
    });
  });
}

export async function readArchivePointerHeads(relay: string, publisher: string, treeName: string): Promise<RawEvent[]> {
  const subscription = randomUUID();
  const events: RawEvent[] = [];
  try { await exchange(relay, ['REQ', subscription, { authors: [publisher], kinds: [30064, 30078], '#d': [treeName], limit: 50 }],
    message => message[0] === 'EOSE' && message[1] === subscription,
    message => {
      if (message[0] !== 'EVENT' || message[1] !== subscription) {return;}
      const event = message[2] as RawEvent;
      if (!verifyEvent(event) || event.pubkey !== publisher
        || ![30064, 30078].includes(event.kind) || !event.tags.some(tag => tag[0] === 'd' && tag[1] === treeName)) {
        throw new Error('Relay returned invalid or excessive pointer events');
      }
      events.push(event);
      // Retain the one verified overflow head as conflict evidence; never accept
      // this incomplete/excessive response as a successful readback.
      if (events.length > 50) {throw new Error('Relay returned invalid or excessive pointer events');}
    }); } catch (error) {
    throw new ArchivePointerReadError([...events], error instanceof Error ? error.message : undefined);
  }
  return events;
}

export async function sendArchivePointer(relay: string, event: RawEvent): Promise<void> {
  await exchange(relay, ['EVENT', event], message => {
    if (message[0] !== 'OK' || message[1] !== event.id) {return false;}
    if (message[2] !== true) {throw new Error('Relay rejected exact signed event');}
    return true;
  });
}
