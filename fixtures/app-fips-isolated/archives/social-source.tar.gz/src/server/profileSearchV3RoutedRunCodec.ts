import {
  LinkType,
  sha256,
  type CID,
  type Link,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import { verifyEvent } from 'nostr-tools/pure';
import {
  parseProfileEvent,
  pubkeyToNpub,
  type ProfileRecord,
  type RawEvent,
} from '../lib/nostr';
import {
  normalizeProfileSearchText,
  profileSearchNip05LocalPart,
  projectProfileSearchIdentity,
  type ProfileSearchIdentity,
} from '../lib/profileSearchIdentity';
import type { PostSearchV5PackedBranchSummary } from './postSearchV5PackedBranch';
import { POST_SEARCH_V5_PACKED_PAGE_FORMAT } from './postSearchV5PackedPage';
import { POST_SEARCH_V5_PAGE_ROUTER_FORMAT } from './postSearchV5PageRouter';
import {
  PROFILE_SEARCH_V3_MAX_POSTINGS_PER_PROFILE,
  PROFILE_SEARCH_V3_MAX_REACHABLE_NODES,
  PROFILE_SEARCH_V3_NORMALIZATION,
  PROFILE_SEARCH_V3_RANK_POLICY,
  PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
  type ProfileSearchV3BranchManifest,
  type ProfileSearchV3Posting,
  type ProfileSearchV3PostingMode,
  type ProfileSearchV3RoutedRunExpected,
  type ProfileSearchV3RoutedRunManifest,
  type ProfileSearchV3StoredProfile,
} from './profileSearchV3RoutedRunTypes';

const MANIFEST_MAX_BYTES = 65_536;
const MAX_PREFIX_CODEPOINTS = 48;
const MAX_TERM_BYTES = 512;
const MAX_PROFILE_CONTENT_BYTES = 262_144;
const MAX_EVENT_TAGS = 256;
const MAX_EVENT_TAG_ITEMS = 64;
const MAX_EVENT_TAG_ITEM_BYTES = 4_096;
const MAX_EVENT_TAG_BYTES = 65_536;
const MAX_RANK_HINT = Number.MAX_SAFE_INTEGER;
const RANK_WIDTH = 16;
const SEPARATOR = '\0';
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export function profileSearchV3PostingsForEvent(
  event: RawEvent,
  rankHint: number,
): ProfileSearchV3Posting[] {
  const validated = validateSignedProfileEvent(event);
  return profileSearchV3PostingsForIdentity(
    validated.event,
    checkedRankHint(rankHint),
    validated.identity,
  );
}

export function profileSearchV3PostingsForIdentity(
  event: RawEvent,
  rankHint: number,
  identity: ProfileSearchIdentity,
): ProfileSearchV3Posting[] {
  const terms = projectedTerms(event, identity);
  return terms.map(({ mode, term }) => ({
    mode,
    term,
    rankHint,
    pubkey: event.pubkey,
  })).sort((left, right) => compareText(
    profileSearchV3PostingKey(left),
    profileSearchV3PostingKey(right),
  ));
}

export function profileSearchV3PostingKey(raw: ProfileSearchV3Posting): string {
  const posting = normalizePosting(raw);
  return `${modeCode(posting.mode)}${SEPARATOR}${posting.term}${SEPARATOR}`
    + `${posting.rankHint.toString().padStart(RANK_WIDTH, '0')}${SEPARATOR}${posting.pubkey}`;
}

export function validateSignedProfileEvent(event: RawEvent): {
  event: RawEvent;
  identity: ProfileSearchIdentity;
} {
  return validateProfileEvent(event, true);
}

function validateProfileEvent(event: RawEvent, verifySignature: boolean): {
  event: RawEvent;
  identity: ProfileSearchIdentity;
} {
  if (!isRecord(event)) {throw new Error('Invalid profile-search v3 profile event');}
  const candidate: RawEvent = {
    id: strictHex(event.id, 64, 'event id'),
    pubkey: strictPubkey(event.pubkey, 'event pubkey'),
    created_at: nonNegativeInteger(event.created_at, 'event created_at'),
    kind: event.kind,
    tags: normalizeTags(event.tags),
    content: boundedStringBytes(event.content, MAX_PROFILE_CONTENT_BYTES, 'event content'),
    sig: strictHex(event.sig, 128, 'event signature'),
  };
  if (candidate.kind !== 0 || (verifySignature && !verifyEvent(candidate))) {
    throw new Error('Profile-search v3 profile event must be a verified signed kind-0 event');
  }
  const identity = projectProfileSearchIdentity(candidate);
  if (!identity) {throw new Error('Profile-search v3 profile identity is invalid or over capacity');}
  return { event: candidate, identity };
}

export function encodeStoredProfile(event: RawEvent, rankHint: number): string {
  const raw = JSON.stringify({ event, rankHint });
  if (encoder.encode(raw).byteLength > 262_144) {
    throw new Error('Profile-search v3 stored profile exceeds its packed-page value capacity');
  }
  return raw;
}

export function parseStoredProfile(
  raw: string,
  expectedPubkey: string,
  verifySignature: boolean,
): ProfileSearchV3StoredProfile {
  let value: unknown;
  try {value = JSON.parse(raw);} catch {throw new Error('Invalid profile-search v3 stored profile JSON');}
  const object = objectValue(value, 'stored profile');
  exactKeys(object, ['event', 'rankHint'], 'stored profile');
  const validated = validateProfileEvent(object.event as RawEvent, verifySignature);
  if (validated.event.pubkey !== strictPubkey(expectedPubkey, 'stored profile key')) {
    throw new Error('Profile-search v3 stored profile pubkey does not match its key');
  }
  const rankHint = checkedRankHint(object.rankHint);
  if (raw !== encodeStoredProfile(validated.event, rankHint)) {
    throw new Error('Profile-search v3 stored profile is not canonical');
  }
  const base = parseProfileEvent(validated.event);
  if (!base) {throw new Error('Profile-search v3 stored profile cannot be projected');}
  const profile: ProfileRecord = {
    ...base,
    name: validated.identity.name,
    displayName: validated.identity.displayName,
    nip05: validated.identity.nip05,
    searchAliases: validated.identity.aliases,
  };
  return { event: validated.event, profile, rankHint };
}

function projectedTerms(
  event: RawEvent,
  identity: ProfileSearchIdentity,
): Array<{ mode: ProfileSearchV3PostingMode; term: string }> {
  const values = [identity.name, identity.displayName, ...identity.aliases]
    .map(normalizeProfileSearchText).filter(Boolean);
  const nip05 = [identity.nip05, profileSearchNip05LocalPart(identity.nip05)]
    .map(normalizeProfileSearchText).filter(Boolean);
  const identifiers = [event.pubkey, pubkeyToNpub(event.pubkey)]
    .map(normalizeProfileSearchText);
  const seen = new Set<string>();
  const terms: Array<{ mode: ProfileSearchV3PostingMode; term: string }> = [];
  const add = (mode: ProfileSearchV3PostingMode, raw: string, required: boolean) => {
    const term = boundedTerm(raw, `${mode} term`);
    if (!term) {return;}
    const key = `${mode}${SEPARATOR}${term}`;
    if (seen.has(key)) {return;}
    if (terms.length >= PROFILE_SEARCH_V3_MAX_POSTINGS_PER_PROFILE) {
      if (required) {throw new Error('Profile-search v3 exact identity postings exceed capacity');}
      return;
    }
    seen.add(key);
    terms.push({ mode, term });
  };
  identifiers.forEach((term) => add('identifier', term, true));
  nip05.forEach((term) => add('nip05', term, true));
  values.forEach((term) => add('identity', term, true));
  const words = [...new Set([...values, ...nip05].flatMap(searchWords))];
  words.forEach((term) => add('word', term, false));
  words.forEach((word) => {
    const codepoints = [...word];
    const maximum = Math.min(codepoints.length - 1, MAX_PREFIX_CODEPOINTS);
    for (let length = 2; length <= maximum; length += 1) {
      add('prefix', codepoints.slice(0, length).join(''), false);
    }
  });
  words.forEach((word) => queryTrigrams(word).forEach((term) => add('trigram', term, false)));
  return terms;
}

export function queryTrigrams(value: string): string[] {
  const grams: string[] = [];
  for (const word of searchWords(value)) {
    const points = [...word];
    if (points.length < 3) {continue;}
    for (let index = 0; index <= points.length - 3; index += 1) {
      grams.push(points.slice(index, index + 3).join(''));
    }
  }
  return [...new Set(grams)];
}

export function searchWords(value: string): string[] {
  return value.split(' ').map((word) => word.trim()).filter(Boolean);
}

export function boundedPrefix(value: string): string {
  return [...value].slice(0, MAX_PREFIX_CODEPOINTS).join('');
}

export function normalizePosting(raw: ProfileSearchV3Posting): ProfileSearchV3Posting {
  if (!isRecord(raw)) {throw new Error('Invalid profile-search v3 posting');}
  return {
    mode: checkedMode(raw.mode),
    term: boundedTerm(raw.term, 'posting term'),
    rankHint: checkedRankHint(raw.rankHint),
    pubkey: strictPubkey(raw.pubkey, 'posting pubkey'),
  };
}

export function parsePostingKey(key: string): ProfileSearchV3Posting {
  const parts = key.split(SEPARATOR);
  if (parts.length !== 4 || parts[0]?.length !== 1 || !/^\d{16}$/.test(parts[2] ?? '')) {
    throw new Error(`Invalid profile-search v3 posting key: ${key}`);
  }
  const posting = normalizePosting({
    mode: codeMode(parts[0]!),
    term: parts[1]!,
    rankHint: Number(parts[2]),
    pubkey: parts[3]!,
  });
  if (profileSearchV3PostingKey(posting) !== key) {
    throw new Error(`Invalid profile-search v3 posting key: ${key}`);
  }
  return posting;
}

export function postingPrefix(mode: ProfileSearchV3PostingMode, term: string): string {
  return `${modeCode(mode)}${SEPARATOR}${boundedTerm(term, 'posting prefix')}${SEPARATOR}`;
}

function modeCode(mode: ProfileSearchV3PostingMode): string {
  return ({ identifier: 'a', nip05: 'b', identity: 'c', word: 'd', prefix: 'e', trigram: 'f' })[mode];
}

function codeMode(code: string): ProfileSearchV3PostingMode {
  const mode = ({ a: 'identifier', b: 'nip05', c: 'identity', d: 'word', e: 'prefix',
    f: 'trigram' } as const)[code as 'a'];
  if (!mode) {throw new Error('Invalid profile-search v3 posting mode code');}
  return mode;
}

function checkedMode(value: unknown): ProfileSearchV3PostingMode {
  if (value === 'identifier' || value === 'nip05' || value === 'identity'
    || value === 'word' || value === 'prefix' || value === 'trigram') {return value;}
  throw new Error('Invalid profile-search v3 posting mode');
}

export function compareMode(
  left: ProfileSearchV3PostingMode,
  right: ProfileSearchV3PostingMode,
): number {
  return compareText(modeCode(left), modeCode(right));
}

export function uniqueRoutes(
  routes: Array<{ mode: ProfileSearchV3PostingMode; term: string }>,
): Array<{ mode: ProfileSearchV3PostingMode; term: string }> {
  const seen = new Set<string>();
  return routes.filter((route) => {
    if (!route.term) {return false;}
    const key = `${route.mode}${SEPARATOR}${route.term}`;
    if (seen.has(key)) {return false;}
    seen.add(key);
    return true;
  });
}

export function branchManifest(
  summary: PostSearchV5PackedBranchSummary,
): ProfileSearchV3BranchManifest {
  return {
    pageKind: summary.pageKind as 'documents' | 'postings',
    entryCount: summary.entryCount,
    minKey: summary.minKey,
    maxKey: summary.maxKey,
    height: summary.height,
    pageCount: summary.pageCount,
    routerNodeCount: summary.routerNodeCount,
    reachableNodeCount: summary.reachableNodeCount,
  };
}

export function branchEntry(name: string, summary: PostSearchV5PackedBranchSummary): TreeEntry {
  return { name, cid: summary.root, size: summary.reachableNodeCount, type: LinkType.Dir };
}

export function parseManifest(bytes: Uint8Array): ProfileSearchV3RoutedRunManifest {
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {
    throw new Error('Invalid profile-search v3 run manifest JSON');
  }
  const raw = objectValue(value, 'run manifest');
  exactKeys(raw, [
    'format', 'packedPageFormat', 'pageRouterFormat', 'normalization', 'rankPolicy',
    'profileCount', 'postingCount', 'minimumRankHint', 'maximumRankHint', 'branches',
    'reachableNodeCount',
  ], 'run manifest');
  if (raw.format !== PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT
    || raw.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || raw.pageRouterFormat !== POST_SEARCH_V5_PAGE_ROUTER_FORMAT
    || raw.normalization !== PROFILE_SEARCH_V3_NORMALIZATION
    || raw.rankPolicy !== PROFILE_SEARCH_V3_RANK_POLICY) {
    throw new Error('Unsupported profile-search v3 run manifest');
  }
  const branchesValue = objectValue(raw.branches, 'branches');
  exactKeys(branchesValue, ['profiles', 'postings'], 'branches');
  const profiles = parseBranch(branchesValue.profiles, 'documents', 'profiles');
  const postings = parseBranch(branchesValue.postings, 'postings', 'postings');
  const manifest: ProfileSearchV3RoutedRunManifest = {
    format: PROFILE_SEARCH_V3_ROUTED_RUN_FORMAT,
    packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
    pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
    normalization: PROFILE_SEARCH_V3_NORMALIZATION,
    rankPolicy: PROFILE_SEARCH_V3_RANK_POLICY,
    profileCount: positiveInteger(raw.profileCount, 'profileCount'),
    postingCount: positiveInteger(raw.postingCount, 'postingCount'),
    minimumRankHint: checkedRankHint(raw.minimumRankHint),
    maximumRankHint: checkedRankHint(raw.maximumRankHint),
    branches: { profiles, postings },
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'reachableNodeCount'),
  };
  const expectedReachable = safeAdd(
    2,
    safeAdd(profiles.reachableNodeCount, postings.reachableNodeCount, 'branch reachability'),
    'run reachability',
  );
  if (manifest.minimumRankHint > manifest.maximumRankHint
    || profiles.entryCount !== manifest.profileCount
    || postings.entryCount !== manifest.postingCount
    || manifest.reachableNodeCount !== expectedReachable
    || manifest.reachableNodeCount > PROFILE_SEARCH_V3_MAX_REACHABLE_NODES
    || !equalBytes(bytes, encodeManifest(manifest))) {
    throw new Error('Inconsistent or noncanonical profile-search v3 run manifest');
  }
  return manifest;
}

function parseBranch(
  value: unknown,
  pageKind: 'documents' | 'postings',
  label: string,
): ProfileSearchV3BranchManifest {
  const raw = objectValue(value, `${label} branch`);
  exactKeys(raw, [
    'pageKind', 'entryCount', 'minKey', 'maxKey', 'height', 'pageCount',
    'routerNodeCount', 'reachableNodeCount',
  ], `${label} branch`);
  const branch: ProfileSearchV3BranchManifest = {
    pageKind,
    entryCount: positiveInteger(raw.entryCount, `${label} entryCount`),
    minKey: nonEmptyString(raw.minKey, `${label} minKey`),
    maxKey: nonEmptyString(raw.maxKey, `${label} maxKey`),
    height: nonNegativeInteger(raw.height, `${label} height`),
    pageCount: positiveInteger(raw.pageCount, `${label} pageCount`),
    routerNodeCount: positiveInteger(raw.routerNodeCount, `${label} routerNodeCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `${label} reachableNodeCount`),
  };
  if (raw.pageKind !== pageKind || compareText(branch.minKey, branch.maxKey) > 0
    || branch.reachableNodeCount !== branch.pageCount + branch.routerNodeCount) {
    throw new Error(`Inconsistent profile-search v3 ${label} branch`);
  }
  return branch;
}

export function encodeManifest(manifest: ProfileSearchV3RoutedRunManifest): Uint8Array {
  const bytes = encoder.encode(JSON.stringify(manifest));
  if (bytes.length === 0 || bytes.length > MANIFEST_MAX_BYTES) {
    throw new Error('Profile-search v3 run manifest exceeds its byte capacity');
  }
  return bytes;
}

export function boundBranchLink(
  links: readonly Link[],
  name: string,
  branch: ProfileSearchV3BranchManifest,
): CID {
  const link = links.find((candidate) => candidate.name === name);
  if (!link || link.type !== LinkType.Dir || link.size !== branch.reachableNodeCount) {
    throw new Error(`Profile-search v3 run ${name} link is inconsistent`);
  }
  return { hash: new Uint8Array(link.hash) };
}

export function assertExpected(
  manifest: ProfileSearchV3RoutedRunManifest,
  expected: ProfileSearchV3RoutedRunExpected,
): void {
  const values = {
    profileCount: manifest.profileCount,
    postingCount: manifest.postingCount,
    pageCount: manifest.branches.profiles.pageCount + manifest.branches.postings.pageCount,
    reachableNodeCount: manifest.reachableNodeCount,
  };
  for (const key of Object.keys(values) as Array<keyof typeof values>) {
    if (expected[key] !== undefined && expected[key] !== values[key]) {
      throw new Error(`Profile-search v3 run expected ${key} does not match`);
    }
  }
}

export function validateEligibleRanks(ranks: ReadonlyMap<string, number>): void {
  if (!(ranks instanceof Map)) {throw new Error('Profile-search v3 eligible ranks must be a map');}
  for (const [pubkey, rank] of ranks) {
    strictPubkey(pubkey, 'eligible pubkey');
    checkedRankHint(rank);
  }
}

export function checkedRankHint(value: unknown): number {
  return boundedInteger(value, 0, MAX_RANK_HINT, 'rank hint');
}

export function strictPubkey(value: unknown, label: string): string {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function boundedTerm(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.includes(SEPARATOR)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  if (encoder.encode(value).byteLength > MAX_TERM_BYTES) {
    throw new Error(`Profile-search v3 ${label} exceeds capacity`);
  }
  return value;
}

function normalizeTags(value: unknown): string[][] {
  if (!Array.isArray(value) || value.length > MAX_EVENT_TAGS) {
    throw new Error('Invalid or over-capacity profile-search v3 event tags');
  }
  let byteLength = 0;
  return value.map((tag) => {
    if (!Array.isArray(tag) || tag.length > MAX_EVENT_TAG_ITEMS) {
      throw new Error('Invalid profile-search v3 event tag');
    }
    return tag.map((item) => {
      if (typeof item !== 'string') {throw new Error('Invalid profile-search v3 event tag');}
      const itemBytes = encoder.encode(item).byteLength;
      if (itemBytes > MAX_EVENT_TAG_ITEM_BYTES) {
        throw new Error('Profile-search v3 event tag item exceeds capacity');
      }
      byteLength = safeAdd(byteLength, itemBytes, 'event tag bytes');
      if (byteLength > MAX_EVENT_TAG_BYTES) {
        throw new Error('Profile-search v3 event tags exceed capacity');
      }
      return item;
    });
  });
}

function strictHex(value: unknown, length: number, label: string): string {
  if (typeof value !== 'string' || value.length !== length || !/^[0-9a-f]+$/.test(value)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

function boundedStringBytes(value: unknown, maximum: number, label: string): string {
  const normalized = nonEmptyString(value, label);
  if (encoder.encode(normalized).byteLength > maximum) {
    throw new Error(`Profile-search v3 ${label} exceeds capacity`);
  }
  return normalized;
}

export async function readPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  const cid = publicCid(root, label);
  const bytes = await store.get(cid.hash);
  if (!bytes) {throw new Error(`Missing profile-search v3 ${label} block`);}
  if (bytes.length > maximum) {throw new Error(`Profile-search v3 ${label} exceeds its byte bound`);}
  const actual = await sha256(bytes);
  if (!equalBytes(actual, cid.hash)) {throw new Error(`Profile-search v3 ${label} hash mismatch`);}
  return bytes;
}

export function publicCid(value: unknown, label: string): CID {
  if (!isRecord(value) || !(value.hash instanceof Uint8Array) || value.hash.length !== 32) {
    throw new Error(`Invalid profile-search v3 ${label} CID`);
  }
  if (value.key !== undefined) {throw new Error(`Encrypted profile-search v3 ${label} CIDs are unsupported`);}
  return { hash: new Uint8Array(value.hash) };
}

export function assertCanonicalLink(link: Link): void {
  if (!(link.hash instanceof Uint8Array) || link.hash.length !== 32 || link.key !== undefined
    || typeof link.name !== 'string' || !link.name || !Number.isSafeInteger(link.size)
    || link.size < 0 || link.meta !== undefined) {
    throw new Error('Profile-search v3 run contains an invalid or encrypted link');
  }
}

export function assertExactLinkNames(links: readonly Link[], expected: readonly string[]): void {
  const names = links.map((link) => link.name!).sort(compareText);
  const wanted = [...expected].sort(compareText);
  if (!sameStrings(names, wanted)) {
    throw new Error('Profile-search v3 run has missing or unbound root links');
  }
}

function exactKeys(value: Record<string, unknown>, expected: readonly string[], label: string): void {
  const keys = Object.keys(value).sort(compareText);
  const wanted = [...expected].sort(compareText);
  if (!sameStrings(keys, wanted)) {throw new Error(`Invalid profile-search v3 ${label} fields`);}
}

function objectValue(value: unknown, label: string): Record<string, unknown> {
  if (!isRecord(value)) {throw new Error(`Invalid profile-search v3 ${label}`);}
  return value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function nonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

function nonNegativeInteger(value: unknown, label: string): number {
  return boundedInteger(value, 0, Number.MAX_SAFE_INTEGER, label);
}

export function positiveInteger(value: unknown, label: string): number {
  return boundedInteger(value, 1, Number.MAX_SAFE_INTEGER, label);
}

export function boundedInteger(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (!Number.isSafeInteger(value) || (value as number) < minimum || (value as number) > maximum) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value as number;
}

export function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {throw new Error(`Profile-search v3 ${label} exceeds capacity`);}
  return result;
}

function sameStrings(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

export function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {return false;}
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
