export interface PostSearchBuilderProgress {
  phase: 'scanning-deletions' | 'selecting-winners' | 'building-segments' | 'idle' | 'complete';
  currentKind: number | null;
  scanned: number;
  accepted: number;
  persisted: number;
  updatedAt: number;
}

export function createPostSearchBuilderProgress(
  phase: PostSearchBuilderProgress['phase'],
  currentKind: number | null,
  scanned: number,
  accepted: number,
  persisted: number,
  updatedAt: number,
): PostSearchBuilderProgress {
  return { phase, currentKind, scanned, accepted, persisted, updatedAt };
}

export function isPostSearchBuilderProgress(value: unknown): value is PostSearchBuilderProgress {
  return isObject(value)
    && ['scanning-deletions', 'selecting-winners', 'building-segments', 'idle', 'complete']
      .includes(String(value.phase))
    && (value.currentKind === null || isNonNegativeInteger(value.currentKind))
    && isNonNegativeInteger(value.scanned)
    && isNonNegativeInteger(value.accepted)
    && isNonNegativeInteger(value.persisted)
    && isNonNegativeInteger(value.updatedAt);
}

function isNonNegativeInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
