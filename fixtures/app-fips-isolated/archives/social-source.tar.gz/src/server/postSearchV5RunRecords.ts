import type { RankedSearchDocument, RankedTermStats } from '@hashtree/index';
import {
  POST_SEARCH_V5_MAX_TOKENS_PER_FIELD,
  POST_SEARCH_V5_PAGE_NAME,
  POST_SEARCH_V5_POSTING_PART_SEPARATOR,
  type PostSearchV5Posting,
  type PostSearchV5RecordManifest,
  type PostSearchV5StoredDocument,
  type PostSearchV5TermStats,
} from './postSearchV5RunTypes';
import {
  assertPostSearchV5ExactKeys,
  comparePostSearchV5Strings,
  parsePostSearchV5JsonObject,
  postSearchV5Integer,
  postSearchV5Object,
  postSearchV5PositiveInteger,
} from './postSearchV5RunValidation';

const TOKEN_PATTERN = /#([\p{L}\p{N}\p{M}_]+)|[\p{L}\p{N}][\p{L}\p{N}\p{M}]*(?:['’][\p{L}\p{N}\p{M}]+)*/gu;

/** Exact token/position projection shared by fixed and routed v5 run builders. */
export function tokenizePostSearchV5Field(
  value: RankedSearchDocument['fields'][string],
  maximum: number,
): { length: number; occurrences: Array<{ term: string; position: number }> } {
  const limit = postSearchV5PositiveInteger(maximum, 'maxTokensPerField');
  if (limit > POST_SEARCH_V5_MAX_TOKENS_PER_FIELD) {
    throw new Error(`Post-search v5 maxTokensPerField exceeds ${POST_SEARCH_V5_MAX_TOKENS_PER_FIELD}`);
  }
  const values = value === undefined ? [] : typeof value === 'string' ? [value] : value;
  if (!Array.isArray(values) || values.some((item) => typeof item !== 'string')) {
    throw new Error('Post-search v5 field values must be strings or string arrays');
  }
  const occurrences: Array<{ term: string; position: number }> = [];
  let length = 0;
  let position = 0;
  for (const raw of values) {
    TOKEN_PATTERN.lastIndex = 0;
    const normalized = raw.normalize('NFKC').toLowerCase().replace(/’/g, "'");
    for (const match of normalized.matchAll(TOKEN_PATTERN)) {
      if (length >= limit) {
        return { length, occurrences };
      }
      const hashtag = match[1] !== undefined;
      const term = hashtag ? match[1] : match[0];
      if (term) {
        occurrences.push({ term, position });
        if (hashtag) {
          occurrences.push({ term: `#${term}`, position });
        }
        length += 1;
        position += 1;
      }
    }
  }
  return { length, occurrences };
}

export function parsePostSearchV5StoredDocument(
  id: string,
  raw: string,
  manifest: PostSearchV5RecordManifest,
): PostSearchV5StoredDocument {
  const value = parsePostSearchV5JsonObject(raw, `document ${id}`);
  assertPostSearchV5ExactKeys(
    value,
    value.value === undefined ? ['lengths'] : ['lengths', 'value'],
    `document ${id}`,
  );
  const rawLengths = postSearchV5Object(value.lengths, `document ${id} lengths`);
  assertPostSearchV5ExactKeys(
    rawLengths,
    manifest.fields.map((field) => field.name),
    `document ${id} lengths`,
  );
  const lengths: Record<string, number> = Object.create(null) as Record<string, number>;
  for (const field of manifest.fields) {
    const length = postSearchV5Integer(rawLengths[field.name], `document ${id} length`);
    if (length > manifest.maxTokensPerField) {
      throw new Error(`Invalid post-search v5 document length: ${id}`);
    }
    lengths[field.name] = length;
  }
  if (value.value !== undefined && typeof value.value !== 'string') {
    throw new Error(`Invalid post-search v5 document value: ${id}`);
  }
  return value.value === undefined ? { lengths } : { lengths, value: value.value };
}

export function parsePostSearchV5Posting(
  raw: unknown,
  label: string,
  manifest: PostSearchV5RecordManifest,
  documents?: ReadonlyMap<string, PostSearchV5StoredDocument>,
): PostSearchV5Posting {
  const value = postSearchV5Object(raw, label);
  assertPostSearchV5ExactKeys(value, ['fields', 'id'], label);
  if (typeof value.id !== 'string' || value.id.length === 0
    || (documents && !documents.has(value.id))) {
    throw new Error(`Invalid post-search v5 posting document: ${label}`);
  }
  const rawFields = postSearchV5Object(value.fields, `${label} fields`);
  const fields: PostSearchV5Posting['fields'] = Object.create(null) as PostSearchV5Posting['fields'];
  const knownFields = new Set(manifest.fields.map((field) => field.name));
  for (const fieldName of Object.keys(rawFields)) {
    if (!knownFields.has(fieldName)) {
      throw new Error(`Unknown post-search v5 posting field: ${fieldName}`);
    }
    const field = postSearchV5Object(rawFields[fieldName], `${label} field ${fieldName}`);
    assertPostSearchV5ExactKeys(field, ['frequency', 'positions'], `${label} field ${fieldName}`);
    const frequency = postSearchV5PositiveInteger(field.frequency, `${label} frequency`);
    if (!Array.isArray(field.positions)) {
      throw new Error(`Invalid post-search v5 posting positions: ${label}`);
    }
    const positions = field.positions.map((position) =>
      postSearchV5Integer(position, `${label} position`));
    if (positions.length !== frequency || positions.some((position, index) =>
      position >= manifest.maxTokensPerField
      || index > 0 && position <= positions[index - 1]!)) {
      throw new Error(`Invalid post-search v5 posting positions: ${label}`);
    }
    const document = documents?.get(value.id);
    if (document && positions.some((position) => position >= document.lengths[fieldName]!)) {
      throw new Error(`Out-of-range post-search v5 posting position: ${label}`);
    }
    fields[fieldName] = { frequency, positions };
  }
  if (Object.keys(fields).length === 0) {
    throw new Error(`Empty post-search v5 posting fields: ${label}`);
  }
  return { id: value.id, fields };
}

export function parsePostSearchV5TermStats(
  raw: string,
  term: string,
  manifest: PostSearchV5RecordManifest,
): PostSearchV5TermStats {
  const value = parsePostSearchV5JsonObject(raw, `term ${term}`);
  assertPostSearchV5ExactKeys(
    value,
    ['documentFrequency', 'fieldSets', 'postingParts'],
    `term ${term}`,
  );
  const documentFrequency = postSearchV5PositiveInteger(
    value.documentFrequency,
    `term ${term} frequency`,
  );
  const fieldSets = parseFieldSets(value.fieldSets, term, manifest);
  const fieldSetFrequency = fieldSets.reduce((sum, fieldSet) => {
    const result = sum + fieldSet.documentFrequency;
    if (!Number.isSafeInteger(result)) {
      throw new Error(`Post-search v5 field set frequency exceeds capacity: ${term}`);
    }
    return result;
  }, 0);
  if (fieldSetFrequency !== documentFrequency) {
    throw new Error(`Post-search v5 field set frequency mismatch: ${term}`);
  }
  return {
    documentFrequency,
    fieldSets,
    postingParts: postSearchV5PositiveInteger(value.postingParts, `term ${term} postingParts`),
  };
}

function parseFieldSets(
  raw: unknown,
  term: string,
  manifest: PostSearchV5RecordManifest,
): RankedTermStats['fieldSets'] {
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new Error(`Invalid post-search v5 field sets: ${term}`);
  }
  const knownFields = new Set(manifest.fields.map((field) => field.name));
  const parsed = raw.map((item, index) => {
    const value = postSearchV5Object(item, `term ${term} fieldSets[${index}]`);
    assertPostSearchV5ExactKeys(
      value,
      ['documentFrequency', 'fields'],
      `term ${term} fieldSets[${index}]`,
    );
    if (!Array.isArray(value.fields) || value.fields.length === 0
      || value.fields.some((field) => typeof field !== 'string' || !knownFields.has(field))) {
      throw new Error(`Invalid post-search v5 field set fields: ${term}`);
    }
    const fields = value.fields as string[];
    if (new Set(fields).size !== fields.length
      || fields.some((field, fieldIndex) =>
        fieldIndex > 0 && field <= fields[fieldIndex - 1]!)) {
      throw new Error(`Non-canonical post-search v5 field set: ${term}`);
    }
    return {
      fields,
      documentFrequency: postSearchV5PositiveInteger(
        value.documentFrequency,
        `term ${term} field set frequency`,
      ),
    };
  });
  const keys = parsed.map((fieldSet) => JSON.stringify(fieldSet.fields));
  if (new Set(keys).size !== keys.length
    || keys.some((key, index) => index > 0 && key <= keys[index - 1]!)) {
    throw new Error(`Non-canonical post-search v5 field sets: ${term}`);
  }
  return parsed;
}

export function postSearchV5TermStatistics(
  postings: readonly PostSearchV5Posting[],
): RankedTermStats {
  const fieldSets = new Map<string, { fields: string[]; documentFrequency: number }>();
  for (const posting of postings) {
    const fields = Object.keys(posting.fields).sort(comparePostSearchV5Strings);
    const key = JSON.stringify(fields);
    const stats = fieldSets.get(key) ?? { fields, documentFrequency: 0 };
    stats.documentFrequency += 1;
    fieldSets.set(key, stats);
  }
  return {
    documentFrequency: postings.length,
    fieldSets: [...fieldSets.values()].sort((left, right) =>
      comparePostSearchV5Strings(JSON.stringify(left.fields), JSON.stringify(right.fields))),
  };
}

export function postSearchV5PostingTerm(key: string): string {
  return parsePostSearchV5PostingKey(key).term;
}

export function parsePostSearchV5PostingKey(key: string): { term: string; part: number } {
  const separator = key.lastIndexOf(POST_SEARCH_V5_POSTING_PART_SEPARATOR);
  const term = key.slice(0, separator);
  const rawPart = key.slice(separator + 1);
  if (!term || separator < 0 || !POST_SEARCH_V5_PAGE_NAME.test(rawPart)) {
    throw new Error('Invalid post-search v5 posting key');
  }
  return { term, part: Number(rawPart) };
}
