import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from '../lib/nostr';
import type { ReferencedEventClosureReference } from './referencedEventClosureTypes';

const HEX_64 = /^[0-9a-f]{64}$/;
export const REFERENCED_EVENT_CLOSURE_SOURCE_KINDS = Object.freeze([
  1, 6, 7, 16, 20, 1_111, 9_735, 30_023,
]);
const REFERENCE_TAG_NAMES = new Set(['e', 'E', 'q', 'a', 'A']);

/** Extract signed event/address references. A p tag is deliberately never inspected. */
export function extractReferencedEventClosureReferences(
  event: RawEvent,
  depth: number,
): ReferencedEventClosureReference[] {
  const result: ReferencedEventClosureReference[] = [];
  const seen = new Set<string>();
  if (!REFERENCED_EVENT_CLOSURE_SOURCE_KINDS.includes(event.kind)) {
    return result;
  }
  for (const tag of event.tags) {
    const name = tag[0] ?? '';
    if (!REFERENCE_TAG_NAMES.has(name)) {
      continue;
    }
    const value = tag[1] ?? '';
    const normalizedName = name.toLowerCase();
    const reference = normalizedName === 'a'
      ? coordinateReference(value, depth)
      : idReference(value.trim(), depth)
        ?? (normalizedName === 'q' ? coordinateReference(value, depth) : null);
    if (!reference) {
      continue;
    }
    const key = closureReferenceKey(reference);
    if (!seen.has(key)) {
      seen.add(key);
      result.push(reference);
    }
  }
  return result;
}

/** A kind-6 JSON target is accepted only when signed and named by an e tag. */
export function getVerifiedKind6ClosureTarget(wrapper: RawEvent): RawEvent | null {
  if (wrapper.kind !== 6 || !wrapper.content.trim()) {
    return null;
  }
  let event: RawEvent;
  try {
    event = normalizeClosureEvent(JSON.parse(wrapper.content));
  } catch {
    return null;
  }
  if (!verifyClosureEvent(event)) {
    return null;
  }
  const namedTarget = wrapper.tags.find((tag) => (
    tag[0] === 'e' && HEX_64.test(tag[1] ?? '')
  ))?.[1];
  return namedTarget === event.id ? event : null;
}

export function retainIndexableClosureBatch(
  candidates: Array<{ event: RawEvent; depth: number }>,
): Array<{ event: RawEvent; depth: number }> {
  const exact = new Map<string, { event: RawEvent; depth: number }>();
  const current = new Map<string, { event: RawEvent; depth: number }>();
  for (const candidate of candidates) {
    if (exact.has(candidate.event.id)) {
      continue;
    }
    exact.set(candidate.event.id, candidate);
    const coordinate = closureCurrentStateCoordinate(candidate.event);
    if (!coordinate) {
      continue;
    }
    const existing = current.get(coordinate);
    if (!existing || newerClosureCurrentState(candidate.event, existing.event)) {
      current.set(coordinate, candidate);
    }
  }
  const winners = new Set([...current.values()].map(({ event }) => event.id));
  return [...exact.values()].filter(({ event }) => {
    const coordinate = closureCurrentStateCoordinate(event);
    return coordinate === null || winners.has(event.id);
  });
}

export function matchingClosureReferenceKeys(
  references: readonly ReferencedEventClosureReference[],
  events: readonly RawEvent[],
): Set<string> {
  const result = new Set<string>();
  for (const reference of references) {
    if (events.some((event) => verifyClosureEvent(event) && closureReferenceMatchesEvent(reference, event))) {
      result.add(closureReferenceKey(reference));
    }
  }
  return result;
}

export function closureReferenceMatchesEvent(
  reference: ReferencedEventClosureReference,
  event: RawEvent,
): boolean {
  return reference.type === 'id'
    ? event.id === reference.value
    : closureCurrentStateCoordinate(event) === reference.value;
}

export function closureCurrentStateCoordinate(event: RawEvent): string | null {
  if (event.kind === 0 || event.kind === 3 || (event.kind >= 10_000 && event.kind < 20_000)) {
    return `${event.kind}:${event.pubkey}:`;
  }
  if (event.kind < 30_000 || event.kind >= 40_000) {
    return null;
  }
  const identifier = event.tags.find((tag) => tag[0] === 'd')?.[1];
  if (identifier === undefined) {
    return null;
  }
  return `${event.kind}:${event.pubkey}:${identifier}`;
}

export function newestClosureEvent(events: readonly RawEvent[]): RawEvent | undefined {
  return [...events].sort((left, right) => (
    right.created_at - left.created_at || left.id.localeCompare(right.id)
  ))[0];
}

export function normalizeClosureEvent(value: unknown): RawEvent {
  if (!value || typeof value !== 'object') {
    throw new Error('invalid event');
  }
  const event = value as Partial<RawEvent>;
  if (
    typeof event.id !== 'string'
    || !HEX_64.test(event.id.toLowerCase())
    || typeof event.pubkey !== 'string'
    || !HEX_64.test(event.pubkey.toLowerCase())
    || !Number.isSafeInteger(event.created_at)
    || Number(event.created_at) < 0
    || !Number.isSafeInteger(event.kind)
    || Number(event.kind) < 0
    || !Array.isArray(event.tags)
    || event.tags.some((tag) => !Array.isArray(tag) || tag.some((part) => typeof part !== 'string'))
    || typeof event.content !== 'string'
    || typeof event.sig !== 'string'
  ) {
    throw new Error('invalid event');
  }
  return {
    id: event.id.toLowerCase(),
    pubkey: event.pubkey.toLowerCase(),
    created_at: Number(event.created_at),
    kind: Number(event.kind),
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

export function verifyClosureEvent(event: RawEvent): boolean {
  try {
    return verifyEvent({ ...event, tags: event.tags.map((tag) => [...tag]) });
  } catch {
    return false;
  }
}

export function parseClosureReference(value: unknown): ReferencedEventClosureReference {
  if (!value || typeof value !== 'object') {
    throw new Error('Invalid referenced-event closure reference');
  }
  const candidate = value as Partial<ReferencedEventClosureReference>;
  const reference = candidate.type === 'id'
    ? idReference(candidate.value ?? '', candidate.depth ?? -1)
    : candidate.type === 'coordinate'
      ? coordinateReference(candidate.value ?? '', candidate.depth ?? -1)
      : null;
  if (!reference) {
    throw new Error('Invalid referenced-event closure reference');
  }
  return reference;
}

export function closureReferenceKey(
  reference: Pick<ReferencedEventClosureReference, 'type' | 'value'>,
): string {
  return `${reference.type}:${reference.value}`;
}

function idReference(value: string, depth: number): ReferencedEventClosureReference | null {
  const normalized = value.toLowerCase();
  return HEX_64.test(normalized) && Number.isSafeInteger(depth) && depth > 0
    ? { type: 'id', value: normalized, depth }
    : null;
}

function coordinateReference(
  value: string,
  depth: number,
): ReferencedEventClosureReference | null {
  const first = value.indexOf(':');
  const second = value.indexOf(':', first + 1);
  if (first <= 0 || second <= first + 1 || !Number.isSafeInteger(depth) || depth <= 0) {
    return null;
  }
  const kindText = value.slice(0, first);
  const kind = Number(kindText);
  const pubkey = value.slice(first + 1, second).toLowerCase();
  const identifier = value.slice(second + 1);
  if (
    !/^\d+$/.test(kindText)
    || !Number.isSafeInteger(kind)
    || kind < 30_000
    || kind >= 40_000
    || !HEX_64.test(pubkey)
    || Buffer.byteLength(identifier) > 1024
  ) {
    return null;
  }
  return { type: 'coordinate', value: `${kind}:${pubkey}:${identifier}`, depth };
}

function newerClosureCurrentState(candidate: RawEvent, existing: RawEvent): boolean {
  return candidate.created_at > existing.created_at
    || (candidate.created_at === existing.created_at && candidate.id < existing.id);
}
