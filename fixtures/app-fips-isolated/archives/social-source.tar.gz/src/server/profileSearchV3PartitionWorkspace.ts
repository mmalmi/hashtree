import { createReadStream } from 'node:fs';
import { appendFile, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import type { RawEvent } from '../lib/nostr';
import {
  profileSearchV3PostingKey,
  type ProfileSearchV3Posting,
} from './profileSearchV3RoutedRun';

interface StagedPosting {
  key: string;
  posting: ProfileSearchV3Posting;
}

export class ProfilePartitionWorkspace {
  private readonly profileBuffers = new Map<string, string[]>();
  private readonly profileBufferBytes = new Map<string, number>();
  private readonly profileCounts = new Map<string, number>();
  private readonly postingBuffer: Array<{ nibble: string; value: StagedPosting }> = [];
  private readonly postingChunks = new Map<string, string[]>();
  private chunkSequence = 0;

  constructor(
    private readonly directory: string,
    private readonly limits: {
      profileBufferEntries: number;
      profileBufferBytes: number;
      postingBufferEntries: number;
      mergeFanIn: number;
    },
  ) {}

  async reset(): Promise<void> {
    await rm(this.directory, { recursive: true, force: true });
    await mkdir(this.directory, { recursive: true, mode: 0o700 });
  }

  async cleanup(): Promise<void> {
    await rm(this.directory, { recursive: true, force: true });
  }

  profileCount(nibble: string): number {
    return this.profileCounts.get(nibble) ?? 0;
  }

  async appendProfile(nibble: string, event: RawEvent): Promise<void> {
    const buffer = this.profileBuffers.get(nibble) ?? [];
    const serialized = JSON.stringify(event);
    buffer.push(serialized);
    this.profileBuffers.set(nibble, buffer);
    const bufferedBytes = (this.profileBufferBytes.get(nibble) ?? 0)
      + Buffer.byteLength(serialized) + 1;
    this.profileBufferBytes.set(nibble, bufferedBytes);
    this.profileCounts.set(nibble, (this.profileCounts.get(nibble) ?? 0) + 1);
    if (buffer.length >= this.limits.profileBufferEntries
      || bufferedBytes >= this.limits.profileBufferBytes) {
      await this.flushProfiles(nibble);
    }
  }

  async appendPosting(nibble: string, posting: ProfileSearchV3Posting): Promise<void> {
    this.postingBuffer.push({
      nibble,
      value: { key: profileSearchV3PostingKey(posting), posting },
    });
    if (this.postingBuffer.length >= this.limits.postingBufferEntries) {
      await this.flushPostingChunk();
    }
  }

  async finishStaging(): Promise<void> {
    for (const nibble of this.profileBuffers.keys()) {await this.flushProfiles(nibble);}
    await this.flushPostingChunk();
  }

  async *streamProfiles(nibble: string): AsyncGenerator<RawEvent> {
    if (this.profileCount(nibble) === 0) {return;}
    for await (const line of lines(this.profilePath(nibble))) {
      yield JSON.parse(line) as RawEvent;
    }
  }

  async *streamSortedPostings(nibble: string): AsyncGenerator<ProfileSearchV3Posting> {
    let paths = this.postingChunks.get(nibble) ?? [];
    let round = 0;
    while (paths.length > this.limits.mergeFanIn) {
      const next: string[] = [];
      for (let offset = 0; offset < paths.length; offset += this.limits.mergeFanIn) {
        const group = paths.slice(offset, offset + this.limits.mergeFanIn);
        const target = join(this.directory, `posting-${nibble}-merge-${round}-${next.length}.jsonl`);
        let output = '';
        const flush = async () => {
          if (!output) {return;}
          await appendFile(target, output, { encoding: 'utf8', mode: 0o600 });
          output = '';
        };
        for await (const posting of iterateMergedPostingFiles(group)) {
          output += `${JSON.stringify([posting.key, posting.posting])}\n`;
          if (output.length >= 256 * 1_024) {await flush();}
        }
        await flush();
        await Promise.all(group.map(async (path) => await rm(path, { force: true })));
        next.push(target);
      }
      paths = next;
      round += 1;
    }
    let previous = '';
    for await (const value of iterateMergedPostingFiles(paths)) {
      if (value.key <= previous) {
        throw new Error('Profile-search v3 external posting sort is not strictly unique');
      }
      previous = value.key;
      yield value.posting;
    }
  }

  private async flushProfiles(nibble: string): Promise<void> {
    const buffer = this.profileBuffers.get(nibble);
    if (!buffer?.length) {return;}
    await appendFile(this.profilePath(nibble), `${buffer.join('\n')}\n`, {
      encoding: 'utf8', mode: 0o600,
    });
    buffer.length = 0;
    this.profileBufferBytes.set(nibble, 0);
  }

  private async flushPostingChunk(): Promise<void> {
    if (this.postingBuffer.length === 0) {return;}
    const groups = new Map<string, StagedPosting[]>();
    for (const { nibble, value } of this.postingBuffer) {
      const group = groups.get(nibble) ?? [];
      group.push(value);
      groups.set(nibble, group);
    }
    this.postingBuffer.length = 0;
    for (const [nibble, group] of groups) {
      group.sort((left, right) => compareText(left.key, right.key));
      const path = join(
        this.directory,
        `posting-${nibble}-chunk-${this.chunkSequence.toString().padStart(8, '0')}.jsonl`,
      );
      this.chunkSequence += 1;
      await writeFile(path, `${group.map((value) => JSON.stringify([
        value.key,
        value.posting,
      ])).join('\n')}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
      const chunks = this.postingChunks.get(nibble) ?? [];
      chunks.push(path);
      this.postingChunks.set(nibble, chunks);
    }
  }

  private profilePath(nibble: string): string {
    return join(this.directory, `profiles-${nibble}.jsonl`);
  }
}

async function* iterateMergedPostingFiles(
  paths: readonly string[],
): AsyncGenerator<StagedPosting> {
  if (paths.length === 0) {return;}
  const sources = paths.map((path) => createReadStream(path, { encoding: 'utf8' }));
  const readers = sources.map((source) => createInterface({ input: source, crlfDelay: Infinity }));
  const iterators = readers.map((reader) => reader[Symbol.asyncIterator]());
  try {
    const heads = await Promise.all(iterators.map(async (iterator) => await iterator.next()));
    while (true) {
      let selected = -1;
      let selectedValue: StagedPosting | null = null;
      for (let index = 0; index < heads.length; index += 1) {
        if (heads[index]!.done) {continue;}
        const line = heads[index]!.value;
        if (typeof line !== 'string') {
          throw new Error('Invalid staged profile-search posting line');
        }
        const value = parseStagedPosting(line);
        if (!selectedValue || value.key < selectedValue.key) {
          selected = index;
          selectedValue = value;
        }
      }
      if (selected < 0 || !selectedValue) {break;}
      yield selectedValue;
      heads[selected] = await iterators[selected]!.next();
    }
  } finally {
    readers.forEach((reader) => reader.close());
    sources.forEach((source) => source.destroy());
  }
}

function parseStagedPosting(line: string): StagedPosting {
  let parsed: unknown;
  try {parsed = JSON.parse(line);} catch {throw new Error('Invalid staged profile-search posting');}
  if (!Array.isArray(parsed) || parsed.length !== 2 || typeof parsed[0] !== 'string') {
    throw new Error('Invalid staged profile-search posting');
  }
  const posting = parsed[1] as ProfileSearchV3Posting;
  if (profileSearchV3PostingKey(posting) !== parsed[0]) {
    throw new Error('Staged profile-search posting key mismatch');
  }
  return { key: parsed[0], posting };
}

async function* lines(path: string): AsyncGenerator<string> {
  const source = createReadStream(path, { encoding: 'utf8' });
  const reader = createInterface({ input: source, crlfDelay: Infinity });
  try {
    for await (const line of reader) {
      if (line) {yield line;}
    }
  } finally {
    reader.close();
    source.destroy();
  }
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
