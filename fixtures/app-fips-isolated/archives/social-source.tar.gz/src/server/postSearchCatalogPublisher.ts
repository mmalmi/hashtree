import { nhashDecode, nhashEncode, toHex, type CID } from '@hashtree/core';
import { parseHashtreeRootEvent } from '@hashtree/nostr';
import * as nip19 from 'nostr-tools/nip19';
import { finalizeEvent, getPublicKey, verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from '../lib/nostr';
import type { HttpBlockStoreCredentials } from './httpBlockStore';
import {
  loopbackHashtreeDaemonUrl,
  pinHashtreeTree,
  publishSignedNostrEventToHashtree,
} from './hashtreeDaemonPublication';
import {
  POST_SEARCH_POINTER_HANDOFF_FORMAT,
  createPostSearchPointerTemplate,
  type PostSearchPointerHandoff,
} from './postSearchCatalogBuilder';

const HEX_64 = /^[0-9a-f]{64}$/;

export interface PostSearchPinResult {
  indexedHashes: number;
  totalSize: number;
  alreadyPinned: boolean;
}

export async function pinAndPublishPostSearchCatalog(
  event: RawEvent,
  catalogRoot: string,
  daemonUrl: string,
  credentials: HttpBlockStoreCredentials,
  options: {
    fetch?: typeof fetch;
    pinTimeoutMs?: number;
    publishTimeoutMs?: number;
  } = {},
): Promise<PostSearchPinResult> {
  assertEventPointsToCatalog(event, catalogRoot);
  const pin = await pinPostSearchCatalog(catalogRoot, daemonUrl, credentials, {
    fetch: options.fetch,
    timeoutMs: options.pinTimeoutMs,
  });
  await publishSignedPostSearchEvent(event, daemonUrl, {
    fetch: options.fetch,
    timeoutMs: options.publishTimeoutMs,
  });
  return pin;
}

function assertEventPointsToCatalog(event: RawEvent, catalogRoot: string): void {
  let expectedRoot: CID;
  try {
    expectedRoot = nhashDecode(catalogRoot);
  } catch {
    throw new Error('Invalid post-search catalog root');
  }
  const parsedRoot = verifyEvent(event) ? parseHashtreeRootEvent(event) : null;
  if (
    !parsedRoot
    || toHex(parsedRoot.rootCid.hash) !== toHex(expectedRoot.hash)
    || toHex(parsedRoot.rootCid.key ?? new Uint8Array()) !== toHex(expectedRoot.key ?? new Uint8Array())
  ) {
    throw new Error('Post-search pointer event does not match the catalog root');
  }
}

export function signPostSearchHandoff(
  value: unknown,
  encodedSecretKey: string,
): { handoff: PostSearchPointerHandoff; event: RawEvent } {
  const handoff = parsePostSearchHandoff(value);
  const secretKey = decodeNsec(encodedSecretKey);
  if (getPublicKey(secretKey) !== handoff.publisherId) {
    throw new Error('Post-search identity key does not match the handoff publisher');
  }

  const expectedTemplate = createPostSearchPointerTemplate({
    catalogRoot: nhashDecode(handoff.catalogRoot),
    sourceEventRoot: handoff.sourceEventRoot,
    treeName: handoff.treeName,
    createdAt: handoff.unsignedEvent.created_at,
  });
  if (JSON.stringify(handoff.unsignedEvent) !== JSON.stringify(expectedTemplate)) {
    throw new Error('Post-search handoff unsigned event does not match its catalog metadata');
  }

  let event: RawEvent;
  try {
    event = finalizeEvent(expectedTemplate, secretKey);
  } finally {
    secretKey.fill(0);
  }
  const parsedRoot = parseHashtreeRootEvent(event);
  const expectedRoot = nhashDecode(handoff.catalogRoot);
  if (
    !verifyEvent(event)
    || event.pubkey !== handoff.publisherId
    || !parsedRoot
    || parsedRoot.treeName !== handoff.treeName
    || toHex(parsedRoot.rootCid.hash) !== toHex(expectedRoot.hash)
    || toHex(parsedRoot.rootCid.key ?? new Uint8Array()) !== toHex(expectedRoot.key ?? new Uint8Array())
  ) {
    throw new Error('Unable to create a valid post-search pointer event');
  }
  return { handoff, event };
}

export async function publishSignedPostSearchEvent(
  event: RawEvent,
  daemonUrl: string,
  options: {
    fetch?: typeof fetch;
    timeoutMs?: number;
  } = {},
): Promise<void> {
  await publishSignedNostrEventToHashtree(event, daemonUrl, {
    ...options,
    label: 'post-search pointer',
    acknowledgementLabel: 'post-search',
  });
}

/**
 * Atomically validate, index, and retain the complete catalog DAG before its
 * signed pointer can be announced. The daemon endpoint is deliberately both
 * loopback-only and strictly authenticated.
 */
export async function pinPostSearchCatalog(
  catalogRoot: string,
  daemonUrl: string,
  credentials: HttpBlockStoreCredentials,
  options: {
    fetch?: typeof fetch;
    timeoutMs?: number;
  } = {},
): Promise<PostSearchPinResult> {
  return await pinHashtreeTree(catalogRoot, daemonUrl, credentials, {
    ...options,
    label: 'post-search catalog',
    acknowledgementLabel: 'post-search',
  });
}

export function parsePostSearchHandoff(value: unknown): PostSearchPointerHandoff {
  if (typeof value !== 'object' || value === null) {
    throw new Error('Invalid post-search pointer handoff');
  }
  const handoff = value as PostSearchPointerHandoff;
  if (
    handoff.format !== POST_SEARCH_POINTER_HANDOFF_FORMAT
    || (handoff.status !== 'unsigned-handoff' && handoff.status !== 'signed-handoff')
    || !HEX_64.test(handoff.publisherId)
    || typeof handoff.catalogRoot !== 'string'
    || typeof handoff.sourceEventRoot !== 'string'
    || typeof handoff.treeName !== 'string'
    || !handoff.unsignedEvent
  ) {
    throw new Error('Invalid post-search pointer handoff');
  }
  try {
    if (nhashEncode(nhashDecode(handoff.catalogRoot)) !== handoff.catalogRoot
      || nhashEncode(nhashDecode(handoff.sourceEventRoot)) !== handoff.sourceEventRoot) {
      throw new Error('non-canonical nhash');
    }
  } catch {
    throw new Error('Invalid post-search pointer handoff roots');
  }
  return handoff;
}

function decodeNsec(value: string): Uint8Array {
  try {
    const decoded = nip19.decode(value.trim());
    if (decoded.type !== 'nsec' || !(decoded.data instanceof Uint8Array) || decoded.data.length !== 32) {
      throw new Error('not an nsec');
    }
    return decoded.data;
  } catch {
    throw new Error('Invalid Hashtree identity key file');
  }
}

export function loopbackPostSearchDaemonUrl(value: string): string {
  return loopbackHashtreeDaemonUrl(value, 'Post-search publication');
}
