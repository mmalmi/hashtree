import { randomBytes, randomUUID } from 'node:crypto';
import { mkdir, open, readFile, rename, rm, stat } from 'node:fs/promises';
import { hostname } from 'node:os';
import { dirname, resolve } from 'node:path';
import { nhashDecode, nhashEncode } from '@hashtree/core';

export const PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT =
  'iris-social/profile-search-v3-catalog-builder-state@1' as const;
export const PROFILE_SEARCH_V3_CATALOG_BUILDER_LOCK_FORMAT =
  'iris-social/profile-search-v3-catalog-builder-lock@1' as const;

const HEX_64 = /^[0-9a-f]{64}$/;
const STATE_KEYS = [
  'format', 'status', 'configurationSha256', 'sourceRoot', 'eligibleRanksSha256',
  'generatedAt', 'completedPartitions', 'catalogRoot',
];
const PARTITION_KEYS = [
  'nibble', 'root', 'profileCount', 'postingCount', 'reachableNodeCount',
];

export interface ProfileSearchV3CompletedPartition {
  nibble: string;
  /** Null means the source snapshot had no visible eligible profile in this partition. */
  root: string | null;
  profileCount: number;
  postingCount: number;
  reachableNodeCount: number;
}

export interface ProfileSearchV3CatalogBuilderState {
  format: typeof PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT;
  status: 'building' | 'complete';
  configurationSha256: string;
  sourceRoot: string;
  eligibleRanksSha256: string;
  generatedAt: number;
  completedPartitions: ProfileSearchV3CompletedPartition[];
  catalogRoot: string | null;
}

export interface ProfileSearchV3CatalogBuilderStateStore {
  load(): Promise<ProfileSearchV3CatalogBuilderState | null>;
  /** Implementations must make a successful save durable before resolving. */
  save(state: ProfileSearchV3CatalogBuilderState): Promise<void>;
}

export class FileProfileSearchV3CatalogBuilderStateStore
implements ProfileSearchV3CatalogBuilderStateStore {
  private readonly path: string;

  constructor(path: string) {
    this.path = resolve(path);
  }

  async load(): Promise<ProfileSearchV3CatalogBuilderState | null> {
    let value: unknown;
    try {
      value = JSON.parse(await readFile(this.path, 'utf8'));
    } catch (error) {
      if (isErrno(error, 'ENOENT')) {return null;}
      throw error;
    }
    if (!isProfileSearchV3CatalogBuilderState(value)) {
      throw new Error('Invalid persisted profile-search v3 catalog builder state');
    }
    return value;
  }

  async save(state: ProfileSearchV3CatalogBuilderState): Promise<void> {
    if (!isProfileSearchV3CatalogBuilderState(state)) {
      throw new Error('Refusing invalid profile-search v3 catalog builder state');
    }
    await writeFsyncedJsonAtomic(this.path, state);
  }
}

export interface ProfileSearchV3CatalogBuilderStateLock {
  path: string;
  release(): Promise<void>;
}

/** One local writer owns a state file and its deterministic scratch directory. */
export async function acquireProfileSearchV3CatalogBuilderStateLock(
  statePath: string,
): Promise<ProfileSearchV3CatalogBuilderStateLock> {
  const path = `${resolve(statePath)}.lock`;
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  let token = '';
  for (let attempt = 0; attempt < 3; attempt += 1) {
    token = randomUUID();
    try {
      const file = await open(path, 'wx', 0o600);
      try {
        await file.writeFile(`${JSON.stringify({
          format: PROFILE_SEARCH_V3_CATALOG_BUILDER_LOCK_FORMAT,
          host: hostname(),
          pid: process.pid,
          token,
          startedAt: new Date().toISOString(),
        })}\n`);
        await file.sync();
      } finally {
        await file.close();
      }
      await syncDirectory(directory);
      break;
    } catch (error) {
      if (!isErrno(error, 'EEXIST')) {throw error;}
    }

    const owner = await readLockOwner(path);
    if (owner) {
      if (owner.host !== hostname()) {
        throw new Error(`Profile-search v3 builder lock belongs to host ${owner.host}`);
      }
      if (processIsAlive(owner.pid)) {
        throw new Error(`Profile-search v3 builder state is locked: ${path}`);
      }
    } else {
      const ageMs = await fileAgeMs(path);
      if (ageMs === null) {continue;}
      if (ageMs < 30_000) {
        throw new Error('Profile-search v3 builder lock is still being initialized');
      }
    }
    await rm(path, { force: true });
  }
  if (!token || (await readLockOwner(path))?.token !== token) {
    throw new Error('Failed to acquire profile-search v3 builder lock');
  }

  let released = false;
  return {
    path,
    async release() {
      if (released) {return;}
      let owner: unknown;
      try {
        owner = JSON.parse(await readFile(path, 'utf8'));
      } catch (error) {
        if (isErrno(error, 'ENOENT')) {
          released = true;
          return;
        }
        throw error;
      }
      if (!isRecord(owner) || owner.token !== token) {
        throw new Error('Profile-search v3 builder lock ownership changed');
      }
      await rm(path);
      await syncDirectory(directory);
      released = true;
    },
  };
}

export function isProfileSearchV3CatalogBuilderState(
  value: unknown,
): value is ProfileSearchV3CatalogBuilderState {
  if (!isRecord(value)
    || !hasExactKeys(value, STATE_KEYS)
    || value.format !== PROFILE_SEARCH_V3_CATALOG_BUILDER_STATE_FORMAT
    || (value.status !== 'building' && value.status !== 'complete')
    || typeof value.configurationSha256 !== 'string'
    || !HEX_64.test(value.configurationSha256)
    || !isCanonicalPublicNhash(value.sourceRoot)
    || typeof value.eligibleRanksSha256 !== 'string'
    || !HEX_64.test(value.eligibleRanksSha256)
    || !isNonNegativeInteger(value.generatedAt)
    || !Array.isArray(value.completedPartitions)
    || value.completedPartitions.length > 16
    || (value.catalogRoot !== null && !isCanonicalPublicNhash(value.catalogRoot))) {
    return false;
  }
  const seen = new Set<string>();
  let previous = '';
  for (const partition of value.completedPartitions) {
    if (!isRecord(partition)
      || !hasExactKeys(partition, PARTITION_KEYS)
      || typeof partition.nibble !== 'string'
      || !/^[0-9a-f]$/.test(partition.nibble)
      || partition.nibble <= previous
      || seen.has(partition.nibble)
      || (partition.root !== null && !isCanonicalPublicNhash(partition.root))
      || !isNonNegativeInteger(partition.profileCount)
      || !isNonNegativeInteger(partition.postingCount)
      || !isNonNegativeInteger(partition.reachableNodeCount)
      || (partition.root === null
        ? partition.profileCount !== 0
          || partition.postingCount !== 0
          || partition.reachableNodeCount !== 0
        : partition.profileCount === 0
          || partition.postingCount === 0
          || partition.reachableNodeCount === 0)) {
      return false;
    }
    previous = partition.nibble;
    seen.add(partition.nibble);
  }
  return value.status === 'complete'
    ? value.completedPartitions.length === 16 && value.catalogRoot !== null
    : value.catalogRoot === null;
}

function isNonNegativeInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && Number(value) >= 0;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasExactKeys(value: Record<string, unknown>, expected: readonly string[]): boolean {
  const keys = Object.keys(value).sort();
  const wanted = [...expected].sort();
  return keys.length === wanted.length && keys.every((key, index) => key === wanted[index]);
}

function isCanonicalPublicNhash(value: unknown): value is string {
  if (typeof value !== 'string') {return false;}
  try {
    const root = nhashDecode(value);
    return root.key === undefined && nhashEncode(root) === value;
  } catch {
    return false;
  }
}

function isErrno(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code;
}

async function readLockOwner(
  path: string,
): Promise<{ pid: number; host: string; token: string } | null> {
  try {
    const value = JSON.parse(await readFile(path, 'utf8')) as Record<string, unknown>;
    if (!Number.isSafeInteger(value.pid)
      || Number(value.pid) <= 0
      || typeof value.host !== 'string'
      || typeof value.token !== 'string') {
      return null;
    }
    return { pid: Number(value.pid), host: value.host, token: value.token };
  } catch (error) {
    if (isErrno(error, 'ENOENT') || error instanceof SyntaxError) {return null;}
    throw error;
  }
}

function processIsAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return isErrno(error, 'EPERM');
  }
}

async function fileAgeMs(path: string): Promise<number | null> {
  try {
    return Math.max(0, Date.now() - (await stat(path)).mtimeMs);
  } catch (error) {
    if (isErrno(error, 'ENOENT')) {return null;}
    throw error;
  }
}

async function syncDirectory(path: string): Promise<void> {
  const handle = await open(path, 'r');
  try {await handle.sync();} finally {await handle.close();}
}

async function writeFsyncedJsonAtomic(path: string, value: unknown): Promise<void> {
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const temporary = `${path}.tmp-${process.pid}-${randomBytes(8).toString('hex')}`;
  try {
    const file = await open(temporary, 'wx', 0o600);
    try {
      await file.writeFile(`${JSON.stringify(value, null, 2)}\n`);
      await file.sync();
    } finally {
      await file.close();
    }
    await rename(temporary, path);
    await syncDirectory(directory);
  } finally {
    await rm(temporary, { force: true });
  }
}
