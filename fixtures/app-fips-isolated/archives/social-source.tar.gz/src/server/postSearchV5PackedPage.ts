import {
  sha256,
  type CID,
  type Store,
} from '@hashtree/core';

export const POST_SEARCH_V5_PACKED_PAGE_FORMAT =
  'iris-social/post-search-v5-packed-page@1' as const;
export const POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES = 1_048_576;
export const POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES = 16_384;
export const POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES = 4_096;
export const POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES = 262_144;
export const POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES = 20;

export type PostSearchV5PackedPageKind =
  | 'documents'
  | 'postings'
  | 'terms'
  | 'visibility';
export type PostSearchV5PackedPageEntry = readonly [key: string, value: string];

export interface PostSearchV5PackedPage {
  format: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
  kind: PostSearchV5PackedPageKind;
  entries: readonly PostSearchV5PackedPageEntry[];
}

export interface PostSearchV5WrittenPackedPage {
  root: CID;
  stored: boolean;
  byteLength: number;
  entryCount: number;
}

const MAGIC = Uint8Array.from([0x49, 0x52, 0x49, 0x53, 0x50, 0x35, 0x50, 0x47]);
const WIRE_VERSION = 1;
const HEADER_BYTES = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES;
const ENTRY_HEADER_BYTES = 8;
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder('utf-8', { fatal: true });

const WIRE_TO_KIND: Readonly<Record<number, PostSearchV5PackedPageKind>> = {
  1: 'documents',
  2: 'postings',
  3: 'terms',
  4: 'visibility',
};

interface EncodedEntry {
  key: string;
  keyBytes: Uint8Array;
  valueBytes: Uint8Array;
}

/** Exact encoded contribution of one entry, including its two length fields. */
export function postSearchV5PackedPageEntryByteLength(
  key: string,
  value: string,
): number {
  const encoded = encodeEntry(key, value, '');
  return ENTRY_HEADER_BYTES + encoded.keyBytes.length + encoded.valueBytes.length;
}

/** Encode one canonical page. Entries are sorted by key so input order cannot affect its CID. */
export function encodePostSearchV5PackedPage(
  kind: PostSearchV5PackedPageKind,
  entries: readonly PostSearchV5PackedPageEntry[],
): Uint8Array {
  const wireKind = encodePageKind(kind);
  if (!Array.isArray(entries) || entries.length === 0) {
    throw new Error('Post-search v5 packed page requires at least one entry');
  }
  if (entries.length > POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES) {
    throw new Error(`Post-search v5 packed page entry count exceeds ${POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES}`);
  }

  const encoded: EncodedEntry[] = entries.map((rawEntry, index) => {
    const entry = rawEntry as unknown;
    if (!Array.isArray(entry) || entry.length !== 2
      || typeof entry[0] !== 'string' || typeof entry[1] !== 'string') {
      throw new Error(`Invalid post-search v5 packed page entry at ${index}`);
    }
    return encodeEntry(entry[0], entry[1], ` at ${index}`);
  });
  encoded.sort((left, right) => compareStrings(left.key, right.key));

  let byteLength = HEADER_BYTES;
  let previousKey: string | undefined;
  for (const entry of encoded) {
    if (entry.key === previousKey) {
      throw new Error(`Duplicate key in post-search v5 packed page: ${entry.key}`);
    }
    const { keyBytes, valueBytes } = entry;
    byteLength += ENTRY_HEADER_BYTES + keyBytes.length + valueBytes.length;
    if (byteLength > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
      throw new Error(`Post-search v5 packed page exceeds ${POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES} bytes`);
    }
    previousKey = entry.key;
  }

  const output = new Uint8Array(byteLength);
  output.set(MAGIC, 0);
  const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
  view.setUint8(8, WIRE_VERSION);
  view.setUint8(9, wireKind);
  view.setUint16(10, 0);
  view.setUint32(12, encoded.length);
  view.setUint32(16, byteLength - HEADER_BYTES);
  let offset = HEADER_BYTES;
  for (const { keyBytes, valueBytes } of encoded) {
    view.setUint32(offset, keyBytes.length);
    view.setUint32(offset + 4, valueBytes.length);
    offset += ENTRY_HEADER_BYTES;
    output.set(keyBytes, offset);
    offset += keyBytes.length;
    output.set(valueBytes, offset);
    offset += valueBytes.length;
  }
  return output;
}

function encodeEntry(key: string, value: string, suffix: string): EncodedEntry {
  if (typeof key !== 'string' || typeof value !== 'string') {
    throw new Error(`Invalid post-search v5 packed page entry${suffix}`);
  }
  if (key.length === 0) {
    throw new Error(`Post-search v5 packed page has an empty key${suffix}`);
  }
  const keyBytes = encodeCanonicalString(key, `key${suffix}`);
  const valueBytes = encodeCanonicalString(value, `value${suffix}`);
  boundedString(keyBytes, POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES, `key${suffix}`);
  boundedString(valueBytes, POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES, `value${suffix}`);
  return { key, keyBytes, valueBytes };
}

/** Decode and validate a canonical page. Malformed or noncanonical bytes are never accepted. */
export function decodePostSearchV5PackedPage(bytes: Uint8Array): PostSearchV5PackedPage {
  if (!(bytes instanceof Uint8Array)
    || bytes.length < HEADER_BYTES
    || bytes.length > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
    throw new Error('Invalid post-search v5 packed page byte length');
  }
  for (let index = 0; index < MAGIC.length; index += 1) {
    if (bytes[index] !== MAGIC[index]) {
      throw new Error('Invalid post-search v5 packed page magic');
    }
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const version = view.getUint8(8);
  if (version !== WIRE_VERSION) {
    throw new Error(`Unsupported post-search v5 packed page version: ${version}`);
  }
  const kind = WIRE_TO_KIND[view.getUint8(9)];
  if (!kind) {
    throw new Error('Invalid post-search v5 packed page kind');
  }
  if (view.getUint16(10) !== 0) {
    throw new Error('Unsupported post-search v5 packed page flags');
  }
  const count = view.getUint32(12);
  if (count === 0 || count > POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES) {
    throw new Error('Invalid post-search v5 packed page entry count');
  }
  if (view.getUint32(16) !== bytes.length - HEADER_BYTES) {
    throw new Error('Invalid post-search v5 packed page body length');
  }

  const entries: PostSearchV5PackedPageEntry[] = [];
  let offset = HEADER_BYTES;
  let previousKey: string | undefined;
  for (let index = 0; index < count; index += 1) {
    if (bytes.length - offset < ENTRY_HEADER_BYTES) {
      throw new Error('Truncated post-search v5 packed page entry header');
    }
    const keyLength = view.getUint32(offset);
    const valueLength = view.getUint32(offset + 4);
    offset += ENTRY_HEADER_BYTES;
    if (keyLength === 0 || keyLength > POST_SEARCH_V5_PACKED_PAGE_MAX_KEY_BYTES) {
      throw new Error(`Invalid post-search v5 packed page key byte length at ${index}`);
    }
    if (valueLength > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      throw new Error(`Invalid post-search v5 packed page value byte length at ${index}`);
    }
    if (keyLength + valueLength > bytes.length - offset) {
      throw new Error('Truncated post-search v5 packed page entry');
    }
    const key = decodeCanonicalString(bytes.subarray(offset, offset + keyLength), `key at ${index}`);
    offset += keyLength;
    const value = decodeCanonicalString(
      bytes.subarray(offset, offset + valueLength),
      `value at ${index}`,
    );
    offset += valueLength;
    if (previousKey !== undefined && compareStrings(previousKey, key) >= 0) {
      throw new Error('Post-search v5 packed page keys are not strictly sorted');
    }
    entries.push([key, value]);
    previousKey = key;
  }
  if (offset !== bytes.length) {
    throw new Error('Post-search v5 packed page has trailing bytes');
  }
  return { format: POST_SEARCH_V5_PACKED_PAGE_FORMAT, kind, entries };
}

/** Store exactly one raw Hashtree block for one page. */
export async function writePostSearchV5PackedPage(
  store: Store,
  kind: PostSearchV5PackedPageKind,
  entries: readonly PostSearchV5PackedPageEntry[],
): Promise<PostSearchV5WrittenPackedPage> {
  const bytes = encodePostSearchV5PackedPage(kind, entries);
  const hash = await sha256(bytes);
  const stored = await store.put(hash, bytes);
  return {
    root: { hash },
    stored,
    byteLength: bytes.length,
    entryCount: entries.length,
  };
}

/** Read one raw block by CID, verify its SHA-256 identity, then decode it strictly. */
export async function readPostSearchV5PackedPage(
  store: Store,
  root: CID,
): Promise<PostSearchV5PackedPage> {
  assertPublicPageCid(root);
  const bytes = await store.get(root.hash);
  if (!bytes) {
    throw new Error('Missing packed page block for post-search v5');
  }
  const actual = await sha256(bytes);
  if (!equalBytes(root.hash, actual)) {
    throw new Error('Post-search v5 packed page block hash mismatch');
  }
  return decodePostSearchV5PackedPage(bytes);
}

function encodeCanonicalString(value: string, label: string): Uint8Array {
  const bytes = textEncoder.encode(value);
  if (decodeCanonicalString(bytes, label) !== value) {
    throw new Error(`Invalid Unicode in post-search v5 packed page ${label}`);
  }
  return bytes;
}

function decodeCanonicalString(bytes: Uint8Array, label: string): string {
  try {
    const value = textDecoder.decode(bytes);
    if (!equalBytes(textEncoder.encode(value), bytes)) {
      throw new Error('noncanonical');
    }
    return value;
  } catch {
    throw new Error(`Invalid UTF-8 in post-search v5 packed page ${label}`);
  }
}

function boundedString(bytes: Uint8Array, maximum: number, label: string): void {
  if (bytes.length > maximum) {
    throw new Error(`Post-search v5 packed page ${label} exceeds ${maximum} bytes`);
  }
}

function assertPublicPageCid(root: CID): void {
  if (!(root?.hash instanceof Uint8Array) || root.hash.length !== 32) {
    throw new Error('Invalid post-search v5 packed page CID hash');
  }
  if (root.key !== undefined) {
    throw new Error('Encrypted post-search v5 packed page CIDs are unsupported');
  }
}

function encodePageKind(kind: PostSearchV5PackedPageKind): number {
  if (kind === 'documents') {
    return 1;
  }
  if (kind === 'postings') {
    return 2;
  }
  if (kind === 'terms') {
    return 3;
  }
  if (kind === 'visibility') {
    return 4;
  }
  throw new Error(`Invalid post-search v5 packed page kind: ${String(kind)}`);
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
