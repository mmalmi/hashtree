import { createHash } from 'node:crypto';
import { nhashDecode, nhashEncode } from '@hashtree/core';
import { closureReferenceKey, parseClosureReference } from './referencedEventClosureReferences';
import {
  REFERENCED_EVENT_CLOSURE_FORMAT,
  REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT,
  type ReferencedEventClosureBatch,
  type ReferencedEventClosureCounters,
  type ReferencedEventClosureJournalInit,
  type ReferencedEventClosureLimits,
  type ReferencedEventClosureResult,
  type ReplayedClosureState,
} from './referencedEventClosureTypes';

const HEX_64 = /^[0-9a-f]{64}$/;
const DEFAULT_MAX_DEPTH = 2;
const DEFAULT_MAX_REFERENCES = 250_000;
const DEFAULT_MAX_ACCEPTED_EVENTS = 250_000;
const DEFAULT_MAX_ACCEPTED_BYTES = 512 * 1024 * 1024;
const DEFAULT_MAX_EVENT_BYTES = 1024 * 1024;
const DEFAULT_SOURCE_BATCH_SIZE = 512;
const DEFAULT_RESOLUTION_BATCH_SIZE = 128;
const DEFAULT_MAX_RESOLVER_CANDIDATES = 512;

export function replayClosureJournal(
  rawEntries: readonly unknown[],
  expected: Pick<
    ReplayedClosureState,
    | 'configurationSha256'
    | 'sourceRoot'
    | 'eligibleAuthorsSha256'
    | 'overmutedAuthorsSha256'
    | 'resolverPolicySha256'
    | 'limits'
  >,
): ReplayedClosureState {
  const state: ReplayedClosureState = {
    ...expected,
    sequence: 0,
    sourceProcessed: 0,
    sourceBoundaryEventId: null,
    sourceComplete: false,
    queue: [],
    queueCursor: 0,
    seenReferenceKeys: new Set(),
    acceptedEventIds: new Set(),
    acceptedCoordinates: new Set(),
    batches: [],
    counters: emptyClosureCounters(),
    complete: false,
  };
  if (rawEntries.length === 0) {
    return state;
  }
  const init = parseInit(rawEntries[0]);
  if (
    init.configurationSha256 !== expected.configurationSha256
    || init.sourceRoot !== expected.sourceRoot
    || init.eligibleAuthorsSha256 !== expected.eligibleAuthorsSha256
    || init.overmutedAuthorsSha256 !== expected.overmutedAuthorsSha256
    || init.resolverPolicySha256 !== expected.resolverPolicySha256
    || JSON.stringify(init.limits) !== JSON.stringify(expected.limits)
  ) {
    throw new Error('Referenced-event closure journal belongs to different inputs');
  }
  for (let index = 1; index < rawEntries.length; index += 1) {
    const raw = rawEntries[index];
    if (!raw || typeof raw !== 'object') {
      throw new Error('Invalid referenced-event closure journal entry');
    }
    const value = raw as Record<string, unknown>;
    if (value.sequence !== index || value.format !== REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT) {
      throw new Error('Referenced-event closure journal sequence is invalid');
    }
    if (value.type === 'complete') {
      if (index !== rawEntries.length - 1 || !state.sourceComplete || state.queueCursor !== state.queue.length) {
        throw new Error('Referenced-event closure completion journal is inconsistent');
      }
      state.counters = parseClosureCounters(value.counters);
      state.complete = true;
      state.sequence = index;
      continue;
    }
    if (value.type !== 'checkpoint' || state.complete) {
      throw new Error('Invalid referenced-event closure checkpoint');
    }
    const added = parseReferences(value.addedReferences);
    for (const reference of added) {
      const key = closureReferenceKey(reference);
      if (state.seenReferenceKeys.has(key)) {
        throw new Error('Referenced-event closure journal contains a duplicate reference');
      }
      state.seenReferenceKeys.add(key);
      if (reference.depth <= state.limits.maxDepth) {
        state.queue.push(reference);
      }
    }
    const batch = parseBatch(value.acceptedBatch);
    if (batch) {
      for (const id of batch.eventIds) {
        if (state.acceptedEventIds.has(id)) {
          throw new Error('Referenced-event closure journal contains a duplicate event');
        }
        state.acceptedEventIds.add(id);
      }
      state.batches.push(batch);
    }
    state.sourceProcessed = nonNegativeInteger(value.sourceProcessed, 'source processed');
    state.sourceBoundaryEventId = nullableEventId(value.sourceBoundaryEventId);
    state.sourceComplete = booleanValue(value.sourceComplete, 'source complete');
    state.queueCursor = nonNegativeInteger(value.queueCursor, 'queue cursor');
    if (state.queueCursor > state.queue.length) {
      throw new Error('Referenced-event closure queue cursor exceeds its queue');
    }
    state.counters = parseClosureCounters(value.counters);
    state.sequence = index;
  }
  return state;
}

export function normalizeClosureLimits(
  value: Partial<ReferencedEventClosureLimits> | undefined,
): ReferencedEventClosureLimits {
  const limits: ReferencedEventClosureLimits = {
    maxDepth: value?.maxDepth ?? DEFAULT_MAX_DEPTH,
    maxReferences: value?.maxReferences ?? DEFAULT_MAX_REFERENCES,
    maxAcceptedEvents: value?.maxAcceptedEvents ?? DEFAULT_MAX_ACCEPTED_EVENTS,
    maxAcceptedBytes: value?.maxAcceptedBytes ?? DEFAULT_MAX_ACCEPTED_BYTES,
    maxEventBytes: value?.maxEventBytes ?? DEFAULT_MAX_EVENT_BYTES,
    sourceBatchSize: value?.sourceBatchSize ?? DEFAULT_SOURCE_BATCH_SIZE,
    resolutionBatchSize: value?.resolutionBatchSize ?? DEFAULT_RESOLUTION_BATCH_SIZE,
    maxResolverCandidates: value?.maxResolverCandidates ?? DEFAULT_MAX_RESOLVER_CANDIDATES,
  };
  for (const [name, limit] of Object.entries(limits)) {
    if (!Number.isSafeInteger(limit) || limit <= 0) {
      throw new Error(`Referenced-event closure ${name} must be a positive integer`);
    }
  }
  if (limits.maxDepth > 16 || limits.maxResolverCandidates < limits.resolutionBatchSize) {
    throw new Error('Referenced-event closure limits are inconsistent');
  }
  return limits;
}

export function hashClosurePubkeySet(
  values: ReadonlySet<string>,
  name: string,
  allowEmpty = false,
): string {
  const sorted = [...values].sort();
  if ((!allowEmpty && sorted.length === 0) || sorted.some((value) => !HEX_64.test(value))) {
    throw new Error(`Referenced-event closure ${name} author set is invalid`);
  }
  return closureSha256(sorted.length === 0 ? '' : `${sorted.join('\n')}\n`);
}

export function emptyClosureCounters(): ReferencedEventClosureCounters {
  return {
    sourceEventsScanned: 0,
    referencesDiscovered: 0,
    referencesProcessed: 0,
    acceptedEvents: 0,
    acceptedEventBytes: 0,
    excludedOvermuted: 0,
    invalidCandidates: 0,
    unmatchedCandidates: 0,
    unresolvedReferences: 0,
    depthLimitedReferences: 0,
    supersededBatchEvents: 0,
    unrepresentableCurrentState: 0,
  };
}

export function resultFromClosureState(state: ReplayedClosureState): ReferencedEventClosureResult {
  return {
    format: REFERENCED_EVENT_CLOSURE_FORMAT,
    complete: true,
    additive: true,
    sourceRoot: state.sourceRoot,
    configurationSha256: state.configurationSha256,
    eligibleAuthorsSha256: state.eligibleAuthorsSha256,
    overmutedAuthorsSha256: state.overmutedAuthorsSha256,
    resolverPolicySha256: state.resolverPolicySha256,
    limits: { ...state.limits },
    batches: state.batches.map((batch) => ({ ...batch, eventIds: [...batch.eventIds] })),
    counters: { ...state.counters },
  };
}

export function closureSha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

function parseInit(value: unknown): ReferencedEventClosureJournalInit {
  if (!value || typeof value !== 'object') {
    throw new Error('Referenced-event closure journal is missing its initialization');
  }
  const init = value as Partial<ReferencedEventClosureJournalInit>;
  if (
    init.format !== REFERENCED_EVENT_CLOSURE_JOURNAL_FORMAT
    || init.type !== 'init'
    || init.sequence !== 0
    || !isSha(init.configurationSha256)
    || !isCanonicalRoot(init.sourceRoot)
    || !isSha(init.eligibleAuthorsSha256)
    || !isSha(init.overmutedAuthorsSha256)
    || !isSha(init.resolverPolicySha256)
  ) {
    throw new Error('Invalid referenced-event closure journal initialization');
  }
  return { ...init, limits: normalizeClosureLimits(init.limits) } as ReferencedEventClosureJournalInit;
}

function parseReferences(value: unknown) {
  if (!Array.isArray(value)) {
    throw new Error('Invalid referenced-event closure reference delta');
  }
  return value.map(parseClosureReference);
}

function parseBatch(value: unknown): ReferencedEventClosureBatch | null {
  if (value === null) {
    return null;
  }
  if (!value || typeof value !== 'object') {
    throw new Error('Invalid referenced-event closure batch');
  }
  const batch = value as Partial<ReferencedEventClosureBatch>;
  if (
    !isCanonicalRoot(batch.root)
    || !Array.isArray(batch.eventIds)
    || batch.eventIds.length === 0
    || batch.eventIds.some((id) => typeof id !== 'string' || !HEX_64.test(id))
    || new Set(batch.eventIds).size !== batch.eventIds.length
  ) {
    throw new Error('Invalid referenced-event closure batch');
  }
  return { root: batch.root, eventIds: [...batch.eventIds] };
}

function parseClosureCounters(value: unknown): ReferencedEventClosureCounters {
  if (!value || typeof value !== 'object') {
    throw new Error('Invalid referenced-event closure counters');
  }
  const raw = value as Record<string, unknown>;
  const result = emptyClosureCounters();
  for (const key of Object.keys(result) as Array<keyof ReferencedEventClosureCounters>) {
    result[key] = nonNegativeInteger(raw[key], key);
  }
  return result;
}

function nonNegativeInteger(value: unknown, name: string): number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {
    throw new Error(`Invalid referenced-event closure ${name}`);
  }
  return Number(value);
}

function nullableEventId(value: unknown): string | null {
  if (value === null) {
    return null;
  }
  if (typeof value !== 'string' || !HEX_64.test(value)) {
    throw new Error('Invalid referenced-event closure source boundary');
  }
  return value;
}

function booleanValue(value: unknown, name: string): boolean {
  if (typeof value !== 'boolean') {
    throw new Error(`Invalid referenced-event closure ${name}`);
  }
  return value;
}

function isSha(value: unknown): value is string {
  return typeof value === 'string' && HEX_64.test(value);
}

function isCanonicalRoot(value: unknown): value is string {
  if (typeof value !== 'string') {
    return false;
  }
  try {
    return nhashEncode(nhashDecode(value)) === value;
  } catch {
    return false;
  }
}
