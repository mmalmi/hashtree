import type { CID, Store } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import { POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES } from './postSearchV5PackedPage';
import {
  createPostSearchV5RoutedRunWriter,
  readPostSearchV5RoutedRun,
  type PostSearchV5RoutedRunLookup,
  type PostSearchV5RoutedRunManifest,
} from './postSearchV5RoutedRun';
import type {
  PostSearchV5Posting,
  PostSearchV5StoredDocument,
  PostSearchV5TermStats,
} from './postSearchV5Run';

const encoder = new TextEncoder();

export interface PostSearchV5RoutedCompactionOptions {
  maxDocumentCount?: number;
  maxTermCount?: number;
  maxPostingCount?: number;
  maxPostingPartCount?: number;
  maxStoredValueCount?: number;
  maxTokenOccurrenceCount?: number;
  maxInputReachableNodeCount?: number;
  maxOutputReachableNodeCount?: number;
}

interface CompactionCapacity {
  documentCount: number;
  termCount: number;
  postingCount: number;
  postingPartCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
  inputReachableNodeCount: number;
  outputReachableNodeCount: number;
}

interface CompactionCounts {
  documentCount: number;
  termCount: number;
  postingCount: number;
  postingPartCount: number;
  storedValueCount: number;
  tokenOccurrenceCount: number;
}

interface FieldTotals {
  totalLength: Map<string, number>;
  populatedDocumentCount: Map<string, number>;
}

/**
 * Strictly verifies and merges two disjoint routed runs without retaining either corpus.
 * The returned lookup has itself passed the complete routed-run verifier.
 */
export async function compactPostSearchV5RoutedRuns(
  store: Store,
  leftRoot: CID,
  rightRoot: CID,
  options: PostSearchV5RoutedCompactionOptions = {},
): Promise<PostSearchV5RoutedRunLookup> {
  const capacity = normalizeCapacity(options);
  const left = await readPostSearchV5RoutedRun(store, leftRoot, {
    maxReachableNodeCount: capacity.inputReachableNodeCount,
  });
  const right = await readPostSearchV5RoutedRun(store, rightRoot, {
    maxReachableNodeCount: capacity.inputReachableNodeCount,
  });
  assertCompatible(left.manifest, right.manifest);

  const expected = await preflightCounts(left, right, capacity);
  const writer = createPostSearchV5RoutedRunWriter(store);
  const totals = createFieldTotals(left.manifest.fields);
  const documents = await appendMergedDocuments(left, right, writer, totals);
  if (documents.documentCount !== expected.documentCount
    || documents.storedValueCount !== expected.storedValueCount) {
    throw new Error('Post-search v5 routed compaction document counters changed after preflight');
  }

  const postings = await appendMergedTerms(left, right, writer, capacity);
  if (postings.termCount !== expected.termCount
    || postings.postingCount !== expected.postingCount
    || postings.tokenOccurrenceCount !== expected.tokenOccurrenceCount) {
    throw new Error('Post-search v5 routed compaction term counters changed after preflight');
  }
  expected.postingPartCount = postings.postingPartCount;

  const built = await writer.finish({
    ...expected,
    k1: left.manifest.k1,
    maxTokensPerField: left.manifest.maxTokensPerField,
    fields: finishFields(left.manifest.fields, totals),
    maxReachableNodeCount: capacity.outputReachableNodeCount,
  });
  return await readPostSearchV5RoutedRun(store, built.root, {
    expected: {
      documentCount: expected.documentCount,
      termCount: expected.termCount,
      postingCount: expected.postingCount,
      postingPartCount: expected.postingPartCount,
      storedValueCount: expected.storedValueCount,
      tokenOccurrenceCount: expected.tokenOccurrenceCount,
      reachableNodeCount: built.manifest.reachableNodeCount,
    },
    maxReachableNodeCount: capacity.outputReachableNodeCount,
  });
}

async function preflightCounts(
  left: PostSearchV5RoutedRunLookup,
  right: PostSearchV5RoutedRunLookup,
  capacity: CompactionCapacity,
): Promise<CompactionCounts> {
  const counts = {
    documentCount: checkedTotal(
      left.manifest.documentCount,
      right.manifest.documentCount,
      capacity.documentCount,
      'document count',
    ),
    termCount: await countMergedTerms(left, right, capacity.termCount),
    postingCount: checkedTotal(
      left.manifest.postingCount,
      right.manifest.postingCount,
      capacity.postingCount,
      'posting count',
    ),
    postingPartCount: 0,
    storedValueCount: checkedTotal(
      left.manifest.storedValueCount,
      right.manifest.storedValueCount,
      capacity.storedValueCount,
      'stored value count',
    ),
    tokenOccurrenceCount: checkedTotal(
      left.manifest.tokenOccurrenceCount,
      right.manifest.tokenOccurrenceCount,
      capacity.tokenOccurrenceCount,
      'token occurrence count',
    ),
  };
  return counts;
}

async function appendMergedDocuments(
  left: PostSearchV5RoutedRunLookup,
  right: PostSearchV5RoutedRunLookup,
  writer: ReturnType<typeof createPostSearchV5RoutedRunWriter>,
  totals: FieldTotals,
): Promise<Pick<CompactionCounts, 'documentCount' | 'storedValueCount'>> {
  const leftCursor = new AsyncCursor(left.streamDocuments());
  const rightCursor = new AsyncCursor(right.streamDocuments());
  await Promise.all([leftCursor.advance(), rightCursor.advance()]);
  let documentCount = 0;
  let storedValueCount = 0;
  while (leftCursor.value || rightCursor.value) {
    const chosen = chooseUniqueEntry(leftCursor.value, rightCursor.value, 'document');
    const [id, document] = chosen.entry;
    await writer.appendDocument(id, document);
    documentCount = safeAdd(documentCount, 1, 'document count');
    if (document.value !== undefined) {
      storedValueCount = safeAdd(storedValueCount, 1, 'stored value count');
    }
    addDocumentTotals(document, totals);
    await (chosen.side === 'left' ? leftCursor : rightCursor).advance();
  }
  return { documentCount, storedValueCount };
}

async function appendMergedTerms(
  left: PostSearchV5RoutedRunLookup,
  right: PostSearchV5RoutedRunLookup,
  writer: ReturnType<typeof createPostSearchV5RoutedRunWriter>,
  capacity: CompactionCapacity,
): Promise<Pick<CompactionCounts,
  'termCount' | 'postingCount' | 'postingPartCount' | 'tokenOccurrenceCount'>> {
  const leftCursor = new AsyncCursor(left.streamTerms());
  const rightCursor = new AsyncCursor(right.streamTerms());
  await Promise.all([leftCursor.advance(), rightCursor.advance()]);
  let termCount = 0;
  let postingCount = 0;
  let postingPartCount = 0;
  let tokenOccurrenceCount = 0;
  while (leftCursor.value || rightCursor.value) {
    const group = chooseTermGroup(leftCursor.value, rightCursor.value);
    const mergedStats = mergeTermStats(group.left?.[1], group.right?.[1]);
    const result = await appendTermPostings(
      group.term,
      group.left ? left.streamPostings(group.term) : emptyPostings(),
      group.right ? right.streamPostings(group.term) : emptyPostings(),
      writer,
      postingPartCount,
      capacity.postingPartCount,
    );
    if (result.postingCount !== mergedStats.documentFrequency) {
      throw new Error(`Post-search v5 routed compaction posting coverage mismatch: ${group.term}`);
    }
    postingCount = safeAdd(postingCount, result.postingCount, 'posting count');
    postingPartCount = safeAdd(postingPartCount, result.postingPartCount, 'posting part count');
    tokenOccurrenceCount = safeAdd(
      tokenOccurrenceCount,
      result.tokenOccurrenceCount,
      'token occurrence count',
    );
    await writer.appendTerm(group.term, {
      ...mergedStats,
      postingParts: result.postingPartCount,
    });
    termCount = safeAdd(termCount, 1, 'term count');
    if (group.left) {await leftCursor.advance();}
    if (group.right) {await rightCursor.advance();}
  }
  return { termCount, postingCount, postingPartCount, tokenOccurrenceCount };
}

async function appendTermPostings(
  term: string,
  left: AsyncGenerator<PostSearchV5Posting>,
  right: AsyncGenerator<PostSearchV5Posting>,
  writer: ReturnType<typeof createPostSearchV5RoutedRunWriter>,
  precedingPartCount: number,
  maximumPartCount: number,
): Promise<Pick<CompactionCounts, 'postingCount' | 'postingPartCount' | 'tokenOccurrenceCount'>> {
  const leftCursor = new AsyncCursor(left);
  const rightCursor = new AsyncCursor(right);
  await Promise.all([leftCursor.advance(), rightCursor.advance()]);
  let part: PostSearchV5Posting[] = [];
  let partBytes = 2;
  let postingCount = 0;
  let postingPartCount = 0;
  let tokenOccurrenceCount = 0;

  const flush = async () => {
    if (part.length === 0) {return;}
    if (safeAdd(precedingPartCount, postingPartCount + 1, 'posting part count')
      > maximumPartCount) {
      throw new Error('Post-search v5 routed compaction posting part count exceeds capacity');
    }
    await writer.appendPosting(term, postingPartCount, part);
    postingPartCount = safeAdd(postingPartCount, 1, 'posting part count');
    part = [];
    partBytes = 2;
  };

  while (leftCursor.value || rightCursor.value) {
    const chosen = chooseUniquePosting(leftCursor.value, rightCursor.value, term);
    const posting = chosen.posting;
    const recordBytes = encoder.encode(JSON.stringify(posting)).length;
    const requiredBytes = recordBytes + (part.length === 0 ? 0 : 1);
    if (part.length > 0 && partBytes + requiredBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      await flush();
    }
    if (partBytes + recordBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_VALUE_BYTES) {
      throw new Error(`Post-search v5 routed compaction posting exceeds value capacity: ${term}`);
    }
    part.push(posting);
    partBytes += recordBytes + (part.length === 1 ? 0 : 1);
    postingCount = safeAdd(postingCount, 1, 'posting count');
    tokenOccurrenceCount = safeAdd(
      tokenOccurrenceCount,
      postingTokenCount(posting),
      'token occurrence count',
    );
    await (chosen.side === 'left' ? leftCursor : rightCursor).advance();
  }
  await flush();
  return { postingCount, postingPartCount, tokenOccurrenceCount };
}

async function countMergedTerms(
  left: PostSearchV5RoutedRunLookup,
  right: PostSearchV5RoutedRunLookup,
  maximum: number,
): Promise<number> {
  const leftCursor = new AsyncCursor(left.streamTerms());
  const rightCursor = new AsyncCursor(right.streamTerms());
  await Promise.all([leftCursor.advance(), rightCursor.advance()]);
  let count = 0;
  while (leftCursor.value || rightCursor.value) {
    const group = chooseTermGroup(leftCursor.value, rightCursor.value);
    count = safeAdd(count, 1, 'term count');
    if (count > maximum) {
      throw new Error('Post-search v5 routed compaction term count exceeds capacity');
    }
    if (group.left) {await leftCursor.advance();}
    if (group.right) {await rightCursor.advance();}
  }
  return count;
}

function chooseUniqueEntry<T>(
  left: readonly [string, T] | null,
  right: readonly [string, T] | null,
  label: string,
): { entry: readonly [string, T]; side: 'left' | 'right' } {
  if (left && right && left[0] === right[0]) {
    throw new Error(`Post-search v5 routed compaction has duplicate ${label}: ${left[0]}`);
  }
  if (left && (!right || compareText(left[0], right[0]) < 0)) {
    return { entry: left, side: 'left' };
  }
  if (!right) {throw new Error(`Post-search v5 routed compaction has no ${label}`);}
  return { entry: right, side: 'right' };
}

interface TermGroup {
  term: string;
  left: readonly [string, PostSearchV5TermStats] | null;
  right: readonly [string, PostSearchV5TermStats] | null;
}

function chooseTermGroup(
  left: readonly [string, PostSearchV5TermStats] | null,
  right: readonly [string, PostSearchV5TermStats] | null,
): TermGroup {
  if (left && right && left[0] === right[0]) {
    return { term: left[0], left, right };
  }
  if (left && (!right || compareText(left[0], right[0]) < 0)) {
    return { term: left[0], left, right: null };
  }
  if (!right) {throw new Error('Post-search v5 routed compaction has no term');}
  return { term: right[0], left: null, right };
}

function chooseUniquePosting(
  left: PostSearchV5Posting | null,
  right: PostSearchV5Posting | null,
  term: string,
): { posting: PostSearchV5Posting; side: 'left' | 'right' } {
  if (left && right && left.id === right.id) {
    throw new Error(`Post-search v5 routed compaction has duplicate posting: ${term}/${left.id}`);
  }
  if (left && (!right || compareText(left.id, right.id) < 0)) {
    return { posting: left, side: 'left' };
  }
  if (!right) {throw new Error(`Post-search v5 routed compaction has no posting: ${term}`);}
  return { posting: right, side: 'right' };
}

class AsyncCursor<T> {
  value: T | null = null;
  private readonly iterator: AsyncIterator<T>;

  constructor(iterable: AsyncIterable<T>) {
    this.iterator = iterable[Symbol.asyncIterator]();
  }

  async advance(): Promise<void> {
    const result = await this.iterator.next();
    this.value = result.done ? null : result.value;
  }
}

async function* emptyPostings(): AsyncGenerator<PostSearchV5Posting> {}

function mergeTermStats(
  left: PostSearchV5TermStats | undefined,
  right: PostSearchV5TermStats | undefined,
): Omit<PostSearchV5TermStats, 'postingParts'> {
  const fieldSets = new Map<string, { fields: string[]; documentFrequency: number }>();
  let documentFrequency = 0;
  for (const stats of [left, right]) {
    if (!stats) {continue;}
    documentFrequency = safeAdd(
      documentFrequency,
      stats.documentFrequency,
      'term document frequency',
    );
    for (const fieldSet of stats.fieldSets) {
      const key = JSON.stringify(fieldSet.fields);
      const existing = fieldSets.get(key);
      if (existing) {
        existing.documentFrequency = safeAdd(
          existing.documentFrequency,
          fieldSet.documentFrequency,
          'term field-set frequency',
        );
      } else {
        fieldSets.set(key, {
          fields: [...fieldSet.fields],
          documentFrequency: fieldSet.documentFrequency,
        });
      }
    }
  }
  return {
    documentFrequency,
    fieldSets: [...fieldSets.values()].sort((a, b) =>
      compareText(JSON.stringify(a.fields), JSON.stringify(b.fields))),
  };
}

function assertCompatible(
  left: PostSearchV5RoutedRunManifest,
  right: PostSearchV5RoutedRunManifest,
): void {
  const leftConfig = configProjection(left);
  const rightConfig = configProjection(right);
  if (JSON.stringify(leftConfig) !== JSON.stringify(rightConfig)) {
    throw new Error('Post-search v5 routed compaction input configurations are incompatible');
  }
}

function configProjection(manifest: PostSearchV5RoutedRunManifest): unknown {
  return {
    format: manifest.format,
    normalization: manifest.normalization,
    k1: manifest.k1,
    maxTokensPerField: manifest.maxTokensPerField,
    fields: manifest.fields.map(({ name, boost, lengthNormalization }) => ({
      name,
      boost,
      lengthNormalization,
    })),
  };
}

function createFieldTotals(fields: readonly RankedSearchFieldManifest[]): FieldTotals {
  return {
    totalLength: new Map(fields.map((field) => [field.name, 0])),
    populatedDocumentCount: new Map(fields.map((field) => [field.name, 0])),
  };
}

function addDocumentTotals(document: PostSearchV5StoredDocument, totals: FieldTotals): void {
  for (const [field, length] of Object.entries(document.lengths)) {
    totals.totalLength.set(
      field,
      safeAdd(totals.totalLength.get(field) ?? 0, length, `field ${field} total length`),
    );
    if (length > 0) {
      totals.populatedDocumentCount.set(
        field,
        safeAdd(
          totals.populatedDocumentCount.get(field) ?? 0,
          1,
          `field ${field} populated count`,
        ),
      );
    }
  }
}

function finishFields(
  fields: readonly RankedSearchFieldManifest[],
  totals: FieldTotals,
): RankedSearchFieldManifest[] {
  return fields.map(({ name, boost, lengthNormalization }) => ({
    name,
    boost,
    lengthNormalization,
    totalLength: totals.totalLength.get(name) ?? 0,
    populatedDocumentCount: totals.populatedDocumentCount.get(name) ?? 0,
  }));
}

function postingTokenCount(posting: PostSearchV5Posting): number {
  return Object.values(posting.fields).reduce(
    (sum, field) => safeAdd(sum, field.frequency, 'posting token count'),
    0,
  );
}

function normalizeCapacity(options: PostSearchV5RoutedCompactionOptions): CompactionCapacity {
  return {
    documentCount: capacity(options.maxDocumentCount, 'maxDocumentCount'),
    termCount: capacity(options.maxTermCount, 'maxTermCount'),
    postingCount: capacity(options.maxPostingCount, 'maxPostingCount'),
    postingPartCount: capacity(options.maxPostingPartCount, 'maxPostingPartCount'),
    storedValueCount: capacity(options.maxStoredValueCount, 'maxStoredValueCount'),
    tokenOccurrenceCount: capacity(
      options.maxTokenOccurrenceCount,
      'maxTokenOccurrenceCount',
    ),
    inputReachableNodeCount: positiveCapacity(
      options.maxInputReachableNodeCount,
      'maxInputReachableNodeCount',
    ),
    outputReachableNodeCount: positiveCapacity(
      options.maxOutputReachableNodeCount,
      'maxOutputReachableNodeCount',
    ),
  };
}

function capacity(value: number | undefined, label: string): number {
  if (value === undefined) {return Number.MAX_SAFE_INTEGER;}
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid post-search v5 routed compaction ${label}`);
  }
  return value;
}

function positiveCapacity(value: number | undefined, label: string): number {
  const result = capacity(value, label);
  if (result === 0) {throw new Error(`Invalid post-search v5 routed compaction ${label}`);}
  return result;
}

function checkedTotal(left: number, right: number, maximum: number, label: string): number {
  const result = safeAdd(left, right, label);
  if (result > maximum) {
    throw new Error(`Post-search v5 routed compaction ${label} exceeds capacity`);
  }
  return result;
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post-search v5 routed compaction ${label} exceeds safe integer capacity`);
  }
  return result;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
