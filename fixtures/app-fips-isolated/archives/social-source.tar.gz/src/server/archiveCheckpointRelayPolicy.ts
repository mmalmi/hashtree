import { canonical, type ArchiveLineageReceipt, type ArchiveRelayRemovalReceipt } from './archiveCheckpointOutbox';

export function isArchiveRelayRemovalReceipt(receipt: ArchiveLineageReceipt): receipt is ArchiveRelayRemovalReceipt {
  return receipt.format === 'iris-social/archive-relay-removal@1';
}

/** Raw checkpoint digests are captured by the operator and bound by the receipt's separate file pin. */
export function validateArchiveRelayRemovalReceipt(receipt: ArchiveRelayRemovalReceipt): void {
  const sortedRelays = (values: string[]) => Array.isArray(values) && values.length > 0
    && values.every(value => typeof value === 'string' && /^wss?:\/\/\S+$/.test(value))
    && canonical(values) === canonical([...new Set(values)].sort());
  const before = receipt.before, after = receipt.after;
  if (receipt.format !== 'iris-social/archive-relay-removal@1' || receipt.completed !== true
    || ![receipt.beforeCheckpointSha256, receipt.afterCheckpointSha256, receipt.previousNativeAuthoritySha256]
      .every(value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value))
    || receipt.beforeCheckpointSha256 === receipt.afterCheckpointSha256
    || !before?.policy || !after?.policy || !sortedRelays(before.policy.relays) || !sortedRelays(after.policy.relays)
    || !sortedRelays(receipt.removedRelays)
    || after.policy.relays.length >= before.policy.relays.length
    || after.policy.relays.some(relay => !before.policy.relays.includes(relay))
    || canonical(receipt.removedRelays) !== canonical(before.policy.relays.filter(relay => !after.policy.relays.includes(relay)))
    || canonical({ ...after, policy: before.policy }) !== canonical(before)
    || canonical({ ...after.policy, relays: before.policy.relays }) !== canonical(before.policy)) {
    throw new Error('Invalid archive relay removal receipt');
  }
}
