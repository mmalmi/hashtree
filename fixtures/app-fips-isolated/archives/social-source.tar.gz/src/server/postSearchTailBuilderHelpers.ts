import type { Hash, Store } from '@hashtree/core';
import type { RawEvent } from '../lib/nostr';

export function abortableNonDeletingStore(store: Store, signal?: AbortSignal): Store {
  return {
    put: async (hash, data) => {
      throwIfAborted(signal);
      return await store.put(hash, data);
    },
    get: async (hash: Hash) => {
      throwIfAborted(signal);
      return await store.get(hash);
    },
    has: async (hash) => {
      throwIfAborted(signal);
      return await store.has(hash);
    },
    // Snapshot transition validation must never delete a base snapshot blob.
    delete: async () => false,
    ...(store.watch ? {
      watch: (hash: Hash, callback: (data: Uint8Array) => void) => store.watch!(hash, callback),
    } : {}),
  };
}

export function compareSearchDocuments(left: RawEvent, right: RawEvent): number {
  return left.kind - right.kind
    || right.created_at - left.created_at
    || (left.id < right.id ? -1 : left.id > right.id ? 1 : 0);
}

export function encodedEventBytes(event: RawEvent): number {
  return new TextEncoder().encode(JSON.stringify(event)).length;
}

export function isTailEventEnvelope(value: unknown): value is RawEvent {
  if (!value || typeof value !== 'object') {
    return false;
  }
  const event = value as Partial<RawEvent>;
  return typeof event.id === 'string'
    && typeof event.pubkey === 'string'
    && Number.isSafeInteger(event.created_at)
    && Number(event.created_at) >= 0
    && Number.isSafeInteger(event.kind)
    && Number(event.kind) >= 0
    && Array.isArray(event.tags)
    && event.tags.every((tag) => Array.isArray(tag)
      && tag.every((item) => typeof item === 'string'))
    && typeof event.content === 'string'
    && typeof event.sig === 'string';
}

export function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw signal.reason ?? new DOMException('The operation was aborted', 'AbortError');
  }
}

export function positiveInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`Invalid tail builder ${name}`);
  }
  return value;
}

export function nonNegativeInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid tail builder ${name}`);
  }
  return value;
}

export function safeAdd(left: number, right: number, name: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result) || result < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return result;
}

export function validateTailPublisherId(value: string): void {
  if (!/^[0-9a-f]{64}$/.test(value)) {
    throw new Error('Tail builder publisherId must be a lowercase Nostr pubkey');
  }
}

export function validateTailTreeName(value: string): void {
  if (!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(value)) {
    throw new Error('Invalid post search pointer tree name');
  }
}
