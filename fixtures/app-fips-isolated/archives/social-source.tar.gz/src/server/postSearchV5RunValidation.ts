import type { CID } from '@hashtree/core';

export function comparePostSearchV5Strings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

export function postSearchV5Object(
  value: unknown,
  label: string,
): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value as Record<string, unknown>;
}

export function assertPostSearchV5ExactKeys(
  value: Record<string, unknown>,
  expected: readonly string[],
  label: string,
): void {
  const keys = Object.keys(value).sort(comparePostSearchV5Strings);
  if (JSON.stringify(keys) !== JSON.stringify([...expected].sort(comparePostSearchV5Strings))) {
    throw new Error(`Invalid post-search v5 ${label} fields`);
  }
}

export function postSearchV5Integer(value: unknown, label: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value as number;
}

export function postSearchV5PositiveInteger(value: unknown, label: string): number {
  const parsed = postSearchV5Integer(value, label);
  if (parsed === 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return parsed;
}

export function postSearchV5PositiveNumber(value: unknown, label: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value;
}

export function postSearchV5BoundedNumber(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isFinite(value)
    || value < minimum || value > maximum) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value;
}

export function postSearchV5NonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value;
}

export function assertPostSearchV5PublicCid(cid: CID, label: string): void {
  if (!(cid?.hash instanceof Uint8Array) || cid.hash.length !== 32 || cid.key !== undefined) {
    throw new Error(`Invalid public post-search v5 ${label} CID`);
  }
}

export function equalPostSearchV5Bytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}

export function parsePostSearchV5JsonObject(
  raw: string,
  label: string,
): Record<string, unknown> {
  try {
    return postSearchV5Object(JSON.parse(raw), label);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid post-search v5 ${label} JSON`);
    }
    throw error;
  }
}

export function parsePostSearchV5JsonArray(raw: string, label: string): unknown[] {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error(`Invalid post-search v5 ${label} JSON`);
  }
  if (!Array.isArray(value)) {
    throw new Error(`Invalid post-search v5 ${label}`);
  }
  return value;
}
