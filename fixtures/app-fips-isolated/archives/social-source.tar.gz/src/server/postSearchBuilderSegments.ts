import { nhashDecode, nhashEncode } from '@hashtree/core';
import {
  POST_SEARCH_VISIBLE_PROJECTION,
  type PostSearchSegmentInput,
} from '../lib/postSearch';

export interface PersistedPostSearchSegment {
  root: string;
  routingRoot: string | null;
  routingMappingCount: number;
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  documentCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export function serializePostSearchSegment(
  segment: PostSearchSegmentInput,
): PersistedPostSearchSegment {
  return {
    ...segment,
    root: nhashEncode(segment.root),
    routingRoot: segment.routingRoot ? nhashEncode(segment.routingRoot) : null,
  };
}

export function deserializePostSearchSegment(
  segment: PersistedPostSearchSegment,
): PostSearchSegmentInput {
  return {
    ...segment,
    root: nhashDecode(segment.root),
    routingRoot: segment.routingRoot ? nhashDecode(segment.routingRoot) : null,
  };
}

export function postSearchCoverageFromSegments(
  segments: readonly PostSearchSegmentInput[],
) {
  const populated = segments.filter((segment) => segment.documentCount > 0);
  return {
    eventCount: segments.reduce((sum, segment) => sum + segment.documentCount, 0),
    kinds: [...new Set(populated.flatMap((segment) => segment.kinds))].sort((a, b) => a - b),
    since: populated.length ? Math.min(...populated.map((segment) => segment.since as number)) : null,
    until: populated.length ? Math.max(...populated.map((segment) => segment.until as number)) : null,
  };
}
