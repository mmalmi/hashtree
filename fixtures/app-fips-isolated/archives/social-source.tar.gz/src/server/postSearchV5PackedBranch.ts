import type { Store } from '@hashtree/core';
import {
  POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES,
  POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES,
  encodePostSearchV5PackedPage,
  postSearchV5PackedPageEntryByteLength,
  type PostSearchV5PackedPageEntry,
  type PostSearchV5PackedPageKind,
} from './postSearchV5PackedPage';
import {
  createPostSearchV5PageRouterWriter,
  type PostSearchV5PageRouterSummary,
  type PostSearchV5PageRouterWriter,
} from './postSearchV5PageRouter';

export interface PostSearchV5PackedBranchSummary extends PostSearchV5PageRouterSummary {
  entryCount: number;
}

export interface PostSearchV5PackedBranchWriter {
  append(key: string, value: string): Promise<void>;
  finish(): Promise<PostSearchV5PackedBranchSummary | null>;
}

type PackedBranchWriterStatus = 'idle' | 'appending' | 'finishing' | 'finished' | 'failed';

class BoundedPackedBranchWriter implements PostSearchV5PackedBranchWriter {
  private readonly page: PostSearchV5PackedPageEntry[] = [];
  private pageByteLength = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES;
  private previousKey: string | null = null;
  private entryCount = 0;
  private pageCount = 0;
  private status: PackedBranchWriterStatus = 'idle';

  constructor(
    private readonly pageKind: PostSearchV5PackedPageKind,
    private readonly router: PostSearchV5PageRouterWriter,
    private readonly targetPageBytes: number,
  ) {}

  append(key: string, value: string): Promise<void> {
    const stateError = this.operationError('append');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'appending';
    return this.appendOne(key, value).then(
      () => { this.status = 'idle'; },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  finish(): Promise<PostSearchV5PackedBranchSummary | null> {
    const stateError = this.operationError('finish');
    if (stateError) {
      return Promise.reject(stateError);
    }
    this.status = 'finishing';
    return this.finishOnce().then(
      (summary) => {
        this.status = 'finished';
        return summary;
      },
      (error: unknown) => {
        this.status = 'failed';
        throw error;
      },
    );
  }

  private async appendOne(key: string, value: string): Promise<void> {
    const entryByteLength = postSearchV5PackedPageEntryByteLength(key, value);
    if (this.previousKey !== null && compareText(this.previousKey, key) >= 0) {
      throw new Error('Post-search v5 packed branch keys are duplicate or out of order');
    }
    if (this.page.length > 0 && (
      this.page.length === POST_SEARCH_V5_PACKED_PAGE_MAX_ENTRIES
      || this.pageByteLength + entryByteLength > this.targetPageBytes
    )) {
      await this.flushPage();
    }
    if (this.pageByteLength + entryByteLength > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
      throw new Error('Post-search v5 packed branch entry cannot fit a packed page');
    }
    this.page.push([key, value]);
    this.pageByteLength += entryByteLength;
    this.entryCount = safeAdd(this.entryCount, 1, 'entry count');
    this.previousKey = key;
  }

  private async finishOnce(): Promise<PostSearchV5PackedBranchSummary | null> {
    if (this.entryCount === 0) {
      return null;
    }
    await this.flushPage();
    const summary = await this.router.finish();
    if (summary.pageCount !== this.pageCount) {
      throw new Error('Post-search v5 packed branch page count is inconsistent');
    }
    return { ...summary, entryCount: this.entryCount };
  }

  private async flushPage(): Promise<void> {
    if (this.page.length === 0) {
      return;
    }
    const bytes = encodePostSearchV5PackedPage(this.pageKind, this.page);
    if (bytes.length !== this.pageByteLength) {
      throw new Error('Post-search v5 packed branch byte accounting is inconsistent');
    }
    await this.router.appendPage(bytes);
    this.page.length = 0;
    this.pageByteLength = POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES;
    this.pageCount = safeAdd(this.pageCount, 1, 'page count');
  }

  private operationError(operation: 'append' | 'finish'): Error | null {
    if (this.status === 'failed') {
      return new Error('Post-search v5 packed branch writer has failed');
    }
    if (this.status === 'finished' || this.status === 'finishing') {
      return operation === 'finish'
        ? new Error('Post-search v5 packed branch writer finish may only be called once')
        : new Error('Post-search v5 packed branch writer cannot append after finish');
    }
    if (this.status !== 'idle') {
      return new Error(`Post-search v5 packed branch writer cannot ${operation} while another operation is in progress`);
    }
    return null;
  }
}

export function createPostSearchV5PackedBranchWriter(
  store: Store,
  pageKind: PostSearchV5PackedPageKind,
  options: { targetPageBytes?: number } = {},
): PostSearchV5PackedBranchWriter {
  const targetPageBytes = options.targetPageBytes ?? POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES;
  if (!Number.isSafeInteger(targetPageBytes)
    || targetPageBytes <= POST_SEARCH_V5_PACKED_PAGE_HEADER_BYTES
    || targetPageBytes > POST_SEARCH_V5_PACKED_PAGE_MAX_BYTES) {
    throw new Error('Post-search v5 packed branch targetPageBytes is out of range');
  }
  return new BoundedPackedBranchWriter(
    pageKind,
    createPostSearchV5PageRouterWriter(store, pageKind),
    targetPageBytes,
  );
}

function safeAdd(left: number, right: number, label: string): number {
  const result = left + right;
  if (!Number.isSafeInteger(result)) {
    throw new Error(`Post-search v5 packed branch ${label} exceeds safe integer capacity`);
  }
  return result;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
