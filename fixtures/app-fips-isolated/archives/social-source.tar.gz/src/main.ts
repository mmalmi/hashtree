import 'virtual:uno.css';
import { flushSync, mount } from 'svelte';
import App from './App.svelte';
import './app.css';
import { settingsStore } from './lib/settings';
import { watchSystemTheme } from './lib/theme';
import { registerAppShellServiceWorker } from './lib/appShellServiceWorker';
import { startPrivateContactSync } from './lib/privateContactSync';
import { waitForNextBrowserPaint } from './lib/asyncTiming';

watchSystemTheme(() => settingsStore.getState().appearance.theme);
void import('./lib/workerClient')
  .then(({ getWorkerClient }) => getWorkerClient())
  .catch((error) => {
    console.warn('Failed to warm the social data worker', error);
  });

const app = mount(App, {
  target: document.getElementById('app')!,
});
// Keep the first frame visible until Svelte has committed its replacement.
flushSync();
document.getElementById('iris-boot-shell')?.remove();
startPrivateContactSync();
void waitForNextBrowserPaint().then(() => {
  void registerAppShellServiceWorker();
  void import('./lib/browserNotifications')
    .then(({ startBrowserNotifications }) => startBrowserNotifications())
    .catch((error) => {
      console.warn('Failed to start browser notifications', error);
    });
});

export default app;
