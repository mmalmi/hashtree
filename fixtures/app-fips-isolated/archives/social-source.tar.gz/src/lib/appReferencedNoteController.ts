import type { BoundedHydrationScheduler, RouteHydrationPromiseCache } from './boundedHydrationScheduler';
import type { createKnownNotesCache } from './appDataUtils';
import type { AppCombinedState } from './appState';
import { resolvePreferredProfile } from './appProfiles';
import { getThreadHydrationRoots } from './appViewState';
import { extractNoteEmbeds } from './noteContent';
import { decodeNostrEventReference, type ProfileRecord, type RawEvent } from './nostr';
import {
  loadEventByRef,
  loadProfilesForPubkeys,
  resolveProfileEventIndexRoot,
} from './nostrIndex';
import { preferNewerProfileRecord } from './profileRecords';
import { loadReferencedNoteEvent, type ReferencedNotePreview } from './referencedNote';
import { socialDataPlane } from './socialDataPlane';

type ReferencedNoteControllerDeps = {
  state: AppCombinedState;
  knownNotesCache: ReturnType<typeof createKnownNotesCache>;
  previewCache: Map<string, ReferencedNotePreview>;
  previewPromises: RouteHydrationPromiseCache<ReferencedNotePreview | null>;
  scheduler: BoundedHydrationScheduler;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  getResolvedProfiles: () => Map<string, ProfileRecord>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
};

export function noteHasMedia(event: RawEvent): boolean {
  return extractNoteEmbeds(event.content, event.tags, event.kind).length > 0;
}

export function createAppReferencedNoteController(deps: ReferencedNoteControllerDeps) {
  const { state } = deps;

  function getThreadReferenceEvents(): RawEvent[] {
    if (!state.threadPage) {
      return [];
    }
    const events = [
      state.threadPage.note,
      state.threadPage.root,
      state.threadPage.parent,
      ...state.threadPage.context,
    ];
    return events.filter((event, index): event is RawEvent => (
      Boolean(event) && events.findIndex((candidate) => candidate?.id === event?.id) === index
    ));
  }

  function getKnownNoteByRef(ref: string): RawEvent | null {
    const event = deps.knownNotesCache.getByRef(ref);
    return event && socialDataPlane.isExternalEventVisible(event)
      ? event
      : null;
  }

  async function resolveReferencedNote(ref: string): Promise<ReferencedNotePreview | null> {
    const trimmed = ref.trim();
    const normalizedRef = trimmed.startsWith('nostr:') ? trimmed.slice('nostr:'.length) : trimmed;
    if (!normalizedRef) {
      return null;
    }

    const cachedPreview = deps.previewCache.get(normalizedRef);
    if (cachedPreview) {
      return cachedPreview;
    }
    const cachedPromise = deps.previewPromises.get(normalizedRef);
    if (cachedPromise) {
      return await cachedPromise;
    }

    const resolutionToken = state.loadToken;
    const isCurrent = () => resolutionToken === state.loadToken;
    const promise = deps.previewPromises.track(normalizedRef, resolvePreview(normalizedRef, isCurrent));
    const preview = await promise;
    if (isCurrent() && preview) {
      deps.previewCache.set(normalizedRef, preview);
    }
    return preview;
  }

  async function resolvePreview(
    normalizedRef: string,
    isCurrent: () => boolean,
  ): Promise<ReferencedNotePreview | null> {
    const scheduled = await deps.scheduler.run(async () => {
      let event = getKnownNoteByRef(normalizedRef);
      if (!event && !state.root) {
        return null;
      }
      if (!event && state.root) {
        const roots = getThreadHydrationRoots(
          state.root,
          state.profilePersonalRoot,
          state.viewerPersonalRoot,
          state.threadPersonalRoot,
        );
        const decoded = decodeNostrEventReference(normalizedRef);
        const referencedPubkey = decoded?.type === 'nevent'
          ? decoded.author
          : decoded?.type === 'naddr'
            ? decoded.pubkey
            : null;
        event = await loadReferencedNoteEvent({
          roots,
          ref: normalizedRef,
          referencedPubkey,
          loadFromRoots: loadEventByRef,
          resolvePersonalRoot: resolveProfileEventIndexRoot,
        });
        if (event) {
          deps.cacheKnownNotes([event]);
        }
      }
      return event ? buildPreview(normalizedRef, event, isCurrent) : null;
    }, { isCurrent, priority: 'foreground' });
    return scheduled.status === 'completed' ? scheduled.value : null;
  }

  function buildPreview(
    normalizedRef: string,
    event: RawEvent,
    isCurrent: () => boolean,
  ): ReferencedNotePreview {
    const cachedProfile = resolvePreferredProfile(
      event.pubkey,
      deps.getResolvedProfiles().get(event.pubkey) ?? null,
    );
    const profileRoot = state.root
      ?? state.profilePersonalRoot
      ?? state.viewerPersonalRoot
      ?? state.threadPersonalRoot;
    if (profileRoot) {
      void hydratePreviewProfile(profileRoot, normalizedRef, event, cachedProfile, isCurrent);
    }
    return { event, profile: cachedProfile };
  }

  async function hydratePreviewProfile(
    root: NonNullable<AppCombinedState['root']>,
    normalizedRef: string,
    event: RawEvent,
    cachedProfile: ProfileRecord | null,
    isCurrent: () => boolean,
  ): Promise<void> {
    try {
      const result = await deps.scheduler.run(
        async () => await loadProfilesForPubkeys(root, [event.pubkey]),
        { isCurrent },
      );
      if (result.status !== 'completed') {
        return;
      }
      const profile = preferNewerProfileRecord(
        cachedProfile,
        result.value.get(event.pubkey) ?? null,
      );
      if (profile) {
        deps.mergeCachedProfiles(new Map([[event.pubkey, profile]]));
        deps.previewCache.set(normalizedRef, { event, profile });
      }
    } catch (error) {
      console.warn('Failed to hydrate referenced-note profile', error);
    }
  }

  return { getKnownNoteByRef, getThreadReferenceEvents, resolveReferencedNote };
}
