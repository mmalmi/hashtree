import type { BoundedHydrationScheduler, RouteHydrationPromiseCache } from './boundedHydrationScheduler';
import type { createKnownNotesCache } from './appDataUtils';
import type { AppCombinedState } from './appState';
import { resolvePreferredProfile } from './appProfiles';
import { getThreadHydrationRoots } from './appViewState';
import { extractNoteEmbeds } from './noteContent';
import { decodeNostrEventReference, pubkeyToNpub, type ProfileRecord, type RawEvent } from './nostr';
import {
  loadEventByRef,
  loadProfilesForPubkeys,
  resolveProfileEventIndexRoot,
} from './nostrIndex';
import { preferNewerProfileRecord } from './profileRecords';
import { loadReferencedNoteEvent, readPublicReferencedNote, readReferencedNoteArchives, type ReferencedNotePreview } from './referencedNote';
import { socialDataPlane } from './socialDataPlane';
import { queryBrowserArchiveRoot } from './browserEventReadRouter';
import { createReferencedNoteWatches } from './referencedNoteWatches';
import { createWorkerRelayTransport } from './workerRelayTransport';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { settingsStore } from './settings';
import { isNewerReplaceableEvent } from './socialRepository';
import type { CID } from '@hashtree/core';
import { getCachedProfileEventIndexRoot } from './nostrIndexRoots';
import { createPublishedRootEventCandidateWatch } from './treeRef';
import { ROOT_RESOLVE_TIMEOUT_MS } from './config';
import type { NostrFilter } from 'nostr-pubsub';

type ReferencedNoteControllerDeps = {
  state: AppCombinedState;
  knownNotesCache: ReturnType<typeof createKnownNotesCache>;
  previewCache: Map<string, ReferencedNotePreview>;
  previewPromises: RouteHydrationPromiseCache<ReferencedNotePreview | null>;
  scheduler: BoundedHydrationScheduler;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  getResolvedProfiles: () => Map<string, ProfileRecord>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
};

export function noteHasMedia(event: RawEvent): boolean {
  return extractNoteEmbeds(event.content, event.tags, event.kind).length > 0;
}

export function createAppReferencedNoteController(deps: ReferencedNoteControllerDeps) {
  const { state } = deps;

  function getThreadReferenceEvents(): RawEvent[] {
    if (!state.threadPage) {
      return [];
    }
    const events = [
      state.threadPage.note,
      state.threadPage.root,
      state.threadPage.parent,
      ...state.threadPage.context,
    ];
    return events.filter((event, index): event is RawEvent => (
      Boolean(event) && events.findIndex((candidate) => candidate?.id === event?.id) === index
    ));
  }

  function getKnownNoteByRef(ref: string): RawEvent | null {
    const event = deps.knownNotesCache.getByRef(ref);
    return event && socialDataPlane.isExternalEventVisible(event)
      ? event
      : null;
  }

  async function resolveReferencedNote(ref: string): Promise<ReferencedNotePreview | null> {
    const trimmed = ref.trim();
    const normalizedRef = trimmed.startsWith('nostr:') ? trimmed.slice('nostr:'.length) : trimmed;
    if (!normalizedRef) {
      return null;
    }

    const cachedPreview = deps.previewCache.get(normalizedRef);
    if (cachedPreview && socialDataPlane.isExternalEventVisible(cachedPreview.event)) {
      return cachedPreview;
    }
    const cachedPromise = deps.previewPromises.get(normalizedRef);
    if (cachedPromise) {
      return await cachedPromise;
    }

    const resolutionToken = state.loadToken;
    const isCurrent = () => resolutionToken === state.loadToken;
    const promise = deps.previewPromises.track(normalizedRef, resolvePreview(normalizedRef, isCurrent));
    const preview = await promise;
    if (isCurrent() && preview) {
      deps.previewCache.set(normalizedRef, preview);
    }
    return preview;
  }

  async function resolvePreview(
    normalizedRef: string,
    isCurrent: () => boolean,
  ): Promise<ReferencedNotePreview | null> {
    const scheduled = await deps.scheduler.run(async (signal) => {
      let event = getKnownNoteByRef(normalizedRef);
      if (!event) {
        const roots = getThreadHydrationRoots(
          state.root,
          state.profilePersonalRoot,
          state.viewerPersonalRoot,
          state.threadPersonalRoot,
        );
        if (roots.length > 0) {
          const decoded = decodeNostrEventReference(normalizedRef);
          const referencedPubkey = decoded?.type === 'nevent'
            ? decoded.author
            : decoded?.type === 'naddr'
              ? decoded.pubkey
              : null;
          event = await loadReferencedNoteEvent({
            roots,
            ref: normalizedRef,
            referencedPubkey,
            loadFromRoots: loadEventByRef,
            resolvePersonalRoot: resolveProfileEventIndexRoot,
          });
        } else {
          event = await readPublicReferencedNote(normalizedRef, signal);
        }
        if (event) {
          deps.cacheKnownNotes([event]);
        }
      }
      return event ? buildPreview(normalizedRef, event, isCurrent) : null;
    }, { isCurrent, priority: 'foreground' });
    return scheduled.status === 'completed' ? scheduled.value : null;
  }

  function buildPreview(
    normalizedRef: string,
    event: RawEvent,
    isCurrent: () => boolean,
  ): ReferencedNotePreview {
    const cachedProfile = resolvePreferredProfile(
      event.pubkey,
      deps.getResolvedProfiles().get(event.pubkey) ?? null,
    );
    const profileRoot = state.root
      ?? state.profilePersonalRoot
      ?? state.viewerPersonalRoot
      ?? state.threadPersonalRoot;
    if (profileRoot) {
      void hydratePreviewProfile(profileRoot, normalizedRef, event, cachedProfile, isCurrent);
    }
    return { event, profile: cachedProfile };
  }

  async function hydratePreviewProfile(
    root: NonNullable<AppCombinedState['root']>,
    normalizedRef: string,
    event: RawEvent,
    cachedProfile: ProfileRecord | null,
    isCurrent: () => boolean,
  ): Promise<void> {
    try {
      const result = await deps.scheduler.run(
        async () => await loadProfilesForPubkeys(root, [event.pubkey]),
        { isCurrent },
      );
      if (result.status !== 'completed') {
        return;
      }
      const profile = preferNewerProfileRecord(
        cachedProfile,
        result.value.get(event.pubkey) ?? null,
      );
      if (profile) {
        deps.mergeCachedProfiles(new Map([[event.pubkey, profile]]));
        deps.previewCache.set(normalizedRef, { event, profile });
      }
    } catch (error) {
      console.warn('Failed to hydrate referenced-note profile', error);
    }
  }

  async function readIndex(root: CID | null, filter: NostrFilter, signal: AbortSignal, deliver: (event: RawEvent) => void) {
    await deps.scheduler.run(async taskSignal => {
      const active = AbortSignal.any([signal, taskSignal]);
      const result = await queryBrowserArchiveRoot(root, [filter], { limit: 1, signal: active }, events => {
        if (!active.aborted) { for (const event of events) { deliver(event); } }
      });
      if (!active.aborted) { for (const { event } of result.events) { deliver(event); } }
    }, { isCurrent: () => !signal.aborted, priority: 'foreground' });
  }
  const watches = createReferencedNoteWatches({
    known({ key, ref, filter }) {
      const stored = filter.ids ? socialDataPlane.getEvent(key) : socialDataPlane.getEventByCoordinate(key);
      const cached = getKnownNoteByRef(ref);
      return stored && (!cached || isNewerReplaceableEvent(stored, cached)) ? stored : cached;
    },
    visible: event => socialDataPlane.isExternalEventVisible(event),
    preview(ref, event, active) {
      deps.cacheKnownNotes([event]);
      return buildPreview(ref, event, active);
    },
    async archive({ filter, author }, signal, deliver) {
      const roots = getThreadHydrationRoots(state.root, state.profilePersonalRoot, state.viewerPersonalRoot, state.threadPersonalRoot);
      await readReferencedNoteArchives(roots, author, signal,
        root => readIndex(root, filter, signal, deliver), getCachedProfileEventIndexRoot);
    },
    subscribe(relays, { filter, author }, deliver) {
      const transport = createWorkerRelayTransport({ getRelays: () => relays });
      const note = transport.subscribe([filter], { onEvent: deliver }, { closeOnEose: false });
      const controller = new AbortController();
      const stopRoot = author && createPublishedRootEventCandidateWatch(transport, { eventsAlreadyAdmitted: true })(
        { kind: 'mutable', npub: pubkeyToNpub(author), path: 'nostr-event-index' },
        candidate => {
          if (candidate && !controller.signal.aborted) {
            void readIndex(candidate.resolution.root, filter, controller.signal, deliver).catch(() => {});
          }
        }, ROOT_RESOLVE_TIMEOUT_MS,
      );
      return { close() { controller.abort(); note.close(); if (stopRoot) { stopRoot(); } } };
    },
    observeLocal: sync => socialDataPlane.subscribe(({ events }) => sync(events)),
    observeRelays(sync) {
      const update = () => sync(settingsStore.getState().network.relayHomeFeedReads && navigator.onLine && !document.hidden
        ? getConfiguredNostrRelays() : []);
      const stop = settingsStore.subscribe(update);
      window.addEventListener('online', update);
      window.addEventListener('offline', update);
      document.addEventListener('visibilitychange', update);
      return () => {
        stop();
        window.removeEventListener('online', update);
        window.removeEventListener('offline', update);
        document.removeEventListener('visibilitychange', update);
      };
    },
  });
  let lastRoots: (CID | null)[] = [];
  let lastKnown = -1;
  function syncQuoteSources(knownVersion: number, ...roots: (CID | null)[]) {
    if (knownVersion !== lastKnown) {
      lastKnown = knownVersion;
      watches.refreshKnownNotes();
    }
    if (roots.some((root, i) => root !== lastRoots[i])) {
      lastRoots = roots;
      watches.refreshArchiveRoots();
    }
  }
  return { getKnownNoteByRef, getThreadReferenceEvents, resolveReferencedNote, watchReferencedNote: watches.watchReferencedNote, syncQuoteSources };
}
