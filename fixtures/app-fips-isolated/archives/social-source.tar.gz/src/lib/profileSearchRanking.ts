import { getProfileSubtitle, type ProfileRecord } from './nostr';
import { overlayProfileRecord } from './profileRecords';
import {
  normalizeProfileSearchText,
  profileSearchIdentityAliases,
  profileSearchNip05LocalPart,
} from './profileSearchIdentity';

export type ProfileSearchRank = {
  textScore: number;
  socialScore: number;
  score: number;
};

export function mergeProfileSearchRecords(profiles: readonly ProfileRecord[]): ProfileRecord[] {
  const merged = new Map<string, ProfileRecord>();
  profiles.forEach((profile) => {
    const current = merged.get(profile.pubkey);
    merged.set(profile.pubkey, current
      ? overlayProfileRecord(profile, current) ?? profile
      : profile);
  });
  return [...merged.values()];
}

function profileSocialScore(_profile: ProfileRecord): number {
  // Viewer-rooted metrics are not rankable until they come from a bounded,
  // current worker query rather than a renderer-local graph snapshot.
  return 0;
}

function words(value: string): string[] {
  return value.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
}

function boundedDamerauEditDistance(left: string, right: string, maximum: number): number | null {
  if (Math.abs(left.length - right.length) > maximum) {return null;}

  let previousPrevious: number[] | null = null;
  let previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  for (let leftIndex = 1; leftIndex <= left.length; leftIndex += 1) {
    const current = [leftIndex];
    let rowMinimum = current[0] ?? leftIndex;
    for (let rightIndex = 1; rightIndex <= right.length; rightIndex += 1) {
      const substitution = previous[rightIndex - 1]! + (left[leftIndex - 1] === right[rightIndex - 1] ? 0 : 1);
      let value = Math.min(
        previous[rightIndex]! + 1,
        current[rightIndex - 1]! + 1,
        substitution,
      );
      if (
        previousPrevious
        && leftIndex > 1
        && rightIndex > 1
        && left[leftIndex - 1] === right[rightIndex - 2]
        && left[leftIndex - 2] === right[rightIndex - 1]
      ) {
        value = Math.min(value, previousPrevious[rightIndex - 2]! + 1);
      }
      current.push(value);
      rowMinimum = Math.min(rowMinimum, value);
    }
    if (rowMinimum > maximum) {return null;}
    previousPrevious = previous;
    previous = current;
  }

  const distance = previous[right.length] ?? maximum + 1;
  return distance <= maximum ? distance : null;
}

function fuzzyTextScore(queryWords: string[], fieldWords: string[]): number {
  if (queryWords.length === 0 || fieldWords.length === 0) {return 0;}
  let totalDistance = 0;

  for (const queryWord of queryWords) {
    if (queryWord.length < 3) {return 0;}
    const maximum = queryWord.length >= 7 ? 2 : 1;
    let best: number | null = null;
    for (const fieldWord of fieldWords) {
      const distance = boundedDamerauEditDistance(queryWord, fieldWord, maximum);
      if (distance !== null && (best === null || distance < best)) {best = distance;}
    }
    if (best === null) {return 0;}
    totalDistance += best;
  }

  return Math.max(1_200, 1_800 - totalDistance * 200);
}

export function profileSearchRank(profile: ProfileRecord, query: string): ProfileSearchRank {
  const normalizedQuery = normalizeProfileSearchText(query);
  if (!normalizedQuery) {return { textScore: 0, socialScore: profileSocialScore(profile), score: 0 };}

  const identifierFields = [profile.npub, profile.pubkey]
    .map(normalizeProfileSearchText)
    .filter(Boolean);
  const nip05Fields = [profile.nip05, profileSearchNip05LocalPart(profile.nip05)]
    .map(normalizeProfileSearchText)
    .filter(Boolean);
  if ([...normalizedQuery].length === 1) {
    const names = [profile.displayName, profile.name, ...profileSearchIdentityAliases(profile), ...nip05Fields]
      .map(normalizeProfileSearchText).filter(Boolean);
    if (!names.some((name) => name.startsWith(normalizedQuery)
      || words(name).some((word) => word.startsWith(normalizedQuery)))) {
      return { textScore: 0, socialScore: profileSocialScore(profile), score: 0 };
    }
  }
  const identityFields = [
    profile.displayName,
    profile.name,
    ...profileSearchIdentityAliases(profile),
    getProfileSubtitle(profile, profile.pubkey),
  ].map(normalizeProfileSearchText).filter(Boolean);
  const fields = [...identityFields, ...nip05Fields, ...identifierFields];
  const queryWords = words(normalizedQuery);
  const fieldWords = [...new Set(fields.flatMap(words))];
  let textScore = 0;

  if (identifierFields.includes(normalizedQuery)) {
    textScore = 14_000;
  } else if (nip05Fields.includes(normalizedQuery)) {
    textScore = 12_000;
  } else if (identityFields.includes(normalizedQuery)) {
    textScore = 10_000;
  } else if (queryWords.length === 1 && fieldWords.includes(normalizedQuery)) {
    textScore = 8_500;
  } else if (fields.some((field) => field.startsWith(normalizedQuery))) {
    textScore = 7_000;
  } else if (queryWords.every((term) => fieldWords.some((fieldWord) => fieldWord.startsWith(term)))) {
    textScore = 5_500;
  } else if (queryWords.every((term) => fields.some((field) => field.includes(term)))) {
    textScore = 3_500;
  } else {
    textScore = fuzzyTextScore(queryWords, fieldWords);
  }

  const socialScore = profileSocialScore(profile);
  return {
    textScore,
    socialScore,
    score: textScore > 0 ? textScore + socialScore : 0,
  };
}

function compareRankedProfiles(
  left: { profile: ProfileRecord; rank: ProfileSearchRank },
  right: { profile: ProfileRecord; rank: ProfileSearchRank },
): number {
  return (
    right.rank.textScore - left.rank.textScore
    || right.rank.socialScore - left.rank.socialScore
    || (right.profile.createdAt ?? 0) - (left.profile.createdAt ?? 0)
    || left.profile.pubkey.localeCompare(right.profile.pubkey)
  );
}

export function sortProfileSearchMatches(profiles: ProfileRecord[], query: string): ProfileRecord[] {
  return profiles
    .map((profile) => ({ profile, rank: profileSearchRank(profile, query) }))
    .filter((entry) => entry.rank.textScore > 0)
    .sort(compareRankedProfiles)
    .map((entry) => entry.profile);
}
