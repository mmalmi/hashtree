export type ProfileSearchAddress = { name: string; domain: string };

const DNS_LABEL = '[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?';
const ADDRESS_PATTERN = new RegExp(
  `^([a-z0-9_.-]{1,64})@((?:${DNS_LABEL}\\.)+${DNS_LABEL})$`,
);
const IRIS_LINK_PATTERN = /^(?:https:\/\/)?iris\.to\/([a-z0-9_.]{1,15})\/?$/;
const PROFILE_ADDRESS_TIMEOUT_MS = 5_000;

export function parseProfileSearchAddress(query: string): ProfileSearchAddress | null {
  const normalized = query.trim().toLowerCase();
  const irisLink = IRIS_LINK_PATTERN.exec(normalized);
  if (irisLink) {
    return { name: irisLink[1]!, domain: 'iris.to' };
  }
  const address = ADDRESS_PATTERN.exec(normalized);
  if (!address || address[2]!.length > 253 || /^\d+(?:\.\d+)+$/.test(address[2]!)) {
    return null;
  }
  return { name: address[1]!, domain: address[2]! };
}

export async function resolveProfileSearchAddress(
  address: ProfileSearchAddress,
  signal: AbortSignal,
): Promise<string | null> {
  const url = new URL('/.well-known/nostr.json', `https://${address.domain}`);
  url.searchParams.set('name', address.name);
  const response = await fetch(url, {
    credentials: 'omit',
    redirect: 'error',
    referrerPolicy: 'no-referrer',
    signal: AbortSignal.any([signal, AbortSignal.timeout(PROFILE_ADDRESS_TIMEOUT_MS)]),
  });
  // A client error means the name is not listed (iris.to answers 418);
  // timeouts, rate limits and server errors stay retryable.
  if (response.status >= 400 && response.status < 500 && response.status !== 408 && response.status !== 429) {
    return null;
  }
  if (!response.ok) { throw new Error(`NIP-05 lookup failed with ${response.status}`); }
  const json = await response.json() as { names?: Record<string, unknown> } | null;
  const value = json?.names && Object.hasOwn(json.names, address.name) ? json.names[address.name] : null;
  return typeof value === 'string' && /^[a-f0-9]{64}$/.test(value) ? value : null;
}
