import type { ProfileRecord } from './nostr';
import { preferNewerProfileRecord } from './profileRecords';

export function mergeProfilesIntoMap(
  currentProfiles: Map<string, ProfileRecord>,
  profiles: Map<string, ProfileRecord>,
): Map<string, ProfileRecord> {
  if (profiles.size === 0) {
    return currentProfiles;
  }

  const nextProfiles = new Map(currentProfiles);
  for (const [pubkey, profile] of profiles) {
    const mergedProfile = preferNewerProfileRecord(nextProfiles.get(pubkey) ?? null, profile);
    if (mergedProfile) {
      nextProfiles.set(pubkey, mergedProfile);
    }
  }
  return nextProfiles;
}

export function getProfilesSubset(
  profiles: Map<string, ProfileRecord>,
  pubkeys: string[],
): Map<string, ProfileRecord> {
  const subset = new Map<string, ProfileRecord>();

  for (const pubkey of pubkeys) {
    const profile = profiles.get(pubkey);
    if (profile) {
      subset.set(pubkey, profile);
    }
  }

  return subset;
}

export function resolvePreferredProfile(
  pubkey: string,
  ...sources: Array<ProfileRecord | null | undefined>
): ProfileRecord | null {
  return sources.reduce<ProfileRecord | null>(
    (resolvedProfile, candidateProfile) => preferNewerProfileRecord(resolvedProfile, candidateProfile),
    null,
  );
}
