import { isReplyEvent, type RawEvent } from './nostr';
import type { HomeTab } from './routes';
import {
  compareSocialEventsNewestFirst,
  getSocialEventCoordinate,
  type SocialEventTombstone,
} from './socialRepository';

export const MAX_BUFFERED_LIVE_HOME_EVENTS = 256;

export type LiveHomeFeedBuffer = {
  events: RawEvent[];
  stableNotes: RawEvent[];
};

export type LiveHomeFeedEligibilityOptions = {
  authors?: readonly string[];
  hasMedia: (event: RawEvent) => boolean;
  mutedPubkeys: ReadonlySet<string>;
  postKinds: readonly number[];
  tab: HomeTab;
  viewerPubkey: string | null;
};

export function isLiveHomeFeedEventEligible(
  event: RawEvent,
  options: LiveHomeFeedEligibilityOptions,
): boolean {
  return options.tab !== 'notifications'
    && options.postKinds.includes(event.kind)
    && (options.tab !== 'for-you' || !isReplyEvent(event))
    && (options.tab !== 'media' || options.hasMedia(event))
    && (event.pubkey === options.viewerPubkey || !options.mutedPubkeys.has(event.pubkey))
    && (options.authors === undefined || options.authors.includes(event.pubkey));
}

export function createLiveHomeFeedBuffer(): LiveHomeFeedBuffer {
  return { events: [], stableNotes: [] };
}

export function clearLiveHomeFeedBuffer(): LiveHomeFeedBuffer {
  return createLiveHomeFeedBuffer();
}

export function bufferLiveHomeFeedEvent(
  state: LiveHomeFeedBuffer,
  event: RawEvent,
  visibleNotes: RawEvent[],
): LiveHomeFeedBuffer {
  if (state.events.some((candidate) => candidate.id === event.id)) {
    return state;
  }
  const events = [...state.events, event]
    .sort(compareSocialEventsNewestFirst)
    .slice(0, MAX_BUFFERED_LIVE_HOME_EVENTS);
  return {
    events,
    stableNotes: state.events.length > 0 ? state.stableNotes : [...visibleNotes],
  };
}

export function getBufferedLiveHomeFeedEvents(
  state: LiveHomeFeedBuffer,
  isEligible: (event: RawEvent) => boolean = () => true,
): RawEvent[] {
  return state.events.filter(isEligible).sort(compareSocialEventsNewestFirst);
}

/**
 * Freeze already painted notes while a live batch is pending. Pagination may
 * still append events older than the stable tail, and deletion tombstones are
 * applied immediately. Superseded stable events remain until reveal so an
 * addressable replacement cannot make a card disappear before it is shown.
 */
export function projectBufferedLiveHomeFeed(
  mergedNotes: RawEvent[],
  state: LiveHomeFeedBuffer,
  tombstones: readonly SocialEventTombstone[],
): RawEvent[] {
  if (state.events.length === 0) {
    return mergedNotes;
  }

  const blockedIds = new Set(state.events.map((event) => event.id));
  const stableNotes = state.stableNotes.filter((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return !tombstones.some((tombstone) => (
      tombstone.targetType === 'event'
        ? tombstone.target === event.id.toLowerCase()
        : coordinate !== null && tombstone.target === coordinate
    ));
  });
  const stableIds = new Set(stableNotes.map((event) => event.id));
  const stableTail = stableNotes.at(-1) ?? null;
  const appended = mergedNotes.filter((event) => (
    !blockedIds.has(event.id)
    && !stableIds.has(event.id)
    && (!stableTail || compareSocialEventsNewestFirst(event, stableTail) > 0)
  ));
  return [...stableNotes, ...appended];
}
