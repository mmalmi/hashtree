import { isReplyEvent, type RawEvent } from './nostr';
import type { HomeTab } from './routes';
import { isMutedEvent } from './muteLists';
import {
  compareSocialEventsNewestFirst,
  getSocialEventCoordinate,
  type SocialEventTombstone,
} from './socialRepository';

export const MAX_BUFFERED_LIVE_HOME_EVENTS = 256;

export type LiveHomeFeedBuffer = {
  events: RawEvent[];
  stableNotes: RawEvent[];
};

export type LiveHomeFeedEligibilityOptions = {
  authors?: readonly string[];
  hasMedia: (event: RawEvent) => boolean;
  /** Hidden identities; followed authors keep posts that mention them. */
  mutedPubkeys: ReadonlySet<string>;
  viewerFollows?: ReadonlySet<string>;
  postKinds: readonly number[];
  tab: HomeTab;
  viewerPubkey: string | null;
};

export function isLiveHomeFeedEventEligible(
  event: RawEvent,
  options: LiveHomeFeedEligibilityOptions,
): boolean {
  return options.tab !== 'popular' && options.tab !== 'notifications'
    && options.postKinds.includes(event.kind)
    && (options.tab !== 'for-you' || !isReplyEvent(event))
    && (options.tab !== 'media' || options.hasMedia(event))
    && !isMutedEvent(event, options.mutedPubkeys, options.viewerPubkey, {
      hideMentions: true, explicitAuthors: options.viewerFollows,
    })
    && (options.authors === undefined || options.authors.includes(event.pubkey));
}

export function createLiveHomeFeedBuffer(): LiveHomeFeedBuffer {
  return { events: [], stableNotes: [] };
}

export function clearLiveHomeFeedBuffer(): LiveHomeFeedBuffer {
  return createLiveHomeFeedBuffer();
}

export function bufferLiveHomeFeedEvents(
  state: LiveHomeFeedBuffer,
  arrivals: readonly RawEvent[],
  displayedNotes: readonly RawEvent[],
  protectedCount: number,
  ranked = false,
): LiveHomeFeedBuffer {
  const protectedNotes = displayedNotes.slice(0, protectedCount);
  const protectedAddresses = new Set(protectedNotes.flatMap((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return coordinate ? [coordinate] : [];
  }));
  const byId = new Map(state.events.map((event) => [event.id, event]));
  for (const event of arrivals) {
    const coordinate = getSocialEventCoordinate(event);
    const replacesProtectedCard = coordinate && protectedAddresses.has(coordinate);
    const insertsBeforeBoundary = !ranked && (protectedCount > displayedNotes.length
      || protectedNotes.some((note) => compareSocialEventsNewestFirst(event, note) < 0));
    if (replacesProtectedCard || insertsBeforeBoundary) { byId.set(event.id, event); }
  }
  const extendsProtectedPrefix = protectedNotes.length > state.stableNotes.length;
  if (byId.size === 0 || (byId.size === state.events.length && !extendsProtectedPrefix)) { return state; }
  return {
    events: [...byId.values()].sort(compareSocialEventsNewestFirst).slice(0, MAX_BUFFERED_LIVE_HOME_EVENTS),
    stableNotes: extendsProtectedPrefix ? protectedNotes : state.stableNotes,
  };
}

export function getBufferedLiveHomeFeedEvents(
  state: LiveHomeFeedBuffer,
  isEligible: (event: RawEvent) => boolean = () => true,
): RawEvent[] {
  return state.events.filter(isEligible).sort(compareSocialEventsNewestFirst);
}

/**
 * Hide only the held arrivals; independent tail changes and tombstones still
 * apply. A held addressable revision keeps the previously painted card.
 */
export function projectBufferedLiveHomeFeed(
  mergedNotes: RawEvent[],
  state: LiveHomeFeedBuffer,
  tombstones: readonly SocialEventTombstone[],
  ranked = false,
): RawEvent[] {
  if (state.events.length === 0) {
    return mergedNotes;
  }

  const blockedIds = new Set(state.events.map((event) => event.id));
  const stableNotes = state.stableNotes.filter((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return !tombstones.some((tombstone) => (
      tombstone.targetType === 'event'
        ? tombstone.target === event.id.toLowerCase()
        : coordinate !== null && tombstone.target === coordinate
    ));
  });
  const stableByAddress = new Map(stableNotes.flatMap((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return coordinate ? [[coordinate, event] as const] : [];
  }));
  const allowed = mergedNotes.flatMap((event) => {
    if (!blockedIds.has(event.id)) { return [event]; }
    const coordinate = getSocialEventCoordinate(event);
    const previous = coordinate ? stableByAddress.get(coordinate) : undefined;
    return previous ? [previous] : [];
  });
  if (ranked) { return allowed; }

  const seenIds = new Set(allowed.map((event) => event.id));
  const seenAddresses = new Set(allowed.flatMap((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return coordinate ? [coordinate] : [];
  }));
  // A ranked or capped source can temporarily leave out a previously painted
  // card while a held arrival occupies that space in the underlying snapshot.
  for (const event of stableNotes) {
    const coordinate = getSocialEventCoordinate(event);
    if (!seenIds.has(event.id) && (!coordinate || !seenAddresses.has(coordinate))) { allowed.push(event); }
  }
  return allowed.sort(compareSocialEventsNewestFirst);
}
