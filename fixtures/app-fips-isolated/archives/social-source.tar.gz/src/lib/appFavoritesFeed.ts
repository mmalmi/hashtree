import type { AppCombinedState } from './appState';
import type { MemoryState } from './contactMemoryStore';
import { createLiveHomeFeedBuffer } from './liveHomeFeedBuffer';
import { readHomeFeedLayout, type HomeFeedLayout } from './homeFeedTabs';

export function favoriteContactPubkeys(memory: MemoryState, viewer: string | null): string[] {
  if (!viewer || memory.viewer !== viewer) { return []; }
  return [...memory.contacts].filter(([pubkey, contact]) => contact.favorite && pubkey !== viewer)
    .map(([pubkey]) => pubkey).sort();
}

/** Only favorite membership changes restart the private feed; name updates do not. */
export function createAppFavoritesFeed(deps: {
  state: AppCombinedState;
  resetHomeFeedPagination: () => void;
  restartCurrentViewLoad: () => void;
}) {
  let previousViewer: string | null | undefined;
  return (memory: MemoryState, viewer: string | null): void => {
    const { state } = deps;
    const authors = favoriteContactPubkeys(memory, viewer);
    if (previousViewer === viewer && authors.length === state.favoritePubkeys.length
      && authors.every((pubkey, i) => pubkey === state.favoritePubkeys[i])) { return; }
    const initialized = previousViewer !== undefined;
    previousViewer = viewer;
    state.favoritePubkeys = authors;
    const cache = new Map(state.routeRenderCache);
    // Custom feeds built on Favorites share its author list.
    for (const key of cache.keys()) { if (key === 'home:favorites' || key.startsWith('home:favorites:')) { cache.delete(key); } }
    state.routeRenderCache = cache;
    if (state.route.kind !== 'home' || state.route.tab !== 'favorites') { return; }
    reloadFavoritesView(deps, initialized);
  };
}

type FavoritesViewDeps = {
  state: AppCombinedState;
  resetHomeFeedPagination: () => void;
  restartCurrentViewLoad: () => void;
};

function reloadFavoritesView({ state, resetHomeFeedPagination, restartCurrentViewLoad }: FavoritesViewDeps, restart: boolean): void {
  state.homeFeedSnapshotReadController?.abort();
  state.homeFeedSnapshotWriteController?.abort();
  state.feed = null;
  state.feedRequiresRefresh = true;
  state.allHomeNotes = [];
  state.homeNotes = [];
  state.liveHomeFeedBuffer = createLiveHomeFeedBuffer();
  state.bufferedLiveHomeEvents = [];
  state.bufferedLiveHomePostCount = 0;
  resetHomeFeedPagination();
  if (restart) { restartCurrentViewLoad(); }
}

/** Editing a custom feed's chosen people reloads that feed when it is open. */
export function createCustomPeopleFeedSync(deps: FavoritesViewDeps) {
  const known = new Map<string, string>();
  return (layouts: Map<string, HomeFeedLayout>, viewer: string | null): void => {
    const layout = readHomeFeedLayout(layouts, viewer);
    const route = deps.state.route;
    const openId = route.kind === 'home' && route.tab === 'favorites' ? route.feedId ?? null : null;
    let changedOpenFeed = false;
    for (const feed of layout.custom) {
      const key = `${viewer}:${feed.id}`;
      const people = feed.people?.join(',') ?? '*';
      changedOpenFeed ||= feed.id === openId && known.has(key) && known.get(key) !== people;
      known.set(key, people);
    }
    if (!changedOpenFeed) { return; }
    const cache = new Map(deps.state.routeRenderCache);
    cache.delete(`home:favorites:${openId}`);
    deps.state.routeRenderCache = cache;
    reloadFavoritesView(deps, true);
  };
}
