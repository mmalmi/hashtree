import type { AppCombinedState } from './appState';
import type { MemoryState } from './contactMemoryStore';
import { createLiveHomeFeedBuffer } from './liveHomeFeedBuffer';

export function favoriteContactPubkeys(memory: MemoryState, viewer: string | null): string[] {
  if (!viewer || memory.viewer !== viewer) { return []; }
  return [...memory.contacts].filter(([pubkey, contact]) => contact.favorite && pubkey !== viewer)
    .map(([pubkey]) => pubkey).sort();
}

/** Only favorite membership changes restart the private feed; name updates do not. */
export function createAppFavoritesFeed(deps: {
  state: AppCombinedState;
  resetHomeFeedPagination: () => void;
  restartCurrentViewLoad: () => void;
}) {
  let previousViewer: string | null | undefined;
  return (memory: MemoryState, viewer: string | null): void => {
    const { state } = deps;
    const authors = favoriteContactPubkeys(memory, viewer);
    if (previousViewer === viewer && authors.length === state.favoritePubkeys.length
      && authors.every((pubkey, i) => pubkey === state.favoritePubkeys[i])) { return; }
    const initialized = previousViewer !== undefined;
    previousViewer = viewer;
    state.favoritePubkeys = authors;
    const cache = new Map(state.routeRenderCache);
    cache.delete('home:favorites');
    state.routeRenderCache = cache;
    if (state.route.kind !== 'home' || state.route.tab !== 'favorites') { return; }
    state.homeFeedSnapshotReadController?.abort();
    state.homeFeedSnapshotWriteController?.abort();
    state.feed = null;
    state.feedRequiresRefresh = true;
    state.allHomeNotes = [];
    state.homeNotes = [];
    state.liveHomeFeedBuffer = createLiveHomeFeedBuffer();
    state.bufferedLiveHomeEvents = [];
    state.bufferedLiveHomePostCount = 0;
    deps.resetHomeFeedPagination();
    if (initialized) { deps.restartCurrentViewLoad(); }
  };
}
