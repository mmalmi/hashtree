import { buildNoteIdentifier, buildNoteShareUrl } from './appSharing';
import {
  createEmptyNoteDetailData,
  createEmptyNoteDetailHasMore,
  loadNoteDetailKindEvents,
  loadNoteDetailKindProfiles,
  NOTE_DETAIL_MAX_EVENTS,
  NOTE_DETAIL_PAGE_SIZE,
  type NoteDetailCursorByKind,
  type NoteDetailHasMoreByKind,
} from './appDetailLoaders';
import { createEmptyNoteDetailEvents, type NoteDetailEventsByKind } from './appDataUtils';
import { getEngagementRootsForEvent } from './appViewState';
import type { Route } from './appRoute';
import type { ProfileRecord, RawEvent } from './nostr';
import type { NoteDetailListKind } from './nostrIndex';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { mergeProfileMaps } from './profileRecords';
import { validateZapReceipt } from './zapReceipt';

type NoteInteractionDeps = {
  getRoot: () => any | null;
  getRoute: () => Route;
  getProfilePersonalRoot: () => any | null;
  getThreadPersonalRoot: () => any | null;
  getAccountProfiles: () => Map<string, ProfileRecord>;
  getCachedDetailEvents: (targetId: string) => RawEvent[];
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  getDetailSheetRequestId: () => number;
  incrementDetailSheetRequestId: () => number;
  setDetailSheetOpen: (open: boolean) => void;
  setDetailSheetLoading: (loading: boolean) => void;
  setDetailSheetKind: (kind: NoteDetailListKind) => void;
  setDetailSheetTitle: (title: string) => void;
  setDetailSheetTargetPubkey: (pubkey: string) => void;
  setDetailSheetEventsByKind: (events: NoteDetailEventsByKind) => void;
  setDetailSheetHasMoreByKind: (hasMore: NoteDetailHasMoreByKind) => void;
  setDetailSheetProfiles: (profiles: Map<string, ProfileRecord>) => void;
  clearPageError: () => void;
  setPageError: (message: string) => void;
  reportError: (fallbackMessage: string, error: unknown) => string;
  getRebroadcastPendingNoteIds: () => Set<string>;
  setRebroadcastPendingNoteIds: (noteIds: Set<string>) => void;
  publishEvent: (event: RawEvent) => void;
};

const NOTE_DETAIL_KINDS: NoteDetailListKind[] = ['likes', 'reposts', 'zaps'];

function sortDetailEvents(events: RawEvent[]): RawEvent[] {
  return [...events].sort((left, right) => (
    right.created_at - left.created_at || left.id.localeCompare(right.id)
  ));
}

function mergeDetailEvents(
  current: RawEvent[],
  loaded: RawEvent[],
  limit: number,
): RawEvent[] {
  return sortDetailEvents(
    [...new Map([...current, ...loaded].map((event) => [event.id, event] as const)).values()],
  ).slice(0, limit);
}

function createCachedNoteDetailEvents(target: RawEvent, events: RawEvent[]): NoteDetailEventsByKind {
  const byKind = createEmptyNoteDetailEvents();
  for (const event of events) {
    if (getLastValidLowercaseEventTarget(event) !== target.id) {
      continue;
    }
    if (event.kind === 7) {
      byKind.likes.push(event);
    } else if (event.kind === 6 || event.kind === 16) {
      byKind.reposts.push(event);
    } else if (
      event.kind === 9_735
      && validateZapReceipt(event, { eventId: target.id })
    ) {
      byKind.zaps.push(event);
    }
  }
  for (const kind of NOTE_DETAIL_KINDS) {
    byKind[kind] = sortDetailEvents(byKind[kind]).slice(0, NOTE_DETAIL_PAGE_SIZE);
  }
  return byKind;
}

function profilesForDetailEvents(
  target: RawEvent,
  eventsByKind: NoteDetailEventsByKind,
  cachedProfiles: Map<string, ProfileRecord>,
): Map<string, ProfileRecord> {
  const actorPubkeys = new Set<string>();
  for (const event of [...eventsByKind.likes, ...eventsByKind.reposts]) {
    actorPubkeys.add(event.pubkey);
  }
  for (const event of eventsByKind.zaps) {
    const zap = validateZapReceipt(event, { eventId: target.id });
    if (zap) {
      actorPubkeys.add(zap.senderPubkey);
    }
  }
  return new Map([...actorPubkeys].flatMap((pubkey) => {
    const profile = cachedProfiles.get(pubkey);
    return profile ? [[pubkey, profile] as const] : [];
  }));
}

export function createNoteInteractions(deps: NoteInteractionDeps) {
  let activeDetailTarget: RawEvent | null = null;
  let activeDetailData = createEmptyNoteDetailData();
  let activeDetailLimitsByKind: Record<NoteDetailListKind, number> = {
    likes: NOTE_DETAIL_PAGE_SIZE,
    reposts: NOTE_DETAIL_PAGE_SIZE,
    zaps: NOTE_DETAIL_PAGE_SIZE,
  };
  let activeDetailCursorsByKind: NoteDetailCursorByKind = {
    likes: null,
    reposts: null,
    zaps: null,
  };
  let activeDetailPendingLoads = 0;

  async function loadActiveNoteDetailKind(kind: NoteDetailListKind): Promise<void> {
    const root = deps.getRoot();
    const target = activeDetailTarget;
    if (!root || !target) {return;}
    const requestId = deps.getDetailSheetRequestId();
    activeDetailPendingLoads += 1;
    deps.setDetailSheetLoading(true);
    let eventLoadFinished = false;
    const finishEventLoad = (): void => {
      if (
        eventLoadFinished
        || requestId !== deps.getDetailSheetRequestId()
        || target !== activeDetailTarget
      ) {
        return;
      }
      eventLoadFinished = true;
      activeDetailPendingLoads = Math.max(0, activeDetailPendingLoads - 1);
      deps.setDetailSheetLoading(activeDetailPendingLoads > 0);
    };
    try {
      const roots = getEngagementRootsForEvent(
        deps.getRoute(),
        root,
        target,
        deps.getProfilePersonalRoot(),
        deps.getThreadPersonalRoot(),
      );
      const loaded = await loadNoteDetailKindEvents(
        roots,
        target,
        kind,
        { limit: activeDetailLimitsByKind[kind] },
      );
      if (requestId !== deps.getDetailSheetRequestId() || target !== activeDetailTarget) {return;}
      activeDetailData = {
        ...activeDetailData,
        eventsByKind: {
          ...activeDetailData.eventsByKind,
          [kind]: mergeDetailEvents(
            activeDetailData.eventsByKind[kind],
            loaded.events,
            activeDetailLimitsByKind[kind],
          ),
        },
        hasMoreByKind: {
          ...activeDetailData.hasMoreByKind,
          [kind]: loaded.hasMore,
        },
      };
      activeDetailCursorsByKind = {
        ...activeDetailCursorsByKind,
        [kind]: loaded.nextCursor,
      };
      deps.setDetailSheetEventsByKind(activeDetailData.eventsByKind);
      deps.setDetailSheetHasMoreByKind(activeDetailData.hasMoreByKind);
      finishEventLoad();

      let loadedProfiles: Map<string, ProfileRecord>;
      try {
        loadedProfiles = await loadNoteDetailKindProfiles(
          roots,
          target,
          mergeProfileMaps(deps.getAccountProfiles(), activeDetailData.profiles),
          kind,
          activeDetailData.eventsByKind[kind],
        );
      } catch (error) {
        console.warn('Failed to hydrate reaction profiles', error);
        return;
      }
      if (requestId !== deps.getDetailSheetRequestId() || target !== activeDetailTarget) {return;}
      activeDetailData = {
        ...activeDetailData,
        profiles: mergeProfileMaps(activeDetailData.profiles, loadedProfiles),
      };
      deps.setDetailSheetProfiles(activeDetailData.profiles);
      deps.mergeCachedProfiles(loadedProfiles);
    } catch (error) {
      console.warn('Failed to load note details', error);
      if (requestId !== deps.getDetailSheetRequestId() || target !== activeDetailTarget) {return;}
      deps.setPageError(deps.reportError("Couldn't load reactions right now.", error));
    } finally {
      finishEventLoad();
    }
  }

  return {
    async copyNoteLink(event: RawEvent): Promise<void> {
      await this.copyText(buildNoteShareUrl(event), "Couldn't copy the link.");
    },

    async copyEventId(event: RawEvent): Promise<void> {
      await this.copyText(buildNoteIdentifier(event.id), "Couldn't copy the Event ID.");
    },

    async copyText(value: string, fallbackMessage: string): Promise<void> {
      try {
        await navigator.clipboard.writeText(value);
        deps.clearPageError();
      } catch (error) {
        deps.setPageError(deps.reportError(fallbackMessage, error));
      }
    },

    closeDetailSheet(): void {
      if (!activeDetailTarget && activeDetailPendingLoads === 0) {
        return;
      }
      deps.incrementDetailSheetRequestId();
      activeDetailTarget = null;
      activeDetailData = createEmptyNoteDetailData();
      activeDetailPendingLoads = 0;
      activeDetailLimitsByKind = {
        likes: NOTE_DETAIL_PAGE_SIZE,
        reposts: NOTE_DETAIL_PAGE_SIZE,
        zaps: NOTE_DETAIL_PAGE_SIZE,
      };
      activeDetailCursorsByKind = { likes: null, reposts: null, zaps: null };
      deps.setDetailSheetTargetPubkey('');
      deps.setDetailSheetOpen(false);
      deps.setDetailSheetLoading(false);
    },

    openNoteDetailSheet(
      target: RawEvent,
      initialKind: NoteDetailListKind = 'likes',
    ): void {
      const root = deps.getRoot();
      deps.incrementDetailSheetRequestId();
      activeDetailTarget = target;
      activeDetailPendingLoads = 0;
      activeDetailLimitsByKind = {
        likes: NOTE_DETAIL_PAGE_SIZE,
        reposts: NOTE_DETAIL_PAGE_SIZE,
        zaps: NOTE_DETAIL_PAGE_SIZE,
      };
      activeDetailCursorsByKind = { likes: null, reposts: null, zaps: null };
      const cachedEvents = createCachedNoteDetailEvents(
        target,
        deps.getCachedDetailEvents(target.id),
      );
      const cachedProfiles = profilesForDetailEvents(
        target,
        cachedEvents,
        deps.getAccountProfiles(),
      );
      activeDetailData = {
        eventsByKind: cachedEvents,
        hasMoreByKind: createEmptyNoteDetailHasMore(),
        profiles: cachedProfiles,
      };
      deps.setDetailSheetKind(initialKind);
      deps.setDetailSheetTitle('Reactions');
      deps.setDetailSheetTargetPubkey(target.pubkey);
      deps.setDetailSheetEventsByKind(activeDetailData.eventsByKind);
      deps.setDetailSheetHasMoreByKind(activeDetailData.hasMoreByKind);
      deps.setDetailSheetProfiles(activeDetailData.profiles);
      deps.setDetailSheetLoading(false);
      deps.setDetailSheetOpen(true);
      deps.clearPageError();

      if (!root) {
        return;
      }
      for (const kind of [
        initialKind,
        ...NOTE_DETAIL_KINDS.filter((candidate) => candidate !== initialKind),
      ]) {
        void loadActiveNoteDetailKind(kind);
      }
    },

    async loadMoreNoteDetails(kind: NoteDetailListKind): Promise<void> {
      const currentLimit = activeDetailLimitsByKind[kind];
      if (!activeDetailTarget || currentLimit >= NOTE_DETAIL_MAX_EVENTS) {return;}
      activeDetailLimitsByKind[kind] = Math.min(
        NOTE_DETAIL_MAX_EVENTS,
        currentLimit + NOTE_DETAIL_PAGE_SIZE,
      );
      await loadActiveNoteDetailKind(kind);
    },

    rebroadcast(event: RawEvent): void {
      if (deps.getRebroadcastPendingNoteIds().has(event.id)) {
        return;
      }

      deps.setRebroadcastPendingNoteIds(new Set(deps.getRebroadcastPendingNoteIds()).add(event.id));
      deps.clearPageError();

      try {
        deps.publishEvent(event);
      } catch (error) {
        deps.setPageError(deps.reportError("Couldn't rebroadcast the post.", error));
      } finally {
        const nextPending = new Set(deps.getRebroadcastPendingNoteIds());
        nextPending.delete(event.id);
        deps.setRebroadcastPendingNoteIds(nextPending);
      }
    },
  };
}
