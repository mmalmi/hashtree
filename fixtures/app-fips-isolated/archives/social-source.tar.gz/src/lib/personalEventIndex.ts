import {
  decryptObject,
  nhashDecode,
  nhashEncode,
  sha256,
  toHex,
  tryDecodeTreeNode,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import { HASHTREE_ROOT_KIND, NostrEventStore } from '@hashtree/nostr';
import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from './nostr';

const PERSONAL_EVENT_INDEX_STATE_VERSION = 1;

export type PersonalEventIndexState = {
  schemaVersion: typeof PERSONAL_EVENT_INDEX_STATE_VERSION;
  pubkey: string;
  headNhash: string;
  publishedHeadNhash: string | null;
  pendingBlockHashes: string[];
  lastAnnouncementCreatedAt: number | null;
};

export type PersonalEventIndexStateStore = {
  load(pubkey: string): Promise<PersonalEventIndexState | null>;
  save(state: PersonalEventIndexState): Promise<void>;
};

export type PersonalEventIndexBlock = {
  hashHex: string;
  data: Uint8Array;
};

export type PersonalEventIndexRemoteBase = {
  root: CID | null;
  createdAt: number | null;
};

export type PersonalEventIndexRootAnnouncer = (
  pubkey: string,
  root: CID,
  createdAt: number,
) => Promise<void>;

export type PersonalEventIndexOptions = {
  store: Store;
  stateStore: PersonalEventIndexStateStore;
  replicateBlocks: (blocks: PersonalEventIndexBlock[]) => Promise<void>;
  announceRoot: (pubkey: string, root: CID, createdAt: number) => Promise<void>;
  verifyEvent?: (event: RawEvent) => boolean | Promise<boolean>;
  runExclusive?: <T>(pubkey: string, operation: () => Promise<T>) => Promise<T>;
  nowMs?: () => number;
};

class CapturingStore implements Store {
  private captured = new Set<string>();

  constructor(private readonly base: Store) {}

  takeCapturedHashes(): string[] {
    const hashes = [...this.captured].sort();
    this.captured.clear();
    return hashes;
  }

  async put(hash: Hash, data: Uint8Array): Promise<boolean> {
    const stored = await this.base.put(hash, data);
    // A block can already exist locally because another account or a remote
    // root used the same content. It still belongs to this mutation's delta
    // and must be considered for replication before announcing the new root.
    this.captured.add(toHex(hash));
    return stored;
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    return await this.base.get(hash);
  }

  async has(hash: Hash): Promise<boolean> {
    return await this.base.has(hash);
  }

  async delete(_hash: Hash): Promise<boolean> {
    // Roots are immutable history. Replacing a Nostr coordinate must not make
    // an older published personal root unreadable on this device.
    return false;
  }
}

function cloneState(state: PersonalEventIndexState): PersonalEventIndexState {
  return {
    ...state,
    pendingBlockHashes: [...state.pendingBlockHashes],
  };
}

function normalizeState(
  state: PersonalEventIndexState | null,
  pubkey: string,
): PersonalEventIndexState | null {
  if (
    !state
    || state.schemaVersion !== PERSONAL_EVENT_INDEX_STATE_VERSION
    || state.pubkey !== pubkey
    || !state.headNhash
    || !Array.isArray(state.pendingBlockHashes)
  ) {
    return null;
  }
  try {
    nhashDecode(state.headNhash);
    if (state.publishedHeadNhash) {
      nhashDecode(state.publishedHeadNhash);
    }
  } catch {
    return null;
  }
  return {
    ...state,
    pendingBlockHashes: [...new Set(
      state.pendingBlockHashes.filter((hash) => /^[0-9a-f]{64}$/.test(hash)),
    )].sort(),
    lastAnnouncementCreatedAt: Number.isInteger(state.lastAnnouncementCreatedAt)
      ? state.lastAnnouncementCreatedAt
      : null,
  };
}

export class PersonalEventIndex {
  private readonly store: Store;
  private readonly stateStore: PersonalEventIndexStateStore;
  private readonly events: NostrEventStore;
  private readonly replicateBlocks: PersonalEventIndexOptions['replicateBlocks'];
  private readonly announceRoot: PersonalEventIndexOptions['announceRoot'];
  private readonly verifyEvent: NonNullable<PersonalEventIndexOptions['verifyEvent']>;
  private readonly externalRunExclusive: PersonalEventIndexOptions['runExclusive'] | null;
  private readonly nowMs: () => number;
  private readonly localQueues = new Map<string, Promise<void>>();
  private readonly listeners = new Set<(state: PersonalEventIndexState) => void>();

  constructor(options: PersonalEventIndexOptions) {
    this.store = options.store;
    this.stateStore = options.stateStore;
    this.events = new NostrEventStore(options.store);
    this.replicateBlocks = options.replicateBlocks;
    this.announceRoot = options.announceRoot;
    this.verifyEvent = options.verifyEvent ?? verifyEvent;
    this.externalRunExclusive = options.runExclusive ?? null;
    this.nowMs = options.nowMs ?? (() => Date.now());
  }

  subscribe(listener: (state: PersonalEventIndexState) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  async getState(pubkey: string): Promise<PersonalEventIndexState | null> {
    return normalizeState(await this.stateStore.load(pubkey), pubkey);
  }

  async getRoot(pubkey: string): Promise<CID | null> {
    const state = await this.getState(pubkey);
    return state ? nhashDecode(state.headNhash) : null;
  }

  async updateRemoteBase(
    pubkey: string,
    remoteRoot: CID | null,
    remoteCreatedAt: number | null = null,
  ): Promise<CID | null> {
    return await this.runExclusive(pubkey, async () => await this.updateRemoteBaseUnlocked(
      pubkey,
      remoteRoot,
      remoteCreatedAt,
    ));
  }

  async refreshRemoteBaseAndFlush(
    pubkey: string,
    resolveRemoteBase: () => Promise<PersonalEventIndexRemoteBase | null>,
    announceRoot: PersonalEventIndexRootAnnouncer = this.announceRoot,
  ): Promise<CID | null> {
    return await this.runExclusive(pubkey, async () => {
      const remote = await resolveRemoteBase();
      if (remote) {
        await this.updateRemoteBaseUnlocked(pubkey, remote.root, remote.createdAt);
      }
      return await this.flushUnlocked(pubkey, announceRoot);
    });
  }

  async append(event: RawEvent): Promise<CID> {
    if (event.kind === HASHTREE_ROOT_KIND) {
      throw new Error('A personal event index cannot recursively index its root announcement');
    }
    const verifiedEvent: RawEvent = {
      id: event.id,
      pubkey: event.pubkey,
      created_at: event.created_at,
      kind: event.kind,
      tags: event.tags.map((tag) => [...tag]),
      content: event.content,
      sig: event.sig,
    };
    if (!await this.verifyEvent(verifiedEvent)) {
      throw new Error('Cannot index an event with an invalid Nostr signature');
    }

    return await this.runExclusive(verifiedEvent.pubkey, async () => {
      const state = await this.getState(verifiedEvent.pubkey);
      const previousRoot = state ? nhashDecode(state.headNhash) : null;
      if (previousRoot && await this.events.getById(previousRoot, verifiedEvent.id)) {
        return previousRoot;
      }
      const capturingStore = new CapturingStore(this.store);
      const nextRoot = await new NostrEventStore(capturingStore).add(previousRoot, verifiedEvent);
      const captured = capturingStore.takeCapturedHashes();
      const nextState: PersonalEventIndexState = {
        schemaVersion: PERSONAL_EVENT_INDEX_STATE_VERSION,
        pubkey: verifiedEvent.pubkey,
        headNhash: nhashEncode(nextRoot),
        publishedHeadNhash: state?.publishedHeadNhash ?? null,
        pendingBlockHashes: [...new Set([
          ...(state?.pendingBlockHashes ?? []),
          ...captured,
        ])].sort(),
        lastAnnouncementCreatedAt: state?.lastAnnouncementCreatedAt ?? null,
      };
      await this.saveAndNotify(nextState, state?.headNhash ?? null);
      return nextRoot;
    });
  }

  async flush(pubkey: string): Promise<CID | null> {
    return await this.runExclusive(pubkey, async () => await this.flushUnlocked(pubkey));
  }

  private async updateRemoteBaseUnlocked(
    pubkey: string,
    remoteRoot: CID | null,
    remoteCreatedAt: number | null,
  ): Promise<CID | null> {
    const state = await this.getState(pubkey);
    if (!remoteRoot) {
      return state ? nhashDecode(state.headNhash) : null;
    }
    if (
      state?.lastAnnouncementCreatedAt !== null
      && state?.lastAnnouncementCreatedAt !== undefined
      && remoteCreatedAt !== null
      && remoteCreatedAt < state.lastAnnouncementCreatedAt
    ) {
      // Root queries can finish out of order. Never let an older relay answer
      // overwrite a head that this device has already observed or announced.
      return nhashDecode(state.headNhash);
    }

    const remoteNhash = nhashEncode(remoteRoot);
    if (!state) {
      // A remotely announced root becomes the immutable base for future
      // delta-only validation. Prove it is complete before persisting it.
      await this.validateCompleteDag(remoteRoot);
      const initialized: PersonalEventIndexState = {
        schemaVersion: PERSONAL_EVENT_INDEX_STATE_VERSION,
        pubkey,
        headNhash: remoteNhash,
        publishedHeadNhash: remoteNhash,
        pendingBlockHashes: [],
        lastAnnouncementCreatedAt: remoteCreatedAt,
      };
      await this.saveAndNotify(initialized, null);
      return remoteRoot;
    }
    if (state.headNhash === remoteNhash || state.publishedHeadNhash === remoteNhash) {
      if (
        remoteCreatedAt !== null
        && remoteCreatedAt > (state.lastAnnouncementCreatedAt ?? 0)
      ) {
        await this.saveAndNotify({
          ...state,
          lastAnnouncementCreatedAt: remoteCreatedAt,
        }, state.headNhash);
      }
      return nhashDecode(state.headNhash);
    }

    // A different root is not evidence that it is a descendant of our local
    // head. Relay/root delivery can be stale or forked, so always merge the
    // locally indexed event IDs into it instead of rolling a clean head back.
    await this.validateCompleteDag(remoteRoot);
    const localEvents = await this.events.listByAuthor(nhashDecode(state.headNhash), pubkey);
    const missingLocalEvents = (await Promise.all(localEvents.map(async (event) => (
      await this.events.getById(remoteRoot, event.id) ? null : event
    )))).filter((event): event is RawEvent => event !== null);
    const capturingStore = new CapturingStore(this.store);
    const mergedRoot = await new NostrEventStore(capturingStore).build(
      remoteRoot,
      missingLocalEvents,
    );
    const captured = capturingStore.takeCapturedHashes();
    if (!mergedRoot) {
      throw new Error('Could not merge the remote personal event index');
    }
    const mergedState: PersonalEventIndexState = {
      ...state,
      headNhash: nhashEncode(mergedRoot),
      publishedHeadNhash: remoteNhash,
      pendingBlockHashes: nhashEncode(mergedRoot) === remoteNhash
        ? []
        : [...new Set([...state.pendingBlockHashes, ...captured])].sort(),
      lastAnnouncementCreatedAt: remoteCreatedAt === null
        ? state.lastAnnouncementCreatedAt
        : Math.max(state.lastAnnouncementCreatedAt ?? remoteCreatedAt, remoteCreatedAt),
    };
    await this.saveAndNotify(mergedState, state.headNhash);
    return mergedRoot;
  }

  private async flushUnlocked(
    pubkey: string,
    announceRoot: PersonalEventIndexRootAnnouncer = this.announceRoot,
  ): Promise<CID | null> {
    const state = await this.getState(pubkey);
    if (!state || state.headNhash === state.publishedHeadNhash) {
      return state ? nhashDecode(state.headNhash) : null;
    }
    if (state.pendingBlockHashes.length === 0) {
      throw new Error('Personal event index head is dirty without pending Hashtree blocks');
    }

    const root = nhashDecode(state.headNhash);
    const pendingHashes = new Set(state.pendingBlockHashes);
    const blocks = await this.collectPendingDelta(root, pendingHashes);
    if (blocks.length === 0) {
      throw new Error(`Personal event index DAG has no reachable pending blocks: ${state.headNhash}`);
    }
    await this.replicateBlocks(blocks);

    const lastCreatedAt = state.lastAnnouncementCreatedAt;
    const createdAt = Math.max(
      Math.floor(this.nowMs() / 1_000),
      (lastCreatedAt ?? -1) + 1,
    );
    await announceRoot(pubkey, root, createdAt);

    await this.saveAndNotify({
      ...state,
      publishedHeadNhash: state.headNhash,
      pendingBlockHashes: [],
      lastAnnouncementCreatedAt: createdAt,
    }, state.headNhash);
    return root;
  }

  private async saveAndNotify(
    state: PersonalEventIndexState,
    previousHeadNhash: string | null,
  ): Promise<void> {
    await this.stateStore.save(cloneState(state));
    if (state.headNhash === previousHeadNhash) {
      return;
    }
    for (const listener of this.listeners) {
      listener(cloneState(state));
    }
  }

  private async validateCompleteDag(root: CID): Promise<void> {
    const visited = new Set<string>();

    const visit = async (hash: Hash, key?: Uint8Array): Promise<void> => {
      const hashHex = toHex(hash);
      const visitKey = `${hashHex}:${key ? toHex(key) : ''}`;
      if (visited.has(visitKey)) {
        return;
      }
      visited.add(visitKey);

      const data = await this.store.get(hash);
      if (!data) {
        throw new Error(`Missing personal event index DAG block: ${hashHex}`);
      }
      const actualHash = toHex(await sha256(data));
      if (actualHash !== hashHex) {
        throw new Error(`Corrupt personal event index DAG block: ${hashHex}`);
      }
      let node = tryDecodeTreeNode(data);
      if (key) {
        try {
          const decrypted = await decryptObject(data, key);
          const decryptedNode = tryDecodeTreeNode(decrypted);
          if (decryptedNode || !node) {
            node = decryptedNode;
          }
        } catch (error) {
          if (!node) {
            throw error;
          }
        }
      }
      if (!node) {
        return;
      }
      for (const link of node.links) {
        await visit(link.hash, link.key);
      }
    };

    await visit(root.hash, root.key);
  }

  private async collectPendingDelta(
    root: CID,
    pendingHashes: ReadonlySet<string>,
  ): Promise<PersonalEventIndexBlock[]> {
    const blocks = new Map<string, PersonalEventIndexBlock>();
    const visited = new Set<string>();

    const visit = async (hash: Hash, key?: Uint8Array): Promise<void> => {
      const hashHex = toHex(hash);
      const visitKey = `${hashHex}:${key ? toHex(key) : ''}`;
      if (visited.has(visitKey)) {
        return;
      }
      visited.add(visitKey);

      const data = await this.store.get(hash);
      if (!data) {
        throw new Error(`Missing personal event index DAG block: ${hashHex}`);
      }
      const actualHash = toHex(await sha256(data));
      if (actualHash !== hashHex) {
        throw new Error(`Corrupt personal event index DAG block: ${hashHex}`);
      }

      // Every put performed by a mutation is captured. A non-pending child is
      // therefore an immutable boundary into the completely validated base.
      // Reading and hashing the boundary catches a missing/corrupt local link
      // without walking the user's entire history on every publication.
      if (!pendingHashes.has(hashHex)) {
        return;
      }
      blocks.set(hashHex, { hashHex, data });

      let node = tryDecodeTreeNode(data);
      if (key) {
        try {
          const decrypted = await decryptObject(data, key);
          const decryptedNode = tryDecodeTreeNode(decrypted);
          if (decryptedNode || !node) {
            node = decryptedNode;
          }
        } catch (error) {
          if (!node) {
            throw error;
          }
        }
      }
      if (!node) {
        return;
      }
      for (const link of node.links) {
        await visit(link.hash, link.key);
      }
    };

    await visit(root.hash, root.key);
    return [...blocks.values()];
  }

  private async runExclusive<T>(pubkey: string, operation: () => Promise<T>): Promise<T> {
    if (this.externalRunExclusive) {
      return await this.externalRunExclusive(pubkey, operation);
    }

    const previous = this.localQueues.get(pubkey) ?? Promise.resolve();
    let release!: () => void;
    const current = new Promise<void>((resolve) => {
      release = resolve;
    });
    const tail = previous.catch(() => undefined).then(() => current);
    this.localQueues.set(pubkey, tail);
    await previous.catch(() => undefined);
    try {
      return await operation();
    } finally {
      release();
      if (this.localQueues.get(pubkey) === tail) {
        this.localQueues.delete(pubkey);
      }
    }
  }
}
