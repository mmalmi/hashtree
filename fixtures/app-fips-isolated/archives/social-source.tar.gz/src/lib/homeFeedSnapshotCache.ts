import { nhashDecode, nhashEncode } from '@hashtree/core';
import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from './nostr';

export const HOME_FEED_SNAPSHOT_FORMAT = 'iris-social/home-feed-snapshot@2' as const;
export const HOME_FEED_SNAPSHOT_MAX_EVENTS = 64;
export const HOME_FEED_SNAPSHOT_MAX_BYTES = 256 * 1_024;

const HOME_FEED_SNAPSHOT_STORAGE_PREFIX = 'iris-social:home-feed-snapshot:v2';
const HOME_FEED_SNAPSHOT_MAX_EVENT_BYTES = 64 * 1_024;
const HOME_FEED_SNAPSHOT_MAX_TAGS = 128;
const HOME_FEED_SNAPSHOT_MAX_TAG_ITEMS = 16;
const HOME_FEED_SNAPSHOT_MAX_TAG_VALUE_LENGTH = 4_096;
const HEX_64 = /^[0-9a-f]{64}$/;
const HEX_128 = /^[0-9a-f]{128}$/;
const NOTE_KINDS = new Set([1, 6, 16, 20, 1_111, 30_023]);
const encoder = new TextEncoder();

export type HomeFeedSnapshotTab = 'latest' | 'for-you' | 'favorites' | 'media';

export type HomeFeedSnapshotKey = {
  viewerPubkey: string;
  tab: HomeFeedSnapshotTab;
  feedSourcePubkey: string;
};

export type HomeFeedSnapshotMetadata = HomeFeedSnapshotKey & {
  /** Canonical immutable Hashtree root from which this feed page was derived. */
  rootNhash: string;
};

export type HomeFeedSnapshot = {
  metadata: HomeFeedSnapshotMetadata;
  notes: RawEvent[];
};

export type HomeFeedSnapshotStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

export type HomeFeedSnapshotReadOptions = {
  /** Verify and return only the first visible page. Unreturned tail events are never trusted. */
  maxNotes?: number;
};

export type HomeFeedSnapshotAsyncReadOptions = HomeFeedSnapshotReadOptions & {
  signal?: AbortSignal;
  verifyNotes?: (notes: RawEvent[]) => Promise<boolean[]>;
};

export type HomeFeedSnapshotAsyncWriteOptions = {
  signal?: AbortSignal;
  verifyNotes?: (notes: RawEvent[]) => Promise<boolean[]>;
};

type StoredHomeFeedSnapshot = HomeFeedSnapshot & {
  format: typeof HOME_FEED_SNAPSHOT_FORMAT;
};

type ParsedHomeFeedSnapshot = {
  metadata: HomeFeedSnapshotMetadata;
  noteValues: unknown[];
};

function defaultStorage(): HomeFeedSnapshotStorage | null {
  return typeof localStorage === 'undefined' ? null : localStorage;
}

/**
 * Persist a small, self-authenticating first-paint feed snapshot.
 * Invalid inputs and storage/quota failures are deliberately non-fatal.
 */
export function writeHomeFeedSnapshot(
  key: HomeFeedSnapshotKey,
  snapshot: Pick<HomeFeedSnapshot, 'notes'> & { rootNhash: string },
  storage: HomeFeedSnapshotStorage | null = defaultStorage(),
): boolean {
  const normalizedKey = normalizeKey(key);
  const rootNhash = canonicalRoot(snapshot.rootNhash);
  if (!storage || !normalizedKey || !rootNhash || !Array.isArray(snapshot.notes)) {
    return false;
  }

  const verifiedNotes: RawEvent[] = [];
  for (const value of snapshot.notes) {
    const note = normalizeVerifiedNote(value);
    if (!note) {
      return false;
    }
    verifiedNotes.push(note);
  }
  return persistHomeFeedSnapshot(normalizedKey, rootNhash, verifiedNotes, storage);
}

/** Verify cache writes in the resident data worker so persistence cannot block paint. */
export async function writeHomeFeedSnapshotAsync(
  key: HomeFeedSnapshotKey,
  snapshot: Pick<HomeFeedSnapshot, 'notes'> & { rootNhash: string },
  storage: HomeFeedSnapshotStorage | null = defaultStorage(),
  options: HomeFeedSnapshotAsyncWriteOptions = {},
): Promise<boolean> {
  const normalizedKey = normalizeKey(key);
  const rootNhash = canonicalRoot(snapshot.rootNhash);
  if (
    options.signal?.aborted
    || !storage
    || !normalizedKey
    || !rootNhash
    || !Array.isArray(snapshot.notes)
  ) {
    return false;
  }

  const notes: RawEvent[] = [];
  for (const value of snapshot.notes.slice(0, HOME_FEED_SNAPSHOT_MAX_EVENTS)) {
    const note = normalizeNote(value);
    if (!note) {
      return false;
    }
    notes.push(note);
  }
  if (notes.length === 0) {
    return false;
  }

  try {
    const verifyNotes = options.verifyNotes
      ?? (async (events: RawEvent[]) => (
        await (await import('./workerClient')).getWorkerClient()
      ).verifyEvents(events, options.signal));
    const validity = await verifyNotes(notes);
    if (
      options.signal?.aborted
      || validity.length !== notes.length
      || validity.some((valid) => !valid)
    ) {
      return false;
    }
    return persistHomeFeedSnapshot(normalizedKey, rootNhash, notes, storage);
  } catch {
    return false;
  }
}

function persistHomeFeedSnapshot(
  normalizedKey: HomeFeedSnapshotKey,
  rootNhash: string,
  verifiedNotes: RawEvent[],
  storage: HomeFeedSnapshotStorage,
): boolean {
  const normalizedNotes = normalizeSnapshotNotes(verifiedNotes, normalizedKey.tab);
  if (normalizedNotes.length === 0) {
    return false;
  }

  const base: Omit<StoredHomeFeedSnapshot, 'notes'> = {
    format: HOME_FEED_SNAPSHOT_FORMAT,
    metadata: { ...normalizedKey, rootNhash },
  };
  const prefix = `${JSON.stringify(base).slice(0, -1)},"notes":[`;
  const suffix = ']}';
  const serializedNotes: string[] = [];
  let serializedBytes = utf8Length(prefix) + utf8Length(suffix);
  for (const note of normalizedNotes) {
    if (serializedNotes.length >= HOME_FEED_SNAPSHOT_MAX_EVENTS) {
      break;
    }
    const serializedNote = JSON.stringify(note);
    const candidateBytes = utf8Length(serializedNote) + (serializedNotes.length > 0 ? 1 : 0);
    if (serializedBytes + candidateBytes > HOME_FEED_SNAPSHOT_MAX_BYTES) {
      continue;
    }
    serializedNotes.push(serializedNote);
    serializedBytes += candidateBytes;
  }
  if (serializedNotes.length === 0) {
    return false;
  }

  try {
    storage.setItem(storageKey(normalizedKey), `${prefix}${serializedNotes.join(',')}${suffix}`);
    return true;
  } catch {
    return false;
  }
}

/** Read and re-verify the requested cached notes before returning them for first paint. */
export function readHomeFeedSnapshot(
  key: HomeFeedSnapshotKey,
  storage: HomeFeedSnapshotStorage | null = defaultStorage(),
  options: HomeFeedSnapshotReadOptions = {},
): HomeFeedSnapshot | null {
  const maxNotes = normalizeReadLimit(options.maxNotes);
  const parsed = readStoredSnapshot(key, storage);
  if (!parsed || maxNotes === 0) {
    return null;
  }

  const notes: RawEvent[] = [];
  for (const value of parsed.noteValues.slice(0, maxNotes)) {
    const note = normalizeVerifiedNote(value);
    if (!note) {
      return null;
    }
    notes.push(note);
  }
  return snapshotFromParsed(parsed, notes);
}

/** Restore a larger authentic offline page without putting signature work on the UI thread. */
export async function readHomeFeedSnapshotAsync(
  key: HomeFeedSnapshotKey,
  storage: HomeFeedSnapshotStorage | null = defaultStorage(),
  options: HomeFeedSnapshotAsyncReadOptions = {},
): Promise<HomeFeedSnapshot | null> {
  if (options.signal?.aborted) {
    return null;
  }
  const maxNotes = normalizeReadLimit(options.maxNotes);
  const parsed = readStoredSnapshot(key, storage);
  if (!parsed || maxNotes === 0) {
    return null;
  }

  const notes: RawEvent[] = [];
  for (const value of parsed.noteValues.slice(0, maxNotes)) {
    const note = normalizeNote(value);
    if (!note) {
      return null;
    }
    notes.push(note);
  }

  try {
    if (options.signal?.aborted) {
      return null;
    }
    const verifyNotes = options.verifyNotes
      ?? (async (events: RawEvent[]) => (
        await (await import('./workerClient')).getWorkerClient()
      ).verifyEvents(events, options.signal));
    const validity = await verifyNotes(notes);
    if (validity.length !== notes.length || validity.some((valid) => !valid)) {
      return null;
    }
    return snapshotFromParsed(parsed, notes);
  } catch {
    return null;
  }
}

function normalizeReadLimit(value: number | undefined): number {
  if (value === undefined) {
    return HOME_FEED_SNAPSHOT_MAX_EVENTS;
  }
  return Number.isSafeInteger(value) && value > 0
    ? Math.min(value, HOME_FEED_SNAPSHOT_MAX_EVENTS)
    : 0;
}

function readStoredSnapshot(
  key: HomeFeedSnapshotKey,
  storage: HomeFeedSnapshotStorage | null,
): ParsedHomeFeedSnapshot | null {
  const normalizedKey = normalizeKey(key);
  if (!storage || !normalizedKey) {
    return null;
  }

  try {
    const raw = storage.getItem(storageKey(normalizedKey));
    if (!raw || raw.length > HOME_FEED_SNAPSHOT_MAX_BYTES
      || utf8Length(raw) > HOME_FEED_SNAPSHOT_MAX_BYTES) {
      return null;
    }
    const parsed: unknown = JSON.parse(raw);
    if (!isExactObject(parsed, ['format', 'metadata', 'notes'])
      || parsed.format !== HOME_FEED_SNAPSHOT_FORMAT
      || !isExactObject(parsed.metadata, [
        'viewerPubkey',
        'tab',
        'feedSourcePubkey',
        'rootNhash',
      ])
      || parsed.metadata.viewerPubkey !== normalizedKey.viewerPubkey
      || parsed.metadata.tab !== normalizedKey.tab
      || parsed.metadata.feedSourcePubkey !== normalizedKey.feedSourcePubkey
      || !Array.isArray(parsed.notes)
      || parsed.notes.length === 0
      || parsed.notes.length > HOME_FEED_SNAPSHOT_MAX_EVENTS) {
      return null;
    }
    const rootNhash = canonicalRoot(parsed.metadata.rootNhash);
    if (!rootNhash || rootNhash !== parsed.metadata.rootNhash) {
      return null;
    }
    return {
      metadata: { ...normalizedKey, rootNhash },
      noteValues: parsed.notes,
    };
  } catch {
    return null;
  }
}

function snapshotFromParsed(
  parsed: ParsedHomeFeedSnapshot,
  notes: RawEvent[],
): HomeFeedSnapshot {
  return {
    metadata: parsed.metadata,
    notes: normalizeSnapshotNotes(notes, parsed.metadata.tab),
  };
}

export function removeHomeFeedSnapshot(
  key: HomeFeedSnapshotKey,
  storage: HomeFeedSnapshotStorage | null = defaultStorage(),
): void {
  const normalizedKey = normalizeKey(key);
  if (!storage || !normalizedKey) {
    return;
  }
  try {
    storage.removeItem(storageKey(normalizedKey));
  } catch {
    // Cache eviction must never affect feed loading.
  }
}

function normalizeKey(key: HomeFeedSnapshotKey): HomeFeedSnapshotKey | null {
  if (!key || typeof key !== 'object'
    || !HEX_64.test(key.viewerPubkey)
    || key.viewerPubkey !== key.viewerPubkey.toLowerCase()
    || !HEX_64.test(key.feedSourcePubkey)
    || key.feedSourcePubkey !== key.feedSourcePubkey.toLowerCase()
    || !isHomeFeedSnapshotTab(key.tab)) {
    return null;
  }
  return {
    viewerPubkey: key.viewerPubkey,
    tab: key.tab,
    feedSourcePubkey: key.feedSourcePubkey,
  };
}

function canonicalRoot(value: unknown): string | null {
  if (typeof value !== 'string' || value.length > 256) {
    return null;
  }
  try {
    const canonical = nhashEncode(nhashDecode(value));
    return canonical === value ? canonical : null;
  } catch {
    return null;
  }
}

function normalizeNote(value: unknown): RawEvent | null {
  if (!isExactObject(value, ['id', 'pubkey', 'created_at', 'kind', 'tags', 'content', 'sig'])
    || typeof value.id !== 'string'
    || !HEX_64.test(value.id)
    || typeof value.pubkey !== 'string'
    || !HEX_64.test(value.pubkey)
    || typeof value.created_at !== 'number'
    || !Number.isSafeInteger(value.created_at)
    || value.created_at < 0
    || typeof value.kind !== 'number'
    || !Number.isSafeInteger(value.kind)
    || !NOTE_KINDS.has(value.kind)
    || typeof value.content !== 'string'
    || typeof value.sig !== 'string'
    || !HEX_128.test(value.sig)
    || !Array.isArray(value.tags)
    || value.tags.length > HOME_FEED_SNAPSHOT_MAX_TAGS) {
    return null;
  }
  const tags: string[][] = [];
  for (const valueTag of value.tags) {
    if (!Array.isArray(valueTag)
      || valueTag.length > HOME_FEED_SNAPSHOT_MAX_TAG_ITEMS
      || valueTag.some((item) => (
        typeof item !== 'string' || item.length > HOME_FEED_SNAPSHOT_MAX_TAG_VALUE_LENGTH
      ))) {
      return null;
    }
    tags.push([...valueTag]);
  }
  const note: RawEvent = {
    id: value.id,
    pubkey: value.pubkey,
    created_at: value.created_at,
    kind: value.kind,
    tags,
    content: value.content,
    sig: value.sig,
  };
  if (utf8Length(JSON.stringify(note)) > HOME_FEED_SNAPSHOT_MAX_EVENT_BYTES) {
    return null;
  }
  return note;
}

function normalizeVerifiedNote(value: unknown): RawEvent | null {
  const note = normalizeNote(value);
  if (!note) {
    return null;
  }
  try {
    return verifyEvent(note) ? note : null;
  } catch {
    return null;
  }
}

function dedupeAndSortNotes(notes: readonly RawEvent[]): RawEvent[] {
  const sorted = [...notes].sort(compareNewest);
  const seenIds = new Set<string>();
  const seenAddresses = new Set<string>();
  const deduped: RawEvent[] = [];
  for (const note of sorted) {
    const address = addressableCoordinate(note);
    if (seenIds.has(note.id) || (address && seenAddresses.has(address))) {
      continue;
    }
    seenIds.add(note.id);
    if (address) {
      seenAddresses.add(address);
    }
    deduped.push(note);
  }
  return deduped;
}

function dedupeNotesPreservingOrder(notes: readonly RawEvent[]): RawEvent[] {
  const seenIds = new Set<string>();
  const seenAddresses = new Set<string>();
  const deduped: RawEvent[] = [];
  for (const note of notes) {
    const address = addressableCoordinate(note);
    if (seenIds.has(note.id) || (address && seenAddresses.has(address))) {
      continue;
    }
    seenIds.add(note.id);
    if (address) {
      seenAddresses.add(address);
    }
    deduped.push(note);
  }
  return deduped;
}

function normalizeSnapshotNotes(
  notes: readonly RawEvent[],
  tab: HomeFeedSnapshotTab,
): RawEvent[] {
  return tab === 'for-you'
    ? dedupeNotesPreservingOrder(notes)
    : dedupeAndSortNotes(notes);
}

function addressableCoordinate(note: RawEvent): string | null {
  if (note.kind < 30_000 || note.kind >= 40_000) {
    return null;
  }
  const identifier = note.tags.find((tag) => tag[0] === 'd')?.[1];
  return identifier === undefined ? null : `${note.kind}:${note.pubkey}:${identifier}`;
}

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at
    || compareStrings(left.id, right.id)
    || compareStrings(left.sig, right.sig);
}

function storageKey(key: HomeFeedSnapshotKey): string {
  return [
    HOME_FEED_SNAPSHOT_STORAGE_PREFIX,
    key.viewerPubkey,
    key.tab,
    key.feedSourcePubkey,
  ].join(':');
}

function isHomeFeedSnapshotTab(value: unknown): value is HomeFeedSnapshotTab {
  return value === 'latest'
    || value === 'for-you'
    || value === 'favorites'
    || value === 'media';
}

function isExactObject(value: unknown, keys: readonly string[]): value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return false;
  }
  const actual = Object.keys(value).sort(compareStrings);
  const expected = [...keys].sort(compareStrings);
  return actual.length === expected.length
    && actual.every((key, index) => key === expected[index]);
}

function utf8Length(value: string): number {
  return encoder.encode(value).length;
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
