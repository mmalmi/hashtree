import type { ProfileRecord } from './nostr';
import {
  isProfileLoadAbort,
  profileLoadAbortReason,
  throwIfProfileLoadAborted,
} from './profileLoadAbort';

export type ProfileBatchLoadOptions = {
  signal?: AbortSignal;
  isCurrent?: () => boolean;
  onProfiles?: (profiles: Map<string, ProfileRecord>) => void;
};

export type ProfileLoadOptions = {
  signal?: AbortSignal;
  isCurrent?: () => boolean;
  onProfile?: (profile: ProfileRecord) => void;
};

type ProfileSource<T> = {
  label: string;
  load: (signal: AbortSignal) => Promise<T>;
};

async function loadFirstUsable<T>(
  sources: readonly ProfileSource<T>[],
  isUsable: (value: T) => boolean,
  emptyValue: T,
  options: {
    signal?: AbortSignal;
    isCurrent?: () => boolean;
    report?: (value: T) => void;
  },
): Promise<T> {
  throwIfProfileLoadAborted(options.signal);
  if (sources.length === 0) {
    return emptyValue;
  }

  const controllers = sources.map(() => new AbortController());
  return await new Promise<T>((resolve, reject) => {
    let remaining = sources.length;
    let settled = false;

    const cleanup = (): void => {
      options.signal?.removeEventListener('abort', cancel);
    };
    const abortSources = (reason: unknown, winnerIndex = -1): void => {
      controllers.forEach((controller, index) => {
        if (index !== winnerIndex && !controller.signal.aborted) {
          controller.abort(reason);
        }
      });
    };
    const cancel = (): void => {
      if (settled) {
        return;
      }
      settled = true;
      const reason = profileLoadAbortReason(options.signal);
      abortSources(reason);
      cleanup();
      reject(reason);
    };
    options.signal?.addEventListener('abort', cancel, { once: true });

    const finishEmpty = (): void => {
      remaining -= 1;
      if (!settled && remaining === 0) {
        settled = true;
        cleanup();
        resolve(emptyValue);
      }
    };

    sources.forEach((source, index) => {
      let result: Promise<T>;
      try {
        result = source.load(controllers[index]!.signal);
      } catch (error) {
        result = Promise.reject(error);
      }
      void result.then((value) => {
        if (settled) {
          return;
        }
        if (!isUsable(value)) {
          finishEmpty();
          return;
        }

        settled = true;
        abortSources(
          new DOMException('A faster profile source completed', 'AbortError'),
          index,
        );
        cleanup();
        try {
          if (
            options.report
            && !options.signal?.aborted
            && options.isCurrent?.() !== false
          ) {
            options.report(value);
          }
        } catch (error) {
          console.warn('Failed to report resolved profile data', error);
        }
        resolve(value);
      }).catch((error) => {
        if (settled) {
          return;
        }
        if (!isProfileLoadAbort(error, controllers[index]!.signal)) {
          console.warn(`Failed to load ${source.label}`, error);
        }
        finishEmpty();
      });
    });
  });
}

export async function loadProfileBatchFromFastestSource(
  pubkeys: string[],
  sources: {
    loadEventProfiles?: (
      pubkeys: string[],
      signal: AbortSignal,
    ) => Promise<Map<string, ProfileRecord>>;
    loadCatalogProfiles: (
      pubkeys: string[],
      signal: AbortSignal,
    ) => Promise<Map<string, ProfileRecord>>;
    loadRoutedProfiles?: (
      pubkeys: string[],
      signal: AbortSignal,
    ) => Promise<Map<string, ProfileRecord>>;
  },
  options: ProfileBatchLoadOptions = {},
): Promise<Map<string, ProfileRecord>> {
  const normalized = [...new Set(
    pubkeys.map((pubkey) => pubkey.trim().toLowerCase()).filter(Boolean),
  )];
  if (normalized.length === 0) {
    return new Map();
  }

  return await loadFirstUsable<Map<string, ProfileRecord>>(
    [
      ...(sources.loadEventProfiles
        ? [{
            label: 'fallback indexed profiles',
            load: async (signal: AbortSignal) => (
              await sources.loadEventProfiles!(normalized, signal)
            ),
          }]
        : []),
      {
        label: 'catalog profiles',
        load: async (signal) => await sources.loadCatalogProfiles(normalized, signal),
      },
      ...(sources.loadRoutedProfiles
        ? [{
            label: 'routed profiles',
            load: async (signal: AbortSignal) => (
              await sources.loadRoutedProfiles!(normalized, signal)
            ),
          }]
        : []),
    ],
    (profiles) => profiles.size > 0,
    new Map<string, ProfileRecord>(),
    {
      signal: options.signal,
      isCurrent: options.isCurrent,
      report: options.onProfiles,
    },
  );
}

export async function loadProfileFromFastestSource(
  pubkey: string,
  sources: {
    loadEventProfile?: (signal: AbortSignal) => Promise<ProfileRecord | null>;
    loadCatalogProfile: (signal: AbortSignal) => Promise<ProfileRecord | null>;
    loadRoutedProfile?: (signal: AbortSignal) => Promise<ProfileRecord | null>;
  },
  options: ProfileLoadOptions = {},
): Promise<ProfileRecord | null> {
  if (!pubkey.trim()) {
    return null;
  }

  return await loadFirstUsable<ProfileRecord | null>(
    [
      {
        label: 'catalog profile',
        load: sources.loadCatalogProfile,
      },
      ...(sources.loadEventProfile
        ? [{
            label: 'fallback indexed profile',
            load: sources.loadEventProfile,
          }]
        : []),
      ...(sources.loadRoutedProfile
        ? [{
            label: 'routed profile',
            load: sources.loadRoutedProfile,
          }]
        : []),
    ],
    (profile) => profile !== null,
    null,
    {
      signal: options.signal,
      isCurrent: options.isCurrent,
      report: options.onProfile
        ? (profile) => {
            if (profile) {
              options.onProfile!(profile);
            }
          }
        : undefined,
    },
  );
}
