import type { Route } from './appRoute';
import type { FeedSnapshot, ProfileSocialSnapshot } from './nostrIndex';
import type { ProfileSnapshot } from './profileNotes';

type PaginationLoaderDeps = {
  getRoute: () => Route;
  getRoot: () => any | null;
  getLoading: () => boolean;
  getHomeFeedInitialLoadPending: () => boolean;
  getFeed: () => FeedSnapshot | null;
  getProfilePage: () => ProfileSnapshot | null;
  getProfileSocial: () => ProfileSocialSnapshot | null;
  getHomeFeedLoadPending: () => boolean;
  setHomeFeedLoadPending: (pending: boolean) => void;
  getHomeFeedHasMore: () => boolean;
  getHomeFeedNoteCount: () => number;
  getFeedLimit: () => number;
  setFeedLimit: (limit: number) => void;
  getHomeFeedScrollOffset: () => number;
  setHomeFeedLastLoadScrollOffset: (offset: number) => void;
  setHomeFeedFetchLimit: (limit: number) => void;
  hydrateNextHomeFeedPage: (
    currentRoot: any,
    route: Route,
    pageSize: number,
    token: number,
  ) => Promise<void>;
  getProfileFeedLoadPending: () => boolean;
  getProfileNotesLoading: () => boolean;
  setProfileFeedLoadPending: (pending: boolean) => void;
  getProfileFeedHasMore: () => boolean;
  getProfileVisibleNoteCount: () => number;
  getProfileNoteLimit: () => number;
  setProfileNoteLimit: (limit: number) => void;
  getProfileFeedScrollOffset: () => number;
  setProfileFeedLastLoadScrollOffset: (offset: number) => void;
  setProfileNotesLoading: (loading: boolean) => void;
  setProfileNoteFetchLimit: (limit: number) => void;
  getLoadToken: () => number;
  hydrateNextProfileNotesPage: (
    currentRoot: any,
    pubkey: string,
    token: number,
    options: {
      pageSize: number;
    },
  ) => Promise<void>;
  hydrateProfileLikes: (currentRoot: any, pubkey: string, token: number) => Promise<void>;
  getProfileSocialLoadPending: () => boolean;
  setProfileSocialLoadPending: (pending: boolean) => void;
  getProfileSocialHasMore: () => boolean;
  getProfileSocialVisibleLimit: () => number;
  setProfileSocialVisibleLimit: (limit: number) => void;
  getProfileSocialScrollOffset: () => number;
  setProfileSocialLastLoadScrollOffset: (offset: number) => void;
  setProfileSocialLoading: (loading: boolean) => void;
  setProfileSocialFollowerFetchLimit: (limit: number) => void;
  hydrateProfileSocial: (
    currentRoot: any,
    pubkey: string,
    token: number,
    options: {
      includeProfiles?: boolean;
      includeFollows?: boolean;
      includeFollowers?: boolean;
      progressSection?: 'follows' | 'followers';
    },
  ) => Promise<void>;
  hydrateProfileListProfiles: (currentRoot: any, pubkeys: string[], token: number) => Promise<void>;
  getThreadPage: () => { note: unknown | null } | null;
  getThreadRepliesLoadPending: () => boolean;
  setThreadRepliesLoadPending: (pending: boolean) => void;
  getThreadRepliesHasMore: () => boolean;
  getThreadReplyFetchLimit: () => number;
  setThreadReplyFetchLimit: (limit: number) => void;
  getThreadReplyScrollOffset: () => number;
  setThreadReplyLastLoadScrollOffset: (offset: number) => void;
  hydrateThreadRepliesPage: (
    currentRoot: any,
    ref: string,
    pageSize: number,
    token: number,
  ) => Promise<void>;
  feedPageSize: number;
  profileSocialPageSize: number;
  threadReplyPageSize: number;
};

export function createPaginationLoaders(deps: PaginationLoaderDeps) {
  let queuedProfileNotesLoad: {
    pubkey: string;
    section: 'posts' | 'replies' | 'media' | 'likes';
    visibleLimit: number;
  } | null = null;

  async function loadMoreProfileNotes(resumeQueued: boolean): Promise<void> {
    const route = deps.getRoute();
    const root = deps.getRoot();
    if (
      route.kind !== 'profile'
      || (
        route.section !== 'posts'
        && route.section !== 'replies'
        && route.section !== 'media'
        && route.section !== 'likes'
      )
      || !route.pubkey
      || deps.getProfileFeedLoadPending()
      || !deps.getProfileFeedHasMore()
    ) {
      if (resumeQueued) {
        queuedProfileNotesLoad = null;
      }
      return;
    }

    const queuedForRoute = queuedProfileNotesLoad
      && queuedProfileNotesLoad.pubkey === route.pubkey
      && queuedProfileNotesLoad.section === route.section
      ? queuedProfileNotesLoad
      : null;
    if (resumeQueued && !queuedForRoute) {
      return;
    }
    if (!resumeQueued && queuedForRoute && deps.getProfileNotesLoading()) {
      return;
    }

    const nextVisibleLimit = queuedForRoute?.visibleLimit
      ?? deps.getProfileNoteLimit() + deps.feedPageSize;
    deps.setProfileNoteLimit(nextVisibleLimit);
    if (
      // This count is filtered for the active Posts/Replies/Media/Likes
      // section. Raw profilePage.notes can be mostly unrelated replies and
      // must not make a sparse section appear prefetched.
      deps.getProfileVisibleNoteCount() >= nextVisibleLimit
      || !root
    ) {
      queuedProfileNotesLoad = null;
      deps.setProfileFeedLastLoadScrollOffset(deps.getProfileFeedScrollOffset());
      return;
    }

    // The initial progressive stream owns the durable cursor and request id.
    // Remember one continuation request and resume it when that stream goes
    // idle instead of dropping the user's Load More action.
    if (deps.getProfileNotesLoading()) {
      queuedProfileNotesLoad = {
        pubkey: route.pubkey,
        section: route.section,
        visibleLimit: nextVisibleLimit,
      };
      deps.setProfileFeedLastLoadScrollOffset(deps.getProfileFeedScrollOffset());
      return;
    }

    queuedProfileNotesLoad = null;
    deps.setProfileNoteFetchLimit(nextVisibleLimit + deps.feedPageSize);
    deps.setProfileFeedLoadPending(true);
    deps.setProfileNotesLoading(true);
    try {
      if (route.section === 'likes') {
        await deps.hydrateProfileLikes(root, route.pubkey, deps.getLoadToken());
      } else {
        await deps.hydrateNextProfileNotesPage(root, route.pubkey, deps.getLoadToken(), {
          pageSize: deps.feedPageSize,
        });
      }
    } finally {
      deps.setProfileFeedLoadPending(false);
      deps.setProfileNotesLoading(false);
      deps.setProfileFeedLastLoadScrollOffset(deps.getProfileFeedScrollOffset());
    }
  }

  return {
    async loadMoreFeed(): Promise<void> {
      const route = deps.getRoute();
      if (
        route.kind !== 'home'
        || (route.tab !== 'latest' && route.tab !== 'for-you' && route.tab !== 'favorites' && route.tab !== 'media')
        || deps.getHomeFeedLoadPending()
        || !deps.getHomeFeedHasMore()
      ) {
        return;
      }

      const nextVisibleLimit = deps.getFeedLimit() + deps.feedPageSize;
      // The durable query keeps a filtered lookahead page beyond the visible
      // window, so reaching the sentinel can reveal useful content immediately.
      // Keep that optimistic window open while the progressive refill catches
      // up; existing cards remain untouched by the route loader.
      deps.setFeedLimit(nextVisibleLimit);
      deps.setHomeFeedLastLoadScrollOffset(deps.getHomeFeedScrollOffset());
      if (
        deps.getHomeFeedNoteCount() > nextVisibleLimit
        || (!deps.getRoot() && deps.getHomeFeedNoteCount() > deps.getFeedLimit())
        || (deps.getFeed()?.notes.length ?? 0) > nextVisibleLimit
      ) {
        return;
      }

      // A cached/live lookahead is safe to reveal while the immutable root is
      // still refreshing. Do not start a competing durable query until the
      // active route load has settled.
      if (deps.getLoading() || deps.getHomeFeedInitialLoadPending()) {
        return;
      }

      const root = deps.getRoot();
      if (!root) {
        return;
      }

      deps.setHomeFeedLoadPending(true);
      deps.setHomeFeedFetchLimit(nextVisibleLimit + deps.feedPageSize);
      try {
        const requestToken = deps.getLoadToken();
        await deps.hydrateNextHomeFeedPage(root, route, deps.feedPageSize, requestToken);
        const latestRoute = deps.getRoute();
        if (
          deps.getLoadToken() === requestToken
          && latestRoute.kind === 'home'
          && (latestRoute.tab === 'latest' || latestRoute.tab === 'for-you' || latestRoute.tab === 'favorites' || latestRoute.tab === 'media')
        ) {
          deps.setFeedLimit(nextVisibleLimit);
        }
      } finally {
        deps.setHomeFeedLoadPending(false);
        deps.setHomeFeedLastLoadScrollOffset(deps.getHomeFeedScrollOffset());
      }
    },

    loadMoreProfileNotes: () => loadMoreProfileNotes(false),

    resumeQueuedProfileNotesLoad: () => loadMoreProfileNotes(true),

    async loadMoreProfileSocial(): Promise<void> {
      const route = deps.getRoute();
      const root = deps.getRoot();
      if (
        route.kind !== 'profile'
        || (route.section !== 'follows' && route.section !== 'followers')
        || !route.pubkey
        || deps.getProfileSocialLoadPending()
        || !deps.getProfileSocialHasMore()
      ) {
        return;
      }

      const nextVisibleLimit = deps.getProfileSocialVisibleLimit() + deps.profileSocialPageSize;
      const currentSocial = deps.getProfileSocial();
      const loadedPubkeys = route.section === 'follows'
        ? currentSocial?.follows ?? []
        : currentSocial?.followers ?? [];
      const knownCount = route.section === 'follows'
        ? currentSocial?.followsCount
        : currentSocial?.followersCount;
      if (!root) {
        // Reveal only relationships already available locally. A missing index
        // must neither block those rows nor imply that another page was fetched.
        const localVisibleLimit = Math.min(nextVisibleLimit, loadedPubkeys.length);
        if (localVisibleLimit > deps.getProfileSocialVisibleLimit()) {
          deps.setProfileSocialVisibleLimit(localVisibleLimit);
          deps.setProfileSocialLastLoadScrollOffset(deps.getProfileSocialScrollOffset());
          return;
        }
        if (knownCount === null || knownCount === undefined || knownCount <= loadedPubkeys.length) {
          return;
        }
        // The retained graph may contain more IDs than its current bounded
        // renderer projection. A null root explicitly selects that local graph.
        const token = deps.getLoadToken();
        const isCurrent = () => {
          const currentRoute = deps.getRoute();
          return token === deps.getLoadToken()
            && currentRoute.kind === 'profile'
            && currentRoute.pubkey === route.pubkey
            && currentRoute.section === route.section;
        };
        deps.setProfileSocialLoadPending(true);
        deps.setProfileSocialFollowerFetchLimit(nextVisibleLimit);
        try {
          await deps.hydrateProfileSocial(null, route.pubkey, token, {
            includeProfiles: false,
            includeFollows: route.section === 'follows',
            includeFollowers: route.section === 'followers',
          });
          if (!isCurrent()) {return;}
          const refreshedSocial = deps.getProfileSocial();
          const refreshedPubkeys = route.section === 'follows'
            ? refreshedSocial?.follows ?? []
            : refreshedSocial?.followers ?? [];
          const refreshedLimit = Math.min(nextVisibleLimit, refreshedPubkeys.length);
          if (refreshedLimit > deps.getProfileSocialVisibleLimit()) {
            deps.setProfileSocialVisibleLimit(refreshedLimit);
          }
        } finally {
          if (isCurrent()) {
            deps.setProfileSocialLoadPending(false);
            deps.setProfileSocialLastLoadScrollOffset(deps.getProfileSocialScrollOffset());
          }
        }
        return;
      }
      deps.setProfileSocialVisibleLimit(nextVisibleLimit);
      if (
        loadedPubkeys.length >= nextVisibleLimit
        || (knownCount !== null && knownCount !== undefined && knownCount <= loadedPubkeys.length)
        || (route.section === 'followers' && !currentSocial?.followersTruncated)
      ) {
        void deps.hydrateProfileListProfiles(
          root,
          loadedPubkeys.slice(0, nextVisibleLimit),
          deps.getLoadToken(),
        );
        deps.setProfileSocialLastLoadScrollOffset(deps.getProfileSocialScrollOffset());
        return;
      }

      deps.setProfileSocialLoadPending(true);
      deps.setProfileSocialLoading(true);
      deps.setProfileSocialFollowerFetchLimit(nextVisibleLimit);

      try {
        await deps.hydrateProfileSocial(root, route.pubkey, deps.getLoadToken(), {
          includeProfiles: false,
          includeFollows: true,
          includeFollowers: true,
          progressSection: route.section,
        });
        const refreshedSocial = deps.getProfileSocial();
        const refreshedPubkeys = route.section === 'follows'
          ? refreshedSocial?.follows ?? []
          : refreshedSocial?.followers ?? [];
        void deps.hydrateProfileListProfiles(
          root,
          refreshedPubkeys.slice(0, nextVisibleLimit),
          deps.getLoadToken(),
        );
      } finally {
        deps.setProfileSocialLoadPending(false);
        deps.setProfileSocialLastLoadScrollOffset(deps.getProfileSocialScrollOffset());
      }
    },

    async loadMoreThreadReplies(): Promise<void> {
      const route = deps.getRoute();
      const root = deps.getRoot();
      if (
        route.kind !== 'thread'
        || !root
        || !deps.getThreadPage()?.note
        || deps.getThreadRepliesLoadPending()
        || !deps.getThreadRepliesHasMore()
      ) {
        return;
      }

      const nextLimit = deps.getThreadReplyFetchLimit() + deps.threadReplyPageSize;
      deps.setThreadReplyFetchLimit(nextLimit);
      deps.setThreadReplyLastLoadScrollOffset(deps.getThreadReplyScrollOffset());
      deps.setThreadRepliesLoadPending(true);

      try {
        await deps.hydrateThreadRepliesPage(root, route.ref, deps.threadReplyPageSize, deps.getLoadToken());
      } finally {
        deps.setThreadRepliesLoadPending(false);
        deps.setThreadReplyLastLoadScrollOffset(deps.getThreadReplyScrollOffset());
      }
    },
  };
}
