import type { CID } from '@hashtree/core';
import { nhashEncode } from '@hashtree/core';
import type { ProfileRecord, RawEvent } from './nostr';
import type {
  ShadowReadExpectedEvent,
  ShadowReadObservation,
  ShadowReadScope,
} from './shadowReadComparator';

export function buildShadowReadObservation(options: {
  scope: ShadowReadScope;
  sharedRoot: CID;
  roots: readonly CID[];
  events: readonly RawEvent[];
  profiles?: readonly (ProfileRecord | null | undefined)[];
}): ShadowReadObservation {
  const sharedIdentity = nhashEncode(options.sharedRoot);
  const roots = uniqueRoots(options.roots);
  const expected = new Map<string, ShadowReadExpectedEvent>(options.events.map((event) => [event.id, {
    id: event.id,
    pubkey: event.pubkey,
    createdAt: event.created_at,
  }]));
  for (const profile of options.profiles ?? []) {
    if (profile?.eventId) {
      expected.set(profile.eventId, {
        id: profile.eventId,
        pubkey: profile.pubkey,
        ...(profile.createdAt === null ? {} : { createdAt: profile.createdAt }),
      });
    }
  }
  return {
    scope: options.scope,
    sharedRoots: [options.sharedRoot],
    personalRoots: roots.filter((root) => nhashEncode(root) !== sharedIdentity),
    expected: [...expected.values()],
  };
}

function uniqueRoots(roots: readonly CID[]): CID[] {
  const byIdentity = new Map(roots.map((root) => [nhashEncode(root), root]));
  return [...byIdentity.values()];
}
