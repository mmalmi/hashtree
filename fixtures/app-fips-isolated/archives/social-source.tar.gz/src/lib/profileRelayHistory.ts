import type { NostrVerifiedEvent } from 'nostr-pubsub';
import { queryBrowserRelayEvents } from './browserEventReadRouter';
import { canReadHomeFeedFromRelays } from './homeFeedReads';
import { isStrictlyBeforeRecentCursor, type RecentTextNoteCursor } from './recentTextNoteCursor';
import { socialDataPlane } from './socialDataPlane';

const HISTORY_WINDOW_MS = 3_000;

type HistoryReport = { complete: boolean; events: NostrVerifiedEvent[] };
type HistoryDeps = {
  read: typeof queryBrowserRelayEvents;
  enabled: () => boolean;
  visible: (event: NostrVerifiedEvent) => boolean;
  publish?: (events: NostrVerifiedEvent[]) => void;
};

const defaultDeps: HistoryDeps = {
  read: queryBrowserRelayEvents,
  enabled: canReadHomeFeedFromRelays,
  visible: event => socialDataPlane.isExternalEventVisible(event),
  publish(events) {
    const fresh = events.filter(event => !socialDataPlane.getStoredEvent(event.id));
    if (fresh.length) { socialDataPlane.ingestVerifiedRelayEvents(fresh, 'configured-relays'); }
  },
};

/** Render verified batches on arrival. A full page releases the scroll action,
 * while later replies may still supply missing posts near the same cursor. */
export async function readProfileRelayHistory(
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  signal?: AbortSignal,
  deps = defaultDeps,
): Promise<HistoryReport> {
  signal?.throwIfAborted();
  if (!deps.enabled() || limit <= 0) { return { complete: false, events: [] }; }
  const timeout = AbortSignal.timeout(HISTORY_WINDOW_MS + 250);
  const requestSignal = signal ? AbortSignal.any([signal, timeout]) : timeout;
  const byId = new Map<string, NostrVerifiedEvent>();
  let pageReady!: () => void;
  const filled = new Promise<void>(resolve => { pageReady = resolve; });
  const collect = (events: readonly NostrVerifiedEvent[]) => {
    if (requestSignal.aborted || !deps.enabled()) { return; }
    const added: NostrVerifiedEvent[] = [];
    for (const event of events) {
      if (!byId.has(event.id) && event.pubkey === pubkey && kinds.includes(event.kind)
        && isStrictlyBeforeRecentCursor(event.created_at, event.id, before) && deps.visible(event)) {
        byId.set(event.id, event);
        added.push(event);
      }
    }
    if (added.length) { deps.publish?.(added); }
    if (byId.size >= limit) { pageReady(); }
  };
  // Nostr until is inclusive. Allow events already seen in the cursor second.
  const deadline = Date.now() + HISTORY_WINDOW_MS;
  const read = async (): Promise<boolean> => {
    let requestLimit = Math.min(256, limit + (before ? 16 : 0));
    while (!requestSignal.aborted && deps.enabled()) {
      const report = await deps.read([{
        authors: [pubkey], kinds: [...kinds], limit: requestLimit,
        ...(before && { until: before.createdAt }),
      }], { limit: requestLimit, deadline, signal: requestSignal }, collect);
      collect(report.events.map(candidate => candidate.event));
      if (report.events.length < requestLimit) { return report.complete === true; }
      if (byId.size >= limit || !before || requestLimit >= 256 || Date.now() >= deadline) { break; }
      requestLimit = Math.min(256, requestLimit * 2);
    }
    return false;
  };
  const request = read().catch(error => {
    if (signal?.aborted) { throw error; }
    // An interrupted read can still supply a useful partial page.
    return false;
  });
  const complete = await Promise.race([filled.then(() => false), request]);
  signal?.throwIfAborted();
  const events = [...byId.values()].sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id));
  return { complete, events: events.slice(0, limit) };
}
