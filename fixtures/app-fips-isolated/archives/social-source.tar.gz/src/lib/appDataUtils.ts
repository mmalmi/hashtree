import type { CID } from '@hashtree/core';
import { getRootNhash, type NoteDetailListKind } from './nostrIndex';
import {
  getAddressableCoordinateFromReference,
  getAddressableEventCoordinate,
  getEventIdFromReference,
  type RawEvent,
} from './nostr';
import { ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from './noteEngagement';
import {
  compareSocialEventsNewestFirst,
  isNewerReplaceableEvent,
  mergeSocialEventsByNewest,
} from './socialRepository';

export type OptimisticNoteEngagement = {
  reactionCountDelta: number;
  viewerReacted: boolean;
};

export type NoteDetailEventsByKind = Record<NoteDetailListKind, RawEvent[]>;

export function createEmptyNoteDetailEvents(): NoteDetailEventsByKind {
  return {
    likes: [],
    reposts: [],
    zaps: [],
  };
}

export function mergeNotesByNewest(...noteLists: RawEvent[][]): RawEvent[] {
  const sourceById = new Map<string, RawEvent>();
  for (const notes of noteLists) {
    for (const event of notes) {
      if (!sourceById.has(event.id)) {
        sourceById.set(event.id, event);
      }
    }
  }
  return mergeSocialEventsByNewest(...noteLists).map(
    (event) => sourceById.get(event.id) ?? event,
  );
}

export function mergeVisibleNotes(
  localNotes: RawEvent[],
  baseNotes: RawEvent[],
): RawEvent[] {
  return mergeNotesByNewest(localNotes, baseNotes);
}

export function getUniqueRoots(...candidates: Array<CID | null>): CID[] {
  const seen = new Set<string>();
  const roots: CID[] = [];

  for (const candidate of candidates) {
    if (!candidate) {
      continue;
    }

    const rootKey = getRootNhash(candidate);
    if (seen.has(rootKey)) {
      continue;
    }

    seen.add(rootKey);
    roots.push(candidate);
  }

  return roots;
}

export function buildDisplayedNoteEngagements(
  engagements: Map<string, NoteEngagement>,
  optimisticEngagements: Map<string, OptimisticNoteEngagement>,
): Map<string, NoteEngagement> {
  const nextEngagements = new Map(engagements);

  for (const [noteId, optimistic] of optimisticEngagements) {
    const base = nextEngagements.get(noteId) ?? ZERO_NOTE_ENGAGEMENT;
    const reactionCountDelta = optimistic.viewerReacted && base.viewerReacted
      ? 0
      : optimistic.reactionCountDelta;
    nextEngagements.set(noteId, {
      ...base,
      reactionCount: base.reactionCount + reactionCountDelta,
      viewerReacted: base.viewerReacted || optimistic.viewerReacted,
    });
  }

  return nextEngagements;
}

export function clearCaughtUpOptimisticEngagements(
  optimisticEngagements: Map<string, OptimisticNoteEngagement>,
  engagements: Map<string, NoteEngagement>,
): Map<string, OptimisticNoteEngagement> {
  const nextOptimistic = new Map(optimisticEngagements);
  for (const [noteId, engagement] of engagements) {
    if (engagement.viewerReacted && nextOptimistic.has(noteId)) {
      nextOptimistic.delete(noteId);
    }
  }
  return nextOptimistic;
}

export function createKnownNotesCache(maxKnownNoteCount: number) {
  const knownNotesById = new Map<string, RawEvent>();
  const knownNotesByAddress = new Map<string, RawEvent>();
  const knownNoteIdsByAuthor = new Map<string, Set<string>>();

  function addAuthorEntry(event: RawEvent): void {
    const ids = knownNoteIdsByAuthor.get(event.pubkey) ?? new Set<string>();
    ids.add(event.id);
    knownNoteIdsByAuthor.set(event.pubkey, ids);
  }

  function removeAuthorEntry(event: RawEvent): void {
    const ids = knownNoteIdsByAuthor.get(event.pubkey);
    if (!ids) {
      return;
    }
    ids.delete(event.id);
    if (ids.size === 0) {
      knownNoteIdsByAuthor.delete(event.pubkey);
    }
  }

  function restoreAddressWinner(address: string): void {
    let winner: RawEvent | null = null;
    for (const candidate of knownNotesById.values()) {
      if (
        getAddressableEventCoordinate(candidate) === address
        && (!winner || isNewerReplaceableEvent(candidate, winner))
      ) {
        winner = candidate;
      }
    }
    if (winner) {
      knownNotesByAddress.set(address, winner);
    } else {
      knownNotesByAddress.delete(address);
    }
  }

  function remove(event: RawEvent): void {
    knownNotesById.delete(event.id);
    removeAuthorEntry(event);
    const address = getAddressableEventCoordinate(event);
    if (address && knownNotesByAddress.get(address)?.id === event.id) {
      restoreAddressWinner(address);
    }
  }

  function remember(event: RawEvent): boolean {
    const existing = knownNotesById.get(event.id);
    if (existing && existing.created_at >= event.created_at) {
      return false;
    }

    if (existing) {
      remove(existing);
    }

    knownNotesById.set(event.id, event);
    addAuthorEntry(event);
    const address = getAddressableEventCoordinate(event);
    const knownAddressEvent = address ? knownNotesByAddress.get(address) : null;
    if (address && (!knownAddressEvent || isNewerReplaceableEvent(event, knownAddressEvent))) {
      knownNotesByAddress.set(address, event);
    }
    while (knownNotesById.size > maxKnownNoteCount) {
      let oldestEvent: RawEvent | null = null;
      for (const candidate of knownNotesById.values()) {
        if (
          !oldestEvent
          || candidate.created_at < oldestEvent.created_at
          || (candidate.created_at === oldestEvent.created_at && candidate.id > oldestEvent.id)
        ) {
          oldestEvent = candidate;
        }
      }
      if (!oldestEvent) {
        break;
      }
      remove(oldestEvent);
    }
    return knownNotesById.has(event.id);
  }

  function cache(...noteLists: RawEvent[][]): boolean {
    let changed = false;
    for (const notes of noteLists) {
      for (const event of notes) {
        changed = remember(event) || changed;
      }
    }
    return changed;
  }

  function getByRef(ref: string): RawEvent | null {
    const eventId = getEventIdFromReference(ref);
    if (eventId) {
      return knownNotesById.get(eventId) ?? null;
    }

    const address = getAddressableCoordinateFromReference(ref);
    return address ? knownNotesByAddress.get(address) ?? null : null;
  }

  function snapshot(): RawEvent[] {
    return [...knownNotesById.values()]
      .filter((event) => {
        const address = getAddressableEventCoordinate(event);
        return !address || knownNotesByAddress.get(address)?.id === event.id;
      })
      .sort(compareSocialEventsNewestFirst);
  }

  function snapshotByAuthor(pubkey: string): RawEvent[] {
    return [...(knownNoteIdsByAuthor.get(pubkey) ?? [])]
      .map((id) => knownNotesById.get(id))
      .filter((event): event is RawEvent => {
        if (!event) {
          return false;
        }
        const address = getAddressableEventCoordinate(event);
        return !address || knownNotesByAddress.get(address)?.id === event.id;
      })
      .sort(compareSocialEventsNewestFirst);
  }

  return {
    remember,
    cache,
    getByRef,
    snapshot,
    snapshotByAuthor,
  };
}
