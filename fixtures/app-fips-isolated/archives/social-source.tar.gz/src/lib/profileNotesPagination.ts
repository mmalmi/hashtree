import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import type { RawEvent } from './nostr';
import { getRootNhash } from './nostrIndex';
import type {
  ProfileNotesPage,
  ProfileNotesRootContinuation,
  ProfileSnapshot,
} from './profileNotes';

export function getProfileRootContinuations(
  snapshot: ProfileSnapshot,
): ProfileNotesRootContinuation[] {
  const continuations = (snapshot.durableRootContinuations ?? []).map((continuation) => ({
    ...continuation,
    cursor: continuation.cursor ? { ...continuation.cursor } : null,
  }));
  const hasPrimaryContinuation = continuations.some(
    (continuation) => continuation.rootNhash === snapshot.rootNhash,
  );
  const hasLegacyPrimaryState = snapshot.durableCursor !== undefined
    || snapshot.durableHasMore !== undefined
    || snapshot.durableNoteCount !== undefined;
  if (!hasPrimaryContinuation && hasLegacyPrimaryState) {
    continuations.unshift({
      rootNhash: snapshot.rootNhash,
      cursor: snapshot.durableCursor ?? null,
      hasMore: snapshot.durableHasMore ?? true,
      noteCount: snapshot.durableNoteCount ?? 0,
    });
  }
  return continuations;
}

function getProfileRootContinuation(
  snapshot: ProfileSnapshot,
  rootNhash: string,
): ProfileNotesRootContinuation | null {
  return getProfileRootContinuations(snapshot).find(
    (continuation) => continuation.rootNhash === rootNhash,
  ) ?? null;
}

export function withProfileRootContinuation(
  snapshot: ProfileSnapshot,
  nextContinuation: ProfileNotesRootContinuation,
): ProfileSnapshot {
  const continuations = getProfileRootContinuations(snapshot);
  const existingIndex = continuations.findIndex(
    (continuation) => continuation.rootNhash === nextContinuation.rootNhash,
  );
  if (existingIndex >= 0) {
    continuations[existingIndex] = nextContinuation;
  } else {
    continuations.push(nextContinuation);
  }
  continuations.sort((left, right) => {
    if (left.rootNhash === snapshot.rootNhash) {
      return -1;
    }
    if (right.rootNhash === snapshot.rootNhash) {
      return 1;
    }
    return left.rootNhash.localeCompare(right.rootNhash);
  });
  const primaryContinuation = continuations.find(
    (continuation) => continuation.rootNhash === snapshot.rootNhash,
  );
  return {
    ...snapshot,
    durableCursor: primaryContinuation?.cursor ?? snapshot.durableCursor ?? null,
    durableHasMore: continuations.some((continuation) => continuation.hasMore),
    durableNoteCount: continuations.reduce(
      (total, continuation) => total + continuation.noteCount,
      0,
    ),
    durableRootContinuations: continuations,
  };
}

function cursorMatches(
  left: ProfileNotesRootContinuation['cursor'],
  right: ProfileNotesRootContinuation['cursor'],
): boolean {
  return left?.createdAt === right?.createdAt && left?.eventId === right?.eventId;
}

type AppendProfileNotesPagesOptions = {
  currentRoot: CID;
  personalRoot: CID | null;
  pubkey: string;
  pageSize: number;
  maxRounds: number;
  matchesVisibleSection: (event: RawEvent) => boolean;
  initialSnapshot: ProfileSnapshot;
  isCurrent: () => boolean;
  getSnapshot: () => ProfileSnapshot | null;
  setSnapshot: (snapshot: ProfileSnapshot) => void;
  cacheKnownNotes: (notes: RawEvent[]) => void;
  mergeLocalVisibleNotes: (notes: RawEvent[], pubkey: string) => RawEvent[];
  clearEmptyRetry: () => void;
  loadPage: (
    root: CID,
    pubkey: string,
    limit: number,
    before: NonNullable<ProfileNotesRootContinuation['cursor']>,
  ) => Promise<ProfileNotesPage>;
};

export type AppendProfileNotesPagesResult = {
  appended: RawEvent[];
  error: unknown | null;
  needsInitialLoad: boolean;
  stale: boolean;
};

export async function appendNextProfileNotesPages(
  options: AppendProfileNotesPagesOptions,
): Promise<AppendProfileNotesPagesResult> {
  const rootNhash = getRootNhash(options.currentRoot);
  if (getProfileRootContinuations(options.initialSnapshot).length === 0) {
    return { appended: [], error: null, needsInitialLoad: true, stale: false };
  }

  const roots = [options.currentRoot];
  if (options.personalRoot && getRootNhash(options.personalRoot) !== rootNhash) {
    roots.push(options.personalRoot);
  }
  const appendedById = new Map<string, RawEvent>();
  const seenEventIds = new Set(options.initialSnapshot.notes.map((event) => event.id));
  let visibleMatches = 0;
  let primaryVisibleMatches = 0;
  let firstError: unknown = null;
  let stale = false;
  let stopOptionalRoots = false;
  let markPrimaryPageReady = (): void => undefined;
  const primaryPageReady = new Promise<void>((resolve) => {
    markPrimaryPageReady = resolve;
  });

  const rootLoads = roots.map(async (pageRoot) => {
    const pageRootNhash = getRootNhash(pageRoot);
    const isPrimaryRoot = pageRootNhash === rootNhash;
    let pageCount = 0;
    while (visibleMatches < Math.max(options.pageSize, 1) && pageCount < options.maxRounds) {
      if (!isPrimaryRoot && stopOptionalRoots) {
        return;
      }
      const currentSnapshot = options.getSnapshot();
      if (!options.isCurrent() || !currentSnapshot || currentSnapshot.rootNhash !== rootNhash) {
        stale = true;
        return;
      }
      const continuation = getProfileRootContinuation(currentSnapshot, pageRootNhash);
      if (!continuation?.hasMore || !continuation.cursor) {
        return;
      }
      try {
        const page = await options.loadPage(
          pageRoot,
          options.pubkey,
          Math.max(options.pageSize, 1),
          continuation.cursor!,
        );
        // The primary archive has already filled the requested visible page.
        // Leave this optional root's cursor unchanged so a later explicit page
        // can retry it; do not let a slow in-flight read hold the UI pending.
        if (!isPrimaryRoot && stopOptionalRoots) {
          return;
        }
        if (!options.isCurrent()) {
          stale = true;
          return;
        }

        const latestSnapshot = options.getSnapshot();
        if (!latestSnapshot || latestSnapshot.rootNhash !== rootNhash) {
          stale = true;
          return;
        }
        const latestContinuation = getProfileRootContinuation(latestSnapshot, pageRootNhash);
        // Personal discovery can finish while a continuation read is in
        // flight. Never move that root backwards from a newer cursor.
        if (!latestContinuation || !cursorMatches(
          latestContinuation.cursor,
          continuation.cursor,
        )) {
          return;
        }

        // Cache before painting the page. A newly visible card can then open
        // an optimistic thread even while another root remains slow.
        options.cacheKnownNotes(page.notes);
        for (const note of page.notes) {
          if (seenEventIds.has(note.id)) {
            continue;
          }
          seenEventIds.add(note.id);
          appendedById.set(note.id, note);
          if (options.matchesVisibleSection(note)) {
            visibleMatches += 1;
            if (isPrimaryRoot) {
              primaryVisibleMatches += 1;
            }
          }
        }

        const mergedNotes = mergeNotesByNewest(latestSnapshot.notes, page.notes);
        const latestVisibleNotes = options.mergeLocalVisibleNotes(mergedNotes, options.pubkey);
        options.setSnapshot(withProfileRootContinuation({
          ...latestSnapshot,
          notes: mergedNotes,
        }, {
          rootNhash: pageRootNhash,
          cursor: page.cursor ?? latestContinuation.cursor,
          hasMore: page.hasMore && page.notes.length > 0,
          noteCount: latestContinuation.noteCount + page.notes.length,
        }));
        if (latestVisibleNotes.length > 0) {
          options.clearEmptyRetry();
        }
        if (primaryVisibleMatches >= Math.max(options.pageSize, 1)) {
          markPrimaryPageReady();
        }
        pageCount += 1;
      } catch (error) {
        firstError ??= error;
        console.warn(`Failed to append profile notes from ${pageRootNhash}`, error);
        return;
      }
    }
  });
  const allRootsLoaded = Promise.all(rootLoads);
  if (roots.length > 1) {
    const firstCompleted = await Promise.race([
      allRootsLoaded.then(() => 'all-roots' as const),
      primaryPageReady.then(() => 'primary-page' as const),
    ]);
    if (firstCompleted === 'primary-page') {
      stopOptionalRoots = true;
    }
  } else {
    await allRootsLoaded;
  }
  if (!options.isCurrent()) {
    stale = true;
  }

  return {
    appended: [...appendedById.values()],
    error: firstError,
    needsInitialLoad: false,
    stale,
  };
}
