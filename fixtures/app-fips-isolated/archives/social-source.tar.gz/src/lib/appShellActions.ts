import type { createAppFeedPreferences } from './appFeedPreferences';
import type { createAppHistoryNavigation } from './appHistoryNavigation';
import type { createAppInfiniteScrollController } from './appInfiniteScrollController';
import type { createAppMediaController } from './appMediaController';
import type { createAppScrollController } from './appScrollController';
import type { AppCombinedState } from './appState';
import type { createAppUserActionControllers } from './appUserActionControllers';
import type { AppShellActions } from './components/app-shell';
import type { RawEvent } from './nostr';
import { buildNoteThreadReference } from './appSharing';

type ShellActionSources = {
  state: AppCombinedState;
  user: ReturnType<typeof createAppUserActionControllers>;
  feed: ReturnType<typeof createAppFeedPreferences>;
  history: ReturnType<typeof createAppHistoryNavigation>;
  media: ReturnType<typeof createAppMediaController>;
  scroll: ReturnType<typeof createAppScrollController>;
  infinite: ReturnType<typeof createAppInfiniteScrollController>;
  loadAccountSheet: () => Promise<void>;
  loadSearchPage: () => Promise<void>;
  loadMoreFeed: () => Promise<void>;
  loadMoreProfileNotes: () => Promise<void>;
  loadMoreProfileSocial: (section?: 'follows' | 'followers', limit?: number) => Promise<void>;
  loadMoreThreadReplies: () => Promise<void>;
  cachePresentedHomeNote: (event: RawEvent) => void;
  markHomeNoteSeen: (event: RawEvent, presentedEvent: RawEvent | null) => void;
};

export function createAppShellActions(sources: ShellActionSources): AppShellActions {
  const { state, user, feed, history, media, scroll, infinite } = sources;

  function openPostComposer(opener?: HTMLElement): void {
    if (state.postComposer || !state.activeAccount) {return;}
    state.postComposer = {
      returnFocusTo: opener ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null),
    };
  }

  function closePostComposer(): void {
    state.postComposer = null;
  }

  return {
    handleWindowChromeClick: user.handleWindowChromeClick,
    handleWindowChromeKeydown: user.handleWindowChromeKeydown,
    handleHomeLinkClick: history.handleHomeLinkClick,
    scrollPageToTopInstant: scroll.scrollPageToTopInstant,
    navigateBack: history.navigateBack,
    openPostComposer,
    closePostComposer,
    navigateActiveProfile: history.navigateActiveProfile,
    navigateAccounts: history.navigateAccounts,
    navigateProfile: history.navigateProfile,
    navigateThread: history.navigateThread,
    navigateHomeTab: history.navigateHomeTab,
    navigateSettings: history.navigateSettings,
    replaceUsernameWithProfile: history.replaceUsernameWithProfile,
    openSearchSheet: user.openSearchSheet,
    handleSearchQueryChange: user.handleSearchQueryChange,
    handleSearchTabChange: user.handleSearchTabChange,
    handleSearchOpenProfile: user.handleSearchOpenProfile,
    handleHeaderSearchPosts: user.handleHeaderSearchPosts,
    handleSearchOpenPost: user.handleSearchOpenPost,
    handleSearchOpenThread: user.handleSearchOpenThread,
    setSearchDropdownRoot: (root) => {
      state.searchDropdownRoot = root;
    },
    loadSearchPage: sources.loadSearchPage,
    loadAccountSheet: sources.loadAccountSheet,
    handleCreateAccount: user.handleCreateAccount,
    handleImportAccount: user.handleImportAccount,
    handleRemoteLogin: user.handleRemoteLogin,
    handleExtensionLogin: user.handleExtensionLogin,
    handleAccountInput: user.handleAccountInput,
    handleSwitchAccount: user.handleSwitchAccount,
    handleRemoveAccount: user.handleRemoveAccount,
    handleComposerInput: user.handleComposerInput,
    bindComposerAttachments: user.bindComposerAttachments,
    handleComposerAttachmentsChange: user.handleComposerAttachmentsChange,
    handleCreatePostSubmit: async (payload) => {
      const composer = state.postComposer;
      const post = await user.handleCreatePostSubmit(payload);
      if (post && composer && state.postComposer === composer) {
        closePostComposer();
        history.navigateThread(buildNoteThreadReference(post));
      }
    },
    loadMoreFeed: sources.loadMoreFeed,
    loadMoreNotifications: infinite.loadMoreNotifications,
    loadMoreProfileNotes: sources.loadMoreProfileNotes,
    loadMoreProfileSocial: sources.loadMoreProfileSocial,
    loadMoreThreadReplies: sources.loadMoreThreadReplies,
    showBufferedLiveHomePosts: user.showBufferedLiveHomePosts,
    handleSelectFeedView: feed.handleSelectFeedView,
    openFeedSourceSheet: feed.openFeedSourceSheet,
    setFeedSourceSheetOpen: (open) => {
      state.feedSourceSheetOpen = open;
    },
    handleFeedSourceNameChange: feed.handleFeedSourceNameChange,
    handleFeedSourceIdentityChange: feed.handleFeedSourceIdentityChange,
    addFeedSource: feed.addFeedSource,
    selectFeedSource: feed.selectFeedSource,
    removeFeedSource: feed.removeFeedSource,
    handleThreadReplyInput: user.handleThreadReplyInput,
    bindThreadReplyAttachments: user.bindThreadReplyAttachments,
    handleThreadReplySubmit: user.handleThreadReplySubmit,
    handleLike: user.handleLike,
    handleZap: user.handleZap,
    sendZap: user.sendZap,
    openZapAll: user.openZapAll,
    handleReplyAction: user.handleReplyAction,
    handleQuoteAction: (event) => {
      const reference = `nostr:${buildNoteThreadReference(event)}`;
      if (!state.composerValue.includes(reference)) {
        user.handleComposerInput([state.composerValue.trimEnd(), reference].filter(Boolean).join('\n\n'));
      }
      openPostComposer();
    },
    handleRepost: user.handleRepost,
    openNoteDetailSheet: (event, kind) => user.noteInteractions.openNoteDetailSheet(event, kind),
    closeDetailSheet: () => user.noteInteractions.closeDetailSheet(),
    loadMoreNoteDetails: (kind) => user.noteInteractions.loadMoreNoteDetails(kind),
    setDetailSheetKind: (kind) => {
      state.detailSheetKind = kind;
    },
    copyNoteLink: (event) => user.noteInteractions.copyNoteLink(event),
    copyEventId: (event) => user.noteInteractions.copyEventId(event),
    rebroadcast: (event) => user.noteInteractions.rebroadcast(event),
    handleDelete: user.handleDelete,
    cachePresentedHomeNote: sources.cachePresentedHomeNote,
    markHomeNoteSeen: sources.markHomeNoteSeen,
    handleViewAsProfile: user.handleViewAsProfile,
    handleToggleFollow: user.handleToggleFollow,
    handleToggleMute: user.handleToggleMute,
    handleCopyPubkey: user.handleCopyPubkey,
    handleCopyNpub: user.handleCopyNpub,
    handleCopyProfileLink: user.handleCopyProfileLink,
    handleOpenWebsite: user.handleOpenWebsite,
    handleSaveProfile: user.handleSaveProfile,
    handleRegisterIrisUsername: user.handleRegisterIrisUsername,
    handleOpenMedia: media.handleOpenMedia,
    handleOpenProfileImage: media.handleOpenProfileImage,
    handleCloseMedia: media.handleCloseMedia,
    handleMediaIndexChange: media.handleMediaIndexChange,
    handleModalOpenProfile: media.handleModalOpenProfile,
    handleModalOpenNote: media.handleModalOpenNote,
    setZapAllSheetOpen: (open) => {
      state.zapAllSheetOpen = open;
    },
    handleZapAllStart: user.handleZapAllStart,
  };
}
