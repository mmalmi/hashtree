import type { ProfileRecord, RawEvent } from './nostr';
import type { NoteDetailListKind } from './nostrIndex';
import { validateZapReceipt } from './zapReceipt';

export type NoteDetailRow = {
  actor: string;
  description: string;
  event: RawEvent;
  totalBits: number;
};

function isNewer(candidate: RawEvent, current: RawEvent): boolean {
  return candidate.created_at > current.created_at
    || (candidate.created_at === current.created_at && candidate.id < current.id);
}

function likeDescription(content: string): string {
  const normalized = content.trim();
  return normalized === '+' || normalized.length === 0 ? '❤️' : normalized;
}

export function buildNoteDetailRows(
  activeKind: NoteDetailListKind,
  events: RawEvent[],
  _knownProfiles: Map<string, ProfileRecord>,
): NoteDetailRow[] {
  if (activeKind === 'zaps') {
    const groups = new Map<string, NoteDetailRow>();
    for (const event of events) {
      const zap = validateZapReceipt(event);
      if (!zap) {
        continue;
      }
      const existing = groups.get(zap.senderPubkey);
      const latestEvent = existing && !isNewer(zap.request, existing.event)
        ? existing.event
        : zap.request;
      const comment = latestEvent.content.trim();
      const totalBits = (existing?.totalBits ?? 0) + zap.bits;
      groups.set(zap.senderPubkey, {
        actor: zap.senderPubkey,
        description: `${comment ? `${comment} · ` : ''}${totalBits.toLocaleString()} bits`,
        event: latestEvent,
        totalBits,
      });
    }
    return [...groups.values()].sort((left, right) => (
      right.totalBits - left.totalBits
      || right.event.created_at - left.event.created_at
      || left.actor.localeCompare(right.actor)
    ));
  }

  const newestByAuthor = new Map<string, RawEvent>();
  for (const event of events) {
    const existing = newestByAuthor.get(event.pubkey);
    if (!existing || isNewer(event, existing)) {
      newestByAuthor.set(event.pubkey, event);
    }
  }

  return [...newestByAuthor.entries()]
    .map(([actor, event]): NoteDetailRow => ({
      actor,
      description: activeKind === 'likes' ? likeDescription(event.content) : '',
      event,
      totalBits: 0,
    }))
    .sort((left, right) => (
      right.event.created_at - left.event.created_at
      || left.actor.localeCompare(right.actor)
    ));
}
