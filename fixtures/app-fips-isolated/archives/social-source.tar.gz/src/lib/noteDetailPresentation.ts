import type { ProfileRecord, RawEvent } from './nostr';
import type { SocialGraphBadge } from './socialGraphBadgeQuery';
import type { NoteDetailListKind } from './nostrIndex';
import { validateZapReceipt, type ValidatedZapReceipt } from './zapReceipt';

export type NoteDetailRow = {
  actor: string;
  description: string;
  message?: string;
  event: RawEvent;
  totalBits: number;
};

function isNewer(candidate: RawEvent, current: RawEvent): boolean {
  return candidate.created_at > current.created_at
    || (candidate.created_at === current.created_at && candidate.id < current.id);
}

function likeDescription(content: string): string {
  const normalized = content.trim();
  return normalized === '+' || normalized.length === 0 ? '❤️' : normalized;
}

function preferZap(candidate: ValidatedZapReceipt, current: ValidatedZapReceipt): boolean {
  if (candidate.amountMillisats !== current.amountMillisats) {
    return candidate.amountMillisats > current.amountMillisats;
  }
  const hasMessage = Boolean(candidate.request.content.trim());
  const currentHasMessage = Boolean(current.request.content.trim());
  return hasMessage !== currentHasMessage ? hasMessage : isNewer(candidate.receipt, current.receipt);
}

function buildZapRows(events: RawEvent[]): NoteDetailRow[] {
  const payments = new Map<string, ValidatedZapReceipt>();
  for (const event of events) {
    const zap = validateZapReceipt(event);
    if (!zap) {continue;}
    const current = payments.get(zap.paymentKey);
    if (!current) {payments.set(zap.paymentKey, zap); continue;}
    // Multiple signed wrappers may describe one payment. Keep its original
    // receipt, withhold attribution on a privacy marker or conflicting sender.
    const order = current.amountMillisats - zap.amountMillisats
      || current.receipt.created_at - event.created_at || current.receipt.id.localeCompare(event.id);
    const earliest = order <= 0 ? current : zap;
    const anonymous = current.anonymous || zap.anonymous || current.senderPubkey !== zap.senderPubkey;
    payments.set(zap.paymentKey, { ...earliest, anonymous });
  }
  const groups = new Map<string, { largest: ValidatedZapReceipt; total: bigint; latest: RawEvent }>();
  for (const zap of payments.values()) {
    const event = zap.receipt;
    const key = zap.anonymous ? 'anonymous' : zap.senderPubkey;
    const group = groups.get(key);
    if (!group) {
      groups.set(key, { largest: zap, total: BigInt(zap.amountMillisats), latest: event });
      continue;
    }
    group.total += BigInt(zap.amountMillisats);
    if (isNewer(event, group.latest)) {group.latest = event;}
    if (!zap.anonymous && preferZap(zap, group.largest)) {group.largest = zap;}
  }

  return [...groups.values()].sort((left, right) => {
    if (left.total !== right.total) {return left.total > right.total ? -1 : 1;}
    return right.latest.created_at - left.latest.created_at || left.latest.id.localeCompare(right.latest.id);
  }).map(({ largest, total, latest }) => {
    const totalBits = Number(total / 1_000n);
    return {
      actor: largest.anonymous ? '' : largest.senderPubkey,
      description: `${totalBits.toLocaleString()} bits`,
      message: largest.anonymous ? '' : largest.request.content.trim(),
      event: latest,
      totalBits,
    };
  });
}

export function buildNoteDetailRows(
  activeKind: NoteDetailListKind,
  events: RawEvent[],
  _knownProfiles: Map<string, ProfileRecord>,
): NoteDetailRow[] {
  if (activeKind === 'zaps') {return buildZapRows(events);}

  const newestByAuthor = new Map<string, RawEvent>();
  for (const event of events) {
    const existing = newestByAuthor.get(event.pubkey);
    if (!existing || isNewer(event, existing)) {
      newestByAuthor.set(event.pubkey, event);
    }
  }

  return [...newestByAuthor.entries()]
    .map(([actor, event]): NoteDetailRow => ({
      actor,
      description: activeKind === 'likes' ? likeDescription(event.content) : '',
      event,
      totalBits: 0,
    }))
    .sort((left, right) => (
      right.event.created_at - left.event.created_at
      || left.actor.localeCompare(right.actor)
    ));
}

// Rows already have deterministic newest-first order. Stable sort preserves
// it within ties while reading each viewer-scoped badge only once.
export function sortLikeRows(
  rows: NoteDetailRow[],
  viewer: string | null,
  follows: ReadonlySet<string>,
  badges: ReadonlyMap<string, SocialGraphBadge>,
): NoteDetailRow[] {
  if (!viewer || rows.length < 2) { return rows; }
  return rows.map(row => {
    const badge = badges.get(row.actor);
    const distance = row.actor === viewer ? 0 : follows.has(row.actor) ? 1 : badge?.distance ?? Number.MAX_SAFE_INTEGER;
    const mutuals = distance === 1 ? badge?.followedByFriends ?? 0 : 0;
    return { row, distance, mutuals };
  }).sort((left, right) => left.distance - right.distance || right.mutuals - left.mutuals)
    .map(entry => entry.row);
}
