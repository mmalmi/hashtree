import type { ProfileRecord } from './nostr';
import {
  createMediaSelection,
  createProfileMediaSelection,
  type MediaOpenPayload,
} from './appMedia';
import type { AppCombinedState } from './appState';

type AppMediaControllerDeps = {
  state: AppCombinedState;
  getCurrentProfile: () => ProfileRecord | null;
  navigateProfile: (pubkey: string) => void;
  navigateThread: (target: string) => void;
  resolveProfile: (pubkey: string) => ProfileRecord | null;
};

export function createAppMediaController(deps: AppMediaControllerDeps) {
  function handleOpenMedia(payload: MediaOpenPayload): void {
    const nextSelection = createMediaSelection(
      payload,
      deps.resolveProfile(payload.event.pubkey),
    );
    if (nextSelection) {
      deps.state.mediaSelection = nextSelection;
      deps.state.mediaModalOpen = true;
    }
  }

  function handleOpenProfileImage(url: string, label: string): void {
    const selection = createProfileMediaSelection(url, label, deps.getCurrentProfile());
    if (selection) {
      deps.state.mediaSelection = selection;
      deps.state.mediaModalOpen = true;
    }
  }

  function handleCloseMedia(): void {
    if (!deps.state.mediaModalOpen && !deps.state.mediaSelection) {
      return;
    }
    deps.state.mediaModalOpen = false;
    deps.state.mediaSelection = null;
  }

  function handleMediaIndexChange(nextIndex: number): void {
    const selection = deps.state.mediaSelection;
    if (!selection) {
      return;
    }
    deps.state.mediaSelection = {
      ...selection,
      index: Math.max(0, Math.min(selection.embeds.length - 1, nextIndex)),
    };
  }

  function handleModalOpenProfile(pubkey: string): void {
    handleCloseMedia();
    deps.navigateProfile(pubkey);
  }

  function handleModalOpenNote(target: string): void {
    handleCloseMedia();
    deps.navigateThread(target);
  }

  return {
    handleCloseMedia,
    handleMediaIndexChange,
    handleModalOpenNote,
    handleModalOpenProfile,
    handleOpenMedia,
    handleOpenProfileImage,
  };
}
