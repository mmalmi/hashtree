import type { CollectionSource } from '@hashtree/collection';
import {
  MANIFEST_BY_AUTHOR_KIND_TIME,
  MANIFEST_BY_AUTHOR_TIME,
  MANIFEST_BY_KIND_TIME,
  MANIFEST_BY_KIND_TIME_AUTHOR,
  MANIFEST_BY_TAG,
  MANIFEST_BY_TIME,
} from '@hashtree/nostr';

export type NostrCollectionIndexes = {
  byAuthorTime: boolean;
  byAuthorKindTime: boolean;
  byKindTime: boolean;
  byKindTimeAuthor: boolean;
  byTag: boolean;
  byTime: boolean;
};

export const EMPTY_NOSTR_COLLECTION_INDEXES: NostrCollectionIndexes = {
  byAuthorTime: false,
  byAuthorKindTime: false,
  byKindTime: false,
  byKindTimeAuthor: false,
  byTag: false,
  byTime: false,
};

export function hasCollectionIndex(source: CollectionSource, indexName: string): boolean {
  return Boolean(source.manifest.indexes[indexName]?.root);
}

export function getNostrCollectionIndexes(source: CollectionSource): NostrCollectionIndexes {
  return {
    byAuthorTime: hasCollectionIndex(source, MANIFEST_BY_AUTHOR_TIME),
    byAuthorKindTime: hasCollectionIndex(source, MANIFEST_BY_AUTHOR_KIND_TIME),
    byKindTime: hasCollectionIndex(source, MANIFEST_BY_KIND_TIME),
    byKindTimeAuthor: hasCollectionIndex(source, MANIFEST_BY_KIND_TIME_AUTHOR),
    byTag: hasCollectionIndex(source, MANIFEST_BY_TAG),
    byTime: hasCollectionIndex(source, MANIFEST_BY_TIME),
  };
}

export function hasAnyNostrCollectionIndex(indexes: NostrCollectionIndexes): boolean {
  return Object.values(indexes).some(Boolean);
}
