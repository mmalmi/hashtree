import {
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  nhashDecode,
  sha256,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';
import { throwIfProfileSearchAborted, withProfileSearchAbort } from './profileSearchAbort';
import {
  MAX_EVENT_TAG_BYTES,
  MAX_EVENT_TAG_ITEM_BYTES,
  MAX_EVENT_TAG_ITEMS,
  MAX_EVENT_TAGS,
  MAX_PACKED_KEY_BYTES,
  MAX_PREFIX_CODEPOINTS,
  MAX_TERM_BYTES,
  SEPARATOR,
  type ProfileSearchV3ClientHit,
  type ProfileSearchV3ClientPageKind,
  type ProfileSearchV3ClientPostingMode,
  type ProfileSearchV3ClientWireNodeDescriptor,
  type ProfileSearchV3ClientWirePageDescriptor,
} from './profileSearchV3ClientTypes';

const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export function parsePostingKey(key: string): {
  mode: ProfileSearchV3ClientPostingMode;
  term: string;
  rankHint: number;
  pubkey: string;
} {
  const parts = key.split(SEPARATOR);
  if (parts.length !== 4 || parts[0]?.length !== 1 || !/^\d{16}$/.test(parts[2] ?? '')) {
    throw new Error('Invalid profile-search v3 posting key');
  }
  const mode = codeMode(parts[0]!);
  const term = boundedTerm(parts[1], 'posting term');
  const rankHint = nonNegativeInteger(Number(parts[2]), 'posting rankHint');
  const pubkey = strictPubkey(parts[3], 'posting pubkey');
  if (`${modeCode(mode)}${SEPARATOR}${term}${SEPARATOR}`
    + `${rankHint.toString().padStart(16, '0')}${SEPARATOR}${pubkey}` !== key) {
    throw new Error('Invalid profile-search v3 posting key');
  }
  return { mode, term, rankHint, pubkey };
}

export function mergeHits(
  batches: readonly (readonly ProfileSearchV3ClientHit[])[],
  limit: number,
): ProfileSearchV3ClientHit[] {
  const byPubkey = new Map<string, ProfileSearchV3ClientHit>();
  for (const hit of batches.flat()) {
    const current = byPubkey.get(hit.event.pubkey);
    if (!current || compareHits(hit, current) < 0) {byPubkey.set(hit.event.pubkey, hit);}
  }
  return [...byPubkey.values()].sort(compareHits).slice(0, limit);
}

export function compareHits(
  left: ProfileSearchV3ClientHit,
  right: ProfileSearchV3ClientHit,
): number {
  return right.textScore - left.textScore
    || left.rankHint - right.rankHint
    || right.event.created_at - left.event.created_at
    || compareText(left.event.pubkey, right.event.pubkey);
}

export function uniqueRoutes(
  routes: Array<{ mode: ProfileSearchV3ClientPostingMode; term: string }>,
): Array<{ mode: ProfileSearchV3ClientPostingMode; term: string }> {
  const seen = new Set<string>();
  return routes.filter((route) => {
    if (!route.term) {return false;}
    const key = `${route.mode}${SEPARATOR}${route.term}`;
    if (seen.has(key)) {return false;}
    seen.add(key);
    return true;
  });
}

export function queryTrigrams(value: string): string[] {
  const grams: string[] = [];
  for (const word of searchWords(value)) {
    const points = [...word];
    for (let index = 0; points.length >= 3 && index <= points.length - 3; index += 1) {
      grams.push(points.slice(index, index + 3).join(''));
    }
  }
  return [...new Set(grams)];
}

export function searchWords(value: string): string[] {
  return value.split(' ').map((word) => word.trim()).filter(Boolean);
}

export function boundedPrefix(value: string): string {
  return [...value].slice(0, MAX_PREFIX_CODEPOINTS).join('');
}

export function boundedTerm(value: unknown, label: string): string {
  if (typeof value !== 'string') {throw new Error(`Invalid profile-search v3 ${label}`);}
  const bytes = encoder.encode(value);
  if (value.includes(SEPARATOR) || bytes.length > MAX_TERM_BYTES) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function modeCode(mode: ProfileSearchV3ClientPostingMode): string {
  return ({ identifier: 'a', nip05: 'b', identity: 'c', word: 'd', prefix: 'e', trigram: 'f' })[mode];
}

function codeMode(code: string): ProfileSearchV3ClientPostingMode {
  const mode = ({ a: 'identifier', b: 'nip05', c: 'identity', d: 'word', e: 'prefix',
    f: 'trigram' } as const)[code as 'a'];
  if (!mode) {throw new Error('Invalid profile-search v3 posting mode');}
  return mode;
}

export function compareMode(
  left: ProfileSearchV3ClientPostingMode,
  right: ProfileSearchV3ClientPostingMode,
): number {
  return compareText(modeCode(left), modeCode(right));
}

export function normalizeTags(value: unknown): string[][] {
  if (!Array.isArray(value) || value.length > MAX_EVENT_TAGS) {
    throw new Error('Invalid profile-search v3 event tags');
  }
  let bytes = 0;
  return value.map((tag) => {
    if (!Array.isArray(tag) || tag.length > MAX_EVENT_TAG_ITEMS) {
      throw new Error('Invalid profile-search v3 event tag');
    }
    return tag.map((item) => {
      const normalized = boundedStringBytes(item, MAX_EVENT_TAG_ITEM_BYTES, 'event tag item');
      bytes = safeAdd(bytes, encoder.encode(normalized).length);
      if (bytes > MAX_EVENT_TAG_BYTES) {throw new Error('Profile-search v3 event tags exceed capacity');}
      return normalized;
    });
  });
}

export async function readCanonicalDirectory(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
  signal: AbortSignal | null,
) {
  const bytes = await readPublicBlock(store, root, maximum, label, signal);
  let node;
  try {node = decodeTreeNode(bytes);} catch {throw new Error(`Profile-search v3 ${label} is not a directory`);}
  if (node.type !== LinkType.Dir || !equalBytes(bytes, encodeTreeNode(node))) {
    throw new Error(`Profile-search v3 ${label} is not a canonical directory`);
  }
  const names = new Set<string>();
  for (const link of node.links) {
    assertCanonicalLink(link);
    if (!link.name || names.has(link.name)) {
      throw new Error(`Profile-search v3 ${label} has duplicate or unnamed links`);
    }
    names.add(link.name);
  }
  return node;
}

export async function readPublicBlock(
  store: Store,
  root: CID,
  maximum: number,
  label: string,
  signal: AbortSignal | null,
): Promise<Uint8Array> {
  const cid = publicCid(root, label);
  throwIfProfileSearchAborted(signal);
  const bytes = await withProfileSearchAbort(store.get(cid.hash), signal);
  if (!bytes || bytes.length < 1 || bytes.length > maximum) {
    throw new Error(`Missing or oversized profile-search v3 ${label}`);
  }
  const actual = await withProfileSearchAbort(sha256(bytes), signal);
  if (!equalBytes(actual, cid.hash)) {throw new Error(`Profile-search v3 ${label} hash mismatch`);}
  return bytes;
}

export function requiredLink(
  links: readonly Link[],
  name: string,
  type: LinkType,
  label: string,
): Link {
  const link = links.find((candidate) => candidate.name === name);
  if (!link || link.type !== type) {throw new Error(`Profile-search v3 ${label} link is missing`);}
  return link;
}

export function assertExactLinkNames(links: readonly Link[], expected: readonly string[]): void {
  const actual = links.map((link) => link.name ?? '').sort(compareText);
  const wanted = [...expected].sort(compareText);
  if (actual.length !== wanted.length || actual.some((name, index) => name !== wanted[index])) {
    throw new Error('Profile-search v3 directory has missing or unbound links');
  }
}

function assertCanonicalLink(link: Link): void {
  if (!link.name || !Number.isSafeInteger(link.size) || link.size < 0
    || !(link.hash instanceof Uint8Array) || link.hash.length !== 32
    || link.key !== undefined
    || link.type !== LinkType.Blob && link.type !== LinkType.Dir) {
    throw new Error('Profile-search v3 directory contains an invalid or encrypted link');
  }
}

export function publicCid(value: CID, label: string): CID {
  if (!(value?.hash instanceof Uint8Array) || value.hash.length !== 32) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  if (value.key !== undefined) {throw new Error(`Encrypted profile-search v3 ${label} is unsupported`);}
  return { hash: new Uint8Array(value.hash) };
}

export function publicNhash(value: unknown, label: string): CID {
  if (typeof value !== 'string') {throw new Error(`Invalid profile-search v3 ${label}`);}
  try {return publicCid(nhashDecode(value), label);} catch {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
}

export function parseCanonicalJson(bytes: Uint8Array, label: string): Record<string, unknown> {
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {throw new Error(`Invalid profile-search v3 ${label} JSON`);}
  return objectValue(value, label);
}

export function decodeCanonicalString(bytes: Uint8Array): string {
  try {
    const value = decoder.decode(bytes);
    if (!equalBytes(encoder.encode(value), bytes)) {throw new Error('noncanonical');}
    return value;
  } catch {throw new Error('Invalid UTF-8 in profile-search v3 page');}
}

export function objectValue(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value as Record<string, unknown>;
}

export function exactKeys(
  value: Record<string, unknown>,
  keys: readonly string[],
  label: string,
): void {
  const actual = Object.keys(value).sort(compareText);
  const expected = [...keys].sort(compareText);
  if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) {
    throw new Error(`Invalid profile-search v3 ${label} keys`);
  }
}

export function assertOrderedChildren(
  children: Array<ProfileSearchV3ClientWirePageDescriptor | ProfileSearchV3ClientWireNodeDescriptor>,
): void {
  for (let index = 1; index < children.length; index += 1) {
    if (children[index - 1]!.maxKey >= children[index]!.minKey) {
      throw new Error('Profile-search v3 router children overlap or are out of order');
    }
  }
}

export function routerChildName(kind: 'leaf' | 'internal', index: number): string {
  return `${kind === 'leaf' ? 'page' : 'node'}-${index.toString().padStart(3, '0')}`;
}

export function isPageKind(value: unknown): value is ProfileSearchV3ClientPageKind {
  return value === 'documents' || value === 'postings' || value === 'terms' || value === 'visibility';
}

export function queryKey(value: unknown, label: string): string {
  return boundedKey(value, label);
}

export function boundedKey(value: unknown, label: string): string {
  const key = nonEmptyString(value, label);
  if (encoder.encode(key).length > MAX_PACKED_KEY_BYTES) {
    throw new Error(`Profile-search v3 ${label} exceeds capacity`);
  }
  return key;
}

export function boundedStringBytes(value: unknown, maximum: number, label: string): string {
  if (typeof value !== 'string' || encoder.encode(value).length > maximum) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function nonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function strictPubkey(value: unknown, label: string): string {
  const pubkey = strictHex(value, 64, label);
  return pubkey;
}

export function strictHex(value: unknown, length: number, label: string): string {
  if (typeof value !== 'string' || value.length !== length
    || !new RegExp(`^[0-9a-f]{${length}}$`).test(value)) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function nonNegativeInteger(value: unknown, label: string): number {
  return boundedInteger(value, 0, Number.MAX_SAFE_INTEGER, label);
}

export function positiveInteger(value: unknown, label: string): number {
  return boundedInteger(value, 1, Number.MAX_SAFE_INTEGER, label);
}

export function boundedInteger(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)
    || value < minimum || value > maximum) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

export function sum(values: readonly number[]): number {
  return values.reduce((total, value) => safeAdd(total, value), 0);
}

export function safeAdd(left: number, right: number): number {
  const value = left + right;
  if (!Number.isSafeInteger(value)) {throw new Error('Profile-search v3 count exceeds capacity');}
  return value;
}

export async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input) => Promise<Output>,
): Promise<Output[]> {
  const output = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      output[index] = await worker(values[index]!);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return output;
}

export function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

export function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {return false;}
  let different = 0;
  for (let index = 0; index < left.length; index += 1) {different |= left[index]! ^ right[index]!;}
  return different === 0;
}
