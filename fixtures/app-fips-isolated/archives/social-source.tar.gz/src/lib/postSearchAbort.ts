export function postSearchAbortReason(signal: AbortSignal | null): unknown {
  return signal?.reason ?? new DOMException('Post search was cancelled', 'AbortError');
}

export function throwIfPostSearchAborted(signal: AbortSignal | null): void {
  if (signal?.aborted) {
    throw postSearchAbortReason(signal);
  }
}

export async function withPostSearchAbort<T>(
  operation: Promise<T>,
  signal: AbortSignal | null,
): Promise<T> {
  throwIfPostSearchAborted(signal);
  if (!signal) {
    return await operation;
  }

  let abort: (() => void) | null = null;
  const cancelled = new Promise<never>((_resolve, reject) => {
    abort = () => reject(postSearchAbortReason(signal));
    signal.addEventListener('abort', abort, { once: true });
  });
  try {
    return await Promise.race([operation, cancelled]);
  } finally {
    if (abort) {
      signal.removeEventListener('abort', abort);
    }
  }
}

export async function withPostSearchAbortTimeout<T>(
  operation: (signal: AbortSignal) => Promise<T>,
  timeoutMs: number,
  externalSignal: AbortSignal | null = null,
): Promise<T> {
  const controller = new AbortController();
  throwIfPostSearchAborted(externalSignal);
  const abortFromExternal = () => controller.abort(externalSignal?.reason);
  externalSignal?.addEventListener('abort', abortFromExternal, { once: true });
  const timeout = setTimeout(() => {
    controller.abort(new Error('Post search request timed out'));
  }, timeoutMs);
  try {
    return await withPostSearchAbort(operation(controller.signal), controller.signal);
  } finally {
    clearTimeout(timeout);
    externalSignal?.removeEventListener('abort', abortFromExternal);
  }
}

export async function withPostSearchTimeout<T>(
  operation: Promise<T>,
  timeoutMs: number,
  signal: AbortSignal | null = null,
): Promise<T> {
  throwIfPostSearchAborted(signal);
  let timeout: ReturnType<typeof setTimeout> | undefined;
  const expired = new Promise<never>((_resolve, reject) => {
    timeout = setTimeout(() => reject(new Error('Post search request timed out')), timeoutMs);
  });
  try {
    return await withPostSearchAbort(Promise.race([operation, expired]), signal);
  } finally {
    if (timeout !== undefined) {
      clearTimeout(timeout);
    }
  }
}
