import type { AppError, ReportAppError } from './appError';
import { getNoteEngagementTargetId } from './noteEngagement';
import { rankedFeedCardKeys } from './repostPresentation';
import { getForYouInteractionTargetEventId } from './forYouFeed';
import type { CID } from '@hashtree/core';
import { hasMoreHomeFeedContinuation, mergeUniqueFeedNotes, retainHomeFeedOrder, uniqueFeedNotesInOrder } from './homeFeedPagination';
import { HOME_FEED_SNAPSHOT_MAX_EVENTS } from './homeFeedSnapshotCache';
import { canReadHomeFeedFromRelays, isRecentHomeFeedPost } from './homeFeedReads';
import { DEFAULT_SUGGESTED_FOLLOWS_PUBKEY } from './config';
import type { ProfileRecord, RawEvent } from './nostr';
import { mergeProfileMaps } from './profileRecords';
import {
  getFeedProfilePubkeys,
  loadProfilesForPubkeys,
  streamForYouFeed,
  streamLatestFeed,
  type FeedSnapshot,
  getRootNhash,
} from './nostrIndex';

type FeedHydratorDeps = {
  getFeed: () => FeedSnapshot | null;
  getFeedRequiresRefresh?: () => boolean;
  setFeedRequiresRefresh?: (requiresRefresh: boolean) => void;
  getHomeFeedFetchLimit: () => number;
  getHomeFeedVisibleLimit: () => number;
  getDisplayedHomeNotes?: () => RawEvent[];
  isHomeFeedScrolled?: () => boolean;
  isForYouOnline?: () => boolean;
  getHomeFeedRequestId: () => number;
  getLoadToken: () => number;
  getRouteKind: () => string;
  getViewerFollows: () => ReadonlySet<string>;
  getViewerMutedPubkeys?: () => ReadonlySet<string>;
  getSeenHomeEventIds?: () => ReadonlySet<string>;
  getForYouOverlayPosts?: (authors: string[], limit: number) => RawEvent[];
  getForYouOverlayInteractions: (authors: string[], limit: number) => RawEvent[];
  getForYouOverlayEventById: (eventId: string) => RawEvent | null;
  getCachedProfiles: (pubkeys: string[]) => Map<string, ProfileRecord>;
  applyHomeFeedSnapshot: (nextFeed: FeedSnapshot, viewerPubkey: string, cacheNotes?: RawEvent[]) => void;
  hydrateNoteEngagements: (
    engagementRoots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  setFeed: (nextFeed: FeedSnapshot) => void;
  setLoading: (nextLoading: boolean) => void;
  reportError: ReportAppError;
  setPageError: (message: AppError) => void;
  incrementHomeFeedRequestId: () => number;
  resumeInitialHomeFeed?: (root: CID, missingCount: number, token: number) => Promise<void>;
  streamForYouFeed?: typeof streamForYouFeed;
  streamLatestFeed?: typeof streamLatestFeed;
};

// Coalesce independent sources only on a cold, connected visit. The first
// useful batch starts this deadline and no relay response can extend it.
const FOR_YOU_INITIAL_RANK_WINDOW_MS = 300;

export function createFeedHydrators(deps: FeedHydratorDeps) {
  const streamForYou = deps.streamForYouFeed ?? streamForYouFeed;
  // For You feeds ranked during this page session. A snapshot restored from
  // storage is only a fast preview and is ranked again on the first visit.
  const rankedForYou = new Set<string>();
  const streamLatest = deps.streamLatestFeed ?? streamLatestFeed;
  function fillsStaleFeed(displayed: FeedSnapshot, snapshot: FeedSnapshot): boolean {
    return !deps.isHomeFeedScrolled?.()
      && snapshot.notes.some(note => isRecentHomeFeedPost(note))
      && !displayed.notes.some(note => isRecentHomeFeedPost(note));
  }

  function retainVisibleNotes(snapshot: FeedSnapshot, preserve = false): FeedSnapshot {
    const displayed = deps.getFeed();
    if (!displayed || (!preserve && !deps.isHomeFeedScrolled?.())
      || displayed.rootNhash !== snapshot.rootNhash
      || displayed.feedOwnerPubkey !== snapshot.feedOwnerPubkey
      || fillsStaleFeed(displayed, snapshot)) {
      return snapshot;
    }
    const retained = (deps.getDisplayedHomeNotes?.() ?? displayed.notes)
      .slice(0, deps.getHomeFeedVisibleLimit());
    if (!retained.length) { return snapshot; }
    const displayOrder = retained.map(event => event.id);
    // A fuller index window does not delete posts that have already painted.
    // Eligibility, mutes, deletions and superseded versions are still applied
    // by the live projection before it restores this presentation order.
    return {
      ...snapshot, displayOrder,
      notes: retainHomeFeedOrder([...snapshot.notes, ...retained], displayOrder, 'latest'),
    };
  }

  async function resumeShortInitialPage(root: CID, token: number, requestId: number): Promise<void> {
    const feed = deps.getFeed();
    const missingCount = deps.getHomeFeedVisibleLimit() - (feed?.notes.length ?? 0);
    if (feed && missingCount > 0
      && hasMoreHomeFeedContinuation(feed.continuation ?? null)
      && token === deps.getLoadToken() && requestId === deps.getHomeFeedRequestId()
      && deps.getRouteKind() === 'home') {
      await deps.resumeInitialHomeFeed?.(root, missingCount, token);
    }
  }

  return {
    async hydratePopularFeed(root: CID, token: number): Promise<void> {
      const request = deps.incrementHomeFeedRequestId();
      const { loadGuestPopularFeed } = await import('./popularFeed');
      const requestedProfiles = new Set<string>();
      const apply = (next: FeedSnapshot) => {
        if (token !== deps.getLoadToken() || request !== deps.getHomeFeedRequestId()) { return; }
        const previous = deps.getFeed();
        const previousNotes = previous?.feedOwnerPubkey === 'popular' ? previous.notes : [];
        if (next.notes.length || !previousNotes.length) {
          const visibleLimit = deps.getHomeFeedVisibleLimit();
          const previousIds = new Set(previousNotes.map(note => note.id));
          const painted = deps.getDisplayedHomeNotes?.().filter(note => previousIds.has(note.id));
          const retained = painted?.length ? painted : previousNotes.slice(0, visibleLimit);
          // Keep the reading order. Fill the unpainted tail with the latest
          // ranking and cache that ranking separately for the next visit.
          const notes = uniqueFeedNotesInOrder([...retained, ...next.notes, ...previousNotes])
            .slice(0, visibleLimit + HOME_FEED_SNAPSHOT_MAX_EVENTS);
          deps.applyHomeFeedSnapshot({ ...next, notes }, '', next.notes);
          const profileNotes = notes.filter(note => {
            if (requestedProfiles.has(note.pubkey)) { return false; }
            requestedProfiles.add(note.pubkey);
            return true;
          });
          if (profileNotes.length) {
            void this.hydrateFeedProfiles(root, '', { ...next, notes: profileNotes }, token);
          }
        }
        deps.setLoading(false);
      };
      apply(await loadGuestPopularFeed(root, apply));
    },

    async hydrateFeedProfiles(
      currentRoot: CID,
      viewerPubkey: string,
      snapshot: FeedSnapshot,
      token: number,
    ): Promise<void> {
      const currentFeed = deps.getFeed();
      if (!currentFeed) {
        return;
      }

      const allPubkeys = getFeedProfilePubkeys(viewerPubkey, snapshot.feedOwnerPubkey, snapshot.notes);
      const missingPubkeys = allPubkeys.filter((pubkey) => !currentFeed.profiles.has(pubkey));
      if (missingPubkeys.length === 0) {
        return;
      }

      let deliveredProfiles = false;
      const applyHydratedProfiles = (hydratedProfiles: Map<string, ProfileRecord>): void => {
        if (hydratedProfiles.size === 0) {
          return;
        }
        deliveredProfiles = true;
        if (token !== deps.getLoadToken() || deps.getRouteKind() !== 'home' || !deps.getFeed()) {
          return;
        }

        const activeFeed = deps.getFeed() as FeedSnapshot;
        deps.setFeed({
          ...activeFeed,
          profiles: mergeProfileMaps(activeFeed.profiles, hydratedProfiles),
        });
        deps.mergeCachedProfiles(hydratedProfiles);
      };

      try {
        const hydratedProfiles = await loadProfilesForPubkeys(currentRoot, missingPubkeys, {
          onProfiles: applyHydratedProfiles,
        });
        if (!deliveredProfiles) {
          applyHydratedProfiles(hydratedProfiles);
        }
      } catch (error) {
        console.warn('Failed to hydrate feed profiles', error);
      }
    },

    async hydrateHomeFeedProgressively(
      currentRoot: CID,
      feedOwnerPubkey: string,
      viewerPubkey: string,
      token: number,
      preferStarterFeed: boolean,
      favoriteAuthors?: string[],
    ): Promise<void> {
      const requestId = deps.incrementHomeFeedRequestId();
      const isCurrentRequest = (): boolean => token === deps.getLoadToken()
        && requestId === deps.getHomeFeedRequestId() && deps.getRouteKind() === 'home';
      let latestFeed: FeedSnapshot | null = null;
      let firstPaintedFeed: FeedSnapshot | null = null;
      let lastPaintedFeed: FeedSnapshot | null = null;
      let lastPaintedNoteCount = 0;
      let retainedReplacementFeed: FeedSnapshot | null = null;
      let streamFailed = false;
      const engagementNoteIds = new Set<string>();

      const hydrateNewEngagements = (snapshot: FeedSnapshot): void => {
        const noteIds = snapshot.notes
          .slice(0, deps.getHomeFeedVisibleLimit())
          .map(getNoteEngagementTargetId)
          .filter((noteId) => !engagementNoteIds.has(noteId));
        if (noteIds.length === 0) {
          return;
        }
        const merge = engagementNoteIds.size > 0;
        for (const noteId of noteIds) {
          engagementNoteIds.add(noteId);
        }
        void deps.hydrateNoteEngagements(currentRoot, noteIds, token, { merge });
      };
      const paintSnapshot = (snapshot: FeedSnapshot): void => {
        const preserve = Boolean(lastPaintedFeed || preserveDisplayedFeedDuringStream);
        lastPaintedFeed = snapshot;
        lastPaintedNoteCount = snapshot.notes.length;
        if (favoriteAuthors !== undefined) {
          snapshot = retainVisibleNotes(snapshot, preserve);
        } else {
          const displayed = deps.getFeed();
          if (displayed?.rootNhash === snapshot.rootNhash) {
            const authors = new Set(snapshot.continuation?.authors ?? [...snapshot.follows, snapshot.feedOwnerPubkey]);
            const retained = displayed.notes.filter(note => authors.has(note.pubkey));
            snapshot = {
              ...snapshot,
              notes: mergeUniqueFeedNotes(snapshot.notes, retained).slice(0, deps.getHomeFeedFetchLimit()),
            };
          }
        }
        deps.applyHomeFeedSnapshot(snapshot, viewerPubkey);
        deps.setLoading(false);
        if (snapshot.notes.length > 0) {
          hydrateNewEngagements(snapshot);
          void this.hydrateFeedProfiles(currentRoot, viewerPubkey, snapshot, token);
        }
      };
      const displayedFeed = deps.getFeed();
      const displayedFeedMatchesRequest = Boolean(
        displayedFeed
        && displayedFeed.rootNhash === getRootNhash(currentRoot)
        && (
          displayedFeed.feedOwnerPubkey === feedOwnerPubkey
          || (
            feedOwnerPubkey === viewerPubkey
            && displayedFeed.usedSuggestedFeed
            && deps.getViewerFollows().size === 0
          )
        ),
      );
      const preserveDisplayedFeedDuringStream = Boolean(
        displayedFeedMatchesRequest
        && displayedFeed?.notes.length
      );
      const retainedReplacementMinimum = preserveDisplayedFeedDuringStream
        ? Math.min(displayedFeed?.notes.length ?? 0, deps.getHomeFeedFetchLimit())
        : 0;
      if (displayedFeed?.notes.length) {
        hydrateNewEngagements(displayedFeed);
      }
      if (
        displayedFeed?.feedOwnerPubkey === feedOwnerPubkey
        && displayedFeed.rootNhash === getRootNhash(currentRoot)
        && displayedFeed.notes.length > 0
        && !deps.getFeedRequiresRefresh?.()
        && (!canReadHomeFeedFromRelays() || displayedFeed.notes.some(note => isRecentHomeFeedPost(note)))
      ) {
        deps.setLoading(false);
        void this.hydrateFeedProfiles(currentRoot, viewerPubkey, displayedFeed, token);
        return;
      }
      try {
        for await (const nextFeed of streamLatest(currentRoot, favoriteAuthors !== undefined ? viewerPubkey : feedOwnerPubkey, deps.getHomeFeedFetchLimit(), {
          favoriteAuthors,
          fallbackFeedOwnerPubkey:
            feedOwnerPubkey === viewerPubkey ? DEFAULT_SUGGESTED_FOLLOWS_PUBKEY : null,
          includeProfiles: false,
          minimumNotes: deps.getHomeFeedVisibleLimit(),
          includeReplies: true,
          knownViewerFollows:
            feedOwnerPubkey === viewerPubkey ? [...deps.getViewerFollows()] : undefined,
          preferStarterFeed: feedOwnerPubkey === viewerPubkey ? preferStarterFeed : false,
        })) {
          if (!isCurrentRequest()) {
            return;
          }
          latestFeed = nextFeed;
          if (preserveDisplayedFeedDuringStream && displayedFeed && favoriteAuthors === undefined
            && nextFeed.rootNhash === displayedFeed.rootNhash
            && nextFeed.notes.some(note => note.created_at > (displayedFeed.notes[0]?.created_at ?? 0))) {
            // Merge a verified recent delta into the retained window promptly,
            // even when it is too small to replace the cached page on its own.
            retainedReplacementFeed = nextFeed;
            paintSnapshot(nextFeed);
          } else if (preserveDisplayedFeedDuringStream && displayedFeed && favoriteAuthors !== undefined
            && fillsStaleFeed(displayedFeed, nextFeed)) {
            retainedReplacementFeed = {
              ...nextFeed,
              notes: mergeUniqueFeedNotes(nextFeed.notes, displayedFeed.notes).slice(0, deps.getHomeFeedFetchLimit()),
            };
          } else if (preserveDisplayedFeedDuringStream && nextFeed.notes.length >= retainedReplacementMinimum) {
            retainedReplacementFeed = nextFeed;
          }
          if (!firstPaintedFeed && nextFeed.notes.length > 0) {
            firstPaintedFeed = nextFeed;
            // A partial stream is useful for a cold route, but replacing a
            // retained feed with its first one-row chunk collapses the page
            // and destroys the Back-navigation viewport. Keep the verified
            // snapshot until the stream supplies a full retained window.
            if (!preserveDisplayedFeedDuringStream) {
              paintSnapshot(nextFeed);
            }
          } else if (!preserveDisplayedFeedDuringStream
            && (nextFeed.notes.length > lastPaintedNoteCount || (
              favoriteAuthors === undefined && nextFeed.notes.length === lastPaintedNoteCount
              && nextFeed.notes.some((note, index) => lastPaintedFeed?.notes[index]?.id !== note.id)
            ))) {
            paintSnapshot(nextFeed);
          }
        }
      } catch (error) {
        streamFailed = true;
        console.warn('Failed to progressively load home feed', error);
        if (
          !latestFeed
          && isCurrentRequest()
          && !(deps.getFeed()?.notes.length ?? 0)
        ) {
          deps.setPageError(deps.reportError("Couldn't load the feed right now.", error));
        }
      }

      if (!isCurrentRequest() || !latestFeed) {
        return;
      }
      if (preserveDisplayedFeedDuringStream) {
        if (retainedReplacementFeed && retainedReplacementFeed !== lastPaintedFeed) {
          paintSnapshot(retainedReplacementFeed);
        } else {
          // A bounded index stream can time out and return normally with only
          // a partial window. Keep the already-verified retained projection;
          // a short result is not evidence that its remaining cards vanished.
          deps.setLoading(false);
        }
        if (!streamFailed) { await resumeShortInitialPage(currentRoot, token, requestId); }
        return;
      }

      if (!firstPaintedFeed) {
        paintSnapshot(latestFeed);
      } else if (latestFeed !== lastPaintedFeed) {
        // Fill the remaining window without replacing the first paint.
        paintSnapshot(latestFeed);
      }
      if (!streamFailed) { await resumeShortInitialPage(currentRoot, token, requestId); }
    },

    async hydrateForYouFeedProgressively(
      currentRoot: CID,
      viewerPubkey: string,
      token: number,
    ): Promise<void> {
      const requestId = deps.incrementHomeFeedRequestId();
      let latestFeed: FeedSnapshot | null = null;
      let lastPainted: FeedSnapshot | null = null;
      const requestedProfileAuthors = new Set<string>();
      let initialRankTimer: ReturnType<typeof setTimeout> | undefined;
      const isCurrent = () => token === deps.getLoadToken() && requestId === deps.getHomeFeedRequestId()
        && deps.getRouteKind() === 'home';
      const online = deps.isForYouOnline?.() ?? (typeof window !== 'undefined' && navigator.onLine);
      const engagementNoteIds = new Map<string, string>();
      const seenEventIds = deps.getSeenHomeEventIds?.() ?? new Set<string>();

      const excludeSeen = (snapshot: FeedSnapshot): FeedSnapshot => ({
        ...snapshot,
        notes: snapshot.notes.filter((event) => !seenEventIds.has(event.id)),
      });

      const hydrateNewEngagements = (snapshot: FeedSnapshot): void => {
        const roots = snapshot.continuation?.roots.map(({ root }) => root) ?? [currentRoot];
        const rootKey = roots.map(getRootNhash).sort().join(',');
        const noteIds = snapshot.notes
          .slice(0, deps.getHomeFeedFetchLimit())
          .map(getNoteEngagementTargetId)
          .filter((noteId) => engagementNoteIds.get(noteId) !== rootKey);
        if (noteIds.length === 0) {
          return;
        }
        const merge = engagementNoteIds.size > 0;
        for (const noteId of noteIds) {
          engagementNoteIds.set(noteId, rootKey);
        }
        void deps.hydrateNoteEngagements(roots.length === 1 ? roots[0]! : roots, noteIds, token, { merge });
      };
      const paintSnapshot = (snapshot: FeedSnapshot): void => {
        clearTimeout(initialRankTimer);
        if (!isCurrent()) { return; }
        lastPainted = snapshot;
        const displayed = deps.getFeed();
        // An empty owner denotes a verified Latest preview for this For You
        // visit. A rolling archive root can change without changing the reader.
        const previous = displayed && ['', 'for-you'].includes(displayed.feedOwnerPubkey) ? displayed.notes : [];
        const previousIds = new Set(previous.map(note => note.id));
        const painted = (deps.getDisplayedHomeNotes?.() ?? previous)
          .slice(0, deps.getHomeFeedVisibleLimit()).filter(note => previousIds.has(note.id) && !seenEventIds.has(note.id));
        // If a visible repost resolves to its verified original, update that
        // card in place. Distinct wrappers stay distinct unless superseded.
        const originals = new Map(snapshot.notes.filter(note => note.kind !== 6).map(note => [note.id, note]));
        const resolved = (note: RawEvent) => note.kind === 6 ? originals.get(getNoteEngagementTargetId(note)) ?? note : note;
        const cardKeys = painted.some(note => note.kind === 6) ? rankedFeedCardKeys(painted) : null;
        const prefix = painted.map(note => {
          const primary = cardKeys?.get(note.id) === `post:${getNoteEngagementTargetId(note)}`;
          return primary ? resolved(note) : note;
        });
        const notes = uniqueFeedNotesInOrder([...prefix, ...snapshot.notes, ...previous.map(resolved)])
          .slice(0, deps.getHomeFeedVisibleLimit() + HOME_FEED_SNAPSHOT_MAX_EVENTS);
        const feed = { ...snapshot, notes, displayOrder: prefix.map(note => note.id) };
        // A short partial read must not erase the rest of the verified
        // offline page before the fuller ranking can arrive.
        const cacheNotes = snapshot.notes.length < Math.min(previous.length, deps.getHomeFeedVisibleLimit())
          ? uniqueFeedNotesInOrder([...snapshot.notes, ...previous.map(resolved)])
          : snapshot.notes;
        deps.applyHomeFeedSnapshot(feed, viewerPubkey, cacheNotes);
        deps.setFeedRequiresRefresh?.(true);
        deps.setLoading(false);
        if (notes.length) {
          hydrateNewEngagements(feed);
          const needProfiles = notes.filter(note => !requestedProfileAuthors.has(note.pubkey));
          for (const note of needProfiles) { requestedProfileAuthors.add(note.pubkey); }
          if (needProfiles.length) {
            void this.hydrateFeedProfiles(currentRoot, viewerPubkey, { ...feed, notes: needProfiles }, token);
          }
        }
      };
      const displayedFeed = deps.getFeed();
      const filteredDisplayedFeed = displayedFeed?.feedOwnerPubkey === 'for-you'
        ? excludeSeen(displayedFeed)
        : displayedFeed;
      const removedDisplayedSeenEvents = Boolean(
        displayedFeed
        && filteredDisplayedFeed
        && displayedFeed.notes.length !== filteredDisplayedFeed.notes.length,
      );
      if (removedDisplayedSeenEvents && filteredDisplayedFeed) {
        if (filteredDisplayedFeed.notes.length > 0) {
          deps.applyHomeFeedSnapshot(filteredDisplayedFeed, viewerPubkey);
        } else {
          deps.setFeed(filteredDisplayedFeed);
          deps.setLoading(true);
        }
      }
      if (filteredDisplayedFeed?.notes.length) {
        hydrateNewEngagements(filteredDisplayedFeed);
      }
      const rankedKey = `${viewerPubkey}:${getRootNhash(currentRoot)}`;
      const refreshingRestored = Boolean(
        filteredDisplayedFeed?.feedOwnerPubkey === 'for-you'
        && filteredDisplayedFeed.notes.length > 0
        && !rankedForYou.has(rankedKey),
      );
      const restoredSnapshotNeedsRefill = Boolean(
        filteredDisplayedFeed?.feedOwnerPubkey === 'for-you'
        && filteredDisplayedFeed.notes.length > 0
        && !filteredDisplayedFeed.continuation
        && seenEventIds.size > 0,
      );
      if (
        filteredDisplayedFeed?.feedOwnerPubkey === 'for-you'
        && filteredDisplayedFeed.rootNhash === getRootNhash(currentRoot)
        && filteredDisplayedFeed.notes.length > 0
        // Like Latest, a restored page with nothing from the last day is
        // refreshed; its cards stay in place while fresher posts are ranked.
        && filteredDisplayedFeed.notes.some(note => isRecentHomeFeedPost(note))
        && !removedDisplayedSeenEvents
        && !restoredSnapshotNeedsRefill
        && !refreshingRestored
        && !deps.getFeedRequiresRefresh?.()
      ) {
        deps.setLoading(false);
        void this.hydrateFeedProfiles(currentRoot, viewerPubkey, filteredDisplayedFeed, token);
        return;
      }

      try {
        for await (const nextFeed of streamForYou(currentRoot, viewerPubkey, deps.getHomeFeedFetchLimit(), {
          includeProfiles: false,
          includeReplies: false,
          excludeEventIds: seenEventIds,
          knownViewerFollows: [...deps.getViewerFollows()],
          mutedPubkeys: deps.getViewerMutedPubkeys?.(),
          getRecentOverlayPostsByAuthors: (authors, limit) => mergeUniqueFeedNotes(
            deps.getFeed()?.feedOwnerPubkey === 'for-you'
              ? deps.getFeed()!.notes.filter(event => authors.includes(event.pubkey)) : [],
            deps.getForYouOverlayPosts?.(authors, limit) ?? [],
          ).slice(0, limit),
          getRecentOverlayInteractionsByAuthors: deps.getForYouOverlayInteractions,
          getOverlayEventById: deps.getForYouOverlayEventById,
        })) {
          if (!isCurrent()) { return; }
          if (!nextFeed.notes.length) { latestFeed ??= nextFeed; continue; }
          latestFeed = excludeSeen(nextFeed);
          if (!latestFeed.notes.length) { continue; }
          const endorsed = new Set(latestFeed.rankingEngagementEvents?.map(getForYouInteractionTargetEventId));
          const hasRecommendation = endorsed.size > 0 && latestFeed.notes.some(note => endorsed.has(note.id));
          if (!lastPainted && !deps.getFeed()?.notes.length && online && !hasRecommendation) {
            initialRankTimer ??= setTimeout(() => {
              if (latestFeed?.notes.length) { paintSnapshot(latestFeed); }
            }, FOR_YOU_INITIAL_RANK_WINDOW_MS);
          } else {
            paintSnapshot(latestFeed);
          }
        }
      } catch (error) {
        if (!lastPainted && latestFeed?.notes.length && isCurrent()) { paintSnapshot(latestFeed); }
        console.warn('Failed to progressively load for-you feed', error);
        if (token !== deps.getLoadToken() || requestId !== deps.getHomeFeedRequestId()) {
          return;
        }
        // A provisional paint clears this flag. A failed refresh must remain
        // retryable and must not replace offline posts with an empty partial.
        deps.setFeedRequiresRefresh?.(true);
        if (!latestFeed && !(deps.getFeed()?.notes.length ?? 0)) {
          deps.setPageError(deps.reportError("Couldn't load the feed right now.", error));
        }
        return;
      } finally {
        clearTimeout(initialRankTimer);
      }

      if (!isCurrent() || !latestFeed) { return; }
      if (latestFeed.notes.length) {
        if (latestFeed !== lastPainted) { paintSnapshot(latestFeed); }
        rankedForYou.add(rankedKey);
        deps.setFeedRequiresRefresh?.(false);
      } else if (!deps.getFeed()?.notes.length) {
        paintSnapshot(latestFeed);
      } else {
        deps.setLoading(false);
        deps.setFeedRequiresRefresh?.(true);
      }
      if (!deps.isHomeFeedScrolled?.()) {
        await resumeShortInitialPage(currentRoot, token, requestId);
      }
    },
  };
}
