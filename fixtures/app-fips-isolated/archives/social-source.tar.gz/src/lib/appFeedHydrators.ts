import { getNoteEngagementTargetId } from './noteEngagement';
import type { CID } from '@hashtree/core';
import { hasMoreHomeFeedContinuation, mergeUniqueFeedNotes, retainHomeFeedOrder } from './homeFeedPagination';
import { DEFAULT_SUGGESTED_FOLLOWS_PUBKEY } from './config';
import type { ProfileRecord, RawEvent } from './nostr';
import { mergeProfileMaps } from './profileRecords';
import {
  getFeedProfilePubkeys,
  loadProfilesForPubkeys,
  streamForYouFeed,
  streamLatestFeed,
  type FeedSnapshot,
  getRootNhash,
} from './nostrIndex';

type FeedHydratorDeps = {
  getFeed: () => FeedSnapshot | null;
  getFeedRequiresRefresh?: () => boolean;
  setFeedRequiresRefresh?: (requiresRefresh: boolean) => void;
  getHomeFeedFetchLimit: () => number;
  getHomeFeedVisibleLimit: () => number;
  getDisplayedHomeNotes?: () => RawEvent[];
  isHomeFeedScrolled?: () => boolean;
  getHomeFeedRequestId: () => number;
  getLoadToken: () => number;
  getRouteKind: () => string;
  getViewerFollows: () => ReadonlySet<string>;
  getSeenHomeEventIds?: () => ReadonlySet<string>;
  getForYouOverlayPosts?: (authors: string[], limit: number) => RawEvent[];
  getForYouOverlayInteractions: (authors: string[], limit: number) => RawEvent[];
  getForYouOverlayEventById: (eventId: string) => RawEvent | null;
  getCachedProfiles: (pubkeys: string[]) => Map<string, ProfileRecord>;
  applyHomeFeedSnapshot: (nextFeed: FeedSnapshot, viewerPubkey: string) => void;
  hydrateNoteEngagements: (
    engagementRoots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  setFeed: (nextFeed: FeedSnapshot) => void;
  setLoading: (nextLoading: boolean) => void;
  reportError: (fallbackMessage: string, error: unknown) => string;
  setPageError: (message: string) => void;
  incrementHomeFeedRequestId: () => number;
  resumeInitialHomeFeed?: (root: CID, missingCount: number, token: number) => Promise<void>;
  streamForYouFeed?: typeof streamForYouFeed;
  streamLatestFeed?: typeof streamLatestFeed;
};

export function createFeedHydrators(deps: FeedHydratorDeps) {
  const streamForYou = deps.streamForYouFeed ?? streamForYouFeed;
  const streamLatest = deps.streamLatestFeed ?? streamLatestFeed;
  function retainVisibleNotes(snapshot: FeedSnapshot, preserve = false): FeedSnapshot {
    const displayed = deps.getFeed();
    const forYouPreview = displayed?.feedOwnerPubkey === '' && snapshot.feedOwnerPubkey === 'for-you';
    if (!displayed || (!preserve && !deps.isHomeFeedScrolled?.())
      || displayed.rootNhash !== snapshot.rootNhash
      || (displayed.feedOwnerPubkey !== snapshot.feedOwnerPubkey && !forYouPreview)) {
      return snapshot;
    }
    const retained = (deps.getDisplayedHomeNotes?.() ?? displayed.notes)
      .slice(0, deps.getHomeFeedVisibleLimit());
    if (!retained.length) { return snapshot; }
    const displayOrder = retained.map(event => event.id);
    // A fuller index window does not delete posts that have already painted.
    // Eligibility, mutes, deletions and superseded versions are still applied
    // by the live projection before it restores this presentation order.
    return {
      ...snapshot, displayOrder,
      notes: retainHomeFeedOrder(mergeUniqueFeedNotes(snapshot.notes, retained), displayOrder,
        snapshot.feedOwnerPubkey === 'for-you' ? 'for-you' : 'latest'),
    };
  }

  return {
    async hydrateFeedProfiles(
      currentRoot: CID,
      viewerPubkey: string,
      snapshot: FeedSnapshot,
      token: number,
    ): Promise<void> {
      const currentFeed = deps.getFeed();
      if (!currentFeed) {
        return;
      }

      const allPubkeys = getFeedProfilePubkeys(viewerPubkey, snapshot.feedOwnerPubkey, snapshot.notes);
      const missingPubkeys = allPubkeys.filter((pubkey) => !currentFeed.profiles.has(pubkey));
      if (missingPubkeys.length === 0) {
        return;
      }

      let deliveredProfiles = false;
      const applyHydratedProfiles = (hydratedProfiles: Map<string, ProfileRecord>): void => {
        if (hydratedProfiles.size === 0) {
          return;
        }
        deliveredProfiles = true;
        if (token !== deps.getLoadToken() || deps.getRouteKind() !== 'home' || !deps.getFeed()) {
          return;
        }

        const activeFeed = deps.getFeed() as FeedSnapshot;
        deps.setFeed({
          ...activeFeed,
          profiles: mergeProfileMaps(activeFeed.profiles, hydratedProfiles),
        });
        deps.mergeCachedProfiles(hydratedProfiles);
      };

      try {
        const hydratedProfiles = await loadProfilesForPubkeys(currentRoot, missingPubkeys, {
          onProfiles: applyHydratedProfiles,
        });
        if (!deliveredProfiles) {
          applyHydratedProfiles(hydratedProfiles);
        }
      } catch (error) {
        console.warn('Failed to hydrate feed profiles', error);
      }
    },

    async hydrateHomeFeedProgressively(
      currentRoot: CID,
      feedOwnerPubkey: string,
      viewerPubkey: string,
      token: number,
      preferStarterFeed: boolean,
      favoriteAuthors?: string[],
    ): Promise<void> {
      const requestId = deps.incrementHomeFeedRequestId();
      const isCurrentRequest = (): boolean => token === deps.getLoadToken()
        && requestId === deps.getHomeFeedRequestId() && deps.getRouteKind() === 'home';
      let latestFeed: FeedSnapshot | null = null;
      let firstPaintedFeed: FeedSnapshot | null = null;
      let lastPaintedFeed: FeedSnapshot | null = null;
      let lastPaintedNoteCount = 0;
      let retainedReplacementFeed: FeedSnapshot | null = null;
      let streamFailed = false;
      const engagementNoteIds = new Set<string>();

      const hydrateNewEngagements = (snapshot: FeedSnapshot): void => {
        const noteIds = snapshot.notes
          .slice(0, deps.getHomeFeedVisibleLimit())
          .map(getNoteEngagementTargetId)
          .filter((noteId) => !engagementNoteIds.has(noteId));
        if (noteIds.length === 0) {
          return;
        }
        const merge = engagementNoteIds.size > 0;
        for (const noteId of noteIds) {
          engagementNoteIds.add(noteId);
        }
        void deps.hydrateNoteEngagements(currentRoot, noteIds, token, { merge });
      };
      const paintSnapshot = (snapshot: FeedSnapshot): void => {
        const preserve = Boolean(lastPaintedFeed || preserveDisplayedFeedDuringStream);
        lastPaintedFeed = snapshot;
        lastPaintedNoteCount = snapshot.notes.length;
        snapshot = retainVisibleNotes(snapshot, preserve);
        deps.applyHomeFeedSnapshot(snapshot, viewerPubkey);
        deps.setLoading(false);
        if (snapshot.notes.length > 0) {
          hydrateNewEngagements(snapshot);
          void this.hydrateFeedProfiles(currentRoot, viewerPubkey, snapshot, token);
        }
      };
      const displayedFeed = deps.getFeed();
      const displayedFeedMatchesRequest = Boolean(
        displayedFeed
        && displayedFeed.rootNhash === getRootNhash(currentRoot)
        && (
          displayedFeed.feedOwnerPubkey === feedOwnerPubkey
          || (
            feedOwnerPubkey === viewerPubkey
            && displayedFeed.usedSuggestedFeed
            && deps.getViewerFollows().size === 0
          )
        ),
      );
      const preserveDisplayedFeedDuringStream = Boolean(
        displayedFeedMatchesRequest
        && displayedFeed?.notes.length
      );
      const retainedReplacementMinimum = preserveDisplayedFeedDuringStream
        ? Math.min(displayedFeed?.notes.length ?? 0, deps.getHomeFeedFetchLimit())
        : 0;
      if (displayedFeed?.notes.length) {
        hydrateNewEngagements(displayedFeed);
      }
      if (
        displayedFeed?.feedOwnerPubkey === feedOwnerPubkey
        && displayedFeed.rootNhash === getRootNhash(currentRoot)
        && displayedFeed.notes.length > 0
        && !deps.getFeedRequiresRefresh?.()
      ) {
        deps.setLoading(false);
        void this.hydrateFeedProfiles(currentRoot, viewerPubkey, displayedFeed, token);
        return;
      }
      try {
        for await (const nextFeed of streamLatest(currentRoot, favoriteAuthors !== undefined ? viewerPubkey : feedOwnerPubkey, deps.getHomeFeedFetchLimit(), {
          favoriteAuthors,
          fallbackFeedOwnerPubkey:
            feedOwnerPubkey === viewerPubkey ? DEFAULT_SUGGESTED_FOLLOWS_PUBKEY : null,
          includeProfiles: false,
          minimumNotes: deps.getHomeFeedVisibleLimit(),
          includeReplies: true,
          knownViewerFollows:
            feedOwnerPubkey === viewerPubkey ? [...deps.getViewerFollows()] : undefined,
          preferStarterFeed: feedOwnerPubkey === viewerPubkey ? preferStarterFeed : false,
        })) {
          if (!isCurrentRequest()) {
            return;
          }
          latestFeed = nextFeed;
          if (
            preserveDisplayedFeedDuringStream
            && nextFeed.notes.length >= retainedReplacementMinimum
          ) {
            retainedReplacementFeed = nextFeed;
          }
          if (!firstPaintedFeed && nextFeed.notes.length > 0) {
            firstPaintedFeed = nextFeed;
            // A partial stream is useful for a cold route, but replacing a
            // retained feed with its first one-row chunk collapses the page
            // and destroys the Back-navigation viewport. Keep the verified
            // snapshot until the stream supplies a full retained window.
            if (!preserveDisplayedFeedDuringStream) {
              paintSnapshot(nextFeed);
            }
          } else if (!preserveDisplayedFeedDuringStream
            && nextFeed.notes.length > lastPaintedNoteCount) {
            paintSnapshot(nextFeed);
          }
        }
      } catch (error) {
        streamFailed = true;
        console.warn('Failed to progressively load home feed', error);
        if (
          !latestFeed
          && isCurrentRequest()
          && !(deps.getFeed()?.notes.length ?? 0)
        ) {
          deps.setPageError(deps.reportError("Couldn't load the feed right now.", error));
        }
      }

      if (!isCurrentRequest() || !latestFeed) {
        return;
      }
      const resumeInitialPage = async (): Promise<void> => {
        const feed = deps.getFeed();
        const missingCount = deps.getHomeFeedVisibleLimit() - (feed?.notes.length ?? 0);
        if (!streamFailed && feed && missingCount > 0
          && hasMoreHomeFeedContinuation(feed.continuation ?? null)
          && token === deps.getLoadToken() && requestId === deps.getHomeFeedRequestId()
          && deps.getRouteKind() === 'home') {
          await deps.resumeInitialHomeFeed?.(currentRoot, missingCount, token);
        }
      };
      if (preserveDisplayedFeedDuringStream) {
        if (retainedReplacementFeed) {
          paintSnapshot(retainedReplacementFeed);
        } else {
          // A bounded index stream can time out and return normally with only
          // a partial window. Keep the already-verified retained projection;
          // a short result is not evidence that its remaining cards vanished.
          deps.setLoading(false);
        }
        await resumeInitialPage();
        return;
      }

      if (!firstPaintedFeed) {
        paintSnapshot(latestFeed);
      } else if (latestFeed !== lastPaintedFeed) {
        // Fill the remaining window without replacing the first paint.
        paintSnapshot(latestFeed);
      }
      await resumeInitialPage();
    },

    async hydrateForYouFeedProgressively(
      currentRoot: CID,
      viewerPubkey: string,
      token: number,
    ): Promise<void> {
      const requestId = deps.incrementHomeFeedRequestId();
      let latestFeed: FeedSnapshot | null = null;
      let firstPaintedFeed: FeedSnapshot | null = null;
      const engagementNoteIds = new Set<string>();
      const seenEventIds = deps.getSeenHomeEventIds?.() ?? new Set<string>();

      const excludeSeen = (snapshot: FeedSnapshot): FeedSnapshot => ({
        ...snapshot,
        notes: snapshot.notes.filter((event) => !seenEventIds.has(event.id)),
      });

      const hydrateNewEngagements = (snapshot: FeedSnapshot): void => {
        const noteIds = snapshot.notes
          .slice(0, deps.getHomeFeedFetchLimit())
          .map(getNoteEngagementTargetId)
          .filter((noteId) => !engagementNoteIds.has(noteId));
        if (noteIds.length === 0) {
          return;
        }
        const merge = engagementNoteIds.size > 0;
        for (const noteId of noteIds) {
          engagementNoteIds.add(noteId);
        }
        void deps.hydrateNoteEngagements(currentRoot, noteIds, token, { merge });
      };
      let hasPainted = false;
      const paintSnapshot = (snapshot: FeedSnapshot): void => {
        if (deps.isHomeFeedScrolled?.() && deps.getFeed()?.feedOwnerPubkey === 'for-you'
          && deps.getFeed()!.notes.length > 0) {
          deps.setFeedRequiresRefresh?.(true);
          return;
        }
        snapshot = retainVisibleNotes(snapshot, hasPainted || deps.getFeed()?.feedOwnerPubkey === '');
        hasPainted = true;
        deps.applyHomeFeedSnapshot(snapshot, viewerPubkey);
        deps.setLoading(false);
        if (snapshot.notes.length > 0) {
          hydrateNewEngagements(snapshot);
          void this.hydrateFeedProfiles(currentRoot, viewerPubkey, snapshot, token);
        }
      };
      const displayedFeed = deps.getFeed();
      const filteredDisplayedFeed = displayedFeed?.feedOwnerPubkey === 'for-you'
        ? excludeSeen(displayedFeed)
        : displayedFeed;
      const removedDisplayedSeenEvents = Boolean(
        displayedFeed
        && filteredDisplayedFeed
        && displayedFeed.notes.length !== filteredDisplayedFeed.notes.length,
      );
      if (removedDisplayedSeenEvents && filteredDisplayedFeed) {
        if (filteredDisplayedFeed.notes.length > 0) {
          deps.applyHomeFeedSnapshot(filteredDisplayedFeed, viewerPubkey);
        } else {
          deps.setFeed(filteredDisplayedFeed);
          deps.setLoading(true);
        }
      }
      if (filteredDisplayedFeed?.notes.length) {
        hydrateNewEngagements(filteredDisplayedFeed);
      }
      const restoredSnapshotNeedsRefill = Boolean(
        filteredDisplayedFeed?.feedOwnerPubkey === 'for-you'
        && filteredDisplayedFeed.notes.length > 0
        && !filteredDisplayedFeed.continuation
        && seenEventIds.size > 0,
      );
      if (
        filteredDisplayedFeed?.feedOwnerPubkey === 'for-you'
        && filteredDisplayedFeed.rootNhash === getRootNhash(currentRoot)
        && filteredDisplayedFeed.notes.length > 0
        && !removedDisplayedSeenEvents
        && !restoredSnapshotNeedsRefill
        && !deps.getFeedRequiresRefresh?.()
      ) {
        deps.setLoading(false);
        void this.hydrateFeedProfiles(currentRoot, viewerPubkey, filteredDisplayedFeed, token);
        return;
      }

      try {
        for await (const nextFeed of streamForYou(currentRoot, viewerPubkey, deps.getHomeFeedFetchLimit(), {
          includeProfiles: false,
          includeReplies: false,
          excludeEventIds: seenEventIds,
          knownViewerFollows: [...deps.getViewerFollows()],
          getRecentOverlayPostsByAuthors: (authors, limit) => mergeUniqueFeedNotes(
            deps.getFeed()?.feedOwnerPubkey === 'for-you'
              ? deps.getFeed()!.notes.filter(event => authors.includes(event.pubkey)) : [],
            deps.getForYouOverlayPosts?.(authors, limit) ?? [],
          ).slice(0, limit),
          getRecentOverlayInteractionsByAuthors: deps.getForYouOverlayInteractions,
          getOverlayEventById: deps.getForYouOverlayEventById,
        })) {
          if (token !== deps.getLoadToken() || requestId !== deps.getHomeFeedRequestId()) {
            return;
          }

          latestFeed = excludeSeen(nextFeed);
          if (latestFeed.notes.length > 0 && (
            !firstPaintedFeed || firstPaintedFeed.notes.length < deps.getHomeFeedVisibleLimit()
          )) {
            firstPaintedFeed = latestFeed;
            paintSnapshot(latestFeed);
          }
        }
      } catch (error) {
        console.warn('Failed to progressively load for-you feed', error);
        if (token !== deps.getLoadToken() || requestId !== deps.getHomeFeedRequestId()) {
          return;
        }
        // A provisional paint clears this flag. A failed refresh must remain
        // retryable and must not replace offline posts with an empty partial.
        deps.setFeedRequiresRefresh?.(true);
        if (!latestFeed && !(deps.getFeed()?.notes.length ?? 0)) {
          deps.setPageError(deps.reportError("Couldn't load the feed right now.", error));
        }
        return;
      }

      if (token !== deps.getLoadToken() || requestId !== deps.getHomeFeedRequestId() || !latestFeed) {
        return;
      }

      if (!firstPaintedFeed) {
        paintSnapshot(latestFeed);
      } else if (latestFeed !== firstPaintedFeed) {
        paintSnapshot(latestFeed);
      }
    },
  };
}
