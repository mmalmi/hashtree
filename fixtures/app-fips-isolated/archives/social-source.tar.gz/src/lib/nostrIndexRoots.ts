import { nhashEncode, type CID } from '@hashtree/core';
import {
  getConfiguredEventIndexRef,
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
} from './config';
import { pubkeyToNpub } from './nostr';
import { NostrEventIndexReader } from './nostrIndexReader';
import {
  createPersonalEventIndexReadStore,
  getLocalPersonalEventIndexRoot,
  isLocalPersonalEventIndexRoot,
} from './personalEventIndexBrowser';
import {
  resolveTreeTargetRoot,
  getCachedPublishedRoot,
  toImmutableTreeTargetRef,
  watchTreeTargetRoot,
} from './treeRef';
import { resolveImmutableRoot } from './workerBlockStore';

const personalIndexRootPromises = new Map<string, Promise<CID | null>>();
const personalIndexRoots = new Map<string, CID>();
const readersByRootKey = new Map<string, NostrEventIndexReader>();

function rootKey(root: CID): string {
  return `${Array.from(root.hash).join(',')}:${Array.from(root.key ?? []).join(',')}`;
}

function resolveImmutableSubpath(root: CID, path: string): Promise<CID | null> {
  return resolveImmutableRoot(toImmutableTreeTargetRef(root), path);
}

export async function resolveConfiguredEventIndexRoot(): Promise<CID | null> {
  return await resolveTreeTargetRoot(getConfiguredEventIndexRef(), {
    resolveImmutablePath: resolveImmutableSubpath,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
  });
}

export async function watchConfiguredEventIndexRoot(
  listener: (root: CID | null) => void,
): Promise<() => Promise<void>> {
  return await watchTreeTargetRoot(getConfiguredEventIndexRef(), listener, {
    resolveImmutablePath: resolveImmutableSubpath,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
  });
}

export function getRootNhash(root: CID): string {
  return nhashEncode(root);
}

export function getReaderForRoot(root: CID): NostrEventIndexReader {
  const key = rootKey(root);
  const cachedReader = readersByRootKey.get(key);
  if (cachedReader) {
    return cachedReader;
  }

  const nextReader = isLocalPersonalEventIndexRoot(root)
    ? new NostrEventIndexReader(root, createPersonalEventIndexReadStore())
    : new NostrEventIndexReader(root);
  readersByRootKey.set(key, nextReader);
  return nextReader;
}

async function knownProfileEventIndexRoot(normalizedPubkey: string): Promise<CID | null> {
  const localRoot = await getLocalPersonalEventIndexRoot(normalizedPubkey);
  if (localRoot) {
    personalIndexRoots.set(normalizedPubkey, localRoot);
    return localRoot;
  }
  return personalIndexRoots.get(normalizedPubkey) ?? null;
}

export async function getCachedProfileEventIndexRoot(pubkey: string): Promise<CID | null> {
  const key = pubkey.trim().toLowerCase();
  return (await knownProfileEventIndexRoot(key)) ?? await getCachedPublishedRoot(pubkeyToNpub(key), 'nostr-event-index');
}

export async function resolveProfileEventIndexRoot(pubkey: string): Promise<CID | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  const known = await knownProfileEventIndexRoot(normalizedPubkey);
  if (known) { return known; }
  const cached = personalIndexRootPromises.get(normalizedPubkey);
  if (cached) {
    return await cached;
  }

  const promise = (async () => {
    try {
      return await resolveTreeTargetRoot(`${pubkeyToNpub(normalizedPubkey)}/nostr-event-index`, {
        resolveImmutablePath: resolveImmutableSubpath,
        timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
        settleMs: ROOT_RESOLVE_SETTLE_MS,
      });
    } catch (error) {
      console.warn('Failed to resolve personal nostr event index', error);
      return null;
    }
  })();

  personalIndexRootPromises.set(normalizedPubkey, promise);
  try {
    const root = await promise;
    if (root) {
      personalIndexRoots.set(normalizedPubkey, root);
    }
    return root;
  } finally {
    personalIndexRootPromises.delete(normalizedPubkey);
  }
}
