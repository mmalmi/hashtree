import { nhashEncode, type CID } from '@hashtree/core';
import {
  getConfiguredEventIndexRef,
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
} from './config';
import { pubkeyToNpub } from './nostr';
import { NostrEventIndexReader } from './nostrIndexReader';
import {
  createPersonalEventIndexReadStore,
  getLocalPersonalEventIndexRoot,
  isLocalPersonalEventIndexRoot,
} from './personalEventIndexBrowser';
import {
  resolveTreeTargetRoot,
  toImmutableTreeTargetRef,
  watchTreeTargetRoot,
} from './treeRef';
import { resolveImmutableRoot } from './workerBlockStore';

const PERSONAL_ROOT_RESOLVE_RETRY_DELAYS_MS = [120, 360, 900];
const personalIndexRootPromises = new Map<string, Promise<CID | null>>();
const personalIndexRoots = new Map<string, CID>();
const readersByRootKey = new Map<string, NostrEventIndexReader>();

function rootKey(root: CID): string {
  return `${Array.from(root.hash).join(',')}:${Array.from(root.key ?? []).join(',')}`;
}

export async function resolveConfiguredEventIndexRoot(): Promise<CID | null> {
  return await resolveTreeTargetRoot(getConfiguredEventIndexRef(), {
    resolveImmutablePath: async (root, path) => await resolveImmutableRoot(toImmutableTreeTargetRef(root), path),
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
  });
}

export async function watchConfiguredEventIndexRoot(
  listener: (root: CID | null) => void,
): Promise<() => Promise<void>> {
  return await watchTreeTargetRoot(getConfiguredEventIndexRef(), listener, {
    resolveImmutablePath: async (root, path) => await resolveImmutableRoot(toImmutableTreeTargetRef(root), path),
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
  });
}

export function getRootNhash(root: CID): string {
  return nhashEncode(root);
}

export function getReaderForRoot(root: CID): NostrEventIndexReader {
  const key = rootKey(root);
  const cachedReader = readersByRootKey.get(key);
  if (cachedReader) {
    return cachedReader;
  }

  const nextReader = isLocalPersonalEventIndexRoot(root)
    ? new NostrEventIndexReader(root, createPersonalEventIndexReadStore())
    : new NostrEventIndexReader(root);
  readersByRootKey.set(key, nextReader);
  return nextReader;
}

async function resolveMutableTreeRootWithRetries(
  npub: string,
  path: string,
): Promise<CID | null> {
  return await resolveTreeTargetRoot(`${npub}/${path}`, {
    resolveImmutablePath: async (root, path) => await resolveImmutableRoot(toImmutableTreeTargetRef(root), path),
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
    retryDelaysMs: PERSONAL_ROOT_RESOLVE_RETRY_DELAYS_MS,
  });
}

export async function resolveProfileEventIndexRoot(pubkey: string): Promise<CID | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  const localRoot = await getLocalPersonalEventIndexRoot(normalizedPubkey);
  if (localRoot) {
    personalIndexRoots.set(normalizedPubkey, localRoot);
    return localRoot;
  }
  const cachedRoot = personalIndexRoots.get(normalizedPubkey);
  if (cachedRoot) {
    return cachedRoot;
  }

  const cached = personalIndexRootPromises.get(normalizedPubkey);
  if (cached) {
    const root = await cached;
    if (root) {
      personalIndexRoots.set(normalizedPubkey, root);
    } else {
      personalIndexRootPromises.delete(normalizedPubkey);
    }
    return root;
  }

  const promise = (async () => {
    try {
      return await resolveMutableTreeRootWithRetries(pubkeyToNpub(normalizedPubkey), 'nostr-event-index');
    } catch (error) {
      console.warn('Failed to resolve personal nostr event index', error);
      return null;
    }
  })();

  personalIndexRootPromises.set(normalizedPubkey, promise);
  const root = await promise;
  personalIndexRootPromises.delete(normalizedPubkey);
  if (root) {
    personalIndexRoots.set(normalizedPubkey, root);
  }
  return root;
}
