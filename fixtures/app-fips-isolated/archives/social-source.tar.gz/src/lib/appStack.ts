import type { CID } from '@hashtree/core';
import type { FeedSnapshot, ProfileSocialSnapshot, NoteThreadSnapshot } from './nostrIndex';
import type { ProfileSnapshot } from './profileNotes';
import type { NotificationItem } from './appDetailLoaders';
import type { ProfileRecord, RawEvent } from './nostr';
import type { NoteEngagement } from './noteEngagement';
import type { Route } from './appRoute';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';

export const MAX_ROUTE_STACK_SIZE = 5;

export type RouteStackEntry = {
  key: string;
  route: Route;
};

export type RouteStackState = {
  entries: RouteStackEntry[];
  currentIndex: number;
};

export type MountedRouteRenderEntry = RouteStackEntry & {
  cache: RouteRenderCache;
};

export type RouteRenderCache = {
  key: string;
  route: Route;
  rootNhash: string;
  viewerPubkey: string | null;
  homeFeedSourcePubkey: string | null;
  loading: boolean;
  feedRequiresRefresh: boolean;
  feed: FeedSnapshot | null;
  profiles: Map<string, ProfileRecord>;
  noteEngagements: Map<string, NoteEngagement>;
  homeNotes: RawEvent[];
  homeFeedHasMore: boolean;
  homeFeedLoadPending: boolean;
  feedLimit: number;
  homeFeedFetchLimit: number;
  homeFeedLastLoadScrollOffset: number;
  notifications: NotificationItem[];
  notificationsLoading: boolean;
  notificationsHasMore: boolean;
  notificationsLoadPending: boolean;
  profilePage: ProfileSnapshot | null;
  profileSocial: ProfileSocialSnapshot | null;
  profileSocialLoading: boolean;
  profileSocialLoadPending: boolean;
  profileNotesLoading: boolean;
  profileNotes: RawEvent[];
  profilePostCountLabel?: string;
  profileReplyCountLabel?: string;
  profileMediaCountLabel?: string;
  profileLikesCountLabel?: string;
  profileFeedHasMore: boolean;
  profileFeedLoadPending: boolean;
  profileNoteLimit: number;
  profileNoteFetchLimit: number;
  profileFeedLastLoadScrollOffset: number;
  profileSocialVisibleLimit: number;
  profileSocialFollowerFetchLimit: number;
  currentFollows: string[];
  currentFollowers: string[];
  followsCountLabel: string;
  followerCountLabel: string;
  profilePersonalRoot: CID | null;
  threadPage: NoteThreadSnapshot | null;
  threadLoading: boolean;
  threadPersonalRoot: CID | null;
  threadRoots: CID[];
  threadReplyCursor: RecentTextNoteCursor | null;
  threadReplies: RawEvent[];
  threadDurableRepliesHasMore: boolean;
  threadRepliesHasMore: boolean;
  threadRepliesLoadPending: boolean;
  threadReplyFetchLimit: number;
  threadReplyLastLoadScrollOffset: number;
};

/**
 * Keep the bounded navigation stack mounted so every view retains local
 * component state. Route-keyed offsets restore the shared page scroller.
 * MAX_ROUTE_STACK_SIZE remains the memory bound.
 */
export function selectMountedRouteStackEntries(
  routeStack: RouteStackEntry[],
  _currentIndex: number,
): RouteStackEntry[] {
  return routeStack;
}

export function syncRouteStackEntries(
  routeStack: RouteStackEntry[],
  _currentIndex: number,
  nextEntry: RouteStackEntry,
): RouteStackState {
  // This is a resident view cache, not a mirror of browser history. Touching
  // an existing URL makes it most-recently used; a Back miss must not discard
  // still-mounted Forward destinations merely because their browser-history
  // entries sit after the current one.
  const nextEntries = [
    ...routeStack.filter((entry) => entry.key !== nextEntry.key),
    nextEntry,
  ];
  let retainedHomeIndex = -1;
  for (let index = nextEntries.length - 1; index >= 0; index -= 1) {
    if (nextEntries[index]?.route.kind === 'home') {
      retainedHomeIndex = index;
      break;
    }
  }

  const entries = [...nextEntries];
  while (entries.length > MAX_ROUTE_STACK_SIZE) {
    const retainedHome = nextEntries[retainedHomeIndex] ?? null;
    const evictionIndex = entries.findIndex((entry) => entry.key !== retainedHome?.key);
    if (evictionIndex < 0) {
      // Defensive only: route keys are unique, so this can happen solely if a
      // future caller lowers the bound below one while retaining Home.
      entries.shift();
    } else {
      entries.splice(evictionIndex, 1);
    }
  }

  return {
    entries,
    currentIndex: entries.length - 1,
  };
}

export function replaceRouteStackEntry(
  routeStack: RouteStackEntry[],
  replacedKey: string,
  nextEntry: RouteStackEntry,
): RouteStackState {
  const retainedEntries = routeStack.filter((entry) => entry.key !== replacedKey);
  return syncRouteStackEntries(retainedEntries, retainedEntries.length - 1, nextEntry);
}

export function trimRouteRenderCache(
  routeRenderCache: Map<string, RouteRenderCache>,
  routeStack: RouteStackEntry[] | RouteStackState,
): Map<string, RouteRenderCache> {
  const entries = Array.isArray(routeStack) ? routeStack : routeStack.entries;
  let needsTrim = false;
  for (const entryKey of routeRenderCache.keys()) {
    if (!entries.some((entry) => entry.key === entryKey)) {
      needsTrim = true;
      break;
    }
  }
  if (!needsTrim) {
    return routeRenderCache;
  }
  return new Map(
    [...routeRenderCache].filter(([entryKey]) => (
      entries.some((entry) => entry.key === entryKey)
    )),
  );
}

/**
 * Cache snapshots are rebuilt by Svelte reactive declarations. Preserve the
 * existing Map when the rebuilt snapshot contains the same references and
 * scalar values so an unrelated hot-state tick does not invalidate the whole
 * mounted route projection.
 */
export function routeRenderCachesShallowEqual(
  left: RouteRenderCache,
  right: RouteRenderCache,
): boolean {
  if (left === right) {
    return true;
  }
  const leftKeys = Object.keys(left) as Array<keyof RouteRenderCache>;
  const rightKeys = Object.keys(right) as Array<keyof RouteRenderCache>;
  return leftKeys.length === rightKeys.length
    && leftKeys.every((key) => Object.is(left[key], right[key]));
}

export function upsertRouteRenderCache(
  routeRenderCache: Map<string, RouteRenderCache>,
  routeStack: RouteStackEntry[] | RouteStackState,
  nextEntry: RouteRenderCache,
): Map<string, RouteRenderCache> {
  const trimmedCache = trimRouteRenderCache(routeRenderCache, routeStack);
  const entries = Array.isArray(routeStack) ? routeStack : routeStack.entries;
  if (!entries.some((entry) => entry.key === nextEntry.key)) {
    return trimmedCache;
  }
  const previousEntry = trimmedCache.get(nextEntry.key);
  if (previousEntry && routeRenderCachesShallowEqual(previousEntry, nextEntry)) {
    return trimmedCache;
  }
  const nextCache = new Map(trimmedCache);
  nextCache.set(nextEntry.key, nextEntry);
  return nextCache;
}

/**
 * Reuse both entry wrappers and the containing array when the stack/cache
 * inputs still describe the same mounted cards. Consumers can pass their
 * previous projection from a reactive declaration to avoid waking every
 * hidden component for an unrelated state change.
 */
export function projectMountedRouteRenderEntries(
  routeStack: RouteStackEntry[],
  routeRenderCache: Map<string, RouteRenderCache>,
  previous: MountedRouteRenderEntry[] = [],
): MountedRouteRenderEntry[] {
  let nextSize = 0;
  for (const entry of routeStack) {
    if (routeRenderCache.has(entry.key)) {
      nextSize += 1;
    }
  }
  const unchanged = previous.length === nextSize && previous.every((entry) => {
    const nextEntry = routeStack.find((candidate) => candidate.key === entry.key);
    return nextEntry?.route === entry.route
      && routeRenderCache.get(entry.key) === entry.cache;
  });
  if (unchanged) {
    return previous;
  }

  const nextByKey = new Map<string, MountedRouteRenderEntry>();
  for (const entry of routeStack) {
    const cache = routeRenderCache.get(entry.key);
    if (cache) {
      nextByKey.set(entry.key, { ...entry, cache });
    }
  }
  const projected: MountedRouteRenderEntry[] = [];
  for (const previousEntry of previous) {
    const nextEntry = nextByKey.get(previousEntry.key);
    if (!nextEntry) {
      continue;
    }
    projected.push(
      previousEntry.route === nextEntry.route && previousEntry.cache === nextEntry.cache
        ? previousEntry
        : nextEntry,
    );
    nextByKey.delete(previousEntry.key);
  }
  // LRU touches reorder routeStack, but moving keyed route DOM can disturb
  // focus, media, and component-local state. Append only genuinely new cards
  // and keep retained cards in their existing render order.
  for (const entry of routeStack) {
    const nextEntry = nextByKey.get(entry.key);
    if (nextEntry) {
      projected.push(nextEntry);
    }
  }
  return projected;
}
