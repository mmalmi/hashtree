const MAX_U64 = (1n << 64n) - 1n;
const HEX_DIGITS = '0123456789abcdef';

export type RecentTextNoteCursor = {
  createdAt: number;
  eventId: string;
};

export type RecentTextNoteQueryOptions = {
  before?: RecentTextNoteCursor;
  emitEvery?: number;
  includeReplies?: boolean;
  kinds?: readonly number[];
  singleAuthorBatchSize?: number;
  singleAuthorScanMultiplier?: number;
  since?: number;
  until?: number;
};

export function isStrictlyBeforeRecentCursor(
  createdAt: number,
  eventId: string,
  cursor: RecentTextNoteCursor | undefined,
): boolean {
  if (!cursor) {
    return true;
  }
  return createdAt < cursor.createdAt
    || (createdAt === cursor.createdAt && eventId.localeCompare(cursor.eventId) > 0);
}

/**
 * Return disjoint index prefixes covering the exact cursor second and every
 * older second in ascending reversed-time order.
 *
 * Nostr collection time indexes store `MAX_U64 - created_at` as sixteen hex
 * digits. Walking the broad author/kind prefix for a continuation would start
 * at the newest event and discard the whole already-painted head. These
 * prefixes let the existing immutable B-tree seek directly to the cursor
 * neighborhood without requiring a different Hashtree query API.
 */
export function timeIndexPrefixesFromCursor(
  fixedPrefix: string,
  cursor: RecentTextNoteCursor,
): string[] {
  if (!Number.isSafeInteger(cursor.createdAt) || cursor.createdAt < 0) {
    throw new Error(`Invalid Nostr created_at cursor: ${cursor.createdAt}`);
  }

  const reversed = (MAX_U64 - BigInt(cursor.createdAt)).toString(16).padStart(16, '0');
  const prefixes = [`${fixedPrefix}${reversed}:`];
  for (let index = reversed.length - 1; index >= 0; index -= 1) {
    const digit = HEX_DIGITS.indexOf(reversed[index]!);
    for (let next = digit + 1; next < HEX_DIGITS.length; next += 1) {
      prefixes.push(`${fixedPrefix}${reversed.slice(0, index)}${HEX_DIGITS[next]}`);
    }
  }
  return prefixes;
}

export async function* streamTimeOrderedIndex<T>(
  source: {
    streamQueryIndex: (
      indexName: string,
      options?: { prefix?: string; limit?: number },
    ) => AsyncGenerator<T>;
  },
  indexName: string,
  fixedPrefix: string,
  before: RecentTextNoteCursor | undefined,
  limit?: number,
): AsyncGenerator<T, void, void> {
  if (!before) {
    yield* source.streamQueryIndex(
      indexName,
      limit === undefined ? { prefix: fixedPrefix } : { prefix: fixedPrefix, limit },
    );
    return;
  }

  for (const prefix of timeIndexPrefixesFromCursor(fixedPrefix, before)) {
    // Cursor filtering happens at the decoded key boundary, so a query limit
    // here could count same-second entries that precede the event-id cursor.
    yield* source.streamQueryIndex(indexName, { prefix });
  }
}

export function timeAndEventIdFromIndexKey(
  key: string,
): { createdAt: number; eventId: string } {
  const parts = key.split(':');
  const reversed = parts.at(-2);
  const eventId = parts.at(-1);
  if (!reversed || !eventId) {
    throw new Error(`Invalid time-ordered Nostr index key: ${key}`);
  }
  const createdAt = MAX_U64 - BigInt(`0x${reversed}`);
  if (createdAt > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error(`Created_at exceeds safe integer range in Nostr index key: ${key}`);
  }
  return { createdAt: Number(createdAt), eventId };
}

export function createdAtFromKindTimeIndexKey(key: string): number {
  const parts = key.split(':');
  if (parts.length < 3 || !parts[1] || !parts.at(-1)) {
    throw new Error(`Invalid kind-time index key: ${key}`);
  }
  const createdAt = MAX_U64 - BigInt(`0x${parts[1]}`);
  if (createdAt > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error(`Created_at exceeds safe integer range in kind-time index key: ${key}`);
  }
  return Number(createdAt);
}

export function authorFromKindTimeAuthorKey(key: string): string | null {
  const parts = key.split(':');
  return parts.length >= 4 ? parts[2] : null;
}
