import { verifyNostrEvent } from 'nostr-pubsub';
import { restoreProfileArchiveHint } from './profileArchiveHint';
import { createProfileRefreshQueue } from './profileRefresh';
import { rememberProfileRecords } from './profileCache';
import { settingsStore } from './settings';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { createWorkerRelayTransport } from './workerRelayTransport';
import { socialDataPlane } from './socialDataPlane';
import { parseProfileEvent, type ProfileRecord } from './nostr';
import { preferNewerProfileRecord } from './profileRecords';

const transport = createWorkerRelayTransport({ getRelays: getConfiguredNostrRelays });
const queue = createProfileRefreshQueue({
  refresh(authors, signal) {
    const profiles = new Map<string, ProfileRecord>();
    return new Promise(resolve => {
      let settleTimer: ReturnType<typeof setTimeout> | undefined;
      const finish = (complete: boolean) => {
        clearTimeout(deadline);
        clearTimeout(settleTimer);
        signal.removeEventListener('abort', stop);
        resolve({ profiles, complete });
      };
      const stop = () => subscription.close('profile refresh stopped');
      const deadline = setTimeout(stop, 6_000);
      // Deliver each verified winner from the worker cache or a relay while
      // other relays are still answering. Later replacements can still win.
      const subscription = transport.subscribe(authors.map(pubkey => ({
        kinds: [0], authors: [pubkey], limit: 1,
      })), {
        onEvent(event) {
          if (signal.aborted || event.kind !== 0 || !authors.includes(event.pubkey)) { return; }
          const profile = parseProfileEvent(event);
          if (!profile) { return; }
          const current = profiles.get(event.pubkey);
          const winner = preferNewerProfileRecord(current, profile);
          if (winner?.eventId !== event.id || current?.eventId === event.id) { return; }
          profiles.set(event.pubkey, profile);
          rememberProfileRecords([profile]);
          socialDataPlane.ingestVerifiedRelayEvent(verifyNostrEvent(event), 'configured-relays');
          // Once every requested author has answered, wait briefly for newer
          // replacements instead of holding the next batch for a slow relay.
          if (profiles.size >= authors.length && !settleTimer) {
            settleTimer = setTimeout(stop, 500);
          }
        },
        onClose(reasons = []) { finish(reasons.length === 0); },
      }, { closeOnEose: true });
      signal.addEventListener('abort', stop, { once: true });
      if (signal.aborted) { stop(); }
    });
  },
  onProfiles: rememberProfileRecords,
});

/** Pair with the route's activity and dispose on unmount, including retained routes. */
export function createProfileRefreshBinding(bindingOptions: { priority?: boolean } = {}) {
  let watched: string | null = null;
  let hintRead: AbortController | undefined;
  let release: (() => void) | undefined;
  return (pubkey: string | null, active = true): void => {
    const next = active ? pubkey : null;
    if (next === watched) { return; }
    release?.();
    hintRead?.abort();
    if (next && bindingOptions.priority) {
      hintRead = new AbortController();
      void restoreProfileArchiveHint(next, hintRead.signal);
    }
    watched = next;
    release = next ? queue.watch(next, bindingOptions) : undefined;
  };
}

export function startBrowserProfileRefresh(): () => void {
  const sync = () => queue.setActive(
    settingsStore.getState().network.refreshProfiles
      && document.visibilityState !== 'hidden' && navigator.onLine,
  );
  const unsubscribe = settingsStore.subscribe(sync);
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('online', sync);
  window.addEventListener('offline', sync);
  return () => {
    unsubscribe();
    document.removeEventListener('visibilitychange', sync);
    window.removeEventListener('online', sync);
    window.removeEventListener('offline', sync);
    queue.setActive(false);
  };
}
