import { createProfileRefreshQueue } from './profileRefresh';
import { rememberProfileRecords } from './profileCache';
import { settingsStore } from './settings';

const queue = createProfileRefreshQueue({
  async refresh(pubkeys, signal) {
    const { refreshBrowserProfiles } = await import('./browserEventReadRouter');
    return await refreshBrowserProfiles(pubkeys, signal);
  },
  onProfiles: rememberProfileRecords,
});

/** Pair with the route's activity and dispose on unmount, including retained routes. */
export function createProfileRefreshBinding() {
  let watched: string | null = null;
  let release: (() => void) | undefined;
  return (pubkey: string | null, active = true): void => {
    const next = active ? pubkey : null;
    if (next === watched) { return; }
    release?.();
    watched = next;
    release = next ? queue.watch(next) : undefined;
  };
}

export function startBrowserProfileRefresh(): () => void {
  const sync = () => queue.setActive(
    settingsStore.getState().network.refreshProfiles
      && document.visibilityState !== 'hidden' && navigator.onLine,
  );
  const unsubscribe = settingsStore.subscribe(sync);
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('online', sync);
  window.addEventListener('offline', sync);
  return () => {
    unsubscribe();
    document.removeEventListener('visibilitychange', sync);
    window.removeEventListener('online', sync);
    window.removeEventListener('offline', sync);
    queue.setActive(false);
  };
}
