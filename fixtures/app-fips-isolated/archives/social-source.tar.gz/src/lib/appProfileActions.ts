import type { AppError, ReportAppError } from './appError';
import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { getSharedProfileRecord } from './profileCache';
import { usesExternalSigner, type SocialAccount } from './accounts';
import type { Route } from './appRoute';
import type { ProfileSocialSnapshot } from './nostrIndex';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  createProfileMetadataEvent,
  createProfileMetadataEventAsync,
  selectNewestProfileMetadataEvent,
  type ProfileEdits,
} from './profileMetadata';
import {
  canPublishFromAccount,
  createMuteListEvent,
  createMuteListEventAsync,
  createContactsListEvent,
  createContactsListEventAsync,
  publishEvent,
} from './nostrPublish';
import { parseProfileEvent } from './nostr';
import { registerIrisUsername, type RegisterIrisUsernameAction } from './irisUsername';
import { changeListMember, newerList, readLatestListFromRelays } from './viewerListRelay';
import { canReadHomeFeedFromRelays } from './homeFeedReads';

type ProfileActionDeps = {
  activeAccount: SocialAccount | null;
  followPendingPubkeys: Set<string>;
  hydratedViewerProfileEvent: RawEvent | null;
  indexedViewerMuteListEvent: RawEvent | null;
  liveOverlayVersion: number;
  mutePendingPubkeys: Set<string>;
  sessionMutedPubkeys: Set<string>;
  pageError: AppError;
  profileEditorBlockedReason: string;
  profileSaveError: string;
  profileSaveMessage: string;
  profileSavePending: boolean;
  profileSocial: ProfileSocialSnapshot | null;
  route: Route;
  viewerContactsEvent: RawEvent | null;
  viewerContactsProjectionAuthoritative: boolean;
  viewerFollows: Set<string>;
  viewerMuteListEvent: RawEvent | null;
  viewerMutedPubkeys: Set<string>;
  viewerProfileEvent: RawEvent | null;
  copyText: (value: string, fallbackMessage: string) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  reportError: ReportAppError;
  resetLiveHomeFeedBuffer: () => void;
};

function buildAbsoluteProfileUrl(href: string): string {
  return typeof window === 'undefined'
    ? href
    : new URL(href, window.location.origin).toString();
}

function normalizeWebsiteUrl(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) {
    return null;
  }
  const candidate = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const url = new URL(candidate);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.toString() : null;
  } catch {
    return null;
  }
}

export function createAppProfileActions(deps: ProfileActionDeps) {
  async function handleCopyPubkey(pubkey: string): Promise<void> {
    await deps.copyText(pubkey, "Couldn't copy the pubkey.");
  }

  async function handleCopyNpub(npub: string): Promise<void> {
    await deps.copyText(npub, "Couldn't copy the npub.");
  }

  async function handleCopyProfileLink(href: string): Promise<void> {
    await deps.copyText(
      buildAbsoluteProfileUrl(href),
      "Couldn't copy the profile link.",
    );
  }

  function handleOpenWebsite(rawUrl: string): void {
    const url = normalizeWebsiteUrl(rawUrl);
    if (!url) {
      deps.pageError = "Couldn't open that website.";
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  async function handleSaveProfile(fields: ProfileEdits): Promise<void> {
    const account = deps.activeAccount;
    if (!account || deps.profileSavePending) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.profileSaveError = 'This profile is read-only.';
      return;
    }
    if (deps.profileEditorBlockedReason) {
      deps.profileSaveError = deps.profileEditorBlockedReason;
      return;
    }
    deps.profileSavePending = true;
    deps.profileSaveError = '';
    deps.profileSaveMessage = '';
    try {
      const options = { baseEvent: deps.viewerProfileEvent };
      const event = usesExternalSigner(account)
        ? await createProfileMetadataEventAsync(account, fields, options)
        : createProfileMetadataEvent(account, fields, options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      if (deps.viewerProfileEvent?.id !== options.baseEvent?.id) {
        throw new Error('Your profile changed while signing. Review your edits and save again.');
      }
      publishEvent(event);
      deps.hydratedViewerProfileEvent = selectNewestProfileMetadataEvent([
        deps.hydratedViewerProfileEvent,
        event,
      ], account.pubkey);
      const profile = parseProfileEvent(event);
      if (profile) {
        deps.mergeCachedProfiles(new Map([[profile.pubkey, profile]]));
      }
      deps.liveOverlayVersion += 1;
      deps.profileSaveMessage = 'Profile saved on this device.';
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.profileSaveError = error instanceof Error
        ? error.message
        : "Couldn't save the profile on this device.";
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {deps.profileSavePending = false;}
    }
  }

  const handleRegisterIrisUsername: RegisterIrisUsernameAction = async (registration) => {
    const account = deps.activeAccount;
    if (account?.pubkey !== registration.pubkey) {
      throw new Error('Your active profile changed. Start registration again.');
    }
    if (!account || !canPublishFromAccount(account)) {
      throw new Error('This profile is read-only.');
    }
    return registerIrisUsername(account, registration);
  };

  async function handleToggleFollow(pubkey: string, nextFollowing: boolean): Promise<void> {
    const account = deps.activeAccount;
    if (!account || pubkey === account.pubkey) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    if (deps.followPendingPubkeys.has(pubkey) || (usesExternalSigner(account) && deps.followPendingPubkeys.size > 0)) {
      return;
    }
    deps.followPendingPubkeys = new Set(deps.followPendingPubkeys).add(pubkey);
    deps.pageError = '';
    try {
      // Merge onto the newest follow list on relays so a stale or not yet
      // loaded list cannot replace the user's real follows.
      const latest = await readLatestListFromRelays(account.pubkey, 3);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      const baseEvent = newerList(deps.viewerContactsEvent, latest);
      // Ask only when relays are reachable but the list could not be checked;
      // offline, the change is queued as before.
      if (!baseEvent && latest === undefined && !deps.viewerContactsProjectionAuthoritative
        && canReadHomeFeedFromRelays() && typeof window !== 'undefined'
        && !window.confirm('Your follow list could not be loaded. Following now may replace it. Continue?')) {
        return;
      }
      const nextFollows = changeListMember(baseEvent, deps.viewerFollows, pubkey, nextFollowing);
      const options = { baseEvent };
      const event = usesExternalSigner(account)
        ? await createContactsListEventAsync(account, [...nextFollows], options)
        : createContactsListEvent(account, [...nextFollows], options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.resetLiveHomeFeedBuffer();
      if (nextFollowing) {contactMemoryStore.remember(pubkey, publicContactName(getSharedProfileRecord(pubkey)));}
      deps.viewerFollows = nextFollows;
      deps.viewerContactsEvent = event;
      deps.viewerContactsProjectionAuthoritative = true;
      if (
        deps.profileSocial
        && deps.route.kind === 'profile'
        && deps.route.pubkey === account.pubkey
      ) {
        deps.profileSocial = {
          ...deps.profileSocial,
          contactsEvent: event,
          follows: [...nextFollows],
          followsCount: nextFollows.size,
          hasFollows: true,
        };
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.pageError = deps.reportError(
        nextFollowing ? "Couldn't follow this profile." : "Couldn't unfollow this profile.",
        error,
      );
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.followPendingPubkeys);
        nextPending.delete(pubkey);
        deps.followPendingPubkeys = nextPending;
      }
    }
  }

  async function handleToggleMute(pubkey: string, nextMuted: boolean): Promise<void> {
    const account = deps.activeAccount;
    if (!account || pubkey === account.pubkey || deps.mutePendingPubkeys.has(pubkey)) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    if (usesExternalSigner(account) && deps.mutePendingPubkeys.size > 0) { return; }
    deps.mutePendingPubkeys = new Set(deps.mutePendingPubkeys).add(pubkey);
    deps.pageError = '';
    try {
      // Same as follows: build on the newest mute list so entries added on
      // another device are kept.
      const latest = await readLatestListFromRelays(account.pubkey, 10_000);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      const local = newerList(deps.indexedViewerMuteListEvent, deps.viewerMuteListEvent);
      const baseEvent = newerList(local, latest);
      if (!baseEvent && latest === undefined && canReadHomeFeedFromRelays()) {
        deps.pageError = "Couldn't verify your mute list. Try again when it is available.";
        return;
      }
      const nextMutedPubkeys = changeListMember(baseEvent, deps.viewerMutedPubkeys, pubkey, nextMuted);
      const options = { baseEvent };
      const event = usesExternalSigner(account)
        ? await createMuteListEventAsync(account, [...nextMutedPubkeys], options)
        : createMuteListEvent(account, [...nextMutedPubkeys], options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.resetLiveHomeFeedBuffer();
      const sessionMuted = new Set(deps.sessionMutedPubkeys);
      if (nextMuted) {sessionMuted.add(pubkey);} else {sessionMuted.delete(pubkey);}
      deps.sessionMutedPubkeys = sessionMuted;
      deps.indexedViewerMuteListEvent = event;
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.pageError = deps.reportError(
        nextMuted ? "Couldn't mute this profile." : "Couldn't unmute this profile.",
        error,
      );
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.mutePendingPubkeys);
        nextPending.delete(pubkey);
        deps.mutePendingPubkeys = nextPending;
      }
    }
  }

  return {
    handleCopyNpub,
    handleCopyProfileLink,
    handleCopyPubkey,
    handleOpenWebsite,
    handleRegisterIrisUsername,
    handleSaveProfile,
    handleToggleFollow,
    handleToggleMute,
  };
}
