import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { getSharedProfileRecord } from './profileCache';
import type { SocialAccount } from './accounts';
import type { Route } from './appRoute';
import type { ProfileSocialSnapshot } from './nostrIndex';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  createProfileMetadataEvent,
  createProfileMetadataEventAsync,
  selectNewestProfileMetadataEvent,
  type EditableProfileFields,
} from './profileMetadata';
import {
  canPublishFromAccount,
  createMuteListEvent,
  createMuteListEventAsync,
  createContactsListEvent,
  createContactsListEventAsync,
  publishEvent,
} from './nostrPublish';
import { parseProfileEvent } from './nostr';
import { registerIrisUsername } from './irisUsername';

type ProfileActionDeps = {
  activeAccount: SocialAccount | null;
  followPendingPubkeys: Set<string>;
  hydratedViewerProfileEvent: RawEvent | null;
  indexedViewerMuteListEvent: RawEvent | null;
  liveOverlayVersion: number;
  mutePendingPubkeys: Set<string>;
  pageError: string;
  profileEditorBlockedReason: string;
  profileSaveError: string;
  profileSaveMessage: string;
  profileSavePending: boolean;
  profileSocial: ProfileSocialSnapshot | null;
  route: Route;
  viewerContactsEvent: RawEvent | null;
  viewerContactsProjectionAuthoritative: boolean;
  viewerFollows: Set<string>;
  viewerMuteListEvent: RawEvent | null;
  viewerMutedPubkeys: Set<string>;
  viewerProfileEvent: RawEvent | null;
  copyText: (value: string, fallbackMessage: string) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  reportError: (fallbackMessage: string, error: unknown) => string;
  resetLiveHomeFeedBuffer: () => void;
};

function buildAbsoluteProfileUrl(href: string): string {
  return typeof window === 'undefined'
    ? href
    : new URL(href, window.location.origin).toString();
}

function normalizeWebsiteUrl(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) {
    return null;
  }
  const candidate = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const url = new URL(candidate);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.toString() : null;
  } catch {
    return null;
  }
}

export function createAppProfileActions(deps: ProfileActionDeps) {
  async function handleCopyPubkey(pubkey: string): Promise<void> {
    await deps.copyText(pubkey, "Couldn't copy the pubkey.");
  }

  async function handleCopyNpub(npub: string): Promise<void> {
    await deps.copyText(npub, "Couldn't copy the npub.");
  }

  async function handleCopyProfileLink(href: string): Promise<void> {
    await deps.copyText(
      buildAbsoluteProfileUrl(href),
      "Couldn't copy the profile link.",
    );
  }

  function handleOpenWebsite(rawUrl: string): void {
    const url = normalizeWebsiteUrl(rawUrl);
    if (!url) {
      deps.pageError = "Couldn't open that website.";
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  async function handleSaveProfile(fields: Partial<EditableProfileFields>): Promise<void> {
    const account = deps.activeAccount;
    if (!account || deps.profileSavePending) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.profileSaveError = 'This account is read-only.';
      return;
    }
    if (deps.profileEditorBlockedReason) {
      deps.profileSaveError = deps.profileEditorBlockedReason;
      return;
    }
    deps.profileSavePending = true;
    deps.profileSaveError = '';
    deps.profileSaveMessage = '';
    try {
      const options = { baseEvent: deps.viewerProfileEvent };
      const event = account.method === 'nip07'
        ? await createProfileMetadataEventAsync(account, fields, options)
        : createProfileMetadataEvent(account, fields, options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.hydratedViewerProfileEvent = selectNewestProfileMetadataEvent([
        deps.hydratedViewerProfileEvent,
        event,
      ], account.pubkey);
      const profile = parseProfileEvent(event);
      if (profile) {
        deps.mergeCachedProfiles(new Map([[profile.pubkey, profile]]));
      }
      deps.liveOverlayVersion += 1;
      deps.profileSaveMessage = 'Profile saved on this device.';
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.profileSaveError = error instanceof Error
        ? error.message
        : "Couldn't save the profile on this device.";
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {deps.profileSavePending = false;}
    }
  }

  async function handleRegisterIrisUsername(
    username: string,
    cfToken?: string,
  ): Promise<{ signedUp: boolean }> {
    const account = deps.activeAccount;
    if (!account || !canPublishFromAccount(account)) {
      throw new Error('This account is read-only.');
    }
    return registerIrisUsername(account, username, cfToken);
  }

  async function handleToggleFollow(pubkey: string, nextFollowing: boolean): Promise<void> {
    const account = deps.activeAccount;
    if (!account || pubkey === account.pubkey) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (deps.followPendingPubkeys.has(pubkey) || (account.method === 'nip07' && deps.followPendingPubkeys.size > 0)) {
      return;
    }
    const previousFollows = new Set(deps.viewerFollows);
    const nextFollows = new Set(deps.viewerFollows);
    if (nextFollowing) {
      nextFollows.add(pubkey);
    } else {
      nextFollows.delete(pubkey);
    }
    deps.followPendingPubkeys = new Set(deps.followPendingPubkeys).add(pubkey);
    deps.pageError = '';
    try {
      const options = { baseEvent: deps.viewerContactsEvent };
      const event = account.method === 'nip07'
        ? await createContactsListEventAsync(account, [...nextFollows], options)
        : createContactsListEvent(account, [...nextFollows], options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.resetLiveHomeFeedBuffer();
      if (nextFollowing) {contactMemoryStore.remember(pubkey, publicContactName(getSharedProfileRecord(pubkey)));}
      deps.viewerFollows = nextFollows;
      deps.viewerContactsEvent = event;
      deps.viewerContactsProjectionAuthoritative = true;
      if (
        deps.profileSocial
        && deps.route.kind === 'profile'
        && deps.route.pubkey === account.pubkey
      ) {
        deps.profileSocial = {
          ...deps.profileSocial,
          contactsEvent: event,
          follows: [...nextFollows],
          followsCount: nextFollows.size,
          hasFollows: true,
        };
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.viewerFollows = previousFollows;
      deps.pageError = deps.reportError(
        nextFollowing ? "Couldn't follow this profile." : "Couldn't unfollow this profile.",
        error,
      );
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.followPendingPubkeys);
        nextPending.delete(pubkey);
        deps.followPendingPubkeys = nextPending;
      }
    }
  }

  async function handleToggleMute(pubkey: string, nextMuted: boolean): Promise<void> {
    const account = deps.activeAccount;
    if (!account || pubkey === account.pubkey || deps.mutePendingPubkeys.has(pubkey)) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (account.method === 'nip07' && deps.mutePendingPubkeys.size > 0) { return; }
    const previousEvent = deps.viewerMuteListEvent;
    const nextMutedPubkeys = new Set(deps.viewerMutedPubkeys);
    if (nextMuted) {
      nextMutedPubkeys.add(pubkey);
    } else {
      nextMutedPubkeys.delete(pubkey);
    }
    deps.mutePendingPubkeys = new Set(deps.mutePendingPubkeys).add(pubkey);
    deps.pageError = '';
    try {
      const options = { baseEvent: previousEvent };
      const event = account.method === 'nip07'
        ? await createMuteListEventAsync(account, [...nextMutedPubkeys], options)
        : createMuteListEvent(account, [...nextMutedPubkeys], options);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.resetLiveHomeFeedBuffer();
      deps.indexedViewerMuteListEvent = event;
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      deps.indexedViewerMuteListEvent = previousEvent;
      deps.pageError = deps.reportError(
        nextMuted ? "Couldn't mute this profile." : "Couldn't unmute this profile.",
        error,
      );
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.mutePendingPubkeys);
        nextPending.delete(pubkey);
        deps.mutePendingPubkeys = nextPending;
      }
    }
  }

  return {
    handleCopyNpub,
    handleCopyProfileLink,
    handleCopyPubkey,
    handleOpenWebsite,
    handleRegisterIrisUsername,
    handleSaveProfile,
    handleToggleFollow,
    handleToggleMute,
  };
}
