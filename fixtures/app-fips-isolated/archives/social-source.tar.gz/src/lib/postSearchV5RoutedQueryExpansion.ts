import { throwIfPostSearchAborted } from './postSearchAbort';
import {
  isPostSearchOneEditApart,
  POST_SEARCH_MAX_EXPANDED_TERMS,
  POST_SEARCH_MAX_PREFIX_TERMS_READ,
  postSearchOneEditDirectCandidates,
  rankPostSearchExpansionCandidates,
} from './postSearchQueryExpansion';
import type { PostSearchV5RoutedCatalogLookup } from '../server/postSearchV5RoutedCatalog';

const LOOKUP_CONCURRENCY = 6;

export interface PostSearchV5RoutedExpansion {
  terms: string[];
  exhaustive: boolean;
}

/** Recover a missing plain term from authenticated, bounded routed-run vocabularies. */
export async function expandPostSearchV5RoutedTerm(
  catalog: PostSearchV5RoutedCatalogLookup,
  term: string,
  signal: AbortSignal | null,
): Promise<PostSearchV5RoutedExpansion> {
  const prefix = await readRoutedPrefix(
    catalog,
    term,
    signal,
    POST_SEARCH_MAX_PREFIX_TERMS_READ,
    (candidate) => candidate !== term && !candidate.startsWith('#'),
  );
  if (prefix.matches.size > 0) {
    return rankedExpansion(term, prefix.matches, prefix.exhaustive);
  }

  const direct = await mapWithConcurrency(
    postSearchOneEditDirectCandidates(term),
    LOOKUP_CONCURRENCY,
    async (candidate) => await routedCatalogHasTerm(catalog, candidate, signal)
      ? candidate
      : null,
  );
  throwIfPostSearchAborted(signal);
  const matches = new Set(direct.filter((candidate): candidate is string => candidate !== null));
  let exhaustive = true;
  let remainingReads = POST_SEARCH_MAX_PREFIX_TERMS_READ;
  const characters = [...term];
  for (let anchorLength = Math.max(2, characters.length - 2);
    anchorLength >= 2
      && remainingReads > 0
      && matches.size < POST_SEARCH_MAX_EXPANDED_TERMS;
    anchorLength -= 1) {
    const anchor = characters.slice(0, anchorLength).join('');
    const scanned = await readRoutedPrefix(
      catalog,
      anchor,
      signal,
      remainingReads,
      (candidate) => candidate !== term
        && !candidate.startsWith('#')
        && isPostSearchOneEditApart(term, candidate),
    );
    remainingReads -= scanned.read;
    scanned.matches.forEach((candidate) => matches.add(candidate));
    exhaustive &&= scanned.exhaustive;
  }
  return rankedExpansion(term, matches, exhaustive);
}

async function routedCatalogHasTerm(
  catalog: PostSearchV5RoutedCatalogLookup,
  term: string,
  signal: AbortSignal | null,
): Promise<boolean> {
  for (const run of catalog.runs) {
    throwIfPostSearchAborted(signal);
    if (await run.getTerm(term)) {
      throwIfPostSearchAborted(signal);
      return true;
    }
  }
  throwIfPostSearchAborted(signal);
  return false;
}

async function readRoutedPrefix(
  catalog: PostSearchV5RoutedCatalogLookup,
  prefix: string,
  signal: AbortSignal | null,
  maxReads: number,
  include: (candidate: string) => boolean,
): Promise<{ matches: Set<string>; read: number; exhaustive: boolean }> {
  const matches = new Set<string>();
  let read = 0;
  const ordered = catalog.manifest.runs.map((descriptor, index) => ({
    descriptor,
    run: catalog.runs[index]!,
  })).sort((left, right) =>
    right.descriptor.newestBatchExclusive - left.descriptor.newestBatchExclusive
      || compareText(left.descriptor.entry, right.descriptor.entry));
  for (const { run } of ordered) {
    throwIfPostSearchAborted(signal);
    for await (const [candidate] of run.streamTermsByPrefix(prefix)) {
      throwIfPostSearchAborted(signal);
      read += 1;
      if (include(candidate)) {matches.add(candidate);}
      if (read >= maxReads) {
        return { matches, read, exhaustive: false };
      }
    }
  }
  return { matches, read, exhaustive: true };
}

function rankedExpansion(
  term: string,
  candidates: Iterable<string>,
  scannedExhaustively: boolean,
): PostSearchV5RoutedExpansion {
  const all = new Set(candidates);
  return {
    terms: rankPostSearchExpansionCandidates(term, all),
    exhaustive: scannedExhaustively && all.size <= POST_SEARCH_MAX_EXPANDED_TERMS,
  };
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  work: (value: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, async () => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await work(values[index]!);
    }
  }));
  return results;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
