import {
  HashTree,
  nhashDecode,
  toHex,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';

export const DEFAULT_WORKER_BLOCK_CACHE_MAX_BYTES = 32 * 1024 * 1024;

type WorkerBlockStoreOptions = {
  maxCacheBytes?: number;
  loadBlock?: (expectedHashHex: string) => Promise<Uint8Array | null>;
};

class ByteBoundedBlockCache {
  private readonly entries = new Map<string, Uint8Array>();
  private bytes = 0;

  constructor(private readonly maxBytes: number) {}

  get(key: string): Uint8Array | null {
    const value = this.entries.get(key);
    if (!value) {
      return null;
    }
    this.entries.delete(key);
    this.entries.set(key, value);
    return value;
  }

  set(key: string, value: Uint8Array): void {
    const current = this.entries.get(key);
    if (current) {
      this.entries.delete(key);
      this.bytes -= current.byteLength;
    }
    if (value.byteLength > this.maxBytes) {
      return;
    }
    this.entries.set(key, value);
    this.bytes += value.byteLength;
    while (this.bytes > this.maxBytes) {
      const oldest = this.entries.entries().next().value as [string, Uint8Array] | undefined;
      if (!oldest) {
        break;
      }
      this.entries.delete(oldest[0]);
      this.bytes -= oldest[1].byteLength;
    }
  }
}

/** Read-only Store backed by the shared IndexedDB/Blossom/FIPS worker mesh. */
export class WorkerBlockStore implements Store {
  private readonly cache: ByteBoundedBlockCache;
  private readonly pending = new Map<string, Promise<Uint8Array | null>>();
  private readonly loadBlock: (expectedHashHex: string) => Promise<Uint8Array | null>;

  constructor(options: WorkerBlockStoreOptions = {}) {
    const maxCacheBytes = options.maxCacheBytes ?? DEFAULT_WORKER_BLOCK_CACHE_MAX_BYTES;
    if (!Number.isSafeInteger(maxCacheBytes) || maxCacheBytes < 0) {
      throw new Error('Worker block cache limit must be a non-negative safe integer');
    }
    this.cache = new ByteBoundedBlockCache(maxCacheBytes);
    this.loadBlock = options.loadBlock ?? loadVerifiedWorkerBlock;
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    const hex = toHex(hash);
    const cached = this.cache.get(hex);
    if (cached) {
      return cached.slice();
    }
    const inflight = this.pending.get(hex);
    if (inflight) {
      return (await inflight)?.slice() ?? null;
    }
    const request = this.loadBlock(hex)
      .then((data) => {
        if (data) {
          this.cache.set(hex, data.slice());
        }
        return data?.slice() ?? null;
      })
      .finally(() => this.pending.delete(hex));
    this.pending.set(hex, request);
    return (await request)?.slice() ?? null;
  }

  async has(hash: Hash): Promise<boolean> {
    return await this.get(hash) !== null;
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('WorkerBlockStore is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('WorkerBlockStore is read-only');
  }
}

async function loadVerifiedWorkerBlock(expectedHashHex: string): Promise<Uint8Array | null> {
  try {
    const { getWorkerClient } = await import('./workerClient');
    const { data } = await (await getWorkerClient()).getBlob(expectedHashHex);
    // Hashtree's worker mesh verifies every primary and remote response
    // against expectedHashHex before returning it. Avoid hashing the same
    // block again on the UI thread during feed/profile traversal.
    return data.slice();
  } catch {
    return null;
  }
}
let sharedWorkerBlockStore: WorkerBlockStore | null = null;

export function createWorkerBlockStore(): WorkerBlockStore {
  sharedWorkerBlockStore ??= new WorkerBlockStore();
  return sharedWorkerBlockStore;
}

export function createWorkerTree(): HashTree {
  return new HashTree({ store: createWorkerBlockStore() });
}


export async function resolveImmutableRoot(nhash: string, path = ''): Promise<CID | null> {
  const tree = createWorkerTree();
  const rootCid = nhashDecode(nhash);
  if (!path) {
    return rootCid;
  }
  return (await tree.resolvePath(rootCid, path))?.cid ?? null;
}
