import { validateEvent, verifyEvent, type Event } from 'nostr-tools/pure';
import { verifyIndexedEvents } from './fastEventVerification';
import { parseBolt11Millisats } from './bolt11';
import type { RawEvent } from './nostr';

export const ZAP_REQUEST_KIND = 9_734;
export const ZAP_RECEIPT_KIND = 9_735;

const HEX_64 = /^[0-9a-f]{64}$/;
const MAX_CACHED_ZAP_VERIFICATIONS = 4_096;
const verifiedZapEvents = new Map<string, boolean>();
let pendingZapAdmission: Promise<boolean> | null = null;

export type ZapReceiptTarget = {
  eventId?: string | null;
  address?: string | null;
  recipientPubkey?: string | null;
};

export type ValidatedZapReceipt = {
  receipt: RawEvent;
  request: RawEvent;
  amountMillisats: number;
  bits: number;
  recipientPubkey: string;
  senderPubkey: string;
  targetEventId: string | null;
  targetAddress: string | null;
};

function cloneEvent(event: RawEvent): Event {
  return {
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

function isVerifiedEvent(event: RawEvent): boolean {
  const key = verificationKey(event);
  if (typeof window !== 'undefined') {
    return verifiedZapEvents.get(key) === true;
  }
  const candidate = cloneEvent(event);
  return validateEvent(candidate) && verifyEvent(candidate);
}

function verificationKey(event: RawEvent): string {
  return `${event.id}:${event.sig}`;
}

function rememberVerification(event: RawEvent, valid: boolean): void {
  const key = verificationKey(event);
  verifiedZapEvents.delete(key);
  verifiedZapEvents.set(key, valid);
  while (verifiedZapEvents.size > MAX_CACHED_ZAP_VERIFICATIONS) {
    const oldest = verifiedZapEvents.keys().next().value as string | undefined;
    if (!oldest) {break;}
    verifiedZapEvents.delete(oldest);
  }
}

function asRawEvent(value: unknown): RawEvent | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  const event = value as Partial<RawEvent>;
  if (
    typeof event.id !== 'string'
    || typeof event.pubkey !== 'string'
    || typeof event.created_at !== 'number'
    || typeof event.kind !== 'number'
    || !Array.isArray(event.tags)
    || !event.tags.every((tag) => (
      Array.isArray(tag) && tag.every((part) => typeof part === 'string')
    ))
    || typeof event.content !== 'string'
    || typeof event.sig !== 'string'
  ) {
    return null;
  }
  return event as RawEvent;
}

/**
 * Admit receipt/request signatures before synchronous engagement projection.
 * Browser verification is delegated to the shared worker by verifyIndexedEvents.
 */
export async function admitZapReceiptEvents(
  receipts: readonly RawEvent[],
  verify: (events: Event[]) => Promise<boolean[]> = verifyIndexedEvents,
): Promise<boolean> {
  if (pendingZapAdmission) {
    const previousChanged = await pendingZapAdmission;
    return (await admitZapReceiptEvents(receipts, verify)) || previousChanged;
  }
  pendingZapAdmission = admitZapReceiptEventsNow(receipts, verify);
  try {
    return await pendingZapAdmission;
  } finally {
    pendingZapAdmission = null;
  }
}

async function admitZapReceiptEventsNow(
  receipts: readonly RawEvent[],
  verify: (events: Event[]) => Promise<boolean[]>,
): Promise<boolean> {
  const candidates: RawEvent[] = [];
  for (const receipt of receipts) {
    if (receipt.kind !== ZAP_RECEIPT_KIND || verifiedZapEvents.has(verificationKey(receipt))) {
      continue;
    }
    candidates.push(receipt);
    const description = receipt.tags.find((tag) => tag[0] === 'description')?.[1];
    if (description) {
      try {
        const request = asRawEvent(JSON.parse(description));
        if (request && request.kind === ZAP_REQUEST_KIND && !verifiedZapEvents.has(verificationKey(request))) {
          candidates.push(request);
        }
      } catch {
        // The structural validator will reject this receipt after admission.
      }
    }
  }
  if (candidates.length === 0) {
    return false;
  }
  for (let index = 0; index < candidates.length; index += 256) {
    const batch = candidates.slice(index, index + 256);
    const valid = await verify(batch);
    if (valid.length !== batch.length) {
      throw new Error('Zap verifier returned an invalid result count');
    }
    for (let batchIndex = 0; batchIndex < batch.length; batchIndex += 1) {
      rememberVerification(batch[batchIndex]!, valid[batchIndex] === true);
    }
  }
  return true;
}

function tagsNamed(event: RawEvent, name: string): string[][] {
  return event.tags.filter((tag) => tag[0] === name);
}

function uniqueTagValue(
  event: RawEvent,
  name: string,
  required: boolean,
): string | null | undefined {
  const tags = tagsNamed(event, name);
  if (tags.length > 1 || (required && tags.length !== 1)) {
    return undefined;
  }
  if (tags.length === 0) {
    return null;
  }
  const value = tags[0]?.[1];
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function parsePositiveInteger(value: string): number | null {
  if (!/^\d+$/.test(value)) {
    return null;
  }
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

function isRelayUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return (url.protocol === 'ws:' || url.protocol === 'wss:') && Boolean(url.hostname);
  } catch {
    return false;
  }
}

function parseAddress(value: string): { kind: number; pubkey: string; identifier: string } | null {
  const firstSeparator = value.indexOf(':');
  const secondSeparator = value.indexOf(':', firstSeparator + 1);
  if (firstSeparator <= 0 || secondSeparator <= firstSeparator + 1) {
    return null;
  }
  const kind = Number(value.slice(0, firstSeparator));
  const pubkey = value.slice(firstSeparator + 1, secondSeparator);
  if (!Number.isInteger(kind) || kind < 0 || !HEX_64.test(pubkey)) {
    return null;
  }
  return {
    kind,
    pubkey,
    identifier: value.slice(secondSeparator + 1),
  };
}

function normalizeHex(value: string | null | undefined): string | null {
  const normalized = value?.trim().toLowerCase() ?? '';
  return HEX_64.test(normalized) ? normalized : null;
}

/**
 * Validates the locally provable parts of a NIP-57 receipt: receipt/request
 * signatures and structure, copied target tags, relay declarations, optional
 * target constraints, and the BOLT11/request amount. Full Appendix-F provider
 * authorization additionally requires a trusted LNURL provider nostrPubkey;
 * this offline projection deliberately does not claim or infer that trust.
 */
export function validateZapReceipt(
  receipt: RawEvent,
  target: ZapReceiptTarget = {},
): ValidatedZapReceipt | null {
  if (receipt.kind !== ZAP_RECEIPT_KIND || !isVerifiedEvent(receipt)) {
    return null;
  }

  const description = uniqueTagValue(receipt, 'description', true);
  const invoice = uniqueTagValue(receipt, 'bolt11', true);
  const receiptRecipient = uniqueTagValue(receipt, 'p', true);
  const receiptSender = uniqueTagValue(receipt, 'P', false);
  const receiptEventId = uniqueTagValue(receipt, 'e', false);
  const receiptAddress = uniqueTagValue(receipt, 'a', false);
  if (
    !description
    || !invoice
    || !receiptRecipient
    || receiptSender === undefined
    || receiptEventId === undefined
    || receiptAddress === undefined
    || !HEX_64.test(receiptRecipient)
    || (receiptSender !== null && !HEX_64.test(receiptSender))
    || (receiptEventId !== null && !HEX_64.test(receiptEventId))
    || (receiptAddress !== null && !parseAddress(receiptAddress))
  ) {
    return null;
  }

  let parsedRequest: unknown;
  try {
    parsedRequest = JSON.parse(description);
  } catch {
    return null;
  }
  const request = asRawEvent(parsedRequest);
  if (!request || request.kind !== ZAP_REQUEST_KIND || !isVerifiedEvent(request)) {
    return null;
  }

  const requestRecipient = uniqueTagValue(request, 'p', true);
  const requestRelays = tagsNamed(request, 'relays');
  const requestAmount = uniqueTagValue(request, 'amount', false);
  const requestEventId = uniqueTagValue(request, 'e', false);
  const requestAddress = uniqueTagValue(request, 'a', false);
  const requestProvider = uniqueTagValue(request, 'P', false);
  if (
    !requestRecipient
    || !HEX_64.test(requestRecipient)
    || requestRelays.length !== 1
    || requestRelays[0]!.length < 2
    || !requestRelays[0]!.slice(1).every(isRelayUrl)
    || requestAmount === undefined
    || requestEventId === undefined
    || requestAddress === undefined
    || requestProvider === undefined
    || (requestEventId !== null && !HEX_64.test(requestEventId))
    || (requestAddress !== null && !parseAddress(requestAddress))
    || (requestProvider !== null && !HEX_64.test(requestProvider))
  ) {
    return null;
  }

  const amountMillisats = parseBolt11Millisats(invoice);
  if (!amountMillisats) {
    return null;
  }
  if (requestAmount !== null && parsePositiveInteger(requestAmount) !== amountMillisats) {
    return null;
  }

  const requestSender = normalizeHex(request.pubkey);
  const receiptProvider = normalizeHex(receipt.pubkey);
  if (
    !requestSender
    || !receiptProvider
    || receiptRecipient !== requestRecipient
    || (receiptSender !== null && receiptSender !== requestSender)
    || (requestProvider !== null && requestProvider !== receiptProvider)
    || receiptEventId !== requestEventId
    || receiptAddress !== requestAddress
  ) {
    return null;
  }

  const hasTargetEventId = target.eventId !== null && target.eventId !== undefined;
  const hasTargetAddress = target.address !== null && target.address !== undefined;
  const hasTargetRecipient = target.recipientPubkey !== null && target.recipientPubkey !== undefined;
  const targetEventId = !hasTargetEventId
    ? null
    : normalizeHex(target.eventId);
  const targetRecipient = !hasTargetRecipient
    ? null
    : normalizeHex(target.recipientPubkey);
  if (
    (hasTargetEventId && (!targetEventId || requestEventId !== targetEventId))
    || (hasTargetAddress && requestAddress !== target.address)
    || (hasTargetRecipient && (!targetRecipient || requestRecipient !== targetRecipient))
  ) {
    return null;
  }

  return {
    receipt,
    request,
    amountMillisats,
    bits: Math.floor(amountMillisats / 1_000),
    recipientPubkey: requestRecipient,
    senderPubkey: requestSender,
    targetEventId: requestEventId,
    targetAddress: requestAddress,
  };
}

export function getValidatedZapBits(event: RawEvent, target: ZapReceiptTarget = {}): number {
  return validateZapReceipt(event, target)?.bits ?? 0;
}
