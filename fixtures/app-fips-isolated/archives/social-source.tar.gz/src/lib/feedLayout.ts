export const FEED_LAYOUTS = ['cozy', 'compact'] as const;

export type FeedLayout = typeof FEED_LAYOUTS[number];

export const DEFAULT_FEED_LAYOUT: FeedLayout = 'cozy';

export function normalizeFeedLayout(value: unknown): FeedLayout {
  return FEED_LAYOUTS.includes(value as FeedLayout) ? value as FeedLayout : DEFAULT_FEED_LAYOUT;
}
