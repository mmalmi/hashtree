import { readable, readonly, writable } from 'svelte/store';
import type { RelaySocketRow, RelaySocketState } from '../workers/relayConnectionMonitor';

export type PeerNetworkStatus = 'starting' | 'ready' | 'unavailable' | 'unsupported' | 'stopped';
const currentPeers = writable<{ status: PeerNetworkStatus; peers: string[] }>({ status: 'stopped', peers: [] });
const currentRelays = writable<ReadonlyMap<string, RelaySocketState> | null>(null);
export const peerNetwork = readonly(currentPeers);
export const relayConnections = readonly(currentRelays);
export const updatePeerNetwork = currentPeers.set;
export function updateRelayConnections(rows: RelaySocketRow[] | null): void {
  currentRelays.set(rows && new Map(rows.map(row => [row.url, row.state])));
}

export const browserOnline = readable(true, set => {
  if (typeof window === 'undefined') { return; }
  const sync = () => set(navigator.onLine);
  sync();
  window.addEventListener('online', sync);
  window.addEventListener('offline', sync);
  return () => { window.removeEventListener('online', sync); window.removeEventListener('offline', sync); };
});
