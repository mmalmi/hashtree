import { isHashtreeObjectKey } from './hashtreeObjectKey';
import {
  LinkType,
  decodeTreeNode,
  encodeTreeNode,
  nhashDecode,
  nhashEncode,
  sha256,
  type CID,
  type Link,
  type Store,
} from '@hashtree/core';
import {
  POST_SEARCH_V5_PACKED_PAGE_FORMAT,
  type PostSearchV5PackedPageKind,
} from '../server/postSearchV5PackedPage';
import {
  POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
  openPostSearchV5PageRouter,
  type PostSearchV5PageRouter,
} from '../server/postSearchV5PageRouter';

export const SOCIAL_RELATIONSHIP_CATALOG_FORMAT =
  'iris-social/social-relationship-catalog@1' as const;
export const SOCIAL_RELATIONSHIP_WINNER_POLICY =
  'verified-created-at-desc-event-id-asc@1' as const;
export const SOCIAL_RELATIONSHIP_DELETION_POLICY =
  'verified-author-bound-kind3-kind10000@1' as const;
export const SOCIAL_RELATIONSHIP_MUTE_POLICY =
  'author-mute-removes-author-forward-edge@1' as const;
export const SOCIAL_RELATIONSHIP_ELIGIBILITY_POLICY =
  'both-edge-endpoints-eligible@1' as const;
export const SOCIAL_RELATIONSHIP_MAX_PAGE_LIMIT = 500;

const MANIFEST_ENTRY = 'manifest.json';
const FOLLOWING_ENTRY = 'following';
const FOLLOWERS_ENTRY = 'followers';
const COUNTS_ENTRY = 'counts';
const ROOT_MAX_BYTES = 65_536;
const MANIFEST_MAX_BYTES = 256 * 1_024;
const HEX_64 = /^[0-9a-f]{64}$/;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export interface SocialRelationshipCatalogCounts {
  eligibleAuthors: number;
  contactWinners: number;
  muteWinners: number;
  deletionEvents: number;
  invalidEvents: number;
  deletedWinners: number;
  rawFollowEdges: number;
  rawMuteEdges: number;
  excludedByMute: number;
  excludedIneligible: number;
  relationshipEdges: number;
  countEntries: number;
}

export interface SocialRelationshipBranchManifest {
  entry: string;
  root: string;
  pageKind: PostSearchV5PackedPageKind;
  entryCount: number;
  minKey: string;
  maxKey: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
}

export interface SocialRelationshipCatalogManifest {
  format: typeof SOCIAL_RELATIONSHIP_CATALOG_FORMAT;
  generatedAt: number;
  sourceRoot: string;
  eligiblePubkeysSha256: string;
  compatibility: {
    packedPageFormat: typeof POST_SEARCH_V5_PACKED_PAGE_FORMAT;
    pageRouterFormat: typeof POST_SEARCH_V5_PAGE_ROUTER_FORMAT;
    winnerPolicy: typeof SOCIAL_RELATIONSHIP_WINNER_POLICY;
    deletionPolicy: typeof SOCIAL_RELATIONSHIP_DELETION_POLICY;
    mutePolicy: typeof SOCIAL_RELATIONSHIP_MUTE_POLICY;
    eligibilityPolicy: typeof SOCIAL_RELATIONSHIP_ELIGIBILITY_POLICY;
  };
  counts: SocialRelationshipCatalogCounts;
  edgeFingerprint: {
    xorSha256: string;
    sumSha256: string;
  };
  branches: {
    following: SocialRelationshipBranchManifest;
    followers: SocialRelationshipBranchManifest;
    counts: SocialRelationshipBranchManifest;
  };
  reachableNodeCount: number;
}

export interface SocialRelationshipPage {
  items: string[];
  nextCursor: string | null;
  total: number;
}

export interface SocialRelationshipCounts {
  follows: number;
  followers: number;
}

export interface SocialRelationshipMetrics extends SocialRelationshipCounts {
  followedByFriends: number;
}

export interface SocialRelationshipCatalogLookup {
  root: CID;
  manifest: SocialRelationshipCatalogManifest;
  getCounts(pubkey: string): Promise<SocialRelationshipCounts>;
  getFollows(pubkey: string, options?: { limit?: number; cursor?: string | null }): Promise<SocialRelationshipPage>;
  getFollowers(pubkey: string, options?: { limit?: number; cursor?: string | null }): Promise<SocialRelationshipPage>;
  hasFollow(author: string, target: string): Promise<boolean>;
  countFollowersInSet(
    pubkey: string,
    candidates: ReadonlySet<string>,
    cap?: number,
  ): Promise<number>;
  getRelationshipMetrics(
    pubkey: string,
    viewerFollows: ReadonlySet<string>,
    friendCap?: number,
  ): Promise<SocialRelationshipMetrics>;
  streamFollows(): AsyncGenerator<{ author: string; target: string }>;
  streamFollowers(): AsyncGenerator<{ author: string; target: string }>;
  streamCounts(): AsyncGenerator<{ pubkey: string; follows: number; followers: number }>;
  /** Internal authenticated routers exposed for the server-side full verifier. */
  readonlyRouters: {
    following: PostSearchV5PageRouter;
    followers: PostSearchV5PageRouter;
    counts: PostSearchV5PageRouter;
  };
}

interface SocialRelationshipCatalogEnvelope {
  root: CID;
  manifest: SocialRelationshipCatalogManifest;
  roots: { following: CID; followers: CID; counts: CID };
}

export async function openSocialRelationshipCatalog(
  store: Store,
  root: CID,
  options: {
    expectedSourceRoot?: CID;
    expectedEligiblePubkeysSha256?: string;
  } = {},
): Promise<SocialRelationshipCatalogLookup> {
  const envelope = await readEnvelope(store, root);
  if (options.expectedSourceRoot
    && envelope.manifest.sourceRoot !== nhashEncode(
      sourceIdentityCid(options.expectedSourceRoot, 'sourceRoot'),
    )) {
    throw new Error('Social relationship catalog sourceRoot does not match');
  }
  if (options.expectedEligiblePubkeysSha256
    && envelope.manifest.eligiblePubkeysSha256 !== strictSha256(
      options.expectedEligiblePubkeysSha256,
      'expectedEligiblePubkeysSha256',
    )) {
    throw new Error('Social relationship catalog eligibility digest does not match');
  }
  const [following, followers, counts] = await Promise.all([
    openPostSearchV5PageRouter(store, envelope.roots.following, envelope.manifest.branches.following),
    openPostSearchV5PageRouter(store, envelope.roots.followers, envelope.manifest.branches.followers),
    openPostSearchV5PageRouter(store, envelope.roots.counts, envelope.manifest.branches.counts),
  ]);
  const getCounts = async (rawPubkey: string): Promise<SocialRelationshipCounts> => {
    const pubkey = strictPubkey(rawPubkey, 'counts pubkey');
    const routed = await counts.lookupPage(pubkey);
    const value = routed?.page.entries.find(([key]) => key === pubkey)?.[1];
    return value === undefined ? { follows: 0, followers: 0 } : parseCountsValue(value);
  };
  const getPage = async (
    router: PostSearchV5PageRouter,
    rawPubkey: string,
    rawOptions: { limit?: number; cursor?: string | null },
    direction: 'following' | 'followers',
  ): Promise<SocialRelationshipPage> => {
    const pubkey = strictPubkey(rawPubkey, `${direction} pubkey`);
    const cursor = rawOptions.cursor === null || rawOptions.cursor === undefined
      ? null
      : strictPubkey(rawOptions.cursor, `${direction} cursor`);
    const limit = boundedInteger(
      rawOptions.limit ?? 120,
      1,
      SOCIAL_RELATIONSHIP_MAX_PAGE_LIMIT,
      `${direction} limit`,
    );
    const prefix = `${pubkey}:`;
    const minimum = cursor ? `${prefix}${cursor}` : `${prefix}${'0'.repeat(64)}`;
    const maximum = `${prefix}${'f'.repeat(64)}`;
    const items: string[] = [];
    for await (const routed of router.rangePages(minimum, maximum)) {
      for (const [key] of routed.page.entries) {
        if (key < minimum || key > maximum || !key.startsWith(prefix)) {continue;}
        const item = key.slice(prefix.length);
        strictPubkey(item, `${direction} item`);
        if (cursor && item <= cursor) {continue;}
        items.push(item);
        if (items.length > limit) {break;}
      }
      if (items.length > limit) {break;}
    }
    const hasMore = items.length > limit;
    if (hasMore) {items.length = limit;}
    const totalCounts = await getCounts(pubkey);
    return {
      items,
      nextCursor: hasMore ? items.at(-1) ?? null : null,
      total: direction === 'following' ? totalCounts.follows : totalCounts.followers,
    };
  };
  const stream = async function* (
    router: PostSearchV5PageRouter,
    inverse: boolean,
  ): AsyncGenerator<{ author: string; target: string }> {
    for await (const routed of router.rangePages(router.minKey, router.maxKey)) {
      for (const [key, value] of routed.page.entries) {
        if (value !== '') {throw new Error('Social relationship edge value must be empty');}
        const edge = parseEdgeKey(key);
        yield inverse
          ? { author: edge.target, target: edge.author }
          : edge;
      }
    }
  };
  const countFollowersInSet = async (
    rawPubkey: string,
    candidates: ReadonlySet<string>,
    rawCap = 50,
  ): Promise<number> => {
    const pubkey = strictPubkey(rawPubkey, 'follower intersection pubkey');
    const cap = boundedInteger(rawCap, 1, 10_000, 'follower intersection cap');
    let count = 0;
    const minimum = `${pubkey}:${'0'.repeat(64)}`;
    const maximum = `${pubkey}:${'f'.repeat(64)}`;
    for await (const routed of followers.rangePages(minimum, maximum)) {
      for (const [key] of routed.page.entries) {
        if (key < minimum || key > maximum) {continue;}
        const follower = parseEdgeKey(key).target;
        if (candidates.has(follower)) {
          count += 1;
          if (count >= cap) {return cap;}
        }
      }
    }
    return count;
  };
  return {
    root: envelope.root,
    manifest: envelope.manifest,
    getCounts,
    getFollows: async (pubkey, pageOptions = {}) =>
      await getPage(following, pubkey, pageOptions, 'following'),
    getFollowers: async (pubkey, pageOptions = {}) =>
      await getPage(followers, pubkey, pageOptions, 'followers'),
    hasFollow: async (rawAuthor, rawTarget) => {
      const key = relationshipEdgeKey(rawAuthor, rawTarget);
      const routed = await following.lookupPage(key);
      return Boolean(routed?.page.entries.some(([candidate, value]) =>
        candidate === key && value === ''));
    },
    countFollowersInSet,
    getRelationshipMetrics: async (pubkey, viewerFollows, friendCap = 50) => {
      const [countsValue, followedByFriends] = await Promise.all([
        getCounts(pubkey),
        countFollowersInSet(pubkey, viewerFollows, friendCap),
      ]);
      return { ...countsValue, followedByFriends };
    },
    streamFollows: () => stream(following, false),
    streamFollowers: () => stream(followers, true),
    streamCounts: async function* () {
      for await (const routed of counts.rangePages(counts.minKey, counts.maxKey)) {
        for (const [pubkey, value] of routed.page.entries) {
          strictPubkey(pubkey, 'count entry pubkey');
          yield { pubkey, ...parseCountsValue(value) };
        }
      }
    },
    readonlyRouters: { following, followers, counts },
  };
}

export function relationshipEdgeKey(rawAuthor: string, rawTarget: string): string {
  return `${strictPubkey(rawAuthor, 'edge author')}:${strictPubkey(rawTarget, 'edge target')}`;
}

export function parseEdgeKey(key: string): { author: string; target: string } {
  if (key.length !== 129 || key[64] !== ':') {
    throw new Error('Invalid social relationship edge key');
  }
  return {
    author: strictPubkey(key.slice(0, 64), 'edge author'),
    target: strictPubkey(key.slice(65), 'edge target'),
  };
}

export function encodeSocialRelationshipCounts(follows: number, followers: number): string {
  return JSON.stringify([
    nonNegativeInteger(follows, 'follows count'),
    nonNegativeInteger(followers, 'followers count'),
  ]);
}

export function parseCountsValue(value: string): SocialRelationshipCounts {
  let parsed: unknown;
  try {parsed = JSON.parse(value);} catch {
    throw new Error('Invalid social relationship counts JSON');
  }
  if (!Array.isArray(parsed) || parsed.length !== 2) {
    throw new Error('Invalid social relationship counts value');
  }
  const result = {
    follows: nonNegativeInteger(parsed[0], 'follows count'),
    followers: nonNegativeInteger(parsed[1], 'followers count'),
  };
  if (encodeSocialRelationshipCounts(result.follows, result.followers) !== value) {
    throw new Error('Noncanonical social relationship counts value');
  }
  return result;
}

async function readEnvelope(store: Store, rawRoot: CID): Promise<SocialRelationshipCatalogEnvelope> {
  const root = publicCid(rawRoot, 'catalog root');
  const rootBytes = await readPublicBlock(store, root, ROOT_MAX_BYTES, 'catalog root');
  let node;
  try {node = decodeTreeNode(rootBytes);} catch {
    throw new Error('Social relationship catalog root is not a directory');
  }
  if (node.type !== LinkType.Dir || !equalBytes(rootBytes, encodeTreeNode(node))) {
    throw new Error('Social relationship catalog root is not canonical');
  }
  node.links.forEach(assertCanonicalLink);
  const manifestLink = node.links.find((link) => link.name === MANIFEST_ENTRY);
  if (!manifestLink || manifestLink.type !== LinkType.Blob) {
    throw new Error('Social relationship catalog manifest is missing');
  }
  const manifestBytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    MANIFEST_MAX_BYTES,
    'catalog manifest',
  );
  if (manifestBytes.length !== manifestLink.size) {
    throw new Error('Social relationship catalog manifest size is inconsistent');
  }
  const manifest = parseManifest(manifestBytes);
  const expectedNames = [MANIFEST_ENTRY, FOLLOWING_ENTRY, FOLLOWERS_ENTRY, COUNTS_ENTRY].sort();
  const actualNames = node.links.map((link) => link.name).sort();
  if (JSON.stringify(expectedNames) !== JSON.stringify(actualNames)) {
    throw new Error('Social relationship catalog root has unbound links');
  }
  const branchRoot = (branch: SocialRelationshipBranchManifest): CID => {
    const link = node.links.find((candidate) => candidate.name === branch.entry);
    const declared = publicNhash(branch.root, `${branch.entry} root`);
    if (!link || link.type !== LinkType.Dir || link.size !== branch.reachableNodeCount
      || !equalBytes(link.hash, declared.hash)) {
      throw new Error(`Social relationship branch link is inconsistent: ${branch.entry}`);
    }
    return declared;
  };
  return {
    root,
    manifest,
    roots: {
      following: branchRoot(manifest.branches.following),
      followers: branchRoot(manifest.branches.followers),
      counts: branchRoot(manifest.branches.counts),
    },
  };
}

function parseManifest(bytes: Uint8Array): SocialRelationshipCatalogManifest {
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {
    throw new Error('Invalid social relationship catalog manifest JSON');
  }
  const raw = record(value, 'catalog manifest');
  exactKeys(raw, [
    'format', 'generatedAt', 'sourceRoot', 'eligiblePubkeysSha256', 'compatibility',
    'counts', 'edgeFingerprint', 'branches', 'reachableNodeCount',
  ], 'catalog manifest');
  const compatibility = record(raw.compatibility, 'compatibility');
  exactKeys(compatibility, [
    'packedPageFormat', 'pageRouterFormat', 'winnerPolicy', 'deletionPolicy',
    'mutePolicy', 'eligibilityPolicy',
  ], 'compatibility');
  if (raw.format !== SOCIAL_RELATIONSHIP_CATALOG_FORMAT
    || compatibility.packedPageFormat !== POST_SEARCH_V5_PACKED_PAGE_FORMAT
    || compatibility.pageRouterFormat !== POST_SEARCH_V5_PAGE_ROUTER_FORMAT
    || compatibility.winnerPolicy !== SOCIAL_RELATIONSHIP_WINNER_POLICY
    || compatibility.deletionPolicy !== SOCIAL_RELATIONSHIP_DELETION_POLICY
    || compatibility.mutePolicy !== SOCIAL_RELATIONSHIP_MUTE_POLICY
    || compatibility.eligibilityPolicy !== SOCIAL_RELATIONSHIP_ELIGIBILITY_POLICY) {
    throw new Error('Unsupported social relationship catalog manifest');
  }
  const countsRaw = record(raw.counts, 'counts');
  const countKeys = [
    'eligibleAuthors', 'contactWinners', 'muteWinners', 'deletionEvents', 'invalidEvents',
    'deletedWinners', 'rawFollowEdges', 'rawMuteEdges', 'excludedByMute',
    'excludedIneligible', 'relationshipEdges', 'countEntries',
  ];
  exactKeys(countsRaw, countKeys, 'counts');
  const counts = Object.fromEntries(countKeys.map((key) => [
    key,
    nonNegativeInteger(countsRaw[key], key),
  ])) as unknown as SocialRelationshipCatalogCounts;
  const fingerprint = record(raw.edgeFingerprint, 'edgeFingerprint');
  exactKeys(fingerprint, ['xorSha256', 'sumSha256'], 'edgeFingerprint');
  const branchesRaw = record(raw.branches, 'branches');
  exactKeys(branchesRaw, ['following', 'followers', 'counts'], 'branches');
  const branches = {
    following: parseBranch(branchesRaw.following, FOLLOWING_ENTRY, 'postings'),
    followers: parseBranch(branchesRaw.followers, FOLLOWERS_ENTRY, 'postings'),
    counts: parseBranch(branchesRaw.counts, COUNTS_ENTRY, 'documents'),
  };
  if (branches.following.entryCount !== counts.relationshipEdges
    || branches.followers.entryCount !== counts.relationshipEdges
    || branches.counts.entryCount !== counts.countEntries) {
    throw new Error('Social relationship catalog branch counts are inconsistent');
  }
  const reachableNodeCount = nonNegativeInteger(raw.reachableNodeCount, 'reachableNodeCount');
  const expectedReachability = 2 + branches.following.reachableNodeCount
    + branches.followers.reachableNodeCount + branches.counts.reachableNodeCount;
  if (reachableNodeCount !== expectedReachability) {
    throw new Error('Social relationship catalog reachability is inconsistent');
  }
  const manifest: SocialRelationshipCatalogManifest = {
    format: SOCIAL_RELATIONSHIP_CATALOG_FORMAT,
    generatedAt: nonNegativeInteger(raw.generatedAt, 'generatedAt'),
    sourceRoot: nhashEncode(publicNhash(raw.sourceRoot, 'sourceRoot')),
    eligiblePubkeysSha256: strictSha256(raw.eligiblePubkeysSha256, 'eligiblePubkeysSha256'),
    compatibility: {
      packedPageFormat: POST_SEARCH_V5_PACKED_PAGE_FORMAT,
      pageRouterFormat: POST_SEARCH_V5_PAGE_ROUTER_FORMAT,
      winnerPolicy: SOCIAL_RELATIONSHIP_WINNER_POLICY,
      deletionPolicy: SOCIAL_RELATIONSHIP_DELETION_POLICY,
      mutePolicy: SOCIAL_RELATIONSHIP_MUTE_POLICY,
      eligibilityPolicy: SOCIAL_RELATIONSHIP_ELIGIBILITY_POLICY,
    },
    counts,
    edgeFingerprint: {
      xorSha256: strictSha256(fingerprint.xorSha256, 'xorSha256'),
      sumSha256: strictSha256(fingerprint.sumSha256, 'sumSha256'),
    },
    branches,
    reachableNodeCount,
  };
  if (!equalBytes(bytes, encoder.encode(JSON.stringify(manifest)))) {
    throw new Error('Social relationship catalog manifest is not canonical');
  }
  return manifest;
}

function parseBranch(
  value: unknown,
  expectedEntry: string,
  expectedKind: PostSearchV5PackedPageKind,
): SocialRelationshipBranchManifest {
  const raw = record(value, `${expectedEntry} branch`);
  exactKeys(raw, [
    'entry', 'root', 'pageKind', 'entryCount', 'minKey', 'maxKey', 'height',
    'pageCount', 'routerNodeCount', 'reachableNodeCount',
  ], `${expectedEntry} branch`);
  if (raw.entry !== expectedEntry || raw.pageKind !== expectedKind) {
    throw new Error(`Invalid social relationship ${expectedEntry} branch`);
  }
  return {
    entry: expectedEntry,
    root: nhashEncode(publicNhash(raw.root, `${expectedEntry} root`)),
    pageKind: expectedKind,
    entryCount: positiveInteger(raw.entryCount, `${expectedEntry} entryCount`),
    minKey: nonEmptyString(raw.minKey, `${expectedEntry} minKey`),
    maxKey: nonEmptyString(raw.maxKey, `${expectedEntry} maxKey`),
    height: nonNegativeInteger(raw.height, `${expectedEntry} height`),
    pageCount: positiveInteger(raw.pageCount, `${expectedEntry} pageCount`),
    routerNodeCount: positiveInteger(raw.routerNodeCount, `${expectedEntry} routerNodeCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `${expectedEntry} reachableNodeCount`),
  };
}

async function readPublicBlock(
  store: Store,
  cid: CID,
  maximum: number,
  label: string,
): Promise<Uint8Array> {
  publicCid(cid, label);
  const bytes = await store.get(cid.hash);
  if (!bytes || bytes.length > maximum || !equalBytes(await sha256(bytes), cid.hash)) {
    throw new Error(`Missing, oversized, or corrupt social relationship ${label}`);
  }
  return bytes;
}

function publicCid(cid: CID, label: string): CID {
  if (!(cid?.hash instanceof Uint8Array) || cid.hash.length !== 32 || cid.key !== undefined) {
    throw new Error(`Invalid public social relationship ${label}`);
  }
  return { hash: new Uint8Array(cid.hash) };
}

function sourceIdentityCid(cid: CID, label: string): CID {
  if (!(cid?.hash instanceof Uint8Array) || cid.hash.length !== 32
    || (cid.key !== undefined
      && !isHashtreeObjectKey(cid.key))) {
    throw new Error(`Invalid immutable social relationship ${label}`);
  }
  return { hash: new Uint8Array(cid.hash) };
}

function publicNhash(value: unknown, label: string): CID {
  if (typeof value !== 'string') {throw new Error(`Invalid ${label}`);}
  let cid: CID;
  try {cid = nhashDecode(value);} catch {throw new Error(`Invalid ${label}`);}
  cid = publicCid(cid, label);
  if (nhashEncode(cid) !== value) {throw new Error(`Noncanonical ${label}`);}
  return cid;
}

function assertCanonicalLink(link: Link): void {
  if (!link.name || link.name.includes('/') || link.hash.length !== 32
    || !Number.isSafeInteger(link.size) || link.size < 0
    || (link.type !== LinkType.Blob && link.type !== LinkType.Dir)) {
    throw new Error('Invalid social relationship catalog root link');
  }
}

function exactKeys(value: Record<string, unknown>, keys: string[], label: string): void {
  const actual = Object.keys(value).sort();
  const expected = [...keys].sort();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(`Invalid ${label} fields`);
  }
}

function record(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Invalid ${label}`);
  }
  return value as Record<string, unknown>;
}

function nonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || !value) {throw new Error(`Invalid ${label}`);}
  return value;
}

function strictPubkey(value: unknown, label: string): string {
  if (typeof value !== 'string' || !HEX_64.test(value)) {throw new Error(`Invalid ${label}`);}
  return value;
}

function strictSha256(value: unknown, label: string): string {
  if (typeof value !== 'string' || !HEX_64.test(value)) {throw new Error(`Invalid ${label}`);}
  return value;
}

function nonNegativeInteger(value: unknown, label: string): number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {throw new Error(`Invalid ${label}`);}
  return Number(value);
}

function positiveInteger(value: unknown, label: string): number {
  const result = nonNegativeInteger(value, label);
  if (result === 0) {throw new Error(`Invalid ${label}`);}
  return result;
}

function boundedInteger(value: unknown, minimum: number, maximum: number, label: string): number {
  const result = nonNegativeInteger(value, label);
  if (result < minimum || result > maximum) {throw new Error(`Invalid ${label}`);}
  return result;
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) {return false;}
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}
