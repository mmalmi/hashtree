import {
  PERSISTED_DATA_PLANE_STATE_VERSION,
  type PersistedSocialDataPlaneState,
} from './socialDataPlaneSupport';
import type { SocialOverlayPersistenceContext } from './socialOverlayPersistence';
import type { SocialEventRepository } from './socialRepository';

export async function prepareSocialOverlayState(options: {
  repository: SocialEventRepository;
  isProtectedEventId: (eventId: string) => boolean;
  pendingDeliveryEventIds: Iterable<string>;
  context: SocialOverlayPersistenceContext;
}): Promise<PersistedSocialDataPlaneState | null> {
  const repositoryState = await options.repository.exportOverlayStateCooperatively({
    isProtectedEventId: options.isProtectedEventId,
    context: options.context,
  });
  if (!repositoryState || !options.context.isCurrent()) {
    return null;
  }

  const overlayIds = new Set<string>();
  for (const event of repositoryState.overlayEvents) {
    if (!options.context.isCurrent()) {
      return null;
    }
    await options.context.run(() => {
      overlayIds.add(event.id);
    });
  }

  const pendingDeliveryEventIds: string[] = [];
  for (const eventId of options.pendingDeliveryEventIds) {
    if (!options.context.isCurrent()) {
      return null;
    }
    await options.context.run(() => {
      if (overlayIds.has(eventId)) {
        pendingDeliveryEventIds.push(eventId);
      }
    });
  }
  await options.context.run(() => {
    pendingDeliveryEventIds.sort();
  });
  return options.context.isCurrent()
    ? {
        schemaVersion: PERSISTED_DATA_PLANE_STATE_VERSION,
        overlayEvents: repositoryState.overlayEvents,
        pendingDeliveryEventIds,
      }
    : null;
}
