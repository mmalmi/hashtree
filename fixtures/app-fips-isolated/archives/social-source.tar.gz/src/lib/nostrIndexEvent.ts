import type { StoredNostrEvent } from '@hashtree/nostr';
import { verifyEventFast, verifyIndexedEvent } from './fastEventVerification';
import { observeSocialGraphEvent } from './socialGraph';
import type { RawEvent } from './nostr';

export function asRawEvent(
  event: StoredNostrEvent,
  options: { observeSocialGraph?: boolean } = {},
): RawEvent | null {
  try {
    if (!verifyEventFast(event)) {
      return null;
    }
  } catch {
    return null;
  }
  if (options.observeSocialGraph !== false) {
    observeSocialGraphEvent(event);
  }
  return event;
}

/** Convert an event only after a trusted verifier has already accepted it. */
export function asVerifiedRawEvent(
  event: StoredNostrEvent,
  options: { observeSocialGraph?: boolean } = {},
): RawEvent {
  if (options.observeSocialGraph !== false) {
    observeSocialGraphEvent(event);
  }
  return event;
}

/** Verify through the browser worker before converting an indexed event. */
export async function verifyAndAsRawEvent(
  event: StoredNostrEvent,
  options: { observeSocialGraph?: boolean } = {},
): Promise<RawEvent | null> {
  try {
    if (!await verifyIndexedEvent(event)) {
      return null;
    }
    return asVerifiedRawEvent(event, options);
  } catch {
    return null;
  }
}
