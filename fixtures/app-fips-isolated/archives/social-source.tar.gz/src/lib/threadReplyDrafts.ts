import { writable } from 'svelte/store';
import type { ComposerAttachment } from './media';

export const clearedComposerDrafts = writable(new Map<string, number>());
let draftClearSequence = 0;

function notifyDraftCleared(owner: string | null, key: string): void {
  if (!owner) { return; }
  clearedComposerDrafts.update((current) => {
    const next = new Map(current);
    const scope = `${owner}:${key}`;
    next.delete(scope);
    next.set(scope, ++draftClearSequence);
    while (next.size > 256) { next.delete(next.keys().next().value!); }
    return next;
  });
}

export type ThreadReplyDraft = {
  value: string;
  attachments: ComposerAttachment[];
  error: string;
};

function cloneDraft(draft: ThreadReplyDraft): ThreadReplyDraft {
  return {
    value: draft.value,
    attachments: draft.attachments.map((attachment) => ({ ...attachment })),
    error: draft.error,
  };
}

function isEmptyDraft(draft: ThreadReplyDraft): boolean {
  return !draft.value && draft.attachments.length === 0 && !draft.error;
}

export function getBrowserDraftStorage(): Storage | undefined {
  try { return globalThis.localStorage; } catch { return undefined; }
}

function restorableDraft(value: unknown): ThreadReplyDraft | null {
  if (!value || typeof value !== 'object') { return null; }
  const draft = value as Partial<ThreadReplyDraft>;
  if (typeof draft.value !== 'string' || !Array.isArray(draft.attachments)) { return null; }
  const attachments = draft.attachments.filter((item): item is ComposerAttachment => (
    item && typeof item === 'object'
    && typeof item.id === 'string' && typeof item.fileName === 'string'
    && typeof item.mimeType === 'string' && Number.isFinite(item.size)
    && item.status === 'done' && typeof item.url === 'string'
    && /^(https?:\/\/|htree:\/\/)/i.test(item.url)
  )).map((item) => ({ ...item, progress: 1, error: '' }));
  return { value: draft.value, attachments, error: '' };
}

export function createThreadReplyDraftStore(maxEntries = 5, storage?: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>) {
  let drafts = new Map<string, ThreadReplyDraft>();
  let ownerPubkey: string | null = null;
  const storageKey = () => ownerPubkey ? `iris-social:composer-drafts:v1:${ownerPubkey}` : null;
  function persist(): void {
    const key = storageKey();
    if (!storage || !key) { return; }
    try {
      const saved = [...drafts].map(([key, draft]) => [key, restorableDraft(draft)] as const)
        .filter(([, draft]) => draft && !isEmptyDraft(draft));
      if (saved.length) { storage.setItem(key, JSON.stringify(saved)); }
      else { storage.removeItem(key); }
    } catch { /* Keep the in-memory draft when storage is unavailable or full. */ }
  }

  return {
    setOwner(pubkey: string | null): void {
      if (pubkey === ownerPubkey) { return; }
      ownerPubkey = pubkey;
      drafts = new Map();
      const key = storageKey();
      if (!storage || !key) { return; }
      try {
        const saved: unknown = JSON.parse(storage.getItem(key) ?? '[]');
        if (!Array.isArray(saved)) { return; }
        for (const entry of saved.slice(-maxEntries)) {
          if (!Array.isArray(entry) || typeof entry[0] !== 'string') { continue; }
          const draft = restorableDraft(entry[1]);
          if (draft && !isEmptyDraft(draft)) { drafts.set(entry[0], draft); }
        }
      } catch { /* A corrupt draft must not prevent composing. */ }
    },

    read(key: string): ThreadReplyDraft | null {
      const draft = drafts.get(key);
      return draft ? cloneDraft(draft) : null;
    },

    write(key: string, draft: ThreadReplyDraft): void {
      drafts.delete(key);
      if (!isEmptyDraft(draft)) {
        drafts.set(key, cloneDraft(draft));
      }
      while (drafts.size > maxEntries) {
        drafts.delete(drafts.keys().next().value as string);
      }
      persist();
    },

    delete(key: string): void {
      drafts.delete(key);
      persist();
      notifyDraftCleared(ownerPubkey, key);
    },

    retain(keys: Iterable<string>): void {
      const retainedKeys = new Set(keys);
      for (const key of drafts.keys()) {
        if (!retainedKeys.has(key)) {
          drafts.delete(key);
        }
      }
    },

    clear(): void {
      drafts.clear();
      persist();
    },
  };
}
