import {
  canonicalizeThreadReference,
  getEventIdFromReference,
  pubkeyToNpub,
} from './nostr';

export const HOME_HREF = '/';
const HOME_LATEST_HREF = '/#/';
export const HOME_FAVORITES_HREF = '/#/favorites';
export const HOME_MEDIA_HREF = '/#/media';
export const NOTIFICATIONS_HREF = '/#/notifications';
export const SEARCH_HREF = '/#/search';
export const WALLET_HREF = '/#/wallet';
export const ACCOUNTS_HREF = '/#/accounts';
export const SETTINGS_HREF = '/#/settings';

export type HomeTab = 'latest' | 'popular' | 'for-you' | 'favorites' | 'media' | 'notifications';
export type ProfileSection = 'posts' | 'replies' | 'reposts' | 'media' | 'likes' | 'follows' | 'followers';
export type SettingsSection = 'root' | 'profile' | 'iris' | 'notifications' | 'content' | 'appearance' | 'network' | 'media' | 'storage' | 'wallet';

/** Built-in feeds a custom home feed can build on. */
export type CustomFeedBase = 'for-you' | 'latest' | 'favorites';
export const CUSTOM_FEED_BASES: readonly CustomFeedBase[] = ['for-you', 'latest', 'favorites'];
const CUSTOM_FEED_ID = /^[a-z0-9]{4,24}$/;

export function isCustomFeedId(value: string): boolean {
  return CUSTOM_FEED_ID.test(value);
}

export function customFeedHref(base: CustomFeedBase, id: string): string {
  return `/#/feed/${base}/${id}`;
}

export function homeTabHref(tab: HomeTab): string {
  switch (tab) {
    case 'popular':
    case 'for-you':
      return HOME_HREF;
    case 'favorites':
      return HOME_FAVORITES_HREF;
    case 'media':
      return HOME_MEDIA_HREF;
    case 'notifications':
      return NOTIFICATIONS_HREF;
    case 'latest':
    default:
      return HOME_LATEST_HREF;
  }
}

export function profileHref(pubkey: string): string {
  return `/${encodeURIComponent(pubkeyToNpub(pubkey))}`;
}

export function profileSectionHref(pubkey: string, section: ProfileSection): string {
  const base = profileHref(pubkey);
  return section === 'posts' ? base : `${base}/${section}`;
}

function normalizeThreadTarget(target: string): string {
  const eventId = getEventIdFromReference(target);
  if (eventId) {
    return canonicalizeThreadReference(eventId);
  }
  return canonicalizeThreadReference(target);
}

export function threadHref(target: string): string {
  const normalized = normalizeThreadTarget(target);
  return `/${encodeURIComponent(normalized)}`;
}

export function noteHref(target: string): string {
  return threadHref(target);
}

export function noteRefHref(target: string): string {
  return threadHref(target);
}

export function settingsHref(section: SettingsSection = 'root'): string {
  return section === 'root' ? SETTINGS_HREF : `${SETTINGS_HREF}/${section}`;
}

export function searchHref(query?: string, tab?: 'people' | 'posts'): string {
  if (!query && tab !== 'posts') { return SEARCH_HREF; }
  return `${SEARCH_HREF}?${new URLSearchParams({ tab: tab ?? 'people', q: query ?? '' })}`;
}

export function walletHref(): string {
  return WALLET_HREF;
}

export function accountsHref(): string {
  return ACCOUNTS_HREF;
}

export function notificationsHref(): string {
  return NOTIFICATIONS_HREF;
}
