import type { CID } from '@hashtree/core';
import { awaitWithin } from './feedIndexTiming';
import { mergeUniqueFeedNotes, mixHomeFeedPage } from './homeFeedPagination';
import { getAddressableEventCoordinate, isHexPubkey, isReplyEvent, type ProfileRecord, type RawEvent } from './nostr';
import type { FeedSnapshot } from './nostrIndexTypes';

const SPARSE_DISCOVERY_MAX_FOLLOWS = 3;
const SPARSE_DISCOVERY_MAX_AUTHORS = 8;
const SPARSE_DISCOVERY_BRANCH_LIMIT = 32;
const SPARSE_DISCOVERY_AUTHOR_POST_LIMIT = 8;
const SPARSE_DISCOVERY_MAX_ORIGINALS_PER_AUTHOR = 2;
const SPARSE_DISCOVERY_LOOKBACK_SECONDS = 48 * 60 * 60;
const SPARSE_DISCOVERY_GRAPH_MS = 350;
const SPARSE_DISCOVERY_POSTS_MS = 750;

export type SparseForYouDeps = {
  durablePostKinds: readonly number[];
  getFeedProfilePubkeys: (viewerPubkey: string, feedOwnerPubkey: string, notes: RawEvent[]) => string[];
  loadProfilesForPubkeys: (root: CID, pubkeys: string[]) => Promise<Map<string, ProfileRecord>>;
  loadSparseDiscoveryFollows?: (
    pubkey: string, limit: number, signal: AbortSignal,
  ) => Promise<readonly string[]>;
  loadSparseDiscoveryPosts?: (
    roots: CID[], authors: string[], limit: number, signal: AbortSignal,
  ) => Promise<readonly RawEvent[]>;
};

type SparseForYouFilters = {
  excludeEventIds?: ReadonlySet<string>;
  mutedPubkeys?: ReadonlySet<string>;
};

async function readSparseDiscoveryWithin<T>(
  read: (signal: AbortSignal) => Promise<readonly T[]>,
  timeoutMs: number,
): Promise<readonly T[]> {
  const controller = new AbortController();
  try {
    const result = await awaitWithin(read(controller.signal), timeoutMs);
    return result.settled ? result.value : [];
  } catch {
    return [];
  } finally {
    controller.abort();
  }
}

async function loadSparseDiscoveryCandidates(
  roots: CID[],
  viewerPubkey: string,
  follows: readonly string[],
  filters: SparseForYouFilters,
  deps: SparseForYouDeps,
): Promise<RawEvent[]> {
  const { loadSparseDiscoveryFollows, loadSparseDiscoveryPosts } = deps;
  if (!loadSparseDiscoveryFollows || !loadSparseDiscoveryPosts
    || follows.length === 0 || follows.length > SPARSE_DISCOVERY_MAX_FOLLOWS) {
    return [];
  }

  const excludedAuthors = new Set([viewerPubkey, ...follows, ...(filters.mutedPubkeys ?? [])]);
  const branches = await Promise.all(follows.filter(author => !filters.mutedPubkeys?.has(author)).sort()
    .map(async (author) => {
      const followed = await readSparseDiscoveryWithin(
        signal => loadSparseDiscoveryFollows(author, SPARSE_DISCOVERY_BRANCH_LIMIT, signal),
        SPARSE_DISCOVERY_GRAPH_MS,
      );
      return [...new Set(followed.slice(0, SPARSE_DISCOVERY_BRANCH_LIMIT))]
        .filter(pubkey => isHexPubkey(pubkey) && !excludedAuthors.has(pubkey));
    }));
  const authors = new Set<string>();
  while (authors.size < SPARSE_DISCOVERY_MAX_AUTHORS) {
    const before = authors.size;
    for (const branch of branches) {
      const author = branch.find(pubkey => !authors.has(pubkey));
      if (author) { authors.add(author); }
      if (authors.size === SPARSE_DISCOVERY_MAX_AUTHORS) {break;}
    }
    if (authors.size === before) {break;}
  }

  const until = Math.floor(Date.now() / 1_000);
  const since = until - SPARSE_DISCOVERY_LOOKBACK_SECONDS;
  // Keep a separate read budget for each candidate author.
  const postsByAuthor = await Promise.all([...authors].map(async (author) => {
    const posts = await readSparseDiscoveryWithin(
      signal => loadSparseDiscoveryPosts(roots, [author], SPARSE_DISCOVERY_AUTHOR_POST_LIMIT, signal),
      SPARSE_DISCOVERY_POSTS_MS,
    );
    return mergeUniqueFeedNotes([...posts.slice(0, SPARSE_DISCOVERY_AUTHOR_POST_LIMIT)])
      .filter(event => event.pubkey === author
        && event.created_at >= since && event.created_at <= until
        && (event.kind === 1 || event.kind === 20 || event.kind === 30_023)
        && deps.durablePostKinds.includes(event.kind)
        && (event.kind !== 1 || !isReplyEvent(event))
        && !filters.excludeEventIds?.has(event.id))
      .slice(0, SPARSE_DISCOVERY_MAX_ORIGINALS_PER_AUTHOR);
  }));
  return mergeUniqueFeedNotes(...postsByAuthor);
}

export async function fillSparseForYouSnapshot(
  snapshot: FeedSnapshot,
  input: SparseForYouFilters & {
    root: CID;
    roots: CID[];
    viewerPubkey: string;
    limit: number;
    includeProfiles?: boolean;
  },
  deps: SparseForYouDeps,
): Promise<FeedSnapshot | null> {
  const { root, roots, viewerPubkey, limit, excludeEventIds } = input;
  const { notes, follows } = snapshot;
  if (notes.length >= limit) {return null;}
  const sparse = await loadSparseDiscoveryCandidates(roots, viewerPubkey, follows, input, deps);
  if (sparse.length === 0) {return null;}

  const fill = mixHomeFeedPage({
    chronological: [],
    discovery: sparse,
    limit: limit - notes.length,
    mode: 'for-you',
    previousAuthor: notes.at(-1)?.pubkey,
    seenIds: new Set([...(excludeEventIds ?? []), ...notes.map(event => event.id)]),
    seenAddresses: new Set(notes.flatMap(event => {
      const address = getAddressableEventCoordinate(event);
      return address ? [address] : [];
    })),
  });
  if (fill.notes.length === 0) {return null;}
  const profiles = new Map(snapshot.profiles);
  if (input.includeProfiles !== false) {
    const missing = deps.getFeedProfilePubkeys(viewerPubkey, snapshot.feedOwnerPubkey, fill.notes)
      .filter(pubkey => !profiles.has(pubkey));
    if (missing.length > 0) {
      for (const [pubkey, profile] of await deps.loadProfilesForPubkeys(root, missing)) {
        profiles.set(pubkey, profile);
      }
    }
  }
  return { ...snapshot, profiles, notes: [...notes, ...fill.notes] };
}
