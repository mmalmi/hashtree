import { getNoteEngagementTargetId } from './noteEngagement';
import type { CID } from '@hashtree/core';
import type { AppCombinedState } from './appState';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import {
  cloneHomeFeedContinuation,
  loadNextHomeFeedPage,
  retainHomeFeedOrder,
  type HomeFeedContinuation,
} from './homeFeedPagination';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import { getReaderForRoot, getRootNhash, type FeedSnapshot } from './nostrIndex';
import type { Route } from './appRoute';
import { routedRecentTextNotesByAuthors } from './routedEventReads';

const MAX_REFILL_PAGES = 4;

type HomePaginationDeps = {
  state: AppCombinedState;
  loadRecentTextNotesByAuthors?: Parameters<typeof loadNextHomeFeedPage>[0]['loadRecentTextNotesByAuthors'];
  homeFeedSeenBatcher: ReturnType<typeof createHomeFeedSeenBatcher>;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  hydrateFeedProfiles: (
    root: CID,
    viewerPubkey: string,
    feed: FeedSnapshot,
    token: number,
  ) => Promise<void>;
  hydrateNoteEngagements: (
    roots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  noteHasMedia: (event: RawEvent) => boolean;
  reportError: (fallback: string, error: unknown) => string;
  scheduleHomeFeedSnapshotWrite: (feed: FeedSnapshot) => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppHomePaginationController(deps: HomePaginationDeps) {
  const { state } = deps;

  function getHomeFeedContinuationIdentity(
    continuation: HomeFeedContinuation | null | undefined = state.feed?.continuation,
  ): string {
    if (!continuation) {return '';}
    const roots = continuation.roots.map((entry) => (
      `${getRootNhash(entry.root)}:${entry.exhausted ? 'exhausted' : 'open'}:${
        entry.cursor ? `${entry.cursor.createdAt}:${entry.cursor.eventId}` : 'none'
      }`
    )).join('|');
    const pools = [continuation.chronologicalPool, continuation.discoveryPool]
      .map((events) => events.map((event) => event.id).join(','))
      .join(':');
    return `${continuation.mode}:${continuation.includeReplies ? 'replies' : 'roots'}:${
      continuation.nextLane
    }:${continuation.authors.join(',')}:${roots}:${pools}`;
  }

  async function hydrateNextHomeFeedPage(
    currentRoot: CID,
    currentRoute: Route,
    pageSize: number,
    token: number,
    options: { initialPage?: boolean } = {},
  ): Promise<void> {
    const currentFeed = state.feed;
    const continuation = cloneHomeFeedContinuation(currentFeed?.continuation);
    if (
      currentRoute.kind !== 'home'
      || (
        currentRoute.tab !== 'latest'
        && currentRoute.tab !== 'for-you'
        && currentRoute.tab !== 'favorites'
        && currentRoute.tab !== 'media'
      )
      || !currentFeed
      || !continuation
      || continuation.roots.length === 0
    ) {return;}

    const rootIdentity = getRootNhash(currentRoot);
    if (!requestIsCurrent(currentRoute, token, rootIdentity)) {return;}
    const continuationIdentity = getHomeFeedContinuationIdentity();
    if (options.initialPage) {
      // A fast first-paint probe may precede newer posts from the ordered
      // merge. Resume unfinished roots from the head, deduplicating the
      // visible notes instead of treating that provisional time as a cursor.
      for (const entry of continuation.roots) {
        if (!entry.exhausted) {entry.cursor = null;}
      }
    }
    try {
      const seenIds = new Set([
        ...currentFeed.notes.map((event) => event.id),
        ...(currentRoute.tab === 'for-you' && state.activeAccount
          ? deps.homeFeedSeenBatcher.read(state.activeAccount.pubkey)
          : []),
      ]);
      const seenAddresses = new Set(currentFeed.notes
        .map(getAddressableEventCoordinate)
        .filter((address): address is string => Boolean(address)));
      const appended: RawEvent[] = [];
      let nextContinuation = continuation;
      let visibleCount = 0;
      for (let pageIndex = 0; pageIndex < MAX_REFILL_PAGES; pageIndex += 1) {
        const previousIdentity = getHomeFeedContinuationIdentity(nextContinuation);
        const nextPage = await loadNextHomeFeedPage({
          continuation: nextContinuation,
          getReaderForRoot,
          loadRecentTextNotesByAuthors: deps.loadRecentTextNotesByAuthors ?? routedRecentTextNotesByAuthors,
          limit: Math.max(1, pageSize - visibleCount),
          seenAddresses,
          seenIds,
        });
        if (!requestIsCurrent(currentRoute, token, rootIdentity)) {return;}
        const newEvents = nextPage.notes.filter((event) => {
          const address = getAddressableEventCoordinate(event);
          return !seenIds.has(event.id) && (!address || !seenAddresses.has(address));
        });
        for (const event of newEvents) {
          seenIds.add(event.id);
          const address = getAddressableEventCoordinate(event);
          if (address) {seenAddresses.add(address);}
          appended.push(event);
          if (isVisible(event, currentRoute)) {visibleCount += 1;}
        }
        nextContinuation = nextPage.continuation;
        if (
          visibleCount >= pageSize
          || !nextPage.hasMore
          || (
            newEvents.length === 0
            && getHomeFeedContinuationIdentity(nextContinuation) === previousIdentity
          )
        ) {break;}
      }

      if (
        getHomeFeedContinuationIdentity() !== continuationIdentity
        || state.feed?.feedOwnerPubkey !== currentFeed.feedOwnerPubkey
      ) {return;}
      const nextFeed: FeedSnapshot = {
        ...currentFeed,
        continuation: nextContinuation,
        displayOrder: state.homeNotes.map(event => event.id),
        notes: retainHomeFeedOrder([...currentFeed.notes, ...appended],
          state.homeNotes.map(event => event.id), continuation.mode),
      };
      state.feed = nextFeed;
      deps.scheduleHomeFeedSnapshotWrite(nextFeed);
      deps.cacheKnownNotes(appended);
      const visible = appended.filter((event) => isVisible(event, currentRoute));
      deps.seedNewEmptyEngagements(visible.map(getNoteEngagementTargetId));
      if (visible.length === 0) {return;}

      void deps.hydrateNoteEngagements(
        nextContinuation.roots.map((entry) => entry.root),
        visible.map(getNoteEngagementTargetId),
        token,
        { merge: true },
      );
      if (state.activeAccount) {
        void deps.hydrateFeedProfiles(currentRoot, state.activeAccount.pubkey, {
          ...nextFeed,
          notes: visible,
        }, token);
      }
    } catch (error) {
      console.warn('Failed to append the next indexed home-feed page', error);
      if (requestIsCurrent(currentRoute, token, rootIdentity)) {
        state.pageError = deps.reportError("Couldn't load more posts right now.", error);
      }
    }
  }

  function requestIsCurrent(
    route: Extract<Route, { kind: 'home' }>,
    token: number,
    rootIdentity: string,
  ): boolean {
    return token === state.loadToken
      && state.rootNhash === rootIdentity
      && state.route.kind === 'home'
      && state.route.tab === route.tab;
  }

  function isVisible(event: RawEvent, route: Extract<Route, { kind: 'home' }>): boolean {
    return (event.pubkey === state.activeAccount?.pubkey || !state.viewerMutedPubkeys.has(event.pubkey))
      && (route.tab !== 'media' || deps.noteHasMedia(event));
  }

  return { getHomeFeedContinuationIdentity, hydrateNextHomeFeedPage };
}
