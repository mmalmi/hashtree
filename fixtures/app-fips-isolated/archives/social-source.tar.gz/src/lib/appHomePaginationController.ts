import type { ReportAppError } from './appError';
import { isMutedEvent } from './muteLists';
import { getNoteEngagementTargetId } from './noteEngagement';
import type { CID } from '@hashtree/core';
import type { EngagementHydrationOptions } from './appEngagementController';
import type { AppCombinedState } from './appState';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import {
  cloneHomeFeedContinuation,
  loadNextHomeFeedPage,
  mergeUniqueFeedNotes,
  retainHomeFeedOrder,
  type HomeFeedContinuation,
} from './homeFeedPagination';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import { getReaderForRoot, getRootNhash, type FeedSnapshot } from './nostrIndex';
import type { Route } from './appRoute';
import { queryArchiveEvents, routedRecentTextNotesByAuthors } from './routedEventReads';
import { awaitWithin } from './feedIndexTiming';
import { readPostsBefore } from './homeFeedReads';

const LOAD_MORE_RETRY_PAUSE_MS = 3_000;

const MAX_REFILL_PAGES = 4;
// The archive can be slow for large follow sets; page from relays instead of
// leaving the reader waiting on a stuck read.
const ARCHIVE_PAGE_READ_DEADLINE_MS = 5_000;
const ARCHIVE_SLOW_BACKOFF_MS = 60_000;
let archiveSlowUntil = 0;

type HomePaginationDeps = {
  state: AppCombinedState;
  loadRecentTextNotesByAuthors?: Parameters<typeof loadNextHomeFeedPage>[0]['loadRecentTextNotesByAuthors'];
  loadPostsBefore?: (authors: string[], until: number) => Promise<RawEvent[]>;
  homeFeedSeenBatcher: ReturnType<typeof createHomeFeedSeenBatcher>;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  hydrateFeedProfiles: (
    root: CID,
    viewerPubkey: string,
    feed: FeedSnapshot,
    token: number,
  ) => Promise<void>;
  hydrateNoteEngagements: (
    roots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: EngagementHydrationOptions,
  ) => Promise<void>;
  noteHasMedia: (event: RawEvent) => boolean;
  reportError: ReportAppError;
  scheduleHomeFeedSnapshotWrite: (feed: FeedSnapshot, viewerPubkey: string) => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppHomePaginationController(deps: HomePaginationDeps) {
  const { state } = deps;

  function getHomeFeedContinuationIdentity(
    continuation: HomeFeedContinuation | null | undefined = state.feed?.continuation,
  ): string {
    if (!continuation) {return '';}
    const roots = continuation.roots.map((entry) => (
      `${getRootNhash(entry.root)}:${entry.exhausted ? 'exhausted' : 'open'}:${
        entry.cursor ? `${entry.cursor.createdAt}:${entry.cursor.eventId}` : 'none'
      }`
    )).join('|');
    const pools = [continuation.chronologicalPool, continuation.discoveryPool]
      .map((events) => events.map((event) => event.id).join(','))
      .join(':');
    return `${continuation.mode}:${continuation.includeReplies ? 'replies' : 'roots'}:${
      continuation.nextLane
    }:${continuation.authors.join(',')}:${roots}:${pools}`;
  }

  async function hydrateNextHomeFeedPage(
    currentRoot: CID,
    currentRoute: Route,
    pageSize: number,
    token: number,
    options: { initialPage?: boolean } = {},
  ): Promise<void> {
    const currentFeed = state.feed;
    const continuation = cloneHomeFeedContinuation(currentFeed?.continuation);
    if (
      currentRoute.kind !== 'home'
      || (
        currentRoute.tab !== 'latest'
        && currentRoute.tab !== 'for-you'
        && currentRoute.tab !== 'favorites'
        && currentRoute.tab !== 'media'
      )
      || !currentFeed
      || !continuation
      || continuation.roots.length === 0
    ) {return;}

    const rootIdentity = getRootNhash(currentRoot);
    if (!requestIsCurrent(currentRoute, token, rootIdentity)) {return;}
    const viewerPubkey = state.activeAccount?.pubkey ?? '';
    const continuationIdentity = getHomeFeedContinuationIdentity();
    if (options.initialPage) {
      // A fast first-paint probe may precede newer posts from the ordered
      // merge. Resume unfinished roots from the head, deduplicating the
      // visible notes instead of treating that provisional time as a cursor.
      for (const entry of continuation.roots) {
        if (!entry.exhausted) {entry.cursor = null;}
      }
    }
    try {
      const seenIds = new Set(currentFeed.notes.map((event) => event.id));
      const seenAddresses = new Set(currentFeed.notes
        .map(getAddressableEventCoordinate)
        .filter((address): address is string => Boolean(address)));
      const appended: RawEvent[] = [];
      let nextContinuation = continuation;
      let visibleCount = 0;
      let previousAuthor = state.homeNotes.at(-1)?.pubkey;
      let archiveTimedOut = Date.now() < archiveSlowUntil;
      let archiveHasMore = true;
      for (let pageIndex = 0; pageIndex < (archiveTimedOut ? 0 : MAX_REFILL_PAGES); pageIndex += 1) {
        const previousIdentity = getHomeFeedContinuationIdentity(nextContinuation);
        const pageRead = await awaitWithin(loadNextHomeFeedPage({
          continuation: nextContinuation,
          getReaderForRoot,
          loadRecentTextNotesByAuthors: deps.loadRecentTextNotesByAuthors
            ?? ((roots, authors, limit, options) => (
              routedRecentTextNotesByAuthors(roots, authors, limit, { ...options, query: queryArchiveEvents })
            )),
          limit: Math.max(1, pageSize - visibleCount),
          previousAuthor,
          seenAddresses,
          seenIds,
        }), ARCHIVE_PAGE_READ_DEADLINE_MS);
        if (!pageRead.settled) {
          archiveTimedOut = true;
          archiveSlowUntil = Date.now() + ARCHIVE_SLOW_BACKOFF_MS;
          break;
        }
        const nextPage = pageRead.value;
        if (!requestIsCurrent(currentRoute, token, rootIdentity)) {return;}
        const newEvents = nextPage.notes.filter((event) => {
          const address = getAddressableEventCoordinate(event);
          return !seenIds.has(event.id) && (!address || !seenAddresses.has(address));
        });
        for (const event of newEvents) {
          seenIds.add(event.id);
          const address = getAddressableEventCoordinate(event);
          if (address) {seenAddresses.add(address);}
          appended.push(event);
          if (isVisible(event, currentRoute)) {
            visibleCount += 1;
            previousAuthor = event.pubkey;
          }
        }
        nextContinuation = nextPage.continuation;
        archiveHasMore = nextPage.hasMore;
        if (
          visibleCount >= pageSize
          || !nextPage.hasMore
          || (
            newEvents.length === 0
            && getHomeFeedContinuationIdentity(nextContinuation) === previousIdentity
          )
        ) {break;}
      }

      // When the archive's author stream is slow or done, one read of the
      // cache, Hashtree index and relays continues past the oldest post.
      const loadPostsBefore = deps.loadPostsBefore
        ?? ((authors: string[], until: number) => readPostsBefore(authors, until, AbortSignal.timeout(6_000)));
      if (visibleCount < pageSize && (archiveTimedOut || !archiveHasMore)
        && continuation.authors.length > 0) {
        const oldest = Math.min(...[...currentFeed.notes, ...appended].map((event) => event.created_at));
        const olderPosts = await loadPostsBefore(continuation.authors, Number.isFinite(oldest) ? oldest : Math.floor(Date.now() / 1_000))
          .catch(() => []);
        if (!requestIsCurrent(currentRoute, token, rootIdentity)) {return;}
        for (const event of olderPosts.sort((left, right) => right.created_at - left.created_at)) {
          const address = getAddressableEventCoordinate(event);
          if (seenIds.has(event.id) || (address && seenAddresses.has(address))) {continue;}
          seenIds.add(event.id);
          if (address) {seenAddresses.add(address);}
          appended.push(event);
          if (isVisible(event, currentRoute)) {
            visibleCount += 1;
          }
          if (visibleCount >= pageSize) {break;}
        }
      }

      if (
        getHomeFeedContinuationIdentity() !== continuationIdentity
        || state.feed?.feedOwnerPubkey !== currentFeed.feedOwnerPubkey
      ) {return;}
      const nextFeed: FeedSnapshot = {
        ...currentFeed,
        continuation: nextContinuation,
        displayOrder: currentRoute.tab === 'latest' ? undefined : state.homeNotes.map(event => event.id),
        notes: currentRoute.tab === 'latest'
          ? mergeUniqueFeedNotes(currentFeed.notes, appended)
          : retainHomeFeedOrder([...currentFeed.notes, ...appended],
            state.homeNotes.map(event => event.id), continuation.mode),
      };
      state.feed = nextFeed;
      deps.scheduleHomeFeedSnapshotWrite(nextFeed, viewerPubkey);
      deps.cacheKnownNotes(appended);
      const visible = appended.filter((event) => isVisible(event, currentRoute));
      deps.seedNewEmptyEngagements(visible.map(getNoteEngagementTargetId));
      if (visible.length === 0) {return;}

      void deps.hydrateNoteEngagements(
        nextContinuation.roots.map((entry) => entry.root),
        visible.map(getNoteEngagementTargetId),
        token,
        {
          merge: true,
          ...(currentRoute.tab === 'for-you' && !options.initialPage ? { forYouRelayNotes: visible } : {}),
        },
      );
      void deps.hydrateFeedProfiles(currentRoot, viewerPubkey, {
        ...nextFeed,
        notes: visible,
      }, token);
    } catch (error) {
      console.warn('Failed to append the next indexed home-feed page', error);
      // Keep the feed quiet: hold the pending state briefly so the visible
      // sentinel retries with a pause instead of showing an error.
      if (requestIsCurrent(currentRoute, token, rootIdentity)) {
        await new Promise(resolve => setTimeout(resolve, LOAD_MORE_RETRY_PAUSE_MS));
      }
    }
  }

  function requestIsCurrent(
    route: Extract<Route, { kind: 'home' }>,
    token: number,
    rootIdentity: string,
  ): boolean {
    return token === state.loadToken
      && state.rootNhash === rootIdentity
      && state.route.kind === 'home'
      && state.route.tab === route.tab;
  }

  function isVisible(event: RawEvent, route: Extract<Route, { kind: 'home' }>): boolean {
    return !isMutedEvent(event, state.viewerHiddenPubkeys, state.activeAccount?.pubkey ?? null, {
      hideMentions: true,
      explicitAuthors: state.viewerFollows,
    })
      && (route.tab !== 'media' || deps.noteHasMedia(event));
  }

  return { getHomeFeedContinuationIdentity, hydrateNextHomeFeedPage };
}
