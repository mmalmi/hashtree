import type { NotificationItem } from './appDetailLoaders';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';

/** One independently paginated notification source (archive or relays). */
export type NotificationSourcePage = {
  /** False until the source returns its first page. */
  loaded: boolean;
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
};

export const PENDING_NOTIFICATION_SOURCE: NotificationSourcePage = {
  loaded: false,
  cursor: null,
  hasMore: true,
};

export const DISABLED_NOTIFICATION_SOURCE: NotificationSourcePage = {
  loaded: true,
  cursor: null,
  hasMore: false,
};

export type NotificationSourceProjection = {
  visible: NotificationItem[];
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
};

function itemCursor(item: NotificationItem): RecentTextNoteCursor {
  return { createdAt: item.actorEvent.created_at, eventId: item.id };
}

function isBefore(item: NotificationItem, cursor: RecentTextNoteCursor): boolean {
  return isStrictlyBeforeRecentCursor(item.actorEvent.created_at, item.id, cursor);
}

/**
 * The newest boundary among sources that still have older pages. Anything
 * older can still gain events from that source, so it waits below the fold.
 */
export function notificationSourceBoundary(
  sources: readonly NotificationSourcePage[],
): RecentTextNoteCursor | null {
  let boundary: RecentTextNoteCursor | null = null;
  for (const source of sources) {
    if (!source.loaded || !source.hasMore || !source.cursor) {continue;}
    if (
      !boundary
      || isStrictlyBeforeRecentCursor(boundary.createdAt, boundary.eventId, source.cursor)
    ) {
      boundary = source.cursor;
    }
  }
  return boundary;
}

/**
 * Merge independently paginated sources without gaps: a newest-first list
 * only shows events no source can still insert above. A source that has not
 * answered yet does not hold the others back; its events merge when they land.
 */
export function projectNotificationSources(
  items: readonly NotificationItem[],
  sources: readonly NotificationSourcePage[],
): NotificationSourceProjection {
  const boundary = notificationSourceBoundary(sources);
  const visible = boundary ? items.filter((item) => !isBefore(item, boundary)) : [...items];
  const oldest = visible.at(-1);
  return {
    visible,
    cursor: boundary ?? (oldest ? itemCursor(oldest) : null),
    hasMore: sources.some((source) => source.loaded && source.hasMore),
  };
}
