import type { CID } from '@hashtree/core';
import { isSocialRelationshipCatalogConfigured } from './config';
import { raceAsyncIteratorWithPromise } from './asyncIteratorRace';
import { awaitWithin } from './feedIndexTiming';
import { getFeedProfilePubkeys } from './feedProfilePubkeys';
import { streamFeedSnapshotsByAuthors as streamFeedSnapshotsByAuthorsWithDeps } from './feedSnapshotStream';
import {
  streamPersonalizedForYouFeed,
  type ForYouFeedStreamOptions,
} from './forYouFeed';
import {
  preferGlobalStarterAuthors,
  selectKnownViewerFollows,
  selectNewestViewerContactsEvent,
  shouldStreamProvisionalViewerFeed,
  type LatestFeedOptions,
} from './homeFeedContacts';
import {
  extractFollowPubkeys,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import {
  getReaderForRoot,
  getRootNhash,
  resolveProfileEventIndexRoot,
} from './nostrIndexRoots';
import type { FeedSnapshot } from './nostrIndexTypes';
import { loadIndexedProfileRecord, loadIndexedProfiles } from './profileIndex';
import {
  loadProfileBatchFromFastestSource,
  loadProfileFromFastestSource,
  type ProfileBatchLoadOptions,
  type ProfileLoadOptions,
} from './profileSourceRace';
import {
  loadProfileSocialFromIndexes,
  type ProfileSocialOptions,
  type ProfileSocialSnapshot,
} from './profileSocial';
import { DURABLE_POST_KINDS } from './recentAuthorFeedReader';
import {
  routedEventsByAuthors,
  routedEventById,
  routedLatestEventByAuthorKind,
  routedProfilesByPubkey,
  routedRecentTextNotesByAuthors,
} from './routedEventReads';
import { isLocalPersonalEventIndexRoot } from './personalEventIndexBrowser';
import {
  applySocialGraphMetrics,
  applySocialGraphMetricsToProfileMap,
} from './socialGraph';
import {
  loadSocialGraphFrontier,
  selectSocialGraphFrontierAuthors,
  selectViewerRootFrontierFollows,
} from './socialGraphFrontier';

const STARTER_FEED_AUTHOR_LIMIT = 96;
const VIEWER_FEED_LOOKUP_GRACE_MS = 250;
const CONTACT_LOOKUP_GRACE_MS = 2_500;
const STARTER_PERSONAL_ROOT_GRACE_MS = 2_500;
export const PROVISIONAL_HOME_FEED_EMIT_EVERY = 8;

async function loadStarterFeedAuthors(
  root: CID,
  viewerPubkey: string,
  fallbackFeedOwnerPubkey: string,
): Promise<{
  feedAuthors: string[];
  starterMode: FeedSnapshot['starterMode'];
  starterPostsRoot: CID;
}> {
  const starterPersonalRootPromise = resolveProfileEventIndexRoot(fallbackFeedOwnerPubkey);
  const toStarterAuthors = (event: RawEvent | null): string[] => [...new Set(extractFollowPubkeys(event))]
    .filter((pubkey) => pubkey !== viewerPubkey && pubkey !== fallbackFeedOwnerPubkey)
    .slice(0, STARTER_FEED_AUTHOR_LIMIT);
  const globalStarterAuthorsPromise = awaitWithin(
    routedLatestEventByAuthorKind([root], fallbackFeedOwnerPubkey, 3),
    STARTER_PERSONAL_ROOT_GRACE_MS,
  )
    .then((result) => toStarterAuthors(result.settled ? result.value : null))
    .catch((error) => {
      console.warn('Failed to read starter feed contacts from global index', error);
      return [];
    });
  let starterPersonalRoot: CID | null = null;
  const personalStarterAuthorsPromise = awaitWithin(
    starterPersonalRootPromise.then(async (personalRoot) => {
      starterPersonalRoot = personalRoot;
      if (!personalRoot || getRootNhash(personalRoot) === getRootNhash(root)) {
        return [];
      }

      const event = await routedLatestEventByAuthorKind(
        [personalRoot],
        fallbackFeedOwnerPubkey,
        3,
      );
      return toStarterAuthors(event);
    }).catch((error) => {
      console.warn('Failed to read starter feed contacts from personal index', error);
      return [];
    }),
    STARTER_PERSONAL_ROOT_GRACE_MS,
  ).then((result) => result.settled ? result.value : []);
  let followedAuthors = await preferGlobalStarterAuthors(
    globalStarterAuthorsPromise,
    personalStarterAuthorsPromise,
  );

  if (followedAuthors.length === 0) {
    if (isSocialRelationshipCatalogConfigured()) {
      followedAuthors = await awaitWithin(
        import('./socialRelationshipRuntime').then(async ({ loadIndexedProfileRelationships }) => (
          await loadIndexedProfileRelationships(root, fallbackFeedOwnerPubkey, {
            followerLimit: 1,
            followLimit: STARTER_FEED_AUTHOR_LIMIT,
            includeFollowers: false,
          })
        )),
        STARTER_PERSONAL_ROOT_GRACE_MS,
      ).then((result) => (
        result.settled && result.value ? result.value.follows : []
      )
        .filter((pubkey) => pubkey !== viewerPubkey && pubkey !== fallbackFeedOwnerPubkey)
        .slice(0, STARTER_FEED_AUTHOR_LIMIT))
        .catch((error) => {
          console.warn('Failed to read starter authors from the relationship catalog', error);
          return [];
        });
    }
  }

  return {
    feedAuthors: followedAuthors.length > 0 ? followedAuthors : [fallbackFeedOwnerPubkey],
    starterMode: followedAuthors.length > 0 ? 'sirius-follows' : 'sirius-posts',
    starterPostsRoot: starterPersonalRoot ?? root,
  };
}

export async function loadLatestFeed(
  root: CID,
  viewerPubkey: string,
  limit: number,
  options: LatestFeedOptions = {},
): Promise<FeedSnapshot> {
  let latestFeed: FeedSnapshot | null = null;
  for await (const nextFeed of streamLatestFeed(root, viewerPubkey, limit, options)) {
    latestFeed = nextFeed;
  }

  return latestFeed ?? {
    rootNhash: getRootNhash(root),
    followCount: 0,
    follows: [],
    profiles: new Map<string, ProfileRecord>(),
    notes: [],
    feedOwnerPubkey: viewerPubkey,
    usedSuggestedFeed: false,
    starterMode: null,
  };
}

function streamFeedSnapshotsByAuthors(
  ...args: Parameters<typeof streamFeedSnapshotsByAuthorsWithDeps> extends [...infer FeedArgs, unknown]
    ? FeedArgs
    : never
): ReturnType<typeof streamFeedSnapshotsByAuthorsWithDeps> {
  return streamFeedSnapshotsByAuthorsWithDeps(...args, {
    getFeedProfilePubkeys,
    getReaderForRoot,
    getRootNhash,
    loadRecentTextNotesByAuthors: routedRecentTextNotesByAuthors,
    loadProfilesForPubkeys,
    shouldRoutePrimaryRoot: isLocalPersonalEventIndexRoot,
  });
}

export async function* streamLatestFeed(
  root: CID,
  viewerPubkey: string,
  limit: number,
  options: LatestFeedOptions = {},
): AsyncGenerator<FeedSnapshot, void, void> {
  const reader = getReaderForRoot(root);
  if (options.favoriteAuthors !== undefined) {
    const authors = selectKnownViewerFollows(options.favoriteAuthors, viewerPubkey);
    yield* streamFeedSnapshotsByAuthors(root, reader, viewerPubkey, limit,
      authors, 'favorites', authors, null, {
        ...options,
        additionalRootsPromise: authors.length > 0
          ? resolveProfileEventIndexRoot(viewerPubkey).then((personalRoot) => personalRoot ? [personalRoot] : [])
          : undefined,
      });
    return;
  }
  const additionalRootsPromise = resolveProfileEventIndexRoot(viewerPubkey).then((personalRoot) => (
    personalRoot ? [personalRoot] : []
  ));
  const feedOptions = { ...options, additionalRootsPromise };
  const fallbackFeedOwnerPubkey =
    options.fallbackFeedOwnerPubkey && options.fallbackFeedOwnerPubkey !== viewerPubkey
      ? options.fallbackFeedOwnerPubkey
      : null;
  const knownViewerFollows = selectKnownViewerFollows(options.knownViewerFollows, viewerPubkey);
  const initialViewerFollows = knownViewerFollows.length > 0
    ? knownViewerFollows
    : selectViewerRootFrontierFollows(viewerPubkey, await loadSocialGraphFrontier()) ?? [];
  if (initialViewerFollows.length > 0) {
    yield* streamFeedSnapshotsByAuthors(root, reader, viewerPubkey, limit,
      initialViewerFollows, viewerPubkey, initialViewerFollows, null, feedOptions);
    return;
  }
  const globalViewerContactsPromise = options.preferStarterFeed
    ? null
    : routedLatestEventByAuthorKind([root], viewerPubkey, 3).catch((error) => {
        console.warn('Failed to read viewer contacts from index', error);
        return null;
      });
  const personalViewerContactsPromise = options.preferStarterFeed
    ? null
    : additionalRootsPromise.then(async ([personalRoot]) => {
        if (!personalRoot || getRootNhash(personalRoot) === getRootNhash(root)) {
          return null;
        }
        return await routedLatestEventByAuthorKind([personalRoot], viewerPubkey, 3);
      }).catch((error) => {
        console.warn('Failed to read viewer contacts from the personal index', error);
        return null;
      });
  const viewerContactsPromise = globalViewerContactsPromise && personalViewerContactsPromise
    ? Promise.all([globalViewerContactsPromise, personalViewerContactsPromise]).then((events) => (
        selectNewestViewerContactsEvent(events, viewerPubkey)
      ))
    : globalViewerContactsPromise;
  const quickViewerContacts = viewerContactsPromise
    ? await awaitWithin(viewerContactsPromise, VIEWER_FEED_LOOKUP_GRACE_MS)
    : { settled: false as const };

  if (
    !quickViewerContacts.settled
    && globalViewerContactsPromise
    && viewerContactsPromise
  ) {
    const quickGlobal = await awaitWithin(globalViewerContactsPromise, VIEWER_FEED_LOOKUP_GRACE_MS);
    const provisionalFollows = extractFollowPubkeys(quickGlobal.settled ? quickGlobal.value : null);
    if (shouldStreamProvisionalViewerFeed(provisionalFollows, fallbackFeedOwnerPubkey)) {
      const provisional = streamFeedSnapshotsByAuthors(
        root,
        reader,
        viewerPubkey,
        limit,
        provisionalFollows,
        viewerPubkey,
        provisionalFollows,
        null,
        { ...options, emitEvery: PROVISIONAL_HOME_FEED_EMIT_EVERY },
      )[Symbol.asyncIterator]();
      const finalContactsPromise = awaitWithin(viewerContactsPromise, CONTACT_LOOKUP_GRACE_MS);
      let finalContacts: Awaited<typeof finalContactsPromise> | null = null;
      for await (const update of raceAsyncIteratorWithPromise(provisional, finalContactsPromise)) {
        if (update.type === 'item') {
          // These authors came from the verified global contact list, but the
          // newer personal contact list is still unresolved. The reader emits
          // note one immediately, then bounded batches, while pagination stays
          // closed until the final frozen author set is known.
          yield { ...update.value, continuation: null };
        } else {
          finalContacts = update.value;
        }
      }
      finalContacts ??= await finalContactsPromise;
      if (finalContacts.settled) {
        const finalFollows = extractFollowPubkeys(finalContacts.value);
        if (shouldStreamProvisionalViewerFeed(finalFollows, fallbackFeedOwnerPubkey)) {
          yield* streamFeedSnapshotsByAuthors(
            root,
            reader,
            viewerPubkey,
            limit,
            finalFollows,
            viewerPubkey,
            finalFollows,
            null,
            feedOptions,
          );
          return;
        }
      } else {
        yield* streamFeedSnapshotsByAuthors(
          root,
          reader,
          viewerPubkey,
          limit,
          provisionalFollows,
          viewerPubkey,
          provisionalFollows,
          null,
          { ...options, additionalRootsPromise: Promise.resolve([]) },
        );
        return;
      }
    }
  }

  if (quickViewerContacts.settled) {
    const follows = extractFollowPubkeys(quickViewerContacts.value);
    if (follows.length > 0 || !fallbackFeedOwnerPubkey) {
      yield* streamFeedSnapshotsByAuthors(
        root,
        reader,
        viewerPubkey,
        limit,
        follows,
        viewerPubkey,
        follows,
        null,
        feedOptions,
      );
      return;
    }
  }

  if (!fallbackFeedOwnerPubkey) {
    const finalViewerContacts = viewerContactsPromise
      ? await awaitWithin(viewerContactsPromise, CONTACT_LOOKUP_GRACE_MS)
      : { settled: true as const, value: null };
    const follows = extractFollowPubkeys(finalViewerContacts.settled ? finalViewerContacts.value : null);
    yield* streamFeedSnapshotsByAuthors(
      root,
      reader,
      viewerPubkey,
      limit,
      follows,
      viewerPubkey,
      follows,
      null,
      feedOptions,
    );
    return;
  }

  const frontierAuthors = selectSocialGraphFrontierAuthors(
    viewerPubkey,
    fallbackFeedOwnerPubkey,
    await loadSocialGraphFrontier(),
  );
  if (frontierAuthors.length > 0) {
    yield* streamFeedSnapshotsByAuthors(
      root,
      reader,
      viewerPubkey,
      limit,
      [],
      fallbackFeedOwnerPubkey,
      frontierAuthors,
      'social-graph-snapshot',
      feedOptions,
    );
    return;
  }

  const starterFeed = await loadStarterFeedAuthors(root, viewerPubkey, fallbackFeedOwnerPubkey);

  if (starterFeed.starterMode === 'sirius-posts') {
    for await (const snapshot of streamFeedSnapshotsByAuthors(
      starterFeed.starterPostsRoot,
      getReaderForRoot(starterFeed.starterPostsRoot),
      viewerPubkey,
      limit,
      [],
      fallbackFeedOwnerPubkey,
      [fallbackFeedOwnerPubkey],
      'sirius-posts',
      feedOptions,
    )) {
      yield snapshot;
    }
    return;
  }

  for await (const snapshot of streamFeedSnapshotsByAuthors(
    root,
    reader,
    viewerPubkey,
    limit,
    [],
    fallbackFeedOwnerPubkey,
    starterFeed.feedAuthors,
    starterFeed.starterMode,
    feedOptions,
  )) {
    yield snapshot;
  }
}

export async function* streamForYouFeed(
  root: CID,
  viewerPubkey: string,
  limit: number,
  options: ForYouFeedStreamOptions = {},
): AsyncGenerator<FeedSnapshot, void, void> {
  yield* streamPersonalizedForYouFeed(root, viewerPubkey, limit, options, {
    durablePostKinds: DURABLE_POST_KINDS,
    getRecentOverlayPostsByAuthors: options.getRecentOverlayPostsByAuthors,
    getRecentOverlayInteractionsByAuthors: options.getRecentOverlayInteractionsByAuthors,
    getOverlayEventById: options.getOverlayEventById,
    getFeedProfilePubkeys,
    getReaderForRoot,
    getRootNhash,
    loadEventById: async (roots, eventId) => await routedEventById(roots, eventId),
    loadLatestEventByAuthorKind: async (roots, pubkey, kind) => (
      await routedLatestEventByAuthorKind(roots, pubkey, kind)
    ),
    loadRecentInteractionsByAuthors: async (roots, authors, interactionLimit) => (
      await routedEventsByAuthors(
        roots,
        authors,
        [6, 7],
        interactionLimit,
      )
    ),
    loadProfilesForPubkeys,
    resolvePersonalEventIndexRoot: resolveProfileEventIndexRoot,
    streamFeedSnapshotsByAuthors,
  });
}

export async function loadProfilesForPubkeys(
  root: CID,
  pubkeys: string[],
  options: ProfileBatchLoadOptions = {},
): Promise<Map<string, ProfileRecord>> {
  const profiles = await loadProfileBatchFromFastestSource(pubkeys, {
    loadCatalogProfiles: async (normalized, signal) => applySocialGraphMetricsToProfileMap(
      await loadIndexedProfiles(normalized, { signal }),
    ),
    loadRoutedProfiles: async (normalized, signal) => applySocialGraphMetricsToProfileMap(
      await routedProfilesByPubkey([root], normalized, { signal }),
    ),
  }, options);
  return profiles;
}

export async function loadProfileRecord(
  root: CID,
  pubkey: string,
  options: ProfileLoadOptions = {},
): Promise<ProfileRecord | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  if (!normalizedPubkey) {return null;}
  return applySocialGraphMetrics(await loadProfileFromFastestSource(normalizedPubkey, {
    loadCatalogProfile: async (signal) => (
      await loadIndexedProfileRecord(normalizedPubkey, { signal })
    ),
    loadRoutedProfile: async (signal) => (
      await routedProfilesByPubkey([root], [normalizedPubkey], { signal })
    ).get(normalizedPubkey) ?? null,
  }, options));
}

export async function loadProfileSocial(
  root: CID,
  pubkey: string,
  options: ProfileSocialOptions = {},
): Promise<ProfileSocialSnapshot> {
  return await loadProfileSocialFromIndexes(root, pubkey, options, {
    getReaderForRoot,
    getRootNhash,
    loadLatestContactsEvent: async (roots, author, signal) => (
      await routedLatestEventByAuthorKind(roots, author, 3, { signal })
    ),
    resolvePersonalRoot: resolveProfileEventIndexRoot,
  });
}
