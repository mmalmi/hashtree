import type { HashtreeWorkerClient } from '@hashtree/worker/client';
import type { SocialWorkerRequest } from '../workers/socialWorkerProtocol';
import { accountsStore } from './accounts';
import { settingsStore, DEFAULT_NOSTR_RELAYS } from './settings';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { resolveLocalSocialGraphRoot } from './socialGraph';
import { socialGraphBadges } from './socialGraphBadges';

export function attachWorkerGraphPolicy(client: HashtreeWorkerClient): void {
  let last = '';
  let suspended = false;
  const sync = (): void => {
    const { accounts, activeAccountPubkey, initialized } = accountsStore.getState();
    const account = accounts.find(value => value.pubkey === activeAccountPubkey) ?? null;
    const { network } = settingsStore.getState();
    const relays = getConfiguredNostrRelays();
    const normalized = (values: readonly string[]) => [...new Set(values.map(url => url.replace(/\/$/, '')))].sort().join(',');
    const policy = {
      enabled: initialized && network.relayContentReads,
      active: !suspended && !document.hidden && navigator.onLine,
      bootstrap: normalized(relays) === normalized(DEFAULT_NOSTR_RELAYS),
      relays,
      root: resolveLocalSocialGraphRoot(account, accounts.length),
      account: activeAccountPubkey,
    };
    const key = JSON.stringify(policy);
    if (key === last) {return;}
    last = key;
    void client.postExtensionMessage({
      type: 'social:configureGraphSync', requestId: 'worker-graph-policy', policy,
    } satisfies SocialWorkerRequest).catch(error => {
      if (last === key) {last = '';}
      console.warn('Failed to configure worker graph', error);
    });
  };
  client.onExtensionMessage(message => {
    if (message && typeof message === 'object' && 'type' in message
      && message.type === 'social:graphChanged') {socialGraphBadges.invalidate();}
  });
  settingsStore.subscribe(sync);
  accountsStore.subscribe(sync);
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('offline', sync);
  window.addEventListener('online', sync);
  window.addEventListener('pagehide', () => { suspended = true; sync(); });
  window.addEventListener('pageshow', () => { suspended = false; sync(); });
}
