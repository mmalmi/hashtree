export const NOTE_URL_REGEX = /(?:https?:\/\/|htree:\/\/)[^\s<>"']+|nhash1[a-z0-9]+\/[^\s<>"']+/gi;

const IMAGE_EXTENSIONS = new Set(['.avif', '.gif', '.jpeg', '.jpg', '.png', '.svg', '.webp']);
const VIDEO_EXTENSIONS = new Set(['.m4v', '.mov', '.mp4', '.webm']);
const AUDIO_EXTENSIONS = new Set(['.aac', '.m4a', '.mp3', '.oga', '.ogg', '.wav']);

export function trimTrailingPunctuation(raw: string): string {
  let value = raw;
  while (/[),.!?:;]+$/.test(value)) {
    value = value.slice(0, -1);
  }
  return value;
}

export function isExternalHttpUrl(raw: string): boolean {
  return /^https?:\/\//i.test(raw.trim());
}

export function safeExternalUrl(raw: string): URL | null {
  if (!isExternalHttpUrl(raw)) {
    return null;
  }

  try {
    return new URL(raw);
  } catch {
    return null;
  }
}

export function extensionForUrl(url: URL): string {
  const match = url.pathname.toLowerCase().match(/\.[a-z0-9]+$/);
  return match?.[0] ?? '';
}

export function isImageExtension(extension: string): boolean {
  return IMAGE_EXTENSIONS.has(extension.toLowerCase());
}

export function isVideoExtension(extension: string): boolean {
  return VIDEO_EXTENSIONS.has(extension.toLowerCase());
}

export function isAudioExtension(extension: string): boolean {
  return AUDIO_EXTENSIONS.has(extension.toLowerCase());
}

export function parseHashtreeAttachment(
  raw: string,
): { nhash: string; path: string; filename: string } | null {
  const trimmed = raw.trim();
  const cleaned = trimmed.startsWith('htree://') ? trimmed.slice('htree://'.length) : trimmed;
  const match = cleaned.match(/^(nhash1[a-z0-9]+)\/(.+)$/i);
  if (!match) {
    return null;
  }

  let decodedPath: string;
  try {
    decodedPath = decodeURIComponent(match[2]!);
  } catch {
    return null;
  }
  const segments = decodedPath.split('/').filter(Boolean);
  const filename = segments.at(-1) ?? decodedPath;
  return {
    nhash: match[1]!,
    path: decodedPath,
    filename,
  };
}

export function buildHashtreeAttachmentUrl(nhash: string, fileName = 'file'): string {
  const encodedName = fileName
    .split('/')
    .filter(Boolean)
    .map((segment) => encodeURIComponent(segment))
    .join('/');
  return encodedName ? `htree://${nhash}/${encodedName}` : `htree://${nhash}`;
}

export function getMimeType(filename: string): string {
  const extension = filename.split('.').pop()?.toLowerCase();
  const mimeTypes: Record<string, string> = {
    aac: 'audio/aac',
    avif: 'image/avif',
    gif: 'image/gif',
    jpeg: 'image/jpeg',
    jpg: 'image/jpeg',
    json: 'application/json',
    m4a: 'audio/mp4',
    m4v: 'video/x-m4v',
    mov: 'video/quicktime',
    mp3: 'audio/mpeg',
    mp4: 'video/mp4',
    oga: 'audio/ogg',
    ogg: 'audio/ogg',
    pdf: 'application/pdf',
    png: 'image/png',
    svg: 'image/svg+xml',
    txt: 'text/plain',
    wav: 'audio/wav',
    webm: 'video/webm',
    webp: 'image/webp',
  };

  return mimeTypes[extension ?? ''] ?? 'application/octet-stream';
}

export function parseHashAddressedMediaUrl(
  raw: string,
): { hashHex: string; filename: string; mimeType: string } | null {
  const url = safeExternalUrl(raw);
  if (!url) {
    return null;
  }

  const encodedFilename = url.pathname.split('/').filter(Boolean).at(-1);
  if (!encodedFilename) {
    return null;
  }

  let filename: string;
  try {
    filename = decodeURIComponent(encodedFilename);
  } catch {
    return null;
  }

  const match = filename.match(/^([0-9a-f]{64})(?:\.[a-z0-9]+)?$/i);
  if (!match) {
    return null;
  }

  return {
    hashHex: match[1]!.toLowerCase(),
    filename,
    mimeType: getMimeType(filename),
  };
}
