import * as nip19 from 'nostr-tools/nip19';
import {
  NOTE_URL_REGEX,
  extensionForUrl,
  isAudioExtension,
  isExternalHttpUrl,
  isImageExtension,
  isVideoExtension,
  parseHashtreeAttachment,
  safeExternalUrl,
  trimTrailingPunctuation,
} from './mediaUrls';
import { fallbackProfileNameForIdentity } from './nostr';

type NoteEmbedMediaMetadata = {
  sha256?: string;
  fallbackUrls?: string[];
};

export type NoteEmbed = NoteEmbedMediaMetadata & (
  | { kind: 'image'; url: string; isHashtree?: boolean; filename?: string; label?: string }
  | { kind: 'video'; url: string; isHashtree?: boolean; filename?: string; label?: string }
  | { kind: 'audio'; url: string; isHashtree?: boolean; filename?: string; label?: string }
  | { kind: 'youtube'; url: string; embedUrl: string; label: string; isHashtree?: boolean; filename?: string }
  | { kind: 'file'; url: string; filename: string; isHashtree: true; label?: string }
);

export type NoteContentSegment =
  | { type: 'text'; text: string }
  | { type: 'mention'; pubkey: string; bech32: string; label: string }
  | { type: 'event-ref'; bech32: string; label: string }
  | { type: 'link'; urls: string[] }
  | { type: 'attachment'; urls: string[] }
  | { type: 'emoji'; shortcode: string; url: string }
  | { type: 'hashtag'; tag: string };

type NoteContentClassification = {
  textEmbed: boolean;
};

/**
 * Text embeds are safe, compact inline representations for metadata fields
 * such as profile About text. New segment kinds must opt in explicitly.
 */
export const NOTE_CONTENT_CLASSIFICATION = {
  text: { textEmbed: false },
  mention: { textEmbed: true },
  'event-ref': { textEmbed: true },
  link: { textEmbed: true },
  attachment: { textEmbed: true },
  emoji: { textEmbed: true },
  hashtag: { textEmbed: true },
} as const satisfies Record<NoteContentSegment['type'], NoteContentClassification>;

type TextEmbedSegmentType = {
  [Type in keyof typeof NOTE_CONTENT_CLASSIFICATION]:
    typeof NOTE_CONTENT_CLASSIFICATION[Type]['textEmbed'] extends true ? Type : never;
}[keyof typeof NOTE_CONTENT_CLASSIFICATION];

export type TextEmbedSegment = Extract<NoteContentSegment, { type: TextEmbedSegmentType }>;

export function isTextEmbedSegment(
  segment: NoteContentSegment,
): segment is TextEmbedSegment {
  return NOTE_CONTENT_CLASSIFICATION[segment.type].textEmbed;
}

export type NotePresentation = {
  segments: NoteContentSegment[];
  embedGroups: NoteEmbed[][];
};

type NotePresentationInput = {
  content: string;
  tags: string[][];
  kind: number;
};

type CachedNotePresentation = NotePresentation & NotePresentationInput;

const notePresentationCache = new WeakMap<object, CachedNotePresentation>();

type MatchWithIndex = {
  index: number;
  match: RegExpExecArray;
};

const PATTERNS = {
  emoji: /:([a-zA-Z0-9_]+):/g,
  nostrUri:
    /nostr:(npub1[a-z0-9]{58}|nprofile1[a-z0-9]+|note1[a-z0-9]{58}|nevent1[a-z0-9]+|naddr1[a-z0-9]+)/gi,
  hashtag: /(^|\s)#([a-zA-Z0-9_\u0080-\uFFFF]+)(?=\s|$|[^\w])/g,
  url: NOTE_URL_REGEX,
} as const;

function detectYouTubeId(url: URL): string | null {
  const hostname = url.hostname.replace(/^www\./, '').toLowerCase();
  if (hostname === 'youtu.be') {
    return url.pathname.split('/').filter(Boolean)[0] ?? null;
  }

  if (hostname !== 'youtube.com' && hostname !== 'm.youtube.com') {
    return null;
  }

  if (url.pathname === '/watch') {
    return url.searchParams.get('v');
  }

  const parts = url.pathname.split('/').filter(Boolean);
  if (parts[0] === 'embed' || parts[0] === 'shorts' || parts[0] === 'live') {
    return parts[1] ?? null;
  }

  return null;
}

function buildEmojiMap(tags: string[][]): Map<string, string> {
  const emojiMap = new Map<string, string>();

  for (const tag of tags) {
    if (tag[0] === 'emoji' && typeof tag[1] === 'string' && typeof tag[2] === 'string') {
      emojiMap.set(tag[1], tag[2]);
    }
  }

  return emojiMap;
}

function decodeMentionPubkey(value: string): string | null {
  try {
    const decoded = nip19.decode(value);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return decoded.data;
    }

    if (
      decoded.type === 'nprofile' &&
      decoded.data &&
      typeof decoded.data === 'object' &&
      typeof decoded.data.pubkey === 'string'
    ) {
      return decoded.data.pubkey;
    }
  } catch {
    return null;
  }

  return null;
}

function shortenNostrReference(value: string, head = 10, tail = 6): string {
  if (value.length <= head + tail + 1) {
    return value;
  }

  return `${value.slice(0, head)}…${value.slice(-tail)}`;
}

function createNostrReferenceSegment(raw: string): NoteContentSegment {
  const cleaned = raw.slice('nostr:'.length);
  const prefix = cleaned.slice(0, cleaned.indexOf('1') + 1);

  if (prefix === 'npub1' || prefix === 'nprofile1') {
    const pubkey = decodeMentionPubkey(cleaned);
    if (pubkey) {
      return {
        type: 'mention',
        pubkey,
        bech32: cleaned,
        label: fallbackProfileNameForIdentity(pubkey),
      };
    }
  }

  if (prefix === 'note1' || prefix === 'nevent1' || prefix === 'naddr1') {
    return {
      type: 'event-ref',
      bech32: cleaned,
      label: shortenNostrReference(cleaned),
    };
  }

  return { type: 'text', text: raw };
}

function createEmbedFromUrl(raw: string): NoteEmbed | null {
  const trimmed = trimTrailingPunctuation(raw);
  const hashtreeAttachment = parseHashtreeAttachment(trimmed);
  if (hashtreeAttachment) {
    const filename = hashtreeAttachment.filename;
    const extension = filename.match(/\.[a-z0-9]+$/i)?.[0]?.toLowerCase() ?? '';

    if (isImageExtension(extension)) {
      return { kind: 'image', url: trimmed, isHashtree: true, filename };
    }

    if (isVideoExtension(extension)) {
      return { kind: 'video', url: trimmed, isHashtree: true, filename };
    }

    if (isAudioExtension(extension)) {
      return { kind: 'audio', url: trimmed, isHashtree: true, filename };
    }

    return {
      kind: 'file',
      url: trimmed,
      filename,
      isHashtree: true,
    };
  }

  const url = safeExternalUrl(trimmed);
  if (!url) {
    return null;
  }

  const extension = extensionForUrl(url);
  if (isImageExtension(extension)) {
    return { kind: 'image', url: trimmed };
  }

  if (isVideoExtension(extension)) {
    return { kind: 'video', url: trimmed };
  }

  if (isAudioExtension(extension)) {
    return { kind: 'audio', url: trimmed };
  }

  const youtubeId = detectYouTubeId(url);
  if (youtubeId) {
    return {
      kind: 'youtube',
      url: trimmed,
      embedUrl: `https://www.youtube.com/embed/${youtubeId}`,
      label: url.host,
    };
  }

  return null;
}

const MAX_IMETA_FALLBACK_URLS = 8;
const MAX_IMETA_FALLBACK_URL_LENGTH = 2_048;

function appendImetaField(fields: Map<string, string[]>, key: string, value: string): void {
  if (!value) {
    return;
  }
  const values = fields.get(key) ?? [];
  values.push(value);
  fields.set(key, values);
}

function parseImetaFields(tag: string[]): Map<string, string[]> {
  const fields = new Map<string, string[]>();
  const rawFields = tag.slice(1);

  // Iris Client also accepts the compact form where every key/value pair is
  // packed into the tag's sole field.
  if (rawFields.length === 1) {
    const parts = rawFields[0]!.trim().split(/\s+/);
    for (let index = 0; index + 1 < parts.length; index += 2) {
      appendImetaField(fields, parts[index]!.toLowerCase(), parts[index + 1]!);
    }
    return fields;
  }

  for (const rawField of rawFields) {
    const field = rawField.trim();
    const separator = field.search(/\s/);
    if (separator <= 0) {
      continue;
    }

    const key = field.slice(0, separator).toLowerCase();
    const value = field.slice(separator).trim();
    appendImetaField(fields, key, value);
  }
  return fields;
}

function firstImetaField(fields: Map<string, string[]>, key: string): string | undefined {
  return fields.get(key)?.[0];
}

function getImetaMediaMetadata(fields: Map<string, string[]>): NoteEmbedMediaMetadata {
  const sha256 = fields
    .get('x')
    ?.map((value) => value.trim())
    .find((value) => /^[0-9a-f]{64}$/i.test(value))
    ?.toLowerCase();
  const fallbackUrls: string[] = [];
  const seen = new Set<string>();

  for (const value of fields.get('fallback') ?? []) {
    if (fallbackUrls.length >= MAX_IMETA_FALLBACK_URLS) {
      break;
    }

    const url = value.trim();
    if (!url || url.length > MAX_IMETA_FALLBACK_URL_LENGTH || seen.has(url)) {
      continue;
    }

    try {
      const parsed = new URL(url);
      if (parsed.protocol !== 'https:' || !parsed.hostname || parsed.username || parsed.password) {
        continue;
      }
    } catch {
      continue;
    }

    seen.add(url);
    fallbackUrls.push(url);
  }

  return {
    ...(sha256 ? { sha256 } : {}),
    ...(fallbackUrls.length > 0 ? { fallbackUrls } : {}),
  };
}

function createEmbedFromImeta(tag: string[]): NoteEmbed | null {
  if (tag[0]?.toLowerCase() !== 'imeta') {
    return null;
  }

  const fields = parseImetaFields(tag);
  const rawUrl = firstImetaField(fields, 'url');
  if (!rawUrl) {
    return null;
  }

  const url = trimTrailingPunctuation(rawUrl);
  const hashtreeAttachment = parseHashtreeAttachment(url);
  if (!hashtreeAttachment && !safeExternalUrl(url)) {
    return null;
  }

  const mimeType = firstImetaField(fields, 'm')?.toLowerCase() ?? '';
  const label = firstImetaField(fields, 'alt')?.trim() || undefined;
  const mediaMetadata = getImetaMediaMetadata(fields);
  const attachmentMetadata = hashtreeAttachment
    ? { isHashtree: true as const, filename: hashtreeAttachment.filename }
    : {};

  if (mimeType.startsWith('image/')) {
    return { kind: 'image', url, ...attachmentMetadata, ...mediaMetadata, label };
  }
  if (mimeType.startsWith('video/')) {
    return { kind: 'video', url, ...attachmentMetadata, ...mediaMetadata, label };
  }
  if (mimeType.startsWith('audio/')) {
    return { kind: 'audio', url, ...attachmentMetadata, ...mediaMetadata, label };
  }

  const inferred = createEmbedFromUrl(url);
  return inferred ? { ...inferred, ...mediaMetadata, ...(label ? { label } : {}) } : null;
}

function classifyMatch(text: string, emojiMap: Map<string, string>): NoteContentSegment {
  const hashtagMatch = text.match(/^(\s)?#([a-zA-Z0-9_\u0080-\uFFFF]+)$/);
  if (hashtagMatch) {
    return { type: 'hashtag', tag: hashtagMatch[2] ?? '' };
  }

  if (text.startsWith(':') && text.endsWith(':')) {
    const shortcode = text.slice(1, -1);
    const url = emojiMap.get(shortcode);
    if (url) {
      return { type: 'emoji', shortcode, url };
    }
  }

  if (text.startsWith('nostr:')) {
    return createNostrReferenceSegment(text);
  }

  if (createEmbedFromUrl(text)) {
    return { type: 'attachment', urls: [trimTrailingPunctuation(text)] };
  }

  if (isExternalHttpUrl(text)) {
    return { type: 'link', urls: [trimTrailingPunctuation(text)] };
  }

  return { type: 'text', text };
}

function collectMatches(content: string): MatchWithIndex[] {
  const matches: MatchWithIndex[] = [];

  for (const pattern of Object.values(PATTERNS)) {
    pattern.lastIndex = 0;
    let match = pattern.exec(content);
    while (match !== null) {
      matches.push({ match, index: match.index });
      match = pattern.exec(content);
    }
  }

  return matches.sort((left, right) => left.index - right.index);
}

function isWhitespaceOnly(text: string): boolean {
  return /^\s*$/.test(text);
}

function groupConsecutiveAttachments(segments: NoteContentSegment[]): NoteContentSegment[] {
  const result: NoteContentSegment[] = [];
  let attachmentBuffer: string[] = [];
  let whitespaceBuffer: NoteContentSegment[] = [];

  function flushAttachments(): void {
    if (attachmentBuffer.length === 0) {
      return;
    }

    result.push({ type: 'attachment', urls: [...attachmentBuffer] });
    attachmentBuffer = [];
    whitespaceBuffer = [];
  }

  function flushWhitespace(): void {
    result.push(...whitespaceBuffer);
    whitespaceBuffer = [];
  }

  for (const segment of segments) {
    if (segment.type === 'attachment' && segment.urls.length === 1) {
      attachmentBuffer.push(segment.urls[0]!);
      continue;
    }

    if (segment.type === 'text' && isWhitespaceOnly(segment.text) && attachmentBuffer.length > 0) {
      whitespaceBuffer.push(segment);
      continue;
    }

    flushAttachments();
    flushWhitespace();
    result.push(segment);
  }

  flushAttachments();
  return result;
}

export function parseNoteContent(content: string, tags: string[][] = []): NoteContentSegment[] {
  const emojiMap = buildEmojiMap(tags);
  const matches = collectMatches(content);
  const segments: NoteContentSegment[] = [];
  let lastIndex = 0;

  for (const { match, index } of matches) {
    if (index < lastIndex) {
      continue;
    }

    if (index > lastIndex) {
      segments.push({ type: 'text', text: content.slice(lastIndex, index) });
    }

    if (/^\s?#[a-zA-Z0-9_\u0080-\uFFFF]+$/.test(match[0])) {
      const hashtagMatch = match[0].match(/^(\s)?#([a-zA-Z0-9_\u0080-\uFFFF]+)$/);
      if (hashtagMatch?.[1]) {
        segments.push({ type: 'text', text: hashtagMatch[1] });
      }
      segments.push({ type: 'hashtag', tag: hashtagMatch?.[2] ?? '' });
    } else {
      segments.push(classifyMatch(match[0], emojiMap));
    }

    lastIndex = index + match[0].length;
  }

  if (lastIndex < content.length) {
    segments.push({ type: 'text', text: content.slice(lastIndex) });
  }

  return groupConsecutiveAttachments(segments);
}

function extractNoteEmbedGroupsFromSegments(
  tags: string[][],
  eventKind: number | undefined,
  segments: NoteContentSegment[],
): NoteEmbed[][] {
  const groups: NoteEmbed[][] = [];
  const seen = new Set<string>();
  const contentUrls = new Set(
    segments.flatMap((segment) => (
      segment.type === 'attachment' || segment.type === 'link' ? segment.urls : []
    )),
  );

  const appendGroup = (candidates: Array<NoteEmbed | null>): void => {
    const group: NoteEmbed[] = [];
    for (const embed of candidates) {
      if (!embed || seen.has(embed.url)) {
        continue;
      }
      seen.add(embed.url);
      group.push(embed);
    }

    if (group.length > 0) {
      groups.push(group);
    }
  };

  // NIP-68 picture-first posts carry their media only in NIP-92 `imeta` tags.
  // Other event kinds must reference the exact URL in their content: some
  // legacy clients accidentally retained metadata after an upload URL was
  // removed from the composer.
  appendGroup(tags.map((tag) => {
    const embed = createEmbedFromImeta(tag);
    return embed && (eventKind === 20 || contentUrls.has(embed.url)) ? embed : null;
  }));

  for (const segment of segments) {
    if (segment.type !== 'attachment') {
      continue;
    }

    appendGroup(segment.urls.map(createEmbedFromUrl));
  }

  return groups;
}

export function extractNoteEmbedGroups(
  content: string,
  tags: string[][] = [],
  eventKind?: number,
): NoteEmbed[][] {
  return extractNoteEmbedGroupsFromSegments(tags, eventKind, parseNoteContent(content, tags));
}

/** Parse an immutable event once for both its text and embed components. */
export function getNotePresentation(event: NotePresentationInput): NotePresentation {
  const cached = notePresentationCache.get(event);
  if (
    cached
    && cached.content === event.content
    && cached.tags === event.tags
    && cached.kind === event.kind
  ) {
    return cached;
  }

  const segments = parseNoteContent(event.content, event.tags);
  const presentation: CachedNotePresentation = {
    content: event.content,
    tags: event.tags,
    kind: event.kind,
    segments,
    embedGroups: extractNoteEmbedGroupsFromSegments(event.tags, event.kind, segments),
  };
  notePresentationCache.set(event, presentation);
  return presentation;
}

export function extractNoteEmbeds(
  content: string,
  tags: string[][] = [],
  eventKind?: number,
): NoteEmbed[] {
  return extractNoteEmbedGroups(content, tags, eventKind).flat();
}

export function buildNotePreviewText(content: string, tags: string[][] = [], maxLength = 180): string {
  const text = parseNoteContent(content, tags)
    .map((segment) => {
      switch (segment.type) {
        case 'text':
          return segment.text;
        case 'mention':
          return `@${segment.label}`;
        case 'event-ref':
          return '';
        case 'link':
          return segment.urls.join(' ');
        case 'attachment':
          return '';
        case 'emoji':
          return `:${segment.shortcode}:`;
        case 'hashtag':
          return `#${segment.tag}`;
      }
    })
    .join('')
    .replace(/\s+/g, ' ')
    .trim();

  if (!text) {
    return '';
  }

  if (text.length <= maxLength) {
    return text;
  }

  return `${text.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`;
}
