import type { SocialAccount } from './accounts';
import type { ProfileRecord, RawEvent } from './nostr';
import { canPublishFromAccount } from './nostrPublish';
import {
  DEFAULT_ZAP_BITS,
  createZapInvoice,
  getZapEndpointUrl,
  payZapInvoice,
  type ZapAllLogEntry,
  type ZapAllRunOptions,
} from './zaps';

type ZapActionDeps = {
  activeAccount: SocialAccount | null;
  pageError: string;
  zapAllCompleted: boolean;
  zapAllError: string;
  zapAllEvents: RawEvent[];
  zapAllLogs: ZapAllLogEntry[];
  zapAllProgress: number;
  zapAllRunning: boolean;
  zapAllSheetOpen: boolean;
  zapAllSpentBits: number;
  zapPendingNoteIds: Set<string>;
  reportError: (fallbackMessage: string, error: unknown) => string;
  resolveProfile: (pubkey: string) => ProfileRecord | null;
};

export function createAppZapActions(deps: ZapActionDeps) {
  async function handleZap(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (deps.zapPendingNoteIds.has(event.id)) {
      return;
    }
    const profile = deps.resolveProfile(event.pubkey);
    if (!getZapEndpointUrl(profile)) {
      deps.pageError = 'This author has no Lightning address.';
      return;
    }
    deps.zapPendingNoteIds = new Set(deps.zapPendingNoteIds).add(event.id);
    deps.pageError = '';
    try {
      const zap = await createZapInvoice({
        account,
        target: event,
        profile,
        amountBits: DEFAULT_ZAP_BITS,
      });
      await payZapInvoice(zap.invoice, {
        expectedBits: zap.amountBits,
        intentId: zap.zapRequest.id,
      });
    } catch (error) {
      deps.pageError = deps.reportError("Couldn't prepare this zap.", error);
    } finally {
      const nextPending = new Set(deps.zapPendingNoteIds);
      nextPending.delete(event.id);
      deps.zapPendingNoteIds = nextPending;
    }
  }

  function openZapAll(events: RawEvent[]): void {
    deps.zapAllEvents = [...events];
    deps.zapAllSheetOpen = true;
    deps.zapAllRunning = false;
    deps.zapAllCompleted = false;
    deps.zapAllProgress = 0;
    deps.zapAllSpentBits = 0;
    deps.zapAllError = '';
    deps.zapAllLogs = [];
  }

  function appendZapAllLog(entry: Omit<ZapAllLogEntry, 'id'>): void {
    deps.zapAllLogs = [
      ...deps.zapAllLogs,
      {
        ...entry,
        id: `${Date.now()}:${deps.zapAllLogs.length}:${entry.eventId}`,
      },
    ];
  }

  async function handleZapAllStart(options: ZapAllRunOptions): Promise<void> {
    if (deps.zapAllRunning) {
      return;
    }
    const account = deps.activeAccount;
    if (!account || !canPublishFromAccount(account)) {
      deps.zapAllError = 'Writable account required.';
      return;
    }
    const amountBits = Math.max(1, Math.floor(options.amountBits));
    const maxBudgetBits = Math.max(amountBits, Math.floor(options.maxBudgetBits));
    let spentBits = 0;
    deps.zapAllRunning = true;
    deps.zapAllCompleted = false;
    deps.zapAllProgress = 0;
    deps.zapAllSpentBits = 0;
    deps.zapAllError = '';
    deps.zapAllLogs = [];
    try {
      for (const event of deps.zapAllEvents) {
        if (spentBits + amountBits > maxBudgetBits) {
          appendZapAllLog({
            type: 'skip',
            message: 'Budget reached',
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          break;
        }
        const profile = deps.resolveProfile(event.pubkey);
        if (!getZapEndpointUrl(profile)) {
          appendZapAllLog({
            type: 'skip',
            message: 'No Lightning address',
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          deps.zapAllProgress += 1;
          continue;
        }
        try {
          const zap = await createZapInvoice({
            account,
            target: event,
            profile,
            amountBits,
            comment: options.comment,
          });
          await payZapInvoice(zap.invoice, {
            requireWebLn: true,
            expectedBits: zap.amountBits,
            intentId: zap.zapRequest.id,
          });
          spentBits += amountBits;
          deps.zapAllSpentBits = spentBits;
          appendZapAllLog({
            type: 'success',
            message: `Zapped ${amountBits} bits`,
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Couldn't zap this post.";
          appendZapAllLog({
            type: 'error',
            message,
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          if (
            message.toLowerCase().includes('webln')
            || (error instanceof Error
              && 'paymentStarted' in error
              && error.paymentStarted === true)
          ) {
            deps.zapAllError = message;
            break;
          }
        } finally {
          deps.zapAllProgress += 1;
        }
      }
    } finally {
      deps.zapAllCompleted = true;
      deps.zapAllRunning = false;
    }
  }

  return { handleZap, handleZapAllStart, openZapAll };
}
