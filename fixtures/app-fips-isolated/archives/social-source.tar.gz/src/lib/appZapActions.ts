import type { AppError, ReportAppError } from './appError';
import type { SocialAccount } from './accounts';
import { addOptimisticZap } from './appViewState';
import type { OptimisticNoteEngagement } from './appDataUtils';
import { parseBolt11PaymentHash } from './bolt11';
import type { ProfileRecord, RawEvent } from './nostr';
import { canPublishFromAccount } from './nostrPublish';
import { settingsStore } from './settings';
import { openZapDialog } from './zapDialog';
import {
  canPayZapWithWallet,
  createZapInvoice,
  getZapEndpointUrl,
  payZapInvoiceWithWallet,
  type ZapAllLogEntry,
  type ZapAllRunOptions,
  type ZapWalletMethod,
} from './zaps';

type ZapActionDeps = {
  activeAccount: SocialAccount | null;
  optimisticNoteEngagements: Map<string, OptimisticNoteEngagement>;
  pageError: AppError;
  zapAllCompleted: boolean;
  zapAllError: string;
  zapAllEvents: RawEvent[];
  zapAllLogs: ZapAllLogEntry[];
  zapAllProgress: number;
  zapAllRunning: boolean;
  zapAllSheetOpen: boolean;
  zapAllSpentBits: number;
  zapPendingNoteIds: Set<string>;
  reportError: ReportAppError;
  resolveProfile: (pubkey: string) => ProfileRecord | null;
};

export type ZapRequestOptions = { amountBits: number; comment?: string };

/** A wallet paid, or the invoice is left for the viewer to pay elsewhere. */
export type ZapOutcome =
  | { status: 'paid'; method: ZapWalletMethod }
  | { status: 'invoice'; invoice: string; amountBits: number };

export function createAppZapActions(deps: ZapActionDeps) {
  function setZapPending(noteId: string, pending: boolean): void {
    const next = new Set(deps.zapPendingNoteIds);
    if (pending) {next.add(noteId);} else {next.delete(noteId);}
    deps.zapPendingNoteIds = next;
  }

  function publishingAccount(): SocialAccount {
    const account = deps.activeAccount;
    if (!account) {throw new Error('Sign in to zap.');}
    if (!canPublishFromAccount(account)) {throw new Error('This profile is read-only.');}
    return account;
  }

  async function zapWithAccount(
    account: SocialAccount,
    event: RawEvent,
    profile: ProfileRecord | null,
    options: ZapRequestOptions,
  ): Promise<ZapOutcome> {
    const zap = await createZapInvoice({
      account,
      target: event,
      profile,
      amountBits: options.amountBits,
      comment: options.comment?.trim() || undefined,
    });
    const method = await payZapInvoiceWithWallet(zap.invoice, {
      expectedBits: zap.amountBits,
      intentId: zap.zapRequest.id,
    });
    if (!method) {return { status: 'invoice', invoice: zap.invoice, amountBits: zap.amountBits };}
    if (deps.activeAccount?.pubkey === account.pubkey) {
      deps.optimisticNoteEngagements = addOptimisticZap(deps.optimisticNoteEngagements, event.id, {
        key: parseBolt11PaymentHash(zap.invoice) ?? zap.invoice.trim().toLowerCase(),
        millisats: zap.amountMillisats,
        sender: account.pubkey,
      });
    }
    return { status: 'paid', method };
  }

  /** Signs and pays one zap chosen in the zap dialog. */
  async function sendZap(
    event: RawEvent,
    profile: ProfileRecord | null,
    options: ZapRequestOptions,
  ): Promise<ZapOutcome> {
    const account = publishingAccount();
    if (deps.zapPendingNoteIds.has(event.id)) {throw new Error('A zap for this post is already in progress.');}
    setZapPending(event.id, true);
    try {
      return await zapWithAccount(account, event, profile, options);
    } finally {
      setZapPending(event.id, false);
    }
  }

  /** One tap zaps the default amount with a wallet; otherwise it asks how much. */
  async function handleZap(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    if (deps.zapPendingNoteIds.has(event.id)) {
      return;
    }
    const profile = deps.resolveProfile(event.pubkey);
    if (!getZapEndpointUrl(profile)) {
      deps.pageError = 'This author has no Lightning address.';
      return;
    }
    const { defaultZapBits, defaultZapComment } = settingsStore.getState().wallet;
    setZapPending(event.id, true);
    deps.pageError = '';
    try {
      if (defaultZapBits <= 0 || !await canPayZapWithWallet(defaultZapBits)) {
        openZapDialog(event, profile);
        return;
      }
      const outcome = await zapWithAccount(account, event, profile, {
        amountBits: defaultZapBits,
        comment: defaultZapComment,
      });
      if (outcome.status === 'invoice') {
        openZapDialog(event, profile, { invoice: outcome.invoice, amountBits: outcome.amountBits });
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey === account.pubkey) {deps.pageError = deps.reportError("Couldn't zap this post.", error);}
    } finally {
      setZapPending(event.id, false);
    }
  }

  function openZapAll(events: RawEvent[]): void {
    deps.zapAllEvents = [...events];
    deps.zapAllSheetOpen = true;
    deps.zapAllRunning = false;
    deps.zapAllCompleted = false;
    deps.zapAllProgress = 0;
    deps.zapAllSpentBits = 0;
    deps.zapAllError = '';
    deps.zapAllLogs = [];
  }

  function appendZapAllLog(entry: Omit<ZapAllLogEntry, 'id'>): void {
    deps.zapAllLogs = [
      ...deps.zapAllLogs,
      {
        ...entry,
        id: `${Date.now()}:${deps.zapAllLogs.length}:${entry.eventId}`,
      },
    ];
  }

  async function handleZapAllStart(options: ZapAllRunOptions): Promise<void> {
    if (deps.zapAllRunning) {
      return;
    }
    const account = deps.activeAccount;
    if (!account || !canPublishFromAccount(account)) {
      deps.zapAllError = 'Sign in with a profile that can publish.';
      return;
    }
    const amountBits = Math.max(1, Math.floor(options.amountBits));
    const maxBudgetBits = Math.max(amountBits, Math.floor(options.maxBudgetBits));
    let spentBits = 0;
    deps.zapAllRunning = true;
    deps.zapAllCompleted = false;
    deps.zapAllProgress = 0;
    deps.zapAllSpentBits = 0;
    deps.zapAllError = '';
    deps.zapAllLogs = [];
    try {
      for (const event of deps.zapAllEvents) {
        if (spentBits + amountBits > maxBudgetBits) {
          appendZapAllLog({
            type: 'skip',
            message: 'Budget reached',
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          break;
        }
        const profile = deps.resolveProfile(event.pubkey);
        if (!getZapEndpointUrl(profile)) {
          appendZapAllLog({
            type: 'skip',
            message: 'No Lightning address',
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          deps.zapAllProgress += 1;
          continue;
        }
        try {
          const zap = await createZapInvoice({
            account,
            target: event,
            profile,
            amountBits,
            comment: options.comment,
          });
          const method = await payZapInvoiceWithWallet(zap.invoice, {
            expectedBits: zap.amountBits,
            intentId: zap.zapRequest.id,
          });
          if (!method) {throw new Error('WebLN wallet required for zap all.');}
          spentBits += amountBits;
          deps.zapAllSpentBits = spentBits;
          appendZapAllLog({
            type: 'success',
            message: `Zapped ${amountBits} bits`,
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Couldn't zap this post.";
          appendZapAllLog({
            type: 'error',
            message,
            eventId: event.id,
            authorPubkey: event.pubkey,
          });
          if (
            message.toLowerCase().includes('webln')
            || (error instanceof Error
              && 'paymentStarted' in error
              && error.paymentStarted === true)
          ) {
            deps.zapAllError = message;
            break;
          }
        } finally {
          deps.zapAllProgress += 1;
        }
      }
    } finally {
      deps.zapAllCompleted = true;
      deps.zapAllRunning = false;
    }
  }

  return { handleZap, handleZapAllStart, openZapAll, sendZap };
}
