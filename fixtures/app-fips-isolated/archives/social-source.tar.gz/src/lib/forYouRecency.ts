import type { RawEvent } from './nostr';
const FOR_YOU_RECENT_WINDOW_SECONDS = 7 * 24 * 60 * 60;
const FOR_YOU_MIN_RECENT_POSTS = 8;

/**
 * A lagging archive must not fill For You with weeks-old posts. Keep posts
 * from the last week, and fall back to the full pool only when too few exist.
 */
export function preferRecentForYouPosts(posts: RawEvent[], now = Date.now()): RawEvent[] {
  const cutoff = Math.floor(now / 1_000) - FOR_YOU_RECENT_WINDOW_SECONDS;
  const recent = posts.filter((event) => event.created_at >= cutoff);
  return recent.length >= FOR_YOU_MIN_RECENT_POSTS ? recent : posts;
}
