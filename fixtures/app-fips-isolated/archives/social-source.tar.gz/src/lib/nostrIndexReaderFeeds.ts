import type { CollectionSource } from '@hashtree/collection';
import type { CID } from '@hashtree/core';
import {
  MANIFEST_BY_AUTHOR_KIND_TIME,
  MANIFEST_BY_KIND_TIME,
  type NostrEventStore,
} from '@hashtree/nostr';
import { verifyAndAsRawEvent } from './nostrIndexEvent';
import { NostrIndexRecentMerge } from './nostrIndexRecentMerge';
import { isHexPubkey, isReplyEvent, type RawEvent } from './nostr';
import { mergeRecentEvents } from './nostrEventMerge';
import type { NostrCollectionIndexes } from './nostrCollectionIndexes';
import {
  DURABLE_POST_KINDS,
  RecentAuthorFeedReader,
} from './recentAuthorFeedReader';
import {
  createdAtFromKindTimeIndexKey,
  isStrictlyBeforeRecentCursor,
  streamTimeOrderedIndex,
  type RecentTextNoteQueryOptions,
} from './recentTextNoteCursor';

const RECENT_NOTE_SCAN_BATCH = 16;
const MIN_RECENT_NOTE_SCAN_LIMIT = 128;
const RECENT_NOTE_SCAN_MULTIPLIER = 96;
const INDEX_COLLECTION_SOURCE_GRACE_MS = 600;
export const NOSTR_INDEX_INTERACTION_KINDS = [6, 7] as const;

export type NostrIndexReaderFeedDependencies = {
  eventStore: NostrEventStore;
  getCollectionIndexes: (
    options?: { timeoutMs?: number },
  ) => Promise<NostrCollectionIndexes>;
  getCollectionSource: () => Promise<CollectionSource>;
  indexedEventReadConcurrency: number;
  readEvent: (cid: CID) => Promise<RawEvent | null>;
  verifyStoredEvent?: (event: import('@hashtree/nostr').StoredNostrEvent) => Promise<RawEvent | null>;
  verifyStoredEvents?: (events: import('@hashtree/nostr').StoredNostrEvent[]) => Promise<RawEvent[]>;
  recentMerge: NostrIndexRecentMerge;
  root: CID;
  signal: AbortSignal | null;
  useWorkerHomeFeedQuery: boolean;
};

function padKind(kind: number): string {
  return kind.toString(16).padStart(8, '0');
}

function getRecentTextNoteKinds(options: RecentTextNoteQueryOptions): readonly number[] {
  return [...new Set(options.kinds ?? DURABLE_POST_KINDS)];
}

function isWithinRecentTextNoteTime(
  event: RawEvent,
  options: RecentTextNoteQueryOptions,
): boolean {
  return (options.since === undefined || event.created_at >= options.since)
    && (options.until === undefined || event.created_at <= options.until);
}

function isFilteredPostReply(event: RawEvent): boolean {
  return event.kind === 1 && isReplyEvent(event);
}

export class NostrIndexReaderFeeds {
  private readonly eventStore: NostrEventStore;
  private readonly getCollectionIndexes: NostrIndexReaderFeedDependencies['getCollectionIndexes'];
  private readonly getCollectionSource: () => Promise<CollectionSource>;
  private readonly indexedEventReadConcurrency: number;
  private readonly readEvent: (cid: CID) => Promise<RawEvent | null>;
  private readonly verifyStoredEvent: (event: import('@hashtree/nostr').StoredNostrEvent) => Promise<RawEvent | null>;
  private readonly verifyStoredEvents: (events: import('@hashtree/nostr').StoredNostrEvent[]) => Promise<RawEvent[]>;
  private readonly recentMerge: NostrIndexRecentMerge;
  private readonly root: CID;
  private readonly signal: AbortSignal | null;
  private readonly useWorkerHomeFeedQuery: boolean;

  constructor(dependencies: NostrIndexReaderFeedDependencies) {
    this.eventStore = dependencies.eventStore;
    this.getCollectionIndexes = dependencies.getCollectionIndexes;
    this.getCollectionSource = dependencies.getCollectionSource;
    this.indexedEventReadConcurrency = dependencies.indexedEventReadConcurrency;
    this.readEvent = dependencies.readEvent;
    this.verifyStoredEvent = dependencies.verifyStoredEvent ?? verifyAndAsRawEvent;
    this.verifyStoredEvents = dependencies.verifyStoredEvents ?? (async (events) => (
      (await Promise.all(events.map(async (event) => await this.verifyStoredEvent(event))))
        .filter((event): event is RawEvent => event !== null)
    ));
    this.recentMerge = dependencies.recentMerge;
    this.root = dependencies.root;
    this.signal = dependencies.signal;
    this.useWorkerHomeFeedQuery = dependencies.useWorkerHomeFeedQuery;
  }

  private async *streamEventsFromCollectionIndex(
    source: CollectionSource,
    indexName: string,
    prefix: string,
    limit?: number,
  ): AsyncGenerator<RawEvent, void, void> {
    const query = limit === undefined ? { prefix } : { prefix, limit };
    for await (const { cid } of source.streamQueryIndex(indexName, query)) {
      const event = await this.readEvent(cid);
      if (event) {
        yield event;
      }
    }
  }

  async *streamRecentTextNotesByAuthors(
    authors: string[],
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    const uniqueAuthors = [...new Set(authors)];
    if (uniqueAuthors.length === 0 || limit <= 0) {
      yield [];
      return;
    }

    if (this.useWorkerHomeFeedQuery) {
      const worker = await (await import('./workerClient')).getWorkerClient();
      yield* worker.streamHomeFeedNotes(this.root, uniqueAuthors, limit, {
        before: options.before,
        emitEvery: options.emitEvery,
        includeReplies: options.includeReplies,
        kinds: options.kinds,
        since: options.since,
        signal: this.signal ?? undefined,
        until: options.until,
      });
      return;
    }

    yield* new RecentAuthorFeedReader({
      getCollectionIndexes: async (readerOptions) => await this.getCollectionIndexes(readerOptions),
      getCollectionSource: async () => await this.getCollectionSource(),
      indexedEventReadConcurrency: this.indexedEventReadConcurrency,
      readEvent: async (cid) => await this.readEvent(cid),
      signal: this.signal,
    }).stream(uniqueAuthors, limit, options);
  }

  private async getRecentTextNotesByKindTime(
    authorSet: Set<string> | null,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    const maxScanned = Math.max(MIN_RECENT_NOTE_SCAN_LIMIT, limit * RECENT_NOTE_SCAN_MULTIPLIER);
    const source = await this.getCollectionSource();
    const eventSets = await Promise.all(getRecentTextNoteKinds(options).map(async (kind) => {
      const events: RawEvent[] = [];
      const seenIds = new Set<string>();
      let scanned = 0;
      let batch: Array<{ cid: CID }> = [];

      const flushBatch = async (): Promise<void> => {
        if (batch.length === 0) {
          return;
        }

        const decodedBatch = await Promise.all(
          batch.map(async ({ cid }) => await this.readEvent(cid)),
        );
        batch = [];

        for (const event of decodedBatch) {
          if (!event || seenIds.has(event.id)) {
            continue;
          }
          if (
            event.kind !== kind
            || (authorSet && !authorSet.has(event.pubkey))
            || !isWithinRecentTextNoteTime(event, options)
            || (!options.includeReplies && isFilteredPostReply(event))
          ) {
            continue;
          }

          seenIds.add(event.id);
          events.push(event);

          if (events.length >= limit) {
            break;
          }
        }
      };

      const hasTimeBounds = options.since !== undefined || options.until !== undefined || Boolean(options.before);
      for await (const { key, cid } of streamTimeOrderedIndex(
        source,
        MANIFEST_BY_KIND_TIME,
        `${padKind(kind)}:`,
        options.before,
        hasTimeBounds ? undefined : maxScanned,
      )) {
        const createdAt = createdAtFromKindTimeIndexKey(key);
        if (options.until !== undefined && createdAt > options.until) {
          continue;
        }
        const eventId = key.split(':').at(-1) ?? '';
        if (!isStrictlyBeforeRecentCursor(createdAt, eventId, options.before)) {
          continue;
        }
        if (options.since !== undefined && createdAt < options.since) {
          break;
        }
        batch.push({ cid });
        scanned += 1;

        if (batch.length >= RECENT_NOTE_SCAN_BATCH) {
          await flushBatch();
        }

        if (events.length >= limit || scanned >= maxScanned) {
          break;
        }
      }

      await flushBatch();
      return events;
    }));

    return mergeRecentEvents(limit, ...eventSets);
  }

  async getRecentTextNotes(
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    if (limit <= 0) {
      return [];
    }

    const { byKindTime } = await this.getCollectionIndexes({
      timeoutMs: INDEX_COLLECTION_SOURCE_GRACE_MS,
    });
    if (!byKindTime) {
      return [];
    }

    return await this.getRecentTextNotesByKindTime(null, limit, options);
  }

  async getRecentInteractionsByAuthors(
    authors: string[],
    limit: number,
    kinds: readonly number[] = NOSTR_INDEX_INTERACTION_KINDS,
  ): Promise<RawEvent[]> {
    const uniqueAuthors = [...new Set(authors)].filter((pubkey) => isHexPubkey(pubkey)).slice(0, 128);
    if (uniqueAuthors.length === 0 || kinds.length === 0 || limit <= 0) {
      return [];
    }

    const { byAuthorKindTime } = await this.getCollectionIndexes({ timeoutMs: INDEX_COLLECTION_SOURCE_GRACE_MS });
    if (!byAuthorKindTime) {
      return [];
    }

    const source = await this.getCollectionSource();
    const iterators = uniqueAuthors.flatMap((author) => kinds.map((kind) => (
      this.streamEventsFromCollectionIndex(
        source, MANIFEST_BY_AUTHOR_KIND_TIME, `${author}:${padKind(kind)}:`, limit,
      )[Symbol.asyncIterator]()
    )));
    let latestEvents: RawEvent[] = [];
    for await (const events of this.recentMerge.streamMergedRecentNoteIterators(
      iterators, new Set(kinds), limit, { includeReplies: true },
      'Failed to stream recent indexed interactions by author',
    )) {
      latestEvents = events;
    }
    return latestEvents;
  }

  async getRecentTextNotesByAuthors(
    authors: string[],
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    let latestNotes: RawEvent[] = [];
    for await (const notes of this.streamRecentTextNotesByAuthors(authors, limit, options)) {
      latestNotes = notes;
    }
    return latestNotes;
  }

  async getRecentTextNotesByAuthor(
    pubkey: string,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    // A single-author lookup is the direct profile-post path. Waiting for its
    // author index to finish a cold fetch is better than reporting an empty
    // profile after the generic feed grace window and retrying the whole view.
    // Once that exact index is available, an empty prefix is authoritative;
    // falling through would scan broad global indexes for a pubkey they cannot
    // contain and can hold sparse profiles in a loading state for seconds.
    const { byAuthorKindTime } = await this.getCollectionIndexes();
    if (byAuthorKindTime) {
      return await this.getRecentTextNotesBySingleAuthor(pubkey, limit, options);
    }

    return await this.getRecentTextNotesByAuthors([pubkey], limit, options);
  }

  async *streamRecentTextNotesByAuthor(
    pubkey: string,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    if (this.useWorkerHomeFeedQuery) {
      let workerCompleted = false;
      try {
        for await (const notes of this.streamRecentTextNotesByAuthors(
          [pubkey],
          limit,
          options,
        )) {
          if (notes.length === 0) {
            continue;
          }
          yield notes;
        }
        workerCompleted = true;
      } catch (error) {
        console.warn('Failed to stream profile notes from the warm worker', error);
      }
      if (workerCompleted) {
        return;
      }
    }

    // Keep profile streaming progressive, but do not let the feed-oriented
    // collection-source grace period turn a slow first block into a false
    // empty result. Once the source is available, the author index emits the
    // first post without waiting for the complete page.
    const { byAuthorKindTime } = await this.getCollectionIndexes();
    if (byAuthorKindTime) {
      let yieldedAny = false;
      for await (const notes of this.recentMerge.streamRecentTextNotesByAuthorKindTime(
        [pubkey], limit, options,
      )) {
        yieldedAny = true;
        yield notes;
      }
      if (yieldedAny) {
        return;
      }
      // The exact author/kind prefixes completed without a row. Do not follow
      // that authoritative miss with the feed-oriented global scan.
      yield [];
      return;
    }

    yield* this.streamRecentTextNotesByAuthors([pubkey], limit, options);
  }

  private async getRecentTextNotesBySingleAuthor(
    pubkey: string,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    if (limit <= 0) {
      return [];
    }

    const batchSize = Math.max(
      options.singleAuthorBatchSize ?? 0,
      limit,
      Math.min(limit * (options.singleAuthorScanMultiplier ?? 3), 256),
    );
    const eventSets = await Promise.all(getRecentTextNoteKinds(options).map(async (kind) => (
      await this.getRecentPostsBySingleAuthorKind(pubkey, kind, limit, batchSize, options)
    )));

    return mergeRecentEvents(limit, ...eventSets);
  }

  private async getRecentPostsBySingleAuthorKind(
    pubkey: string,
    kind: number,
    limit: number,
    batchSize: number,
    options: RecentTextNoteQueryOptions,
  ): Promise<RawEvent[]> {
    const includeReplies = options.includeReplies ?? false;
    const events: RawEvent[] = [];
    const seenIds = new Set<string>();
    if (options.before) {
      for await (const storedEvent of this.eventStore.streamByAuthorAndKind(
        this.root,
        pubkey,
        kind,
        {
          since: options.since,
          until: Math.min(options.until ?? options.before.createdAt, options.before.createdAt),
        },
      )) {
        const event = await this.verifyStoredEvent(storedEvent);
        if (
          !event
          || seenIds.has(event.id)
          || !isStrictlyBeforeRecentCursor(event.created_at, event.id, options.before)
          || (!includeReplies && isFilteredPostReply(event))
        ) {
          continue;
        }
        seenIds.add(event.id);
        events.push(event);
        if (events.length >= limit) {
          break;
        }
      }
      return events;
    }

    let cursorUntil = options.until;

    while (events.length < limit) {
      const batch = await this.eventStore.listByAuthorAndKind(this.root, pubkey, kind, {
        limit: batchSize,
        since: options.since,
        until: cursorUntil,
      });

      if (batch.length === 0) {
        break;
      }

      for (const event of await this.verifyStoredEvents(batch)) {
        if (
          !event
          || seenIds.has(event.id)
          || event.kind !== kind
          || (!includeReplies && isFilteredPostReply(event))
        ) {
          continue;
        }

        seenIds.add(event.id);
        events.push(event);
        if (events.length >= limit) {
          break;
        }
      }

      if (batch.length < batchSize) {
        break;
      }

      const oldestCreatedAt = batch[batch.length - 1]?.created_at;
      if (typeof oldestCreatedAt !== 'number') {
        break;
      }

      if (cursorUntil !== undefined && oldestCreatedAt >= cursorUntil) {
        cursorUntil -= 1;
      } else {
        cursorUntil = oldestCreatedAt - 1;
      }

      if (options.since !== undefined && cursorUntil < options.since) {
        break;
      }
    }

    return events;
  }
}
