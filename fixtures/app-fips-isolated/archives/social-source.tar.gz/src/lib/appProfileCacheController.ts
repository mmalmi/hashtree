import type { CID } from '@hashtree/core';
import { accountsStore } from './accounts';
import { hydrateAccountProfiles as loadAccountProfiles } from './appAccountState';
import type { AppCombinedState } from './appState';
import {
  prependLocalPost as prependLocalPostToState,
  writeLocalPostsToStorage,
} from './appNoteState';
import {
  getProfilesSubset,
  mergeProfilesIntoMap,
} from './appProfiles';
import { getVerifiedEmbeddedRepostTarget } from './repostPresentation';
import type { createKnownNotesCache } from './appDataUtils';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  applySocialGraphMetricsToProfileMap,
} from './socialGraph';
import { socialDataPlane } from './socialDataPlane';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  getSharedProfileRecord,
  rememberProfileRecords,
} from './profileCache';

type ProfileCacheControllerDeps = {
  state: AppCombinedState;
  knownNotesCache: ReturnType<typeof createKnownNotesCache>;
};

export function createAppProfileCacheController(deps: ProfileCacheControllerDeps) {
  const { state } = deps;
  let knownProfileNotesKey = '';
  let knownProfileNotesSnapshot: RawEvent[] = [];

  async function hydrateAccountProfiles(currentRoot: CID): Promise<void> {
    const pubkeys = [...new Set(accountsStore.getState().accounts.map((account) => account.pubkey))];
    try {
      state.accountProfiles = await loadAccountProfiles(
        currentRoot,
        pubkeys,
        state.accountProfiles,
      );
      rememberProfileRecords(state.accountProfiles.values());
    } catch (error) {
      console.warn('Failed to load account profiles', error);
    }
  }

  function mergeCachedProfiles(profiles: Map<string, ProfileRecord>): void {
    rememberProfileRecords(profiles.values());
    state.accountProfiles = mergeProfilesIntoMap(
      state.accountProfiles,
      applySocialGraphMetricsToProfileMap(profiles),
    );
  }

  function getCachedProfiles(pubkeys: string[]): Map<string, ProfileRecord> {
    return getProfilesSubset(state.accountProfiles, pubkeys);
  }

  function prependLocalPost(event: RawEvent): void {
    state.localPostsByAuthor = prependLocalPostToState(state.localPostsByAuthor, event);
    writeLocalPostsToStorage(state.localPostsByAuthor);
    cacheKnownNotes([event]);
  }

  function pruneTombstonedLocalPosts(): void {
    let changed = false;
    const nextLocalPosts = new Map<string, RawEvent[]>();
    for (const [pubkey, posts] of state.localPostsByAuthor) {
      const visibleIds = new Set(socialDataPlane.mergeSnapshot(posts, {
        ids: posts.map((event) => event.id),
      }).map((event) => event.id));
      const visiblePosts = posts.filter((event) => visibleIds.has(event.id));
      changed ||= visiblePosts.length !== posts.length;
      if (visiblePosts.length > 0) {
        nextLocalPosts.set(pubkey, visiblePosts);
      }
    }
    if (changed) {
      state.localPostsByAuthor = nextLocalPosts;
      writeLocalPostsToStorage(state.localPostsByAuthor);
    }
  }

  function cacheKnownNotes(...noteLists: RawEvent[][]): void {
    const visibleLists = noteLists.map((notes) => (
      socialDataPlane.filterVisibleExternalEvents(notes)
    ));
    const repostCandidates = visibleLists
      .flatMap((notes) => notes)
      .map((event) => getVerifiedEmbeddedRepostTarget(event))
      .filter((event): event is RawEvent => event !== null);
    const repostTargets = socialDataPlane.filterVisibleExternalEvents(repostCandidates);
    if (deps.knownNotesCache.cache(...visibleLists, repostTargets)) {
      state.knownNotesVersion += 1;
    }
  }

  function snapshotLocalPostSearchEvents(
    _notesVersion?: number,
    _overlayVersion?: number,
  ): RawEvent[] {
    const cached = deps.knownNotesCache.snapshot();
    return socialDataPlane.filterVisibleExternalEvents(cached);
  }

  function getCanonicalKnownNoteByRef(ref: string): RawEvent | null {
    const event = deps.knownNotesCache.getByRef(ref);
    return event && socialDataPlane.isExternalEventVisible(event) ? event : null;
  }

  function snapshotKnownProfileNotes(
    pubkey: string,
    notesVersion = state.knownNotesVersion,
  ): RawEvent[] {
    const snapshotKey = `${pubkey}:${notesVersion}:${socialDataPlane.version}`;
    if (snapshotKey === knownProfileNotesKey) {
      return knownProfileNotesSnapshot;
    }
    const cached = socialDataPlane.filterVisibleExternalEvents(
      deps.knownNotesCache.snapshotByAuthor(pubkey),
    ).filter((event) => (
      (PROFILE_CONTENT_KINDS as readonly number[]).includes(event.kind)
    ));
    knownProfileNotesKey = snapshotKey;
    // Recheck the live overlay because a deletion may arrive after the note
    // entered the canonical cache. The projection preserves the exact objects
    // rendered by Home and only walks this author's cached events.
    knownProfileNotesSnapshot = cached;
    return knownProfileNotesSnapshot;
  }

  return {
    cacheKnownNotes,
    getCachedProfiles,
    getCanonicalKnownNoteByRef,
    getSharedProfileRecord,
    hydrateAccountProfiles,
    mergeCachedProfiles,
    prependLocalPost,
    pruneTombstonedLocalPosts,
    snapshotKnownProfileNotes,
    snapshotLocalPostSearchEvents,
  };
}
