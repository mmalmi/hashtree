import {
  cloneFilter,
  verifyNostrEventsWith,
  type NostrRelayTransport,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import type { SocialWorkerClient } from './workerClient';

type RelaySubscriptionClient = Pick<SocialWorkerClient, 'subscribeRelayEvents'>;

type WorkerRelayTransportOptions = {
  getRelays(): readonly string[];
  getClient?(): Promise<RelaySubscriptionClient>;
};

/**
 * A fail-closed relay subscription proxy. Its WebSockets and Schnorr work stay
 * inside the dedicated social worker; this side only canonicalizes that
 * worker's authenticated response before exposing it to readers.
 */
export function createWorkerRelayTransport(
  options: WorkerRelayTransportOptions,
): Pick<NostrRelayTransport, 'subscribe'> {
  const getClient = options.getClient ?? defaultWorkerClient;
  return {
    subscribe(filters, handlers, subscribeOptions = {}) {
      let stopped = false;
      let terminal = false;
      let workerSubscription: { close(reason?: string): void } | null = null;
      let delivery = Promise.resolve();

      const finish = (reasons: readonly string[]): void => {
        if (terminal) {
          return;
        }
        terminal = true;
        handlers.onClose?.(reasons);
      };
      const fail = (error: unknown): void => {
        if (terminal) {
          return;
        }
        stopped = true;
        workerSubscription?.close('invalid relay worker subscription response');
        finish([errorMessage(error)]);
      };
      const enqueue = (task: () => Promise<void> | void): void => {
        delivery = delivery.then(task).catch(fail);
      };
      const relays = [...new Set(options.getRelays())];
      const clientPromise = getClient();
      void clientPromise.then((client) => {
        if (stopped) {
          return;
        }
        workerSubscription = client.subscribeRelayEvents(
          relays,
          filters.map(cloneFilter),
          {
            onEvent(rawEvent) {
              enqueue(async () => {
                if (stopped) {
                  return;
                }
                const event = await admitTrustedRelayWorkerEvent(rawEvent);
                if (!stopped) {
                  handlers.onEvent(event);
                }
              });
            },
            onClose(reasons = []) {
              enqueue(() => {
                stopped = true;
                finish(reasons);
              });
            },
          },
          { closeOnEose: subscribeOptions.closeOnEose === true },
        );
        if (stopped) {
          workerSubscription.close('stopped relay subscription before worker opened');
        }
      }).catch(fail);

      return {
        close(reason?: string) {
          if (stopped) {
            return;
          }
          stopped = true;
          workerSubscription?.close(reason);
          finish(reason === undefined ? [] : [reason]);
        },
      };
    },
  };
}

/**
 * This attestation is private to an event delivered by the tracked worker
 * subscription above. The worker's nostr-pubsub runtime already verified the
 * exact serialized event, so a second crypto pass would defeat the handoff.
 */
async function admitTrustedRelayWorkerEvent(event: RawEvent) {
  const admitted = await verifyNostrEventsWith(
    [event],
    async (trustedWorkerEvents) => trustedWorkerEvents.map(() => true),
  );
  return admitted[0]!;
}

async function defaultWorkerClient(): Promise<RelaySubscriptionClient> {
  return await (await import('./workerClient')).getWorkerClient();
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
