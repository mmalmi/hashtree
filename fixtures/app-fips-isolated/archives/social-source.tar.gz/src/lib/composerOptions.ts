import { get, writable } from 'svelte/store';
import type { ComposerAttachment } from './media';
import { clearedComposerDrafts, getBrowserDraftStorage } from './threadReplyDrafts';

/** Per-draft publishing options that Iris Client also offers: NIP-40 expiry and a geohash location. */
export type ComposerOptions = {
  /** Seconds after publishing until the note expires (NIP-40), or null. */
  expirationDelta: number | null;
  /** The most precise geohash the author chose, or null. */
  geohash: string | null;
};

export type ComposerSubmitPayload = {
  text: string;
  attachments: ComposerAttachment[];
  expirationDelta?: number | null;
  geohash?: string | null;
};

export const EMPTY_COMPOSER_OPTIONS: ComposerOptions = Object.freeze({ expirationDelta: null, geohash: null });

// The same presets as Iris Client's ExpirationSelector.
export const EXPIRATION_OPTIONS: ReadonlyArray<{ label: string; value: number }> = [
  { label: '5 minutes', value: 5 * 60 },
  { label: '1 hour', value: 60 * 60 },
  { label: '24 hours', value: 24 * 60 * 60 },
  { label: '1 week', value: 7 * 24 * 60 * 60 },
  { label: '1 month', value: 30 * 24 * 60 * 60 },
  { label: '3 months', value: 90 * 24 * 60 * 60 },
];

export function expirationLabel(delta: number): string {
  const preset = EXPIRATION_OPTIONS.find((option) => option.value === delta);
  if (preset) { return preset.label; }
  if (delta < 60) { return `${delta} seconds`; }
  if (delta < 3600) { return `${Math.floor(delta / 60)} minutes`; }
  if (delta < 86_400) { return `${Math.floor(delta / 3600)} hours`; }
  return `${Math.floor(delta / 86_400)} days`;
}

const GEOHASH_BASE32 = '0123456789bcdefghjkmnpqrstuvwxyz';
const GEOHASH_PATTERN = /^[0-9b-hjkmnp-z]{1,12}$/;
// Iris Client shares location as a precision-4 geohash (about 39 km × 20 km).
export const LOCATION_GEOHASH_PRECISION = 4;
const GEOHASH_CELL_SIZES = ['5000 km', '1250 km', '156 km', '39 km', '5 km', '1.2 km', '150 m', '38 m', '5 m', '1 m', '15 cm', '4 cm'];

export function normalizeGeohash(value: string): string | null {
  const geohash = value.trim().toLowerCase();
  return GEOHASH_PATTERN.test(geohash) ? geohash : null;
}

export function encodeGeohash(latitude: number, longitude: number, precision = LOCATION_GEOHASH_PRECISION): string {
  let latMin = -90;
  let latMax = 90;
  let lonMin = -180;
  let lonMax = 180;
  let geohash = '';
  let bits = 0;
  let index = 0;
  let evenBit = true;
  while (geohash.length < precision) {
    if (evenBit) {
      const mid = (lonMin + lonMax) / 2;
      if (longitude > mid) { index = (index << 1) | 1; lonMin = mid; } else { index <<= 1; lonMax = mid; }
    } else {
      const mid = (latMin + latMax) / 2;
      if (latitude > mid) { index = (index << 1) | 1; latMin = mid; } else { index <<= 1; latMax = mid; }
    }
    evenBit = !evenBit;
    if (++bits === 5) {
      geohash += GEOHASH_BASE32[index];
      bits = 0;
      index = 0;
    }
  }
  return geohash;
}

/** Every coarser prefix as well, so `#g` filters match at each precision (as Iris Client publishes). */
export function geohashPrefixes(geohash: string): string[] {
  return Array.from({ length: geohash.length }, (_, index) => geohash.slice(0, index + 1));
}

/** Approximate width of a geohash cell with this many characters. */
export function geohashCellSize(precision: number): string {
  return GEOHASH_CELL_SIZES[Math.max(1, Math.min(precision, GEOHASH_CELL_SIZES.length)) - 1]!;
}

export function buildComposerOptionTags(
  options: Pick<ComposerSubmitPayload, 'expirationDelta' | 'geohash'>,
  nowSeconds = Math.floor(Date.now() / 1000),
): string[][] {
  const tags: string[][] = [];
  const geohash = options.geohash ? normalizeGeohash(options.geohash) : null;
  if (geohash) {
    tags.push(...geohashPrefixes(geohash).map((prefix) => ['g', prefix]));
  }
  const delta = options.expirationDelta;
  if (typeof delta === 'number' && Number.isFinite(delta) && delta > 0) {
    tags.push(['expiration', String(Math.floor(nowSeconds + delta))]);
  }
  return tags;
}

export function hasComposerOptions(options: ComposerOptions): boolean {
  return options.expirationDelta !== null || options.geohash !== null;
}

function restorableOptions(value: unknown): ComposerOptions | null {
  if (!value || typeof value !== 'object') { return null; }
  const { expirationDelta, geohash } = value as Partial<ComposerOptions>;
  const options: ComposerOptions = {
    expirationDelta: typeof expirationDelta === 'number' && Number.isFinite(expirationDelta) && expirationDelta > 0
      ? Math.floor(expirationDelta)
      : null,
    geohash: typeof geohash === 'string' ? normalizeGeohash(geohash) : null,
  };
  return hasComposerOptions(options) ? options : null;
}

type OptionsStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;
const STORAGE_KEY = 'iris-social:composer-options:v1';

/**
 * Options are keyed like composer drafts (`${pubkey}:${draftKey}`) and are
 * cleared when that draft is cleared after publishing.
 */
export function createComposerOptionsStore(storage?: OptionsStorage, maxEntries = 24) {
  const initial = new Map<string, ComposerOptions>();
  try {
    const saved: unknown = JSON.parse(storage?.getItem(STORAGE_KEY) ?? '[]');
    if (Array.isArray(saved)) {
      for (const entry of saved.slice(-maxEntries)) {
        const options = Array.isArray(entry) && typeof entry[0] === 'string' ? restorableOptions(entry[1]) : null;
        if (options) { initial.set(entry[0], options); }
      }
    }
  } catch { /* Corrupt options must not prevent composing. */ }
  const store = writable(initial);

  function persist(entries: Map<string, ComposerOptions>): void {
    if (!storage) { return; }
    try {
      if (entries.size) { storage.setItem(STORAGE_KEY, JSON.stringify([...entries])); }
      else { storage.removeItem(STORAGE_KEY); }
    } catch { /* Keep in-memory options when storage is unavailable or full. */ }
  }

  function update(scope: string, options: ComposerOptions | null): void {
    store.update((current) => {
      const existing = current.get(scope);
      if (!options && !existing) { return current; }
      const next = new Map(current);
      next.delete(scope);
      if (options) { next.set(scope, options); }
      while (next.size > maxEntries) { next.delete(next.keys().next().value!); }
      persist(next);
      return next;
    });
  }

  return {
    subscribe: store.subscribe,
    read(scope: string): ComposerOptions {
      return get(store).get(scope) ?? EMPTY_COMPOSER_OPTIONS;
    },
    write(scope: string, options: ComposerOptions): void {
      update(scope, restorableOptions(options));
    },
    clear(scope: string): void {
      update(scope, null);
    },
  };
}

export const composerOptionsStore = createComposerOptionsStore(getBrowserDraftStorage());

// Posting clears a draft through threadReplyDrafts.delete(); drop its options too.
let seenDraftClears = get(clearedComposerDrafts);
clearedComposerDrafts.subscribe((clears) => {
  for (const [scope, version] of clears) {
    if (version > (seenDraftClears.get(scope) ?? 0)) { composerOptionsStore.clear(scope); }
  }
  seenDraftClears = clears;
});

export function snapshotComposerOptions(options: Pick<ComposerSubmitPayload, 'expirationDelta' | 'geohash'>): string {
  return `${options.expirationDelta ?? ''}|${options.geohash ?? ''}`;
}
