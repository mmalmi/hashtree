import type { SocialGraphProfileSocial } from './socialGraphProfileQuery';

const signedSeed = new EventTarget();

export function notifySignedGraphSeed(): void {
  signedSeed.dispatchEvent(new Event('change'));
}

export function subscribeSignedGraphSeed(refresh: () => void): () => void {
  signedSeed.addEventListener('change', refresh);
  return () => signedSeed.removeEventListener('change', refresh);
}

/**
 * Read relationships from the persisted/bundled graph only. Route hydration
 * must not open or wait for a broad event-index stream.
 */
export async function loadSnapshotSocialGraphProfileSocial(
  pubkey: string,
  followerLimit: number,
  signal?: AbortSignal,
): Promise<SocialGraphProfileSocial | null | undefined> {
  // `undefined`: no graph to ask here. `null`: the graph does not know them.
  if (typeof window === 'undefined') {
    return undefined;
  }
  const { getWorkerClient } = await import('./workerClient');
  return await (await getWorkerClient()).queryProfileSocialSnapshot(
    pubkey,
    followerLimit,
    signal,
  );
}
