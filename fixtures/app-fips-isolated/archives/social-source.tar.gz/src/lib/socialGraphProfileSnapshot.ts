import type { SocialGraphProfileSocial } from './socialGraphProfileQuery';

/**
 * Read relationships from the persisted/bundled graph only. Route hydration
 * must not open or wait for a broad event-index stream.
 */
export async function loadSnapshotSocialGraphProfileSocial(
  pubkey: string,
  followerLimit: number,
  signal?: AbortSignal,
): Promise<SocialGraphProfileSocial | null> {
  if (typeof window === 'undefined') {
    return null;
  }
  const { getWorkerClient } = await import('./workerClient');
  return await (await getWorkerClient()).queryProfileSocialSnapshot(
    pubkey,
    followerLimit,
    signal,
  );
}
