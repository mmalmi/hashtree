import { getLiveNostrPubsub } from './fipsP2P';

export function getBrowserStorage(): Storage | null {
  if (typeof window === 'undefined') {
    return null;
  }
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

export function getBrowserOnlineTarget(): EventTarget | null {
  return typeof window === 'undefined' ? null : window;
}

export function getBrowserStorageEventTarget(): EventTarget | null {
  return typeof window === 'undefined' ? null : window;
}

export async function connectDefaultLiveTransport() {
  return await getLiveNostrPubsub();
}

export function hasConfiguredLivePeers(): boolean {
  return typeof window !== 'undefined' && typeof RTCPeerConnection !== 'undefined';
}
