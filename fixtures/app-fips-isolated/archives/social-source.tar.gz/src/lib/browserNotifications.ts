import { get, writable } from 'svelte/store';
import { accountsStore, type SocialAccount } from './accounts';
import { canSignAccount } from './accountSigner';
import { notificationRequest, webPushData, NOTIFICATION_SERVER } from './browserNotificationApi';

export const PUSH_CACHE = 'iris-social-notifications-v1';
const STORAGE_KEY = 'iris-social:browser-notifications:v1';
export const NOTIFICATION_KINDS = [1, 6, 7, 9735];
export type NotificationPreferences = {
  enabled: boolean; previews: boolean; socialGraphFilter: boolean; kinds: number[];
  endpoint?: string; subscriptionId?: string;
};
const defaults = (): NotificationPreferences => ({
  enabled: false, previews: false, socialGraphFilter: false, kinds: [...NOTIFICATION_KINDS],
});

function loadPreferences(pubkey: string | null): NotificationPreferences {
  if (!pubkey || typeof localStorage === 'undefined') { return defaults(); }
  try {
    const stored = JSON.parse(localStorage.getItem(`${STORAGE_KEY}:${pubkey}`) ?? 'null');
    if (!stored || typeof stored !== 'object') { return defaults(); }
    return {
      enabled: stored.enabled === true, previews: stored.previews === true,
      socialGraphFilter: stored.socialGraphFilter === true,
      kinds: Array.isArray(stored.kinds) ? NOTIFICATION_KINDS.filter(kind => stored.kinds.includes(kind)) : [...NOTIFICATION_KINDS],
      endpoint: typeof stored.endpoint === 'string' ? stored.endpoint : undefined,
      subscriptionId: typeof stored.subscriptionId === 'string' ? stored.subscriptionId : undefined,
    };
  } catch { return defaults(); }
}
function savePreferences(pubkey: string, preferences: NotificationPreferences): void {
  localStorage.setItem(`${STORAGE_KEY}:${pubkey}`, JSON.stringify(preferences));
}

export function browserNotificationsSupported(): boolean {
  return typeof window !== 'undefined' && window.isSecureContext && 'Notification' in window
    && 'PushManager' in window && 'serviceWorker' in navigator && 'caches' in window;
}

export const browserNotificationState = writable({
  pubkey: null as string | null, preferences: defaults(), busy: false, error: '',
  supported: browserNotificationsSupported(), permission: typeof Notification === 'undefined' ? 'default' : Notification.permission,
});
let generation = 0;
let activeAccount: SocialAccount | null = null;
let operation = Promise.resolve();
let policyWrites = Promise.resolve();
let started = false;

function writePolicy(pubkey: string | null, preferences: NotificationPreferences): Promise<void> {
  policyWrites = policyWrites.catch(() => undefined).then(async () => {
    if (!('caches' in window)) { return; }
    const cache = await caches.open(PUSH_CACHE);
    await cache.put(new URL('__notification_policy__', document.baseURI).href, Response.json({
      pubkey, enabled: preferences.enabled, previews: preferences.previews, kinds: preferences.kinds,
    }));
  });
  return policyWrites;
}
function queue(task: () => Promise<void>): Promise<void> {
  operation = operation.catch(() => undefined).then(task);
  return operation;
}
function current(account: SocialAccount, token: number): boolean {
  return activeAccount?.pubkey === account.pubkey && generation === token;
}
function assertCurrent(account: SocialAccount, token: number): void {
  if (!current(account, token)) { throw new Error('Account changed. Enable notifications for the current account.'); }
}
async function registration(): Promise<ServiceWorkerRegistration> {
  const existing = await navigator.serviceWorker.getRegistration();
  if (existing?.active) { return existing; }
  return await Promise.race([
    navigator.serviceWorker.ready,
    new Promise<never>((_, reject) => setTimeout(() => reject(new Error('Notifications are still starting. Please try again.')), 10_000)),
  ]);
}
async function stopBrowserSubscription(): Promise<void> {
  if (!browserNotificationsSupported()) { return; }
  const reg = await navigator.serviceWorker.getRegistration();
  const subscription = await reg?.pushManager.getSubscription();
  if (subscription && !await subscription.unsubscribe()) {
    throw new Error('Could not disconnect browser notifications. Please try again.');
  }
  const notifications = await reg?.getNotifications();
  notifications?.forEach(notification => notification.close());
}

/** Opt-in belongs to one account on this browser; switching never transfers it. */
export function setNotificationAccount(account: SocialAccount | null): void {
  const previous = activeAccount;
  const sameIdentity = account?.pubkey === previous?.pubkey;
  activeAccount = account;
  if (sameIdentity) {
    const credentialsChanged = previous?.method !== account?.method || previous?.nsec !== account?.nsec;
    if (!credentialsChanged || (canSignAccount(account) && !get(browserNotificationState).busy)) { return; }
  }
  const token = ++generation;
  let preferences = loadPreferences(account?.pubkey ?? null);
  const binding = typeof localStorage === 'undefined' ? null : localStorage.getItem(STORAGE_KEY);
  const changedOwner = Boolean(binding && binding !== account?.pubkey);
  if (preferences.enabled && (!browserNotificationsSupported() || Notification.permission !== 'granted')) {
    preferences = { ...preferences, enabled: false };
    if (account) { savePreferences(account.pubkey, preferences); }
  }
  if (previous || changedOwner) {
    const oldPubkey = previous?.pubkey ?? binding;
    if (oldPubkey) { savePreferences(oldPubkey, { ...loadPreferences(oldPubkey), enabled: false }); }
    preferences = { ...preferences, enabled: false };
    if (account) { savePreferences(account.pubkey, preferences); }
  }
  browserNotificationState.set({
    pubkey: account?.pubkey ?? null, preferences, busy: false, error: '',
    supported: browserNotificationsSupported(), permission: typeof Notification === 'undefined' ? 'default' : Notification.permission,
  });
  void writePolicy(account?.pubkey ?? null, preferences).catch(() => {
    browserNotificationState.update(state => ({ ...state, error: 'Could not save notification settings.' }));
  });
  if (!previous && !changedOwner && account && preferences.enabled) {
    void queue(async () => {
      const reg = await navigator.serviceWorker.getRegistration();
      const subscription = await reg?.pushManager.getSubscription();
      if (generation !== token || subscription?.endpoint === preferences.endpoint) { return; }
      const disabled = { ...preferences, enabled: false };
      savePreferences(account.pubkey, disabled);
      await writePolicy(account.pubkey, disabled);
      browserNotificationState.update(state => ({ ...state, preferences: disabled }));
    }).catch(() => {
      if (generation === token) { browserNotificationState.update(state => ({ ...state, error: 'Could not check browser notifications. Please try again.' })); }
    });
  }
  if (changedOwner || previous) {
    void queue(async () => {
      const browserStopped = await stopBrowserSubscription().then(() => true, () => false);
      // Local-key accounts can clean up without a new prompt. Extension users
      // retain the ID for explicit cleanup when signing as that account again.
      const oldPreferences = previous ? loadPreferences(previous.pubkey) : null;
      if (previous && previous.method !== 'nip07' && canSignAccount(previous) && oldPreferences?.subscriptionId) {
        try {
          await notificationRequest(`subscriptions/${encodeURIComponent(oldPreferences.subscriptionId)}`, previous, 'DELETE');
          delete oldPreferences.subscriptionId;
          delete oldPreferences.endpoint;
          savePreferences(previous.pubkey, oldPreferences);
        } catch { /* Keep the ID for the next explicit enable/disable attempt. */ }
      }
      if (generation === token) {
        if (browserStopped) { localStorage.removeItem(STORAGE_KEY); }
        else { browserNotificationState.update(state => ({ ...state, error: 'Could not disconnect the previous account. Check notification permissions in browser settings.' })); }
      }
    });
  }
}

export function enableBrowserNotifications(): Promise<void> {
  const account = activeAccount;
  if (!account || !canSignAccount(account) || !browserNotificationsSupported()) { return Promise.resolve(); }
  const token = ++generation;
  // Must run directly on the click path, before any asynchronous work.
  const permission = Notification.permission === 'granted'
    ? Promise.resolve(Notification.permission) : Notification.requestPermission();
  browserNotificationState.update(state => ({ ...state, busy: true, error: '' }));
  return queue(async () => {
    let subscription: PushSubscription | null = null;
    let createdId: string | null = null;
    try {
      if (await permission !== 'granted') { throw new Error('Notifications are blocked. Allow them in your browser settings to continue.'); }
      assertCurrent(account, token);
      const preferences = get(browserNotificationState).preferences;
      if (!preferences.kinds.length) { throw new Error('Choose at least one notification type.'); }
      const info = await notificationRequest('info', null);
      if (!info || typeof info !== 'object' || !('vapid_public_key' in info) || typeof info.vapid_public_key !== 'string') {
        throw new Error('The notification service did not provide a browser key.');
      }
      assertCurrent(account, token);
      const reg = await registration();
      assertCurrent(account, token);
      // Recreate explicitly so a changed server key or old account cannot reuse
      // an endpoint that is still associated with an earlier subscription.
      const previousSubscription = await reg.pushManager.getSubscription();
      if (previousSubscription && !await previousSubscription.unsubscribe()) {
        throw new Error('Could not disconnect the previous notification subscription. Please try again.');
      }
      subscription = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: info.vapid_public_key });
      assertCurrent(account, token);
      if (preferences.subscriptionId) {
        await notificationRequest(`subscriptions/${encodeURIComponent(preferences.subscriptionId)}`, account, 'DELETE');
      }
      assertCurrent(account, token);
      const result = await notificationRequest('subscriptions', account, 'POST', {
        filter: { kinds: preferences.kinds, '#p': [account.pubkey] },
        web_push_subscriptions: [webPushData(subscription)], webhooks: [], fcm_tokens: [], apns_tokens: [],
        social_graph_filter: preferences.socialGraphFilter,
      });
      if (!result || typeof result !== 'object' || !('id' in result) || typeof result.id !== 'string') {
        throw new Error('The notification service did not confirm your subscription.');
      }
      createdId = result.id;
      assertCurrent(account, token);
      const next = { ...preferences, enabled: true, endpoint: subscription.endpoint, subscriptionId: createdId };
      await writePolicy(account.pubkey, next);
      assertCurrent(account, token);
      savePreferences(account.pubkey, next);
      localStorage.setItem(STORAGE_KEY, account.pubkey);
      browserNotificationState.update(state => ({ ...state, preferences: next }));
    } catch (error) {
      await subscription?.unsubscribe().catch(() => false);
      if (createdId) {
        savePreferences(account.pubkey, { ...loadPreferences(account.pubkey), enabled: false, subscriptionId: createdId });
      }
      if (current(account, token)) {
        await writePolicy(account.pubkey, { ...get(browserNotificationState).preferences, enabled: false });
        browserNotificationState.update(state => ({ ...state, preferences: { ...state.preferences, enabled: false }, error: error instanceof Error ? error.message : 'Could not enable notifications.' }));
      }
    } finally {
      if (current(account, token)) { browserNotificationState.update(state => ({ ...state, busy: false, permission: Notification.permission })); }
    }
  });
}

export function disableBrowserNotifications(): Promise<void> {
  const account = activeAccount;
  if (!account) { return Promise.resolve(); }
  const token = ++generation;
  const preferences = { ...get(browserNotificationState).preferences, enabled: false };
  savePreferences(account.pubkey, preferences);
  browserNotificationState.update(state => ({ ...state, preferences, busy: true, error: '' }));
  const policy = writePolicy(account.pubkey, preferences);
  return queue(async () => {
    try {
      const [policyResult, browserResult] = await Promise.allSettled([policy, stopBrowserSubscription()]);
      if (policyResult.status === 'rejected' && browserResult.status === 'rejected') {
        const stillEnabled = { ...preferences, enabled: true };
        savePreferences(account.pubkey, stillEnabled);
        if (current(account, token)) {
          browserNotificationState.update(state => ({ ...state, preferences: stillEnabled,
            error: 'Could not turn notifications off. Please block them in browser settings.' }));
        }
        return;
      }
      localStorage.removeItem(STORAGE_KEY);
      if (preferences.subscriptionId) {
        await notificationRequest(`subscriptions/${encodeURIComponent(preferences.subscriptionId)}`, account, 'DELETE');
        delete preferences.subscriptionId;
        delete preferences.endpoint;
        savePreferences(account.pubkey, preferences);
      }
    } catch {
      if (current(account, token)) { browserNotificationState.update(state => ({ ...state, error: 'Notifications are off. The service could not finish disconnecting; try again to clean up.' })); }
    } finally {
      if (current(account, token)) { browserNotificationState.update(state => ({ ...state, busy: false })); }
    }
  });
}

export function updateBrowserNotificationPreferences(patch: Partial<Pick<NotificationPreferences, 'kinds' | 'previews' | 'socialGraphFilter'>>): void {
  if (!activeAccount) { return; }
  const state = get(browserNotificationState);
  if (state.busy || state.preferences.enabled) { return; }
  const preferences = { ...state.preferences, ...patch };
  savePreferences(activeAccount.pubkey, preferences);
  browserNotificationState.update(value => ({ ...value, preferences }));
}

export async function importPushedEvents(): Promise<void> {
  if (!('caches' in window) || !activeAccount) { return; }
  const account = activeAccount.pubkey;
  const cache = await caches.open(PUSH_CACHE);
  const requests = (await cache.keys()).filter(request => new URL(request.url).pathname.includes('/__notification_event__/'));
  if (!requests.length) { return; }
  const [{ verifyNostrEvent }, { socialDataPlane }] = await Promise.all([import('nostr-pubsub'), import('./socialDataPlane')]);
  for (const request of requests) {
    if (activeAccount?.pubkey !== account) { return; }
    try {
      const event = await (await cache.match(request))?.json();
      const verified = verifyNostrEvent(event);
      if (activeAccount?.pubkey !== account) { return; }
      // Another open tab may still use a different account. Leave its valid
      // event in the bounded inbox for the matching account to consume.
      if (!verified.tags.some(tag => tag[0] === 'p' && tag[1] === account)) { continue; }
      socialDataPlane.ingestVerifiedRelayEvent(verified, NOTIFICATION_SERVER);
    } catch { /* Never admit malformed or unsigned push payloads. */ }
    await cache.delete(request);
  }
}

export function startBrowserNotifications(): void {
  if (started) { return; }
  started = true;
  accountsStore.subscribe(state => {
    if (!state.initialized) { return; }
    setNotificationAccount(state.accounts.find(account => account.pubkey === state.activeAccountPubkey) ?? null);
    void importPushedEvents().catch(() => undefined);
  });
  window.addEventListener('focus', () => void importPushedEvents().catch(() => undefined));
  navigator.serviceWorker?.addEventListener('message', event => {
    if (event.data?.type === 'IRIS_PUSH_RECEIVED') { void importPushedEvents().catch(() => undefined); }
  });
}
