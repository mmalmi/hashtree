import { filtersMatch, type NostrFilter } from 'nostr-pubsub';
import { decodeNostrEventReference, getAddressableEventCoordinate, getEventIdFromReference, type RawEvent } from './nostr';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import type { ReferencedNotePreview } from './referencedNote';
import type { WatchReferencedNote } from './referencedNoteContext';
import { isNewerReplaceableEvent } from './socialRepository';

type Sink = (preview: ReferencedNotePreview | null) => void;
type Interest = { key: string; ref: string; filter: NostrFilter; author: string | null };
type Watch = Interest & {
  listeners: Set<Sink>;
  preview: ReferencedNotePreview | null;
  archive: AbortController;
  subscription?: { close(): void };
  resolvedId?: boolean;
  revision: number;
};
type WatchSources = {
  known(interest: Interest): RawEvent | null;
  visible(event: RawEvent): boolean;
  preview(ref: string, event: RawEvent, active: () => boolean): ReferencedNotePreview;
  archive(interest: Interest, signal: AbortSignal, deliver: (event: RawEvent) => void): Promise<void>;
  subscribe(relays: string[], interest: Interest, deliver: (event: RawEvent) => void): { close(): void };
  observeRelays(sync: (relays: string[]) => void): () => void;
  observeLocal(sync: (events: readonly RawEvent[]) => void): () => void;
};

function interestFor(ref: string): Interest | null {
  ref = ref.trim().replace(/^nostr:/i, '');
  const decoded = decodeNostrEventReference(ref);
  const kinds: number[] = [...PROFILE_CONTENT_KINDS];
  if (decoded && 'kind' in decoded && decoded.kind !== null && !kinds.includes(decoded.kind)) { return null; }
  const id = getEventIdFromReference(ref);
  if (id) {
    return { key: id, ref, author: decoded?.type === 'nevent' ? decoded.author : null, filter: { ids: [id], kinds, limit: 1 } };
  }
  if (decoded?.type !== 'naddr') { return null; }
  return {
    key: `${decoded.kind}:${decoded.pubkey}:${decoded.identifier}`, ref, author: decoded.pubkey,
    filter: { kinds: [decoded.kind], authors: [decoded.pubkey], '#d': [decoded.identifier], limit: 1 },
  };
}

export function createReferencedNoteWatches(sources: WatchSources) {
  const watches = new Map<string, Watch>();
  let relays: string[] = [];
  let stopSources: (() => void) | undefined;
  const current = (watch: Watch) => watches.get(watch.key) === watch;
  function notify(watch: Watch, preview: ReferencedNotePreview | null) {
    watch.preview = preview;
    for (const sink of watch.listeners) { sink(preview); }
  }
  function accept(watch: Watch, event: RawEvent | null) {
    if (!event || !current(watch) || !filtersMatch([watch.filter], event) || !sources.visible(event)) { return; }
    if (watch.preview && !isNewerReplaceableEvent(event, watch.preview.event)) { return; }
    if (watch.filter.ids) {
      watch.resolvedId = true;
      watch.subscription?.close();
      watch.subscription = undefined;
      watch.archive.abort();
    }
    const revision = ++watch.revision;
    notify(watch, sources.preview(watch.ref, event, () => current(watch) && watch.revision === revision && sources.visible(event)));
  }
  function refreshLocal(watch: Watch) {
    if (watch.preview && !sources.visible(watch.preview.event)) { notify(watch, null); }
    accept(watch, sources.known(watch));
  }
  function readArchive(watch: Watch) {
    watch.archive.abort();
    const controller = new AbortController();
    watch.archive = controller;
    void sources.archive(watch, controller.signal, event => {
      if (!controller.signal.aborted) { accept(watch, event); }
    }).catch(() => { /* The live and local interests continue independently. */ });
  }
  function connect(watch: Watch) {
    watch.subscription?.close();
    const permitted = relays;
    watch.subscription = permitted.length && !watch.resolvedId ? sources.subscribe(permitted, watch, event => {
      if (permitted === relays) { accept(watch, event); }
    }) : undefined;
    if (watch.resolvedId) { watch.subscription?.close(); watch.subscription = undefined; }
  }
  function startSources() {
    const stopLocal = sources.observeLocal(events => {
      for (const event of events) {
        const byId = watches.get(event.id);
        if (byId) { accept(byId, event); }
        const coordinate = getAddressableEventCoordinate(event);
        const byAddress = coordinate && watches.get(coordinate);
        if (byAddress) { accept(byAddress, event); }
        if (event.kind === 5 || coordinate) {
          for (const watch of watches.values()) {
            if (watch.preview && !sources.visible(watch.preview.event)) { refreshLocal(watch); }
          }
        }
      }
    });
    const stopRelays = sources.observeRelays(next => {
      if (JSON.stringify(next) === JSON.stringify(relays)) { return; }
      relays = next;
      for (const watch of watches.values()) { connect(watch); }
    });
    stopSources = () => { stopLocal(); stopRelays(); relays = []; };
  }
  const watchReferencedNote: WatchReferencedNote = (ref, sink) => {
    const interest = interestFor(ref);
    if (!interest) { sink(null); return () => {}; }
    if (!stopSources) { startSources(); }
    let watch = watches.get(interest.key);
    if (!watch) {
      watch = { ...interest, listeners: new Set(), preview: null, archive: new AbortController(), revision: 0 };
      watches.set(watch.key, watch);
      refreshLocal(watch);
      if (!watch.resolvedId) { readArchive(watch); }
      connect(watch);
    } else if (!watch.author && interest.author && !watch.resolvedId) {
      watch.author = interest.author;
      readArchive(watch);
    }
    // Identical callbacks from independent consumers retain independent leases.
    const listener: Sink = preview => sink(preview);
    watch.listeners.add(listener);
    sink(watch.preview);
    return () => {
      if (!watch.listeners.delete(listener) || watch.listeners.size) { return; }
      watches.delete(watch.key);
      watch.archive.abort();
      watch.subscription?.close();
      if (!watches.size) { stopSources?.(); stopSources = undefined; }
    };
  };
  return {
    watchReferencedNote,
    refreshKnownNotes() {
      for (const watch of watches.values()) { if (!watch.resolvedId) { refreshLocal(watch); } }
    },
    refreshArchiveRoots() {
      for (const watch of watches.values()) { if (!watch.resolvedId) { readArchive(watch); } }
    },
  };
}
