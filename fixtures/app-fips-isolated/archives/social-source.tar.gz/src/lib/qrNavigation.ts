import * as nip19 from 'nostr-tools/nip19';

export type ScannedNostrTarget =
  | { kind: 'profile'; pubkey: string }
  | { kind: 'thread'; ref: string };

export function parseScannedNostrValue(value: string): ScannedNostrTarget | null {
  const trimmed = value.trim();
  const identifier = /^nostr:/i.test(trimmed) ? trimmed.slice(6).trim() : trimmed;
  if (!identifier) {
    return null;
  }

  try {
    const decoded = nip19.decode(identifier.toLowerCase());
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return { kind: 'profile', pubkey: decoded.data };
    }
    if (decoded.type === 'nprofile' && typeof decoded.data === 'object' && decoded.data) {
      return { kind: 'profile', pubkey: decoded.data.pubkey };
    }
    if (decoded.type === 'note' || decoded.type === 'nevent' || decoded.type === 'naddr') {
      return { kind: 'thread', ref: identifier.toLowerCase() };
    }
  } catch {
    return null;
  }

  return null;
}
