import { WalletPaymentError, type WalletSnapshot } from './walletTypes';
import type {
  WalletWorkerCommand,
  WalletWorkerRequest,
  WalletWorkerResponse,
  WalletWorkerResult,
} from '../workers/walletWorkerProtocol';

const DEFAULT_TIMEOUT_MS = 20_000;
const PAYMENT_TIMEOUT_MS = 45_000;
const TOKEN_HARD_TIMEOUT_MS = 120_000;

type PendingRequest = {
  resolve(value: WalletWorkerResult): void;
  reject(reason: Error): void;
  timeout: ReturnType<typeof setTimeout> | null;
  hardTimeout: ReturnType<typeof setTimeout> | null;
  movement: 'payment' | 'token' | null;
};

type WalletRequestOptions = {
  timeoutMs?: number;
  hardTimeoutMs?: number;
};

let worker: Worker | null = null;
let nextRequestId = 0;
const pending = new Map<string, PendingRequest>();
const snapshotListeners = new Set<(snapshot: WalletSnapshot) => void>();

function clearRequestTimeouts(request: PendingRequest): void {
  if (request.timeout) {clearTimeout(request.timeout);}
  if (request.hardTimeout) {clearTimeout(request.hardTimeout);}
}

function rejectPending(message: string): void {
  for (const request of pending.values()) {
    clearRequestTimeouts(request);
    request.reject(new WalletPaymentError(message, request.movement !== null));
  }
  pending.clear();
}

function stopWorker(target: Worker, message: string): void {
  if (worker !== target) {return;}
  worker = null;
  target.terminate();
  rejectPending(message);
}

function handleMessage(event: MessageEvent<WalletWorkerResponse>): void {
  const message = event.data;
  if (message.type === 'wallet:snapshot') {
    for (const listener of snapshotListeners) {listener(message.snapshot);}
    return;
  }
  const request = pending.get(message.requestId);
  if (!request) {return;}
  pending.delete(message.requestId);
  clearRequestTimeouts(request);
  if (message.type === 'wallet:error') {
    request.reject(new WalletPaymentError(
      message.message,
      message.paymentStarted || request.movement === 'token',
    ));
  } else {
    request.resolve(message.result);
  }
}

function getWorker(): Worker {
  if (worker) {return worker;}
  if (typeof Worker === 'undefined') {throw new Error('Wallet workers are unavailable.');}
  const target = new Worker(new URL('../workers/wallet.worker.ts', import.meta.url), {
    type: 'module',
    name: 'iris-wallet',
  });
  worker = target;
  target.addEventListener('message', (event) => {
    if (worker === target) {
      handleMessage(event);
    }
  });
  target.addEventListener('error', () => {
    stopWorker(target, 'Wallet worker stopped unexpectedly. Reopen the wallet to reconcile it.');
  });
  return target;
}

export async function requestWallet<T extends WalletWorkerResult = WalletWorkerResult>(
  command: WalletWorkerCommand,
  options: WalletRequestOptions = {},
): Promise<T> {
  const target = getWorker();
  const requestId = `${Date.now().toString(36)}-${(++nextRequestId).toString(36)}`;
  const payment = command.type === 'wallet:payInvoice' || command.type === 'wallet:executePayment';
  const movement = payment ? 'payment' : command.type === 'wallet:sendToken' ? 'token' : null;
  const defaultTimeoutMs = payment ? PAYMENT_TIMEOUT_MS : DEFAULT_TIMEOUT_MS;
  const timeoutMs = options.timeoutMs ?? defaultTimeoutMs;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError('Wallet request timeout must be positive.');
  }
  const hardTimeoutMs = options.hardTimeoutMs ?? TOKEN_HARD_TIMEOUT_MS;
  if (movement === 'token' && (!Number.isFinite(hardTimeoutMs) || hardTimeoutMs <= timeoutMs)) {
    throw new RangeError('Token hard timeout must be greater than its soft timeout.');
  }
  return new Promise<T>((resolve, reject) => {
    const request: PendingRequest = {
      resolve: (value) => resolve(value as T),
      reject,
      timeout: null,
      hardTimeout: null,
      movement,
    };
    request.timeout = setTimeout(() => {
      request.timeout = null;
      if (movement === 'token') {
        return;
      }
      stopWorker(target,
        payment
          ? 'Payment status is uncertain. Reopen the wallet to reconcile it before retrying.'
          : 'Wallet operation timed out. The wallet worker was restarted; please retry.',
      );
    }, timeoutMs);
    if (movement === 'token') {
      request.hardTimeout = setTimeout(() => {
        request.hardTimeout = null;
        stopWorker(
          target,
          'Token creation stalled. Reopen the wallet to reconcile it before retrying.',
        );
      }, hardTimeoutMs);
    }
    pending.set(requestId, request);
    target.postMessage({ ...command, requestId } satisfies WalletWorkerRequest);
  });
}

export function subscribeWalletSnapshots(listener: (snapshot: WalletSnapshot) => void): () => void {
  snapshotListeners.add(listener);
  return () => snapshotListeners.delete(listener);
}

export function prewarmWallet(): void {
  if (typeof window === 'undefined') {return;}
  void requestWallet({ type: 'wallet:initialize' }).catch(() => undefined);
}

export function restartWalletWorker(): void {
  rejectPending('Wallet worker restarted.');
  worker?.terminate();
  worker = null;
}
