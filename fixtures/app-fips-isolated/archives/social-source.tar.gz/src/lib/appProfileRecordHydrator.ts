import type { CID } from '@hashtree/core';
import type { ProfileRecord } from './nostr';
import { getRootNhash, loadProfileRecord } from './nostrIndex';
import type { ProfileSnapshot } from './profileNotes';

type ProfileRecordHydratorDeps = {
  getLoadToken: () => number;
  getProfilePage: () => ProfileSnapshot | null;
  getAccountProfiles: () => Map<string, ProfileRecord>;
  setProfilePage: (page: ProfileSnapshot | null) => void;
  setAccountProfiles: (profiles: Map<string, ProfileRecord>) => void;
  setProfileEmptyRetryKey: (key: string | null) => void;
  loadProfileRecord?: typeof loadProfileRecord;
};

export function createProfileRecordHydrator(deps: ProfileRecordHydratorDeps) {
  const loadProfileMetadata = deps.loadProfileRecord ?? loadProfileRecord;
  let activeController: AbortController | null = null;

  return {
    cancelPendingProfileRecordHydration(): void {
      activeController?.abort(
        new DOMException('Profile record hydration cancelled', 'AbortError'),
      );
      activeController = null;
    },

    async hydrateProfileRecordProgressively(
      currentRoot: CID,
      pubkey: string,
      token: number,
      routeMatchesProfile: () => boolean,
    ): Promise<void> {
      activeController?.abort(
        new DOMException('Profile record hydration superseded', 'AbortError'),
      );
      const controller = new AbortController();
      activeController = controller;
      const isCurrent = () => (
        !controller.signal.aborted
        && token === deps.getLoadToken()
        && routeMatchesProfile()
      );
      try {
        const nextProfile = await loadProfileMetadata(currentRoot, pubkey, {
          signal: controller.signal,
          isCurrent,
        });
        if (!isCurrent() || !deps.getProfilePage()) {
          return;
        }

        deps.setProfilePage({
          ...deps.getProfilePage(),
          rootNhash: getRootNhash(currentRoot),
          profile: nextProfile,
          notes: deps.getProfilePage()?.notes ?? [],
        });

        if (nextProfile) {
          deps.setAccountProfiles(new Map(deps.getAccountProfiles()).set(pubkey, nextProfile));
          deps.setProfileEmptyRetryKey(null);
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          console.warn('Failed to progressively load profile record', error);
        }
      } finally {
        if (activeController === controller) {
          activeController = null;
        }
      }
    },
  };
}
