import {
  canonicalizeThreadReference,
  normalizePubkey,
  pubkeyToNpub,
} from './nostr';
import {
  accountsHref,
  homeTabHref,
  notificationsHref,
  profileSectionHref,
  searchHref,
  settingsHref,
  threadHref,
  walletHref,
  type HomeTab,
  type ProfileSection,
  type SettingsSection,
} from './routes';

export type Route =
  | { kind: 'home'; tab: HomeTab }
  | { kind: 'profile'; npub: string; pubkey: string | null; section: ProfileSection }
  | { kind: 'thread'; ref: string; discoveryRef?: string }
  | { kind: 'search'; query?: string; tab?: 'people' | 'posts' }
  | { kind: 'wallet' }
  | { kind: 'notifications' }
  | { kind: 'accounts' }
  | { kind: 'settings'; section: SettingsSection }
  | { kind: 'username'; username: string };

export function routeKey(route: Route): string {
  if (route.kind === 'home') {
    return `home:${route.tab}`;
  }

  if (route.kind === 'profile') {
    return `profile:${route.pubkey ?? route.npub}:${route.section}`;
  }

  if (route.kind === 'thread') {
    return `thread:${route.ref}`;
  }

  if (route.kind === 'search') {
    return 'search';
  }

  if (route.kind === 'accounts') {
    return 'accounts';
  }

  if (route.kind === 'wallet') {
    return 'wallet';
  }

  if (route.kind === 'notifications') {
    return 'notifications';
  }

  if (route.kind === 'username') {
    return `username:${route.username}`;
  }

  return `settings:${route.section}`;
}

export function parseRouteHash(hash: string): Route {
  const raw = hash.trim();
  const hashIndex = raw.indexOf('#');
  const trimmed = hashIndex >= 0 ? raw.slice(hashIndex) : raw;
  if (!trimmed || trimmed === '#' || trimmed === '#/') {
    return { kind: 'home', tab: 'latest' };
  }

  if (trimmed === '#/favorites') {
    return { kind: 'home', tab: 'favorites' };
  }

  if (trimmed === '#/media') {
    return { kind: 'home', tab: 'media' };
  }

  if (trimmed === '#/for-you') {
    return { kind: 'home', tab: 'for-you' };
  }

  if (trimmed === '#/notifications') {
    return { kind: 'notifications' };
  }

  if (trimmed === '#/wallet') {
    return { kind: 'wallet' };
  }

  if (trimmed === '#/settings' || trimmed.startsWith('#/settings/')) {
    const rawSection = trimmed.slice('#/settings'.length).replace(/^\/+|\/+$/g, '');
    const section: SettingsSection = rawSection === 'profile'
      || rawSection === 'iris'
      || rawSection === 'notifications'
      || rawSection === 'content'
      || rawSection === 'appearance'
      || rawSection === 'network'
      || rawSection === 'media'
      || rawSection === 'storage'
      || rawSection === 'wallet'
        ? rawSection
        : 'root';
    return { kind: 'settings', section };
  }

  if (trimmed === '#/search' || trimmed.startsWith('#/search?')) {
    if (trimmed === '#/search') { return { kind: 'search' }; }
    const params = new URLSearchParams(trimmed.slice('#/search?'.length));
    return { kind: 'search', query: params.get('q') ?? '', tab: params.get('tab') === 'posts' ? 'posts' : 'people' };
  }

  if (trimmed === '#/accounts') {
    return { kind: 'accounts' };
  }

  if (trimmed.startsWith('#/thread/')) {
    const ref = canonicalizeThreadReference(
      safeDecodePathSegment(trimmed.slice('#/thread/'.length)),
    );
    return {
      kind: 'thread',
      ref,
    };
  }

  if (trimmed.startsWith('#/profile/')) {
    const [encodedNpub, rawSection] = trimmed.slice('#/profile/'.length).split('/');
    const npub = safeDecodePathSegment(encodedNpub ?? '');
    const section =
      rawSection === 'replies'
      || rawSection === 'media'
      || rawSection === 'likes'
      || rawSection === 'follows'
      || rawSection === 'followers'
        ? rawSection
        : 'posts';
    return {
      kind: 'profile',
      npub,
      pubkey: normalizePubkey(npub),
      section,
    };
  }

  return { kind: 'home', tab: 'latest' };
}

function safeDecodePathSegment(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function profileSection(value: string | undefined): ProfileSection {
  return value === 'replies'
    || value === 'media'
    || value === 'likes'
    || value === 'follows'
    || value === 'followers'
      ? value
      : 'posts';
}

function parseRootIdentifierRoute(pathname: string): Route | null {
  const [encodedIdentifier, rawSection] = pathname.replace(/^\/+|\/+$/g, '').split('/');
  if (!encodedIdentifier) {
    return null;
  }

  const identifier = safeDecodePathSegment(encodedIdentifier);
  if (identifier.startsWith('npub1') || identifier.startsWith('nprofile1')) {
    const pubkey = normalizePubkey(identifier);
    return {
      kind: 'profile',
      npub: pubkey ? pubkeyToNpub(pubkey) : identifier,
      pubkey,
      section: profileSection(rawSection),
    };
  }

  if (
    identifier.startsWith('note1')
    || identifier.startsWith('nevent1')
    || identifier.startsWith('naddr1')
  ) {
    return {
      kind: 'thread',
      ref: canonicalizeThreadReference(identifier),
    };
  }

  if (/^[a-z0-9_.]{3,15}$/.test(identifier)) {
    return { kind: 'username', username: identifier };
  }

  return null;
}

export function parseRouteLocation(pathname: string, hash: string): Route {
  return parseRootIdentifierRoute(pathname) ?? parseRouteHash(hash);
}

export function parseRouteHref(href: string): Route {
  const trimmed = href.trim();
  if (trimmed.startsWith('#')) {
    return parseRouteHash(trimmed);
  }

  const hashIndex = trimmed.indexOf('#');
  const hash = hashIndex >= 0 ? trimmed.slice(hashIndex) : '';
  const pathAndSearch = hashIndex >= 0 ? trimmed.slice(0, hashIndex) : trimmed;
  const pathname = pathAndSearch.split('?')[0] || '/';
  return parseRouteLocation(pathname, hash);
}

export function canonicalRouteHref(route: Route): string {
  if (route.kind === 'profile') {
    return route.pubkey
      ? profileSectionHref(route.pubkey, route.section)
      : `/${encodeURIComponent(route.npub)}`;
  }
  if (route.kind === 'thread') {
    return threadHref(route.ref);
  }
  if (route.kind === 'home') {
    return homeTabHref(route.tab);
  }
  if (route.kind === 'search') {
    return searchHref(route.query, route.tab);
  }
  if (route.kind === 'notifications') {
    return notificationsHref();
  }
  if (route.kind === 'accounts') {
    return accountsHref();
  }
  if (route.kind === 'wallet') {
    return walletHref();
  }
  if (route.kind === 'settings') {
    return settingsHref(route.section);
  }
  return `/${route.username}`;
}

/**
 * Reparse the public canonical URL so compatibility identifiers such as
 * nevent/nprofile cannot leak into mounted-view keys after their URL was
 * replaced with note/npub.
 */
export function canonicalRoute(route: Route): Route {
  const reparsed = parseRouteHref(canonicalRouteHref(route));
  if (route.kind !== 'thread' || reparsed.kind !== 'thread') {
    return reparsed;
  }
  const discoveryRef = route.discoveryRef ?? route.ref;
  return discoveryRef === reparsed.ref
    ? reparsed
    : { ...reparsed, discoveryRef };
}

export function threadRouteDiscoveryRef(
  route: Extract<Route, { kind: 'thread' }>,
): string {
  return route.discoveryRef ?? route.ref;
}

export function isAppRouteLocation(pathname: string, hash: string): boolean {
  if (parseRootIdentifierRoute(pathname)) {
    return true;
  }
  return (pathname === '/' || pathname === '/index.html') && isAppRouteHash(hash);
}

export function isAppRouteHash(hash: string): boolean {
  return hash === '' || hash === '#' || hash.startsWith('#/');
}
