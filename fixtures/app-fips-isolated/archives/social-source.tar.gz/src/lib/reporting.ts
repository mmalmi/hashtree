import type { EventTemplate } from 'nostr-tools/pure';
import type { RawEvent } from './nostr';

export const REPORT_REASONS = [
  { value: 'spam', label: 'Spam' },
  { value: 'impersonation', label: 'Impersonation' },
  { value: 'nudity', label: 'Nudity' },
  { value: 'malware', label: 'Malware' },
  { value: 'profanity', label: 'Abusive language' },
  { value: 'illegal', label: 'Illegal content' },
  { value: 'other', label: 'Other' },
] as const;
export type ReportReason = typeof REPORT_REASONS[number]['value'];

export function createReportDraft(target: Pick<RawEvent, 'id' | 'pubkey'>, reason: ReportReason, details = ''): EventTemplate {
  if (!/^[0-9a-f]{64}$/.test(target.id) || !/^[0-9a-f]{64}$/.test(target.pubkey)) {
    throw new Error('Invalid post.');
  }
  if (!REPORT_REASONS.some(item => item.value === reason)) {throw new Error('Choose a reason.');}
  if (details.length > 2_000) {throw new Error('Keep the details under 2,000 characters.');}
  return {
    kind: 1984,
    created_at: Math.floor(Date.now() / 1_000),
    content: details.trim(),
    tags: [['e', target.id, reason], ['p', target.pubkey]],
  };
}
