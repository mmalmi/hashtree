import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { get, writable } from 'svelte/store';
import type { ProfileRecord } from './nostr';
import { loadIndexedProfiles, warmProfileIndex } from './profileIndex';
import { preferNewerProfileRecord, profileRecordsEqual } from './profileRecords';
import { applySocialGraphMetrics } from './socialGraph';

const PROFILE_FETCH_RETRY_MS = 2_000;
const PROFILE_FETCH_BATCH_SIZE = 32;
// Quick at first, then spread over two minutes: a cold start can keep the
// sources busy for longer than a burst of early retries lasts.
const PROFILE_FETCH_RETRY_DELAYS_MS = [2_000, 2_000, 2_000, 4_000, 8_000, 15_000, 30_000, 60_000];

export const sharedProfilesStore = writable<Map<string, ProfileRecord>>(new Map());
// A direct profile visit waits for its local metadata before revealing content
// whose height depends on that metadata. Image geometry remains reserved.
export const pendingInitialProfileMetadata = writable<string | null>(null);

export function getSharedProfileRecord(pubkey: string): ProfileRecord | null {
  return get(sharedProfilesStore).get(pubkey) ?? null;
}

const queuedProfilePubkeys = new Set<string>();
const pendingProfilePubkeys = new Set<string>();
const lastProfileFetchAt = new Map<string, number>();
const scheduledProfileRetries = new Map<string, ReturnType<typeof setTimeout>>();
const profileRetryCounts = new Map<string, number>();
const profileFetchQueue: string[] = [];
let profileFlushPromise: Promise<void> | null = null;
let sharedProfileResolver:
  | {
      id: symbol;
      resolve: (pubkey: string, signal?: AbortSignal) => Promise<ProfileRecord | null>;
      resolveBatch?: (pubkeys: string[], signal?: AbortSignal) => Promise<Map<string, ProfileRecord>>;
    }
  | null = null;

export type ProfileHydrationField = 'identity' | 'picture';

/**
 * Add the active application's authenticated event router as a profile source.
 * The standalone profile catalog remains the fast path; this resolver covers
 * authors that have reached the event archive but not the derived catalog yet.
 */
export function configureSharedProfileResolver(
  resolve: (pubkey: string, signal?: AbortSignal) => Promise<ProfileRecord | null>,
  resolveBatch?: (pubkeys: string[], signal?: AbortSignal) => Promise<Map<string, ProfileRecord>>,
): () => void {
  const registration = { id: Symbol('shared-profile-resolver'), resolve, resolveBatch };
  sharedProfileResolver = registration;
  return () => {
    if (sharedProfileResolver?.id === registration.id) {
      sharedProfileResolver = null;
    }
  };
}

export function profileNeedsIndexHydration(
  profile: ProfileRecord | null | undefined,
  fields: readonly ProfileHydrationField[],
): boolean {
  return fields.some((field) => (
    field === 'identity'
      // A cached signed event without a name may be an older kind-0 winner.
      // Give the shared name component one throttled chance to find a newer
      // event before settling on the deterministic pubkey fallback.
      ? !(profile?.displayName?.trim() || profile?.name?.trim())
      // Pictures are optional. A signed kind-0 that omits one is authoritative
      // and must not make every mounted avatar refetch forever.
      : !profile?.eventId && !profile?.picture?.trim()
  ));
}

export function rememberProfileRecords(profiles: Iterable<ProfileRecord | null | undefined>): void {
  const currentProfiles = get(sharedProfilesStore);
  let nextProfiles: Map<string, ProfileRecord> | null = null;

  for (const profile of profiles) {
    if (!profile) {
      continue;
    }
    const enrichedProfile = applySocialGraphMetrics(profile) ?? profile;
    const sourceProfiles = nextProfiles ?? currentProfiles;
    const currentProfile = sourceProfiles.get(enrichedProfile.pubkey) ?? null;
    const mergedProfile = preferNewerProfileRecord(currentProfile, enrichedProfile);
    if (mergedProfile) {contactMemoryStore.observe(mergedProfile.pubkey, publicContactName(mergedProfile));}
    if (!mergedProfile || profileRecordsEqual(currentProfile, mergedProfile)) {
      continue;
    }
    nextProfiles ??= new Map(currentProfiles);
    nextProfiles.set(enrichedProfile.pubkey, mergedProfile);
  }

  if (nextProfiles) {
    sharedProfilesStore.set(nextProfiles);
  }
}

export function rememberProfileRecord(profile: ProfileRecord | null | undefined): void {
  rememberProfileRecords([profile]);
}

function shouldFetchProfile(pubkey: string): boolean {
  if (pendingProfilePubkeys.has(pubkey)) {
    return false;
  }

  const currentProfile = get(sharedProfilesStore).get(pubkey) ?? null;
  if (!profileNeedsIndexHydration(currentProfile, ['identity', 'picture'])) {
    return false;
  }

  const lastFetchAt = lastProfileFetchAt.get(pubkey) ?? 0;
  return Date.now() - lastFetchAt >= PROFILE_FETCH_RETRY_MS;
}

function scheduleProfileRetry(pubkey: string): void {
  if (scheduledProfileRetries.has(pubkey)) {
    return;
  }

  const retryCount = profileRetryCounts.get(pubkey) ?? 0;
  if (retryCount >= PROFILE_FETCH_RETRY_DELAYS_MS.length) {
    return;
  }

  profileRetryCounts.set(pubkey, retryCount + 1);
  scheduledProfileRetries.set(pubkey, setTimeout(() => {
    scheduledProfileRetries.delete(pubkey);
    void ensureProfile(pubkey);
  }, PROFILE_FETCH_RETRY_DELAYS_MS[retryCount]));
}

async function loadSharedProfileBatch(pubkeys: string[]): Promise<Set<string>> {
  const resolver = sharedProfileResolver;
  const catalogController = new AbortController();
  const eventController = new AbortController();
  const resolved = new Set<string>();
  const accept = (profiles: Iterable<ProfileRecord | null | undefined>, other: AbortController): void => {
    const records = [...profiles].filter((profile): profile is ProfileRecord => Boolean(profile));
    for (const profile of records) { resolved.add(profile.pubkey); }
    if (records.length > 0) { rememberProfileRecords(records); }
    if (resolved.size >= pubkeys.length && !other.signal.aborted) {
      other.abort(new DOMException('A faster profile source completed', 'AbortError'));
    }
  };
  const sources: Array<Promise<void>> = [
    loadIndexedProfiles(pubkeys, { signal: catalogController.signal })
      .then((profiles) => accept(profiles.values(), eventController))
      .catch(() => undefined),
  ];
  if (resolver) {
    const eventLoad = resolver.resolveBatch
      ? resolver.resolveBatch(pubkeys, eventController.signal).then((profiles) => profiles.values())
      : Promise.all(pubkeys.map((pubkey) => resolver.resolve(pubkey, eventController.signal).catch(() => null)));
    sources.push(eventLoad.then((profiles) => accept(profiles, catalogController)).catch(() => undefined));
  }
  await Promise.all(sources);
  return resolved;
}

function settleProfileBatch(batch: readonly string[], resolved: ReadonlySet<string>): void {
  for (const pubkey of batch) {
    if (!resolved.has(pubkey)) {
      scheduleProfileRetry(pubkey);
      continue;
    }
    profileRetryCounts.delete(pubkey);
    const retry = scheduledProfileRetries.get(pubkey);
    if (retry) {
      clearTimeout(retry);
      scheduledProfileRetries.delete(pubkey);
    }
  }
}

async function flushProfileFetchQueue(): Promise<void> {
  // Yield one microtask so components mounting in the same frame coalesce into
  // a single batched catalog + archive lookup instead of N serial fetches.
  await Promise.resolve();
  try {
    while (profileFetchQueue.length > 0) {
      const batch = profileFetchQueue.splice(0, PROFILE_FETCH_BATCH_SIZE);
      for (const pubkey of batch) {
        queuedProfilePubkeys.delete(pubkey);
        pendingProfilePubkeys.add(pubkey);
      }
      try {
        settleProfileBatch(batch, await loadSharedProfileBatch(batch));
      } catch (error) {
        console.warn('Failed to ensure profiles', error);
        settleProfileBatch(batch, new Set());
      } finally {
        for (const pubkey of batch) { pendingProfilePubkeys.delete(pubkey); }
      }
    }
  } finally {
    profileFlushPromise = profileFetchQueue.length > 0 ? flushProfileFetchQueue() : null;
  }
}

export async function ensureProfiles(pubkeys: Iterable<string>): Promise<void> {
  const now = Date.now();
  let added = false;
  for (const pubkey of pubkeys) {
    const normalized = pubkey.trim().toLowerCase();
    if (!normalized || queuedProfilePubkeys.has(normalized) || !shouldFetchProfile(normalized)) { continue; }
    queuedProfilePubkeys.add(normalized);
    lastProfileFetchAt.set(normalized, now);
    profileFetchQueue.push(normalized);
    added = true;
  }
  if (!added) { return; }
  profileFlushPromise ??= flushProfileFetchQueue();
  await profileFlushPromise;
}

export async function ensureProfile(pubkey: string): Promise<void> {
  await ensureProfiles([pubkey]);
}

export async function warmSharedProfiles(): Promise<void> {
  await warmProfileIndex();
}
