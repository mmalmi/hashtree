import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { get, writable } from 'svelte/store';
import type { ProfileRecord } from './nostr';
import { loadIndexedProfileRecord, warmProfileIndex } from './profileIndex';
import { preferNewerProfileRecord, profileRecordsEqual } from './profileRecords';
import { loadProfileFromFastestSource } from './profileSourceRace';
import { applySocialGraphMetrics } from './socialGraph';

const PROFILE_FETCH_RETRY_MS = 2_000;
const MAX_PROFILE_FETCH_RETRIES = 8;

export const sharedProfilesStore = writable<Map<string, ProfileRecord>>(new Map());
// A direct profile visit waits for its local metadata before revealing content
// whose height depends on that metadata. Image geometry remains reserved.
export const pendingInitialProfileMetadata = writable<string | null>(null);

export function getSharedProfileRecord(pubkey: string): ProfileRecord | null {
  return get(sharedProfilesStore).get(pubkey) ?? null;
}

const queuedProfilePubkeys = new Set<string>();
const pendingProfilePubkeys = new Set<string>();
const lastProfileFetchAt = new Map<string, number>();
const scheduledProfileRetries = new Map<string, ReturnType<typeof setTimeout>>();
const profileRetryCounts = new Map<string, number>();
const profileFetchQueue: string[] = [];
let profileFetchInFlight = false;
let sharedProfileResolver:
  | {
      id: symbol;
      resolve: (pubkey: string, signal?: AbortSignal) => Promise<ProfileRecord | null>;
    }
  | null = null;

export type ProfileHydrationField = 'identity' | 'picture';

/**
 * Add the active application's authenticated event router as a profile source.
 * The standalone profile catalog remains the fast path; this resolver covers
 * authors that have reached the event archive but not the derived catalog yet.
 */
export function configureSharedProfileResolver(
  resolve: (pubkey: string, signal?: AbortSignal) => Promise<ProfileRecord | null>,
): () => void {
  const registration = { id: Symbol('shared-profile-resolver'), resolve };
  sharedProfileResolver = registration;
  return () => {
    if (sharedProfileResolver?.id === registration.id) {
      sharedProfileResolver = null;
    }
  };
}

export function profileNeedsIndexHydration(
  profile: ProfileRecord | null | undefined,
  fields: readonly ProfileHydrationField[],
): boolean {
  return fields.some((field) => (
    field === 'identity'
      // A cached signed event without a name may be an older kind-0 winner.
      // Give the shared name component one throttled chance to find a newer
      // event before settling on the deterministic pubkey fallback.
      ? !(profile?.displayName?.trim() || profile?.name?.trim())
      // Pictures are optional. A signed kind-0 that omits one is authoritative
      // and must not make every mounted avatar refetch forever.
      : !profile?.eventId && !profile?.picture?.trim()
  ));
}

export function rememberProfileRecords(profiles: Iterable<ProfileRecord | null | undefined>): void {
  const currentProfiles = get(sharedProfilesStore);
  let nextProfiles: Map<string, ProfileRecord> | null = null;

  for (const profile of profiles) {
    if (!profile) {
      continue;
    }
    const enrichedProfile = applySocialGraphMetrics(profile) ?? profile;
    const sourceProfiles = nextProfiles ?? currentProfiles;
    const currentProfile = sourceProfiles.get(enrichedProfile.pubkey) ?? null;
    const mergedProfile = preferNewerProfileRecord(currentProfile, enrichedProfile);
    if (mergedProfile) {contactMemoryStore.observe(mergedProfile.pubkey, publicContactName(mergedProfile));}
    if (!mergedProfile || profileRecordsEqual(currentProfile, mergedProfile)) {
      continue;
    }
    nextProfiles ??= new Map(currentProfiles);
    nextProfiles.set(enrichedProfile.pubkey, mergedProfile);
  }

  if (nextProfiles) {
    sharedProfilesStore.set(nextProfiles);
  }
}

export function rememberProfileRecord(profile: ProfileRecord | null | undefined): void {
  rememberProfileRecords([profile]);
}

function shouldFetchProfile(pubkey: string): boolean {
  if (pendingProfilePubkeys.has(pubkey)) {
    return false;
  }

  const currentProfile = get(sharedProfilesStore).get(pubkey) ?? null;
  if (!profileNeedsIndexHydration(currentProfile, ['identity', 'picture'])) {
    return false;
  }

  const lastFetchAt = lastProfileFetchAt.get(pubkey) ?? 0;
  return Date.now() - lastFetchAt >= PROFILE_FETCH_RETRY_MS;
}

function scheduleProfileRetry(pubkey: string): void {
  if (scheduledProfileRetries.has(pubkey)) {
    return;
  }

  const retryCount = profileRetryCounts.get(pubkey) ?? 0;
  if (retryCount >= MAX_PROFILE_FETCH_RETRIES) {
    return;
  }

  profileRetryCounts.set(pubkey, retryCount + 1);
  scheduledProfileRetries.set(pubkey, setTimeout(() => {
    scheduledProfileRetries.delete(pubkey);
    void ensureProfile(pubkey);
  }, PROFILE_FETCH_RETRY_MS));
}

async function loadSharedProfile(pubkey: string): Promise<ProfileRecord | null> {
  const applicationResolver = sharedProfileResolver?.resolve;
  return await loadProfileFromFastestSource(pubkey, {
    loadCatalogProfile: async (signal) => await loadIndexedProfileRecord(pubkey, { signal }),
    loadEventProfile: async (signal) => (
      applicationResolver ? await applicationResolver(pubkey, signal) : null
    ),
  }, {
    onProfile: rememberProfileRecord,
  });
}

export async function ensureProfile(pubkey: string): Promise<void> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  if (
    !normalizedPubkey
    || queuedProfilePubkeys.has(normalizedPubkey)
    || !shouldFetchProfile(normalizedPubkey)
  ) {
    return;
  }

  queuedProfilePubkeys.add(normalizedPubkey);
  lastProfileFetchAt.set(normalizedPubkey, Date.now());
  profileFetchQueue.push(normalizedPubkey);

  if (profileFetchInFlight) {
    return;
  }

  try {
    profileFetchInFlight = true;

    while (profileFetchQueue.length > 0) {
      const nextPubkey = profileFetchQueue.shift()!;
      queuedProfilePubkeys.delete(nextPubkey);
      pendingProfilePubkeys.add(nextPubkey);

      let resolvedProfile: ProfileRecord | null = null;
      try {
        resolvedProfile = await loadSharedProfile(nextPubkey);
        if (resolvedProfile) {
          profileRetryCounts.delete(nextPubkey);
          const scheduledRetry = scheduledProfileRetries.get(nextPubkey);
          if (scheduledRetry) {
            clearTimeout(scheduledRetry);
            scheduledProfileRetries.delete(nextPubkey);
          }
          continue;
        }

        scheduleProfileRetry(nextPubkey);
      } catch (error) {
        console.warn('Failed to ensure profile', error);
        scheduleProfileRetry(nextPubkey);
      } finally {
        pendingProfilePubkeys.delete(nextPubkey);
      }
    }
  } finally {
    profileFetchInFlight = false;
  }
}

export async function warmSharedProfiles(): Promise<void> {
  await warmProfileIndex();
}

export async function ensurePersonalProfile(pubkey: string): Promise<void> {
  await ensureProfile(pubkey);
}
