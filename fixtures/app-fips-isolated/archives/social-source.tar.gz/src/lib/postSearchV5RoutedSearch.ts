import { nhashEncode, type Store } from '@hashtree/core';
import type { RankedSearchFieldManifest } from '@hashtree/index';
import type { RawEvent } from './nostr';
import { parseStoredPostSearchDocument } from './postSearchCatalog';
import { throwIfPostSearchAborted } from './postSearchAbort';
import {
  createPostSearchExecution,
  PostSearchExecution,
  selectBestPostSearchResults,
  takePostSearchIteratorBatch,
  type PostSearchExecutionInput,
} from './postSearchExecution';
import { postSearchExpansionTerm } from './postSearchQueryExpansion';
import { expandPostSearchV5RoutedTerm } from './postSearchV5RoutedQueryExpansion';
import {
  isPostSearchV5EventVisible,
  type PostSearchV5VisibilityOverlay,
} from '../server/postSearchV5Overlay';
import { readPostSearchV5VisibilityOverlay } from '../server/postSearchV5OverlayStore';
import type {
  PostSearchV5RoutedCatalogLookup,
  PostSearchV5RoutedCatalogRunDescriptor,
} from '../server/postSearchV5RoutedCatalog';
import type {
  PostSearchV5Posting,
  PostSearchV5StoredDocument,
  PostSearchV5TermStats,
} from '../server/postSearchV5Run';

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;
const DEFAULT_MAX_SCANNED_POSTINGS = 250_000;
const HARD_MAX_SCANNED_POSTINGS = 1_000_000;
const DEFAULT_MAX_CANDIDATES = 50_000;
const HARD_MAX_CANDIDATES = 250_000;
const DEFAULT_DOCUMENT_CONCURRENCY = 16;
const MAX_DOCUMENT_CONCURRENCY = 32;
const OVERLAY_CACHE_LIMIT = 8;
const TOKEN_PATTERN = /#([\p{L}\p{N}\p{M}_]+)|[\p{L}\p{N}][\p{L}\p{N}\p{M}]*(?:['’][\p{L}\p{N}\p{M}]+)*/gu;
const QUOTED_PHRASE_PATTERN = /"([^"]*)"/g;

export interface PostSearchV5RoutedSearchOptions {
  signal?: AbortSignal;
  limit?: number;
  operator?: 'or' | 'and';
  authors?: readonly string[];
  kinds?: readonly number[];
  since?: number;
  until?: number;
  maxScannedPostings?: number;
  maxCandidates?: number;
  documentConcurrency?: number;
}

export interface PostSearchV5RoutedSearchResult {
  event: RawEvent;
  score: number;
  matchedTerms: string[];
  matchedPhrases: number;
}

export interface PostSearchV5RoutedSearchResponse {
  results: PostSearchV5RoutedSearchResult[];
  exhaustive: boolean;
  scannedPostings: number;
  scannedCandidates: number;
}

type NormalizedOptions = {
  signal: AbortSignal | null;
  limit: number;
  operator: 'or' | 'and';
  authors: Set<string> | null;
  kinds: Set<number> | null;
  since: number | null;
  until: number | null;
  maxScannedPostings: number;
  maxCandidates: number;
  documentConcurrency: number;
};

type SelectedRun = {
  index: number;
  descriptor: PostSearchV5RoutedCatalogRunDescriptor;
  run: PostSearchV5RoutedCatalogLookup['runs'][number];
  terms: Map<string, PostSearchV5TermStats>;
};

type Candidate = {
  id: string;
  run: SelectedRun;
  postings: Map<string, PostSearchV5Posting>;
};

type PreparedCandidate = {
  candidate: Candidate;
  document: PostSearchV5StoredDocument;
  event: RawEvent;
  matchedTerms: string[];
  matchedPhrases: number;
};

type Query = { terms: string[]; phrases: string[][] };

/** Exact authenticated BM25F search until explicit safety bounds are reached. */
export class PostSearchV5RoutedSearch {
  private readonly overlayCache = new Map<string, Promise<PostSearchV5VisibilityOverlay>>();
  private readonly execution: PostSearchExecution;

  constructor(
    private readonly store: Store,
    execution?: PostSearchExecutionInput,
  ) {
    this.execution = createPostSearchExecution(execution);
  }

  async search(
    catalog: PostSearchV5RoutedCatalogLookup,
    queryText: string,
    options: PostSearchV5RoutedSearchOptions = {},
  ): Promise<PostSearchV5RoutedSearchResponse> {
    const normalized = normalizeOptions(options);
    throwIfPostSearchAborted(normalized.signal);
    let query = parseQuery(queryText);
    if (query.terms.length === 0 || normalized.limit === 0) {
      return emptyResponse();
    }
    let selected = await this.selectRuns(catalog, query.terms, normalized);
    let expansionExhaustive = true;
    const expansionTerm = hasSearchFilters(normalized)
      ? null
      : postSearchExpansionTerm(queryText, normalized.operator);
    if (expansionTerm && !globalTermFrequencies(selected, [expansionTerm]).has(expansionTerm)) {
      const expanded = await expandPostSearchV5RoutedTerm(
        catalog,
        expansionTerm,
        normalized.signal,
      );
      if (expanded.terms.length > 0) {
        query = { terms: expanded.terms, phrases: [] };
        selected = await this.selectRuns(catalog, query.terms, normalized);
        expansionExhaustive = expanded.exhaustive;
      }
    }
    const frequencies = globalTermFrequencies(selected, query.terms);
    if (query.terms.some((term) => !frequencies.has(term))
      && (normalized.operator === 'and' || query.phrases.length > 0)) {
      return emptyResponse();
    }
    const scoring = scoringForRuns(selected);
    const collected = await collectCandidates(selected, query, normalized, this.execution);
    const overlay = await this.overlay(catalog, normalized.signal);
    const byEvent = new Map<string, PostSearchV5RoutedSearchResult>();
    const candidates = collected.candidates.values();
    while (true) {
      const candidateBatch = await this.execution.run(normalized.signal, () =>
        takePostSearchIteratorBatch(candidates, this.execution.verificationBatchSize));
      if (candidateBatch.length === 0) {
        break;
      }
      const loaded = await mapWithConcurrency(
        candidateBatch,
        normalized.documentConcurrency,
        async (candidate) => await this.prepareCandidate(
          candidate,
          query,
          normalized,
          overlay,
          scoring.fieldNames,
        ),
      );
      const prepared = loaded.filter((value): value is PreparedCandidate => value !== null);
      const valid = await this.execution.verifyEvents(
        prepared.map((candidate) => candidate.event),
        normalized.signal,
      );
      for (let index = 0; index < prepared.length; index += 1) {
        if (!valid[index]) {
          continue;
        }
        const result = await this.execution.run(normalized.signal, () =>
          scorePreparedCandidate(prepared[index]!, frequencies, scoring));
        const previous = byEvent.get(result.event.id);
        if (!previous || compareResults(result, previous) < 0) {
          byEvent.set(result.event.id, result);
        }
      }
    }
    const results = await selectBestPostSearchResults(
      byEvent.values(),
      normalized.limit,
      normalized.signal,
      this.execution,
      compareResults,
    );
    return {
      results,
      exhaustive: expansionExhaustive && collected.exhaustive,
      scannedPostings: collected.scannedPostings,
      scannedCandidates: collected.candidates.size,
    };
  }

  private async selectRuns(
    catalog: PostSearchV5RoutedCatalogLookup,
    terms: readonly string[],
    options: NormalizedOptions,
  ): Promise<SelectedRun[]> {
    const matching = catalog.manifest.runs.flatMap((descriptor, index) =>
      runMatchesFilters(descriptor, options) ? [{ descriptor, index }] : []);
    return await mapWithConcurrency(matching, 4, async ({ descriptor, index }) => {
      throwIfPostSearchAborted(options.signal);
      const run = catalog.runs[index]!;
      const values = await Promise.all(terms.map(async (term) => [
        term,
        await run.getTerm(term),
      ] as const));
      const found = new Map<string, PostSearchV5TermStats>();
      for (const [term, stats] of values) {
        if (!stats) {continue;}
        if (stats.documentFrequency > run.manifest.documentCount) {
          throw new Error('Post-search v5 routed term frequency exceeds its run');
        }
        found.set(term, stats);
      }
      return { index, descriptor, run, terms: found };
    });
  }

  private async prepareCandidate(
    candidate: Candidate,
    query: Query,
    options: NormalizedOptions,
    overlay: PostSearchV5VisibilityOverlay | null,
    fieldNames: ReadonlySet<string>,
  ): Promise<PreparedCandidate | null> {
    const match = await this.execution.run(options.signal, () => {
      const matchedTerms = query.terms.filter((term) => candidate.postings.has(term));
      if (options.operator === 'and' && matchedTerms.length !== query.terms.length) {
        return null;
      }
      const matchedPhrases = countMatchedPhrases(query.phrases, candidate.postings, fieldNames);
      return matchedPhrases === query.phrases.length
        ? { matchedTerms, matchedPhrases }
        : null;
    });
    if (!match) {
      return null;
    }
    const document = await candidate.run.run.getDocument(candidate.id);
    throwIfPostSearchAborted(options.signal);
    if (!document) {throw new Error(`Missing post-search v5 routed document: ${candidate.id}`);}
    return await this.execution.run(options.signal, () => {
      const stored = parseStoredPostSearchDocument(document.value);
      if (!stored || stored.event.id !== candidate.id
        || !eventMatchesFilters(stored.event, options)
        || (overlay && !isPostSearchV5EventVisible(overlay, stored.event))) {
        return null;
      }
      return {
        candidate,
        document,
        event: stored.event,
        matchedTerms: match.matchedTerms,
        matchedPhrases: match.matchedPhrases,
      };
    });
  }

  private async overlay(
    catalog: PostSearchV5RoutedCatalogLookup,
    signal: AbortSignal | null,
  ): Promise<PostSearchV5VisibilityOverlay | null> {
    if (!catalog.overlayRoot || !catalog.manifest.overlay) {return null;}
    const key = nhashEncode(catalog.overlayRoot);
    let pending = this.overlayCache.get(key);
    if (pending) {
      this.overlayCache.delete(key);
      this.overlayCache.set(key, pending);
    } else {
      while (this.overlayCache.size >= OVERLAY_CACHE_LIMIT) {
        this.overlayCache.delete(this.overlayCache.keys().next().value as string);
      }
      const descriptor = catalog.manifest.overlay;
      pending = readPostSearchV5VisibilityOverlay(this.store, catalog.overlayRoot, {
        exactTombstoneCount: descriptor.exactTombstoneCount,
        coordinateStateCount: descriptor.coordinateStateCount,
        addressWinnerCount: descriptor.addressWinnerCount,
        addressDeletionCount: descriptor.addressDeletionCount,
        pageCount: descriptor.pageCount,
        reachableNodeCount: descriptor.reachableNodeCount,
      }).then((result) => result.overlay);
      this.overlayCache.set(key, pending);
      void pending.catch(() => {
        if (this.overlayCache.get(key) === pending) {
          this.overlayCache.delete(key);
        }
      });
    }
    throwIfPostSearchAborted(signal);
    const overlay = await pending;
    throwIfPostSearchAborted(signal);
    return overlay;
  }
}

async function collectCandidates(
  selected: readonly SelectedRun[],
  query: Query,
  options: NormalizedOptions,
  execution: PostSearchExecution,
): Promise<{ candidates: Map<string, Candidate>; exhaustive: boolean; scannedPostings: number }> {
  const candidates = new Map<string, Candidate>();
  let scannedPostings = 0;
  let exhaustive = true;
  const newestFirst = [...selected].sort((left, right) =>
    right.descriptor.newestBatchExclusive - left.descriptor.newestBatchExclusive);
  scan: for (const term of query.terms) {
    for (const run of newestFirst) {
      if (!run.terms.has(term)) {continue;}
      for await (const posting of run.run.streamPostings(term)) {
        throwIfPostSearchAborted(options.signal);
        const outcome = await execution.run(options.signal, () => {
          if (scannedPostings >= options.maxScannedPostings) {
            exhaustive = false;
            return 'stop';
          }
          scannedPostings += 1;
          const key = `${run.index}\0${posting.id}`;
          let candidate = candidates.get(key);
          if (!candidate) {
            if (candidates.size >= options.maxCandidates) {
              exhaustive = false;
              return 'stop';
            }
            candidate = { id: posting.id, run, postings: new Map() };
            candidates.set(key, candidate);
          }
          candidate.postings.set(term, posting);
          return 'continue';
        });
        if (outcome === 'stop') {
          break scan;
        }
      }
    }
  }
  return { candidates, exhaustive, scannedPostings };
}

type ScoringContext = {
  documentCount: number;
  k1: number;
  fields: Map<string, RankedSearchFieldManifest>;
  fieldNames: Set<string>;
};

function scoringForRuns(runs: readonly SelectedRun[]): ScoringContext {
  if (runs.length === 0) {
    return { documentCount: 0, k1: 1.2, fields: new Map(), fieldNames: new Set() };
  }
  const first = runs[0]!.run.manifest;
  const fields = new Map(first.fields.map(({ name, boost, lengthNormalization }) => [name, {
    name, boost, lengthNormalization, totalLength: 0, populatedDocumentCount: 0,
  }]));
  let documentCount = 0;
  for (const selected of runs) {
    const manifest = selected.run.manifest;
    if (manifest.k1 !== first.k1 || !sameFieldSchema(manifest.fields, first.fields)) {
      throw new Error('Post-search v5 routed runs use incompatible scoring schemas');
    }
    documentCount += manifest.documentCount;
    for (const field of manifest.fields) {
      const total = fields.get(field.name)!;
      total.totalLength += field.totalLength;
      total.populatedDocumentCount += field.populatedDocumentCount;
    }
  }
  return { documentCount, k1: first.k1, fields, fieldNames: new Set(fields.keys()) };
}

function globalTermFrequencies(
  runs: readonly SelectedRun[],
  terms: readonly string[],
): Map<string, number> {
  const frequencies = new Map<string, number>();
  for (const term of terms) {
    const count = runs.reduce((sum, run) => sum + (run.terms.get(term)?.documentFrequency ?? 0), 0);
    if (count > 0) {frequencies.set(term, count);}
  }
  return frequencies;
}

function scoreCandidate(
  document: PostSearchV5StoredDocument,
  postings: ReadonlyMap<string, PostSearchV5Posting>,
  matchedTerms: readonly string[],
  frequencies: ReadonlyMap<string, number>,
  scoring: ScoringContext,
): number {
  let score = 0;
  for (const term of matchedTerms) {
    const posting = postings.get(term);
    const frequency = frequencies.get(term);
    if (!posting || frequency === undefined) {continue;}
    let weightedFrequency = 0;
    for (const [fieldName, fieldPosting] of Object.entries(posting.fields)) {
      const field = scoring.fields.get(fieldName);
      if (!field) {continue;}
      const average = field.populatedDocumentCount > 0
        ? field.totalLength / field.populatedDocumentCount
        : 0;
      const length = document.lengths[fieldName] ?? 0;
      const normalization = average > 0
        ? (1 - field.lengthNormalization) + field.lengthNormalization * (length / average)
        : 1;
      weightedFrequency += field.boost * fieldPosting.frequency / Math.max(normalization, 1e-12);
    }
    if (weightedFrequency <= 0) {continue;}
    const boundedFrequency = Math.max(0, Math.min(frequency, scoring.documentCount));
    const idf = Math.log(1 + (scoring.documentCount - boundedFrequency + 0.5)
      / (boundedFrequency + 0.5));
    score += idf * ((scoring.k1 + 1) * weightedFrequency)
      / (scoring.k1 + weightedFrequency);
  }
  return score;
}

function scorePreparedCandidate(
  prepared: PreparedCandidate,
  frequencies: ReadonlyMap<string, number>,
  scoring: ScoringContext,
): PostSearchV5RoutedSearchResult {
  return {
    event: prepared.event,
    score: scoreCandidate(
      prepared.document,
      prepared.candidate.postings,
      prepared.matchedTerms,
      frequencies,
      scoring,
    ),
    matchedTerms: [...prepared.matchedTerms].sort(compareText),
    matchedPhrases: prepared.matchedPhrases,
  };
}

function countMatchedPhrases(
  phrases: readonly (readonly string[])[],
  postings: ReadonlyMap<string, PostSearchV5Posting>,
  fields: ReadonlySet<string>,
): number {
  return phrases.reduce((matched, phrase) => {
    for (const field of fields) {
      const starts = postings.get(phrase[0]!)?.fields[field]?.positions;
      if (!starts) {continue;}
      const following = phrase.slice(1).map((term) =>
        new Set(postings.get(term)?.fields[field]?.positions ?? []));
      if (starts.some((start) => following.every((positions, offset) =>
        positions.has(start + offset + 1)))) {
        return matched + 1;
      }
    }
    return matched;
  }, 0);
}

function parseQuery(text: string): Query {
  const normalized = normalizeText(text).replace(/[“”]/g, '"');
  const terms: string[] = [];
  const phrases: string[][] = [];
  const seen = new Set<string>();
  let cursor = 0;
  QUOTED_PHRASE_PATTERN.lastIndex = 0;
  for (const match of normalized.matchAll(QUOTED_PHRASE_PATTERN)) {
    const start = match.index ?? 0;
    appendUnique(queryTerms(normalized.slice(cursor, start)), terms, seen);
    const phrase = queryTerms(match[1] ?? '');
    if (phrase.length > 0) {
      phrases.push(phrase);
      appendUnique(phrase, terms, seen);
    }
    cursor = start + match[0].length;
  }
  appendUnique(queryTerms(normalized.slice(cursor)), terms, seen);
  return { terms, phrases };
}

function queryTerms(text: string): string[] {
  TOKEN_PATTERN.lastIndex = 0;
  return [...normalizeText(text).matchAll(TOKEN_PATTERN)].flatMap((match) => {
    const hashtag = match[1] !== undefined;
    const term = hashtag ? match[1] : match[0];
    return term ? [hashtag ? `#${term}` : term] : [];
  });
}

function normalizeText(value: string): string {
  return value.normalize('NFKC').toLowerCase().replace(/’/g, "'");
}

function appendUnique(source: readonly string[], target: string[], seen: Set<string>): void {
  for (const term of source) {
    if (!seen.has(term)) {seen.add(term); target.push(term);}
  }
}

function runMatchesFilters(
  run: PostSearchV5RoutedCatalogRunDescriptor,
  options: NormalizedOptions,
): boolean {
  return (!options.kinds || run.kinds.some((kind) => options.kinds!.has(kind)))
    && (options.since === null || run.until >= options.since)
    && (options.until === null || run.since <= options.until);
}

function hasSearchFilters(options: NormalizedOptions): boolean {
  return options.authors !== null
    || options.kinds !== null
    || options.since !== null
    || options.until !== null;
}

function eventMatchesFilters(event: RawEvent, options: NormalizedOptions): boolean {
  return (!options.authors || options.authors.has(event.pubkey))
    && (!options.kinds || options.kinds.has(event.kind))
    && (options.since === null || event.created_at >= options.since)
    && (options.until === null || event.created_at <= options.until);
}

function normalizeOptions(options: PostSearchV5RoutedSearchOptions): NormalizedOptions {
  const since = optionalTimestamp(options.since, 'since');
  const until = optionalTimestamp(options.until, 'until');
  if (since !== null && until !== null && since > until) {
    throw new Error('Post-search v5 since must not be later than until');
  }
  return {
    signal: options.signal ?? null,
    limit: boundedInteger(options.limit, DEFAULT_LIMIT, 0, MAX_LIMIT),
    operator: options.operator ?? 'or',
    authors: options.authors?.length
      ? new Set(options.authors.map((author) => author.trim().toLowerCase()).filter(Boolean))
      : null,
    kinds: options.kinds?.length ? new Set(options.kinds) : null,
    since,
    until,
    maxScannedPostings: boundedInteger(
      options.maxScannedPostings,
      DEFAULT_MAX_SCANNED_POSTINGS,
      1,
      HARD_MAX_SCANNED_POSTINGS,
    ),
    maxCandidates: boundedInteger(
      options.maxCandidates,
      DEFAULT_MAX_CANDIDATES,
      1,
      HARD_MAX_CANDIDATES,
    ),
    documentConcurrency: boundedInteger(
      options.documentConcurrency,
      DEFAULT_DOCUMENT_CONCURRENCY,
      1,
      MAX_DOCUMENT_CONCURRENCY,
    ),
  };
}

function optionalTimestamp(value: number | undefined, label: string): number | null {
  if (value === undefined) {return null;}
  if (!Number.isSafeInteger(value) || value < 0) {throw new Error(`Invalid post-search v5 ${label}`);}
  return value;
}

function boundedInteger(value: number | undefined, fallback: number, min: number, max: number): number {
  if (value === undefined) {return fallback;}
  if (!Number.isFinite(value)) {throw new Error('Invalid post-search v5 search bound');}
  return Math.max(min, Math.min(max, Math.trunc(value)));
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  work: (value: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, async () => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await work(values[index]!, index);
    }
  }));
  return results;
}

function sameFieldSchema(
  left: readonly RankedSearchFieldManifest[],
  right: readonly RankedSearchFieldManifest[],
): boolean {
  return left.length === right.length && left.every((field, index) => {
    const other = right[index];
    return other?.name === field.name && other.boost === field.boost
      && other.lengthNormalization === field.lengthNormalization;
  });
}

function compareResults(
  left: PostSearchV5RoutedSearchResult,
  right: PostSearchV5RoutedSearchResult,
): number {
  return right.score - left.score
    || right.matchedPhrases - left.matchedPhrases
    || right.event.created_at - left.event.created_at
    || compareText(left.event.id, right.event.id);
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function emptyResponse(): PostSearchV5RoutedSearchResponse {
  return { results: [], exhaustive: true, scannedPostings: 0, scannedCandidates: 0 };
}
