import { isNip10ReplyTag } from './nostrReplyTags';
import type { RawEvent } from './nostr';

const hexKey = /^[0-9a-f]{64}$/;
const postKinds = new Set([1, 20, 1111, 30023]);

export function isBulkAddressedPost(event: RawEvent): boolean {
  if (!postKinds.has(event.kind)) { return false; }
  const recipients = new Set<string>();
  for (const [name, value] of event.tags) {
    if (name === 'p' && hexKey.test(value ?? '')) {
      recipients.add(value!);
      if (recipients.size > 10) { return true; }
    }
  }
  return false;
}

function nip10Parent(event: RawEvent): string[] | undefined {
  const refs = event.tags.filter(tag => isNip10ReplyTag(tag) && hexKey.test(tag[1] ?? ''));
  const replies = refs.filter(tag => tag[3]?.trim().toLowerCase() === 'reply');
  if (replies.length) { return replies.length === 1 ? replies[0] : undefined; }
  if (refs.length === 1) { return refs[0]; }
  // Legacy positional threads put the immediate parent last. A root among
  // several marked references is never enough to establish a direct reply.
  if (refs.every(tag => !tag[3])) { return refs.at(-1); }
  return undefined;
}

export function allowsAddressedNotification(
  event: RawEvent,
  viewer: string,
  follows: ReadonlySet<string>,
  knownAuthor: (id: string) => string | undefined,
): boolean {
  if (!isBulkAddressedPost(event) || follows.has(event.pubkey)) { return true; }
  if (event.kind === 1111) {
    const refs = event.tags.filter(tag => tag[0] === 'e' || tag[0] === 'a' || tag[0] === 'i');
    if (refs.length !== 1) { return false; }
    const [type, value, , authorHint] = refs[0]!;
    if (type === 'e' && hexKey.test(value ?? '')) {
      return (knownAuthor(value!) ?? authorHint) === viewer;
    }
    // A valid address coordinates the immediate parent by kind, author and d.
    const match = type === 'a' && /^(\d+):([0-9a-f]{64}):/.exec(value ?? '');
    return Boolean(match && Number(match[1]) >= 30000 && Number(match[1]) < 40000 && match[2] === viewer);
  }
  const parent = nip10Parent(event);
  return Boolean(parent && (knownAuthor(parent[1]!) ?? parent[4]) === viewer);
}
