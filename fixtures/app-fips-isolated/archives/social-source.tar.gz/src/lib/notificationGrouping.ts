import type { NotificationItem } from './appDetailLoaders';

export type NotificationGroup = {
  id: string;
  kind: NotificationItem['kind'];
  items: NotificationItem[];
  latest: NotificationItem;
  targetEvent: NotificationItem['targetEvent'];
  targetRef: string;
  bits: number;
};

function replyTarget(item: NotificationItem): string {
  if (item.kind !== 'reply') {
    return item.targetRef;
  }
  return item.actorEvent.tags.find((tag) => ['e', 'a', 'i'].includes(tag[0] ?? ''))?.[1]
    ?? item.targetRef;
}

function newer(left: NotificationItem, right: NotificationItem): NotificationItem {
  return left.actorEvent.created_at > right.actorEvent.created_at
    || (left.actorEvent.created_at === right.actorEvent.created_at && left.id < right.id)
    ? left
    : right;
}

export function groupNotificationItems(items: readonly NotificationItem[]): NotificationGroup[] {
  const grouped = new Map<string, NotificationItem[]>();
  for (const item of items) {
    const key = `${item.kind}:${replyTarget(item)}`;
    grouped.set(key, [...(grouped.get(key) ?? []), item]);
  }

  return [...grouped.entries()].map(([id, candidates]) => {
    const byActor = new Map<string, NotificationItem>();
    for (const item of candidates) {
      const actor = item.actorEvent.pubkey;
      byActor.set(actor, byActor.has(actor) ? newer(item, byActor.get(actor)!) : item);
    }
    const groupedItems = [...byActor.values()].sort((left, right) => (
      right.actorEvent.created_at - left.actorEvent.created_at || left.id.localeCompare(right.id)
    ));
    const latest = groupedItems[0]!;
    return {
      id,
      kind: latest.kind,
      items: groupedItems,
      latest,
      targetEvent: candidates.find((item) => item.targetEvent)?.targetEvent ?? null,
      targetRef: latest.targetRef,
      bits: groupedItems.reduce((sum, item) => sum + (item.bits ?? 0), 0),
    };
  }).sort((left, right) => (
    right.latest.actorEvent.created_at - left.latest.actorEvent.created_at
    || left.id.localeCompare(right.id)
  ));
}
