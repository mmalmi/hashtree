import type { NotificationItem } from './appDetailLoaders';

export type NotificationGroup = {
  id: string;
  kind: NotificationItem['kind'];
  /** The newest item from each actor, newest first. */
  items: NotificationItem[];
  reactedPosts: NotificationItem[];
  latest: NotificationItem;
  targetEvent: NotificationItem['targetEvent'];
  targetRef: string;
  /** Every zap in the group counts, including repeat zaps from one actor. */
  bits: number;
  /** Zap totals per actor, for the avatar badges. */
  bitsByActor: Map<string, number>;
};

function compareItems(left: NotificationItem, right: NotificationItem): number {
  return right.actorEvent.created_at - left.actorEvent.created_at || left.id.localeCompare(right.id);
}

function actorDay(item: NotificationItem): string | null {
  // Items without a valid reaction target fall back to the reaction's own id.
  if (item.kind !== 'like' || item.targetRef === item.id) {return null;}
  return `actor:${item.actorEvent.pubkey}:${Math.floor(item.actorEvent.created_at / 86_400)}`;
}

/** Replies and mentions carry their own text, so each stays its own row. */
function groupKey(item: NotificationItem): string {
  return item.kind === 'reply' || item.kind === 'mention'
    ? `${item.kind}:${item.id}`
    : `${item.kind}:${item.targetRef}`;
}

/**
 * Group like Iris Client: reactions, reposts and zaps become one row per
 * target post and kind. One actor reacting to several posts on one day becomes
 * one row when it replaces at least one complete post row.
 */
export function groupNotificationItems(items: readonly NotificationItem[]): NotificationGroup[] {
  const postsByActorDay = new Map<string, Set<string>>();
  const soleActorDay = new Map<string, string | null>();
  for (const item of items) {
    const day = actorDay(item);
    if (!day) {continue;}
    const posts = postsByActorDay.get(day);
    if (posts) {posts.add(item.targetRef);}
    else {postsByActorDay.set(day, new Set([item.targetRef]));}
    if (!soleActorDay.has(item.targetRef)) {soleActorDay.set(item.targetRef, day);}
    else if (soleActorDay.get(item.targetRef) !== day) {soleActorDay.set(item.targetRef, null);}
  }
  // Leave popular posts grouped by post when splitting them would add rows.
  const bursts = new Set([...soleActorDay.values()].filter((day): day is string =>
    day !== null && postsByActorDay.get(day)!.size > 1
  ));

  const grouped = new Map<string, NotificationItem[]>();
  const seen = new Set<string>();
  for (const item of [...items].sort(compareItems)) {
    if (seen.has(item.id)) {continue;}
    seen.add(item.id);
    const day = actorDay(item);
    const key = day && bursts.has(day) ? day : groupKey(item);
    const candidates = grouped.get(key);
    if (candidates) {candidates.push(item);}
    else {grouped.set(key, [item]);}
  }

  return [...grouped.entries()].map(([id, candidates]) => {
    const byActor = new Map<string, NotificationItem>();
    const byPost = new Map<string, NotificationItem>();
    const bitsByActor = new Map<string, number>();
    let bits = 0;
    for (const item of candidates) {
      if (!byActor.has(item.actorEvent.pubkey)) {byActor.set(item.actorEvent.pubkey, item);}
      if (bursts.has(id) && !byPost.has(item.targetRef)) {byPost.set(item.targetRef, item);}
      if (item.bits) {
        bits += item.bits;
        bitsByActor.set(item.actorEvent.pubkey, (bitsByActor.get(item.actorEvent.pubkey) ?? 0) + item.bits);
      }
    }
    const latest = candidates[0]!;
    return {
      id,
      kind: latest.kind,
      items: [...byActor.values()],
      reactedPosts: [...byPost.values()],
      latest,
      targetEvent: candidates.find((item) => item.targetEvent)?.targetEvent ?? null,
      targetRef: latest.targetRef,
      bits,
      bitsByActor,
    };
  }).sort((left, right) => (
    right.latest.actorEvent.created_at - left.latest.actorEvent.created_at
    || left.id.localeCompare(right.id)
  ));
}
