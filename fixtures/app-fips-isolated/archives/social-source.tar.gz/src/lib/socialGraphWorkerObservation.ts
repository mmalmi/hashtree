import { socialGraphBadges } from './socialGraphBadges';
import type { RawEvent } from './nostr';
import {
  MAX_SOCIAL_GRAPH_OBSERVATION_BATCH_CODE_UNITS,
  MAX_SOCIAL_GRAPH_OBSERVATION_EVENTS,
  measureSocialGraphObservationEvent,
} from '../workers/socialWorkerProtocol';
import { isNewerReplaceableEvent } from './nostrEventOrdering';

const OBSERVED_SOCIAL_GRAPH_KINDS = new Set([3, 10_000]);
const MAX_PENDING_SOCIAL_GRAPH_COORDINATES = 4_096;
const MAX_PENDING_SOCIAL_GRAPH_CODE_UNITS = 8 * 1_048_576;
const RETRY_DELAY_MS = 2_000;
const WARNING_INTERVAL_MS = 30_000;

type PendingSocialGraphEvent = {
  event: RawEvent;
  codeUnits: number;
};

const pendingEvents = new Map<string, PendingSocialGraphEvent>();
let pendingCodeUnits = 0;
let drainScheduled = false;
let draining = false;
let retryTimer: ReturnType<typeof setTimeout> | null = null;
let lastWarningAt = 0;

export function isNewerWorkerSocialGraphEvent(
  candidate: RawEvent,
  current: RawEvent,
): boolean {
  return isNewerReplaceableEvent(candidate, current);
}

function rememberPendingEvent(event: RawEvent): void {
  const codeUnits = measureSocialGraphObservationEvent(event);
  if (codeUnits === null) {
    return;
  }
  const key = `${event.kind}:${event.pubkey}`;
  const current = pendingEvents.get(key);
  if (current && !isNewerWorkerSocialGraphEvent(event, current.event)) {
    return;
  }
  if (current) {
    pendingCodeUnits -= current.codeUnits;
    pendingEvents.delete(key);
  }
  while (
    pendingEvents.size >= MAX_PENDING_SOCIAL_GRAPH_COORDINATES
    || pendingCodeUnits + codeUnits > MAX_PENDING_SOCIAL_GRAPH_CODE_UNITS
  ) {
    const oldestKey = pendingEvents.keys().next().value;
    if (!oldestKey) {
      break;
    }
    pendingCodeUnits -= pendingEvents.get(oldestKey)?.codeUnits ?? 0;
    pendingEvents.delete(oldestKey);
  }
  pendingEvents.set(key, { event, codeUnits });
  pendingCodeUnits += codeUnits;
}

function takePendingBatch(): RawEvent[] {
  const batch: RawEvent[] = [];
  let batchCodeUnits = 0;
  for (const [key, pending] of pendingEvents) {
    if (
      batch.length > 0
      && batchCodeUnits + pending.codeUnits > MAX_SOCIAL_GRAPH_OBSERVATION_BATCH_CODE_UNITS
    ) {
      break;
    }
    pendingEvents.delete(key);
    pendingCodeUnits -= pending.codeUnits;
    batchCodeUnits += pending.codeUnits;
    batch.push(pending.event);
    if (batch.length >= MAX_SOCIAL_GRAPH_OBSERVATION_EVENTS) {
      break;
    }
  }
  return batch;
}

function scheduleDrain(): void {
  if (drainScheduled || draining || retryTimer || pendingEvents.size === 0) {
    return;
  }
  drainScheduled = true;
  queueMicrotask(() => {
    drainScheduled = false;
    void drainPendingEvents();
  });
}

function warnDrainFailure(error: unknown): void {
  const now = Date.now();
  if (now - lastWarningAt < WARNING_INTERVAL_MS) {
    return;
  }
  lastWarningAt = now;
  console.warn('Failed to update worker social graph cache', error);
}

async function drainPendingEvents(): Promise<void> {
  if (draining || pendingEvents.size === 0) {
    return;
  }
  draining = true;
  let activeBatch: RawEvent[] = [];
  try {
    const { getWorkerClient } = await import('./workerClient');
    const client = await getWorkerClient();
    while (pendingEvents.size > 0) {
      activeBatch = takePendingBatch();
      await client.observeSocialGraphEvents(activeBatch);
      socialGraphBadges.invalidate();
      activeBatch = [];
    }
  } catch (error) {
    const retryable = !(error instanceof RangeError);
    if (retryable) {
      for (const event of activeBatch) {
        rememberPendingEvent(event);
      }
    }
    warnDrainFailure(error);
    if (retryable) {
      retryTimer = setTimeout(() => {
        retryTimer = null;
        scheduleDrain();
      }, RETRY_DELAY_MS);
    }
  } finally {
    draining = false;
    scheduleDrain();
  }
}

/** Queue verified contact/mute replacements for the canonical data worker. */
export function queueWorkerSocialGraphEvent(event: RawEvent | null | undefined): void {
  if (
    typeof window === 'undefined'
    || !event
    || !OBSERVED_SOCIAL_GRAPH_KINDS.has(event.kind)
  ) {
    return;
  }
  rememberPendingEvent(event);
  scheduleDrain();
}
