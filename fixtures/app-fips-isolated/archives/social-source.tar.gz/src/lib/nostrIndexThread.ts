import type { CID } from '@hashtree/core';
import {
  NOTE_ENGAGEMENT_EVENT_KINDS,
  summarizeNoteEngagementEvents,
  type NoteEngagement,
} from './noteEngagement';
import {
  getThreadParentReference,
  getThreadRootReference,
  isHexEventId,
  type RawEvent,
} from './nostr';
import { verifyAndAsRawEvent } from './nostrIndexEvent';
import { getRootNhash } from './nostrIndexRoots';
import type { NoteDetailListKind, NoteThreadSnapshot } from './nostrIndexTypes';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import {
  MAX_ROUTED_ENGAGEMENT_EVENTS,
  MAX_ROUTED_ENGAGEMENT_TARGETS,
  routedEngagementEventsByTagValues,
  routedEventById,
  routedEventByRef,
  routedEventsByTag,
} from './routedEventReads';
import {
  buildThreadContext,
  type ThreadRepliesPage,
} from './threadReplyPagination';
import {
  loadRoutedRepliesForEvent,
  loadRoutedRepliesForEventPage,
} from './routedThreadReplies';
import { validateZapReceipt } from './zapReceipt';
import { admitZapReceiptEvents } from './zapReceipt';

const NOTE_DETAIL_EVENT_KINDS: Record<NoteDetailListKind, number[]> = {
  likes: [7],
  reposts: [6, 16],
  zaps: [9735],
};

function uniqueRoots(roots: CID | CID[]): CID[] {
  return [...new Map(
    (Array.isArray(roots) ? roots : [roots]).map((root) => [getRootNhash(root), root] as const),
  ).values()];
}

async function getEventByIdFromRoots(roots: CID[], eventId: string): Promise<RawEvent | null> {
  const event = await routedEventById(roots, eventId);
  return event ? await verifyAndAsRawEvent(event) : null;
}

async function loadEventByRefFromRoots(roots: CID[], ref: string): Promise<RawEvent | null> {
  const event = await routedEventByRef(roots, ref);
  return event ? await verifyAndAsRawEvent(event) : null;
}

async function getRoutedEventsByTagFromRoots(
  roots: CID[],
  tagName: string,
  tagValue: string,
  kinds: readonly number[],
  limit: number,
): Promise<RawEvent[]> {
  const events = await routedEventsByTag(roots, tagName, tagValue, kinds, limit);
  const verified = await Promise.all(events.map(async (event) => await verifyAndAsRawEvent(event)));
  return verified.filter((event): event is RawEvent => event !== null);
}

export async function loadEventById(
  roots: CID | CID[],
  eventId: string,
): Promise<RawEvent | null> {
  return await getEventByIdFromRoots(uniqueRoots(roots), eventId);
}

export async function loadEventByRef(
  roots: CID | CID[],
  ref: string,
): Promise<RawEvent | null> {
  return await loadEventByRefFromRoots(uniqueRoots(roots), ref);
}

export async function loadThreadContext(
  roots: CID | CID[],
  noteRefOrId: string,
): Promise<NoteThreadSnapshot> {
  const unique = uniqueRoots(roots);
  const note = await loadEventByRefFromRoots(unique, noteRefOrId);
  return note
    ? await loadThreadContextForEvent(unique, note)
    : {
        rootNhash: unique.length > 0 ? getRootNhash(unique[0]!) : '',
        note: null,
        root: null,
        parent: null,
        context: [],
      };
}

export async function loadThreadContextForEvent(
  roots: CID | CID[],
  note: RawEvent,
): Promise<NoteThreadSnapshot> {
  const unique = uniqueRoots(roots);
  const rootRef = getThreadRootReference(note);
  const parentRef = getThreadParentReference(note);
  const rootPromise = rootRef && rootRef !== note.id
    ? loadEventByRefFromRoots(unique, rootRef)
    : Promise.resolve(null);
  const parentPromise = parentRef && parentRef !== note.id
    ? parentRef === rootRef
      ? rootPromise
      : loadEventByRefFromRoots(unique, parentRef)
    : Promise.resolve(null);
  const [root, parent] = await Promise.all([rootPromise, parentPromise]);

  return {
    rootNhash: unique.length > 0 ? getRootNhash(unique[0]!) : '',
    note,
    root,
    parent,
    context: buildThreadContext(note, root, parent),
  };
}

export async function loadNoteReplies(
  roots: CID | CID[],
  noteId: string,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  const unique = uniqueRoots(roots);
  const limit = Math.max(options.limit ?? 50, 1);
  return await getRoutedEventsByTagFromRoots(
    unique,
    'e',
    noteId,
    [1, 1111],
    limit,
  );
}

export async function loadRepliesForEvent(
  roots: CID | CID[],
  event: RawEvent,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  return await loadRoutedRepliesForEvent(roots, event, options);
}

export async function loadRepliesForEventPage(
  roots: CID | CID[],
  event: RawEvent,
  options: {
    before?: RecentTextNoteCursor;
    limit?: number;
  } = {},
): Promise<ThreadRepliesPage> {
  return await loadRoutedRepliesForEventPage(roots, event, options);
}

export async function loadNoteDetailEvents(
  roots: CID | CID[],
  noteId: string,
  detailKind: NoteDetailListKind,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  const unique = uniqueRoots(roots);
  const limit = Math.max(options.limit ?? 50, 1);
  if (!isHexEventId(noteId)) {return [];}
  return await getRoutedEventsByTagFromRoots(
    unique,
    'e',
    noteId,
    NOTE_DETAIL_EVENT_KINDS[detailKind],
    limit,
  );
}

export async function loadNoteLikes(
  roots: CID | CID[],
  noteId: string,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  return await loadNoteDetailEvents(roots, noteId, 'likes', options);
}

export async function loadNoteReposts(
  roots: CID | CID[],
  noteId: string,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  return await loadNoteDetailEvents(roots, noteId, 'reposts', options);
}

export async function loadNoteZaps(
  roots: CID | CID[],
  noteId: string,
  options: {
    limit?: number;
  } = {},
): Promise<RawEvent[]> {
  const limit = Math.max(options.limit ?? 50, 1);
  const candidateLimit = Math.min(
    Math.max(limit * 4, 64),
    MAX_ROUTED_ENGAGEMENT_EVENTS,
  );
  const candidates = await loadNoteDetailEvents(roots, noteId, 'zaps', {
    limit: candidateLimit,
  });
  await admitZapReceiptEvents(candidates);
  return candidates.filter((event) => Boolean(validateZapReceipt(event, {
    eventId: noteId,
  }))).slice(0, limit);
}

export async function loadNoteEngagements(
  roots: CID | CID[],
  noteIds: string[],
  viewerPubkey?: string | null,
  options: {
    signal?: AbortSignal;
  } = {},
): Promise<Map<string, NoteEngagement>> {
  const engagementRoots = (Array.isArray(roots) ? roots : [roots]).filter((root, index, allRoots) => (
    allRoots.findIndex((candidate) => getRootNhash(candidate) === getRootNhash(root)) === index
  ));
  const uniqueNoteIds = [...new Set(noteIds
    .map((noteId) => noteId.trim().toLowerCase())
    .filter(isHexEventId))]
    .slice(0, MAX_ROUTED_ENGAGEMENT_TARGETS);
  options.signal?.throwIfAborted();
  const eventGroups = await routedEngagementEventsByTagValues(
    engagementRoots,
    uniqueNoteIds,
    NOTE_ENGAGEMENT_EVENT_KINDS,
    MAX_ROUTED_ENGAGEMENT_EVENTS,
    { signal: options.signal },
  );
  options.signal?.throwIfAborted();
  await admitZapReceiptEvents(
    [...new Map(
      [...eventGroups.values()].flat()
        .filter((event) => event.kind === 9_735)
        .map((event) => [`${event.id}:${event.sig}`, event] as const),
    ).values()],
  );
  options.signal?.throwIfAborted();
  return new Map(uniqueNoteIds.map((noteId) => [
    noteId,
    summarizeNoteEngagementEvents(noteId, eventGroups.get(noteId) ?? [], viewerPubkey),
  ]));
}
