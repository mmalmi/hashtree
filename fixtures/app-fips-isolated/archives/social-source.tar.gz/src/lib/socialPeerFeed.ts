import { writable } from 'svelte/store';
import { canSignAccount } from './accountSigner';
import { accountsStore, type SocialAccount } from './accounts';
import { NOTIFICATION_EVENT_KINDS } from './notificationPagination';
import {
  isPrivateRelayEvent, verifyNostrEvent,
  type NostrEvent, type NostrFilter, type PublicPeerFeed, type RuntimeSource,
} from 'nostr-pubsub';

// All routes share the same account feed. A restored page can temporarily have
// no contacts event while the index loads. Keep the winning signed revision.
const postKinds = [1, 6, 16, 20, 1111, 30023];
const latest: PublicPeerFeed = { type: 'latest', kinds: postKinds };
export const peerFeeds = writable<readonly PublicPeerFeed[]>([latest]);
let account: string | null = null;
let winner: NostrEvent | undefined;

export function updateAccountPeerFeed(candidate?: NostrEvent | null): void {
  const state = accountsStore.getState();
  updatePeerFeed(state.accounts.find(active => active.pubkey === state.activeAccountPubkey) ?? null, candidate);
}

export function updatePeerFeed(active: SocialAccount | null, candidate?: NostrEvent | null): void {
  const owner = active && canSignAccount(active) ? active.pubkey : null;
  const changedAccount = owner !== account;
  if (changedAccount) { account = owner; winner = undefined; }
  if (owner && candidate?.kind === 3 && candidate.pubkey === owner &&
      (!winner || candidate.created_at > winner.created_at ||
        (candidate.created_at === winner.created_at && candidate.id < winner.id))) {
    try {
      winner = verifyNostrEvent(candidate);
    } catch {
      if (!changedAccount) { return; }
    }
  } else if (!changedAccount) { return; }
  if (!owner) { peerFeeds.set([latest]); return; }
  peerFeeds.set([
    winner ? { type: 'following', owner, contacts: winner, kinds: postKinds } : latest,
    { type: 'notifications', owner, kinds: NOTIFICATION_EVENT_KINDS },
  ]);
}

const inboxFields = new Set(['kinds', 'authors', '#p', 'since', 'until', 'limit']);
function isInbox(filter: NostrFilter): boolean {
  return Boolean(filter.kinds?.length && filter.kinds.every(kind => isPrivateRelayEvent({kind})) &&
    (filter.authors?.length || filter['#p']?.length) && Object.keys(filter).every(key => inboxFields.has(key)));
}

/** UI queries match the public feed locally. Only encrypted inbox subscriptions use the messaging endpoint. */
export function socialPeerSource(feed: RuntimeSource, messaging: RuntimeSource): RuntimeSource {
  function routes(filters: NostrFilter[]) {
    const inbox = filters.filter(isInbox);
    const local = filters.filter(filter => !isInbox(filter));
    return [...(local.length ? [{source: feed, filters: local}] : []),
      ...(inbox.length ? [{source: messaging, filters: inbox}] : [])];
  }
  return {
    id: messaging.id, publishAcceptance: messaging.publishAcceptance,
    publish: (event, origin) => (isPrivateRelayEvent(event) ? messaging : feed).publish!(event, origin),
    async query(filters, options) {
      const results = await Promise.all(routes(filters).map(r => r.source.query!(r.filters, options)));
      return { events: results.flatMap(result => result.events), complete: results.every(result => result.complete !== false) };
    },
    async subscribe(filters, handler) {
      const opened = await Promise.allSettled(routes(filters).map(async r => r.source.subscribe!(r.filters, handler)));
      const close = () => {
        for (const entry of opened) {
          if (entry.status === 'fulfilled') { entry.value.close(); }
        }
      };
      const failed = opened.find(entry => entry.status === 'rejected');
      if (failed) { close(); throw failed.reason; }
      return { close };
    },
  };
}
