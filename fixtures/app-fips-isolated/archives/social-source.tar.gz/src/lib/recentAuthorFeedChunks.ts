import type { RawEvent } from './nostr';
import { mergeRecentEvents } from './nostrEventMerge';

export const MAX_RECENT_AUTHOR_FALLBACK_CHUNK = 128;

/** Merge every author chunk while keeping iterator fanout strictly bounded. */
export async function* streamChunkedAuthorFeed(
  authors: string[],
  limit: number,
  isAborted: () => boolean,
  streamChunk: (
    chunk: string[],
    chunkIndex: number,
  ) => AsyncGenerator<RawEvent[], void, void>,
): AsyncGenerator<RawEvent[], void, void> {
  let merged: RawEvent[] = [];
  for (
    let offset = 0, chunkIndex = 0;
    offset < authors.length && !isAborted();
    offset += MAX_RECENT_AUTHOR_FALLBACK_CHUNK, chunkIndex += 1
  ) {
    const base = merged;
    let chunkLatest: RawEvent[] | null = null;
    for await (const notes of streamChunk(
      authors.slice(offset, offset + MAX_RECENT_AUTHOR_FALLBACK_CHUNK),
      chunkIndex,
    )) {
      if (isAborted()) {
        return;
      }
      chunkLatest = mergeRecentEvents(limit, base, notes);
      yield chunkLatest;
    }
    if (chunkLatest) {
      merged = chunkLatest;
    }
  }
}
