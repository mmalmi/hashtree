import * as nip19 from 'nostr-tools/nip19';

export function postSearchPublisherId(ref: string): string | null {
  const slashIndex = ref.indexOf('/');
  if (slashIndex <= 0 || slashIndex === ref.length - 1) {
    return null;
  }
  const npub = ref.slice(0, slashIndex);
  if (!npub.startsWith('npub1')) {
    return null;
  }
  try {
    const decoded = nip19.decode(npub);
    return decoded.type === 'npub' && typeof decoded.data === 'string' ? decoded.data : null;
  } catch {
    return null;
  }
}
