import * as nip19 from 'nostr-tools/nip19';
import type { RawEvent } from './nostr';
import { threadHref } from './routes';

export function buildNoteIdentifier(noteId: string): string {
  return nip19.noteEncode(noteId);
}

export function buildNoteThreadReference(event: RawEvent): string {
  return nip19.neventEncode({
    id: event.id,
    author: event.pubkey,
    kind: event.kind,
  });
}

export function buildNoteShareUrl(event: RawEvent): string {
  const reference = buildNoteThreadReference(event);
  return new URL(threadHref(reference), 'https://social.iris.to').toString();
}
