import type { RawEvent } from './nostr';
import type { RestoredSocialDataPlaneState } from './socialDataPlaneSupport';
import type {
  RestoredSocialOutboxJournal,
  SocialOutboxJournalCoordinator,
  SocialOutboxObligations,
} from './socialOutboxJournal';
import { throwIfProfileLoadAborted } from './profileLoadAbort';
import type { SocialEventRepository } from './socialRepository';
import type { SocialOverlayPersistence } from './socialOverlayPersistence';

type RestorationOptions = {
  repository: SocialEventRepository;
  outboxJournal: SocialOutboxJournalCoordinator;
  overlayPersistence: SocialOverlayPersistence;
  applyJournalObligations: (entry: {
    event: RawEvent;
    obligations: SocialOutboxObligations;
  }) => void;
  enforceOverlayBound: () => boolean;
};

async function waitUntilAfterApplicationPaint(): Promise<void> {
  await new Promise<void>((resolve) => {
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(() => setTimeout(resolve, 0));
    } else {
      setTimeout(resolve, 0);
    }
  });
}

/** Restores the compatibility overlay without putting it on the application mount task. */
export class SocialDataPlaneRestoration {
  private readonly options: RestorationOptions;
  private pending: Promise<RawEvent[]> | null = null;
  private abortController: AbortController | null = null;
  private restored = false;

  constructor(options: RestorationOptions) {
    this.options = options;
  }

  get complete(): boolean {
    return this.restored;
  }

  restoreSynchronously(): RawEvent[] {
    const restored = this.options.overlayPersistence.read();
    const restoredJournal = this.options.outboxJournal.restore(
      this.legacyPendingEvents(restored),
    );
    return this.commit(restored, restoredJournal);
  }

  async restoreAfterPaint(canCommit: () => boolean): Promise<RawEvent[]> {
    if (this.restored) {
      return [];
    }
    if (this.pending) {
      await this.pending;
      return !this.restored && canCommit()
        ? await this.restoreAfterPaint(canCommit)
        : [];
    }

    const controller = new AbortController();
    this.abortController = controller;
    const restore = (async () => {
      try {
        await waitUntilAfterApplicationPaint();
        throwIfProfileLoadAborted(controller.signal);
        const restored = await this.options.overlayPersistence.readAsync({
          signal: controller.signal,
        });
        throwIfProfileLoadAborted(controller.signal);
        const restoredJournal = await this.options.outboxJournal.restoreAsync(
          this.legacyPendingEvents(restored),
          { signal: controller.signal },
        );
        throwIfProfileLoadAborted(controller.signal);
        return canCommit() ? this.commit(restored, restoredJournal) : [];
      } catch (error) {
        if (controller.signal.aborted) {
          return [];
        }
        throw error;
      }
    })();
    const pending = restore.finally(() => {
      if (this.pending === pending) {
        this.pending = null;
      }
      if (this.abortController === controller) {
        this.abortController = null;
      }
    });
    this.pending = pending;
    return await pending;
  }

  cancel(): void {
    this.abortController?.abort();
  }

  private legacyPendingEvents(
    restored: RestoredSocialDataPlaneState | null,
  ): RawEvent[] {
    const restoredEvents = restored?.repositoryState.overlayEvents ?? [];
    const restoredEventsById = new Map(restoredEvents.map((event) => [event.id, event]));
    return (restored?.pendingDeliveryEventIds ?? [])
      .map((eventId) => restoredEventsById.get(eventId) ?? null)
      .filter((event): event is RawEvent => Boolean(event));
  }

  private commit(
    restored: RestoredSocialDataPlaneState | null,
    restoredJournal: RestoredSocialOutboxJournal,
  ): RawEvent[] {
    if (this.restored) {
      return [];
    }
    const restoredEvents = restored?.repositoryState.overlayEvents ?? [];
    const restoredEventsById = new Map(restoredEvents.map((event) => [event.id, event]));
    for (const entry of restoredJournal.entries.values()) {
      this.options.applyJournalObligations(entry);
    }
    if (!restoredJournal.migrated) {
      for (const eventId of restored?.pendingDeliveryEventIds ?? []) {
        const event = restoredEventsById.get(eventId);
        if (event) {
          this.options.applyJournalObligations({
            event,
            obligations: { relay: true, personalIndex: false },
          });
        }
      }
    }

    const mergedEvents = new Map(restoredEvents.map((event) => [event.id, event]));
    for (const { event } of restoredJournal.entries.values()) {
      mergedEvents.set(event.id, event);
    }
    const newlyRestoredEvents = [...mergedEvents.values()]
      .filter((event) => this.options.repository.getStoredEvent(event.id) === null);
    this.options.repository.ingestOverlay(mergedEvents.values());
    this.restored = true;
    if (this.options.enforceOverlayBound()) {
      this.options.overlayPersistence.persistBestEffort();
    }
    const retainedIds = new Set(
      this.options.repository.getOverlayEvents().map((event) => event.id),
    );
    return newlyRestoredEvents.filter((event) => retainedIds.has(event.id));
  }
}
