import type { CID } from '@hashtree/core';
import { createAppAccountActions } from './appAccountActions';
import { createAppLiveHomeController } from './appLiveHomeController';
import { createNoteInteractions } from './appNoteInteractions';
import { createAppProfileActions } from './appProfileActions';
import { createAppPublishingActions } from './appPublishingActions';
import { createAppSearchActions } from './appSearchActions';
import type { AppCombinedState } from './appState';
import { createAppZapActions } from './appZapActions';
import { publishEvent } from './nostrPublish';
import type { ProfileRecord, RawEvent } from './nostr';
import type { ProfileSocialSnapshot } from './nostrIndex';
import { createReactiveDeps } from './reactiveState';
import { socialDataPlane } from './socialDataPlane';
import type { createThreadReplyDraftStore } from './threadReplyDrafts';

type UserActionDeps = {
  state: AppCombinedState;
  pendingLiveViewEvents: Map<string, RawEvent>;
  threadReplyDrafts: ReturnType<typeof createThreadReplyDraftStore>;
  activeThreadReplyDraftKey: () => string | null;
  applyProfileSocialSnapshot: (social: ProfileSocialSnapshot | null) => void;
  applyViewerFollows: (follows: Set<string>) => void;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  cancelProfileSearchDebounce: () => void;
  cancelRemoteSearch: () => void;
  clearOptimisticLike: (noteId: string) => void;
  clearThreadReplyDraft: () => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  getProfileEditorBlockedReason: () => string;
  hydrateAccountProfiles: (root: CID) => Promise<void>;
  loadSearchPage: () => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  navigateHome: () => void;
  navigateProfile: (pubkey: string) => void;
  navigateThread: (target: string) => void;
  navigateToHref: (href: string) => void;
  noteHasMedia: (event: RawEvent) => boolean;
  persistActiveThreadReplyDraft: () => void;
  prependLocalPost: (event: RawEvent) => void;
  prependThreadReply: (event: RawEvent) => void;
  projectContactsEvent: (event: RawEvent | null, pubkey: string) => RawEvent | null;
  pruneTombstonedLocalPosts: () => void;
  reportError: (fallback: string, error: unknown) => string;
  resetActiveAccountUiState: (nextViewerPubkey?: string | null) => void;
  resolveProfile: (pubkey: string) => ProfileRecord | null;
  restartCurrentViewLoad: () => void;
  scheduleRemoteSearch: (query: string) => void;
  scrollPageToTopInstant: () => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
  setOptimisticLike: (noteId: string) => void;
};

export function createAppUserActionControllers(deps: UserActionDeps) {
  const { state } = deps;
  const noteInteractions = createNoteInteractions({
    getRoot: () => state.root,
    getRoute: () => state.route,
    getProfilePersonalRoot: () => state.profilePersonalRoot,
    getThreadPersonalRoot: () => state.threadPersonalRoot,
    getAccountProfiles: () => state.accountProfiles,
    getCachedDetailEvents: (targetId) => socialDataPlane.query({
      kinds: [6, 7, 16, 9_735],
      tags: { e: [targetId] },
    }),
    mergeCachedProfiles: deps.mergeCachedProfiles,
    getDetailSheetRequestId: () => state.detailSheetRequestId,
    incrementDetailSheetRequestId: () => ++state.detailSheetRequestId,
    setDetailSheetOpen: (open) => {
      state.detailSheetOpen = open;
    },
    setDetailSheetLoading: (loading) => {
      state.detailSheetLoading = loading;
    },
    setDetailSheetKind: (kind) => {
      state.detailSheetKind = kind;
    },
    setDetailSheetTitle: (title) => {
      state.detailSheetTitle = title;
    },
    setDetailSheetTargetPubkey: (pubkey) => {
      state.detailSheetTargetPubkey = pubkey;
    },
    setDetailSheetEventsByKind: (events) => {
      state.detailSheetEventsByKind = events;
    },
    setDetailSheetHasMoreByKind: (hasMore) => {
      state.detailSheetHasMoreByKind = hasMore;
    },
    setDetailSheetProfiles: (profiles) => {
      state.detailSheetProfiles = profiles;
    },
    clearPageError: () => {
      state.pageError = '';
    },
    setPageError: (message) => {
      state.pageError = message;
    },
    reportError: deps.reportError,
    getRebroadcastPendingNoteIds: () => state.rebroadcastPendingNoteIds,
    setRebroadcastPendingNoteIds: (ids) => {
      state.rebroadcastPendingNoteIds = ids;
    },
    publishEvent,
  });

  const liveHome = createAppLiveHomeController({
    state,
    pendingLiveViewEvents: deps.pendingLiveViewEvents,
    applyProfileSocialSnapshot: deps.applyProfileSocialSnapshot,
    applyViewerFollows: deps.applyViewerFollows,
    cacheKnownNotes: deps.cacheKnownNotes,
    getKnownNoteByRef: deps.getKnownNoteByRef,
    noteHasMedia: deps.noteHasMedia,
    projectContactsEvent: deps.projectContactsEvent,
    pruneTombstonedLocalPosts: deps.pruneTombstonedLocalPosts,
    restartCurrentViewLoad: deps.restartCurrentViewLoad,
    scrollPageToTopInstant: deps.scrollPageToTopInstant,
    seedNewEmptyEngagements: deps.seedNewEmptyEngagements,
  });

  const publishing = createAppPublishingActions(createReactiveDeps(state, {
    threadReplyDrafts: deps.threadReplyDrafts,
    activeThreadReplyDraftKey: deps.activeThreadReplyDraftKey,
    clearOptimisticLike: deps.clearOptimisticLike,
    clearThreadReplyDraft: deps.clearThreadReplyDraft,
    navigateHome: deps.navigateHome,
    navigateThread: deps.navigateThread,
    persistActiveThreadReplyDraft: deps.persistActiveThreadReplyDraft,
    prependLocalPost: deps.prependLocalPost,
    prependThreadReply: deps.prependThreadReply,
    pruneTombstonedLocalPosts: deps.pruneTombstonedLocalPosts,
    reportError: deps.reportError,
    setOptimisticLike: deps.setOptimisticLike,
  }));

  const zaps = createAppZapActions(createReactiveDeps(state, {
    reportError: deps.reportError,
    resolveProfile: deps.resolveProfile,
  }));

  const profiles = createAppProfileActions(createReactiveDeps(state, {
    get profileEditorBlockedReason() {
      return deps.getProfileEditorBlockedReason();
    },
    copyText: (value: string, fallbackMessage: string) => (
      noteInteractions.copyText(value, fallbackMessage)
    ),
    mergeCachedProfiles: deps.mergeCachedProfiles,
    reportError: deps.reportError,
    resetLiveHomeFeedBuffer: liveHome.resetLiveHomeFeedBuffer,
  }));

  const accounts = createAppAccountActions(createReactiveDeps(state, {
    hydrateAccountProfiles: deps.hydrateAccountProfiles,
    navigateHome: deps.navigateHome,
    resetActiveAccountUiState: deps.resetActiveAccountUiState,
    restartCurrentViewLoad: deps.restartCurrentViewLoad,
  }));

  const search = createAppSearchActions(createReactiveDeps(state, {
    loadSearchPage: deps.loadSearchPage,
    cacheKnownNotes: deps.cacheKnownNotes,
    cancelProfileSearchDebounce: deps.cancelProfileSearchDebounce,
    cancelRemoteSearch: deps.cancelRemoteSearch,
    navigateProfile: deps.navigateProfile,
    navigateThread: deps.navigateThread,
    navigateToHref: deps.navigateToHref,
    scheduleRemoteSearch: deps.scheduleRemoteSearch,
  }));

  return {
    ...liveHome,
    ...publishing,
    ...zaps,
    ...profiles,
    ...accounts,
    ...search,
    noteInteractions,
  };
}
