import { getPublicKey } from 'nostr-tools/pure';
import { writable } from 'svelte/store';
import { parseBolt11Millisats, parseBolt11PaymentHash } from './bolt11';
import { NostrWalletConnect, parseNwcConnection } from './nostrWalletConnect';
import { WalletPaymentError } from './walletTypes';
import { claimNwcPayment, readNwcConnection, recordNwcPayment, removeNwcConnection, saveNwcConnection } from './nwcStorage';

type NwcWalletState = { loaded: boolean; name: string | null; enabled: boolean; connectionId: string | null; error: string | null };
export const nwcWallet = writable<NwcWalletState>({ loaded: false, name: null, enabled: false, connectionId: null, error: null }, () => {
  void reloadNwcWallet().catch(() => nwcWallet.set({ loaded: true, name: null, enabled: false, connectionId: null, error: 'Could not read the payment wallet. Reload before paying.' }));
});

export async function reloadNwcWallet(): Promise<void> {
  const saved = await readNwcConnection();
  const connection = saved ? parseNwcConnection(saved.uri) : null;
  nwcWallet.set({ loaded: true, name: saved?.name ?? null, enabled: saved?.enabled === true,
    connectionId: connection ? `${connection.walletPubkey}:${getPublicKey(connection.secret)}` : null, error: null,
  });
  connection?.secret.fill(0);
}
export async function connectNwcWallet(uri: string, name: string): Promise<void> {
  const wallet = new NostrWalletConnect(parseNwcConnection(uri));
  try {
    await wallet.connect();
    await saveNwcConnection({ uri: uri.trim(), name: name.trim().slice(0, 80) || 'Lightning wallet', enabled: true });
    await reloadNwcWallet();
  } finally {wallet.close();}
}
export async function setNwcWalletEnabled(enabled: boolean): Promise<void> {
  const saved = await readNwcConnection();
  if (!saved) {throw new Error('Connect a wallet first.');}
  await saveNwcConnection({ ...saved, enabled });
  await reloadNwcWallet();
}
export async function disconnectNwcWallet(): Promise<void> {
  await removeNwcConnection();
  await reloadNwcWallet();
}
export async function revealNwcWallet(): Promise<string> {
  return (await readNwcConnection())?.uri ?? '';
}

/** A payment is never queued, automatically retried, or handed to another wallet. */
export async function payWithConnectedNwc(invoice: string, expectedBits?: number, expectedConnectionId?: string): Promise<boolean> {
  const saved = await readNwcConnection();
  if (!saved?.enabled) {return false;}
  const millisats = parseBolt11Millisats(invoice);
  const paymentHash = parseBolt11PaymentHash(invoice);
  if (!paymentHash || millisats === null || (expectedBits !== undefined && millisats !== expectedBits * 1_000)) {
    throw new Error('The Lightning invoice has an invalid or unexpected amount.');
  }
  const connection = parseNwcConnection(saved.uri);
  if (expectedConnectionId && expectedConnectionId !== `${connection.walletPubkey}:${getPublicKey(connection.secret)}`) {
    connection.secret.fill(0);
    throw new Error('Wallet connection changed. Review the payment again.');
  }
  const paymentKey = `${connection.walletPubkey}:${paymentHash}`;
  const wallet = new NostrWalletConnect(connection);
  try {
    const result = await wallet.request('pay_invoice', { invoice }, async () => {
      const current = await readNwcConnection();
      if (!current?.enabled || current.uri !== saved.uri) {
        throw new Error('Wallet connection changed. Review the payment again.');
      }
      await claimNwcPayment(paymentKey);
    });
    await confirmNwcPayment(result, paymentHash, () => recordNwcPayment(paymentKey));
    return true;
  } finally {wallet.close();}
}

/** Keep all post-send failures marked uncertain; confirmed payments survive bookkeeping errors. */
export async function confirmNwcPayment(
  result: Record<string, unknown>, paymentHash: string, recordPaid: () => Promise<void>,
  digest: (value: Uint8Array<ArrayBuffer>) => Promise<ArrayBuffer> = (value) => crypto.subtle.digest('SHA-256', value),
): Promise<void> {
  try {
    if (typeof result.preimage !== 'string' || !/^[0-9a-fA-F]{64}$/.test(result.preimage)) {
      throw new Error('Wallet response did not prove payment. Check your wallet before continuing.');
    }
    const preimage = Uint8Array.from(result.preimage.match(/.{2}/g)!, (value) => parseInt(value, 16));
    const hash = new Uint8Array(await digest(preimage));
    if ([...hash].map((byte) => byte.toString(16).padStart(2, '0')).join('') !== paymentHash) {
      throw new Error('Wallet payment proof did not match this invoice. Check your wallet before continuing.');
    }
  } catch (error) {
    throw new WalletPaymentError(error instanceof Error ? error.message : 'Could not verify payment. Check your wallet before continuing.', true);
  }
  try {await recordPaid();} catch {
    // The durable pre-send claim still prevents duplicates. Bookkeeping cannot
    // undo an invoice payment already proven by the matching preimage.
  }
}
