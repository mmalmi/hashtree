import type { RawEvent } from './nostr';

export type VisibleQueryIndexes = {
  byAuthor: Map<string, RawEvent[]>;
  byKind: Map<number, RawEvent[]>;
};

/** Index the canonical visible winners, without retaining another event copy. */
export function buildVisibleQueryIndexes(events: Iterable<RawEvent>): VisibleQueryIndexes {
  const byAuthor = new Map<string, RawEvent[]>();
  const byKind = new Map<number, RawEvent[]>();
  for (const event of events) {
    const author = event.pubkey.toLowerCase();
    const authorEvents = byAuthor.get(author) ?? [];
    authorEvents.push(event);
    byAuthor.set(author, authorEvents);
    const kindEvents = byKind.get(event.kind) ?? [];
    kindEvents.push(event);
    byKind.set(event.kind, kindEvents);
  }
  return { byAuthor, byKind };
}
