import {
  decodeNostrEventReference,
  getThreadParentReference,
  isHexPubkey,
  type RawEvent,
} from './nostr';

export type ReplyParentAuthor = {
  /** The parent's author, or null when the tags do not name one. */
  pubkey: string | null;
  /** True when a tag names the parent's author directly. */
  certain: boolean;
};

function hexPubkey(value: string | undefined): string | null {
  const trimmed = value?.trim() ?? '';
  return isHexPubkey(trimmed) ? trimmed.toLowerCase() : null;
}

function parentAuthorFromTags(event: RawEvent, parentRef: string): string | null {
  if (event.kind === 1_111) {
    // NIP-22: lowercase `p` names the parent author; `e` may carry it at [3].
    const parentPubkey = hexPubkey(event.tags.find((tag) => tag[0] === 'p')?.[1]);
    if (parentPubkey) {
      return parentPubkey;
    }
    const eTag = event.tags.find((tag) => tag[0] === 'e' && tag[1]?.trim().toLowerCase() === parentRef);
    const hinted = hexPubkey(eTag?.[3]);
    if (hinted) {
      return hinted;
    }
  } else {
    // NIP-10 marked `e` tags may carry the referenced author at [4].
    const eTag = event.tags.find((tag) => tag[0] === 'e' && tag[1]?.trim().toLowerCase() === parentRef);
    const hinted = hexPubkey(eTag?.[4]);
    if (hinted) {
      return hinted;
    }
  }

  const decoded = decodeNostrEventReference(parentRef);
  if (decoded?.type === 'naddr') {
    return hexPubkey(decoded.pubkey);
  }
  if (decoded?.type === 'nevent' && decoded.author) {
    return hexPubkey(decoded.author);
  }
  return null;
}

/**
 * The author of a reply's immediate parent, read from the reply's own tags.
 * Clients list the replied-to author first among `p` tags, so the first `p`
 * that is not the reply's author is the fallback when no tag names it.
 */
export function getReplyParentAuthor(event: RawEvent): ReplyParentAuthor {
  const parentRef = getThreadParentReference(event)?.toLowerCase() ?? null;
  if (!parentRef) {
    return { pubkey: null, certain: false };
  }

  const named = parentAuthorFromTags(event, parentRef);
  if (named) {
    return { pubkey: named, certain: true };
  }

  const pTags = [...new Set(event.tags
    .filter((tag) => tag[0] === 'p')
    .map((tag) => hexPubkey(tag[1]))
    .filter((pubkey): pubkey is string => Boolean(pubkey)))];
  const author = event.pubkey.toLowerCase();
  const others = pTags.filter((pubkey) => pubkey !== author);
  if (others.length > 0) {
    return { pubkey: others[0]!, certain: false };
  }
  return { pubkey: pTags[0] ?? null, certain: false };
}
