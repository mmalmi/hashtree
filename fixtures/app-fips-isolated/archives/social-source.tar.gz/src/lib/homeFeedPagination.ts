import type { CID } from '@hashtree/core';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';

export type HomeFeedMode = 'latest' | 'for-you';

export type HomeFeedRootCursor = {
  cursor: RecentTextNoteCursor | null;
  exhausted: boolean;
  root: CID;
};

export type HomeFeedContinuation = {
  authors: string[];
  chronologicalPool: RawEvent[];
  discoveryPool: RawEvent[];
  includeReplies: boolean;
  mode: HomeFeedMode;
  nextLane: 'chronological' | 'discovery';
  roots: HomeFeedRootCursor[];
};

export type HomeFeedPage = {
  continuation: HomeFeedContinuation;
  hasMore: boolean;
  notes: RawEvent[];
};

type FeedReader = {
  getRecentTextNotesByAuthors: (
    authors: string[],
    limit: number,
    options: {
      before?: RecentTextNoteCursor;
      includeReplies?: boolean;
    },
  ) => Promise<RawEvent[]>;
};

type InitialRootPage = {
  events: RawEvent[];
  exhausted?: boolean;
  root: CID;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

function orderLatestByAuthorRound(events: RawEvent[]): RawEvent[] {
  const nextRoundByAuthor = new Map<string, number>();
  return events
    .map((event) => {
      const round = nextRoundByAuthor.get(event.pubkey) ?? 0;
      nextRoundByAuthor.set(event.pubkey, round + 1);
      return { event, round };
    })
    .sort((left, right) => (
      left.round - right.round || compareNewest(left.event, right.event)
    ))
    .map(({ event }) => event);
}

export function mergeUniqueFeedNotes(...eventLists: RawEvent[][]): RawEvent[] {
  const byIdentity = new Map<string, RawEvent>();
  for (const event of eventLists.flat()) {
    const identity = getAddressableEventCoordinate(event) ?? event.id;
    const previous = byIdentity.get(identity);
    if (!previous || compareNewest(event, previous) < 0) {
      byIdentity.set(identity, event);
    }
  }
  return [...byIdentity.values()].sort(compareNewest);
}

function cursorForLast(events: RawEvent[]): RecentTextNoteCursor | null {
  const boundary = events.at(-1);
  return boundary
    ? { createdAt: boundary.created_at, eventId: boundary.id }
    : null;
}

export function buildInitialHomeFeedPage(options: {
  authors: string[];
  includeReplies: boolean;
  limit: number;
  mode: HomeFeedMode;
  rootPages: InitialRootPage[];
}): HomeFeedPage {
  const limit = Math.max(0, options.limit);
  const decoded = mergeUniqueFeedNotes(...options.rootPages.map((page) => page.events));
  const ordered = options.mode === 'latest'
    ? orderLatestByAuthorRound(decoded)
    : decoded;
  const notes = ordered.slice(0, limit);
  const continuation: HomeFeedContinuation = {
    authors: [...new Set(options.authors)],
    chronologicalPool: ordered.slice(limit),
    discoveryPool: [],
    includeReplies: options.includeReplies,
    mode: options.mode,
    nextLane: 'chronological',
    roots: options.rootPages.map(({ events, exhausted, root }) => ({
      cursor: cursorForLast(events),
      exhausted: exhausted ?? events.length < limit,
      root,
    })),
  };
  return {
    continuation,
    hasMore: hasMoreHomeFeedContinuation(continuation, new Set(notes.map((event) => event.id))),
    notes,
  };
}

export function cloneHomeFeedContinuation(
  continuation: HomeFeedContinuation | null | undefined,
): HomeFeedContinuation | null {
  if (!continuation) {
    return null;
  }
  return {
    ...continuation,
    authors: [...continuation.authors],
    chronologicalPool: [...continuation.chronologicalPool],
    discoveryPool: [...continuation.discoveryPool],
    roots: continuation.roots.map((entry) => ({
      ...entry,
      cursor: entry.cursor ? { ...entry.cursor } : null,
    })),
  };
}

export function getHomeFeedContinuationRootIdentity(
  continuation: HomeFeedContinuation,
  getRootIdentity: (root: CID) => string,
): string {
  return continuation.roots.map((entry) => getRootIdentity(entry.root)).join('|');
}

function isUnseen(
  event: RawEvent,
  seenIds: ReadonlySet<string>,
  seenAddresses: ReadonlySet<string>,
): boolean {
  const address = getAddressableEventCoordinate(event);
  return !seenIds.has(event.id) && (!address || !seenAddresses.has(address));
}

function filterUnseen(
  events: RawEvent[],
  seenIds: ReadonlySet<string>,
  seenAddresses: ReadonlySet<string>,
): RawEvent[] {
  return events.filter((event) => isUnseen(event, seenIds, seenAddresses));
}

export function mixHomeFeedPage(options: {
  chronological: RawEvent[];
  discovery: RawEvent[];
  limit: number;
  mode: HomeFeedMode;
  nextLane?: HomeFeedContinuation['nextLane'];
  previousAuthor?: string | null;
  seenAddresses?: Set<string>;
  seenIds?: Set<string>;
}): {
  chronologicalPool: RawEvent[];
  discoveryPool: RawEvent[];
  nextLane: HomeFeedContinuation['nextLane'];
  notes: RawEvent[];
} {
  const seenIds = new Set(options.seenIds ?? []);
  const seenAddresses = new Set(options.seenAddresses ?? []);
  const chronological = filterUnseen(
    mergeUniqueFeedNotes(options.chronological),
    seenIds,
    seenAddresses,
  );
  const discovery = filterUnseen(options.discovery, seenIds, seenAddresses);
  if (options.mode === 'latest') {
    const authorDiverse = orderLatestByAuthorRound(chronological);
    const notes = authorDiverse.slice(0, Math.max(options.limit, 0));
    return {
      chronologicalPool: authorDiverse.slice(notes.length),
      discoveryPool: discovery,
      nextLane: 'chronological',
      notes,
    };
  }

  const chronologicalPool = [...chronological];
  const discoveryPool = [...discovery];
  let nextLane = options.nextLane ?? 'chronological';
  const notes: RawEvent[] = [];
  // Count identities once even when the same recommendation is in both lanes.
  const remainingAuthors = new Map<string, number>();
  let remainingCount = 0;
  for (const event of mergeUniqueFeedNotes(chronological, discovery)) {
    remainingAuthors.set(event.pubkey, (remainingAuthors.get(event.pubkey) ?? 0) + 1);
    remainingCount += 1;
  }
  const takeNext = (
    lane: HomeFeedContinuation['nextLane'],
    avoidAuthor: string | null,
    requiredAuthor?: string,
  ): boolean => {
    const source = lane === 'chronological' ? chronologicalPool : discoveryPool;
    for (let index = source.length - 1; index >= 0; index -= 1) {
      if (!isUnseen(source[index]!, seenIds, seenAddresses)) {
        source.splice(index, 1);
      }
    }
    const index = source.findIndex((candidate) => (
      (avoidAuthor === null || candidate.pubkey !== avoidAuthor)
      && (!requiredAuthor || candidate.pubkey === requiredAuthor)
    ));
    const event = index >= 0 ? source.splice(index, 1)[0] : undefined;
    if (!event) {
      return false;
    }
    seenIds.add(event.id);
    const address = getAddressableEventCoordinate(event);
    if (address) {
      seenAddresses.add(address);
    }
    notes.push(event);
    remainingAuthors.set(event.pubkey, remainingAuthors.get(event.pubkey)! - 1);
    remainingCount -= 1;
    nextLane = lane === 'chronological' ? 'discovery' : 'chronological';
    return true;
  };

  while (notes.length < Math.max(options.limit, 0)) {
    const avoidAuthor = notes.at(-1)?.pubkey ?? options.previousAuthor ?? null;
    const alternate = nextLane === 'chronological' ? 'discovery' : 'chronological';
    // Keep enough other authors in reserve to separate a majority author's
    // remaining posts, rather than stranding a run at the end of the page.
    const urgentAuthor = [...remainingAuthors].find(([author, count]) => (
      author !== avoidAuthor && count > remainingCount / 2
    ))?.[0];
    if (urgentAuthor && (
      takeNext(nextLane, avoidAuthor, urgentAuthor)
      || takeNext(alternate, avoidAuthor, urgentAuthor)
    )) {
      continue;
    }
    if (takeNext(nextLane, avoidAuthor)) {
      continue;
    }
    if (takeNext(alternate, avoidAuthor)) {
      continue;
    }
    if (takeNext(nextLane, null)) {
      continue;
    }
    if (takeNext(alternate, null)) {
      continue;
    }
    break;
  }

  return {
    chronologicalPool,
    discoveryPool,
    nextLane,
    notes,
  };
}

export function hasMoreHomeFeedContinuation(
  continuation: HomeFeedContinuation | null,
  seenIds: Set<string> = new Set(),
  seenAddresses: Set<string> = new Set(),
): boolean {
  if (!continuation) {
    return false;
  }
  return continuation.chronologicalPool.some((event) => isUnseen(event, seenIds, seenAddresses))
    || continuation.discoveryPool.some((event) => isUnseen(event, seenIds, seenAddresses))
    || continuation.roots.some((entry) => !entry.exhausted);
}

export async function loadNextHomeFeedPage(options: {
  continuation: HomeFeedContinuation;
  getReaderForRoot: (root: CID) => FeedReader;
  loadRecentTextNotesByAuthors?: (
    roots: CID[],
    authors: string[],
    limit: number,
    options: {
      before?: RecentTextNoteCursor;
      includeReplies?: boolean;
    },
  ) => Promise<RawEvent[]>;
  limit: number;
  seenAddresses?: Set<string>;
  seenIds: Set<string>;
}): Promise<HomeFeedPage> {
  const continuation = cloneHomeFeedContinuation(options.continuation)!;
  const pageSize = Math.max(0, options.limit);
  if (pageSize === 0) {
    return {
      continuation,
      hasMore: hasMoreHomeFeedContinuation(
        continuation,
        options.seenIds,
        options.seenAddresses,
      ),
      notes: [],
    };
  }

  const seenAddresses = options.seenAddresses ?? new Set<string>();
  let chronological = filterUnseen(
    continuation.chronologicalPool,
    options.seenIds,
    seenAddresses,
  );
  const desiredChronological = continuation.mode === 'for-you'
    && continuation.discoveryPool.some((event) => (
      isUnseen(event, options.seenIds, seenAddresses)
    ))
    ? Math.ceil(pageSize / 2)
    : pageSize;
  if (
    chronological.length < desiredChronological
    && continuation.roots.some((entry) => !entry.exhausted)
  ) {
    const queryLimit = Math.max(1, desiredChronological - chronological.length);
    const rootPages = await Promise.all(continuation.roots.map(async (entry) => {
      if (entry.exhausted) {
        return [] as RawEvent[];
      }
      const queryOptions = {
        before: entry.cursor ?? undefined,
        includeReplies: continuation.includeReplies,
      };
      const notes = options.loadRecentTextNotesByAuthors
        ? await options.loadRecentTextNotesByAuthors(
            [entry.root],
            continuation.authors,
            queryLimit,
            queryOptions,
          )
        : await options.getReaderForRoot(entry.root).getRecentTextNotesByAuthors(
            continuation.authors,
            queryLimit,
            queryOptions,
          );
      entry.cursor = cursorForLast(notes) ?? entry.cursor;
      entry.exhausted = notes.length < queryLimit;
      return notes;
    }));
    chronological = mergeUniqueFeedNotes(chronological, ...rootPages);
  }

  const mixed = mixHomeFeedPage({
    chronological,
    discovery: continuation.discoveryPool,
    limit: pageSize,
    mode: continuation.mode,
    nextLane: continuation.nextLane,
    seenAddresses,
    seenIds: options.seenIds,
  });
  continuation.chronologicalPool = mixed.chronologicalPool;
  continuation.discoveryPool = mixed.discoveryPool;
  continuation.nextLane = mixed.nextLane;
  return {
    continuation,
    hasMore: hasMoreHomeFeedContinuation(
      continuation,
      new Set([...options.seenIds, ...mixed.notes.map((event) => event.id)]),
      new Set([
        ...seenAddresses,
        ...mixed.notes
          .map((event) => getAddressableEventCoordinate(event))
          .filter((address): address is string => Boolean(address)),
      ]),
    ),
    notes: mixed.notes,
  };
}

/** Keep admitted painted identities in place; diversify only the unpainted tail. */
export function retainHomeFeedOrder(
  candidates: RawEvent[],
  retainedIds: readonly string[],
  mode: HomeFeedMode,
): RawEvent[] {
  const byId = new Map(candidates.map(event => [event.id, event]));
  const retained = retainedIds.flatMap(id => {
    const event = byId.get(id);
    byId.delete(id);
    return event ? [event] : [];
  });
  return [...retained, ...mixHomeFeedPage({
    chronological: [...byId.values()], discovery: [], limit: byId.size, mode,
    previousAuthor: retained.at(-1)?.pubkey,
  }).notes];
}
