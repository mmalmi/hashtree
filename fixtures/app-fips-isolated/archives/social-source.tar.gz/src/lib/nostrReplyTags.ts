/** NIP-10 thread markers, including legacy unmarked positional references. */
export function isNip10ReplyTag(tag: readonly string[]): boolean {
  if (tag[0] !== 'e') { return false; }
  const marker = (tag[3] ?? '').trim().toLowerCase();
  // Explicit citations such as `mention` and `quote` do not create a reply.
  return marker === '' || marker === 'root' || marker === 'reply';
}
