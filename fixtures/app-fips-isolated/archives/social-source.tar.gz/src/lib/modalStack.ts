import { readonly, writable } from 'svelte/store';

let nextModalToken = 1;
const activeModalTokens: number[] = [];
const count = writable(0);
export const activeModalCount = readonly(count);

export function createModalToken(): number {
  return nextModalToken++;
}

export function activateModal(token: number): void {
  deactivateModal(token);
  activeModalTokens.push(token);
  count.set(activeModalTokens.length);
}

export function deactivateModal(token: number): void {
  const index = activeModalTokens.lastIndexOf(token);
  if (index >= 0) {
    activeModalTokens.splice(index, 1);
    count.set(activeModalTokens.length);
  }
}

export function isTopModal(token: number): boolean {
  return activeModalTokens[activeModalTokens.length - 1] === token;
}
