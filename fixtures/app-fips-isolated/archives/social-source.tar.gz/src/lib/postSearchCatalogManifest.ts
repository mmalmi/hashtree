import { nhashDecode, nhashEncode } from '@hashtree/core';
import { RANKED_SEARCH_SEGMENT_FORMAT } from '@hashtree/index';
import {
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_CATALOG_FORMAT_V1,
  POST_SEARCH_CATALOG_FORMAT_V2,
  POST_SEARCH_CATALOG_FORMAT_V3,
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_DOCUMENT_FORMAT,
  POST_SEARCH_KINDS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_MAX_CATALOG_SEGMENTS,
  POST_SEARCH_VISIBLE_PROJECTION,
} from './postSearchCatalogConstants';
import { POST_SEARCH_GLOBAL_SCORING_FORMAT } from './postSearchGlobalScoring';
import { POST_SEARCH_TERM_ROUTING_FORMAT } from './postSearchTermRouting';
import type {
  PostSearchCatalogManifest,
  PostSearchCoverage,
  PostSearchSegmentDescriptor,
  PostSearchSourceSnapshot,
  PostSearchTermRoutingDescriptor,
} from './postSearchCatalog';
import type { PostSearchGlobalScoringDescriptor } from './postSearchGlobalScoring';

export function parsePostSearchCatalogManifest(raw: string): PostSearchCatalogManifest {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Invalid post search catalog JSON');
  }
  if (!isObject(value)
    || (
      value.format !== POST_SEARCH_CATALOG_FORMAT
      && value.format !== POST_SEARCH_CATALOG_FORMAT_V3
      && value.format !== POST_SEARCH_CATALOG_FORMAT_V2
      && value.format !== POST_SEARCH_CATALOG_FORMAT_V1
    )) {
    throw new Error('Unsupported post search catalog format');
  }
  if (!isCompatibleCatalog(value.compatibility, value.format)) {
    throw new Error('Incompatible ranked post search catalog');
  }
  if (!Array.isArray(value.segments)) {
    throw new Error('Invalid post search catalog segments');
  }
  if (value.segments.length > POST_SEARCH_MAX_CATALOG_SEGMENTS) {
    throw new Error('Post search catalog exceeds the supported segment capacity');
  }
  const seenEntries = new Set<string>();
  const segments = value.segments.map((rawSegment, index) => {
    const segment = parseSegmentDescriptor(rawSegment, index);
    if (seenEntries.has(segment.entry)) {
      throw new Error(`Duplicate post search segment entry: ${segment.entry}`);
    }
    seenEntries.add(segment.entry);
    return segment;
  });
  const source = validateSourceSnapshot(value.source, segments);
  const hasRouting = value.format === POST_SEARCH_CATALOG_FORMAT
    || value.format === POST_SEARCH_CATALOG_FORMAT_V3;
  const routing = hasRouting ? parseTermRoutingDescriptor(value.routing) : null;
  const globalScoring = value.format === POST_SEARCH_CATALOG_FORMAT
    ? parseGlobalScoringDescriptor(value.globalScoring)
    : null;
  const hasV2Compatibility = value.format !== POST_SEARCH_CATALOG_FORMAT_V1;
  return {
    format: value.format,
    publisherId: validatePublisherId(value.publisherId),
    generatedAt: nonNegativeInteger(value.generatedAt, 'generatedAt'),
    source,
    compatibility: {
      documentFormat: POST_SEARCH_DOCUMENT_FORMAT,
      rankedSegmentFormat: RANKED_SEARCH_SEGMENT_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
      fields: POST_SEARCH_BUILD_OPTIONS.fields,
      maxTokensPerField: hasV2Compatibility ? POST_SEARCH_BUILD_OPTIONS.maxTokensPerField : null,
      authorTerms: hasV2Compatibility ? POST_SEARCH_AUTHOR_TERMS_PROJECTION : null,
      termRouting: hasRouting ? POST_SEARCH_TERM_ROUTING_FORMAT : null,
      globalScoring: value.format === POST_SEARCH_CATALOG_FORMAT
        ? POST_SEARCH_GLOBAL_SCORING_FORMAT
        : null,
    },
    routing,
    globalScoring,
    segments,
  };
}

export function validateSourceSnapshot(
  value: unknown,
  segments: readonly PostSearchSegmentDescriptor[],
): PostSearchSourceSnapshot {
  if (!isObject(value)) {
    throw new Error('Invalid post search source snapshot');
  }
  const coverage = parseCoverage(value.coverage, 'source coverage');
  const expected = coverageForSegments(segments);
  if (!sameCoverage(coverage, expected)) {
    throw new Error('Post search source coverage does not match its visible segments');
  }
  return {
    eventRoot: canonicalEventRoot(value.eventRoot),
    projection: validateProjection(value.projection),
    coverage,
  };
}

export function validateSegmentCoverage(segment: PostSearchSegmentDescriptor): void {
  validateCoverageShape({
    eventCount: segment.documentCount,
    kinds: segment.kinds,
    since: segment.since,
    until: segment.until,
  }, `segment ${segment.entry}`);
}

export function validateProjection(value: unknown): typeof POST_SEARCH_VISIBLE_PROJECTION {
  if (value !== POST_SEARCH_VISIBLE_PROJECTION) {
    throw new Error('Unsupported post search visible projection');
  }
  return POST_SEARCH_VISIBLE_PROJECTION;
}

export function validatePublisherId(value: unknown): string {
  if (typeof value !== 'string' || !value.trim() || value.length > 256) {
    throw new Error('Invalid post search publisher id');
  }
  return value.trim();
}

export function validateKinds(value: unknown): number[] {
  if (!Array.isArray(value)
    || !value.every((kind) => Number.isInteger(kind) && supportedKind(kind))) {
    throw new Error('Invalid post search catalog kinds');
  }
  return uniqueNumbers(value as number[]);
}

export function nullableTimestamp(value: unknown, name: string): number | null {
  return value === null ? null : nonNegativeInteger(value, name);
}

export function nonNegativeInteger(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}

export function uniqueNumbers(values: readonly number[]): number[] {
  return [...new Set(values)].sort((left, right) => left - right);
}

export function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function parseGlobalScoringDescriptor(value: unknown): PostSearchGlobalScoringDescriptor {
  if (!isObject(value)
    || value.format !== POST_SEARCH_GLOBAL_SCORING_FORMAT
    || value.entry !== 'global-scoring') {
    throw new Error('Invalid post search global scoring descriptor');
  }
  return { format: POST_SEARCH_GLOBAL_SCORING_FORMAT, entry: 'global-scoring' };
}

function parseTermRoutingDescriptor(value: unknown): PostSearchTermRoutingDescriptor {
  if (!isObject(value) || value.format !== POST_SEARCH_TERM_ROUTING_FORMAT) {
    throw new Error('Invalid post search term routing descriptor');
  }
  const mappingCount = nonNegativeInteger(value.mappingCount, 'routing mappingCount');
  const entry = value.entry;
  if (entry !== null && entry !== 'term-routing') {
    throw new Error('Invalid post search term routing entry');
  }
  if ((mappingCount === 0) !== (entry === null)) {
    throw new Error('Post search term routing coverage is inconsistent');
  }
  return { format: POST_SEARCH_TERM_ROUTING_FORMAT, entry, mappingCount };
}

function parseSegmentDescriptor(value: unknown, index: number): PostSearchSegmentDescriptor {
  if (!isObject(value)
    || typeof value.entry !== 'string'
    || !/^segment-[0-9]{6}$/.test(value.entry)) {
    throw new Error(`Invalid post search segment descriptor at ${index}`);
  }
  const since = nullableTimestamp(value.since, 'segment since');
  const until = nullableTimestamp(value.until, 'segment until');
  if (since !== null && until !== null && since > until) {
    throw new Error(`Post search segment ${value.entry} has an inverted time range`);
  }
  const segment: PostSearchSegmentDescriptor = {
    entry: value.entry,
    projection: validateProjection(value.projection),
    documentCount: nonNegativeInteger(value.documentCount, 'segment documentCount'),
    kinds: validateKinds(value.kinds),
    since,
    until,
  };
  validateSegmentCoverage(segment);
  return segment;
}

function parseCoverage(value: unknown, name: string): PostSearchCoverage {
  if (!isObject(value)) {
    throw new Error(`Invalid post search ${name}`);
  }
  const coverage = {
    eventCount: nonNegativeInteger(value.eventCount, `${name} eventCount`),
    kinds: validateKinds(value.kinds),
    since: nullableTimestamp(value.since, `${name} since`),
    until: nullableTimestamp(value.until, `${name} until`),
  };
  validateCoverageShape(coverage, name);
  return coverage;
}

function coverageForSegments(segments: readonly PostSearchSegmentDescriptor[]): PostSearchCoverage {
  const populated = segments.filter((segment) => segment.documentCount > 0);
  return {
    eventCount: segments.reduce((sum, segment) => sum + segment.documentCount, 0),
    kinds: uniqueNumbers(populated.flatMap((segment) => segment.kinds)),
    since: populated.length > 0
      ? Math.min(...populated.map((segment) => segment.since as number))
      : null,
    until: populated.length > 0
      ? Math.max(...populated.map((segment) => segment.until as number))
      : null,
  };
}

function validateCoverageShape(coverage: PostSearchCoverage, name: string): void {
  const empty = coverage.eventCount === 0;
  if (empty && (coverage.kinds.length > 0 || coverage.since !== null || coverage.until !== null)) {
    throw new Error(`Empty post search ${name} must have empty coverage`);
  }
  if (!empty && (coverage.kinds.length === 0 || coverage.since === null || coverage.until === null)) {
    throw new Error(`Populated post search ${name} must have complete coverage`);
  }
  if (coverage.since !== null && coverage.until !== null && coverage.since > coverage.until) {
    throw new Error(`Post search ${name} has an inverted time range`);
  }
}

function sameCoverage(left: PostSearchCoverage, right: PostSearchCoverage): boolean {
  return left.eventCount === right.eventCount
    && left.since === right.since
    && left.until === right.until
    && JSON.stringify(left.kinds) === JSON.stringify(right.kinds);
}

function canonicalEventRoot(value: unknown): string {
  if (typeof value !== 'string') {
    throw new Error('Invalid post search source event root');
  }
  try {
    const canonical = nhashEncode(nhashDecode(value));
    if (canonical !== value) {
      throw new Error('non-canonical');
    }
    return canonical;
  } catch {
    throw new Error('Invalid or non-canonical post search source event root');
  }
}

function isCompatibleCatalog(
  value: unknown,
  format:
    | typeof POST_SEARCH_CATALOG_FORMAT
    | typeof POST_SEARCH_CATALOG_FORMAT_V3
    | typeof POST_SEARCH_CATALOG_FORMAT_V2
    | typeof POST_SEARCH_CATALOG_FORMAT_V1,
): boolean {
  if (!isObject(value)) {
    return false;
  }
  const legacyCompatible = value.documentFormat === POST_SEARCH_DOCUMENT_FORMAT
    && value.rankedSegmentFormat === RANKED_SEARCH_SEGMENT_FORMAT
    && value.normalization === POST_SEARCH_NORMALIZATION
    && hasCompatibleFieldOptions(value.fields);
  if (!legacyCompatible) {
    return false;
  }
  if (format === POST_SEARCH_CATALOG_FORMAT_V1) {
    return true;
  }
  const v2Compatible = value.maxTokensPerField === POST_SEARCH_BUILD_OPTIONS.maxTokensPerField
    && value.authorTerms === POST_SEARCH_AUTHOR_TERMS_PROJECTION;
  return v2Compatible && (
    format === POST_SEARCH_CATALOG_FORMAT_V2
    || (
      value.termRouting === POST_SEARCH_TERM_ROUTING_FORMAT
      && (
        format === POST_SEARCH_CATALOG_FORMAT_V3
        || value.globalScoring === POST_SEARCH_GLOBAL_SCORING_FORMAT
      )
    )
  );
}

function hasCompatibleFieldOptions(value: unknown): boolean {
  if (!isObject(value)) {
    return false;
  }
  const expected = Object.entries(POST_SEARCH_BUILD_OPTIONS.fields);
  if (Object.keys(value).length !== expected.length) {
    return false;
  }
  return expected.every(([name, options]) => {
    const field = value[name];
    return isObject(field)
      && field.boost === options.boost
      && field.lengthNormalization === options.lengthNormalization;
  });
}

function supportedKind(value: number): boolean {
  return (POST_SEARCH_KINDS as readonly number[]).includes(value);
}
