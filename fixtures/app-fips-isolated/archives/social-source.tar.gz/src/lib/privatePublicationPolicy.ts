import { hasMetadataPrivacyVersion, isGroupRosterFactEvent } from 'nostr-double-ratchet';
import type { Event } from 'nostr-tools';

/** Retired private traffic stays local, including generic worker retry queues. */
export function assertPrivatePublicationPolicy(event: Event): void {
  const invite = event.kind === 30078 && event.tags.some(tag =>
    tag[0] === 'l' && tag[1] === 'double-ratchet/invites');
  if (([1059, 1060].includes(event.kind) || invite) && !hasMetadataPrivacyVersion(event)) {
    throw new Error('Old private ciphertext cannot be resent; start a new encrypted session.');
  }
  if ((event.kind === 1060 && !event.tags.some(tag => tag[0] === 'p')) || isGroupRosterFactEvent(event)) {
    throw new Error('Private groups must use encrypted device sessions.');
  }
  if (event.kind === 37368 && event.tags.some(tag => tag[0] === 'encrypted_device_labels'
    || (tag[0] === 'f' && tag[1] === 'encrypted_device_labels'))) {
    throw new Error('Private device names must remain local.');
  }
  if ([10449, 10450, 10451, 10452, 10453, 21111, 21112].includes(event.kind)
    || (event.kind === 30078 && event.tags.some(tag => tag[0] === 't' && tag[1] === 'nostr-social-memory/v1'))) {
    throw new Error('Private settings must use encrypted device sessions.');
  }
}
