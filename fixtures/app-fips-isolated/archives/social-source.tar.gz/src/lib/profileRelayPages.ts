import { DURABLE_PROFILE_POST_KINDS } from './nostrIndexTypes';
import type { ProfileNotesPage } from './profileNotes';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { createRelayHistoryPages } from './relayHistory';

const PROFILE_RELAY_PAGE = 100;

/** Profile post history from relays, one worker history session per profile. */
export function createProfileRelayPages(
  createReader?: Parameters<typeof createRelayHistoryPages>[1],
) {
  const pages = createRelayHistoryPages((pubkey) => ({
    authors: [pubkey], kinds: [...DURABLE_PROFILE_POST_KINDS], limit: PROFILE_RELAY_PAGE,
  }), createReader);
  return {
    async load(
      pubkey: string,
      limit: number,
      before: RecentTextNoteCursor | null,
      signal?: AbortSignal,
    ): Promise<ProfileNotesPage> {
      const page = await pages.load(pubkey, limit, before, signal);
      return { notes: page.events, cursor: page.cursor, hasMore: page.hasMore };
    },
    close: pages.close,
  };
}
