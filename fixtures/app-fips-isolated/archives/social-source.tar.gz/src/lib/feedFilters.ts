import { writable } from 'svelte/store';
import { getNotePresentation } from './noteContent';
import { isReplyEvent, type RawEvent } from './nostr';
import { getKind6RepostTargetEventId, getVerifiedEmbeddedRepostTarget } from './repostPresentation';
import type { HomeTab } from './routes';

export type FeedFilters = {
  showReplies: boolean;
  showReposts: boolean;
  showRepliedTo: boolean;
  mediaOnly: boolean;
  postType: 'all' | 'posts' | 'articles';
};

const DEFAULT_FILTERS: FeedFilters = {
  showReplies: true,
  showReposts: true,
  showRepliedTo: true,
  mediaOnly: false,
  postType: 'all',
};
const STORAGE_KEY = 'iris-social:feed-filters:v1';

function normalizeFilters(value: unknown): FeedFilters {
  const input = value && typeof value === 'object' ? value as Partial<FeedFilters> : {};
  return {
    showReplies: input.showReplies !== false,
    showReposts: input.showReposts !== false,
    showRepliedTo: input.showRepliedTo !== false,
    mediaOnly: input.mediaOnly === true,
    postType: input.postType === 'posts' || input.postType === 'articles' ? input.postType : 'all',
  };
}

function readFilters(): Map<string, FeedFilters> {
  try {
    const saved: unknown = JSON.parse(globalThis.localStorage?.getItem(STORAGE_KEY) ?? '[]');
    if (!Array.isArray(saved)) { return new Map(); }
    return new Map(saved.slice(-180).flatMap((entry) => (
      Array.isArray(entry) && typeof entry[0] === 'string'
        ? [[entry[0], normalizeFilters(entry[1])] as const]
        : []
    )));
  } catch { return new Map(); }
}

export const feedFiltersStore = writable(readFilters());

export function feedFilterScope(viewerPubkey: string | null, sourceId: string | null, tab: HomeTab): string | null {
  return viewerPubkey ? `${viewerPubkey}:${sourceId ?? 'following'}:${tab}` : null;
}

export function readFeedFilters(filters: Map<string, FeedFilters>, scope: string | null): FeedFilters {
  return scope ? filters.get(scope) ?? DEFAULT_FILTERS : DEFAULT_FILTERS;
}

export function updateFeedFilters(scope: string | null, patch: Partial<FeedFilters> | null): void {
  if (!scope) { return; }
  feedFiltersStore.update((current) => {
    const next = new Map(current);
    next.delete(scope);
    if (patch) { next.set(scope, normalizeFilters({ ...readFeedFilters(current, scope), ...patch })); }
    while (next.size > 180) { next.delete(next.keys().next().value!); }
    try { globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify([...next])); } catch { /* Retain session settings when storage is full. */ }
    return next;
  });
}

export function needsRepostFilterTargets(filters: FeedFilters): boolean {
  return filters.showReposts && (!filters.showReplies || filters.mediaOnly || filters.postType !== 'all');
}

export function filterHomeFeedEvents(
  events: RawEvent[],
  filters: FeedFilters,
  resolvedReposts: ReadonlyMap<string, RawEvent> = new Map(),
): RawEvent[] {
  if (filters.showReplies && filters.showReposts && !filters.mediaOnly && filters.postType === 'all') { return events; }
  const knownEvents = new Map(events.map((event) => [event.id, event]));
  return events.filter((event) => {
    const repost = event.kind === 6 || event.kind === 16;
    if (repost && !filters.showReposts) { return false; }
    const target = repost && needsRepostFilterTargets(filters)
      ? resolvedReposts.get(event.id)
        ?? getVerifiedEmbeddedRepostTarget(event)
        ?? knownEvents.get(getKind6RepostTargetEventId(event) ?? '')
      : event;
    if (!target) { return false; }
    return (filters.showReplies || target.kind !== 1 || !isReplyEvent(target))
      && (filters.postType !== 'articles' || target.kind === 30_023)
      && (filters.postType !== 'posts' || target.kind !== 30_023)
      && (!filters.mediaOnly || getNotePresentation(target).embedGroups.some((group) => group.some((embed) => embed.kind !== 'file')));
  });
}
