import { writable } from 'svelte/store';
import { getNotePresentation } from './noteContent';
import { isReplyEvent, type RawEvent } from './nostr';
import { getKind6RepostTargetEventId, getVerifiedEmbeddedRepostTarget } from './repostPresentation';
import type { HomeTab } from './routes';

export type FeedFilters = {
  showReplies: boolean;
  showReposts: boolean;
  showRepliedTo: boolean;
  mediaOnly: boolean;
  postType: 'all' | 'posts' | 'articles';
  /** Show only posts containing any of these words or #hashtags (lowercase). */
  words: string[];
  /** Show only posts that tag any of these people (hex pubkeys). */
  mentions: string[];
  /** Leave out posts already seen when the feed opens. */
  hideSeen: boolean;
  /** Reveal new posts without the "new posts" button while at the top. */
  autoShowNew: boolean;
};

const DEFAULT_FILTERS: FeedFilters = {
  showReplies: true,
  showReposts: true,
  showRepliedTo: true,
  mediaOnly: false,
  postType: 'all',
  words: [],
  mentions: [],
  hideSeen: false,
  autoShowNew: false,
};
const MAX_WORDS = 20;
const MAX_MENTIONS = 100;
const HEX_PUBKEY = /^[0-9a-f]{64}$/;

/** Split a typed list into lowercase words and #hashtags. */
export function parseFeedWords(value: string): string[] {
  return [...new Set(value.toLowerCase().split(/[\s,]+/).map((word) => word.trim()).filter((word) => word && word !== '#'))]
    .slice(0, MAX_WORDS);
}
const STORAGE_KEY = 'iris-social:feed-filters:v1';

function normalizeFilters(value: unknown): FeedFilters {
  const input = value && typeof value === 'object' ? value as Partial<FeedFilters> : {};
  return {
    showReplies: input.showReplies !== false,
    showReposts: input.showReposts !== false,
    showRepliedTo: input.showRepliedTo !== false,
    mediaOnly: input.mediaOnly === true,
    postType: input.postType === 'posts' || input.postType === 'articles' ? input.postType : 'all',
    words: Array.isArray(input.words)
      ? parseFeedWords(input.words.filter((word): word is string => typeof word === 'string').join(' '))
      : [],
    mentions: Array.isArray(input.mentions)
      ? [...new Set(input.mentions.filter((pubkey): pubkey is string => typeof pubkey === 'string' && HEX_PUBKEY.test(pubkey)))]
        .slice(0, MAX_MENTIONS)
      : [],
    hideSeen: input.hideSeen === true,
    autoShowNew: input.autoShowNew === true,
  };
}

function readFilters(): Map<string, FeedFilters> {
  try {
    const saved: unknown = JSON.parse(globalThis.localStorage?.getItem(STORAGE_KEY) ?? '[]');
    if (!Array.isArray(saved)) { return new Map(); }
    return new Map(saved.slice(-180).flatMap((entry) => (
      Array.isArray(entry) && typeof entry[0] === 'string'
        ? [[entry[0], normalizeFilters(entry[1])] as const]
        : []
    )));
  } catch { return new Map(); }
}

export const feedFiltersStore = writable(readFilters());

export function feedFilterScope(
  viewerPubkey: string | null,
  sourceId: string | null,
  tab: HomeTab,
  feedId: string | null = null,
): string | null {
  if (!viewerPubkey) { return null; }
  // A custom feed keeps its own filters across sources and base changes.
  if (feedId) { return `${viewerPubkey}:custom:${feedId}`; }
  const source = tab === 'favorites' ? 'favorites' : sourceId ?? 'following';
  return `${viewerPubkey}:${source}:${tab}`;
}

export function readFeedFilters(filters: Map<string, FeedFilters>, scope: string | null): FeedFilters {
  return scope ? filters.get(scope) ?? DEFAULT_FILTERS : DEFAULT_FILTERS;
}

export function updateFeedFilters(scope: string | null, patch: Partial<FeedFilters> | null): void {
  if (!scope) { return; }
  feedFiltersStore.update((current) => {
    const next = new Map(current);
    next.delete(scope);
    if (patch) { next.set(scope, normalizeFilters({ ...readFeedFilters(current, scope), ...patch })); }
    while (next.size > 180) { next.delete(next.keys().next().value!); }
    try { globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify([...next])); } catch { /* Retain session settings when storage is full. */ }
    return next;
  });
}

export function copyFeedFilters(from: string | null, to: string | null): void {
  let saved: FeedFilters | undefined;
  feedFiltersStore.subscribe((filters) => { saved = from ? filters.get(from) : undefined; })();
  if (saved) { updateFeedFilters(to, saved); }
}

function matchesContent(filters: FeedFilters): boolean {
  return filters.words.length > 0 || filters.mentions.length > 0;
}

export function needsRepostFilterTargets(filters: FeedFilters): boolean {
  return filters.showReposts
    && (!filters.showReplies || filters.mediaOnly || filters.postType !== 'all' || matchesContent(filters));
}

function matchesWords(event: RawEvent, words: readonly string[]): boolean {
  if (words.length === 0) { return true; }
  const content = event.content.toLowerCase();
  const hashtags = new Set(event.tags.filter((tag) => tag[0] === 't' && tag[1]).map((tag) => tag[1]!.toLowerCase()));
  return words.some((word) => (word.startsWith('#')
    ? hashtags.has(word.slice(1)) || content.includes(word)
    : content.includes(word)));
}

function matchesMentions(event: RawEvent, mentions: readonly string[]): boolean {
  return mentions.length === 0
    || event.tags.some((tag) => tag[0] === 'p' && mentions.includes(tag[1]?.toLowerCase() ?? ''));
}

export function filterHomeFeedEvents(
  events: RawEvent[],
  filters: FeedFilters,
  resolvedReposts: ReadonlyMap<string, RawEvent> = new Map(),
  seenEventIds: ReadonlySet<string> | null = null,
): RawEvent[] {
  const hidesSeen = filters.hideSeen && Boolean(seenEventIds?.size);
  if (filters.showReplies && filters.showReposts && !filters.mediaOnly && filters.postType === 'all'
    && !matchesContent(filters) && !hidesSeen) { return events; }
  const knownEvents = new Map(events.map((event) => [event.id, event]));
  return events.filter((event) => {
    if (hidesSeen && seenEventIds!.has(event.id)) { return false; }
    const repost = event.kind === 6 || event.kind === 16;
    if (repost && !filters.showReposts) { return false; }
    const target = repost && needsRepostFilterTargets(filters)
      ? resolvedReposts.get(event.id)
        ?? getVerifiedEmbeddedRepostTarget(event)
        ?? knownEvents.get(getKind6RepostTargetEventId(event) ?? '')
      : event;
    if (!target) { return false; }
    return (filters.showReplies || target.kind !== 1 || !isReplyEvent(target))
      && (filters.postType !== 'articles' || target.kind === 30_023)
      && (filters.postType !== 'posts' || target.kind !== 30_023)
      && (!filters.mediaOnly || getNotePresentation(target).embedGroups.some((group) => group.some((embed) => embed.kind !== 'file')))
      && matchesWords(target, filters.words)
      && matchesMentions(target, filters.mentions);
  });
}
