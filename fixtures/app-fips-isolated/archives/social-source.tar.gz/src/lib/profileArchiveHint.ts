import { nhashDecode } from '@hashtree/core';
import { decodeStoredNostrEventMsgpack } from '@hashtree/nostr';
import { DEFAULT_NOSTR_EVENT_INDEX_REF, getConfiguredEventIndexRef } from './config';
import { verifyIndexedEvent } from './fastEventVerification';
import { parseProfileEvent } from './nostr';
import { loadSocialGraphFrontier } from './socialGraphFrontier';
import { SOCIAL_GRAPH_ROOT } from './socialGraphSnapshot.generated';
import { socialDataPlane } from './socialDataPlane';
import { createWorkerTree } from './workerBlockStore';
import { getSharedProfileRecord, rememberProfileRecord } from './profileCache';

/** Read the signed profile block directly when the public starter graph has a known archive link. */
export async function restoreProfileArchiveHint(pubkey: string, signal: AbortSignal): Promise<void> {
  if (getConfiguredEventIndexRef() !== DEFAULT_NOSTR_EVENT_INDEX_REF
    || getSharedProfileRecord(pubkey)?.eventId) { return; }
  try {
    if (pubkey !== SOCIAL_GRAPH_ROOT && !(await loadSocialGraphFrontier()).includes(pubkey)) { return; }
    if (signal.aborted) { return; }
    const { links }: { links: Record<string, string> } = (await import('./profileArchiveHints.json')).default;
    const link = links[pubkey];
    if (!link || signal.aborted || getSharedProfileRecord(pubkey)?.eventId) { return; }
    const bytes = await createWorkerTree().readFile(nhashDecode(link));
    if (!bytes || signal.aborted) { return; }
    const event = decodeStoredNostrEventMsgpack(bytes);
    if (event.kind === 0 && event.pubkey === pubkey && await verifyIndexedEvent(event, signal)
      && !signal.aborted && socialDataPlane.isExternalEventVisible(event)) {
      rememberProfileRecord(parseProfileEvent(event));
    }
  } catch {
    // A missing block is an ordinary cache miss. The live and catalog reads continue.
  }
}
