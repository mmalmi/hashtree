import type { Store } from '@hashtree/core';
import {
  HashtreeNostrEventReader,
  type HashtreeNostrRootEntry,
  type HashtreeNostrRootProvider,
} from '@hashtree/nostr-pubsub';
import {
  NostrPubsubRouter,
  allowWithPriority,
  drop,
  localIndexRoute,
  relayRoute,
  withRouteDataset,
  type NostrEventReader,
  type NostrFilter,
  type PubsubPolicy,
  type QueryOptions,
  type RoutedQueryReport,
  type RouteQuerySource,
} from 'nostr-pubsub';

export const IRIS_DURABLE_EVENT_DATASET = 'iris-social:durable-hashtree';
export const IRIS_LIVE_EVENT_DATASET = 'iris-social:live-overlay';
export const IRIS_RELAY_EVENT_DATASET = 'iris-social:optional-relay-content';

export type IrisEventRootSnapshot = {
  /** Additive shared/archive partitions. Equal partition IDs are replicas. */
  shared: readonly HashtreeNostrRootEntry[];
  /** Additive personal partitions. Equal partition IDs are replicas. */
  personal: readonly HashtreeNostrRootEntry[];
};

export type IrisEventReadRouterOptions = {
  store: Store;
  /** The bounded persisted/in-memory social tail is an additive local dataset. */
  liveOverlayReader: NostrEventReader;
  /** Optional direct relay reads. The route is always disabled unless explicitly enabled. */
  relayContentReader?: NostrEventReader;
  relayContentEnabled?: () => boolean;
  policy?: PubsubPolicy;
  maxConcurrentPartitions?: number;
  /** Browser deployments move durable traversal/verification into the data worker. */
  durableReaderFactory?: (roots: HashtreeNostrRootProvider) => NostrEventReader;
};

const allowLocalSources: PubsubPolicy = {
  checkEvent: () => allowWithPriority(0),
  checkSource: () => allowWithPriority(0),
};

/**
 * The one application event-query router.
 *
 * Each query captures the active immutable root snapshot while every event
 * request remains an ordinary Nostr filter. One Hashtree adapter fans that
 * request across all additive shared/personal partitions. The live overlay is
 * a separate local dataset, and direct relay content is an explicit opt-in.
 */
export class IrisEventReadRouter {
  private roots: IrisEventRootSnapshot = { shared: [], personal: [] };
  private readonly router: NostrPubsubRouter;

  constructor(options: IrisEventReadRouterOptions) {
    const configuredPolicy = options.policy ?? allowLocalSources;
    const rootProvider: HashtreeNostrRootProvider = {
      snapshot: () => {
        const snapshot = this.roots;
        return [
          ...prefixPartitions('shared', snapshot.shared),
          ...prefixPartitions('personal', snapshot.personal),
        ];
      },
    };
    const durableReader = options.durableReaderFactory
      ? options.durableReaderFactory(rootProvider)
      : new HashtreeNostrEventReader({
          store: options.store,
          sourceId: 'iris-social-hashtree-indexes',
          roots: rootProvider,
          maxConcurrentPartitions: options.maxConcurrentPartitions,
        });
    const routes: RouteQuerySource[] = [
      {
        route: withRouteDataset(
          localIndexRoute('iris-social-hashtree-indexes'),
          IRIS_DURABLE_EVENT_DATASET,
        ),
        reader: durableReader,
      },
      {
        route: withRouteDataset(
          localIndexRoute('iris-social-live-overlay'),
          IRIS_LIVE_EVENT_DATASET,
        ),
        reader: options.liveOverlayReader,
      },
    ];
    if (options.relayContentReader) {
      routes.push({
        route: withRouteDataset(
          relayRoute('iris-social:configured-relays'),
          IRIS_RELAY_EVENT_DATASET,
        ),
        reader: options.relayContentReader,
      });
    }
    const policy: PubsubPolicy = {
      checkEvent: (context) => configuredPolicy.checkEvent(context),
      checkSource: (context) => {
        if (
          context.candidate.source.kind === 'relay'
          && options.relayContentEnabled?.() !== true
        ) {
          return drop('Direct relay content reads are disabled');
        }
        return configuredPolicy.checkSource(context);
      },
    };
    this.router = new NostrPubsubRouter({ policy, querySources: routes });
  }

  /**
   * Add or replace named partitions known to this browser session. Distinct
   * partition IDs are additive; an equal partition/replica identity replaces
   * an older mutable root atomically for subsequent queries.
   */
  registerRoots(roots: IrisEventRootSnapshot): void {
    this.roots = mergeRootSnapshots(this.roots, roots);
  }

  /** Replace the complete bounded active-root registry for subsequent queries. */
  replaceRoots(roots: IrisEventRootSnapshot): void {
    this.roots = {
      shared: roots.shared.map(cloneRootEntry),
      personal: roots.personal.map(cloneRootEntry),
    };
  }

  async query(
    filters: NostrFilter[],
    options: QueryOptions = {},
  ): Promise<RoutedQueryReport> {
    return await this.router.queryWithContext(filters, { query: options });
  }
}

function mergeRootSnapshots(
  current: IrisEventRootSnapshot,
  incoming: IrisEventRootSnapshot,
): IrisEventRootSnapshot {
  return {
    shared: mergeRootEntries(current.shared, incoming.shared),
    personal: mergeRootEntries(current.personal, incoming.personal),
  };
}

function mergeRootEntries(
  current: readonly HashtreeNostrRootEntry[],
  incoming: readonly HashtreeNostrRootEntry[],
): HashtreeNostrRootEntry[] {
  const entries = new Map(current.map((entry) => [rootEntryKey(entry), entry]));
  for (const entry of incoming) {
    entries.set(rootEntryKey(entry), cloneRootEntry(entry));
  }
  return [...entries.values()];
}

function rootEntryKey(entry: HashtreeNostrRootEntry): string {
  return `${entry.partitionId}\u0000${entry.replicaId ?? 'default'}`;
}

function cloneRootEntry(entry: HashtreeNostrRootEntry): HashtreeNostrRootEntry {
  return {
    ...entry,
    root: entry.root === null
      ? null
      : {
          hash: new Uint8Array(entry.root.hash),
          key: entry.root.key === undefined ? undefined : new Uint8Array(entry.root.key),
        },
  };
}

function prefixPartitions(
  namespace: 'shared' | 'personal',
  roots: readonly HashtreeNostrRootEntry[],
): HashtreeNostrRootEntry[] {
  return roots.map((entry) => ({
    ...entry,
    partitionId: `${namespace}:${entry.partitionId}`,
  }));
}
