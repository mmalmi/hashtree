import { LinkType, nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  assertExactLinkNames,
  boundedInteger,
  equalBytes,
  exactKeys,
  nonEmptyString,
  nonNegativeInteger,
  objectValue,
  parseCanonicalJson,
  positiveInteger,
  publicCid,
  publicNhash,
  readCanonicalDirectory,
  readPublicBlock,
  requiredLink,
  safeAdd,
  strictHex,
  strictPubkey,
} from './profileSearchV3ClientPrimitives';
import {
  CATALOG_MANIFEST_MAX_BYTES,
  MANIFEST_ENTRY,
  MAX_CATALOG_RUNS,
  MAX_REACHABLE_NODES,
  MAX_ROUTER_HEIGHT,
  NORMALIZATION,
  PACKED_PAGE_FORMAT,
  PAGE_ROUTER_FORMAT,
  PARTITION_POLICY,
  RANK_POLICY,
  ROOT_MAX_BYTES,
  RUN_MANIFEST_MAX_BYTES,
  RUN_POSTING_ENTRY,
  RUN_PROFILE_ENTRY,
  PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT,
  PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT,
  type ProfileSearchV3ClientBranchManifest,
  type ProfileSearchV3ClientCatalogEnvelope,
  type ProfileSearchV3ClientCatalogManifest,
  type ProfileSearchV3ClientRunDescriptor,
  type ProfileSearchV3ClientRunEnvelope,
  type ProfileSearchV3ClientRunManifest,
} from './profileSearchV3ClientTypes';

const decoder = new TextDecoder('utf-8', { fatal: true });

export async function readCatalogEnvelope(
  store: Store,
  root: CID,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientCatalogEnvelope> {
  const directory = await readCanonicalDirectory(store, root, ROOT_MAX_BYTES, 'catalog root', signal);
  const manifestLink = requiredLink(directory.links, MANIFEST_ENTRY, LinkType.Blob, 'catalog manifest');
  const manifestBytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    CATALOG_MANIFEST_MAX_BYTES,
    'catalog manifest',
    signal,
  );
  if (manifestLink.size !== manifestBytes.length) {
    throw new Error('Profile-search v3 catalog manifest size is inconsistent');
  }
  const manifest = parseCatalogManifest(manifestBytes);
  assertExactLinkNames(directory.links, [MANIFEST_ENTRY, ...manifest.runs.map((run) => run.entry)]);
  const runRoots = manifest.runs.map((run) => {
    const link = requiredLink(directory.links, run.entry, LinkType.Dir, `catalog ${run.entry}`);
    const declared = publicNhash(run.root, `${run.entry} root`);
    if (link.size !== run.reachableNodeCount || !equalBytes(link.hash, declared.hash)) {
      throw new Error(`Profile-search v3 catalog run link is inconsistent: ${run.entry}`);
    }
    return declared;
  });
  return { root: publicCid(root, 'catalog root'), manifest, runRoots };
}

function parseCatalogManifest(bytes: Uint8Array): ProfileSearchV3ClientCatalogManifest {
  const raw = parseCanonicalJson(bytes, 'catalog manifest');
  exactKeys(raw, [
    'format', 'generatedAt', 'sourceRoot', 'eligibleRanksSha256', 'compatibility', 'runs',
    'reachableNodeCount',
  ], 'catalog manifest');
  const compatibility = objectValue(raw.compatibility, 'catalog compatibility');
  exactKeys(compatibility, ['runFormat', 'normalization', 'rankPolicy', 'partitionPolicy'],
    'catalog compatibility');
  if (raw.format !== PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT
    || compatibility.runFormat !== PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT
    || compatibility.normalization !== NORMALIZATION
    || compatibility.rankPolicy !== RANK_POLICY
    || compatibility.partitionPolicy !== PARTITION_POLICY
    || !Array.isArray(raw.runs)
    || raw.runs.length < 1
    || raw.runs.length > MAX_CATALOG_RUNS) {
    throw new Error('Unsupported profile-search v3 catalog manifest');
  }
  const roots = new Set<string>();
  const runs = raw.runs.map((candidate, index) => parseRunDescriptor(candidate, index, roots));
  for (let index = 1; index < runs.length; index += 1) {
    if (runs[index - 1]!.rangeEnd >= runs[index]!.rangeStart) {
      throw new Error('Profile-search v3 catalog partitions overlap or are out of order');
    }
  }
  const manifest: ProfileSearchV3ClientCatalogManifest = {
    format: PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT,
    generatedAt: nonNegativeInteger(raw.generatedAt, 'generatedAt'),
    sourceRoot: nhashEncode(publicNhash(raw.sourceRoot, 'sourceRoot')),
    eligibleRanksSha256: strictHex(raw.eligibleRanksSha256, 64, 'eligibleRanksSha256'),
    compatibility: {
      runFormat: PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT,
      normalization: NORMALIZATION,
      rankPolicy: RANK_POLICY,
      partitionPolicy: PARTITION_POLICY,
    },
    runs,
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'catalog reachableNodeCount'),
  };
  const reachable = runs.reduce((total, run) => safeAdd(total, run.reachableNodeCount), 2);
  if (manifest.reachableNodeCount !== reachable || reachable > MAX_REACHABLE_NODES
    || decoder.decode(bytes) !== JSON.stringify(manifest)) {
    throw new Error('Profile-search v3 catalog manifest is inconsistent or noncanonical');
  }
  return manifest;
}

function parseRunDescriptor(
  value: unknown,
  index: number,
  roots: Set<string>,
): ProfileSearchV3ClientRunDescriptor {
  const raw = objectValue(value, `run ${index}`);
  exactKeys(raw, [
    'entry', 'root', 'rangeStart', 'rangeEnd', 'minimumPubkey', 'maximumPubkey',
    'profileCount', 'postingCount', 'pageCount', 'reachableNodeCount', 'minimumRankHint',
    'maximumRankHint',
  ], `run ${index}`);
  const root = nhashEncode(publicNhash(raw.root, `run ${index} root`));
  if (roots.has(root)) {throw new Error('Profile-search v3 catalog has a duplicate run');}
  roots.add(root);
  const run: ProfileSearchV3ClientRunDescriptor = {
    entry: nonEmptyString(raw.entry, `run ${index} entry`),
    root,
    rangeStart: strictPubkey(raw.rangeStart, `run ${index} rangeStart`),
    rangeEnd: strictPubkey(raw.rangeEnd, `run ${index} rangeEnd`),
    minimumPubkey: strictPubkey(raw.minimumPubkey, `run ${index} minimumPubkey`),
    maximumPubkey: strictPubkey(raw.maximumPubkey, `run ${index} maximumPubkey`),
    profileCount: positiveInteger(raw.profileCount, `run ${index} profileCount`),
    postingCount: positiveInteger(raw.postingCount, `run ${index} postingCount`),
    pageCount: positiveInteger(raw.pageCount, `run ${index} pageCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `run ${index} reachableNodeCount`),
    minimumRankHint: nonNegativeInteger(raw.minimumRankHint, `run ${index} minimumRankHint`),
    maximumRankHint: nonNegativeInteger(raw.maximumRankHint, `run ${index} maximumRankHint`),
  };
  if (run.entry !== `run-${index.toString().padStart(4, '0')}`
    || run.rangeStart > run.minimumPubkey
    || run.minimumPubkey > run.maximumPubkey
    || run.maximumPubkey > run.rangeEnd
    || run.rangeStart[0] !== run.rangeEnd[0]
    || run.minimumRankHint > run.maximumRankHint) {
    throw new Error(`Invalid profile-search v3 catalog run layout at ${index}`);
  }
  return run;
}

export async function readClientRunEnvelope(
  store: Store,
  root: CID,
  expected: ProfileSearchV3ClientRunDescriptor,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientRunEnvelope> {
  const directory = await readCanonicalDirectory(store, root, ROOT_MAX_BYTES, 'run root', signal);
  assertExactLinkNames(directory.links, [MANIFEST_ENTRY, RUN_PROFILE_ENTRY, RUN_POSTING_ENTRY]);
  const manifestLink = requiredLink(directory.links, MANIFEST_ENTRY, LinkType.Blob, 'run manifest');
  const manifestBytes = await readPublicBlock(
    store,
    { hash: manifestLink.hash },
    RUN_MANIFEST_MAX_BYTES,
    'run manifest',
    signal,
  );
  if (manifestLink.size !== manifestBytes.length) {
    throw new Error('Profile-search v3 run manifest size is inconsistent');
  }
  const manifest = parseRunManifest(manifestBytes);
  if (manifest.profileCount !== expected.profileCount
    || manifest.postingCount !== expected.postingCount
    || manifest.reachableNodeCount !== expected.reachableNodeCount
    || manifest.branches.profiles.pageCount + manifest.branches.postings.pageCount
      !== expected.pageCount
    || manifest.branches.profiles.minKey !== expected.minimumPubkey
    || manifest.branches.profiles.maxKey !== expected.maximumPubkey
    || manifest.minimumRankHint !== expected.minimumRankHint
    || manifest.maximumRankHint !== expected.maximumRankHint) {
    throw new Error('Profile-search v3 catalog run descriptor is inconsistent');
  }
  return {
    manifest,
    profileRoot: boundBranch(directory.links, RUN_PROFILE_ENTRY, manifest.branches.profiles),
    postingRoot: boundBranch(directory.links, RUN_POSTING_ENTRY, manifest.branches.postings),
  };
}

function parseRunManifest(bytes: Uint8Array): ProfileSearchV3ClientRunManifest {
  const raw = parseCanonicalJson(bytes, 'run manifest');
  exactKeys(raw, [
    'format', 'packedPageFormat', 'pageRouterFormat', 'normalization', 'rankPolicy',
    'profileCount', 'postingCount', 'minimumRankHint', 'maximumRankHint', 'branches',
    'reachableNodeCount',
  ], 'run manifest');
  if (raw.format !== PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT
    || raw.packedPageFormat !== PACKED_PAGE_FORMAT
    || raw.pageRouterFormat !== PAGE_ROUTER_FORMAT
    || raw.normalization !== NORMALIZATION
    || raw.rankPolicy !== RANK_POLICY) {
    throw new Error('Unsupported profile-search v3 run manifest');
  }
  const branches = objectValue(raw.branches, 'run branches');
  exactKeys(branches, ['profiles', 'postings'], 'run branches');
  const manifest: ProfileSearchV3ClientRunManifest = {
    format: PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT,
    packedPageFormat: PACKED_PAGE_FORMAT,
    pageRouterFormat: PAGE_ROUTER_FORMAT,
    normalization: NORMALIZATION,
    rankPolicy: RANK_POLICY,
    profileCount: positiveInteger(raw.profileCount, 'profileCount'),
    postingCount: positiveInteger(raw.postingCount, 'postingCount'),
    minimumRankHint: nonNegativeInteger(raw.minimumRankHint, 'minimumRankHint'),
    maximumRankHint: nonNegativeInteger(raw.maximumRankHint, 'maximumRankHint'),
    branches: {
      profiles: parseBranch(branches.profiles, 'documents', 'profiles'),
      postings: parseBranch(branches.postings, 'postings', 'postings'),
    },
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, 'run reachableNodeCount'),
  };
  const reachable = safeAdd(2, safeAdd(
    manifest.branches.profiles.reachableNodeCount,
    manifest.branches.postings.reachableNodeCount,
  ));
  if (manifest.profileCount !== manifest.branches.profiles.entryCount
    || manifest.postingCount !== manifest.branches.postings.entryCount
    || manifest.minimumRankHint > manifest.maximumRankHint
    || manifest.reachableNodeCount !== reachable
    || reachable > MAX_REACHABLE_NODES
    || decoder.decode(bytes) !== JSON.stringify(manifest)) {
    throw new Error('Profile-search v3 run manifest is inconsistent or noncanonical');
  }
  return manifest;
}

function parseBranch(
  value: unknown,
  kind: ProfileSearchV3ClientBranchManifest['pageKind'],
  label: string,
): ProfileSearchV3ClientBranchManifest {
  const raw = objectValue(value, `${label} branch`);
  exactKeys(raw, [
    'pageKind', 'entryCount', 'minKey', 'maxKey', 'height', 'pageCount', 'routerNodeCount',
    'reachableNodeCount',
  ], `${label} branch`);
  const branch: ProfileSearchV3ClientBranchManifest = {
    pageKind: kind,
    entryCount: positiveInteger(raw.entryCount, `${label} entryCount`),
    minKey: nonEmptyString(raw.minKey, `${label} minKey`),
    maxKey: nonEmptyString(raw.maxKey, `${label} maxKey`),
    height: boundedInteger(raw.height, 0, MAX_ROUTER_HEIGHT, `${label} height`),
    pageCount: positiveInteger(raw.pageCount, `${label} pageCount`),
    routerNodeCount: positiveInteger(raw.routerNodeCount, `${label} routerNodeCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `${label} reachableNodeCount`),
  };
  if (raw.pageKind !== kind || branch.minKey > branch.maxKey
    || branch.reachableNodeCount !== branch.pageCount + branch.routerNodeCount) {
    throw new Error(`Invalid profile-search v3 ${label} branch`);
  }
  return branch;
}

function boundBranch(
  links: Parameters<typeof requiredLink>[0],
  name: string,
  branch: ProfileSearchV3ClientBranchManifest,
): CID {
  const link = requiredLink(links, name, LinkType.Dir, `run ${name}`);
  if (link.size !== branch.reachableNodeCount) {
    throw new Error(`Profile-search v3 run ${name} link is inconsistent`);
  }
  return { hash: new Uint8Array(link.hash) };
}
