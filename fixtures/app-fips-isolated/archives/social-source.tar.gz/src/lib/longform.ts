import { getTagValue, type RawEvent } from './nostr';
import { buildNotePreviewText } from './noteContent';

export type LongformMetadata = {
  title: string;
  summary: string | null;
  image: string | null;
};

const LONGFORM_KINDS = new Set([30023, 30024]);

function trimToLength(value: string, maxLength: number): string {
  const trimmed = value.replace(/\s+/g, ' ').trim();
  if (trimmed.length <= maxLength) {
    return trimmed;
  }

  return `${trimmed.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`;
}

export function isLongformEvent(event: RawEvent): boolean {
  return LONGFORM_KINDS.has(event.kind);
}

export function getLongformMetadata(event: RawEvent): LongformMetadata | null {
  if (!isLongformEvent(event)) {
    return null;
  }

  const title = getTagValue(event, 'title')?.trim() || 'Longform post';
  const summary = getTagValue(event, 'summary')?.trim() || null;
  const image = getTagValue(event, 'image')?.trim() || null;

  return {
    title,
    summary,
    image,
  };
}

export function buildEventPreviewText(event: RawEvent, maxLength = 180): string {
  const metadata = getLongformMetadata(event);
  if (metadata?.title) {
    return trimToLength(metadata.summary ? `${metadata.title} ${metadata.summary}` : metadata.title, maxLength);
  }

  return buildNotePreviewText(event.content, event.tags, maxLength);
}
