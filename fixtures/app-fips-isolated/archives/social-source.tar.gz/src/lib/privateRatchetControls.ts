import type { NdrRuntime } from 'nostr-double-ratchet';
import { PRIVATE_CONTACT_CONTROL_KIND, parsePrivateContactControl, type PrivateContactDocument } from 'nostr-social-graph/privateContactSyncV2';
import { isPrivateSyncSibling, requirePrivateSyncAuthorization } from './privateRatchetAuthorization';

// Social has no chat mute/pin or device-label feature. Authorized snapshots for
// those known controls may be acknowledged without growing an unused inbox.
const unsupportedKinds = [10449, 10450, 10453];
export const SOCIAL_PRIVATE_CONTROL_KINDS = [PRIVATE_CONTACT_CONTROL_KIND, ...unsupportedKinds];

type ControlOptions = {
  owner: string;
  signal: AbortSignal;
  isAuthorizationReady(): boolean;
  refreshAuthorization(): Promise<void>;
  onError(error: unknown): void;
  merge(document: PrivateContactDocument): Promise<void>;
  snapshot(): Promise<void>;
};

/** Register before runtime initialization so all durable controls share admission. */
export function registerPrivateRatchetControls(
  runtime: Pick<NdrRuntime, 'getState' | 'onDurableSessionEvent'>,
  options: ControlOptions,
): () => void {
  const requested = new Map<string, number>();
  const { owner, signal } = options;
  return runtime.onDurableSessionEvent(SOCIAL_PRIVATE_CONTROL_KINDS, async (event, sender, meta) => {
    signal.throwIfAborted();
    if (!options.isAuthorizationReady()) { throw new Error('Waiting for the device list.'); }
    const state = runtime.getState();
    requirePrivateSyncAuthorization(state);
    const senderDevice = meta?.senderDevicePubkey ?? meta?.fromDeviceId;
    const unsupported = unsupportedKinds.includes(event.kind);
    // Rejecting a control consumes its local inbox row without applying a setting.
    // An otherwise valid sibling with unresolved membership still retries below.
    if (state.ownerPubkey !== owner || sender !== owner
      || meta?.senderOwnerPubkey !== owner || !senderDevice || senderDevice === state.currentDevicePubkey
      || (event.pubkey !== owner && event.pubkey !== senderDevice)
      || event.tags.some(tag => tag[0] === 'p' && tag[1] !== owner)) { return; }
    if (sender === owner && meta?.senderOwnerPubkey === owner && senderDevice
      && (!state.isCurrentDeviceRegistered || !state.registeredDevices.some(device => device.identityPubkey === senderDevice))) {
      // A paired device may send before its newer roster reaches this client.
      void options.refreshAuthorization().catch(options.onError);
      throw new Error('Waiting for the device list.');
    }
    if (!isPrivateSyncSibling(owner, event, sender, meta, state) || unsupported) { return; }
    if (new TextEncoder().encode(event.content).length > 26_000) { return; }
    let control: ReturnType<typeof parsePrivateContactControl>;
    try { control = parsePrivateContactControl(JSON.parse(event.content), owner); }
    catch { return; }
    if (control.type === 'private-contact-sync') { await options.merge(control.document); }
    else {
      const device = meta!.senderDevicePubkey ?? meta!.fromDeviceId!;
      if (Date.now() - (requested.get(device) ?? 0) < 5_000) { return; }
      await options.snapshot();
      requested.set(device, Date.now());
    }
  });
}
