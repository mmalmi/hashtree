import { nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  readPostSearchCatalog,
  type PostSearchCatalog,
} from './postSearchCatalog';
import { readPostSearchCatalogFormat } from './postSearchCatalogFormat';
import {
  throwIfPostSearchAborted,
  withPostSearchTimeout,
} from './postSearchAbort';
import { POST_SEARCH_V5_ROUTED_CATALOG_FORMAT } from '../server/postSearchV5RoutedCatalog';

const IMMUTABLE_CATALOG_CACHE_LIMIT = 8;

export type PostSearchCatalogWarmSource = {
  publisherId: string;
  root: CID | PromiseLike<CID | null>;
};

export type PostSearchCatalogWarmOptions = {
  signal: AbortSignal | null;
  publisherConcurrency: number;
  requestTimeoutMs: number;
};

/** Bounded parsed-object cache for immutable catalog roots. */
export class PostSearchCatalogCache {
  private readonly formats = new Map<string, Promise<string>>();
  private readonly legacyCatalogs = new Map<string, Promise<PostSearchCatalog>>();

  constructor(private readonly store: Store) {}

  async format(root: CID): Promise<string> {
    return await this.open(this.formats, root, async () =>
      await readPostSearchCatalogFormat(this.store, root));
  }

  async legacy(root: CID): Promise<PostSearchCatalog> {
    return await this.open(this.legacyCatalogs, root, async () =>
      await readPostSearchCatalog(this.store, root));
  }

  async warm(
    sources: readonly PostSearchCatalogWarmSource[],
    routedWarm: (publisherId: string, root: CID) => Promise<void>,
    options: PostSearchCatalogWarmOptions,
  ): Promise<void> {
    throwIfPostSearchAborted(options.signal);
    await mapConcurrent(sources, options.publisherConcurrency, async (source) => {
      try {
        const root = await withPostSearchTimeout(
          Promise.resolve(source.root),
          options.requestTimeoutMs,
          options.signal,
        );
        if (!root) {return;}
        const format = await withPostSearchTimeout(
          this.format(root),
          options.requestTimeoutMs,
          options.signal,
        );
        if (format === POST_SEARCH_V5_ROUTED_CATALOG_FORMAT) {
          await withPostSearchTimeout(
            routedWarm(source.publisherId, root),
            options.requestTimeoutMs,
            options.signal,
          );
        }
      } catch {
        throwIfPostSearchAborted(options.signal);
      }
    });
  }

  private async open<Value>(
    cache: Map<string, Promise<Value>>,
    root: CID,
    reader: () => Promise<Value>,
  ): Promise<Value> {
    const key = nhashEncode(root);
    let pending = cache.get(key);
    if (pending) {
      cache.delete(key);
      cache.set(key, pending);
      return await pending;
    }
    while (cache.size >= IMMUTABLE_CATALOG_CACHE_LIMIT) {
      cache.delete(cache.keys().next().value as string);
    }
    pending = reader();
    cache.set(key, pending);
    void pending.catch(() => {
      if (cache.get(key) === pending) {cache.delete(key);}
    });
    return await pending;
  }
}

async function mapConcurrent<Input>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input) => Promise<void>,
): Promise<void> {
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      await worker(values[index]!);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
}
