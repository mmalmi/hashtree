import type { CID } from '@hashtree/core';
import type { AppCombinedState } from './appState';
import { isShadowEventReadComparisonEnabled } from './config';
import { buildShadowReadObservation } from './shadowReadObservation';
import type {
  ShadowReadObservation,
  ShadowReadScope,
} from './shadowReadComparator';
import type { ProfileRecord, RawEvent } from './nostr';

export type ShadowReadOptions = {
  scope: ShadowReadScope;
  sharedRoot: CID;
  roots: readonly CID[];
  events: readonly RawEvent[];
  profiles?: readonly (ProfileRecord | null | undefined)[];
};

type ShadowReadControllerDeps = {
  state: AppCombinedState;
  pendingObservations: Map<ShadowReadScope, ShadowReadObservation>;
};

export function createAppShadowReadController(deps: ShadowReadControllerDeps) {
  const { state } = deps;

  function scheduleShadowReadComparison(options: ShadowReadOptions): void {
    if (!isShadowEventReadComparisonEnabled()) {return;}
    const observation = buildShadowReadObservation(options);
    if (observation.expected.length === 0) {return;}
    deps.pendingObservations.set(observation.scope, observation);
    if (state.cancelShadowReadIdleDrain || typeof window === 'undefined') {return;}

    const drain = () => {
      state.cancelShadowReadIdleDrain = null;
      const observations = [...deps.pendingObservations.values()];
      deps.pendingObservations.clear();
      if (observations.length === 0) {return;}
      if (!state.shadowReadComparatorPromise) {
        const pending = import('./browserShadowReadComparator')
          .then(({ getBrowserShadowReadComparator }) => getBrowserShadowReadComparator())
          .catch((error) => {
            if (state.shadowReadComparatorPromise === pending) {
              state.shadowReadComparatorPromise = null;
            }
            throw error;
          });
        state.shadowReadComparatorPromise = pending;
      }
      void state.shadowReadComparatorPromise
        .then((comparator) => observations.forEach((item) => comparator.observe(item)))
        .catch((error) => console.warn('Detached Hashtree shadow comparison unavailable', error));
    };

    if (typeof window.requestIdleCallback === 'function') {
      const idleId = window.requestIdleCallback(drain, { timeout: 3_000 });
      state.cancelShadowReadIdleDrain = () => window.cancelIdleCallback?.(idleId);
    } else {
      const timeoutId = window.setTimeout(drain, 1_500);
      state.cancelShadowReadIdleDrain = () => window.clearTimeout(timeoutId);
    }
  }

  function scheduleCurrentFeedShadowComparison(currentRoot: CID, token: number): void {
    const snapshot = state.feed;
    if (!snapshot || token !== state.loadToken) {return;}
    scheduleShadowReadComparison({
      scope: 'feed',
      sharedRoot: currentRoot,
      roots: snapshot.continuation?.roots.map(({ root }) => root) ?? [currentRoot],
      events: snapshot.notes,
    });
  }

  function scheduleCurrentProfileShadowComparison(currentRoot: CID, token: number): void {
    const snapshot = state.profilePage;
    if (!snapshot || token !== state.loadToken) {return;}
    scheduleShadowReadComparison({
      scope: 'profile',
      sharedRoot: currentRoot,
      roots: state.profilePersonalRoot ? [currentRoot, state.profilePersonalRoot] : [currentRoot],
      events: [
        ...snapshot.notes,
        ...(snapshot.likedNotes ?? []).flatMap(({ reaction, note }) => [reaction, note]),
      ],
      profiles: [snapshot.profile],
    });
  }

  async function runProfileHydrationWithShadow(
    currentRoot: CID,
    token: number,
    operation: () => Promise<void>,
  ): Promise<void> {
    await operation();
    scheduleCurrentProfileShadowComparison(currentRoot, token);
  }

  return {
    runProfileHydrationWithShadow,
    scheduleCurrentFeedShadowComparison,
    scheduleShadowReadComparison,
  };
}
