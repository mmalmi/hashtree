import { geohashCellSize, normalizeGeohash } from './composerOptions';
import type { RawEvent } from './nostr';

export type NoteLocation = {
  /** Short text for the card. */
  label: string;
  /** Full description for the tooltip. */
  title: string;
};

const LOCATION_TEXT_MAX = 30;

function truncate(value: string, max: number): string {
  return value.length > max ? `${value.slice(0, max - 1).trimEnd()}…` : value;
}

/** Keep only the most precise geohash for each area, as Iris Client shows them. */
export function mostSpecificGeohashes(geohashes: Iterable<string>): string[] {
  const unique = [...new Set(geohashes)].sort((a, b) => b.length - a.length);
  const specific: string[] = [];
  for (const geohash of unique) {
    if (!specific.some((existing) => existing.startsWith(geohash))) {
      specific.push(geohash);
    }
  }
  return specific.sort();
}

/** The NIP-52 style `location` text or the geohash `g` tags of a note. */
export function getNoteLocation(event: Pick<RawEvent, 'tags'>): NoteLocation | null {
  const locationText = event.tags
    .find((tag) => tag[0] === 'location' && tag[1]?.trim())?.[1]?.trim() ?? '';
  const geohashes = mostSpecificGeohashes(event.tags
    .filter((tag) => tag[0] === 'g' && tag[1])
    .map((tag) => normalizeGeohash(tag[1]!))
    .filter((geohash): geohash is string => Boolean(geohash)));

  if (locationText && geohashes.length <= 1) {
    return { label: truncate(locationText, LOCATION_TEXT_MAX), title: locationText };
  }
  if (geohashes.length === 0) {
    return null;
  }
  const label = geohashes.join(' · ');
  const title = geohashes.length === 1
    ? `Geohash ${geohashes[0]} (about ${geohashCellSize(geohashes[0]!.length)})`
    : `Geohashes ${label}`;
  return { label, title };
}

const MAX_DISPLAY_TIMESTAMP = 253_402_300_799;

/** The NIP-40 expiration timestamp in seconds, or null. */
export function getNoteExpiration(event: Pick<RawEvent, 'tags'>): number | null {
  const value = event.tags.find((tag) => tag[0] === 'expiration' && tag[1])?.[1]?.trim() ?? '';
  if (!/^\d+$/.test(value)) {
    return null;
  }
  const timestamp = Number(value);
  // Anything past year 9999 cannot be shown as a date.
  return Number.isSafeInteger(timestamp) && timestamp > 0 && timestamp <= MAX_DISPLAY_TIMESTAMP
    ? timestamp
    : null;
}

/** Iris Client's compact countdown: "45s", "12m", "24h", "6d", "3w", "2mo" or "Expired". */
export function formatExpiresIn(timestamp: number, nowSeconds = Math.floor(Date.now() / 1000)): string {
  const diff = timestamp - nowSeconds;
  if (diff <= 0) {
    return 'Expired';
  }
  const minute = 60;
  const hour = minute * 60;
  const day = hour * 24;
  const week = day * 7;
  const month = day * 30;
  if (diff < minute) { return `${diff}s`; }
  if (diff < hour) { return `${Math.floor(diff / minute)}m`; }
  if (diff < day * 1.5) { return `${Math.round(diff / hour)}h`; }
  if (diff < week * 1.5) { return `${Math.round(diff / day)}d`; }
  if (diff < month * 2.5) { return `${Math.round(diff / week)}w`; }
  return `${Math.round(diff / month)}mo`;
}

const LINK_LABEL_MAX = 48;

/** Show a link without its scheme or trailing slash, shortened when long; the href stays intact. */
export function formatLinkLabel(url: string, maxLength = LINK_LABEL_MAX): string {
  const label = url.replace(/^https?:\/\//i, '').replace(/\/$/, '');
  if (!label) {
    return url;
  }
  return truncate(label, Math.max(8, maxLength));
}
