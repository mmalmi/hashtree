import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from './nostr';
import { isNewerReplaceableEvent } from './socialRepository';

export const MUTE_LIST_KIND = 10_000;

type AuthoredValue = {
  pubkey: string;
};

type AuthoredItem = {
  actorEvent: AuthoredValue;
};

function normalizeHexPubkey(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return /^[0-9a-f]{64}$/.test(normalized) ? normalized : null;
}

function isVerifiedMuteList(event: RawEvent, viewerPubkey: string): boolean {
  if (!isMuteListForViewer(event, viewerPubkey)) {
    return false;
  }
  try {
    // Verify a plain clone so a caller cannot smuggle nostr-tools' cached
    // verification symbol from an object that was mutated after signing.
    return verifyEvent({
      id: event.id,
      pubkey: event.pubkey,
      created_at: event.created_at,
      kind: event.kind,
      tags: event.tags.map((tag) => [...tag]),
      content: event.content,
      sig: event.sig,
    });
  } catch {
    return false;
  }
}

function isMuteListForViewer(event: RawEvent, viewerPubkey: string): boolean {
  return event.kind === MUTE_LIST_KIND && event.pubkey === viewerPubkey;
}

function selectNewestMuteListEventWhere(
  events: Iterable<RawEvent | null | undefined>,
  viewerPubkey: string,
  accepts: (event: RawEvent, viewerPubkey: string) => boolean,
): RawEvent | null {
  const normalizedViewer = normalizeHexPubkey(viewerPubkey);
  if (!normalizedViewer) {
    return null;
  }

  let winner: RawEvent | null = null;
  for (const event of events) {
    if (!event || !accepts(event, normalizedViewer)) {
      continue;
    }
    if (!winner || isNewerReplaceableEvent(event, winner)) {
      winner = event;
    }
  }
  return winner;
}

/**
 * Select a viewer's valid NIP-51 mute list. Content is deliberately opaque:
 * Iris does not claim to decrypt private entries it cannot safely interpret.
 */
export function selectNewestMuteListEvent(
  events: Iterable<RawEvent | null | undefined>,
  viewerPubkey: string,
): RawEvent | null {
  return selectNewestMuteListEventWhere(events, viewerPubkey, isVerifiedMuteList);
}

/**
 * Select from events already admitted by the social worker or locally signed.
 * This must only be used after that trust boundary; it deliberately performs
 * no renderer-thread signature work.
 */
export function selectNewestAdmittedMuteListEvent(
  events: Iterable<RawEvent | null | undefined>,
  viewerPubkey: string,
): RawEvent | null {
  return selectNewestMuteListEventWhere(events, viewerPubkey, isMuteListForViewer);
}

/** Read only public NIP-51 `p` tags. Encrypted/private content is never parsed. */
export function extractPublicMutedPubkeys(event: RawEvent | null | undefined): Set<string> {
  const pubkeys = new Set<string>();
  if (!event || event.kind !== MUTE_LIST_KIND) {
    return pubkeys;
  }
  for (const tag of event.tags) {
    if (tag[0] !== 'p') {
      continue;
    }
    const pubkey = normalizeHexPubkey(tag[1]);
    if (pubkey) {
      pubkeys.add(pubkey);
    }
  }
  return pubkeys;
}

/**
 * Replace public `p` entries while preserving opaque content at the caller and
 * every non-`p` entry. Metadata on retained `p` tags is kept verbatim.
 */
export function buildPublicMuteListTags(
  baseTags: readonly string[][],
  mutedPubkeys: Iterable<string>,
): string[][] {
  const desired = new Set<string>();
  for (const value of mutedPubkeys) {
    const pubkey = normalizeHexPubkey(value);
    if (pubkey) {
      desired.add(pubkey);
    }
  }

  const emitted = new Set<string>();
  const result: string[][] = [];
  for (const tag of baseTags) {
    if (tag[0] !== 'p') {
      result.push([...tag]);
      continue;
    }
    const pubkey = normalizeHexPubkey(tag[1]);
    if (!pubkey) {
      result.push([...tag]);
      continue;
    }
    if (!desired.has(pubkey) || emitted.has(pubkey)) {
      continue;
    }
    result.push([...tag]);
    emitted.add(pubkey);
  }

  for (const pubkey of desired) {
    if (!emitted.has(pubkey)) {
      result.push(['p', pubkey]);
    }
  }
  return result;
}

export function isMutedAuthor(
  pubkey: string,
  mutedPubkeys: ReadonlySet<string>,
  viewerPubkey: string | null,
): boolean {
  const normalized = pubkey.toLowerCase();
  return normalized !== viewerPubkey?.toLowerCase() && mutedPubkeys.has(normalized);
}

export function filterMutedAuthorEvents<T extends AuthoredValue>(
  events: readonly T[],
  mutedPubkeys: ReadonlySet<string>,
  viewerPubkey: string | null,
): T[] {
  return events.filter((event) => !isMutedAuthor(event.pubkey, mutedPubkeys, viewerPubkey));
}

export function filterMutedAuthorItems<T extends AuthoredItem>(
  items: readonly T[],
  mutedPubkeys: ReadonlySet<string>,
  viewerPubkey: string | null,
): T[] {
  return items.filter((item) => (
    !isMutedAuthor(item.actorEvent.pubkey, mutedPubkeys, viewerPubkey)
  ));
}
