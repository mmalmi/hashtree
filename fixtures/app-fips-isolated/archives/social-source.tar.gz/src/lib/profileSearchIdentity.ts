import type { ProfileRecord, RawEvent } from './nostr';

export const PROFILE_SEARCH_EVENT_MAX_BYTES = 256 * 1_024;
export const PROFILE_SEARCH_IDENTITY_FIELD_MAX_BYTES = 256;
export const PROFILE_SEARCH_IDENTITY_MAX_ALIASES = 32;
export const PROFILE_SEARCH_IDENTITY_MAX_NORMALIZED_BYTES = 8 * 1_024;

export type ProfileSearchIdentity = {
  name: string | null;
  displayName: string | null;
  nip05: string | null;
  aliases: string[];
};

const encoder = new TextEncoder();

function isUnsafeIdentityCodePoint(codePoint: number): boolean {
  return codePoint <= 0x1f
    || (codePoint >= 0x7f && codePoint <= 0x9f)
    || (codePoint >= 0x202a && codePoint <= 0x202e)
    || (codePoint >= 0x2066 && codePoint <= 0x2069);
}

function boundedIdentityField(value: unknown): { invalid: boolean; value: string | null } {
  if (typeof value !== 'string') {
    return { invalid: false, value: null };
  }
  const normalized = [...value.normalize('NFKC')]
    .filter((character) => !isUnsafeIdentityCodePoint(character.codePointAt(0) ?? 0))
    .join('')
    .replace(/\s+/gu, ' ')
    .trim();
  if (!normalized) {
    return { invalid: false, value: null };
  }
  return encoder.encode(normalized).byteLength <= PROFILE_SEARCH_IDENTITY_FIELD_MAX_BYTES
    ? { invalid: false, value: normalized }
    : { invalid: true, value: null };
}

export function projectProfileSearchIdentity(event: RawEvent): ProfileSearchIdentity | null {
  if (
    event.kind !== 0
    || encoder.encode(event.content).byteLength > PROFILE_SEARCH_EVENT_MAX_BYTES
  ) {
    return null;
  }

  let metadata: unknown;
  try {
    metadata = JSON.parse(event.content);
  } catch {
    return null;
  }
  if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) {
    return null;
  }

  const value = metadata as Record<string, unknown>;
  const fields = {
    name: boundedIdentityField(value.name),
    displayName: boundedIdentityField(value.display_name),
    alternateDisplayName: boundedIdentityField(value.displayName),
    username: boundedIdentityField(value.username),
    nickname: boundedIdentityField(value.nickname),
    nip05: boundedIdentityField(value.nip05),
  };
  if (Object.values(fields).some((field) => field.invalid)) {
    return null;
  }

  const displayName = fields.displayName.value ?? fields.alternateDisplayName.value;
  const primary = [fields.name.value, displayName, fields.nip05.value]
    .filter((field): field is string => Boolean(field))
    .map(normalizeProfileSearchText);
  const seen = new Set(primary);
  const aliases: string[] = [];
  for (const alias of [
    fields.alternateDisplayName.value,
    fields.username.value,
    fields.nickname.value,
  ]) {
    if (!alias) {
      continue;
    }
    const normalized = normalizeProfileSearchText(alias);
    if (!normalized || seen.has(normalized)) {
      continue;
    }
    seen.add(normalized);
    aliases.push(alias);
  }
  if (aliases.length > PROFILE_SEARCH_IDENTITY_MAX_ALIASES) {
    return null;
  }

  const normalizedBytes = [...primary, ...aliases.map(normalizeProfileSearchText)]
    .reduce((total, field) => total + encoder.encode(field).byteLength, 0);
  if (normalizedBytes > PROFILE_SEARCH_IDENTITY_MAX_NORMALIZED_BYTES) {
    return null;
  }

  return {
    name: fields.name.value,
    displayName,
    nip05: fields.nip05.value,
    aliases,
  };
}

export function normalizeProfileSearchText(value: string | null | undefined): string {
  return `${value ?? ''}`
    .normalize('NFKD')
    .replace(/\p{M}+/gu, '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/gu, ' ');
}

export function profileSearchIdentityAliases(profile: ProfileRecord): string[] {
  return Array.isArray(profile.searchAliases)
    ? boundedProfileSearchAliases(profile.searchAliases)
    : [];
}

export function boundedProfileSearchAliases(values: readonly unknown[]): string[] {
  const aliases: string[] = [];
  for (const value of values.slice(0, PROFILE_SEARCH_IDENTITY_MAX_ALIASES)) {
    const field = boundedIdentityField(value);
    if (!field.invalid && field.value) {
      aliases.push(field.value);
    }
  }
  return aliases;
}

export function profileSearchNip05LocalPart(value: string | null | undefined): string {
  const localPart = `${value ?? ''}`.trim().replace(/^@/, '').split('@', 1)[0] ?? '';
  return localPart === '_' ? '' : normalizeProfileSearchText(localPart);
}
