import {
  nhashDecode,
  nhashEncode,
  type CID,
  type Store,
} from '@hashtree/core';
import type { HashtreeNostrRootEntry } from '@hashtree/nostr-pubsub';
import type { NostrEventReader } from 'nostr-pubsub';
import {
  IRIS_SHADOW_DURABLE_DATASET,
  IrisShadowEventRouter,
  type IrisShadowRootSnapshot,
} from './shadowEventRouter';

export type ShadowReadScope = 'feed' | 'thread' | 'profile';

export type ShadowReadExpectedEvent = {
  id: string;
  pubkey?: string;
  createdAt?: number;
};

export type ShadowReadObservation = {
  scope: ShadowReadScope;
  sharedRoots: readonly CID[];
  personalRoots: readonly CID[];
  expected: readonly ShadowReadExpectedEvent[];
};

export type ShadowReadComparisonResult = {
  scope: ShadowReadScope;
  status: 'match' | 'mismatch' | 'inconclusive';
  expectedCount: number;
  comparedCount: number;
  durableFoundCount: number;
  missingIds: string[];
  durableComplete: boolean;
  eventsTruncated: boolean;
  sharedRootCount: number;
  personalRootCount: number;
  rootsTruncated: boolean;
  relayRouteObserved: boolean;
  durationMs: number;
  finishedAt: number;
  error?: string;
};

export type ShadowReadComparatorOptions = {
  store: Store;
  liveOverlayReader: NostrEventReader;
  storeForRoot?: (root: CID, namespace: 'shared' | 'personal') => Store;
  maxConcurrentPartitions?: number;
  maxExpectedEvents?: number;
  maxRootsPerObservation?: number;
  maxBatchSize?: number;
  maxQueuedObservations?: number;
  maxResults?: number;
  deadlineMs?: number;
  now?: () => number;
  onResult?: (result: ShadowReadComparisonResult) => void;
};

export type ShadowReadComparatorSnapshot = {
  running: boolean;
  stopped: boolean;
  queued: number;
  dropped: number;
  results: ShadowReadComparisonResult[];
};

type FrozenObservation = {
  key: string;
  scope: ShadowReadScope;
  sharedRoots: CID[];
  personalRoots: CID[];
  expected: ShadowReadExpectedEvent[];
  expectedCount: number;
  eventsTruncated: boolean;
  rootsTruncated: boolean;
};

const HEX_64 = /^[0-9a-f]{64}$/;

/** Detached exact-ID parity checks. It never mutates displayed application state. */
export class ShadowReadComparator {
  private readonly storeForRoot;
  private readonly maxExpectedEvents;
  private readonly maxRootsPerObservation;
  private readonly maxBatchSize;
  private readonly maxQueuedObservations;
  private readonly maxResults;
  private readonly deadlineMs;
  private readonly now;
  private readonly onResult;
  private readonly controller = new AbortController();
  private readonly router: IrisShadowEventRouter;
  private readonly queue: FrozenObservation[] = [];
  private readonly results: ShadowReadComparisonResult[] = [];
  private activeRoots: IrisShadowRootSnapshot = { shared: [], personal: [] };
  private activeKey: string | null = null;
  private drainPromise: Promise<void> | null = null;
  private dropped = 0;
  private stopped = false;

  constructor(options: ShadowReadComparatorOptions) {
    this.storeForRoot = options.storeForRoot ?? (() => options.store);
    this.maxExpectedEvents = boundedInteger(options.maxExpectedEvents, 128, 1, 256);
    this.maxRootsPerObservation = boundedInteger(options.maxRootsPerObservation, 32, 1, 256);
    this.maxBatchSize = boundedInteger(options.maxBatchSize, 32, 1, 128);
    this.maxQueuedObservations = boundedInteger(options.maxQueuedObservations, 3, 1, 8);
    this.maxResults = boundedInteger(options.maxResults, 24, 1, 64);
    this.deadlineMs = boundedInteger(options.deadlineMs, 1_500, 50, 10_000);
    this.now = options.now ?? Date.now;
    this.onResult = options.onResult;
    this.router = new IrisShadowEventRouter({
      store: options.store,
      liveOverlayReader: options.liveOverlayReader,
      maxConcurrentPartitions: options.maxConcurrentPartitions ?? 2,
      snapshotRoots: () => this.activeRoots,
    });
  }

  observe(observation: ShadowReadObservation): void {
    if (this.stopped) {return;}
    const frozen = freezeObservation(
      observation,
      this.maxExpectedEvents,
      this.maxRootsPerObservation,
    );
    if (!frozen || frozen.key === this.activeKey || this.queue.some(({ key }) => key === frozen.key)) {
      return;
    }
    for (let index = this.queue.length - 1; index >= 0; index -= 1) {
      if (this.queue[index]?.scope === frozen.scope) {
        this.queue.splice(index, 1);
        this.dropped += 1;
      }
    }
    while (this.queue.length >= this.maxQueuedObservations) {
      this.queue.shift();
      this.dropped += 1;
    }
    this.queue.push(frozen);
    this.ensureDrain();
  }

  async idle(): Promise<void> {
    while (this.drainPromise) {await this.drainPromise;}
  }

  stop(): void {
    if (this.stopped) {return;}
    this.stopped = true;
    this.queue.length = 0;
    this.controller.abort('Shadow read comparison stopped');
  }

  snapshot(): ShadowReadComparatorSnapshot {
    return {
      running: this.activeKey !== null,
      stopped: this.stopped,
      queued: this.queue.length,
      dropped: this.dropped,
      results: this.results.map((result) => ({ ...result, missingIds: [...result.missingIds] })),
    };
  }

  private ensureDrain(): void {
    if (this.drainPromise) {return;}
    this.drainPromise = Promise.resolve()
      .then(async () => {
        while (!this.stopped) {
          const job = this.queue.shift();
          if (!job) {break;}
          this.activeKey = job.key;
          const result = await this.compare(job);
          this.record(result);
          this.activeKey = null;
        }
      })
      .catch(() => undefined)
      .finally(() => {
        this.activeKey = null;
        this.drainPromise = null;
        if (!this.stopped && this.queue.length > 0) {this.ensureDrain();}
      });
  }

  private async compare(job: FrozenObservation): Promise<ShadowReadComparisonResult> {
    const startedAt = this.now();
    const durableIds = new Set<string>();
    let durableComplete = !job.rootsTruncated && !job.eventsTruncated;
    let relayRouteObserved = false;
    let errorMessage: string | undefined;
    const deadline = startedAt + this.deadlineMs;

    try {
      this.activeRoots = {
        shared: this.rootEntries(job.sharedRoots, 'shared'),
        personal: this.rootEntries(job.personalRoots, 'personal'),
      };
      for (let offset = 0; offset < job.expected.length; offset += this.maxBatchSize) {
        const expectedIds = job.expected
          .slice(offset, offset + this.maxBatchSize)
          .map(({ id }) => id);
        const report = await this.router.query(
          expectedIds.map((eventId) => ({ ids: [eventId], limit: 1 })),
          {
            limit: expectedIds.length,
            signal: this.controller.signal,
            deadline,
          },
        );
        const durable = report.datasets.find(({ datasetId }) => (
          datasetId === IRIS_SHADOW_DURABLE_DATASET
        ));
        durableComplete = durableComplete && durable?.complete === true;
        relayRouteObserved = relayRouteObserved || report.attempts.some(({ route }) => (
          route.source.kind === 'relay'
        ));
        for (const item of report.events) {
          if (item.provenance.some(({ datasetId }) => datasetId === IRIS_SHADOW_DURABLE_DATASET)) {
            durableIds.add(item.event.id);
          }
        }
      }
    } catch (error) {
      durableComplete = false;
      errorMessage = error instanceof Error ? error.message : String(error);
    }

    const missingIds = job.expected
      .map(({ id }) => id)
      .filter((eventId) => !durableIds.has(eventId));
    const status = missingIds.length === 0
      ? job.eventsTruncated ? 'inconclusive' : 'match'
      : durableComplete
        ? 'mismatch'
        : 'inconclusive';
    return {
      scope: job.scope,
      status,
      expectedCount: job.expectedCount,
      comparedCount: job.expected.length,
      durableFoundCount: durableIds.size,
      missingIds,
      durableComplete,
      eventsTruncated: job.eventsTruncated,
      sharedRootCount: job.sharedRoots.length,
      personalRootCount: job.personalRoots.length,
      rootsTruncated: job.rootsTruncated,
      relayRouteObserved,
      durationMs: Math.max(0, this.now() - startedAt),
      finishedAt: this.now(),
      ...(errorMessage ? { error: errorMessage } : {}),
    };
  }

  private rootEntries(
    roots: readonly CID[],
    namespace: 'shared' | 'personal',
  ): HashtreeNostrRootEntry[] {
    return roots.map((root) => {
      const identity = nhashEncode(root);
      return {
        partitionId: identity,
        replicaId: identity,
        root,
        store: this.storeForRoot(root, namespace),
      };
    });
  }

  private record(result: ShadowReadComparisonResult): void {
    this.results.push(result);
    while (this.results.length > this.maxResults) {this.results.shift();}
    try {
      this.onResult?.({ ...result, missingIds: [...result.missingIds] });
    } catch {
      // Diagnostics must never affect the application data path.
    }
  }
}

function freezeObservation(
  observation: ShadowReadObservation,
  maxExpectedEvents: number,
  maxRoots: number,
): FrozenObservation | null {
  const shared = canonicalRoots(observation.sharedRoots);
  const sharedIds = new Set(shared.map(nhashEncode));
  const personal = canonicalRoots(observation.personalRoots)
    .filter((root) => !sharedIds.has(nhashEncode(root)));
  const rootsTruncated = shared.length > maxRoots || personal.length > maxRoots;
  const sharedRoots = shared.slice(0, maxRoots);
  const personalRoots = personal.slice(0, maxRoots);
  const allExpected = [...new Map(observation.expected
    .map((item) => ({ ...item, id: item.id.trim().toLowerCase() }))
    .filter(({ id }) => HEX_64.test(id))
    .map((item) => [item.id, item])).values()];
  const eventsTruncated = allExpected.length > maxExpectedEvents;
  const expected = boundedHeadAndTail(allExpected, maxExpectedEvents);
  if (expected.length === 0 || sharedRoots.length + personalRoots.length === 0) {return null;}
  const key = JSON.stringify([
    observation.scope,
    sharedRoots.map(nhashEncode),
    personalRoots.map(nhashEncode),
    expected.map(({ id }) => id),
  ]);
  return {
    key,
    scope: observation.scope,
    sharedRoots,
    personalRoots,
    expected,
    expectedCount: allExpected.length,
    eventsTruncated,
    rootsTruncated,
  };
}

function boundedHeadAndTail<T>(values: readonly T[], limit: number): T[] {
  if (values.length <= limit) {return [...values];}
  const headCount = Math.ceil(limit / 2);
  return [
    ...values.slice(0, headCount),
    ...values.slice(values.length - (limit - headCount)),
  ];
}

function canonicalRoots(roots: readonly CID[]): CID[] {
  const encoded = [...new Set(roots.map((root) => nhashEncode(root)))];
  return encoded.map((root) => nhashDecode(root));
}

function boundedInteger(
  value: number | undefined,
  fallback: number,
  minimum: number,
  maximum: number,
): number {
  if (value === undefined || !Number.isFinite(value)) {return fallback;}
  return Math.min(maximum, Math.max(minimum, Math.floor(value)));
}
