import type { RankedSearchFieldManifest } from '@hashtree/index';

type FieldOptions = Readonly<Record<string, {
  boost?: number;
  lengthNormalization?: number;
}>>;

export function aggregateFields(
  manifests: ReadonlyArray<{ fields: RankedSearchFieldManifest[] }>,
  expectedFields: FieldOptions,
): RankedSearchFieldManifest[] {
  return Object.entries(expectedFields)
    .sort(([left], [right]) => compareStrings(left, right))
    .map(([name, options]) => ({
      name,
      boost: options.boost ?? 1,
      lengthNormalization: options.lengthNormalization ?? 0.75,
      totalLength: sumSafeIntegers(
        manifests.map((manifest) => requiredField(manifest.fields, name).totalLength),
        `${name} total length`,
      ),
      populatedDocumentCount: sumSafeIntegers(
        manifests.map((manifest) => requiredField(manifest.fields, name).populatedDocumentCount),
        `${name} populated count`,
      ),
    }));
}

export function requiredField(
  fields: readonly RankedSearchFieldManifest[],
  name: string,
): RankedSearchFieldManifest {
  const field = fields.find((candidate) => candidate.name === name);
  if (!field) {
    throw new Error(`Missing ranked search field: ${name}`);
  }
  return field;
}

export function hasCompatibleFields(
  fields: readonly RankedSearchFieldManifest[],
  expectedFields: FieldOptions,
): boolean {
  const actual = fields.map((field) => ({
    name: field.name,
    boost: field.boost,
    lengthNormalization: field.lengthNormalization,
  }));
  const expected = Object.entries(expectedFields)
    .map(([name, options]) => ({
      name,
      boost: options.boost ?? 1,
      lengthNormalization: options.lengthNormalization ?? 0.75,
    }))
    .sort((left, right) => compareStrings(left.name, right.name));
  return JSON.stringify(actual) === JSON.stringify(expected);
}

function sumSafeIntegers(values: readonly number[], name: string): number {
  return values.reduce((sum, value) => {
    const result = sum + value;
    if (!Number.isSafeInteger(result) || result < 0) {
      throw new Error(`Invalid ${name}`);
    }
    return result;
  }, 0);
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
