import type { FederatedPostSearchResponse } from './postSearch';

export const POST_SEARCH_DEBOUNCE_MS = 280;
export const POST_SEARCH_INITIAL_LIMIT = 20;
export const POST_SEARCH_MAX_LIMIT = 80;

export type PostSearchRequestState =
  | { status: 'idle'; query: string }
  | { status: 'loading'; query: string; limit: typeof POST_SEARCH_INITIAL_LIMIT }
  | {
      status: 'complete';
      query: string;
      limit: number;
      response: FederatedPostSearchResponse;
      hasMore: boolean;
      /** True while additional publishers may still refine these verified results. */
      settling: boolean;
      loadingMore: boolean;
      loadMoreError: string | null;
    }
  | { status: 'error'; query: string; message: string };

export type PostSearchRunner = (
  query: string,
  limit: number,
  signal: AbortSignal,
  onProgress: (response: FederatedPostSearchResponse) => void,
) => Promise<FederatedPostSearchResponse>;

type CompletePostSearchState = Extract<PostSearchRequestState, { status: 'complete' }>;

/** Debounces post search, expands bounded top-k, and rejects stale completions. */
export class PostSearchRequestController {
  private requestId = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private controller: AbortController | null = null;
  private listener: ((state: PostSearchRequestState) => void) | null = null;
  private state: PostSearchRequestState = { status: 'idle', query: '' };

  constructor(
    private readonly run: PostSearchRunner,
    private readonly debounceMs = POST_SEARCH_DEBOUNCE_MS,
  ) {}

  update(query: string, listener: (state: PostSearchRequestState) => void): void {
    const normalized = query.trim();
    const requestId = ++this.requestId;
    this.clearPending();
    this.listener = listener;

    if (normalized.length < 2) {
      this.emit({ status: 'idle', query: normalized });
      return;
    }

    this.emit({ status: 'loading', query: normalized, limit: POST_SEARCH_INITIAL_LIMIT });
    this.timer = setTimeout(() => {
      this.timer = null;
      this.startRequest(normalized, POST_SEARCH_INITIAL_LIMIT, requestId, null);
    }, this.debounceMs);
  }

  loadMore(): void {
    if (
      this.state.status !== 'complete'
      || this.state.settling
      || this.state.loadingMore
      || !this.state.hasMore
    ) {
      return;
    }
    const previous = this.state;
    const nextLimit = Math.min(POST_SEARCH_MAX_LIMIT, previous.limit * 2);
    if (nextLimit <= previous.limit) {
      return;
    }
    const requestId = ++this.requestId;
    this.clearPending();
    this.emit({ ...previous, loadingMore: true, loadMoreError: null });
    this.startRequest(previous.query, nextLimit, requestId, previous);
  }

  cancel(): void {
    this.requestId += 1;
    this.clearPending();
    this.listener = null;
    this.state = { status: 'idle', query: '' };
  }

  /** Abort background work while retaining a completed, useful result page. */
  pause(): PostSearchRequestState {
    this.requestId += 1;
    this.clearPending();
    this.listener = null;
    this.state = this.state.status === 'complete' && this.state.response.results.length > 0
      ? { ...this.state, settling: false, loadingMore: false }
      : { status: 'idle', query: this.state.query };
    return this.state;
  }

  /** Reattach a mounted view without rerunning the same completed query. */
  resume(query: string, listener: (state: PostSearchRequestState) => void): boolean {
    if (this.state.status !== 'complete' || this.state.query !== query.trim()) {
      return false;
    }
    this.listener = listener;
    listener(this.state);
    return true;
  }

  private startRequest(
    query: string,
    limit: number,
    requestId: number,
    previous: CompletePostSearchState | null,
  ): void {
    const controller = new AbortController();
    this.controller = controller;
    const applyResponse = (rawResponse: FederatedPostSearchResponse, settling: boolean): void => {
      if (requestId !== this.requestId || controller.signal.aborted) {
        return;
      }
      const deduplicated = deduplicatePostSearchResponse(rawResponse, limit);
      const response = previous && (settling || deduplicated.failures.length > 0)
        ? preservePartialPostSearchResults(deduplicated, previous.response, limit)
        : deduplicated;
      this.emit({
        status: 'complete',
        query,
        limit,
        response,
        hasMore: settling
          ? previous?.hasMore ?? false
          : hasMorePostSearchResults(rawResponse, response, limit),
        settling,
        loadingMore: settling && Boolean(previous),
        loadMoreError: null,
      });
    };
    void this.run(query, limit, controller.signal, (response) => applyResponse(response, true))
      .then((rawResponse) => applyResponse(rawResponse, false))
      .catch((error: unknown) => {
        if (requestId !== this.requestId || controller.signal.aborted) {
          return;
        }
        const message = error instanceof Error ? error.message : 'Post search failed';
        this.emit(previous
          ? { ...previous, loadingMore: false, loadMoreError: message }
          : { status: 'error', query, message });
      })
      .finally(() => {
        if (this.controller === controller) {
          this.controller = null;
        }
      });
  }

  private emit(state: PostSearchRequestState): void {
    this.state = state;
    this.listener?.(state);
  }

  private clearPending(): void {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.controller?.abort();
    this.controller = null;
  }
}

function deduplicatePostSearchResponse(
  response: FederatedPostSearchResponse,
  limit: number,
): FederatedPostSearchResponse {
  const seen = new Set<string>();
  return {
    ...response,
    results: response.results.filter((result) => {
      if (seen.has(result.event.id)) {
        return false;
      }
      seen.add(result.event.id);
      return true;
    }).slice(0, limit),
  };
}

function hasMorePostSearchResults(
  rawResponse: FederatedPostSearchResponse,
  response: FederatedPostSearchResponse,
  limit: number,
): boolean {
  if (limit >= POST_SEARCH_MAX_LIMIT || response.results.length === 0) {
    return false;
  }
  return rawResponse.results.length >= limit
    || rawResponse.failures.length > 0
    || rawResponse.truncatedPublishers.length > 0
    || !rawResponse.exhaustive;
}

function preservePartialPostSearchResults(
  response: FederatedPostSearchResponse,
  previous: FederatedPostSearchResponse,
  limit: number,
): FederatedPostSearchResponse {
  return deduplicatePostSearchResponse({
    ...response,
    results: [...response.results, ...previous.results],
  }, limit);
}
