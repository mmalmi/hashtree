import { writable } from 'svelte/store';
import type {
  WalletMintInvoice,
  WalletPaymentQuote,
  WalletPaymentResult,
  WalletPreparedOperation,
  WalletSnapshot,
  WalletTokenResult,
  WalletTokenPreview,
} from './walletTypes';
import { requestWallet, subscribeWalletSnapshots } from './walletWorkerTransport';

export function automaticPaymentFeeLimit(amountBits: number): number {
  return Math.max(3, Math.ceil(amountBits * 0.02));
}

const SNAPSHOT_CACHE_KEY = 'iris-social:wallet-snapshot';
const EMPTY_SNAPSHOT: WalletSnapshot = {
  initialized: false,
  active: false,
  spendableBits: 0,
  reservedBits: 0,
  totalBits: 0,
  balances: [],
  mints: [],
  history: [],
  updatedAt: 0,
};

function readCachedSnapshot(): WalletSnapshot {
  if (typeof localStorage === 'undefined') {return EMPTY_SNAPSHOT;}
  try {
    const value = JSON.parse(localStorage.getItem(SNAPSHOT_CACHE_KEY) ?? 'null') as WalletSnapshot | null;
    return value && typeof value.totalBits === 'number' && Array.isArray(value.mints)
      ? { ...value, active: false }
      : EMPTY_SNAPSHOT;
  } catch {
    return EMPTY_SNAPSHOT;
  }
}

let latestSnapshot = readCachedSnapshot();
const snapshotStore = writable<WalletSnapshot>(latestSnapshot);

function acceptSnapshot(snapshot: WalletSnapshot): WalletSnapshot {
  latestSnapshot = snapshot;
  snapshotStore.set(snapshot);
  try {
    localStorage.setItem(SNAPSHOT_CACHE_KEY, JSON.stringify({ ...snapshot, active: false }));
  } catch {
    // A live IndexedDB snapshot remains authoritative when this optional UI cache is unavailable.
  }
  return snapshot;
}

subscribeWalletSnapshots(acceptSnapshot);

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (event.key === SNAPSHOT_CACHE_KEY && event.newValue) {
      acceptSnapshot(readCachedSnapshot());
    }
  });
}

async function snapshotCommand(command: Parameters<typeof requestWallet>[0]): Promise<WalletSnapshot> {
  return acceptSnapshot(await requestWallet<WalletSnapshot>(command));
}

export const wallet = {
  subscribe: snapshotStore.subscribe,
  canPayFromCache: (amountBits: number) => latestSnapshot.spendableBits >= amountBits,
  initialize: () => snapshotCommand({ type: 'wallet:initialize' }),
  refresh: () => snapshotCommand({ type: 'wallet:getSnapshot' }),
  setActive: (active: boolean) => snapshotCommand({ type: 'wallet:setActive', active }),
  addMint: (mintUrl: string) => snapshotCommand({ type: 'wallet:addMint', mintUrl }),
  setMintTrusted: (mintUrl: string, trusted: boolean) => (
    snapshotCommand({ type: 'wallet:setMintTrusted', mintUrl, trusted })
  ),
  createMintInvoice: (mintUrl: string, amountBits: number) => (
    requestWallet<WalletMintInvoice>({ type: 'wallet:createMintInvoice', mintUrl, amountBits })
  ),
  refreshMint: (operationId: string) => (
    requestWallet<WalletPreparedOperation>({ type: 'wallet:refreshMint', operationId })
  ),
  sendToken: (mintUrl: string, amountBits: number, memo?: string) => (
    requestWallet<WalletTokenResult>({ type: 'wallet:sendToken', mintUrl, amountBits, memo })
  ),
  inspectToken: (token: string) => (
    requestWallet<WalletTokenPreview>({ type: 'wallet:inspectToken', token })
  ),
  receiveToken: (token: string, trustMint = false) => (
    requestWallet<WalletPreparedOperation>({ type: 'wallet:receiveToken', token, trustMint })
  ),
  preparePayment: (
    invoice: string,
    expectedBits: number,
    intentId: string,
    preferredMintUrl?: string,
  ) => requestWallet<WalletPaymentQuote | WalletPaymentResult>({
    type: 'wallet:preparePayment',
    invoice,
    expectedBits,
    intentId,
    preferredMintUrl,
  }),
  executePayment: (intentId: string) => (
    requestWallet<WalletPaymentResult>({ type: 'wallet:executePayment', intentId })
  ),
  payInvoice: (
    invoice: string,
    expectedBits: number,
    intentId: string,
    preferredMintUrl?: string,
  ) => (
    requestWallet<WalletPaymentResult>({
      type: 'wallet:payInvoice',
      invoice,
      expectedBits,
      intentId,
      maxFeeBits: automaticPaymentFeeLimit(expectedBits),
      preferredMintUrl,
    })
  ),
  refreshPayment: (operationId: string) => (
    requestWallet<WalletPaymentResult>({ type: 'wallet:refreshPayment', operationId })
  ),
  cancelOperation: (operationId: string, kind: 'send' | 'receive' | 'melt') => (
    requestWallet({ type: 'wallet:cancelOperation', operationId, kind })
  ),
  exportSeed: () => requestWallet<{ seed: string }>({ type: 'wallet:exportSeed' }),
};
