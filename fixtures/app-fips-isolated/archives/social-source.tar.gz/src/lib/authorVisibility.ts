import type { SocialGraphBadge } from './socialGraphBadgeQuery';

export type AuthorVisibility = 'visible' | 'hidden' | 'pending';

/**
 * iris-client's `shouldHideUser` for one author, as the renderer sees it.
 * The viewer and the people they follow always show; everyone else waits for
 * the worker's graph answer (muted, overmuted, or beyond five follows hides).
 * Without an active viewer there is no graph to judge by, so nothing hides.
 */
export function authorVisibility(
  pubkey: string,
  viewer: string | null,
  follows: ReadonlySet<string>,
  badges: ReadonlyMap<string, SocialGraphBadge>,
): AuthorVisibility {
  if (!viewer || pubkey === viewer || follows.has(pubkey)) {
    return 'visible';
  }
  const badge = badges.get(pubkey);
  return badge ? badge.hidden ? 'hidden' : 'visible' : 'pending';
}
