import type { ReportAppError } from './appError';
import { favoritesFeedAuthors } from './homeFeedTabs';
import type { CID } from '@hashtree/core';
import { accountsStore } from './accounts';
import { getCurrentActiveAccountPubkey, shouldPreferStarterFeed } from './appAccountState';
import type { createFeedHydrators } from './appFeedHydrators';
import type { createAppHomePaginationController } from './appHomePaginationController';
import type { createProfileDataHydrators } from './appProfileDataHydrators';
import type { createProfileHydrators } from './appProfileHydrators';
import type { createAppThreadHydrationController } from './appThreadHydrationController';
import { createPaginationLoaders } from './appPaginationLoaders';
import { createRouteLoader } from './appRouteLoader';
import {
  hasLiveRouteContent,
} from './appViewState';
import {
  routeRenderCacheHasVisibleContent,
  routeRenderCacheMatchesScope,
} from './appRouteState';
import type { AppCombinedState } from './appState';
import type { createViewerHydrators } from './appViewerHydrators';
import { FEED_PAGE_SIZE, THREAD_REPLY_PAGE_SIZE } from './config';
import { filterProfileContentEvents, isProfileContentSection } from './profileContent';
import { getRootNhash, type ProfileSocialSnapshot } from './nostrIndex';
import { routeKey } from './appRoute';
import type { ShadowReadOptions } from './appShadowReadController';
import type { RawEvent } from './nostr';
import { readPostsBefore } from './homeFeedReads';

const NOTIFICATION_PAGE_SIZE = 40;
const PROFILE_SOCIAL_PAGE_SIZE = 40;

type ScrollTracker = {
  get: () => number;
  set: (value: number) => void;
};

type RouteHydrationDeps = {
  state: AppCombinedState;
  feedHydrators: ReturnType<typeof createFeedHydrators>;
  profileDataHydrators: ReturnType<typeof createProfileDataHydrators>;
  profileHydrators: ReturnType<typeof createProfileHydrators>;
  viewerHydrators: ReturnType<typeof createViewerHydrators>;
  homeFeedScroll: ScrollTracker;
  profileFeedScroll: ScrollTracker;
  threadReplyScroll: ScrollTracker;
  applyProfileSocialSnapshot: (social: ProfileSocialSnapshot | null) => void;
  clearProfileViewState: () => void;
  clearRootBoundState: () => void;
  clearThreadViewState: () => void;
  getHomeFeedHasMore: () => boolean;
  getProfileFeedHasMore: () => boolean;
  getProfileSocialHasMore: () => boolean;
  hydrateNextHomeFeedPage: ReturnType<typeof createAppHomePaginationController>['hydrateNextHomeFeedPage'];
  hydrateThread: ReturnType<typeof createAppThreadHydrationController>['hydrateThread'];
  hydrateThreadRepliesPage: ReturnType<typeof createAppThreadHydrationController>['hydrateThreadRepliesPage'];
  reportError: ReportAppError;
  runProfileHydrationWithShadow: (
    root: CID,
    token: number,
    operation: () => Promise<void>,
  ) => Promise<void>;
  scheduleCurrentFeedShadowComparison: (
    root: CID,
    token: number,
  ) => void;
  scheduleShadowReadComparison: (options: ShadowReadOptions) => void;
  updateProfileNotesLoading: (loading: boolean) => void;
};

export function createAppRouteHydrationControllers(deps: RouteHydrationDeps) {
  const { state } = deps;

  function shouldUseStarterFeed(): boolean {
    const accounts = accountsStore.getState();
    const activePubkey = getCurrentActiveAccountPubkey(
      accounts.activeAccountPubkey,
      accounts.accounts,
    );
    const activeAccount = accounts.accounts.find((account) => account.pubkey === activePubkey) ?? null;
    return shouldPreferStarterFeed(activeAccount, accounts.accounts.length);
  }

  async function runInitialHomeFeedLoad(operation: () => Promise<void>): Promise<void> {
    const generation = ++state.homeFeedInitialLoadGeneration;
    state.homeFeedInitialLoadPending = true;
    try {
      await operation();
    } finally {
      if (generation === state.homeFeedInitialLoadGeneration) {
        state.homeFeedInitialLoadPending = false;
        queueMicrotask(() => {
          void paginationLoaders.resumeQueuedHomeFeedLoad();
        });
      }
    }
  }

  const routeLoader = createRouteLoader({
    getRoute: () => state.route,
    getRoot: () => state.root,
    getLoadToken: () => state.loadToken,
    getActivePubkey: () => {
      const accounts = accountsStore.getState();
      return getCurrentActiveAccountPubkey(accounts.activeAccountPubkey, accounts.accounts);
    },
    hasVisibleContent: (route) => {
      const candidate = state.routeRenderCache.get(routeKey(route));
      const cached = candidate && routeRenderCacheMatchesScope(candidate, {
        viewerPubkey: state.activeAccount?.pubkey ?? null,
        homeFeedSourcePubkey: state.activeFeedSource?.pubkey ?? null,
      }) ? candidate : null;
      return hasLiveRouteContent(route, {
        feed: state.feed,
        profilePage: state.profilePage,
        threadPage: state.threadPage,
        notificationsCount: state.visibleNotifications.length,
        homeNoteCount: state.homeNotes.length,
      }) || Boolean(cached && routeRenderCacheHasVisibleContent(cached));
    },
    clearRootBoundState: deps.clearRootBoundState,
    clearProfileViewState: deps.clearProfileViewState,
    clearThreadViewState: deps.clearThreadViewState,
    setLoading: (loading) => {
      state.loading = loading;
    },
    setPageError: (message) => {
      state.pageError = message;
    },
    reportError: deps.reportError,
    setFeed: (feed) => {
      state.feed = feed;
      if (!feed) {state.feedRequiresRefresh = false;}
    },
    getLoadedProfilePubkey: () => state.loadedProfilePubkey,
    setLoadedProfilePubkey: (pubkey) => {
      state.loadedProfilePubkey = pubkey;
    },
    getAccountProfile: (pubkey) => state.accountProfiles.get(pubkey) ?? null,
    getProfilePage: () => state.profilePage,
    setProfilePage: (page) => {
      state.profilePage = page;
    },
    setProfileSocial: deps.applyProfileSocialSnapshot,
    setProfileSocialLoading: (loading) => {
      state.profileSocialLoading = loading;
    },
    setProfilePersonalRoot: (root) => {
      state.profilePersonalRoot = root;
    },
    setProfileNotesLoading: deps.updateProfileNotesLoading,
    getProfileNoteFetchLimit: () => state.profileNoteFetchLimit,
    setNoteEngagementsEmpty: () => {
      state.noteEngagements = new Map();
    },
    hydrateProfileRecordProgressively: (root, pubkey, token) => (
      deps.runProfileHydrationWithShadow(root, token, () => (
        deps.profileDataHydrators.hydrateProfileRecordProgressively(
          root,
          pubkey,
          token,
          () => state.route.kind === 'profile' && state.route.pubkey === pubkey,
        )
      ))
    ),
    hydrateProfileNotesPage: (root, pubkey, token, options) => (
      deps.runProfileHydrationWithShadow(root, token, () => (
        deps.profileDataHydrators.hydrateProfileNotesPage(root, pubkey, token, options)
      ))
    ),
    hydrateProfileNotesProgressively: (root, pubkey, token, options) => (
      deps.runProfileHydrationWithShadow(root, token, () => (
        deps.profileDataHydrators.hydrateProfileNotesProgressively(root, pubkey, token, options)
      ))
    ),
    hydrateProfileLikes: (root, pubkey, token, options) => (
      deps.runProfileHydrationWithShadow(root, token, () => (
        deps.profileDataHydrators.hydrateProfileLikes(root, pubkey, token, options)
      ))
    ),
    hydrateProfileFromPersonalIndex: (root, pubkey, token) => (
      root
        ? deps.runProfileHydrationWithShadow(root, token, () => (
          deps.profileDataHydrators.hydrateProfileFromPersonalIndex(root, pubkey, token)
        ))
        : deps.profileDataHydrators.hydrateProfileFromPersonalIndex(null, pubkey, token)
    ),
    scheduleProfileSocialHydration: (root, pubkey, token, options) => (
      deps.profileHydrators.scheduleProfileSocialHydration(root, pubkey, token, options)
    ),
    scheduleEmptyProfileRetry: (root, pubkey, token) => (
      deps.profileHydrators.scheduleEmptyProfileRetry(root, pubkey, token)
    ),
    hydrateThread: deps.hydrateThread,
    hydrateNotifications: (root, pubkey, token) => (
      deps.viewerHydrators.hydrateNotifications(root, pubkey, token, {
        limit: NOTIFICATION_PAGE_SIZE,
      })
    ),
    hydrateHomeFeed: async (root, ownerPubkey, activePubkey, token) => {
      if (
        state.homeNotes.length > 0
        && state.feed
        && !state.feedRequiresRefresh
        && state.feed.rootNhash === getRootNhash(root)
        && state.feed.feedOwnerPubkey === ownerPubkey
      ) {
        state.loading = false;
        return;
      }
      await runInitialHomeFeedLoad(() => deps.feedHydrators.hydrateHomeFeedProgressively(
        root,
        ownerPubkey,
        activePubkey,
        token,
        shouldUseStarterFeed(),
        state.route.kind === 'home' && state.route.tab === 'favorites'
          ? favoritesFeedAuthors(activePubkey, state.route.feedId, state.favoritePubkeys)
          : undefined,
      ));
      deps.scheduleCurrentFeedShadowComparison(root, token);
    },
    hydratePopularFeed: (root, token) => runInitialHomeFeedLoad(() => deps.feedHydrators.hydratePopularFeed(root, token)),
    hydrateForYouFeed: (root, pubkey, token) => runInitialHomeFeedLoad(() => (
      deps.feedHydrators.hydrateForYouFeedProgressively(root, pubkey, token)
    )).then(() => deps.scheduleCurrentFeedShadowComparison(root, token)),
    hydrateViewerPersonalRoot: deps.viewerHydrators.hydrateViewerPersonalRoot,
    hydrateViewerGraphFollows: deps.viewerHydrators.hydrateViewerGraphFollows,
    hydrateViewerFollows: deps.viewerHydrators.hydrateViewerFollows,
    hydrateViewerMuteList: deps.viewerHydrators.hydrateViewerMuteList,
    hydrateViewerRelayMuteList: deps.viewerHydrators.hydrateViewerRelayMuteList,
    hydrateViewerProfile: deps.viewerHydrators.hydrateViewerProfile,
    setViewerProfileLoading: (loading) => {
      state.viewerProfileLoading = loading;
    },
    resetViewerRouteState: () => {
      state.viewerPersonalRoot = null;
      state.viewerContactsEvent = null;
      state.viewerContactsProjectionAuthoritative = false;
      state.viewerFollows = new Set();
      state.indexedViewerMuteListEvent = null;
      state.hydratedViewerProfileEvent = null;
      state.viewerProfileLoading = false;
    },
    getActiveFeedSourcePubkey: () => state.activeFeedSource?.pubkey ?? null,
  });

  /** Older posts by followed authors from every source, when ranking has no cursor. */
  async function appendForYouOlderPage(pageSize: number): Promise<number> {
    const feed = state.feed;
    if (!feed) {return 0;}
    const authors = state.viewerFollows.size > 0
      ? [...state.viewerFollows]
      : [...new Set(feed.notes.map((event) => event.pubkey))];
    if (authors.length === 0) {return 0;}
    const oldest = Math.min(...feed.notes.map((event) => event.created_at));
    const posts = await readPostsBefore(authors, Number.isFinite(oldest) ? oldest : Math.floor(Date.now() / 1_000),
      AbortSignal.timeout(8_000)).catch(() => [] as RawEvent[]);
    const current = state.feed;
    if (!current || current.feedOwnerPubkey !== feed.feedOwnerPubkey) {return 0;}
    const known = new Set(current.notes.map((event) => event.id));
    const fresh = posts.filter((event) => !known.has(event.id))
      .sort((left, right) => right.created_at - left.created_at)
      .slice(0, Math.max(pageSize, 1) * 2);
    if (fresh.length === 0) {return 0;}
    state.feed = { ...current, notes: [...current.notes, ...fresh] };
    return fresh.length;
  }

  const paginationLoaders = createPaginationLoaders({
    getRoute: () => state.route,
    getRoot: () => state.root,
    getLoading: () => state.loading,
    getHomeFeedInitialLoadPending: () => state.homeFeedInitialLoadPending,
    getFeed: () => state.feed,
    getProfilePage: () => state.profilePage,
    getProfileSocial: () => state.profileSocial,
    getHomeFeedLoadPending: () => state.homeFeedLoadPending,
    setHomeFeedLoadPending: (pending) => {
      state.homeFeedLoadPending = pending;
    },
    getHomeFeedHasMore: deps.getHomeFeedHasMore,
    getHomeFeedNoteCount: () => state.allHomeNotes.length,
    getFeedLimit: () => state.feedLimit,
    setFeedLimit: (limit) => {
      state.feedLimit = limit;
    },
    getHomeFeedScrollOffset: deps.homeFeedScroll.get,
    setHomeFeedLastLoadScrollOffset: (offset) => {
      state.homeFeedLastLoadScrollOffset = offset;
    },
    setHomeFeedFetchLimit: (limit) => {
      state.homeFeedFetchLimit = limit;
    },
    hydrateNextHomeFeedPage: async (root, route, pageSize, token) => {
      if (route.kind === 'home' && route.tab === 'for-you' && state.feed && !state.feed.continuation) {
        // A restored or preview For You page has no ranking cursor. Rank now,
        // keeping painted cards in place, so Load More reveals the next page.
        state.feedRequiresRefresh = true;
        const accounts = accountsStore.getState();
        const viewer = getCurrentActiveAccountPubkey(accounts.activeAccountPubkey, accounts.accounts) ?? '';
        await deps.feedHydrators.hydrateForYouFeedProgressively(root, viewer, token).catch(() => undefined);
        if (state.feed && !state.feed.continuation && token === state.loadToken) {
          // Ranking produced no cursor (offline archive, failed stream). Like Iris
          // Client, page older posts by followed authors from relays instead.
          const appended = await appendForYouOlderPage(pageSize);
          if (state.feed && !state.feed.continuation && appended === 0) {
            state.feed = { ...state.feed, lazyRankAttempted: true };
          }
        }
        return;
      }
      await deps.hydrateNextHomeFeedPage(root, route, pageSize, token);
      deps.scheduleCurrentFeedShadowComparison(root, token);
    },
    getProfileFeedLoadPending: () => state.profileFeedLoadPending,
    getProfileNotesLoading: () => state.profileNotesLoading,
    setProfileFeedLoadPending: (pending) => {
      state.profileFeedLoadPending = pending;
    },
    getProfileFeedHasMore: deps.getProfileFeedHasMore,
    getProfileVisibleNoteCount: () => state.allProfileSectionNotes.length,
    getProfileNoteLimit: () => state.profileNoteLimit,
    setProfileNoteLimit: (limit) => {
      state.profileNoteLimit = limit;
    },
    getProfileFeedScrollOffset: deps.profileFeedScroll.get,
    setProfileFeedLastLoadScrollOffset: (offset) => {
      state.profileFeedLastLoadScrollOffset = offset;
    },
    setProfileNotesLoading: deps.updateProfileNotesLoading,
    setProfileNoteFetchLimit: (limit) => {
      state.profileNoteFetchLimit = limit;
    },
    getLoadToken: () => state.loadToken,
    hydrateNextProfileNotesPage: (root, pubkey, token, options) => (
      deps.runProfileHydrationWithShadow(root, token, () => (
        deps.profileDataHydrators.hydrateNextProfileNotesPage(root, pubkey, token, {
          ...options,
          matchesVisibleSection: (event) => {
            const section = state.route.kind === 'profile' ? state.route.section : 'posts';
            return isProfileContentSection(section)
              && filterProfileContentEvents([event], section).length > 0;
          },
        })
      ))
    ),
    hydrateProfileLikes: (root, pubkey, token, options) => deps.runProfileHydrationWithShadow(
      root,
      token,
      () => deps.profileDataHydrators.hydrateProfileLikes(root, pubkey, token, options),
    ),
    getProfileSocialLoadPending: () => state.profileSocialLoadPending,
    setProfileSocialLoadPending: (pending) => {
      state.profileSocialLoadPending = pending;
    },
    getProfileSocialHasMore: deps.getProfileSocialHasMore,
    getProfileSocialVisibleLimit: () => state.profileSocialVisibleLimit,
    setProfileSocialVisibleLimit: (limit) => {
      state.profileSocialVisibleLimit = limit;
    },
    getProfileSocialScrollOffset: () => state.profileSocialScrollOffset,
    setProfileSocialLastLoadScrollOffset: (offset) => {
      state.profileSocialLastLoadScrollOffset = offset;
    },
    setProfileSocialLoading: (loading) => {
      state.profileSocialLoading = loading;
    },
    setProfileSocialFollowerFetchLimit: (limit) => {
      state.profileSocialFollowerFetchLimit = limit;
    },
    hydrateProfileSocial: deps.profileHydrators.hydrateProfileSocial,
    hydrateProfileListProfiles: deps.profileHydrators.hydrateProfileListProfiles,
    getThreadPage: () => state.threadPage,
    getThreadRepliesLoadPending: () => state.threadRepliesLoadPending,
    setThreadRepliesLoadPending: (pending) => {
      state.threadRepliesLoadPending = pending;
    },
    getThreadRepliesHasMore: () => state.threadRepliesHasMore,
    getThreadReplyFetchLimit: () => state.threadReplyFetchLimit,
    setThreadReplyFetchLimit: (limit) => {
      state.threadReplyFetchLimit = limit;
    },
    getThreadReplyScrollOffset: deps.threadReplyScroll.get,
    setThreadReplyLastLoadScrollOffset: (offset) => {
      state.threadReplyLastLoadScrollOffset = offset;
    },
    hydrateThreadRepliesPage: async (root, ref, limit, token) => {
      await deps.hydrateThreadRepliesPage(root, ref, limit, token);
      if (token !== state.loadToken || !state.threadPage?.note) {return;}
      deps.scheduleShadowReadComparison({
        scope: 'thread',
        sharedRoot: root,
        roots: state.threadRoots,
        events: [state.threadPage.note, ...state.threadPage.context, ...state.threadReplies],
      });
    },
    feedPageSize: FEED_PAGE_SIZE,
    profileSocialPageSize: PROFILE_SOCIAL_PAGE_SIZE,
    threadReplyPageSize: THREAD_REPLY_PAGE_SIZE,
  });

  return { paginationLoaders, routeLoader };
}
