import { parseProfileEvent, type ProfileRecord, type RawEvent } from './nostr';

/** Project replaceable kind-0 events into one newest profile record per author. */
export function profileMapFromMetadataEvents(
  events: readonly RawEvent[],
): Map<string, ProfileRecord> {
  const winners = new Map<string, RawEvent>();
  for (const event of events) {
    if (event.kind !== 0) {
      continue;
    }
    const current = winners.get(event.pubkey);
    if (
      !current
      || event.created_at > current.created_at
      || (event.created_at === current.created_at && event.id < current.id)
    ) {
      winners.set(event.pubkey, event);
    }
  }

  const profiles = new Map<string, ProfileRecord>();
  for (const event of winners.values()) {
    const profile = parseProfileEvent(event);
    if (profile) {
      profiles.set(profile.pubkey, profile);
    }
  }
  return profiles;
}

export function overlayProfileRecord(
  primaryProfile: ProfileRecord | null | undefined,
  fallbackProfile: ProfileRecord | null | undefined,
): ProfileRecord | null {
  if (!primaryProfile && !fallbackProfile) {
    return null;
  }
  if (primaryProfile?.eventId || fallbackProfile?.eventId) {
    return preferNewerProfileRecord(primaryProfile, fallbackProfile);
  }

  const primary = primaryProfile ?? fallbackProfile!;
  const fallback = fallbackProfile ?? primaryProfile!;

  return {
    pubkey: primary.pubkey,
    npub: primary.npub || fallback.npub,
    eventId: primary.eventId ?? fallback.eventId,
    createdAt: Math.max(primary.createdAt ?? 0, fallback.createdAt ?? 0) || null,
    name: primary.name ?? fallback.name,
    displayName: primary.displayName ?? fallback.displayName,
    about: primary.about ?? fallback.about,
    picture: primary.picture ?? fallback.picture,
    banner: primary.banner ?? fallback.banner,
    nip05: primary.nip05 ?? fallback.nip05,
    website: primary.website ?? fallback.website,
    lud16: primary.lud16 ?? fallback.lud16,
    lud06: primary.lud06 ?? fallback.lud06,
    searchAliases: primary.searchAliases ?? fallback.searchAliases,
    socialDistance: null,
    followedByFriends: null,
  };
}

function withoutStaleSocialMetrics(profile: ProfileRecord): ProfileRecord {
  if ((profile.socialDistance ?? null) === null && (profile.followedByFriends ?? null) === null) {
    return profile;
  }
  return {
    ...profile,
    socialDistance: null,
    followedByFriends: null,
  };
}

export function preferNewerProfileRecord(
  currentProfile: ProfileRecord | null | undefined,
  candidateProfile: ProfileRecord | null | undefined,
): ProfileRecord | null {
  if (!candidateProfile) {
    return currentProfile ? withoutStaleSocialMetrics(currentProfile) : null;
  }

  if (!currentProfile) {
    return withoutStaleSocialMetrics(candidateProfile);
  }

  const currentCreatedAt = currentProfile.createdAt ?? -1;
  const candidateCreatedAt = candidateProfile.createdAt ?? -1;
  const candidateWins = Boolean(currentProfile.eventId) !== Boolean(candidateProfile.eventId)
    ? Boolean(candidateProfile.eventId)
    : candidateCreatedAt > currentCreatedAt
    || (candidateCreatedAt === currentCreatedAt
      && (!currentProfile.eventId
        || (candidateProfile.eventId !== null && candidateProfile.eventId < currentProfile.eventId)));
  const winner = candidateWins ? candidateProfile : currentProfile;
  const fallback = candidateWins ? currentProfile : candidateProfile;
  // A signed kind-0 is a complete replacement. Null fields can mean removal.
  return winner.eventId
    ? withoutStaleSocialMetrics(winner)
    : overlayProfileRecord(winner, fallback);
}

export function mergeProfileMaps(...maps: Array<Map<string, ProfileRecord>>): Map<string, ProfileRecord> {
  const merged = new Map<string, ProfileRecord>();
  for (const map of maps) {
    for (const [pubkey, profile] of map) {
      const mergedProfile = preferNewerProfileRecord(merged.get(pubkey) ?? null, profile);
      if (mergedProfile) {
        merged.set(pubkey, mergedProfile);
      }
    }
  }
  return merged;
}

export function profileRecordsEqual(
  left: ProfileRecord | null | undefined,
  right: ProfileRecord | null | undefined,
): boolean {
  if (left === right) {
    return true;
  }

  if (!left || !right) {
    return false;
  }

  return (
    left.pubkey === right.pubkey
    && left.npub === right.npub
    && (left.eventId ?? null) === (right.eventId ?? null)
    && (left.createdAt ?? null) === (right.createdAt ?? null)
    && (left.name ?? null) === (right.name ?? null)
    && (left.displayName ?? null) === (right.displayName ?? null)
    && (left.about ?? null) === (right.about ?? null)
    && (left.picture ?? null) === (right.picture ?? null)
    && (left.banner ?? null) === (right.banner ?? null)
    && (left.nip05 ?? null) === (right.nip05 ?? null)
    && (left.website ?? null) === (right.website ?? null)
    && (left.lud16 ?? null) === (right.lud16 ?? null)
    && (left.lud06 ?? null) === (right.lud06 ?? null)
    && arrayEqual(left.searchAliases, right.searchAliases)
    && (left.socialDistance ?? null) === (right.socialDistance ?? null)
    && (left.followedByFriends ?? null) === (right.followedByFriends ?? null)
  );
}

function arrayEqual(left: readonly string[] | undefined, right: readonly string[] | undefined): boolean {
  if (left === right) {
    return true;
  }
  const leftValues = left ?? [];
  const rightValues = right ?? [];
  if (leftValues.length !== rightValues.length) {
    return false;
  }
  return leftValues.every((value, index) => value === rightValues[index]);
}
