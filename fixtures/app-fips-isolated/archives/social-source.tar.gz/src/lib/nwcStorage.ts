// Private local wallet state, separate from settings, social caches and published indexes.
const DATABASE = 'iris-social-nwc';
const STORE = 'private';
export type SavedNwcConnection = { uri: string; name: string; enabled: boolean };

async function openDatabase(): Promise<IDBDatabase> {
  return await new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error('Could not open wallet connection storage.'));
  });
}

async function transaction<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const database = await openDatabase();
  try {
    return await new Promise<T>((resolve, reject) => {
      const transaction = database.transaction(STORE, mode);
      const request = run(transaction.objectStore(STORE));
      transaction.oncomplete = () => resolve(request.result);
      transaction.onerror = () => reject(new Error('Could not save wallet state.'));
      transaction.onabort = () => reject(new Error('Could not save wallet state.'));
    });
  } finally {database.close();}
}

export async function readNwcConnection(): Promise<SavedNwcConnection | null> {
  return await transaction<SavedNwcConnection | undefined>('readonly', (store) => store.get('connection')) ?? null;
}
export async function saveNwcConnection(connection: SavedNwcConnection): Promise<void> {
  await transaction('readwrite', (store) => store.put(connection, 'connection'));
}
export async function removeNwcConnection(): Promise<void> {
  await transaction('readwrite', (store) => store.delete('connection'));
}
export async function claimNwcPayment(key: string): Promise<void> {
  try {
    await transaction('readwrite', (store) => store.add({ state: 'attempted', createdAt: Date.now() }, `payment:${key}`));
  } catch {
    throw new Error('This invoice may already have been paid, or its payment could not be recorded. Check your wallet before continuing.');
  }
}
export async function recordNwcPayment(key: string): Promise<void> {
  await transaction('readwrite', (store) => store.put({ state: 'paid', updatedAt: Date.now() }, `payment:${key}`));
}
