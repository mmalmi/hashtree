import {
  normalizePersistedEventsAsync,
  normalizePersistedEvent,
  normalizePersistedState,
  normalizePersistedStateAsync,
  PERSISTED_DATA_PLANE_STATE_VERSION,
  type PersistedEventVerificationOptions,
  type PersistedSocialDataPlaneState,
  type RestoredSocialDataPlaneState,
} from './socialDataPlaneSupport';
import type { RawEvent } from './nostr';
import { SocialPersistenceError } from './socialDataPlaneTypes';

export const SOCIAL_OVERLAY_STORAGE_KEY = 'iris-social:social-overlay:v1';

const DEFAULT_MAX_WORK_MS = 8;
const DEFAULT_MAX_WORK_ITEMS = 64;
const BACKGROUND_WORK_TIMEOUT_MS = 1_000;

export type SocialOverlayPersistenceContext = {
  /** Run one bounded preparation unit, yielding to input/paint between slices. */
  run<T>(work: () => T): Promise<T>;
  /** False once a newer persistence request or an explicit flush supersedes this run. */
  isCurrent(): boolean;
};

type CancelScheduledWork = () => void;

export type SocialOverlayPersistenceOptions = {
  storage: Storage | null;
  debounceMs: number;
  getState: () => PersistedSocialDataPlaneState;
  prepareState?: (
    context: SocialOverlayPersistenceContext,
  ) => Promise<PersistedSocialDataPlaneState | null>;
  onError: (error: SocialPersistenceError) => void;
  onSuccess: () => void;
  maxWorkMs?: number;
  maxWorkItems?: number;
  now?: () => number;
  yieldControl?: () => Promise<void>;
  scheduleBackgroundWork?: (work: () => void) => CancelScheduledWork;
};

function defaultNow(): number {
  return typeof performance === 'undefined' ? Date.now() : performance.now();
}

function defaultYieldControl(): Promise<void> {
  const scheduler = (
    globalThis as typeof globalThis & {
      scheduler?: { yield?: () => Promise<void> };
    }
  ).scheduler;
  if (typeof scheduler?.yield === 'function') {
    return scheduler.yield();
  }
  if (typeof MessageChannel === 'function') {
    return new Promise<void>((resolve) => {
      const channel = new MessageChannel();
      channel.port1.onmessage = () => {
        channel.port1.close();
        channel.port2.close();
        resolve();
      };
      channel.port2.postMessage(undefined);
    });
  }
  return new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });
}

function defaultScheduleBackgroundWork(work: () => void): CancelScheduledWork {
  if (
    typeof window !== 'undefined'
    && typeof window.requestIdleCallback === 'function'
  ) {
    const idleId = window.requestIdleCallback(work, {
      timeout: BACKGROUND_WORK_TIMEOUT_MS,
    });
    return () => window.cancelIdleCallback(idleId);
  }
  const timer = setTimeout(work, 0);
  return () => clearTimeout(timer);
}

class PersistenceWorkBudget implements SocialOverlayPersistenceContext {
  private readonly maxWorkMs: number;
  private readonly maxWorkItems: number;
  private readonly now: () => number;
  private readonly yieldControl: () => Promise<void>;
  private readonly current: () => boolean;
  private sliceStartedAt: number;
  private sliceItems = 0;

  constructor(options: {
    maxWorkMs: number;
    maxWorkItems: number;
    now: () => number;
    yieldControl: () => Promise<void>;
    current: () => boolean;
  }) {
    this.maxWorkMs = options.maxWorkMs;
    this.maxWorkItems = options.maxWorkItems;
    this.now = options.now;
    this.yieldControl = options.yieldControl;
    this.current = options.current;
    this.sliceStartedAt = this.now();
  }

  isCurrent(): boolean {
    return this.current();
  }

  async run<T>(work: () => T): Promise<T> {
    if (
      this.sliceItems >= this.maxWorkItems
      || this.now() - this.sliceStartedAt >= this.maxWorkMs
    ) {
      await this.yieldControl();
      this.sliceStartedAt = this.now();
      this.sliceItems = 0;
    }
    this.sliceItems += 1;
    return work();
  }
}

/** Persists the bounded display overlay; the relay outbox has its own journal. */
export class SocialOverlayPersistence {
  private readonly options: SocialOverlayPersistenceOptions;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private cancelBackgroundWork: CancelScheduledWork | null = null;
  private running = false;
  private requestedRevision = 0;
  private persistedRevision = 0;
  private lifecycle = 0;
  private lastReadRaw: string | null | undefined;
  private lastReadParsed: unknown | null = null;

  constructor(options: SocialOverlayPersistenceOptions) {
    this.options = options;
    if (
      options.maxWorkMs !== undefined
      && (!Number.isFinite(options.maxWorkMs) || options.maxWorkMs <= 0)
    ) {
      throw new RangeError('Overlay persistence work budget must be positive and finite');
    }
    if (
      options.maxWorkItems !== undefined
      && (!Number.isSafeInteger(options.maxWorkItems) || options.maxWorkItems <= 0)
    ) {
      throw new RangeError('Overlay persistence item budget must be a positive integer');
    }
  }

  read(): RestoredSocialDataPlaneState | null {
    const parsed = this.readParsed();
    return parsed === null ? null : normalizePersistedState(parsed);
  }

  async readAsync(
    options: PersistedEventVerificationOptions = {},
  ): Promise<RestoredSocialDataPlaneState | null> {
    const parsed = this.readParsed();
    return parsed === null ? null : await normalizePersistedStateAsync(parsed, options);
  }

  readMetadataEvents(pubkeys: ReadonlySet<string>): RawEvent[] {
    const parsed = this.readParsed();
    if (!parsed || typeof parsed !== 'object') {
      return [];
    }
    const candidate = parsed as { overlayEvents?: unknown; schemaVersion?: unknown };
    if (
      (
        candidate.schemaVersion !== 1
        && candidate.schemaVersion !== PERSISTED_DATA_PLANE_STATE_VERSION
      )
      || !Array.isArray(candidate.overlayEvents)
    ) {
      return [];
    }
    return candidate.overlayEvents
      .filter((value) => {
        if (!value || typeof value !== 'object') {
          return false;
        }
        const event = value as { kind?: unknown; pubkey?: unknown };
        return event.kind === 0
          && typeof event.pubkey === 'string'
          && pubkeys.has(event.pubkey);
      })
      .map(normalizePersistedEvent)
      .filter((event): event is RawEvent => Boolean(event));
  }

  async readMetadataEventsAsync(
    pubkeys: ReadonlySet<string>,
    options: PersistedEventVerificationOptions = {},
  ): Promise<RawEvent[]> {
    const parsed = this.readParsed();
    if (!parsed || typeof parsed !== 'object') {
      return [];
    }
    const candidate = parsed as { overlayEvents?: unknown; schemaVersion?: unknown };
    if (
      (
        candidate.schemaVersion !== 1
        && candidate.schemaVersion !== PERSISTED_DATA_PLANE_STATE_VERSION
      )
      || !Array.isArray(candidate.overlayEvents)
    ) {
      return [];
    }
    const metadataCandidates = candidate.overlayEvents.filter((value) => {
      if (!value || typeof value !== 'object') {
        return false;
      }
      const event = value as { kind?: unknown; pubkey?: unknown };
      return event.kind === 0
        && typeof event.pubkey === 'string'
        && pubkeys.has(event.pubkey);
    });
    return await normalizePersistedEventsAsync(metadataCandidates, options);
  }

  private readParsed(): unknown | null {
    const storage = this.options.storage;
    if (!storage) {
      return null;
    }
    try {
      const raw = storage.getItem(SOCIAL_OVERLAY_STORAGE_KEY);
      if (raw === this.lastReadRaw) {
        return this.lastReadParsed;
      }
      const parsed = raw ? JSON.parse(raw) : null;
      this.lastReadRaw = raw;
      this.lastReadParsed = parsed;
      return parsed;
    } catch (cause) {
      this.options.onError(new SocialPersistenceError(
        'Could not read saved social events from this device.',
        cause,
      ));
      return null;
    }
  }

  schedule(): void {
    if (!this.options.storage) {
      return;
    }
    this.requestedRevision += 1;
    this.armDebounce();
  }

  private armDebounce(): void {
    if (this.timer || this.cancelBackgroundWork || this.running) {
      return;
    }
    this.timer = setTimeout(() => {
      this.timer = null;
      const scheduleBackgroundWork = this.options.scheduleBackgroundWork
        ?? defaultScheduleBackgroundWork;
      this.cancelBackgroundWork = scheduleBackgroundWork(() => {
        this.cancelBackgroundWork = null;
        void this.persistCooperatively();
      });
    }, this.options.debounceMs);
  }

  flush(): boolean {
    if (!this.options.storage) {
      return false;
    }
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.cancelBackgroundWork?.();
    this.cancelBackgroundWork = null;
    this.lifecycle += 1;
    this.requestedRevision += 1;
    const revision = this.requestedRevision;
    const persisted = this.persistSynchronously();
    // A lifecycle flush is the final attempt for all work requested so far.
    // Do not let an invalidated async run re-arm itself after shutdown.
    this.persistedRevision = revision;
    return persisted;
  }

  /**
   * Compatibility entry point for existing mutation callers. Overlay storage
   * is only a display cache, so this must never export or serialize inline.
   */
  persistBestEffort(): boolean {
    if (!this.options.storage) {
      return false;
    }
    this.schedule();
    return true;
  }

  private async persistCooperatively(): Promise<void> {
    const storage = this.options.storage;
    if (!storage || this.running) {
      return;
    }
    this.running = true;
    const revision = this.requestedRevision;
    const lifecycle = this.lifecycle;
    const isCurrent = () => (
      revision === this.requestedRevision
      && lifecycle === this.lifecycle
    );
    const context = new PersistenceWorkBudget({
      maxWorkMs: this.options.maxWorkMs ?? DEFAULT_MAX_WORK_MS,
      maxWorkItems: this.options.maxWorkItems ?? DEFAULT_MAX_WORK_ITEMS,
      now: this.options.now ?? defaultNow,
      yieldControl: this.options.yieldControl ?? defaultYieldControl,
      current: isCurrent,
    });

    try {
      const state = this.options.prepareState
        ? await this.options.prepareState(context)
        : await context.run(this.options.getState);
      if (!state || !isCurrent()) {
        return;
      }
      if (state.overlayEvents.length === 0) {
        storage.removeItem(SOCIAL_OVERLAY_STORAGE_KEY);
      } else {
        const serialized = await this.serializeCooperatively(state, context);
        if (!serialized || !isCurrent()) {
          return;
        }
        storage.setItem(SOCIAL_OVERLAY_STORAGE_KEY, serialized);
      }
      this.persistedRevision = revision;
      this.options.onSuccess();
    } catch (cause) {
      if (isCurrent()) {
        this.reportWriteError(cause);
      }
    } finally {
      this.running = false;
      if (this.persistedRevision < this.requestedRevision) {
        this.armDebounce();
      }
    }
  }

  private async serializeCooperatively(
    state: PersistedSocialDataPlaneState,
    context: SocialOverlayPersistenceContext,
  ): Promise<string | null> {
    const chunks = [
      `{"schemaVersion":${state.schemaVersion},"overlayEvents":[`,
    ];
    for (let index = 0; index < state.overlayEvents.length; index += 1) {
      if (!context.isCurrent()) {
        return null;
      }
      const serializedEvent = await context.run(
        () => JSON.stringify(state.overlayEvents[index]),
      );
      chunks.push(index === 0 ? serializedEvent : `,${serializedEvent}`);
    }
    chunks.push('],"pendingDeliveryEventIds":[');
    for (let index = 0; index < state.pendingDeliveryEventIds.length; index += 1) {
      if (!context.isCurrent()) {
        return null;
      }
      const serializedEventId = await context.run(
        () => JSON.stringify(state.pendingDeliveryEventIds[index]),
      );
      chunks.push(index === 0 ? serializedEventId : `,${serializedEventId}`);
    }
    chunks.push(']}');
    if (!context.isCurrent()) {
      return null;
    }
    return await context.run(() => chunks.join(''));
  }

  private persistSynchronously(): boolean {
    const storage = this.options.storage;
    if (!storage) {
      return false;
    }
    try {
      const state = this.options.getState();
      if (state.overlayEvents.length === 0) {
        storage.removeItem(SOCIAL_OVERLAY_STORAGE_KEY);
      } else {
        storage.setItem(SOCIAL_OVERLAY_STORAGE_KEY, JSON.stringify(state));
      }
      this.options.onSuccess();
      return true;
    } catch (cause) {
      this.reportWriteError(cause);
      return false;
    }
  }

  private reportWriteError(cause: unknown): void {
    this.options.onError(new SocialPersistenceError(
      'Could not save the local social-event display cache on this device.',
      cause,
    ));
  }
}
