import { nhashEncode, type CID } from '@hashtree/core';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { routedEventsByTag } from './routedEventReads';
import {
  createThreadRepliesPage,
  mergeUniqueEvents,
  type ThreadRepliesPage,
} from './threadReplyPagination';

type RoutedThreadReplyDeps = {
  loadEventsByTag?: typeof routedEventsByTag;
};

function uniqueRoots(roots: CID | CID[]): CID[] {
  return [...new Map(
    (Array.isArray(roots) ? roots : [roots]).map((root) => [nhashEncode(root), root] as const),
  ).values()];
}

async function loadRoutedEventsByTag(
  roots: CID[],
  tagName: string,
  tagValue: string,
  limit: number,
  before?: RecentTextNoteCursor,
  deps: RoutedThreadReplyDeps = {},
): Promise<RawEvent[]> {
  const loadEventsByTag = deps.loadEventsByTag ?? routedEventsByTag;
  return await loadEventsByTag(
    roots,
    tagName,
    tagValue,
    [1, 1111],
    limit,
    before,
  );
}

export async function loadRoutedRepliesForEvent(
  roots: CID | CID[],
  event: RawEvent,
  options: {
    limit?: number;
  } = {},
  deps: RoutedThreadReplyDeps = {},
): Promise<RawEvent[]> {
  const unique = uniqueRoots(roots);
  const limit = Math.max(options.limit ?? 50, 1);
  const address = getAddressableEventCoordinate(event);
  const [eventIdReplies, addressReplies] = await Promise.all([
    loadRoutedEventsByTag(unique, 'e', event.id, limit, undefined, deps),
    address
      ? loadRoutedEventsByTag(unique, 'a', address, limit, undefined, deps)
      : Promise.resolve([]),
  ]);
  return mergeUniqueEvents([eventIdReplies, addressReplies], limit);
}

export async function loadRoutedRepliesForEventPage(
  roots: CID | CID[],
  event: RawEvent,
  options: {
    before?: RecentTextNoteCursor;
    limit?: number;
  } = {},
  deps: RoutedThreadReplyDeps = {},
): Promise<ThreadRepliesPage> {
  const unique = uniqueRoots(roots);
  const limit = Math.max(options.limit ?? 50, 1);
  const candidateLimit = limit + 1;
  const address = getAddressableEventCoordinate(event);
  const [eventIdReplies, addressReplies] = await Promise.all([
    loadRoutedEventsByTag(unique, 'e', event.id, candidateLimit, options.before, deps),
    address
      ? loadRoutedEventsByTag(unique, 'a', address, candidateLimit, options.before, deps)
      : Promise.resolve([]),
  ]);
  const candidates = mergeUniqueEvents([eventIdReplies, addressReplies], candidateLimit);
  return createThreadRepliesPage(candidates, limit, options.before);
}
