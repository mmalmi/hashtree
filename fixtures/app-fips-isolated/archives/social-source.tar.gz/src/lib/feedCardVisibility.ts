type VisibilityListener = (visible: boolean) => void;

const listeners = new Map<Element, VisibilityListener>();
let observer: IntersectionObserver | null = null;

function getObserver(): IntersectionObserver | null {
  if (observer || typeof IntersectionObserver === 'undefined') {
    return observer;
  }
  observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => listeners.get(entry.target)?.(entry.isIntersecting));
  }, { rootMargin: '-200px 0px 0px 0px' });
  return observer;
}

export function observeFeedCardVisibility(
  node: HTMLElement,
  listener: VisibilityListener,
): (() => void) | null {
  const sharedObserver = getObserver();
  if (!sharedObserver) {
    return null;
  }
  listeners.set(node, listener);
  sharedObserver.observe(node);
  return () => {
    listeners.delete(node);
    sharedObserver.unobserve(node);
    if (listeners.size === 0) {
      sharedObserver.disconnect();
      observer = null;
    }
  };
}
