import { streamUploadWithProgress } from '@hashtree/core';
import { createWorkerTree, resolveImmutableRoot } from './workerBlockStore';
import {
  buildHashtreeAttachmentUrl,
  getMimeType,
  parseHashAddressedMediaUrl,
  parseHashtreeAttachment,
  safeExternalUrl,
} from './mediaUrls';

async function getWorkerClient() {
  return (await import('./workerClient')).getWorkerClient();
}

export {
  NOTE_URL_REGEX,
  buildHashtreeAttachmentUrl,
  extensionForUrl,
  getMimeType,
  isAudioExtension,
  isExternalHttpUrl,
  isImageExtension,
  isVideoExtension,
  parseHashAddressedMediaUrl,
  parseHashtreeAttachment,
  safeExternalUrl,
  trimTrailingPunctuation,
} from './mediaUrls';

export type NoteTextPart =
  | { type: 'text'; text: string }
  | { type: 'url'; text: string; href: string; external: boolean };

export type MediaUploadPhase = 'reading' | 'writing' | 'finalizing' | 'complete';

export interface MediaUploadProgress {
  phase: MediaUploadPhase;
  bytesProcessed: number;
  totalBytes: number;
  progress: number;
  fileName: string;
  mimeType: string;
}

export interface UploadedMediaFile {
  hashHex: string;
  nhash: string;
  url: string;
  fileName: string;
  mimeType: string;
  size: number;
}

export interface UploadMediaOptions {
  upload?: boolean;
  batchBytes?: number;
  signal?: AbortSignal;
  onProgress?: (progress: MediaUploadProgress) => void;
}

export interface ComposerAttachment {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  status: 'uploading' | 'done' | 'error';
  progress: number;
  url?: string;
  nhash?: string;
  hashHex?: string;
  error?: string;
}

const IMG_PROXY = {
  url: 'https://imgproxy.iris.to',
  key: 'f66233cb160ea07078ff28099bfa3e3e654bc10aa4a745e12176c433d79b8996',
  salt: '5e608e60945dcd2a787e8465d76ba34149894765061d39287609fb9d776caa0c',
};

const VIDEO_PROXY_URL = 'https://vidproxy.iris.to';

const encoder = new TextEncoder();
const hexByteCache = new Map<string, Uint8Array>();
const signedProxyPathCache = new Map<string, Promise<string>>();
const MAX_SIGNED_PROXY_PATHS = 2_048;
let proxyKeyPromise: Promise<CryptoKey> | null = null;

function hexToBytes(hex: string): Uint8Array {
  const cached = hexByteCache.get(hex);
  if (cached) {
    return cached;
  }

  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  }
  hexByteCache.set(hex, bytes);
  return bytes;
}

function concatBytes(left: Uint8Array, right: Uint8Array): Uint8Array {
  const bytes = new Uint8Array(left.length + right.length);
  bytes.set(left);
  bytes.set(right, left.length);
  return bytes;
}

function toArrayBuffer(bytes: Uint8Array): ArrayBuffer {
  return Uint8Array.from(bytes).buffer;
}

function bytesToBase64Url(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }

  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function getProxyKey(): Promise<CryptoKey> {
  if (!proxyKeyPromise) {
    proxyKeyPromise = crypto.subtle.importKey(
      'raw',
      toArrayBuffer(hexToBytes(IMG_PROXY.key)),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign'],
    );
  }

  return await proxyKeyPromise;
}

function signProxyPath(path: string): Promise<string> {
  const cached = signedProxyPathCache.get(path);
  if (cached) {
    signedProxyPathCache.delete(path);
    signedProxyPathCache.set(path, cached);
    return cached;
  }

  const pending = (async () => {
    const key = await getProxyKey();
    const data = concatBytes(hexToBytes(IMG_PROXY.salt), encoder.encode(path));
    const signature = await crypto.subtle.sign('HMAC', key, toArrayBuffer(data));
    return bytesToBase64Url(new Uint8Array(signature));
  })();
  signedProxyPathCache.set(path, pending);
  if (signedProxyPathCache.size > MAX_SIGNED_PROXY_PATHS) {
    signedProxyPathCache.delete(signedProxyPathCache.keys().next().value!);
  }
  void pending.catch(() => {
    if (signedProxyPathCache.get(path) === pending) {
      signedProxyPathCache.delete(path);
    }
  });
  return pending;
}

export async function generateImageProxyUrl(
  originalSrc: string,
  options: { width?: number; height?: number; square?: boolean } = {},
): Promise<string> {
  const encodedUrl = bytesToBase64Url(encoder.encode(originalSrc));
  const transforms: string[] = [];

  if (options.width || options.height) {
    const resizeType = options.square ? 'fill' : 'fit';
    const width = options.width ?? options.height ?? 0;
    const height = options.height ?? options.width ?? 0;
    transforms.push(`rs:${resizeType}:${width}:${height}`);
  }

  transforms.push('dpr:2');
  const path = `/${transforms.join('/')}/${encodedUrl}`;
  const signature = await signProxyPath(path);
  return `${IMG_PROXY.url}/${signature}${path}`;
}

/** Iris Client compatible first-frame thumbnail for an external video URL. */
export async function generateVideoThumbnailUrl(originalSrc: string): Promise<string> {
  const encodedUrl = bytesToBase64Url(encoder.encode(originalSrc));
  const path = `/thumb/${encodedUrl}`;
  const signature = await signProxyPath(path);
  return `${VIDEO_PROXY_URL}/${signature}${path}`;
}

export async function loadHashtreeObjectUrl(
  raw: string,
): Promise<{ url: string; filename: string; mimeType: string }> {
  const parsed = parseHashtreeAttachment(raw);
  if (!parsed) {
    throw new Error('Invalid Hashtree attachment');
  }

  let cid = await resolveImmutableRoot(parsed.nhash, parsed.path);
  if (!cid) {
    cid = await resolveImmutableRoot(parsed.nhash);
  }
  if (!cid) {
    throw new Error('Attachment not found');
  }

  const bytes = await createWorkerTree().readFile(cid);
  if (!bytes) {
    throw new Error('Attachment not found');
  }

  const mimeType = getMimeType(parsed.filename);
  const blob = new Blob([toArrayBuffer(bytes)], { type: mimeType });
  return {
    url: URL.createObjectURL(blob),
    filename: parsed.filename,
    mimeType,
  };
}

export async function loadHashAddressedMediaObjectUrl(
  raw: string,
  options: { expectedHashHex?: string; fallbackUrls?: readonly string[] } = {},
): Promise<{ url: string; filename: string; mimeType: string }> {
  const parsed = parseHashAddressedMediaUrl(raw);
  const explicitHash = options.expectedHashHex?.trim().toLowerCase() ?? '';
  if (explicitHash && !/^[0-9a-f]{64}$/.test(explicitHash)) {
    throw new Error('Invalid expected media SHA-256');
  }
  const hashHex = explicitHash || parsed?.hashHex;
  if (!hashHex) {
    throw new Error('Media URL is not hash-addressed');
  }

  const filename = parsed?.filename ?? filenameFromMediaUrl(raw);
  const inferredMimeType = getMimeType(filename);
  const candidateUrls = verifiedMediaCandidateUrls(options.fallbackUrls ?? []);
  const inflightKey = `${hashHex}\n${candidateUrls.join('\n')}`;
  let loadPromise = verifiedMediaInflight.get(inflightKey);
  if (!loadPromise) {
    loadPromise = resolveAndCacheVerifiedMediaBytes(
      hashHex,
      candidateUrls,
      inferredMimeType,
    );
    verifiedMediaInflight.set(inflightKey, loadPromise);
    void loadPromise.finally(() => {
      if (verifiedMediaInflight.get(inflightKey) === loadPromise) {
        verifiedMediaInflight.delete(inflightKey);
      }
    }).catch(() => undefined);
  }

  const resolved = await loadPromise;
  const blob = new Blob([toArrayBuffer(resolved.data)], { type: resolved.mimeType });
  return {
    url: URL.createObjectURL(blob),
    filename,
    mimeType: resolved.mimeType,
  };
}

async function resolveAndCacheVerifiedMediaBytes(
  hashHex: string,
  candidateUrls: readonly string[],
  inferredMimeType: string,
): Promise<VerifiedMediaBytes> {
  const workerClient = await getWorkerClient();
  try {
    const cached = await workerClient.getBlob(hashHex, { sourceIds: ['idb'] });
    return {
      data: cached.data,
      mimeType: inferredMimeType,
      cacheLocally: false,
    };
  } catch {
    // A local miss falls through to the normal mesh and signed source hints.
  }

  const fallbackAbort = new AbortController();
  const candidates: Array<Promise<VerifiedMediaBytes>> = [
    workerClient.getBlob(hashHex).then((result) => ({
      data: result.data,
      mimeType: inferredMimeType,
      cacheLocally: false,
    })),
    fetchFirstVerifiedMediaCandidate(
      candidateUrls,
      hashHex,
      inferredMimeType,
      fallbackAbort.signal,
    ),
  ];

  try {
    const resolved = await Promise.any(candidates);
    if (resolved.cacheLocally) {
      void workerClient.putBlock(resolved.data, {
        hashHex,
        mimeType: resolved.mimeType,
        upload: false,
      }).catch(() => undefined);
    }

    return resolved;
  } finally {
    fallbackAbort.abort();
  }
}

type VerifiedMediaBytes = {
  data: Uint8Array;
  mimeType: string;
  cacheLocally: boolean;
};

const MAX_VERIFIED_MEDIA_BYTES = 32 * 1024 * 1024;
const MAX_VERIFIED_MEDIA_URLS = 8;
const MAX_VERIFIED_MEDIA_URL_LENGTH = 2_048;
const verifiedMediaInflight = new Map<string, Promise<VerifiedMediaBytes>>();

function filenameFromMediaUrl(raw: string): string {
  const url = safeExternalUrl(raw);
  const encoded = url?.pathname.split('/').filter(Boolean).at(-1);
  if (!encoded) {
    return 'image';
  }
  try {
    return decodeURIComponent(encoded);
  } catch {
    return 'image';
  }
}

function verifiedMediaCandidateUrls(fallbackUrls: readonly string[]): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();
  for (const value of fallbackUrls) {
    if (urls.length >= MAX_VERIFIED_MEDIA_URLS) {
      break;
    }
    const trimmed = value.trim();
    if (!trimmed || trimmed.length > MAX_VERIFIED_MEDIA_URL_LENGTH || seen.has(trimmed)) {
      continue;
    }
    const url = safeExternalUrl(trimmed);
    if (!url || url.protocol !== 'https:' || url.username || url.password) {
      continue;
    }
    seen.add(trimmed);
    urls.push(trimmed);
  }
  return urls;
}

async function fetchFirstVerifiedMediaCandidate(
  urls: readonly string[],
  expectedHashHex: string,
  fallbackMimeType: string,
  signal: AbortSignal,
): Promise<VerifiedMediaBytes> {
  let lastError: unknown = new Error('No signed media fallback is available');
  for (const url of urls) {
    if (signal.aborted) {
      throw signal.reason;
    }
    try {
      return await fetchVerifiedMediaBytes(url, expectedHashHex, fallbackMimeType, signal);
    } catch (error) {
      if (signal.aborted) {
        throw signal.reason;
      }
      lastError = error;
    }
  }
  throw lastError;
}

async function readCappedMediaResponse(response: Response): Promise<Uint8Array> {
  const declaredLength = Number(response.headers.get('content-length'));
  if (Number.isFinite(declaredLength) && declaredLength > MAX_VERIFIED_MEDIA_BYTES) {
    throw new Error('Verified media exceeds the size limit');
  }
  if (!response.body) {
    throw new Error('Verified media response has no body');
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let totalBytes = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) {
        break;
      }
      totalBytes += value.byteLength;
      if (totalBytes > MAX_VERIFIED_MEDIA_BYTES) {
        await reader.cancel();
        throw new Error('Verified media exceeds the size limit');
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }

  const data = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    data.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return data;
}

function bytesToHex(bytes: Uint8Array): string {
  let value = '';
  for (const byte of bytes) {
    value += byte.toString(16).padStart(2, '0');
  }
  return value;
}

async function fetchVerifiedMediaBytes(
  url: string,
  expectedHashHex: string,
  fallbackMimeType: string,
  signal: AbortSignal,
): Promise<VerifiedMediaBytes> {
  const response = await fetch(url, {
    headers: { Accept: 'image/*' },
    signal: AbortSignal.any([signal, AbortSignal.timeout(10_000)]),
  });
  if (!response.ok) {
    throw new Error(`Verified media fetch failed: ${response.status}`);
  }

  const data = await readCappedMediaResponse(response);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', toArrayBuffer(data)));
  if (bytesToHex(digest) !== expectedHashHex) {
    throw new Error('Verified media did not match its expected SHA-256');
  }

  const responseMimeType = response.headers.get('content-type')?.split(';', 1)[0]?.trim().toLowerCase();
  return {
    data,
    mimeType: responseMimeType?.startsWith('image/') ? responseMimeType : fallbackMimeType,
    cacheLocally: true,
  };
}

function createAbortError(): Error {
  const error = new Error('Upload cancelled');
  error.name = 'AbortError';
  return error;
}

function normalizeProgress(
  phase: MediaUploadPhase,
  bytesProcessed: number,
  totalBytes: number,
  fileName: string,
  mimeType: string,
): MediaUploadProgress {
  const total = Math.max(0, totalBytes);
  const progress = total > 0 ? Math.min(1, Math.max(0, bytesProcessed / total)) : phase === 'complete' ? 1 : 0;
  return {
    phase,
    bytesProcessed: Math.max(0, Math.min(bytesProcessed, total || bytesProcessed)),
    totalBytes: total,
    progress,
    fileName,
    mimeType,
  };
}

function updateAttachmentPath(path: string): string {
  const trimmed = path.trim();
  if (!trimmed) {
    return 'file';
  }
  return trimmed.split('/').filter(Boolean).join('/');
}

export function selectPrimaryMediaEmbed<T extends { kind: string }>(embeds: T[]): T | null {
  const priority: Record<string, number> = {
    image: 0,
    video: 1,
    audio: 2,
    youtube: 3,
    file: 4,
  };

  let best: T | null = null;
  let bestPriority = Number.POSITIVE_INFINITY;
  for (const embed of embeds) {
    const nextPriority = priority[embed.kind] ?? 99;
    if (nextPriority < bestPriority) {
      best = embed;
      bestPriority = nextPriority;
    }
  }
  return best;
}

export async function uploadHashtreeFile(
  file: File,
  options: UploadMediaOptions = {},
): Promise<UploadedMediaFile> {
  const workerClient = await getWorkerClient();
  const mimeType = file.type?.trim() || getMimeType(file.name);
  const upload = options.upload ?? true;
  const streamId = await workerClient.beginPutBlobStream(mimeType, upload);
  const totalBytes = Math.max(0, file.size);
  const fileName = updateAttachmentPath(file.name || 'file');

  const emitProgress = (phase: MediaUploadPhase, bytesProcessed: number): void => {
    options.onProgress?.(normalizeProgress(phase, bytesProcessed, totalBytes, fileName, mimeType));
  };

  const aborted = (): boolean => options.signal?.aborted ?? false;
  const abortError = createAbortError();

  try {
    emitProgress('reading', 0);
    const result = await streamUploadWithProgress(
      file,
      {
        append: async (chunk) => {
          if (aborted()) {
            throw abortError;
          }
          await workerClient.appendPutBlobStream(streamId, chunk);
        },
        finalize: async () => {
          if (aborted()) {
            throw abortError;
          }
          return await workerClient.finishPutBlobStream(streamId);
        },
      },
      {
        batchBytes: options.batchBytes,
        readChunk: async (reader) => {
          if (aborted()) {
            throw abortError;
          }
          return await reader.read();
        },
        onProgress: (progress) => {
          emitProgress(progress.phase, progress.bytesProcessed);
        },
      },
    );

    emitProgress('complete', totalBytes);
    return {
      hashHex: result.hashHex,
      nhash: result.nhash,
      url: buildHashtreeAttachmentUrl(result.nhash, fileName),
      fileName,
      mimeType,
      size: file.size,
    };
  } catch (error) {
    await workerClient.cancelPutBlobStream(streamId).catch(() => undefined);
    if (aborted()) {
      throw abortError;
    }
    throw error;
  }
}
