import type { NoteEmbed } from './noteContent';

/** One rendered embed slot: a swipeable carousel or a single embed. */
export type NoteEmbedSlot =
  | { kind: 'carousel'; items: NoteEmbed[] }
  | { kind: 'single'; embed: NoteEmbed; index: number; lightbox: NoteEmbed[] };

export function canOpenEmbedInLightbox(embed: NoteEmbed): boolean {
  return embed.kind !== 'file';
}

export function isMediaCarouselGroup(group: readonly NoteEmbed[]): boolean {
  return group.length > 1 && group.every(canOpenEmbedInLightbox);
}

function toSlots(groups: readonly NoteEmbed[][]): NoteEmbedSlot[] {
  const slots: NoteEmbedSlot[] = [];
  for (const group of groups) {
    if (isMediaCarouselGroup(group)) {
      slots.push({ kind: 'carousel', items: [...group] });
      continue;
    }
    group.forEach((embed, index) => {
      slots.push({ kind: 'single', embed, index, lightbox: [...group] });
    });
  }
  return slots;
}

function slotMedia(slot: NoteEmbedSlot): NoteEmbed[] {
  if (slot.kind === 'carousel') {
    return slot.items;
  }
  return canOpenEmbedInLightbox(slot.embed) ? [slot.embed] : [];
}

/**
 * Bound a card to `limit` fixed-height embed slots without hiding media.
 *
 * A carousel takes one slot however many items it holds, so every image of a
 * gallery stays reachable by swiping and in the lightbox. When there are more
 * slots than the limit, the media from the overflow slots shares the last slot
 * as one carousel. Only non-media embeds (files) past the limit are dropped.
 */
export function selectNoteEmbedSlots(
  groups: readonly NoteEmbed[][],
  limit: number,
): NoteEmbedSlot[] {
  const slots = toSlots(groups);
  const maxSlots = Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : slots.length;
  if (slots.length <= maxSlots) {
    return slots;
  }
  if (maxSlots === 0) {
    return [];
  }

  const kept = slots.slice(0, maxSlots - 1);
  const overflow = slots.slice(maxSlots - 1);
  const overflowMedia = overflow.flatMap(slotMedia);
  if (overflowMedia.length > 1) {
    kept.push({ kind: 'carousel', items: overflowMedia });
  } else if (overflowMedia.length === 1) {
    const embed = overflowMedia[0]!;
    kept.push({ kind: 'single', embed, index: 0, lightbox: [embed] });
  } else {
    kept.push(overflow[0]!);
  }
  return kept;
}

export function noteEmbedSlotKey(slot: NoteEmbedSlot): string {
  return slot.kind === 'carousel'
    ? `carousel:${slot.items[0]?.url ?? ''}`
    : `single:${slot.embed.url}`;
}

export function flattenNoteEmbedSlots(slots: readonly NoteEmbedSlot[]): NoteEmbed[] {
  return slots.flatMap((slot) => (slot.kind === 'carousel' ? slot.items : [slot.embed]));
}
