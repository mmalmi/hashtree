import type { HashtreeNostrRootEntry } from '@hashtree/nostr-pubsub';
import { isHashtreeObjectKey } from './hashtreeObjectKey';
import type { SocialWorkerHashtreeRoot } from '../workers/socialWorkerProtocol';

/** Copy one root entry into the structured form the worker's index source reads. */
export function serializeRoot(
  entry: HashtreeNostrRootEntry,
  storeKind: 'shared' | 'personal',
): SocialWorkerHashtreeRoot {
  if (
    typeof entry.partitionId !== 'string'
    || entry.partitionId.length === 0
    || entry.partitionId.includes('\u0000')
    || (
      entry.replicaId !== undefined
      && (
        typeof entry.replicaId !== 'string'
        || entry.replicaId.length === 0
        || entry.replicaId.includes('\u0000')
      )
    )
  ) {
    throw new Error('Invalid Hashtree root snapshot identity');
  }
  const root = entry.root;
  if (
    root !== null
    && (
      !(root.hash instanceof Uint8Array)
      || root.hash.byteLength !== 32
      || (
        root.key !== undefined
        && !isHashtreeObjectKey(root.key)
      )
    )
  ) {
    throw new Error('Invalid Hashtree root snapshot CID');
  }
  return {
    partitionId: entry.partitionId,
    replicaId: entry.replicaId,
    root: root === null
      ? null
      : {
          hash: root.hash.slice(),
          key: root.key?.slice(),
        },
    storeKind,
  };
}
