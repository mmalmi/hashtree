import { finalizeEvent } from 'nostr-tools/pure';
import { getAccountSecretKey, type SocialAccount } from './accounts';
import type { RawEvent } from './nostr';
import { signAccountEvent } from './accountSigner';

export const IRIS_API_ORIGIN = 'https://api.iris.to';
export const IRIS_USERNAME_ORIGIN = 'https://iris.to';
export const IRIS_USERNAME_MAX_LENGTH = 15;

export type IrisUsernameAccount = {
  name: string | null;
  subscriptionPlan: string | null;
  minimumLength: number;
};

export type IrisUsernameAvailability = {
  available: boolean;
  message: string;
};

function normalizePubkey(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return /^[0-9a-f]{64}$/.test(normalized) ? normalized : null;
}

async function readJson(response: Response): Promise<Record<string, unknown>> {
  const text = await response.text();
  if (!response.ok) {
    let message = 'Iris username service returned an invalid response.';
    try {
      const parsed = JSON.parse(text) as Record<string, unknown>;
      if (typeof parsed.error === 'string') {
        message = parsed.error;
      } else if (typeof parsed.message === 'string') {
        message = parsed.message;
      }
    } catch {
      // Keep the bounded, user-safe response message.
    }
    throw new Error(message);
  }

  try {
    const parsed: unknown = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    // Fall through to the bounded error below.
  }
  throw new Error('Iris username service returned an invalid response.');
}

export function getIrisUsernameMinimumLength(subscriptionPlan: string | null): number {
  const plan = subscriptionPlan?.toLowerCase() ?? '';
  if (plan.includes('vanguard')) {
    return 3;
  }
  if (plan.includes('champion')) {
    return 5;
  }
  if (plan.includes('patron')) {
    return 6;
  }
  return 8;
}

export function validateIrisUsername(
  value: string,
  minimumLength = 8,
): { ok: true; username: string } | { ok: false; message: string } {
  const username = value.trim();
  if (username.length < minimumLength || username.length > IRIS_USERNAME_MAX_LENGTH) {
    return {
      ok: false,
      message: `Username must be between ${minimumLength} and ${IRIS_USERNAME_MAX_LENGTH} characters`,
    };
  }
  if (!/^[a-z0-9_.]+$/.test(username)) {
    return {
      ok: false,
      message: 'Username must only contain lowercase letters, numbers, underscores and dots',
    };
  }
  return { ok: true, username };
}

export async function findIrisUsernameAccount(
  pubkey: string,
  fetcher: typeof fetch = fetch,
): Promise<IrisUsernameAccount> {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey) {
    throw new Error('Account has an invalid public key.');
  }
  const url = new URL('/user/find', IRIS_API_ORIGIN);
  url.searchParams.set('public_key', normalizedPubkey);
  url.searchParams.set('nocache', String(Date.now()));
  const json = await readJson(await fetcher(url));
  const subscriptionPlan = typeof json.subscription_plan === 'string'
    ? json.subscription_plan.slice(0, 80)
    : null;
  const name = typeof json.name === 'string' && /^[a-z0-9_.]{1,15}$/.test(json.name)
    ? json.name
    : null;
  return {
    name,
    subscriptionPlan,
    minimumLength: getIrisUsernameMinimumLength(subscriptionPlan),
  };
}

export async function checkIrisUsernameAvailability(
  username: string,
  pubkey: string,
  fetcher: typeof fetch = fetch,
): Promise<IrisUsernameAvailability> {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey) {
    throw new Error('Account has an invalid public key.');
  }
  const url = new URL('/user/available', IRIS_API_ORIGIN);
  url.searchParams.set('name', username);
  url.searchParams.set('public_key', normalizedPubkey);
  const json = await readJson(await fetcher(url));
  const available = json.available === true;
  return {
    available,
    message: typeof json.message === 'string'
      ? json.message.slice(0, 200)
      : available ? 'Username is available' : 'This username is not available',
  };
}

export function createIrisUsernameAuthEvent(
  account: SocialAccount,
  options: { url: string; method: string; now?: number },
): RawEvent {
  const createdAt = options.now ?? Math.floor(Date.now() / 1_000);
  const event = finalizeEvent({
    kind: 27_235,
    tags: [
      ['u', options.url],
      ['method', options.method],
    ],
    content: '',
    created_at: createdAt,
  }, getAccountSecretKey(account));
  if (event.pubkey !== account.pubkey.toLowerCase()) {
    throw new Error('Account secret key does not match its public key.');
  }
  return event;
}

export async function createIrisUsernameAuthEventAsync(
  account: SocialAccount,
  options: { url: string; method: string; now?: number },
): Promise<RawEvent> {
  return signAccountEvent(account, {
    kind: 27_235, content: '',
    tags: [['u', options.url], ['method', options.method]],
    created_at: options.now ?? Math.floor(Date.now() / 1_000),
  });
}

export async function registerIrisUsername(
  account: SocialAccount,
  username: string,
  cfToken?: string,
  fetcher: typeof fetch = fetch,
): Promise<{ signedUp: boolean }> {
  const url = `${IRIS_API_ORIGIN}/user/register`;
  const authEvent = await createIrisUsernameAuthEventAsync(account, { url, method: 'POST' });
  const body: { username: string; cfToken?: string } = { username };
  if (cfToken) {
    body.cfToken = cfToken;
  }
  const json = await readJson(await fetcher(url, {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'content-type': 'application/json',
      authorization: `Nostr ${btoa(JSON.stringify(authEvent))}`,
    },
    body: JSON.stringify(body),
  }));
  if (typeof json.error === 'string') {
    throw new Error(json.error.slice(0, 200));
  }
  return { signedUp: json.signed_up === true };
}

export async function resolveIrisUsername(
  username: string,
  fetcher: typeof fetch = fetch,
): Promise<string | null> {
  if (!/^[a-z0-9_.]{1,15}$/.test(username)) {
    return null;
  }
  const url = new URL('/.well-known/nostr.json', IRIS_USERNAME_ORIGIN);
  url.searchParams.set('name', username);
  const json = await readJson(await fetcher(url));
  if (!json.names || typeof json.names !== 'object' || Array.isArray(json.names)) {
    return null;
  }
  return normalizePubkey((json.names as Record<string, unknown>)[username]);
}
