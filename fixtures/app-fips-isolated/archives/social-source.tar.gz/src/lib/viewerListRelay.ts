import { isNewerReplaceableEvent } from './socialRepository';
import { queryBrowserRelayEvents } from './browserEventReadRouter';
import { awaitWithin } from './feedIndexTiming';
import { canReadHomeFeedFromRelays } from './homeFeedReads';
import type { RawEvent } from './nostr';

const LIST_READ_TIMEOUT_MS = 2_500;

/**
 * The newest replaceable list (follows, mutes) the account has on relays.
 * Publishing a new list on top of a stale or missing one would silently drop
 * entries the user added elsewhere, so callers merge onto the newest version.
 */
export async function readLatestListFromRelays(
  pubkey: string,
  kind: number,
  read = queryBrowserRelayEvents,
  timeoutMs = LIST_READ_TIMEOUT_MS,
  canRead = canReadHomeFeedFromRelays,
): Promise<RawEvent | null | undefined> {
  // undefined: relays could not be checked; null: checked, no list exists.
  if (!canRead()) { return undefined; }
  const now = Date.now();
  const signal = AbortSignal.timeout(timeoutMs + 500);
  const result = await awaitWithin(read([{
    kinds: [kind], authors: [pubkey], since: 0, until: Math.floor(now / 1_000) + 60, limit: 1,
  }], { limit: 4, deadline: now + timeoutMs, signal }).catch(() => null), timeoutMs + 250);
  if (!result.settled || !result.value) { return undefined; }
  const newest = result.value.events
    .map(({ event }) => event)
    .filter((event) => event.pubkey === pubkey && event.kind === kind)
    .reduce<RawEvent | null>((newest, event) => (
      !newest || isNewerReplaceableEvent(event, newest) ? event : newest
    ), null);
  return newest ?? (result.value.complete ? null : undefined);
}

export function newerList(local: RawEvent | null | undefined, remote: RawEvent | null | undefined): RawEvent | null {
  if (!remote) { return local ?? null; }
  if (!local) { return remote; }
  return isNewerReplaceableEvent(remote, local) ? remote : local;
}

export function listPubkeys(event: RawEvent | null | undefined): string[] {
  return (event?.tags ?? [])
    .filter(tag => tag[0] === 'p')
    .map(tag => (tag[1] ?? '').trim().toLowerCase())
    .filter(pubkey => /^[0-9a-f]{64}$/.test(pubkey));
}

/** Apply one requested change to the winning list. A newer list can remove
 * entries too; unioning it with an older projection would put them back. */
export function changeListMember(
  base: RawEvent | null,
  projected: ReadonlySet<string>,
  pubkey: string,
  included: boolean,
): Set<string> {
  const members = new Set(base ? listPubkeys(base) : projected);
  if (included) { members.add(pubkey); }
  else { members.delete(pubkey); }
  return members;
}
