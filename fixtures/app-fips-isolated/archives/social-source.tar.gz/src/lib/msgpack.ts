import { decode } from '@msgpack/msgpack';

export { decode };
