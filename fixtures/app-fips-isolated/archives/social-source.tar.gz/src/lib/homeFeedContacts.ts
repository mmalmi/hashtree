import { isHexPubkey, type RawEvent } from './nostr';
import { isNewerReplaceableEvent } from './socialRepository';

export type LatestFeedOptions = {
  /** A private Favorites feed: exact authors, with no public-follow or starter fallback. */
  favoriteAuthors?: string[];
  fallbackFeedOwnerPubkey?: string | null;
  includeProfiles?: boolean;
  includeReplies?: boolean;
  emitEvery?: number;
  /** Keep the initial stream open until this many visible notes are available. */
  minimumNotes?: number;
  knownViewerFollows?: string[];
  preferStarterFeed?: boolean;
};

export function selectKnownViewerFollows(
  follows: readonly string[] | undefined,
  viewerPubkey: string,
): string[] {
  return [...new Set(follows ?? [])]
    .filter((pubkey) => isHexPubkey(pubkey) && pubkey !== viewerPubkey);
}

export async function preferGlobalStarterAuthors(
  globalAuthorsPromise: Promise<string[]>,
  personalAuthorsPromise: Promise<string[]>,
): Promise<string[]> {
  const globalAuthors = await globalAuthorsPromise;
  return globalAuthors.length > 0 ? globalAuthors : await personalAuthorsPromise;
}

/**
 * A viewer feed can paint from the global contact projection immediately.
 * With no anonymous fallback, the viewer's own posts are also a useful
 * provisional feed while an optional personal root is still resolving.
 */
export function shouldStreamProvisionalViewerFeed(
  globalFollows: readonly string[],
  fallbackFeedOwnerPubkey: string | null,
): boolean {
  return globalFollows.length > 0 || fallbackFeedOwnerPubkey === null;
}

export function selectNewestViewerContactsEvent(
  events: Array<RawEvent | null>,
  viewerPubkey: string,
): RawEvent | null {
  return events.reduce<RawEvent | null>((winner, event) => (
    event
    && event.kind === 3
    && event.pubkey === viewerPubkey
    && (!winner || isNewerReplaceableEvent(event, winner))
      ? event
      : winner
  ), null);
}
