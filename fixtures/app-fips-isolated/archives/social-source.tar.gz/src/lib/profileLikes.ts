import type { CID } from '@hashtree/core';
import { isBrowserRelayContentEnabled } from './browserEventReadRouter';
import { getRootNhash, loadEventByRef } from './nostrIndex';
import type { RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  routedEventsByAuthors,
  routedLiveProfileHistory,
} from './routedEventReads';

const PROFILE_REACTION_KIND = 7;
const MIN_PROFILE_REACTION_SCAN = 64;

export type ProfileLikedNote = {
  reaction: RawEvent;
  note: RawEvent;
};

export type ProfileLikesPage = {
  hasMore: boolean;
  items: ProfileLikedNote[];
};

export type ProfileLikesLoadDeps = {
  loadIndexedReactions?: (root: CID, pubkey: string, limit: number) => Promise<RawEvent[]>;
  relayCacheFillEnabled?: () => boolean;
  loadRelayReactions?: (pubkey: string, limit: number) => Promise<RawEvent[]>;
  loadTarget?: (roots: CID[], targetId: string) => Promise<RawEvent | null>;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

function isNewerReaction(candidate: RawEvent, existing: RawEvent): boolean {
  return compareNewest(candidate, existing) < 0;
}

export function getProfileReactionTargetId(reaction: RawEvent): string | null {
  if (reaction.kind !== PROFILE_REACTION_KIND) {
    return null;
  }
  return getLastValidLowercaseEventTarget(reaction);
}

function selectLatestPositiveReactions(reactions: Iterable<RawEvent>): RawEvent[] {
  const latestByTarget = new Map<string, RawEvent>();
  for (const reaction of reactions) {
    const targetId = getProfileReactionTargetId(reaction);
    if (!targetId) {
      continue;
    }
    const existing = latestByTarget.get(targetId);
    if (!existing || isNewerReaction(reaction, existing)) {
      latestByTarget.set(targetId, reaction);
    }
  }
  return [...latestByTarget.values()]
    .filter((reaction) => reaction.content.trim() !== '-')
    .sort(compareNewest);
}

export function projectProfileLikedNotes(
  reactions: Iterable<RawEvent>,
  targetsById: ReadonlyMap<string, RawEvent>,
): ProfileLikedNote[] {
  const contentKinds = new Set<number>(PROFILE_CONTENT_KINDS);
  return selectLatestPositiveReactions(reactions).flatMap((reaction) => {
    const targetId = getProfileReactionTargetId(reaction);
    const note = targetId ? targetsById.get(targetId) ?? null : null;
    return note && contentKinds.has(note.kind) ? [{ reaction, note }] : [];
  });
}

function uniqueRoots(roots: CID[]): CID[] {
  const seen = new Set<string>();
  return roots.filter((root) => {
    const nhash = getRootNhash(root);
    if (seen.has(nhash)) {
      return false;
    }
    seen.add(nhash);
    return true;
  });
}

export async function loadProfileLikedNotes(
  roots: CID[],
  pubkey: string,
  limit: number,
  additionalReactions: RawEvent[] = [],
  additionalTargets: ReadonlyMap<string, RawEvent> = new Map(),
  deps: ProfileLikesLoadDeps = {},
): Promise<ProfileLikesPage> {
  const boundedLimit = Number.isFinite(limit) ? Math.max(0, Math.trunc(limit)) : 0;
  if (boundedLimit === 0) {
    return { hasMore: false, items: [] };
  }
  const queryRoots = uniqueRoots(roots);
  const scanLimit = Math.max(MIN_PROFILE_REACTION_SCAN, boundedLimit * 4);
  const loadRelayReactions = deps.loadRelayReactions ?? (async (author, limit) => (
    await routedLiveProfileHistory(author, [PROFILE_REACTION_KIND], limit)
  ));
  const relayCacheFillEnabled = deps.relayCacheFillEnabled ?? isBrowserRelayContentEnabled;
  const indexedResultsPromise = deps.loadIndexedReactions
    ? Promise.all(queryRoots.map(async (root) => {
        try {
          const reactions = await deps.loadIndexedReactions!(root, pubkey, scanLimit + 1);
          return {
            reactions: reactions.slice(0, scanLimit),
            scanSaturated: reactions.length > scanLimit,
          };
        } catch (error) {
          console.warn('Failed to load profile reactions from an indexed root', error);
          return { reactions: [] as RawEvent[], scanSaturated: false };
        }
      }))
    : routedEventsByAuthors(
        queryRoots,
        [pubkey],
        [PROFILE_REACTION_KIND],
        scanLimit + 1,
      ).then((reactions) => [{
        reactions: reactions.slice(0, scanLimit),
        scanSaturated: reactions.length > scanLimit,
      }]).catch((error) => {
        console.warn('Failed to load routed profile reactions', error);
        return [{ reactions: [] as RawEvent[], scanSaturated: false }];
      });
  const [indexedResults, relayResult] = await Promise.all([
    indexedResultsPromise,
    relayCacheFillEnabled()
      ? loadRelayReactions(pubkey, scanLimit + 1).catch((error) => {
        console.warn('Failed to fill profile reactions from relays', error);
        return [];
      })
      : Promise.resolve([] as RawEvent[]),
  ]);
  const relayReactions = relayResult.slice(0, scanLimit);
  const relayScanSaturated = relayResult.length > scanLimit;
  const indexedLists = indexedResults.map((result) => result.reactions);
  const reactions = [...new Map(
    [...additionalReactions, ...relayReactions, ...indexedLists.flat()]
      .filter((event) => event.pubkey === pubkey && event.kind === PROFILE_REACTION_KIND)
      .map((event) => [event.id, event] as const),
  ).values()];
  const selectedReactions = selectLatestPositiveReactions(reactions).slice(0, scanLimit);
  const targetsById = new Map(additionalTargets);
  const loadTarget = deps.loadTarget ?? loadEventByRef;
  let items = projectProfileLikedNotes(selectedReactions, targetsById);
  // Missing/deleted targets near the reaction head must not make Likes look
  // exhausted. Resolve bounded batches until the visible page plus lookahead
  // is full, or this user-requested reaction window is exhausted.
  for (let offset = 0; offset < selectedReactions.length && items.length <= boundedLimit; offset += 16) {
    await Promise.all(selectedReactions.slice(offset, offset + 16).map(async (reaction) => {
      const targetId = getProfileReactionTargetId(reaction);
      if (!targetId || targetsById.has(targetId)) {
        return;
      }
      const target = await loadTarget(queryRoots, targetId);
      if (target) {
        targetsById.set(targetId, target);
      }
    }));
    items = projectProfileLikedNotes(selectedReactions, targetsById);
  }

  return {
    hasMore:
      items.length > boundedLimit
      || reactions.length > scanLimit
      || relayScanSaturated
      || indexedResults.some((result) => result.scanSaturated),
    items: items.slice(0, boundedLimit),
  };
}
