import type { CID } from '@hashtree/core';
import { isBrowserRelayContentEnabled } from './browserEventReadRouter';
import { getRootNhash, loadEventByRef } from './nostrIndex';
import type { RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import { createRelayHistoryReader, type RelayHistoryReader } from './relayHistory';
import { isStrictlyBeforeRecentCursor, type RecentTextNoteCursor } from './recentTextNoteCursor';
import { routedEventsByAuthors } from './routedEventReads';

const PROFILE_REACTION_KIND = 7;
const MIN_PROFILE_REACTION_SCAN = 32;
const RELAY_REACTION_PAGE = 100;
const MAX_PAGE_ROUNDS = 6;
/** Liked notes looked up ahead of the reader, in parallel. */
const TARGET_LOOKAHEAD = 32;
/** A slow index read must not hold the relay pages back. */
const INDEX_WAIT_MS = 3_000;
/** After this, a page shows what it has; slow lookups continue for the next page. */
const PAGE_BUDGET_MS = 5_000;
const CONTENT_KINDS: ReadonlySet<number> = new Set(PROFILE_CONTENT_KINDS);

export type ProfileLikedNote = {
  reaction: RawEvent;
  note: RawEvent;
};

export type ProfileLikesPage = {
  hasMore: boolean;
  items: ProfileLikedNote[];
};

export type ProfileLikesPagerDeps = {
  /** Newest indexed kind-7 reactions strictly before `before`. */
  loadIndexedReactions?: (
    roots: CID[],
    pubkey: string,
    limit: number,
    before?: RecentTextNoteCursor,
  ) => Promise<RawEvent[]>;
  /** Paged relay history; continues across `next` calls. */
  createRelayHistory?: (pubkey: string) => Pick<RelayHistoryReader, 'next' | 'close'>;
  relayCacheFillEnabled?: () => boolean;
  loadTarget?: (roots: CID[], targetId: string) => Promise<RawEvent | null>;
  now?: () => number;
  /** Bounds on waiting for the index and for liked-note lookups. */
  waits?: { indexMs?: number; pageMs?: number };
};

export type ProfileLikesPager = {
  readonly pubkey: string;
  /** The next liked notes after those already returned, newest first. */
  next(
    roots: CID[],
    limit: number,
    additionalReactions?: readonly RawEvent[],
    knownTargets?: ReadonlyMap<string, RawEvent>,
  ): Promise<ProfileLikesPage>;
  close(): void;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

function isNewerReaction(candidate: RawEvent, existing: RawEvent): boolean {
  return compareNewest(candidate, existing) < 0;
}

export function getProfileReactionTargetId(reaction: RawEvent): string | null {
  if (reaction.kind !== PROFILE_REACTION_KIND) {
    return null;
  }
  return getLastValidLowercaseEventTarget(reaction);
}

function selectLatestPositiveReactions(reactions: Iterable<RawEvent>): RawEvent[] {
  const latestByTarget = new Map<string, RawEvent>();
  for (const reaction of reactions) {
    const targetId = getProfileReactionTargetId(reaction);
    if (!targetId) {
      continue;
    }
    const existing = latestByTarget.get(targetId);
    if (!existing || isNewerReaction(reaction, existing)) {
      latestByTarget.set(targetId, reaction);
    }
  }
  return [...latestByTarget.values()]
    .filter((reaction) => reaction.content.trim() !== '-')
    .sort(compareNewest);
}

export function projectProfileLikedNotes(
  reactions: Iterable<RawEvent>,
  targetsById: ReadonlyMap<string, RawEvent>,
): ProfileLikedNote[] {
  const contentKinds = new Set<number>(PROFILE_CONTENT_KINDS);
  return selectLatestPositiveReactions(reactions).flatMap((reaction) => {
    const targetId = getProfileReactionTargetId(reaction);
    const note = targetId ? targetsById.get(targetId) ?? null : null;
    return note && contentKinds.has(note.kind) ? [{ reaction, note }] : [];
  });
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** A boundary that covers the whole second of `createdAt`. */
function wholeSecond(createdAt: number): RecentTextNoteCursor {
  return { createdAt, eventId: 'f'.repeat(64) };
}

/** The newer of two positions in newest-first order. */
function newerCursor(left: RecentTextNoteCursor, right: RecentTextNoteCursor): RecentTextNoteCursor {
  return isStrictlyBeforeRecentCursor(left.createdAt, left.eventId, right) ? right : left;
}

function cursorOf(event: RawEvent): RecentTextNoteCursor {
  return { createdAt: event.created_at, eventId: event.id };
}

function uniqueRoots(roots: CID[]): CID[] {
  const seen = new Set<string>();
  return roots.filter((root) => {
    const nhash = getRootNhash(root);
    if (seen.has(nhash)) {
      return false;
    }
    seen.add(nhash);
    return true;
  });
}

/**
 * Pages one profile's Likes. Relays page through nostr-pubsub HistoryCursors
 * in the worker; the Hashtree index pages by an exact event cursor. A reaction
 * is released only once every source that may still answer has paged past it,
 * so a later page never inserts a like above one already shown.
 */
export function createProfileLikesPager(pubkey: string, deps: ProfileLikesPagerDeps = {}): ProfileLikesPager {
  const loadIndexed = deps.loadIndexedReactions ?? (async (roots, author, limit, before) => (
    await routedEventsByAuthors(roots, [author], [PROFILE_REACTION_KIND], limit, before)
  ));
  const relayEnabled = (deps.relayCacheFillEnabled ?? isBrowserRelayContentEnabled)();
  const relay = relayEnabled
    ? (deps.createRelayHistory ?? ((author) => createRelayHistoryReader({
        authors: [author], kinds: [PROFILE_REACTION_KIND], limit: RELAY_REACTION_PAGE,
      })))(pubkey)
    : null;
  const loadTarget = deps.loadTarget ?? loadEventByRef;
  const now = deps.now ?? (() => Date.now());
  const indexWaitMs = deps.waits?.indexMs ?? INDEX_WAIT_MS;
  const pageBudgetMs = deps.waits?.pageMs ?? PAGE_BUDGET_MS;
  /** Lookups shared across pages, so a slow one is never restarted. */
  const lookups = new Map<string, Promise<void>>();
  const missing = new Set<string>();
  const buffered = new Map<string, RawEvent>();
  const emittedTargets = new Set<string>();
  const targets = new Map<string, RawEvent>();
  let relayDone = relay === null;
  let relayBoundary: RecentTextNoteCursor | null = null;
  let indexDone = false;
  let indexCursor: RecentTextNoteCursor | undefined;
  let released: RecentTextNoteCursor | undefined;
  let pending: Promise<unknown> = Promise.resolve();

  const accept = (reaction: RawEvent): void => {
    if (
      reaction.pubkey === pubkey
      && reaction.kind === PROFILE_REACTION_KIND
      // Anything newer than the last released like belongs to the live view.
      && isStrictlyBeforeRecentCursor(reaction.created_at, reaction.id, released)
    ) {
      buffered.set(reaction.id, reaction);
    }
  };

  const readRelay = async (scan: number): Promise<void> => {
    if (!relay || relayDone) { return; }
    try {
      const page = await relay.next(scan);
      page.events.forEach(accept);
      const oldest = page.events.at(-1);
      if (oldest) { relayBoundary = wholeSecond(oldest.created_at); }
      relayDone = !page.hasMore;
    } catch (error) {
      console.warn('Failed to page profile reactions from relays', error);
      relayDone = true;
    }
  };

  const readIndex = async (roots: CID[], scan: number): Promise<void> => {
    if (indexDone) { return; }
    try {
      const read = loadIndexed(roots, pubkey, scan + 1, indexCursor);
      const reactions = await Promise.race([read, delay(indexWaitMs).then(() => null)]);
      if (!reactions) {
        // Relays carry on; this pager stops waiting for the slow index.
        void read.catch(() => undefined);
        indexDone = true;
        return;
      }
      reactions.sort(compareNewest);
      const page = reactions.slice(0, scan);
      page.forEach(accept);
      const oldest = page.at(-1);
      if (oldest) { indexCursor = cursorOf(oldest); }
      indexDone = reactions.length <= scan;
    } catch (error) {
      // An unfinished index read cannot advance its cursor; relays continue.
      console.warn('Failed to page profile reactions from the Hashtree index', error);
      indexDone = true;
    }
  };

  /** Buffered reactions that no open source can still precede. */
  const releasable = (): RawEvent[] => {
    let boundary: RecentTextNoteCursor | null = null;
    if (!relayDone) {
      if (!relayBoundary) { return []; }
      boundary = relayBoundary;
    }
    if (!indexDone) {
      if (!indexCursor) { return []; }
      boundary = boundary ? newerCursor(boundary, indexCursor) : indexCursor;
    }
    return [...buffered.values()]
      .filter((event) => !boundary || !isStrictlyBeforeRecentCursor(event.created_at, event.id, boundary))
      .sort(compareNewest);
  };

  /** Start (or reuse) the lookup of one reaction's liked note. */
  const lookup = (roots: CID[], reaction: RawEvent): Promise<void> => {
    const targetId = getProfileReactionTargetId(reaction);
    if (!targetId || targets.has(targetId) || missing.has(targetId) || emittedTargets.has(targetId)) {
      return Promise.resolve();
    }
    let request = lookups.get(targetId);
    if (!request) {
      request = loadTarget(roots, targetId).then((target) => {
        if (target) { targets.set(targetId, target); } else { missing.add(targetId); }
      }, () => { missing.add(targetId); });
      lookups.set(targetId, request);
    }
    return request;
  };

  const run = async (
    roots: CID[],
    limit: number,
    additionalReactions: readonly RawEvent[],
    knownTargets: ReadonlyMap<string, RawEvent>,
  ): Promise<ProfileLikesPage> => {
    const queryRoots = uniqueRoots(roots);
    for (const [id, note] of knownTargets) { targets.set(id, note); }
    additionalReactions.forEach(accept);
    const scan = Math.max(MIN_PROFILE_REACTION_SCAN, limit * 2);
    const deadline = now() + pageBudgetMs;
    const items: ProfileLikedNote[] = [];
    let stalled = false;
    for (let round = 0; round < MAX_PAGE_ROUNDS && items.length < limit; round += 1) {
      // Read more history only when the buffer cannot fill this page.
      if (releasable().length < limit - items.length) {
        await Promise.all([readRelay(scan), readIndex(queryRoots, scan)]);
      }
      const ready = releasable();
      if (ready.length === 0) {
        if (relayDone && indexDone) { break; }
        continue;
      }
      // Look targets up ahead in parallel, but release strictly in order: a
      // like whose note is still loading ends this page and leads the next.
      for (const reaction of ready.slice(0, TARGET_LOOKAHEAD)) { lookup(queryRoots, reaction); }
      for (const [index, reaction] of ready.entries()) {
        if (items.length >= limit) { break; }
        const targetId = getProfileReactionTargetId(reaction);
        if (targetId && !emittedTargets.has(targetId) && !targets.has(targetId) && !missing.has(targetId)) {
          const next = ready[index + TARGET_LOOKAHEAD];
          if (next) { lookup(queryRoots, next); }
          const remaining = deadline - now();
          if (remaining > 0) {
            await Promise.race([lookup(queryRoots, reaction), delay(remaining)]);
          }
          if (!targets.has(targetId) && !missing.has(targetId)) {
            stalled = true;
            break;
          }
        }
        buffered.delete(reaction.id);
        released = cursorOf(reaction);
        // Newest first: the first reaction per target is its latest one.
        if (!targetId || emittedTargets.has(targetId)) { continue; }
        emittedTargets.add(targetId);
        const note = targets.get(targetId);
        if (reaction.content.trim() !== '-' && note && CONTENT_KINDS.has(note.kind)) {
          items.push({ reaction, note });
        }
      }
      if (stalled) { break; }
    }
    return { items, hasMore: buffered.size > 0 || !relayDone || !indexDone };
  };

  return {
    pubkey,
    next(roots, limit, additionalReactions = [], knownTargets = new Map()) {
      const bounded = Number.isFinite(limit) ? Math.max(0, Math.trunc(limit)) : 0;
      const result = pending.then(() => (
        bounded === 0
          ? { items: [], hasMore: buffered.size > 0 || !relayDone || !indexDone }
          : run(roots, bounded, additionalReactions, knownTargets)
      ));
      pending = result.catch(() => undefined);
      return result;
    },
    close() {
      relay?.close();
    },
  };
}
