import { nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  RANKED_SEARCH_SEGMENT_FORMAT,
  RankedSearchIndex,
  type RankedSearchResult,
  type RankedSearchScoringContext,
} from '@hashtree/index';
import type { RawEvent } from './nostr';
import {
  throwIfPostSearchAborted,
  withPostSearchTimeout,
} from './postSearchAbort';
import {
  createPostSearchExecution,
  PostSearchExecution,
  type PostSearchExecutionInput,
} from './postSearchExecution';
import { routePostSearchSegments } from './postSearchCatalogRouting';
import {
  POST_SEARCH_BUILD_OPTIONS,
  parseStoredPostSearchDocument,
  type PostSearchCatalog,
} from './postSearchCatalog';
import { PostSearchCatalogCache } from './postSearchCatalogCache';
import {
  normalizePostSearchOptions,
  type NormalizedPostSearchOptions,
} from './postSearchFederationOptions';
import { readPostSearchScoringContext } from './postSearchGlobalScoring';
import { expandPostSearchQuery } from './postSearchQueryExpansion';
import { parsePostSearchRoutingQueryTerms } from './postSearchTermRouting';
import {
  buildPublisherResponse,
  type PostSearchPublisherFailure,
  type PublisherHit,
  type PublisherResponse,
  type SegmentHit,
  type SegmentSearchResponse,
  type SegmentWorkerResponse,
} from './postSearchPublisherResponse';
import { PostSearchV5RoutedFederation } from './postSearchV5RoutedFederation';
import { POST_SEARCH_V5_ROUTED_CATALOG_FORMAT } from '../server/postSearchV5RoutedCatalog';

export type { PostSearchPublisherFailure } from './postSearchPublisherResponse';
export type {
  PostSearchEventBatchVerifier,
  PostSearchEventVerifier,
  PostSearchExecutionOptions,
} from './postSearchExecution';

const RECIPROCAL_RANK_OFFSET = 60;

export interface PostSearchCatalogSource {
  /** Expected stable publisher identity, normally the signer of the mutable catalog pointer. */
  publisherId: string;
  /** Immutable catalog root resolved by the caller from Hashtree/Nostr/FIPS. */
  root: CID;
}

export interface DeferredPostSearchCatalogSource {
  /** Expected stable publisher identity while its mutable pointer resolves. */
  publisherId: string;
  /** Root resolution already in flight, bounded by the normal publisher request deadline. */
  root: PromiseLike<CID | null>;
}

type ResolvablePostSearchCatalogSource = PostSearchCatalogSource | DeferredPostSearchCatalogSource;

export interface FederatedPostSearchOptions {
  /** Stops obsolete browser queries before they traverse more immutable blocks. */
  signal?: AbortSignal;
  limit?: number;
  operator?: 'or' | 'and';
  authors?: readonly string[];
  kinds?: readonly number[];
  since?: number;
  until?: number;
  /** Bounds simultaneous catalog reads/searches. Clamped to 1...8. */
  publisherConcurrency?: number;
  /** Bounds simultaneous immutable segment searches per catalog. Clamped to 1...4. */
  segmentConcurrency?: number;
  /** Bounds candidates read from each segment before filters/dedup. Clamped to 1...256. */
  perSegmentLimit?: number;
  /** Maximum adaptive overfetch per segment. Clamped to the initial limit...4096. */
  maxPerSegmentLimit?: number;
  /** Bounds an unavailable catalog or segment read. Clamped to 100...60000ms. */
  requestTimeoutMs?: number;
  /** Receives verified partial results as segments and publishers finish. */
  onProgress?: (response: FederatedPostSearchResponse) => void;
}

export type FederatedPostSearchWarmOptions = Pick<
  FederatedPostSearchOptions,
  'signal' | 'publisherConcurrency' | 'requestTimeoutMs'
>;

export interface FederatedPostSearchResult {
  event: RawEvent;
  /** Reciprocal-rank fusion score across independent publishers. */
  score: number;
  /** Highest segment-local BM25F score, useful for diagnostics only. */
  lexicalScore: number;
  matchedTerms: string[];
  matchedPhrases: number;
  publisherIds: string[];
}

export interface FederatedPostSearchResponse {
  results: FederatedPostSearchResult[];
  failures: PostSearchPublisherFailure[];
  searchedPublishers: number;
  /** True when filters could not hide any result that belongs in this requested top-k. */
  exhaustive: boolean;
  /** Publishers whose adaptive filtering hit maxPerSegmentLimit before proving top-k. */
  truncatedPublishers: string[];
}

type AggregateHit = FederatedPostSearchResult & {
  canonicalEvent: string;
  publishers: Set<string>;
  terms: Set<string>;
};

type LegacySegmentCandidate = {
  result: RankedSearchResult;
  event: RawEvent;
};

/**
 * Searches immutable Hashtree catalogs directly through the supplied local/FIPS-backed Store.
 * Catalog pointer discovery and event signature verification deliberately remain caller-owned.
 */
export class FederatedPostSearch {
  private readonly routedSearch: PostSearchV5RoutedFederation;
  private readonly catalogCache: PostSearchCatalogCache;
  private readonly execution: PostSearchExecution;

  constructor(
    private readonly store: Store,
    execution?: PostSearchExecutionInput,
  ) {
    this.execution = createPostSearchExecution(execution);
    this.routedSearch = new PostSearchV5RoutedFederation(store, this.execution);
    this.catalogCache = new PostSearchCatalogCache(store);
  }

  async warm(
    sources: readonly ResolvablePostSearchCatalogSource[],
    options: FederatedPostSearchWarmOptions = {},
  ): Promise<void> {
    const normalized = normalizePostSearchOptions(options);
    await this.catalogCache.warm(
      [...sources].sort(compareSources),
      async (publisherId, root) => await this.routedSearch.warm(publisherId, root),
      normalized,
    );
  }

  async search(
    sources: readonly ResolvablePostSearchCatalogSource[],
    query: string,
    options: FederatedPostSearchOptions = {},
  ): Promise<FederatedPostSearchResponse> {
    const normalized = normalizePostSearchOptions(options);
    throwIfPostSearchAborted(normalized.signal);
    const orderedSources = [...sources].sort(compareSources);
    const progressResponses = new Array<PublisherResponse | null>(orderedSources.length).fill(null);
    let completedPublishers = 0;
    const emitProgress = (): void => {
      if (!normalized.onProgress) {
        return;
      }
      throwIfPostSearchAborted(normalized.signal);
      try {
        normalized.onProgress(buildFederatedResponse(
          progressResponses.filter((response): response is PublisherResponse => response !== null),
          normalized.limit,
          false,
        ));
      } catch {
        // Rendering progress must never make the underlying verified search fail.
      }
    };
    const publisherResponses = await mapConcurrent(
      orderedSources,
      normalized.publisherConcurrency,
      async (source, index) => {
        const response = await this.searchPublisher(
          source,
          query,
          normalized,
          normalized.onProgress
            ? (partial) => {
                progressResponses[index] = partial;
                emitProgress();
              }
            : null,
        );
        progressResponses[index] = response;
        completedPublishers += 1;
        if (completedPublishers < orderedSources.length) {
          emitProgress();
        }
        return response;
      },
    );
    throwIfPostSearchAborted(normalized.signal);
    return buildFederatedResponse(publisherResponses, normalized.limit, true);
  }

  private async searchPublisher(
    source: ResolvablePostSearchCatalogSource,
    query: string,
    options: NormalizedPostSearchOptions,
    onProgress: ((response: PublisherResponse) => void) | null = null,
  ): Promise<PublisherResponse> {
    throwIfPostSearchAborted(options.signal);
    let catalog: PostSearchCatalog;
    let scoringContext: RankedSearchScoringContext | undefined;
    let effectiveQuery = query;
    try {
      const root = await withPostSearchTimeout(
        Promise.resolve(source.root),
        options.requestTimeoutMs,
        options.signal,
      );
      if (!root) {
        throw new Error('Publisher catalog root is unavailable');
      }
      const format = await withPostSearchTimeout(
        this.catalogCache.format(root),
        options.requestTimeoutMs,
        options.signal,
      );
      if (format === POST_SEARCH_V5_ROUTED_CATALOG_FORMAT) {
        return await this.routedSearch.searchPublisher(
          source.publisherId,
          root,
          query,
          options,
        );
      }
      catalog = await withPostSearchTimeout(
        this.catalogCache.legacy(root),
        options.requestTimeoutMs,
        options.signal,
      );
      if (catalog.manifest.publisherId !== source.publisherId) {
        throw new IncompatibleCatalogError('Catalog publisher identity does not match its pointer');
      }
      if (catalog.globalScoring) {
        effectiveQuery = await withPostSearchTimeout(expandPostSearchQuery(
          this.store,
          catalog.globalScoring,
          query,
          options.operator,
          options.signal,
        ), options.requestTimeoutMs, options.signal);
        scoringContext = await withPostSearchTimeout(readPostSearchScoringContext(
          this.store,
          catalog.globalScoring,
          parsePostSearchRoutingQueryTerms(effectiveQuery),
        ), options.requestTimeoutMs, options.signal);
      }
    } catch (error) {
      throwIfPostSearchAborted(options.signal);
      return {
        publisherId: source.publisherId,
        hits: [],
        failure: failureForCatalog(source.publisherId, error),
        searched: false,
        exhaustive: false,
        truncated: false,
      };
    }

    const compatibleSegments = catalog.segments.filter((segment) => segmentMatchesFilters(segment, options));
    let segments: PostSearchCatalog['segments'];
    try {
      segments = await withPostSearchTimeout(
        routePostSearchSegments(
          this.store,
          catalog,
          compatibleSegments,
          effectiveQuery,
          options.operator,
          options.signal,
        ),
        options.requestTimeoutMs,
        options.signal,
      );
    } catch (error) {
      throwIfPostSearchAborted(options.signal);
      return {
        publisherId: source.publisherId,
        hits: [],
        failure: failureForCatalog(source.publisherId, error),
        searched: false,
        exhaustive: false,
        truncated: false,
      };
    }
    const completedSegmentResponses: SegmentWorkerResponse[] = [];
    const segmentResponses = await mapConcurrent(
      segments,
      options.segmentConcurrency,
      async (segment) => {
        throwIfPostSearchAborted(options.signal);
        let result: SegmentWorkerResponse;
        try {
          result = {
            response: await withPostSearchTimeout(
              searchSegment(
                this.store,
                segment,
                effectiveQuery,
                options,
                this.execution,
                scoringContext,
              ),
              options.requestTimeoutMs,
              options.signal,
            ),
            failed: false,
          };
        } catch {
          throwIfPostSearchAborted(options.signal);
          result = {
            response: { hits: [] as SegmentHit[], exhaustive: false },
            failed: true,
          };
        }
        completedSegmentResponses.push(result);
        if (completedSegmentResponses.length < segments.length) {
          throwIfPostSearchAborted(options.signal);
          onProgress?.(buildPublisherResponse(
            source.publisherId,
            completedSegmentResponses,
            segments.length,
            false,
          ));
        }
        return result;
      },
    );
    return buildPublisherResponse(source.publisherId, segmentResponses, segments.length, true);
  }

}

async function searchSegment(
  store: Store,
  segment: PostSearchCatalog['segments'][number],
  query: string,
  options: NormalizedPostSearchOptions,
  execution: PostSearchExecution,
  scoringContext: RankedSearchScoringContext | undefined,
): Promise<SegmentSearchResponse> {
  throwIfPostSearchAborted(options.signal);
  const index = new RankedSearchIndex(store);
  const manifest = await index.readManifest(segment.root);
  if (manifest.format !== RANKED_SEARCH_SEGMENT_FORMAT
    || manifest.documentCount !== segment.documentCount
    || !hasCompatibleFields(manifest.fields)) {
    throw new IncompatibleCatalogError('Ranked segment does not match its catalog descriptor');
  }
  let requestLimit = Math.min(
    options.maxPerSegmentLimit,
    Math.max(options.limit, options.perSegmentLimit),
  );
  while (true) {
    throwIfPostSearchAborted(options.signal);
    const results = await index.search(segment.root, query, {
      limit: requestLimit,
      operator: options.operator,
      ...(scoringContext ? { scoringContext } : {}),
    });
    throwIfPostSearchAborted(options.signal);
    const candidates: LegacySegmentCandidate[] = [];
    for (const result of results) {
      const candidate = await execution.run(options.signal, () =>
        toLegacySegmentCandidate(result, options));
      if (candidate) {
        candidates.push(candidate);
      }
    }
    const validity = await execution.verifyEvents(
      candidates.map((candidate) => candidate.event),
      options.signal,
    );
    const hits: SegmentHit[] = [];
    for (let index = 0; index < candidates.length; index += 1) {
      if (!validity[index]) {
        continue;
      }
      hits.push(await execution.run(options.signal, () =>
        toVerifiedSegmentHit(candidates[index]!)));
    }
    if (hits.length >= options.limit || results.length < requestLimit) {
      return { hits: hits.slice(0, options.limit), exhaustive: true };
    }
    if (requestLimit >= options.maxPerSegmentLimit) {
      return { hits, exhaustive: false };
    }
    requestLimit = Math.min(options.maxPerSegmentLimit, requestLimit * 2);
  }
}

function toLegacySegmentCandidate(
  result: RankedSearchResult,
  options: NormalizedPostSearchOptions,
): LegacySegmentCandidate | null {
  const stored = parseStoredPostSearchDocument(result.value);
  if (
    !stored
    || stored.event.id !== result.id
    || !eventMatchesFilters(stored.event, options)
  ) {
    return null;
  }
  return { result, event: stored.event };
}

function toVerifiedSegmentHit(candidate: LegacySegmentCandidate): SegmentHit {
  return {
    event: candidate.event,
    lexicalScore: candidate.result.score,
    matchedTerms: [...candidate.result.matchedTerms].sort(compareStrings),
    matchedPhrases: candidate.result.matchedPhrases,
  };
}

function mergePublisherHit(
  aggregates: Map<string, AggregateHit>,
  publisherId: string,
  hit: PublisherHit,
): void {
  const canonicalEvent = JSON.stringify(hit.event);
  const reciprocalRankScore = 1 / (RECIPROCAL_RANK_OFFSET + hit.rank);
  const existing = aggregates.get(hit.event.id);
  if (!existing) {
    aggregates.set(hit.event.id, {
      event: hit.event,
      canonicalEvent,
      score: reciprocalRankScore,
      lexicalScore: hit.lexicalScore,
      matchedTerms: [],
      matchedPhrases: hit.matchedPhrases,
      publisherIds: [],
      publishers: new Set([publisherId]),
      terms: new Set(hit.matchedTerms),
    });
    return;
  }
  if (existing.publishers.has(publisherId)) {
    return;
  }
  existing.publishers.add(publisherId);
  existing.score += reciprocalRankScore;
  existing.lexicalScore = Math.max(existing.lexicalScore, hit.lexicalScore);
  existing.matchedPhrases = Math.max(existing.matchedPhrases, hit.matchedPhrases);
  hit.matchedTerms.forEach((term) => existing.terms.add(term));
  if (compareStrings(canonicalEvent, existing.canonicalEvent) < 0) {
    existing.event = hit.event;
    existing.canonicalEvent = canonicalEvent;
  }
}

function finalizeAggregate(aggregate: AggregateHit): FederatedPostSearchResult {
  return {
    event: aggregate.event,
    score: aggregate.score,
    lexicalScore: aggregate.lexicalScore,
    matchedTerms: [...aggregate.terms].sort(compareStrings),
    matchedPhrases: aggregate.matchedPhrases,
    publisherIds: [...aggregate.publishers].sort(compareStrings),
  };
}

function segmentMatchesFilters(
  segment: PostSearchCatalog['segments'][number],
  options: NormalizedPostSearchOptions,
): boolean {
  if (options.kinds && !segment.kinds.some((kind) => options.kinds?.has(kind))) {
    return false;
  }
  if (options.since !== null && segment.until !== null && segment.until < options.since) {
    return false;
  }
  return !(options.until !== null && segment.since !== null && segment.since > options.until);
}

function eventMatchesFilters(event: RawEvent, options: NormalizedPostSearchOptions): boolean {
  return (!options.authors || options.authors.has(event.pubkey))
    && (!options.kinds || options.kinds.has(event.kind))
    && (options.since === null || event.created_at >= options.since)
    && (options.until === null || event.created_at <= options.until);
}

function hasCompatibleFields(fields: Array<{
  name: string;
  boost: number;
  lengthNormalization: number;
}>): boolean {
  const actual = fields.map((field) => ({
    name: field.name,
    boost: field.boost,
    lengthNormalization: field.lengthNormalization,
  }));
  const expected = Object.entries(POST_SEARCH_BUILD_OPTIONS.fields)
    .map(([name, options]) => ({ name, ...options }))
    .sort((left, right) => compareStrings(left.name, right.name));
  return JSON.stringify(actual) === JSON.stringify(expected);
}

function failureForCatalog(publisherId: string, error: unknown): PostSearchPublisherFailure {
  const incompatible = error instanceof IncompatibleCatalogError
    || (error instanceof Error
      && /incompatible|unsupported|identity|global scoring|global term/.test(error.message.toLowerCase()));
  return {
    publisherId,
    status: incompatible ? 'incompatible' : 'unavailable',
    failedSegments: 0,
    message: incompatible ? 'Publisher catalog is incompatible' : 'Publisher catalog is unavailable',
  };
}

function compareSources(
  left: ResolvablePostSearchCatalogSource,
  right: ResolvablePostSearchCatalogSource,
): number {
  return compareStrings(left.publisherId, right.publisherId)
    || compareStrings(
      'then' in left.root ? '' : nhashEncode(left.root),
      'then' in right.root ? '' : nhashEncode(right.root),
    );
}

function buildFederatedResponse(
  publisherResponses: readonly PublisherResponse[],
  limit: number,
  complete: boolean,
): FederatedPostSearchResponse {
  const aggregates = new Map<string, AggregateHit>();
  for (const response of publisherResponses) {
    for (const hit of response.hits) {
      mergePublisherHit(aggregates, response.publisherId, hit);
    }
  }
  const results = [...aggregates.values()].map(finalizeAggregate)
    .sort(compareFederatedResults).slice(0, limit);
  const failures = publisherResponses.flatMap((response) => response.failure ? [response.failure] : [])
    .sort((left, right) => compareStrings(left.publisherId, right.publisherId));
  const truncatedPublishers = publisherResponses.filter((response) => response.truncated)
    .map((response) => response.publisherId).sort(compareStrings);
  return {
    results,
    failures,
    searchedPublishers: publisherResponses.filter((response) => response.searched).length,
    exhaustive: complete && publisherResponses.every((response) => response.exhaustive),
    truncatedPublishers,
  };
}

function compareFederatedResults(
  left: FederatedPostSearchResult,
  right: FederatedPostSearchResult,
): number {
  return right.score - left.score
    || right.lexicalScore - left.lexicalScore
    || right.matchedPhrases - left.matchedPhrases
    || right.event.created_at - left.event.created_at
    || compareStrings(left.event.id, right.event.id);
}

async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input, index: number) => Promise<Output>,
): Promise<Output[]> {
  const results = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await worker(values[index], index);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return results;
}

class IncompatibleCatalogError extends Error {}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
