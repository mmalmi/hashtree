import { getConfiguredDefaultViewerNpub } from './config';
import type { ProfileRecord } from './nostr';
import { overlayProfileRecord } from './profileRecords';
import { readStoredNumber, saveStoredNumber } from './appStorage';
import type { AppCombinedState } from './appState';

const STORAGE_KEY_NOTIFICATIONS_SEEN_AT = 'iris-social:notifications-seen-at';

export function createAppBrowserState(state: AppCombinedState) {
  function readNotificationsSeenAt(): number {
    return readStoredNumber(STORAGE_KEY_NOTIFICATIONS_SEEN_AT);
  }

  function saveNotificationsSeenAt(value: number): void {
    state.notificationsSeenAt = value;
    saveStoredNumber(STORAGE_KEY_NOTIFICATIONS_SEEN_AT, value);
  }

  function stripTransientQueryParams(): void {
    const url = new URL(window.location.href);
    let changed = false;
    for (const param of ['finaldeploy']) {
      if (url.searchParams.has(param)) {
        url.searchParams.delete(param);
        changed = true;
      }
    }
    if (changed) {
      const search = url.searchParams.toString();
      window.history.replaceState(
        window.history.state,
        '',
        `${url.pathname}${search ? `?${search}` : ''}${url.hash}`,
      );
    }
  }

  function consumeViewerOverride(): string {
    const url = new URL(window.location.href);
    const viewAs = url.searchParams.get('viewAs')?.trim() || '';
    if (viewAs) {
      url.searchParams.delete('viewAs');
      const search = url.searchParams.toString();
      window.history.replaceState(
        {},
        '',
        `${url.pathname}${search ? `?${search}` : ''}${url.hash}`,
      );
      return viewAs;
    }
    return getConfiguredDefaultViewerNpub() || '';
  }

  return {
    consumeViewerOverride,
    readNotificationsSeenAt,
    saveNotificationsSeenAt,
    stripTransientQueryParams,
  };
}

export function reportAppError(fallbackMessage: string, error: unknown): string {
  console.error(error);
  return fallbackMessage;
}

export function overlayViewerProfile(
  profiles: Map<string, ProfileRecord>,
  profile: ProfileRecord | null,
): Map<string, ProfileRecord> {
  if (!profile) {
    return profiles;
  }
  const nextProfiles = new Map(profiles);
  const mergedProfile = overlayProfileRecord(profile, profiles.get(profile.pubkey) ?? null);
  if (mergedProfile) {
    nextProfiles.set(profile.pubkey, mergedProfile);
  }
  return nextProfiles;
}
