import { verifyEvent } from 'nostr-tools/pure';
import type { RawEvent } from './nostr';
import { mergeNotesByNewest, mergeVisibleNotes } from './appDataUtils';
import {
  verifyPersistedEventShapes,
  type PersistedEventVerificationOptions,
} from './socialDataPlaneSupport';

export const STORAGE_KEY_LOCAL_POSTS = 'iris-social:local-posts';
const MAX_STORED_LOCAL_POSTS = 256;

function getLocalStorage(): Storage | null {
  return typeof localStorage === 'undefined' ? null : localStorage;
}

function isHex64(value: string): boolean {
  return /^[0-9a-f]{64}$/i.test(value);
}

function normalizeStoredEventShape(value: unknown): RawEvent | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const candidate = value as Partial<RawEvent>;
  if (
    typeof candidate.id !== 'string' ||
    typeof candidate.pubkey !== 'string' ||
    !isHex64(candidate.id) ||
    !isHex64(candidate.pubkey) ||
    typeof candidate.created_at !== 'number' ||
    !Number.isFinite(candidate.created_at) ||
    typeof candidate.kind !== 'number' ||
    !Number.isFinite(candidate.kind) ||
    typeof candidate.content !== 'string' ||
    typeof candidate.sig !== 'string' ||
    !/^[0-9a-f]{128}$/i.test(candidate.sig) ||
    !Array.isArray(candidate.tags)
  ) {
    return null;
  }

  const tags = candidate.tags
    .filter((tag): tag is string[] => Array.isArray(tag) && tag.every((entry) => typeof entry === 'string'));

  const event: RawEvent = {
    id: candidate.id.toLowerCase(),
    pubkey: candidate.pubkey.toLowerCase(),
    created_at: Math.trunc(candidate.created_at),
    kind: Math.trunc(candidate.kind),
    tags,
    content: candidate.content,
    sig: candidate.sig.toLowerCase(),
  };
  return event;
}

function normalizeStoredEvent(value: unknown): RawEvent | null {
  const event = normalizeStoredEventShape(value);
  if (!event) {
    return null;
  }
  try {
    return verifyEvent(event) ? event : null;
  } catch {
    return null;
  }
}

function collectStoredEvents(
  value: unknown,
  normalize: (entry: unknown) => RawEvent | null,
): RawEvent[] {
  if (Array.isArray(value)) {
    return value
      .map((entry) => normalize(entry))
      .filter((entry): entry is RawEvent => Boolean(entry));
  }

  if (!value || typeof value !== 'object') {
    return [];
  }

  return Object.values(value as Record<string, unknown>)
    .flatMap((entry) => collectStoredEvents(entry, normalize));
}

function groupLocalPostsByAuthor(posts: readonly RawEvent[]): Map<string, RawEvent[]> {
  const postsByAuthor = new Map<string, RawEvent[]>();
  for (const post of posts) {
    const existing = postsByAuthor.get(post.pubkey) ?? [];
    postsByAuthor.set(post.pubkey, [...existing, post]);
  }
  return postsByAuthor;
}

export function flattenLocalPostsByAuthor(localPostsByAuthor: Map<string, RawEvent[]>): RawEvent[] {
  return mergeNotesByNewest(...localPostsByAuthor.values());
}

export function mergeLocalPostsByAuthor(
  ...maps: Array<Map<string, RawEvent[]>>
): Map<string, RawEvent[]> {
  return groupLocalPostsByAuthor(
    mergeNotesByNewest(...maps.flatMap((map) => [...map.values()]))
      .slice(0, MAX_STORED_LOCAL_POSTS),
  );
}

export function readLocalPostsFromStorage(storage: Storage | null = getLocalStorage()): Map<string, RawEvent[]> {
  if (!storage) {
    return new Map();
  }

  try {
    const raw = storage.getItem(STORAGE_KEY_LOCAL_POSTS);
    if (!raw) {
      return new Map();
    }

    const posts = mergeNotesByNewest(collectStoredEvents(JSON.parse(raw), normalizeStoredEvent))
      .slice(0, MAX_STORED_LOCAL_POSTS);
    return groupLocalPostsByAuthor(posts);
  } catch {
    return new Map();
  }
}

export async function readLocalPostsFromStorageAsync(
  storage: Storage | null = getLocalStorage(),
  options: PersistedEventVerificationOptions = {},
): Promise<Map<string, RawEvent[]>> {
  if (!storage) {
    return new Map();
  }

  let parsed: unknown;
  try {
    const raw = storage.getItem(STORAGE_KEY_LOCAL_POSTS);
    if (!raw) {
      return new Map();
    }
    parsed = JSON.parse(raw);
  } catch {
    return new Map();
  }

  const candidates = mergeNotesByNewest(
    collectStoredEvents(parsed, normalizeStoredEventShape),
  ).slice(0, MAX_STORED_LOCAL_POSTS);
  const posts = await verifyPersistedEventShapes(candidates, options);
  return groupLocalPostsByAuthor(posts);
}

export function writeLocalPostsToStorage(
  localPostsByAuthor: Map<string, RawEvent[]>,
  storage: Storage | null = getLocalStorage(),
): void {
  if (!storage) {
    return;
  }

  try {
    const posts = flattenLocalPostsByAuthor(localPostsByAuthor).slice(0, MAX_STORED_LOCAL_POSTS);
    if (posts.length === 0) {
      storage.removeItem(STORAGE_KEY_LOCAL_POSTS);
      return;
    }
    storage.setItem(STORAGE_KEY_LOCAL_POSTS, JSON.stringify(posts));
  } catch {
    // Local persistence should never block composing or reading posts.
  }
}

export function prependLocalPost(
  localPostsByAuthor: Map<string, RawEvent[]>,
  event: RawEvent,
): Map<string, RawEvent[]> {
  const nextLocalPosts = new Map(localPostsByAuthor);
  const existing = nextLocalPosts.get(event.pubkey) ?? [];
  nextLocalPosts.set(event.pubkey, [event, ...existing.filter((entry) => entry.id !== event.id)]);
  return nextLocalPosts;
}

export function mergeLocalVisibleNotes(
  localPostsByAuthor: Map<string, RawEvent[]>,
  baseNotes: RawEvent[],
  authorPubkey: string | null,
): RawEvent[] {
  return mergeVisibleNotes(
    authorPubkey ? localPostsByAuthor.get(authorPubkey) ?? [] : [],
    baseNotes,
  );
}

export function prependThreadReply(
  threadReplies: RawEvent[],
  event: RawEvent,
): RawEvent[] {
  return mergeNotesByNewest([event], threadReplies);
}
