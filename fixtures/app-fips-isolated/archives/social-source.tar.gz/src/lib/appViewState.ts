import type { CID } from '@hashtree/core';
import { getUniqueRoots } from './appDataUtils';
import type { Route } from './appRoute';
import type { RawEvent } from './nostr';
import type { NoteEngagement } from './noteEngagement';
import { ZERO_NOTE_ENGAGEMENT } from './noteEngagement';
import type { FeedSnapshot, NoteThreadSnapshot } from './nostrIndex';
import type { ProfileSnapshot } from './profileNotes';

export function hasLiveRouteContent(
  route: Route,
  options: {
    feed: FeedSnapshot | null;
    profilePage: ProfileSnapshot | null;
    threadPage: NoteThreadSnapshot | null;
    notificationsCount: number;
    homeNoteCount?: number;
  },
): boolean {
  if (route.kind === 'profile') {
    return Boolean(options.profilePage);
  }

  if (route.kind === 'thread') {
    return Boolean(options.threadPage?.note);
  }

  if (route.kind === 'notifications') {
    return options.notificationsCount > 0;
  }

  return route.kind === 'settings'
    || route.kind === 'wallet'
    || route.kind === 'search'
    || route.kind === 'accounts'
    || route.kind === 'username'
    || Boolean(options.feed)
    || (route.kind === 'home' && (options.homeNoteCount ?? 0) > 0);
}

export function getViewerRoots(currentRoot: CID | null, viewerPersonalRoot: CID | null): CID[] {
  return getUniqueRoots(currentRoot, viewerPersonalRoot);
}

export function getThreadHydrationRoots(
  currentRoot: CID,
  profilePersonalRoot: CID | null,
  viewerPersonalRoot: CID | null,
  threadPersonalRoot: CID | null,
): CID[] {
  return getUniqueRoots(currentRoot, profilePersonalRoot, viewerPersonalRoot, threadPersonalRoot);
}

export function getThreadRoots(currentRoot: CID, threadPersonalRoot: CID | null): CID[] {
  return getUniqueRoots(currentRoot, threadPersonalRoot);
}

export function getProfileEngagementRoots(currentRoot: CID, profilePersonalRoot: CID | null): CID[] {
  return profilePersonalRoot ? [currentRoot, profilePersonalRoot] : [currentRoot];
}

export function getEngagementRootsForEvent(
  route: Route,
  currentRoot: CID,
  event: RawEvent,
  profilePersonalRoot: CID | null,
  threadPersonalRoot: CID | null,
): CID[] {
  if (route.kind === 'profile' && route.pubkey === event.pubkey) {
    return getProfileEngagementRoots(currentRoot, profilePersonalRoot);
  }

  if (route.kind === 'thread') {
    return getThreadRoots(currentRoot, threadPersonalRoot);
  }

  return [currentRoot];
}

export function buildSeededNoteEngagements(noteIds: string[]): Map<string, NoteEngagement> {
  return new Map(noteIds.map((noteId) => [noteId, {
    ...ZERO_NOTE_ENGAGEMENT,
  }]));
}

export function addOptimisticLike(
  optimisticEngagements: Map<string, { reactionCountDelta: number; viewerReacted: boolean }>,
  noteId: string,
): Map<string, { reactionCountDelta: number; viewerReacted: boolean }> {
  const nextOptimistic = new Map(optimisticEngagements);
  nextOptimistic.set(noteId, {
    reactionCountDelta: 1,
    viewerReacted: true,
  });
  return nextOptimistic;
}

export function removeOptimisticLike(
  optimisticEngagements: Map<string, { reactionCountDelta: number; viewerReacted: boolean }>,
  noteId: string,
): Map<string, { reactionCountDelta: number; viewerReacted: boolean }> {
  if (!optimisticEngagements.has(noteId)) {
    return optimisticEngagements;
  }

  const nextOptimistic = new Map(optimisticEngagements);
  nextOptimistic.delete(noteId);
  return nextOptimistic;
}
