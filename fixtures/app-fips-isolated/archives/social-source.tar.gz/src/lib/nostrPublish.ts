import { toHex, type CID } from '@hashtree/core';
import { HASHTREE_LABEL, HASHTREE_ROOT_KIND } from '@hashtree/nostr';
import { finalizeEvent, type EventTemplate } from 'nostr-tools/pure';
import { canSignAccount, signAccountEvent } from './accountSigner';
import {
  accountsStore,
  getAccountSecretKey,
  markAccountUsed,
  type SocialAccount,
} from './accounts';
import { getConfiguredNostrRelays } from './htreeRuntime';
import {
  buildPublicMuteListTags,
  MUTE_LIST_KIND,
  selectNewestMuteListEvent,
} from './muteLists';
import { getAddressableEventCoordinate, normalizePubkey, type RawEvent } from './nostr';
import {
  configurePersonalEventIndexRootPublisher,
  flushPersonalEventIndex,
  indexPersonalEvent,
  isPersonalEventIndexRootDurablyQueued,
  PERSONAL_EVENT_INDEX_TREE_NAME,
} from './personalEventIndexBrowser';
import { socialDataPlane } from './socialDataPlane';
import { buildComposerReferenceTags } from './composerReferences';
import { createPersonalIndexSigner } from './personalIndexSigner';

const personalIndexSigner = createPersonalIndexSigner();

type EventDraft = {
  kind: number;
  content: string;
  tags?: string[][];
  created_at?: number;
};

export const canPublishFromAccount = canSignAccount;

function eventDraft(draft: EventDraft): EventTemplate {
  return { kind: draft.kind, content: draft.content, tags: draft.tags ?? [],
    created_at: draft.created_at ?? Math.floor(Date.now() / 1000) };
}

function signEvent(account: SocialAccount, draft: EventDraft): RawEvent {
  const secretKey = getAccountSecretKey(account);

  const signed = finalizeEvent({
    kind: draft.kind,
    content: draft.content,
    tags: draft.tags ?? [],
    created_at: draft.created_at ?? Math.floor(Date.now() / 1000),
  }, secretKey);

  return {
    id: signed.id,
    pubkey: signed.pubkey,
    created_at: signed.created_at,
    kind: signed.kind,
    tags: signed.tags,
    content: signed.content,
    sig: signed.sig,
  };
}

function buildPersonalEventIndexRootEventDraft(
  account: SocialAccount,
  root: CID,
  createdAt: number,
): EventTemplate {
  const tags: string[][] = [
    ['d', PERSONAL_EVENT_INDEX_TREE_NAME],
    ['l', HASHTREE_LABEL],
    ['hash', toHex(root.hash)],
  ];
  if (root.key) {
    tags.push(['key', toHex(root.key)]);
  }
  return eventDraft({
    kind: HASHTREE_ROOT_KIND,
    content: '',
    tags,
    created_at: createdAt,
  });
}

export function createPersonalEventIndexRootEvent(
  account: SocialAccount,
  root: CID,
  createdAt: number,
): RawEvent {
  return signEvent(account, buildPersonalEventIndexRootEventDraft(account, root, createdAt));
}

export async function createPersonalEventIndexRootEventAsync(
  account: SocialAccount,
  root: CID,
  createdAt: number,
): Promise<RawEvent> {
  return personalIndexSigner.sign(account, buildPersonalEventIndexRootEventDraft(account, root, createdAt));
}

async function deliverSignedEventToRelays(event: RawEvent): Promise<void> {
  const worker = await (await import('./workerClient')).getWorkerClient();
  await worker.publishRelayEvent(getConfiguredNostrRelays(), event);
}

socialDataPlane.setRelayPublisher(deliverSignedEventToRelays);

async function publishSignedEventToPersonalIndex(
  account: SocialAccount,
  event: RawEvent,
): Promise<void> {
  await indexPersonalEvent(account, event);
  await flushPersonalEventIndex(account);
  if (!await isPersonalEventIndexRootDurablyQueued(account.pubkey)) {
    throw new Error('Personal Hashtree root publication remains queued');
  }
}

socialDataPlane.setPersonalIndexPublisher(async (event) => {
  const account = accountsStore.getState().accounts.find((candidate) => (
    candidate.pubkey === event.pubkey && canPublishFromAccount(candidate)
  ));
  if (!account || event.kind === HASHTREE_ROOT_KIND) {
    throw new Error('Personal Hashtree index account is unavailable');
  }
  await publishSignedEventToPersonalIndex(account, event);
});

function publishSignedEvent(
  event: RawEvent,
  options: { indexPersonal?: boolean } = {},
): void {
  const account = options.indexPersonal === false || event.kind === HASHTREE_ROOT_KIND
    ? null
    : accountsStore.getState().accounts.find((candidate) => (
        candidate.pubkey === event.pubkey && canPublishFromAccount(candidate)
      )) ?? null;
  // UI-facing publication stops after this synchronous durable queue. Relay
  // and FIPS acknowledgements belong exclusively to the background outbox.
  socialDataPlane.publishInBackground(
    event,
    () => deliverSignedEventToRelays(event),
    account ? async () => {
      // This callback only runs for this deliberate, durably queued publication.
      // The separate background retry publisher cannot grant new permissions.
      personalIndexSigner.allowForPublication(account);
      await publishSignedEventToPersonalIndex(account, event);
    } : null,
  );
  if (account) {
    markAccountUsed(account.pubkey);
  }
}

export function publishEvent(event: RawEvent): void {
  publishSignedEvent(event);
}

function buildContactsTags(
  follows: string[],
  baseEvent: RawEvent | null = null,
): string[][] {
  const normalizedFollows = [...new Set(
    follows
      .map((value) => normalizePubkey(value))
      .filter((value): value is string => Boolean(value)),
  )];
  const preservedTags = (baseEvent?.tags ?? []).filter((tag) => tag[0] !== 'p');
  return [
    ...preservedTags,
    ...normalizedFollows.map((pubkey) => ['p', pubkey] as string[]),
  ];
}

function buildContactsListEventDraft(
  account: SocialAccount,
  follows: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): EventTemplate {
  return eventDraft({
    kind: 3,
    content: options.baseEvent?.content ?? '',
    tags: buildContactsTags(follows, options.baseEvent ?? null),
    created_at: Math.max(
      Math.floor(Date.now() / 1_000),
      (options.baseEvent?.created_at ?? -1) + 1,
    ),
  });
}

export function createContactsListEvent(
  account: SocialAccount,
  follows: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): RawEvent {
  return signEvent(account, buildContactsListEventDraft(account, follows, options));
}

export async function createContactsListEventAsync(
  account: SocialAccount,
  follows: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): Promise<RawEvent> {
  return signAccountEvent(account, buildContactsListEventDraft(account, follows, options));
}

export function publishContactsList(
  account: SocialAccount,
  follows: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): RawEvent {
  const event = createContactsListEvent(account, follows, options);
  publishSignedEvent(event);
  return event;
}

function buildMuteListEventDraft(
  account: SocialAccount,
  mutedPubkeys: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): EventTemplate {
  const baseEvent = selectNewestMuteListEvent([options.baseEvent], account.pubkey);
  return eventDraft({
    kind: MUTE_LIST_KIND,
    content: baseEvent?.content ?? '',
    tags: buildPublicMuteListTags(baseEvent?.tags ?? [], mutedPubkeys),
    created_at: Math.max(
      Math.floor(Date.now() / 1_000),
      (baseEvent?.created_at ?? -1) + 1,
    ),
  });
}

export function createMuteListEvent(
  account: SocialAccount,
  mutedPubkeys: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): RawEvent {
  return signEvent(account, buildMuteListEventDraft(account, mutedPubkeys, options));
}

export async function createMuteListEventAsync(
  account: SocialAccount,
  mutedPubkeys: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): Promise<RawEvent> {
  return signAccountEvent(account, buildMuteListEventDraft(account, mutedPubkeys, options));
}

export function publishMuteList(
  account: SocialAccount,
  mutedPubkeys: string[],
  options: {
    baseEvent?: RawEvent | null;
  } = {},
): RawEvent {
  const event = createMuteListEvent(account, mutedPubkeys, options);
  publishSignedEvent(event);
  return event;
}

function buildTextNoteDraft(account: SocialAccount, content: string): EventTemplate {
  return eventDraft({
    kind: 1,
    content: content.trim(),
    tags: buildComposerReferenceTags(content),
  });
}

export function createTextNote(account: SocialAccount, content: string): RawEvent {
  return signEvent(account, buildTextNoteDraft(account, content));
}

export async function createTextNoteAsync(account: SocialAccount, content: string): Promise<RawEvent> {
  return signAccountEvent(account, buildTextNoteDraft(account, content));
}

export function publishTextNote(account: SocialAccount, content: string): RawEvent {
  const event = createTextNote(account, content);
  publishSignedEvent(event);
  return event;
}

function buildDeletionDraft(account: SocialAccount, target: RawEvent): EventTemplate {
  const accountPubkey = normalizePubkey(account.pubkey);
  const targetPubkey = normalizePubkey(target.pubkey);
  if (!accountPubkey || !targetPubkey || accountPubkey !== targetPubkey) {
    throw new Error('You can only delete your own post.');
  }

  return eventDraft({
    kind: 5,
    content: '',
    tags: [
      ['e', target.id],
      ['k', `${target.kind}`],
    ],
  });
}

export function createDeletionEvent(account: SocialAccount, target: RawEvent): RawEvent {
  return signEvent(account, buildDeletionDraft(account, target));
}

export async function createDeletionEventAsync(account: SocialAccount, target: RawEvent): Promise<RawEvent> {
  return signAccountEvent(account, buildDeletionDraft(account, target));
}

export function publishDeletion(account: SocialAccount, target: RawEvent): RawEvent {
  const event = createDeletionEvent(account, target);
  publishSignedEvent(event);
  return event;
}

function buildReplyTags(target: RawEvent, root: RawEvent | null = null): string[][] {
  const rootTarget = root ?? target;
  const tags: string[][] = [
    ['e', rootTarget.id, '', 'root', rootTarget.pubkey],
    ['e', target.id, '', 'reply', target.pubkey],
    ['p', target.pubkey],
  ];

  if (rootTarget.pubkey !== target.pubkey) {
    tags.push(['p', rootTarget.pubkey]);
  }

  if (target.kind !== 1) {
    tags.push(['k', `${target.kind}`]);
  }

  const rootAddress = getAddressableEventCoordinate(rootTarget);
  const targetAddress = getAddressableEventCoordinate(target);
  if (rootAddress) {
    tags.push(['a', rootAddress, '', 'root']);
  }
  if (targetAddress && targetAddress !== rootAddress) {
    tags.push(['a', targetAddress, '', 'reply']);
  }

  return tags;
}

function buildReplyNoteDraft(
  account: SocialAccount,
  target: RawEvent,
  content: string,
  options: {
    root?: RawEvent | null;
  } = {},
): EventTemplate {
  return eventDraft({
    kind: 1,
    content: content.trim(),
    tags: buildComposerReferenceTags(content, buildReplyTags(target, options.root ?? null)),
  });
}

export function createReplyNote(
  account: SocialAccount,
  target: RawEvent,
  content: string,
  options: {
    root?: RawEvent | null;
  } = {},
): RawEvent {
  return signEvent(account, buildReplyNoteDraft(account, target, content, options));
}

export async function createReplyNoteAsync(
  account: SocialAccount,
  target: RawEvent,
  content: string,
  options: {
    root?: RawEvent | null;
  } = {},
): Promise<RawEvent> {
  return signAccountEvent(account, buildReplyNoteDraft(account, target, content, options));
}

export function publishReply(
  account: SocialAccount,
  target: RawEvent,
  content: string,
  options: {
    root?: RawEvent | null;
  } = {},
): RawEvent {
  const event = createReplyNote(account, target, content, options);
  publishSignedEvent(event);
  return event;
}

function buildReactionDraft(account: SocialAccount, target: RawEvent, content = '+'): EventTemplate {
  const tags: string[][] = [
    ['e', target.id, '', '', target.pubkey],
    ['p', target.pubkey],
  ];

  if (target.kind !== 1) {
    tags.push(['k', `${target.kind}`]);
  }

  return eventDraft({
    kind: 7,
    content,
    tags,
  });
}

export function publishReaction(account: SocialAccount, target: RawEvent, content = '+'): RawEvent {
  const event = signEvent(account, buildReactionDraft(account, target, content));
  publishSignedEvent(event);
  return event;
}

export async function createReactionEventAsync(account: SocialAccount, target: RawEvent, content = '+'): Promise<RawEvent> {
  return signAccountEvent(account, buildReactionDraft(account, target, content));
}

function buildZapRequestEventDraft(
  account: SocialAccount,
  target: RawEvent,
  options: {
    amountMillisats: number;
    relays?: string[];
    lnurl?: string | null;
    comment?: string;
  },
): EventTemplate {
  const relays = [...new Set((options.relays?.length ? options.relays : getConfiguredNostrRelays()))];
  const tags: string[][] = [
    ['relays', ...relays],
    ['amount', `${Math.max(0, Math.floor(options.amountMillisats))}`],
    ['p', target.pubkey],
    ['e', target.id],
  ];

  if (target.kind !== 1) {
    tags.push(['k', `${target.kind}`]);
  }

  if (options.lnurl) {
    tags.push(['lnurl', options.lnurl]);
  }

  return eventDraft({
    kind: 9734,
    content: options.comment?.trim() ?? '',
    tags,
  });
}

export function createZapRequestEvent(
  account: SocialAccount,
  target: RawEvent,
  options: {
    amountMillisats: number;
    relays?: string[];
    lnurl?: string | null;
    comment?: string;
  },
): RawEvent {
  return signEvent(account, buildZapRequestEventDraft(account, target, options));
}

export async function createZapRequestEventAsync(
  account: SocialAccount,
  target: RawEvent,
  options: {
    amountMillisats: number;
    relays?: string[];
    lnurl?: string | null;
    comment?: string;
  },
): Promise<RawEvent> {
  return signAccountEvent(account, buildZapRequestEventDraft(account, target, options));
}

function buildRepostEventDraft(account: SocialAccount, target: RawEvent): EventTemplate {
  const tags: string[][] = [
    ['e', target.id, '', '', target.pubkey],
    ['p', target.pubkey],
  ];

  if (target.kind !== 1) {
    tags.push(['k', `${target.kind}`]);
  }

  return eventDraft({
    kind: 6,
    content: JSON.stringify(target),
    tags,
  });
}

export function createRepostEvent(account: SocialAccount, target: RawEvent): RawEvent {
  return signEvent(account, buildRepostEventDraft(account, target));
}

export async function createRepostEventAsync(account: SocialAccount, target: RawEvent): Promise<RawEvent> {
  return signAccountEvent(account, buildRepostEventDraft(account, target));
}

export function publishRepost(account: SocialAccount, target: RawEvent): RawEvent {
  const event = createRepostEvent(account, target);
  publishSignedEvent(event);
  return event;
}

configurePersonalEventIndexRootPublisher(async (account, root, createdAt) => {
  const event = await createPersonalEventIndexRootEventAsync(account, root, createdAt);
  publishSignedEvent(event, { indexPersonal: false });
});
