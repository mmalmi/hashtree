import type { NostrFilter, NostrVerifiedEvent, QueryOptions, QueryReport } from 'nostr-pubsub';
import { awaitWithin } from './feedIndexTiming';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { isHexEventId, type RawEvent } from './nostr';
import { NOTIFICATION_EVENT_KINDS } from './notificationPagination';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';
import { createRelayHistoryPages } from './relayHistory';
import { settingsStore } from './settings';

/** Like Iris Client, one relay page asks for the newest 100 addressed events. */
export const NOTIFICATION_RELAY_PAGE_LIMIT = 100;
export const NOTIFICATION_RELAY_NETWORK_WINDOW_MS = 3_500;
// The worker returns verified partial results at its network deadline. Leave
// time for that reply to arrive before the outer request is cancelled.
const NOTIFICATION_RELAY_RESPONSE_WINDOW_MS = NOTIFICATION_RELAY_NETWORK_WINDOW_MS + 1_500;
export const NOTIFICATION_TARGET_BATCH_LIMIT = 128;

/** Reads one relay set through the worker's verified relay reader. */
type ReceivedEvents = (events: readonly NostrVerifiedEvent[]) => void;

export type NotificationRelayRead = (
  relays: readonly string[],
  filters: NostrFilter[],
  options: QueryOptions,
  onEvents?: ReceivedEvents,
) => Promise<QueryReport>;

export type NotificationRelayPage = {
  /** The next addressed events, newest first. */
  events: RawEvent[];
  /** Where the next page continues. */
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
};

const HEX_PUBKEY = /^[0-9a-f]{64}$/;

async function defaultRead(
  relays: readonly string[],
  filters: NostrFilter[],
  options: QueryOptions,
  onEvents?: ReceivedEvents,
): Promise<QueryReport> {
  const { createWorkerRelayEventReader } = await import('./workerRelayEventReader');
  return await createWorkerRelayEventReader({ getRelays: () => relays, onEvents }).query(filters, options);
}

/** A failed or late relay read is an empty contribution, never a route error. */
async function readWithin(
  read: NotificationRelayRead,
  relays: readonly string[],
  filters: NostrFilter[],
  options: { limit: number; now: number; signal?: AbortSignal },
  onEvents: ReceivedEvents,
): Promise<RawEvent[]> {
  const signals = [AbortSignal.timeout(NOTIFICATION_RELAY_RESPONSE_WINDOW_MS)];
  if (options.signal) {signals.push(options.signal);}
  const received = new Map<string, RawEvent>();
  try {
    const result = await awaitWithin(read(relays, filters, {
      limit: options.limit,
      deadline: options.now + NOTIFICATION_RELAY_NETWORK_WINDOW_MS,
      signal: AbortSignal.any(signals),
    }, batch => {
      for (const event of batch) { received.set(event.id, event); }
      onEvents(batch);
    }), NOTIFICATION_RELAY_RESPONSE_WINDOW_MS);
    if (result.settled) { return result.value.events.map(({ event }) => event); }
  } catch (error) {
    options.signal?.throwIfAborted();
    console.warn('Notification relay read failed', error);
  }
  options.signal?.throwIfAborted();
  return [...received.values()];
}

/**
 * Ask each relay on its own so one slow or unreachable relay cannot hold back
 * the others: results are reported as each relay answers.
 */
async function readEachRelay(
  read: NotificationRelayRead,
  relays: readonly string[],
  filters: NostrFilter[],
  options: { limit: number; now: number; signal?: AbortSignal },
  onRelay: (events: readonly RawEvent[], finished: boolean) => void,
): Promise<void> {
  await Promise.all([...new Set(relays)].map(async (relay) => {
    const events = await readWithin(read, [relay], filters, options, batch => onRelay(batch, false));
    onRelay(events, true);
  }));
}

/** Addressed activity is recent feed activity: it shares that relay setting. */
export function canReadNotificationsFromRelays(): boolean {
  return typeof window !== 'undefined'
    && navigator.onLine
    && settingsStore.getState().network.relayHomeFeedReads
    && getConfiguredNostrRelays().length > 0;
}

export function buildNotificationRelayFilter(
  viewerPubkey: string,
  options: { before?: RecentTextNoteCursor | null; limit?: number } = {},
): NostrFilter {
  const limit = Math.max(1, Math.min(
    NOTIFICATION_RELAY_PAGE_LIMIT,
    Math.trunc(options.limit ?? NOTIFICATION_RELAY_PAGE_LIMIT),
  ));
  return {
    kinds: [...NOTIFICATION_EVENT_KINDS],
    '#p': [viewerPubkey.trim().toLowerCase()],
    limit,
    // `until` is inclusive. The exact cursor removes the boundary event below.
    ...(options.before ? { until: options.before.createdAt } : {}),
  };
}

function addressesViewer(event: RawEvent, viewerPubkey: string): boolean {
  return event.tags.some((tag) => tag[0] === 'p' && tag[1]?.toLowerCase() === viewerPubkey);
}

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

const notificationRelayPages = createRelayHistoryPages((viewer) => buildNotificationRelayFilter(viewer));

/**
 * Read the next newest-first page of events addressed to the viewer. Relays
 * page through the worker's per-relay history cursors, so a relay that caps or
 * times out cannot end the list early or push older events above newer ones.
 */
export async function readNotificationRelayPage(options: {
  viewerPubkey: string;
  before?: RecentTextNoteCursor | null;
  limit?: number;
  signal?: AbortSignal;
  onProgress?: (page: NotificationRelayPage) => void;
  pages?: Pick<ReturnType<typeof createRelayHistoryPages>, 'load'>;
}): Promise<NotificationRelayPage> {
  const viewer = options.viewerPubkey.trim().toLowerCase();
  const before = options.before ?? null;
  if (!HEX_PUBKEY.test(viewer)) {
    return { events: [], cursor: before, hasMore: false };
  }
  const limit = buildNotificationRelayFilter(viewer, options).limit!;
  const page = await (options.pages ?? notificationRelayPages).load(viewer, limit, before, options.signal);
  const supportedKinds = new Set<number>(NOTIFICATION_EVENT_KINDS);
  const result: NotificationRelayPage = {
    events: page.events.filter((event) => (
      supportedKinds.has(event.kind)
      && addressesViewer(event, viewer)
      && isStrictlyBeforeRecentCursor(event.created_at, event.id, before ?? undefined)
    )).sort(compareNewest),
    cursor: page.cursor,
    hasMore: page.hasMore,
  };
  if (result.events.length) { options.onProgress?.(result); }
  return result;
}

/** Load the viewer's posts that reactions, reposts and zaps point at. */
export async function readNotificationRelayTargets(options: {
  ids: readonly string[];
  signal?: AbortSignal;
  read?: NotificationRelayRead;
  relays?: readonly string[];
  now?: number;
  onProgress?: (targets: Map<string, RawEvent>) => void;
}): Promise<Map<string, RawEvent>> {
  const ids = [...new Set(options.ids.map((id) => id.toLowerCase()).filter(isHexEventId))]
    .slice(0, NOTIFICATION_TARGET_BATCH_LIMIT);
  const targets = new Map<string, RawEvent>();
  const relays = options.relays ?? getConfiguredNostrRelays();
  if (ids.length === 0 || relays.length === 0) {return targets;}
  const wanted = new Set(ids);
  await readEachRelay(options.read ?? defaultRead, relays, [{ ids, limit: ids.length }], {
    limit: ids.length,
    now: options.now ?? Date.now(),
    signal: options.signal,
  }, (relayEvents) => {
    let added = false;
    for (const event of relayEvents) {
      if (wanted.has(event.id) && !targets.has(event.id)) {
        targets.set(event.id, event);
        added = true;
      }
    }
    if (added) {options.onProgress?.(new Map(targets));}
  });
  return targets;
}
