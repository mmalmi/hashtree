import type { CID } from '@hashtree/core';
import type {
  NostrFilter,
  NostrVerifiedEvent,
  QueryOptions,
  QueryReport,
} from 'nostr-pubsub';
import {
  isBrowserRelayContentEnabled,
  queryBrowserEvents,
  queryBrowserLiveTailEvents,
} from './browserEventReadRouter';
import {
  decodeNostrEventReference,
  isHexEventId,
  isHexPubkey,
  isReplyEvent,
  type ProfileRecord,
} from './nostr';
import { DURABLE_POST_KINDS } from './recentAuthorFeedReader';
import { mergeProfileMaps, profileMapFromMetadataEvents } from './profileRecords';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';

const MAX_PROFILE_AUTHORS_PER_QUERY = 128;
const PROFILE_HISTORY_PAGE_SIZE = 500;
const MAX_ROUTED_AUTHORS_PER_QUERY = 128;
const MAX_CONCURRENT_ROUTED_AUTHOR_QUERIES = 2;
const MAX_ROUTED_EVENT_KINDS = 32;
const MAX_ROUTED_AUTHOR_EVENTS = 1_024;
export const MAX_ROUTED_ENGAGEMENT_TARGETS = 64;
export const MAX_ROUTED_ENGAGEMENT_EVENTS = 600;
const MAX_ROUTED_RELAY_QUERY_EVENTS = 256;
const MAX_ROUTED_ENGAGEMENT_KINDS = 16;
const MAX_ROUTED_ENGAGEMENT_INPUT_VALUES = 256;
const MAX_ROUTED_ENGAGEMENT_EVENT_TAGS = 256;

type BrowserEventQuery = (
  roots: CID[],
  filters: NostrFilter[],
  options?: QueryOptions,
) => Promise<Pick<QueryReport, 'events' | 'complete'>>;

export async function routedEventById(
  roots: CID[],
  eventId: string,
): Promise<NostrVerifiedEvent | null> {
  if (!isHexEventId(eventId)) {return null;}
  const report = await queryBrowserEvents(roots, [{ ids: [eventId], limit: 1 }], { limit: 1 });
  return report.events[0]?.event ?? null;
}

export async function routedEventByRef(
  roots: CID[],
  reference: string,
): Promise<NostrVerifiedEvent | null> {
  const trimmed = reference.trim().startsWith('nostr:')
    ? reference.trim().slice('nostr:'.length)
    : reference.trim();
  if (!trimmed) {return null;}
  if (isHexEventId(trimmed)) {return await routedEventById(roots, trimmed);}
  const decoded = decodeNostrEventReference(trimmed);
  if (!decoded) {return null;}
  if (decoded.type === 'note' || decoded.type === 'nevent') {
    return await routedEventById(roots, decoded.eventId);
  }
  const report = await queryBrowserEvents(roots, [{
    authors: [decoded.pubkey],
    kinds: [decoded.kind],
    '#d': [decoded.identifier],
    limit: 8,
  }], { limit: 8 });
  return report.events[0]?.event ?? null;
}

export async function routedEventsByTag(
  roots: CID[],
  tagName: string,
  tagValue: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: typeof queryBrowserEvents = queryBrowserEvents,
): Promise<NostrVerifiedEvent[]> {
  if (!tagName || !tagValue || kinds.length === 0 || limit <= 0) {return [];}
  const queryLimit = before ? Math.max(limit * 2, limit + 16) : limit;
  const filter: NostrFilter = {
    kinds: [...kinds],
    limit: queryLimit,
    ...(before ? { until: before.createdAt } : {}),
  };
  filter[`#${tagName}`] = [tagValue];
  const report = await query(roots, [filter], { limit: queryLimit });
  return report.events
    .map(({ event }) => event)
    .filter((event) => isStrictlyBeforeRecentCursor(event.created_at, event.id, before))
    .slice(0, limit);
}

/**
 * Read one bounded newest-first author/kind page through the resident event
 * router. Hashtree traversal, decoding, and signature admission stay in the
 * worker instead of becoming one renderer request per stored event.
 */
export async function routedEventsByAuthors(
  roots: CID[],
  authors: readonly string[],
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  options: {
    query?: BrowserEventQuery;
    signal?: AbortSignal;
  } = {},
): Promise<NostrVerifiedEvent[]> {
  const normalizedAuthors = [...new Set(authors
    .map((author) => author.trim().toLowerCase())
    .filter(isHexPubkey))];
  const normalizedKinds = [...new Set(kinds
    .filter((kind) => Number.isSafeInteger(kind) && kind >= 0))]
    .slice(0, MAX_ROUTED_EVENT_KINDS);
  const requestedLimit = Number.isFinite(limit)
    ? Math.max(0, Math.trunc(limit))
    : 0;
  if (
    normalizedAuthors.length === 0
    || normalizedKinds.length === 0
    || requestedLimit === 0
  ) {
    return [];
  }

  options.signal?.throwIfAborted();
  const resultLimit = Math.min(requestedLimit, MAX_ROUTED_AUTHOR_EVENTS);
  const queryLimit = Math.min(
    before ? Math.max(resultLimit * 2, resultLimit + 16) : resultLimit,
    MAX_ROUTED_AUTHOR_EVENTS,
  );
  const query = options.query ?? queryBrowserEvents;
  let nextAuthor = 0;
  let failed = false;
  let events: NostrVerifiedEvent[] = [];
  const readBatches = async (): Promise<void> => {
    try {
      while (!failed && nextAuthor < normalizedAuthors.length) {
        options.signal?.throwIfAborted();
        const batch = normalizedAuthors.slice(nextAuthor, nextAuthor + MAX_ROUTED_AUTHORS_PER_QUERY);
        nextAuthor += batch.length;
        const report = await query(roots, [{
          authors: batch,
          kinds: normalizedKinds,
          limit: queryLimit,
          ...(before ? { until: before.createdAt } : {}),
        }], { limit: queryLimit, signal: options.signal });
        options.signal?.throwIfAborted();
        // Array-only callers use a short page as exhaustion. An unfinished
        // read cannot safely advance their cursor or stand in for absence.
        if (report.complete === false) {throw new Error('Author page read is incomplete');}
        const merged = new Map(events.map((event) => [event.id, event]));
        for (const { event } of report.events) {
          if (
            batch.includes(event.pubkey)
            && normalizedKinds.includes(event.kind)
            && isStrictlyBeforeRecentCursor(event.created_at, event.id, before)
          ) {merged.set(event.id, event);}
        }
        events = [...merged.values()]
          .sort((left, right) => right.created_at - left.created_at || left.id.localeCompare(right.id))
          .slice(0, resultLimit);
      }
    } catch (error) {
      failed = true;
      throw error;
    }
  };
  await Promise.all(Array.from({
    length: Math.min(MAX_CONCURRENT_ROUTED_AUTHOR_QUERIES, Math.ceil(normalizedAuthors.length / MAX_ROUTED_AUTHORS_PER_QUERY)),
  }, readBatches));
  return events;
}

/** Read the newest available replaceable candidate, including when other roots are offline. */
export async function routedLatestEventByAuthorKind(
  roots: CID[],
  pubkey: string,
  kind: number,
  options: { signal?: AbortSignal; query?: BrowserEventQuery } = {},
): Promise<NostrVerifiedEvent | null> {
  const author = pubkey.trim().toLowerCase();
  if (!isHexPubkey(author) || !Number.isSafeInteger(kind) || kind < 0) {return null;}
  options.signal?.throwIfAborted();
  const report = await (options.query ?? queryBrowserEvents)(roots, [{
    authors: [author], kinds: [kind], limit: 8,
  }], { limit: 8, signal: options.signal });
  options.signal?.throwIfAborted();
  const events = report.events.map(({ event }) => event)
    .filter((event) => event.pubkey === author && event.kind === kind)
    .sort((left, right) => right.created_at - left.created_at || left.id.localeCompare(right.id));
  // A verified candidate can restore local state; an unfinished empty read
  // cannot establish absence. Paginated author reads remain strictly complete.
  if (report.complete === false && events.length === 0) {
    throw new Error('Author state read is incomplete');
  }
  return events[0] ?? null;
}

export async function routedRecentTextNotesByAuthors(
  roots: CID[],
  authors: readonly string[],
  limit: number,
  options: {
    before?: RecentTextNoteCursor;
    includeReplies?: boolean;
    signal?: AbortSignal;
    query?: BrowserEventQuery;
  } = {},
): Promise<NostrVerifiedEvent[]> {
  const requestedLimit = Number.isFinite(limit) ? Math.max(0, Math.trunc(limit)) : 0;
  if (requestedLimit === 0) {
    return [];
  }
  const scanLimit = Math.min(
    Math.max(requestedLimit * 6, requestedLimit + 16),
    MAX_ROUTED_AUTHOR_EVENTS,
  );
  return (await routedEventsByAuthors(
    roots,
    authors,
    DURABLE_POST_KINDS,
    scanLimit,
    options.before,
    { signal: options.signal, query: options.query },
  )).filter((event) => (
    options.includeReplies === true || event.kind !== 1 || !isReplyEvent(event)
  )).slice(0, requestedLimit);
}

export async function routedProfileHistory(
  roots: CID[],
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: BrowserEventQuery = queryBrowserEvents,
): Promise<NostrVerifiedEvent[]> {
  if (!isHexPubkey(pubkey) || kinds.length === 0 || limit <= 0) {return [];}
  const normalizedPubkey = pubkey.toLowerCase();
  const events = new Map<string, NostrVerifiedEvent>();
  let cursor = before;
  const maxPages = Math.ceil(limit / PROFILE_HISTORY_PAGE_SIZE) + 2;

  for (let page = 0; page < maxPages && events.size < limit; page += 1) {
    const remaining = limit - events.size;
    const queryLimit = Math.min(
      PROFILE_HISTORY_PAGE_SIZE,
      remaining + (cursor ? 1 : 0),
    );
    const filter: NostrFilter = {
      authors: [normalizedPubkey],
      kinds: [...kinds],
      limit: queryLimit,
      ...(cursor ? { until: cursor.createdAt } : {}),
    };
    const report = await query(roots, [filter], { limit: queryLimit });
    const candidates = report.events
      .map(({ event }) => event)
      .filter((event) => (
        event.pubkey === normalizedPubkey
        && kinds.includes(event.kind)
        && isStrictlyBeforeRecentCursor(event.created_at, event.id, cursor)
      ))
      .sort((left, right) => (
        right.created_at - left.created_at || left.id.localeCompare(right.id)
      ));
    let added = 0;
    for (const event of candidates) {
      if (!events.has(event.id)) {
        events.set(event.id, event);
        added += 1;
      }
      if (events.size >= limit) {
        break;
      }
    }
    const boundary = candidates.at(-1);
    if (!boundary || added === 0) {
      break;
    }
    cursor = { createdAt: boundary.created_at, eventId: boundary.id };
    if (report.events.length < queryLimit) {
      break;
    }
  }

  return [...events.values()]
    .sort((left, right) => (
      right.created_at - left.created_at || left.id.localeCompare(right.id)
    ))
    .slice(0, limit);
}

/** Query only the bounded live/relay tail for one author's event history. */
export async function routedLiveProfileHistory(
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  queryLiveTail: typeof queryBrowserLiveTailEvents = queryBrowserLiveTailEvents,
): Promise<NostrVerifiedEvent[]> {
  return await routedProfileHistory(
    [],
    pubkey,
    kinds,
    limit,
    before,
    async (_roots, filters, options) => await queryLiveTail(filters, options),
  );
}

/**
 * Runs one per-target Nostr filter batch through the shared router, then
 * restores the per-target result sets after the router deduplicates events.
 * Filter limits remain per target; no accidental global limit is applied.
 */
export async function routedEventsByTagValues(
  roots: CID[],
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  query: typeof queryBrowserEvents = queryBrowserEvents,
): Promise<Map<string, NostrVerifiedEvent[]>> {
  return await queryEventsByTagValues(
    tagName,
    tagValues,
    kinds,
    limitPerValue,
    async (filters, options) => await query(roots, filters, options),
  );
}

type RoutedEngagementDeps = {
  isLiveTailEnabled?: () => boolean;
  queryAll?: typeof queryBrowserEvents;
  queryLiveTail?: (
    filters: NostrFilter[],
    options?: QueryOptions,
  ) => Promise<QueryReport>;
  signal?: AbortSignal;
};

/**
 * Keep visible engagement reads off slow broad archives when a relay tail is
 * active. Unlike general tag reads, this path uses one multi-value filter and
 * one aggregate event cap: a visible set can never expand into one hundreds-
 * deep scan per note.
 */
export async function routedEngagementEventsByTagValues(
  roots: CID[],
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  deps: RoutedEngagementDeps = {},
): Promise<Map<string, NostrVerifiedEvent[]>> {
  const liveTailEnabled = deps.isLiveTailEnabled ?? isBrowserRelayContentEnabled;
  const useLiveTail = liveTailEnabled();
  const query = useLiveTail
    ? deps.queryLiveTail ?? queryBrowserLiveTailEvents
    : async (filters: NostrFilter[], options?: QueryOptions) => (
      await (deps.queryAll ?? queryBrowserEvents)(roots, filters, options)
    );
  return await queryAggregateEngagementEventsByTagValues(
    'e',
    tagValues,
    kinds,
    limitPerValue,
    query,
    deps.signal,
    useLiveTail ? MAX_ROUTED_RELAY_QUERY_EVENTS : MAX_ROUTED_ENGAGEMENT_EVENTS,
  );
}

async function queryAggregateEngagementEventsByTagValues(
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  requestedEventLimit: number,
  query: (
    filters: NostrFilter[],
    options?: QueryOptions,
  ) => Promise<Pick<QueryReport, 'events'>>,
  signal?: AbortSignal,
  maximumEventLimit: number = MAX_ROUTED_ENGAGEMENT_EVENTS,
): Promise<Map<string, NostrVerifiedEvent[]>> {
  if (!tagName || requestedEventLimit <= 0) {return new Map();}
  const values: string[] = [];
  const seenValues = new Set<string>();
  for (
    let index = 0;
    index < Math.min(tagValues.length, MAX_ROUTED_ENGAGEMENT_INPUT_VALUES)
      && values.length < MAX_ROUTED_ENGAGEMENT_TARGETS;
    index += 1
  ) {
    const value = normalizeTagQueryValue(tagName, tagValues[index] ?? '');
    if (!value || seenValues.has(value)) {continue;}
    seenValues.add(value);
    values.push(value);
  }
  const normalizedKinds = [...new Set(kinds
    .slice(0, MAX_ROUTED_ENGAGEMENT_KINDS)
    .filter((kind) => (
    Number.isSafeInteger(kind) && kind >= 0
  )))];
  if (values.length === 0 || normalizedKinds.length === 0) {return new Map();}

  signal?.throwIfAborted();
  const eventLimit = Math.min(
    Math.max(1, Math.trunc(requestedEventLimit)),
    maximumEventLimit,
  );
  const filter: NostrFilter = {
    kinds: normalizedKinds,
    limit: eventLimit,
  };
  filter[`#${tagName}`] = values;
  const report = await query(
    [filter],
    { limit: eventLimit, ...(signal ? { signal } : {}) },
  );
  signal?.throwIfAborted();

  const grouped = new Map(values.map((value) => [value, [] as NostrVerifiedEvent[]]));
  for (const { event } of report.events.slice(0, eventLimit)) {
    const targets = new Set<string>();
    for (
      let index = 0;
      index < Math.min(event.tags.length, MAX_ROUTED_ENGAGEMENT_EVENT_TAGS);
      index += 1
    ) {
      const tag = event.tags[index]!;
      if (tag[0] !== tagName) {continue;}
      const value = normalizeTagQueryValue(tagName, tag[1] ?? '');
      if (value && grouped.has(value)) {
        targets.add(value);
      }
    }
    for (const target of targets) {
      grouped.get(target)!.push(event);
    }
  }
  return grouped;
}

async function queryEventsByTagValues(
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  query: (
    filters: NostrFilter[],
    options?: QueryOptions,
  ) => Promise<Pick<QueryReport, 'events'>>,
): Promise<Map<string, NostrVerifiedEvent[]>> {
  if (!tagName || kinds.length === 0 || limitPerValue <= 0) {return new Map();}
  const values = [...new Set(tagValues
    .map((value) => normalizeTagQueryValue(tagName, value))
    .filter((value): value is string => value !== null))]
    .sort();
  if (values.length === 0) {return new Map();}

  const filters = values.map((value): NostrFilter => {
    const filter: NostrFilter = { kinds: [...kinds], limit: limitPerValue };
    filter[`#${tagName}`] = [value];
    return filter;
  });
  const report = await query(filters, {});
  const grouped = new Map(values.map((value) => [value, [] as NostrVerifiedEvent[]]));
  for (const { event } of report.events) {
    const targets = new Set(event.tags.flatMap((tag) => {
      if (tag[0] !== tagName) {return [];}
      const value = normalizeTagQueryValue(tagName, tag[1] ?? '');
      return value && grouped.has(value) ? [value] : [];
    }));
    for (const target of targets) {
      grouped.get(target)!.push(event);
    }
  }
  return grouped;
}

function normalizeTagQueryValue(tagName: string, rawValue: string): string | null {
  const value = rawValue.trim();
  if (!value) {return null;}
  if (tagName === 'e' || tagName === 'p') {
    return /^[0-9a-f]{64}$/i.test(value) ? value.toLowerCase() : null;
  }
  return tagName === 't' ? value.toLowerCase() : value;
}

/** Resolve signed profile metadata through the one application event router. */
export async function routedProfilesByPubkey(
  roots: CID[],
  pubkeys: readonly string[],
  options: { signal?: AbortSignal } = {},
): Promise<Map<string, ProfileRecord>> {
  const authors = [...new Set(pubkeys
    .map((pubkey) => pubkey.trim().toLowerCase())
    .filter(isHexPubkey))]
    .sort();
  if (authors.length === 0) {return new Map();}

  const queries: Array<Promise<Map<string, ProfileRecord>>> = [];
  for (let offset = 0; offset < authors.length; offset += MAX_PROFILE_AUTHORS_PER_QUERY) {
    const chunk = authors.slice(offset, offset + MAX_PROFILE_AUTHORS_PER_QUERY);
    queries.push(queryBrowserEvents(roots, [{
      kinds: [0],
      authors: chunk,
      limit: chunk.length,
    }], {
      limit: chunk.length,
      signal: options.signal,
    }).then((report) => profileMapFromMetadataEvents(
      report.events.map(({ event }) => event),
    )));
  }
  return mergeProfileMaps(...await Promise.all(queries));
}
