import type { CID } from '@hashtree/core';
import type {
  NostrFilter,
  NostrVerifiedEvent,
  QueryOptions,
  QueryReport,
} from 'nostr-pubsub';
import { queryBrowserEvents } from './browserEventReadRouter';
import {
  decodeNostrEventReference,
  isHexEventId,
  isHexPubkey,
  isReplyEvent,
  type ProfileRecord,
} from './nostr';
import { DURABLE_POST_KINDS } from './recentAuthorFeedReader';
import { mergeProfileMaps, profileMapFromMetadataEvents } from './profileRecords';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';

const MAX_PROFILE_AUTHORS_PER_QUERY = 128;
const PROFILE_HISTORY_PAGE_SIZE = 500;
const MAX_ROUTED_AUTHORS_PER_QUERY = 128;
const MAX_CONCURRENT_ROUTED_AUTHOR_QUERIES = 2;
const MAX_ROUTED_EVENT_KINDS = 32;
const MAX_ROUTED_AUTHOR_EVENTS = 1_024;
export const MAX_ROUTED_ENGAGEMENT_TARGETS = 64;
export const MAX_ROUTED_ENGAGEMENT_EVENTS = 600;
const MAX_ROUTED_ENGAGEMENT_KINDS = 16;
const MAX_ROUTED_ENGAGEMENT_INPUT_VALUES = 256;
const MAX_ROUTED_ENGAGEMENT_EVENT_TAGS = 256;

type BrowserEventQuery = (
  roots: CID[],
  filters: NostrFilter[],
  options?: QueryOptions,
) => Promise<Pick<QueryReport, 'events' | 'complete'>>;

/**
 * Cache, Hashtree index and live overlay only, for feeds that still read
 * relays themselves (For You, Latest paging, notifications).
 */
export const queryArchiveEvents: BrowserEventQuery = async (roots, filters, options) => (
  await queryBrowserEvents(roots, filters, options, 'archive')
);

export async function routedEventById(
  roots: CID[],
  eventId: string,
): Promise<NostrVerifiedEvent | null> {
  if (!isHexEventId(eventId)) {return null;}
  const report = await queryBrowserEvents(roots, [{ ids: [eventId], limit: 1 }], { limit: 1 });
  return report.events[0]?.event ?? null;
}

export async function routedEventsByIds(
  roots: CID[],
  eventIds: readonly string[],
): Promise<Map<string, NostrVerifiedEvent>> {
  const ids = [...new Set(eventIds.map((id) => id.trim().toLowerCase()).filter(isHexEventId))];
  const events = new Map<string, NostrVerifiedEvent>();
  const chunks = Array.from(
    { length: Math.ceil(ids.length / MAX_ROUTED_AUTHORS_PER_QUERY) },
    (_, i) => ids.slice(i * MAX_ROUTED_AUTHORS_PER_QUERY, (i + 1) * MAX_ROUTED_AUTHORS_PER_QUERY),
  );
  await Promise.all(chunks.map(async (chunk) => {
    const report = await queryBrowserEvents(roots, [{ ids: chunk, limit: chunk.length }], { limit: chunk.length });
    for (const { event } of report.events) { events.set(event.id, event); }
  }));
  return events;
}

export async function routedEventByRef(
  roots: CID[],
  reference: string,
): Promise<NostrVerifiedEvent | null> {
  const trimmed = reference.trim().startsWith('nostr:')
    ? reference.trim().slice('nostr:'.length)
    : reference.trim();
  if (!trimmed) {return null;}
  if (isHexEventId(trimmed)) {return await routedEventById(roots, trimmed);}
  const decoded = decodeNostrEventReference(trimmed);
  if (!decoded) {return null;}
  if (decoded.type === 'note' || decoded.type === 'nevent') {
    return await routedEventById(roots, decoded.eventId);
  }
  const report = await queryBrowserEvents(roots, [{
    authors: [decoded.pubkey],
    kinds: [decoded.kind],
    '#d': [decoded.identifier],
    limit: 8,
  }], { limit: 8 });
  return report.events[0]?.event ?? null;
}

export async function routedEventsByTag(
  roots: CID[],
  tagName: string,
  tagValue: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: typeof queryBrowserEvents = queryBrowserEvents,
): Promise<NostrVerifiedEvent[]> {
  if (!tagName || !tagValue || kinds.length === 0 || limit <= 0) {return [];}
  const queryLimit = before ? Math.max(limit * 2, limit + 16) : limit;
  const filter: NostrFilter = {
    kinds: [...kinds],
    limit: queryLimit,
    ...(before ? { until: before.createdAt } : {}),
  };
  filter[`#${tagName}`] = [tagValue];
  const report = await query(roots, [filter], { limit: queryLimit });
  return report.events
    .map(({ event }) => event)
    .filter((event) => isStrictlyBeforeRecentCursor(event.created_at, event.id, before))
    .slice(0, limit);
}

/**
 * Read one bounded newest-first author/kind page through the resident event
 * router. Hashtree traversal, decoding, and signature admission stay in the
 * worker instead of becoming one renderer request per stored event.
 */
export async function routedEventsByAuthors(
  roots: CID[],
  authors: readonly string[],
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  options: {
    query?: BrowserEventQuery;
    signal?: AbortSignal;
    allowPartial?: boolean;
  } = {},
): Promise<NostrVerifiedEvent[]> {
  const normalizedAuthors = [...new Set(authors
    .map((author) => author.trim().toLowerCase())
    .filter(isHexPubkey))];
  const normalizedKinds = [...new Set(kinds
    .filter((kind) => Number.isSafeInteger(kind) && kind >= 0))]
    .slice(0, MAX_ROUTED_EVENT_KINDS);
  const requestedLimit = Number.isFinite(limit)
    ? Math.max(0, Math.trunc(limit))
    : 0;
  if (
    normalizedAuthors.length === 0
    || normalizedKinds.length === 0
    || requestedLimit === 0
  ) {
    return [];
  }

  options.signal?.throwIfAborted();
  const resultLimit = Math.min(requestedLimit, MAX_ROUTED_AUTHOR_EVENTS);
  const queryLimit = Math.min(
    before ? Math.max(resultLimit * 2, resultLimit + 16) : resultLimit,
    MAX_ROUTED_AUTHOR_EVENTS,
  );
  const query = options.query ?? queryBrowserEvents;
  let nextAuthor = 0;
  let failed = false;
  let events: NostrVerifiedEvent[] = [];
  const readBatches = async (): Promise<void> => {
    try {
      while (!failed && nextAuthor < normalizedAuthors.length) {
        options.signal?.throwIfAborted();
        const batch = normalizedAuthors.slice(nextAuthor, nextAuthor + MAX_ROUTED_AUTHORS_PER_QUERY);
        nextAuthor += batch.length;
        let report: Awaited<ReturnType<BrowserEventQuery>>;
        try {
          report = await query(roots, [{
            authors: batch,
            kinds: normalizedKinds,
            limit: queryLimit,
            ...(before ? { until: before.createdAt } : {}),
          }], { limit: queryLimit, signal: options.signal });
        } catch (error) {
          if (!options.allowPartial || options.signal?.aborted) {throw error;}
          continue;
        }
        options.signal?.throwIfAborted();
        // Array-only callers use a short page as exhaustion. An unfinished
        // read cannot safely advance their cursor or stand in for absence.
        if (!options.allowPartial && report.complete === false) {
          throw new Error('Author page read is incomplete');
        }
        const merged = new Map(events.map((event) => [event.id, event]));
        for (const { event } of report.events) {
          if (
            batch.includes(event.pubkey)
            && normalizedKinds.includes(event.kind)
            && isStrictlyBeforeRecentCursor(event.created_at, event.id, before)
          ) {merged.set(event.id, event);}
        }
        events = [...merged.values()]
          .sort((left, right) => right.created_at - left.created_at || left.id.localeCompare(right.id))
          .slice(0, resultLimit);
      }
    } catch (error) {
      failed = true;
      throw error;
    }
  };
  await Promise.all(Array.from({
    length: Math.min(MAX_CONCURRENT_ROUTED_AUTHOR_QUERIES, Math.ceil(normalizedAuthors.length / MAX_ROUTED_AUTHORS_PER_QUERY)),
  }, readBatches));
  return events;
}

/** Read the newest available replaceable candidate, including when other roots are offline. */
export async function routedLatestEventByAuthorKind(
  roots: CID[],
  pubkey: string,
  kind: number,
  options: { signal?: AbortSignal; query?: BrowserEventQuery } = {},
): Promise<NostrVerifiedEvent | null> {
  const author = pubkey.trim().toLowerCase();
  if (!isHexPubkey(author) || !Number.isSafeInteger(kind) || kind < 0) {return null;}
  options.signal?.throwIfAborted();
  const report = await (options.query ?? queryBrowserEvents)(roots, [{
    authors: [author], kinds: [kind], limit: 8,
  }], { limit: 8, signal: options.signal });
  options.signal?.throwIfAborted();
  const events = report.events.map(({ event }) => event)
    .filter((event) => event.pubkey === author && event.kind === kind)
    .sort((left, right) => right.created_at - left.created_at || left.id.localeCompare(right.id));
  // A verified candidate can restore local state; an unfinished empty read
  // cannot establish absence. Paginated author reads remain strictly complete.
  if (report.complete === false && events.length === 0) {
    throw new Error('Author state read is incomplete');
  }
  return events[0] ?? null;
}

export async function routedRecentTextNotesByAuthors(
  roots: CID[],
  authors: readonly string[],
  limit: number,
  options: {
    before?: RecentTextNoteCursor;
    includeReplies?: boolean;
    signal?: AbortSignal;
    query?: BrowserEventQuery;
  } = {},
): Promise<NostrVerifiedEvent[]> {
  const requestedLimit = Number.isFinite(limit) ? Math.max(0, Math.trunc(limit)) : 0;
  if (requestedLimit === 0) {
    return [];
  }
  const scanLimit = Math.min(
    Math.max(requestedLimit * 6, requestedLimit + 16),
    MAX_ROUTED_AUTHOR_EVENTS,
  );
  return (await routedEventsByAuthors(
    roots,
    authors,
    DURABLE_POST_KINDS,
    scanLimit,
    options.before,
    { signal: options.signal, query: options.query },
  )).filter((event) => (
    options.includeReplies === true || event.kind !== 1 || !isReplyEvent(event)
  )).slice(0, requestedLimit);
}

export async function routedProfileHistory(
  roots: CID[],
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: BrowserEventQuery = queryBrowserEvents,
): Promise<NostrVerifiedEvent[]> {
  return (await routedProfileHistoryPage(roots, pubkey, kinds, limit, before, query)).events;
}

/** Preserve source coverage for paginators: a partial batch is useful, but cannot prove exhaustion. */
export async function routedProfileHistoryPage(
  roots: CID[],
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: BrowserEventQuery = queryBrowserEvents,
): Promise<{ events: NostrVerifiedEvent[]; complete: boolean }> {
  if (!isHexPubkey(pubkey) || kinds.length === 0 || limit <= 0) {return { events: [], complete: true };}
  const normalizedPubkey = pubkey.toLowerCase();
  const events = new Map<string, NostrVerifiedEvent>();
  let cursor = before;
  let complete = true;
  let exhausted = false;
  let overlapLimit = 0;
  const maxPages = Math.ceil(limit / PROFILE_HISTORY_PAGE_SIZE) + Math.ceil(Math.log2(PROFILE_HISTORY_PAGE_SIZE)) + 1;

  for (let page = 0; page < maxPages && events.size < limit; page += 1) {
    const remaining = limit - events.size;
    const queryLimit = Math.min(
      PROFILE_HISTORY_PAGE_SIZE,
      Math.max(overlapLimit, remaining + (cursor ? 1 : 0)),
    );
    const filter: NostrFilter = {
      authors: [normalizedPubkey],
      kinds: [...kinds],
      limit: queryLimit,
      ...(cursor ? { until: cursor.createdAt } : {}),
    };
    const report = await query(roots, [filter], { limit: queryLimit });
    if (!report.complete) { complete = false; }
    const candidates = report.events
      .map(({ event }) => event)
      .filter((event) => (
        event.pubkey === normalizedPubkey
        && kinds.includes(event.kind)
        && isStrictlyBeforeRecentCursor(event.created_at, event.id, cursor)
      ))
      .sort((left, right) => (
        right.created_at - left.created_at || left.id.localeCompare(right.id)
      ));
    let added = 0;
    for (const event of candidates) {
      if (!events.has(event.id)) {
        events.set(event.id, event);
        added += 1;
      }
      if (events.size >= limit) {
        break;
      }
    }
    const boundary = candidates.at(-1);
    if (report.events.length < queryLimit) {
      exhausted = true;
      break;
    }
    if (!boundary || added === 0) {
      // Nostr until includes the cursor second. Widen a saturated page to
      // get past IDs already covered by a previous same-second page.
      if (!report.complete || queryLimit >= PROFILE_HISTORY_PAGE_SIZE) { break; }
      overlapLimit = queryLimit * 2;
      continue;
    }
    overlapLimit = 0;
    cursor = { createdAt: boundary.created_at, eventId: boundary.id };
  }

  return { complete: complete && (exhausted || events.size >= limit), events: [...events.values()]
    .sort((left, right) => (
      right.created_at - left.created_at || left.id.localeCompare(right.id)
    ))
    .slice(0, limit) };
}

/** One author's event history from the live overlay and relays only. */
export async function routedLiveProfileHistory(
  pubkey: string,
  kinds: readonly number[],
  limit: number,
  before?: RecentTextNoteCursor,
  query: BrowserEventQuery = async (roots, filters, options) => (
    await queryBrowserEvents(roots, filters, options, 'relays')
  ),
): Promise<NostrVerifiedEvent[]> {
  return await routedProfileHistory([], pubkey, kinds, limit, before, query);
}

/**
 * Runs one per-target Nostr filter batch through the shared router, then
 * restores the per-target result sets after the router deduplicates events.
 * Filter limits remain per target; no accidental global limit is applied.
 */
export async function routedEventsByTagValues(
  roots: CID[],
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  query: typeof queryBrowserEvents = queryBrowserEvents,
): Promise<Map<string, NostrVerifiedEvent[]>> {
  return await queryEventsByTagValues(
    tagName,
    tagValues,
    kinds,
    limitPerValue,
    async (filters, options) => await query(roots, filters, options),
  );
}

type RoutedEngagementDeps = {
  queryAll?: typeof queryBrowserEvents;
  signal?: AbortSignal;
  forYouArchive?: boolean;
};

type RoutedEngagementReport = {
  groups: Map<string, NostrVerifiedEvent[]>;
  complete: boolean;
};

/**
 * Keep visible engagement reads off slow broad archives when a relay tail is
 * active. Unlike general tag reads, this path uses one multi-value filter and
 * one aggregate event cap: a visible set can never expand into one hundreds-
 * deep scan per note.
 */
export async function routedEngagementEventsByTagValues(
  roots: CID[],
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  deps: RoutedEngagementDeps = {},
): Promise<RoutedEngagementReport> {
  // One routed read covers the cache, Hashtree index and relays. For You
  // reads its relay engagement per visible card instead.
  const query = async (filters: NostrFilter[], options?: QueryOptions) => (
    deps.forYouArchive
      ? await (deps.queryAll ?? queryBrowserEvents)(roots, filters, options, 'for-you-archive')
      : await (deps.queryAll ?? queryBrowserEvents)(roots, filters, options)
  );
  return await queryAggregateEngagementEventsByTagValues(
    'e',
    tagValues,
    kinds,
    limitPerValue,
    query,
    deps.signal,
    MAX_ROUTED_ENGAGEMENT_EVENTS,
  );
}

async function queryAggregateEngagementEventsByTagValues(
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  requestedEventLimit: number,
  query: (
    filters: NostrFilter[],
    options?: QueryOptions,
  ) => Promise<Pick<QueryReport, 'events' | 'complete'>>,
  signal?: AbortSignal,
  maximumEventLimit: number = MAX_ROUTED_ENGAGEMENT_EVENTS,
): Promise<RoutedEngagementReport> {
  if (!tagName || requestedEventLimit <= 0) {return { groups: new Map(), complete: true };}
  const values: string[] = [];
  const seenValues = new Set<string>();
  for (
    let index = 0;
    index < Math.min(tagValues.length, MAX_ROUTED_ENGAGEMENT_INPUT_VALUES)
      && values.length < MAX_ROUTED_ENGAGEMENT_TARGETS;
    index += 1
  ) {
    const value = normalizeTagQueryValue(tagName, tagValues[index] ?? '');
    if (!value || seenValues.has(value)) {continue;}
    seenValues.add(value);
    values.push(value);
  }
  const normalizedKinds = [...new Set(kinds
    .slice(0, MAX_ROUTED_ENGAGEMENT_KINDS)
    .filter((kind) => (
    Number.isSafeInteger(kind) && kind >= 0
  )))];
  if (values.length === 0 || normalizedKinds.length === 0) {
    return { groups: new Map(), complete: true };
  }

  signal?.throwIfAborted();
  const eventLimit = Math.min(
    Math.max(1, Math.trunc(requestedEventLimit)),
    maximumEventLimit,
  );
  const filter: NostrFilter = {
    kinds: normalizedKinds,
    limit: eventLimit,
  };
  filter[`#${tagName}`] = values;
  const report = await query(
    [filter],
    { limit: eventLimit, ...(signal ? { signal } : {}) },
  );
  signal?.throwIfAborted();

  const grouped = new Map(values.map((value) => [value, [] as NostrVerifiedEvent[]]));
  for (const { event } of report.events.slice(0, eventLimit)) {
    const targets = new Set<string>();
    for (
      let index = 0;
      index < Math.min(event.tags.length, MAX_ROUTED_ENGAGEMENT_EVENT_TAGS);
      index += 1
    ) {
      const tag = event.tags[index]!;
      if (tag[0] !== tagName) {continue;}
      const value = normalizeTagQueryValue(tagName, tag[1] ?? '');
      if (value && grouped.has(value)) {
        targets.add(value);
      }
    }
    for (const target of targets) {
      grouped.get(target)!.push(event);
    }
  }
  // An aggregate cap can hide later matches for any of the requested targets.
  return { groups: grouped, complete: report.complete !== false && report.events.length < eventLimit };
}

async function queryEventsByTagValues(
  tagName: string,
  tagValues: readonly string[],
  kinds: readonly number[],
  limitPerValue: number,
  query: (
    filters: NostrFilter[],
    options?: QueryOptions,
  ) => Promise<Pick<QueryReport, 'events'>>,
): Promise<Map<string, NostrVerifiedEvent[]>> {
  if (!tagName || kinds.length === 0 || limitPerValue <= 0) {return new Map();}
  const values = [...new Set(tagValues
    .map((value) => normalizeTagQueryValue(tagName, value))
    .filter((value): value is string => value !== null))]
    .sort();
  if (values.length === 0) {return new Map();}

  const filters = values.map((value): NostrFilter => {
    const filter: NostrFilter = { kinds: [...kinds], limit: limitPerValue };
    filter[`#${tagName}`] = [value];
    return filter;
  });
  const report = await query(filters, {});
  const grouped = new Map(values.map((value) => [value, [] as NostrVerifiedEvent[]]));
  for (const { event } of report.events) {
    const targets = new Set(event.tags.flatMap((tag) => {
      if (tag[0] !== tagName) {return [];}
      const value = normalizeTagQueryValue(tagName, tag[1] ?? '');
      return value && grouped.has(value) ? [value] : [];
    }));
    for (const target of targets) {
      grouped.get(target)!.push(event);
    }
  }
  return grouped;
}

function normalizeTagQueryValue(tagName: string, rawValue: string): string | null {
  const value = rawValue.trim();
  if (!value) {return null;}
  if (tagName === 'e' || tagName === 'p') {
    return /^[0-9a-f]{64}$/i.test(value) ? value.toLowerCase() : null;
  }
  return tagName === 't' ? value.toLowerCase() : value;
}

/**
 * Resolve signed profile metadata from the cache and Hashtree index. Feeds wait
 * for these batches; the profile refresh lane reads newer metadata from relays.
 */
export async function routedProfilesByPubkey(
  roots: CID[],
  pubkeys: readonly string[],
  options: { signal?: AbortSignal } = {},
): Promise<Map<string, ProfileRecord>> {
  const authors = [...new Set(pubkeys
    .map((pubkey) => pubkey.trim().toLowerCase())
    .filter(isHexPubkey))]
    .sort();
  if (authors.length === 0) {return new Map();}

  const queries: Array<Promise<Map<string, ProfileRecord>>> = [];
  for (let offset = 0; offset < authors.length; offset += MAX_PROFILE_AUTHORS_PER_QUERY) {
    const chunk = authors.slice(offset, offset + MAX_PROFILE_AUTHORS_PER_QUERY);
    queries.push(queryBrowserEvents(roots, [{
      kinds: [0],
      authors: chunk,
      limit: chunk.length,
    }], {
      limit: chunk.length,
      signal: options.signal,
    }, 'archive').then((report) => profileMapFromMetadataEvents(
      report.events.map(({ event }) => event),
    )));
  }
  return mergeProfileMaps(...await Promise.all(queries));
}
