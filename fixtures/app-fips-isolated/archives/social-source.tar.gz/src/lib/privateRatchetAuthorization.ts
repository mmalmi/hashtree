import type { NdrRuntimeState, OnEventMeta, Rumor } from 'nostr-double-ratchet';

/** Throwing retains the durable control until its authorization can be checked. */
export function requirePrivateSyncAuthorization(state: NdrRuntimeState): void {
  if (!state.sessionManagerReady || !state.appKeysManagerReady
    || (!state.hasLocalAppKeys && state.lastAppKeysCreatedAt <= 0)) {
    throw new Error('Waiting for the device list.');
  }
}

/** Decryption alone does not authorize an account preference change.
 * Native builders historically omit self p tags; explicit recipients stay owner-only.
 */
export function isPrivateSyncSibling(
  owner: string,
  event: Rumor,
  sender: string,
  meta: OnEventMeta | undefined,
  state: NdrRuntimeState,
): boolean {
  const device = meta?.senderDevicePubkey ?? meta?.fromDeviceId;
  return state.ownerPubkey === owner && state.isCurrentDeviceRegistered
    && sender === owner && meta?.senderOwnerPubkey === owner
    && !!device && device !== state.currentDevicePubkey
    && state.registeredDevices.some(value => value.identityPubkey === device)
    && (event.pubkey === owner || event.pubkey === device)
    && event.tags.every(tag => tag[0] !== 'p' || tag[1] === owner);
}
