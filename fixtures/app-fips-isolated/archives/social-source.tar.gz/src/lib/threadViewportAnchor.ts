export type ThreadViewportAnchorPlan = {
  bottomReservePx: number;
  targetOffset: number;
};

const THREAD_ANCHOR_EPSILON_PX = 1;

/**
 * Keep the main thread note at the same viewport position when late parent
 * context is inserted above it. A short thread may need trailing room before
 * the shared page scroller can reach the compensating offset.
 */
export function planThreadViewportAnchor(options: {
  anchorTopAfter: number;
  anchorTopBefore: number;
  clientHeight: number;
  currentOffset: number;
  scrollHeight: number;
}): ThreadViewportAnchorPlan | null {
  const delta = options.anchorTopAfter - options.anchorTopBefore;
  if (!Number.isFinite(delta) || Math.abs(delta) <= THREAD_ANCHOR_EPSILON_PX) {
    return null;
  }

  const targetOffset = Math.max(0, options.currentOffset + delta);
  return {
    bottomReservePx: Math.max(
      0,
      targetOffset + options.clientHeight - options.scrollHeight,
    ),
    targetOffset,
  };
}
