import * as nip19 from 'nostr-tools/nip19';
import { verifyEvent } from 'nostr-tools/pure';
import { verifyIndexedEvents } from './fastEventVerification';
import { isHexEventId, isHexPubkey, type ProfileRecord, type RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import type { ReferencedNotePreview } from './referencedNote';

export type RepostTargetProjection = {
  event: RawEvent;
  profile: ProfileRecord | null;
  source: 'embedded' | 'index';
};

type RepostTargetResolver = (ref: string) => Promise<ReferencedNotePreview | null>;
const MAX_EMBEDDED_REPOST_CACHE = 2_048;
const embeddedVerification = new Map<string, boolean>();
const pendingWrappers = new Set<RawEvent>();
let pendingAdmission: Promise<void> | null = null;

function signedIdentity(event: RawEvent): string {
  return `${event.id}:${event.sig}`;
}

function normalizeCandidateEvent(value: unknown, verify = true): RawEvent | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const candidate = value as Partial<RawEvent>;
  if (
    typeof candidate.id !== 'string'
    || !isHexEventId(candidate.id)
    || typeof candidate.pubkey !== 'string'
    || !isHexPubkey(candidate.pubkey)
    || !Number.isSafeInteger(candidate.created_at)
    || typeof candidate.kind !== 'number'
    || !Number.isSafeInteger(candidate.kind)
    || !Array.isArray(candidate.tags)
    || !candidate.tags.every((tag) => (
      Array.isArray(tag) && tag.every((entry) => typeof entry === 'string')
    ))
    || typeof candidate.content !== 'string'
    || typeof candidate.sig !== 'string'
  ) {
    return null;
  }

  const event: RawEvent = {
    id: candidate.id.toLowerCase(),
    pubkey: candidate.pubkey.toLowerCase(),
    created_at: candidate.created_at as number,
    kind: candidate.kind,
    tags: candidate.tags.map((tag) => [...tag]),
    content: candidate.content,
    sig: candidate.sig,
  };

  try {
    if (!verify) {
      return event;
    }
    if (typeof window !== 'undefined') {
      return embeddedVerification.get(signedIdentity(event)) === true ? event : null;
    }
    // Verify a fresh mutable copy. Events arriving from nostr-pubsub can be
    // frozen and a separate nostr-tools bundle may otherwise try to attach its
    // private verification marker to that frozen transport object.
    return verifyEvent(event) ? event : null;
  } catch {
    return null;
  }
}

function embeddedCandidate(wrapper: RawEvent): RawEvent | null {
  const targetId = getKind6RepostTargetEventId(wrapper);
  if (!targetId || !wrapper.content.trim()) {return null;}
  try {
    const target = normalizeCandidateEvent(JSON.parse(wrapper.content), false);
    return target?.id === targetId ? target : null;
  } catch {
    return null;
  }
}

export function needsEmbeddedRepostAdmission(wrapper: RawEvent): boolean {
  const candidate = embeddedCandidate(wrapper);
  return Boolean(candidate && !embeddedVerification.has(signedIdentity(candidate)));
}

export function requestEmbeddedRepostAdmission(
  wrapper: RawEvent,
  verify: (events: RawEvent[]) => Promise<boolean[]> = verifyIndexedEvents,
): Promise<void> {
  pendingWrappers.add(wrapper);
  pendingAdmission ??= Promise.resolve().then(async () => {
    while (pendingWrappers.size > 0) {
      const wrappers = [...pendingWrappers];
      pendingWrappers.clear();
      const candidates = wrappers.flatMap((item) => {
        const candidate = embeddedCandidate(item);
        return candidate ? [candidate] : [];
      });
      for (let index = 0; index < candidates.length; index += 256) {
        const batch = candidates.slice(index, index + 256);
        const valid = await verify(batch);
        for (let offset = 0; offset < batch.length; offset += 1) {
          const key = signedIdentity(batch[offset]!);
          embeddedVerification.set(key, valid[offset] === true);
          while (embeddedVerification.size > MAX_EMBEDDED_REPOST_CACHE) {
            const oldest = embeddedVerification.keys().next().value as string | undefined;
            if (!oldest) {break;}
            embeddedVerification.delete(oldest);
          }
        }
      }
    }
  }).finally(() => { pendingAdmission = null; });
  return pendingAdmission;
}

export function getKind6RepostTargetEventId(wrapper: RawEvent): string | null {
  if (wrapper.kind !== 6) {
    return null;
  }

  return getLastValidLowercaseEventTarget(wrapper);
}

function getKind6RepostTargetAuthor(wrapper: RawEvent): string | null {
  const value = wrapper.tags.find((tag) => tag[0] === 'p' && isHexPubkey(tag[1] ?? ''))?.[1];
  return value ? value.toLowerCase() : null;
}

/**
 * Build a relay-free reference for the app's Hashtree index resolver. The
 * author hint lets it try the target author's personal index after an open-root
 * miss without ever issuing a content query to a Nostr relay.
 */
export function getKind6RepostTargetReference(wrapper: RawEvent): string | null {
  const id = getKind6RepostTargetEventId(wrapper);
  if (!id) {
    return null;
  }

  const author = getKind6RepostTargetAuthor(wrapper);
  return author ? nip19.neventEncode({ id, author }) : nip19.noteEncode(id);
}

export function getVerifiedEmbeddedRepostTarget(wrapper: RawEvent): RawEvent | null {
  const target = embeddedCandidate(wrapper);
  if (!target) {return null;}
  if (typeof window !== 'undefined') {
    return embeddedVerification.get(signedIdentity(target)) === true ? target : null;
  }
  return normalizeCandidateEvent(target);
}

/**
 * Resolve the event presented by a kind-6 wrapper. A valid signed embedded
 * event wins immediately. Only missing or invalid embedded content reaches the
 * supplied Hashtree-backed reference resolver.
 */
export async function resolveKind6RepostTarget(
  wrapper: RawEvent,
  resolveReferencedNote: RepostTargetResolver | null,
): Promise<RepostTargetProjection | null> {
  const embedded = getVerifiedEmbeddedRepostTarget(wrapper);
  if (embedded) {
    return { event: embedded, profile: null, source: 'embedded' };
  }

  const ref = getKind6RepostTargetReference(wrapper);
  if (!ref || !resolveReferencedNote) {
    return null;
  }

  try {
    const preview = await resolveReferencedNote(ref);
    // Indexed previews have already crossed their own worker verification
    // boundary; do not require the unrelated embedded-event browser cache.
    const event = normalizeCandidateEvent(preview?.event, false);
    if (!event || event.id !== getKind6RepostTargetEventId(wrapper)) {
      return null;
    }

    return {
      event,
      profile: preview?.profile?.pubkey === event.pubkey ? preview.profile : null,
      source: 'index',
    };
  } catch {
    return null;
  }
}
