import type { ProfileRecord, RawEvent } from './nostr';

export type ReferencedNotePreview = {
  event: RawEvent;
  profile: ProfileRecord | null;
};

type ReferencedNoteEventLoaderOptions<Root> = {
  roots: Root[];
  ref: string;
  referencedPubkey: string | null;
  loadFromRoots: (roots: Root[], ref: string) => Promise<RawEvent | null>;
  resolvePersonalRoot: (pubkey: string) => Promise<Root | null>;
};

export async function loadReferencedNoteEvent<Root>(
  options: ReferencedNoteEventLoaderOptions<Root>,
): Promise<RawEvent | null> {
  const event = await options.loadFromRoots(options.roots, options.ref);
  if (event || !options.referencedPubkey) {
    return event;
  }

  const personalRoot = await options.resolvePersonalRoot(options.referencedPubkey);
  return personalRoot
    ? await options.loadFromRoots([personalRoot], options.ref)
    : null;
}
