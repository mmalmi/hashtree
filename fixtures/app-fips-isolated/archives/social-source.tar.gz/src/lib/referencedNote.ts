import { isBrowserRelayContentEnabled, queryBrowserEvents } from './browserEventReadRouter';
import { decodeNostrEventReference, isHexEventId, type ProfileRecord, type RawEvent } from './nostr';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import { nhashEncode, type CID } from '@hashtree/core';

export type ReferencedNotePreview = {
  event: RawEvent;
  profile: ProfileRecord | null;
};

type ReferencedNoteEventLoaderOptions<Root> = {
  roots: Root[];
  ref: string;
  referencedPubkey: string | null;
  loadFromRoots: (roots: Root[], ref: string) => Promise<RawEvent | null>;
  resolvePersonalRoot: (pubkey: string) => Promise<Root | null>;
};

export async function loadReferencedNoteEvent<Root>(
  options: ReferencedNoteEventLoaderOptions<Root>,
): Promise<RawEvent | null> {
  const event = await options.loadFromRoots(options.roots, options.ref);
  if (event || !options.referencedPubkey) {
    return event;
  }

  const personalRoot = await options.resolvePersonalRoot(options.referencedPubkey);
  return personalRoot
    ? await options.loadFromRoots([personalRoot], options.ref)
    : null;
}

/** The event cache and the author's own saved index can each supply the
 * first preview, including when the current view has no archive root yet. */
export async function readReferencedNoteArchives(
  roots: CID[], author: string | null, signal: AbortSignal,
  read: (root: CID | null) => Promise<void>, getPersonalRoot: (author: string) => Promise<CID | null>,
): Promise<void> {
  await Promise.all([
    ...(roots.length ? roots : [null]).map(read),
    author && getPersonalRoot(author).then(personal => {
      if (personal && !signal.aborted && !roots.some(root => nhashEncode(root) === nhashEncode(personal))) {
        return read(personal);
      }
    }),
  ]);
}

export async function readPublicReferencedNote(
  ref: string,
  signal: AbortSignal,
  enabled = isBrowserRelayContentEnabled(),
  query = queryBrowserEvents,
): Promise<RawEvent | null> {
  if (!enabled) {return null;}
  const decoded = decodeNostrEventReference(ref);
  const id = isHexEventId(ref) ? ref.toLowerCase()
    : decoded?.type === 'note' || decoded?.type === 'nevent' ? decoded.eventId : null;
  if (!id) {return null;}
  const kinds: number[] = [...PROFILE_CONTENT_KINDS];
  if (decoded?.type === 'nevent' && decoded.kind !== null && !kinds.includes(decoded.kind)) {return null;}
  const report = await query([], [{ ids: [id], kinds, limit: 1 }], {
    limit: 1, deadline: Date.now() + 4_000, signal,
  }, 'relays');
  const event = report.events[0]?.event;
  return event?.id === id && kinds.some(kind => kind === event.kind) ? event : null;
}
