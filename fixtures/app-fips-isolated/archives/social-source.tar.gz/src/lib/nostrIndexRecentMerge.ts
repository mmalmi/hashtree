import type { CollectionSource } from '@hashtree/collection';
import type { CID } from '@hashtree/core';
import {
  MANIFEST_BY_AUTHOR_KIND_TIME,
  MANIFEST_BY_AUTHOR_TIME,
  MANIFEST_BY_TIME,
} from '@hashtree/nostr';
import { isReplyEvent, type RawEvent } from './nostr';
import { DURABLE_POST_KINDS } from './recentAuthorFeedReader';
import {
  isStrictlyBeforeRecentCursor,
  streamTimeOrderedIndex,
  timeAndEventIdFromIndexKey,
  type RecentTextNoteQueryOptions,
} from './recentTextNoteCursor';
import { hasCollectionIndex } from './nostrCollectionIndexes';
import {
  mapOrderedConcurrent,
  type ConcurrencyLimiter,
} from './orderedConcurrent';

const MIN_RECENT_NOTE_SCAN_LIMIT = 128;
const RECENT_NOTE_SCAN_MULTIPLIER = 96;
const MIN_SINGLE_AUTHOR_FAST_SCAN_LIMIT = 32;
const SINGLE_AUTHOR_FAST_SCAN_MULTIPLIER = 8;

type RecentCursor = {
  iteratorIndex: number;
  event: RawEvent;
};

export type NostrIndexRecentMergeDependencies = {
  findFastRecentTextNote: (
    source: CollectionSource,
    authorSet: Set<string>,
    limit: number,
    options: RecentTextNoteQueryOptions,
    isCancelled?: () => boolean,
  ) => Promise<RawEvent | null>;
  getCollectionSource: () => Promise<CollectionSource>;
  indexedEventReadConcurrency: number;
  indexedEventReadLimiter: ConcurrencyLimiter;
  nextRecentNoteCursor: (
    iteratorIndex: number,
    iterator: AsyncIterator<RawEvent>,
    options: RecentTextNoteQueryOptions,
  ) => Promise<RecentCursor | null>;
  readEvent: (cid: CID) => Promise<RawEvent | null>;
};

function padKind(kind: number): string {
  return kind.toString(16).padStart(8, '0');
}

function getRecentTextNoteKinds(options: RecentTextNoteQueryOptions): readonly number[] {
  return [...new Set(options.kinds ?? DURABLE_POST_KINDS)];
}

function isWithinRecentTextNoteTime(
  event: RawEvent,
  options: RecentTextNoteQueryOptions,
): boolean {
  return (options.since === undefined || event.created_at >= options.since)
    && (options.until === undefined || event.created_at <= options.until);
}

function isFilteredPostReply(event: RawEvent): boolean {
  return event.kind === 1 && isReplyEvent(event);
}

export class NostrIndexRecentMerge {
  private readonly findFastRecentTextNote: NostrIndexRecentMergeDependencies['findFastRecentTextNote'];
  private readonly getCollectionSource: () => Promise<CollectionSource>;
  private readonly indexedEventReadConcurrency: number;
  private readonly indexedEventReadLimiter: ConcurrencyLimiter;
  private readonly nextRecentNoteCursor: NostrIndexRecentMergeDependencies['nextRecentNoteCursor'];
  private readonly readEvent: (cid: CID) => Promise<RawEvent | null>;

  constructor(dependencies: NostrIndexRecentMergeDependencies) {
    this.findFastRecentTextNote = dependencies.findFastRecentTextNote;
    this.getCollectionSource = dependencies.getCollectionSource;
    this.indexedEventReadConcurrency = dependencies.indexedEventReadConcurrency;
    this.indexedEventReadLimiter = dependencies.indexedEventReadLimiter;
    this.nextRecentNoteCursor = dependencies.nextRecentNoteCursor;
    this.readEvent = dependencies.readEvent;
  }

  async nextRecentNoteCursorDefault(
    iteratorIndex: number,
    iterator: AsyncIterator<RawEvent>,
    options: RecentTextNoteQueryOptions,
  ): Promise<RecentCursor | null> {
    while (true) {
      const next = await iterator.next();
      if (next.done) {
        return null;
      }

      const event = next.value;
      if (!isStrictlyBeforeRecentCursor(event.created_at, event.id, options.before)) {
        continue;
      }
      if (options.until !== undefined && event.created_at > options.until) {
        continue;
      }
      if (options.since !== undefined && event.created_at < options.since) {
        await iterator.return?.();
        return null;
      }
      if (!options.includeReplies && isFilteredPostReply(event)) {
        continue;
      }

      return { iteratorIndex, event };
    }
  }

  async *streamRecentTextNotesByAuthorKindTime(
    authors: string[],
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    const kinds = getRecentTextNoteKinds(options);
    const source = await this.getCollectionSource();
    const authorSet = new Set(authors);
    const fastProbe = this.createFastRecentNoteProbe(
      source, authorSet, limit, options, 'Failed to read fast recent post by author',
    );
    const iterators = authors.flatMap((author) => kinds.map((kind) =>
      this.streamAuthorKindPostCandidates(source, author, kind, limit, options)[Symbol.asyncIterator](),
    ));

    yield* this.streamMergedRecentNoteIterators(
      iterators,
      new Set(kinds),
      limit,
      options,
      'Failed to stream recent indexed posts by author',
      fastProbe,
    );
  }

  private async *streamAuthorKindPostCandidates(
    source: CollectionSource,
    author: string,
    kind: number,
    limit: number,
    options: RecentTextNoteQueryOptions,
  ): AsyncGenerator<RawEvent, void, void> {
    const candidates = (async function* (): AsyncGenerator<CID, void, void> {
      for await (const { key, cid } of streamTimeOrderedIndex(
        source,
        MANIFEST_BY_AUTHOR_KIND_TIME,
        `${author}:${padKind(kind)}:`,
        options.before,
      )) {
        const { createdAt, eventId } = timeAndEventIdFromIndexKey(key);
        if (options.until !== undefined && createdAt > options.until) {
          continue;
        }
        if (!isStrictlyBeforeRecentCursor(createdAt, eventId, options.before)) {
          continue;
        }
        if (options.since !== undefined && createdAt < options.since) {
          break;
        }
        yield cid;
      }
    })();
    for await (const event of mapOrderedConcurrent(
      candidates,
      async (cid) => await this.indexedEventReadLimiter.run(async () => await this.readEvent(cid)),
      { concurrency: Math.min(this.indexedEventReadConcurrency, Math.max(limit, 1)) },
    )) {
      if (event && event.pubkey === author && event.kind === kind) {
        yield event;
      }
    }
  }

  async findFastRecentTextNoteDefault(
    source: CollectionSource,
    authorSet: Set<string>,
    limit: number,
    options: RecentTextNoteQueryOptions,
    isCancelled: () => boolean = () => false,
  ): Promise<RawEvent | null> {
    // Continuation pages already have an exact per-event boundary. The fast
    // head probe would rescan and fetch blobs that the cursor deliberately
    // excludes, so let the keyed iterators produce the next verified event.
    if (options.before) {
      return null;
    }
    const singleAuthor = authorSet.size === 1 ? [...authorSet][0] : null;
    const indexName = singleAuthor && hasCollectionIndex(source, MANIFEST_BY_AUTHOR_TIME)
      ? MANIFEST_BY_AUTHOR_TIME
      : hasCollectionIndex(source, MANIFEST_BY_TIME)
        ? MANIFEST_BY_TIME
        : null;
    if (!indexName) {
      return null;
    }

    const kindSet = new Set(getRecentTextNoteKinds(options));
    const maxScanned = singleAuthor
      ? Math.max(MIN_SINGLE_AUTHOR_FAST_SCAN_LIMIT, limit * SINGLE_AUTHOR_FAST_SCAN_MULTIPLIER)
      : Math.max(MIN_RECENT_NOTE_SCAN_LIMIT, limit * RECENT_NOTE_SCAN_MULTIPLIER);
    for await (const { cid } of source.streamQueryIndex(indexName, {
      prefix: indexName === MANIFEST_BY_AUTHOR_TIME ? `${singleAuthor}:` : '',
      limit: maxScanned,
    })) {
      if (isCancelled()) {
        return null;
      }
      const event = await this.readEvent(cid);
      if (isCancelled()) {
        return null;
      }
      if (
        event
        && authorSet.has(event.pubkey)
        && kindSet.has(event.kind)
        && isWithinRecentTextNoteTime(event, options)
        && (options.includeReplies || !isFilteredPostReply(event))
      ) {
        return event;
      }
    }
    return null;
  }

  private createFastRecentNoteProbe(
    source: CollectionSource, authorSet: Set<string>,
    limit: number, options: RecentTextNoteQueryOptions,
    warning: string,
  ): { promise: Promise<RawEvent | null>; cancel: () => void } {
    let cancelled = false;
    return {
      cancel: () => { cancelled = true; },
      promise: this.findFastRecentTextNote(source, authorSet, limit, options, () => cancelled)
        .catch((error) => {
          console.warn(warning, error);
          return null;
        }),
    };
  }

  async *streamMergedRecentNoteIterators(
    iterators: AsyncIterator<RawEvent>[],
    kindSet: Set<number>,
    limit: number,
    options: RecentTextNoteQueryOptions,
    warning: string,
    fastProbe?: { promise: Promise<RawEvent | null>; cancel: () => void },
  ): AsyncGenerator<RawEvent[], void, void> {
    const emitEvery = Math.max(options.emitEvery ?? 1, 1);
    const ready: RecentCursor[] = [];
    const events: RawEvent[] = [];
    const seenIds = new Set<string>();
    let yieldedCount = 0;

    try {
      const initialCursorsPromise = Promise.all(iterators.map(async (iterator, iteratorIndex) => (
        await this.nextRecentNoteCursor(iteratorIndex, iterator, options).catch((error) => {
          console.warn(warning, error);
          return null;
        })
      )));
      let initialCursors: Array<RecentCursor | null>;
      if (fastProbe) {
        const firstReady = await Promise.race([
          initialCursorsPromise.then((cursors) => ({ type: 'merged' as const, cursors })),
          fastProbe.promise.then((event) => ({ type: 'fast' as const, event })),
        ]);
        if (firstReady.type === 'fast') {
          if (firstReady.event) {
            // by-author-time/by-time gives an exact newest verified post from
            // one index path while sparse kind heads continue in parallel.
            yield [firstReady.event];
          }
          initialCursors = await initialCursorsPromise;
        } else {
          fastProbe.cancel();
          initialCursors = firstReady.cursors;
        }
      } else {
        initialCursors = await initialCursorsPromise;
      }
      for (const cursor of initialCursors) {
        if (cursor) {
          ready.push(cursor);
        }
      }

      while (ready.length > 0 && events.length < limit) {
        ready.sort((left, right) => (
          right.event.created_at - left.event.created_at || left.event.id.localeCompare(right.event.id)
        ));
        const cursor = ready.shift()!;
        const event = cursor.event;
        if (!seenIds.has(event.id) && kindSet.has(event.kind)) {
          seenIds.add(event.id);
          events.push(event);
          events.sort((left, right) => (
            right.created_at - left.created_at || left.id.localeCompare(right.id)
          ));
          if (events.length === 1 || events.length === limit || events.length - yieldedCount >= emitEvery) {
            yieldedCount = events.length;
            yield [...events];
          }
        }

        if (events.length >= limit) {
          break;
        }

        const nextCursor = await this.nextRecentNoteCursor(
          cursor.iteratorIndex,
          iterators[cursor.iteratorIndex],
          options,
        ).catch((error) => {
          console.warn(warning, error);
          return null;
        });
        if (nextCursor) {
          ready.push(nextCursor);
        }
      }
    } finally {
      fastProbe?.cancel();
      await Promise.all(iterators.map(async (iterator) => {
        try {
          await iterator.return?.(undefined);
        } catch {
          // Ignore iterator cleanup failures.
        }
      }));
    }

    if (events.length > 0 && yieldedCount !== events.length) {
      yield [...events];
    }
  }
}
