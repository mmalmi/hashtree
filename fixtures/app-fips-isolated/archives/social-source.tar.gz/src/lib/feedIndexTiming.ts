// A genuinely cold immutable index can need several seconds to traverse from
// the CDN into the worker. Giving up after 2.5 seconds returned an empty feed
// permanently even though the same index painted immediately after reload
// from the warmed block cache. Keep the worker request alive until it either
// produces its first verified snapshot or reaches the transport's bounded
// response window; this does not block the route shell or the main thread.
const FEED_INDEX_STREAM_GRACE_MS = 15_000;
const FEED_INDEX_CONTINUATION_GRACE_MS = 750;

export async function awaitWithin<T>(
  promise: Promise<T>,
  timeoutMs: number,
): Promise<{ settled: true; value: T } | { settled: false }> {
  const timeoutToken = Symbol('timeout');
  const result = await Promise.race([
    promise,
    new Promise<typeof timeoutToken>((resolve) => {
      setTimeout(() => resolve(timeoutToken), timeoutMs);
    }),
  ]);
  return result === timeoutToken
    ? { settled: false }
    : { settled: true, value: result as T };
}

export async function nextIteratorWithin<T>(
  iterator: AsyncIterator<T>,
  timeoutMs: number,
): Promise<{ settled: true; value: IteratorResult<T> } | { settled: false }> {
  const nextPromise = iterator.next().catch((error) => ({ error }));
  const result = await awaitWithin(nextPromise, timeoutMs);
  if (!result.settled) {
    return { settled: false };
  }
  if ('error' in result.value) {
    throw result.value.error;
  }
  return { settled: true, value: result.value };
}

export function feedIndexStreamWaitMs(streamedAny: boolean): number {
  // Once a verified partial page has painted, its continuation remains open.
  // Release the initial-load cursor promptly; a later page request can resume
  // from the exact boundary without holding the UI on a slow immutable block.
  return streamedAny ? FEED_INDEX_CONTINUATION_GRACE_MS : FEED_INDEX_STREAM_GRACE_MS;
}

export const INITIAL_FEED_INDEX_STREAM_GRACE_MS = FEED_INDEX_STREAM_GRACE_MS;
