export type OutboxRetryControllerOptions = {
  delaysMs: readonly number[];
  onlineTarget: EventTarget | null;
  canRetry: () => boolean;
  retry: () => Promise<void>;
  onError?: (error: unknown) => void;
};

/** Owns bounded relay-outbox backoff and the browser online lifecycle. */
export class OutboxRetryController {
  private readonly options: OutboxRetryControllerOptions;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private attempt = 0;
  private listening = false;
  private readonly handleOnline = (): void => {
    if (!this.options.canRetry()) {
      return;
    }
    this.clear();
    this.run();
  };

  constructor(options: OutboxRetryControllerOptions) {
    this.options = options;
  }

  start(): void {
    if (!this.options.onlineTarget || this.listening) {
      return;
    }
    this.options.onlineTarget.addEventListener('online', this.handleOnline);
    this.listening = true;
  }

  stop(): void {
    this.clear(true);
    if (!this.options.onlineTarget || !this.listening) {
      return;
    }
    this.options.onlineTarget.removeEventListener('online', this.handleOnline);
    this.listening = false;
  }

  schedule(): void {
    if (this.timer || !this.options.canRetry()) {
      return;
    }
    const index = Math.min(this.attempt, this.options.delaysMs.length - 1);
    const delayMs = this.options.delaysMs[index] ?? 0;
    this.attempt += 1;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.run();
    }, delayMs);
  }

  clear(resetAttempt = false): void {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (resetAttempt) {
      this.attempt = 0;
    }
  }

  private run(): void {
    void this.options.retry().catch((error: unknown) => {
      this.options.onError?.(error);
    });
  }
}
