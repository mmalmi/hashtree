import type { RawEvent } from './nostr';
import type { SocialDataPlaneChange } from './socialDataPlaneTypes';
import { cloneRawEvent } from './socialDataPlaneSupport';
import type { SocialEventRepository } from './socialRepository';

const MAX_LIVE_INGEST_BATCH = 128;

export type CommittedSocialEventBatch = {
  events: RawEvent[];
  sourcePeers: (string | null)[];
};

/** Add, bound, and project an already trusted event batch exactly once. */
export function commitSocialEventBatch(options: {
  repository: SocialEventRepository;
  events: readonly RawEvent[];
  sourcePeers: readonly (string | null)[];
  maxOverlayEvents: number;
  protectedEventIds: Iterable<string>;
}): CommittedSocialEventBatch | null {
  if (options.events.length === 0 || options.events.length !== options.sourcePeers.length) {
    return null;
  }
  const events: RawEvent[] = [];
  const sourcePeers: (string | null)[] = [];
  const seen = new Set<string>();
  for (let index = 0; index < options.events.length; index += 1) {
    const event = options.events[index]!;
    const eventId = event.id.toLowerCase();
    if (seen.has(eventId) || options.repository.getStoredEvent(eventId)) {
      continue;
    }
    seen.add(eventId);
    events.push(event);
    sourcePeers.push(options.sourcePeers[index] ?? null);
  }
  if (events.length === 0) {
    return null;
  }
  const mutation = options.repository.ingestBoundedOverlay(
    events,
    options.maxOverlayEvents,
    options.protectedEventIds,
  );
  if (!mutation.changed) {
    return null;
  }
  const retainedIds = new Set(
    options.repository.getOverlayEvents({ includeEphemeral: true })
      .map((event) => event.id.toLowerCase()),
  );
  const retained: CommittedSocialEventBatch = { events: [], sourcePeers: [] };
  for (let index = 0; index < events.length; index += 1) {
    if (!retainedIds.has(events[index]!.id.toLowerCase())) {
      continue;
    }
    retained.events.push(events[index]!);
    retained.sourcePeers.push(sourcePeers[index]!);
  }
  return retained.events.length > 0 ? retained : null;
}

export function forEachLiveEventBatch(
  events: readonly RawEvent[],
  sourcePeers: readonly string[],
  commit: (events: RawEvent[], sourcePeers: string[]) => void,
): void {
  if (events.length !== sourcePeers.length) {
    return;
  }
  for (let offset = 0; offset < events.length; offset += MAX_LIVE_INGEST_BATCH) {
    const batch = events.slice(offset, offset + MAX_LIVE_INGEST_BATCH).map(cloneRawEvent);
    commit(batch, sourcePeers.slice(offset, offset + batch.length));
  }
}

export function enforceSocialOverlayBound(options: {
  repository: SocialEventRepository;
  maxOverlayEvents: number;
  protectedEventIds: ReadonlySet<string>;
}): boolean {
  const overlayEvents = options.repository.getOverlayEvents({ includeEphemeral: true });
  let excess = overlayEvents.length - options.maxOverlayEvents;
  if (excess <= 0) {
    return false;
  }
  const removals: string[] = [];
  for (let index = overlayEvents.length - 1; index >= 0 && excess > 0; index -= 1) {
    const eventId = overlayEvents[index]?.id;
    if (!eventId || options.protectedEventIds.has(eventId)) {
      continue;
    }
    removals.push(eventId);
    excess -= 1;
  }
  return removals.length > 0 && options.repository.removeOverlayEvents(removals).changed;
}

/** Notify every observer with one immutable batch change. */
export function notifySocialEventBatch(options: {
  events: readonly RawEvent[];
  origin: SocialDataPlaneChange['origin'];
  sourcePeers: readonly (string | null)[];
  version: number;
  observe(event: RawEvent): void;
  listeners: Iterable<(change: SocialDataPlaneChange) => void>;
}): void {
  if (options.events.length === 0 || options.events.length !== options.sourcePeers.length) {
    return;
  }
  for (const event of options.events) {
    options.observe(event);
  }
  const events = options.events.map(cloneRawEvent);
  const change: SocialDataPlaneChange = {
    event: events[0]!,
    events,
    origin: options.origin,
    sourcePeer: options.sourcePeers[0] ?? null,
    sourcePeers: [...options.sourcePeers],
    version: options.version,
  };
  for (const listener of options.listeners) {
    listener(change);
  }
}
