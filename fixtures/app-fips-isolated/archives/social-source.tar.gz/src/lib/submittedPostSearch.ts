import type { NostrVerifiedEvent } from 'nostr-pubsub';
import { getConfiguredPostSearchIndexRefs } from './config';
import { searchLocalPosts } from './localPostSearch';
import { authorSignal, lexicalMatch, planPostSearch, postSubstanceFactor } from './post-search/ranking';
import { throwIfPostSearchAborted, withPostSearchAbortTimeout } from './postSearchAbort';
import { POST_SEARCH_KINDS } from './postSearchCatalogConstants';
import type { FederatedPostSearchOptions, FederatedPostSearchResponse } from './postSearchFederation';
import { POST_SEARCH_INITIAL_LIMIT, POST_SEARCH_MAX_LIMIT } from './postSearchRequest';
import { parsePostSearchRoutingQueryTerms } from './postSearchTermRouting';
import { getPublicSearchRelays } from './publicSearchRelays';
import { getLoadedSocialGraphAuthorInfo } from './socialGraph';
import { createWorkerRelayEventReader } from './workerRelayEventReader';

const SEARCH_NETWORK_TIMEOUT_MS = 3_500;
const SEARCH_RESPONSE_TIMEOUT_MS = 4_500;
const MAX_SEARCH_QUERY_BYTES = 1_024;

type SubmittedPostSearchOptions = Pick<FederatedPostSearchOptions, 'limit' | 'signal' | 'onProgress'>;

const emptyResponse: FederatedPostSearchResponse = {
  results: [],
  failures: [],
  searchedPublishers: 0,
  exhaustive: true,
  truncatedPublishers: [],
};

/** Invoke only for an explicit public relay search submission or its pagination. */
export const searchSubmittedPosts = createSubmittedPostSearch({
  getRelays: getPublicSearchRelays,
  async searchCatalog(query, options) {
    if (getConfiguredPostSearchIndexRefs().length === 0) {
      return null;
    }
    return (await import('./postSearchRuntime')).searchPosts(query, options);
  },
  createReader: (getRelays, onEvents) => createWorkerRelayEventReader({ getRelays, onEvents }),
});

type SubmittedPostSearchDependencies = {
  getRelays: () => readonly string[];
  searchCatalog: (query: string, options: SubmittedPostSearchOptions) => Promise<FederatedPostSearchResponse | null>;
  createReader: (getRelays: () => readonly string[], onEvents?: (events: readonly NostrVerifiedEvent[]) => void) => ReturnType<typeof createWorkerRelayEventReader>;
};

export function createSubmittedPostSearch(dependencies: SubmittedPostSearchDependencies) {
  return async (
    query: string,
    options: SubmittedPostSearchOptions = {},
    settledCatalog?: FederatedPostSearchResponse | null,
  ): Promise<FederatedPostSearchResponse> => {
    const signal = options.signal ?? null;
    const submittedQuery = query.trim();
    throwIfPostSearchAborted(signal);
    if (submittedQuery.length < 2) {
      return emptyResponse;
    }
    const catalog = settledCatalog === undefined
      ? await dependencies.searchCatalog(submittedQuery, options)
      : settledCatalog;
    throwIfPostSearchAborted(signal);
    if (catalog?.results.length) {
      return catalog;
    }

    const relays = dependencies.getRelays();
    if (relays.length === 0 || new TextEncoder().encode(submittedQuery).byteLength > MAX_SEARCH_QUERY_BYTES) {
      return catalog ?? emptyResponse;
    }
    const plan = planPostSearch(submittedQuery);
    const relayQuery = plan.relayQuery.trim() || submittedQuery;
    const terms = parsePostSearchRoutingQueryTerms(relayQuery);
    if (terms.length === 0) {
      return catalog ?? emptyResponse;
    }
    const requestedLimit = options.limit ?? POST_SEARCH_INITIAL_LIMIT;
    const limit = Number.isFinite(requestedLimit)
      ? Math.max(1, Math.min(POST_SEARCH_MAX_LIMIT, Math.trunc(requestedLimit)))
      : POST_SEARCH_INITIAL_LIMIT;
    const candidateLimit = 2 * limit;
    const publisherId = relays[0]!;
    const filters = [{ kinds: [...POST_SEARCH_KINDS], search: relayQuery, limit: candidateLimit }];
    const rank = (events: NostrVerifiedEvent[], complete: boolean, pending = false): FederatedPostSearchResponse => {
      const lexicalQuery = plan.browse ? relayQuery : submittedQuery;
      const lexicalHits = searchLocalPosts(events, lexicalQuery, {
        limit: candidateLimit,
        operator: plan.browse ? 'or' : 'and',
        authorTextByPubkey: null,
      });
      const nonSpamHits = lexicalHits.filter((hit) => lexicalMatch(plan, hit.event) >= 0);
      const effectiveHits = nonSpamHits.length > 0 ? nonSpamHits : lexicalHits;
      const ranked = effectiveHits
        .map((hit) => {
          const info = getLoadedSocialGraphAuthorInfo(hit.event.pubkey);
          const trust = info ? authorSignal(info.distance, info.followers) : 0;
          const substance = postSubstanceFactor(plan, hit.event);
          return {
            event: hit.event,
            score: hit.score * substance * (0.7 + 0.3 * trust),
          };
        })
        .sort((left, right) => (
          right.score - left.score
          || right.event.created_at - left.event.created_at
          || left.event.id.localeCompare(right.event.id)
        ));
      // Several authors can publish the exact same long note. Show distinct
      // answers first and fill any remaining slots with their separate discussions.
      const seenText = new Set<string>();
      const distinct = [];
      const repeats = [];
      for (const hit of ranked) {
        const text = hit.event.kind === 1 && hit.event.content.length >= 80
          ? hit.event.content.replace(/\s+/gu, ' ').trim() : '';
        if (text.length >= 80 && seenText.has(text)) {
          repeats.push(hit);
        } else {
          distinct.push(hit);
          if (text.length >= 80) { seenText.add(text); }
        }
      }
      const posts = distinct.concat(repeats).slice(0, limit);
      const truncated = events.length >= candidateLimit;
      return {
        results: posts.map(({ event, score }) => ({
          event,
          score,
          lexicalScore: score,
          matchedTerms: terms,
          matchedPhrases: 0,
          publisherIds: [publisherId],
        })),
        failures: complete || pending ? [] : [{
          publisherId,
          status: posts.length > 0 ? 'partial' : 'unavailable',
          failedSegments: 0,
          message: 'Public relay search did not finish',
        }],
        searchedPublishers: complete || posts.length > 0 ? 1 : 0,
        exhaustive: complete && !truncated,
        truncatedPublishers: truncated ? [publisherId] : [],
      };
    };
    const seen = new Map<string, NostrVerifiedEvent>();
    const reader = dependencies.createReader(dependencies.getRelays, options.onProgress && (batch => {
      if (signal?.aborted) { return; }
      for (const event of batch) { seen.set(event.id, event); }
      if (seen.size) { options.onProgress?.(rank([...seen.values()], false, true)); }
    }));
    const report = await withPostSearchAbortTimeout((relaySignal) => reader.query(filters, {
      limit: candidateLimit,
      deadline: Date.now() + SEARCH_NETWORK_TIMEOUT_MS,
      signal: relaySignal,
    }), SEARCH_RESPONSE_TIMEOUT_MS, signal).catch(() => {
      throwIfPostSearchAborted(signal);
      return { events: [], complete: false };
    });
    const events = report.events.map(({ event }) => event);
    return rank(events.length || report.complete ? events : [...seen.values()], report.complete === true);
  };
}
