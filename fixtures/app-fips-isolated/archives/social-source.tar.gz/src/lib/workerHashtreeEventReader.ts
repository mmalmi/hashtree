import { isHashtreeObjectKey } from './hashtreeObjectKey';
import type {
  HashtreeNostrRootEntry,
  HashtreeNostrRootProvider,
} from '@hashtree/nostr-pubsub';
import {
  SOURCE_PRIORITY_LOCAL_INDEX,
  cloneFilter,
  filtersMatch,
  localIndexSource,
  verifyNostrEventsWith,
  type NostrEventReader,
  type NostrFilter,
  type NostrVerifiedEvent,
  type QueryOptions,
  type QueryReport,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import type { SocialWorkerClient } from './workerClient';
import type { SocialWorkerHashtreeRoot } from '../workers/socialWorkerProtocol';
import { MAX_SOCIAL_WORKER_HASHTREE_QUERY_EVENTS } from '../workers/socialWorkerHashtreeLimits';

const DURABLE_SOURCE = localIndexSource('iris-social-hashtree-indexes');
const MAX_QUERY_LIMIT = MAX_SOCIAL_WORKER_HASHTREE_QUERY_EVENTS;
const MAX_QUERY_ROOTS = 32;

type HashtreeQueryClient = Pick<SocialWorkerClient, 'queryHashtreeEvents'>;

type WorkerHashtreeEventReaderOptions = {
  roots: HashtreeNostrRootProvider;
  storeKindForRoot(root: HashtreeNostrRootEntry): 'shared' | 'personal';
  getClient?(): Promise<HashtreeQueryClient>;
};

/**
 * Durable Hashtree adapter whose traversal and Schnorr verification both run
 * in the existing social worker. This side only validates and canonically
 * admits the exact response attached to its tracked worker request.
 */
export function createWorkerHashtreeEventReader(
  options: WorkerHashtreeEventReaderOptions,
): NostrEventReader {
  const getClient = options.getClient ?? defaultWorkerClient;
  return {
    async query(filters: NostrFilter[], queryOptions: QueryOptions = {}): Promise<QueryReport> {
      validateQueryOptions(queryOptions);
      throwIfAborted(queryOptions.signal);
      const limit = boundedQueryLimit(filterSnapshotLimit(filters), queryOptions.limit);
      if (limit === 0) {
        return { events: [], complete: true };
      }
      const filterSnapshot = filters.map(cloneFilter);
      const roots = await options.roots.snapshot({
        filters: filterSnapshot.map(cloneFilter),
        signal: queryOptions.signal,
        deadline: queryOptions.deadline,
      });
      throwIfAborted(queryOptions.signal);
      if (!Array.isArray(roots) || roots.length > MAX_QUERY_ROOTS) {
        throw new Error('Hashtree root snapshot exceeds worker capacity');
      }
      if (roots.length === 0) {
        return { events: [], complete: true };
      }
      const workerRoots = roots.map((root) => serializeRoot(
        root,
        options.storeKindForRoot(root),
      ));
      const client = await getClient();
      throwIfAborted(queryOptions.signal);
      const report = await client.queryHashtreeEvents(
        workerRoots,
        filterSnapshot.map(cloneFilter),
        {
          limit,
          deadline: queryOptions.deadline,
          signal: queryOptions.signal,
        },
      );
      throwIfAborted(queryOptions.signal);
      if (
        typeof report.complete !== 'boolean'
        || !Array.isArray(report.events)
        || report.events.length > limit
      ) {
        throw new Error('Invalid Hashtree worker query response');
      }
      const admittedEvents = await admitTrustedHashtreeWorkerEvents(
        report.events,
        queryOptions.signal,
      );
      const byId = new Map<string, NostrVerifiedEvent>();
      for (const event of admittedEvents) {
        if (!filtersMatch(filterSnapshot, event)) {
          throw new Error('Hashtree worker returned an event outside the requested filters');
        }
        if (!byId.has(event.id)) {
          byId.set(event.id, event);
        }
      }
      return {
        events: [...byId.values()]
          .sort((left, right) => (
            right.created_at - left.created_at || left.id.localeCompare(right.id)
          ))
          .map((event) => ({
            event,
            source: DURABLE_SOURCE,
            priority: SOURCE_PRIORITY_LOCAL_INDEX,
          })),
        complete: report.complete,
      };
    },
  };
}

function serializeRoot(
  entry: HashtreeNostrRootEntry,
  storeKind: 'shared' | 'personal',
): SocialWorkerHashtreeRoot {
  if (
    typeof entry.partitionId !== 'string'
    || entry.partitionId.length === 0
    || entry.partitionId.includes('\u0000')
    || (
      entry.replicaId !== undefined
      && (
        typeof entry.replicaId !== 'string'
        || entry.replicaId.length === 0
        || entry.replicaId.includes('\u0000')
      )
    )
  ) {
    throw new Error('Invalid Hashtree root snapshot identity');
  }
  const root = entry.root;
  if (
    root !== null
    && (
      !(root.hash instanceof Uint8Array)
      || root.hash.byteLength !== 32
      || (
        root.key !== undefined
        && !isHashtreeObjectKey(root.key)
      )
    )
  ) {
    throw new Error('Invalid Hashtree root snapshot CID');
  }
  return {
    partitionId: entry.partitionId,
    replicaId: entry.replicaId,
    root: root === null
      ? null
      : {
          hash: root.hash.slice(),
          key: root.key?.slice(),
        },
    storeKind,
  };
}

/**
 * The tracked worker query already ran the production Hashtree reader's
 * signature checks. This private all-true callback does no crypto; it asks
 * nostr-pubsub to make immutable canonical copies for downstream routers.
 */
function admitTrustedHashtreeWorkerEvents(
  events: readonly RawEvent[],
  signal?: AbortSignal,
): Promise<NostrVerifiedEvent[]> {
  return verifyNostrEventsWith(
    events,
    async (trustedWorkerEvents) => trustedWorkerEvents.map(() => true),
    { signal },
  );
}

async function defaultWorkerClient(): Promise<HashtreeQueryClient> {
  return await (await import('./workerClient')).getWorkerClient();
}

function validateQueryOptions(options: QueryOptions): void {
  if (
    options.limit !== undefined
    && (
      !Number.isSafeInteger(options.limit)
      || options.limit < 0
      || options.limit > MAX_QUERY_LIMIT
    )
  ) {
    throw new RangeError(
      `Hashtree query limit must be between zero and ${MAX_QUERY_LIMIT}`,
    );
  }
  if (options.deadline !== undefined && !Number.isFinite(options.deadline)) {
    throw new RangeError('Hashtree query deadline must be finite');
  }
}

function filterSnapshotLimit(filters: readonly NostrFilter[]): number | undefined {
  let aggregate = 0;
  for (const filter of filters) {
    if (!Number.isSafeInteger(filter.limit) || (filter.limit ?? -1) < 0) {
      return undefined;
    }
    aggregate = Math.min(MAX_QUERY_LIMIT, aggregate + filter.limit!);
  }
  return filters.length === 0 ? undefined : aggregate;
}

function boundedQueryLimit(
  filterLimit: number | undefined,
  explicitLimit: number | undefined,
): number {
  return explicitLimit ?? filterLimit ?? MAX_QUERY_LIMIT;
}

function throwIfAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) {
    throw new DOMException('Hashtree query cancelled', 'AbortError');
  }
}
