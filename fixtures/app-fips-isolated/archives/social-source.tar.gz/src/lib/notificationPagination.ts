import type { CID } from '@hashtree/core';
import type { RawEvent } from './nostr';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';
import { routedEventsByTag } from './routedEventReads';

export const NOTIFICATION_EVENT_KINDS = [1, 6, 7, 16, 20, 1_111, 9_735, 30_023] as const;

export type AddressedNotificationPage = {
  cursor: RecentTextNoteCursor | null;
  events: RawEvent[];
  hasMore: boolean;
};

export type NotificationTagReader = {
  getRecentEventsByTag: (
    tagName: string,
    tagValue: string,
    options: {
      before?: RecentTextNoteCursor;
      kinds?: number[];
      limit?: number;
    },
  ) => Promise<RawEvent[]>;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

export function mergeAddressedNotificationEvents(
  eventLists: RawEvent[][],
  viewerPubkey: string,
  before?: RecentTextNoteCursor,
): RawEvent[] {
  const normalizedViewer = viewerPubkey.trim().toLowerCase();
  const supportedKinds = new Set<number>(NOTIFICATION_EVENT_KINDS);
  const byId = new Map<string, RawEvent>();

  for (const event of eventLists.flat()) {
    if (
      byId.has(event.id)
      || !supportedKinds.has(event.kind)
      || !isStrictlyBeforeRecentCursor(event.created_at, event.id, before)
      || !event.tags.some((tag) => tag[0]?.toLowerCase() === 'p' && tag[1]?.toLowerCase() === normalizedViewer)
    ) {
      continue;
    }
    byId.set(event.id, event);
  }

  return [...byId.values()].sort(compareNewest);
}

export async function loadAddressedNotificationEventsPage<Root>(options: {
  before?: RecentTextNoteCursor;
  getReader: (root: Root) => NotificationTagReader;
  limit: number;
  roots: Root[];
  viewerPubkey: string;
}): Promise<AddressedNotificationPage> {
  const limit = Math.max(1, Math.trunc(options.limit));
  const candidates = mergeAddressedNotificationEvents(
    await Promise.all(options.roots.map(async (root) => (
      await options.getReader(root).getRecentEventsByTag('p', options.viewerPubkey, {
        before: options.before,
        kinds: [...NOTIFICATION_EVENT_KINDS],
        limit: limit + 1,
      })
    ))),
    options.viewerPubkey,
    options.before,
  );
  const events = candidates.slice(0, limit);
  const boundary = events.at(-1);

  return {
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : options.before ?? null,
    events,
    hasMore: candidates.length > limit,
  };
}

/** Keep the common notification scan and signature admission in the worker. */
export async function loadRoutedAddressedNotificationEventsPage(options: {
  before?: RecentTextNoteCursor;
  limit: number;
  roots: CID[];
  viewerPubkey: string;
  loadEventsByTag?: typeof routedEventsByTag;
}): Promise<AddressedNotificationPage> {
  const limit = Math.max(1, Math.trunc(options.limit));
  const loadEventsByTag = options.loadEventsByTag ?? routedEventsByTag;
  const candidates = mergeAddressedNotificationEvents([
    await loadEventsByTag(
      options.roots,
      'p',
      options.viewerPubkey,
      [...NOTIFICATION_EVENT_KINDS],
      limit + 1,
      options.before,
    ),
  ], options.viewerPubkey, options.before);
  const events = candidates.slice(0, limit);
  const boundary = events.at(-1);
  return {
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : options.before ?? null,
    events,
    hasMore: candidates.length > limit,
  };
}
