export const QR_SCAN_INTERVAL_MS = 200;
export const QR_SCAN_MAX_EDGE = 640;

export interface QrScanFrameSize {
  width: number;
  height: number;
}

export function fitQrScanFrame(
  sourceWidth: number,
  sourceHeight: number,
  maxEdge = QR_SCAN_MAX_EDGE,
): QrScanFrameSize {
  if (sourceWidth <= 0 || sourceHeight <= 0 || maxEdge <= 0) {
    return { width: 0, height: 0 };
  }

  const scale = Math.min(1, maxEdge / Math.max(sourceWidth, sourceHeight));
  return {
    width: Math.max(1, Math.round(sourceWidth * scale)),
    height: Math.max(1, Math.round(sourceHeight * scale)),
  };
}
