import { type Store } from '@hashtree/core';
import { BTree } from '@hashtree/index';
import { throwIfPostSearchAborted } from './postSearchAbort';
import type { PostSearchGlobalScoringIndex } from './postSearchGlobalScoring';
import { parsePostSearchRoutingQueryTerms } from './postSearchTermRouting';

export const POST_SEARCH_MIN_EXPANSION_TERM_LENGTH = 3;
export const POST_SEARCH_MAX_EXPANSION_TERM_LENGTH = 24;
export const POST_SEARCH_MAX_EXPANDED_TERMS = 8;
export const POST_SEARCH_MAX_PREFIX_TERMS_READ = 24;
const DIRECT_LOOKUP_CONCURRENCY = 6;

/**
 * Conservatively recover a single unfinished or mistyped plain term from the
 * authenticated catalog vocabulary. Exact terms and structured queries are
 * intentionally left byte-for-byte unchanged.
 */
export async function expandPostSearchQuery(
  store: Store,
  scoring: PostSearchGlobalScoringIndex | null,
  query: string,
  operator: 'or' | 'and',
  signal: AbortSignal | null,
): Promise<string> {
  throwIfPostSearchAborted(signal);
  if (!scoring?.termsRoot) {
    return query;
  }
  const term = postSearchExpansionTerm(query, operator);
  if (!term) {return query;}

  const vocabulary = new BTree(store);
  if (await vocabulary.get(scoring.termsRoot, term) !== null) {
    return query;
  }
  throwIfPostSearchAborted(signal);

  const prefixMatches = await readVocabularyPrefix(
    vocabulary,
    scoring.termsRoot,
    term,
    signal,
    (candidate) => candidate !== term && !candidate.startsWith('#'),
    POST_SEARCH_MAX_PREFIX_TERMS_READ,
  );
  if (prefixMatches.matches.length > 0) {
    return joinExpandedTerms(prefixMatches.matches);
  }

  const directCandidates = postSearchOneEditDirectCandidates(term);
  const directMatches = await mapConcurrent(
    directCandidates,
    DIRECT_LOOKUP_CONCURRENCY,
    async (candidate) => {
      throwIfPostSearchAborted(signal);
      return await vocabulary.get(scoring.termsRoot, candidate) === null ? null : candidate;
    },
  );
  throwIfPostSearchAborted(signal);

  const matches = new Set(directMatches.filter((candidate): candidate is string => candidate !== null));
  if (matches.size < POST_SEARCH_MAX_EXPANDED_TERMS) {
    let remainingReads = POST_SEARCH_MAX_PREFIX_TERMS_READ;
    const characters = [...term];
    for (let anchorLength = Math.max(2, characters.length - 2);
      anchorLength >= 2
        && remainingReads > 0
        && matches.size < POST_SEARCH_MAX_EXPANDED_TERMS;
      anchorLength -= 1) {
      const anchor = characters.slice(0, anchorLength).join('');
      const scanned = await readVocabularyPrefix(
        vocabulary,
        scoring.termsRoot,
        anchor,
        signal,
        (candidate) => candidate !== term
          && !candidate.startsWith('#')
          && isPostSearchOneEditApart(term, candidate),
        remainingReads,
      );
      remainingReads -= scanned.read;
      scanned.matches.forEach((candidate) => matches.add(candidate));
    }
  }

  return matches.size === 0
    ? query
    : joinExpandedTerms(rankPostSearchExpansionCandidates(term, matches));
}

/** Return the one normalized term eligible for conservative vocabulary recovery. */
export function postSearchExpansionTerm(
  query: string,
  operator: 'or' | 'and',
): string | null {
  if (operator !== 'or') {return null;}
  const terms = parsePostSearchRoutingQueryTerms(query);
  const parsedTerm = terms[0];
  if (terms.length !== 1 || !parsedTerm || !isExpandablePlainQuery(query, parsedTerm)) {
    return null;
  }
  const length = [...parsedTerm].length;
  return length >= POST_SEARCH_MIN_EXPANSION_TERM_LENGTH
    && length <= POST_SEARCH_MAX_EXPANSION_TERM_LENGTH
    ? parsedTerm
    : null;
}

function isExpandablePlainQuery(query: string, parsedTerm: string): boolean {
  if (parsedTerm.startsWith('#') || /["“”#]/u.test(query)) {
    return false;
  }
  const normalized = query.normalize('NFKC').toLowerCase().replace(/’/g, "'").trim();
  return normalized === parsedTerm;
}

async function readVocabularyPrefix(
  vocabulary: BTree,
  root: NonNullable<PostSearchGlobalScoringIndex['termsRoot']>,
  prefix: string,
  signal: AbortSignal | null,
  include: (candidate: string) => boolean,
  maxReads: number,
): Promise<{ matches: string[]; read: number }> {
  const matches: string[] = [];
  let read = 0;
  for await (const [candidate] of vocabulary.prefix(root, prefix)) {
    throwIfPostSearchAborted(signal);
    read += 1;
    if (include(candidate)) {
      matches.push(candidate);
      if (matches.length >= POST_SEARCH_MAX_EXPANDED_TERMS) {
        break;
      }
    }
    if (read >= maxReads) {
      break;
    }
  }
  return { matches: rankPostSearchExpansionCandidates(prefix, matches), read };
}

/** Bounded deletions/transpositions that can be checked with exact vocabulary lookups. */
export function postSearchOneEditDirectCandidates(term: string): string[] {
  const characters = [...term];
  const candidates = new Set<string>();
  for (let index = 0; index < characters.length; index += 1) {
    const deleted = [...characters.slice(0, index), ...characters.slice(index + 1)].join('');
    if ([...deleted].length >= POST_SEARCH_MIN_EXPANSION_TERM_LENGTH) {
      candidates.add(deleted);
    }
    if (index + 1 < characters.length && characters[index] !== characters[index + 1]) {
      const transposed = [...characters];
      [transposed[index], transposed[index + 1]] = [transposed[index + 1], transposed[index]];
      candidates.add(transposed.join(''));
    }
  }
  return [...candidates].sort(compareStrings);
}

export function isPostSearchOneEditApart(left: string, right: string): boolean {
  const a = [...left];
  const b = [...right];
  if (Math.abs(a.length - b.length) > 1 || (a.length === 0 && b.length === 0)) {
    return false;
  }
  if (a.length === b.length) {
    const differences: number[] = [];
    for (let index = 0; index < a.length; index += 1) {
      if (a[index] !== b[index]) {
        differences.push(index);
      }
      if (differences.length > 2) {
        return false;
      }
    }
    return differences.length === 1
      || (differences.length === 2
        && differences[1] === differences[0] + 1
        && a[differences[0]] === b[differences[1]]
        && a[differences[1]] === b[differences[0]]);
  }
  const shorter = a.length < b.length ? a : b;
  const longer = a.length < b.length ? b : a;
  let shortIndex = 0;
  let longIndex = 0;
  let skipped = false;
  while (shortIndex < shorter.length && longIndex < longer.length) {
    if (shorter[shortIndex] === longer[longIndex]) {
      shortIndex += 1;
      longIndex += 1;
      continue;
    }
    if (skipped) {
      return false;
    }
    skipped = true;
    longIndex += 1;
  }
  return true;
}

function joinExpandedTerms(candidates: readonly string[]): string {
  return candidates.slice(0, POST_SEARCH_MAX_EXPANDED_TERMS).join(' ');
}

/** Deduplicate and rank expansion terms identically across catalog formats and runs. */
export function rankPostSearchExpansionCandidates(
  prefix: string,
  candidates: Iterable<string>,
): string[] {
  return [...new Set(candidates)]
    .sort(compareExpansionCandidates(prefix))
    .slice(0, POST_SEARCH_MAX_EXPANDED_TERMS);
}

function compareExpansionCandidates(prefix: string): (left: string, right: string) => number {
  return (left, right) => {
    const leftPrefix = left.startsWith(prefix) ? 0 : 1;
    const rightPrefix = right.startsWith(prefix) ? 0 : 1;
    return leftPrefix - rightPrefix
      || [...left].length - [...right].length
      || compareStrings(left, right);
  };
}

async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input) => Promise<Output>,
): Promise<Output[]> {
  const results = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await worker(values[index]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return results;
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
