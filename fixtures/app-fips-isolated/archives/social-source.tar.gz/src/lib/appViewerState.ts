import type { CID } from '@hashtree/core';
import type { ProfileRecord, RawEvent } from './nostr';
import { extractFollowPubkeys } from './nostr';
import { loadNotificationsData } from './appDetailLoaders';
import {
  getRootNhash,
  resolveProfileEventIndexRoot,
} from './nostrIndex';
import { getViewerRoots } from './appViewState';
import { selectNewestAdmittedMuteListEvent } from './muteLists';
import { selectNewestAdmittedProfileMetadataEvent } from './profileMetadata';
import { throwIfProfileSearchAborted, withProfileSearchAbort } from './profileSearchAbort';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { loadSnapshotSocialGraphProfileSocial } from './socialGraphProfileSnapshot';
import { routedLatestEventByAuthorKind } from './routedEventReads';
import {
  loadSocialGraphFrontier,
  selectViewerRootFrontierFollows,
} from './socialGraphFrontier';

export async function resolveViewerPersonalRoot(
  currentRoot: CID | null,
  viewerPubkey: string,
): Promise<CID | null> {
  const personalRoot = await resolveProfileEventIndexRoot(viewerPubkey);
  if (
    !personalRoot
    || (currentRoot && getRootNhash(personalRoot) === getRootNhash(currentRoot))
  ) {
    return null;
  }

  return personalRoot;
}

export async function loadViewerFollowsState(
  currentRoot: CID | null,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
): Promise<{
  contactsEvent: RawEvent | null;
  follows: Set<string>;
}> {
  const contactsCandidates = await loadPreferredViewerEventCandidates(
    currentRoot,
    viewerPersonalRoot,
    viewerPubkey,
    3,
  );

  const latestContacts = contactsCandidates
    .filter((event): event is RawEvent => Boolean(event))
    .sort((left, right) => right.created_at - left.created_at)[0] ?? null;

  return {
    contactsEvent: latestContacts,
    follows: new Set(extractFollowPubkeys(latestContacts)),
  };
}

export async function loadViewerGraphFollowsState(
  _currentRoot: CID | null,
  viewerPubkey: string,
): Promise<Set<string>> {
  const frontierFollows = selectViewerRootFrontierFollows(
    viewerPubkey,
    await loadSocialGraphFrontier(),
  );
  if (frontierFollows?.length) {
    return new Set(frontierFollows);
  }

  const social = await loadSnapshotSocialGraphProfileSocial(viewerPubkey, 65_536);
  return new Set(social?.follows ?? []);
}

export async function loadViewerMuteListState(
  currentRoot: CID | null,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
): Promise<RawEvent | null> {
  const candidates = await loadPreferredViewerEventCandidates(
    currentRoot,
    viewerPersonalRoot,
    viewerPubkey,
    10_000,
  );
  return selectNewestAdmittedMuteListEvent(candidates, viewerPubkey);
}

export async function loadViewerProfileMetadataState(
  currentRoot: CID | null,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
): Promise<RawEvent | null> {
  const candidates = await loadPreferredViewerEventCandidates(
    currentRoot,
    viewerPersonalRoot,
    viewerPubkey,
    0,
  );
  return selectNewestAdmittedProfileMetadataEvent(candidates, viewerPubkey);
}

async function loadPreferredViewerEventCandidates(
  currentRoot: CID | null,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
  kind: number,
): Promise<Array<RawEvent | null>> {
  if (viewerPersonalRoot) {
    // A personal head is built by merging the last published base before local
    // appends. Its own viewer event is therefore authoritative and must not be
    // held behind a slow or offline shared index read.
    const personalEvent = await routedLatestEventByAuthorKind(
      [viewerPersonalRoot],
      viewerPubkey,
      kind,
    );
    if (personalEvent) {
      return [personalEvent];
    }
  }

  const sharedRoots = getViewerRoots(currentRoot, null);
  return [await routedLatestEventByAuthorKind(sharedRoots, viewerPubkey, kind)];
}

export async function loadNotificationsState(
  currentRoot: CID,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
  accountProfiles: Map<string, ProfileRecord>,
  options: {
    before?: RecentTextNoteCursor;
    includeViewerState?: boolean;
    limit?: number;
  } = {},
) {
  return loadNotificationsData(
    getViewerRoots(currentRoot, viewerPersonalRoot),
    viewerPubkey,
    accountProfiles,
    options,
  );
}

export async function searchRemoteProfiles(
  query: string,
  limit: number,
  signal: AbortSignal | null = null,
  onProgress: ((profiles: ProfileRecord[]) => void) | null = null,
): Promise<ProfileRecord[]> {
  if (!query.trim()) {
    return [];
  }

  throwIfProfileSearchAborted(signal);
  const { searchProfileSearchRollout } = await withProfileSearchAbort(
    import('./profileSearchV3Runtime'),
    signal,
  );
  return searchProfileSearchRollout(query, limit, signal, onProgress);
}
