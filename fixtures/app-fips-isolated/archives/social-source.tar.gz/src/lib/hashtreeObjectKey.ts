import { encryptionMode } from '@hashtree/core';

export function isHashtreeObjectKey(key: unknown): key is Uint8Array {
  if (!(key instanceof Uint8Array)) {return false;}
  try {
    encryptionMode(key);
    return true;
  } catch {
    return false;
  }
}
