import type { ProfileRecord } from './nostr';

export const PROFILE_REFRESH_TTL_MS = 5 * 60_000;
const RETRY_MS = 60_000;
const BATCH_SIZE = 16;

type RefreshResult = { profiles: Map<string, ProfileRecord>; complete: boolean };
type Options = {
  refresh(pubkeys: string[], signal: AbortSignal): Promise<RefreshResult>;
  onProfiles(profiles: Iterable<ProfileRecord>): void;
  ttlMs?: number;
};

/** One bounded refresh queue for mounted identities; cache reads never count as revalidation. */
export function createProfileRefreshQueue(options: Options) {
  const watchers = new Map<string, number>();
  const nextChecks = new Map<string, number>();
  let active = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let pending: { authors: string[]; controller: AbortController } | null = null;

  function schedule(): void {
    clearTimeout(timer);
    timer = undefined;
    if (!active || pending || watchers.size === 0) { return; }
    let next = Infinity;
    for (const pubkey of watchers.keys()) {
      next = Math.min(next, nextChecks.get(pubkey) ?? 0);
    }
    timer = setTimeout(() => { timer = undefined; void run(); }, Math.max(50, next - Date.now()));
  }

  async function run(): Promise<void> {
    if (!active || pending) { return; }
    const authors = [...watchers.keys()]
      .filter(pubkey => (nextChecks.get(pubkey) ?? 0) <= Date.now())
      .slice(0, BATCH_SIZE);
    if (authors.length === 0) { schedule(); return; }
    const controller = new AbortController();
    pending = { authors, controller };
    try {
      const result = await options.refresh(authors, controller.signal);
      if (controller.signal.aborted) { return; }
      options.onProfiles(result.profiles.values());
      for (const pubkey of authors) {
        nextChecks.delete(pubkey);
        nextChecks.set(pubkey, Date.now() + (result.complete && result.profiles.has(pubkey)
          ? options.ttlMs ?? PROFILE_REFRESH_TTL_MS : RETRY_MS));
      }
    } catch {
      if (!controller.signal.aborted) {
        for (const pubkey of authors) { nextChecks.set(pubkey, Date.now() + RETRY_MS); }
      }
    } finally {
      pending = null;
      // Bound bookkeeping during long sessions, retaining the most recently checked authors.
      while (nextChecks.size > 4096) { nextChecks.delete(nextChecks.keys().next().value!); }
      schedule();
    }
  }

  return {
    watch(pubkey: string): () => void {
      if (!/^[0-9a-f]{64}$/.test(pubkey)) { return () => undefined; }
      watchers.set(pubkey, (watchers.get(pubkey) ?? 0) + 1);
      schedule();
      return () => {
        const count = watchers.get(pubkey) ?? 0;
        if (count <= 1) { watchers.delete(pubkey); }
        else { watchers.set(pubkey, count - 1); }
        if (pending?.authors.every(author => !watchers.has(author))) { pending.controller.abort(); }
        schedule();
      };
    },
    setActive(value: boolean): void {
      active = value;
      if (!active) { pending?.controller.abort(); }
      schedule();
    },
  };
}
