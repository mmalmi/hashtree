import type { ProfileRecord } from './nostr';

export const PROFILE_REFRESH_TTL_MS = 5 * 60_000;
const RETRY_MS = 60_000;
// An author with no answer yet is asked again sooner: on a cold start the
// first lookup can end before a busy worker has delivered anything.
const UNANSWERED_RETRY_DELAYS_MS = [5_000, 15_000, 45_000];
const BATCH_SIZE = 16;

type RefreshResult = { profiles: Map<string, ProfileRecord>; complete: boolean };
type Options = {
  refresh(pubkeys: string[], signal: AbortSignal): Promise<RefreshResult>;
  onProfiles(profiles: Iterable<ProfileRecord>): void;
  ttlMs?: number;
  unansweredRetryDelaysMs?: readonly number[];
};

/** One bounded refresh queue for mounted identities; cache reads never count as revalidation. */
export function createProfileRefreshQueue(options: Options) {
  const watchers = new Map<string, number>();
  // Open profile pages. They are refreshed in their own lane so they never
  // wait behind a batch of feed authors.
  const priorityWatchers = new Map<string, number>();
  const nextChecks = new Map<string, number>();
  const unanswered = new Map<string, number>();
  const unansweredDelays = options.unansweredRetryDelaysMs ?? UNANSWERED_RETRY_DELAYS_MS;

  function unansweredDelay(pubkey: string): number {
    const attempt = unanswered.get(pubkey) ?? 0;
    unanswered.set(pubkey, attempt + 1);
    return unansweredDelays[attempt] ?? RETRY_MS;
  }
  let active = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let pending: { authors: string[]; controller: AbortController } | null = null;
  let priorityPending: { authors: string[]; controller: AbortController } | null = null;
  let priorityTimer: ReturnType<typeof setTimeout> | undefined;

  function isDue(pubkey: string): boolean {
    return (nextChecks.get(pubkey) ?? 0) <= Date.now();
  }

  function schedulePriority(): void {
    clearTimeout(priorityTimer);
    priorityTimer = undefined;
    if (!active || priorityPending || priorityWatchers.size === 0) { return; }
    let next = Infinity;
    for (const pubkey of priorityWatchers.keys()) {
      if (pending?.authors.includes(pubkey)) { continue; }
      next = Math.min(next, nextChecks.get(pubkey) ?? 0);
    }
    if (next === Infinity) { return; }
    priorityTimer = setTimeout(() => { priorityTimer = undefined; void run(true); }, Math.max(0, next - Date.now()));
  }

  function schedule(): void {
    clearTimeout(timer);
    timer = undefined;
    schedulePriority();
    if (!active || pending || watchers.size === 0) { return; }
    let next = Infinity;
    for (const pubkey of watchers.keys()) {
      if (priorityPending?.authors.includes(pubkey)) { continue; }
      next = Math.min(next, nextChecks.get(pubkey) ?? 0);
    }
    if (next === Infinity) { return; }
    timer = setTimeout(() => { timer = undefined; void run(); }, Math.max(50, next - Date.now()));
  }

  async function run(priority = false): Promise<void> {
    if (!active || (priority ? priorityPending : pending)) { return; }
    const busy = new Set(priority ? pending?.authors ?? [] : priorityPending?.authors ?? []);
    const source = priority ? priorityWatchers : watchers;
    const authors = [...source.keys()]
      .filter(pubkey => isDue(pubkey) && !busy.has(pubkey))
      .slice(0, BATCH_SIZE);
    if (authors.length === 0) { schedule(); return; }
    const controller = new AbortController();
    const lane = { authors, controller };
    if (priority) { priorityPending = lane; } else { pending = lane; }
    try {
      const result = await options.refresh(authors, controller.signal);
      if (controller.signal.aborted) { return; }
      options.onProfiles(result.profiles.values());
      for (const pubkey of authors) {
        nextChecks.delete(pubkey);
        if (!result.profiles.has(pubkey)) {
          nextChecks.set(pubkey, Date.now() + unansweredDelay(pubkey));
          continue;
        }
        unanswered.delete(pubkey);
        nextChecks.set(pubkey, Date.now() + (result.complete
          ? options.ttlMs ?? PROFILE_REFRESH_TTL_MS : RETRY_MS));
      }
    } catch {
      if (!controller.signal.aborted) {
        for (const pubkey of authors) { nextChecks.set(pubkey, Date.now() + unansweredDelay(pubkey)); }
      }
    } finally {
      if (priority) { priorityPending = null; } else { pending = null; }
      // Bound bookkeeping during long sessions, retaining the most recently checked authors.
      while (nextChecks.size > 4096) { nextChecks.delete(nextChecks.keys().next().value!); }
      while (unanswered.size > 4096) { unanswered.delete(unanswered.keys().next().value!); }
      schedule();
    }
  }

  return {
    watch(pubkey: string, watchOptions: { priority?: boolean } = {}): () => void {
      if (!/^[0-9a-f]{64}$/.test(pubkey)) { return () => undefined; }
      const target = watchOptions.priority ? priorityWatchers : watchers;
      target.set(pubkey, (target.get(pubkey) ?? 0) + 1);
      schedule();
      return () => {
        const count = target.get(pubkey) ?? 0;
        if (count <= 1) { target.delete(pubkey); }
        else { target.set(pubkey, count - 1); }
        if (pending?.authors.every(author => !watchers.has(author))) { pending.controller.abort(); }
        if (priorityPending?.authors.every(author => !priorityWatchers.has(author))) {
          priorityPending.controller.abort();
        }
        schedule();
      };
    },
    setActive(value: boolean): void {
      active = value;
      if (!active) { pending?.controller.abort(); priorityPending?.controller.abort(); }
      schedule();
    },
  };
}
