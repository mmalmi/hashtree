import type { CID } from '@hashtree/core';
import type { FeedSnapshot, ProfileSocialSnapshot, NoteThreadSnapshot } from './nostrIndex';
import type { ProfileSnapshot } from './profileNotes';
import type { NotificationItem } from './appDetailLoaders';
import type { ProfileRecord, RawEvent } from './nostr';
import type { NoteEngagement } from './noteEngagement';
import type { Route } from './appRoute';
import type { RouteRenderCache, RouteStackEntry } from './appStack';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { cloneHomeFeedContinuation, mergeUniqueFeedNotes } from './homeFeedPagination';
import { hasLiveRouteContent } from './appViewState';

export type RestoredLiveRouteState = {
  loading: boolean;
  feedRequiresRefresh: boolean;
  noteEngagements: Map<string, NoteEngagement>;
  feed: FeedSnapshot | null;
  homeFeedLoadPending: boolean;
  feedLimit: number;
  homeFeedFetchLimit: number;
  homeFeedLastLoadScrollOffset: number;
  notifications: NotificationItem[];
  notificationsLoading: boolean;
  notificationsHasMore: boolean;
  notificationsLoadPending: boolean;
  profilePage: ProfileSnapshot | null;
  loadedProfilePubkey: string | null;
  profileSocial: ProfileSocialSnapshot | null;
  profileSocialLoading: boolean;
  profileSocialLoadPending: boolean;
  profileNotesLoading: boolean;
  profileFeedLoadPending: boolean;
  profileNoteLimit: number;
  profileNoteFetchLimit: number;
  profileFeedLastLoadScrollOffset: number;
  profileSocialVisibleLimit: number;
  profileSocialFollowerFetchLimit: number;
  threadPage: NoteThreadSnapshot | null;
  threadRoots: CID[];
  threadReplyCursor: RecentTextNoteCursor | null;
  threadReplies: RawEvent[];
  threadDurableRepliesHasMore: boolean;
  threadRepliesHasMore: boolean;
  threadRepliesLoadPending: boolean;
  threadReplyFetchLimit: number;
  threadReplyLastLoadScrollOffset: number;
  threadProfiles: Map<string, ProfileRecord>;
  threadLoading: boolean;
  profilePersonalRoot: CID | null;
  threadPersonalRoot: CID | null;
};

export type RouteRenderCacheScope = {
  viewerPubkey: string | null;
  homeFeedSourcePubkey: string | null;
};

type BuildRestoredLiveRouteStateOptions = {
  cache: RouteRenderCache;
  currentFeed: FeedSnapshot | null;
  rootNhash: string;
  activeFeedSourcePubkey: string | null;
  activeAccountPubkey: string | null;
  reuseReferences?: boolean;
  preserveProfileNotesLoading?: boolean;
};

export function buildRestoredLiveRouteState(
  options: BuildRestoredLiveRouteStateOptions,
): RestoredLiveRouteState {
  const {
    cache,
    currentFeed,
    rootNhash,
    activeFeedSourcePubkey,
    activeAccountPubkey,
    reuseReferences = false,
    preserveProfileNotesLoading = false,
  } = options;

  return {
    // A route change invalidates the request token that owned these flags.
    // Restore the verified content, but never restore an abandoned spinner or
    // pagination lock. updateRoute starts a fresh hydration when the cached
    // entry reports unfinished work.
    loading: false,
    feedRequiresRefresh: cache.feedRequiresRefresh,
    noteEngagements: reuseReferences ? cache.noteEngagements : new Map(cache.noteEngagements),
    feed: cache.route.kind === 'home'
      ? reuseReferences && cache.feed
        ? { ...cache.feed, displayOrder: cache.homeNotes.map(event => event.id),
            notes: mergeUniqueFeedNotes(cache.homeNotes, cache.feed.notes) }
        : {
          ...(cache.feed ?? currentFeed ?? {
            rootNhash,
            followCount: 0,
            follows: [],
            feedOwnerPubkey: activeFeedSourcePubkey ?? activeAccountPubkey ?? '',
            notes: [],
            profiles: new Map<string, ProfileRecord>(),
            usedSuggestedFeed: false,
            starterMode: null,
          }),
          rootNhash: cache.feed?.rootNhash ?? currentFeed?.rootNhash ?? rootNhash,
          follows: [...(cache.feed?.follows ?? currentFeed?.follows ?? [])],
          profiles: new Map(cache.feed?.profiles ?? cache.profiles),
          notes: mergeUniqueFeedNotes(cache.homeNotes, cache.feed?.notes ?? []),
          displayOrder: cache.homeNotes.map(event => event.id),
          continuation: cloneHomeFeedContinuation(
            cache.feed?.continuation ?? currentFeed?.continuation,
          ),
          }
      : null,
    homeFeedLoadPending: false,
    feedLimit: cache.feedLimit,
    homeFeedFetchLimit: cache.homeFeedFetchLimit,
    homeFeedLastLoadScrollOffset: cache.homeFeedLastLoadScrollOffset,
    notifications: reuseReferences ? cache.notifications : [...cache.notifications],
    notificationsLoading: false,
    notificationsHasMore: cache.notificationsHasMore,
    notificationsLoadPending: false,
    profilePage: reuseReferences
      ? cache.profilePage
      : cache.profilePage
      ? {
          ...cache.profilePage,
          durableRootContinuations: cache.profilePage.durableRootContinuations?.map(
            (continuation) => ({
              ...continuation,
              cursor: continuation.cursor ? { ...continuation.cursor } : null,
            }),
          ),
          notes: [...cache.profilePage.notes],
          likedNotes: cache.profilePage.likedNotes?.map((item) => ({ ...item })),
        }
      : null,
    loadedProfilePubkey: cache.route.kind === 'profile' ? cache.route.pubkey : null,
    profileSocial: reuseReferences
      ? cache.profileSocial
      : cache.profileSocial
      ? {
          ...cache.profileSocial,
          follows: [...cache.profileSocial.follows],
          followers: [...cache.profileSocial.followers],
          profiles: new Map(cache.profileSocial.profiles),
        }
      : null,
    profileSocialLoading: false,
    profileSocialLoadPending: false,
    // A staged/interrupted profile explicitly preserves this bit until the
    // replacement loader reaches post-paint work. Other cached loading flags
    // belong to abandoned requests and must not be revived.
    profileNotesLoading: cache.route.kind === 'profile'
      && preserveProfileNotesLoading
      && cache.profileNotesLoading,
    profileFeedLoadPending: false,
    profileNoteLimit: cache.profileNoteLimit,
    profileNoteFetchLimit: cache.profileNoteFetchLimit,
    profileFeedLastLoadScrollOffset: cache.profileFeedLastLoadScrollOffset,
    profileSocialVisibleLimit: cache.profileSocialVisibleLimit,
    profileSocialFollowerFetchLimit: cache.profileSocialFollowerFetchLimit,
    threadPage: reuseReferences
      ? cache.threadPage
      : cache.threadPage
      ? {
          ...cache.threadPage,
          context: [...cache.threadPage.context],
        }
      : null,
    threadRoots: cache.route.kind === 'thread'
      ? (reuseReferences ? cache.threadRoots : [...cache.threadRoots])
      : [],
    threadReplyCursor: cache.route.kind === 'thread' && cache.threadReplyCursor
      ? (reuseReferences ? cache.threadReplyCursor : { ...cache.threadReplyCursor })
      : null,
    threadReplies: reuseReferences ? cache.threadReplies : [...cache.threadReplies],
    threadDurableRepliesHasMore: cache.threadDurableRepliesHasMore,
    threadRepliesHasMore: cache.threadRepliesHasMore,
    threadRepliesLoadPending: false,
    threadReplyFetchLimit: cache.threadReplyFetchLimit,
    threadReplyLastLoadScrollOffset: cache.threadReplyLastLoadScrollOffset,
    threadProfiles: cache.route.kind === 'thread'
      ? (reuseReferences ? cache.profiles : new Map(cache.profiles))
      : new Map<string, ProfileRecord>(),
    threadLoading: false,
    profilePersonalRoot: cache.route.kind === 'profile' ? cache.profilePersonalRoot : null,
    threadPersonalRoot: cache.route.kind === 'thread' ? cache.threadPersonalRoot : null,
  };
}

/**
 * A cold home-feed paint may contain only the viewer while their signed
 * contact list is still resolving. Once that authoritative follow set is
 * available, do not treat the provisional snapshot as a reusable route.
 */
export function homeFeedNeedsViewerFollowRefresh(options: {
  route: Route;
  feed: FeedSnapshot | null;
  viewerPubkey: string | null;
  viewerFollows: ReadonlySet<string>;
  activeFeedSourcePubkey: string | null;
}): boolean {
  const {
    route,
    feed,
    viewerPubkey,
    viewerFollows,
    activeFeedSourcePubkey,
  } = options;
  if (
    route.kind !== 'home'
    || !viewerPubkey
    || !feed
  ) {
    return false;
  }

  // Private membership invalidation is owned by the Favorites controller.
  if (route.tab === 'favorites') { return feed.feedOwnerPubkey !== 'favorites'; }

  const expectedFeedOwner = route.tab === 'for-you' ? 'for-you' : activeFeedSourcePubkey ?? viewerPubkey;
  if (feed.feedOwnerPubkey !== expectedFeedOwner) {
    // A viewer with no follows intentionally renders the suggested starter
    // feed under its fallback owner's identity. That is a complete snapshot,
    // not evidence that this route cache belongs to another viewer.
    return !(
      !activeFeedSourcePubkey
      && viewerFollows.size === 0
      && feed.usedSuggestedFeed
    );
  }

  if ((route.tab !== 'for-you' && activeFeedSourcePubkey) || viewerFollows.size === 0) {
    return false;
  }

  if (feed.follows.length !== viewerFollows.size) {
    return true;
  }

  const snapshotFollows = new Set(feed.follows);
  return [...viewerFollows].some((pubkey) => !snapshotFollows.has(pubkey));
}

/**
 * Restore verified cached content immediately, but only skip hydration when it
 * was complete and still belongs to the active durable root.
 */
export function shouldReuseExactRouteStackView(options: {
  routeExistsInStack: boolean;
  cache: RouteRenderCache | null;
  route: Route;
  viewerPubkey: string | null;
  viewerFollows: ReadonlySet<string>;
  activeFeedSourcePubkey: string | null;
  currentRootNhash: string;
}): boolean {
  const {
    routeExistsInStack,
    cache,
    route,
    viewerPubkey,
    viewerFollows,
    activeFeedSourcePubkey,
    currentRootNhash,
  } = options;
  return Boolean(
    routeExistsInStack
    && cache
    && routeRenderCacheHasVisibleContent(cache)
    && cache.rootNhash === currentRootNhash
    && !routeRenderCacheHasUnfinishedWork(cache)
    && !homeFeedNeedsViewerFollowRefresh({
      route,
      feed: cache.feed,
      viewerPubkey,
      viewerFollows,
      activeFeedSourcePubkey,
    }),
  );
}

function routeRenderCacheHasUnfinishedWork(cache: RouteRenderCache): boolean {
  if (cache.loading) {
    return true;
  }
  switch (cache.route.kind) {
    case 'home':
      return cache.feedRequiresRefresh || cache.homeFeedLoadPending;
    case 'notifications':
      return cache.notificationsLoading || cache.notificationsLoadPending;
    case 'profile': {
      const contentSection = cache.route.section === 'posts'
        || cache.route.section === 'replies'
        || cache.route.section === 'media'
        || cache.route.section === 'likes';
      return contentSection
        ? cache.profileNotesLoading || cache.profileFeedLoadPending
        : cache.profileSocialLoading || cache.profileSocialLoadPending;
    }
    case 'thread':
      return cache.threadLoading || cache.threadRepliesLoadPending;
    default:
      return false;
  }
}

export function routeRenderCacheHasVisibleContent(cache: RouteRenderCache): boolean {
  return hasLiveRouteContent(cache.route, {
    feed: cache.feed,
    profilePage: cache.profilePage,
    threadPage: cache.threadPage,
    notificationsCount: cache.notifications.length,
    homeNoteCount: cache.homeNotes.length,
  });
}

/**
 * Durable profile/thread data is public, but their cached engagement flags are
 * viewer-relative. Never restore a data-bearing mounted card under another
 * account; Home additionally belongs to the selected feed source.
 */
export function routeRenderCacheMatchesScope(
  cache: RouteRenderCache,
  scope: RouteRenderCacheScope,
): boolean {
  switch (cache.route.kind) {
    case 'home':
      return cache.viewerPubkey === scope.viewerPubkey
        && cache.homeFeedSourcePubkey === scope.homeFeedSourcePubkey;
    case 'notifications':
    case 'profile':
    case 'thread':
      return cache.viewerPubkey === scope.viewerPubkey;
    default:
      return true;
  }
}

export function pruneRouteRenderCacheForScope(
  routeRenderCache: Map<string, RouteRenderCache>,
  scope: RouteRenderCacheScope,
): Map<string, RouteRenderCache> {
  let needsPrune = false;
  for (const cache of routeRenderCache.values()) {
    if (!routeRenderCacheMatchesScope(cache, scope)) {
      needsPrune = true;
      break;
    }
  }
  if (!needsPrune) {
    return routeRenderCache;
  }
  return new Map(
    [...routeRenderCache].filter(([, cache]) => routeRenderCacheMatchesScope(cache, scope)),
  );
}

export function findSiblingProfileCache(
  routeStack: RouteStackEntry[],
  routeRenderCache: Map<string, RouteRenderCache>,
  nextRoute: Route,
): RouteRenderCache | null {
  if (nextRoute.kind !== 'profile' || !nextRoute.pubkey) {
    return null;
  }

  for (let index = routeStack.length - 1; index >= 0; index -= 1) {
    const entry = routeStack[index];
    if (entry?.route.kind !== 'profile' || entry.route.pubkey !== nextRoute.pubkey) {
      continue;
    }

    const cached = routeRenderCache.get(entry.key);
    if (cached) {
      return cached;
    }
  }

  return null;
}
