import { AppKeys, type KnownAppKeysSnapshot, type NdrRuntime } from 'nostr-double-ratchet';
import type { VerifiedEvent } from 'nostr-tools/pure';

type RosterRuntime = Pick<NdrRuntime, 'applyTrustedAppKeysSnapshot'>;

/** Apply a completed server read to the runtime's registration authority, not just its session cache. */
export async function applyPrivateRatchetRoster(
  owner: string,
  events: readonly unknown[],
  runtime: RosterRuntime,
): Promise<void> {
  if (!/^[0-9a-f]{64}$/.test(owner)) { throw new Error('Invalid device-list owner.'); }
  const snapshots = new Map<string, KnownAppKeysSnapshot>();
  // Validate the entire response before changing state. A bad response is not
  // evidence that the account has no devices and may start a new empty roster.
  for (const raw of events) {
    // Drop library verification-cache symbols before checking signed bytes.
    const event = JSON.parse(JSON.stringify(raw)) as VerifiedEvent;
    if (!event || event.pubkey !== owner || event.kind !== 37368
      || !Number.isSafeInteger(event.created_at) || event.created_at < 0) {
      throw new Error('Invalid signed device list.');
    }
    snapshots.set(event.id, {
      ownerPubkey: owner,
      appKeys: AppKeys.fromEvent(event),
      createdAt: event.created_at,
    });
  }
  const ordered = [...snapshots.entries()].sort(([leftId, left], [rightId, right]) =>
    left.createdAt - right.createdAt || (leftId < rightId ? -1 : leftId > rightId ? 1 : 0));
  for (const [, snapshot] of ordered) {
    // The runtime handles stale snapshots and equal-time monotonic merges. It
    // also persists the effective roster before this application resolves.
    await runtime.applyTrustedAppKeysSnapshot(snapshot);
  }
}
