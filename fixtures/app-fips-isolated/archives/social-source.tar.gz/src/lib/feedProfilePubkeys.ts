import { isHexPubkey, type RawEvent } from './nostr';
import { getVerifiedEmbeddedRepostTarget } from './repostPresentation';

export function getFeedProfilePubkeys(
  viewerPubkey: string,
  feedOwnerPubkey: string,
  notes: RawEvent[],
): string[] {
  const notePubkeys = notes.flatMap((event) => [
    event.pubkey,
    getVerifiedEmbeddedRepostTarget(event)?.pubkey ?? '',
  ]);

  return [...new Set([
    viewerPubkey,
    feedOwnerPubkey,
    ...notePubkeys,
  ].filter((pubkey) => isHexPubkey(pubkey)))];
}
