import { nhashEncode, type CID } from '@hashtree/core';
import {
  SOURCE_PRIORITY_LOCAL_INDEX,
  localIndexSource,
  type NostrEventReader,
  type NostrVerifiedEvent,
  type NostrFilter,
  type QueryOptions,
  type QueryReport,
  type RoutedQueryReport,
} from 'nostr-pubsub';
import { IrisEventReadRouter, type IrisEventReadScope, type IrisEventRootSnapshot } from './eventReadRouter';
import {
  FOR_YOU_RELAY_COUNT_LIMIT,
  FOR_YOU_RELAY_ENGAGEMENT_KINDS,
  FOR_YOU_RELAY_ENGAGEMENT_MODE,
  FOR_YOU_RELAY_EVENT_LIMIT,
  FOR_YOU_RELAY_LOOKBACK_SECONDS,
  FOR_YOU_RELAY_RESPONSE_GRACE_MS,
  FOR_YOU_RELAY_TARGET_LIMIT,
  FOR_YOU_RELAY_WINDOW_MS,
} from './forYouRelayEngagement';
import {
  createPersonalEventIndexReadStore,
  isLocalPersonalEventIndexRoot,
} from './personalEventIndexBrowser';
import { settingsStore } from './settings';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { isHexEventId } from './nostr';
import { getInteractionTargetId } from './noteEngagement';
import { socialDataPlane } from './socialDataPlane';
import { createSocialDataPlaneEventReader } from './socialDataPlaneEventReader';
import { createWorkerBlockStore } from './workerBlockStore';
import { serializeRoot } from './workerReadRoots';
import { createWorkerRelayEventReader, type VerifiedReadProgress } from './workerRelayEventReader';
import { MAX_SOCIAL_WORKER_HASHTREE_QUERY_EVENTS } from '../workers/socialWorkerHashtreeLimits';
import type { SocialWorkerHashtreeRoot } from '../workers/socialWorkerProtocol';

const MAX_RECENT_QUERY_ROOTS = 16;
/** Bound the lifetime of a background refresh, including relays that never finish history. */
const ROUTED_RELAY_WINDOW_MS = 3_000;

type StableRoots = {
  primary: CID | null;
  viewerPersonal: CID | null;
  routePersonal: CID | null;
};

// Repeated renders can ask for the same data while its network refresh is still open.
const REFRESH_COOLDOWN_MS = ROUTED_RELAY_WINDOW_MS;
function projectRelayEvents(events: readonly NostrVerifiedEvent[]): void {
  if (!isBrowserRelayContentEnabled()) { return; }
  const fresh = events.filter(event => !socialDataPlane.getStoredEvent(event.id));
  if (fresh.length) { socialDataPlane.ingestVerifiedRelayEvents(fresh, 'configured-relays'); }
}

function projectEngagements(events: readonly NostrVerifiedEvent[], targets: ReadonlySet<string>): void {
  projectRelayEvents(events.filter(event => {
    const target = getInteractionTargetId(event);
    return target !== null && targets.has(target);
  }));
}

class BrowserEventReadRouter {
  private readonly sharedStore = createWorkerBlockStore();
  private readonly personalStore = createPersonalEventIndexReadStore();
  private readonly liveOverlayReader: NostrEventReader;
  private readonly relayReader: ReturnType<typeof createWorkerRelayEventReader>;
  private readonly unifiedReader: ReturnType<typeof createWorkerRelayEventReader>;
  private readonly router: IrisEventReadRouter;
  private stable: StableRoots = { primary: null, viewerPersonal: null, routePersonal: null };
  private readonly recent = new Map<string, CID>();
  private routeScopeKey = '';
  private readonly refreshes = new Map<string, number>();
  /** The roots each archive read sends to the worker's Hashtree index source. */
  private workerRoots: SocialWorkerHashtreeRoot[] = [];

  constructor() {
    this.relayReader = createWorkerRelayEventReader({
      getRelays: getConfiguredNostrRelays,
    });
    const archive = {
      source: localIndexSource('iris-social-hashtree-indexes'),
      priority: SOURCE_PRIORITY_LOCAL_INDEX,
      maxLimit: MAX_SOCIAL_WORKER_HASHTREE_QUERY_EVENTS,
      getRoots: () => this.workerRoots,
    };
    this.unifiedReader = createWorkerRelayEventReader({
      getRelays: () => (isBrowserRelayContentEnabled() && navigator.onLine ? getConfiguredNostrRelays() : []), archive,
    });
    this.liveOverlayReader = createSocialDataPlaneEventReader(
      () => socialDataPlane.query({ includeDeletionEvents: true }),
      (eventId) => socialDataPlane.getStoredEvent(eventId),
      {
        verifyEvents: async (events, signal) => (
          await (await import('./workerClient')).getWorkerClient().then(
            (worker) => worker.verifyEvents([...events], signal),
          )
        ),
      },
    );
    const engagementReader = createWorkerRelayEventReader({
      getRelays: () => getConfiguredNostrRelays().slice(0, FOR_YOU_RELAY_COUNT_LIMIT),
      mode: FOR_YOU_RELAY_ENGAGEMENT_MODE,
    });
    this.router = new IrisEventReadRouter({
      store: this.sharedStore,
      liveOverlayReader: this.liveOverlayReader,
      relayContentReader: createWorkerRelayEventReader({
        getRelays: getConfiguredNostrRelays,
        maxWindowMs: ROUTED_RELAY_WINDOW_MS,
        onEvents: projectRelayEvents,
      }),
      relayContentEnabled: () => isBrowserRelayContentEnabled() && navigator.onLine,
      forYouRelayReader: {
        query(filters, options) {
          const targets = new Set(filters.flatMap(filter => filter['#e'] ?? []));
          return engagementReader.query(filters, { ...options, onEvents: events => {
            if (!options?.signal?.aborted) { projectEngagements(events, targets); }
          } });
        },
      },
      forYouRelayEnabled: () => settingsStore.getState().network.relayHomeFeedReads,
      maxConcurrentPartitions: 4,
      // The worker's nostr-pubsub runtime reads its cache and the Hashtree
      // index source, whose roots `applyRoots` keeps current.
      durableReaderFactory: () => createWorkerRelayEventReader({ getRelays: () => [], archive }),
    });
    this.applyRoots();
  }

  syncStableRoots(
    primary: CID | null,
    viewerPersonal: CID | null,
    routePersonal: CID | null,
    routeScopeKey: string,
  ): void {
    if (routeScopeKey !== this.routeScopeKey) {
      this.routeScopeKey = routeScopeKey;
      this.recent.clear();
    }
    this.stable = { primary, viewerPersonal, routePersonal };
    this.applyRoots();
  }

  async query(
    roots: CID | CID[],
    filters: NostrFilter[],
    options: QueryOptions = {},
    scope?: IrisEventReadScope,
  ): Promise<RoutedQueryReport> {
    this.rememberRoots(Array.isArray(roots) ? roots : [roots]);
    this.applyRoots();
    if (scope === undefined && isBrowserRelayContentEnabled() && navigator.onLine) {
      const now = Date.now();
      const key = JSON.stringify([getConfiguredNostrRelays(), filters, options.limit]);
      if ((this.refreshes.get(key) ?? 0) <= now) {
        for (const [previous, expires] of this.refreshes) {
          if (expires <= now) { this.refreshes.delete(previous); }
        }
        if (this.refreshes.size >= 256) { this.refreshes.delete(this.refreshes.keys().next().value!); }
        this.refreshes.set(key, now + REFRESH_COOLDOWN_MS);
        // A late relay event updates the projected view through the data plane.
        // The foreground read's completion describes the local and archive sources.
        void this.router.query(filters, options, 'relays').then(report => {
          projectRelayEvents(report.events.filter(candidate => candidate.provenance.some(({ source }) => source.kind === 'relay'))
            .map(candidate => candidate.event));
        }).catch(() => undefined);
      }
    }
    return this.router.query(filters, options, scope ?? 'archive');
  }

  async refreshForYouEngagements(noteIds: readonly string[], signal: AbortSignal): Promise<void> {
    const targets = [...new Set(noteIds.filter(isHexEventId))].slice(0, FOR_YOU_RELAY_TARGET_LIMIT);
    if (targets.length === 0 || !settingsStore.getState().network.relayHomeFeedReads) {return;}
    const targetIds = new Set(targets);
    const now = Date.now();
    const until = Math.floor(now / 1_000);
    // The worker's earlier network deadline lets its verified partial result
    // reach us before the outer response deadline cancels the request.
    const responseWindow = FOR_YOU_RELAY_WINDOW_MS + FOR_YOU_RELAY_RESPONSE_GRACE_MS;
    const requestSignal = AbortSignal.any([signal, AbortSignal.timeout(responseWindow)]);
    const report = await this.router.query([{
      kinds: [...FOR_YOU_RELAY_ENGAGEMENT_KINDS], '#e': targets,
      since: Math.max(0, until - FOR_YOU_RELAY_LOOKBACK_SECONDS), until, limit: FOR_YOU_RELAY_EVENT_LIMIT,
    }], {
      limit: FOR_YOU_RELAY_EVENT_LIMIT,
      deadline: now + responseWindow,
      signal: requestSignal,
    }, 'for-you-relays');
    requestSignal.throwIfAborted();
    if (!settingsStore.getState().network.relayHomeFeedReads) {return;}
    projectEngagements(report.events.map(({ event }) => event), targetIds);
  }

  queryRelays(filters: NostrFilter[], options: QueryOptions, onEvents?: VerifiedReadProgress): Promise<QueryReport> {
    return this.relayReader.query(filters, { ...options, onEvents });
  }

  /**
   * One worker query over the cache, Hashtree index and (when "Read from
   * relays" is on) the relays. It settles once enough sources answered, so a
   * slow archive or relay cannot hold the others' results.
   */
  queryAll(roots: CID[], filters: NostrFilter[], options: QueryOptions, onEvents?: VerifiedReadProgress): Promise<QueryReport> {
    this.rememberRoots(roots);
    this.applyRoots();
    return this.unifiedReader.query(filters, { ...options, onEvents });
  }

  queryArchiveRoot(root: CID | null, filters: NostrFilter[], options: QueryOptions, onEvents: VerifiedReadProgress) {
    const personal = root && isLocalPersonalEventIndexRoot(root);
    const roots = root ? workerRoot({
      root, partitionId: nhashEncode(root), store: personal ? this.personalStore : this.sharedStore,
    }, personal ? 'personal' : 'shared') : [];
    return createWorkerRelayEventReader({
      getRelays: () => [],
      archive: {
        getRoots: () => roots, source: localIndexSource('iris-social-hashtree-indexes'),
        priority: SOURCE_PRIORITY_LOCAL_INDEX, maxLimit: MAX_SOCIAL_WORKER_HASHTREE_QUERY_EVENTS,
      },
    }).query(filters, { ...options, onEvents });
  }

  private rememberRoots(roots: CID[]): void {
    for (const root of roots) {
      const identity = nhashEncode(root);
      this.recent.delete(identity);
      this.recent.set(identity, root);
    }
    while (this.recent.size > MAX_RECENT_QUERY_ROOTS) {
      const oldest = this.recent.keys().next().value as string | undefined;
      if (!oldest) {break;}
      this.recent.delete(oldest);
    }
  }

  private applyRoots(): void {
    const snapshot = this.rootSnapshot();
    this.router.replaceRoots(snapshot);
    this.workerRoots = [
      ...snapshot.shared.flatMap((entry) => workerRoot(entry, 'shared')),
      ...snapshot.personal.flatMap((entry) => workerRoot(entry, 'personal')),
    ];
  }

  private rootSnapshot(): IrisEventRootSnapshot {
    const shared: IrisEventRootSnapshot['shared'][number][] = [];
    const personal: IrisEventRootSnapshot['personal'][number][] = [];
    const seen = new Set<string>();
    const add = (partitionId: string, root: CID | null): void => {
      if (!root) {return;}
      const identity = nhashEncode(root);
      if (seen.has(identity)) {return;}
      seen.add(identity);
      const localPersonal = isLocalPersonalEventIndexRoot(root);
      (localPersonal ? personal : shared).push({
        partitionId,
        replicaId: identity,
        root,
        store: localPersonal ? this.personalStore : this.sharedStore,
      });
    };

    add('archive', this.stable.primary);
    add('viewer', this.stable.viewerPersonal);
    add('route', this.stable.routePersonal);
    for (const [identity, root] of this.recent) {
      add(`recent:${identity}`, root);
    }
    return { shared, personal };
  }
}

/** Ordinary reads include the configured relays unless "Read from relays" is off. */
/** One malformed saved root must not stop every other root from being read. */
function workerRoot(
  entry: IrisEventRootSnapshot['shared'][number],
  storeKind: 'shared' | 'personal',
): SocialWorkerHashtreeRoot[] {
  try {
    return [serializeRoot({ ...entry, partitionId: `${storeKind}:${entry.partitionId}` }, storeKind)];
  } catch (error) {
    console.warn('Skipping an unreadable Hashtree root', error);
    return [];
  }
}

export function isBrowserRelayContentEnabled(
  relayReads = settingsStore.getState().network.relayHomeFeedReads,
): boolean {
  return relayReads === true;
}

let browserRouter: BrowserEventReadRouter | null = null;

function getBrowserRouter(): BrowserEventReadRouter {
  browserRouter ??= new BrowserEventReadRouter();
  return browserRouter;
}

/** Keep the one adapter's bounded primary/viewer/active-route partitions current. */
export function syncBrowserEventReadRoots(
  primary: CID | null,
  viewerPersonal: CID | null,
  routePersonal: CID | null,
  routeScopeKey: string,
): void {
  getBrowserRouter().syncStableRoots(primary, viewerPersonal, routePersonal, routeScopeKey);
}

/** Query current and freshly discovered roots through the one application router. */
export async function queryBrowserEvents(
  roots: CID | CID[],
  filters: NostrFilter[],
  options: QueryOptions = {},
  scope?: IrisEventReadScope,
): Promise<RoutedQueryReport> {
  return await getBrowserRouter().query(roots, filters, options, scope);
}

export async function refreshBrowserForYouEngagements(noteIds: readonly string[], signal: AbortSignal): Promise<void> {
  await getBrowserRouter().refreshForYouEngagements(noteIds, signal);
}

/** One read of the cache, Hashtree index and relays, settled early (see `queryAll`). */
export function queryBrowserAllEvents(
  roots: CID[],
  filters: NostrFilter[],
  options: QueryOptions,
  onEvents?: VerifiedReadProgress,
): Promise<QueryReport> {
  return getBrowserRouter().queryAll(roots, filters, options, onEvents);
}

/** Replay verified local and indexed events without opening a relay read. */
export function queryBrowserArchiveRoot(
  root: CID | null, filters: NostrFilter[], options: QueryOptions, onEvents: VerifiedReadProgress,
): Promise<QueryReport> {
  return getBrowserRouter().queryArchiveRoot(root, filters, options, onEvents);
}

/** Bounded reads from the worker's verified relay and offline event store. */
export function queryBrowserRelayEvents(
  filters: NostrFilter[],
  options: QueryOptions,
  onEvents?: VerifiedReadProgress,
): Promise<QueryReport> {
  return getBrowserRouter().queryRelays(filters, options, onEvents);
}
