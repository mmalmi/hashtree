import { nhashEncode, type CID } from '@hashtree/core';
import {
  type NostrEventReader,
  type NostrFilter,
  type QueryOptions,
  type QueryReport,
  type RoutedQueryReport,
} from 'nostr-pubsub';
import { IrisEventReadRouter, type IrisEventRootSnapshot } from './eventReadRouter';
import {
  createPersonalEventIndexReadStore,
  isLocalPersonalEventIndexRoot,
} from './personalEventIndexBrowser';
import { settingsStore } from './settings';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { profileMapFromMetadataEvents } from './profileRecords';
import type { ProfileRecord } from './nostr';
import { socialDataPlane } from './socialDataPlane';
import { createSocialDataPlaneEventReader } from './socialDataPlaneEventReader';
import { createWorkerBlockStore } from './workerBlockStore';
import { createWorkerHashtreeEventReader } from './workerHashtreeEventReader';
import { createWorkerRelayEventReader } from './workerRelayEventReader';

const MAX_RECENT_QUERY_ROOTS = 16;

type StableRoots = {
  primary: CID | null;
  viewerPersonal: CID | null;
  routePersonal: CID | null;
};

class BrowserEventReadRouter {
  private readonly sharedStore = createWorkerBlockStore();
  private readonly personalStore = createPersonalEventIndexReadStore();
  private readonly liveOverlayReader: NostrEventReader;
  private readonly relayReader: NostrEventReader;
  private readonly router: IrisEventReadRouter;
  private stable: StableRoots = { primary: null, viewerPersonal: null, routePersonal: null };
  private readonly recent = new Map<string, CID>();
  private routeScopeKey = '';

  constructor() {
    this.relayReader = createWorkerRelayEventReader({
      getRelays: getConfiguredNostrRelays,
    });
    this.liveOverlayReader = createSocialDataPlaneEventReader(
      () => socialDataPlane.query({ includeDeletionEvents: true }),
      (eventId) => socialDataPlane.getStoredEvent(eventId),
      {
        verifyEvents: async (events, signal) => (
          await (await import('./workerClient')).getWorkerClient().then(
            (worker) => worker.verifyEvents([...events], signal),
          )
        ),
      },
    );
    this.router = new IrisEventReadRouter({
      store: this.sharedStore,
      liveOverlayReader: this.liveOverlayReader,
      relayContentReader: this.relayReader,
      relayContentEnabled: () => isBrowserRelayContentEnabled(),
      maxConcurrentPartitions: 4,
      durableReaderFactory: (roots) => createWorkerHashtreeEventReader({
        roots,
        storeKindForRoot: (entry) => (
          entry.store === this.personalStore ? 'personal' : 'shared'
        ),
      }),
    });
    this.applyRoots();
  }

  syncStableRoots(
    primary: CID | null,
    viewerPersonal: CID | null,
    routePersonal: CID | null,
    routeScopeKey: string,
  ): void {
    if (routeScopeKey !== this.routeScopeKey) {
      this.routeScopeKey = routeScopeKey;
      this.recent.clear();
    }
    this.stable = { primary, viewerPersonal, routePersonal };
    this.applyRoots();
  }

  async query(
    roots: CID | CID[],
    filters: NostrFilter[],
    options: QueryOptions = {},
  ): Promise<RoutedQueryReport> {
    for (const root of Array.isArray(roots) ? roots : [roots]) {
      const identity = nhashEncode(root);
      this.recent.delete(identity);
      this.recent.set(identity, root);
    }
    while (this.recent.size > MAX_RECENT_QUERY_ROOTS) {
      const oldest = this.recent.keys().next().value as string | undefined;
      if (!oldest) {break;}
      this.recent.delete(oldest);
    }
    this.applyRoots();
    const report = await this.router.query(filters, options);
    const relayEvents = report.events.flatMap((candidate) => (
      candidate.provenance.some(({ source }) => source.kind === 'relay')
        ? [candidate.event]
        : []
    ));
    if (relayEvents.length > 0) {
      socialDataPlane.ingestVerifiedRelayEvents(relayEvents, 'configured-relays');
    }
    return report;
  }

  async queryLiveTail(
    filters: NostrFilter[],
    options: QueryOptions = {},
  ): Promise<QueryReport> {
    const overlayPromise = this.liveOverlayReader.query(filters, options);
    if (!isBrowserRelayContentEnabled()) {
      return await overlayPromise;
    }
    const [overlay, relay] = await Promise.all([
      overlayPromise,
      this.relayReader.query(filters, options),
    ]);
    const relayEvents = relay.events.map(({ event }) => event);
    if (relayEvents.length > 0) {
      socialDataPlane.ingestVerifiedRelayEvents(relayEvents, 'configured-relays');
    }
    const byId = new Map([
      ...overlay.events,
      ...relay.events,
    ].map((candidate) => [candidate.event.id, candidate] as const));
    return {
      events: [...byId.values()].sort((left, right) => (
        right.event.created_at - left.event.created_at
          || left.event.id.localeCompare(right.event.id)
      )),
      complete: overlay.complete !== false && relay.complete !== false,
    };
  }

  async refreshProfiles(pubkeys: string[], signal: AbortSignal) {
    if (!settingsStore.getState().network.refreshProfiles) {
      return { profiles: new Map<string, ProfileRecord>(), complete: false };
    }
    // One filter per author avoids a prolific author's metadata starving others.
    const authors = [...new Set(pubkeys)].filter(pubkey => /^[0-9a-f]{64}$/.test(pubkey)).slice(0, 16);
    const report = await this.relayReader.query(authors.map(pubkey => ({
      kinds: [0], authors: [pubkey], limit: 1,
    })), { limit: 256, deadline: Date.now() + 6_000, signal });
    signal.throwIfAborted();
    const events = report.events.map(({ event }) => event);
    socialDataPlane.ingestVerifiedRelayEvents(events, 'configured-relays');
    return { profiles: profileMapFromMetadataEvents(events), complete: report.complete !== false };
  }

  private applyRoots(): void {
    this.router.replaceRoots(this.rootSnapshot());
  }

  private rootSnapshot(): IrisEventRootSnapshot {
    const shared: IrisEventRootSnapshot['shared'][number][] = [];
    const personal: IrisEventRootSnapshot['personal'][number][] = [];
    const seen = new Set<string>();
    const add = (partitionId: string, root: CID | null): void => {
      if (!root) {return;}
      const identity = nhashEncode(root);
      if (seen.has(identity)) {return;}
      seen.add(identity);
      const localPersonal = isLocalPersonalEventIndexRoot(root);
      (localPersonal ? personal : shared).push({
        partitionId,
        replicaId: identity,
        root,
        store: localPersonal ? this.personalStore : this.sharedStore,
      });
    };

    add('archive', this.stable.primary);
    add('viewer', this.stable.viewerPersonal);
    add('route', this.stable.routePersonal);
    for (const [identity, root] of this.recent) {
      add(`recent:${identity}`, root);
    }
    return { shared, personal };
  }
}

export function isBrowserRelayContentEnabled(
  relayContentReads = settingsStore.getState().network.relayContentReads,
): boolean {
  return relayContentReads === true;
}

let browserRouter: BrowserEventReadRouter | null = null;

function getBrowserRouter(): BrowserEventReadRouter {
  browserRouter ??= new BrowserEventReadRouter();
  return browserRouter;
}

/** Keep the one adapter's bounded primary/viewer/active-route partitions current. */
export function syncBrowserEventReadRoots(
  primary: CID | null,
  viewerPersonal: CID | null,
  routePersonal: CID | null,
  routeScopeKey: string,
): void {
  getBrowserRouter().syncStableRoots(primary, viewerPersonal, routePersonal, routeScopeKey);
}

/** Query current and freshly discovered roots through the one application router. */
export async function queryBrowserEvents(
  roots: CID | CID[],
  filters: NostrFilter[],
  options: QueryOptions = {},
): Promise<RoutedQueryReport> {
  return await getBrowserRouter().query(roots, filters, options);
}

/** Query only the persisted live overlay and configured relay tail. */
export async function queryBrowserLiveTailEvents(
  filters: NostrFilter[],
  options: QueryOptions = {},
): Promise<QueryReport> {
  return await getBrowserRouter().queryLiveTail(filters, options);
}

/** Bounded metadata revalidation through the same verified worker and durable overlay. */
export async function refreshBrowserProfiles(pubkeys: string[], signal: AbortSignal) {
  return await getBrowserRouter().refreshProfiles(pubkeys, signal);
}
