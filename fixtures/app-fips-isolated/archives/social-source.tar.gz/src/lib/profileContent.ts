import type { RawEvent } from './nostr';
import { extractNoteEmbeds } from './noteContent';
import { isNip10ReplyTag } from './nostrReplyTags';

/** Content kinds Iris can render in an authored profile feed. */
export const PROFILE_CONTENT_KINDS = [1, 6, 20, 1_111, 30_023] as const;

export type ProfileContentClass = 'post' | 'reply';
export type ProfileContentSection = 'posts' | 'replies' | 'media';

const PROFILE_CONTENT_KIND_SET = new Set<number>(PROFILE_CONTENT_KINDS);

/**
 * Classify an event already obtained from an author-scoped profile query.
 *
 * NIP-10 reply tags apply only to kind 1. A `q` tag or an explicitly cited
 * `e` tag is not a reply, so quote posts stay in Posts. Repost wrappers and
 * kinds 20/30023 are root content; replies to non-kind-1 roots use NIP-22
 * kind 1111 comments.
 */
export function classifyProfileContentEvent(event: RawEvent): ProfileContentClass | null {
  if (!PROFILE_CONTENT_KIND_SET.has(event.kind)) {
    return null;
  }

  if (event.kind === 1_111) {
    return 'reply';
  }

  if (event.kind === 1 && event.tags.some(isNip10ReplyTag)) {
    return 'reply';
  }

  return 'post';
}

export function isProfileRootPost(event: RawEvent): boolean {
  return classifyProfileContentEvent(event) === 'post';
}

export function isProfileReply(event: RawEvent): boolean {
  return classifyProfileContentEvent(event) === 'reply';
}

/** Require an embed the existing note renderer actually understands. */
export function hasSupportedProfileMedia(event: RawEvent): boolean {
  return classifyProfileContentEvent(event) !== null
    && extractNoteEmbeds(event.content, event.tags, event.kind).length > 0;
}

/** Preserve source ordering while selecting a profile content section. */
export function filterProfileContentEvents(
  events: Iterable<RawEvent>,
  section: ProfileContentSection,
): RawEvent[] {
  const result: RawEvent[] = [];
  for (const event of events) {
    const contentClass = classifyProfileContentEvent(event);
    if (
      (section === 'posts' && contentClass === 'post')
      || (section === 'replies' && contentClass === 'reply')
      || (section === 'media' && contentClass !== null && hasSupportedProfileMedia(event))
    ) {
      result.push(event);
    }
  }
  return result;
}
