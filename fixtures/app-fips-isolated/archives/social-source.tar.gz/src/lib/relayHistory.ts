import { filtersMatch, type NostrFilter, type NostrVerifiedEvent } from 'nostr-pubsub';
import { generateRequestId } from '@hashtree/core';
import { isBrowserRelayContentEnabled } from './browserEventReadRouter';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { isStrictlyBeforeRecentCursor, type RecentTextNoteCursor } from './recentTextNoteCursor';
import { socialDataPlane } from './socialDataPlane';
import { admitTrustedRelayWorkerEvents } from './workerRelayEventReader';
import type { SocialWorkerClient } from './workerClient';

const DEFAULT_PAGE_WINDOW_MS = 4_000;

export type RelayHistoryPage = {
  /** Newest first. A later page never holds an event newer than these. */
  events: NostrVerifiedEvent[];
  hasMore: boolean;
  /** False when relays were skipped, offline, or stopped early. */
  complete: boolean;
};

export type RelayHistoryReader = {
  next(limit: number, signal?: AbortSignal): Promise<RelayHistoryPage>;
  close(): void;
};

type RelayHistoryDeps = {
  getClient?: () => Promise<Pick<SocialWorkerClient, 'historyPage' | 'closeHistory'>>;
  getRelays?: () => string[];
  enabled?: () => boolean;
  publish?: (events: NostrVerifiedEvent[]) => void;
  windowMs?: number;
};

const defaultPublish = (events: NostrVerifiedEvent[]): void => {
  const fresh = events.filter(event => !socialDataPlane.getStoredEvent(event.id));
  if (fresh.length) { socialDataPlane.ingestVerifiedRelayEvents(fresh, 'configured-relays'); }
};

/**
 * Paged relay history for one view, backed by the worker's per-relay
 * nostr-pubsub `HistoryCursor`s. Each `next` continues where the last one
 * ended. If the worker lost the session, it resumes from the oldest event
 * this reader returned.
 */
export function createRelayHistoryReader(
  filter: NostrFilter,
  deps: RelayHistoryDeps = {},
  /** Resume below this saved position, for example after a reload. */
  resumeBefore?: RecentTextNoteCursor | null,
): RelayHistoryReader {
  const sessionId = `history:${generateRequestId()}`;
  const getClient = deps.getClient ?? (async () => (await import('./workerClient')).getWorkerClient());
  const getRelays = deps.getRelays ?? (() => getConfiguredNostrRelays());
  const enabled = deps.enabled ?? (() => isBrowserRelayContentEnabled() && navigator.onLine);
  const publish = deps.publish ?? defaultPublish;
  const returned = new Set<string>();
  let oldest: number | undefined = resumeBefore?.createdAt;
  /** A page that arrived after its caller gave up; the next call returns it first. */
  let carried: NostrVerifiedEvent[] = [];
  let running: Promise<unknown> = Promise.resolve();
  let lastHasMore = true;
  let lastComplete = true;
  let opened = false;
  let closed = false;
  let exhausted = false;

  async function readNext(limit: number, signal?: AbortSignal): Promise<RelayHistoryPage> {
    signal?.throwIfAborted();
    if (carried.length) {
      const events = carried.slice(0, Math.max(limit, 0));
      carried = carried.slice(events.length);
      return { events, hasMore: carried.length > 0 || lastHasMore, complete: lastComplete };
    }
    const relays = [...new Set(getRelays())];
    if (closed || exhausted) {
      return { events: [], hasMore: false, complete: exhausted };
    }
    if (limit <= 0) {
      return { events: [], hasMore: true, complete: true };
    }
    if (relays.length === 0 || !enabled()) {
      // Relay reads are off or offline: nothing more here, but not proven absent.
      return { events: [], hasMore: false, complete: false };
    }
    const client = await getClient();
    signal?.throwIfAborted();
    opened = true;
    // The worker releases a page once; finish it even if the caller aborts,
    // and keep it for the next call instead of leaving a gap.
    const result = await client.historyPage(sessionId, relays, {
      ...filter,
      ...(oldest !== undefined && { until: oldest }),
    }, { limit, deadline: Date.now() + (deps.windowMs ?? DEFAULT_PAGE_WINDOW_MS) });
    if (result.events.some(event => !filtersMatch([filter], event))) {
      throw new Error('Relay history returned an event outside the requested filter');
    }
    const admitted = (await admitTrustedRelayWorkerEvents(result.events))
      .filter(event => !returned.has(event.id)
        && isStrictlyBeforeRecentCursor(event.created_at, event.id, resumeBefore ?? undefined)
        && socialDataPlane.isExternalEventVisible(event));
    for (const event of admitted) {
      returned.add(event.id);
      oldest = oldest === undefined ? event.created_at : Math.min(oldest, event.created_at);
    }
    if (admitted.length) { publish(admitted); }
    exhausted = !result.hasMore;
    lastHasMore = result.hasMore;
    lastComplete = result.complete;
    if (signal?.aborted) {
      carried = admitted;
      signal.throwIfAborted();
    }
    return { events: admitted, hasMore: result.hasMore, complete: result.complete };
  }

  return {
    next(limit, signal) {
      // Pages are sequential: each continues the previous one.
      const result = running.then(() => readNext(limit, signal));
      running = result.catch(() => undefined);
      return result;
    },
    close() {
      if (closed) { return; }
      closed = true;
      if (opened) { void getClient().then(client => client.closeHistory(sessionId)).catch(() => undefined); }
    },
  };
}

export type RelayHistoryCursorPage = {
  events: NostrVerifiedEvent[];
  /** The last event returned, or the caller's cursor when none was. */
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
};

type CursorReader = Pick<RelayHistoryReader, 'next' | 'close'>;

function sameCursor(left: RecentTextNoteCursor | null, right: RecentTextNoteCursor | null): boolean {
  return left?.createdAt === right?.createdAt && left?.eventId === right?.eventId;
}

/**
 * Cursor-addressed relay pages for one view at a time (a profile, a viewer's
 * notifications). A page continues the current history session when the
 * caller's cursor is where the last page ended. Any other key or cursor, such
 * as a restored snapshot, starts a session that resumes below that cursor.
 */
export function createRelayHistoryPages(
  filterFor: (key: string) => NostrFilter,
  createReader: (filter: NostrFilter, before: RecentTextNoteCursor | null) => CursorReader = (filter, before) => (
    createRelayHistoryReader(filter, {}, before)
  ),
) {
  let current: { key: string; reader: CursorReader; cursor: RecentTextNoteCursor | null } | null = null;
  return {
    async load(
      key: string,
      limit: number,
      before: RecentTextNoteCursor | null,
      signal?: AbortSignal,
    ): Promise<RelayHistoryCursorPage> {
      if (!current || current.key !== key || !sameCursor(current.cursor, before)) {
        current?.reader.close();
        current = { key, reader: createReader(filterFor(key), before), cursor: before };
      }
      const session = current;
      const page = await session.reader.next(limit, signal);
      const last = page.events.at(-1);
      if (last) { session.cursor = { createdAt: last.created_at, eventId: last.id }; }
      return { events: page.events, cursor: session.cursor, hasMore: page.hasMore };
    },
    close(): void {
      current?.reader.close();
      current = null;
    },
  };
}
