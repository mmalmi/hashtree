export function advanceSearchResultLimit(
  currentLimit: number,
  availableResults: number,
  pageSize: number,
): number {
  return Math.min(availableResults, currentLimit + pageSize);
}

/**
 * Keep already-shown search results in place while additional sources stream in
 * for the same query, appending newly discovered items in ranked order below.
 */
export function stabilizeSearchOrder<T>(
  ranked: readonly T[],
  pinnedKeys: readonly string[],
  getKey: (item: T) => string,
): T[] {
  if (pinnedKeys.length === 0 || ranked.length <= 1) { return [...ranked]; }
  const byKey = new Map(ranked.map((item) => [getKey(item), item]));
  const placed = new Set<string>();
  const pinned: T[] = [];
  for (const key of pinnedKeys) {
    const item = byKey.get(key);
    if (item && !placed.has(key)) {
      placed.add(key);
      pinned.push(item);
    }
  }
  return [...pinned, ...ranked.filter((item) => !placed.has(getKey(item)))];
}

/**
 * Preserve already-painted AI search rows in place (including rows later demoted
 * by inference, while still removing muted/hidden items) until the user chooses
 * to refresh the ranking.
 */
export function stabilizePinnedResults<T>(
  ranked: readonly T[],
  pinnedItems: readonly T[],
  getKey: (item: T) => string,
  keepPinned: (item: T) => boolean = () => true,
): T[] {
  if (pinnedItems.length === 0) { return [...ranked]; }
  const byKey = new Map(ranked.map((item) => [getKey(item), item]));
  const placed = new Set<string>();
  const pinned: T[] = [];
  for (const item of pinnedItems) {
    const key = getKey(item);
    if (placed.has(key) || !keepPinned(item)) { continue; }
    placed.add(key);
    pinned.push(byKey.get(key) ?? item);
  }
  return [...pinned, ...ranked.filter((item) => !placed.has(getKey(item)))];
}

export function hasBetterTopResults<T>(
  ranked: readonly T[],
  pinned: readonly T[],
  getKey: (item: T) => string,
  topCount = 5,
): boolean {
  const checkCount = Math.min(topCount, Math.max(ranked.length, pinned.length));
  for (let index = 0; index < checkCount; index += 1) {
    if (!ranked[index] || !pinned[index] || getKey(ranked[index]!) !== getKey(pinned[index]!)) {
      return true;
    }
  }
  return false;
}
