export function advanceSearchResultLimit(
  currentLimit: number,
  availableResults: number,
  pageSize: number,
): number {
  return Math.min(availableResults, currentLimit + pageSize);
}
