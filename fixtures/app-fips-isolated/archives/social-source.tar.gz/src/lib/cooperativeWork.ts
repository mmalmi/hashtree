export type CooperativeWorkBudgetOptions = {
  maxWorkMs?: number;
  now?: () => number;
  yieldControl?: () => Promise<void>;
};

const DEFAULT_MAX_WORK_MS = 8;

/**
 * Bounds a run of synchronous work reached through already-settled promises.
 * Cached reads otherwise form one microtask train which can starve paint and input.
 */
export class CooperativeWorkBudget {
  private readonly maxWorkMs: number;
  private readonly now: () => number;
  private readonly yieldControl: () => Promise<void>;
  private usedWorkMs = 0;
  private pendingYield: Promise<void> | null = null;

  constructor(options: CooperativeWorkBudgetOptions = {}) {
    this.maxWorkMs = options.maxWorkMs ?? DEFAULT_MAX_WORK_MS;
    if (!Number.isFinite(this.maxWorkMs) || this.maxWorkMs <= 0) {
      throw new RangeError('Cooperative work budget must be positive and finite');
    }
    this.now = options.now ?? (() => performance.now());
    this.yieldControl = options.yieldControl ?? (() => new Promise<void>((resolve) => {
      setTimeout(resolve, 0);
    }));
  }

  async run<T>(work: () => T): Promise<T> {
    await this.yieldIfNeeded();
    const startedAt = this.now();
    try {
      return work();
    } finally {
      this.usedWorkMs += Math.max(0, this.now() - startedAt);
    }
  }

  private async yieldIfNeeded(): Promise<void> {
    if (this.pendingYield) {
      await this.pendingYield;
      return;
    }
    if (this.usedWorkMs < this.maxWorkMs) {
      return;
    }

    const pending = this.yieldControl().finally(() => {
      this.usedWorkMs = 0;
      if (this.pendingYield === pending) {
        this.pendingYield = null;
      }
    });
    this.pendingYield = pending;
    await pending;
  }
}
