import {
  FEED_PAGE_SIZE,
  INITIAL_FEED_LIMIT,
  INITIAL_MEDIA_FEED_LIMIT,
  INITIAL_PROFILE_NOTE_LIMIT,
  THREAD_REPLY_PAGE_SIZE,
} from './config';
import { getThreadParentReference, type RawEvent } from './nostr';
import { createOptimisticThreadSnapshot } from './appThreadLoader';
import {
  buildRestoredLiveRouteState,
  pruneRouteRenderCacheForScope,
} from './appRouteState';
import type { AppCombinedState } from './appState';
import type { RouteRenderCache } from './appStack';
import {
  createHomeFeedPaginationState,
  createProfileFeedPaginationState,
  createProfileSocialPaginationState,
  createThreadReplyPaginationState,
} from './appUiState';
import type { createThreadReplyDraftStore } from './threadReplyDrafts';
import {
  loadAccountSheetModule,
  loadSearchPageModule,
} from './lazyRouteComponents';
import { rememberProfileRecords } from './profileCache';

const PROFILE_SOCIAL_PAGE_SIZE = 40;

type ScrollTracker = {
  get: () => number;
  set: (offset: number) => void;
};

type ViewStateControllerDeps = {
  state: AppCombinedState;
  homeFeedScroll: ScrollTracker;
  profileFeedScroll: ScrollTracker;
  threadReplyScroll: ScrollTracker;
  threadReplyDrafts: ReturnType<typeof createThreadReplyDraftStore>;
  getActiveAccountPubkey: () => string | null;
  getActiveFeedSourcePubkey: () => string | null;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  closeDetailSheet: () => void;
  closeMedia: () => void;
};

export function createAppViewStateController(deps: ViewStateControllerDeps) {
  const { state } = deps;
  let restoredDraftOwner: string | null | undefined;

  function restoreAccountDrafts(pubkey: string | null): void {
    if (restoredDraftOwner === pubkey) { return; }
    restoredDraftOwner = pubkey;
    deps.threadReplyDrafts.setOwner(pubkey);
    const homeDraft = deps.threadReplyDrafts.read('home');
    state.composerValue = homeDraft?.value ?? '';
    state.composerAttachments = homeDraft?.attachments ?? [];
    state.composerError = '';
    restoreThreadReplyDraft();
  }

  function getInitialHomeFeedLimit(): number {
    return state.route.kind === 'home' && (
      state.route.tab === 'media'
      || (
        (state.route.tab === 'latest' || state.route.tab === 'for-you' || state.route.tab === 'favorites')
        && state.feedView === 'media-grid'
      )
    ) ? INITIAL_MEDIA_FEED_LIMIT : INITIAL_FEED_LIMIT;
  }

  function resetHomeFeedPagination(): void {
    const next = createHomeFeedPaginationState(getInitialHomeFeedLimit(), FEED_PAGE_SIZE);
    state.feedLimit = next.feedLimit;
    state.homeFeedFetchLimit = next.homeFeedFetchLimit;
    state.homeFeedLoadPending = next.homeFeedLoadPending;
    state.homeFeedInitialLoadGeneration += 1;
    state.homeFeedInitialLoadPending = false;
    deps.homeFeedScroll.set(next.homeFeedScrollOffset);
    state.homeFeedLastLoadScrollOffset = next.homeFeedLastLoadScrollOffset;
  }

  function resetProfileFeedPagination(): void {
    const limit = state.route.kind === 'profile' && state.route.section === 'media'
      ? INITIAL_MEDIA_FEED_LIMIT
      : INITIAL_PROFILE_NOTE_LIMIT;
    const next = createProfileFeedPaginationState(limit, FEED_PAGE_SIZE);
    state.profileNoteLimit = next.profileNoteLimit;
    state.profileNoteFetchLimit = next.profileNoteFetchLimit;
    state.profileFeedLoadPending = next.profileFeedLoadPending;
    deps.profileFeedScroll.set(next.profileFeedScrollOffset);
    state.profileFeedLastLoadScrollOffset = next.profileFeedLastLoadScrollOffset;
  }

  function resetProfileSocialPagination(): void {
    const next = createProfileSocialPaginationState(PROFILE_SOCIAL_PAGE_SIZE);
    state.profileSocialLoadPending = next.profileSocialLoadPending;
    state.profileSocialVisibleLimit = next.profileSocialVisibleLimit;
    state.profileSocialFollowerFetchLimit = next.profileSocialFollowerFetchLimit;
    state.profileSocialScrollOffset = next.profileSocialScrollOffset;
    state.profileSocialLastLoadScrollOffset = next.profileSocialLastLoadScrollOffset;
  }

  function resetThreadReplyPagination(): void {
    const next = createThreadReplyPaginationState(THREAD_REPLY_PAGE_SIZE);
    state.threadReplyFetchLimit = next.threadReplyFetchLimit;
    state.threadRepliesLoadPending = next.threadRepliesLoadPending;
    deps.threadReplyScroll.set(next.threadReplyScrollOffset);
    state.threadReplyLastLoadScrollOffset = next.threadReplyLastLoadScrollOffset;
  }

  function clearProfileViewState(): void {
    state.profilePage = null;
    state.profileSocial = null;
    state.profilePersonalRoot = null;
    state.profileNotesLoading = false;
    resetProfileFeedPagination();
    resetProfileSocialPagination();
  }

  function activeThreadReplyDraftKey(): string | null {
    return state.route.kind === 'thread' ? `thread:${state.route.ref}` : null;
  }

  function persistActiveThreadReplyDraft(): void {
    const key = activeThreadReplyDraftKey();
    if (key) {
      deps.threadReplyDrafts.write(key, {
        value: state.threadReplyValue,
        attachments: state.threadReplyAttachments,
        error: state.threadReplyError,
      });
    }
  }

  function restoreThreadReplyDraft(): void {
    const key = activeThreadReplyDraftKey();
    const draft = key ? deps.threadReplyDrafts.read(key) : null;
    state.threadReplyValue = draft?.value ?? '';
    state.threadReplyAttachments = draft?.attachments ?? [];
    state.threadReplyError = draft?.error ?? '';
  }

  function clearThreadReplyDraft(): void {
    const key = activeThreadReplyDraftKey();
    if (key) {
      deps.threadReplyDrafts.delete(key);
    }
    state.threadReplyValue = '';
    state.threadReplyAttachments = [];
    state.threadReplyError = '';
  }

  function clearThreadViewState(): void {
    state.threadPage = null;
    state.threadRoots = [];
    state.threadReplyCursor = null;
    state.threadReplies = [];
    state.threadPersonalRoot = null;
    state.threadProfiles = new Map();
    state.threadLoading = false;
    resetThreadReplyPagination();
  }

  function clearNotificationsState(): void {
    state.notifications = [];
    state.visibleNotifications = [];
    state.notificationsProfiles = new Map();
    state.notificationsLoading = false;
    state.notificationsLoadPending = false;
    state.notificationsHasMore = false;
    state.notificationCursor = null;
  }

  function clearRootBoundState(): void {
    state.feed = null;
    state.noteEngagements = new Map();
    clearProfileViewState();
    clearThreadViewState();
    clearNotificationsState();
  }

  function resetActiveAccountUiState(nextViewerPubkey = deps.getActiveAccountPubkey()): void {
    const currentStackEntry = state.routeStack[state.routeStackIndex] ?? null;
    state.routeRenderCache = pruneRouteRenderCacheForScope(state.routeRenderCache, {
      viewerPubkey: nextViewerPubkey,
      homeFeedSourcePubkey: deps.getActiveFeedSourcePubkey(),
    });
    const retainedKeys = new Set(state.routeRenderCache.keys());
    state.routeStack = state.routeStack.filter((entry) => (
      retainedKeys.has(entry.key) || entry.key === currentStackEntry?.key
    ));
    state.routeStackIndex = Math.max(
      0,
      currentStackEntry
        ? state.routeStack.findIndex((entry) => entry.key === currentStackEntry.key)
        : state.routeStack.length - 1,
    );
    state.mountedRenderEntries = state.mountedRenderEntries.filter((entry) => (
      retainedKeys.has(entry.key)
    ));
    state.activeRenderEntry = state.mountedRenderEntries.find((entry) => (
      entry.key === currentStackEntry?.key
    )) ?? null;
    clearRootBoundState();
    state.viewerContactsEvent = null;
    state.viewerContactsProjectionAuthoritative = false;
    state.viewerFollows = new Set();
    state.accountInput = '';
    state.accountImportError = '';
    restoreAccountDrafts(nextViewerPubkey);
    state.optimisticNoteEngagements = new Map();
    state.likePendingNoteIds = new Set();
    state.indexedViewerMuteListEvent = null;
    state.mutePendingPubkeys = new Set();
    state.hydratedViewerProfileEvent = null;
    state.viewerProfileLoading = false;
    state.profileSavePending = false;
    state.profileSaveError = '';
    state.profileSaveMessage = '';
    state.homeRefreshPending = false;
    resetHomeFeedPagination();
  }

  function restoreLiveRouteState(
    cache: RouteRenderCache,
    options: {
      reuseReferences?: boolean;
      preserveProfileNotesLoading?: boolean;
    } = {},
  ): void {
    const next = buildRestoredLiveRouteState({
      cache,
      currentFeed: state.feed,
      rootNhash: state.rootNhash,
      activeFeedSourcePubkey: deps.getActiveFeedSourcePubkey(),
      activeAccountPubkey: deps.getActiveAccountPubkey(),
      reuseReferences: options.reuseReferences,
      preserveProfileNotesLoading: options.preserveProfileNotesLoading,
    });
    rememberProfileRecords([
      next.profilePage?.profile,
      ...(next.feed?.profiles.values() ?? []),
      ...(next.profileSocial?.profiles.values() ?? []),
      ...next.threadProfiles.values(),
    ]);
    state.loading = next.loading;
    state.noteEngagements = next.noteEngagements;
    state.feed = next.feed;
    state.feedRequiresRefresh = next.feedRequiresRefresh;
    state.homeFeedLoadPending = next.homeFeedLoadPending;
    state.feedLimit = next.feedLimit;
    state.homeFeedFetchLimit = next.homeFeedFetchLimit;
    state.homeFeedLastLoadScrollOffset = next.homeFeedLastLoadScrollOffset;
    state.notifications = next.notifications;
    state.notificationsLoading = next.notificationsLoading;
    state.notificationsHasMore = next.notificationsHasMore;
    state.notificationsLoadPending = next.notificationsLoadPending;
    state.profilePage = next.profilePage;
    state.loadedProfilePubkey = next.loadedProfilePubkey;
    state.profileSocial = next.profileSocial;
    state.profileSocialLoading = next.profileSocialLoading;
    state.profileSocialLoadPending = next.profileSocialLoadPending;
    state.profileNotesLoading = next.profileNotesLoading;
    state.profileFeedLoadPending = next.profileFeedLoadPending;
    state.profileNoteLimit = next.profileNoteLimit;
    state.profileNoteFetchLimit = next.profileNoteFetchLimit;
    state.profileFeedLastLoadScrollOffset = next.profileFeedLastLoadScrollOffset;
    state.profileSocialVisibleLimit = next.profileSocialVisibleLimit;
    state.profileSocialFollowerFetchLimit = next.profileSocialFollowerFetchLimit;
    state.threadPage = next.threadPage;
    state.threadRoots = next.threadRoots;
    state.threadReplyCursor = next.threadReplyCursor;
    state.threadReplies = next.threadReplies;
    state.durableThreadRepliesHasMore = next.threadDurableRepliesHasMore;
    state.threadRepliesLoadPending = next.threadRepliesLoadPending;
    state.threadReplyFetchLimit = next.threadReplyFetchLimit;
    state.threadReplyLastLoadScrollOffset = next.threadReplyLastLoadScrollOffset;
    state.threadProfiles = next.threadProfiles;
    state.threadLoading = next.threadLoading;
    state.profilePersonalRoot = next.profilePersonalRoot;
    state.threadPersonalRoot = next.threadPersonalRoot;
  }

  async function loadAccountSheet(): Promise<void> {
    if (state.accountSheetComponent) {
      return;
    }
    state.accountSheetLoadError = '';
    try {
      state.accountSheetComponent = (await loadAccountSheetModule()).default;
    } catch (error) {
      state.accountSheetLoadError = "Couldn't load accounts.";
      console.warn('Failed to load account manager', error);
    }
  }

  async function loadSearchPage(): Promise<void> {
    if (state.searchPageComponent) {
      return;
    }
    state.searchPageLoadError = '';
    try {
      state.searchPageComponent = (await loadSearchPageModule()).default;
    } catch (error) {
      state.searchPageLoadError = "Couldn't load search.";
      console.warn('Failed to load search', error);
    }
  }

  function applyPendingNavigationState(): void {
    deps.closeDetailSheet();
    deps.closeMedia();
  }

  function primeThreadPreview(target: string): void {
    if (!state.root) {
      return;
    }
    const knownNote = deps.getKnownNoteByRef(target);
    if (!knownNote) {
      return;
    }
    const parentRef = getThreadParentReference(knownNote);
    const knownParent = parentRef ? deps.getKnownNoteByRef(parentRef) : null;
    state.threadPage = createOptimisticThreadSnapshot(state.root, knownNote, knownParent);
    state.threadReplies = [];
    resetThreadReplyPagination();
    state.threadLoading = true;
    state.loading = false;
  }

  return {
    activeThreadReplyDraftKey,
    applyPendingNavigationState,
    clearNotificationsState,
    clearProfileViewState,
    clearRootBoundState,
    clearThreadReplyDraft,
    clearThreadViewState,
    loadAccountSheet,
    loadSearchPage,
    persistActiveThreadReplyDraft,
    primeThreadPreview,
    resetActiveAccountUiState,
    resetHomeFeedPagination,
    resetProfileFeedPagination,
    resetProfileSocialPagination,
    resetThreadReplyPagination,
    restoreLiveRouteState,
    restoreAccountDrafts,
    restoreThreadReplyDraft,
  };
}
