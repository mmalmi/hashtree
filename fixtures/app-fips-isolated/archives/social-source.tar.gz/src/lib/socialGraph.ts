import { loadStaticSocialGraph } from './socialGraphSeed';
export { parseStaticSocialGraphSnapshot } from './socialGraphSeed';
import { beginPublicDiscoveryUpdate, publicDiscoveryRelays, type PublicDiscoveryUpdate } from './publicDiscoveryUpdate';
import type { SocialGraph, NostrEvent as SocialGraphEvent } from 'nostr-social-graph';
import type { SocialAccount } from './accounts';
import { settingsStore, DEFAULT_NOSTR_RELAYS } from './settings';
import { isHexPubkey, type ProfileRecord, type RawEvent } from './nostr';
import {
  SOCIAL_GRAPH_ROOT,
  SOCIAL_GRAPH_SNAPSHOT_URL,
} from './socialGraphSnapshot.generated';
import {
  profileSocialFromGraph,
  type SocialGraphProfileSocial,
} from './socialGraphProfileQuery';
import { queueWorkerSocialGraphEvent } from './socialGraphWorkerObservation';

export { profileSocialFromGraph };
export type { SocialGraphProfileSocial };

export const DEFAULT_SOCIAL_GRAPH_ROOT = SOCIAL_GRAPH_ROOT;
const UNKNOWN_FOLLOW_DISTANCE = 1000;
const SOCIAL_GRAPH_DB_NAME = 'iris-social:social-graph';
const SOCIAL_GRAPH_DB_VERSION = 1;
const SOCIAL_GRAPH_STORE = 'snapshots';
const SOCIAL_GRAPH_SNAPSHOT_KEY = 'default';
const SOCIAL_GRAPH_SAVE_DELAY_MS = 15_000;
const SOCIAL_GRAPH_RECALCULATE_BATCH_SIZE = 5_000;
const SOCIAL_GRAPH_KIND_CONTACTS = 3, SOCIAL_GRAPH_KIND_MUTES = 10000;
const SOCIAL_GRAPH_KINDS = new Set([SOCIAL_GRAPH_KIND_CONTACTS, SOCIAL_GRAPH_KIND_MUTES]);

type StoredSocialGraphSnapshot = {
  key: string;
  root: string;
  sourceKey: string | null;
  syncedAt: number;
  bytes: ArrayBuffer | Uint8Array;
};

type SocialGraphMetrics = {
  socialDistance: number | null;
  followedByFriends: number | null;
};

export type SocialGraphEventStreamFactory = () => AsyncIterable<RawEvent>;

let socialGraphInstance: SocialGraph | null = null;
let socialGraphPromise: Promise<SocialGraph> | null = null;
let socialGraphSaveTimer: ReturnType<typeof setTimeout> | null = null;
let socialGraphSyncPromise: Promise<void> | null = null;
let socialGraphPersistenceAllowed = true;
let firstSave = false;
let untouchedFallback = false;
let publicUpdate: PublicDiscoveryUpdate | undefined;
let stopBootstrapSettings: (() => void) | undefined;
let lastSyncedSourceKey: string | null = null;
let lastSyncedAt = 0;
let requestedSocialGraphRoot = DEFAULT_SOCIAL_GRAPH_ROOT;
let stableSocialGraphRoot: string | null = null;
let socialGraphRootRequestVersion = 0;
let socialGraphRootActivationPromise: Promise<void> | null = null;
const listeners = new Set<() => void>();

const loadSocialGraphModule = () => import('nostr-social-graph');

function isSocialGraphEvent(event: RawEvent | null | undefined): event is RawEvent {
  return Boolean(event && SOCIAL_GRAPH_KINDS.has(event.kind));
}

function canUseIndexedDb(): boolean {
  return typeof indexedDB !== 'undefined';
}

function openSocialGraphDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(SOCIAL_GRAPH_DB_NAME, SOCIAL_GRAPH_DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(SOCIAL_GRAPH_STORE)) {
        db.createObjectStore(SOCIAL_GRAPH_STORE, { keyPath: 'key' });
      }
    };
    request.onerror = () => reject(request.error ?? new Error('Failed to open social graph IndexedDB'));
    request.onsuccess = () => resolve(request.result);
  });
}

function idbRequest<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed'));
    request.onsuccess = () => resolve(request.result);
  });
}

function closeDb(db: IDBDatabase): void {
  try {
    db.close();
  } catch {
    // Ignore IndexedDB close failures.
  }
}

async function readStoredSnapshot(): Promise<StoredSocialGraphSnapshot | null> {
  if (!canUseIndexedDb()) {
    return null;
  }

  const db = await openSocialGraphDb();
  try {
    const transaction = db.transaction(SOCIAL_GRAPH_STORE, 'readonly');
    const store = transaction.objectStore(SOCIAL_GRAPH_STORE);
    const record = await idbRequest<StoredSocialGraphSnapshot | undefined>(
      store.get(SOCIAL_GRAPH_SNAPSHOT_KEY),
    );
    if (!record) {
      return null;
    }
    return record;
  } finally {
    closeDb(db);
  }
}

async function writeStoredSnapshotBytes(bytes: Uint8Array): Promise<void> {
  if (!canUseIndexedDb() || !socialGraphPersistenceAllowed) {
    return;
  }

  const db = await openSocialGraphDb();
  try {
    const transaction = db.transaction(SOCIAL_GRAPH_STORE, 'readwrite');
    const store = transaction.objectStore(SOCIAL_GRAPH_STORE);
    if (firstSave) {
      const existing = await idbRequest(store.get(SOCIAL_GRAPH_SNAPSHOT_KEY));
      // An earlier transaction in this tab may have completed while this one waited.
      if (firstSave && existing !== undefined) {
        socialGraphPersistenceAllowed = false;
        return;
      }
    }
    await idbRequest(store.put({
      key: SOCIAL_GRAPH_SNAPSHOT_KEY,
      root: DEFAULT_SOCIAL_GRAPH_ROOT,
      sourceKey: lastSyncedSourceKey,
      syncedAt: lastSyncedAt,
      bytes,
    } satisfies StoredSocialGraphSnapshot));
    firstSave = false;
  } finally {
    closeDb(db);
  }
}

function hasStableSocialGraphRoot(graph: SocialGraph): boolean {
  return graph === socialGraphInstance
    && stableSocialGraphRoot !== null
    && stableSocialGraphRoot === requestedSocialGraphRoot
    && graph.getRoot() === stableSocialGraphRoot;
}

async function writeStoredSnapshot(graph: SocialGraph): Promise<void> {
  // Full v4 exports preserve every retained component and its revision metadata,
  // including a personal crawl while its viewer root is active.
  if (publicUpdate || untouchedFallback || !hasStableSocialGraphRoot(graph)) {return;}
  const requestVersion = socialGraphRootRequestVersion;
  const bytes = await graph.toBinary();
  if (requestVersion !== socialGraphRootRequestVersion || !hasStableSocialGraphRoot(graph)) {return;}
  await writeStoredSnapshotBytes(bytes);
}

function snapshotBytes(record: StoredSocialGraphSnapshot): Uint8Array | null {
  if (record.bytes instanceof Uint8Array) {
    return record.bytes;
  }
  if (record.bytes instanceof ArrayBuffer) {
    return new Uint8Array(record.bytes);
  }
  return null;
}

async function createLocalSocialGraph(): Promise<SocialGraph> {
  const { SocialGraph } = await loadSocialGraphModule();
  let maySeed = true;
  const stored = await readStoredSnapshot().catch((error) => {
    maySeed = false;
    console.warn('Failed to read local social graph snapshot', error);
    return null;
  });
  if (stored) { maySeed = false; }
  const bytes = stored ? snapshotBytes(stored) : null;

  if (bytes && bytes.byteLength <= 16 * 1024 * 1024) {
    try {
      const graph = await SocialGraph.fromBinary(DEFAULT_SOCIAL_GRAPH_ROOT, bytes);
      // A small personal crawl is valid; bootstrap size is not a freshness test.
      if (graph.size().users > 0) {
        lastSyncedSourceKey = stored?.sourceKey ?? null;
        lastSyncedAt = typeof stored?.syncedAt === 'number' ? stored.syncedAt : 0;
        return graph;
      }
    } catch (error) {
      console.warn('Failed to load local social graph snapshot', error);
    }
  }

  // An unsupported/corrupt retained crawl is not an absent cache. An in-memory
  // fallback must not later overwrite it through the ordinary save timer.
  socialGraphPersistenceAllowed = maySeed;
  firstSave = maySeed;
  untouchedFallback = true;

  // A fresh projection can seed a new graph, but must never replace a retained crawl.
  const network = settingsStore.getState().network;
  if (maySeed && network.publicGraphSnapshot && publicDiscoveryRelays(network.relays, DEFAULT_NOSTR_RELAYS)) {
    const update = beginPublicDiscoveryUpdate(DEFAULT_SOCIAL_GRAPH_ROOT);
    publicUpdate = update;
    stopBootstrapSettings = settingsStore.subscribe(({network}) => {
      if (!network.publicGraphSnapshot || !publicDiscoveryRelays(network.relays, DEFAULT_NOSTR_RELAYS)) {update.cancel();}
    });
  }

  const staticSnapshot = typeof window !== 'undefined' ? await loadStaticSocialGraph() : null;
  if (staticSnapshot) {
    lastSyncedSourceKey = SOCIAL_GRAPH_SNAPSHOT_URL;
    lastSyncedAt = Date.now();
    return staticSnapshot.graph;
  }

  return new SocialGraph(DEFAULT_SOCIAL_GRAPH_ROOT);
}

async function finishPublicBootstrap(update: PublicDiscoveryUpdate, embedded: SocialGraph): Promise<void> {
  try {
    const fresh = await update.ready;
    if (fresh && !update.signal.aborted && socialGraphInstance === embedded) {
      await fresh.setRoot(requestedSocialGraphRoot);
      while (socialGraphRootActivationPromise) {
        await socialGraphRootActivationPromise;
      }
      update.replay(event => fresh.handleEvent(event as SocialGraphEvent, true));
      socialGraphInstance = fresh;
      untouchedFallback = false;
      lastSyncedSourceKey = 'htree://npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/social-graph';
      lastSyncedAt = Date.now();
      stableSocialGraphRoot = null;
      await ensureSocialGraphRootActivation();
    }
  } finally {
    stopBootstrapSettings?.();
    stopBootstrapSettings = undefined;
    if (publicUpdate === update) {publicUpdate = undefined;}
    const selected = socialGraphInstance;
    if (selected) {await writeStoredSnapshot(selected);}
  }
}

async function loadLocalSocialGraph(): Promise<SocialGraph> {
  if (socialGraphInstance) {
    return socialGraphInstance;
  }

  if (!socialGraphPromise) {
    socialGraphPromise = createLocalSocialGraph()
      .then(async (graph) => {
        socialGraphInstance = graph;
        stableSocialGraphRoot = null;
        await ensureSocialGraphRootActivation();
        if (publicUpdate) {void finishPublicBootstrap(publicUpdate, graph).catch(error => {
          console.warn('Could not finish the public graph bootstrap', error);
        });}
        return graph;
      })
      .finally(() => {
        socialGraphPromise = null;
      });
  }

  return await socialGraphPromise;
}

function emitSocialGraphChange(graph: SocialGraph | null = socialGraphInstance): void {
  if (!graph || !hasStableSocialGraphRoot(graph)) {
    return;
  }

  for (const listener of listeners) {
    try {
      listener();
    } catch (error) {
      console.warn('Social graph listener failed', error);
    }
  }
}

function normalizeSocialGraphRoot(value: string | null | undefined): string {
  if (!value) {
    return DEFAULT_SOCIAL_GRAPH_ROOT;
  }
  return normalizePubkey(value) ?? DEFAULT_SOCIAL_GRAPH_ROOT;
}

function requestSocialGraphRoot(root: string): number {
  const normalizedRoot = normalizeSocialGraphRoot(root);
  if (normalizedRoot === requestedSocialGraphRoot) {
    return socialGraphRootRequestVersion;
  }

  requestedSocialGraphRoot = normalizedRoot;
  socialGraphRootRequestVersion += 1;
  stableSocialGraphRoot = null;
  return socialGraphRootRequestVersion;
}

function ensureSocialGraphRootActivation(): Promise<void> {
  const graph = socialGraphInstance;
  if (!graph || hasStableSocialGraphRoot(graph)) {
    return Promise.resolve();
  }
  if (socialGraphRootActivationPromise) {
    return socialGraphRootActivationPromise;
  }

  let activationFailed = false;
  socialGraphRootActivationPromise = (async () => {
    while (graph === socialGraphInstance) {
      const targetRoot = requestedSocialGraphRoot;
      stableSocialGraphRoot = null;
      if (graph.getRoot() !== targetRoot) {
        await graph.setRoot(targetRoot);
      }
      if (graph !== socialGraphInstance) {
        return;
      }
      if (targetRoot !== requestedSocialGraphRoot) {
        continue;
      }

      stableSocialGraphRoot = targetRoot;
      if (targetRoot === DEFAULT_SOCIAL_GRAPH_ROOT) {
        scheduleSocialGraphSave();
      }
      emitSocialGraphChange(graph);
      return;
    }
  })().catch((error) => {
    activationFailed = true;
    throw error;
  }).finally(() => {
    socialGraphRootActivationPromise = null;
    if (
      !activationFailed
      && graph === socialGraphInstance
      && !hasStableSocialGraphRoot(graph)
    ) {
      void ensureSocialGraphRootActivation().catch((error) => {
        console.warn('Failed to activate local social graph root', error);
      });
    }
  });

  return socialGraphRootActivationPromise;
}

export function resolveLocalSocialGraphRoot(
  account: SocialAccount | null,
  accountCount: number,
): string {
  const isLegacyPristineGeneratedDefault = account?.isPristineDefault === undefined
    && account?.method === 'generated'
    && accountCount === 1
    && account.updatedAt === account.createdAt;
  const isPristineGeneratedDefault = account?.isPristineDefault === true
    || isLegacyPristineGeneratedDefault;
  return account && !isPristineGeneratedDefault
    ? normalizeSocialGraphRoot(account.pubkey)
    : DEFAULT_SOCIAL_GRAPH_ROOT;
}

/** Record the viewer root without forcing the large shared graph to load early. */
export function configureLocalSocialGraphViewer(
  account: SocialAccount | null,
  accountCount: number,
): void {
  const previousVersion = socialGraphRootRequestVersion;
  requestSocialGraphRoot(resolveLocalSocialGraphRoot(account, accountCount));
  if (socialGraphInstance && previousVersion !== socialGraphRootRequestVersion) {
    void ensureSocialGraphRootActivation().catch((error) => {
      console.warn('Failed to activate viewer-rooted social graph', error);
    });
  }
}

/** Load if needed, then resolve only after this root wins or is superseded. */
export async function setLoadedLocalSocialGraphRoot(root: string): Promise<boolean> {
  const normalizedRoot = normalizeSocialGraphRoot(root);
  const requestVersion = requestSocialGraphRoot(normalizedRoot);
  await loadLocalSocialGraph();
  await ensureSocialGraphRootActivation();
  return requestVersion === socialGraphRootRequestVersion
    && requestedSocialGraphRoot === normalizedRoot
    && stableSocialGraphRoot === normalizedRoot
    && socialGraphInstance?.getRoot() === normalizedRoot;
}

export function getLoadedSocialGraphRoot(): string | null {
  return socialGraphInstance && hasStableSocialGraphRoot(socialGraphInstance)
    ? stableSocialGraphRoot
    : null;
}

/** Only the public kind-3 graph may authorize identified public-feed requests. */
export function getLoadedPublicFeedAuthors(): string[] {
  const root = getLoadedSocialGraphRoot();
  return root && socialGraphInstance
    ? [root, ...socialGraphInstance.getFollowedByUser(root)].filter(isHexPubkey)
    : [];
}

function scheduleSocialGraphSave(): void {
  if (socialGraphSaveTimer) {
    return;
  }

  socialGraphSaveTimer = setTimeout(() => {
    socialGraphSaveTimer = null;
    const graph = socialGraphInstance;
    if (!graph) {
      return;
    }

    void writeStoredSnapshot(graph).catch((error) => {
      console.warn('Failed to persist local social graph', error);
    });
  }, SOCIAL_GRAPH_SAVE_DELAY_MS);
}

function normalizePubkey(value: string): string | null {
  const normalized = value.trim().toLowerCase();
  return isHexPubkey(normalized) ? normalized : null;
}

function metricsFromGraph(graph: SocialGraph, pubkey: string): SocialGraphMetrics | null {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey) {
    return null;
  }

  const distance = graph.getFollowDistance(normalizedPubkey);
  const followedByFriends = graph.followedByFriendsCount(normalizedPubkey);
  if (distance >= UNKNOWN_FOLLOW_DISTANCE && followedByFriends === 0) {
    return null;
  }

  return {
    socialDistance: distance >= UNKNOWN_FOLLOW_DISTANCE ? null : distance,
    followedByFriends,
  };
}

function hasUsableLocalSocialGraph(): boolean {
  if (
    !socialGraphInstance
    || !hasStableSocialGraphRoot(socialGraphInstance)
    || lastSyncedAt <= 0
  ) {
    return false;
  }

  const size = socialGraphInstance.size();
  return size.follows > 0;
}

async function yieldToBrowser(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 0));
}

async function ingestSocialGraphEvents(events: AsyncIterable<RawEvent>): Promise<number> {
  await loadLocalSocialGraph();
  let count = 0;

  for await (const event of events) {
    if (!isSocialGraphEvent(event)) {
      continue;
    }

    publicUpdate?.observe(event);
    if (socialGraphInstance!.handleEvent(event as SocialGraphEvent, true)) {untouchedFallback = false;}
    count += 1;
    if (count % 500 === 0) {
      await yieldToBrowser();
    }
  }

  if (count > 0) {
    const graph = socialGraphInstance!;
    await graph.recalculateFollowDistances(
      SOCIAL_GRAPH_RECALCULATE_BATCH_SIZE,
      Number.MAX_SAFE_INTEGER,
      () => {},
    );
    scheduleSocialGraphSave();
    emitSocialGraphChange();
  }

  return count;
}

export function observeSocialGraphEvent(event: RawEvent | null | undefined): void {
  queueWorkerSocialGraphEvent(event);
}

export async function syncLocalSocialGraph(
  sourceKey: string,
  streamEvents: SocialGraphEventStreamFactory,
  options: { force?: boolean } = {},
): Promise<void> {
  if (!options.force && hasUsableLocalSocialGraph()) {
    return;
  }

  if (socialGraphSyncPromise) {
    return await socialGraphSyncPromise;
  }

  socialGraphSyncPromise = (async () => {
    if (!options.force) {
      await loadLocalSocialGraph();
      if (hasUsableLocalSocialGraph()) {
        return;
      }
    }

    await ingestSocialGraphEvents(streamEvents());
    lastSyncedSourceKey = sourceKey;
    lastSyncedAt = Date.now();
    const graph = await loadLocalSocialGraph();
    await writeStoredSnapshot(graph).catch((error) => {
      console.warn('Failed to persist synced local social graph', error);
    });
  })().finally(() => {
    socialGraphSyncPromise = null;
  });

  return await socialGraphSyncPromise;
}

export async function primeLocalSocialGraph(
  sourceKey: string,
  streamEvents: SocialGraphEventStreamFactory,
): Promise<void> {
  try {
    await syncLocalSocialGraph(sourceKey, streamEvents);
  } catch (error) {
    console.warn('Failed to sync local social graph from hashtree index', error);
  }
}

export async function loadSocialGraphProfileSocial(
  sourceKey: string,
  streamEvents: SocialGraphEventStreamFactory,
  pubkey: string,
  followerLimit: number,
): Promise<SocialGraphProfileSocial | null> {
  const graph = await loadLocalSocialGraph();
  const immediate = profileSocialFromGraph(graph, pubkey, followerLimit);
  const syncPromise = syncLocalSocialGraph(sourceKey, streamEvents).catch((error) => {
    console.warn('Failed to refresh local social graph', error);
  });

  if (immediate) {
    void syncPromise;
    return immediate;
  }

  await syncPromise;
  return profileSocialFromGraph(graph, pubkey, followerLimit);
}

export async function warmLocalSocialGraph(): Promise<void> {
  await loadLocalSocialGraph().catch(() => undefined);
}

export function getLoadedSocialGraphMetrics(pubkey: string): SocialGraphMetrics | null {
  return socialGraphInstance && hasStableSocialGraphRoot(socialGraphInstance)
    ? metricsFromGraph(socialGraphInstance, pubkey)
    : null;
}

export function getLoadedSocialGraphAuthorInfo(
  pubkey: string,
): { distance: number; followers: number } | null {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey || !socialGraphInstance || !hasStableSocialGraphRoot(socialGraphInstance)) {
    return null;
  }
  return {
    distance: socialGraphInstance.getFollowDistance(normalizedPubkey),
    followers: socialGraphInstance.followerCount(normalizedPubkey),
  };
}

export function getLoadedFollowedBy(pubkey: string, limit = 3): { pubkeys: string[]; total: number } | null {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey || !socialGraphInstance || !hasStableSocialGraphRoot(socialGraphInstance)) {return null;}
  const pubkeys = [...socialGraphInstance.followedByFriends(normalizedPubkey)].filter(isHexPubkey);
  return { pubkeys: pubkeys.slice(0, Number.isSafeInteger(limit) ? Math.max(0, Math.min(limit, 12)) : 3), total: pubkeys.length };
}

/** Whether the loaded graph shows `pubkey` following `viewer` (null when unknown). */
export function getLoadedFollowsViewer(pubkey: string, viewer: string | null | undefined): boolean | null {
  const normalizedPubkey = normalizePubkey(pubkey);
  const normalizedViewer = viewer ? normalizePubkey(viewer) : null;
  if (!normalizedPubkey || !normalizedViewer || !socialGraphInstance
    || !hasStableSocialGraphRoot(socialGraphInstance)) {return null;}
  return socialGraphInstance.isFollowing(normalizedPubkey, normalizedViewer);
}

export function applySocialGraphMetrics(profile: ProfileRecord | null | undefined): ProfileRecord | null {
  if (!profile) {
    return null;
  }

  // These fields were populated from whichever viewer rooted the renderer
  // graph. Keep the compatibility entry point, but never publish stale values.
  if ((profile.socialDistance ?? null) === null && (profile.followedByFriends ?? null) === null) {
    return profile;
  }

  return {
    ...profile,
    socialDistance: null,
    followedByFriends: null,
  };
}

export function applySocialGraphMetricsToProfileMap(profiles: Map<string, ProfileRecord>): Map<string, ProfileRecord> {
  if (profiles.size === 0) {
    return profiles;
  }

  let changed = false;
  const nextProfiles = new Map<string, ProfileRecord>();
  for (const [pubkey, profile] of profiles) {
    const nextProfile = applySocialGraphMetrics(profile) ?? profile;
    nextProfiles.set(pubkey, nextProfile);
    changed ||= nextProfile !== profile;
  }

  return changed ? nextProfiles : profiles;
}

export function subscribeLocalSocialGraphChanges(listener: () => void): () => void {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

/** Optional relay catch-up for callers that explicitly enable public networking.
 * The existing local/Hashtree graph remains authoritative and is never replaced.
 * Stop this handle on account/network configuration changes.
 */
export async function startLocalSocialGraphCatchup(relays: string[]): Promise<() => void> {
  await loadLocalSocialGraph();
  const { startGraphSync } = await import('nostr-social-graph/publicGraphSync');
  return startGraphSync({
    getGraph: () => socialGraphInstance!,
    relays: relays.length === DEFAULT_NOSTR_RELAYS.length && relays.every(url => DEFAULT_NOSTR_RELAYS.includes(url))
      ? ['wss://graph-relay.iris.to', ...relays] : relays,
    maxAuthors: 500, maxBytes: 2 * 1024 * 1024,
    onEvent: event => {
      untouchedFallback = false;
      publicUpdate?.observe(event);
      // An in-flight reconciliation may still hold the embedded graph.
      socialGraphInstance?.handleEvent(event as SocialGraphEvent, true);
      queueWorkerSocialGraphEvent(event);
    },
    onChange: () => { emitSocialGraphChange(); scheduleSocialGraphSave(); },
    onError: (error) => console.warn('Public graph catch-up unavailable', error),
  });
}
