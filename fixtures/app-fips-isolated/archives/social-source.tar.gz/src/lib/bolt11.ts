const BECH32_CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const BECH32_GENERATORS = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];

function hasValidBech32Checksum(value: string): boolean {
  if (value !== value.toLowerCase() && value !== value.toUpperCase()) {return false;}
  const normalized = value.toLowerCase();
  const separatorIndex = normalized.lastIndexOf('1');
  if (separatorIndex <= 0 || normalized.length - separatorIndex - 1 < 6) {return false;}
  const data = [...normalized.slice(separatorIndex + 1)]
    .map((character) => BECH32_CHARSET.indexOf(character));
  if (data.some((part) => part < 0)) {return false;}
  const prefix = [...normalized.slice(0, separatorIndex)];
  const values = [
    ...prefix.map((character) => character.charCodeAt(0) >> 5),
    0,
    ...prefix.map((character) => character.charCodeAt(0) & 31),
    ...data,
  ];
  let checksum = 1;
  for (const part of values) {
    const top = checksum >>> 25;
    checksum = ((checksum & 0x1ff_ffff) << 5) ^ part;
    for (let bit = 0; bit < BECH32_GENERATORS.length; bit += 1) {
      if ((top >>> bit) & 1) {checksum ^= BECH32_GENERATORS[bit]!;}
    }
  }
  return checksum === 1;
}

export function parseBolt11Millisats(invoice: string): number | null {
  const normalized = invoice.trim().toLowerCase();
  if (normalized.length < 50 || !/^ln(?:bc|tb|bcrt|sb)/.test(normalized) || !hasValidBech32Checksum(invoice.trim())) {
    return null;
  }
  const separatorIndex = normalized.lastIndexOf('1');
  const match = normalized.slice(0, separatorIndex).match(/^ln(?:bc|tb|bcrt|sb)(\d+)([munp]?)$/);
  if (!match) {return null;}
  const amount = Number(match[1]);
  if (!Number.isSafeInteger(amount) || amount <= 0) {return null;}
  let millisats: number;
  switch (match[2]) {
    case 'm': millisats = amount * 100_000_000; break;
    case 'u': millisats = amount * 100_000; break;
    case 'n': millisats = amount * 100; break;
    case 'p': millisats = amount % 10 === 0 ? amount / 10 : 0; break;
    default: millisats = amount * 100_000_000_000;
  }
  return Number.isSafeInteger(millisats) && millisats > 0 ? millisats : null;
}

/** Extract the signed invoice's payment hash after checking its encoded amount/checksum. */
export function parseBolt11PaymentHash(invoice: string): string | null {
  if (parseBolt11Millisats(invoice) === null) {return null;}
  const normalized = invoice.trim().toLowerCase();
  const words = [...normalized.slice(normalized.lastIndexOf('1') + 1, -6)]
    .map((character) => BECH32_CHARSET.indexOf(character));
  const end = words.length - 104; // The recoverable signature occupies 520 bits.
  let paymentHash: string | null = null;
  for (let cursor = 7; cursor < end;) {
    const tag = words[cursor++];
    const length = words[cursor++]! * 32 + words[cursor++]!;
    if (!Number.isSafeInteger(length) || cursor + length > end) {return null;}
    if (tag === BECH32_CHARSET.indexOf('p') && length === 52) {
      if (paymentHash !== null) {return null;}
      let buffer = 0;
      let bits = 0;
      const bytes: number[] = [];
      for (const word of words.slice(cursor, cursor + length)) {
        buffer = (buffer << 5) | word;
        bits += 5;
        if (bits >= 8) {bits -= 8; bytes.push((buffer >> bits) & 255);}
      }
      if (bytes.length !== 32 || (buffer & ((1 << bits) - 1)) !== 0) {return null;}
      paymentHash = bytes.map((byte) => byte.toString(16).padStart(2, '0')).join('');
    }
    cursor += length;
  }
  return paymentHash;
}
