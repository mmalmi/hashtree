import type { CID, Store } from '@hashtree/core';
import { CooperativeWorkBudget } from './cooperativeWork';
import {
  MAX_INDEXED_EVENT_VERIFICATION_BATCH,
  verifyIndexedEvents,
} from './fastEventVerification';
import {
  normalizePubkey,
  parseProfileEvent,
  type RawEvent,
} from './nostr';
import {
  normalizeProfileSearchText,
  projectProfileSearchIdentity,
} from './profileSearchIdentity';
import {
  throwIfProfileSearchAborted,
  withProfileSearchAbort,
} from './profileSearchAbort';
import { profileSearchRank } from './profileSearchRanking';
import { readClientRunEnvelope } from './profileSearchV3ClientManifest';
import {
  boundedPrefix,
  boundedStringBytes,
  boundedTerm,
  compareHits,
  compareMode,
  compareText,
  exactKeys,
  mapConcurrent,
  modeCode,
  nonNegativeInteger,
  normalizeTags,
  objectValue,
  parsePostingKey,
  queryTrigrams,
  searchWords,
  strictHex,
  strictPubkey,
  uniqueRoutes,
} from './profileSearchV3ClientPrimitives';
import { openPageRouter } from './profileSearchV3ClientRouter';
import {
  MAX_PROFILE_CONTENT_BYTES,
  MAX_QUERY_CANDIDATES,
  MAX_QUERY_TRIGRAMS,
  SEPARATOR,
  type ProfileSearchV3ClientHit,
  type ProfileSearchV3ClientOpenRun,
  type ProfileSearchV3ClientPageRouter,
  type ProfileSearchV3ClientPostingMode,
  type ProfileSearchV3ClientRunDescriptor,
  type ProfileSearchV3ClientStoredProfile,
} from './profileSearchV3ClientTypes';

export type ProfileSearchV3ClientRunDependencies = {
  verifyEvents?: (
    events: RawEvent[],
    signal?: AbortSignal,
  ) => Promise<boolean[]>;
  createWorkBudget?: () => CooperativeWorkBudget;
};

export type ProfileSearchV3ClientStoredProfileInput = {
  expectedPubkey: string;
  raw: string;
};

type DecodedStoredProfile = {
  event: RawEvent;
  rankHint: number;
};

type VerifyStoredProfileOptions = ProfileSearchV3ClientRunDependencies & {
  signal?: AbortSignal | null;
  workBudget?: CooperativeWorkBudget;
};

export async function openClientRun(
  store: Store,
  root: CID,
  expected: ProfileSearchV3ClientRunDescriptor,
  signal: AbortSignal | null,
  dependencies: ProfileSearchV3ClientRunDependencies = {},
): Promise<ProfileSearchV3ClientOpenRun> {
  const envelope = await readClientRunEnvelope(store, root, expected, signal);
  const [profiles, postings] = await Promise.all([
    openPageRouter(store, envelope.profileRoot, envelope.manifest.branches.profiles, signal),
    openPageRouter(store, envelope.postingRoot, envelope.manifest.branches.postings, signal),
  ]);
  return {
    manifest: envelope.manifest,
    getProfile: async (value, lookupSignal) => {
      const pubkey = normalizePubkey(value);
      return pubkey
        ? await lookupStoredProfile(profiles, pubkey, lookupSignal, dependencies)
        : null;
    },
    search: async (query, limit, searchSignal) => await searchRun(
      profiles,
      postings,
      query,
      limit,
      searchSignal,
      dependencies,
    ),
  };
}

async function searchRun(
  profiles: ProfileSearchV3ClientPageRouter,
  postings: ProfileSearchV3ClientPageRouter,
  rawQuery: string,
  limit: number,
  signal: AbortSignal | null,
  dependencies: ProfileSearchV3ClientRunDependencies,
): Promise<ProfileSearchV3ClientHit[]> {
  throwIfProfileSearchAborted(signal);
  const directPubkey = normalizePubkey(rawQuery);
  if (directPubkey) {
    const direct = await lookupStoredProfile(
      profiles,
      directPubkey,
      signal,
      dependencies,
    );
    return direct ? [{ ...direct, textScore: 14_000, matchedModes: ['identifier'] }] : [];
  }
  const query = boundedTerm(normalizeProfileSearchText(rawQuery), 'query');
  if (!query) {return [];}
  const candidates = new Map<string, Set<ProfileSearchV3ClientPostingMode>>();
  const routeLimit = Math.min(MAX_QUERY_CANDIDATES, Math.max(32, limit * 8));
  const words = searchWords(query).sort((left, right) => right.length - left.length
    || compareText(left, right));
  const routes = uniqueRoutes([
    { mode: 'nip05', term: query },
    { mode: 'identity', term: query },
    ...(words.length === 1 ? [{ mode: 'word' as const, term: words[0]! }] : []),
    ...words.flatMap((word) => [
      { mode: 'word' as const, term: word },
      { mode: 'prefix' as const, term: boundedPrefix(word) },
    ]),
  ]);
  for (const route of routes) {
    await collectRoute(postings, route, routeLimit, candidates, signal);
    if (candidates.size >= MAX_QUERY_CANDIDATES) {break;}
  }
  if (candidates.size < routeLimit) {
    for (const gram of queryTrigrams(query).slice(0, MAX_QUERY_TRIGRAMS)) {
      await collectRoute(
        postings,
        { mode: 'trigram', term: gram },
        Math.max(16, limit * 4),
        candidates,
        signal,
      );
      if (candidates.size >= MAX_QUERY_CANDIDATES) {break;}
    }
  }
  const entries = [...candidates.entries()];
  const loaded = (await mapConcurrent(entries, 8, async ([pubkey, modes]) => {
    throwIfProfileSearchAborted(signal);
    const input = await lookupStoredProfileInput(profiles, pubkey, signal);
    return input ? { input, modes } : null;
  })).filter((candidate): candidate is {
    input: ProfileSearchV3ClientStoredProfileInput;
    modes: Set<ProfileSearchV3ClientPostingMode>;
  } => candidate !== null);
  const workBudget = dependencies.createWorkBudget?.() ?? new CooperativeWorkBudget();
  const storedProfiles = await verifyAndProjectClientStoredProfiles(
    loaded.map(({ input }) => input),
    {
      signal,
      verifyEvents: dependencies.verifyEvents,
      workBudget,
    },
  );
  const hydrated: ProfileSearchV3ClientHit[] = [];
  for (let index = 0; index < loaded.length; index += 1) {
    throwIfProfileSearchAborted(signal);
    const stored = storedProfiles[index];
    if (!stored) {continue;}
    const textScore = await workBudget.run(
      () => profileSearchRank(stored.profile, rawQuery).textScore,
    );
    if (textScore > 0) {
      hydrated.push({
        ...stored,
        textScore,
        matchedModes: [...loaded[index]!.modes].sort(compareMode),
      });
    }
  }
  return hydrated
    .sort(compareHits).slice(0, limit);
}

async function collectRoute(
  router: ProfileSearchV3ClientPageRouter,
  route: { mode: ProfileSearchV3ClientPostingMode; term: string },
  limit: number,
  candidates: Map<string, Set<ProfileSearchV3ClientPostingMode>>,
  signal: AbortSignal | null,
): Promise<void> {
  if (!route.term) {return;}
  // Existing catalogs index full words and prefixes of two or more characters.
  // A bounded word-range scan also supports the first character without rebuilding them.
  const firstCharacter = route.mode === 'word' && [...route.term].length === 1;
  const prefix = `${modeCode(route.mode)}${SEPARATOR}${boundedTerm(route.term, 'posting prefix')}${firstCharacter ? '' : SEPARATOR}`;
  let read = 0;
  for await (const routed of router.rangePages(prefix, `${prefix}\uffff`, signal)) {
    for (const [key, value] of routed.page.entries) {
      throwIfProfileSearchAborted(signal);
      if (!key.startsWith(prefix)) {continue;}
      if (value !== '') {throw new Error('Profile-search v3 posting value is not canonical');}
      const posting = parsePostingKey(key);
      const modes = candidates.get(posting.pubkey) ?? new Set<ProfileSearchV3ClientPostingMode>();
      modes.add(posting.mode);
      candidates.set(posting.pubkey, modes);
      read += 1;
      if (read >= limit || candidates.size >= MAX_QUERY_CANDIDATES) {return;}
    }
  }
}

async function lookupStoredProfile(
  router: ProfileSearchV3ClientPageRouter,
  pubkey: string,
  signal: AbortSignal | null,
  dependencies: ProfileSearchV3ClientRunDependencies,
): Promise<ProfileSearchV3ClientStoredProfile | null> {
  const input = await lookupStoredProfileInput(router, pubkey, signal);
  if (!input) {return null;}
  return (await verifyAndProjectClientStoredProfiles([input], {
    signal,
    verifyEvents: dependencies.verifyEvents,
    workBudget: dependencies.createWorkBudget?.(),
  }))[0] ?? null;
}

async function lookupStoredProfileInput(
  router: ProfileSearchV3ClientPageRouter,
  pubkey: string,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientStoredProfileInput | null> {
  const normalized = strictPubkey(pubkey, 'profile pubkey');
  const page = await router.lookupPage(normalized, signal);
  const entry = page?.page.entries.find(([key]) => key === normalized);
  return entry ? { expectedPubkey: normalized, raw: entry[1] } : null;
}

function decodeStoredProfile(
  raw: string,
  expectedPubkey: string,
): DecodedStoredProfile {
  let value: unknown;
  try {value = JSON.parse(raw);} catch {throw new Error('Invalid profile-search v3 stored profile JSON');}
  const object = objectValue(value, 'stored profile');
  exactKeys(object, ['event', 'rankHint'], 'stored profile');
  const event = validateProfileEvent(object.event);
  if (event.pubkey !== strictPubkey(expectedPubkey, 'stored profile key')) {
    throw new Error('Profile-search v3 stored profile pubkey does not match its key');
  }
  const rankHint = nonNegativeInteger(object.rankHint, 'rankHint');
  if (raw !== JSON.stringify({ event, rankHint })) {
    throw new Error('Profile-search v3 stored profile is not canonical');
  }
  return { event, rankHint };
}

function projectStoredProfile(
  decoded: DecodedStoredProfile,
): ProfileSearchV3ClientStoredProfile {
  const { event, rankHint } = decoded;
  const base = parseProfileEvent(event);
  const identity = projectProfileSearchIdentity(event);
  if (!base || !identity) {throw new Error('Profile-search v3 stored profile cannot be projected');}
  return {
    event,
    rankHint,
    profile: {
      ...base,
      name: identity.name,
      displayName: identity.displayName,
      nip05: identity.nip05,
      searchAliases: identity.aliases,
    },
  };
}

export async function verifyAndProjectClientStoredProfiles(
  inputs: readonly ProfileSearchV3ClientStoredProfileInput[],
  options: VerifyStoredProfileOptions = {},
): Promise<Array<ProfileSearchV3ClientStoredProfile | null>> {
  throwIfProfileSearchAborted(options.signal ?? null);
  const signal = options.signal ?? null;
  const workBudget = options.workBudget
    ?? options.createWorkBudget?.()
    ?? new CooperativeWorkBudget();
  const decoded: DecodedStoredProfile[] = [];
  for (const input of inputs) {
    throwIfProfileSearchAborted(signal);
    decoded.push(await workBudget.run(
      () => decodeStoredProfile(input.raw, input.expectedPubkey),
    ));
  }

  const valid: boolean[] = [];
  const verifyEvents = options.verifyEvents ?? verifyIndexedEvents;
  for (
    let offset = 0;
    offset < decoded.length;
    offset += MAX_INDEXED_EVENT_VERIFICATION_BATCH
  ) {
    throwIfProfileSearchAborted(signal);
    const events = decoded
      .slice(offset, offset + MAX_INDEXED_EVENT_VERIFICATION_BATCH)
      .map(({ event }) => event);
    const verified = await withProfileSearchAbort(
      verifyEvents(events, signal ?? undefined),
      signal,
    );
    if (verified.length !== events.length) {
      throw new Error('Profile-search verifier returned an invalid result count');
    }
    valid.push(...verified);
  }

  const profiles: Array<ProfileSearchV3ClientStoredProfile | null> = [];
  for (let index = 0; index < decoded.length; index += 1) {
    throwIfProfileSearchAborted(signal);
    profiles.push(valid[index]
      ? await workBudget.run(() => projectStoredProfile(decoded[index]!))
      : null);
  }
  return profiles;
}

function validateProfileEvent(value: unknown): RawEvent {
  const raw = objectValue(value, 'profile event');
  exactKeys(raw, ['id', 'pubkey', 'created_at', 'kind', 'tags', 'content', 'sig'], 'profile event');
  const event: RawEvent = {
    id: strictHex(raw.id, 64, 'event id'),
    pubkey: strictPubkey(raw.pubkey, 'event pubkey'),
    created_at: nonNegativeInteger(raw.created_at, 'event created_at'),
    kind: raw.kind === 0 ? 0 : -1,
    tags: normalizeTags(raw.tags),
    content: boundedStringBytes(raw.content, MAX_PROFILE_CONTENT_BYTES, 'event content'),
    sig: strictHex(raw.sig, 128, 'event signature'),
  };
  if (event.kind !== 0) {
    throw new Error('Profile-search v3 profile event is not a kind-0 event');
  }
  return event;
}
