export const DEFAULT_NOSTR_EVENT_INDEX_REF =
  'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/nostr-event-index';
export const DEFAULT_PROFILE_INDEX_REF =
  'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/profiles-by-pubkey';
export const DEFAULT_PROFILE_SEARCH_INDEX_REF =
  'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/profile-search';

export const ROOT_RESOLVE_TIMEOUT_MS = 4_500;
export const ROOT_RESOLVE_SETTLE_MS = 0;
export const INITIAL_FEED_LIMIT = 8;
export const INITIAL_MEDIA_FEED_LIMIT = 60;
export const FEED_PAGE_SIZE = 16;
export const INITIAL_PROFILE_NOTE_LIMIT = 6;
export const THREAD_REPLY_PAGE_SIZE = 64;
export const DEFAULT_PROFILE_NOTE_LIMIT = 24;
export const DEFAULT_PROFILE_FOLLOWER_LIMIT = 120;
export const PROFILE_RELAY_HISTORY_CACHE_LIMIT = 2_048;
export const DEFAULT_SUGGESTED_FOLLOWS_PUBKEY =
  '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';
export const SHADOW_EVENT_READS_STORAGE_KEY = 'iris-social:shadow-event-reads';

function readEnvString(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }

  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

export function getConfiguredEventIndexRef(): string {
  return readEnvString(import.meta.env?.VITE_NOSTR_EVENT_INDEX) ?? DEFAULT_NOSTR_EVENT_INDEX_REF;
}

export function getConfiguredProfileIndexRef(): string {
  return readEnvString(import.meta.env?.VITE_PROFILE_INDEX) ?? DEFAULT_PROFILE_INDEX_REF;
}

export function getConfiguredProfileSearchIndexRef(): string {
  return readEnvString(import.meta.env?.VITE_PROFILE_SEARCH_INDEX) ?? DEFAULT_PROFILE_SEARCH_INDEX_REF;
}

export function parseConfiguredProfileSearchIndexRefs(
  value: unknown,
  fallbackRef = DEFAULT_PROFILE_SEARCH_INDEX_REF,
): string[] {
  const configured = parseConfiguredPostSearchIndexRefs(value);
  return configured.length > 0 ? configured : [fallbackRef];
}

export function getConfiguredProfileSearchIndexRefs(): string[] {
  return parseConfiguredProfileSearchIndexRefs(
    import.meta.env?.VITE_PROFILE_SEARCH_INDEXES,
    getConfiguredProfileSearchIndexRef(),
  );
}

/** Profile Search v3 is opt-in while immutable catalogs are shadowed. */
export function parseConfiguredProfileSearchV3IndexRefs(
  value: unknown,
  primaryRef: string | null = null,
): string[] {
  return parseConfiguredPostSearchIndexRefs(value, primaryRef);
}

export function getConfiguredProfileSearchV3IndexRefs(): string[] {
  return parseConfiguredProfileSearchV3IndexRefs(
    import.meta.env?.VITE_PROFILE_SEARCH_V3_INDEXES,
    getConfiguredProfileSearchV3IndexRef(),
  );
}

export function getConfiguredProfileSearchV3IndexRef(): string | null {
  return readEnvString(import.meta.env?.VITE_PROFILE_SEARCH_V3_INDEX);
}

export function getConfiguredSocialRelationshipIndexRef(): string | null {
  return readEnvString(import.meta.env?.VITE_SOCIAL_RELATIONSHIP_INDEX);
}

export function isSocialRelationshipCatalogConfigured(): boolean {
  return getConfiguredSocialRelationshipIndexRef() !== null;
}

export function parseConfiguredPostSearchIndexRefs(
  value: unknown,
  primaryRef: string | null = null,
): string[] {
  const configured = readEnvString(value);
  const federated = configured
    ? configured.split(/[\s,]+/).map((entry) => entry.trim()).filter(Boolean)
    : [];
  return [...new Set([
    ...(primaryRef?.trim() ? [primaryRef.trim()] : []),
    ...federated,
  ])];
}

export function getConfiguredPostSearchIndexRefs(): string[] {
  return parseConfiguredPostSearchIndexRefs(
    import.meta.env?.VITE_POST_SEARCH_INDEXES,
    readEnvString(import.meta.env?.VITE_POST_SEARCH_INDEX),
  );
}

export function getConfiguredDefaultViewerNpub(): string | null {
  return readEnvString(import.meta.env?.VITE_DEFAULT_VIEWER_NPUB);
}

export function isShadowEventReadComparisonEnabled(
  storage: Pick<Storage, 'getItem'> | null = browserStorage(),
): boolean {
  if (enabledFlag(import.meta.env?.VITE_SHADOW_EVENT_READS)) {return true;}
  try {
    return enabledFlag(storage?.getItem(SHADOW_EVENT_READS_STORAGE_KEY));
  } catch {
    return false;
  }
}

function enabledFlag(value: unknown): boolean {
  return typeof value === 'string' && /^(1|true|on|yes)$/i.test(value.trim());
}

function browserStorage(): Pick<Storage, 'getItem'> | null {
  if (typeof window === 'undefined') {return null;}
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}
