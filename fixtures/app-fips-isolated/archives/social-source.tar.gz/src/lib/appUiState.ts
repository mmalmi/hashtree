export type HomeFeedPaginationState = {
  feedLimit: number;
  homeFeedFetchLimit: number;
  homeFeedLoadPending: boolean;
  homeFeedScrollOffset: number;
  homeFeedLastLoadScrollOffset: number;
};

export type ProfileFeedPaginationState = {
  profileNoteLimit: number;
  profileNoteFetchLimit: number;
  profileFeedLoadPending: boolean;
  profileFeedScrollOffset: number;
  profileFeedLastLoadScrollOffset: number;
};

export type ProfileSocialPaginationState = {
  profileSocialLoadPending: boolean;
  profileSocialVisibleLimit: number;
  profileSocialFollowerFetchLimit: number;
  profileSocialScrollOffset: number;
  profileSocialLastLoadScrollOffset: number;
};

export type ThreadReplyPaginationState = {
  threadReplyFetchLimit: number;
  threadRepliesLoadPending: boolean;
  threadReplyScrollOffset: number;
  threadReplyLastLoadScrollOffset: number;
};

export function createHomeFeedPaginationState(
  initialFeedLimit: number,
  prefetchCount = 1,
): HomeFeedPaginationState {
  return {
    feedLimit: initialFeedLimit,
    homeFeedFetchLimit: initialFeedLimit + Math.max(prefetchCount, 1),
    homeFeedLoadPending: false,
    homeFeedScrollOffset: 0,
    homeFeedLastLoadScrollOffset: 0,
  };
}

export function createProfileFeedPaginationState(
  initialProfileNoteLimit: number,
  prefetchCount = 1,
): ProfileFeedPaginationState {
  return {
    profileNoteLimit: initialProfileNoteLimit,
    profileNoteFetchLimit: initialProfileNoteLimit + Math.max(prefetchCount, 1),
    profileFeedLoadPending: false,
    profileFeedScrollOffset: 0,
    profileFeedLastLoadScrollOffset: 0,
  };
}

export function createProfileSocialPaginationState(pageSize: number): ProfileSocialPaginationState {
  return {
    profileSocialLoadPending: false,
    profileSocialVisibleLimit: pageSize,
    profileSocialFollowerFetchLimit: pageSize,
    profileSocialScrollOffset: 0,
    profileSocialLastLoadScrollOffset: 0,
  };
}

export function createThreadReplyPaginationState(pageSize: number): ThreadReplyPaginationState {
  return {
    threadReplyFetchLimit: pageSize,
    threadRepliesLoadPending: false,
    threadReplyScrollOffset: 0,
    threadReplyLastLoadScrollOffset: 0,
  };
}
