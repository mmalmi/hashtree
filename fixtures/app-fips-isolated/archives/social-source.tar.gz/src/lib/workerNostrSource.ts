import type { HashtreeWorkerClient } from '@hashtree/worker/client';
import { connectNostrSource, serveNostrSource } from '@hashtree/worker/nostr-source-port';
import {
  localIndexSource, type NostrEventReader, type NostrVerifiedEvent,
  type NostrFilter, type RuntimeSource,
} from 'nostr-pubsub';
import type { SocialLiveTransport } from './socialDataPlaneTypes';

type Interest = {
  filters: NostrFilter[];
  handler: Parameters<SocialLiveTransport['subscribe']>[1];
  active: Array<{ close(): void }>;
  generation: number;
};

/** Browser control surface; all event caching and relay work stay in the worker. */
export class WorkerNostrSource implements SocialLiveTransport, NostrEventReader {
  private app: ReturnType<typeof connectNostrSource> | null = null;
  private stopPeer: (() => void) | null = null;
  private interests = new Set<Interest>();
  get attached(): boolean { return this.app !== null; }
  constructor(readonly client: HashtreeWorkerClient) {}

  async attach(source: RuntimeSource): Promise<void> {
    await this.detach();
    const peerChannel = new MessageChannel();
    const appChannel = new MessageChannel();
    this.stopPeer = serveNostrSource(peerChannel.port1, source);
    this.app = connectNostrSource(appChannel.port1, 'social-worker', 'queued');
    await this.client.postExtensionMessage({
      type: 'social:nostrPorts', peerPort: peerChannel.port2, appPort: appChannel.port2,
    }, [peerChannel.port2, appChannel.port2]);
    for (const interest of this.interests) { this.activate(interest); }
  }

  query: NostrEventReader['query'] = async (filters, options) => this.app
    ? this.app.source.query!(filters, options) : { events: [], complete: false };

  private activate(interest: Interest): void {
    const app = this.app;
    if (!app) { return; }
    const generation = ++interest.generation;
    // Large author scopes use multiple bounded wire frames, never a firehose.
    for (let offset = 0; offset < interest.filters.length; offset += 3) {
      void Promise.resolve(app.source.subscribe!(interest.filters.slice(offset, offset + 3), ({ event, source }) => {
        if (this.app === app && this.interests.has(interest) && interest.generation === generation) { interest.handler(event, source.id); }
      })).then(subscription => {
        if (this.app !== app || !this.interests.has(interest) || interest.generation !== generation) { subscription.close(); }
        else { interest.active.push(subscription); }
      }).catch(error => {
        if (this.app === app && this.interests.has(interest)) { console.warn('Peer subscription failed', error); }
      });
    }
  }

  subscribe: SocialLiveTransport['subscribe'] = (filters, handler) => {
    if (filters.length > 192) { throw new Error('Peer filter limit exceeded'); }
    const interest: Interest = { filters: structuredClone(filters), handler, active: [], generation: 0 };
    this.interests.add(interest);
    this.activate(interest);
    return { close: () => {
      this.interests.delete(interest);
      interest.active.forEach(subscription => subscription.close());
    } };
  };

  subscribeBatch: NonNullable<SocialLiveTransport['subscribeBatch']> = (filters, handler) => {
    const pending = new Map<string, { event: NostrVerifiedEvent; peer: string }>();
    let timer: ReturnType<typeof setTimeout> | null = null;
    const subscription = this.subscribe(filters, (event, peer) => {
      if (pending.size >= 256) {pending.delete(pending.keys().next().value!); }
      pending.set(event.id, { event, peer });
      timer ??= setTimeout(() => {
        timer = null;
        const batch = [...pending.values()];
        pending.clear();
        handler(batch.map(value => value.event), batch.map(value => value.peer));
      }, 0);
    });
    return { close() { subscription.close(); if (timer) { clearTimeout(timer); } pending.clear(); } };
  };

  async publish(event: Parameters<SocialLiveTransport['publish']>[0]): Promise<void> {
    await this.publishWithReceipt(event);
  }

  async publishWithReceipt(event: Parameters<SocialLiveTransport['publish']>[0]): Promise<boolean> {
    if (!this.app) { throw new Error('Peer delivery is unavailable'); }
    const report = await this.app.source.publish!(event, localIndexSource('social-outbox'));
    if (!report.accepted) { throw new Error('Peer delivery is unavailable'); }
    return 'remoteAccepted' in report && report.remoteAccepted === true;
  }

  async detach(): Promise<void> {
    const app = this.app;
    this.app = null;
    for (const interest of this.interests) {
      interest.active.forEach(subscription => subscription.close());
      interest.active = [];
    }
    if (app) { await this.client.postExtensionMessage({ type: 'social:nostrPorts' }); }
    this.stopPeer?.();
    this.stopPeer = null;
    app?.close();
  }

  async dispose(): Promise<void> { await this.detach(); this.interests.clear(); }
}
