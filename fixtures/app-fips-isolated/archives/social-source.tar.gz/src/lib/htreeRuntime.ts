import {
  createHtreeRuntime,
  type BlossomServerConfig,
  type WorkerConfig,
} from '@hashtree/worker';
import {
  DEFAULT_BLOSSOM_SERVERS,
  DEFAULT_NOSTR_RELAYS,
  readStoredSettingsSnapshot,
} from './settings';

type RuntimeOverrides = {
  relays?: readonly string[];
  privateRelays?: readonly string[];
  blossomServers?: readonly BlossomServerConfig[];
  fipsDiscoveryApp?: string;
  fipsPeers?: readonly string[];
  fipsWebsocketSeedUrls?: readonly string[];
};

type RuntimeWindow = Window & {
  __IRIS_SOCIAL_RUNTIME_OVERRIDES__?: RuntimeOverrides;
};

const runtime = createHtreeRuntime({
  appId: 'iris-social',
  relays: DEFAULT_NOSTR_RELAYS,
  blossomServers: DEFAULT_BLOSSOM_SERVERS,
});

export const WORKER_STORE_NAME = 'iris-social-worker';
export const IRIS_SOCIAL_FIPS_DISCOVERY_APP = 'iris-social-v1';

const COMPRESSED_FIPS_PEER_PATTERN = /^(02|03)[0-9a-f]{64}$/i;

function getRuntimeOverrides(): RuntimeOverrides {
  if (typeof window === 'undefined') {
    return {};
  }

  const overrides = (window as RuntimeWindow).__IRIS_SOCIAL_RUNTIME_OVERRIDES__;
  if (!overrides || typeof overrides !== 'object') {
    return {};
  }

  return overrides;
}

export function getConfiguredNostrRelays(): string[] {
  const overrides = getRuntimeOverrides();
  const settings = readStoredSettingsSnapshot();
  const relays = overrides.relays ?? settings.network.relays;
  if (relays.length === 0) { return []; }
  return runtime.getEndpoints({
    relays,
    blossomServers: overrides.blossomServers ?? settings.network.blossomServers,
  }).nostrRelays;
}

/** Private discovery, receiving and delivery retain their own saved relay scope. */
export function getConfiguredPrivateNostrRelays(): string[] {
  const overrides = getRuntimeOverrides();
  const { network } = readStoredSettingsSnapshot();
  const relays = overrides.privateRelays ?? overrides.relays ?? network.privateRelays ?? network.relays;
  if (relays.length === 0) { return []; }
  return runtime.getEndpoints({
    relays,
    blossomServers: overrides.blossomServers ?? network.blossomServers,
  }).nostrRelays;
}

export function getConfiguredBlossomServers(): BlossomServerConfig[] {
  const overrides = getRuntimeOverrides();
  const settings = readStoredSettingsSnapshot();
  return runtime.getEndpoints({
    relays: overrides.relays ?? settings.network.relays,
    blossomServers: overrides.blossomServers ?? settings.network.blossomServers ?? DEFAULT_BLOSSOM_SERVERS,
  }).blossomServers;
}

export function getConfiguredFipsDiscoveryApp(): string {
  const configured = getRuntimeOverrides().fipsDiscoveryApp?.trim();
  return configured || IRIS_SOCIAL_FIPS_DISCOVERY_APP;
}

export function normalizeFipsPeerIds(peerIds: readonly string[]): string[] {
  const normalized = new Set<string>();
  for (const peerId of peerIds) {
    const value = peerId.trim().toLowerCase();
    if (!COMPRESSED_FIPS_PEER_PATTERN.test(value)) {
      throw new Error(`Invalid compressed FIPS peer identity: ${peerId}`);
    }
    normalized.add(value);
  }
  return [...normalized].sort();
}

/** Optional known provider routes; authenticated discovery supplies additional peers. */
export function getConfiguredFipsPeerIds(): string[] {
  const overridden = getRuntimeOverrides().fipsPeers;
  if (overridden) {
    return normalizeFipsPeerIds(overridden);
  }
  const configured = import.meta.env.VITE_FIPS_PEERS;
  if (typeof configured !== 'string' || !configured.trim()) {
    return [];
  }
  return normalizeFipsPeerIds(configured.split(/[\s,]+/));
}

/** Test/runtime override for authenticated first-adjacency seeds; absent uses adapter defaults. */
export function getConfiguredFipsWebsocketSeedUrls(): readonly string[] | undefined {
  return getRuntimeOverrides().fipsWebsocketSeedUrls;
}

export function getHashtreeWorkerConfig(
  options: Omit<WorkerConfig, 'relays' | 'blossomServers'> = {},
): WorkerConfig {
  return {
    ...options,
    // Mutable roots are resolved by Iris Social's guarded nostr-pubsub relay
    // carrier. The block worker never receives relay endpoints, so it cannot
    // accidentally grow a second raw Nostr read path.
    relays: [],
    blossomServers: getConfiguredBlossomServers(),
  };
}
