import { canonicalRouteHref, parseRouteLocation, type Route } from './appRoute';
import { buildNoteThreadReference } from './appSharing';
import type { ProfileRecord, RawEvent } from './nostr';
import { warmSharedProfiles } from './profileCache';
import { searchHref } from './routes';
import { waitForNextBrowserPaint } from './asyncTiming';

type SearchActionsDeps = {
  route: Route;
  searchDropdownRoot: HTMLDivElement | null;
  searchLoading: boolean;
  searchQuery: string;
  searchRemoteProfiles: ProfileRecord[];
  searchRequestId: number;
  searchSheetOpen: boolean;
  searchTab: 'people' | 'posts';
  cacheKnownNotes: (notes: RawEvent[]) => void;
  loadSearchPage: () => Promise<void>;
  cancelProfileSearchDebounce: () => void;
  cancelRemoteSearch: () => void;
  navigateProfile: (pubkey: string) => void;
  navigateThread: (ref: string) => void;
  navigateToHref: (href: string) => void;
  scheduleRemoteSearch: (query: string) => void;
  warmSearchIndexes?: () => void;
  waitForSearchPaint?: () => Promise<void>;
};

export function createAppSearchActions(deps: SearchActionsDeps) {
  const warmSearchIndexes = deps.warmSearchIndexes ?? (() => {
    void import('./profileSearch').then(({ warmProfileSearchIndex }) => warmProfileSearchIndex()).catch((error) => {
      console.warn('Failed to warm profile search index', error);
    });
    void import('./profileSearchV3Runtime').then(({ warmProfileSearchV3Indexes }) => warmProfileSearchV3Indexes()).catch((error) => {
      console.warn('Failed to warm profile search v3 indexes', error);
    });
    void warmSharedProfiles().catch((error) => {
      console.warn('Failed to warm shared profile index', error);
    });
    void import('./postSearchRuntime').then(async ({ warmPostSearchIndexes }) => {
      await warmPostSearchIndexes();
    }).catch((error) => {
      console.warn('Failed to warm post search indexes', error);
    });
  });
  const waitForSearchPaint = deps.waitForSearchPaint ?? waitForNextBrowserPaint;

  function persistSearchLocation(): void {
    if (typeof window === 'undefined'
      || parseRouteLocation(window.location.pathname, window.location.hash).kind !== 'search') { return; }
    window.history.replaceState(window.history.state, '', searchHref(deps.searchQuery, deps.searchTab));
  }

  function applySearchRoute(route: Route): void {
    if (route.kind !== 'search') { return; }
    if (typeof window !== 'undefined'
      && canonicalRouteHref(parseRouteLocation(window.location.pathname, window.location.hash))
        !== canonicalRouteHref(route)) { return; }
    closeSearchSheet({ preserveQuery: true });
    deps.searchQuery = route.query ?? deps.searchQuery;
    deps.searchTab = route.tab ?? deps.searchTab;
    deps.searchRemoteProfiles = [];
    persistSearchLocation();
    if (deps.searchTab === 'people') { deps.scheduleRemoteSearch(deps.searchQuery); }
  }

  function warmSearchResources(): void {
    void deps.loadSearchPage();
    warmSearchIndexes();
  }

  function openSearchSheet(): void {
    if (deps.searchSheetOpen) {
      return;
    }
    deps.searchSheetOpen = true;
    void waitForSearchPaint().then(() => {
      if (deps.searchSheetOpen) {
        warmSearchResources();
      }
    });
  }

  function closeSearchSheet(options: { preserveQuery?: boolean } = {}): void {
    deps.cancelProfileSearchDebounce();
    deps.cancelRemoteSearch();
    deps.searchRequestId += 1;
    deps.searchSheetOpen = false;
    if (options.preserveQuery) {
      deps.searchLoading = false;
      return;
    }
    deps.searchQuery = '';
    deps.searchTab = 'people';
    deps.searchRemoteProfiles = [];
    deps.searchLoading = false;
  }

  function handleSearchQueryChange(value: string, source: 'page' | 'header' = 'header'): void {
    if (typeof window !== 'undefined') {
      const onSearchPage = parseRouteLocation(window.location.pathname, window.location.hash).kind === 'search';
      if (onSearchPage !== (source === 'page')) { return; }
    }
    deps.searchQuery = value;
    persistSearchLocation();
    if (deps.searchTab !== 'people') {
      deps.cancelProfileSearchDebounce();
      deps.cancelRemoteSearch();
      deps.searchRequestId += 1;
      deps.searchLoading = false;
      return;
    }
    deps.scheduleRemoteSearch(value);
  }

  function handleSearchTabChange(tab: 'people' | 'posts'): void {
    if (typeof window !== 'undefined'
      && parseRouteLocation(window.location.pathname, window.location.hash).kind !== 'search') { return; }
    deps.searchTab = tab;
    persistSearchLocation();
    if (tab === 'people') {
      deps.scheduleRemoteSearch(deps.searchQuery);
      return;
    }
    deps.cancelProfileSearchDebounce();
    deps.cancelRemoteSearch();
    deps.searchRequestId += 1;
    deps.searchLoading = false;
  }

  function handleSearchOpenProfile(pubkey: string): void {
    closeSearchSheet({ preserveQuery: deps.route.kind === 'search' });
    deps.navigateProfile(pubkey);
  }

  function handleSearchOpenPost(event: RawEvent): void {
    deps.cacheKnownNotes([event]);
    closeSearchSheet({ preserveQuery: deps.route.kind === 'search' });
    deps.navigateThread(buildNoteThreadReference(event));
  }

  function handleHeaderSearchPosts(value: string): void {
    const nextQuery = value.trim();
    if (!nextQuery) {
      return;
    }
    closeSearchSheet();
    deps.searchQuery = nextQuery;
    deps.searchTab = 'posts';
    deps.navigateToHref(searchHref(nextQuery, 'posts'));
  }

  function handleSearchOpenThread(ref: string): void {
    closeSearchSheet({ preserveQuery: deps.route.kind === 'search' });
    deps.navigateThread(ref);
  }

  function handleWindowChromeClick(event: MouseEvent): void {
    const target = event.target;
    if (
      target instanceof Node
      && deps.searchSheetOpen
      && !deps.searchDropdownRoot?.contains(target)
    ) {
      closeSearchSheet();
    }
  }

  function handleWindowChromeKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape' || !deps.searchSheetOpen) {
      return;
    }
    event.preventDefault();
    closeSearchSheet();
  }

  return {
    applySearchRoute,
    closeSearchSheet,
    handleHeaderSearchPosts,
    handleSearchOpenPost,
    handleSearchOpenProfile,
    handleSearchOpenThread,
    handleSearchQueryChange,
    handleSearchTabChange,
    handleWindowChromeClick,
    handleWindowChromeKeydown,
    openSearchSheet,
    warmSearchResources,
  };
}
