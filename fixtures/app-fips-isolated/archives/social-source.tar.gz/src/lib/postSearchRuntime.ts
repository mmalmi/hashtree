import { HashTree, type CID } from '@hashtree/core';
import { getConfiguredPostSearchIndexRefs, ROOT_RESOLVE_SETTLE_MS, ROOT_RESOLVE_TIMEOUT_MS } from './config';
import {
  FederatedPostSearch,
  type FederatedPostSearchOptions,
  type FederatedPostSearchResponse,
  type PostSearchCatalogSource,
} from './postSearch';
import type { DeferredPostSearchCatalogSource } from './postSearchFederation';
import { postSearchPublisherId } from './postSearchRefs';
import { throwIfPostSearchAborted, withPostSearchAbort } from './postSearchAbort';
import { verifyPostSearchEventsInWorker } from './postSearchExecution';
import { resolveTreeTargetRoot } from './treeRef';
import { createWorkerBlockStore } from './workerBlockStore';

const POST_SEARCH_ROOT_TTL_MS = 30_000;
const POST_SEARCH_ROOT_RETRY_DELAYS_MS = [120, 360, 900];
const POST_SEARCH_ROOT_CACHE_LIMIT = 32;

type CachedRoot = {
  expiresAt: number;
  root: CID;
};

const store = createWorkerBlockStore();
const tree = new HashTree({ store });
const search = new FederatedPostSearch(store, {
  verifyEvents: verifyPostSearchEventsInWorker,
});
const rootCache = new Map<string, CachedRoot>();
const rootPromises = new Map<string, Promise<PostSearchCatalogSource | null>>();

export async function searchPosts(
  query: string,
  options: FederatedPostSearchOptions = {},
): Promise<FederatedPostSearchResponse> {
  const signal = options.signal ?? null;
  const sources = getConfiguredPostSearchIndexRefs().flatMap<DeferredPostSearchCatalogSource>((ref) => {
    const publisherId = postSearchPublisherId(ref);
    if (!publisherId) {
      return [];
    }
    return [{
      publisherId,
      root: resolvePostSearchSource(ref, signal).then((source) => source?.root ?? null),
    }];
  });
  return await search.search(sources, query, options);
}

export async function warmPostSearchIndexes(): Promise<void> {
  const sources = (await Promise.all(getConfiguredPostSearchIndexRefs().map(async (ref) =>
    await resolvePostSearchSource(ref))))
    .filter((source): source is PostSearchCatalogSource => source !== null);
  await search.warm(sources);
}

async function resolvePostSearchSource(
  ref: string,
  signal: AbortSignal | null = null,
): Promise<PostSearchCatalogSource | null> {
  throwIfPostSearchAborted(signal);
  const publisherId = postSearchPublisherId(ref);
  if (!publisherId) {
    return null;
  }
  const cached = rootCache.get(ref);
  if (cached && cached.expiresAt > Date.now()) {
    rootCache.delete(ref);
    rootCache.set(ref, cached);
    return { publisherId, root: cached.root };
  }
  const pending = rootPromises.get(ref);
  if (pending) {
    return await withPostSearchAbort(pending, signal);
  }
  const promise = (async () => {
    const root = await resolveTreeTargetRoot(ref, {
      resolveImmutablePath: async (immutableRoot, path) =>
        (await tree.resolvePath(immutableRoot, path))?.cid ?? null,
      timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
      settleMs: ROOT_RESOLVE_SETTLE_MS,
      retryDelaysMs: POST_SEARCH_ROOT_RETRY_DELAYS_MS,
    });
    if (!root) {
      return null;
    }
    rootCache.delete(ref);
    while (rootCache.size >= POST_SEARCH_ROOT_CACHE_LIMIT) {
      rootCache.delete(rootCache.keys().next().value as string);
    }
    rootCache.set(ref, { root, expiresAt: Date.now() + POST_SEARCH_ROOT_TTL_MS });
    return { publisherId, root };
  })();
  rootPromises.set(ref, promise);
  void promise.finally(() => {
    if (rootPromises.get(ref) === promise) {
      rootPromises.delete(ref);
    }
  }).catch(() => undefined);
  return await withPostSearchAbort(promise, signal);
}
