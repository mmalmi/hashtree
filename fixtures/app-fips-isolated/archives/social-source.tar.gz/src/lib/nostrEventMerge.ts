import type { RawEvent } from './nostr';

export function mergeRecentEvents(limit: number, ...eventSets: RawEvent[][]): RawEvent[] {
  const byId = new Map<string, RawEvent>();
  for (const events of eventSets) {
    for (const event of events) {
      if (!byId.has(event.id)) {
        byId.set(event.id, event);
      }
    }
  }
  return [...byId.values()]
    .sort((left, right) => right.created_at - left.created_at || left.id.localeCompare(right.id))
    .slice(0, Math.max(limit, 0));
}
