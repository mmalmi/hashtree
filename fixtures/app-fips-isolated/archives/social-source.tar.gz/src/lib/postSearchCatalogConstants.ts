import type { RankedSearchBuildOptions } from '@hashtree/index';

export const POST_SEARCH_CATALOG_FORMAT_V1 = 'iris-social/ranked-post-search-catalog@1' as const;
export const POST_SEARCH_CATALOG_FORMAT_V2 = 'iris-social/ranked-post-search-catalog@2' as const;
export const POST_SEARCH_CATALOG_FORMAT_V3 = 'iris-social/ranked-post-search-catalog@3' as const;
export const POST_SEARCH_CATALOG_FORMAT = 'iris-social/ranked-post-search-catalog@4' as const;
export const POST_SEARCH_DOCUMENT_FORMAT = 'iris-social/nostr-post-search-document@1' as const;
export const POST_SEARCH_NORMALIZATION = 'NFKC-lowercase@1' as const;
export const POST_SEARCH_VISIBLE_PROJECTION = 'nostr-visible-posts@1' as const;
export const POST_SEARCH_AUTHOR_TERMS_PROJECTION = 'nostr-kind0-name-display_name-nip05@1' as const;
export const POST_SEARCH_KINDS = [1, 20, 1_111, 30_023] as const;
/** Keeps every emitted manifest comfortably below the authenticated 1 MiB reader cap. */
export const POST_SEARCH_MAX_CATALOG_SEGMENTS = 1_024;
export const POST_SEARCH_MAX_CATALOG_BYTES = 1_048_576;

export const POST_SEARCH_BUILD_OPTIONS = {
  fields: {
    author: { boost: 2.5, lengthNormalization: 0.1 },
    content: { boost: 1, lengthNormalization: 0.75 },
    hashtags: { boost: 7, lengthNormalization: 0.1 },
    title: { boost: 5, lengthNormalization: 0.25 },
  },
  maxTokensPerField: 4_096,
} as const satisfies RankedSearchBuildOptions;
