import { getNoteEngagementTargetId } from './noteEngagement';
import { accountsStore } from './accounts';
import { getCurrentActiveAccountPubkey } from './appAccountState';
import type { Route } from './appRoute';
import { routeKey } from './appRoute';
import type { FeedSource } from './appStorage';
import { waitForNextBrowserPaint } from './asyncTiming';
import { DURABLE_POST_KINDS, type FeedSnapshot } from './nostrIndex';
import {
  readHomeFeedSnapshotAsync,
  writeHomeFeedSnapshotAsync,
  type HomeFeedSnapshotKey,
} from './homeFeedSnapshotCache';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import {
  extractPublicMutedPubkeys,
  filterMutedAuthorEvents,
  selectNewestAdmittedMuteListEvent,
} from './muteLists';
import { isReplyEvent, type RawEvent } from './nostr';
import { socialDataPlane } from './socialDataPlane';
import { INITIAL_FEED_LIMIT } from './config';

type HomeFeedSeenBatcher = ReturnType<typeof createHomeFeedSeenBatcher>;

type HomeFeedSnapshotDeps = {
  favoritePubkeys?: string[];
  activeFeedSourceId: string | null;
  feed: FeedSnapshot | null;
  feedRequiresRefresh: boolean;
  feedSources: FeedSource[];
  homeFeedSnapshotReadController: AbortController | null;
  homeFeedSnapshotWriteController: AbortController | null;
  homeFeedSnapshotWriteTimer: number | null;
  route: Route;
  homeFeedSeenBatcher: HomeFeedSeenBatcher;
  cacheKnownNotes: (notes: RawEvent[]) => void;
  noteHasMedia: (event: RawEvent) => boolean;
  seedEmptyEngagements: (noteIds: string[]) => void;
};

function getHomeFeedSnapshotKey(
  route: Route,
  viewerPubkey: string,
  feedSourcePubkey: string | null,
): HomeFeedSnapshotKey | null {
  if (route.kind !== 'home' || route.tab === 'notifications') {
    return null;
  }
  return {
    viewerPubkey,
    tab: route.tab,
    feedSourcePubkey: route.tab === 'for-you' || route.tab === 'favorites'
      ? viewerPubkey
      : feedSourcePubkey ?? viewerPubkey,
  };
}

function sameHomeFeedSnapshotKey(
  left: HomeFeedSnapshotKey,
  right: HomeFeedSnapshotKey,
): boolean {
  return left.viewerPubkey === right.viewerPubkey
    && left.tab === right.tab
    && left.feedSourcePubkey === right.feedSourcePubkey;
}

export function createAppHomeFeedSnapshots(deps: HomeFeedSnapshotDeps) {
  function getCurrentHomeFeedSnapshotKey(): HomeFeedSnapshotKey | null {
    const accountState = accountsStore.getState();
    const viewerPubkey = getCurrentActiveAccountPubkey(
      accountState.activeAccountPubkey ?? null,
      accountState.accounts,
    );
    if (!viewerPubkey) {
      return null;
    }
    const feedSourcePubkey = deps.activeFeedSourceId
      ? deps.feedSources.find((source) => source.id === deps.activeFeedSourceId)?.pubkey ?? null
      : null;
    return getHomeFeedSnapshotKey(deps.route, viewerPubkey, feedSourcePubkey);
  }

  function filterCachedHomeNotes(
    sourceNotes: RawEvent[],
    key: HomeFeedSnapshotKey,
    isForYouPreview: boolean,
  ): RawEvent[] {
    const localMuteList = selectNewestAdmittedMuteListEvent(
      socialDataPlane.query({ authors: [key.viewerPubkey], kinds: [10_000] }),
      key.viewerPubkey,
    );
    const seenEventIds = key.tab === 'for-you'
      ? deps.homeFeedSeenBatcher.read(key.viewerPubkey)
      : new Set<string>();
    return filterMutedAuthorEvents(
      sourceNotes,
      extractPublicMutedPubkeys(localMuteList),
      key.viewerPubkey,
    ).filter((event) => (
      !seenEventIds.has(event.id)
      && (key.tab !== 'favorites' || (deps.favoritePubkeys ?? []).includes(event.pubkey))
      && (
        !isForYouPreview
        || (
          event.pubkey !== key.viewerPubkey
          && (DURABLE_POST_KINDS as readonly number[]).includes(event.kind)
          && !(event.kind === 1 && isReplyEvent(event))
        )
      )
    ));
  }

  function scheduleHomeFeedSnapshotTailRestore(options: {
    storedSourceKey: HomeFeedSnapshotKey;
    currentKey: HomeFeedSnapshotKey;
    rootNhash: string;
    isForYouPreview: boolean;
  }): void {
    const controller = new AbortController();
    const expectedRouteKey = routeKey(deps.route);
    deps.homeFeedSnapshotReadController = controller;
    window.requestAnimationFrame(() => {
      window.setTimeout(() => {
        void readHomeFeedSnapshotAsync(options.storedSourceKey, undefined, {
          signal: controller.signal,
        }).then((snapshot) => {
          const currentKey = getCurrentHomeFeedSnapshotKey();
          if (
            !snapshot
            || controller.signal.aborted
            || deps.homeFeedSnapshotReadController !== controller
            || !currentKey
            || routeKey(deps.route) !== expectedRouteKey
            || !sameHomeFeedSnapshotKey(currentKey, options.currentKey)
            || !deps.feedRequiresRefresh
            || deps.feed?.rootNhash !== options.rootNhash
          ) {
            return;
          }
          const notes = filterCachedHomeNotes(
            snapshot.notes,
            options.currentKey,
            options.isForYouPreview,
          );
          if (notes.length === 0) {
            return;
          }
          deps.feed = {
            ...deps.feed,
            notes,
            follows: options.isForYouPreview
              ? [...new Set(notes.map((event) => event.pubkey))]
              : deps.feed.follows,
          };
          deps.cacheKnownNotes(notes);
          deps.seedEmptyEngagements(notes.map(getNoteEngagementTargetId));
          deps.homeFeedSnapshotReadController = null;
        });
      }, 0);
    });
  }

  function restoreHomeFeedSnapshot(previousLatestFeed: FeedSnapshot | null = null): void {
    deps.homeFeedSnapshotReadController?.abort();
    const key = getCurrentHomeFeedSnapshotKey();
    if (!key) {
      deps.homeFeedSnapshotReadController = null;
      return;
    }
    const latestFallbackKey: HomeFeedSnapshotKey = {
      viewerPubkey: key.viewerPubkey,
      tab: 'latest',
      feedSourcePubkey: key.viewerPubkey,
    };
    const expectedRouteKey = routeKey(deps.route);
    const controller = new AbortController();
    deps.homeFeedSnapshotReadController = controller;

    const applySnapshot = (
      sourceNotes: RawEvent[],
      sourceRootNhash: string,
      isForYouPreview: boolean,
    ): boolean => {
      const notes = filterCachedHomeNotes(sourceNotes, key, isForYouPreview);
      if (notes.length === 0) {
        return false;
      }
      deps.feed = {
        rootNhash: sourceRootNhash,
        followCount: 0,
        follows: key.tab === 'favorites' ? [...(deps.favoritePubkeys ?? [])] : isForYouPreview ? [...new Set(notes.map((event) => event.pubkey))] : [],
        profiles: new Map(),
        notes,
        feedOwnerPubkey: key.tab === 'favorites' ? 'favorites' : isForYouPreview
          ? ''
          : deps.route.kind === 'home' && deps.route.tab === 'for-you'
            ? 'for-you'
            : key.feedSourcePubkey,
        usedSuggestedFeed: false,
        starterMode: null,
        continuation: null,
      };
      deps.feedRequiresRefresh = true;
      deps.cacheKnownNotes(notes);
      deps.seedEmptyEngagements(notes.map(getNoteEngagementTargetId));
      return true;
    };

    // A just-presented Latest feed is already authenticated in memory, so it
    // can seed a cold For You surface without storage or signature work.
    const previewApplied = Boolean(
      key.tab === 'for-you'
      && previousLatestFeed?.rootNhash
      && applySnapshot(previousLatestFeed.notes, previousLatestFeed.rootNhash, true),
    );
    const expectedFeed = deps.feed;

    // localStorage is untrusted. Parse and verify its initial notes only after
    // the destination has painted, and perform all Schnorr work in the worker.
    void waitForNextBrowserPaint().then(async () => {
      const cached = await readHomeFeedSnapshotAsync(key, undefined, {
        maxNotes: INITIAL_FEED_LIMIT,
        signal: controller.signal,
      });
      const cachedLatest = !cached && key.tab === 'for-you' && !previewApplied
        ? await readHomeFeedSnapshotAsync(latestFallbackKey, undefined, {
            maxNotes: INITIAL_FEED_LIMIT,
            signal: controller.signal,
          })
        : null;
      const currentKey = getCurrentHomeFeedSnapshotKey();
      if (
        controller.signal.aborted
        || deps.homeFeedSnapshotReadController !== controller
        || !currentKey
        || routeKey(deps.route) !== expectedRouteKey
        || !sameHomeFeedSnapshotKey(currentKey, key)
        || deps.feed !== expectedFeed
      ) {
        if (deps.homeFeedSnapshotReadController === controller) {
          deps.homeFeedSnapshotReadController = null;
        }
        return;
      }
      const snapshot = cached ?? cachedLatest;
      const storedSourceKey = cached ? key : cachedLatest ? latestFallbackKey : null;
      if (
        !snapshot
        || !storedSourceKey
        || !applySnapshot(snapshot.notes, snapshot.metadata.rootNhash, key.tab === 'for-you' && !cached)
      ) {
        if (deps.homeFeedSnapshotReadController === controller) {
          deps.homeFeedSnapshotReadController = null;
        }
        return;
      }
      scheduleHomeFeedSnapshotTailRestore({
        storedSourceKey,
        currentKey: key,
        rootNhash: snapshot.metadata.rootNhash,
        isForYouPreview: key.tab === 'for-you' && !cached,
      });
    }).catch(() => {
      if (deps.homeFeedSnapshotReadController === controller) {
        deps.homeFeedSnapshotReadController = null;
      }
    });
  }

  function scheduleHomeFeedSnapshotWrite(nextFeed: FeedSnapshot): void {
    const key = getCurrentHomeFeedSnapshotKey();
    if (!key) {
      return;
    }
    const notes = (key.tab === 'media'
      ? nextFeed.notes.filter(deps.noteHasMedia)
      : nextFeed.notes).slice(0, 64);
    if (notes.length === 0) {
      return;
    }
    if (deps.homeFeedSnapshotWriteTimer !== null) {
      window.clearTimeout(deps.homeFeedSnapshotWriteTimer);
    }
    deps.homeFeedSnapshotWriteController?.abort();
    const controller = new AbortController();
    deps.homeFeedSnapshotWriteController = controller;
    const rootNhash = nextFeed.rootNhash;
    deps.homeFeedSnapshotWriteTimer = window.setTimeout(() => {
      deps.homeFeedSnapshotWriteTimer = null;
      void writeHomeFeedSnapshotAsync(key, { rootNhash, notes }, undefined, {
        signal: controller.signal,
      }).finally(() => {
        if (deps.homeFeedSnapshotWriteController === controller) {
          deps.homeFeedSnapshotWriteController = null;
        }
      });
    }, 250);
  }

  return { restoreHomeFeedSnapshot, scheduleHomeFeedSnapshotWrite };
}
