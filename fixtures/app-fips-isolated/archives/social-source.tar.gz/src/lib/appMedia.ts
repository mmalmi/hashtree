import type { RawEvent, ProfileRecord } from './nostr';
import type { NoteEmbed } from './noteContent';

export type MediaSelection = {
  event: RawEvent | null;
  profile: ProfileRecord | null;
  embeds: NoteEmbed[];
  index: number;
};

export type MediaOpenPayload = {
  event: RawEvent;
  embed: NoteEmbed;
  index: number;
  embeds: NoteEmbed[];
};

export function canOpenInMediaModal(embed: NoteEmbed): boolean {
  return embed.kind !== 'file';
}

export function isHashtreeMediaUrl(url: string): boolean {
  const trimmed = url.trim();
  return trimmed.startsWith('htree://') || /^nhash1[a-z0-9]+\/.+/i.test(trimmed);
}

export function createMediaSelection(
  payload: MediaOpenPayload,
  profile: ProfileRecord | null,
): MediaSelection | null {
  const modalEmbeds = payload.embeds.filter(canOpenInMediaModal);
  if (modalEmbeds.length === 0) {
    return null;
  }

  const nextIndex = modalEmbeds.findIndex((candidate) => candidate.url === payload.embed.url);
  return {
    event: payload.event,
    profile,
    embeds: modalEmbeds,
    index: nextIndex >= 0 ? nextIndex : 0,
  };
}

export function createProfileMediaSelection(
  url: string,
  label: string,
  profile: ProfileRecord | null,
): MediaSelection | null {
  const trimmed = url.trim();
  if (!trimmed) {
    return null;
  }

  return {
    event: null,
    profile,
    embeds: [{
      kind: 'image',
      url: trimmed,
      isHashtree: isHashtreeMediaUrl(trimmed),
      label,
    }],
    index: 0,
  };
}
