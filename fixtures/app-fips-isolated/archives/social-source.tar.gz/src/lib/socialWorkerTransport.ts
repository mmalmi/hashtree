import { validateSocialGraphBadgeQuery, type SocialGraphBadge } from './socialGraphBadgeQuery';
import { generateRequestId, type CID } from '@hashtree/core';
import type { HashtreeWorkerClient } from '@hashtree/worker/client';
import type { NostrFilter } from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import type { RecentTextNoteQueryOptions } from './recentTextNoteCursor';
import {
  isBoundedSocialGraphObservationBatch,
  isSocialWorkerResponse,
  type SocialWorkerHashtreeRoot,
  type SocialWorkerProfileSocial,
  type SocialWorkerRequest,
  type SocialWorkerResponse,
} from '../workers/socialWorkerProtocol';
import { verifyEventsInBoundedWorkerBatches } from './socialWorkerEventVerification';

export type HomeFeedWorkerOptions = Pick<
  RecentTextNoteQueryOptions,
  'before' | 'emitEvery' | 'includeReplies' | 'kinds' | 'since' | 'until'
> & {
  signal?: AbortSignal;
};

type SocialWorkerTransportOptions = {
  responseTimeoutMs?: number;
};

const DEFAULT_RESPONSE_TIMEOUT_MS = 30_000;
const DEFAULT_HASHTREE_QUERY_WINDOW_MS = 30_000;
const MAX_HASHTREE_QUERY_WINDOW_MS = 30_000;
const DEFAULT_RELAY_QUERY_WINDOW_MS = 10_000;
const MAX_RELAY_QUERY_WINDOW_MS = 30_000;

export type RelayQueryWorkerOptions = {
  limit: number;
  deadline?: number;
  signal?: AbortSignal;
};

export type HashtreeQueryWorkerOptions = {
  limit: number;
  deadline?: number;
  signal?: AbortSignal;
};

export type RelaySubscriptionWorkerHandlers = {
  onEvent(event: RawEvent): void;
  onClose?(reasons?: readonly string[]): void;
};

export type RelaySubscriptionWorkerOptions = {
  closeOnEose?: boolean;
};

function abortError(): DOMException {
  return new DOMException('The operation was aborted', 'AbortError');
}

function createResponseQueue(
  client: HashtreeWorkerClient,
  requestId: string,
  responseTimeoutMs: number,
  signal?: AbortSignal,
): {
  close(): void;
  workerFailed(): boolean;
  next(): Promise<SocialWorkerResponse>;
} {
  const queued: SocialWorkerResponse[] = [];
  let wake: (() => void) | null = null;
  let failure: Error | null = null;
  let failed = false;
  let closed = false;
  const notify = (): void => {
    const current = wake;
    wake = null;
    current?.();
  };
  const unsubscribe = client.onExtensionMessage((message) => {
    if (closed || !isSocialWorkerResponse(message) || message.requestId !== requestId) {
      return;
    }
    queued.push(message);
    notify();
  });
  const unsubscribeError = client.onExtensionError((error) => {
    if (closed) {
      return;
    }
    failed = true;
    failure = error;
    notify();
  });
  const onAbort = notify;
  signal?.addEventListener('abort', onAbort, { once: true });

  return {
    close() {
      closed = true;
      unsubscribe();
      unsubscribeError();
      signal?.removeEventListener('abort', onAbort);
      notify();
    },
    workerFailed() {
      return failed;
    },
    async next() {
      if (signal?.aborted) {
        throw abortError();
      }
      while (queued.length === 0) {
        if (signal?.aborted) {
          throw abortError();
        }
        if (failure) {
          throw failure;
        }
        if (closed) {
          throw new Error('Social worker response queue closed');
        }
        await new Promise<void>((resolve, reject) => {
          const resume = (): void => {
            clearTimeout(timeoutId);
            resolve();
          };
          const timeoutId = setTimeout(() => {
            if (wake !== resume) {
              return;
            }
            wake = null;
            reject(new Error('Social worker response timed out'));
          }, responseTimeoutMs);
          wake = resume;
        });
      }
      if (signal?.aborted) {
        throw abortError();
      }
      return queued.shift()!;
    },
  };
}

export class SocialWorkerTransport {
  private readonly responseTimeoutMs: number;

  constructor(
    private readonly client: HashtreeWorkerClient,
    options: SocialWorkerTransportOptions = {},
  ) {
    this.responseTimeoutMs = options.responseTimeoutMs ?? DEFAULT_RESPONSE_TIMEOUT_MS;
    if (!Number.isFinite(this.responseTimeoutMs) || this.responseTimeoutMs <= 0) {
      throw new RangeError('Social worker response timeout must be positive');
    }
  }

  async *streamHomeFeedNotes(
    root: CID,
    authors: string[],
    limit: number,
    options: HomeFeedWorkerOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    if (options.signal?.aborted) {
      throw abortError();
    }
    const requestId = generateRequestId();
    const queue = createResponseQueue(
      this.client,
      requestId,
      this.responseTimeoutMs,
      options.signal,
    );
    let complete = false;
    let reconstructedSnapshot: RawEvent[] | null = null;
    try {
      const request: SocialWorkerRequest = {
        type: 'social:openHomeFeed',
        requestId,
        root,
        authors,
        limit,
        includeReplies: options.includeReplies ?? false,
        emitEvery: options.emitEvery,
        before: options.before,
        kinds: options.kinds ? [...options.kinds] : undefined,
        since: options.since,
        until: options.until,
        acceptSnapshotPatches: true,
      };
      await this.client.postExtensionMessage(request);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:homeFeedSnapshot') {
          if (message.replaceFrom === undefined) {
            reconstructedSnapshot = message.notes.slice();
            yield message.notes;
            continue;
          }
          if (
            !Number.isSafeInteger(message.replaceFrom)
            || message.replaceFrom < 0
            || (reconstructedSnapshot === null && message.replaceFrom !== 0)
            || message.replaceFrom > (reconstructedSnapshot?.length ?? 0)
          ) {
            throw new Error('Invalid social worker Home snapshot patch');
          }
          reconstructedSnapshot = [
            ...(reconstructedSnapshot?.slice(0, message.replaceFrom) ?? []),
            ...message.notes,
          ];
          yield reconstructedSnapshot.slice();
          continue;
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
        if (message.type === 'social:homeFeedComplete') {
          complete = true;
          if (message.cancelled && !options.signal?.aborted) {
            throw abortError();
          }
          return;
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async verifyEvents(events: RawEvent[], signal?: AbortSignal): Promise<boolean[]> {
    // Validate and partition before postMessage. Structured cloning happens
    // synchronously on the caller's thread, so the worker cannot protect the
    // UI from an oversized cached event after it has already been posted.
    return await verifyEventsInBoundedWorkerBatches(
      events,
      async (batch, batchSignal) => await this.verifyBoundedEventBatch(batch, batchSignal),
      signal,
    );
  }

  private async verifyBoundedEventBatch(
    events: RawEvent[],
    signal?: AbortSignal,
  ): Promise<boolean[]> {
    const requestId = generateRequestId();
    const queue = createResponseQueue(this.client, requestId, this.responseTimeoutMs, signal);
    let complete = false;
    try {
      await this.client.postExtensionMessage({
        type: 'social:verifyEvents',
        requestId,
        events,
      } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:eventsVerified') {
          if (
            message.valid.length !== events.length
            || message.valid.some((valid) => typeof valid !== 'boolean')
          ) {
            throw new Error('Invalid event verification worker response');
          }
          complete = true;
          return message.valid;
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async queryProfileSocialSnapshot(
    pubkey: string, followerLimit: number, signal?: AbortSignal,
  ): Promise<SocialWorkerProfileSocial | null> {
    const response = await this.queryGraph({ type: 'social:queryProfileSocialSnapshot', pubkey, followerLimit }, signal);
    if (response.type !== 'social:profileSocialSnapshot') {throw new Error('Unexpected social graph response');}
    return response.social;
  }

  async querySocialGraphBadges(
    viewer: string, pubkeys: string[], signal?: AbortSignal,
  ): Promise<SocialGraphBadge[]> {
    validateSocialGraphBadgeQuery(viewer, pubkeys);
    const response = await this.queryGraph({ type: 'social:querySocialGraphBadges', viewer, pubkeys }, signal);
    if (response.type !== 'social:socialGraphBadges') {throw new Error('Unexpected social graph response');}
    return response.badges;
  }

  private async queryGraph(
    request: Omit<Extract<SocialWorkerRequest, { type: 'social:queryProfileSocialSnapshot' }>, 'requestId'>
      | Omit<Extract<SocialWorkerRequest, { type: 'social:querySocialGraphBadges' }>, 'requestId'>,
    signal?: AbortSignal,
  ): Promise<Extract<SocialWorkerResponse, { type: 'social:profileSocialSnapshot' | 'social:socialGraphBadges' }>> {
    if (signal?.aborted) {throw abortError();}
    const requestId = generateRequestId();
    const queue = createResponseQueue(this.client, requestId, this.responseTimeoutMs, signal);
    let complete = false;
    try {
      await this.client.postExtensionMessage({ ...request, requestId } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:profileSocialSnapshot' || message.type === 'social:socialGraphBadges') {
          complete = true;
          return message;
        }
        if (message.type === 'social:error') {throw new Error(message.error);}
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel', requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async observeSocialGraphEvents(
    events: readonly RawEvent[],
    signal?: AbortSignal,
  ): Promise<number> {
    if (signal?.aborted) {
      throw abortError();
    }
    if (!isBoundedSocialGraphObservationBatch(events)) {
      throw new RangeError('Invalid social graph observation batch');
    }
    const requestId = generateRequestId();
    const queue = createResponseQueue(this.client, requestId, this.responseTimeoutMs, signal);
    let complete = false;
    try {
      await this.client.postExtensionMessage({
        type: 'social:observeSocialGraphEvents',
        requestId,
        events: [...events],
      } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:socialGraphEventsObserved') {
          complete = true;
          return message.observed;
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async queryHashtreeEvents(
    roots: SocialWorkerHashtreeRoot[],
    filters: NostrFilter[],
    options: HashtreeQueryWorkerOptions,
  ): Promise<{ events: RawEvent[]; complete: boolean }> {
    if (options.signal?.aborted) {
      throw abortError();
    }
    const requestId = generateRequestId();
    const queue = createResponseQueue(
      this.client,
      requestId,
      this.responseTimeoutMs,
      options.signal,
    );
    const now = Date.now();
    const deadline = Math.min(
      options.deadline ?? now + DEFAULT_HASHTREE_QUERY_WINDOW_MS,
      now + MAX_HASHTREE_QUERY_WINDOW_MS,
    );
    let complete = false;
    try {
      await this.client.postExtensionMessage({
        type: 'social:queryHashtreeEvents',
        requestId,
        roots,
        filters,
        limit: options.limit,
        deadline,
      } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:hashtreeQueryResult') {
          complete = true;
          return {
            events: message.events,
            complete: message.complete,
          };
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async queryRelayEvents(
    relays: string[],
    filters: NostrFilter[],
    options: RelayQueryWorkerOptions,
  ): Promise<{ events: RawEvent[]; complete: boolean }> {
    if (options.signal?.aborted) {
      throw abortError();
    }
    const requestId = generateRequestId();
    const queue = createResponseQueue(
      this.client,
      requestId,
      this.responseTimeoutMs,
      options.signal,
    );
    const now = Date.now();
    const deadline = Math.min(
      options.deadline ?? now + DEFAULT_RELAY_QUERY_WINDOW_MS,
      now + MAX_RELAY_QUERY_WINDOW_MS,
    );
    let complete = false;
    try {
      await this.client.postExtensionMessage({
        type: 'social:queryRelays',
        requestId,
        relays,
        filters,
        limit: options.limit,
        deadline,
      } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:relayQueryResult') {
          complete = true;
          return {
            events: message.events,
            complete: message.complete,
          };
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  async publishRelayEvent(
    relays: string[],
    event: RawEvent,
    signal?: AbortSignal,
  ): Promise<void> {
    if (signal?.aborted) {
      throw abortError();
    }
    const requestId = generateRequestId();
    const queue = createResponseQueue(this.client, requestId, this.responseTimeoutMs, signal);
    let complete = false;
    try {
      await this.client.postExtensionMessage({
        type: 'social:publishRelayEvent',
        requestId,
        relays: [...relays],
        event: cloneRawEvent(event),
      } satisfies SocialWorkerRequest);
      while (true) {
        const message = await queue.next();
        if (message.type === 'social:relayEventPublished') {
          complete = true;
          return;
        }
        if (message.type === 'social:error') {
          throw new Error(message.error);
        }
      }
    } finally {
      queue.close();
      if (!complete && !queue.workerFailed()) {
        void this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest).catch(() => undefined);
      }
    }
  }

  subscribeRelayEvents(
    relays: string[],
    filters: NostrFilter[],
    handlers: RelaySubscriptionWorkerHandlers,
    options: RelaySubscriptionWorkerOptions = {},
  ): { close(reason?: string): void } {
    const requestId = generateRequestId();
    let closed = false;
    let requestPosted: Promise<void> | null = null;
    let unsubscribe = (): void => undefined;
    let unsubscribeError = (): void => undefined;
    const cleanup = (): void => {
      unsubscribe();
      unsubscribeError();
    };
    const cancelWorker = (): void => {
      void (requestPosted ?? Promise.resolve()).then(() => (
        this.client.postExtensionMessage({
          type: 'social:cancel',
          requestId,
        } satisfies SocialWorkerRequest)
      )).catch(() => undefined);
    };
    const finish = (reasons: readonly string[], cancel: boolean): void => {
      if (closed) {
        return;
      }
      closed = true;
      cleanup();
      if (cancel) {
        cancelWorker();
      }
      handlers.onClose?.(reasons);
    };
    unsubscribe = this.client.onExtensionMessage((message) => {
      if (
        closed
        || !isSocialWorkerResponse(message)
        || message.requestId !== requestId
      ) {
        return;
      }
      if (message.type === 'social:relayEvent') {
        try {
          handlers.onEvent(message.event);
        } catch (error) {
          finish([errorMessage(error)], true);
        }
        return;
      }
      if (message.type === 'social:relaySubscriptionClosed') {
        finish(message.reasons, false);
        return;
      }
      if (message.type === 'social:error') {
        finish([message.error], false);
      }
    });
    unsubscribeError = this.client.onExtensionError((error) => {
      finish([error.message], false);
    });
    if (closed) {
      cleanup();
      return { close: () => undefined };
    }

    requestPosted = this.client.postExtensionMessage({
      type: 'social:subscribeRelays',
      requestId,
      relays,
      filters,
      closeOnEose: options.closeOnEose === true,
    } satisfies SocialWorkerRequest);
    void requestPosted.catch((error: unknown) => {
      finish([errorMessage(error)], false);
    });

    return {
      close(reason?: string) {
        finish(reason === undefined ? [] : [reason], true);
      },
    };
  }
}

function cloneRawEvent(event: RawEvent): RawEvent {
  return {
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
