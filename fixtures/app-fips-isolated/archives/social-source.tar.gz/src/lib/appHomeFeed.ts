import type { FeedSnapshot } from './nostrIndex';
import type { ProfileRecord } from './nostr';
import { getFeedProfilePubkeys } from './nostrIndex';
import { mergeProfileMaps } from './profileRecords';

export function hasMoreHomeFeedNotes(options: {
  visibleNoteCount: number;
  durableNoteCount: number;
  visibleLimit: number;
  fetchLimit: number;
}): boolean {
  return options.visibleNoteCount > options.visibleLimit
    || (
      options.fetchLimit > options.visibleLimit
      && options.durableNoteCount >= options.fetchLimit
    );
}

export function buildHomeFeedSnapshot(
  nextFeed: FeedSnapshot,
  viewerPubkey: string,
  cachedProfiles: Map<string, ProfileRecord>,
): {
  feed: FeedSnapshot;
  feedProfilePubkeys: string[];
} {
  const feedProfilePubkeys = getFeedProfilePubkeys(viewerPubkey, nextFeed.feedOwnerPubkey, nextFeed.notes);
  return {
    feedProfilePubkeys,
    feed: {
      ...nextFeed,
      profiles: mergeProfileMaps(nextFeed.profiles, cachedProfiles),
    },
  };
}
