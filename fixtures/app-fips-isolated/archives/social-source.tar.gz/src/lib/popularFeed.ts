import type { CID } from '@hashtree/core';
import { INITIAL_FEED_LIMIT } from './config';
import { queryBrowserAllEvents } from './browserEventReadRouter';
import { readEventsByIds, readRecentInteractions } from './homeFeedReads';
import { isReplyEvent, type RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { getRootNhash } from './nostrIndexRoots';
import type { FeedSnapshot } from './nostrIndexTypes';
import { loadSocialGraphFrontier } from './socialGraphFrontier';
import { socialDataPlane } from './socialDataPlane';

const SIGNAL_LIMIT = 192;
const TARGET_LIMIT = 64;
const DAY = 86_400;

/** A reaction and a repost by the same person are one vote for the original. */
function popularTargetIds(signals: readonly RawEvent[], authors: readonly string[], since: number, now: number): string[] {
  const allowed = new Set(authors);
  const votes = new Map<string, { actors: Set<string>; last: number }>();
  for (const event of signals) {
    if (!allowed.has(event.pubkey) || (event.kind !== 6 && event.kind !== 7)
      || event.created_at < since || event.created_at > now + 60) { continue; }
    const id = getLastValidLowercaseEventTarget(event);
    if (!id) { continue; }
    const vote = votes.get(id) ?? { actors: new Set<string>(), last: 0 };
    vote.actors.add(event.pubkey);
    vote.last = Math.max(vote.last, event.created_at);
    votes.set(id, vote);
  }
  return [...votes].sort(([a, left], [b, right]) => right.actors.size - left.actors.size
    || right.last - left.last || a.localeCompare(b)).slice(0, TARGET_LIMIT).map(([id]) => id);
}

function isPopularPost(event: RawEvent): boolean {
  return [1, 20, 30_023].includes(event.kind) && !(event.kind === 1 && isReplyEvent(event));
}

export async function loadGuestPopularFeed(
  root: CID,
  onProgress?: (snapshot: FeedSnapshot) => void,
): Promise<FeedSnapshot> {
  const authors = await loadSocialGraphFrontier();
  const now = Math.floor(Date.now() / 1000);
  const recent = now - 2 * DAY;
  const filter = { authors, kinds: [6, 7], since: 0, limit: SIGNAL_LIMIT };
  const signals = new Map((authors.length ? socialDataPlane.query(filter) : []).map(event => [event.id, event]));
  const targets = new Map<string, RawEvent>();
  const requested = new Set<string>();
  let ids: string[] = [];
  let visibleSignals: RawEvent[] = [];
  let published = '';
  let pendingTargets: Promise<void> | undefined;

  const snapshot = (): FeedSnapshot => {
    const notes = ids.flatMap(id => {
      const event = targets.get(id);
      return event && isPopularPost(event) ? [event] : [];
    });
    const visible = new Set(socialDataPlane.filterVisibleExternalEvents(notes).map(note => note.id));
    return {
      rootNhash: getRootNhash(root), feedOwnerPubkey: 'popular', usedSuggestedFeed: true,
      starterMode: 'social-graph-snapshot', follows: [], followCount: 0,
      notes: notes.filter(note => visible.has(note.id)), profiles: new Map(),
      rankingEngagementEvents: visibleSignals, continuation: null,
    };
  };
  const publish = () => {
    if (!onProgress) { return; }
    const page = snapshot();
    const order = page.notes.map(note => note.id).join(',');
    if (order && order !== published) { published = order; onProgress(page); }
  };
  const receiveTargets = (events: readonly RawEvent[]) => {
    for (const event of events) { targets.set(event.id, event); }
    publish();
  };
  const readMissingTargets = () => {
    if (pendingTargets) { return; }
    const missing = ids.filter(id => !targets.has(id) && !requested.has(id));
    if (!missing.length) { return; }
    for (const id of missing) { requested.add(id); }
    pendingTargets = readEventsByIds(missing, AbortSignal.timeout(5500),
      (filters, options) => queryBrowserAllEvents([root], filters, options, receiveTargets))
      .then(receiveTargets, () => undefined)
      .finally(() => { pendingTargets = undefined; readMissingTargets(); });
  };
  const receiveSignals = (events: readonly RawEvent[]) => {
    for (const event of events) { signals.set(event.id, event); }
    visibleSignals = socialDataPlane.filterVisibleExternalEvents([...signals.values()]);
    ids = popularTargetIds(visibleSignals, authors, recent, now);
    if (ids.length < INITIAL_FEED_LIMIT) { ids = popularTargetIds(visibleSignals, authors, recent - DAY, now); }
    if (!ids.length && visibleSignals.length) {
      const newest = Math.max(0, ...visibleSignals.filter(event => event.created_at <= now).map(event => event.created_at));
      ids = popularTargetIds(visibleSignals, authors, newest - 2 * DAY, now);
    }
    for (const id of ids) {
      const local = socialDataPlane.getEvent(id);
      if (local) { targets.set(id, local); }
    }
    publish();
    readMissingTargets();
  };
  receiveSignals([]);
  if (authors.length) {
    const result = await readRecentInteractions(authors, AbortSignal.timeout(5500),
      (filters, options) => queryBrowserAllEvents([root], filters, options, receiveSignals), 0).catch(() => []);
    receiveSignals(result);
  }
  while (pendingTargets) { await pendingTargets; }
  return snapshot();
}
