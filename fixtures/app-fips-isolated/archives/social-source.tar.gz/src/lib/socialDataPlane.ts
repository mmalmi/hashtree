import {
  verifyNostrEvent,
  type NostrFilter,
  type NostrVerifiedEvent,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import {
  buildScopedLiveFilters,
  cloneRawEvent,
  normalizeReconnectDelays,
  PERSISTED_DATA_PLANE_STATE_VERSION,
  rememberSnapshotEventIds,
  type PersistedSocialDataPlaneState,
  type SocialLiveScope,
} from './socialDataPlaneSupport';
import { SocialDataPlaneRestoration } from './socialDataPlaneRestoration';
import { observeSocialGraphEvent as observeDefaultSocialGraphEvent } from './socialGraph';
import { DetachedLivePublisher } from './detachedLivePublisher';
import { SocialOutboxDelivery } from './socialOutboxDelivery';
import {
  connectDefaultLiveTransport,
  getBrowserOnlineTarget,
  getBrowserStorage,
  getBrowserStorageEventTarget,
  hasConfiguredLivePeers,
} from './socialDataPlaneDefaults';
import {
  SocialPersistenceError,
  type LiveTextNoteOptions,
  type SocialDataPlaneChange,
  type SocialDataPlaneOptions,
  type SocialLiveTransport,
} from './socialDataPlaneTypes';
import {
  SocialEventRepository,
  type SocialEventFilter,
  type SocialEventStatus,
  type SocialEventTombstone,
  type SocialRepositorySnapshot,
} from './socialRepository';
import { SocialOutboxJournalCoordinator, type SocialOutboxEntry, type SocialOutboxObligations } from './socialOutboxJournal';
import { SocialOverlayPersistence } from './socialOverlayPersistence';
import { prepareSocialOverlayState } from './socialOverlayStatePreparation';
import { commitSocialEventBatch, enforceSocialOverlayBound, forEachLiveEventBatch, notifySocialEventBatch } from './socialDataPlaneBatch';
import { projectLiveTextNotes, projectLiveThreadReplies, projectRankedTextNotes } from './socialDataPlaneProjections';

export { SOCIAL_OVERLAY_STORAGE_KEY } from './socialOverlayPersistence';
export const DEFAULT_SOCIAL_OVERLAY_LIMIT = 2_048;
const LIVE_PERSIST_DEBOUNCE_MS = 75;
const LIVE_REPLAY_WINDOW_SECONDS = 6 * 60 * 60;
const ENGAGEMENT_REPLAY_WINDOW_SECONDS = 48 * 60 * 60;
const MAX_REMEMBERED_SNAPSHOT_IDS = 8_192;

export { buildScopedLiveFilters } from './socialDataPlaneSupport';
export type { SocialLiveScope } from './socialDataPlaneSupport';
export { SocialPersistenceError } from './socialDataPlaneTypes';
export type {
  LiveTextNoteOptions,
  SocialDataPlaneChange,
  SocialDataPlaneOptions,
  SocialLiveTransport,
} from './socialDataPlaneTypes';

type LiveSubscription = { close(): void };

export class SocialDataPlane extends SocialOutboxDelivery {
  private readonly repository: SocialEventRepository;
  private readonly storage: Storage | null;
  private readonly outboxJournal: SocialOutboxJournalCoordinator;
  private readonly overlayPersistence: SocialOverlayPersistence;
  private readonly restoration: SocialDataPlaneRestoration;
  private readonly deferOverlayRestore: boolean;
  private readonly maxOverlayEvents: number;
  private readonly connectLive: () => Promise<SocialLiveTransport | null>;
  private readonly observeSocialGraphEvent: (event: RawEvent) => void;
  private readonly reconnectDelaysMs: readonly number[];
  private readonly liveReplaySince: number;
  private readonly engagementReplaySince: number;
  private readonly shouldConnectLive: () => boolean;
  private readonly onPersistenceError: (error: SocialPersistenceError) => void;
  private readonly listeners = new Set<(change: SocialDataPlaneChange) => void>();
  private readonly livePublisher = new DetachedLivePublisher();
  private readonly snapshotEventIds = new Set<string>();
  private liveTransport: SocialLiveTransport | null = null;
  private liveSubscription: LiveSubscription | null = null;
  private liveFilters: NostrFilter[] = [];
  private liveFiltersKey = '[]';
  private startPromise: Promise<boolean> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private lastPersistenceError: SocialPersistenceError | null = null;
  private reconnectAttempt = 0;
  private running = false;
  private outboxJournalStarted = false;
  private lifecycle = 0;

  constructor(options: SocialDataPlaneOptions = {}) {
    super({
      onlineTarget: options.onlineTarget === undefined ? getBrowserOnlineTarget() : options.onlineTarget,
      outboxRetryDelaysMs: options.outboxRetryDelaysMs,
      personalIndexRetryDelaysMs: options.personalIndexRetryDelaysMs,
      publishToRelays: options.publishToRelays,
      publishToPersonalIndex: options.publishToPersonalIndex,
    });
    this.storage = options.storage === undefined ? getBrowserStorage() : options.storage;
    this.repository = new SocialEventRepository();
    this.deferOverlayRestore = options.deferOverlayRestore === true;
    this.maxOverlayEvents = Math.max(1, Math.trunc(options.maxOverlayEvents ?? DEFAULT_SOCIAL_OVERLAY_LIMIT));
    this.connectLive = options.connectLive ?? connectDefaultLiveTransport;
    this.shouldConnectLive = options.shouldConnectLive
      ?? (options.connectLive ? () => true : hasConfiguredLivePeers);
    this.observeSocialGraphEvent = options.observeSocialGraphEvent ?? observeDefaultSocialGraphEvent;
    this.onPersistenceError = options.onPersistenceError ?? ((error) => {
      console.error(error.message, error.cause);
    });
    this.reconnectDelaysMs = normalizeReconnectDelays(options.reconnectDelaysMs);
    const nowSeconds = Math.floor(Date.now() / 1_000);
    this.liveReplaySince = Math.max(
      0,
      nowSeconds - LIVE_REPLAY_WINDOW_SECONDS,
    );
    this.engagementReplaySince = Math.max(
      0,
      nowSeconds - ENGAGEMENT_REPLAY_WINDOW_SECONDS,
    );
    this.outboxJournal = new SocialOutboxJournalCoordinator({
      storage: this.storage,
      storageEventTarget: options.storageEventTarget === undefined
        ? getBrowserStorageEventTarget()
        : options.storageEventTarget,
      getPendingEvents: () => [...new Set([
        ...this.allPendingOutboxEventIds,
      ])]
        .map((eventId) => this.repository.getStoredEvent(eventId))
        .filter((event): event is RawEvent => Boolean(event)),
      onQueued: (entry) => this.ingestJournalEntry(entry),
      onRemoved: (eventId) => this.acknowledgeJournalRemoval(eventId),
      onError: (error) => this.recordPersistenceError(error),
    });
    this.overlayPersistence = new SocialOverlayPersistence({
      storage: this.storage,
      debounceMs: Math.max(0, Math.trunc(
        options.persistDebounceMs ?? LIVE_PERSIST_DEBOUNCE_MS,
      )),
      getState: () => this.persistedState(),
      prepareState: async (context) => await prepareSocialOverlayState({
        repository: this.repository,
        isProtectedEventId: (eventId) => this.hasPendingOutboxObligation(eventId),
        pendingDeliveryEventIds: this.relayPendingEventIds,
        context,
      }),
      onError: (error) => this.recordPersistenceError(error),
      onSuccess: () => { this.lastPersistenceError = null; },
    });
    this.restoration = new SocialDataPlaneRestoration({
      repository: this.repository,
      outboxJournal: this.outboxJournal,
      overlayPersistence: this.overlayPersistence,
      applyJournalObligations: (entry) => this.applyJournalObligations(entry),
      enforceOverlayBound: () => this.enforceOverlayBound(),
    });
    if (!this.deferOverlayRestore) {
      this.restoration.restoreSynchronously();
    }
  }

  get overlaySize(): number { return this.repository.getOverlayEvents().length; }

  get connected(): boolean { return this.liveTransport !== null; }

  get persistenceError(): SocialPersistenceError | null { return this.lastPersistenceError; }

  get version(): number { return this.repository.version; }

  readPersistedMetadata(pubkeys: readonly string[]): RawEvent[] {
    return pubkeys.length > 0 ? this.overlayPersistence.readMetadataEvents(new Set(pubkeys)) : [];
  }

  async readPersistedMetadataAsync(
    pubkeys: readonly string[],
    signal?: AbortSignal,
  ): Promise<RawEvent[]> {
    if (pubkeys.length === 0) { return []; }
    return await this.overlayPersistence.readMetadataEventsAsync(new Set(pubkeys), { signal });
  }

  async start(): Promise<boolean> {
    this.running = true;
    const lifecycle = this.lifecycle;
    const restorationWasComplete = this.restoration.complete;
    // Listen before taking the async journal snapshot. Any cross-tab changes
    // during worker verification are then reconciled by the coordinator.
    const journalWasStarted = this.outboxJournalStarted;
    if (!journalWasStarted) {
      this.outboxJournal.start();
      this.outboxJournalStarted = true;
    }
    if (this.deferOverlayRestore && !restorationWasComplete) {
      const restoredEvents = await this.restoration.restoreAfterPaint(
        () => this.running && lifecycle === this.lifecycle,
      );
      if (restoredEvents.length > 0) {
        this.notifyEvents(
          restoredEvents,
          'restore',
          restoredEvents.map(() => null),
        );
      }
      if (!this.running || lifecycle !== this.lifecycle) {
        return false;
      }
    }
    // The first deferred restoration already scanned the complete journal.
    // Non-deferred construction and later restarts still need synchronization
    // for changes that happened before the listener was attached.
    if (!journalWasStarted && (!this.deferOverlayRestore || restorationWasComplete)) {
      this.outboxJournal.synchronize();
    }
    this.startOutboxDelivery();
    if (!this.shouldConnectLive()) {
      this.clearReconnectTimer();
      this.resumeBackgroundWork();
      return false;
    }
    if (this.liveTransport) { return true; }
    if (this.startPromise) { return await this.startPromise; }

    this.clearReconnectTimer();
    const started = (async () => {
      try {
        const liveTransport = await this.connectLive();
        if (!liveTransport || lifecycle !== this.lifecycle || !this.running) {
          this.resumeBackgroundWork(lifecycle);
          return false;
        }
        this.liveTransport = liveTransport;
        try {
          this.replaceLiveSubscription();
        } catch (error) {
          this.liveTransport = null;
          throw error;
        }
        this.reconnectAttempt = 0;
        this.publishPendingLiveBestEffort();
        this.resumeBackgroundWork(lifecycle);
        return true;
      } catch (error) {
        this.resumeBackgroundWork(lifecycle);
        throw error;
      }
    })();
    const pending = started.finally(() => {
      if (this.startPromise === pending) {
        this.startPromise = null;
      }
    });
    this.startPromise = pending;
    return await pending;
  }

  setLiveScope(scope: SocialLiveScope): void {
    const filters = buildScopedLiveFilters(
      scope,
      this.liveReplaySince,
      this.engagementReplaySince,
    );
    const nextKey = JSON.stringify(filters);
    if (nextKey === this.liveFiltersKey) {
      return;
    }
    this.liveFilters = filters;
    this.liveFiltersKey = nextKey;
    if (this.liveTransport) {
      this.replaceLiveSubscription();
    }
  }

  stop(): void {
    this.running = false;
    this.lifecycle += 1;
    this.restoration.cancel();
    this.clearReconnectTimer();
    this.stopOutboxDelivery();
    this.outboxJournal.stop();
    this.outboxJournalStarted = false;
    this.liveSubscription?.close();
    this.liveSubscription = null;
    this.liveTransport = null;
    this.startPromise = null;
    if (this.restoration.complete) {
      this.overlayPersistence.flush();
    }
  }

  private replaceLiveSubscription(): void {
    const transport = this.liveTransport;
    if (!transport) {
      return;
    }
    if (this.liveFilters.length === 0) {
      this.liveSubscription?.close();
      this.liveSubscription = null;
      return;
    }

    const previous = this.liveSubscription;
    const next = transport.subscribeBatch
      ? transport.subscribeBatch(
          this.liveFilters,
          (events, sourcePeers) => this.ingestLiveEvents(events, sourcePeers),
        )
      : transport.subscribe(
          this.liveFilters,
          (event, sourcePeer) => this.ingestLiveEvents([event], [sourcePeer]),
        );
    if (!this.running) {
      next.close();
      return;
    }
    this.liveSubscription = next;
    previous?.close();
  }

  private scheduleReconnect(): void {
    if (!this.running || !this.shouldConnectLive() || this.liveTransport || this.reconnectTimer) {
      return;
    }
    const delayIndex = Math.min(this.reconnectAttempt, this.reconnectDelaysMs.length - 1);
    const delayMs = this.reconnectDelaysMs[delayIndex] ?? 0;
    this.reconnectAttempt += 1;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.start().catch(() => undefined);
    }, delayMs);
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  subscribe(listener: (change: SocialDataPlaneChange) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  query(filter: SocialEventFilter = {}): RawEvent[] { return this.repository.getEvents(filter); }

  getEvent(eventId: string): RawEvent | null { return this.repository.getEvent(eventId); }

  getStoredEvent(eventId: string): RawEvent | null { return this.repository.getStoredEvent(eventId); }

  protected getStoredOutboxEvent(eventId: string): RawEvent | null {
    return this.repository.getStoredEvent(eventId);
  }

  getEventStatus(eventId: string): SocialEventStatus | null {
    return this.repository.getEventStatus(eventId);
  }

  getSnapshot(): SocialRepositorySnapshot { return this.repository.getSnapshot(); }

  getTombstones(): SocialEventTombstone[] {
    return this.repository.getTombstones();
  }

  mergeSnapshot(snapshotEvents: RawEvent[], filter: SocialEventFilter = {}): RawEvent[] {
    this.rememberSnapshotEvents(snapshotEvents);
    return this.projectSnapshot(snapshotEvents, filter);
  }

  projectSnapshot(snapshotEvents: RawEvent[], filter: SocialEventFilter = {}): RawEvent[] {
    const merged = new SocialEventRepository({ snapshotEvents: [...snapshotEvents, ...this.repository.getOverlayEvents()] });
    return merged.getEvents(filter);
  }

  /** Apply overlay visibility to external cached events without cloning them. */
  filterVisibleExternalEvents(events: readonly RawEvent[], filter: SocialEventFilter = {}): RawEvent[] {
    return this.repository.filterVisibleExternalEvents(events, filter);
  }

  isExternalEventVisible(event: RawEvent): boolean { return this.repository.isExternalEventVisible(event); }

  getLiveTextNotes(snapshotEvents: RawEvent[], options: LiveTextNoteOptions): RawEvent[] {
    return projectLiveTextNotes(
      snapshotEvents,
      options,
      (events, filter) => this.mergeSnapshot(events, filter),
    );
  }

  getRankedTextNotes(snapshotEvents: RawEvent[], options: LiveTextNoteOptions): RawEvent[] {
    return projectRankedTextNotes(
      snapshotEvents,
      options,
      (events, filter) => this.mergeSnapshot(events, filter),
    );
  }

  getLiveThreadReplies(
    snapshotReplies: RawEvent[],
    threadEvents: RawEvent[],
    limit: number,
  ): RawEvent[] {
    return projectLiveThreadReplies(
      snapshotReplies,
      threadEvents,
      limit,
      (events, filter) => this.mergeSnapshot(events, filter),
    );
  }

  ingestLocalEvent(event: RawEvent): void {
    this.queueLocalEvent(event, { relay: true, personalIndex: false });
  }

  /** Persist a bounded event admitted by a trusted verification boundary. */
  ingestVerifiedRelayEvent(event: NostrVerifiedEvent, sourceRelay: string): void {
    this.ingestVerifiedRelayEvents([event], sourceRelay);
  }

  /** Persist a verified relay batch with one repository projection rebuild. */
  ingestVerifiedRelayEvents(events: readonly NostrVerifiedEvent[], sourceRelay: string): void {
    const verifiedEvents = events.map((event) => cloneRawEvent(verifyNostrEvent(event)));
    this.ingestBatch(
      verifiedEvents,
      'relay',
      verifiedEvents.map(() => sourceRelay),
    );
  }

  publishInBackground(
    event: RawEvent,
    publishToRelays: () => Promise<void>,
    publishToPersonalIndex: (() => Promise<void>) | null = null,
  ): void {
    this.queueLocalEvent(event, {
      relay: true,
      personalIndex: publishToPersonalIndex !== null,
    });
    // FIPS is an immediate live fanout, not durable discovery. Only a relay
    // acknowledgement may clear the relay obligation in the persisted outbox.
    this.publishQueuedObligations(event, publishToRelays, publishToPersonalIndex);
    this.publishLiveBestEffort(event, true);
  }

  private resumeBackgroundWork(lifecycle = this.lifecycle): void {
    if (lifecycle !== this.lifecycle || !this.running) { return; }
    this.resumeOutboxBackgroundWork();
    if (this.shouldConnectLive()) { this.scheduleReconnect(); }
  }

  private ingestLiveEvents(
    events: readonly NostrVerifiedEvent[],
    sourcePeers: readonly string[],
  ): void {
    forEachLiveEventBatch(events, sourcePeers, (batch, sources) => {
      this.ingestBatch(batch, 'live', sources);
    });
  }

  private ingestBatch(
    events: readonly RawEvent[],
    origin: SocialDataPlaneChange['origin'],
    sourcePeers: readonly (string | null)[],
  ): void {
    const committed = commitSocialEventBatch({
      repository: this.repository,
      events,
      sourcePeers,
      maxOverlayEvents: this.maxOverlayEvents,
      protectedEventIds: this.allPendingOutboxEventIds,
    });
    if (!committed) {
      return;
    }
    this.overlayPersistence.schedule();
    this.notifyEvents(committed.events, origin, committed.sourcePeers);
  }

  private queueLocalEvent(event: RawEvent, obligations: SocialOutboxObligations): void {
    const eventId = event.id.toLowerCase();
    const wasStored = this.repository.getStoredEvent(eventId) !== null;
    const mutation = this.repository.ingestEvent(event);

    try {
      // Each signed event has its own atomic record. This is the synchronous
      // durability boundary: no relay, FIPS, or personal-index work starts
      // before all requested obligations are represented in one record.
      const entry = this.outboxJournal.persist(event, obligations);
      this.applyJournalObligations(entry);
      this.enforceOverlayBound();
      this.lastPersistenceError = null;
    } catch (error) {
      if (!wasStored) {
        this.repository.removeOverlayEvents([eventId]);
      }
      throw error;
    }
    // The overlay blob remains a bounded display cache and compatibility
    // mirror. The per-event journal above is the durable outbox authority.
    this.overlayPersistence.persistBestEffort();

    if (mutation.changed) {
      this.notifyEvent(event, 'local', null);
    }
  }

  private notifyEvent(
    event: RawEvent,
    origin: SocialDataPlaneChange['origin'],
    sourcePeer: string | null,
  ): void {
    this.notifyEvents([event], origin, [sourcePeer]);
  }

  private notifyEvents(
    events: readonly RawEvent[],
    origin: SocialDataPlaneChange['origin'],
    sourcePeers: readonly (string | null)[],
  ): void {
    notifySocialEventBatch({
      events,
      origin,
      sourcePeers,
      version: this.repository.version,
      observe: this.observeSocialGraphEvent,
      listeners: this.listeners,
    });
  }

  private publishLiveBestEffort(event: RawEvent, allowLiveConnect: boolean): void {
    this.livePublisher.publish(
      event,
      async () => this.liveTransport
        ?? (allowLiveConnect && this.shouldConnectLive() ? await this.getLiveTransport() : null),
      () => {
        if (this.running && this.shouldConnectLive()) {
          this.scheduleReconnect();
        }
      },
    );
  }

  private publishPendingLiveBestEffort(): void {
    for (const eventId of this.relayPendingEventIds) {
      const event = this.repository.getStoredEvent(eventId);
      if (event) {
        this.publishLiveBestEffort(event, false);
      }
    }
  }

  protected completeOutboxObligation(
    eventId: string,
    obligation: keyof SocialOutboxObligations,
  ): boolean {
    try {
      // Concurrent tabs can only leave a safe extra obligation behind: each
      // acknowledgement clears one flag, and the record disappears only when
      // a writer observes that both flags are clear.
      const remaining = this.outboxJournal.acknowledge(eventId, obligation);
      if (remaining) {
        this.applyJournalObligations(remaining);
      } else {
        this.removeJournalObligations(eventId);
      }
      this.lastPersistenceError = null;
    } catch {
      return false;
    }
    this.pruneCompletedSnapshotEvent(eventId);
    this.overlayPersistence.persistBestEffort();
    return true;
  }

  private pruneCompletedSnapshotEvent(eventId: string): void {
    if (
      this.snapshotEventIds.has(eventId)
      && !this.hasPendingOutboxObligation(eventId)
    ) {
      this.repository.removeOverlayEvents([eventId]);
    }
  }

  private async getLiveTransport(): Promise<SocialLiveTransport | null> {
    if (this.liveTransport) {
      return this.liveTransport;
    }
    await this.start();
    return this.liveTransport;
  }

  private enforceOverlayBound(): boolean {
    return enforceSocialOverlayBound({
      repository: this.repository,
      maxOverlayEvents: this.maxOverlayEvents,
      protectedEventIds: this.allPendingOutboxEventIds,
    });
  }

  private rememberSnapshotEvents(snapshotEvents: RawEvent[]): void {
    const deliveredSnapshotIds = rememberSnapshotEventIds(
      this.snapshotEventIds,
      snapshotEvents,
      this.allPendingOutboxEventIds,
      MAX_REMEMBERED_SNAPSHOT_IDS,
    );
    if (
      deliveredSnapshotIds.length > 0
      && this.repository.removeOverlayEvents(deliveredSnapshotIds).changed
    ) {
      this.overlayPersistence.persistBestEffort();
    }
  }

  private ingestJournalEntry(entry: SocialOutboxEntry): void {
    const event = entry.event;
    const eventId = event.id.toLowerCase();
    const wasRelayPending = this.isPendingDelivery(eventId);
    const wasPersonalIndexPending = this.isPendingPersonalIndex(eventId);
    const mutation = this.repository.ingestEvent(event);
    this.applyJournalObligations(entry);
    this.enforceOverlayBound();
    this.overlayPersistence.persistBestEffort();
    if (mutation.changed) {
      this.notifyEvent(event, 'local', null);
    }
    if (this.running && !wasRelayPending && entry.obligations.relay) {
      this.publishLiveBestEffort(event, false);
    }
    this.scheduleJournalEntryRetries(entry, wasRelayPending, wasPersonalIndexPending);
  }

  private acknowledgeJournalRemoval(eventId: string): void {
    if (!this.removeJournalObligations(eventId)) { return; }
    this.pruneCompletedSnapshotEvent(eventId);
    this.overlayPersistence.persistBestEffort();
  }

  private persistedState(): PersistedSocialDataPlaneState {
    const repositoryState = this.repository.exportOverlayState({
      protectedEventIds: new Set([
        ...this.allPendingOutboxEventIds,
      ]),
    });
    const overlayIds = new Set(repositoryState.overlayEvents.map((event) => event.id));
    return {
      schemaVersion: PERSISTED_DATA_PLANE_STATE_VERSION,
      overlayEvents: repositoryState.overlayEvents,
      pendingDeliveryEventIds: [...this.relayPendingEventIds]
        .filter((eventId) => overlayIds.has(eventId))
        .sort(),
    };
  }

  private recordPersistenceError(error: SocialPersistenceError): void {
    this.lastPersistenceError = error;
    this.onPersistenceError(error);
  }
}

export const socialDataPlane = new SocialDataPlane({ deferOverlayRestore: true });
