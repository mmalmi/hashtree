import type { CID } from '@hashtree/core';
import type { RawEvent } from './nostr';
import { selectNewestViewerContactsEvent } from './homeFeedContacts';

export type ProfileIndexedContactsDeps = {
  getRootNhash: (root: CID) => string;
  loadLatestContactsEvent: (
    roots: CID[],
    pubkey: string,
    signal?: AbortSignal,
  ) => Promise<RawEvent | null>;
  resolvePersonalRoot: (pubkey: string) => Promise<CID | null>;
  signal?: AbortSignal;
};

/**
 * Read a profile's replaceable kind-3 event from the open archive and its
 * optional personal event index. Readers provide signature-verified events;
 * this boundary additionally enforces the requested author/kind coordinate.
 *
 * `onNewerEvent` is called as soon as either immutable source produces a new
 * deterministic winner, so callers do not need to wait for root discovery or
 * the other source before painting follows.
 */
export async function loadProfileIndexedContacts(
  root: CID,
  pubkey: string,
  deps: ProfileIndexedContactsDeps,
  onNewerEvent?: (event: RawEvent) => void,
): Promise<RawEvent | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  const candidates: Array<RawEvent | null> = [];
  let winner: RawEvent | null = null;

  const consider = (event: RawEvent | null): RawEvent | null => {
    candidates.push(event);
    const nextWinner = selectNewestViewerContactsEvent(candidates, normalizedPubkey);
    if (nextWinner && nextWinner.id !== winner?.id) {
      winner = nextWinner;
      onNewerEvent?.(nextWinner);
    }
    return event;
  };

  const globalContactsPromise = deps.loadLatestContactsEvent(
    [root],
    normalizedPubkey,
    deps.signal,
  )
    .then((event) => {
      deps.signal?.throwIfAborted();
      return consider(event);
    })
    .catch((error) => {
      console.warn('Failed to load profile contact list from the open index', error);
      return null;
    });
  const personalContactsPromise = deps.resolvePersonalRoot(normalizedPubkey)
    .then(async (personalRoot) => {
      if (!personalRoot || deps.getRootNhash(personalRoot) === deps.getRootNhash(root)) {
        return null;
      }
      return await deps.loadLatestContactsEvent(
        [personalRoot],
        normalizedPubkey,
        deps.signal,
      );
    })
    .then((event) => {
      deps.signal?.throwIfAborted();
      return consider(event);
    })
    .catch((error) => {
      console.warn('Failed to load profile contact list from the personal index', error);
      return null;
    });

  await Promise.all([globalContactsPromise, personalContactsPromise]);
  return winner;
}
