export type AppDataSourceStartupOptions<T> = {
  startLive: () => Promise<unknown>;
  watchDurableRoot: () => Promise<T>;
  onLiveError: (error: unknown) => void;
};

/**
 * Starts the optional live tail without putting it on the durable snapshot's
 * critical path. The app can render from Hashtree while live peers connect.
 */
export async function startAppDataSources<T>(
  options: AppDataSourceStartupOptions<T>,
): Promise<T> {
  void options.startLive().catch(options.onLiveError);
  return await options.watchDurableRoot();
}
