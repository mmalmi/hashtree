import {
  parseProfileSearchAddress,
  resolveProfileSearchAddress,
  type ProfileSearchAddress,
} from './profileSearchAddress';

/** true: verified, false: the domain names another key or none, null: unknown/unreachable. */
export type Nip05Status = boolean | null;

/** A pubkey the domain names, or '' when the domain answered without one. */
type Resolution = { pubkey: string; checkedAt: number };

const STORAGE_KEY = 'iris:nip05:v1';
const MAX_ENTRIES = 1_000;
const FRESH_MS = 60 * 60 * 1_000;
const LOOKUP_TIMEOUT_MS = 6_000;

let stored: Map<string, Resolution> | null = null;
const pending = new Map<string, Promise<string | null>>();
let persistTimer: ReturnType<typeof setTimeout> | null = null;

function addressKey(address: ProfileSearchAddress): string {
  return `${address.name}@${address.domain}`;
}

function storage(): Storage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage;
  } catch {
    return null;
  }
}

function resolutions(): Map<string, Resolution> {
  if (stored) { return stored; }
  stored = new Map();
  try {
    const raw = JSON.parse(storage()?.getItem(STORAGE_KEY) ?? '[]') as unknown;
    if (Array.isArray(raw)) {
      for (const entry of raw) {
        if (!Array.isArray(entry)) { continue; }
        const [key, pubkey, checkedAt] = entry as unknown[];
        if (typeof key === 'string' && typeof pubkey === 'string' && typeof checkedAt === 'number'
          && (pubkey === '' || /^[0-9a-f]{64}$/.test(pubkey))) {
          stored.set(key, { pubkey, checkedAt });
        }
      }
    }
  } catch {
    // A damaged cache only costs a fresh lookup.
  }
  return stored;
}

function persistSoon(): void {
  if (persistTimer) { return; }
  persistTimer = setTimeout(() => {
    persistTimer = null;
    try {
      storage()?.setItem(STORAGE_KEY, JSON.stringify(
        [...resolutions()].map(([key, value]) => [key, value.pubkey, value.checkedAt]),
      ));
    } catch {
      // Storage may be full or blocked; the in-memory cache still works.
    }
  }, 250);
}

function remember(key: string, pubkey: string): void {
  const cache = resolutions();
  cache.delete(key);
  cache.set(key, { pubkey, checkedAt: Date.now() });
  while (cache.size > MAX_ENTRIES) { cache.delete(cache.keys().next().value!); }
  persistSoon();
}

function isOffline(): boolean {
  return typeof navigator !== 'undefined' && navigator.onLine === false;
}

function lookup(address: ProfileSearchAddress, signal?: AbortSignal): Promise<string | null> {
  const key = addressKey(address);
  let request = pending.get(key);
  if (!request) {
    request = resolveProfileSearchAddress(address, AbortSignal.timeout(LOOKUP_TIMEOUT_MS))
      .then((pubkey) => {
        remember(key, pubkey ?? '');
        return pubkey;
      })
      .finally(() => pending.delete(key));
    pending.set(key, request);
  }
  if (!signal) { return request; }
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason);
    if (signal.aborted) { abort(); return; }
    signal.addEventListener('abort', abort, { once: true });
    request.then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
  });
}

/**
 * Resolve a NIP-05 address to a pubkey. Answers are kept locally, so a known
 * address opens offline; an unreachable domain throws and stays retryable.
 */
export async function resolveNip05Address(
  address: ProfileSearchAddress,
  signal?: AbortSignal,
): Promise<string | null> {
  const cached = resolutions().get(addressKey(address));
  if (cached && (Date.now() - cached.checkedAt < FRESH_MS || isOffline())) {
    return cached.pubkey || null;
  }
  try {
    return await lookup(address, signal);
  } catch (error) {
    if (cached && !signal?.aborted) { return cached.pubkey || null; }
    throw error;
  }
}

function statusFor(resolution: Resolution | undefined, pubkey: string): Nip05Status {
  return resolution ? resolution.pubkey === pubkey : null;
}

/** The last known status without a network request, for a steady first paint. */
export function peekNip05Status(nip05: string, pubkey: string): Nip05Status {
  const address = parseProfileSearchAddress(nip05);
  return address ? statusFor(resolutions().get(addressKey(address)), pubkey) : null;
}

/**
 * Like Iris Client, check a profile's NIP-05 address against its domain so an
 * impersonating claim is shown as unverified. Known answers are reused and
 * refreshed when stale; unreachable domains report null and are retried later.
 */
export async function verifyNip05(nip05: string, pubkey: string): Promise<Nip05Status> {
  const address = parseProfileSearchAddress(nip05);
  if (!address || !/^[0-9a-f]{64}$/.test(pubkey)) { return null; }
  try {
    const resolved = await resolveNip05Address(address);
    return resolved === pubkey;
  } catch {
    return null;
  }
}

/** Iris Client hides the default `_` name: `_@example.com` shows as `example.com`. */
export function displayNip05(nip05: string): string {
  return nip05.startsWith('_@') ? nip05.slice(2) : nip05;
}

/** Test hook: forget every cached answer. */
export function clearNip05Cache(): void {
  stored = new Map();
  pending.clear();
  try { storage()?.removeItem(STORAGE_KEY); } catch { /* ignore */ }
}
