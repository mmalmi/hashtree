import { SimplePool } from 'nostr-tools/pool';
import { finalizeEvent, getPublicKey, verifyEvent, type Event } from 'nostr-tools/pure';
import type { Filter } from 'nostr-tools/filter';
import * as nip04 from 'nostr-tools/nip04';
import * as nip44 from 'nostr-tools/nip44';
import { WalletPaymentError } from './walletTypes';

export type NwcConnection = { walletPubkey: string; relays: string[]; secret: Uint8Array };
export type NwcEncryption = 'nip44_v2' | 'nip04';
export type NwcTransport = {
  info(connection: NwcConnection): Promise<Event | null>;
  subscribe(connection: NwcConnection, filter: Filter, onEvent: (event: Event) => void): () => void;
  publish(connection: NwcConnection, event: Event): Promise<void>;
  close(): void;
};

export function parseNwcConnection(value: string): NwcConnection {
  try {
    if (value.length > 8_192) {throw new Error();}
    const url = new URL(value.trim());
    const walletPubkey = url.hostname.toLowerCase();
    const secretHex = url.searchParams.get('secret') ?? '';
    if (url.protocol !== 'nostr+walletconnect:' || !/^[0-9a-f]{64}$/.test(walletPubkey)
      || !/^[0-9a-fA-F]{64}$/.test(secretHex) || url.username || url.password
      || url.searchParams.getAll('secret').length !== 1) {throw new Error();}
    const secret = Uint8Array.from(secretHex.match(/.{2}/g)!, (byte) => parseInt(byte, 16));
    getPublicKey(secret);
    const relays = [...new Set(url.searchParams.getAll('relay').map((value) => {
      const relay = new URL(value);
      const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(relay.hostname);
      if (relay.username || relay.password || relay.hash || value.length > 2_048
        || (relay.protocol !== 'wss:' && !(loopback && relay.protocol === 'ws:'))) {throw new Error();}
      return relay.toString();
    }))];
    if (relays.length === 0 || relays.length > 4) {throw new Error();}
    return { walletPubkey, secret, relays };
  } catch {
    // URL errors can include the input. Never expose a connection secret in errors.
    throw new Error('Enter a valid Nostr Wallet Connect connection with a secure relay.');
  }
}

export function createNwcRelayTransport(): NwcTransport {
  // Dedicated ephemeral traffic: no social event store, mesh, outbox or reconnect.
  const pool = new SimplePool({ enableReconnect: false, enablePing: false });
  pool.maxWaitForConnection = 5_000;
  return {
    info: (connection) => pool.get(connection.relays, {
      kinds: [13_194], authors: [connection.walletPubkey],
    }, { maxWait: 5_000 }),
    subscribe(connection, filter, onEvent) {
      const subscription = pool.subscribe(connection.relays, filter, { onevent: onEvent });
      return () => subscription.close();
    },
    async publish(connection, event) {
      await Promise.any(pool.publish(connection.relays, event, { maxWait: 10_000 }));
    },
    close: () => pool.destroy(),
  };
}

function singleTag(event: Event, name: string): string | undefined {
  const tags = event.tags.filter((tag) => tag[0] === name);
  return tags.length === 1 ? tags[0]?.[1] : undefined;
}

export class NostrWalletConnect {
  private encryption: NwcEncryption | null = null;
  private methods = new Set<string>();
  constructor(
    private readonly connection: NwcConnection,
    private readonly transport: NwcTransport = createNwcRelayTransport(),
    private readonly timeoutMs = 30_000,
  ) {}

  async connect(): Promise<void> {
    const info = await this.transport.info(this.connection);
    if (!info || info.kind !== 13_194 || info.pubkey !== this.connection.walletPubkey
      || info.content.length > 4_096 || !verifyEvent(info)) {
      throw new Error('Could not verify this wallet. Check the connection and try again.');
    }
    this.methods = new Set(info.content.split(/\s+/));
    if (!this.methods.has('pay_invoice')) {throw new Error('This connection does not allow payments.');}
    const supported = (singleTag(info, 'encryption') ?? 'nip04').split(/\s+/);
    this.encryption = supported.includes('nip44_v2') ? 'nip44_v2' : supported.includes('nip04') ? 'nip04' : null;
    if (!this.encryption) {throw new Error('This wallet uses unsupported encryption.');}
  }

  async request(
    method: 'pay_invoice' | 'get_balance', params: Record<string, unknown>,
    beforeSend?: () => Promise<void>,
  ): Promise<Record<string, unknown>> {
    if (!this.encryption) {await this.connect();}
    if (!this.methods.has(method)) {throw new Error(`Wallet does not support ${method}.`);}
    const encryption = this.encryption!;
    const { secret, walletPubkey } = this.connection;
    const clientPubkey = getPublicKey(secret);
    const conversationKey = encryption === 'nip44_v2' ? nip44.getConversationKey(secret, walletPubkey) : null;
    const plaintext = JSON.stringify({ method, params });
    const content = conversationKey ? nip44.encrypt(plaintext, conversationKey) : nip04.encrypt(secret, walletPubkey, plaintext);
    const request = finalizeEvent({
      kind: 23_194, created_at: Math.floor(Date.now() / 1_000), content,
      tags: [['p', walletPubkey], ['encryption', encryption], ['expiration', String(Math.floor((Date.now() + this.timeoutMs) / 1_000))]],
    }, secret);
    await beforeSend?.();
    return await new Promise<Record<string, unknown>>((resolve, reject) => {
      let settled = false;
      let sent = false;
      let close = () => undefined as void;
      const finish = (result: Record<string, unknown> | null, error?: Error) => {
        if (settled) {return;}
        settled = true;
        clearTimeout(timer);
        close();
        if (error) {reject(error);} else {resolve(result!);}
      };
      const fail = (message: string) => finish(null, new WalletPaymentError(message, method === 'pay_invoice' && sent));
      const timer = setTimeout(() => fail(method === 'pay_invoice'
        ? 'Wallet did not confirm payment. Check your wallet before trying another payment.'
        : 'Wallet did not respond.'), this.timeoutMs);
      try {
        close = this.transport.subscribe(this.connection, {
          kinds: [23_195], authors: [walletPubkey], '#p': [clientPubkey], '#e': [request.id],
        }, (event) => {
          if (settled || event.kind !== 23_195 || event.pubkey !== walletPubkey
            || singleTag(event, 'p') !== clientPubkey || singleTag(event, 'e') !== request.id
            || event.content.length > 65_536 || !verifyEvent(event)) {return;}
          try {
            const response = JSON.parse(conversationKey
              ? nip44.decrypt(event.content, conversationKey)
              : nip04.decrypt(secret, walletPubkey, event.content)) as {
                result_type?: unknown; result?: unknown; error?: { code?: unknown } | null;
              };
            if (response.result_type !== method) {return;}
            if (response.error) {
              // Do not reflect a remote message that could contain sensitive input.
              fail(`Wallet rejected the request${typeof response.error.code === 'string' && /^[A-Z_]{1,40}$/.test(response.error.code) ? ` (${response.error.code})` : ''}.`);
              return;
            }
            if (!response.result || typeof response.result !== 'object' || Array.isArray(response.result)) {return;}
            finish(response.result as Record<string, unknown>);
          } catch {
            // Ignore malformed/unrelated responses until a matching response or timeout.
          }
        });
        sent = true;
        void this.transport.publish(this.connection, request).catch(() => fail(
          method === 'pay_invoice' ? 'Payment delivery is uncertain. Check your wallet before trying another payment.' : 'Could not reach the wallet.',
        ));
      } catch {
        fail('Could not connect to the wallet.');
      }
    });
  }

  close(): void {
    try {this.transport.close();} catch {
      // Socket cleanup must not replace a confirmed or uncertain payment result.
    } finally {this.connection.secret.fill(0);}
  }
}
