/** IndexedDB block store shared by the browser writer and Hashtree data worker. */
export const PERSONAL_EVENT_INDEX_BLOCK_STORE_NAME =
  'iris-social-personal-event-index-blocks';
