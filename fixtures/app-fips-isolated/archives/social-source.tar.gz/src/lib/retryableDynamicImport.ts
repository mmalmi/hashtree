const FAILED_IMPORT_URL_PATTERN = /https?:\/\/[^\s"'<>]+/g;

function failedImportUrl(error: unknown): string | null {
  const message = error instanceof Error ? error.message : String(error);
  const currentOrigin = globalThis.location?.origin;
  if (!currentOrigin) {
    return null;
  }

  for (const match of message.matchAll(FAILED_IMPORT_URL_PATTERN)) {
    try {
      const url = new URL(match[0].replace(/[),.;]+$/, ''));
      if (url.origin === currentOrigin) {
        return url.href;
      }
    } catch {
      // Ignore unrelated text that only resembles a URL.
    }
  }
  return null;
}

export function createRetryableDynamicImport<T>(initialImport: () => Promise<T>): () => Promise<T> {
  let modulePromise: Promise<T> | null = null;
  let retryUrl: string | null = null;
  let retryAttempt = 0;

  return function loadModule(): Promise<T> {
    if (modulePromise) {
      return modulePromise;
    }

    const request = (async () => {
      try {
        if (!retryUrl) {
          return await initialImport();
        }
        const url = new URL(retryUrl);
        url.searchParams.set('iris-import-retry', String(++retryAttempt));
        return await import(/* @vite-ignore */ url.href) as T;
      } catch (error) {
        retryUrl = failedImportUrl(error) ?? retryUrl;
        throw error;
      }
    })();
    modulePromise = request;
    void request.catch(() => {
      if (modulePromise === request) {
        modulePromise = null;
      }
    });
    return request;
  };
}
