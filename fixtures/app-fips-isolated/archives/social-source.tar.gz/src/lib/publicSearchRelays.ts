import { getConfiguredNostrRelays } from './htreeRuntime';

const NIP_50_RELAY = 'wss://relay.ditto.pub';

/** Availability for a one-query, user-initiated search of a public relay. */
export function getPublicSearchRelays(): string[] {
  if (typeof navigator === 'undefined' || navigator.onLine !== true) {
    return [];
  }
  return getConfiguredNostrRelays().some((relay) => relay === NIP_50_RELAY || relay === `${NIP_50_RELAY}/`)
    ? [NIP_50_RELAY]
    : [];
}
