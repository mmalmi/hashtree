import { getNoteEngagementTargetId } from './noteEngagement';
import type { CID } from '@hashtree/core';
import { createFeedHydrators } from './appFeedHydrators';
import { getAppScrollOffset } from './appScroll';
import { buildHomeFeedSnapshot } from './appHomeFeed';
import { createAppHomePaginationController } from './appHomePaginationController';
import { mergeLocalVisibleNotes } from './appNoteState';
import { createProfileDataHydrators } from './appProfileDataHydrators';
import { createProfileHydrators } from './appProfileHydrators';
import type { AppCombinedState } from './appState';
import { homeFeedNeedsViewerFollowRefresh } from './appRouteState';
import { createViewerHydrators } from './appViewerHydrators';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import { extractFollowPubkeys, type ProfileRecord, type RawEvent } from './nostr';
import {
  DURABLE_POST_KINDS,
  getFeedProfilePubkeys,
  selectNewestViewerContactsEvent,
  type FeedSnapshot,
  type ProfileSocialSnapshot,
} from './nostrIndex';
import {
  loadProfileNotesPageWithCacheFill,
  streamProfileNotesWithCacheFill,
} from './profileNotes';
import { rememberProfileRecord, rememberProfileRecords } from './profileCache';
import { socialDataPlane } from './socialDataPlane';

type DataHydrationDeps = {
  state: AppCombinedState;
  homeFeedSeenBatcher: ReturnType<typeof createHomeFeedSeenBatcher>;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  clearProfileViewState: () => void;
  clearThreadViewState: () => void;
  getCachedProfiles: (pubkeys: string[]) => Map<string, ProfileRecord>;
  getForYouOverlayInteractions: (authors: string[], limit: number) => RawEvent[];
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  hydrateNoteEngagements: (
    roots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  noteHasMedia: (event: RawEvent) => boolean;
  reportError: (fallback: string, error: unknown) => string;
  restartCurrentViewLoad: () => void;
  saveNotificationsSeenAt: (seenAt: number) => void;
  scheduleHomeFeedSnapshotWrite: (feed: FeedSnapshot) => void;
  seedEmptyEngagements: (noteIds: string[]) => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
  updateProfileNotesLoading: (loading: boolean) => void;
};

export function createAppDataHydrationControllers(deps: DataHydrationDeps) {
  const { state } = deps;
  const feedHydrators = createFeedHydrators({
    getFeed: () => state.feed,
    getFeedRequiresRefresh: () => state.feedRequiresRefresh,
    setFeedRequiresRefresh: (requiresRefresh) => {
      state.feedRequiresRefresh = requiresRefresh;
    },
    getHomeFeedFetchLimit: () => state.homeFeedFetchLimit,
    getHomeFeedVisibleLimit: () => state.feedLimit,
    getDisplayedHomeNotes: () => state.homeNotes,
    isHomeFeedScrolled: () => getAppScrollOffset() > 50,
    getHomeFeedRequestId: () => state.homeFeedRequestId,
    getLoadToken: () => state.loadToken,
    getRouteKind: () => state.route.kind,
    getViewerFollows: () => state.viewerFollows,
    getSeenHomeEventIds: () => state.activeAccount
      ? deps.homeFeedSeenBatcher.read(state.activeAccount.pubkey)
      : new Set(),
    getForYouOverlayInteractions: deps.getForYouOverlayInteractions,
    getForYouOverlayPosts: (authors, limit) => authors.length === 0 ? []
      : socialDataPlane.query({ authors, kinds: [...DURABLE_POST_KINDS], limit }),
    getForYouOverlayEventById: (eventId) => socialDataPlane.getEvent(eventId),
    getCachedProfiles: deps.getCachedProfiles,
    applyHomeFeedSnapshot: (nextFeed, viewerPubkey) => {
      state.homeFeedSnapshotReadController?.abort();
      state.homeFeedSnapshotReadController = null;
      const snapshot = buildHomeFeedSnapshot(
        nextFeed,
        viewerPubkey,
        deps.getCachedProfiles(getFeedProfilePubkeys(
          viewerPubkey,
          nextFeed.feedOwnerPubkey,
          nextFeed.notes,
        )),
      );
      deps.cacheKnownNotes(nextFeed.notes);
      state.feed = snapshot.feed;
      state.feedRequiresRefresh = false;
      deps.scheduleHomeFeedSnapshotWrite(snapshot.feed);
      deps.clearProfileViewState();
      deps.clearThreadViewState();
      deps.seedEmptyEngagements(nextFeed.notes.map(getNoteEngagementTargetId));
      deps.mergeCachedProfiles(snapshot.feed.profiles);
    },
    hydrateNoteEngagements: deps.hydrateNoteEngagements,
    mergeCachedProfiles: deps.mergeCachedProfiles,
    setFeed: (feed) => {
      state.feed = feed;
    },
    setLoading: (loading) => {
      state.loading = loading;
    },
    reportError: deps.reportError,
    setPageError: (message) => {
      state.pageError = message;
    },
    incrementHomeFeedRequestId: () => ++state.homeFeedRequestId,
    resumeInitialHomeFeed: async (root, missingCount, token) => {
      if (state.homeFeedLoadPending || token !== state.loadToken || state.route.kind !== 'home') {return;}
      state.homeFeedLoadPending = true;
      try {
        await hydrateNextHomeFeedPage(root, state.route, missingCount, token, { initialPage: true });
      } finally {
        if (token === state.loadToken) {
          state.homeFeedLoadPending = false;
        }
      }
    },
  });

  const { hydrateNextHomeFeedPage } = createAppHomePaginationController({
    state,
    homeFeedSeenBatcher: deps.homeFeedSeenBatcher,
    cacheKnownNotes: deps.cacheKnownNotes,
    hydrateFeedProfiles: (root, pubkey, feed, token) => (
      feedHydrators.hydrateFeedProfiles(root, pubkey, feed, token)
    ),
    hydrateNoteEngagements: deps.hydrateNoteEngagements,
    noteHasMedia: deps.noteHasMedia,
    reportError: deps.reportError,
    scheduleHomeFeedSnapshotWrite: deps.scheduleHomeFeedSnapshotWrite,
    seedNewEmptyEngagements: deps.seedNewEmptyEngagements,
  });

  function applyViewerFollows(follows: Set<string>): void {
    const changed = follows.size !== state.viewerFollows.size
      || [...follows].some((pubkey) => !state.viewerFollows.has(pubkey));
    if (!changed) {
      return;
    }
    state.viewerFollows = follows;
    if (homeFeedNeedsViewerFollowRefresh({
      route: state.route,
      feed: state.feed,
      viewerPubkey: state.activeAccount?.pubkey ?? null,
      viewerFollows: state.viewerFollows,
      activeFeedSourcePubkey: state.activeFeedSource?.pubkey ?? null,
    })) {
      deps.restartCurrentViewLoad();
    }
  }

  function projectContactsEvent(event: RawEvent | null, pubkey: string): RawEvent | null {
    return socialDataPlane.projectSnapshot(event ? [event] : [], {
      authors: [pubkey],
      kinds: [3],
      limit: 1,
    })[0] ?? null;
  }

  function overlayProfileSocialContacts(
    social: ProfileSocialSnapshot | null,
    pubkey: string,
  ): ProfileSocialSnapshot | null {
    if (!social) {
      return null;
    }
    const contactsEvent = projectContactsEvent(social.contactsEvent, pubkey);
    if (!contactsEvent) {
      return social.contactsEvent
        ? { ...social, contactsEvent: null, follows: [], followsCount: 0, hasFollows: true }
        : social;
    }
    const follows = extractFollowPubkeys(contactsEvent);
    return { ...social, contactsEvent, follows, followsCount: follows.length, hasFollows: true };
  }

  function applyProfileSocialSnapshot(social: ProfileSocialSnapshot | null): void {
    const next = state.route.kind === 'profile' && state.route.pubkey
      ? overlayProfileSocialContacts(social, state.route.pubkey)
      : social;
    state.profileSocial = next;
    if (
      next?.contactsEvent
      && state.route.kind === 'profile'
      && state.route.pubkey === state.activeAccount?.pubkey
    ) {
      const winner = selectNewestViewerContactsEvent(
        [state.viewerContactsEvent, next.contactsEvent],
        state.activeAccount.pubkey,
      );
      if (winner?.id !== state.viewerContactsEvent?.id) {
        state.viewerContactsEvent = winner;
        state.viewerFollows = new Set(extractFollowPubkeys(winner));
      }
    }
  }

  const viewerHydrators = createViewerHydrators({
    getLoadToken: () => state.loadToken,
    getSearchRequestId: () => state.searchRequestId,
    getViewerPersonalRoot: () => state.viewerPersonalRoot,
    getAccountProfiles: () => state.accountProfiles,
    getNotifications: () => state.notifications,
    getNotificationsProfiles: () => state.notificationsProfiles,
    isNotificationsRoute: () => state.route.kind === 'notifications',
    mergeCachedProfiles: deps.mergeCachedProfiles,
    saveNotificationsSeenAt: (seenAt) => {
      deps.saveNotificationsSeenAt(Math.max(state.notificationsSeenAt, seenAt));
    },
    setViewerPersonalRoot: (root) => {
      state.viewerPersonalRoot = root;
    },
    setViewerContactsEvent: (event) => {
      const pubkey = state.activeAccount?.pubkey;
      const projected = pubkey ? projectContactsEvent(event, pubkey) : event;
      state.viewerContactsProjectionAuthoritative = Boolean(event || projected);
      state.viewerContactsEvent = projected;
    },
    setViewerFollows: (follows) => applyViewerFollows(
      state.viewerContactsProjectionAuthoritative
        ? new Set(extractFollowPubkeys(state.viewerContactsEvent))
        : follows.size > 0 ? follows : state.viewerFollows,
    ),
    setViewerGraphFollows: (follows) => {
      if (!state.viewerContactsProjectionAuthoritative) {
        applyViewerFollows(follows);
      }
    },
    setViewerMuteListEvent: (event) => {
      state.indexedViewerMuteListEvent = event;
    },
    setViewerProfileEvent: (event) => {
      state.hydratedViewerProfileEvent = event;
    },
    setViewerProfileLoading: (loading) => {
      state.viewerProfileLoading = loading;
    },
    setSearchLoading: (loading) => {
      state.searchLoading = loading;
    },
    setSearchRemoteProfiles: (profiles) => {
      state.searchRemoteProfiles = profiles;
      deps.mergeCachedProfiles(new Map(profiles.map((profile) => [profile.pubkey, profile])));
    },
    setNotificationsLoading: (loading) => {
      state.notificationsLoading = loading;
    },
    setNotificationsLoadPending: (loading) => {
      state.notificationsLoadPending = loading;
    },
    setNotificationsCursor: (cursor) => {
      state.notificationCursor = cursor;
    },
    setNotificationsHasMore: (hasMore) => {
      state.notificationsHasMore = hasMore;
    },
    setNotifications: (items) => {
      state.notifications = items;
    },
    setNotificationsProfiles: (profiles) => {
      state.notificationsProfiles = profiles;
    },
  });

  const profileHydrators = createProfileHydrators({
    getLoadToken: () => state.loadToken,
    getProfileSocial: () => state.profileSocial,
    getProfileSocialFollowerFetchLimit: () => state.profileSocialFollowerFetchLimit,
    getProfilePageHasContent: (pubkey) => Boolean(
      state.profilePage?.profile
      ?? state.accountProfiles.get(pubkey)
      ?? (state.profilePage?.notes.length ? true : null),
    ),
    getCurrentRouteProfilePubkey: () => state.route.kind === 'profile' ? state.route.pubkey : null,
    mergeCachedProfiles: deps.mergeCachedProfiles,
    restartCurrentViewLoad: deps.restartCurrentViewLoad,
    setProfileSocial: applyProfileSocialSnapshot,
    setProfileSocialLoading: (loading) => {
      state.profileSocialLoading = loading;
    },
    setProfileEmptyRetryKey: (key) => {
      state.profileEmptyRetryKey = key;
    },
    getProfileEmptyRetryKey: () => state.profileEmptyRetryKey,
  });

  const profileDataHydrators = createProfileDataHydrators({
    getLoadToken: () => state.loadToken,
    getProfileNotesRequestId: () => state.profileNotesRequestId,
    getProfileLikesRequestId: () => state.profileLikesRequestId,
    getProfileNoteFetchLimit: () => state.profileNoteFetchLimit,
    getProfilePage: () => state.profilePage,
    getAccountProfiles: () => state.accountProfiles,
    getProfilePersonalRoot: () => state.profilePersonalRoot,
    setProfilePersonalRoot: (root) => {
      state.profilePersonalRoot = root;
    },
    setProfilePage: (page) => {
      rememberProfileRecord(page?.profile);
      state.profilePage = page;
    },
    setAccountProfiles: (profiles) => {
      rememberProfileRecords(profiles.values());
      state.accountProfiles = profiles;
    },
    setProfileEmptyRetryKey: (key) => {
      state.profileEmptyRetryKey = key;
    },
    setProfileNotesLoading: deps.updateProfileNotesLoading,
    setPageError: (message) => {
      state.pageError = message;
    },
    reportError: deps.reportError,
    incrementProfileNotesRequestId: () => ++state.profileNotesRequestId,
    incrementProfileLikesRequestId: () => ++state.profileLikesRequestId,
    cacheKnownNotes: deps.cacheKnownNotes,
    mergeLocalVisibleNotes: (notes, pubkey) => (
      mergeLocalVisibleNotes(state.localPostsByAuthor, notes, pubkey)
    ),
    seedEmptyEngagements: deps.seedEmptyEngagements,
    hydrateNoteEngagements: deps.hydrateNoteEngagements,
    loadNextProfileNotesPage: loadProfileNotesPageWithCacheFill,
    streamProfileNotes: streamProfileNotesWithCacheFill,
    getProfileOverlayReactions: (pubkey) => socialDataPlane.query({ authors: [pubkey], kinds: [7] }),
    getKnownNoteById: deps.getKnownNoteByRef,
  });

  return {
    applyProfileSocialSnapshot,
    applyViewerFollows,
    feedHydrators,
    hydrateNextHomeFeedPage,
    profileDataHydrators,
    profileHydrators,
    projectContactsEvent,
    viewerHydrators,
  };
}
