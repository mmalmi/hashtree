import * as nip19 from 'nostr-tools/nip19';

/** NIP-27 mentions and NIP-18 quotes stay distinct from reply ancestry. */
export function buildComposerReferenceTags(content: string, existing: string[][] = []): string[][] {
  const tags = existing.map((tag) => [...tag]);
  const append = (tag: string[]) => {
    if (!tags.some((current) => current[0] === tag[0] && current[1] === tag[1])) {
      tags.push(tag);
    }
  };
  for (const match of content.matchAll(/\bnostr:((?:npub|nprofile|note|nevent|naddr)1[023456789acdefghjklmnpqrstuvwxyz]+)/gi)) {
    try {
      const decoded = nip19.decode(match[1]!.toLowerCase());
      if (decoded.type === 'npub') {
        append(['p', decoded.data]);
      } else if (decoded.type === 'nprofile') {
        append(['p', decoded.data.pubkey]);
      } else if (decoded.type === 'note') {
        append(['q', decoded.data]);
      } else if (decoded.type === 'nevent') {
        const { id, relays, author } = decoded.data;
        append(author ? ['q', id, relays?.[0] ?? '', author] : ['q', id, relays?.[0] ?? '']);
        if (author) { append(['p', author]); }
      } else if (decoded.type === 'naddr') {
        append(['q', `${decoded.data.kind}:${decoded.data.pubkey}:${decoded.data.identifier}`, decoded.data.relays?.[0] ?? '']);
        append(['p', decoded.data.pubkey]);
      }
    } catch {
      // Invalid references remain ordinary text.
    }
  }
  return tags;
}
