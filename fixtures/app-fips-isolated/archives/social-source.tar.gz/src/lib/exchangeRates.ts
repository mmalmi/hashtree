export const EXCHANGE_RATE_CACHE_KEY = 'iris-social:btc-exchange-rates:v1';
export const EXCHANGE_RATE_FRESH_TTL_MS = 5 * 60 * 1_000;
export const EXCHANGE_RATE_FETCH_TIMEOUT_MS = 8_000;
export const COINBASE_BTC_RATES_URL = 'https://api.coinbase.com/v2/exchange-rates?currency=BTC';
export const KRAKEN_BTC_TICKERS_URL =
  'https://api.kraken.com/0/public/Ticker?pair=XBTUSD,XBTEUR,XBTGBP,XBTCAD,XBTAUD,XBTJPY,XBTCHF';

export const EXCHANGE_RATE_CURRENCIES = [
  'SAT',
  'BTC',
  'USD',
  'EUR',
  'GBP',
  'CAD',
  'AUD',
  'JPY',
  'CHF',
] as const;

const FIAT_CURRENCIES = ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY', 'CHF'] as const;
const SATS_PER_BTC = 100_000_000;
const MAX_PROVIDER_SPREAD = 0.1;
const MAX_CACHE_CLOCK_SKEW_MS = 60_000;

export type ExchangeRateCurrency = typeof EXCHANGE_RATE_CURRENCIES[number];
export type FiatExchangeRateCurrency = typeof FIAT_CURRENCIES[number];
export type ExchangeRateTable = Record<ExchangeRateCurrency, number>;
export type NetworkExchangeRateSource = 'coinbase' | 'kraken' | 'coinbase+kraken';
export type ExchangeRateSource = NetworkExchangeRateSource | 'cache';

export type ExchangeRateSnapshot = {
  rates: ExchangeRateTable;
  updatedAt: number;
  ageMs: number;
  stale: boolean;
  source: ExchangeRateSource;
  cachedSource?: NetworkExchangeRateSource;
};

export type ExchangeRateStorage = Pick<Storage, 'getItem' | 'setItem'>;

export type ExchangeRateClient = {
  getRates(options?: { forceRefresh?: boolean }): Promise<ExchangeRateSnapshot | null>;
  readCachedRates(): ExchangeRateSnapshot | null;
};

export type ExchangeRateClientOptions = {
  fetch?: typeof fetch | null;
  storage?: ExchangeRateStorage | null;
  now?: () => number;
  freshTtlMs?: number;
  timeoutMs?: number;
};

type Provider = 'coinbase' | 'kraken';
type FiatRates = Partial<Record<FiatExchangeRateCurrency, number>>;
type ProviderResult = { provider: Provider; rates: FiatRates };
type NetworkResult = { rates: ExchangeRateTable; source: NetworkExchangeRateSource };

type StoredExchangeRates = {
  version: 1;
  rates: ExchangeRateTable;
  source: NetworkExchangeRateSource;
  updatedAt: number;
};

const RATE_BOUNDS: Record<FiatExchangeRateCurrency, readonly [number, number]> = {
  USD: [100, 10_000_000],
  EUR: [100, 10_000_000],
  GBP: [100, 10_000_000],
  CAD: [100, 20_000_000],
  AUD: [100, 20_000_000],
  JPY: [10_000, 2_000_000_000],
  CHF: [100, 10_000_000],
};

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function readNow(clock: () => number): number {
  try {
    const value = clock();
    return Number.isFinite(value) && value >= 0 ? Math.floor(value) : Date.now();
  } catch {
    return Date.now();
  }
}

function positiveDuration(value: number | undefined, fallback: number): number {
  return Number.isFinite(value) && (value ?? 0) > 0 ? Math.floor(value!) : fallback;
}

function parseFiatRate(currency: FiatExchangeRateCurrency, value: unknown): number | null {
  if (typeof value !== 'number' && typeof value !== 'string') {
    return null;
  }
  const parsed = Number(value);
  const [minimum, maximum] = RATE_BOUNDS[currency];
  return Number.isFinite(parsed) && parsed >= minimum && parsed <= maximum ? parsed : null;
}

function parseCoinbaseRates(value: unknown): FiatRates {
  if (!isObject(value) || !isObject(value.data) || !isObject(value.data.rates)) {
    return {};
  }
  if (value.data.currency !== undefined && value.data.currency !== 'BTC') {
    return {};
  }
  const rates: FiatRates = {};
  for (const currency of FIAT_CURRENCIES) {
    const rate = parseFiatRate(currency, value.data.rates[currency]);
    if (rate !== null) {
      rates[currency] = rate;
    }
  }
  return rates;
}

function currencyFromKrakenPair(pair: string): FiatExchangeRateCurrency | null {
  const normalized = pair.toUpperCase();
  if (!normalized.includes('XBT')) {
    return null;
  }
  return FIAT_CURRENCIES.find((currency) => normalized.endsWith(currency)) ?? null;
}

function parseKrakenRates(value: unknown): FiatRates {
  if (!isObject(value) || !Array.isArray(value.error) || value.error.length > 0 || !isObject(value.result)) {
    return {};
  }
  const rates: FiatRates = {};
  for (const [pair, rawTicker] of Object.entries(value.result)) {
    const currency = currencyFromKrakenPair(pair);
    if (!currency || !isObject(rawTicker) || !Array.isArray(rawTicker.c)) {
      continue;
    }
    const rate = parseFiatRate(currency, rawTicker.c[0]);
    if (rate !== null) {
      rates[currency] = rate;
    }
  }
  return rates;
}

async function fetchProvider(
  fetcher: typeof fetch,
  provider: Provider,
  signal: AbortSignal,
): Promise<ProviderResult | null> {
  const url = provider === 'coinbase' ? COINBASE_BTC_RATES_URL : KRAKEN_BTC_TICKERS_URL;
  try {
    const response = await fetcher(url, {
      signal,
      headers: { accept: 'application/json' },
    });
    if (!response.ok) {
      return null;
    }
    const payload = await response.json() as unknown;
    const rates = provider === 'coinbase'
      ? parseCoinbaseRates(payload)
      : parseKrakenRates(payload);
    return Object.keys(rates).length > 0 ? { provider, rates } : null;
  } catch {
    return null;
  }
}

function relativeSpread(left: number, right: number): number {
  return Math.abs(left - right) / ((left + right) / 2);
}

function chooseRate(
  currency: FiatExchangeRateCurrency,
  coinbase: FiatRates,
  kraken: FiatRates,
): { rate: number; providers: Provider[] } | null {
  const coinbaseRate = coinbase[currency];
  const krakenRate = kraken[currency];
  if (coinbaseRate !== undefined && krakenRate !== undefined) {
    if (relativeSpread(coinbaseRate, krakenRate) <= MAX_PROVIDER_SPREAD) {
      return { rate: (coinbaseRate + krakenRate) / 2, providers: ['coinbase', 'kraken'] };
    }
    return null;
  }
  if (coinbaseRate !== undefined) {
    return { rate: coinbaseRate, providers: ['coinbase'] };
  }
  return krakenRate === undefined ? null : { rate: krakenRate, providers: ['kraken'] };
}

function networkSource(providers: Set<Provider>): NetworkExchangeRateSource {
  if (providers.size === 2) {
    return 'coinbase+kraken';
  }
  return providers.has('coinbase') ? 'coinbase' : 'kraken';
}

function combineProviderRates(
  results: Array<ProviderResult | null>,
): NetworkResult | null {
  const coinbase = results.find((result) => result?.provider === 'coinbase')?.rates ?? {};
  const kraken = results.find((result) => result?.provider === 'kraken')?.rates ?? {};
  const selected: FiatRates = {};
  const providers = new Set<Provider>();
  for (const currency of FIAT_CURRENCIES) {
    const choice = chooseRate(currency, coinbase, kraken);
    if (!choice) {
      return null;
    }
    selected[currency] = choice.rate;
    choice.providers.forEach((provider) => providers.add(provider));
  }
  return {
    rates: {
      SAT: SATS_PER_BTC,
      BTC: 1,
      USD: selected.USD!,
      EUR: selected.EUR!,
      GBP: selected.GBP!,
      CAD: selected.CAD!,
      AUD: selected.AUD!,
      JPY: selected.JPY!,
      CHF: selected.CHF!,
    },
    source: networkSource(providers),
  };
}

async function fetchNetworkRates(
  fetcher: typeof fetch,
  timeoutMs: number,
): Promise<NetworkResult | null> {
  const controller = new AbortController();
  const providers: Provider[] = ['coinbase', 'kraken'];
  const results: Array<ProviderResult | null> = [null, null];
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  const requests = providers.map(async (provider, index) => {
    results[index] = await fetchProvider(fetcher, provider, controller.signal);
  });
  const completed = Promise.all(requests).then(() => results);
  const timedOut = new Promise<Array<ProviderResult | null>>((resolve) => {
    timeoutId = setTimeout(() => {
      controller.abort();
      resolve([...results]);
    }, timeoutMs);
  });
  try {
    return combineProviderRates(await Promise.race([completed, timedOut]));
  } finally {
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
    }
  }
}

function isNetworkSource(value: unknown): value is NetworkExchangeRateSource {
  return value === 'coinbase' || value === 'kraken' || value === 'coinbase+kraken';
}

function validateRateTable(value: unknown): ExchangeRateTable | null {
  if (!isObject(value) || value.SAT !== SATS_PER_BTC || value.BTC !== 1) {
    return null;
  }
  const rates = { SAT: SATS_PER_BTC, BTC: 1 } as ExchangeRateTable;
  for (const currency of FIAT_CURRENCIES) {
    const rate = parseFiatRate(currency, value[currency]);
    if (rate === null) {
      return null;
    }
    rates[currency] = rate;
  }
  return rates;
}

function readStoredRates(
  storage: ExchangeRateStorage | null,
  now: number,
): StoredExchangeRates | null {
  if (!storage) {
    return null;
  }
  try {
    const raw = storage.getItem(EXCHANGE_RATE_CACHE_KEY);
    const value = raw ? JSON.parse(raw) as unknown : null;
    if (
      !isObject(value)
      || value.version !== 1
      || !isNetworkSource(value.source)
      || !Number.isSafeInteger(value.updatedAt)
      || (value.updatedAt as number) < 0
      || (value.updatedAt as number) > now + MAX_CACHE_CLOCK_SKEW_MS
    ) {
      return null;
    }
    const rates = validateRateTable(value.rates);
    return rates ? {
      version: 1,
      rates,
      source: value.source,
      updatedAt: value.updatedAt as number,
    } : null;
  } catch {
    return null;
  }
}

function writeStoredRates(storage: ExchangeRateStorage | null, value: StoredExchangeRates): void {
  if (!storage) {
    return;
  }
  try {
    storage.setItem(EXCHANGE_RATE_CACHE_KEY, JSON.stringify(value));
  } catch {
    // A live network result remains usable when browser storage is unavailable.
  }
}

function getBrowserStorage(): ExchangeRateStorage | null {
  if (typeof window === 'undefined') {
    return null;
  }
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

export function createExchangeRateClient(
  options: ExchangeRateClientOptions = {},
): ExchangeRateClient {
  const fetcher = options.fetch === undefined
    ? globalThis.fetch?.bind(globalThis) ?? null
    : options.fetch;
  const storage = options.storage === undefined ? getBrowserStorage() : options.storage;
  const clock = options.now ?? Date.now;
  const freshTtlMs = positiveDuration(options.freshTtlMs, EXCHANGE_RATE_FRESH_TTL_MS);
  const timeoutMs = positiveDuration(options.timeoutMs, EXCHANGE_RATE_FETCH_TIMEOUT_MS);
  let inFlight: Promise<ExchangeRateSnapshot | null> | null = null;

  const readCachedRates = (): ExchangeRateSnapshot | null => {
    const now = readNow(clock);
    const stored = readStoredRates(storage, now);
    if (!stored) {
      return null;
    }
    const ageMs = Math.max(0, now - stored.updatedAt);
    return {
      rates: stored.rates,
      updatedAt: stored.updatedAt,
      ageMs,
      stale: ageMs >= freshTtlMs,
      source: 'cache',
      cachedSource: stored.source,
    };
  };

  const getRates = (loadOptions: { forceRefresh?: boolean } = {}) => {
    const cached = readCachedRates();
    if (!loadOptions.forceRefresh && cached && !cached.stale) {
      return Promise.resolve(cached);
    }
    if (inFlight) {
      return inFlight;
    }
    if (!fetcher) {
      return Promise.resolve(cached);
    }
    const request = (async (): Promise<ExchangeRateSnapshot | null> => {
      const network = await fetchNetworkRates(fetcher, timeoutMs);
      if (!network) {
        return readCachedRates() ?? cached;
      }
      const updatedAt = readNow(clock);
      writeStoredRates(storage, {
        version: 1,
        rates: network.rates,
        source: network.source,
        updatedAt,
      });
      return {
        rates: network.rates,
        updatedAt,
        ageMs: 0,
        stale: false,
        source: network.source,
      };
    })();
    inFlight = request;
    void request.then(
      () => {
        if (inFlight === request) {
          inFlight = null;
        }
      },
      () => {
        if (inFlight === request) {
          inFlight = null;
        }
      },
    );
    return request;
  };

  return { getRates, readCachedRates };
}

let defaultClient: ExchangeRateClient | null = null;

function getDefaultClient(): ExchangeRateClient {
  defaultClient ??= createExchangeRateClient();
  return defaultClient;
}

export function getExchangeRates(
  options: { forceRefresh?: boolean } = {},
): Promise<ExchangeRateSnapshot | null> {
  return getDefaultClient().getRates(options);
}

export function readCachedExchangeRates(): ExchangeRateSnapshot | null {
  return getDefaultClient().readCachedRates();
}

function unwrapRates(
  value: ExchangeRateTable | Pick<ExchangeRateSnapshot, 'rates'> | null,
): ExchangeRateTable | null {
  if (!value) {
    return null;
  }
  return 'rates' in value ? value.rates : value;
}

export function convertSats(
  amountSats: number,
  currency: ExchangeRateCurrency,
  rates: ExchangeRateTable | Pick<ExchangeRateSnapshot, 'rates'> | null,
): number | null {
  if (!Number.isSafeInteger(amountSats)) {
    return null;
  }
  if (currency === 'SAT') {
    return amountSats;
  }
  if (currency === 'BTC') {
    return amountSats / SATS_PER_BTC;
  }
  const rate = unwrapRates(rates)?.[currency];
  if (!rate || !Number.isFinite(rate)) {
    return null;
  }
  const converted = (amountSats / SATS_PER_BTC) * rate;
  return Number.isFinite(converted) ? converted : null;
}

const numberFormatters = new Map<string, Intl.NumberFormat>();

function compactFormatter(
  locale: string | string[] | undefined,
  currency: FiatExchangeRateCurrency | null,
  compact: boolean,
): Intl.NumberFormat {
  const key = JSON.stringify([locale ?? null, currency, compact]);
  let formatter = numberFormatters.get(key);
  if (!formatter) {
    formatter = new Intl.NumberFormat(locale, {
      ...(currency ? {
        style: 'currency',
        currency,
        currencyDisplay: 'narrowSymbol',
      } : {}),
      notation: compact ? 'compact' : 'standard',
      compactDisplay: 'short',
      maximumSignificantDigits: 4,
    });
    numberFormatters.set(key, formatter);
  }
  return formatter;
}

export function formatSatsAmount(
  amountSats: number,
  currency: ExchangeRateCurrency,
  rates: ExchangeRateTable | Pick<ExchangeRateSnapshot, 'rates'> | null,
  options: { locale?: string | string[] } = {},
): string {
  const value = convertSats(amountSats, currency, rates);
  if (value === null) {
    return '—';
  }
  const normalized = Object.is(value, -0) ? 0 : value;
  const compact = Math.abs(normalized) >= 1_000;
  const fiat = currency === 'SAT' || currency === 'BTC' ? null : currency;
  const formatted = compactFormatter(options.locale, fiat, compact).format(normalized);
  return fiat ? formatted : `${formatted} ${currency}`;
}
