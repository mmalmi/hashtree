export function profileLoadAbortReason(signal: AbortSignal | null | undefined): unknown {
  return signal?.reason ?? new DOMException('Profile hydration was cancelled', 'AbortError');
}

export function throwIfProfileLoadAborted(signal: AbortSignal | null | undefined): void {
  if (signal?.aborted) {
    throw profileLoadAbortReason(signal);
  }
}

export function isProfileLoadAbort(
  error: unknown,
  signal: AbortSignal | null | undefined = null,
): boolean {
  return Boolean(
    signal?.aborted
    || (typeof DOMException !== 'undefined'
      && error instanceof DOMException
      && error.name === 'AbortError')
    || (error instanceof Error && error.name === 'AbortError'),
  );
}

export async function withProfileLoadAbort<T>(
  operation: Promise<T>,
  signal: AbortSignal | null | undefined,
): Promise<T> {
  throwIfProfileLoadAborted(signal);
  if (!signal) {
    return await operation;
  }

  let abort: (() => void) | null = null;
  const cancelled = new Promise<never>((_resolve, reject) => {
    abort = () => reject(profileLoadAbortReason(signal));
    signal.addEventListener('abort', abort, { once: true });
  });
  try {
    return await Promise.race([operation, cancelled]);
  } finally {
    if (abort) {
      signal.removeEventListener('abort', abort);
    }
  }
}
