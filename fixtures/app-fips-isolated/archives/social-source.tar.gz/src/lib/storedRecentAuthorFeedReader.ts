import { CollectionSource } from '@hashtree/collection';
import { HashTree, nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  decodeStoredNostrEventMsgpack,
  NostrEventStore,
  nostrEventManifestToCollectionManifest,
  type StoredNostrEvent,
} from '@hashtree/nostr';
import { CooperativeWorkBudget } from './cooperativeWork';
import { awaitWithin } from './feedIndexTiming';
import {
  EMPTY_NOSTR_COLLECTION_INDEXES,
  getNostrCollectionIndexes,
} from './nostrCollectionIndexes';
import { RecentAuthorFeedReader } from './recentAuthorFeedReader';

const MAX_CACHED_COLLECTION_SOURCES_PER_STORE = 8;
const collectionSourcesByStore = new WeakMap<Store, Map<string, Promise<CollectionSource>>>();

function getCachedCollectionSource(root: CID, store: Store): Promise<CollectionSource> {
  let sources = collectionSourcesByStore.get(store);
  if (!sources) {
    sources = new Map();
    collectionSourcesByStore.set(store, sources);
  }
  const key = nhashEncode(root);
  const cached = sources.get(key);
  if (cached) {
    // Map insertion order provides a tiny LRU for successive immutable feed roots.
    sources.delete(key);
    sources.set(key, cached);
    return cached;
  }

  const source = (async () => {
    const eventStore = new NostrEventStore(store);
    return new CollectionSource(
      store,
      nostrEventManifestToCollectionManifest(await eventStore.getManifest(root)),
    );
  })();
  sources.set(key, source);
  while (sources.size > MAX_CACHED_COLLECTION_SOURCES_PER_STORE) {
    const oldestKey = sources.keys().next().value;
    if (oldestKey === undefined) {
      break;
    }
    sources.delete(oldestKey);
  }
  void source.catch(() => {
    if (sources?.get(key) === source) {
      sources.delete(key);
    }
  });
  return source;
}

export type StoredRecentAuthorFeedReaderOptions = {
  indexedEventReadConcurrency?: number;
  signal?: AbortSignal;
  verifyEvent(event: StoredNostrEvent): boolean | Promise<boolean>;
};

/** Build the worker's small, self-contained storage/decode/verification slice. */
export function createStoredRecentAuthorFeedReader(
  root: CID,
  store: Store,
  options: StoredRecentAuthorFeedReaderOptions,
): RecentAuthorFeedReader {
  const tree = new HashTree({ store });
  const budget = new CooperativeWorkBudget();
  const getCollectionSource = async (): Promise<CollectionSource> => (
    await getCachedCollectionSource(root, store)
  );

  return new RecentAuthorFeedReader({
    indexedEventReadConcurrency: options.indexedEventReadConcurrency,
    signal: options.signal,
    getCollectionSource,
    async getCollectionIndexes({ timeoutMs } = {}) {
      try {
        if (timeoutMs === undefined) {
          return getNostrCollectionIndexes(await getCollectionSource());
        }
        const quickSource = await awaitWithin(getCollectionSource(), timeoutMs);
        return quickSource.settled
          ? getNostrCollectionIndexes(quickSource.value)
          : EMPTY_NOSTR_COLLECTION_INDEXES;
      } catch (error) {
        console.warn('Failed to load Nostr collection indexes', error);
        return EMPTY_NOSTR_COLLECTION_INDEXES;
      }
    },
    async readEvent(cid) {
      if (options.signal?.aborted) {
        return null;
      }
      const bytes = await tree.readFile(cid);
      if (!bytes || options.signal?.aborted) {
        return null;
      }
      try {
        const event = await budget.run(() => decodeStoredNostrEventMsgpack(bytes));
        const valid = await budget.run(() => options.verifyEvent(event));
        return valid && !options.signal?.aborted ? event : null;
      } catch (error) {
        console.warn('Failed to decode indexed nostr event', error);
        return null;
      }
    },
  });
}
