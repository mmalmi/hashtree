import type { CID } from '@hashtree/core';
import type { ProfileRecord } from './nostr';
import {
  loadProfileFromFastestSource,
  type ProfileLoadOptions,
} from './profileSourceRace';
import { routedProfilesByPubkey } from './routedEventReads';
import { applySocialGraphMetrics } from './socialGraph';

/** Resolve profile metadata only through the authenticated application event root. */
export async function loadEventIndexProfileRecord(
  root: CID,
  pubkey: string,
  options: ProfileLoadOptions = {},
): Promise<ProfileRecord | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  if (!normalizedPubkey) {
    return null;
  }

  const profile = await loadProfileFromFastestSource(normalizedPubkey, {
    loadCatalogProfile: async () => null,
    loadRoutedProfile: async (signal) => (
      await routedProfilesByPubkey([root], [normalizedPubkey], { signal })
    ).get(normalizedPubkey) ?? null,
  }, {
    signal: options.signal,
    isCurrent: options.isCurrent,
    onProfile: (candidate) => {
      const enriched = applySocialGraphMetrics(candidate) ?? candidate;
      options.onProfile?.(enriched);
    },
  });
  return applySocialGraphMetrics(profile);
}
