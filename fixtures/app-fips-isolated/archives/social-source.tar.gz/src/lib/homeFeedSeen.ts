import type { RawEvent } from './nostr';

export const HOME_FEED_SEEN_DWELL_MS = 1_000;
export const HOME_FEED_SEEN_WRITE_DELAY_MS = 500;
export const HOME_FEED_SEEN_MAX_EVENTS = 4_096;

const HOME_FEED_SEEN_FORMAT = 'iris-social/home-feed-seen@1' as const;
const HOME_FEED_SEEN_STORAGE_PREFIX = 'iris-social:home-feed-seen:v1';
const HEX_64 = /^[0-9a-f]{64}$/;

export type HomeFeedSeenStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

type StoredHomeFeedSeen = {
  format: typeof HOME_FEED_SEEN_FORMAT;
  eventIds: string[];
};

export type HomeFeedSeenDwellScheduler = {
  setTimeout: (callback: () => void, delay: number) => unknown;
  clearTimeout: (timerId: unknown) => void;
};

function defaultDwellScheduler(): HomeFeedSeenDwellScheduler {
  return {
    setTimeout: (callback, delay) => globalThis.setTimeout(callback, delay),
    clearTimeout: (timerId) => globalThis.clearTimeout(
      timerId as ReturnType<typeof globalThis.setTimeout>,
    ),
  };
}

/** Match Iris Client's rule: a continuously visible card becomes seen after one second. */
export function createHomeFeedSeenDwellTracker(
  onSeen: (event: RawEvent, presentedEvent: RawEvent | null) => void,
  scheduler: HomeFeedSeenDwellScheduler = defaultDwellScheduler(),
): {
  update: (event: RawEvent, presentedEvent: RawEvent | null, visible: boolean) => void;
  destroy: () => void;
} {
  const reportedKeys = new Set<string>();
  let pendingKey: string | null = null;
  let pendingTimer: unknown = null;

  const cancelPending = (): void => {
    if (pendingTimer !== null) {
      scheduler.clearTimeout(pendingTimer);
    }
    pendingKey = null;
    pendingTimer = null;
  };

  return {
    update(event, presentedEvent, visible) {
      if (!visible) {
        cancelPending();
        return;
      }
      const key = `${event.id}:${presentedEvent?.id ?? ''}`;
      if (reportedKeys.has(key) || pendingKey === key) {
        return;
      }

      cancelPending();
      pendingKey = key;
      pendingTimer = scheduler.setTimeout(() => {
        if (pendingKey !== key) {
          return;
        }
        pendingKey = null;
        pendingTimer = null;
        reportedKeys.add(key);
        onSeen(event, presentedEvent);
      }, HOME_FEED_SEEN_DWELL_MS);
    },
    destroy() {
      cancelPending();
      reportedKeys.clear();
    },
  };
}

function defaultStorage(): HomeFeedSeenStorage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage;
  } catch {
    return null;
  }
}

function storageKey(viewerPubkey: string): string | null {
  return HEX_64.test(viewerPubkey)
    ? `${HOME_FEED_SEEN_STORAGE_PREFIX}:${viewerPubkey}`
    : null;
}

export function readHomeFeedSeenEventIds(
  viewerPubkey: string,
  storage: HomeFeedSeenStorage | null = defaultStorage(),
): Set<string> {
  const key = storageKey(viewerPubkey);
  if (!storage || !key) {
    return new Set();
  }

  try {
    const raw = storage.getItem(key);
    if (!raw) {
      return new Set();
    }
    const parsed: unknown = JSON.parse(raw);
    if (
      typeof parsed !== 'object'
      || parsed === null
      || Array.isArray(parsed)
      || Object.keys(parsed).sort().join(',') !== 'eventIds,format'
    ) {
      throw new Error('Invalid seen-feed envelope');
    }
    const stored = parsed as Partial<StoredHomeFeedSeen>;
    if (
      stored.format !== HOME_FEED_SEEN_FORMAT
      || !Array.isArray(stored.eventIds)
      || stored.eventIds.length > HOME_FEED_SEEN_MAX_EVENTS
      || stored.eventIds.some((eventId) => typeof eventId !== 'string' || !HEX_64.test(eventId))
      || new Set(stored.eventIds).size !== stored.eventIds.length
    ) {
      throw new Error('Invalid seen-feed events');
    }
    return new Set(stored.eventIds);
  } catch {
    try {
      storage.removeItem(key);
    } catch {
      // Corrupt optional history must never block the feed.
    }
    return new Set();
  }
}

export function markHomeFeedEventsSeen(
  viewerPubkey: string,
  eventIds: readonly string[],
  storage: HomeFeedSeenStorage | null = defaultStorage(),
): boolean {
  const key = storageKey(viewerPubkey);
  if (!storage || !key) {
    return false;
  }
  const newIds = [...new Set(eventIds.filter((eventId) => HEX_64.test(eventId)))];
  if (newIds.length === 0) {
    return false;
  }
  const newIdSet = new Set(newIds);
  const existing = readHomeFeedSeenEventIds(viewerPubkey, storage);
  const bounded = [
    ...newIds,
    ...[...existing].filter((eventId) => !newIdSet.has(eventId)),
  ].slice(0, HOME_FEED_SEEN_MAX_EVENTS);
  try {
    storage.setItem(key, JSON.stringify({
      format: HOME_FEED_SEEN_FORMAT,
      eventIds: bounded,
    } satisfies StoredHomeFeedSeen));
    return true;
  } catch {
    return false;
  }
}

export function createHomeFeedSeenBatcher(
  storage: HomeFeedSeenStorage | null = defaultStorage(),
  scheduler: HomeFeedSeenDwellScheduler = defaultDwellScheduler(),
): {
  mark: (viewerPubkey: string, eventIds: readonly string[]) => void;
  read: (viewerPubkey: string) => Set<string>;
  flush: () => void;
  destroy: () => void;
} {
  const pendingByViewer = new Map<string, Set<string>>();
  let writeTimer: unknown = null;

  const flush = (): void => {
    if (writeTimer !== null) {
      scheduler.clearTimeout(writeTimer);
      writeTimer = null;
    }
    pendingByViewer.forEach((eventIds, viewerPubkey) => {
      if (markHomeFeedEventsSeen(viewerPubkey, [...eventIds], storage)) {
        pendingByViewer.delete(viewerPubkey);
      }
    });
  };

  return {
    mark(viewerPubkey, eventIds) {
      const validIds = eventIds.filter((eventId) => HEX_64.test(eventId));
      if (!storageKey(viewerPubkey) || validIds.length === 0) {
        return;
      }
      const pending = pendingByViewer.get(viewerPubkey) ?? new Set<string>();
      validIds.forEach((eventId) => {
        pending.delete(eventId);
        pending.add(eventId);
      });
      while (pending.size > HOME_FEED_SEEN_MAX_EVENTS) {
        const oldest = pending.values().next().value;
        if (!oldest) {
          break;
        }
        pending.delete(oldest);
      }
      pendingByViewer.set(viewerPubkey, pending);
      if (writeTimer === null) {
        writeTimer = scheduler.setTimeout(flush, HOME_FEED_SEEN_WRITE_DELAY_MS);
      }
    },
    read(viewerPubkey) {
      const pending = [...(pendingByViewer.get(viewerPubkey) ?? [])];
      const pendingIds = new Set(pending);
      const stored = readHomeFeedSeenEventIds(viewerPubkey, storage);
      return new Set([
        ...pending,
        ...[...stored].filter((eventId) => !pendingIds.has(eventId)),
      ].slice(0, HOME_FEED_SEEN_MAX_EVENTS));
    },
    flush,
    destroy() {
      flush();
      pendingByViewer.clear();
    },
  };
}
