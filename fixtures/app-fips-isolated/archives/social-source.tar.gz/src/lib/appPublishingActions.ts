import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { getSharedProfileRecord } from './profileCache';
import type { ComposerAttachment } from './media';
import type { NoteEngagement } from './noteEngagement';
import { ZERO_NOTE_ENGAGEMENT } from './noteEngagement';
import type { RawEvent } from './nostr';
import {
  canPublishFromAccount,
  createReplyNote,
  createReplyNoteAsync,
  createTextNote,
  createTextNoteAsync,
  createDeletionEventAsync,
  createReactionEventAsync,
  createRepostEventAsync,
  publishDeletion,
  publishEvent,
  publishReaction,
  publishRepost,
} from './nostrPublish';
import type { NoteThreadSnapshot } from './nostrIndex';
import type { RouteStackEntry } from './appStack';
import type { SocialAccount } from './accounts';
import type { createThreadReplyDraftStore } from './threadReplyDrafts';
import { buildNoteThreadReference } from './appSharing';

type ThreadReplyDraftStore = ReturnType<typeof createThreadReplyDraftStore>;

type PublishingActionDeps = {
  activeAccount: SocialAccount | null;
  composerAttachments: ComposerAttachment[];
  composerError: string;
  composerValue: string;
  displayedNoteEngagements: Map<string, NoteEngagement>;
  likePendingNoteIds: Set<string>;
  liveOverlayVersion: number;
  noteEngagements: Map<string, NoteEngagement>;
  pageError: string;
  repostPendingNoteIds: Set<string>;
  routeStack: RouteStackEntry[];
  threadPage: NoteThreadSnapshot | null;
  threadReplyAttachments: ComposerAttachment[];
  threadReplyDrafts: ThreadReplyDraftStore;
  threadReplyError: string;
  threadReplyValue: string;
  activeThreadReplyDraftKey: () => string | null;
  clearOptimisticLike: (noteId: string) => void;
  clearThreadReplyDraft: () => void;
  navigateHome: () => void;
  navigateThread: (target: string) => void;
  persistActiveThreadReplyDraft: () => void;
  prependLocalPost: (event: RawEvent) => void;
  prependThreadReply: (event: RawEvent) => void;
  pruneTombstonedLocalPosts: () => void;
  reportError: (fallbackMessage: string, error: unknown) => string;
  setOptimisticLike: (noteId: string) => void;
};

type ComposerSubmitPayload = {
  text: string;
  attachments: ComposerAttachment[];
};

function snapshotComposerDraft(text: string, attachments: ComposerAttachment[]): string {
  return JSON.stringify([text, attachments.map((attachment) => [
    attachment.id, attachment.fileName, attachment.mimeType, attachment.size,
    attachment.status, attachment.progress, attachment.url, attachment.nhash,
    attachment.hashHex, attachment.error,
  ])]);
}

export function buildComposerPostContent(
  text: string,
  attachments: ComposerAttachment[],
): string {
  const trimmedText = text.trim();
  const attachmentUrls = attachments
    .map((attachment) => attachment.url?.trim() ?? '')
    .filter((url): url is string => Boolean(url));
  const newAttachmentUrls = attachmentUrls.filter((url, index) => (
    attachmentUrls.indexOf(url) === index && !trimmedText.includes(url)
  ));

  if (!trimmedText) {
    return newAttachmentUrls.join('\n');
  }
  return newAttachmentUrls.length > 0
    ? `${trimmedText}\n\n${newAttachmentUrls.join('\n')}`
    : trimmedText;
}

export function createAppPublishingActions(deps: PublishingActionDeps) {
  const pendingDrafts = new Set<string>();
  function persistHomeDraft(): void {
    deps.threadReplyDrafts.write('home', {
      value: deps.composerValue,
      attachments: deps.composerAttachments,
      error: '',
    });
  }

  function handleComposerInput(value: string): void {
    deps.composerValue = value;
    deps.composerError = '';
    persistHomeDraft();
  }

  function bindComposerAttachments(ownerPubkey: string): (attachments: ComposerAttachment[]) => void {
    return (attachments) => {
      if (deps.activeAccount?.pubkey === ownerPubkey) { handleComposerAttachmentsChange(attachments); }
    };
  }

  function handleComposerAttachmentsChange(attachments: ComposerAttachment[]): void {
    deps.composerAttachments = attachments;
    deps.composerError = '';
    persistHomeDraft();
  }

  function isActiveThreadReplyDraft(key: string): boolean {
    return deps.activeThreadReplyDraftKey() === key;
  }

  function handleThreadReplyInput(key: string, value: string): void {
    if (!isActiveThreadReplyDraft(key)) {
      return;
    }
    deps.threadReplyValue = value;
    deps.threadReplyError = '';
    deps.persistActiveThreadReplyDraft();
  }

  function handleThreadReplyAttachmentsChange(
    key: string,
    ownerPubkey: string | null,
    attachments: ComposerAttachment[],
  ): void {
    if (
      ownerPubkey !== deps.activeAccount?.pubkey
      || !deps.routeStack.some((entry) => entry.key === key && entry.route.kind === 'thread')
    ) {
      return;
    }
    if (isActiveThreadReplyDraft(key)) {
      deps.threadReplyAttachments = attachments;
      deps.threadReplyError = '';
      deps.persistActiveThreadReplyDraft();
      return;
    }
    const draft = deps.threadReplyDrafts.read(key);
    deps.threadReplyDrafts.write(key, {
      value: draft?.value ?? '',
      attachments,
      error: '',
    });
  }

  function bindThreadReplyAttachments(
    key: string,
    ownerPubkey: string | null,
  ): (attachments: ComposerAttachment[]) => void {
    return (attachments) => {
      handleThreadReplyAttachmentsChange(key, ownerPubkey, attachments);
    };
  }

  async function handleCreatePostSubmit(payload: ComposerSubmitPayload): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    const content = buildComposerPostContent(payload.text, payload.attachments);
    if (!content) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.composerError = 'Read-only account.';
      return;
    }
    const pendingKey = `${account.pubkey}:home`;
    if (pendingDrafts.has(pendingKey)) {return;}
    pendingDrafts.add(pendingKey);
    deps.composerError = '';
    const submittedDraft = snapshotComposerDraft(payload.text, payload.attachments);
    try {
      const event = account.method === 'nip07'
        ? await createTextNoteAsync(account, content)
        : createTextNote(account, content);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
      publishEvent(event);
      deps.prependLocalPost(event);
      if (snapshotComposerDraft(deps.composerValue, deps.composerAttachments) === submittedDraft) {
        deps.composerValue = '';
        deps.composerAttachments = [];
        deps.threadReplyDrafts.delete('home');
      }
      deps.noteEngagements = new Map(deps.noteEngagements).set(event.id, {
        ...ZERO_NOTE_ENGAGEMENT,
      });
    } catch (error) {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        deps.composerError = deps.reportError("Couldn't publish the post.", error);
      }
    } finally {
      pendingDrafts.delete(pendingKey);
    }
  }

  async function handleThreadReplySubmit(key: string, payload: ComposerSubmitPayload): Promise<void> {
    const account = deps.activeAccount;
    if (!isActiveThreadReplyDraft(key) || !account || !deps.threadPage?.note) {
      return;
    }
    const content = buildComposerPostContent(payload.text, payload.attachments);
    if (!content) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.threadReplyError = 'Read-only account.';
      deps.persistActiveThreadReplyDraft();
      return;
    }
    const pendingKey = `${account.pubkey}:${key}`;
    if (pendingDrafts.has(pendingKey)) {return;}
    pendingDrafts.add(pendingKey);
    deps.threadReplyError = '';
    const submittedDraft = snapshotComposerDraft(payload.text, payload.attachments);
    try {
      const options = { root: deps.threadPage.root ?? null };
      const event = account.method === 'nip07'
        ? await createReplyNoteAsync(account, deps.threadPage.note, content, options)
        : createReplyNote(account, deps.threadPage.note, content, options);
      if (deps.activeAccount?.pubkey !== account.pubkey || !isActiveThreadReplyDraft(key)) {return;}
      publishEvent(event);
      contactMemoryStore.remember(deps.threadPage.note.pubkey, publicContactName(getSharedProfileRecord(deps.threadPage.note.pubkey)));
      deps.prependThreadReply(event);
      if (snapshotComposerDraft(deps.threadReplyValue, deps.threadReplyAttachments) === submittedDraft) {
        deps.clearThreadReplyDraft();
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey === account.pubkey && isActiveThreadReplyDraft(key)) {
        deps.threadReplyError = deps.reportError("Couldn't publish the reply.", error);
        deps.persistActiveThreadReplyDraft();
      }
    } finally {
      pendingDrafts.delete(pendingKey);
    }
  }

  function handleReplyAction(event: RawEvent): void {
    deps.navigateThread(buildNoteThreadReference(event));
  }

  async function handleDelete(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account || !canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (account.pubkey !== event.pubkey) {
      deps.pageError = 'You can only delete your own post.';
      return;
    }
    deps.pageError = '';
    try {
      if (account.method === 'nip07') {
        const signed = await createDeletionEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishDeletion(account, event); }
      deps.pruneTombstonedLocalPosts();
      deps.liveOverlayVersion += 1;
      if (deps.threadPage?.note?.id === event.id) {
        deps.navigateHome();
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      deps.pageError = deps.reportError("Couldn't delete the post.", error);
    }
  }

  async function handleLike(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (
      deps.likePendingNoteIds.has(event.id)
      || (deps.displayedNoteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted
    ) {
      return;
    }
    deps.likePendingNoteIds = new Set(deps.likePendingNoteIds).add(event.id);
    deps.pageError = '';
    try {
      if (account.method === 'nip07') {
        const signed = await createReactionEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishReaction(account, event); }
      contactMemoryStore.remember(event.pubkey, publicContactName(getSharedProfileRecord(event.pubkey)));
      deps.setOptimisticLike(event.id);
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      const nextPending = new Set(deps.likePendingNoteIds);
      nextPending.delete(event.id);
      deps.likePendingNoteIds = nextPending;
      deps.clearOptimisticLike(event.id);
      deps.pageError = deps.reportError("Couldn't send the like.", error);
      return;
    }
    const nextPending = new Set(deps.likePendingNoteIds);
    nextPending.delete(event.id);
    deps.likePendingNoteIds = nextPending;
  }

  async function handleRepost(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This account is read-only.';
      return;
    }
    if (deps.repostPendingNoteIds.has(event.id)) {
      return;
    }
    deps.repostPendingNoteIds = new Set(deps.repostPendingNoteIds).add(event.id);
    deps.pageError = '';
    try {
      if (account.method === 'nip07') {
        const signed = await createRepostEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishRepost(account, event); }
      contactMemoryStore.remember(event.pubkey, publicContactName(getSharedProfileRecord(event.pubkey)));
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      deps.pageError = deps.reportError("Couldn't repost this note.", error);
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.repostPendingNoteIds);
        nextPending.delete(event.id);
        deps.repostPendingNoteIds = nextPending;
      }
    }
  }

  return {
    bindComposerAttachments,
    bindThreadReplyAttachments,
    handleComposerAttachmentsChange,
    handleComposerInput,
    handleCreatePostSubmit,
    handleDelete,
    handleLike,
    handleReplyAction,
    handleRepost,
    handleThreadReplyInput,
    handleThreadReplySubmit,
  };
}
