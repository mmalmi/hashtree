import type { AppError, ReportAppError } from './appError';
import { contactMemoryStore, publicContactName } from './contactMemoryStore';
import { getSharedProfileRecord } from './profileCache';
import type { ComposerAttachment } from './media';
import type { NoteEngagement } from './noteEngagement';
import { ZERO_NOTE_ENGAGEMENT } from './noteEngagement';
import type { RawEvent } from './nostr';
import {
  canPublishFromAccount,
  createReplyNote,
  createReplyNoteAsync,
  createTextNote,
  createTextNoteAsync,
  createDeletionEventAsync,
  createReactionEventAsync,
  createRepostEventAsync,
  publishDeletion,
  publishEvent,
  publishReaction,
  publishRepost,
} from './nostrPublish';
import type { NoteThreadSnapshot } from './nostrIndex';
import type { RouteStackEntry } from './appStack';
import { usesExternalSigner, type SocialAccount } from './accounts';
import type { createThreadReplyDraftStore } from './threadReplyDrafts';
import { buildNoteThreadReference } from './appSharing';
import {
  buildComposerOptionTags,
  composerOptionsStore,
  snapshotComposerOptions,
  type ComposerSubmitPayload,
} from './composerOptions';

type ThreadReplyDraftStore = ReturnType<typeof createThreadReplyDraftStore>;

type PublishingActionDeps = {
  activeAccount: SocialAccount | null;
  composerAttachments: ComposerAttachment[];
  composerError: AppError;
  composerValue: string;
  displayedNoteEngagements: Map<string, NoteEngagement>;
  likePendingNoteIds: Set<string>;
  liveOverlayVersion: number;
  noteEngagements: Map<string, NoteEngagement>;
  pageError: AppError;
  repostPendingNoteIds: Set<string>;
  routeStack: RouteStackEntry[];
  threadPage: NoteThreadSnapshot | null;
  threadReplyAttachments: ComposerAttachment[];
  threadReplyDrafts: ThreadReplyDraftStore;
  threadReplyError: AppError;
  threadReplyValue: string;
  activeThreadReplyDraftKey: () => string | null;
  clearOptimisticLike: (noteId: string) => void;
  clearThreadReplyDraft: () => void;
  navigateHome: () => void;
  navigateThread: (target: string) => void;
  persistActiveThreadReplyDraft: () => void;
  prependLocalPost: (event: RawEvent) => void;
  prependThreadReply: (event: RawEvent) => void;
  pruneTombstonedLocalPosts: () => void;
  reportError: ReportAppError;
  setOptimisticLike: (noteId: string) => void;
};

function snapshotComposerDraft(
  text: string,
  attachments: ComposerAttachment[],
  options: Pick<ComposerSubmitPayload, 'expirationDelta' | 'geohash'>,
): string {
  return JSON.stringify([text, attachments.map((attachment) => [
    attachment.id, attachment.fileName, attachment.mimeType, attachment.size,
    attachment.status, attachment.progress, attachment.url, attachment.nhash,
    attachment.hashHex, attachment.error,
  ]), snapshotComposerOptions(options)]);
}

export function buildComposerPostContent(
  text: string,
  attachments: ComposerAttachment[],
): string {
  const trimmedText = text.trim();
  const attachmentUrls = attachments
    .map((attachment) => attachment.url?.trim() ?? '')
    .filter((url): url is string => Boolean(url));
  const newAttachmentUrls = attachmentUrls.filter((url, index) => (
    attachmentUrls.indexOf(url) === index && !trimmedText.includes(url)
  ));

  if (!trimmedText) {
    return newAttachmentUrls.join('\n');
  }
  return newAttachmentUrls.length > 0
    ? `${trimmedText}\n\n${newAttachmentUrls.join('\n')}`
    : trimmedText;
}

export function createAppPublishingActions(deps: PublishingActionDeps) {
  const pendingDrafts = new Set<string>();
  function persistHomeDraft(): void {
    deps.threadReplyDrafts.write('home', {
      value: deps.composerValue,
      attachments: deps.composerAttachments,
      error: '',
    });
  }

  function handleComposerInput(value: string): void {
    deps.composerValue = value;
    deps.composerError = '';
    persistHomeDraft();
  }

  function bindComposerAttachments(ownerPubkey: string): (attachments: ComposerAttachment[]) => void {
    return (attachments) => {
      if (deps.activeAccount?.pubkey === ownerPubkey) { handleComposerAttachmentsChange(attachments); }
    };
  }

  function handleComposerAttachmentsChange(attachments: ComposerAttachment[]): void {
    deps.composerAttachments = attachments;
    deps.composerError = '';
    persistHomeDraft();
  }

  function isActiveThreadReplyDraft(key: string): boolean {
    return deps.activeThreadReplyDraftKey() === key;
  }

  function handleThreadReplyInput(key: string, value: string): void {
    if (!isActiveThreadReplyDraft(key)) {
      return;
    }
    deps.threadReplyValue = value;
    deps.threadReplyError = '';
    deps.persistActiveThreadReplyDraft();
  }

  function handleThreadReplyAttachmentsChange(
    key: string,
    ownerPubkey: string | null,
    attachments: ComposerAttachment[],
  ): void {
    if (
      ownerPubkey !== deps.activeAccount?.pubkey
      || !deps.routeStack.some((entry) => entry.key === key && entry.route.kind === 'thread')
    ) {
      return;
    }
    if (isActiveThreadReplyDraft(key)) {
      deps.threadReplyAttachments = attachments;
      deps.threadReplyError = '';
      deps.persistActiveThreadReplyDraft();
      return;
    }
    const draft = deps.threadReplyDrafts.read(key);
    deps.threadReplyDrafts.write(key, {
      value: draft?.value ?? '',
      attachments,
      error: '',
    });
  }

  function bindThreadReplyAttachments(
    key: string,
    ownerPubkey: string | null,
  ): (attachments: ComposerAttachment[]) => void {
    return (attachments) => {
      handleThreadReplyAttachmentsChange(key, ownerPubkey, attachments);
    };
  }

  async function handleCreatePostSubmit(payload: ComposerSubmitPayload): Promise<RawEvent | null> {
    const account = deps.activeAccount;
    if (!account) {
      return null;
    }
    const content = buildComposerPostContent(payload.text, payload.attachments);
    if (!content) {
      return null;
    }
    if (!canPublishFromAccount(account)) {
      deps.composerError = 'Read-only profile.';
      return null;
    }
    const pendingKey = `${account.pubkey}:home`;
    if (pendingDrafts.has(pendingKey)) {return null;}
    pendingDrafts.add(pendingKey);
    deps.composerError = '';
    const submittedDraft = snapshotComposerDraft(payload.text, payload.attachments, payload);
    const optionTags = buildComposerOptionTags(payload);
    try {
      const event = usesExternalSigner(account)
        ? await createTextNoteAsync(account, content, optionTags)
        : createTextNote(account, content, optionTags);
      if (deps.activeAccount?.pubkey !== account.pubkey) {return null;}
      publishEvent(event);
      deps.prependLocalPost(event);
      const clearedDraft = snapshotComposerDraft(
        deps.composerValue,
        deps.composerAttachments,
        composerOptionsStore.read(`${account.pubkey}:home`),
      ) === submittedDraft;
      if (clearedDraft) {
        deps.composerValue = '';
        deps.composerAttachments = [];
        deps.threadReplyDrafts.delete('home');
      }
      deps.noteEngagements = new Map(deps.noteEngagements).set(event.id, {
        ...ZERO_NOTE_ENGAGEMENT,
      });
      return clearedDraft ? event : null;
    } catch (error) {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        deps.composerError = deps.reportError("Couldn't publish the post.", error, [payload.text, content]);
      }
      return null;
    } finally {
      pendingDrafts.delete(pendingKey);
    }
  }

  async function handleThreadReplySubmit(key: string, payload: ComposerSubmitPayload): Promise<void> {
    const account = deps.activeAccount;
    if (!isActiveThreadReplyDraft(key) || !account || !deps.threadPage?.note) {
      return;
    }
    const content = buildComposerPostContent(payload.text, payload.attachments);
    if (!content) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.threadReplyError = 'Read-only profile.';
      deps.persistActiveThreadReplyDraft();
      return;
    }
    const pendingKey = `${account.pubkey}:${key}`;
    if (pendingDrafts.has(pendingKey)) {return;}
    pendingDrafts.add(pendingKey);
    deps.threadReplyError = '';
    const submittedDraft = snapshotComposerDraft(payload.text, payload.attachments, payload);
    try {
      const options = { root: deps.threadPage.root ?? null, extraTags: buildComposerOptionTags(payload) };
      const event = usesExternalSigner(account)
        ? await createReplyNoteAsync(account, deps.threadPage.note, content, options)
        : createReplyNote(account, deps.threadPage.note, content, options);
      if (deps.activeAccount?.pubkey !== account.pubkey || !isActiveThreadReplyDraft(key)) {return;}
      publishEvent(event);
      contactMemoryStore.remember(deps.threadPage.note.pubkey, publicContactName(getSharedProfileRecord(deps.threadPage.note.pubkey)));
      deps.prependThreadReply(event);
      const currentDraft = snapshotComposerDraft(
        deps.threadReplyValue,
        deps.threadReplyAttachments,
        composerOptionsStore.read(`${account.pubkey}:${key}`),
      );
      if (currentDraft === submittedDraft) {
        deps.clearThreadReplyDraft();
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey === account.pubkey && isActiveThreadReplyDraft(key)) {
        deps.threadReplyError = deps.reportError("Couldn't publish the reply.", error, [payload.text, content]);
        deps.persistActiveThreadReplyDraft();
      }
    } finally {
      pendingDrafts.delete(pendingKey);
    }
  }

  function handleReplyAction(event: RawEvent): void {
    deps.navigateThread(buildNoteThreadReference(event));
  }

  async function handleDelete(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account || !canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    if (account.pubkey !== event.pubkey) {
      deps.pageError = 'You can only delete your own post.';
      return;
    }
    deps.pageError = '';
    try {
      if (usesExternalSigner(account)) {
        const signed = await createDeletionEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishDeletion(account, event); }
      deps.pruneTombstonedLocalPosts();
      deps.liveOverlayVersion += 1;
      if (deps.threadPage?.note?.id === event.id) {
        deps.navigateHome();
      }
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      deps.pageError = deps.reportError("Couldn't delete the post.", error);
    }
  }

  async function handleLike(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    if (
      deps.likePendingNoteIds.has(event.id)
      || (deps.displayedNoteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted
    ) {
      return;
    }
    deps.likePendingNoteIds = new Set(deps.likePendingNoteIds).add(event.id);
    deps.pageError = '';
    try {
      if (usesExternalSigner(account)) {
        const signed = await createReactionEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishReaction(account, event); }
      contactMemoryStore.remember(event.pubkey, publicContactName(getSharedProfileRecord(event.pubkey)));
      deps.setOptimisticLike(event.id);
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      const nextPending = new Set(deps.likePendingNoteIds);
      nextPending.delete(event.id);
      deps.likePendingNoteIds = nextPending;
      deps.clearOptimisticLike(event.id);
      deps.pageError = deps.reportError("Couldn't send the like.", error);
      return;
    }
    const nextPending = new Set(deps.likePendingNoteIds);
    nextPending.delete(event.id);
    deps.likePendingNoteIds = nextPending;
  }

  // Live projection may lag a fresh repost; one account reposts a note once.
  const publishedRepostKeys = new Set<string>();

  async function handleRepost(event: RawEvent): Promise<void> {
    const account = deps.activeAccount;
    if (!account) {
      return;
    }
    if (!canPublishFromAccount(account)) {
      deps.pageError = 'This profile is read-only.';
      return;
    }
    const repostKey = `${account.pubkey}:${event.id}`;
    if (
      deps.repostPendingNoteIds.has(event.id)
      || publishedRepostKeys.has(repostKey)
      || (deps.displayedNoteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).repostAuthors.includes(account.pubkey)
    ) {
      return;
    }
    deps.repostPendingNoteIds = new Set(deps.repostPendingNoteIds).add(event.id);
    deps.pageError = '';
    try {
      if (usesExternalSigner(account)) {
        const signed = await createRepostEventAsync(account, event);
        if (deps.activeAccount?.pubkey !== account.pubkey) {return;}
        publishEvent(signed);
      } else { publishRepost(account, event); }
      publishedRepostKeys.add(repostKey);
      contactMemoryStore.remember(event.pubkey, publicContactName(getSharedProfileRecord(event.pubkey)));
    } catch (error) {
      if (deps.activeAccount?.pubkey !== account.pubkey) { return; }
      deps.pageError = deps.reportError("Couldn't repost this note.", error);
    } finally {
      if (deps.activeAccount?.pubkey === account.pubkey) {
        const nextPending = new Set(deps.repostPendingNoteIds);
        nextPending.delete(event.id);
        deps.repostPendingNoteIds = nextPending;
      }
    }
  }

  return {
    bindComposerAttachments,
    bindThreadReplyAttachments,
    handleComposerAttachmentsChange,
    handleComposerInput,
    handleCreatePostSubmit,
    handleDelete,
    handleLike,
    handleReplyAction,
    handleRepost,
    handleThreadReplyInput,
    handleThreadReplySubmit,
  };
}
