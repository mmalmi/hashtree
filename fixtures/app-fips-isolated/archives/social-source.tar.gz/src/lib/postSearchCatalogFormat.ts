import { HashTree, LinkType, type CID, type Store } from '@hashtree/core';
import { throwIfPostSearchAborted } from './postSearchAbort';

const MANIFEST_ENTRY = 'manifest.json';
const MAX_MANIFEST_BYTES = 1_048_576;
const decoder = new TextDecoder('utf-8', { fatal: true });

/** Read only the authenticated catalog envelope needed for an explicit format dispatch. */
export async function readPostSearchCatalogFormat(
  store: Store,
  root: CID,
  signal: AbortSignal | null = null,
): Promise<string> {
  throwIfPostSearchAborted(signal);
  const tree = new HashTree({ store });
  const entries = await tree.listDirectory(root);
  throwIfPostSearchAborted(signal);
  const manifest = entries.find((entry) => entry.name === MANIFEST_ENTRY);
  if (!manifest || (manifest.type !== LinkType.File && manifest.type !== LinkType.Blob)) {
    throw new Error('Post search catalog manifest is missing');
  }
  const bytes = await tree.readFile(manifest.cid, { maxBytes: MAX_MANIFEST_BYTES });
  throwIfPostSearchAborted(signal);
  if (!bytes) {throw new Error('Post search catalog manifest is unreadable');}
  let value: unknown;
  try {value = JSON.parse(decoder.decode(bytes));} catch {
    throw new Error('Invalid post search catalog manifest JSON');
  }
  if (!isRecord(value) || typeof value.format !== 'string' || !value.format) {
    throw new Error('Invalid post search catalog format');
  }
  return value.format;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
