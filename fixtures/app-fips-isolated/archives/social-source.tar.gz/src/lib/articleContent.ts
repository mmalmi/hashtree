import MarkdownIt from 'markdown-it';
import { parseHashtreeAttachment, safeExternalUrl } from './mediaUrls';
import { parseNoteContent, type NoteEmbed } from './noteContent';
import { profileHref, searchHref, threadHref } from './routes';

const markdown = new MarkdownIt({ html: false, linkify: true, maxNesting: 32 });
const tags = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'blockquote',
  'em', 'strong', 's', 'table', 'thead', 'tbody', 'tr', 'th', 'td'] as const;
type ArticleTag = typeof tags[number];
type ImageEmbed = Extract<NoteEmbed, { kind: 'image' }>;
const hasControlCharacters = (value: string) => [...value].some(char => char.charCodeAt(0) < 32 || char.charCodeAt(0) === 127);
export type ArticleLink = { href: string; external: boolean; pubkey?: string; reference?: string };
export type ArticleNode =
  | { type: 'text'; text: string }
  | { type: 'code'; text: string; block: boolean }
  | { type: 'break' | 'rule' }
  | { type: 'image'; embed: ImageEmbed; alt: string; title?: string }
  | { type: 'link'; link: ArticleLink; children: ArticleNode[]; title?: string; mention?: boolean }
  | { type: 'element'; tag: ArticleTag; children: ArticleNode[]; start?: number };

/** Article URLs have no document base. Reject executable and ambiguous relative URLs. */
export function articleLink(raw: string): ArticleLink | null {
  const value = raw.trim();
  if (hasControlCharacters(value)) { return null; }
  const http = safeExternalUrl(value);
  if (http && ['http:', 'https:'].includes(http.protocol)) {
    return { href: http.href, external: true };
  }
  if (/^mailto:/i.test(value)) { return { href: value, external: true }; }
  if (/^nostr:/i.test(value)) {
    const segments = parseNoteContent(value);
    const segment = segments.length === 1 ? segments[0] : null;
    if (segment?.type === 'mention') {
      return { href: profileHref(segment.pubkey), external: false, pubkey: segment.pubkey };
    }
    if (segment?.type === 'event-ref') {
      return { href: threadHref(segment.bech32), external: false, reference: segment.bech32 };
    }
  }
  return null;
}

export function articleImage(raw: string): ImageEmbed | null {
  const value = raw.trim();
  if (hasControlCharacters(value)) { return null; }
  const http = safeExternalUrl(value);
  if (http && ['http:', 'https:'].includes(http.protocol)) {
    return { kind: 'image', url: http.href };
  }
  const attachment = parseHashtreeAttachment(value);
  return attachment ? { kind: 'image', url: value, isHashtree: true, filename: attachment.filename } : null;
}

function textNodes(text: string, inLink: boolean): ArticleNode[] {
  if (inLink) { return [{ type: 'text', text }]; }
  return parseNoteContent(text).flatMap((segment): ArticleNode[] => {
    if (segment.type === 'mention') {
      return [{ type: 'link', link: { href: profileHref(segment.pubkey), external: false, pubkey: segment.pubkey },
        children: [{ type: 'text', text: segment.label }], mention: true }];
    }
    if (segment.type === 'event-ref') {
      return [{ type: 'link', link: { href: threadHref(segment.bech32), external: false, reference: segment.bech32 },
        children: [{ type: 'text', text: segment.label }] }];
    }
    if (segment.type === 'hashtag') {
      return [{ type: 'link', link: { href: searchHref(`#${segment.tag}`, 'posts'), external: false },
        children: [{ type: 'text', text: `#${segment.tag}` }] }];
    }
    if (segment.type === 'link' || segment.type === 'attachment') {
      return [{ type: 'text', text: segment.urls.join(' ') }];
    }
    return [{ type: 'text', text: segment.type === 'emoji' ? `:${segment.shortcode}:` : segment.text }];
  });
}

/** Markdown-it owns Markdown parsing; only this fixed Svelte-rendered vocabulary is admitted. */
function tokenNodes(tokens: ReturnType<typeof markdown.parse>, insideLink = false): ArticleNode[] {
  const result: ArticleNode[] = [];
  const stack: Array<{ children: ArticleNode[]; inLink: boolean }> = [{ children: result, inLink: insideLink }];
  for (const token of tokens) {
    if (token.hidden) { continue; }
    const current = stack.at(-1)!;
    if (token.nesting === -1) {
      if (stack.length > 1) { stack.pop(); }
    } else if (token.nesting === 1) {
      const children: ArticleNode[] = [];
      if (token.type === 'link_open') {
        const link = articleLink(String(token.attrGet('href') ?? ''));
        if (link) { current.children.push({ type: 'link', link, children, title: token.attrGet('title')?.toString() }); }
        else { current.children.push({ type: 'element', tag: 'em', children }); }
      } else if ((tags as readonly string[]).includes(token.tag)) {
        const start = token.tag === 'ol' ? Number(token.attrGet('start') ?? 1) : undefined;
        current.children.push({ type: 'element', tag: token.tag as ArticleTag, children,
          start: start !== undefined && Number.isSafeInteger(start) ? start : undefined });
      }
      stack.push({ children, inLink: current.inLink || token.type === 'link_open' });
    } else if (token.type === 'inline') {
      current.children.push(...tokenNodes(token.children ?? [], current.inLink));
    } else if (token.type === 'text') {
      current.children.push(...textNodes(token.content, current.inLink));
    } else if (token.type === 'code_inline' || token.type === 'code_block' || token.type === 'fence') {
      current.children.push({ type: 'code', text: token.content, block: token.type !== 'code_inline' });
    } else if (token.type === 'image') {
      const embed = articleImage(String(token.attrGet('src') ?? ''));
      const alt = markdown.renderer.renderInlineAsText(token.children ?? [], markdown.options, {});
      current.children.push(embed ? { type: 'image', embed, alt, title: token.attrGet('title')?.toString() }
        : { type: 'text', text: alt });
    } else if (token.type === 'softbreak') {
      current.children.push({ type: 'text', text: '\n' });
    } else if (token.type === 'hardbreak' || token.type === 'hr') {
      current.children.push({ type: token.type === 'hr' ? 'rule' : 'break' });
    } else if (token.content) {
      current.children.push({ type: 'text', text: token.content });
    }
  }
  return result;
}

export function parseArticleContent(content: string): ArticleNode[] {
  return tokenNodes(markdown.parse(content, {}));
}

export function articleImages(nodes: ArticleNode[]): ImageEmbed[] {
  const images = new Map<string, ImageEmbed>();
  const visit = (entries: ArticleNode[]) => {
    for (const node of entries) {
      if (node.type === 'image') { images.set(node.embed.url, node.embed); }
      else if ('children' in node) { visit(node.children); }
    }
  };
  visit(nodes);
  return [...images.values()];
}
