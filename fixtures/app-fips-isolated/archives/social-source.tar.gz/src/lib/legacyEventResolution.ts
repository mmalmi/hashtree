import type { CollectionSource } from '@hashtree/collection';
import type { CID } from '@hashtree/core';
import {
  MANIFEST_BY_AUTHOR_KIND_TIME,
  MANIFEST_BY_AUTHOR_TIME,
} from '@hashtree/nostr';
import { isHexEventId, isHexPubkey, type RawEvent } from './nostr';
import { getVerifiedEmbeddedRepostTarget } from './repostPresentation';
import { timeAndEventIdFromIndexKey } from './recentTextNoteCursor';

type ResolveLegacyNeventOptions = {
  source: CollectionSource;
  eventId: string;
  author: string | null;
  kind: number | null;
  readEvent: (cid: CID) => Promise<RawEvent | null>;
  loadTaggedEvents: (
    tagName: string,
    tagValue: string,
    options: { kinds: number[]; limit: number },
  ) => Promise<RawEvent[]>;
};

function hasIndex(source: CollectionSource, indexName: string): boolean {
  return Boolean(source.manifest.indexes[indexName]?.root);
}

function padKind(kind: number): string {
  return kind.toString(16).padStart(8, '0');
}

async function resolveEmbeddedRepostTarget(
  options: ResolveLegacyNeventOptions,
): Promise<RawEvent | null> {
  const wrappers = await options.loadTaggedEvents('e', options.eventId, {
    kinds: [6],
    limit: 16,
  });
  for (const wrapper of wrappers) {
    const target = getVerifiedEmbeddedRepostTarget(wrapper);
    if (
      target?.id === options.eventId
      && (!options.author || target.pubkey === options.author)
      && (options.kind === null || target.kind === options.kind)
    ) {
      return target;
    }
  }
  return null;
}

async function resolveFromAuthorIndex(
  options: ResolveLegacyNeventOptions,
): Promise<RawEvent | null> {
  const { author, eventId, kind, source } = options;
  if (!author || !isHexEventId(eventId) || !isHexPubkey(author)) {
    return null;
  }

  const plans: Array<{ indexName: string; prefix: string }> = [];
  if (
    kind !== null
    && Number.isSafeInteger(kind)
    && kind >= 0
    && hasIndex(source, MANIFEST_BY_AUTHOR_KIND_TIME)
  ) {
    plans.push({
      indexName: MANIFEST_BY_AUTHOR_KIND_TIME,
      prefix: `${author}:${padKind(kind)}:`,
    });
  }
  if (hasIndex(source, MANIFEST_BY_AUTHOR_TIME)) {
    plans.push({ indexName: MANIFEST_BY_AUTHOR_TIME, prefix: `${author}:` });
  }

  for (const { indexName, prefix } of plans) {
    for await (const { key, cid } of source.streamQueryIndex(indexName, { prefix })) {
      if (timeAndEventIdFromIndexKey(key).eventId !== eventId) {
        continue;
      }
      const event = await options.readEvent(cid);
      if (
        event
        && event.id === eventId
        && event.pubkey === author
        && (kind === null || event.kind === kind)
      ) {
        return event;
      }
    }
  }
  return null;
}

/**
 * Compatibility lookup for authenticated legacy roots whose useful secondary
 * indexes predate a complete by-id collection. It never queries relay content.
 */
export async function resolveLegacyNevent(
  options: ResolveLegacyNeventOptions,
): Promise<RawEvent | null> {
  return await resolveEmbeddedRepostTarget(options)
    ?? await resolveFromAuthorIndex(options);
}
