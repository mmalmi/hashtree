import { writable, type Readable } from 'svelte/store';

export type ReactiveState<T extends object> = T & Readable<T>;

let reactiveBatchDepth = 0;
const pendingReactiveNotifications = new Set<() => void>();

/**
 * Apply a group of synchronous state writes while notifying each affected
 * state slice only once. Reads inside the callback still see every write.
 */
export function batchReactiveState<Result>(callback: () => Result): Result {
  reactiveBatchDepth += 1;
  try {
    return callback();
  } finally {
    reactiveBatchDepth -= 1;
    if (reactiveBatchDepth === 0) {
      const notifications = [...pendingReactiveNotifications];
      pendingReactiveNotifications.clear();
      for (const notify of notifications) {
        notify();
      }
    }
  }
}

export function createReactiveState<T extends object>(
  initial: T,
  options: { silentProperties?: ReadonlySet<keyof T> } = {},
): ReactiveState<T> {
  const target = { ...initial };
  const store = writable(target);
  const notify = () => store.set(target);
  const silentProperties = options.silentProperties ?? new Set<keyof T>();
  const proxy = new Proxy(target as ReactiveState<T>, {
    get(current, property, receiver) {
      if (property === 'subscribe') {
        return store.subscribe;
      }
      return Reflect.get(current, property, receiver);
    },
    set(current, property, value, receiver) {
      const previous = Reflect.get(current, property, receiver);
      const changed = Reflect.set(current, property, value, receiver);
      if (
        changed
        && !Object.is(previous, value)
        && !silentProperties.has(property as keyof T)
      ) {
        if (reactiveBatchDepth > 0) {
          pendingReactiveNotifications.add(notify);
        } else {
          notify();
        }
      }
      return changed;
    },
  });
  return proxy;
}

export function createReactiveDeps<
  State extends object,
  Extra extends object,
>(state: State, extra: Extra): State & Extra {
  return new Proxy(extra as State & Extra, {
    get(current, property, receiver) {
      return Reflect.has(current, property)
        ? Reflect.get(current, property, receiver)
        : Reflect.get(state, property, state);
    },
    set(current, property, value, receiver) {
      return Reflect.has(state, property)
        ? Reflect.set(state, property, value, state)
        : Reflect.set(current, property, value, receiver);
    },
    has(current, property) {
      return Reflect.has(current, property) || Reflect.has(state, property);
    },
  });
}

type UnionToIntersection<Value> = (
  Value extends unknown ? (value: Value) => void : never
) extends (value: infer Intersection) => void
  ? Intersection
  : never;

export function combineReactiveStates<States extends readonly object[]>(
  ...states: States
): UnionToIntersection<States[number]> {
  const ownerByProperty = new Map<PropertyKey, object>();
  for (const state of states) {
    for (const property of Reflect.ownKeys(state)) {
      if (ownerByProperty.has(property)) {
        throw new Error(`Reactive state property has multiple owners: ${String(property)}`);
      }
      ownerByProperty.set(property, state);
    }
  }
  return new Proxy({}, {
    get(_current, property) {
      const state = ownerByProperty.get(property);
      return state ? Reflect.get(state, property, state) : undefined;
    },
    set(_current, property, value) {
      const state = ownerByProperty.get(property);
      return state ? Reflect.set(state, property, value, state) : false;
    },
    has(_current, property) {
      return ownerByProperty.has(property);
    },
  }) as UnionToIntersection<States[number]>;
}
