import type { ReportAppError } from './appError';
import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import type { AppCombinedState } from './appState';
import { createOptimisticThreadSnapshot, loadThreadViewData } from './appThreadLoader';
import { getRootNhash, loadEventById, loadProfilesForPubkeys } from './nostrIndex';
import type { ProfileRecord, RawEvent } from './nostr';
import { getEventIdFromReference, getThreadParentReference } from './nostr';
import { routedEventsByTag } from './routedEventReads';
import { getDirectThreadParentTargetKey } from './threadTree';
import { mergeProfileMaps } from './profileRecords';
import { loadRoutedRepliesForEventPage } from './routedThreadReplies';
import type { ShadowReadScope } from './shadowReadComparator';

const THREAD_REPLY_KINDS = [1, 1_111] as const;
const THREAD_REPLY_READ_LIMIT = 100;

type ShadowReadOptions = {
  scope: ShadowReadScope;
  sharedRoot: CID;
  roots: readonly CID[];
  events: readonly RawEvent[];
  profiles?: readonly (ProfileRecord | null | undefined)[];
};

type ThreadHydrationDeps = {
  state: AppCombinedState;
  applyCachedRoot: (root: CID) => boolean;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  clearProfileViewState: () => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  hydrateNoteEngagements: (
    roots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  reportError: ReportAppError;
  resetThreadReplyPagination: () => void;
  scheduleShadowReadComparison: (options: ShadowReadOptions) => void;
  seedEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppThreadHydrationController(deps: ThreadHydrationDeps) {
  const { state } = deps;

  /**
   * Without an archive root, or after loading failed, read the post, its parent
   * and recent replies through the ordinary router: cache, Hashtree index and relays.
   */
  async function hydrateThreadDirect(currentRoot: CID | null, ref: string, token: number): Promise<boolean> {
    const eventId = state.threadPage?.note?.id ?? getEventIdFromReference(ref);
    if (!eventId) {return false;}
    const roots = currentRoot ? [currentRoot] : [];
    try {
      const needsNote = !state.threadPage?.note;
      const [found, replies] = await Promise.all([
        needsNote ? loadEventById(roots, eventId) : Promise.resolve(null),
        routedEventsByTag(roots, 'e', eventId, THREAD_REPLY_KINDS, THREAD_REPLY_READ_LIMIT),
      ]);
      if (token !== state.loadToken) {return false;}
      const note = state.threadPage?.note ?? found;
      if (!note) {return false;}
      const directReplies = (replies as RawEvent[])
        .filter((event) => getDirectThreadParentTargetKey(event) === `e:${note.id}`);
      if (needsNote) {
        const parentRef = getThreadParentReference(note);
        const parentId = parentRef ? getEventIdFromReference(parentRef) ?? parentRef : null;
        const parent = parentId
          ? deps.getKnownNoteByRef(parentId) ?? await loadEventById(roots, parentId).catch(() => null)
          : null;
        if (token !== state.loadToken) {return false;}
        state.threadPage = createOptimisticThreadSnapshot(currentRoot, note, parent);
        state.pageError = '';
        state.loading = false;
        state.threadLoading = false;
        deps.cacheKnownNotes([note], parent ? [parent] : []);
      }
      const known = new Set(state.threadReplies.map((event) => event.id));
      const added = directReplies.filter((event) => !known.has(event.id));
      if (added.length > 0) {
        state.threadReplies = mergeNotesByNewest(state.threadReplies, added);
        deps.cacheKnownNotes(added);
      }
      const noteIds = [note.id, ...added.map((event) => event.id)];
      deps.seedEmptyEngagements(noteIds);
      void deps.hydrateNoteEngagements(state.threadRoots.length ? state.threadRoots : roots, noteIds, token);
      return true;
    } catch (error) {
      console.warn('Failed to read thread', error);
      return false;
    }
  }

  async function hydrateThread(currentRoot: CID | null, ref: string, token: number): Promise<void> {
    if (token !== state.loadToken) {return;}
    state.threadLoading = true;
    const knownNote = deps.getKnownNoteByRef(ref);
    const parentRef = knownNote ? getThreadParentReference(knownNote) : null;
    const knownParent = parentRef ? deps.getKnownNoteByRef(parentRef) : null;
    let primaryCommitted = Boolean(knownNote && state.threadPage?.note?.id === knownNote.id);

    if (!knownNote) {
      clearThreadContent();
    } else if (!state.threadPage?.note || state.threadPage.note.id !== knownNote.id) {
      state.threadPage = createOptimisticThreadSnapshot(currentRoot, knownNote, knownParent);
      state.threadReplies = [];
      deps.resetThreadReplyPagination();
      state.feed = null;
      deps.clearProfileViewState();
      state.loading = false;
    }

    // A saved/previously verified note is usable even while its remote index
    // is unavailable. Keep local replies and never start index reads without a root.
    if (!currentRoot) {
      state.threadLoading = false;
      // Without an archive root the post can still come from the cache or relays.
      void hydrateThreadDirect(null, ref, token);
      if (knownNote) {
        state.pageError = '';
        state.rootError = '';
        state.threadRoots = [];
        state.threadPersonalRoot = null;
        state.threadReplyCursor = null;
        state.durableThreadRepliesHasMore = false;
        deps.seedEmptyEngagements([knownNote.id]);
      }
      return;
    }

    let hydratedEngagementKey = '';
    const hydrateEngagementsOnce = (roots: CID[], noteIds: string[]) => {
      const key = `${roots.map(getRootNhash).join('|')}:${noteIds.join(',')}`;
      if (!noteIds.length || key === hydratedEngagementKey) {return;}
      hydratedEngagementKey = key;
      deps.seedEmptyEngagements(noteIds);
      void deps.hydrateNoteEngagements(roots, noteIds, token);
    };

    try {
      const loaded = await loadThreadViewData({
        currentRoot,
        ref,
        knownNote,
        knownParent,
        profilePersonalRoot: state.profilePersonalRoot,
        viewerPersonalRoot: state.viewerPersonalRoot,
        cachedProfiles: new Map(state.threadProfiles),
        replyLimit: state.threadReplyFetchLimit,
        onPrimary: (primary) => {
          if (token !== state.loadToken) {return;}
          if (getRootNhash(primary.resolvedRoot) !== getRootNhash(currentRoot)) {
            deps.applyCachedRoot(primary.resolvedRoot);
          }
          state.threadRoots = primary.threadRoots;
          state.threadPage = primary.snapshot;
          state.threadReplies = [];
          state.durableThreadRepliesHasMore = false;
          deps.cacheKnownNotes(
            primary.snapshot.note ? [primary.snapshot.note] : [],
            primary.snapshot.context,
          );
          deps.clearProfileViewState();
          state.feed = null;
          state.loading = false;
          state.threadLoading = false;
          primaryCommitted = Boolean(primary.snapshot.note);
        },
        onReplies: (update) => {
          if (token !== state.loadToken) {return;}
          state.threadPersonalRoot = update.threadPersonalRoot;
          state.threadRoots = update.threadRoots;
          state.threadReplyCursor = update.replyCursor;
          state.threadPage = update.snapshot;
          state.threadReplies = update.replies;
          state.durableThreadRepliesHasMore = update.repliesHasMore;
          const noteIds = [
            ...(update.snapshot.note ? [update.snapshot.note.id] : []),
            ...update.replies.map((event) => event.id),
          ];
          deps.cacheKnownNotes(
            update.snapshot.note ? [update.snapshot.note] : [],
            update.snapshot.context,
            update.replies,
          );
          hydrateEngagementsOnce(update.threadRoots, noteIds);
          state.loading = false;
          state.threadLoading = false;
          primaryCommitted = Boolean(update.snapshot.note);
        },
        onProfiles: (profiles) => {
          if (token !== state.loadToken) {return;}
          state.threadProfiles = profiles;
          deps.mergeCachedProfiles(profiles);
        },
      });
      if (token !== state.loadToken) {return;}
      if (getRootNhash(loaded.resolvedRoot) !== getRootNhash(currentRoot)) {
        deps.applyCachedRoot(loaded.resolvedRoot);
      }

      state.threadPersonalRoot = loaded.threadPersonalRoot;
      state.threadRoots = loaded.threadRoots;
      state.threadReplyCursor = loaded.replyCursor;
      state.threadPage = loaded.snapshot;
      state.durableThreadRepliesHasMore = loaded.repliesHasMore;
      deps.cacheKnownNotes(...loaded.noteListsToCache);
      state.threadProfiles = loaded.profiles;
      deps.clearProfileViewState();
      state.feed = null;
      state.loading = false;
      if (!loaded.snapshot.note) {
        state.threadReplies = [];
        state.noteEngagements = new Map();
        if (token === state.loadToken && !state.threadPage?.note) {
          state.pageError = 'This post could not be found.';
        }
        return;
      }

      state.threadReplies = loaded.replies;
      deps.mergeCachedProfiles(state.threadProfiles);
      hydrateEngagementsOnce(loaded.threadRoots, loaded.noteIds);
      deps.scheduleShadowReadComparison({
        scope: 'thread',
        sharedRoot: loaded.resolvedRoot,
        roots: loaded.threadRoots,
        events: [loaded.snapshot.note, ...loaded.snapshot.context, ...loaded.replies]
          .filter((event): event is RawEvent => Boolean(event)),
      });
    } catch (error) {
      console.warn('Failed to hydrate thread', error);
      if (token === state.loadToken && !primaryCommitted && !state.threadPage?.note
        && await hydrateThreadDirect(currentRoot, ref, token)) {return;}
      if (token === state.loadToken && !primaryCommitted && !state.threadPage?.note) {
        clearThreadContent();
        state.threadReplyCursor = null;
        state.threadProfiles = new Map();
        state.noteEngagements = new Map();
        state.pageError = deps.reportError("Couldn't load this thread.", error);
      }
    } finally {
      if (token === state.loadToken) {state.threadLoading = false;}
    }
  }

  async function hydrateThreadRepliesPage(
    currentRoot: CID,
    ref: string,
    pageSize: number,
    token: number,
  ): Promise<void> {
    const knownNote = state.threadPage?.note ?? deps.getKnownNoteByRef(ref);
    const cursor = state.threadReplyCursor;
    const roots = [...state.threadRoots];
    if (!knownNote || !cursor || !state.durableThreadRepliesHasMore) {return;}

    const rootIdentity = roots.map(getRootNhash).join('|');
    if (!roots[0] || getRootNhash(roots[0]) !== getRootNhash(currentRoot)) {
      await hydrateThread(currentRoot, ref, token);
      return;
    }
    try {
      const page = await loadRoutedRepliesForEventPage(roots, knownNote, {
        before: cursor,
        limit: pageSize,
      });
      if (!pageIsCurrent(ref, token, rootIdentity, cursor)) {return;}
      state.threadReplyCursor = page.cursor;
      state.durableThreadRepliesHasMore = page.hasMore;
      state.threadReplies = mergeNotesByNewest(state.threadReplies, page.replies);
      deps.cacheKnownNotes(page.replies);
      deps.seedEmptyEngagements(page.replies.map((event) => event.id));
      void deps.hydrateNoteEngagements(roots, page.replies.map((event) => event.id), token);
      hydrateReplyProfiles(roots, page.replies, ref, token, rootIdentity);
    } catch (error) {
      console.warn('Failed to load more thread replies', error);
      if (token === state.loadToken && state.route.kind === 'thread' && state.route.ref === ref) {
        state.pageError = deps.reportError("Couldn't load more replies.", error);
      }
    }
  }

  function pageIsCurrent(
    ref: string,
    token: number,
    rootIdentity: string,
    cursor: NonNullable<AppCombinedState['threadReplyCursor']>,
  ): boolean {
    return token === state.loadToken
      && state.route.kind === 'thread'
      && state.route.ref === ref
      && rootIdentity === state.threadRoots.map(getRootNhash).join('|')
      && state.threadReplyCursor?.createdAt === cursor.createdAt
      && state.threadReplyCursor?.eventId === cursor.eventId;
  }

  function hydrateReplyProfiles(
    roots: CID[],
    replies: RawEvent[],
    ref: string,
    token: number,
    rootIdentity: string,
  ): void {
    const pubkeys = [...new Set(replies.map((event) => event.pubkey))];
    if (pubkeys.length === 0) {return;}
    void Promise.all(roots.map(async (root) => await loadProfilesForPubkeys(root, pubkeys)))
      .then((profiles) => {
        if (
          token !== state.loadToken
          || state.route.kind !== 'thread'
          || state.route.ref !== ref
          || rootIdentity !== state.threadRoots.map(getRootNhash).join('|')
        ) {return;}
        state.threadProfiles = mergeProfileMaps(...profiles, state.threadProfiles);
        deps.mergeCachedProfiles(state.threadProfiles);
      })
      .catch((error) => console.warn('Failed to hydrate profiles for appended thread replies', error));
  }

  function clearThreadContent(): void {
    state.threadPage = null;
    state.threadRoots = [];
    state.threadReplies = [];
    state.durableThreadRepliesHasMore = false;
  }

  return { hydrateThread, hydrateThreadRepliesPage };
}
