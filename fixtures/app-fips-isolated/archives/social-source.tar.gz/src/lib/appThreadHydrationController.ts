import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import type { AppCombinedState } from './appState';
import { createOptimisticThreadSnapshot, loadThreadViewData } from './appThreadLoader';
import { getRootNhash, loadProfilesForPubkeys } from './nostrIndex';
import type { ProfileRecord, RawEvent } from './nostr';
import { getThreadParentReference } from './nostr';
import { mergeProfileMaps } from './profileRecords';
import { loadRoutedRepliesForEventPage } from './routedThreadReplies';
import type { ShadowReadScope } from './shadowReadComparator';

type ShadowReadOptions = {
  scope: ShadowReadScope;
  sharedRoot: CID;
  roots: readonly CID[];
  events: readonly RawEvent[];
  profiles?: readonly (ProfileRecord | null | undefined)[];
};

type ThreadHydrationDeps = {
  state: AppCombinedState;
  applyCachedRoot: (root: CID) => boolean;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  clearProfileViewState: () => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  hydrateNoteEngagements: (
    roots: CID | CID[],
    noteIds: string[],
    token: number,
    options?: { merge?: boolean },
  ) => Promise<void>;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  reportError: (fallback: string, error: unknown) => string;
  resetThreadReplyPagination: () => void;
  scheduleShadowReadComparison: (options: ShadowReadOptions) => void;
  seedEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppThreadHydrationController(deps: ThreadHydrationDeps) {
  const { state } = deps;

  async function hydrateThread(currentRoot: CID | null, ref: string, token: number): Promise<void> {
    if (token !== state.loadToken) {return;}
    state.threadLoading = true;
    const knownNote = deps.getKnownNoteByRef(ref);
    const parentRef = knownNote ? getThreadParentReference(knownNote) : null;
    const knownParent = parentRef ? deps.getKnownNoteByRef(parentRef) : null;
    let primaryCommitted = Boolean(knownNote && state.threadPage?.note?.id === knownNote.id);

    if (!knownNote) {
      clearThreadContent();
    } else if (!state.threadPage?.note || state.threadPage.note.id !== knownNote.id) {
      state.threadPage = createOptimisticThreadSnapshot(currentRoot, knownNote, knownParent);
      state.threadReplies = [];
      deps.resetThreadReplyPagination();
      state.feed = null;
      deps.clearProfileViewState();
      state.loading = false;
    }

    // A saved/previously verified note is usable even while its remote index
    // is unavailable. Keep local replies and never start index reads without a root.
    if (!currentRoot) {
      state.threadLoading = false;
      if (knownNote) {
        state.pageError = '';
        state.rootError = '';
        state.threadRoots = [];
        state.threadPersonalRoot = null;
        state.threadReplyCursor = null;
        state.durableThreadRepliesHasMore = false;
        deps.seedEmptyEngagements([knownNote.id]);
      }
      return;
    }

    try {
      const loaded = await loadThreadViewData({
        currentRoot,
        ref,
        knownNote,
        knownParent,
        profilePersonalRoot: state.profilePersonalRoot,
        viewerPersonalRoot: state.viewerPersonalRoot,
        cachedProfiles: new Map(state.threadProfiles),
        replyLimit: state.threadReplyFetchLimit,
        onPrimary: (primary) => {
          if (token !== state.loadToken) {return;}
          if (getRootNhash(primary.resolvedRoot) !== getRootNhash(currentRoot)) {
            deps.applyCachedRoot(primary.resolvedRoot);
          }
          state.threadRoots = primary.threadRoots;
          state.threadPage = primary.snapshot;
          state.threadReplies = [];
          state.durableThreadRepliesHasMore = false;
          deps.cacheKnownNotes(
            primary.snapshot.note ? [primary.snapshot.note] : [],
            primary.snapshot.context,
          );
          deps.clearProfileViewState();
          state.feed = null;
          state.loading = false;
          state.threadLoading = false;
          primaryCommitted = Boolean(primary.snapshot.note);
          if (!primary.snapshot.note) {
            state.pageError = 'This post is not available in the configured Hashtree indexes.';
          }
        },
        onReplies: (update) => {
          if (token !== state.loadToken) {return;}
          state.threadPersonalRoot = update.threadPersonalRoot;
          state.threadRoots = update.threadRoots;
          state.threadReplyCursor = update.replyCursor;
          state.threadPage = update.snapshot;
          state.threadReplies = update.replies;
          state.durableThreadRepliesHasMore = update.repliesHasMore;
          const noteIds = [
            ...(update.snapshot.note ? [update.snapshot.note.id] : []),
            ...update.replies.map((event) => event.id),
          ];
          deps.cacheKnownNotes(
            update.snapshot.note ? [update.snapshot.note] : [],
            update.snapshot.context,
            update.replies,
          );
          deps.seedEmptyEngagements(noteIds);
          void deps.hydrateNoteEngagements(update.threadRoots, noteIds, token);
          state.loading = false;
          state.threadLoading = false;
          primaryCommitted = Boolean(update.snapshot.note);
        },
      });
      if (token !== state.loadToken) {return;}
      if (getRootNhash(loaded.resolvedRoot) !== getRootNhash(currentRoot)) {
        deps.applyCachedRoot(loaded.resolvedRoot);
      }

      state.threadPersonalRoot = loaded.threadPersonalRoot;
      state.threadRoots = loaded.threadRoots;
      state.threadReplyCursor = loaded.replyCursor;
      state.threadPage = loaded.snapshot;
      state.threadReplies = [];
      state.durableThreadRepliesHasMore = loaded.repliesHasMore;
      deps.cacheKnownNotes(...loaded.noteListsToCache);
      state.threadProfiles = loaded.profiles;
      deps.clearProfileViewState();
      state.feed = null;
      state.loading = false;
      if (!loaded.snapshot.note) {
        state.noteEngagements = new Map();
        state.pageError = 'This post is not available in the configured Hashtree indexes.';
        return;
      }

      state.threadReplies = loaded.replies;
      deps.mergeCachedProfiles(state.threadProfiles);
      deps.seedEmptyEngagements(loaded.noteIds);
      void deps.hydrateNoteEngagements(loaded.threadRoots, loaded.noteIds, token);
      deps.scheduleShadowReadComparison({
        scope: 'thread',
        sharedRoot: loaded.resolvedRoot,
        roots: loaded.threadRoots,
        events: [loaded.snapshot.note, ...loaded.snapshot.context, ...loaded.replies]
          .filter((event): event is RawEvent => Boolean(event)),
      });
    } catch (error) {
      console.warn('Failed to hydrate thread', error);
      if (token === state.loadToken && !primaryCommitted && !state.threadPage?.note) {
        clearThreadContent();
        state.threadReplyCursor = null;
        state.threadProfiles = new Map();
        state.noteEngagements = new Map();
        state.pageError = deps.reportError("Couldn't load this thread.", error);
      }
    } finally {
      if (token === state.loadToken) {state.threadLoading = false;}
    }
  }

  async function hydrateThreadRepliesPage(
    currentRoot: CID,
    ref: string,
    pageSize: number,
    token: number,
  ): Promise<void> {
    const knownNote = state.threadPage?.note ?? deps.getKnownNoteByRef(ref);
    const cursor = state.threadReplyCursor;
    const roots = [...state.threadRoots];
    if (!knownNote || !cursor || !state.durableThreadRepliesHasMore) {return;}

    const rootIdentity = roots.map(getRootNhash).join('|');
    if (!roots[0] || getRootNhash(roots[0]) !== getRootNhash(currentRoot)) {
      await hydrateThread(currentRoot, ref, token);
      return;
    }
    try {
      const page = await loadRoutedRepliesForEventPage(roots, knownNote, {
        before: cursor,
        limit: pageSize,
      });
      if (!pageIsCurrent(ref, token, rootIdentity, cursor)) {return;}
      state.threadReplyCursor = page.cursor;
      state.durableThreadRepliesHasMore = page.hasMore;
      state.threadReplies = mergeNotesByNewest(state.threadReplies, page.replies);
      deps.cacheKnownNotes(page.replies);
      deps.seedEmptyEngagements(page.replies.map((event) => event.id));
      void deps.hydrateNoteEngagements(roots, page.replies.map((event) => event.id), token);
      hydrateReplyProfiles(roots, page.replies, ref, token, rootIdentity);
    } catch (error) {
      console.warn('Failed to load more thread replies', error);
      if (token === state.loadToken && state.route.kind === 'thread' && state.route.ref === ref) {
        state.pageError = deps.reportError("Couldn't load more replies.", error);
      }
    }
  }

  function pageIsCurrent(
    ref: string,
    token: number,
    rootIdentity: string,
    cursor: NonNullable<AppCombinedState['threadReplyCursor']>,
  ): boolean {
    return token === state.loadToken
      && state.route.kind === 'thread'
      && state.route.ref === ref
      && rootIdentity === state.threadRoots.map(getRootNhash).join('|')
      && state.threadReplyCursor?.createdAt === cursor.createdAt
      && state.threadReplyCursor?.eventId === cursor.eventId;
  }

  function hydrateReplyProfiles(
    roots: CID[],
    replies: RawEvent[],
    ref: string,
    token: number,
    rootIdentity: string,
  ): void {
    const pubkeys = [...new Set(replies.map((event) => event.pubkey))];
    if (pubkeys.length === 0) {return;}
    void Promise.all(roots.map(async (root) => await loadProfilesForPubkeys(root, pubkeys)))
      .then((profiles) => {
        if (
          token !== state.loadToken
          || state.route.kind !== 'thread'
          || state.route.ref !== ref
          || rootIdentity !== state.threadRoots.map(getRootNhash).join('|')
        ) {return;}
        state.threadProfiles = mergeProfileMaps(...profiles, state.threadProfiles);
        deps.mergeCachedProfiles(state.threadProfiles);
      })
      .catch((error) => console.warn('Failed to hydrate profiles for appended thread replies', error));
  }

  function clearThreadContent(): void {
    state.threadPage = null;
    state.threadRoots = [];
    state.threadReplies = [];
    state.durableThreadRepliesHasMore = false;
  }

  return { hydrateThread, hydrateThreadRepliesPage };
}
