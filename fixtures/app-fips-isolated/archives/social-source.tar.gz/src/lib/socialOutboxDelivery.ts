import type { RawEvent } from './nostr';
import { OutboxRetryController } from './outboxRetryController';
import { normalizeReconnectDelays } from './socialDataPlaneSupport';
import type { SocialOutboxEntry, SocialOutboxObligations } from './socialOutboxJournal';

type Publisher = (event: RawEvent) => Promise<void>;

type SocialOutboxDeliveryOptions = {
  onlineTarget: EventTarget | null;
  outboxRetryDelaysMs?: readonly number[];
  personalIndexRetryDelaysMs?: readonly number[];
  publishToRelays?: Publisher;
  publishToPersonalIndex?: Publisher;
};

/** Owns independent relay and personal-index delivery obligations and retries. */
export abstract class SocialOutboxDelivery {
  private readonly pendingDeliveryEventIds = new Set<string>();
  private readonly pendingPersonalIndexEventIds = new Set<string>();
  private readonly deliveringEventIds = new Set<string>();
  private readonly indexingEventIds = new Set<string>();
  private readonly outboxRetry: OutboxRetryController;
  private readonly personalIndexRetry: OutboxRetryController;
  private relayPublisher: Publisher | null;
  private personalIndexPublisher: Publisher | null;
  private outboxRetryPromise: Promise<void> | null = null;
  private personalIndexRetryPromise: Promise<void> | null = null;
  private deliveryRunning = false;

  protected constructor(options: SocialOutboxDeliveryOptions) {
    this.relayPublisher = options.publishToRelays ?? null;
    this.personalIndexPublisher = options.publishToPersonalIndex ?? null;
    this.outboxRetry = new OutboxRetryController({
      delaysMs: normalizeReconnectDelays(options.outboxRetryDelaysMs),
      onlineTarget: options.onlineTarget,
      canRetry: () => Boolean(
        this.deliveryRunning
        && this.relayPublisher
        && this.pendingDeliveryEventIds.size > 0
        && !this.outboxRetryPromise
      ),
      retry: async () => await this.retryPendingDeliveries(),
      onError: (error) => console.warn('Background Nostr relay retry remains queued', error),
    });
    this.personalIndexRetry = new OutboxRetryController({
      delaysMs: normalizeReconnectDelays(
        options.personalIndexRetryDelaysMs ?? options.outboxRetryDelaysMs,
      ),
      onlineTarget: options.onlineTarget,
      canRetry: () => Boolean(
        this.deliveryRunning
        && this.personalIndexPublisher
        && this.pendingPersonalIndexEventIds.size > 0
        && !this.personalIndexRetryPromise
      ),
      retry: async () => await this.retryPendingPersonalIndexes(),
      onError: (error) => console.warn('Personal Hashtree indexing retry remains queued', error),
    });
  }

  protected abstract getStoredOutboxEvent(eventId: string): RawEvent | null;

  protected abstract completeOutboxObligation(
    eventId: string,
    obligation: keyof SocialOutboxObligations,
  ): boolean;

  get pendingDeliveryCount(): number { return this.pendingDeliveryEventIds.size; }

  get pendingPersonalIndexCount(): number { return this.pendingPersonalIndexEventIds.size; }

  isPendingDelivery(eventId: string): boolean {
    return this.pendingDeliveryEventIds.has(eventId.toLowerCase());
  }

  isPendingPersonalIndex(eventId: string): boolean {
    return this.pendingPersonalIndexEventIds.has(eventId.toLowerCase());
  }

  protected get relayPendingEventIds(): ReadonlySet<string> {
    return this.pendingDeliveryEventIds;
  }

  protected get allPendingOutboxEventIds(): Set<string> {
    return new Set([...this.pendingDeliveryEventIds, ...this.pendingPersonalIndexEventIds]);
  }

  protected hasPendingOutboxObligation(eventId: string): boolean {
    return this.pendingDeliveryEventIds.has(eventId)
      || this.pendingPersonalIndexEventIds.has(eventId);
  }

  protected applyJournalObligations(entry: SocialOutboxEntry): void {
    const eventId = entry.event.id.toLowerCase();
    this.updatePendingSet(this.pendingDeliveryEventIds, eventId, entry.obligations.relay);
    this.updatePendingSet(
      this.pendingPersonalIndexEventIds,
      eventId,
      entry.obligations.personalIndex,
    );
    this.clearSatisfiedRetries();
  }

  protected removeJournalObligations(eventId: string): boolean {
    const hadRelay = this.pendingDeliveryEventIds.delete(eventId);
    const hadPersonalIndex = this.pendingPersonalIndexEventIds.delete(eventId);
    this.clearSatisfiedRetries();
    return hadRelay || hadPersonalIndex;
  }

  protected startOutboxDelivery(): void {
    this.deliveryRunning = true;
    this.outboxRetry.start();
    this.personalIndexRetry.start();
  }

  protected stopOutboxDelivery(): void {
    this.deliveryRunning = false;
    this.outboxRetry.stop();
    this.personalIndexRetry.stop();
  }

  setRelayPublisher(publisher: Publisher | null): void {
    this.relayPublisher = publisher;
    if (!publisher) {
      this.outboxRetry.clear();
    } else if (this.deliveryRunning && this.pendingDeliveryEventIds.size > 0) {
      this.resumeOutboxBackgroundWork();
    }
  }

  setPersonalIndexPublisher(publisher: Publisher | null): void {
    this.personalIndexPublisher = publisher;
    if (!publisher) {
      this.personalIndexRetry.clear();
    } else if (this.deliveryRunning && this.pendingPersonalIndexEventIds.size > 0) {
      this.resumeOutboxBackgroundWork();
    }
  }

  protected publishQueuedObligations(
    event: RawEvent,
    publishToRelays: Publisher,
    publishToPersonalIndex: Publisher | null,
  ): void {
    void this.deliverRelayQueuedEvent(event, publishToRelays).finally(() => {
      if (this.isPendingDelivery(event.id)) { this.outboxRetry.schedule(); }
    });
    if (publishToPersonalIndex) {
      void this.deliverPersonalIndexQueuedEvent(event, publishToPersonalIndex).finally(() => {
        if (this.isPendingPersonalIndex(event.id)) { this.personalIndexRetry.schedule(); }
      });
    }
  }

  async retryPendingDeliveries(): Promise<void> {
    if (this.outboxRetryPromise) { return await this.outboxRetryPromise; }
    const retry = this.deliverPendingSet(
      this.pendingDeliveryEventIds,
      this.deliveringEventIds,
      this.relayPublisher,
      (event, publisher) => this.deliverRelayQueuedEvent(event, publisher),
    );
    const pending = retry.finally(() => {
      if (this.outboxRetryPromise === pending) { this.outboxRetryPromise = null; }
      this.finishRetry(this.pendingDeliveryEventIds, this.outboxRetry);
    });
    this.outboxRetryPromise = pending;
    return await pending;
  }

  async retryPendingPersonalIndexes(): Promise<void> {
    if (this.personalIndexRetryPromise) { return await this.personalIndexRetryPromise; }
    const retry = this.deliverPendingSet(
      this.pendingPersonalIndexEventIds,
      this.indexingEventIds,
      this.personalIndexPublisher,
      (event, publisher) => this.deliverPersonalIndexQueuedEvent(event, publisher),
    );
    const pending = retry.finally(() => {
      if (this.personalIndexRetryPromise === pending) { this.personalIndexRetryPromise = null; }
      this.finishRetry(this.pendingPersonalIndexEventIds, this.personalIndexRetry);
    });
    this.personalIndexRetryPromise = pending;
    return await pending;
  }

  protected resumeOutboxBackgroundWork(): void {
    if (!this.deliveryRunning) { return; }
    void this.retryPendingDeliveries().catch((error: unknown) => {
      console.warn('Relay retry remains queued', error);
    });
    void this.retryPendingPersonalIndexes().catch((error: unknown) => {
      console.warn('Personal Hashtree indexing retry remains queued', error);
    });
  }

  protected scheduleJournalEntryRetries(
    entry: SocialOutboxEntry,
    wasRelayPending: boolean,
    wasPersonalIndexPending: boolean,
  ): void {
    if (!this.deliveryRunning) { return; }
    if (!wasRelayPending && entry.obligations.relay) { this.outboxRetry.schedule(); }
    if (!wasPersonalIndexPending && entry.obligations.personalIndex) {
      this.personalIndexRetry.schedule();
    }
  }

  private async deliverPendingSet(
    pendingIds: ReadonlySet<string>,
    activeIds: ReadonlySet<string>,
    publisher: Publisher | null,
    deliver: (event: RawEvent, publisher: Publisher | null) => Promise<boolean>,
  ): Promise<void> {
    for (const eventId of [...pendingIds]) {
      if (activeIds.has(eventId)) { continue; }
      const event = this.getStoredOutboxEvent(eventId);
      if (event) { await deliver(event, publisher); }
    }
  }

  private async deliverRelayQueuedEvent(event: RawEvent, publisher: Publisher | null): Promise<boolean> {
    return await this.deliverQueuedEvent(
      event,
      publisher,
      this.pendingDeliveryEventIds,
      this.deliveringEventIds,
      'relay',
    );
  }

  private async deliverPersonalIndexQueuedEvent(
    event: RawEvent,
    publisher: Publisher | null,
  ): Promise<boolean> {
    return await this.deliverQueuedEvent(
      event,
      publisher,
      this.pendingPersonalIndexEventIds,
      this.indexingEventIds,
      'personalIndex',
    );
  }

  private async deliverQueuedEvent(
    event: RawEvent,
    publisher: Publisher | null,
    pendingIds: ReadonlySet<string>,
    activeIds: Set<string>,
    obligation: keyof SocialOutboxObligations,
  ): Promise<boolean> {
    const eventId = event.id.toLowerCase();
    if (!pendingIds.has(eventId) || activeIds.has(eventId) || !publisher) { return false; }
    activeIds.add(eventId);
    try {
      try {
        await publisher(event);
        return this.completeOutboxObligation(eventId, obligation);
      } catch {
        return false;
      }
    } finally {
      activeIds.delete(eventId);
    }
  }

  private finishRetry(pendingIds: ReadonlySet<string>, retry: OutboxRetryController): void {
    if (pendingIds.size === 0) { retry.clear(true); } else { retry.schedule(); }
  }

  private clearSatisfiedRetries(): void {
    if (this.pendingDeliveryEventIds.size === 0) { this.outboxRetry.clear(true); }
    if (this.pendingPersonalIndexEventIds.size === 0) { this.personalIndexRetry.clear(true); }
  }

  private updatePendingSet(target: Set<string>, eventId: string, pending: boolean): void {
    if (pending) { target.add(eventId); } else { target.delete(eventId); }
  }
}
