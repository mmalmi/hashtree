import { get, writable } from 'svelte/store';
import { copyFeedFilters, feedFilterScope, updateFeedFilters } from './feedFilters';
import { CUSTOM_FEED_BASES, isCustomFeedId, type CustomFeedBase, type HomeTab } from './routes';

/**
 * A custom home feed. On the Favorites base, `people` replaces the viewer's
 * starred favorites with a chosen list; without it the feed uses favorites.
 */
export type CustomHomeFeed = { id: string; name: string; base: CustomFeedBase; people?: string[] };

/** Per-account home feed tabs: order and custom feeds. */
export type HomeFeedLayout = { order: string[]; custom: CustomHomeFeed[] };

export type HomeFeedTab = {
  /** Built-in tab name, or `custom:<id>`. */
  key: string;
  label: string;
  tab: HomeTab;
  feedId: string | null;
};

const BUILT_IN_TABS: readonly { key: HomeTab; label: string }[] = [
  { key: 'for-you', label: 'For you' },
  { key: 'latest', label: 'Latest' },
  { key: 'favorites', label: 'Favorites' },
];
const BUILT_IN_KEYS = new Set<string>(BUILT_IN_TABS.map((tab) => tab.key));
const BASE_LABELS: Record<CustomFeedBase, string> = { 'for-you': 'For you', latest: 'Latest', favorites: 'Favorites' };
export const DEFAULT_HOME_FEED_LAYOUT: HomeFeedLayout = Object.freeze({
  order: BUILT_IN_TABS.map((tab) => tab.key),
  custom: [],
}) as HomeFeedLayout;
const STORAGE_KEY = 'iris-social:home-feed-tabs:v1';
const MAX_CUSTOM_FEEDS = 24;
const MAX_NAME_LENGTH = 40;
const MAX_STORED_ACCOUNTS = 32;
const MAX_PEOPLE = 500;
const HEX_PUBKEY = /^[0-9a-f]{64}$/;

export const customFeedKey = (id: string): string => `custom:${id}`;
export const customFeedBaseLabel = (base: CustomFeedBase): string => BASE_LABELS[base];

function normalizeName(value: unknown): string {
  return typeof value === 'string' ? value.trim().slice(0, MAX_NAME_LENGTH) : '';
}

export function normalizePeople(value: unknown): string[] {
  return Array.isArray(value)
    ? [...new Set(value.filter((pubkey): pubkey is string => typeof pubkey === 'string')
      .map((pubkey) => pubkey.toLowerCase()).filter((pubkey) => HEX_PUBKEY.test(pubkey)))].slice(0, MAX_PEOPLE)
    : [];
}

export function normalizeHomeFeedLayout(value: unknown): HomeFeedLayout {
  const input = value && typeof value === 'object' ? value as Partial<HomeFeedLayout> : {};
  const custom = (Array.isArray(input.custom) ? input.custom : []).flatMap((feed): CustomHomeFeed[] => {
    const entry = feed && typeof feed === 'object' ? feed as Partial<CustomHomeFeed> : {};
    if (typeof entry.id !== 'string' || !isCustomFeedId(entry.id)
      || !(CUSTOM_FEED_BASES as readonly unknown[]).includes(entry.base)) {return [];}
    const normalized: CustomHomeFeed = { id: entry.id, name: normalizeName(entry.name) || 'Feed', base: entry.base as CustomFeedBase };
    if (normalized.base === 'favorites' && Array.isArray(entry.people)) {normalized.people = normalizePeople(entry.people);}
    return [normalized];
  }).filter((feed, index, all) => all.findIndex((other) => other.id === feed.id) === index)
    .slice(0, MAX_CUSTOM_FEEDS);
  const known = new Set([...BUILT_IN_KEYS, ...custom.map((feed) => customFeedKey(feed.id))]);
  const order = [...new Set((Array.isArray(input.order) ? input.order : DEFAULT_HOME_FEED_LAYOUT.order)
    .filter((key): key is string => typeof key === 'string' && known.has(key)))];
  // New built-ins and feeds missing from a stored order go to the end.
  for (const key of known) {if (!order.includes(key)) {order.push(key);}}
  return { order, custom };
}

function readLayouts(): Map<string, HomeFeedLayout> {
  try {
    const saved: unknown = JSON.parse(globalThis.localStorage?.getItem(STORAGE_KEY) ?? '[]');
    if (!Array.isArray(saved)) {return new Map();}
    return new Map(saved.slice(-MAX_STORED_ACCOUNTS).flatMap((entry) => (
      Array.isArray(entry) && typeof entry[0] === 'string'
        ? [[entry[0], normalizeHomeFeedLayout(entry[1])] as const]
        : []
    )));
  } catch { return new Map(); }
}

export const homeFeedLayoutsStore = writable(readLayouts());

export function readHomeFeedLayout(layouts: Map<string, HomeFeedLayout>, viewer: string | null): HomeFeedLayout {
  return (viewer && layouts.get(viewer)) || DEFAULT_HOME_FEED_LAYOUT;
}

function updateLayout(viewer: string | null, change: (layout: HomeFeedLayout) => HomeFeedLayout): void {
  if (!viewer) {return;}
  homeFeedLayoutsStore.update((current) => {
    const next = new Map(current);
    const layout = normalizeHomeFeedLayout(change(readHomeFeedLayout(current, viewer)));
    next.delete(viewer);
    next.set(viewer, layout);
    while (next.size > MAX_STORED_ACCOUNTS) {next.delete(next.keys().next().value!);}
    try { globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify([...next])); } catch { /* Keep session layout when storage is full. */ }
    return next;
  });
}

/** Tabs in display order. */
export function visibleHomeFeedTabs(layout: HomeFeedLayout): HomeFeedTab[] {
  const custom = new Map(layout.custom.map((feed) => [customFeedKey(feed.id), feed]));
  return layout.order.flatMap((key): HomeFeedTab[] => {
    const feed = custom.get(key);
    if (feed) {return [{ key, label: feed.name, tab: feed.base, feedId: feed.id }];}
    const builtIn = BUILT_IN_TABS.find((tab) => tab.key === key);
    return builtIn ? [{ key, label: builtIn.label, tab: builtIn.key, feedId: null }] : [];
  });
}

export function homeFeedTabKey(tab: HomeTab, feedId: string | null | undefined): string {
  return feedId ? customFeedKey(feedId) : tab;
}

export function findCustomFeed(layout: HomeFeedLayout, feedId: string | null | undefined): CustomHomeFeed | null {
  return feedId ? layout.custom.find((feed) => feed.id === feedId) ?? null : null;
}

function newFeedId(): string {
  const bytes = new Uint8Array(6);
  globalThis.crypto.getRandomValues(bytes);
  return [...bytes].map((byte) => byte.toString(36).padStart(2, '0')).join('').slice(0, 10);
}

/** Add a custom feed right after `afterKey` (or last) and return it. */
export function createCustomFeed(
  viewer: string | null,
  base: CustomFeedBase,
  afterKey: string | null,
): CustomHomeFeed | null {
  if (!viewer) {return null;}
  const feed: CustomHomeFeed = { id: newFeedId(), name: 'New feed', base };
  let created: CustomHomeFeed | null = null;
  updateLayout(viewer, (layout) => {
    if (layout.custom.length >= MAX_CUSTOM_FEEDS) {return layout;}
    created = feed;
    const order = [...layout.order];
    const index = afterKey ? order.indexOf(afterKey) : -1;
    order.splice(index >= 0 ? index + 1 : order.length, 0, customFeedKey(feed.id));
    return { ...layout, order, custom: [...layout.custom, feed] };
  });
  return created;
}

/** Copy a custom feed, with its filters, right after the original. */
export function duplicateCustomFeed(viewer: string | null, id: string): CustomHomeFeed | null {
  const source = findCustomFeed(readHomeFeedLayout(get(homeFeedLayoutsStore), viewer), id);
  if (!viewer || !source) {return null;}
  const copy = createCustomFeed(viewer, source.base, customFeedKey(id));
  if (!copy) {return null;}
  const name = `${source.name} copy`.slice(0, MAX_NAME_LENGTH);
  updateCustomFeed(viewer, copy.id, { name, people: source.people });
  copyFeedFilters(feedFilterScope(viewer, null, source.base, id), feedFilterScope(viewer, null, source.base, copy.id));
  return { ...copy, name, people: source.people };
}

/**
 * Authors for a Favorites-based view: a custom feed's chosen people, or the
 * viewer's starred favorites.
 */
export function favoritesFeedAuthors(
  viewer: string | null,
  feedId: string | null | undefined,
  favoritePubkeys: string[],
  layouts: Map<string, HomeFeedLayout> = get(homeFeedLayoutsStore),
): string[] {
  const feed = findCustomFeed(readHomeFeedLayout(layouts, viewer), feedId);
  return feed?.base === 'favorites' && feed.people ? feed.people : favoritePubkeys;
}

export function updateCustomFeed(viewer: string | null, id: string, patch: Partial<Omit<CustomHomeFeed, 'id'>>): void {
  updateLayout(viewer, (layout) => ({
    ...layout,
    custom: layout.custom.map((feed) => {
      if (feed.id !== id) {return feed;}
      const next: CustomHomeFeed = {
        ...feed, ...patch, name: patch.name === undefined ? feed.name : normalizeName(patch.name) || feed.name,
      };
      if (next.base !== 'favorites' || next.people === undefined) {delete next.people;}
      return next;
    }),
  }));
}

export function deleteCustomFeed(viewer: string | null, id: string): void {
  updateFeedFilters(feedFilterScope(viewer, null, 'latest', id), null);
  updateLayout(viewer, (layout) => ({
    ...layout,
    order: layout.order.filter((key) => key !== customFeedKey(id)),
    custom: layout.custom.filter((feed) => feed.id !== id),
  }));
}

/** Move a tab one step left or right. */
export function moveHomeFeedTab(viewer: string | null, key: string, direction: -1 | 1): void {
  updateLayout(viewer, (layout) => {
    const visible = visibleHomeFeedTabs(layout).map((tab) => tab.key);
    const index = visible.indexOf(key);
    const neighbor = visible[index + direction];
    if (index < 0 || !neighbor) {return layout;}
    const order = [...layout.order];
    const from = order.indexOf(key);
    const to = order.indexOf(neighbor);
    order[from] = neighbor;
    order[to] = key;
    return { ...layout, order };
  });
}

/** The feed just added with "+", until its settings are closed: Cancel removes it. */
export type PendingNewFeed = { viewer: string; id: string; returnTab: HomeTab; returnFeedId: string | null };
export const pendingNewFeedStore = writable<PendingNewFeed | null>(null);
