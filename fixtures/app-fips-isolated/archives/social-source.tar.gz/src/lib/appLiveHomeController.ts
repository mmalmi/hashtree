import { getNoteEngagementTargetId } from './noteEngagement';
import { favoritesFeedAuthors } from './homeFeedTabs';
import { tick } from 'svelte';
import type { AppCombinedState } from './appState';
import { routeKey } from './appRoute';
import { getHomeFeedProtectedCount } from './appScroll';
import { FOR_YOU_INTERACTION_KINDS } from './forYouFeed';
import {
  bufferLiveHomeFeedEvents,
  clearLiveHomeFeedBuffer,
  MAX_BUFFERED_LIVE_HOME_EVENTS,
} from './liveHomeFeedBuffer';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  DURABLE_POST_KINDS,
} from './nostrIndex';
import {
  extractFollowPubkeys,
  type RawEvent,
} from './nostr';
import { profileMapFromMetadataEvents } from './profileRecords';
import {
  isLiveHomeFeedEventEligible,
} from './liveHomeFeedBuffer';
import { socialDataPlane, type SocialDataPlaneChange } from './socialDataPlane';

const LIVE_VIEW_REFRESH_DEBOUNCE_MS = 80;

type LiveHomeControllerDeps = {
  state: AppCombinedState;
  dataPlane?: typeof socialDataPlane;
  pendingLiveViewEvents: Map<string, RawEvent>;
  applyProfileSocialSnapshot: (social: AppCombinedState['profileSocial']) => void;
  applyViewerFollows: (follows: Set<string>) => void;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  noteHasMedia: (event: RawEvent) => boolean;
  projectContactsEvent: (event: RawEvent | null, pubkey: string) => RawEvent | null;
  pruneTombstonedLocalPosts: () => void;
  restartCurrentViewLoad: () => void;
  scrollPageToTopInstant: () => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppLiveHomeController(deps: LiveHomeControllerDeps) {
  const { state } = deps;
  const dataPlane = deps.dataPlane ?? socialDataPlane;
  function getLiveHomeAuthors(): string[] {
    if (state.route.kind !== 'home') {
      return [];
    }
    if (state.route.tab === 'favorites') {
      return favoritesFeedAuthors(state.activeAccount?.pubkey ?? null, state.route.feedId, state.favoritePubkeys);
    }
    const authors = new Set(state.route.tab === 'for-you'
      ? getForYouRankingAuthors() : state.feed?.follows ?? []);
    if (!state.activeFeedSource) {
      if ((state.route.tab === 'latest' || state.route.tab === 'media') && state.activeAccount) {
        authors.add(state.activeAccount.pubkey);
      }
      state.viewerFollows.forEach((pubkey) => authors.add(pubkey));
    }
    state.feed?.notes.forEach((event) => authors.add(event.pubkey));
    if (state.feed?.feedOwnerPubkey && (
      state.route.tab === 'for-you'
      || state.feed.starterMode
      || state.feed.usedSuggestedFeed
    )) {
      authors.add(state.feed.feedOwnerPubkey);
    }
    return [...authors];
  }

  // Refresh can replay the same signed events while the feed is being rebuilt.
  // Keep only IDs from the pre-refresh screen. New arrivals still enter the buffer.
  const refreshedIds = new Set<string>();
  let refreshedOwner: string | null = null;
  function resetLiveHomeFeedBuffer(rememberScreen = false): void {
    refreshedIds.clear();
    if (rememberScreen) {
      refreshedOwner = state.activeAccount?.pubkey ?? null;
      const remember = (notes: readonly RawEvent[]) => {
        for (const note of notes) {
          if (refreshedIds.size >= MAX_BUFFERED_LIVE_HOME_EVENTS) {break;}
          refreshedIds.add(note.id);
        }
      };
      remember(state.liveHomeFeedBuffer.events);
      remember(state.homeNotes);
      remember(state.liveHomeFeedBuffer.stableNotes);
    }
    if (state.liveHomeFeedBuffer.events.length > 0) {
      state.liveHomeFeedBuffer = clearLiveHomeFeedBuffer();
    }
  }

  function liveEventMatchesCurrentHomeFeed(event: RawEvent, authors = getLiveHomeAuthors()): boolean {
    return state.route.kind === 'home' && isLiveHomeFeedEventEligible(event, {
      authors,
      hasMedia: deps.noteHasMedia,
      mutedPubkeys: state.viewerHiddenPubkeys,
      viewerFollows: state.viewerFollows,
      postKinds: DURABLE_POST_KINDS,
      tab: state.route.tab,
      viewerPubkey: state.activeAccount?.pubkey ?? null,
    });
  }

  function bufferIncomingLiveHomeEvents(events: readonly RawEvent[]): void {
    const route = state.route;
    const displayed = state.allHomeNotes;
    if (route.kind !== 'home' || displayed.length === 0) { return; }
    const authors = getLiveHomeAuthors();
    const displayedIds = new Set(displayed.map((note) => note.id));
    const sameRefreshedOwner = refreshedOwner === (state.activeAccount?.pubkey ?? null);
    const arrivals = events.filter((event) => (
      !(sameRefreshedOwner && refreshedIds.has(event.id))
      && !displayedIds.has(event.id)
      && liveEventMatchesCurrentHomeFeed(event, authors)
      && dataPlane.getEventStatus(event.id) === 'visible'
    ));
    if (arrivals.length === 0) { return; }

    state.liveHomeFeedBuffer = bufferLiveHomeFeedEvents(
      state.liveHomeFeedBuffer,
      arrivals,
      displayed,
      getHomeFeedProtectedCount(displayed, routeKey(route)) ?? displayed.length + 1,
      route.tab === 'for-you',
    );
  }

  function scheduleLiveViewRefresh(change: SocialDataPlaneChange): void {
    const changedEvents = change.events;
    if (change.origin === 'live') {
      bufferIncomingLiveHomeEvents(changedEvents);
    } else if (change.origin === 'local') {
      resetLiveHomeFeedBuffer();
      if (state.feed?.displayOrder) { state.feed = { ...state.feed, displayOrder: undefined }; }
    } else if (change.origin === 'restore') {
      state.pendingOverlayRestore = true;
    }
    for (const event of changedEvents) {
      deps.pendingLiveViewEvents.set(event.id, event);
    }
    if (state.liveViewRefreshTimer !== null) {
      return;
    }
    state.liveViewRefreshTimer = window.setTimeout(() => {
      state.liveViewRefreshTimer = null;
      const nextEvents = state.pendingOverlayRestore
        ? dataPlane.query({ includeDeletionEvents: true })
        : [...deps.pendingLiveViewEvents.values()];
      const profilePubkey = state.route.kind === 'profile' ? state.route.pubkey : null;
      state.pendingOverlayRestore = false;
      deps.pendingLiveViewEvents.clear();
      if (nextEvents.some((event) => event.kind === 5)) {
        deps.pruneTombstonedLocalPosts();
      }
      deps.cacheKnownNotes(nextEvents.filter((event) => (
        PROFILE_CONTENT_KINDS.includes(event.kind as (typeof PROFILE_CONTENT_KINDS)[number])
      )));
      if (nextEvents.some((event) => event.kind === 0 || event.kind === 5)) {
        state.liveProfiles = profileMapFromMetadataEvents(dataPlane.query({ kinds: [0] }));
      }
      state.liveOverlayVersion += 1;
      if (nextEvents.some((event) => event.kind === 3 || event.kind === 5)) {
        if (state.activeAccount) {
          const previous = state.viewerContactsEvent;
          state.viewerContactsEvent = deps.projectContactsEvent(previous, state.activeAccount.pubkey);
          state.viewerContactsProjectionAuthoritative = Boolean(previous || state.viewerContactsEvent);
          deps.applyViewerFollows(new Set(extractFollowPubkeys(state.viewerContactsEvent)));
        }
        if (profilePubkey && state.profileSocial) {
          deps.applyProfileSocialSnapshot(state.profileSocial);
        }
      }
      if (
        profilePubkey
        && nextEvents.some((event) => (
          event.pubkey === profilePubkey
          && PROFILE_CONTENT_KINDS.includes(event.kind as (typeof PROFILE_CONTENT_KINDS)[number])
        ))
      ) {
        state.profilePage ??= {
          rootNhash: state.rootNhash,
          profile: state.accountProfiles.get(profilePubkey) ?? null,
          notes: [],
        };
        state.loading = false;
      }
      if (
        state.route.kind === 'thread'
        && !state.threadPage?.note
        && deps.getKnownNoteByRef(state.route.ref)
      ) {
        deps.restartCurrentViewLoad();
      }
    }, LIVE_VIEW_REFRESH_DEBOUNCE_MS);
  }

  function getForYouRankingAuthors(): string[] {
    if (state.route.kind !== 'home' || state.route.tab !== 'for-you') {
      return [];
    }
    return [...new Set(
      state.feed?.continuation?.authors?.length
        ? state.feed.continuation.authors
        : state.feed?.follows?.length
          ? state.feed.follows
          : [...state.viewerFollows],
    )];
  }

  function getForYouOverlayInteractions(authors: string[], limit: number): RawEvent[] {
    return authors.length === 0 || limit <= 0
      ? []
      : dataPlane.query({ authors, kinds: [...FOR_YOU_INTERACTION_KINDS], limit });
  }

  async function showBufferedLiveHomePosts(): Promise<void> {
    if (state.bufferedLiveHomePostCount === 0) {
      return;
    }
    const revealed = [...state.bufferedLiveHomeEvents];
    if (state.feed?.displayOrder) {
      state.feed = { ...state.feed, displayOrder: undefined };
    }
    state.liveHomeFeedBuffer = clearLiveHomeFeedBuffer();
    state.liveOverlayVersion += 1;
    deps.cacheKnownNotes(revealed);
    deps.seedNewEmptyEngagements(revealed.map(getNoteEngagementTargetId));
    await tick();
    deps.scrollPageToTopInstant();
  }

  return {
    getForYouOverlayInteractions,
    getForYouRankingAuthors,
    getLiveHomeAuthors,
    liveEventMatchesCurrentHomeFeed,
    resetLiveHomeFeedBuffer,
    scheduleLiveViewRefresh,
    showBufferedLiveHomePosts,
  };
}
