import { getNoteEngagementTargetId } from './noteEngagement';
import { tick } from 'svelte';
import type { AppCombinedState } from './appState';
import { FOR_YOU_INTERACTION_KINDS } from './forYouFeed';
import {
  bufferLiveHomeFeedEvent,
  clearLiveHomeFeedBuffer,
} from './liveHomeFeedBuffer';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  DURABLE_POST_KINDS,
} from './nostrIndex';
import {
  extractFollowPubkeys,
  type RawEvent,
} from './nostr';
import { profileMapFromMetadataEvents } from './profileRecords';
import {
  isLiveHomeFeedEventEligible,
} from './liveHomeFeedBuffer';
import { socialDataPlane, type SocialDataPlaneChange } from './socialDataPlane';

const LIVE_VIEW_REFRESH_DEBOUNCE_MS = 80;

type LiveHomeControllerDeps = {
  state: AppCombinedState;
  dataPlane?: typeof socialDataPlane;
  pendingLiveViewEvents: Map<string, RawEvent>;
  applyProfileSocialSnapshot: (social: AppCombinedState['profileSocial']) => void;
  applyViewerFollows: (follows: Set<string>) => void;
  cacheKnownNotes: (...events: RawEvent[][]) => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  noteHasMedia: (event: RawEvent) => boolean;
  projectContactsEvent: (event: RawEvent | null, pubkey: string) => RawEvent | null;
  pruneTombstonedLocalPosts: () => void;
  restartCurrentViewLoad: () => void;
  scrollPageToTopInstant: () => void;
  seedNewEmptyEngagements: (noteIds: string[]) => void;
};

export function createAppLiveHomeController(deps: LiveHomeControllerDeps) {
  const { state } = deps;
  const dataPlane = deps.dataPlane ?? socialDataPlane;
  function getLiveHomeAuthors(): string[] {
    if (state.route.kind !== 'home') {
      return [];
    }
    if (state.route.tab === 'favorites') { return state.favoritePubkeys; }
    const authors = new Set(state.route.tab === 'for-you'
      ? getForYouRankingAuthors() : state.feed?.follows ?? []);
    if (!state.activeFeedSource) {
      state.viewerFollows.forEach((pubkey) => authors.add(pubkey));
    }
    state.feed?.notes.forEach((event) => authors.add(event.pubkey));
    if (state.feed?.feedOwnerPubkey && (
      state.route.tab === 'for-you'
      || state.feed.starterMode
      || state.feed.usedSuggestedFeed
    )) {
      authors.add(state.feed.feedOwnerPubkey);
    }
    return [...authors];
  }

  function resetLiveHomeFeedBuffer(): void {
    if (state.liveHomeFeedBuffer.events.length > 0) {
      state.liveHomeFeedBuffer = clearLiveHomeFeedBuffer();
    }
  }

  function liveEventMatchesCurrentHomeFeed(event: RawEvent): boolean {
    return state.route.kind === 'home' && isLiveHomeFeedEventEligible(event, {
      authors: getLiveHomeAuthors(),
      hasMedia: deps.noteHasMedia,
      mutedPubkeys: state.viewerMutedPubkeys,
      postKinds: DURABLE_POST_KINDS,
      tab: state.route.tab,
      viewerPubkey: state.activeAccount?.pubkey ?? null,
    });
  }

  function bufferIncomingLiveHomeEvent(event: RawEvent): void {
    if (
      (state.route.kind === 'home' && state.route.tab === 'for-you')
      || state.allHomeNotes.length === 0
      || state.homeNotes.some(note => note.id === event.id)
      || dataPlane.getEventStatus(event.id) !== 'visible'
      || !liveEventMatchesCurrentHomeFeed(event)
    ) {
      return;
    }
    state.liveHomeFeedBuffer = bufferLiveHomeFeedEvent(
      state.liveHomeFeedBuffer,
      event,
      state.allHomeNotes,
    );
  }

  function scheduleLiveViewRefresh(change: SocialDataPlaneChange): void {
    const changedEvents = change.events;
    if (change.origin === 'live') {
      for (const event of changedEvents) {
        bufferIncomingLiveHomeEvent(event);
      }
    } else if (change.origin === 'local') {
      resetLiveHomeFeedBuffer();
      if (state.feed?.displayOrder) { state.feed = { ...state.feed, displayOrder: undefined }; }
    } else if (change.origin === 'restore') {
      state.pendingOverlayRestore = true;
    }
    for (const event of changedEvents) {
      deps.pendingLiveViewEvents.set(event.id, event);
    }
    if (state.liveViewRefreshTimer !== null) {
      return;
    }
    state.liveViewRefreshTimer = window.setTimeout(() => {
      state.liveViewRefreshTimer = null;
      const nextEvents = state.pendingOverlayRestore
        ? dataPlane.query({ includeDeletionEvents: true })
        : [...deps.pendingLiveViewEvents.values()];
      const profilePubkey = state.route.kind === 'profile' ? state.route.pubkey : null;
      state.pendingOverlayRestore = false;
      deps.pendingLiveViewEvents.clear();
      if (nextEvents.some((event) => event.kind === 5)) {
        deps.pruneTombstonedLocalPosts();
      }
      deps.cacheKnownNotes(nextEvents.filter((event) => (
        PROFILE_CONTENT_KINDS.includes(event.kind as (typeof PROFILE_CONTENT_KINDS)[number])
      )));
      if (nextEvents.some((event) => event.kind === 0 || event.kind === 5)) {
        state.liveProfiles = profileMapFromMetadataEvents(dataPlane.query({ kinds: [0] }));
      }
      state.liveOverlayVersion += 1;
      if (nextEvents.some((event) => event.kind === 3 || event.kind === 5)) {
        if (state.activeAccount) {
          const previous = state.viewerContactsEvent;
          state.viewerContactsEvent = deps.projectContactsEvent(previous, state.activeAccount.pubkey);
          state.viewerContactsProjectionAuthoritative = Boolean(previous || state.viewerContactsEvent);
          deps.applyViewerFollows(new Set(extractFollowPubkeys(state.viewerContactsEvent)));
        }
        if (profilePubkey && state.profileSocial) {
          deps.applyProfileSocialSnapshot(state.profileSocial);
        }
      }
      if (
        profilePubkey
        && nextEvents.some((event) => (
          event.pubkey === profilePubkey
          && PROFILE_CONTENT_KINDS.includes(event.kind as (typeof PROFILE_CONTENT_KINDS)[number])
        ))
      ) {
        state.profilePage ??= {
          rootNhash: state.rootNhash,
          profile: state.accountProfiles.get(profilePubkey) ?? null,
          notes: [],
        };
        state.loading = false;
      }
      if (
        state.route.kind === 'thread'
        && !state.threadPage?.note
        && deps.getKnownNoteByRef(state.route.ref)
      ) {
        deps.restartCurrentViewLoad();
      }
    }, LIVE_VIEW_REFRESH_DEBOUNCE_MS);
  }

  function getForYouRankingAuthors(): string[] {
    if (state.route.kind !== 'home' || state.route.tab !== 'for-you') {
      return [];
    }
    return [...new Set(
      state.feed?.continuation?.authors?.length
        ? state.feed.continuation.authors
        : state.feed?.follows?.length
          ? state.feed.follows
          : [...state.viewerFollows],
    )];
  }

  function getForYouOverlayInteractions(authors: string[], limit: number): RawEvent[] {
    return authors.length === 0 || limit <= 0
      ? []
      : dataPlane.query({ authors, kinds: [...FOR_YOU_INTERACTION_KINDS], limit });
  }

  async function showBufferedLiveHomePosts(): Promise<void> {
    if (state.bufferedLiveHomePostCount === 0) {
      return;
    }
    const revealed = [...state.bufferedLiveHomeEvents];
    if (state.feed?.displayOrder) {
      state.feed = { ...state.feed, displayOrder: undefined };
    }
    state.liveHomeFeedBuffer = clearLiveHomeFeedBuffer();
    state.liveOverlayVersion += 1;
    deps.cacheKnownNotes(revealed);
    deps.seedNewEmptyEngagements(revealed.map(getNoteEngagementTargetId));
    await tick();
    deps.scrollPageToTopInstant();
  }

  return {
    getForYouOverlayInteractions,
    getForYouRankingAuthors,
    getLiveHomeAuthors,
    liveEventMatchesCurrentHomeFeed,
    resetLiveHomeFeedBuffer,
    scheduleLiveViewRefresh,
    showBufferedLiveHomePosts,
  };
}
