import { writable } from 'svelte/store';
import {
  EXCHANGE_RATE_FRESH_TTL_MS,
  getExchangeRates,
  readCachedExchangeRates,
  type ExchangeRateCurrency,
  type ExchangeRateSnapshot,
} from './exchangeRates';

const ENSURE_RETRY_INTERVAL_MS = 60_000;
let currentSnapshot = readCachedExchangeRates();
const store = writable<ExchangeRateSnapshot | null>(currentSnapshot);
let inFlight: Promise<ExchangeRateSnapshot | null> | null = null;
let lastEnsureAttemptAt = 0;

export const exchangeRateStore = { subscribe: store.subscribe };

export function currencyNeedsExchangeRate(currency: ExchangeRateCurrency): boolean {
  return currency !== 'SAT' && currency !== 'BTC';
}

export function refreshExchangeRates(forceRefresh = false): Promise<ExchangeRateSnapshot | null> {
  if (inFlight) {
    return inFlight;
  }
  if (
    !forceRefresh
    && currentSnapshot
    && Date.now() - currentSnapshot.updatedAt < EXCHANGE_RATE_FRESH_TTL_MS
  ) {
    return Promise.resolve(currentSnapshot);
  }
  const request = getExchangeRates({ forceRefresh }).then((snapshot) => {
    currentSnapshot = snapshot;
    store.set(snapshot);
    return snapshot;
  });
  inFlight = request;
  const clear = () => {
    if (inFlight === request) {
      inFlight = null;
    }
  };
  void request.then(clear, clear);
  return request;
}

export function ensureExchangeRates(currency: ExchangeRateCurrency): void {
  if (!currencyNeedsExchangeRate(currency)) {
    return;
  }
  const now = Date.now();
  if (
    currentSnapshot
    && now - currentSnapshot.updatedAt < EXCHANGE_RATE_FRESH_TTL_MS
  ) {
    return;
  }
  if (now - lastEnsureAttemptAt < ENSURE_RETRY_INTERVAL_MS) {
    return;
  }
  lastEnsureAttemptAt = now;
  void refreshExchangeRates().catch(() => undefined);
}
