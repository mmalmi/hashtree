import type { CID } from '@hashtree/core';
import { parseHashtreeRootEvent } from '@hashtree/nostr';
import type { NostrEvent, NostrVerifiedEvent } from 'nostr-pubsub';
import * as nip19 from 'nostr-tools/nip19';
import { verifyEvent } from 'nostr-tools/pure';
import { verifyIndexedEvent } from './fastEventVerification';

export const PUBLISHED_ROOT_EVENT_CACHE_STORAGE_KEY = 'iris-social:published-root-events:v1';
export const DEFAULT_PUBLISHED_ROOT_EVENT_CACHE_LIMIT = 128;
export const MAX_PUBLISHED_ROOT_EVENT_CACHE_ENTRY_BYTES = 16_384;

const PUBLISHED_ROOT_EVENT_CACHE_FORMAT = 'iris-social/published-root-events@1' as const;
const CACHE_ENTRY_JSON_OVERHEAD_BYTES = 768;
const CACHE_JSON_OVERHEAD_BYTES = 512;
const textEncoder = new TextEncoder();

export type RootEventCacheStorage = Pick<Storage, 'getItem' | 'setItem'>;

export type MutablePublishedRootTarget = {
  kind: 'mutable';
  npub: string;
  path: string;
};

export type CanonicalMutableRootTarget = MutablePublishedRootTarget & {
  pubkey: string;
  cacheKey: string;
};

export type ValidatedPublishedRootEvent = {
  root: CID;
  createdAt: number;
  eventId: string;
};

type StoredRootEvent = {
  key: string;
  event: NostrEvent;
};

type StoredRootEventCache = {
  format: typeof PUBLISHED_ROOT_EVENT_CACHE_FORMAT;
  entries: StoredRootEvent[];
};

export function canonicalMutableRootTarget(
  target: MutablePublishedRootTarget,
): CanonicalMutableRootTarget | null {
  const path = target.path.trim();
  if (!path || path.includes('/')) {
    return null;
  }
  try {
    const decoded = nip19.decode(target.npub.trim().toLowerCase());
    if (decoded.type !== 'npub' || typeof decoded.data !== 'string') {
      return null;
    }
    const pubkey = decoded.data.toLowerCase();
    const npub = nip19.npubEncode(pubkey);
    return {
      kind: 'mutable',
      npub,
      pubkey,
      path,
      cacheKey: `${npub}/${path}`,
    };
  } catch {
    return null;
  }
}

export function canonicalPublishedRootCacheKey(npub: string, treeName: string): string {
  const target = canonicalMutableRootTarget({ kind: 'mutable', npub, path: treeName });
  if (!target) {
    throw new Error('Invalid mutable Hashtree root target');
  }
  return target.cacheKey;
}

function cloneEvent(event: NostrEvent): NostrEvent {
  return {
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

export function validatePublishedRootEvent(
  target: MutablePublishedRootTarget,
  event: NostrEvent,
): ValidatedPublishedRootEvent | null {
  try {
    // nostr-pubsub returns a verified, frozen defensive copy. Verify another
    // mutable copy so separate nostr-tools bundles cannot try to attach their
    // private verification symbol to the frozen transport object.
    const verifiedEvent = cloneEvent(event);
    return verifyEvent(verifiedEvent)
      ? validateAdmittedPublishedRootEvent(target, verifiedEvent as NostrVerifiedEvent)
      : null;
  } catch {
    return null;
  }
}

/**
 * Validate a root event already admitted by a trusted worker/transport.
 * The remaining author/path/root checks are cheap and contain no Schnorr work.
 */
export function validateAdmittedPublishedRootEvent(
  target: MutablePublishedRootTarget,
  event: NostrVerifiedEvent,
): ValidatedPublishedRootEvent | null {
  const canonical = canonicalMutableRootTarget(target);
  if (!canonical) {
    return null;
  }
  try {
    const identifiers = event.tags.filter((tag) => tag[0] === 'd');
    if (
      event.pubkey !== canonical.pubkey
      || identifiers.length !== 1
      || identifiers[0]?.[1] !== canonical.path
    ) {
      return null;
    }
    const parsed = parseHashtreeRootEvent(event);
    if (!parsed || parsed.treeName !== canonical.path) {
      return null;
    }
    return {
      root: parsed.rootCid,
      createdAt: event.created_at,
      eventId: event.id,
    };
  } catch {
    return null;
  }
}

/** Verify an untrusted cached root through the shared worker before using it. */
export async function validatePublishedRootEventAsync(
  target: MutablePublishedRootTarget,
  event: NostrEvent,
): Promise<ValidatedPublishedRootEvent | null> {
  try {
    const candidate = cloneEvent(event);
    if (!await verifyIndexedEvent(candidate)) {
      return null;
    }
    return validateAdmittedPublishedRootEvent(
      target,
      candidate as NostrVerifiedEvent,
    );
  } catch {
    return null;
  }
}

export function comparePublishedRootEvents(left: NostrEvent, right: NostrEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

export function getDefaultPublishedRootEventCache(): PublishedRootEventCache {
  let storage: Storage | null = null;
  if (typeof window !== 'undefined') {
    try {
      storage = window.localStorage;
    } catch {
      storage = null;
    }
  }
  return new PublishedRootEventCache(storage);
}

function isStringTagArray(value: unknown): value is string[][] {
  return Array.isArray(value) && value.every((tag) => (
    Array.isArray(tag) && tag.every((part) => typeof part === 'string')
  ));
}

function parseEvent(value: unknown): NostrEvent | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  const event = value as Partial<NostrEvent>;
  if (
    typeof event.id !== 'string'
    || typeof event.pubkey !== 'string'
    || typeof event.created_at !== 'number'
    || typeof event.kind !== 'number'
    || !isStringTagArray(event.tags)
    || typeof event.content !== 'string'
    || typeof event.sig !== 'string'
  ) {
    return null;
  }
  const cloned = cloneEvent(event as NostrEvent);
  try {
    return JSON.stringify(cloned).length <= MAX_PUBLISHED_ROOT_EVENT_CACHE_ENTRY_BYTES
      ? cloned
      : null;
  } catch {
    return null;
  }
}

/**
 * A tiny synchronous LRU for full signed Hashtree pointer events. Storage is
 * only an untrusted hint: callers must verify every event before using it.
 */
export class PublishedRootEventCache {
  private readonly storage: RootEventCacheStorage | null;
  private readonly maximumEntries: number;
  private readonly maximumRawBytes: number;

  constructor(
    storage: RootEventCacheStorage | null,
    maximumEntries = DEFAULT_PUBLISHED_ROOT_EVENT_CACHE_LIMIT,
  ) {
    this.storage = storage;
    this.maximumEntries = Math.max(1, Math.trunc(maximumEntries));
    this.maximumRawBytes = this.maximumEntries
      * (MAX_PUBLISHED_ROOT_EVENT_CACHE_ENTRY_BYTES + CACHE_ENTRY_JSON_OVERHEAD_BYTES)
      + CACHE_JSON_OVERHEAD_BYTES;
  }

  get(key: string): NostrEvent | null {
    const entries = this.readEntries();
    const index = entries.findIndex((entry) => entry.key === key);
    if (index < 0) {
      return null;
    }
    const [entry] = entries.splice(index, 1);
    if (!entry) {
      return null;
    }
    entries.unshift(entry);
    this.writeEntries(entries);
    return cloneEvent(entry.event);
  }

  set(key: string, event: NostrEvent): void {
    if (!key || key.length > 512) {
      return;
    }
    try {
      if (JSON.stringify(event).length > MAX_PUBLISHED_ROOT_EVENT_CACHE_ENTRY_BYTES) {
        return;
      }
    } catch {
      return;
    }
    const entries = this.readEntries().filter((entry) => entry.key !== key);
    entries.unshift({ key, event: cloneEvent(event) });
    this.writeEntries(entries.slice(0, this.maximumEntries));
  }

  delete(key: string): void {
    const entries = this.readEntries();
    const filtered = entries.filter((entry) => entry.key !== key);
    if (filtered.length !== entries.length) {
      this.writeEntries(filtered);
    }
  }

  private readEntries(): StoredRootEvent[] {
    if (!this.storage) {
      return [];
    }
    try {
      const raw = this.storage.getItem(PUBLISHED_ROOT_EVENT_CACHE_STORAGE_KEY);
      if (!raw) {
        return [];
      }
      if (
        raw.length > this.maximumRawBytes
        || textEncoder.encode(raw).byteLength > this.maximumRawBytes
      ) {
        this.writeEntries([]);
        return [];
      }
      const parsed = JSON.parse(raw) as Partial<StoredRootEventCache>;
      if (parsed.format !== PUBLISHED_ROOT_EVENT_CACHE_FORMAT || !Array.isArray(parsed.entries)) {
        this.writeEntries([]);
        return [];
      }
      const entries: StoredRootEvent[] = [];
      const seenKeys = new Set<string>();
      let requiresRewrite = parsed.entries.length > this.maximumEntries;
      for (const value of parsed.entries) {
        if (!value || typeof value !== 'object') {
          requiresRewrite = true;
          continue;
        }
        const candidate = value as Partial<StoredRootEvent>;
        const event = parseEvent(candidate.event);
        if (
          typeof candidate.key !== 'string'
          || !candidate.key
          || candidate.key.length > 512
          || seenKeys.has(candidate.key)
          || !event
        ) {
          requiresRewrite = true;
          continue;
        }
        seenKeys.add(candidate.key);
        entries.push({ key: candidate.key, event });
        if (entries.length >= this.maximumEntries) {
          break;
        }
      }
      if (requiresRewrite) {
        this.writeEntries(entries);
      }
      return entries;
    } catch {
      return [];
    }
  }

  private writeEntries(entries: StoredRootEvent[]): void {
    if (!this.storage) {
      return;
    }
    try {
      this.storage.setItem(PUBLISHED_ROOT_EVENT_CACHE_STORAGE_KEY, JSON.stringify({
        format: PUBLISHED_ROOT_EVENT_CACHE_FORMAT,
        entries,
      } satisfies StoredRootEventCache));
    } catch {
      // A denied/full storage area must never block immutable Hashtree reads.
    }
  }
}
