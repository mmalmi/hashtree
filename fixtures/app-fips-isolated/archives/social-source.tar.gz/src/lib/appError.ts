export type AppError = string | { summary: string; detail: string };
export type ReportAppError = typeof reportAppError;

// Signers and transports can include the request or credentials in their error messages.
function safeMessage(message: string, privateValues: readonly string[]): string {
  let text = message;
  for (const value of new Set(privateValues)) {
    if (value) { text = text.replaceAll(value, '[redacted]'); }
  }
  return text
    .split(/\n\s*at\s/)[0]
    .replace(/\b(?:bunker|nostrconnect|nostr\+walletconnect|nwc):\/\/\S+|\b(?:nsec1|ncryptsec1|cashu[ab])[\w=-]+|\b[\da-f]{64,}\b|\bBearer\s+\S+/gi, '[redacted]')
    .replace(/\b(?:https?|wss?):\/\/[^\s"')<>]+/gi, (url) => {
      try {
        const parsed = new URL(url);
        return parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/'
          ? `${parsed.origin}/[redacted]` : url;
      } catch { return '[redacted]'; }
    })
    .replace(/(?:\{\s*["']|\[\s*[[{"']|\b(?:payload|template|content|tags|secret|token|password|authorization|private[ _-]?key|seed phrase|mnemonic)\s*[:=])[\s\S]*/i, '[redacted]')
    .trim().slice(0, 800);
}

export function reportAppError(summary: string, error: unknown, privateValues: readonly string[] = []): AppError {
  const messages = new Set<string>();
  const seen = new Set<unknown>();
  let cause = error;
  while (cause && !seen.has(cause) && seen.size < 4) {
    seen.add(cause);
    const record = typeof cause === 'object' ? cause as { message?: unknown; cause?: unknown } : null;
    const message = typeof cause === 'string' ? cause : record?.message;
    if (typeof message === 'string') {
      const safe = safeMessage(message, privateValues);
      if (safe && safe !== summary && safe !== '[redacted]') { messages.add(safe); }
    }
    cause = record?.cause;
  }
  const detail = [...messages].join('\n');
  console.error(summary, detail);
  return detail ? { summary, detail } : summary;
}
