import { getContext, setContext } from 'svelte';
import type { ReferencedNotePreview } from './referencedNote';

export type WatchReferencedNote = (ref: string, onPreview: (preview: ReferencedNotePreview | null) => void) => () => void;

const context = Symbol('referenced-note-watcher');
export function provideReferencedNoteWatcher(watch: WatchReferencedNote): void { setContext(context, watch); }
export function getReferencedNoteWatcher(): WatchReferencedNote | null { return getContext<WatchReferencedNote>(context) ?? null; }
