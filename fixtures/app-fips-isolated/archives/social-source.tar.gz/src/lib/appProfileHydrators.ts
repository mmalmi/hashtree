import type { CID } from '@hashtree/core';
import { getRootNhash, loadProfilesForPubkeys, loadProfileSocial, type ProfileSocialSnapshot } from './nostrIndex';
import { loadSnapshotSocialGraphProfileSocial } from './socialGraphProfileSnapshot';

type ProfileHydratorDeps = {
  getLoadToken: () => number;
  getProfileSocial: () => ProfileSocialSnapshot | null;
  getProfileSocialFollowerFetchLimit: () => number;
  getProfilePageHasContent: (pubkey: string) => boolean;
  getCurrentRouteProfilePubkey: () => string | null;
  mergeCachedProfiles: (profiles: Map<string, any>) => void;
  restartCurrentViewLoad: () => void;
  setProfileSocial: (social: ProfileSocialSnapshot | null) => void;
  setProfileSocialLoading: (loading: boolean) => void;
  setProfileEmptyRetryKey: (key: string | null) => void;
  getProfileEmptyRetryKey: () => string | null;
  loadProfileSocial?: typeof loadProfileSocial;
  loadProfilesForPubkeys?: typeof loadProfilesForPubkeys;
  loadSnapshotSocialGraphProfileSocial?: typeof loadSnapshotSocialGraphProfileSocial;
};

export function createProfileHydrators(deps: ProfileHydratorDeps) {
  const loadProfileSocialSnapshot = deps.loadProfileSocial ?? loadProfileSocial;
  const loadProfileRecords = deps.loadProfilesForPubkeys ?? loadProfilesForPubkeys;
  const loadLocalGraph = deps.loadSnapshotSocialGraphProfileSocial ?? loadSnapshotSocialGraphProfileSocial;
  let activeProfileListController: AbortController | null = null;
  let activeProfileSocialController: AbortController | null = null;

  const cancelController = (
    controller: AbortController | null,
    message: string,
  ): void => {
    if (controller && !controller.signal.aborted) {
      controller.abort(new DOMException(message, 'AbortError'));
    }
  };

  return {
    cancelPendingProfileHydrations(): void {
      cancelController(activeProfileListController, 'Profile list hydration cancelled');
      cancelController(activeProfileSocialController, 'Profile social hydration cancelled');
      activeProfileListController = null;
      activeProfileSocialController = null;
    },

    async hydrateProfileListProfiles(
      currentRoot: CID,
      pubkeys: string[],
      token: number,
    ): Promise<void> {
      const uniquePubkeys = [...new Set(pubkeys)];
      if (uniquePubkeys.length === 0) {
        return;
      }

      cancelController(activeProfileListController, 'Profile list hydration superseded');
      const controller = new AbortController();
      activeProfileListController = controller;
      const isCurrent = () => (
        !controller.signal.aborted
        && token === deps.getLoadToken()
      );
      const nextProfiles = new Map(deps.getProfileSocial()?.profiles ?? []);
      const chunkSize = 48;

      try {
        for (let index = 0; index < uniquePubkeys.length; index += chunkSize) {
          const chunk = uniquePubkeys.slice(index, index + chunkSize);

          const chunkProfiles = await loadProfileRecords(currentRoot, chunk, {
            signal: controller.signal,
            isCurrent,
          });
          if (!isCurrent()) {
            return;
          }

          for (const [pubkey, profile] of chunkProfiles) {
            nextProfiles.set(pubkey, profile);
          }

          if (deps.getProfileSocial()) {
            deps.setProfileSocial({
              ...(deps.getProfileSocial() as ProfileSocialSnapshot),
              profiles: new Map(nextProfiles),
            });
          }
          deps.mergeCachedProfiles(chunkProfiles);
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          console.warn('Failed to hydrate profile list profiles', error);
        }
      } finally {
        if (activeProfileListController === controller) {
          activeProfileListController = null;
        }
      }
    },

    async hydrateProfileSocial(
      currentRoot: CID | null,
      pubkey: string,
      token: number,
      options: {
        includeProfiles?: boolean;
        includeFollows?: boolean;
        includeFollowers?: boolean;
        progressSection?: 'follows' | 'followers';
      } = {},
    ): Promise<void> {
      cancelController(activeProfileSocialController, 'Profile social hydration superseded');
      const controller = new AbortController();
      activeProfileSocialController = controller;
      try {
        const nextSocial = currentRoot ? await loadProfileSocialSnapshot(currentRoot, pubkey, {
          followerLimit: deps.getProfileSocialFollowerFetchLimit(),
          // Content routes need all available mutual IDs before the modal
          // sorts and renders its first page, without loading their profiles.
          snapshotFollowerLimit: options.includeProfiles === false ? 65_536 : undefined,
          includeProfiles: false,
          includeFollows: options.includeFollows,
          includeFollowers: options.includeFollowers,
          signal: controller.signal,
          onProgress: options.progressSection
            ? (progress) => {
                if (
                  controller.signal.aborted
                  ||
                  token !== deps.getLoadToken()
                  || deps.getCurrentRouteProfilePubkey() !== pubkey
                  || (options.progressSection === 'follows' && !progress.hasFollows)
                  || (options.progressSection === 'followers' && !progress.hasFollowers)
                ) {
                  return;
                }

                const currentSocial = deps.getProfileSocial();
                deps.setProfileSocial({
                  ...progress,
                  profiles: new Map(currentSocial?.profiles ?? []),
                });
                deps.setProfileSocialLoading(false);

                if (currentRoot && options.includeProfiles !== false) {
                  void this.hydrateProfileListProfiles(
                    currentRoot,
                    [pubkey, ...progress.follows, ...progress.followers],
                    token,
                  );
                }
              }
            : undefined,
        }) : await loadLocalGraph(pubkey, deps.getProfileSocialFollowerFetchLimit(), controller.signal)
          .then((social): ProfileSocialSnapshot | null => social ? {
            ...social,
            rootNhash: '',
            contactsEvent: null,
            profiles: new Map(),
            followersTruncated: social.followersCount > social.followers.length,
            hasFollows: true,
            hasFollowers: true,
          } : null);
        if (controller.signal.aborted || token !== deps.getLoadToken()) {
          return;
        }

        if (!nextSocial) {
          deps.setProfileSocial(null);
          deps.setProfileSocialLoading(false);
          return;
        }
        deps.setProfileSocial({
          ...nextSocial,
          profiles: new Map(deps.getProfileSocial()?.profiles ?? nextSocial.profiles),
        });
        deps.setProfileSocialLoading(false);

        if (currentRoot && options.includeProfiles !== false) {
          const profilePubkeys = [
            ...(options.includeFollows === false ? [] : nextSocial.follows),
            ...(options.includeFollowers === false ? [] : nextSocial.followers),
            pubkey,
          ];
          void this.hydrateProfileListProfiles(currentRoot, profilePubkeys, token);
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          console.warn('Failed to load profile social lists', error);
        }
        if (!controller.signal.aborted && token === deps.getLoadToken()) {
          deps.setProfileSocial(null);
          deps.setProfileSocialLoading(false);
        }
      } finally {
        if (activeProfileSocialController === controller) {
          activeProfileSocialController = null;
        }
      }
    },

    scheduleProfileSocialHydration(
      currentRoot: CID | null,
      pubkey: string,
      token: number,
      options: {
        includeProfiles?: boolean;
        includeFollows?: boolean;
        includeFollowers?: boolean;
        progressSection?: 'follows' | 'followers';
        defer?: boolean;
      } = {},
    ): void {
      const hydrate = () => {
        if (token !== deps.getLoadToken() || deps.getCurrentRouteProfilePubkey() !== pubkey) {
          return;
        }
        void this.hydrateProfileSocial(currentRoot, pubkey, token, options);
      };

      if (!options.defer) {
        hydrate();
        return;
      }

      if (typeof requestIdleCallback === 'function') {
        requestIdleCallback(hydrate, { timeout: 1_000 });
        return;
      }

      setTimeout(hydrate, 0);
    },

    scheduleEmptyProfileRetry(currentRoot: CID, pubkey: string, token: number): void {
      const retryKey = `${getRootNhash(currentRoot)}:${pubkey}`;
      if (deps.getProfileEmptyRetryKey() === retryKey) {
        return;
      }

      setTimeout(() => {
        if (token !== deps.getLoadToken() || deps.getCurrentRouteProfilePubkey() !== pubkey) {
          return;
        }

        if (deps.getProfilePageHasContent(pubkey)) {
          return;
        }

        deps.setProfileEmptyRetryKey(retryKey);
        deps.restartCurrentViewLoad();
      }, 1200);
    },
  };
}
