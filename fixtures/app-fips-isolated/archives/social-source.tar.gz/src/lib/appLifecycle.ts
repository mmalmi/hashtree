import { withProfileLoadAbort } from './profileLoadAbort';
import type { AppError, ReportAppError } from './appError';
import { subscribeSignedGraphSeed } from './socialGraphProfileSnapshot';
import { touchesProfileRelationships } from './socialGraphProfileQuery';
import { subscribeAppliedSocialGraphEvents } from './socialGraphWorkerObservation';
import type { createProfileHydrators } from './appProfileHydrators';
import { getNoteEngagementTargetId } from './noteEngagement';
import { canSignAccount } from './accountSigner';
import { onMount, tick } from 'svelte';
import { startBrowserProfileRefresh } from './browserProfileRefresh';
import type { CID } from '@hashtree/core';
import { accountsStore, initAccountsStore, isParkedDefaultAccount, syncStoredAccounts } from './accounts';
import { getCurrentActiveAccountPubkey } from './appAccountState';
import {
  readHistoryScrollState,
  readStoredRouteScroll,
  shouldRestoreInitialRouteScroll,
} from './appNavigation';
import { parseRouteLocation, routeForViewer, routeKey, threadRouteDiscoveryRef, type Route } from './appRoute';
import {
  getActiveAppRouteElement,
  getActiveAppScrollElement,
  getAppScrollOffset,
  isActiveAppScrollEvent,
  markAppScrollInteraction,
} from './appScroll';
import type { AppCombinedState } from './appState';
import { startAppDataSources } from './appStartup';
import type { createBoundedHydrationScheduler } from './boundedHydrationScheduler';
import type { DebouncedTask } from './debouncedTask';
import { routedProfilesByPubkey } from './routedEventReads';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import {
  flattenLocalPostsByAuthor,
  mergeLocalPostsByAuthor,
  readLocalPostsFromStorageAsync,
} from './appNoteState';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  subscribePendingPersonalEventChanges,
  subscribePersonalEventIndexRootChanges,
  resumePersonalEventIndexes,
} from './personalEventIndexBrowser';
import {
  configureSharedProfileResolver,
  pendingInitialProfileMetadata,
  rememberProfileRecords,
} from './profileCache';
import {
  mergeProfileMaps,
  profileMapFromMetadataEvents,
} from './profileRecords';
import { warmSocialGraphFrontier } from './socialGraphFrontier';
import { socialDataPlane, type SocialDataPlaneChange } from './socialDataPlane';
import {
  resolveConfiguredEventIndexRoot,
  watchConfiguredEventIndexRoot,
} from './nostrIndex';
import type { RawEvent } from './nostr';
import type { ShadowReadObservation, ShadowReadScope } from './shadowReadComparator';
import { appHistoryState, readAppHistoryIndex, replaceGuestHomeRoute } from './appHistoryNavigation';
import { waitForNextBrowserPaint } from './asyncTiming';

const APP_SCROLL_KEYS = new Set([
  'ArrowDown',
  'ArrowUp',
  'End',
  'Home',
  'PageDown',
  'PageUp',
  ' ',
]);

type LifecycleDeps = {
  state: AppCombinedState;
  profileHydrators: Pick<ReturnType<typeof createProfileHydrators>, 'scheduleProfileSocialHydration'>;
  homeFeedSeenBatcher: ReturnType<typeof createHomeFeedSeenBatcher>;
  pendingLiveViewEvents: Map<string, RawEvent>;
  pendingShadowReadObservations: Map<ShadowReadScope, ShadowReadObservation>;
  profileSearchDebounce: DebouncedTask;
  visibleNoteHydrationScheduler: ReturnType<typeof createBoundedHydrationScheduler>;
  applyCachedRoot: (root: CID) => boolean;
  applySearchRoute: (route: Route) => void;
  applyViewerOverride: (value: string) => void;
  cacheKnownNotes: (...notes: RawEvent[][]) => void;
  getKnownNoteByRef: (ref: string) => RawEvent | null;
  clearRootBoundState: () => void;
  consumeViewerOverride: () => string;
  handleDocumentNavigationClick: (event: MouseEvent) => void;
  handleRouteLocationChange: (options?: { fromPopState?: boolean }) => void;
  initializeFeedSources: () => void;
  loadAccountSheet: () => Promise<void>;
  persistCurrentRouteScroll: (key?: string, offset?: number, updateHistory?: boolean) => void;
  persistCurrentRouteScrollIfNeeded: () => void;
  pruneTombstonedLocalPosts: () => void;
  readNotificationsSeenAt: () => number;
  replaceNonCanonicalIdentifierRoute: (route: Route) => Route;
  reportError: ReportAppError;
  resetActiveAccountUiState: (nextViewerPubkey?: string | null) => void;
  resetHomeFeedPagination: () => void;
  resetLiveHomeFeedBuffer: () => void;
  resetProfileFeedPagination: () => void;
  restartCurrentViewLoad: () => void;
  restoreHomeFeedSnapshot: () => void;
  scheduleCurrentRouteScrollPersistence: () => void;
  scheduleLiveViewRefresh: (change: SocialDataPlaneChange) => void;
  seedEmptyEngagements: (noteIds: string[]) => void;
  stripTransientQueryParams: () => void;
  syncRouteStack: (route: Route) => void;
  warmSearchResources: () => void;
};

export function getRootUnavailableError(
  state: Pick<AppCombinedState, 'feed' | 'homeNotes'>
    & Partial<Pick<AppCombinedState, 'route' | 'threadPage'>>,
  message: AppError,
): AppError {
  // Missing remote content must not insert a late banner above a usable
  // retained/local feed and shift its restored scroll position.
  return (state.feed?.notes.length ?? 0) > 0 || state.homeNotes.length > 0
    || (state.route?.kind === 'thread' && Boolean(state.threadPage?.note))
    ? ''
    : message;
}

export function registerAppLifecycle(deps: LifecycleDeps): void {
  const { state } = deps;
  onMount(() => {
    let disposed = false;
    const stopProfileRefresh = startBrowserProfileRefresh();
    const persistedCacheHydrationController = new AbortController();
    const refreshOpenProfileSocial = (): void => {
      const route = state.route;
      if (route.kind === 'profile' && route.pubkey) {
        deps.profileHydrators.scheduleProfileSocialHydration(state.root, route.pubkey, state.loadToken, {
          includeProfiles: route.section === 'follows' || route.section === 'followers',
          defer: false,
        });
      }
    };
    const stopSeedRefresh = subscribeSignedGraphSeed(refreshOpenProfileSocial);
    // Without an index root, a profile's relationships come only from the
    // local graph. Saved lists reach it after first paint, so refresh the open
    // profile when a list by or about it lands.
    const stopAppliedGraphRefresh = subscribeAppliedSocialGraphEvents((events) => {
      const route = state.route;
      if (!state.root && route.kind === 'profile' && route.pubkey
        && touchesProfileRelationships(events, route.pubkey)) {
        refreshOpenProfileSocial();
      }
    });
    const resolveRoutedProfiles = async (pubkeys: string[], signal?: AbortSignal) => {
      const profileRoot = state.root ?? await withProfileLoadAbort(resolveConfiguredEventIndexRoot(), signal);
      return profileRoot ? await routedProfilesByPubkey([profileRoot], pubkeys, { signal }) : new Map();
    };
    const disposeSharedProfileResolver = configureSharedProfileResolver(
      async (pubkey, signal) => (await resolveRoutedProfiles([pubkey], signal)).get(pubkey) ?? null,
      resolveRoutedProfiles,
    );
    deps.stripTransientQueryParams();
    initAccountsStore();
    const override = deps.consumeViewerOverride();
    if (override) { deps.applyViewerOverride(override); }
    state.route = replaceGuestHomeRoute(
      parseRouteLocation(window.location.pathname, window.location.hash),
      Boolean(accountsStore.getState().activeAccountPubkey),
    );
    state.route = deps.replaceNonCanonicalIdentifierRoute(state.route);
    deps.applySearchRoute(state.route);
    const initialProfilePubkey = state.route.kind === 'profile'
      ? state.route.pubkey
      : null;
    pendingInitialProfileMetadata.set(initialProfilePubkey);
    if (state.route.kind === 'search' || state.route.kind === 'accounts') {
      const initialRouteKey = routeKey(state.route);
      void waitForNextBrowserPaint().then(() => {
        if (routeKey(state.route) !== initialRouteKey) {
          return;
        }
        if (state.route.kind === 'search') {
          deps.warmSearchResources();
        } else if (state.route.kind === 'accounts') {
          void deps.loadAccountSheet();
        }
      });
    }
    if (state.route.kind === 'home') {
      deps.resetHomeFeedPagination();
    } else if (state.route.kind === 'profile') {
      deps.resetProfileFeedPagination();
    }
    deps.syncRouteStack(state.route);
    const initialHistoryScroll = readHistoryScrollState();
    const initialStoredScroll = readStoredRouteScroll(routeKey(state.route));
    const initialScrollOffset = initialHistoryScroll ?? initialStoredScroll;
    if (
      shouldRestoreInitialRouteScroll()
      && typeof initialScrollOffset === 'number'
      && initialScrollOffset > 0
    ) {
      state.pendingScrollMode = 'restore';
      state.pendingScrollRestoreKey = routeKey(state.route);
      state.pendingScrollRestoreOffset = initialScrollOffset;
    }
    const unsubscribePersonalRoots = subscribePersonalEventIndexRootChanges((pubkey, nextRoot) => {
      const activePubkey = getCurrentActiveAccountPubkey(
        accountsStore.getState().activeAccountPubkey ?? null,
        accountsStore.getState().accounts,
      );
      if (pubkey === activePubkey) {
        state.viewerPersonalRoot = nextRoot;
      }
      if (state.route.kind === 'profile' && state.route.pubkey === pubkey) {
        state.profilePersonalRoot = nextRoot;
      }
      const currentRouteNeedsRoot = state.route.kind === 'profile'
        ? state.route.pubkey === pubkey
        : (
            (state.route.kind === 'home' && state.route.tab !== 'for-you')
            || state.route.kind === 'notifications'
          ) && pubkey === activePubkey;
      if (nextRoot && currentRouteNeedsRoot && state.personalRootRefreshTimer === null) {
        state.personalRootRefreshTimer = window.setTimeout(() => {
          state.personalRootRefreshTimer = null;
          deps.restartCurrentViewLoad();
        }, 50);
      }
    });
    const unsubscribePendingEvents = subscribePendingPersonalEventChanges((pubkey) => {
      const account = accountsStore.getState().accounts.find((candidate) => (
        candidate.pubkey === pubkey && !isParkedDefaultAccount(candidate)
      ));
      if (account && canSignAccount(account)) {
        void resumePersonalEventIndexes([account]);
      }
    });
    const accountsToResume = accountsStore.getState().accounts.filter((account) => !isParkedDefaultAccount(account));
    if (accountsToResume.length > 0) {
      void resumePersonalEventIndexes(accountsToResume, socialDataPlane.query({ includeDeletionEvents: true }));
    }
    warmSocialGraphFrontier();
    deps.pruneTombstonedLocalPosts();
    const storedLocalPosts = flattenLocalPostsByAuthor(state.localPostsByAuthor);
    const restoredOverlayNotes = socialDataPlane.query({ kinds: PROFILE_CONTENT_KINDS });
    deps.cacheKnownNotes(storedLocalPosts, restoredOverlayNotes);
    deps.seedEmptyEngagements(
      [...storedLocalPosts, ...restoredOverlayNotes].map(getNoteEngagementTargetId),
    );
    const signal = persistedCacheHydrationController.signal;
    if (initialProfilePubkey) {
      void socialDataPlane.readPersistedMetadataAsync([initialProfilePubkey], signal).then(restoredMetadata => {
        if (disposed || signal.aborted) { return; }
        if (restoredMetadata.length > 0) {
          const restoredProfiles = profileMapFromMetadataEvents(restoredMetadata);
          state.liveProfiles = mergeProfileMaps(state.liveProfiles, restoredProfiles);
          rememberProfileRecords(restoredProfiles.values());
        }
      }).catch(error => {
        if (!signal.aborted) { console.warn('Saved profile could not be restored', error); }
      }).finally(() => {
        if (!disposed) { pendingInitialProfileMetadata.set(null); }
      });
    }
    const localContentReady = waitForNextBrowserPaint().then(async () => {
      const restoredLocalPosts = await readLocalPostsFromStorageAsync(undefined, { signal });
      if (disposed || signal.aborted) {
        return;
      }

      // Posts composed while restoration was in flight stay authoritative.
      // Merging at commit time also deduplicates the persisted copy by id.
      state.localPostsByAuthor = mergeLocalPostsByAuthor(
        state.localPostsByAuthor,
        restoredLocalPosts,
      );
      deps.pruneTombstonedLocalPosts();
      const localPosts = flattenLocalPostsByAuthor(state.localPostsByAuthor);
      deps.cacheKnownNotes(localPosts);
      deps.seedEmptyEngagements(localPosts.map(getNoteEngagementTargetId));
      // A cold deep link can load before signature checks restore its saved note.
      if (state.route.kind === 'thread' && !state.threadPage?.note
        && deps.getKnownNoteByRef(threadRouteDiscoveryRef(state.route))) {
        deps.restartCurrentViewLoad();
      }
    }).catch((error) => {
      if (!persistedCacheHydrationController.signal.aborted) {
        console.warn('Saved local social data could not be restored', error);
      }
    });
    state.notificationsSeenAt = deps.readNotificationsSeenAt();
    deps.initializeFeedSources();
    deps.restoreHomeFeedSnapshot();
    const unsubscribeSocialDataPlane = socialDataPlane.subscribe(deps.scheduleLiveViewRefresh);
    const previousScrollRestoration = window.history.scrollRestoration;
    window.history.scrollRestoration = 'manual';
    state.appHistoryIndex = readAppHistoryIndex(window.history.state) ?? 0;
    if (readAppHistoryIndex(window.history.state) === null) {
      window.history.replaceState(appHistoryState(state.appHistoryIndex), '');
    }
    const onPopState = (event: PopStateEvent) => {
      const presentedKey = getActiveAppRouteElement()?.dataset.routeKey ?? routeKey(state.route);
      deps.persistCurrentRouteScroll(presentedKey, getAppScrollOffset(), false);
      state.appHistoryIndex = readAppHistoryIndex(event.state) ?? 0;
      deps.handleRouteLocationChange({ fromPopState: true });
    };
    const onScroll = (event: Event) => {
      if (isActiveAppScrollEvent(event)) {
        deps.scheduleCurrentRouteScrollPersistence();
      }
    };
    const onScrollIntent = (event: Event) => {
      const target = event.target;
      const scrollElement = getActiveAppScrollElement();
      if (
        !scrollElement
        || !(target instanceof Node)
        || !scrollElement.contains(target)
      ) {
        return;
      }
      if (
        event instanceof KeyboardEvent
        && (
          !APP_SCROLL_KEYS.has(event.key)
          || event.metaKey
          || event.ctrlKey
          || event.altKey
        )
      ) {
        return;
      }
      markAppScrollInteraction();
    };
    const onPageHide = () => {
      deps.homeFeedSeenBatcher.flush();
      deps.persistCurrentRouteScrollIfNeeded();
    };
    const onProfileStorageChange = (event: StorageEvent): void => {
      if (!syncStoredAccounts(event)) {return;}
      const activeAccountPubkey = accountsStore.getState().activeAccountPubkey;
      deps.resetActiveAccountUiState(activeAccountPubkey);
      const route = state.route;
      if (routeForViewer(route, Boolean(activeAccountPubkey)) !== route) {
        deps.handleRouteLocationChange();
      } else {
        deps.restartCurrentViewLoad();
      }
    };
    window.addEventListener('storage', onProfileStorageChange);
    window.addEventListener('popstate', onPopState);
    document.addEventListener('scroll', onScroll, { capture: true, passive: true });
    document.addEventListener('wheel', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('touchstart', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('pointerdown', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('keydown', onScrollIntent, true);
    window.addEventListener('pagehide', onPageHide);
    document.addEventListener('click', deps.handleDocumentNavigationClick);
    // A retained graph can populate a profile while the content index is offline.
    if (state.route.kind === 'profile') {
      deps.restartCurrentViewLoad();
    }
    async function finishMissingRoot(message: AppError): Promise<void> {
      await localContentReady;
      if (disposed || state.root) {return;}
      // The Home projection shows verified local posts once loading finishes.
      state.loading = false;
      await tick();
      if (disposed || state.root) {return;}
      state.rootNhash = '';
      state.rootError = getRootUnavailableError(state, message);
      state.accountProfiles = new Map();
      state.optimisticNoteEngagements = new Map();
      if (state.route.kind !== 'profile' && state.rootError) {
        deps.clearRootBoundState();
      }
      // Settings and other root-free views still load the viewer's own
      // profile, follows and mutes from the personal Hashtree index.
      if (['settings', 'search', 'wallet', 'accounts', 'username'].includes(state.route.kind)) {
        deps.restartCurrentViewLoad();
      }
    }
    void (async () => {
      if (override) { await tick(); }
      if (disposed) {
        return;
      }
      try {
        const stopWatching = await startAppDataSources({
          startLive: () => socialDataPlane.start(),
          onLiveError: (error) => console.warn('Live Nostr data plane is unavailable', error),
          watchDurableRoot: () => watchConfiguredEventIndexRoot(async (nextRoot) => {
            if (disposed) {
              return;
            }
            if (!nextRoot) {
              await finishMissingRoot("Couldn't load the feed right now.");
              return;
            }
            const changed = deps.applyCachedRoot(nextRoot);
            if (changed) {
              deps.resetLiveHomeFeedBuffer();
            }
            const shouldRefresh = changed || (
              state.route.kind === 'home'
                ? !state.feed || state.feed.notes.length === 0
                : !state.profilePage
            );
            if (shouldRefresh) {
              deps.restartCurrentViewLoad();
            }
          }),
        });
        if (disposed) {
          await stopWatching();
        } else {
          state.stopRootWatch = stopWatching;
        }
      } catch (error) {
        if (!disposed && !state.root) {
          await finishMissingRoot(deps.reportError("Couldn't load the feed right now.", error));
        }
      }
    })();
    return () => {
      disposed = true;
      persistedCacheHydrationController.abort();
      if (state.personalRootRefreshTimer !== null) {
        window.clearTimeout(state.personalRootRefreshTimer);
      }
      window.removeEventListener('storage', onProfileStorageChange);
      window.removeEventListener('popstate', onPopState);
      document.removeEventListener('scroll', onScroll, true);
      document.removeEventListener('wheel', onScrollIntent, true);
      document.removeEventListener('touchstart', onScrollIntent, true);
      document.removeEventListener('pointerdown', onScrollIntent, true);
      document.removeEventListener('keydown', onScrollIntent, true);
      window.removeEventListener('pagehide', onPageHide);
      document.removeEventListener('click', deps.handleDocumentNavigationClick);
      if (state.routeScrollPersistTimer !== null) {
        window.clearTimeout(state.routeScrollPersistTimer);
      }
      window.history.scrollRestoration = previousScrollRestoration;
      deps.profileSearchDebounce.cancel();
      unsubscribeSocialDataPlane();
      unsubscribePersonalRoots();
      unsubscribePendingEvents();
      stopSeedRefresh();
      stopAppliedGraphRefresh();
      disposeSharedProfileResolver();
      stopProfileRefresh();
      socialDataPlane.stop();
      state.cancelShadowReadIdleDrain?.();
      deps.pendingShadowReadObservations.clear();
      void state.shadowReadComparatorPromise?.then((comparator) => comparator.stop()).catch(() => undefined);
      if (state.liveViewRefreshTimer !== null) {
        window.clearTimeout(state.liveViewRefreshTimer);
      }
      if (state.homeFeedSnapshotWriteTimer !== null) {
        window.clearTimeout(state.homeFeedSnapshotWriteTimer);
      }
      state.homeFeedSnapshotWriteController?.abort();
      deps.pendingLiveViewEvents.clear();
      state.pendingOverlayRestore = false;
      deps.visibleNoteHydrationScheduler.dispose();
      deps.homeFeedSeenBatcher.destroy();
      void state.stopRootWatch?.();
    };
  });
}
