import { getNoteEngagementTargetId } from './noteEngagement';
import { canSignAccount } from './accountSigner';
import { onMount, tick } from 'svelte';
import { startBrowserProfileRefresh } from './browserProfileRefresh';
import type { CID } from '@hashtree/core';
import { accountsStore, initAccountsStore } from './accounts';
import { getCurrentActiveAccountPubkey } from './appAccountState';
import {
  readHistoryScrollState,
  readStoredRouteScroll,
  shouldRestoreInitialRouteScroll,
} from './appNavigation';
import { parseRouteLocation, routeKey, type Route } from './appRoute';
import {
  getActiveAppRouteElement,
  getActiveAppScrollElement,
  getAppScrollOffset,
  isActiveAppScrollEvent,
  markAppScrollInteraction,
} from './appScroll';
import type { AppCombinedState } from './appState';
import { startAppDataSources } from './appStartup';
import type { createBoundedHydrationScheduler } from './boundedHydrationScheduler';
import type { DebouncedTask } from './debouncedTask';
import { loadEventIndexProfileRecord } from './eventIndexProfile';
import type { createHomeFeedSeenBatcher } from './homeFeedSeen';
import {
  flattenLocalPostsByAuthor,
  mergeLocalPostsByAuthor,
  readLocalPostsFromStorageAsync,
} from './appNoteState';
import { PROFILE_CONTENT_KINDS } from './profileContent';
import {
  subscribePendingPersonalEventChanges,
  subscribePersonalEventIndexRootChanges,
  resumePersonalEventIndexes,
} from './personalEventIndexBrowser';
import {
  configureSharedProfileResolver,
  pendingInitialProfileMetadata,
  rememberProfileRecord,
  rememberProfileRecords,
} from './profileCache';
import {
  mergeProfileMaps,
  profileMapFromMetadataEvents,
} from './profileRecords';
import { warmSocialGraphFrontier } from './socialGraphFrontier';
import { socialDataPlane, type SocialDataPlaneChange } from './socialDataPlane';
import {
  resolveConfiguredEventIndexRoot,
  watchConfiguredEventIndexRoot,
} from './nostrIndex';
import type { RawEvent } from './nostr';
import type { ShadowReadObservation, ShadowReadScope } from './shadowReadComparator';
import { appHistoryState, readAppHistoryIndex } from './appHistoryNavigation';
import { waitForNextBrowserPaint } from './asyncTiming';

const APP_SCROLL_KEYS = new Set([
  'ArrowDown',
  'ArrowUp',
  'End',
  'Home',
  'PageDown',
  'PageUp',
  ' ',
]);

type LifecycleDeps = {
  state: AppCombinedState;
  homeFeedSeenBatcher: ReturnType<typeof createHomeFeedSeenBatcher>;
  pendingLiveViewEvents: Map<string, RawEvent>;
  pendingShadowReadObservations: Map<ShadowReadScope, ShadowReadObservation>;
  profileSearchDebounce: DebouncedTask;
  visibleNoteHydrationScheduler: ReturnType<typeof createBoundedHydrationScheduler>;
  applyCachedRoot: (root: CID) => boolean;
  applySearchRoute: (route: Route) => void;
  applyViewerOverride: (value: string) => void;
  cacheKnownNotes: (...notes: RawEvent[][]) => void;
  clearRootBoundState: () => void;
  consumeViewerOverride: () => string;
  handleDocumentNavigationClick: (event: MouseEvent) => void;
  handleRouteLocationChange: (options?: { fromPopState?: boolean }) => void;
  initializeFeedSources: () => void;
  loadAccountSheet: () => Promise<void>;
  persistCurrentRouteScroll: (key?: string, offset?: number, updateHistory?: boolean) => void;
  persistCurrentRouteScrollIfNeeded: () => void;
  pruneTombstonedLocalPosts: () => void;
  readNotificationsSeenAt: () => number;
  replaceNonCanonicalIdentifierRoute: (route: Route) => Route;
  reportError: (fallbackMessage: string, error: unknown) => string;
  resetHomeFeedPagination: () => void;
  resetLiveHomeFeedBuffer: () => void;
  resetProfileFeedPagination: () => void;
  restartCurrentViewLoad: () => void;
  restoreHomeFeedSnapshot: () => void;
  scheduleCurrentRouteScrollPersistence: () => void;
  scheduleLiveViewRefresh: (change: SocialDataPlaneChange) => void;
  seedEmptyEngagements: (noteIds: string[]) => void;
  stripTransientQueryParams: () => void;
  syncRouteStack: (route: Route) => void;
  warmSearchResources: () => void;
};

export function getRootUnavailableError(
  state: Pick<AppCombinedState, 'feed' | 'homeNotes'>
    & Partial<Pick<AppCombinedState, 'route' | 'threadPage'>>,
  message: string,
): string {
  // Missing remote content must not insert a late banner above a usable
  // retained/local feed and shift its restored scroll position.
  return (state.feed?.notes.length ?? 0) > 0 || state.homeNotes.length > 0
    || (state.route?.kind === 'thread' && Boolean(state.threadPage?.note))
    ? ''
    : message;
}

export function registerAppLifecycle(deps: LifecycleDeps): void {
  const { state } = deps;
  onMount(() => {
    let disposed = false;
    const stopProfileRefresh = startBrowserProfileRefresh();
    const persistedCacheHydrationController = new AbortController();
    const disposeSharedProfileResolver = configureSharedProfileResolver(async (pubkey, signal) => {
      const profileRoot = state.root ?? await resolveConfiguredEventIndexRoot();
      return profileRoot
        ? await loadEventIndexProfileRecord(profileRoot, pubkey, {
            signal,
            onProfile: rememberProfileRecord,
          })
        : null;
    });
    deps.stripTransientQueryParams();
    state.route = parseRouteLocation(window.location.pathname, window.location.hash);
    state.route = deps.replaceNonCanonicalIdentifierRoute(state.route);
    deps.applySearchRoute(state.route);
    const initialProfilePubkey = state.route.kind === 'profile'
      ? state.route.pubkey
      : null;
    pendingInitialProfileMetadata.set(initialProfilePubkey);
    if (state.route.kind === 'search' || state.route.kind === 'accounts') {
      const initialRouteKey = routeKey(state.route);
      void waitForNextBrowserPaint().then(() => {
        if (routeKey(state.route) !== initialRouteKey) {
          return;
        }
        if (state.route.kind === 'search') {
          deps.warmSearchResources();
        } else if (state.route.kind === 'accounts') {
          void deps.loadAccountSheet();
        }
      });
    }
    if (state.route.kind === 'home') {
      deps.resetHomeFeedPagination();
    } else if (state.route.kind === 'profile') {
      deps.resetProfileFeedPagination();
    }
    deps.syncRouteStack(state.route);
    const initialHistoryScroll = readHistoryScrollState();
    const initialStoredScroll = readStoredRouteScroll(routeKey(state.route));
    const initialScrollOffset = initialHistoryScroll ?? initialStoredScroll;
    if (
      shouldRestoreInitialRouteScroll()
      && typeof initialScrollOffset === 'number'
      && initialScrollOffset > 0
    ) {
      state.pendingScrollMode = 'restore';
      state.pendingScrollRestoreKey = routeKey(state.route);
      state.pendingScrollRestoreOffset = initialScrollOffset;
    }
    initAccountsStore();
    const unsubscribePersonalRoots = subscribePersonalEventIndexRootChanges((pubkey, nextRoot) => {
      const activePubkey = getCurrentActiveAccountPubkey(
        accountsStore.getState().activeAccountPubkey ?? null,
        accountsStore.getState().accounts,
      );
      if (pubkey === activePubkey) {
        state.viewerPersonalRoot = nextRoot;
      }
      if (state.route.kind === 'profile' && state.route.pubkey === pubkey) {
        state.profilePersonalRoot = nextRoot;
      }
      const currentRouteNeedsRoot = state.route.kind === 'profile'
        ? state.route.pubkey === pubkey
        : (
            (state.route.kind === 'home' && state.route.tab !== 'for-you')
            || state.route.kind === 'notifications'
          ) && pubkey === activePubkey;
      if (nextRoot && currentRouteNeedsRoot && state.personalRootRefreshTimer === null) {
        state.personalRootRefreshTimer = window.setTimeout(() => {
          state.personalRootRefreshTimer = null;
          deps.restartCurrentViewLoad();
        }, 50);
      }
    });
    const unsubscribePendingEvents = subscribePendingPersonalEventChanges((pubkey) => {
      const account = accountsStore.getState().accounts.find((candidate) => candidate.pubkey === pubkey);
      if (account && canSignAccount(account)) {
        void resumePersonalEventIndexes([account]);
      }
    });
    void resumePersonalEventIndexes(
      accountsStore.getState().accounts,
      socialDataPlane.query({ includeDeletionEvents: true }),
    );
    warmSocialGraphFrontier();
    deps.pruneTombstonedLocalPosts();
    const storedLocalPosts = flattenLocalPostsByAuthor(state.localPostsByAuthor);
    const restoredOverlayNotes = socialDataPlane.query({ kinds: PROFILE_CONTENT_KINDS });
    deps.cacheKnownNotes(storedLocalPosts, restoredOverlayNotes);
    deps.seedEmptyEngagements(
      [...storedLocalPosts, ...restoredOverlayNotes].map(getNoteEngagementTargetId),
    );
    void waitForNextBrowserPaint().then(async () => {
      const signal = persistedCacheHydrationController.signal;
      const [restoredLocalPosts, restoredMetadata] = await Promise.all([
        readLocalPostsFromStorageAsync(undefined, { signal }),
        initialProfilePubkey
          ? socialDataPlane.readPersistedMetadataAsync([initialProfilePubkey], signal)
          : Promise.resolve([]),
      ]);
      if (disposed || signal.aborted) {
        return;
      }

      // Posts composed while restoration was in flight stay authoritative.
      // Merging at commit time also deduplicates the persisted copy by id.
      state.localPostsByAuthor = mergeLocalPostsByAuthor(
        state.localPostsByAuthor,
        restoredLocalPosts,
      );
      deps.pruneTombstonedLocalPosts();
      const localPosts = flattenLocalPostsByAuthor(state.localPostsByAuthor);
      deps.cacheKnownNotes(localPosts);
      deps.seedEmptyEngagements(localPosts.map(getNoteEngagementTargetId));

      if (restoredMetadata.length > 0) {
        const restoredProfiles = profileMapFromMetadataEvents(restoredMetadata);
        state.liveProfiles = mergeProfileMaps(state.liveProfiles, restoredProfiles);
        rememberProfileRecords(restoredProfiles.values());
      }
    }).catch((error) => {
      if (!persistedCacheHydrationController.signal.aborted) {
        console.warn('Saved local social data could not be restored', error);
      }
    }).finally(() => {
      pendingInitialProfileMetadata.set(null);
    });
    state.notificationsSeenAt = deps.readNotificationsSeenAt();
    deps.initializeFeedSources();
    deps.restoreHomeFeedSnapshot();
    const unsubscribeSocialDataPlane = socialDataPlane.subscribe(deps.scheduleLiveViewRefresh);
    const previousScrollRestoration = window.history.scrollRestoration;
    window.history.scrollRestoration = 'manual';
    const override = deps.consumeViewerOverride();
    state.appHistoryIndex = readAppHistoryIndex(window.history.state) ?? 0;
    if (readAppHistoryIndex(window.history.state) === null) {
      window.history.replaceState(appHistoryState(state.appHistoryIndex), '');
    }
    const onPopState = (event: PopStateEvent) => {
      const presentedKey = getActiveAppRouteElement()?.dataset.routeKey ?? routeKey(state.route);
      deps.persistCurrentRouteScroll(presentedKey, getAppScrollOffset(), false);
      state.appHistoryIndex = readAppHistoryIndex(event.state) ?? 0;
      deps.handleRouteLocationChange({ fromPopState: true });
    };
    const onScroll = (event: Event) => {
      if (isActiveAppScrollEvent(event)) {
        deps.scheduleCurrentRouteScrollPersistence();
      }
    };
    const onScrollIntent = (event: Event) => {
      const target = event.target;
      const scrollElement = getActiveAppScrollElement();
      if (
        !scrollElement
        || !(target instanceof Node)
        || !scrollElement.contains(target)
      ) {
        return;
      }
      if (
        event instanceof KeyboardEvent
        && (
          !APP_SCROLL_KEYS.has(event.key)
          || event.metaKey
          || event.ctrlKey
          || event.altKey
        )
      ) {
        return;
      }
      markAppScrollInteraction();
    };
    const onPageHide = () => {
      deps.homeFeedSeenBatcher.flush();
      deps.persistCurrentRouteScrollIfNeeded();
    };
    window.addEventListener('popstate', onPopState);
    document.addEventListener('scroll', onScroll, { capture: true, passive: true });
    document.addEventListener('wheel', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('touchstart', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('pointerdown', onScrollIntent, { capture: true, passive: true });
    document.addEventListener('keydown', onScrollIntent, true);
    window.addEventListener('pagehide', onPageHide);
    document.addEventListener('click', deps.handleDocumentNavigationClick);
    // A retained graph can populate a profile while the content index is offline.
    if (state.route.kind === 'profile') {
      deps.restartCurrentViewLoad();
    }
    void (async () => {
      if (override) {
        deps.applyViewerOverride(override);
        await tick();
      }
      if (disposed) {
        return;
      }
      try {
        const stopWatching = await startAppDataSources({
          startLive: () => socialDataPlane.start(),
          onLiveError: (error) => console.warn('Live Nostr data plane is unavailable', error),
          watchDurableRoot: () => watchConfiguredEventIndexRoot(async (nextRoot) => {
            if (disposed) {
              return;
            }
            if (!nextRoot) {
              if (!state.root) {
                state.rootNhash = '';
                state.rootError = getRootUnavailableError(state, "Couldn't load the feed right now.");
                state.accountProfiles = new Map();
                state.optimisticNoteEngagements = new Map();
                if (state.route.kind !== 'profile' && !state.feed?.notes.length && state.homeNotes.length === 0) {
                  deps.clearRootBoundState();
                }
                state.loading = false;
              }
              return;
            }
            const changed = deps.applyCachedRoot(nextRoot);
            if (changed) {
              deps.resetLiveHomeFeedBuffer();
            }
            const shouldRefresh = changed || (
              state.route.kind === 'home'
                ? !state.feed || state.feed.notes.length === 0
                : !state.profilePage
            );
            if (shouldRefresh) {
              deps.restartCurrentViewLoad();
            }
          }),
        });
        if (disposed) {
          await stopWatching();
        } else {
          state.stopRootWatch = stopWatching;
        }
      } catch (error) {
        if (!disposed && !state.root) {
          state.rootNhash = '';
          state.rootError = getRootUnavailableError(
            state,
            deps.reportError("Couldn't load the feed right now.", error),
          );
          state.accountProfiles = new Map();
          state.optimisticNoteEngagements = new Map();
          if (state.route.kind !== 'profile' && !state.feed?.notes.length && state.homeNotes.length === 0) {
            deps.clearRootBoundState();
          }
          state.loading = false;
        }
      }
    })();
    return () => {
      disposed = true;
      persistedCacheHydrationController.abort();
      if (state.personalRootRefreshTimer !== null) {
        window.clearTimeout(state.personalRootRefreshTimer);
      }
      window.removeEventListener('popstate', onPopState);
      document.removeEventListener('scroll', onScroll, true);
      document.removeEventListener('wheel', onScrollIntent, true);
      document.removeEventListener('touchstart', onScrollIntent, true);
      document.removeEventListener('pointerdown', onScrollIntent, true);
      document.removeEventListener('keydown', onScrollIntent, true);
      window.removeEventListener('pagehide', onPageHide);
      document.removeEventListener('click', deps.handleDocumentNavigationClick);
      if (state.routeScrollPersistTimer !== null) {
        window.clearTimeout(state.routeScrollPersistTimer);
      }
      window.history.scrollRestoration = previousScrollRestoration;
      deps.profileSearchDebounce.cancel();
      unsubscribeSocialDataPlane();
      unsubscribePersonalRoots();
      unsubscribePendingEvents();
      disposeSharedProfileResolver();
      stopProfileRefresh();
      socialDataPlane.stop();
      state.cancelShadowReadIdleDrain?.();
      deps.pendingShadowReadObservations.clear();
      void state.shadowReadComparatorPromise?.then((comparator) => comparator.stop()).catch(() => undefined);
      if (state.liveViewRefreshTimer !== null) {
        window.clearTimeout(state.liveViewRefreshTimer);
      }
      if (state.homeFeedSnapshotWriteTimer !== null) {
        window.clearTimeout(state.homeFeedSnapshotWriteTimer);
      }
      state.homeFeedSnapshotWriteController?.abort();
      deps.pendingLiveViewEvents.clear();
      state.pendingOverlayRestore = false;
      deps.visibleNoteHydrationScheduler.dispose();
      deps.homeFeedSeenBatcher.destroy();
      void state.stopRootWatch?.();
    };
  });
}
