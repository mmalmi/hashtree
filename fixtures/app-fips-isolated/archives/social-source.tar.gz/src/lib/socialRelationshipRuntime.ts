import { HashTree, nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
  getConfiguredSocialRelationshipIndexRef,
} from './config';
import {
  openSocialRelationshipCatalog,
  type SocialRelationshipCatalogLookup,
} from './socialRelationshipCatalogReader';
import { resolveTreeTargetRoot } from './treeRef';
import { createWorkerBlockStore } from './workerBlockStore';

const RELATIONSHIP_ROOT_TTL_MS = 30_000;
const RELATIONSHIP_ROOT_RETRY_DELAYS_MS = [120, 360, 900];
const RELATIONSHIP_PAGE_SIZE = 500;
const MAX_PROFILE_FOLLOWS = 10_000;

export type IndexedProfileRelationships = {
  follows: string[];
  followsCount: number;
  followers: string[];
  followersCount: number;
};

export type SocialRelationshipRuntimeOptions = {
  store: Store;
  resolveRoot: (ref: string) => Promise<CID | null>;
  rootTtlMs?: number;
};

type CachedRoot = { root: CID; expiresAt: number };
type CachedCatalog = {
  catalog: SocialRelationshipCatalogLookup;
  catalogRoot: string;
  sourceRoot: string;
};

/**
 * Opens the signed relationship pointer lazily, then serves bounded routed
 * lookups from its hash-authenticated public catalog. The catalog is accepted
 * only when it was built from the exact broad-archive root used by the view.
 */
export class SocialRelationshipRuntime {
  private readonly rootTtlMs: number;
  private readonly roots = new Map<string, CachedRoot>();
  private readonly pendingRoots = new Map<string, Promise<CID | null>>();
  private readonly catalogs = new Map<string, CachedCatalog>();
  private readonly pendingCatalogs = new Map<string, Promise<SocialRelationshipCatalogLookup>>();

  constructor(private readonly options: SocialRelationshipRuntimeOptions) {
    const rootTtlMs = options.rootTtlMs ?? RELATIONSHIP_ROOT_TTL_MS;
    if (!Number.isSafeInteger(rootTtlMs) || rootTtlMs < 0 || rootTtlMs > 3_600_000) {
      throw new Error('Invalid social relationship root TTL');
    }
    this.rootTtlMs = rootTtlMs;
  }

  async loadProfile(
    ref: string,
    sourceRoot: CID,
    pubkey: string,
    options: {
      followerLimit: number;
      followLimit?: number;
      includeFollows?: boolean;
      includeFollowers?: boolean;
    },
  ): Promise<IndexedProfileRelationships | null> {
    const catalog = await this.open(ref, sourceRoot);
    if (!catalog) {return null;}
    const followerLimit = boundedLimit(options.followerLimit, 1, RELATIONSHIP_PAGE_SIZE);
    const followLimit = boundedLimit(
      options.followLimit ?? MAX_PROFILE_FOLLOWS,
      1,
      MAX_PROFILE_FOLLOWS,
    );
    const [follows, followers, counts] = await Promise.all([
      options.includeFollows === false
        ? Promise.resolve([])
        : readFollowing(catalog, pubkey, followLimit),
      options.includeFollowers === false
        ? Promise.resolve([])
        : catalog.getFollowers(pubkey, { limit: followerLimit }).then((page) => page.items),
      catalog.getCounts(pubkey),
    ]);
    return {
      follows,
      followsCount: counts.follows,
      followers,
      followersCount: counts.followers,
    };
  }

  private async open(
    ref: string,
    sourceRoot: CID,
  ): Promise<SocialRelationshipCatalogLookup | null> {
    const root = await this.resolve(ref);
    if (!root) {return null;}
    const catalogRoot = nhashEncode(root);
    const sourceRootId = nhashEncode({ hash: sourceRoot.hash });
    const cached = this.catalogs.get(ref);
    if (cached?.catalogRoot === catalogRoot && cached.sourceRoot === sourceRootId) {
      return cached.catalog;
    }
    const pendingKey = `${ref}\0${catalogRoot}\0${sourceRootId}`;
    const pending = this.pendingCatalogs.get(pendingKey);
    if (pending) {return await pending;}
    const created = openSocialRelationshipCatalog(this.options.store, root, {
      expectedSourceRoot: sourceRoot,
    });
    this.pendingCatalogs.set(pendingKey, created);
    void created.then((catalog) => {
      this.catalogs.set(ref, { catalog, catalogRoot, sourceRoot: sourceRootId });
    }).finally(() => {
      if (this.pendingCatalogs.get(pendingKey) === created) {
        this.pendingCatalogs.delete(pendingKey);
      }
    }).catch(() => undefined);
    return await created;
  }

  private async resolve(ref: string): Promise<CID | null> {
    const cached = this.roots.get(ref);
    if (cached && cached.expiresAt > Date.now()) {return cached.root;}
    const pending = this.pendingRoots.get(ref);
    if (pending) {return await pending;}
    const created = this.options.resolveRoot(ref);
    this.pendingRoots.set(ref, created);
    void created.then((root) => {
      if (root) {
        this.roots.set(ref, { root, expiresAt: Date.now() + this.rootTtlMs });
      }
    }).finally(() => {
      if (this.pendingRoots.get(ref) === created) {this.pendingRoots.delete(ref);}
    }).catch(() => undefined);
    return await created;
  }
}

const workerStore = createWorkerBlockStore();
const workerTree = new HashTree({ store: workerStore });
const browserRuntime = new SocialRelationshipRuntime({
  store: workerStore,
  resolveRoot: async (ref) => await resolveTreeTargetRoot(ref, {
    resolveImmutablePath: async (root, path) =>
      (await workerTree.resolvePath(root, path))?.cid ?? null,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
    retryDelaysMs: RELATIONSHIP_ROOT_RETRY_DELAYS_MS,
  }),
});

export async function loadIndexedProfileRelationships(
  sourceRoot: CID,
  pubkey: string,
  options: {
    followerLimit: number;
    followLimit?: number;
    includeFollows?: boolean;
    includeFollowers?: boolean;
  },
): Promise<IndexedProfileRelationships | null> {
  const ref = getConfiguredSocialRelationshipIndexRef();
  return ref ? await browserRuntime.loadProfile(ref, sourceRoot, pubkey, options) : null;
}

export async function warmSocialRelationshipIndex(sourceRoot: CID): Promise<void> {
  const ref = getConfiguredSocialRelationshipIndexRef();
  if (!ref) {return;}
  await browserRuntime.loadProfile(ref, sourceRoot, '0'.repeat(64), {
    followerLimit: 1,
    includeFollows: false,
    includeFollowers: false,
  });
}

async function readFollowing(
  catalog: SocialRelationshipCatalogLookup,
  pubkey: string,
  limit: number,
): Promise<string[]> {
  const items: string[] = [];
  let cursor: string | null = null;
  while (items.length < limit) {
    const page = await catalog.getFollows(pubkey, {
      cursor,
      limit: Math.min(RELATIONSHIP_PAGE_SIZE, limit - items.length),
    });
    items.push(...page.items);
    if (!page.nextCursor || page.nextCursor === cursor) {break;}
    cursor = page.nextCursor;
  }
  return items;
}

function boundedLimit(value: number, minimum: number, maximum: number): number {
  if (!Number.isSafeInteger(value)) {return minimum;}
  return Math.min(Math.max(value, minimum), maximum);
}
