export const FEED_VIEWS = ['feed', 'media-grid'] as const;

export type FeedView = typeof FEED_VIEWS[number];

export const DEFAULT_FEED_VIEW: FeedView = 'feed';

export function normalizeFeedView(value: unknown): FeedView {
  return FEED_VIEWS.includes(value as FeedView) ? value as FeedView : DEFAULT_FEED_VIEW;
}
