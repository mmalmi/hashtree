import { tick } from 'svelte';
import type { SocialAccount } from './accounts';
import {
  isPrimaryNavigationItemActive,
  persistHistoryScroll,
  persistRouteScroll,
  readStoredRouteScroll,
  type PrimaryNavigationItem,
} from './appNavigation';
import type { Route } from './appRoute';
import { parseRouteLocation, routeKey } from './appRoute';
import {
  getActiveAppScrollElement,
  getActiveAppRouteElement,
  getAppContentViewportBounds,
  getAppScrollInteractionVersion,
  getAppScrollOffset,
  scrollAppTo,
} from './appScroll';
import {
  PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE,
  reachableScrollOffset,
  restoreScrollProgressively,
  type ProgressiveScrollRestore,
} from './progressiveScrollRestore';

const ACTIVE_NAVIGATION_TOP_THRESHOLD_PX = 50;
const HOME_FEED_ANCHOR_RESTORE_WINDOW_MS = 3_000;
const ROUTE_SCROLL_PERSIST_DELAY_MS = 120;
const WARM_ROUTE_SCROLL_ANCHOR_HOLD_MS = 600;

export type PendingHomeFeedAnchorRestore = {
  routeKey: string;
  anchor: { noteId: string; top: number };
  expiresAt: number;
  interactionVersion: number;
};

export function findFirstTopInViewport(
  itemCount: number,
  readTop: (index: number) => number,
  viewportTop: number,
  viewportBottom: number,
): { index: number; top: number } | null {
  let low = 0;
  let high = itemCount;
  while (low < high) {
    const middle = low + Math.floor((high - low) / 2);
    if (readTop(middle) < viewportTop) {
      low = middle + 1;
    } else {
      high = middle;
    }
  }
  if (low >= itemCount) {
    return null;
  }
  const top = readTop(low);
  return top >= viewportTop && top < viewportBottom ? { index: low, top } : null;
}

export function shouldRestoreRouteScrollProgressively(offset: number): boolean {
  return offset > 1;
}

type AppScrollControllerDeps = {
  activeAccount: SocialAccount | null;
  pendingHomeFeedAnchorRestore: PendingHomeFeedAnchorRestore | null;
  pendingScrollMode: 'top' | 'restore' | null;
  pendingScrollRestoreKey: string | null;
  pendingScrollRestoreOffset: number | null;
  route: Route;
  routeScrollPersistTimer: number | null;
  routeScrollPositions: Map<string, number>;
  appHistoryIndex: number;
  historyScrollPositions: Map<number, number>;
  handleRefreshHome: () => Promise<void>;
};

export function createAppScrollController(deps: AppScrollControllerDeps) {
  let homeAnchorRestoreAttemptQueued = false;
  let homeAnchorRestoreExpiryTimer: number | null = null;
  let homeAnchorResizeObserver: ResizeObserver | null = null;
  let homeAnchorObservedFeed: HTMLElement | null = null;
  let profileAnchorRestoreVersion = 0;
  let progressiveRestore: ProgressiveScrollRestore | null = null;
  let restoreVersion = 0;
  let warmAnchorHold: {
    element: HTMLElement;
    marker: string;
    timer: number;
  } | null = null;

  function presentedRouteKey(): string {
    return typeof window === 'undefined'
      ? routeKey(deps.route)
      : routeKey(parseRouteLocation(window.location.pathname, window.location.hash));
  }

  function cancelPendingRouteScrollRestores(): void {
    restoreVersion += 1;
    clearPendingHomeFeedAnchorRestore();
    if (warmAnchorHold) {
      window.clearTimeout(warmAnchorHold.timer);
      if (
        warmAnchorHold.element.getAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE)
        === warmAnchorHold.marker
      ) {
        warmAnchorHold.element.removeAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE);
      }
      warmAnchorHold = null;
    }
    progressiveRestore?.cancel();
    progressiveRestore = null;
  }

  function clearPendingHomeFeedAnchorRestore(
    expected: PendingHomeFeedAnchorRestore | null = null,
  ): void {
    if (
      expected
      && deps.pendingHomeFeedAnchorRestore !== expected
    ) {
      return;
    }
    deps.pendingHomeFeedAnchorRestore = null;
    homeAnchorResizeObserver?.disconnect();
    homeAnchorResizeObserver = null;
    homeAnchorObservedFeed = null;
    if (homeAnchorRestoreExpiryTimer !== null) {
      window.clearTimeout(homeAnchorRestoreExpiryTimer);
      homeAnchorRestoreExpiryTimer = null;
    }
  }

  function observePendingHomeFeedAnchor(
    pendingRestore: PendingHomeFeedAnchorRestore,
    feedElement: HTMLElement,
  ): void {
    if (
      typeof ResizeObserver !== 'undefined'
      && homeAnchorObservedFeed !== feedElement
    ) {
      homeAnchorResizeObserver?.disconnect();
      homeAnchorResizeObserver = new ResizeObserver(() => {
        queueVisibleHomeAnchorRestore();
      });
      homeAnchorResizeObserver.observe(feedElement);
      homeAnchorObservedFeed = feedElement;
    }
    if (homeAnchorRestoreExpiryTimer === null) {
      homeAnchorRestoreExpiryTimer = window.setTimeout(() => {
        homeAnchorRestoreExpiryTimer = null;
        clearPendingHomeFeedAnchorRestore(pendingRestore);
      }, Math.max(0, pendingRestore.expiresAt - Date.now()));
    }
  }

  function holdWarmRouteScrollAnchor(element: HTMLElement, targetOffset: number): void {
    const marker = `warm:${restoreVersion}:${targetOffset}`;
    element.setAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE, marker);
    const timer = window.setTimeout(() => {
      if (element.getAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE) === marker) {
        element.removeAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE);
      }
      if (warmAnchorHold?.marker === marker) {
        warmAnchorHold = null;
      }
    }, WARM_ROUTE_SCROLL_ANCHOR_HOLD_MS);
    warmAnchorHold = { element, marker, timer };
  }

  function persistCurrentRouteScroll(
    key = presentedRouteKey(),
    scrollY = getAppScrollOffset(),
    updateHistory = true,
  ): void {
    if (deps.routeScrollPersistTimer !== null) {
      window.clearTimeout(deps.routeScrollPersistTimer);
      deps.routeScrollPersistTimer = null;
    }
    if (updateHistory) {
      persistHistoryScroll(scrollY);
    }
    persistRouteScroll(key, scrollY);
    deps.routeScrollPositions.set(key, scrollY);
    deps.historyScrollPositions.set(deps.appHistoryIndex, scrollY);
  }

  function persistCurrentRouteScrollIfNeeded(): void {
    persistCurrentRouteScroll();
  }

  function scheduleCurrentRouteScrollPersistence(): void {
    // Once the presented surface has moved, it is interactive and owns its
    // scroll position. A late cache-projection restore must never snap a user
    // back after they have already scrolled. Browser scroll anchoring and
    // programmatic route restoration also emit scroll events, so explicit
    // input—not this event—is what advances the interaction version.
    if (deps.pendingScrollMode) {
      cancelPendingRouteScrollRestores();
      deps.pendingScrollMode = null;
      deps.pendingScrollRestoreKey = null;
      deps.pendingScrollRestoreOffset = null;
    }
    if (deps.routeScrollPersistTimer !== null) {
      window.clearTimeout(deps.routeScrollPersistTimer);
    }
    const scheduledRouteKey = presentedRouteKey();
    const scheduledHistoryIndex = deps.appHistoryIndex;
    deps.routeScrollPersistTimer = window.setTimeout(() => {
      deps.routeScrollPersistTimer = null;
      if (
        presentedRouteKey() === scheduledRouteKey
        && deps.appHistoryIndex === scheduledHistoryIndex
      ) {
        persistCurrentRouteScroll(scheduledRouteKey);
      }
    }, ROUTE_SCROLL_PERSIST_DELAY_MS);
  }

  function restorePresentedRouteScroll(key: string, targetOffset: number): void {
    cancelPendingRouteScrollRestores();
    const pendingRestoreVersion = restoreVersion;
    const scrollElement = getActiveAppScrollElement();
    const routeElement = getActiveAppRouteElement();
    if (
      !scrollElement
      || routeElement?.dataset.routeKey !== key
      || presentedRouteKey() !== key
    ) {
      return;
    }
    const reachableTarget = reachableScrollOffset(
      targetOffset,
      scrollElement.scrollHeight,
      scrollElement.clientHeight,
    );
    if (Math.abs(reachableTarget - targetOffset) <= 1) {
      holdWarmRouteScrollAnchor(scrollElement, targetOffset);
      scrollElement.scrollTo(0, targetOffset);
      persistCurrentRouteScroll(key, scrollElement.scrollTop);
      return;
    }
    const pendingInteractionVersion = getAppScrollInteractionVersion();
    const restore = restoreScrollProgressively({
      element: scrollElement,
      targetOffset,
      shouldContinue: () => (
        restoreVersion === pendingRestoreVersion
        && getAppScrollInteractionVersion() === pendingInteractionVersion
        && presentedRouteKey() === key
        && getActiveAppScrollElement() === scrollElement
        && getActiveAppRouteElement() === routeElement
        && routeElement.dataset.routeKey === key
      ),
      onSettled: (finalOffset) => {
        persistCurrentRouteScroll(key, finalOffset);
      },
    });
    progressiveRestore = restore.active ? restore : null;
  }

  function scrollPageToTopInstant(): void {
    if (!getActiveAppScrollElement()) {
      return;
    }
    cancelPendingRouteScrollRestores();
    deps.pendingHomeFeedAnchorRestore = null;
    scrollAppTo(0);
    persistCurrentRouteScroll(presentedRouteKey(), 0);
  }

  function applyPendingRouteScroll(): void {
    const mode = deps.pendingScrollMode;
    const restoreKey = mode === 'restore'
      ? deps.pendingScrollRestoreKey
      : routeKey(deps.route);
    if (!mode || !restoreKey || routeKey(deps.route) !== restoreKey) {
      return;
    }
    cancelPendingRouteScrollRestores();
    const pendingRestoreVersion = restoreVersion;
    const pendingInteractionVersion = getAppScrollInteractionVersion();
    const nextOffset = mode === 'top'
      ? 0
      : deps.pendingScrollRestoreOffset
        ?? readStoredRouteScroll(restoreKey)
        ?? deps.routeScrollPositions.get(restoreKey)
        ?? 0;
    void tick().then(() => {
      const scrollElement = getActiveAppScrollElement();
      const routeElement = getActiveAppRouteElement();
      if (
        restoreVersion !== pendingRestoreVersion
        || getAppScrollInteractionVersion() !== pendingInteractionVersion
        || routeKey(deps.route) !== restoreKey
        || !scrollElement
        || routeElement?.dataset.routeKey !== restoreKey
      ) {
        return;
      }
      if (mode === 'restore' && scrollElement.scrollTop > 1) {
        deps.pendingScrollMode = null;
        deps.pendingScrollRestoreKey = null;
        deps.pendingScrollRestoreOffset = null;
        persistCurrentRouteScroll(restoreKey, scrollElement.scrollTop);
        return;
      }
      if (mode === 'restore' && shouldRestoreRouteScrollProgressively(nextOffset)) {
        const restore = restoreScrollProgressively({
          element: scrollElement,
          targetOffset: nextOffset,
          shouldContinue: () => (
            restoreVersion === pendingRestoreVersion
            && getAppScrollInteractionVersion() === pendingInteractionVersion
            && routeKey(deps.route) === restoreKey
            && getActiveAppScrollElement() === scrollElement
            && getActiveAppRouteElement() === routeElement
            && routeElement.dataset.routeKey === restoreKey
          ),
          onSettled: (finalOffset) => {
            persistCurrentRouteScroll(restoreKey, finalOffset);
          },
        });
        progressiveRestore = restore.active ? restore : null;
      } else {
        if (scrollElement.scrollTop !== nextOffset) {
          scrollElement.scrollTop = nextOffset;
        }
        persistCurrentRouteScroll(restoreKey, nextOffset);
      }
      deps.pendingScrollMode = null;
      deps.pendingScrollRestoreKey = null;
      deps.pendingScrollRestoreOffset = null;
    });
  }

  function captureVisibleHomeFeedAnchor(): { noteId: string; top: number } | null {
    // Repeated projections must keep the same card rendered that the pending
    // scroll restoration will use, even before the preceding DOM update paints.
    const pending = deps.pendingHomeFeedAnchorRestore;
    if (deps.route.kind === 'home' && pending
      && pending.routeKey === routeKey(deps.route)
      && pending.expiresAt > Date.now()
      && pending.interactionVersion === getAppScrollInteractionVersion()) {
      return pending.anchor;
    }
    const scrollElement = getActiveAppScrollElement();
    const routeElement = getActiveAppRouteElement();
    if (deps.route.kind !== 'home' || !scrollElement || !routeElement
      || scrollElement.scrollTop <= ACTIVE_NAVIGATION_TOP_THRESHOLD_PX) {
      return null;
    }
    const cards = routeElement.querySelectorAll<HTMLElement>(
      '[data-testid="latest-feed"] > [data-testid="note-card"][data-note-id]',
    );
    const viewport = getAppContentViewportBounds(scrollElement);
    if (!viewport) {
      return null;
    }
    const match = findFirstTopInViewport(
      cards.length,
      (candidateIndex) => cards[candidateIndex]!.getBoundingClientRect().top,
      viewport.top,
      viewport.bottom,
    );
    const card = match ? cards[match.index] : null;
    const noteId = card?.dataset.noteId?.trim();
    if (match && noteId) {
      return { noteId, top: match.top };
    }
    return null;
  }

  function captureVisibleProfileFeedAnchor(): { noteId: string; top: number } | null {
    const scrollElement = getActiveAppScrollElement();
    const routeElement = getActiveAppRouteElement();
    if (
      deps.route.kind !== 'profile'
      || !scrollElement
      || !routeElement
      || routeElement.dataset.routeKind !== 'profile'
      || scrollElement.scrollTop <= ACTIVE_NAVIGATION_TOP_THRESHOLD_PX
    ) {
      return null;
    }
    const cards = routeElement.querySelectorAll<HTMLElement>(
      '[data-testid="profile-feed"] > [data-testid="note-card"][data-note-id]',
    );
    const viewport = getAppContentViewportBounds(scrollElement);
    if (!viewport) {
      return null;
    }
    const match = findFirstTopInViewport(
      cards.length,
      (candidateIndex) => cards[candidateIndex]!.getBoundingClientRect().top,
      viewport.top,
      viewport.bottom,
    );
    const noteId = match ? cards[match.index]?.dataset.noteId?.trim() : '';
    return match && noteId ? { noteId, top: match.top } : null;
  }

  function queueVisibleHomeAnchorRestore(): void {
    const pendingRestore = deps.pendingHomeFeedAnchorRestore;
    if (!pendingRestore || homeAnchorRestoreAttemptQueued) {
      return;
    }
    homeAnchorRestoreAttemptQueued = true;
    void tick().then(() => {
      homeAnchorRestoreAttemptQueued = false;
      if (deps.pendingHomeFeedAnchorRestore !== pendingRestore) {
        // A newer projection may have replaced the request while this tick was
        // queued. Its first attempt was coalesced by the shared guard, so hand
        // control directly to that newer request now.
        queueVisibleHomeAnchorRestore();
        return;
      }
      if (
        routeKey(deps.route) !== pendingRestore.routeKey
        || pendingRestore.expiresAt <= Date.now()
        || getAppScrollInteractionVersion() !== pendingRestore.interactionVersion
      ) {
        clearPendingHomeFeedAnchorRestore(pendingRestore);
        return;
      }
      const routeElement = getActiveAppRouteElement();
      const feedElement = routeElement?.querySelector<HTMLElement>(
        '[data-testid="latest-feed"]',
      );
      if (!feedElement) {
        clearPendingHomeFeedAnchorRestore(pendingRestore);
        return;
      }
      observePendingHomeFeedAnchor(pendingRestore, feedElement);
      const card = feedElement.querySelector<HTMLElement>(
        `:scope > [data-testid="note-card"]`
          + `[data-note-id="${CSS.escape(pendingRestore.anchor.noteId)}"]`,
      );
      if (!(card instanceof HTMLElement)) {
        // A streamed projection can remove the anchor for one commit and put
        // it back in the next. Leave the restore pending; that next projection
        // schedules one fresh attempt. Do not poll the DOM every animation
        // frame while no matching card exists.
        return;
      }
      const delta = card.getBoundingClientRect().top - pendingRestore.anchor.top;
      if (Math.abs(delta) > 1) {
        const nextOffset = Math.max(0, getAppScrollOffset() + delta);
        scrollAppTo(nextOffset);
        persistCurrentRouteScroll(pendingRestore.routeKey, nextOffset);
      }
    });
  }

  function scheduleVisibleHomeAnchorRestore(
    expectedRouteKey: string,
    capturedAnchor: { noteId: string; top: number } | null,
  ): void {
    const now = Date.now();
    const interactionVersion = getAppScrollInteractionVersion();
    const pendingRestoreIsCompatible = deps.pendingHomeFeedAnchorRestore
      && deps.pendingHomeFeedAnchorRestore.routeKey === expectedRouteKey
      && deps.pendingHomeFeedAnchorRestore.expiresAt > now
      && deps.pendingHomeFeedAnchorRestore.interactionVersion === interactionVersion;
    if (!pendingRestoreIsCompatible) {
      clearPendingHomeFeedAnchorRestore();
      deps.pendingHomeFeedAnchorRestore = capturedAnchor
        ? {
            routeKey: expectedRouteKey,
            anchor: capturedAnchor,
            expiresAt: now + HOME_FEED_ANCHOR_RESTORE_WINDOW_MS,
            interactionVersion,
          }
        : null;
    }
    queueVisibleHomeAnchorRestore();
  }

  function scheduleVisibleProfileAnchorRestore(
    expectedRouteKey: string,
    anchor: { noteId: string; top: number } | null,
  ): void {
    const version = ++profileAnchorRestoreVersion;
    if (!anchor) {
      return;
    }
    void tick().then(() => {
      const scrollElement = getActiveAppScrollElement();
      const routeElement = getActiveAppRouteElement();
      if (
        version !== profileAnchorRestoreVersion
        || routeKey(deps.route) !== expectedRouteKey
        || routeElement?.dataset.routeKey !== expectedRouteKey
        || !scrollElement
      ) {
        return;
      }
      const card = routeElement.querySelector<HTMLElement>(
        `[data-testid="profile-feed"] > [data-testid="note-card"]`
          + `[data-note-id="${CSS.escape(anchor.noteId)}"]`,
      );
      if (!card) {
        return;
      }
      const delta = card.getBoundingClientRect().top - anchor.top;
      if (Math.abs(delta) <= 1) {
        return;
      }
      const nextOffset = Math.max(0, scrollElement.scrollTop + delta);
      scrollElement.scrollTop = nextOffset;
      persistCurrentRouteScroll(expectedRouteKey, nextOffset);
    });
  }

  function handleActivePrimaryNavigation(item: PrimaryNavigationItem): boolean {
    const presentedRoute = typeof window === 'undefined'
      ? deps.route
      : parseRouteLocation(window.location.pathname, window.location.hash);
    if (!isPrimaryNavigationItemActive(
      item,
      presentedRoute,
      deps.activeAccount?.pubkey ?? null,
    )) {
      return false;
    }
    if (item === 'home' && getAppScrollOffset() < ACTIVE_NAVIGATION_TOP_THRESHOLD_PX) {
      void deps.handleRefreshHome();
    } else {
      scrollPageToTopInstant();
    }
    return true;
  }

  return {
    applyPendingRouteScroll,
    cancelPendingRouteScrollRestores,
    captureVisibleHomeFeedAnchor,
    captureVisibleProfileFeedAnchor,
    handleActivePrimaryNavigation,
    persistCurrentRouteScroll,
    persistCurrentRouteScrollIfNeeded,
    restorePresentedRouteScroll,
    scheduleCurrentRouteScrollPersistence,
    scheduleVisibleHomeAnchorRestore,
    scheduleVisibleProfileAnchorRestore,
    scrollPageToTopInstant,
  };
}
