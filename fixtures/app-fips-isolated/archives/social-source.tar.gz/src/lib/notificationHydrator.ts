import type { CID } from '@hashtree/core';
import {
  createNotificationItem,
  getNotificationTargetReference,
  mergeNotificationItems,
  type NotificationDataPage,
  type NotificationReadOptions,
  type NotificationItem,
} from './appDetailLoaders';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  canReadNotificationsFromRelays,
  NOTIFICATION_TARGET_BATCH_LIMIT,
  readNotificationRelayPage,
  readNotificationRelayTargets,
  type NotificationRelayPage,
} from './notificationRelayReads';
import {
  DISABLED_NOTIFICATION_SOURCE,
  notificationSourceBoundary,
  PENDING_NOTIFICATION_SOURCE,
  projectNotificationSources,
  type NotificationSourcePage,
} from './notificationSources';
import { mergeProfileMaps } from './profileRecords';
import {
  isStrictlyBeforeRecentCursor,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';

export type NotificationHydratorDeps = {
  getLoadToken: () => number;
  getViewerPersonalRoot: () => CID | null;
  getAccountProfiles: () => Map<string, ProfileRecord>;
  getNotifications: () => NotificationItem[];
  isNotificationsRoute: () => boolean;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  saveNotificationsSeenAt: (nextSeenAt: number) => void;
  setViewerContactsEvent: (event: RawEvent | null) => void;
  setViewerFollows: (follows: Set<string>) => void;
  setNotificationsLoading: (loading: boolean) => void;
  setNotificationsLoadPending: (loading: boolean) => void;
  setNotificationsCursor: (cursor: RecentTextNoteCursor | null) => void;
  setNotificationsHasMore: (hasMore: boolean) => void;
  setNotifications: (items: NotificationItem[]) => void;
  setNotificationsProfiles: (profiles: Map<string, ProfileRecord>) => void;
};

type KnownEventLookup = (eventId: string) => RawEvent | null;

export type NotificationArchiveLoader = (
  currentRoot: CID,
  viewerPersonalRoot: CID | null,
  viewerPubkey: string,
  accountProfiles: Map<string, ProfileRecord>,
  options: NotificationReadOptions,
) => Promise<NotificationDataPage>;

export type NotificationHydratorOptions = {
  loadArchivePage: NotificationArchiveLoader;
  loadRelayPage?: typeof readNotificationRelayPage;
  loadRelayTargets?: typeof readNotificationRelayTargets;
  relayEnabled?: () => boolean;
  /** Locally known posts (own posts, the live overlay) skip a relay target read. */
  getKnownEventLookup?: () => Promise<KnownEventLookup>;
};

type NotificationSession = {
  viewer: string;
  items: NotificationItem[];
  profiles: Map<string, ProfileRecord>;
  archive: NotificationSourcePage;
  relay: NotificationSourcePage;
  archiveTask: Promise<void> | null;
  relayTask: Promise<void> | null;
  viewerStateLoaded: boolean;
  requestedTargets: Set<string>;
  readingTargets: boolean;
  controller: AbortController;
};

async function defaultKnownEventLookup(): Promise<KnownEventLookup> {
  const { socialDataPlane } = await import('./socialDataPlane');
  return (eventId) => socialDataPlane.getEvent(eventId);
}

/**
 * Notifications read two sources at once: configured relays answer within a
 * few seconds, and the Hashtree archive adds offline history. Each source
 * keeps its own cursor; the visible list only grows downward.
 */
export function createNotificationHydrator(
  deps: NotificationHydratorDeps,
  options: NotificationHydratorOptions,
) {
  const loadRelayPage = options.loadRelayPage ?? readNotificationRelayPage;
  const loadRelayTargets = options.loadRelayTargets ?? readNotificationRelayTargets;
  const relayEnabled = options.relayEnabled ?? canReadNotificationsFromRelays;
  const knownEventLookup = options.getKnownEventLookup ?? defaultKnownEventLookup;
  let session: NotificationSession | null = null;

  function startSession(viewer: string, before?: RecentTextNoteCursor): NotificationSession {
    // Without a session (for example after a reload of the hydrator), resume
    // both sources from the visible cursor the caller kept.
    const resumed = before ? { loaded: true, cursor: before, hasMore: true } : PENDING_NOTIFICATION_SOURCE;
    return {
      viewer,
      items: before ? [...deps.getNotifications()] : [],
      profiles: new Map(),
      archive: resumed,
      relay: relayEnabled() ? resumed : DISABLED_NOTIFICATION_SOURCE,
      archiveTask: null,
      relayTask: null,
      viewerStateLoaded: Boolean(before),
      requestedTargets: new Set(),
      readingTargets: false,
      controller: new AbortController(),
    };
  }

  /**
   * A source whose cursor is older than the visible boundary already holds
   * its next events below the fold. Only the source(s) at the boundary read.
   */
  function shouldRead(current: NotificationSession, source: NotificationSourcePage): boolean {
    if (!source.hasMore) {return false;}
    if (!source.loaded || !source.cursor) {return true;}
    const boundary = notificationSourceBoundary([current.archive, current.relay]);
    return !boundary || !isStrictlyBeforeRecentCursor(
      source.cursor.createdAt,
      source.cursor.eventId,
      boundary,
    );
  }

  function publish(current: NotificationSession, token: number): boolean {
    if (session !== current || token !== deps.getLoadToken()) {return false;}
    const sources = [current.archive, current.relay];
    // Keep the previous list until a source answers, so a revisit does not flash empty.
    if (current.items.length === 0 && sources.some(source => !source.loaded)) {
      if (current.archive.loaded) {deps.setNotificationsLoading(false);}
      return false;
    }
    const page = projectNotificationSources(current.items, sources);
    deps.setNotifications(page.visible);
    if (page.visible.length || current.archive.loaded) {deps.setNotificationsLoading(false);}
    deps.setNotificationsProfiles(current.profiles);
    deps.setNotificationsCursor(page.cursor);
    deps.setNotificationsHasMore(page.hasMore);
    if (deps.isNotificationsRoute() && page.visible[0]) {
      deps.saveNotificationsSeenAt(page.visible[0].actorEvent.created_at);
    }
    return true;
  }

  function withTargets(
    current: NotificationSession,
    targets: ReadonlyMap<string, RawEvent>,
  ): NotificationItem[] {
    let changed = false;
    const items = current.items.map((item) => {
      const target = item.targetEvent ? null : targets.get(item.targetRef);
      if (!target) {return item;}
      changed = true;
      return { ...item, targetEvent: target };
    });
    return changed ? items : current.items;
  }

  async function resolveRelayTargets(current: NotificationSession, token: number): Promise<void> {
    if (current.readingTargets) {return;}
    current.readingTargets = true;
    const apply = (targets: ReadonlyMap<string, RawEvent>) => {
      if (session !== current) {return;}
      const items = withTargets(current, targets);
      if (items === current.items) {return;}
      current.items = items;
      publish(current, token);
    };
    try {
      while (session === current) {
        const missing = [...new Set(current.items.filter(item => !item.targetEvent && item.targetRef !== item.id)
          .map(item => item.targetRef))]
          .filter(id => !current.requestedTargets.has(id))
          .slice(0, NOTIFICATION_TARGET_BATCH_LIMIT);
        if (!missing.length) {return;}
        for (const id of missing) {current.requestedTargets.add(id);}
        apply(await loadRelayTargets({ ids: missing, onProgress: apply, signal: current.controller.signal }));
      }
    } finally {
      current.readingTargets = false;
    }
  }

  function loadRelay(current: NotificationSession, token: number): Promise<void> {
    if (current.relayTask) {return current.relayTask;}
    const before = current.relay.cursor;
    let ready!: () => void;
    const firstResult = new Promise<void>(resolve => { ready = resolve; });
    // A source reading its next page must not hide known rows behind its old cursor.
    current.relay = { ...current.relay, loaded: false };
    current.relayTask = (async () => {
      try {
        const known = await knownEventLookup();
        const apply = (page: NotificationRelayPage, finished = false) => {
          if (session !== current) {return;}
          const items = page.events.flatMap((event) => {
            const targetRef = getNotificationTargetReference(event);
            const item = createNotificationItem(event, current.viewer, targetRef ? known(targetRef) : null);
            return item ? [item] : [];
          });
          current.items = mergeNotificationItems(current.items, items);
          // Only a finished page establishes the next pagination position.
          if (finished) {current.relay = { loaded: true, cursor: page.cursor, hasMore: page.hasMore };}
          publish(current, token);
          if (items.length > 0) {
            ready();
            void resolveRelayTargets(current, token).catch(error => {
              if (!current.controller.signal.aborted) {console.warn('Failed to load notification targets', error);}
            });
          }
        };
        apply(await loadRelayPage({
          viewerPubkey: current.viewer, before, onProgress: apply, signal: current.controller.signal,
        }), true);
      } catch (error) {
        if (session === current) {
          console.warn('Failed to load relay notifications', error);
          current.relay = { ...current.relay, loaded: true, hasMore: false };
          publish(current, token);
        }
      } finally {
        current.relayTask = null;
        ready();
      }
    })();
    return firstResult;
  }

  function loadArchive(
    current: NotificationSession,
    currentRoot: CID,
    token: number,
    limit: number | undefined,
  ): Promise<void> {
    if (current.archiveTask) {return current.archiveTask;}
    const before = current.archive.cursor;
    const includeViewerState = !current.viewerStateLoaded;
    current.viewerStateLoaded = true;
    current.archive = { ...current.archive, loaded: false };
    let release!: () => void;
    const ready = new Promise<void>(resolve => { release = resolve; });
    current.archiveTask = ready;
    const applyPage: NonNullable<NotificationReadOptions['onPage']> = page => {
      if (session === current) {
        current.items = mergeNotificationItems(current.items, page.notifications);
        current.archive = { loaded: true, cursor: page.cursor, hasMore: page.hasMore };
        publish(current, token);
      }
      current.archiveTask = null;
      release();
    };
    void options.loadArchivePage(
      currentRoot, deps.getViewerPersonalRoot(), current.viewer, deps.getAccountProfiles(),
      { before: before ?? undefined, includeViewerState, limit, onPage: applyPage },
    ).then(data => {
      if (session !== current) {return;}
      if (includeViewerState && data.contactsEvent && token === deps.getLoadToken()) {
        deps.setViewerContactsEvent(data.contactsEvent);
        deps.setViewerFollows(data.follows);
      }
      // A late target or avatar can enrich a previous page after pagination advances.
      if (current.archiveTask === ready) {applyPage(data);}
      current.items = mergeNotificationItems(current.items, data.notifications);
      current.profiles = mergeProfileMaps(current.profiles, data.profiles);
      deps.mergeCachedProfiles(data.profiles);
      publish(current, token);
    }).catch(error => {
      console.warn('Failed to hydrate notifications', error);
      if (session === current && current.archiveTask === ready) {
        applyPage({ notifications: [], cursor: before, hasMore: false });
      }
    }).finally(release);
    return ready;
  }

  return async function hydrateNotifications(
    currentRoot: CID,
    viewerPubkey: string,
    token: number,
    hydrateOptions: {
      append?: boolean;
      before?: RecentTextNoteCursor;
      limit?: number;
    } = {},
  ): Promise<void> {
    const viewer = viewerPubkey.trim().toLowerCase();
    const append = hydrateOptions.append === true;
    if (!append || session?.viewer !== viewer) {
      session?.controller.abort();
      session = startSession(viewer, append ? hydrateOptions.before : undefined);
    }
    const current = session;
    if (append) {
      deps.setNotificationsLoadPending(true);
    } else {
      deps.setNotificationsLoading(true);
    }

    const readRelay = shouldRead(current, current.relay);
    const readArchive = shouldRead(current, current.archive);
    const tasks = [];
    if (readRelay) {tasks.push(loadRelay(current, token));}
    if (readArchive) {tasks.push(loadArchive(current, currentRoot, token, hydrateOptions.limit));}
    // Opening a boundary for an in-flight page can itself reveal rows we already hold.
    if (append) {publish(current, token);}
    if (tasks.length) {await Promise.race(tasks);}
    if (token === deps.getLoadToken() && session === current) {
      publish(current, token);
      deps.setNotificationsLoadPending(false);
    }
  };
}
