import {
  nhashDecode,
  nhashEncode,
  toHex,
  type CID,
  type Hash,
  type Store,
} from '@hashtree/core';
import { HASHTREE_ROOT_KIND } from '@hashtree/nostr';
import type { SocialAccount } from './accounts';
import { canSignAccount } from './accountSigner';
import { verifyIndexedEvent } from './fastEventVerification';
import { getConfiguredBlossomServers } from './htreeRuntime';
import type { RawEvent } from './nostr';
import { resolveLatestPublishedRootResolution } from './treeRef';
import {
  PersonalEventIndex,
  type PersonalEventIndexBlock,
  type PersonalEventIndexState,
  type PersonalEventIndexStateStore,
} from './personalEventIndex';
import { PERSONAL_EVENT_INDEX_BLOCK_STORE_NAME } from './personalEventIndexConstants';

export const PERSONAL_EVENT_INDEX_TREE_NAME = 'nostr-event-index';
const PERSONAL_STATE_DB_NAME = 'iris-social:personal-event-index';
const PERSONAL_STATE_DB_VERSION = 2;
const PERSONAL_STATE_STORE = 'heads';
const PERSONAL_PENDING_EVENT_STORE = 'pending-events';
const ROOT_RESOLVE_TIMEOUT_MS = 2_500;
const UPLOAD_BATCH_SIZE = 64;
const PERSONAL_PENDING_EVENT_CHANNEL = 'iris-social:personal-event-index-pending:v1';
const PERSONAL_ROOT_CHANGE_CHANNEL = 'iris-social:personal-event-index-root:v1';

type RootPublisher = (
  account: SocialAccount,
  root: CID,
  createdAt: number,
) => void | Promise<void>;

let personalBlockStore: PersonalBrowserBlockStore | null = null;
let personalIndex: PersonalEventIndex | null = null;
let rootPublisher: RootPublisher | null = null;
const initializedAccounts = new Set<string>();
const initializationPromises = new Map<string, Promise<CID | null>>();
const localRootNhashes = new Set<string>();
const fallbackExclusiveQueues = new Map<string, Promise<void>>();
const flushPromises = new Map<string, Promise<CID | null>>();
const rootChangeListeners = new Set<(pubkey: string, root: CID) => void>();
const pendingEventListeners = new Set<(pubkey: string) => void>();
let pendingEventChannel: BroadcastChannel | null = null;
let rootChangeChannel: BroadcastChannel | null = null;

async function getPersonalWorkerClient() {
  return await (await import('./workerClient')).getWorkerClient();
}

function openStateDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(PERSONAL_STATE_DB_NAME, PERSONAL_STATE_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PERSONAL_STATE_STORE)) {
        db.createObjectStore(PERSONAL_STATE_STORE, { keyPath: 'pubkey' });
      }
      if (!db.objectStoreNames.contains(PERSONAL_PENDING_EVENT_STORE)) {
        db.createObjectStore(PERSONAL_PENDING_EVENT_STORE, { keyPath: 'id' });
      }
    };
    request.onerror = () => reject(request.error ?? new Error('Could not open personal index state'));
    request.onsuccess = () => resolve(request.result);
  });
}

function getPendingEventChannel(): BroadcastChannel | null {
  if (
    pendingEventChannel
    || typeof window === 'undefined'
    || typeof BroadcastChannel === 'undefined'
  ) {
    return pendingEventChannel;
  }
  pendingEventChannel = new BroadcastChannel(PERSONAL_PENDING_EVENT_CHANNEL);
  pendingEventChannel.onmessage = (message: MessageEvent<unknown>) => {
    const pubkey = typeof message.data === 'string' ? message.data.toLowerCase() : '';
    if (!/^[0-9a-f]{64}$/.test(pubkey)) {
      return;
    }
    for (const listener of pendingEventListeners) {
      listener(pubkey);
    }
  };
  return pendingEventChannel;
}

function postPendingEventChange(pubkey: string): void {
  const channel = pendingEventChannel;
  if (channel) {
    channel.postMessage(pubkey);
    return;
  }
  if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') {
    return;
  }
  const sender = new BroadcastChannel(PERSONAL_PENDING_EVENT_CHANNEL);
  sender.postMessage(pubkey);
  sender.close();
}

function getRootChangeChannel(): BroadcastChannel | null {
  if (
    rootChangeChannel
    || typeof window === 'undefined'
    || typeof BroadcastChannel === 'undefined'
  ) {
    return rootChangeChannel;
  }
  rootChangeChannel = new BroadcastChannel(PERSONAL_ROOT_CHANGE_CHANNEL);
  rootChangeChannel.onmessage = (message: MessageEvent<unknown>) => {
    if (!isRootChangeMessage(message.data)) {
      return;
    }
    const root = nhashDecode(message.data.root);
    rememberLocalRoot(root);
    for (const listener of rootChangeListeners) {
      listener(message.data.pubkey, root);
    }
  };
  return rootChangeChannel;
}

function postRootChange(pubkey: string, root: CID): void {
  const message = { pubkey, root: nhashEncode(root) };
  const channel = rootChangeChannel;
  if (channel) {
    channel.postMessage(message);
    return;
  }
  if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') {
    return;
  }
  const sender = new BroadcastChannel(PERSONAL_ROOT_CHANGE_CHANNEL);
  sender.postMessage(message);
  sender.close();
}

function isRootChangeMessage(value: unknown): value is { pubkey: string; root: string } {
  if (
    typeof value !== 'object'
    || value === null
    || !('pubkey' in value)
    || !('root' in value)
    || typeof value.pubkey !== 'string'
    || !/^[0-9a-f]{64}$/.test(value.pubkey)
    || typeof value.root !== 'string'
  ) {
    return false;
  }
  try {
    return nhashEncode(nhashDecode(value.root)) === value.root;
  } catch {
    return false;
  }
}

function cloneEvent(event: RawEvent): RawEvent {
  return { ...event, tags: event.tags.map((tag) => [...tag]) };
}

async function savePendingPersonalEvent(event: RawEvent): Promise<void> {
  const db = await openStateDb();
  try {
    const transaction = db.transaction(PERSONAL_PENDING_EVENT_STORE, 'readwrite');
    await idbRequest(transaction.objectStore(PERSONAL_PENDING_EVENT_STORE).put(cloneEvent(event)));
    await transactionDone(transaction);
  } finally {
    db.close();
  }
  postPendingEventChange(event.pubkey);
}

async function deletePendingPersonalEvent(eventId: string): Promise<void> {
  const db = await openStateDb();
  try {
    const transaction = db.transaction(PERSONAL_PENDING_EVENT_STORE, 'readwrite');
    await idbRequest(transaction.objectStore(PERSONAL_PENDING_EVENT_STORE).delete(eventId));
    await transactionDone(transaction);
  } finally {
    db.close();
  }
}

async function loadPendingPersonalEvents(pubkey: string): Promise<RawEvent[]> {
  const db = await openStateDb();
  try {
    const events = await idbRequest<RawEvent[]>(
      db.transaction(PERSONAL_PENDING_EVENT_STORE, 'readonly')
        .objectStore(PERSONAL_PENDING_EVENT_STORE)
        .getAll(),
    );
    return events.filter((event) => event.pubkey === pubkey).map(cloneEvent);
  } finally {
    db.close();
  }
}

function idbRequest<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onerror = () => reject(request.error ?? new Error('Personal index state request failed'));
    request.onsuccess = () => resolve(request.result);
  });
}

function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error('Personal index transaction failed'));
    transaction.onabort = () => reject(transaction.error ?? new Error('Personal index transaction aborted'));
  });
}

class BrowserPersonalStateStore implements PersonalEventIndexStateStore {
  async load(pubkey: string): Promise<PersonalEventIndexState | null> {
    const db = await openStateDb();
    try {
      const record = await idbRequest<PersonalEventIndexState | undefined>(
        db.transaction(PERSONAL_STATE_STORE, 'readonly').objectStore(PERSONAL_STATE_STORE).get(pubkey),
      );
      return record ? { ...record, pendingBlockHashes: [...record.pendingBlockHashes] } : null;
    } finally {
      db.close();
    }
  }

  async save(state: PersonalEventIndexState): Promise<void> {
    const db = await openStateDb();
    try {
      const transaction = db.transaction(PERSONAL_STATE_STORE, 'readwrite');
      await idbRequest(
        transaction.objectStore(PERSONAL_STATE_STORE).put({
          ...state,
          pendingBlockHashes: [...state.pendingBlockHashes],
        }),
      );
      await transactionDone(transaction);
    } finally {
      db.close();
    }
  }
}

export class PersonalBrowserBlockStore implements Store {
  private local: Promise<Store> | null = null;

  constructor(private readonly loadLocalStore: () => Promise<Store> = async () => {
    const { DexieStore } = await import('@hashtree/dexie');
    return new DexieStore(PERSONAL_EVENT_INDEX_BLOCK_STORE_NAME);
  }) {}

  private getLocalStore(): Promise<Store> {
    // Merely restoring an account or subscribing to roots does not need the
    // database library. Share initialization when the first block reads race.
    this.local ??= this.loadLocalStore().catch(error => {
      this.local = null;
      throw error;
    });
    return this.local;
  }

  async put(hash: Hash, data: Uint8Array): Promise<boolean> {
    return await (await this.getLocalStore()).put(hash, data);
  }

  async get(hash: Hash): Promise<Uint8Array | null> {
    const store = await this.getLocalStore();
    const local = await store.get(hash);
    if (local) {
      return local;
    }
    try {
      const { data } = await (await getPersonalWorkerClient()).getBlob(toHex(hash));
      await store.put(hash, data);
      return data;
    } catch {
      return null;
    }
  }

  async has(hash: Hash): Promise<boolean> {
    return await (await this.getLocalStore()).has(hash) || await this.get(hash) !== null;
  }

  async delete(_hash: Hash): Promise<boolean> {
    return false;
  }
}

async function runBrowserExclusive<T>(pubkey: string, operation: () => Promise<T>): Promise<T> {
  if (typeof navigator !== 'undefined' && navigator.locks) {
    return await navigator.locks.request(
      `iris-social:personal-event-index:${pubkey}`,
      operation,
    );
  }

  const previous = fallbackExclusiveQueues.get(pubkey) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>((resolve) => {
    release = resolve;
  });
  const tail = previous.catch(() => undefined).then(() => current);
  fallbackExclusiveQueues.set(pubkey, tail);
  await previous.catch(() => undefined);
  try {
    return await operation();
  } finally {
    release();
    if (fallbackExclusiveQueues.get(pubkey) === tail) {
      fallbackExclusiveQueues.delete(pubkey);
    }
  }
}

async function replicatePersonalBlocks(blocks: PersonalEventIndexBlock[]): Promise<void> {
  if (!getConfiguredBlossomServers().some((server) => server.write !== false)) {
    throw new Error('No writable Hashtree replica is configured');
  }
  const worker = await getPersonalWorkerClient();
  for (let offset = 0; offset < blocks.length; offset += UPLOAD_BATCH_SIZE) {
    await worker.putBlocks(
      blocks.slice(offset, offset + UPLOAD_BATCH_SIZE).map((block) => ({
        hashHex: block.hashHex,
        data: block.data,
      })),
      { upload: true },
    );
  }
}

function rememberLocalRoot(root: CID | null): void {
  if (root) {
    localRootNhashes.add(nhashEncode(root));
  }
}

function getPersonalBlockStore(): PersonalBrowserBlockStore {
  personalBlockStore ??= new PersonalBrowserBlockStore();
  return personalBlockStore;
}

function getPersonalIndex(): PersonalEventIndex {
  if (personalIndex) {
    return personalIndex;
  }
  personalIndex = new PersonalEventIndex({
    store: getPersonalBlockStore(),
    stateStore: new BrowserPersonalStateStore(),
    replicateBlocks: replicatePersonalBlocks,
    verifyEvent: verifyIndexedEvent,
    announceRoot: async () => {
      throw new Error('Personal event index root publisher is unavailable');
    },
    runExclusive: runBrowserExclusive,
  });
  personalIndex.subscribe((state) => {
    try {
      const root = nhashDecode(state.headNhash);
      rememberLocalRoot(root);
      for (const listener of rootChangeListeners) {
        listener(state.pubkey, root);
      }
      postRootChange(state.pubkey, root);
    } catch {
      // State validation in PersonalEventIndex will ignore corrupt heads.
    }
  });
  return personalIndex;
}

export function configurePersonalEventIndexRootPublisher(publisher: RootPublisher): void {
  rootPublisher = publisher;
}

export function subscribePersonalEventIndexRootChanges(
  listener: (pubkey: string, root: CID) => void,
): () => void {
  rootChangeListeners.add(listener);
  getRootChangeChannel();
  let subscribed = true;
  return () => {
    if (!subscribed) {
      return;
    }
    subscribed = false;
    rootChangeListeners.delete(listener);
    if (rootChangeListeners.size === 0 && rootChangeChannel) {
      rootChangeChannel.onmessage = null;
      rootChangeChannel.close();
      rootChangeChannel = null;
    }
  };
}

export function subscribePendingPersonalEventChanges(
  listener: (pubkey: string) => void,
): () => void {
  pendingEventListeners.add(listener);
  getPendingEventChannel();
  let subscribed = true;
  return () => {
    if (!subscribed) {
      return;
    }
    subscribed = false;
    pendingEventListeners.delete(listener);
    if (pendingEventListeners.size === 0 && pendingEventChannel) {
      pendingEventChannel.onmessage = null;
      pendingEventChannel.close();
      pendingEventChannel = null;
    }
  };
}

export function createPersonalEventIndexReadStore(): Store {
  return getPersonalBlockStore();
}

export function isLocalPersonalEventIndexRoot(root: CID): boolean {
  return localRootNhashes.has(nhashEncode(root));
}

export async function getLocalPersonalEventIndexRoot(pubkey: string): Promise<CID | null> {
  if (typeof indexedDB === 'undefined') {
    return null;
  }
  const root = await getPersonalIndex().getRoot(pubkey);
  rememberLocalRoot(root);
  return root;
}

export async function isPersonalEventIndexRootDurablyQueued(pubkey: string): Promise<boolean> {
  if (typeof indexedDB === 'undefined') {
    return false;
  }
  const state = await getPersonalIndex().getState(pubkey);
  return Boolean(state && state.headNhash === state.publishedHeadNhash);
}

export async function ensurePersonalEventIndexBase(account: SocialAccount): Promise<CID | null> {
  if (typeof indexedDB === 'undefined') {
    return null;
  }
  if (initializedAccounts.has(account.pubkey)) {
    return await getLocalPersonalEventIndexRoot(account.pubkey);
  }
  const pending = initializationPromises.get(account.pubkey);
  if (pending) {
    return await pending;
  }
  const initialization = (async () => {
    const remote = await resolveLatestPublishedRootResolution({
      kind: 'mutable',
      npub: account.npub,
      path: PERSONAL_EVENT_INDEX_TREE_NAME,
    }, ROOT_RESOLVE_TIMEOUT_MS);
    const root = await getPersonalIndex().updateRemoteBase(
      account.pubkey,
      remote?.root ?? null,
      remote?.createdAt ?? null,
    );
    rememberLocalRoot(root);
    initializedAccounts.add(account.pubkey);
    return root;
  })().finally(() => initializationPromises.delete(account.pubkey));
  initializationPromises.set(account.pubkey, initialization);
  return await initialization;
}

export async function indexPersonalEvent(account: SocialAccount, event: RawEvent): Promise<CID> {
  if (account.pubkey !== event.pubkey) {
    throw new Error('Cannot add another author to this personal event index');
  }
  await savePendingPersonalEvent(event);
  await ensurePersonalEventIndexBase(account);
  const root = await getPersonalIndex().append(event);
  await deletePendingPersonalEvent(event.id);
  rememberLocalRoot(root);
  return root;
}

export async function flushPersonalEventIndex(account: SocialAccount): Promise<CID | null> {
  if (!getConfiguredBlossomServers().some((server) => server.write !== false)) {
    // Offline/local-only indexes stay dirty and resume when a writable replica
    // appears. Do not spend relay or FIPS resources on an unpublishable head.
    return await getLocalPersonalEventIndexRoot(account.pubkey);
  }
  const activeFlush = flushPromises.get(account.pubkey);
  if (activeFlush) {
    return await activeFlush;
  }

  const flush = (async () => {
    const publisher = rootPublisher;
    if (!publisher) {
      throw new Error('Personal event index root publisher is unavailable');
    }
    // One cross-tab lock now covers the root query, merge, replication, and
    // durable root enqueue. Concurrent callers share this same promise.
    const root = await getPersonalIndex().refreshRemoteBaseAndFlush(
      account.pubkey,
      async () => {
        const remote = await resolveLatestPublishedRootResolution({
          kind: 'mutable',
          npub: account.npub,
          path: PERSONAL_EVENT_INDEX_TREE_NAME,
        }, ROOT_RESOLVE_TIMEOUT_MS);
        return remote
          ? { root: remote.root, createdAt: remote.createdAt }
          : null;
      },
      async (_pubkey, nextRoot, createdAt) => {
        await publisher(account, nextRoot, createdAt);
      },
    );
    rememberLocalRoot(root);
    initializedAccounts.add(account.pubkey);
    return root;
  })();
  const trackedFlush = flush.finally(() => {
    if (flushPromises.get(account.pubkey) === trackedFlush) {
      flushPromises.delete(account.pubkey);
    }
  });
  flushPromises.set(account.pubkey, trackedFlush);
  return await trackedFlush;
}

export async function resumePersonalEventIndexes(
  accounts: readonly SocialAccount[],
  locallyQueuedEvents: readonly RawEvent[] = [],
): Promise<void> {
  await Promise.all(accounts
    .filter(canSignAccount)
    .map(async (account) => {
      try {
        const localQueuedEvents = locallyQueuedEvents.filter((event) => (
          event.pubkey === account.pubkey && event.kind !== HASHTREE_ROOT_KIND
        ));
        let durablePendingEvents = await loadPendingPersonalEvents(account.pubkey);
        let state = await getPersonalIndex().getState(account.pubkey);
        if (!state && durablePendingEvents.length === 0 && localQueuedEvents.length === 0) {
          return;
        }
        await ensurePersonalEventIndexBase(account);
        const processedEventIds = new Set<string>();
        let includeLocalQueue = true;
        while (true) {
          const queuedEvents = [...new Map(
            [
              ...durablePendingEvents,
              ...(includeLocalQueue ? localQueuedEvents : []),
            ]
              .filter((event) => (
                event.pubkey === account.pubkey
                && event.kind !== HASHTREE_ROOT_KIND
                && !processedEventIds.has(event.id)
              ))
              .map((event) => [event.id, event]),
          ).values()];
          includeLocalQueue = false;
          if (queuedEvents.length === 0) {
            break;
          }
          for (const event of queuedEvents) {
            await getPersonalIndex().append(event);
            processedEventIds.add(event.id);
            await deletePendingPersonalEvent(event.id);
          }
          // Another tab can finish its durable enqueue after our first read.
          // Drain again so close/reload races cannot strand that event until a
          // later app launch.
          durablePendingEvents = await loadPendingPersonalEvents(account.pubkey);
        }
        state = await getPersonalIndex().getState(account.pubkey);
        if (!state || state.headNhash === state.publishedHeadNhash) {
          return;
        }
        await flushPersonalEventIndex(account);
      } catch (error) {
        console.warn('Could not flush the personal Hashtree event index', error);
      }
    }));
}
