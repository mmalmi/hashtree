import { isReplyEvent, type RawEvent } from './nostr';
import type { LiveTextNoteOptions } from './socialDataPlaneTypes';
import { selectLiveThreadReplies } from './socialDataPlaneSupport';
import {
  getSocialEventCoordinate,
  type SocialEventFilter,
} from './socialRepository';

type SnapshotMerger = (
  snapshotEvents: RawEvent[],
  filter?: SocialEventFilter,
) => RawEvent[];

export function projectLiveTextNotes(
  snapshotEvents: RawEvent[],
  options: LiveTextNoteOptions,
  mergeSnapshot: SnapshotMerger,
): RawEvent[] {
  if (options.authors && options.authors.length === 0) {
    return [];
  }
  const retainedIds = options.retainSnapshotEvents
    ? new Set(snapshotEvents.map(event => event.id))
    : null;
  return mergeSnapshot(snapshotEvents, {
    kinds: options.kinds ?? [1],
    authors: options.authors,
  })
    .filter((event) => options.includeReplies !== false || event.kind !== 1 || !isReplyEvent(event))
    // A newer history window must not evict already painted snapshot posts.
    // Retention happens after visibility filtering, so deletions still apply.
    .filter((event, index) => index < Math.max(0, options.limit) || retainedIds?.has(event.id));
}

export function projectRankedTextNotes(
  snapshotEvents: RawEvent[],
  options: LiveTextNoteOptions,
  mergeSnapshot: SnapshotMerger,
): RawEvent[] {
  if (options.authors && options.authors.length === 0) {
    return [];
  }
  const projected = mergeSnapshot(snapshotEvents, {
    kinds: options.kinds ?? [1],
    authors: options.authors,
  }).filter((event) => options.includeReplies !== false || event.kind !== 1 || !isReplyEvent(event));
  const byId = new Map(projected.map((event) => [event.id, event] as const));
  const byCoordinate = new Map(projected.flatMap((event) => {
    const coordinate = getSocialEventCoordinate(event);
    return coordinate ? [[coordinate, event] as const] : [];
  }));
  const seen = new Set<string>();
  const ordered: RawEvent[] = [];
  for (const snapshotEvent of snapshotEvents) {
    const coordinate = getSocialEventCoordinate(snapshotEvent);
    const event = byId.get(snapshotEvent.id) ?? (
      coordinate ? byCoordinate.get(coordinate) : undefined
    );
    if (!event || seen.has(event.id)) {
      continue;
    }
    seen.add(event.id);
    ordered.push(event);
    if (ordered.length >= Math.max(0, options.limit)) {
      break;
    }
  }
  return ordered;
}

export function projectLiveThreadReplies(
  snapshotReplies: RawEvent[],
  threadEvents: RawEvent[],
  limit: number,
  mergeSnapshot: SnapshotMerger,
): RawEvent[] {
  if (threadEvents.length === 0) {
    return snapshotReplies.slice(0, Math.max(0, limit));
  }
  const candidates = mergeSnapshot(snapshotReplies, { kinds: [1, 1111] });
  return selectLiveThreadReplies(snapshotReplies, threadEvents, candidates, limit);
}
