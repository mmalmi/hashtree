import { verifyEvent } from 'nostr-tools/pure';
import { CooperativeWorkBudget } from './cooperativeWork';
import type { RawEvent } from './nostr';
import {
  throwIfPostSearchAborted,
  withPostSearchAbort,
} from './postSearchAbort';

const DEFAULT_VERIFICATION_BATCH_SIZE = 128;
const MAX_VERIFICATION_BATCH_SIZE = 512;

export type PostSearchEventVerifier = (event: RawEvent) => boolean;

export type PostSearchEventBatchVerifier = (
  events: readonly RawEvent[],
  signal?: AbortSignal,
) => Promise<readonly boolean[]>;

export type PostSearchExecutionOptions = {
  /** Node/server compatibility path. Browser runtime supplies verifyEvents instead. */
  verifyEvent?: PostSearchEventVerifier;
  /** Browser verification boundary, normally the shared social worker. */
  verifyEvents?: PostSearchEventBatchVerifier;
  verificationBatchSize?: number;
  /** Injectable so responsiveness and yielding can be verified deterministically. */
  workBudget?: CooperativeWorkBudget;
};

export type PostSearchExecutionInput =
  | PostSearchEventVerifier
  | PostSearchExecutionOptions
  | PostSearchExecution;

/**
 * Owns the renderer-safety boundary for search work.
 *
 * Large local loops pass through the cooperative budget, while browser signature
 * verification crosses the supplied asynchronous batch boundary and never falls
 * back to per-event Schnorr work on the renderer.
 */
export class PostSearchExecution {
  readonly verificationBatchSize: number;
  private readonly verifyEvent: PostSearchEventVerifier;
  private readonly verifyEventsBatch: PostSearchEventBatchVerifier | null;
  private readonly workBudget: CooperativeWorkBudget;

  constructor(options: PostSearchExecutionOptions = {}) {
    this.verifyEvent = options.verifyEvent ?? verifyEvent;
    this.verifyEventsBatch = options.verifyEvents ?? null;
    this.verificationBatchSize = boundedBatchSize(options.verificationBatchSize);
    this.workBudget = options.workBudget ?? new CooperativeWorkBudget();
  }

  async run<T>(
    signal: AbortSignal | null,
    work: () => T,
  ): Promise<T> {
    throwIfPostSearchAborted(signal);
    const result = await this.workBudget.run(work);
    throwIfPostSearchAborted(signal);
    return result;
  }

  async verifyEvents(
    events: readonly RawEvent[],
    signal: AbortSignal | null,
  ): Promise<boolean[]> {
    const validity: boolean[] = [];
    for (let offset = 0; offset < events.length; offset += this.verificationBatchSize) {
      throwIfPostSearchAborted(signal);
      const batch = events.slice(offset, offset + this.verificationBatchSize);
      if (this.verifyEventsBatch) {
        const batchValidity = await withPostSearchAbort(
          Promise.resolve(this.verifyEventsBatch(batch, signal ?? undefined)),
          signal,
        );
        throwIfPostSearchAborted(signal);
        if (batchValidity.length !== batch.length) {
          throw new Error('Post-search verifier returned an invalid result count');
        }
        validity.push(...batchValidity.map((valid) => valid === true));
        continue;
      }

      for (const event of batch) {
        validity.push(await this.run(signal, () => {
          try {
            return this.verifyEvent(event);
          } catch {
            return false;
          }
        }));
      }
    }
    return validity;
  }
}

export function createPostSearchExecution(
  input: PostSearchExecutionInput | undefined,
): PostSearchExecution {
  if (input instanceof PostSearchExecution) {
    return input;
  }
  if (typeof input === 'function') {
    return new PostSearchExecution({ verifyEvent: input });
  }
  return new PostSearchExecution(input);
}

export function takePostSearchIteratorBatch<T>(iterator: Iterator<T>, limit: number): T[] {
  const batch: T[] = [];
  while (batch.length < limit) {
    const next = iterator.next();
    if (next.done) {
      break;
    }
    batch.push(next.value);
  }
  return batch;
}

export async function selectBestPostSearchResults<T>(
  values: Iterable<T>,
  limit: number,
  signal: AbortSignal | null,
  execution: PostSearchExecution,
  compare: (left: T, right: T) => number,
): Promise<T[]> {
  if (limit === 0) {
    return [];
  }
  const best: T[] = [];
  for (const candidate of values) {
    await execution.run(signal, () => {
      let low = 0;
      let high = best.length;
      while (low < high) {
        const middle = (low + high) >>> 1;
        if (compare(candidate, best[middle]!) < 0) {
          high = middle;
        } else {
          low = middle + 1;
        }
      }
      best.splice(low, 0, candidate);
      if (best.length > limit) {
        best.pop();
      }
    });
  }
  return best;
}

/** Browser runtime verifier: one cancellable shared-worker request per bounded batch. */
export async function verifyPostSearchEventsInWorker(
  events: readonly RawEvent[],
  signal?: AbortSignal,
): Promise<boolean[]> {
  const normalizedSignal = signal ?? null;
  throwIfPostSearchAborted(normalizedSignal);
  const client = await withPostSearchAbort(
    import('./workerClient').then(async ({ getWorkerClient }) => await getWorkerClient()),
    normalizedSignal,
  );
  throwIfPostSearchAborted(normalizedSignal);
  return await withPostSearchAbort(
    client.verifyEvents([...events], signal),
    normalizedSignal,
  );
}

function boundedBatchSize(value: number | undefined): number {
  if (value === undefined) {
    return DEFAULT_VERIFICATION_BATCH_SIZE;
  }
  if (!Number.isFinite(value)) {
    throw new RangeError('Post-search verification batch size must be finite');
  }
  return Math.max(1, Math.min(MAX_VERIFICATION_BATCH_SIZE, Math.trunc(value)));
}
