import type { DexieStore } from '@hashtree/dexie';
import type { BrowserHashtreeFipsProvider, openBrowserAnnouncements } from '@hashtree/fips-transport/browser';
import type { HashtreeWorkerClient } from '@hashtree/worker/client';
import { MemoryStore, fromHex } from '@hashtree/core';
import { createAnonymousFipsDiscovery, createAnonymousFipsPublisher, createScopedFipsSource,
  FipsNostrPubsubClient, FipsNostrPubsubEventSource, openPublicPeerFeedSource, type RuntimeSource } from 'nostr-pubsub';
import { get } from 'svelte/store';
import { generateSecretKey, getPublicKey } from 'nostr-tools/pure';
import {
  getConfiguredFipsDiscoveryApp,
  getConfiguredFipsPeerIds,
  getConfiguredFipsWebsocketSeedUrls,
  getConfiguredPrivateNostrRelays,
  WORKER_STORE_NAME,
} from './htreeRuntime';
import type { SocialLiveTransport } from './socialDataPlaneTypes';
import { WorkerNostrSource } from './workerNostrSource';
import { accountsStore } from './accounts';
import { peerFeeds, socialPeerSource, updateAccountPeerFeed } from './socialPeerFeed';
import { publicFipsAuthors } from './publicFipsAuthors';

const DEVICE_SECRET_STORAGE_KEY = 'iris-social:fips-device-secret';
const HEX_SECRET_PATTERN = /^[0-9a-f]{64}$/;
// Private controls only enter this transport inside opaque ratcheted envelopes.
// Authorization is checked again by the receiving private-sync runtime.
const PEER_EVENT_KINDS = [0, 1, 3, 5, 6, 7, 16, 20, 1059, 1060, 1111, 9735, 10000, 21111, 30000, 30023, 30064, 30078, 37195, 37368];

export type PeerNetworkStatus = 'starting' | 'ready' | 'unavailable' | 'unsupported' | 'stopped';
let networkStatus: PeerNetworkStatus = 'stopped';
let provider: BrowserHashtreeFipsProvider | null = null;
let providerSource: (RuntimeSource & {close(): void}) | null = null;
let providerPubsub: FipsNostrPubsubClient | null = null;
let providerLifetime: AbortController | null = null;
let providerAnnouncements: Awaited<ReturnType<typeof openBrowserAnnouncements>> | null = null;
let stopPublicFollows: (() => void) | null = null;

/** A read-only snapshot; opening settings must not create another peer network. */
export function getPeerNetworkSnapshot(): { status: PeerNetworkStatus; peers: string[] } {
  return { status: networkStatus, peers: provider?.listConnectedPeerIds() ?? [] };
}
let providerStore: DexieStore | null = null;
let startPromise: Promise<BrowserHashtreeFipsProvider | null> | null = null;
let activeConfigurationKey: string | null = null;
let activeWorkerClient: HashtreeWorkerClient | null = null;
let liveNostrPubsub: WorkerNostrSource | null = null;
let workerStartPromise: Promise<void> | null = null;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function getOrCreateDeviceSecret(): string {
  const stored = localStorage.getItem(DEVICE_SECRET_STORAGE_KEY)?.trim().toLowerCase();
  if (stored && HEX_SECRET_PATTERN.test(stored)) {
    return stored;
  }

  const created = bytesToHex(generateSecretKey());
  localStorage.setItem(DEVICE_SECRET_STORAGE_KEY, created);
  return created;
}

function getConfiguration() {
  return {
    relays: getConfiguredPrivateNostrRelays(),
    discoveryApp: getConfiguredFipsDiscoveryApp(),
    peerIds: getConfiguredFipsPeerIds(),
    websocketSeedUrls: getConfiguredFipsWebsocketSeedUrls(),
  };
}

function getConfigurationKey(): string {
  return JSON.stringify(getConfiguration());
}

/** Start the browser FIPS provider used as the worker's opaque datagram bridge. */
export function startBrowserFipsP2P(): Promise<BrowserHashtreeFipsProvider | null> {
  if (provider) {
    return Promise.resolve(provider);
  }
  if (startPromise) {
    return startPromise;
  }

  const configuration = getConfiguration();
  const configurationKey = JSON.stringify(configuration);
  networkStatus = 'starting';
  startPromise = (async () => {
    const {
      createBrowserHashtreeFipsProvider,
      openBrowserAnnouncements,
      supportsBrowserHashtreeFips,
    } = await import('@hashtree/fips-transport/browser');
    if (!supportsBrowserHashtreeFips()) {
      networkStatus = 'unsupported';
      return null;
    }
    const { DexieStore } = await import('@hashtree/dexie');
    const localStore = new DexieStore(WORKER_STORE_NAME);
    let created: BrowserHashtreeFipsProvider | null = null;
    let pubsub: FipsNostrPubsubClient | null = null;
    const lifetime = new AbortController();
    let announcements: Awaited<ReturnType<typeof openBrowserAnnouncements>> | null = null;
    try {
      const base = {
        relays: configuration.relays,
        discoveryApp: configuration.discoveryApp,
        providerRoutes: configuration.peerIds.map((peerId) => ({ peerId, htl: 0 })),
        websocketSeedUrls: configuration.websocketSeedUrls,
        maxConnections: 4,
        iceGatherTimeoutMs: 2_000,
      };
      const secret = getOrCreateDeviceSecret();
      const deviceAuthor = getPublicKey(fromHex(secret));
      // The UI event cache records what was read. Only discovery's own
      // announcement store can serve retained history to incoming peers.
      announcements = await openBrowserAnnouncements(deviceAuthor, base.discoveryApp, base.relays,
        undefined, error => console.warn('Peer announcement discovery failed', error));
      created = await createBrowserHashtreeFipsProvider({
        ...base, deviceSecretKey: secret,
        localStore, discoveryProvider: announcements.discovery,
      });
      const createEndpoint = async () => {
        lifetime.signal.throwIfAborted();
        if (!configuration.peerIds.length) { throw new Error('No private message provider is configured'); }
        const endpoint = await createBrowserHashtreeFipsProvider({
          ...base, deviceSecretKey: generateSecretKey(), localStore: new MemoryStore(),
          serveBlob: async () => null, forwarding: false,
          allowIncomingPeer: peer => configuration.peerIds.includes(peer.toLowerCase()),
        });
        if (lifetime.signal.aborted) { await endpoint.stop(); lifetime.signal.throwIfAborted(); }
        return { node: endpoint.node, localPeerId: endpoint.localPeerId,
          peers: () => configuration.peerIds, close: () => endpoint.stop() };
      };
      const liveProvider = created;
      pubsub = new FipsNostrPubsubClient({
        node: created.node, localPeerId: created.localPeerId,
        peers: () => [...new Set([...configuration.peerIds, ...liveProvider.listConnectedPeerIds()])],
        role: 'receiver',
        receiverPublicAuthors: () => {
          const owner = accountsStore.getState().activeAccountPubkey;
          const selected = get(peerFeeds).find(feed => feed.type === 'following');
          const contacts = selected?.owner === owner ? selected?.contacts : undefined;
          return [deviceAuthor, ...publicFipsAuthors(owner, contacts, () => [])];
        },
        allowedKinds: PEER_EVENT_KINDS,
        retainedEventReader: announcements.retained,
      }).start();
      const receiver = new FipsNostrPubsubEventSource(pubsub);
      announcements.attach(receiver);
      const anonymousPublisher = createAnonymousFipsPublisher({ createEndpoint, timeoutMs: 2_500 });
      const messaging = createScopedFipsSource({
        receiver,
        publisher: { publish: (event, origin) => anonymousPublisher.publish(event, origin, { signal: lifetime.signal }) },
        // Without an approved provider, public discovery stays on its separate
        // relay lane. It must not cancel independent inbox/feed interests.
        discovery: configuration.peerIds.length
          ? createAnonymousFipsDiscovery({ createEndpoint, timeoutMs: 2_500 })
          : { query: async () => ({ events: [], complete: false }),
              subscribe: async () => ({ close() {} }) },
      });
      updateAccountPeerFeed();
      const initialFeed = get(peerFeeds);
      const feed = await openPublicPeerFeedSource(receiver, initialFeed);
      providerSource = { ...socialPeerSource(feed, messaging), close() { feed.close(); messaging.close(); } };
      providerPubsub = pubsub;
      const stopAccount = accountsStore.subscribe(() => updateAccountPeerFeed());
      let selected = initialFeed;
      const stopFeed = peerFeeds.subscribe(next => {
        if (selected !== next) {
          selected = next;
          void feed.replaceFeed(next).catch(error => console.warn('Peer feed unavailable', error));
        }
      });
      stopPublicFollows = () => { stopAccount(); stopFeed(); };
      providerAnnouncements = announcements;
      providerLifetime = lifetime;
      providerStore = localStore;
      provider = created;
      networkStatus = 'ready';
      activeConfigurationKey = configurationKey;
      return created;
    } catch (error) {
      lifetime.abort();
      await announcements?.close().catch(() => undefined);
      await pubsub?.stop().catch(() => undefined);
      await created?.stop().catch(() => undefined);
      localStore.close();
      throw error;
    }
  })().catch(error => {
    networkStatus = 'unavailable';
    throw error;
  }).finally(() => {
    startPromise = null;
  });

  return startPromise;
}

/** Keep public reception/files on the live endpoint and private delivery anonymous. */
export async function startWorkerFipsP2P(workerClient: HashtreeWorkerClient): Promise<void> {
  activeWorkerClient = workerClient;
  if (workerStartPromise) { await workerStartPromise; }
  if (provider && liveNostrPubsub?.client === workerClient && liveNostrPubsub.attached) {
    workerClient.setP2PProvider(provider);
    return;
  }
  const pending = (async () => {
    const activeProvider = await startBrowserFipsP2P();
    if (!activeProvider || activeWorkerClient !== workerClient) { return; }
    workerClient.setP2PProvider(activeProvider);
    if (liveNostrPubsub && liveNostrPubsub.client !== workerClient) {
      await liveNostrPubsub.dispose();
      liveNostrPubsub = null;
    }
    liveNostrPubsub ??= new WorkerNostrSource(workerClient);
    if (!providerSource) { throw new Error('Peer message source is unavailable'); }
    await liveNostrPubsub.attach(providerSource);
  })();
  workerStartPromise = pending;
  try { await pending; }
  finally { if (workerStartPromise === pending) {workerStartPromise = null; } }
}

/** Return the worker-owned live service backed by the shared FIPS node. */
export async function getLiveNostrPubsub(): Promise<SocialLiveTransport | null> {
  let workerClient = activeWorkerClient;
  if (!workerClient) {
    const { getHashtreeWorkerClient } = await import('./workerClient');
    workerClient = await getHashtreeWorkerClient();
  }
  await startWorkerFipsP2P(workerClient);
  return provider ? liveNostrPubsub : null;
}

export async function syncWorkerFipsP2P(workerClient: HashtreeWorkerClient): Promise<void> {
  await startPromise?.catch(() => undefined);
  await workerStartPromise?.catch(() => undefined);
  const configurationKey = getConfigurationKey();
  if (provider && activeConfigurationKey === configurationKey) {
    workerClient.setP2PProvider(provider);
    await startWorkerFipsP2P(workerClient);
    return;
  }
  await stopWorkerFipsP2P(workerClient);
  await startWorkerFipsP2P(workerClient);
}

export async function stopWorkerFipsP2P(workerClient: HashtreeWorkerClient): Promise<void> {
  await startPromise?.catch(() => undefined);
  await workerStartPromise?.catch(() => undefined);
  workerClient.setP2PProvider(null);
  const activeProvider = provider;
  const activeStore = providerStore;
  const announcements = providerAnnouncements;
  providerAnnouncements = null;
  const activeSource = providerSource;
  const activePubsub = providerPubsub;
  stopPublicFollows?.();
  stopPublicFollows = null;
  providerLifetime?.abort();
  providerLifetime = null;
  providerSource = null;
  providerPubsub = null;
  provider = null;
  networkStatus = 'stopped';
  providerStore = null;
  activeConfigurationKey = null;
  try {
    await liveNostrPubsub?.detach();
  } finally {
    activeSource?.close();
    try {
      try { await announcements?.close(); } finally { await activePubsub?.stop(); }
    } finally {
      try { await activeProvider?.stop(); }
      finally { activeStore?.close(); }
    }
  }
}
