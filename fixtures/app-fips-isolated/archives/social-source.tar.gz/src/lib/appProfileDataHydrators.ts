import type { AppError, ReportAppError } from './appError';
import { canReadHomeFeedFromRelays } from './homeFeedReads';
import { getNoteEngagementTargetId } from './noteEngagement';
import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import { createProfileRecordHydrator } from './appProfileRecordHydrator';
import { getProfileEngagementRoots } from './appViewState';
import {
  getRootNhash,
  loadProfilesForPubkeys,
  loadProfileRecord,
  resolveProfileEventIndexRoot,
} from './nostrIndex';
import {
  loadProfileNotes,
  loadProfileNotesPage,
  readProfilePage,
  streamProfileNotes,
  type ProfileSnapshot,
} from './profileNotes';
import { createProfileRelayPages } from './profileRelayPages';
import {
  appendNextProfileNotesPages,
  withProfileRootContinuation,
} from './profileNotesPagination';
import type { ProfileRecord, RawEvent } from './nostr';
import { preferNewerProfileRecord } from './profileRecords';
import {
  createProfileLikesPager,
  getProfileReactionTargetId,
  type ProfileLikedNote,
  type ProfileLikesPage,
  type ProfileLikesPager,
} from './profileLikes';

type ProfileDataHydratorDeps = {
  getLoadToken: () => number;
  getProfileNotesRequestId: () => number;
  getProfileLikesRequestId?: () => number;
  getProfileNoteFetchLimit: () => number;
  getProfilePage: () => ProfileSnapshot | null;
  getAccountProfiles: () => Map<string, ProfileRecord>;
  getProfilePersonalRoot: () => CID | null;
  setProfilePersonalRoot: (root: CID | null) => void;
  setProfilePage: (page: ProfileSnapshot | null) => void;
  setAccountProfiles: (profiles: Map<string, ProfileRecord>) => void;
  setProfileEmptyRetryKey: (key: string | null) => void;
  setProfileNotesLoading: (loading: boolean) => void;
  setPageError: (message: AppError) => void;
  reportError: ReportAppError;
  incrementProfileNotesRequestId: () => number;
  incrementProfileLikesRequestId?: () => number;
  cacheKnownNotes: (...noteLists: RawEvent[][]) => void;
  mergeLocalVisibleNotes: (notes: RawEvent[], pubkey: string) => RawEvent[];
  seedEmptyEngagements: (noteIds: string[]) => void;
  hydrateNoteEngagements: (engagementRoots: CID | CID[], noteIds: string[], token: number) => Promise<void>;
  loadNextProfileNotesPage?: typeof loadProfileNotesPage;
  streamProfileNotes?: typeof streamProfileNotes;
  createProfileLikesPager?: (pubkey: string) => ProfileLikesPager;
  profileRelayPages?: Pick<ReturnType<typeof createProfileRelayPages>, 'load'>;
  resolveProfileLikesRoot?: typeof resolveProfileEventIndexRoot;
  getProfileOverlayReactions?: (pubkey: string) => RawEvent[];
  getKnownNoteById?: (eventId: string) => RawEvent | null;
  loadProfileRecord?: typeof loadProfileRecord;
};

export function createProfileDataHydrators(deps: ProfileDataHydratorDeps) {
  const maxContinuationPagesPerLoad = 8;
  const loadNextProfileNotesPage = deps.loadNextProfileNotesPage ?? loadProfileNotesPage;
  const loadProgressiveProfileNotes = deps.streamProfileNotes ?? streamProfileNotes;
  const createLikesPager = deps.createProfileLikesPager ?? ((pubkey: string) => createProfileLikesPager(pubkey));
  /** One pager per visible profile: Load More continues it, a fresh load replaces it. */
  let likesPager: ProfileLikesPager | null = null;
  const profileRelayPages = deps.profileRelayPages ?? createProfileRelayPages();
  const resetLikesPager = (pubkey: string): ProfileLikesPager => {
    likesPager?.close();
    likesPager = createLikesPager(pubkey);
    return likesPager;
  };
  const loadProfileRecordForPubkey = deps.loadProfileRecord ?? loadProfileRecord;
  const resolveProfileLikesRoot = deps.resolveProfileLikesRoot ?? resolveProfileEventIndexRoot;
  let fallbackProfileLikesRequestId = 0;
  const getProfileLikesRequestId = deps.getProfileLikesRequestId
    ?? (() => fallbackProfileLikesRequestId);
  const incrementProfileLikesRequestId = deps.incrementProfileLikesRequestId
    ?? (() => ++fallbackProfileLikesRequestId);
  const profileRecordHydrator = createProfileRecordHydrator({
    getLoadToken: deps.getLoadToken,
    getProfilePage: deps.getProfilePage,
    getAccountProfiles: deps.getAccountProfiles,
    setProfilePage: deps.setProfilePage,
    setAccountProfiles: deps.setAccountProfiles,
    setProfileEmptyRetryKey: deps.setProfileEmptyRetryKey,
    loadProfileRecord: deps.loadProfileRecord,
  });

  function isCurrentProfileRequest(token: number, requestId: number): boolean {
    return token === deps.getLoadToken() && requestId === deps.getProfileNotesRequestId();
  }

  function isCurrentProfileLikesRequest(token: number, requestId: number): boolean {
    return token === deps.getLoadToken() && requestId === getProfileLikesRequestId();
  }

  function commitProfileLikesPage(
    currentRoot: CID,
    pubkey: string,
    roots: CID[],
    page: ProfileLikesPage,
    token: number,
    requestId: number,
    previous: readonly ProfileLikedNote[] = [],
  ): void {
    if (!isCurrentProfileLikesRequest(token, requestId)) {
      return;
    }
    const seen = new Set(previous.map((item) => item.note.id));
    const added = page.items.filter((item) => !seen.has(item.note.id));
    const notes = added.map((item) => item.note);
    deps.cacheKnownNotes(notes);
    deps.setProfilePage({
      ...deps.getProfilePage(),
      rootNhash: getRootNhash(currentRoot),
      profile: deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
      notes: deps.getProfilePage()?.notes ?? [],
      likedNotes: [...previous, ...added],
      likedNotesHasMore: page.hasMore,
    });
    deps.seedEmptyEngagements(notes.map(getNoteEngagementTargetId));
    if (notes.length === 0) {
      return;
    }
    void deps.hydrateNoteEngagements(roots, notes.map(getNoteEngagementTargetId), token);
    void loadProfilesForPubkeys(
      currentRoot,
      [...new Set(notes.map((event) => event.pubkey))],
    ).then((targetProfiles) => {
      if (!isCurrentProfileLikesRequest(token, requestId)) {
        return;
      }
      const profiles = new Map(deps.getAccountProfiles());
      for (const [targetPubkey, profile] of targetProfiles) {
        profiles.set(
          targetPubkey,
          preferNewerProfileRecord(profiles.get(targetPubkey) ?? null, profile) ?? profile,
        );
      }
      deps.setAccountProfiles(profiles);
    }).catch((error: unknown) => {
      console.warn('Failed to hydrate liked-note profiles', error);
    });
  }

  async function mergePersonalProfileNotesPage(
    currentRoot: CID,
    pubkey: string,
    token: number,
    requestId: number,
  ): Promise<void> {
    const personalRoot = deps.getProfilePersonalRoot();
    if (!personalRoot || getRootNhash(personalRoot) === getRootNhash(currentRoot)) {
      return;
    }

    try {
      const personalNotes = await loadProfileNotes(personalRoot, pubkey, deps.getProfileNoteFetchLimit());
      if (token !== deps.getLoadToken() || requestId !== deps.getProfileNotesRequestId()) {
        return;
      }

      const mergedNotes = mergeNotesByNewest(deps.getProfilePage()?.notes ?? [], personalNotes);
      const latestVisibleNotes = deps.mergeLocalVisibleNotes(mergedNotes, pubkey);
      deps.cacheKnownNotes(mergedNotes);
      const snapshot: ProfileSnapshot = {
        ...deps.getProfilePage(),
        rootNhash: getRootNhash(currentRoot),
        profile: deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
        notes: mergedNotes,
      };
      const boundary = personalNotes.at(-1);
      deps.setProfilePage(withProfileRootContinuation(snapshot, {
        rootNhash: getRootNhash(personalRoot),
        cursor: boundary
          ? { createdAt: boundary.created_at, eventId: boundary.id }
          : null,
        hasMore: personalNotes.length >= deps.getProfileNoteFetchLimit(),
        noteCount: personalNotes.length,
      }));
      deps.seedEmptyEngagements(latestVisibleNotes.map(getNoteEngagementTargetId));
      if (latestVisibleNotes.length > 0) {
        deps.setProfileEmptyRetryKey(null);
      }

      if (latestVisibleNotes.length > 0) {
        void deps.hydrateNoteEngagements(
          getProfileEngagementRoots(currentRoot, deps.getProfilePersonalRoot()),
          latestVisibleNotes.map(getNoteEngagementTargetId),
          token,
        );
      }
    } catch (error) {
      console.warn('Failed to merge profile notes from personal nostr index', error);
    }
  }

  return {
    ...profileRecordHydrator,

    async hydrateProfileLikes(
      currentRoot: CID,
      pubkey: string,
      token: number,
      options: { updateLoading?: boolean; continuation?: boolean } = {},
    ): Promise<void> {
      const requestId = incrementProfileLikesRequestId();
      const updateLoading = options.updateLoading ?? true;
      const continuation = options.continuation === true && likesPager?.pubkey === pubkey;
      const pager = continuation && likesPager ? likesPager : resetLikesPager(pubkey);
      const previous = continuation
        ? (deps.getProfilePage()?.likedNotes ?? []).filter((item) => item.reaction.pubkey === pubkey)
        : [];
      const fetchLimit = deps.getProfileNoteFetchLimit();
      const limit = continuation ? Math.max(8, fetchLimit - previous.length) : fetchLimit;
      const knownPersonalRoot = deps.getProfilePersonalRoot();
      const personalRootPromise = continuation || knownPersonalRoot
        ? null
        : resolveProfileLikesRoot(pubkey).catch((error: unknown) => {
            console.warn('Failed to resolve profile Likes personal Hashtree root', error);
            return null;
          });
      const overlayReactions = deps.getProfileOverlayReactions?.(pubkey) ?? [];
      const knownTargets = new Map<string, RawEvent>();
      for (const reaction of overlayReactions) {
        const targetId = getProfileReactionTargetId(reaction);
        const target = targetId ? deps.getKnownNoteById?.(targetId) ?? null : null;
        if (targetId && target) {
          knownTargets.set(targetId, target);
        }
      }
      try {
        const roots = getProfileEngagementRoots(currentRoot, knownPersonalRoot);
        const page: ProfileLikesPage = await pager.next(roots, limit, overlayReactions, knownTargets);
        if (likesPager !== pager) {
          return;
        }
        commitProfileLikesPage(currentRoot, pubkey, roots, page, token, requestId, previous);
        if (personalRootPromise) {
          void personalRootPromise.then(async (resolvedPersonalRoot) => {
            if (
              !resolvedPersonalRoot
              || !isCurrentProfileLikesRequest(token, requestId)
              || likesPager !== pager
              || getRootNhash(resolvedPersonalRoot) === getRootNhash(currentRoot)
            ) {
              return;
            }
            deps.setProfilePersonalRoot(resolvedPersonalRoot);
            // The first page missed this index; restart once with both roots.
            const mergedPager = resetLikesPager(pubkey);
            const mergedRoots = getProfileEngagementRoots(currentRoot, resolvedPersonalRoot);
            const mergedPage = await mergedPager.next(mergedRoots, fetchLimit, overlayReactions, knownTargets);
            if (likesPager === mergedPager) {
              commitProfileLikesPage(currentRoot, pubkey, mergedRoots, mergedPage, token, requestId);
            }
          }).catch((error: unknown) => {
            console.warn('Failed to merge profile Likes from personal Hashtree index', error);
          });
        }
      } catch (error) {
        console.warn('Failed to load profile likes from Hashtree indexes', error);
        if (
          updateLoading
          && token === deps.getLoadToken()
          && requestId === getProfileLikesRequestId()
          && !(deps.getProfilePage()?.likedNotes?.length ?? 0)
        ) {
          deps.setPageError(deps.reportError("Couldn't load likes right now.", error));
        }
      } finally {
        if (
          updateLoading
          && token === deps.getLoadToken()
          && requestId === getProfileLikesRequestId()
        ) {
          deps.setProfileNotesLoading(false);
        }
      }
    },

    /** Without a shared index root (offline), the personal index is the only Hashtree source. */
    async hydrateProfileFromPersonalIndex(
      currentRoot: CID | null,
      pubkey: string,
      token: number,
    ): Promise<void> {
      const personalRoot = await resolveProfileEventIndexRoot(pubkey);
      if (!personalRoot || token !== deps.getLoadToken()) {
        return;
      }
      const currentRootNhash = currentRoot ? getRootNhash(currentRoot) : '';

      if (getRootNhash(personalRoot) === currentRootNhash) {
        deps.setProfilePersonalRoot(null);
        return;
      }

      try {
        deps.setProfilePersonalRoot(personalRoot);
        // A post-only personal root has no kind-0 event. Read that immutable
        // root directly instead of falling through to the shared profile
        // catalog, and never let optional metadata hold local notes hostage.
        void loadProfileRecordForPubkey(personalRoot, pubkey).then((profile) => {
          if (!profile || token !== deps.getLoadToken()) {
            return;
          }
          const nextProfile = preferNewerProfileRecord(
            deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
            profile,
          );
          if (!nextProfile) {
            return;
          }
          deps.setProfilePage({
            ...deps.getProfilePage(),
            rootNhash: currentRootNhash,
            profile: nextProfile,
            notes: deps.getProfilePage()?.notes ?? [],
          });
          deps.setAccountProfiles(new Map(deps.getAccountProfiles()).set(pubkey, nextProfile));
          deps.setProfileEmptyRetryKey(null);
        }).catch((error: unknown) => {
          console.warn('Failed to load profile metadata from personal nostr index', error);
        });

        const notes = await loadProfileNotes(
          personalRoot,
          pubkey,
          deps.getProfileNoteFetchLimit(),
        );
        if (token !== deps.getLoadToken()) {
          return;
        }

        if (notes.length === 0) {
          return;
        }

        const mergedNotes = mergeNotesByNewest(deps.getProfilePage()?.notes ?? [], notes);
        deps.cacheKnownNotes(mergedNotes);
        const snapshot: ProfileSnapshot = {
          ...deps.getProfilePage(),
          rootNhash: currentRootNhash,
          profile: deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
          notes: mergedNotes,
        };
        const boundary = notes.at(-1);
        deps.setProfilePage(withProfileRootContinuation(snapshot, {
          rootNhash: getRootNhash(personalRoot),
          cursor: boundary
            ? { createdAt: boundary.created_at, eventId: boundary.id }
            : null,
          hasMore: notes.length >= deps.getProfileNoteFetchLimit(),
          noteCount: notes.length,
        }));

        const nextProfile = deps.getProfilePage()?.profile ?? null;
        if (nextProfile) {
          deps.setAccountProfiles(new Map(deps.getAccountProfiles()).set(pubkey, nextProfile));
          deps.setProfileEmptyRetryKey(null);
        }

        const mergedNoteIds = mergedNotes.map(getNoteEngagementTargetId);
        deps.seedEmptyEngagements(mergedNoteIds);
        void deps.hydrateNoteEngagements(
          currentRoot ? getProfileEngagementRoots(currentRoot, deps.getProfilePersonalRoot()) : [personalRoot],
          mergedNoteIds,
          token,
        );
      } catch (error) {
        console.warn('Failed to load profile from personal nostr index', error);
      }
    },

    async hydrateProfileNotesProgressively(
      currentRoot: CID,
      pubkey: string,
      token: number,
      options: {
        emitEvery?: number;
        visibleThreshold?: number;
        onVisibleReady?: () => void;
      } = {},
    ): Promise<void> {
      const requestId = deps.incrementProfileNotesRequestId();
      const rootNhash = getRootNhash(currentRoot);
      let latestVisibleNotes: RawEvent[] = [];
      let latestStreamedNotes: RawEvent[] = [];
      let indexedNotes: RawEvent[] | undefined;
      let indexFinished = false;
      let visibleReady = false;
      let previousStreamedIds = new Set<string>();

      try {
        for await (const streamedNotes of loadProgressiveProfileNotes(currentRoot, pubkey, deps.getProfileNoteFetchLimit(), {
          emitEvery: options.emitEvery,
          onIndexedNotes: (notes, complete) => { indexedNotes = notes; indexFinished = complete; },
        })) {
          if (token !== deps.getLoadToken() || requestId !== deps.getProfileNotesRequestId()) {
            return;
          }

          const preservedNotes = (deps.getProfilePage()?.notes ?? [])
            .filter((event) => !previousStreamedIds.has(event.id));
          const mergedNotes = mergeNotesByNewest(preservedNotes, streamedNotes);
          latestStreamedNotes = streamedNotes;
          previousStreamedIds = new Set(streamedNotes.map((event) => event.id));
          latestVisibleNotes = deps.mergeLocalVisibleNotes(mergedNotes, pubkey);
          deps.cacheKnownNotes(mergedNotes);
          const snapshot: ProfileSnapshot = {
            ...deps.getProfilePage(),
            rootNhash,
            profile: deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
            notes: mergedNotes,
          };
          const archivePage = indexedNotes ?? streamedNotes;
          const boundary = archivePage.at(-1);
          deps.setProfilePage(withProfileRootContinuation(snapshot, {
            rootNhash,
            cursor: boundary
              ? { createdAt: boundary.created_at, eventId: boundary.id }
              : null,
            // A progressive yield is not end-of-stream. Keep continuation
            // conservatively open so a partial first paint cannot truncate
            // the durable cursor.
            hasMore: true,
            noteCount: archivePage.length,
          }));
          deps.seedEmptyEngagements(
            latestVisibleNotes.slice(0, deps.getProfileNoteFetchLimit()).map(getNoteEngagementTargetId),
          );
          if (latestVisibleNotes.length > 0) {
            deps.setProfileEmptyRetryKey(null);
          }
          if (
            !visibleReady
            && options.visibleThreshold
            && latestVisibleNotes.length >= options.visibleThreshold
          ) {
            visibleReady = true;
            options.onVisibleReady?.();
          }
        }

        if (isCurrentProfileRequest(token, requestId)) {
          const currentSnapshot = deps.getProfilePage();
          if (currentSnapshot?.rootNhash === rootNhash) {
            const archivePage = indexedNotes ?? latestStreamedNotes;
            const boundary = archivePage.at(-1);
            const initialPage = latestStreamedNotes.length && !currentSnapshot.relayContinuation && canReadHomeFeedFromRelays()
              ? { ...currentSnapshot, relayContinuation: { cursor: null, hasMore: true, noteCount: 0 } }
              : currentSnapshot;
            deps.setProfilePage(withProfileRootContinuation(initialPage, {
              rootNhash,
              cursor: boundary
                ? { createdAt: boundary.created_at, eventId: boundary.id }
                : null,
              hasMore: (indexedNotes !== undefined && !indexFinished) || archivePage.length >= deps.getProfileNoteFetchLimit(),
              noteCount: archivePage.length,
            }));
          }
        }

        if (latestVisibleNotes.length > 0) {
          const engagementNoteIds = latestVisibleNotes
            .slice(0, deps.getProfileNoteFetchLimit())
            .map(getNoteEngagementTargetId);
          void deps.hydrateNoteEngagements(
            getProfileEngagementRoots(currentRoot, deps.getProfilePersonalRoot()),
            engagementNoteIds,
            token,
          );
        }
      } catch (error) {
        console.warn('Failed to progressively load profile notes', error);
        if (
          token === deps.getLoadToken()
          && requestId === deps.getProfileNotesRequestId()
          && !(deps.getProfilePage()?.notes.length ?? 0)
        ) {
          deps.setPageError(deps.reportError("Couldn't load posts right now.", error));
        }
      } finally {
        if (token === deps.getLoadToken() && requestId === deps.getProfileNotesRequestId()) {
          deps.setProfileNotesLoading(false);
        }
      }
    },

    async hydrateProfileNotesPage(
      currentRoot: CID,
      pubkey: string,
      token: number,
      options: {
        visibleThreshold?: number;
        onVisibleReady?: () => void;
      } = {},
    ): Promise<void> {
      const requestId = deps.incrementProfileNotesRequestId();
      const rootNhash = getRootNhash(currentRoot);

      try {
        const directNotes = await loadProfileNotes(currentRoot, pubkey, deps.getProfileNoteFetchLimit());
        if (token !== deps.getLoadToken() || requestId !== deps.getProfileNotesRequestId()) {
          return;
        }

        const mergedNotes = mergeNotesByNewest(deps.getProfilePage()?.notes ?? [], directNotes);
        const latestVisibleNotes = deps.mergeLocalVisibleNotes(mergedNotes, pubkey);
        deps.cacheKnownNotes(mergedNotes);
        const snapshot: ProfileSnapshot = {
          ...deps.getProfilePage(),
          rootNhash,
          profile: deps.getProfilePage()?.profile ?? deps.getAccountProfiles().get(pubkey) ?? null,
          notes: mergedNotes,
        };
        const boundary = directNotes.at(-1);
        deps.setProfilePage(withProfileRootContinuation(snapshot, {
          rootNhash,
          cursor: boundary
            ? { createdAt: boundary.created_at, eventId: boundary.id }
            : null,
          hasMore: directNotes.length >= deps.getProfileNoteFetchLimit(),
          noteCount: directNotes.length,
        }));
        deps.seedEmptyEngagements(latestVisibleNotes.map(getNoteEngagementTargetId));
        if (latestVisibleNotes.length > 0) {
          deps.setProfileEmptyRetryKey(null);
        }
        if (!options.visibleThreshold || latestVisibleNotes.length >= options.visibleThreshold) {
          options.onVisibleReady?.();
        }

        if (latestVisibleNotes.length > 0) {
          void deps.hydrateNoteEngagements(
            getProfileEngagementRoots(currentRoot, deps.getProfilePersonalRoot()),
            latestVisibleNotes.map(getNoteEngagementTargetId),
            token,
          );
        }

        await mergePersonalProfileNotesPage(currentRoot, pubkey, token, requestId);
      } catch (error) {
        console.warn('Failed to directly load profile notes page', error);
        if (
          token === deps.getLoadToken()
          && requestId === deps.getProfileNotesRequestId()
          && !(deps.getProfilePage()?.notes.length ?? 0)
        ) {
          deps.setPageError(deps.reportError("Couldn't load posts right now.", error));
        }
      } finally {
        if (token === deps.getLoadToken() && requestId === deps.getProfileNotesRequestId()) {
          deps.setProfileNotesLoading(false);
        }
      }
    },

    async hydrateNextProfileNotesPage(
      currentRoot: CID,
      pubkey: string,
      token: number,
      options: {
        matchesVisibleSection: (event: RawEvent) => boolean;
        pageSize: number;
      },
    ): Promise<void> {
      const requestId = deps.incrementProfileNotesRequestId();
      const rootNhash = getRootNhash(currentRoot);
      const initialSnapshot = deps.getProfilePage();
      if (!initialSnapshot || initialSnapshot.rootNhash !== rootNhash) {
        await this.hydrateProfileNotesProgressively(currentRoot, pubkey, token);
        return;
      }

      try {
        const result = await appendNextProfileNotesPages({
          currentRoot,
          personalRoot: deps.getProfilePersonalRoot(),
          pubkey,
          pageSize: options.pageSize,
          maxRounds: maxContinuationPagesPerLoad,
          matchesVisibleSection: options.matchesVisibleSection,
          initialSnapshot,
          isCurrent: () => isCurrentProfileRequest(token, requestId),
          getSnapshot: deps.getProfilePage,
          setSnapshot: deps.setProfilePage,
          cacheKnownNotes: deps.cacheKnownNotes,
          mergeLocalVisibleNotes: deps.mergeLocalVisibleNotes,
          clearEmptyRetry: () => deps.setProfileEmptyRetryKey(null),
          loadPage: loadNextProfileNotesPage,
          loadArchiveHead: (pageRoot, limit, signal) => readProfilePage(pageRoot, pubkey, limit, undefined, 'archive', signal),
          loadRelayPage: canReadHomeFeedFromRelays()
            ? (limit, before, signal) => profileRelayPages.load(pubkey, limit, before, signal)
            : undefined,
        });
        if (result.needsInitialLoad) {
          await this.hydrateProfileNotesProgressively(currentRoot, pubkey, token);
          return;
        }
        if (result.stale) {
          return;
        }
        if (result.appended.length > 0) {
          deps.seedEmptyEngagements(result.appended.map(getNoteEngagementTargetId));
          void deps.hydrateNoteEngagements(
            getProfileEngagementRoots(currentRoot, deps.getProfilePersonalRoot()),
            result.appended.map(getNoteEngagementTargetId),
            token,
          );
        }
        if (result.error && isCurrentProfileRequest(token, requestId)) {
          console.warn('Failed to append the next indexed profile notes page', result.error);
        }
      } catch (error) {
        console.warn('Failed to append the next indexed profile notes page', error);
      } finally {
        if (token === deps.getLoadToken() && requestId === deps.getProfileNotesRequestId()) {
          deps.setProfileNotesLoading(false);
        }
      }
    },
  };
}
