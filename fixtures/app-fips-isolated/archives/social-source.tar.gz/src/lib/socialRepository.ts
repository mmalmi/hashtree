import type { RawEvent } from './nostr';

const KIND_EVENT_DELETION = 5;
const PERSISTED_STATE_VERSION = 1;

export type SocialEventStatus = 'visible' | 'deleted' | 'superseded' | 'deletion';

export type SocialEventFilter = {
  ids?: readonly string[];
  authors?: readonly string[];
  kinds?: readonly number[];
  since?: number;
  until?: number;
  tags?: Readonly<Record<string, readonly string[]>>;
  includeDeletionEvents?: boolean;
  limit?: number;
};

export type SocialEventTombstone = {
  targetType: 'event' | 'address';
  target: string;
  pubkey: string;
  createdAt: number;
  deletionEventId: string;
};

export type SocialRepositorySnapshot = {
  version: number;
  events: RawEvent[];
  tombstones: SocialEventTombstone[];
};

export type PersistedSocialRepositoryState = {
  schemaVersion: typeof PERSISTED_STATE_VERSION;
  overlayEvents: RawEvent[];
};

export type SocialRepositoryMutation = {
  changed: boolean;
  version: number;
  storedEventCount: number;
  visibleEventCount: number;
};

type RepositoryProjection = {
  allById: Map<string, RawEvent>;
  visibleById: Map<string, RawEvent>;
  statusById: Map<string, SocialEventStatus>;
  winnerByCoordinate: Map<string, RawEvent>;
  exactDeletions: Map<string, Map<string, RawEvent>>;
  addressDeletions: Map<string, RawEvent>;
  tombstones: SocialEventTombstone[];
};

type CompiledSocialEventFilter = {
  ids: Set<string> | null;
  authors: Set<string> | null;
  kinds: Set<number> | null;
  since?: number;
  until?: number;
  tags: Array<[string, Set<string>]>;
};

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function eventKey(eventId: string): string {
  return eventId.toLowerCase();
}

function authorKey(pubkey: string): string {
  return pubkey.toLowerCase();
}

function cloneEvent(event: RawEvent): RawEvent {
  return {
    ...event,
    tags: event.tags.map((tag) => [...tag]),
  };
}

/** Stable display/query ordering: newest first, then lexically lowest id. */
export function compareSocialEventsNewestFirst(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || compareText(left.id, right.id);
}

/** NIP-01 replaceable winner: newest timestamp, then lexically lowest id. */
export function isNewerReplaceableEvent(candidate: RawEvent, existing: RawEvent): boolean {
  return candidate.created_at > existing.created_at
    || (candidate.created_at === existing.created_at && compareText(candidate.id, existing.id) < 0);
}

export function isReplaceableEventKind(kind: number): boolean {
  return kind === 0 || kind === 3 || (kind >= 10_000 && kind < 20_000);
}

export function isAddressableEventKind(kind: number): boolean {
  return kind >= 30_000 && kind < 40_000;
}

export function isEphemeralEventKind(kind: number): boolean {
  return kind >= 20_000 && kind < 30_000;
}

function getDTag(event: RawEvent): string {
  return event.tags.find((tag) => tag[0] === 'd' && typeof tag[1] === 'string')?.[1] ?? '';
}

/** Returns the stable replaceable/addressable coordinate for an event. */
export function getSocialEventCoordinate(event: RawEvent): string | null {
  const pubkey = authorKey(event.pubkey);
  if (isReplaceableEventKind(event.kind)) {
    return `${event.kind}:${pubkey}:`;
  }
  if (isAddressableEventKind(event.kind)) {
    return `${event.kind}:${pubkey}:${getDTag(event)}`;
  }
  return null;
}

function normalizeCoordinate(value: string): { coordinate: string; pubkey: string } | null {
  const firstSeparator = value.indexOf(':');
  const secondSeparator = value.indexOf(':', firstSeparator + 1);
  if (firstSeparator <= 0 || secondSeparator < 0) {
    return null;
  }

  const kind = Number(value.slice(0, firstSeparator));
  const pubkey = authorKey(value.slice(firstSeparator + 1, secondSeparator));
  if (!Number.isInteger(kind) || kind < 0 || !pubkey) {
    return null;
  }
  if (!isReplaceableEventKind(kind) && !isAddressableEventKind(kind)) {
    return null;
  }

  return {
    coordinate: `${kind}:${pubkey}:${value.slice(secondSeparator + 1)}`,
    pubkey,
  };
}

function eventMap(events: Iterable<RawEvent>, cloneEntries = true): Map<string, RawEvent> {
  const result = new Map<string, RawEvent>();
  for (const event of events) {
    const key = eventKey(event.id);
    if (!result.has(key)) {
      result.set(key, cloneEntries ? cloneEvent(event) : event);
    }
  }
  return result;
}

function chooseDeletionWinner(candidate: RawEvent, existing: RawEvent | undefined): RawEvent {
  return !existing || isNewerReplaceableEvent(candidate, existing) ? candidate : existing;
}

function buildProjection(
  snapshotEvents: Map<string, RawEvent>,
  overlayEvents: Map<string, RawEvent>,
): RepositoryProjection {
  const allById = new Map(snapshotEvents);
  for (const [id, event] of overlayEvents) {
    if (!allById.has(id)) {
      allById.set(id, event);
    }
  }

  const exactDeletions = new Map<string, Map<string, RawEvent>>();
  const addressDeletions = new Map<string, RawEvent>();
  const tombstones: SocialEventTombstone[] = [];
  const statusById = new Map<string, SocialEventStatus>();

  for (const event of allById.values()) {
    if (event.kind !== KIND_EVENT_DELETION) {
      continue;
    }

    statusById.set(eventKey(event.id), 'deletion');
    const deletionAuthor = authorKey(event.pubkey);
    for (const tag of event.tags) {
      if (tag[0] === 'e' && tag[1]) {
        const target = eventKey(tag[1]);
        const deletionsByAuthor = exactDeletions.get(target) ?? new Map<string, RawEvent>();
        deletionsByAuthor.set(
          deletionAuthor,
          chooseDeletionWinner(event, deletionsByAuthor.get(deletionAuthor)),
        );
        exactDeletions.set(target, deletionsByAuthor);
        tombstones.push({
          targetType: 'event',
          target,
          pubkey: deletionAuthor,
          createdAt: event.created_at,
          deletionEventId: event.id,
        });
        continue;
      }

      if (tag[0] !== 'a' || !tag[1]) {
        continue;
      }
      const target = normalizeCoordinate(tag[1]);
      if (!target || target.pubkey !== deletionAuthor) {
        continue;
      }

      addressDeletions.set(
        target.coordinate,
        chooseDeletionWinner(event, addressDeletions.get(target.coordinate)),
      );
      tombstones.push({
        targetType: 'address',
        target: target.coordinate,
        pubkey: deletionAuthor,
        createdAt: event.created_at,
        deletionEventId: event.id,
      });
    }
  }

  const visibleById = new Map<string, RawEvent>();
  const winnerByCoordinate = new Map<string, RawEvent>();
  for (const event of allById.values()) {
    if (event.kind === KIND_EVENT_DELETION) {
      continue;
    }

    const id = eventKey(event.id);
    const ownExactDeletion = exactDeletions.get(id)?.get(authorKey(event.pubkey));
    const coordinate = getSocialEventCoordinate(event);
    const addressDeletion = coordinate ? addressDeletions.get(coordinate) : undefined;
    if (ownExactDeletion || (addressDeletion && event.created_at <= addressDeletion.created_at)) {
      statusById.set(id, 'deleted');
      continue;
    }

    if (!coordinate) {
      visibleById.set(id, event);
      statusById.set(id, 'visible');
      continue;
    }

    const existing = winnerByCoordinate.get(coordinate);
    if (!existing) {
      winnerByCoordinate.set(coordinate, event);
      continue;
    }

    if (isNewerReplaceableEvent(event, existing)) {
      statusById.set(eventKey(existing.id), 'superseded');
      winnerByCoordinate.set(coordinate, event);
    } else {
      statusById.set(id, 'superseded');
    }
  }

  for (const event of winnerByCoordinate.values()) {
    const id = eventKey(event.id);
    visibleById.set(id, event);
    statusById.set(id, 'visible');
  }

  tombstones.sort((left, right) => (
    compareText(left.targetType, right.targetType)
    || compareText(left.target, right.target)
    || right.createdAt - left.createdAt
    || compareText(left.deletionEventId, right.deletionEventId)
  ));

  return {
    allById,
    visibleById,
    statusById,
    winnerByCoordinate,
    exactDeletions,
    addressDeletions,
    tombstones,
  };
}

function compileFilter(filter: SocialEventFilter): CompiledSocialEventFilter {
  return {
    ids: filter.ids ? new Set(filter.ids.map(eventKey)) : null,
    authors: filter.authors ? new Set(filter.authors.map(authorKey)) : null,
    kinds: filter.kinds ? new Set(filter.kinds) : null,
    since: filter.since,
    until: filter.until,
    tags: Object.entries(filter.tags ?? {}).map(([tagName, values]) => [tagName, new Set(values)]),
  };
}

function eventMatchesFilter(event: RawEvent, filter: CompiledSocialEventFilter): boolean {
  if (filter.ids && !filter.ids.has(eventKey(event.id))) {
    return false;
  }
  if (filter.authors && !filter.authors.has(authorKey(event.pubkey))) {
    return false;
  }
  if (filter.kinds && !filter.kinds.has(event.kind)) {
    return false;
  }
  if (filter.since !== undefined && event.created_at < filter.since) {
    return false;
  }
  if (filter.until !== undefined && event.created_at > filter.until) {
    return false;
  }

  for (const [tagName, values] of filter.tags) {
    if (!event.tags.some((tag) => tag[0] === tagName && tag[1] !== undefined && values.has(tag[1]))) {
      return false;
    }
  }
  return true;
}

export class SocialEventRepository {
  private snapshotEvents = new Map<string, RawEvent>();
  private overlayEvents = new Map<string, RawEvent>();
  private projection = buildProjection(this.snapshotEvents, this.overlayEvents);
  private listeners = new Set<(snapshot: SocialRepositorySnapshot) => void>();
  private revision = 0;

  constructor(options: {
    snapshotEvents?: Iterable<RawEvent>;
    persistedState?: PersistedSocialRepositoryState;
  } = {}) {
    if (options.snapshotEvents) {
      this.snapshotEvents = eventMap(options.snapshotEvents);
    }
    if (options.persistedState) {
      this.overlayEvents = this.readPersistedState(options.persistedState);
    }
    this.projection = buildProjection(this.snapshotEvents, this.overlayEvents);
  }

  get version(): number {
    return this.revision;
  }

  replaceSnapshot(events: Iterable<RawEvent>): SocialRepositoryMutation {
    this.snapshotEvents = eventMap(events);
    return this.rebuild(true);
  }

  ingestOverlay(events: Iterable<RawEvent>): SocialRepositoryMutation {
    let changed = false;
    for (const event of events) {
      const id = eventKey(event.id);
      if (this.overlayEvents.has(id)) {
        continue;
      }
      this.overlayEvents.set(id, cloneEvent(event));
      changed = true;
    }
    return this.rebuild(changed);
  }

  /**
   * Commit a bounded overlay batch with one projection rebuild. Protected
   * entries may temporarily keep the overlay above the requested maximum.
   */
  ingestBoundedOverlay(
    events: Iterable<RawEvent>,
    maximum: number,
    protectedEventIds: Iterable<string> = [],
  ): SocialRepositoryMutation {
    let changed = false;
    for (const event of events) {
      const id = eventKey(event.id);
      if (this.overlayEvents.has(id)) {
        continue;
      }
      this.overlayEvents.set(id, cloneEvent(event));
      changed = true;
    }
    const protectedIds = new Set([...protectedEventIds].map(eventKey));
    let excess = this.overlayEvents.size - Math.max(0, Math.trunc(maximum));
    if (excess > 0) {
      const ordered = [...this.overlayEvents.values()].sort(compareSocialEventsNewestFirst);
      for (let index = ordered.length - 1; index >= 0 && excess > 0; index -= 1) {
        const eventId = eventKey(ordered[index]!.id);
        if (protectedIds.has(eventId)) {
          continue;
        }
        changed = this.overlayEvents.delete(eventId) || changed;
        excess -= 1;
      }
    }
    return this.rebuild(changed);
  }

  ingestEvent(event: RawEvent): SocialRepositoryMutation {
    return this.ingestOverlay([event]);
  }

  removeOverlayEvents(eventIds: Iterable<string>): SocialRepositoryMutation {
    let changed = false;
    for (const eventId of eventIds) {
      changed = this.overlayEvents.delete(eventKey(eventId)) || changed;
    }
    return this.rebuild(changed);
  }

  clearOverlay(): SocialRepositoryMutation {
    const changed = this.overlayEvents.size > 0;
    this.overlayEvents.clear();
    return this.rebuild(changed);
  }

  /** Drop overlay copies that have reached the durable snapshot. */
  pruneOverlayContainedInSnapshot(): SocialRepositoryMutation {
    let changed = false;
    for (const id of this.snapshotEvents.keys()) {
      changed = this.overlayEvents.delete(id) || changed;
    }
    return this.rebuild(changed);
  }

  restoreOverlayState(state: PersistedSocialRepositoryState): SocialRepositoryMutation {
    this.overlayEvents = this.readPersistedState(state);
    return this.rebuild(true);
  }

  exportOverlayState(options: { protectedEventIds?: Iterable<string> } = {}): PersistedSocialRepositoryState {
    const protectedEventIds = new Set(
      [...(options.protectedEventIds ?? [])].map(eventKey),
    );
    return {
      schemaVersion: PERSISTED_STATE_VERSION,
      overlayEvents: [...this.overlayEvents.values()]
        .filter((event) => (
          !isEphemeralEventKind(event.kind) || protectedEventIds.has(eventKey(event.id))
        ))
        .sort(compareSocialEventsNewestFirst)
        .map(cloneEvent),
    };
  }

  /**
   * Prepare the display-cache snapshot without monopolizing the renderer.
   * The caller owns the work budget so preparation and serialization share
   * one yield cadence.
   */
  async exportOverlayStateCooperatively(options: {
    isProtectedEventId: (eventId: string) => boolean;
    context: {
      run<T>(work: () => T): Promise<T>;
      isCurrent(): boolean;
    };
  }): Promise<PersistedSocialRepositoryState | null> {
    const overlayEvents: RawEvent[] = [];
    for (const event of this.overlayEvents.values()) {
      if (!options.context.isCurrent()) {
        return null;
      }
      const cloned = await options.context.run(() => (
        !isEphemeralEventKind(event.kind) || options.isProtectedEventId(event.id)
          ? cloneEvent(event)
          : null
      ));
      if (cloned) {
        overlayEvents.push(cloned);
      }
    }
    if (!options.context.isCurrent()) {
      return null;
    }
    await options.context.run(() => {
      overlayEvents.sort(compareSocialEventsNewestFirst);
    });
    return {
      schemaVersion: PERSISTED_STATE_VERSION,
      overlayEvents,
    };
  }

  getOverlayEvents(options: { includeEphemeral?: boolean } = {}): RawEvent[] {
    return [...this.overlayEvents.values()]
      .filter((event) => options.includeEphemeral !== false || !isEphemeralEventKind(event.kind))
      .sort(compareSocialEventsNewestFirst);
  }

  getEvent(eventId: string): RawEvent | null {
    return this.projection.visibleById.get(eventKey(eventId)) ?? null;
  }

  getStoredEvent(eventId: string): RawEvent | null {
    return this.projection.allById.get(eventKey(eventId)) ?? null;
  }

  getEventStatus(eventId: string): SocialEventStatus | null {
    return this.projection.statusById.get(eventKey(eventId)) ?? null;
  }

  getEventByCoordinate(coordinate: string): RawEvent | null {
    const normalized = normalizeCoordinate(coordinate);
    return normalized ? this.projection.winnerByCoordinate.get(normalized.coordinate) ?? null : null;
  }

  /**
   * Project durable/cache-owned events against the live overlay without cloning
   * them. Callers that retain event identity (for example route caches) can
   * therefore apply deletion and replacement rules without allocating a new
   * event graph.
   */
  filterVisibleExternalEvents(
    events: readonly RawEvent[],
    filter: SocialEventFilter = {},
  ): RawEvent[] {
    const uniqueEvents = eventMap(events, false);
    const visibleEvents: RawEvent[] = [];
    const winnerByCoordinate = new Map<string, RawEvent>();
    const exactDeletions = new Map<string, Map<string, RawEvent>>();
    const addressDeletions = new Map<string, RawEvent>();

    for (const event of uniqueEvents.values()) {
      if (event.kind !== KIND_EVENT_DELETION) {
        continue;
      }

      const deletionAuthor = authorKey(event.pubkey);
      for (const tag of event.tags) {
        if (tag[0] === 'e' && tag[1]) {
          const target = eventKey(tag[1]);
          const deletionsByAuthor = exactDeletions.get(target) ?? new Map<string, RawEvent>();
          deletionsByAuthor.set(
            deletionAuthor,
            chooseDeletionWinner(event, deletionsByAuthor.get(deletionAuthor)),
          );
          exactDeletions.set(target, deletionsByAuthor);
          continue;
        }

        if (tag[0] !== 'a' || !tag[1]) {
          continue;
        }
        const target = normalizeCoordinate(tag[1]);
        if (!target || target.pubkey !== deletionAuthor) {
          continue;
        }
        addressDeletions.set(
          target.coordinate,
          chooseDeletionWinner(event, addressDeletions.get(target.coordinate)),
        );
      }
    }

    for (const event of uniqueEvents.values()) {
      if (event.kind === KIND_EVENT_DELETION) {
        if (filter.includeDeletionEvents) {
          visibleEvents.push(event);
        }
        continue;
      }
      const id = eventKey(event.id);
      if (exactDeletions.get(id)?.has(authorKey(event.pubkey))) {
        continue;
      }
      const coordinate = getSocialEventCoordinate(event);
      const addressDeletion = coordinate ? addressDeletions.get(coordinate) : undefined;
      if (addressDeletion && event.created_at <= addressDeletion.created_at) {
        continue;
      }
      if (!this.isExternalEventVisible(event)) {
        continue;
      }
      if (!coordinate) {
        visibleEvents.push(event);
        continue;
      }
      const existing = winnerByCoordinate.get(coordinate);
      if (!existing || isNewerReplaceableEvent(event, existing)) {
        winnerByCoordinate.set(coordinate, event);
      }
    }

    visibleEvents.push(...winnerByCoordinate.values());
    const compiledFilter = compileFilter(filter);
    return visibleEvents
      .filter((event) => eventMatchesFilter(event, compiledFilter))
      .sort(compareSocialEventsNewestFirst);
  }

  isExternalEventVisible(event: RawEvent): boolean {
    const id = eventKey(event.id);
    const storedStatus = this.projection.statusById.get(id);
    if (storedStatus) {
      return storedStatus === 'visible';
    }
    if (event.kind === KIND_EVENT_DELETION) {
      return false;
    }

    const author = authorKey(event.pubkey);
    if (this.projection.exactDeletions.get(id)?.has(author)) {
      return false;
    }

    const coordinate = getSocialEventCoordinate(event);
    if (!coordinate) {
      return true;
    }
    const addressDeletion = this.projection.addressDeletions.get(coordinate);
    if (addressDeletion && event.created_at <= addressDeletion.created_at) {
      return false;
    }
    const overlayWinner = this.projection.winnerByCoordinate.get(coordinate);
    return !overlayWinner || !isNewerReplaceableEvent(overlayWinner, event);
  }

  getEvents(filter: SocialEventFilter = {}): RawEvent[] {
    const candidates = [...this.projection.visibleById.values()];
    if (filter.includeDeletionEvents) {
      for (const event of this.projection.allById.values()) {
        if (event.kind === KIND_EVENT_DELETION) {
          candidates.push(event);
        }
      }
    }

    const compiledFilter = compileFilter(filter);
    const events = candidates
      .filter((event) => eventMatchesFilter(event, compiledFilter))
      .sort(compareSocialEventsNewestFirst);
    return filter.limit === undefined ? events : events.slice(0, Math.max(0, filter.limit));
  }

  getSnapshot(): SocialRepositorySnapshot {
    return {
      version: this.revision,
      events: this.getEvents().map(cloneEvent),
      tombstones: this.getTombstones(),
    };
  }

  getTombstones(): SocialEventTombstone[] {
    return this.projection.tombstones.map((tombstone) => ({ ...tombstone }));
  }

  subscribe(listener: (snapshot: SocialRepositorySnapshot) => void): () => void {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private readPersistedState(state: PersistedSocialRepositoryState): Map<string, RawEvent> {
    if (state.schemaVersion !== PERSISTED_STATE_VERSION || !Array.isArray(state.overlayEvents)) {
      throw new Error('Unsupported persisted social repository state');
    }
    return eventMap(state.overlayEvents);
  }

  private rebuild(changed: boolean): SocialRepositoryMutation {
    if (changed) {
      this.projection = buildProjection(this.snapshotEvents, this.overlayEvents);
      this.revision += 1;
      if (this.listeners.size > 0) {
        const snapshot = this.getSnapshot();
        for (const listener of this.listeners) {
          listener(snapshot);
        }
      }
    }

    return {
      changed,
      version: this.revision,
      storedEventCount: this.projection.allById.size,
      visibleEventCount: this.projection.visibleById.size,
    };
  }
}

/** Merge active snapshot/overlay result sets using repository visibility rules. */
export function mergeSocialEventsByNewest(...eventLists: RawEvent[][]): RawEvent[] {
  return new SocialEventRepository({ snapshotEvents: eventLists.flat() }).getEvents();
}
