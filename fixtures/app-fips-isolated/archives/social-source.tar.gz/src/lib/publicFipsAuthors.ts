import { verifyNostrEvent, type NostrEvent } from 'nostr-pubsub';

const verifiedFollows = new WeakMap<NostrEvent, readonly string[]>();

/** Only a verified, current public follow list may expand the live endpoint's
 * public-author policy. Private contacts are not an input to this function. */
export function publicFipsAuthors(owner: string | null, contacts: NostrEvent | undefined,
  publicGraphAuthors: () => readonly string[]): string[] {
  if (!owner) { return [...publicGraphAuthors()]; }
  if (!contacts) { return [...new Set([owner, ...publicGraphAuthors()])]; }
  if (contacts.kind !== 3 || contacts.pubkey !== owner) { return [owner]; }
  let follows = verifiedFollows.get(contacts);
  if (!follows) {
    try {
      const event = verifyNostrEvent(contacts);
      follows = event.tags.filter(tag => tag[0] === 'p' && /^[0-9a-f]{64}$/.test(tag[1] ?? '')).map(tag => tag[1]);
    } catch { follows = []; }
    verifiedFollows.set(contacts, follows);
  }
  return [...new Set([owner, ...follows])];
}
