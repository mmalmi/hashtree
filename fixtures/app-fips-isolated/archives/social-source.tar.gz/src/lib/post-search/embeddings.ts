import type { Tokenizer } from '@huggingface/tokenizers';
import { InferenceSession, Tensor } from 'onnxruntime-web/wasm';

export async function embed(
  model: InferenceSession,
  tokenizer: Tokenizer,
  text: string,
): Promise<Float32Array> {
  const [vector] = await embedBatch(model, tokenizer, [text]);
  return vector!;
}

export async function embedBatch(
  model: InferenceSession,
  tokenizer: Tokenizer,
  texts: readonly string[],
  TensorClass: typeof Tensor = Tensor,
): Promise<Float32Array[]> {
  if (!texts.length) { return []; }
  const rows = texts.map((text) => {
    const { ids } = tokenizer.encode(text);
    // Keep the final separator at the model's 128-token limit.
    if (ids.length > 128) { ids.splice(127, ids.length - 128); }
    return ids;
  });
  const width = Math.max(...rows.map((row) => row.length));
  const total = rows.length * width;
  const ids = new BigInt64Array(total);
  const mask = new BigInt64Array(total);
  for (let rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
    const row = rows[rowIndex]!;
    const base = rowIndex * width;
    for (let col = 0; col < row.length; col += 1) {
      ids[base + col] = BigInt(row[col]!);
    }
    mask.fill(1n, base, base + row.length);
  }
  const dims = [rows.length, width];
  const inputs = {
    input_ids: new TensorClass('int64', ids, dims),
    attention_mask: new TensorClass('int64', mask, dims),
    token_type_ids: new TensorClass('int64', new BigInt64Array(total), dims),
  };
  try {
    const outputs = await model.run(inputs);
    try {
      const hidden = outputs.last_hidden_state!;
      const size = hidden.dims[2]!;
      const data = hidden.data as Float32Array;
      return rows.map((row, rowIndex) => {
        const pooled = new Float32Array(size);
        const rowOffset = rowIndex * width * size;
        for (let tokenIndex = 0; tokenIndex < row.length; tokenIndex += 1) {
          const base = rowOffset + tokenIndex * size;
          for (let dim = 0; dim < size; dim += 1) {
            pooled[dim] = pooled[dim]! + Number(data[base + dim]);
          }
        }
        let sumSq = 0;
        for (let dim = 0; dim < size; dim += 1) {
          sumSq += pooled[dim]! * pooled[dim]!;
        }
        const invNorm = sumSq > 0 ? 1 / Math.sqrt(sumSq) : 0;
        for (let dim = 0; dim < size; dim += 1) {
          pooled[dim] = pooled[dim]! * invNorm;
        }
        return pooled;
      });
    } finally {
      Object.values(outputs).forEach((tensor) => tensor.dispose());
    }
  } finally {
    Object.values(inputs).forEach((tensor) => tensor.dispose());
  }
}

export function similarity(left: Float32Array, right: Float32Array): number {
  let dot = 0;
  for (let index = 0; index < left.length; index += 1) {
    dot += left[index]! * right[index]!;
  }
  return Math.max(0, Math.min(1, dot));
}
