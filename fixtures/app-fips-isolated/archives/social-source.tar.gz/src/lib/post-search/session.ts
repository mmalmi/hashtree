import type { RawEvent } from '../nostr';
import {
  getLoadedSocialGraphAuthorInfo,
  subscribeLocalSocialGraphChanges,
  warmLocalSocialGraph,
} from '../socialGraph';
import { PostSearchRelevanceController, type SemanticSearchSnapshot } from './controller';
import { searchExpandedPosts } from './expansion';
import { planPostSearch } from './query';
import { authorSignal } from './ranking';
import type { SearchSettings } from './scorer';

export type PostSearchAiSessionState = {
  enabled: boolean;
  ordered: RawEvent[];
  status: string;
  busy: boolean;
  scoredCount: number;
  expandedEvents: RawEvent[];
};

export type PostSearchAiSessionInput = {
  active: boolean;
  query: string;
  aiEnabled: boolean;
  settings: SearchSettings;
  allowRelayExpansion: boolean;
  candidates: readonly RawEvent[];
};

const EMPTY_STATE: PostSearchAiSessionState = {
  enabled: false,
  ordered: [],
  status: '',
  busy: false,
  scoredCount: 0,
  expandedEvents: [],
};

/**
 * Bridges reactive UI state with the on-device AI relevance controller,
 * social-graph warmup, and post-submission relay expansion.
 */
export class PostSearchAiSession {
  private activeQuery = '';
  private activeEnabled = false;
  private allowRelayExpansion = false;
  private baseCandidates: RawEvent[] = [];
  private expandedById = new Map<string, RawEvent>();
  private pendingExpansion: { query: string; terms: string[]; tags: string[] } | null = null;
  private launchedExpansionKey = '';
  private expansionController: AbortController | null = null;
  private stopGraphSub: (() => void) | null = null;
  private readonly relevance: PostSearchRelevanceController;
  private snapshot: SemanticSearchSnapshot = {
    ordered: [],
    primary: [],
    status: '',
    busy: false,
    relatedTerms: [],
    relatedTags: [],
    scoredCount: 0,
  };

  constructor(private readonly onChange: (state: PostSearchAiSessionState) => void) {
    this.relevance = new PostSearchRelevanceController({
      getAuthorSignal: (pubkey) => {
        const info = getLoadedSocialGraphAuthorInfo(pubkey);
        return info ? authorSignal(info.distance, info.followers) : 0;
      },
      getKnownTags: () => this.collectKnownTags(),
      onChange: (next) => {
        this.snapshot = next;
        this.emit();
      },
      onExpansion: (expansion) => {
        if (expansion.query !== this.activeQuery) { return; }
        this.pendingExpansion = expansion;
        this.maybeRunExpansion();
      },
    });
  }

  update(input: PostSearchAiSessionInput): void {
    const query = input.query.trim();
    const enabled = input.active && input.aiEnabled && query.length >= 2;
    if (this.allowRelayExpansion && !input.allowRelayExpansion) {
      this.abortExpansion();
      this.launchedExpansionKey = '';
    }
    this.allowRelayExpansion = input.allowRelayExpansion;

    if (!enabled) {
      if (this.activeEnabled || this.activeQuery) {
        this.reset();
        this.onChange(EMPTY_STATE);
      }
      return;
    }

    if (!this.stopGraphSub) {
      void warmLocalSocialGraph();
      this.stopGraphSub = subscribeLocalSocialGraphChanges(() => {
        this.relevance.refreshRanking();
      });
    }

    if (query !== this.activeQuery || !this.activeEnabled) {
      this.abortExpansion();
      this.expandedById.clear();
      this.pendingExpansion = null;
      this.launchedExpansionKey = '';
      this.activeQuery = query;
      this.activeEnabled = true;
    }

    this.baseCandidates = dedupeEvents(input.candidates);
    this.relevance.configure(query, input.settings);
    this.relevance.setCandidates(this.combinedCandidates());
    this.maybeRunExpansion();
  }

  increaseBudget(): void {
    if (this.activeEnabled) {
      this.relevance.increaseBudget();
    }
  }

  destroy(): void {
    this.reset();
  }

  private reset(): void {
    this.stopGraphSub?.();
    this.stopGraphSub = null;
    this.abortExpansion();
    this.relevance.stop();
    this.relevance.configure('', null);
    this.activeQuery = '';
    this.activeEnabled = false;
    this.baseCandidates = [];
    this.expandedById.clear();
    this.pendingExpansion = null;
    this.launchedExpansionKey = '';
  }

  private abortExpansion(): void {
    this.expansionController?.abort();
    this.expansionController = null;
  }

  private collectKnownTags(): string[] {
    const tags = new Set<string>();
    for (const event of this.combinedCandidates().slice(0, 128)) {
      for (const [name, value] of event.tags.slice(0, 16)) {
        if (name === 't' && value) { tags.add(value); }
        if (tags.size >= 96) { return [...tags]; }
      }
    }
    return [...tags];
  }

  private combinedCandidates(): RawEvent[] {
    if (this.expandedById.size === 0) { return this.baseCandidates; }
    return dedupeEvents([...this.baseCandidates, ...this.expandedById.values()]);
  }

  private maybeRunExpansion(): void {
    if (!this.activeEnabled || !this.allowRelayExpansion || !this.activeQuery) { return; }
    const plan = planPostSearch(this.activeQuery);
    const terms = this.pendingExpansion?.query === this.activeQuery ? this.pendingExpansion.terms : [];
    const modelTags = this.pendingExpansion?.query === this.activeQuery ? this.pendingExpansion.tags : [];
    const baseTags = [...plan.hashtags, ...plan.terms.filter((term) => term.length >= 3)].slice(0, 4);
    const tags = [...new Set([...modelTags, ...baseTags])].slice(0, 8);
    if (!terms.length && !tags.length) { return; }

    const key = `${this.activeQuery}|${terms.join(',')}|${tags.join(',')}`;
    if (key === this.launchedExpansionKey) { return; }
    this.launchedExpansionKey = key;

    const controller = new AbortController();
    this.expansionController?.abort();
    this.expansionController = controller;
    const queryForRun = this.activeQuery;

    void searchExpandedPosts({
      terms,
      tags,
      signal: controller.signal,
      onEvents: (batch) => {
        if (controller.signal.aborted || queryForRun !== this.activeQuery) { return; }
        let added = false;
        for (const event of batch) {
          if (!this.expandedById.has(event.id)) {
            this.expandedById.set(event.id, event);
            added = true;
          }
        }
        if (added) {
          this.relevance.setCandidates(this.combinedCandidates());
        }
      },
    }).then((finalEvents) => {
      if (controller.signal.aborted || queryForRun !== this.activeQuery) { return; }
      let added = false;
      for (const event of finalEvents) {
        if (!this.expandedById.has(event.id)) {
          this.expandedById.set(event.id, event);
          added = true;
        }
      }
      if (added) {
        this.relevance.setCandidates(this.combinedCandidates());
      }
    }).catch(() => undefined);
  }

  private emit(): void {
    this.onChange({
      enabled: this.activeEnabled,
      ordered: this.snapshot.ordered,
      status: this.snapshot.status,
      busy: this.snapshot.busy,
      scoredCount: this.snapshot.scoredCount,
      expandedEvents: [...this.expandedById.values()],
    });
  }
}

function dedupeEvents(events: readonly RawEvent[]): RawEvent[] {
  const byId = new Map<string, RawEvent>();
  for (const event of events) {
    if (!byId.has(event.id)) { byId.set(event.id, event); }
  }
  return [...byId.values()];
}
