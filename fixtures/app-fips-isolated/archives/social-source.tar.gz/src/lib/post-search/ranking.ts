import type { RawEvent } from '../nostr';
import { words, type SearchPlan } from './query';

export { planPostSearch, type SearchPlan } from './query';

type Note = Pick<RawEvent, 'id' | 'content' | 'tags' | 'pubkey' | 'created_at'>;
const REFERENCES = /(?:nostr:)?(?:npub|nprofile|note|nevent|naddr)1[a-z0-9]+|#\[\d+\]/gi;
const LINKS = /https?:\/\/[^\s)]+/gi;
const INLINE_HASHTAG = /(?:^|\s)#([\p{L}\p{M}\p{N}_-]+)/gu;
const CONVERSATIONAL = new Set(
  'a ah awesome bro cheers cool d dude eh excellent for good great haha hey huh i interesting is it its like looks love man neat nice oh ok okay pretty really s sharing so sounds stuff such super t thank thanks that the this very wow yeah yep yes you'.split(' '),
);
const PRAISE_WORDS = new Set(['nice', 'cool', 'awesome', 'interesting', 'great']);

// Hosts and opaque attachment IDs describe storage, not the subject of a photo.
function readableLink(url: string): string {
  const path = url.split(/[?#]/, 1)[0]!;
  if (/\.(?:jpe?g|png|webp|gif|avif|heic|svg|mp4|m4v|mov|webm)$/i.test(path)) { return ''; }
  return path
    .replace(/^https?:\/\//i, '')
    .replace(/[\w-]{32,}|\b[\da-f]{12,}\b/gi, ' ')
    .replace(/[-_/]+/g, ' ')
    .trim()
    .slice(0, 140);
}

function mediaDescriptions(event: Pick<Note, 'tags'>): string[] {
  return [
    ...new Set(
      event.tags
        .slice(0, 64)
        .flatMap(([name, ...values]) => {
          if (name === 'alt' || name === 'title' || name === 'summary' || name === 'subject') {
            return values.slice(0, 1);
          }
          if (name === 'imeta') {
            return values.filter((value) => value.startsWith('alt ')).map((value) => value.slice(4));
          }
          return [];
        })
        .map((value) => value.slice(0, 240)),
    ),
  ];
}

// Long Nostr pointers and tracking parameters can consume the model's entire
// 128-token window. Keep readable link slugs for notes that just share a link.
export function searchPostText(event: Pick<Note, 'content' | 'tags'>): string {
  const content = event.content
    .slice(0, 12_000)
    .replace(REFERENCES, ' ')
    .replace(/<\/?[a-z][a-z0-9]*(?:\s[^<>]*)?\s*\/?>|&(?:#\d+|#x[\da-f]+|[a-z]{2,12});/gi, ' ')
    .replace(LINKS, readableLink);
  const present = new Set(
    Array.from(content.matchAll(INLINE_HASHTAG), (match) => match[1]!.toLowerCase()),
  );
  const parts = [content, ...mediaDescriptions(event)];
  for (const [key, value] of event.tags) {
    if (key !== 't' || !value || present.has(value.toLowerCase())) { continue; }
    parts.push(`#${value}`);
    present.add(value.toLowerCase());
  }
  return parts.join(' ').trim().slice(0, 1800);
}

function isKeywordStuffedOrHashtagOnly(event: Pick<Note, 'content' | 'tags'>): boolean {
  const stripped = event.content
    .slice(0, 4_000)
    .replace(REFERENCES, ' ')
    .replace(LINKS, ' ');
  const inlineHashtags = Array.from(stripped.matchAll(INLINE_HASHTAG), (match) => match[1]!.toLowerCase());
  const prose = stripped.replace(INLINE_HASHTAG, ' ');
  const proseWords = words(prose);
  const descriptions = mediaDescriptions(event);
  // Pure hashtag list ("#privacy", "#Bitcoin #Bitcoin ...") with no prose or media alt text.
  if (proseWords.length === 0 && descriptions.length === 0 && (inlineHashtags.length > 0 || event.tags.some((t) => t[0] === 't'))) {
    return true;
  }
  // Repeated identical hashtags (#Bitcoin #Bitcoin #Bitcoin) or keyword stuffing.
  if (inlineHashtags.length >= 3) {
    const counts = new Map<string, number>();
    for (const tag of inlineHashtags) {
      const next = (counts.get(tag) ?? 0) + 1;
      if (next >= 3) { return true; }
      counts.set(tag, next);
    }
  }
  const nonNumberWords = words(stripped).filter((token) => !/^\d+$/.test(token));
  if (nonNumberWords.length >= 3) {
    const counts = new Map<string, number>();
    for (const token of nonNumberWords) {
      counts.set(token, (counts.get(token) ?? 0) + 1);
    }
    const maxCount = Math.max(...counts.values());
    if (maxCount >= 3 && maxCount / nonNumberWords.length >= 0.45) { return true; }
  }
  return false;
}

export function postSubstanceFactor(plan: SearchPlan, event: Pick<Note, 'content' | 'tags'>): number {
  if (isKeywordStuffedOrHashtagOnly(event)) { return 0.35; }
  const stripped = event.content.slice(0, 4_000).replace(REFERENCES, ' ').replace(LINKS, ' ').replace(INLINE_HASHTAG, ' ');
  const distinctWords = new Set(words(stripped));
  const hasMediaOrLink = LINKS.test(event.content) || mediaDescriptions(event).length > 0;
  LINKS.lastIndex = 0;
  if (!hasMediaOrLink && distinctWords.size <= 2 && plan.terms.length >= 2) {
    // One- or two-word fragments ("Privacy 💯", "Coffee brewing") carry little context.
    return 0.15;
  }
  if (!hasMediaOrLink && plan.terms.length >= 2 && distinctWords.size <= plan.terms.length) {
    // Ultra-short title echo ("OPEN SOURCE HARDWARE") with no extra context.
    return 0.2;
  }
  return 1;
}

export function cachedLexicalMatch(plan: SearchPlan) {
  const cache = new WeakMap<Note, number>();
  return (event: Note): number => {
    const cached = cache.get(event);
    if (cached !== undefined) { return cached; }
    const match = lexicalMatch(plan, event);
    cache.set(event, match);
    return match;
  };
}

export function lexicalMatch(plan: SearchPlan, event: Note): number {
  const tags = new Set(
    event.tags
      .filter((tag) => tag[0] === 't' && tag[1])
      .map((tag) => tag[1]!.normalize('NFKC').toLowerCase()),
  );
  if (!plan.hashtags.every((tag) => tags.has(tag.normalize('NFKC').toLowerCase()))) { return -1; }
  if (!plan.terms.length) {
    if (plan.hashtags.length) { return 1; }
    return event.content.normalize('NFKC').includes(plan.text.normalize('NFKC')) ? 1 : 0;
  }
  if (!plan.hashtags.length && isKeywordStuffedOrHashtagOnly(event)) { return -1; }
  const described = [
    event.content.slice(0, 12_000).replace(LINKS, readableLink),
    ...mediaDescriptions(event),
  ].join(' ');
  const tokens = words(described);
  if (!tokens.length && !tags.size) { return -1; }
  if (tokens.length <= 12 && !plan.terms.every((term) => CONVERSATIONAL.has(term))) {
    const body = words(described.replace(REFERENCES, ' '));
    if (!body.length && !tags.size && !plan.terms.some((term) => tokens.includes(term))) { return -1; }
    const substance = body.filter((token) => !CONVERSATIONAL.has(token));
    if (body.length && !substance.length) { return -1; }
    if (
      substance.length === 1
      && body.some((token) => PRAISE_WORDS.has(token))
      && (!plan.terms.includes(substance[0]!) || plan.browse)
    ) { return -1; }
  }
  const inlineHashtags = Array.from(described.matchAll(INLINE_HASHTAG), (match) => match[1]!.normalize('NFKC').toLowerCase());
  const proseTokens = words(described.replace(INLINE_HASHTAG, ' '));
  const proseSet = new Set(proseTokens);
  const tagSet = new Set([...inlineHashtags, ...tags]);
  let matched = 0;
  for (const term of plan.terms) {
    if (proseSet.has(term)) {
      matched += 1;
    } else if (tagSet.has(term)) {
      // Tag-only mentions (e.g. unrelated crypto spam stuffing #bitcoin) need semantic corroboration.
      matched += 0.5;
    }
  }
  const coverage = matched / plan.terms.length;
  if (!coverage) { return 0; }
  if (plan.browse && plan.terms.length === 1) { return 0.52 * coverage; }
  const phrase = ` ${proseTokens.join(' ')} `.includes(` ${plan.phrase} `);
  return 0.9 * coverage + (phrase ? 0.1 : 0);
}

// Calibrate cosine similarity on short posts. Values near 0.2 are common
// for off-topic notes, while relevant paraphrases often score around 0.4.
export function calibratedSimilarity(cosine: number): number {
  return Math.min(1, Math.max(0, (cosine - 0.16) / 0.48));
}

// A close term in the post can corroborate a weaker whole-post embedding.
export function semanticMatch(
  cosine: number,
  content: string,
  neighbors?: ReadonlyMap<string, number>,
  broadSubject?: string,
  intentCosine?: number,
): number {
  if (!neighbors?.size) { return calibratedSimilarity(cosine); }
  const tokens = new Set(words(content));
  const evidence = Array.from(tokens, (token) => neighbors.get(token) ?? 0).sort((left, right) => right - left);
  const [first = 0, second = 0] = evidence;
  if (broadSubject && tokens.size >= 24) {
    const support = evidence.slice(0, 4).reduce((sum, value) => sum + Math.min(0.65, value), 0) / 4;
    const meaning = 0.4 * cosine + 0.6 * (intentCosine ?? cosine);
    return calibratedSimilarity(Math.max(0.8 * cosine, 0.8 * support + 0.2 * meaning));
  }
  const nearby = 0.7 * first + 0.3 * second;
  let match = Math.max(cosine, 0.8 * nearby + 0.14 * cosine);
  if (broadSubject && tokens.has(broadSubject) && nearby < 0.48) {
    match *= Math.max(0, 1 - (0.48 - nearby) / 0.48);
  }
  return calibratedSimilarity(match);
}

export function authorSignal(distance: number, followers: number): number {
  const proximity = distance >= 1000 ? 0 : 1 / Math.max(1, distance);
  return 0.65 * proximity + 0.35 * Math.min(1, Math.log1p(followers) / Math.log(101));
}

export function postRelevance(
  lexical: number,
  semantic: number | undefined,
  author: number,
  ageDays: number,
  substance = 1,
): number {
  if (lexical < 0) { return -Infinity; }
  // Before inference completes, require a strong literal match (avoid admitting
  // single-word incidental hits on multi-word queries like "nostr" for "nostr privacy").
  if (semantic === undefined) {
    if (lexical < 0.54) { return -Infinity; }
    const freshness = 1 / (1 + Math.max(0, ageDays) / 30);
    return 0.64 * lexical * substance * (0.65 + 0.28 * author + 0.07 * freshness);
  }
  // Once scored, require genuine semantic relevance or a near-complete literal
  // match with at least modest semantic corroboration.
  if (semantic < 0.42 && !(lexical >= 0.72 && semantic >= 0.25)) { return -Infinity; }
  const topical = Math.max(
    (0.25 + 0.23 * Math.min(1, semantic / 0.42)) * lexical,
    0.68 * semantic + 0.32 * lexical,
  );
  const freshness = 1 / (1 + Math.max(0, ageDays) / 30);
  return topical * substance * (0.65 + 0.28 * author + 0.07 * freshness);
}

export function rankCandidates<T extends Note>(
  candidates: ReadonlyArray<{ event: T; lexical: number; author: number; substance?: number }>,
  scores: ReadonlyMap<string, number>,
  now: number,
) {
  const ranked = candidates
    .map(({ event, lexical, author, substance }) => ({
      event,
      score: postRelevance(
        lexical,
        scores.get(event.id),
        author,
        (now - (event.created_at ?? 0)) / 86_400,
        substance ?? 1,
      ),
    }))
    .filter((row) => Number.isFinite(row.score))
    .sort((left, right) => (
      right.score - left.score
      || (right.event.created_at ?? 0) - (left.event.created_at ?? 0)
      || left.event.id.localeCompare(right.event.id)
    ));
  const primary: T[] = [];
  const additional = new Map<string, T[]>();
  const overflow: T[] = [];
  for (const { event } of ranked) {
    const others = additional.get(event.pubkey);
    if (others) {
      others.push(event);
      overflow.push(event);
    } else {
      primary.push(event);
      additional.set(event.pubkey, []);
    }
  }
  return { primary, additional, ordered: [...primary, ...overflow] };
}
