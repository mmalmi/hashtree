import type { NostrFilter, NostrVerifiedEvent } from 'nostr-pubsub';
import { POST_SEARCH_KINDS } from '../postSearchCatalogConstants';
import { withPostSearchAbortTimeout } from '../postSearchAbort';
import { getPublicSearchRelays } from '../publicSearchRelays';
import { createWorkerRelayEventReader } from '../workerRelayEventReader';

const EXPANSION_NETWORK_TIMEOUT_MS = 3_500;
const EXPANSION_RESPONSE_TIMEOUT_MS = 4_500;

export type ExpandedPostSearchOptions = {
  terms: readonly string[];
  tags: readonly string[];
  limit?: number;
  signal?: AbortSignal | null;
  onEvents?: (events: readonly NostrVerifiedEvent[]) => void;
};

/**
 * Fetch additional candidate posts for model-selected terms and hashtags from
 * public search relays. Only invoked after the active post search has been submitted;
 * the opt-in does not disclose derived queries to other configured relays.
 */
export async function searchExpandedPosts(
  options: ExpandedPostSearchOptions,
): Promise<NostrVerifiedEvent[]> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) { return []; }
  const signal = options.signal ?? null;
  if (signal?.aborted) { return []; }
  const limit = Math.max(12, Math.min(64, Math.trunc(options.limit ?? 36)));
  const cleanTerms = [...new Set(options.terms.map((t) => t.trim().toLowerCase()).filter(Boolean))].slice(0, 2);
  const cleanTags = [...new Set([
    ...options.tags.map((t) => t.trim()).filter(Boolean),
    ...cleanTerms.map((term) => term.replace(/\s+/g, '')),
  ])].slice(0, 8);
  const searchRelays = getPublicSearchRelays();
  const tasks: Array<Promise<NostrVerifiedEvent[]>> = [];
  const merged = new Map<string, NostrVerifiedEvent>();
  const emit = (batch: readonly NostrVerifiedEvent[]): void => {
    if (signal?.aborted) { return; }
    const fresh: NostrVerifiedEvent[] = [];
    for (const event of batch) {
      if (!merged.has(event.id)) {
        merged.set(event.id, event);
        fresh.push(event);
      }
    }
    if (fresh.length) { options.onEvents?.(fresh); }
  };

  if (cleanTags.length && searchRelays.length) {
    const tagReader = createWorkerRelayEventReader({ getRelays: () => searchRelays, onEvents: emit });
    const tagFilters: NostrFilter[] = [{ kinds: [...POST_SEARCH_KINDS], '#t': cleanTags, limit }];
    tasks.push(
      withPostSearchAbortTimeout(
        (relaySignal) => tagReader.query(tagFilters, {
          limit,
          deadline: Date.now() + EXPANSION_NETWORK_TIMEOUT_MS,
          signal: relaySignal,
        }),
        EXPANSION_RESPONSE_TIMEOUT_MS,
        signal,
      ).then((report) => report.events.map(({ event }) => event)).catch(() => []),
    );
  }

  if (cleanTerms.length && searchRelays.length) {
    const termReader = createWorkerRelayEventReader({ getRelays: () => searchRelays, onEvents: emit });
    const termFilters: NostrFilter[] = cleanTerms.map((search) => ({
      kinds: [...POST_SEARCH_KINDS],
      search,
      limit: Math.min(28, limit),
    }));
    tasks.push(
      withPostSearchAbortTimeout(
        (relaySignal) => termReader.query(termFilters, {
          limit: limit * 2,
          deadline: Date.now() + EXPANSION_NETWORK_TIMEOUT_MS,
          signal: relaySignal,
        }),
        EXPANSION_RESPONSE_TIMEOUT_MS,
        signal,
      ).then((report) => report.events.map(({ event }) => event)).catch(() => []),
    );
  }

  if (!tasks.length) { return []; }
  const batches = await Promise.all(tasks);
  for (const batch of batches) {
    for (const event of batch) { merged.set(event.id, event); }
  }
  return [...merged.values()];
}
