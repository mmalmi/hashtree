import { Tokenizer } from '@huggingface/tokenizers';
import { InferenceSession, Tensor, env } from 'onnxruntime-web/wasm';
import wasmUrl from 'onnxruntime-web/ort-wasm-simd-threaded.wasm?url';
import moduleUrl from 'onnxruntime-web/ort-wasm-simd-threaded.mjs?url';
import modelUrl from './model/search-minilm-q8.onnx?url';
import tokenizerUrl from './model/search-tokenizer.json?url';
import indexUrl from './model/search-keywords.bin?url';
import config from './model/tokenizer_config.json' with { type: 'json' };
import { embedBatch } from './embeddings';
import type { FilterHints } from './query';
import { prepareSemanticQuery, scoreSemanticPost, searchVocabulary } from './vocabulary';
import { planPostSearch } from './ranking';

async function loadCpuModel() {
  env.wasm.numThreads = 1;
  env.wasm.wasmPaths = { wasm: wasmUrl, mjs: moduleUrl };
  const model = await InferenceSession.create(modelUrl, { executionProviders: ['wasm'] });
  return { model, Tensor, batchSize: 1 };
}

async function loadModel() {
  if ('gpu' in navigator && 'Suspending' in WebAssembly) {
    try {
      const gpu = await (await import('./gpu-model')).loadGpuModel();
      if (gpu) { return gpu; }
    } catch {
      // A disabled adapter or unsupported driver falls back cleanly to CPU WASM.
    }
  }
  return await loadCpuModel();
}

async function load() {
  // Fetch the optional keyword index in parallel with the model so cold planning
  // does not incur a second sequential network round-trip.
  const [tokenizerResponse, keywordResponse, runtime] = await Promise.all([
    fetch(tokenizerUrl),
    fetch(indexUrl).catch(() => null),
    loadModel(),
  ]);
  if (!tokenizerResponse.ok) { throw new Error('Tokenizer unavailable'); }
  const json = await tokenizerResponse.json();
  const keywordIndex = keywordResponse?.ok
    ? new Int8Array(await keywordResponse.arrayBuffer())
    : undefined;
  return {
    runtime,
    tokenizer: new Tokenizer(json, config),
    words: searchVocabulary(json.model.vocab),
    keywordIndex,
  };
}

let loaded: ReturnType<typeof load> | undefined;
let evidence: {
  query: string;
  selection: Awaited<ReturnType<typeof prepareSemanticQuery>>;
} | undefined;

const vectors = new Map<string, Float32Array>();
function remembered(text: string): Float32Array | undefined {
  const vector = vectors.get(text);
  if (vector) {
    vectors.delete(text);
    vectors.set(text, vector);
  }
  return vector;
}

async function vectorsFor(texts: string[]): Promise<Float32Array[]> {
  const found = new Map(texts.map((text) => [text, remembered(text)]));
  const missing = [...found.keys()].filter((text) => !found.get(text));
  if (missing.length) {
    const state = await loaded!;
    const { model, batchSize, Tensor: RuntimeTensor } = state.runtime;
    // Sort uncached posts by length when batching so padding stays minimal.
    const ordered = batchSize > 1 ? [...missing].sort((a, b) => a.length - b.length) : missing;
    for (let start = 0; start < ordered.length; start += batchSize) {
      const batch = ordered.slice(start, start + batchSize);
      const result = await embedBatch(model, state.tokenizer, batch, RuntimeTensor);
      batch.forEach((text, index) => {
        if (vectors.size >= 1024) { vectors.delete(vectors.keys().next().value!); }
        vectors.set(text, result[index]!);
        found.set(text, result[index]!);
      });
    }
  }
  return texts.map((text) => found.get(text)!);
}

async function vectorFor(text: string): Promise<Float32Array> {
  const [vector] = await vectorsFor([text]);
  return vector!;
}

interface SearchRequest {
  request: number;
  query: string;
  posts: string[];
  hints?: FilterHints;
}

async function score({ request, query, posts, hints }: SearchRequest): Promise<void> {
  const state = await (loaded ??= load());
  const { words, runtime, keywordIndex } = state;
  const plan = planPostSearch(query);
  const vector = await vectorFor(plan.modelQuery);
  if (!posts.length) {
    let terms: string[] = [];
    let tags: string[] = [];
    evidence = undefined;
    try {
      if (keywordIndex) {
        if (!hints) {
          self.postMessage({ request, needsHints: true });
          return;
        }
        const selection = await prepareSemanticQuery(plan, words, keywordIndex, vector, hints, vectorFor);
        terms = selection.terms;
        tags = selection.tags;
        evidence = { query, selection };
      }
    } catch {
      // Primary words, hashtags, and cached notes are already being searched.
    }
    self.postMessage({ request, scores: [], terms, tags, batchSize: runtime.batchSize });
    return;
  }
  const postVectors = await vectorsFor(posts);
  const scores = posts.map((post, index) =>
    scoreSemanticPost(
      plan,
      vector,
      postVectors[index]!,
      post,
      evidence?.query === query ? evidence.selection : undefined,
    ),
  );
  self.postMessage({ request, scores, batchSize: runtime.batchSize });
}

async function handle(data: SearchRequest): Promise<void> {
  try {
    await score(data);
  } catch {
    const state = await loaded?.catch(() => undefined);
    if (state && state.runtime.batchSize > 1) {
      try {
        await state.runtime.model.release().catch(() => undefined);
        vectors.clear();
        evidence = undefined;
        state.runtime = await loadCpuModel();
        await score(data);
        return;
      } catch {
        // Report failure below.
      }
    }
    self.postMessage({ request: data.request, error: true });
  }
}

let pending = Promise.resolve();
let latestRequest = 0;
self.onmessage = ({ data }: MessageEvent<SearchRequest>) => {
  latestRequest = Math.max(latestRequest, data.request);
  pending = pending.then(() => {
    if (data.request < latestRequest) { return undefined; }
    return handle(data);
  });
};
