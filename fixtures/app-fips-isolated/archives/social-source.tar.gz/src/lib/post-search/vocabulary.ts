import { words as tokenize, stopWords, type FilterHints, type SearchPlan } from './query';
import { similarity } from './embeddings';
import tagWeights from './model/search-tag-head.json' with { type: 'json' };
import { semanticMatch } from './ranking';

// Use whole words from the pinned tokenizer, supplemented with network terminology
// absent from its older vocabulary. The index contains no users or search history.
export function searchVocabulary(vocab: Record<string, number>): string[] {
  const vocabWords = Object.keys(vocab)
    .filter((token) => /^[a-z]{3,18}$/.test(token))
    .sort((left, right) => vocab[left]! - vocab[right]!)
    .slice(0, 9000);
  return [
    ...new Set([
      ...vocabWords,
      ...'nostr bitcoin lightning sats satoshi ecash cashu wallet relay relays zap zaps pubkey selfhosted privacy encryption nip05 nsec npub lnbc lightningnetwork nostrconnect decentralized'.split(' '),
    ]),
  ];
}

function sameWordFamily(left: string, right: string): boolean {
  if (left === right) { return true; }
  if (left.includes(' ') || right.includes(' ')) { return false; }
  const short = left.length <= right.length ? left : right;
  const long = left.length <= right.length ? right : left;
  if (short.length >= 3 && long.startsWith(short) && long.length - short.length <= 3) {
    return true;
  }
  return short.length >= 6 && long.length - short.length <= 3 && long.startsWith(short.slice(0, -2));
}

export function selectKeywordFilters(
  vocabWords: readonly string[],
  index: Int8Array,
  query: Float32Array,
  exclude: ReadonlySet<string>,
  hints?: FilterHints,
) {
  if (index.length !== vocabWords.length * query.length) {
    throw new Error('Invalid keyword index');
  }
  const seenTags = new Set(hints?.tags.map((tag) => tag.toLowerCase()));
  const neighbors = new Map<string, number>();
  const candidates: Array<{ word: string; score: number; offset: number }> = [];
  for (let indexPos = 0; indexPos < vocabWords.length; indexPos += 1) {
    const offset = indexPos * query.length;
    let dot = 0;
    let squared = 0;
    for (let dim = 0; dim < query.length; dim += 1) {
      const value = index[offset + dim]!;
      dot += value * query[dim]!;
      squared += value * value;
    }
    const word = vocabWords[indexPos]!;
    const score = dot / Math.sqrt(squared);
    if (score >= 0.32 && !stopWords.has(word) && !exclude.has(word)) {
      neighbors.set(word, score);
    }
  }
  const support = new Map<string, number>();
  for (const sample of hints?.observed ?? []) {
    const ranked = sample
      .map((word) => ({ word, score: exclude.has(word) ? 0.7 : (neighbors.get(word) ?? 0) }))
      .sort((left, right) => right.score - left.score);
    for (const { word } of ranked) {
      const other = (ranked[0]?.word === word ? ranked[1] : ranked[0])?.score ?? 0;
      support.set(word, Math.max(support.get(word) ?? 0, other));
    }
  }
  for (let indexPos = 0; indexPos < vocabWords.length; indexPos += 1) {
    const word = vocabWords[indexPos]!;
    const affinity = neighbors.get(word) ?? 0;
    if (affinity < 0.41) { continue; }
    if (affinity < 0.52 && (support.get(word) ?? 0) < 0.42 && !seenTags.has(word)) { continue; }
    const evidence = Math.max(0, (support.get(word) ?? 0) - 0.35);
    candidates.push({
      word,
      offset: indexPos * query.length,
      score: affinity + 0.08 * Math.sqrt(indexPos / vocabWords.length) + 0.3 * evidence + (seenTags.has(word) ? 0.08 : 0),
    });
  }
  candidates.sort((left, right) => right.score - left.score);
  const families = [...exclude];
  const options = candidates.filter((candidate) => !families.some((word) => sameWordFamily(word, candidate.word)));
  const first = options[0];
  const rest = first ? options.filter((candidate) => !sameWordFamily(first.word, candidate.word)) : [];
  const minimumAffinity = 0.75 * (neighbors.get(first?.word ?? '') ?? 0);
  const grounded = (candidate: { word: string }) =>
    (neighbors.get(candidate.word) ?? 0) >= minimumAffinity
    && ((support.get(candidate.word) ?? 0) >= 0.42 || seenTags.has(candidate.word));
  let second = rest.find(grounded);
  if (!second && first) {
    let best = -Infinity;
    for (const option of rest.slice(0, 24)) {
      if (option.score < Math.max(0.52, first.score - 0.27)) { break; }
      let dot = 0;
      let normA = 0;
      let normB = 0;
      for (let dim = 0; dim < query.length; dim += 1) {
        const left = index[first.offset + dim]!;
        const right = index[option.offset + dim]!;
        dot += left * right;
        normA += left * left;
        normB += right * right;
      }
      const utility = option.score - (0.35 * dot) / Math.sqrt(normA * normB);
      if (utility > best) {
        best = utility;
        second = option;
      }
    }
  }
  const terms = [first, second].flatMap((candidate) => (candidate ? [candidate.word] : []));
  const context = candidates
    .filter(grounded)
    .filter((candidate) => !exclude.has(candidate.word))
    .slice(0, 4)
    .map((candidate) => candidate.word);
  return { terms, neighbors, context };
}

export function planModelFilters(
  plan: SearchPlan,
  vocabWords: readonly string[],
  index: Int8Array,
  query: Float32Array,
  hints?: FilterHints,
) {
  const searched = [plan.relayQuery, ...plan.anchors, ...plan.hashtags, ...plan.terms];
  return selectKeywordFilters(
    vocabWords,
    index,
    query,
    new Set(searched.map((term) => term.toLowerCase())),
    hints,
  );
}

export async function selectKnownTags(
  tags: readonly string[],
  plan: SearchPlan,
  neighbors: ReadonlyMap<string, number>,
  vector: Float32Array,
  vectorFor: (text: string) => Promise<Float32Array>,
  allowLearnedFallback = false,
): Promise<string[]> {
  const candidates = tags
    .map((tag) => {
      const label = tokenize(tag.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]/g, ' ')).join(' ');
      const parts = label.split(' ');
      const estimate = Math.max(0, ...parts.map((token) => (plan.terms.includes(token) ? 1 : (neighbors.get(token) ?? 0))));
      return { tag, label, estimate };
    })
    .sort((left, right) => right.estimate - left.estimate);
  let budget = 8;
  const found: Array<{ tag: string; score: number }> = [];
  let fallback: { tag: string; score: number } | undefined;
  for (const { tag, label, estimate } of candidates) {
    if (plan.terms.includes(tag) || plan.hashtags.includes(tag)) { continue; }
    let score = neighbors.get(label);
    if (score === undefined && budget > 0) {
      budget -= 1;
      const candidate = await vectorFor(label);
      score = similarity(candidate, vector);
      if (allowLearnedFallback && tagWeights.length === candidate.length + 2) {
        const logit = candidate.reduce(
          (sum, value, dim) => sum + value * tagWeights[dim + 2]!,
          tagWeights[0]! + tagWeights[1]! * Math.max(0, score),
        );
        const probability = 1 / (1 + Math.exp(-logit));
        const priority = probability + 0.04 * estimate;
        if (probability >= 0.45 && (!fallback || priority > fallback.score)) {
          fallback = { tag, score: priority };
        }
      }
    }
    if ((score ?? 0) >= 0.45) { found.push({ tag, score: score! + 0.04 * estimate }); }
  }
  if (!found.length && fallback) { return [fallback.tag]; }
  return found.sort((left, right) => right.score - left.score).slice(0, 6).map((item) => item.tag);
}

export async function prepareSemanticQuery(
  plan: SearchPlan,
  vocabWords: readonly string[],
  index: Int8Array,
  query: Float32Array,
  hints: FilterHints | undefined,
  vectorFor: (text: string) => Promise<Float32Array>,
  useTagHead = true,
) {
  const topic = !plan.browse && plan.terms.length === 1 && plan.phrase === plan.terms[0]
    ? await vectorFor(`A post about ${plan.modelQuery}.`)
    : undefined;
  const selected = planModelFilters(plan, vocabWords, index, topic ?? query, hints);
  const tags = await selectKnownTags(
    hints?.tags ?? [],
    plan,
    selected.neighbors,
    topic ?? query,
    vectorFor,
    useTagHead && plan.terms.length > 1 && !selected.terms.length,
  );
  const facets = topic && !selected.context.length ? selected.terms : selected.context;
  const context = (plan.browse || topic) && plan.terms.length === 1 && facets.length
    ? await vectorFor([plan.modelQuery, ...facets].join(', '))
    : undefined;
  const intent = plan.browse && plan.terms.length === 1 ? await vectorFor(plan.text) : undefined;
  return {
    terms: selected.terms,
    tags,
    topic,
    context,
    intent,
    neighbors: selected.neighbors,
  };
}

export function scoreSemanticPost(
  plan: SearchPlan,
  query: Float32Array,
  vector: Float32Array,
  text: string,
  selected?: Awaited<ReturnType<typeof prepareSemanticQuery>>,
): number {
  const cosine = Math.max(
    similarity(query, vector),
    selected?.topic ? similarity(selected.topic, vector) : 0,
    selected?.context ? 0.85 * similarity(selected.context, vector) : 0,
  );
  const score = semanticMatch(
    cosine,
    text,
    plan.terms.length === 1 ? selected?.neighbors : undefined,
    plan.browse && plan.terms.length === 1 ? plan.terms[0] : undefined,
    selected?.intent ? similarity(selected.intent, vector) : undefined,
  );
  return selected?.topic ? Math.min(1, score + 0.08, 0.1 + 1.55 * cosine) : score;
}
