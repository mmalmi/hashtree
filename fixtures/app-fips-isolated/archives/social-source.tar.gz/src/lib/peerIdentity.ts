import { fallbackProfileNameForIdentity, pubkeyToNpub } from './nostr';

/** FIPS keeps the point's parity byte. Nostr represents the same peer by its x coordinate. */
export function peerIdentity(peerId: string) {
  const key = peerId.trim().toLowerCase();
  const pubkey = /^(02|03)[0-9a-f]{64}$/.test(key) ? key.slice(2) : null;
  return { peerId, name: fallbackProfileNameForIdentity(pubkey ?? peerId), npub: pubkey ? pubkeyToNpub(pubkey) : null };
}
