import type { RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { getDirectThreadParentTargetKey } from './threadTree';
import { getValidatedZapBits, validateZapReceipt } from './zapReceipt';

export const NOTE_ENGAGEMENT_EVENT_KINDS = [1, 6, 7, 16, 1_111, 9_735] as const;

export type NoteEngagement = {
  reactionCount: number;
  replyCount: number;
  repostCount: number;
  zapCount: number;
  zapBits: number;
  viewerReacted: boolean;
  reactionAuthors: readonly string[];
  replyEventIds: readonly string[];
  repostAuthors: readonly string[];
  zapReceipts: readonly { id: string; bits: number }[];
};

export const ZERO_NOTE_ENGAGEMENT: NoteEngagement = {
  reactionCount: 0,
  replyCount: 0,
  repostCount: 0,
  zapCount: 0,
  zapBits: 0,
  viewerReacted: false,
  reactionAuthors: [],
  replyEventIds: [],
  repostAuthors: [],
  zapReceipts: [],
};

/** Repost cards display and count interactions on the original post. */
export function getNoteEngagementTargetId(event: RawEvent): string {
  return event.kind === 6 ? getLastValidLowercaseEventTarget(event) ?? event.id : event.id;
}

function selectNewestEventsByAuthor(events: readonly RawEvent[]): RawEvent[] {
  const byAuthor = new Map<string, RawEvent>();
  for (const event of events) {
    const existing = byAuthor.get(event.pubkey);
    if (
      !existing
      || event.created_at > existing.created_at
      || (event.created_at === existing.created_at && event.id.localeCompare(existing.id) < 0)
    ) {
      byAuthor.set(event.pubkey, event);
    }
  }
  return [...byAuthor.values()].sort((left, right) => (
    right.created_at - left.created_at || left.id.localeCompare(right.id)
  ));
}

export function selectNewestReactionsByAuthor(events: readonly RawEvent[]): RawEvent[] {
  return selectNewestEventsByAuthor(events);
}

export function getZapBits(event: RawEvent): number {
  return getValidatedZapBits(event);
}

export function summarizeNoteEngagementEvents(
  noteId: string,
  events: readonly RawEvent[],
  viewerPubkey?: string | null,
): NoteEngagement {
  const uniqueEvents = [...new Map(events.map((event) => [event.id, event] as const)).values()];
  const normalizedNoteId = noteId.trim().toLowerCase();
  const reactions = selectNewestReactionsByAuthor(
    uniqueEvents.filter((event) => (
      event.kind === 7 && getLastValidLowercaseEventTarget(event) === normalizedNoteId
    )),
  );
  const reposts = selectNewestEventsByAuthor(
    uniqueEvents.filter((event) => (
      (event.kind === 6 || event.kind === 16)
      && getLastValidLowercaseEventTarget(event) === normalizedNoteId
    )),
  );
  const replies = uniqueEvents.filter((event) => (
    (event.kind === 1 || event.kind === 1_111)
    && getDirectThreadParentTargetKey(event) === `e:${normalizedNoteId}`
  ));
  const zaps = uniqueEvents.flatMap((event) => {
    if (event.kind !== 9_735) {
      return [];
    }
    const validated = validateZapReceipt(event, { eventId: normalizedNoteId });
    return validated ? [{ event, bits: validated.bits }] : [];
  });
  const normalizedViewerPubkey = viewerPubkey?.trim().toLowerCase() || null;

  return {
    reactionCount: reactions.length,
    replyCount: replies.length,
    repostCount: reposts.length,
    zapCount: zaps.length,
    zapBits: zaps.reduce((total, zap) => total + zap.bits, 0),
    viewerReacted: normalizedViewerPubkey
      ? reactions.some((event) => event.pubkey === normalizedViewerPubkey)
      : false,
    reactionAuthors: reactions.map((event) => event.pubkey).sort(),
    replyEventIds: replies.map((event) => event.id).sort(),
    repostAuthors: reposts.map((event) => event.pubkey).sort(),
    zapReceipts: zaps
      .map(({ event, bits }) => ({ id: event.id, bits }))
      .sort((left, right) => left.id.localeCompare(right.id)),
  };
}

export function mergeLiveNoteEngagementEvents(
  durable: Map<string, NoteEngagement>,
  liveEvents: readonly RawEvent[],
  viewerPubkey?: string | null,
): Map<string, NoteEngagement> {
  if (durable.size === 0 || liveEvents.length === 0) {
    return durable;
  }

  const eventsByTarget = new Map<string, RawEvent[]>();
  for (const event of liveEvents) {
    const directParent = getDirectThreadParentTargetKey(event);
    const target = event.kind === 1 || event.kind === 1_111
      ? directParent?.startsWith('e:') ? directParent.slice(2) : null
      : getLastValidLowercaseEventTarget(event);
    const targets = target && durable.has(target)
      ? [target]
      : [];
    for (const target of targets) {
      const events = eventsByTarget.get(target) ?? [];
      events.push(event);
      eventsByTarget.set(target, events);
    }
  }
  if (eventsByTarget.size === 0) {
    return durable;
  }

  const normalizedViewerPubkey = viewerPubkey?.trim().toLowerCase() || null;
  const merged = new Map(durable);
  for (const [noteId, events] of eventsByTarget) {
    const base = durable.get(noteId) ?? ZERO_NOTE_ENGAGEMENT;
    const reactionAuthors = new Set(base.reactionAuthors);
    const replyEventIds = new Set(base.replyEventIds);
    const repostAuthors = new Set(base.repostAuthors);
    const zapReceipts = new Map(base.zapReceipts.map((receipt) => [receipt.id, receipt.bits]));

    for (const event of events) {
      if (event.kind === 7 && getLastValidLowercaseEventTarget(event) === noteId) {
        reactionAuthors.add(event.pubkey);
      } else if ((event.kind === 6 || event.kind === 16)
        && getLastValidLowercaseEventTarget(event) === noteId) {
        repostAuthors.add(event.pubkey);
      } else if (
        (event.kind === 1 || event.kind === 1_111)
        && getDirectThreadParentTargetKey(event) === `e:${noteId}`
      ) {
        replyEventIds.add(event.id);
      } else if (event.kind === 9_735) {
        const validated = validateZapReceipt(event, { eventId: noteId });
        if (validated) {
          zapReceipts.set(event.id, validated.bits);
        }
      }
    }

    const sortedReactionAuthors = [...reactionAuthors].sort();
    const sortedReplyEventIds = [...replyEventIds].sort();
    const sortedRepostAuthors = [...repostAuthors].sort();
    const sortedZapReceipts = [...zapReceipts]
      .map(([id, bits]) => ({ id, bits }))
      .sort((left, right) => left.id.localeCompare(right.id));
    merged.set(noteId, {
      reactionCount: sortedReactionAuthors.length,
      replyCount: sortedReplyEventIds.length,
      repostCount: sortedRepostAuthors.length,
      zapCount: sortedZapReceipts.length,
      zapBits: sortedZapReceipts.reduce((total, receipt) => total + receipt.bits, 0),
      viewerReacted: base.viewerReacted || Boolean(
        normalizedViewerPubkey && reactionAuthors.has(normalizedViewerPubkey)
      ),
      reactionAuthors: sortedReactionAuthors,
      replyEventIds: sortedReplyEventIds,
      repostAuthors: sortedRepostAuthors,
      zapReceipts: sortedZapReceipts,
    });
  }
  return merged;
}

const compactStatFormatters = [0, 1].map((maximumFractionDigits) => new Intl.NumberFormat(undefined, {
  notation: 'compact',
  maximumFractionDigits,
}));

export function formatCompactStat(value: number): string {
  return compactStatFormatters[value >= 1000 ? 1 : 0]!.format(value);
}
