import { HashTree, type CID } from '@hashtree/core';
import { BTree } from '@hashtree/index';
import { verifyEvent } from 'nostr-tools/pure';
import {
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
  getConfiguredProfileIndexRef,
} from './config';
import { CooperativeWorkBudget } from './cooperativeWork';
import { verifyIndexedEvents } from './fastEventVerification';
import { parseProfileEvent, type ProfileRecord, type RawEvent } from './nostr';
import {
  isProfileLoadAbort,
  throwIfProfileLoadAborted,
  withProfileLoadAbort,
} from './profileLoadAbort';
import {
  PROFILE_SEARCH_EVENT_MAX_BYTES,
  projectProfileSearchIdentity,
} from './profileSearchIdentity';
import { createWorkerBlockStore } from './workerBlockStore';
import { resolveTreeTargetRoot } from './treeRef';

const PROFILE_INDEX_ROOT_CACHE_TTL_MS = 30_000;
const PROFILE_INDEX_ROOT_RETRY_DELAYS_MS = [120, 360, 900];

type ProfileIndexContext = {
  tree: HashTree;
  index: BTree;
};

let profileIndexContext: ProfileIndexContext | null = null;
let cachedProfileIndexRoot:
  | {
      expiresAt: number;
      ref: string;
      root: CID;
    }
  | null = null;
let profileIndexRootPromise:
  | {
      ref: string;
      promise: Promise<CID | null>;
    }
  | null = null;

export type IndexedProfileRecordInput = {
  pubkey: string;
  bytes: Uint8Array;
};

export type ProfileIndexLoadOptions = {
  signal?: AbortSignal;
};

export type IndexedProfileRecordVerificationOptions = ProfileIndexLoadOptions & {
  verifyEvents?: (
    events: RawEvent[],
    signal?: AbortSignal,
  ) => Promise<boolean[]>;
  workBudget?: CooperativeWorkBudget;
};

function getProfileIndexContext(): ProfileIndexContext {
  if (profileIndexContext) {
    return profileIndexContext;
  }

  const store = createWorkerBlockStore();
  profileIndexContext = {
    tree: new HashTree({ store }),
    index: new BTree(store),
  };
  return profileIndexContext;
}

async function readProfileRecordInput(
  cid: CID,
  fallbackPubkey: string,
  signal?: AbortSignal,
): Promise<IndexedProfileRecordInput | null> {
  try {
    const bytes = await withProfileLoadAbort(
      getProfileIndexContext().tree.readFile(cid),
      signal,
    );
    if (!bytes) {
      return null;
    }
    return { pubkey: fallbackPubkey, bytes };
  } catch (error) {
    if (isProfileLoadAbort(error, signal)) {
      throw error;
    }
    return null;
  }
}

function decodeIndexedProfileRecord(
  bytes: Uint8Array,
  fallbackPubkey: string,
): RawEvent | null {
  try {
    if (bytes.byteLength > PROFILE_SEARCH_EVENT_MAX_BYTES) {
      return null;
    }
    const event = JSON.parse(new TextDecoder().decode(bytes)) as Partial<RawEvent>;
    if (
      typeof event.id !== 'string'
      || typeof event.pubkey !== 'string'
      || typeof event.created_at !== 'number'
      || event.kind !== 0
      || !Array.isArray(event.tags)
      || typeof event.content !== 'string'
      || typeof event.sig !== 'string'
    ) {
      return null;
    }
    const candidate: RawEvent = {
      id: event.id,
      pubkey: event.pubkey.toLowerCase(),
      created_at: event.created_at,
      kind: event.kind,
      tags: event.tags.filter(Array.isArray).map((tag) => tag.map(String)),
      content: event.content,
      sig: event.sig,
    };
    if (candidate.pubkey !== fallbackPubkey) {
      return null;
    }
    return candidate;
  } catch {
    return null;
  }
}

function projectIndexedProfileRecord(candidate: RawEvent): ProfileRecord | null {
  const profile = parseProfileEvent(candidate);
  const identity = projectProfileSearchIdentity(candidate);
  return profile && identity
    ? {
        ...profile,
        name: identity.name,
        displayName: identity.displayName,
        nip05: identity.nip05,
        searchAliases: identity.aliases,
      }
    : null;
}

/**
 * Decode a catalog chunk without cryptography, verify the whole chunk through
 * one worker request, then project only signed records for the indexed key.
 */
export async function verifyAndProjectIndexedProfileRecords(
  records: readonly IndexedProfileRecordInput[],
  options: IndexedProfileRecordVerificationOptions = {},
): Promise<Map<string, ProfileRecord>> {
  throwIfProfileLoadAborted(options.signal);
  const workBudget = options.workBudget ?? new CooperativeWorkBudget();
  const candidates: Array<{ pubkey: string; event: RawEvent }> = [];
  for (const { pubkey, bytes } of records) {
    throwIfProfileLoadAborted(options.signal);
    const candidate = await workBudget.run(() => {
      const normalizedPubkey = pubkey.trim().toLowerCase();
      const event = normalizedPubkey
        ? decodeIndexedProfileRecord(bytes, normalizedPubkey)
        : null;
      return event ? { pubkey: normalizedPubkey, event } : null;
    });
    if (candidate) {
      candidates.push(candidate);
    }
  }
  if (candidates.length === 0) {
    return new Map();
  }

  const valid = await withProfileLoadAbort(
    (options.verifyEvents ?? verifyIndexedEvents)(
      candidates.map(({ event }) => event),
      options.signal,
    ),
    options.signal,
  );
  throwIfProfileLoadAborted(options.signal);
  if (valid.length !== candidates.length) {
    return new Map();
  }

  const profiles = new Map<string, ProfileRecord>();
  for (let index = 0; index < candidates.length; index += 1) {
    if (!valid[index]) {
      continue;
    }
    const candidate = candidates[index]!;
    throwIfProfileLoadAborted(options.signal);
    const profile = await workBudget.run(
      () => projectIndexedProfileRecord(candidate.event),
    );
    if (profile) {
      profiles.set(candidate.pubkey, profile);
    }
  }
  return profiles;
}

/**
 * Synchronous parser retained for local-search verification and Node tests.
 * Browser profile hydration uses verifyAndProjectIndexedProfileRecords instead.
 */
export function parseVerifiedIndexedProfileRecord(
  bytes: Uint8Array,
  fallbackPubkey: string,
): ProfileRecord | null {
  const candidate = decodeIndexedProfileRecord(bytes, fallbackPubkey);
  return candidate && verifyEvent(candidate)
    ? projectIndexedProfileRecord(candidate)
    : null;
}

export async function resolveProfileIndexRoot(force = false): Promise<CID | null> {
  const ref = getConfiguredProfileIndexRef();
  const cached = cachedProfileIndexRoot;
  if (!force && cached && cached.ref === ref && cached.expiresAt > Date.now()) {
    return cached.root;
  }

  // A forced refresh may bypass a cached root, but it must never duplicate an
  // already active mutable-root subscription/retry sequence.
  if (profileIndexRootPromise?.ref === ref) {
    return await profileIndexRootPromise.promise;
  }

  const promise = resolveTreeTargetRoot(ref, {
    resolveImmutablePath: async (root, path) => (await getProfileIndexContext().tree.resolvePath(root, path))?.cid ?? null,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
    retryDelaysMs: PROFILE_INDEX_ROOT_RETRY_DELAYS_MS,
  });

  profileIndexRootPromise = { ref, promise };

  try {
    const root = await promise;
    cachedProfileIndexRoot = root
      ? {
          ref,
          root,
          expiresAt: Date.now() + PROFILE_INDEX_ROOT_CACHE_TTL_MS,
        }
      : null;
    return root;
  } finally {
    if (profileIndexRootPromise?.ref === ref) {
      profileIndexRootPromise = null;
    }
  }
}

export async function loadIndexedProfileRecord(
  pubkey: string,
  options: ProfileIndexLoadOptions = {},
): Promise<ProfileRecord | null> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  if (!normalizedPubkey) {
    return null;
  }

  return (await loadIndexedProfiles([normalizedPubkey], options)).get(normalizedPubkey) ?? null;
}

export async function loadIndexedProfiles(
  pubkeys: string[],
  options: ProfileIndexLoadOptions = {},
): Promise<Map<string, ProfileRecord>> {
  const normalizedPubkeys = [...new Set(pubkeys.map((pubkey) => pubkey.trim().toLowerCase()).filter(Boolean))];
  if (normalizedPubkeys.length === 0) {
    return new Map();
  }

  const root = await withProfileLoadAbort(resolveProfileIndexRoot(), options.signal);
  if (!root) {
    return new Map();
  }

  const entries = await Promise.all(
    normalizedPubkeys.map(async (pubkey) => {
      throwIfProfileLoadAborted(options.signal);
      const cid = await withProfileLoadAbort(
        getProfileIndexContext().index.getLink(root, pubkey),
        options.signal,
      );
      if (!cid) {
        return null;
      }

      return await readProfileRecordInput(cid, pubkey, options.signal);
    }),
  );

  throwIfProfileLoadAborted(options.signal);
  return await verifyAndProjectIndexedProfileRecords(
    entries.filter((entry): entry is IndexedProfileRecordInput => Boolean(entry)),
    options,
  );
}

export async function warmProfileIndex(): Promise<void> {
  await resolveProfileIndexRoot();
}
