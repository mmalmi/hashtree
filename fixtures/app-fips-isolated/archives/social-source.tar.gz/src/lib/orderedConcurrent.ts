export const DEFAULT_INDEXED_EVENT_READ_CONCURRENCY = 24;

type SettledValue<T> =
  | { status: 'fulfilled'; value: T }
  | { status: 'rejected'; reason: unknown };

export type ConcurrencyLimiter = {
  run: <T>(task: () => Promise<T>) => Promise<T>;
};

function normalizeConcurrency(concurrency: number | undefined): number {
  if (concurrency === undefined) {
    return DEFAULT_INDEXED_EVENT_READ_CONCURRENCY;
  }
  if (!Number.isFinite(concurrency) || concurrency < 1) {
    throw new Error(`Concurrency must be a positive finite number: ${concurrency}`);
  }
  return Math.max(1, Math.trunc(concurrency));
}

function toAsyncIterator<T>(source: AsyncIterable<T> | Iterable<T>): AsyncIterator<T> {
  if (Symbol.asyncIterator in source) {
    return source[Symbol.asyncIterator]();
  }
  const iterator = source[Symbol.iterator]();
  return {
    next: async () => iterator.next(),
    return: iterator.return
      ? async () => iterator.return!()
      : undefined,
  };
}

/**
 * Read bounded batches while yielding results in source order.
 * A new batch starts only after the previous batch was consumed, so callers
 * that stop on a page boundary do not speculatively cross into the next page.
 * Mapper failures are wrapped so speculative reads cannot reject unobserved.
 * First-match probes can leave unused reads settling in the background.
 */
export async function* mapOrderedConcurrent<Input, Output>(
  source: AsyncIterable<Input> | Iterable<Input>,
  mapper: (value: Input, index: number) => Promise<Output>,
  options: { concurrency?: number; waitForPendingOnClose?: boolean } = {},
): AsyncGenerator<Output, void, void> {
  const concurrency = normalizeConcurrency(options.concurrency);
  const iterator = toAsyncIterator(source);
  const pending: Array<Promise<SettledValue<Output>>> = [];
  let inputIndex = 0;
  let sourceDone = false;

  const fill = async (): Promise<void> => {
    while (!sourceDone && pending.length < concurrency) {
      const next = await iterator.next();
      if (next.done) {
        sourceDone = true;
        return;
      }
      const index = inputIndex;
      inputIndex += 1;
      pending.push((async (): Promise<SettledValue<Output>> => {
        try {
          return { status: 'fulfilled', value: await mapper(next.value, index) };
        } catch (reason) {
          return { status: 'rejected', reason };
        }
      })());
    }
  };

  try {
    while (!sourceDone || pending.length > 0) {
      await fill();
      while (pending.length > 0) {
        const settled = await pending.shift()!;
        if (settled.status === 'rejected') {
          throw settled.reason;
        }
        yield settled.value;
      }
    }
  } finally {
    try {
      await iterator.return?.();
    } finally {
      if (options.waitForPendingOnClose !== false) { await Promise.all(pending); }
    }
  }
}

/** Share one concurrency ceiling across several ordered streams. */
export function createConcurrencyLimiter(concurrency?: number): ConcurrencyLimiter {
  const limit = normalizeConcurrency(concurrency);
  const queue: Array<() => void> = [];
  let active = 0;

  const pump = (): void => {
    while (active < limit && queue.length > 0) {
      active += 1;
      queue.shift()!();
    }
  };

  return {
    run<T>(task: () => Promise<T>): Promise<T> {
      return new Promise<T>((resolve, reject) => {
        queue.push(() => {
          void Promise.resolve()
            .then(task)
            .then(resolve, reject)
            .finally(() => {
              active -= 1;
              pump();
            });
        });
        pump();
      });
    },
  };
}
