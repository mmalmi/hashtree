import type { AppCombinedState } from './appState';
import {
  createInfiniteScrollAction,
  INFINITE_SCROLL_PRELOAD_PX,
} from './infiniteScroll';

const NOTIFICATION_PAGE_SIZE = 40;

type ScrollTracker = {
  get: () => number;
  set: (offset: number) => void;
};

type InfiniteScrollDeps = {
  state: AppCombinedState;
  homeFeedScroll: ScrollTracker;
  profileFeedScroll: ScrollTracker;
  threadReplyScroll: ScrollTracker;
  hydrateNotificationsPage: (options: {
    root: NonNullable<AppCombinedState['root']>;
    pubkey: string;
    token: number;
    before: NonNullable<AppCombinedState['notificationCursor']>;
    limit: number;
  }) => Promise<void>;
  loadMoreFeed: () => Promise<void>;
  loadMoreProfileNotes: () => Promise<void>;
  loadMoreProfileSocial: () => Promise<void>;
  loadMoreThreadReplies: () => Promise<void>;
  getHomeFeedHasMore: () => boolean;
  getProfileFeedHasMore: () => boolean;
  getProfileSocialHasMore: () => boolean;
};

export function createAppInfiniteScrollController(deps: InfiniteScrollDeps) {
  const { state } = deps;
  async function loadMoreNotifications(): Promise<void> {
    if (
      state.notificationsLoadPending
      || !state.notificationsHasMore
      || !state.notificationCursor
      || !state.root
      || !state.activeAccount
      || state.route.kind !== 'notifications'
    ) {
      return;
    }
    state.notificationLastLoadScrollOffset = state.notificationScrollOffset;
    await deps.hydrateNotificationsPage({
      root: state.root,
      pubkey: state.activeAccount.pubkey,
      token: state.loadToken,
      before: state.notificationCursor,
      limit: NOTIFICATION_PAGE_SIZE,
    });
  }

  const sharedOptions = {
    preloadPx: INFINITE_SCROLL_PRELOAD_PX,
    minScrollDeltaPx: 0,
  };
  const homeFeedInfiniteScroll = createInfiniteScrollAction({
    ...sharedOptions,
    getScrollOffset: deps.homeFeedScroll.get,
    setScrollOffset: deps.homeFeedScroll.set,
    getLastLoadScrollOffset: () => state.homeFeedLastLoadScrollOffset,
    getLoadPending: () => state.homeFeedLoadPending,
    getHasMore: deps.getHomeFeedHasMore,
    getFillViewport: () => state.route.kind === 'home' && (
      state.route.tab === 'media'
      || (
        (state.route.tab === 'latest' || state.route.tab === 'for-you' || state.route.tab === 'favorites')
        && state.feedView === 'media-grid'
      )
    ),
    onLoadMore: () => void deps.loadMoreFeed(),
  });
  const notificationsInfiniteScroll = createInfiniteScrollAction({
    ...sharedOptions,
    getScrollOffset: () => state.notificationScrollOffset,
    setScrollOffset: (offset) => { state.notificationScrollOffset = offset; },
    getLastLoadScrollOffset: () => state.notificationLastLoadScrollOffset,
    getLoadPending: () => state.notificationsLoadPending,
    getHasMore: () => state.notificationsHasMore,
    onLoadMore: () => void loadMoreNotifications(),
  });
  const profileFeedInfiniteScroll = createInfiniteScrollAction({
    ...sharedOptions,
    getScrollOffset: deps.profileFeedScroll.get,
    setScrollOffset: deps.profileFeedScroll.set,
    getLastLoadScrollOffset: () => state.profileFeedLastLoadScrollOffset,
    getLoadPending: () => state.profileFeedLoadPending,
    getHasMore: deps.getProfileFeedHasMore,
    getFillViewport: () => state.route.kind === 'profile' && state.route.section === 'media',
    onLoadMore: () => void deps.loadMoreProfileNotes(),
  });
  const profileSocialInfiniteScroll = createInfiniteScrollAction({
    ...sharedOptions,
    getScrollOffset: () => state.profileSocialScrollOffset,
    setScrollOffset: (offset) => { state.profileSocialScrollOffset = offset; },
    getLastLoadScrollOffset: () => state.profileSocialLastLoadScrollOffset,
    getLoadPending: () => state.profileSocialLoadPending,
    getHasMore: deps.getProfileSocialHasMore,
    onLoadMore: () => void deps.loadMoreProfileSocial(),
  });
  const threadRepliesInfiniteScroll = createInfiniteScrollAction({
    ...sharedOptions,
    getScrollOffset: deps.threadReplyScroll.get,
    setScrollOffset: deps.threadReplyScroll.set,
    getLastLoadScrollOffset: () => state.threadReplyLastLoadScrollOffset,
    getLoadPending: () => state.threadRepliesLoadPending,
    getHasMore: () => state.threadRepliesHasMore,
    onLoadMore: () => void deps.loadMoreThreadReplies(),
  });

  return {
    homeFeedInfiniteScroll,
    loadMoreNotifications,
    notificationsInfiniteScroll,
    profileFeedInfiniteScroll,
    profileSocialInfiniteScroll,
    threadRepliesInfiniteScroll,
  };
}
