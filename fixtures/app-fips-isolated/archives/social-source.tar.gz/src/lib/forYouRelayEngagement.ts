export const FOR_YOU_RELAY_ENGAGEMENT_MODE = 'for-you-engagement';
export const FOR_YOU_RELAY_ENGAGEMENT_KINDS = [1, 6, 7, 1_111] as const;
export const FOR_YOU_RELAY_TARGET_LIMIT = 16;
export const FOR_YOU_RELAY_EVENT_LIMIT = 96;
export const FOR_YOU_RELAY_COUNT_LIMIT = 8;
export const FOR_YOU_RELAY_WINDOW_MS = 4_000;
export const FOR_YOU_RELAY_RESPONSE_GRACE_MS = 1_500;
export const FOR_YOU_RELAY_LOOKBACK_SECONDS = 30 * 24 * 60 * 60;
