import { NdrRuntime, buildAppKeysFilter, type NdrRuntimeState } from 'nostr-double-ratchet';
import { getEventHash, type VerifiedEvent } from 'nostr-tools/pure';
import { isRelayDiscoveryFilter, type NostrEvent } from 'nostr-pubsub';
import {
  PRIVATE_CONTACT_CONTROL_KIND, buildPrivateContactControl, buildPrivateContactRequest,
  type PrivateContactDocument,
} from 'nostr-social-graph/privateContactSyncV2';
import type { SocialAccount } from './accounts';
import { canSignAccount, signAccountEvent } from './accountSigner';
import { getConfiguredPrivateNostrRelays } from './htreeRuntime';
import { createPrivateRatchetStorage, createPrivateRatchetOutbox, publishPrivateRatchetEnvelope } from './privateRatchetStorage';
import { registerPrivateRatchetControls } from './privateRatchetControls';
import { applyPrivateRatchetRoster } from './privateRatchetRoster';
import type { SocialLiveTransport } from './socialDataPlaneTypes';
import { getWorkerClient } from './workerClient';

export type PrivateRatchetOptions = {
  account: SocialAccount;
  signal: AbortSignal;
  merge(document: PrivateContactDocument): Promise<void>;
  snapshot(): Promise<void>;
  onState(state: NdrRuntimeState): void;
  onError(error: unknown): void;
};

// SDK event objects are immutable; independently bundled signature verifiers
// annotate their own event copies when checking device authorization.
const protocolEvent = (event: NostrEvent): VerifiedEvent => structuredClone(event) as VerifiedEvent;

/** One instance per account across tabs, held by the caller's Web Lock. */
export async function createPrivateRatchetRuntime(options: PrivateRatchetOptions) {
  const { account, signal } = options;
  signal.throwIfAborted();
  const worker = await getWorkerClient();
  signal.throwIfAborted();
  const storage = createPrivateRatchetStorage(localStorage, `iris-social:private-ratchet:${account.pubkey}:`);
  let peer: SocialLiveTransport | null = null;
  const subscriptions = new Set<{ attachPeer(): void; close(): void }>();
  const outbox = createPrivateRatchetOutbox(storage, async (event, sendSignal) => {
    await publishPrivateRatchetEnvelope(event, () => worker.publishRelayEvent(
      getConfiguredPrivateNostrRelays(), event, AbortSignal.any([signal, sendSignal])), peer);
  }, options.onError);
  const sign = async (draft: Parameters<typeof signAccountEvent>[1]): Promise<VerifiedEvent> => {
    signal.throwIfAborted();
    if (draft.kind !== 37368 || draft.content !== ''
      || draft.tags.some(tag => tag[0] === 'encrypted_device_labels')) {
      throw new Error('Only public device authorization may use the account signer.');
    }
    try { return await signAccountEvent(account, draft) as VerifiedEvent; }
    catch (cause) {
      const error = new Error('Enable private sync to approve this device.', { cause });
      error.name = 'PrivateSyncApprovalError';
      throw error;
    }
  };
  const runtime = new NdrRuntime({
    storage,
    // The account key only signs the public roster. All private data uses device sessions.
    nostrSign: sign,
    nostrEnqueue: event => outbox.enqueue(event),
    nostrPublish: async event => {
      const signed = 'sig' in event && event.sig ? event as VerifiedEvent : await sign(event);
      return await outbox.publish(signed);
    },
    nostrFetch: async filter => {
      const limit = Math.min(filter.limit ?? 256, 256);
      const result = await worker.queryRelayEvents(getConfiguredPrivateNostrRelays(), [{ ...filter, limit }], { limit, signal });
      if (!result.complete) { throw new Error('Waiting for the device list.'); }
      return result.events.map(protocolEvent);
    },
    nostrSubscribe: (filter, handler) => {
      let stopped = false;
      let relay: { close(): void } | undefined;
      let direct: { close(): void } | undefined;
      let retry: ReturnType<typeof setTimeout> | undefined;
      const connectRelay = () => {
        if (stopped || signal.aborted) { return; }
        relay = worker.subscribeRelayEvents(getConfiguredPrivateNostrRelays(), [filter], {
          onEvent: event => { if (!stopped && !signal.aborted) { handler(protocolEvent(event)); } },
          onClose: () => {
            if (!stopped && !signal.aborted) { retry = setTimeout(connectRelay, 5_000); }
          },
        });
      };
      const subscription = {
        attachPeer() {
          direct?.close();
          if (!stopped && peer && !isRelayDiscoveryFilter(filter)) {
            direct = peer.subscribe([filter], event => { if (!stopped && !signal.aborted) { handler(protocolEvent(event)); } });
          }
        },
        close() { stopped = true; clearTimeout(retry); relay?.close(); direct?.close(); subscriptions.delete(subscription); },
      };
      subscriptions.add(subscription);
      connectRelay(); subscription.attachPeer();
      return subscription.close;
    },
    onPublishError: ({ error }) => options.onError(error),
  });
  let authorizationReady = false;
  let readingRoster: Promise<void> | undefined;
  async function refreshAuthorization(): Promise<void> {
    if (readingRoster) { return readingRoster; }
    readingRoster = (async () => {
      const roster = await worker.queryRelayEvents(getConfiguredPrivateNostrRelays(), [buildAppKeysFilter(account.pubkey)], { limit: 256, signal });
      if (!roster.complete) { throw new Error('Waiting for the device list.'); }
      await applyPrivateRatchetRoster(account.pubkey, roster.events.map(protocolEvent), runtime);
      signal.throwIfAborted();
      authorizationReady = true;
    })().finally(() => { readingRoster = undefined; });
    return readingRoster;
  }
  const stopIncoming = registerPrivateRatchetControls(runtime, {
    owner: account.pubkey, signal, isAuthorizationReady: () => authorizationReady,
    refreshAuthorization, onError: options.onError, merge: options.merge, snapshot: options.snapshot,
  });
  const stopState = runtime.onStateChange(options.onState);
  let stopped = false;
  function stop() {
    if (stopped) { return; }
    stopped = true;
    stopIncoming(); stopState(); outbox.stop(); runtime.close();
    for (const subscription of subscriptions) { subscription.close(); }
  }
  signal.addEventListener('abort', stop, { once: true });
  try {
    await runtime.initForOwner(account.pubkey);
    await refreshAuthorization();
    signal.throwIfAborted();
    outbox.start();
    void import('./fipsP2P').then(module => module.getLiveNostrPubsub()).then(value => {
      if (signal.aborted) { return; }
      peer = value;
      for (const subscription of subscriptions) { subscription.attachPeer(); }
      void outbox.retry();
    }).catch(() => undefined);
  } catch (error) { stop(); throw error; }
  async function send(payload: object): Promise<void> {
    signal.throwIfAborted();
    if (!runtime.getState().isCurrentDeviceRegistered) { throw new Error('Link this device to sync.'); }
    const draft = { kind: PRIVATE_CONTACT_CONTROL_KIND, pubkey: account.pubkey,
      content: JSON.stringify(payload), tags: [['p', account.pubkey]], created_at: Math.floor(Date.now() / 1_000) };
    await runtime.sendEvent(account.pubkey, { ...draft, id: getEventHash(draft) });
    signal.throwIfAborted();
  }
  return {
    getState: () => runtime.getState(),
    async enable(): Promise<void> {
      signal.throwIfAborted();
      if (!runtime.getState().isCurrentDeviceRegistered) {
        if (!canSignAccount(account)) { throw new Error('Link this device using another device.'); }
        await refreshAuthorization();
        // The completed read above has already updated both runtime and session state.
        await runtime.registerCurrentDevice({ ownerPubkey: account.pubkey, clientLabel: 'Iris Social' });
      }
      await runtime.republishInvite();
      await runtime.setupUser(account.pubkey);
    },
    async link(): Promise<string> { return (await runtime.createLinkInvite(account.pubkey)).getUrl(); },
    async send(document: PrivateContactDocument): Promise<boolean> { await send(buildPrivateContactControl(document)); return true; },
    request: () => send(buildPrivateContactRequest(account.pubkey)),
    async wake() {
      await outbox.retry();
      await refreshAuthorization();
      if (runtime.getState().isCurrentDeviceRegistered) { await runtime.setupUser(account.pubkey); }
    },
    stop,
  };
}
export type PrivateRatchetRuntime = Awaited<ReturnType<typeof createPrivateRatchetRuntime>>;
