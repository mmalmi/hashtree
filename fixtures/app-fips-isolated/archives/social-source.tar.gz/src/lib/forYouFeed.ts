import type { CID } from '@hashtree/core';
import { awaitWithin } from './feedIndexTiming';
import { loadSocialGraphFrontier } from './socialGraphFrontier';
import { getLocalPersonalEventIndexRoot } from './personalEventIndexBrowser';
import { isNewerReplaceableEvent } from './socialRepository';
import { selectKnownViewerFollows } from './homeFeedContacts';
import {
  cloneHomeFeedContinuation,
  mergeUniqueFeedNotes,
  mixHomeFeedPage,
} from './homeFeedPagination';
import {
  extractFollowPubkeys,
  getThreadParentEventId,
  isHexEventId,
  isHexPubkey,
  isReplyEvent,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import type { NostrEventIndexReader } from './nostrIndexReader';
import type { FeedSnapshot } from './nostrIndexTypes';

export const FOR_YOU_INTERACTION_KINDS = [6, 7] as const;

const FOR_YOU_FEED_OWNER = 'for-you';
const FOR_YOU_MIN_INTERACTION_LIMIT = 32;
const FOR_YOU_MAX_INTERACTION_LIMIT = 128;
const FOR_YOU_QUICK_CONTACT_LOOKUP_MS = 250;
const FOR_YOU_FINAL_CONTACT_LOOKUP_MS = 2_500;
const FOR_YOU_FRONTIER_LOOKUP_MS = 400;
const FOR_YOU_TARGET_LOOKUP_LIMIT = 32;

export type ForYouFeedAuthors = {
  authors: string[];
  follows: string[];
  usedFrontier: boolean;
};

type ForYouFeedOptions = {
  knownViewerFollows?: string[];
  excludeEventIds?: ReadonlySet<string>;
  includeProfiles?: boolean;
  includeReplies?: boolean;
};

type StreamFeedSnapshotsByAuthors = (
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  follows: string[],
  feedOwnerPubkey: string,
  feedAuthors: string[],
  starterMode: FeedSnapshot['starterMode'],
  options: {
    additionalRootsPromise?: Promise<CID[]>;
    includeProfiles?: boolean;
    includeReplies?: boolean;
    emitEvery?: number;
    minimumNotes?: number;
  },
) => AsyncGenerator<FeedSnapshot, void, void>;

export type ForYouFeedDeps = {
  durablePostKinds: readonly number[];
  getRecentOverlayPostsByAuthors?: (authors: string[], limit: number) => RawEvent[];
  getRecentOverlayInteractionsByAuthors?: (authors: string[], limit: number) => RawEvent[];
  getOverlayEventById?: (eventId: string) => RawEvent | null;
  getLocalPersonalEventIndexRoot?: (pubkey: string) => Promise<CID | null>;
  resolvePersonalEventIndexRoot?: (pubkey: string) => Promise<CID | null>;
  getFeedProfilePubkeys: (
    viewerPubkey: string,
    feedOwnerPubkey: string,
    notes: RawEvent[],
  ) => string[];
  getReaderForRoot: (root: CID) => NostrEventIndexReader;
  getRootNhash: (root: CID) => string;
  loadEventById: (roots: CID[], eventId: string) => Promise<RawEvent | null>;
  loadLatestEventByAuthorKind: (
    roots: CID[],
    pubkey: string,
    kind: number,
  ) => Promise<RawEvent | null>;
  loadRecentInteractionsByAuthors: (
    roots: CID[],
    authors: string[],
    limit: number,
  ) => Promise<RawEvent[]>;
  loadProfilesForPubkeys: (root: CID, pubkeys: string[]) => Promise<Map<string, ProfileRecord>>;
  loadSocialGraphFrontier?: () => Promise<string[]>;
  streamFeedSnapshotsByAuthors: StreamFeedSnapshotsByAuthors;
};

export type ForYouFeedStreamOptions = ForYouFeedOptions & Pick<
  ForYouFeedDeps,
  'getRecentOverlayPostsByAuthors' | 'getRecentOverlayInteractionsByAuthors' | 'getOverlayEventById'
>;

type BuildPersonalizedForYouNotesOptions = {
  viewerPubkey: string;
  chronological: RawEvent[];
  interactions: RawEvent[];
  targets: RawEvent[];
  limit: number;
  durablePostKinds: readonly number[];
  excludeEventIds?: ReadonlySet<string>;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

function isEligibleForYouPost(
  event: RawEvent,
  viewerPubkey: string,
  durablePostKinds: readonly number[],
): boolean {
  return event.pubkey !== viewerPubkey
    && durablePostKinds.includes(event.kind)
    && !(event.kind === 1 && isReplyEvent(event));
}

export function selectForYouFeedAuthors(
  viewerPubkey: string,
  followedPubkeys: string[],
  frontierPubkeys: string[],
): ForYouFeedAuthors {
  const withoutViewer = (pubkeys: string[]): string[] => [...new Set(pubkeys)]
    .filter((pubkey) => isHexPubkey(pubkey) && pubkey !== viewerPubkey);
  const follows = withoutViewer(followedPubkeys);
  if (follows.length > 0) {
    return {
      authors: follows,
      follows,
      usedFrontier: false,
    };
  }

  return {
    authors: withoutViewer(frontierPubkeys),
    follows: [],
    usedFrontier: true,
  };
}

export function getForYouInteractionTargetEventId(event: RawEvent): string | null {
  if (!FOR_YOU_INTERACTION_KINDS.includes(
    event.kind as typeof FOR_YOU_INTERACTION_KINDS[number],
  )) {
    return null;
  }
  const eventId = getThreadParentEventId(event);
  return eventId && isHexEventId(eventId) ? eventId.toLowerCase() : null;
}

export function shouldRefreshForYouRanking(
  events: RawEvent[],
  rankingAuthors: readonly string[],
  rankingInteractions: readonly RawEvent[],
): boolean {
  const authors = new Set(rankingAuthors);
  const targetIds = new Set(rankingInteractions.flatMap((interaction) => {
    const targetId = getForYouInteractionTargetEventId(interaction);
    return targetId ? [targetId] : [];
  }));
  return events.some((event) => (
    (authors.has(event.pubkey) && getForYouInteractionTargetEventId(event) !== null)
    || targetIds.has(event.id)
  ));
}

export function buildPersonalizedForYouNotes(
  options: BuildPersonalizedForYouNotesOptions,
): RawEvent[] {
  const limit = Math.max(options.limit, 0);
  if (limit === 0) {
    return [];
  }

  const { chronological, discovery } = buildPersonalizedForYouPools(options);
  return mixHomeFeedPage({
    chronological,
    discovery,
    limit,
    mode: 'for-you',
  }).notes;
}

export function buildPersonalizedForYouPools(
  options: BuildPersonalizedForYouNotesOptions,
): { chronological: RawEvent[]; discovery: RawEvent[] } {
  const chronological = [...new Map(
    options.chronological
      .filter((event) => isEligibleForYouPost(
        event,
        options.viewerPubkey,
        options.durablePostKinds,
      ))
      .filter((event) => !options.excludeEventIds?.has(event.id))
      .map((event) => [event.id, event] as const),
  ).values()].sort(compareNewest);
  const targetsById = new Map(
    options.targets
      .filter((event) => isEligibleForYouPost(
        event,
        options.viewerPubkey,
        options.durablePostKinds,
      ))
      .filter((event) => !options.excludeEventIds?.has(event.id))
      .map((event) => [event.id, event] as const),
  );
  const backingByTarget = new Map<string, Map<string, RawEvent>>();
  for (const interaction of options.interactions) {
    if (interaction.kind === 7 && interaction.content.trim() === '-') {
      continue;
    }
    const targetId = getForYouInteractionTargetEventId(interaction);
    if (!targetId || !targetsById.has(targetId)) {
      continue;
    }
    const byAuthor = backingByTarget.get(targetId) ?? new Map<string, RawEvent>();
    const previous = byAuthor.get(interaction.pubkey);
    if (!previous || compareNewest(interaction, previous) < 0) {
      byAuthor.set(interaction.pubkey, interaction);
    }
    backingByTarget.set(targetId, byAuthor);
  }

  const discovery = [...backingByTarget.entries()]
    .map(([targetId, byAuthor]) => ({
      event: targetsById.get(targetId)!,
      supporterCount: byAuthor.size,
      latestInteractionAt: Math.max(...[...byAuthor.values()].map((event) => event.created_at)),
    }))
    .sort((left, right) => (
      right.supporterCount - left.supporterCount
      || right.latestInteractionAt - left.latestInteractionAt
      || compareNewest(left.event, right.event)
    ))
    .map((discovery) => discovery.event);

  return { chronological, discovery };
}

export function selectNewestForYouFollowPubkeys(
  events: Array<RawEvent | null>,
  viewerPubkey: string,
): string[] {
  let winner: RawEvent | null = null;
  for (const event of events) {
    if (!event || event.kind !== 3 || event.pubkey !== viewerPubkey) {
      continue;
    }
    if (!winner || isNewerReplaceableEvent(event, winner)) {
      winner = event;
    }
  }
  return extractFollowPubkeys(winner);
}

function sameAuthors(left: string[], right: string[]): boolean {
  if (left.length !== right.length) {
    return false;
  }
  const rightSet = new Set(right);
  return left.every((author) => rightSet.has(author));
}

function sameSelection(left: ForYouFeedAuthors, right: ForYouFeedAuthors): boolean {
  return left.usedFrontier === right.usedFrontier
    && sameAuthors(left.authors, right.authors)
    && sameAuthors(left.follows, right.follows);
}

async function loadFrontierWithinDeadline(
  loadFrontier: () => Promise<string[]>,
): Promise<string[]> {
  const result = await awaitWithin(
    loadFrontier().catch((error) => {
      console.warn('Failed to load the compact For You social-graph frontier', error);
      return [];
    }),
    FOR_YOU_FRONTIER_LOOKUP_MS,
  );
  return result.settled ? result.value : [];
}

async function* streamSelection(
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  selection: ForYouFeedAuthors,
  options: ForYouFeedOptions,
  deps: ForYouFeedDeps,
  additionalRootsPromise: Promise<CID[]>,
): AsyncGenerator<FeedSnapshot, void, void> {
  if (selection.authors.length === 0) {
    return;
  }
  const starterMode: FeedSnapshot['starterMode'] = selection.usedFrontier
    ? 'social-graph-snapshot'
    : null;
  // The projection retires overlay copies after painting them. Keep admitted
  // candidates throughout this stream so a later archive page cannot undo it.
  let recentPosts: RawEvent[] = [];
  const mergeRecentPosts = (snapshot: FeedSnapshot): FeedSnapshot => {
    recentPosts = mergeUniqueFeedNotes(recentPosts,
      deps.getRecentOverlayPostsByAuthors?.(selection.authors, limit) ?? []).slice(0, limit);
    const continuation = cloneHomeFeedContinuation(snapshot.continuation);
    const pools = buildPersonalizedForYouPools({
      viewerPubkey, limit, durablePostKinds: deps.durablePostKinds,
      excludeEventIds: options.excludeEventIds, interactions: [], targets: [],
      chronological: mergeUniqueFeedNotes(snapshot.notes, continuation?.chronologicalPool ?? [], recentPosts),
    });
    const mixed = mixHomeFeedPage({ ...pools, limit, mode: 'for-you' });
    if (continuation) {
      continuation.mode = 'for-you';
      continuation.chronologicalPool = mixed.chronologicalPool;
    }
    return { ...snapshot, notes: mixed.notes, continuation };
  };
  const cached = mergeRecentPosts({
    rootNhash: deps.getRootNhash(root), followCount: selection.follows.length,
    follows: selection.follows, profiles: new Map(), notes: [],
    feedOwnerPubkey: FOR_YOU_FEED_OWNER, usedSuggestedFeed: selection.usedFrontier, starterMode,
    continuation: {
      authors: selection.authors, chronologicalPool: [], discoveryPool: [],
      includeReplies: false, mode: 'for-you', nextLane: 'chronological',
      roots: [{ root, cursor: null, exhausted: false }],
    },
  });
  if (cached.notes.length > 0) { yield cached; }
  for await (const snapshot of deps.streamFeedSnapshotsByAuthors(
    root,
    reader,
    viewerPubkey,
    limit,
    selection.follows,
    FOR_YOU_FEED_OWNER,
    selection.authors,
    starterMode,
    {
      includeProfiles: false,
      includeReplies: options.includeReplies,
      additionalRootsPromise,
      minimumNotes: limit,
    },
  )) {
    yield mergeRecentPosts(snapshot);
  }
}

/**
 * Hashtree-only personalized feed. The compact frontier may paint first, but a
 * cold viewer contact list can still replace it as soon as the indexed event
 * arrives. Relay reads are never used here.
 */
export async function* streamPersonalizedForYouFeed(
  root: CID,
  viewerPubkey: string,
  limit: number,
  options: ForYouFeedOptions,
  deps: ForYouFeedDeps,
): AsyncGenerator<FeedSnapshot, void, void> {
  const reader = deps.getReaderForRoot(root);
  const knownFollows = selectKnownViewerFollows(options.knownViewerFollows, viewerPubkey);
  const candidateLimit = Math.min(
    limit + (options.excludeEventIds?.size ?? 0),
    Math.max(limit, 64),
  );
  const loadFrontier = deps.loadSocialGraphFrontier ?? loadSocialGraphFrontier;
  const resolvePersonalRoot = deps.resolvePersonalEventIndexRoot
    ?? deps.getLocalPersonalEventIndexRoot
    ?? getLocalPersonalEventIndexRoot;
  const personalRootPromise = resolvePersonalRoot(viewerPubkey).catch((error) => {
    console.warn('Failed to resolve the For You personal index root', error);
    return null;
  });
  const additionalRootsPromise = personalRootPromise.then((personalRoot) => (
    personalRoot && deps.getRootNhash(personalRoot) !== deps.getRootNhash(root)
      ? [personalRoot]
      : []
  ));
  const globalContactsPromise = (knownFollows.length > 0
    ? Promise.resolve(null)
    : deps.loadLatestEventByAuthorKind([root], viewerPubkey, 3))
    .catch((error) => {
      console.warn('Failed to read For You contacts from the global index', error);
      return null;
    });
  const localContactsPromise = (knownFollows.length > 0 ? Promise.resolve(null) : personalRootPromise
    .then(async (personalRoot) => {
      if (!personalRoot || deps.getRootNhash(personalRoot) === deps.getRootNhash(root)) {
        return null;
      }
      return await deps.loadLatestEventByAuthorKind([personalRoot], viewerPubkey, 3);
    }))
    .catch((error) => {
      console.warn('Failed to read For You contacts from the local personal index', error);
      return null;
    });
  const firstFollowList = new Promise<string[]>((resolve) => {
    let remaining = 2;
    const settle = (event: RawEvent | null): void => {
      const follows = extractFollowPubkeys(event);
      if (follows.length > 0 || --remaining === 0) {
        resolve(follows);
      }
    };
    void globalContactsPromise.then(settle);
    void localContactsPromise.then(settle);
  });
  const quickFollows = knownFollows.length > 0
    ? { settled: true as const, value: knownFollows }
    : await awaitWithin(firstFollowList, FOR_YOU_QUICK_CONTACT_LOOKUP_MS);
  const initialFollows = quickFollows.settled ? quickFollows.value : [];
  const frontierPubkeys = initialFollows.length > 0
    ? []
    : await loadFrontierWithinDeadline(loadFrontier);
  let selection = selectForYouFeedAuthors(viewerPubkey, initialFollows, frontierPubkeys);
  const finalContactsPromise = awaitWithin(
    Promise.all([globalContactsPromise, localContactsPromise]),
    FOR_YOU_FINAL_CONTACT_LOOKUP_MS,
  );
  let finalContactsHandled = false;
  let shouldStreamCorrectedSelection = false;

  const applyFinalContacts = async (
    finalContacts: Awaited<typeof finalContactsPromise>,
  ): Promise<void> => {
    finalContactsHandled = true;
    if (!finalContacts.settled || knownFollows.length > 0) {
      return;
    }
    const finalFollows = selectNewestForYouFollowPubkeys(finalContacts.value, viewerPubkey);
    const finalFrontier = finalFollows.length === 0 && frontierPubkeys.length === 0
      ? await loadFrontierWithinDeadline(loadFrontier)
      : frontierPubkeys;
    const finalSelection = selectForYouFeedAuthors(viewerPubkey, finalFollows, finalFrontier);
    if (!sameSelection(selection, finalSelection)) {
      selection = finalSelection;
      shouldStreamCorrectedSelection = true;
    }
  };

  let latestSnapshot: FeedSnapshot | null = null;
  if (selection.authors.length === 0) {
    latestSnapshot = {
      rootNhash: deps.getRootNhash(root),
      followCount: selection.follows.length,
      follows: selection.follows,
      profiles: new Map<string, ProfileRecord>(),
      notes: [],
      feedOwnerPubkey: FOR_YOU_FEED_OWNER,
      usedSuggestedFeed: selection.usedFrontier,
      starterMode: selection.usedFrontier ? 'social-graph-snapshot' : null,
    };
    yield latestSnapshot;
  } else {
    const iterator = streamSelection(
      root, reader, viewerPubkey, candidateLimit, selection, options, deps, additionalRootsPromise,
    )[Symbol.asyncIterator]();
    let nextSnapshot = iterator.next();
    const contactsResult = finalContactsPromise.then((value) => ({ type: 'contacts' as const, value }));
    let pendingContacts: typeof contactsResult | null = contactsResult;
    while (true) {
      const result = pendingContacts
        ? await Promise.race([
            nextSnapshot.then((value) => ({ type: 'snapshot' as const, value })),
            pendingContacts,
          ])
        : { type: 'snapshot' as const, value: await nextSnapshot };
      if (result.type === 'contacts') {
        pendingContacts = null;
        await applyFinalContacts(result.value);
        if (shouldStreamCorrectedSelection) {
          void iterator.return?.(undefined).catch((error) => {
            console.warn('Failed to stop the superseded For You stream', error);
          });
          break;
        }
        continue;
      }
      if (result.value.done) {
        break;
      }
      latestSnapshot = result.value.value;
      yield latestSnapshot;
      nextSnapshot = iterator.next();
    }
  }

  if (!finalContactsHandled) {
    await applyFinalContacts(await finalContactsPromise);
  }
  if (shouldStreamCorrectedSelection) {
    if (selection.authors.length === 0) {
      latestSnapshot = {
        rootNhash: deps.getRootNhash(root),
        followCount: 0,
        follows: [],
        profiles: new Map<string, ProfileRecord>(),
        notes: [],
        feedOwnerPubkey: FOR_YOU_FEED_OWNER,
        usedSuggestedFeed: false,
        starterMode: null,
      };
      yield latestSnapshot;
    } else {
      for await (const snapshot of streamSelection(
        root,
        reader,
        viewerPubkey,
        candidateLimit,
        selection,
        options,
        deps,
        additionalRootsPromise,
      )) {
        latestSnapshot = snapshot;
        yield snapshot;
      }
    }
  }

  const chronological = latestSnapshot?.notes ?? [];
  const interactionLimit = Math.min(
    FOR_YOU_MAX_INTERACTION_LIMIT,
    Math.max(FOR_YOU_MIN_INTERACTION_LIMIT, limit * 4),
  );
  const continuation = cloneHomeFeedContinuation(latestSnapshot?.continuation);
  const feedRoots = continuation?.roots.map((entry) => entry.root) ?? [root];
  const durableInteractions = [await deps.loadRecentInteractionsByAuthors(
    feedRoots,
    selection.authors,
    interactionLimit,
  ).catch((error) => {
    console.warn('Failed to read routed For You interactions', error);
    return [];
  })];
  const overlayInteractions = deps.getRecentOverlayInteractionsByAuthors?.(
    selection.authors,
    interactionLimit,
  ) ?? [];
  const interactions = mergeUniqueFeedNotes(...durableInteractions, overlayInteractions);
  const targetIds = [...new Set(interactions.flatMap((interaction) => {
    const eventId = getForYouInteractionTargetEventId(interaction);
    return eventId ? [eventId] : [];
  }))].slice(0, FOR_YOU_TARGET_LOOKUP_LIMIT);
  const targets = (await Promise.all(targetIds.map(async (eventId) => {
    const overlayEvent = deps.getOverlayEventById?.(eventId);
    if (overlayEvent) {
      return overlayEvent;
    }
    return await deps.loadEventById(feedRoots, eventId);
  }))).filter((event): event is RawEvent => Boolean(event));
  const chronologicalCandidates = mergeUniqueFeedNotes(
    chronological, continuation?.chronologicalPool ?? [],
    deps.getRecentOverlayPostsByAuthors?.(selection.authors, candidateLimit) ?? [],
  );
  const pools = buildPersonalizedForYouPools({
    viewerPubkey,
    chronological: chronologicalCandidates,
    interactions,
    targets,
    limit,
    durablePostKinds: deps.durablePostKinds,
    excludeEventIds: options.excludeEventIds,
  });
  const mixed = mixHomeFeedPage({
    chronological: pools.chronological,
    discovery: pools.discovery,
    limit,
    mode: 'for-you',
  });
  const notes = mixed.notes;
  if (continuation) {
    continuation.mode = 'for-you';
    continuation.chronologicalPool = mixed.chronologicalPool;
    continuation.discoveryPool = mixed.discoveryPool;
    continuation.nextLane = mixed.nextLane;
  }
  const profiles = options.includeProfiles === false
    ? new Map<string, ProfileRecord>()
    : await deps.loadProfilesForPubkeys(
        root,
        deps.getFeedProfilePubkeys(viewerPubkey, FOR_YOU_FEED_OWNER, notes),
      );
  const notesChanged = notes.length !== chronological.length
    || notes.some((event, index) => event.id !== chronological[index]?.id);
  if (notesChanged || options.includeProfiles !== false || !latestSnapshot) {
    yield {
      rootNhash: deps.getRootNhash(root),
      followCount: selection.follows.length,
      follows: selection.follows,
      profiles,
      notes,
      feedOwnerPubkey: FOR_YOU_FEED_OWNER,
      usedSuggestedFeed: selection.usedFrontier,
      starterMode: selection.usedFrontier ? 'social-graph-snapshot' : null,
      continuation,
    };
  }
}
