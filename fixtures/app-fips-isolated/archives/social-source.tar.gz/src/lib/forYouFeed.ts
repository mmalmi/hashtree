import type { CID } from '@hashtree/core';
import { awaitWithin } from './feedIndexTiming';
import { loadSocialGraphFrontier } from './socialGraphFrontier';
import { getLocalPersonalEventIndexRoot } from './personalEventIndexBrowser';
import { isNewerReplaceableEvent } from './socialRepository';
import { selectKnownViewerFollows } from './homeFeedContacts';
import {
  cloneHomeFeedContinuation,
  mergeUniqueFeedNotes,
  mixHomeFeedPage,
} from './homeFeedPagination';
import {
  extractFollowPubkeys,
  isHexPubkey,
  isReplyEvent,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import { collectTargetEndorsements, compareTargetEndorsements, getForYouInteractionTargetEventId, streamForYouRecommendations } from './forYouRecommendations';
export { FOR_YOU_INTERACTION_KINDS, getForYouInteractionTargetEventId } from './forYouRecommendations';
import type { NostrEventIndexReader } from './nostrIndexReader';
import type { FeedSnapshot } from './nostrIndexTypes';
import { fillSparseForYouSnapshot, type SparseForYouDeps } from './sparseForYouDiscovery';
import { preferRecentForYouPosts } from './forYouRecency';


const FOR_YOU_FEED_OWNER = 'for-you';
const FOR_YOU_MIN_INTERACTION_LIMIT = 32;
const FOR_YOU_MAX_INTERACTION_LIMIT = 128;
const FOR_YOU_QUICK_CONTACT_LOOKUP_MS = 250;
const FOR_YOU_SPARSE_FILL_DEADLINE_MS = 4_000;
const FOR_YOU_FINAL_CONTACT_LOOKUP_MS = 2_500;
const FOR_YOU_FRONTIER_LOOKUP_MS = 400;

export type ForYouFeedAuthors = {
  authors: string[];
  follows: string[];
  usedFrontier: boolean;
};

type ForYouFeedOptions = {
  knownViewerFollows?: string[];
  excludeEventIds?: ReadonlySet<string>;
  includeProfiles?: boolean;
  includeReplies?: boolean;
  mutedPubkeys?: ReadonlySet<string>;
};

type StreamFeedSnapshotsByAuthors = (
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  follows: string[],
  feedOwnerPubkey: string,
  feedAuthors: string[],
  starterMode: FeedSnapshot['starterMode'],
  options: {
    additionalRootsPromise?: Promise<CID[]>;
    includeProfiles?: boolean;
    includeReplies?: boolean;
    emitEvery?: number;
    minimumNotes?: number;
  },
) => AsyncGenerator<FeedSnapshot, void, void>;

export type ForYouFeedDeps = SparseForYouDeps & {
  getRecentOverlayPostsByAuthors?: (authors: string[], limit: number) => RawEvent[];
  getRecentOverlayInteractionsByAuthors?: (authors: string[], limit: number) => RawEvent[];
  getOverlayEventById?: (eventId: string) => RawEvent | null;
  getLocalPersonalEventIndexRoot?: (pubkey: string) => Promise<CID | null>;
  resolvePersonalEventIndexRoot?: (pubkey: string) => Promise<CID | null>;
  getReaderForRoot: (root: CID) => NostrEventIndexReader;
  getRootNhash: (root: CID) => string;
  loadEventById: (roots: CID[], eventId: string) => Promise<RawEvent | null>;
  /**
   * Target posts in one read (cache, Hashtree index and relays together).
   * Without it, each target is read from the archive by id.
   */
  loadEventsByIds?: (roots: CID[], ids: string[], onEvents?: (events: readonly RawEvent[]) => void) => Promise<RawEvent[]>;
  loadLatestEventByAuthorKind: (
    roots: CID[],
    pubkey: string,
    kind: number,
  ) => Promise<RawEvent | null>;
  /** Recent reactions and reposts by authors, from one read of all sources. */
  loadRecentInteractionsByAuthors: (
    roots: CID[],
    authors: string[],
    limit: number,
    onEvents?: (events: readonly RawEvent[]) => void,
  ) => Promise<RawEvent[]>;
  loadSocialGraphFrontier?: () => Promise<string[]>;
  streamFeedSnapshotsByAuthors: StreamFeedSnapshotsByAuthors;
};

export type ForYouFeedStreamOptions = ForYouFeedOptions & Pick<
  ForYouFeedDeps,
  'getRecentOverlayPostsByAuthors' | 'getRecentOverlayInteractionsByAuthors' | 'getOverlayEventById'
>;

type BuildPersonalizedForYouNotesOptions = {
  viewerPubkey: string;
  chronological: RawEvent[];
  interactions: RawEvent[];
  targets: RawEvent[];
  limit: number;
  durablePostKinds: readonly number[];
  excludeEventIds?: ReadonlySet<string>;
  mutedPubkeys?: ReadonlySet<string>;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

function isEligibleForYouPost(
  event: RawEvent,
  viewerPubkey: string,
  durablePostKinds: readonly number[],
  mutedPubkeys?: ReadonlySet<string>,
): boolean {
  return event.pubkey !== viewerPubkey
    && !mutedPubkeys?.has(event.pubkey)
    && event.kind !== 6
    && durablePostKinds.includes(event.kind)
    && !(event.kind === 1 && isReplyEvent(event));
}

export function selectForYouFeedAuthors(
  viewerPubkey: string,
  followedPubkeys: string[],
  frontierPubkeys: string[],
): ForYouFeedAuthors {
  const withoutViewer = (pubkeys: string[]): string[] => [...new Set(pubkeys)]
    .filter((pubkey) => isHexPubkey(pubkey) && pubkey !== viewerPubkey);
  const follows = withoutViewer(followedPubkeys);
  if (follows.length > 0) {
    return {
      authors: follows,
      follows,
      usedFrontier: false,
    };
  }

  return {
    authors: withoutViewer(frontierPubkeys),
    follows: [],
    usedFrontier: true,
  };
}

export function shouldRefreshForYouRanking(
  events: RawEvent[],
  rankingAuthors: readonly string[],
  rankingInteractions: readonly RawEvent[],
): boolean {
  const authors = new Set(rankingAuthors);
  const targetIds = new Set(rankingInteractions.flatMap((interaction) => {
    const targetId = getForYouInteractionTargetEventId(interaction);
    return targetId ? [targetId] : [];
  }));
  return events.some((event) => (
    (authors.has(event.pubkey) && getForYouInteractionTargetEventId(event) !== null)
    || targetIds.has(event.id)
  ));
}

export function buildPersonalizedForYouNotes(
  options: BuildPersonalizedForYouNotesOptions,
): RawEvent[] {
  const limit = Math.max(options.limit, 0);
  if (limit === 0) {
    return [];
  }

  const { chronological, discovery } = buildPersonalizedForYouPools(options);
  return mixHomeFeedPage({
    chronological,
    discovery,
    limit,
    mode: 'for-you',
  }).notes;
}

export function buildPersonalizedForYouPools(
  options: BuildPersonalizedForYouNotesOptions,
): { chronological: RawEvent[]; discovery: RawEvent[] } {
  const chronological = [...new Map(
    options.chronological
      .filter((event) => isEligibleForYouPost(
        event,
        options.viewerPubkey,
        options.durablePostKinds,
        options.mutedPubkeys,
      ))
      .filter((event) => !options.excludeEventIds?.has(event.id))
      .map((event) => [event.id, event] as const),
  ).values()].sort(compareNewest);
  const targetsById = new Map(
    options.targets
      .filter((event) => isEligibleForYouPost(
        event,
        options.viewerPubkey,
        options.durablePostKinds,
        options.mutedPubkeys,
      ))
      .filter((event) => !options.excludeEventIds?.has(event.id))
      .map((event) => [event.id, event] as const),
  );
  const discovery = [...collectTargetEndorsements(options.interactions, options.excludeEventIds)]
    .flatMap(([targetId, endorsements]) => {
      const event = targetsById.get(targetId);
      return event ? [{ event, endorsements }] : [];
    })
    .sort((left, right) => (
      compareTargetEndorsements(left.endorsements, right.endorsements)
      || compareNewest(left.event, right.event)
    ))
    .map((discovery) => discovery.event);

  return { chronological: preferRecentForYouPosts(chronological), discovery: preferRecentForYouPosts(discovery) };
}

export function selectNewestForYouFollowPubkeys(
  events: Array<RawEvent | null>,
  viewerPubkey: string,
): string[] {
  let winner: RawEvent | null = null;
  for (const event of events) {
    if (!event || event.kind !== 3 || event.pubkey !== viewerPubkey) {
      continue;
    }
    if (!winner || isNewerReplaceableEvent(event, winner)) {
      winner = event;
    }
  }
  return extractFollowPubkeys(winner);
}

function sameAuthors(left: string[], right: string[]): boolean {
  if (left.length !== right.length) {
    return false;
  }
  const rightSet = new Set(right);
  return left.every((author) => rightSet.has(author));
}

function sameSelection(left: ForYouFeedAuthors, right: ForYouFeedAuthors): boolean {
  return left.usedFrontier === right.usedFrontier
    && sameAuthors(left.authors, right.authors)
    && sameAuthors(left.follows, right.follows);
}

async function loadFrontierWithinDeadline(
  loadFrontier: () => Promise<string[]>,
): Promise<string[]> {
  const result = await awaitWithin(
    loadFrontier().catch((error) => {
      console.warn('Failed to load the compact For You social-graph frontier', error);
      return [];
    }),
    FOR_YOU_FRONTIER_LOOKUP_MS,
  );
  return result.settled ? result.value : [];
}

async function* streamSelection(
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  selection: ForYouFeedAuthors,
  options: ForYouFeedOptions,
  deps: ForYouFeedDeps,
  additionalRootsPromise: Promise<CID[]>,
): AsyncGenerator<FeedSnapshot, void, void> {
  const authors = selection.authors.filter(author => !options.mutedPubkeys?.has(author));
  if (authors.length === 0) {
    return;
  }
  const starterMode: FeedSnapshot['starterMode'] = selection.usedFrontier
    ? 'social-graph-snapshot'
    : null;
  const candidateLimit = Math.min(
    limit + (options.excludeEventIds?.size ?? 0),
    Math.max(limit, 64),
  );
  // Followed posts and the originals endorsed by follows are independent sources.
  // Either can paint before the other has opened its index or found a relay.
  let source: FeedSnapshot = {
    rootNhash: deps.getRootNhash(root), followCount: selection.follows.length,
    follows: selection.follows, profiles: new Map(), notes: [],
    feedOwnerPubkey: FOR_YOU_FEED_OWNER, usedSuggestedFeed: selection.usedFrontier, starterMode,
    continuation: {
      authors, chronologicalPool: [], discoveryPool: [],
      includeReplies: false, mode: 'for-you', nextLane: 'chronological',
      roots: [{ root, cursor: null, exhausted: false }],
    },
  };
  let recentPosts: RawEvent[] = [];
  let signals: RawEvent[] = [];
  let targets: RawEvent[] = [];
  function snapshot(): FeedSnapshot {
    recentPosts = mergeUniqueFeedNotes(recentPosts,
      deps.getRecentOverlayPostsByAuthors?.(authors, candidateLimit) ?? []).slice(0, candidateLimit);
    const continuation = cloneHomeFeedContinuation(source.continuation);
    const pools = buildPersonalizedForYouPools({
      viewerPubkey, limit, durablePostKinds: deps.durablePostKinds,
      mutedPubkeys: options.mutedPubkeys, excludeEventIds: options.excludeEventIds,
      interactions: signals, targets,
      chronological: mergeUniqueFeedNotes(source.notes, continuation?.chronologicalPool ?? [], recentPosts),
    });
    const mixed = mixHomeFeedPage({ ...pools, limit, mode: 'for-you' });
    if (continuation) {
      continuation.mode = 'for-you';
      continuation.chronologicalPool = mixed.chronologicalPool;
      continuation.discoveryPool = mixed.discoveryPool;
      continuation.nextLane = mixed.nextLane;
    }
    return { ...source, notes: mixed.notes, continuation,
      ...(signals.length ? { rankingEngagementEvents: signals } : {}) };
  }

  const posts = deps.streamFeedSnapshotsByAuthors(root, reader, viewerPubkey, candidateLimit,
    selection.follows, FOR_YOU_FEED_OWNER, authors, starterMode, {
      includeProfiles: false, includeReplies: options.includeReplies,
      additionalRootsPromise, minimumNotes: limit,
    });
  const recommendations = streamForYouRecommendations(root, authors, Math.min(FOR_YOU_MAX_INTERACTION_LIMIT,
    Math.max(FOR_YOU_MIN_INTERACTION_LIMIT, limit * 4)), options, deps);
  const nextPosts = () => posts.next().then(result => ({ kind: 'posts' as const, result }));
  const nextRecommendations = () => recommendations.next().then(result => ({ kind: 'recommendations' as const, result }));
  let postsRead: ReturnType<typeof nextPosts> | undefined = nextPosts();
  let recommendationsRead: ReturnType<typeof nextRecommendations> | undefined = nextRecommendations();
  try {
    const cached = snapshot();
    if (cached.notes.length) { yield cached; }
    while (postsRead || recommendationsRead) {
      const update = await (postsRead && recommendationsRead
        ? Promise.race([postsRead, recommendationsRead]) : (postsRead ?? recommendationsRead)!);
      if (update.kind === 'posts') {
        if (update.result.done) { postsRead = undefined; continue; }
        source = update.result.value;
        postsRead = nextPosts();
      } else {
        if (update.result.done) { recommendationsRead = undefined; continue; }
        signals = mergeUniqueFeedNotes(signals, update.result.value.interactions);
        targets = mergeUniqueFeedNotes(targets, update.result.value.targets);
        recommendationsRead = nextRecommendations();
      }
      yield snapshot();
    }
  } finally {
    if (postsRead) { void posts.return(undefined).catch(() => undefined); }
    if (recommendationsRead) { void recommendations.return(undefined).catch(() => undefined); }
  }
}

/**
 * The compact frontier may paint first, but a
 * cold viewer contact list can still replace it as soon as the indexed event
 * arrives.
 */
export async function* streamPersonalizedForYouFeed(
  root: CID,
  viewerPubkey: string,
  limit: number,
  options: ForYouFeedOptions,
  deps: ForYouFeedDeps,
): AsyncGenerator<FeedSnapshot, void, void> {
  const reader = deps.getReaderForRoot(root);
  const knownFollows = selectKnownViewerFollows(options.knownViewerFollows, viewerPubkey);
  const loadFrontier = deps.loadSocialGraphFrontier ?? loadSocialGraphFrontier;
  const resolvePersonalRoot = deps.resolvePersonalEventIndexRoot
    ?? deps.getLocalPersonalEventIndexRoot
    ?? getLocalPersonalEventIndexRoot;
  const personalRootPromise = viewerPubkey
    ? resolvePersonalRoot(viewerPubkey).catch((error) => {
        console.warn('Failed to resolve the For You personal index root', error);
        return null;
      })
    : Promise.resolve(null);
  const additionalRootsPromise = personalRootPromise.then((personalRoot) => (
    personalRoot && deps.getRootNhash(personalRoot) !== deps.getRootNhash(root)
      ? [personalRoot]
      : []
  ));
  const globalContactsPromise = (!viewerPubkey || knownFollows.length > 0
    ? Promise.resolve(null)
    : deps.loadLatestEventByAuthorKind([root], viewerPubkey, 3))
    .catch((error) => {
      console.warn('Failed to read For You contacts from the global index', error);
      return null;
    });
  const localContactsPromise = (knownFollows.length > 0 ? Promise.resolve(null) : personalRootPromise
    .then(async (personalRoot) => {
      if (!personalRoot || deps.getRootNhash(personalRoot) === deps.getRootNhash(root)) {
        return null;
      }
      return await deps.loadLatestEventByAuthorKind([personalRoot], viewerPubkey, 3);
    }))
    .catch((error) => {
      console.warn('Failed to read For You contacts from the local personal index', error);
      return null;
    });
  const firstFollowList = new Promise<string[]>((resolve) => {
    let remaining = 2;
    const settle = (event: RawEvent | null): void => {
      const follows = extractFollowPubkeys(event);
      if (follows.length > 0 || --remaining === 0) {
        resolve(follows);
      }
    };
    void globalContactsPromise.then(settle);
    void localContactsPromise.then(settle);
  });
  const quickFollows = knownFollows.length > 0
    ? { settled: true as const, value: knownFollows }
    : await awaitWithin(firstFollowList, FOR_YOU_QUICK_CONTACT_LOOKUP_MS);
  const initialFollows = quickFollows.settled ? quickFollows.value : [];
  const frontierPubkeys = initialFollows.length > 0
    ? []
    : await loadFrontierWithinDeadline(loadFrontier);
  let selection = selectForYouFeedAuthors(viewerPubkey, initialFollows, frontierPubkeys);
  const finalContactsPromise = awaitWithin(
    Promise.all([globalContactsPromise, localContactsPromise]),
    FOR_YOU_FINAL_CONTACT_LOOKUP_MS,
  );
  let finalContactsHandled = false;
  let shouldStreamCorrectedSelection = false;

  const applyFinalContacts = async (
    finalContacts: Awaited<typeof finalContactsPromise>,
  ): Promise<void> => {
    finalContactsHandled = true;
    if (!finalContacts.settled || knownFollows.length > 0) {
      return;
    }
    const finalFollows = selectNewestForYouFollowPubkeys(finalContacts.value, viewerPubkey);
    const finalFrontier = finalFollows.length === 0 && frontierPubkeys.length === 0
      ? await loadFrontierWithinDeadline(loadFrontier)
      : frontierPubkeys;
    const finalSelection = selectForYouFeedAuthors(viewerPubkey, finalFollows, finalFrontier);
    if (!sameSelection(selection, finalSelection)) {
      selection = finalSelection;
      shouldStreamCorrectedSelection = true;
    }
  };

  let latestSnapshot: FeedSnapshot | null = null;
  if (selection.authors.length === 0) {
    latestSnapshot = {
      rootNhash: deps.getRootNhash(root),
      followCount: selection.follows.length,
      follows: selection.follows,
      profiles: new Map<string, ProfileRecord>(),
      notes: [],
      feedOwnerPubkey: FOR_YOU_FEED_OWNER,
      usedSuggestedFeed: selection.usedFrontier,
      starterMode: selection.usedFrontier ? 'social-graph-snapshot' : null,
    };
    yield latestSnapshot;
  } else {
    const iterator = streamSelection(
      root, reader, viewerPubkey, limit, selection, options, deps, additionalRootsPromise,
    )[Symbol.asyncIterator]();
    let nextSnapshot = iterator.next();
    const contactsResult = finalContactsPromise.then((value) => ({ type: 'contacts' as const, value }));
    let pendingContacts: typeof contactsResult | null = contactsResult;
    while (true) {
      const result = pendingContacts
        ? await Promise.race([
            nextSnapshot.then((value) => ({ type: 'snapshot' as const, value })),
            pendingContacts,
          ])
        : { type: 'snapshot' as const, value: await nextSnapshot };
      if (result.type === 'contacts') {
        pendingContacts = null;
        await applyFinalContacts(result.value);
        if (shouldStreamCorrectedSelection) {
          void iterator.return?.(undefined).catch((error) => {
            console.warn('Failed to stop the superseded For You stream', error);
          });
          break;
        }
        continue;
      }
      if (result.value.done) {
        break;
      }
      latestSnapshot = result.value.value;
      yield latestSnapshot;
      nextSnapshot = iterator.next();
    }
  }

  if (!finalContactsHandled) {
    await applyFinalContacts(await finalContactsPromise);
  }
  if (shouldStreamCorrectedSelection) {
    if (selection.authors.length === 0) {
      latestSnapshot = {
        rootNhash: deps.getRootNhash(root),
        followCount: 0,
        follows: [],
        profiles: new Map<string, ProfileRecord>(),
        notes: [],
        feedOwnerPubkey: FOR_YOU_FEED_OWNER,
        usedSuggestedFeed: false,
        starterMode: null,
      };
      yield latestSnapshot;
    } else {
      for await (const snapshot of streamSelection(
        root,
        reader,
        viewerPubkey,
        limit,
        selection,
        options,
        deps,
        additionalRootsPromise,
      )) {
        latestSnapshot = snapshot;
        yield snapshot;
      }
    }
  }

  if (!latestSnapshot) { return; }
  let snapshot: FeedSnapshot = latestSnapshot;
  const feedRoots = snapshot.continuation?.roots.map(entry => entry.root) ?? [root];
  if (options.includeProfiles !== false) {
    snapshot = { ...snapshot, profiles: await deps.loadProfilesForPubkeys(root,
      deps.getFeedProfilePubkeys(viewerPubkey, FOR_YOU_FEED_OWNER, snapshot.notes)) };
    yield snapshot;
  }
  // Direct and endorsed posts paint before sparse recommendations are read.
  const filled = await awaitWithin(fillSparseForYouSnapshot(snapshot, {
    ...options, root, roots: feedRoots, viewerPubkey, limit,
  }, deps), FOR_YOU_SPARSE_FILL_DEADLINE_MS);
  if (filled.settled && filled.value) { yield filled.value; }
}
