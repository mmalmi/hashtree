import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import { isBrowserRelayContentEnabled } from './browserEventReadRouter';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  DURABLE_PROFILE_POST_KINDS,
  getReaderForRoot,
  getRootNhash,
  loadProfileRecord,
} from './nostrIndex';
import type {
  RecentTextNoteCursor,
  RecentTextNoteQueryOptions,
} from './recentTextNoteCursor';
import type { ProfileLikedNote } from './profileLikes';
import { routedProfileHistory } from './routedEventReads';

export type ProfileNotesRootContinuation = {
  rootNhash: string;
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
  noteCount: number;
};

export type ProfileSnapshot = {
  durableCursor?: RecentTextNoteCursor | null;
  durableHasMore?: boolean;
  durableNoteCount?: number;
  durableRootContinuations?: ProfileNotesRootContinuation[];
  rootNhash: string;
  profile: ProfileRecord | null;
  notes: RawEvent[];
  likedNotes?: ProfileLikedNote[];
  likedNotesHasMore?: boolean;
};

export type ProfileNotesPage = {
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
  notes: RawEvent[];
};

type ProfileNotesPageDeps = {
  loadRoutedNotes?: typeof loadProfileNotes;
};

export async function loadProfileNotes(
  root: CID,
  pubkey: string,
  limit: number,
  options: RecentTextNoteQueryOptions = {},
): Promise<RawEvent[]> {
  const profileOptions: RecentTextNoteQueryOptions = {
    ...options,
    includeReplies: true,
    kinds: DURABLE_PROFILE_POST_KINDS,
  };
  return await routedProfileHistory(
    [root],
    pubkey,
    DURABLE_PROFILE_POST_KINDS,
    limit,
    profileOptions.before,
  )
    .catch((error) => {
      console.warn('Failed to load routed profile notes', error);
      return [] as RawEvent[];
    });
}

export async function* streamProfileNotes(
  root: CID,
  pubkey: string,
  limit: number,
  options: RecentTextNoteQueryOptions = {},
): AsyncGenerator<RawEvent[], void, void> {
  const profileOptions: RecentTextNoteQueryOptions = {
    ...options,
    includeReplies: true,
    kinds: DURABLE_PROFILE_POST_KINDS,
  };
  for await (const notes of getReaderForRoot(root)
    .streamRecentTextNotesByAuthor(pubkey, limit, profileOptions)) {
    yield notes;
    if (notes.length >= limit) {
      return;
    }
  }
}

type ProfileRelayCacheFillDeps = {
  enabled?: () => boolean;
  loadHistory?: typeof routedProfileHistory;
  streamIndexed?: typeof streamProfileNotes;
};

/**
 * Stream the immutable profile page first, then fill a bounded local cache from
 * configured Nostr relays when the hosted archive does not yet contain the
 * author's full history.
 */
export async function* streamProfileNotesWithCacheFill(
  root: CID,
  pubkey: string,
  limit: number,
  options: RecentTextNoteQueryOptions = {},
  deps: ProfileRelayCacheFillDeps = {},
): AsyncGenerator<RawEvent[], void, void> {
  let indexedNotes: RawEvent[] = [];
  const streamIndexed = deps.streamIndexed ?? streamProfileNotes;
  try {
    for await (const notes of streamIndexed(root, pubkey, limit, options)) {
      indexedNotes = notes;
      yield notes;
    }
  } catch (error) {
    console.warn('Failed to stream indexed profile notes before relay cache fill', error);
  }

  const enabled = deps.enabled ?? isBrowserRelayContentEnabled;
  if (!enabled()) {
    return;
  }

  const loadHistory = deps.loadHistory ?? routedProfileHistory;
  try {
    const relayNotes = await loadHistory(
      [root],
      pubkey,
      DURABLE_PROFILE_POST_KINDS,
      limit,
      options.before,
    );
    const mergedNotes = mergeNotesByNewest(indexedNotes, relayNotes).slice(0, limit);
    if (
      mergedNotes.length !== indexedNotes.length
      || mergedNotes.some((event, index) => event.id !== indexedNotes[index]?.id)
    ) {
      yield mergedNotes;
    }
  } catch (error) {
    console.warn('Failed to fill profile history from configured Nostr relays', error);
  }
}

export async function loadProfileNotesPage(
  root: CID,
  pubkey: string,
  limit: number,
  before: RecentTextNoteCursor,
  deps: ProfileNotesPageDeps = {},
): Promise<ProfileNotesPage> {
  const pageSize = Math.max(0, limit);
  if (pageSize === 0) {
    return { cursor: before, hasMore: true, notes: [] };
  }

  const candidates = await (deps.loadRoutedNotes ?? loadProfileNotes)(
    root,
    pubkey,
    pageSize + 1,
    { before },
  );
  const pageNotes = candidates.slice(0, pageSize);
  const boundary = pageNotes.at(-1);
  return {
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : before,
    hasMore: candidates.length > pageSize,
    notes: pageNotes,
  };
}

export async function loadProfileNotesPageWithCacheFill(
  root: CID,
  pubkey: string,
  limit: number,
  before: RecentTextNoteCursor,
  deps: ProfileNotesPageDeps = {},
): Promise<ProfileNotesPage> {
  const pageSize = Math.max(0, limit);
  if (pageSize === 0) {
    return { cursor: before, hasMore: true, notes: [] };
  }

  // The routed query owns both immutable roots and the optional relay tail.
  // Pagination does not need the initial progressive archive-only stream, and
  // avoiding it keeps a local personal-root traversal out of the renderer.
  const candidates = await (deps.loadRoutedNotes ?? loadProfileNotes)(
    root,
    pubkey,
    pageSize + 1,
    { before },
  );
  const pageNotes = candidates.slice(0, pageSize);
  const boundary = pageNotes.at(-1);
  return {
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : before,
    hasMore: candidates.length > pageSize,
    notes: pageNotes,
  };
}

export async function loadProfile(
  root: CID,
  pubkey: string,
  limit: number,
): Promise<ProfileSnapshot> {
  const [profile, indexedNotes] = await Promise.all([
    loadProfileRecord(root, pubkey),
    loadProfileNotes(root, pubkey, limit),
  ]);
  const rootNhash = getRootNhash(root);
  const boundary = indexedNotes.at(-1);
  const continuation: ProfileNotesRootContinuation = {
    rootNhash,
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : null,
    hasMore: indexedNotes.length >= limit,
    noteCount: indexedNotes.length,
  };

  return {
    durableCursor: continuation.cursor,
    durableHasMore: continuation.hasMore,
    durableNoteCount: indexedNotes.length,
    durableRootContinuations: [continuation],
    rootNhash,
    profile,
    notes: indexedNotes,
  };
}
