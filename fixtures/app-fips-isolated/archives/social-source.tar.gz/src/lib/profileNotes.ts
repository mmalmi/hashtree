import type { CID } from '@hashtree/core';
import { mergeNotesByNewest } from './appDataUtils';
import { isBrowserRelayContentEnabled, queryBrowserEvents } from './browserEventReadRouter';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  DURABLE_PROFILE_POST_KINDS,
  getReaderForRoot,
  getRootNhash,
  loadProfileRecord,
} from './nostrIndex';
import type {
  RecentTextNoteCursor,
  RecentTextNoteQueryOptions,
} from './recentTextNoteCursor';
import type { ProfileLikedNote } from './profileLikes';
import { routedProfileHistory, routedProfileHistoryPage } from './routedEventReads';
import { readProfileRelayHistory } from './profileRelayHistory';

export type ProfileNotesRootContinuation = {
  rootNhash: string;
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
  noteCount: number;
};

export type ProfileSnapshot = {
  durableCursor?: RecentTextNoteCursor | null;
  durableHasMore?: boolean;
  durableNoteCount?: number;
  durableRootContinuations?: ProfileNotesRootContinuation[];
  relayContinuation?: Omit<ProfileNotesRootContinuation, 'rootNhash'>;
  rootNhash: string;
  profile: ProfileRecord | null;
  notes: RawEvent[];
  likedNotes?: ProfileLikedNote[];
  likedNotesHasMore?: boolean;
};

export type ProfileNotesPage = {
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
  notes: RawEvent[];
};

type ProfileNotesPageDeps = {
  signal?: AbortSignal;
  loadRoutedNotes?: typeof loadProfileNotes;
};

export async function loadProfileNotes(
  root: CID,
  pubkey: string,
  limit: number,
  options: RecentTextNoteQueryOptions = {},
): Promise<RawEvent[]> {
  const profileOptions: RecentTextNoteQueryOptions = {
    ...options,
    includeReplies: true,
    kinds: DURABLE_PROFILE_POST_KINDS,
  };
  return await routedProfileHistory(
    [root],
    pubkey,
    DURABLE_PROFILE_POST_KINDS,
    limit,
    profileOptions.before,
  )
    .catch((error) => {
      console.warn('Failed to load routed profile notes', error);
      return [] as RawEvent[];
    });
}

type ProfileStreamOptions = RecentTextNoteQueryOptions & {
  onIndexedNotes?: (notes: RawEvent[], complete: boolean) => void;
};

export async function* streamProfileNotes(
  root: CID,
  pubkey: string,
  limit: number,
  options: ProfileStreamOptions = {},
): AsyncGenerator<RawEvent[], void, void> {
  const { onIndexedNotes, ...indexOptions } = options;
  const profileOptions: RecentTextNoteQueryOptions = {
    ...indexOptions,
    includeReplies: true,
    kinds: DURABLE_PROFILE_POST_KINDS,
  };
  let latest: RawEvent[] = [];
  for await (const notes of getReaderForRoot(root)
    .streamRecentTextNotesByAuthor(pubkey, limit, profileOptions)) {
    latest = notes;
    onIndexedNotes?.(notes, false);
    yield notes;
    if (notes.length >= limit) {
      break;
    }
  }
  onIndexedNotes?.(latest, true);
}

type ProfileRelayCacheFillDeps = {
  enabled?: () => boolean;
  loadHistory?: typeof routedProfileHistory;
  streamIndexed?: typeof streamProfileNotes;
};

/**
 * Stream the author-ordered profile index while the router reads the same page
 * from the cache and relays, and yield the merge as soon as either answers.
 * The archive can lag behind an author's newest posts.
 */
export async function* streamProfileNotesWithCacheFill(
  root: CID,
  pubkey: string,
  limit: number,
  options: ProfileStreamOptions = {},
  deps: ProfileRelayCacheFillDeps = {},
): AsyncGenerator<RawEvent[], void, void> {
  const { onIndexedNotes, ...indexOptions } = options;
  const streamIndexed = deps.streamIndexed ?? streamProfileNotes;
  const enabled = deps.enabled ?? isBrowserRelayContentEnabled;
  // The author-ordered index stream above covers the archive; this read adds
  // the cache and relays, whose newest posts the archive may not have yet.
  const loadHistory = deps.loadHistory ?? (async (_roots, author, kinds, historyLimit, before) => (
    await readProfileRelayHistory(author, kinds, historyLimit, before)
  ).events);
  let indexedNotes: RawEvent[] = [];
  let routedNotes: RawEvent[] = [];
  let emitted: RawEvent[] = [];
  let yielded = false;
  const merged = (): RawEvent[] => mergeNotesByNewest(indexedNotes, routedNotes).slice(0, limit);
  const changed = (notes: RawEvent[]): boolean => (
    notes.length !== emitted.length || notes.some((event, index) => event.id !== emitted[index]?.id)
  );

  type Step = { kind: 'indexed'; result: IteratorResult<RawEvent[]> } | { kind: 'routed' };
  let routed: Promise<Step> | null = enabled()
    ? loadHistory([root], pubkey, DURABLE_PROFILE_POST_KINDS, limit, options.before)
      .then((notes) => { routedNotes = notes; return { kind: 'routed' as const }; })
      .catch((error: unknown) => {
        console.warn('Failed to read profile history', error);
        return { kind: 'routed' as const };
      })
    : null;
  onIndexedNotes?.([], false);
  const iterator = streamIndexed(root, pubkey, limit, indexOptions)[Symbol.asyncIterator]();
  let indexed: Promise<Step> | null = iterator.next().then((result) => ({ kind: 'indexed' as const, result }));
  try {
    while (indexed || routed) {
      let step: Step;
      try {
        step = await Promise.race([indexed, routed].filter((value): value is Promise<Step> => value !== null));
      } catch (error) {
        console.warn('Failed to stream indexed profile notes', error);
        indexed = null;
        continue;
      }
      if (step.kind === 'routed') {
        routed = null;
      } else if (step.result.done) {
        indexed = null;
        onIndexedNotes?.(indexedNotes, true);
      } else {
        indexedNotes = step.result.value;
        onIndexedNotes?.(indexedNotes, false);
        indexed = iterator.next().then((result) => ({ kind: 'indexed' as const, result }));
      }
      const notes = merged();
      // The first indexed page is yielded even when empty, as before.
      if (changed(notes) || (!yielded && step.kind === 'indexed')) {
        yielded = true;
        emitted = notes;
        yield notes;
      }
      if (step.kind === 'routed' && routedNotes.length >= limit) { return; }
    }
  } finally {
    if (indexed) {void iterator.return?.(undefined);}
  }
}

export async function loadProfileNotesPage(
  root: CID,
  pubkey: string,
  limit: number,
  before: RecentTextNoteCursor,
  deps: ProfileNotesPageDeps = {},
): Promise<ProfileNotesPage> {
  const pageSize = Math.max(0, limit);
  if (pageSize === 0) {
    return { cursor: before, hasMore: true, notes: [] };
  }

  const candidates = await (deps.loadRoutedNotes ?? loadProfileNotes)(
    root,
    pubkey,
    pageSize + 1,
    { before },
  );
  const pageNotes = candidates.slice(0, pageSize);
  const boundary = pageNotes.at(-1);
  return {
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : before,
    hasMore: candidates.length > pageSize,
    notes: pageNotes,
  };
}

export async function loadProfileNotesPageWithCacheFill(
  root: CID,
  pubkey: string,
  limit: number,
  before: RecentTextNoteCursor,
  deps: ProfileNotesPageDeps = {},
): Promise<ProfileNotesPage> {
  if (deps.loadRoutedNotes) { return loadProfileNotesPage(root, pubkey, limit, before, deps); }
  return readProfilePage(root, pubkey, limit, before, 'archive', deps.signal);
}

export async function readProfilePage(
  root: CID,
  pubkey: string,
  limit: number,
  before: RecentTextNoteCursor | undefined,
  source: 'archive',
  signal?: AbortSignal,
  read?: typeof routedProfileHistoryPage,
): Promise<ProfileNotesPage> {
  if (limit <= 0) { return { notes: [], cursor: before ?? null, hasMore: true }; }
  const { events, complete } = await (read ?? routedProfileHistoryPage)([root], pubkey, DURABLE_PROFILE_POST_KINDS, limit + 1, before,
    (roots, filters, options) => queryBrowserEvents(roots, filters, { ...options, signal }, source));
  const notes = events.slice(0, limit);
  const boundary = notes.at(-1);
  return {
    notes,
    cursor: boundary && (complete || events.length > limit)
      ? { createdAt: boundary.created_at, eventId: boundary.id } : before ?? null,
    hasMore: events.length > limit || !complete,
  };
}

export async function loadProfile(
  root: CID,
  pubkey: string,
  limit: number,
): Promise<ProfileSnapshot> {
  const [profile, indexedNotes] = await Promise.all([
    loadProfileRecord(root, pubkey),
    loadProfileNotes(root, pubkey, limit),
  ]);
  const rootNhash = getRootNhash(root);
  const boundary = indexedNotes.at(-1);
  const continuation: ProfileNotesRootContinuation = {
    rootNhash,
    cursor: boundary
      ? { createdAt: boundary.created_at, eventId: boundary.id }
      : null,
    hasMore: indexedNotes.length >= limit,
    noteCount: indexedNotes.length,
  };

  return {
    durableCursor: continuation.cursor,
    durableHasMore: continuation.hasMore,
    durableNoteCount: indexedNotes.length,
    durableRootContinuations: [continuation],
    rootNhash,
    profile,
    notes: indexedNotes,
  };
}
