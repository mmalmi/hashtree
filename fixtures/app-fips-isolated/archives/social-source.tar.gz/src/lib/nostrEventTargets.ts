import { isHexEventId, type RawEvent } from './nostr';

/**
 * NIP-25 and nostr-tools select the final lowercase `e` tag when an event has
 * several candidates. Invalid trailing tags do not erase an earlier valid id.
 */
export function getLastValidLowercaseEventTarget(event: RawEvent): string | null {
  for (let index = event.tags.length - 1; index >= 0; index -= 1) {
    const tag = event.tags[index];
    if (tag?.[0] !== 'e' || !isHexEventId(tag[1] ?? '')) {continue;}
    return tag[1]!.toLowerCase();
  }
  return null;
}
