import { nhashEncode, type CID, type Store } from '@hashtree/core';
import { withPostSearchAbortTimeout } from './postSearchAbort';
import type { PostSearchExecution } from './postSearchExecution';
import {
  buildPublisherResponse,
  type PublisherResponse,
} from './postSearchPublisherResponse';
import { PostSearchV5RoutedSearch } from './postSearchV5RoutedSearch';
import {
  openPostSearchV5RoutedCatalog,
  type PostSearchV5RoutedCatalogLookup,
} from '../server/postSearchV5RoutedCatalog';

const ROUTED_CATALOG_CACHE_LIMIT = 8;

export interface PostSearchV5RoutedPublisherOptions {
  signal: AbortSignal | null;
  limit: number;
  operator: 'or' | 'and';
  authors: ReadonlySet<string> | null;
  kinds: ReadonlySet<number> | null;
  since: number | null;
  until: number | null;
  requestTimeoutMs: number;
}

export class PostSearchV5RoutedFederation {
  private readonly search: PostSearchV5RoutedSearch;
  private readonly catalogs = new Map<string, Promise<PostSearchV5RoutedCatalogLookup>>();

  constructor(store: Store, execution: PostSearchExecution) {
    this.search = new PostSearchV5RoutedSearch(store, execution);
    this.store = store;
  }

  private readonly store: Store;

  async warm(publisherId: string, root: CID): Promise<void> {
    this.assertPublisher(await this.openCatalog(root), publisherId);
  }

  async searchPublisher(
    publisherId: string,
    root: CID,
    query: string,
    options: PostSearchV5RoutedPublisherOptions,
  ): Promise<PublisherResponse> {
    const catalog = await withPostSearchAbortTimeout(
      async () => await this.openCatalog(root),
      options.requestTimeoutMs,
      options.signal,
    );
    this.assertPublisher(catalog, publisherId);
    const response = await withPostSearchAbortTimeout(
      async (signal) => await this.search.search(catalog, query, {
        signal,
        limit: options.limit,
        operator: options.operator,
        authors: options.authors ? [...options.authors] : undefined,
        kinds: options.kinds ? [...options.kinds] : undefined,
        since: options.since ?? undefined,
        until: options.until ?? undefined,
      }),
      options.requestTimeoutMs,
      options.signal,
    );
    return buildPublisherResponse(publisherId, [{
      response: {
        hits: response.results.map((result) => ({
          event: result.event,
          lexicalScore: result.score,
          matchedTerms: result.matchedTerms,
          matchedPhrases: result.matchedPhrases,
        })),
        exhaustive: response.exhaustive,
      },
      failed: false,
    }], 1, true);
  }

  private async openCatalog(root: CID): Promise<PostSearchV5RoutedCatalogLookup> {
    const key = nhashEncode(root);
    let pending = this.catalogs.get(key);
    if (pending) {
      this.catalogs.delete(key);
      this.catalogs.set(key, pending);
      return await pending;
    }
    while (this.catalogs.size >= ROUTED_CATALOG_CACHE_LIMIT) {
      this.catalogs.delete(this.catalogs.keys().next().value as string);
    }
    pending = openPostSearchV5RoutedCatalog(this.store, root);
    this.catalogs.set(key, pending);
    void pending.catch(() => {
      if (this.catalogs.get(key) === pending) {this.catalogs.delete(key);}
    });
    return await pending;
  }

  private assertPublisher(
    catalog: PostSearchV5RoutedCatalogLookup,
    publisherId: string,
  ): void {
    if (catalog.manifest.publisherId !== publisherId) {
      throw new Error('Catalog publisher identity does not match its pointer');
    }
  }
}
