import type { CID } from '@hashtree/core';
import { getUniqueRoots } from './appDataUtils';
import {
  getRootNhash,
  loadEventByRef,
  loadProfilesForPubkeys,
  loadThreadContextForEvent,
  resolveConfiguredEventIndexRoot,
  resolveProfileEventIndexRoot,
  type NoteThreadSnapshot,
} from './nostrIndex';
import { loadRoutedRepliesForEventPage } from './routedThreadReplies';
import {
  decodeNostrEventReference,
  getAddressableCoordinateFromReference,
  getAddressableEventCoordinate,
  getEventIdFromReference,
  getThreadParentReference,
  getThreadRootReference,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { mergeProfileMaps } from './profileRecords';
import { getThreadHydrationRoots } from './appViewState';
import { THREAD_REPLY_PAGE_SIZE } from './config';
import { buildThreadContext } from './threadReplyPagination';

export type LoadedThreadView = {
  resolvedRoot: CID;
  threadPersonalRoot: CID | null;
  threadRoots: CID[];
  snapshot: NoteThreadSnapshot;
  replies: RawEvent[];
  replyCursor: RecentTextNoteCursor | null;
  repliesHasMore: boolean;
  profiles: Map<string, ProfileRecord>;
  noteIds: string[];
  noteListsToCache: RawEvent[][];
};

export type LoadedThreadPrimary = Pick<
  LoadedThreadView,
  'resolvedRoot' | 'threadRoots' | 'snapshot'
>;

export type LoadedThreadReplies = Pick<
  LoadedThreadView,
  | 'resolvedRoot'
  | 'threadPersonalRoot'
  | 'threadRoots'
  | 'snapshot'
  | 'replies'
  | 'replyCursor'
  | 'repliesHasMore'
>;

type LoadThreadViewOptions = {
  currentRoot: CID;
  ref: string;
  knownNote: RawEvent | null;
  knownParent?: RawEvent | null;
  profilePersonalRoot: CID | null;
  viewerPersonalRoot: CID | null;
  cachedProfiles: Map<string, ProfileRecord>;
  replyLimit?: number;
  onPrimary?: (primary: LoadedThreadPrimary) => void;
  onReplies?: (update: LoadedThreadReplies) => void;
};

type ThreadLoaderDeps = {
  loadEventByRef: typeof loadEventByRef;
  loadThreadContextForEvent: typeof loadThreadContextForEvent;
  resolveConfiguredEventIndexRoot: typeof resolveConfiguredEventIndexRoot;
  resolveProfileEventIndexRoot: typeof resolveProfileEventIndexRoot;
  loadRepliesForEventPage: typeof loadRoutedRepliesForEventPage;
  loadProfilesForPubkeys: typeof loadProfilesForPubkeys;
};

const defaultThreadLoaderDeps: ThreadLoaderDeps = {
  loadEventByRef,
  loadThreadContextForEvent,
  resolveConfiguredEventIndexRoot,
  resolveProfileEventIndexRoot,
  loadRepliesForEventPage: loadRoutedRepliesForEventPage,
  loadProfilesForPubkeys,
};

export function takeThreadReplyPage(
  replies: RawEvent[],
  limit: number,
): { replies: RawEvent[]; hasMore: boolean } {
  const normalizedLimit = Math.max(1, Math.floor(limit));
  return {
    replies: replies.slice(0, normalizedLimit),
    hasMore: replies.length > normalizedLimit,
  };
}

export function createOptimisticThreadSnapshot(
  currentRoot: CID | null,
  knownNote: RawEvent,
  knownParent: RawEvent | null = null,
): NoteThreadSnapshot {
  return {
    rootNhash: currentRoot ? getRootNhash(currentRoot) : '',
    note: knownNote,
    root: null,
    parent: knownParent,
    context: knownParent ? [knownParent] : [],
  };
}

function eventMatchesReference(event: RawEvent, ref: string | null): boolean {
  if (!ref) {
    return false;
  }

  const eventId = getEventIdFromReference(ref);
  if (eventId) {
    return event.id === eventId;
  }

  const address = getAddressableCoordinateFromReference(ref);
  return Boolean(address && getAddressableEventCoordinate(event) === address);
}

function preserveKnownThreadParent(
  snapshot: NoteThreadSnapshot,
  knownParent: RawEvent | null,
): NoteThreadSnapshot {
  if (
    snapshot.parent
    || !snapshot.note
    || !knownParent
    || !eventMatchesReference(knownParent, getThreadParentReference(snapshot.note))
  ) {
    return snapshot;
  }

  const root = snapshot.root
    ?? (eventMatchesReference(knownParent, getThreadRootReference(snapshot.note))
      ? knownParent
      : null);

  return {
    ...snapshot,
    root,
    parent: knownParent,
    context: buildThreadContext(snapshot.note, root, knownParent),
  };
}

async function loadSnapshotWithKnownNoteFallback(
  roots: CID[],
  ref: string,
  knownNote: RawEvent | null,
  knownParent: RawEvent | null,
  deps: ThreadLoaderDeps,
  onResolvedNote?: (note: RawEvent) => void,
): Promise<{ snapshot: NoteThreadSnapshot; roots: CID[] }> {
  const nextRoots = roots;

  // A feed/profile card already carries the verified event. Resolve only its
  // optional parent context; do not look the same note up again before first
  // paint.
  if (knownNote) {
    const snapshot = preserveKnownThreadParent(
      await deps.loadThreadContextForEvent(nextRoots, knownNote),
      knownParent,
    );
    return { snapshot, roots: nextRoots };
  }

  const note = await deps.loadEventByRef(nextRoots, ref);
  if (!note) {
    return {
      roots: nextRoots,
      snapshot: {
        rootNhash: getRootNhash(nextRoots[0]!),
        note: null,
        root: null,
        parent: null,
        context: [],
      },
    };
  }
  onResolvedNote?.(note);
  const snapshot = await deps.loadThreadContextForEvent(nextRoots, note);

  return { snapshot, roots: nextRoots };
}

export async function loadThreadViewData(
  options: LoadThreadViewOptions,
  deps: ThreadLoaderDeps = defaultThreadLoaderDeps,
): Promise<LoadedThreadView> {
  const replyLimit = Math.max(1, Math.floor(options.replyLimit ?? THREAD_REPLY_PAGE_SIZE));
  let resolvedRoot = options.currentRoot;
  let threadPersonalRoot: CID | null = null;
  const decodedRef = decodeNostrEventReference(options.ref);
  const hintedAuthor = decodedRef?.type === 'nevent'
    ? decodedRef.author
    : decodedRef?.type === 'naddr'
      ? decodedRef.pubkey
      : null;
  let threadRoots = getThreadHydrationRoots(
    resolvedRoot,
    options.profilePersonalRoot,
    options.viewerPersonalRoot,
    null,
  );
  if (options.knownNote) {
    options.onPrimary?.({
      resolvedRoot,
      threadRoots,
      snapshot: createOptimisticThreadSnapshot(
        resolvedRoot,
        options.knownNote,
        options.knownParent ?? null,
      ),
    });
  }
  let loaded = await loadSnapshotWithKnownNoteFallback(
    threadRoots,
    options.ref,
    options.knownNote,
    options.knownParent ?? null,
    deps,
    (note) => options.onPrimary?.({
      resolvedRoot,
      threadRoots,
      snapshot: createOptimisticThreadSnapshot(resolvedRoot, note),
    }),
  );
  let snapshot = loaded.snapshot;
  threadRoots = loaded.roots;

  if (!snapshot.note) {
    const liveConfiguredRoot = await deps.resolveConfiguredEventIndexRoot();
    if (liveConfiguredRoot && getRootNhash(liveConfiguredRoot) !== getRootNhash(resolvedRoot)) {
      resolvedRoot = liveConfiguredRoot;
      threadRoots = getThreadHydrationRoots(
        resolvedRoot,
        options.profilePersonalRoot,
        options.viewerPersonalRoot,
        null,
      );
      loaded = await loadSnapshotWithKnownNoteFallback(
        threadRoots,
        options.ref,
        options.knownNote,
        options.knownParent ?? null,
        deps,
        (note) => options.onPrimary?.({
          resolvedRoot,
          threadRoots,
          snapshot: createOptimisticThreadSnapshot(resolvedRoot, note),
        }),
      );
      snapshot = loaded.snapshot;
      threadRoots = loaded.roots;
    }
  }

  if (!snapshot.note && hintedAuthor) {
    const hintedRoot = await deps.resolveProfileEventIndexRoot(hintedAuthor);
    if (
      hintedRoot
      && !threadRoots.some((candidateRoot) => getRootNhash(candidateRoot) === getRootNhash(hintedRoot))
    ) {
      // Relay discovery stops at the signed root pointer. The event itself is
      // loaded and signature-verified by the Hashtree event-index reader.
      const hintedNote = await deps.loadEventByRef([hintedRoot], options.ref);
      if (hintedNote) {
        threadPersonalRoot = hintedRoot;
        threadRoots = getUniqueRoots(...threadRoots, hintedRoot);
        options.onPrimary?.({
          resolvedRoot,
          threadRoots,
          snapshot: createOptimisticThreadSnapshot(resolvedRoot, hintedNote),
        });
        snapshot = preserveKnownThreadParent(
          await deps.loadThreadContextForEvent(threadRoots, hintedNote),
          options.knownParent ?? null,
        );
      }
    }
  }

  if (!snapshot.note) {
    options.onPrimary?.({ resolvedRoot, threadRoots, snapshot });
    return {
      resolvedRoot,
      threadPersonalRoot,
      threadRoots,
      snapshot,
      replies: [],
      replyCursor: null,
      repliesHasMore: false,
      profiles: new Map(),
      noteIds: [],
      noteListsToCache: [snapshot.context],
    };
  }

  options.onPrimary?.({ resolvedRoot, threadRoots, snapshot });

  const resolvedNote = snapshot.note;
  // Root-pointer discovery is independent of the first durable reply page.
  // Start it now so its relay settle window overlaps Hashtree reply IO instead
  // of adding another serial wait after the replies have already loaded.
  const personalRootPromise = threadPersonalRoot && resolvedNote.pubkey === hintedAuthor
    ? Promise.resolve(threadPersonalRoot)
    : deps.resolveProfileEventIndexRoot(resolvedNote.pubkey);
  let replyPage = await deps.loadRepliesForEventPage(threadRoots, snapshot.note, { limit: replyLimit });
  let replies = replyPage.replies;
  options.onReplies?.({
    resolvedRoot,
    threadPersonalRoot,
    threadRoots,
    snapshot,
    replies,
    replyCursor: replyPage.cursor,
    repliesHasMore: replyPage.hasMore,
  });
  const involvedPubkeys = [...new Set([
    snapshot.note.pubkey,
    ...snapshot.context.map((event) => event.pubkey),
    ...replies.map((event) => event.pubkey),
  ])];
  let profileMapsPromise = Promise.all(
    threadRoots.map(async (candidateRoot) => await deps.loadProfilesForPubkeys(candidateRoot, involvedPubkeys)),
  );

  const personalRoot = await personalRootPromise;
  if (personalRoot && !threadRoots.some((candidateRoot) => getRootNhash(candidateRoot) === getRootNhash(personalRoot))) {
    const mergedRoots = getUniqueRoots(...threadRoots, personalRoot);
    const [loadedMergedSnapshot, mergedReplyPage] = await Promise.all([
      deps.loadThreadContextForEvent(mergedRoots, resolvedNote),
      deps.loadRepliesForEventPage(mergedRoots, resolvedNote, { limit: replyLimit }),
    ]);
    const mergedSnapshot = preserveKnownThreadParent(
      loadedMergedSnapshot,
      options.knownParent ?? null,
    );
    const mergedReplies = mergedReplyPage.replies;
    const mergedInvolvedPubkeys = [...new Set([
      mergedSnapshot.note?.pubkey ?? resolvedNote.pubkey,
      ...mergedSnapshot.context.map((event) => event.pubkey),
      ...mergedReplies.map((event) => event.pubkey),
    ])];
    const mergedProfileMapsPromise = Promise.all(
      mergedRoots.map(async (candidateRoot) => await deps.loadProfilesForPubkeys(candidateRoot, mergedInvolvedPubkeys)),
    );

    threadPersonalRoot = personalRoot;
    threadRoots = mergedRoots;
    snapshot = mergedSnapshot;
    replyPage = mergedReplyPage;
    replies = mergedReplies;
    profileMapsPromise = mergedProfileMapsPromise;
    options.onReplies?.({
      resolvedRoot,
      threadPersonalRoot,
      threadRoots,
      snapshot,
      replies,
      replyCursor: replyPage.cursor,
      repliesHasMore: replyPage.hasMore,
    });
  }
  const profileMaps = await profileMapsPromise;

  return {
    resolvedRoot,
    threadPersonalRoot,
    threadRoots,
    snapshot,
    replies,
    replyCursor: replyPage.cursor,
    repliesHasMore: replyPage.hasMore,
    profiles: mergeProfileMaps(...profileMaps, options.cachedProfiles),
    noteIds: [(snapshot.note ?? resolvedNote).id, ...replies.map((event) => event.id)],
    noteListsToCache: [
      snapshot.note ? [snapshot.note] : [],
      snapshot.context,
      replies,
    ],
  };
}
