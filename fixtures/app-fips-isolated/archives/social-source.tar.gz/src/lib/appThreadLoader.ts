import type { CID } from '@hashtree/core';
import { getUniqueRoots } from './appDataUtils';
import {
  getRootNhash,
  loadEventByRef,
  loadProfilesForPubkeys,
  loadThreadContextForEvent,
  resolveConfiguredEventIndexRoot,
  resolveProfileEventIndexRoot,
  type NoteThreadSnapshot,
} from './nostrIndex';
import { loadRoutedRepliesForEventPage } from './routedThreadReplies';
import {
  decodeNostrEventReference,
  getAddressableCoordinateFromReference,
  getAddressableEventCoordinate,
  getEventIdFromReference,
  getThreadParentReference,
  getThreadRootReference,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { mergeProfileMaps } from './profileRecords';
import { getThreadHydrationRoots } from './appViewState';
import { THREAD_REPLY_PAGE_SIZE } from './config';
import { buildThreadContext } from './threadReplyPagination';

export type LoadedThreadView = {
  resolvedRoot: CID;
  threadPersonalRoot: CID | null;
  threadRoots: CID[];
  snapshot: NoteThreadSnapshot;
  replies: RawEvent[];
  replyCursor: RecentTextNoteCursor | null;
  repliesHasMore: boolean;
  profiles: Map<string, ProfileRecord>;
  noteIds: string[];
  noteListsToCache: RawEvent[][];
};

export type LoadedThreadPrimary = Pick<
  LoadedThreadView,
  'resolvedRoot' | 'threadRoots' | 'snapshot'
>;

export type LoadedThreadReplies = Pick<
  LoadedThreadView,
  | 'resolvedRoot'
  | 'threadPersonalRoot'
  | 'threadRoots'
  | 'snapshot'
  | 'replies'
  | 'replyCursor'
  | 'repliesHasMore'
>;

type LoadThreadViewOptions = {
  currentRoot: CID;
  ref: string;
  knownNote: RawEvent | null;
  knownParent?: RawEvent | null;
  profilePersonalRoot: CID | null;
  viewerPersonalRoot: CID | null;
  cachedProfiles: Map<string, ProfileRecord>;
  replyLimit?: number;
  onPrimary?: (primary: LoadedThreadPrimary) => void;
  onReplies?: (update: LoadedThreadReplies) => void;
  onProfiles?: (profiles: Map<string, ProfileRecord>) => void;
};

type ThreadLoaderDeps = {
  loadEventByRef: typeof loadEventByRef;
  loadThreadContextForEvent: typeof loadThreadContextForEvent;
  resolveConfiguredEventIndexRoot: typeof resolveConfiguredEventIndexRoot;
  resolveProfileEventIndexRoot: typeof resolveProfileEventIndexRoot;
  loadRepliesForEventPage: typeof loadRoutedRepliesForEventPage;
  loadProfilesForPubkeys: typeof loadProfilesForPubkeys;
};

const defaultThreadLoaderDeps: ThreadLoaderDeps = {
  loadEventByRef,
  loadThreadContextForEvent,
  resolveConfiguredEventIndexRoot,
  resolveProfileEventIndexRoot,
  loadRepliesForEventPage: loadRoutedRepliesForEventPage,
  loadProfilesForPubkeys,
};

export function takeThreadReplyPage(
  replies: RawEvent[],
  limit: number,
): { replies: RawEvent[]; hasMore: boolean } {
  const normalizedLimit = Math.max(1, Math.floor(limit));
  return {
    replies: replies.slice(0, normalizedLimit),
    hasMore: replies.length > normalizedLimit,
  };
}

export function createOptimisticThreadSnapshot(
  currentRoot: CID | null,
  knownNote: RawEvent,
  knownParent: RawEvent | null = null,
): NoteThreadSnapshot {
  return {
    rootNhash: currentRoot ? getRootNhash(currentRoot) : '',
    note: knownNote,
    root: null,
    parent: knownParent,
    context: knownParent ? [knownParent] : [],
  };
}

function eventMatchesReference(event: RawEvent, ref: string | null): boolean {
  if (!ref) {
    return false;
  }

  const eventId = getEventIdFromReference(ref);
  if (eventId) {
    return event.id === eventId;
  }

  const address = getAddressableCoordinateFromReference(ref);
  return Boolean(address && getAddressableEventCoordinate(event) === address);
}

function preserveKnownThreadParent(
  snapshot: NoteThreadSnapshot,
  knownParent: RawEvent | null,
): NoteThreadSnapshot {
  if (
    snapshot.parent
    || !snapshot.note
    || !knownParent
    || !eventMatchesReference(knownParent, getThreadParentReference(snapshot.note))
  ) {
    return snapshot;
  }

  const root = snapshot.root
    ?? (eventMatchesReference(knownParent, getThreadRootReference(snapshot.note))
      ? knownParent
      : null);

  return {
    ...snapshot,
    root,
    parent: knownParent,
    context: buildThreadContext(snapshot.note, root, knownParent),
  };
}

function collectThreadPubkeys(
  note: RawEvent,
  context: readonly RawEvent[],
  replies: readonly RawEvent[],
): string[] {
  return [...new Set([
    note.pubkey,
    ...context.map((event) => event.pubkey),
    ...replies.map((event) => event.pubkey),
  ])];
}

async function loadProfilesFromRoots(
  roots: readonly CID[],
  pubkeys: string[],
  cachedProfiles: Map<string, ProfileRecord>,
  deps: ThreadLoaderDeps,
): Promise<Map<string, ProfileRecord>> {
  const profileMaps = await Promise.all(
    roots.map(async (candidateRoot) => await deps.loadProfilesForPubkeys(candidateRoot, pubkeys)),
  );
  return mergeProfileMaps(...profileMaps, cachedProfiles);
}

export async function loadThreadViewData(
  options: LoadThreadViewOptions,
  deps: ThreadLoaderDeps = defaultThreadLoaderDeps,
): Promise<LoadedThreadView> {
  const replyLimit = Math.max(1, Math.floor(options.replyLimit ?? THREAD_REPLY_PAGE_SIZE));
  const knownParent = options.knownParent ?? null;
  let resolvedRoot = options.currentRoot;
  let threadPersonalRoot: CID | null = null;
  const decodedRef = decodeNostrEventReference(options.ref);
  const hintedAuthor = decodedRef?.type === 'nevent'
    ? decodedRef.author
    : decodedRef?.type === 'naddr'
      ? decodedRef.pubkey
      : null;
  let threadRoots = getThreadHydrationRoots(
    resolvedRoot,
    options.profilePersonalRoot,
    options.viewerPersonalRoot,
    null,
  );
  let resolvedNote = options.knownNote;

  if (!resolvedNote) {
    resolvedNote = await deps.loadEventByRef(threadRoots, options.ref);
    if (!resolvedNote) {
      const liveConfiguredRoot = await deps.resolveConfiguredEventIndexRoot();
      if (liveConfiguredRoot && getRootNhash(liveConfiguredRoot) !== getRootNhash(resolvedRoot)) {
        resolvedRoot = liveConfiguredRoot;
        threadRoots = getThreadHydrationRoots(
          resolvedRoot,
          options.profilePersonalRoot,
          options.viewerPersonalRoot,
          null,
        );
        resolvedNote = await deps.loadEventByRef(threadRoots, options.ref);
      }
    }
    if (!resolvedNote && hintedAuthor) {
      const hintedRoot = await deps.resolveProfileEventIndexRoot(hintedAuthor);
      if (
        hintedRoot
        && !threadRoots.some((candidateRoot) => getRootNhash(candidateRoot) === getRootNhash(hintedRoot))
      ) {
        // Relay discovery stops at the signed root pointer. The event itself is
        // loaded and signature-verified by the Hashtree event-index reader.
        const hintedNote = await deps.loadEventByRef([hintedRoot], options.ref);
        if (hintedNote) {
          threadPersonalRoot = hintedRoot;
          threadRoots = getUniqueRoots(...threadRoots, hintedRoot);
          resolvedNote = hintedNote;
        }
      }
    }
  }

  if (!resolvedNote) {
    const emptySnapshot: NoteThreadSnapshot = {
      rootNhash: getRootNhash(threadRoots[0]!),
      note: null,
      root: null,
      parent: null,
      context: [],
    };
    options.onPrimary?.({ resolvedRoot, threadRoots, snapshot: emptySnapshot });
    return {
      resolvedRoot,
      threadPersonalRoot,
      threadRoots,
      snapshot: emptySnapshot,
      replies: [],
      replyCursor: null,
      repliesHasMore: false,
      profiles: new Map(),
      noteIds: [],
      noteListsToCache: [[]],
    };
  }

  options.onPrimary?.({
    resolvedRoot,
    threadRoots,
    snapshot: createOptimisticThreadSnapshot(resolvedRoot, resolvedNote, knownParent),
  });

  // Start context, first reply page, main author profile, and optional
  // personal-root discovery in parallel once the main note is verified.
  const personalRootPromise = threadPersonalRoot && resolvedNote.pubkey === hintedAuthor
    ? Promise.resolve(threadPersonalRoot)
    : deps.resolveProfileEventIndexRoot(resolvedNote.pubkey);
  const mainAuthorProfilesPromise = loadProfilesFromRoots(
    threadRoots,
    [resolvedNote.pubkey],
    options.cachedProfiles,
    deps,
  ).then((authorProfiles) => {
    options.onProfiles?.(authorProfiles);
    return authorProfiles;
  });
  const contextPromise = deps.loadThreadContextForEvent(threadRoots, resolvedNote).then((loaded) => {
    const withParent = preserveKnownThreadParent(loaded, knownParent);
    options.onPrimary?.({ resolvedRoot, threadRoots, snapshot: withParent });
    return withParent;
  });
  const replyPagePromise = deps.loadRepliesForEventPage(threadRoots, resolvedNote, { limit: replyLimit });

  let [snapshot, replyPage] = await Promise.all([contextPromise, replyPagePromise]);
  let replies = replyPage.replies;
  options.onReplies?.({
    resolvedRoot,
    threadPersonalRoot,
    threadRoots,
    snapshot,
    replies,
    replyCursor: replyPage.cursor,
    repliesHasMore: replyPage.hasMore,
  });

  // Commit remaining context and reply profiles without waiting for optional
  // personal-root discovery.
  const remainingPubkeys = collectThreadPubkeys(resolvedNote, snapshot.context, replies)
    .filter((pubkey) => pubkey !== resolvedNote.pubkey);
  const [authorProfiles, extraProfiles] = await Promise.all([
    mainAuthorProfilesPromise,
    remainingPubkeys.length > 0
      ? loadProfilesFromRoots(threadRoots, remainingPubkeys, options.cachedProfiles, deps)
      : Promise.resolve(new Map<string, ProfileRecord>()),
  ]);
  let profiles = remainingPubkeys.length > 0
    ? mergeProfileMaps(extraProfiles, authorProfiles)
    : authorProfiles;
  if (remainingPubkeys.length > 0) {
    options.onProfiles?.(profiles);
  }

  const personalRoot = await personalRootPromise;
  if (personalRoot && !threadRoots.some((candidateRoot) => getRootNhash(candidateRoot) === getRootNhash(personalRoot))) {
    const mergedRoots = getUniqueRoots(...threadRoots, personalRoot);
    const [loadedMergedSnapshot, mergedReplyPage] = await Promise.all([
      deps.loadThreadContextForEvent(mergedRoots, resolvedNote),
      deps.loadRepliesForEventPage(mergedRoots, resolvedNote, { limit: replyLimit }),
    ]);
    threadPersonalRoot = personalRoot;
    threadRoots = mergedRoots;
    snapshot = preserveKnownThreadParent(loadedMergedSnapshot, knownParent);
    replyPage = mergedReplyPage;
    replies = mergedReplyPage.replies;
    options.onReplies?.({
      resolvedRoot,
      threadPersonalRoot,
      threadRoots,
      snapshot,
      replies,
      replyCursor: replyPage.cursor,
      repliesHasMore: replyPage.hasMore,
    });
    profiles = await loadProfilesFromRoots(
      mergedRoots,
      collectThreadPubkeys(snapshot.note ?? resolvedNote, snapshot.context, replies),
      profiles,
      deps,
    );
    options.onProfiles?.(profiles);
  }

  return {
    resolvedRoot,
    threadPersonalRoot,
    threadRoots,
    snapshot,
    replies,
    replyCursor: replyPage.cursor,
    repliesHasMore: replyPage.hasMore,
    profiles,
    noteIds: [(snapshot.note ?? resolvedNote).id, ...replies.map((event) => event.id)],
    noteListsToCache: [
      snapshot.note ? [snapshot.note] : [],
      snapshot.context,
      replies,
    ],
  };
}
