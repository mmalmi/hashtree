import type { SocialAccount } from './accounts';
import { signAccountEvent } from './accountSigner';

export const NOTIFICATION_SERVER = 'https://notifications.iris.to';

export async function notificationRequest(
  path: string,
  account: SocialAccount | null,
  method = 'GET',
  body?: unknown,
  fetcher: typeof fetch = fetch,
): Promise<unknown> {
  const url = `${NOTIFICATION_SERVER}/${path}`;
  const headers: Record<string, string> = { accept: 'application/json' };
  if (account) {
    const event = await signAccountEvent(account, {
      kind: 27235, created_at: Math.floor(Date.now() / 1000), content: '',
      tags: [['u', url], ['method', method]],
    });
    headers.authorization = `Nostr ${btoa(JSON.stringify(event))}`;
  }
  if (body !== undefined) { headers['content-type'] = 'application/json'; }
  const response = await fetcher(url, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok && !(method === 'DELETE' && response.status === 404)) {
    throw new Error('The notification service is unavailable. Please try again.');
  }
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export function webPushData(subscription: PushSubscription) {
  const encodeKey = (name: PushEncryptionKeyName): string => {
    const key = subscription.getKey(name);
    if (!key) { throw new Error('The browser did not provide notification keys.'); }
    return btoa(String.fromCharCode(...new Uint8Array(key)));
  };
  return { endpoint: subscription.endpoint, p256dh: encodeKey('p256dh'), auth: encodeKey('auth') };
}
