import type { SocialGraph } from 'nostr-social-graph';
import { SOCIAL_GRAPH_ROOT, SOCIAL_GRAPH_SNAPSHOT_BYTES, SOCIAL_GRAPH_SNAPSHOT_SHA256, SOCIAL_GRAPH_SNAPSHOT_URL } from './socialGraphSnapshot.generated';

const MIN_USEFUL_GRAPH_FOLLOWS = 10_000;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', Uint8Array.from(bytes).buffer);
  return bytesToHex(new Uint8Array(digest));
}

export async function parseStaticSocialGraphSnapshot(
  bytes: Uint8Array,
): Promise<{ graph: SocialGraph; bytes: Uint8Array } | null> {
  if (
    bytes.length !== SOCIAL_GRAPH_SNAPSHOT_BYTES
    || await sha256Hex(bytes) !== SOCIAL_GRAPH_SNAPSHOT_SHA256
  ) {
    return null;
  }

  const { SocialGraph } = await import('nostr-social-graph');
  const graph = await SocialGraph.fromBinary(SOCIAL_GRAPH_ROOT, bytes);
  return graph.size().follows >= MIN_USEFUL_GRAPH_FOLLOWS ? { graph, bytes } : null;
}

export async function loadStaticSocialGraph(): Promise<{ graph: SocialGraph; bytes: Uint8Array } | null> {
  if (typeof fetch === 'undefined') {
    return null;
  }

  try {
    const response = await fetch(SOCIAL_GRAPH_SNAPSHOT_URL, { cache: 'force-cache' });
    if (!response.ok) {
      return null;
    }

    return await parseStaticSocialGraphSnapshot(new Uint8Array(await response.arrayBuffer()));
  } catch (error) {
    console.warn('Failed to load static social graph seed', error);
    return null;
  }
}
