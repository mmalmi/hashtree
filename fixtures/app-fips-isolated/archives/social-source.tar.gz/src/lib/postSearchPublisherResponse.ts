import type { RawEvent } from './nostr';

export interface PostSearchPublisherFailure {
  publisherId: string;
  status: 'incompatible' | 'partial' | 'unavailable';
  failedSegments: number;
  message: string;
}

export type PublisherHit = {
  event: RawEvent;
  lexicalScore: number;
  matchedTerms: string[];
  matchedPhrases: number;
  rank: number;
};

export type PublisherResponse = {
  publisherId: string;
  hits: PublisherHit[];
  failure: PostSearchPublisherFailure | null;
  searched: boolean;
  exhaustive: boolean;
  truncated: boolean;
};

export type SegmentHit = Omit<PublisherHit, 'rank'>;

export type SegmentSearchResponse = {
  hits: SegmentHit[];
  exhaustive: boolean;
};

export type SegmentWorkerResponse = {
  response: SegmentSearchResponse;
  failed: boolean;
};

export function buildPublisherResponse(
  publisherId: string,
  segmentResponses: readonly SegmentWorkerResponse[],
  segmentCount: number,
  complete: boolean,
): PublisherResponse {
  const failedSegments = segmentResponses.filter((response) => response.failed).length;
  const hits = rankPublisherHits(segmentResponses.flatMap((response) => response.response.hits));
  const truncated = segmentResponses.some((response) =>
    !response.failed && !response.response.exhaustive);
  const allSegmentsFailed = complete && failedSegments === segmentCount;
  const failure = failedSegments > 0
    ? {
        publisherId,
        status: allSegmentsFailed ? 'unavailable' as const : 'partial' as const,
        failedSegments,
        message: allSegmentsFailed
          ? 'All compatible search segments were unavailable'
          : 'Some compatible search segments were unavailable',
      }
    : null;
  return {
    publisherId,
    hits,
    failure,
    searched: segmentCount > 0,
    exhaustive: complete && failedSegments === 0 && !truncated,
    truncated,
  };
}

function rankPublisherHits(hits: readonly SegmentHit[]): PublisherHit[] {
  const bestById = new Map<string, SegmentHit>();
  for (const hit of [...hits].sort(compareSegmentHits)) {
    if (!bestById.has(hit.event.id)) {
      bestById.set(hit.event.id, hit);
    }
  }
  return [...bestById.values()]
    .sort(compareSegmentHits)
    .map((hit, index) => ({ ...hit, rank: index + 1 }));
}

function compareSegmentHits(left: SegmentHit, right: SegmentHit): number {
  return right.lexicalScore - left.lexicalScore
    || right.matchedPhrases - left.matchedPhrases
    || right.event.created_at - left.event.created_at
    || compareStrings(left.event.id, right.event.id);
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
