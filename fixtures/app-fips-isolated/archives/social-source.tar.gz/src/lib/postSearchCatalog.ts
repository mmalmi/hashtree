import {
  HashTree,
  LinkType,
  nhashEncode,
  type CID,
  type Store,
  type TreeEntry,
} from '@hashtree/core';
import {
  RANKED_SEARCH_SEGMENT_FORMAT,
  RankedSearchIndex,
  type RankedSearchDocument,
} from '@hashtree/index';
import type { RawEvent } from './nostr';
import {
  POST_SEARCH_TERM_ROUTING_FORMAT,
  buildPostSearchSegmentRouting,
  extendPostSearchSegmentRouting,
  mergePostSearchSegmentRoutings,
} from './postSearchTermRouting';
import {
  POST_SEARCH_GLOBAL_SCORING_FORMAT,
  buildPostSearchGlobalScoring,
  extendPostSearchGlobalScoring,
  readPostSearchGlobalScoring,
  type PostSearchGlobalScoringDescriptor,
  type PostSearchGlobalScoringIndex,
} from './postSearchGlobalScoring';
import {
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_CATALOG_FORMAT_V1,
  POST_SEARCH_CATALOG_FORMAT_V2,
  POST_SEARCH_CATALOG_FORMAT_V3,
  POST_SEARCH_DOCUMENT_FORMAT,
  POST_SEARCH_KINDS,
  POST_SEARCH_MAX_CATALOG_BYTES,
  POST_SEARCH_MAX_CATALOG_SEGMENTS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
} from './postSearchCatalogConstants';
import {
  isObject,
  nonNegativeInteger,
  nullableTimestamp,
  parsePostSearchCatalogManifest,
  uniqueNumbers,
  validateKinds,
  validateProjection,
  validatePublisherId,
  validateSegmentCoverage,
  validateSourceSnapshot,
} from './postSearchCatalogManifest';

export {
  POST_SEARCH_AUTHOR_TERMS_PROJECTION,
  POST_SEARCH_BUILD_OPTIONS,
  POST_SEARCH_CATALOG_FORMAT,
  POST_SEARCH_CATALOG_FORMAT_V1,
  POST_SEARCH_CATALOG_FORMAT_V2,
  POST_SEARCH_CATALOG_FORMAT_V3,
  POST_SEARCH_DOCUMENT_FORMAT,
  POST_SEARCH_KINDS,
  POST_SEARCH_MAX_CATALOG_BYTES,
  POST_SEARCH_MAX_CATALOG_SEGMENTS,
  POST_SEARCH_NORMALIZATION,
  POST_SEARCH_VISIBLE_PROJECTION,
} from './postSearchCatalogConstants';

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const SUPPORTED_KINDS = new Set<number>(POST_SEARCH_KINDS);
const HEX_64 = /^[0-9a-f]{64}$/;

export class PostSearchCatalogCapacityError extends Error {
  readonly code = 'POST_SEARCH_CATALOG_CAPACITY_EXCEEDED';

  constructor(message: string) {
    super(message);
    this.name = 'PostSearchCatalogCapacityError';
  }
}

export interface StoredPostSearchDocument {
  format: typeof POST_SEARCH_DOCUMENT_FORMAT;
  event: RawEvent;
}

export interface PostSearchSegmentDescriptor {
  entry: string;
  /** Events after replaceable selection and valid kind-5 deletion tombstones are applied. */
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  documentCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchCoverage {
  eventCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchSourceSnapshot {
  /** Canonical nhash of the immutable archive event root used to build these segments. */
  eventRoot: string;
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  /** Coverage of indexable visible events, not the archive's raw event count. */
  coverage: PostSearchCoverage;
}

export interface PostSearchCatalogManifest {
  format:
    | typeof POST_SEARCH_CATALOG_FORMAT
    | typeof POST_SEARCH_CATALOG_FORMAT_V3
    | typeof POST_SEARCH_CATALOG_FORMAT_V2
    | typeof POST_SEARCH_CATALOG_FORMAT_V1;
  publisherId: string;
  generatedAt: number;
  source: PostSearchSourceSnapshot;
  compatibility: {
    documentFormat: typeof POST_SEARCH_DOCUMENT_FORMAT;
    rankedSegmentFormat: typeof RANKED_SEARCH_SEGMENT_FORMAT;
    normalization: typeof POST_SEARCH_NORMALIZATION;
    fields: typeof POST_SEARCH_BUILD_OPTIONS.fields;
    maxTokensPerField: typeof POST_SEARCH_BUILD_OPTIONS.maxTokensPerField | null;
    authorTerms: typeof POST_SEARCH_AUTHOR_TERMS_PROJECTION | null;
    termRouting: typeof POST_SEARCH_TERM_ROUTING_FORMAT | null;
    globalScoring: typeof POST_SEARCH_GLOBAL_SCORING_FORMAT | null;
  };
  routing: PostSearchTermRoutingDescriptor | null;
  globalScoring: PostSearchGlobalScoringDescriptor | null;
  segments: PostSearchSegmentDescriptor[];
}

export interface PostSearchTermRoutingDescriptor {
  format: typeof POST_SEARCH_TERM_ROUTING_FORMAT;
  entry: 'term-routing' | null;
  mappingCount: number;
}

export interface PostSearchBuiltSegment {
  root: CID;
  routingRoot: CID | null;
  routingMappingCount: number;
  projection: typeof POST_SEARCH_VISIBLE_PROJECTION;
  documentCount: number;
  kinds: number[];
  since: number | null;
  until: number | null;
}

export interface PostSearchSegmentInput extends Omit<PostSearchSegmentDescriptor, 'entry'> {
  root: CID;
  /** BTree of term-NUL-segment-nhash keys, emitted beside the ranked segment. */
  routingRoot: CID | null;
  routingMappingCount: number;
}

export interface PostSearchCatalogInput {
  publisherId: string;
  generatedAt: number;
  source: PostSearchSourceSnapshot;
  segments: readonly PostSearchSegmentInput[];
}

export interface PostSearchCatalogExtensionInput {
  /** Fully authenticated v4 catalog whose segment DAGs remain immutable. */
  base: PostSearchCatalog;
  publisherId: string;
  generatedAt: number;
  /** New immutable archive snapshot represented by base plus the exact tail batch. */
  eventRoot: string;
  appendedSegments: readonly PostSearchSegmentInput[];
  signal?: AbortSignal;
}

export interface PostSearchCatalog {
  manifest: PostSearchCatalogManifest;
  routing: (PostSearchTermRoutingDescriptor & { root: CID | null }) | null;
  globalScoring: PostSearchGlobalScoringIndex | null;
  segments: Array<PostSearchSegmentDescriptor & { root: CID }>;
}

export interface PostSearchBuildContext {
  /** Profile names known to the builder. The event pubkey is always indexed too. */
  authorNames?: Readonly<Record<string, readonly string[]>>;
}

/**
 * Convert verified Nostr events into one reusable immutable ranked segment.
 * The caller must first apply replaceable selection and valid kind-5 deletion tombstones.
 */
export async function buildPostSearchSegment(
  store: Store,
  events: Iterable<RawEvent>,
  context: PostSearchBuildContext = {},
): Promise<PostSearchBuiltSegment> {
  const searchableEvents = [...events]
    .filter((event) => SUPPORTED_KINDS.has(event.kind))
    .map(normalizeSearchableEvent);
  const documents = searchableEvents.map((event) =>
    createPostSearchDocument(event, context.authorNames?.[event.pubkey]));
  const root = await new RankedSearchIndex(store).buildSegment(
    documents,
    POST_SEARCH_BUILD_OPTIONS,
  );
  const routing = await buildPostSearchSegmentRouting(
    store,
    root,
    documents,
    POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
  );
  const timestamps = searchableEvents.map((event) => event.created_at);

  return {
    root,
    routingRoot: routing.root,
    routingMappingCount: routing.mappingCount,
    projection: POST_SEARCH_VISIBLE_PROJECTION,
    documentCount: documents.length,
    kinds: uniqueNumbers(searchableEvents.map((event) => event.kind)),
    since: timestamps.length > 0 ? Math.min(...timestamps) : null,
    until: timestamps.length > 0 ? Math.max(...timestamps) : null,
  };
}

/** Write a content-addressed catalog whose directory links retain every segment DAG. */
export async function writePostSearchCatalog(
  store: Store,
  input: PostSearchCatalogInput,
): Promise<CID> {
  const publisherId = validatePublisherId(input.publisherId);
  const generatedAt = nonNegativeInteger(input.generatedAt, 'generatedAt');
  assertPostSearchSegmentCapacity(input.segments.length);
  const sortedSegments = [...input.segments].sort(compareSegmentInputs);
  const routing = await mergePostSearchSegmentRoutings(store, sortedSegments);
  const segmentDescriptors = sortedSegments.map((segment, index) => ({
    entry: `segment-${index.toString().padStart(6, '0')}`,
    projection: validateProjection(segment.projection),
    documentCount: nonNegativeInteger(segment.documentCount, 'segment documentCount'),
    kinds: validateKinds(segment.kinds),
    since: nullableTimestamp(segment.since, 'segment since'),
    until: nullableTimestamp(segment.until, 'segment until'),
  }));
  for (const segment of segmentDescriptors) {
    validateSegmentCoverage(segment);
  }
  const source = validateSourceSnapshot(input.source, segmentDescriptors);
  const globalScoring = await buildPostSearchGlobalScoring(
    store,
    sortedSegments,
    POST_SEARCH_BUILD_OPTIONS.fields,
    POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
  );

  return await writePostSearchCatalogDirectory(store, {
    publisherId,
    generatedAt,
    source,
    segments: segmentDescriptors.map((descriptor, index) => ({
      descriptor,
      root: sortedSegments[index].root,
    })),
    routing,
    globalScoring,
  });
}

/**
 * Append immutable v4 segments while retaining base segment DAGs and updating
 * only the new routing/statistics terms in their persistent B-trees.
 */
export async function extendPostSearchCatalog(
  store: Store,
  input: PostSearchCatalogExtensionInput,
): Promise<CID> {
  const publisherId = validatePublisherId(input.publisherId);
  const generatedAt = nonNegativeInteger(input.generatedAt, 'generatedAt');
  if (input.base.manifest.format !== POST_SEARCH_CATALOG_FORMAT
    || !input.base.routing
    || !input.base.globalScoring) {
    throw new Error('Incremental post search requires a complete v4 base catalog');
  }
  if (input.base.manifest.publisherId !== publisherId) {
    throw new Error('Incremental post search publisher does not match the base catalog');
  }
  if (generatedAt <= input.base.manifest.generatedAt) {
    throw new Error('Incremental post search generatedAt must be newer than the base catalog');
  }
  assertPostSearchSegmentCapacity(
    input.base.segments.length + input.appendedSegments.length,
  );
  throwIfAborted(input.signal);

  const baseRoots = new Set(input.base.segments.map((segment) => nhashEncode(segment.root)));
  const appendedRoots = new Set<string>();
  for (const segment of input.appendedSegments) {
    const root = nhashEncode(segment.root);
    if (baseRoots.has(root) || appendedRoots.has(root)) {
      throw new Error(`Duplicate post search segment root: ${root}`);
    }
    appendedRoots.add(root);
  }
  const appended = [...input.appendedSegments].sort(compareSegmentInputs);
  const routing = await extendPostSearchSegmentRouting(store, {
    root: input.base.routing.root,
    mappingCount: input.base.routing.mappingCount,
  }, appended, input.signal);
  const globalScoring = await extendPostSearchGlobalScoring(
    store,
    input.base.globalScoring,
    appended,
    POST_SEARCH_BUILD_OPTIONS.fields,
    POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
    { signal: input.signal },
  );
  throwIfAborted(input.signal);

  const segments = [
    ...input.base.segments.map(({ root, ...descriptor }) => ({ descriptor, root })),
    ...appended.map((segment) => ({
      descriptor: segmentDescriptor(segment),
      root: segment.root,
    })),
  ].sort((left, right) => compareSegmentDescriptors(left, right));
  const descriptors = segments.map((segment, index) => ({
    ...segment.descriptor,
    entry: `segment-${index.toString().padStart(6, '0')}`,
  }));
  const source = validateSourceSnapshot({
    eventRoot: input.eventRoot,
    projection: POST_SEARCH_VISIBLE_PROJECTION,
    coverage: coverageForSegmentDescriptors(descriptors),
  }, descriptors);

  return await writePostSearchCatalogDirectory(store, {
    publisherId,
    generatedAt,
    source,
    segments: segments.map((segment, index) => ({
      descriptor: descriptors[index],
      root: segment.root,
    })),
    routing,
    globalScoring,
  });
}

type CatalogDirectoryInput = {
  publisherId: string;
  generatedAt: number;
  source: PostSearchSourceSnapshot;
  segments: Array<{ descriptor: PostSearchSegmentDescriptor; root: CID }>;
  routing: { root: CID | null; mappingCount: number };
  globalScoring: PostSearchGlobalScoringIndex;
};

async function writePostSearchCatalogDirectory(
  store: Store,
  input: CatalogDirectoryInput,
): Promise<CID> {
  const manifest: PostSearchCatalogManifest = {
    format: POST_SEARCH_CATALOG_FORMAT,
    publisherId: input.publisherId,
    generatedAt: input.generatedAt,
    source: input.source,
    compatibility: {
      documentFormat: POST_SEARCH_DOCUMENT_FORMAT,
      rankedSegmentFormat: RANKED_SEARCH_SEGMENT_FORMAT,
      normalization: POST_SEARCH_NORMALIZATION,
      fields: POST_SEARCH_BUILD_OPTIONS.fields,
      maxTokensPerField: POST_SEARCH_BUILD_OPTIONS.maxTokensPerField,
      authorTerms: POST_SEARCH_AUTHOR_TERMS_PROJECTION,
      termRouting: POST_SEARCH_TERM_ROUTING_FORMAT,
      globalScoring: POST_SEARCH_GLOBAL_SCORING_FORMAT,
    },
    routing: {
      format: POST_SEARCH_TERM_ROUTING_FORMAT,
      entry: input.routing.root ? 'term-routing' : null,
      mappingCount: input.routing.mappingCount,
    },
    globalScoring: {
      format: POST_SEARCH_GLOBAL_SCORING_FORMAT,
      entry: 'global-scoring',
    },
    segments: input.segments.map((segment) => segment.descriptor),
  };
  const manifestBytes = encoder.encode(JSON.stringify(manifest));
  if (manifestBytes.length > POST_SEARCH_MAX_CATALOG_BYTES) {
    throw new PostSearchCatalogCapacityError(
      'Post search catalog manifest exceeds the authenticated reader capacity',
    );
  }
  const manifestFile = await new HashTree({ store }).putFile(
    manifestBytes,
  );
  const entries: TreeEntry[] = [{
    name: 'manifest.json',
    cid: manifestFile.cid,
    size: manifestFile.size,
    type: LinkType.File,
  }];
  input.segments.forEach((segment) => {
    entries.push({
      name: segment.descriptor.entry,
      cid: segment.root,
      size: 0,
      type: LinkType.Dir,
    });
  });
  if (input.routing.root) {
    entries.push({
      name: 'term-routing',
      cid: input.routing.root,
      size: input.routing.mappingCount,
      type: LinkType.Dir,
    });
  }
  entries.push({
    name: 'global-scoring',
    cid: input.globalScoring.root,
    size: input.globalScoring.manifest.termCount,
    type: LinkType.Dir,
  });

  return (await new HashTree({ store }).putDirectory(entries)).cid;
}

export async function readPostSearchCatalog(
  store: Store,
  root: CID,
  signal?: AbortSignal,
): Promise<PostSearchCatalog> {
  const tree = new HashTree({ store });
  const entries = await tree.listDirectory(root, signal);
  const manifestEntry = entries.find((entry) => entry.name === 'manifest.json');
  if (!manifestEntry || manifestEntry.type !== LinkType.File) {
    throw new Error('Missing post search catalog manifest');
  }
  const manifestBytes = await tree.readFile(manifestEntry.cid, {
    maxBytes: POST_SEARCH_MAX_CATALOG_BYTES,
  });
  if (!manifestBytes) {
    throw new Error('Unreadable post search catalog manifest');
  }
  const manifest = parsePostSearchCatalogManifest(decoder.decode(manifestBytes));
  const entriesByName = new Map(entries.map((entry) => [entry.name, entry]));
  const segments = manifest.segments.map((segment) => {
    const entry = entriesByName.get(segment.entry);
    if (!entry || entry.type !== LinkType.Dir) {
      throw new Error(`Missing post search segment: ${segment.entry}`);
    }
    return { ...segment, root: entry.cid };
  });
  const routing = manifest.routing
    ? {
        ...manifest.routing,
        root: routingRootForManifest(manifest.routing, entriesByName),
      }
    : null;
  const globalScoring = manifest.globalScoring
    ? await readGlobalScoringForManifest(
        store,
        manifest.globalScoring,
        entriesByName,
        manifest.source.coverage.eventCount,
        signal,
      )
    : null;
  return { manifest, routing, globalScoring, segments };
}

export function parseStoredPostSearchDocument(raw: string | undefined): StoredPostSearchDocument | null {
  if (!raw) {
    return null;
  }
  try {
    const value = JSON.parse(raw) as Partial<StoredPostSearchDocument>;
    if (value.format !== POST_SEARCH_DOCUMENT_FORMAT || !isRawSearchableEvent(value.event)) {
      return null;
    }
    return { format: POST_SEARCH_DOCUMENT_FORMAT, event: normalizeSearchableEvent(value.event) };
  } catch {
    return null;
  }
}

/** Canonical v4/v5 document projection shared by every immutable post-search builder. */
export function createPostSearchDocument(
  rawEvent: RawEvent,
  names: readonly string[] = [],
): RankedSearchDocument {
  const event = normalizeSearchableEvent(rawEvent);
  const title = tagValues(event.tags, ['subject', 'summary', 'title']);
  const hashtags = tagValues(event.tags, ['t']).map((hashtag) => `#${hashtag.replace(/^#/, '')}`);
  const author = [event.pubkey, ...names.map((name) => name.trim()).filter(Boolean)];
  const value: StoredPostSearchDocument = { format: POST_SEARCH_DOCUMENT_FORMAT, event };
  return {
    id: event.id,
    fields: { author, content: event.content, hashtags, title },
    value: JSON.stringify(value),
  };
}

function normalizeSearchableEvent(event: RawEvent): RawEvent {
  if (!isRawSearchableEvent(event)) {
    throw new Error('Invalid searchable Nostr event');
  }
  return {
    id: event.id.toLowerCase(),
    pubkey: event.pubkey.toLowerCase(),
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => tag.map(String)),
    content: event.content,
    sig: event.sig,
  };
}

function isRawSearchableEvent(value: unknown): value is RawEvent {
  return isObject(value)
    && typeof value.id === 'string'
    && HEX_64.test(value.id.toLowerCase())
    && typeof value.pubkey === 'string'
    && HEX_64.test(value.pubkey.toLowerCase())
    && typeof value.created_at === 'number'
    && Number.isInteger(value.created_at)
    && value.created_at >= 0
    && typeof value.kind === 'number'
    && SUPPORTED_KINDS.has(value.kind)
    && Array.isArray(value.tags)
    && value.tags.every((tag) => Array.isArray(tag) && tag.every((item) => typeof item === 'string'))
    && typeof value.content === 'string'
    && typeof value.sig === 'string';
}

function tagValues(tags: readonly string[][], names: readonly string[]): string[] {
  const allowed = new Set(names);
  return tags
    .filter((tag) => allowed.has(tag[0]) && tag[1]?.trim())
    .map((tag) => tag[1].trim());
}

function routingRootForManifest(
  routing: PostSearchTermRoutingDescriptor,
  entriesByName: ReadonlyMap<string, TreeEntry>,
): CID | null {
  if (routing.entry === null) {
    return null;
  }
  const entry = entriesByName.get(routing.entry);
  if (!entry || entry.type !== LinkType.Dir) {
    throw new Error('Missing post search term routing index');
  }
  return entry.cid;
}

async function readGlobalScoringForManifest(
  store: Store,
  globalScoring: PostSearchGlobalScoringDescriptor,
  entriesByName: ReadonlyMap<string, TreeEntry>,
  documentCount: number,
  signal?: AbortSignal,
): Promise<PostSearchGlobalScoringIndex> {
  const entry = entriesByName.get(globalScoring.entry);
  if (!entry || entry.type !== LinkType.Dir) {
    throw new Error('Missing post search global scoring index');
  }
  const scoring = await readPostSearchGlobalScoring(
    store,
    entry.cid,
    documentCount,
    POST_SEARCH_BUILD_OPTIONS.fields,
    signal,
  );
  if (entry.size !== scoring.manifest.termCount) {
    throw new Error('Post search catalog global scoring term count is inconsistent');
  }
  return scoring;
}

function compareSegmentInputs(left: PostSearchSegmentInput, right: PostSearchSegmentInput): number {
  return (left.since ?? -1) - (right.since ?? -1)
    || (left.until ?? -1) - (right.until ?? -1)
    || compareStrings(nhashEncode(left.root), nhashEncode(right.root));
}

function segmentDescriptor(segment: PostSearchSegmentInput): PostSearchSegmentDescriptor {
  const descriptor: PostSearchSegmentDescriptor = {
    entry: 'segment-000000',
    projection: validateProjection(segment.projection),
    documentCount: nonNegativeInteger(segment.documentCount, 'segment documentCount'),
    kinds: validateKinds(segment.kinds),
    since: nullableTimestamp(segment.since, 'segment since'),
    until: nullableTimestamp(segment.until, 'segment until'),
  };
  validateSegmentCoverage(descriptor);
  return descriptor;
}

function coverageForSegmentDescriptors(
  segments: readonly PostSearchSegmentDescriptor[],
): PostSearchCoverage {
  const populated = segments.filter((segment) => segment.documentCount > 0);
  return {
    eventCount: segments.reduce((sum, segment) => safeAdd(sum, segment.documentCount), 0),
    kinds: uniqueNumbers(populated.flatMap((segment) => segment.kinds)),
    since: populated.length > 0
      ? Math.min(...populated.map((segment) => segment.since as number))
      : null,
    until: populated.length > 0
      ? Math.max(...populated.map((segment) => segment.until as number))
      : null,
  };
}

function compareSegmentDescriptors(
  left: { descriptor: PostSearchSegmentDescriptor; root: CID },
  right: { descriptor: PostSearchSegmentDescriptor; root: CID },
): number {
  return (left.descriptor.since ?? -1) - (right.descriptor.since ?? -1)
    || (left.descriptor.until ?? -1) - (right.descriptor.until ?? -1)
    || compareStrings(nhashEncode(left.root), nhashEncode(right.root));
}

function safeAdd(left: number, right: number): number {
  const sum = left + right;
  if (!Number.isSafeInteger(sum) || sum < 0) {
    throw new Error('Invalid post search catalog coverage');
  }
  return sum;
}

function assertPostSearchSegmentCapacity(count: number): void {
  if (!Number.isSafeInteger(count) || count < 0 || count > POST_SEARCH_MAX_CATALOG_SEGMENTS) {
    throw new PostSearchCatalogCapacityError(
      `Post search catalog exceeds ${POST_SEARCH_MAX_CATALOG_SEGMENTS} segments; compact first`,
    );
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw signal.reason ?? new DOMException('The operation was aborted', 'AbortError');
  }
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
