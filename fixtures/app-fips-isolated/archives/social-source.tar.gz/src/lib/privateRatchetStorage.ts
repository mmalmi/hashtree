import { verifyEvent, type VerifiedEvent } from 'nostr-tools/pure';
import { assertPrivatePublicationPolicy } from './privatePublicationPolicy';
import type { SocialLiveTransport } from './socialDataPlaneTypes';

type BrowserStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem' | 'key' | 'length'>;

/** Storage errors must propagate: a ratchet cannot safely pretend a write succeeded. */
export function createPrivateRatchetStorage(storage: BrowserStorage, prefix: string) {
  return {
    async get<T = unknown>(key: string): Promise<T | undefined> {
      const value = storage.getItem(prefix + key);
      return value === null ? undefined : JSON.parse(value) as T;
    },
    async put<T = unknown>(key: string, value: T): Promise<void> {
      storage.setItem(prefix + key, JSON.stringify(value));
    },
    async del(key: string): Promise<void> { storage.removeItem(prefix + key); },
    async list(filter = ''): Promise<string[]> {
      const keys: string[] = [];
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        if (key?.startsWith(prefix + filter)) { keys.push(key.slice(prefix.length)); }
      }
      return keys;
    },
  };
}

export type PrivateRatchetStorage = ReturnType<typeof createPrivateRatchetStorage>;

/** Gossip is opportunistic; only an actual relay/provider receipt retires an event. */
export async function publishPrivateRatchetEnvelope(event: VerifiedEvent,
  publishRelay: () => Promise<void>, peer: SocialLiveTransport | null): Promise<void> {
  if (!peer?.publishWithReceipt) {
    void peer?.publish(event).catch(() => undefined);
    return publishRelay();
  }
  await Promise.any([publishRelay(), peer.publishWithReceipt(event).then(accepted => {
    if (!accepted) { throw new Error('The message provider has not accepted this event.'); }
  })]);
}

function admitEnvelope(event: VerifiedEvent): VerifiedEvent {
  const copy = JSON.parse(JSON.stringify(event)) as VerifiedEvent;
  const invite = copy.kind === 30078
    && copy.tags.some(tag => tag[0] === 'l' && tag[1] === 'double-ratchet/invites');
  const roster = copy.kind === 37368 && copy.content === ''
    && !copy.tags.some(tag => tag[0] === 'encrypted_device_labels');
  assertPrivatePublicationPolicy(copy);
  if (!(copy.kind === 1060 || copy.kind === 1059 || invite || roster) || !verifyEvent(copy)) {
    throw new Error('Private sync requires a ratcheted envelope or device authorization.');
  }
  return copy;
}

/** The outbox holds already sealed envelopes; every retry sends identical bytes. */
export function createPrivateRatchetOutbox(
  storage: PrivateRatchetStorage,
  publish: (event: VerifiedEvent, signal: AbortSignal) => Promise<void>,
  onError: (error: unknown) => void = () => {},
) {
  const abort = new AbortController();
  const inFlight = new Map<string, Promise<void>>();
  const enqueuing = new Map<string, Promise<void>>();
  let timer: ReturnType<typeof setInterval> | undefined;

  async function enqueue(event: VerifiedEvent): Promise<void> {
    abort.signal.throwIfAborted();
    const copy = admitEnvelope(event);
    const key = `outbox/${copy.id}`;
    const existing = enqueuing.get(key);
    if (existing) { return existing; }
    const saving = (async () => {
      if (!await storage.get(key)) { await storage.put(key, copy); }
      abort.signal.throwIfAborted();
    })().finally(() => enqueuing.delete(key));
    enqueuing.set(key, saving);
    return saving;
  }
  function attempt(key: string): Promise<void> {
    const existing = inFlight.get(key);
    if (existing) { return existing; }
    const sending = (async () => {
      await enqueuing.get(key);
      abort.signal.throwIfAborted();
      const event = await storage.get<VerifiedEvent>(key);
      if (!event) { return; }
      await publish(admitEnvelope(event), abort.signal);
      abort.signal.throwIfAborted();
      await storage.del(key);
    })().finally(() => inFlight.delete(key));
    inFlight.set(key, sending);
    return sending;
  }
  async function retry(): Promise<void> {
    if (abort.signal.aborted) { return; }
    // A slow message server must not prevent independent conversations progressing.
    await Promise.allSettled((await storage.list('outbox/')).map(attempt));
  }
  return {
    enqueue,
    async publish(event: VerifiedEvent): Promise<VerifiedEvent> {
      await enqueue(event);
      await attempt(`outbox/${event.id}`);
      return event;
    },
    retry,
    start() {
      if (timer || abort.signal.aborted) { return; }
      timer = setInterval(() => { void retry().catch(onError); }, 5_000);
      void retry().catch(onError);
    },
    stop() { abort.abort(); clearInterval(timer); timer = undefined; },
  };
}
