import type { ViewerGraphMutes } from './socialGraphOvermute';

export type ViewerGraphMutesState = {
  viewer: string | null;
  mutes: ViewerGraphMutes | null;
  /** The cached graph answered (or failed) for this viewer. Never waits on relays. */
  settled: boolean;
};

type Fetch = (viewer: string) => Promise<ViewerGraphMutes>;

const REFRESH_DEBOUNCE_MS = 400;
/** First paint waits at most this long for the cached graph. */
export const VIEWER_GRAPH_MUTES_MAX_WAIT_MS = 1_500;

/**
 * Keeps the viewer's mutes and overmute set from the worker's cached social
 * graph. The graph is local, so this is ready long before any relay answers.
 * Graph changes (relay catch-up, observed lists) refresh it in the background.
 */
export function createViewerGraphMutesSource(
  fetch: Fetch = async (viewer) => (await (await import('./workerClient')).getWorkerClient())
    .queryViewerGraphMutes(viewer),
  maxWaitMs = VIEWER_GRAPH_MUTES_MAX_WAIT_MS,
) {
  let waitTimer: ReturnType<typeof setTimeout> | null = null;
  let state: ViewerGraphMutesState = { viewer: null, mutes: null, settled: false };
  let generation = 0;
  let timer: ReturnType<typeof setTimeout> | null = null;
  const listeners = new Set<(state: ViewerGraphMutesState) => void>();

  const emit = (next: ViewerGraphMutesState): void => {
    state = next;
    for (const listener of listeners) {listener(state);}
  };

  const refresh = async (): Promise<void> => {
    const viewer = state.viewer;
    const current = ++generation;
    if (!viewer) {return;}
    try {
      const mutes = await fetch(viewer);
      if (current === generation && state.viewer === viewer && mutes.viewer === viewer) {
        emit({ viewer, mutes, settled: true });
      }
    } catch (error) {
      console.warn('Failed to read mutes from the cached social graph', error);
      if (current === generation && state.viewer === viewer && !state.settled) {
        emit({ ...state, settled: true });
      }
    }
  };

  return {
    setViewer(viewer: string | null): void {
      if (viewer === state.viewer) {return;}
      if (timer) {clearTimeout(timer); timer = null;}
      if (waitTimer) {clearTimeout(waitTimer); waitTimer = null;}
      generation += 1;
      emit({ viewer, mutes: null, settled: viewer === null });
      if (viewer) {
        waitTimer = setTimeout(() => {
          waitTimer = null;
          if (state.viewer === viewer && !state.settled) {emit({ ...state, settled: true });}
        }, maxWaitMs);
      }
      void refresh();
    },
    invalidate(): void {
      if (!state.viewer || timer) {return;}
      timer = setTimeout(() => { timer = null; void refresh(); }, REFRESH_DEBOUNCE_MS);
    },
    subscribe(listener: (state: ViewerGraphMutesState) => void): () => void {
      listeners.add(listener);
      listener(state);
      return () => { listeners.delete(listener); };
    },
    getState: (): ViewerGraphMutesState => state,
  };
}

export const viewerGraphMutes = createViewerGraphMutesSource();
