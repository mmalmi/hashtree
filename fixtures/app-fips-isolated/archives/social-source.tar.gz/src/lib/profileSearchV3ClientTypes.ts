import type { CID } from '@hashtree/core';
import type { ProfileRecord, RawEvent } from './nostr';

export const PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT =
  'iris-social/routed-profile-search-catalog@3' as const;
export const PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT =
  'iris-social/routed-profile-search-run@3' as const;

export const PACKED_PAGE_FORMAT = 'iris-social/post-search-v5-packed-page@1';
export const PAGE_ROUTER_FORMAT = 'iris-social/post-search-v5-page-router@1';
export const NORMALIZATION = 'NFKD-accent-folded-lowercase@1';
export const RANK_POLICY = 'lower-frozen-social-rank-first@1';
export const PARTITION_POLICY = 'first-hex-nibble@1';
export const MANIFEST_ENTRY = 'manifest.json';
export const RUN_PROFILE_ENTRY = 'profiles';
export const RUN_POSTING_ENTRY = 'postings';
export const ROUTER_INDEX_ENTRY = 'index.json';
export const MAX_CATALOG_RUNS = 16;
export const MAX_QUERY_RESULTS = 100;
export const MAX_QUERY_CANDIDATES = 1_024;
export const MAX_REACHABLE_NODES = 9_000_000;
export const MAX_ROUTER_CHILDREN = 128;
export const MAX_ROUTER_HEIGHT = 52;
export const MAX_ROUTER_METADATA_BYTES = 1_048_576;
export const MAX_PACKED_PAGE_BYTES = 1_048_576;
export const MAX_PACKED_PAGE_ENTRIES = 16_384;
export const MAX_PACKED_KEY_BYTES = 4_096;
export const MAX_PACKED_VALUE_BYTES = 262_144;
export const MAX_PROFILE_CONTENT_BYTES = 262_144;
export const MAX_EVENT_TAGS = 256;
export const MAX_EVENT_TAG_ITEMS = 64;
export const MAX_EVENT_TAG_ITEM_BYTES = 4_096;
export const MAX_EVENT_TAG_BYTES = 65_536;
export const MAX_QUERY_TRIGRAMS = 12;
export const MAX_PREFIX_CODEPOINTS = 48;
export const MAX_TERM_BYTES = 512;
export const ROOT_MAX_BYTES = 65_536;
export const RUN_MANIFEST_MAX_BYTES = 65_536;
export const CATALOG_MANIFEST_MAX_BYTES = 256 * 1_024;
export const PACKED_HEADER_BYTES = 20;
export const PACKED_ENTRY_HEADER_BYTES = 8;
export const SEPARATOR = '\0';
export const PACKED_MAGIC = Uint8Array.from([
  0x49, 0x52, 0x49, 0x53, 0x50, 0x35, 0x50, 0x47,
]);

export type ProfileSearchV3ClientPostingMode =
  | 'identifier'
  | 'nip05'
  | 'identity'
  | 'word'
  | 'prefix'
  | 'trigram';

export interface ProfileSearchV3ClientHit {
  event: RawEvent;
  profile: ProfileRecord;
  rankHint: number;
  textScore: number;
  matchedModes: ProfileSearchV3ClientPostingMode[];
}

export interface ProfileSearchV3ClientRunDescriptor {
  entry: string;
  root: string;
  rangeStart: string;
  rangeEnd: string;
  minimumPubkey: string;
  maximumPubkey: string;
  profileCount: number;
  postingCount: number;
  pageCount: number;
  reachableNodeCount: number;
  minimumRankHint: number;
  maximumRankHint: number;
}

export interface ProfileSearchV3ClientCatalogManifest {
  format: typeof PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT;
  generatedAt: number;
  sourceRoot: string;
  eligibleRanksSha256: string;
  compatibility: {
    runFormat: typeof PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT;
    normalization: typeof NORMALIZATION;
    rankPolicy: typeof RANK_POLICY;
    partitionPolicy: typeof PARTITION_POLICY;
  };
  runs: ProfileSearchV3ClientRunDescriptor[];
  reachableNodeCount: number;
}

export interface ProfileSearchV3ClientCatalog {
  root: CID;
  manifest: ProfileSearchV3ClientCatalogManifest;
  getProfile(pubkeyOrNpub: string, signal?: AbortSignal | null): Promise<ProfileRecord | null>;
  search(
    query: string,
    limit?: number,
    options?: {
      signal?: AbortSignal | null;
      concurrency?: number;
      onProgress?: (profiles: ProfileRecord[]) => void;
    },
  ): Promise<ProfileRecord[]>;
}

export type ProfileSearchV3ClientBranchManifest = {
  pageKind: 'documents' | 'postings';
  entryCount: number;
  minKey: string;
  maxKey: string;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
};

export type ProfileSearchV3ClientRunManifest = {
  format: typeof PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT;
  packedPageFormat: typeof PACKED_PAGE_FORMAT;
  pageRouterFormat: typeof PAGE_ROUTER_FORMAT;
  normalization: typeof NORMALIZATION;
  rankPolicy: typeof RANK_POLICY;
  profileCount: number;
  postingCount: number;
  minimumRankHint: number;
  maximumRankHint: number;
  branches: {
    profiles: ProfileSearchV3ClientBranchManifest;
    postings: ProfileSearchV3ClientBranchManifest;
  };
  reachableNodeCount: number;
};

export type ProfileSearchV3ClientStoredProfile = {
  event: RawEvent;
  profile: ProfileRecord;
  rankHint: number;
};

export type ProfileSearchV3ClientPageKind = 'documents' | 'postings' | 'terms' | 'visibility';
export type ProfileSearchV3ClientPackedEntry = readonly [key: string, value: string];
export type ProfileSearchV3ClientPackedPage = {
  kind: ProfileSearchV3ClientPageKind;
  entries: readonly ProfileSearchV3ClientPackedEntry[];
};
export type ProfileSearchV3ClientPageDescriptor = {
  minKey: string;
  maxKey: string;
  root: CID;
  byteLength: number;
  entryCount: number;
};
export type ProfileSearchV3ClientNodeDescriptor = {
  minKey: string;
  maxKey: string;
  root: CID;
  height: number;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
};
export type ProfileSearchV3ClientWirePageDescriptor =
  Omit<ProfileSearchV3ClientPageDescriptor, 'root'> & { root: string };
export type ProfileSearchV3ClientWireNodeDescriptor =
  Omit<ProfileSearchV3ClientNodeDescriptor, 'root'> & { root: string };
export type ProfileSearchV3ClientRouterIndex = {
  format: typeof PAGE_ROUTER_FORMAT;
  packedPageFormat: typeof PACKED_PAGE_FORMAT;
  pageKind: ProfileSearchV3ClientPageKind;
  kind: 'leaf' | 'internal';
  height: number;
  minKey: string;
  maxKey: string;
  pageCount: number;
  routerNodeCount: number;
  reachableNodeCount: number;
  children: Array<ProfileSearchV3ClientWirePageDescriptor | ProfileSearchV3ClientWireNodeDescriptor>;
};
export type ProfileSearchV3ClientLoadedRouterNode = {
  index: ProfileSearchV3ClientRouterIndex;
};
export type ProfileSearchV3ClientRoutedPage = {
  descriptor: ProfileSearchV3ClientPageDescriptor;
  page: ProfileSearchV3ClientPackedPage;
};

export interface ProfileSearchV3ClientPageRouter {
  minKey: string;
  maxKey: string;
  lookupPage(
    key: string,
    signal: AbortSignal | null,
  ): Promise<ProfileSearchV3ClientRoutedPage | null>;
  rangePages(
    minimum: string,
    maximum: string,
    signal: AbortSignal | null,
  ): AsyncGenerator<ProfileSearchV3ClientRoutedPage>;
}

export interface ProfileSearchV3ClientOpenRun {
  manifest: ProfileSearchV3ClientRunManifest;
  getProfile(
    value: string,
    signal: AbortSignal | null,
  ): Promise<ProfileSearchV3ClientStoredProfile | null>;
  search(
    query: string,
    limit: number,
    signal: AbortSignal | null,
  ): Promise<ProfileSearchV3ClientHit[]>;
}

export type ProfileSearchV3ClientCatalogEnvelope = {
  root: CID;
  manifest: ProfileSearchV3ClientCatalogManifest;
  runRoots: CID[];
};

export type ProfileSearchV3ClientRunEnvelope = {
  manifest: ProfileSearchV3ClientRunManifest;
  profileRoot: CID;
  postingRoot: CID;
};
