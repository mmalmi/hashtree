import type { ProfileRecord } from './nostr';

export type ProfileIdentity = {
  nip05: string | null;
  lightning: string | null;
  lightningSource: 'lud16' | 'lud06' | null;
};

const MAX_IDENTITY_TEXT_LENGTH = 320;

function isUnsafeIdentityCodePoint(codePoint: number): boolean {
  return codePoint <= 0x1f
    || (codePoint >= 0x7f && codePoint <= 0x9f)
    || (codePoint >= 0x202a && codePoint <= 0x202e)
    || (codePoint >= 0x2066 && codePoint <= 0x2069);
}

/**
 * Profile metadata is untrusted. Keep identity fields as bounded plain text and
 * remove control/bidirectional override characters before presenting them.
 */
export function normalizeProfileIdentityText(value: string | null | undefined): string | null {
  if (typeof value !== 'string') {
    return null;
  }

  const normalized = [...value]
    .filter((character) => !isUnsafeIdentityCodePoint(character.codePointAt(0) ?? 0))
    .join('')
    .replace(/\s+/g, ' ')
    .trim();
  if (!normalized) {
    return null;
  }
  if (normalized.length <= MAX_IDENTITY_TEXT_LENGTH) {
    return normalized;
  }
  return `${normalized.slice(0, MAX_IDENTITY_TEXT_LENGTH - 1)}…`;
}

export function getProfileIdentity(profile: ProfileRecord | null | undefined): ProfileIdentity {
  const lud16 = normalizeProfileIdentityText(profile?.lud16);
  const lud06 = normalizeProfileIdentityText(profile?.lud06);

  return {
    nip05: normalizeProfileIdentityText(profile?.nip05),
    lightning: lud16 ?? lud06,
    lightningSource: lud16 ? 'lud16' : lud06 ? 'lud06' : null,
  };
}
