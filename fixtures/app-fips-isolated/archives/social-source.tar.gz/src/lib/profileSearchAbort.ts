export function profileSearchAbortReason(signal: AbortSignal | null): unknown {
  return signal?.reason ?? new DOMException('Profile search was cancelled', 'AbortError');
}

export function throwIfProfileSearchAborted(signal: AbortSignal | null): void {
  if (signal?.aborted) {
    throw profileSearchAbortReason(signal);
  }
}

export async function withProfileSearchAbort<T>(
  operation: Promise<T>,
  signal: AbortSignal | null,
): Promise<T> {
  throwIfProfileSearchAborted(signal);
  if (!signal) {
    return await operation;
  }

  let abort: (() => void) | null = null;
  const cancelled = new Promise<never>((_resolve, reject) => {
    abort = () => reject(profileSearchAbortReason(signal));
    signal.addEventListener('abort', abort, { once: true });
  });
  try {
    return await Promise.race([operation, cancelled]);
  } finally {
    if (abort) {
      signal.removeEventListener('abort', abort);
    }
  }
}
