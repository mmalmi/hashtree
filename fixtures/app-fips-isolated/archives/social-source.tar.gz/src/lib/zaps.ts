import type { SocialAccount } from './accounts';
import { parseBolt11Millisats } from './bolt11';
import { getConfiguredNostrRelays } from './htreeRuntime';
import type { ProfileRecord, RawEvent } from './nostr';
import { createZapRequestEventAsync } from './nostrPublish';
import { WalletPaymentError } from './walletTypes';

export const DEFAULT_ZAP_BITS = 21;

const LNURL_FETCH_TIMEOUT_MS = 10_000;
const MAX_LNURL_JSON_BYTES = 64 * 1024;
const MAX_INVOICE_LENGTH = 20_000;
const BECH32_CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const BECH32_GENERATORS = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];

type ZapProfile = Pick<ProfileRecord, 'lud16' | 'lud06'> | null | undefined;

type LnurlPayMetadata = {
  tag?: unknown;
  callback?: unknown;
  minSendable?: unknown;
  maxSendable?: unknown;
  allowsNostr?: unknown;
  nostrPubkey?: unknown;
  status?: unknown;
  reason?: unknown;
};

type LnurlInvoiceResponse = {
  pr?: unknown;
  routes?: unknown;
  status?: unknown;
  reason?: unknown;
};

type WebLnProvider = {
  enable?: () => Promise<void>;
  sendPayment: (invoice: string) => Promise<unknown>;
};

type WebLnWindow = Window & {
  webln?: WebLnProvider;
};

export type ZapInvoice = {
  invoice: string;
  amountBits: number;
  amountMillisats: number;
  endpointUrl: string;
  callbackUrl: string;
  zapRequest: RawEvent;
};

export type ZapAllRunOptions = {
  amountBits: number;
  maxBudgetBits: number;
  comment: string;
};

export type ZapAllLogEntry = {
  id: string;
  type: 'success' | 'error' | 'skip';
  message: string;
  eventId: string;
  authorPubkey: string;
};

function stripLightningScheme(value: string): string {
  return value.trim().replace(/^lightning:/i, '').trim();
}

function readNumber(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === 'string' && /^\d+(\.\d+)?$/.test(value.trim())) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function normalizeZapBits(value: number): number {
  const bits = Math.floor(value);
  if (!Number.isFinite(bits) || bits <= 0) {
    throw new Error('Zap amount must be positive.');
  }
  return bits;
}

function bech32HrpExpand(prefix: string): number[] {
  const values: number[] = [];
  for (const character of prefix) {
    values.push(character.charCodeAt(0) >> 5);
  }
  values.push(0);
  for (const character of prefix) {
    values.push(character.charCodeAt(0) & 31);
  }
  return values;
}

function bech32Polymod(values: number[]): number {
  let checksum = 1;
  for (const value of values) {
    const top = checksum >> 25;
    checksum = ((checksum & 0x1ffffff) << 5) ^ value;
    for (let index = 0; index < BECH32_GENERATORS.length; index += 1) {
      if ((top >> index) & 1) {
        checksum ^= BECH32_GENERATORS[index] ?? 0;
      }
    }
  }
  return checksum >>> 0;
}

function decodeBech32(value: string): { prefix: string; words: number[] } | null {
  const trimmed = stripLightningScheme(value);
  if (!trimmed || (trimmed !== trimmed.toLowerCase() && trimmed !== trimmed.toUpperCase())) {
    return null;
  }

  const normalized = trimmed.toLowerCase();
  const separatorIndex = normalized.lastIndexOf('1');
  if (separatorIndex <= 0 || separatorIndex + 7 > normalized.length) {
    return null;
  }

  const prefix = normalized.slice(0, separatorIndex);
  const payload = normalized.slice(separatorIndex + 1);
  const words: number[] = [];
  for (const character of payload) {
    const word = BECH32_CHARSET.indexOf(character);
    if (word < 0) {
      return null;
    }
    words.push(word);
  }

  if (bech32Polymod([...bech32HrpExpand(prefix), ...words]) !== 1) {
    return null;
  }

  return { prefix, words: words.slice(0, -6) };
}

function convertBits(data: number[], fromBits: number, toBits: number, pad: boolean): number[] | null {
  let accumulator = 0;
  let bitCount = 0;
  const output: number[] = [];
  const maxValue = (1 << toBits) - 1;
  const maxAccumulator = (1 << (fromBits + toBits - 1)) - 1;

  for (const value of data) {
    if (value < 0 || (value >> fromBits) !== 0) {
      return null;
    }
    accumulator = ((accumulator << fromBits) | value) & maxAccumulator;
    bitCount += fromBits;
    while (bitCount >= toBits) {
      bitCount -= toBits;
      output.push((accumulator >> bitCount) & maxValue);
    }
  }

  if (pad) {
    if (bitCount > 0) {
      output.push((accumulator << (toBits - bitCount)) & maxValue);
    }
  } else if (bitCount >= fromBits || ((accumulator << (toBits - bitCount)) & maxValue) !== 0) {
    return null;
  }

  return output;
}

function isLoopbackHostname(hostname: string): boolean {
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]';
}

function normalizeHttpUrl(value: string): string | null {
  try {
    const url = new URL(value);
    const allowedProtocol = url.protocol === 'https:'
      || (isLoopbackHostname(url.hostname) && url.protocol === 'http:');
    return allowedProtocol && !url.username && !url.password
      ? url.toString()
      : null;
  } catch {
    return null;
  }
}

export function decodeLnurlPayUrl(value: string | null | undefined): string | null {
  if (!value) {
    return null;
  }

  const decoded = decodeBech32(value);
  if (!decoded || decoded.prefix !== 'lnurl') {
    return null;
  }

  const bytes = convertBits(decoded.words, 5, 8, false);
  if (!bytes) {
    return null;
  }

  return normalizeHttpUrl(new TextDecoder().decode(new Uint8Array(bytes)));
}

function getLud16Endpoint(value: string | null | undefined): string | null {
  if (!value) {
    return null;
  }

  const address = stripLightningScheme(value);
  const separatorIndex = address.lastIndexOf('@');
  if (separatorIndex <= 0 || separatorIndex === address.length - 1) {
    return null;
  }

  const name = address.slice(0, separatorIndex).trim();
  const domain = address.slice(separatorIndex + 1).trim().toLowerCase();
  if (!name || !domain || /[\s/?#\\]/.test(name) || /[\s/?#\\]/.test(domain)) {
    return null;
  }

  return normalizeHttpUrl(`https://${domain}/.well-known/lnurlp/${encodeURIComponent(name)}`);
}

export function getZapEndpointUrl(profile: ZapProfile): string | null {
  return getLud16Endpoint(profile?.lud16) ?? decodeLnurlPayUrl(profile?.lud06);
}

function getZapLnurlTag(profile: ZapProfile, endpointUrl: string): string {
  return stripLightningScheme(profile?.lud06 || profile?.lud16 || endpointUrl);
}

function throwIfAborted(signal: AbortSignal): void {
  if (signal.aborted) {
    throw signal.reason instanceof Error
      ? signal.reason
      : new DOMException('The operation was aborted.', 'AbortError');
  }
}

async function readLnurlJson(response: Response, signal: AbortSignal): Promise<unknown> {
  const declaredLength = response.headers.get('content-length')?.trim();
  if (declaredLength && /^\d+$/.test(declaredLength)
    && Number(declaredLength) > MAX_LNURL_JSON_BYTES) {
    throw new Error('LNURL service response is too large.');
  }

  const reader = response.body?.getReader();
  if (!reader) {
    return null;
  }

  const chunks: Uint8Array[] = [];
  let byteLength = 0;
  const cancelOnAbort = () => {
    void reader.cancel(signal.reason).catch(() => undefined);
  };
  signal.addEventListener('abort', cancelOnAbort, { once: true });

  try {
    while (true) {
      throwIfAborted(signal);
      const { done, value } = await reader.read();
      throwIfAborted(signal);
      if (done) {
        break;
      }

      byteLength += value.byteLength;
      if (byteLength > MAX_LNURL_JSON_BYTES) {
        void reader.cancel().catch(() => undefined);
        throw new Error('LNURL service response is too large.');
      }
      chunks.push(value);
    }
  } finally {
    signal.removeEventListener('abort', cancelOnAbort);
    reader.releaseLock();
  }

  const body = new Uint8Array(byteLength);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }

  try {
    return JSON.parse(new TextDecoder().decode(body)) as unknown;
  } catch {
    return null;
  }
}

async function fetchJson<T>(url: string): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => {
    controller.abort();
  }, LNURL_FETCH_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      credentials: 'omit',
      redirect: 'error',
      referrerPolicy: 'no-referrer',
      headers: {
        accept: 'application/json',
      },
    });
    const payload = await readLnurlJson(response, controller.signal);
    const status = payload && typeof payload === 'object' ? (payload as { status?: unknown }).status : null;
    if (status === 'ERROR') {
      const reason = (payload as { reason?: unknown }).reason;
      throw new Error(typeof reason === 'string' && reason.trim() ? reason : 'LNURL service rejected the request.');
    }
    if (!response.ok) {
      throw new Error(`LNURL service returned ${response.status}.`);
    }
    if (!payload || typeof payload !== 'object') {
      throw new Error('LNURL service returned invalid JSON.');
    }
    return payload as T;
  } finally {
    clearTimeout(timeout);
  }
}

function assertPayMetadata(metadata: LnurlPayMetadata): asserts metadata is LnurlPayMetadata & { callback: string } {
  if (metadata.tag && metadata.tag !== 'payRequest') {
    throw new Error('Lightning address is not a pay endpoint.');
  }

  if (metadata.allowsNostr !== true) {
    throw new Error('Lightning address does not accept Nostr zaps.');
  }

  if (typeof metadata.nostrPubkey !== 'string' || !/^[0-9a-f]{64}$/i.test(metadata.nostrPubkey)) {
    throw new Error('Lightning address is missing a zap signer.');
  }

  if (typeof metadata.callback !== 'string' || !metadata.callback.trim()) {
    throw new Error('Lightning address is missing a callback URL.');
  }
}

export function buildZapCallbackUrl(
  callbackUrl: string,
  endpointUrl: string,
  amountMillisats: number,
  zapRequest: RawEvent,
): string {
  const endpoint = new URL(endpointUrl);
  const callback = new URL(callbackUrl, endpoint);
  const endpointIsLoopback = isLoopbackHostname(endpoint.hostname);
  const callbackIsLoopback = isLoopbackHostname(callback.hostname);
  const secure = callback.protocol === 'https:';
  const localDevelopment = callback.protocol === 'http:'
    && callbackIsLoopback
    && endpointIsLoopback;
  if (
    (!secure && !localDevelopment)
    || (callbackIsLoopback && !endpointIsLoopback)
    || callback.username
    || callback.password
  ) {
    throw new Error('Lightning address returned an unsafe callback URL.');
  }
  callback.searchParams.set('amount', `${amountMillisats}`);
  callback.searchParams.set('nostr', JSON.stringify(zapRequest));
  return callback.toString();
}

export async function createZapInvoice(options: {
  account: SocialAccount;
  target: RawEvent;
  profile: ZapProfile;
  amountBits?: number;
  comment?: string;
  relays?: string[];
}): Promise<ZapInvoice> {
  const endpointUrl = getZapEndpointUrl(options.profile);
  if (!endpointUrl) {
    throw new Error('This author has no Lightning address.');
  }

  const metadata = await fetchJson<LnurlPayMetadata>(endpointUrl);
  assertPayMetadata(metadata);

  const amountBits = normalizeZapBits(options.amountBits ?? DEFAULT_ZAP_BITS);
  const amountMillisats = amountBits * 1000;
  const minSendable = readNumber(metadata.minSendable);
  const maxSendable = readNumber(metadata.maxSendable);
  if (minSendable !== null && amountMillisats < minSendable) {
    throw new Error(`Minimum zap is ${Math.ceil(minSendable / 1000)} bits.`);
  }
  if (maxSendable !== null && amountMillisats > maxSendable) {
    throw new Error(`Maximum zap is ${Math.floor(maxSendable / 1000)} bits.`);
  }

  const zapRequest = await createZapRequestEventAsync(options.account, options.target, {
    amountMillisats,
    relays: options.relays ?? getConfiguredNostrRelays(),
    lnurl: getZapLnurlTag(options.profile, endpointUrl),
    comment: options.comment,
  });
  const callbackUrl = buildZapCallbackUrl(metadata.callback, endpointUrl, amountMillisats, zapRequest);
  const invoiceResponse = await fetchJson<LnurlInvoiceResponse>(callbackUrl);
  const invoice = typeof invoiceResponse.pr === 'string' ? invoiceResponse.pr.trim() : '';
  if (!invoice || invoice.length > MAX_INVOICE_LENGTH) {
    throw new Error('Lightning address did not return an invoice.');
  }
  const invoiceMillisats = parseBolt11Millisats(invoice);
  if (invoiceMillisats !== amountMillisats) {
    throw new Error('Lightning address returned an invoice for the wrong amount.');
  }

  return {
    invoice,
    amountBits,
    amountMillisats,
    endpointUrl,
    callbackUrl,
    zapRequest,
  };
}

export function lightningPaymentUrl(invoice: string): string {
  return `lightning:${invoice.trim()}`;
}

export function hasWebLnPaymentProvider(): boolean {
  return typeof window !== 'undefined' && Boolean((window as WebLnWindow).webln?.sendPayment);
}

export async function payZapInvoice(
  invoice: string,
  options: {
    requireWebLn?: boolean;
    expectedBits?: number;
    intentId?: string;
    preferredMintUrl?: string;
  } = {},
): Promise<'cashu' | 'nwc' | 'webln' | 'uri'> {
  const trimmed = invoice.trim();
  if (!trimmed) {
    throw new Error('Missing Lightning invoice.');
  }

  if (typeof window === 'undefined') {
    throw new Error('Lightning payments require a browser.');
  }

  const { payWithConnectedNwc } = await import('./nwcWallet');
  if (await payWithConnectedNwc(trimmed, options.expectedBits)) {return 'nwc';}

  if (
    options.expectedBits
    && options.intentId
  ) {
    const { wallet } = await import('./walletStore');
    if (wallet.canPayFromCache(options.expectedBits)) {
      try {
        await wallet.payInvoice(
          trimmed,
          options.expectedBits,
          options.intentId,
          options.preferredMintUrl,
        );
        return 'cashu';
      } catch (error) {
        if (error instanceof WalletPaymentError && error.paymentStarted) {throw error;}
      }
    }
  }

  const webln = (window as WebLnWindow).webln;
  if (webln?.sendPayment) {
    await webln.enable?.();
    await webln.sendPayment(trimmed);
    return 'webln';
  }

  if (options.requireWebLn) {
    throw new Error('WebLN wallet required for zap all.');
  }

  const paymentUrl = lightningPaymentUrl(trimmed);
  const opened = window.open(paymentUrl, '_blank', 'noopener,noreferrer');
  if (!opened) {
    window.location.href = paymentUrl;
  }
  return 'uri';
}
