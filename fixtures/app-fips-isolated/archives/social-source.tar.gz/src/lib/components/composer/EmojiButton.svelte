<script context="module" lang="ts">
  import { createRetryableDynamicImport } from '../../retryableDynamicImport';

  const loadEmojiPicker = createRetryableDynamicImport(() => import('./EmojiPicker.svelte'));
</script>

<script lang="ts">
  import { tick, type ComponentType } from 'svelte';
  import ComposerPopover from './ComposerPopover.svelte';

  export let disabled = false;
  export let onSelect: (emoji: string) => void;
  export let returnFocus: (() => void) | null = null;

  let popover: ComposerPopover;
  let Picker: ComponentType | null = null;
  let loadFailed = false;

  async function load(): Promise<void> {
    if (Picker) { return; }
    loadFailed = false;
    try {
      Picker = (await loadEmojiPicker()).default as unknown as ComponentType;
      await tick();
      popover?.focusContent();
    } catch {
      loadFailed = true;
    }
  }
</script>

<ComposerPopover
  bind:this={popover}
  label="Add emoji"
  panelLabel="Emoji"
  icon="face-smile-solid"
  testId="composer-emoji"
  {disabled}
  {returnFocus}
  onOpen={() => void load()}
>
  {#if Picker}
    <svelte:component this={Picker} {onSelect} />
  {:else if loadFailed}
    <button type="button" class="m-2 rounded-full px-4 py-2 text-[0.9rem] hover:bg-[rgb(var(--iris-text-rgb)/0.08)]" on:click={() => void load()}>
      Retry loading emoji
    </button>
  {:else}
    <div class="grid h-24 w-[min(20.5rem,calc(100vw-1rem))] place-items-center text-[0.88rem] text-[rgb(var(--iris-text-rgb)/0.55)]">Loading…</div>
  {/if}
</ComposerPopover>
