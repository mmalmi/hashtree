<script lang="ts">
  import { EXPIRATION_OPTIONS } from '../../composerOptions';
  import IrisIcon from '../IrisIcon.svelte';
  import ComposerPopover from './ComposerPopover.svelte';

  export let value: number | null = null;
  export let disabled = false;
  export let onChange: (value: number | null) => void;

  let popover: ComposerPopover;
  let list: HTMLDivElement;

  function select(next: number | null): void {
    onChange(next);
    popover.close(true);
  }

  function moveFocus(event: KeyboardEvent): void {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') { return; }
    const buttons = [...list.querySelectorAll<HTMLButtonElement>('button')];
    const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
    const next = buttons[(index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length];
    event.preventDefault();
    next?.focus();
  }

  const optionClass = 'flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-left text-[0.92rem] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:outline-none';
</script>

<ComposerPopover
  bind:this={popover}
  label="Set expiration"
  panelLabel="Expiration"
  icon="clock-solid"
  testId="composer-expiration"
  active={value !== null}
  {disabled}
>
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div bind:this={list} class="w-52 p-1.5" on:keydown={moveFocus}>
    <div class="px-3 pb-1 pt-1.5 text-[0.75rem] font-600 text-[rgb(var(--iris-text-rgb)/0.55)]">Delete after</div>
    {#each EXPIRATION_OPTIONS as option, index (option.value)}
      <button
        type="button"
        class={optionClass}
        aria-pressed={value === option.value}
        data-autofocus={value === option.value || (value === null && index === 0) ? '' : undefined}
        on:click={() => select(option.value)}
      >
        {option.label}
        {#if value === option.value}<IrisIcon name="check" size={16} className="text-violet-400" />{/if}
      </button>
    {/each}
    {#if value !== null}
      <button type="button" class={optionClass + ' text-[rgb(var(--iris-text-rgb)/0.7)]'} on:click={() => select(null)}>No expiration</button>
    {/if}
  </div>
</ComposerPopover>
