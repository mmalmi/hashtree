<script lang="ts">
  import { onDestroy } from 'svelte';
  import {
    encodeGeohash,
    geohashCellSize,
    LOCATION_GEOHASH_PRECISION,
    normalizeGeohash,
  } from '../../composerOptions';
  import IrisIcon from '../IrisIcon.svelte';
  import ComposerPopover from './ComposerPopover.svelte';

  export let value: string | null = null;
  export let disabled = false;
  export let onChange: (geohash: string | null) => void;

  let popover: ComposerPopover;
  let manual = '';
  let error = '';
  let locating = false;
  let destroyed = false;

  function choose(geohash: string | null): void {
    onChange(geohash);
    popover.close(true);
  }

  function reset(): void {
    manual = '';
    error = '';
  }

  // Location is read only after this explicit click, never on its own.
  function useCurrentLocation(): void {
    if (!('geolocation' in navigator)) {
      error = 'Location isn’t available in this browser.';
      return;
    }
    locating = true;
    error = '';
    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (destroyed) { return; }
        locating = false;
        choose(encodeGeohash(position.coords.latitude, position.coords.longitude, LOCATION_GEOHASH_PRECISION));
      },
      (failure) => {
        if (destroyed) { return; }
        locating = false;
        error = failure.code === failure.PERMISSION_DENIED
          ? 'Location permission was denied.'
          : failure.code === failure.TIMEOUT ? 'Finding your location timed out.' : 'Couldn’t find your location.';
      },
      { enableHighAccuracy: false, timeout: 10_000, maximumAge: 5 * 60_000 },
    );
  }

  function addManual(): void {
    const geohash = normalizeGeohash(manual);
    if (!geohash) {
      error = 'Enter a geohash of up to 12 characters (0–9, b–z without a, i, l, o).';
      return;
    }
    choose(geohash);
  }

  onDestroy(() => { destroyed = true; });

  const rowClass = 'flex h-10 w-full items-center gap-2.5 rounded-xl px-3 text-left text-[0.92rem] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:outline-none disabled:cursor-wait disabled:opacity-60';
</script>

<ComposerPopover
  bind:this={popover}
  label="Add location"
  panelLabel="Location"
  icon="marker-pin-solid"
  testId="composer-location"
  active={value !== null}
  {disabled}
  onOpen={reset}
>
  <div class="grid w-[min(18rem,calc(100vw-1rem))] gap-1 p-1.5">
    <button type="button" class={rowClass} data-autofocus disabled={locating} on:click={useCurrentLocation}>
      <IrisIcon name="marker-pin-solid" size={18} className="text-violet-400" />
      {locating ? 'Finding your location…' : 'Use current location'}
    </button>
    <form class="flex items-center gap-1.5 px-1.5 pb-1 pt-1" on:submit|preventDefault={addManual}>
      <input
        bind:value={manual}
        aria-label="Geohash"
        placeholder="Geohash, e.g. u33d"
        maxlength="12"
        autocomplete="off"
        autocapitalize="off"
        spellcheck="false"
        class="h-9 min-w-0 flex-1 rounded-full bg-[rgb(var(--iris-text-rgb)/0.07)] px-3.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.5)] focus:bg-[rgb(var(--iris-text-rgb)/0.1)]"
        on:input={() => { error = ''; }}
      />
      <button
        type="submit"
        class="h-9 shrink-0 rounded-full bg-[rgb(var(--iris-text-rgb)/0.1)] px-3.5 text-[0.88rem] font-650 transition hover:bg-[rgb(var(--iris-text-rgb)/0.16)] disabled:opacity-40"
        disabled={!manual.trim()}
      >Add</button>
    </form>
    {#if error}
      <p role="alert" class="px-3 pb-1 text-[0.82rem] text-[#ffb4b4]">{error}</p>
    {/if}
    <p class="px-3 pb-1.5 text-[0.78rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.55)]">
      Current location is shared as an area about {geohashCellSize(LOCATION_GEOHASH_PRECISION)} wide.
    </p>
    {#if value !== null}
      <button type="button" class={rowClass + ' text-[rgb(var(--iris-text-rgb)/0.7)]'} on:click={() => choose(null)}>
        <IrisIcon name="x-close" size={18} />
        Remove location
      </button>
    {/if}
  </div>
</ComposerPopover>
