// A small curated set keeps the picker light; names drive search and labels.
export type EmojiEntry = readonly [emoji: string, name: string];
export type EmojiGroup = { label: string; emojis: readonly EmojiEntry[] };

export const EMOJI_GROUPS: readonly EmojiGroup[] = [
  {
    label: 'Smileys',
    emojis: [
      ['😀', 'grinning face'], ['😃', 'smiley'], ['😄', 'smile'], ['😁', 'grin'], ['😆', 'laughing'],
      ['😅', 'sweat smile'], ['🤣', 'rolling on the floor laughing rofl'], ['😂', 'joy tears laughing'],
      ['🙂', 'slightly smiling'], ['🙃', 'upside down'], ['😉', 'wink'], ['😊', 'blush happy'],
      ['😇', 'innocent halo angel'], ['🥰', 'smiling hearts love'], ['😍', 'heart eyes love'],
      ['🤩', 'star struck'], ['😘', 'kiss'], ['😋', 'yum delicious'], ['😛', 'tongue'],
      ['😜', 'winking tongue'], ['🤪', 'zany crazy'], ['🤑', 'money mouth'], ['🤗', 'hugging'],
      ['🤭', 'hand over mouth oops'], ['🤫', 'shush quiet'], ['🤔', 'thinking hmm'], ['🤨', 'raised eyebrow'],
      ['😐', 'neutral'], ['😑', 'expressionless'], ['😶', 'no mouth speechless'], ['😏', 'smirk'],
      ['😒', 'unamused'], ['🙄', 'eye roll'], ['😬', 'grimace'], ['😌', 'relieved'], ['😔', 'pensive'],
      ['😴', 'sleeping'], ['😷', 'mask sick'], ['🤯', 'mind blown exploding head'], ['🥳', 'party celebrate'],
      ['😎', 'cool sunglasses'], ['🤓', 'nerd'], ['🧐', 'monocle'], ['😕', 'confused'], ['😟', 'worried'],
      ['😮', 'open mouth wow'], ['😲', 'astonished'], ['🥺', 'pleading'], ['😢', 'cry sad'],
      ['😭', 'sob crying'], ['😱', 'scream fear'], ['😤', 'triumph huff'], ['😡', 'angry pout'],
      ['🤬', 'cursing'], ['😈', 'smiling devil'], ['💀', 'skull dead'], ['💩', 'poop'], ['🤡', 'clown'],
      ['👻', 'ghost'], ['👽', 'alien'], ['🤖', 'robot'], ['🙈', 'see no evil monkey'],
    ],
  },
  {
    label: 'People',
    emojis: [
      ['👋', 'wave hello'], ['🤙', 'shaka call me'], ['👍', 'thumbs up like yes'], ['👎', 'thumbs down no'],
      ['👌', 'ok'], ['🤌', 'pinched fingers'], ['✌️', 'victory peace'], ['🤞', 'crossed fingers luck'],
      ['🤟', 'love you gesture'], ['🤘', 'rock on'], ['👈', 'point left'], ['👉', 'point right'],
      ['👆', 'point up'], ['👇', 'point down'], ['✋', 'raised hand stop'], ['✊', 'raised fist'],
      ['👊', 'fist bump punch'], ['👏', 'clap applause'], ['🙌', 'raising hands hooray'], ['🫶', 'heart hands'],
      ['🤝', 'handshake deal'], ['🙏', 'pray thanks please'], ['✍️', 'writing'], ['💪', 'muscle strong'],
      ['🧠', 'brain'], ['👀', 'eyes looking'], ['🫡', 'salute'], ['🫂', 'people hugging'],
      ['🤷', 'shrug'], ['🤦', 'facepalm'], ['🙋', 'raising hand'], ['🙇', 'bow'], ['💃', 'dancer'],
      ['🕺', 'dancing man'], ['🏃', 'running'], ['🧘', 'yoga meditate'],
    ],
  },
  {
    label: 'Hearts & symbols',
    emojis: [
      ['❤️', 'red heart love'], ['🧡', 'orange heart'], ['💛', 'yellow heart'], ['💚', 'green heart'],
      ['💙', 'blue heart'], ['💜', 'purple heart'], ['🖤', 'black heart'], ['🤍', 'white heart'],
      ['💔', 'broken heart'], ['💕', 'two hearts'], ['💖', 'sparkling heart'], ['💯', 'hundred points'],
      ['✨', 'sparkles'], ['⭐', 'star'], ['🌟', 'glowing star'], ['⚡', 'zap lightning'], ['🔥', 'fire lit'],
      ['💥', 'boom collision'], ['💫', 'dizzy'], ['🎉', 'party popper tada'], ['🎊', 'confetti'],
      ['✅', 'check done'], ['❌', 'cross no'], ['⚠️', 'warning'], ['❓', 'question'], ['❗', 'exclamation'],
      ['💤', 'zzz sleep'], ['💬', 'speech bubble'], ['🫠', 'melting'], ['♾️', 'infinity'],
    ],
  },
  {
    label: 'Nature',
    emojis: [
      ['☀️', 'sun'], ['🌙', 'moon'], ['🌈', 'rainbow'], ['⛅', 'sun behind cloud'], ['🌧️', 'rain'],
      ['❄️', 'snowflake'], ['🌊', 'ocean wave'], ['🌸', 'cherry blossom'], ['🌹', 'rose'],
      ['🌻', 'sunflower'], ['🌱', 'seedling'], ['🌲', 'evergreen tree'], ['🍀', 'four leaf clover'],
      ['🍁', 'maple leaf'], ['🍄', 'mushroom'], ['🐶', 'dog'], ['🐱', 'cat'], ['🦊', 'fox'], ['🐻', 'bear'],
      ['🐼', 'panda'], ['🐨', 'koala'], ['🐯', 'tiger'], ['🦁', 'lion'], ['🐮', 'cow'], ['🐷', 'pig'],
      ['🐸', 'frog'], ['🐵', 'monkey'], ['🐔', 'chicken'], ['🐧', 'penguin'], ['🐦', 'bird'],
      ['🦅', 'eagle'], ['🦉', 'owl'], ['🦄', 'unicorn'], ['🐝', 'bee'], ['🦋', 'butterfly'],
      ['🐢', 'turtle'], ['🐙', 'octopus'], ['🐬', 'dolphin'], ['🐳', 'whale'], ['🦈', 'shark'],
    ],
  },
  {
    label: 'Food & drink',
    emojis: [
      ['🍎', 'apple'], ['🍊', 'orange'], ['🍋', 'lemon'], ['🍌', 'banana'], ['🍉', 'watermelon'],
      ['🍇', 'grapes'], ['🍓', 'strawberry'], ['🍒', 'cherries'], ['🍑', 'peach'], ['🥑', 'avocado'],
      ['🍅', 'tomato'], ['🌶️', 'hot pepper'], ['🥕', 'carrot'], ['🌽', 'corn'], ['🍞', 'bread'],
      ['🥐', 'croissant'], ['🧀', 'cheese'], ['🍳', 'cooking egg'], ['🥓', 'bacon'], ['🍔', 'burger'],
      ['🍟', 'fries'], ['🍕', 'pizza'], ['🌮', 'taco'], ['🍣', 'sushi'], ['🍜', 'ramen noodles'],
      ['🍦', 'ice cream'], ['🍩', 'doughnut'], ['🍪', 'cookie'], ['🎂', 'birthday cake'], ['🍫', 'chocolate'],
      ['🍿', 'popcorn'], ['☕', 'coffee'], ['🍵', 'tea'], ['🍺', 'beer'], ['🍷', 'wine'], ['🥂', 'cheers toast'],
      ['🍸', 'cocktail'], ['🧃', 'juice box'],
    ],
  },
  {
    label: 'Activities & things',
    emojis: [
      ['⚽', 'soccer football'], ['🏀', 'basketball'], ['🎾', 'tennis'], ['🎮', 'video game'], ['🎲', 'dice'],
      ['🎯', 'bullseye target'], ['🎨', 'art palette'], ['🎵', 'music note'], ['🎸', 'guitar'],
      ['🎧', 'headphones'], ['📷', 'camera photo'], ['🎬', 'movie clapper'], ['📚', 'books'],
      ['✏️', 'pencil'], ['💡', 'idea light bulb'], ['💻', 'laptop computer'], ['📱', 'phone'],
      ['🔑', 'key'], ['🔒', 'lock'], ['🛠️', 'tools'], ['⚙️', 'gear'], ['🚀', 'rocket'], ['✈️', 'airplane'],
      ['🚗', 'car'], ['🚲', 'bicycle'], ['🏠', 'house home'], ['🏔️', 'mountain'], ['🏖️', 'beach'],
      ['🌍', 'globe earth world'], ['🗺️', 'map'], ['📍', 'pin location'], ['⏰', 'alarm clock'],
      ['⏳', 'hourglass'], ['🎁', 'gift present'], ['🏆', 'trophy'], ['🥇', 'gold medal'],
      ['💰', 'money bag'], ['💸', 'money flying'], ['🪙', 'coin'], ['📈', 'chart up'],
    ],
  },
];

export function searchEmoji(query: string, limit = 64): EmojiEntry[] {
  const terms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!terms.length) { return []; }
  const matches: EmojiEntry[] = [];
  for (const group of EMOJI_GROUPS) {
    for (const entry of group.emojis) {
      if (terms.every((term) => entry[1].includes(term)) && matches.push(entry) >= limit) { return matches; }
    }
  }
  return matches;
}
