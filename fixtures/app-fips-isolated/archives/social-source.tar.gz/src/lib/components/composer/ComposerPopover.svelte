<script lang="ts">
  import { onDestroy } from 'svelte';
  import IrisIcon from '../IrisIcon.svelte';

  export let label: string;
  export let icon: string;
  export let testId: string;
  export let active = false;
  export let disabled = false;
  export let panelLabel = label;
  /** Where focus goes when Escape closes the panel; the trigger by default. */
  export let returnFocus: (() => void) | null = null;
  export let onOpen: () => void = () => undefined;

  const panelId = `composer-popover-${globalThis.crypto.randomUUID()}`;
  let trigger: HTMLButtonElement;
  let panel: HTMLDivElement;
  let open = false;
  let resizeObserver: ResizeObserver | null = null;

  export function close(focusTrigger = false): void {
    if (panel?.matches(':popover-open')) { panel.hidePopover(); }
    if (focusTrigger) { trigger?.focus({ preventScroll: true }); }
  }

  // The panel sits in the top layer, so it is never clipped by the scrolling
  // dialog. Place it below the trigger when it fits, otherwise above.
  function place(): void {
    if (!open || !trigger || !panel) { return; }
    const margin = 8;
    const gap = 6;
    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    const viewportHeight = window.visualViewport?.height ?? window.innerHeight;
    const anchor = trigger.getBoundingClientRect();
    const spaceBelow = viewportHeight - anchor.bottom - gap - margin;
    const spaceAbove = anchor.top - gap - margin;
    panel.style.maxHeight = '';
    const naturalHeight = panel.scrollHeight;
    const below = naturalHeight <= spaceBelow || spaceBelow >= spaceAbove;
    const height = Math.min(naturalHeight, Math.max(0, below ? spaceBelow : spaceAbove));
    panel.style.maxHeight = `${height}px`;
    const width = panel.offsetWidth;
    panel.style.left = `${Math.max(margin, Math.min(anchor.left, viewportWidth - width - margin))}px`;
    panel.style.top = `${below ? anchor.bottom + gap : anchor.top - gap - height}px`;
    panel.style.visibility = '';
  }

  function listen(active: boolean): void {
    if (active) {
      window.addEventListener('resize', place);
      window.addEventListener('scroll', place, true);
      resizeObserver = typeof ResizeObserver === 'function' ? new ResizeObserver(() => place()) : null;
      resizeObserver?.observe(panel);
    } else {
      window.removeEventListener('resize', place);
      window.removeEventListener('scroll', place, true);
      resizeObserver?.disconnect();
      resizeObserver = null;
    }
  }

  // `beforetoggle` runs synchronously, so state never lags the popover. The
  // panel is placed in the next frame, before it is first painted.
  function handleBeforeToggle(event: ToggleEvent): void {
    if (event.newState === 'open') {
      requestAnimationFrame(opened);
      return;
    }
    if (!open) { return; }
    open = false;
    listen(false);
    panel.style.visibility = 'hidden';
  }

  function opened(): void {
    if (open || !panel?.matches(':popover-open')) { return; }
    open = true;
    listen(true);
    onOpen();
    place();
    focusContent();
  }

  /** Focus the panel's `[data-autofocus]` control, or the panel itself. */
  export function focusContent(): void {
    if (!open) { return; }
    (panel.querySelector<HTMLElement>('[data-autofocus]') ?? panel).focus({ preventScroll: true });
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape' || !open || event.isComposing) { return; }
    // Keep the surrounding dialog open; Escape only closes this panel.
    event.preventDefault();
    close(!returnFocus);
    returnFocus?.();
  }

  onDestroy(() => {
    if (open) { listen(false); }
  });
</script>

<!-- svelte-ignore a11y_no_static_element_interactions -->
<div class="contents" on:keydown={handleKeydown}>
  <button
    bind:this={trigger}
    type="button"
    data-testid={testId}
    aria-label={label}
    title={label}
    aria-haspopup="dialog"
    aria-expanded={open}
    aria-controls={panelId}
    popovertarget={panelId}
    {disabled}
    class={'grid h-10 w-10 shrink-0 place-items-center rounded-full transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-40 '
      + (active || open ? 'text-violet-400' : 'text-[rgb(var(--iris-text-rgb)/0.8)] hover:text-[rgb(var(--iris-text-rgb))]')}
  >
    <IrisIcon name={icon} size={22} />
  </button>
  <div
    bind:this={panel}
    id={panelId}
    popover="auto"
    role="dialog"
    aria-label={panelLabel}
    tabindex="-1"
    style="visibility: hidden"
    class="composer-popover overflow-y-auto overscroll-contain rounded-2xl bg-[var(--iris-surface-active)] text-[rgb(var(--iris-text-rgb))] shadow-[0_12px_40px_rgba(0,0,0,0.45)] outline-none"
    on:beforetoggle={handleBeforeToggle}
    on:toggle={(event) => { if (event.newState === 'open') { opened(); } }}
  >
    <slot {open} {close} />
  </div>
</div>

<style>
  .composer-popover {
    position: fixed;
    inset: auto;
    margin: 0;
    padding: 0;
    border: 0;
  }
</style>
