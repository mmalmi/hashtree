<script lang="ts">
  import { EMOJI_GROUPS, searchEmoji, type EmojiEntry } from './emojiData';

  export let onSelect: (emoji: string) => void;

  const COLUMNS = 8;
  // Typing to search suits a keyboard; on touch the on-screen keyboard would cover the picker.
  const focusSearch = typeof matchMedia === 'function' && matchMedia('(pointer: fine)').matches;
  let query = '';
  let grid: HTMLDivElement;

  $: results = query.trim() ? searchEmoji(query) : null;

  function moveFocus(event: KeyboardEvent): void {
    const steps: Record<string, number> = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: COLUMNS, ArrowUp: -COLUMNS };
    const step = steps[event.key];
    if (!step || !(event.target instanceof HTMLButtonElement)) { return; }
    const buttons = [...grid.querySelectorAll<HTMLButtonElement>('button[data-emoji]')];
    const next = buttons[buttons.indexOf(event.target) + step];
    if (next) {
      event.preventDefault();
      next.focus();
    }
  }

  function handleSearchKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && results?.[0]) {
      event.preventDefault();
      onSelect(results[0][0]);
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      grid.querySelector<HTMLButtonElement>('button[data-emoji]')?.focus();
    }
  }

  const label = (entry: EmojiEntry) => entry[1].split(' ').slice(0, 3).join(' ');
</script>

<div class="flex w-[min(20.5rem,calc(100vw-1rem))] flex-col">
  <div class="p-2 pb-1">
    <input
      bind:value={query}
      data-autofocus={focusSearch ? '' : undefined}
      type="search"
      aria-label="Search emoji"
      placeholder="Search emoji"
      autocomplete="off"
      spellcheck="false"
      class="h-9 w-full rounded-full bg-[rgb(var(--iris-text-rgb)/0.07)] px-3.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.5)] focus:bg-[rgb(var(--iris-text-rgb)/0.1)]"
      on:keydown={handleSearchKeydown}
    />
  </div>
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div bind:this={grid} class="max-h-[15.5rem] overflow-y-auto overscroll-contain px-2 pb-2" on:keydown={moveFocus}>
    {#if results}
      {#if results.length}
        <div class="grid grid-cols-8">
          {#each results as entry (entry[0])}
            <button type="button" data-emoji class="emoji" aria-label={label(entry)} title={label(entry)} on:click={() => onSelect(entry[0])}>{entry[0]}</button>
          {/each}
        </div>
      {:else}
        <p class="px-2 py-6 text-center text-[0.88rem] text-[rgb(var(--iris-text-rgb)/0.55)]">No emoji found</p>
      {/if}
    {:else}
      {#each EMOJI_GROUPS as group (group.label)}
        <div class="px-1.5 pb-1 pt-2 text-[0.75rem] font-600 text-[rgb(var(--iris-text-rgb)/0.55)]">{group.label}</div>
        <div class="grid grid-cols-8">
          {#each group.emojis as entry (entry[0])}
            <button type="button" data-emoji class="emoji" aria-label={label(entry)} title={label(entry)} on:click={() => onSelect(entry[0])}>{entry[0]}</button>
          {/each}
        </div>
      {/each}
    {/if}
  </div>
</div>

<style>
  .emoji {
    display: grid;
    place-items: center;
    aspect-ratio: 1;
    border-radius: 0.6rem;
    font-size: 1.4rem;
    line-height: 1;
    font-family: 'Apple Color Emoji', 'Segoe UI Emoji', 'Noto Color Emoji', sans-serif;
  }

  .emoji:hover,
  .emoji:focus-visible {
    background-color: rgb(var(--iris-text-rgb) / 0.1);
    outline: none;
  }
</style>
