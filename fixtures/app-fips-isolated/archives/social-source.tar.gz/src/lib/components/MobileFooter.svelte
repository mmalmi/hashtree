<script lang="ts">
  import { canSignAccount } from '../accountSigner';
  import type { SocialAccount } from '../accounts';
  import type { Route } from '../appRoute';
  import {
    prewarmWalletRoute,
    scheduleRoutePrewarm,
  } from '../lazyRouteComponents';
  import type { ProfileRecord } from '../nostr';
  import { HOME_HREF, profileHref, searchHref, settingsHref, walletHref } from '../routes';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import WalletNavBalance from './wallet/WalletNavBalance.svelte';

  export let route: Route;
  export let activeAccount: SocialAccount | null = null;
  export let activeProfile: ProfileRecord | null = null;
  export let onCompose: () => void = () => undefined;
  export let onOpenProfile: () => void = () => undefined;
  export let onOpenAccounts: () => void = () => undefined;

  $: profileActive = route.kind === 'accounts'
    || (route.kind === 'profile' && route.pubkey === activeAccount?.pubkey);
  let searchPrewarmScheduled = false;
  let settingsPrewarmScheduled = false;
  let walletPrewarmScheduled = false;

  function handleProfileClick(event: MouseEvent): void {
    if (
      event.button !== 0
      || event.metaKey
      || event.ctrlKey
      || event.shiftKey
      || event.altKey
    ) {
      return;
    }

    event.preventDefault();
    if (event.detail > 1) {
      return;
    }
    onOpenProfile();
  }

  function handleProfileDoubleClick(event: MouseEvent): void {
    event.preventDefault();
    onOpenAccounts();
  }

  function warmSearch(): void {
    if (searchPrewarmScheduled) {
      return;
    }
    searchPrewarmScheduled = true;
    scheduleRoutePrewarm(() => {
      void import('./SearchPage.svelte');
    });
  }

  function warmSettings(): void {
    if (settingsPrewarmScheduled) {
      return;
    }
    settingsPrewarmScheduled = true;
    scheduleRoutePrewarm(() => {
      void import('./SettingsPage.svelte');
    });
  }

  function warmWallet(): void {
    if (walletPrewarmScheduled) {
      return;
    }
    walletPrewarmScheduled = true;
    scheduleRoutePrewarm(prewarmWalletRoute);
  }
</script>

<footer
  data-testid="mobile-footer"
  class="iris-mobile-footer fixed inset-x-0 bottom-[-1px] z-40 bg-[var(--iris-surface)] md:hidden"
  style="padding-bottom: env(safe-area-inset-bottom, 0px)"
>
  {#if activeAccount && !canSignAccount(activeAccount)}
    <div
      data-testid="mobile-readonly-indicator"
      class="flex items-center justify-center gap-1 border-b border-red-500/20 py-1 text-xs text-red-400"
    >
      <IrisIcon name="lock-line" size={12} />
      <span>Read-only mode</span>
    </div>
  {/if}

  <nav class="mx-auto flex max-w-[39rem]" aria-label="Primary navigation">
    <a
      data-testid="mobile-nav-home"
      data-primary-navigation-item="home"
      href={HOME_HREF}
      aria-label="Home"
      aria-current={route.kind === 'home' ? 'page' : undefined}
      class={`flex flex-grow cursor-pointer items-center justify-center p-3 transition ${route.kind === 'home' ? 'text-[rgb(var(--iris-text-rgb))]' : 'text-[rgb(var(--iris-text-rgb)/0.56)]'}`}
    >
      <IrisIcon name={route.kind === 'home' ? 'home-solid' : 'home-outline'} size={24} />
    </a>

    <a
      data-testid="mobile-nav-wallet"
      data-primary-navigation-item="wallet"
      href={walletHref()}
      aria-label="Wallet"
      aria-current={route.kind === 'wallet' ? 'page' : undefined}
      on:focus={warmWallet}
      class={`flex flex-grow cursor-pointer flex-col items-center justify-center gap-0.5 p-2.5 transition ${route.kind === 'wallet' ? 'text-[rgb(var(--iris-text-rgb))]' : 'text-[rgb(var(--iris-text-rgb)/0.56)]'}`}
    >
      <IrisIcon name={route.kind === 'wallet' ? 'wallet-solid' : 'wallet-outline'} size={24} />
      <WalletNavBalance compact={true} />
    </a>

    {#if canSignAccount(activeAccount)}
      <button
        data-testid="mobile-nav-compose"
        type="button"
        class="flex flex-grow cursor-pointer items-center justify-center p-3 text-[rgb(var(--iris-text-rgb)/0.76)] transition"
        aria-label="Compose post"
        on:click={onCompose}
      >
        <IrisIcon name="add-circle-outline" size={28} />
      </button>
    {/if}

    <a
      data-testid="mobile-nav-search"
      data-primary-navigation-item="search"
      href={searchHref()}
      aria-label="Search"
      aria-current={route.kind === 'search' ? 'page' : undefined}
      on:focus={warmSearch}
      class={`flex flex-grow cursor-pointer items-center justify-center p-3 transition ${route.kind === 'search' ? 'text-[rgb(var(--iris-text-rgb))]' : 'text-[rgb(var(--iris-text-rgb)/0.56)]'}`}
    >
      <IrisIcon name={route.kind === 'search' ? 'search-solid' : 'search-outline'} size={24} />
    </a>

    <a
      data-testid="mobile-nav-settings"
      data-primary-navigation-item="settings"
      href={settingsHref()}
      aria-label="Settings"
      aria-current={route.kind === 'settings' ? 'page' : undefined}
      on:focus={warmSettings}
      class={`flex flex-grow cursor-pointer items-center justify-center p-3 transition ${route.kind === 'settings' ? 'text-[rgb(var(--iris-text-rgb))]' : 'text-[rgb(var(--iris-text-rgb)/0.56)]'}`}
    >
      <IrisIcon name={route.kind === 'settings' ? 'settings-solid' : 'settings-outline'} size={24} />
    </a>

    {#if activeAccount}
      <a
        data-testid="mobile-nav-profile"
        data-primary-navigation-item="profile"
        href={profileHref(activeAccount.pubkey)}
        aria-label="Profile. Double-click for accounts"
        aria-current={profileActive ? 'page' : undefined}
        class="flex flex-grow cursor-pointer items-center justify-center p-3"
        on:click={handleProfileClick}
        on:dblclick={handleProfileDoubleClick}
      >
        <span class={`rounded-full border-2 ${profileActive ? 'border-[rgb(var(--iris-text-rgb))]' : 'border-transparent'}`}>
          <Avatar pubkey={activeAccount.pubkey} profile={activeProfile} size={28} />
        </span>
      </a>
    {/if}
  </nav>
</footer>
