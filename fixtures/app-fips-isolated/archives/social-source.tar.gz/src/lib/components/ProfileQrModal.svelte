<script lang="ts">
  import { onDestroy } from 'svelte';
  import QRCode from 'qrcode';
  import type { ProfileRecord } from '../nostr';
  import { getProfileTitle, pubkeyToNpub } from '../nostr';
  import { parseScannedNostrValue } from '../qrNavigation';
  import { createRetryableDynamicImport } from '../retryableDynamicImport';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';
  import ProxyImg from './ProxyImg.svelte';

  export let open = false;
  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let onClose: () => void = () => undefined;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  const gradients = [
    'linear-gradient(135deg,#fb923c,#ec4899 52%,#9333ea)',
    'linear-gradient(135deg,#60a5fa,#a855f7 52%,#ec4899)',
    'linear-gradient(135deg,#4ade80,#3b82f6 52%,#9333ea)',
    'linear-gradient(135deg,#facc15,#ef4444 52%,#ec4899)',
    'linear-gradient(135deg,#818cf8,#a855f7 52%,#ec4899)',
  ];

  let activeTab: 'npub' | 'lightning' = 'npub';
  let scannerOpen = false;
  let scannerLoadError = '';
  let scannerModulePromise: Promise<typeof import('./QrScanner.svelte')> | null = null;
  let copied = false;
  let qrCodeUrl = '';
  let qrRequest = 0;
  let copiedTimer: number | null = null;
  let lastQrValue = '';
  const importScanner = createRetryableDynamicImport(() => import('./QrScanner.svelte'));

  $: npub = pubkeyToNpub(pubkey);
  $: profileName = getProfileTitle(profile, pubkey);
  $: lightningAddress = profile?.lud16?.trim() || '';
  $: bannerUrl = profile?.banner?.trim() || '';
  $: qrValue = activeTab === 'lightning' ? `lightning:${lightningAddress}` : `nostr:${npub}`;
  $: copyValue = activeTab === 'lightning' ? lightningAddress : npub;
  $: displayValue = copyValue.length > 30
    ? `${copyValue.slice(0, 15)}...${copyValue.slice(-15)}`
    : copyValue;
  $: gradient = gradients[Number.parseInt(pubkey.slice(0, 2), 16) % gradients.length];
  $: if (open && qrValue && qrValue !== lastQrValue) {
    lastQrValue = qrValue;
    void generateQr(qrValue);
  }
  $: if (!open) {
    scannerOpen = false;
    scannerLoadError = '';
    copied = false;
  }

  async function generateQr(value: string): Promise<void> {
    const request = ++qrRequest;
    qrCodeUrl = '';
    try {
      const url = await QRCode.toDataURL(value, {
        errorCorrectionLevel: 'H',
        margin: 0,
        width: 256,
        color: { dark: '#000000', light: '#ffffff' },
      });
      if (request === qrRequest) {
        qrCodeUrl = url;
      }
    } catch {
      if (request === qrRequest) {
        qrCodeUrl = '';
      }
    }
  }

  function selectTab(tab: 'npub' | 'lightning'): void {
    activeTab = tab;
  }

  async function copyCurrentValue(): Promise<void> {
    if (!copyValue) {
      return;
    }
    await navigator.clipboard.writeText(copyValue);
    copied = true;
    if (copiedTimer !== null) {
      window.clearTimeout(copiedTimer);
    }
    copiedTimer = window.setTimeout(() => {
      copied = false;
      copiedTimer = null;
    }, 2_000);
  }

  function handleScan(value: string): void {
    const target = parseScannedNostrValue(value);
    if (!target) {
      scannerOpen = false;
      return;
    }
    onClose();
    if (target.kind === 'profile') {
      onOpenProfile?.(target.pubkey);
    } else {
      onOpenThread?.(target.ref);
    }
  }

  function loadScanner(): Promise<typeof import('./QrScanner.svelte')> {
    if (scannerModulePromise) {
      return scannerModulePromise;
    }

    const request = importScanner();
    scannerModulePromise = request;
    void request.catch(() => {
      if (scannerModulePromise === request) {
        scannerModulePromise = null;
      }
    });
    return request;
  }

  function warmScanner(): void {
    void loadScanner().catch(() => undefined);
  }

  async function openScanner(): Promise<void> {
    scannerOpen = true;
    scannerLoadError = '';
    try {
      await loadScanner();
    } catch {
      scannerLoadError = 'Could not load the QR scanner.';
    }
  }

  onDestroy(() => {
    if (copiedTimer !== null) {
      window.clearTimeout(copiedTimer);
    }
  });
</script>

<ModalShell
  {open}
  {onClose}
  shellClass="items-center justify-center p-4 md:p-6"
  contentClass="h-[min(700px,calc(100dvh-2rem))] w-full max-w-[500px]"
  backdropClass="bg-black/78"
>
  <section
    data-testid="profile-qr-modal"
    class="iris-dark-context relative flex h-full w-full flex-col overflow-hidden rounded-lg text-white"
    style={`background:${gradient}`}
  >
    {#if bannerUrl}
      <ProxyImg
        src={bannerUrl}
        alt=""
        className="absolute inset-[-12px] h-[calc(100%+24px)] w-[calc(100%+24px)] scale-105 object-cover blur-lg"
      />
      <div class="absolute inset-0 bg-black/40"></div>
    {/if}

    <div class="relative z-10 flex min-h-0 flex-1 flex-col">
      <button
        type="button"
        class="absolute left-2 top-[calc(0.5rem+env(safe-area-inset-top))] z-20 grid h-11 w-11 place-items-center rounded-lg text-white transition hover:bg-white/10"
        aria-label={scannerOpen ? 'View QR Code' : 'Close QR'}
        on:click={() => scannerOpen ? (scannerOpen = false) : onClose()}
      >
        <IrisIcon name="arrowBack" size={28} />
      </button>

      {#if scannerOpen}
        <h1 class="pt-[calc(0.8rem+env(safe-area-inset-top))] text-center text-2xl font-600">Scan QR Code</h1>
        <div class="flex min-h-0 flex-1 flex-col items-center justify-center px-6">
          <div class="h-80 w-80 max-w-full rounded-2xl bg-white p-1 shadow-2xl">
            {#if scannerLoadError}
              <div
                data-testid="profile-qr-scanner-load-error"
                role="alert"
                class="grid h-full place-content-center gap-4 rounded-2xl bg-black px-6 text-center text-sm text-white"
              >
                <p>{scannerLoadError}</p>
                <button
                  type="button"
                  class="mx-auto rounded-full border border-white/30 px-5 py-2 font-600 hover:bg-white/10"
                  aria-label="Retry QR scanner"
                  on:click={() => void openScanner()}
                >Retry</button>
              </div>
            {:else if scannerModulePromise}
              {#await scannerModulePromise}
                <div class="grid h-full place-items-center rounded-2xl bg-black text-sm text-white/70">
                  Starting camera…
                </div>
              {:then scannerModule}
                <svelte:component this={scannerModule.default} onScan={handleScan} />
              {:catch}
                <div class="grid h-full place-items-center rounded-2xl bg-black px-6 text-center text-sm text-white">
                  Could not load the QR scanner.
                </div>
              {/await}
            {/if}
          </div>
          <p class="mb-8 mt-8 text-center">Scan a user or post QR code<br />to open it on Nostr</p>
        </div>
        <div class="px-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))]">
          <button
            type="button"
            class="w-full rounded-full border border-white/30 bg-white/20 py-4 font-600 text-white shadow-lg backdrop-blur-sm"
            on:click={() => scannerOpen = false}
          >View QR Code</button>
        </div>
      {:else}
        <div class="flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto px-6 pb-6 pt-[calc(3.5rem+env(safe-area-inset-top))]">
          <div class="mb-6 flex flex-col items-center">
            <div class="mb-4 overflow-hidden rounded-full border-4 border-white shadow-xl">
              <Avatar {pubkey} {profile} size={96} />
            </div>
            <h1 class="mb-1 text-2xl font-700 text-white [text-shadow:0_2px_8px_rgba(0,0,0,0.45)]">{profileName}</h1>
            {#if profile?.nip05}
              <p class="text-sm text-white/80 [text-shadow:0_1px_5px_rgba(0,0,0,0.5)]">{profile.nip05.replace('_@', '')}</p>
            {/if}
          </div>

          <div class="mb-6 flex gap-8">
            <button
              type="button"
              class={`pb-2 font-600 text-white ${activeTab === 'npub' ? 'border-b-2 border-white' : 'text-white/60'}`}
              on:click={() => selectTab('npub')}
            >PUBLIC KEY</button>
            {#if lightningAddress}
              <button
                type="button"
                class={`pb-2 font-600 text-white ${activeTab === 'lightning' ? 'border-b-2 border-white' : 'text-white/60'}`}
                on:click={() => selectTab('lightning')}
              >LIGHTNING ADDRESS</button>
            {/if}
          </div>

          <div class="relative mb-6 grid h-72 w-72 place-items-center rounded-2xl bg-white p-4 shadow-2xl">
            {#if qrCodeUrl}
              <img src={qrCodeUrl} alt={activeTab === 'npub' ? 'Public Key QR Code' : 'Lightning Address QR Code'} class="iris-preserve-white h-64 w-64" />
              <div class="pointer-events-none absolute inset-0 grid place-items-center">
                <div class="grid h-16 w-16 place-items-center overflow-hidden rounded-full border-4 border-white bg-black shadow-lg">
                  {#if activeTab === 'npub'}
                    <img src="/favicon.svg" alt="" class="h-9 w-9" />
                  {:else}
                    <IrisIcon name="zap-solid" size={30} className="text-white" />
                  {/if}
                </div>
              </div>
            {:else}
              <div class="h-64 w-64 animate-pulse rounded bg-gray-200"></div>
            {/if}
          </div>

          <button
            type="button"
            class="relative mb-6 flex items-center gap-2 rounded-lg bg-white/10 px-4 py-2 font-mono text-sm text-white transition hover:bg-white/20"
            aria-label={`Copy ${activeTab === 'npub' ? 'public key' : 'lightning address'}`}
            on:click={() => void copyCurrentValue()}
          >
            <span class:invisible={copied}>{displayValue}</span>
            <IrisIcon name="copy" size={16} className={copied ? 'invisible' : ''} />
            {#if copied}<span class="absolute inset-0 grid place-items-center font-sans">Copied</span>{/if}
          </button>

          <button
            type="button"
            class="rounded-full bg-white px-8 py-3 font-600 text-black shadow-lg"
            on:pointerenter={warmScanner}
            on:pointerdown={warmScanner}
            on:focus={warmScanner}
            on:click={() => void openScanner()}
          >Scan QR Code</button>
        </div>
      {/if}
    </div>
  </section>
</ModalShell>
