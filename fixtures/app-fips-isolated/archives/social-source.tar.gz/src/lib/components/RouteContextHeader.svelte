<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';
  export let title: string;
  export let onBack: () => void = () => undefined;
</script>

<header
  data-testid="route-context-header"
  class="sticky top-16 z-10 flex min-h-12 items-center gap-3 border-b border-white/5 bg-[rgba(0,0,0,0.92)] px-3 py-2 backdrop-blur-sm sm:px-4"
>
  <button
    type="button"
    class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white/75 transition hover:bg-white/[0.07] hover:text-white"
    aria-label="Back"
    on:click={onBack}
  >
    <IrisIcon name="arrowBack" size={18} />
  </button>

  <div class="min-w-0 truncate text-[0.98rem] font-700 text-white">
    {title}
  </div>
</header>
