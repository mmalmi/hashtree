<script lang="ts">
  import { onMount } from 'svelte';

  export let onVerify: (token: string) => void = () => undefined;
  export let onError: () => void = () => undefined;

  type TurnstileApi = {
    render: (container: HTMLElement, options: Record<string, unknown>) => string;
    remove: (widgetId: string) => void;
  };

  let container: HTMLDivElement;

  function waitForTurnstile(): Promise<TurnstileApi> {
    return new Promise((resolve, reject) => {
      const startedAt = Date.now();
      const interval = window.setInterval(() => {
        const api = (window as Window & { turnstile?: TurnstileApi }).turnstile;
        if (api) {
          window.clearInterval(interval);
          resolve(api);
        } else if (Date.now() - startedAt > 12_000) {
          window.clearInterval(interval);
          reject(new Error('Verification failed to load.'));
        }
      }, 50);
    });
  }

  onMount(() => {
    let disposed = false;
    let widgetId = '';
    const id = 'iris-turnstile-script';
    if (!document.getElementById(id)) {
      const script = document.createElement('script');
      script.id = id;
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.defer = true;
      document.head.append(script);
    }

    void waitForTurnstile().then((api) => {
      if (disposed) return;
      const host = window.location.hostname;
      const production = host === 'iris.to' || host.endsWith('.iris.to');
      widgetId = api.render(container, {
        sitekey: production ? '0x4AAAAAAACsEd8XuwpPTFwz' : '3x00000000000000000000FF',
        theme: document.documentElement.dataset.theme === 'light' ? 'light' : 'dark',
        callback: onVerify,
        'error-callback': onError,
        'expired-callback': onError,
      });
    }).catch(onError);

    return () => {
      disposed = true;
      const api = (window as Window & { turnstile?: TurnstileApi }).turnstile;
      if (api && widgetId) api.remove(widgetId);
    };
  });
</script>

<div bind:this={container} data-testid="iris-turnstile" class="min-h-[65px]"></div>
