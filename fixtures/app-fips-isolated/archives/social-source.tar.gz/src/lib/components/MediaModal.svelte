<script lang="ts">
  import ModalShell from './ModalShell.svelte';
  import FeedCard from './FeedCard.svelte';
  import SwipeableMediaCarousel from './SwipeableMediaCarousel.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import type { NoteEmbed } from '../noteContent';
  import type { ProfileRecord, RawEvent } from '../nostr';

  export let open = false;
  export let items: NoteEmbed[] = [];
  export let index = 0;
  export let sourceEvent: RawEvent | null = null;
  export let sourceProfile: ProfileRecord | null = null;
  export let onClose: () => void = () => undefined;
  export let onIndexChange: (index: number) => void = () => undefined;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: ((target: string) => void) | null = null;

  let currentIndex = 0;
  let observedOpen = false;
  let observedPropIndex: number | null = null;
  let observedItemsKey = '';
  let currentEmbed: NoteEmbed | null = null;
  let sidebarVisible = true;
  let previousOpen = false;

  function wrapIndex(value: number): number {
    if (items.length === 0) {
      return 0;
    }
    return ((value % items.length) + items.length) % items.length;
  }

  function syncIndexFromProps(nextOpen: boolean, nextIndex: number, itemsKey: string): void {
    const opened = nextOpen && !observedOpen;
    const itemsChanged = itemsKey !== observedItemsKey;
    observedOpen = nextOpen;
    observedItemsKey = itemsKey;
    if (!nextOpen) {
      return;
    }
    if (!opened && !itemsChanged && nextIndex === observedPropIndex) {
      return;
    }
    currentIndex = wrapIndex(nextIndex);
    observedPropIndex = nextIndex;
  }

  function setIndex(nextIndex: number): void {
    if (items.length === 0) {
      return;
    }

    currentIndex = wrapIndex(nextIndex);
    onIndexChange(currentIndex);
  }

  function moveIndex(delta: number): void {
    if (items.length <= 1) {
      return;
    }

    setIndex(currentIndex + delta);
  }

  function toggleSidebar(): void {
    sidebarVisible = !sidebarVisible;
  }

  function handleOpenSourceNote(target: string): void {
    onClose();
    onOpenNote?.(target);
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (!open || event.defaultPrevented) {
      return;
    }

    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      moveIndex(-1);
      return;
    }

    if (event.key === 'ArrowRight') {
      event.preventDefault();
      moveIndex(1);
    }
  }

  $: itemsKey = items.map((item) => `${item.kind}:${item.url}`).join('\n');
  $: syncIndexFromProps(open, index, itemsKey);
  $: currentEmbed = items[currentIndex] ?? null;
  $: if (open !== previousOpen) {
    if (open) {
      sidebarVisible = true;
    }
    previousOpen = open;
  }
</script>

<svelte:window on:keydown={handleKeydown} />

{#if open && currentEmbed}
  <ModalShell
    {open}
    {onClose}
    shellClass="items-stretch justify-stretch p-0"
    contentClass="iris-dark-context h-full w-full"
    backdropClass="iris-media-backdrop bg-black"
  >
    <div data-testid="media-modal" class="flex h-full w-full flex-col lg:flex-row">
      <section
        data-testid="media-modal-viewer"
        aria-label="Media viewer"
        class="relative min-h-0 min-w-0 flex-1 touch-pan-y select-none bg-black"
      >
        <button
          type="button"
          aria-label="Close media modal backdrop"
          class="absolute inset-0 z-0 cursor-default bg-black"
          on:click={onClose}
        ></button>

        <button
          type="button"
          aria-label="Close media modal"
          class="absolute left-3 top-3 z-30 grid h-11 w-11 place-items-center rounded-full bg-black/45 text-white transition hover:bg-black/60"
          on:click={onClose}
        >
          <IrisIcon name="x-close" size={19} />
        </button>

        {#if sourceEvent}
          <button
            type="button"
            aria-label={sidebarVisible ? 'Hide details' : 'Show details'}
            class="absolute right-3 top-3 z-30 hidden h-11 w-11 place-items-center rounded-full bg-black/45 text-white transition hover:bg-black/60 lg:grid"
            on:click={toggleSidebar}
          >
            <IrisIcon name="arrowFront" size={18} className={sidebarVisible ? '' : '-scale-x-100'} />
          </button>
        {/if}

        <div
          class="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-6 py-16 sm:px-10"
        >
          <SwipeableMediaCarousel
            {items}
            index={currentIndex}
            variant="modal"
            onIndexChange={setIndex}
            onBackgroundClick={onClose}
          />
        </div>
      </section>

      {#if sourceEvent && sidebarVisible}
        <aside class="w-full max-h-[40vh] overflow-y-auto border-t border-white/5 bg-[#050505] lg:max-h-none lg:w-[25rem] lg:min-w-[25rem] lg:border-l lg:border-t-0">
          <FeedCard
            event={sourceEvent}
            profile={sourceProfile}
            showEmbeds={false}
            showEngagement={false}
            onOpenProfile={onOpenProfile}
            onOpenNote={onOpenNote ? handleOpenSourceNote : null}
            className="border-0 hover:bg-transparent"
          />

          <slot name="sidebar"></slot>
        </aside>
      {/if}
    </div>
  </ModalShell>
{/if}
