<script lang="ts">
  import type { Action } from 'svelte/action';
  import type { NotificationItem } from '../appDetailLoaders';
  import type { ProfileRecord } from '../nostr';
  import NotificationFeed from './NotificationFeed.svelte';

  export let items: NotificationItem[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let loading = false;
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMore: (() => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: (target: string) => void = () => undefined;
</script>

<section
  data-testid="notifications-page"
  class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
>
  <NotificationFeed
    {items}
    {profiles}
    {loading}
    {hasMore}
    {loadPending}
    {infiniteScroll}
    {onLoadMore}
    {onOpenProfile}
    {onOpenNote}
  />
</section>
