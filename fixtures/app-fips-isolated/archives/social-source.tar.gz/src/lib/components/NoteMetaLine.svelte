<script context="module" lang="ts">
  import { readable } from 'svelte/store';

  const absoluteTimeFormatter = new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  // One shared clock for every visible countdown; it stops with the last one.
  const nowSeconds = readable(Math.floor(Date.now() / 1000), (set) => {
    const interval = setInterval(() => set(Math.floor(Date.now() / 1000)), 30_000);
    return () => clearInterval(interval);
  });
</script>

<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';
  import type { RawEvent } from '../nostr';
  import { formatExpiresIn, getNoteExpiration, getNoteLocation } from '../noteMeta';

  export let event: RawEvent;

  $: location = getNoteLocation(event);
  $: expiration = getNoteExpiration(event);
  $: expiresIn = expiration === null ? '' : formatExpiresIn(expiration, $nowSeconds);
  $: expired = expiresIn === 'Expired';
  $: expirationTitle = expiration === null
    ? ''
    : `${expired ? 'Expired' : 'Expires'} ${absoluteTimeFormatter.format(expiration * 1000)}`;
</script>

{#if location || expiration !== null}
  <div
    data-testid="note-meta"
    class="mt-2 flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1 text-[0.78rem] leading-5 text-white/45"
  >
    {#if location}
      <span data-testid="note-location" class="flex min-w-0 items-center gap-1" title={location.title}>
        <IrisIcon name="marker-pin-solid" size={13} className="shrink-0" />
        <span class="truncate">{location.label}</span>
      </span>
    {/if}
    {#if expiration !== null}
      <span
        data-testid="note-expiration"
        class={`flex shrink-0 items-center gap-1 ${expired ? 'text-red-300/70' : ''}`.trim()}
        title={expirationTitle}
      >
        <IrisIcon name="clock-solid" size={13} className="shrink-0" />
        <span>{expired ? 'Expired' : `Expires in ${expiresIn}`}</span>
      </span>
    {/if}
  </div>
{/if}
