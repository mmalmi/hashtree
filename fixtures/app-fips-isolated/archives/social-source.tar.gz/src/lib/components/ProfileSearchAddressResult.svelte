<script lang="ts">
  import { onDestroy } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { type ProfileSearchAddress } from '../profileSearchAddress';
  import { resolveNip05Address } from '../nip05Verification';

  export let address: ProfileSearchAddress;
  export let onOpenProfile: (pubkey: string) => void;
  export let selected = false;
  export let optionId: string | undefined = undefined;
  /** Like Iris Client, open a valid pasted or typed address without Enter. */
  export let autoOpenDelayMs = 400;

  let controller: AbortController | null = null;
  let loading = false;
  let failed = false;
  let autoTimer: ReturnType<typeof setTimeout> | null = null;
  let addressKey = '';

  $: scheduleAutoOpen(`${address.name}@${address.domain}`);

  function scheduleAutoOpen(key: string): void {
    if (key === addressKey) { return; }
    addressKey = key;
    controller?.abort();
    controller = null;
    loading = false;
    failed = false;
    if (autoTimer) { clearTimeout(autoTimer); }
    autoTimer = setTimeout(() => {
      autoTimer = null;
      void open();
    }, autoOpenDelayMs);
  }

  onDestroy(() => {
    if (autoTimer) { clearTimeout(autoTimer); }
    controller?.abort();
  });

  export async function open(): Promise<void> {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    if (controller) { return; }
    const request = new AbortController();
    controller = request;
    loading = true;
    failed = false;
    try {
      const pubkey = await resolveNip05Address(address, request.signal);
      if (!request.signal.aborted && pubkey) {
        onOpenProfile(pubkey);
        return;
      }
    } catch {
      // A name with an unavailable endpoint can be retried.
    } finally {
      if (controller === request) {
        controller = null;
        loading = false;
      }
    }
    failed = !request.signal.aborted;
  }
</script>

<button
  type="button"
  id={optionId}
  role={optionId ? 'option' : undefined}
  aria-selected={optionId ? selected : undefined}
  aria-busy={loading}
  data-testid="search-profile-address"
  data-active={selected}
  class={`flex w-full cursor-pointer items-center gap-3 rounded-[0.55rem] px-3 py-3 text-left ${selected
    ? 'iris-preserve-white-text bg-violet-600 text-white'
    : 'text-[rgb(var(--iris-text-rgb))] hover:bg-violet-500/15'}`}
  on:click={open}
>
  <IrisIcon name="profile" size={19} className="shrink-0 opacity-70" />
  <span class="min-w-0 truncate">{loading ? 'Looking up' : 'Open'} <strong class="font-700">{address.name}@{address.domain}</strong></span>
</button>
{#if failed}
  <div role="status" class="px-3 pb-2 text-sm opacity-70">Couldn’t find this profile address.</div>
{/if}
