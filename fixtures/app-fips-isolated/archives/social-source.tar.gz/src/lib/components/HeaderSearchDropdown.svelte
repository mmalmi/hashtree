<script lang="ts">
  import { tick } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import UserRow from './UserRow.svelte';
  import {
    canonicalizeThreadReference,
    decodeNostrEventReference,
    normalizePubkey,
    type ProfileRecord,
  } from '../nostr';
  import { isMutedAuthor } from '../muteLists';
  import { overlayProfileRecord } from '../profileRecords';
  import { mergeProfileSearchRecords, sortProfileSearchMatches } from '../profileSearchRanking';
  import { profileHref } from '../routes';
  import { recentProfilesStore } from '../recentProfiles';

  type DropdownResult =
    | { key: string; kind: 'posts'; query: string }
    | {
        key: string;
        kind: 'profile';
        pubkey: string;
        profile: ProfileRecord | null;
        exact: boolean;
        muted: boolean;
      };

  const MAX_RESULTS = 6;

  export let open = false;
  export let query = '';
  export let profilesByPubkey: Map<string, ProfileRecord> = new Map();
  export let profileRecords: ProfileRecord[] = [];
  export let loading = false;
  export let mutedPubkeys: Set<string> = new Set();
  export let viewerPubkey: string | null = null;
  export let root: HTMLDivElement | null = null;
  export let onOpen: () => void = () => undefined;
  export let onQueryChange: (value: string) => void = () => undefined;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenPosts: ((query: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  let input: HTMLInputElement | null = null;
  let resultsContainer: HTMLDivElement | null = null;
  let activeIndex = -1;
  let lastSelectionKey = '';

  $: normalizedQuery = query.trim();
  $: exactPubkey = normalizePubkey(normalizedQuery);
  $: remoteProfiles = profileRecords
    .map((profile) => overlayProfileRecord(profile, profilesByPubkey.get(profile.pubkey) ?? null))
    .filter((profile): profile is ProfileRecord => Boolean(profile));
  $: mergedProfiles = mergeProfileSearchRecords([...profilesByPubkey.values(), ...remoteProfiles]);
  $: matchingProfiles = normalizedQuery.length >= 1
    ? sortProfileSearchMatches(mergedProfiles, normalizedQuery)
        .filter((profile) => !isMutedAuthor(profile.pubkey, mutedPubkeys, viewerPubkey))
    : [];
  $: exactProfile = exactPubkey
    ? overlayProfileRecord(
        profileRecords.find((profile) => profile.pubkey === exactPubkey) ?? null,
        profilesByPubkey.get(exactPubkey) ?? null,
      )
    : null;
  $: dropdownResults = buildResults(
    normalizedQuery,
    exactPubkey,
    exactProfile,
    matchingProfiles,
    mutedPubkeys,
    viewerPubkey,
    $recentProfilesStore.viewer === viewerPubkey ? $recentProfilesStore.pubkeys : [],
  );
  $: selectionKey = `${open}:${normalizedQuery}:${dropdownResults.map((result) => result.key).join(',')}`;
  $: if (selectionKey !== lastSelectionKey) {
    lastSelectionKey = selectionKey;
    activeIndex = open && dropdownResults.length > 0 ? 0 : -1;
  }
  $: activeResult = activeIndex >= 0 ? dropdownResults[activeIndex] ?? null : null;
  $: showDropdown = open
    && (normalizedQuery.length > 0 || dropdownResults.length > 0);

  function buildResults(
    currentQuery: string,
    currentExactPubkey: string | null,
    currentExactProfile: ProfileRecord | null,
    currentProfiles: ProfileRecord[],
    currentMutedPubkeys: Set<string>,
    currentViewerPubkey: string | null,
    recentPubkeys: string[],
  ): DropdownResult[] {
    const results: DropdownResult[] = [];

    if (!currentQuery) {
      return recentPubkeys
        .filter((pubkey) => !isMutedAuthor(pubkey, currentMutedPubkeys, currentViewerPubkey))
        .slice(0, MAX_RESULTS)
        .map((pubkey) => ({
          key: `profile:${pubkey}`, kind: 'profile', pubkey,
          profile: profilesByPubkey.get(pubkey) ?? null, exact: false, muted: false,
        }));
    }

    if (currentExactPubkey) {
      results.push({
        key: `profile:${currentExactPubkey}`,
        kind: 'profile',
        pubkey: currentExactPubkey,
        profile: currentExactProfile,
        exact: true,
        muted: isMutedAuthor(currentExactPubkey, currentMutedPubkeys, currentViewerPubkey),
      });
    } else if (currentQuery.length >= 2) {
      results.push({
        key: `posts:${currentQuery}`,
        kind: 'posts',
        query: currentQuery,
      });
    }

    for (const profile of currentProfiles) {
      if (profile.pubkey === currentExactPubkey || results.length >= MAX_RESULTS) {
        continue;
      }
      results.push({
        key: `profile:${profile.pubkey}`,
        kind: 'profile',
        pubkey: profile.pubkey,
        profile,
        exact: false,
        muted: false,
      });
    }

    return results.slice(0, MAX_RESULTS);
  }

  function handleInput(value: string): void {
    onOpen();
    onQueryChange(value);
    void tick().then(() => {
      if (input && input.value !== query) { input.value = query; }
    });
  }

  function openThreadReference(value: string): boolean {
    const reference = canonicalizeThreadReference(value);
    if (!decodeNostrEventReference(reference) || !onOpenThread) {
      return false;
    }
    onOpenThread(reference);
    return true;
  }

  function selectResult(result: DropdownResult | null): void {
    if (!result) {
      return;
    }
    if (result.kind === 'posts') {
      onOpenPosts?.(result.query);
      return;
    }
    if (onOpenProfile) {
      recentProfilesStore.select(viewerPubkey, result.pubkey);
      onOpenProfile(result.pubkey);
    }
  }

  function scrollActiveIntoView(): void {
    if (!resultsContainer || activeIndex < 0) {
      return;
    }
    resultsContainer.querySelector<HTMLElement>(`#header-search-result-${activeIndex}`)
      ?.scrollIntoView({ block: 'nearest' });
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && openThreadReference((event.currentTarget as HTMLInputElement).value)) {
      event.preventDefault();
      return;
    }

    if (!dropdownResults.length) {
      return;
    }

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      activeIndex = (activeIndex + 1 + dropdownResults.length) % dropdownResults.length;
      void tick().then(scrollActiveIntoView);
      return;
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault();
      activeIndex = (activeIndex - 1 + dropdownResults.length) % dropdownResults.length;
      void tick().then(scrollActiveIntoView);
      return;
    }

    if (event.key === 'Enter') {
      event.preventDefault();
      selectResult(activeResult);
    }
  }

  function handleProfileClick(event: MouseEvent, pubkey: string): void {
    if (event.button === 0) {
      recentProfilesStore.select(viewerPubkey, pubkey);
    }
    if (
      !onOpenProfile
      || event.button !== 0
      || event.metaKey
      || event.ctrlKey
      || event.shiftKey
      || event.altKey
    ) {
      return;
    }
    event.preventDefault();
    onOpenProfile(pubkey);
  }
</script>

<div bind:this={root} data-testid="header-search-trigger" class="relative ml-auto w-full max-w-[20rem]">
  <label
    class={`flex h-10 w-full items-center gap-2 rounded-full border bg-[var(--iris-surface)] px-3 transition-colors ${
      open
        ? 'border-violet-400/65'
        : 'border-[rgb(var(--iris-text-rgb)/0.15)] hover:border-[rgb(var(--iris-text-rgb)/0.24)]'
    }`}
  >
    <input
      bind:this={input}
      data-testid="profile-search-input"
      autocomplete="off"
      value={query}
      placeholder="Search"
      aria-label="Search people and posts"
      aria-autocomplete="list"
      aria-controls="header-search-results"
      aria-expanded={showDropdown}
      aria-activedescendant={activeIndex >= 0 ? `header-search-result-${activeIndex}` : undefined}
      class="min-w-0 flex-1 border-0 bg-transparent text-base text-[rgb(var(--iris-text-rgb))] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.45)]"
      on:focus={onOpen}
      on:input={(event) => handleInput((event.currentTarget as HTMLInputElement).value)}
      on:keydown={handleKeydown}
    />

    {#if query}
      <button
        type="button"
        class="inline-flex h-6 w-6 shrink-0 items-center justify-center text-[rgb(var(--iris-text-rgb)/0.55)] transition hover:text-[rgb(var(--iris-text-rgb))]"
        aria-label="Clear search"
        on:mousedown|preventDefault
        on:click={() => {
          onQueryChange('');
          input?.focus();
        }}
      >
        <IrisIcon name="x-close" size={15} />
      </button>
    {:else}
      <IrisIcon name="search-outline" size={18} className="shrink-0 text-[rgb(var(--iris-text-rgb)/0.5)]" />
    {/if}
  </label>

  {#if showDropdown}
    <div
      bind:this={resultsContainer}
      id="header-search-results"
      data-testid="profile-search-sheet"
      data-presentation="dropdown"
      role="listbox"
      aria-label="Search results"
      aria-busy={Boolean(normalizedQuery) && loading}
      class="absolute left-0 right-0 top-[calc(100%+0.35rem)] z-40 max-h-[min(27rem,calc(100vh-6rem))] overflow-y-auto rounded-[0.65rem] border border-violet-400/55 bg-[var(--iris-surface-raised)] p-1 shadow-[0_18px_50px_rgba(0,0,0,0.3)]"
    >
      {#if !normalizedQuery}
        <div class="flex items-center justify-between px-3 py-2 text-sm text-[rgb(var(--iris-text-rgb)/0.55)]">
          <span>Recent</span>
          <button type="button" aria-label="Clear recent profiles" class="hover:text-[rgb(var(--iris-text-rgb))]" on:click={() => recentProfilesStore.clear()}>Clear</button>
        </div>
      {/if}
      {#each dropdownResults as result, index (result.key)}
        {#if result.kind === 'posts'}
          <button
            id={`header-search-result-${index}`}
            data-testid="header-search-posts-result"
            data-active={activeIndex === index ? 'true' : 'false'}
            role="option"
            aria-selected={activeIndex === index}
            type="button"
            class={`flex w-full cursor-pointer items-center gap-3 rounded-[0.55rem] px-3 py-3 text-left transition-colors ${
              activeIndex === index
                ? 'iris-preserve-white-text bg-violet-600 text-white'
                : 'text-[rgb(var(--iris-text-rgb))] hover:bg-violet-500/15'
            }`}
            on:click={() => selectResult(result)}
          >
            <IrisIcon name="search-outline" size={19} className="shrink-0 opacity-70" />
            <span class="min-w-0 truncate">Search notes: <strong class="font-700">{result.query}</strong></span>
          </button>
        {:else}
          <a
            id={`header-search-result-${index}`}
            data-testid={result.exact ? 'header-search-exact-result' : 'people-row'}
            data-active={activeIndex === index ? 'true' : 'false'}
            role="option"
            aria-selected={activeIndex === index}
            href={profileHref(result.pubkey)}
            class={`block cursor-pointer rounded-[0.55rem] px-3 py-2.5 transition-colors ${
              activeIndex === index
                ? 'iris-preserve-white-text bg-violet-600 text-white'
                : 'text-[rgb(var(--iris-text-rgb))] hover:bg-violet-500/15'
            }`}
            on:click={(event) => handleProfileClick(event, result.pubkey)}
            on:auxclick={(event) => {
              if (event.button === 1) recentProfilesStore.select(viewerPubkey, result.pubkey);
            }}
          >
            <UserRow
              pubkey={result.pubkey}
              profile={result.profile}
              avatarSize={40}
              onOpenProfile={null}
              onSelectProfile={(pubkey) => recentProfilesStore.select(viewerPubkey, pubkey)}
              gapClass="gap-2.5"
              titleClass="truncate text-base font-600"
              subtitleClass="mt-0.5 truncate text-sm opacity-65"
            >
              <span
                slot="end"
                class:hidden={!result.exact}
                class="ml-2 shrink-0 text-sm opacity-65"
              >Exact profile</span>
            </UserRow>
            {#if result.muted}
              <div data-testid="exact-profile-muted" class="mt-1 pl-[3.35rem] text-sm text-amber-300">
                Muted · direct profile link
              </div>
            {/if}
          </a>
        {/if}
      {/each}

      {#if normalizedQuery && loading}
        <div role="status" class="px-3 py-3 text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">Searching…</div>
      {:else if dropdownResults.length === 0}
        <div class="px-3 py-4 text-base text-[rgb(var(--iris-text-rgb)/0.58)]">No people found.</div>
      {/if}
    </div>
  {/if}
</div>
