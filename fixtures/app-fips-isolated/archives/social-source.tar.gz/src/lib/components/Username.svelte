<script context="module" lang="ts">
  const absoluteTimestampFormatter = new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'long',
  });
  const minuteClockListeners = new Set<(now: number) => void>();
  let minuteClockInterval: number | null = null;

  function subscribeMinuteClock(listener: (now: number) => void): () => void {
    minuteClockListeners.add(listener);
    listener(Date.now());
    minuteClockInterval ??= window.setInterval(() => {
      const now = Date.now();
      minuteClockListeners.forEach((notify) => notify(now));
    }, 60_000);
    return () => {
      minuteClockListeners.delete(listener);
      if (minuteClockListeners.size === 0 && minuteClockInterval !== null) {
        window.clearInterval(minuteClockInterval);
        minuteClockInterval = null;
      }
    };
  }
</script>

<script lang="ts">
  import FavoriteStar from '@iris/svelte-ui/FavoriteStar.svelte';
  import { contactMemoryStore } from '../contactMemoryStore';
  import ProfileSocialBadge from './ProfileSocialBadge.svelte';
  import { createProfileRefreshBinding } from '../browserProfileRefresh';
  import { onDestroy } from 'svelte';
  import {
    ensureProfile,
    profileNeedsIndexHydration,
    rememberProfileRecord,
    sharedProfilesStore,
  } from '../profileCache';
  import {
    formatRelativeTime,
    getProfileSubtitle,
    getProfileTitle,
    type ProfileRecord,
  } from '../nostr';
  import { preferNewerProfileRecord } from '../profileRecords';
  import { getRouteActivity } from '../routeActivity';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let timestamp: number | null = null;
  export let fallbackSubtitle = '';
  export let showSubtitle = true;
  export let titleClass = 'truncate text-[1rem] font-700 text-white';
  export let subtitleClass = 'mt-1 truncate text-[0.84rem] text-white/55';
  export let timeClass = 'text-sm text-white/45';
  export let inline = false;
  export let titlePrefix = '';

  let now = Date.now();
  let minuteClockActive = false;
  let unsubscribeMinuteClock: (() => void) | null = null;
  const routeActivity = getRouteActivity();
  const syncProfileRefresh = createProfileRefreshBinding();
  $: syncProfileRefresh(pubkey, $routeActivity);
  onDestroy(() => syncProfileRefresh(null));

  $: rememberProfileRecord(profile);
  $: cachedProfile = $sharedProfilesStore.get(pubkey) ?? null;
  $: resolvedProfile = preferNewerProfileRecord(profile, cachedProfile);
  $: memory = $contactMemoryStore.contacts.get(pubkey);
  $: title = memory?.nickname || memory?.accepted_name || memory?.first_seen_name || getProfileTitle(resolvedProfile, pubkey);
  $: subtitle = getProfileSubtitle(resolvedProfile, pubkey) || fallbackSubtitle;
  $: relativeTimestamp = timestamp === null ? '' : formatRelativeTime(timestamp, now);
  $: absoluteTimestamp =
    timestamp === null
      ? ''
      : absoluteTimestampFormatter.format(timestamp * 1000);
  $: isoTimestamp = timestamp === null ? '' : new Date(timestamp * 1000).toISOString();
  $: if ($routeActivity && profileNeedsIndexHydration(resolvedProfile, ['identity', 'picture'])) {
    void ensureProfile(pubkey);
  }
  $: syncMinuteClock($routeActivity && timestamp !== null);

  function syncMinuteClock(active: boolean): void {
    if (active === minuteClockActive) {
      return;
    }
    minuteClockActive = active;
    unsubscribeMinuteClock?.();
    unsubscribeMinuteClock = active
      ? subscribeMinuteClock((nextNow) => {
          now = nextNow;
        })
      : null;
  }

  onDestroy(() => unsubscribeMinuteClock?.());
</script>

{#if inline}
  <span
    data-testid="username"
    data-profile-loaded={resolvedProfile ? 'true' : 'false'}
    data-minute-clock-active={minuteClockActive ? 'true' : 'false'}
    class={`inline-flex min-w-0 items-center gap-1 ${titleClass}`}
  ><span class="truncate">{titlePrefix}{title}</span>{#if memory?.favorite}<FavoriteStar favorite />{/if}<ProfileSocialBadge {pubkey} active={$routeActivity} reserveSpace /></span>
{:else}
  <div
    data-testid="username"
    data-profile-loaded={resolvedProfile ? 'true' : 'false'}
    data-minute-clock-active={minuteClockActive ? 'true' : 'false'}
    class="min-w-0 flex-1"
  >
    <div class="flex flex-wrap items-center gap-x-2 gap-y-1">
      <div class={`inline-flex min-w-0 max-w-full items-center gap-1 ${titleClass}`}>
        <span class="truncate">{titlePrefix}{title}</span>
        {#if memory?.favorite}<FavoriteStar favorite />{/if}
      </div>

      {#if timestamp !== null}
        <time class={timeClass} datetime={isoTimestamp} title={absoluteTimestamp}>
          {relativeTimestamp}
        </time>
      {/if}

    </div>

    {#if showSubtitle && subtitle}
      <div class={subtitleClass}>
        {subtitle}
      </div>
    {/if}
  </div>
{/if}
