<script lang="ts">
  import { onDestroy } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import NoteShareButton from './NoteShareButton.svelte';
  import RepostMenu from './RepostMenu.svelte';
  import { accountsStore } from '../accounts';
  import { ensureExchangeRates, exchangeRateStore } from '../exchangeRateStore';
  import { formatSatsAmount } from '../exchangeRates';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import {
    ZERO_NOTE_ENGAGEMENT,
    formatCompactStat,
    type NoteEngagement,
  } from '../noteEngagement';
  import { settingsStore } from '../settings';
  import { openZapDialog } from '../zapDialog';
  import { getZapEndpointUrl } from '../zaps';

  export let engagement: NoteEngagement | null = null;
  /** The presented note; enables quoting and the zap dialog from this bar. */
  export let note: RawEvent | null = null;
  /** The note author's profile; undefined means the caller did not look it up. */
  export let authorProfile: ProfileRecord | null | undefined = undefined;
  export let liked = false;
  export let likePending = false;
  export let likeDisabled = false;
  export let onLike: (() => void) | null = null;
  export let zapPending = false;
  export let zapDisabled = false;
  export let onZap: (() => void) | null = null;
  export let onReply: (() => void) | null = null;
  export let onRepost: (() => void) | null = null;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let repostPending = false;
  export let getShareUrl: () => string;
  export let onShare: (() => void) | null = null;

  const LONG_PRESS_MS = 500;
  const LONG_PRESS_SLOP_PX = 10;
  let longPressTimer: ReturnType<typeof setTimeout> | null = null;
  let longPressStart: { x: number; y: number } | null = null;
  let suppressZapClick = false;

  $: current = engagement ?? ZERO_NOTE_ENGAGEMENT;
  $: viewerPubkey = $accountsStore.activeAccountPubkey;
  $: reposted = Boolean(viewerPubkey && current.repostAuthors.includes(viewerPubkey));
  $: zapped = Boolean(viewerPubkey && current.zapSenders.includes(viewerPubkey));
  $: canLike = typeof onLike === 'function' && !likeDisabled;
  $: zapEndpoint = authorProfile === undefined || Boolean(getZapEndpointUrl(authorProfile));
  $: canZap = typeof onZap === 'function' && !zapDisabled && zapEndpoint;
  $: canOpenZapDialog = canZap && note !== null;
  $: quote = onQuote && note ? () => onQuote?.(note as RawEvent) : null;
  $: primaryCurrency = $settingsStore.wallet.primaryCurrency;
  $: ensureExchangeRates(primaryCurrency);
  $: primaryZapAmount = formatSatsAmount(current.zapBits, primaryCurrency, $exchangeRateStore);
  $: formattedZapAmount = (primaryZapAmount === '—'
    ? formatSatsAmount(current.zapBits, 'SAT', null)
    : primaryZapAmount).replace(/ SAT$/, '');
  $: zapTitle = `${current.zapBits} bits from ${current.zapCount} zaps`;

  const actionClass = 'inline-flex min-w-[50px] items-center gap-1 border-0 bg-transparent p-0 text-inherit shadow-none outline-none transition-colors duration-200 appearance-none md:min-w-[80px]';

  function cancelLongPress(): void {
    if (longPressTimer !== null) {clearTimeout(longPressTimer);}
    longPressTimer = null;
    longPressStart = null;
  }

  function openDialog(): void {
    if (!canOpenZapDialog || zapPending) {return;}
    openZapDialog(note as RawEvent, authorProfile ?? null);
  }

  function handleZapPointerDown(event: PointerEvent): void {
    suppressZapClick = false;
    if (!canOpenZapDialog || event.button !== 0) {return;}
    cancelLongPress();
    longPressStart = { x: event.clientX, y: event.clientY };
    longPressTimer = setTimeout(() => {
      longPressTimer = null;
      suppressZapClick = true;
      openDialog();
    }, LONG_PRESS_MS);
  }

  function handleZapPointerMove(event: PointerEvent): void {
    if (!longPressStart) {return;}
    if (Math.hypot(event.clientX - longPressStart.x, event.clientY - longPressStart.y) > LONG_PRESS_SLOP_PX) {
      cancelLongPress();
    }
  }

  function handleZapContextMenu(event: MouseEvent): void {
    if (!canOpenZapDialog) {return;}
    event.preventDefault();
    cancelLongPress();
    suppressZapClick = true;
    openDialog();
  }

  function handleZapClick(): void {
    if (suppressZapClick) {
      suppressZapClick = false;
      return;
    }
    onZap?.();
  }

  onDestroy(cancelLongPress);
</script>

{#if $settingsStore.content.showReactions}
<div
  data-testid="note-engagement"
  class="mt-1 flex flex-row items-center gap-4 py-2 text-base font-400 text-[rgb(var(--iris-text-rgb)/0.5)]"
>
  {#if onReply && $settingsStore.content.showReplies}
    <button
      data-testid="note-reply-button"
      type="button"
      class={`${actionClass} hover:text-sky-400`}
      title={`${current.replyCount} replies`}
      aria-label="Reply"
      on:click={() => onReply?.()}
    >
      <IrisIcon name="reply" size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.replyCount)}</span>{/if}
    </button>
  {/if}

  {#if onRepost && $settingsStore.content.showReposts}
    <RepostMenu
      buttonClass={actionClass}
      count={current.repostCount}
      showCount={$settingsStore.content.showReactionCounts}
      {reposted}
      pending={repostPending}
      onRepost={() => onRepost?.()}
      onQuote={quote}
    />
  {/if}

  {#if $settingsStore.content.showLikes}
  {#if canLike}
    <button
      data-testid="note-like-button"
      type="button"
      title={liked ? 'Liked' : `${current.reactionCount} reactions`}
      class={`${actionClass} hover:text-red-400 disabled:opacity-100 ${liked ? 'text-red-400' : ''}`}
      disabled={likePending || liked}
      on:click={() => onLike?.()}
    >
      <IrisIcon name={liked ? 'heart-solid' : 'heart'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.reactionCount)}</span>{/if}
    </button>
  {:else}
    <div title={`${current.reactionCount} reactions`} class={`${actionClass} ${liked ? 'text-red-400' : ''}`}>
      <IrisIcon name={liked ? 'heart-solid' : 'heart'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.reactionCount)}</span>{/if}
    </div>
  {/if}

  {/if}
  {#if $settingsStore.content.showZaps}
  {#if canZap}
    <button
      data-testid="note-zap-button"
      data-zapped={zapped}
      type="button"
      title={zapped ? `You zapped · ${zapTitle}` : zapTitle}
      aria-label={zapped ? 'Zapped' : 'Zap'}
      class={`${actionClass} zap-button select-none disabled:opacity-60 ${zapped ? '!text-amber-400' : 'hover:text-amber-400'}`}
      disabled={zapPending}
      on:click={handleZapClick}
      on:pointerdown={handleZapPointerDown}
      on:pointermove={handleZapPointerMove}
      on:pointerup={cancelLongPress}
      on:pointercancel={cancelLongPress}
      on:pointerleave={cancelLongPress}
      on:contextmenu={handleZapContextMenu}
    >
      <IrisIcon name={zapped ? 'zap-solid' : 'zap'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span data-testid="note-zap-amount">{formattedZapAmount}</span>{/if}
    </button>
  {:else if zapEndpoint || current.zapCount > 0}
    <!-- Received zaps stay visible even when this viewer cannot zap. -->
    <button type="button" data-testid="note-zap-button" disabled title={zapTitle}
      class={`${actionClass} cursor-default ${zapped ? '!text-amber-400' : ''}`}>
      <IrisIcon name={zapped ? 'zap-solid' : 'zap'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span data-testid="note-zap-amount">{formattedZapAmount}</span>{/if}
    </button>
  {:else}
    <!-- Authors without a Lightning address get no zap action; keep the row aligned. -->
    <span data-testid="note-zap-unavailable" aria-hidden="true" class={actionClass}></span>
  {/if}

  {/if}
  {#if onShare}
    <NoteShareButton {getShareUrl} onCopy={onShare} />
  {/if}
</div>

{/if}

<style>
  .zap-button { -webkit-touch-callout: none; }
</style>
