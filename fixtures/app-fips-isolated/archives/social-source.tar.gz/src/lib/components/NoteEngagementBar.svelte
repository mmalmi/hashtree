<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';
  import { ensureExchangeRates, exchangeRateStore } from '../exchangeRateStore';
  import { formatSatsAmount } from '../exchangeRates';
  import {
    ZERO_NOTE_ENGAGEMENT,
    formatCompactStat,
    type NoteEngagement,
  } from '../noteEngagement';
  import { settingsStore } from '../settings';

  export let engagement: NoteEngagement | null = null;
  export let liked = false;
  export let likePending = false;
  export let likeDisabled = false;
  export let onLike: (() => void) | null = null;
  export let zapPending = false;
  export let zapDisabled = false;
  export let onZap: (() => void) | null = null;
  export let onReply: (() => void) | null = null;
  export let onRepost: (() => void) | null = null;
  export let repostPending = false;
  export let onShare: (() => void) | null = null;

  $: current = engagement ?? ZERO_NOTE_ENGAGEMENT;
  $: canLike = typeof onLike === 'function' && !likeDisabled;
  $: canZap = typeof onZap === 'function' && !zapDisabled;
  $: primaryCurrency = $settingsStore.wallet.primaryCurrency;
  $: ensureExchangeRates(primaryCurrency);
  $: primaryZapAmount = formatSatsAmount(current.zapBits, primaryCurrency, $exchangeRateStore);
  $: formattedZapAmount = (primaryZapAmount === '—'
    ? formatSatsAmount(current.zapBits, 'SAT', null)
    : primaryZapAmount).replace(/ SAT$/, '');

  const actionClass = 'inline-flex min-w-[50px] items-center gap-1 border-0 bg-transparent p-0 text-inherit shadow-none outline-none transition-colors duration-200 appearance-none md:min-w-[80px]';
</script>

{#if $settingsStore.content.showReactions}
<div
  data-testid="note-engagement"
  class="mt-1 flex flex-row items-center gap-4 py-2 text-base font-400 text-[rgb(var(--iris-text-rgb)/0.5)]"
>
  {#if onReply && $settingsStore.content.showReplies}
    <button
      data-testid="note-reply-button"
      type="button"
      class={`${actionClass} hover:text-sky-400`}
      title={`${current.replyCount} replies`}
      aria-label="Reply"
      on:click={() => onReply?.()}
    >
      <IrisIcon name="reply" size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.replyCount)}</span>{/if}
    </button>
  {/if}

  {#if onRepost && $settingsStore.content.showReposts}
    <button
      data-testid="note-repost-button"
      type="button"
      class={`${actionClass} hover:text-emerald-400 disabled:opacity-60`}
      title={`${current.repostCount} reposts`}
      aria-label="Repost"
      disabled={repostPending}
      on:click={() => onRepost?.()}
    >
      <IrisIcon name="repost" size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.repostCount)}</span>{/if}
    </button>
  {/if}

  {#if $settingsStore.content.showLikes}
  {#if canLike}
    <button
      data-testid="note-like-button"
      type="button"
      title={liked ? 'Liked' : `${current.reactionCount} reactions`}
      class={`${actionClass} hover:text-red-400 disabled:opacity-100 ${liked ? 'text-red-400' : ''}`}
      disabled={likePending || liked}
      on:click={() => onLike?.()}
    >
      <IrisIcon name={liked ? 'heart-solid' : 'heart'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.reactionCount)}</span>{/if}
    </button>
  {:else}
    <div title={`${current.reactionCount} reactions`} class={`${actionClass} ${liked ? 'text-red-400' : ''}`}>
      <IrisIcon name={liked ? 'heart-solid' : 'heart'} size={16} />
      {#if $settingsStore.content.showReactionCounts}<span>{formatCompactStat(current.reactionCount)}</span>{/if}
    </div>
  {/if}

  {/if}
  {#if $settingsStore.content.showZaps}
  {#if canZap}
    <button
      data-testid="note-zap-button"
      type="button"
      title={`${current.zapBits} bits from ${current.zapCount} zaps`}
      class={`${actionClass} hover:text-violet-400 disabled:opacity-60`}
      disabled={zapPending}
      on:click={() => onZap?.()}
    >
      <IrisIcon name="zap" size={16} />
      {#if $settingsStore.content.showReactionCounts}<span data-testid="note-zap-amount">{formattedZapAmount}</span>{/if}
    </button>
  {:else}
    <div title={`${current.zapBits} bits from ${current.zapCount} zaps`} class={actionClass}>
      <IrisIcon name="zap" size={16} />
      {#if $settingsStore.content.showReactionCounts}<span data-testid="note-zap-amount">{formattedZapAmount}</span>{/if}
    </div>
  {/if}

  {/if}
  {#if onShare}
    <button
      data-testid="note-share-button"
      type="button"
      class="inline-flex items-center border-0 bg-transparent p-0 text-inherit shadow-none outline-none transition-colors duration-200 hover:text-sky-400 appearance-none"
      title="Share"
      aria-label="Share"
      on:click={() => onShare?.()}
    >
      <IrisIcon name="share-sheet" size={16} />
    </button>
  {/if}
</div>

{/if}
