<script lang="ts">
  import { settingsStore } from '../settings';
  import { getNotePresentation } from '../noteContent';
  import type { NoteEmbed } from '../noteContent';
  import type { RawEvent } from '../nostr';
  import { getSensitiveMediaWarning } from '../sensitiveMedia';
  import NoteEmbedItem from './NoteEmbedItem.svelte';
  import SwipeableMediaCarousel from './SwipeableMediaCarousel.svelte';
  import IrisIcon from './IrisIcon.svelte';

  export let event: RawEvent;
  export let limit = 4;
  export let viewActive = true;
  export let activeMediaUrl: string | null = null;
  export let onEmbedsChange: (embeds: NoteEmbed[]) => void = () => undefined;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let onCarouselGesture: () => void = () => undefined;

  function selectGroups(allGroups: NoteEmbed[][]): NoteEmbed[][] {
    const selected: NoteEmbed[][] = [];
    let remaining = Math.max(0, limit);
    for (const group of allGroups) {
      if (remaining === 0) {
        break;
      }
      const nextGroup = group.slice(0, remaining);
      if (nextGroup.length > 0) {
        selected.push(nextGroup);
        remaining -= nextGroup.length;
      }
    }
    return selected;
  }

  function canOpenInModal(embed: NoteEmbed): boolean {
    return embed.kind !== 'file';
  }

  let revealedEventId = '';

  $: embedGroups = selectGroups(getNotePresentation(event).embedGroups);
  $: embeds = embedGroups.flat();
  $: sensitiveMediaWarning = getSensitiveMediaWarning(event);
  $: sensitiveMediaRevealed = revealedEventId === event.id;
  $: onEmbedsChange(embeds);
</script>

{#if embeds.length > 0}
  <div class="relative mt-3 overflow-hidden rounded-[18px]">
    {#if $settingsStore.content.blurSensitiveMedia && sensitiveMediaWarning && !sensitiveMediaRevealed}
      <button
        data-testid="sensitive-media-gate"
        type="button"
        class="flex min-h-28 w-full flex-col items-center justify-center gap-1 bg-[#111111] px-5 text-center text-white transition hover:bg-[#171717]"
        aria-label={`Reveal media: ${sensitiveMediaWarning}`}
        on:click={() => {
          revealedEventId = event.id;
        }}
      >
        <IrisIcon name="closedeye" size={22} />
        <span class="text-[0.9rem] font-700">{sensitiveMediaWarning}</span>
        <span class="text-[0.78rem] text-white/65">Click to reveal</span>
      </button>
    {:else}
      <div class="grid gap-2.5">
        {#each embedGroups as group (group[0]?.url)}
          {#if group.length > 1 && group.every(canOpenInModal)}
            <SwipeableMediaCarousel
              items={group}
              {viewActive}
              index={Math.max(0, group.findIndex((embed) => embed.url === activeMediaUrl))}
              {activeMediaUrl}
              onGesture={onCarouselGesture}
              onOpenMedia={onOpenMedia
                ? (embed, index) => onOpenMedia({ event, embed, index, embeds: group })
                : null}
            />
          {:else}
            {#each group as embed, index (embed.url)}
              <NoteEmbedItem
                {embed}
                {viewActive}
                active={activeMediaUrl === embed.url}
                onOpenMedia={onOpenMedia && canOpenInModal(embed)
                  ? () => onOpenMedia({ event, embed, index, embeds: group })
                  : null}
              />
            {/each}
          {/if}
        {/each}
      </div>
    {/if}
  </div>
{/if}
