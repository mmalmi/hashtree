<script lang="ts">
  import { settingsStore } from '../settings';
  import { getNotePresentation } from '../noteContent';
  import type { NoteEmbed } from '../noteContent';
  import type { RawEvent } from '../nostr';
  import { getSensitiveMediaWarning } from '../sensitiveMedia';
  import {
    canOpenEmbedInLightbox,
    flattenNoteEmbedSlots,
    noteEmbedSlotKey,
    selectNoteEmbedSlots,
  } from '../noteEmbedLayout';
  import NoteEmbedItem from './NoteEmbedItem.svelte';
  import SwipeableMediaCarousel from './SwipeableMediaCarousel.svelte';
  import IrisIcon from './IrisIcon.svelte';

  /** Fixed-height embed slots; a carousel uses one slot for all of its media. */
  export let limit = 4;
  export let event: RawEvent;
  export let viewActive = true;
  export let activeMediaUrl: string | null = null;
  export let onEmbedsChange: (embeds: NoteEmbed[]) => void = () => undefined;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let onCarouselGesture: () => void = () => undefined;

  let revealedEventId = '';

  $: slots = selectNoteEmbedSlots(getNotePresentation(event).embedGroups, limit);
  $: embeds = flattenNoteEmbedSlots(slots);
  $: sensitiveMediaWarning = getSensitiveMediaWarning(event);
  $: sensitiveMediaRevealed = revealedEventId === event.id;
  $: onEmbedsChange(embeds);
</script>

{#if embeds.length > 0}
  <div class="relative mt-3 overflow-hidden rounded-[18px]">
    {#if $settingsStore.content.blurSensitiveMedia && sensitiveMediaWarning && !sensitiveMediaRevealed}
      <button
        data-testid="sensitive-media-gate"
        type="button"
        class="flex min-h-28 w-full flex-col items-center justify-center gap-1 bg-[#111111] px-5 text-center text-white transition hover:bg-[#171717]"
        aria-label={`Reveal media: ${sensitiveMediaWarning}`}
        on:click={() => {
          revealedEventId = event.id;
        }}
      >
        <IrisIcon name="closedeye" size={22} />
        <span class="text-[0.9rem] font-700">{sensitiveMediaWarning}</span>
        <span class="text-[0.78rem] text-white/65">Click to reveal</span>
      </button>
    {:else}
      <div class="grid gap-2.5">
        {#each slots as slot (noteEmbedSlotKey(slot))}
          {#if slot.kind === 'carousel'}
            <SwipeableMediaCarousel
              items={slot.items}
              {viewActive}
              index={Math.max(0, slot.items.findIndex((embed) => embed.url === activeMediaUrl))}
              {activeMediaUrl}
              onGesture={onCarouselGesture}
              onOpenMedia={onOpenMedia
                ? (embed, index) => onOpenMedia({ event, embed, index, embeds: slot.items })
                : null}
            />
          {:else}
            <NoteEmbedItem
              embed={slot.embed}
              {viewActive}
              active={activeMediaUrl === slot.embed.url}
              onOpenMedia={onOpenMedia && canOpenEmbedInLightbox(slot.embed)
                ? () => onOpenMedia({ event, embed: slot.embed, index: slot.index, embeds: slot.lightbox })
                : null}
            />
          {/if}
        {/each}
      </div>
    {/if}
  </div>
{/if}
