<script lang="ts">
  import { loadWalletPageModule } from '../lazyRouteComponents';

  export let active = false;

  let component: typeof import('./WalletPage.svelte').default | null = null;
  let loadError = '';

  async function load(): Promise<void> {
    if (component) return;
    loadError = '';
    try {
      component = (await loadWalletPageModule()).default;
    } catch (error) {
      loadError = "Couldn't load the wallet.";
      console.warn('Failed to load wallet', error);
    }
  }

  $: if (!component) void load();
</script>

<div
  aria-busy={!component && !loadError}
  class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
>
  {#if component}
    <svelte:component this={component} {active} />
  {:else if loadError}
    <div role="alert" class="grid justify-items-start gap-3 px-4 py-8 text-sm text-[rgb(var(--iris-text-rgb)/0.68)] sm:px-5">
      <span>{loadError}</span>
      <button type="button" class="rounded-full border border-white/15 px-4 py-2 font-700" on:click={() => void load()}>
        Retry
      </button>
    </div>
  {/if}
</div>
