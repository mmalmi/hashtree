<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { accountsStore } from '../accounts';
  import { canSignAccount } from '../accountSigner';
  import {
    browserNotificationState, enableBrowserNotifications, disableBrowserNotifications,
    updateBrowserNotificationPreferences,
  } from '../browserNotifications';

  const kinds = [{ kind: 1, label: 'Replies and mentions' }, { kind: 6, label: 'Reposts' },
    { kind: 7, label: 'Reactions' }, { kind: 9735, label: 'Zaps' }];
  $: account = $accountsStore.accounts.find(item => item.pubkey === $accountsStore.activeAccountPubkey);
  $: state = $browserNotificationState;
  $: locked = state.busy || state.preferences.enabled;
</script>

<div data-testid="settings-notifications-section" class="grid gap-6 p-4 sm:p-5">
  <SettingsGroup title="Browser notifications">
    <SettingsGroupItem isLast={true}>
      <div class="grid gap-3">
        <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">Get updates even when Iris is closed. Uses Iris’s notification service.</p>
        <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">For this account on this browser. Switching accounts turns them off.</p>
        {#if !state.supported}
          <p role="status">This browser does not support push notifications. On iPhone or iPad, add Iris to your Home Screen first.</p>
        {:else if !canSignAccount(account)}
          <p role="status">Sign in with your secret key or browser extension to enable notifications.</p>
        {:else}
          <div class="flex items-center justify-between gap-3">
            <span data-testid="push-status">{state.preferences.enabled ? 'On' : 'Off'}</span>
            <button type="button" data-testid="push-toggle" disabled={state.busy}
              class="rounded-full bg-[var(--iris-solid)] px-4 py-2 text-sm font-600 text-[var(--iris-on-solid)] disabled:opacity-50"
              on:click={() => state.preferences.enabled ? disableBrowserNotifications() : enableBrowserNotifications()}>
              {state.busy ? 'Saving…' : state.preferences.enabled ? 'Turn off' : 'Enable notifications'}
            </button>
          </div>
        {/if}
        {#if state.error}<p role="alert" class="text-sm text-red-500">{state.error}</p>{/if}
      </div>
    </SettingsGroupItem>
  </SettingsGroup>
  <SettingsGroup title="Notify me about">
    {#each kinds as item, index}
      <SettingsGroupItem isLast={index === kinds.length - 1}>
        <label class="flex items-center justify-between gap-4 text-sm">
          <span>{item.label}</span>
          <input type="checkbox" disabled={locked} checked={state.preferences.kinds.includes(item.kind)} class="h-4 w-4 accent-blue-500"
            on:change={() => updateBrowserNotificationPreferences({ kinds: state.preferences.kinds.includes(item.kind)
              ? state.preferences.kinds.filter(kind => kind !== item.kind) : [...state.preferences.kinds, item.kind] })} />
        </label>
      </SettingsGroupItem>
    {/each}
  </SettingsGroup>
  <SettingsGroup title="Privacy">
    <SettingsGroupItem>
      <label class="flex items-center justify-between gap-4 text-sm">
        <span>Only from people in my network</span>
        <input type="checkbox" disabled={locked} checked={state.preferences.socialGraphFilter} class="h-4 w-4 accent-blue-500"
          on:change={() => updateBrowserNotificationPreferences({ socialGraphFilter: !state.preferences.socialGraphFilter })} />
      </label>
    </SettingsGroupItem>
    <SettingsGroupItem isLast={true}>
      <label class="flex items-center justify-between gap-4 text-sm">
        <span>Show previews</span>
        <input type="checkbox" disabled={locked} checked={state.preferences.previews} class="h-4 w-4 accent-blue-500"
          on:change={() => updateBrowserNotificationPreferences({ previews: !state.preferences.previews })} />
      </label>
    </SettingsGroupItem>
  </SettingsGroup>
  {#if state.preferences.enabled}<p class="text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">Turn notifications off to change these options.</p>{/if}
</div>
