<script lang="ts">
  import { articleImage, articleImages, parseArticleContent, type ArticleNode } from '../articleContent';
  import { buildNoteThreadReference } from '../appSharing';
  import { getLongformMetadata } from '../longform';
  import type { NoteEmbed } from '../noteContent';
  import type { RawEvent } from '../nostr';
  import { threadHref } from '../routes';
  import { getSensitiveMediaWarning } from '../sensitiveMedia';
  import { settingsStore } from '../settings';
  import ArticleNodes from './ArticleNodes.svelte';

  export let event: RawEvent;
  export let compact = false;
  export let collapsible = true;
  export let showImages = true;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenNote: ((reference: string) => void) | null = null;
  export let onOpenMedia: ((payload: { event: RawEvent; embed: NoteEmbed; index: number; embeds: NoteEmbed[] }) => void) | null = null;

  let revealedEventId = '';
  $: metadata = getLongformMetadata(event);
  $: nodes = parseArticleContent(event.content);
  $: previewNodes = metadata?.summary ? parseArticleContent(metadata.summary) : nodes.slice(0, compact ? 1 : 3);
  $: cover = metadata?.image ? articleImage(metadata.image) : null;
  $: contentNodes = [
    ...(cover ? [{ type: 'image', embed: cover, alt: metadata?.title ?? 'Article image' } satisfies ArticleNode] : []),
    ...(collapsible ? previewNodes : nodes),
  ];
  $: images = articleImages(contentNodes);
  $: warning = getSensitiveMediaWarning(event);
  $: gateImages = showImages && images.length > 0 && $settingsStore.content.blurSensitiveMedia && Boolean(warning) && revealedEventId !== event.id;
  $: reference = buildNoteThreadReference(event);

  function openArticle(click: MouseEvent): void {
    if (click.button !== 0 || click.metaKey || click.ctrlKey || click.shiftKey || click.altKey || !onOpenNote) { return; }
    click.preventDefault();
    onOpenNote(reference);
  }
</script>

<div data-testid="article-content" class:article-preview={collapsible} class:article-compact={compact} class="article-content">
  {#if gateImages}
    <button type="button" data-testid="article-sensitive-media-gate" class="my-3 w-full rounded-xl bg-white/5 px-4 py-5 text-sm" on:click={() => revealedEventId = event.id}>
      {warning} · Show images
    </button>
  {/if}
  <div class="article-body">
    <ArticleNodes
      nodes={contentNodes}
      imagesVisible={showImages && !gateImages}
      {onOpenProfile}
      {onOpenNote}
      onOpenImage={onOpenMedia ? (embed) => onOpenMedia?.({ event, embed, index: images.findIndex(image => image.url === embed.url), embeds: images }) : null}
    />
  </div>
  {#if collapsible}
    <a data-testid="article-read-more" class="mt-2 inline-block text-sm font-600" href={threadHref(reference)} on:click={openArticle}>Read article</a>
  {/if}
</div>

<style>
  .article-content { min-width: 0; max-width: 100%; color: rgb(var(--iris-text-rgb) / .85); font-size: 1rem; line-height: 1.75; overflow-wrap: anywhere; }
  .article-body { min-width: 0; }
  .article-preview .article-body { max-height: 24rem; overflow: hidden; }
  .article-compact .article-body { max-height: 12rem; }
  .article-content :global(p) { margin: 0 0 1em; }
  .article-content :global(h1), .article-content :global(h2), .article-content :global(h3), .article-content :global(h4), .article-content :global(h5), .article-content :global(h6) { margin: 1.3em 0 .45em; font-weight: 700; line-height: 1.3; color: rgb(var(--iris-text-rgb)); }
  .article-content :global(h1) { font-size: 1.85em; }
  .article-content :global(h2) { font-size: 1.5em; }
  .article-content :global(h3) { font-size: 1.25em; }
  .article-content :global(h4), .article-content :global(h5), .article-content :global(h6) { font-size: 1.1em; }
  .article-content :global(strong) { font-weight: 700; }
  .article-content :global(em) { font-style: italic; }
  .article-content :global(s) { text-decoration: line-through; }
  .article-content :global(ul), .article-content :global(ol) { margin: .6em 0 1em; padding-left: 1.6em; }
  .article-content :global(ul) { list-style: disc; }
  .article-content :global(ol) { list-style: decimal; }
  .article-content :global(li) { margin: .25em 0; }
  .article-content :global(li > ul), .article-content :global(li > ol) { margin: .2em 0; }
  .article-content :global(blockquote) { margin: 1.25em 0; padding-left: 1em; border-left: 3px solid rgb(var(--iris-text-rgb) / .22); color: rgb(var(--iris-text-rgb) / .64); }
  .article-content :global(code) { border-radius: .3rem; background: rgb(var(--iris-text-rgb) / .07); padding: .12em .3em; font-size: .88em; font-family: ui-monospace, monospace; }
  .article-content :global(pre) { max-width: 100%; overflow-x: auto; margin: 1em 0; border-radius: .6rem; padding: .85rem 1rem; background: rgb(var(--iris-text-rgb) / .06); line-height: 1.55; }
  .article-content :global(pre code) { padding: 0; background: none; overflow-wrap: normal; white-space: pre; }
  .article-content :global(a) { color: #a989ee; text-underline-offset: .18em; }
  .article-content :global(a:hover) { text-decoration: underline; }
  .article-content :global(hr) { margin: 1.5em 0; border: 0; border-top: 1px solid rgb(var(--iris-text-rgb) / .15); }
  .article-content :global(table) { display: block; max-width: 100%; overflow-x: auto; border-collapse: collapse; margin: 1em 0; }
  .article-content :global(th), .article-content :global(td) { padding: .45em .75em; border: 1px solid rgb(var(--iris-text-rgb) / .15); text-align: left; }
  .article-content :global(th) { font-weight: 700; background: rgb(var(--iris-text-rgb) / .04); }
  .article-content :global(.article-image) { display: inline-block; width: 100%; overflow: hidden; margin: .5em 0; border-radius: .6rem; vertical-align: middle; }
</style>
