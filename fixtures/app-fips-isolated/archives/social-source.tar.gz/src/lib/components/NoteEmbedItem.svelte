<script lang="ts">
  import { onDestroy } from 'svelte';
  import { settingsStore } from '../settings';
  import { videoAutoplay } from '../videoAutoplay';
  import type { NoteEmbed } from '../noteContent';
  import ProxyImg from './ProxyImg.svelte';
  import {
    generateVideoThumbnailUrl,
    isExternalHttpUrl,
    loadHashtreeObjectUrl,
  } from '../media';
  import { scheduleMediaResolution } from '../mediaLoadScheduler';
  import IrisIcon from './IrisIcon.svelte';

  export let embed: NoteEmbed;
  export let active = false;
  export let viewActive = true;
  export let onOpenMedia: (() => void) | null = null;
  export let variant: 'inline' | 'grid' | 'modal' = 'inline';
  export let autoplay = false;
  export let preload = false;

  let resolvedUrl = '';
  let loading = false;
  let error = '';
  let destroyed = false;
  let loadGeneration = 0;
  let hashtreeLoadPromise: Promise<string> | null = null;
  let videoThumbnailKey = '';
  let videoThumbnailUrl = '';
  let videoThumbnailFailed = false;
  let videoThumbnailGeneration = 0;
  let playbackElement: HTMLMediaElement | null = null;

  function cleanupResolvedUrl(): void {
    if (resolvedUrl && (embed.kind === 'file' || embed.isHashtree)) {
      URL.revokeObjectURL(resolvedUrl);
    }
    resolvedUrl = '';
  }

  function loadHashtreeMedia(): Promise<string> {
    if (hashtreeLoadPromise) {
      return hashtreeLoadPromise;
    }

    const generation = ++loadGeneration;
    loading = true;
    error = '';
    const nextPromise = (async (): Promise<string> => {
      try {
        const resolved = await scheduleMediaResolution(async () => {
          if (destroyed || generation !== loadGeneration) {
            return null;
          }
          return await loadHashtreeObjectUrl(embed.url);
        }, {
          onLateResult: (lateResult) => {
            if (lateResult) {
              URL.revokeObjectURL(lateResult.url);
            }
          },
        });
        if (!resolved) {
          return '';
        }
        if (destroyed || generation !== loadGeneration) {
          URL.revokeObjectURL(resolved.url);
          return '';
        }
        cleanupResolvedUrl();
        resolvedUrl = resolved.url;
        return resolved.url;
      } catch (loadError) {
        if (!destroyed && generation === loadGeneration) {
          error = loadError instanceof Error ? loadError.message : 'Could not load attachment.';
        }
        return '';
      } finally {
        if (generation === loadGeneration) {
          loading = false;
          hashtreeLoadPromise = null;
        }
      }
    })();
    hashtreeLoadPromise = nextPromise;
    return nextPromise;
  }

  async function syncVideoThumbnail(nextEmbed: NoteEmbed): Promise<void> {
    const nextKey = nextEmbed.kind === 'video'
      && !nextEmbed.isHashtree
      && isExternalHttpUrl(nextEmbed.url)
      ? nextEmbed.url
      : '';
    if (nextKey === videoThumbnailKey) {
      return;
    }

    videoThumbnailKey = nextKey;
    videoThumbnailUrl = '';
    videoThumbnailFailed = false;
    const generation = ++videoThumbnailGeneration;
    if (!nextKey) {
      return;
    }

    try {
      const nextUrl = await generateVideoThumbnailUrl(nextKey);
      if (!destroyed && generation === videoThumbnailGeneration) {
        videoThumbnailUrl = nextUrl;
      }
    } catch {
      if (!destroyed && generation === videoThumbnailGeneration) {
        videoThumbnailFailed = true;
      }
    }
  }

  async function ensureLoaded(): Promise<string> {
    if (!embed.isHashtree) {
      return embed.url;
    }

    if (resolvedUrl) {
      return resolvedUrl;
    }

    return await loadHashtreeMedia();
  }

  async function handleFileOpen(): Promise<void> {
    const href = await ensureLoaded();
    if (!href) {
      return;
    }

    const anchor = document.createElement('a');
    anchor.href = href;
    anchor.download =
      embed.kind === 'file'
        ? embed.filename
        : embed.kind === 'image' || embed.kind === 'video' || embed.kind === 'audio'
          ? embed.filename ?? 'attachment'
          : 'attachment';
    anchor.rel = 'noreferrer noopener';
    anchor.click();
  }

  function triggerOpenMedia(mouseEvent: MouseEvent): void {
    if (!onOpenMedia) {
      return;
    }

    mouseEvent.preventDefault();
    mouseEvent.stopPropagation();
    onOpenMedia();
  }

  function shouldOpenPreview(): boolean {
    return variant === 'grid' && !!onOpenMedia;
  }

  function syncViewActivity(nextActive: boolean, nextEmbed: NoteEmbed): void {
    if (nextActive) {
      void syncVideoThumbnail(nextEmbed);
      return;
    }
    if (videoThumbnailKey && !videoThumbnailUrl && !videoThumbnailFailed) {
      videoThumbnailKey = '';
    }
    videoThumbnailGeneration += 1;
    playbackElement?.pause();
  }

  $: ringClass = active ? 'ring-2 ring-white/25' : '';
  $: visualFrameClass =
    variant === 'grid'
      ? 'aspect-square'
      : variant === 'modal'
        ? 'max-h-[82vh]'
        : 'h-[20rem] sm:h-[24rem] lg:h-[28rem]';

  $: imageSurfaceClass =
    variant === 'grid'
      ? `grid h-full w-full place-items-center overflow-hidden bg-black/18 transition ${visualFrameClass} ${ringClass}`.trim()
      : variant === 'modal'
        ? `inline-flex max-w-full items-center justify-center overflow-hidden bg-transparent transition ${visualFrameClass} ${ringClass}`.trim()
        : `flex w-full items-center justify-center overflow-hidden rounded-[24px] bg-black/14 px-2 py-2 transition ${visualFrameClass} sm:px-3 sm:py-3 ${ringClass}`.trim();

  $: imagePlaceholderClass =
    variant === 'grid'
      ? 'grid aspect-square w-full place-items-center px-4 py-10 text-[0.95rem] text-white/45'
      : variant === 'modal'
        ? 'grid min-h-[20rem] w-full place-items-center px-4 py-10 text-[0.95rem] text-white/45'
        : 'grid h-[20rem] w-full place-items-center px-4 py-10 text-[0.95rem] text-white/45 sm:h-[24rem] lg:h-[28rem]';

  $: imageClassName =
    variant === 'grid'
      ? 'h-full w-full object-cover'
      : variant === 'modal'
        ? 'block max-h-[82vh] max-w-full object-contain'
        : 'block h-full w-full object-contain';

  $: mediaCardClass =
    variant === 'grid'
      ? `flex aspect-square w-full flex-col items-center justify-center bg-[#111111] px-2 py-2 text-center transition hover:bg-[#171717] ${ringClass}`.trim()
      : `flex w-full flex-col justify-center rounded-[24px] border border-white/5 bg-[#0f0f0f] px-4 py-5 text-left transition hover:bg-[#161616] ${
          variant === 'modal' ? 'min-h-[14rem]' : 'h-[20rem] sm:h-[24rem] lg:h-[28rem]'
        } ${ringClass}`.trim();

  $: audioCardClass =
    variant === 'grid'
      ? `flex aspect-square w-full flex-col items-center justify-center bg-[#111111] px-2 py-2 text-center transition hover:bg-[#171717] ${ringClass}`.trim()
      : `w-full rounded-[24px] border border-white/5 bg-[#0f0f0f] px-4 py-5 text-left transition hover:bg-[#161616] ${ringClass}`.trim();

  $: videoClassName =
    `${
      variant === 'grid'
        ? 'aspect-square w-full object-cover'
        : variant === 'modal'
          ? 'block max-h-[82vh] max-w-full object-contain'
          : 'h-[20rem] w-full object-contain sm:h-[24rem] lg:h-[28rem]'
    } ${variant === 'modal' || variant === 'grid' ? '' : 'rounded-[24px] bg-black/24'} ${ringClass}`.trim();

  $: youtubeSurfaceClass =
    `overflow-hidden bg-black/30 ${variant === 'grid' ? '' : 'rounded-[24px]'} ${
      variant === 'grid'
        ? 'aspect-square'
        : variant === 'modal'
          ? 'aspect-video'
          : 'h-[20rem] sm:h-[24rem] lg:h-[28rem]'
    } ${ringClass}`.trim();

  $: if (viewActive && embed.isHashtree && !resolvedUrl && !loading && !error && (embed.kind === 'image' || variant === 'modal')) {
    void ensureLoaded();
  }
  $: syncViewActivity(viewActive, embed);

  onDestroy(() => {
    destroyed = true;
    loadGeneration += 1;
    videoThumbnailGeneration += 1;
    hashtreeLoadPromise = null;
    cleanupResolvedUrl();
  });
</script>

{#if embed.kind === 'image'}
  {#if onOpenMedia}
    <button
      data-testid="note-embed"
      type="button"
      aria-label={variant === 'grid' ? 'Open image' : undefined}
      class={`border-0 p-0 text-left ${imageSurfaceClass}`.trim()}
      on:click={triggerOpenMedia}
    >
      {#if embed.isHashtree && !resolvedUrl}
        <div class={imagePlaceholderClass}>
          {#if loading}
            Loading image…
          {:else if error}
            {error}
          {:else}
            Loading image…
          {/if}
        </div>
      {:else}
        <ProxyImg
          alt={embed.label ?? embed.filename ?? ''}
          src={embed.isHashtree ? resolvedUrl : embed.url}
          loading={preload ? 'eager' : 'lazy'}
          sha256={embed.sha256}
          fallbackUrls={embed.fallbackUrls}
          width={variant === 'grid' ? 256 : undefined}
          height={variant === 'grid' ? 256 : undefined}
          square={variant === 'grid'}
          className={imageClassName}
        />
      {/if}
    </button>
  {:else}
    {#if variant === 'modal'}
      <div
        data-testid="note-embed"
        class={imageSurfaceClass}
      >
        {#if embed.isHashtree && !resolvedUrl}
          <div class={imagePlaceholderClass}>
            {#if loading}
              Loading image…
            {:else if error}
              {error}
            {:else}
              Loading image…
            {/if}
          </div>
        {:else}
          <ProxyImg
            alt={embed.label ?? embed.filename ?? ''}
            src={embed.isHashtree ? resolvedUrl : embed.url}
            loading={preload ? 'eager' : 'lazy'}
            sha256={embed.sha256}
            fallbackUrls={embed.fallbackUrls}
            className={imageClassName}
          />
        {/if}
      </div>
    {:else}
      <a
        data-testid="note-embed"
        href={embed.isHashtree ? resolvedUrl || undefined : embed.url}
        target={embed.isHashtree ? undefined : '_blank'}
        rel={embed.isHashtree ? undefined : 'noreferrer noopener'}
        class={imageSurfaceClass}
      >
        {#if embed.isHashtree && !resolvedUrl}
          <div class={imagePlaceholderClass}>
            {#if loading}
              Loading image…
            {:else if error}
              {error}
            {:else}
              Loading image…
            {/if}
          </div>
        {:else}
          <ProxyImg
            alt={embed.label ?? embed.filename ?? ''}
            src={embed.isHashtree ? resolvedUrl : embed.url}
            loading={preload ? 'eager' : 'lazy'}
            sha256={embed.sha256}
            fallbackUrls={embed.fallbackUrls}
            width={variant === 'grid' ? 256 : undefined}
            height={variant === 'grid' ? 256 : undefined}
            square={variant === 'grid'}
            className={imageClassName}
          />
        {/if}
      </a>
    {/if}
  {/if}
{:else if embed.kind === 'video'}
  {#if embed.isHashtree && !resolvedUrl}
    <button
      data-testid="note-embed"
      type="button"
      class={mediaCardClass}
      on:click={() => (onOpenMedia ? onOpenMedia() : void ensureLoaded())}
    >
      {#if variant === 'grid'}<IrisIcon name="play-square-outline" size={29} className="text-white/85" />{/if}
      <div class={variant === 'grid' ? 'sr-only' : 'text-[0.82rem] uppercase tracking-[0.16em] text-white/40'}>Video</div>
      <div class={variant === 'grid' ? 'sr-only' : 'mt-2 break-words text-[0.96rem] text-white'}>{embed.filename ?? 'Load attachment'}</div>
      {#if loading}
        <div class="mt-2 text-[0.88rem] text-white/45">Loading…</div>
      {:else if error}
        <div class="mt-2 text-[0.88rem] text-[#ffb4b4]">{error}</div>
      {/if}
    </button>
  {:else if shouldOpenPreview()}
    <button
      data-testid="note-embed"
      type="button"
      aria-label="Open video"
      class={`relative aspect-square w-full overflow-hidden border-0 bg-[#111111] p-0 text-left transition hover:opacity-80 ${ringClass}`.trim()}
      on:click={triggerOpenMedia}
    >
      {#if videoThumbnailUrl && !videoThumbnailFailed}
        <img
          data-testid="video-thumbnail"
          src={videoThumbnailUrl}
          alt={embed.label ?? 'Video thumbnail'}
          loading="lazy"
          decoding="async"
          class="h-full w-full object-cover"
          on:error={() => { videoThumbnailFailed = true; }}
        />
      {/if}
      <span
        data-testid="video-thumbnail-play"
        class="absolute left-1/2 top-1/2 grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-black/60 text-white shadow-lg"
        aria-hidden="true"
      ><IrisIcon name="play-square-outline" size={23} /></span>
      <span class="sr-only">{embed.filename ?? 'Open video'}</span>
    </button>
  {:else}
    <video
      bind:this={playbackElement}
      data-testid="note-embed"
      controls
      autoplay={autoplay && $settingsStore.content.autoplayVideos && viewActive}
      use:videoAutoplay={{ enabled: $settingsStore.content.autoplayVideos && (autoplay || variant === 'inline'), active: viewActive, muted: variant !== 'modal' }}
      preload={viewActive ? 'metadata' : 'none'}
      playsinline
      poster={videoThumbnailUrl || undefined}
      class={videoClassName}
    >
      <source src={embed.isHashtree ? resolvedUrl : embed.url} />
    </video>
  {/if}
{:else if embed.kind === 'audio'}
  {#if embed.isHashtree && !resolvedUrl}
    <button
      data-testid="note-embed"
      type="button"
      class={audioCardClass}
      on:click={() => (onOpenMedia ? onOpenMedia() : void ensureLoaded())}
    >
      {#if variant === 'grid'}<IrisIcon name="signal-01" size={29} className="text-white/85" />{/if}
      <div class={variant === 'grid' ? 'sr-only' : 'text-[0.82rem] uppercase tracking-[0.16em] text-white/40'}>Audio</div>
      <div class={variant === 'grid' ? 'sr-only' : 'mt-2 break-words text-[0.96rem] text-white'}>{embed.filename ?? 'Load attachment'}</div>
      {#if loading}
        <div class="mt-2 text-[0.88rem] text-white/45">Loading…</div>
      {:else if error}
        <div class="mt-2 text-[0.88rem] text-[#ffb4b4]">{error}</div>
      {/if}
    </button>
  {:else if shouldOpenPreview()}
    <button
      data-testid="note-embed"
      type="button"
      class={audioCardClass}
      on:click={triggerOpenMedia}
    >
      {#if variant === 'grid'}<IrisIcon name="signal-01" size={29} className="text-white/85" />{/if}
      <div class={variant === 'grid' ? 'sr-only' : 'text-[0.82rem] uppercase tracking-[0.16em] text-white/40'}>Audio</div>
      <div class={variant === 'grid' ? 'sr-only' : 'mt-2 break-words text-[0.96rem] text-white'}>{embed.filename ?? 'Open audio'}</div>
    </button>
  {:else}
    <audio
      bind:this={playbackElement}
      data-testid="note-embed"
      controls
      preload={viewActive ? 'metadata' : 'none'}
      class={`w-full rounded-[20px] ${ringClass}`.trim()}
    >
      <source src={embed.isHashtree ? resolvedUrl : embed.url} />
    </audio>
  {/if}
{:else if embed.kind === 'youtube'}
  {#if shouldOpenPreview()}
    <button
      data-testid="note-embed"
      type="button"
      class={`text-left ${youtubeSurfaceClass}`.trim()}
      on:click={triggerOpenMedia}
    >
      <div class="grid h-full w-full place-items-center bg-[#111111] px-4 text-center">
        <div>
          <IrisIcon name="play-square-outline" size={29} className="text-white/85" />
          <div class="sr-only">YouTube: {embed.label}</div>
        </div>
      </div>
    </button>
  {:else}
    <div
      data-testid="note-embed"
      class={youtubeSurfaceClass}
    >
      <div class="h-full w-full">
        <iframe
          src={viewActive ? embed.embedUrl : undefined}
          title={embed.label}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
          class="h-full w-full border-0"
        ></iframe>
      </div>
    </div>
  {/if}
{:else if embed.kind === 'file'}
  <button
    data-testid="note-embed"
    type="button"
    class={`${
      variant === 'grid'
        ? 'flex aspect-square w-full flex-col items-center justify-center bg-[#111111] px-2 py-2 text-center hover:bg-[#171717]'
        : 'block w-full rounded-[24px] border border-white/5 bg-[#0f0f0f] px-4 py-4 text-left hover:bg-[#161616]'
    } transition ${active ? 'ring-2 ring-white/25' : ''}`}
    on:click={() => void handleFileOpen()}
  >
    {#if variant === 'grid'}<IrisIcon name="file-06" size={29} className="text-white/85" />{/if}
    <div class={variant === 'grid' ? 'sr-only' : 'text-[0.82rem] uppercase tracking-[0.16em] text-white/40'}>Attachment</div>
    <div class={variant === 'grid' ? 'sr-only' : 'mt-2 break-words text-[0.96rem] text-white'}>{embed.filename}</div>
    {#if loading}
      <div class="mt-2 text-[0.88rem] text-white/45">Preparing download…</div>
    {:else if error}
      <div class="mt-2 text-[0.88rem] text-[#ffb4b4]">{error}</div>
    {/if}
  </button>
{/if}
