<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';
  import Username from './Username.svelte';
  import { getThreadParentReference, type ProfileRecord, type RawEvent } from '../nostr';
  import { sharedProfilesStore } from '../profileCache';
  import type { ReferencedNotePreview } from '../referencedNote';
  import { getReplyParentAuthor } from '../replyContext';
  import { profileHref, threadHref } from '../routes';

  export let event: RawEvent;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let onOpenNote: ((target: string) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let isActive = true;

  let resolvedRef = '';
  let resolvedPubkey: string | null = null;
  let resolvedProfile: ProfileRecord | null = null;
  let requestedRef = '';

  $: parentRef = getThreadParentReference(event);
  $: hint = getReplyParentAuthor(event);
  $: if (parentRef !== resolvedRef) {
    resolvedPubkey = null;
    resolvedProfile = null;
  }
  // Tags that only list `p` participants may not name the parent first, so
  // confirm the author from the parent itself when it can be resolved.
  $: if (parentRef && !hint.certain && isActive && resolveReferencedNote && requestedRef !== parentRef) {
    void resolveParentAuthor(parentRef, resolveReferencedNote);
  }
  $: parentPubkey = (parentRef === resolvedRef ? resolvedPubkey : null) ?? hint.pubkey;
  $: parentProfile = parentPubkey
    ? $sharedProfilesStore.get(parentPubkey)
      ?? profiles.get(parentPubkey)
      ?? (resolvedProfile?.pubkey === parentPubkey ? resolvedProfile : null)
    : null;

  async function resolveParentAuthor(
    ref: string,
    resolve: (ref: string) => Promise<ReferencedNotePreview | null>,
  ): Promise<void> {
    requestedRef = ref;
    try {
      const preview = await resolve(ref);
      if (preview && ref === getThreadParentReference(event)) {
        resolvedRef = ref;
        resolvedPubkey = preview.event.pubkey;
        resolvedProfile = preview.profile;
      }
    } catch {
      // Keep the tag-based author when the parent cannot be loaded.
    }
  }

  function isPlainClick(mouseEvent: MouseEvent): boolean {
    return mouseEvent.button === 0
      && !mouseEvent.metaKey
      && !mouseEvent.ctrlKey
      && !mouseEvent.shiftKey
      && !mouseEvent.altKey;
  }

  function openParent(mouseEvent: MouseEvent): void {
    if (parentRef && onOpenNote && isPlainClick(mouseEvent)) {
      mouseEvent.preventDefault();
      onOpenNote(parentRef);
    }
  }

  function openAuthor(mouseEvent: MouseEvent): void {
    if (parentPubkey && onOpenProfile && isPlainClick(mouseEvent)) {
      mouseEvent.preventDefault();
      onOpenProfile(parentPubkey);
    }
  }
</script>

{#if parentRef}
  <div
    data-testid="note-reply-context"
    data-parent-ref={parentRef}
    data-parent-author={parentPubkey ?? ''}
    class="flex h-5 min-w-0 items-center gap-1 text-[0.8rem] leading-5 text-white/45"
  >
    <a
      href={threadHref(parentRef)}
      class="flex shrink-0 items-center gap-1 transition hover:text-white/70"
      on:click={openParent}
    >
      <IrisIcon name="reverse-left" size={13} />
      <span>{parentPubkey ? 'Replying to' : 'Replying to a post'}</span>
    </a>
    {#if parentPubkey}
      <a
        data-testid="note-reply-context-author"
        href={profileHref(parentPubkey)}
        class="min-w-0 truncate font-600 text-white/55 transition hover:text-white/80"
        on:click={openAuthor}
      >
        <Username
          pubkey={parentPubkey}
          profile={parentProfile}
          inline={true}
          showSubtitle={false}
          titlePrefix="@"
          titleClass="inline"
        />
      </a>
    {/if}
  </div>
{/if}
