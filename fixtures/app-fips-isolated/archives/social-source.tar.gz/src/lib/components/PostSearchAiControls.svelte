<script lang="ts">
  export let query = '';
  export let aiSelected = true;
  export let aiBusy = false;
  export let aiStatus = '';
  export let showPublicPostSearch = false;
  export let postSearchAlreadySubmitted = false;
  export let showLoading = false;
  export let showSettling = false;
  export let hasPendingUpdate = false;
  export let onToggleAi: () => void = () => undefined;
  export let onSubmitPublic: () => void = () => undefined;
  export let onApplyUpdate: () => void = () => undefined;
</script>

<div class="flex min-w-0 items-center justify-end gap-2">
  {#if hasPendingUpdate}
    <button
      type="button"
      data-testid="post-search-update-results"
      class="shrink-0 rounded-full bg-violet-600 px-3 py-1 text-[0.78rem] font-700 text-white transition hover:bg-violet-500"
      on:click={onApplyUpdate}
    >
      Update results
    </button>
  {:else if showPublicPostSearch}
    <button
      type="button"
      class="shrink-0 rounded-full bg-[var(--iris-surface)] px-3 py-1.5 text-[0.8rem] font-700 hover:bg-[var(--iris-surface-hover)]"
      on:click={onSubmitPublic}
    >
      {postSearchAlreadySubmitted ? 'Retry public relay search' : 'Search public relay'}
    </button>
  {:else if aiStatus}
    <div
      data-testid="post-search-ai-status"
      class="truncate text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.5)]"
      title={aiStatus}
    >
      {aiStatus}
    </div>
  {:else if showLoading}
    <div data-testid="post-search-loading" class="truncate text-[0.8rem] text-white/45">Searching posts…</div>
  {:else if showSettling}
    <div data-testid="post-search-settling" class="truncate text-[0.8rem] text-white/45">Searching for more posts…</div>
  {/if}

  {#if query.length >= 2}
    <button
      type="button"
      data-testid="post-search-ai-toggle"
      aria-busy={aiBusy}
      class="inline-grid shrink-0 rounded-full px-2.5 py-1 text-left text-[0.78rem] font-600 text-violet-500 transition hover:bg-[var(--iris-surface)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
      on:click={onToggleAi}
    >
      <span class={`col-start-1 row-start-1 ${aiSelected ? '' : 'invisible'}`}>Show all</span>
      <span class={`col-start-1 row-start-1 ${aiSelected ? 'invisible' : ''}`}>Show AI selected</span>
    </button>
  {/if}
</div>
