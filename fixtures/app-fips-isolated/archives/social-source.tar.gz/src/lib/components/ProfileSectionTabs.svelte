<script lang="ts">
  import { profileSectionHref, type ProfileSection } from '../routes';

  export let pubkey: string;
  export let activeSection: ProfileSection;
  export let postCountLabel = '...';
  export let replyCountLabel = '...';
  export let mediaCountLabel = '...';
  export let likesCountLabel = '...';

  $: tabs = [
    { section: 'posts', label: 'Posts', count: postCountLabel === '...' ? '' : postCountLabel },
    { section: 'replies', label: 'Replies', count: replyCountLabel === '...' ? '' : replyCountLabel },
    { section: 'media', label: 'Media', count: mediaCountLabel === '...' ? '' : mediaCountLabel },
    { section: 'likes', label: 'Likes', count: likesCountLabel === '...' ? '' : likesCountLabel },
  ] satisfies Array<{ section: ProfileSection; label: string; count: string }>;
</script>

<nav class="grid grid-cols-4 border-b border-white/5 bg-black/20" aria-label="Profile sections">
  {#each tabs as tab (tab.section)}
    <a
      data-testid={`profile-tab-${tab.section}`}
      href={profileSectionHref(pubkey, tab.section)}
      class={`min-w-0 border-b-2 px-1.5 py-2.5 text-center transition sm:px-3 sm:py-3 ${
        activeSection === tab.section
          ? 'border-white/80 bg-black/30 text-white'
          : 'border-transparent text-white/60 hover:bg-[#0a0a0a] hover:text-white'
      }`}
    >
      <div class="truncate text-[0.58rem] uppercase tracking-[0.02em] text-white/45 sm:text-[0.72rem] sm:tracking-[0.12em]">
        {tab.label}
      </div>
      <div class="mt-1.5 min-h-[1.5em] text-[0.94rem] font-700 tabular-nums sm:text-[1.02rem]">{tab.count}</div>
    </a>
  {/each}
</nav>
