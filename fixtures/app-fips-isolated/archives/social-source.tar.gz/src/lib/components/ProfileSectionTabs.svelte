<script lang="ts">
  import { profileSectionHref, type ProfileSection } from '../routes';

  export let pubkey: string;
  export let activeSection: ProfileSection;
  export let postCountLabel = '...';
  export let repostCountLabel = '...';
  export let replyCountLabel = '...';
  export let mediaCountLabel = '...';
  export let likesCountLabel = '...';

  $: tabs = [
    { section: 'posts', label: 'Posts', count: postCountLabel === '...' ? '' : postCountLabel },
    { section: 'replies', label: 'Replies', count: replyCountLabel === '...' ? '' : replyCountLabel },
    { section: 'reposts', label: 'Reposts', count: repostCountLabel === '...' ? '' : repostCountLabel },
    { section: 'media', label: 'Media', count: mediaCountLabel === '...' ? '' : mediaCountLabel },
    { section: 'likes', label: 'Likes', count: likesCountLabel === '...' ? '' : likesCountLabel },
  ] satisfies Array<{ section: ProfileSection; label: string; count: string }>;
</script>

<nav class="flex min-w-0 items-center gap-1 overflow-x-auto sm:gap-2" aria-label="Profile sections">
  {#each tabs as tab (tab.section)}
    <a
      data-testid={`profile-tab-${tab.section}`}
      href={profileSectionHref(pubkey, tab.section)}
      aria-current={activeSection === tab.section ? 'page' : undefined}
      aria-label={tab.label}
      title={tab.count ? `${tab.label} (${tab.count})` : tab.label}
      class={`inline-flex h-9 shrink-0 items-center rounded-full px-2 text-sm font-600 sm:px-3 ${activeSection === tab.section
        ? 'iris-preserve-white-text bg-violet-700 text-white'
        : 'iris-neutral-button text-[rgb(var(--iris-text-rgb))]'}`}
    >
      {tab.label}<span aria-hidden="true" class="sr-only sm:not-sr-only sm:ml-1 sm:w-[3ch] sm:text-right sm:text-xs sm:tabular-nums">{tab.count}</span>
    </a>
  {/each}
</nav>
