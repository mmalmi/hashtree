<script lang="ts">
  import ProfileContactMemory from './ProfileContactMemory.svelte';
  import Avatar from './Avatar.svelte';
  import ProxyImg from './ProxyImg.svelte';
  import Username from './Username.svelte';
  import ProfileAbout from './ProfileAbout.svelte';
  import ProfileIdentity from './ProfileIdentity.svelte';
  import ProfileHeroActions from './ProfileHeroActions.svelte';
  import ProfileSocialSummary from './ProfileSocialSummary.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { type ProfileRecord } from '../nostr';
  import { sharedProfilesStore } from '../profileCache';
  import { preferNewerProfileRecord } from '../profileRecords';
  import type { FollowedByPresentation } from '../profileSocialPresentation';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let showBack = false;
  export let onBack: () => void = () => undefined;
  export let following = false;
  export let followPending = false;
  export let muted = false;
  export let mutePending = false;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onToggleMute: ((pubkey: string, nextMuted: boolean) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let onViewAsProfile: ((pubkey: string) => void) | null = null;
  export let onCopyPubkey: ((pubkey: string) => void) | null = null;
  export let onCopyNpub: ((npub: string) => void) | null = null;
  export let onCopyProfileLink: ((href: string) => void) | null = null;
  export let onOpenWebsite: ((url: string) => void) | null = null;
  export let onOpenImage: ((url: string, label: string) => void) | null = null;
  export let onEditProfile: (() => void) | null = null;
  export let qrValue = '';
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let followsCountLabel = '...';
  export let followerCountLabel = '...';
  export let followedBy: FollowedByPresentation = {
    pubkeys: [],
    total: 0,
    followedByViewer: false,
  };
  export let socialContextKnown = false;
  export let isOwnProfile = false;
  export let onOpenFollows: () => void = () => undefined;
  export let onOpenFollowers: () => void = () => undefined;
  export let isActive = true;

  $: cachedProfile = $sharedProfilesStore.get(pubkey) ?? null;
  $: resolvedProfile = preferNewerProfileRecord(profile, cachedProfile);
  $: bannerUrl = resolvedProfile?.banner?.trim() || '';
  $: avatarUrl = resolvedProfile?.picture?.trim() || '';
</script>

<section
  data-testid="profile-hero"
  class="border-b border-white/5 bg-black"
>
  <div class="iris-profile-banner relative h-36 overflow-hidden md:h-56">
    {#if bannerUrl}
      {#if onOpenImage}
        <button
          data-testid="profile-banner-button"
          type="button"
          class="block h-full w-full cursor-zoom-in border-0 bg-transparent p-0 text-left"
          aria-label="Open banner image"
          on:click={() => onOpenImage?.(bannerUrl, 'Banner image')}
        >
          <ProxyImg
            alt=""
            src={bannerUrl}
            loading="eager"
            className="h-36 w-full select-none object-cover md:h-56"
          />
        </button>
      {:else}
        <ProxyImg
          alt=""
          src={bannerUrl}
          loading="eager"
          className="h-36 w-full select-none object-cover md:h-56"
        />
      {/if}
    {/if}

    {#if showBack}
      <button
        type="button"
        class="iris-preserve-white-text absolute left-4 top-4 inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/5 bg-black/55 text-[1.1rem] text-white shadow-[0_10px_28px_rgba(0,0,0,0.26)] backdrop-blur-sm"
        aria-label="Back"
        on:click={onBack}
      >
        <IrisIcon name="arrowBack" size={18} />
      </button>
    {/if}
  </div>

  <div class="relative -mt-16 flex flex-col gap-4 px-4 pb-4">
    <div class="mt-4 flex items-end justify-between gap-4">
      <div
        data-testid="profile-hero-avatar"
        class="shrink-0 rounded-full"
        style="background-color:var(--iris-canvas);"
      >
        {#if avatarUrl && onOpenImage}
          <button
            data-testid="profile-avatar-button"
            type="button"
            class="shrink-0 cursor-zoom-in rounded-full border-0 bg-transparent p-0 text-left"
            aria-label="Open profile image"
            on:click={() => onOpenImage?.(avatarUrl, 'Profile image')}
          >
            <Avatar
              {pubkey}
              profile={resolvedProfile}
              size={92}
              showBadge={false}
              className="iris-profile-avatar"
              backgroundColor="var(--iris-canvas)"
            />
          </button>
        {:else}
          <Avatar
            {pubkey}
            profile={resolvedProfile}
            size={92}
              showBadge={false}
            className="iris-profile-avatar"
            backgroundColor="var(--iris-canvas)"
          />
        {/if}
      </div>

      <div class="min-w-0 pb-0.5">
        <ProfileHeroActions
          {pubkey}
          profile={resolvedProfile}
          {following}
          {followPending}
          {muted}
          {mutePending}
          {qrValue}
          {onToggleFollow}
          {onToggleMute}
          {onOpenProfile}
          {onOpenThread}
          {onViewAsProfile}
          {onCopyPubkey}
          {onCopyNpub}
          {onCopyProfileLink}
          {onOpenWebsite}
          {onEditProfile}
          {isActive}
        />
      </div>
    </div>

    <div class="min-w-0">
      <div class={resolvedProfile?.eventId ? '' : 'min-h-[3.5rem]'}>
        <Username
          {pubkey}
          profile={resolvedProfile}
          titleClass="truncate text-2xl font-700 leading-tight tracking-[-0.01em] text-white"
          subtitleClass="mt-1 truncate text-[0.95rem] text-white/60"
        />
      </div>
      <ProfileIdentity profile={resolvedProfile} reserveSpace={!resolvedProfile?.eventId} />
    </div>

    <ProfileContactMemory {pubkey} profile={resolvedProfile} {following} {isActive} />

    <ProfileAbout
      text={resolvedProfile?.about ?? ''}
      stableCollapsedHeight={resolvedProfile?.eventId ? null : 80}
      {profiles}
      {onOpenProfile}
      {onOpenThread}
    />

    <ProfileSocialSummary
      {pubkey}
      {profiles}
      {followsCountLabel}
      {followerCountLabel}
      {followedBy}
      {socialContextKnown}
      {isOwnProfile}
      {onOpenFollows}
      {onOpenFollowers}
    />
  </div>
</section>
