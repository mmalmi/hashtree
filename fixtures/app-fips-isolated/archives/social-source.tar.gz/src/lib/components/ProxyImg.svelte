<script lang="ts">
  import { onDestroy } from 'svelte';
  import {
    generateImageProxyUrl,
    isExternalHttpUrl,
    loadHashAddressedMediaObjectUrl,
    loadHashtreeObjectUrl,
  } from '../media';
  import { scheduleMediaResolution } from '../mediaLoadScheduler';
  import IrisIcon from './IrisIcon.svelte';

  export let src = '';
  export let alt = '';
  export let width: number | undefined = undefined;
  export let height: number | undefined = undefined;
  export let loading: 'eager' | 'lazy' = 'lazy';
  export let square = false;
  export let className = '';
  export let style = '';
  export let sha256: string | undefined = undefined;
  export let fallbackUrls: string[] = [];
  export let showUnavailable = true;

  let displaySrc = '';
  let objectUrl = '';
  let loadVersion = 0;
  let meshFallbackAttempted = false;
  let meshFallbackPending = false;
  let directFallbackAttempted = false;
  let unavailable = false;

  function cleanupObjectUrl(): void {
    if (objectUrl) {
      URL.revokeObjectURL(objectUrl);
      objectUrl = '';
    }
  }

  async function loadDisplaySrc(
    nextSrc: string,
    _nextSha256: string | undefined,
    _nextFallbackUrlsKey: string,
    _nextWidth: number | undefined,
    _nextHeight: number | undefined,
    _nextSquare: boolean,
  ): Promise<void> {
    const version = ++loadVersion;
    const trimmed = nextSrc.trim();
    meshFallbackAttempted = false;
    meshFallbackPending = false;
    directFallbackAttempted = false;
    unavailable = false;
    cleanupObjectUrl();

    if (!trimmed) {
      displaySrc = '';
      return;
    }

    try {
      if (trimmed.startsWith('htree://') || /^nhash1[a-z0-9]+\//i.test(trimmed)) {
        const resolved = await scheduleMediaResolution(async () => {
          if (version !== loadVersion) {
            throw new Error('Media load cancelled');
          }
          return await loadHashtreeObjectUrl(trimmed);
        }, {
          onLateResult: (lateResult) => URL.revokeObjectURL(lateResult.url),
        });
        if (version !== loadVersion) {
          URL.revokeObjectURL(resolved.url);
          return;
        }

        objectUrl = resolved.url;
        displaySrc = resolved.url;
        return;
      }

      if (isExternalHttpUrl(trimmed)) {
        const proxied = await generateImageProxyUrl(trimmed, {
          width,
          height,
          square,
        });
        if (version !== loadVersion) {
          return;
        }
        displaySrc = proxied;
        return;
      }

      if (version !== loadVersion) {
        return;
      }
      displaySrc = trimmed;
    } catch {
      if (version === loadVersion) {
        if (isExternalHttpUrl(trimmed)) {
          directFallbackAttempted = true;
          displaySrc = trimmed;
        } else {
          displaySrc = '';
          unavailable = true;
        }
      }
    }
  }

  function showDirectFallback(trimmed: string, version: number): void {
    if (version !== loadVersion || directFallbackAttempted || displaySrc === trimmed) {
      return;
    }
    directFallbackAttempted = true;
    unavailable = false;
    cleanupObjectUrl();
    displaySrc = trimmed;
  }

  async function handleError(): Promise<void> {
    const trimmed = src.trim();
    if (!isExternalHttpUrl(trimmed)) {
      return;
    }

    const version = loadVersion;
    if (meshFallbackPending) {
      return;
    }

    if (!directFallbackAttempted) {
      showDirectFallback(trimmed, version);
      return;
    }

    if (!meshFallbackAttempted) {
      meshFallbackAttempted = true;
      meshFallbackPending = true;
      cleanupObjectUrl();
      displaySrc = '';
      unavailable = true;
      try {
        const resolved = await scheduleMediaResolution(async () => {
          if (version !== loadVersion) {
            throw new Error('Media load cancelled');
          }
          return await loadHashAddressedMediaObjectUrl(trimmed, {
            expectedHashHex: sha256,
            fallbackUrls,
          });
        }, {
          onLateResult: (lateResult) => URL.revokeObjectURL(lateResult.url),
        });
        if (version !== loadVersion) {
          URL.revokeObjectURL(resolved.url);
          return;
        }

        cleanupObjectUrl();
        objectUrl = resolved.url;
        displaySrc = resolved.url;
        unavailable = false;
        return;
      } catch {
        if (version === loadVersion) {
          unavailable = true;
        }
        return;
      } finally {
        if (version === loadVersion) {
          meshFallbackPending = false;
        }
      }
    }

    cleanupObjectUrl();
    displaySrc = '';
    unavailable = true;
  }

  $: fallbackUrlsKey = fallbackUrls.join('\n');
  $: void loadDisplaySrc(src, sha256, fallbackUrlsKey, width, height, square);

  onDestroy(() => {
    loadVersion += 1;
    cleanupObjectUrl();
  });
</script>

{#if displaySrc}
  {#key displaySrc}
    <img
      {alt}
      src={displaySrc}
      {width}
      {height}
      {loading}
      class={className}
      {style}
      on:error={handleError}
    />
  {/key}
{:else if unavailable && showUnavailable}
  <span
    role="img"
    aria-label={alt || 'Image unavailable'}
    class={`${className} grid place-items-center bg-white/4 text-white/35`.trim()}
    {style}
  >
    <IrisIcon name="image-plus" size={23} />
  </span>
{/if}
