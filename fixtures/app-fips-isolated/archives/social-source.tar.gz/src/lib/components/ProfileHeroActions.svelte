<script lang="ts">
  import { contactMemoryStore, publicContactName } from '../contactMemoryStore';
  import IrisIcon from './IrisIcon.svelte';
  import { pubkeyToNpub, type ProfileRecord } from '../nostr';
  import { createRetryableDynamicImport } from '../retryableDynamicImport';
  import { profileHref } from '../routes';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let following = false;
  export let followPending = false;
  export let muted = false;
  export let mutePending = false;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onToggleMute: ((pubkey: string, nextMuted: boolean) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let onViewAsProfile: ((pubkey: string) => void) | null = null;
  export let onCopyPubkey: ((pubkey: string) => void) | null = null;
  export let onCopyNpub: ((npub: string) => void) | null = null;
  export let onCopyProfileLink: ((href: string) => void) | null = null;
  export let onOpenWebsite: ((url: string) => void) | null = null;
  export let onEditProfile: (() => void) | null = null;
  export let qrValue = '';
  export let isActive = true;

  let menuOpen = false;
  let favoritePending = false;
  let favoriteError = '';
  let qrOpen = false;
  let qrLoadError = '';
  let qrModalModulePromise: Promise<typeof import('./ProfileQrModal.svelte')> | null = null;
  let menuButton: HTMLButtonElement | null = null;
  let menuPanel: HTMLDivElement | null = null;
  const importQrModal = createRetryableDynamicImport(() => import('./ProfileQrModal.svelte'));

  $: profileNpub = profile?.npub || pubkeyToNpub(pubkey);
  $: profileUrl = profileHref(pubkey);
  $: profileWebsite = profile?.website?.trim() || '';
  $: resolvedQrValue = qrValue.trim() || profileNpub;
  $: hasMenuActions = Boolean(
    onViewAsProfile ||
      onToggleMute ||
      onCopyPubkey ||
      onCopyNpub ||
      onCopyProfileLink ||
      onOpenWebsite ||
      profileWebsite
  );
  $: favorite = $contactMemoryStore.contacts.get(pubkey)?.favorite ?? false;
  $: canFavorite = Boolean($contactMemoryStore.viewer && $contactMemoryStore.viewer !== pubkey);
  $: canToggleFollow = typeof onToggleFollow === 'function';
  $: if (!isActive) {
    menuOpen = false;
    qrOpen = false;
    qrLoadError = '';
  }

  function closeMenu(): void {
    menuOpen = false;
  }

  function toggleMenu(): void {
    menuOpen = !menuOpen;
    if (!menuOpen) {
      qrOpen = false;
    }
  }

  function handleWindowClick(event: MouseEvent): void {
    if (!menuOpen) {
      return;
    }

    const target = event.target;
    if (!(target instanceof Node)) {
      return;
    }

    if (menuButton?.contains(target) || menuPanel?.contains(target)) {
      return;
    }

    closeMenu();
  }

  function handleWindowKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape') {
      return;
    }

    closeMenu();
    qrOpen = false;
  }

  function loadQrModal(): Promise<typeof import('./ProfileQrModal.svelte')> {
    if (qrModalModulePromise) {
      return qrModalModulePromise;
    }

    const request = importQrModal();
    qrModalModulePromise = request;
    void request.catch(() => {
      if (qrModalModulePromise === request) {
        qrModalModulePromise = null;
      }
    });
    return request;
  }

  function warmQrModal(): void {
    void loadQrModal().catch(() => undefined);
  }

  async function openQr(): Promise<void> {
    if (!isActive) {
      return;
    }
    qrLoadError = '';
    closeMenu();
    try {
      await loadQrModal();
      qrOpen = isActive;
    } catch {
      if (isActive) {
        qrLoadError = 'Could not load the QR view.';
      }
    }
  }

  function triggerFollow(): void {
    onToggleFollow?.(pubkey, !following);
  }

  async function toggleFavorite(): Promise<void> {
    favoritePending = true;
    favoriteError = '';
    try { await contactMemoryStore.favorite(pubkey, publicContactName(profile), !favorite); }
    catch { favoriteError = 'Could not save your favorite. Please try again.'; }
    finally { favoritePending = false; }
  }

  function invoke(action: () => void): void {
    action();
    closeMenu();
  }
</script>

<svelte:window on:click={handleWindowClick} on:keydown={handleWindowKeydown} />

<div data-testid="profile-header-actions" class="relative flex flex-row items-center justify-end gap-2">
  {#if canFavorite}
    <button
      data-testid="profile-favorite"
      type="button"
      aria-label={favorite ? 'Remove favorite' : 'Favorite'}
      aria-pressed={favorite}
      disabled={favoritePending}
      title="Favorite · Only you can see this"
      class={`inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/5 bg-[#111111] transition hover:bg-[#1a1a1a] ${favorite ? 'text-amber-400' : 'text-white/65'}`}
      on:click={toggleFavorite}
    >
      <svg width="19" height="19" viewBox="0 0 24 24" fill={favorite ? 'currentColor' : 'none'} stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m12 3 2.78 5.63L21 9.54l-4.5 4.39L17.56 20 12 17.08 6.44 20l1.06-6.07L3 9.54l6.22-.91Z" /></svg>
    </button>
    {#if favoriteError}<span role="alert" class="max-w-48 text-xs text-red-400">{favoriteError}</span>{/if}
  {/if}

  {#if resolvedQrValue}
    <button
      data-testid="profile-actions-qr"
      type="button"
      class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white transition hover:bg-[#1a1a1a]"
      aria-label="Show profile QR"
      on:pointerenter={warmQrModal}
      on:pointerdown={warmQrModal}
      on:focus={warmQrModal}
      on:click={() => void openQr()}
    >
      <IrisIcon name="qr" size={18} />
    </button>
  {/if}

  {#if onEditProfile}
    <button
      data-testid="profile-actions-edit-profile"
      type="button"
      class="inline-flex h-10 items-center rounded-full border border-white/5 bg-[#111111] px-4 text-[0.86rem] font-700 text-white transition hover:bg-[#1a1a1a]"
      on:click={onEditProfile}
    >
      Edit profile
    </button>
  {/if}

  {#if canToggleFollow}
    <button
      type="button"
      class={`group inline-flex h-10 min-w-[6rem] items-center justify-center rounded-full px-4 text-[0.86rem] font-700 transition ${
        following
          ? 'border border-white/5 bg-[#111111] text-white hover:bg-[#2a0d0d]'
          : 'iris-preserve-white-text bg-[#3b82f6] text-white hover:bg-[#2563eb]'
      }`}
      aria-label={following ? 'Following' : 'Follow'}
      title={following ? 'Unfollow publicly' : 'Follow publicly'}
      disabled={followPending}
      on:click={triggerFollow}
    >
      {#if following}
        <span class="group-hover:hidden">Following</span>
        <span class="hidden group-hover:inline">Unfollow</span>
      {:else}
        Follow
      {/if}
    </button>
  {/if}

  {#if hasMenuActions}
    <div class="relative">
      <button
        bind:this={menuButton}
        type="button"
        class={`inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/5 text-white/72 transition hover:bg-[#1a1a1a] hover:text-white ${
          menuOpen ? 'bg-[#1a1a1a] text-white' : 'bg-[#111111]'
        }`}
        aria-label="Profile actions"
        aria-expanded={menuOpen}
        on:click={toggleMenu}
      >
        <IrisIcon name="dots" size={18} />
      </button>

      {#if menuOpen}
        <div
          bind:this={menuPanel}
          data-testid="profile-actions-menu"
          class="iris-dropdown-menu absolute right-0 top-12 z-20 w-[17rem] overflow-hidden rounded-[14px] border border-white/10 bg-[#111111] p-2 shadow-[0_24px_80px_rgba(0,0,0,0.42)]"
        >
          {#if onViewAsProfile}
            <button
              data-testid="profile-actions-view-as"
              type="button"
              class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
              on:click={() => invoke(() => onViewAsProfile(pubkey))}
            >
              <IrisIcon name="openeye" size={18} className="text-white/55" />
              View as
            </button>
          {/if}

          {#if onToggleMute}
            <button
              data-testid="profile-actions-toggle-mute"
              type="button"
              class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a] disabled:opacity-50"
              disabled={mutePending}
              on:click={() => invoke(() => onToggleMute?.(pubkey, !muted))}
            >
              <IrisIcon name={muted ? 'signal-01' : 'mute'} size={18} className="text-white/55" />
              {muted ? 'Unmute profile' : 'Mute profile'}
            </button>
          {/if}

          {#if onCopyPubkey}
            <button
              type="button"
              class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
              on:click={() => invoke(() => onCopyPubkey(pubkey))}
            >
              <IrisIcon name="copy-solid" size={18} className="text-white/55" />
              Copy hex
            </button>
          {/if}

          {#if onCopyNpub}
            <button
              type="button"
              class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
              on:click={() => invoke(() => onCopyNpub(profileNpub))}
            >
              <IrisIcon name="copy-solid" size={18} className="text-white/55" />
              Copy npub
            </button>
          {/if}

          {#if onCopyProfileLink}
            <button
              type="button"
              class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
              on:click={() => invoke(() => onCopyProfileLink(profileUrl))}
            >
              <IrisIcon name="share" size={18} className="text-white/55" />
              Copy link
            </button>
          {/if}

          {#if profileWebsite}
            {#if onOpenWebsite}
              <button
                type="button"
                class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
                on:click={() => invoke(() => onOpenWebsite(profileWebsite))}
              >
                <IrisIcon name="globe" size={18} className="text-white/55" />
                Open website
              </button>
            {:else}
              <a
                href={profileWebsite}
                target="_blank"
                rel="noreferrer noopener"
                class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
                on:click={closeMenu}
              >
                <IrisIcon name="globe" size={18} className="text-white/55" />
                Open website
              </a>
            {/if}
          {/if}
        </div>
      {/if}
    </div>
  {/if}

  {#if qrLoadError}
    <div
      data-testid="profile-qr-load-error"
      role="alert"
      class="absolute right-0 top-12 z-30 flex items-center gap-3 whitespace-nowrap rounded-xl border border-white/10 bg-[#111111] px-3 py-2 text-sm text-white shadow-xl"
    >
      <span>{qrLoadError}</span>
      <button
        type="button"
        class="font-700 text-blue-400 hover:text-blue-300"
        aria-label="Retry profile QR"
        on:click={() => void openQr()}
      >Retry</button>
    </div>
  {/if}

</div>

{#if qrOpen && qrModalModulePromise}
  {#await qrModalModulePromise then qrModalModule}
    <svelte:component
      this={qrModalModule.default}
      open={qrOpen && Boolean(resolvedQrValue)}
      {pubkey}
      {profile}
      {onOpenProfile}
      {onOpenThread}
      onClose={() => {
        qrOpen = false;
      }}
    />
  {/await}
{/if}
