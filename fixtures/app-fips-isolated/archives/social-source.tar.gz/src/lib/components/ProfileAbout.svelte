<script lang="ts">
  import { tick } from 'svelte';
  import { getRouteActivity } from '../routeActivity';
  import type { ProfileRecord } from '../nostr';
  import ProfileText from './ProfileText.svelte';

  export let text = '';
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let reserveSpace = false;

  const COLLAPSED_HEIGHT = 80;

  let textElement: HTMLDivElement | null = null;
  let expanded = false;
  let canExpand = false;
  let measuredText = '';
  const routeActivity = getRouteActivity();

  $: normalizedText = text.trim();
  $: if (normalizedText !== measuredText) {
    expanded = false;
    measuredText = normalizedText;
  }
  $: if ($routeActivity && normalizedText) {
    void measureOverflow();
  }

  async function measureOverflow(): Promise<void> {
    await tick();
    if (!textElement) {
      return;
    }

    const nextCanExpand = textElement.scrollHeight > COLLAPSED_HEIGHT + 4;
    canExpand = nextCanExpand;
    if (!nextCanExpand) {
      expanded = false;
    }
  }

  function observeResize(node: HTMLDivElement, initiallyActive: boolean) {
    let observer: ResizeObserver | null = null;
    const sync = (active: boolean) => {
      observer?.disconnect();
      observer = null;
      if (active && typeof ResizeObserver !== 'undefined') {
        observer = new ResizeObserver(() => void measureOverflow());
        observer.observe(node);
      }
    };
    sync(initiallyActive);
    return {
      update: sync,
      destroy: () => observer?.disconnect(),
    };
  }
</script>

{#if !normalizedText && reserveSpace}
  <div aria-hidden="true" class="h-14 sm:h-7"></div>
{:else if normalizedText}
  <div class="relative max-w-3xl">
    <div class="relative">
      <div
        data-testid="profile-about"
        bind:this={textElement}
        use:observeResize={$routeActivity}
        class={`whitespace-pre-wrap break-words [overflow-wrap:anywhere] text-[1rem] leading-7 text-white/82 ${
          !expanded ? 'overflow-hidden' : ''
        }`}
        style={!expanded
          ? `max-height:${COLLAPSED_HEIGHT}px;`
          : undefined}
      >
        <ProfileText
          text={normalizedText}
          {profiles}
          {onOpenProfile}
          {onOpenThread}
        />
      </div>

      {#if canExpand && !expanded}
        <div
          aria-hidden="true"
          class="iris-profile-about-fade pointer-events-none absolute inset-x-0 bottom-0 h-12"
        ></div>
      {/if}

      {#if canExpand}
        <button
          data-testid="profile-about-toggle"
          type="button"
          class="mt-2 inline-flex items-center text-[0.84rem] font-700 text-white/60 transition hover:text-white"
          aria-expanded={expanded}
          on:click={() => {
            expanded = !expanded;
          }}
        >
          {expanded ? 'Show less' : 'Show more'}
        </button>
      {/if}
    </div>
  </div>
{/if}
