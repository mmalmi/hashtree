<script lang="ts">
  import { tick } from 'svelte';
  import { getRouteActivity } from '../routeActivity';
  import type { ProfileRecord } from '../nostr';
  import ProfileText from './ProfileText.svelte';

  export let text = '';
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let stableCollapsedHeight: number | null = null;

  const COLLAPSED_HEIGHT = 80;

  let textElement: HTMLDivElement | null = null;
  let expanded = false;
  let canExpand = false;
  let measuredText = '';
  const routeActivity = getRouteActivity();

  $: normalizedText = text.trim();
  $: collapsedHeight = stableCollapsedHeight ?? COLLAPSED_HEIGHT;
  $: if (normalizedText !== measuredText) {
    expanded = false;
    measuredText = normalizedText;
  }
  $: if ($routeActivity && normalizedText) {
    void measureOverflow();
  }

  async function measureOverflow(): Promise<void> {
    await tick();
    if (!textElement) {
      return;
    }

    const nextCanExpand = textElement.scrollHeight > collapsedHeight + 4;
    canExpand = nextCanExpand;
    if (!nextCanExpand) {
      expanded = false;
    }
  }

  function observeResize(node: HTMLDivElement, initiallyActive: boolean) {
    let observer: ResizeObserver | null = null;
    const sync = (active: boolean) => {
      observer?.disconnect();
      observer = null;
      if (active && typeof ResizeObserver !== 'undefined') {
        observer = new ResizeObserver(() => void measureOverflow());
        observer.observe(node);
      }
    };
    sync(initiallyActive);
    return {
      update: sync,
      destroy: () => observer?.disconnect(),
    };
  }
</script>

{#if normalizedText || stableCollapsedHeight !== null}
  <div
    class="relative max-w-3xl"
    style={stableCollapsedHeight !== null && !expanded
      ? `height:${stableCollapsedHeight}px;`
      : undefined}
  >
    {#if normalizedText}
      <div class={stableCollapsedHeight !== null && !expanded ? 'relative h-full' : 'relative'}>
        <div
          data-testid="profile-about"
          bind:this={textElement}
          use:observeResize={$routeActivity}
          class={`whitespace-pre-wrap break-words [overflow-wrap:anywhere] text-[1rem] leading-7 text-white/82 ${
            !expanded ? 'overflow-hidden' : ''
          }`}
          style={!expanded
            ? `max-height:${collapsedHeight}px;`
            : undefined}
        >
          <ProfileText
            text={normalizedText}
            {profiles}
            {onOpenProfile}
            {onOpenThread}
          />
        </div>

        {#if canExpand && !expanded}
          <div
            aria-hidden="true"
            class="iris-profile-about-fade pointer-events-none absolute inset-x-0 bottom-0 h-12"
          ></div>
        {/if}

        {#if canExpand}
          <button
            data-testid="profile-about-toggle"
            type="button"
            class={stableCollapsedHeight !== null && !expanded
              ? 'absolute bottom-0 right-0 rounded bg-black/85 px-1.5 py-0.5 text-[0.84rem] font-700 text-white/60 backdrop-blur-sm transition hover:text-white'
              : 'mt-2 inline-flex items-center text-[0.84rem] font-700 text-white/60 transition hover:text-white'}
            aria-expanded={expanded}
            on:click={() => {
              expanded = !expanded;
            }}
          >
            {expanded ? 'Show less' : 'Show more'}
          </button>
        {/if}
      </div>
    {/if}
  </div>
{/if}
