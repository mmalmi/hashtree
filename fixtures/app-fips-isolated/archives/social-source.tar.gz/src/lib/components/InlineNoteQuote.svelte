<script lang="ts">
  import { onDestroy } from 'svelte';
  import LongformHeader from './LongformHeader.svelte';
  import NoteEmbeds from './NoteEmbeds.svelte';
  import NoteText from './NoteText.svelte';
  import UserRow from './UserRow.svelte';
  import type { ReferencedNotePreview } from '../referencedNote';
  import { getRouteActivity } from '../routeActivity';

  export let bech32: string;
  export let onOpenNote: ((target: string) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;

  let preview: ReferencedNotePreview | null = null;
  let loading = false;
  let requestId = 0;
  let retryRef = '';
  let retryAttempt = 0;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;
  let expanded = false;
  let expandedReference = '';
  let activityRef = '';
  let wasActive = false;

  const RETRY_DELAYS_MS = [750, 2_000, 5_000] as const;
  const routeActivity = getRouteActivity();

  $: syncActivity(bech32, $routeActivity);
  $: if (bech32 !== expandedReference) {
    expandedReference = bech32;
    expanded = false;
  }

  async function hydratePreview(ref: string): Promise<void> {
    if (retryRef !== ref) {
      retryRef = ref;
      retryAttempt = 0;
      clearRetryTimer();
    }
    const nextRequestId = ++requestId;
    preview = null;
    if (!resolveReferencedNote) {
      loading = false;
      return;
    }

    loading = true;
    try {
      const nextPreview = await resolveReferencedNote(ref);
      if (requestId !== nextRequestId) {
        return;
      }
      preview = nextPreview;
      if (!nextPreview) {
        scheduleRetry(ref, nextRequestId);
      }
    } finally {
      if (requestId === nextRequestId) {
        loading = false;
      }
    }
  }

  function syncActivity(ref: string, active: boolean): void {
    if (!active) {
      if (wasActive) {
        requestId += 1;
        loading = false;
        clearRetryTimer();
      }
      wasActive = false;
      return;
    }
    const shouldHydrate = !wasActive || activityRef !== ref;
    wasActive = true;
    activityRef = ref;
    if (ref && shouldHydrate && (!preview || retryRef !== ref)) {
      void hydratePreview(ref);
    }
  }

  function scheduleRetry(ref: string, nextRequestId: number): void {
    const delay = RETRY_DELAYS_MS[retryAttempt];
    if (delay === undefined || requestId !== nextRequestId || retryRef !== ref) {
      return;
    }
    retryAttempt += 1;
    retryTimer = setTimeout(() => {
      retryTimer = null;
      void hydratePreview(ref);
    }, delay);
  }

  function clearRetryTimer(): void {
    if (retryTimer !== null) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }
  }

  function shouldIgnoreActivation(target: EventTarget | null): boolean {
    return target instanceof Element && Boolean(target.closest('a, button, input, textarea, select'));
  }

  function handleOpen(event: MouseEvent | KeyboardEvent): void {
    if (
      !onOpenNote
      || shouldIgnoreActivation(event.target)
      || (event instanceof MouseEvent && (
        event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey
      ))
    ) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    onOpenNote(bech32);
  }

  function handleOpenProfile(pubkey: string): void {
    onOpenProfile?.(pubkey);
  }

  onDestroy(() => {
    requestId += 1;
    clearRetryTimer();
  });
</script>

<div
  data-note-no-thread-nav
  data-testid="note-inline-quote"
  data-route-active={$routeActivity ? 'true' : 'false'}
  data-retry-pending={retryTimer !== null ? 'true' : 'false'}
  data-retry-attempt={retryAttempt}
  data-presentation="iris-client-embed"
  role="link"
  tabindex="0"
  aria-label="Open quoted post"
  aria-disabled={!onOpenNote}
  class={`relative my-2 w-full rounded-lg border border-[var(--iris-border-subtle)] bg-[var(--iris-surface)] text-left transition-colors hover:bg-[var(--iris-surface-hover)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgb(var(--iris-text-rgb)/0.35)] ${
    expanded ? '' : 'h-[200px] overflow-hidden'
  } ${onOpenNote ? 'cursor-pointer' : ''}`.trim()}
  on:click={handleOpen}
  on:keydown={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      handleOpen(event);
    }
  }}
>
  <div class="px-4 pb-3 pt-3">
    {#if preview}
      <UserRow
        pubkey={preview.event.pubkey}
        profile={preview.profile}
        onOpenThread={onOpenNote}
        avatarSize={38}
        timestamp={preview.event.created_at}
        showSubtitle={false}
        gapClass="gap-2"
        titleClass="truncate text-base font-700 text-[rgb(var(--iris-text-rgb))]"
        subtitleClass="truncate text-sm text-[rgb(var(--iris-text-rgb)/0.55)]"
        timeClass="text-sm text-[rgb(var(--iris-text-rgb)/0.5)]"
        onOpenProfile={onOpenProfile}
      />

      <div class="mt-2 min-w-0">
        <LongformHeader event={preview.event} />
        <NoteText
          event={preview.event}
          profile={preview.profile}
          onOpenProfile={handleOpenProfile}
          {onOpenNote}
          {resolveReferencedNote}
          collapsible={false}
          isActive={$routeActivity}
        />
        <NoteEmbeds event={preview.event} limit={1} viewActive={$routeActivity} />
      </div>
    {:else if loading}
      <div class="text-base text-[rgb(var(--iris-text-rgb)/0.5)]">
        Loading quoted post…
      </div>
    {:else}
      <div class="text-base text-[rgb(var(--iris-text-rgb)/0.5)]">
        Quoted post unavailable
      </div>
    {/if}
  </div>

  {#if !expanded}
    <div
      aria-hidden="true"
      class="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[var(--iris-surface)] to-transparent"
    ></div>
    <button
      data-testid="note-inline-quote-expand"
      type="button"
      class="absolute bottom-2 left-1/2 -translate-x-1/2 text-sm text-violet-400 transition-colors hover:text-violet-300"
      on:click|stopPropagation={() => {
        expanded = true;
      }}
    >
      Show More
    </button>
  {/if}
</div>
