<script lang="ts">
  import { onDestroy } from 'svelte';
  import LongformHeader from './LongformHeader.svelte';
  import NoteEmbeds from './NoteEmbeds.svelte';
  import NoteText from './NoteText.svelte';
  import UserRow from './UserRow.svelte';
  import type { ReferencedNotePreview } from '../referencedNote';
  import { getRouteActivity } from '../routeActivity';
  import { getReferencedNoteWatcher } from '../referencedNoteContext';

  export let bech32: string;
  export let quoteTrail: readonly string[] = [];
  export let onOpenNote: ((target: string) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;

  let preview: ReferencedNotePreview | null = null;
  let expanded = false;
  let currentRef = '';
  let stopWatching: (() => void) | null = null;
  const routeActivity = getRouteActivity();
  const watchReferencedNote = getReferencedNoteWatcher();

  $: syncLookup(bech32, $routeActivity, resolveReferencedNote);

  function syncLookup(ref: string, active: boolean, resolve: typeof resolveReferencedNote): void {
    stopWatching?.();
    stopWatching = null;
    if (ref !== currentRef) {
      currentRef = ref;
      expanded = false;
      preview = null;
    }
    if (!active || !ref) { return; }
    if (watchReferencedNote) {
      stopWatching = watchReferencedNote(ref, value => { preview = value; });
    } else if (resolve) {
      let cancelled = false;
      stopWatching = () => { cancelled = true; };
      void resolve(ref).then(value => {
        if (!cancelled) { preview = value; }
      }).catch(error => console.warn('Quoted post lookup failed', error));
    }
  }

  function shouldIgnoreActivation(target: EventTarget | null): boolean {
    return target instanceof Element && Boolean(target.closest('a, button, input, textarea, select'));
  }

  function handleOpen(event: MouseEvent | KeyboardEvent): void {
    if (
      !onOpenNote
      || shouldIgnoreActivation(event.target)
      || (event instanceof MouseEvent && (
        event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey
      ))
    ) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    onOpenNote(bech32);
  }

  function handleOpenProfile(pubkey: string): void {
    onOpenProfile?.(pubkey);
  }

  onDestroy(() => stopWatching?.());
</script>

<div
  data-note-no-thread-nav
  data-testid="note-inline-quote"
  data-route-active={$routeActivity ? 'true' : 'false'}
  data-presentation="iris-client-embed"
  role="link"
  tabindex="0"
  aria-label="Open quoted post"
  aria-disabled={!onOpenNote}
  class={`iris-inline-quote relative my-2 w-full whitespace-normal rounded-xl border border-divider text-left transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgb(var(--iris-text-rgb)/0.35)] ${
    expanded && preview ? '' : 'h-[200px] overflow-hidden'
  } ${onOpenNote ? 'cursor-pointer' : ''}`.trim()}
  on:click={handleOpen}
  on:keydown={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      handleOpen(event);
    }
  }}
>
  <div class="px-4 pb-3 pt-3">
    {#if preview}
      <UserRow
        pubkey={preview.event.pubkey}
        profile={preview.profile}
        onOpenThread={onOpenNote}
        avatarSize={38}
        timestamp={preview.event.created_at}
        showSubtitle={false}
        gapClass="gap-2"
        titleClass="truncate text-base font-700 text-[rgb(var(--iris-text-rgb))]"
        subtitleClass="truncate text-sm text-[rgb(var(--iris-text-rgb)/0.55)]"
        timeClass="text-sm text-[rgb(var(--iris-text-rgb)/0.5)]"
        onOpenProfile={onOpenProfile}
      />

      <div class="mt-2 min-w-0">
        <LongformHeader event={preview.event} />
        <NoteText
          event={preview.event}
          quoteTrail={[...quoteTrail, bech32]}
          profile={preview.profile}
          onOpenProfile={handleOpenProfile}
          {onOpenNote}
          {resolveReferencedNote}
          collapsible={false}
          isActive={$routeActivity}
        />
        <NoteEmbeds event={preview.event} limit={1} viewActive={$routeActivity} />
      </div>
    {:else}
      <div class="flex h-[38px] items-center gap-2 text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">
        <span aria-hidden="true" class="h-[38px] w-[38px] shrink-0 rounded-full bg-[var(--iris-control)]"></span>
        Looking for quoted post…
      </div>
    {/if}
  </div>

  {#if !expanded && preview}
    <div
      aria-hidden="true"
      class="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[var(--iris-quote-fill)] to-transparent"
    ></div>
    <button
      data-testid="note-inline-quote-expand"
      type="button"
      class="iris-neutral-button absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-sm font-semibold"
      on:click|stopPropagation={() => {
        expanded = true;
      }}
    >
      Show More
    </button>
  {/if}
</div>

<style>
  .iris-inline-quote {
    --iris-quote-fill: var(--iris-canvas);
    background-color: var(--iris-quote-fill);
  }

  .iris-inline-quote:hover {
    --iris-quote-fill: var(--iris-surface);
  }
</style>
