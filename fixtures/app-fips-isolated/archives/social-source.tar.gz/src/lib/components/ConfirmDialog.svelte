<script lang="ts">
  import ModalShell from './ModalShell.svelte';

  export let title: string;
  export let message = '';
  export let confirmLabel = 'Confirm';
  export let testId = 'confirm-dialog';
  export let onConfirm: () => void;
  export let onClose: () => void;

  const titleId = `confirm-dialog-title-${Math.random().toString(36).slice(2)}`;
</script>

<ModalShell open {onClose} shellClass="items-center justify-center p-4" contentClass="w-full max-w-sm">
  <div
    role="alertdialog"
    tabindex="-1"
    aria-modal="true"
    aria-labelledby={titleId}
    data-testid={testId}
    data-note-no-thread-nav
    class="rounded-2xl bg-[var(--iris-surface)] p-5 text-[rgb(var(--iris-text-rgb))] shadow-xl"
  >
    <h2 id={titleId} class="break-words text-lg font-700">{title}</h2>
    {#if message}
      <p class="mt-2 text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">{message}</p>
    {/if}
    <div class="mt-5 flex justify-end gap-3">
      <button
        type="button"
        class="rounded-full px-4 py-2.5 transition hover:bg-[rgb(var(--iris-text-rgb)/0.06)]"
        on:click={onClose}
      >
        Cancel
      </button>
      <button
        data-testid={`${testId}-confirm`}
        type="button"
        class="rounded-full bg-violet-600 px-4 py-2.5 font-600 text-white transition hover:bg-violet-500"
        on:click={() => { onConfirm(); onClose(); }}
      >
        {confirmLabel}
      </button>
    </div>
  </div>
</ModalShell>
