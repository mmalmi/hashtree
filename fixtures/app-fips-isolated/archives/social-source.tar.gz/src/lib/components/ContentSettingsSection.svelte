<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import {
    settingsStore,
    type ContentSettings,
    type SearchModelPreference,
  } from '../settings';
  import UserRow from './UserRow.svelte';

  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let canPublish = false;
  export let onToggleMute: (pubkey: string, muted: boolean) => void = () => undefined;

  const groups: Array<{ title: string; items: Array<{ key: keyof ContentSettings; label: string }> }> = [
    { title: 'Posting', items: [
      { key: 'showClientTag', label: 'Identify Iris Social on my public posts, replies and reposts' },
    ] },
    { title: 'Media', items: [
      { key: 'blurSensitiveMedia', label: 'Hide sensitive media until revealed' },
      { key: 'autoplayVideos', label: 'Autoplay videos' },
    ] },
    { title: 'Reactions', items: [
      { key: 'showReactions', label: 'Show reaction buttons' },
      { key: 'showReactionCounts', label: 'Show reaction counts' },
      { key: 'showLikes', label: 'Show likes' },
      { key: 'showReposts', label: 'Show reposts' },
      { key: 'showReplies', label: 'Show replies' },
      { key: 'showZaps', label: 'Show zaps' },
    ] },
  ];
</script>

<div data-testid="settings-content-section" class="grid gap-6 p-4 sm:p-5">
  {#each groups as group}
    <SettingsGroup title={group.title}>
      {#each group.items as item, index}
        <SettingsGroupItem isLast={index === group.items.length - 1}>
          <label class="flex cursor-pointer items-center justify-between gap-4 text-[0.9rem]">
            <span>{item.label}</span>
            <input
              type="checkbox"
              data-testid={`content-${item.key}`}
              checked={$settingsStore.content[item.key]}
              class="h-4 w-4 shrink-0 accent-violet-500"
              on:change={() => settingsStore.setContentSettings({ [item.key]: !$settingsStore.content[item.key] })}
            />
          </label>
        </SettingsGroupItem>
      {/each}
    </SettingsGroup>
  {/each}
  <SettingsGroup title="Post search">
    <SettingsGroupItem isLast={true}>
      <label class="flex flex-wrap items-center justify-between gap-3 text-[0.9rem]">
        <span>AI search model</span>
        <select
          data-testid="search-model-select"
          aria-label="AI search model"
          value={$settingsStore.search.model}
          class="rounded-lg bg-[var(--iris-surface)] px-3 py-1.5 text-sm text-[rgb(var(--iris-text-rgb))] outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          on:change={(event) => settingsStore.setSearchSettings({
            model: (event.currentTarget as HTMLSelectElement).value as SearchModelPreference,
          })}
        >
          <option value="auto">Automatic · browser, then MiniLM</option>
          <option value="minilm">MiniLM · on device</option>
          <option value="browser">Browser model · already installed</option>
          <option value="ollama">Ollama · local server</option>
        </select>
      </label>
      {#if $settingsStore.search.model === 'ollama'}
        <label class="mt-3 flex flex-col gap-1.5 text-[0.88rem]">
          <span>Ollama model</span>
          <input
            type="text"
            data-testid="search-ollama-model"
            aria-label="Ollama model"
            value={$settingsStore.search.ollamaModel}
            placeholder="gemma3:1b"
            class="rounded-lg bg-[var(--iris-surface)] px-3 py-1.5 text-sm text-[rgb(var(--iris-text-rgb))] outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
            on:input={(event) => settingsStore.setSearchSettings({
              ollamaModel: (event.currentTarget as HTMLInputElement).value,
            })}
          />
          <span class="text-xs text-[rgb(var(--iris-text-rgb)/0.6)]">
            Queries and candidate posts go to your Ollama server on port 11434. Allow this site’s origin in OLLAMA_ORIGINS.
          </span>
        </label>
      {/if}
    </SettingsGroupItem>
  </SettingsGroup>
  <SettingsGroup title="Muted people">
    {#each [...mutedPubkeys] as pubkey, index (pubkey)}
      <SettingsGroupItem isLast={index === mutedPubkeys.size - 1}>
        <div data-testid="settings-muted-person" class="flex items-center justify-between gap-3">
          <UserRow {pubkey} avatarSize={36} showSubtitle={false} showHoverCard={false} className="min-w-0 flex-1" />
          <button type="button" aria-busy={mutePendingPubkeys.has(pubkey)} disabled={!canPublish || mutePendingPubkeys.has(pubkey)} class="shrink-0 rounded-full px-3 py-2 text-sm font-600 text-violet-500 hover:bg-[var(--iris-surface-hover)] disabled:opacity-50" on:click={() => onToggleMute(pubkey, false)}>{mutePendingPubkeys.has(pubkey) ? 'Unmuting…' : 'Unmute'}</button>
        </div>
      </SettingsGroupItem>
    {:else}
      <SettingsGroupItem isLast={true}>
        <span class="text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">No muted people</span>
      </SettingsGroupItem>
    {/each}
  </SettingsGroup>
</div>
