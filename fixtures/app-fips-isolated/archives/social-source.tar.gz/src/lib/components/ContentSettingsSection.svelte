<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { settingsStore, type ContentSettings } from '../settings';
  import UserRow from './UserRow.svelte';

  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let canPublish = false;
  export let onToggleMute: (pubkey: string, muted: boolean) => void = () => undefined;

  const groups: Array<{ title: string; items: Array<{ key: keyof ContentSettings; label: string }> }> = [
    { title: 'Media', items: [
      { key: 'blurSensitiveMedia', label: 'Hide sensitive media until revealed' },
      { key: 'autoplayVideos', label: 'Autoplay videos' },
    ] },
    { title: 'Reactions', items: [
      { key: 'showReactions', label: 'Show reaction buttons' },
      { key: 'showReactionCounts', label: 'Show reaction counts' },
      { key: 'showLikes', label: 'Show likes' },
      { key: 'showReposts', label: 'Show reposts' },
      { key: 'showReplies', label: 'Show replies' },
      { key: 'showZaps', label: 'Show zaps' },
    ] },
  ];
</script>

<div data-testid="settings-content-section" class="grid gap-6 p-4 sm:p-5">
  {#each groups as group}
    <SettingsGroup title={group.title}>
      {#each group.items as item, index}
        <SettingsGroupItem isLast={index === group.items.length - 1}>
          <label class="flex cursor-pointer items-center justify-between gap-4 text-[0.9rem]">
            <span>{item.label}</span>
            <input
              type="checkbox"
              data-testid={`content-${item.key}`}
              checked={$settingsStore.content[item.key]}
              class="h-4 w-4 shrink-0 accent-violet-500"
              on:change={() => settingsStore.setContentSettings({ [item.key]: !$settingsStore.content[item.key] })}
            />
          </label>
        </SettingsGroupItem>
      {/each}
    </SettingsGroup>
  {/each}
  <SettingsGroup title="Muted people">
    {#each [...mutedPubkeys] as pubkey, index (pubkey)}
      <SettingsGroupItem isLast={index === mutedPubkeys.size - 1}>
        <div data-testid="settings-muted-person" class="flex items-center justify-between gap-3">
          <UserRow {pubkey} avatarSize={36} showSubtitle={false} showHoverCard={false} className="min-w-0 flex-1" />
          <button type="button" disabled={!canPublish || mutePendingPubkeys.has(pubkey)} class="shrink-0 rounded-full px-3 py-2 text-sm font-600 text-violet-500 hover:bg-[var(--iris-surface-hover)] disabled:opacity-50" on:click={() => onToggleMute(pubkey, false)}>Unmute</button>
        </div>
      </SettingsGroupItem>
    {:else}
      <SettingsGroupItem isLast={true}>
        <span class="text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">No muted people</span>
      </SettingsGroupItem>
    {/each}
  </SettingsGroup>
</div>
