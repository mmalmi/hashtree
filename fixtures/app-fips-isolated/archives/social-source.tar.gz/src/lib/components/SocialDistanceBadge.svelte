<script lang="ts">
  import SharedSocialDistanceBadge from '@iris/svelte-ui/SocialDistanceBadge.svelte';
  export let distance: number | null | undefined = null;
  export let followedByFriends: number | null | undefined = null;
  export let className = '';
  export let muted = false;
</script>

<SharedSocialDistanceBadge {distance} {followedByFriends} {muted} className={`iris-preserve-white-text ${className}`} />
