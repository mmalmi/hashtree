<script lang="ts">
  import type { AppError } from '../appError';
  import { onDestroy, tick } from 'svelte';
  import { buildComposerPostContent } from '../appPublishingActions';
  import type { ComposerAttachment } from '../media';
  import type { ComposerSubmitPayload } from '../composerOptions';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { ReferencedNotePreview } from '../referencedNote';
  import ComposerCard from './ComposerCard.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';
  import NoteEmbeds from './NoteEmbeds.svelte';
  import NoteText from './NoteText.svelte';

  export let open = false;
  export let title = 'New post';
  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let value = '';
  export let disabled = false;
  export let error: AppError = '';
  export let attachments: ComposerAttachment[] = [];
  export let returnFocusTo: HTMLElement | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let onOpenNote: ((ref: string) => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onInput: (value: string) => void;
  export let onAttachmentsChange: (attachments: ComposerAttachment[]) => void;
  export let onSubmit: (payload: ComposerSubmitPayload) => void | Promise<void>;
  export let onClose: () => void;

  let panel: HTMLDivElement;
  let composer: ComposerCard;
  let preview = false;
  let wasOpen = false;
  let returnFocus: HTMLElement | null = null;
  let retainEditor = false;

  // Uploaded files and text are stored with the draft. Leave the closed editor
  // mounted only while a retry can still need a File from its upload session.
  $: if (open || !attachments.some(attachment => attachment.status !== 'done')) {
    retainEditor = open;
  }
  $: syncOpen(open);
  $: previewContent = preview ? buildComposerPostContent(
    value,
    attachments.filter(attachment => attachment.status === 'done'),
  ) : '';
  $: previewEvent = previewContent ? {
    id: 'draft-preview', pubkey, created_at: 0, kind: 1, tags: [], content: previewContent, sig: '',
  } satisfies RawEvent : null;

  async function focusEditor(): Promise<void> {
    await tick();
    if (open && !composer?.focusInput()) {panel?.focus({ preventScroll: true });}
  }

  function restoreFocus(): void {
    const target = returnFocus;
    returnFocus = null;
    if (!target) {return;}
    void tick().then(() => {
      if (!returnFocus && target.isConnected && !target.closest('[inert]')) {
        target.focus({ preventScroll: true });
      }
    });
  }

  function syncOpen(nextOpen: boolean): void {
    if (nextOpen === wasOpen) {return;}
    wasOpen = nextOpen;
    preview = false;
    if (nextOpen) {
      returnFocus = returnFocusTo ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null);
      void focusEditor();
    } else {
      restoreFocus();
    }
  }

  function edit(): void {
    preview = false;
    void focusEditor();
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (event.defaultPrevented || event.isComposing) {return;}
    if (event.key === 'Escape' && !document.fullscreenElement) {
      event.preventDefault();
      onClose();
    }
    if (event.key !== 'Tab') {return;}
    const focusable = [...panel.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])',
    )].filter(element => element.getClientRects().length > 0);
    const first = focusable[0] ?? panel;
    const last = focusable.at(-1) ?? panel;
    if (event.shiftKey && (event.target === first || event.target === panel)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && event.target === last) {
      event.preventDefault();
      first.focus();
    }
  }

  onDestroy(restoreFocus);

  const toggleClass = 'h-8 rounded-full px-4 text-[0.88rem] font-650 text-[rgb(var(--iris-text-rgb)/0.7)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] aria-pressed:bg-[linear-gradient(to_top,#3c21c8,#7a29ff)] aria-pressed:text-white aria-pressed:hover:brightness-110';
</script>

<ModalShell
  {open}
  {onClose}
  closeOnEscape={false}
  keepMounted={retainEditor}
  shellClass="items-start justify-center p-3 pt-6 sm:items-center sm:p-5"
  contentClass="max-h-[calc(100dvh-2rem)] w-full max-w-[38rem] overflow-y-auto rounded-2xl"
  backdropClass="bg-black/70"
>
  <div
    bind:this={panel}
    data-testid="post-composer-dialog"
    role="dialog"
    aria-modal="true"
    aria-labelledby="post-composer-title"
    tabindex="-1"
    on:keydown={handleKeydown}
    class="composer-dialog rounded-2xl text-[rgb(var(--iris-text-rgb))] shadow-2xl outline-none"
  >
    <h2 id="post-composer-title" class="sr-only">{title}</h2>
    <div class="flex items-center justify-between gap-3 px-4 pt-4 sm:px-5">
      <div role="group" aria-label="Composer view" class="flex gap-1.5">
        <button
          data-testid="composer-edit"
          type="button"
          aria-pressed={!preview}
          class={toggleClass}
          on:click={edit}
        >Edit</button>
        <button
          data-testid="composer-preview"
          type="button"
          aria-pressed={preview}
          class={toggleClass}
          on:click={() => {preview = true;}}
        >Preview</button>
      </div>
      <button
        type="button"
        aria-label="Close composer"
        title="Close"
        class="-mr-1.5 grid h-9 w-9 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.7)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] hover:text-[rgb(var(--iris-text-rgb))]"
        on:click={onClose}
      ><IrisIcon name="x-close" size={20} /></button>
    </div>

    <ComposerCard
      bind:this={composer}
      dialog
      {preview}
      {pubkey}
      {profile}
      {value}
      {disabled}
      {error}
      {attachments}
      {onInput}
      {onAttachmentsChange}
      {onSubmit}
      onCancel={onClose}
      placeholder="What's on your mind?"
    >
      <div
        slot="preview"
        data-testid="composer-preview-content"
        class="min-h-[10rem] max-h-[min(45dvh,22rem)] overflow-x-hidden overflow-y-auto overscroll-contain pt-1.5 pr-1 text-[1.05rem]"
      >
        {#if previewEvent}
          <NoteText event={previewEvent} {profile} {resolveReferencedNote} {onOpenNote} {onOpenProfile} collapsible={false} />
          <NoteEmbeds event={previewEvent} viewActive={open} />
        {/if}
      </div>
    </ComposerCard>
  </div>
</ModalShell>

<style>
  /* A lifted surface separates the composer from the page without lines. */
  .composer-dialog {
    --composer-surface: #1a1a1a;
    background-color: var(--composer-surface);
  }

  :global(:root[data-theme='light']) .composer-dialog {
    --composer-surface: var(--iris-surface);
  }
</style>
