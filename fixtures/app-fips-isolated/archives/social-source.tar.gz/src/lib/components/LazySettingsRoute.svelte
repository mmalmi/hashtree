<script lang="ts">
  import { loadSettingsPageModule } from '../lazyRouteComponents';
  import type { EditableProfileFields } from '../profileMetadata';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { SettingsSection } from '../routes';

  export let section: SettingsSection;
  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let onToggleMute: (pubkey: string, muted: boolean) => void = () => undefined;
  export let viewerPubkey: string | null = null;
  export let viewerProfileEvent: RawEvent | null = null;
  export let viewerProfile: ProfileRecord | null = null;
  export let canActiveAccountPublish = false;
  export let profileSavePending = false;
  export let profileEditorBlockedReason = '';
  export let profileSaveError = '';
  export let profileSaveMessage = '';
  export let onSaveProfile: (fields: Partial<EditableProfileFields>) => void = () => undefined;
  export let onRegisterIrisUsername: (username: string, cfToken?: string) => Promise<{ signedUp: boolean }> = async () => ({ signedUp: false });
  export let onSetProfileNip05: (nip05: string) => void = () => undefined;
  export let isActive = false;

  let component: typeof import('./SettingsPage.svelte').default | null = null;
  let loadError = '';

  async function load(): Promise<void> {
    if (component) {
      return;
    }
    loadError = '';
    try {
      component = (await loadSettingsPageModule()).default;
    } catch (error) {
      loadError = "Couldn't load settings.";
      console.warn('Failed to load settings', error);
    }
  }

  $: if (!component) {
    void load();
  }
</script>

<div
  aria-busy={!component && !loadError}
  class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
>
  {#if component}
    <svelte:component
      this={component}
      {section}
      {mutedPubkeys}
      {mutePendingPubkeys}
      {onToggleMute}
      {viewerPubkey}
      {viewerProfileEvent}
      {viewerProfile}
      canPublishProfile={canActiveAccountPublish}
      {profileSavePending}
      {profileEditorBlockedReason}
      {profileSaveError}
      {profileSaveMessage}
      {onSaveProfile}
      {onRegisterIrisUsername}
      {onSetProfileNip05}
      {isActive}
    />
  {:else if loadError}
    <div class="grid justify-items-start gap-3 border-b border-white/5 px-4 py-6 text-[0.95rem] text-white/60 sm:px-5">
      <span>{loadError}</span>
      <button
        type="button"
        class="rounded-full border border-white/15 px-4 py-2 font-700 text-white/80 transition hover:bg-white/5 hover:text-white"
        on:click={() => void load()}
      >
        Retry
      </button>
    </div>
  {/if}
</div>
