<script lang="ts">
  import { onDestroy } from 'svelte';
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import {
    checkIrisUsernameAvailability,
    findIrisUsernameAccount,
    validateIrisUsername,
    type IrisUsernameAccount,
  } from '../irisUsername';
  import IrisIcon from './IrisIcon.svelte';
  import IrisTurnstile from './IrisTurnstile.svelte';

  export let viewerPubkey: string | null = null;
  export let profileNip05 = '';
  export let canPublish = false;
  export let profileSavePending = false;
  export let onRegister: (username: string, cfToken?: string) => Promise<{ signedUp: boolean }> = async () => ({ signedUp: false });
  export let onSetProfileNip05: (nip05: string) => void = () => undefined;
  export let isActive = true;

  let account: IrisUsernameAccount | null = null;
  let loading = true;
  let loadedPubkey = '';
  let username = '';
  let availability: 'idle' | 'checking' | 'available' | 'unavailable' = 'idle';
  let statusMessage = '';
  let error = '';
  let registrationPending = false;
  let showChallenge = false;
  let pendingUsername = '';
  let availabilityTimer: ReturnType<typeof setTimeout> | null = null;

  $: activeIrisName = profileNip05.toLowerCase().endsWith('@iris.to')
    ? profileNip05.slice(0, -'@iris.to'.length)
    : '';
  $: if (viewerPubkey && viewerPubkey !== loadedPubkey) {
    loadedPubkey = viewerPubkey;
    void loadAccount(viewerPubkey);
  }
  $: if (!isActive) {
    showChallenge = false;
    if (availabilityTimer) {
      clearTimeout(availabilityTimer);
      availabilityTimer = null;
    }
  }

  async function loadAccount(pubkey: string): Promise<void> {
    loading = true;
    error = '';
    try {
      account = await findIrisUsernameAccount(pubkey);
    } catch (nextError) {
      error = nextError instanceof Error ? nextError.message : 'Could not load your Iris account.';
      account = { name: null, subscriptionPlan: null, minimumLength: 8 };
    } finally {
      loading = false;
    }
  }

  function handleUsernameInput(): void {
    if (availabilityTimer) clearTimeout(availabilityTimer);
    availability = 'idle';
    statusMessage = '';
    error = '';
    const validation = validateIrisUsername(username, account?.minimumLength ?? 8);
    if (!username) return;
    if (!validation.ok) {
      availability = 'unavailable';
      statusMessage = validation.message;
      return;
    }
    availability = 'checking';
    statusMessage = 'Checking availability…';
    availabilityTimer = setTimeout(() => void checkAvailability(validation.username), 300);
  }

  async function checkAvailability(name: string): Promise<void> {
    if (!viewerPubkey) return;
    try {
      const result = await checkIrisUsernameAvailability(name, viewerPubkey);
      if (username.trim() !== name) return;
      availability = result.available ? 'available' : 'unavailable';
      statusMessage = result.message;
    } catch {
      availability = 'unavailable';
      statusMessage = 'Could not check availability. Try again.';
    }
  }

  function beginRegistration(): void {
    const validation = validateIrisUsername(username, account?.minimumLength ?? 8);
    if (!validation.ok || availability !== 'available') return;
    pendingUsername = validation.username;
    if (account?.subscriptionPlan) void completeRegistration();
    else showChallenge = true;
  }

  async function completeRegistration(cfToken?: string): Promise<void> {
    registrationPending = true;
    error = '';
    try {
      const result = await onRegister(pendingUsername, cfToken);
      if (!result.signedUp) throw new Error('Iris could not register that username.');
      account = {
        name: pendingUsername,
        subscriptionPlan: account?.subscriptionPlan ?? null,
        minimumLength: account?.minimumLength ?? 8,
      };
      showChallenge = false;
    } catch (nextError) {
      error = nextError instanceof Error ? nextError.message : 'Could not register that username.';
      showChallenge = false;
    } finally {
      registrationPending = false;
    }
  }

  onDestroy(() => {
    if (availabilityTimer) {
      clearTimeout(availabilityTimer);
    }
  });
</script>

<div data-testid="settings-iris-section" class="grid gap-6 p-4 sm:p-5">
  <p class="m-0 px-3 text-[0.76rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.4)]">
    Registration sends your public key, chosen username, IP address and country to Iris for abuse prevention.
  </p>

  <div>
  {#if loading}
    <SettingsGroup>
      <SettingsGroupItem isLast={true}>
        <div class="py-2 text-[0.9rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Loading your Iris account…</div>
      </SettingsGroupItem>
    </SettingsGroup>
  {:else if activeIrisName}
    <SettingsGroup title="Active iris.to username">
      <SettingsGroupItem isLast={true}>
        <a href={`https://iris.to/${activeIrisName}`} class="flex items-center gap-3 text-[rgb(var(--iris-text-rgb))] no-underline" target="_blank" rel="noreferrer">
          <span class="grid h-10 w-10 place-items-center rounded-full bg-violet-500 text-white iris-preserve-white-text"><IrisIcon name="at-sign" size={21} /></span>
          <span class="min-w-0">
            <span class="block truncate text-[1rem] font-700">iris.to/{activeIrisName}</span>
            <span class="mt-0.5 block truncate text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.52)]">{activeIrisName}@iris.to</span>
          </span>
        </a>
      </SettingsGroupItem>
    </SettingsGroup>
  {:else if account?.name}
    <SettingsGroup title="Your iris.to username">
      <SettingsGroupItem isLast={true}>
        <a href={`https://iris.to/${account.name}`} target="_blank" rel="noreferrer" class="text-[1rem] font-700 text-[rgb(var(--iris-text-rgb))] no-underline">iris.to/{account.name}</a>
        <div class="mt-1 text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.52)]">{account.name}@iris.to</div>
        <button
          data-testid="iris-set-primary"
          type="button"
          class="mt-4 rounded-full bg-[var(--iris-solid)] px-4 py-2 text-[0.86rem] font-700 text-[var(--iris-on-solid)] disabled:opacity-45"
          disabled={!canPublish || profileSavePending}
          on:click={() => onSetProfileNip05(`${account?.name}@iris.to`)}
        >
          {profileSavePending ? 'Saving…' : 'Set as primary Nostr address'}
        </button>
      </SettingsGroupItem>
    </SettingsGroup>
  {:else if showChallenge}
    <SettingsGroup title="Verification required">
      <SettingsGroupItem isLast={true}>
        <p class="m-0 mb-4 text-[0.9rem] text-[rgb(var(--iris-text-rgb)/0.62)]">Complete the check to register <strong class="text-[rgb(var(--iris-text-rgb))]">iris.to/{pendingUsername}</strong>.</p>
        <IrisTurnstile onVerify={(token) => void completeRegistration(token)} onError={() => error = 'Verification failed. Try again.'} />
        <button type="button" class="mt-2 text-[0.84rem] font-600 text-[rgb(var(--iris-text-rgb)/0.58)]" on:click={() => showChallenge = false}>Cancel</button>
      </SettingsGroupItem>
    </SettingsGroup>
  {:else}
    {#if account?.subscriptionPlan}
      <SettingsGroup title="Subscription">
        <SettingsGroupItem isLast={true}>
          <div class="text-[0.9rem]">
          {account.subscriptionPlan} · usernames from {account.minimumLength} characters
          </div>
        </SettingsGroupItem>
      </SettingsGroup>
    {/if}

    <SettingsGroup title="Register username">
      <SettingsGroupItem isLast={true}>
        <form on:submit|preventDefault={beginRegistration}>
        <p class="m-0 text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.58)]">Choose a short address for your Nostr profile.</p>
        <div class="mt-4 flex gap-2">
          <div class="flex min-w-0 flex-1 items-center rounded-lg bg-[var(--iris-surface-subtle)] px-3 focus-within:ring-1 focus-within:ring-violet-400/45">
            <span class="shrink-0 text-[0.9rem] text-[rgb(var(--iris-text-rgb)/0.42)]">iris.to/</span>
            <input
              data-testid="iris-username-input"
              bind:value={username}
              autocomplete="username"
              maxlength="15"
              class="min-w-0 flex-1 bg-transparent py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none"
              placeholder="username"
              on:input={handleUsernameInput}
            />
          </div>
          <button
            data-testid="iris-username-register"
            type="submit"
            class="rounded-lg bg-violet-600 px-4 py-2.5 text-[0.88rem] font-700 text-white iris-preserve-white-text transition hover:bg-violet-500 disabled:cursor-not-allowed disabled:opacity-40"
            disabled={availability !== 'available' || registrationPending || !canPublish}
          >{registrationPending ? 'Registering…' : 'Register'}</button>
        </div>
        {#if statusMessage}
          <div class={`mt-2 text-[0.82rem] ${availability === 'available' ? 'text-emerald-400' : availability === 'unavailable' ? 'text-rose-400' : 'text-[rgb(var(--iris-text-rgb)/0.48)]'}`}>{statusMessage}</div>
        {/if}
        {#if !canPublish}
          <div class="mt-3 text-[0.82rem] text-amber-500">Import this account’s secret key to register a username.</div>
        {/if}
        </form>
      </SettingsGroupItem>
    </SettingsGroup>
  {/if}
  </div>

  {#if error}
    <div data-testid="iris-username-error" class="text-[0.84rem] text-rose-400">{error}</div>
  {/if}
</div>
