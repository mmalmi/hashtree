<script lang="ts">
  import type { ArticleLink, ArticleNode } from '../articleContent';
  import type { NoteEmbed } from '../noteContent';
  import ProxyImg from './ProxyImg.svelte';
  import Username from './Username.svelte';

  export let nodes: ArticleNode[];
  export let imagesVisible = true;
  export let insideLink = false;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenNote: ((reference: string) => void) | null = null;
  export let onOpenImage: ((embed: NoteEmbed) => void) | null = null;

  function followLink(event: MouseEvent, link: ArticleLink): void {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) { return; }
    if (link.pubkey && onOpenProfile) { event.preventDefault(); onOpenProfile(link.pubkey); }
    else if (link.reference && onOpenNote) { event.preventDefault(); onOpenNote(link.reference); }
  }
</script>

{#each nodes as node}
  {#if node.type === 'text'}
    {node.text}
  {:else if node.type === 'code'}
    {#if node.block}<pre><code>{node.text}</code></pre>{:else}<code>{node.text}</code>{/if}
  {:else if node.type === 'break'}
    <br />
  {:else if node.type === 'rule'}
    <hr />
  {:else if node.type === 'element'}
    <svelte:element this={node.tag} start={node.start}>
      <svelte:self nodes={node.children} {imagesVisible} {insideLink} {onOpenProfile} {onOpenNote} {onOpenImage} />
    </svelte:element>
  {:else if node.type === 'link'}
    <a
      href={node.link.href}
      title={node.title}
      target={node.link.external ? '_blank' : undefined}
      rel={node.link.external ? 'noopener noreferrer' : undefined}
      on:click={(event) => followLink(event, node.link)}
    >
      {#if node.mention && node.link.pubkey}
        <Username pubkey={node.link.pubkey} inline showSubtitle={false} titlePrefix="@" titleClass="inline" />
      {:else}
        <svelte:self nodes={node.children} {imagesVisible} insideLink {onOpenProfile} {onOpenNote} {onOpenImage} />
      {/if}
    </a>
  {:else if node.type === 'image' && imagesVisible}
    {#if onOpenImage && !insideLink}
      <button type="button" class="article-image" title={node.title} aria-label={node.alt ? `Open image: ${node.alt}` : 'Open image'} on:click={() => onOpenImage?.(node.embed)}>
        <ProxyImg src={node.embed.url} alt={node.alt} width={900} className="block h-auto max-h-[75vh] w-full object-contain" />
      </button>
    {:else}
      <span class="article-image" title={node.title}>
        <ProxyImg src={node.embed.url} alt={node.alt} width={900} className="block h-auto max-h-[75vh] w-full object-contain" />
      </span>
    {/if}
  {/if}
{/each}
