<script lang="ts">
  import { onDestroy, tick } from 'svelte';
  import ComposerCard from '../ComposerCard.svelte';
  import IrisUsernameRoute from '../IrisUsernameRoute.svelte';
  import LazyWalletRoute from '../LazyWalletRoute.svelte';
  import MainRouteView from '../MainRouteView.svelte';
  import RouteActivityProvider from '../RouteActivityProvider.svelte';
  import { getActiveAppRouteElement } from '../../appScroll';
  import { routeKey } from '../../appRoute';
  import { presentedRoute } from '../../appRoutePresentation';
  import { waitForNextBrowserPaint } from '../../asyncTiming';
  import type {
    AccountStateSnapshot,
    AppShellActions,
    AppShellView,
    EngagementStateSnapshot,
    HomeStateSnapshot,
    MediaStateSnapshot,
    NotificationStateSnapshot,
    RouteStateSnapshot,
    SearchStateSnapshot,
    ThreadStateSnapshot,
    ViewerStateSnapshot,
  } from './types';

  export let routeState: RouteStateSnapshot;
  export let homeState: HomeStateSnapshot;
  export let threadState: ThreadStateSnapshot;
  export let searchState: SearchStateSnapshot;
  export let accountState: AccountStateSnapshot;
  export let viewerState: ViewerStateSnapshot;
  export let engagementState: EngagementStateSnapshot;
  export let notificationState: NotificationStateSnapshot;
  export let mediaState: MediaStateSnapshot;
  export let view: AppShellView;
  export let actions: AppShellActions;

  let contentActiveKeys = new Set<string>();
  let requestedContentActiveKey: string | null = null;
  let contentActivityVersion = 0;
  let contentPauseIdleId: number | null = null;
  let contentPauseTimer: number | null = null;
  $: activePresentationKey = $presentedRoute
    ? routeKey($presentedRoute)
    : routeState.activeRenderEntry?.key ?? null;
  $: activePresentationIsMounted = routeState.mountedRenderEntries.some(
    (entry) => entry.key === activePresentationKey,
  );

  function cancelContentPause(): void {
    if (contentPauseIdleId !== null) {
      window.cancelIdleCallback?.(contentPauseIdleId);
      contentPauseIdleId = null;
    }
    if (contentPauseTimer !== null) {
      window.clearTimeout(contentPauseTimer);
      contentPauseTimer = null;
    }
  }

  function scheduleRouteContentActivity(nextKey: string | null): void {
    if (!nextKey || nextKey === requestedContentActiveKey) {
      return;
    }
    requestedContentActiveKey = nextKey;
    const version = ++contentActivityVersion;
    cancelContentPause();

    if (contentActiveKeys.size === 0) {
      contentActiveKeys = new Set([nextKey]);
      return;
    }

    void waitForNextBrowserPaint().then(() => {
      if (version !== contentActivityVersion || nextKey !== requestedContentActiveKey) {
        return;
      }

      // Showing the destination card only changes two wrappers. Wake its
      // subtree after that card has reached the compositor, then pause the old
      // tree during idle time so hundreds of cards cannot delay the transition.
      contentActiveKeys = new Set(contentActiveKeys).add(nextKey);
      const pauseInactiveContent = () => {
        contentPauseIdleId = null;
        contentPauseTimer = null;
        if (version === contentActivityVersion && nextKey === requestedContentActiveKey) {
          contentActiveKeys = new Set([nextKey]);
        }
      };
      if (typeof window.requestIdleCallback === 'function') {
        contentPauseIdleId = window.requestIdleCallback(pauseInactiveContent, { timeout: 500 });
      } else {
        contentPauseTimer = window.setTimeout(pauseInactiveContent, 50);
      }
    });
  }

  $: scheduleRouteContentActivity(activePresentationKey);

  onDestroy(() => {
    contentActivityVersion += 1;
    cancelContentPause();
  });

  function maintainValidRouteFocus(node: HTMLElement, initiallyActive: boolean) {
    let active = initiallyActive;
    return {
      update(nextActive: boolean) {
        const focusedElement = document.activeElement;
        const shouldTransferFocus = active
          && !nextActive
          && focusedElement instanceof HTMLElement
          && node.contains(focusedElement);
        active = nextActive;
        if (!shouldTransferFocus) {
          return;
        }
        void tick().then(() => {
          const currentFocus = document.activeElement;
          if (currentFocus !== focusedElement && currentFocus !== document.body) {
            return;
          }
          getActiveAppRouteElement()?.focus({ preventScroll: true });
        });
      },
    };
  }

</script>

<div class="relative min-h-0">
  {#each routeState.mountedRenderEntries as stackEntry (stackEntry.key)}
    {@const entryIsActive = stackEntry.key === activePresentationKey}
    {@const entryContentIsActive = contentActiveKeys.has(stackEntry.key)}
    {@const inactiveThreadDraft = !entryContentIsActive && stackEntry.route.kind === 'thread'
      ? view.threadReplyDrafts.read(stackEntry.key)
      : null}
    <div
      data-route-stack-card
      data-route-key={stackEntry.key}
      data-route-kind={stackEntry.route.kind}
      class={entryIsActive
        ? 'relative min-h-0'
        : 'hidden'}
    >
      <div
        data-testid={entryIsActive ? 'active-route-scroll' : undefined}
        data-app-route-scroll
        data-route-active={entryIsActive ? 'true' : 'false'}
        data-route-key={stackEntry.key}
        data-route-kind={stackEntry.route.kind}
        aria-hidden={entryIsActive ? undefined : 'true'}
        inert={entryIsActive ? undefined : true}
        tabindex="-1"
        aria-label={`${stackEntry.route.kind} view`}
        use:maintainValidRouteFocus={entryIsActive}
        class="min-h-0 overflow-x-clip"
      >
        <div
          data-testid="mounted-route-view"
          data-route-key={stackEntry.key}
          data-route-kind={stackEntry.route.kind}
          class="min-h-full"
        >
          <RouteActivityProvider active={entryContentIsActive}>
          <div class="h-[calc(4rem+env(safe-area-inset-top))] md:hidden" aria-hidden="true"></div>
          {#if stackEntry.route.kind === 'wallet'}
            <LazyWalletRoute active={entryContentIsActive} />
          {:else if stackEntry.route.kind === 'search'}
            <div
              aria-busy={!searchState.searchPageComponent && !searchState.searchPageLoadError}
              class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
            >
              {#if searchState.searchPageComponent}
                <svelte:component
                  this={searchState.searchPageComponent}
                  active={entryContentIsActive}
                  query={searchState.searchQuery}
                  initialTab={searchState.searchTab}
                  profilesByPubkey={view.searchableProfiles}
                  profileRecords={searchState.searchRemoteProfiles}
                  loading={entryContentIsActive && searchState.searchLoading}
                  localPostSearchEvents={view.localPostSearchEvents}
                  mutedPubkeys={viewerState.viewerMutedPubkeys}
                  viewerPubkey={accountState.activeAccount?.pubkey ?? null}
                  viewerFollows={viewerState.viewerFollows}
                  onQueryChange={(value: string) => actions.handleSearchQueryChange(value, 'page')}
                  onTabChange={actions.handleSearchTabChange}
                  onOpenProfile={actions.handleSearchOpenProfile}
                  onOpenPost={actions.handleSearchOpenPost}
                  onOpenThread={actions.handleSearchOpenThread}
                />
              {:else if searchState.searchPageLoadError}
                <div class="grid justify-items-start gap-3 border-b border-white/5 px-4 py-6 text-[0.95rem] text-white/60 sm:px-5">
                  <span>{searchState.searchPageLoadError}</span>
                  <button
                    type="button"
                    class="rounded-full border border-white/15 px-4 py-2 font-700 text-white/80 transition hover:bg-white/5 hover:text-white"
                    on:click={() => void actions.loadSearchPage()}
                  >
                    Retry
                  </button>
                </div>
              {/if}
            </div>
          {:else if stackEntry.route.kind === 'accounts'}
            <div
              aria-busy={!accountState.accountSheetComponent && !accountState.accountSheetLoadError}
              class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
            >
              {#if accountState.accountSheetComponent}
                <svelte:component
                  this={accountState.accountSheetComponent}
                  accounts={view.accounts}
                  activePubkey={accountState.activeAccount?.pubkey ?? null}
                  remoteProfiles={accountState.accountProfiles}
                  accountInput={accountState.accountInput}
                  importError={accountState.accountImportError}
                  onCreateAccount={() => void actions.handleCreateAccount()}
                  onImportAccount={() => void actions.handleImportAccount()}
                  onExtensionLogin={actions.handleExtensionLogin}
                  onAccountInput={actions.handleAccountInput}
                  onSwitchAccount={(pubkey) => void actions.handleSwitchAccount(pubkey)}
                  onRemoveAccount={(pubkey) => void actions.handleRemoveAccount(pubkey)}
                />
              {:else if accountState.accountSheetLoadError}
                <div class="grid justify-items-start gap-3 border-b border-white/5 px-4 py-6 text-[0.95rem] text-white/60 sm:px-5">
                  <span>{accountState.accountSheetLoadError}</span>
                  <button
                    type="button"
                    class="rounded-full border border-white/15 px-4 py-2 font-700 text-white/80 transition hover:bg-white/5 hover:text-white"
                    on:click={() => void actions.loadAccountSheet()}
                  >
                    Retry
                  </button>
                </div>
              {/if}
            </div>
          {:else if stackEntry.route.kind === 'username'}
            <IrisUsernameRoute
              username={stackEntry.route.username}
              active={entryContentIsActive}
              onResolve={actions.replaceUsernameWithProfile}
            />
          {:else}
            {#if stackEntry.route.kind === 'home' && view.canActiveAccountPublish && accountState.activeAccount}
              <div class="border-b border-white/5">
                <ComposerCard
                  pubkey={accountState.activeAccount.pubkey}
                  profile={view.activeProfile}
                  value={accountState.composerValue}
                  disabled={!view.canActiveAccountPublish}
                  error={accountState.composerError}
                  attachments={accountState.composerAttachments}
                  onInput={actions.handleComposerInput}
                  onAttachmentsChange={actions.bindComposerAttachments(accountState.activeAccount.pubkey)}
                  onSubmit={(payload) => void actions.handleCreatePostSubmit(payload)}
                />
              </div>
            {/if}
            <MainRouteView
              route={stackEntry.route}
              loading={stackEntry.cache.loading}
              homeRefreshing={entryContentIsActive && homeState.homeRefreshPending}
              isActive={entryContentIsActive}
              threadPresented={stackEntry.route.kind === 'thread' && entryIsActive}
              canActiveAccountPublish={view.canActiveAccountPublish}
              profiles={stackEntry.cache.profiles}
              noteEngagements={entryContentIsActive
                ? engagementState.displayedNoteEngagements
                : stackEntry.cache.noteEngagements}
              homeNotes={stackEntry.cache.homeNotes}
              feedView={homeState.feedView}
              homeFeedHasMore={stackEntry.cache.homeFeedHasMore}
              homeFeedLoadPending={stackEntry.cache.homeFeedLoadPending}
              homeFeedInfiniteScroll={view.infiniteScroll.home}
              onLoadMoreHome={() => void actions.loadMoreFeed()}
              bufferedLiveHomePostCount={homeState.bufferedLiveHomePostCount}
              feedSourceLabel={view.activeFeedSourceLabel}
              feedSourceId={homeState.activeFeedSourceId}
              notifications={stackEntry.cache.notifications}
              notificationsLoading={entryContentIsActive
                ? notificationState.notificationsLoading
                : stackEntry.cache.notificationsLoading}
              notificationsHasMore={entryContentIsActive
                ? notificationState.notificationsHasMore
                : stackEntry.cache.notificationsHasMore}
              notificationsLoadPending={entryContentIsActive
                ? notificationState.notificationsLoadPending
                : stackEntry.cache.notificationsLoadPending}
              notificationsInfiniteScroll={view.infiniteScroll.notifications}
              onLoadMoreNotifications={() => void actions.loadMoreNotifications()}
              profilePage={stackEntry.cache.profilePage}
              profileSocial={stackEntry.cache.profileSocial}
              profileSocialLoading={stackEntry.cache.profileSocialLoading}
              profileSocialLoadPending={stackEntry.cache.profileSocialLoadPending}
              profileNotesLoading={stackEntry.cache.profileNotesLoading}
              profileNotes={stackEntry.cache.profileNotes}
              profilePostCountLabel={stackEntry.cache.profilePostCountLabel ?? '...'}
              profileReplyCountLabel={stackEntry.cache.profileReplyCountLabel ?? '...'}
              profileMediaCountLabel={stackEntry.cache.profileMediaCountLabel ?? '...'}
              profileLikesCountLabel={stackEntry.cache.profileLikesCountLabel ?? '...'}
              profileFeedHasMore={stackEntry.cache.profileFeedHasMore}
              profileFeedLoadPending={stackEntry.cache.profileFeedLoadPending}
              profileFeedInfiniteScroll={view.infiniteScroll.profileFeed}
              onLoadMoreProfileNotes={() => void actions.loadMoreProfileNotes()}
              currentFollows={stackEntry.cache.currentFollows}
              currentFollowers={stackEntry.cache.currentFollowers}
              followsCountLabel={stackEntry.cache.followsCountLabel}
              followerCountLabel={stackEntry.cache.followerCountLabel}
              profileSocialHasMore={view.profileSocialHasMore}
              profileSocialInfiniteScroll={view.infiniteScroll.profileSocial}
              viewerPubkey={accountState.activeAccount?.pubkey ?? null}
              viewerProfile={view.activeProfile}
              viewerProfileEvent={accountState.viewerProfileEvent}
              profileSavePending={accountState.profileSavePending}
              profileEditorBlockedReason={view.profileEditorBlockedReason}
              profileSaveError={accountState.profileSaveError}
              profileSaveMessage={accountState.profileSaveMessage}
              viewerFollows={viewerState.viewerFollows}
              followPendingPubkeys={viewerState.followPendingPubkeys}
              mutedPubkeys={viewerState.viewerMutedPubkeys}
              mutePendingPubkeys={viewerState.mutePendingPubkeys}
              threadPage={stackEntry.cache.threadPage}
              threadReplies={stackEntry.cache.threadReplies}
              threadRepliesHasMore={stackEntry.cache.threadRepliesHasMore}
              threadRepliesLoadPending={entryContentIsActive
                ? threadState.threadRepliesLoadPending
                : stackEntry.cache.threadRepliesLoadPending}
              threadRepliesInfiniteScroll={view.infiniteScroll.threadReplies}
              onLoadMoreThreadReplies={() => void actions.loadMoreThreadReplies()}
              activeMediaEventId={mediaState.activeMediaEventId}
              activeMediaUrl={mediaState.activeMediaUrl}
              likePendingNoteIds={engagementState.likePendingNoteIds}
              zapPendingNoteIds={engagementState.zapPendingNoteIds}
              repostPendingNoteIds={engagementState.repostPendingNoteIds}
              rebroadcastPendingNoteIds={engagementState.rebroadcastPendingNoteIds}
              onLike={(event) => void actions.handleLike(event)}
              onZap={(event) => void actions.handleZap(event)}
              onZapAll={actions.openZapAll}
              onReply={actions.handleReplyAction}
              onQuote={view.canActiveAccountPublish ? actions.handleQuoteAction : null}
              onRepost={(event) => void actions.handleRepost(event)}
              threadReplyValue={entryContentIsActive
                ? threadState.threadReplyValue
                : inactiveThreadDraft?.value ?? ''}
              threadReplyError={entryContentIsActive
                ? threadState.threadReplyError
                : inactiveThreadDraft?.error ?? ''}
              threadReplyAttachments={entryContentIsActive
                ? threadState.threadReplyAttachments
                : inactiveThreadDraft?.attachments ?? []}
              onThreadReplyInput={(value) => actions.handleThreadReplyInput(stackEntry.key, value)}
              onThreadReplyAttachmentsChange={actions.bindThreadReplyAttachments(
                stackEntry.key,
                accountState.activeAccount?.pubkey ?? null,
              )}
              onThreadReplySubmit={(payload) =>
                void actions.handleThreadReplySubmit(stackEntry.key, payload)}
              onOpenReactions={(event, kind = 'likes') =>
                void actions.openNoteDetailSheet(event, kind)}
              onCopyLink={(event) => void actions.copyNoteLink(event)}
              onShare={(event) => void actions.copyNoteLink(event)}
              onCopyEventId={(event) => void actions.copyEventId(event)}
              onRebroadcast={(event) => void actions.rebroadcast(event)}
              onDelete={view.canActiveAccountPublish ? actions.handleDelete : null}
              onOpenMedia={actions.handleOpenMedia}
              onOpenProfile={actions.navigateProfile}
              onViewAsProfile={(pubkey) => void actions.handleViewAsProfile(pubkey)}
              onOpenNote={actions.navigateThread}
              onHomeNotePresented={entryContentIsActive ? actions.cachePresentedHomeNote : null}
              onHomeNoteVisible={entryContentIsActive ? actions.markHomeNoteSeen : null}
              onSelectHomeTab={actions.navigateHomeTab}
              onSelectFeedView={actions.handleSelectFeedView}
              onOpenFeedSources={actions.openFeedSourceSheet}
              onShowBufferedLiveHomePosts={() => void actions.showBufferedLiveHomePosts()}
              onToggleFollow={(pubkey, nextFollowing) =>
                void actions.handleToggleFollow(pubkey, nextFollowing)}
              onToggleMute={(pubkey, nextMuted) =>
                void actions.handleToggleMute(pubkey, nextMuted)}
              onCopyPubkey={(pubkey) => void actions.handleCopyPubkey(pubkey)}
              onCopyNpub={(npub) => void actions.handleCopyNpub(npub)}
              onCopyProfileLink={(href) => void actions.handleCopyProfileLink(href)}
              onOpenWebsite={actions.handleOpenWebsite}
              onEditProfile={actions.navigateSettings}
              onSaveProfile={(fields) => void actions.handleSaveProfile(fields)}
              onRegisterIrisUsername={actions.handleRegisterIrisUsername}
              onSetProfileNip05={(nip05) => void actions.handleSaveProfile({ nip05 })}
              resolveReferencedNote={view.resolveReferencedNote}
              onNavigateBack={actions.navigateBack}
              onOpenProfileImage={actions.handleOpenProfileImage}
            />
          {/if}
          </RouteActivityProvider>
          <div
            class="h-[calc(4rem+env(safe-area-inset-bottom))] md:hidden"
            aria-hidden="true"
          ></div>
        </div>
      </div>
    </div>
  {/each}

  {#if !activePresentationIsMounted}
    <div
      data-testid="active-route-scroll"
      data-app-route-scroll
      data-route-active="true"
      data-route-key={routeKey(routeState.route)}
      tabindex="-1"
      aria-label={`${routeState.route.kind} view`}
      class="relative min-h-[calc(100dvh-4rem)] overflow-x-clip"
    ></div>
  {/if}
</div>
