import type { Action } from 'svelte/action';
import type { Readable } from 'svelte/store';
import type { SocialAccount } from '../../accounts';
import type { AppState } from '../../appState';
import type { FeedView } from '../../feedView';
import type { RegisterIrisUsernameAction } from '../../irisUsername';
import type { MediaOpenPayload } from '../../appMedia';
import type { ComposerAttachment } from '../../media';
import type { NoteDetailListKind } from '../../nostrIndex';
import type { ProfileEdits } from '../../profileMetadata';
import type { ProfileRecord, RawEvent } from '../../nostr';
import type { ReferencedNotePreview } from '../../referencedNote';
import type { HomeTab } from '../../routes';
import type { ThreadReplyDraft } from '../../threadReplyDrafts';
import type { ZapOutcome, ZapRequestOptions } from '../../appZapActions';
import type { ZapAllRunOptions } from '../../zaps';

type StoreValue<Store> = Store extends Readable<infer Value> ? Value : never;

export type RouteStateSnapshot = StoreValue<AppState['routeState']>;
export type HomeStateSnapshot = StoreValue<AppState['homeState']>;
export type ThreadStateSnapshot = StoreValue<AppState['threadState']>;
export type SearchStateSnapshot = StoreValue<AppState['searchState']>;
export type AccountStateSnapshot = StoreValue<AppState['accountState']>;
export type ViewerStateSnapshot = StoreValue<AppState['viewerState']>;
export type EngagementStateSnapshot = StoreValue<AppState['engagementState']>;
export type NotificationStateSnapshot = StoreValue<AppState['notificationState']>;
export type MediaStateSnapshot = StoreValue<AppState['mediaState']>;
export type RuntimeStateSnapshot = StoreValue<AppState['runtimeState']>;
export type AccountAccessMode = 'sign-in' | 'create-profile';

type AccountAccessOptions = { preserveRoute?: boolean };

export type AppShellStateProps = Pick<
  AppState,
  | 'routeState'
  | 'homeState'
  | 'threadState'
  | 'searchState'
  | 'accountState'
  | 'viewerState'
  | 'engagementState'
  | 'notificationState'
  | 'mediaState'
  | 'runtimeState'
>;

export type ComposerPayload = {
  text: string;
  attachments: ComposerAttachment[];
};

export type ThreadReplyDraftReader = {
  read(key: string): ThreadReplyDraft | null;
};

export type AppShellInfiniteScrollActions = {
  home: Action<HTMLDivElement> | null;
  notifications: Action<HTMLDivElement> | null;
  profileFeed: Action<HTMLDivElement> | null;
  profileSocial: Action<HTMLDivElement> | null;
  threadReplies: Action<HTMLDivElement> | null;
};

export type AppShellView = {
  documentTitle: string;
  headerTitle: string;
  activeProfile: ProfileRecord | null;
  activeAccountFallbackProfile: ProfileRecord | null;
  searchableProfiles: Map<string, ProfileRecord>;
  localPostSearchEvents: RawEvent[];
  accounts: SocialAccount[];
  canActiveAccountPublish: boolean;
  profileEditorBlockedReason: string;
  profileSocialHasMore: boolean;
  activeFeedSourceLabel: string;
  threadReplyDrafts: ThreadReplyDraftReader;
  infiniteScroll: AppShellInfiniteScrollActions;
  resolveReferencedNote: (ref: string) => Promise<ReferencedNotePreview | null>;
};

export type AppShellActions = {
  handleWindowChromeClick(event: MouseEvent): void;
  handleWindowChromeKeydown(event: KeyboardEvent): void;
  handleHomeLinkClick(event: MouseEvent): void;
  scrollPageToTopInstant(): void;
  navigateBack(): void;
  openPostComposer(opener?: HTMLElement): void;
  closePostComposer(): void;
  navigateActiveProfile(): void;
  navigateAccounts(): void;
  navigateProfile(pubkey: string): void;
  navigateThread(target: string): void;
  navigateHomeTab(tab: HomeTab, feedId?: string | null): void;
  navigateSettings(): void;
  replaceUsernameWithProfile(pubkey: string): void;
  openSearchSheet(): void;
  handleSearchQueryChange(value: string, source?: 'page' | 'header'): void;
  handleSearchTabChange(tab: 'people' | 'posts'): void;
  handleSearchOpenProfile(pubkey: string): void;
  handleHeaderSearchPosts(query: string): void;
  handleSearchOpenPost(event: RawEvent): void;
  handleSearchOpenThread(ref: string): void;
  setSearchDropdownRoot(root: HTMLDivElement | null): void;
  loadSearchPage(): void | Promise<void>;
  loadAccountSheet(): void | Promise<void>;
  handleCreateAccount(options?: AccountAccessOptions & { name?: string }): void | Promise<void>;
  handleImportAccount(showError?: boolean, options?: AccountAccessOptions): void | Promise<void>;
  handleRemoteLogin(signal: AbortSignal, options?: AccountAccessOptions): void | Promise<void>;
  handleExtensionLogin(options?: AccountAccessOptions & { signal?: AbortSignal }): void | Promise<void>;
  handleAccountInput(value: string, pasted?: boolean, options?: AccountAccessOptions): void;
  handleSwitchAccount(pubkey: string, options?: AccountAccessOptions): void | Promise<void>;
  handleRemoveAccount(pubkey: string): void | Promise<void>;
  bindComposerAttachments(ownerPubkey: string): (attachments: ComposerAttachment[]) => void;
  handleComposerInput(value: string): void;
  handleComposerAttachmentsChange(attachments: ComposerAttachment[]): void;
  handleCreatePostSubmit(payload: ComposerPayload): void | Promise<void>;
  loadMoreFeed(): void | Promise<void>;
  loadMoreNotifications(): void | Promise<void>;
  loadMoreProfileNotes(): void | Promise<void>;
  loadMoreProfileSocial(section?: 'follows' | 'followers', limit?: number): Promise<void>;
  loadMoreThreadReplies(): void | Promise<void>;
  showBufferedLiveHomePosts(): void | Promise<void>;
  handleSelectFeedView(view: FeedView): void;
  openFeedSourceSheet(): void;
  setFeedSourceSheetOpen(open: boolean): void;
  handleFeedSourceNameChange(value: string): void;
  handleFeedSourceIdentityChange(value: string): void;
  addFeedSource(): void;
  selectFeedSource(id: string | null): void;
  removeFeedSource(id: string): void;
  handleThreadReplyInput(routeKey: string, value: string): void;
  bindThreadReplyAttachments(
    routeKey: string,
    pubkey: string | null,
  ): (attachments: ComposerAttachment[]) => void;
  handleThreadReplySubmit(routeKey: string, payload: ComposerPayload): void | Promise<void>;
  handleLike(event: RawEvent): void | Promise<void>;
  handleZap(event: RawEvent): void | Promise<void>;
  sendZap(event: RawEvent, profile: ProfileRecord | null, options: ZapRequestOptions): Promise<ZapOutcome>;
  openZapAll(events: RawEvent[]): void;
  handleReplyAction(event: RawEvent): void;
  handleQuoteAction(event: RawEvent): void;
  handleRepost(event: RawEvent): void | Promise<void>;
  openNoteDetailSheet(event: RawEvent, kind: NoteDetailListKind): void | Promise<void>;
  closeDetailSheet(): void;
  loadMoreNoteDetails(kind: NoteDetailListKind): void | Promise<void>;
  setDetailSheetKind(kind: NoteDetailListKind): void;
  copyNoteLink(event: RawEvent): void | Promise<void>;
  copyEventId(event: RawEvent): void | Promise<void>;
  rebroadcast(event: RawEvent): void | Promise<void>;
  handleDelete(event: RawEvent): void | Promise<void>;
  cachePresentedHomeNote(event: RawEvent): void;
  markHomeNoteSeen(event: RawEvent, presentedEvent: RawEvent | null): void;
  handleViewAsProfile(pubkey: string): void | Promise<void>;
  handleToggleFollow(pubkey: string, nextFollowing: boolean): void | Promise<void>;
  handleToggleMute(pubkey: string, nextMuted: boolean): void | Promise<void>;
  handleCopyPubkey(pubkey: string): void | Promise<void>;
  handleCopyNpub(npub: string): void | Promise<void>;
  handleCopyProfileLink(href: string): void | Promise<void>;
  handleOpenWebsite(url: string): void;
  handleSaveProfile(fields: ProfileEdits): void | Promise<void>;
  handleRegisterIrisUsername: RegisterIrisUsernameAction;
  handleOpenMedia(payload: MediaOpenPayload): void;
  handleOpenProfileImage(url: string, label: string): void;
  handleCloseMedia(): void;
  handleMediaIndexChange(index: number): void;
  handleModalOpenProfile(pubkey: string): void;
  handleModalOpenNote(target: string): void;
  setZapAllSheetOpen(open: boolean): void;
  handleZapAllStart(options: ZapAllRunOptions): void | Promise<void>;
};
