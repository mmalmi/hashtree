<script lang="ts">
  import AppHeader from '../AppHeader.svelte';
  import DesktopSidebar from '../DesktopSidebar.svelte';
  import MobileFooter from '../MobileFooter.svelte';
  import { routeKey } from '../../appRoute';
  import { presentedRoute } from '../../appRoutePresentation';
  import { getProfileTitle } from '../../nostr';
  import { sharedProfilesStore } from '../../profileCache';
  import { recentProfilesStore } from '../../recentProfiles';
  import { HOME_HREF, notificationsHref } from '../../routes';
  import { getHeaderTitle } from '../app-projection/identityProjection';
  import AppOverlays from './AppOverlays.svelte';
  import AppRouteStack from './AppRouteStack.svelte';
  import type { AppShellActions, AppShellStateProps, AppShellView } from './types';

  export let routeState: AppShellStateProps['routeState'];
  export let homeState: AppShellStateProps['homeState'];
  export let threadState: AppShellStateProps['threadState'];
  export let searchState: AppShellStateProps['searchState'];
  export let accountState: AppShellStateProps['accountState'];
  export let viewerState: AppShellStateProps['viewerState'];
  export let engagementState: AppShellStateProps['engagementState'];
  export let notificationState: AppShellStateProps['notificationState'];
  export let mediaState: AppShellStateProps['mediaState'];
  export let runtimeState: AppShellStateProps['runtimeState'];
  export let view: AppShellView;
  export let actions: AppShellActions;

  let searchDropdownRoot: HTMLDivElement | null = searchState.searchDropdownRoot;
  let reportedSearchDropdownRoot = searchDropdownRoot;
  $: shellRoute = $presentedRoute ?? $routeState.route;
  $: recentProfilesStore.setViewer($accountState.activeAccount?.pubkey ?? null);
  $: shellEntry = $routeState.mountedRenderEntries.find(
    (entry) => entry.key === routeKey(shellRoute),
  ) ?? null;
  $: shellProfile = shellRoute.kind === 'profile' && shellRoute.pubkey
    ? $sharedProfilesStore.get(shellRoute.pubkey)
      ?? shellEntry?.cache.profilePage?.profile
      ?? null
    : null;
  $: shellThreadAuthor = shellEntry?.cache.threadPage?.note?.pubkey ?? null;
  $: shellHeaderTitle = routeKey(shellRoute) === routeKey($routeState.route)
    ? view.headerTitle
    : getHeaderTitle(
        shellRoute,
        shellRoute.kind === 'profile'
          ? getProfileTitle(shellProfile, shellRoute.pubkey ?? shellRoute.npub)
          : '',
        shellThreadAuthor
          ? getProfileTitle(
              $sharedProfilesStore.get(shellThreadAuthor)
                ?? shellEntry?.cache.profiles.get(shellThreadAuthor)
                ?? null,
              shellThreadAuthor,
            )
          : '',
      );

  $: if (searchDropdownRoot !== reportedSearchDropdownRoot) {
    reportedSearchDropdownRoot = searchDropdownRoot;
    actions.setSearchDropdownRoot(searchDropdownRoot);
  }
</script>

<svelte:head>
  <title>{view.documentTitle}</title>
</svelte:head>

<svelte:window
  on:storage={(event) => recentProfilesStore.refresh(event.key)}
  on:click={actions.handleWindowChromeClick}
  on:keydown={actions.handleWindowChromeKeydown}
/>

<div
  data-testid="page-scroll"
  data-app-page-scroll
  data-scrollable
  data-route-key={routeKey(shellRoute)}
  data-route-kind={shellRoute.kind}
  tabindex="-1"
  class="iris-page-scroll h-[100dvh] overflow-y-auto overflow-x-hidden overscroll-y-contain bg-[#000000] text-white"
>
  <div
    data-testid="desktop-layout-shell"
    class="min-h-full w-full md:mx-auto md:flex md:items-start md:max-w-[47rem] xl:max-w-[62rem]"
  >
    <DesktopSidebar
      route={shellRoute}
      activeAccount={$accountState.activeAccount}
      activeProfile={view.activeProfile}
      onCompose={actions.navigateCompose}
      onOpenProfile={actions.navigateActiveProfile}
      onOpenAccounts={actions.navigateAccounts}
    />

    <div class="min-w-0 w-full md:flex-1">
      <main
        data-testid="desktop-main-column"
        class="min-h-[100dvh] w-full border-white/5 bg-black md:max-w-[42rem] md:border-r xl:max-w-[46rem]"
      >
        <AppHeader
          homeHref={HOME_HREF}
          notificationsHref={notificationsHref()}
          routeTitle={shellHeaderTitle}
          routeIdentity={routeKey(shellRoute)}
          homeRoute={shellRoute.kind === 'home'}
          notificationsActive={shellRoute.kind === 'notifications'}
          showBack={shellRoute.kind !== 'home'}
          showDesktopSearch={shellRoute.kind !== 'search' && shellRoute.kind !== 'profile'}
          profileHeader={shellRoute.kind === 'profile'}
          searchSheetOpen={$searchState.searchSheetOpen}
          searchQuery={$searchState.searchQuery}
          searchableProfiles={view.searchableProfiles}
          searchRemoteProfiles={$searchState.searchRemoteProfiles}
          searchLoading={$searchState.searchLoading}
          mutedPubkeys={$viewerState.viewerMutedPubkeys}
          viewerPubkey={$accountState.activeAccount?.pubkey ?? null}
          rootError={$runtimeState.rootError}
          pageError={$routeState.pageError}
          bind:searchDropdownRoot
          onHomeClick={actions.handleHomeLinkClick}
          onHeaderClick={actions.scrollPageToTopInstant}
          onBack={actions.navigateBack}
          onOpenSearch={actions.openSearchSheet}
          onQueryChange={actions.handleSearchQueryChange}
          onOpenProfile={actions.handleSearchOpenProfile}
          onOpenPostSearch={actions.handleHeaderSearchPosts}
          onOpenThread={actions.handleSearchOpenThread}
        />

        <AppRouteStack
          routeState={$routeState}
          homeState={$homeState}
          threadState={$threadState}
          searchState={$searchState}
          accountState={$accountState}
          viewerState={$viewerState}
          engagementState={$engagementState}
          notificationState={$notificationState}
          mediaState={$mediaState}
          {view}
          {actions}
        />
      </main>
    </div>
  </div>

  <MobileFooter
    route={shellRoute}
    activeAccount={$accountState.activeAccount}
    activeProfile={view.activeProfile}
    onCompose={actions.navigateCompose}
    onOpenProfile={actions.navigateActiveProfile}
    onOpenAccounts={actions.navigateAccounts}
  />

  <AppOverlays
    activeHomeTab={shellRoute.kind === 'home' ? shellRoute.tab : 'latest'}
    homeState={$homeState}
    accountState={$accountState}
    engagementState={$engagementState}
    mediaState={$mediaState}
    {view}
    {actions}
  />
</div>
