<script lang="ts">
  import { tick } from 'svelte';
  import AppHeader from '../AppHeader.svelte';
  import DesktopSidebar from '../DesktopSidebar.svelte';
  import IrisIcon from '../IrisIcon.svelte';
  import LazyOverlay from '../LazyOverlay.svelte';
  import MobileFooter from '../MobileFooter.svelte';
  import ModalShell from '../ModalShell.svelte';
  import { routeKey } from '../../appRoute';
  import { presentedRoute } from '../../appRoutePresentation';
  import { getProfileTitle } from '../../nostr';
  import { loadAccountSheetModule } from '../../lazyRouteComponents';
  import { sharedProfilesStore } from '../../profileCache';
  import { recentProfilesStore } from '../../recentProfiles';
  import { HOME_HREF, notificationsHref } from '../../routes';
  import { getHeaderTitle } from '../app-projection/identityProjection';
  import AppOverlays from './AppOverlays.svelte';
  import AppRouteStack from './AppRouteStack.svelte';
  import type { AccountAccessMode, AppShellActions, AppShellStateProps, AppShellView } from './types';

  export let routeState: AppShellStateProps['routeState'];
  export let homeState: AppShellStateProps['homeState'];
  export let threadState: AppShellStateProps['threadState'];
  export let searchState: AppShellStateProps['searchState'];
  export let accountState: AppShellStateProps['accountState'];
  export let viewerState: AppShellStateProps['viewerState'];
  export let engagementState: AppShellStateProps['engagementState'];
  export let notificationState: AppShellStateProps['notificationState'];
  export let mediaState: AppShellStateProps['mediaState'];
  export let runtimeState: AppShellStateProps['runtimeState'];
  export let view: AppShellView;
  export let actions: AppShellActions;

  let searchDropdownRoot: HTMLDivElement | null = searchState.searchDropdownRoot;
  let reportedSearchDropdownRoot = searchDropdownRoot;
  let guestAccountMode: AccountAccessMode | null = null;
  let guestAccountOpener: HTMLElement | null = null;

  function openGuestAccount(mode: AccountAccessMode): void {
    guestAccountOpener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    actions.handleAccountInput('', false, guestAccessOptions);
    guestAccountMode = mode;
  }

  function closeGuestAccount(): void {
    const opener = guestAccountOpener;
    guestAccountMode = null;
    guestAccountOpener = null;
    actions.handleAccountInput('', false, guestAccessOptions);
    void tick().then(() => {
      if (opener?.isConnected) opener.focus({ preventScroll: true });
    });
  }

  $: if ($accountState.activeAccount && guestAccountMode) closeGuestAccount();
  $: shellRoute = $presentedRoute ?? $routeState.route;
  $: if (shellRoute.kind !== 'home' && $homeState.feedSourceSheetOpen) {
    actions.setFeedSourceSheetOpen(false);
  }
  $: guestAccessOptions = { preserveRoute: shellRoute.kind !== 'home' };
  $: recentProfilesStore.setViewer($accountState.activeAccount?.pubkey ?? null);
  $: shellEntry = $routeState.mountedRenderEntries.find(
    (entry) => entry.key === routeKey(shellRoute),
  ) ?? null;
  $: shellProfile = shellRoute.kind === 'profile' && shellRoute.pubkey
    ? $sharedProfilesStore.get(shellRoute.pubkey)
      ?? shellEntry?.cache.profilePage?.profile
      ?? null
    : null;
  $: shellThreadAuthor = shellEntry?.cache.threadPage?.note?.pubkey ?? null;
  $: shellHeaderTitle = routeKey(shellRoute) === routeKey($routeState.route)
    ? view.headerTitle
    : getHeaderTitle(
        shellRoute,
        shellRoute.kind === 'profile'
          ? getProfileTitle(shellProfile, shellRoute.pubkey ?? shellRoute.npub)
          : '',
        shellThreadAuthor
          ? getProfileTitle(
              $sharedProfilesStore.get(shellThreadAuthor)
                ?? shellEntry?.cache.profiles.get(shellThreadAuthor)
                ?? null,
              shellThreadAuthor,
            )
          : '',
      );

  $: if (searchDropdownRoot !== reportedSearchDropdownRoot) {
    reportedSearchDropdownRoot = searchDropdownRoot;
    actions.setSearchDropdownRoot(searchDropdownRoot);
  }
</script>

<svelte:head>
  <title>{view.documentTitle}</title>
</svelte:head>

<svelte:window
  on:storage={(event) => recentProfilesStore.refresh(event.key)}
  on:click={actions.handleWindowChromeClick}
  on:keydown={actions.handleWindowChromeKeydown}
/>

<div
  data-testid="page-scroll"
  data-app-page-scroll
  data-scrollable
  data-route-key={routeKey(shellRoute)}
  data-route-kind={shellRoute.kind}
  tabindex="-1"
  class="iris-page-scroll h-[100dvh] overflow-y-auto overflow-x-hidden overscroll-y-contain bg-[#000000] text-white"
>
  <div
    data-testid="desktop-layout-shell"
    inert={guestAccountMode !== null || $accountState.postComposer !== null || undefined}
    class="min-h-full w-full md:mx-auto md:flex md:items-start md:max-w-[56rem] lg:max-w-[64rem] xl:max-w-[76rem]"
  >
    <DesktopSidebar
      route={shellRoute}
      activeAccount={$accountState.activeAccount}
      activeProfile={view.activeProfile}
      onCompose={actions.openPostComposer}
      onOpenProfile={actions.navigateActiveProfile}
      onOpenAccounts={actions.navigateAccounts}
      onOpenAccount={openGuestAccount}
    />

    <div class="min-w-0 w-full md:flex-1">
      <main
        data-testid="desktop-main-column"
        class="min-h-[100dvh] w-full border-divider bg-black md:border-r xl:max-w-[60rem]"
      >
        <AppHeader
          homeHref={HOME_HREF}
          notificationsHref={notificationsHref()}
          routeTitle={shellHeaderTitle}
          routeIdentity={routeKey(shellRoute)}
          homeRoute={shellRoute.kind === 'home'}
          notificationsActive={shellRoute.kind === 'notifications'}
          showBack={shellRoute.kind !== 'home'}
          showDesktopSearch={shellRoute.kind !== 'search' && shellRoute.kind !== 'profile'}
          profileHeader={shellRoute.kind === 'profile'}
          searchSheetOpen={$searchState.searchSheetOpen}
          searchQuery={$searchState.searchQuery}
          searchableProfiles={view.searchableProfiles}
          searchRemoteProfiles={$searchState.searchRemoteProfiles}
          searchLoading={$searchState.searchLoading}
          mutedPubkeys={$viewerState.viewerMutedPubkeys}
          hiddenPubkeys={$viewerState.viewerHiddenPubkeys}
          viewerPubkey={$accountState.activeAccount?.pubkey ?? null}
          rootError={shellRoute.kind === 'search' ? '' : $runtimeState.rootError}
          pageError={$routeState.pageError}
          bind:searchDropdownRoot
          onHomeClick={actions.handleHomeLinkClick}
          onHeaderClick={actions.scrollPageToTopInstant}
          onBack={actions.navigateBack}
          onOpenSearch={actions.openSearchSheet}
          onQueryChange={actions.handleSearchQueryChange}
          onOpenProfile={actions.handleSearchOpenProfile}
          onOpenPostSearch={actions.handleHeaderSearchPosts}
          onOpenThread={actions.handleSearchOpenThread}
          onOpenAccount={shellRoute.kind === 'accounts' ? null : openGuestAccount}
        />

        <AppRouteStack
          routeState={$routeState}
          homeState={$homeState}
          threadState={$threadState}
          searchState={$searchState}
          accountState={$accountState}
          viewerState={$viewerState}
          engagementState={$engagementState}
          notificationState={$notificationState}
          mediaState={$mediaState}
          {view}
          {actions}
        />
      </main>
    </div>
  </div>

  <div inert={guestAccountMode !== null || $accountState.postComposer !== null || undefined}>
    <MobileFooter
      route={shellRoute}
      activeAccount={$accountState.activeAccount}
      activeProfile={view.activeProfile}
      onCompose={actions.openPostComposer}
      onOpenProfile={actions.navigateActiveProfile}
      onOpenAccounts={actions.navigateAccounts}
    />
  </div>

  {#if guestAccountMode}
    <LazyOverlay open title="Iris profile" load={loadAccountSheetModule} onClose={closeGuestAccount} let:component>
      <ModalShell open onClose={closeGuestAccount} contentClass="w-full max-w-[25rem]">
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Iris profile"
          class="max-h-[calc(100dvh-2rem)] overflow-y-auto rounded-2xl iris-panel"
        >
          <div class="flex justify-end px-3 pt-2">
            <button type="button" aria-label="Close" class="grid h-10 w-10 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]" on:click={closeGuestAccount}>
              <IrisIcon name="x-close" size={20} />
            </button>
          </div>
          <svelte:component
            this={component}
            initialMode={guestAccountMode}
            accounts={view.accounts}
            activePubkey={null}
            remoteProfiles={$accountState.accountProfiles}
            accountInput={$accountState.accountInput}
            importError={$accountState.accountImportError}
            onCreateAccount={(name) => actions.handleCreateAccount({ name, ...guestAccessOptions })}
            onImportAccount={() => void actions.handleImportAccount(true, guestAccessOptions)}
            onRemoteLogin={(signal) => actions.handleRemoteLogin(signal, guestAccessOptions)}
            onExtensionLogin={(signal) => actions.handleExtensionLogin({ signal, ...guestAccessOptions })}
            onAccountInput={(value, pasted) => actions.handleAccountInput(value, pasted, guestAccessOptions)}
            onSwitchAccount={(pubkey) => void actions.handleSwitchAccount(pubkey, guestAccessOptions)}
            onRemoveAccount={actions.handleRemoveAccount}
          />
        </div>
      </ModalShell>
    </LazyOverlay>
  {/if}

  <AppOverlays
    viewerFollows={$viewerState.viewerFollows}
    hiddenPubkeys={$viewerState.viewerHiddenPubkeys}
    accountState={$accountState}
    engagementState={$engagementState}
    mediaState={$mediaState}
    {view}
    {actions}
  />
</div>
