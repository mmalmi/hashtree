<script lang="ts">
  import type { HomeTab } from '../../routes';
  import { createRetryableDynamicImport } from '../../retryableDynamicImport';
  import LazyOverlay from '../LazyOverlay.svelte';
  import MediaModal from '../MediaModal.svelte';
  import type {
    AccountStateSnapshot,
    AppShellActions,
    AppShellView,
    EngagementStateSnapshot,
    HomeStateSnapshot,
    MediaStateSnapshot,
  } from './types';

  export let activeHomeTab: HomeTab = 'latest';
  export let homeState: HomeStateSnapshot;
  export let accountState: AccountStateSnapshot;
  export let engagementState: EngagementStateSnapshot;
  export let mediaState: MediaStateSnapshot;
  export let view: AppShellView;
  export let actions: AppShellActions;

  const loadNoteDetails = createRetryableDynamicImport(() => import('../NoteDetailSheet.svelte'));
  const loadZapAll = createRetryableDynamicImport(() => import('../ZapAllSheet.svelte'));
  const loadFeedSources = createRetryableDynamicImport(() => import('../FeedSourceEditorSheet.svelte'));

  function closeZapAll(): void {
    if (!engagementState.zapAllRunning) {
      actions.setZapAllSheetOpen(false);
    }
  }
</script>

<LazyOverlay open={engagementState.detailSheetOpen} title={engagementState.detailSheetTitle || 'Reactions'} load={loadNoteDetails} onClose={actions.closeDetailSheet} let:component>
  <svelte:component this={component}
    open={engagementState.detailSheetOpen}
    kind={engagementState.detailSheetKind}
    title={engagementState.detailSheetTitle}
    targetPubkey={engagementState.detailSheetTargetPubkey}
    targetProfile={engagementState.detailSheetTargetPubkey === accountState.activeAccount?.pubkey
      ? view.activeProfile ?? view.activeAccountFallbackProfile
      : accountState.accountProfiles.get(engagementState.detailSheetTargetPubkey) ?? null}
    eventsByKind={engagementState.detailSheetEventsByKind}
    hasMoreByKind={engagementState.detailSheetHasMoreByKind}
    profiles={engagementState.detailSheetProfiles}
    loading={engagementState.detailSheetLoading}
    onClose={actions.closeDetailSheet}
    onSelectKind={actions.setDetailSheetKind}
    onLoadMore={() => void actions.loadMoreNoteDetails(engagementState.detailSheetKind)}
    onOpenProfile={actions.navigateProfile}
  />
</LazyOverlay>

<LazyOverlay open={engagementState.zapAllSheetOpen} title="Zap all" load={loadZapAll} onClose={closeZapAll} let:component>
  <svelte:component this={component}
    open={engagementState.zapAllSheetOpen}
    eventCount={engagementState.zapAllEvents.length}
    running={engagementState.zapAllRunning}
    completed={engagementState.zapAllCompleted}
    progress={engagementState.zapAllProgress}
    spentBits={engagementState.zapAllSpentBits}
    error={engagementState.zapAllError}
    logs={engagementState.zapAllLogs}
    canRun={view.canActiveAccountPublish}
    onClose={closeZapAll}
    onStart={(options) => void actions.handleZapAllStart(options)}
  />
</LazyOverlay>

<!-- Already displayed media must open without fetching another app chunk. -->
{#if mediaState.mediaModalOpen}
  <MediaModal
    open={mediaState.mediaModalOpen}
    items={mediaState.mediaSelection?.embeds ?? []}
    index={mediaState.mediaSelection?.index ?? 0}
    sourceEvent={mediaState.mediaSelection?.event ?? null}
    sourceProfile={mediaState.mediaSelection?.profile ?? null}
    onClose={actions.handleCloseMedia}
    onIndexChange={actions.handleMediaIndexChange}
    onOpenProfile={actions.handleModalOpenProfile}
    onOpenNote={actions.handleModalOpenNote}
  />
{/if}

<LazyOverlay open={homeState.feedSourceSheetOpen} title="Feed settings" load={loadFeedSources} onClose={() => actions.setFeedSourceSheetOpen(false)} let:component>
  <svelte:component this={component}
    open={homeState.feedSourceSheetOpen}
    sources={homeState.feedSources}
    sourceName={homeState.feedSourceName}
    sourceIdentity={homeState.feedSourceIdentity}
    sourceError={homeState.feedSourceError}
    activeSourceId={homeState.activeFeedSourceId}
    viewerPubkey={accountState.activeAccount?.pubkey ?? null}
    activeTab={activeHomeTab}
    onClose={() => actions.setFeedSourceSheetOpen(false)}
    onSourceNameChange={actions.handleFeedSourceNameChange}
    onSourceIdentityChange={actions.handleFeedSourceIdentityChange}
    onAddSource={actions.addFeedSource}
    onSelectDefault={() => actions.selectFeedSource(null)}
    onSelectSource={actions.selectFeedSource}
    onRemoveSource={actions.removeFeedSource}
  />
</LazyOverlay>
