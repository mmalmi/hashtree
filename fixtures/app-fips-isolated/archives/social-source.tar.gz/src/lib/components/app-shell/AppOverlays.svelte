<script lang="ts">
  import { createRetryableDynamicImport } from '../../retryableDynamicImport';
  import LazyOverlay from '../LazyOverlay.svelte';
  import MediaModal from '../MediaModal.svelte';
  import { closeZapDialog, zapDialogRequest } from '../../zapDialog';
  import type {
    AccountStateSnapshot,
    AppShellActions,
    AppShellView,
    EngagementStateSnapshot,
    MediaStateSnapshot,
  } from './types';

  export let viewerFollows: ReadonlySet<string>;
  export let hiddenPubkeys: ReadonlySet<string> = new Set();
  export let accountState: AccountStateSnapshot;
  export let engagementState: EngagementStateSnapshot;
  export let mediaState: MediaStateSnapshot;
  export let view: AppShellView;
  export let actions: AppShellActions;

  const loadNoteDetails = createRetryableDynamicImport(() => import('../NoteDetailSheet.svelte'));
  const loadZapAll = createRetryableDynamicImport(() => import('../ZapAllSheet.svelte'));
  const loadZapDialog = createRetryableDynamicImport(() => import('../ZapDialog.svelte'));
  const loadPostComposer = createRetryableDynamicImport(() => import('../PostComposerDialog.svelte'));

  // A zap is signed by the account that opened the dialog.
  let zapDialogAccount = accountState.activeAccount?.pubkey ?? null;
  $: if ((accountState.activeAccount?.pubkey ?? null) !== zapDialogAccount) {
    zapDialogAccount = accountState.activeAccount?.pubkey ?? null;
    closeZapDialog();
  }

  function closeZapAll(): void {
    if (!engagementState.zapAllRunning) {
      actions.setZapAllSheetOpen(false);
    }
  }
</script>

{#if accountState.activeAccount}
  {#key accountState.activeAccount.pubkey}
    <LazyOverlay open={accountState.postComposer !== null} title="New post" load={loadPostComposer} onClose={actions.closePostComposer} let:component>
      <svelte:component this={component}
        open={accountState.postComposer !== null}
        returnFocusTo={accountState.postComposer?.returnFocusTo ?? null}
        pubkey={accountState.activeAccount.pubkey}
        profile={view.activeProfile ?? view.activeAccountFallbackProfile}
        value={accountState.composerValue}
        disabled={!view.canActiveAccountPublish}
        error={accountState.composerError}
        attachments={accountState.composerAttachments}
        resolveReferencedNote={view.resolveReferencedNote}
        onOpenNote={(target) => { actions.closePostComposer(); actions.navigateThread(target); }}
        onOpenProfile={(pubkey) => { actions.closePostComposer(); actions.navigateProfile(pubkey); }}
        onInput={actions.handleComposerInput}
        onAttachmentsChange={actions.bindComposerAttachments(accountState.activeAccount.pubkey)}
        onSubmit={actions.handleCreatePostSubmit}
        onClose={actions.closePostComposer}
      />
    </LazyOverlay>
  {/key}
{/if}

<LazyOverlay open={engagementState.detailSheetOpen} title={engagementState.detailSheetTitle || 'Reactions'} load={loadNoteDetails} onClose={actions.closeDetailSheet} let:component>
  <svelte:component this={component}
    open={engagementState.detailSheetOpen}
    kind={engagementState.detailSheetKind}
    viewerPubkey={accountState.activeAccount?.pubkey ?? null}
    {viewerFollows}
    {hiddenPubkeys}
    title={engagementState.detailSheetTitle}
    targetPubkey={engagementState.detailSheetTargetPubkey}
    targetProfile={engagementState.detailSheetTargetPubkey === accountState.activeAccount?.pubkey
      ? view.activeProfile ?? view.activeAccountFallbackProfile
      : accountState.accountProfiles.get(engagementState.detailSheetTargetPubkey) ?? null}
    eventsByKind={engagementState.detailSheetEventsByKind}
    hasMoreByKind={engagementState.detailSheetHasMoreByKind}
    profiles={engagementState.detailSheetProfiles}
    loading={engagementState.detailSheetLoading}
    onClose={actions.closeDetailSheet}
    onSelectKind={actions.setDetailSheetKind}
    onLoadMore={() => void actions.loadMoreNoteDetails(engagementState.detailSheetKind)}
    onOpenProfile={actions.navigateProfile}
  />
</LazyOverlay>

<LazyOverlay open={engagementState.zapAllSheetOpen} title="Zap all" load={loadZapAll} onClose={closeZapAll} let:component>
  <svelte:component this={component}
    open={engagementState.zapAllSheetOpen}
    eventCount={engagementState.zapAllEvents.length}
    running={engagementState.zapAllRunning}
    completed={engagementState.zapAllCompleted}
    progress={engagementState.zapAllProgress}
    spentBits={engagementState.zapAllSpentBits}
    error={engagementState.zapAllError}
    logs={engagementState.zapAllLogs}
    canRun={view.canActiveAccountPublish}
    onClose={closeZapAll}
    onStart={(options) => void actions.handleZapAllStart(options)}
  />
</LazyOverlay>

<LazyOverlay open={$zapDialogRequest !== null} title="Zap" load={loadZapDialog} onClose={closeZapDialog} let:component>
  {#if $zapDialogRequest}
    {@const request = $zapDialogRequest}
    {#key request}
      <svelte:component this={component}
        open
        {request}
        canZap={view.canActiveAccountPublish}
        onClose={closeZapDialog}
        onZap={(options) => actions.sendZap(request.event, request.profile, options)}
      />
    {/key}
  {/if}
</LazyOverlay>

<!-- Already displayed media must open without fetching another app chunk. -->
{#if mediaState.mediaModalOpen}
  <MediaModal
    open={mediaState.mediaModalOpen}
    items={mediaState.mediaSelection?.embeds ?? []}
    index={mediaState.mediaSelection?.index ?? 0}
    sourceEvent={mediaState.mediaSelection?.event ?? null}
    sourceProfile={mediaState.mediaSelection?.profile ?? null}
    onClose={actions.handleCloseMedia}
    onIndexChange={actions.handleMediaIndexChange}
    onOpenProfile={actions.handleModalOpenProfile}
    onOpenNote={actions.handleModalOpenNote}
  />
{/if}
