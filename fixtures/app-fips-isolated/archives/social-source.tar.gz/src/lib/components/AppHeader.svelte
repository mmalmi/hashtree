<script lang="ts">
  import { onMount, tick } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import HeaderSearchDropdown from './HeaderSearchDropdown.svelte';
  import type { ProfileRecord } from '../nostr';
  import { getActiveAppScrollElement, getAppScrollOffset } from '../appScroll';

  export let homeHref = '#/';
  export let notificationsHref = '#/notifications';
  export let routeTitle = 'Home';
  export let routeIdentity = 'home:latest';
  export let homeRoute = true;
  export let notificationsActive = false;
  export let showBack = false;
  export let showDesktopSearch = true;
  export let profileHeader = false;
  export let searchSheetOpen = false;
  export let searchQuery = '';
  export let searchableProfiles: Map<string, ProfileRecord> = new Map();
  export let searchRemoteProfiles: ProfileRecord[] = [];
  export let searchLoading = false;
  export let mutedPubkeys: Set<string> = new Set();
  export let viewerPubkey: string | null = null;
  export let rootError = '';
  export let pageError = '';
  export let searchDropdownRoot: HTMLDivElement | null = null;
  export let onHomeClick: (event: MouseEvent) => void = () => undefined;
  export let onHeaderClick: () => void = () => undefined;
  export let onBack: () => void = () => undefined;
  export let onOpenSearch: () => void = () => undefined;
  export let onQueryChange: (value: string) => void = () => undefined;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenPostSearch: ((query: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  let mobileOffset = 0;
  let mobileAtTop = true;
  let lastScrollY = 0;
  let lastRouteIdentity = routeIdentity;

  $: homeBrandVisible = homeRoute && mobileAtTop && mobileOffset === 0;
  $: mobileContentOpacity = Math.max(0, 1 - Math.abs(mobileOffset) / 30);
  $: if (routeIdentity !== lastRouteIdentity) {
    lastRouteIdentity = routeIdentity;
    mobileOffset = 0;
    void tick().then(() => {
      lastScrollY = getAppScrollOffset();
      mobileAtTop = lastScrollY <= 10;
    });
  }

  onMount(() => {
    function resetMobileHeader(): void {
      mobileOffset = 0;
      lastScrollY = getAppScrollOffset();
      mobileAtTop = lastScrollY <= 10;
    }

    function handleScroll(event: Event): void {
      if (window.innerWidth >= 768 || event.target !== getActiveAppScrollElement()) {
        return;
      }

      const nextScrollY = getAppScrollOffset();
      const delta = nextScrollY - lastScrollY;
      if (nextScrollY <= 10) {
        mobileOffset = 0;
      } else if (delta > 0) {
        mobileOffset = Math.max(-72, mobileOffset - delta);
      } else if (delta < 0) {
        mobileOffset = Math.min(0, mobileOffset - delta);
      }
      mobileAtTop = nextScrollY <= 10;
      lastScrollY = nextScrollY;
    }

    document.addEventListener('scroll', handleScroll, { capture: true, passive: true });
    window.addEventListener('resize', resetMobileHeader);
    resetMobileHeader();

    return () => {
      document.removeEventListener('scroll', handleScroll, true);
      window.removeEventListener('resize', resetMobileHeader);
    };
  });

  function preventMouseFocusShift(event: MouseEvent): void {
    event.preventDefault();
  }

  function handleProfileTitleKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Enter' && event.key !== ' ') {
      return;
    }
    event.preventDefault();
    onHeaderClick();
  }

</script>

<header
  data-testid="app-header"
  class={`fixed inset-x-0 top-0 z-30 border-b border-white/5 bg-[rgba(0,0,0,0.88)] px-2 pt-[env(safe-area-inset-top)] backdrop-blur-sm will-change-transform md:sticky md:px-3 md:pt-0 ${profileHeader ? 'cursor-pointer select-none' : ''}`}
  style={`transform: translateY(${mobileOffset}px)`}
>
  <div
    class="relative flex min-h-16 items-center gap-2 py-2"
    style={`opacity: ${mobileContentOpacity}`}
  >
    {#if profileHeader}
      <button
        data-testid="header-profile-scroll-top"
        type="button"
        class="absolute inset-0 z-0 cursor-pointer bg-transparent"
        aria-label="Scroll profile to top"
        on:click={onHeaderClick}
      ></button>
    {/if}

    <div class="pointer-events-none relative z-10 flex min-w-0 flex-1 items-center md:w-[13rem] md:flex-none">
      {#if showBack}
        <button
          data-testid="header-back-button"
          type="button"
          class="pointer-events-auto grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-transparent text-white/80 transition hover:bg-white/[0.07] hover:text-white"
          aria-label="Back"
          on:click={onBack}
        >
          <IrisIcon name="arrowBack" size={22} />
        </button>
      {/if}

      {#if profileHeader}
        <div
          data-testid="header-profile-title"
          class="pointer-events-auto flex min-w-0 shrink-0 cursor-pointer items-center bg-transparent px-2 py-1 text-left md:w-full"
          role="button"
          tabindex="0"
          on:click={onHeaderClick}
          on:keydown={handleProfileTitleKeydown}
        >
          <span class="truncate text-2xl font-600 leading-tight text-[rgb(var(--iris-text-rgb))]">
            {routeTitle}
          </span>
        </div>
      {:else}
        <a
          data-testid="header-home-link"
          data-primary-navigation-item="home"
          href={homeHref}
          class="pointer-events-auto flex min-w-0 shrink-0 items-center gap-2 bg-transparent px-2 py-1 text-left text-white no-underline md:w-full"
          aria-label="Go to latest feed"
          on:mousedown={preventMouseFocusShift}
          on:click={onHomeClick}
        >
          <img src="/favicon.svg" alt="" class={`h-7 w-7 md:hidden ${showBack ? 'hidden' : ''}`} />
          {#if homeRoute}
            <span
              data-header-logo
              class="truncate text-3xl font-700 text-[rgb(var(--iris-text-rgb))] transition-opacity duration-200 md:hidden"
              style={`opacity: ${homeBrandVisible ? 1 : 0}`}
            >iris</span>
          {:else}
            <span class="truncate text-2xl font-600 leading-tight text-[rgb(var(--iris-text-rgb))] md:hidden">{routeTitle}</span>
          {/if}
          <span class="hidden truncate text-2xl font-600 leading-tight text-[rgb(var(--iris-text-rgb))] md:block">
            {routeTitle}
          </span>
        </a>
      {/if}

      {#if homeRoute}
        <div
          data-testid="mobile-feed-title"
          data-header-feed-name
          class="pointer-events-none absolute inset-0 flex items-center text-2xl font-600 leading-tight text-[rgb(var(--iris-text-rgb))] transition-opacity duration-200 md:hidden"
          style={`padding-left: 3.25rem; opacity: ${homeBrandVisible ? 0 : 1}`}
        >
          <span class="truncate">{routeTitle}</span>
        </div>
      {/if}
    </div>

    {#if showDesktopSearch}
      <div class="pointer-events-auto relative z-10 hidden min-w-0 flex-1 md:block">
        <HeaderSearchDropdown
          bind:root={searchDropdownRoot}
          open={searchSheetOpen}
          query={searchQuery}
          profilesByPubkey={searchableProfiles}
          profileRecords={searchRemoteProfiles}
          loading={searchLoading}
          {mutedPubkeys}
          {viewerPubkey}
          onOpen={onOpenSearch}
          onQueryChange={onQueryChange}
          onOpenProfile={onOpenProfile}
          onOpenPosts={onOpenPostSearch}
          onOpenThread={onOpenThread}
        />
      </div>
    {/if}

    <a
      data-testid="header-notifications-link"
      data-primary-navigation-item="notifications"
      href={notificationsHref}
      class={`pointer-events-auto relative z-10 grid h-10 w-10 shrink-0 place-items-center rounded-full no-underline transition md:hidden ${
        notificationsActive ? 'bg-[var(--iris-surface-raised)] text-[rgb(var(--iris-text-rgb))]' : 'text-[rgb(var(--iris-text-rgb)/0.7)] hover:bg-[var(--iris-surface-hover)] hover:text-[rgb(var(--iris-text-rgb))]'
      }`}
      aria-label="Notifications"
      aria-current={notificationsActive ? 'page' : undefined}
    >
      <IrisIcon name={notificationsActive ? 'bell-solid' : 'bell-outline'} size={24} />
    </a>

  </div>

  {#if rootError}
    <div
      data-testid="root-error"
      class="mb-2 rounded-[14px] bg-[rgba(239,68,68,0.12)] px-4 py-3 text-[0.9rem] text-[#ffd4d4]"
    >
      {rootError}
    </div>
  {/if}

  {#if pageError}
    <div class="mb-2 rounded-[14px] bg-[rgba(239,68,68,0.12)] px-4 py-3 text-[0.9rem] text-[#ffd4d4]">
      {pageError}
    </div>
  {/if}
</header>
