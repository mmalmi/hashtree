<script lang="ts">
  import type { Action } from 'svelte/action';
  import UserRow from './UserRow.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { type ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';

  export let pubkeys: string[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let emptyText = 'No one yet.';
  export let activePubkey: string | null = null;
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement> | null = null;
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onSelectProfile: ((pubkey: string) => void) | null = null;
</script>

{#if pubkeys.length > 0}
  <div data-testid="people-list" class="grid gap-0">
    {#each pubkeys as pubkey (pubkey)}
      <div
        data-testid="people-list-row"
        data-active={activePubkey === pubkey ? 'true' : 'false'}
        class={`flex min-w-0 items-center border-b border-white/5 transition ${activePubkey === pubkey ? 'bg-violet-500/20' : 'hover:bg-white/5'}`}
      >
        <a
          data-testid="people-row"
          data-active={activePubkey === pubkey ? 'true' : 'false'}
          href={profileHref(pubkey)}
          class="min-w-0 flex-1 px-4 py-4 text-left sm:px-5"
          on:click={() => onSelectProfile?.(pubkey)}
          on:auxclick={(event) => { if (event.button === 1) onSelectProfile?.(pubkey); }}
        >
          <UserRow
            {pubkey}
            profile={profiles.get(pubkey) ?? null}
            {profiles}
            {viewerPubkey}
            following={viewerFollows.has(pubkey)}
            followPending={followPendingPubkeys.has(pubkey)}
            {onToggleFollow}
            avatarSize={48}
            onOpenProfile={null}
            {onSelectProfile}
            titleClass="truncate text-[1rem] font-700 text-white"
            subtitleClass="mt-1 truncate text-[0.84rem] text-white/60"
          >
            <span
              slot="end"
              aria-hidden="true"
              class:hidden={Boolean(viewerPubkey && viewerPubkey !== pubkey && onToggleFollow)}
              class="text-white/40"
            ><IrisIcon name="arrowFront" size={16} /></span>
          </UserRow>
        </a>

        {#if viewerPubkey && viewerPubkey !== pubkey && onToggleFollow}
          <button
            data-testid="people-follow-button"
            type="button"
            class="mr-4 shrink-0 rounded-full border border-white/8 bg-[#111111] px-3.5 py-2 text-[0.82rem] font-700 text-white transition hover:bg-[#1a1a1a] disabled:cursor-wait disabled:opacity-55 sm:mr-5"
            aria-label={`${viewerFollows.has(pubkey) ? 'Unfollow' : 'Follow'} user`}
            disabled={followPendingPubkeys.has(pubkey)}
            on:click={() => onToggleFollow?.(pubkey, !viewerFollows.has(pubkey))}
          >
            {viewerFollows.has(pubkey) ? 'Unfollow' : 'Follow'}
          </button>
        {/if}
      </div>
    {/each}

    {#if hasMore || loadPending}
      <div class="grid gap-0">
        {#if loadPending}
          <div class="border-b border-white/5 px-4 py-3 text-center text-[0.92rem] text-white/60 sm:px-5">
            Loading more…
          </div>
        {/if}

        {#if infiniteScroll && (hasMore || loadPending)}
          <div use:infiniteScroll aria-hidden="true" class="h-px w-full"></div>
        {/if}
      </div>
    {/if}
  </div>
{:else}
  <div class="border-b border-white/5 px-4 py-6 text-[1rem] leading-7 text-white/60 sm:px-5">
    {emptyText}
  </div>
{/if}
