<script lang="ts">
  import type { ProfileRecord } from '../nostr';
  import { getProfileIdentity, normalizeProfileIdentityText } from '../profileIdentity';
  import IrisIcon from './IrisIcon.svelte';
  import { displayNip05, peekNip05Status, verifyNip05, type Nip05Status } from '../nip05Verification';

  export let profile: ProfileRecord | null = null;
  export let reserveSpace = false;

  $: identity = getProfileIdentity(profile);
  $: website = getWebsite(profile?.website);
  $: hasIdentity = Boolean(identity.nip05 || identity.lightning || website);
  let nip05Status: Nip05Status = null;
  let nip05Key = '';
  $: {
    const key = identity.nip05 && profile?.pubkey ? `${identity.nip05}:${profile.pubkey}` : '';
    if (key !== nip05Key) {
      nip05Key = key;
      nip05Status = key && identity.nip05 && profile?.pubkey ? peekNip05Status(identity.nip05, profile.pubkey) : null;
      if (key && identity.nip05 && profile?.pubkey) {
        void verifyNip05(identity.nip05, profile.pubkey).then((status) => {
          if (nip05Key === key) { nip05Status = status; }
        });
      }
    }
  }

  // Like Iris Client, keep both ends of long addresses visible.
  function middleTruncate(value: string, keep = 15): string {
    return value.length > keep * 2 ? `${value.slice(0, keep)}…${value.slice(-keep)}` : value;
  }

  function getWebsite(value: string | null | undefined): { href: string; label: string } | null {
    const text = normalizeProfileIdentityText(value);
    if (!text) return null;
    try {
      const url = new URL(/^[a-z][a-z\d+.-]*:/i.test(text) ? text : `https://${text}`);
      if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
      return { href: url.href, label: url.href.replace(/^https?:\/\//, '').replace(/\/$/, '') };
    } catch {
      return null;
    }
  }
</script>

{#if hasIdentity || reserveSpace}
<div
  data-testid="profile-identity"
  aria-hidden={hasIdentity ? undefined : 'true'}
  class="mt-2 flex min-h-5 min-w-0 flex-wrap items-center gap-x-4 gap-y-1 text-[0.8rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.6)]"
>
  {#if identity.nip05}
    <span
      data-testid="profile-nip05"
      class="inline-flex min-w-0 max-w-full items-center gap-1.5"
      data-verified={nip05Status === null ? 'unknown' : String(nip05Status)}
      title={nip05Status === false
        ? `Not verified: ${identity.nip05} does not point to this profile`
        : nip05Status === true ? `Verified: ${identity.nip05}` : identity.nip05}
    >
      <IrisIcon
        name="at-sign"
        size={15}
        className={'shrink-0 ' + (nip05Status === false ? 'text-red-400' : nip05Status === true ? 'text-violet-400' : 'opacity-60')}
      />
      <span class={'truncate' + (nip05Status === false ? ' line-through opacity-70' : '')}>{displayNip05(identity.nip05)}</span>
      {#if nip05Status === false}<span class="sr-only">(not verified)</span>{/if}
    </span>
  {/if}

  {#if website}
    <a
      data-testid="profile-website"
      href={website.href}
      target="_blank"
      rel="noopener noreferrer nofollow"
      class="inline-flex min-w-0 max-w-full items-center gap-1.5 hover:underline"
      title={website.href}
    >
      <IrisIcon name="link-02" size={15} className="shrink-0 text-violet-400" />
      <span class="truncate">{middleTruncate(website.label, 20)}</span>
    </a>
  {/if}

  {#if identity.lightning}
    <a
      data-testid="profile-lightning"
      data-source={identity.lightningSource}
      href={`lightning:${identity.lightning}`}
      class="inline-flex min-w-0 max-w-full items-center gap-1.5 hover:underline"
      title={identity.lightning}
    >
      <IrisIcon name="zap-solid" size={15} className="shrink-0 text-amber-400" />
      <span class="truncate">{middleTruncate(identity.lightning)}</span>
    </a>
  {/if}
</div>
{/if}
