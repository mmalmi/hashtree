<script lang="ts">
  import type { ProfileRecord } from '../nostr';
  import { getProfileIdentity } from '../profileIdentity';
  import IrisIcon from './IrisIcon.svelte';

  export let profile: ProfileRecord | null = null;
  export let reserveSpace = false;

  $: identity = getProfileIdentity(profile);
</script>

{#if identity.nip05 || identity.lightning || reserveSpace}
<div
  data-testid="profile-identity"
  aria-hidden={!identity.nip05 && !identity.lightning ? 'true' : undefined}
  class="mt-2 flex h-5 min-w-0 flex-nowrap items-center gap-x-3 overflow-hidden text-[0.8rem] leading-5 text-white/50"
>
  {#if identity.nip05 || identity.lightning}
    {#if identity.nip05}
      <span
        data-testid="profile-nip05"
        class="inline-flex min-w-0 max-w-full shrink items-center gap-1"
        title={identity.nip05}
      >
        <IrisIcon name="at-sign" size={15} className="shrink-0" />
        <span class="truncate">{identity.nip05}</span>
      </span>
    {/if}

    {#if identity.lightning}
      <span
        data-testid="profile-lightning"
        data-source={identity.lightningSource}
        class="inline-flex min-w-0 max-w-full shrink items-center gap-1"
        title={identity.lightning}
      >
        <IrisIcon name="zap" size={15} className="shrink-0" />
        <span class="truncate">{identity.lightning}</span>
      </span>
    {/if}
  {/if}
</div>
{/if}
