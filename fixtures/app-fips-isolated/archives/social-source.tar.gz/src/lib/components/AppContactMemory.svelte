<script lang="ts">
  import { createAppFavoritesFeed, createCustomPeopleFeedSync } from '../appFavoritesFeed';
  import { homeFeedLayoutsStore } from '../homeFeedTabs';
  import type { AppCombinedState } from '../appState';
  import { contactMemoryStore } from '../contactMemoryStore';

  export let appState: AppCombinedState;
  export let viewerPubkey: string | null;
  export let resetHomeFeedPagination: () => void;
  export let restartCurrentViewLoad: () => void;
  const syncFavoritesFeed = createAppFavoritesFeed({
    state: appState, resetHomeFeedPagination, restartCurrentViewLoad,
  });
  $: contactMemoryStore.setViewer(viewerPubkey);
  $: syncFavoritesFeed($contactMemoryStore, viewerPubkey);
  const syncPeopleFeed = createCustomPeopleFeedSync({ state: appState, resetHomeFeedPagination, restartCurrentViewLoad });
  $: syncPeopleFeed($homeFeedLayoutsStore, viewerPubkey);
</script>

<svelte:window on:storage={(event) => contactMemoryStore.refresh(event.key)} />
