<script lang="ts">
  import { createAppFavoritesFeed } from '../appFavoritesFeed';
  import type { AppCombinedState } from '../appState';
  import { contactMemoryStore } from '../contactMemoryStore';

  export let appState: AppCombinedState;
  export let viewerPubkey: string | null;
  export let resetHomeFeedPagination: () => void;
  export let restartCurrentViewLoad: () => void;
  const syncFavoritesFeed = createAppFavoritesFeed({
    state: appState, resetHomeFeedPagination, restartCurrentViewLoad,
  });
  $: contactMemoryStore.setViewer(viewerPubkey);
  $: syncFavoritesFeed($contactMemoryStore, viewerPubkey);
</script>

<svelte:window on:storage={(event) => contactMemoryStore.refresh(event.key)} />
