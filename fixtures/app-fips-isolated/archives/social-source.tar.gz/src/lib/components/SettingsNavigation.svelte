<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { settingsHref, type SettingsSection } from '../routes';
  import IrisIcon from './IrisIcon.svelte';

  export let section: SettingsSection = 'root';

  const groups: Array<{
    title: string;
    items: Array<{
      section: Exclude<SettingsSection, 'root'>;
      label: string;
      icon: string;
      color: string;
    }>;
  }> = [
    {
      title: 'User',
      items: [
        { section: 'profile', label: 'Profile', icon: 'profile', color: 'bg-emerald-500' },
        { section: 'iris', label: 'iris.to username', icon: 'at-sign', color: 'bg-violet-500' },
      ],
    },
    {
      title: 'Application',
      items: [
        { section: 'notifications', label: 'Notifications', icon: 'bell-outline', color: 'bg-blue-500' },
        { section: 'content', label: 'Content', icon: 'openeye', color: 'bg-indigo-500' },
        { section: 'appearance', label: 'Appearance', icon: 'stars', color: 'bg-purple-500' },
        { section: 'wallet', label: 'Wallet', icon: 'wallet-outline', color: 'bg-orange-500' },
      ],
    },
    {
      title: 'Data',
      items: [
        { section: 'network', label: 'Network', icon: 'relay', color: 'bg-blue-500' },
        { section: 'media', label: 'Media servers', icon: 'media', color: 'bg-sky-500' },
        { section: 'storage', label: 'Storage', icon: 'hard-drive', color: 'bg-amber-500' },
      ],
    },
  ];

  $: selectedSection = section === 'root' ? 'profile' : section;
</script>

<nav
  data-testid="settings-navigation"
  aria-label="Settings"
  class={`w-full shrink-0 bg-[var(--iris-surface-subtle)] p-4 lg:sticky lg:top-16 lg:block lg:min-h-[calc(100vh-4rem)] lg:w-64 lg:self-start lg:border-r lg:border-[rgb(var(--iris-text-rgb)/0.08)] ${section === 'root' ? 'block' : 'hidden'}`}
>
  <div class="grid gap-6 pb-32 lg:pb-4">
    {#each groups as group (group.title)}
      <SettingsGroup title={group.title}>
        {#each group.items as item, index (item.section)}
          <SettingsGroupItem
            href={settingsHref(item.section)}
            active={selectedSection === item.section}
            isLast={index === group.items.length - 1}
            variant="navigation"
            testId={`settings-nav-${item.section}`}
          >
            <span class="flex items-center justify-between gap-3">
              <span class="flex min-w-0 items-center gap-3">
                <span class={`settings-navigation-icon grid h-[24px] w-[24px] shrink-0 place-items-center rounded-[8px] text-white iris-preserve-white-text ${item.color}`}>
                  <IrisIcon name={item.icon} size={16} />
                </span>
                <span class="settings-navigation-label truncate text-[16px] font-500">{item.label}</span>
              </span>
              <IrisIcon name="arrowFront" size={18} className="text-[rgb(var(--iris-text-rgb)/0.5)]" />
            </span>
          </SettingsGroupItem>
        {/each}
      </SettingsGroup>
    {/each}
  </div>
</nav>
