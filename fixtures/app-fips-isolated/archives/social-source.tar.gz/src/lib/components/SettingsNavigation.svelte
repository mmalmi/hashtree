<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { accountsHref, settingsHref, type SettingsSection } from '../routes';
  import IrisIcon from './IrisIcon.svelte';

  export let section: SettingsSection = 'root';
  export let onSignOut: (() => Promise<void>) | null = null;

  let signingOut = false;
  let signOutError = '';

  async function signOut(): Promise<void> {
    if (!onSignOut || signingOut) return;
    signingOut = true;
    signOutError = '';
    try {
      await onSignOut();
    } catch {
      signOutError = 'Could not sign out.';
    } finally {
      signingOut = false;
    }
  }

  let groups: Array<{
    title: string;
    items: Array<{
      section: Exclude<SettingsSection, 'root'> | 'accounts';
      label: string;
      icon: string;
      color: string;
    }>;
  }>;

  $: groups = [
    {
      title: 'User',
      items: [
        onSignOut
          ? { section: 'profile', label: 'Profile', icon: 'profile', color: 'bg-emerald-500' }
          : { section: 'accounts', label: 'Sign in', icon: 'sign-in', color: 'bg-violet-500' },
        { section: 'iris', label: 'iris.to username', icon: 'at-sign', color: 'bg-violet-500' },
      ],
    },
    {
      title: 'Application',
      items: [
        { section: 'notifications', label: 'Notifications', icon: 'bell-outline', color: 'bg-blue-500' },
        { section: 'content', label: 'Content', icon: 'openeye', color: 'bg-indigo-500' },
        { section: 'appearance', label: 'Appearance', icon: 'stars', color: 'bg-purple-500' },
        { section: 'wallet', label: 'Wallet', icon: 'wallet-outline', color: 'bg-orange-500' },
      ],
    },
    {
      title: 'Data',
      items: [
        { section: 'network', label: 'Network', icon: 'relay', color: 'bg-blue-500' },
        { section: 'media', label: 'Media servers', icon: 'media', color: 'bg-sky-500' },
        { section: 'storage', label: 'Storage', icon: 'hard-drive', color: 'bg-amber-500' },
      ],
    },
  ];

  $: selectedSection = section === 'root' ? 'profile' : section;
</script>

<nav
  data-testid="settings-navigation"
  aria-label="Settings"
  class={`w-full shrink-0 bg-[var(--iris-surface-subtle)] p-4 lg:sticky lg:top-16 lg:block lg:min-h-[calc(100vh-4rem)] lg:w-64 lg:self-start lg:border-r lg:border-divider ${section === 'root' ? 'block' : 'hidden'}`}
>
  <div class="grid gap-6 pb-32 lg:pb-4">
    {#each groups as group (group.title)}
      <SettingsGroup title={group.title}>
        {#each group.items as item, index (item.section)}
          <SettingsGroupItem
            href={item.section === 'accounts' ? accountsHref() : settingsHref(item.section)}
            active={selectedSection === item.section}
            isLast={index === group.items.length - 1}
            variant="navigation"
            testId={`settings-nav-${item.section}`}
          >
            <span class="flex items-center justify-between gap-3">
              <span class="flex min-w-0 items-center gap-3">
                <span class={`settings-navigation-icon grid h-[24px] w-[24px] shrink-0 place-items-center rounded-[8px] text-white iris-preserve-white-text ${item.color}`}>
                  <IrisIcon name={item.icon} size={16} />
                </span>
                <span class="settings-navigation-label truncate text-[16px] font-500">{item.label}</span>
              </span>
              <IrisIcon name="arrowFront" size={18} className="text-[rgb(var(--iris-text-rgb)/0.5)]" />
            </span>
          </SettingsGroupItem>
        {/each}
      </SettingsGroup>
    {/each}
    {#if onSignOut}
      <div class="grid justify-items-center gap-2">
        <button
          type="button"
          data-testid="settings-sign-out"
          disabled={signingOut}
          class="rounded-full px-5 py-2 text-[15px] font-600 text-red-500 transition hover:bg-red-500/10 disabled:opacity-50"
          on:click={() => void signOut()}
        >{signingOut ? 'Signing out…' : 'Sign out'}</button>
        {#if signOutError}<p role="alert" class="text-sm text-red-400">{signOutError}</p>{/if}
      </div>
    {/if}
  </div>
</nav>
