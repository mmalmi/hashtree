<script context="module" lang="ts">
  import type ArticleRenderer from './ArticleContent.svelte';
  let cached: typeof ArticleRenderer | null = null;
  let pending: Promise<typeof ArticleRenderer> | null = null;
  function loadRenderer() {
    pending ??= import('./ArticleContent.svelte').then(module => (cached = module.default)).finally(() => { pending = null; });
    return pending;
  }
</script>

<script lang="ts">
  import { onMount } from 'svelte';
  import { buildNoteThreadReference } from '../appSharing';
  import { getLongformMetadata } from '../longform';
  import type { RawEvent } from '../nostr';
  import type { NoteEmbed } from '../noteContent';
  import { threadHref } from '../routes';
  export let event: RawEvent;
  export let compact = false;
  export let collapsible = true;
  export let showImages = true;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenNote: ((reference: string) => void) | null = null;
  export let onOpenMedia: ((payload: { event: RawEvent; embed: NoteEmbed; index: number; embeds: NoteEmbed[] }) => void) | null = null;

  let Renderer = cached;
  $: metadata = getLongformMetadata(event);
  $: paragraphs = (collapsible ? metadata?.summary || event.content : event.content).trim().split(/\n\s*\n/)
    .slice(0, collapsible ? (compact ? 1 : 3) : undefined);
  $: reference = buildNoteThreadReference(event);
  onMount(() => { if (!Renderer) { void loadRenderer().then(component => { Renderer = component; }).catch(() => {}); } });

  function openArticle(click: MouseEvent): void {
    if (click.button !== 0 || click.metaKey || click.ctrlKey || click.shiftKey || click.altKey || !onOpenNote) { return; }
    click.preventDefault();
    onOpenNote(reference);
  }
</script>

<div data-testid="article-content" class="min-w-0">
  <div class:preview={collapsible} class:compact>
    {#if collapsible || !Renderer}
      <!-- The excerpt sets the row size before Markdown code or media bytes arrive. -->
      <div class="excerpt" class:reserved={Boolean(Renderer)} aria-hidden={Renderer ? 'true' : undefined}>
        {#if metadata?.image && showImages}<div class="image-space"></div>{/if}
        {#each paragraphs as paragraph}
          {#if /^!\[[^\]]*\]\(/.test(paragraph)}
            {#if showImages}<div class="image-space"></div>{/if}
          {:else if /^#{1,6}\s/.test(paragraph)}
            <p class="heading">{paragraph.replace(/^#{1,6}\s+/, '')}</p>
          {:else}
            <p>{paragraph}</p>
          {/if}
        {/each}
      </div>
    {/if}
    {#if Renderer}
      <div class:formatted={collapsible}>
        <svelte:component this={Renderer} {event} {compact} {collapsible} {showImages} {onOpenProfile} {onOpenNote} {onOpenMedia} />
      </div>
    {/if}
  </div>
  {#if collapsible}
    <a data-testid="article-read-more" class="mt-2 inline-block text-sm font-600 text-[#a989ee]" href={threadHref(reference)} on:click={openArticle}>Read article</a>
  {/if}
</div>

<style>
  .preview { position: relative; overflow: hidden; max-height: 24rem; }
  .preview.compact { max-height: 12rem; }
  .formatted { position: absolute; inset: 0; overflow: hidden; }
  .excerpt { display: flow-root; overflow-wrap: anywhere; font-size: 1rem; line-height: 1.75; color: rgb(var(--iris-text-rgb) / .85); }
  .excerpt p { white-space: pre-line; margin: .7em 0; }
  .excerpt .heading { font-size: 1.55em; font-weight: 700; line-height: 1.3; margin: 1.3em 0 .45em; }
  .reserved { visibility: hidden; }
  .image-space { width: 100%; aspect-ratio: 16/9; max-height: 75vh; margin: .5em 0; border-radius: .6rem; background: var(--iris-surface-raised); }
</style>
