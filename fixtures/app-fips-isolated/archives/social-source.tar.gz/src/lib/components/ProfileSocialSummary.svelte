<script lang="ts">
  import ProfileSocialBadge from './ProfileSocialBadge.svelte';
  import { getRouteActivity } from '../routeActivity';
  import { socialGraphBadges } from '../socialGraphBadges';
  import { contactMemoryStore } from '../contactMemoryStore';
  import { AvatarGroup, type AvatarGroupItem } from '@iris/svelte-ui';
  import { getProfileTitle, type ProfileRecord } from '../nostr';
  import type { FollowedByPresentation } from '../profileSocialPresentation';
  import { profileHref } from '../routes';

  export let pubkey: string;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let followsCountLabel = '...';
  export let followerCountLabel = '...';
  export let followedBy: FollowedByPresentation = {
    pubkeys: [],
    total: 0,
    followedByViewer: false,
  };
  export let socialContextKnown = false;
  export let isOwnProfile = false;
  export let onOpenFollows: () => void = () => undefined;
  export let onOpenFollowers: () => void = () => undefined;

  const routeActivity = getRouteActivity();
  $: badge = $socialGraphBadges.get(pubkey);
  $: avatarItems = followedBy.pubkeys.map((pubkey): AvatarGroupItem => {
    const profile = profiles.get(pubkey) ?? null;
    return {
      pubkey,
      profile,
      href: profileHref(pubkey),
      label: $contactMemoryStore.contacts.get(pubkey)?.nickname || $contactMemoryStore.contacts.get(pubkey)?.accepted_name || getProfileTitle(profile, pubkey),
    };
  });
  $: undisplayedCount = Math.max(0, followedBy.total - followedBy.pubkeys.length);
  $: displayedFollowsCount = followsCountLabel === '...' ? '' : followsCountLabel;
  $: displayedFollowerCount = followerCountLabel === '...' ? '' : followerCountLabel;
</script>

<div data-testid="profile-social-summary" class="grid gap-3">
  <div class="flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.94rem]">
    <button
      data-testid="profile-follows-button"
      type="button"
      class="group bg-transparent p-0 text-left text-[rgb(var(--iris-text-rgb))] hover:underline"
      on:click={onOpenFollows}
    >
      <span class="inline-block min-w-[3ch] text-right font-700 tabular-nums">{displayedFollowsCount}</span>
      <span class="ml-1 text-[rgb(var(--iris-text-rgb)/0.62)]">follows</span>
    </button>
    <button
      data-testid="profile-followers-button"
      type="button"
      class="group bg-transparent p-0 text-left text-[rgb(var(--iris-text-rgb))] hover:underline"
      on:click={onOpenFollowers}
    >
      <span class="inline-block min-w-[3ch] text-right font-700 tabular-nums">{displayedFollowerCount}</span>
      <span class="ml-1 text-[rgb(var(--iris-text-rgb)/0.62)]">known followers</span>
    </button>
  </div>

  <div class="flex h-[22px] min-w-0 items-center gap-2 overflow-hidden" data-testid="profile-follow-explanation">
    <ProfileSocialBadge {pubkey} active={$routeActivity} reserveSpace />
    <div class="h-full min-w-0 flex-1 overflow-hidden">
      {#if isOwnProfile}
        <div data-testid="profile-followed-by" class="h-full text-[0.82rem] leading-[22px] text-[rgb(var(--iris-text-rgb)/0.5)]">You</div>
      {:else if followedBy.total > 0}
        <div
          data-testid="profile-followed-by"
          class="flex h-full min-w-0 items-center gap-2 text-[0.82rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.5)]"
        >
          {#if avatarItems.length > 0}
            <AvatarGroup
              items={avatarItems}
              size={22}
              overlap={7}
              max={3}
              ariaLabel="People you follow who follow this profile"
              class="shrink-0"
            />
          {/if}
          <div class="flex min-w-0 items-center gap-1 whitespace-nowrap">
            <button type="button" class="shrink-0 hover:underline" on:click={onOpenFollowers}>Followed by</button>
            {#if followedBy.pubkeys.length > 0}
              <span class="min-w-0 truncate">
              {#each followedBy.pubkeys as pubkey, index (pubkey)}
                <a
                  href={profileHref(pubkey)}
                  class="text-[rgb(var(--iris-text-rgb)/0.72)] hover:underline"
                >{$contactMemoryStore.contacts.get(pubkey)?.nickname || $contactMemoryStore.contacts.get(pubkey)?.accepted_name || getProfileTitle(profiles.get(pubkey) ?? null, pubkey)}</a>{index < followedBy.pubkeys.length - 1 ? ', ' : ' '}
              {/each}
              </span>
              {#if undisplayedCount > 0}
                <button
                  data-testid="profile-followed-by-others"
                  type="button"
                  class="shrink-0 hover:underline"
                  aria-label={`Show followers, including ${undisplayedCount} more people you follow`}
                  on:click={onOpenFollowers}
                >and {undisplayedCount} {undisplayedCount === 1 ? 'other' : 'others'}</button>
              {/if}
            {:else}
              <button type="button" class="truncate hover:underline" on:click={onOpenFollowers}>
                {followedBy.total} {followedBy.total === 1 ? 'person' : 'people'} you follow
              </button>
            {/if}
          </div>
        </div>
      {:else if followedBy.followedByViewer || badge?.distance === 1}
        <div
          data-testid="profile-followed-by"
          class="h-full truncate whitespace-nowrap text-[0.82rem] leading-[22px] text-[rgb(var(--iris-text-rgb)/0.5)]"
        >
          Followed by you
        </div>
      {:else if badge?.distance === 2}
        <div data-testid="profile-followed-by" class="h-full truncate whitespace-nowrap text-[0.82rem] leading-[22px] text-[rgb(var(--iris-text-rgb)/0.5)]">
          Followed by {badge.followedByFriends} {badge.followedByFriends === 1 ? 'person' : 'people'} you follow
        </div>
      {:else if badge?.distance === 3}
        <div data-testid="profile-followed-by" class="h-full truncate whitespace-nowrap text-[0.82rem] leading-[22px] text-[rgb(var(--iris-text-rgb)/0.5)]">
          Followed by friends of friends
        </div>
      {:else if socialContextKnown}
        <div
          data-testid="profile-followed-by"
          class="h-full truncate whitespace-nowrap text-[0.82rem] leading-[22px] text-[rgb(var(--iris-text-rgb)/0.5)]"
        >
          Not followed by anyone you follow
        </div>
      {/if}
    </div>
  </div>
</div>
