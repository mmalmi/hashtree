<script lang="ts">
  import { contactMemoryStore, publicContactName } from '../contactMemoryStore';
  import { pendingContactName } from '@iris/svelte-ui/contactMemory';
  import { getSharedProfileRecord } from '../profileCache';
  import { preferNewerProfileRecord } from '../profileRecords';
  import type { ProfileRecord } from '../nostr';
  import PrivateContactDetails from './PrivateContactDetails.svelte';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let following = false;
  export let isActive = true;
  $: memory = $contactMemoryStore.contacts.get(pubkey);
  $: name = publicContactName(profile);
  $: if (isActive && $contactMemoryStore.viewer && (following || memory)) {
    contactMemoryStore.remember(pubkey, name);
  }
  $: pendingName = memory ? pendingContactName(memory, name) : null;

  function approve(expectedName: string): void {
    const latest = preferNewerProfileRecord(profile, getSharedProfileRecord(pubkey));
    contactMemoryStore.approve(pubkey, expectedName, publicContactName(latest), Math.floor(Date.now() / 1000));
  }
</script>

<PrivateContactDetails {pubkey} />

{#if memory && (pendingName || memory.name_changes.length > 0)}
  <div data-testid="profile-contact-memory" class="grid gap-2 text-sm text-white/60">
    {#if pendingName}
      <div data-testid="profile-name-change" class="flex flex-wrap items-center gap-x-3 gap-y-2">
        <span class="min-w-0 max-w-full break-words">Now uses “{pendingName}”</span>
        <button
          type="button"
          title="Only you can see this"
          class="rounded-full bg-white/10 px-3 py-1.5 font-600 text-white hover:bg-white/15"
          on:click={() => pendingName && approve(pendingName)}
        >Use new name</button>
      </div>
    {/if}
    {#if memory.first_seen_name && (pendingName || memory.name_changes.length > 0)}
      <details data-testid="profile-name-history">
        <summary class="w-fit cursor-pointer text-xs" title="Only you can see this">Name history</summary>
        <div class="mt-2 grid gap-1 break-words text-xs">
          <p>First known as {memory.first_seen_name}</p>
          {#each memory.name_changes as change}
            <p>{change.previous_name} → {change.accepted_name} · Approved {new Date(change.accepted_at_secs * 1000).toLocaleDateString()}</p>
          {/each}
        </div>
      </details>
    {/if}
  </div>
{/if}
