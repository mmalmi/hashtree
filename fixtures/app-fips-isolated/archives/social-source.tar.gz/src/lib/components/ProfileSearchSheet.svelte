<script lang="ts">
  import { onDestroy, tick } from 'svelte';
  import PeopleList from './PeopleList.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import PostSearchResults from './PostSearchResults.svelte';
  import { getConfiguredPostSearchIndexRefs } from '../config';
  import {
    buildLocalPostSearchDocuments,
    mergePostSearchEvents,
    searchLocalPostDocuments,
    type LocalPostSearchDocument,
    type LocalPostSearchResult,
  } from '../localPostSearch';
  import {
    canonicalizeThreadReference,
    decodeNostrEventReference,
    type ProfileRecord,
    type RawEvent,
    getProfileTitle,
    normalizePubkey,
    pubkeyToNpub,
    shortNpub,
  } from '../nostr';
  import { PostSearchRequestController, type PostSearchRequestState } from '../postSearchRequest';
  import { overlayProfileRecord } from '../profileRecords';
  import { mergeProfileSearchRecords, sortProfileSearchMatches } from '../profileSearchRanking';
  import { profileHref } from '../routes';
  import { isMutedAuthor } from '../muteLists';
  import {
    createInfiniteScrollAction,
    INFINITE_SCROLL_PRELOAD_PX,
  } from '../infiniteScroll';
  import { advanceSearchResultLimit } from '../searchPagination';
  import { recentProfilesStore } from '../recentProfiles';

  const SEARCH_PAGE_SIZE = 20;
  const SEARCH_RESULT_LIMIT = 80;
  const DROPDOWN_PEOPLE_LIMIT = 16;

  export let open = false;
  export let active = true;
  export let presentation: 'dropdown' | 'page' = 'dropdown';
  export let initialTab: 'people' | 'posts' = 'people';
  export let query = '';
  export let profilesByPubkey: Map<string, ProfileRecord> = new Map();
  export let profileRecords: ProfileRecord[] = [];
  export let suggestedPubkeys: string[] = [];
  export let suggestedPosts: RawEvent[] = [];
  export let suggestionsLoading = false;
  export let loading = false;
  export let localPostSearchEvents: RawEvent[] = [];
  export let mutedPubkeys: Set<string> = new Set();
  export let viewerPubkey: string | null = null;
  export let onQueryChange: (value: string) => void = () => undefined;
  export let onTabChange: (tab: 'people' | 'posts') => void = () => undefined;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenPost: ((event: RawEvent) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  let searchInput: HTMLInputElement | null = null;
  let resultsContainer: HTMLDivElement | null = null;
  let wasOpen = false;
  let activeIndex = -1;
  let activeTab: 'people' | 'posts' = 'people';
  let lastInitialTab = initialTab;
  let lastSearchKey = '';
  let lastSelectionKey = '';
  let postSearchState: PostSearchRequestState = { status: 'idle', query: '' };
  let peopleVisibleLimit = SEARCH_PAGE_SIZE;
  let localPostVisibleLimit = SEARCH_PAGE_SIZE;
  let searchScrollOffset = 0;
  let searchLastLoadScrollOffset = 0;
  let lastPaginatedQuery = '';
  let remoteProfiles: ProfileRecord[] = [];
  let postSearchAuthorText = new Map<string, string>();
  let allSearchMatches: ProfileRecord[] = [];
  let localPostSearchDocuments: LocalPostSearchDocument[] = [];
  let localPostSearchCandidates: LocalPostSearchResult[] = [];
  let postSearchRunCount = 0;

  const configuredPostSearchIndexes = getConfiguredPostSearchIndexRefs();
  const postSearchController = new PostSearchRequestController(
    async (nextQuery, limit, signal, onProgress) => {
      postSearchRunCount += 1;
      const { searchPosts } = await import('../postSearchRuntime');
      if (signal.aborted) {
        throw new DOMException('Post search was cancelled', 'AbortError');
      }
      return await searchPosts(nextQuery, { limit, signal, onProgress });
    },
  );

  $: normalizedQuery = query.trim();
  $: if (initialTab !== lastInitialTab) {
    lastInitialTab = initialTab;
    activeTab = initialTab;
    resetSearchPagination();
  }
  $: exactPubkey = normalizePubkey(normalizedQuery);
  $: exactNpub = exactPubkey ? pubkeyToNpub(exactPubkey) : '';
  $: if (active) {
    remoteProfiles = profileRecords
      .map((profile) => overlayProfileRecord(profile, profilesByPubkey.get(profile.pubkey) ?? null))
      .filter((profile): profile is ProfileRecord => Boolean(profile));
    postSearchAuthorText = new Map(
      [...profilesByPubkey.values(), ...remoteProfiles].map((profile) => [
        profile.pubkey,
        [profile.displayName, profile.name, profile.nip05].filter(Boolean).join(' '),
      ]),
    );
  }
  $: if (active && normalizedQuery !== lastPaginatedQuery) {
    lastPaginatedQuery = normalizedQuery;
    resetSearchPagination();
  }
  $: if (active) {
    allSearchMatches = activeTab === 'people' && normalizedQuery.length >= 1
      ? sortProfileSearchMatches(
          mergeProfileSearchRecords([
            ...profilesByPubkey.values(),
            ...remoteProfiles,
          ]),
          normalizedQuery,
        )
          .filter((profile) => !isMutedAuthor(profile.pubkey, mutedPubkeys, viewerPubkey))
      : [];
  }
  $: searchMatches = allSearchMatches.slice(
    0,
    presentation === 'page' ? peopleVisibleLimit : DROPDOWN_PEOPLE_LIMIT,
  );
  $: recentPubkeys = $recentProfilesStore.viewer === viewerPubkey
    ? $recentProfilesStore.pubkeys.filter((pubkey) => !isMutedAuthor(pubkey, mutedPubkeys, viewerPubkey))
    : [];
  $: defaultPubkeys = [...new Set([...recentPubkeys, ...(suggestedPubkeys.length > 0
    ? suggestedPubkeys
    : [...profilesByPubkey.keys()])])]
    .filter((pubkey) => pubkey !== viewerPubkey && !isMutedAuthor(pubkey, mutedPubkeys, viewerPubkey));
  $: peopleHasMore = presentation === 'page' && (normalizedQuery
    ? searchMatches.length < allSearchMatches.length
    : filteredPubkeys.length < defaultPubkeys.length);
  $: displayProfiles = (() => {
    const merged = new Map<string, ProfileRecord>(profilesByPubkey);

    for (const profile of searchMatches) {
      merged.set(profile.pubkey, profile);
    }

    return merged;
  })();
  $: filteredPubkeys = normalizedQuery
    ? searchMatches.map((profile) => profile.pubkey)
    : defaultPubkeys.slice(0, presentation === 'page' ? peopleVisibleLimit : DROPDOWN_PEOPLE_LIMIT);
  $: otherPubkeys = normalizedQuery ? filteredPubkeys : filteredPubkeys.filter((pubkey) => !recentPubkeys.includes(pubkey));
  $: selectionKey = `${activeTab}:${normalizedQuery}:${filteredPubkeys.join(',')}`;
  $: exactProfile = exactPubkey
    ? overlayProfileRecord(
        profileRecords.find((profile) => profile.pubkey === exactPubkey) ?? null,
        profilesByPubkey.get(exactPubkey) ?? null,
      )
    : null;
  $: peopleSearchPending = active && Boolean(normalizedQuery) && loading;
  $: emptyText = normalizedQuery ? 'No people found.' : 'No people available yet.';
  $: activePubkey = activeIndex >= 0 && activeIndex < filteredPubkeys.length
    ? filteredPubkeys[activeIndex]
    : null;
  $: completePostSearchState = postSearchState.status === 'complete' ? postSearchState : null;
  $: postSearchResponse = completePostSearchState?.response ?? null;
  $: postSearchPageLimit = Math.max(
    completePostSearchState?.limit ?? SEARCH_PAGE_SIZE,
    localPostVisibleLimit,
  );
  $: if (active) {
    localPostSearchDocuments = activeTab === 'posts'
      ? buildLocalPostSearchDocuments(localPostSearchEvents, postSearchAuthorText)
      : [];
    localPostSearchCandidates = activeTab !== 'posts'
      ? []
      : !normalizedQuery
        ? localPostSearchDocuments
          .filter(({ event }) => !isMutedAuthor(event.pubkey, mutedPubkeys, viewerPubkey))
          .map(({ event }) => ({ event, score: 0 }))
          .sort((left, right) => right.event.created_at - left.event.created_at || left.event.id.localeCompare(right.event.id))
          .slice(0, SEARCH_RESULT_LIMIT)
        : searchLocalPostDocuments(
          localPostSearchDocuments,
          normalizedQuery,
          SEARCH_RESULT_LIMIT,
        )
        .filter((result) => !isMutedAuthor(result.event.pubkey, mutedPubkeys, viewerPubkey));
  }
  $: catalogPostSearchEvents = (normalizedQuery
    ? (postSearchResponse?.results ?? []).map((result) => result.event)
    : suggestedPosts)
    .filter((event) => !isMutedAuthor(event.pubkey, mutedPubkeys, viewerPubkey));
  $: mergedPostSearchEvents = mergePostSearchEvents(
    catalogPostSearchEvents,
    localPostSearchCandidates,
    SEARCH_RESULT_LIMIT,
  );
  $: postSearchEvents = mergedPostSearchEvents.slice(0, postSearchPageLimit);
  $: postSearchHasMore = mergedPostSearchEvents.length > postSearchPageLimit || Boolean(completePostSearchState?.hasMore);
  $: postSearchLoadPending = Boolean(completePostSearchState?.loadingMore);
  $: if (activeIndex >= filteredPubkeys.length) {
    activeIndex = filteredPubkeys.length > 0 ? filteredPubkeys.length - 1 : -1;
  }
  $: if (open && active && activeTab === 'people' && selectionKey !== lastSelectionKey) {
    lastSelectionKey = selectionKey;
    activeIndex = filteredPubkeys.length > 0 ? 0 : -1;
  }
  $: if (open && active && (!wasOpen || lastSearchKey !== `${activeTab}:${normalizedQuery}`)) {
    const opening = !wasOpen;
    wasOpen = true;
    if (opening) { activeTab = initialTab; activeIndex = -1; }
    lastSearchKey = `${activeTab}:${normalizedQuery}`;
    if (activeTab === 'posts') {
      if (!postSearchController.resume(query, applyPostSearchState)) {
        schedulePostSearch(query);
      }
    } else {
      postSearchController.cancel();
    }
    if (opening) { void tick().then(() => searchInput?.focus({ preventScroll: true })); }
  } else if ((!open || !active) && wasOpen) {
    wasOpen = false;
    activeIndex = -1;
    lastSelectionKey = '';
    postSearchState = postSearchController.pause();
  }

  onDestroy(() => postSearchController.cancel());

  function applyPostSearchState(state: PostSearchRequestState): void {
    postSearchState = state;
  }

  function resetSearchPagination(): void {
    peopleVisibleLimit = SEARCH_PAGE_SIZE;
    localPostVisibleLimit = SEARCH_PAGE_SIZE;
    searchScrollOffset = 0;
    searchLastLoadScrollOffset = 0;
  }

  function schedulePostSearch(value: string): void {
    if (!active || configuredPostSearchIndexes.length === 0) {
      postSearchController.cancel();
      postSearchState = { status: 'idle', query: value.trim() };
      return;
    }
    postSearchController.update(value, applyPostSearchState);
  }

  function loadMorePostSearch(): void {
    localPostVisibleLimit = advanceSearchResultLimit(
      localPostVisibleLimit,
      SEARCH_RESULT_LIMIT,
      SEARCH_PAGE_SIZE,
    );
    if (completePostSearchState?.hasMore) {
      postSearchController.loadMore();
    }
  }

  function loadMoreSearchResults(): void {
    if (!active || presentation !== 'page') {
      return;
    }
    searchLastLoadScrollOffset = searchScrollOffset;
    if (activeTab === 'people') {
      peopleVisibleLimit = advanceSearchResultLimit(
        peopleVisibleLimit,
        normalizedQuery ? allSearchMatches.length : defaultPubkeys.length,
        SEARCH_PAGE_SIZE,
      );
      return;
    }
    loadMorePostSearch();
  }

  const searchInfiniteScroll = createInfiniteScrollAction({
    preloadPx: INFINITE_SCROLL_PRELOAD_PX,
    minScrollDeltaPx: 0,
    getScrollOffset: () => searchScrollOffset,
    setScrollOffset: (nextOffset) => {
      searchScrollOffset = nextOffset;
    },
    getLastLoadScrollOffset: () => searchLastLoadScrollOffset,
    getLoadPending: () => activeTab === 'posts' && postSearchLoadPending,
    getHasMore: () => active && presentation === 'page' && (
      activeTab === 'people' ? peopleHasMore : postSearchHasMore
    ),
    getFillViewport: () => active && presentation === 'page',
    onLoadMore: loadMoreSearchResults,
  });

  function selectTab(tab: 'people' | 'posts'): void {
    activeTab = tab;
    activeIndex = -1;
    resetSearchPagination();
    onTabChange(tab);
    void tick().then(() => searchInput?.focus({ preventScroll: true }));
  }

  function handleQueryInput(value: string): void {
    onQueryChange(value);
    // A navigation can reject an outgoing input event before this retained
    // view receives its inactive prop. Restore the accepted value as well.
    void tick().then(() => {
      if (searchInput && searchInput.value !== query) { searchInput.value = query; }
    });
  }

  function openThreadReference(value: string): boolean {
    const threadReference = canonicalizeThreadReference(value);
    if (decodeNostrEventReference(threadReference) && onOpenThread) {
      onOpenThread(threadReference);
      return true;
    }

    return false;
  }

  function handleSubmit(): void {
    if (openThreadReference(query)) {
      return;
    }

    if (activeTab === 'posts') {
      return;
    }

    if (activePubkey && onOpenProfile) {
      openProfile(activePubkey);
      return;
    }

    if (!exactPubkey || !onOpenProfile) {
      return;
    }

    openProfile(exactPubkey);
  }

  function recordProfileSelection(pubkey: string): void {
    recentProfilesStore.select(viewerPubkey, pubkey);
  }

  function openProfile(pubkey: string): void {
    recordProfileSelection(pubkey);
    onOpenProfile?.(pubkey);
  }

  function scrollActiveResultIntoView(): void {
    if (!resultsContainer || !activePubkey) {
      return;
    }

    const activeRow = resultsContainer.querySelector<HTMLElement>(`[data-testid="people-row"][href="${profileHref(activePubkey)}"]`);
    activeRow?.scrollIntoView({ block: 'nearest' });
  }

  function handleInputKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && openThreadReference((event.currentTarget as HTMLInputElement).value)) {
      event.preventDefault();
      return;
    }

    if (activeTab !== 'people') {
      return;
    }

    if (!filteredPubkeys.length) {
      return;
    }

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      activeIndex = activeIndex < 0 ? 0 : (activeIndex + 1) % filteredPubkeys.length;
      void tick().then(scrollActiveResultIntoView);
      return;
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault();
      activeIndex = activeIndex < 0 ? filteredPubkeys.length - 1 : (activeIndex - 1 + filteredPubkeys.length) % filteredPubkeys.length;
      void tick().then(scrollActiveResultIntoView);
    }
  }

  function handlePostClick(mouseEvent: MouseEvent, event: RawEvent): void {
    if (
      !onOpenPost
      || mouseEvent.button !== 0
      || mouseEvent.metaKey
      || mouseEvent.ctrlKey
      || mouseEvent.shiftKey
      || mouseEvent.altKey
    ) {
      return;
    }
    mouseEvent.preventDefault();
    onOpenPost(event);
  }
</script>

{#if open}
  <div
    data-testid="profile-search-sheet"
    data-search-active={active ? 'true' : 'false'}
    data-post-search-status={postSearchState.status}
    data-post-search-run-count={postSearchRunCount}
    data-presentation={presentation}
    class={presentation === 'page'
      ? 'relative bg-transparent'
      : 'absolute left-0 right-0 top-[calc(100%+0.45rem)] z-40 overflow-hidden rounded-[16px] border border-violet-300/25 bg-[#111111] shadow-[0_24px_80px_rgba(0,0,0,0.45)]'}
  >
    <form class={presentation === 'page' ? 'px-4 pb-2 pt-4' : 'p-3'} on:submit|preventDefault={handleSubmit}>
      <label class="flex h-12 items-center gap-3 rounded-full bg-[var(--iris-surface)] px-4 transition focus-within:bg-[var(--iris-surface-hover)] focus-within:ring-1 focus-within:ring-violet-400/45">
        <IrisIcon name="search-outline" size={19} className="shrink-0 text-white/45" />
        <input
          bind:this={searchInput}
          data-testid="profile-search-input"
          autocomplete="off"
          value={query}
          placeholder={activeTab === 'people' ? 'Search names or paste npub / hex' : 'Search posts and hashtags'}
          class="min-w-0 flex-1 border-0 bg-transparent text-[0.98rem] text-white outline-none placeholder:text-white/40"
          on:input={(event) => handleQueryInput((event.currentTarget as HTMLInputElement).value)}
          on:keydown={handleInputKeydown}
        />
        {#if query}
          <button
            type="button"
            class="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-white/45 transition hover:bg-white/8 hover:text-white"
            aria-label="Clear search"
            on:click={() => {
              handleQueryInput('');
              void tick().then(() => searchInput?.focus({ preventScroll: true }));
            }}
          >
            <IrisIcon name="x-close" size={15} />
          </button>
        {/if}
      </label>
    </form>

    <div class={presentation === 'page' ? 'flex px-4' : 'flex border-b border-white/5 px-4'} role="tablist" aria-label="Search type">
      <button
        data-testid="search-tab-people"
        type="button"
        role="tab"
        aria-selected={activeTab === 'people'}
        class={`min-w-20 border-b-2 px-3 py-3 text-[0.9rem] font-700 transition ${activeTab === 'people' ? 'border-violet-500 text-white' : 'border-transparent text-white/50 hover:text-white/75'}`}
        on:click={() => selectTab('people')}
      >
        People
      </button>
      <button
        data-testid="search-tab-posts"
        type="button"
        role="tab"
        aria-selected={activeTab === 'posts'}
        class={`min-w-20 border-b-2 px-3 py-3 text-[0.9rem] font-700 transition ${activeTab === 'posts' ? 'border-violet-500 text-white' : 'border-transparent text-white/50 hover:text-white/75'}`}
        on:click={() => selectTab('posts')}
      >
        Posts
      </button>
    </div>

    <div
      bind:this={resultsContainer}
      data-scrollable={presentation === 'page' ? undefined : true}
      aria-busy={activeTab === 'people' && peopleSearchPending}
      class={presentation === 'page' ? 'overflow-y-visible' : 'max-h-[min(28rem,calc(100vh-7rem))] overflow-y-auto'}
    >
      {#if activeTab === 'people'}
        {#if peopleSearchPending}
          <div role="status" class="px-4 py-3 text-sm text-white/55 sm:px-5">
            Searching…
          </div>
        {/if}
        {#if exactPubkey}
        <div class="border-b border-white/5 bg-black/20 px-4 py-3 sm:px-5">
          <div class="flex items-center gap-3">
            <div class="flex h-11 w-11 items-center justify-center rounded-full bg-[#111111] text-white/70">
              <IrisIcon name="profile" size={18} />
            </div>

            <div class="min-w-0 flex-1">
              <div class="text-[0.74rem] uppercase tracking-[0.16em] text-white/45">Exact profile</div>
              <div class="mt-1 truncate text-[0.94rem] text-white">{shortNpub(exactNpub)}</div>
              {#if isMutedAuthor(exactPubkey, mutedPubkeys, viewerPubkey)}
                <div data-testid="exact-profile-muted" class="mt-1 text-[0.78rem] font-700 text-amber-200/70">
                  Muted · direct profile link
                </div>
              {/if}
              {#if exactProfile}
                <div class="mt-1 truncate text-[0.82rem] text-white/60">
                  {getProfileTitle(exactProfile, exactProfile.pubkey)}
                </div>
              {/if}
            </div>

            {#if onOpenProfile}
              <button
                type="button"
                class="rounded-[18px] border border-white/5 bg-[#111111] px-4 py-2 text-[0.88rem] font-700 text-white transition hover:bg-[#1a1a1a]"
                on:click={() => openProfile(exactPubkey)}
              >
                Open
              </button>
            {:else}
              <a
                href={profileHref(exactPubkey)}
                on:click={() => recordProfileSelection(exactPubkey)}
                on:auxclick={(event) => { if (event.button === 1) recordProfileSelection(exactPubkey); }}
                class="rounded-[18px] border border-white/5 bg-[#111111] px-4 py-2 text-[0.88rem] font-700 text-white transition hover:bg-[#1a1a1a]"
              >
                Open
              </a>
            {/if}
          </div>
        </div>
        {/if}

        {#if filteredPubkeys.length > 0}
          {#if !normalizedQuery && recentPubkeys.length > 0}
            <section aria-label="Recent profiles">
              <div class="flex items-center justify-between px-4 pt-4 pb-1 text-sm text-white/50 sm:px-5">
                <h2 class="m-0 text-sm font-600">Recent</h2>
                <button type="button" aria-label="Clear recent profiles" class="hover:text-white" on:click={() => recentProfilesStore.clear()}>Clear</button>
              </div>
              <PeopleList pubkeys={recentPubkeys} profiles={displayProfiles} {activePubkey} onSelectProfile={recordProfileSelection} />
            </section>
            {#if filteredPubkeys.length > recentPubkeys.length}
              <h2 class="m-0 px-4 pt-4 pb-1 text-sm font-600 text-white/50 sm:px-5">People</h2>
            {/if}
          {/if}
          {#if otherPubkeys.length > 0}
          <PeopleList
            pubkeys={otherPubkeys}
            profiles={displayProfiles}
            {emptyText}
            {activePubkey}
            onSelectProfile={recordProfileSelection}
          />
          {/if}
          {#if active && peopleHasMore}
            <div
              data-testid="search-infinite-sentinel"
              use:searchInfiniteScroll
              aria-hidden="true"
              class="h-px w-full"
            ></div>
          {/if}
        {:else if !peopleSearchPending}
          <div class={`px-4 py-8 text-[0.94rem] leading-6 text-white/55 sm:px-5 ${presentation === 'page' ? '' : 'border-b border-white/5'}`}>
            {emptyText}
          </div>
        {/if}
      {:else}
        <PostSearchResults
          {active}
          query={normalizedQuery}
          configured={configuredPostSearchIndexes.length > 0}
          {presentation}
          state={postSearchState}
          events={postSearchEvents}
          {suggestionsLoading}
          {profilesByPubkey}
          hasMore={postSearchHasMore}
          loadPending={postSearchLoadPending}
          infiniteScroll={searchInfiniteScroll}
          onLoadMore={loadMorePostSearch}
          onPostClick={handlePostClick}
        />
      {/if}
    </div>
  </div>
{/if}
