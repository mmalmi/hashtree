<script lang="ts">
  export let name: string;
  export let size = 20;
  export let className = '';
  export let label = '';
</script>

<svg
  width={size}
  height={size}
  class={`iris-icon ${className}`.trim()}
  aria-hidden={label ? undefined : 'true'}
  aria-label={label || undefined}
  role={label ? 'img' : undefined}
>
  <use href={`/iris-icons.svg#${name}`}></use>
</svg>

<style>
  .iris-icon {
    display: block;
    flex: none;
  }
</style>
