<script lang="ts">
  import {
    feedFilterScope,
    feedFiltersStore,
    parseFeedWords,
    readFeedFilters,
    updateFeedFilters,
    type FeedFilters,
  } from '../feedFilters';
  import { findCustomFeed, homeFeedLayoutsStore, readHomeFeedLayout, updateCustomFeed } from '../homeFeedTabs';
  import type { ProfileRecord } from '../nostr';
  import type { CustomFeedBase, HomeTab } from '../routes';
  import FeedPeoplePicker from './FeedPeoplePicker.svelte';

  type FeedSourceChoice = 'latest' | 'for-you' | 'favorites' | 'people';

  export let viewerPubkey: string | null;
  export let activeTab: HomeTab;
  export let activeFeedId: string | null = null;
  export let activeSourceId: string | null = null;
  export let tabLabel: string;
  export let profiles: ReadonlyMap<string, ProfileRecord> = new Map();
  export let onSelectFeed: ((tab: HomeTab, feedId: string | null) => void) | null = null;

  const SOURCE_CHOICES: { value: FeedSourceChoice; label: string }[] = [
    { value: 'latest', label: 'People you follow' },
    { value: 'for-you', label: 'Recommended' },
    { value: 'favorites', label: 'Your favorites' },
    { value: 'people', label: 'People you choose' },
  ];
  const BUILT_IN_DESCRIPTIONS: Partial<Record<HomeTab, string>> = {
    'for-you': 'Recommended posts from your network.',
    latest: 'Newest posts from people you follow.',
    favorites: 'Newest posts from your favorites.',
    media: 'Photos and videos from people you follow.',
  };
  const POST_TYPES: { value: FeedFilters['postType']; label: string }[] = [
    { value: 'all', label: 'All' }, { value: 'posts', label: 'Notes' }, { value: 'articles', label: 'Articles' },
  ];

  let wordsDraft = '';
  let wordsScope: string | null = null;

  $: custom = findCustomFeed(readHomeFeedLayout($homeFeedLayoutsStore, viewerPubkey), activeFeedId);
  $: sourceChoice = (custom?.base === 'favorites' && custom.people ? 'people' : custom?.base ?? activeTab) as FeedSourceChoice;
  $: filterScope = feedFilterScope(viewerPubkey, activeSourceId, activeTab, activeFeedId);
  $: filters = readFeedFilters($feedFiltersStore, filterScope);
  $: if (wordsScope !== filterScope) { wordsScope = filterScope; wordsDraft = filters.words.join(' '); }

  function changeSource(choice: FeedSourceChoice): void {
    if (!custom || choice === sourceChoice) {return;}
    const base: CustomFeedBase = choice === 'people' ? 'favorites' : choice;
    updateCustomFeed(viewerPubkey, custom.id, { base, people: choice === 'people' ? custom.people ?? [] : undefined });
    if (base !== custom.base) {onSelectFeed?.(base, custom.id);}
  }

  function changeFilter(key: 'showReplies' | 'showRepliedTo' | 'showReposts' | 'mediaOnly' | 'hideSeen' | 'autoShowNew', checked: boolean): void {
    updateFeedFilters(filterScope, { [key]: checked });
  }

  function saveWords(): void {
    updateFeedFilters(filterScope, { words: parseFeedWords(wordsDraft) });
  }

  const checkClass = 'h-4.5 w-4.5 shrink-0 accent-violet-600';
  const rowClass = 'flex min-h-9 cursor-pointer items-center gap-2.5';
  const inputClass = 'min-w-0 rounded-lg iris-field px-3 py-2 text-[max(1rem,16px)]';
  const fieldLabel = 'text-sm font-650';
  const hint = 'm-0 text-xs text-white/60';
  const chip = 'rounded-full px-3 py-1.5 font-650 transition';
  const chipOn = 'iris-preserve-white-text bg-violet-700 text-white';
  const chipOff = 'iris-neutral-button';
</script>

<div class="grid gap-4 text-sm" data-testid="feed-editor">
  <section class="grid gap-3" aria-label="Feed">
    {#if custom}
      <label class="grid gap-1.5">
        <span class={fieldLabel}>Name</span>
        <input data-testid="custom-feed-name" class={inputClass} maxlength="40" value={custom.name}
          on:change={(event) => updateCustomFeed(viewerPubkey, custom.id, { name: event.currentTarget.value })} />
      </label>
      <div class="grid gap-1.5" role="radiogroup" aria-label="Posts from">
        <span class={fieldLabel}>Posts from</span>
        <div class="flex flex-wrap gap-1.5">
          {#each SOURCE_CHOICES as choice (choice.value)}
            <button type="button" role="radio" aria-checked={sourceChoice === choice.value}
              data-testid={`custom-feed-source-${choice.value}`}
              class={`${chip} ${sourceChoice === choice.value ? chipOn : chipOff}`}
              on:click={() => changeSource(choice.value)}>{choice.label}</button>
          {/each}
        </div>
      </div>
      {#if sourceChoice === 'people'}
        <div class="grid gap-1.5">
          <span class={fieldLabel}>People</span>
          <FeedPeoplePicker label="Add a person" testId="custom-feed-people" pubkeys={custom.people ?? []} {profiles}
            onChange={(people) => updateCustomFeed(viewerPubkey, custom.id, { people })} />
          {#if (custom.people ?? []).length === 0}<p class={hint}>Add people to see their posts here.</p>{/if}
        </div>
      {/if}
    {:else}
      <p class="m-0 truncate text-white/70">{BUILT_IN_DESCRIPTIONS[activeTab] ?? ''}</p>
    {/if}
  </section>

  <fieldset aria-label={`${tabLabel} filters`} disabled={!filterScope} class="m-0 grid min-w-0 gap-3 border-0 border-t border-divider p-0 pt-3">
    <div class="flex h-7 items-center justify-between gap-3">
      <span class={fieldLabel}>Show</span>
      {#if filterScope && $feedFiltersStore.has(filterScope)}
        <button type="button" class="rounded-full px-2 py-1 text-white/65 hover:text-white" on:click={() => updateFeedFilters(filterScope, null)}>Reset filters</button>
      {/if}
    </div>
    <div class="grid">
      {#if activeTab !== 'for-you'}
        <label class={rowClass}>
          <input class={checkClass} type="checkbox" checked={filters.showReplies} on:change={event => changeFilter('showReplies', event.currentTarget.checked)} />
          Show replies
        </label>
      {/if}
      {#if activeTab === 'latest' || activeTab === 'favorites'}
        <label class={`${rowClass} ml-7 ${filters.showReplies ? '' : 'opacity-50'}`}>
          <input class={checkClass} type="checkbox" checked={filters.showReplies && filters.showRepliedTo} disabled={!filters.showReplies} on:change={event => changeFilter('showRepliedTo', event.currentTarget.checked)} />
          Show the post being replied to
        </label>
      {/if}
      <label class={rowClass}>
        <input class={checkClass} type="checkbox" checked={filters.showReposts} on:change={event => changeFilter('showReposts', event.currentTarget.checked)} />
        Show reposts
      </label>
      {#if activeTab !== 'media'}
        <label class={rowClass}>
          <input class={checkClass} type="checkbox" checked={filters.mediaOnly} on:change={event => changeFilter('mediaOnly', event.currentTarget.checked)} />
          Only posts with media
        </label>
      {/if}
      <label class={rowClass}>
        <input class={checkClass} type="checkbox" checked={filters.hideSeen} on:change={event => changeFilter('hideSeen', event.currentTarget.checked)} />
        Hide posts you've seen
      </label>
      <label class={rowClass}>
        <input class={checkClass} type="checkbox" checked={filters.autoShowNew} on:change={event => changeFilter('autoShowNew', event.currentTarget.checked)} />
        Show new posts automatically
      </label>
    </div>
    <div class="grid gap-1.5" role="radiogroup" aria-label="Post type">
      <span class={fieldLabel}>Post type</span>
      <div class="flex flex-wrap gap-1.5">
        {#each POST_TYPES as type (type.value)}
          <button type="button" role="radio" aria-checked={filters.postType === type.value}
            class={`${chip} ${filters.postType === type.value ? chipOn : chipOff}`}
            on:click={() => updateFeedFilters(filterScope, { postType: type.value })}>{type.label}</button>
        {/each}
      </div>
    </div>
    <label class="grid gap-1.5">
      <span class={fieldLabel}>Words</span>
      <input data-testid="feed-filter-words" class={inputClass} placeholder="bitcoin #art" bind:value={wordsDraft}
        on:change={saveWords} on:keydown={(event) => { if (event.key === 'Enter') { saveWords(); } }} />
      <span class={hint}>Only posts that contain any of these words or #hashtags.</span>
    </label>
    <div class="grid gap-1.5">
      <span class={fieldLabel}>Mentions</span>
      <FeedPeoplePicker label="Add a mentioned person" testId="feed-filter-mentions" pubkeys={filters.mentions} {profiles}
        onChange={(mentions) => updateFeedFilters(filterScope, { mentions })} />
      <span class={hint}>Only posts that tag any of these people.</span>
    </div>
  </fieldset>
</div>
