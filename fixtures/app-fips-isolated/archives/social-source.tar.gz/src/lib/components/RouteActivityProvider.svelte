<script lang="ts">
  import { writable } from 'svelte/store';
  import { provideRouteActivity } from '../routeActivity';

  export let active = true;

  const activity = writable(active);
  provideRouteActivity(activity);
  $: activity.set(active);
</script>

<slot></slot>
