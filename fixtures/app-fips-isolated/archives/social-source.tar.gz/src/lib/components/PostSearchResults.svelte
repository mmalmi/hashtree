<script lang="ts">
  import type { Action } from 'svelte/action';
  import { buildEventPreviewText } from '../longform';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { PostSearchRequestState } from '../postSearchRequest';
  import { noteHref } from '../routes';
  import { buildNoteThreadReference } from '../appSharing';
  import UserRow from './UserRow.svelte';

  export let active = true;
  export let query = '';
  export let configured = false;
  export let presentation: 'dropdown' | 'page' = 'dropdown';
  export let state: PostSearchRequestState = { status: 'idle', query: '' };
  export let events: RawEvent[] = [];
  export let suggestionsLoading = false;
  export let profilesByPubkey: Map<string, ProfileRecord> = new Map();
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement>;
  export let onLoadMore: () => void = () => undefined;
  export let onPostClick: (event: MouseEvent, post: RawEvent) => void = () => undefined;

  $: completeState = state.status === 'complete' ? state : null;
  $: response = completeState?.response ?? null;
  $: partial = Boolean(response?.failures.length);
  $: truncated = Boolean(response?.truncatedPublishers.length);
  $: settling = Boolean(completeState?.settling);
</script>

{#if query.length === 1}
  <div class="border-b border-white/5 px-4 py-6 text-[0.94rem] leading-6 text-white/55 sm:px-5">
    Type at least two characters to search posts.
  </div>
{:else if events.length > 0}
  {#if query && !configured}
    <div data-testid="post-search-local-scope" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      Showing matches already available on this device.
    </div>
  {:else if state.status === 'loading'}
    <div data-testid="post-search-loading" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      Searching posts…
    </div>
  {:else if state.status === 'error'}
    <div data-testid="post-search-error" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      Search is unavailable. Showing matches already on this device.
    </div>
  {:else if settling}
    <div data-testid="post-search-settling" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      Searching for more posts…
    </div>
  {/if}

  {#if partial}
    <div data-testid="post-search-partial" class="border-b border-amber-300/10 bg-amber-300/[0.04] px-4 py-2.5 text-[0.8rem] leading-5 text-amber-100/60 sm:px-5">
      Some results could not be loaded. Showing the available posts.
    </div>
  {/if}
  {#if truncated}
    <div data-testid="post-search-truncated" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      These results may not include every matching post.
    </div>
  {/if}

  <div data-testid="post-search-results">
    {#each events as event (event.id)}
      <a
        data-testid="post-search-result"
        data-note-id={event.id}
        href={noteHref(buildNoteThreadReference(event))}
        class="block border-b border-white/5 px-4 py-3.5 text-left transition hover:bg-[#0a0a0a] focus-visible:bg-[#0a0a0a] focus-visible:outline-none sm:px-5"
        on:click={(mouseEvent) => onPostClick(mouseEvent, event)}
      >
        <UserRow
          pubkey={event.pubkey}
          profile={profilesByPubkey.get(event.pubkey) ?? null}
          timestamp={event.created_at}
          avatarSize={34}
          showSubtitle={false}
          onOpenProfile={null}
          gapClass="gap-2.5"
          titleClass="truncate text-[0.9rem] font-700 text-white/85"
          timeClass="text-[0.76rem] text-white/40"
        />
        <div class="mt-2 line-clamp-3 break-words pl-[2.75rem] text-[0.9rem] leading-5.5 text-white/67">
          {buildEventPreviewText(event, 220) || 'Post without text'}
        </div>
      </a>
    {/each}
  </div>
{:else if !query}
  <div data-testid="post-search-suggestions-empty" class="px-4 py-6 text-[0.94rem] leading-6 text-white/55 sm:px-5">
    {suggestionsLoading ? 'Loading posts…' : 'No posts available yet.'}
  </div>
{:else if !configured}
  <div data-testid="post-search-unconfigured" class="border-b border-white/5 px-4 py-6 sm:px-5">
    <div class="text-[0.96rem] font-700 text-white/80">No matching posts</div>
    <p class="mt-1.5 text-[0.88rem] leading-6 text-white/50">
      Search currently covers posts saved on this device.
    </p>
  </div>
{:else if state.status === 'loading'}
  <div data-testid="post-search-loading" class="border-b border-white/5 px-4 py-6 text-[0.94rem] text-white/60 sm:px-5">
    Searching posts…
  </div>
{:else if state.status === 'error'}
  <div data-testid="post-search-error" class="border-b border-white/5 px-4 py-6 sm:px-5">
    <div class="text-[0.94rem] font-700 text-white/75">Post search is unavailable right now.</div>
    <div class="mt-1.5 text-[0.82rem] leading-5 text-white/45">You can still search people and posts saved on this device.</div>
  </div>
{:else if state.status === 'complete'}
  {#if settling}
    <div data-testid="post-search-settling" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      Searching for more posts…
    </div>
  {/if}
  {#if partial}
    <div data-testid="post-search-partial" class="border-b border-amber-300/10 bg-amber-300/[0.04] px-4 py-2.5 text-[0.8rem] leading-5 text-amber-100/60 sm:px-5">
      Some results could not be loaded. Showing the available posts.
    </div>
  {/if}
  {#if truncated}
    <div data-testid="post-search-truncated" class="border-b border-white/5 bg-white/[0.02] px-4 py-2.5 text-[0.8rem] leading-5 text-white/45 sm:px-5">
      These results may not include every matching post.
    </div>
  {/if}
  <div data-testid="post-search-empty" class="border-b border-white/5 px-4 py-6 text-[0.94rem] leading-6 text-white/55 sm:px-5">
    {settling
      ? 'Searching for more matching posts…'
      : response?.searchedPublishers === 0 && partial
        ? 'Post search is unavailable right now.'
        : 'No matching posts.'}
  </div>
{/if}

{#if completeState?.loadMoreError}
  <div data-testid="post-search-load-more-error" class="border-b border-red-300/10 bg-red-300/[0.03] px-4 py-2.5 text-[0.8rem] leading-5 text-red-100/55 sm:px-5">
    Couldn’t load more posts. Existing results are still available.
  </div>
{/if}
{#if presentation === 'dropdown' && (completeState?.hasMore || completeState?.loadingMore)}
  <div class="border-b border-white/5 px-4 py-3 text-center sm:px-5">
    <button
      data-testid="post-search-load-more"
      type="button"
      disabled={completeState.loadingMore}
      class="rounded-full border border-white/8 bg-[#111111] px-4 py-2 text-[0.82rem] font-700 text-white/70 transition hover:bg-[#242424] hover:text-white disabled:cursor-wait disabled:opacity-50"
      on:click={onLoadMore}
    >
      {completeState.loadingMore ? 'Loading…' : 'Load more'}
    </button>
  </div>
{/if}
{#if active && presentation === 'page' && (hasMore || loadPending)}
  {#if loadPending}
    <div class="px-4 py-3 text-center text-[0.82rem] text-white/45 sm:px-5">Loading more…</div>
  {/if}
  <div data-testid="search-infinite-sentinel" use:infiniteScroll aria-hidden="true" class="h-px w-full"></div>
{/if}
