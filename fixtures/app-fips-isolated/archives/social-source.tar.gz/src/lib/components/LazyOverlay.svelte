<script lang="ts" generics="T extends ComponentType">
  import type { ComponentType } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';

  interface $$Slots {
    default: { component: T };
  }

  export let open = false;
  export let title: string;
  export let load: () => Promise<{ default: T }>;
  export let onClose: () => void;

  let component: T | null = null;
  let loading = false;
  let failed = false;

  async function loadComponent(): Promise<void> {
    if (loading || component) { return; }
    loading = true;
    failed = false;
    try {
      component = (await load()).default;
    } catch {
      failed = true;
    } finally {
      loading = false;
    }
  }

  $: if (open && !component && !loading && !failed) {
    void loadComponent();
  }
</script>

{#if component}
  <slot {component} />
{:else}
  <ModalShell {open} {onClose}>
    <div
      data-testid="overlay-loading"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      aria-busy={loading}
      class="w-full min-w-[min(20rem,calc(100vw-2rem))] max-w-[32rem] rounded-2xl border border-[var(--iris-border-subtle)] bg-[var(--iris-surface)] px-4 pb-6 pt-4 shadow-2xl"
    >
      <header class="flex items-center justify-between gap-3">
        <span class="font-700">{title}</span>
        <button type="button" aria-label={`Close ${title.toLowerCase()}`} class="grid h-10 w-10 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]" on:click={onClose}>
          <IrisIcon name="x-close" size={18} />
        </button>
      </header>
      <div class="mt-4 text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">
        {#if failed}
          <p role="alert" class="m-0">Couldn't load {title.toLowerCase()}.</p>
          <button type="button" class="mt-3 rounded-full border border-[var(--iris-border-subtle)] px-4 py-2 font-700" on:click={() => void loadComponent()}>Retry</button>
        {:else}
          <span role="status">Loading…</span>
        {/if}
      </div>
    </div>
  </ModalShell>
{/if}
