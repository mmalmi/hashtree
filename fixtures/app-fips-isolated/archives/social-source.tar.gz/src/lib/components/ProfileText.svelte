<script lang="ts">
  import { isTextEmbedSegment, parseNoteContent } from '../noteContent';
  import { profileHref, searchHref, threadHref } from '../routes';
  import type { ProfileRecord } from '../nostr';
  import Username from './Username.svelte';

  export let text = '';
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  $: segments = parseNoteContent(text);

  function openProfile(mouseEvent: MouseEvent, pubkey: string): void {
    if (
      !onOpenProfile
      || mouseEvent.button !== 0
      || mouseEvent.metaKey
      || mouseEvent.ctrlKey
      || mouseEvent.shiftKey
      || mouseEvent.altKey
    ) {
      return;
    }
    mouseEvent.preventDefault();
    onOpenProfile(pubkey);
  }

  function openThread(mouseEvent: MouseEvent, ref: string): void {
    if (
      !onOpenThread
      || mouseEvent.button !== 0
      || mouseEvent.metaKey
      || mouseEvent.ctrlKey
      || mouseEvent.shiftKey
      || mouseEvent.altKey
    ) {
      return;
    }
    mouseEvent.preventDefault();
    onOpenThread(ref);
  }
</script>

{#each segments as segment, index (`${segment.type}:${index}`)}
  {#if segment.type === 'text'}
    <span>{segment.text}</span>
  {:else if isTextEmbedSegment(segment)}
    {#if segment.type === 'mention'}
      <a
        data-testid="profile-about-mention"
        href={profileHref(segment.pubkey)}
        class="inline text-violet-300 underline decoration-transparent underline-offset-3 transition hover:text-[rgb(var(--iris-text-rgb))] hover:decoration-current"
        on:click={(event) => openProfile(event, segment.pubkey)}
      >
        <Username
          pubkey={segment.pubkey}
          profile={profiles.get(segment.pubkey) ?? null}
          inline={true}
          showSubtitle={false}
          titlePrefix="@"
          titleClass="inline"
        />
      </a>
    {:else if segment.type === 'event-ref'}
      <a
        data-testid="profile-about-event"
        href={threadHref(segment.bech32)}
        class="inline text-violet-300 underline decoration-transparent underline-offset-3 transition hover:text-[rgb(var(--iris-text-rgb))] hover:decoration-current"
        on:click={(event) => openThread(event, segment.bech32)}
      >{segment.label}</a>
    {:else if segment.type === 'link' || segment.type === 'attachment'}
      {#each segment.urls as url, urlIndex (`${url}:${urlIndex}`)}
        <a
          data-testid="profile-about-link"
          href={url}
          target="_blank"
          rel="noreferrer noopener"
          class="inline break-all text-violet-300 underline decoration-transparent underline-offset-3 transition hover:text-[rgb(var(--iris-text-rgb))] hover:decoration-current"
        >{url}</a>
      {/each}
    {:else if segment.type === 'emoji'}
      <img
        src={segment.url}
        alt={`:${segment.shortcode}:`}
        class="mx-[0.08em] inline-block h-[1.2em] w-[1.2em] align-[-0.18em]"
      />
    {:else if segment.type === 'hashtag'}
      <a
        data-testid="profile-about-hashtag"
        href={searchHref(`#${segment.tag}`, 'posts')}
        class="inline text-violet-300 underline decoration-transparent underline-offset-3 transition hover:text-[rgb(var(--iris-text-rgb))] hover:decoration-current"
      >#{segment.tag}</a>
    {/if}
  {/if}
{/each}
