<script lang="ts">
  import { onDestroy, onMount, tick } from 'svelte';
  import type { ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';
  import Avatar from './Avatar.svelte';
  import ProfileText from './ProfileText.svelte';
  import Username from './Username.svelte';

  export let anchor: HTMLElement;
  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let viewerPubkey: string | null = null;
  export let following = false;
  export let followPending = false;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onSelectProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let onPointerEnter: () => void = () => undefined;
  export let onPointerLeave: () => void = () => undefined;
  export let onClose: () => void = () => undefined;

  const VIEWPORT_PADDING = 12;
  const CARD_GAP = 10;
  const MAX_WIDTH = 384;

  let card: HTMLElement | null = null;
  let positioned = false;
  let left = VIEWPORT_PADDING;
  let top = VIEWPORT_PADDING;
  let width = MAX_WIDTH;
  let positionGeneration = 0;

  function portal(node: HTMLElement) {
    document.body.appendChild(node);
    return {
      destroy() {
        node.remove();
      },
    };
  }

  function hoverSurface(node: HTMLElement) {
    const enter = () => onPointerEnter();
    const leave = () => onPointerLeave();
    const stopClick = (event: MouseEvent) => event.stopPropagation();
    node.addEventListener('pointerenter', enter);
    node.addEventListener('pointerleave', leave);
    node.addEventListener('click', stopClick);
    return {
      destroy() {
        node.removeEventListener('pointerenter', enter);
        node.removeEventListener('pointerleave', leave);
        node.removeEventListener('click', stopClick);
      },
    };
  }

  async function positionCard(): Promise<void> {
    const generation = ++positionGeneration;
    positioned = false;
    width = Math.min(MAX_WIDTH, Math.max(280, window.innerWidth - VIEWPORT_PADDING * 2));
    await tick();
    if (!card || generation !== positionGeneration || !anchor.isConnected) {
      return;
    }

    const anchorRect = anchor.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    left = Math.min(
      window.innerWidth - cardRect.width - VIEWPORT_PADDING,
      Math.max(VIEWPORT_PADDING, anchorRect.left),
    );
    const below = anchorRect.bottom + CARD_GAP;
    const above = anchorRect.top - cardRect.height - CARD_GAP;
    top = below + cardRect.height <= window.innerHeight - VIEWPORT_PADDING
      ? below
      : Math.max(VIEWPORT_PADDING, above);
    positioned = true;
  }

  function openProfile(mouseEvent: MouseEvent): void {
    if (mouseEvent.button === 0) onSelectProfile?.(pubkey);
    if (
      !onOpenProfile
      || mouseEvent.button !== 0
      || mouseEvent.metaKey
      || mouseEvent.ctrlKey
      || mouseEvent.shiftKey
      || mouseEvent.altKey
    ) {
      return;
    }
    mouseEvent.preventDefault();
    onOpenProfile(pubkey);
    onClose();
  }

  function handleKeydown(keyboardEvent: KeyboardEvent): void {
    if (keyboardEvent.key === 'Escape') {
      onClose();
      anchor.focus({ preventScroll: true });
    }
  }

  $: if (anchor) void positionCard();

  onMount(() => {
    const reposition = () => void positionCard();
    window.addEventListener('scroll', reposition, true);
    return () => window.removeEventListener('scroll', reposition, true);
  });

  onDestroy(() => {
    positionGeneration += 1;
  });
</script>

<svelte:window
  on:keydown={handleKeydown}
  on:resize={() => void positionCard()}
/>

<aside
  bind:this={card}
  use:portal
  use:hoverSurface
  data-testid="profile-hover-card"
  data-positioned={positioned ? 'true' : 'false'}
  class="fixed z-[70] rounded-2xl border border-[var(--iris-border-subtle)] bg-[var(--iris-surface-raised)] p-4 text-[rgb(var(--iris-text-rgb))] shadow-[0_20px_55px_rgba(0,0,0,0.36)]"
  style={`left:${left}px;top:${top}px;width:${width}px;opacity:${positioned ? 1 : 0};`}
>
  <div class="flex min-w-0 items-start justify-between gap-3">
    <a
      data-testid="profile-hover-link"
      href={profileHref(pubkey)}
      class="flex min-w-0 items-center gap-3 no-underline"
      on:click={openProfile}
      on:auxclick={(event) => { if (event.button === 1) onSelectProfile?.(pubkey); }}
    >
      <Avatar {pubkey} {profile} size={52} />
      <Username
        {pubkey}
        {profile}
        titleClass="truncate text-[1rem] font-700 text-[rgb(var(--iris-text-rgb))]"
        subtitleClass="mt-1 truncate text-[0.82rem] text-[rgb(var(--iris-text-rgb)/0.58)]"
      />
    </a>

    {#if viewerPubkey && viewerPubkey !== pubkey && onToggleFollow}
      <button
        data-testid="profile-hover-follow"
        type="button"
        disabled={followPending}
        class="shrink-0 rounded-full border border-[var(--iris-border-subtle)] px-3.5 py-2 text-[0.82rem] font-700 transition hover:bg-[var(--iris-surface-hover)] disabled:cursor-wait disabled:opacity-55"
        on:click={() => onToggleFollow?.(pubkey, !following)}
      >
        {following ? 'Unfollow' : 'Follow'}
      </button>
    {/if}
  </div>

  {#if profile?.about?.trim()}
    <div
      data-testid="profile-hover-about"
      class="mt-3 line-clamp-4 whitespace-pre-wrap break-words text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.72)]"
    >
      <ProfileText
        text={profile.about}
        {profiles}
        {onOpenProfile}
        {onOpenThread}
      />
    </div>
  {/if}
</aside>
