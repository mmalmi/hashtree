<script lang="ts">
  import { onDestroy, onMount, tick } from 'svelte';
  import type { ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';
  import Avatar from './Avatar.svelte';
  import ProfileText from './ProfileText.svelte';
  import Username from './Username.svelte';
  import { getLoadedFollowedBy, getLoadedFollowsViewer } from '../socialGraph';
  import { sharedProfilesStore } from '../profileCache';
  import { getProfileTitle } from '../nostr';
  import { getPresentedRoute, presentedRoute } from '../appRoutePresentation';

  export let anchor: HTMLElement;
  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let viewerPubkey: string | null = null;
  export let following = false;
  export let followPending = false;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onSelectProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let onPointerEnter: () => void = () => undefined;
  export let onPointerLeave: () => void = () => undefined;
  export let onClose: () => void = () => undefined;

  // Like Iris Client: who you follow follows them, and whether they follow you.
  $: followedBy = getLoadedFollowedBy(pubkey, 3);
  $: followsViewer = viewerPubkey && viewerPubkey !== pubkey ? getLoadedFollowsViewer(pubkey, viewerPubkey) : null;
  $: followedByNames = (followedBy?.pubkeys ?? []).slice(0, 2).map((key) => getProfileTitle(
    profiles.get(key) ?? $sharedProfilesStore.get(key) ?? null, key,
  ));

  const VIEWPORT_PADDING = 12;
  const CARD_GAP = 10;
  const MAX_WIDTH = 384;

  let card: HTMLElement | null = null;
  let positioned = false;
  let left = VIEWPORT_PADDING;
  let top = VIEWPORT_PADDING;
  let width = MAX_WIDTH;
  let positionGeneration = 0;

  function portal(node: HTMLElement) {
    document.body.appendChild(node);
    return {
      destroy() {
        node.remove();
      },
    };
  }

  function hoverSurface(node: HTMLElement) {
    const enter = () => onPointerEnter();
    const leave = () => onPointerLeave();
    node.addEventListener('pointerenter', enter);
    node.addEventListener('pointerleave', leave);
    return {
      destroy() {
        node.removeEventListener('pointerenter', enter);
        node.removeEventListener('pointerleave', leave);
      },
    };
  }

  async function positionCard(): Promise<void> {
    const generation = ++positionGeneration;
    width = Math.min(MAX_WIDTH, Math.max(280, window.innerWidth - VIEWPORT_PADDING * 2));
    await tick();
    if (!card || generation !== positionGeneration) {
      return;
    }

    const anchorRect = anchor.getBoundingClientRect();
    if (!anchorRect.width || !anchorRect.height || anchor.closest('[inert]')) {
      onClose();
      return;
    }
    const cardRect = card.getBoundingClientRect();
    left = Math.min(
      window.innerWidth - cardRect.width - VIEWPORT_PADDING,
      Math.max(VIEWPORT_PADDING, anchorRect.left),
    );
    const below = anchorRect.bottom + CARD_GAP;
    const above = anchorRect.top - cardRect.height - CARD_GAP;
    top = below + cardRect.height <= window.innerHeight - VIEWPORT_PADDING
      ? below
      : Math.max(VIEWPORT_PADDING, above);
    positioned = true;
  }

  function openProfile(mouseEvent: MouseEvent): void {
    if (mouseEvent.button === 0) onSelectProfile?.(pubkey);
    if (
      mouseEvent.button !== 0
      || mouseEvent.metaKey
      || mouseEvent.ctrlKey
      || mouseEvent.shiftKey
      || mouseEvent.altKey
    ) {
      return;
    }
    onClose();
    if (onOpenProfile) {
      mouseEvent.preventDefault();
      onOpenProfile(pubkey);
    }
  }

  function handleKeydown(keyboardEvent: KeyboardEvent): void {
    if (keyboardEvent.key === 'Escape' && !keyboardEvent.defaultPrevented) {
      keyboardEvent.preventDefault();
      onClose();
      anchor.focus({ preventScroll: true });
    }
  }

  $: if (anchor) void positionCard();

  onMount(() => {
    // The portal lives in the body while its source route may stay mounted.
    const owner = getPresentedRoute();
    const unsubscribe = presentedRoute.subscribe(route => {
      if (route !== owner) { onClose(); }
    });
    const reposition = () => void positionCard();
    window.addEventListener('scroll', reposition, true);
    return () => {
      unsubscribe();
      window.removeEventListener('scroll', reposition, true);
    };
  });

  onDestroy(() => {
    positionGeneration += 1;
  });
</script>

<svelte:window
  on:keydown={handleKeydown}
  on:resize={() => void positionCard()}
/>

<aside
  bind:this={card}
  use:portal
  use:hoverSurface
  data-testid="profile-hover-card"
  data-positioned={positioned ? 'true' : 'false'}
  class="fixed z-[70] rounded-2xl bg-[var(--iris-surface-raised)] p-4 text-[rgb(var(--iris-text-rgb))] shadow-[0_20px_55px_rgba(0,0,0,0.45)]"
  style={`left:${left}px;top:${top}px;width:${width}px;opacity:${positioned ? 1 : 0};`}
>
  <div class="flex min-w-0 items-center justify-between gap-3">
    <a
      data-testid="profile-hover-link"
      href={profileHref(pubkey)}
      class="flex min-w-0 items-center gap-3 no-underline"
      on:click={openProfile}
      on:auxclick={(event) => { if (event.button === 1) onSelectProfile?.(pubkey); }}
    >
      <Avatar {pubkey} {profile} size={52} />
      <Username
        {pubkey}
        {profile}
        showSubtitle={false}
        titleClass="truncate text-[1.05rem] font-700 text-[rgb(var(--iris-text-rgb))]"
      />
    </a>

    {#if viewerPubkey && viewerPubkey !== pubkey && onToggleFollow}
      <button
        data-testid="profile-hover-follow"
        type="button"
        aria-busy={followPending}
        disabled={followPending}
        class={'shrink-0 rounded-full px-4 py-2 text-[0.85rem] font-700 transition disabled:cursor-wait disabled:opacity-55 '
          + (following
            ? 'bg-[var(--iris-surface-active)] hover:bg-[var(--iris-surface-hover)]'
            : 'iris-preserve-white-text bg-gradient-to-t from-violet-800 to-violet-600 text-white hover:brightness-110')}
        on:click={() => onToggleFollow?.(pubkey, !following)}
      >
        {followPending ? 'Updating…' : following ? 'Following' : 'Follow'}
      </button>
    {/if}
  </div>

  {#if profile?.about?.trim()}
    <div
      data-testid="profile-hover-about"
      class="mt-3 line-clamp-4 whitespace-pre-wrap break-words text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.75)]"
    >
      <ProfileText
        text={profile.about}
        {profiles}
        {onOpenProfile}
        {onOpenThread}
      />
    </div>
  {/if}

  {#if (followedBy && followedBy.total > 0) || followsViewer}
    <div class="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2 text-[0.82rem] text-[rgb(var(--iris-text-rgb)/0.65)]">
      {#if followedBy && followedBy.total > 0}
        <span data-testid="profile-hover-followed-by" class="flex min-w-0 items-center gap-2">
          <span class="flex shrink-0 -space-x-2">
            {#each followedBy.pubkeys as key (key)}
              <span class="rounded-full ring-2 ring-[var(--iris-surface-raised)]">
                <Avatar pubkey={key} profile={profiles.get(key) ?? $sharedProfilesStore.get(key) ?? null} size={22} />
              </span>
            {/each}
          </span>
          <span class="min-w-0 truncate">
            Followed by {followedByNames.join(', ')}{followedBy.total > followedByNames.length
              ? ` and ${followedBy.total - followedByNames.length} other${followedBy.total - followedByNames.length === 1 ? '' : 's'}` : ''}
          </span>
        </span>
      {/if}
      {#if followsViewer}
        <span data-testid="profile-hover-follows-you" class="rounded-full bg-[var(--iris-surface-active)] px-2 py-0.5 text-[0.75rem] font-600">Follows you</span>
      {/if}
    </div>
  {/if}
</aside>
