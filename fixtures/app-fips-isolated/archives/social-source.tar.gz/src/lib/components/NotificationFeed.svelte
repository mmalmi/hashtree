<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Action } from 'svelte/action';
  import type { NotificationItem } from '../appDetailLoaders';
  import { waitForNextBrowserPaint } from '../asyncTiming';
  import { observeElementResize } from '../elementResize';
  import { formatRelativeTime, getProfileTitle, type ProfileRecord } from '../nostr';
  import { formatCompactStat } from '../noteEngagement';
  import { groupNotificationItems, type NotificationGroup } from '../notificationGrouping';
  import { sharedProfilesStore } from '../profileCache';
  import { noteHref, profileHref } from '../routes';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import NoteText from './NoteText.svelte';

  export let items: NotificationItem[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let loading = false;
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMore: (() => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: (target: string) => void = () => undefined;

  const MAX_STACKED_AVATARS = 5;
  const KIND_STYLE: Record<NotificationItem['kind'], { icon: string; color: string }> = {
    like: { icon: 'heart-solid', color: 'text-pink-500' },
    repost: { icon: 'repeat', color: 'text-green-500' },
    zap: { icon: 'zap-solid', color: 'text-yellow-500' },
    reply: { icon: 'message-chat-circle', color: 'text-sky-500' },
    mention: { icon: 'at-sign', color: 'text-violet-400' },
  };
  const graphemes = typeof Intl !== 'undefined' && 'Segmenter' in Intl
    ? new Intl.Segmenter(undefined, { granularity: 'grapheme' })
    : null;

  let emptyStateReady = false;
  let emptyStatePending = false;
  let emptyStateVersion = 0;

  async function prepareEmptyState(): Promise<void> {
    const version = ++emptyStateVersion;
    emptyStatePending = true;
    await waitForNextBrowserPaint();
    if (version !== emptyStateVersion || loading || items.length > 0) {
      return;
    }
    emptyStatePending = false;
    emptyStateReady = true;
  }

  $: if (loading || items.length > 0) {
    emptyStateVersion += 1;
    emptyStatePending = false;
    emptyStateReady = false;
  } else if (!emptyStateReady && !emptyStatePending) {
    void prepareEmptyState();
  }

  onDestroy(() => {
    emptyStateVersion += 1;
  });

  function actionLabel(group: NotificationGroup): string {
    switch (group.kind) {
      case 'reply': return 'replied';
      case 'mention': return 'mentioned you';
      case 'repost': return 'reposted your post';
      case 'zap': return 'zapped your post';
      default: return 'reacted to your post';
    }
  }

  function excerpt(content: string): string {
    const trimmed = content.trim().replace(/\s+/g, ' ');
    if (trimmed.length <= 280) {
      return trimmed;
    }
    return `${trimmed.slice(0, 277)}…`;
  }

  /** Iris Client shows a short reaction on the reactor's avatar. */
  function reactionBadge(item: NotificationItem): { text: string } | { url: string; alt: string } | null {
    if (item.kind !== 'like') {return null;}
    const content = item.actorEvent.content.trim();
    if (!content || content === '+') {return { text: '❤️' };}
    if (content === '-') {return { text: '👎' };}
    const shortcode = /^:([\w-]+):$/.exec(content)?.[1];
    if (shortcode) {
      const url = item.actorEvent.tags.find((tag) => tag[0] === 'emoji' && tag[1] === shortcode)?.[2];
      return url?.startsWith('https://') ? { url, alt: content } : null;
    }
    const count = graphemes ? [...graphemes.segment(content)].length : [...content].length;
    return count === 1 && content.length <= 16 ? { text: content } : null;
  }

  function openTarget(group: NotificationGroup): string {
    return group.kind === 'reply' || group.kind === 'mention' ? group.latest.id : group.targetRef;
  }

  function handleRowClick(event: MouseEvent, group: NotificationGroup): void {
    if (
      event.defaultPrevented
      || event.button !== 0
      || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey
      || (event.target instanceof Element && event.target.closest('a, button, summary, details, input, video, audio'))
      || window.getSelection()?.toString()
    ) {
      return;
    }
    onOpenNote(openTarget(group));
  }

  function handleNoteLink(event: MouseEvent, target: string): void {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
      return;
    }
    event.preventDefault();
    onOpenNote(target);
  }

  /** Long notes fade out; the row opens the full thread, like Iris Client. */
  const fadeOverflow: Action<HTMLDivElement> = (node) => {
    const update = () => {
      node.toggleAttribute('data-overflowing', node.scrollHeight > node.clientHeight + 2);
    };
    const stop = observeElementResize(node.firstElementChild ?? node, update);
    update();
    return { destroy: stop };
  };

  $: groups = groupNotificationItems(items);
  $: resolveProfile = (pubkey: string): ProfileRecord | null => (
    $sharedProfilesStore.get(pubkey) ?? profiles.get(pubkey) ?? null
  );
</script>

<section data-testid="notifications-feed" aria-busy={loading} class="grid grid-cols-[minmax(0,1fr)] gap-0">
  {#if items.length === 0}
    {#if emptyStateReady}
      <div class="px-4 py-10 text-center text-[0.98rem] text-[rgb(var(--iris-text-rgb)/0.6)] sm:px-5">
        No notifications yet.
      </div>
    {/if}
  {:else}
    {#each groups as group (group.id)}
      {@const style = KIND_STYLE[group.kind]}
      {@const lead = group.items[0] ?? group.latest}
      {@const others = group.items.length - 1}
      <!-- svelte-ignore a11y_click_events_have_key_events a11y_no_noninteractive_element_interactions -->
      <article
        data-testid="notification-item"
        data-notification-id={group.latest.id}
        data-notification-kind={group.kind}
        data-notification-count={group.items.length}
        class="min-w-0 cursor-pointer border-b border-divider px-4 py-4 transition-colors hover:bg-[var(--iris-surface-hover)] md:px-8"
        on:click={(event) => handleRowClick(event, group)}
      >
        <div class="flex gap-3">
          <IrisIcon name={style.icon} size={20} className={`mt-1.5 ${style.color}`} />

          <div class="min-w-0 flex-1">
            <div class="flex items-start justify-between gap-3">
              <div class="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1.5">
                <div class="flex shrink-0 items-center">
                  {#each group.items.slice(0, MAX_STACKED_AVATARS) as item, index (item.actorEvent.pubkey)}
                    {@const badge = reactionBadge(item)}
                    {@const zapBits = group.bitsByActor.get(item.actorEvent.pubkey) ?? 0}
                    <a
                      data-testid="notification-avatar"
                      href={profileHref(item.actorEvent.pubkey)}
                      aria-label={`Open profile for ${getProfileTitle(resolveProfile(item.actorEvent.pubkey), item.actorEvent.pubkey)}`}
                      class={`relative rounded-full ring-2 ring-[var(--iris-surface)] ${index > 0 ? '-ml-2' : ''}`}
                      style={`z-index:${MAX_STACKED_AVATARS - index};`}
                      on:click|preventDefault={() => onOpenProfile(item.actorEvent.pubkey)}
                    >
                      <Avatar
                        pubkey={item.actorEvent.pubkey}
                        profile={resolveProfile(item.actorEvent.pubkey)}
                        size={32}
                        showBadge={false}
                      />
                      {#if group.kind === 'zap' && zapBits > 0}
                        <span class="absolute -right-1.5 -bottom-1 rounded-full bg-yellow-400 px-1 text-[0.6rem] leading-[0.95rem] font-800 text-black">
                          {formatCompactStat(zapBits)}
                        </span>
                      {:else if badge && 'text' in badge}
                        <span class="absolute -right-1 -bottom-1 grid h-4.5 w-4.5 place-items-center overflow-hidden rounded-full bg-[var(--iris-surface-raised)] text-[0.66rem] leading-none">
                          {badge.text}
                        </span>
                      {:else if badge}
                        <img src={badge.url} alt={badge.alt} class="absolute -right-1 -bottom-1 h-4.5 w-4.5 rounded-full bg-[var(--iris-surface-raised)] object-contain" />
                      {/if}
                    </a>
                  {/each}
                </div>
                <span class="min-w-0 text-[0.94rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.72)]">
                  {#if group.reactedPosts.length}
                    <a
                      href={profileHref(lead.actorEvent.pubkey)}
                      class="font-700 text-[rgb(var(--iris-text-rgb))] hover:underline"
                      on:click|preventDefault={() => onOpenProfile(lead.actorEvent.pubkey)}
                    >{getProfileTitle(resolveProfile(lead.actorEvent.pubkey), lead.actorEvent.pubkey)}</a>
                    reacted to {group.reactedPosts.length} posts
                  {:else}
                    <a
                      href={profileHref(lead.actorEvent.pubkey)}
                      class="font-700 text-[rgb(var(--iris-text-rgb))] hover:underline"
                      on:click|preventDefault={() => onOpenProfile(lead.actorEvent.pubkey)}
                    >{getProfileTitle(resolveProfile(lead.actorEvent.pubkey), lead.actorEvent.pubkey)}</a>
                    {#if others > 0}
                      and <span class="font-700 text-[rgb(var(--iris-text-rgb))]">{others} {others === 1 ? 'other' : 'others'}</span>
                    {/if}
                    {actionLabel(group)}
                    {#if group.kind === 'zap' && group.bits > 0}
                      <span data-testid="notification-zap-total" class="font-700 text-yellow-500">{group.bits.toLocaleString()} bits</span>
                    {/if}
                  {/if}
                </span>
              </div>
              <a
                href={noteHref(openTarget(group))}
                class="shrink-0 pt-1 text-[0.8rem] text-[rgb(var(--iris-text-rgb)/0.45)] hover:underline"
                on:click={(event) => handleNoteLink(event, openTarget(group))}
              >
                <time datetime={new Date(group.latest.actorEvent.created_at * 1000).toISOString()}>
                  {formatRelativeTime(group.latest.actorEvent.created_at)}
                </time>
              </a>
            </div>

            {#if group.reactedPosts.length}
              <details class="mt-2 text-[0.92rem] text-[rgb(var(--iris-text-rgb)/0.76)]">
                <summary class="w-fit cursor-pointer rounded-full px-3 py-1 font-600 transition hover:bg-[var(--iris-surface-raised)]">View posts</summary>
                <ul class="mt-2 grid list-none gap-1 rounded-xl bg-[var(--iris-surface-raised)] p-2 pl-2">
                  {#each group.reactedPosts as item (item.targetRef)}
                    {@const badge = reactionBadge(item)}
                    <li class="flex min-w-0 items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-[var(--iris-surface-hover)]">
                      <span aria-hidden="true" class="w-5 shrink-0 text-center">{badge && 'text' in badge ? badge.text : '❤️'}</span>
                      <a
                        href={noteHref(item.targetRef)}
                        class="min-w-0 truncate hover:underline"
                        on:click={(event) => handleNoteLink(event, item.targetRef)}
                      >{item.targetEvent?.content.trim() ? excerpt(item.targetEvent.content) : `Post · ${item.targetRef.slice(0, 12)}…`}</a>
                    </li>
                  {/each}
                </ul>
              </details>
            {:else if group.kind === 'reply' || group.kind === 'mention'}
              <div class="notification-text mt-2 max-h-[14rem] overflow-hidden" use:fadeOverflow>
                <NoteText
                  event={group.latest.actorEvent}
                  profile={resolveProfile(group.latest.actorEvent.pubkey)}
                  {profiles}
                  {onOpenProfile}
                  compact={true}
                  collapsible={false}
                />
              </div>
            {:else}
              <a
                data-testid="notification-target"
                href={noteHref(group.targetRef)}
                class="mt-2.5 flex min-h-[4.25rem] items-start rounded-xl bg-[var(--iris-surface-raised)] px-3.5 py-2.5 transition-colors hover:bg-[var(--iris-surface-hover)]"
                on:click={(event) => handleNoteLink(event, group.targetRef)}
              >
                {#if group.targetEvent?.content.trim()}
                  <span class="line-clamp-2 break-words text-[0.92rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.7)] [overflow-wrap:anywhere]">
                    {excerpt(group.targetEvent.content)}
                  </span>
                {:else}
                  <span class="block text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.45)]">
                    {group.targetEvent ? 'View post' : 'Loading post…'}
                  </span>
                {/if}
              </a>
            {/if}
          </div>
        </div>
      </article>
    {/each}
  {/if}

  {#if hasMore || loadPending}
    <div class="grid gap-0 px-4 py-4 sm:px-5">
      <button
        data-testid="notifications-load-more"
        type="button"
        class="mx-auto rounded-full bg-[var(--iris-surface-raised)] px-4 py-2 text-[0.88rem] font-700 text-[rgb(var(--iris-text-rgb)/0.72)] transition hover:bg-[var(--iris-surface-hover)] hover:text-[rgb(var(--iris-text-rgb))] disabled:cursor-wait disabled:opacity-70"
        disabled={loadPending || !hasMore}
        on:click={() => onLoadMore?.()}
      >
        {loadPending ? 'Loading notifications…' : 'Load more notifications'}
      </button>
      {#if infiniteScroll}
        <div
          data-testid="notifications-sentinel"
          use:infiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>

<style>
  .notification-text:global([data-overflowing]) {
    -webkit-mask-image: linear-gradient(to bottom, #000 72%, transparent);
    mask-image: linear-gradient(to bottom, #000 72%, transparent);
  }
</style>
