<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Action } from 'svelte/action';
  import type { NotificationItem } from '../appDetailLoaders';
  import { waitForNextBrowserPaint } from '../asyncTiming';
  import { formatRelativeTime, type ProfileRecord } from '../nostr';
  import { groupNotificationItems, type NotificationGroup } from '../notificationGrouping';
  import { profileHref } from '../routes';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';

  export let items: NotificationItem[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let loading = false;
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMore: (() => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: (target: string) => void = () => undefined;

  let emptyStateReady = false;
  let emptyStatePending = false;
  let emptyStateVersion = 0;

  async function prepareEmptyState(): Promise<void> {
    const version = ++emptyStateVersion;
    emptyStatePending = true;
    await waitForNextBrowserPaint();
    if (version !== emptyStateVersion || loading || items.length > 0) {
      return;
    }
    emptyStatePending = false;
    emptyStateReady = true;
  }

  $: if (loading || items.length > 0) {
    emptyStateVersion += 1;
    emptyStatePending = false;
    emptyStateReady = false;
  } else if (!emptyStateReady && !emptyStatePending) {
    void prepareEmptyState();
  }

  onDestroy(() => {
    emptyStateVersion += 1;
  });

  function labelFor(kind: NotificationItem['kind']): string {
    if (kind === 'reply') {
      return 'replied';
    }
    if (kind === 'repost') {
      return 'reposted';
    }
    if (kind === 'mention') {
      return 'mentioned you';
    }
    if (kind === 'zap') {
      return 'zapped';
    }
    return 'liked';
  }

  function excerpt(content: string): string {
    const trimmed = content.trim().replace(/\s+/g, ' ');
    if (trimmed.length <= 150) {
      return trimmed || 'Post';
    }
    return `${trimmed.slice(0, 147)}...`;
  }

  function groupExcerpt(group: NotificationGroup): string {
    return excerpt(group.targetEvent?.content ?? group.latest.targetEvent?.content ?? '');
  }

  $: groups = groupNotificationItems(items);
</script>

<section data-testid="notifications-feed" aria-busy={loading} class="grid gap-0">
  {#if items.length === 0}
    {#if emptyStateReady}
      <div class="px-4 py-7 text-[0.98rem] text-[rgb(var(--iris-text-rgb)/0.68)] sm:px-5">
        No notifications yet.
      </div>
    {/if}
  {:else}
    {#each groups as group (group.id)}
      <article
        data-testid="notification-item"
        data-notification-id={group.latest.id}
        data-notification-kind={group.kind}
        data-notification-count={group.items.length}
        class="border-b border-[var(--iris-border-subtle)] px-4 py-4 transition hover:bg-[var(--iris-surface-hover)] md:px-8"
      >
        <div class="flex gap-3">
          <div class="mt-2 flex h-7 w-7 shrink-0 items-center justify-center">
            {#if group.kind === 'reply'}
              <IrisIcon name="reply" size={20} className="text-blue-500" />
            {:else if group.kind === 'mention'}
              <IrisIcon name="at-sign" size={20} className="text-violet-400" />
            {:else if group.kind === 'repost'}
              <IrisIcon name="repost" size={20} className="text-green-500" />
            {:else if group.kind === 'zap'}
              <IrisIcon name="zap-solid" size={20} className="text-yellow-500" />
            {:else}
              <IrisIcon name="heart-solid" size={20} className="text-pink-500" />
            {/if}
          </div>

          <div class="min-w-0 flex-1">
            <div class="flex items-start justify-between gap-3">
              <div class="flex min-w-0 flex-wrap items-center gap-1.5">
                {#each group.items.slice(0, 5) as item (item.actorEvent.pubkey)}
                  <a
                    data-testid="notification-avatar"
                    href={profileHref(item.actorEvent.pubkey)}
                    aria-label="Open profile"
                    class="rounded-full"
                    on:click|preventDefault={() => onOpenProfile(item.actorEvent.pubkey)}
                  >
                    <Avatar
                      pubkey={item.actorEvent.pubkey}
                      profile={profiles.get(item.actorEvent.pubkey) ?? null}
                      size={34}
                    />
                  </a>
                {/each}
                {#if group.items.length > 5}
                  <span class="ml-1 text-[0.86rem] font-700 text-[rgb(var(--iris-text-rgb)/0.76)]">
                    and {group.items.length - 5} others
                  </span>
                {/if}
                <span class="ml-1 text-[0.88rem] font-700 text-[rgb(var(--iris-text-rgb))]">
                  {labelFor(group.kind)}
                  {#if group.kind === 'zap' && group.bits}
                    <span class="font-500 text-[rgb(var(--iris-text-rgb)/0.59)]"> {group.bits.toLocaleString()} bits</span>
                  {/if}
                </span>
              </div>
              <time class="shrink-0 pt-1 text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.4)]">
                {formatRelativeTime(group.latest.actorEvent.created_at)}
              </time>
            </div>

            <button
              type="button"
              class="mt-2 block w-full bg-transparent py-2 text-left"
              on:click={() => onOpenNote(group.targetRef)}
            >
              <div class="line-clamp-3 text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.68)]">
                {groupExcerpt(group)}
              </div>
            </button>
          </div>
        </div>
      </article>
    {/each}
  {/if}

  {#if hasMore || loadPending}
    <div class="grid gap-0 px-4 py-3 sm:px-5">
      <button
        data-testid="notifications-load-more"
        type="button"
        class="mx-auto rounded-full border border-[var(--iris-border-subtle)] px-4 py-2 text-[0.88rem] font-700 text-[rgb(var(--iris-text-rgb)/0.76)] transition hover:bg-[var(--iris-surface-hover)] hover:text-[rgb(var(--iris-text-rgb))] disabled:cursor-wait disabled:opacity-60"
        disabled={loadPending || !hasMore}
        on:click={() => onLoadMore?.()}
      >
        {loadPending ? 'Loading notifications…' : 'Load more notifications'}
      </button>
      {#if infiniteScroll}
        <div
          data-testid="notifications-sentinel"
          use:infiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>
