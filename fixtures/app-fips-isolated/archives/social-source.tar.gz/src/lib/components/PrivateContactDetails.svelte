<script lang="ts">
  import { contactMemoryStore } from '../contactMemoryStore';
  import PrivateContactSyncStatus from './PrivateContactSyncStatus.svelte';

  export let pubkey: string;
  let open = false;
  let nickname = '';
  let note = '';
  let initialNickname = '';
  let initialNote = '';
  let editingContact = '';
  let saving = false;
  let error = '';
  $: memory = $contactMemoryStore.contacts.get(pubkey);
  $: identity = `${$contactMemoryStore.viewer}:${pubkey}`;
  $: if (!open || editingContact !== identity) {
    editingContact = identity;
    nickname = initialNickname = memory?.nickname ?? '';
    note = initialNote = memory?.note ?? '';
    error = '';
  }

  async function save(): Promise<void> {
    const editingIdentity = identity;
    saving = true;
    error = '';
    try {
      await contactMemoryStore.details(pubkey, {
        ...(nickname !== initialNickname ? { nickname } : {}),
        ...(note !== initialNote ? { note } : {}),
      });
      if (identity === editingIdentity) { open = false; }
    } catch {
      if (identity === editingIdentity) { error = 'Could not save your changes. Please try again.'; }
    } finally { saving = false; }
  }
</script>

{#if $contactMemoryStore.viewer && $contactMemoryStore.viewer !== pubkey}
  <details bind:open data-testid="private-contact-details" class="text-sm text-white/60">
    <summary class="w-fit cursor-pointer" title="Only you can see this">Private details</summary>
    <form class="mt-3 grid gap-3" on:submit|preventDefault={save}>
      <PrivateContactSyncStatus />
      <label class="grid gap-1.5">
        <span>Nickname</span>
        <input aria-label="Private nickname" data-testid="private-contact-nickname" bind:value={nickname} maxlength="80"
          class="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-white focus:border-white/30 focus:outline-none" />
      </label>
      <label class="grid gap-1.5">
        <span>Note</span>
        <textarea aria-label="Private note" data-testid="private-contact-note" bind:value={note} maxlength="240" rows="3"
          class="w-full resize-y rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-white focus:border-white/30 focus:outline-none"></textarea>
      </label>
      <div class="flex items-center gap-3">
        <button type="submit" data-testid="private-contact-save" disabled={saving}
          class="rounded-full bg-[var(--iris-solid)] px-4 py-2 text-xs font-700 text-[var(--iris-on-solid)] disabled:opacity-50">{saving ? 'Saving…' : 'Save'}</button>
        <button type="button" disabled={saving} on:click={() => open = false} class="px-2 py-2 text-xs">Cancel</button>
      </div>
      {#if error}<p role="alert" class="text-xs text-red-400">{error}</p>{/if}
    </form>
  </details>
{/if}
