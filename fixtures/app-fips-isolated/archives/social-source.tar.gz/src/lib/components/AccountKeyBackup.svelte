<script lang="ts">
  import { onMount } from 'svelte';
  import type { SocialAccount } from '../accounts';
  import { getRouteActivity } from '../routeActivity';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';

  export let account: SocialAccount;

  const routeActivity = getRouteActivity();
  let open = false;
  let revealed = false;
  let copied = false;
  let error = '';
  let openedPubkey: string | null = null;
  let operation = 0;

  $: hasLocalKey = Boolean(account.nsec)
    && (account.method === 'generated' || account.method === 'nsec');
  $: if (open && (!$routeActivity || !hasLocalKey || openedPubkey !== account.pubkey)) {
    close();
  }

  function close(): void {
    operation += 1;
    open = false;
    revealed = false;
    copied = false;
    error = '';
    openedPubkey = null;
  }

  function openBackup(): void {
    if (!$routeActivity || !hasLocalKey || document.visibilityState === 'hidden') return;
    openedPubkey = account.pubkey;
    open = true;
  }

  function reveal(): void {
    if (open && $routeActivity && hasLocalKey && document.visibilityState !== 'hidden') {
      revealed = true;
    }
  }

  function hideKey(): void {
    operation += 1;
    revealed = false;
    copied = false;
    error = '';
  }

  async function copyKey(): Promise<void> {
    if (!open || !revealed || !account.nsec) return;
    const request = ++operation;
    error = '';
    try {
      await navigator.clipboard.writeText(account.nsec);
      if (request === operation && open) copied = true;
    } catch {
      if (request === operation && open) error = 'Copy failed. Select the key or download it.';
    }
  }

  function downloadKey(): void {
    if (!open || !revealed || !account.nsec) return;
    error = '';
    let url: string | null = null;
    try {
      url = URL.createObjectURL(new Blob([`${account.nsec}\n`], { type: 'text/plain' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `iris-account-${account.npub.slice(0, 16)}.txt`;
      link.click();
    } catch {
      error = 'Download failed. Copy the key instead.';
    } finally {
      if (url) {
        const downloadUrl = url;
        window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 0);
      }
    }
  }

  onMount(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') close();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', close);
    return () => {
      close();
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', close);
    };
  });
</script>

{#if hasLocalKey}
  <button
    type="button"
    class="justify-self-start px-1 py-1 text-[0.9rem] font-600 text-[rgb(var(--iris-text-rgb)/0.7)] transition hover:text-[rgb(var(--iris-text-rgb))]"
    on:click={openBackup}
  >Back up secret key</button>
{/if}

<ModalShell {open} onClose={close}>
  <div
    data-testid="account-backup-dialog"
    role="dialog"
    aria-modal="true"
    aria-labelledby="account-backup-title"
    tabindex="-1"
    class="w-full max-w-[28rem] rounded-[24px] border border-[rgb(var(--iris-text-rgb)/0.1)] bg-[var(--iris-canvas)] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.35)]"
  >
    <div class="flex items-center justify-between gap-3">
      <h2 id="account-backup-title" class="text-lg font-700">Back up your account</h2>
      <button type="button" aria-label="Close account backup" class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[var(--iris-surface)]" on:click={close}>
        <IrisIcon name="x-close" size={18} />
      </button>
    </div>
    <p class="mt-3 text-sm leading-6 text-[rgb(var(--iris-text-rgb)/0.65)]">Keep this key somewhere safe. Anyone with it can use your account.</p>
    {#if revealed && account.nsec}
      <label for="account-secret-key" class="mb-2 mt-4 block text-sm font-600">Secret key</label>
      <textarea
        id="account-secret-key"
        data-testid="account-secret-key"
        readonly
        spellcheck="false"
        autocomplete="off"
        value={account.nsec}
        rows="3"
        class="w-full resize-none rounded-xl bg-[var(--iris-surface)] p-3 font-mono text-sm leading-6"
        on:focus={(event) => event.currentTarget.select()}
      ></textarea>
      <div class="mt-4 flex flex-wrap gap-2">
        <button type="button" aria-label="Copy secret key" class="rounded-full bg-[var(--iris-solid)] px-4 py-2 text-sm font-700 text-[var(--iris-on-solid)]" on:click={() => void copyKey()}>{copied ? 'Copied' : 'Copy key'}</button>
        <button type="button" aria-label="Download secret key" class="rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] px-4 py-2 text-sm font-700" on:click={downloadKey}>Download</button>
        <button type="button" class="px-3 py-2 text-sm text-[rgb(var(--iris-text-rgb)/0.65)]" on:click={hideKey}>Hide key</button>
      </div>
    {:else}
      <button type="button" class="mt-4 rounded-full bg-[var(--iris-solid)] px-4 py-2 text-sm font-700 text-[var(--iris-on-solid)]" on:click={reveal}>Reveal secret key</button>
    {/if}
    {#if error}<p role="alert" class="mt-3 text-sm text-red-400">{error}</p>{/if}
  </div>
</ModalShell>
