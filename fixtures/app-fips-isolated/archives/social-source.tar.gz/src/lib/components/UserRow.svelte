<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import Avatar from './Avatar.svelte';
  import ProfileHoverCard from './ProfileHoverCard.svelte';
  import Username from './Username.svelte';
  import type { ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';
  import { activeModalCount } from '../modalStack';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let timestamp: number | null = null;
  export let avatarSize = 52;
  export let fallbackSubtitle = '';
  export let showSubtitle = true;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onSelectProfile: ((pubkey: string) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let viewerPubkey: string | null = null;
  export let following = false;
  export let followPending = false;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let showHoverCard = true;
  export let className = '';
  export let gapClass = 'gap-3';
  export let titleClass = 'truncate text-[1rem] font-700 text-white';
  export let subtitleClass = 'mt-1 truncate text-[0.84rem] text-white/55';
  export let timeClass = 'text-sm text-white/45';
  $: interactive = typeof onOpenProfile === 'function';

  let rootElement: HTMLDivElement | null = null;
  let hoverCapable = false;
  let hoverOpen = false;
  let hoverTimer: ReturnType<typeof setTimeout> | null = null;

  $: if ($activeModalCount > 0) {
    clearHoverTimer();
    hoverOpen = false;
  }

  function clearHoverTimer(): void {
    if (hoverTimer !== null) {
      clearTimeout(hoverTimer);
      hoverTimer = null;
    }
  }

  function openHoverCard(delay = 300): void {
    if (!showHoverCard || !hoverCapable || $activeModalCount > 0) {
      return;
    }
    clearHoverTimer();
    hoverTimer = setTimeout(() => {
      hoverTimer = null;
      hoverOpen = true;
    }, delay);
  }

  function closeHoverCard(delay = 220): void {
    clearHoverTimer();
    hoverTimer = setTimeout(() => {
      hoverTimer = null;
      hoverOpen = false;
    }, delay);
  }

  function keepHoverCardOpen(): void {
    clearHoverTimer();
    hoverOpen = $activeModalCount === 0;
  }

  function hoverCardTrigger(node: HTMLDivElement) {
    const pointerEnter = (event: PointerEvent) => {
      if (event.pointerType === 'mouse') {
        openHoverCard();
      }
    };
    const pointerLeave = (event: PointerEvent) => {
      if (event.pointerType === 'mouse') {
        closeHoverCard();
      }
    };
    const focusIn = () => openHoverCard(0);
    const focusOut = () => closeHoverCard();
    node.addEventListener('pointerenter', pointerEnter);
    node.addEventListener('pointerleave', pointerLeave);
    node.addEventListener('focusin', focusIn);
    node.addEventListener('focusout', focusOut);
    return {
      destroy() {
        node.removeEventListener('pointerenter', pointerEnter);
        node.removeEventListener('pointerleave', pointerLeave);
        node.removeEventListener('focusin', focusIn);
        node.removeEventListener('focusout', focusOut);
      },
    };
  }

  onMount(() => {
    const hoverMedia = window.matchMedia('(hover: hover) and (pointer: fine)');
    const syncHoverCapability = () => {
      hoverCapable = hoverMedia.matches;
      if (!hoverCapable) {
        clearHoverTimer();
        hoverOpen = false;
      }
    };
    syncHoverCapability();
    hoverMedia.addEventListener('change', syncHoverCapability);
    return () => hoverMedia.removeEventListener('change', syncHoverCapability);
  });

  onDestroy(clearHoverTimer);
</script>

<div
  bind:this={rootElement}
  use:hoverCardTrigger
  class={`flex min-w-0 items-center ${gapClass} ${className}`.trim()}
>
  {#if interactive}
    <a
      href={profileHref(pubkey)}
      class="block rounded-full bg-transparent p-0 no-underline outline-none"
      aria-label="Open profile"
    >
      <Avatar {pubkey} {profile} size={avatarSize} />
    </a>
  {:else}
    <Avatar {pubkey} {profile} size={avatarSize} />
  {/if}

  <div class="min-w-0 flex-1">
    {#if interactive}
      <a
        href={profileHref(pubkey)}
        class="inline-block max-w-full bg-transparent p-0 text-left no-underline outline-none"
      >
        <Username
          {pubkey}
          {profile}
          {timestamp}
          {fallbackSubtitle}
          {showSubtitle}
          {titleClass}
          {subtitleClass}
          {timeClass}
        />
      </a>
    {:else}
      <Username
        {pubkey}
        {profile}
        {timestamp}
        {fallbackSubtitle}
        {showSubtitle}
        {titleClass}
        {subtitleClass}
        {timeClass}
      />
    {/if}
  </div>

  <slot name="end"></slot>
</div>

{#if hoverOpen && rootElement}
  <ProfileHoverCard
    anchor={rootElement}
    {pubkey}
    {profile}
    {profiles}
    {viewerPubkey}
    {following}
    {followPending}
    {onToggleFollow}
    {onOpenProfile}
    {onSelectProfile}
    {onOpenThread}
    onPointerEnter={keepHoverCardOpen}
    onPointerLeave={() => closeHoverCard()}
    onClose={() => {
      clearHoverTimer();
      hoverOpen = false;
    }}
  />
{/if}
