<script lang="ts">
  import { onDestroy } from 'svelte';
  import { canSearchPublicPeople, searchPublicPeople, type PublicPeopleSearchResult } from '../profileSearchRelay';
  import IrisIcon from './IrisIcon.svelte';

  export let query: string;
  export let onResults: (query: string, results: PublicPeopleSearchResult) => void;
  export let optionId: string | undefined = undefined;
  export let selected = false;

  let controller: AbortController | null = null;
  let loading = false;
  let status = '';
  onDestroy(() => controller?.abort());

  export async function search(): Promise<void> {
    if (controller) { return; }
    if (!canSearchPublicPeople(query)) {
      status = 'Public relay search is unavailable.';
      return;
    }
    const submitted = query;
    const request = new AbortController();
    controller = request;
    loading = true;
    status = '';
    try {
      const results = await searchPublicPeople(submitted, request.signal, undefined, undefined, partial => {
        if (!request.signal.aborted && query === submitted) { onResults(submitted, partial); }
      });
      if (request.signal.aborted || query !== submitted) { return; }
      onResults(submitted, results);
      if (results.profiles.length === 0) {
        status = results.complete ? 'No people found on the public relay.' : 'Public relay search is unavailable.';
      }
    } catch {
      if (!request.signal.aborted) { status = 'Public relay search is unavailable.'; }
    } finally {
      controller = null;
      loading = false;
    }
  }
</script>

<button
  type="button"
  id={optionId}
  role={optionId ? 'option' : undefined}
  aria-selected={optionId ? selected : undefined}
  aria-busy={loading}
  data-testid="search-public-people"
  data-active={selected}
  class={`flex w-full cursor-pointer items-center gap-3 rounded-[0.55rem] px-3 py-3 text-left ${selected
    ? 'iris-preserve-white-text bg-violet-600 text-white'
    : 'text-[rgb(var(--iris-text-rgb))] hover:bg-violet-500/15'}`}
  on:click={search}
>
  <IrisIcon name="profile" size={19} className="shrink-0 opacity-70" />
  <span class="truncate">{loading ? 'Searching public relays for people…' : status || 'Search public relays for people'}</span>
</button>
