<script lang="ts">
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';
  import UserRow from './UserRow.svelte';
  import Username from './Username.svelte';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { NoteDetailListKind } from '../nostrIndex';
  import type { NoteDetailHasMoreByKind } from '../appDetailLoaders';
  import { buildNoteDetailRows } from '../noteDetailPresentation';

  export let open = false;
  export let kind: NoteDetailListKind = 'likes';
  export let title = '';
  export let targetPubkey = '';
  export let targetProfile: ProfileRecord | null = null;
  export let eventsByKind: Record<NoteDetailListKind, RawEvent[]> = {
    likes: [],
    reposts: [],
    zaps: [],
  };
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let hasMoreByKind: NoteDetailHasMoreByKind = {
    likes: false,
    reposts: false,
    zaps: false,
  };
  export let loading = false;
  export let onClose: () => void = () => undefined;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onSelectKind: ((kind: NoteDetailListKind) => void) | null = null;
  export let onLoadMore: (() => void) | null = null;

  const tabs: Array<{ kind: NoteDetailListKind; label: string }> = [
    { kind: 'likes', label: 'Likes' },
    { kind: 'reposts', label: 'Reposts' },
    { kind: 'zaps', label: 'Zaps' },
  ];

  $: currentEvents = eventsByKind[kind] ?? [];
  $: resolvedTitle = title || 'Reactions';
  $: rows = buildNoteDetailRows(kind, currentEvents, profiles);

  function emptyText(activeKind: NoteDetailListKind): string {
    if (activeKind === 'reposts') {
      return 'No reposts yet';
    }
    if (activeKind === 'zaps') {
      return 'No zaps yet';
    }
    return 'No reactions yet';
  }

  function openActor(pubkey: string): void {
    onClose();
    onOpenProfile(pubkey);
  }
</script>

<ModalShell
  {open}
  {onClose}
  shellClass="items-center justify-center p-4 sm:p-6"
  contentClass="flex h-[min(620px,calc(100dvh-2rem))] w-full max-w-[430px] items-stretch"
>
  <div
    data-testid="note-detail-sheet"
    role="dialog"
    aria-modal="true"
    aria-label={resolvedTitle}
    class="flex min-h-0 w-full flex-col overflow-hidden rounded-2xl border border-[var(--iris-border-subtle)] bg-[var(--iris-surface)] shadow-2xl"
  >
    <header class="flex shrink-0 items-center gap-3 px-4 pb-3 pt-4">
      {#if targetPubkey}
        <div data-testid="note-detail-author-context" class="flex min-w-0 flex-1 items-center gap-3">
          <Avatar pubkey={targetPubkey} profile={targetProfile} size={40} />
          <div class="min-w-0 flex-1">
            <div class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.5)]">
              Reactions to post by
            </div>
            <Username
              pubkey={targetPubkey}
              profile={targetProfile}
              showSubtitle={false}
              titleClass="truncate text-[0.98rem] font-700 text-[rgb(var(--iris-text-rgb))]"
            />
          </div>
        </div>
      {:else}
        <div class="min-w-0 flex-1 text-[1rem] font-700 text-[rgb(var(--iris-text-rgb))]">
          {resolvedTitle}
        </div>
      {/if}

      <button
        data-testid="note-detail-close"
        type="button"
        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[rgb(var(--iris-text-rgb)/0.65)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] hover:text-[rgb(var(--iris-text-rgb))]"
        aria-label="Close"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={18} />
      </button>
    </header>

    <div role="tablist" aria-label="Reaction types" class="flex shrink-0 border-b border-[var(--iris-border-subtle)] px-2">
      {#each tabs as tab (tab.kind)}
        <button
          data-testid={`note-detail-tab-${tab.kind}`}
          type="button"
          role="tab"
          aria-selected={kind === tab.kind}
          class={`flex-1 border-b-2 px-3 py-3 text-[0.88rem] font-600 transition-colors ${
            kind === tab.kind
              ? 'border-violet-500 text-[rgb(var(--iris-text-rgb))]'
              : 'border-transparent text-[rgb(var(--iris-text-rgb)/0.55)] hover:text-[rgb(var(--iris-text-rgb))]'
          }`}
          on:click={() => onSelectKind?.(tab.kind)}
        >
          {tab.label}
        </button>
      {/each}
    </div>

    <div data-testid="note-detail-list" class="min-h-0 flex-1 overflow-y-auto overscroll-contain px-2 py-4">
      {#if loading && rows.length === 0}
        <p class="m-0 px-2 py-2 text-[0.92rem] text-[rgb(var(--iris-text-rgb)/0.55)]">
          Loading…
        </p>
      {:else if rows.length === 0}
        <p class="m-0 px-2 py-2 text-[0.92rem] text-[rgb(var(--iris-text-rgb)/0.55)]">
          {emptyText(kind)}
        </p>
      {:else}
        <div class="grid gap-1">
          {#each rows as row (row.actor)}
            <button
              data-testid="note-detail-row"
              type="button"
              class="w-full rounded-xl px-2 py-2 text-left transition-colors hover:bg-[var(--iris-surface-hover)]"
              on:click={() => openActor(row.actor)}
            >
              <UserRow
                pubkey={row.actor}
                profile={profiles.get(row.actor) ?? null}
                avatarSize={45}
                showSubtitle={false}
                onOpenProfile={null}
                gapClass="gap-2"
                titleClass="truncate text-[0.95rem] font-600 text-[rgb(var(--iris-text-rgb))]"
              >
                <span
                  slot="end"
                  class:hidden={!row.description}
                  class="max-w-[48%] shrink-0 truncate text-right text-[0.88rem] text-[rgb(var(--iris-text-rgb)/0.68)]"
                >
                  {row.description}
                </span>
              </UserRow>
            </button>
          {/each}
        </div>

        {#if hasMoreByKind[kind] && onLoadMore}
          <button
            data-testid="note-detail-load-more"
            type="button"
            class="mt-3 inline-flex min-h-10 w-full items-center justify-center rounded-xl px-4 text-[0.88rem] font-600 text-[rgb(var(--iris-text-rgb)/0.7)] transition-colors hover:bg-[var(--iris-surface-hover)] hover:text-[rgb(var(--iris-text-rgb))] disabled:cursor-wait disabled:opacity-50"
            disabled={loading}
            on:click={onLoadMore}
          >
            {loading ? 'Loading…' : 'Load more'}
          </button>
        {/if}
      {/if}
    </div>
  </div>
</ModalShell>
