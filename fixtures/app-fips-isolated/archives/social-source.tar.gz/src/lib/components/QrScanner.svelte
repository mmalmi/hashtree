<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import jsQR from 'jsqr';
  import { fitQrScanFrame, QR_SCAN_INTERVAL_MS } from '../qrScanner';

  export let onScan: (value: string) => void = () => undefined;

  let video: HTMLVideoElement | null = null;
  let canvas: HTMLCanvasElement | null = null;
  let stream: MediaStream | null = null;
  let scanTimer: ReturnType<typeof setTimeout> | null = null;
  let error = '';
  let stopped = false;

  function stopScanner(): void {
    stopped = true;
    if (scanTimer !== null) {
      clearTimeout(scanTimer);
      scanTimer = null;
    }
    stream?.getTracks().forEach((track) => track.stop());
    stream = null;
    if (video) {
      video.srcObject = null;
    }
  }

  function scheduleScan(): void {
    if (stopped) {
      return;
    }
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scanFrame();
    }, QR_SCAN_INTERVAL_MS);
  }

  function scanFrame(): void {
    if (stopped || !video || !canvas) {
      return;
    }

    if (
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA &&
      video.videoWidth > 0 &&
      video.videoHeight > 0
    ) {
      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (context) {
        const frameSize = fitQrScanFrame(video.videoWidth, video.videoHeight);
        if (canvas.width !== frameSize.width || canvas.height !== frameSize.height) {
          canvas.width = frameSize.width;
          canvas.height = frameSize.height;
        }
        context.drawImage(video, 0, 0, frameSize.width, frameSize.height);
        const frame = context.getImageData(0, 0, frameSize.width, frameSize.height);
        const code = jsQR(frame.data, frame.width, frame.height, { inversionAttempts: 'dontInvert' });
        if (code?.data) {
          const value = code.data;
          stopScanner();
          onScan(value);
          return;
        }
      }
    }

    scheduleScan();
  }

  onMount(() => {
    if (!navigator.mediaDevices?.getUserMedia) {
      error = 'Camera scanning is not supported by this browser.';
      return;
    }

    void navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
    }).then((nextStream) => {
      if (stopped || !video) {
        nextStream.getTracks().forEach((track) => track.stop());
        return;
      }
      stream = nextStream;
      video.srcObject = nextStream;
      void video.play().then(() => {
        scanFrame();
      }).catch(() => {
        error = 'Unable to start the camera.';
        stopScanner();
      });
    }).catch(() => {
      error = 'Unable to access the camera. Check the browser camera permission.';
    });
  });

  onDestroy(stopScanner);
</script>

<div class="relative h-full w-full overflow-hidden rounded-2xl bg-black">
  {#if error}
    <div class="grid h-full place-items-center px-6 text-center text-sm text-red-100">{error}</div>
  {:else}
    <video bind:this={video} muted playsinline class="h-full w-full object-cover"></video>
    <canvas bind:this={canvas} class="hidden"></canvas>
    <div class="pointer-events-none absolute inset-6 rounded-2xl border-2 border-white/80"></div>
  {/if}
</div>
