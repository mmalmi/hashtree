<script lang="ts">
  import { browserOnline, peerNetwork, relayConnections } from '../networkStatus';
  import { settingsHref } from '../routes';

  $: peers = $peerNetwork.peers.length;
  $: relays = [...($relayConnections?.values() ?? [])].filter(state => state === 'connected').length;
  $: connecting = [...($relayConnections?.values() ?? [])].some(state => state === 'connecting');
  $: state = !$browserOnline ? 'offline' : peers || relays ? 'connected'
    : connecting || $peerNetwork.status === 'starting' || !$relayConnections ? 'connecting' : 'disconnected';
  $: description = state === 'offline' ? 'Offline'
    : state === 'connecting' ? connecting ? 'Connecting to relays'
      : $peerNetwork.status === 'starting' ? 'Connecting to peers' : 'Checking connections'
    : `${peers} ${peers === 1 ? 'peer' : 'peers'}, ${relays} ${relays === 1 ? 'relay' : 'relays'} connected`;
</script>

<a
  data-testid="network-indicator"
  data-state={state}
  href={settingsHref('network')}
  aria-label={`Network: ${description}`}
  class="network-indicator pointer-events-auto relative z-10 grid h-10 w-8 shrink-0 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]"
>
  <span class="network-dot" aria-hidden="true"></span>
  <span class="network-tooltip" aria-hidden="true">{description}</span>
</a>

<style>
  .network-dot { inline-size: .55rem; block-size: .55rem; border-radius: 50%; background: #f08078; }
  [data-state='connecting'] .network-dot { background: #e6b85c; }
  [data-state='connected'] .network-dot { background: #49bd83; }
  :global([data-theme='light']) .network-dot { background: #a73730; }
  :global([data-theme='light']) [data-state='connecting'] .network-dot { background: #936600; }
  :global([data-theme='light']) [data-state='connected'] .network-dot { background: #197244; }
  .network-tooltip {
    display: none; position: absolute; z-index: 20; inset-block-start: calc(100% + .25rem); inset-inline-end: 0;
    width: max-content; max-width: min(80vw, 20rem); padding: .35rem .65rem; border-radius: .5rem;
    background: var(--iris-surface-raised); color: rgb(var(--iris-text-rgb)); font-size: .8rem;
    box-shadow: 0 .2rem .75rem rgb(0 0 0 / .18); pointer-events: none;
  }
  .network-indicator:is(:hover, :focus-visible) .network-tooltip { display: block; }
</style>
