<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';

  export let type: 'Audio' | 'Video' | 'Attachment';
  export let filename: string;
  export let loading = false;
  export let error = '';
  export let grid = false;

  $: status = loading ? (type === 'Attachment' ? 'Preparing download…' : 'Loading…') : error;
  $: icon = type === 'Audio' ? 'signal-01' : type === 'Video' ? 'play-square-outline' : 'file-06';
</script>

{#if grid}
  <IrisIcon name={icon} size={29} className="text-white/85" />
  <span class="sr-only">{type} · {filename}</span>
  <span aria-live="polite" title={status} class="absolute inset-x-1 bottom-1 truncate text-center text-xs">{status}</span>
{:else}
  <span class="block min-w-0 w-full">
    <span aria-live="polite" title={status || undefined}
      class={'block truncate text-xs leading-4 ' + (error ? 'text-[#ffb4b4]' : 'text-[rgb(var(--iris-text-rgb)/0.65)]')}
    >{status || type}</span>
    <span title={filename} class="block truncate text-[0.96rem] leading-5 text-[rgb(var(--iris-text-rgb))]">{filename}</span>
  </span>
{/if}
