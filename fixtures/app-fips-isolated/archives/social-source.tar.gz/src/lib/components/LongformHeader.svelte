<script lang="ts">
  import { getLongformMetadata } from '../longform';
  import type { RawEvent } from '../nostr';

  export let event: RawEvent;
  export let compact = false;
  export let showSummary = true;

  $: metadata = getLongformMetadata(event);
</script>

{#if metadata}
  <div data-testid="longform-header" class={`mb-2 grid gap-1 ${compact ? 'gap-0.5' : ''}`}>
    <div class={`${compact ? 'text-[1rem] leading-6' : 'text-[1.28rem] leading-8'} font-700 text-white`}>
      {metadata.title}
    </div>

    {#if metadata.summary && !compact && showSummary}
      <div class="line-clamp-3 text-[0.95rem] leading-6 text-white/62">
        {metadata.summary}
      </div>
    {/if}
  </div>
{/if}
