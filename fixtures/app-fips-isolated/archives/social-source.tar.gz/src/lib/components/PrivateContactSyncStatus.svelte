<script lang="ts">
  import { privateContactSyncStatus, retryPrivateContactSync, linkPrivateContactDevice } from '../privateContactSync';
  $: state = $privateContactSyncStatus;
  $: label = state.anotherTab ? 'Sync open in another tab'
    : state.status === 'ready' ? 'Private sync ready'
    : state.status === 'local-only' ? 'Saved on this device'
    : state.status === 'error' ? 'Sync unavailable'
    : 'Saved · Syncing…';
</script>

{#if state.owner}
  <div data-testid="private-contact-sync-status" class="flex min-h-6 flex-wrap items-center gap-x-3 gap-y-1 text-xs text-white/45" aria-live="polite">
    <span title={state.error || undefined}>{label}</span>
    {#if (state.needsApproval && state.canAuthorize) || state.status === 'error'}
      <button type="button" class="py-1 text-white/70 underline underline-offset-2" on:click={retryPrivateContactSync}>
        {state.needsApproval ? 'Enable private sync' : 'Retry'}
      </button>
    {/if}
    {#if state.needsApproval}
      <button type="button" class="py-1 text-white/70 underline underline-offset-2" on:click={linkPrivateContactDevice}>Link this device</button>
    {/if}
    {#if state.link}
      <div class="w-full py-1">
        <p>Open this link on a device you already use.</p>
        <input aria-label="Device link" class="mt-1 w-full rounded bg-white/5 p-2" readonly value={state.link} on:click={event => event.currentTarget.select()} />
      </div>
    {/if}
  </div>
{/if}
