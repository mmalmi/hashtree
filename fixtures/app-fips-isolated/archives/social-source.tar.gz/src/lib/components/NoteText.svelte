<script lang="ts">
  import { tick } from 'svelte';
  import InlineNoteQuote from './InlineNoteQuote.svelte';
  import Username from './Username.svelte';
  import { getProfileTitle, type ProfileRecord, type RawEvent } from '../nostr';
  import { getNotePresentation } from '../noteContent';
  import { sharedProfilesStore } from '../profileCache';
  import type { ReferencedNotePreview } from '../referencedNote';
  import { profileHref, searchHref, threadHref } from '../routes';
  import { observeElementResize } from '../elementResize';

  export let event: RawEvent;
  export let profile: ProfileRecord | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: ((target: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let compact = false;
  export let collapsible = true;
  export let isActive = true;

  const COLLAPSED_HEIGHT = {
    regular: 224,
    compact: 176,
  } as const;

  let textElement: HTMLDivElement | null = null;
  let expanded = false;
  let canExpand = false;
  let expandedEventId = '';

  $: segments = getNotePresentation(event).segments;
  $: collapsedHeight = compact ? COLLAPSED_HEIGHT.compact : COLLAPSED_HEIGHT.regular;
  $: if (event.id !== expandedEventId) {
    expanded = false;
    expandedEventId = event.id;
  }
  $: if (!collapsible) {
    canExpand = false;
    expanded = false;
  }
  $: if (isActive && collapsible && (event.id || compact || segments.length)) {
    void measureOverflow();
  }

  function handleMentionClick(mouseEvent: MouseEvent, pubkey: string): void {
    if (
      mouseEvent.button !== 0 ||
      mouseEvent.metaKey ||
      mouseEvent.ctrlKey ||
      mouseEvent.shiftKey ||
      mouseEvent.altKey
    ) {
      return;
    }

    mouseEvent.preventDefault();
    onOpenProfile(pubkey);
  }

  function resolveMentionProfile(pubkey: string): ProfileRecord | null {
    return $sharedProfilesStore.get(pubkey)
      ?? profiles.get(pubkey)
      ?? (profile?.pubkey === pubkey ? profile : null);
  }

  function mentionLabel(pubkey: string): string {
    return getProfileTitle(resolveMentionProfile(pubkey), pubkey);
  }

  function handleEventRefClick(mouseEvent: MouseEvent, target: string): void {
    if (
      mouseEvent.button !== 0 ||
      mouseEvent.metaKey ||
      mouseEvent.ctrlKey ||
      mouseEvent.shiftKey ||
      mouseEvent.altKey
    ) {
      return;
    }

    if (onOpenNote) {
      mouseEvent.preventDefault();
      onOpenNote(target);
    }
  }

  async function measureOverflow(): Promise<void> {
    await tick();
    if (!textElement || !isActive || !textElement.getClientRects().length) {
      return;
    }

    const nextCanExpand = textElement.scrollHeight > collapsedHeight + 4;
    canExpand = nextCanExpand;
    if (!nextCanExpand) {
      expanded = false;
    }
  }

  function observeResize(
    node: HTMLDivElement,
    initiallyEnabled: boolean,
  ): { update: (enabled: boolean) => void; destroy: () => void } {
    let enabled = initiallyEnabled;
    let stopObserving: (() => void) | null = null;
    const start = () => {
      if (!enabled || stopObserving) {
        return;
      }
      stopObserving = observeElementResize(node, () => {
        void measureOverflow();
      });
    };
    const stop = () => {
      stopObserving?.();
      stopObserving = null;
    };
    start();
    return {
      update(nextEnabled) {
        if (nextEnabled === enabled) {
          return;
        }
        enabled = nextEnabled;
        if (enabled) {
          start();
        } else {
          stop();
        }
      },
      destroy: stop,
    };
  }
</script>

<div class="min-w-0 max-w-full">
  <div class="relative">
    <div
      bind:this={textElement}
      use:observeResize={isActive && collapsible}
      class={`min-w-0 max-w-full whitespace-pre-wrap break-words [overflow-wrap:anywhere] ${
        compact ? 'text-[0.97rem] leading-6.5' : 'text-[1rem] leading-7'
      } text-white/82 ${collapsible && !expanded ? 'overflow-hidden' : ''}`}
      style={collapsible && !expanded ? `max-height:${collapsedHeight}px;` : undefined}
    >
      {#each segments as segment, index (`${segment.type}:${index}`)}
        {#if segment.type === 'text'}
          <span>{segment.text}</span>
        {:else if segment.type === 'mention'}
          <a
            data-testid="note-mention"
            href={profileHref(segment.pubkey)}
            class="inline text-[rgb(172,136,255)] underline decoration-transparent underline-offset-3 transition hover:text-white hover:decoration-current"
            aria-label={`Open ${mentionLabel(segment.pubkey)}`}
            on:click={(mouseEvent) => handleMentionClick(mouseEvent, segment.pubkey)}
          >
            <Username
              pubkey={segment.pubkey}
              profile={resolveMentionProfile(segment.pubkey)}
              inline={true}
              showSubtitle={false}
              titlePrefix="@"
              titleClass="inline"
            />
          </a>
        {:else if segment.type === 'hashtag'}
          <a data-testid="note-tag" href={searchHref(`#${segment.tag}`, 'posts')}
            class="text-[rgb(172,136,255)] underline decoration-transparent underline-offset-3 hover:decoration-current">#{segment.tag}</a>
        {:else if segment.type === 'emoji'}
          <img
            src={segment.url}
            alt={`:${segment.shortcode}:`}
            class="mx-[0.08em] inline-block h-[1.2em] w-[1.2em] align-[-0.18em]"
          />
        {:else if segment.type === 'event-ref'}
          {#if resolveReferencedNote && onOpenNote}
            <InlineNoteQuote
              bech32={segment.bech32}
              {onOpenNote}
              {onOpenProfile}
              {resolveReferencedNote}
            />
          {:else}
            <a
              data-testid="note-event-ref"
              href={threadHref(segment.bech32)}
              class="inline text-white/55 underline decoration-transparent underline-offset-3 transition hover:text-white hover:decoration-current"
              aria-label={`Open referenced note ${segment.label}`}
              on:click={(mouseEvent) => handleEventRefClick(mouseEvent, segment.bech32)}
            >
              {segment.label}
            </a>
          {/if}
        {:else if segment.type === 'link'}
          {#each segment.urls as url, urlIndex (`${url}:${urlIndex}`)}
            <a
              data-testid="note-link"
              href={url}
              target="_blank"
              rel="noreferrer noopener"
              class="max-w-full break-all [overflow-wrap:anywhere] text-[rgb(172,136,255)] underline decoration-transparent underline-offset-3 transition hover:text-white hover:decoration-current"
            >
              {url}
            </a>
          {/each}
        {/if}
      {/each}
    </div>

    {#if collapsible && canExpand && !expanded}
      <div
        aria-hidden="true"
        class="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#1a1a1a] via-[rgba(26,26,26,0.92)] to-transparent"
      ></div>
    {/if}
  </div>

  {#if collapsible && canExpand}
    <button
      type="button"
      class="mt-2 inline-flex items-center text-[0.84rem] font-700 text-white/60 transition hover:text-white"
      aria-expanded={expanded}
      on:click={() => {
        expanded = !expanded;
      }}
    >
      {expanded ? 'Show less' : 'Show more'}
    </button>
  {/if}
</div>
