<script lang="ts">
  import { onMount } from 'svelte';
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { getPeerNetworkSnapshot } from '../fipsP2P';

  export let active = true;
  let snapshot = getPeerNetworkSnapshot();
  let mounted = false;
  let interval: ReturnType<typeof setInterval> | undefined;
  $: label = snapshot.peers.length > 0 ? 'Connected'
    : snapshot.status === 'unsupported' ? 'Not supported in this browser'
    : snapshot.status === 'unavailable' ? 'Unavailable'
    : snapshot.status === 'stopped' ? 'Not connected' : 'Connecting';

  function sync(enabled: boolean): void {
    if (enabled === (interval !== undefined)) { return; }
    clearInterval(interval);
    interval = undefined;
    if (enabled) {
      snapshot = getPeerNetworkSnapshot();
      interval = setInterval(() => { snapshot = getPeerNetworkSnapshot(); }, 2_000);
    }
  }
  $: if (mounted) { sync(active && document.visibilityState !== 'hidden'); }
  onMount(() => {
    mounted = true;
    const visibilityChanged = () => sync(active && document.visibilityState !== 'hidden');
    visibilityChanged();
    document.addEventListener('visibilitychange', visibilityChanged);
    return () => { document.removeEventListener('visibilitychange', visibilityChanged); sync(false); };
  });
</script>

<div data-testid="settings-peer-network" data-polling={interval !== undefined}>
  <SettingsGroup title="Peer network">
    <SettingsGroupItem isLast={snapshot.peers.length === 0}>
      <div class="flex items-center justify-between gap-4 text-[0.9rem]">
        <span class="flex items-center gap-2"><span class={`h-2 w-2 rounded-full ${snapshot.peers.length ? 'bg-emerald-500' : 'bg-[rgb(var(--iris-text-rgb)/0.3)]'}`}></span>{label}</span>
        <span class="text-[rgb(var(--iris-text-rgb)/0.6)]">{snapshot.peers.length} {snapshot.peers.length === 1 ? 'peer' : 'peers'}</span>
      </div>
    </SettingsGroupItem>
    {#each snapshot.peers as peer, index (peer)}
      <SettingsGroupItem isLast={index === snapshot.peers.length - 1}>
        <div class="flex items-center justify-between gap-4 text-[0.82rem]">
          <span class="font-mono" title={peer}>{peer.slice(0, 12)}…{peer.slice(-6)}</span>
          <span class="text-[rgb(var(--iris-text-rgb)/0.6)]">Connected</span>
        </div>
      </SettingsGroupItem>
    {/each}
  </SettingsGroup>
</div>
