<script lang="ts">
  import CopyButton from '@iris/svelte-ui/CopyButton.svelte';
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { getPeerNetworkSnapshot, peerNetwork } from '../fipsP2P';
  import { shortNpub } from '../nostr';
  import { peerIdentity } from '../peerIdentity';

  let { active = true }: { active?: boolean } = $props();
  const summaryId = $props.id();
  let snapshot = $state(getPeerNetworkSnapshot());
  let expanded = $state(false);
  $effect(() => {
    if (active) return peerNetwork.subscribe(value => { snapshot = value; });
  });
  const peers = $derived(snapshot.peers.map(peerIdentity));
  const label = $derived(peers.length > 0 ? `${peers.length} connected ${peers.length === 1 ? 'peer' : 'peers'}`
    : snapshot.status === 'unsupported' ? 'Not supported in this browser'
    : snapshot.status === 'unavailable' ? 'Unavailable'
    : snapshot.status === 'stopped' ? 'Not connected' : 'Connecting');
  const copyClass = 'iris-neutral-button shrink-0 rounded-full px-3 py-1 text-xs font-600';
</script>

<div data-testid="settings-peer-network">
  <SettingsGroup title="Peer network">
    <SettingsGroupItem isLast={!expanded}>
      <button
        type="button"
        class="flex w-full items-center gap-3 text-left"
        aria-label={expanded ? 'Hide connected peer details' : 'Show connected peer details'}
        aria-expanded={expanded}
        aria-describedby={summaryId}
        disabled={!peers.length && !expanded}
        onclick={() => { expanded = !expanded; }}
      >
        <span id={summaryId} class="min-w-0 flex-1">
          <span class="flex items-center gap-2 text-[0.9rem]">
            <span aria-hidden="true" class={`h-2 w-2 shrink-0 rounded-full ${peers.length ? 'bg-emerald-500' : 'bg-[rgb(var(--iris-text-rgb)/0.3)]'}`}></span>
            {label}
          </span>
          <span class="block truncate text-xs text-[rgb(var(--iris-text-rgb)/0.7)]">{peers.length ? peers.map(peer => peer.name).join(', ') : '0 peers'}</span>
        </span>
        <span class="chevron" class:expanded aria-hidden="true">›</span>
      </button>
    </SettingsGroupItem>
    {#if expanded}
      <div class="peer-list">
        {#if !peers.length}<p class="px-4 py-3 text-sm">No connected peers.</p>{/if}
        {#each peers as peer, index (peer.peerId)}
          <SettingsGroupItem isLast={index === peers.length - 1} testId="settings-connected-peer">
            <details>
              <summary>
                <span class="min-w-0 flex-1">
                  <strong class="block">{peer.name}</strong>
                  <span class="font-mono text-xs text-[rgb(var(--iris-text-rgb)/0.7)]">{shortNpub(peer.npub ?? peer.peerId)}</span>
                </span>
                <span class="chevron" aria-hidden="true">›</span>
              </summary>
              {#each (peer.npub ? [['npub', peer.npub], ['Peer ID', peer.peerId]] : [['Peer ID', peer.peerId]]) as [title, value]}
                <div class="flex items-center justify-between gap-3 pt-3">
                  <div class="min-w-0">
                    <span class="block text-xs font-600">{title}</span>
                    <code class="break-all select-all text-xs">{value}</code>
                  </div>
                  <CopyButton text={value} ariaLabel={`Copy ${title}`} title={`Copy ${title}`} class={copyClass} />
                </div>
              {/each}
            </details>
          </SettingsGroupItem>
        {/each}
      </div>
    {/if}
  </SettingsGroup>
</div>

<style>
  summary { display: flex; align-items: center; gap: .75rem; cursor: pointer; list-style: none; }
  summary::-webkit-details-marker { display: none; }
  .chevron { font-size: 1.25rem; line-height: 1; }
  .peer-list { block-size: min(15rem, 45dvh); overflow-y: auto; overscroll-behavior: contain; }
  details[open] .chevron, .chevron.expanded { transform: rotate(90deg); }
</style>
