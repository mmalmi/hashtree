<script lang="ts">
  import { getNoteEngagementTargetId } from '../../noteEngagement';
  import { hasMoreHomeFeedNotes } from '../../appHomeFeed';
  import { updateAccountPeerFeed } from '../../socialPeerFeed';
  import { buildCurrentLiveScope } from '../../appLiveScope';
  import { routeKey } from '../../appRoute';
  import { hasMoreHomeFeedContinuation } from '../../homeFeedPagination';
  import {
    extractPublicMutedPubkeys,
    selectNewestAdmittedMuteListEvent,
  } from '../../muteLists';
  import { getAddressableEventCoordinate, type RawEvent } from '../../nostr';
  import { admitZapReceiptEvents } from '../../zapReceipt';
  import { socialDataPlane } from '../../socialDataPlane';
  import { commitHomeProjection } from './homeProjectionCommit';
  import {
    createDisplayedEngagementsProjector,
    createHomeNotesProjector,
    createLikedNotesProjector,
    createProfileEventSplitter,
    createProfileNotesProjector,
    createThreadRepliesProjector,
    createVisibleNotificationsProjector,
    profileCountLabel,
    projectBufferedHomeEvents,
    reuseKnownNoteReferences,
    selectActiveRouteEngagementEvents,
    queryVisibleLiveEngagementEvents,
    visibleEngagementIds,
  } from './liveProjection';
  import {
    sameEngagementMap,
    sameEventOrder,
    sameNotificationOrder,
    sameProfileLikedNotes,
    sameStringSet,
  } from './projectionEquality';
  import {
    createInitialAppReactiveProjection,
    type AppIdentityProjection,
    type AppLiveProjection,
    type AppProjectionStateProps,
    type AppReactiveProjectionServices,
  } from './types';

  export let runtimeState: AppProjectionStateProps['runtimeState'];
  export let routeState: AppProjectionStateProps['routeState'];
  export let homeState: AppProjectionStateProps['homeState'];
  export let profileState: AppProjectionStateProps['profileState'];
  export let threadState: AppProjectionStateProps['threadState'];
  export let viewerState: AppProjectionStateProps['viewerState'];
  export let engagementState: AppProjectionStateProps['engagementState'];
  export let notificationState: AppProjectionStateProps['notificationState'];
  export let mediaState: AppProjectionStateProps['mediaState'];
  export let overlayState: AppProjectionStateProps['overlayState'];
  export let identity: AppIdentityProjection;
  export let services: AppReactiveProjectionServices;
  export let projection: AppLiveProjection = createInitialAppReactiveProjection().live;

  $: updateAccountPeerFeed($viewerState.viewerContactsEvent);

  const projectVisibleNotifications = createVisibleNotificationsProjector();
  const projectDisplayedEngagements = createDisplayedEngagementsProjector();
  const projectHomeNotes = createHomeNotesProjector();
  const projectProfileNotes = createProfileNotesProjector();
  const projectThreadReplies = createThreadRepliesProjector();
  const projectLikedNotes = createLikedNotesProjector();
  const splitProfileEvents = createProfileEventSplitter();
  let homeFeedHasMore = false;
  let profileFeedHasMore = false;
  let profilePostCountLabel = '...';
  let profileReplyCountLabel = '...';
  let profileMediaCountLabel = '...';
  let muteProjectionKey = '';
  let projectedMuteList = $viewerState.viewerMuteListEvent;
  let projectedMutedPubkeys = $viewerState.viewerMutedPubkeys;
  let forYouProjectionKey = '';
  let projectedForYouInteractions: RawEvent[] = [];
  let zapAdmissionKey = '';
  let zapAdmissionVersion = 0;

  $: {
    const viewerPubkey = identity.activeAccount?.pubkey ?? null;
    const nextMuteProjectionKey = [
      viewerPubkey ?? '',
      $viewerState.indexedViewerMuteListEvent?.id ?? '',
      $overlayState.liveOverlayVersion,
    ].join(':');
    if (muteProjectionKey !== nextMuteProjectionKey) {
      muteProjectionKey = nextMuteProjectionKey;
      projectedMuteList = viewerPubkey
        ? selectNewestAdmittedMuteListEvent([
            $viewerState.indexedViewerMuteListEvent,
            ...socialDataPlane.query({ authors: [viewerPubkey], kinds: [10_000] }),
          ], viewerPubkey)
        : null;
      projectedMutedPubkeys = extractPublicMutedPubkeys(projectedMuteList);
    }
    if ($viewerState.viewerMuteListEvent?.id !== projectedMuteList?.id) {
      viewerState.viewerMuteListEvent = projectedMuteList;
    }
    if (!sameStringSet($viewerState.viewerMutedPubkeys, projectedMutedPubkeys)) {
      viewerState.viewerMutedPubkeys = projectedMutedPubkeys;
    }
  }
  $: {
    if ($routeState.route.kind === 'notifications') {
      const nextNotifications = projectVisibleNotifications({
        durable: $notificationState.notifications,
        cursor: $notificationState.notificationCursor,
        mutedPubkeys: $viewerState.viewerMutedPubkeys,
        viewerPubkey: identity.activeAccount?.pubkey ?? null,
        getKnownNoteByRef: services.getKnownNoteByRef,
        liveOverlayVersion: $overlayState.liveOverlayVersion,
      });
      if (!sameNotificationOrder($notificationState.visibleNotifications, nextNotifications)) {
        notificationState.visibleNotifications = nextNotifications;
      }
    }
  }
  $: {
    if ($routeState.route.kind === 'home') {
      const nextBufferedEvents = projectBufferedHomeEvents(
        $homeState.liveHomeFeedBuffer,
        services.liveEventMatchesCurrentHomeFeed,
      );
      if (!sameEventOrder($homeState.bufferedLiveHomeEvents, nextBufferedEvents)) {
        homeState.bufferedLiveHomeEvents = nextBufferedEvents;
      }
      if ($homeState.bufferedLiveHomePostCount !== nextBufferedEvents.length) {
        homeState.bufferedLiveHomePostCount = nextBufferedEvents.length;
      }
      void $overlayState.liveOverlayVersion;
    }
  }
  $: {
    if ($routeState.route.kind === 'home') {
      const repositoryVersion = socialDataPlane.version;
      const tombstones = $homeState.liveHomeFeedBuffer.events.length > 0
        ? socialDataPlane.getTombstones()
        : [];
      const projectedHomeNotes = projectHomeNotes({
        route: $routeState.route,
        feed: $homeState.feed,
        loading: $routeState.loading,
        localPostsByAuthor: $overlayState.localPostsByAuthor,
        buffer: $homeState.liveHomeFeedBuffer,
        tombstones,
        mutedPubkeys: $viewerState.viewerMutedPubkeys,
        viewerPubkey: identity.activeAccount?.pubkey ?? null,
        feedLimit: $homeState.feedLimit,
        homeFeedFetchLimit: $homeState.homeFeedFetchLimit,
        liveAuthors: services.getLiveHomeAuthors(),
        liveOverlayVersion: $overlayState.liveOverlayVersion,
        repositoryVersion,
      });
      const nextAllHomeNotes = reuseKnownNoteReferences(
        projectedHomeNotes,
        services.getCanonicalKnownNoteByRef,
      );
      commitHomeProjection({
        current: $homeState.allHomeNotes,
        next: nextAllHomeNotes,
        routeKey: routeKey($routeState.route),
        visibleLimit: $homeState.feedLimit,
        captureVisibleAnchor: services.captureVisibleHomeFeedAnchor,
        commit: (events) => { homeState.allHomeNotes = events; },
        ensureAnchorRendered: (minimumVisibleCount) => {
          if ($homeState.feedLimit < minimumVisibleCount) {
            homeState.feedLimit = minimumVisibleCount;
          }
        },
        scheduleAnchorRestore: services.scheduleVisibleHomeAnchorRestore,
      });
    }
  }
  $: {
    if ($routeState.route.kind === 'home') {
      const nextHomeNotes = $homeState.allHomeNotes.slice(0, $homeState.feedLimit);
      if (!sameEventOrder($homeState.homeNotes, nextHomeNotes)) {
        homeState.homeNotes = nextHomeNotes;
      }
      homeFeedHasMore = hasMoreHomeFeedNotes({
        visibleNoteCount: $homeState.allHomeNotes.length,
        durableNoteCount: $homeState.feed?.notes.length ?? 0,
        visibleLimit: $homeState.feedLimit,
        fetchLimit: $homeState.homeFeedFetchLimit,
      }) || hasMoreHomeFeedContinuation(
        $homeState.feed?.continuation ?? null,
        new Set(($homeState.feed?.notes ?? []).map((event) => event.id)),
        new Set(($homeState.feed?.notes ?? [])
          .map((event) => getAddressableEventCoordinate(event))
          .filter((address): address is string => Boolean(address))),
      );
    }
  }
  $: {
    if ($routeState.route.kind === 'profile') {
      const projectedProfile = projectProfileNotes({
        profilePubkey: identity.currentProfilePubkey,
        profilePage: $profileState.profilePage,
        knownNotes: identity.currentProfilePubkey
          ? services.snapshotKnownProfileNotes(
              identity.currentProfilePubkey,
              $overlayState.knownNotesVersion,
            )
          : [],
        localPostsByAuthor: $overlayState.localPostsByAuthor,
        mutedPubkeys: $viewerState.viewerMutedPubkeys,
        viewerPubkey: identity.activeAccount?.pubkey ?? null,
        profileNoteFetchLimit: $profileState.profileNoteFetchLimit,
        profileNoteLimit: $profileState.profileNoteLimit,
        liveOverlayVersion: $overlayState.liveOverlayVersion,
      });
      const nextProfileProjection = {
        ...projectedProfile,
        events: reuseKnownNoteReferences(
          projectedProfile.events,
          services.getCanonicalKnownNoteByRef,
        ),
      };
      if (!sameEventOrder($profileState.allProfileNotes, nextProfileProjection.events)) {
        const anchor = services.captureVisibleProfileFeedAnchor();
        if (anchor) {
          const anchorIndex = nextProfileProjection.events.findIndex(
            (event) => event.id === anchor.noteId,
          );
          if (anchorIndex >= $profileState.profileNoteLimit) {
            profileState.profileNoteLimit = anchorIndex + 1;
          }
        }
        profileState.allProfileNotes = nextProfileProjection.events;
        services.scheduleVisibleProfileAnchorRestore(
          routeKey($routeState.route),
          anchor,
        );
      }
      if ($profileState.profileContentSourceHasMore !== nextProfileProjection.sourceHasMore) {
        profileState.profileContentSourceHasMore = nextProfileProjection.sourceHasMore;
      }
    }
  }
  $: {
    if ($routeState.route.kind === 'profile') {
      const split = splitProfileEvents($profileState.allProfileNotes);
      if (!sameEventOrder($profileState.allProfileRootPosts, split.posts)) {
        profileState.allProfileRootPosts = split.posts;
      }
      if (!sameEventOrder($profileState.allProfileReplies, split.replies)) {
        profileState.allProfileReplies = split.replies;
      }
      if (!sameEventOrder($profileState.allProfileMedia, split.media)) {
        profileState.allProfileMedia = split.media;
      }
      const nextLikedNotes = projectLikedNotes({
        profilePubkey: identity.currentProfilePubkey,
        profilePage: $profileState.profilePage,
        getKnownNoteByRef: services.getKnownNoteByRef,
        liveOverlayVersion: $overlayState.liveOverlayVersion,
      });
      if (!sameProfileLikedNotes($profileState.allProfileLikedNotes, nextLikedNotes)) {
        profileState.allProfileLikedNotes = nextLikedNotes;
      }
    }
  }
  $: {
    if ($routeState.route.kind === 'profile') {
      const nextSectionNotes: RawEvent[] = $routeState.route.section === 'replies'
        ? $profileState.allProfileReplies
        : $routeState.route.section === 'media'
          ? $profileState.allProfileMedia
          : $routeState.route.section === 'likes'
            ? $profileState.allProfileLikedNotes.map((item) => item.note)
            : $routeState.route.section === 'posts'
              ? $profileState.allProfileRootPosts
              : [];
      if (!sameEventOrder($profileState.allProfileSectionNotes, nextSectionNotes)) {
        profileState.allProfileSectionNotes = nextSectionNotes;
      }
      const nextProfileNotes = nextSectionNotes.slice(0, $profileState.profileNoteLimit);
      if (!sameEventOrder($profileState.profileNotes, nextProfileNotes)) {
        profileState.profileNotes = nextProfileNotes;
      }
      profilePostCountLabel = profileCountLabel(
        $profileState.allProfileRootPosts.length,
        $profileState.profileNotesLoading,
        $profileState.profileContentSourceHasMore,
      );
      profileReplyCountLabel = profileCountLabel(
        $profileState.allProfileReplies.length,
        $profileState.profileNotesLoading,
        $profileState.profileContentSourceHasMore,
      );
      profileMediaCountLabel = profileCountLabel(
        $profileState.allProfileMedia.length,
        $profileState.profileNotesLoading,
        $profileState.profileContentSourceHasMore,
      );
      const likesCountLabel = `${$profileState.allProfileLikedNotes.length}`;
      if ($profileState.profileLikesCountLabel !== likesCountLabel) {
        profileState.profileLikesCountLabel = likesCountLabel;
      }
      profileFeedHasMore = ['posts', 'replies', 'media', 'likes'].includes($routeState.route.section)
      && (
        nextSectionNotes.length > $profileState.profileNoteLimit
        || ($routeState.route.section === 'likes'
          ? Boolean($profileState.profilePage?.likedNotesHasMore)
          : $profileState.profileContentSourceHasMore)
        || ($profileState.profileNotesLoading && nextSectionNotes.length > 0)
      );
    }
  }
  $: {
    if ($routeState.route.kind === 'thread') {
      const nextAllThreadReplies = projectThreadReplies({
        active: true,
        durableReplies: $threadState.threadReplies,
        referenceEvents: services.getThreadReferenceEvents(),
        mutedPubkeys: $viewerState.viewerMutedPubkeys,
        viewerPubkey: identity.activeAccount?.pubkey ?? null,
        fetchLimit: $threadState.threadReplyFetchLimit,
        liveOverlayVersion: $overlayState.liveOverlayVersion,
      });
      if (!sameEventOrder($threadState.allLiveThreadReplies, nextAllThreadReplies)) {
        threadState.allLiveThreadReplies = nextAllThreadReplies;
      }
      const nextLiveReplies = nextAllThreadReplies.slice(0, $threadState.threadReplyFetchLimit);
      if (!sameEventOrder($threadState.liveThreadReplies, nextLiveReplies)) {
        threadState.liveThreadReplies = nextLiveReplies;
      }
      const nextHasMore = (
        $threadState.durableThreadRepliesHasMore
        || nextAllThreadReplies.length > $threadState.threadReplyFetchLimit
      );
      if ($threadState.threadRepliesHasMore !== nextHasMore) {
        threadState.threadRepliesHasMore = nextHasMore;
      }
    }
  }
  $: {
    if ($runtimeState.root) {
      const visibleEvents = selectActiveRouteEngagementEvents({
        route: $routeState.route,
        homeNotes: $homeState.homeNotes,
        profileNotes: $profileState.profileNotes,
        threadReplies: $threadState.liveThreadReplies,
        threadNote: $threadState.threadPage?.note ?? null,
        threadContext: $threadState.threadPage?.context ?? [],
      });
      // Snapshot seeding can replace the map while cached posts remain visible.
      // Reconcile against the rendered set whenever that map changes as well.
      $engagementState.noteEngagements;
      services.ensureVisibleNoteEngagements(
        $runtimeState.root, visibleEvents.map(getNoteEngagementTargetId), $runtimeState.loadToken,
      );
    }
  }
  $: {
    if (['home', 'profile', 'thread'].includes($routeState.route.kind)) {
      const visibleEvents = selectActiveRouteEngagementEvents({
        route: $routeState.route,
        homeNotes: $homeState.allHomeNotes,
        profileNotes: $profileState.allProfileSectionNotes,
        threadReplies: $threadState.liveThreadReplies,
        threadNote: $threadState.threadPage?.note ?? null,
        threadContext: $threadState.threadPage?.context ?? [],
      });
      const liveEngagementEvents = queryVisibleLiveEngagementEvents(visibleEngagementIds(
        $engagementState.noteEngagements,
        visibleEvents,
      ));
      const nextEngagements = projectDisplayedEngagements({
        durable: $engagementState.noteEngagements,
        optimistic: $engagementState.optimisticNoteEngagements,
        visibleEvents,
        liveEvents: liveEngagementEvents,
        viewerPubkey: identity.activeAccount?.pubkey ?? null,
        liveOverlayVersion: $overlayState.liveOverlayVersion + zapAdmissionVersion,
      });
      if (!sameEngagementMap($engagementState.displayedNoteEngagements, nextEngagements)) {
        engagementState.displayedNoteEngagements = nextEngagements;
      }
      const nextZapAdmissionKey = liveEngagementEvents
        .filter((event) => event.kind === 9_735)
        .map((event) => `${event.id}:${event.sig}`)
        .sort()
        .join(',');
      if (nextZapAdmissionKey !== zapAdmissionKey) {
        zapAdmissionKey = nextZapAdmissionKey;
        const admissionRouteKey = routeKey($routeState.route);
        void admitZapReceiptEvents(liveEngagementEvents).then((changed) => {
          if (!changed || routeKey($routeState.route) !== admissionRouteKey) {
            return;
          }
          zapAdmissionVersion += 1;
        }).catch(() => undefined);
      }
    }
  }
  $: {
    if ($routeState.route.kind === 'home' && $routeState.route.tab === 'for-you') {
      const rankingAuthors = services.getForYouRankingAuthors();
      const nextForYouProjectionKey = [
        socialDataPlane.version,
        $overlayState.liveOverlayVersion,
        ...rankingAuthors,
      ].join(':');
      if (forYouProjectionKey !== nextForYouProjectionKey) {
        forYouProjectionKey = nextForYouProjectionKey;
        projectedForYouInteractions = services.getForYouOverlayInteractions(rankingAuthors, 128);
      }
      if (!sameEventOrder($homeState.liveForYouInteractions, projectedForYouInteractions)) {
        homeState.liveForYouInteractions = projectedForYouInteractions;
      }
    }
    socialDataPlane.setLiveScope(buildCurrentLiveScope({
      route: $routeState.route,
      activePubkey: identity.activeAccount?.pubkey ?? null,
      feed: $homeState.feed,
      viewerFollows: $viewerState.viewerFollows,
      favoritePubkeys: $homeState.favoritePubkeys,
      homeNotes: $homeState.homeNotes,
      profileNotes: $profileState.profileNotes,
      threadPage: $threadState.threadPage,
      threadReplies: $threadState.liveThreadReplies,
      forYouInteractions: projectedForYouInteractions,
    }));
  }
  $: {
    const activeEventId = $mediaState.mediaModalOpen
      ? $mediaState.mediaSelection?.event?.id ?? null
      : null;
    const activeUrl = $mediaState.mediaModalOpen
      ? $mediaState.mediaSelection?.embeds[$mediaState.mediaSelection.index]?.url ?? null
      : null;
    if ($mediaState.activeMediaEventId !== activeEventId) {
      mediaState.activeMediaEventId = activeEventId;
    }
    if ($mediaState.activeMediaUrl !== activeUrl) {
      mediaState.activeMediaUrl = activeUrl;
    }
  }
  $: {
    const nextProjection: AppLiveProjection = {
      homeFeedHasMore,
      profileFeedHasMore,
      profilePostCountLabel,
      profileReplyCountLabel,
      profileMediaCountLabel,
    };
    if (
      projection.homeFeedHasMore !== nextProjection.homeFeedHasMore
      || projection.profileFeedHasMore !== nextProjection.profileFeedHasMore
      || projection.profilePostCountLabel !== nextProjection.profilePostCountLabel
      || projection.profileReplyCountLabel !== nextProjection.profileReplyCountLabel
      || projection.profileMediaCountLabel !== nextProjection.profileMediaCountLabel
    ) {
      projection = nextProjection;
    }
  }
</script>
