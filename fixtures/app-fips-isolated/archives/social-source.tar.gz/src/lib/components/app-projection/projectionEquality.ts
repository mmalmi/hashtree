import type { NotificationItem } from '../../appDetailLoaders';
import type { NoteEngagement } from '../../noteEngagement';
import type { ProfileLikedNote } from '../../profileLikes';
import type { RawEvent } from '../../nostr';

export function sameEventOrder(
  left: readonly RawEvent[],
  right: readonly RawEvent[],
): boolean {
  return left === right || (
    left.length === right.length
    && left.every((event, index) => event.id === right[index]?.id)
  );
}

export function sameStringOrder(left: readonly string[], right: readonly string[]): boolean {
  return left === right || (
    left.length === right.length
    && left.every((value, index) => value === right[index])
  );
}

export function sameStringSet(left: ReadonlySet<string>, right: ReadonlySet<string>): boolean {
  return left === right || (
    left.size === right.size
    && [...left].every((value) => right.has(value))
  );
}

export function sameNotificationOrder(
  left: readonly NotificationItem[],
  right: readonly NotificationItem[],
): boolean {
  return left === right || (
    left.length === right.length
    && left.every((item, index) => {
      const candidate = right[index];
      return item.id === candidate?.id
        && item.targetEvent?.id === candidate.targetEvent?.id;
    })
  );
}

export function sameProfileLikedNotes(
  left: readonly ProfileLikedNote[],
  right: readonly ProfileLikedNote[],
): boolean {
  return left === right || (
    left.length === right.length
    && left.every((item, index) => (
      item.reaction.id === right[index]?.reaction.id
      && item.note.id === right[index]?.note.id
    ))
  );
}

function sameStrings(left: readonly string[], right: readonly string[]): boolean {
  return left === right || (
    left.length === right.length
    && left.every((value, index) => value === right[index])
  );
}

function sameEngagement(left: NoteEngagement, right: NoteEngagement): boolean {
  return left === right || (
    left.reactionCount === right.reactionCount
    && left.replyCount === right.replyCount
    && left.repostCount === right.repostCount
    && left.zapCount === right.zapCount
    && left.zapBits === right.zapBits
    && left.viewerReacted === right.viewerReacted
    && sameStrings(left.reactionAuthors, right.reactionAuthors)
    && sameStrings(left.replyEventIds, right.replyEventIds)
    && sameStrings(left.repostAuthors, right.repostAuthors)
    && left.zapReceipts.length === right.zapReceipts.length
    && left.zapReceipts.every((receipt, index) => (
      receipt.id === right.zapReceipts[index]?.id
      && receipt.bits === right.zapReceipts[index]?.bits
    ))
  );
}

export function sameEngagementMap(
  left: ReadonlyMap<string, NoteEngagement>,
  right: ReadonlyMap<string, NoteEngagement>,
): boolean {
  return left === right || (
    left.size === right.size
    && [...left].every(([noteId, engagement]) => {
      const candidate = right.get(noteId);
      return Boolean(candidate && sameEngagement(engagement, candidate));
    })
  );
}
