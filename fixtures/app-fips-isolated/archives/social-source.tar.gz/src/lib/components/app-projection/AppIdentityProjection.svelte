<script lang="ts">
  import { accountsStore } from '../../accounts';
  import { contactMemoryStore } from '../../contactMemoryStore';
  import { routeKey } from '../../appRoute';
  import { syncBrowserEventReadRoots } from '../../browserEventReadRouter';
  import { sharedProfilesStore } from '../../profileCache';
  import { configureLocalSocialGraphViewer } from '../../socialGraph';
  import {
    createIdentityProjector,
    type IdentityProjectionResult,
  } from './identityProjection';
  import { sameEventOrder } from './projectionEquality';
  import {
    createInitialAppReactiveProjection,
    type AppIdentityProjection,
    type AppProjectionStateProps,
    type AppReactiveProjectionServices,
  } from './types';

  export let routeState: AppProjectionStateProps['routeState'];
  export let homeState: AppProjectionStateProps['homeState'];
  export let profileState: AppProjectionStateProps['profileState'];
  export let threadState: AppProjectionStateProps['threadState'];
  export let searchState: AppProjectionStateProps['searchState'];
  export let accountState: AppProjectionStateProps['accountState'];
  export let viewerState: AppProjectionStateProps['viewerState'];
  export let engagementState: AppProjectionStateProps['engagementState'];
  export let notificationState: AppProjectionStateProps['notificationState'];
  export let overlayState: AppProjectionStateProps['overlayState'];
  export let runtimeState: AppProjectionStateProps['runtimeState'];
  export let services: AppReactiveProjectionServices;
  export let projection: AppIdentityProjection = createInitialAppReactiveProjection().identity;

  const projectIdentity = createIdentityProjector();
  let result: IdentityProjectionResult = {
    ...projection,
    activeFeedSource: null,
    viewerProfileEvent: null,
    viewerProfileOverlayEvents: [],
  };
  let configuredViewerKey = '';

  $: result = projectIdentity({
    accounts: $accountsStore.accounts,
    activeAccountPubkey: $accountsStore.activeAccountPubkey ?? null,
    privateContacts: $contactMemoryStore.viewer === $accountsStore.activeAccountPubkey ? $contactMemoryStore.contacts : undefined,
    accountProfiles: $accountState.accountProfiles,
    detailSheetProfiles: $engagementState.detailSheetProfiles,
    hydratedViewerProfileEvent: $accountState.hydratedViewerProfileEvent,
    viewerProfileLoading: $accountState.viewerProfileLoading,
    feed: $homeState.feed,
    feedSources: $homeState.feedSources,
    activeFeedSourceId: $homeState.activeFeedSourceId,
    liveProfiles: $overlayState.liveProfiles,
    liveOverlayVersion: $overlayState.liveOverlayVersion,
    knownNotesVersion: $overlayState.knownNotesVersion,
    notificationsProfiles: $notificationState.notificationsProfiles,
    profilePage: $profileState.profilePage,
    profileSocial: $profileState.profileSocial,
    profileSocialVisibleLimit: $profileState.profileSocialVisibleLimit,
    route: $routeState.route,
    searchTab: $searchState.searchTab,
    sharedProfiles: $sharedProfilesStore,
    threadPageAuthorPubkey: $routeState.route.kind === 'thread'
      ? $threadState.threadPage?.note?.pubkey ?? null
      : null,
    threadProfiles: $threadState.threadProfiles,
    snapshotLocalPostSearchEvents: services.snapshotLocalPostSearchEvents,
  });
  $: projection = result;
  $: if ($accountState.activeAccount !== result.activeAccount) {
    accountState.activeAccount = result.activeAccount;
  }
  $: if (!sameEventOrder(
    $accountState.viewerProfileOverlayEvents,
    result.viewerProfileOverlayEvents,
  )) {
    accountState.viewerProfileOverlayEvents = result.viewerProfileOverlayEvents;
  }
  $: if ($accountState.viewerProfileEvent?.id !== result.viewerProfileEvent?.id) {
    accountState.viewerProfileEvent = result.viewerProfileEvent;
  }
  $: if ($homeState.activeFeedSource !== result.activeFeedSource) {
    homeState.activeFeedSource = result.activeFeedSource;
  }
  $: syncBrowserEventReadRoots(
    $runtimeState.root,
    $viewerState.viewerPersonalRoot,
    $routeState.route.kind === 'profile'
      ? $profileState.profilePersonalRoot
      : $threadState.threadPersonalRoot,
    routeKey($routeState.route),
  );
  $: {
    const nextViewerKey = `${result.activeAccount?.pubkey ?? ''}:${$accountsStore.accounts.length}`;
    if (nextViewerKey !== configuredViewerKey) {
      configuredViewerKey = nextViewerKey;
      configureLocalSocialGraphViewer(result.activeAccount, $accountsStore.accounts.length);
    }
  }
  $: {
    const accountProfileKey = `${$runtimeState.rootNhash}:${$accountsStore.accounts
      .map((account) => account.pubkey)
      .join(',')}`;
    if ($runtimeState.root && accountProfileKey !== $runtimeState.hydratedAccountsKey) {
      runtimeState.hydratedAccountsKey = accountProfileKey;
      void services.hydrateAccountProfiles($runtimeState.root);
    }
  }
  $: if (typeof document !== 'undefined' && document.title !== result.documentTitle) {
    document.title = result.documentTitle;
  }
</script>
