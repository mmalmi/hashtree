import type { SocialAccount } from '../../accounts';
import type { AppContactMemory } from '../../contactMemoryStore';
import type { FeedSnapshot, ProfileSocialSnapshot } from '../../nostrIndex';
import type { ProfileSnapshot } from '../../profileNotes';
import type { Route } from '../../appRoute';
import type { FeedSource } from '../../appStorage';
import {
  fallbackProfileNameForIdentity,
  parseProfileEvent,
  type ProfileRecord,
  type RawEvent,
} from '../../nostr';
import { canPublishFromAccount } from '../../nostrPublish';
import {
  isKnownProfileMetadataBaseUnavailable,
  parseEditableProfileMetadata,
  selectNewestAdmittedProfileMetadataEvent,
} from '../../profileMetadata';
import { resolvePreferredProfile } from '../../appProfiles';
import {
  mergeProfileMaps,
  preferNewerProfileRecord,
} from '../../profileRecords';
import { overlayViewerProfile } from '../../appBrowserState';
import { socialDataPlane } from '../../socialDataPlane';
import type { AppIdentityProjection } from './types';

export type IdentityProjectionInput = {
  accounts: SocialAccount[];
  activeAccountPubkey: string | null;
  privateContacts?: ReadonlyMap<string, AppContactMemory>;
  accountProfiles: Map<string, ProfileRecord>;
  detailSheetProfiles: Map<string, ProfileRecord>;
  hydratedViewerProfileEvent: RawEvent | null;
  viewerProfileLoading: boolean;
  feed: FeedSnapshot | null;
  feedSources: FeedSource[];
  activeFeedSourceId: string | null;
  liveProfiles: Map<string, ProfileRecord>;
  liveOverlayVersion: number;
  knownNotesVersion: number;
  notificationsProfiles: Map<string, ProfileRecord>;
  profilePage: ProfileSnapshot | null;
  profileSocial: ProfileSocialSnapshot | null;
  profileSocialVisibleLimit: number;
  route: Route;
  searchTab: 'people' | 'posts';
  sharedProfiles: Map<string, ProfileRecord>;
  threadPageAuthorPubkey: string | null;
  threadProfiles: Map<string, ProfileRecord>;
  snapshotLocalPostSearchEvents(
    knownNotesVersion: number,
    liveOverlayVersion: number,
  ): RawEvent[];
};

export type IdentityProjectionResult = AppIdentityProjection & {
  activeFeedSource: FeedSource | null;
  viewerProfileEvent: RawEvent | null;
  viewerProfileOverlayEvents: RawEvent[];
};

export function hasMoreProfileSocial(
  social: ProfileSocialSnapshot | null,
  section: 'follows' | 'followers',
  visibleCount: number,
): boolean {
  const pubkeys = section === 'follows' ? social?.follows ?? [] : social?.followers ?? [];
  const count = section === 'follows' ? social?.followsCount : social?.followersCount;
  return (count ?? pubkeys.length) > visibleCount;
}

type BaseIdentityProjection = {
  activeAccountFallbackProfile: ProfileRecord | null;
  activeProfile: ProfileRecord | null;
  baseResolvedProfilesByPubkey: Map<string, ProfileRecord>;
  parsedViewerProfileMetadata: ReturnType<typeof parseEditableProfileMetadata>;
  viewerProfileBaseUnavailable: boolean;
  viewerProfileEvent: RawEvent | null;
  viewerProfileOverlayEvents: RawEvent[];
};

type BaseProjectionCache = {
  accounts: SocialAccount[];
  activeAccount: SocialAccount | null;
  accountProfiles: Map<string, ProfileRecord>;
  activePageProfile: ProfileRecord | null;
  detailSheetProfiles: Map<string, ProfileRecord>;
  feedProfiles: Map<string, ProfileRecord> | null;
  hydratedViewerProfileEvent: RawEvent | null;
  liveProfiles: Map<string, ProfileRecord>;
  liveOverlayVersion: number;
  notificationsProfiles: Map<string, ProfileRecord>;
  profileSocialProfiles: Map<string, ProfileRecord> | null;
  sharedProfiles: Map<string, ProfileRecord>;
  threadProfiles: Map<string, ProfileRecord>;
  result: BaseIdentityProjection;
};

function accountFallbackProfileRecord(account: SocialAccount | null): ProfileRecord | null {
  if (!account) {
    return null;
  }
  return {
    pubkey: account.pubkey,
    npub: account.npub,
    eventId: null,
    createdAt: null,
    name: account.profile.name,
    displayName: null,
    about: null,
    picture: null,
    banner: null,
    nip05: null,
    website: null,
    lud16: null,
    lud06: null,
  };
}

export function getHeaderTitle(
  route: Route,
  currentProfileLabel: string,
  threadAuthorLabel: string,
): string {
  if (route.kind === 'home') {
    return route.tab === 'favorites' ? 'Favorites' : route.tab === 'for-you' ? 'For you' : route.tab === 'media' ? 'Media' : 'Home';
  }
  if (route.kind === 'notifications') {
    return 'Notifications';
  }
  if (route.kind === 'search') {
    return 'Search';
  }
  if (route.kind === 'accounts') {
    return 'Accounts';
  }
  if (route.kind === 'wallet') {
    return 'Wallet';
  }
  if (route.kind === 'username') {
    return `iris.to/${route.username}`;
  }
  if (route.kind === 'profile') {
    return currentProfileLabel;
  }
  if (route.kind === 'thread') {
    return threadAuthorLabel ? `Post by ${threadAuthorLabel}` : 'Post';
  }
  if (route.kind !== 'settings') {
    return 'Profile';
  }
  if (route.section === 'iris') {
    return 'iris.to username';
  }
  if (route.section === 'content') { return 'Content'; }
  if (route.section === 'appearance') {
    return 'Appearance';
  }
  if (route.section === 'network') {
    return 'Network';
  }
  if (route.section === 'media') {
    return 'Media servers';
  }
  if (route.section === 'storage') {
    return 'Storage';
  }
  if (route.section === 'wallet') {
    return 'Wallet settings';
  }
  return route.section === 'profile' ? 'Profile' : 'Settings';
}

function inputsEqual(left: IdentityProjectionInput, right: IdentityProjectionInput): boolean {
  return left.accounts === right.accounts
    && left.activeAccountPubkey === right.activeAccountPubkey
    && left.privateContacts === right.privateContacts
    && left.accountProfiles === right.accountProfiles
    && left.detailSheetProfiles === right.detailSheetProfiles
    && left.hydratedViewerProfileEvent === right.hydratedViewerProfileEvent
    && left.viewerProfileLoading === right.viewerProfileLoading
    && left.feed === right.feed
    && left.feedSources === right.feedSources
    && left.activeFeedSourceId === right.activeFeedSourceId
    && left.liveProfiles === right.liveProfiles
    && left.liveOverlayVersion === right.liveOverlayVersion
    && left.knownNotesVersion === right.knownNotesVersion
    && left.notificationsProfiles === right.notificationsProfiles
    && left.profilePage === right.profilePage
    && left.profileSocial === right.profileSocial
    && left.profileSocialVisibleLimit === right.profileSocialVisibleLimit
    && left.route === right.route
    && left.searchTab === right.searchTab
    && left.sharedProfiles === right.sharedProfiles
    && left.threadPageAuthorPubkey === right.threadPageAuthorPubkey
    && left.threadProfiles === right.threadProfiles
    && left.snapshotLocalPostSearchEvents === right.snapshotLocalPostSearchEvents;
}

export function createIdentityProjector() {
  let previousInput: IdentityProjectionInput | null = null;
  let previousResult: IdentityProjectionResult | null = null;
  let baseCache: BaseProjectionCache | null = null;
  let searchableBase: Map<string, ProfileRecord> | null = null;
  let searchableCurrent: ProfileRecord | null = null;
  let searchableProfiles = new Map<string, ProfileRecord>();
  let socialSource: ProfileSocialSnapshot | null = null;
  let socialVisibleLimit = -1;
  let socialProjection = {
    currentFollows: [] as string[],
    currentFollowers: [] as string[],
    followsCountLabel: '...',
    followerCountLabel: '...',
  };
  let localSearchKey = '';
  let localSearchSnapshot = null as IdentityProjectionInput['snapshotLocalPostSearchEvents'] | null;
  let localPostSearchEvents: RawEvent[] = [];

  function projectBase(
    input: IdentityProjectionInput,
    activeAccount: SocialAccount | null,
  ): BaseIdentityProjection {
    const pageProfile = input.profilePage?.profile ?? null;
    const activePageProfile = pageProfile?.pubkey === activeAccount?.pubkey ? pageProfile : null;
    const feedProfiles = input.feed?.profiles ?? null;
    const profileSocialProfiles = input.profileSocial?.profiles ?? null;
    if (
      baseCache
      && baseCache.accounts === input.accounts
      && baseCache.activeAccount === activeAccount
      && baseCache.accountProfiles === input.accountProfiles
      && baseCache.activePageProfile === activePageProfile
      && baseCache.detailSheetProfiles === input.detailSheetProfiles
      && baseCache.feedProfiles === feedProfiles
      && baseCache.hydratedViewerProfileEvent === input.hydratedViewerProfileEvent
      && baseCache.liveProfiles === input.liveProfiles
      && baseCache.liveOverlayVersion === input.liveOverlayVersion
      && baseCache.notificationsProfiles === input.notificationsProfiles
      && baseCache.profileSocialProfiles === profileSocialProfiles
      && baseCache.sharedProfiles === input.sharedProfiles
      && baseCache.threadProfiles === input.threadProfiles
    ) {
      return baseCache.result;
    }
    const accountFallbackProfiles = new Map(
      input.accounts.flatMap((account) => {
        const profile = accountFallbackProfileRecord(account);
        return profile ? [[profile.pubkey, profile] as const] : [];
      }),
    );
    const profilesBeforeViewerMetadata = mergeProfileMaps(
      accountFallbackProfiles,
      input.accountProfiles,
      input.sharedProfiles,
      feedProfiles ?? new Map<string, ProfileRecord>(),
      input.liveProfiles,
      input.threadProfiles,
      profileSocialProfiles ?? new Map<string, ProfileRecord>(),
      input.notificationsProfiles,
      input.detailSheetProfiles,
    );
    const viewerPubkey = activeAccount?.pubkey ?? null;
    const viewerProfileOverlayEvents = viewerPubkey
      ? socialDataPlane.query({ authors: [viewerPubkey], kinds: [0] })
      : [];
    const viewerProfileEvent = viewerPubkey
      ? selectNewestAdmittedProfileMetadataEvent([
          input.hydratedViewerProfileEvent,
          ...viewerProfileOverlayEvents,
        ], viewerPubkey)
      : null;
    const knownViewerProfile = activeAccount
      ? preferNewerProfileRecord(
          profilesBeforeViewerMetadata.get(activeAccount.pubkey) ?? null,
          activePageProfile,
        )
      : null;
    const viewerProfileBaseUnavailable = isKnownProfileMetadataBaseUnavailable(
      knownViewerProfile,
      viewerProfileEvent,
    );
    const parsedViewerProfileMetadata = viewerProfileEvent
      ? parseEditableProfileMetadata(viewerProfileEvent.content)
      : null;
    const viewerProfileRecord = viewerProfileEvent && parsedViewerProfileMetadata
      ? parseProfileEvent(viewerProfileEvent)
      : null;
    const baseResolvedProfilesByPubkey = overlayViewerProfile(
      profilesBeforeViewerMetadata,
      viewerProfileBaseUnavailable ? null : viewerProfileRecord,
    );
    const result: BaseIdentityProjection = {
      activeAccountFallbackProfile: accountFallbackProfileRecord(activeAccount),
      activeProfile: activeAccount
        ? baseResolvedProfilesByPubkey.get(activeAccount.pubkey) ?? null
        : null,
      baseResolvedProfilesByPubkey,
      parsedViewerProfileMetadata,
      viewerProfileBaseUnavailable,
      viewerProfileEvent,
      viewerProfileOverlayEvents,
    };
    baseCache = {
      accounts: input.accounts,
      activeAccount,
      accountProfiles: input.accountProfiles,
      activePageProfile,
      detailSheetProfiles: input.detailSheetProfiles,
      feedProfiles,
      hydratedViewerProfileEvent: input.hydratedViewerProfileEvent,
      liveProfiles: input.liveProfiles,
      liveOverlayVersion: input.liveOverlayVersion,
      notificationsProfiles: input.notificationsProfiles,
      profileSocialProfiles,
      sharedProfiles: input.sharedProfiles,
      threadProfiles: input.threadProfiles,
      result,
    };
    return result;
  }

  function projectSocial(input: IdentityProjectionInput) {
    if (
      socialSource !== input.profileSocial
      || socialVisibleLimit !== input.profileSocialVisibleLimit
    ) {
      socialSource = input.profileSocial;
      socialVisibleLimit = input.profileSocialVisibleLimit;
      socialProjection = {
        currentFollows: input.profileSocial?.follows.slice(0, input.profileSocialVisibleLimit) ?? [],
        currentFollowers: input.profileSocial?.followers.slice(0, input.profileSocialVisibleLimit) ?? [],
        followsCountLabel: input.profileSocial?.hasFollows
          ? `${input.profileSocial.followsCount ?? input.profileSocial.follows.length}`
          : '...',
        followerCountLabel: input.profileSocial?.hasFollowers
          ? input.profileSocial.followersCount === null
            ? '...'
            : `${input.profileSocial.followersCount}`
          : '...',
      };
    }
    return socialProjection;
  }

  function projectSearch(input: IdentityProjectionInput): RawEvent[] {
    const nextKey = input.searchTab === 'posts'
      ? `${input.knownNotesVersion}:${input.liveOverlayVersion}`
      : 'people';
    if (nextKey !== localSearchKey || localSearchSnapshot !== input.snapshotLocalPostSearchEvents) {
      localSearchKey = nextKey;
      localSearchSnapshot = input.snapshotLocalPostSearchEvents;
      localPostSearchEvents = input.searchTab === 'posts'
        ? input.snapshotLocalPostSearchEvents(input.knownNotesVersion, input.liveOverlayVersion)
        : [];
    }
    return localPostSearchEvents;
  }

  return (input: IdentityProjectionInput): IdentityProjectionResult => {
    if (previousInput && previousResult && inputsEqual(previousInput, input)) {
      return previousResult;
    }
    previousInput = input;
    const activeAccount = input.accounts.find(
      (account) => account.pubkey === input.activeAccountPubkey,
    ) ?? input.accounts[0] ?? null;
    const base = projectBase(input, activeAccount);
    const {
      activeAccountFallbackProfile,
      activeProfile,
      baseResolvedProfilesByPubkey,
      parsedViewerProfileMetadata,
      viewerProfileBaseUnavailable,
      viewerProfileEvent,
      viewerProfileOverlayEvents,
    } = base;
    const currentProfilePubkey = input.route.kind === 'profile' ? input.route.pubkey : null;
    const currentProfile = currentProfilePubkey
      ? preferNewerProfileRecord(
          baseResolvedProfilesByPubkey.get(currentProfilePubkey) ?? null,
          input.profilePage?.profile ?? null,
        )
      : null;
    const profileMemory = currentProfilePubkey ? input.privateContacts?.get(currentProfilePubkey) : undefined;
    const currentProfileLabel = input.route.kind === 'profile'
      ? profileMemory?.nickname || profileMemory?.accepted_name || profileMemory?.first_seen_name
        || currentProfile?.displayName?.trim()
        || currentProfile?.name?.trim()
        || fallbackProfileNameForIdentity(input.route.pubkey ?? input.route.npub)
      : '';
    const threadAuthorProfile = input.threadPageAuthorPubkey
      ? resolvePreferredProfile(
          input.threadPageAuthorPubkey,
          baseResolvedProfilesByPubkey.get(input.threadPageAuthorPubkey) ?? null,
        )
      : null;
    const threadMemory = input.threadPageAuthorPubkey ? input.privateContacts?.get(input.threadPageAuthorPubkey) : undefined;
    const threadAuthorLabel = input.threadPageAuthorPubkey
      ? threadMemory?.nickname || threadMemory?.accepted_name || threadMemory?.first_seen_name
        || threadAuthorProfile?.displayName?.trim()
        || threadAuthorProfile?.name?.trim()
        || fallbackProfileNameForIdentity(input.threadPageAuthorPubkey)
      : '';
    const activeFeedSource = input.activeFeedSourceId
      ? input.feedSources.find((source) => source.id === input.activeFeedSourceId) ?? null
      : null;
    const {
      currentFollows,
      currentFollowers,
      followsCountLabel,
      followerCountLabel,
    } = projectSocial(input);
    if (searchableBase !== baseResolvedProfilesByPubkey || searchableCurrent !== currentProfile) {
      searchableBase = baseResolvedProfilesByPubkey;
      searchableCurrent = currentProfile;
      searchableProfiles = mergeProfileMaps(
        baseResolvedProfilesByPubkey,
        currentProfile
          ? new Map([[currentProfile.pubkey, currentProfile] as const])
          : new Map<string, ProfileRecord>(),
      );
    }
    const result: IdentityProjectionResult = {
      documentTitle: input.route.kind === 'profile'
        ? currentProfileLabel
        : input.route.kind === 'thread' && threadAuthorLabel
          ? `${threadAuthorLabel} on iris`
          : 'iris social',
      headerTitle: getHeaderTitle(input.route, currentProfileLabel, threadAuthorLabel),
      activeAccount,
      activeProfile,
      activeAccountFallbackProfile,
      searchableProfiles,
      localPostSearchEvents: projectSearch(input),
      accounts: input.accounts,
      canActiveAccountPublish: canPublishFromAccount(activeAccount),
      profileEditorBlockedReason: viewerProfileEvent && !parsedViewerProfileMetadata
        ? 'This profile metadata is malformed and cannot be safely edited.'
        : viewerProfileBaseUnavailable
          ? input.viewerProfileLoading
            ? 'Loading the latest profile metadata…'
            : 'The latest profile metadata is known but not fully loaded. Try again when the Hashtree index is available.'
          : '',
      profileSocialHasMore: input.route.kind === 'profile' && input.route.section === 'follows'
        ? hasMoreProfileSocial(input.profileSocial, 'follows', currentFollows.length)
        : input.route.kind === 'profile' && input.route.section === 'followers'
          ? hasMoreProfileSocial(input.profileSocial, 'followers', currentFollowers.length)
          : false,
      activeFeedSourceLabel: activeFeedSource?.name ?? 'Following',
      activeFeedSource,
      baseResolvedProfilesByPubkey,
      currentProfile,
      currentProfilePubkey,
      currentFollows,
      currentFollowers,
      followsCountLabel,
      followerCountLabel,
      viewerProfileEvent,
      viewerProfileOverlayEvents,
    };
    previousResult = result;
    return result;
  };
}
