<script lang="ts">
  import AppIdentityProjection from './AppIdentityProjection.svelte';
  import AppLiveProjection from './AppLiveProjection.svelte';
  import AppRouteCacheProjection from './AppRouteCacheProjection.svelte';
  import {
    createInitialAppReactiveProjection,
    type AppIdentityProjection as IdentityProjection,
    type AppLiveProjection as LiveProjection,
    type AppProjectionStateProps,
    type AppReactiveProjectionServices,
    type AppReactiveProjectionValue,
  } from './types';

  export let routeState: AppProjectionStateProps['routeState'];
  export let homeState: AppProjectionStateProps['homeState'];
  export let profileState: AppProjectionStateProps['profileState'];
  export let threadState: AppProjectionStateProps['threadState'];
  export let searchState: AppProjectionStateProps['searchState'];
  export let accountState: AppProjectionStateProps['accountState'];
  export let viewerState: AppProjectionStateProps['viewerState'];
  export let engagementState: AppProjectionStateProps['engagementState'];
  export let notificationState: AppProjectionStateProps['notificationState'];
  export let mediaState: AppProjectionStateProps['mediaState'];
  export let overlayState: AppProjectionStateProps['overlayState'];
  export let runtimeState: AppProjectionStateProps['runtimeState'];
  export let services: AppReactiveProjectionServices;
  export let projection: AppReactiveProjectionValue = createInitialAppReactiveProjection();

  let identity: IdentityProjection = projection.identity;
  let live: LiveProjection = projection.live;

  $: if (projection.identity !== identity || projection.live !== live) {
    projection = { identity, live, view: identity };
  }
</script>

<AppIdentityProjection
  {routeState}
  {homeState}
  {profileState}
  {threadState}
  {searchState}
  {accountState}
  {viewerState}
  {engagementState}
  {notificationState}
  {overlayState}
  {runtimeState}
  {services}
  bind:projection={identity}
/>
<AppLiveProjection
  {routeState}
  {homeState}
  {profileState}
  {threadState}
  {viewerState}
  {engagementState}
  {notificationState}
  {mediaState}
  {runtimeState}
  {overlayState}
  {identity}
  {services}
  bind:projection={live}
/>
<AppRouteCacheProjection
  {routeState}
  {homeState}
  {profileState}
  {threadState}
  {engagementState}
  {notificationState}
  {runtimeState}
  {identity}
  {live}
  {services}
/>
