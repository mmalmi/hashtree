import type { CID } from '@hashtree/core';
import type { SocialAccount } from '../../accounts';
import type { AppState } from '../../appState';
import type { RouteRenderCache } from '../../appStack';
import type { AppShellView } from '../app-shell/types';
import type { ProfileRecord, RawEvent } from '../../nostr';

export type AppProjectionStateProps = Pick<
  AppState,
  | 'routeState'
  | 'homeState'
  | 'profileState'
  | 'threadState'
  | 'searchState'
  | 'accountState'
  | 'viewerState'
  | 'engagementState'
  | 'notificationState'
  | 'mediaState'
  | 'overlayState'
  | 'runtimeState'
>;

export type ProjectedAppShellView = Omit<
  AppShellView,
  'infiniteScroll' | 'resolveReferencedNote' | 'threadReplyDrafts'
>;

export type AppIdentityProjection = ProjectedAppShellView & {
  activeAccount: SocialAccount | null;
  baseResolvedProfilesByPubkey: Map<string, ProfileRecord>;
  currentProfile: ProfileRecord | null;
  currentProfilePubkey: string | null;
  currentFollows: string[];
  currentFollowers: string[];
  followsCountLabel: string;
  followerCountLabel: string;
};

export type AppLiveProjection = {
  homeFeedHasMore: boolean;
  profileFeedHasMore: boolean;
  profilePostCountLabel: string;
  profileReplyCountLabel: string;
  profileMediaCountLabel: string;
};

export type AppReactiveProjectionValue = {
  identity: AppIdentityProjection;
  live: AppLiveProjection;
  view: ProjectedAppShellView;
};

export type VisibleHomeAnchor = { noteId: string; top: number } | null;

export type AppReactiveProjectionServices = {
  applyCurrentRouteCache(cache: RouteRenderCache): void;
  applyPendingRouteScroll(): void;
  captureVisibleHomeFeedAnchor(): VisibleHomeAnchor;
  captureVisibleProfileFeedAnchor(): VisibleHomeAnchor;
  getForYouOverlayInteractions(authors: string[], limit: number): RawEvent[];
  getForYouRankingAuthors(): string[];
  getCanonicalKnownNoteByRef(ref: string): RawEvent | null;
  getKnownNoteByRef(ref: string): RawEvent | null;
  getLiveHomeAuthors(): string[];
  getThreadReferenceEvents(): RawEvent[];
  hydrateAccountProfiles(root: CID): Promise<void>;
  ensureVisibleNoteEngagements(roots: CID | CID[], noteIds: string[], token: number): void;
  liveEventMatchesCurrentHomeFeed(event: RawEvent): boolean;
  scheduleVisibleHomeAnchorRestore(routeKey: string, anchor: VisibleHomeAnchor): void;
  scheduleVisibleProfileAnchorRestore(routeKey: string, anchor: VisibleHomeAnchor): void;
  snapshotKnownProfileNotes(pubkey: string, knownNotesVersion?: number): RawEvent[];
  snapshotLocalPostSearchEvents(knownNotesVersion: number, liveOverlayVersion: number): RawEvent[];
};

const EMPTY_PROFILES = new Map<string, ProfileRecord>();

export function createInitialAppReactiveProjection(): AppReactiveProjectionValue {
  const identity: AppIdentityProjection = {
    documentTitle: 'iris social',
    headerTitle: 'Home',
    activeAccount: null,
    activeProfile: null,
    activeAccountFallbackProfile: null,
    searchableProfiles: EMPTY_PROFILES,
    localPostSearchEvents: [],
    accounts: [],
    canActiveAccountPublish: false,
    profileEditorBlockedReason: '',
    profileSocialHasMore: false,
    activeFeedSourceLabel: 'Following',
    baseResolvedProfilesByPubkey: EMPTY_PROFILES,
    currentProfile: null,
    currentProfilePubkey: null,
    currentFollows: [],
    currentFollowers: [],
    followsCountLabel: '...',
    followerCountLabel: '...',
  };
  return {
    identity,
    live: {
      homeFeedHasMore: false,
      profileFeedHasMore: false,
      profilePostCountLabel: '...',
      profileReplyCountLabel: '...',
      profileMediaCountLabel: '...',
    },
    view: identity,
  };
}
