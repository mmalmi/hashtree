import type { RawEvent } from '../../nostr';
import { sameEventOrder } from './projectionEquality';
import type { VisibleHomeAnchor } from './types';

export type HomeProjectionCommitOptions = {
  current: RawEvent[];
  next: RawEvent[];
  routeKey: string;
  visibleLimit: number;
  captureVisibleAnchor(): VisibleHomeAnchor;
  commit(events: RawEvent[]): void;
  ensureAnchorRendered(minimumVisibleCount: number): void;
  scheduleAnchorRestore(routeKey: string, anchor: VisibleHomeAnchor): void;
};

function sameVisibleEventOrder(
  current: readonly RawEvent[],
  next: readonly RawEvent[],
  limit: number,
): boolean {
  const visibleLimit = Math.max(0, limit);
  const currentLength = Math.min(current.length, visibleLimit);
  const nextLength = Math.min(next.length, visibleLimit);
  if (currentLength !== nextLength) {
    return false;
  }
  for (let index = 0; index < currentLength; index += 1) {
    if (current[index]?.id !== next[index]?.id) {
      return false;
    }
  }
  return true;
}

/**
 * Commit only a genuinely different ordered event projection. DOM reads are
 * deliberately inside the commit path so an unrelated live-overlay tick does
 * not force layout or query every mounted Home card.
 */
export function commitHomeProjection(options: HomeProjectionCommitOptions): boolean {
  if (sameEventOrder(options.current, options.next)) {
    return false;
  }

  const visibleOrderChanged = !sameVisibleEventOrder(
    options.current,
    options.next,
    options.visibleLimit,
  );
  const anchor = visibleOrderChanged ? options.captureVisibleAnchor() : null;
  const nextAnchorIndex = anchor
    ? options.next.findIndex((event) => event.id === anchor.noteId)
    : -1;
  if (anchor && nextAnchorIndex >= 0) {
    if (nextAnchorIndex >= Math.max(0, options.visibleLimit)) {
      options.ensureAnchorRendered(nextAnchorIndex + 1);
    }
  }
  options.commit(options.next);
  if (visibleOrderChanged) {
    options.scheduleAnchorRestore(options.routeKey, anchor);
  }
  return true;
}
