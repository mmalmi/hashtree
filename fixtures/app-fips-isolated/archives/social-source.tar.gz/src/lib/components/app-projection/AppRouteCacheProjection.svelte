<script lang="ts">
  import { hasLiveRouteContent } from '../../appViewState';
  import { routeRenderCacheMatchesScope } from '../../appRouteState';
  import { routeKey } from '../../appRoute';
  import {
    projectMountedRouteRenderEntries,
    routeRenderCachesShallowEqual,
    type MountedRouteRenderEntry,
    type RouteRenderCache,
  } from '../../appStack';
  import type {
    AppIdentityProjection,
    AppLiveProjection,
    AppProjectionStateProps,
    AppReactiveProjectionServices,
  } from './types';

  export let routeState: AppProjectionStateProps['routeState'];
  export let homeState: AppProjectionStateProps['homeState'];
  export let profileState: AppProjectionStateProps['profileState'];
  export let threadState: AppProjectionStateProps['threadState'];
  export let engagementState: AppProjectionStateProps['engagementState'];
  export let notificationState: AppProjectionStateProps['notificationState'];
  export let runtimeState: AppProjectionStateProps['runtimeState'];
  export let identity: AppIdentityProjection;
  export let live: AppLiveProjection;
  export let services: AppReactiveProjectionServices;

  let liveRouteCache: RouteRenderCache | null = null;
  let lastPendingScrollSignature = '';

  function projectActiveEntry(
    previous: MountedRouteRenderEntry | null,
    entries: MountedRouteRenderEntry[],
    activeKey: string | null,
  ): MountedRouteRenderEntry | null {
    const next = activeKey ? entries.find((entry) => entry.key === activeKey) ?? null : null;
    return previous?.route === next?.route && previous?.cache === next?.cache ? previous : next;
  }

  $: {
    const nextLiveCache: RouteRenderCache = {
      key: routeKey($routeState.route),
      route: $routeState.route,
      rootNhash: $runtimeState.rootNhash,
      viewerPubkey: identity.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: $homeState.activeFeedSource?.pubkey ?? null,
      loading: $routeState.loading,
      feedRequiresRefresh: Boolean($homeState.feed && $homeState.feedRequiresRefresh),
      feed: $homeState.feed,
      profiles: identity.baseResolvedProfilesByPubkey,
      noteEngagements: $engagementState.displayedNoteEngagements,
      homeNotes: $homeState.homeNotes,
      homeFeedHasMore: live.homeFeedHasMore,
      homeFeedLoadPending: $homeState.homeFeedLoadPending,
      feedLimit: $homeState.feedLimit,
      homeFeedFetchLimit: $homeState.homeFeedFetchLimit,
      homeFeedLastLoadScrollOffset: $homeState.homeFeedLastLoadScrollOffset,
      notifications: $notificationState.visibleNotifications,
      notificationsLoading: $notificationState.notificationsLoading,
      notificationsHasMore: $notificationState.notificationsHasMore,
      notificationsLoadPending: $notificationState.notificationsLoadPending,
      profilePage: $profileState.profilePage,
      profileSocial: $profileState.profileSocial,
      profileSocialLoading: $profileState.profileSocialLoading,
      profileSocialLoadPending: $profileState.profileSocialLoadPending,
      profileNotesLoading: $profileState.profileNotesLoading,
      profileNotes: $profileState.profileNotes,
      profilePostCountLabel: live.profilePostCountLabel,
      profileReplyCountLabel: live.profileReplyCountLabel,
      profileMediaCountLabel: live.profileMediaCountLabel,
      profileLikesCountLabel: $profileState.profileLikesCountLabel,
      profileFeedHasMore: live.profileFeedHasMore,
      profileFeedLoadPending: $profileState.profileFeedLoadPending,
      profileNoteLimit: $profileState.profileNoteLimit,
      profileNoteFetchLimit: $profileState.profileNoteFetchLimit,
      profileFeedLastLoadScrollOffset: $profileState.profileFeedLastLoadScrollOffset,
      profileSocialVisibleLimit: $profileState.profileSocialVisibleLimit,
      profileSocialFollowerFetchLimit: $profileState.profileSocialFollowerFetchLimit,
      currentFollows: identity.currentFollows,
      currentFollowers: identity.currentFollowers,
      followsCountLabel: identity.followsCountLabel,
      followerCountLabel: identity.followerCountLabel,
      profilePersonalRoot: $profileState.profilePersonalRoot,
      threadPage: $threadState.threadPage,
      threadLoading: $threadState.threadLoading,
      threadPersonalRoot: $threadState.threadPersonalRoot,
      threadRoots: $threadState.threadRoots,
      threadReplyCursor: $threadState.threadReplyCursor,
      threadReplies: $threadState.liveThreadReplies,
      threadDurableRepliesHasMore: $threadState.durableThreadRepliesHasMore,
      threadRepliesHasMore: $threadState.threadRepliesHasMore,
      threadRepliesLoadPending: $threadState.threadRepliesLoadPending,
      threadReplyFetchLimit: $threadState.threadReplyFetchLimit,
      threadReplyLastLoadScrollOffset: $threadState.threadReplyLastLoadScrollOffset,
    };
    if (!liveRouteCache || !routeRenderCachesShallowEqual(liveRouteCache, nextLiveCache)) {
      liveRouteCache = nextLiveCache;
    }
  }
  $: if (liveRouteCache) {
    const cachedCandidate = $routeState.routeRenderCache.get(routeKey($routeState.route)) ?? null;
    const scopedCache = cachedCandidate && routeRenderCacheMatchesScope(cachedCandidate, {
      viewerPubkey: identity.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: $homeState.activeFeedSource?.pubkey ?? null,
    })
      ? cachedCandidate
      : null;
    const nextCurrentCache = !hasLiveRouteContent($routeState.route, {
      feed: $homeState.feed,
      profilePage: $profileState.profilePage,
      threadPage: $threadState.threadPage,
      notificationsCount: $notificationState.visibleNotifications.length,
      homeNoteCount: $homeState.homeNotes.length,
    })
      ? scopedCache ?? liveRouteCache
      : liveRouteCache;
    if ($routeState.currentRouteCache !== nextCurrentCache) {
      routeState.currentRouteCache = nextCurrentCache;
    }
    services.applyCurrentRouteCache(nextCurrentCache);
  }
  $: {
    const pendingSignature = $routeState.pendingScrollMode
      ? [
          $routeState.pendingScrollMode,
          routeKey($routeState.route),
          $routeState.pendingScrollRestoreKey ?? '',
          $routeState.pendingScrollRestoreOffset ?? '',
        ].join(':')
      : '';
    if (pendingSignature && pendingSignature !== lastPendingScrollSignature) {
      lastPendingScrollSignature = pendingSignature;
      services.applyPendingRouteScroll();
    } else if (!pendingSignature) {
      lastPendingScrollSignature = '';
    }
  }
  $: {
    const nextMountedEntries = projectMountedRouteRenderEntries(
      $routeState.routeStack,
      $routeState.routeRenderCache,
      $routeState.mountedRenderEntries,
    );
    if ($routeState.mountedRenderEntries !== nextMountedEntries) {
      routeState.mountedRenderEntries = nextMountedEntries;
    }
    const activeStackEntry = $routeState.routeStack[$routeState.routeStackIndex] ?? null;
    const nextActiveEntry = projectActiveEntry(
      $routeState.activeRenderEntry,
      nextMountedEntries,
      activeStackEntry?.key ?? null,
    );
    if ($routeState.activeRenderEntry !== nextActiveEntry) {
      routeState.activeRenderEntry = nextActiveEntry;
    }
  }
</script>
