import { canReadHomeFeedFromRelays } from '../../homeFeedReads';
import type { Route } from '../../appRoute';
import {
  createNotificationItem,
  getNotificationTargetReference,
  mergeNotificationItems,
  type NotificationItem,
} from '../../appDetailLoaders';
import { mergeUniqueFeedNotes, retainHomeFeedOrder } from '../../homeFeedPagination';
import {
  getBufferedLiveHomeFeedEvents,
  projectBufferedLiveHomeFeed,
  type LiveHomeFeedBuffer,
} from '../../liveHomeFeedBuffer';
import { filterMutedAuthorEvents, filterMutedAuthorItems, isMutedEvent } from '../../muteLists';
import { mergeLocalVisibleNotes } from '../../appNoteState';
import {
  getNoteEngagementTargetId,
  NOTE_ENGAGEMENT_EVENT_KINDS,
  ZERO_NOTE_ENGAGEMENT,
  mergeLiveNoteEngagementEvents,
  type NoteEngagement,
} from '../../noteEngagement';
import { allowsAddressedNotification } from '../../notificationAudience';
import { NOTIFICATION_EVENT_KINDS } from '../../notificationPagination';
import { DURABLE_POST_KINDS, type FeedSnapshot } from '../../nostrIndex';
import { PROFILE_CONTENT_KINDS, filterProfileContentEvents } from '../../profileContent';
import { getProfileReactionTargetId, projectProfileLikedNotes } from '../../profileLikes';
import type { RecentTextNoteCursor } from '../../recentTextNoteCursor';
import type { SocialEventTombstone } from '../../socialRepository';
import type { ProfileLikedNote } from '../../profileLikes';
import type { ProfileSnapshot } from '../../profileNotes';
import type { RawEvent } from '../../nostr';
import { isStrictlyBeforeRecentCursor } from '../../recentTextNoteCursor';
import { buildDisplayedNoteEngagements, mergeNotesByNewest } from '../../appDataUtils';
import { socialDataPlane } from '../../socialDataPlane';

const MAX_LIVE_VIEW_NOTE_COUNT = 256;
const PROFILE_LIVE_PROJECTION_KINDS = [...PROFILE_CONTENT_KINDS, 5];

export function reuseKnownNoteReferences(
  events: RawEvent[],
  getKnownNoteByRef: (ref: string) => RawEvent | null,
): RawEvent[] {
  let result: RawEvent[] | null = null;
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index]!;
    const known = getKnownNoteByRef(event.id);
    if (!known || known === event) {
      if (result) {
        result.push(event);
      }
      continue;
    }
    result ??= events.slice(0, index);
    result.push(known);
  }
  return result ?? events;
}

export function projectVisibleNotifications(options: {
  durable: NotificationItem[];
  cursor: RecentTextNoteCursor | null;
  mutedPubkeys: Set<string>;
  viewerFollows: Set<string>;
  viewerPubkey: string | null;
  getKnownNoteByRef(ref: string): RawEvent | null;
}): NotificationItem[] {
  const live = options.viewerPubkey
    ? socialDataPlane.query({
        kinds: NOTIFICATION_EVENT_KINDS,
        tags: { p: [options.viewerPubkey] },
      }).filter((event) => (
        !options.cursor
        || !isStrictlyBeforeRecentCursor(event.created_at, event.id, options.cursor)
      )).flatMap((event) => {
        const targetRef = getNotificationTargetReference(event);
        const target = targetRef
          ? options.getKnownNoteByRef(targetRef) ?? socialDataPlane.getEvent(targetRef)
          : null;
        const item = createNotificationItem(event, options.viewerPubkey!, target);
        return item ? [item] : [];
      })
    : [];
  const viewer = options.viewerPubkey;
  if (!viewer) { return []; }
  const knownAuthor = (id: string) =>
    (options.getKnownNoteByRef(id) ?? socialDataPlane.getEvent(id))?.pubkey;
  return filterMutedAuthorItems(
    mergeNotificationItems(options.durable, live),
    options.mutedPubkeys,
    viewer,
    { hideMentions: true, explicitAuthors: options.viewerFollows },
  ).filter(item => allowsAddressedNotification(item.actorEvent, viewer, options.viewerFollows, knownAuthor));
}

export type VisibleNotificationsInput = Parameters<typeof projectVisibleNotifications>[0] & {
  liveOverlayVersion: number;
  knownNotesVersion: number;
};

export function createVisibleNotificationsProjector() {
  let previousInput: VisibleNotificationsInput | null = null;
  let previousResult: NotificationItem[] = [];
  return (input: VisibleNotificationsInput): NotificationItem[] => {
    const unchanged = previousInput
      && previousInput.durable === input.durable
      && previousInput.cursor === input.cursor
      && previousInput.mutedPubkeys === input.mutedPubkeys
      && previousInput.viewerFollows === input.viewerFollows
      && previousInput.knownNotesVersion === input.knownNotesVersion
      && previousInput.viewerPubkey === input.viewerPubkey
      && previousInput.getKnownNoteByRef === input.getKnownNoteByRef
      && previousInput.liveOverlayVersion === input.liveOverlayVersion;
    if (!unchanged) {
      previousInput = input;
      previousResult = projectVisibleNotifications(input);
    }
    return previousResult;
  };
}

export function projectDisplayedEngagements(options: {
  durable: Map<string, NoteEngagement>;
  optimistic: Parameters<typeof buildDisplayedNoteEngagements>[1];
  visibleEvents: RawEvent[];
  viewerPubkey: string | null;
  liveEvents?: RawEvent[];
  rankingEvents?: RawEvent[];
}): Map<string, NoteEngagement> {
  const visibleIds = new Set([
    ...options.durable.keys(),
    ...options.visibleEvents.map(getNoteEngagementTargetId),
  ]);
  const seeded = new Map(options.durable);
  for (const noteId of visibleIds) {
    if (!seeded.has(noteId)) {
      seeded.set(noteId, ZERO_NOTE_ENGAGEMENT);
    }
  }
  const live = options.liveEvents ?? queryVisibleLiveEngagementEvents(visibleIds);
  const ranking = options.rankingEvents?.length
    ? socialDataPlane.filterVisibleExternalEvents(options.rankingEvents) : [];
  return buildDisplayedNoteEngagements(
    mergeLiveNoteEngagementEvents(seeded, ranking.length ? [...live, ...ranking] : live, options.viewerPubkey),
    options.optimistic,
  );
}

export function queryVisibleLiveEngagementEvents(noteIds: ReadonlySet<string>): RawEvent[] {
  return noteIds.size > 0
    ? socialDataPlane.query({ kinds: NOTE_ENGAGEMENT_EVENT_KINDS, tags: { e: [...noteIds] } })
    : [];
}

export function visibleEngagementIds(
  durable: ReadonlyMap<string, NoteEngagement>,
  visibleEvents: readonly RawEvent[],
): Set<string> {
  return new Set([...durable.keys(), ...visibleEvents.map(getNoteEngagementTargetId)]);
}

export type DisplayedEngagementsInput = Parameters<typeof projectDisplayedEngagements>[0] & {
  liveOverlayVersion: number;
};

/**
 * Engagements are only needed for the route that is currently visible.  Keeping
 * inactive route data out of this input is important: a route switch must not
 * walk every retained feed before its wrapper can be revealed.
 */
export function selectActiveRouteEngagementEvents(options: {
  route: Route;
  homeNotes: RawEvent[];
  profileNotes: RawEvent[];
  threadReplies: RawEvent[];
  threadNote: RawEvent | null;
  threadContext: RawEvent[];
}): RawEvent[] {
  switch (options.route.kind) {
    case 'home':
      return options.homeNotes;
    case 'profile':
      return options.profileNotes;
    case 'thread':
      return [
        ...options.threadReplies,
        ...(options.threadNote ? [options.threadNote] : []),
        ...options.threadContext,
      ];
    default:
      return [];
  }
}

export function createDisplayedEngagementsProjector() {
  let previousInput: DisplayedEngagementsInput | null = null;
  let previousResult = new Map<string, NoteEngagement>();
  return (input: DisplayedEngagementsInput): Map<string, NoteEngagement> => {
    const sameVisibleEvents = previousInput
      && previousInput.visibleEvents.length === input.visibleEvents.length
      && previousInput.visibleEvents.every((event, index) => event.id === input.visibleEvents[index]?.id);
    const unchanged = previousInput
      && previousInput.durable === input.durable
      && previousInput.optimistic === input.optimistic
      && previousInput.viewerPubkey === input.viewerPubkey
      && previousInput.liveOverlayVersion === input.liveOverlayVersion
      && previousInput.liveEvents === input.liveEvents
      && previousInput.rankingEvents === input.rankingEvents
      && sameVisibleEvents;
    if (!unchanged) {
      previousInput = input;
      previousResult = projectDisplayedEngagements(input);
    }
    return previousResult;
  };
}

export function projectBufferedHomeEvents(
  buffer: LiveHomeFeedBuffer,
  isEligible: (event: RawEvent) => boolean,
): RawEvent[] {
  return getBufferedLiveHomeFeedEvents(buffer, (event) => {
    const status = socialDataPlane.getEventStatus(event.id);
    return status !== 'deleted'
      && status !== 'superseded'
      && status !== 'deletion'
      && isEligible(event);
  });
}

export type HomeNotesProjectionInput = {
  route: Route;
  feed: FeedSnapshot | null;
  localPostsByAuthor: Map<string, RawEvent[]>;
  buffer: LiveHomeFeedBuffer;
  tombstones: SocialEventTombstone[];
  /** Hidden identities: direct mutes plus overmuted users the viewer does not follow. */
  mutedPubkeys: Set<string>;
  /** Followed authors keep posts that mention hidden users. */
  viewerFollows?: ReadonlySet<string>;
  /** Muted by the viewer this session; these leave even painted rows. */
  sessionMutedPubkeys?: ReadonlySet<string>;
  /** Rows already on screen. Late mute data never removes them. */
  paintedIds?: ReadonlySet<string>;
  viewerPubkey: string | null;
  feedLimit: number;
  homeFeedFetchLimit: number;
  liveAuthors: string[];
  liveOverlayVersion: number;
  repositoryVersion: number;
};

const NO_PUBKEYS: ReadonlySet<string> = new Set();

/**
 * Same policy as iris-client feeds: hide hidden authors, reposts of them and,
 * unless a followed author wrote it, posts that tag them. Painted rows stay put
 * when mute data arrives late; only the viewer's own mute action removes them.
 */
function filterHiddenHomeEvents(events: RawEvent[], options: HomeNotesProjectionInput): RawEvent[] {
  const policy = { hideMentions: true, explicitAuthors: options.viewerFollows };
  return events.filter((event) => (
    options.paintedIds?.has(event.id)
      ? !isMutedEvent(event, options.sessionMutedPubkeys ?? NO_PUBKEYS, options.viewerPubkey)
      : !isMutedEvent(event, options.mutedPubkeys, options.viewerPubkey, policy)
  ));
}

export function projectHomeNotes(options: HomeNotesProjectionInput): RawEvent[] {
  if (options.route.kind === 'home' && options.route.tab === 'popular') {
    const notes = options.feed?.feedOwnerPubkey === 'popular' ? options.feed.notes : [];
    return filterHiddenHomeEvents(notes.filter(note => socialDataPlane.isExternalEventVisible(note)), options);
  }
  const favorites = options.route.kind === 'home' && options.route.tab === 'favorites';
  const ranked = options.route.kind === 'home' && options.route.tab === 'for-you';
  const allowedAuthors = new Set(options.liveAuthors);
  const indexedNotes = (options.feed?.notes ?? []).filter((event) => !favorites || allowedAuthors.has(event.pubkey));
  const liveLimit = Math.max(
    indexedNotes.length,
    Math.min(MAX_LIVE_VIEW_NOTE_COUNT, Math.max(options.homeFeedFetchLimit, options.feedLimit)),
  );
  const mergedNotes = favorites && allowedAuthors.size === 0 ? [] : options.route.kind === 'home'
    ? ranked
      ? socialDataPlane.getRankedTextNotes(indexedNotes, {
          authors: options.liveAuthors,
          includeReplies: false,
          kinds: DURABLE_POST_KINDS,
          limit: liveLimit,
        })
      : socialDataPlane.getLiveTextNotes(indexedNotes, {
          authors: options.liveAuthors,
          includeReplies: true,
          kinds: DURABLE_POST_KINDS,
          limit: liveLimit + options.buffer.events.length,
          retainSnapshotEvents: true,
        })
    : indexedNotes;
  // Signed local posts are ready independently of the first archive response.
  const includeLocalPosts = !favorites && !ranked && options.viewerPubkey && allowedAuthors.has(options.viewerPubkey);
  const visibleNotes = includeLocalPosts
    ? mergeLocalVisibleNotes(options.localPostsByAuthor, mergedNotes, options.viewerPubkey)
    : mergedNotes;
  const unmuted = filterHiddenHomeEvents(
    projectBufferedLiveHomeFeed(
      visibleNotes,
      options.buffer,
      options.buffer.events.length > 0 ? options.tombstones : [],
      ranked,
    ),
    options,
  ).filter((event) => !favorites || allowedAuthors.has(event.pubkey));
  if (options.route.kind === 'home' && options.route.tab === 'latest') {
    return mergeUniqueFeedNotes(unmuted);
  }
  return options.route.kind === 'home' && (options.route.tab === 'for-you' || favorites)
    ? retainHomeFeedOrder(unmuted, options.feed?.displayOrder ?? [],
        options.route.tab === 'for-you' ? 'for-you' : 'latest')
    : unmuted;
}

function homeInputsEqual(
  left: HomeNotesProjectionInput,
  right: HomeNotesProjectionInput,
): boolean {
  return left.route === right.route
    && left.feed === right.feed
    && left.localPostsByAuthor === right.localPostsByAuthor
    && left.buffer === right.buffer
    && left.mutedPubkeys === right.mutedPubkeys
    && left.viewerFollows === right.viewerFollows
    && left.sessionMutedPubkeys === right.sessionMutedPubkeys
    && left.viewerPubkey === right.viewerPubkey
    && left.feedLimit === right.feedLimit
    && left.homeFeedFetchLimit === right.homeFeedFetchLimit
    && left.liveOverlayVersion === right.liveOverlayVersion
    && left.repositoryVersion === right.repositoryVersion
    && left.liveAuthors.length === right.liveAuthors.length
    && left.liveAuthors.every((author, index) => author === right.liveAuthors[index]);
}

export function createHomeNotesProjector() {
  let previousInput: HomeNotesProjectionInput | null = null;
  let previousResult: RawEvent[] = [];
  return (input: HomeNotesProjectionInput): RawEvent[] => {
    if (!previousInput || !homeInputsEqual(previousInput, input)) {
      // Keep the painted prefix for recommendations and Favorites. Latest
      // uses the viewport anchor to keep the reader in place when history fills in.
      const retainPainted = previousInput && input.feed
        && previousInput.route.kind === 'home' && input.route.kind === 'home'
        && ['for-you', 'favorites'].includes(input.route.tab)
        && previousInput.route.tab === input.route.tab
        && previousInput.viewerPubkey === input.viewerPubkey
        && previousInput.feed?.rootNhash === input.feed.rootNhash
        && previousInput.feed?.feedOwnerPubkey === input.feed.feedOwnerPubkey
        && (previousInput.feed.notes === input.feed.notes || input.feed.displayOrder)
        && previousInput.localPostsByAuthor === input.localPostsByAuthor
        && previousInput.buffer === input.buffer;
      const sameView = previousInput
        && previousInput.route.kind === 'home' && input.route.kind === 'home'
        && previousInput.route.tab === input.route.tab
        && previousInput.viewerPubkey === input.viewerPubkey;
      const paintedIds = previousInput && sameView && !input.paintedIds
        ? new Set(previousResult.slice(0, previousInput.feedLimit).map(event => event.id))
        : input.paintedIds;
      const next = projectHomeNotes(paintedIds ? { ...input, paintedIds } : input);
      previousResult = retainPainted
        ? retainHomeFeedOrder(next, previousResult.slice(0, input.feedLimit).map(event => event.id),
            input.route.kind === 'home' && input.route.tab === 'for-you' ? 'for-you' : 'latest')
        : next;
      previousInput = input;
    }
    return previousResult;
  };
}

export type ProfileNotesProjectionInput = {
  profilePubkey: string | null;
  profilePage: ProfileSnapshot | null;
  knownNotes: RawEvent[];
  localPostsByAuthor: Map<string, RawEvent[]>;
  mutedPubkeys: Set<string>;
  viewerPubkey: string | null;
  profileNoteFetchLimit: number;
  profileNoteLimit: number;
  liveOverlayVersion: number;
};

export function projectProfileNotes(
  options: ProfileNotesProjectionInput,
): { events: RawEvent[]; sourceHasMore: boolean } {
  const indexedNotes = mergeNotesByNewest(
    options.knownNotes,
    options.profilePage?.notes ?? [],
  );
  const liveProfileEvents = options.profilePubkey
    ? socialDataPlane.query({
        authors: [options.profilePubkey],
        kinds: PROFILE_LIVE_PROJECTION_KINDS,
        includeDeletionEvents: true,
      })
    : [];
  // Apply the visible section limit after merging. A relay may fill gaps in
  // the archive, so either source's length can be smaller than the union.
  const merged = mergeNotesByNewest(indexedNotes, liveProfileEvents);
  return {
    events: filterMutedAuthorEvents(
      mergeLocalVisibleNotes(options.localPostsByAuthor, merged, options.profilePubkey),
      options.mutedPubkeys,
      options.viewerPubkey,
    ),
    sourceHasMore: Boolean(
      options.profilePubkey
      && ((options.profilePage?.relayContinuation?.hasMore && canReadHomeFeedFromRelays()) || (options.profilePage?.durableHasMore
        ?? (options.profilePage?.notes.length ?? 0) >= options.profileNoteFetchLimit))
    ),
  };
}

function profileInputsEqual(
  left: ProfileNotesProjectionInput,
  right: ProfileNotesProjectionInput,
): boolean {
  return left.profilePubkey === right.profilePubkey
    && left.profilePage === right.profilePage
    && left.knownNotes === right.knownNotes
    && left.localPostsByAuthor === right.localPostsByAuthor
    && left.mutedPubkeys === right.mutedPubkeys
    && left.viewerPubkey === right.viewerPubkey
    && left.profileNoteFetchLimit === right.profileNoteFetchLimit
    && left.profileNoteLimit === right.profileNoteLimit
    && left.liveOverlayVersion === right.liveOverlayVersion;
}

export function createProfileNotesProjector() {
  let previousInput: ProfileNotesProjectionInput | null = null;
  let previousResult = { events: [] as RawEvent[], sourceHasMore: false };
  return (input: ProfileNotesProjectionInput) => {
    if (!previousInput || !profileInputsEqual(previousInput, input)) {
      previousInput = input;
      previousResult = projectProfileNotes(input);
    }
    return previousResult;
  };
}

export function projectThreadReplies(options: {
  active: boolean;
  durableReplies: RawEvent[];
  referenceEvents: RawEvent[];
  mutedPubkeys: Set<string>;
  viewerFollows?: ReadonlySet<string>;
  viewerPubkey: string | null;
  fetchLimit: number;
}): RawEvent[] {
  return options.active
    ? filterMutedAuthorEvents(
        socialDataPlane.getLiveThreadReplies(
          options.durableReplies,
          options.referenceEvents,
          Math.max(options.durableReplies.length, options.fetchLimit + 1),
        ),
        options.mutedPubkeys,
        options.viewerPubkey,
        { hideMentions: true, explicitAuthors: options.viewerFollows },
      )
    : options.durableReplies;
}

export type ThreadRepliesProjectionInput = Parameters<typeof projectThreadReplies>[0] & {
  liveOverlayVersion: number;
};

export function createThreadRepliesProjector() {
  let previousInput: ThreadRepliesProjectionInput | null = null;
  let previousResult: RawEvent[] = [];
  return (input: ThreadRepliesProjectionInput): RawEvent[] => {
    const sameReferences = previousInput
      && previousInput.referenceEvents.length === input.referenceEvents.length
      && previousInput.referenceEvents.every((event, index) => event.id === input.referenceEvents[index]?.id);
    const unchanged = previousInput
      && previousInput.active === input.active
      && previousInput.durableReplies === input.durableReplies
      && previousInput.mutedPubkeys === input.mutedPubkeys
      && previousInput.viewerFollows === input.viewerFollows
      && previousInput.viewerPubkey === input.viewerPubkey
      && previousInput.fetchLimit === input.fetchLimit
      && previousInput.liveOverlayVersion === input.liveOverlayVersion
      && sameReferences;
    if (!unchanged) {
      previousInput = input;
      previousResult = projectThreadReplies(input);
    }
    return previousResult;
  };
}

export function projectLikedNotes(options: {
  profilePubkey: string | null;
  profilePage: ProfileSnapshot | null;
  getKnownNoteByRef(ref: string): RawEvent | null;
  hiddenPubkeys?: ReadonlySet<string>;
  viewerPubkey?: string | null;
}): ProfileLikedNote[] {
  const indexed = options.profilePage?.likedNotes ?? [];
  const reactions = options.profilePubkey
    ? socialDataPlane.projectSnapshot(
        indexed.map((item) => item.reaction),
        { authors: [options.profilePubkey], kinds: [7] },
      )
    : indexed.map((item) => item.reaction);
  const targets = new Map(indexed.map((item) => [item.note.id, item.note] as const));
  for (const reaction of reactions) {
    const targetId = getProfileReactionTargetId(reaction);
    const target = targetId
      ? options.getKnownNoteByRef(targetId) ?? socialDataPlane.getEvent(targetId)
      : null;
    if (targetId && target) {
      targets.set(targetId, target);
    }
  }
  const liked = projectProfileLikedNotes(reactions, targets);
  return options.hiddenPubkeys?.size
    ? liked.filter(({ note }) => !isMutedEvent(note, options.hiddenPubkeys!, options.viewerPubkey ?? null))
    : liked;
}

export type LikedNotesProjectionInput = Parameters<typeof projectLikedNotes>[0] & {
  liveOverlayVersion: number;
};

export function createLikedNotesProjector() {
  let previousInput: LikedNotesProjectionInput | null = null;
  let previousResult: ProfileLikedNote[] = [];
  return (input: LikedNotesProjectionInput): ProfileLikedNote[] => {
    const unchanged = previousInput
      && previousInput.profilePubkey === input.profilePubkey
      && previousInput.profilePage === input.profilePage
      && previousInput.getKnownNoteByRef === input.getKnownNoteByRef
      && previousInput.hiddenPubkeys === input.hiddenPubkeys
      && previousInput.liveOverlayVersion === input.liveOverlayVersion;
    if (!unchanged) {
      previousInput = input;
      previousResult = projectLikedNotes(input);
    }
    return previousResult;
  };
}

export function splitProfileEvents(events: RawEvent[]) {
  return {
    posts: filterProfileContentEvents(events, 'posts'),
    replies: filterProfileContentEvents(events, 'replies'),
    reposts: filterProfileContentEvents(events, 'reposts'),
    media: filterProfileContentEvents(events, 'media'),
  };
}

export function createProfileEventSplitter() {
  let previousEvents: RawEvent[] | null = null;
  let previousResult = splitProfileEvents([]);
  return (events: RawEvent[]) => {
    if (events !== previousEvents) {
      previousEvents = events;
      previousResult = splitProfileEvents(events);
    }
    return previousResult;
  };
}

export function profileCountLabel(count: number, loading: boolean, hasMore: boolean): string {
  return loading || hasMore
    ? count > 0 ? `${count}+` : '...'
    : `${count}`;
}
