<script lang="ts">
  import { contactMemoryStore } from '../contactMemoryStore';
  import SocialDistanceBadge from '@iris/svelte-ui/SocialDistanceBadge.svelte';
  import { socialGraphBadges, createSocialGraphBadgeBinding } from '../socialGraphBadges';
  import { onDestroy } from 'svelte';
  import { createProfileRefreshBinding } from '../browserProfileRefresh';
  import ProxyImg from './ProxyImg.svelte';
  import {
    ensureProfile,
    profileNeedsIndexHydration,
    rememberProfileRecord,
    sharedProfilesStore,
  } from '../profileCache';
  import { getProfileTitle, type ProfileRecord } from '../nostr';
  import { getRouteActivity } from '../routeActivity';

  export let pubkey: string;
  export let profile: ProfileRecord | null = null;
  export let size = 52;
  export let showBadge = true;
  export let className = '';
  export let backgroundColor: string | null = null;
  const routeActivity = getRouteActivity();
  const syncBadge = createSocialGraphBadgeBinding();
  $: syncBadge(showBadge && size >= 28 && $routeActivity ? pubkey : null);
  $: badge = $socialGraphBadges.get(pubkey);
  $: hasBadge = badge?.muted || (badge?.distance !== undefined
    && badge.distance !== null && badge.distance <= 2);
  onDestroy(() => syncBadge(null));
  const syncProfileRefresh = createProfileRefreshBinding();
  $: syncProfileRefresh(pubkey, $routeActivity);
  onDestroy(() => syncProfileRefresh(null));

  function initialsFromName(source: string): string {
    const words = source.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      return 'IS';
    }
    if (words.length === 1) {
      return words[0].slice(0, 2).toUpperCase();
    }
    return `${words[0][0]}${words[1][0]}`.toUpperCase();
  }

  $: rememberProfileRecord(profile);
  $: cachedProfile = $sharedProfilesStore.get(pubkey) ?? null;
  $: resolvedProfile = cachedProfile ?? profile;
  $: avatarUrl = resolvedProfile?.picture?.trim() || '';
  $: initials = initialsFromName(label);
  $: surfaceColor = backgroundColor ?? 'var(--iris-surface-raised)';
  $: label = $contactMemoryStore.contacts.get(pubkey)?.nickname || $contactMemoryStore.contacts.get(pubkey)?.accepted_name || getProfileTitle(resolvedProfile, pubkey);
  $: if ($routeActivity && profileNeedsIndexHydration(resolvedProfile, ['picture'])) {
    void ensureProfile(pubkey);
  }
</script>

<div class="relative shrink-0" style={`width:${size}px;height:${size}px;`}>
  <div
    data-testid="avatar"
    role="img"
    aria-label={label}
    class={`relative grid shrink-0 place-items-center overflow-hidden rounded-full font-600 text-[0.9rem] text-[rgb(var(--iris-text-rgb))] shadow-[0_10px_24px_rgba(0,0,0,0.25)] ${className}`.trim()}
    style={`width:${size}px;height:${size}px;background-color:${surfaceColor};background-image:none;`}
  >
    <span aria-hidden="true">{initials}</span>
    {#if avatarUrl}
      <ProxyImg
        alt=""
        src={avatarUrl}
        width={size}
        height={size}
        square={true}
        showUnavailable={false}
        className="absolute inset-0 h-full w-full rounded-full object-cover"
        style={`background-color:${surfaceColor};`}
      />
    {/if}
  </div>

  {#if showBadge && size >= 28 && hasBadge}
    <span class="absolute top-0 right-0 flex h-4 w-4 items-center justify-center">
      <SocialDistanceBadge size={16} distance={badge?.distance} followedByFriends={badge?.followedByFriends} muted={badge?.muted} className="iris-preserve-white-text" />
    </span>
  {/if}
</div>
