<script lang="ts">
  import { onDestroy } from 'svelte';
  import LongformHeader from './LongformHeader.svelte';
  import NoteActionsMenu from './NoteActionsMenu.svelte';
  import NoteEngagementBar from './NoteEngagementBar.svelte';
  import NoteEmbeds from './NoteEmbeds.svelte';
  import NoteText from './NoteText.svelte';
  import type ArticleContentComponent from './ArticleContent.svelte';
  import { isLongformEvent } from '../longform';
  import InlineNoteQuote from './InlineNoteQuote.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import type { NoteEmbed } from '../noteContent';
  import type { ReferencedNotePreview } from '../referencedNote';
  import { buildNoteThreadReference } from '../appSharing';
  import UserRow from './UserRow.svelte';
  import {
    getProfileTitle,
    getThreadParentReference,
    type ProfileRecord,
    type RawEvent,
  } from '../nostr';
  import type { NoteEngagement } from '../noteEngagement';
  import { createHomeFeedSeenDwellTracker } from '../homeFeedSeen';
  import { observeFeedCardVisibility } from '../feedCardVisibility';
  import {
    getKind6RepostTargetReference,
    getVerifiedEmbeddedRepostTarget,
    needsEmbeddedRepostAdmission,
    requestEmbeddedRepostAdmission,
    resolveKind6RepostTarget,
    type RepostTargetProjection,
  } from '../repostPresentation';

  export let event: RawEvent;
  export let profile: ProfileRecord | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let engagement: NoteEngagement | null = null;
  export let engagements: Map<string, NoteEngagement> = new Map();
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: ((target: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let liked = false;
  export let likePending = false;
  export let likeDisabled = false;
  export let onLike: ((event: RawEvent) => void) | null = null;
  export let zapPending = false;
  export let zapDisabled = false;
  export let onZap: ((event: RawEvent) => void) | null = null;
  export let onReply: ((event: RawEvent) => void) | null = null;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: ((event: RawEvent) => void) | null = null;
  export let repostPending = false;
  export let onShare: ((event: RawEvent) => void) | null = null;
  export let onOpenReactions: ((event: RawEvent) => void) | null = null;
  export let onCopyLink: ((event: RawEvent) => void) | null = null;
  export let onCopyEventId: ((event: RawEvent) => void) | null = null;
  export let onRebroadcast: ((event: RawEvent) => void) | null = null;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let rebroadcastPending = false;
  export let activeMediaUrl: string | null = null;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let compact = false;
  export let showRepliedTo = false;
  export let showEmbeds = true;
  export let showEngagement = true;
  export let textCollapsible = true;
  export let className = '';
  export let isActive = true;
  export let onPresented: ((event: RawEvent) => void) | null = null;
  export let onVisible: ((event: RawEvent, presentedEvent: RawEvent | null) => void) | null = null;

  const CAROUSEL_CLICK_SUPPRESSION_MS = 800;

  let resolvedRepostTarget: RepostTargetProjection | null = null;
  let resolvingRepostTarget = false;
  let repostResolutionRequestId = 0;
  let lastRepostResolutionEvent: RawEvent | null = null;
  let lastRepostResolver: typeof resolveReferencedNote = null;
  let suppressCardClickUntil = 0;
  let cardVisible = false;
  let repostAdmissionVersion = 0;
  let embeddedRepostTarget: RawEvent | null = null;
  let lastPresentedIdentity = '';
  let ArticleContent: typeof ArticleContentComponent | null = null;
  let articleLoading = false;
  let articleLoadFailed = false;
  const seenDwellTracker = createHomeFeedSeenDwellTracker((visibleEvent, visiblePresentedEvent) => {
    onVisible?.(visibleEvent, visiblePresentedEvent);
  });

  function trackVisibility(node: HTMLElement, initiallyEnabled: boolean) {
    let enabled = initiallyEnabled;
    let stopObserving: (() => void) | null = null;

    const stop = () => {
      cardVisible = false;
      seenDwellTracker.update(event, presentedEvent, false);
      stopObserving?.();
      stopObserving = null;
    };
    const start = () => {
      if (!enabled || stopObserving) {
        return;
      }
      stopObserving = observeFeedCardVisibility(node, (visible) => {
        cardVisible = visible;
      });
    };

    start();
    return {
      update(nextEnabled: boolean) {
        if (nextEnabled === enabled) {
          return;
        }
        enabled = nextEnabled;
        if (enabled) {
          start();
        } else {
          stop();
        }
      },
      destroy() {
        stop();
      },
    };
  }

  $: { repostAdmissionVersion; embeddedRepostTarget = getVerifiedEmbeddedRepostTarget(event); }
  $: if (event.kind === 6 && needsEmbeddedRepostAdmission(event)) {
    void requestEmbeddedRepostAdmission(event)
      .then(() => { repostAdmissionVersion += 1; })
      .catch(() => undefined);
  }
  $: repostTarget = event.kind === 6
    ? embeddedRepostTarget ?? resolvedRepostTarget?.event ?? null
    : event;
  $: presentedEvent = event.kind === 6 ? repostTarget : event;
  $: if (presentedEvent && isLongformEvent(presentedEvent) && !ArticleContent && !articleLoading && !articleLoadFailed) {
    articleLoading = true;
    void import('./ArticleContent.svelte').then(module => {
      ArticleContent = module.default;
    }).catch(() => { articleLoadFailed = true; }).finally(() => { articleLoading = false; });
  }
  $: if (presentedEvent && onPresented) {
    const identity = `${presentedEvent.id}:${presentedEvent.sig}`;
    if (identity !== lastPresentedIdentity) {
      lastPresentedIdentity = identity;
      onPresented(presentedEvent);
    }
  }
  $: presentedProfile = presentedEvent
    ? presentedEvent.id === event.id
      ? profile
      : profiles.get(presentedEvent.pubkey) ?? resolvedRepostTarget?.profile ?? null
    : null;
  $: presentedEngagement = presentedEvent
    ? presentedEvent.id === event.id
      ? engagement
      : engagements.get(presentedEvent.id) ?? null
    : null;
  $: presentedLiked = presentedEvent?.id === event.id
    ? liked
    : presentedEngagement?.viewerReacted ?? false;
  $: repostTargetReference = getKind6RepostTargetReference(event);
  $: repliedToReference = showRepliedTo && presentedEvent
    ? getThreadParentReference(presentedEvent)
    : null;
  $: seenDwellTracker.update(event, presentedEvent, cardVisible && Boolean(onVisible));
  $: scheduleRepostResolution(
    event,
    embeddedRepostTarget,
    isActive ? resolveReferencedNote : null,
  );

  onDestroy(() => seenDwellTracker.destroy());

  function scheduleRepostResolution(
    wrapper: RawEvent,
    embeddedTarget: RawEvent | null,
    resolver: typeof resolveReferencedNote,
  ): void {
    if (lastRepostResolutionEvent === wrapper && lastRepostResolver === resolver) {
      return;
    }
    const wrapperChanged = lastRepostResolutionEvent?.id !== wrapper.id;
    lastRepostResolutionEvent = wrapper;
    lastRepostResolver = resolver;
    const requestId = ++repostResolutionRequestId;
    if (wrapperChanged || embeddedTarget) {
      resolvedRepostTarget = null;
    }

    if (wrapper.kind !== 6 || embeddedTarget) {
      resolvingRepostTarget = false;
      return;
    }
    if (!resolver) {
      // Pausing a retained route must stop background resolution without
      // collapsing an already-rendered repost body. The same DOM is revealed
      // on Back, so keep its last verified projection and its exact height.
      resolvingRepostTarget = false;
      return;
    }
    if (!wrapperChanged && resolvedRepostTarget) {
      resolvingRepostTarget = false;
      return;
    }

    resolvingRepostTarget = true;
    void resolveKind6RepostTarget(wrapper, resolver).then((projection) => {
      if (requestId === repostResolutionRequestId) {
        resolvedRepostTarget = projection;
      }
    }).finally(() => {
      if (requestId === repostResolutionRequestId) {
        resolvingRepostTarget = false;
      }
    });
  }

  function shouldIgnoreCardActivation(target: EventTarget | null): boolean {
    return target instanceof Element && Boolean(
      target.closest('a, button, input, textarea, select, summary, video, audio, label, [data-note-no-thread-nav]'),
    );
  }

  function handleCarouselGesture(): void {
    suppressCardClickUntil = Date.now() + CAROUSEL_CLICK_SUPPRESSION_MS;
  }

  function activateNoteThread(): void {
    const target = presentedEvent
      ? buildNoteThreadReference(presentedEvent)
      : repostTargetReference;
    if (target) {
      onOpenNote?.(target);
    }
  }

  function handleCardClick(mouseEvent: MouseEvent): void {
    if (Date.now() < suppressCardClickUntil) {
      mouseEvent.preventDefault();
      mouseEvent.stopPropagation();
      return;
    }
    if (
      !onOpenNote ||
      mouseEvent.button !== 0 ||
      mouseEvent.metaKey ||
      mouseEvent.ctrlKey ||
      mouseEvent.shiftKey ||
      mouseEvent.altKey ||
      shouldIgnoreCardActivation(mouseEvent.target)
    ) {
      return;
    }

    if (typeof window !== 'undefined') {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed && selection.toString().trim()) {
        return;
      }
    }

    mouseEvent.preventDefault();
    activateNoteThread();
  }

  function handleCardKeydown(keyboardEvent: KeyboardEvent): void {
    if (
      !onOpenNote ||
      shouldIgnoreCardActivation(keyboardEvent.target) ||
      (keyboardEvent.key !== 'Enter' && keyboardEvent.key !== ' ')
    ) {
      return;
    }

    keyboardEvent.preventDefault();
    activateNoteThread();
  }

</script>

<div
  use:trackVisibility={isActive && Boolean(onVisible)}
  data-testid="note-card"
  data-note-id={event.id}
  data-presented-note-id={presentedEvent?.id ?? ''}
  data-presented-note-author={presentedEvent?.pubkey ?? ''}
  data-repost-wrapper={event.kind === 6}
  data-feed-layout={compact ? 'compact' : 'cozy'}
  class={`iris-feed-card group border-b border-white/5 px-4 py-3 transition-colors duration-150 hover:bg-[#0a0a0a] sm:px-5 ${
    compact ? 'py-2.5' : ''
  } ${onOpenNote ? 'cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-white/35' : ''} ${className}`.trim()}
  role="link"
  tabindex="0"
  aria-label="Open thread"
  aria-disabled={!onOpenNote}
  on:click={handleCardClick}
  on:keydown={handleCardKeydown}
>
  <article class={`grid ${compact ? 'gap-1.5' : 'gap-2'}`}>
    {#if event.kind === 6}
      <div
        data-testid="note-repost-attribution"
        data-reposter-pubkey={event.pubkey}
        class={`flex min-w-0 items-center gap-1.5 text-white/48 ${compact ? 'pl-[2.35rem] text-[0.76rem]' : 'pl-[2.7rem] text-[0.8rem]'}`}
      >
        <IrisIcon name="repost" size={16} className="shrink-0" />
        {#if onOpenProfile}
          <button
            type="button"
            class="truncate font-700 transition hover:text-white/75"
            on:click={() => onOpenProfile(event.pubkey)}
          >
            {getProfileTitle(profile, event.pubkey)} reposted
          </button>
        {:else}
          <span class="truncate font-700">{getProfileTitle(profile, event.pubkey)} reposted</span>
        {/if}
      </div>
    {/if}

    {#if presentedEvent}
      <UserRow
        pubkey={presentedEvent.pubkey}
        profile={presentedProfile}
        {profiles}
        {viewerPubkey}
        following={viewerFollows.has(presentedEvent.pubkey)}
        followPending={followPendingPubkeys.has(presentedEvent.pubkey)}
        onToggleFollow={viewerPubkey && viewerPubkey !== presentedEvent.pubkey
          ? onToggleFollow
          : null}
        onOpenThread={onOpenNote}
        avatarSize={compact ? 34 : 40}
        timestamp={presentedEvent.created_at}
        showSubtitle={false}
        gapClass="gap-2"
        titleClass={compact ? 'truncate text-[0.93rem] font-700 text-white' : 'truncate text-[0.97rem] font-700 text-white'}
        subtitleClass="mt-0.5 truncate text-[0.8rem] text-white/55"
        timeClass="text-[0.8rem] text-white/45"
        onOpenProfile={onOpenProfile}
      >
        <svelte:fragment slot="end">
          <NoteActionsMenu
            event={presentedEvent}
            {rebroadcastPending}
            onQuote={onQuote ? () => onQuote?.(presentedEvent as RawEvent) : null}
            onShowReactions={onOpenReactions ? () => onOpenReactions?.(presentedEvent as RawEvent) : null}
            onCopyLink={onCopyLink ? () => onCopyLink?.(presentedEvent as RawEvent) : null}
            onCopyEventId={onCopyEventId ? () => onCopyEventId?.(presentedEvent as RawEvent) : null}
            onRebroadcast={onRebroadcast ? () => onRebroadcast?.(presentedEvent as RawEvent) : null}
            onDelete={onDelete && viewerPubkey === presentedEvent.pubkey
              ? () => onDelete?.(presentedEvent as RawEvent)
              : null}
            {isActive}
          />
        </svelte:fragment>
      </UserRow>

      <div class={`min-w-0 ${compact ? 'pl-[2.35rem]' : 'pl-[2.7rem]'}`}>
        <div>
        <LongformHeader event={presentedEvent} {compact} showSummary={!textCollapsible} />
        {#if repliedToReference}
          <div data-testid="note-replied-to-context">
            <InlineNoteQuote
              bech32={repliedToReference}
              {onOpenNote}
              {onOpenProfile}
              {resolveReferencedNote}
            />
          </div>
        {/if}
        {#if isLongformEvent(presentedEvent)}
          {#if ArticleContent}
            <svelte:component this={ArticleContent} event={presentedEvent} {compact} collapsible={textCollapsible} showImages={showEmbeds} {onOpenProfile} {onOpenNote} {onOpenMedia} />
          {:else}
            <p class="text-sm text-white/50">{articleLoadFailed ? 'Could not load article.' : 'Loading article…'}</p>
          {/if}
        {:else}
        <NoteText
          event={presentedEvent}
          profile={presentedProfile}
          {profiles}
          {onOpenProfile}
          {onOpenNote}
          {resolveReferencedNote}
          compact={compact}
          collapsible={textCollapsible}
          {isActive}
        />
        {#if showEmbeds}
          <NoteEmbeds
            event={presentedEvent}
            limit={compact ? 3 : 4}
            viewActive={isActive}
            {activeMediaUrl}
            {onOpenMedia}
            onCarouselGesture={handleCarouselGesture}
          />
        {/if}
        {/if}
      </div>
      {#if showEngagement}
        <NoteEngagementBar
          engagement={presentedEngagement}
          liked={presentedLiked}
          {likePending}
          {likeDisabled}
          onLike={onLike ? () => onLike?.(presentedEvent as RawEvent) : null}
          {zapPending}
          {zapDisabled}
          onZap={onZap ? () => onZap?.(presentedEvent as RawEvent) : null}
          onReply={onReply ? () => onReply?.(presentedEvent as RawEvent) : null}
          onRepost={onRepost ? () => onRepost?.(presentedEvent as RawEvent) : null}
          {repostPending}
          onShare={onShare ? () => onShare?.(presentedEvent as RawEvent) : null}
        />
      {/if}
      </div>
    {:else}
      <div
        data-testid="note-repost-target-unavailable"
        class={`min-h-16 rounded-xl border border-white/5 bg-white/[0.015] px-3 py-3 text-[0.88rem] text-white/45 ${compact ? 'ml-[2.35rem]' : 'ml-[2.7rem]'}`}
      >
        {resolvingRepostTarget ? 'Loading reposted post…' : 'Reposted post unavailable'}
      </div>
    {/if}
  </article>
</div>
