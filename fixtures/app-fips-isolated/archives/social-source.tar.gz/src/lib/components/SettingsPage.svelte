<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { onMount } from 'svelte';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { EditableProfileFields } from '../profileMetadata';
  import type { SettingsSection } from '../routes';
  import { settingsStore } from '../settings';
  import type { ThemePreference } from '../theme';
  import { getWorkerClient } from '../workerClient';
  import IrisIcon from './IrisIcon.svelte';
  import IrisUsernameSettings from './IrisUsernameSettings.svelte';
  import ProfileEditorSection from './ProfileEditorSection.svelte';
  import PeerNetworkSettings from './PeerNetworkSettings.svelte';
  import SettingsNavigation from './SettingsNavigation.svelte';
  import NotificationSettingsSection from './NotificationSettingsSection.svelte';
  import PrivateContactSyncStatus from './PrivateContactSyncStatus.svelte';
  import ContentSettingsSection from './ContentSettingsSection.svelte';
  import WalletSettingsSection from './wallet/WalletSettingsSection.svelte';

  export let section: SettingsSection = 'root';
  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let onToggleMute: (pubkey: string, muted: boolean) => void = () => undefined;
  export let viewerPubkey: string | null = null;
  export let viewerProfileEvent: RawEvent | null = null;
  export let viewerProfile: ProfileRecord | null = null;
  export let canPublishProfile = false;
  export let profileSavePending = false;
  export let profileEditorBlockedReason = '';
  export let profileSaveError = '';
  export let profileSaveMessage = '';
  export let onSaveProfile: (fields: EditableProfileFields) => void = () => undefined;
  export let onRegisterIrisUsername: (username: string, cfToken?: string) => Promise<{ signedUp: boolean }> = async () => ({ signedUp: false });
  export let onSetProfileNip05: (nip05: string) => void = () => undefined;
  export let isActive = true;

  let newRelayUrl = '';
  let newBlossomUrl = '';
  const themeOptions: Array<{ value: ThemePreference; label: string }> = [
    { value: 'system', label: 'System' },
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
  ];
  let storageStats = { items: 0, bytes: 0, maxBytes: $settingsStore.storage.maxBytes };
  let mounted = false;
  let storageStatsInterval: number | null = null;
  $: activeSection = section === 'root' ? 'profile' : section;

  function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
  }

  function addRelay(): void {
    const url = newRelayUrl.trim();
    if (!url) return;
    settingsStore.setNetworkSettings({ relays: [...$settingsStore.network.relays, url] });
    newRelayUrl = '';
  }

  function removeRelay(url: string): void {
    settingsStore.setNetworkSettings({
      relays: $settingsStore.network.relays.filter((relay) => relay !== url),
    });
  }

  function toggleRelayContentReads(): void {
    settingsStore.setNetworkSettings({
      relayContentReads: !$settingsStore.network.relayContentReads,
    });
  }

  function addBlossomServer(): void {
    const url = newBlossomUrl.trim();
    if (!url) return;
    settingsStore.setNetworkSettings({
      blossomServers: [...$settingsStore.network.blossomServers, { url, read: true, write: false }],
    });
    newBlossomUrl = '';
  }

  function removeBlossomServer(url: string): void {
    settingsStore.setNetworkSettings({
      blossomServers: $settingsStore.network.blossomServers.filter((server) => server.url !== url),
    });
  }

  function toggleBlossomRead(url: string): void {
    settingsStore.setNetworkSettings({
      blossomServers: $settingsStore.network.blossomServers.map((server) =>
        server.url === url ? { ...server, read: server.read === false } : server),
    });
  }

  function toggleBlossomWrite(url: string): void {
    settingsStore.setNetworkSettings({
      blossomServers: $settingsStore.network.blossomServers.map((server) =>
        server.url === url ? { ...server, write: server.write !== true } : server),
    });
  }

  function updateStorageLimit(megabytes: string): void {
    const parsed = Number(megabytes);
    if (!Number.isFinite(parsed) || parsed <= 0) return;
    settingsStore.setStorageSettings({ maxBytes: Math.round(parsed * 1024 * 1024) });
  }

  async function refreshRuntimeStats(): Promise<void> {
    try {
      storageStats = await (await getWorkerClient()).getStorageStats();
    } catch {
      storageStats = { items: 0, bytes: 0, maxBytes: $settingsStore.storage.maxBytes };
    }
  }

  function syncStorageStatsPolling(active: boolean): void {
    if (active === (storageStatsInterval !== null)) {
      return;
    }
    if (storageStatsInterval !== null) {
      window.clearInterval(storageStatsInterval);
      storageStatsInterval = null;
    }
    if (active) {
      void refreshRuntimeStats();
      storageStatsInterval = window.setInterval(() => void refreshRuntimeStats(), 2_000);
    }
  }

  $: if (mounted) {
    syncStorageStatsPolling(isActive && activeSection === 'storage' && document.visibilityState !== 'hidden');
  }

  onMount(() => {
    mounted = true;
    syncStorageStatsPolling(isActive && activeSection === 'storage' && document.visibilityState !== 'hidden');
    const handleVisibilityChange = () => {
      syncStorageStatsPolling(isActive && activeSection === 'storage' && document.visibilityState !== 'hidden');
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      syncStorageStatsPolling(false);
    };
  });
</script>

<div
  data-testid="settings-page"
  data-storage-polling={storageStatsInterval !== null}
  class="flex min-h-[calc(100dvh-8rem)] w-full bg-[var(--iris-surface-subtle)] md:min-h-[calc(100dvh-4rem)]"
  style="--iris-settings-surface:var(--iris-surface);--iris-settings-muted:rgb(var(--iris-text-rgb)/0.7);--iris-settings-row-hover:var(--iris-surface-hover);--iris-settings-row-active:var(--iris-surface-raised);--iris-settings-divider:rgb(var(--iris-text-rgb)/0.15);--iris-settings-focus:rgb(139 92 246);"
>
  <SettingsNavigation {section} />

  <div class={`min-w-0 flex-1 bg-[var(--iris-surface-subtle)] ${section === 'root' ? 'hidden lg:block' : 'block'}`}>
    {#if activeSection === 'profile'}
      <div class="mb-5 grid gap-2 px-1">
        <h2 class="text-sm font-600">Private contacts</h2>
        <p class="text-xs text-white/45">Favorites, nicknames, and notes sync securely between your devices.</p>
        <PrivateContactSyncStatus />
      </div>
      <div class="p-4 sm:p-5">
        <ProfileEditorSection
          {viewerPubkey}
          profileEvent={viewerProfileEvent}
          profile={viewerProfile}
          canPublish={canPublishProfile}
          savePending={profileSavePending}
          blockedReason={profileEditorBlockedReason}
          error={profileSaveError}
          message={profileSaveMessage}
          onSave={onSaveProfile}
        />
      </div>
    {:else if activeSection === 'iris'}
      <IrisUsernameSettings
        {isActive}
        {viewerPubkey}
        profileNip05={viewerProfile?.nip05 ?? ''}
        canPublish={canPublishProfile}
        {profileSavePending}
        onRegister={onRegisterIrisUsername}
        {onSetProfileNip05}
      />
    {:else if activeSection === 'notifications'}
      <NotificationSettingsSection />
    {:else if activeSection === 'content'}
      <ContentSettingsSection {mutedPubkeys} {mutePendingPubkeys} {onToggleMute} canPublish={canPublishProfile} />
    {:else if activeSection === 'appearance'}
      <div data-testid="settings-appearance-section" class="grid gap-6 p-4 sm:p-5">
        <SettingsGroup title="Theme" ariaLabel="Theme">
          <SettingsGroupItem isLast={true}>
            <label class="flex items-center justify-between gap-4" for="settings-theme-select">
              <span>Color scheme</span>
              <select
                id="settings-theme-select"
                data-testid="settings-theme-select"
                value={$settingsStore.appearance.theme}
                class="rounded-lg border border-[rgb(var(--iris-text-rgb)/0.2)] bg-[var(--iris-surface-subtle)] px-3 py-1.5 text-sm text-[rgb(var(--iris-text-rgb))] outline-none focus:border-violet-400"
                on:change={(event) => settingsStore.setAppearanceSettings({ theme: (event.currentTarget as HTMLSelectElement).value as ThemePreference })}
              >
                {#each themeOptions as option (option.value)}
                  <option value={option.value}>{option.label}</option>
                {/each}
              </select>
            </label>
          </SettingsGroupItem>
        </SettingsGroup>
      </div>
    {:else if activeSection === 'wallet'}
      <WalletSettingsSection active={isActive} />
    {:else if activeSection === 'network'}
      <div data-testid="settings-network-section" class="grid gap-6 p-4 sm:p-5">
        <PeerNetworkSettings active={isActive} />
        <SettingsGroup title="Profiles">
          <SettingsGroupItem isLast={true}>
            <label class="flex cursor-pointer items-start justify-between gap-4">
              <span><span class="block text-[0.9rem]">Keep profiles up to date</span><span class="mt-1 block text-[0.78rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.6)]">Check these relays for newer names and pictures. Save updates for offline use.</span></span>
              <input data-testid="settings-profile-refresh-toggle" type="checkbox" checked={$settingsStore.network.refreshProfiles} class="mt-0.5 h-4 w-4 accent-violet-500" on:change={() => settingsStore.setNetworkSettings({ refreshProfiles: !$settingsStore.network.refreshProfiles })} />
            </label>
          </SettingsGroupItem>
        </SettingsGroup>
        <SettingsGroup title="Relays">
          {#each $settingsStore.network.relays as relay (relay)}
            <SettingsGroupItem>
              <div class="flex items-center gap-3">
                <span class="min-w-0 flex-1 truncate text-[0.9rem]">{relay}</span>
                <button type="button" class="grid h-8 w-8 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.55)] hover:bg-[var(--iris-surface-hover)]" aria-label="Remove relay" on:click={() => removeRelay(relay)}><IrisIcon name="x-close" size={16} /></button>
              </div>
            </SettingsGroupItem>
          {/each}
          <SettingsGroupItem>
            <label data-testid="settings-relay-content-reads" class="flex cursor-pointer items-start justify-between gap-4">
              <span><span class="block text-[0.9rem]">Read posts directly from relays</span><span class="mt-1 block text-[0.78rem] leading-5 text-[rgb(var(--iris-text-rgb)/0.6)]">Optional. Hashtree indexes remain the primary source.</span></span>
              <input data-testid="settings-relay-content-reads-toggle" type="checkbox" checked={$settingsStore.network.relayContentReads} class="mt-0.5 h-4 w-4 accent-violet-500" on:change={toggleRelayContentReads} />
            </label>
          </SettingsGroupItem>
          <SettingsGroupItem isLast={true}>
            <div class="flex gap-2">
              <input data-testid="settings-relay-input" bind:value={newRelayUrl} class="min-w-0 flex-1 rounded-lg bg-transparent px-0 py-2 text-[0.9rem] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.4)]" placeholder="wss://relay.example" on:keydown={(event) => event.key === 'Enter' && addRelay()} />
              <button data-testid="settings-relay-add" type="button" class="rounded-lg bg-[var(--iris-solid)] px-4 py-2 text-[0.88rem] font-700 text-[var(--iris-on-solid)]" on:click={addRelay}>Add</button>
              <button type="button" class="rounded-lg bg-[var(--iris-surface-subtle)] px-4 py-2 text-[0.88rem] font-600 hover:bg-[var(--iris-surface-hover)]" on:click={() => settingsStore.resetNetworkSettings()}>Reset</button>
            </div>
          </SettingsGroupItem>
        </SettingsGroup>
      </div>
    {:else if activeSection === 'media'}
      <div data-testid="settings-blossom-section" class="grid gap-6 p-4 sm:p-5">
        <SettingsGroup title="Blossom servers">
          {#each $settingsStore.network.blossomServers as server (server.url)}
            <SettingsGroupItem testId="settings-blossom-row">
              <div>
                <div class="flex items-center gap-3"><span class="min-w-0 flex-1 truncate text-[0.9rem]">{server.url}</span><button type="button" class="grid h-8 w-8 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.55)] hover:bg-[var(--iris-surface-hover)]" aria-label="Remove blossom server" on:click={() => removeBlossomServer(server.url)}><IrisIcon name="x-close" size={16} /></button></div>
                <div class="mt-2 flex gap-5 text-[0.82rem] text-[rgb(var(--iris-text-rgb)/0.65)]">
                  <label class="flex items-center gap-2"><input data-testid="settings-blossom-read" type="checkbox" checked={server.read !== false} class="h-4 w-4 accent-violet-500" on:change={() => toggleBlossomRead(server.url)} />Read</label>
                  <label class="flex items-center gap-2"><input data-testid="settings-blossom-write" type="checkbox" checked={server.write === true} class="h-4 w-4 accent-violet-500" on:change={() => toggleBlossomWrite(server.url)} />Write</label>
                </div>
              </div>
            </SettingsGroupItem>
          {/each}
          <SettingsGroupItem isLast={true}>
            <div class="flex gap-2">
              <input data-testid="settings-blossom-input" bind:value={newBlossomUrl} class="min-w-0 flex-1 bg-transparent px-0 py-2 text-[0.9rem] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.4)]" placeholder="https://cdn.example" on:keydown={(event) => event.key === 'Enter' && addBlossomServer()} />
              <button data-testid="settings-blossom-add" type="button" class="rounded-lg bg-[var(--iris-solid)] px-4 py-2 text-[0.88rem] font-700 text-[var(--iris-on-solid)]" on:click={addBlossomServer}>Add</button>
            </div>
          </SettingsGroupItem>
        </SettingsGroup>
      </div>
    {:else if activeSection === 'storage'}
      <div class="grid gap-6 p-4 sm:p-5">
        <SettingsGroup title="Local storage">
          <SettingsGroupItem isLast={true}>
            <div class="flex items-center justify-between gap-4"><span>{formatBytes(storageStats.bytes)} / {formatBytes($settingsStore.storage.maxBytes)}</span><span class="text-[0.8rem] text-[rgb(var(--iris-text-rgb)/0.6)]">{storageStats.items} blobs</span></div>
            <label class="mt-4 flex items-center gap-3"><span class="text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.55)]">Limit</span><input data-testid="settings-storage-limit" type="number" min="128" step="128" value={Math.round($settingsStore.storage.maxBytes / 1024 / 1024)} class="min-w-0 flex-1 rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.9rem] outline-none" on:change={(event) => updateStorageLimit((event.currentTarget as HTMLInputElement).value)} /><span class="text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.45)]">MB</span></label>
          </SettingsGroupItem>
        </SettingsGroup>
      </div>
    {/if}
  </div>
</div>
