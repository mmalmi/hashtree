<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { NoteEmbed } from '../noteContent';
  import NoteEmbedItem from './NoteEmbedItem.svelte';
  import IrisIcon from './IrisIcon.svelte';

  export let items: NoteEmbed[] = [];
  export let index = 0;
  export let variant: 'inline' | 'modal' = 'inline';
  export let viewActive = true;
  export let activeMediaUrl: string | null = null;
  export let onIndexChange: (index: number) => void = () => undefined;
  export let onGesture: () => void = () => undefined;
  export let onOpenMedia: ((embed: NoteEmbed, index: number) => void) | null = null;
  export let onBackgroundClick: (() => void) | null = null;

  type Slide = {
    embed: NoteEmbed;
    index: number;
    position: -1 | 0 | 1;
  };

  const SWIPE_MIN_DISTANCE_PX = 56;
  const SWIPE_QUICK_DISTANCE_PX = 28;
  const SWIPE_QUICK_DURATION_MS = 260;
  const DIRECTION_LOCK_DISTANCE_PX = 8;
  const SETTLE_DURATION_MS = 180;
  const INLINE_CLICK_SUPPRESSION_MS = 800;

  let currentIndex = 0;
  let observedPropIndex: number | null = null;
  let observedItemsKey = '';
  let pointerId: number | null = null;
  let pointerStartX = 0;
  let pointerStartY = 0;
  let pointerStartedAt = 0;
  let pointerDirection: 'pending' | 'horizontal' | 'vertical' = 'pending';
  let dragX = 0;
  let viewportWidth = 1;
  let settling = false;
  let settleTimer: ReturnType<typeof setTimeout> | null = null;
  let suppressClickUntil = 0;
  let slides: Slide[] = [];

  function wrapIndex(value: number): number {
    if (items.length === 0) {
      return 0;
    }
    return ((value % items.length) + items.length) % items.length;
  }

  function syncIndexFromProps(nextIndex: number, itemsKey: string, isSettling: boolean): void {
    const itemsChanged = itemsKey !== observedItemsKey;
    if (isSettling || (!itemsChanged && nextIndex === observedPropIndex)) {
      return;
    }
    currentIndex = items.length === 0 ? 0 : wrapIndex(nextIndex);
    observedPropIndex = nextIndex;
    observedItemsKey = itemsKey;
  }

  function buildSlides(): Slide[] {
    const current = items[currentIndex];
    if (!current) {
      return [];
    }
    if (items.length === 1) {
      return [{ embed: current, index: currentIndex, position: 0 }];
    }
    const previousIndex = wrapIndex(currentIndex - 1);
    const nextIndex = wrapIndex(currentIndex + 1);
    // Keep the active item first in DOM order so focus, screen readers, and
    // stable selectors never land on a visually hidden preload slide.
    return [
      { embed: current, index: currentIndex, position: 0 },
      { embed: items[previousIndex]!, index: previousIndex, position: -1 },
      { embed: items[nextIndex]!, index: nextIndex, position: 1 },
    ];
  }

  function resetPointer(): void {
    pointerId = null;
    pointerDirection = 'pending';
    pointerStartX = 0;
    pointerStartY = 0;
    pointerStartedAt = 0;
  }

  function finishNavigation(delta: number): void {
    if (settleTimer) {
      clearTimeout(settleTimer);
    }
    settleTimer = setTimeout(() => {
      settling = false;
      dragX = 0;
      currentIndex = wrapIndex(currentIndex + delta);
      onIndexChange(currentIndex);
      settleTimer = null;
    }, SETTLE_DURATION_MS);
  }

  function announceCarouselGesture(): void {
    suppressClickUntil = Date.now() + (variant === 'inline'
      ? INLINE_CLICK_SUPPRESSION_MS
      : 300);
    onGesture();
  }

  function navigate(delta: number, fromGesture = false): void {
    if (items.length <= 1 || settling) {
      return;
    }
    viewportWidth = Math.max(viewportWidth, 1);
    settling = true;
    dragX = delta > 0 ? -viewportWidth : viewportWidth;
    if (!fromGesture) {
      suppressClickUntil = Date.now() + SETTLE_DURATION_MS + 80;
    }
    finishNavigation(delta);
  }

  function isCarouselControl(target: EventTarget | null): boolean {
    return target instanceof Element && Boolean(
      target.closest('[data-carousel-control], video, audio, iframe, input, textarea, select'),
    );
  }

  function handlePointerDown(event: PointerEvent): void {
    if (
      items.length <= 1
      || settling
      || !event.isPrimary
      || event.button !== 0
      || isCarouselControl(event.target)
    ) {
      return;
    }

    const target = event.currentTarget as HTMLElement;
    viewportWidth = Math.max(1, target.getBoundingClientRect().width);
    pointerId = event.pointerId;
    pointerStartX = event.clientX;
    pointerStartY = event.clientY;
    pointerStartedAt = Date.now();
    pointerDirection = 'pending';
    dragX = 0;
    if (event.pointerType === 'mouse') {
      event.preventDefault();
    }
  }

  function handlePointerMove(event: PointerEvent): void {
    if (pointerId !== event.pointerId) {
      return;
    }
    const deltaX = event.clientX - pointerStartX;
    const deltaY = event.clientY - pointerStartY;
    if (pointerDirection === 'pending' && Math.hypot(deltaX, deltaY) >= DIRECTION_LOCK_DISTANCE_PX) {
      pointerDirection = Math.abs(deltaX) > Math.abs(deltaY) ? 'horizontal' : 'vertical';
    }
    if (pointerDirection === 'vertical') {
      dragX = 0;
      resetPointer();
      return;
    }
    if (pointerDirection === 'horizontal') {
      try {
        (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
      } catch {
        // Synthetic test events and inactive pointers may reject capture.
      }
      event.preventDefault();
      dragX = deltaX;
      if (Math.abs(deltaX) >= DIRECTION_LOCK_DISTANCE_PX) {
        suppressClickUntil = Date.now() + (variant === 'inline'
          ? INLINE_CLICK_SUPPRESSION_MS
          : 300);
      }
    }
  }

  function handlePointerUp(event: PointerEvent): void {
    if (pointerId !== event.pointerId) {
      return;
    }
    const deltaX = event.clientX - pointerStartX;
    const deltaY = event.clientY - pointerStartY;
    const elapsed = Date.now() - pointerStartedAt;
    const isHorizontal = pointerDirection === 'horizontal'
      || (pointerDirection === 'pending' && Math.abs(deltaX) > Math.abs(deltaY));
    const shouldNavigate = isHorizontal
      && (Math.abs(deltaX) >= SWIPE_MIN_DISTANCE_PX
        || (elapsed <= SWIPE_QUICK_DURATION_MS && Math.abs(deltaX) >= SWIPE_QUICK_DISTANCE_PX));
    if (isHorizontal && Math.abs(deltaX) >= DIRECTION_LOCK_DISTANCE_PX) {
      announceCarouselGesture();
    }
    try {
      (event.currentTarget as HTMLElement).releasePointerCapture(event.pointerId);
    } catch {
      // The pointer may already have been released by the browser.
    }
    resetPointer();

    if (!shouldNavigate) {
      if (Math.abs(dragX) < 1) {
        dragX = 0;
        return;
      }
      settling = true;
      dragX = 0;
      settleTimer = setTimeout(() => {
        settling = false;
        settleTimer = null;
      }, SETTLE_DURATION_MS);
      return;
    }

    event.preventDefault();
    navigate(deltaX < 0 ? 1 : -1, true);
  }

  function handlePointerCancel(): void {
    resetPointer();
    dragX = 0;
    settling = false;
  }

  function handleOpen(embed: NoteEmbed, slideIndex: number): void {
    onOpenMedia?.(embed, slideIndex);
  }

  function handleBackgroundClick(event: MouseEvent): void {
    if (
      onBackgroundClick
      && event.target === event.currentTarget
      && Date.now() >= suppressClickUntil
      && !settling
    ) {
      onBackgroundClick();
    }
  }

  function handleSlideClick(event: MouseEvent, slide: Slide): void {
    if (Date.now() < suppressClickUntil || settling) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    if (event.target === event.currentTarget) {
      handleBackgroundClick(event);
      return;
    }
    if (onOpenMedia && !isCarouselControl(event.target)) {
      event.preventDefault();
      event.stopPropagation();
      handleOpen(slide.embed, slide.index);
    }
  }

  function handleCarouselClickCapture(event: MouseEvent): void {
    if (Date.now() < suppressClickUntil || settling) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  function pauseInteraction(): void {
    resetPointer();
    dragX = 0;
    settling = false;
    if (settleTimer) {
      clearTimeout(settleTimer);
      settleTimer = null;
    }
  }

  $: itemsKey = items.map((item) => `${item.kind}:${item.url}`).join('\n');
  $: syncIndexFromProps(index, itemsKey, settling);
  $: {
    items;
    currentIndex;
    slides = buildSlides();
  }
  $: if (!viewActive) {
    pauseInteraction();
  }
  $: frameClass = variant === 'modal'
    ? 'h-full min-h-0 w-full'
    : 'h-[20rem] w-full sm:h-[24rem] lg:h-[28rem]';

  onDestroy(() => {
    if (settleTimer) {
      clearTimeout(settleTimer);
    }
  });
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
<div
  data-testid="media-carousel"
  data-note-no-thread-nav
  role="region"
  aria-label="Media carousel"
  class={`pointer-events-auto relative touch-pan-y select-none overflow-hidden ${pointerId === null ? 'cursor-grab' : 'cursor-grabbing'} ${frameClass}`.trim()}
  on:pointerdown={handlePointerDown}
  on:pointermove={handlePointerMove}
  on:pointerup={handlePointerUp}
  on:pointercancel={handlePointerCancel}
  on:click|capture={handleCarouselClickCapture}
  on:dragstart|preventDefault
>
  {#each slides as slide (`${slide.position}:${slide.embed.url}`)}
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div
      data-testid={slide.position === 0 ? 'media-carousel-backdrop' : undefined}
      aria-hidden={slide.position === 0 ? undefined : 'true'}
      inert={slide.position === 0 ? undefined : true}
      class={`absolute inset-0 flex items-center justify-center ${slide.position === 0 ? '' : 'pointer-events-none'} ${settling ? 'transition-transform duration-200 ease-out' : ''}`.trim()}
      style={`transform: translate3d(calc(${slide.position * 100}% + ${dragX}px), 0, 0);`}
      on:click|capture={slide.position === 0 ? (event) => handleSlideClick(event, slide) : undefined}
    >
      <NoteEmbedItem
        embed={slide.embed}
        {viewActive}
        active={activeMediaUrl === slide.embed.url}
        {variant}
        preload={slide.position !== 0}
        autoplay={variant === 'modal' && slide.position === 0 && slide.embed.kind === 'video'}
        onOpenMedia={slide.position === 0 && onOpenMedia
          ? () => handleOpen(slide.embed, slide.index)
          : null}
      />
    </div>
  {/each}

  {#if items.length > 1}
    <button
      data-carousel-control
      type="button"
      aria-label="Previous media item"
      class={`absolute left-3 top-1/2 z-20 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-black/55 text-white shadow-lg transition hover:bg-black/70 ${variant === 'inline' ? 'opacity-85' : ''}`.trim()}
      on:click={() => navigate(-1)}
    >
      <IrisIcon name="arrowFront" size={17} className="-scale-x-100" />
    </button>
    <button
      data-carousel-control
      type="button"
      aria-label="Next media item"
      class={`absolute right-3 top-1/2 z-20 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-black/55 text-white shadow-lg transition hover:bg-black/70 ${variant === 'inline' ? 'opacity-85' : ''}`.trim()}
      on:click={() => navigate(1)}
    >
      <IrisIcon name="arrowFront" size={17} />
    </button>

    <div class="pointer-events-none absolute bottom-3 left-3 z-20 rounded-full bg-black/55 px-2.5 py-1 text-[0.76rem] font-700 text-white">
      {currentIndex + 1} / {items.length}
    </div>
  {/if}
</div>
