<script lang="ts">
  import IrisIcon from './IrisIcon.svelte';

  export let getShareUrl: () => string;
  export let onCopy: () => void;

  let trigger: HTMLButtonElement;
  let panel: HTMLDivElement;
  let open = false;
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
    && (!navigator.canShare || navigator.canShare({ url: 'https://social.iris.to' }));
  const id = canShare ? `note-share-${crypto.randomUUID()}` : undefined;

  function onToggle(): void {
    open = panel.matches(':popover-open');
    if (!open) return;
    const rect = trigger.getBoundingClientRect();
    const x = Math.min(rect.left, window.innerWidth - panel.offsetWidth - 8);
    const below = rect.bottom + 6;
    panel.style.left = `${Math.max(8, x)}px`;
    panel.style.top = `${below + panel.offsetHeight < window.innerHeight ? below : Math.max(8, rect.top - panel.offsetHeight - 6)}px`;
    panel.querySelector('button')?.focus({ preventScroll: true });
  }

  function close(): void {
    panel.hidePopover();
    trigger.focus({ preventScroll: true });
  }

  function onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Escape') close();
  }

  async function share(): Promise<void> {
    close();
    try {
      await navigator.share({ url: getShareUrl() });
    } catch (error) {
      if (!(error instanceof DOMException && error.name === 'AbortError')) onCopy();
    }
  }
</script>

<button
  bind:this={trigger}
  data-testid="note-share-button"
  type="button"
  class="inline-flex cursor-pointer items-center border-0 bg-transparent p-0 text-inherit hover:text-sky-400"
  title="Share"
  aria-label="Share"
  aria-expanded={canShare ? open : undefined}
  popovertarget={canShare ? id : undefined}
  on:click={() => { if (!canShare) onCopy(); }}
>
  <IrisIcon name="share" size={16} />
</button>
{#if canShare}
  <div
    {id}
    bind:this={panel}
    popover="auto"
    role="group"
    aria-label="Share"
    class="share-choices"
    on:toggle={onToggle}
  >
    <button type="button" on:keydown={onKeyDown} on:click={() => { close(); onCopy(); }}>Copy link</button>
    <button type="button" on:keydown={onKeyDown} on:click={share}>Share via…</button>
  </div>
{/if}

<style>
  .share-choices {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: 9rem;
    padding: .25rem;
    border: 0;
    border-radius: .65rem;
    background: var(--iris-surface-raised);
    color: rgb(var(--iris-text-rgb));
    box-shadow: 0 .4rem 1.25rem #0003;
  }
  .share-choices button {
    display: block;
    width: 100%;
    padding: .6rem .75rem;
    border: 0;
    border-radius: .4rem;
    background: transparent;
    color: inherit;
    text-align: left;
    cursor: pointer;
  }
  .share-choices button:is(:hover, :focus-visible) { background: rgb(var(--iris-text-rgb) / .08); }
</style>
