<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { nip19 } from 'nostr-tools';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import {
    parseEditableProfileMetadata,
    type EditableProfileFields,
  } from '../profileMetadata';

  export let viewerPubkey: string | null = null;
  export let profileEvent: RawEvent | null = null;
  export let profile: ProfileRecord | null = null;
  export let canPublish = false;
  export let savePending = false;
  export let blockedReason = '';
  export let error = '';
  export let message = '';
  export let onSave: (fields: EditableProfileFields) => void = () => undefined;

  const emptyFields = (): EditableProfileFields => ({
    displayName: '',
    about: '',
    website: '',
    picture: '',
    banner: '',
    lud16: '',
    nip05: '',
  });

  let fields = emptyFields();
  let initialFields = emptyFields();
  let loadedBaseKey = '';

  $: baseKey = profileEvent?.id ?? `none:${profile?.eventId ?? profile?.pubkey ?? ''}`;
  $: if (baseKey !== loadedBaseKey && !savePending) {
    const parsed = profileEvent ? parseEditableProfileMetadata(profileEvent.content) : null;
    fields = parsed
      ? { ...parsed.fields }
      : {
          ...emptyFields(),
          displayName: profile?.displayName?.trim() || profile?.name?.trim() || '',
          about: profile?.about ?? '',
          website: profile?.website ?? '',
          picture: profile?.picture ?? '',
          banner: profile?.banner ?? '',
          lud16: profile?.lud16 ?? '',
          nip05: profile?.nip05 ?? '',
        };
    initialFields = { ...fields };
    loadedBaseKey = baseKey;
  }
  $: dirty = JSON.stringify(fields) !== JSON.stringify(initialFields);
  $: saveDisabled = !canPublish || savePending || Boolean(blockedReason) || !dirty;
  $: npubCashAddress = viewerPubkey ? `${nip19.npubEncode(viewerPubkey)}@npub.cash` : '';

  function submit(): void {
    if (saveDisabled) {
      return;
    }
    onSave({ ...fields });
  }
</script>

<SettingsGroup title="Public profile" testId="settings-profile-section">
  <SettingsGroupItem isLast={true}>
    <div class="flex items-start justify-between gap-4">
      <div class="text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.6)]">
        Stored as signed Nostr metadata and queued locally before delivery.
      </div>
      <button
        data-testid="profile-editor-save"
        type="submit"
        form="profile-metadata-form"
        class="shrink-0 rounded-full bg-[var(--iris-solid)] px-4 py-2 text-[0.86rem] font-700 text-[var(--iris-on-solid)] transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-35"
        disabled={saveDisabled}
      >
        {savePending ? 'Saving…' : 'Save profile'}
      </button>
    </div>

    <form id="profile-metadata-form" class="mt-4 grid gap-3" on:submit|preventDefault={submit}>
    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Name</span>
      <input
        data-testid="profile-editor-name"
        bind:value={fields.displayName}
        autocomplete="name"
      class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="Your name"
      />
    </label>

    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">About</span>
      <textarea
        data-testid="profile-editor-about"
        bind:value={fields.about}
        rows="4"
        class="resize-y rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] leading-6 text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="A little about you"
      ></textarea>
    </label>

    <div class="grid gap-3 sm:grid-cols-2">
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Website URL</span>
        <input
          data-testid="profile-editor-website"
          bind:value={fields.website}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com"
        />
      </label>
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">NIP-05 address</span>
        <input
          data-testid="profile-editor-nip05"
          bind:value={fields.nip05}
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="you@example.com"
        />
      </label>
    </div>

    <div class="grid gap-3 sm:grid-cols-2">
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Picture URL</span>
        <input
          data-testid="profile-editor-picture"
          bind:value={fields.picture}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com/avatar.jpg"
        />
      </label>
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Banner URL</span>
        <input
          data-testid="profile-editor-banner"
          bind:value={fields.banner}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com/banner.jpg"
        />
      </label>
    </div>

    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Lightning address</span>
      <input
        data-testid="profile-editor-lud16"
        bind:value={fields.lud16}
        class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="you@example.com"
      />
    </label>
    {#if !fields.lud16.trim() && npubCashAddress}
      <button
        type="button"
        class="justify-self-start break-all text-left text-[0.84rem] text-violet-500 hover:underline disabled:cursor-not-allowed disabled:opacity-35"
        disabled={!canPublish || savePending || Boolean(blockedReason)}
        on:click={() => fields.lud16 = npubCashAddress}
      >
        Use {npubCashAddress}
      </button>
    {/if}
    </form>

    {#if blockedReason}
      <div data-testid="profile-editor-blocked" class="mt-3 rounded-[16px] border border-amber-400/15 bg-amber-400/[0.06] px-3 py-2.5 text-[0.84rem] leading-5 text-amber-500">
        {blockedReason}
      </div>
    {:else if !canPublish}
      <div data-testid="profile-editor-read-only" class="mt-3 text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.5)]">
        This account is read-only. Import its secret key to edit the profile.
      </div>
    {/if}

    {#if error}
      <div data-testid="profile-editor-error" class="mt-3 text-[0.84rem] leading-5 text-rose-500">{error}</div>
    {:else if message}
      <div data-testid="profile-editor-success" class="mt-3 text-[0.84rem] leading-5 text-emerald-500">{message}</div>
    {/if}
  </SettingsGroupItem>
</SettingsGroup>
