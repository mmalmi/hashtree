<script lang="ts">
  import SettingsGroup from '@iris/svelte-ui/SettingsGroup.svelte';
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { diffRawProfileFields, readRawProfileFields, formatRawProfileFields } from '@iris/profile-events';
  import { nip19 } from 'nostr-tools';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import {
    customProfileFields, parseEditableProfileMetadata, type ProfileEdits,
    type EditableProfileFields,
  } from '../profileMetadata';

  export let viewerPubkey: string | null = null;
  export let profileEvent: RawEvent | null = null;
  export let profile: ProfileRecord | null = null;
  export let canPublish = false;
  export let savePending = false;
  export let blockedReason = '';
  export let error = '';
  export let message = '';
  export let onSave: (fields: ProfileEdits) => void = () => undefined;

  const emptyFields = (): EditableProfileFields => ({
    displayName: '',
    about: '',
    website: '',
    picture: '',
    banner: '',
    lud16: '',
    nip05: '',
  });

  let fields = emptyFields();
  let initialFields = emptyFields();
  let loadedBaseKey = '';

  let originalContent = '{}';
  let initialCustom = '{}';
  let originalCustom: Record<string,string> = {};
  let custom = '{}';
  let submitted = false;
  let dirty = false;
  $: baseKey = profileEvent?.id ?? `none:${profile?.eventId ?? profile?.pubkey ?? ''}`;
  function loadProfile() {
    originalContent = profileEvent?.content ?? '{}';
    const parsed = parseEditableProfileMetadata(originalContent);
    fields = parsed?.fields ?? emptyFields();
    initialFields = { ...fields };
    originalCustom = parsed ? customProfileFields(readRawProfileFields(originalContent)) : {};
    initialCustom = formatRawProfileFields(originalCustom);
    custom = initialCustom;
    loadedBaseKey = baseKey;
    submitted = false;
  }
  $: if (baseKey !== loadedBaseKey && !savePending && (!dirty || (submitted && message))) loadProfile();
  function customEdits(text: string, base: Record<string, string>) {
    try {
      const object = readRawProfileFields(text);
      const customOnly = customProfileFields(object);
      if (Object.keys(customOnly).length !== Object.keys(object).length) throw Error();
      return diffRawProfileFields(base, customOnly);
    } catch { return null; }
  }
  $: extraEdits = customEdits(custom, originalCustom);
  $: dirty = JSON.stringify(fields) !== JSON.stringify(initialFields) || custom !== initialCustom;
  $: changedFields = Object.keys(fields).filter(key => fields[key as keyof EditableProfileFields] !== initialFields[key as keyof EditableProfileFields]);
  $: changes = [...changedFields, ...Object.keys(extraEdits ?? {})];
  $: saveDisabled = !canPublish || savePending || Boolean(blockedReason) || !changes.length || !extraEdits;
  $: npubCashAddress = viewerPubkey ? `${nip19.npubEncode(viewerPubkey)}@npub.cash` : '';

  function submit(): void {
    if (saveDisabled) {
      return;
    }
    submitted = true;
    const edits = Object.fromEntries(changedFields.map(key => [key, fields[key as keyof EditableProfileFields]]));
    onSave({ ...edits, originalContent, rawCustom: extraEdits ?? {} });
  }
</script>

<SettingsGroup title="Public profile" testId="settings-profile-section">
  <SettingsGroupItem isLast={true}>
    <div class="flex items-start justify-between gap-4">
      <div class="text-[0.9rem] leading-6 text-[rgb(var(--iris-text-rgb)/0.6)]">
        Stored as signed Nostr metadata and queued locally before delivery.
      </div>
      <button
        data-testid="profile-editor-save"
        type="submit"
        form="profile-metadata-form"
        class="shrink-0 rounded-full bg-[var(--iris-solid)] px-4 py-2 text-[0.86rem] font-700 text-[var(--iris-on-solid)] transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-35"
        disabled={saveDisabled}
      >
        {savePending ? 'Saving…' : 'Save profile'}
      </button>
    </div>

    <form id="profile-metadata-form" class="mt-4 grid gap-3" on:submit|preventDefault={submit}>
    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Name</span>
      <input
        data-testid="profile-editor-name"
        bind:value={fields.displayName}
        autocomplete="name"
      class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="Your name"
      />
    </label>

    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">About</span>
      <textarea
        data-testid="profile-editor-about"
        bind:value={fields.about}
        rows="4"
        class="resize-y rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] leading-6 text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="A little about you"
      ></textarea>
    </label>

    <div class="grid gap-3 sm:grid-cols-2">
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Website URL</span>
        <input
          data-testid="profile-editor-website"
          bind:value={fields.website}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com"
        />
      </label>
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">NIP-05 address</span>
        <input
          data-testid="profile-editor-nip05"
          bind:value={fields.nip05}
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="you@example.com"
        />
      </label>
    </div>

    <div class="grid gap-3 sm:grid-cols-2">
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Picture URL</span>
        <input
          data-testid="profile-editor-picture"
          bind:value={fields.picture}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com/avatar.jpg"
        />
      </label>
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Banner URL</span>
        <input
          data-testid="profile-editor-banner"
          bind:value={fields.banner}
          type="url"
          class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
          placeholder="https://example.com/banner.jpg"
        />
      </label>
    </div>

    <label class="grid gap-1.5">
      <span class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.6)]">Lightning address</span>
      <input
        data-testid="profile-editor-lud16"
        bind:value={fields.lud16}
        class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-[0.92rem] text-[rgb(var(--iris-text-rgb))] outline-none focus:ring-1 focus:ring-violet-400/45"
        placeholder="you@example.com"
      />
    </label>
    {#if !fields.lud16.trim() && npubCashAddress}
      <button
        type="button"
        class="justify-self-start break-all text-left text-[0.84rem] text-violet-500 hover:underline disabled:cursor-not-allowed disabled:opacity-35"
        disabled={!canPublish || savePending || Boolean(blockedReason)}
        on:click={() => fields.lud16 = npubCashAddress}
      >
        Use {npubCashAddress}
      </button>
    {/if}
    <details class="mt-2 rounded-lg bg-[var(--iris-surface-subtle)] p-3">
      <summary class="cursor-pointer">Custom fields and tags</summary>
      <label class="mt-3 grid gap-1 text-sm">
        Custom fields (JSON)
        <textarea class="w-full rounded-md p-2 font-mono text-sm" bind:value={custom} rows="5" spellcheck="false"></textarea>
      </label>
      {#if !extraEdits}<p class="mt-2 text-sm" role="alert">Enter a JSON object using keys outside the main form.</p>{/if}
      {#if extraEdits && Object.keys(extraEdits).length}
        <dl class="mt-2 grid gap-2 text-sm" aria-label="Custom field changes">
          {#each Object.entries(extraEdits) as [key, next]}
            <div><dt class="font-medium">{key}</dt>
              <dd class="break-all">Before · {originalCustom[key] ?? 'Absent'}</dd>
              <dd class="break-all">After · {next ?? 'Absent'}</dd></div>
          {/each}
        </dl>
      {/if}
      {#if profileEvent?.tags.length}
        <p class="mt-3 text-sm">Event tags</p>
        {#each profileEvent.tags as tag}<code class="block break-all text-xs">{JSON.stringify(tag)}</code>{/each}
      {/if}
    </details>
    {#if changes.length}<p class="break-words text-sm" role="status">Changes: {changes.join(', ')}</p>{/if}
    {#if dirty && baseKey !== loadedBaseKey}
      <p class="text-sm">A newer profile is available. <button type="button" on:click={loadProfile} class="underline">Discard edits and load latest</button></p>
    {/if}
    </form>

    {#if blockedReason}
      <div data-testid="profile-editor-blocked" class="mt-3 rounded-[16px] bg-amber-400/[0.06] px-3 py-2.5 text-[0.84rem] leading-5 text-amber-500">
        {blockedReason}
      </div>
    {:else if !canPublish}
      <div data-testid="profile-editor-read-only" class="mt-3 text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.5)]">
        This account is read-only. Import its secret key to edit the profile.
      </div>
    {/if}

    {#if error}
      <div data-testid="profile-editor-error" class="mt-3 text-[0.84rem] leading-5 text-rose-500">{error}</div>
    {:else if message}
      <div data-testid="profile-editor-success" class="mt-3 text-[0.84rem] leading-5 text-emerald-500">{message}</div>
    {/if}
  </SettingsGroupItem>
</SettingsGroup>
