<script lang="ts">
  import { resolveIrisUsername } from '../irisUsername';

  export let username: string;
  export let active = true;
  export let onResolve: (pubkey: string) => void = () => undefined;

  let loading = true;
  let error = '';
  let loadedUsername = '';
  let resolvedPubkey = '';
  let reportedUsername = '';
  let requestId = 0;

  $: if (username !== loadedUsername) {
    loadedUsername = username;
    resolvedPubkey = '';
    reportedUsername = '';
    void resolve();
  }
  $: if (active && resolvedPubkey && reportedUsername !== username) {
    reportedUsername = username;
    onResolve(resolvedPubkey);
  }

  async function resolve(): Promise<void> {
    const requestedUsername = username;
    const nextRequestId = ++requestId;
    loading = true;
    error = '';
    try {
      const pubkey = await resolveIrisUsername(requestedUsername);
      if (nextRequestId !== requestId || requestedUsername !== username) return;
      if (!pubkey) throw new Error('No Iris profile was found for this username.');
      resolvedPubkey = pubkey;
    } catch (nextError) {
      if (nextRequestId !== requestId || requestedUsername !== username) return;
      error = nextError instanceof Error ? nextError.message : 'Could not resolve this Iris username.';
    } finally {
      if (nextRequestId === requestId) loading = false;
    }
  }
</script>

<div data-testid="iris-username-route" class="px-5 py-8 text-[0.94rem] text-[rgb(var(--iris-text-rgb)/0.58)]">
  {#if loading}
    Opening iris.to/{username}…
  {:else if error}
    <p class="m-0">{error}</p>
    <button type="button" class="mt-4 rounded-full bg-[var(--iris-solid)] px-4 py-2 font-700 text-[var(--iris-on-solid)]" on:click={() => void resolve()}>Try again</button>
  {/if}
</div>
