<script lang="ts">
  import { onDestroy } from 'svelte';
  import { socialGraphBadges, createSocialGraphBadgeBinding } from '../socialGraphBadges';
  import SocialDistanceBadge from '@iris/svelte-ui/SocialDistanceBadge.svelte';
  export let pubkey: string;
  export let className = '';
  export let reserveSpace = false;
  export let active = true;
  const sync = createSocialGraphBadgeBinding();
  $: sync(active ? pubkey : null);
  $: badge = $socialGraphBadges.get(pubkey);
  $: hasBadge = badge?.muted || (badge?.distance !== undefined
    && badge.distance !== null && badge.distance <= 2);
  onDestroy(() => sync(null));
</script>

{#if reserveSpace}
  {#if !badge || hasBadge}
    <span class="inline-flex h-4 w-4 shrink-0 items-center justify-center">
      {#if hasBadge}
        <SocialDistanceBadge distance={badge?.distance} followedByFriends={badge?.followedByFriends} muted={badge?.muted} className={`iris-preserve-white-text ${className}`} />
      {/if}
    </span>
  {/if}
{:else if hasBadge}
  <SocialDistanceBadge distance={badge?.distance} followedByFriends={badge?.followedByFriends} muted={badge?.muted} className={`iris-preserve-white-text ${className}`} />
{/if}
