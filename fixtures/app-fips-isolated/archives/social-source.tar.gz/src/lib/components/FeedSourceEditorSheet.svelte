<script lang="ts">
  import { feedFilterScope, feedFiltersStore, readFeedFilters, updateFeedFilters, type FeedFilters } from '../feedFilters';
  import type { HomeTab } from '../routes';
  import ModalShell from './ModalShell.svelte';
  import IrisIcon from './IrisIcon.svelte';

  type FeedSourceEntry = {
    id: string;
    name: string;
    identity: string;
  };

  export let open = false;
  export let viewerPubkey: string | null = null;
  export let activeTab: HomeTab = 'latest';
  export let sources: FeedSourceEntry[] = [];
  export let sourceName = '';
  export let sourceIdentity = '';
  export let sourceError = '';
  export let activeSourceId: string | null = null;
  export let onClose: () => void = () => undefined;
  export let onSourceNameChange: (value: string) => void = () => undefined;
  export let onSourceIdentityChange: (value: string) => void = () => undefined;
  export let onAddSource: () => void = () => undefined;
  export let onSelectDefault: (() => void) | null = null;
  export let onSelectSource: ((id: string) => void) | null = null;
  export let onRemoveSource: ((id: string) => void) | null = null;

  let editingSourceId: string | null = null;
  $: filterScope = feedFilterScope(viewerPubkey, activeSourceId, activeTab);
  $: filters = readFeedFilters($feedFiltersStore, filterScope);
  $: tabLabel = activeTab === 'for-you' ? 'For you' : activeTab === 'media' ? 'Media' : 'Latest';
  $: if (!open) { editingSourceId = null; }

  function editSource(source: FeedSourceEntry): void {
    editingSourceId = source.id;
    onSourceNameChange(source.name);
    onSourceIdentityChange(source.identity);
  }

  function changeFilter(key: keyof FeedFilters, checked: boolean): void {
    updateFeedFilters(filterScope, { [key]: checked });
  }

  function shortIdentity(value: string): string {
    const trimmed = value.trim();
    if (trimmed.length <= 28) {
      return trimmed;
    }

    return `${trimmed.slice(0, 12)}…${trimmed.slice(-8)}`;
  }

  function handleSubmit(): void {
    onAddSource();
  }
</script>

<ModalShell {open} {onClose}>
  <aside
    data-testid="feed-source-sheet"
    class="max-h-[calc(100dvh-2rem)] w-full max-w-[32rem] overflow-y-auto rounded-[28px] border border-white/5 bg-black px-4 pb-6 pt-5 shadow-[0_24px_80px_rgba(0,0,0,0.35)] sm:px-5"
  >
    <div class="flex items-center justify-between gap-3">
      <div class="text-[1.05rem] font-700 text-white">Feed settings</div>

      <button
        type="button"
        class="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white transition hover:bg-[#1a1a1a]"
        aria-label="Close feed settings"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={18} />
      </button>
    </div>

    <fieldset class="mt-4 grid gap-3 rounded-2xl border border-white/5 bg-[#0a0a0a] p-4" disabled={!filterScope}>
      <legend class="px-1 text-sm font-600">{tabLabel} filters</legend>
      <label class="flex items-center justify-between gap-3 text-sm">
        <span>Post type</span>
        <select
          aria-label="Post type"
          value={filters.postType}
          class="rounded-lg border border-white/10 bg-[#111] px-3 py-2"
          on:change={(event) => updateFeedFilters(filterScope, { postType: event.currentTarget.value as FeedFilters['postType'] })}
        >
          <option value="all">All types</option>
          <option value="posts">Posts</option>
          <option value="articles">Articles</option>
        </select>
      </label>
      {#if activeTab !== 'for-you'}
        <label class="flex items-center justify-between gap-3 text-sm">
          <span>Show replies</span>
          <input type="checkbox" checked={filters.showReplies} on:change={(event) => changeFilter('showReplies', event.currentTarget.checked)} />
        </label>
      {/if}
      <label class="flex items-center justify-between gap-3 text-sm">
        <span>Show reposts</span>
        <input type="checkbox" checked={filters.showReposts} on:change={(event) => changeFilter('showReposts', event.currentTarget.checked)} />
      </label>
      {#if activeTab === 'latest'}
        <label class="flex items-center justify-between gap-3 text-sm">
          <span>Show replied-to posts</span>
          <input type="checkbox" checked={filters.showReplies && filters.showRepliedTo} disabled={!filters.showReplies} on:change={(event) => changeFilter('showRepliedTo', event.currentTarget.checked)} />
        </label>
      {/if}
      {#if activeTab !== 'media'}
        <label class="flex items-center justify-between gap-3 text-sm">
          <span>Only posts with media</span>
          <input type="checkbox" checked={filters.mediaOnly} on:change={(event) => changeFilter('mediaOnly', event.currentTarget.checked)} />
        </label>
      {/if}
      <div class="flex items-center justify-between gap-3 text-xs text-white/50">
        <span>Saved for this account and source.</span>
        <button type="button" class="text-white/75 hover:text-white" on:click={() => updateFeedFilters(filterScope, null)}>Reset filters</button>
      </div>
    </fieldset>

    <div class="mb-2 mt-4 px-1 text-[0.72rem] font-700 uppercase tracking-[0.14em] text-white/40">
      Sources
    </div>

    <form class="grid gap-3" on:submit|preventDefault={handleSubmit}>
      <input
        data-testid="feed-source-name-input"
        value={sourceName}
        placeholder="Name"
        aria-label="Source name"
        class="rounded-[18px] border border-white/5 bg-[#0a0a0a] px-4 py-3 text-[0.95rem] text-white outline-none placeholder:text-white/28"
        on:input={(event) => onSourceNameChange((event.currentTarget as HTMLInputElement).value)}
      />

      <div class="flex gap-2">
        <input
          data-testid="feed-source-identity-input"
          value={sourceIdentity}
          placeholder="npub or hex pubkey"
          aria-label="Source profile"
          disabled={editingSourceId !== null}
          class="min-w-0 flex-1 rounded-[18px] border border-white/5 bg-[#0a0a0a] px-4 py-3 text-[0.95rem] text-white outline-none placeholder:text-white/28"
          on:input={(event) => onSourceIdentityChange((event.currentTarget as HTMLInputElement).value)}
        />

        <button
          data-testid="feed-source-add"
          type="submit"
          class="rounded-[18px] border border-white/5 bg-[#111111] px-4 py-3 text-[0.92rem] font-700 text-white transition hover:bg-[#1a1a1a]"
        >
          {editingSourceId ? 'Save' : 'Add'}
        </button>
      </div>
    </form>

    {#if sourceError}
      <div class="mt-3 text-[0.85rem] text-[#ffb4b4]">{sourceError}</div>
    {/if}

    <div class="mt-5 grid gap-3">
      {#if onSelectDefault}
        <button
          data-testid="feed-source-default"
          type="button"
          class={`flex items-center gap-3 rounded-[24px] border px-4 py-4 text-left transition ${
            activeSourceId === null
              ? 'border-white/10 bg-[#111111] text-white'
              : 'border-white/5 bg-[#0a0a0a] text-white/75 hover:bg-[#111111] hover:text-white'
          }`}
          on:click={() => onSelectDefault?.()}
        >
          <IrisIcon name="home-solid" size={18} className="text-white/60" />
          <span class="min-w-0 flex-1">
            <span class="block truncate text-[0.98rem] font-700">Following</span>
            <span class="mt-1 block truncate text-[0.82rem] text-white/55">Active account</span>
          </span>
          {#if activeSourceId === null}
            <IrisIcon name="check-verified" size={18} className="text-white/70" />
          {/if}
        </button>
      {/if}

      {#each sources as source (source.id)}
        <div class={`flex items-center gap-3 rounded-[24px] border px-4 py-4 ${
          activeSourceId === source.id ? 'border-white/10 bg-[#111111]' : 'border-white/5 bg-[#0a0a0a]'
        }`}>
          <button
            data-testid="feed-source-row"
            type="button"
            class="min-w-0 flex-1 text-left"
            on:click={() => onSelectSource?.(source.id)}
          >
            <div class="truncate text-[0.98rem] font-700 text-white">{source.name}</div>
            <div class="mt-1 truncate font-mono text-[0.82rem] text-white/55">
              {shortIdentity(source.identity)}
            </div>
          </button>

          {#if activeSourceId === source.id}
            <IrisIcon name="check-verified" size={18} className="shrink-0 text-white/70" />
          {/if}

          <button
            type="button"
            class="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white/65 hover:text-white"
            aria-label={`Edit ${source.name}`}
            on:click={() => editSource(source)}
          >
            <IrisIcon name="pencil" size={17} />
          </button>

          {#if onRemoveSource}
            <button
              type="button"
              class="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white/65 transition hover:bg-[#1a1a1a] hover:text-white"
              aria-label={`Remove ${source.name}`}
              on:click={() => onRemoveSource(source.id)}
            >
              <IrisIcon name="trash" size={17} />
            </button>
          {/if}
        </div>
      {/each}
    </div>

    {#if sources.length === 0}
      <div class="mt-5 rounded-[24px] border border-white/5 bg-[#0a0a0a] p-6 text-[1rem] leading-7 text-white/55">
        No sources yet.
      </div>
    {/if}
  </aside>
</ModalShell>
