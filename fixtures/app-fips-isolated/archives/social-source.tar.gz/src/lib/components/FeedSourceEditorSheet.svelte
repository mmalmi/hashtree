<script lang="ts">
  import { tick } from 'svelte';
  import {
    deleteCustomFeed,
    duplicateCustomFeed,
    findCustomFeed,
    homeFeedLayoutsStore,
    homeFeedTabKey,
    moveHomeFeedTab,
    readHomeFeedLayout,
    visibleHomeFeedTabs,
  } from '../homeFeedTabs';
  import type { HomeTab } from '../routes';
  import IrisIcon from './IrisIcon.svelte';

  type FeedSourceEntry = { id: string; name: string; identity: string };

  export let viewerPubkey: string | null;
  export let activeTab: HomeTab;
  export let activeFeedId: string | null = null;
  export let sources: FeedSourceEntry[];
  export let sourceName: string;
  export let sourceIdentity: string;
  export let sourceError: string;
  export let activeSourceId: string | null;
  export let onSourceNameChange: (value: string) => void;
  export let onSourceIdentityChange: (value: string) => void;
  export let onAddSource: () => void;
  export let onSelectDefault: () => void;
  export let onSelectSource: (id: string) => void;
  export let onRemoveSource: (id: string) => void;
  export let onSelectFeed: ((tab: HomeTab, feedId: string | null) => void) | null = null;
  export let onClose: (() => void) | null = null;

  let editingSource: FeedSourceEntry | 'new' | null = null;
  let nameInput: HTMLInputElement;
  let addButton: HTMLButtonElement;
  let sourcesSummary: HTMLElement;
  let formTrigger: HTMLElement | null = null;
  let confirmingDelete = false;

  $: layout = readHomeFeedLayout($homeFeedLayoutsStore, viewerPubkey);
  $: custom = findCustomFeed(layout, activeFeedId);
  $: tabs = visibleHomeFeedTabs(layout);
  $: activeKey = homeFeedTabKey(activeTab, activeFeedId);
  $: position = tabs.findIndex((tab) => tab.key === activeKey);
  $: if (activeKey) { confirmingDelete = false; }
  $: activeSourceName = sources.find(source => source.id === activeSourceId)?.name ?? 'Yours';
  $: usesFollowList = activeTab === 'latest' || activeTab === 'for-you' || activeTab === 'media';

  function duplicate(): void {
    if (!custom) {return;}
    const copy = duplicateCustomFeed(viewerPubkey, custom.id);
    if (copy) {onSelectFeed?.(copy.base, copy.id);}
  }

  /** After deleting, show the tab to its left (or the first tab). */
  function deleteFeed(): void {
    if (!custom) {return;}
    const remaining = tabs.filter((tab) => tab.key !== activeKey);
    const next = remaining[Math.max(position - 1, 0)] ?? null;
    deleteCustomFeed(viewerPubkey, custom.id);
    onSelectFeed?.(next?.tab ?? 'for-you', next?.feedId ?? null);
    onClose?.();
  }

  async function editSource(source: FeedSourceEntry | 'new', trigger: HTMLElement): Promise<void> {
    formTrigger = trigger;
    editingSource = source;
    onSourceNameChange(source === 'new' ? '' : source.name);
    onSourceIdentityChange(source === 'new' ? '' : source.identity);
    await tick();
    nameInput?.focus();
  }

  async function cancelEdit(): Promise<void> {
    const wasNew = editingSource === 'new';
    editingSource = null;
    await tick();
    (wasNew ? addButton : formTrigger)?.focus({ preventScroll: true });
    formTrigger = null;
  }

  function handleSourcesKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && !event.defaultPrevented && !event.isComposing && sourcesSummary.parentElement instanceof HTMLDetailsElement && sourcesSummary.parentElement.open) {
      event.preventDefault();
      sourcesSummary.parentElement.open = false;
      sourcesSummary.focus({ preventScroll: true });
    }
  }

  function handleFormKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && !event.isComposing) {
      event.preventDefault();
      void cancelEdit();
    }
  }

  function shortIdentity(identity: string): string {
    return identity.length > 28 ? `${identity.slice(0, 12)}…${identity.slice(-8)}` : identity;
  }

  const inputClass = 'min-w-0 rounded-lg iris-field px-3 py-2 text-[max(1rem,16px)]';
  const hint = 'm-0 text-xs text-white/60';
  const pillButton = 'inline-flex h-8 items-center gap-1.5 rounded-full iris-neutral-button px-3 font-650 disabled:opacity-40';
  const iconButton = 'grid h-8 w-8 place-items-center rounded-full iris-neutral-button disabled:opacity-40';
</script>

<div class="grid gap-4 text-sm">
  {#if usesFollowList}
    <!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
    <details class="border-t border-divider pt-1" on:keydown={handleSourcesKeydown}>
      <summary bind:this={sourcesSummary} class="min-h-10 cursor-pointer py-2.5 font-650">
        <span>Follow list</span><span class="ml-2 font-normal text-white/60">{activeSourceName}</span>
      </summary>
      <p class={`${hint} mb-2`}>Whose follows "People you follow" and "Recommended" use. Applies to every feed.</p>
      <button data-testid="feed-source-default" type="button" aria-pressed={activeSourceId === null}
        class="flex w-full items-center gap-2 rounded-lg py-2 text-left" on:click={onSelectDefault}>
        <IrisIcon name="home-solid" size={17} /><span class="flex-1">Yours</span>
        {#if activeSourceId === null}<IrisIcon name="check" size={17} className="text-violet-400" />{/if}
      </button>
      {#each sources as source (source.id)}
        <div class="flex min-w-0 items-center gap-2">
          <button data-testid="feed-source-row" type="button" aria-pressed={activeSourceId === source.id}
            class="flex min-w-0 flex-1 items-center gap-2 rounded-lg py-2 text-left" on:click={() => onSelectSource(source.id)}>
            <span class="min-w-0 flex-1">
              <span class="block truncate font-650">{source.name}</span>
              <span class="block truncate font-mono text-xs text-white/60">{shortIdentity(source.identity)}</span>
            </span>
            {#if activeSourceId === source.id}<IrisIcon name="check" size={17} className="text-violet-400" />{/if}
          </button>
          <button type="button" aria-label={`Edit ${source.name}`} class="grid h-9 w-9 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]"
            on:click={event => editSource(source, event.currentTarget)}><IrisIcon name="pencil" size={16} /></button>
          <button type="button" aria-label={`Remove ${source.name}`} class="grid h-9 w-9 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]"
            on:click={() => onRemoveSource(source.id)}><IrisIcon name="trash" size={16} /></button>
        </div>
      {/each}
      {#if editingSource}
        <!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
        <form aria-label={editingSource === 'new' ? 'Add follow list' : 'Edit follow list'} class="mt-2 grid gap-2 sm:max-w-md"
          on:keydown={handleFormKeydown} on:submit|preventDefault={onAddSource}>
          <label class="grid gap-1">Name
            <input bind:this={nameInput} data-testid="feed-source-name-input" value={sourceName} class={inputClass}
              on:input={event => onSourceNameChange(event.currentTarget.value)} />
          </label>
          <label class="grid gap-1">Person
            <input data-testid="feed-source-identity-input" value={sourceIdentity} placeholder="npub or hex pubkey" disabled={editingSource !== 'new'}
              class={inputClass} on:input={event => onSourceIdentityChange(event.currentTarget.value)} />
          </label>
          {#if sourceError}<span role="alert" class="text-red-400">{sourceError}</span>{/if}
          <div class="flex justify-end gap-2">
            <button type="button" class="rounded-full px-3 py-2" on:click={cancelEdit}>Cancel</button>
            <button data-testid="feed-source-add" type="submit" class="rounded-full iris-neutral-button px-4 py-2 font-650">{editingSource === 'new' ? 'Add' : 'Save'}</button>
          </div>
        </form>
      {:else}
        <button bind:this={addButton} type="button" class="mt-1 rounded-full iris-neutral-button px-3 py-2 font-650"
          on:click={event => editSource('new', event.currentTarget)}>Use someone's follows</button>
      {/if}
    </details>
  {/if}

  {#if viewerPubkey}
    <div class="flex items-center gap-2 border-t border-divider pt-3" data-testid="feed-actions">
      <button type="button" data-testid="feed-tab-move-left" aria-label="Move feed left" title="Move left" class={iconButton}
        disabled={position <= 0} on:click={() => moveHomeFeedTab(viewerPubkey, activeKey, -1)}>
        <IrisIcon name="arrowBack" size={15} />
      </button>
      <button type="button" data-testid="feed-tab-move-right" aria-label="Move feed right" title="Move right" class={iconButton}
        disabled={position < 0 || position >= tabs.length - 1} on:click={() => moveHomeFeedTab(viewerPubkey, activeKey, 1)}>
        <IrisIcon name="arrowFront" size={15} />
      </button>
      {#if custom}
        {#if confirmingDelete}
          <span class="ml-auto flex min-w-0 items-center gap-2" role="group" aria-label="Confirm delete">
            <span class="truncate font-650">Delete "{custom.name}"?</span>
            <button type="button" data-testid="custom-feed-delete-cancel" class={pillButton} on:click={() => { confirmingDelete = false; }}>Keep</button>
            <button type="button" data-testid="custom-feed-delete-confirm"
              class="h-8 shrink-0 rounded-full bg-red-600 px-3 font-650 text-white iris-preserve-white-text" on:click={deleteFeed}>Delete</button>
          </span>
        {:else}
          <button type="button" data-testid="custom-feed-duplicate" class={pillButton} on:click={duplicate}>
            <IrisIcon name="copy" size={15} />Duplicate
          </button>
          <button type="button" data-testid="custom-feed-delete" class={`${pillButton} ml-auto`} on:click={() => { confirmingDelete = true; }}>
            <IrisIcon name="trash" size={15} />Delete feed
          </button>
        {/if}
      {/if}
    </div>
  {/if}
</div>
