<script lang="ts">
  import { onDestroy } from 'svelte';
  import { createRetryableDynamicImport } from '../../retryableDynamicImport';
  import IrisIcon from '../IrisIcon.svelte';

  export let value = '';
  export let label = 'payment';

  let qrUrl = '';
  let qrRequest = 0;
  let lastValue = '';
  let copied = false;
  let copyError = '';
  let copiedTimer: number | null = null;
  const loadQrCode = createRetryableDynamicImport(() => import('qrcode'));

  $: if (value && value !== lastValue) {
    lastValue = value;
    void generate(value);
  }

  async function generate(nextValue: string): Promise<void> {
    const request = ++qrRequest;
    try {
      const QRCode = (await loadQrCode()).default;
      const nextUrl = await QRCode.toDataURL(nextValue, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 320,
        color: { dark: '#000000', light: '#ffffff' },
      });
      if (request === qrRequest) qrUrl = nextUrl;
    } catch {
      if (request === qrRequest) qrUrl = '';
    }
  }

  async function copy(): Promise<void> {
    copyError = '';
    try {
      await navigator.clipboard.writeText(value);
      copied = true;
      if (copiedTimer !== null) window.clearTimeout(copiedTimer);
      copiedTimer = window.setTimeout(() => {
        copied = false;
        copiedTimer = null;
      }, 2_000);
    } catch {
      copyError = 'Copy failed. Select the value below.';
    }
  }

  onDestroy(() => {
    if (copiedTimer !== null) window.clearTimeout(copiedTimer);
  });
</script>

<div class="grid justify-items-center gap-3">
  {#if qrUrl}
    <img data-testid="wallet-qr" src={qrUrl} alt={`QR code for ${label}`} class="h-56 w-56 rounded-2xl bg-white p-2" />
  {/if}
  <label class="sr-only" for="wallet-qr-value">{label}</label>
  <textarea
    id="wallet-qr-value"
    readonly
    rows="3"
    value={value}
    class="w-full resize-none rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs leading-5 outline-none"
    on:focus={(event) => event.currentTarget.select()}
  ></textarea>
  <button
    type="button"
    class="flex min-h-11 items-center justify-center gap-2 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)]"
    on:click={() => void copy()}
  >
    <IrisIcon name={copied ? 'check' : 'copy'} size={18} />
    {copied ? 'Copied' : 'Copy'}
  </button>
  {#if copyError}<p role="alert" class="text-sm text-red-400">{copyError}</p>{/if}
</div>
