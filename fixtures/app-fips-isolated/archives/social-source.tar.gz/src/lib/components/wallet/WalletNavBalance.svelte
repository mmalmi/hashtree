<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { ensureExchangeRates, exchangeRateStore } from '../../exchangeRateStore';
  import { formatSatsAmount } from '../../exchangeRates';
  import { settingsStore } from '../../settings';
  import type { WalletSnapshot } from '../../walletTypes';

  export let compact = false;

  let mounted = false;
  let loading = false;
  let unsubscribe: (() => void) | null = null;
  let snapshot: WalletSnapshot | null = null;

  $: enabled = $settingsStore.wallet.showBalanceInNavigation;
  $: currency = $settingsStore.wallet.primaryCurrency;
  $: label = snapshot
    ? formatSatsAmount(snapshot.spendableBits, currency, $exchangeRateStore)
    : '';
  $: if (mounted) syncSubscription(enabled);
  $: if (mounted && enabled) ensureExchangeRates(currency);

  function accept(nextSnapshot: WalletSnapshot): void {
    snapshot = nextSnapshot.initialized || nextSnapshot.updatedAt ? nextSnapshot : null;
  }

  function syncSubscription(nextEnabled: boolean): void {
    if (!nextEnabled) {
      unsubscribe?.();
      unsubscribe = null;
      snapshot = null;
      return;
    }
    if (unsubscribe || loading) return;
    loading = true;
    void import('../../walletStore').then(({ wallet }) => {
      if (!mounted || !$settingsStore.wallet.showBalanceInNavigation) return;
      unsubscribe = wallet.subscribe(accept);
    }).catch(() => undefined).finally(() => { loading = false; });
  }

  onMount(() => {
    mounted = true;
    syncSubscription(enabled);
  });

  onDestroy(() => {
    mounted = false;
    unsubscribe?.();
  });
</script>

{#if compact && enabled}
  <span
    data-testid={snapshot && label !== '—' ? 'mobile-wallet-balance' : undefined}
    aria-hidden={!snapshot || label === '—'}
    class="block h-[0.58rem] max-w-16 truncate text-[0.58rem] font-700 leading-none opacity-70"
  >{snapshot && label !== '—' ? label : ''}</span>
{:else if enabled && snapshot && label !== '—'}
  <span
    data-testid="desktop-wallet-balance"
    class="ml-auto hidden max-w-24 truncate text-xs font-600 opacity-60 xl:inline"
  >{label}</span>
{/if}
