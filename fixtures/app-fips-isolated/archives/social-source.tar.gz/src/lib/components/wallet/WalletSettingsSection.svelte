<script lang="ts">
  import NwcSettings from './NwcSettings.svelte';
  import { onDestroy } from 'svelte';
  import { wallet } from '../../walletStore';
  import { EXCHANGE_RATE_CURRENCIES, type ExchangeRateCurrency } from '../../exchangeRates';
  import {
    ensureExchangeRates,
    exchangeRateStore,
    refreshExchangeRates,
  } from '../../exchangeRateStore';
  import { walletHref } from '../../routes';
  import { settingsStore } from '../../settings';
  import { errorMessage } from './walletUi';

  export let active = false;

  let seed = '';
  let pending = false;
  let error = '';
  let copied = false;
  let ratesPending = false;
  let seedRequest = 0;

  $: if (active) ensureExchangeRates($settingsStore.wallet.primaryCurrency);
  $: rateStatus = $settingsStore.wallet.primaryCurrency === 'SAT'
    || $settingsStore.wallet.primaryCurrency === 'BTC'
    ? 'No exchange rate needed'
    : $exchangeRateStore
      ? `${$exchangeRateStore.stale ? 'Cached' : 'Updated'} ${new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format($exchangeRateStore.updatedAt)} · ${$exchangeRateStore.cachedSource ?? $exchangeRateStore.source}`
      : 'No cached exchange rate';

  $: if (!active) {
    seedRequest += 1;
    seed = '';
    copied = false;
    pending = false;
  }

  async function revealSeed(): Promise<void> {
    if (pending) return;
    const request = ++seedRequest;
    pending = true;
    error = '';
    try {
      const result = await wallet.exportSeed();
      if (active && request === seedRequest) seed = result.seed;
    } catch (nextError) {
      if (active && request === seedRequest) error = errorMessage(nextError);
    } finally {
      if (request === seedRequest) pending = false;
    }
  }

  async function copySeed(): Promise<void> {
    const request = seedRequest;
    try {
      await navigator.clipboard.writeText(seed);
      if (active && request === seedRequest) copied = true;
    } catch {
      if (active && request === seedRequest) error = 'Copy failed. Select the wallet secret manually.';
    }
  }

  onDestroy(() => { seedRequest += 1; });

  function selectCurrency(value: string): void {
    const currency = value as ExchangeRateCurrency;
    settingsStore.setWalletSettings({ primaryCurrency: currency });
    ensureExchangeRates(currency);
  }

  async function refreshRates(): Promise<void> {
    if (ratesPending) return;
    ratesPending = true;
    try {
      await refreshExchangeRates(true);
    } catch {
      error = 'Could not refresh exchange rates. Cached values remain available.';
    } finally {
      ratesPending = false;
    }
  }
</script>

<div data-testid="settings-wallet-section" class="grid gap-6 p-4 sm:p-5">
  <NwcSettings {active} />
  <section class="overflow-hidden rounded-xl bg-[var(--iris-surface)] shadow-sm">
    <header class="border-b border-[rgb(var(--iris-text-rgb)/0.1)] px-4 py-3"><h2 class="font-700">Cashu wallet</h2></header>
    <div class="grid gap-3 p-4">
      <p class="text-sm leading-6 text-[rgb(var(--iris-text-rgb)/0.65)]">Cashu wallet data and keys stay in this browser. Move funds out before clearing site data; this version does not yet support restoring a wallet in-app.</p>
      <a href={walletHref()} class="w-fit rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] px-4 py-2 text-sm font-700 no-underline">Open wallet</a>
    </div>
  </section>

  <section class="overflow-hidden rounded-xl bg-[var(--iris-surface)] shadow-sm">
    <header class="border-b border-[rgb(var(--iris-text-rgb)/0.1)] px-4 py-3"><h2 class="font-700">Display</h2></header>
    <div class="divide-y divide-[rgb(var(--iris-text-rgb)/0.08)]">
      <label class="flex items-center justify-between gap-4 p-4" for="wallet-primary-currency">
        <span><span class="block text-sm font-600">Primary currency</span><span class="mt-1 block text-xs text-[rgb(var(--iris-text-rgb)/0.55)]">Wallet and zap amounts</span></span>
        <select id="wallet-primary-currency" data-testid="wallet-primary-currency" value={$settingsStore.wallet.primaryCurrency} class="rounded-lg bg-[var(--iris-surface-subtle)] px-3 py-2 text-sm" on:change={(event) => selectCurrency(event.currentTarget.value)}>{#each EXCHANGE_RATE_CURRENCIES as currency}<option value={currency}>{currency}</option>{/each}</select>
      </label>
      <label class="flex cursor-pointer items-center justify-between gap-4 p-4">
        <span><span class="block text-sm font-600">Show balance in navigation</span><span class="mt-1 block text-xs text-[rgb(var(--iris-text-rgb)/0.55)]">Keep the cached balance visible beside Wallet</span></span>
        <input data-testid="wallet-show-nav-balance" type="checkbox" checked={$settingsStore.wallet.showBalanceInNavigation} class="h-4 w-4 accent-violet-500" on:change={(event) => settingsStore.setWalletSettings({ showBalanceInNavigation: event.currentTarget.checked })} />
      </label>
      {#if $settingsStore.wallet.primaryCurrency !== 'SAT' && $settingsStore.wallet.primaryCurrency !== 'BTC'}
        <div class="flex items-center justify-between gap-4 p-4 text-xs text-[rgb(var(--iris-text-rgb)/0.55)]"><span>{rateStatus}</span><button type="button" disabled={ratesPending} class="shrink-0 font-700 text-violet-400 disabled:opacity-50" on:click={() => void refreshRates()}>{ratesPending ? 'Refreshing…' : 'Refresh rate'}</button></div>
      {/if}
    </div>
  </section>

  <section class="overflow-hidden rounded-xl bg-[var(--iris-surface)] shadow-sm">
    <header class="border-b border-[rgb(var(--iris-text-rgb)/0.1)] px-4 py-3"><h2 class="font-700">Wallet secret</h2></header>
    <div class="grid gap-3 p-4">
      <p class="text-sm leading-6 text-amber-500">Advanced export only: this secret is sensitive, but it is not a complete restorable backup without wallet and mint state. Never share it.</p>
      {#if seed}
        <label for="wallet-recovery-seed" class="text-sm font-600">Wallet secret</label>
        <textarea id="wallet-recovery-seed" data-testid="wallet-recovery-seed" readonly value={seed} rows="3" class="w-full resize-none rounded-xl bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs leading-5" on:focus={(event) => event.currentTarget.select()}></textarea>
        <button type="button" class="w-fit rounded-full bg-[var(--iris-solid)] px-4 py-2 text-sm font-700 text-[var(--iris-on-solid)]" on:click={() => void copySeed()}>{copied ? 'Copied' : 'Copy seed'}</button>
      {:else}
        <button data-testid="wallet-reveal-seed" type="button" disabled={pending} class="w-fit rounded-full border border-red-400/35 px-4 py-2 text-sm font-700 text-red-400 disabled:opacity-50" on:click={() => void revealSeed()}>{pending ? 'Opening wallet…' : 'Reveal wallet secret'}</button>
      {/if}
      {#if error}<p role="alert" class="text-sm text-red-400">{error}</p>{/if}
    </div>
  </section>
</div>
