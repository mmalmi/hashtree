<script lang="ts">
  import type { WalletBalance, WalletMint } from '../../walletTypes';
  import { wallet } from '../../walletStore';
  import IrisIcon from '../IrisIcon.svelte';
  import { errorMessage, formatBits } from './walletUi';

  export let mints: WalletMint[] = [];
  export let balances: WalletBalance[] = [];

  let mintUrl = '';
  let adding = false;
  let pendingUrl = '';
  let error = '';

  function balanceFor(url: string): WalletBalance | null {
    return balances.find((balance) => balance.mintUrl === url) ?? null;
  }

  async function addMint(): Promise<void> {
    if (!mintUrl.trim() || adding) return;
    adding = true;
    error = '';
    try {
      await wallet.addMint(mintUrl);
      mintUrl = '';
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      adding = false;
    }
  }

  async function toggleTrust(mint: WalletMint): Promise<void> {
    if (pendingUrl) return;
    pendingUrl = mint.url;
    error = '';
    try {
      await wallet.setMintTrusted(mint.url, !mint.trusted);
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pendingUrl = '';
    }
  }
</script>

<section id="wallet-mints" data-testid="wallet-mints" aria-labelledby="wallet-mints-title">
  <h2 id="wallet-mints-title" class="sr-only">Mints</h2>
  {#if mints.length > 0}
    <ul>
      {#each mints as mint (mint.url)}
        {@const balance = balanceFor(mint.url)}
        <li class="flex items-center gap-3 border-b border-[rgb(var(--iris-text-rgb)/0.07)] px-4 py-3">
          <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-violet-500/12 text-violet-400"><IrisIcon name="wallet-outline" size={18} /></span>
          <span class="min-w-0 flex-1">
            <span class="block truncate font-600">{mint.name}</span>
            <span class="block truncate text-xs text-[rgb(var(--iris-text-rgb)/0.5)]" title={mint.url}>{mint.url}</span>
            {#if balance}<span class="block text-xs text-[rgb(var(--iris-text-rgb)/0.62)]">{formatBits(balance.spendableBits)} spendable</span>{/if}
          </span>
          <label class="grid shrink-0 cursor-pointer justify-items-center gap-1 text-[0.68rem] text-[rgb(var(--iris-text-rgb)/0.58)]">
            <input
              type="checkbox"
              checked={mint.trusted}
              disabled={pendingUrl === mint.url}
              class="h-4 w-4 accent-violet-500"
              aria-label={`Trust ${mint.name}`}
              on:change={() => void toggleTrust(mint)}
            />
            Trusted
          </label>
        </li>
      {/each}
    </ul>
  {/if}
  <form class="flex gap-2 p-4" on:submit|preventDefault={() => void addMint()}>
    <label for="wallet-mint-url" class="sr-only">Mint URL</label>
    <input
      id="wallet-mint-url"
      data-testid="wallet-mint-url"
      type="url"
      inputmode="url"
      autocomplete="url"
      bind:value={mintUrl}
      placeholder="https://mint.example"
      class="min-w-0 flex-1 rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-sm outline-none focus:border-violet-400"
    />
    <button data-testid="wallet-add-mint" type="submit" disabled={!mintUrl.trim() || adding} class="rounded-xl bg-[var(--iris-solid)] px-4 text-sm font-700 text-[var(--iris-on-solid)] disabled:opacity-45">
      {adding ? 'Adding…' : 'Add'}
    </button>
  </form>
  {#if error}<p role="alert" class="px-4 pb-4 text-sm text-red-400">{error}</p>{/if}
</section>
