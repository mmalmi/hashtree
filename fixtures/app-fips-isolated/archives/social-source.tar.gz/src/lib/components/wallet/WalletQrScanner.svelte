<script lang="ts">
  import { createRetryableDynamicImport } from '../../retryableDynamicImport';
  import WalletDialogShell from './WalletDialogShell.svelte';

  export let open = false;
  export let onClose: () => void = () => undefined;
  export let onScan: (value: string) => void = () => undefined;

  const loadScanner = createRetryableDynamicImport(() => import('../QrScanner.svelte'));
  let scannerPromise: ReturnType<typeof loadScanner> | null = null;

  $: if (open && !scannerPromise) {
    scannerPromise = loadScanner();
  }

  function accept(value: string): void {
    onClose();
    onScan(value);
  }

  function retry(): void {
    scannerPromise = null;
  }
</script>

<WalletDialogShell
  {open}
  {onClose}
  title="Scan payment QR"
  titleId="wallet-scan-title"
  testId="wallet-qr-scanner-dialog"
>
  <div class="aspect-square w-full overflow-hidden rounded-2xl bg-black text-white">
    {#if scannerPromise}
      {#await scannerPromise}
        <div class="grid h-full place-items-center bg-white/5 text-sm text-white/65">Starting camera…</div>
      {:then scanner}
        <svelte:component this={scanner.default} onScan={accept} />
      {:catch}
        <div role="alert" class="grid h-full place-items-center gap-4 bg-white/5 p-6 text-center text-sm"><span>Could not load the QR scanner.</span><button type="button" class="rounded-full border border-white/25 px-4 py-2 font-700" on:click={retry}>Retry</button></div>
      {/await}
    {/if}
  </div>
</WalletDialogShell>
