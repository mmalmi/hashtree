<script lang="ts">
  import type { WalletHistoryItem } from '../../walletTypes';
  import { wallet } from '../../walletStore';
  import { formatBits, formatWalletTime } from './walletUi';

  export let items: WalletHistoryItem[] = [];
  let confirmReclaimId = '';
  let reclaimPendingId = '';
  let reclaimError = '';

  const labels: Record<WalletHistoryItem['kind'], string> = {
    mint: 'Lightning received',
    melt: 'Lightning sent',
    send: 'Cashu sent',
    receive: 'Cashu received',
  };

  function incoming(kind: WalletHistoryItem['kind']): boolean {
    return kind === 'mint' || kind === 'receive';
  }

  function reclaimable(item: WalletHistoryItem): boolean {
    return item.kind === 'send'
      && Boolean(item.operationId)
      && (item.state === 'prepared' || item.state === 'executing' || item.state === 'pending');
  }

  async function reclaim(item: WalletHistoryItem): Promise<void> {
    if (!item.operationId || reclaimPendingId) return;
    reclaimPendingId = item.id;
    reclaimError = '';
    try {
      await wallet.cancelOperation(item.operationId, 'send');
      await wallet.refresh();
      confirmReclaimId = '';
    } catch (error) {
      reclaimError = error instanceof Error ? error.message : 'Could not reclaim this token.';
    } finally {
      reclaimPendingId = '';
    }
  }
</script>

<section id="wallet-history" data-testid="wallet-history" aria-labelledby="wallet-history-title">
  <h2 id="wallet-history-title" class="sr-only">Activity</h2>
  {#if items.length === 0}
    <p class="px-4 py-8 text-center text-sm text-[rgb(var(--iris-text-rgb)/0.55)]">No wallet activity yet.</p>
  {:else}
    <ol>
      {#each items as item (item.id)}
        <li class="flex items-start gap-3 border-b border-[rgb(var(--iris-text-rgb)/0.07)] px-4 py-3 last:border-b-0">
          <span class={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full text-lg ${incoming(item.kind) ? 'bg-emerald-500/12 text-emerald-400' : 'bg-violet-500/12 text-violet-400'}`} aria-hidden="true">
            {incoming(item.kind) ? '↓' : '↑'}
          </span>
          <span class="min-w-0 flex-1">
            <span class="block font-600">{labels[item.kind]}</span>
            <span class="block truncate text-xs text-[rgb(var(--iris-text-rgb)/0.5)]" title={item.mintUrl}>{formatWalletTime(item.createdAt)} · {item.state}</span>
            {#if item.error}<span role="alert" class="mt-1 block text-xs text-red-400">{item.error}</span>{/if}
            {#if confirmReclaimId === item.id}
              <span class="mt-2 block text-xs leading-5 text-amber-300">Reclaim only if the recipient has not redeemed this token. Their copy will stop working.</span>
              <span class="mt-2 flex gap-3 text-xs font-700"><button data-testid="wallet-confirm-reclaim-send" type="button" disabled={Boolean(reclaimPendingId)} class="text-red-400" on:click={() => void reclaim(item)}>{reclaimPendingId === item.id ? 'Reclaiming…' : 'Confirm reclaim'}</button><button type="button" class="text-[rgb(var(--iris-text-rgb)/0.58)]" on:click={() => confirmReclaimId = ''}>Cancel</button></span>
            {/if}
            {#if reclaimError && confirmReclaimId === item.id}<span role="alert" class="mt-2 block text-xs text-red-400">{reclaimError}</span>{/if}
          </span>
          <span class={`grid shrink-0 justify-items-end gap-1 pt-1 text-sm font-700 ${incoming(item.kind) ? 'text-emerald-400' : ''}`}>
            <span>{incoming(item.kind) ? '+' : '−'}{formatBits(item.amountBits)}</span>
            {#if reclaimable(item) && confirmReclaimId !== item.id}<button data-testid="wallet-reclaim-send" type="button" class="text-xs text-red-400" on:click={() => { confirmReclaimId = item.id; reclaimError = ''; }}>Reclaim</button>{/if}
          </span>
        </li>
      {/each}
    </ol>
  {/if}
</section>
