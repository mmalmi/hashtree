const bitsFormatter = new Intl.NumberFormat();
const walletTimeFormatter = new Intl.DateTimeFormat(undefined, {
  dateStyle: 'medium',
  timeStyle: 'short',
});

export function formatBits(value: number): string {
  return `${bitsFormatter.format(value)} bit${value === 1 ? '' : 's'}`;
}

export function formatWalletTime(timestamp: number): string {
  if (!timestamp) {return 'Not synced yet';}
  return walletTimeFormatter.format(timestamp);
}

export function relativeWalletTime(timestamp: number, now = Date.now()): string {
  if (!timestamp) {return 'Waiting for first sync';}
  const seconds = Math.max(0, Math.floor((now - timestamp) / 1_000));
  if (seconds < 10) {return 'Updated just now';}
  if (seconds < 60) {return `Updated ${seconds}s ago`;}
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {return `Updated ${minutes}m ago`;}
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {return `Updated ${hours}h ago`;}
  return `Updated ${Math.floor(hours / 24)}d ago`;
}

export function readPositiveBits(value: string): number | null {
  const bits = Number(value);
  return Number.isSafeInteger(bits) && bits > 0 ? bits : null;
}

export function errorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim()
    ? error.message
    : 'Wallet operation failed. Please retry.';
}

export function stripPaymentScheme(value: string): string {
  return value.trim().replace(/^lightning:/i, '');
}

export function createPaymentIntentId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `wallet-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
