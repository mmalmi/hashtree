<script lang="ts">
  import { onDestroy } from 'svelte';
  import { wallet } from '../../walletStore';
  import type {
    WalletMint,
    WalletMintInvoice,
    WalletPreparedOperation,
    WalletTokenPreview,
  } from '../../walletTypes';
  import IrisIcon from '../IrisIcon.svelte';
  import WalletDialogShell from './WalletDialogShell.svelte';
  import WalletQr from './WalletQr.svelte';
  import WalletQrScanner from './WalletQrScanner.svelte';
  import { errorMessage, formatBits, readPositiveBits } from './walletUi';

  export let open = false;
  export let mints: WalletMint[] = [];
  export let onClose: () => void = () => undefined;

  let mode: 'lightning' | 'cashu' = 'lightning';
  let mintUrl = '';
  let amount = '';
  let token = '';
  let pending = false;
  let error = '';
  let invoice: WalletMintInvoice | null = null;
  let received: WalletPreparedOperation | null = null;
  let tokenPreview: WalletTokenPreview | null = null;
  let previewedToken = '';
  let scannerOpen = false;
  let wasOpen = false;
  const MAX_TOKEN_LENGTH = 200_000;
  let invoiceClock = Date.now();
  let invoiceExpiryTimer: number | null = null;

  $: trustedMints = mints.filter((mint) => mint.trusted);
  $: if (!trustedMints.some((mint) => mint.url === mintUrl)) mintUrl = trustedMints[0]?.url ?? '';
  $: invoiceExpired = Boolean(invoice?.expiresAt)
    && (invoice!.expiresAt! < 1_000_000_000_000 ? invoice!.expiresAt! * 1_000 : invoice!.expiresAt!) <= invoiceClock;
  $: invoiceFailed = invoice?.state === 'failed' || invoice?.state === 'cancelled';
  $: syncInvoiceExpiry(invoice?.expiresAt ?? null);
  $: syncOpenState(open);
  $: if (!open) scannerOpen = false;

  function syncOpenState(nextOpen: boolean): void {
    if (nextOpen === wasOpen) return;
    const opening = nextOpen && !wasOpen;
    wasOpen = nextOpen;
    scannerOpen = false;
    if (opening && !pending && (!invoice || invoice.state === 'finalized' || invoiceFailed || invoiceExpired)) reset();
  }

  function syncInvoiceExpiry(expiresAt: number | null): void {
    if (invoiceExpiryTimer !== null) window.clearTimeout(invoiceExpiryTimer);
    invoiceExpiryTimer = null;
    invoiceClock = Date.now();
    if (!expiresAt) return;
    const expiresAtMs = expiresAt < 1_000_000_000_000 ? expiresAt * 1_000 : expiresAt;
    if (expiresAtMs > invoiceClock) {
      invoiceExpiryTimer = window.setTimeout(() => {
        invoiceExpiryTimer = null;
        invoiceClock = Date.now();
      }, Math.min(2_147_000_000, expiresAtMs - invoiceClock + 50));
    }
  }

  function reset(): void {
    mode = 'lightning';
    mintUrl = trustedMints[0]?.url ?? '';
    amount = '';
    token = '';
    pending = false;
    error = '';
    invoice = null;
    received = null;
    tokenPreview = null;
    previewedToken = '';
    scannerOpen = false;
  }

  function selectMode(nextMode: typeof mode): void {
    if (pending) return;
    mode = nextMode;
    error = '';
  }

  function setToken(value: string): void {
    if (pending) return;
    const nextToken = value.trim();
    if (nextToken.length > MAX_TOKEN_LENGTH) {
      token = '';
      error = 'Cashu token is too long.';
      return;
    }
    token = nextToken;
    received = null;
    tokenPreview = null;
    previewedToken = '';
    error = '';
  }

  async function createInvoice(): Promise<void> {
    const amountBits = readPositiveBits(amount);
    if (!amountBits || !mintUrl || pending) return;
    pending = true;
    error = '';
    try {
      invoice = await wallet.createMintInvoice(mintUrl, amountBits);
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function checkInvoice(): Promise<void> {
    if (!invoice || pending || invoiceExpired || invoiceFailed) return;
    pending = true;
    error = '';
    try {
      const result = await wallet.refreshMint(invoice.operationId);
      invoice = { ...invoice, ...result };
      await wallet.refresh();
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  function createAnotherInvoice(): void {
    invoice = null;
    amount = '';
    error = '';
  }

  async function receiveToken(trustMint = false): Promise<void> {
    const submittedToken = trustMint ? previewedToken : token.trim();
    if (!submittedToken || pending) return;
    if (trustMint && (!tokenPreview || token.trim() !== submittedToken)) {
      tokenPreview = null;
      previewedToken = '';
      error = 'Token changed. Inspect it again before trusting its mint.';
      return;
    }
    pending = true;
    scannerOpen = false;
    error = '';
    try {
      if (!trustMint) {
        const preview = await wallet.inspectToken(submittedToken);
        if (token.trim() !== submittedToken) return;
        if (!preview.trusted) {
          tokenPreview = preview;
          previewedToken = submittedToken;
          return;
        }
      }
      received = await wallet.receiveToken(submittedToken, trustMint);
      tokenPreview = null;
      previewedToken = '';
      await wallet.refresh();
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  onDestroy(() => {
    if (invoiceExpiryTimer !== null) window.clearTimeout(invoiceExpiryTimer);
  });
</script>

<WalletDialogShell {open} title="Receive" titleId="wallet-receive-title" testId="wallet-receive-dialog" {onClose}>
  <div class="mb-5 grid grid-cols-2 rounded-xl bg-[var(--iris-surface-subtle)] p-1" role="group" aria-label="Receive method">
    <button type="button" aria-pressed={mode === 'lightning'} disabled={pending} class={`rounded-lg px-3 py-2 text-sm font-700 disabled:opacity-50 ${mode === 'lightning' ? 'bg-[var(--iris-surface-raised)] shadow' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectMode('lightning')}>Lightning</button>
    <button type="button" aria-pressed={mode === 'cashu'} disabled={pending} class={`rounded-lg px-3 py-2 text-sm font-700 disabled:opacity-50 ${mode === 'cashu' ? 'bg-[var(--iris-surface-raised)] shadow' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectMode('cashu')}>Cashu token</button>
  </div>

  {#if mode === 'lightning'}
    {#if invoice}
      <div class="grid gap-4">
        <div class="text-center">
          <h3 class="text-lg font-700">{invoice.state === 'finalized' ? 'Payment received' : invoiceExpired ? 'Invoice expired' : invoiceFailed ? 'Invoice failed' : `Receive ${formatBits(invoice.amountBits)}`}</h3>
          <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">{invoice.state === 'finalized' ? 'Your balance is updated.' : invoiceExpired || invoiceFailed ? 'Create a new invoice to try again.' : 'Pay this Lightning invoice to mint Cashu.'}</p>
        </div>
        {#if invoice.state !== 'finalized' && !invoiceExpired && !invoiceFailed}<WalletQr value={invoice.invoice} label="Lightning invoice" />{/if}
        {#if invoiceExpired || invoiceFailed}<button type="button" class="mx-auto rounded-full bg-[var(--iris-solid)] px-5 py-2.5 font-700 text-[var(--iris-on-solid)]" on:click={createAnotherInvoice}>Create another invoice</button>{:else}<button type="button" disabled={pending} class="mx-auto flex items-center gap-2 rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] px-5 py-2.5 font-700" on:click={() => void checkInvoice()}><IrisIcon name={invoice.state === 'finalized' ? 'check' : 'refresh-ccw-01'} size={18} />{pending ? 'Checking…' : invoice.state === 'finalized' ? 'Check again' : 'Check payment'}</button>{/if}
      </div>
    {:else if trustedMints.length === 0}
      <p class="rounded-xl bg-amber-500/10 p-3 text-sm text-amber-300">Add or trust a mint on the wallet page before receiving over Lightning.</p>
    {:else}
      <form class="grid gap-4" on:submit|preventDefault={() => void createInvoice()}>
        <label class="grid gap-1.5" for="wallet-receive-mint"><span class="text-sm font-600">Mint</span><select id="wallet-receive-mint" bind:value={mintUrl} disabled={pending} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-sm disabled:opacity-60">{#each trustedMints as mint (mint.url)}<option value={mint.url}>{mint.name}</option>{/each}</select></label>
        <label class="grid gap-1.5" for="wallet-receive-amount"><span class="text-sm font-600">Amount in bits</span><input id="wallet-receive-amount" data-testid="wallet-receive-amount" type="number" inputmode="numeric" min="1" step="1" bind:value={amount} disabled={pending} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 outline-none focus:border-violet-400 disabled:opacity-60" /></label>
        <button data-testid="wallet-create-invoice" type="submit" disabled={!readPositiveBits(amount) || !mintUrl || pending} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-45">{pending ? 'Creating…' : 'Create invoice'}</button>
      </form>
    {/if}
  {:else if received}
    <div class="grid justify-items-center gap-4 py-4 text-center">
      <span class="grid h-14 w-14 place-items-center rounded-full bg-emerald-500/15 text-emerald-400"><IrisIcon name="check" size={27} /></span>
      <div><h3 class="text-lg font-700">Token received</h3><p class="text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">{formatBits(received.amountBits)} added from {new URL(received.mintUrl).hostname}.</p></div>
    </div>
  {:else if tokenPreview && !tokenPreview.trusted}
    <div class="grid gap-4">
      <div class="rounded-xl bg-amber-500/10 p-4 text-sm text-amber-300">
        <h3 class="font-700">Trust this mint?</h3>
        <p class="mt-1 break-all text-xs leading-5">{tokenPreview.mintUrl}</p>
        <p class="mt-2 leading-5">The mint backs this token and will become eligible for wallet payments. Only continue if you trust its operator.</p>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <button type="button" class="min-h-11 rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] font-700" on:click={() => { tokenPreview = null; previewedToken = ''; }}>Cancel</button>
        <button data-testid="wallet-trust-token-mint" type="button" disabled={pending} class="min-h-11 rounded-full bg-[var(--iris-solid)] px-4 font-700 text-[var(--iris-on-solid)] disabled:opacity-45" on:click={() => void receiveToken(true)}>{pending ? 'Receiving…' : 'Trust & receive'}</button>
      </div>
    </div>
  {:else}
    <form class="grid gap-4" on:submit|preventDefault={() => void receiveToken(false)}>
      <label class="grid gap-1.5" for="wallet-receive-token"><span class="text-sm font-600">Cashu token</span><textarea id="wallet-receive-token" data-testid="wallet-receive-token" rows="6" maxlength={MAX_TOKEN_LENGTH} disabled={pending} value={token} placeholder="cashuA…" class="resize-none rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs outline-none focus:border-violet-400 disabled:opacity-60" on:input={(event) => setToken(event.currentTarget.value)}></textarea></label>
      <button type="button" disabled={pending} class="flex items-center justify-center gap-2 rounded-xl border border-[rgb(var(--iris-text-rgb)/0.14)] py-2.5 text-sm font-700 disabled:opacity-50" on:click={() => scannerOpen = true}><IrisIcon name="qr" size={18} /> Scan token</button>
      <button data-testid="wallet-receive-token-submit" type="submit" disabled={!token.trim() || pending} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-45">{pending ? 'Receiving…' : 'Receive token'}</button>
    </form>
  {/if}
  {#if error}<p role="alert" class="mt-4 rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{error}</p>{/if}
</WalletDialogShell>

<WalletQrScanner open={scannerOpen} onClose={() => scannerOpen = false} onScan={setToken} />
