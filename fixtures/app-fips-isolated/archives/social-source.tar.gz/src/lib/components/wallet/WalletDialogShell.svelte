<script lang="ts">
  import { tick } from 'svelte';
  import ModalShell from '../ModalShell.svelte';
  import IrisIcon from '../IrisIcon.svelte';

  export let open = false;
  export let title: string;
  export let titleId: string;
  export let testId: string;
  export let onClose: () => void = () => undefined;

  let dialog: HTMLDivElement | null = null;
  let previousOpen = false;
  let returnFocus: HTMLElement | null = null;

  $: if (open !== previousOpen) {
    previousOpen = open;
    if (open) {
      returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      void tick().then(() => {
        const initial = dialog?.querySelector<HTMLElement>('[data-dialog-initial-focus]');
        (initial ?? dialog)?.focus({ preventScroll: true });
      });
    } else {
      const target = returnFocus;
      returnFocus = null;
      void tick().then(() => {
        if (target?.isConnected && !target.closest('[inert]')) target.focus({ preventScroll: true });
      });
    }
  }

  function trapFocus(event: KeyboardEvent): void {
    if (event.key !== 'Tab' || !dialog) return;
    const focusable = [...dialog.querySelectorAll<HTMLElement>(
      'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])',
    )].filter((element) => element.getClientRects().length > 0);
    if (focusable.length === 0) {
      event.preventDefault();
      dialog.focus();
      return;
    }
    const first = focusable[0]!;
    const last = focusable.at(-1)!;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
</script>

<ModalShell
  {open}
  {onClose}
  shellClass="items-center justify-center p-4 sm:p-5"
  contentClass="max-h-[min(92dvh,48rem)] w-full max-w-[34rem] overflow-y-auto"
  backdropClass="bg-black/72 backdrop-blur-sm"
>
  <div
    bind:this={dialog}
    id={testId}
    data-testid={testId}
    role="dialog"
    aria-modal="true"
    aria-labelledby={titleId}
    tabindex="-1"
    on:keydown={trapFocus}
    class="rounded-3xl border border-[rgb(var(--iris-text-rgb)/0.1)] bg-[var(--iris-surface)] text-[rgb(var(--iris-text-rgb))] shadow-2xl"
  >
    <header class="flex items-center justify-between border-b border-[rgb(var(--iris-text-rgb)/0.08)] px-5 py-4">
      <h2 id={titleId} class="text-xl font-700">{title}</h2>
      <button
        data-dialog-initial-focus
        type="button"
        aria-label={`Close ${title.toLowerCase()}`}
        class="grid h-10 w-10 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.65)] transition hover:bg-[var(--iris-surface-hover)]"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={21} />
      </button>
    </header>
    <div class="p-5"><slot></slot></div>
  </div>
</ModalShell>
