<script lang="ts">
  import { nwcWallet } from '../../nwcWallet';
  import NwcInvoicePayment from './NwcInvoicePayment.svelte';
  import { parseBolt11Millisats } from '../../bolt11';
  import { wallet } from '../../walletStore';
  import {
    WalletPaymentError,
    type WalletBalance,
    type WalletMint,
    type WalletPaymentQuote,
    type WalletPaymentResult,
    type WalletTokenResult,
  } from '../../walletTypes';
  import IrisIcon from '../IrisIcon.svelte';
  import WalletDialogShell from './WalletDialogShell.svelte';
  import WalletQr from './WalletQr.svelte';
  import WalletQrScanner from './WalletQrScanner.svelte';
  import { createPaymentIntentId, errorMessage, formatBits, readPositiveBits, stripPaymentScheme } from './walletUi';

  export let open = false;
  export let mints: WalletMint[] = [];
  export let balances: WalletBalance[] = [];
  export let onClose: () => void = () => undefined;

  let mode: 'lightning' | 'cashu' = 'lightning';
  let invoice = '';
  let paymentIntentId = createPaymentIntentId();
  let preferredMintUrl = '';
  let sendMintUrl = '';
  let sendAmount = '';
  let memo = '';
  let pending = false;
  let nwcPaymentPending = false;
  let error = '';
  let paymentWarning = '';
  let reconciliationNotice = '';
  let paymentQuote: WalletPaymentQuote | null = null;
  let paymentResult: WalletPaymentResult | null = null;
  let tokenResult: WalletTokenResult | null = null;
  let scannerOpen = false;
  let wasOpen = false;
  let dialogSession = 0;
  let replaceTokenConfirm = false;
  const MAX_INVOICE_LENGTH = 20_000;

  $: trustedMints = mints.filter((mint) => mint.trusted);
  $: spendableBalances = balances.filter((balance) => balance.spendableBits > 0);
  $: if (!sendMintUrl && spendableBalances[0]) sendMintUrl = spendableBalances[0].mintUrl;
  $: parsedMillisats = parseBolt11Millisats(stripPaymentScheme(invoice));
  $: invoiceBits = parsedMillisats !== null && parsedMillisats % 1_000 === 0
    ? parsedMillisats / 1_000
    : null;
  $: syncOpenState(open);
  $: if (!open) scannerOpen = false;

  function syncOpenState(nextOpen: boolean): void {
    if (nextOpen === wasOpen) return;
    const opening = nextOpen && !wasOpen;
    wasOpen = nextOpen;
    scannerOpen = false;
    if (opening) dialogSession += 1;
    if (!nextOpen && paymentQuote && !pending) void cancelPaymentQuote();
    if (opening && !pending && !tokenResult && !paymentQuote && !paymentWarning && paymentResult?.status !== 'pending') reset();
  }

  function reset(): void {
    mode = 'lightning';
    invoice = '';
    paymentIntentId = createPaymentIntentId();
    preferredMintUrl = '';
    sendMintUrl = spendableBalances[0]?.mintUrl ?? '';
    sendAmount = '';
    memo = '';
    pending = false;
    error = '';
    paymentWarning = '';
    reconciliationNotice = '';
    paymentQuote = null;
    paymentResult = null;
    tokenResult = null;
    scannerOpen = false;
    replaceTokenConfirm = false;
  }

  function setInvoice(value: string): void {
    if (pending || paymentWarning) return;
    const nextInvoice = stripPaymentScheme(value);
    if (nextInvoice.length > MAX_INVOICE_LENGTH) {
      invoice = '';
      error = 'Lightning invoice is too long.';
      return;
    }
    invoice = nextInvoice;
    paymentIntentId = createPaymentIntentId();
    paymentQuote = null;
    paymentResult = null;
    error = '';
    paymentWarning = '';
  }

  function selectMode(nextMode: typeof mode): void {
    if (pending || paymentWarning) return;
    mode = nextMode;
    error = '';
  }

  async function prepareLightning(): Promise<void> {
    if (pending || paymentWarning || invoiceBits === null) return;
    pending = true;
    scannerOpen = false;
    error = '';
    paymentWarning = '';
    reconciliationNotice = '';
    const submittedInvoice = stripPaymentScheme(invoice);
    const submittedBits = invoiceBits;
    const submittedIntentId = paymentIntentId;
    const submittedMintUrl = preferredMintUrl;
    const submittedSession = dialogSession;
    try {
      const result = await wallet.preparePayment(
        submittedInvoice,
        submittedBits,
        submittedIntentId,
        submittedMintUrl || undefined,
      );
      if (result.status === 'prepared') {
        if (!open || submittedSession !== dialogSession) {
          try {
            await wallet.cancelOperation(result.operationId, 'melt');
            void wallet.refresh();
            if (open) reset();
          } catch (cancelError) {
            paymentQuote = result;
            error = `Payment review closed, but its reservation could not be released. ${errorMessage(cancelError)}`;
          }
          return;
        }
        paymentQuote = result;
        paymentResult = null;
      } else {
        paymentQuote = null;
        paymentResult = result;
        void wallet.refresh();
      }
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function executeLightning(): Promise<void> {
    if (!paymentQuote || pending) return;
    pending = true;
    error = '';
    paymentWarning = '';
    try {
      paymentResult = await wallet.executePayment(paymentIntentId);
      paymentQuote = null;
      void wallet.refresh();
    } catch (nextError) {
      if (nextError instanceof WalletPaymentError && nextError.paymentStarted) {
        paymentQuote = null;
        paymentWarning = 'Payment status may be pending. Do not pay this invoice again; reopen the wallet to reconcile it.';
      }
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function cancelPaymentQuote(): Promise<void> {
    const quote = paymentQuote;
    if (!quote || pending) return;
    pending = true;
    error = '';
    try {
      await wallet.cancelOperation(quote.operationId, 'melt');
      if (paymentQuote?.operationId === quote.operationId) {
        paymentQuote = null;
        paymentIntentId = createPaymentIntentId();
      }
      await wallet.refresh();
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function refreshPayment(): Promise<void> {
    if (!paymentResult || pending) return;
    pending = true;
    error = '';
    try {
      paymentResult = await wallet.refreshPayment(paymentResult.operationId);
      await wallet.refresh();
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function sendCashu(): Promise<void> {
    const amountBits = readPositiveBits(sendAmount);
    if (!amountBits || !sendMintUrl || pending || paymentWarning) return;
    pending = true;
    error = '';
    reconciliationNotice = '';
    try {
      tokenResult = await wallet.sendToken(sendMintUrl, amountBits, memo.trim() || undefined);
      void wallet.refresh();
    } catch (nextError) {
      if (nextError instanceof WalletPaymentError && nextError.paymentStarted) {
        paymentWarning = 'Token creation status is uncertain. Do not create another token. Reopen the wallet and reclaim the pending send from Activity if no token appears.';
        void wallet.refresh();
      }
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  async function reconcileAndReset(): Promise<void> {
    if (!paymentWarning || pending) return;
    const previousMode = mode;
    pending = true;
    error = '';
    try {
      await wallet.initialize();
      reset();
      mode = previousMode;
      reconciliationNotice = 'Wallet state refreshed. Before another send, close this dialog, inspect Activity, and reclaim any pending token send that did not produce a token.';
    } catch (nextError) {
      error = `Wallet state could not be refreshed. ${errorMessage(nextError)}`;
    } finally {
      pending = false;
    }
  }

  async function reclaimToken(): Promise<void> {
    if (!tokenResult || pending) return;
    pending = true;
    error = '';
    try {
      await wallet.cancelOperation(tokenResult.operationId, 'send');
      await wallet.refresh();
      tokenResult = null;
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  function createAnotherToken(): void {
    if (!replaceTokenConfirm) {
      replaceTokenConfirm = true;
      return;
    }
    reset();
    mode = 'cashu';
  }
</script>

<WalletDialogShell {open} title="Send" titleId="wallet-send-title" testId="wallet-send-dialog" onClose={() => { if (!nwcPaymentPending) onClose(); }}>
  <div class="mb-5 grid grid-cols-2 rounded-xl bg-[var(--iris-surface-subtle)] p-1" role="group" aria-label="Send method">
    <button type="button" aria-pressed={mode === 'lightning'} disabled={pending || nwcPaymentPending || Boolean(paymentWarning)} class={`rounded-lg px-3 py-2 text-sm font-700 disabled:opacity-50 ${mode === 'lightning' ? 'bg-[var(--iris-surface-raised)] shadow' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectMode('lightning')}>Lightning</button>
    <button type="button" aria-pressed={mode === 'cashu'} disabled={pending || nwcPaymentPending || Boolean(paymentWarning)} class={`rounded-lg px-3 py-2 text-sm font-700 disabled:opacity-50 ${mode === 'cashu' ? 'bg-[var(--iris-surface-raised)] shadow' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectMode('cashu')}>Cashu token</button>
  </div>

  {#if mode === 'lightning'}
    {#if !$nwcWallet.loaded || $nwcWallet.error}
      <p class="text-sm" role="status">{$nwcWallet.error ?? 'Loading payment wallet…'}</p>
    {:else if $nwcWallet.enabled && !paymentQuote && !paymentResult && !paymentWarning}
      <NwcInvoicePayment bind:pending={nwcPaymentPending} />
    {:else if paymentResult}
      <div class="grid gap-4 text-center">
        <span class={`mx-auto grid h-14 w-14 place-items-center rounded-full text-2xl ${paymentResult.status === 'paid' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-amber-500/15 text-amber-400'}`}><IrisIcon name={paymentResult.status === 'paid' ? 'check' : 'refresh-ccw-01'} size={26} /></span>
        <div><h3 class="text-lg font-700">{paymentResult.status === 'paid' ? 'Payment sent' : 'Payment pending'}</h3><p class="text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">{formatBits(paymentResult.amountBits)} · fee {formatBits(paymentResult.feeBits)}</p></div>
        {#if paymentResult.status === 'pending'}<button type="button" disabled={pending} class="mx-auto rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] px-5 py-2.5 font-700" on:click={() => void refreshPayment()}>{pending ? 'Checking…' : 'Check status'}</button>{/if}
      </div>
    {:else if paymentQuote}
      <div class="grid gap-4">
        <div class="text-center"><h3 class="text-lg font-700">Review payment</h3><p class="mt-1 text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">The final fee may be lower than this reserved maximum.</p></div>
        <dl class="grid gap-2 rounded-xl bg-[var(--iris-surface-subtle)] p-4 text-sm">
          <div class="flex justify-between gap-4"><dt>Invoice</dt><dd class="font-700">{formatBits(paymentQuote.amountBits)}</dd></div>
          <div class="flex justify-between gap-4"><dt>Maximum fee</dt><dd class="font-700">{formatBits(paymentQuote.feeBits)}</dd></div>
          <div class="flex justify-between gap-4 border-t border-[rgb(var(--iris-text-rgb)/0.1)] pt-2"><dt class="font-700">Maximum total</dt><dd class="font-800">{formatBits(paymentQuote.totalBits)}</dd></div>
        </dl>
        <div class="grid grid-cols-2 gap-3"><button type="button" disabled={pending} class="min-h-12 rounded-full border border-[rgb(var(--iris-text-rgb)/0.15)] font-700 disabled:opacity-50" on:click={() => void cancelPaymentQuote()}>{pending ? 'Cancelling…' : 'Back'}</button><button data-testid="wallet-confirm-payment" type="button" disabled={pending} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-4 font-700 text-[var(--iris-on-solid)] disabled:opacity-50" on:click={() => void executeLightning()}>{pending ? 'Paying…' : 'Confirm & pay'}</button></div>
      </div>
    {:else}
      <form class="grid gap-4" on:submit|preventDefault={() => void prepareLightning()}>
        <label class="grid gap-1.5" for="wallet-lightning-invoice"><span class="text-sm font-600">Lightning invoice</span><textarea id="wallet-lightning-invoice" data-testid="wallet-lightning-invoice" rows="4" maxlength={MAX_INVOICE_LENGTH} disabled={pending || Boolean(paymentWarning)} value={invoice} placeholder="lnbc…" class="resize-none rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs outline-none focus:border-violet-400 disabled:opacity-60" on:input={(event) => setInvoice(event.currentTarget.value)}></textarea></label>
        <button type="button" disabled={pending || Boolean(paymentWarning)} class="flex items-center justify-center gap-2 rounded-xl border border-[rgb(var(--iris-text-rgb)/0.14)] py-2.5 text-sm font-700 disabled:opacity-50" on:click={() => scannerOpen = true}><IrisIcon name="qr" size={18} /> Scan invoice</button>
        {#if invoice}
          <p class={`rounded-xl px-3 py-2 text-sm ${invoiceBits === null ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'}`}>{invoiceBits === null ? 'Enter a valid amount-bearing Lightning invoice.' : `Invoice amount: ${formatBits(invoiceBits)}`}</p>
        {/if}
        {#if trustedMints.length > 1}
          <label class="grid gap-1.5" for="wallet-payment-mint"><span class="text-sm font-600">Preferred mint</span><select id="wallet-payment-mint" bind:value={preferredMintUrl} disabled={pending || Boolean(paymentWarning)} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-sm disabled:opacity-60"><option value="">Best available balance</option>{#each trustedMints as mint (mint.url)}<option value={mint.url}>{mint.name}</option>{/each}</select></label>
        {/if}
        <button data-testid="wallet-pay-invoice" type="submit" disabled={invoiceBits === null || pending || Boolean(paymentWarning)} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-45">{pending ? 'Checking fee…' : paymentWarning ? 'Refresh before retrying' : invoiceBits === null ? 'Enter invoice' : `Review ${formatBits(invoiceBits)}`}</button>
      </form>
    {/if}
  {:else if tokenResult}
    <div class="grid gap-4">
      <div class="text-center"><h3 class="text-lg font-700">Token ready</h3><p class="text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">Share it once. Reclaim it if the recipient does not redeem it.</p></div>
      <WalletQr value={tokenResult.token} label="Cashu token" />
      <div class="flex flex-wrap justify-center gap-4 text-sm font-700"><button type="button" disabled={pending} class="text-red-400" on:click={() => void reclaimToken()}>{pending ? 'Reclaiming…' : 'Reclaim unspent token'}</button><button type="button" disabled={pending} class="text-violet-400" on:click={createAnotherToken}>{replaceTokenConfirm ? 'I saved it — continue' : 'Create another token'}</button>{#if replaceTokenConfirm}<button type="button" class="text-[rgb(var(--iris-text-rgb)/0.58)]" on:click={() => replaceTokenConfirm = false}>Keep this token</button><p class="w-full text-center text-xs font-400 text-amber-300">The token code will no longer be shown here. Save or share it before continuing.</p>{/if}</div>
    </div>
  {:else}
    <form class="grid gap-4" on:submit|preventDefault={() => void sendCashu()}>
      {#if spendableBalances.length === 0}<p class="rounded-xl bg-amber-500/10 p-3 text-sm text-amber-300">Receive funds before creating a Cashu token.</p>{:else}
        <label class="grid gap-1.5" for="wallet-send-mint"><span class="text-sm font-600">Mint balance</span><select id="wallet-send-mint" bind:value={sendMintUrl} disabled={Boolean(paymentWarning)} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 text-sm disabled:opacity-60">{#each spendableBalances as balance (balance.mintUrl)}<option value={balance.mintUrl}>{mints.find((mint) => mint.url === balance.mintUrl)?.name ?? balance.mintUrl} · {formatBits(balance.spendableBits)}</option>{/each}</select></label>
        <label class="grid gap-1.5" for="wallet-send-amount"><span class="text-sm font-600">Amount in bits</span><input id="wallet-send-amount" data-testid="wallet-send-amount" type="number" inputmode="numeric" min="1" step="1" bind:value={sendAmount} disabled={Boolean(paymentWarning)} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 outline-none focus:border-violet-400 disabled:opacity-60" /></label>
        <label class="grid gap-1.5" for="wallet-send-memo"><span class="text-sm font-600">Memo <span class="font-400 text-[rgb(var(--iris-text-rgb)/0.48)]">optional</span></span><input id="wallet-send-memo" bind:value={memo} maxlength="120" disabled={Boolean(paymentWarning)} class="rounded-xl border border-[rgb(var(--iris-text-rgb)/0.12)] bg-[var(--iris-surface-subtle)] px-3 py-2.5 outline-none focus:border-violet-400 disabled:opacity-60" /></label>
        <button data-testid="wallet-create-token" type="submit" disabled={!readPositiveBits(sendAmount) || !sendMintUrl || pending || Boolean(paymentWarning)} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-45">{pending ? 'Creating…' : 'Create token'}</button>
      {/if}
    </form>
  {/if}
  {#if paymentWarning}
    <div role="alert" class="mt-4 grid gap-3 rounded-xl bg-amber-500/10 p-3 text-sm text-amber-300">
      <p>{paymentWarning}</p>
      <p>Refreshing only reloads wallet state; it never retries or cancels the operation. Inspect Activity and reclaim any pending token send before sending again.</p>
      <button data-testid="wallet-reconcile-reset" type="button" disabled={pending} class="justify-self-start rounded-full border border-amber-300/35 px-4 py-2 font-700 disabled:opacity-50" on:click={() => void reconcileAndReset()}>{pending ? 'Refreshing…' : 'Refresh wallet & reset form'}</button>
    </div>
  {/if}
  {#if reconciliationNotice}<p data-testid="wallet-reconciliation-notice" class="mt-4 rounded-xl bg-emerald-500/10 p-3 text-sm text-emerald-300">{reconciliationNotice}</p>{/if}
  {#if error}<p role="alert" class="mt-4 rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{error}</p>{/if}
</WalletDialogShell>

<WalletQrScanner open={scannerOpen} onClose={() => scannerOpen = false} onScan={setInvoice} />
