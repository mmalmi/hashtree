<script lang="ts">
  import { parseBolt11Millisats } from '../../bolt11';
  import { nwcWallet, payWithConnectedNwc } from '../../nwcWallet';
  import { errorMessage, formatBits, stripPaymentScheme } from './walletUi';
  export let pending = false;
  let invoice = '';
  let review: { invoice: string; bits: number; walletName: string; connectionId: string } | null = null;
  let paid = false;
  let error = '';
  $: millisats = parseBolt11Millisats(stripPaymentScheme(invoice));
  $: bits = millisats !== null && millisats % 1_000 === 0 ? millisats / 1_000 : null;
  async function pay(): Promise<void> {
    if (!review || pending) {return;}
    pending = true; error = '';
    try {
      if (!await payWithConnectedNwc(review.invoice, review.bits, review.connectionId)) {throw new Error('Wallet connection changed. Review the payment again.');}
      paid = true;
    } catch (cause) {error = errorMessage(cause);}
    finally {pending = false; review = null;}
  }
</script>

{#if paid}
  <div data-testid="nwc-payment-sent" class="grid gap-2 text-center"><h3 class="text-lg font-700">Payment sent</h3><p>{bits === null ? '' : formatBits(bits)}</p></div>
{:else if review}
  <div data-testid="nwc-payment-review" class="grid gap-4">
    <h3 class="text-center text-lg font-700">Pay {formatBits(review.bits)}</h3>
    <p class="text-center text-sm">From {review.walletName}. Your wallet may charge a routing fee.</p>
    <button data-testid="nwc-confirm-payment" type="button" disabled={pending} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-50" on:click={() => void pay()}>{pending ? 'Paying…' : 'Confirm payment'}</button>
    <button type="button" disabled={pending} class="text-sm" on:click={() => review = null}>Back</button>
  </div>
{:else}
  <form class="grid gap-4" on:submit|preventDefault={() => { if (bits !== null && $nwcWallet.name && $nwcWallet.connectionId && !error) review = { invoice: stripPaymentScheme(invoice), bits, walletName: $nwcWallet.name, connectionId: $nwcWallet.connectionId }; }}>
    <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">Pay with {$nwcWallet.name}</p>
    <label for="nwc-payment-invoice" class="grid gap-2 text-sm">Lightning invoice<textarea id="nwc-payment-invoice" data-testid="wallet-lightning-invoice" rows="4" maxlength="20000" value={invoice} class="resize-none rounded-xl bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs" on:input={(event) => { invoice = event.currentTarget.value; error = ''; }}></textarea></label>
    <button data-testid="wallet-pay-invoice" type="submit" disabled={bits === null || Boolean(error)} class="min-h-12 rounded-full bg-[var(--iris-solid)] px-5 font-700 text-[var(--iris-on-solid)] disabled:opacity-50">{bits === null ? 'Enter invoice' : `Review ${formatBits(bits)}`}</button>
  </form>
{/if}
{#if error}<p role="alert" class="mt-4 text-sm text-red-500">{error}</p>{/if}
