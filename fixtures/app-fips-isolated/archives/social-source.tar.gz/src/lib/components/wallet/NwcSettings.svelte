<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { nwcWallet, connectNwcWallet, disconnectNwcWallet, revealNwcWallet, setNwcWalletEnabled } from '../../nwcWallet';
  import { errorMessage } from './walletUi';
  export let active = false;
  let name = '';
  let connection = '';
  let revealed = '';
  let pending = false;
  let error = '';
  let revealVersion = 0;
  function hideSecrets(): void {revealVersion += 1; connection = ''; revealed = '';}
  $: if (!active) hideSecrets();
  onMount(() => {
    const onVisibility = () => {if (document.visibilityState === 'hidden') hideSecrets();};
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', hideSecrets);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', hideSecrets);
    };
  });
  onDestroy(hideSecrets);

  async function connect(): Promise<void> {
    if (pending) {return;}
    pending = true;
    error = '';
    const submitted = connection;
    connection = '';
    try {await connectNwcWallet(submitted, name); name = '';}
    catch (cause) {error = errorMessage(cause);}
    finally {pending = false;}
  }
  async function change(action: () => Promise<void>): Promise<void> {
    if (pending) {return;}
    pending = true; error = ''; revealed = ''; revealVersion += 1;
    try {await action();} catch (cause) {error = errorMessage(cause);} finally {pending = false;}
  }
  async function reveal(): Promise<void> {
    if (revealed) {revealed = ''; revealVersion += 1; return;}
    const version = ++revealVersion;
    try {
      const value = await revealNwcWallet();
      if (active && document.visibilityState !== 'hidden' && version === revealVersion) {revealed = value;}
    } catch (cause) {error = errorMessage(cause);}
  }
</script>

<section data-testid="nwc-settings" class="overflow-hidden rounded-xl bg-[var(--iris-surface)] shadow-sm">
  <header class="border-b border-[rgb(var(--iris-text-rgb)/0.1)] px-4 py-3"><h2 class="font-700">Nostr Wallet Connect</h2></header>
  <div class="grid gap-4 p-4">
    {#if $nwcWallet.name}
      <label class="flex items-center justify-between gap-4"><span><span class="block font-700">{$nwcWallet.name}</span><span class="text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">Use for Lightning payments and zaps</span></span><input data-testid="nwc-enabled" type="checkbox" checked={$nwcWallet.enabled} disabled={pending} on:change={(event) => void change(() => setNwcWalletEnabled(event.currentTarget.checked))} /></label>
      <div class="flex gap-4 text-sm font-700"><button data-testid="nwc-reveal" type="button" disabled={pending} on:click={() => void reveal()}>{revealed ? 'Hide connection' : 'Reveal connection'}</button><button data-testid="nwc-remove" type="button" disabled={pending} class="text-red-500" on:click={() => void change(disconnectNwcWallet)}>Remove connection</button></div>
      {#if revealed}<p class="text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">Keep this secret. Anyone with it can use the wallet permissions you granted.</p><textarea data-testid="nwc-revealed-connection" readonly value={revealed} rows="4" class="w-full resize-none rounded-xl bg-[var(--iris-surface-subtle)] p-3 font-mono text-xs"></textarea>{/if}
    {:else}
      <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">Connect your Lightning wallet with its Nostr Wallet Connect link. The connection stays in this browser.</p>
      <form class="grid gap-3" on:submit|preventDefault={() => void connect()}>
        <label class="grid gap-1 text-sm" for="nwc-name">Wallet name<input id="nwc-name" bind:value={name} placeholder="Lightning wallet" maxlength="80" disabled={pending} class="rounded-xl bg-[var(--iris-surface-subtle)] px-3 py-2.5" /></label>
        <label class="grid gap-1 text-sm" for="nwc-connection">Connection link<input id="nwc-connection" data-testid="nwc-connection" type="password" autocomplete="off" spellcheck="false" bind:value={connection} placeholder="nostr+walletconnect://…" maxlength="8192" disabled={pending} class="rounded-xl bg-[var(--iris-surface-subtle)] px-3 py-2.5" /></label>
        <button data-testid="nwc-connect" type="submit" disabled={pending || !connection.trim()} class="justify-self-start rounded-full bg-[var(--iris-solid)] px-5 py-2.5 text-sm font-700 text-[var(--iris-on-solid)] disabled:opacity-50">{pending ? 'Connecting…' : 'Connect wallet'}</button>
      </form>
    {/if}
    {#if error}<p role="alert" class="text-sm text-red-500">{error}</p>{/if}
  </div>
</section>
