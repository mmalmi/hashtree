<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { DEFAULT_SUGGESTED_FOLLOWS_PUBKEY } from '../config';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import { preparePostSearchSuggestions } from '../localPostSearch';
  import { resolveConfiguredEventIndexRoot, streamForYouFeed } from '../nostrIndex';
  import { loadSocialGraphFrontier } from '../socialGraphFrontier';
  import { socialDataPlane } from '../socialDataPlane';
  import ProfileSearchSheet from './ProfileSearchSheet.svelte';

  export let query = '';
  export let active = true;
  export let initialTab: 'people' | 'posts' = 'people';
  export let profilesByPubkey: Map<string, ProfileRecord> = new Map();
  export let profileRecords: ProfileRecord[] = [];
  export let loading = false;
  export let localPostSearchEvents: RawEvent[] = [];
  export let mutedPubkeys: Set<string> = new Set();
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let onQueryChange: (value: string) => void = () => undefined;
  export let onTabChange: (tab: 'people' | 'posts') => void = () => undefined;
  export let onOpenProfile: ((pubkey: string) => void) | null = null;
  export let onOpenPost: ((event: RawEvent) => void) | null = null;
  export let onOpenThread: ((ref: string) => void) | null = null;

  let starterPubkeys: string[] = [];
  let suggestedPosts: RawEvent[] = [];
  let suggestionsLoading = false;
  let discoveryKey = '';
  let loadedDiscoveryKey = '';
  let discoveryRequest = 0;

  $: suggestedPubkeys = viewerFollows.size > 0 ? [...viewerFollows] : starterPubkeys;
  $: updateDiscovery(active && !query.trim() && initialTab === 'posts', viewerPubkey, viewerFollows);

  onMount(() => {
    let mounted = true;
    void loadSocialGraphFrontier().then((pubkeys) => {
      if (mounted) { starterPubkeys = pubkeys; }
    });
    const unsubscribe = socialDataPlane.subscribe(() => {
      suggestedPosts = socialDataPlane.filterVisibleExternalEvents(suggestedPosts);
    });
    return () => { mounted = false; unsubscribe(); };
  });
  onDestroy(() => { discoveryRequest += 1; });

  function updateDiscovery(enabled: boolean, viewer: string | null, follows: Set<string>): void {
    const owner = viewer ?? DEFAULT_SUGGESTED_FOLLOWS_PUBKEY;
    const key = `${owner}:${[...follows].sort().join(',')}`;
    if (key !== discoveryKey) {
      discoveryRequest += 1;
      discoveryKey = key;
      loadedDiscoveryKey = '';
      suggestedPosts = [];
      suggestionsLoading = false;
    }
    if (!enabled) {
      discoveryRequest += 1;
      suggestionsLoading = false;
      return;
    }
    if (suggestionsLoading || loadedDiscoveryKey === key) { return; }
    suggestionsLoading = true;
    void loadSuggestions(owner, [...follows], key, ++discoveryRequest);
  }

  async function loadSuggestions(owner: string, follows: string[], key: string, request: number): Promise<void> {
    try {
      const root = await resolveConfiguredEventIndexRoot();
      if (!root || request !== discoveryRequest) { return; }
      for await (const feed of streamForYouFeed(root, owner, 80, {
        knownViewerFollows: follows,
        includeProfiles: false,
        includeReplies: false,
      })) {
        if (request !== discoveryRequest) { return; }
        const posts = await preparePostSearchSuggestions(feed.notes);
        if (request !== discoveryRequest) { return; }
        suggestedPosts = socialDataPlane.filterVisibleExternalEvents(posts);
      }
    } catch (error) {
      console.warn('Failed to load search suggestions', error);
    } finally {
      if (request === discoveryRequest) {
        loadedDiscoveryKey = key;
        suggestionsLoading = false;
      }
    }
  }
</script>

<section
  data-testid="search-page"
  class="min-h-[calc(100dvh-8rem)] pb-4 md:min-h-[calc(100dvh-4rem)]"
>
  <ProfileSearchSheet
    open={true}
    {active}
    presentation="page"
    {initialTab}
    {query}
    {profilesByPubkey}
    {profileRecords}
    {suggestedPubkeys}
    {suggestedPosts}
    {suggestionsLoading}
    {loading}
    {localPostSearchEvents}
    {mutedPubkeys}
    {viewerPubkey}
    {onQueryChange}
    {onTabChange}
    {onOpenProfile}
    {onOpenPost}
    {onOpenThread}
  />
</section>
