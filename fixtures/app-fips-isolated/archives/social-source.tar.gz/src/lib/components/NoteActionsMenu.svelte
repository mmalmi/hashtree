<script lang="ts">
  import { onMount } from 'svelte';
  import ModalShell from './ModalShell.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import type { RawEvent } from '../nostr';
  import { accountsStore } from '../accounts';
  import { canSignAccount } from '../accountSigner';
  import ReportPostDialog from './ReportPostDialog.svelte';
  import ConfirmDialog from './ConfirmDialog.svelte';

  export let event: RawEvent;
  export let onQuote: (() => void) | null = null;
  export let onShowReactions: (() => void) | null = null;
  export let onCopyLink: (() => void) | null = null;
  export let onCopyEventId: (() => void) | null = null;
  export let onRebroadcast: (() => void) | null = null;
  export let onDelete: (() => void) | null = null;
  export let rebroadcastPending = false;
  export let authorLabel = '';
  export let muted = false;
  export let mutePending = false;
  export let onToggleMute: ((nextMuted: boolean) => void) | null = null;
  export let isActive = true;

  let menuOpen = false;
  let rawOpen = false;
  let reportAccountPubkey: string | null = null;
  let muteConfirmOpen = false;
  let menuButton: HTMLButtonElement | null = null;
  let menuPanel: HTMLDivElement | null = null;
  let mounted = false;
  let menuListenersActive = false;

  $: rawJson = rawOpen ? JSON.stringify(event, null, 2) : '';
  $: activeAccount = $accountsStore.accounts.find(account => account.pubkey === $accountsStore.activeAccountPubkey) ?? null;
  $: if (reportAccountPubkey !== activeAccount?.pubkey) { reportAccountPubkey = null; }
  $: canModerateAuthor = Boolean(
    activeAccount && activeAccount.pubkey !== event.pubkey && canSignAccount(activeAccount),
  );
  $: muteAction = canModerateAuthor ? onToggleMute : null;
  $: authorHandle = `@${authorLabel || 'this user'}`.replace(/^@@/, '@');
  $: if (!muteAction) { muteConfirmOpen = false; }
  $: if (!isActive) {
    menuOpen = false;
    rawOpen = false;
    reportAccountPubkey = null;
    muteConfirmOpen = false;
  }

  function closeMenu(): void {
    menuOpen = false;
  }

  function toggleMenu(): void {
    menuOpen = !menuOpen;
  }

  function handleWindowClick(windowEvent: MouseEvent): void {
    if (!menuOpen) {
      return;
    }

    const target = windowEvent.target;
    if (!(target instanceof Node)) {
      return;
    }

    if (menuButton?.contains(target) || menuPanel?.contains(target)) {
      return;
    }

    closeMenu();
  }

  function handleWindowKeydown(windowEvent: KeyboardEvent): void {
    if (windowEvent.key !== 'Escape' || windowEvent.defaultPrevented) { return; }
    windowEvent.preventDefault();
    closeMenu();
    rawOpen = false;
  }

  function syncMenuListeners(active: boolean): void {
    if (active === menuListenersActive) {
      return;
    }
    menuListenersActive = active;
    if (active) {
      window.addEventListener('click', handleWindowClick);
      window.addEventListener('keydown', handleWindowKeydown);
    } else {
      window.removeEventListener('click', handleWindowClick);
      window.removeEventListener('keydown', handleWindowKeydown);
    }
  }

  $: if (mounted) {
    syncMenuListeners(menuOpen);
  }

  onMount(() => {
    mounted = true;
    syncMenuListeners(menuOpen);
    return () => syncMenuListeners(false);
  });

  function showRawData(): void {
    rawOpen = true;
    closeMenu();
  }

  async function copyRawData(): Promise<void> {
    try {
      await navigator.clipboard.writeText(rawJson);
    } catch (error) {
      console.warn('Failed to copy event JSON', error);
    }
  }

  function invoke(action: (() => void) | null): void {
    action?.();
    closeMenu();
  }

  function handleMuteClick(): void {
    closeMenu();
    if (muted) {
      muteAction?.(false);
    } else {
      muteConfirmOpen = true;
    }
  }
</script>

<div class="relative">
    <button
      bind:this={menuButton}
      data-testid="note-actions-button"
      data-note-no-thread-nav
      type="button"
      class={`inline-flex h-9 w-9 items-center justify-center rounded-full text-white/72 transition hover:bg-[#111111] hover:text-white ${
        menuOpen ? 'bg-[#111111] text-white' : 'bg-transparent'
      }`}
      aria-label={mutePending ? "Updating mute list" : "Post actions"}
      aria-busy={mutePending}
      aria-haspopup="menu"
      aria-expanded={menuOpen}
      on:click={toggleMenu}
    >
      <IrisIcon name={mutePending ? 'refresh-ccw-01' : 'dots-horizontal'} size={mutePending ? 18 : 24} className={mutePending ? 'animate-spin' : ''} />
    </button>

    {#if menuOpen}
      <div
        bind:this={menuPanel}
        data-testid="note-actions-menu"
        data-note-no-thread-nav
        role="menu"
        class="iris-dropdown-menu absolute right-0 top-11 z-20 w-[15rem] overflow-hidden rounded-[14px] p-2 shadow-[0_24px_80px_rgba(0,0,0,0.42)]"
      >
        {#if onQuote}
          <button
            data-testid="note-actions-quote"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
            on:click={() => {
              menuButton?.focus({ preventScroll: true });
              invoke(onQuote);
            }}
          >
            <IrisIcon name="edit" size={18} className="text-white/55" />
            Quote post
          </button>
        {/if}

        {#if onShowReactions}
          <button
            data-testid="note-actions-show-reactions"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
            on:click={() => invoke(onShowReactions)}
          >
            <IrisIcon name="heart-solid" size={18} className="text-white/55" />
            Show reactions
          </button>
        {/if}

        <button
          data-testid="note-actions-show-raw"
          type="button"
          class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
          on:click={showRawData}
        >
          <IrisIcon name="code-circle" size={18} className="text-white/55" />
          Show raw data
        </button>

        {#if onCopyLink}
          <button
            data-testid="note-actions-copy-link"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
            on:click={() => invoke(onCopyLink)}
          >
            <IrisIcon name="link" size={18} className="text-white/55" />
            Copy link
          </button>
        {/if}

        {#if onCopyEventId}
          <button
            data-testid="note-actions-copy-event-id"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
            on:click={() => invoke(onCopyEventId)}
          >
            <IrisIcon name="copy-solid" size={18} className="text-white/55" />
            Copy Event ID
          </button>
        {/if}

        {#if onRebroadcast}
          <button
            data-testid="note-actions-rebroadcast"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition disabled:cursor-default disabled:opacity-55"
            disabled={rebroadcastPending}
            on:click={() => invoke(onRebroadcast)}
          >
            <IrisIcon name="relay" size={18} className="text-white/55" />
            {rebroadcastPending ? 'Rebroadcasting…' : 'Rebroadcast'}
          </button>
        {/if}

        {#if muteAction}
          <button
            data-testid="note-actions-toggle-mute"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition disabled:cursor-default disabled:opacity-55"
            disabled={mutePending}
            on:click={handleMuteClick}
          >
            <IrisIcon name={muted ? 'signal-01' : 'mute'} size={18} className="text-white/55" />
            <span class="min-w-0 truncate">{muted ? 'Unmute' : 'Mute'} {authorHandle}</span>
          </button>
        {/if}

        {#if canModerateAuthor}
          <button
            data-testid="note-actions-report"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-white transition"
            on:click={() => { reportAccountPubkey = activeAccount?.pubkey ?? null; closeMenu(); }}
          >
            <IrisIcon name="block" size={18} className="text-white/55" />
            Report
          </button>
        {/if}

        {#if onDelete}
          <button
            data-testid="note-actions-delete"
            type="button"
            class="flex w-full items-center gap-3 px-3 py-3 text-left text-[0.94rem] text-red-300 transition hover:bg-red-400/10 hover:text-red-200"
            on:click={() => invoke(onDelete)}
          >
            <IrisIcon name="trash" size={18} />
            Delete
          </button>
        {/if}
      </div>
    {/if}
</div>

{#if reportAccountPubkey && activeAccount}
  <ReportPostDialog
    {event}
    account={activeAccount}
    onMute={muteAction && !muted ? () => muteAction?.(true) : null}
    onClose={() => { reportAccountPubkey = null; }}
  />
{/if}

{#if muteConfirmOpen && muteAction}
  <ConfirmDialog
    testId="note-mute-confirm"
    title={`Mute ${authorHandle}?`}
    message="Their posts will be hidden from your feeds."
    confirmLabel="Mute"
    onConfirm={() => muteAction?.(true)}
    onClose={() => { muteConfirmOpen = false; }}
  />
{/if}

{#if rawOpen}
  <ModalShell
    open
    onClose={() => {
      rawOpen = false;
    }}
    shellClass="items-center justify-center p-4 sm:p-6"
    contentClass="w-full max-w-2xl"
  >
  <section
    data-testid="note-raw-data-sheet"
    data-note-no-thread-nav
    class="rounded-[28px] iris-panel p-5 shadow-[0_24px_80px_rgba(0,0,0,0.35)]"
  >
    <div class="flex items-center justify-between gap-3">
      <div class="text-[1rem] font-700 text-white">Raw event</div>

      <div class="flex items-center gap-2">
        <button
          type="button"
          class="inline-flex h-10 items-center justify-center gap-2 rounded-full iris-neutral-button px-4 text-[0.88rem] font-600 text-white transition"
          on:click={() => void copyRawData()}
        >
          <IrisIcon name="copy-solid" size={17} className="text-white/65" />
          Copy JSON
        </button>

        <button
          type="button"
          class="inline-flex h-10 w-10 items-center justify-center rounded-full iris-neutral-button text-white transition"
          aria-label="Close raw event"
          on:click={() => {
            rawOpen = false;
          }}
        >
          <IrisIcon name="x-close" size={18} />
        </button>
      </div>
    </div>

    <div class="mt-4 overflow-hidden rounded-[24px] bg-[var(--iris-surface-subtle)]">
      <pre class="max-h-[70vh] overflow-auto px-4 py-4 text-[0.78rem] leading-6 text-white/72">{rawJson}</pre>
    </div>
  </section>
  </ModalShell>
{/if}
