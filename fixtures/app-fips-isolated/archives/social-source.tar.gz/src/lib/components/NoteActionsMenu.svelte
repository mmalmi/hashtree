<script lang="ts">
  import { onMount } from 'svelte';
  import ModalShell from './ModalShell.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import type { RawEvent } from '../nostr';
  import { accountsStore } from '../accounts';
  import { canSignAccount } from '../accountSigner';
  import ReportPostDialog from './ReportPostDialog.svelte';

  export let event: RawEvent;
  export let onQuote: (() => void) | null = null;
  export let onShowReactions: (() => void) | null = null;
  export let onCopyLink: (() => void) | null = null;
  export let onCopyEventId: (() => void) | null = null;
  export let onRebroadcast: (() => void) | null = null;
  export let onDelete: (() => void) | null = null;
  export let rebroadcastPending = false;
  export let isActive = true;

  let menuOpen = false;
  let rawOpen = false;
  let reportAccountPubkey: string | null = null;
  let menuButton: HTMLButtonElement | null = null;
  let menuPanel: HTMLDivElement | null = null;
  let mounted = false;
  let menuListenersActive = false;

  $: rawJson = rawOpen ? JSON.stringify(event, null, 2) : '';
  $: activeAccount = $accountsStore.accounts.find(account => account.pubkey === $accountsStore.activeAccountPubkey) ?? null;
  $: if (reportAccountPubkey !== activeAccount?.pubkey) { reportAccountPubkey = null; }
  $: if (!isActive) {
    menuOpen = false;
    rawOpen = false;
    reportAccountPubkey = null;
  }

  function closeMenu(): void {
    menuOpen = false;
  }

  function toggleMenu(): void {
    menuOpen = !menuOpen;
  }

  function handleWindowClick(windowEvent: MouseEvent): void {
    if (!menuOpen) {
      return;
    }

    const target = windowEvent.target;
    if (!(target instanceof Node)) {
      return;
    }

    if (menuButton?.contains(target) || menuPanel?.contains(target)) {
      return;
    }

    closeMenu();
  }

  function handleWindowKeydown(windowEvent: KeyboardEvent): void {
    if (windowEvent.key !== 'Escape') {
      return;
    }

    closeMenu();
    rawOpen = false;
  }

  function syncMenuListeners(active: boolean): void {
    if (active === menuListenersActive) {
      return;
    }
    menuListenersActive = active;
    if (active) {
      window.addEventListener('click', handleWindowClick);
      window.addEventListener('keydown', handleWindowKeydown);
    } else {
      window.removeEventListener('click', handleWindowClick);
      window.removeEventListener('keydown', handleWindowKeydown);
    }
  }

  $: if (mounted) {
    syncMenuListeners(menuOpen);
  }

  onMount(() => {
    mounted = true;
    syncMenuListeners(menuOpen);
    return () => syncMenuListeners(false);
  });

  function showRawData(): void {
    rawOpen = true;
    closeMenu();
  }

  async function copyRawData(): Promise<void> {
    try {
      await navigator.clipboard.writeText(rawJson);
    } catch (error) {
      console.warn('Failed to copy event JSON', error);
    }
  }

  function invoke(action: (() => void) | null): void {
    action?.();
    closeMenu();
  }
</script>

<div class="relative">
    <button
      bind:this={menuButton}
      data-testid="note-actions-button"
      data-note-no-thread-nav
      type="button"
      class={`inline-flex h-9 w-9 items-center justify-center rounded-full text-white/72 transition hover:bg-[#111111] hover:text-white ${
        menuOpen ? 'bg-[#111111] text-white' : 'bg-transparent'
      }`}
      aria-label="Post actions"
      aria-haspopup="menu"
      aria-expanded={menuOpen}
      on:click={toggleMenu}
    >
      <IrisIcon name="dots-horizontal" size={24} />
    </button>

    {#if menuOpen}
      <div
        bind:this={menuPanel}
        data-testid="note-actions-menu"
        data-note-no-thread-nav
        role="menu"
        class="iris-dropdown-menu absolute right-0 top-11 z-20 w-[15rem] overflow-hidden rounded-[14px] border border-white/10 bg-[#111111] p-2 shadow-[0_24px_80px_rgba(0,0,0,0.42)]"
      >
        {#if onQuote}
          <button
            data-testid="note-actions-quote"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
            on:click={() => invoke(onQuote)}
          >
            <IrisIcon name="edit" size={18} className="text-white/55" />
            Quote post
          </button>
        {/if}

        {#if onShowReactions}
          <button
            data-testid="note-actions-show-reactions"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
            on:click={() => invoke(onShowReactions)}
          >
            <IrisIcon name="heart-solid" size={18} className="text-white/55" />
            Show reactions
          </button>
        {/if}

        <button
          data-testid="note-actions-show-raw"
          type="button"
          class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
          on:click={showRawData}
        >
          <IrisIcon name="code-circle" size={18} className="text-white/55" />
          Show raw data
        </button>

        {#if onCopyLink}
          <button
            data-testid="note-actions-copy-link"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
            on:click={() => invoke(onCopyLink)}
          >
            <IrisIcon name="link" size={18} className="text-white/55" />
            Copy link
          </button>
        {/if}

        {#if onCopyEventId}
          <button
            data-testid="note-actions-copy-event-id"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
            on:click={() => invoke(onCopyEventId)}
          >
            <IrisIcon name="copy-solid" size={18} className="text-white/55" />
            Copy Event ID
          </button>
        {/if}

        {#if onRebroadcast}
          <button
            data-testid="note-actions-rebroadcast"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a] disabled:cursor-default disabled:opacity-55"
            disabled={rebroadcastPending}
            on:click={() => invoke(onRebroadcast)}
          >
            <IrisIcon name="relay" size={18} className="text-white/55" />
            {rebroadcastPending ? 'Rebroadcasting…' : 'Rebroadcast'}
          </button>
        {/if}

        {#if activeAccount && activeAccount.pubkey !== event.pubkey && canSignAccount(activeAccount)}
          <button
            data-testid="note-actions-report"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-white transition hover:bg-[#0a0a0a]"
            on:click={() => { reportAccountPubkey = activeAccount?.pubkey ?? null; closeMenu(); }}
          >
            <IrisIcon name="block" size={18} className="text-white/55" />
            Report
          </button>
        {/if}

        {#if onDelete}
          <button
            data-testid="note-actions-delete"
            type="button"
            class="flex w-full items-center gap-3 rounded-[18px] px-3 py-3 text-left text-[0.94rem] text-red-300 transition hover:bg-red-400/10 hover:text-red-200"
            on:click={() => invoke(onDelete)}
          >
            <IrisIcon name="trash" size={18} />
            Delete
          </button>
        {/if}
      </div>
    {/if}
</div>

{#if reportAccountPubkey && activeAccount}
  <ReportPostDialog {event} account={activeAccount} onClose={() => { reportAccountPubkey = null; }} />
{/if}

{#if rawOpen}
  <ModalShell
    open
    onClose={() => {
      rawOpen = false;
    }}
    shellClass="items-center justify-center p-4 sm:p-6"
    contentClass="w-full max-w-2xl"
  >
  <section
    data-testid="note-raw-data-sheet"
    class="rounded-[28px] border border-white/5 bg-black p-5 shadow-[0_24px_80px_rgba(0,0,0,0.35)]"
  >
    <div class="flex items-center justify-between gap-3">
      <div class="text-[1rem] font-700 text-white">Raw event</div>

      <div class="flex items-center gap-2">
        <button
          type="button"
          class="inline-flex h-10 items-center justify-center gap-2 rounded-full border border-white/5 bg-[#111111] px-4 text-[0.88rem] font-600 text-white transition hover:bg-[#1a1a1a]"
          on:click={() => void copyRawData()}
        >
          <IrisIcon name="copy-solid" size={17} className="text-white/65" />
          Copy JSON
        </button>

        <button
          type="button"
          class="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white transition hover:bg-[#1a1a1a]"
          aria-label="Close raw event"
          on:click={() => {
            rawOpen = false;
          }}
        >
          <IrisIcon name="x-close" size={18} />
        </button>
      </div>
    </div>

    <div class="mt-4 overflow-hidden rounded-[24px] border border-white/5 bg-[#0a0a0a]">
      <pre class="max-h-[70vh] overflow-auto px-4 py-4 text-[0.78rem] leading-6 text-white/72">{rawJson}</pre>
    </div>
  </section>
  </ModalShell>
{/if}
