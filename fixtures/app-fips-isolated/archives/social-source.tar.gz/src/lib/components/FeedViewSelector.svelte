<script lang="ts">
  import type { FeedView } from '../feedView';
  import IrisIcon from './IrisIcon.svelte';

  export let feedView: FeedView = 'feed';
  export let testIdPrefix = 'feed-view';
  export let ariaLabel = 'Feed view';
  export let onSelect: (view: FeedView) => void = () => undefined;

  const viewOptions: { key: FeedView; label: string; icon: string }[] = [
    { key: 'feed', label: 'Feed', icon: 'deck-solid' },
    { key: 'media-grid', label: 'Media grid', icon: 'grid-01' },
  ];
</script>

<div
  data-testid={`${testIdPrefix}-switcher`}
  class="flex"
  role="group"
  aria-label={ariaLabel}
>
  {#each viewOptions as view (view.key)}
    <button
      type="button"
      data-testid={`${testIdPrefix}-${view.key}`}
      class={`flex flex-1 items-center justify-center border-b-2 bg-transparent py-2.5 transition ${
        feedView === view.key
          ? 'border-violet-400 text-violet-300'
          : 'border-transparent text-white/45 hover:border-white/15 hover:text-white'
      }`}
      aria-label={view.label}
      aria-pressed={feedView === view.key}
      title={view.label}
      on:click={() => onSelect(view.key)}
    >
      <IrisIcon name={view.icon} size={18} className={view.key === 'feed' ? 'rotate-90' : ''} />
    </button>
  {/each}
</div>
