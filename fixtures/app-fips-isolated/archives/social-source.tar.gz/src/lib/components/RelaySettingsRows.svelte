<script lang="ts">
  import SettingsGroupItem from '@iris/svelte-ui/SettingsGroupItem.svelte';
  import { browserOnline, relayConnections } from '../networkStatus';
  import { settingsStore } from '../settings';
  import IrisIcon from './IrisIcon.svelte';

  $: network = $settingsStore.network;
  $: privateRelays = network.privateRelays ?? network.relays;
  $: urls = [...new Set([...network.relays, ...privateRelays])];
  $: disabled = network.disabledRelays ?? [];
  const labels = { connected: 'Connected', connecting: 'Connecting', disconnected: 'Disconnected' };

  function toggle(url: string): void {
    settingsStore.setNetworkSettings({ disabledRelays: disabled.includes(url)
      ? disabled.filter(relay => relay !== url) : [...disabled, url] });
  }

  function remove(url: string): void {
    const relays = network.relays.filter(relay => relay !== url);
    // Clearing the last general relay also stops private interests, as before.
    const keepPrivate = !network.relays.includes(url) || relays.length > 0;
    settingsStore.setNetworkSettings({ relays, privateRelays: keepPrivate ? privateRelays.filter(relay => relay !== url) : [] });
  }
</script>

{#each urls as url (url)}
  {@const paused = disabled.includes(url)}
  {@const state = $relayConnections?.get(url)}
  {@const label = paused ? 'Disabled' : !$browserOnline ? 'Offline' : state ? labels[state] : $relayConnections ? 'Not in use' : 'Checking'}
  <SettingsGroupItem>
    <div class="flex items-center gap-2" data-testid="network-relay" data-url={url}>
      <span class="min-w-0 flex-1">
        <span class="block truncate text-[0.9rem]" title={url}>{url.replace(/^wss?:\/\//, '')}</span>
        <span class="mt-0.5 flex items-center gap-1.5 text-xs text-[rgb(var(--iris-text-rgb)/0.66)]">
          <span aria-hidden="true" class={`h-2 w-2 shrink-0 rounded-full ${label === 'Connected' ? 'bg-emerald-500' : label === 'Connecting' ? 'bg-amber-500' : 'bg-[rgb(var(--iris-text-rgb)/0.38)]'}`}></span>
          <span>{network.relays.includes(url) ? privateRelays.includes(url) ? 'Public and private' : 'Public' : 'Private'}</span>
          <span aria-hidden="true">·</span>
          <span data-testid="relay-state">{label}</span>
        </span>
      </span>
      <label class="grid h-9 w-9 shrink-0 cursor-pointer place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]">
        <input type="checkbox" checked={!paused} aria-label={`Enable relay ${url}`} class="h-4 w-4 accent-violet-500" on:change={() => toggle(url)} />
      </label>
      <button type="button" class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.64)] hover:bg-[var(--iris-surface-hover)]" aria-label={network.relays.includes(url) ? 'Remove relay' : 'Remove private relay'} title={`Remove ${url}`} on:click={() => remove(url)}>
        <IrisIcon name="x-close" size={16} />
      </button>
    </div>
  </SettingsGroupItem>
{/each}
