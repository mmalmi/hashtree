<script lang="ts">
  import { get } from 'svelte/store';
  import { accountsStore, type SocialAccount } from '../accounts';
  import { signAccountEvent } from '../accountSigner';
  import { publishEvent } from '../nostrPublish';
  import { createReportDraft, REPORT_REASONS, type ReportReason } from '../reporting';
  import type { RawEvent } from '../nostr';
  import ModalShell from './ModalShell.svelte';
  import { onDestroy } from 'svelte';

  export let event: RawEvent;
  export let account: SocialAccount;
  export let onClose: () => void;
  let reason: ReportReason = 'spam';
  let details = '';
  let pending = false;
  let queued = false;
  let error = '';
  let active = true;
  onDestroy(() => { active = false; });

  async function submit(): Promise<void> {
    if (pending || queued) {return;}
    const author = account;
    pending = true;
    error = '';
    try {
      const signed = await signAccountEvent(author, createReportDraft(event, reason, details));
      if (!active || get(accountsStore).activeAccountPubkey !== author.pubkey) {return;}
      publishEvent(signed);
      queued = true;
    } catch (cause) {
      if (active) {error = cause instanceof Error ? cause.message : 'Could not sign the report. Try again.';}
    } finally {
      if (active) {pending = false;}
    }
  }
</script>

<ModalShell open {onClose} shellClass="items-center justify-center p-4" contentClass="w-full max-w-md">
  <div role="dialog" tabindex="-1" aria-modal="true" aria-labelledby="report-post-title" data-testid="report-post-dialog" class="rounded-2xl bg-[var(--iris-surface)] p-5 text-[rgb(var(--iris-text-rgb))] shadow-xl">
    <h2 id="report-post-title" class="mb-4 text-lg font-700">Report post</h2>
    {#if queued}
      <p role="status" class="text-sm">Report saved. It will be sent when connected.</p>
      <button type="button" class="mt-5 w-full rounded-full bg-violet-600 px-4 py-2.5 font-600 text-white" on:click={onClose}>Done</button>
    {:else}
      <form on:submit|preventDefault={() => void submit()} class="grid gap-4">
        <label class="grid gap-2 text-sm">Reason
          <select bind:value={reason} disabled={pending} class="rounded-lg border border-[var(--iris-border-subtle)] bg-[var(--iris-surface-raised)] p-3">
            {#each REPORT_REASONS as item}<option value={item.value}>{item.label}</option>{/each}
          </select>
        </label>
        <label class="grid gap-2 text-sm">Details (optional)
          <textarea bind:value={details} disabled={pending} maxlength="2000" rows="3" class="resize-y rounded-lg border border-[var(--iris-border-subtle)] bg-[var(--iris-surface-raised)] p-3"></textarea>
        </label>
        <p class="text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">Reports are public and signed by your account.</p>
        {#if error}<p role="alert" class="text-sm text-red-500">{error}</p>{/if}
        <div class="flex justify-end gap-3">
          <button type="button" class="rounded-full px-4 py-2.5" on:click={onClose}>Cancel</button>
          <button type="submit" disabled={pending} class="rounded-full bg-violet-600 px-4 py-2.5 font-600 text-white disabled:opacity-50">{pending ? 'Signing…' : 'Publish report'}</button>
        </div>
      </form>
    {/if}
  </div>
</ModalShell>
