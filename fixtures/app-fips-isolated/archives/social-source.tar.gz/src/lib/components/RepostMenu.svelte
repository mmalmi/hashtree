<script lang="ts">
  import { tick } from 'svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { formatCompactStat } from '../noteEngagement';

  export let count = 0;
  export let showCount = true;
  export let reposted = false;
  export let pending = false;
  export let buttonClass = '';
  export let onRepost: () => void;
  export let onQuote: (() => void) | null = null;

  let trigger: HTMLButtonElement;
  let panel: HTMLDivElement;
  let open = false;
  const id = `note-repost-${crypto.randomUUID()}`;

  function place(): void {
    const rect = trigger.getBoundingClientRect();
    const x = Math.min(rect.left, window.innerWidth - panel.offsetWidth - 8);
    const below = rect.bottom + 6;
    panel.style.left = `${Math.max(8, x)}px`;
    panel.style.top = `${below + panel.offsetHeight < window.innerHeight ? below : Math.max(8, rect.top - panel.offsetHeight - 6)}px`;
  }

  // Items render only while open, keeping long feeds light.
  function onBeforeToggle(event: Event): void {
    open = (event as ToggleEvent).newState === 'open';
    if (open) {place();}
  }

  async function onToggle(): Promise<void> {
    open = panel.matches(':popover-open');
    if (!open) {return;}
    await tick();
    place();
    panel.querySelector<HTMLButtonElement>('button:not([disabled])')?.focus({ preventScroll: true });
  }

  function choose(action: (() => void) | null): void {
    panel.hidePopover();
    trigger.focus({ preventScroll: true });
    action?.();
  }
</script>

<button
  bind:this={trigger}
  data-testid="note-repost-button"
  data-reposted={reposted}
  type="button"
  class={`${buttonClass} ${reposted ? '!text-emerald-400' : 'hover:text-emerald-400'} disabled:opacity-60`}
  title={reposted ? 'Reposted' : `${count} reposts`}
  aria-label={reposted ? 'Reposted' : 'Repost'}
  aria-haspopup="menu"
  aria-expanded={open}
  disabled={pending}
  popovertarget={id}
>
  <IrisIcon name="repost" size={16} />
  {#if showCount}<span>{formatCompactStat(count)}</span>{/if}
</button>
<div
  {id}
  bind:this={panel}
  popover="auto"
  role="menu"
  aria-label="Repost"
  data-testid="note-repost-menu"
  data-note-no-thread-nav
  class="repost-menu"
  on:beforetoggle={onBeforeToggle}
  on:toggle={() => void onToggle()}
>
  {#if open}
  <button
    type="button"
    role="menuitem"
    data-testid="note-repost-confirm"
    disabled={reposted || pending}
    class:reposted
    on:click={() => choose(onRepost)}
  >
    <IrisIcon name={reposted ? 'check' : 'repost'} size={18} />
    {reposted ? 'Reposted' : 'Repost'}
  </button>
  {#if onQuote}
    <button type="button" role="menuitem" data-testid="note-repost-quote" on:click={() => choose(onQuote)}>
      <IrisIcon name="edit" size={18} />
      Quote
    </button>
  {/if}
  {/if}
</div>

<style>
  .repost-menu {
    position: fixed;
    inset: auto;
    margin: 0;
    min-width: 10rem;
    padding: .3rem;
    border: 0;
    border-radius: .9rem;
    background: var(--iris-surface-raised);
    color: rgb(var(--iris-text-rgb));
    box-shadow: 0 .6rem 1.8rem rgb(0 0 0 / .35);
  }
  .repost-menu button {
    display: flex;
    align-items: center;
    gap: .6rem;
    width: 100%;
    padding: .6rem .75rem;
    border: 0;
    border-radius: .6rem;
    background: transparent;
    color: inherit;
    font-weight: 600;
    text-align: left;
    cursor: pointer;
  }
  .repost-menu button:is(:hover, :focus-visible):not(:disabled) { background: rgb(var(--iris-text-rgb) / .08); }
  .repost-menu button:disabled { cursor: default; }
  .repost-menu button.reposted { color: rgb(52 211 153); }
</style>
