<script lang="ts">
  import { canSignAccount } from '../accountSigner';
  import type { SocialAccount } from '../accounts';
  import type { Route } from '../appRoute';
  import {
    prewarmWalletRoute,
    scheduleRoutePrewarm,
  } from '../lazyRouteComponents';
  import { getProfileTitle, type ProfileRecord } from '../nostr';
  import {
    HOME_HREF,
    accountsHref,
    notificationsHref,
    profileHref,
    searchHref,
    settingsHref,
    walletHref,
  } from '../routes';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import WalletNavBalance from './wallet/WalletNavBalance.svelte';
  import type { AccountAccessMode } from './app-shell/types';

  const navLinkClass = 'flex min-h-12 items-center justify-center gap-4 rounded-full px-3 text-xl no-underline transition xl:justify-start';

  export let route: Route;
  export let activeAccount: SocialAccount | null = null;
  export let activeProfile: ProfileRecord | null = null;
  export let onCompose: (opener: HTMLButtonElement) => void = () => undefined;
  export let onOpenProfile: () => void = () => undefined;
  export let onOpenAccounts: () => void = () => undefined;
  export let onOpenAccount: (mode: AccountAccessMode) => void = () => undefined;

  $: profileActive = route.kind === 'accounts'
    || (route.kind === 'profile' && route.pubkey === activeAccount?.pubkey);
  $: readOnly = Boolean(activeAccount && !canSignAccount(activeAccount));
  $: accountName = activeAccount
    ? getProfileTitle(activeProfile, activeAccount.pubkey)
    : '';
  let searchPrewarmScheduled = false;
  let settingsPrewarmScheduled = false;
  let walletPrewarmScheduled = false;

  function handleProfileClick(event: MouseEvent): void {
    if (
      event.button !== 0
      || event.metaKey
      || event.ctrlKey
      || event.shiftKey
      || event.altKey
    ) {
      return;
    }

    event.preventDefault();
    if (event.detail > 1) {
      return;
    }
    onOpenProfile();
  }

  function handleProfileDoubleClick(event: MouseEvent): void {
    event.preventDefault();
    onOpenAccounts();
  }

  function warmSettings(): void {
    if (settingsPrewarmScheduled) {
      return;
    }
    settingsPrewarmScheduled = true;
    scheduleRoutePrewarm(() => {
      void import('./SettingsPage.svelte');
    });
  }

  function warmSearch(): void {
    if (searchPrewarmScheduled) {
      return;
    }
    searchPrewarmScheduled = true;
    scheduleRoutePrewarm(() => {
      void import('./SearchPage.svelte');
    });
  }

  function warmWallet(): void {
    if (walletPrewarmScheduled) {
      return;
    }
    walletPrewarmScheduled = true;
    scheduleRoutePrewarm(prewarmWalletRoute);
  }
</script>

<aside
  data-testid="desktop-sidebar"
  class="sticky top-0 z-40 hidden h-[100dvh] w-20 shrink-0 self-start flex-col border-r border-divider bg-[var(--iris-canvas)] md:flex xl:w-64"
>
  <div class="flex min-h-0 flex-1 flex-col overflow-y-auto px-2 pb-4 pt-4 [scrollbar-width:none] xl:px-4">
    <a
      data-testid="desktop-sidebar-logo"
      data-primary-navigation-item="home"
      href={HOME_HREF}
      class="mb-4 mt-0 flex min-h-11 items-center justify-center gap-2 bg-transparent no-underline xl:justify-start xl:px-2"
      aria-label="iris social home"
    >
      <img src="/favicon.svg" alt="" class="h-8 w-8" />
      <span class="hidden text-3xl font-700 text-[rgb(var(--iris-text-rgb))] xl:inline">iris</span>
    </a>

    <nav class="grid gap-2" aria-label="Desktop primary navigation">
      <a
        data-testid="desktop-nav-home"
        data-primary-navigation-item="home"
        href={HOME_HREF}
        aria-current={route.kind === 'home' ? 'page' : undefined}
        class={navLinkClass}
      >
        <IrisIcon name={route.kind === 'home' ? 'home-solid' : 'home-outline'} size={24} />
        <span class="hidden xl:inline">Home</span>
      </a>

      <a
        data-testid="desktop-nav-search"
        data-primary-navigation-item="search"
        href={searchHref()}
        aria-current={route.kind === 'search' ? 'page' : undefined}
        on:pointerenter={warmSearch}
        on:focus={warmSearch}
        class={navLinkClass}
      >
        <IrisIcon name={route.kind === 'search' ? 'search-solid' : 'search-outline'} size={24} />
        <span class="hidden xl:inline">Search</span>
      </a>

      {#if activeAccount}
        <a
          data-testid="desktop-nav-notifications"
          data-primary-navigation-item="notifications"
          href={notificationsHref()}
          aria-current={route.kind === 'notifications' ? 'page' : undefined}
          class={navLinkClass}
        >
          <IrisIcon name={route.kind === 'notifications' ? 'bell-solid' : 'bell-outline'} size={24} />
          <span class="hidden xl:inline">Notifications</span>
        </a>

        <a
          data-testid="desktop-nav-wallet"
          data-primary-navigation-item="wallet"
          href={walletHref()}
          aria-label="Wallet"
          aria-current={route.kind === 'wallet' ? 'page' : undefined}
          on:pointerenter={warmWallet}
          on:focus={warmWallet}
          class={navLinkClass}
        >
          <IrisIcon name={route.kind === 'wallet' ? 'wallet-solid' : 'wallet-outline'} size={24} />
          <span class="hidden xl:inline">Wallet</span>
          <WalletNavBalance />
        </a>

        <a
          data-testid="desktop-nav-settings"
          data-primary-navigation-item="settings"
          href={settingsHref()}
          aria-current={route.kind === 'settings' ? 'page' : undefined}
          on:pointerenter={warmSettings}
          on:focus={warmSettings}
          class={navLinkClass}
        >
          <IrisIcon name={route.kind === 'settings' ? 'settings-solid' : 'settings-outline'} size={24} />
          <span class="hidden xl:inline">Settings</span>
        </a>
      {/if}
    </nav>

    {#if canSignAccount(activeAccount)}
      <button
        data-testid="desktop-compose-button"
        type="button"
        class="iris-preserve-white-text mx-auto mt-5 flex h-12 w-12 items-center justify-center gap-3 rounded-full bg-gradient-to-t from-violet-800 to-violet-600 font-700 text-white shadow-[0_10px_28px_rgba(91,33,182,0.28)] transition hover:brightness-110 xl:mx-0 xl:w-full"
        on:click={(event) => onCompose(event.currentTarget)}
      >
        <span class="xl:hidden">
          <IrisIcon name="plus" size={22} />
        </span>
        <span class="hidden xl:inline">Post</span>
      </button>
    {:else if !activeAccount && route.kind !== 'accounts'}
      <button
        type="button"
        data-testid="desktop-guest-sign-in"
        aria-label="Sign in"
        title="Sign in"
        class="iris-preserve-white-text mx-auto mt-5 flex h-12 w-12 items-center justify-center gap-3 rounded-full bg-gradient-to-t from-violet-800 to-violet-600 font-700 text-white shadow-[0_10px_28px_rgba(91,33,182,0.28)] transition hover:brightness-110 xl:mx-0 xl:w-full"
        on:click={() => onOpenAccount('sign-in')}
      >
        <span class="xl:hidden"><IrisIcon name="sign-in" size={21} /></span>
        <span class="hidden xl:inline">Sign in</span>
      </button>
    {/if}
  </div>

  {#if activeAccount}
    <div class="p-3 xl:p-4">
      {#if readOnly}
        <a
          data-testid="desktop-readonly-indicator"
          href={accountsHref()}
          aria-label="Read-only mode. Manage profiles"
          title="Manage profiles"
          class="mb-2 flex min-h-12 items-center justify-center gap-4 rounded-full px-3 text-red-400 no-underline hover:bg-[var(--iris-surface-hover)] xl:justify-start"
        >
          <IrisIcon name="lock-line" size={24} />
          <span class="hidden min-h-5 items-center rounded-full bg-red-500 px-2.5 text-xs font-600 text-white xl:inline-flex">Read-only</span>
        </a>
      {/if}
      <a
        data-testid="desktop-nav-profile"
        data-primary-navigation-item="profile"
        href={profileHref(activeAccount.pubkey)}
        aria-label="Profile. Double-click to manage profiles"
        aria-current={profileActive ? 'page' : undefined}
        class={`flex min-h-13 items-center justify-center gap-3 rounded-full p-2 no-underline transition xl:justify-start ${
          profileActive ? 'bg-[var(--iris-surface-raised)]' : 'hover:bg-[var(--iris-surface-hover)]'
        }`}
        on:click={handleProfileClick}
        on:dblclick={handleProfileDoubleClick}
      >
        <span class={`rounded-full border-2 p-[1px] ${profileActive ? 'border-white/80' : 'border-transparent'}`}>
          <Avatar pubkey={activeAccount.pubkey} profile={activeProfile} size={38} />
        </span>
        <span class="hidden min-w-0 flex-1 truncate font-700 text-[rgb(var(--iris-text-rgb))] xl:block">{accountName}</span>
      </a>
    </div>
  {/if}
</aside>

<style>
  nav a:hover,
  nav a[aria-current='page'] {
    background-color: var(--iris-surface-hover);
  }
</style>
