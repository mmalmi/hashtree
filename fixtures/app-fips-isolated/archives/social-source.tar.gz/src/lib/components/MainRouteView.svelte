<script lang="ts">
  import type { Action } from 'svelte/action';
  import FeedCard from './FeedCard.svelte';
  import FeedViewSelector from './FeedViewSelector.svelte';
  import HomeRouteView from './HomeRouteView.svelte';
  import LazyOverlay from './LazyOverlay.svelte';
  import LazySettingsRoute from './LazySettingsRoute.svelte';
  import MediaGrid from './MediaGrid.svelte';
  import NotificationsPage from './NotificationsPage.svelte';
  import PeopleList from './PeopleList.svelte';
  import ProfileHero from './ProfileHero.svelte';
  import ProfileSectionTabs from './ProfileSectionTabs.svelte';
  import type { ComposerAttachment } from '../media';
  import ThreadDetail from './ThreadDetail.svelte';
  import type { NotificationItem } from '../appDetailLoaders';
  import { ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from '../noteEngagement';
  import type { ReferencedNotePreview } from '../referencedNote';
  import type { NoteDetailListKind, NoteThreadSnapshot, ProfileSocialSnapshot } from '../nostrIndex';
  import type { ProfileSnapshot } from '../profileNotes';
  import { preferNewerProfileRecord } from '../profileRecords';
  import { pendingInitialProfileMetadata } from '../profileCache';
  import type { RawEvent, ProfileRecord } from '../nostr';
  import type { EditableProfileFields } from '../profileMetadata';
  import type { FeedLayout } from '../feedLayout';
  import type { FeedView } from '../feedView';
  import type { HomeTab } from '../routes';
  import type { Route } from '../appRoute';
  import { isMutedAuthor } from '../muteLists';
  import { buildNoteThreadReference } from '../appSharing';
  import { socialGraphBadges } from '../socialGraphBadges';
  import { createRetryableDynamicImport } from '../retryableDynamicImport';
  import {
    buildFollowedByPresentation,
    hasCompleteFollowerCoverage,
    sortProfileFollowers,
  } from '../profileSocialPresentation';

  export let route: Route;
  export let loading = false;
  export let homeRefreshing = false;
  export let isActive = false;
  export let threadPresented = false;
  export let canActiveAccountPublish = false;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let noteEngagements: Map<string, NoteEngagement> = new Map();
  export let homeNotes: RawEvent[] = [];
  export let feedLayout: FeedLayout = 'cozy';
  export let feedView: FeedView = 'feed';
  export let homeFeedHasMore = false;
  export let homeFeedLoadPending = false;
  export let homeFeedInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let bufferedLiveHomePostCount = 0;
  export let feedSourceLabel = 'Following';
  export let feedSourceId: string | null = null;
  export let notifications: NotificationItem[] = [];
  export let notificationsLoading = false;
  export let notificationsHasMore = false;
  export let notificationsLoadPending = false;
  export let notificationsInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreNotifications: (() => void) | null = null;
  export let profilePage: ProfileSnapshot | null = null;
  export let profileSocial: ProfileSocialSnapshot | null = null;
  export let profileSocialLoading = false;
  export let profileNotesLoading = false;
  export let profileNotes: RawEvent[] = [];
  export let profilePostCountLabel = '...';
  export let profileReplyCountLabel = '...';
  export let profileMediaCountLabel = '...';
  export let profileLikesCountLabel = '...';
  export let profileFeedHasMore = false;
  export let profileFeedLoadPending = false;
  export let profileFeedInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreProfileNotes: (() => void) | null = null;
  export let currentFollows: string[] = [];
  export let currentFollowers: string[] = [];
  export let followsCountLabel = '...';
  export let followerCountLabel = '...';
  export let profileSocialHasMore = false;
  export let profileSocialLoadPending = false;
  export let profileSocialInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let viewerPubkey: string | null = null;
  export let viewerProfile: ProfileRecord | null = null;
  export let viewerProfileEvent: RawEvent | null = null;
  export let profileSavePending = false;
  export let profileEditorBlockedReason = '';
  export let profileSaveError = '';
  export let profileSaveMessage = '';
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let threadPage: NoteThreadSnapshot | null = null;
  export let threadReplies: RawEvent[] = [];
  export let threadRepliesHasMore = false;
  export let threadRepliesLoadPending = false;
  export let threadRepliesInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreThreadReplies: (() => void) | null = null;
  export let activeMediaEventId: string | null = null;
  export let activeMediaUrl: string | null = null;
  export let likePendingNoteIds: Set<string> = new Set();
  export let zapPendingNoteIds: Set<string> = new Set();
  export let repostPendingNoteIds: Set<string> = new Set();
  export let rebroadcastPendingNoteIds: Set<string> = new Set();
  export let onLike: (event: RawEvent) => void = () => undefined;
  export let onZap: (event: RawEvent) => void = () => undefined;
  export let onZapAll: (events: RawEvent[]) => void = () => undefined;
  export let onReply: (event: RawEvent) => void = () => undefined;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: (event: RawEvent) => void = () => undefined;
  export let threadReplyValue = '';
  export let threadReplyError = '';
  export let threadReplyAttachments: ComposerAttachment[] = [];
  export let onThreadReplyInput: (value: string) => void = () => undefined;
  export let onThreadReplyAttachmentsChange: (attachments: ComposerAttachment[]) => void = () => undefined;
  export let onThreadReplySubmit: (payload: { text: string; attachments: ComposerAttachment[] }) => void = () => undefined;
  export let onOpenReactions: (event: RawEvent, kind?: NoteDetailListKind) => void = () => undefined;
  export let onCopyLink: (event: RawEvent) => void = () => undefined;
  export let onShare: (event: RawEvent) => void = () => undefined;
  export let onCopyEventId: (event: RawEvent) => void = () => undefined;
  export let onRebroadcast: (event: RawEvent) => void = () => undefined;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let onOpenMedia: (payload: any) => void = () => undefined;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onViewAsProfile: (pubkey: string) => void = () => undefined;
  export let onOpenNote: (target: string) => void = () => undefined;
  export let onHomeNotePresented: ((event: RawEvent) => void) | null = null;
  export let onHomeNoteVisible: ((event: RawEvent, presentedEvent: RawEvent | null) => void) | null = null;
  export let onSelectHomeTab: (tab: HomeTab) => void = () => undefined;
  export let onSelectFeedView: (view: FeedView) => void = () => undefined;
  export let onOpenFeedSources: (() => void) | null = null;
  export let onShowBufferedLiveHomePosts: (() => void) | null = null;
  export let onLoadMoreHome: (() => void) | null = null;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onToggleMute: ((pubkey: string, nextMuted: boolean) => void) | null = null;
  export let onCopyPubkey: ((pubkey: string) => void) | null = null;
  export let onCopyNpub: ((npub: string) => void) | null = null;
  export let onCopyProfileLink: ((href: string) => void) | null = null;
  export let onOpenWebsite: ((url: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let onNavigateBack: () => void = () => undefined;
  export let onOpenProfileImage: (url: string, label: string) => void = () => undefined;
  export let onEditProfile: (() => void) | null = null;
  export let onSaveProfile: (fields: Partial<EditableProfileFields>) => void = () => undefined;
  export let onRegisterIrisUsername: (username: string, cfToken?: string) => Promise<{ signedUp: boolean }> = async () => ({ signedUp: false });
  export let onSetProfileNip05: (nip05: string) => void = () => undefined;

  let profilePeopleModal: 'follows' | 'followers' | null = null;
  let profilePeopleModalPubkey = '';
  const loadProfilePeople = createRetryableDynamicImport(() => import('./ProfilePeopleModal.svelte'));

  $: currentProfile =
    route.kind === 'profile' && route.pubkey
      ? preferNewerProfileRecord(
          profiles.get(route.pubkey) ?? null,
          profilePage?.profile ?? null,
        )
      : null;
  $: currentProfileMuted = Boolean(
    route.kind === 'profile'
    && route.pubkey
    && isMutedAuthor(route.pubkey, mutedPubkeys, viewerPubkey),
  );
  $: threadAuthorMuted = Boolean(
    threadPage?.note && isMutedAuthor(threadPage.note.pubkey, mutedPubkeys, viewerPubkey),
  );
  $: followedBy = route.kind === 'profile' && route.pubkey
    ? buildFollowedByPresentation({
        viewerPubkey,
        targetPubkey: route.pubkey,
        viewerFollows,
        targetFollowers: profileSocial?.followers ?? currentFollowers,
        totalFollowedByFriends: $socialGraphBadges.get(route.pubkey)?.followedByFriends,
      })
    : { pubkeys: [], total: 0, followedByViewer: false };
  $: socialContextKnown = Boolean(viewerPubkey && hasCompleteFollowerCoverage(profileSocial));
  $: sortedFollowers = sortProfileFollowers(profileSocial?.followers ?? currentFollowers, viewerFollows);
  $: if (
    profilePeopleModal
    && (!isActive || route.kind !== 'profile' || route.pubkey !== profilePeopleModalPubkey)
  ) {
    profilePeopleModal = null;
    profilePeopleModalPubkey = '';
  }
  function openProfilePeopleModal(kind: 'follows' | 'followers'): void {
    if (route.kind !== 'profile' || !route.pubkey) {
      return;
    }
    profilePeopleModalPubkey = route.pubkey;
    profilePeopleModal = kind;
  }

  function closeProfilePeopleModal(): void {
    profilePeopleModal = null;
    profilePeopleModalPubkey = '';
  }

  function unmuteThreadAuthor(): void {
    const pubkey = threadPage?.note?.pubkey;
    if (pubkey) {
      onToggleMute?.(pubkey, false);
    }
  }
</script>

{#if route.kind === 'thread'}
  {#if threadPage?.note}
    {#if threadAuthorMuted}
      <div
        data-testid="thread-muted-affordance"
        class="flex items-center justify-between gap-3 border-b border-amber-200/10 bg-amber-200/[0.04] px-4 py-3 text-[0.86rem] text-amber-100/70 sm:px-5"
      >
        <span>Muted author · shown because you opened this thread directly.</span>
        {#if onToggleMute && canActiveAccountPublish}
          <button
            type="button"
            class="shrink-0 rounded-full border border-amber-100/15 px-3 py-1.5 font-700 text-amber-50 transition hover:bg-amber-100/10"
            disabled={mutePendingPubkeys.has(threadPage.note.pubkey)}
            on:click={unmuteThreadAuthor}
          >
            Unmute
          </button>
        {/if}
      </div>
    {/if}
    <ThreadDetail
      {threadPresented}
      note={threadPage.note}
      profile={profiles.get(threadPage.note.pubkey) ?? null}
      contextNotes={threadPage.context}
      replies={threadReplies}
      repliesHasMore={threadRepliesHasMore}
      repliesLoadPending={threadRepliesLoadPending}
      repliesInfiniteScroll={isActive ? threadRepliesInfiniteScroll : null}
      onLoadMoreReplies={isActive ? onLoadMoreThreadReplies : null}
      {profiles} noteEngagement={noteEngagements.get(threadPage.note.id) ?? ZERO_NOTE_ENGAGEMENT}
      replyEngagements={noteEngagements}
      {viewerPubkey} {viewerFollows} {followPendingPubkeys} {onToggleFollow}
      {viewerProfile}
      canReply={canActiveAccountPublish}
      replyValue={threadReplyValue}
      replyDraftKey={`thread:${route.ref}`}
      replyError={threadReplyError}
      replyAttachments={threadReplyAttachments}
      onReplyInput={onThreadReplyInput}
      onReplyAttachmentsChange={onThreadReplyAttachmentsChange}
      onReplySubmit={onThreadReplySubmit}
      {activeMediaEventId}
      {activeMediaUrl}
      liked={(noteEngagements.get(threadPage.note.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted}
      likePending={likePendingNoteIds.has(threadPage.note.id)}
      likeDisabled={!canActiveAccountPublish}
      onLike={onLike}
      {zapPendingNoteIds}
      {onZap}
      onReply={onReply}
      {repostPendingNoteIds}
      onQuote={onQuote}
      onRepost={onRepost}
      onOpenReactions={(event) => onOpenReactions(event, 'likes')}
      onCopyLink={onCopyLink}
      onShare={onShare}
      onCopyEventId={onCopyEventId}
      onRebroadcast={onRebroadcast}
      {onDelete}
      {rebroadcastPendingNoteIds}
      onOpenMedia={onOpenMedia}
      onOpenProfile={onOpenProfile}
      onOpenNote={onOpenNote}
      {resolveReferencedNote}
      {isActive}
    />
  {:else}
    <div
      aria-busy={loading}
      class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
    ></div>
  {/if}
{:else if route.kind === 'notifications'}
  <NotificationsPage
    items={notifications}
    {profiles}
    loading={loading || notificationsLoading}
    hasMore={notificationsHasMore}
    loadPending={notificationsLoadPending}
    infiniteScroll={isActive ? notificationsInfiniteScroll : null}
    onLoadMore={onLoadMoreNotifications}
    {onOpenProfile}
    {onOpenNote}
  />
{:else if route.kind === 'home'}
  <HomeRouteView
    activeTab={route.tab}
    {loading}
    refreshing={homeRefreshing}
    {isActive}
    {canActiveAccountPublish}
    {viewerPubkey} {viewerFollows} {followPendingPubkeys}
    {profiles}
    {noteEngagements}
    {homeNotes}
    {feedLayout}
    {feedView}
    showFeedViewSelector={route.tab === 'latest' || route.tab === 'for-you' || route.tab === 'favorites'}
    {homeFeedHasMore}
    {homeFeedLoadPending}
    {homeFeedInfiniteScroll}
    {bufferedLiveHomePostCount}
    {feedSourceLabel}
    {feedSourceId}
    {notifications}
    {notificationsLoading}
    {notificationsHasMore}
    {notificationsLoadPending}
    {notificationsInfiniteScroll}
    {onLoadMoreNotifications}
    {activeMediaEventId}
    {activeMediaUrl}
    {likePendingNoteIds}
    {zapPendingNoteIds}
    {repostPendingNoteIds}
    {rebroadcastPendingNoteIds}
    {onSelectHomeTab}
    {onSelectFeedView}
    {onOpenFeedSources}
    onShowBufferedLivePosts={onShowBufferedLiveHomePosts}
    onLoadMore={onLoadMoreHome}
    {onLike}
    {onZap}
    {onZapAll}
    {onReply}
    {onQuote}
    {onRepost}
    {onOpenReactions}
    {onCopyLink}
    {onShare}
    {onCopyEventId}
    {onRebroadcast}
    {onDelete}
    {onOpenMedia}
    {onOpenProfile}
    {onToggleFollow}
    {onOpenNote}
    onNotePresented={onHomeNotePresented}
    onNoteVisible={onHomeNoteVisible}
    {resolveReferencedNote}
  />
{:else if route.kind === 'settings'}
  <LazySettingsRoute
    {mutedPubkeys}
    {mutePendingPubkeys}
    onToggleMute={(pubkey, muted) => onToggleMute?.(pubkey, muted)}
    section={route.section}
    {viewerPubkey}
    {viewerProfileEvent}
    {viewerProfile}
    {canActiveAccountPublish}
    {profileSavePending}
    {profileEditorBlockedReason}
    {profileSaveError}
    {profileSaveMessage}
    {onSaveProfile}
    {onRegisterIrisUsername}
    {onSetProfileNip05}
    {isActive}
  />
{:else if loading && route.kind !== 'profile'}
  <div
    aria-busy="true"
    class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
  ></div>
{:else if route.kind === 'profile' && route.pubkey}
  <div class="grid gap-0" class:invisible={$pendingInitialProfileMetadata === route.pubkey && !currentProfile?.eventId}>
    <ProfileHero
      pubkey={route.pubkey}
      profile={currentProfile}
      {profiles}
      showBack={false}
      onBack={onNavigateBack}
      following={viewerFollows.has(route.pubkey)}
      followPending={followPendingPubkeys.has(route.pubkey)}
      onToggleFollow={viewerPubkey && viewerPubkey !== route.pubkey ? onToggleFollow : null}
      muted={currentProfileMuted}
      mutePending={mutePendingPubkeys.has(route.pubkey)}
      onToggleMute={viewerPubkey && viewerPubkey !== route.pubkey && canActiveAccountPublish
        ? onToggleMute
        : null}
      onOpenProfile={onOpenProfile}
      onOpenThread={onOpenNote}
      onViewAsProfile={viewerPubkey && viewerPubkey !== route.pubkey ? onViewAsProfile : null}
      onCopyPubkey={onCopyPubkey}
      onCopyNpub={onCopyNpub}
      onCopyProfileLink={onCopyProfileLink}
      onOpenWebsite={onOpenWebsite}
      onOpenImage={onOpenProfileImage}
      onEditProfile={viewerPubkey === route.pubkey ? onEditProfile : null}
      {followsCountLabel}
      {followerCountLabel}
      {followedBy}
      {socialContextKnown}
      isOwnProfile={viewerPubkey === route.pubkey}
      onOpenFollows={() => openProfilePeopleModal('follows')}
      onOpenFollowers={() => openProfilePeopleModal('followers')}
      {isActive}
    />

    <LazyOverlay open={profilePeopleModal !== null} title={profilePeopleModal === 'followers' ? 'Known followers' : 'Follows'} load={loadProfilePeople} onClose={closeProfilePeopleModal} let:component>
      <svelte:component this={component}
        open={profilePeopleModal !== null}
        kind={profilePeopleModal ?? 'follows'}
        pubkey={route.pubkey}
        profile={currentProfile}
        pubkeys={profilePeopleModal === 'followers' ? sortedFollowers : currentFollows}
        {profiles}
        loading={profileSocialLoading}
        hasMore={route.section === profilePeopleModal ? profileSocialHasMore : false}
        loadPending={profileSocialLoadPending}
        infiniteScroll={route.section === profilePeopleModal && isActive ? profileSocialInfiniteScroll : null}
        {viewerPubkey}
        {viewerFollows}
        {followPendingPubkeys}
        {onToggleFollow}
        onClose={closeProfilePeopleModal}
      />
    </LazyOverlay>

    {#if currentProfileMuted}
      <div
        data-testid="profile-muted-affordance"
        class="border-b border-amber-200/10 bg-amber-200/[0.04] px-4 py-3 text-[0.86rem] leading-6 text-amber-100/70 sm:px-5"
      >
        Muted · this profile stays available by direct navigation, while its content is hidden from your views.
      </div>
    {/if}

    <ProfileSectionTabs
      pubkey={route.pubkey}
      activeSection={route.section}
      postCountLabel={profilePostCountLabel}
      replyCountLabel={profileReplyCountLabel}
      mediaCountLabel={profileMediaCountLabel}
      likesCountLabel={profileLikesCountLabel}
    />

    {#if
      !currentProfileMuted
      && route.section !== 'follows'
      && route.section !== 'followers'
      && route.section !== 'media'
    }
      <div class="border-b border-white/5 px-3 pt-1 sm:px-4">
        <FeedViewSelector
          {feedView}
          testIdPrefix="profile-view"
          ariaLabel="Profile feed view"
          onSelect={onSelectFeedView}
        />
      </div>
    {/if}

    {#if route.section === 'follows'}
      {#if !profileSocialLoading || profileSocial}
        <PeopleList
          pubkeys={currentFollows}
          {profiles}
          {viewerPubkey}
          {viewerFollows}
          {followPendingPubkeys}
          {onToggleFollow}
          emptyText="No follows."
          hasMore={profileSocialHasMore}
          loadPending={profileSocialLoadPending}
          infiniteScroll={isActive ? profileSocialInfiniteScroll : null}
        />
      {/if}
    {:else if route.section === 'followers'}
      {#if !profileSocialLoading || profileSocial}
        <PeopleList
          pubkeys={currentFollowers}
          {profiles}
          {viewerPubkey}
          {viewerFollows}
          {followPendingPubkeys}
          {onToggleFollow}
          emptyText="No followers."
          hasMore={profileSocialHasMore}
          loadPending={profileSocialLoadPending}
          infiniteScroll={isActive ? profileSocialInfiniteScroll : null}
        />
      {/if}
    {:else if currentProfileMuted}
      <div class="border-b border-white/5 px-4 py-6 text-[0.98rem] text-white/60 sm:px-5">
        Content from this muted profile is hidden.
      </div>
    {:else if route.section === 'media' || feedView === 'media-grid'}
      {#if !profileNotesLoading || profileNotes.length > 0}
        <MediaGrid
          events={profileNotes}
          onOpenMedia={onOpenMedia}
          emptyLabel="No media in this view."
          {isActive}
        />
      {/if}
    {:else if profileNotes.length > 0}
      <div data-testid="profile-feed" class="grid gap-0">
        {#each profileNotes as event (event.id)}
          <FeedCard
            {event}
            {profiles}
            {viewerPubkey} {viewerFollows} {followPendingPubkeys} {onToggleFollow}
            profile={route.section === 'likes' ? profiles.get(event.pubkey) ?? null : currentProfile}
            showRepliedTo={route.section === 'replies'}
            engagement={noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT}
            engagements={noteEngagements}
            activeMediaUrl={activeMediaEventId === event.id ? activeMediaUrl : null}
            liked={(noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted}
            likePending={likePendingNoteIds.has(event.id)}
            likeDisabled={!canActiveAccountPublish}
            onLike={onLike}
            zapPending={zapPendingNoteIds.has(event.id)}
            zapDisabled={!canActiveAccountPublish}
            {onZap}
            onReply={onReply}
            repostPending={repostPendingNoteIds.has(event.id)}
            onQuote={onQuote}
            onRepost={onRepost}
            onOpenReactions={(nextEvent) => onOpenReactions(nextEvent, 'likes')}
            onCopyLink={onCopyLink}
            onShare={onShare}
            onCopyEventId={onCopyEventId}
            onRebroadcast={onRebroadcast}
            {onDelete}
            rebroadcastPending={rebroadcastPendingNoteIds.has(event.id)}
            onOpenMedia={onOpenMedia}
            onOpenProfile={onOpenProfile}
            onOpenNote={onOpenNote}
            {resolveReferencedNote}
            {isActive}
          />
        {/each}
      </div>
    {:else if !profileNotesLoading}
      <div class="border-b border-white/5 px-4 py-6 text-[0.98rem] text-white/60 sm:px-5">
        {route.section === 'replies' ? 'No replies yet.' : route.section === 'likes' ? 'No likes yet.' : 'No posts yet.'}
      </div>
    {/if}

    {#if
      !currentProfileMuted
      && (
        route.section === 'posts'
        || route.section === 'replies'
        || route.section === 'media'
        || route.section === 'likes'
      )
      && (profileFeedHasMore || profileFeedLoadPending || profileNotesLoading)
    }
      <div class="grid gap-0">
        {#if profileFeedHasMore && !profileFeedLoadPending && onLoadMoreProfileNotes}
          <button
            data-testid="profile-load-more"
            type="button"
            class="border-b border-white/5 px-4 py-3 text-center text-[0.86rem] font-700 text-white/65 transition hover:bg-white/[0.03] hover:text-white sm:px-5"
            on:click={onLoadMoreProfileNotes}
          >
            Load more {route.section === 'replies' ? 'replies' : route.section === 'media' ? 'media' : route.section === 'likes' ? 'likes' : 'posts'}
          </button>
        {/if}

        {#if isActive && profileFeedInfiniteScroll && (profileFeedHasMore || profileFeedLoadPending)}
          <div
            data-testid="profile-feed-infinite-sentinel"
            use:profileFeedInfiniteScroll
            aria-hidden="true"
            class="h-px w-full"
          ></div>
        {/if}
      </div>
    {/if}
  </div>
{/if}
