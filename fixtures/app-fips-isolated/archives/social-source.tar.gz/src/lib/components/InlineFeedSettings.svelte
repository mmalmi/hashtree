<script context="module" lang="ts">
  import { createRetryableDynamicImport } from '../retryableDynamicImport';
  import type { AppShellActions, HomeStateSnapshot } from './app-shell/types';

  export type FeedSettingsContext = { home: HomeStateSnapshot; actions: AppShellActions };
  const loadEditor = createRetryableDynamicImport(() => import('./FeedSourceEditorSheet.svelte'));
</script>

<script lang="ts">
  import type { HomeTab } from '../routes';
  import type { ProfileRecord } from '../nostr';
  import {
    deleteCustomFeed, findCustomFeed, homeFeedLayoutsStore, pendingNewFeedStore, readHomeFeedLayout,
  } from '../homeFeedTabs';
  import FeedEditor from './FeedEditor.svelte';

  export let context: FeedSettingsContext;
  export let activeTab: HomeTab;
  export let activeFeedId: string | null = null;
  export let viewerPubkey: string | null;
  export let onClose: () => void;
  export let onSelectFeed: ((tab: HomeTab, feedId: string | null) => void) | null = null;
  export let profiles: ReadonlyMap<string, ProfileRecord> = new Map();
  let editor = loadEditor();
  $: usesFollowList = activeTab === 'latest' || activeTab === 'for-you' || activeTab === 'media';
  // A feed just added with "+" can be cancelled until its settings close.
  $: pendingNewFeed = $pendingNewFeedStore?.viewer === viewerPubkey && $pendingNewFeedStore?.id === activeFeedId
    ? $pendingNewFeedStore : null;

  function finish(): void {
    if (pendingNewFeed) { pendingNewFeedStore.set(null); }
    onClose();
  }

  function cancelNewFeed(): void {
    if (!pendingNewFeed) { return; }
    const { id, returnTab, returnFeedId } = pendingNewFeed;
    pendingNewFeedStore.set(null);
    deleteCustomFeed(viewerPubkey, id);
    onSelectFeed?.(returnTab, returnFeedId);
    onClose();
  }

  $: customFeed = findCustomFeed(readHomeFeedLayout($homeFeedLayoutsStore, viewerPubkey), activeFeedId);
  $: tabLabel = customFeed?.name
    ?? (activeTab === 'for-you' ? 'For you' : activeTab === 'media' ? 'Media' : activeTab === 'favorites' ? 'Favorites' : 'Latest');
</script>

<section id="home-feed-settings" aria-label={`${tabLabel} feed settings`} data-testid="feed-source-sheet"
  class="bg-[var(--iris-surface)] px-4 py-3.5 sm:px-5">
  <header class="mb-2 flex items-center justify-between gap-4">
    <h2 class="m-0 min-w-0 truncate text-[1.04rem] font-700">{pendingNewFeed ? 'New feed' : `${tabLabel} settings`}</h2>
    <div class="flex shrink-0 items-center gap-2">
      {#if pendingNewFeed}
        <button type="button" data-testid="custom-feed-cancel"
          class="rounded-full iris-neutral-button px-4 py-1.5 text-sm font-700" on:click={cancelNewFeed}>Cancel</button>
      {/if}
      <button type="button" aria-label="Close feed settings"
        class="rounded-full bg-violet-700 px-4 py-1.5 text-sm font-700 iris-preserve-white-text"
        on:click={finish}>Done</button>
    </div>
  </header>
  <div class="grid gap-4">
  <FeedEditor {viewerPubkey} {activeTab} {activeFeedId} {tabLabel} {profiles} {onSelectFeed}
    activeSourceId={context.home.activeFeedSourceId} />
  {#await editor}
    <!-- Same rows and heights as the follow list and action row it stands in for. -->
    <div role="status" data-testid="overlay-loading" aria-busy="true" class="grid gap-4 text-sm">
      {#if usesFollowList}
        <div class="border-t border-divider pt-1">
          <p class="m-0 flex min-h-10 items-center py-2.5 text-white/60">Loading feed settings…</p>
        </div>
      {/if}
      {#if viewerPubkey}
        <div class="border-t border-divider pt-3">
          <p class="m-0 flex h-8 items-center text-white/60">{usesFollowList ? '' : 'Loading feed settings…'}</p>
        </div>
      {/if}
    </div>
  {:then module}
    <svelte:component this={module.default}
      {activeTab} {activeFeedId} {viewerPubkey} {onSelectFeed} onClose={finish}
      sources={context.home.feedSources} sourceName={context.home.feedSourceName}
      sourceIdentity={context.home.feedSourceIdentity} sourceError={context.home.feedSourceError}
      activeSourceId={context.home.activeFeedSourceId}
      onSourceNameChange={context.actions.handleFeedSourceNameChange}
      onSourceIdentityChange={context.actions.handleFeedSourceIdentityChange}
      onAddSource={context.actions.addFeedSource}
      onSelectDefault={() => context.actions.selectFeedSource(null)}
      onSelectSource={context.actions.selectFeedSource} onRemoveSource={context.actions.removeFeedSource}
    />
  {:catch}
    <div data-testid="overlay-loading" class="flex items-center gap-3 py-2 text-sm">
      <span role="alert">Couldn't load feed settings.</span>
      <button type="button" class="rounded-full iris-neutral-button px-3 py-1.5 font-700" on:click={() => { editor = loadEditor(); }}>Retry</button>
    </div>
  {/await}
  </div>
  <slot />
</section>
