<script lang="ts">
  import { getProfileTitle, normalizePubkey, type ProfileRecord } from '../nostr';
  import IrisIcon from './IrisIcon.svelte';

  export let label: string;
  export let pubkeys: readonly string[];
  export let profiles: ReadonlyMap<string, ProfileRecord>;
  export let onChange: (pubkeys: string[]) => void;
  export let testId: string;

  const MAX_SUGGESTIONS = 5;
  let query = '';
  let error = '';

  $: needle = query.trim().toLowerCase();
  $: suggestions = needle.length < 2 || normalizePubkey(query) ? [] : [...profiles.values()]
    .filter((profile) => !pubkeys.includes(profile.pubkey)
      && [profile.displayName, profile.name, profile.nip05].some((value) => value?.toLowerCase().includes(needle)))
    .slice(0, MAX_SUGGESTIONS);

  function add(pubkey: string): void {
    if (!pubkeys.includes(pubkey)) {onChange([...pubkeys, pubkey]);}
    query = '';
    error = '';
  }

  function submit(): void {
    const pubkey = normalizePubkey(query) ?? suggestions[0]?.pubkey ?? null;
    if (pubkey) {
      add(pubkey);
    } else if (query.trim()) {
      error = 'Enter an npub or pick a name from the list.';
    }
  }
</script>

<div class="grid gap-2" data-testid={testId}>
  {#if pubkeys.length > 0}
    <ul class="m-0 flex list-none flex-wrap gap-1.5 p-0">
      {#each pubkeys as pubkey (pubkey)}
        <li class="inline-flex max-w-full items-center gap-1 rounded-full bg-[var(--iris-surface-raised)] py-1 pl-3 pr-1">
          <span class="truncate">{getProfileTitle(profiles.get(pubkey) ?? null, pubkey)}</span>
          <button type="button" aria-label={`Remove ${getProfileTitle(profiles.get(pubkey) ?? null, pubkey)}`}
            class="grid h-6 w-6 shrink-0 place-items-center rounded-full hover:bg-[var(--iris-surface-hover)]"
            on:click={() => onChange(pubkeys.filter((value) => value !== pubkey))}>
            <IrisIcon name="x-close" size={14} />
          </button>
        </li>
      {/each}
    </ul>
  {/if}
  <form class="relative" on:submit|preventDefault={submit}>
    <input aria-label={label} placeholder="Name or npub" bind:value={query} on:input={() => { error = ''; }}
      class="w-full min-w-0 rounded-lg iris-field px-3 py-2 text-[max(1rem,16px)]" />
    {#if suggestions.length > 0}
      <ul role="listbox" aria-label={`${label} suggestions`}
        class="absolute inset-x-0 top-full z-10 m-0 mt-1 list-none overflow-hidden rounded-lg bg-[var(--iris-surface-raised)] p-1 shadow-lg">
        {#each suggestions as profile (profile.pubkey)}
          <li>
            <button type="button" role="option" aria-selected="false"
              class="w-full truncate rounded-md px-3 py-2 text-left hover:bg-[var(--iris-surface-hover)]"
              on:click={() => add(profile.pubkey)}>{getProfileTitle(profile, profile.pubkey)}</button>
          </li>
        {/each}
      </ul>
    {/if}
  </form>
  {#if error}<span role="alert" class="text-red-400">{error}</span>{/if}
</div>
