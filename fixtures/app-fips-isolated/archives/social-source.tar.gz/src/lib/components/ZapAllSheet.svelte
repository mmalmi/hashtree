<script lang="ts">
  import ModalShell from './ModalShell.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { DEFAULT_ZAP_BITS, type ZapAllLogEntry, type ZapAllRunOptions } from '../zaps';

  export let open = false;
  export let eventCount = 0;
  export let running = false;
  export let completed = false;
  export let progress = 0;
  export let spentBits = 0;
  export let error = '';
  export let logs: ZapAllLogEntry[] = [];
  export let canRun = false;
  export let onClose: () => void = () => undefined;
  export let onStart: (options: ZapAllRunOptions) => void = () => undefined;

  let amountBits = DEFAULT_ZAP_BITS;
  let maxBudgetBits = 210;
  let comment = '';

  $: maxPosts = amountBits > 0 ? Math.floor(maxBudgetBits / amountBits) : 0;
  $: startDisabled = running || !canRun || amountBits < 1 || maxBudgetBits < amountBits || eventCount === 0;

  function normalizePositiveInteger(value: string, fallback: number): number {
    const parsed = Number.parseInt(value, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
  }

  function handleStart(): void {
    if (startDisabled) {
      return;
    }

    onStart({
      amountBits,
      maxBudgetBits,
      comment,
    });
  }
</script>

<ModalShell {open} {onClose}>
  <aside
    data-testid="zap-all-sheet"
    class="max-h-[calc(100dvh-2rem)] w-full max-w-[32rem] overflow-y-auto rounded-[28px] border border-white/5 bg-black px-4 pb-6 pt-5 shadow-[0_24px_80px_rgba(0,0,0,0.35)] sm:px-5"
  >
    <div class="flex items-center justify-between gap-3">
      <div class="flex items-center gap-2 text-[1.05rem] font-700 text-white">
        <IrisIcon name="zap-solid" size={18} className="text-[#fbbf24]" />
        <span>Zap all</span>
      </div>

      <button
        type="button"
        class="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/5 bg-[#111111] text-white transition hover:bg-[#1a1a1a]"
        aria-label="Close zap all"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={18} />
      </button>
    </div>

    <div class="mt-4 grid grid-cols-2 gap-3">
      <label class="grid gap-1.5">
        <span class="text-[0.78rem] uppercase tracking-[0.16em] text-white/42">Bits</span>
        <input
          data-testid="zap-all-amount"
          type="number"
          min="1"
          value={amountBits}
          class="rounded-[18px] border border-white/5 bg-[#0a0a0a] px-4 py-3 text-[0.95rem] text-white outline-none"
          disabled={running}
          on:input={(event) => {
            amountBits = normalizePositiveInteger((event.currentTarget as HTMLInputElement).value, DEFAULT_ZAP_BITS);
          }}
        />
      </label>

      <label class="grid gap-1.5">
        <span class="text-[0.78rem] uppercase tracking-[0.16em] text-white/42">Budget</span>
        <input
          data-testid="zap-all-budget"
          type="number"
          min="1"
          value={maxBudgetBits}
          class="rounded-[18px] border border-white/5 bg-[#0a0a0a] px-4 py-3 text-[0.95rem] text-white outline-none"
          disabled={running}
          on:input={(event) => {
            maxBudgetBits = normalizePositiveInteger((event.currentTarget as HTMLInputElement).value, 210);
          }}
        />
      </label>
    </div>

    <input
      data-testid="zap-all-comment"
      value={comment}
      placeholder="Comment"
      class="mt-3 w-full rounded-[18px] border border-white/5 bg-[#0a0a0a] px-4 py-3 text-[0.95rem] text-white outline-none placeholder:text-white/28"
      disabled={running}
      on:input={(event) => {
        comment = (event.currentTarget as HTMLInputElement).value;
      }}
    />

    <div class="mt-3 flex items-center justify-between gap-3 rounded-[18px] border border-white/5 bg-[#080808] px-4 py-3 text-[0.86rem] text-white/60">
      <span>{eventCount} posts</span>
      <span>{maxPosts} max</span>
      <span>{spentBits} spent</span>
    </div>

    {#if error}
      <div data-testid="zap-all-error" class="mt-3 rounded-[18px] border border-[#5f2727] bg-[#2a0d0d] px-4 py-3 text-[0.88rem] text-[#ffb4b4]">
        {error}
      </div>
    {/if}

    {#if running || completed}
      <div class="mt-4">
        <div class="h-2 overflow-hidden rounded-full bg-white/8">
          <div
            class="h-full rounded-full bg-[#fbbf24] transition-all"
            style={`width:${eventCount > 0 ? Math.min(100, Math.round((progress / eventCount) * 100)) : 0}%`}
          ></div>
        </div>
        <div class="mt-2 text-[0.82rem] text-white/52">{progress} / {eventCount}</div>
      </div>
    {/if}

    <button
      data-testid="zap-all-start"
      type="button"
      class="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-[18px] border border-white/5 bg-[#151515] px-4 py-3 text-[0.95rem] font-700 text-white transition hover:bg-[#1d1d1d] disabled:cursor-not-allowed disabled:opacity-50"
      disabled={startDisabled}
      on:click={handleStart}
    >
      <IrisIcon name="play-square-outline" size={18} />
      <span>{running ? 'Running' : completed ? 'Run again' : 'Start'}</span>
    </button>

    {#if logs.length > 0}
      <div class="mt-4 grid max-h-52 gap-2 overflow-y-auto">
        {#each logs as log (log.id)}
          <div class={`rounded-[14px] px-3 py-2 text-[0.82rem] ${
            log.type === 'success'
              ? 'bg-[#122016] text-[#a7f3b5]'
              : log.type === 'skip'
                ? 'bg-[#171717] text-white/58'
                : 'bg-[#251010] text-[#ffb4b4]'
          }`}>
            {log.message}
          </div>
        {/each}
      </div>
    {/if}
  </aside>
</ModalShell>
