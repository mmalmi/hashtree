<script lang="ts">
  import ErrorNotice from './ErrorNotice.svelte';
  import type { AppError } from '../appError';
  import { onDestroy, tick } from 'svelte';
  import * as nip19 from 'nostr-tools/nip19';
  import { sharedProfilesStore, rememberProfileRecords } from '../profileCache';
  import { sortProfileSearchMatches } from '../profileSearchRanking';
  import { getProfileTitle } from '../nostr';
  import { clearedComposerDrafts } from '../threadReplyDrafts';
  import { getRouteActivity } from '../routeActivity';
  import {
    composerOptionsStore,
    EMPTY_COMPOSER_OPTIONS,
    expirationLabel,
    geohashCellSize,
    hasComposerOptions,
    type ComposerOptions,
    type ComposerSubmitPayload,
  } from '../composerOptions';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import EmojiButton from './composer/EmojiButton.svelte';
  import ExpirationSelector from './composer/ExpirationSelector.svelte';
  import LocationSelector from './composer/LocationSelector.svelte';
  import type { ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';
  import {
    getMimeType,
    type ComposerAttachment,
    type MediaUploadProgress,
    uploadHashtreeFile,
  } from '../media';

  export let pubkey: string;
  export let draftKey = 'home';
  export let profile: ProfileRecord | null = null;
  export let value = '';
  export let disabled = false;
  export let error: AppError = '';
  export let attachments: ComposerAttachment[] = [];
  export let placeholder = 'What’s on your mind?';
  export let submitLabel = 'Post';
  export let preview = false;
  export let dialog = false;
  export let onInput: (value: string) => void = () => undefined;
  export let onSubmit: (payload: ComposerSubmitPayload) => void = () => undefined;
  export let onAttachmentsChange: (attachments: ComposerAttachment[]) => void = () => undefined;
  /** Shows a Cancel button beside Post (the dialog composer). */
  export let onCancel: (() => void) | null = null;

  type DraftAttachment = ComposerAttachment & { file?: File };

  const routeActivity = getRouteActivity();
  const mentionListId = `composer-mentions-${globalThis.crypto.randomUUID()}`;
  let textarea: HTMLTextAreaElement;
  let composerRoot: HTMLElement;
  let focused = false;
  // Expiration and location belong to the draft, like its text and attachments.
  $: optionsScope = `${pubkey}:${draftKey}`;
  $: options = $composerOptionsStore.get(optionsScope) ?? EMPTY_COMPOSER_OPTIONS;
  // Like Iris Client, the inline composer stays one line until it is used.
  $: expanded = dialog || preview || focused || Boolean(value.trim()) || draftAttachments.length > 0
    || hasComposerOptions(options);

  function setOptions(patch: Partial<ComposerOptions>): void {
    composerOptionsStore.write(optionsScope, { ...options, ...patch });
  }

  function insertEmoji(emoji: string): void {
    if (!textarea || disabled) { return; }
    const current = textarea.value;
    const start = textarea.selectionStart ?? current.length;
    const end = textarea.selectionEnd ?? start;
    const cursor = start + emoji.length;
    onInput(current.slice(0, start) + emoji + current.slice(end));
    void tick().then(() => { textarea?.setSelectionRange(cursor, cursor); });
  }

  function focusTextarea(): void {
    textarea?.focus({ preventScroll: true });
  }

  // Keep the editor focused (and the inline composer open) when a toolbar icon is pressed.
  function keepEditorFocus(event: MouseEvent): void {
    if (document.activeElement === textarea && event.target instanceof Element && event.target.closest('button')) {
      event.preventDefault();
    }
  }

  function handleFocusOut(event: FocusEvent): void {
    const next = event.relatedTarget;
    if (!(next instanceof Node) || !composerRoot?.contains(next)) { focused = false; }
  }
  let mention: { start: number; end: number; query: string } | null = null;
  let selectedMention = 0;
  let mentionTimer: ReturnType<typeof setTimeout> | null = null;
  let mentionController: AbortController | null = null;
  $: mentionResults = mention
    ? (mention.query ? sortProfileSearchMatches([...$sharedProfilesStore.values()], mention.query) : [...$sharedProfilesStore.values()]).slice(0, 6)
    : [];
  $: if (!$routeActivity || disabled || preview) { closeMentions(); }

  export function focusInput(): boolean {
    if (!textarea || disabled || preview) {return false;}
    textarea.focus({ preventScroll: true });
    return true;
  }

  function closeMentions(): void {
    mention = null;
    if (mentionTimer) { clearTimeout(mentionTimer); }
    mentionTimer = null;
    mentionController?.abort();
    mentionController = null;
  }

  function updateMention(): void {
    if (!textarea || disabled) { return; }
    const cursor = textarea.selectionStart;
    const match = textarea.value.slice(0, cursor).match(/(?:^|\s)@([^\s@]*)$/);
    if (!match || textarea.selectionEnd !== cursor) { closeMentions(); return; }
    const query = match[1]!;
    const start = cursor - query.length - 1;
    if (mention?.query === query && mention.start === start) { return; }
    closeMentions();
    mention = { start, end: cursor, query };
    selectedMention = 0;
    if (query.length < 2) { return; }
    const controller = new AbortController();
    mentionController = controller;
    mentionTimer = setTimeout(() => {
      mentionTimer = null;
      void import('../profileSearchV3Runtime').then(({ searchProfileSearchRollout }) => (
        searchProfileSearchRollout(query, 6, controller.signal, (profiles) => {
          if (!controller.signal.aborted) { rememberProfileRecords(profiles); }
        })
      )).then((profiles) => {
        if (!controller.signal.aborted) { rememberProfileRecords(profiles); }
      }).catch(() => undefined);
    }, 240);
  }

  function selectMention(profile: ProfileRecord): void {
    if (!mention || !textarea) { return; }
    const reference = `nostr:${nip19.npubEncode(profile.pubkey)} `;
    const cursor = mention.start + reference.length;
    onInput(textarea.value.slice(0, mention.start) + reference + textarea.value.slice(mention.end));
    closeMentions();
    void tick().then(() => {
      textarea?.focus();
      textarea?.setSelectionRange(cursor, cursor);
    });
  }

  onDestroy(closeMentions);

  let attachmentInput: HTMLInputElement | null = null;
  let draftAttachments: DraftAttachment[] = [];
  let attachmentSignature = '';
  let attachmentOwner = pubkey;
  let submitRequested = false;
  let dismissedIds = new Set<string>();
  let observedDraftScope = '';
  let observedDraftClear = 0;

  $: {
    const scope = `${pubkey}:${draftKey}`;
    const version = $clearedComposerDrafts.get(scope) ?? 0;
    if (scope !== observedDraftScope) {
      observedDraftScope = scope;
      observedDraftClear = version;
    } else if (version > observedDraftClear) {
      observedDraftClear = version;
      submitRequested = false;
      draftAttachments = [];
      dismissedIds = new Set();
      attachmentSignature = '';
    }
  }

  function cloneAttachments(list: ComposerAttachment[]): DraftAttachment[] {
    return list.map((attachment) => ({ ...attachment }));
  }

  function publicAttachments(list: DraftAttachment[]): ComposerAttachment[] {
    return list.map(({ file: _file, ...attachment }) => ({ ...attachment }));
  }

  function signatureForAttachments(list: ComposerAttachment[]): string {
    return list
      .map(
        (attachment) =>
          [
            attachment.id,
            attachment.fileName,
            attachment.mimeType,
            attachment.size,
            attachment.status,
            attachment.progress.toFixed(4),
            attachment.url ?? '',
            attachment.nhash ?? '',
            attachment.hashHex ?? '',
            attachment.error ?? '',
          ].join('|'),
      )
      .join(';;');
  }

  function syncExternalAttachments(next: ComposerAttachment[], owner: string, scope: string): void {
    if (owner !== attachmentOwner) {
      attachmentOwner = owner;
      draftAttachments = cloneAttachments(next);
      dismissedIds = new Set();
      submitRequested = false;
    }
    const nextSignature = signatureForAttachments(next);
    if (nextSignature === attachmentSignature) { return; }
    attachmentSignature = nextSignature;
    const local = new Map(draftAttachments.map((attachment) => [attachment.id, attachment]));
    if (scope === 'home') {
      // The inline editor and modal share this draft, including removals.
      draftAttachments = next.map((attachment) => ({
        ...attachment,
        file: attachment.status === 'done' ? undefined : local.get(attachment.id)?.file,
      }));
      return;
    }
    // Retained routes can briefly replay an older draft during navigation.
    // Keep this component's upload progress and File until its owner submits.
    for (const attachment of next) {
      if (dismissedIds.has(attachment.id)) { continue; }
      const current = local.get(attachment.id);
      if (!current || (attachment.status === 'done' && current.status !== 'done')) {
        local.set(attachment.id, { ...attachment });
      }
    }
    draftAttachments = [...local.values()];
  }

  $: syncExternalAttachments(attachments, pubkey, draftKey);
  $: if (submitRequested && !value && attachments.length === 0) {
    submitRequested = false;
    draftAttachments = [];
    dismissedIds = new Set();
    attachmentSignature = '';
  }

  function emitAttachments(
    callback: (attachments: ComposerAttachment[]) => void = onAttachmentsChange,
  ): void {
    const next = publicAttachments(draftAttachments);
    attachmentSignature = signatureForAttachments(next);
    callback(next);
  }

  function updateAttachment(
    id: string,
    patch: Partial<DraftAttachment>,
    callback: (attachments: ComposerAttachment[]) => void = onAttachmentsChange,
  ): void {
    let changed = false;
    draftAttachments = draftAttachments.map((attachment) => {
      if (attachment.id !== id) {
        return attachment;
      }
      changed = true;
      return { ...attachment, ...patch };
    });
    if (changed) {
      emitAttachments(callback);
    }
  }

  function removeAttachment(id: string): void {
    dismissedIds.add(id);
    draftAttachments = draftAttachments.filter((attachment) => attachment.id !== id);
    emitAttachments();
  }


  function createAttachmentId(): string {
    return globalThis.crypto?.randomUUID?.() ?? `attachment-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function fileLabel(file: File): string {
    return file.name.trim() || 'attachment';
  }

  function attachmentProgress(progress: MediaUploadProgress): number {
    return progress.progress;
  }

  async function uploadAttachment(file: File, id: string): Promise<void> {
    const mimeType = file.type?.trim() || getMimeType(file.name);
    const emitUploadAttachments = onAttachmentsChange;
    try {
      const result = await uploadHashtreeFile(file, {
        onProgress: (progress) => {
          if (dismissedIds.has(id)) {
            return;
          }
          updateAttachment(id, {
            status: 'uploading',
            file,
            fileName: fileLabel(file),
            mimeType,
            size: file.size,
            progress: attachmentProgress(progress),
            error: '',
          }, emitUploadAttachments);
        },
      });

      if (dismissedIds.has(id)) {
        return;
      }

      updateAttachment(id, {
        status: 'done',
        file: undefined,
        fileName: result.fileName,
        mimeType: result.mimeType,
        size: result.size,
        progress: 1,
        url: result.url,
        nhash: result.nhash,
        hashHex: result.hashHex,
        error: '',
      }, emitUploadAttachments);
    } catch (uploadError) {
      if (dismissedIds.has(id)) {
        return;
      }

      updateAttachment(id, {
        status: 'error',
        file,
        fileName: fileLabel(file),
        mimeType,
        size: file.size,
        progress: 0,
        error: uploadError instanceof Error ? uploadError.message : 'Upload failed',
      }, emitUploadAttachments);
    }
  }

  async function handleAttachmentSelect(files: FileList | null): Promise<void> {
    if (!files?.length || disabled) {
      return;
    }

    const selectedFiles = Array.from(files);
    for (const file of selectedFiles) {
      const id = createAttachmentId();
      draftAttachments = [
        ...draftAttachments,
        {
          id,
          file,
          fileName: fileLabel(file),
          mimeType: file.type?.trim() || getMimeType(file.name),
          size: file.size,
          status: 'uploading',
          progress: 0,
        },
      ];
      emitAttachments();
      void uploadAttachment(file, id);
    }

    if (attachmentInput) {
      attachmentInput.value = '';
    }
  }

  function handleSubmit(): void {
    if (disabled || !canSubmit) {
      return;
    }

    submitRequested = true;
    onSubmit({
      text: value,
      attachments: publicAttachments(draftAttachments).filter((attachment) => attachment.status === 'done'),
      expirationDelta: options.expirationDelta,
      geohash: options.geohash,
    });
  }

  function retryAttachment(attachment: DraftAttachment): void {
    if (!attachment.file || attachment.status !== 'error') {
      return;
    }

    dismissedIds.delete(attachment.id);
    updateAttachment(attachment.id, {
      status: 'uploading',
      progress: 0,
      error: '',
    });
    void uploadAttachment(attachment.file, attachment.id);
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (event.isComposing || event.keyCode === 229) { return; }
    if (mention && !event.metaKey && !event.ctrlKey) {
      if (event.key === 'Escape') { event.preventDefault(); closeMentions(); return; }
      if (mentionResults.length > 0 && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
        event.preventDefault();
        selectedMention = (selectedMention + (event.key === 'ArrowDown' ? 1 : -1) + mentionResults.length) % mentionResults.length;
        return;
      }
      if ((event.key === 'Enter' || event.key === 'Tab') && !event.shiftKey && mentionResults[selectedMention]) {
        event.preventDefault();
        selectMention(mentionResults[selectedMention]!);
        return;
      }
    }
    if ((event.metaKey || event.ctrlKey) && event.key === 'Enter' && !disabled) {
      event.preventDefault();
      handleSubmit();
    }
  }

  function handleFileDrop(event: DragEvent): void {
    if (!event.dataTransfer?.files.length) { return; }
    event.preventDefault();
    void handleAttachmentSelect(event.dataTransfer.files);
  }

  function handlePaste(event: ClipboardEvent): void {
    if (!event.clipboardData?.files.length) { return; }
    if (!event.clipboardData.getData('text/plain')) { event.preventDefault(); }
    void handleAttachmentSelect(event.clipboardData.files);
  }

  function handleAttachmentButtonClick(): void {
    if (disabled) {
      return;
    }
    attachmentInput?.click();
  }

  $: hasUploadingAttachments = draftAttachments.some((attachment) => attachment.status === 'uploading');
  $: hasAttachmentErrors = draftAttachments.some((attachment) => attachment.status === 'error');
  $: hasReadyAttachments = draftAttachments.some((attachment) => attachment.status === 'done');
  $: canSubmit = !disabled && !hasUploadingAttachments && !hasAttachmentErrors && (value.trim().length > 0 || hasReadyAttachments);

  const chipClass = 'inline-flex h-8 max-w-full items-center gap-1.5 rounded-full bg-[rgb(var(--iris-text-rgb)/0.07)] pl-2.5 pr-1 text-[0.84rem] text-[rgb(var(--iris-text-rgb)/0.85)]';
  const chipRemoveClass = 'grid h-6 w-6 shrink-0 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.6)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.1)] hover:text-[rgb(var(--iris-text-rgb))] disabled:opacity-40';
</script>


<section
  bind:this={composerRoot}
  aria-label={submitLabel === 'Post' ? 'Post composer' : 'Reply composer'}
  data-expanded={expanded ? 'true' : 'false'}
  on:focusin={() => { focused = true; }}
  on:focusout={handleFocusOut}
  class="bg-transparent p-0"
  on:dragover={(event) => { if (event.dataTransfer?.types.includes('Files')) { event.preventDefault(); } }}
  on:drop={handleFileDrop}
>
  <div class={'flex items-start gap-3 px-4 sm:px-5 ' + (dialog ? 'pt-3' : expanded ? 'pt-2.5' : 'py-2.5')}>
    <a
      href={profileHref(pubkey)}
      aria-label="Open your profile"
      class="shrink-0 rounded-full transition hover:opacity-90"
    >
      <Avatar {pubkey} {profile} size={40} />
    </a>

    <div class="min-w-0 flex-1">
      <textarea
        bind:this={textarea}
        data-testid="composer-input"
        aria-label={submitLabel === 'Post' ? 'Write a post' : 'Write a reply'}
        aria-autocomplete="list"
        aria-controls={mentionResults.length ? mentionListId : undefined}
        aria-activedescendant={mentionResults.length ? `${mentionListId}-${selectedMention}` : undefined}
        value={value}
        rows={dialog ? 6 : expanded ? 3 : 1}
        placeholder={disabled ? 'Read-only profile' : placeholder}
        disabled={disabled}
        style="field-sizing: content"
        class={'w-full resize-none align-top border-0 bg-transparent px-0 text-[rgb(var(--iris-text-rgb))] outline-none placeholder:text-[rgb(var(--iris-text-rgb)/0.66)] disabled:cursor-not-allowed disabled:opacity-70 '
          + (dialog
            ? 'min-h-[10rem] max-h-[min(45dvh,22rem)] py-1.5 text-[1.1rem] leading-7'
            : 'py-2 text-[max(1rem,16px)] leading-6 ' + (expanded ? 'min-h-[4.5rem] max-h-[50dvh]' : ''))}
        hidden={preview}
        on:input={(event) => { onInput((event.currentTarget as HTMLTextAreaElement).value); updateMention(); }}
        on:click={updateMention}
        on:keyup={(event) => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { updateMention(); } }}
        on:blur={closeMentions}
        on:paste={handlePaste}
        on:keydown={handleKeydown}
      ></textarea>

      {#if preview}
        <slot name="preview" />
      {/if}

      {#if mention && mentionResults.length > 0}
        <div id={mentionListId} role="listbox" aria-label="Mention a person" class="mt-1 overflow-hidden rounded-2xl bg-[var(--iris-surface-active)] p-1 shadow-[0_12px_40px_rgba(0,0,0,0.45)]">
          {#each mentionResults as candidate, index (candidate.pubkey)}
            <button
              id={`${mentionListId}-${index}`}
              type="button"
              role="option"
              aria-selected={index === selectedMention}
              class={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left ${index === selectedMention ? 'bg-[rgb(var(--iris-text-rgb)/0.1)]' : 'hover:bg-[rgb(var(--iris-text-rgb)/0.06)]'}`}
              on:mousedown|preventDefault
              on:click={() => selectMention(candidate)}
            >
              <Avatar pubkey={candidate.pubkey} profile={candidate} size={32} />
              <span class="min-w-0 truncate">{getProfileTitle(candidate, candidate.pubkey)}</span>
              {#if candidate.nip05}<span class="ml-auto truncate text-xs text-[rgb(var(--iris-text-rgb)/0.45)]">{candidate.nip05}</span>{/if}
            </button>
          {/each}
        </div>
      {/if}

      <input
        bind:this={attachmentInput}
        data-testid="composer-attachment-input"
        type="file"
        multiple
        class="hidden"
        on:change={(event) => void handleAttachmentSelect((event.currentTarget as HTMLInputElement).files)}
      />

      {#if draftAttachments.length > 0}
        <div class="mt-3 grid min-w-0 grid-cols-1 gap-2">
          {#each draftAttachments as attachment (attachment.id)}
            <div class="min-w-0 rounded-2xl bg-[rgb(var(--iris-text-rgb)/0.06)] px-3.5 py-3">
              <div class="flex items-start gap-3">
                <div class="min-w-0 flex-1">
                  <div class="truncate text-[0.92rem] text-[rgb(var(--iris-text-rgb))]">{attachment.fileName}</div>
                  <div class="mt-0.5 text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.55)]">{attachment.mimeType} · {attachment.size.toLocaleString()} bytes</div>
                </div>

                <div class="flex items-center gap-1.5">
                  {#if attachment.status === 'error'}
                    <button
                      type="button"
                      class="h-8 rounded-full bg-[rgba(239,68,68,0.16)] px-3 text-[0.8rem] font-650 text-[#ffd4d4]"
                      on:click={() => retryAttachment(attachment)}
                    >
                      Retry
                    </button>
                  {/if}

                  <button
                    type="button"
                    class="h-8 rounded-full bg-[rgb(var(--iris-text-rgb)/0.08)] px-3 text-[0.8rem] font-650 text-[rgb(var(--iris-text-rgb)/0.85)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.14)]"
                    on:click={() => removeAttachment(attachment.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>

              {#if attachment.status === 'uploading'}
                <div class="mt-2.5 h-1.5 overflow-hidden rounded-full bg-[rgb(var(--iris-text-rgb)/0.1)]">
                  <div
                    class="h-full rounded-full bg-[linear-gradient(to_top,#3c21c8,#7a29ff)] transition-all duration-300"
                    style={`width:${Math.max(0, Math.min(100, Math.round(attachment.progress * 100)))}%;`}
                  ></div>
                </div>
              {/if}

              <div class="mt-1.5 flex items-center justify-between gap-3 text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.55)]">
                <span class={attachment.status === 'error' ? 'min-w-0 break-words text-[#ffb4b4]' : 'shrink-0'}>
                  {#if attachment.status === 'uploading'}
                    Uploading…
                  {:else if attachment.status === 'done'}
                    Ready
                  {:else}
                    {attachment.error || 'Upload failed'}
                  {/if}
                </span>

                {#if attachment.url}
                  <span class="min-w-0 flex-1 truncate text-right" title={attachment.url}>{attachment.url}</span>
                {/if}
              </div>
            </div>
          {/each}
        </div>
      {/if}
    </div>
  </div>

  {#if expanded}
    <div class={'px-4 sm:px-5 ' + (dialog ? 'sticky bottom-0 z-10 bg-[var(--composer-surface,var(--iris-surface))] pb-4 pt-3' : 'pb-3 pt-2')}>
      {#if options.geohash || options.expirationDelta !== null}
        <div class="flex flex-wrap items-center gap-2 pb-2.5">
          {#if options.geohash}
            <span data-testid="composer-location-chip" class={chipClass} title={`Location geohash ${options.geohash}`}>
              <IrisIcon name="marker-pin-solid" size={15} className="text-violet-400" />
              <span class="truncate">{options.geohash}</span>
              <span class="shrink-0 text-[rgb(var(--iris-text-rgb)/0.5)]">~{geohashCellSize(options.geohash.length)}</span>
              <button type="button" class={chipRemoveClass} aria-label="Remove location" title="Remove location" {disabled} on:click={() => setOptions({ geohash: null })}>
                <IrisIcon name="x" size={15} />
              </button>
            </span>
          {/if}
          {#if options.expirationDelta !== null}
            <span data-testid="composer-expiration-chip" class={chipClass} title={`Expires ${expirationLabel(options.expirationDelta)} after posting`}>
              <IrisIcon name="clock-solid" size={15} className="text-violet-400" />
              <span class="truncate">Expires in {expirationLabel(options.expirationDelta)}</span>
              <button type="button" class={chipRemoveClass} aria-label="Remove expiration" title="Remove expiration" {disabled} on:click={() => setOptions({ expirationDelta: null })}>
                <IrisIcon name="x" size={15} />
              </button>
            </span>
          {/if}
        </div>
      {/if}

      {#if !error && (hasUploadingAttachments || hasAttachmentErrors)}
        <p class={'truncate pb-2 text-[0.85rem] ' + (hasAttachmentErrors ? 'text-[#ffd4d4]' : 'text-[rgb(var(--iris-text-rgb)/0.6)]')}>{hasUploadingAttachments ? 'Uploading attachments…' : 'Fix or remove failed attachments.'}</p>
      {/if}

      <div class="flex items-center justify-between gap-2">
        <!-- svelte-ignore a11y_no_static_element_interactions -->
        <div class="-ml-2 flex min-w-0 items-center" on:mousedown={keepEditorFocus}>
          <EmojiButton {disabled} onSelect={insertEmoji} returnFocus={focusTextarea} />
          <button
            type="button"
            data-testid="composer-attach"
            aria-label="Attach files"
            title="Attach files"
            class="grid h-10 w-10 shrink-0 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.8)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] hover:text-[rgb(var(--iris-text-rgb))] focus-visible:bg-[rgb(var(--iris-text-rgb)/0.08)] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-40"
            disabled={disabled}
            on:click={handleAttachmentButtonClick}
          >
            <IrisIcon name="attachment" size={21} />
          </button>
          <LocationSelector {disabled} value={options.geohash} onChange={(geohash) => setOptions({ geohash })} />
          <ExpirationSelector {disabled} value={options.expirationDelta} onChange={(expirationDelta) => setOptions({ expirationDelta })} />
        </div>

        <div class="flex shrink-0 items-center gap-1">
          {#if onCancel}
            <button
              type="button"
              class="h-9 rounded-full px-3.5 text-[0.9rem] font-650 text-[rgb(var(--iris-text-rgb)/0.75)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] hover:text-[rgb(var(--iris-text-rgb))]"
              on:click={onCancel}
            >Cancel</button>
          {/if}
          <button
            data-testid="composer-submit"
            type="button"
            class="iris-preserve-white-text inline-flex h-9 shrink-0 items-center justify-center rounded-full bg-[linear-gradient(to_top,#3c21c8,#7a29ff)] px-5 text-[0.9rem] font-700 text-white transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-45"
            disabled={!canSubmit}
            on:click={handleSubmit}
          >
            {submitLabel}
          </button>
        </div>
      </div>
    </div>
  {/if}
  {#if error}
    <div class="px-4 pb-2 text-[0.85rem] text-[#ffd4d4] sm:px-5"><ErrorNotice {error} /></div>
  {/if}
</section>
