<script lang="ts">
  import { onDestroy, tick } from 'svelte';
  import * as nip19 from 'nostr-tools/nip19';
  import { sharedProfilesStore, rememberProfileRecords } from '../profileCache';
  import { sortProfileSearchMatches } from '../profileSearchRanking';
  import { getProfileTitle } from '../nostr';
  import { clearedComposerDrafts } from '../threadReplyDrafts';
  import { getRouteActivity } from '../routeActivity';
  import Avatar from './Avatar.svelte';
  import type { ProfileRecord } from '../nostr';
  import { profileHref } from '../routes';
  import {
    getMimeType,
    type ComposerAttachment,
    type MediaUploadProgress,
    uploadHashtreeFile,
  } from '../media';

  export let pubkey: string;
  export let draftKey = 'home';
  export let profile: ProfileRecord | null = null;
  export let value = '';
  export let disabled = false;
  export let error = '';
  export let attachments: ComposerAttachment[] = [];
  export let placeholder = 'Share something';
  export let submitLabel = 'Post';
  export let onInput: (value: string) => void = () => undefined;
  export let onSubmit: (payload: { text: string; attachments: ComposerAttachment[] }) => void = () =>
    undefined;
  export let onAttachmentsChange: (attachments: ComposerAttachment[]) => void = () => undefined;

  type DraftAttachment = ComposerAttachment & { file?: File };

  const routeActivity = getRouteActivity();
  const mentionListId = `composer-mentions-${globalThis.crypto.randomUUID()}`;
  let textarea: HTMLTextAreaElement;
  let mention: { start: number; end: number; query: string } | null = null;
  let selectedMention = 0;
  let mentionTimer: ReturnType<typeof setTimeout> | null = null;
  let mentionController: AbortController | null = null;
  $: mentionResults = mention
    ? (mention.query ? sortProfileSearchMatches([...$sharedProfilesStore.values()], mention.query) : [...$sharedProfilesStore.values()]).slice(0, 6)
    : [];
  $: if (!$routeActivity || disabled) { closeMentions(); }

  function closeMentions(): void {
    mention = null;
    if (mentionTimer) { clearTimeout(mentionTimer); }
    mentionTimer = null;
    mentionController?.abort();
    mentionController = null;
  }

  function updateMention(): void {
    if (!textarea || disabled) { return; }
    const cursor = textarea.selectionStart;
    const match = textarea.value.slice(0, cursor).match(/(?:^|\s)@([^\s@]*)$/);
    if (!match || textarea.selectionEnd !== cursor) { closeMentions(); return; }
    const query = match[1]!;
    const start = cursor - query.length - 1;
    if (mention?.query === query && mention.start === start) { return; }
    closeMentions();
    mention = { start, end: cursor, query };
    selectedMention = 0;
    if (query.length < 2) { return; }
    const controller = new AbortController();
    mentionController = controller;
    mentionTimer = setTimeout(() => {
      mentionTimer = null;
      void import('../profileSearchV3Runtime').then(({ searchProfileSearchRollout }) => (
        searchProfileSearchRollout(query, 6, controller.signal, (profiles) => {
          if (!controller.signal.aborted) { rememberProfileRecords(profiles); }
        })
      )).then((profiles) => {
        if (!controller.signal.aborted) { rememberProfileRecords(profiles); }
      }).catch(() => undefined);
    }, 240);
  }

  function selectMention(profile: ProfileRecord): void {
    if (!mention || !textarea) { return; }
    const reference = `nostr:${nip19.npubEncode(profile.pubkey)} `;
    const cursor = mention.start + reference.length;
    onInput(textarea.value.slice(0, mention.start) + reference + textarea.value.slice(mention.end));
    closeMentions();
    void tick().then(() => {
      textarea?.focus();
      textarea?.setSelectionRange(cursor, cursor);
    });
  }

  onDestroy(closeMentions);

  let attachmentInput: HTMLInputElement | null = null;
  let draftAttachments: DraftAttachment[] = [];
  let attachmentSignature = '';
  let attachmentOwner = pubkey;
  let submitRequested = false;
  let dismissedIds = new Set<string>();
  let observedDraftScope = '';
  let observedDraftClear = 0;

  $: {
    const scope = `${pubkey}:${draftKey}`;
    const version = $clearedComposerDrafts.get(scope) ?? 0;
    if (scope !== observedDraftScope) {
      observedDraftScope = scope;
      observedDraftClear = version;
    } else if (version > observedDraftClear) {
      observedDraftClear = version;
      submitRequested = false;
      draftAttachments = [];
      dismissedIds = new Set();
      attachmentSignature = '';
    }
  }

  function cloneAttachments(list: ComposerAttachment[]): DraftAttachment[] {
    return list.map((attachment) => ({ ...attachment }));
  }

  function publicAttachments(list: DraftAttachment[]): ComposerAttachment[] {
    return list.map(({ file: _file, ...attachment }) => ({ ...attachment }));
  }

  function signatureForAttachments(list: ComposerAttachment[]): string {
    return list
      .map(
        (attachment) =>
          [
            attachment.id,
            attachment.fileName,
            attachment.mimeType,
            attachment.size,
            attachment.status,
            attachment.progress.toFixed(4),
            attachment.url ?? '',
            attachment.nhash ?? '',
            attachment.hashHex ?? '',
            attachment.error ?? '',
          ].join('|'),
      )
      .join(';;');
  }

  function syncExternalAttachments(next: ComposerAttachment[], owner: string): void {
    if (owner !== attachmentOwner) {
      attachmentOwner = owner;
      draftAttachments = cloneAttachments(next);
      dismissedIds = new Set();
      submitRequested = false;
    }
    const nextSignature = signatureForAttachments(next);
    if (nextSignature === attachmentSignature) { return; }
    attachmentSignature = nextSignature;
    // Retained routes can briefly replay an older draft during navigation.
    // Keep this component's upload progress and File until its owner submits.
    const local = new Map(draftAttachments.map((attachment) => [attachment.id, attachment]));
    for (const attachment of next) {
      if (dismissedIds.has(attachment.id)) { continue; }
      const current = local.get(attachment.id);
      if (!current || (attachment.status === 'done' && current.status !== 'done')) {
        local.set(attachment.id, { ...attachment });
      }
    }
    draftAttachments = [...local.values()];
  }

  $: syncExternalAttachments(attachments, pubkey);
  $: if (submitRequested && !value && attachments.length === 0) {
    submitRequested = false;
    draftAttachments = [];
    dismissedIds = new Set();
    attachmentSignature = '';
  }

  function emitAttachments(
    callback: (attachments: ComposerAttachment[]) => void = onAttachmentsChange,
  ): void {
    const next = publicAttachments(draftAttachments);
    attachmentSignature = signatureForAttachments(next);
    callback(next);
  }

  function updateAttachment(
    id: string,
    patch: Partial<DraftAttachment>,
    callback: (attachments: ComposerAttachment[]) => void = onAttachmentsChange,
  ): void {
    let changed = false;
    draftAttachments = draftAttachments.map((attachment) => {
      if (attachment.id !== id) {
        return attachment;
      }
      changed = true;
      return { ...attachment, ...patch };
    });
    if (changed) {
      emitAttachments(callback);
    }
  }

  function removeAttachment(id: string): void {
    dismissedIds.add(id);
    draftAttachments = draftAttachments.filter((attachment) => attachment.id !== id);
    emitAttachments();
  }


  function createAttachmentId(): string {
    return globalThis.crypto?.randomUUID?.() ?? `attachment-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function fileLabel(file: File): string {
    return file.name.trim() || 'attachment';
  }

  function attachmentProgress(progress: MediaUploadProgress): number {
    return progress.progress;
  }

  async function uploadAttachment(file: File, id: string): Promise<void> {
    const mimeType = file.type?.trim() || getMimeType(file.name);
    const emitUploadAttachments = onAttachmentsChange;
    try {
      const result = await uploadHashtreeFile(file, {
        onProgress: (progress) => {
          if (dismissedIds.has(id)) {
            return;
          }
          updateAttachment(id, {
            status: 'uploading',
            file,
            fileName: fileLabel(file),
            mimeType,
            size: file.size,
            progress: attachmentProgress(progress),
            error: '',
          }, emitUploadAttachments);
        },
      });

      if (dismissedIds.has(id)) {
        return;
      }

      updateAttachment(id, {
        status: 'done',
        file: undefined,
        fileName: result.fileName,
        mimeType: result.mimeType,
        size: result.size,
        progress: 1,
        url: result.url,
        nhash: result.nhash,
        hashHex: result.hashHex,
        error: '',
      }, emitUploadAttachments);
    } catch (uploadError) {
      if (dismissedIds.has(id)) {
        return;
      }

      updateAttachment(id, {
        status: 'error',
        file,
        fileName: fileLabel(file),
        mimeType,
        size: file.size,
        progress: 0,
        error: uploadError instanceof Error ? uploadError.message : 'Upload failed',
      }, emitUploadAttachments);
    }
  }

  async function handleAttachmentSelect(files: FileList | null): Promise<void> {
    if (!files?.length || disabled) {
      return;
    }

    const selectedFiles = Array.from(files);
    for (const file of selectedFiles) {
      const id = createAttachmentId();
      draftAttachments = [
        ...draftAttachments,
        {
          id,
          file,
          fileName: fileLabel(file),
          mimeType: file.type?.trim() || getMimeType(file.name),
          size: file.size,
          status: 'uploading',
          progress: 0,
        },
      ];
      emitAttachments();
      void uploadAttachment(file, id);
    }

    if (attachmentInput) {
      attachmentInput.value = '';
    }
  }

  function handleSubmit(): void {
    if (disabled || !canSubmit) {
      return;
    }

    submitRequested = true;
    onSubmit({
      text: value,
      attachments: publicAttachments(draftAttachments).filter((attachment) => attachment.status === 'done'),
    });
  }

  function retryAttachment(attachment: DraftAttachment): void {
    if (!attachment.file || attachment.status !== 'error') {
      return;
    }

    dismissedIds.delete(attachment.id);
    updateAttachment(attachment.id, {
      status: 'uploading',
      progress: 0,
      error: '',
    });
    void uploadAttachment(attachment.file, attachment.id);
  }

  function handleKeydown(event: KeyboardEvent): void {
    if (mention && !event.isComposing && !event.metaKey && !event.ctrlKey) {
      if (event.key === 'Escape') { event.preventDefault(); closeMentions(); return; }
      if (mentionResults.length > 0 && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
        event.preventDefault();
        selectedMention = (selectedMention + (event.key === 'ArrowDown' ? 1 : -1) + mentionResults.length) % mentionResults.length;
        return;
      }
      if (event.key === 'Enter' && mentionResults[selectedMention]) {
        event.preventDefault();
        selectMention(mentionResults[selectedMention]!);
        return;
      }
    }
    if ((event.metaKey || event.ctrlKey) && event.key === 'Enter' && !disabled) {
      event.preventDefault();
      handleSubmit();
    }
  }

  function handleAttachmentButtonClick(): void {
    if (disabled) {
      return;
    }
    attachmentInput?.click();
  }

  $: hasUploadingAttachments = draftAttachments.some((attachment) => attachment.status === 'uploading');
  $: hasAttachmentErrors = draftAttachments.some((attachment) => attachment.status === 'error');
  $: hasReadyAttachments = draftAttachments.some((attachment) => attachment.status === 'done');
  $: canSubmit = !disabled && !hasUploadingAttachments && !hasAttachmentErrors && (value.trim().length > 0 || hasReadyAttachments);
</script>

<section class="bg-transparent p-0">
  <div class="flex items-start gap-3 px-4 py-3 sm:px-5">
    <a
      href={profileHref(pubkey)}
      aria-label="Open your profile"
      class="shrink-0 rounded-full transition hover:opacity-90"
    >
      <Avatar {pubkey} {profile} size={40} />
    </a>

    <div class="min-w-0 flex-1">
      <textarea
        bind:this={textarea}
        data-testid="composer-input"
        aria-label={submitLabel === 'Post' ? 'Write a post' : 'Write a reply'}
        aria-autocomplete="list"
        aria-controls={mentionResults.length ? mentionListId : undefined}
        aria-activedescendant={mentionResults.length ? `${mentionListId}-${selectedMention}` : undefined}
        value={value}
        rows="2"
        placeholder={disabled ? 'Read-only account' : placeholder}
        disabled={disabled}
        class="min-h-[3rem] w-full resize-none border-0 bg-transparent px-0 py-1 text-[1rem] leading-6 text-white outline-none placeholder:text-white/35 disabled:cursor-not-allowed disabled:opacity-70"
        on:input={(event) => { onInput((event.currentTarget as HTMLTextAreaElement).value); updateMention(); }}
        on:click={updateMention}
        on:keyup={(event) => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { updateMention(); } }}
        on:blur={closeMentions}
        on:keydown={handleKeydown}
      ></textarea>

      {#if mention && mentionResults.length > 0}
        <div id={mentionListId} role="listbox" aria-label="Mention a person" class="mt-1 overflow-hidden rounded-xl border border-white/10 bg-[var(--color-bg,#111)] shadow-lg">
          {#each mentionResults as candidate, index (candidate.pubkey)}
            <button
              id={`${mentionListId}-${index}`}
              type="button"
              role="option"
              aria-selected={index === selectedMention}
              class={`flex w-full items-center gap-3 px-3 py-2 text-left ${index === selectedMention ? 'bg-white/10' : 'hover:bg-white/5'}`}
              on:mousedown|preventDefault
              on:click={() => selectMention(candidate)}
            >
              <Avatar pubkey={candidate.pubkey} profile={candidate} size={32} />
              <span class="min-w-0 truncate">{getProfileTitle(candidate, candidate.pubkey)}</span>
              {#if candidate.nip05}<span class="ml-auto truncate text-xs text-white/45">{candidate.nip05}</span>{/if}
            </button>
          {/each}
        </div>
      {/if}

      <input
        bind:this={attachmentInput}
        data-testid="composer-attachment-input"
        type="file"
        multiple
        class="hidden"
        on:change={(event) => void handleAttachmentSelect((event.currentTarget as HTMLInputElement).files)}
      />

      {#if draftAttachments.length > 0}
        <div class="mt-4 grid gap-2">
          {#each draftAttachments as attachment (attachment.id)}
            <div class="rounded-[18px] border border-white/5 bg-black/20 px-3 py-3">
              <div class="flex items-start gap-3">
                <div class="min-w-0 flex-1">
                  <div class="truncate text-[0.92rem] text-white">{attachment.fileName}</div>
                  <div class="mt-1 text-[0.78rem] text-white/55">{attachment.mimeType} · {attachment.size.toLocaleString()} bytes</div>
                </div>

                <div class="flex items-center gap-2">
                  {#if attachment.status === 'error'}
                    <button
                      type="button"
                      class="rounded-full bg-[rgba(239,68,68,0.16)] px-3 py-1 text-[0.78rem] font-600 text-[#ffd4d4]"
                      on:click={() => retryAttachment(attachment)}
                    >
                      Retry
                    </button>
                  {/if}

                  <button
                    type="button"
                    class="rounded-full border border-white/5 bg-[#121212] px-3 py-1 text-[0.78rem] font-600 text-white/82"
                    on:click={() => removeAttachment(attachment.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>

              <div class="mt-3 h-1.5 overflow-hidden rounded-full bg-[rgba(255,255,255,0.1)]">
                <div
                  class="h-full rounded-full bg-[linear-gradient(to_top,#3c21c8,#7a29ff)] transition-all duration-300"
                  style={`width:${Math.max(0, Math.min(100, Math.round(attachment.progress * 100)))}%;`}
                ></div>
              </div>

              <div class="mt-2 flex items-center justify-between gap-3 text-[0.78rem] text-white/55">
                <span>
                  {#if attachment.status === 'uploading'}
                    Uploading…
                  {:else if attachment.status === 'done'}
                    Ready
                  {:else}
                    {attachment.error || 'Upload failed'}
                  {/if}
                </span>

                {#if attachment.url}
                  <span class="truncate">{attachment.url}</span>
                {/if}
              </div>
            </div>
          {/each}
        </div>
      {/if}

      <div class="mt-4 flex items-center justify-between gap-3 border-t border-white/5 pt-3">
        {#if error}
          <div class="text-[0.85rem] text-[#ffd4d4]">{error}</div>
        {:else if hasUploadingAttachments}
          <div class="text-[0.85rem] text-white/60">Uploading attachments…</div>
        {:else if hasAttachmentErrors}
          <div class="text-[0.85rem] text-[#ffd4d4]">Fix or remove failed attachments.</div>
        {/if}

        <div class="flex items-center gap-2">
          <button
            type="button"
            data-testid="composer-attach"
            class="inline-flex h-8 items-center justify-center rounded-full border border-white/5 bg-[#111111] px-3 text-[0.82rem] font-600 text-white/82 disabled:cursor-not-allowed disabled:opacity-50"
            disabled={disabled}
            on:click={handleAttachmentButtonClick}
          >
            Attach
          </button>

          <button
            data-testid="composer-submit"
            type="button"
            class="iris-preserve-white-text inline-flex h-8 items-center justify-center rounded-full bg-[linear-gradient(to_top,#3c21c8,#7a29ff)] px-4 text-[0.82rem] font-700 text-white disabled:cursor-not-allowed disabled:opacity-50"
            disabled={!canSubmit}
            on:click={handleSubmit}
          >
            {submitLabel}
          </button>
        </div>
      </div>
    </div>
  </div>
</section>
