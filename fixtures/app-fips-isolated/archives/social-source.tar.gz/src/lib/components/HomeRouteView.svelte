<script lang="ts">
  import { contactMemoryStore } from '../contactMemoryStore';
  import { favoriteContactPubkeys } from '../appFavoritesFeed';
  import { onDestroy } from 'svelte';
  import { getKind6RepostTargetEventId, requestEmbeddedRepostAdmission, resolveKind6RepostTarget } from '../repostPresentation';
  import { feedFilterScope, feedFiltersStore, filterHomeFeedEvents, readFeedFilters, needsRepostFilterTargets, type FeedFilters } from '../feedFilters';
  import type { Action } from 'svelte/action';
  import FeedCard from './FeedCard.svelte';
  import FeedTabSwitcher from './FeedTabSwitcher.svelte';
  import MediaGrid from './MediaGrid.svelte';
  import NotificationFeed from './NotificationFeed.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from '../noteEngagement';
  import type { NoteEmbed } from '../noteContent';
  import type { ReferencedNotePreview } from '../referencedNote';
  import type { NotificationItem } from '../appDetailLoaders';
  import type { NoteDetailListKind } from '../nostrIndex';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { FeedLayout } from '../feedLayout';
  import type { FeedView } from '../feedView';
  import type { HomeTab } from '../routes';
  import { buildNoteThreadReference } from '../appSharing';

  export let activeTab: HomeTab = 'latest';
  export let feedLayout: FeedLayout = 'cozy';
  export let feedView: FeedView = 'feed';
  export let showFeedViewSelector = true;
  export let loading = false;
  export let refreshing = false;
  export let isActive = false;
  export let canActiveAccountPublish = false;
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let noteEngagements: Map<string, NoteEngagement> = new Map();
  export let homeNotes: RawEvent[] = [];
  export let homeFeedHasMore = false;
  export let homeFeedLoadPending = false;
  export let homeFeedInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let bufferedLiveHomePostCount = 0;
  export let feedSourceLabel = 'Following';
  export let feedSourceId: string | null = null;
  export let notifications: NotificationItem[] = [];
  export let notificationsLoading = false;
  export let notificationsHasMore = false;
  export let notificationsLoadPending = false;
  export let notificationsInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreNotifications: (() => void) | null = null;
  export let activeMediaEventId: string | null = null;
  export let activeMediaUrl: string | null = null;
  export let likePendingNoteIds: Set<string> = new Set();
  export let zapPendingNoteIds: Set<string> = new Set();
  export let repostPendingNoteIds: Set<string> = new Set();
  export let rebroadcastPendingNoteIds: Set<string> = new Set();
  export let onSelectHomeTab: (tab: HomeTab) => void = () => undefined;
  export let onSelectFeedView: (view: FeedView) => void = () => undefined;
  export let onOpenFeedSources: (() => void) | null = null;
  export let onShowBufferedLivePosts: (() => void) | null = null;
  export let onLoadMore: (() => void) | null = null;
  export let onLike: (event: RawEvent) => void = () => undefined;
  export let onZap: (event: RawEvent) => void = () => undefined;
  export let onZapAll: (events: RawEvent[]) => void = () => undefined;
  export let onReply: (event: RawEvent) => void = () => undefined;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: (event: RawEvent) => void = () => undefined;
  export let onOpenReactions: (event: RawEvent, kind?: NoteDetailListKind) => void = () => undefined;
  export let onCopyLink: (event: RawEvent) => void = () => undefined;
  export let onShare: (event: RawEvent) => void = () => undefined;
  export let onCopyEventId: (event: RawEvent) => void = () => undefined;
  export let onRebroadcast: (event: RawEvent) => void = () => undefined;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onOpenNote: (target: string) => void = () => undefined;
  export let onNotePresented: ((event: RawEvent) => void) | null = null;
  export let onNoteVisible: ((event: RawEvent, presentedEvent: RawEvent | null) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;

  $: filterScope = feedFilterScope(viewerPubkey, feedSourceId, activeTab);
  $: feedFilters = readFeedFilters($feedFiltersStore, filterScope);
  let resolvedFilterReposts = new Map<string, RawEvent>();
  let filterResolutionVersion = 0;
  $: filteredNotes = filterHomeFeedEvents(homeNotes, feedFilters, resolvedFilterReposts);
  $: hydrateRepostFilterTargets(homeNotes, feedFilters, isActive, resolveReferencedNote);

  function hydrateRepostFilterTargets(
    notes: RawEvent[],
    filters: FeedFilters,
    active: boolean,
    resolver: typeof resolveReferencedNote,
  ): void {
    const version = ++filterResolutionVersion;
    if (!active || !needsRepostFilterTargets(filters)) { return; }
    const knownIds = new Set(notes.map((event) => event.id));
    const queue = notes.filter((event) => event.kind === 6
      && !resolvedFilterReposts.has(event.id)
      && !knownIds.has(getKind6RepostTargetEventId(event) ?? ''));
    const run = async () => {
      while (version === filterResolutionVersion && queue.length) {
        const event = queue.shift()!;
        try {
          await requestEmbeddedRepostAdmission(event);
          if (version !== filterResolutionVersion) { return; }
          const target = await resolveKind6RepostTarget(event, resolver);
          if (version !== filterResolutionVersion) { return; }
          if (target) {
            const next = new Map(resolvedFilterReposts).set(event.id, target.event);
            while (next.size > 2048) { next.delete(next.keys().next().value!); }
            resolvedFilterReposts = next;
          }
        } catch { /* An unavailable target remains excluded until a later feed load. */ }
      }
    };
    for (let index = 0; index < Math.min(4, queue.length); index += 1) { void run(); }
  }

  onDestroy(() => { filterResolutionVersion += 1; });

  // The feed is the default projection for switchable Home views, so retain it
  // from their first mount. The dedicated Media route can never reveal feed
  // rows in-place and must not build dozens of hidden FeedCards.
  let feedProjectionMounted = activeTab !== 'media';
  let mediaProjectionMounted = false;

  $: hasFavorites = favoriteContactPubkeys($contactMemoryStore, viewerPubkey).length > 0;
  $: mediaProjectionVisible = activeTab === 'media'
    || (showFeedViewSelector && feedView === 'media-grid');
  $: feedProjectionVisible = activeTab !== 'notifications' && !mediaProjectionVisible;
  $: if (feedProjectionVisible) {
    feedProjectionMounted = true;
  }
  $: if (mediaProjectionVisible) {
    mediaProjectionMounted = true;
  }
</script>

<section
  data-testid="home-route-view"
  aria-busy={loading || refreshing}
  class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
>
  <div class="border-b border-white/5 px-3 py-2 sm:px-4">
    <FeedTabSwitcher
      activeTab={activeTab}
      {feedView}
      {showFeedViewSelector}
      {feedSourceLabel}
      onSelectTab={onSelectHomeTab}
      onSelectFeedView={showFeedViewSelector ? onSelectFeedView : null}
      onOpenSources={activeTab !== 'notifications' && activeTab !== 'favorites' ? onOpenFeedSources : null}
    />
  </div>

  {#if isActive && activeTab !== 'notifications' && bufferedLiveHomePostCount > 0 && onShowBufferedLivePosts}
    <div class="pointer-events-none fixed inset-x-0 top-[8.5rem] z-30 flex justify-center px-4">
      <button
        data-testid="show-new-posts"
        type="button"
        class="pointer-events-auto rounded-full border border-violet-300/20 bg-violet-700 px-4 py-2 text-[0.86rem] font-700 text-white shadow-[0_12px_36px_rgba(0,0,0,0.5)] transition hover:bg-violet-600"
        on:click={onShowBufferedLivePosts}
      >
        {bufferedLiveHomePostCount} new {bufferedLiveHomePostCount === 1 ? 'post' : 'posts'}
      </button>
    </div>
  {/if}

  {#if activeTab === 'notifications'}
    <NotificationFeed
      items={notifications}
      profiles={profiles}
      loading={loading || notificationsLoading}
      hasMore={notificationsHasMore}
      loadPending={notificationsLoadPending}
      infiniteScroll={isActive ? notificationsInfiniteScroll : null}
      onLoadMore={onLoadMoreNotifications}
      onOpenProfile={onOpenProfile}
      onOpenNote={onOpenNote}
    />
  {:else if activeTab === 'favorites' && !hasFavorites}
    <div data-testid="favorites-empty" class="border-b border-white/5 px-4 py-7 text-[1rem] text-white/60 sm:px-5">
      Star someone’s profile to see their posts here. Only you can see your favorites.
    </div>
  {:else if !loading || filteredNotes.length > 0}
    {#if feedProjectionMounted && filteredNotes.length > 0}
      <div
        data-testid="home-feed-projection"
        hidden={!feedProjectionVisible}
        aria-hidden={!feedProjectionVisible}
      >
        <div class="border-b border-white/5 px-3 py-2 sm:px-4">
          <button
            data-testid="feed-zap-all-button"
            type="button"
            class="inline-flex items-center gap-2 rounded-full border border-white/5 bg-[#111111] px-3 py-2 text-[0.84rem] font-700 text-white transition hover:bg-[#1a1a1a]"
            on:click={() => onZapAll(filteredNotes)}
          >
            <IrisIcon name="zap-solid" size={17} className="text-[#fbbf24]" />
            <span>Zap all</span>
            <span class="text-white/45">{filteredNotes.length}</span>
          </button>
        </div>

        <div data-testid="latest-feed" class="grid gap-0">
          {#each filteredNotes as event (event.id)}
            <FeedCard
              {event}
              {profiles}
              {viewerPubkey}
              {viewerFollows}
              {followPendingPubkeys}
              {onToggleFollow}
              compact={feedLayout === 'compact'}
              showRepliedTo={(activeTab === 'latest' || activeTab === 'favorites') && feedFilters.showRepliedTo}
              profile={profiles.get(event.pubkey) ?? null}
              engagement={noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT}
              engagements={noteEngagements}
              activeMediaUrl={activeMediaEventId === event.id ? activeMediaUrl : null}
              liked={(noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted}
              likePending={likePendingNoteIds.has(event.id)}
              likeDisabled={!canActiveAccountPublish}
              onLike={onLike}
              zapPending={zapPendingNoteIds.has(event.id)}
              zapDisabled={!canActiveAccountPublish}
              {onZap}
              onReply={onReply}
              repostPending={repostPendingNoteIds.has(event.id)}
              onQuote={onQuote}
              onRepost={onRepost}
              onOpenReactions={(nextEvent) => onOpenReactions(nextEvent, 'likes')}
              onCopyLink={onCopyLink}
              onShare={onShare}
              onCopyEventId={onCopyEventId}
              onRebroadcast={onRebroadcast}
              {onDelete}
              rebroadcastPending={rebroadcastPendingNoteIds.has(event.id)}
              onOpenMedia={onOpenMedia}
              onOpenProfile={onOpenProfile}
              onOpenNote={onOpenNote}
              isActive={isActive && feedProjectionVisible}
              onPresented={isActive && feedProjectionVisible ? onNotePresented : null}
              onVisible={isActive && feedProjectionVisible ? onNoteVisible : null}
              {resolveReferencedNote}
            />
          {/each}
        </div>
      </div>
    {/if}

    {#if mediaProjectionMounted}
      <div
        data-testid="home-media-projection"
        hidden={!mediaProjectionVisible}
        aria-hidden={!mediaProjectionVisible}
      >
        <MediaGrid
          events={filteredNotes}
          isActive={isActive && mediaProjectionVisible}
          onOpenMedia={onOpenMedia}
          emptyLabel={homeFeedHasMore ? 'No matching media yet. Load more to keep looking.' : 'No media yet.'}
        />
      </div>
    {/if}
    {#if feedProjectionVisible && filteredNotes.length === 0}
      <div class="border-b border-white/5 px-4 py-7 text-[1rem] text-white/60 sm:px-5">
        {homeFeedHasMore ? 'No matches yet. Load more to keep looking.' : homeNotes.length > 0 ? 'No posts match these filters.' : 'No posts yet.'}
      </div>
    {/if}
  {/if}

  {#if activeTab !== 'notifications' && (homeFeedHasMore || homeFeedLoadPending)}
    <div class="grid gap-0">
      {#if homeFeedLoadPending}
        <div class="border-b border-white/5 px-4 py-3 text-center text-[0.92rem] text-white/60 sm:px-5">
          Loading more posts...
        </div>
      {:else if homeFeedHasMore && onLoadMore}
        <div class="border-b border-white/5 px-4 py-3 text-center sm:px-5">
          <button
            data-testid="home-feed-load-more"
            type="button"
            class="rounded-full border border-white/10 bg-[#111111] px-4 py-2 text-[0.9rem] font-700 text-white/75 transition hover:bg-[#1a1a1a] hover:text-white"
            on:click={onLoadMore}
          >
            Load more
          </button>
        </div>
      {/if}

      {#if isActive && homeFeedInfiniteScroll}
        <div
          data-testid="home-feed-infinite-sentinel"
          use:homeFeedInfiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>
