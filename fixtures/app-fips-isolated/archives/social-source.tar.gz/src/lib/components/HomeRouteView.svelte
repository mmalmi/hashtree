<script lang="ts">
  import { contactMemoryStore } from '../contactMemoryStore';
  import { favoriteContactPubkeys } from '../appFavoritesFeed';
  import { onDestroy } from 'svelte';
  import { getKind6RepostTargetEventId, rankedFeedCardKeys, requestEmbeddedRepostAdmission, resolveKind6RepostTarget } from '../repostPresentation';
  import { feedFilterScope, feedFiltersStore, filterHomeFeedEvents, readFeedFilters, needsRepostFilterTargets, type FeedFilters } from '../feedFilters';
  import type { Action } from 'svelte/action';
  import FeedCard from './FeedCard.svelte';
  import FeedViewSelector from './FeedViewSelector.svelte';
  import InlineFeedSettings, { type FeedSettingsContext } from './InlineFeedSettings.svelte';
  import FeedTabSwitcher from './FeedTabSwitcher.svelte';
  import {
    createCustomFeed, findCustomFeed, homeFeedLayoutsStore, homeFeedTabKey, pendingNewFeedStore, readHomeFeedLayout,
  } from '../homeFeedTabs';
  import { readHomeFeedSeenEventIds } from '../homeFeedSeen';
  import { getActiveAppScrollElement } from '../appScroll';
  import MediaGrid from './MediaGrid.svelte';
  import NotificationFeed from './NotificationFeed.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import { ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from '../noteEngagement';
  import type { NoteEmbed } from '../noteContent';
  import type { ReferencedNotePreview } from '../referencedNote';
  import type { NotificationItem } from '../appDetailLoaders';
  import type { NoteDetailListKind } from '../nostrIndex';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import type { FeedLayout } from '../feedLayout';
  import type { FeedView } from '../feedView';
  import { CUSTOM_FEED_BASES, type CustomFeedBase, type HomeTab } from '../routes';
  import { buildNoteThreadReference } from '../appSharing';

  export let activeTab: HomeTab = 'latest';
  export let activeFeedId: string | null = null;
  export let feedLayout: FeedLayout = 'cozy';
  export let feedView: FeedView = 'feed';
  export let showFeedViewSelector = true;
  export let loading = false;
  export let refreshing = false;
  export let initialReadPending = false;
  export let snapshotPending = false;
  export let isActive = false;
  export let canActiveAccountPublish = false;
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let onToggleMute: ((pubkey: string, nextMuted: boolean) => void) | null = null;
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let noteEngagements: Map<string, NoteEngagement> = new Map();
  export let homeNotes: RawEvent[] = [];
  export let homeFeedHasMore = false;
  export let homeFeedLoadPending = false;
  export let homeFeedInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let bufferedLiveHomePostCount = 0;
  export let feedSourceLabel = 'Following';
  export let feedSourceId: string | null = null;
  export let notifications: NotificationItem[] = [];
  export let notificationsLoading = false;
  export let notificationsHasMore = false;
  export let notificationsLoadPending = false;
  export let notificationsInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreNotifications: (() => void) | null = null;
  export let activeMediaEventId: string | null = null;
  export let activeMediaUrl: string | null = null;
  export let likePendingNoteIds: Set<string> = new Set();
  export let zapPendingNoteIds: Set<string> = new Set();
  export let repostPendingNoteIds: Set<string> = new Set();
  export let rebroadcastPendingNoteIds: Set<string> = new Set();
  export let onSelectHomeTab: (tab: HomeTab, feedId?: string | null) => void = () => undefined;
  export let onSelectFeedView: (view: FeedView) => void = () => undefined;
  export let feedSettings: FeedSettingsContext | null = null;
  export let onOpenFeedSources: (() => void) | null = null;
  export let onShowBufferedLivePosts: (() => void) | null = null;
  export let onLoadMore: (() => void) | null = null;
  export let onLike: (event: RawEvent) => void = () => undefined;
  export let onZap: (event: RawEvent) => void = () => undefined;
  export let onZapAll: (events: RawEvent[]) => void = () => undefined;
  export let onReply: (event: RawEvent) => void = () => undefined;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: (event: RawEvent) => void = () => undefined;
  export let onOpenReactions: (event: RawEvent, kind?: NoteDetailListKind) => void = () => undefined;
  export let onCopyLink: (event: RawEvent) => void = () => undefined;
  export let onShare: (event: RawEvent) => void = () => undefined;
  export let onCopyEventId: (event: RawEvent) => void = () => undefined;
  export let onRebroadcast: (event: RawEvent) => void = () => undefined;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onOpenNote: (target: string) => void = () => undefined;
  export let onNotePresented: ((event: RawEvent) => void) | null = null;
  export let onNoteVisible: ((event: RawEvent, presentedEvent: RawEvent | null) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;

  $: settingsSourceLabel = activeTab === 'favorites' ? 'Favorites' : feedSourceLabel;
  $: filterScope = feedFilterScope(viewerPubkey, feedSourceId, activeTab, activeFeedId);
  $: feedFilters = readFeedFilters($feedFiltersStore, filterScope);
  let resolvedFilterReposts = new Map<string, RawEvent>();
  let filterResolutionVersion = 0;
  // "Hide posts you've seen" uses the posts seen before the feed opened, so
  // posts the reader sees now stay in place.
  let seenAtOpen: Set<string> | null = null;
  let seenAtOpenKey = '';
  $: {
    const key = feedFilters.hideSeen && viewerPubkey ? `${viewerPubkey}:${filterScope}` : '';
    if (key !== seenAtOpenKey) {
      seenAtOpenKey = key;
      seenAtOpen = key && viewerPubkey ? readHomeFeedSeenEventIds(viewerPubkey) : null;
    }
  }
  $: filteredNotes = filterHomeFeedEvents(homeNotes, feedFilters, resolvedFilterReposts, seenAtOpen);
  // "Show new posts automatically" reveals them only while the reader is at the top.
  $: if (feedFilters.autoShowNew && isActive && bufferedLiveHomePostCount > 0 && onShowBufferedLivePosts
    && (getActiveAppScrollElement()?.scrollTop ?? 0) <= 4) {
    onShowBufferedLivePosts();
  }
  $: cardKeys = activeTab === 'for-you' ? rankedFeedCardKeys(filteredNotes) : null;
  $: hydrateRepostFilterTargets(homeNotes, feedFilters, isActive, resolveReferencedNote);

  let filterButton: HTMLButtonElement;
  /** New feed next to the open tab, built on it when possible, with its settings open. */
  function createFeed(): void {
    const base: CustomFeedBase = (CUSTOM_FEED_BASES as readonly HomeTab[]).includes(activeTab)
      ? activeTab as CustomFeedBase
      : 'latest';
    const feed = createCustomFeed(viewerPubkey, base, homeFeedTabKey(activeTab, activeFeedId));
    if (!feed) { return; }
    pendingNewFeedStore.set({ viewer: viewerPubkey!, id: feed.id, returnTab: activeTab, returnFeedId: activeFeedId });
    onSelectHomeTab(feed.base, feed.id);
    if (!feedSettings) { onOpenFeedSources?.(); }
  }

  function closeFeedSettings(): void {
    // A new feed stops being cancellable once its settings are closed.
    if ($pendingNewFeedStore?.id === activeFeedId) { pendingNewFeedStore.set(null); }
    feedSettings?.actions.setFeedSourceSheetOpen(false);
    filterButton?.focus({ preventScroll: true });
  }

  function handleFeedKeydown(event: KeyboardEvent): void {
    if (!feedSettings || event.key !== 'Escape' || event.defaultPrevented || event.isComposing) { return; }
    const target = event.target;
    if (!(target instanceof Element) || (target !== filterButton && !target.closest('#home-feed-settings'))) { return; }
    event.preventDefault();
    closeFeedSettings();
  }

  function hydrateRepostFilterTargets(
    notes: RawEvent[],
    filters: FeedFilters,
    active: boolean,
    resolver: typeof resolveReferencedNote,
  ): void {
    const version = ++filterResolutionVersion;
    if (!active || !needsRepostFilterTargets(filters)) { return; }
    const knownIds = new Set(notes.map((event) => event.id));
    const queue = notes.filter((event) => event.kind === 6
      && !resolvedFilterReposts.has(event.id)
      && !knownIds.has(getKind6RepostTargetEventId(event) ?? ''));
    const run = async () => {
      while (version === filterResolutionVersion && queue.length) {
        const event = queue.shift()!;
        try {
          await requestEmbeddedRepostAdmission(event);
          if (version !== filterResolutionVersion) { return; }
          const target = await resolveKind6RepostTarget(event, resolver);
          if (version !== filterResolutionVersion) { return; }
          if (target) {
            const next = new Map(resolvedFilterReposts).set(event.id, target.event);
            while (next.size > 2048) { next.delete(next.keys().next().value!); }
            resolvedFilterReposts = next;
          }
        } catch { /* An unavailable target remains excluded until a later feed load. */ }
      }
    };
    for (let index = 0; index < Math.min(4, queue.length); index += 1) { void run(); }
  }

  onDestroy(() => { filterResolutionVersion += 1; });

  // Mount each layout on first use, then retain it for immediate switches.
  let feedProjectionMounted = false;
  let mediaProjectionMounted = false;
  let renderedFeedNotes: RawEvent[] = [];
  let hiddenFeedFrame: number | null = null;

  function cancelHiddenFeedUpdate(): void {
    if (hiddenFeedFrame !== null) {
      window.cancelAnimationFrame(hiddenFeedFrame);
      hiddenFeedFrame = null;
    }
  }

  function updateRenderedFeedNotes(notes: RawEvent[], hidden: boolean): void {
    cancelHiddenFeedUpdate();
    if (!hidden || typeof window === 'undefined') {
      renderedFeedNotes = notes;
      return;
    }
    // A grid asks for more candidates than rows. Keep the retained row list,
    // then prepare its extra cards in bounded frames while it is hidden.
    // Returning to rows always adopts the complete current projection.
    if (notes.length === renderedFeedNotes.length
      && notes.every((note, index) => note === renderedFeedNotes[index])) {
      return;
    }
    let count = renderedFeedNotes.every((note, index) => note === notes[index])
      ? renderedFeedNotes.length : 0;
    const advance = () => {
      hiddenFeedFrame = null;
      count = Math.min(notes.length, count + 8);
      renderedFeedNotes = notes.slice(0, count);
      if (count < notes.length) {
        hiddenFeedFrame = window.requestAnimationFrame(advance);
      }
    };
    hiddenFeedFrame = window.requestAnimationFrame(advance);
  }

  onDestroy(cancelHiddenFeedUpdate);

  let online = navigator.onLine;
  let emptyConfirmed = false;
  let emptyTimer: ReturnType<typeof setTimeout> | undefined;

  // The feed may briefly finish a local read before its next source starts.
  // Defer only the empty-state message. Verified rows are always paintable.
  function confirmEmptyForYou(candidate: boolean, connected: boolean, _scope: string | null): void {
    clearTimeout(emptyTimer);
    emptyConfirmed = false;
    if (!candidate) { return; }
    if (!connected) { emptyConfirmed = true; return; }
    emptyTimer = setTimeout(() => { emptyConfirmed = true; }, 350);
  }
  $: checkingForYou = activeTab === 'for-you' && !homeNotes.length && (snapshotPending || (online && (initialReadPending || loading || refreshing)));
  $: confirmEmptyForYou(isActive && activeTab === 'for-you' && !homeNotes.length && !checkingForYou, online, filterScope);
  $: pendingForYou = activeTab === 'for-you' && !homeNotes.length && !emptyConfirmed;
  onDestroy(() => clearTimeout(emptyTimer));

  $: customFeed = findCustomFeed(readHomeFeedLayout($homeFeedLayoutsStore, viewerPubkey), activeFeedId);
  $: choosesPeople = activeTab === 'favorites' && Boolean(customFeed?.people);
  $: hasFavorites = choosesPeople
    ? (customFeed?.people ?? []).length > 0
    : favoriteContactPubkeys($contactMemoryStore, viewerPubkey).length > 0;
  $: mediaProjectionVisible = showFeedViewSelector && feedView === 'media-grid';
  $: feedProjectionVisible = activeTab !== 'notifications' && !mediaProjectionVisible;
  $: updateRenderedFeedNotes(filteredNotes, mediaProjectionVisible);
  $: newPostsLabel = bufferedLiveHomePostCount === 1 ? 'new post' : 'new posts';
  $: if (isActive && feedProjectionVisible) {
    feedProjectionMounted = true;
  }
  $: if (isActive && mediaProjectionVisible) {
    mediaProjectionMounted = true;
  }
</script>

<svelte:window bind:online />

<!-- svelte-ignore a11y_no_static_element_interactions -->
<section
  on:keydown={handleFeedKeydown}
  data-testid="home-route-view"
  aria-busy={activeTab === 'for-you' && !homeNotes.length ? pendingForYou : loading || refreshing}
  class="min-h-[calc(100dvh-8rem)] md:min-h-[calc(100dvh-4rem)]"
>
  <div data-testid="home-feed-controls" class={viewerPubkey ? 'border-b border-divider' : 'relative'}>
    {#if !viewerPubkey && activeTab === 'popular'}
      <h1 data-testid="guest-feed-title" class="m-0 px-4 py-3 text-[1.1rem] font-700 sm:px-5 md:hidden">Popular</h1>
    {/if}
    <div
      data-testid="home-feed-actions"
      class={viewerPubkey
        ? 'feed-toolbar grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-x-2 gap-y-1 bg-[var(--iris-surface-subtle)] px-3 py-2 sm:px-4 md:grid-cols-[auto_minmax(0,1fr)_auto_auto]'
        : 'pointer-events-none absolute inset-x-0 top-full z-10 flex justify-center'}
    >
      {#if viewerPubkey}
        {#if onOpenFeedSources && activeTab !== 'notifications'}
          <button
            type="button"
            bind:this={filterButton}
            data-testid="feed-source-button"
            aria-expanded={Boolean(feedSettings)}
            aria-controls={feedSettings ? 'home-feed-settings' : undefined}
            class="iris-neutral-button col-start-1 row-start-1 inline-flex h-9 w-9 items-center justify-center rounded-full text-[rgb(var(--iris-text-rgb))] transition"
            aria-label={`Feed settings, ${settingsSourceLabel}`}
            title={`Feed settings · ${settingsSourceLabel}`}
            on:click={feedSettings ? closeFeedSettings : onOpenFeedSources}
          >
            <IrisIcon name="settings-04" size={17} />
            <span class="sr-only">{settingsSourceLabel}</span>
          </button>
        {/if}
        <div class="col-start-2 col-end-4 row-start-1 min-w-0 md:col-end-3">
          <FeedTabSwitcher {activeTab} {activeFeedId} {viewerPubkey} onSelectTab={onSelectHomeTab}
            onCreateFeed={onOpenFeedSources ? createFeed : null} />
        </div>
      {/if}

      {#if activeTab !== 'notifications' && isActive && bufferedLiveHomePostCount > 0 && onShowBufferedLivePosts}
        <button
          data-testid="show-new-posts"
          type="button"
          class="iris-preserve-white-text pointer-events-auto col-start-2 row-start-2 inline-flex h-7 items-center justify-self-start gap-1 whitespace-nowrap rounded-full bg-violet-700 px-2 text-[0.84rem] font-700 tabular-nums md:col-start-3 md:row-start-1"
          aria-label={`${bufferedLiveHomePostCount} ${newPostsLabel}`}
          on:click={onShowBufferedLivePosts}
        >
          {#if viewerPubkey}<span class="new-posts-arrow"><IrisIcon name="arrowUp" size={14} /></span>{/if}
          <span>{bufferedLiveHomePostCount}<span class:compact-label={viewerPubkey}>{` ${newPostsLabel}`}</span></span>
        </button>
      {/if}
      {#if showFeedViewSelector && onSelectFeedView && activeTab !== 'notifications'}
        <div class="col-span-full row-start-2 w-20 justify-self-center md:col-start-4 md:col-end-5 md:row-start-1 md:justify-self-end">
          <FeedViewSelector {feedView} onSelect={onSelectFeedView} />
        </div>
      {/if}
    </div>

    {#if feedSettings && viewerPubkey}
      <InlineFeedSettings context={feedSettings} {activeTab} {activeFeedId} {viewerPubkey}
        onClose={closeFeedSettings} onSelectFeed={onSelectHomeTab} {profiles}>
        {#if canActiveAccountPublish && feedProjectionVisible && filteredNotes.length > 0}
          <button
            data-testid="feed-zap-all-button"
            type="button"
            class="iris-neutral-button mt-2 inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-700 text-white"
            on:click={() => onZapAll(filteredNotes)}
          >
            <IrisIcon name="zap-solid" size={17} className="text-[#fbbf24]" />
            Zap all <span class="text-white/60 tabular-nums">({filteredNotes.length})</span>
          </button>
        {/if}
      </InlineFeedSettings>
    {/if}
    <slot />
  </div>

  {#if activeTab === 'notifications'}
    <NotificationFeed
      items={notifications}
      profiles={profiles}
      loading={loading || notificationsLoading}
      hasMore={notificationsHasMore}
      loadPending={notificationsLoadPending}
      infiniteScroll={isActive ? notificationsInfiniteScroll : null}
      onLoadMore={onLoadMoreNotifications}
      onOpenProfile={onOpenProfile}
      onOpenNote={onOpenNote}
    />
  {:else if activeTab === 'favorites' && !hasFavorites}
    <div data-testid="favorites-empty" class="border-b border-divider px-4 py-7 text-[1rem] text-white/60 sm:px-5">
      {choosesPeople
        ? 'Add people in this feed’s settings to see their posts here.'
        : 'Star someone’s profile to see their posts here. Only you can see your favorites.'}
    </div>
  {:else}
    <!-- Keep the list mounted while a refresh loads to avoid remount flicker. -->
    {#if feedProjectionMounted && filteredNotes.length > 0}
      <div
        data-testid="home-feed-projection"
        hidden={!feedProjectionVisible}
        aria-hidden={!feedProjectionVisible}
      >
        <div data-testid="latest-feed" class="grid gap-0">
          {#each renderedFeedNotes as event (cardKeys?.get(event.id) ?? event.id)}
            <FeedCard
              {event}
              {profiles}
              {viewerPubkey}
              {viewerFollows}
              {followPendingPubkeys}
              {onToggleFollow}
              {mutedPubkeys}
              {mutePendingPubkeys}
              {onToggleMute}
              compact={feedLayout === 'compact'}
              showRepliedTo={(activeTab === 'latest' || activeTab === 'favorites') && feedFilters.showRepliedTo}
              profile={profiles.get(event.pubkey) ?? null}
              engagement={noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT}
              engagements={noteEngagements}
              activeMediaUrl={activeMediaEventId === event.id ? activeMediaUrl : null}
              liked={(noteEngagements.get(event.id) ?? ZERO_NOTE_ENGAGEMENT).viewerReacted}
              likePending={likePendingNoteIds.has(event.id)}
              likeDisabled={!canActiveAccountPublish}
              onLike={onLike}
              zapPending={zapPendingNoteIds.has(event.id)}
              zapDisabled={!canActiveAccountPublish}
              {onZap}
              onReply={onReply}
              repostPending={repostPendingNoteIds.has(event.id)}
              onQuote={onQuote}
              onRepost={onRepost}
              onOpenReactions={(nextEvent) => onOpenReactions(nextEvent, 'likes')}
              onCopyLink={onCopyLink}
              onShare={onShare}
              onCopyEventId={onCopyEventId}
              onRebroadcast={onRebroadcast}
              {onDelete}
              rebroadcastPending={rebroadcastPendingNoteIds.has(event.id)}
              onOpenMedia={onOpenMedia}
              onOpenProfile={onOpenProfile}
              onOpenNote={onOpenNote}
              isActive={isActive && feedProjectionVisible}
              onPresented={isActive && feedProjectionVisible ? onNotePresented : null}
              onVisible={isActive && feedProjectionVisible ? onNoteVisible : null}
              {resolveReferencedNote}
            />
          {/each}
        </div>
      </div>
    {/if}

    {#if mediaProjectionMounted && !pendingForYou && (!loading || filteredNotes.length > 0)}
      <div
        data-testid="home-media-projection"
        hidden={!mediaProjectionVisible}
        aria-hidden={!mediaProjectionVisible}
      >
        <MediaGrid
          events={filteredNotes}
          isActive={isActive && mediaProjectionVisible}
          onOpenMedia={onOpenMedia}
          emptyLabel={homeFeedHasMore ? 'No matching media yet. Load more to keep looking.' : 'No media yet.'}
        />
      </div>
    {/if}
    {#if pendingForYou}
      <div data-testid="for-you-loading" role="status" class="feed-loading">
        <span class="sr-only">Loading For you posts…</span>
        {#each [0, 1] as row (row)}
          <div class="feed-loading-row" aria-hidden="true"><i></i><div><b></b><b></b></div></div>
        {/each}
      </div>
    {:else if (!loading || (activeTab === 'for-you' && emptyConfirmed)) && feedProjectionVisible && filteredNotes.length === 0}
      <div class="border-b border-divider px-4 py-7 text-[1rem] text-white/60 sm:px-5">
        {homeFeedHasMore ? 'No matches yet. Load more to keep looking.' : homeNotes.length > 0 ? 'No posts match these filters.' : activeTab === 'popular' ? 'No popular posts available yet.' : 'No posts yet.'}
      </div>
    {/if}
  {/if}

  {#if activeTab !== 'notifications' && (homeFeedHasMore || homeFeedLoadPending)}
    <div class="grid gap-0">
      {#if homeFeedLoadPending}
        <div class="border-b border-divider px-4 py-3 text-center text-[0.92rem] text-white/60 sm:px-5">
          Loading more posts...
        </div>
      {:else if homeFeedHasMore && onLoadMore}
        <div class="border-b border-divider px-4 py-3 text-center sm:px-5">
          <button
            data-testid="home-feed-load-more"
            type="button"
            class="rounded-full iris-neutral-button px-4 py-2 text-[0.9rem] font-700 text-white/75 transition hover:text-white"
            on:click={onLoadMore}
          >
            Load more
          </button>
        </div>
      {/if}

      {#if isActive && homeFeedInfiniteScroll}
        <div
          data-testid="home-feed-infinite-sentinel"
          use:homeFeedInfiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>

<style>
  .feed-loading-row { display: flex; align-items: flex-start; gap: .7rem; padding: .9rem 1rem 1.25rem; border-bottom: 1px solid var(--iris-divider); }
  .feed-loading-row i, .feed-loading-row b { display: block; background: var(--iris-surface-raised); border-radius: 1rem; }
  .feed-loading-row i { width: 2.5rem; height: 2.5rem; border-radius: 50%; }
  .feed-loading-row div { flex: 1; padding-top: .25rem; }
  .feed-loading-row b { width: 6rem; height: .6rem; }
  .feed-loading-row b + b { margin-top: 1rem; width: min(72%, 24rem); }

  .feed-toolbar {
    container-type: inline-size;
  }

  .new-posts-arrow {
    display: none;
  }

  @container (max-width: 28rem) {
    .new-posts-arrow {
      display: inline-flex;
    }

    .compact-label {
      display: none;
    }
  }
</style>
