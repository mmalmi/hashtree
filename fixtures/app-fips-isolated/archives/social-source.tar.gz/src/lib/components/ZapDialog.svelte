<script lang="ts">
  import { onDestroy, onMount, tick } from 'svelte';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';
  import WalletQr from './wallet/WalletQr.svelte';
  import { errorMessage, formatBits } from './wallet/walletUi';
  import type { ZapOutcome, ZapRequestOptions } from '../appZapActions';
  import { ensureExchangeRates, exchangeRateStore } from '../exchangeRateStore';
  import { formatSatsAmount } from '../exchangeRates';
  import { getProfileTitle } from '../nostr';
  import { formatCompactStat } from '../noteEngagement';
  import { MAX_DEFAULT_ZAP_BITS, MAX_ZAP_COMMENT_LENGTH, settingsStore } from '../settings';
  import type { ZapDialogInvoice, ZapDialogRequest } from '../zapDialog';
  import { DEFAULT_ZAP_BITS, ZAP_AMOUNT_PRESETS, lightningPaymentUrl } from '../zaps';

  export let open = false;
  export let request: ZapDialogRequest;
  export let canZap = true;
  export let onClose: () => void;
  export let onZap: (options: ZapRequestOptions) => Promise<ZapOutcome>;

  const titleId = `zap-dialog-title-${Math.random().toString(36).slice(2)}`;
  const defaults = settingsStore.getState().wallet;
  let amount: number | null = request.invoice?.amountBits ?? (defaults.defaultZapBits || DEFAULT_ZAP_BITS);
  let comment = defaults.defaultZapComment;
  let saveDefault = false;
  let pending = false;
  let error = '';
  let invoice: ZapDialogInvoice | null = request.invoice;
  let dialog: HTMLDivElement | null = null;
  const returnFocus = typeof document !== 'undefined' && document.activeElement instanceof HTMLElement
    ? document.activeElement
    : null;

  $: validAmount = typeof amount === 'number' && Number.isSafeInteger(amount)
    && amount > 0 && amount <= MAX_DEFAULT_ZAP_BITS ? amount : null;
  $: recipient = getProfileTitle(request.profile, request.event.pubkey);
  $: currency = $settingsStore.wallet.primaryCurrency;
  $: if (open) {ensureExchangeRates(currency);}
  $: fiatHint = validAmount && currency !== 'SAT' && currency !== 'BTC'
    ? formatSatsAmount(validAmount, currency, $exchangeRateStore)
    : '';

  onMount(() => {
    void tick().then(() => dialog?.focus({ preventScroll: true }));
  });

  onDestroy(() => {
    if (returnFocus?.isConnected && !returnFocus.closest('[inert]')) {returnFocus.focus({ preventScroll: true });}
  });

  function trapFocus(event: KeyboardEvent): void {
    if (event.key !== 'Tab' || !dialog) {return;}
    const focusable = [...dialog.querySelectorAll<HTMLElement>(
      'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled])',
    )].filter((element) => element.getClientRects().length > 0);
    const first = focusable[0] ?? dialog;
    const last = focusable.at(-1) ?? dialog;
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  async function submit(): Promise<void> {
    if (pending || !validAmount || !canZap) {return;}
    const trimmedComment = comment.trim();
    if (saveDefault) {
      settingsStore.setWalletSettings({ defaultZapBits: validAmount, defaultZapComment: trimmedComment });
    }
    pending = true;
    error = '';
    try {
      const outcome = await onZap({ amountBits: validAmount, comment: trimmedComment });
      if (outcome.status === 'paid') {
        onClose();
      } else {
        invoice = { invoice: outcome.invoice, amountBits: outcome.amountBits };
      }
    } catch (nextError) {
      error = errorMessage(nextError);
    } finally {
      pending = false;
    }
  }

  const chipClass = 'min-h-11 rounded-2xl text-[0.95rem] font-700 tabular-nums transition';
  const fieldClass = 'w-full rounded-2xl bg-[rgb(var(--iris-text-rgb)/0.07)] px-4 py-3 text-[0.95rem] outline-none transition placeholder:text-[rgb(var(--iris-text-rgb)/0.4)] focus:bg-[rgb(var(--iris-text-rgb)/0.1)]';
</script>

<ModalShell
  {open}
  {onClose}
  shellClass="items-end justify-center p-3 sm:items-center sm:p-5"
  contentClass="max-h-[calc(100dvh-1.5rem)] w-full max-w-[26rem] overflow-y-auto rounded-3xl"
  backdropClass="bg-black/70 backdrop-blur-sm"
>
  <div
    bind:this={dialog}
    data-testid="zap-dialog"
    data-note-no-thread-nav
    role="dialog"
    aria-modal="true"
    aria-labelledby={titleId}
    tabindex="-1"
    class="grid gap-4 rounded-3xl bg-[var(--iris-surface-raised)] p-5 text-[rgb(var(--iris-text-rgb))] shadow-2xl outline-none"
    on:keydown={trapFocus}
  >
    <header class="flex items-center gap-3">
      <Avatar pubkey={request.event.pubkey} profile={request.profile} size={40} showBadge={false} />
      <h2 id={titleId} class="min-w-0 flex-1 truncate text-lg font-700">Zap {recipient}</h2>
      <button
        type="button"
        aria-label="Close zap"
        class="grid h-10 w-10 shrink-0 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.65)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)]"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={20} />
      </button>
    </header>

    {#if invoice}
      <div data-testid="zap-dialog-invoice" class="grid gap-3">
        <p class="m-0 text-center text-sm text-[rgb(var(--iris-text-rgb)/0.65)]">Scan or copy to pay {formatBits(invoice.amountBits)}</p>
        <WalletQr value={invoice.invoice} label="Lightning invoice" />
        <a
          data-testid="zap-dialog-open-wallet"
          href={lightningPaymentUrl(invoice.invoice)}
          class="flex min-h-11 items-center justify-center gap-2 rounded-full bg-amber-400 px-5 font-700 text-amber-950 no-underline transition hover:bg-amber-300"
        >
          <IrisIcon name="zap-solid" size={18} />
          Open in wallet
        </a>
      </div>
    {:else}
      <form class="grid gap-3" on:submit|preventDefault={() => void submit()}>
        <div class="grid grid-cols-3 gap-2" role="group" aria-label="Amount presets">
          {#each ZAP_AMOUNT_PRESETS as preset}
            <button
              type="button"
              data-testid={`zap-dialog-preset-${preset}`}
              aria-pressed={validAmount === preset}
              class={`${chipClass} ${validAmount === preset
                ? 'bg-amber-400 text-amber-950'
                : 'bg-[rgb(var(--iris-text-rgb)/0.07)] hover:bg-[rgb(var(--iris-text-rgb)/0.12)]'}`}
              on:click={() => { amount = preset; }}
            >
              {formatCompactStat(preset)}
            </button>
          {/each}
        </div>

        <label class="relative block">
          <span class="sr-only">Amount in bits</span>
          <input
            data-testid="zap-dialog-amount"
            type="number"
            inputmode="numeric"
            min="1"
            max={MAX_DEFAULT_ZAP_BITS}
            step="1"
            bind:value={amount}
            class={`${fieldClass} pr-24 tabular-nums`}
          />
          <span class="pointer-events-none absolute inset-y-0 right-4 flex items-center gap-2 text-sm text-[rgb(var(--iris-text-rgb)/0.5)]">
            {#if fiatHint}<span data-testid="zap-dialog-fiat">≈ {fiatHint}</span>{/if}
            bits
          </span>
        </label>

        <label class="block">
          <span class="sr-only">Comment</span>
          <input
            data-testid="zap-dialog-comment"
            type="text"
            maxlength={MAX_ZAP_COMMENT_LENGTH}
            placeholder="Comment (optional)"
            bind:value={comment}
            class={fieldClass}
          />
        </label>

        <label class="flex w-fit cursor-pointer items-center gap-2 px-1 text-sm text-[rgb(var(--iris-text-rgb)/0.7)]">
          <input data-testid="zap-dialog-save-default" type="checkbox" bind:checked={saveDefault} class="h-4 w-4 accent-amber-400" />
          Save as default
        </label>

        {#if !canZap}<p class="m-0 px-1 text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">Sign in with a profile that can publish to zap.</p>{/if}
        {#if error}<p data-testid="zap-dialog-error" role="alert" class="m-0 px-1 text-sm text-red-400">{error}</p>{/if}

        <button
          data-testid="zap-dialog-submit"
          type="submit"
          disabled={pending || !validAmount || !canZap}
          class="flex min-h-12 items-center justify-center gap-2 rounded-full bg-amber-400 px-5 font-700 text-amber-950 transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <IrisIcon name="zap-solid" size={18} />
          {#if pending}Zapping…{:else if validAmount}Zap {formatBits(validAmount)}{:else}Enter an amount{/if}
        </button>
      </form>
    {/if}
  </div>
</ModalShell>
