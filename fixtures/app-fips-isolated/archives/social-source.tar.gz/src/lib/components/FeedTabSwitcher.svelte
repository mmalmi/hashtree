<script lang="ts">
  import type { HomeTab } from '../routes';
  import {
    homeFeedLayoutsStore,
    homeFeedTabKey,
    readHomeFeedLayout,
    visibleHomeFeedTabs,
    type HomeFeedTab,
  } from '../homeFeedTabs';
  import IrisIcon from './IrisIcon.svelte';

  export let activeTab: HomeTab = 'latest';
  export let activeFeedId: string | null = null;
  export let viewerPubkey: string | null = null;
  export let onSelectTab: ((tab: HomeTab, feedId: string | null) => void) | null = null;
  export let onCreateFeed: (() => void) | null = null;

  const FALLBACK_LABELS: Partial<Record<HomeTab, string>> = {
    'for-you': 'For you', latest: 'Latest', favorites: 'Favorites', media: 'Media',
  };

  $: activeKey = homeFeedTabKey(activeTab, activeFeedId);
  $: visibleTabs = visibleHomeFeedTabs(readHomeFeedLayout($homeFeedLayoutsStore, viewerPubkey));
  // A hidden or removed feed opened from a link still shows where the reader is.
  $: tabs = visibleTabs.some((tab) => tab.key === activeKey)
    ? visibleTabs
    : [...visibleTabs, {
        key: activeKey,
        label: activeFeedId ? 'Feed' : FALLBACK_LABELS[activeTab] ?? 'Feed',
        tab: activeTab,
        feedId: activeFeedId,
      } satisfies HomeFeedTab];
</script>

<div
  data-testid="feed-tab-switcher"
  role="tablist"
  aria-label="Home feeds"
  class="flex min-w-0 gap-1 overflow-x-auto sm:gap-2 py-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
>
  {#each tabs as tab (tab.key)}
    <button
      type="button"
      role="tab"
      aria-selected={activeKey === tab.key}
      data-testid={`feed-tab-${tab.feedId ? 'custom' : tab.key}`}
      data-feed-key={tab.key}
      class={`shrink-0 whitespace-nowrap rounded-full px-2 py-2 text-[0.82rem] font-700 transition sm:px-4 ${
        activeKey === tab.key
          ? 'iris-preserve-white-text bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-[0_8px_22px_rgba(124,58,237,0.22)]'
          : 'iris-neutral-button text-[rgb(var(--iris-text-rgb))]'
      }`}
      on:click={() => onSelectTab?.(tab.tab, tab.feedId)}
    >
      {tab.label}
    </button>
  {/each}
  {#if onCreateFeed && viewerPubkey}
    <button
      type="button"
      data-testid="feed-tab-new"
      aria-label="New feed"
      title="New feed"
      class="iris-neutral-button grid aspect-square shrink-0 place-items-center rounded-full text-[rgb(var(--iris-text-rgb))]"
      on:click={onCreateFeed}
    >
      <IrisIcon name="plus" size={15} />
    </button>
  {/if}
</div>
