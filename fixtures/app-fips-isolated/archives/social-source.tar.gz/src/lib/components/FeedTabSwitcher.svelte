<script lang="ts">
  import type { FeedView } from '../feedView';
  import type { HomeTab } from '../routes';
  import FeedViewSelector from './FeedViewSelector.svelte';
  import IrisIcon from './IrisIcon.svelte';

  export let activeTab: HomeTab = 'latest';
  export let feedView: FeedView = 'feed';
  export let showFeedViewSelector = true;
  export let feedSourceLabel = 'Following';
  export let onSelectTab: ((tab: HomeTab) => void) | null = null;
  export let onSelectFeedView: ((view: FeedView) => void) | null = null;
  export let onOpenSources: (() => void) | null = null;

  const tabs: { key: HomeTab; label: string }[] = [
    { key: 'latest', label: 'Latest' },
    { key: 'for-you', label: 'For you' },
    { key: 'favorites', label: 'Favorites' },
    { key: 'media', label: 'Media' },
  ];
</script>

<div
  data-testid="feed-tab-switcher"
  class="grid gap-1"
>
  <div class="flex max-w-full items-center gap-2 overflow-hidden">
    {#if onOpenSources}
      <button
        type="button"
        data-testid="feed-source-button"
        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#151515] text-white/65 transition hover:bg-[#222222] hover:text-white"
        aria-label={`Feed settings, ${feedSourceLabel}`}
        title={`Feed settings · ${feedSourceLabel}`}
        on:click={() => onOpenSources?.()}
      >
        <IrisIcon name="settings-04" size={17} />
        <span class="sr-only">{feedSourceLabel}</span>
      </button>
    {/if}

    <div class="flex min-w-0 flex-1 gap-2 overflow-x-auto py-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      {#each tabs as tab (tab.key)}
        <button
          type="button"
          role="tab"
          aria-selected={activeTab === tab.key}
          data-testid={`feed-tab-${tab.key}`}
          class={`shrink-0 whitespace-nowrap rounded-full px-4 py-2 text-[0.82rem] font-700 transition ${
            activeTab === tab.key
              ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-[0_8px_22px_rgba(124,58,237,0.22)]'
              : 'bg-[#151515] text-white/60 hover:bg-[#222222] hover:text-white'
          }`}
          on:click={() => onSelectTab?.(tab.key)}
        >
          {tab.label}
        </button>
      {/each}
    </div>
  </div>

  {#if showFeedViewSelector && onSelectFeedView}
    <FeedViewSelector {feedView} onSelect={onSelectFeedView} />
  {/if}
</div>
