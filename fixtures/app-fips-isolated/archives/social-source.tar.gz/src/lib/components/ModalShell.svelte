<script context="module" lang="ts">
  const scrollLockTokens = new Set<number>();
  let scrollLocked = false;
  let previousHtmlOverflow = '';
  let previousBodyOverflow = '';
  let previousBodyPaddingRight = '';
  let previousPageOverflowY = '';
  let lockedPageScroll: HTMLElement | null = null;

  function syncDocumentScrollLock(): void {
    if (typeof document === 'undefined' || typeof window === 'undefined') {
      return;
    }

    const shouldLock = scrollLockTokens.size > 0;
    if (shouldLock === scrollLocked) {
      return;
    }

    const root = document.documentElement;
    const body = document.body;
    const pageScroll = shouldLock
      ? document.querySelector<HTMLElement>('[data-app-page-scroll]')
      : lockedPageScroll;
    if (!root || !body) {
      return;
    }

    if (shouldLock) {
      previousHtmlOverflow = root.style.overflow;
      previousBodyOverflow = body.style.overflow;
      previousBodyPaddingRight = body.style.paddingRight;
      previousPageOverflowY = pageScroll?.style.overflowY ?? '';
      lockedPageScroll = pageScroll;

      const scrollbarWidth = Math.max(0, window.innerWidth - root.clientWidth);
      root.style.overflow = 'hidden';
      body.style.overflow = 'hidden';
      if (pageScroll) {
        pageScroll.style.overflowY = 'hidden';
      }

      if (scrollbarWidth > 0) {
        body.style.paddingRight = `${scrollbarWidth}px`;
      }
    } else {
      root.style.overflow = previousHtmlOverflow;
      body.style.overflow = previousBodyOverflow;
      body.style.paddingRight = previousBodyPaddingRight;
      if (pageScroll) {
        pageScroll.style.overflowY = previousPageOverflowY;
      }

      previousHtmlOverflow = '';
      previousBodyOverflow = '';
      previousBodyPaddingRight = '';
      previousPageOverflowY = '';
      lockedPageScroll = null;
    }

    scrollLocked = shouldLock;
  }

  function activateModalScrollLock(token: number): void {
    scrollLockTokens.add(token);
    syncDocumentScrollLock();
  }

  function deactivateModalScrollLock(token: number): void {
    scrollLockTokens.delete(token);
    syncDocumentScrollLock();
  }
</script>

<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { activateModal, createModalToken, deactivateModal, isTopModal } from '../modalStack';

  export let open = false;
  export let onClose: () => void = () => undefined;
  export let shellClass = 'items-center justify-center p-4 sm:p-6';
  export let contentClass = 'w-full sm:w-auto';
  export let backdropClass = 'bg-black/78';
  export let closeOnEscape = true;
  const modalToken = createModalToken();
  let previousOpen = false;
  let mounted = false;
  let keydownListenerActive = false;

  function handleCapturedKeydown(event: KeyboardEvent): void {
    if (!open || !closeOnEscape || event.defaultPrevented || event.key !== 'Escape' || !isTopModal(modalToken)) {
      return;
    }

    if (typeof document !== 'undefined' && document.fullscreenElement) {
      return;
    }

    event.preventDefault();
    onClose();
  }

  function syncKeydownListener(active: boolean): void {
    if (active === keydownListenerActive) {
      return;
    }
    keydownListenerActive = active;
    if (active) {
      window.addEventListener('keydown', handleCapturedKeydown, true);
    } else {
      window.removeEventListener('keydown', handleCapturedKeydown, true);
    }
  }

  $: if (open !== previousOpen) {
    if (open) {
      activateModal(modalToken);
      activateModalScrollLock(modalToken);
    } else {
      deactivateModal(modalToken);
      deactivateModalScrollLock(modalToken);
    }
    previousOpen = open;
  }

  $: if (mounted) {
    syncKeydownListener(open && closeOnEscape);
  }

  onMount(() => {
    mounted = true;
    syncKeydownListener(open && closeOnEscape);
    return () => syncKeydownListener(false);
  });

  onDestroy(() => {
    deactivateModal(modalToken);
    deactivateModalScrollLock(modalToken);
  });
</script>

{#if open}
  <div class={`fixed inset-0 z-50 flex ${shellClass}`.trim()}>
    <button
      type="button"
      aria-label="Close modal backdrop"
      class={`absolute inset-0 ${backdropClass}`.trim()}
      on:click={onClose}
    ></button>

    <div class={`relative z-10 ${contentClass}`.trim()}>
      <slot></slot>
    </div>
  </div>
{/if}
