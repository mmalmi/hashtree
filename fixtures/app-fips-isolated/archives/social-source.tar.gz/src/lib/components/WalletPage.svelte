<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { settingsHref } from '../routes';
  import { ensureExchangeRates, exchangeRateStore } from '../exchangeRateStore';
  import { formatSatsAmount } from '../exchangeRates';
  import { settingsStore } from '../settings';
  import { wallet } from '../walletStore';
  import { nwcWallet } from '../nwcWallet';
  import IrisIcon from './IrisIcon.svelte';
  import WalletHistory from './wallet/WalletHistory.svelte';
  import WalletMints from './wallet/WalletMints.svelte';
  import WalletReceiveDialog from './wallet/WalletReceiveDialog.svelte';
  import WalletSendDialog from './wallet/WalletSendDialog.svelte';
  import { errorMessage, formatBits } from './wallet/walletUi';

  export let active = false;

  let mounted = false;
  let documentVisible = true;
  let requestedActivity: boolean | null = null;
  let activityTail = Promise.resolve();
  let activityError = '';
  let refreshPending = false;
  let sendOpen = false;
  let receiveOpen = false;
  let selectedSection: 'activity' | 'mints' = 'activity';

  $: effectiveActive = active && documentVisible;
  $: primaryCurrency = $settingsStore.wallet.primaryCurrency;
  $: balanceLabel = primaryCurrency === 'SAT'
    ? formatBits($wallet.spendableBits)
    : formatSatsAmount($wallet.spendableBits, primaryCurrency, $exchangeRateStore);
  $: if (mounted) syncActivity(effectiveActive);
  $: if (mounted && effectiveActive) ensureExchangeRates(primaryCurrency);
  $: if (!effectiveActive) {
    sendOpen = false;
    receiveOpen = false;
  }

  function syncActivity(nextActive: boolean): void {
    if (requestedActivity === nextActive) return;
    requestedActivity = nextActive;
    activityTail = activityTail.catch(() => undefined).then(async () => {
      try {
        await wallet.setActive(nextActive);
        activityError = '';
      } catch (error) {
        if (requestedActivity === nextActive) requestedActivity = null;
        activityError = errorMessage(error);
      }
    });
  }

  async function refresh(): Promise<void> {
    if (refreshPending) return;
    refreshPending = true;
    activityError = '';
    try {
      await wallet.refresh();
      requestedActivity = null;
      syncActivity(effectiveActive);
    } catch (error) {
      activityError = errorMessage(error);
    } finally {
      refreshPending = false;
    }
  }

  onMount(() => {
    mounted = true;
    documentVisible = document.visibilityState !== 'hidden';
    const handleVisibility = () => { documentVisible = document.visibilityState !== 'hidden'; };
    document.addEventListener('visibilitychange', handleVisibility);
    syncActivity(effectiveActive);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  });

  onDestroy(() => {
    if (requestedActivity) void wallet.setActive(false).catch(() => undefined);
  });
</script>

<main
  id="wallet-page"
  data-testid="wallet-page"
  data-wallet-active={effectiveActive ? 'true' : 'false'}
  class="grid w-full gap-5 px-4 pb-28 pt-4 text-[rgb(var(--iris-text-rgb))] sm:px-5 sm:pt-5 md:pb-10"
>
  <header class="flex justify-end gap-1">
    <h1 class="sr-only">Wallet</h1>
    <button
      type="button"
      aria-label="Refresh wallet"
      disabled={refreshPending}
      class="grid h-11 w-11 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.62)] transition hover:bg-[var(--iris-surface-hover)] disabled:opacity-50"
      on:click={() => void refresh()}
    ><IrisIcon name="refresh-ccw-01" size={21} className={refreshPending ? 'animate-spin' : ''} /></button>
    <a
      data-testid="wallet-settings-link"
      href={settingsHref('wallet')}
      aria-label="Wallet settings"
      class="grid h-11 w-11 place-items-center rounded-full text-[rgb(var(--iris-text-rgb)/0.62)] transition hover:bg-[var(--iris-surface-hover)]"
    ><IrisIcon name="settings-outline" size={23} /></a>
  </header>

  <section id="wallet-balance" data-testid="wallet-balance" aria-labelledby="wallet-balance-title" class="grid justify-items-center py-7 text-center sm:py-10">
    <h2 id="wallet-balance-title" class="sr-only">Wallet balance</h2>
    {#if $nwcWallet.enabled}<p class="mb-2 text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">Cashu balance</p>{/if}
    <p class="text-5xl font-800 tracking-tight">{balanceLabel}</p>
    {#if primaryCurrency !== 'SAT'}<p class="mt-2 text-lg text-[rgb(var(--iris-text-rgb)/0.58)]">{formatBits($wallet.spendableBits)}</p>{/if}
    {#if $wallet.reservedBits > 0}<p class="mt-2 text-sm text-[rgb(var(--iris-text-rgb)/0.58)]">{formatBits($wallet.reservedBits)} pending</p>{/if}
  </section>

  <div class="flex items-center justify-center gap-5 py-3">
    <button id="wallet-receive" data-testid="wallet-receive" type="button" class="flex min-h-11 items-center justify-center gap-2 rounded-full bg-[var(--iris-solid)] px-6 font-700 text-[var(--iris-on-solid)] transition hover:opacity-90" on:click={() => receiveOpen = true}><span aria-hidden="true">↓</span> Receive</button>
    <button id="wallet-send" data-testid="wallet-send" type="button" class="flex min-h-11 items-center justify-center gap-2 rounded-full bg-[var(--iris-solid)] px-6 font-700 text-[var(--iris-on-solid)] transition hover:opacity-90" on:click={() => sendOpen = true}>Send <span aria-hidden="true">↑</span></button>
  </div>

  {#if activityError}
    <p
      role="alert"
      class="fixed left-1/2 top-[calc(4.75rem+env(safe-area-inset-top))] z-40 w-[min(32rem,calc(100vw-2rem))] -translate-x-1/2 rounded-2xl border border-red-300/15 bg-[var(--iris-surface-raised)] px-4 py-3 text-sm text-red-400 shadow-xl"
    >{activityError}</p>
  {/if}

  <section class="min-w-0">
    <div class="flex border-b border-[rgb(var(--iris-text-rgb)/0.1)]">
      <button data-testid="wallet-tab-activity" type="button" aria-pressed={selectedSection === 'activity'} class={`px-4 py-2.5 text-sm ${selectedSection === 'activity' ? 'border-b-2 border-current font-700' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectedSection = 'activity'}>Activity</button>
      <button data-testid="wallet-tab-mints" type="button" aria-pressed={selectedSection === 'mints'} class={`px-4 py-2.5 text-sm ${selectedSection === 'mints' ? 'border-b-2 border-current font-700' : 'text-[rgb(var(--iris-text-rgb)/0.55)]'}`} on:click={() => selectedSection = 'mints'}>Mints</button>
    </div>
    <div class="pt-4">
      {#if selectedSection === 'activity'}
        <WalletHistory items={$wallet.history} />
      {:else}
        <WalletMints mints={$wallet.mints} balances={$wallet.balances} />
      {/if}
    </div>
  </section>
</main>

<WalletSendDialog open={sendOpen} mints={$wallet.mints} balances={$wallet.balances} onClose={() => sendOpen = false} />
<WalletReceiveDialog open={receiveOpen} mints={$wallet.mints} onClose={() => receiveOpen = false} />
