<script lang="ts">
  import { onDestroy, onMount, tick } from 'svelte';
  import ProfileSettings from '@iris/svelte-ui/ProfileSettings.svelte';
  import { getNostrExtension } from '../accountSigner';
  import Avatar from './Avatar.svelte';
  import { getProfileTitle, type ProfileRecord } from '../nostr';
  import type { SocialAccount } from '../accounts';
  import IrisIcon from './IrisIcon.svelte';
  import AccountKeyBackup from './AccountKeyBackup.svelte';
  import type { AccountAccessMode } from './app-shell/types';

  export let accounts: SocialAccount[] = [];
  export let activePubkey: string | null = null;
  export let remoteProfiles: Map<string, ProfileRecord> = new Map();
  export let accountInput = '';
  export let importError = '';
  export let initialMode: AccountAccessMode | null = null;
  export let onCreateAccount: (name: string) => void | Promise<void> = () => undefined;
  export let onImportAccount: () => void = () => undefined;
  export let onRemoteLogin: (signal: AbortSignal) => void | Promise<void> = () => undefined;
  export let onExtensionLogin: (signal: AbortSignal) => void | Promise<void> = () => undefined;
  export let onAccountInput: (value: string, pasted?: boolean) => void = () => undefined;
  export let onSwitchAccount: (pubkey: string) => void = () => undefined;
  export let onRemoveAccount: (pubkey: string) => void | Promise<void> = () => undefined;

  $: activeAccount = accounts.find((account) => account.pubkey === activePubkey) ?? null;
  $: profiles = accounts.map((account) => ({
    id: account.pubkey,
    publicKey: account.npub,
    name: remoteProfiles.has(account.pubkey)
      ? getProfileTitle(remoteProfiles.get(account.pubkey) ?? null, account.pubkey)
      : account.profile.name,
  }));

  let mode: AccountAccessMode | 'overview' = initialMode ?? 'overview';
  let keyInput: HTMLInputElement;
  let nameInput: HTMLInputElement;
  let name = '';
  let createPending = false;
  let createError = '';
  let extensionAvailable = false;
  let extension: AbortController | null = null;
  let pairing: AbortController | null = null;
  const primaryButton = 'iris-preserve-white-text inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-gradient-to-t from-violet-800 to-violet-600 px-5 text-[0.95rem] font-700 text-white shadow-[0_10px_28px_rgba(91,33,182,0.28)] transition hover:brightness-110 disabled:opacity-60 disabled:hover:brightness-100';
  const neutralButton = 'inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full iris-neutral-button px-5 text-[0.95rem] font-700 transition disabled:opacity-60';
  const smallNeutralButton = 'inline-flex min-h-9 items-center justify-center rounded-full iris-neutral-button px-4 text-sm font-700 transition';
  const fieldClass = 'w-full rounded-full iris-field px-5 py-3 text-center transition placeholder:text-[rgb(var(--iris-text-rgb)/0.45)]';

  function cancelSignIn(): void {
    pairing?.abort();
    extension?.abort();
  }
  onDestroy(cancelSignIn);

  async function showMode(next: typeof mode): Promise<void> {
    if (next !== 'sign-in') {
      cancelSignIn();
      onAccountInput('');
    }
    mode = next;
    await tick();
    if (next === 'sign-in') keyInput?.focus();
    if (next === 'create-profile') nameInput?.focus();
  }

  async function createProfile(): Promise<void> {
    if (createPending) return;
    createPending = true;
    createError = '';
    try {
      await onCreateAccount(name.trim());
    } catch {
      createError = 'Could not create your profile. Please try again.';
    } finally {
      createPending = false;
    }
  }

  async function loginWithRemoteSigner(): Promise<void> {
    if (pairing) return;
    pairing = new AbortController();
    try { await onRemoteLogin(pairing.signal); } finally { pairing = null; }
  }
  onMount(() => {
    const syncExtension = () => { extensionAvailable = getNostrExtension() !== null; };
    syncExtension();
    if (initialMode) void showMode(initialMode);
    window.addEventListener('focus', syncExtension);
    return () => window.removeEventListener('focus', syncExtension);
  });

  async function loginWithExtension(): Promise<void> {
    if (extension) return;
    extension = new AbortController();
    try { await onExtensionLogin(extension.signal); } finally { extension = null; }
  }

</script>

<section
  data-testid="account-sheet"
  class="grid gap-4 px-4 py-4 pb-6 sm:px-5"
  style="--iris-settings-surface:var(--iris-surface);--iris-settings-muted:rgb(var(--iris-text-rgb)/0.7);--iris-settings-divider:var(--iris-divider);"
>
  {#if profiles.length > 0}
    <ProfileSettings
      {profiles}
      activeProfileId={activePubkey}
      onSwitchProfile={onSwitchAccount}
      onSignOut={onRemoveAccount}
      onRemoveProfile={onRemoveAccount}
    >
      {#snippet profileName(profile)}
        <span data-testid="account-item">{profile.name ?? profile.publicKey}</span>
      {/snippet}
      {#snippet profileAvatar(profile)}
        <Avatar pubkey={profile.id} profile={remoteProfiles.get(profile.id) ?? null} size={44} />
      {/snippet}
    </ProfileSettings>
  {/if}

  {#if activeAccount}
    <AccountKeyBackup account={activeAccount} />
  {/if}

  {#if mode === 'sign-in'}
    <div class="mx-auto grid w-full max-w-[22rem] justify-items-center gap-4 pt-2">
      <img src="/favicon.svg" alt="" class="h-12 w-12" />
      <h2 class="text-2xl font-700">Sign in</h2>
      {#if extensionAvailable}
        <button
          data-testid="extension-login"
          type="button"
          disabled={Boolean(extension)}
          class={primaryButton}
          on:click={() => void loginWithExtension()}
        >{extension ? 'Connecting…' : 'Sign in with Nostr extension'}</button>
      {/if}
      <button
        type="button"
        disabled={Boolean(pairing)}
        class={extensionAvailable ? neutralButton : primaryButton}
        on:click={loginWithRemoteSigner}
      >Sign in with remote signer</button>

      <div class="flex w-full items-center gap-3 text-xs font-700 uppercase tracking-wide text-[rgb(var(--iris-text-rgb)/0.45)]">
        <span class="h-px flex-1 bg-divider"></span>
        or use a key
        <span class="h-px flex-1 bg-divider"></span>
      </div>

      <form class="grid w-full gap-2" on:submit|preventDefault={onImportAccount}>
        <label for="account-key-input" class="sr-only">Secret or public key</label>
        <input
          id="account-key-input"
          data-testid="account-input"
          type="password"
          bind:this={keyInput}
          autocomplete="off"
          autocapitalize="none"
          spellcheck="false"
          aria-describedby="account-key-help"
          value={accountInput}
          placeholder="Paste secret or public key"
          class={fieldClass}
          on:input={(event) => onAccountInput(event.currentTarget.value, event instanceof InputEvent && event.inputType === 'insertFromPaste')}
          on:blur={onImportAccount}
        />
        <p id="account-key-help" class="text-center text-sm text-[rgb(var(--iris-text-rgb)/0.6)]">A public key gives read-only access.</p>
        {#if importError}
          <div role="alert" class="text-center text-[0.85rem] text-[#ffb4b4]">{importError}</div>
        {/if}
        {#if accountInput.trim()}
          <button type="submit" class={neutralButton}>Sign in with key</button>
        {/if}
      </form>

      <div class="mt-1 grid w-full justify-items-center gap-3 border-t border-divider pt-4">
        <span class="text-sm text-[rgb(var(--iris-text-rgb)/0.7)]">Don’t have a profile?</span>
        <button type="button" class={smallNeutralButton} on:click={() => void showMode('create-profile')}>Create a profile</button>
      </div>
    </div>
  {:else if mode === 'create-profile'}
    <div class="mx-auto grid w-full max-w-[22rem] justify-items-center gap-4 pt-2">
      <img src="/favicon.svg" alt="" class="h-12 w-12" />
      <h2 class="text-2xl font-700">Create profile</h2>
      <form class="grid w-full gap-3" on:submit|preventDefault={createProfile}>
        <label for="account-name-input" class="sr-only">What’s your name? Optional</label>
        <input
          id="account-name-input"
          data-testid="create-profile-name"
          bind:this={nameInput}
          bind:value={name}
          type="text"
          autocomplete="nickname"
          maxlength="80"
          placeholder="What’s your name?"
          class={fieldClass}
        />
        {#if createError}<p role="alert" class="text-center text-sm text-[#ffb4b4]">{createError}</p>{/if}
        <button
          data-testid="create-profile-submit"
          type="submit"
          disabled={createPending}
          class={primaryButton}
        >{createPending ? 'Creating profile…' : 'Create profile'}</button>
      </form>
      <div class="mt-1 grid w-full justify-items-center gap-3 border-t border-divider pt-4">
        <span class="text-sm text-[rgb(var(--iris-text-rgb)/0.7)]">Already have a profile?</span>
        <button type="button" class={smallNeutralButton} on:click={() => void showMode('sign-in')}>Sign in</button>
      </div>
    </div>
  {:else}
    <div class="grid gap-3">
      <button
        type="button"
        class="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full iris-neutral-button px-4 py-2.5 text-sm font-700 text-[rgb(var(--iris-text-rgb))] transition"
        on:click={() => void showMode('sign-in')}
      >
        <IrisIcon name="sign-in" size={18} />
        Sign in
      </button>
      <button
        data-testid="create-account"
        type="button"
        class="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-[var(--iris-solid)] px-4 py-2.5 text-sm font-700 text-[var(--iris-on-solid)] transition hover:opacity-90"
        on:click={() => void showMode('create-profile')}
      >
        <IrisIcon name="plus" size={18} />
        Create profile
      </button>
    </div>
  {/if}
  {#if !initialMode && mode !== 'overview'}
    <button type="button" class="justify-self-center text-sm text-[rgb(var(--iris-text-rgb)/0.6)] hover:underline" on:click={() => void showMode('overview')}>Back to profiles</button>
  {/if}
</section>
