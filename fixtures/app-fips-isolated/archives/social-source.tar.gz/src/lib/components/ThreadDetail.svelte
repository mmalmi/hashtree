<script lang="ts">
  import type { AppError } from '../appError';
  import { afterUpdate, beforeUpdate, onDestroy, tick } from 'svelte';
  import type { Action } from 'svelte/action';
  import ComposerCard from './ComposerCard.svelte';
  import FeedCard from './FeedCard.svelte';
  import type { ComposerAttachment } from '../media';
  import type { NoteEmbed } from '../noteContent';
  import type { NoteEngagement } from '../noteEngagement';
  import type { ReferencedNotePreview } from '../referencedNote';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import { clearViewedPostNotifications } from '../viewedPostNotifications';
  import { get } from 'svelte/store';
  import {
    buildThreadReplyRows,
    pruneThreadReplyRows,
    type ThreadReplySocialRank,
  } from '../threadTree';
  import { createSocialGraphBadgeSetBinding, socialGraphBadges } from '../socialGraphBadges';
  import { authorVisibility } from '../authorVisibility';
  import { shouldRenderThreadContextEmbeds } from '../threadContextPresentation';
  import {
    getActiveAppRouteElement,
    getActiveAppScrollElement,
  } from '../appScroll';
  import { planThreadViewportAnchor } from '../threadViewportAnchor';

  export let note: RawEvent;
  export let profile: ProfileRecord | null = null;
  export let contextNotes: RawEvent[] = [];
  export let replies: RawEvent[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let noteEngagement: NoteEngagement | null = null;
  export let replyEngagements: Map<string, NoteEngagement> = new Map();
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let viewerProfile: ProfileRecord | null = null;
  export let canReply = false;
  export let replyValue = '';
  export let replyDraftKey = '';
  export let replyError: AppError = '';
  export let replyAttachments: ComposerAttachment[] = [];
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let mutedPubkeys: Set<string> = new Set();
  export let mutePendingPubkeys: Set<string> = new Set();
  export let onToggleMute: ((pubkey: string, nextMuted: boolean) => void) | null = null;
  export let onOpenNote: ((target: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let onReplyInput: (value: string) => void = () => undefined;
  export let onReplyAttachmentsChange: (attachments: ComposerAttachment[]) => void = () => undefined;
  export let onReplySubmit: (payload: { text: string; attachments: ComposerAttachment[] }) => void = () => undefined;
  export let onLike: ((event: RawEvent) => void) | null = null;
  export let onZap: ((event: RawEvent) => void) | null = null;
  export let onReply: ((event: RawEvent) => void) | null = null;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: ((event: RawEvent) => void) | null = null;
  export let zapPendingNoteIds: Set<string> = new Set();
  export let repostPendingNoteIds: Set<string> = new Set();
  export let onShare: ((event: RawEvent) => void) | null = null;
  export let onOpenReactions: ((event: RawEvent) => void) | null = null;
  export let onCopyLink: ((event: RawEvent) => void) | null = null;
  export let onCopyEventId: ((event: RawEvent) => void) | null = null;
  export let onRebroadcast: ((event: RawEvent) => void) | null = null;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let rebroadcastPendingNoteIds: Set<string> = new Set();
  export let activeMediaEventId: string | null = null;
  export let activeMediaUrl: string | null = null;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let liked = false;
  export let likePending = false;
  export let likeDisabled = false;
  export let likePendingNoteIds: Set<string> = new Set();
  export let repliesHasMore = false;
  export let repliesLoadPending = false;
  export let repliesInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreReplies: (() => void) | null = null;
  export let isActive = true;
  export let threadPresented = false;

  type ThreadAnchorCapture = {
    anchorTop: number;
    contextKey: string;
    scrollElement: HTMLElement;
  };

  let threadDetailElement: HTMLElement | null = null;
  let mainNoteElement: HTMLElement | null = null;
  let renderedContextKey = '';
  let hasRendered = false;
  let pendingAnchorCapture: ThreadAnchorCapture | null = null;
  let anchorBottomReservePx = 0;
  let anchorRestoreVersion = 0;

  function profileFor(pubkey: string): ProfileRecord | null {
    return profiles.get(pubkey) ?? null;
  }

  function replyEngagementFor(event: RawEvent): NoteEngagement | null {
    return replyEngagements.get(event.id) ?? null;
  }

  // Like Iris Client: closer authors first (self, follows, friends of
  // follows), then oldest. Each reply keeps the rank it had when first shown,
  // so a late follow list or badge cannot reshuffle rows under the reader.
  let replyRanks = new Map<string, ThreadReplySocialRank>();
  let replyRankScope = '';
  function replyRank(event: RawEvent): ThreadReplySocialRank {
    const known = replyRanks.get(event.id);
    if (known) {
      return known;
    }
    const badge = get(socialGraphBadges).get(event.pubkey);
    const rank: ThreadReplySocialRank = event.pubkey === viewerPubkey
      ? { distance: 0, followedByFriends: null }
      : viewerFollows.has(event.pubkey)
        ? { distance: 1, followedByFriends: badge?.followedByFriends ?? null }
        : { distance: badge?.distance ?? null, followedByFriends: badge?.followedByFriends ?? null };
    // Latch only a decided rank; a reply still waiting for its author's
    // graph answer is not shown yet, so it may rank again once it arrives.
    if (badge || event.pubkey === viewerPubkey || viewerFollows.has(event.pubkey)) {
      replyRanks.set(event.id, rank);
    }
    return rank;
  }

  // Like iris-client's reply feeds, authors outside the viewer's web of trust
  // (or muted/overmuted) are left out together with replies beneath them.
  // Replies wait for their author's local graph answer instead of popping out.
  const syncReplyAuthors = createSocialGraphBadgeSetBinding();
  $: syncReplyAuthors(isActive ? replies.map((event) => event.pubkey) : null);
  onDestroy(() => syncReplyAuthors(null));
  $: badgeViewer = (void $socialGraphBadges, socialGraphBadges.getViewer());
  $: {
    const scope = `${note.id}:${viewerPubkey ?? ''}`;
    if (scope !== replyRankScope) {
      replyRankScope = scope;
      replyRanks = new Map();
    }
  }
  $: replyRows = (void replyRankScope, pruneThreadReplyRows(
    buildThreadReplyRows(note, replies, viewerPubkey ? replyRank : null),
    (event) => authorVisibility(event.pubkey, badgeViewer, viewerFollows, $socialGraphBadges) === 'visible',
  ));
  // Flat, Twitter-style chains: a row links to the row directly below it when
  // that row replies to it, drawn as a line between their avatars.
  $: replyLinks = replyRows.map((row, index) => ({
    above: index > 0 && row.parentId === replyRows[index - 1].event.id,
    below: replyRows[index + 1]?.parentId === row.event.id,
  }));
  $: contextKey = `${note.id}:${contextNotes.map((event) => event.id).join(':')}`;

  beforeUpdate(() => {
    if (!hasRendered || contextKey === renderedContextKey || !isActive) {
      return;
    }
    const scrollElement = getActiveAppScrollElement();
    const routeElement = getActiveAppRouteElement();
    if (
      !scrollElement
      || !routeElement
      || !threadDetailElement
      || !mainNoteElement
      || !routeElement.contains(threadDetailElement)
    ) {
      return;
    }
    pendingAnchorCapture = {
      anchorTop: mainNoteElement.getBoundingClientRect().top,
      contextKey,
      scrollElement,
    };
  });

  afterUpdate(() => {
    const capture = pendingAnchorCapture;
    pendingAnchorCapture = null;
    renderedContextKey = contextKey;
    if (!hasRendered) {
      hasRendered = true;
      return;
    }
    if (!capture || capture.contextKey !== contextKey) {
      return;
    }
    const version = ++anchorRestoreVersion;
    void restoreMainNoteAnchor(capture, version);
  });

  async function restoreMainNoteAnchor(
    capture: ThreadAnchorCapture,
    version: number,
  ): Promise<void> {
    if (
      !isActive
      || !mainNoteElement
      || !threadDetailElement
      || getActiveAppScrollElement() !== capture.scrollElement
      || !getActiveAppRouteElement()?.contains(threadDetailElement)
    ) {
      return;
    }
    const plan = planThreadViewportAnchor({
      anchorTopAfter: mainNoteElement.getBoundingClientRect().top,
      anchorTopBefore: capture.anchorTop,
      clientHeight: capture.scrollElement.clientHeight,
      currentOffset: capture.scrollElement.scrollTop,
      scrollHeight: capture.scrollElement.scrollHeight,
    });
    if (!plan) {
      return;
    }
    if (plan.bottomReservePx > 0) {
      anchorBottomReservePx += plan.bottomReservePx;
      await tick();
    }
    if (
      version !== anchorRestoreVersion
      || contextKey !== capture.contextKey
      || !isActive
      || !threadDetailElement
      || getActiveAppScrollElement() !== capture.scrollElement
      || !getActiveAppRouteElement()?.contains(threadDetailElement)
    ) {
      return;
    }
    capture.scrollElement.scrollTop = plan.targetOffset;
  }
</script>

<section
  bind:this={threadDetailElement}
  data-testid="thread-detail"
  data-thread-anchor-reserve={anchorBottomReservePx}
  class="grid gap-0"
  style={anchorBottomReservePx > 0 ? `padding-bottom:${anchorBottomReservePx}px` : undefined}
>
  {#if contextNotes.length > 0}
    <div data-testid="thread-context" class="grid gap-0">
      {#each contextNotes as contextEvent, contextIndex (contextEvent.id)}
        <div data-testid="thread-context-note" class="relative">
          {#if contextIndex > 0}
            <div aria-hidden="true" class="iris-thread-link top-0 h-[0.5rem]"></div>
          {/if}
          <div
            aria-hidden="true"
            data-testid="thread-context-link-below"
            class="iris-thread-link bottom-0 top-[3.5rem]"
          ></div>
          <FeedCard
            event={contextEvent}
            {profiles}
            {viewerPubkey}
            {viewerFollows}
            {followPendingPubkeys}
            {onToggleFollow}
            {mutedPubkeys}
            {mutePendingPubkeys}
            {onToggleMute}
            engagements={replyEngagements}
            profile={profileFor(contextEvent.pubkey)}
            showReplyContext={false}
            showEmbeds={shouldRenderThreadContextEmbeds(contextIndex, contextNotes.length)}
            showEngagement={false}
            activeMediaUrl={activeMediaEventId === contextEvent.id ? activeMediaUrl : null}
            {onOpenProfile}
            onOpenMedia={shouldRenderThreadContextEmbeds(contextIndex, contextNotes.length)
              ? onOpenMedia
              : null}
            {onOpenNote}
            {resolveReferencedNote}
            onOpenReactions={onOpenReactions}
            onCopyLink={onCopyLink}
            onCopyEventId={onCopyEventId}
            onRebroadcast={onRebroadcast}
            {onDelete}
            rebroadcastPending={rebroadcastPendingNoteIds.has(contextEvent.id)}
            className="border-b-0"
            {isActive}
          />
        </div>
      {/each}
    </div>
  {/if}

  <div
    bind:this={mainNoteElement}
    use:clearViewedPostNotifications={{ id: note.id, pubkey: viewerPubkey, presented: threadPresented }}
    data-testid="thread-main-note"
    class={`relative border-b border-divider bg-[radial-gradient(circle_at_top_left,rgba(139,92,246,0.09),transparent_52%)] ${
      contextNotes.length > 0 ? '' : 'border-t'
    }`}
  >
    {#if contextNotes.length > 0}
      <div aria-hidden="true" data-testid="thread-main-link-above" class="iris-thread-link top-0 h-[0.5rem]"></div>
    {/if}
    <FeedCard
      event={note}
      {profiles}
      {viewerPubkey}
      {viewerFollows}
      {followPendingPubkeys}
      {onToggleFollow}
      {mutedPubkeys}
      {mutePendingPubkeys}
      {onToggleMute}
      engagements={replyEngagements}
      {profile}
      engagement={noteEngagement}
      activeMediaUrl={activeMediaEventId === note.id ? activeMediaUrl : null}
      {onOpenProfile}
      {onOpenMedia}
      {onOpenNote}
      {resolveReferencedNote}
      showRepliedTo={contextNotes.length === 0}
      showReplyContext={false}
      textCollapsible={false}
      {liked}
      {likePending}
      {likeDisabled}
      {onLike}
      {onZap}
      zapPending={zapPendingNoteIds.has(note.id)}
      zapDisabled={likeDisabled}
      {onReply}
      {onQuote}
      {onRepost}
      repostPending={repostPendingNoteIds.has(note.id)}
      {onShare}
      {onOpenReactions}
      {onCopyLink}
      {onCopyEventId}
      {onRebroadcast}
      {onDelete}
      rebroadcastPending={rebroadcastPendingNoteIds.has(note.id)}
      className="border-b-0"
      {isActive}
    />
  </div>

  {#if viewerPubkey}
    <div data-testid="thread-reply-composer" class="border-b border-divider bg-black/10">
      {#key `${note.id}:${viewerPubkey}`}
        <ComposerCard
          pubkey={viewerPubkey}
          draftKey={replyDraftKey}
          profile={viewerProfile}
          value={replyValue}
          disabled={!canReply}
          error={replyError}
          attachments={replyAttachments}
          placeholder="Write a reply"
          submitLabel="Reply"
          onInput={onReplyInput}
          onAttachmentsChange={onReplyAttachmentsChange}
          onSubmit={onReplySubmit}
        />
      {/key}
    </div>
  {/if}

  {#if replyRows.length > 0}
    <div data-testid="thread-reply-tree" class="grid gap-0">
      {#each replyRows as row, rowIndex (row.event.id)}
        <div
          data-testid="thread-reply"
          data-thread-depth={row.depth}
          data-thread-parent-id={row.parentId ?? ''}
          data-thread-orphaned={row.orphaned}
          data-thread-has-children={row.hasChildren}
          data-thread-link-above={replyLinks[rowIndex]?.above ?? false}
          data-thread-link-below={replyLinks[rowIndex]?.below ?? false}
          class="relative"
        >
          {#if replyLinks[rowIndex]?.above}
            <div
              aria-hidden="true"
              data-testid="thread-reply-link-above"
              class="iris-thread-link top-0 h-[0.5rem]"
            ></div>
          {/if}
          {#if replyLinks[rowIndex]?.below}
            <div
              aria-hidden="true"
              data-testid="thread-reply-link-below"
              class="iris-thread-link bottom-0 top-[3.5rem]"
            ></div>
          {/if}
          <FeedCard
            event={row.event}
            {profiles}
            {viewerPubkey}
            {viewerFollows}
            {followPendingPubkeys}
            {onToggleFollow}
            {mutedPubkeys}
            {mutePendingPubkeys}
            {onToggleMute}
            engagements={replyEngagements}
            profile={profileFor(row.event.pubkey)}
            engagement={replyEngagementFor(row.event)}
            showReplyContext={row.orphaned}
            activeMediaUrl={activeMediaEventId === row.event.id ? activeMediaUrl : null}
            {onOpenProfile}
            {onOpenMedia}
            {onOpenNote}
            {resolveReferencedNote}
            liked={replyEngagementFor(row.event)?.viewerReacted ?? false}
            likePending={likePendingNoteIds.has(row.event.id)}
            {likeDisabled}
            {onLike}
            {onZap}
            zapPending={zapPendingNoteIds.has(row.event.id)}
            zapDisabled={likeDisabled}
            {onReply}
            {onQuote}
            {onRepost}
            repostPending={repostPendingNoteIds.has(row.event.id)}
            {onShare}
            {onOpenReactions}
            {onCopyLink}
            {onCopyEventId}
            {onRebroadcast}
            {onDelete}
            rebroadcastPending={rebroadcastPendingNoteIds.has(row.event.id)}
            className={replyLinks[rowIndex]?.below ? 'border-b-0' : ''}
            {isActive}
          />
        </div>
      {/each}
    </div>
  {/if}

  {#if repliesHasMore || repliesLoadPending}
    <div class="grid gap-0 border-b border-divider px-4 py-3 sm:px-5">
      <button
        data-testid="thread-replies-load-more"
        type="button"
        class="mx-auto rounded-full iris-neutral-button px-4 py-2 text-[0.88rem] font-700 text-white/75 transition hover:text-white disabled:cursor-wait disabled:opacity-60"
        disabled={repliesLoadPending || !repliesHasMore}
        on:click={() => onLoadMoreReplies?.()}
      >
        {repliesLoadPending ? 'Loading replies…' : 'Load more replies'}
      </button>
      {#if repliesInfiniteScroll && (repliesHasMore || repliesLoadPending)}
        <div
          data-testid="thread-replies-sentinel"
          use:repliesInfiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>

<style>
  /* Centered under the 40px avatar inside the card's px-4 / sm:px-5 inset. */
  .iris-thread-link {
    position: absolute;
    left: calc(1rem + 19px);
    z-index: 1;
    width: 2px;
    pointer-events: none;
    background: var(--iris-control);
  }

  @media (min-width: 640px) {
    .iris-thread-link {
      left: calc(1.25rem + 19px);
    }
  }
</style>
