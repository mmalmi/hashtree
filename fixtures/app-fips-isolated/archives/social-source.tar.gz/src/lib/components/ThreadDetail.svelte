<script lang="ts">
  import { afterUpdate, beforeUpdate, tick } from 'svelte';
  import type { Action } from 'svelte/action';
  import ComposerCard from './ComposerCard.svelte';
  import FeedCard from './FeedCard.svelte';
  import type { ComposerAttachment } from '../media';
  import type { NoteEmbed } from '../noteContent';
  import type { NoteEngagement } from '../noteEngagement';
  import type { ReferencedNotePreview } from '../referencedNote';
  import type { ProfileRecord, RawEvent } from '../nostr';
  import { clearViewedPostNotifications } from '../viewedPostNotifications';
  import { buildThreadReplyRows } from '../threadTree';
  import { shouldRenderThreadContextEmbeds } from '../threadContextPresentation';
  import {
    getActiveAppRouteElement,
    getActiveAppScrollElement,
  } from '../appScroll';
  import { planThreadViewportAnchor } from '../threadViewportAnchor';

  export let note: RawEvent;
  export let profile: ProfileRecord | null = null;
  export let contextNotes: RawEvent[] = [];
  export let replies: RawEvent[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let noteEngagement: NoteEngagement | null = null;
  export let replyEngagements: Map<string, NoteEngagement> = new Map();
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let viewerProfile: ProfileRecord | null = null;
  export let canReply = false;
  export let replyValue = '';
  export let replyDraftKey = '';
  export let replyError = '';
  export let replyAttachments: ComposerAttachment[] = [];
  export let onOpenProfile: (pubkey: string) => void = () => undefined;
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onOpenNote: ((target: string) => void) | null = null;
  export let resolveReferencedNote: ((ref: string) => Promise<ReferencedNotePreview | null>) | null = null;
  export let onReplyInput: (value: string) => void = () => undefined;
  export let onReplyAttachmentsChange: (attachments: ComposerAttachment[]) => void = () => undefined;
  export let onReplySubmit: (payload: { text: string; attachments: ComposerAttachment[] }) => void = () => undefined;
  export let onLike: ((event: RawEvent) => void) | null = null;
  export let onZap: ((event: RawEvent) => void) | null = null;
  export let onReply: ((event: RawEvent) => void) | null = null;
  export let onQuote: ((event: RawEvent) => void) | null = null;
  export let onRepost: ((event: RawEvent) => void) | null = null;
  export let zapPendingNoteIds: Set<string> = new Set();
  export let repostPendingNoteIds: Set<string> = new Set();
  export let onShare: ((event: RawEvent) => void) | null = null;
  export let onOpenReactions: ((event: RawEvent) => void) | null = null;
  export let onCopyLink: ((event: RawEvent) => void) | null = null;
  export let onCopyEventId: ((event: RawEvent) => void) | null = null;
  export let onRebroadcast: ((event: RawEvent) => void) | null = null;
  export let onDelete: ((event: RawEvent) => void) | null = null;
  export let rebroadcastPendingNoteIds: Set<string> = new Set();
  export let activeMediaEventId: string | null = null;
  export let activeMediaUrl: string | null = null;
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let liked = false;
  export let likePending = false;
  export let likeDisabled = false;
  export let repliesHasMore = false;
  export let repliesLoadPending = false;
  export let repliesInfiniteScroll: Action<HTMLDivElement> | null = null;
  export let onLoadMoreReplies: (() => void) | null = null;
  export let isActive = true;
  export let threadPresented = false;

  type ThreadAnchorCapture = {
    anchorTop: number;
    contextKey: string;
    scrollElement: HTMLElement;
  };

  let threadDetailElement: HTMLElement | null = null;
  let mainNoteElement: HTMLElement | null = null;
  let renderedContextKey = '';
  let hasRendered = false;
  let pendingAnchorCapture: ThreadAnchorCapture | null = null;
  let anchorBottomReservePx = 0;
  let anchorRestoreVersion = 0;

  function profileFor(pubkey: string): ProfileRecord | null {
    return profiles.get(pubkey) ?? null;
  }

  function replyEngagementFor(event: RawEvent): NoteEngagement | null {
    return replyEngagements.get(event.id) ?? null;
  }

  $: replyRows = buildThreadReplyRows(note, replies);
  $: contextKey = `${note.id}:${contextNotes.map((event) => event.id).join(':')}`;

  beforeUpdate(() => {
    if (!hasRendered || contextKey === renderedContextKey || !isActive) {
      return;
    }
    const scrollElement = getActiveAppScrollElement();
    const routeElement = getActiveAppRouteElement();
    if (
      !scrollElement
      || !routeElement
      || !threadDetailElement
      || !mainNoteElement
      || !routeElement.contains(threadDetailElement)
    ) {
      return;
    }
    pendingAnchorCapture = {
      anchorTop: mainNoteElement.getBoundingClientRect().top,
      contextKey,
      scrollElement,
    };
  });

  afterUpdate(() => {
    const capture = pendingAnchorCapture;
    pendingAnchorCapture = null;
    renderedContextKey = contextKey;
    if (!hasRendered) {
      hasRendered = true;
      return;
    }
    if (!capture || capture.contextKey !== contextKey) {
      return;
    }
    const version = ++anchorRestoreVersion;
    void restoreMainNoteAnchor(capture, version);
  });

  async function restoreMainNoteAnchor(
    capture: ThreadAnchorCapture,
    version: number,
  ): Promise<void> {
    if (
      !isActive
      || !mainNoteElement
      || !threadDetailElement
      || getActiveAppScrollElement() !== capture.scrollElement
      || !getActiveAppRouteElement()?.contains(threadDetailElement)
    ) {
      return;
    }
    const plan = planThreadViewportAnchor({
      anchorTopAfter: mainNoteElement.getBoundingClientRect().top,
      anchorTopBefore: capture.anchorTop,
      clientHeight: capture.scrollElement.clientHeight,
      currentOffset: capture.scrollElement.scrollTop,
      scrollHeight: capture.scrollElement.scrollHeight,
    });
    if (!plan) {
      return;
    }
    if (plan.bottomReservePx > 0) {
      anchorBottomReservePx += plan.bottomReservePx;
      await tick();
    }
    if (
      version !== anchorRestoreVersion
      || contextKey !== capture.contextKey
      || !isActive
      || !threadDetailElement
      || getActiveAppScrollElement() !== capture.scrollElement
      || !getActiveAppRouteElement()?.contains(threadDetailElement)
    ) {
      return;
    }
    capture.scrollElement.scrollTop = plan.targetOffset;
  }
</script>

<section
  bind:this={threadDetailElement}
  data-testid="thread-detail"
  data-thread-anchor-reserve={anchorBottomReservePx}
  class="grid gap-0"
  style={anchorBottomReservePx > 0 ? `padding-bottom:${anchorBottomReservePx}px` : undefined}
>
  {#if contextNotes.length > 0}
    <div data-testid="thread-context" class="relative grid gap-0 bg-white/[0.008]">
      <div
        aria-hidden="true"
        class="pointer-events-none absolute bottom-0 left-[1.35rem] top-0 w-px bg-gradient-to-b from-transparent via-white/12 to-violet-300/25 sm:left-[1.6rem]"
      ></div>
      {#each contextNotes as contextEvent, contextIndex (contextEvent.id)}
        <div data-testid="thread-context-note" class="relative">
          <FeedCard
            event={contextEvent}
            {profiles}
            {viewerPubkey}
            {viewerFollows}
            {followPendingPubkeys}
            {onToggleFollow}
            engagements={replyEngagements}
            profile={profileFor(contextEvent.pubkey)}
            compact
            showEmbeds={shouldRenderThreadContextEmbeds(contextIndex, contextNotes.length)}
            showEngagement={false}
            activeMediaUrl={activeMediaEventId === contextEvent.id ? activeMediaUrl : null}
            {onOpenProfile}
            onOpenMedia={shouldRenderThreadContextEmbeds(contextIndex, contextNotes.length)
              ? onOpenMedia
              : null}
            {onOpenNote}
            {resolveReferencedNote}
            onOpenReactions={onOpenReactions}
            onCopyLink={onCopyLink}
            onCopyEventId={onCopyEventId}
            onRebroadcast={onRebroadcast}
            {onDelete}
            rebroadcastPending={rebroadcastPendingNoteIds.has(contextEvent.id)}
            {isActive}
          />
        </div>
      {/each}
    </div>
  {/if}

  <div
    bind:this={mainNoteElement}
    use:clearViewedPostNotifications={{ id: note.id, pubkey: viewerPubkey, presented: threadPresented }}
    data-testid="thread-main-note"
    class="relative overflow-hidden border-y border-violet-300/15 bg-[radial-gradient(circle_at_top_left,rgba(139,92,246,0.09),transparent_52%)] shadow-[inset_0_1px_0_rgba(255,255,255,0.025)]"
  >
    <div
      aria-hidden="true"
      class="pointer-events-none absolute bottom-0 left-0 top-0 w-0.5 bg-gradient-to-b from-violet-300/70 via-fuchsia-300/35 to-transparent"
    ></div>
    <FeedCard
      event={note}
      {profiles}
      {viewerPubkey}
      {viewerFollows}
      {followPendingPubkeys}
      {onToggleFollow}
      engagements={replyEngagements}
      {profile}
      engagement={noteEngagement}
      activeMediaUrl={activeMediaEventId === note.id ? activeMediaUrl : null}
      {onOpenProfile}
      {onOpenMedia}
      {onOpenNote}
      {resolveReferencedNote}
      showRepliedTo={contextNotes.length === 0}
      textCollapsible={false}
      {liked}
      {likePending}
      {likeDisabled}
      {onLike}
      {onZap}
      zapPending={zapPendingNoteIds.has(note.id)}
      zapDisabled={likeDisabled}
      {onReply}
      {onQuote}
      {onRepost}
      repostPending={repostPendingNoteIds.has(note.id)}
      {onShare}
      {onOpenReactions}
      {onCopyLink}
      {onCopyEventId}
      {onRebroadcast}
      {onDelete}
      rebroadcastPending={rebroadcastPendingNoteIds.has(note.id)}
      className="border-b-0"
      {isActive}
    />
  </div>

  {#if viewerPubkey}
    <div data-testid="thread-reply-composer" class="border-b border-white/5 bg-black/10">
      {#key `${note.id}:${viewerPubkey}`}
        <ComposerCard
          pubkey={viewerPubkey}
          draftKey={replyDraftKey}
          profile={viewerProfile}
          value={replyValue}
          disabled={!canReply}
          error={replyError}
          attachments={replyAttachments}
          placeholder="Write a reply"
          submitLabel="Reply"
          onInput={onReplyInput}
          onAttachmentsChange={onReplyAttachmentsChange}
          onSubmit={onReplySubmit}
        />
      {/key}
    </div>
  {/if}

  {#if replyRows.length > 0}
    <div data-testid="thread-reply-tree" class="grid gap-0">
      {#each replyRows as row (row.event.id)}
        <div
          data-testid="thread-reply"
          data-thread-depth={row.depth}
          data-thread-parent-id={row.parentId ?? ''}
          data-thread-orphaned={row.orphaned}
          data-thread-has-children={row.hasChildren}
          class={row.depth > 0 ? 'border-l border-white/10' : ''}
          style={`margin-left: ${Math.min(row.depth, 4) * 12}px`}
        >
          <FeedCard
            event={row.event}
            {profiles}
            {viewerPubkey}
            {viewerFollows}
            {followPendingPubkeys}
            {onToggleFollow}
            engagements={replyEngagements}
            profile={profileFor(row.event.pubkey)}
            engagement={replyEngagementFor(row.event)}
            compact
            activeMediaUrl={activeMediaEventId === row.event.id ? activeMediaUrl : null}
            {onOpenProfile}
            {onOpenMedia}
            {onOpenNote}
            {resolveReferencedNote}
            {onLike}
            {onZap}
            zapPending={zapPendingNoteIds.has(row.event.id)}
            zapDisabled={likeDisabled}
            {onReply}
            {onQuote}
            {onRepost}
            repostPending={repostPendingNoteIds.has(row.event.id)}
            {onShare}
            {onOpenReactions}
            {onCopyLink}
            {onCopyEventId}
            {onRebroadcast}
            {onDelete}
            rebroadcastPending={rebroadcastPendingNoteIds.has(row.event.id)}
            {isActive}
          />
        </div>
      {/each}
    </div>
  {/if}

  {#if repliesHasMore || repliesLoadPending}
    <div class="grid gap-0 border-b border-white/5 px-4 py-3 sm:px-5">
      <button
        data-testid="thread-replies-load-more"
        type="button"
        class="mx-auto rounded-full border border-white/10 px-4 py-2 text-[0.88rem] font-700 text-white/75 transition hover:bg-white/5 hover:text-white disabled:cursor-wait disabled:opacity-60"
        disabled={repliesLoadPending || !repliesHasMore}
        on:click={() => onLoadMoreReplies?.()}
      >
        {repliesLoadPending ? 'Loading replies…' : 'Load more replies'}
      </button>
      {#if repliesInfiniteScroll && (repliesHasMore || repliesLoadPending)}
        <div
          data-testid="thread-replies-sentinel"
          use:repliesInfiniteScroll
          aria-hidden="true"
          class="h-px w-full"
        ></div>
      {/if}
    </div>
  {/if}
</section>
