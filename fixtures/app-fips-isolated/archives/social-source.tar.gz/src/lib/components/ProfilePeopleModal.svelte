<script lang="ts">
  import type { Action } from 'svelte/action';
  import type { ProfileRecord } from '../nostr';
  import Avatar from './Avatar.svelte';
  import IrisIcon from './IrisIcon.svelte';
  import ModalShell from './ModalShell.svelte';
  import PeopleList from './PeopleList.svelte';
  import Username from './Username.svelte';

  export let open = false;
  export let kind: 'follows' | 'followers' = 'follows';
  export let pubkey = '';
  export let profile: ProfileRecord | null = null;
  export let pubkeys: string[] = [];
  export let profiles: Map<string, ProfileRecord> = new Map();
  export let loading = false;
  export let hasMore = false;
  export let loadPending = false;
  export let infiniteScroll: Action<HTMLDivElement> | null = null;
  export let viewerPubkey: string | null = null;
  export let viewerFollows: Set<string> = new Set();
  export let followPendingPubkeys: Set<string> = new Set();
  export let onToggleFollow: ((pubkey: string, nextFollowing: boolean) => void) | null = null;
  export let onClose: () => void = () => undefined;

  let visibleLimit = 40;
  $: if (!open) visibleLimit = 40;
  $: visiblePubkeys = pubkeys.slice(0, visibleLimit);
</script>

<ModalShell
  {open}
  {onClose}
  shellClass="items-center justify-center p-4 sm:p-6"
  contentClass="flex h-[min(720px,calc(100dvh-2rem))] w-full max-w-[430px] items-stretch"
>
  <div
    data-testid="profile-people-modal"
    role="dialog"
    aria-modal="true"
    aria-label={kind === 'follows' ? 'Follows' : 'Known followers'}
    class="flex min-h-0 w-full flex-col overflow-hidden rounded-2xl border border-[var(--iris-border-subtle)] bg-[var(--iris-surface)] shadow-2xl"
  >
    <header class="flex shrink-0 items-center gap-3 border-b border-[var(--iris-border-subtle)] px-4 py-3">
      <Avatar {pubkey} {profile} size={40} />
      <div class="min-w-0 flex-1">
        <div class="text-[0.78rem] text-[rgb(var(--iris-text-rgb)/0.5)]">
          {kind === 'follows' ? 'Followed by' : 'Known followers of'}
        </div>
        <Username
          {pubkey}
          {profile}
          showSubtitle={false}
          titleClass="truncate text-[0.98rem] font-700 text-[rgb(var(--iris-text-rgb))]"
        />
      </div>
      <button
        data-testid="profile-people-modal-close"
        type="button"
        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[rgb(var(--iris-text-rgb)/0.65)] transition hover:bg-[rgb(var(--iris-text-rgb)/0.08)] hover:text-[rgb(var(--iris-text-rgb))]"
        aria-label="Close"
        on:click={onClose}
      >
        <IrisIcon name="x-close" size={18} />
      </button>
    </header>

    <div data-scrollable class="min-h-0 flex-1 overflow-y-auto overscroll-contain">
      {#if loading && pubkeys.length === 0}
        <div class="px-4 py-6 text-[0.92rem] text-[rgb(var(--iris-text-rgb)/0.55)]">
          Loading {kind === 'follows' ? 'follows' : 'followers'}…
        </div>
      {:else}
        <PeopleList
          pubkeys={visiblePubkeys}
          {profiles}
          {viewerPubkey}
          {viewerFollows}
          {followPendingPubkeys}
          {onToggleFollow}
          emptyText={kind === 'follows' ? 'No follows.' : 'No followers.'}
          hasMore={hasMore && visibleLimit >= pubkeys.length}
          {loadPending}
          {infiniteScroll}
        />
        {#if visibleLimit < pubkeys.length}
          <button
            type="button"
            class="w-full px-4 py-4 text-[0.9rem] text-[rgb(var(--iris-text-rgb)/0.65)] hover:underline"
            on:click={() => visibleLimit += 40}
          >Show more</button>
        {/if}
      {/if}
    </div>
  </div>
</ModalShell>
