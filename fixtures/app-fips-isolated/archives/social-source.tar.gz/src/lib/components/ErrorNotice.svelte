<script lang="ts">
  import type { AppError } from '../appError';

  let { error }: { error: AppError } = $props();
  const detailId = $props.id();
  let expandedError = $state.raw<AppError | null>(null);
  let copyResult = $state('');
  const expanded = $derived(expandedError === error);

  async function copyError() {
    if (typeof error === 'string') { return; }
    const current = error;
    try {
      await navigator.clipboard.writeText(`${current.summary}\n${current.detail}`);
      if (expandedError === current) { copyResult = 'Copied'; }
    } catch {
      if (expandedError === current) { copyResult = 'Select and copy the error text.'; }
    }
  }
</script>

<div class="min-w-0">
  <div class="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
    <span role="alert">{typeof error === 'string' ? error : error.summary}</span>
    {#if typeof error !== 'string'}
      <button type="button" class="shrink-0 rounded font-600 underline underline-offset-2"
        aria-expanded={expanded} aria-controls={detailId}
        onclick={() => { expandedError = expanded ? null : error; copyResult = ''; }}
      >{expanded ? 'Hide error' : 'Show error'}</button>
    {/if}
  </div>
  {#if typeof error !== 'string'}
    <div id={detailId} hidden={!expanded} class="mt-2">
      <pre class="m-0 max-h-36 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-[var(--iris-surface-raised)] p-2.5 text-xs text-[rgb(var(--iris-text-rgb))]">{error.detail}</pre>
      <div class="mt-2 flex items-center gap-2">
        <button type="button" class="iris-neutral-button rounded-full px-3 py-1.5 text-xs font-600 text-[rgb(var(--iris-text-rgb))]" onclick={copyError}>Copy error</button>
        <span role="status" class="text-xs">{expanded ? copyResult : ''}</span>
      </div>
    </div>
  {/if}
</div>
