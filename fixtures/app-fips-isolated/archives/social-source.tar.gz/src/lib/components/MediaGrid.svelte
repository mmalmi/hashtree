<script lang="ts">
  import { settingsStore } from '../settings';
  import { onDestroy } from 'svelte';
  import NoteEmbedItem from './NoteEmbedItem.svelte';
  import { extractNoteEmbedGroups } from '../noteContent';
  import { selectPrimaryMediaEmbed } from '../media';
  import type { NoteEmbed } from '../noteContent';
  import type { RawEvent } from '../nostr';
  import { getSensitiveMediaWarning } from '../sensitiveMedia';
  import IrisIcon from './IrisIcon.svelte';

  export let events: RawEvent[] = [];
  export let onOpenMedia: ((payload: {
    event: RawEvent;
    embed: NoteEmbed;
    index: number;
    embeds: NoteEmbed[];
  }) => void) | null = null;
  export let emptyLabel = 'No media yet';
  export let className = '';
  export let isActive = true;

  type MediaEntry = {
    event: RawEvent;
    embeds: NoteEmbed[];
    primary: NoteEmbed;
    sensitiveMediaWarning: string | null;
  };

  type MediaTileObserverOptions = {
    active: boolean;
    eager: boolean;
    eventId: string;
  };

  const EAGER_MEDIA_TILE_COUNT = 9;
  const MEDIA_TILE_PRELOAD_MARGIN_PX = 600;

  function mediaEntriesFromEvents(list: RawEvent[]): MediaEntry[] {
    const entries: MediaEntry[] = [];
    for (const event of list) {
      const groups = extractNoteEmbedGroups(event.content, event.tags, event.kind);
      const embeds = groups.flat();
      const primary = selectPrimaryMediaEmbed(embeds);
      if (!primary) {
        continue;
      }
      entries.push({
        event,
        embeds: groups.find((group) => group.some((embed) => embed.url === primary.url)) ?? [primary],
        primary,
        sensitiveMediaWarning: getSensitiveMediaWarning(event),
      });
    }
    return entries;
  }

  let mediaEntries: MediaEntry[] = [];
  let revealedSensitiveEventIds = new Set<string>();
  let activeMediaEventIds = new Set<string>();
  let mediaTileObserver: IntersectionObserver | null = null;
  let mediaTileObserverRoot: Element | null = null;
  const observedMediaTiles = new Map<Element, string>();

  function revealSensitiveMedia(eventId: string): void {
    revealedSensitiveEventIds = new Set([...revealedSensitiveEventIds, eventId]);
  }

  function updateMediaEventVisibility(
    updates: Array<{ eventId: string; active: boolean }>,
  ): void {
    const nextActiveIds = new Set(activeMediaEventIds);
    let changed = false;

    for (const update of updates) {
      if (update.active) {
        if (!nextActiveIds.has(update.eventId)) {
          nextActiveIds.add(update.eventId);
          changed = true;
        }
      } else if (nextActiveIds.delete(update.eventId)) {
        changed = true;
      }
    }

    if (changed) {
      activeMediaEventIds = nextActiveIds;
    }
  }

  function getMediaTileObserver(root: Element | null): IntersectionObserver | null {
    if (typeof IntersectionObserver === 'undefined') {
      return null;
    }
    if (mediaTileObserver && mediaTileObserverRoot !== root) {
      mediaTileObserver.disconnect();
      observedMediaTiles.clear();
      mediaTileObserver = null;
    }
    if (!mediaTileObserver) {
      mediaTileObserverRoot = root;
      mediaTileObserver = new IntersectionObserver((entries) => {
        const visibilityUpdates: Array<{ eventId: string; active: boolean }> = [];
        for (const entry of entries) {
          const eventId = observedMediaTiles.get(entry.target);
          if (eventId) {
            visibilityUpdates.push({
              eventId,
              active: entry.isIntersecting,
            });
          }
        }
        updateMediaEventVisibility(visibilityUpdates);
      }, {
        root,
        rootMargin: `${MEDIA_TILE_PRELOAD_MARGIN_PX}px 0px`,
        threshold: 0,
      });
    }
    return mediaTileObserver;
  }

  function observeMediaTile(
    node: HTMLElement,
    initialOptions: MediaTileObserverOptions,
  ): { update: (options: MediaTileObserverOptions) => void; destroy: () => void } {
    let options = initialOptions;
    let observer: IntersectionObserver | null = null;

    const stopObserving = () => {
      observer?.unobserve(node);
      observedMediaTiles.delete(node);
      observer = null;
      if (!options.eager) {
        updateMediaEventVisibility([{ eventId: options.eventId, active: false }]);
      }
    };

    const startObserving = () => {
      if (!options.active || options.eager) {
        return;
      }
      observer = getMediaTileObserver(node.closest('[data-app-page-scroll]'));
      if (!observer) {
        updateMediaEventVisibility([{ eventId: options.eventId, active: true }]);
        return;
      }
      observedMediaTiles.set(node, options.eventId);
      observer.observe(node);
    };

    startObserving();
    return {
      update(nextOptions) {
        if (
          nextOptions.eager === options.eager
          && nextOptions.active === options.active
          && nextOptions.eventId === options.eventId
        ) {
          return;
        }
        stopObserving();
        options = nextOptions;
        startObserving();
      },
      destroy() {
        stopObserving();
      },
    };
  }

  $: mediaEntries = mediaEntriesFromEvents(events);

  onDestroy(() => {
    mediaTileObserver?.disconnect();
    mediaTileObserverRoot = null;
    observedMediaTiles.clear();
  });
</script>

{#if mediaEntries.length === 0}
  <div data-testid="media-feed-grid" class={`border-b border-white/5 px-4 py-10 text-center text-[0.95rem] text-white/60 sm:px-5 ${className}`.trim()}>
    {emptyLabel}
  </div>
{:else}
  <div data-testid="media-feed-grid" class={`grid grid-cols-3 gap-px sm:gap-0.5 xl:gap-1 ${className}`.trim()}>
    {#each mediaEntries as entry, index (entry.event.id)}
      <article
        data-testid="media-feed-tile"
        data-media-event-id={entry.event.id}
        data-media-active={isActive && (index < EAGER_MEDIA_TILE_COUNT || activeMediaEventIds.has(entry.event.id)) ? 'true' : 'false'}
        use:observeMediaTile={{
          active: isActive,
          eager: index < EAGER_MEDIA_TILE_COUNT,
          eventId: entry.event.id,
        }}
        class="relative aspect-square min-w-0 overflow-hidden bg-[#111111] transition hover:opacity-80"
      >
        {#if $settingsStore.content.blurSensitiveMedia && entry.sensitiveMediaWarning && !revealedSensitiveEventIds.has(entry.event.id)}
          <button
            data-testid="sensitive-media-gate"
            type="button"
            class="flex h-full w-full flex-col items-center justify-center gap-1 bg-[#111111] px-2 text-center text-white transition hover:bg-[#171717] sm:px-3"
            aria-label={`Reveal media: ${entry.sensitiveMediaWarning}`}
            on:click={() => revealSensitiveMedia(entry.event.id)}
          >
            <IrisIcon name="closedeye" size={21} />
            <span class="line-clamp-2 text-[0.7rem] font-700 leading-4 sm:text-[0.82rem]">{entry.sensitiveMediaWarning}</span>
            <span class="text-[0.64rem] text-white/65 sm:text-[0.72rem]">Click to reveal</span>
          </button>
        {:else if index < EAGER_MEDIA_TILE_COUNT || activeMediaEventIds.has(entry.event.id)}
          <NoteEmbedItem
            embed={entry.primary}
            variant="grid"
            active={false}
            viewActive={isActive}
            onOpenMedia={onOpenMedia ? () => onOpenMedia({ event: entry.event, embed: entry.primary, index: 0, embeds: entry.embeds }) : null}
          />
        {:else}
          <div
            data-testid="media-feed-tile-placeholder"
            class="h-full w-full animate-pulse bg-white/4"
            aria-hidden="true"
          ></div>
        {/if}
      </article>
    {/each}
  </div>
{/if}
