import type { CID, Store } from '@hashtree/core';
import { normalizePubkey } from './nostr';
import { throwIfProfileSearchAborted, withProfileSearchAbort } from './profileSearchAbort';
import { readCatalogEnvelope } from './profileSearchV3ClientManifest';
import {
  boundedInteger,
  mapConcurrent,
  mergeHits,
} from './profileSearchV3ClientPrimitives';
import {
  openClientRun,
  type ProfileSearchV3ClientRunDependencies,
} from './profileSearchV3ClientRun';
import {
  MAX_QUERY_RESULTS,
  type ProfileSearchV3ClientCatalog,
  type ProfileSearchV3ClientHit,
  type ProfileSearchV3ClientOpenRun,
} from './profileSearchV3ClientTypes';

export {
  PROFILE_SEARCH_V3_CLIENT_CATALOG_FORMAT,
  PROFILE_SEARCH_V3_CLIENT_RUN_FORMAT,
  type ProfileSearchV3ClientCatalog,
  type ProfileSearchV3ClientCatalogManifest,
  type ProfileSearchV3ClientHit,
  type ProfileSearchV3ClientPostingMode,
  type ProfileSearchV3ClientRunDescriptor,
} from './profileSearchV3ClientTypes';

/**
 * Opens only the authenticated catalog envelope. Immutable runs and routed
 * pages remain lazy, so warmup never downloads the frozen social graph.
 */
export async function openProfileSearchV3ClientCatalog(
  store: Store,
  root: CID,
  signal: AbortSignal | null = null,
  runDependencies: ProfileSearchV3ClientRunDependencies = {},
): Promise<ProfileSearchV3ClientCatalog> {
  const envelope = await readCatalogEnvelope(store, root, signal);
  const runPromises = new Map<number, Promise<ProfileSearchV3ClientOpenRun>>();
  const openRun = async (
    index: number,
    runSignal: AbortSignal | null,
  ): Promise<ProfileSearchV3ClientOpenRun> => {
    throwIfProfileSearchAborted(runSignal);
    const current = runPromises.get(index);
    if (current) {return await withProfileSearchAbort(current, runSignal);}
    const descriptor = envelope.manifest.runs[index];
    const runRoot = envelope.runRoots[index];
    if (!descriptor || !runRoot) {throw new Error('Profile-search v3 run is unavailable');}
    const pending = openClientRun(
      store,
      runRoot,
      descriptor,
      runSignal,
      runDependencies,
    );
    runPromises.set(index, pending);
    void pending.catch(() => {
      if (runPromises.get(index) === pending) {runPromises.delete(index);}
    });
    return await withProfileSearchAbort(pending, runSignal);
  };

  return {
    root: envelope.root,
    manifest: envelope.manifest,
    getProfile: async (value, lookupSignal = null) => {
      throwIfProfileSearchAborted(lookupSignal);
      const pubkey = normalizePubkey(value);
      if (!pubkey) {return null;}
      const index = envelope.manifest.runs.findIndex((run) =>
        run.rangeStart <= pubkey && pubkey <= run.rangeEnd);
      if (index < 0) {return null;}
      return (await (await openRun(index, lookupSignal)).getProfile(pubkey, lookupSignal))?.profile ?? null;
    },
    search: async (rawQuery, rawLimit = 20, options = {}) => {
      const searchSignal = options.signal ?? null;
      throwIfProfileSearchAborted(searchSignal);
      const query = rawQuery.trim();
      if (!query) {return [];}
      const limit = boundedInteger(rawLimit, 1, MAX_QUERY_RESULTS, 'query limit');
      const directPubkey = normalizePubkey(query);
      if (directPubkey) {
        const profile = await (async () => {
          const index = envelope.manifest.runs.findIndex((run) =>
            run.rangeStart <= directPubkey && directPubkey <= run.rangeEnd);
          if (index < 0) {return null;}
          return await (await openRun(index, searchSignal)).getProfile(directPubkey, searchSignal);
        })();
        return profile ? [profile.profile] : [];
      }

      const results = new Array<ProfileSearchV3ClientHit[]>(envelope.manifest.runs.length).fill([]);
      const emit = (): void => {
        if (!options.onProgress) {return;}
        throwIfProfileSearchAborted(searchSignal);
        options.onProgress(mergeHits(results, limit).map((hit) => hit.profile));
      };
      await mapConcurrent(
        envelope.manifest.runs.map((_run, index) => index),
        boundedInteger(options.concurrency ?? 4, 1, 8, 'query concurrency'),
        async (index) => {
          throwIfProfileSearchAborted(searchSignal);
          try {
            results[index] = await (await openRun(index, searchSignal))
              .search(query, limit, searchSignal);
            emit();
          } catch {
            throwIfProfileSearchAborted(searchSignal);
            // One missing/corrupt immutable partition must not forge a result
            // or hide verified progress from the other disjoint partitions.
          }
        },
      );
      throwIfProfileSearchAborted(searchSignal);
      return mergeHits(results, limit).map((hit) => hit.profile);
    },
  };
}
