import {
  SOURCE_PRIORITY_RELAY,
  cloneFilter,
  filtersMatch,
  relaySource,
  verifyNostrEventsWith,
  type EventSource,
  type NostrFilter,
  type NostrVerifiedEvent,
  type QueryOptions,
  type QueryReport,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import { FOR_YOU_RELAY_RESPONSE_GRACE_MS, FOR_YOU_RELAY_WINDOW_MS } from './forYouRelayEngagement';
import type { RelayQueryWorkerOptions } from './socialWorkerTransport';
import type { SocialWorkerClient } from './workerClient';
import type { SocialWorkerHashtreeRoot } from '../workers/socialWorkerProtocol';

const RELAY_SOURCE = relaySource('iris-social:configured-relays');
const DEFAULT_RELAY_QUERY_LIMIT = 256;

type RelayQueryClient = Pick<SocialWorkerClient, 'queryRelayEvents'>;

export type VerifiedReadProgress = (events: readonly NostrVerifiedEvent[]) => void;
type ProgressiveQueryOptions = QueryOptions & { onEvents?: VerifiedReadProgress };

type WorkerRelayEventReaderOptions = {
  getRelays(): readonly string[];
  getClient?(): Promise<RelayQueryClient>;
  mode?: RelayQueryWorkerOptions['mode'];
  onEvents?: VerifiedReadProgress;
  /**
   * Also read the worker's Hashtree index source in the same nostr-pubsub
   * query. Relays may then be empty, and results carry `source`.
   */
  archive?: {
    source: EventSource;
    priority: number;
    maxLimit: number;
    /** The Hashtree index roots to read, current at each query. */
    getRoots(): SocialWorkerHashtreeRoot[];
  };
  /** Longest wait for relays, so they cannot hold up results that other routes already have. */
  maxWindowMs?: number;
};

/**
 * A relay reader whose WebSockets and signature verification live in the
 * existing Hashtree/social worker. Worker failure is terminal for this source;
 * it must never fall back to browser-thread relay verification.
 */
export function createWorkerRelayEventReader(
  options: WorkerRelayEventReaderOptions,
) {
  const getClient = options.getClient ?? defaultWorkerClient;
  return {
    async query(filters: NostrFilter[], queryOptions: ProgressiveQueryOptions = {}): Promise<QueryReport> {
      const maxLimit = options.archive?.maxLimit ?? DEFAULT_RELAY_QUERY_LIMIT;
      validateQueryOptions(queryOptions);
      throwIfAborted(queryOptions.signal);
      // A routed read passes its overall limit to every route; relays answer
      // at most their own bounded page.
      const limit = Math.min(queryOptions.limit ?? DEFAULT_RELAY_QUERY_LIMIT, maxLimit);
      const relays = [...new Set(options.getRelays())];
      if (limit === 0 || filters.length === 0 || (relays.length === 0 && !options.archive)) {
        return { events: [], complete: true };
      }
      const client = await getClient();
      throwIfAborted(queryOptions.signal);
      const now = Date.now();
      const deadline = options.mode ? Math.min(
        (queryOptions.deadline ?? Infinity) - FOR_YOU_RELAY_RESPONSE_GRACE_MS,
        now + FOR_YOU_RELAY_WINDOW_MS,
      ) : options.maxWindowMs === undefined
        ? queryOptions.deadline
        : Math.min(queryOptions.deadline ?? Infinity, now + options.maxWindowMs);
      if (options.mode && deadline !== undefined && deadline <= now) {
        return { events: [], complete: false };
      }
      const admit = async (events: readonly RawEvent[]) => {
        if (events.length > limit) { throw new Error('Relay worker response exceeds requested limit'); }
        const admitted = await admitTrustedRelayWorkerEvents(events, queryOptions.signal);
        if (admitted.some(event => !filtersMatch(filters, event))) {
          throw new Error('Relay worker returned an event outside the requested filters');
        }
        return admitted;
      };
      const progress = queryOptions.onEvents ?? options.onEvents;
      const report = await client.queryRelayEvents(
        relays,
        // A route can ask for more interactions than this worker lane admits.
        // Keep each wire filter within the same bound as the overall query.
        filters.map(filter => filter.limit !== undefined && filter.limit > limit
          ? { ...cloneFilter(filter), limit } : cloneFilter(filter)),
        {
          limit,
          deadline,
          signal: queryOptions.signal,
          ...(progress && { onEvents: async (events: readonly RawEvent[]) => progress(await admit(events)) }),
          ...(options.mode ? { mode: options.mode } : {}),
          ...(options.archive ? { archive: { roots: options.archive.getRoots() } } : {}),
        },
      );
      throwIfAborted(queryOptions.signal);
      const byId = new Map<string, NostrVerifiedEvent>();
      for (const event of await admit(report.events)) {
        if (!byId.has(event.id)) {
          byId.set(event.id, event);
        }
      }
      return {
        events: [...byId.values()]
          .sort((left, right) => (
            right.created_at - left.created_at || left.id.localeCompare(right.id)
          ))
          .map((event) => ({
            event,
            source: options.archive?.source ?? RELAY_SOURCE,
            priority: options.archive?.priority ?? SOURCE_PRIORITY_RELAY,
          })),
        complete: report.complete,
      };
    },
  };
}

/**
 * Canonically admit only the exact serialized batch returned for the tracked
 * dedicated-worker request above. NostrRelayEventSource already verified this
 * batch inside that worker, so repeating worker crypto here would defeat the
 * trust-boundary handoff.
 */
export function admitTrustedRelayWorkerEvents(
  events: readonly RawEvent[],
  signal?: AbortSignal,
): Promise<NostrVerifiedEvent[]> {
  return verifyNostrEventsWith(
    events,
    async (trustedWorkerEvents) => trustedWorkerEvents.map(() => true),
    { signal },
  );
}

async function defaultWorkerClient(): Promise<RelayQueryClient> {
  return await (await import('./workerClient')).getWorkerClient();
}

function validateQueryOptions(options: QueryOptions): void {
  if (
    options.limit !== undefined
    && (!Number.isSafeInteger(options.limit) || options.limit < 0)
  ) {
    throw new RangeError('Relay query limit must be a non-negative integer');
  }
  if (options.deadline !== undefined && !Number.isFinite(options.deadline)) {
    throw new RangeError('Relay query deadline must be finite');
  }
}

function throwIfAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) {
    throw new DOMException('Relay query cancelled', 'AbortError');
  }
}
