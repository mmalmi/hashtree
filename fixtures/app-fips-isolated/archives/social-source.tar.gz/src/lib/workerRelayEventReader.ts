import {
  SOURCE_PRIORITY_RELAY,
  cloneFilter,
  filtersMatch,
  relaySource,
  verifyNostrEventsWith,
  type NostrEventReader,
  type NostrFilter,
  type NostrVerifiedEvent,
  type QueryOptions,
  type QueryReport,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';
import type { SocialWorkerClient } from './workerClient';

const RELAY_SOURCE = relaySource('iris-social:configured-relays');
const DEFAULT_RELAY_QUERY_LIMIT = 256;

type RelayQueryClient = Pick<SocialWorkerClient, 'queryRelayEvents'>;

type WorkerRelayEventReaderOptions = {
  getRelays(): readonly string[];
  getClient?(): Promise<RelayQueryClient>;
};

/**
 * A relay reader whose WebSockets and signature verification live in the
 * existing Hashtree/social worker. Worker failure is terminal for this source;
 * it must never fall back to browser-thread relay verification.
 */
export function createWorkerRelayEventReader(
  options: WorkerRelayEventReaderOptions,
): NostrEventReader {
  const getClient = options.getClient ?? defaultWorkerClient;
  return {
    async query(filters: NostrFilter[], queryOptions: QueryOptions = {}): Promise<QueryReport> {
      validateQueryOptions(queryOptions);
      throwIfAborted(queryOptions.signal);
      const limit = queryOptions.limit ?? DEFAULT_RELAY_QUERY_LIMIT;
      const relays = [...new Set(options.getRelays())];
      if (limit === 0 || filters.length === 0 || relays.length === 0) {
        return { events: [], complete: true };
      }
      const client = await getClient();
      throwIfAborted(queryOptions.signal);
      const report = await client.queryRelayEvents(
        relays,
        filters.map(cloneFilter),
        {
          limit,
          deadline: queryOptions.deadline,
          signal: queryOptions.signal,
        },
      );
      throwIfAborted(queryOptions.signal);
      if (report.events.length > limit) {
        throw new Error('Relay worker response exceeds requested limit');
      }
      const admittedEvents = await admitTrustedRelayWorkerEvents(
        report.events,
        queryOptions.signal,
      );
      const byId = new Map<string, NostrVerifiedEvent>();
      for (const event of admittedEvents) {
        if (!filtersMatch(filters, event)) {
          throw new Error('Relay worker returned an event outside the requested filters');
        }
        if (!byId.has(event.id)) {
          byId.set(event.id, event);
        }
      }
      return {
        events: [...byId.values()]
          .sort((left, right) => (
            right.created_at - left.created_at || left.id.localeCompare(right.id)
          ))
          .map((event) => ({
            event,
            source: RELAY_SOURCE,
            priority: SOURCE_PRIORITY_RELAY,
          })),
        complete: report.complete,
      };
    },
  };
}

/**
 * Canonically admit only the exact serialized batch returned for the tracked
 * dedicated-worker request above. NostrRelayEventSource already verified this
 * batch inside that worker, so repeating worker crypto here would defeat the
 * trust-boundary handoff.
 */
function admitTrustedRelayWorkerEvents(
  events: readonly RawEvent[],
  signal?: AbortSignal,
): Promise<NostrVerifiedEvent[]> {
  return verifyNostrEventsWith(
    events,
    async (trustedWorkerEvents) => trustedWorkerEvents.map(() => true),
    { signal },
  );
}

async function defaultWorkerClient(): Promise<RelayQueryClient> {
  return await (await import('./workerClient')).getWorkerClient();
}

function validateQueryOptions(options: QueryOptions): void {
  if (
    options.limit !== undefined
    && (!Number.isSafeInteger(options.limit) || options.limit < 0 || options.limit > 256)
  ) {
    throw new RangeError('Relay query limit must be between zero and 256');
  }
  if (options.deadline !== undefined && !Number.isFinite(options.deadline)) {
    throw new RangeError('Relay query deadline must be finite');
  }
}

function throwIfAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) {
    throw new DOMException('Relay query cancelled', 'AbortError');
  }
}
