import { nhashDecode, nhashEncode, type CID } from '@hashtree/core';
import { HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import {
  type NostrEvent,
  type NostrRelayTransport,
  type NostrVerifiedEvent,
} from 'nostr-pubsub';
import * as nip19 from 'nostr-tools/nip19';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { sortReplaceableEventsNewestFirst } from './nostrEventOrdering';
import { createWorkerRelayTransport } from './workerRelayTransport';
import {
  PublishedRootEventCache,
  canonicalMutableRootTarget,
  canonicalPublishedRootCacheKey,
  comparePublishedRootEvents,
  getDefaultPublishedRootEventCache,
  validateAdmittedPublishedRootEvent,
  validatePublishedRootEvent,
  validatePublishedRootEventAsync,
  type CanonicalMutableRootTarget,
} from './publishedRootEventCache';

export { canonicalPublishedRootCacheKey, validatePublishedRootEvent };

export type TreeTarget =
  | { kind: 'mutable'; npub: string; path: string }
  | { kind: 'immutable'; root: CID; path: string };

export type PublishedRootResolution = {
  root: CID;
  createdAt: number;
  eventId: string;
};

type ResolveTreeTargetRootOptions = {
  resolveImmutablePath: (root: CID, path: string) => Promise<CID | null>;
  timeoutMs: number;
  settleMs: number;
  retryDelaysMs?: number[];
};

type WatchTreeTargetRootOptions = {
  resolveImmutablePath: (root: CID, path: string) => Promise<CID | null>;
  timeoutMs: number;
  settleMs: number;
};

type DirectRootQueryTransport = Pick<NostrRelayTransport, 'subscribe'>;
type PublishedRootListener = (root: CID | null) => void;

export type PublishedRootEventCandidate = {
  event: NostrEvent;
  resolution: PublishedRootResolution;
};

export type PublishedRootEventCandidateWatch = (
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  listener: (candidate: PublishedRootEventCandidate | null) => void,
  timeoutMs: number,
) => () => void;

const ROOT_QUERY_SETTLE_MS = 750;

export async function firstNonNull<T>(
  candidates: Array<Promise<T | null>>,
): Promise<T | null> {
  if (candidates.length === 0) {
    return null;
  }

  return await new Promise<T | null>((resolve, reject) => {
    let pending = candidates.length;
    let settled = false;
    let lastError: unknown;

    const finishEmptyCandidate = () => {
      pending -= 1;
      if (pending !== 0 || settled) {
        return;
      }
      settled = true;
      if (lastError !== undefined) {
        reject(lastError);
      } else {
        resolve(null);
      }
    };

    for (const candidate of candidates) {
      void candidate.then((value) => {
        if (settled) {
          return;
        }
        if (value !== null) {
          settled = true;
          resolve(value);
          return;
        }
        finishEmptyCandidate();
      }, (error: unknown) => {
        lastError = error;
        finishEmptyCandidate();
      });
    }
  });
}

export function parseTreeTarget(input: string): TreeTarget | null {
  const trimmed = input.trim();
  if (!trimmed) {
    return null;
  }

  if (trimmed.startsWith('npub1')) {
    const slashIndex = trimmed.indexOf('/');
    if (slashIndex <= 0 || slashIndex === trimmed.length - 1) {
      return null;
    }

    return {
      kind: 'mutable',
      npub: trimmed.slice(0, slashIndex),
      path: trimmed.slice(slashIndex + 1),
    };
  }

  if (trimmed.startsWith('htree://')) {
    const withoutProtocol = trimmed.slice('htree://'.length);
    const slashIndex = withoutProtocol.indexOf('/');
    if (slashIndex === -1) {
      return {
        kind: 'immutable',
        root: nhashDecode(withoutProtocol),
        path: '',
      };
    }

    return {
      kind: 'immutable',
      root: nhashDecode(withoutProtocol.slice(0, slashIndex)),
      path: withoutProtocol.slice(slashIndex + 1),
    };
  }

  if (trimmed.startsWith('nhash1')) {
    return {
      kind: 'immutable',
      root: nhashDecode(trimmed),
      path: '',
    };
  }

  return null;
}

async function sleep(timeoutMs: number): Promise<void> {
  await new Promise((resolve) => {
    setTimeout(resolve, timeoutMs);
  });
}

const directRootQueryTransport = createWorkerRelayTransport({
  getRelays: getConfiguredNostrRelays,
});

function candidateFromAdmittedEvent(
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  event: NostrVerifiedEvent,
): PublishedRootEventCandidate | null {
  const resolution = validateAdmittedPublishedRootEvent(target, event);
  return resolution ? { event, resolution } : null;
}

function candidateFromUntrustedEvent(
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  event: NostrEvent,
): PublishedRootEventCandidate | null {
  const resolution = validatePublishedRootEvent(target, event);
  return resolution ? { event, resolution } : null;
}

async function cachedRootCandidate(
  cache: PublishedRootEventCache,
  target: CanonicalMutableRootTarget,
): Promise<PublishedRootEventCandidate | null> {
  const event = cache.get(target.cacheKey);
  if (!event) {
    return null;
  }
  const resolution = await validatePublishedRootEventAsync(target, event);
  const candidate = resolution ? { event, resolution } : null;
  if (!candidate) {
    cache.delete(target.cacheKey);
    return null;
  }
  return candidate;
}

async function resolveLatestPublishedRoot(
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  timeoutMs: number,
): Promise<CID | null> {
  return (await resolveLatestPublishedRootResolution(target, timeoutMs))?.root ?? null;
}

export function selectLatestPublishedRootResolution(
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  events: readonly NostrEvent[],
): PublishedRootResolution | null {
  for (const event of sortReplaceableEventsNewestFirst([...events])) {
    const resolution = validatePublishedRootEvent(target, event);
    if (resolution) {
      return resolution;
    }
  }
  return null;
}

export async function resolveLatestPublishedRootResolution(
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  timeoutMs: number,
): Promise<PublishedRootResolution | null> {
  const canonical = canonicalMutableRootTarget(target);
  if (!canonical) {
    return null;
  }
  const cache = getDefaultPublishedRootEventCache();
  const cachedPromise = cachedRootCandidate(cache, canonical);
  let events: NostrEvent[];
  try {
    events = await queryPublishedRootEvents(canonical, timeoutMs);
  } catch (error) {
    const cached = await cachedPromise;
    if (cached) {
      return cached.resolution;
    }
    throw error;
  }
  const cached = await cachedPromise;
  const candidates = events
    .map((event) => candidateFromAdmittedEvent(
      canonical,
      event as NostrVerifiedEvent,
    ))
    .filter((candidate): candidate is PublishedRootEventCandidate => Boolean(candidate));
  if (cached) {
    candidates.push(cached);
  }
  const winner = candidates.sort((left, right) => (
    comparePublishedRootEvents(left.event, right.event)
  ))[0] ?? null;
  if (!winner) {
    return null;
  }
  cache.set(canonical.cacheKey, winner.event);
  return winner.resolution;
}

export function createPublishedRootEventQuery(
  transport: DirectRootQueryTransport,
): (
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  timeoutMs: number,
) => Promise<NostrEvent[]> {
  return async (target, timeoutMs) => {
    let pubkey: string;
    try {
      const decoded = nip19.decode(target.npub);
      if (decoded.type !== 'npub' || typeof decoded.data !== 'string') {
        return [];
      }
      pubkey = decoded.data;
    } catch {
      return [];
    }

    return await new Promise<NostrEvent[]>((resolve, reject) => {
      const events = new Map<string, NostrEvent>();
      let settled = false;
      let settleTimer: ReturnType<typeof setTimeout> | null = null;
      let timeoutTimer: ReturnType<typeof setTimeout> | null = null;
      let subscription: { close: (reason?: string) => void } | null = null;

      const finish = (error?: Error) => {
        if (settled) {
          return;
        }

        settled = true;
        if (settleTimer) {
          clearTimeout(settleTimer);
        }
        if (timeoutTimer) {
          clearTimeout(timeoutTimer);
        }
        subscription?.close('resolved mutable tree root');
        if (error) {
          reject(error);
          return;
        }
        resolve(sortReplaceableEventsNewestFirst([...events.values()]));
      };

      timeoutTimer = setTimeout(finish, Math.max(timeoutMs, ROOT_QUERY_SETTLE_MS));
      subscription = transport.subscribe([{
          kinds: [...HASHTREE_ROOT_KINDS],
          authors: [pubkey],
          '#d': [target.path],
          limit: 12,
        }], {
        onEvent(event) {
          events.set(event.id, event);
          if (settleTimer) {
            clearTimeout(settleTimer);
          }
          settleTimer = setTimeout(finish, ROOT_QUERY_SETTLE_MS);
        },
        onClose(reasons) {
          const reason = reasons?.filter(Boolean).join('; ');
          finish(events.size === 0 && reason
            ? new Error(`Hashtree root relay query closed: ${reason}`)
            : undefined);
        },
      });
    });
  };
}

const queryPublishedRootEvents = createPublishedRootEventQuery(directRootQueryTransport);

function splitMutableTreePath(path: string): { treeName: string; subPath: string } {
  const [treeName = '', ...subPath] = path.split('/').filter(Boolean);
  return { treeName, subPath: subPath.join('/') };
}

export function createPublishedRootEventCandidateWatch(
  transport: DirectRootQueryTransport,
  options: { eventsAlreadyAdmitted?: boolean } = {},
): PublishedRootEventCandidateWatch {
  return (target, listener, timeoutMs) => {
    const canonical = canonicalMutableRootTarget(target);
    if (!canonical) {
      listener(null);
      return () => undefined;
    }

    let latestCandidate: PublishedRootEventCandidate | null = null;
    let emitted = false;
    const timeout = setTimeout(() => {
      if (!emitted) {
        emitted = true;
        listener(null);
      }
    }, Math.max(1, timeoutMs));
    const subscription = transport.subscribe([{
      kinds: [...HASHTREE_ROOT_KINDS],
      authors: [canonical.pubkey],
      '#d': [canonical.path],
      limit: 12,
    }], {
      onEvent(event) {
        const candidate = options.eventsAlreadyAdmitted
          ? candidateFromAdmittedEvent(canonical, event as NostrVerifiedEvent)
          : candidateFromUntrustedEvent(canonical, event);
        if (!candidate) {
          return;
        }
        if (
          latestCandidate
          && comparePublishedRootEvents(candidate.event, latestCandidate.event) >= 0
        ) {
          return;
        }
        latestCandidate = candidate;
        emitted = true;
        clearTimeout(timeout);
        listener(candidate);
      },
    });

    return () => {
      clearTimeout(timeout);
      subscription.close('stopped mutable tree root watch');
    };
  };
}

export function createPublishedRootEventWatch(
  transport: DirectRootQueryTransport,
): (
  target: Extract<TreeTarget, { kind: 'mutable' }>,
  listener: PublishedRootListener,
  timeoutMs: number,
) => () => void {
  const watchCandidates = createPublishedRootEventCandidateWatch(transport);
  return (target, listener, timeoutMs) => watchCandidates(
    target,
    (candidate) => listener(candidate?.resolution.root ?? null),
    timeoutMs,
  );
}

const watchPublishedRootCandidates = createPublishedRootEventCandidateWatch(
  directRootQueryTransport,
  { eventsAlreadyAdmitted: true },
);

export async function resolveTreeTargetRoot(
  input: string,
  options: ResolveTreeTargetRootOptions,
): Promise<CID | null> {
  const target = parseTreeTarget(input);
  if (!target) {
    return null;
  }

  if (target.kind === 'immutable') {
    if (!target.path) {
      return target.root;
    }

    return await options.resolveImmutablePath(target.root, target.path);
  }

  const { treeName, subPath } = splitMutableTreePath(target.path);
  const rootTarget = canonicalMutableRootTarget({ ...target, path: treeName });
  if (!rootTarget) {
    return null;
  }
  const cache = getDefaultPublishedRootEventCache();
  const cached = await cachedRootCandidate(cache, rootTarget);
  const refresh = cached
    ? resolveLatestPublishedRoot(rootTarget, options.timeoutMs).catch(() => null)
    : null;
  if (cached) {
    try {
      const cachedRoot = subPath
        ? await options.resolveImmutablePath(cached.resolution.root, subPath)
        : cached.resolution.root;
      if (cachedRoot) {
        void refresh;
        return cachedRoot;
      }
    } catch {
      // A missing cached subpath may become available after root refresh.
    }
  }

  let root = refresh
    ? await refresh
    : await resolveLatestPublishedRoot(rootTarget, options.timeoutMs);
  if (root) {
    return subPath ? await options.resolveImmutablePath(root, subPath) : root;
  }

  for (const delayMs of options.retryDelaysMs ?? []) {
    await sleep(delayMs);
    root = await resolveLatestPublishedRoot(rootTarget, options.timeoutMs);
    if (root) {
      return subPath ? await options.resolveImmutablePath(root, subPath) : root;
    }
  }

  return null;
}

type TreeTargetRootWatcherOptions = {
  cache: PublishedRootEventCache;
  watchCandidates: PublishedRootEventCandidateWatch;
};

export function createTreeTargetRootWatcher(
  watcherOptions: TreeTargetRootWatcherOptions,
): (
  input: string,
  listener: (root: CID | null) => void,
  options: WatchTreeTargetRootOptions,
) => Promise<() => Promise<void>> {
  return async (input, listener, options) => {
    const target = parseTreeTarget(input);
    if (!target) {
      listener(null);
      return async () => undefined;
    }

    if (target.kind === 'immutable') {
      listener(target.path ? await options.resolveImmutablePath(target.root, target.path) : target.root);
      return async () => undefined;
    }

    const { treeName, subPath } = splitMutableTreePath(target.path);
    const rootTarget = canonicalMutableRootTarget({ ...target, path: treeName });
    if (!rootTarget) {
      listener(null);
      return async () => undefined;
    }

    let stopped = false;
    let winningCandidate: PublishedRootEventCandidate | null = null;
    let lastEmittedRoot: string | null = null;
    let resolveTicket = 0;
    const emitDistinctRoot = (root: CID | null) => {
      if (stopped) {
        return;
      }
      const encoded = root ? nhashEncode(root) : '';
      if (encoded === lastEmittedRoot) {
        return;
      }
      lastEmittedRoot = encoded;
      listener(root);
    };
    const acceptCandidate = async (
      candidate: PublishedRootEventCandidate,
      persist: boolean,
    ): Promise<void> => {
      if (
        winningCandidate
        && comparePublishedRootEvents(candidate.event, winningCandidate.event) >= 0
      ) {
        return;
      }
      winningCandidate = candidate;
      if (persist) {
        watcherOptions.cache.set(rootTarget.cacheKey, candidate.event);
      }
      const ticket = ++resolveTicket;
      try {
        const resolved = subPath
          ? await options.resolveImmutablePath(candidate.resolution.root, subPath)
          : candidate.resolution.root;
        if (ticket === resolveTicket && winningCandidate.event.id === candidate.event.id) {
          emitDistinctRoot(resolved);
        }
      } catch {
        if (ticket === resolveTicket && lastEmittedRoot === null) {
          emitDistinctRoot(null);
        }
      }
    };

    const cached = await cachedRootCandidate(watcherOptions.cache, rootTarget);
    // Set the cached winner synchronously before the transport can call back.
    // Subpath IO remains concurrent with subscription setup.
    const cachedResolution = cached
      ? acceptCandidate(cached, false)
      : Promise.resolve();
    const stopWatching = watcherOptions.watchCandidates(rootTarget, (candidate) => {
      if (!candidate) {
        if (!winningCandidate) {
          emitDistinctRoot(null);
        }
        return;
      }
      void acceptCandidate(candidate, true);
    }, options.timeoutMs);

    await cachedResolution;

    return async () => {
      stopped = true;
      resolveTicket += 1;
      stopWatching();
    };
  };
}

export async function watchTreeTargetRoot(
  input: string,
  listener: (root: CID | null) => void,
  options: WatchTreeTargetRootOptions,
): Promise<() => Promise<void>> {
  return await createTreeTargetRootWatcher({
    cache: getDefaultPublishedRootEventCache(),
    watchCandidates: watchPublishedRootCandidates,
  })(input, listener, options);
}

export function toImmutableTreeTargetRef(root: CID, path = ''): string {
  return path ? `htree://${nhashEncode(root)}/${path}` : nhashEncode(root);
}
