import type { CID } from '@hashtree/core';
import {
  createPersonalEventIndexReadStore,
  isLocalPersonalEventIndexRoot,
} from './personalEventIndexBrowser';
import { socialDataPlane } from './socialDataPlane';
import { createSocialDataPlaneEventReader } from './socialDataPlaneEventReader';
import {
  ShadowReadComparator,
  type ShadowReadComparatorSnapshot,
} from './shadowReadComparator';
import { createWorkerBlockStore } from './workerBlockStore';

declare global {
  interface Window {
    __IRIS_SOCIAL_SHADOW_READS__?: ShadowReadComparatorSnapshot;
  }
}

let comparator: ShadowReadComparator | null = null;

export function getBrowserShadowReadComparator(): ShadowReadComparator {
  if (comparator && !comparator.snapshot().stopped) {return comparator;}
  const sharedStore = createWorkerBlockStore();
  const personalStore = createPersonalEventIndexReadStore();
  comparator = new ShadowReadComparator({
    store: sharedStore,
    liveOverlayReader: createSocialDataPlaneEventReader(() => (
      socialDataPlane.query({ includeDeletionEvents: true })
    ), (eventId) => socialDataPlane.getStoredEvent(eventId), {
      verifyEvents: async (events, signal) => (
        await (await import('./workerClient')).getWorkerClient().then(
          (worker) => worker.verifyEvents([...events], signal),
        )
      ),
    }),
    storeForRoot: (root: CID, namespace) => (
      namespace === 'personal' && isLocalPersonalEventIndexRoot(root)
        ? personalStore
        : sharedStore
    ),
    onResult: () => {
      queueMicrotask(updateBrowserSnapshot);
    },
  });
  if (typeof window !== 'undefined') {
    window.__IRIS_SOCIAL_SHADOW_READS__ = comparator.snapshot();
  }
  return comparator;
}

function updateBrowserSnapshot(): void {
  if (typeof window !== 'undefined' && comparator) {
    window.__IRIS_SOCIAL_SHADOW_READS__ = comparator.snapshot();
  }
}

export function stopBrowserShadowReadComparator(): void {
  comparator?.stop();
  if (typeof window !== 'undefined' && comparator) {
    window.__IRIS_SOCIAL_SHADOW_READS__ = comparator.snapshot();
  }
  comparator = null;
}
