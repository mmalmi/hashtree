import { get, writable } from 'svelte/store';
import type { BlossomServerConfig } from '@hashtree/worker';
import {
  EXCHANGE_RATE_CURRENCIES,
  type ExchangeRateCurrency,
} from './exchangeRates';
import {
  applyThemePreference,
  normalizeThemePreference,
  type ThemePreference,
} from './theme';

const STORAGE_KEY_SETTINGS = 'iris-social:settings';

export const DEFAULT_PRIVATE_NOSTR_RELAYS = [
  'wss://temp.iris.to',
  'wss://relay.primal.net',
  'wss://relay.snort.social',
  'wss://nos.lol',
];

export const DEFAULT_NOSTR_RELAYS = [
  'wss://relay.ditto.pub',
  ...DEFAULT_PRIVATE_NOSTR_RELAYS,
];

export const DEFAULT_BLOSSOM_SERVERS: BlossomServerConfig[] = [
  { url: 'https://upload.iris.to', read: false, write: true },
  { url: 'https://cdn.iris.to', read: true, write: false },
];

export const DEFAULT_STORAGE_MAX_BYTES = 1024 * 1024 * 1024;

export interface NetworkSettings {
  relays: string[];
  /** Retained separately so new public defaults never expand private delivery. */
  privateRelays?: string[];
  /** A paused endpoint stays in its saved scopes for later re-enabling. */
  disabledRelays?: string[];
  relayHomeFeedReads: boolean;
  relayContentReads: boolean;
  publicGraphSnapshot: boolean;
  refreshProfiles: boolean;
  blossomServers: BlossomServerConfig[];
}

export interface StorageSettings {
  maxBytes: number;
}

export interface AppearanceSettings {
  theme: ThemePreference;
  showConnectionIndicator: boolean;
}

export const DEFAULT_CONTENT_SETTINGS = {
  showClientTag: true,
  blurSensitiveMedia: true,
  autoplayVideos: true,
  showReactions: true,
  showReactionCounts: true,
  showLikes: true,
  showReposts: true,
  showReplies: true,
  showZaps: true,
};
export type ContentSettings = typeof DEFAULT_CONTENT_SETTINGS;

export interface WalletSettings {
  primaryCurrency: ExchangeRateCurrency;
  showBalanceInNavigation: boolean;
  /** Bits sent by one tap on the zap button; 0 asks for an amount each time. */
  defaultZapBits: number;
  defaultZapComment: string;
}

export type SearchModelPreference = 'auto' | 'minilm' | 'browser' | 'ollama';

export interface SearchSettings {
  aiSearch: boolean;
  model: SearchModelPreference;
  ollamaModel: string;
}

export const DEFAULT_SEARCH_SETTINGS: SearchSettings = {
  aiSearch: true,
  model: 'auto',
  ollamaModel: 'gemma3:1b',
};

const VALID_SEARCH_MODELS = new Set<SearchModelPreference>(['auto', 'minilm', 'browser', 'ollama']);

export const MAX_DEFAULT_ZAP_BITS = 10_000_000;
export const MAX_ZAP_COMMENT_LENGTH = 280;

export interface AppSettings {
  appearance: AppearanceSettings;
  network: NetworkSettings;
  storage: StorageSettings;
  wallet: WalletSettings;
  content: ContentSettings;
  search: SearchSettings;
}

type StoredSettings = Partial<{
  appearance: Partial<AppearanceSettings>;
  network: Partial<NetworkSettings>;
  storage: Partial<StorageSettings>;
  wallet: Partial<WalletSettings>;
  content: Partial<ContentSettings>;
  search: Partial<SearchSettings>;
}>;

export const DEFAULT_NETWORK_SETTINGS: NetworkSettings = {
  relays: [...DEFAULT_NOSTR_RELAYS],
  privateRelays: [...DEFAULT_PRIVATE_NOSTR_RELAYS],
  relayHomeFeedReads: true,
  relayContentReads: false,
  publicGraphSnapshot: true,
  refreshProfiles: true,
  blossomServers: DEFAULT_BLOSSOM_SERVERS.map((server) => ({ ...server })),
};

export const DEFAULT_STORAGE_SETTINGS: StorageSettings = {
  maxBytes: DEFAULT_STORAGE_MAX_BYTES,
};

export const DEFAULT_APPEARANCE_SETTINGS: AppearanceSettings = {
  theme: 'system',
  showConnectionIndicator: false,
};

export const DEFAULT_WALLET_SETTINGS: WalletSettings = {
  primaryCurrency: 'SAT',
  showBalanceInNavigation: true,
  defaultZapBits: 0,
  defaultZapComment: '',
};

export const DEFAULT_SETTINGS: AppSettings = {
  appearance: DEFAULT_APPEARANCE_SETTINGS,
  network: DEFAULT_NETWORK_SETTINGS,
  storage: DEFAULT_STORAGE_SETTINGS,
  wallet: DEFAULT_WALLET_SETTINGS,
  content: DEFAULT_CONTENT_SETTINGS,
  search: DEFAULT_SEARCH_SETTINGS,
};

function cloneSettings(settings: AppSettings): AppSettings {
  return {
    appearance: { ...settings.appearance },
    network: {
      relays: [...settings.network.relays],
      privateRelays: [...(settings.network.privateRelays ?? settings.network.relays)],
      disabledRelays: [...(settings.network.disabledRelays ?? [])],
      relayHomeFeedReads: settings.network.relayHomeFeedReads,
      relayContentReads: settings.network.relayContentReads,
      publicGraphSnapshot: settings.network.publicGraphSnapshot,
      refreshProfiles: settings.network.refreshProfiles,
      blossomServers: settings.network.blossomServers.map((server) => ({ ...server })),
    },
    storage: { ...settings.storage },
    wallet: { ...settings.wallet },
    content: { ...settings.content },
    search: { ...settings.search },
  };
}

function normalizePositiveInteger(value: unknown, fallback: number, minimum = 1): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }
  return Math.max(minimum, Math.floor(parsed));
}

export function normalizeRelayUrl(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'wss:' && parsed.protocol !== 'ws:') {
      return null;
    }
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return null;
  }
}

function normalizeHttpUrl(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return null;
  }
}

function normalizeBlossomServers(servers: unknown): BlossomServerConfig[] {
  if (!Array.isArray(servers)) {
    return DEFAULT_BLOSSOM_SERVERS.map((server) => ({ ...server }));
  }

  const byUrl = new Map<string, BlossomServerConfig>();
  for (const server of servers) {
    const candidate = server as Partial<BlossomServerConfig>;
    const url = normalizeHttpUrl(candidate?.url);
    if (!url) {
      continue;
    }

    byUrl.set(url, {
      url,
      read: candidate?.read !== false,
      write: candidate?.write === true,
    });
  }

  return byUrl.size > 0
    ? [...byUrl.values()]
    : DEFAULT_BLOSSOM_SERVERS.map((server) => ({ ...server }));
}

function normalizeRelays(relays: unknown): string[] {
  if (!Array.isArray(relays)) {
    return [];
  }

  const unique = [...new Set(relays.map((relay) => normalizeRelayUrl(relay)).filter(Boolean))] as string[];
  return unique;
}

function normalizeNetworkSettings(network: Partial<NetworkSettings> | undefined): NetworkSettings {
  const relays = network === undefined ? [...DEFAULT_NOSTR_RELAYS] : normalizeRelays(network?.relays);
  const privateRelays = network === undefined
    ? [...DEFAULT_PRIVATE_NOSTR_RELAYS]
    : normalizeRelays(network?.privateRelays === undefined ? network?.relays : network.privateRelays);
  const legacyRelayReads = typeof network?.relayContentReads === 'boolean' ? network.relayContentReads : undefined;
  return {
    relays,
    privateRelays,
    disabledRelays: normalizeRelays(network?.disabledRelays).filter(url => relays.includes(url) || privateRelays.includes(url)),
    // Earlier releases saved `relayContentReads: false` as a default with any
    // network edit, so only an explicit choice here turns relay reads off.
    relayHomeFeedReads: typeof network?.relayHomeFeedReads === 'boolean'
      ? network.relayHomeFeedReads
      : DEFAULT_NETWORK_SETTINGS.relayHomeFeedReads,
    relayContentReads: network?.relayContentReads === true,
    // Earlier releases used the public content toggle for graph downloads.
    publicGraphSnapshot: typeof network?.publicGraphSnapshot === 'boolean'
      ? network.publicGraphSnapshot : legacyRelayReads ?? DEFAULT_NETWORK_SETTINGS.publicGraphSnapshot,
    refreshProfiles: network?.refreshProfiles !== false,
    blossomServers: normalizeBlossomServers(network?.blossomServers),
  };
}

function normalizeStorageSettings(storage: Partial<StorageSettings> | undefined): StorageSettings {
  return {
    maxBytes: normalizePositiveInteger(storage?.maxBytes, DEFAULT_STORAGE_SETTINGS.maxBytes),
  };
}

function normalizeAppearanceSettings(
  appearance: Partial<AppearanceSettings> | undefined,
): AppearanceSettings {
  return {
    theme: normalizeThemePreference(appearance?.theme),
    showConnectionIndicator: appearance?.showConnectionIndicator === true,
  };
}

function normalizeWalletSettings(wallet: Partial<WalletSettings> | undefined): WalletSettings {
  const primaryCurrency = EXCHANGE_RATE_CURRENCIES.includes(
    wallet?.primaryCurrency as ExchangeRateCurrency,
  )
    ? wallet!.primaryCurrency as ExchangeRateCurrency
    : DEFAULT_WALLET_SETTINGS.primaryCurrency;
  const defaultZapBits = Number(wallet?.defaultZapBits);
  return {
    primaryCurrency,
    showBalanceInNavigation: wallet?.showBalanceInNavigation !== false,
    defaultZapBits: Number.isSafeInteger(defaultZapBits) && defaultZapBits > 0
      ? Math.min(defaultZapBits, MAX_DEFAULT_ZAP_BITS)
      : DEFAULT_WALLET_SETTINGS.defaultZapBits,
    defaultZapComment: typeof wallet?.defaultZapComment === 'string'
      ? wallet.defaultZapComment.trim().slice(0, MAX_ZAP_COMMENT_LENGTH)
      : DEFAULT_WALLET_SETTINGS.defaultZapComment,
  };
}

function normalizeSearchSettings(search: Partial<SearchSettings> | undefined): SearchSettings {
  const model = VALID_SEARCH_MODELS.has(search?.model as SearchModelPreference)
    ? (search!.model as SearchModelPreference)
    : DEFAULT_SEARCH_SETTINGS.model;
  const ollamaModel = typeof search?.ollamaModel === 'string' && search.ollamaModel.trim()
    ? search.ollamaModel.trim().slice(0, 120)
    : DEFAULT_SEARCH_SETTINGS.ollamaModel;
  return {
    aiSearch: search?.aiSearch !== false,
    model,
    ollamaModel,
  };
}

function normalizeSettings(value: StoredSettings | null | undefined): AppSettings {
  return {
    appearance: normalizeAppearanceSettings(value?.appearance),
    network: normalizeNetworkSettings(value?.network),
    storage: normalizeStorageSettings(value?.storage),
    wallet: normalizeWalletSettings(value?.wallet),
    content: Object.fromEntries(Object.entries(DEFAULT_CONTENT_SETTINGS).map(([key, fallback]) => {
      const candidate = value?.content?.[key as keyof ContentSettings];
      return [key, typeof candidate === 'boolean' ? candidate : fallback];
    })) as ContentSettings,
    search: normalizeSearchSettings(value?.search),
  };
}

function saveSettingsToStorage(settings: AppSettings): void {
  if (typeof localStorage === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch {
    // Ignore storage errors.
  }
}

export function readStoredSettingsSnapshot(): AppSettings {
  if (typeof localStorage === 'undefined') {
    return cloneSettings(DEFAULT_SETTINGS);
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (raw === null) {
      return cloneSettings(DEFAULT_SETTINGS);
    }

    const stored = JSON.parse(raw);
    if (!stored || typeof stored !== 'object' || Array.isArray(stored)) { throw new Error('Invalid settings'); }
    return normalizeSettings(stored as StoredSettings);
  } catch {
    return normalizeSettings({ network: { relays: [], privateRelays: [] } });
  }
}

function createSettingsStore() {
  const initialSettings = readStoredSettingsSnapshot();
  applyThemePreference(initialSettings.appearance.theme);
  const { subscribe, set, update } = writable<AppSettings>(initialSettings);

  function commit(next: AppSettings): AppSettings {
    saveSettingsToStorage(next);
    applyThemePreference(next.appearance.theme);
    return next;
  }

  return {
    subscribe,
    set,
    update,
    getState: (): AppSettings => get(settingsStore),
    replace(nextSettings: AppSettings): void {
      const normalized = normalizeSettings(nextSettings);
      set(commit(normalized));
    },
    setAppearanceSettings(partial: Partial<AppearanceSettings>): void {
      update((current) => commit(normalizeSettings({
        ...current,
        appearance: {
          ...current.appearance,
          ...partial,
        },
      })));
    },
    setNetworkSettings(partial: Partial<NetworkSettings>): void {
      update((current) => {
        const next = normalizeSettings({
          ...current,
          network: {
            ...current.network,
            ...partial,
            // The existing relay control governs both public and private traffic.
            ...(Object.hasOwn(partial, 'relays') && !Object.hasOwn(partial, 'privateRelays')
              ? { privateRelays: partial.relays } : {}),
          },
        });
        return commit(next);
      });
    },
    resetNetworkSettings(): void {
      update((current) => {
        const next = normalizeSettings({
          ...current,
          network: DEFAULT_NETWORK_SETTINGS,
        });
        return commit(next);
      });
    },
    setStorageSettings(partial: Partial<StorageSettings>): void {
      update((current) => {
        const next = normalizeSettings({
          ...current,
          storage: {
            ...current.storage,
            ...partial,
          },
        });
        return commit(next);
      });
    },
    setContentSettings(partial: Partial<ContentSettings>): void {
      update(current => commit(normalizeSettings({
        ...current, content: { ...current.content, ...partial },
      })));
    },
    setSearchSettings(partial: Partial<SearchSettings>): void {
      update(current => commit(normalizeSettings({
        ...current, search: { ...current.search, ...partial },
      })));
    },
    setWalletSettings(partial: Partial<WalletSettings>): void {
      update((current) => commit(normalizeSettings({
        ...current,
        wallet: {
          ...current.wallet,
          ...partial,
        },
      })));
    },
    resetStorageSettings(): void {
      update((current) => {
        const next = normalizeSettings({
          ...current,
          storage: DEFAULT_STORAGE_SETTINGS,
        });
        return commit(next);
      });
    },
  };
}

export const settingsStore = createSettingsStore();
