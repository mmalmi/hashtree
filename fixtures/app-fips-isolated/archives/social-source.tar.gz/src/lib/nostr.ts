import * as nip19 from 'nostr-tools/nip19';
import { contactMemoryStore } from './contactMemoryStore';
import { isNip10ReplyTag } from './nostrReplyTags';

export type RawEvent = {
  id: string;
  pubkey: string;
  created_at: number;
  kind: number;
  tags: string[][];
  content: string;
  sig: string;
};

export type NostrEventReference =
  | { type: 'note'; eventId: string }
  | { type: 'nevent'; eventId: string; author: string | null; kind: number | null; relays: string[] }
  | { type: 'naddr'; identifier: string; pubkey: string; kind: number; relays: string[] };

export type NostrProfile = {
  name?: string;
  display_name?: string;
  about?: string;
  picture?: string;
  banner?: string;
  nip05?: string;
  website?: string;
  lud16?: string;
  lud06?: string;
};

export type ProfileRecord = {
  pubkey: string;
  npub: string;
  eventId: string | null;
  createdAt: number | null;
  name: string | null;
  displayName: string | null;
  about: string | null;
  picture: string | null;
  banner: string | null;
  nip05: string | null;
  website: string | null;
  lud16: string | null;
  lud06: string | null;
  searchAliases?: string[];
  socialDistance?: number | null;
  followedByFriends?: number | null;
};

const identityAdjectives = [
  'Amber',
  'Bright',
  'Calm',
  'Clear',
  'Golden',
  'Lunar',
  'Nova',
  'Quiet',
  'Silver',
  'Solar',
  'Velvet',
  'Wild',
];

const identityNouns = [
  'Aurora',
  'Comet',
  'Echo',
  'Falcon',
  'Harbor',
  'Listener',
  'Otter',
  'Raven',
  'Signal',
  'Sparrow',
  'Tide',
  'Voyager',
];

function hashSeed(seed: string): number {
  let hash = 0;
  for (let index = 0; index < seed.length; index += 1) {
    hash = (hash * 31 + seed.charCodeAt(index)) >>> 0;
  }
  return hash;
}

function fallbackProfileName(seed: string): string {
  const hash = hashSeed(seed);
  const adjective = identityAdjectives[hash % identityAdjectives.length] ?? 'Quiet';
  const noun =
    identityNouns[Math.floor(hash / identityAdjectives.length) % identityNouns.length] ?? 'Listener';
  return `${adjective} ${noun}`;
}

export function isHexPubkey(value: string): boolean {
  return /^[0-9a-f]{64}$/i.test(value.trim());
}

export function isHexEventId(value: string): boolean {
  return /^[0-9a-f]{64}$/i.test(value.trim());
}

export function normalizePubkey(value: string): string | null {
  const trimmed = stripNostrScheme(value);
  if (!trimmed) {
    return null;
  }

  if (isHexPubkey(trimmed)) {
    return trimmed.toLowerCase();
  }

  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return decoded.data.toLowerCase();
    }
    if (
      decoded.type === 'nprofile'
      && decoded.data
      && typeof decoded.data === 'object'
      && typeof decoded.data.pubkey === 'string'
      && isHexPubkey(decoded.data.pubkey)
    ) {
      return decoded.data.pubkey.toLowerCase();
    }
    return null;
  } catch {
    return null;
  }
}

export function pubkeyToNpub(pubkey: string): string {
  return nip19.npubEncode(pubkey);
}

export function stripNostrScheme(value: string): string {
  const trimmed = value.trim();
  return trimmed.startsWith('nostr:') ? trimmed.slice('nostr:'.length) : trimmed;
}

export function canonicalizeThreadReference(value: string): string {
  const trimmed = stripNostrScheme(value);
  if (!trimmed) {
    return '';
  }

  if (isHexEventId(trimmed)) {
    return nip19.noteEncode(trimmed.toLowerCase());
  }

  const decoded = decodeNostrEventReference(trimmed);
  if (decoded?.type === 'note') {
    return nip19.noteEncode(decoded.eventId);
  }

  // A shared nevent's author is a discovery hint for the author's personal
  // Hashtree event index. Keep the canonical bech32 reference intact so thread
  // loading can use that hint after the configured indexes miss.
  if (decoded?.type === 'nevent') {
    return trimmed.toLowerCase();
  }

  return trimmed;
}

export function getEventIdFromReference(value: string): string | null {
  const trimmed = stripNostrScheme(value);
  if (!trimmed) {
    return null;
  }

  if (isHexEventId(trimmed)) {
    return trimmed.toLowerCase();
  }

  const decoded = decodeNostrEventReference(trimmed);
  if (decoded?.type === 'note' || decoded?.type === 'nevent') {
    return decoded.eventId;
  }

  return null;
}

export function getTagValue(event: RawEvent, name: string): string | null {
  const normalizedName = name.toLowerCase();
  for (const tag of event.tags) {
    if (tag[0]?.toLowerCase() === normalizedName && typeof tag[1] === 'string') {
      return tag[1];
    }
  }
  return null;
}

export function isParameterizedReplaceableKind(kind: number): boolean {
  return kind >= 30000 && kind < 40000;
}

export function getAddressableEventCoordinate(event: RawEvent): string | null {
  if (!isParameterizedReplaceableKind(event.kind)) {
    return null;
  }

  const identifier = getTagValue(event, 'd');
  return identifier === null ? null : `${event.kind}:${event.pubkey}:${identifier}`;
}

export function getAddressableCoordinateFromReference(value: string): string | null {
  const decoded = decodeNostrEventReference(stripNostrScheme(value));
  return decoded?.type === 'naddr'
    ? `${decoded.kind}:${decoded.pubkey}:${decoded.identifier}`
    : null;
}

export function shortNpub(value: string, head = 10, tail = 6): string {
  if (value.length <= head + tail + 1) {
    return value;
  }
  return `${value.slice(0, head)}…${value.slice(-tail)}`;
}

export function fallbackProfileNameForIdentity(identity: string | null | undefined): string {
  const trimmed = `${identity ?? ''}`.trim();
  if (!trimmed) {
    return 'Quiet Listener';
  }

  if (trimmed.startsWith('npub1')) {
    try {
      const decoded = nip19.decode(trimmed);
      if (decoded.type === 'npub') {
        return fallbackProfileName(`${decoded.data}`);
      }
    } catch {
      // Fall back to hashing the provided identifier.
    }
  }

  return fallbackProfileName(trimmed);
}

export function extractFollowPubkeys(event: RawEvent | null): string[] {
  if (!event) {
    return [];
  }

  const follows = new Set<string>();
  for (const tag of event.tags) {
    if (tag[0] !== 'p' || typeof tag[1] !== 'string') {
      continue;
    }
    const pubkey = normalizePubkey(tag[1]);
    if (pubkey) {
      follows.add(pubkey);
    }
  }
  return [...follows];
}

function getEventTagsByName(event: RawEvent, name: string): string[][] {
  const normalizedName = name.toLowerCase();
  return event.tags.filter((tag) => tag[0]?.toLowerCase() === normalizedName);
}

function getTaggedEventId(tags: string[][], marker: string): string | null {
  const normalizedMarker = marker.toLowerCase();
  for (const tag of tags) {
    if (typeof tag[1] !== 'string' || !tag[1]) {
      continue;
    }

    if ((tag[3] ?? '').toLowerCase() === normalizedMarker) {
      return tag[1];
    }
  }

  return null;
}

export function isReplyEvent(event: RawEvent): boolean {
  return event.tags.some(isNip10ReplyTag);
}

export function getThreadRootEventId(event: RawEvent): string | null {
  const eTags = getEventTagsByName(event, 'e').filter(isNip10ReplyTag);
  const rootTagged = getTaggedEventId(eTags, 'root');
  if (rootTagged) {
    return rootTagged;
  }

  return typeof eTags[0]?.[1] === 'string' && eTags[0][1] ? eTags[0][1] : null;
}

export function getThreadParentEventId(event: RawEvent): string | null {
  const eTags = getEventTagsByName(event, 'e').filter(isNip10ReplyTag);
  const replyTagged = getTaggedEventId(eTags, 'reply');
  if (replyTagged) {
    return replyTagged;
  }

  if (eTags.length >= 2 && typeof eTags[eTags.length - 1]?.[1] === 'string' && eTags[eTags.length - 1]?.[1]) {
    return eTags[eTags.length - 1]?.[1] ?? null;
  }

  return typeof eTags[0]?.[1] === 'string' && eTags[0][1] ? eTags[0][1] : null;
}

function naddrFromAddressCoordinate(coordinate: string): string | null {
  const firstSeparator = coordinate.indexOf(':');
  const secondSeparator = coordinate.indexOf(':', firstSeparator + 1);
  if (firstSeparator <= 0 || secondSeparator <= firstSeparator + 1) {
    return null;
  }

  const kindText = coordinate.slice(0, firstSeparator);
  const pubkey = coordinate.slice(firstSeparator + 1, secondSeparator).toLowerCase();
  const identifier = coordinate.slice(secondSeparator + 1);
  if (!/^\d+$/.test(kindText) || !isHexPubkey(pubkey)) {
    return null;
  }

  const kind = Number(kindText);
  if (!Number.isSafeInteger(kind) || kind < 0) {
    return null;
  }

  try {
    return nip19.naddrEncode({ identifier, pubkey, kind });
  } catch {
    return null;
  }
}

/**
 * Return a reference that the Hashtree event reader can resolve for a reply's
 * immediate parent. NIP-22 deliberately distinguishes uppercase root-scope
 * tags from lowercase parent-scope tags, while NIP-10 uses e-tag markers.
 */
export function getThreadParentReference(event: RawEvent): string | null {
  if (event.kind !== 1_111) {
    return getThreadParentEventId(event);
  }

  const parentTag = event.tags.find((tag) => (
    tag[0] === 'e' || tag[0] === 'a' || tag[0] === 'i'
  ));
  const value = parentTag?.[1]?.trim() ?? '';
  if (!parentTag || !value) {
    return null;
  }

  if (parentTag[0] === 'e') {
    return isHexEventId(value) ? value.toLowerCase() : null;
  }
  if (parentTag[0] === 'a') {
    return naddrFromAddressCoordinate(value);
  }

  // An `i` tag points outside the Nostr event address space, so there is no
  // signed Nostr event for InlineNoteQuote to load from a Hashtree index.
  return null;
}

/**
 * Return the root-scope reference for a conversation. NIP-22 uses uppercase
 * tags for the root scope, including addressable `A` roots, while NIP-10 uses
 * marked `e` tags.
 */
export function getThreadRootReference(event: RawEvent): string | null {
  if (event.kind !== 1_111) {
    return getThreadRootEventId(event);
  }

  const rootTag = event.tags.find((tag) => (
    tag[0] === 'E' || tag[0] === 'A' || tag[0] === 'I'
  ));
  const value = rootTag?.[1]?.trim() ?? '';
  if (!rootTag || !value) {
    return null;
  }

  if (rootTag[0] === 'E') {
    return isHexEventId(value) ? value.toLowerCase() : null;
  }
  if (rootTag[0] === 'A') {
    return naddrFromAddressCoordinate(value);
  }

  return null;
}

export function decodeNostrEventReference(value: string): NostrEventReference | null {
  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'note' && typeof decoded.data === 'string') {
      return { type: 'note', eventId: decoded.data };
    }

    if (decoded.type === 'nevent' && decoded.data && typeof decoded.data === 'object') {
      return {
        type: 'nevent',
        eventId: decoded.data.id,
        author: typeof decoded.data.author === 'string' ? decoded.data.author : null,
        kind: typeof decoded.data.kind === 'number' ? decoded.data.kind : null,
        relays: Array.isArray(decoded.data.relays)
          ? decoded.data.relays.filter((relay): relay is string => typeof relay === 'string')
          : [],
      };
    }

    if (decoded.type === 'naddr' && decoded.data && typeof decoded.data === 'object') {
      return {
        type: 'naddr',
        identifier: decoded.data.identifier,
        pubkey: decoded.data.pubkey,
        kind: decoded.data.kind,
        relays: Array.isArray(decoded.data.relays)
          ? decoded.data.relays.filter((relay): relay is string => typeof relay === 'string')
          : [],
      };
    }
  } catch {
    return null;
  }

  return null;
}

export function parseProfileEvent(event: RawEvent | null): ProfileRecord | null {
  if (!event || event.kind !== 0) {
    return null;
  }

  let content: NostrProfile = {};
  try {
    const parsed = JSON.parse(event.content) as NostrProfile;
    if (parsed && typeof parsed === 'object') {
      content = parsed;
    }
  } catch {
    content = {};
  }

  return {
    pubkey: event.pubkey,
    npub: pubkeyToNpub(event.pubkey),
    eventId: event.id,
    createdAt: event.created_at,
    name: typeof content.name === 'string' ? content.name : null,
    displayName: typeof content.display_name === 'string' ? content.display_name : null,
    about: typeof content.about === 'string' ? content.about : null,
    picture: typeof content.picture === 'string' ? content.picture : null,
    banner: typeof content.banner === 'string' ? content.banner : null,
    nip05: typeof content.nip05 === 'string' ? content.nip05 : null,
    website: typeof content.website === 'string' ? content.website : null,
    lud16: typeof content.lud16 === 'string' ? content.lud16 : null,
    lud06: typeof content.lud06 === 'string' ? content.lud06 : null,
    socialDistance: null,
    followedByFriends: null,
  };
}

export function getProfileTitle(profile: ProfileRecord | null, fallbackPubkey: string): string {
  const memory = contactMemoryStore.get(fallbackPubkey);
  return (
    memory?.nickname ||
    memory?.accepted_name ||
    memory?.first_seen_name ||
    profile?.displayName?.trim() ||
    profile?.name?.trim() ||
    fallbackProfileNameForIdentity(fallbackPubkey)
  );
}

function normalizeComparableHandle(value: string): string {
  return value.trim().replace(/^@/, '').toLowerCase();
}

function formatWebsiteLabel(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) {
    return '';
  }

  try {
    const url = new URL(trimmed.startsWith('http://') || trimmed.startsWith('https://') ? trimmed : `https://${trimmed}`);
    return url.host.replace(/^www\./, '');
  } catch {
    return trimmed;
  }
}

export function getProfileSubtitle(profile: ProfileRecord | null, _fallbackPubkey: string): string {
  const name = profile?.name?.trim();
  const displayName = profile?.displayName?.trim();
  if (name && (!displayName || normalizeComparableHandle(name) !== normalizeComparableHandle(displayName))) {
    return name.startsWith('@') ? name : `@${name}`;
  }

  return formatWebsiteLabel(profile?.website?.trim() || '');
}

export function formatRelativeTime(unixSeconds: number, now = Date.now()): string {
  const from = unixSeconds * 1000;
  const elapsedSeconds = Math.floor((now - from) / 1000);
  const absoluteSeconds = Math.abs(elapsedSeconds);

  if (absoluteSeconds < 60) {
    return 'now';
  }

  if (absoluteSeconds < 60 * 60) {
    const minutes = Math.floor(absoluteSeconds / 60);
    return elapsedSeconds < 0 ? `now + ${minutes}m` : `${minutes}m`;
  }

  if (absoluteSeconds < 60 * 60 * 24) {
    const hours = Math.floor(absoluteSeconds / (60 * 60));
    return elapsedSeconds < 0 ? `now + ${hours}h` : `${hours}h`;
  }

  const fromDate = new Date(from);
  const currentDate = new Date(now);
  return fromDate.toLocaleDateString(undefined, fromDate.getFullYear() === currentDate.getFullYear()
    ? { month: 'short', day: 'numeric' }
    : { year: 'numeric', month: 'short', day: 'numeric' });
}
