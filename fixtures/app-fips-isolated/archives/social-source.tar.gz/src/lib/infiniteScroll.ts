export const INFINITE_SCROLL_PRELOAD_PX = 2_400;

type InfiniteScrollActionOptions = {
  preloadPx: number;
  minScrollDeltaPx: number;
  getScrollOffset: () => number;
  setScrollOffset: (nextOffset: number) => void;
  getLastLoadScrollOffset: () => number;
  getLoadPending: () => boolean;
  getHasMore: () => boolean;
  getFillViewport?: () => boolean;
  onLoadMore: () => void;
};

function findNearestScrollingParent(element: HTMLElement): HTMLElement | null {
  let parent = element.parentElement;
  while (parent) {
    if (parent === document.body || parent === document.documentElement) {
      return null;
    }

    // Reading scrollHeight/clientHeight here forces layout while a route is
    // mounting. The scroll roots we own opt in explicitly, so discovering the
    // root stays a cheap DOM walk even when a retained feed has many cards.
    if (parent.hasAttribute('data-scrollable')) {
      return parent;
    }
    parent = parent.parentElement;
  }

  return null;
}

function getCurrentScrollOffset(rootElement: HTMLElement | null): number {
  if (rootElement) {
    return rootElement.scrollTop;
  }

  if (typeof window === 'undefined') {
    return 0;
  }

  return window.scrollY
    || window.pageYOffset
    || document.scrollingElement?.scrollTop
    || document.documentElement.scrollTop
    || document.body.scrollTop
    || 0;
}

function canAdvanceInfiniteScroll(currentOffset: number, lastLoadOffset: number, minScrollDeltaPx: number): boolean {
  return currentOffset > lastLoadOffset + minScrollDeltaPx;
}

function isSentinelWithinLoadMargin(
  node: HTMLElement,
  rootElement: HTMLElement | null,
  preloadPx: number,
): boolean {
  const sentinelRect = node.getBoundingClientRect();
  const viewportBottom = rootElement
    ? rootElement.getBoundingClientRect().bottom
    : window.innerHeight;

  return sentinelRect.top <= viewportBottom + preloadPx;
}

function isSentinelInsideViewport(
  node: HTMLElement,
  rootElement: HTMLElement | null,
): boolean {
  const sentinelRect = node.getBoundingClientRect();
  const viewportRect = rootElement?.getBoundingClientRect();
  const viewportTop = viewportRect?.top ?? 0;
  const viewportBottom = viewportRect?.bottom ?? window.innerHeight;
  return sentinelRect.top <= viewportBottom && sentinelRect.bottom >= viewportTop;
}

export function createInfiniteScrollAction(options: InfiniteScrollActionOptions): (
  node: HTMLDivElement,
) => { destroy: () => void } {
  return (node: HTMLDivElement) => {
    if (typeof IntersectionObserver === 'undefined' || typeof window === 'undefined') {
      return {
        destroy() {},
      };
    }

    const rootElement = findNearestScrollingParent(node);
    const scrollTarget: HTMLElement | Window = rootElement ?? window;
    const layoutTarget = rootElement ?? document.documentElement;
    // The sentinel controls are a sibling of the feed/grid whose hydration
    // moves the sentinel. Observe their shared container so a sentinel that
    // stays intersecting is rechecked even though IntersectionObserver does
    // not emit another edge transition.
    const layoutScope = node.parentElement?.parentElement ?? node.parentElement;
    let frameId = 0;
    let sentinelNear = false;

    const scheduleMaybeLoadMore = () => {
      if (frameId) {
        return;
      }

      frameId = window.requestAnimationFrame(() => {
        frameId = 0;
        maybeLoadMore();
      });
    };

    const syncScrollOffset = () => {
      options.setScrollOffset(getCurrentScrollOffset(rootElement));
    };

    const maybeLoadMore = () => {
      syncScrollOffset();
      if (
        options.getLoadPending()
        || !options.getHasMore()
        || !isSentinelWithinLoadMargin(node, rootElement, options.preloadPx)
      ) {
        return;
      }

      const advancedByScrolling = canAdvanceInfiniteScroll(
        options.getScrollOffset(),
        options.getLastLoadScrollOffset(),
        options.minScrollDeltaPx,
      );
      const shouldFillViewport = options.getFillViewport?.() ?? false;
      if (
        !advancedByScrolling
        && (!shouldFillViewport || !isSentinelInsideViewport(node, rootElement))
      ) {
        return;
      }

      options.onLoadMore();
    };

    const handleScroll = () => {
      if (sentinelNear) {
        scheduleMaybeLoadMore();
      }
    };

    const resizeObserver = typeof ResizeObserver === 'undefined'
      ? null
      : new ResizeObserver(() => {
          scheduleMaybeLoadMore();
        });
    const mutationObserver = typeof MutationObserver === 'undefined'
      ? null
      : new MutationObserver(() => {
          scheduleMaybeLoadMore();
        });
    const viewportFillResizeObserver = typeof ResizeObserver === 'undefined'
      ? null
      : new ResizeObserver(() => {
          syncScrollOffset();
          if ((options.getFillViewport?.() ?? false) && options.getScrollOffset() === 0) {
            scheduleMaybeLoadMore();
          }
        });

    const observer = new IntersectionObserver(
      (entries) => {
        sentinelNear = Boolean(entries[0]?.isIntersecting);
        if (!sentinelNear) {
          return;
        }

        scheduleMaybeLoadMore();
      },
      {
        root: rootElement,
        rootMargin: `0px 0px ${options.preloadPx}px 0px`,
        threshold: 0,
      },
    );

    syncScrollOffset();
    scrollTarget.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    resizeObserver?.observe(layoutTarget);
    if (node.parentElement) {
      resizeObserver?.observe(node.parentElement);
      mutationObserver?.observe(node.parentElement, {
        childList: true,
        subtree: true,
      });
    }
    if (layoutScope && layoutScope !== node.parentElement) {
      viewportFillResizeObserver?.observe(layoutScope);
    }
    observer.observe(node);
    scheduleMaybeLoadMore();

    return {
      destroy() {
        if (frameId) {
          window.cancelAnimationFrame(frameId);
        }
        resizeObserver?.disconnect();
        viewportFillResizeObserver?.disconnect();
        mutationObserver?.disconnect();
        observer.disconnect();
        scrollTarget.removeEventListener('scroll', handleScroll);
        window.removeEventListener('resize', handleScroll);
      },
    };
  };
}
