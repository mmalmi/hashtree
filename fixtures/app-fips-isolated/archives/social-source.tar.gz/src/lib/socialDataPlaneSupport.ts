import type { NostrFilter, NostrVerifiedEvent } from 'nostr-pubsub';
import { verifyEvent } from 'nostr-tools/pure';
import {
  MAX_INDEXED_EVENT_VERIFICATION_BATCH,
  verifyIndexedEvents,
} from './fastEventVerification';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import {
  isProfileLoadAbort,
  throwIfProfileLoadAborted,
} from './profileLoadAbort';
import type { PersistedSocialRepositoryState } from './socialRepository';

const LIVE_REPLAY_LIMIT = 256;
const MAX_LIVE_SCOPE_AUTHORS = 256;
const MAX_LIVE_SCOPE_EVENT_IDS = 128;
const MAX_LIVE_SCOPE_REFERENCED_EVENT_IDS = 128;
const MAX_LIVE_SCOPE_ADDRESSES = 64;
const MAX_LIVE_SCOPE_PUBKEY_TAGS = 32;
const MAX_LIVE_SCOPE_INTERACTION_AUTHORS = 256;
export const PERSISTED_DATA_PLANE_STATE_VERSION = 2;
export const DEFAULT_LIVE_RECONNECT_DELAYS_MS = [1_000, 2_500, 5_000, 15_000, 30_000] as const;

const AUTHOR_SCOPED_LIVE_KINDS = [1, 3, 5, 6, 16, 20, 1_111, 10_000, 30_000, 30_023] as const;
const AUTHOR_PROFILE_LIVE_KINDS = [0] as const;
const EVENT_SCOPED_LIVE_KINDS = [1, 5, 6, 7, 16, 1_111, 9_735] as const;
const REFERENCED_EVENT_LIVE_KINDS = [1, 6, 16, 20, 1_111, 30_023] as const;
const ADDRESS_SCOPED_LIVE_KINDS = [1, 5, 1_111] as const;
const PUBKEY_TAG_SCOPED_LIVE_KINDS = [1, 6, 7, 16, 20, 1_111, 9_735, 30_023] as const;
const PROFILE_INTERACTION_LIVE_KINDS = [7] as const;

export type SocialLiveScope = {
  authors?: readonly string[];
  eventIds?: readonly string[];
  referencedEventIds?: readonly string[];
  addresses?: readonly string[];
  pubkeys?: readonly string[];
  /** Local interests on the public peer feed. */
  interactionAuthors?: readonly string[];
  interactionKinds?: readonly number[];
};

export type PersistedSocialDataPlaneState = {
  schemaVersion: typeof PERSISTED_DATA_PLANE_STATE_VERSION;
  overlayEvents: RawEvent[];
  /** Signed events still awaiting durable acknowledgement from a Nostr relay. */
  pendingDeliveryEventIds: string[];
};

export type RestoredSocialDataPlaneState = {
  repositoryState: PersistedSocialRepositoryState;
  pendingDeliveryEventIds: string[];
};

function isHex64(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{64}$/i.test(value);
}

function normalizeHexValues(values: readonly string[] | undefined): string[] {
  const normalized = new Set<string>();
  for (const candidate of values ?? []) {
    const value = candidate.trim().toLowerCase();
    if (isHex64(value)) {
      normalized.add(value);
    }
  }
  return [...normalized].sort();
}

function normalizeLimitedHexValues(values: readonly string[] | undefined, limit: number): string[] {
  const normalized = new Set<string>();
  for (const candidate of values ?? []) {
    const value = candidate.trim().toLowerCase();
    if (isHex64(value)) {
      normalized.add(value);
    }
    if (normalized.size >= limit) {
      break;
    }
  }
  return [...normalized].sort();
}

function normalizeLimitedAddresses(values: readonly string[] | undefined, limit: number): string[] {
  const normalized = new Set<string>();
  for (const candidate of values ?? []) {
    const value = candidate.trim();
    if (value && value.length <= 512) {
      normalized.add(value);
    }
    if (normalized.size >= limit) {
      break;
    }
  }
  return [...normalized].sort();
}

/** Select live records for the current view. The public peer feed matches these filters locally. */
export function buildScopedLiveFilters(
  scope: SocialLiveScope,
  since: number,
  engagementSince: number = since,
): NostrFilter[] {
  const filters: NostrFilter[] = [];
  const authors = normalizeHexValues(scope.authors);
  const eventIds = normalizeLimitedHexValues(scope.eventIds, MAX_LIVE_SCOPE_EVENT_IDS);
  const referencedEventIds = normalizeLimitedHexValues(
    scope.referencedEventIds,
    MAX_LIVE_SCOPE_REFERENCED_EVENT_IDS,
  );
  const addresses = normalizeLimitedAddresses(scope.addresses, MAX_LIVE_SCOPE_ADDRESSES);
  const pubkeys = normalizeLimitedHexValues(scope.pubkeys, MAX_LIVE_SCOPE_PUBKEY_TAGS);
  const interactionAuthors = normalizeHexValues(scope.interactionAuthors);
  const interactionKinds = [...new Set(
    scope.interactionKinds ?? PROFILE_INTERACTION_LIVE_KINDS,
  )].filter((kind) => kind === 6 || kind === 7).sort((left, right) => left - right);
  const replaySince = Math.max(0, Math.trunc(since));
  const engagementReplaySince = Math.max(0, Math.trunc(engagementSince));

  for (let offset = 0; offset < authors.length; offset += MAX_LIVE_SCOPE_AUTHORS) {
    const authorChunk = authors.slice(offset, offset + MAX_LIVE_SCOPE_AUTHORS);
    filters.push({
      kinds: [...AUTHOR_SCOPED_LIVE_KINDS],
      authors: authorChunk,
      since: replaySince,
      limit: LIVE_REPLAY_LIMIT,
    });
    // Kind 0 is replaceable state, not recent activity. Omitting `since` lets a
    // relay return the author's latest profile even when it was published long
    // before the bounded live replay window.
    filters.push({
      kinds: [...AUTHOR_PROFILE_LIVE_KINDS],
      authors: authorChunk,
      limit: authorChunk.length,
    });
  }
  if (referencedEventIds.length > 0) {
    filters.push({
      ids: referencedEventIds,
      kinds: [...REFERENCED_EVENT_LIVE_KINDS],
      limit: referencedEventIds.length,
    });
  }
  if (eventIds.length > 0) {
    filters.push({
      kinds: [...EVENT_SCOPED_LIVE_KINDS],
      '#e': eventIds,
      since: engagementReplaySince,
      limit: LIVE_REPLAY_LIMIT,
    });
  }
  if (addresses.length > 0) {
    filters.push({
      kinds: [...ADDRESS_SCOPED_LIVE_KINDS],
      '#a': addresses,
      since: replaySince,
      limit: LIVE_REPLAY_LIMIT,
    });
  }
  if (pubkeys.length > 0) {
    filters.push({
      kinds: [...PUBKEY_TAG_SCOPED_LIVE_KINDS],
      '#p': pubkeys,
      since: replaySince,
      limit: LIVE_REPLAY_LIMIT,
    });
  }
  for (
    let offset = 0;
    offset < interactionAuthors.length;
    offset += MAX_LIVE_SCOPE_INTERACTION_AUTHORS
  ) {
    filters.push({
      kinds: interactionKinds,
      authors: interactionAuthors.slice(offset, offset + MAX_LIVE_SCOPE_INTERACTION_AUTHORS),
      since: engagementReplaySince,
      limit: LIVE_REPLAY_LIMIT,
    });
  }
  return filters;
}

export function normalizePersistedEventShape(value: unknown): RawEvent | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  const candidate = value as Partial<RawEvent>;
  if (
    !isHex64(candidate.id)
    || candidate.id !== candidate.id.toLowerCase()
    || !isHex64(candidate.pubkey)
    || candidate.pubkey !== candidate.pubkey.toLowerCase()
    || typeof candidate.created_at !== 'number'
    || !Number.isSafeInteger(candidate.created_at)
    || candidate.created_at < 0
    || typeof candidate.kind !== 'number'
    || !Number.isSafeInteger(candidate.kind)
    || candidate.kind < 0
    || candidate.kind > 65_535
    || typeof candidate.content !== 'string'
    || typeof candidate.sig !== 'string'
    || !/^[0-9a-f]{128}$/.test(candidate.sig)
    || !Array.isArray(candidate.tags)
    || !candidate.tags.every((tag) => (
      Array.isArray(tag) && tag.every((part) => typeof part === 'string')
    ))
  ) {
    return null;
  }

  const event: RawEvent = {
    id: candidate.id,
    pubkey: candidate.pubkey,
    created_at: candidate.created_at,
    kind: candidate.kind,
    content: candidate.content,
    sig: candidate.sig,
    tags: candidate.tags.map((tag) => [...tag]),
  };
  return event;
}

export function normalizePersistedEvent(value: unknown): RawEvent | null {
  const event = normalizePersistedEventShape(value);
  if (!event) {
    return null;
  }
  try {
    return verifyEvent(event) ? event : null;
  } catch {
    return null;
  }
}

export type PersistedEventBatchVerifier = (
  events: RawEvent[],
  signal?: AbortSignal,
) => Promise<readonly boolean[]>;

export type PersistedEventVerificationOptions = {
  signal?: AbortSignal;
  verifyEvents?: PersistedEventBatchVerifier;
  yieldControl?: () => Promise<void>;
};

function defaultVerificationYield(): Promise<void> {
  return new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });
}

/**
 * Admit structurally decoded persisted events through bounded worker batches.
 * The default verifier is the shared event-verifier worker; the injectable
 * boundary keeps storage restoration deterministic in production-size tests.
 */
export async function verifyPersistedEventShapes(
  events: readonly RawEvent[],
  options: PersistedEventVerificationOptions = {},
): Promise<RawEvent[]> {
  const signal = options.signal;
  const verifyEvents = options.verifyEvents ?? verifyIndexedEvents;
  const yieldControl = options.yieldControl ?? defaultVerificationYield;
  const verified: RawEvent[] = [];
  throwIfProfileLoadAborted(signal);

  for (
    let offset = 0;
    offset < events.length;
    offset += MAX_INDEXED_EVENT_VERIFICATION_BATCH
  ) {
    throwIfProfileLoadAborted(signal);
    const batch = events.slice(
      offset,
      offset + MAX_INDEXED_EVENT_VERIFICATION_BATCH,
    );
    let validity: readonly boolean[] = [];
    try {
      validity = await verifyEvents(batch, signal);
    } catch (error) {
      if (isProfileLoadAbort(error, signal)) {
        throw error;
      }
    }
    throwIfProfileLoadAborted(signal);
    if (validity.length === batch.length) {
      for (let index = 0; index < batch.length; index += 1) {
        const event = batch[index];
        if (event && validity[index] === true) {
          verified.push(event);
        }
      }
    }
    if (offset + MAX_INDEXED_EVENT_VERIFICATION_BATCH < events.length) {
      await yieldControl();
    }
  }
  return verified;
}

export async function normalizePersistedEventsAsync(
  values: readonly unknown[],
  options: PersistedEventVerificationOptions = {},
): Promise<RawEvent[]> {
  const shapedEvents = values
    .map(normalizePersistedEventShape)
    .filter((event): event is RawEvent => Boolean(event));
  return await verifyPersistedEventShapes(shapedEvents, options);
}

type PersistedStateCandidate = {
  schemaVersion: 1 | typeof PERSISTED_DATA_PLANE_STATE_VERSION;
  overlayEvents: unknown[];
  pendingDeliveryEventIds: unknown[];
};

function persistedStateCandidate(value: unknown): PersistedStateCandidate | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  const candidate = value as {
    schemaVersion?: unknown;
    overlayEvents?: unknown;
    pendingDeliveryEventIds?: unknown;
  };
  if (
    (candidate.schemaVersion !== 1 && candidate.schemaVersion !== PERSISTED_DATA_PLANE_STATE_VERSION)
    || !Array.isArray(candidate.overlayEvents)
    || (
      candidate.schemaVersion === PERSISTED_DATA_PLANE_STATE_VERSION
      && !Array.isArray(candidate.pendingDeliveryEventIds)
    )
  ) {
    return null;
  }

  return {
    schemaVersion: candidate.schemaVersion,
    overlayEvents: candidate.overlayEvents,
    pendingDeliveryEventIds: candidate.schemaVersion === PERSISTED_DATA_PLANE_STATE_VERSION
      ? candidate.pendingDeliveryEventIds as unknown[]
      : [],
  };
}

function restoredPersistedState(
  candidate: PersistedStateCandidate,
  overlayEvents: RawEvent[],
): RestoredSocialDataPlaneState {
  const overlayIds = new Set(overlayEvents.map((event) => event.id));
  const pendingDeliveryEventIds = candidate.schemaVersion === PERSISTED_DATA_PLANE_STATE_VERSION
    ? [...new Set(candidate.pendingDeliveryEventIds.filter((eventId): eventId is string => (
        isHex64(eventId)
        && eventId === eventId.toLowerCase()
        && overlayIds.has(eventId)
      )))]
    : [];

  return {
    repositoryState: { schemaVersion: 1, overlayEvents },
    pendingDeliveryEventIds,
  };
}

export function normalizePersistedState(value: unknown): RestoredSocialDataPlaneState | null {
  const candidate = persistedStateCandidate(value);
  if (!candidate) {
    return null;
  }

  const overlayEvents = candidate.overlayEvents
    .map(normalizePersistedEvent)
    .filter((event): event is RawEvent => Boolean(event));

  return restoredPersistedState(candidate, overlayEvents);
}

/** Verify a saved overlay away from the application mount task and yield between fallback chunks. */
export async function normalizePersistedStateAsync(
  value: unknown,
  options: PersistedEventVerificationOptions = {},
): Promise<RestoredSocialDataPlaneState | null> {
  const candidate = persistedStateCandidate(value);
  if (!candidate) {
    return null;
  }

  const overlayEvents = await normalizePersistedEventsAsync(
    candidate.overlayEvents,
    options,
  );

  return restoredPersistedState(candidate, overlayEvents);
}

export function cloneRawEvent(event: RawEvent | NostrVerifiedEvent): RawEvent {
  return {
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

export function eventReferencesTargets(event: RawEvent, targets: Set<string>): boolean {
  return event.tags.some((tag) => (
    (tag[0] === 'e' || tag[0] === 'a')
    && typeof tag[1] === 'string'
    && targets.has(tag[1])
  ));
}

export function addEventTargets(targets: Set<string>, event: RawEvent): void {
  targets.add(event.id);
  const address = getAddressableEventCoordinate(event);
  if (address) {
    targets.add(address);
  }
}

export function selectLiveThreadReplies(
  snapshotReplies: RawEvent[],
  threadEvents: RawEvent[],
  candidates: RawEvent[],
  limit: number,
): RawEvent[] {
  const targets = new Set<string>();
  const selected = new Set(snapshotReplies.map((event) => event.id));
  for (const event of [...threadEvents, ...snapshotReplies]) {
    addEventTargets(targets, event);
  }

  let added = true;
  while (added) {
    added = false;
    for (const event of candidates) {
      if (selected.has(event.id) || !eventReferencesTargets(event, targets)) {
        continue;
      }
      selected.add(event.id);
      addEventTargets(targets, event);
      added = true;
    }
  }
  return candidates
    .filter((event) => selected.has(event.id))
    .slice(0, Math.max(0, limit));
}

export function rememberSnapshotEventIds(
  rememberedIds: Set<string>,
  snapshotEvents: RawEvent[],
  pendingDeliveryEventIds: Set<string>,
  maximum: number,
): string[] {
  const deliveredSnapshotIds: string[] = [];
  for (const event of snapshotEvents) {
    // Keep deletion events in the overlay: their tombstones must continue to
    // guard app-local posts and caches even after the durable index has them.
    if (event.kind === 5) {
      continue;
    }
    const eventId = event.id.toLowerCase();
    rememberedIds.delete(eventId);
    rememberedIds.add(eventId);
    if (!pendingDeliveryEventIds.has(eventId)) {
      deliveredSnapshotIds.push(eventId);
    }
  }
  while (rememberedIds.size > maximum) {
    const oldestId = rememberedIds.values().next().value;
    if (!oldestId) {
      break;
    }
    rememberedIds.delete(oldestId);
  }
  return deliveredSnapshotIds;
}

export function normalizeReconnectDelays(values: readonly number[] | undefined): readonly number[] {
  const normalized = (values ?? DEFAULT_LIVE_RECONNECT_DELAYS_MS)
    .map((value) => Math.max(0, Math.trunc(value)))
    .filter(Number.isSafeInteger);
  return normalized.length > 0 ? normalized : DEFAULT_LIVE_RECONNECT_DELAYS_MS;
}
