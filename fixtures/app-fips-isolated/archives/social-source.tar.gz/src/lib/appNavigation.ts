import { isAppRouteLocation, type Route } from './appRoute';

export type PrimaryNavigationItem = 'home' | 'wallet' | 'search' | 'notifications' | 'settings' | 'profile';

const PRIMARY_NAVIGATION_ITEMS = new Set<PrimaryNavigationItem>([
  'home',
  'wallet',
  'search',
  'notifications',
  'settings',
  'profile',
]);

function getStoredRouteScrollKey(key: string): string {
  return `iris-social:scroll:${key}`;
}

export function persistRouteScroll(key: string, scrollY: number): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    window.sessionStorage.setItem(getStoredRouteScrollKey(key), String(scrollY));
  } catch {
    // Ignore session storage failures.
  }
}

export function readStoredRouteScroll(key: string): number | null {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const raw = window.sessionStorage.getItem(getStoredRouteScrollKey(key));
    if (raw === null) {
      return null;
    }
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

export function readHistoryScrollState(): number | null {
  if (typeof window === 'undefined') {
    return null;
  }

  const state = window.history.state;
  return state && typeof state.irisScrollY === 'number' ? state.irisScrollY : null;
}

export function persistHistoryScroll(nextScrollY: number): void {
  if (typeof window === 'undefined') {
    return;
  }

  const state = window.history.state;
  const nextState =
    state && typeof state === 'object'
      ? { ...state, irisScrollY: nextScrollY }
      : { irisScrollY: nextScrollY };
  window.history.replaceState(nextState, '');
}

export function shouldRestoreInitialRouteScroll(): boolean {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return false;
  }

  const navigationEntry = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;
  let hasSameOriginReferrer = false;
  try {
    hasSameOriginReferrer = Boolean(document.referrer)
      && new URL(document.referrer).origin === window.location.origin;
  } catch {
    hasSameOriginReferrer = false;
  }

  return navigationEntry?.type === 'back_forward' || hasSameOriginReferrer;
}

export function isPrimaryNavigationClick(event: MouseEvent): boolean {
  return event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey;
}

export function getPrimaryNavigationItem(target: EventTarget | null): PrimaryNavigationItem | null {
  if (!(target instanceof Element)) {
    return null;
  }

  const element = target.closest<HTMLElement>('[data-primary-navigation-item]');
  const item = element?.dataset.primaryNavigationItem as PrimaryNavigationItem | undefined;
  return item && PRIMARY_NAVIGATION_ITEMS.has(item) ? item : null;
}

export function isPrimaryNavigationItemActive(
  item: PrimaryNavigationItem,
  route: Route,
  activeProfilePubkey: string | null = null,
): boolean {
  if (item === 'profile') {
    return route.kind === 'profile'
      && Boolean(activeProfilePubkey)
      && route.pubkey === activeProfilePubkey;
  }

  return route.kind === item;
}

export function getCurrentAppNavigationHref(target: EventTarget | null): string | null {
  if (!(target instanceof Element)) {
    return null;
  }

  const anchor = target.closest('a[href]');
  if (!(anchor instanceof HTMLAnchorElement) || anchor.hasAttribute('download')) {
    return null;
  }

  const targetAttr = anchor.getAttribute('target');
  if (targetAttr && targetAttr !== '_self') {
    return null;
  }

  let url: URL;
  try {
    url = new URL(anchor.href, window.location.href);
  } catch {
    return null;
  }

  if (
    url.origin !== window.location.origin
    || !isAppRouteLocation(url.pathname, url.hash)
  ) {
    return null;
  }

  return `${url.pathname}${url.search}${url.hash}`;
}

export function isCurrentAppNavigationTarget(target: EventTarget | null): boolean {
  return getCurrentAppNavigationHref(target) !== null;
}
