type ViewedPost = { id: string; pubkey: string | null; presented: boolean };

/** A retained thread only counts as viewed while its main post is on screen. */
export function clearViewedPostNotifications(node: HTMLElement, target: ViewedPost) {
  if (!navigator.serviceWorker || typeof Notification === 'undefined') { return; }
  let inView = false;

  function visible(): boolean {
    return target.presented && inView && document.visibilityState === 'visible' && node.getClientRects().length > 0;
  }

  async function clear(): Promise<void> {
    const { id, pubkey } = target;
    if (!pubkey || !visible() || Notification.permission !== 'granted') { return; }
    const registration = await navigator.serviceWorker.getRegistration();
    if (!registration?.getNotifications) { return; }
    const notifications = await registration.getNotifications();
    if (pubkey !== target.pubkey || id !== target.id || !visible()) { return; }
    const url = new URL(`#/thread/${id}`, registration.scope).href;
    for (const alert of notifications) {
      if (alert.data?.pubkey === pubkey && (alert.data.url === url || alert.data.parentId === id)) {
        alert.close();
      }
    }
  }

  const refresh = () => { void clear().catch(() => undefined); };
  const observer = new IntersectionObserver(entries => {
    inView = entries[entries.length - 1]!.isIntersecting;
    if (inView) { refresh(); }
  });
  const onPush = (event: MessageEvent) => {
    if (event.data?.type === 'IRIS_PUSH_RECEIVED') { refresh(); }
  };
  observer.observe(node);
  document.addEventListener('visibilitychange', refresh);
  navigator.serviceWorker.addEventListener('message', onPush);

  return {
    update(next: ViewedPost) {
      if (next.pubkey !== target.pubkey || next.id !== target.id || next.presented !== target.presented) {
        target = next;
        // Svelte updates the route wrapper's display in this same turn.
        queueMicrotask(refresh);
      }
    },
    destroy() {
      inView = false;
      observer.disconnect();
      document.removeEventListener('visibilitychange', refresh);
      navigator.serviceWorker.removeEventListener('message', onPush);
    },
  };
}
