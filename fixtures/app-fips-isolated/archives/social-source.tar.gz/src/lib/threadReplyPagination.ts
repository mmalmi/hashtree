import type { CollectionSource } from '@hashtree/collection';
import type { CID } from '@hashtree/core';
import { MANIFEST_BY_TAG, type NostrEventStore, type StoredNostrEvent } from '@hashtree/nostr';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import {
  isStrictlyBeforeRecentCursor,
  timeAndEventIdFromIndexKey,
  type RecentTextNoteCursor,
} from './recentTextNoteCursor';
import {
  DEFAULT_INDEXED_EVENT_READ_CONCURRENCY,
  mapOrderedConcurrent,
} from './orderedConcurrent';

export type ThreadRepliesPage = {
  cursor: RecentTextNoteCursor | null;
  hasMore: boolean;
  replies: RawEvent[];
};

export type ThreadReplyReader = {
  getNoteReplies: (
    noteId: string,
    limit: number,
    before?: RecentTextNoteCursor,
  ) => Promise<RawEvent[]>;
  getRecentEventsByTag: (
    tagName: string,
    tagValue: string,
    options: {
      before?: RecentTextNoteCursor;
      kinds?: number[];
      limit?: number;
    },
  ) => Promise<RawEvent[]>;
};

function compareNewest(left: RawEvent, right: RawEvent): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}

export function mergeUniqueEvents(eventLists: RawEvent[][], limit: number): RawEvent[] {
  const merged = new Map<string, RawEvent>();
  for (const list of eventLists) {
    for (const event of list) {
      const existing = merged.get(event.id);
      if (!existing || compareNewest(event, existing) < 0) {
        merged.set(event.id, event);
      }
    }
  }
  return [...merged.values()].sort(compareNewest).slice(0, limit);
}

export async function readIndexedEventsByTag(options: {
  before?: RecentTextNoteCursor;
  kinds?: number[];
  limit: number;
  normalizedName: string;
  normalizedValue: string;
  readConcurrency?: number;
  readEvent: (cid: CID) => Promise<RawEvent | null>;
  source: CollectionSource;
}): Promise<RawEvent[]> {
  const kinds = options.kinds ? new Set(options.kinds) : null;
  const events: RawEvent[] = [];
  const candidates = (async function* (): AsyncGenerator<CID, void, void> {
    for await (const { key, cid } of options.source.streamQueryIndex(MANIFEST_BY_TAG, {
      prefix: `${options.normalizedName}:${options.normalizedValue}:`,
    })) {
      const { createdAt, eventId } = timeAndEventIdFromIndexKey(key);
      if (isStrictlyBeforeRecentCursor(createdAt, eventId, options.before)) {
        yield cid;
      }
    }
  })();
  for await (const event of mapOrderedConcurrent(
    candidates,
    options.readEvent,
    {
      concurrency: Math.min(
        options.readConcurrency ?? DEFAULT_INDEXED_EVENT_READ_CONCURRENCY,
        Math.max(options.limit, 1),
      ),
    },
  )) {
    if (
      !event
      || (kinds && !kinds.has(event.kind))
      || !event.tags.some(([name, value]) => (
        name?.toLowerCase() === options.normalizedName
        && typeof value === 'string'
        && (options.normalizedName === 't' ? value.toLowerCase() : value) === options.normalizedValue
      ))
    ) {
      continue;
    }
    events.push(event);
    if (events.length >= options.limit) {
      break;
    }
  }
  return events;
}

export async function readFallbackEventsByTag(options: {
  before?: RecentTextNoteCursor;
  eventStore: Pick<NostrEventStore, 'streamQuery'>;
  kinds?: number[];
  limit: number;
  normalizedName: string;
  normalizedValue: string;
  root: CID;
  toRawEvent: (event: StoredNostrEvent) => RawEvent | null | Promise<RawEvent | null>;
}): Promise<RawEvent[]> {
  const kinds = options.kinds?.length ? options.kinds : [null];
  const eventLists = await Promise.all(kinds.map(async (kind) => {
    const events: RawEvent[] = [];
    const query = kind === null
      ? {}
      : { kinds: [kind], tags: { [options.normalizedName]: options.normalizedValue } };
    for await (const storedEvent of options.eventStore.streamQuery(
      options.root,
      query,
      options.before ? { until: options.before.createdAt } : {},
    )) {
      const event = await options.toRawEvent(storedEvent);
      if (
        !event
        || !isStrictlyBeforeRecentCursor(event.created_at, event.id, options.before)
        || !event.tags.some(([name, value]) => (
          name?.toLowerCase() === options.normalizedName
          && typeof value === 'string'
          && (options.normalizedName === 't' ? value.toLowerCase() : value) === options.normalizedValue
        ))
      ) {
        continue;
      }
      events.push(event);
      if (events.length >= options.limit) {
        break;
      }
    }
    return events;
  }));
  return mergeUniqueEvents(eventLists, options.limit);
}

export async function loadRepliesFromRoots(
  roots: CID[],
  event: RawEvent,
  limit: number,
  before: RecentTextNoteCursor | undefined,
  getReader: (root: CID) => ThreadReplyReader,
): Promise<RawEvent[]> {
  const address = getAddressableEventCoordinate(event);
  const [eventIdLists, addressLists] = await Promise.all([
    Promise.all(
      roots.map(async (root) => await getReader(root).getNoteReplies(event.id, limit, before)),
    ),
    address
      ? Promise.all(roots.map(async (root) => await getReader(root).getRecentEventsByTag('a', address, {
          before,
          kinds: [1, 1111],
          limit,
        })))
      : Promise.resolve([]),
  ]);
  return mergeUniqueEvents([...eventIdLists, ...addressLists], limit);
}

export function createThreadRepliesPage(
  candidates: RawEvent[],
  limit: number,
  before?: RecentTextNoteCursor,
): ThreadRepliesPage {
  const replies = candidates.slice(0, limit);
  const boundary = replies.at(-1);
  return {
    cursor: boundary ? { createdAt: boundary.created_at, eventId: boundary.id } : before ?? null,
    hasMore: candidates.length > limit,
    replies,
  };
}

export function buildThreadContext(
  note: RawEvent | null,
  root: RawEvent | null,
  parent: RawEvent | null,
): RawEvent[] {
  return [root, parent].filter((event, index, events): event is RawEvent => Boolean(
    event
    && events.findIndex((candidate) => candidate?.id === event.id) === index
    && event.id !== note?.id,
  ));
}
