export class DebouncedTask {
  private timer: ReturnType<typeof setTimeout> | null = null;

  constructor(private readonly delayMs: number) {}

  schedule(task: () => void): void {
    this.cancel();
    this.timer = setTimeout(() => {
      this.timer = null;
      task();
    }, this.delayMs);
  }

  cancel(): void {
    if (this.timer === null) {
      return;
    }
    clearTimeout(this.timer);
    this.timer = null;
  }
}
