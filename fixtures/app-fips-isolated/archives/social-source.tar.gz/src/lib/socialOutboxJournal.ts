import type { RawEvent } from './nostr';
import {
  normalizePersistedEvent,
  normalizePersistedEventShape,
  verifyPersistedEventShapes,
  type PersistedEventBatchVerifier,
  type PersistedEventVerificationOptions,
} from './socialDataPlaneSupport';
import { SocialPersistenceError } from './socialDataPlaneTypes';

const SOCIAL_OUTBOX_RECORD_VERSION = 2;
const LEGACY_SOCIAL_OUTBOX_RECORD_VERSION = 1;

export const SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX = 'iris-social:social-outbox:v1:event:';
export const SOCIAL_OUTBOX_MIGRATION_STORAGE_KEY = 'iris-social:social-outbox:v1:migrated';

export type SocialOutboxObligations = {
  relay: boolean;
  personalIndex: boolean;
};

export type SocialOutboxEntry = {
  event: RawEvent;
  obligations: SocialOutboxObligations;
};

type SocialOutboxRecord = {
  schemaVersion: typeof SOCIAL_OUTBOX_RECORD_VERSION;
  event: RawEvent;
  obligations: SocialOutboxObligations;
};

type SocialOutboxObligation = keyof SocialOutboxObligations;

function eventStorageKey(eventId: string): string {
  return `${SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX}${eventId.toLowerCase()}`;
}

function cloneEvent(event: RawEvent): RawEvent {
  return {
    ...event,
    tags: event.tags.map((tag) => [...tag]),
  };
}

function cloneEntry(entry: SocialOutboxEntry): SocialOutboxEntry {
  return {
    event: cloneEvent(entry.event),
    obligations: { ...entry.obligations },
  };
}

function hasAnyObligation(obligations: SocialOutboxObligations): boolean {
  return obligations.relay || obligations.personalIndex;
}

function writeSocialOutboxEntry(storage: Storage, entry: SocialOutboxEntry): void {
  const record: SocialOutboxRecord = {
    schemaVersion: SOCIAL_OUTBOX_RECORD_VERSION,
    event: cloneEvent(entry.event),
    obligations: { ...entry.obligations },
  };
  storage.setItem(eventStorageKey(entry.event.id), JSON.stringify(record));
}

export function socialOutboxEventIdFromStorageKey(key: string): string | null {
  if (!key.startsWith(SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX)) {
    return null;
  }
  const eventId = key.slice(SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX.length);
  return /^[0-9a-f]{64}$/.test(eventId) ? eventId : null;
}

export function decodeSocialOutboxRecord(
  key: string,
  raw: string | null,
): SocialOutboxEntry | null {
  const shaped = decodeSocialOutboxRecordShape(key, raw);
  if (!shaped) {
    return null;
  }
  const event = normalizePersistedEvent(shaped.event);
  return event
    ? { event, obligations: { ...shaped.obligations } }
    : null;
}

function decodeSocialOutboxRecordShape(
  key: string,
  raw: string | null,
): SocialOutboxEntry | null {
  const eventId = socialOutboxEventIdFromStorageKey(key);
  if (!eventId || raw === null) {
    return null;
  }
  try {
    const record = JSON.parse(raw) as {
      schemaVersion?: unknown;
      event?: unknown;
      obligations?: Partial<SocialOutboxObligations>;
    };
    const event = normalizePersistedEventShape(record.event);
    if (!event || event.id !== eventId) {
      return null;
    }
    if (record.schemaVersion === LEGACY_SOCIAL_OUTBOX_RECORD_VERSION) {
      return {
        event: cloneEvent(event),
        obligations: { relay: true, personalIndex: false },
      };
    }
    const obligations = record.obligations;
    if (
      record.schemaVersion !== SOCIAL_OUTBOX_RECORD_VERSION
      || typeof obligations?.relay !== 'boolean'
      || typeof obligations.personalIndex !== 'boolean'
      || !hasAnyObligation(obligations as SocialOutboxObligations)
    ) {
      return null;
    }
    return {
      event: cloneEvent(event),
      obligations: { ...obligations } as SocialOutboxObligations,
    };
  } catch {
    return null;
  }
}

async function decodeSocialOutboxRecordAsync(
  key: string,
  raw: string | null,
  options: PersistedEventVerificationOptions = {},
): Promise<SocialOutboxEntry | null> {
  const shaped = decodeSocialOutboxRecordShape(key, raw);
  if (!shaped) {
    return null;
  }
  const [event] = await verifyPersistedEventShapes([shaped.event], options);
  return event
    ? { event, obligations: { ...shaped.obligations } }
    : null;
}

export function readSocialOutboxJournal(storage: Storage): Map<string, SocialOutboxEntry> {
  const entries = new Map<string, SocialOutboxEntry>();
  const keys = Array.from({ length: storage.length }, (_, index) => storage.key(index))
    .filter((key): key is string => Boolean(key))
    .filter((key) => key.startsWith(SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX))
    .sort();
  for (const key of keys) {
    const entry = decodeSocialOutboxRecord(key, storage.getItem(key));
    if (entry) {
      entries.set(entry.event.id, entry);
    }
  }
  return entries;
}

export async function readSocialOutboxJournalAsync(
  storage: Storage,
  options: PersistedEventVerificationOptions = {},
): Promise<Map<string, SocialOutboxEntry>> {
  const keys = Array.from({ length: storage.length }, (_, index) => storage.key(index))
    .filter((key): key is string => Boolean(key))
    .filter((key) => key.startsWith(SOCIAL_OUTBOX_EVENT_STORAGE_PREFIX))
    .sort();
  const candidates = keys
    .map((key) => decodeSocialOutboxRecordShape(key, storage.getItem(key)))
    .filter((entry): entry is SocialOutboxEntry => Boolean(entry));
  const verifiedEvents = await verifyPersistedEventShapes(
    candidates.map((entry) => entry.event),
    options,
  );
  const verifiedIds = new Set(verifiedEvents.map((event) => event.id));
  return new Map(
    candidates
      .filter((entry) => verifiedIds.has(entry.event.id))
      .map((entry) => [entry.event.id, cloneEntry(entry)]),
  );
}

export function isSocialOutboxJournalMigrated(storage: Storage): boolean {
  return storage.getItem(SOCIAL_OUTBOX_MIGRATION_STORAGE_KEY) === '1';
}

export function persistSocialOutboxEvent(
  storage: Storage,
  event: RawEvent,
  obligations: SocialOutboxObligations = { relay: true, personalIndex: false },
): SocialOutboxEntry {
  const key = eventStorageKey(event.id);
  const previous = decodeSocialOutboxRecord(key, storage.getItem(key));
  const entry: SocialOutboxEntry = {
    event: cloneEvent(event),
    obligations: {
      relay: obligations.relay || previous?.obligations.relay === true,
      personalIndex: obligations.personalIndex || previous?.obligations.personalIndex === true,
    },
  };
  if (!hasAnyObligation(entry.obligations)) {
    throw new Error('A durable outbox record must have at least one pending obligation');
  }
  writeSocialOutboxEntry(storage, entry);
  return cloneEntry(entry);
}

export function acknowledgeSocialOutboxObligation(
  storage: Storage,
  eventId: string,
  obligation: SocialOutboxObligation,
): SocialOutboxEntry | null {
  const key = eventStorageKey(eventId);
  const previous = decodeSocialOutboxRecord(key, storage.getItem(key));
  if (!previous) {
    return null;
  }
  const entry: SocialOutboxEntry = {
    event: previous.event,
    obligations: {
      ...previous.obligations,
      [obligation]: false,
    },
  };
  if (!hasAnyObligation(entry.obligations)) {
    storage.removeItem(key);
    return null;
  }
  writeSocialOutboxEntry(storage, entry);
  return cloneEntry(entry);
}

/**
 * Move the legacy whole-snapshot outbox into independent event records. The
 * marker is deliberately written last, so interruption can only repeat puts;
 * it can never make an unjournaled legacy event disappear.
 */
export function migrateSocialOutboxJournal(
  storage: Storage,
  legacyPendingEvents: readonly RawEvent[],
): void {
  if (isSocialOutboxJournalMigrated(storage)) {
    return;
  }
  for (const event of legacyPendingEvents) {
    persistSocialOutboxEvent(storage, event, { relay: true, personalIndex: false });
  }
  storage.setItem(SOCIAL_OUTBOX_MIGRATION_STORAGE_KEY, '1');
}

function migrateSocialOutboxJournalWithoutVerification(
  storage: Storage,
  legacyPendingEvents: readonly RawEvent[],
): void {
  if (isSocialOutboxJournalMigrated(storage)) {
    return;
  }
  for (const event of legacyPendingEvents) {
    const key = eventStorageKey(event.id);
    const previous = decodeSocialOutboxRecordShape(key, storage.getItem(key));
    writeSocialOutboxEntry(storage, {
      event,
      obligations: {
        relay: true,
        personalIndex: previous?.obligations.personalIndex === true,
      },
    });
  }
  storage.setItem(SOCIAL_OUTBOX_MIGRATION_STORAGE_KEY, '1');
}

export type RestoredSocialOutboxJournal = {
  entries: Map<string, SocialOutboxEntry>;
  migrated: boolean;
};

export type SocialOutboxJournalCoordinatorOptions = {
  storage: Storage | null;
  storageEventTarget: EventTarget | null;
  getPendingEvents: () => RawEvent[];
  onQueued: (entry: SocialOutboxEntry) => void;
  onRemoved: (eventId: string) => void;
  onError: (error: SocialPersistenceError) => void;
  verifyEvents?: PersistedEventBatchVerifier;
};

/** Owns cross-tab storage events and the atomic per-event outbox journal. */
export class SocialOutboxJournalCoordinator {
  private readonly options: SocialOutboxJournalCoordinatorOptions;
  private listening = false;
  private restoring = false;
  private listenerLifecycle = 0;
  private readonly changedEventIds = new Set<string>();
  private readonly storageEventRevisions = new Map<string, number>();
  private readonly handleStorage = (event: Event): void => {
    const storage = this.options.storage;
    if (!storage) {
      return;
    }
    const change = event as Event & {
      key?: unknown;
      newValue?: unknown;
      storageArea?: unknown;
    };
    if (
      typeof change.key !== 'string'
      || (change.storageArea && change.storageArea !== storage)
    ) {
      return;
    }
    const eventId = socialOutboxEventIdFromStorageKey(change.key);
    if (!eventId) {
      return;
    }
    if (this.restoring) {
      this.changedEventIds.add(eventId);
    }
    const revision = (this.storageEventRevisions.get(eventId) ?? 0) + 1;
    this.storageEventRevisions.set(eventId, revision);
    if (change.newValue === null) {
      this.options.onRemoved(eventId);
      return;
    }
    if (typeof change.newValue !== 'string') {
      return;
    }
    const lifecycle = this.listenerLifecycle;
    void decodeSocialOutboxRecordAsync(change.key, change.newValue, {
      verifyEvents: this.options.verifyEvents,
    }).then((queuedEntry) => {
      if (
        queuedEntry
        && this.listening
        && lifecycle === this.listenerLifecycle
        && revision === this.storageEventRevisions.get(eventId)
      ) {
        this.options.onQueued(queuedEntry);
      }
    }).catch((cause) => {
      if (this.listening && lifecycle === this.listenerLifecycle) {
        this.options.onError(new SocialPersistenceError(
          'Could not verify an updated Nostr outbox record from another tab.',
          cause,
        ));
      }
    });
  };

  constructor(options: SocialOutboxJournalCoordinatorOptions) {
    this.options = options;
  }

  restore(legacyPendingEvents: readonly RawEvent[]): RestoredSocialOutboxJournal {
    const storage = this.options.storage;
    if (!storage) {
      return { entries: new Map(), migrated: false };
    }
    let migrated = false;
    let entries = new Map<string, SocialOutboxEntry>();
    try {
      migrateSocialOutboxJournal(storage, legacyPendingEvents);
      migrated = isSocialOutboxJournalMigrated(storage);
    } catch (cause) {
      if (legacyPendingEvents.length > 0) {
        this.options.onError(new SocialPersistenceError(
          'Could not migrate the saved Nostr outbox on this device.',
          cause,
        ));
      }
    }
    try {
      entries = readSocialOutboxJournal(storage);
    } catch (cause) {
      this.options.onError(new SocialPersistenceError(
        'Could not read the saved Nostr outbox from this device.',
        cause,
      ));
    }
    return { entries, migrated };
  }

  async restoreAsync(
    legacyPendingEvents: readonly RawEvent[],
    options: PersistedEventVerificationOptions = {},
  ): Promise<RestoredSocialOutboxJournal> {
    const storage = this.options.storage;
    if (!storage) {
      return { entries: new Map(), migrated: false };
    }
    this.restoring = true;
    let migrated = false;
    let entries = new Map<string, SocialOutboxEntry>();
    try {
      try {
        // Legacy events were admitted by the overlay worker batch immediately
        // before this call. Merge only structurally decoded prior obligations;
        // do not repeat Schnorr verification on the main thread during migration.
        migrateSocialOutboxJournalWithoutVerification(storage, legacyPendingEvents);
        migrated = isSocialOutboxJournalMigrated(storage);
      } catch (cause) {
        if (legacyPendingEvents.length > 0) {
          this.options.onError(new SocialPersistenceError(
            'Could not migrate the saved Nostr outbox on this device.',
            cause,
          ));
        }
      }
      try {
        entries = await readSocialOutboxJournalAsync(storage, {
          ...options,
          verifyEvents: options.verifyEvents ?? this.options.verifyEvents,
        });
        // Storage events may arrive while the worker is verifying the baseline.
        // Their callbacks own the newest value, so never replay an older scan
        // result over them when restoration commits.
        for (const eventId of this.changedEventIds) {
          entries.delete(eventId);
        }
      } catch (cause) {
        if (options.signal?.aborted) {
          throw cause;
        }
        this.options.onError(new SocialPersistenceError(
          'Could not read the saved Nostr outbox from this device.',
          cause,
        ));
      }
      return { entries, migrated };
    } finally {
      this.restoring = false;
      this.changedEventIds.clear();
    }
  }

  start(): void {
    const target = this.options.storageEventTarget;
    if (!target || this.listening) {
      return;
    }
    this.changedEventIds.clear();
    this.listenerLifecycle += 1;
    this.listening = true;
    target.addEventListener('storage', this.handleStorage);
  }

  stop(): void {
    const target = this.options.storageEventTarget;
    if (!target || !this.listening) {
      return;
    }
    target.removeEventListener('storage', this.handleStorage);
    this.listening = false;
    this.listenerLifecycle += 1;
    this.storageEventRevisions.clear();
  }

  synchronize(): void {
    const storage = this.options.storage;
    if (!storage) {
      return;
    }
    try {
      this.ensureMigrated();
      const entries = readSocialOutboxJournal(storage);
      for (const entry of entries.values()) {
        this.options.onQueued(entry);
      }
      if (isSocialOutboxJournalMigrated(storage)) {
        for (const event of this.options.getPendingEvents()) {
          if (!entries.has(event.id)) {
            this.options.onRemoved(event.id);
          }
        }
      }
    } catch (cause) {
      this.options.onError(new SocialPersistenceError(
        'Could not synchronize the saved Nostr outbox on this device.',
        cause,
      ));
    }
  }

  persist(event: RawEvent, obligations: SocialOutboxObligations): SocialOutboxEntry {
    const storage = this.options.storage;
    if (!storage) {
      this.fail('This event could not be saved on this device, so it was not queued for delivery.');
    }
    try {
      this.ensureMigrated();
      return persistSocialOutboxEvent(storage, event, obligations);
    } catch (cause) {
      this.fail(
        'This event could not be saved on this device, so it was not queued for delivery.',
        cause,
      );
    }
  }

  acknowledge(eventId: string, obligation: SocialOutboxObligation): SocialOutboxEntry | null {
    const storage = this.options.storage;
    if (!storage) {
      this.fail('The completed event obligation could not be saved in this device outbox.');
    }
    try {
      this.ensureMigrated();
      return acknowledgeSocialOutboxObligation(storage, eventId, obligation);
    } catch (cause) {
      this.fail('The completed event obligation could not be saved in this device outbox.', cause);
    }
  }

  private ensureMigrated(): void {
    const storage = this.options.storage;
    if (!storage) {
      throw new SocialPersistenceError('Nostr outbox storage is unavailable.');
    }
    if (!isSocialOutboxJournalMigrated(storage)) {
      migrateSocialOutboxJournal(storage, this.options.getPendingEvents());
    }
  }

  private fail(message: string, cause?: unknown): never {
    const error = cause instanceof SocialPersistenceError
      ? cause
      : new SocialPersistenceError(message, cause);
    this.options.onError(error);
    throw error;
  }
}
