import type { SocialGraphBadge } from './socialGraphBadgeQuery';
import { type CID } from '@hashtree/core';
import { HashtreeWorkerClient } from '@hashtree/worker/client';
import type { NostrFilter } from 'nostr-pubsub';
import HashtreeWorker from '../workers/hashtree.worker.ts?worker';
import { startWorkerFipsP2P, syncWorkerFipsP2P } from './fipsP2P';
import {
  getConfiguredBlossomServers,
  getHashtreeWorkerConfig,
  WORKER_STORE_NAME,
} from './htreeRuntime';
import { settingsStore } from './settings';
import type { RawEvent } from './nostr';
import {
  SocialWorkerTransport,
  type HashtreeQueryWorkerOptions,
  type HomeFeedWorkerOptions,
  type RelayQueryWorkerOptions,
  type RelaySubscriptionWorkerHandlers,
  type RelaySubscriptionWorkerOptions,
} from './socialWorkerTransport';
import type {
  SocialWorkerHashtreeRoot,
  SocialWorkerProfileSocial,
} from '../workers/socialWorkerProtocol';
import { createCanonicalWorkerRuntime } from './canonicalWorkerRuntime';
import { attachWorkerGraphPolicy } from './workerGraphPolicy';

type RootResolveOptions = {
  timeoutMs?: number;
  settleMs?: number;
};

export type SocialWorkerClient = {
  putBlock(
    data: Uint8Array,
    options?: { hashHex?: string; mimeType?: string; upload?: boolean },
  ): Promise<{ hashHex: string; nhash: string }>;
  putBlocks(
    blocks: Array<{ data: Uint8Array; hashHex?: string; mimeType?: string }>,
    options?: { upload?: boolean },
  ): Promise<Array<{ hashHex: string; nhash: string }>>;
  beginPutBlobStream(mimeType?: string, upload?: boolean): Promise<string>;
  appendPutBlobStream(streamId: string, chunk: Uint8Array): Promise<void>;
  finishPutBlobStream(streamId: string): Promise<{ hashHex: string; nhash: string }>;
  cancelPutBlobStream(streamId: string): Promise<void>;
  getBlob(
    hashHex: string,
    options?: { sourceIds?: readonly string[]; skipPrimary?: boolean; htl?: number },
  ): Promise<{ data: Uint8Array; source: 'idb' | 'blossom' | 'p2p' }>;
  registerMediaPort(port: MessagePort): Promise<void>;
  probeConnectivity(): Promise<{
    online: boolean;
    reachableReadServers: number;
    totalReadServers: number;
    reachableWriteServers: number;
    totalWriteServers: number;
    updatedAt: number;
  }>;
  resolveRoot(npub: string, path?: string, options?: RootResolveOptions): Promise<CID | null>;
  watchRoot(
    npub: string,
    path: string | undefined,
    listener: (cid: CID | null) => void,
    options?: RootResolveOptions,
  ): Promise<() => Promise<void>>;
  getStorageStats(): Promise<{ items: number; bytes: number; maxBytes: number }>;
  streamHomeFeedNotes(
    root: CID,
    authors: string[],
    limit: number,
    options?: HomeFeedWorkerOptions,
  ): AsyncGenerator<RawEvent[], void, void>;
  verifyEvents(events: RawEvent[], signal?: AbortSignal): Promise<boolean[]>;
  queryProfileSocialSnapshot(
    pubkey: string,
    followerLimit: number,
    signal?: AbortSignal,
  ): Promise<SocialWorkerProfileSocial | null>;
  querySocialGraphBadges(
    viewer: string, pubkeys: string[], signal?: AbortSignal,
  ): Promise<SocialGraphBadge[]>;
  observeSocialGraphEvents(
    events: readonly RawEvent[],
    signal?: AbortSignal,
  ): Promise<number>;
  queryHashtreeEvents(
    roots: SocialWorkerHashtreeRoot[],
    filters: NostrFilter[],
    options: HashtreeQueryWorkerOptions,
  ): Promise<{ events: RawEvent[]; complete: boolean }>;
  queryRelayEvents(
    relays: string[],
    filters: NostrFilter[],
    options: RelayQueryWorkerOptions,
  ): Promise<{ events: RawEvent[]; complete: boolean }>;
  publishRelayEvent(
    relays: string[],
    event: RawEvent,
    signal?: AbortSignal,
  ): Promise<void>;
  subscribeRelayEvents(
    relays: string[],
    filters: NostrFilter[],
    handlers: RelaySubscriptionWorkerHandlers,
    options?: RelaySubscriptionWorkerOptions,
  ): { close(reason?: string): void };
};

let hybridClient: SocialWorkerClient | null = null;
let initPromise: Promise<SocialWorkerClient> | null = null;
let settingsSubscriptionInitialized = false;

const workerRuntime = createCanonicalWorkerRuntime({
  createClient: () => new HashtreeWorkerClient(
    HashtreeWorker,
    getHashtreeWorkerConfig({
      storeName: WORKER_STORE_NAME,
    }),
  ),
  initializeClient: async (client) => {
    await client.init();
    attachWorkerGraphPolicy(client);
  },
  attachP2P: startWorkerFipsP2P,
  createTransport: (client) => new SocialWorkerTransport(client),
  onP2PError: (error) => {
    console.warn('Failed to start Hashtree over FIPS', error);
  },
});

const ensureBaseClient = workerRuntime.getClient;

/** The initialized worker endpoint used by browser-owned transport bridges. */
export async function getHashtreeWorkerClient(): Promise<HashtreeWorkerClient> {
  ensureSettingsSubscriptions();
  return await ensureBaseClient();
}

async function syncBaseClientState(): Promise<void> {
  const client = workerRuntime.currentClient();
  if (!client) {
    return;
  }

  const settings = settingsStore.getState();
  try {
    // Resolve settings and browser/runtime overrides through the same path used
    // to initialize the worker. Otherwise the first settings sync can silently
    // discard an explicitly configured writable replica.
    await client.setBlossomServers(getConfiguredBlossomServers());
    await client.setStorageMaxBytes(settings.storage.maxBytes);
    await syncWorkerFipsP2P(client);
  } catch (error) {
    console.warn('Failed to sync blob worker state', error);
  }
}

function ensureSettingsSubscriptions(): void {
  if (settingsSubscriptionInitialized) {
    return;
  }

  settingsSubscriptionInitialized = true;
  settingsStore.subscribe(() => {
    void syncBaseClientState();
  });
}

function createHybridClient(client: HashtreeWorkerClient): SocialWorkerClient {
  const socialTransport = () => workerRuntime.getTransport(client);
  return {
    async putBlock(
      data: Uint8Array,
      options: { hashHex?: string; mimeType?: string; upload?: boolean } = {},
    ): Promise<{ hashHex: string; nhash: string }> {
      return await client.putBlock(data, options);
    },

    async putBlocks(
      blocks: Array<{ data: Uint8Array; hashHex?: string; mimeType?: string }>,
      options: { upload?: boolean } = {},
    ): Promise<Array<{ hashHex: string; nhash: string }>> {
      return await client.putBlocks(blocks, options);
    },

    async beginPutBlobStream(mimeType?: string, upload = true): Promise<string> {
      return await client.beginPutBlobStream(mimeType, upload);
    },

    async appendPutBlobStream(streamId: string, chunk: Uint8Array): Promise<void> {
      await client.appendPutBlobStream(streamId, chunk);
    },

    async finishPutBlobStream(streamId: string): Promise<{ hashHex: string; nhash: string }> {
      return await client.finishPutBlobStream(streamId);
    },

    async cancelPutBlobStream(streamId: string): Promise<void> {
      await client.cancelPutBlobStream(streamId);
    },

    async getBlob(
      hashHex: string,
      options: { sourceIds?: readonly string[]; skipPrimary?: boolean; htl?: number } = {},
    ): Promise<{ data: Uint8Array; source: 'idb' | 'blossom' | 'p2p' }> {
      return await client.getBlob(hashHex, options);
    },

    async registerMediaPort(port: MessagePort): Promise<void> {
      await client.registerMediaPort(port);
    },

    async probeConnectivity() {
      return await client.probeConnectivity();
    },

    async resolveRoot(
      npub: string,
      path?: string,
      options: RootResolveOptions = {},
    ): Promise<CID | null> {
      const { resolveTreeTargetRoot } = await import('./treeRef');
      const { createWorkerTree } = await import('./workerBlockStore');
      return await resolveTreeTargetRoot(`${npub}/${path || 'public'}`, {
        resolveImmutablePath: async (root, subPath) =>
          (await createWorkerTree().resolvePath(root, subPath))?.cid ?? null,
        timeoutMs: options.timeoutMs ?? 15_000,
        settleMs: options.settleMs ?? 500,
      });
    },

    async watchRoot(
      npub: string,
      path: string | undefined,
      listener: (cid: CID | null) => void,
      options: RootResolveOptions = {},
    ): Promise<() => Promise<void>> {
      const { watchTreeTargetRoot } = await import('./treeRef');
      const { createWorkerTree } = await import('./workerBlockStore');
      return await watchTreeTargetRoot(`${npub}/${path || 'public'}`, listener, {
        resolveImmutablePath: async (root, subPath) =>
          (await createWorkerTree().resolvePath(root, subPath))?.cid ?? null,
        timeoutMs: options.timeoutMs ?? 15_000,
        settleMs: options.settleMs ?? 500,
      });
    },

    async getStorageStats(): Promise<{ items: number; bytes: number; maxBytes: number }> {
      const settings = settingsStore.getState();
      const stats = await client.getStorageStats();
      return {
        ...stats,
        maxBytes: settings.storage.maxBytes,
      };
    },

    streamHomeFeedNotes(
      root: CID,
      authors: string[],
      limit: number,
      options: HomeFeedWorkerOptions = {},
    ): AsyncGenerator<RawEvent[], void, void> {
      return socialTransport().streamHomeFeedNotes(root, authors, limit, options);
    },

    async verifyEvents(events: RawEvent[], signal?: AbortSignal): Promise<boolean[]> {
      return await socialTransport().verifyEvents(events, signal);
    },

    async queryProfileSocialSnapshot(
      pubkey: string,
      followerLimit: number,
      signal?: AbortSignal,
    ): Promise<SocialWorkerProfileSocial | null> {
      return await socialTransport().queryProfileSocialSnapshot(pubkey, followerLimit, signal);
    },

    async querySocialGraphBadges(
      viewer: string, pubkeys: string[], signal?: AbortSignal,
    ): Promise<SocialGraphBadge[]> {
      return await socialTransport().querySocialGraphBadges(viewer, pubkeys, signal);
    },

    async observeSocialGraphEvents(
      events: readonly RawEvent[],
      signal?: AbortSignal,
    ): Promise<number> {
      return await socialTransport().observeSocialGraphEvents(events, signal);
    },

    async queryHashtreeEvents(
      roots: SocialWorkerHashtreeRoot[],
      filters: NostrFilter[],
      options: HashtreeQueryWorkerOptions,
    ): Promise<{ events: RawEvent[]; complete: boolean }> {
      return await socialTransport().queryHashtreeEvents(roots, filters, options);
    },

    async queryRelayEvents(
      relays: string[],
      filters: NostrFilter[],
      options: RelayQueryWorkerOptions,
    ): Promise<{ events: RawEvent[]; complete: boolean }> {
      return await socialTransport().queryRelayEvents(relays, filters, options);
    },

    async publishRelayEvent(
      relays: string[],
      event: RawEvent,
      signal?: AbortSignal,
    ): Promise<void> {
      await socialTransport().publishRelayEvent(relays, event, signal);
    },

    subscribeRelayEvents(
      relays: string[],
      filters: NostrFilter[],
      handlers: RelaySubscriptionWorkerHandlers,
      options?: RelaySubscriptionWorkerOptions,
    ): { close(reason?: string): void } {
      return socialTransport().subscribeRelayEvents(relays, filters, handlers, options);
    },
  };
}

export async function getWorkerClient(): Promise<SocialWorkerClient> {
  if (hybridClient) {
    return hybridClient;
  }
  if (initPromise) {
    return initPromise;
  }

  ensureSettingsSubscriptions();
  const pending = (async () => {
    const client = await ensureBaseClient();
    hybridClient = createHybridClient(client);
    void syncBaseClientState();
    return hybridClient;
  })();
  initPromise = pending;

  try {
    return await pending;
  } catch (error) {
    if (initPromise === pending) {
      initPromise = null;
    }
    throw error;
  }
}
