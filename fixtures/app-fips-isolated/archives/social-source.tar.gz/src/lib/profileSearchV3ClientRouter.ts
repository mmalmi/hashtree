import { LinkType, nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  throwIfProfileSearchAborted,
  withProfileSearchAbort,
} from './profileSearchAbort';
import {
  assertExactLinkNames,
  assertOrderedChildren,
  boundedInteger,
  boundedKey,
  decodeCanonicalString,
  exactKeys,
  isPageKind,
  objectValue,
  parseCanonicalJson,
  positiveInteger,
  publicNhash,
  queryKey,
  readCanonicalDirectory,
  readPublicBlock,
  requiredLink,
  routerChildName,
  safeAdd,
  sum,
  equalBytes,
} from './profileSearchV3ClientPrimitives';
import {
  MAX_PACKED_KEY_BYTES,
  MAX_PACKED_PAGE_BYTES,
  MAX_PACKED_PAGE_ENTRIES,
  MAX_PACKED_VALUE_BYTES,
  MAX_ROUTER_CHILDREN,
  MAX_ROUTER_HEIGHT,
  MAX_ROUTER_METADATA_BYTES,
  PACKED_ENTRY_HEADER_BYTES,
  PACKED_HEADER_BYTES,
  PACKED_MAGIC,
  PACKED_PAGE_FORMAT,
  PAGE_ROUTER_FORMAT,
  ROUTER_INDEX_ENTRY,
  type ProfileSearchV3ClientBranchManifest,
  type ProfileSearchV3ClientLoadedRouterNode,
  type ProfileSearchV3ClientNodeDescriptor,
  type ProfileSearchV3ClientPackedEntry,
  type ProfileSearchV3ClientPackedPage,
  type ProfileSearchV3ClientPageDescriptor,
  type ProfileSearchV3ClientPageKind,
  type ProfileSearchV3ClientPageRouter,
  type ProfileSearchV3ClientRoutedPage,
  type ProfileSearchV3ClientRouterIndex,
  type ProfileSearchV3ClientWireNodeDescriptor,
  type ProfileSearchV3ClientWirePageDescriptor,
} from './profileSearchV3ClientTypes';

const decoder = new TextDecoder('utf-8', { fatal: true });
const ROUTER_NODE_CACHE_LIMIT = 8;
const ROUTER_PAGE_CACHE_MAX_BYTES = 2 * 1_048_576;

type CachedPage = {
  byteLength: number;
  pending: Promise<ProfileSearchV3ClientRoutedPage>;
};

type RouterReadCache = {
  nodes: Map<string, Promise<ProfileSearchV3ClientLoadedRouterNode>>;
  pages: Map<string, CachedPage>;
  pageBytes: number;
};

export async function openPageRouter(
  store: Store,
  root: CID,
  expected: ProfileSearchV3ClientBranchManifest,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientPageRouter> {
  const loaded = await readRouterNode(store, root, signal);
  const cache: RouterReadCache = {
    nodes: new Map(),
    pages: new Map(),
    pageBytes: 0,
  };
  const index = loaded.index;
  if (index.pageKind !== expected.pageKind || index.minKey !== expected.minKey
    || index.maxKey !== expected.maxKey || index.height !== expected.height
    || index.pageCount !== expected.pageCount || index.routerNodeCount !== expected.routerNodeCount
    || index.reachableNodeCount !== expected.reachableNodeCount) {
    throw new Error('Profile-search v3 page router does not match its manifest');
  }
  return {
    minKey: index.minKey,
    maxKey: index.maxKey,
    lookupPage: async (key, lookupSignal) => await lookupPage(
      store,
      loaded,
      queryKey(key, 'lookup key'),
      lookupSignal,
      cache,
    ),
    rangePages: (minimum, maximum, rangeSignal) => rangePages(
      store,
      loaded,
      queryKey(minimum, 'range minimum'),
      queryKey(maximum, 'range maximum'),
      rangeSignal,
      cache,
    ),
  };
}

async function lookupPage(
  store: Store,
  initial: ProfileSearchV3ClientLoadedRouterNode,
  key: string,
  signal: AbortSignal | null,
  cache: RouterReadCache,
): Promise<ProfileSearchV3ClientRoutedPage | null> {
  let node = initial;
  while (true) {
    throwIfProfileSearchAborted(signal);
    const childIndex = containingChild(node.index.children, key);
    if (childIndex < 0) {return null;}
    const child = node.index.children[childIndex]!;
    if (node.index.kind === 'leaf') {
      return await readCachedRoutedPage(
        store,
        node.index.pageKind,
        fromWirePage(child),
        signal,
        cache,
      );
    }
    const descriptor = fromWireNode(child);
    node = await readCachedRouterNode(store, descriptor.root, signal, cache);
    assertNodeDescriptor(node.index, descriptor);
  }
}

async function* rangePages(
  store: Store,
  initial: ProfileSearchV3ClientLoadedRouterNode,
  minimum: string,
  maximum: string,
  signal: AbortSignal | null,
  cache: RouterReadCache,
): AsyncGenerator<ProfileSearchV3ClientRoutedPage> {
  if (minimum > maximum) {throw new Error('Profile-search v3 range minimum exceeds maximum');}
  yield* visitRange(store, initial, minimum, maximum, signal, cache);
}

async function* visitRange(
  store: Store,
  node: ProfileSearchV3ClientLoadedRouterNode,
  minimum: string,
  maximum: string,
  signal: AbortSignal | null,
  cache: RouterReadCache,
): AsyncGenerator<ProfileSearchV3ClientRoutedPage> {
  for (const child of node.index.children) {
    throwIfProfileSearchAborted(signal);
    if (child.maxKey < minimum || child.minKey > maximum) {continue;}
    if (node.index.kind === 'leaf') {
      yield await readCachedRoutedPage(
        store,
        node.index.pageKind,
        fromWirePage(child),
        signal,
        cache,
      );
    } else {
      const descriptor = fromWireNode(child);
      const loaded = await readCachedRouterNode(store, descriptor.root, signal, cache);
      assertNodeDescriptor(loaded.index, descriptor);
      yield* visitRange(store, loaded, minimum, maximum, signal, cache);
    }
  }
}

async function readCachedRouterNode(
  store: Store,
  root: CID,
  signal: AbortSignal | null,
  cache: RouterReadCache,
): Promise<ProfileSearchV3ClientLoadedRouterNode> {
  throwIfProfileSearchAborted(signal);
  const key = nhashEncode(root);
  let pending = touch(cache.nodes, key);
  if (!pending) {
    while (cache.nodes.size >= ROUTER_NODE_CACHE_LIMIT) {
      cache.nodes.delete(cache.nodes.keys().next().value as string);
    }
    pending = readRouterNode(store, root, null);
    cache.nodes.set(key, pending);
    void pending.catch(() => {
      if (cache.nodes.get(key) === pending) {cache.nodes.delete(key);}
    });
  }
  return await withProfileSearchAbort(pending, signal);
}

async function readCachedRoutedPage(
  store: Store,
  kind: ProfileSearchV3ClientPageKind,
  descriptor: ProfileSearchV3ClientPageDescriptor,
  signal: AbortSignal | null,
  cache: RouterReadCache,
): Promise<ProfileSearchV3ClientRoutedPage> {
  throwIfProfileSearchAborted(signal);
  const key = pageCacheKey(kind, descriptor);
  let cached = touch(cache.pages, key);
  if (!cached) {
    while (
      cache.pageBytes + descriptor.byteLength > ROUTER_PAGE_CACHE_MAX_BYTES
      && cache.pages.size > 0
    ) {
      const oldestKey = cache.pages.keys().next().value as string;
      const oldest = cache.pages.get(oldestKey)!;
      cache.pages.delete(oldestKey);
      cache.pageBytes -= oldest.byteLength;
    }
    const pending = readRoutedPage(store, kind, descriptor, null);
    cached = { byteLength: descriptor.byteLength, pending };
    cache.pages.set(key, cached);
    cache.pageBytes += descriptor.byteLength;
    void pending.catch(() => {
      if (cache.pages.get(key) === cached) {
        cache.pages.delete(key);
        cache.pageBytes -= descriptor.byteLength;
      }
    });
  }
  return await withProfileSearchAbort(cached.pending, signal);
}

function pageCacheKey(
  kind: ProfileSearchV3ClientPageKind,
  descriptor: ProfileSearchV3ClientPageDescriptor,
): string {
  return [
    kind,
    nhashEncode(descriptor.root),
    descriptor.byteLength,
    descriptor.entryCount,
    descriptor.minKey,
    descriptor.maxKey,
  ].join('\0');
}

function touch<Key, Value>(map: Map<Key, Value>, key: Key): Value | undefined {
  const value = map.get(key);
  if (value !== undefined) {
    map.delete(key);
    map.set(key, value);
  }
  return value;
}

async function readRouterNode(
  store: Store,
  root: CID,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientLoadedRouterNode> {
  const directory = await readCanonicalDirectory(
    store,
    root,
    MAX_ROUTER_METADATA_BYTES,
    'router node',
    signal,
  );
  if (directory.links.length < 2 || directory.links.length > MAX_ROUTER_CHILDREN + 1) {
    throw new Error('Profile-search v3 router link count is invalid');
  }
  const indexLink = requiredLink(directory.links, ROUTER_INDEX_ENTRY, LinkType.Blob, 'router index');
  const bytes = await readPublicBlock(
    store,
    { hash: indexLink.hash },
    MAX_ROUTER_METADATA_BYTES,
    'router index',
    signal,
  );
  if (indexLink.size !== bytes.length) {throw new Error('Profile-search v3 router index size is inconsistent');}
  const index = parseRouterIndex(bytes);
  const expectedNames = [
    ROUTER_INDEX_ENTRY,
    ...index.children.map((_child, childIndex) => routerChildName(index.kind, childIndex)),
  ];
  assertExactLinkNames(directory.links, expectedNames);
  index.children.forEach((child, childIndex) => {
    const name = routerChildName(index.kind, childIndex);
    const link = directory.links.find((candidate) => candidate.name === name);
    const rootCid = publicNhash(child.root, `router ${name}`);
    const expectedType = index.kind === 'leaf' ? LinkType.Blob : LinkType.Dir;
    const expectedSize = index.kind === 'leaf'
      ? (child as ProfileSearchV3ClientWirePageDescriptor).byteLength
      : (child as ProfileSearchV3ClientWireNodeDescriptor).reachableNodeCount;
    if (!link || link.type !== expectedType || link.size !== expectedSize
      || !equalBytes(link.hash, rootCid.hash)) {
      throw new Error(`Profile-search v3 router child link is inconsistent: ${name}`);
    }
  });
  return { index };
}

function parseRouterIndex(bytes: Uint8Array): ProfileSearchV3ClientRouterIndex {
  const raw = parseCanonicalJson(bytes, 'router index');
  exactKeys(raw, [
    'format', 'packedPageFormat', 'pageKind', 'kind', 'height', 'minKey', 'maxKey',
    'pageCount', 'routerNodeCount', 'reachableNodeCount', 'children',
  ], 'router index');
  if (raw.format !== PAGE_ROUTER_FORMAT || raw.packedPageFormat !== PACKED_PAGE_FORMAT
    || !isPageKind(raw.pageKind) || raw.kind !== 'leaf' && raw.kind !== 'internal'
    || !Array.isArray(raw.children) || raw.children.length < 1
    || raw.children.length > MAX_ROUTER_CHILDREN) {
    throw new Error('Invalid profile-search v3 router index');
  }
  const children = raw.kind === 'leaf'
    ? raw.children.map(parseWirePage)
    : raw.children.map(parseWireNode);
  assertOrderedChildren(children);
  const childHeight = raw.kind === 'leaf'
    ? -1
    : (children[0] as ProfileSearchV3ClientWireNodeDescriptor).height;
  if (raw.kind === 'internal'
    && children.some((child) => (
      child as ProfileSearchV3ClientWireNodeDescriptor
    ).height !== childHeight)) {
    throw new Error('Profile-search v3 router child heights are inconsistent');
  }
  const pageCount = raw.kind === 'leaf'
    ? children.length
    : sum(children.map((child) => (child as ProfileSearchV3ClientWireNodeDescriptor).pageCount));
  const routerNodeCount = raw.kind === 'leaf'
    ? 2
    : safeAdd(2, sum(children.map((child) => (
      child as ProfileSearchV3ClientWireNodeDescriptor
    ).routerNodeCount)));
  const reachableNodeCount = raw.kind === 'leaf'
    ? children.length + 2
    : safeAdd(2, sum(children.map((child) => (
      child as ProfileSearchV3ClientWireNodeDescriptor
    ).reachableNodeCount)));
  const index: ProfileSearchV3ClientRouterIndex = {
    format: PAGE_ROUTER_FORMAT,
    packedPageFormat: PACKED_PAGE_FORMAT,
    pageKind: raw.pageKind,
    kind: raw.kind,
    height: raw.kind === 'leaf' ? 0 : childHeight + 1,
    minKey: children[0]!.minKey,
    maxKey: children.at(-1)!.maxKey,
    pageCount,
    routerNodeCount,
    reachableNodeCount,
    children,
  };
  if (index.height > MAX_ROUTER_HEIGHT
    || raw.height !== index.height || raw.minKey !== index.minKey
    || raw.maxKey !== index.maxKey || raw.pageCount !== pageCount
    || raw.routerNodeCount !== routerNodeCount
    || raw.reachableNodeCount !== reachableNodeCount
    || decoder.decode(bytes) !== JSON.stringify(toWireRouterIndex(index))) {
    throw new Error('Profile-search v3 router index is inconsistent or noncanonical');
  }
  return index;
}

function toWireRouterIndex(index: ProfileSearchV3ClientRouterIndex): Record<string, unknown> {
  return {
    format: index.format,
    packedPageFormat: index.packedPageFormat,
    pageKind: index.pageKind,
    kind: index.kind,
    height: index.height,
    minKey: index.minKey,
    maxKey: index.maxKey,
    pageCount: index.pageCount,
    routerNodeCount: index.routerNodeCount,
    reachableNodeCount: index.reachableNodeCount,
    children: index.children,
  };
}

function parseWirePage(value: unknown, index: number): ProfileSearchV3ClientWirePageDescriptor {
  const raw = objectValue(value, `page ${index}`);
  exactKeys(raw, ['minKey', 'maxKey', 'root', 'byteLength', 'entryCount'], `page ${index}`);
  const descriptor: ProfileSearchV3ClientWirePageDescriptor = {
    minKey: boundedKey(raw.minKey, `page ${index} minKey`),
    maxKey: boundedKey(raw.maxKey, `page ${index} maxKey`),
    root: nhashEncode(publicNhash(raw.root, `page ${index} root`)),
    byteLength: boundedInteger(raw.byteLength, 1, MAX_PACKED_PAGE_BYTES, `page ${index} bytes`),
    entryCount: boundedInteger(raw.entryCount, 1, MAX_PACKED_PAGE_ENTRIES, `page ${index} entries`),
  };
  if (descriptor.minKey > descriptor.maxKey) {throw new Error('Invalid profile-search v3 page range');}
  return descriptor;
}

function parseWireNode(value: unknown, index: number): ProfileSearchV3ClientWireNodeDescriptor {
  const raw = objectValue(value, `router child ${index}`);
  exactKeys(raw, [
    'minKey', 'maxKey', 'root', 'height', 'pageCount', 'routerNodeCount', 'reachableNodeCount',
  ], `router child ${index}`);
  const descriptor: ProfileSearchV3ClientWireNodeDescriptor = {
    minKey: boundedKey(raw.minKey, `node ${index} minKey`),
    maxKey: boundedKey(raw.maxKey, `node ${index} maxKey`),
    root: nhashEncode(publicNhash(raw.root, `node ${index} root`)),
    height: boundedInteger(raw.height, 0, MAX_ROUTER_HEIGHT, `node ${index} height`),
    pageCount: positiveInteger(raw.pageCount, `node ${index} pageCount`),
    routerNodeCount: positiveInteger(raw.routerNodeCount, `node ${index} routerNodeCount`),
    reachableNodeCount: positiveInteger(raw.reachableNodeCount, `node ${index} reachableNodeCount`),
  };
  if (descriptor.minKey > descriptor.maxKey) {throw new Error('Invalid profile-search v3 node range');}
  return descriptor;
}

async function readRoutedPage(
  store: Store,
  kind: ProfileSearchV3ClientPageKind,
  descriptor: ProfileSearchV3ClientPageDescriptor,
  signal: AbortSignal | null,
): Promise<ProfileSearchV3ClientRoutedPage> {
  const bytes = await readPublicBlock(store, descriptor.root, MAX_PACKED_PAGE_BYTES,
    'packed page', signal);
  if (bytes.length !== descriptor.byteLength) {throw new Error('Profile-search v3 page size is inconsistent');}
  const page = decodePackedPage(bytes);
  const first = page.entries[0];
  const last = page.entries.at(-1);
  if (page.kind !== kind || page.entries.length !== descriptor.entryCount || !first || !last
    || first[0] !== descriptor.minKey || last[0] !== descriptor.maxKey) {
    throw new Error('Profile-search v3 routed page coverage is inconsistent');
  }
  return { descriptor, page };
}

function decodePackedPage(bytes: Uint8Array): ProfileSearchV3ClientPackedPage {
  if (bytes.length < PACKED_HEADER_BYTES || bytes.length > MAX_PACKED_PAGE_BYTES
    || !PACKED_MAGIC.every((value, index) => bytes[index] === value)) {
    throw new Error('Invalid profile-search v3 packed page');
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const kind = ({ 1: 'documents', 2: 'postings', 3: 'terms', 4: 'visibility' } as const)[
    view.getUint8(9) as 1
  ];
  const count = view.getUint32(12);
  if (view.getUint8(8) !== 1 || !kind || view.getUint16(10) !== 0
    || count < 1 || count > MAX_PACKED_PAGE_ENTRIES
    || view.getUint32(16) !== bytes.length - PACKED_HEADER_BYTES) {
    throw new Error('Invalid profile-search v3 packed page header');
  }
  const entries: ProfileSearchV3ClientPackedEntry[] = [];
  let offset = PACKED_HEADER_BYTES;
  let previous = '';
  for (let index = 0; index < count; index += 1) {
    if (bytes.length - offset < PACKED_ENTRY_HEADER_BYTES) {throw new Error('Truncated packed page');}
    const keyLength = view.getUint32(offset);
    const valueLength = view.getUint32(offset + 4);
    offset += PACKED_ENTRY_HEADER_BYTES;
    if (keyLength < 1 || keyLength > MAX_PACKED_KEY_BYTES || valueLength > MAX_PACKED_VALUE_BYTES
      || keyLength + valueLength > bytes.length - offset) {
      throw new Error('Invalid profile-search v3 packed entry length');
    }
    const key = decodeCanonicalString(bytes.subarray(offset, offset + keyLength));
    offset += keyLength;
    const value = decodeCanonicalString(bytes.subarray(offset, offset + valueLength));
    offset += valueLength;
    if (index > 0 && previous >= key) {throw new Error('Profile-search v3 packed keys are not sorted');}
    entries.push([key, value]);
    previous = key;
  }
  if (offset !== bytes.length) {throw new Error('Profile-search v3 packed page has trailing bytes');}
  return { kind, entries };
}

function containingChild(
  children: Array<ProfileSearchV3ClientWirePageDescriptor | ProfileSearchV3ClientWireNodeDescriptor>,
  key: string,
): number {
  let low = 0;
  let high = children.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const child = children[middle]!;
    if (key < child.minKey) {high = middle - 1;}
    else if (key > child.maxKey) {low = middle + 1;}
    else {return middle;}
  }
  return -1;
}

function fromWirePage(
  value: ProfileSearchV3ClientWirePageDescriptor | ProfileSearchV3ClientWireNodeDescriptor,
): ProfileSearchV3ClientPageDescriptor {
  const page = value as ProfileSearchV3ClientWirePageDescriptor;
  return { ...page, root: publicNhash(page.root, 'page root') };
}

function fromWireNode(
  value: ProfileSearchV3ClientWirePageDescriptor | ProfileSearchV3ClientWireNodeDescriptor,
): ProfileSearchV3ClientNodeDescriptor {
  const node = value as ProfileSearchV3ClientWireNodeDescriptor;
  return { ...node, root: publicNhash(node.root, 'node root') };
}

function assertNodeDescriptor(
  index: ProfileSearchV3ClientRouterIndex,
  expected: ProfileSearchV3ClientNodeDescriptor,
): void {
  if (index.minKey !== expected.minKey || index.maxKey !== expected.maxKey
    || index.height !== expected.height || index.pageCount !== expected.pageCount
    || index.routerNodeCount !== expected.routerNodeCount
    || index.reachableNodeCount !== expected.reachableNodeCount) {
    throw new Error('Profile-search v3 router node descriptor is inconsistent');
  }
}
