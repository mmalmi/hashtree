import { PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE } from './progressiveScrollRestore';

export const ACTIVE_APP_SCROLL_SELECTOR =
  '[data-app-page-scroll]';
export const ACTIVE_APP_ROUTE_SELECTOR =
  '[data-app-route-scroll][data-route-active="true"]';

let appScrollInteractionVersion = 0;

type ViewportRect = Pick<DOMRectReadOnly, 'top' | 'bottom' | 'width' | 'height'>;

function overlapsViewport(rect: ViewportRect, viewport: ViewportRect): boolean {
  return rect.width > 0 && rect.height > 0
    && rect.bottom > viewport.top && rect.top < viewport.bottom;
}

export function insetViewportForAppChrome(
  viewport: ViewportRect,
  header: ViewportRect | null,
  footer: ViewportRect | null,
): { top: number; bottom: number } {
  const top = header && overlapsViewport(header, viewport)
    ? Math.min(viewport.bottom, Math.max(viewport.top, header.bottom))
    : viewport.top;
  const bottom = footer && overlapsViewport(footer, viewport)
    ? Math.max(top, Math.min(viewport.bottom, footer.top))
    : viewport.bottom;
  return { top, bottom };
}

export function getActiveAppScrollElement(): HTMLElement | null {
  if (typeof document === 'undefined') {
    return null;
  }
  const element = document.querySelector(ACTIVE_APP_SCROLL_SELECTOR);
  return element instanceof HTMLElement ? element : null;
}

export function getActiveAppRouteElement(): HTMLElement | null {
  if (typeof document === 'undefined') {
    return null;
  }
  const element = document.querySelector(ACTIVE_APP_ROUTE_SELECTOR);
  return element instanceof HTMLElement ? element : null;
}

export function getAppContentViewportBounds(
  scrollElement = getActiveAppScrollElement(),
): { top: number; bottom: number } | null {
  if (!scrollElement) {
    return null;
  }
  const viewport = scrollElement.getBoundingClientRect();
  const header = document.querySelector<HTMLElement>('[data-testid="app-header"]');
  const footer = document.querySelector<HTMLElement>('[data-testid="mobile-footer"]');
  const headerBounds = header?.getBoundingClientRect();
  const footerBounds = footer?.getBoundingClientRect();
  return insetViewportForAppChrome(viewport, headerBounds ?? null, footerBounds ?? null);
}

export function getAppScrollOffset(): number {
  return getActiveAppScrollElement()?.scrollTop ?? 0;
}

export function getAppScrollInteractionVersion(): number {
  return appScrollInteractionVersion;
}

export function markAppScrollInteraction(): number {
  appScrollInteractionVersion += 1;
  return appScrollInteractionVersion;
}

export function scrollAppTo(offset: number): void {
  getActiveAppScrollElement()?.scrollTo(0, Math.max(0, offset));
}

export function isActiveAppScrollEvent(event: Event): boolean {
  const activeElement = getActiveAppScrollElement();
  return event.target === activeElement
    && !activeElement?.hasAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE);
}
