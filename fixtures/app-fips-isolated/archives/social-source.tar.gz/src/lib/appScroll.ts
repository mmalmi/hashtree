import { PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE } from './progressiveScrollRestore';

export const ACTIVE_APP_SCROLL_SELECTOR =
  '[data-app-page-scroll]';
export const ACTIVE_APP_ROUTE_SELECTOR =
  '[data-app-route-scroll][data-route-active="true"]';

let appScrollInteractionVersion = 0;

type ViewportRect = Pick<DOMRectReadOnly, 'top' | 'bottom' | 'width' | 'height'>;

function overlapsViewport(rect: ViewportRect, viewport: ViewportRect): boolean {
  return rect.width > 0 && rect.height > 0
    && rect.bottom > viewport.top && rect.top < viewport.bottom;
}

export function insetViewportForAppChrome(
  viewport: ViewportRect,
  header: ViewportRect | null,
  footer: ViewportRect | null,
): { top: number; bottom: number } {
  const top = header && overlapsViewport(header, viewport)
    ? Math.min(viewport.bottom, Math.max(viewport.top, header.bottom))
    : viewport.top;
  const bottom = footer && overlapsViewport(footer, viewport)
    ? Math.max(top, Math.min(viewport.bottom, footer.top))
    : viewport.bottom;
  return { top, bottom };
}

export function getActiveAppScrollElement(): HTMLElement | null {
  if (typeof document === 'undefined') {
    return null;
  }
  const element = document.querySelector(ACTIVE_APP_SCROLL_SELECTOR);
  return element instanceof HTMLElement ? element : null;
}

export function getActiveAppRouteElement(): HTMLElement | null {
  if (typeof document === 'undefined') {
    return null;
  }
  const element = document.querySelector(ACTIVE_APP_ROUTE_SELECTOR);
  return element instanceof HTMLElement ? element : null;
}

export function getAppContentViewportBounds(
  scrollElement = getActiveAppScrollElement(),
): { top: number; bottom: number } | null {
  if (!scrollElement) {
    return null;
  }
  const viewport = scrollElement.getBoundingClientRect();
  const header = document.querySelector<HTMLElement>('[data-testid="app-header"]');
  const footer = document.querySelector<HTMLElement>('[data-testid="mobile-footer"]');
  const headerBounds = header?.getBoundingClientRect();
  const footerBounds = footer?.getBoundingClientRect();
  return insetViewportForAppChrome(viewport, headerBounds ?? null, footerBounds ?? null);
}

export function firstCardBelowViewport(
  length: number,
  topAt: (index: number) => number,
  bottom: number,
): number {
  let start = 0;
  let end = length;
  while (start < end) {
    const middle = Math.floor((start + end) / 2);
    if (topAt(middle) < bottom) { start = middle + 1; }
    else { end = middle; }
  }
  return start;
}

/** Bound the protected prefix in feed order, including cards hidden by content filters. */
export function getHomeFeedProtectedCount(notes: readonly { id: string }[], routeKey: string): number | null {
  const route = getActiveAppRouteElement();
  if (!route || route.dataset.routeKey !== routeKey) { return null; }
  const viewport = getAppContentViewportBounds();
  const media = route.querySelector<HTMLElement>(
    '[data-testid="home-media-projection"]:not([hidden]) [data-testid="media-feed-grid"]',
  );
  const feed = media ?? route.querySelector<HTMLElement>(
    '[data-testid="home-feed-projection"]:not([hidden]) [data-testid="latest-feed"]',
  );
  if (!feed || !viewport || viewport.bottom <= viewport.top || !feed.children.length) { return null; }

  const cards = feed.children;
  // The feed and the media grid place items in reading order, including equal
  // top coordinates for items that share a media row.
  const topAt = (index: number): number => cards[index]!.getBoundingClientRect().top;
  const reached = firstCardBelowViewport(cards.length, topAt, viewport.bottom);
  if (reached === 0) { return 0; }

  const lastReached = cards[reached - 1]!;
  const lastId = lastReached.getAttribute(media ? 'data-media-event-id' : 'data-note-id');
  const lastIndex = notes.findIndex((note) => note.id === lastId);
  if (lastIndex < 0) { return null; }

  if (reached === cards.length) {
    const columns = media ? getComputedStyle(feed).gridTemplateColumns.split(' ').length : 1;
    const appendTop = cards.length % columns ? topAt(reached - 1) : feed.getBoundingClientRect().bottom;
    if (appendTop < viewport.bottom) { return lastIndex + 2; }
  }
  return lastIndex + 1;
}

export function getAppScrollOffset(): number {
  return getActiveAppScrollElement()?.scrollTop ?? 0;
}

export function getAppScrollInteractionVersion(): number {
  return appScrollInteractionVersion;
}

export function markAppScrollInteraction(): number {
  appScrollInteractionVersion += 1;
  return appScrollInteractionVersion;
}

export function scrollAppTo(offset: number): void {
  getActiveAppScrollElement()?.scrollTo(0, Math.max(0, offset));
}

export function isActiveAppScrollEvent(event: Event): boolean {
  const activeElement = getActiveAppScrollElement();
  return event.target === activeElement
    && !activeElement?.hasAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE);
}
