export type WalletOperationKind = 'mint' | 'melt' | 'send' | 'receive';

export type WalletBalance = {
  mintUrl: string;
  spendableBits: number;
  reservedBits: number;
  totalBits: number;
};

export type WalletMint = {
  url: string;
  name: string;
  trusted: boolean;
};

export type WalletHistoryItem = {
  id: string;
  operationId: string | null;
  kind: WalletOperationKind;
  state: string;
  amountBits: number;
  mintUrl: string;
  createdAt: number;
  updatedAt: number;
  error: string | null;
};

export type WalletSnapshot = {
  initialized: boolean;
  active: boolean;
  spendableBits: number;
  reservedBits: number;
  totalBits: number;
  balances: WalletBalance[];
  mints: WalletMint[];
  history: WalletHistoryItem[];
  updatedAt: number;
};

export type WalletPreparedOperation = {
  operationId: string;
  amountBits: number;
  feeBits: number;
  mintUrl: string;
  state: string;
};

export type WalletMintInvoice = WalletPreparedOperation & {
  invoice: string;
  expiresAt: number | null;
};

export type WalletPaymentResult = WalletPreparedOperation & {
  status: 'paid' | 'pending';
};

export type WalletPaymentQuote = WalletPreparedOperation & {
  status: 'prepared';
  totalBits: number;
};

export type WalletTokenResult = WalletPreparedOperation & {
  token: string;
};

export type WalletTokenPreview = {
  mintUrl: string;
  unit: string;
  memo: string | null;
  known: boolean;
  trusted: boolean;
};

export class WalletPaymentError extends Error {
  readonly paymentStarted: boolean;

  constructor(message: string, paymentStarted = false) {
    super(message);
    this.name = 'WalletPaymentError';
    this.paymentStarted = paymentStarted;
  }
}
