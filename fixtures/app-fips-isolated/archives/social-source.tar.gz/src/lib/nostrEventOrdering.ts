import type { Event as NostrEvent } from 'nostr-tools';

/** Whether candidate wins a NIP-01 replaceable coordinate over current. */
export function isNewerReplaceableEvent(
  candidate: Pick<NostrEvent, 'created_at' | 'id'>,
  current: Pick<NostrEvent, 'created_at' | 'id'>,
): boolean {
  return candidate.created_at > current.created_at
    || (candidate.created_at === current.created_at && candidate.id < current.id);
}

/** NIP-01 replaceable winner ordering: newest timestamp, then lowest event id. */
export function sortReplaceableEventsNewestFirst(events: readonly NostrEvent[]): NostrEvent[] {
  return [...events].sort((left, right) =>
    right.created_at - left.created_at || left.id.localeCompare(right.id));
}
