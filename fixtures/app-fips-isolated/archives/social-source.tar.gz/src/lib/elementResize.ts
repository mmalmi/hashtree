const listeners = new Map<Element, (entry: ResizeObserverEntry) => void>();
let observer: ResizeObserver | null = null;

export function observeElementResize(node: Element, listener: (entry: ResizeObserverEntry) => void): () => void {
  if (typeof ResizeObserver === 'undefined') {
    return () => undefined;
  }
  observer ??= new ResizeObserver((entries) => {
    entries.forEach((entry) => listeners.get(entry.target)?.(entry));
  });
  listeners.set(node, listener);
  observer.observe(node);
  return () => {
    listeners.delete(node);
    observer?.unobserve(node);
    if (listeners.size === 0) {
      observer?.disconnect();
      observer = null;
    }
  };
}
