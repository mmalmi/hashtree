import type { SearchResult } from '@hashtree/index';
import { pubkeyToNpub, type ProfileRecord } from './nostr';
import { boundedProfileSearchAliases } from './profileSearchIdentity';
import { profileSearchRank } from './profileSearchRanking';

type StoredRemoteProfileSearchEntry = {
  pubkey?: string;
  name?: string;
  aliases?: string[];
  nip05?: string;
  picture?: string;
  created_at?: number;
  follow_distance?: number | null;
  followDistance?: number | null;
  social_distance?: number | null;
  socialDistance?: number | null;
  followed_by_friends?: number | null;
  followedByFriends?: number | null;
};

function parseProfileMetric(value: unknown): number | null {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    return null;
  }

  const normalized = Math.trunc(value);
  return normalized >= 0 ? normalized : null;
}

export function profileSearchResultToProfileRecord(
  result: SearchResult,
  query: string,
): ProfileRecord | null {
  try {
    const parsed = JSON.parse(result.value) as StoredRemoteProfileSearchEntry;
    const pubkey = `${parsed.pubkey || result.id || ''}`.trim().toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(pubkey)) {
      return null;
    }

    const aliases = Array.isArray(parsed.aliases)
      ? boundedProfileSearchAliases(parsed.aliases)
      : [];
    const displayName = typeof parsed.name === 'string' && parsed.name.trim() ? parsed.name.trim() : null;
    const baseProfile: ProfileRecord = {
      pubkey,
      npub: pubkeyToNpub(pubkey),
      eventId: null,
      createdAt: typeof parsed.created_at === 'number' ? parsed.created_at : null,
      name: aliases[0]?.trim() || null,
      displayName,
      about: null,
      picture: typeof parsed.picture === 'string' && parsed.picture.trim() ? parsed.picture.trim() : null,
      banner: null,
      nip05: typeof parsed.nip05 === 'string' && parsed.nip05.trim() ? parsed.nip05.trim() : null,
      website: null,
      lud16: null,
      lud06: null,
      socialDistance: parseProfileMetric(
        parsed.follow_distance
        ?? parsed.followDistance
        ?? parsed.social_distance
        ?? parsed.socialDistance,
      ),
      followedByFriends: parseProfileMetric(parsed.followed_by_friends ?? parsed.followedByFriends),
    };

    let bestProfile = baseProfile;
    let bestTextScore = profileSearchRank(baseProfile, query).textScore;
    for (const alias of aliases.slice(1)) {
      const candidate = { ...baseProfile, name: alias.trim() };
      const candidateTextScore = profileSearchRank(candidate, query).textScore;
      if (candidateTextScore > bestTextScore) {
        bestProfile = candidate;
        bestTextScore = candidateTextScore;
      }
    }
    return {
      ...bestProfile,
      searchAliases: aliases.map((alias) => alias.trim()),
    };
  } catch {
    return null;
  }
}
