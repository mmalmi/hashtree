import type { CID } from '@hashtree/core';
import type { SocialAccount } from './accounts';
import { createEmptyNoteDetailEvents } from './appDataUtils';
import { createEmptyNoteDetailHasMore, type NotificationItem } from './appDetailLoaders';
import { readStoredFeedView } from './appFeedPreferences';
import { parseRouteLocation, type Route } from './appRoute';
import type { RouteRenderCache, RouteStackEntry } from './appStack';
import type { FeedSource } from './appStorage';
import {
  FEED_PAGE_SIZE,
  INITIAL_FEED_LIMIT,
  INITIAL_PROFILE_NOTE_LIMIT,
  THREAD_REPLY_PAGE_SIZE,
} from './config';
import type { FeedView } from './feedView';
import { createLiveHomeFeedBuffer } from './liveHomeFeedBuffer';
import type { ComposerAttachment } from './media';
import type { NoteEngagement } from './noteEngagement';
import type { ProfileRecord, RawEvent } from './nostr';
import type { FeedSnapshot, NoteDetailListKind, NoteThreadSnapshot, ProfileSocialSnapshot } from './nostrIndex';
import type { ProfileLikedNote } from './profileLikes';
import type { ProfileSnapshot } from './profileNotes';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import type { ShadowReadComparator } from './shadowReadComparator';
import {
  createHomeFeedPaginationState,
  createProfileFeedPaginationState,
  createProfileSocialPaginationState,
  createThreadReplyPaginationState,
} from './appUiState';
import type { MediaSelection } from './appMedia';
import type { PendingHomeFeedAnchorRestore } from './appScrollController';
import type { ZapAllLogEntry } from './zaps';
import { combineReactiveStates, createReactiveState } from './reactiveState';

const PROFILE_SOCIAL_PAGE_SIZE = 40;

export function createAppState() {
  const initialRoute = typeof window === 'undefined'
    ? { kind: 'home', tab: 'latest' } as const
    : parseRouteLocation(window.location.pathname, window.location.hash);
  const homePagination = createHomeFeedPaginationState(INITIAL_FEED_LIMIT, FEED_PAGE_SIZE);
  const profilePagination = createProfileFeedPaginationState(
    INITIAL_PROFILE_NOTE_LIMIT,
    FEED_PAGE_SIZE,
  );
  const socialPagination = createProfileSocialPaginationState(PROFILE_SOCIAL_PAGE_SIZE);
  const threadPagination = createThreadReplyPaginationState(THREAD_REPLY_PAGE_SIZE);
  const routeState = createReactiveState({
    route: initialRoute as Route,
    loading: true,
    pageError: '',
    routeStack: [] as RouteStackEntry[],
    routeStackIndex: 0,
    routeRenderCache: new Map<string, RouteRenderCache>(),
    mountedRenderEntries: [] as Array<RouteStackEntry & { cache: RouteRenderCache }>,
    activeRenderEntry: null as (RouteStackEntry & { cache: RouteRenderCache }) | null,
    currentRouteCache: null as RouteRenderCache | null,
    routeScrollPositions: new Map<string, number>(),
    historyScrollPositions: new Map<number, number>(),
    pendingScrollRestoreKey: null as string | null,
    pendingScrollRestoreOffset: null as number | null,
    pendingScrollMode: null as 'top' | 'restore' | null,
    pendingHomeFeedAnchorRestore: null as PendingHomeFeedAnchorRestore | null,
    navigationTriggeredByPopState: false,
    routeScrollPersistTimer: null as number | null,
    appHistoryIndex: 0,
  }, {
    // Controller bookkeeping must never publish the route store. In
    // particular, navigation persists scroll and increments history before it
    // presents a retained card; notifying the shared store here would queue
    // the entire route projection ahead of that first paint.
    silentProperties: new Set([
      'routeScrollPositions',
      'historyScrollPositions',
      'pendingHomeFeedAnchorRestore',
      'navigationTriggeredByPopState',
      'routeScrollPersistTimer',
      'appHistoryIndex',
      // The retained-route warm path mutates the existing stack and advances
      // its cursor before the lightweight presented-route store flips. The
      // full route projection adopts that cursor after the destination paints.
      'routeStackIndex',
    ]),
  });
  const homeState = createReactiveState({
    favoritePubkeys: [] as string[],
    feed: null as FeedSnapshot | null,
    feedRequiresRefresh: false,
    feedLimit: INITIAL_FEED_LIMIT,
    homeFeedFetchLimit: INITIAL_FEED_LIMIT + FEED_PAGE_SIZE,
    feedView: readStoredFeedView() as FeedView,
    allHomeNotes: [] as RawEvent[],
    homeNotes: [] as RawEvent[],
    liveHomeFeedBuffer: createLiveHomeFeedBuffer(),
    bufferedLiveHomeEvents: [] as RawEvent[],
    bufferedLiveHomePostCount: 0,
    liveForYouInteractions: [] as RawEvent[],
    homeFeedRequestId: 0,
    homeFeedInitialLoadGeneration: 0,
    homeFeedInitialLoadPending: false,
    homeRefreshPending: false,
    feedSourceSheetOpen: false,
    feedSourceName: '',
    feedSourceIdentity: '',
    feedSourceError: '',
    feedSources: [] as FeedSource[],
    activeFeedSourceId: null as string | null,
    activeFeedSource: null as FeedSource | null,
    homeFeedLoadPending: homePagination.homeFeedLoadPending,
    homeFeedLastLoadScrollOffset: homePagination.homeFeedLastLoadScrollOffset,
    homeFeedSnapshotWriteTimer: null as number | null,
    homeFeedSnapshotWriteController: null as AbortController | null,
    homeFeedSnapshotReadController: null as AbortController | null,
  });
  const profileState = createReactiveState({
    profilePage: null as ProfileSnapshot | null,
    profileSocial: null as ProfileSocialSnapshot | null,
    profileSocialLoading: false,
    profileSocialLoadPending: false,
    profileNotesLoading: false,
    allProfileNotes: [] as RawEvent[],
    allProfileRootPosts: [] as RawEvent[],
    allProfileReplies: [] as RawEvent[],
    allProfileMedia: [] as RawEvent[],
    allProfileLikedNotes: [] as ProfileLikedNote[],
    allProfileSectionNotes: [] as RawEvent[],
    profileNotes: [] as RawEvent[],
    profileContentSourceHasMore: false,
    profileLikesCountLabel: '...',
    loadedProfilePubkey: null as string | null,
    profilePersonalRoot: null as CID | null,
    profileNoteLimit: profilePagination.profileNoteLimit,
    profileNoteFetchLimit: profilePagination.profileNoteFetchLimit,
    profileFeedLoadPending: profilePagination.profileFeedLoadPending,
    profileFeedLastLoadScrollOffset: profilePagination.profileFeedLastLoadScrollOffset,
    profileSocialVisibleLimit: socialPagination.profileSocialVisibleLimit,
    profileSocialFollowerFetchLimit: socialPagination.profileSocialFollowerFetchLimit,
    profileSocialScrollOffset: socialPagination.profileSocialScrollOffset,
    profileSocialLastLoadScrollOffset: socialPagination.profileSocialLastLoadScrollOffset,
    profileEmptyRetryKey: null as string | null,
  });
  const threadState = createReactiveState({
    threadPage: null as NoteThreadSnapshot | null,
    threadRoots: [] as CID[],
    threadReplyCursor: null as RecentTextNoteCursor | null,
    threadReplies: [] as RawEvent[],
    durableThreadRepliesHasMore: false,
    threadRepliesHasMore: false,
    threadPersonalRoot: null as CID | null,
    threadProfiles: new Map<string, ProfileRecord>(),
    threadLoading: false,
    threadReplyValue: '',
    threadReplyAttachments: [] as ComposerAttachment[],
    threadReplyError: '',
    liveThreadReplies: [] as RawEvent[],
    allLiveThreadReplies: [] as RawEvent[],
    threadReplyFetchLimit: threadPagination.threadReplyFetchLimit,
    threadRepliesLoadPending: threadPagination.threadRepliesLoadPending,
    threadReplyLastLoadScrollOffset: threadPagination.threadReplyLastLoadScrollOffset,
  });
  const searchState = createReactiveState({
    searchSheetOpen: false,
    searchQuery: '',
    searchTab: 'people' as 'people' | 'posts',
    searchPageComponent: null as typeof import('./components/SearchPage.svelte').default | null,
    searchPageLoadError: '',
    searchRemoteProfiles: [] as ProfileRecord[],
    searchLoading: false,
    searchRequestId: 0,
    searchDropdownRoot: null as HTMLDivElement | null,
  });
  const accountState = createReactiveState({
    composerValue: '',
    composerAttachments: [] as ComposerAttachment[],
    composerError: '',
    accountInput: '',
    accountImportError: '',
    accountSheetComponent: null as typeof import('./components/AccountSheet.svelte').default | null,
    accountSheetLoadError: '',
    accountProfiles: new Map<string, ProfileRecord>(),
    activeAccount: null as SocialAccount | null,
    hydratedViewerProfileEvent: null as RawEvent | null,
    viewerProfileEvent: null as RawEvent | null,
    viewerProfileOverlayEvents: [] as RawEvent[],
    viewerProfileLoading: false,
    profileSavePending: false,
    profileSaveError: '',
    profileSaveMessage: '',
  });
  const viewerState = createReactiveState({
    viewerPersonalRoot: null as CID | null,
    viewerContactsEvent: null as RawEvent | null,
    viewerContactsProjectionAuthoritative: false,
    viewerFollows: new Set<string>(),
    followPendingPubkeys: new Set<string>(),
    indexedViewerMuteListEvent: null as RawEvent | null,
    viewerMuteListEvent: null as RawEvent | null,
    viewerMutedPubkeys: new Set<string>(),
    mutePendingPubkeys: new Set<string>(),
  });
  const engagementState = createReactiveState({
    noteEngagements: new Map<string, NoteEngagement>(),
    optimisticNoteEngagements: new Map<string, import('./appDataUtils').OptimisticNoteEngagement>(),
    displayedNoteEngagements: new Map<string, NoteEngagement>(),
    likePendingNoteIds: new Set<string>(),
    zapPendingNoteIds: new Set<string>(),
    repostPendingNoteIds: new Set<string>(),
    rebroadcastPendingNoteIds: new Set<string>(),
    noteEngagementRequestId: 0,
    detailSheetOpen: false,
    detailSheetKind: 'likes' as NoteDetailListKind,
    detailSheetTitle: 'Reactions',
    detailSheetTargetPubkey: '',
    detailSheetEventsByKind: createEmptyNoteDetailEvents(),
    detailSheetHasMoreByKind: createEmptyNoteDetailHasMore(),
    detailSheetProfiles: new Map<string, ProfileRecord>(),
    detailSheetLoading: false,
    detailSheetRequestId: 0,
    zapAllSheetOpen: false,
    zapAllEvents: [] as RawEvent[],
    zapAllRunning: false,
    zapAllCompleted: false,
    zapAllProgress: 0,
    zapAllSpentBits: 0,
    zapAllError: '',
    zapAllLogs: [] as ZapAllLogEntry[],
  });
  const notificationState = createReactiveState({
    notifications: [] as NotificationItem[],
    visibleNotifications: [] as NotificationItem[],
    notificationsProfiles: new Map<string, ProfileRecord>(),
    notificationsLoading: false,
    notificationsLoadPending: false,
    notificationsHasMore: false,
    notificationCursor: null as RecentTextNoteCursor | null,
    notificationScrollOffset: 0,
    notificationLastLoadScrollOffset: 0,
    notificationsSeenAt: 0,
  });
  const mediaState = createReactiveState({
    mediaModalOpen: false,
    mediaSelection: null as MediaSelection | null,
    activeMediaEventId: null as string | null,
    activeMediaUrl: null as string | null,
  });
  const overlayState = createReactiveState({
    // Local persistence is admitted through the verifier worker after the
    // initial route has painted; module evaluation must never perform Schnorr.
    liveProfiles: new Map<string, ProfileRecord>(),
    localPostsByAuthor: new Map<string, RawEvent[]>(),
    liveOverlayVersion: 0,
    knownNotesVersion: 0,
    liveViewRefreshTimer: null as number | null,
    pendingOverlayRestore: false,
  });
  const runtimeState = createReactiveState({
    root: null as CID | null,
    rootNhash: '',
    rootError: '',
    personalRootRefreshTimer: null as number | null,
    shadowReadComparatorPromise: null as Promise<ShadowReadComparator> | null,
    cancelShadowReadIdleDrain: null as (() => void) | null,
    stopRootWatch: null as (() => Promise<void>) | null,
    loadToken: 0,
    profileNotesRequestId: 0,
    profileLikesRequestId: 0,
    hydratedAccountsKey: '',
  }, {
    silentProperties: new Set([
      'loadToken',
      'profileNotesRequestId',
      'profileLikesRequestId',
    ]),
  });
  const combinedState = combineReactiveStates(
    routeState,
    homeState,
    profileState,
    threadState,
    searchState,
    accountState,
    viewerState,
    engagementState,
    notificationState,
    mediaState,
    overlayState,
    runtimeState,
  );
  return {
    routeState,
    homeState,
    profileState,
    threadState,
    searchState,
    accountState,
    viewerState,
    engagementState,
    notificationState,
    mediaState,
    overlayState,
    runtimeState,
    combinedState,
  };
}

export type AppState = ReturnType<typeof createAppState>;
export type AppCombinedState = AppState['combinedState'];
