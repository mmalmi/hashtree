import { nhashEncode, type CID } from '@hashtree/core';
import { accountsStore } from './accounts';
import {
  clearCaughtUpOptimisticEngagements,
} from './appDataUtils';
import { getCurrentActiveAccountPubkey } from './appAccountState';
import type { AppCombinedState } from './appState';
import { refreshBrowserForYouEngagements } from './browserEventReadRouter';
import { canReadHomeFeedFromRelays } from './homeFeedReads';
import { FOR_YOU_RELAY_TARGET_LIMIT } from './forYouRelayEngagement';
import { addOptimisticLike, removeOptimisticLike } from './appViewState';
import type { BoundedHydrationScheduler } from './boundedHydrationScheduler';
import { prependThreadReply as prependThreadReplyToState } from './appNoteState';
import { getNoteEngagementTargetId, mergeNoteEngagements, ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from './noteEngagement';
import { DURABLE_POST_KINDS, loadNoteEngagements } from './nostrIndex';
import { isHexEventId, type RawEvent } from './nostr';
import { waitForNextBrowserPaint } from './asyncTiming';
import { MAX_ROUTED_ENGAGEMENT_TARGETS } from './routedEventReads';
import { socialDataPlane } from './socialDataPlane';

export type EngagementHydrationOptions = {
  merge?: boolean;
  forYouRelayNotes?: readonly RawEvent[];
};

type EngagementControllerDeps = {
  state: AppCombinedState;
  scheduler: BoundedHydrationScheduler;
  loadEngagements?: typeof loadNoteEngagements;
  refreshForYouEngagements?: typeof refreshBrowserForYouEngagements;
  canReadHomeFeedFromRelays?: typeof canReadHomeFeedFromRelays;
  waitForRoutePaint?: () => Promise<void>;
  getKnownNoteByRef?: (id: string) => RawEvent | null;
};

export const MAX_VISIBLE_ENGAGEMENT_NOTES = MAX_ROUTED_ENGAGEMENT_TARGETS;
const FOR_YOU_RELAY_DEBOUNCE_MS = 250;
// Small chunks keep one popular post from using up the others' event budget.
const FOR_YOU_RELAY_CHUNK_SIZE = 4;
const FOR_YOU_RELAY_TTL_MS = 10 * 60_000;
const FOR_YOU_RELAY_RETRY_MS = 30_000;

type RequestedEngagement = {
  attempt: number;
  value?: NoteEngagement;
  complete: boolean;
};

export function createAppEngagementController(deps: EngagementControllerDeps) {
  const { state } = deps;
  const loadEngagements = deps.loadEngagements ?? loadNoteEngagements;
  const refreshForYouEngagements = deps.refreshForYouEngagements ?? refreshBrowserForYouEngagements;
  const canReadForYouRelays = deps.canReadHomeFeedFromRelays ?? canReadHomeFeedFromRelays;
  const waitForRoutePaint = deps.waitForRoutePaint ?? waitForNextBrowserPaint;
  let activeRequestController: AbortController | null = null;
  let hydrationScope = '';
  let requestedEngagements = new Map<string, RequestedEngagement>();
  let engagementReadAttempt = 0;

  function syncHydrationScope(roots: CID | CID[], token: number): void {
    const accounts = accountsStore.getState();
    const primary = state.rootNhash || (Array.isArray(roots)
      ? roots.map(nhashEncode).join(',') : nhashEncode(roots));
    const scope = [token, accounts.activeAccountPubkey ?? '', primary].join(':');
    if (scope === hydrationScope) {return;}
    hydrationScope = scope;
    requestedEngagements = new Map();
    activeRequestController?.abort();
  }

  // The rendered feed includes cached/live posts that never pass through an
  // archive feed snapshot. Hydrate those same visible targets after projection.
  function ensureVisibleNoteEngagements(roots: CID | CID[], noteIds: string[], token: number): void {
    if (token !== state.loadToken) {return;}
    syncHydrationScope(roots, token);
    const missing: string[] = [];
    let restored: Map<string, NoteEngagement> | null = null;
    for (const id of new Set(noteIds.slice(0, MAX_VISIBLE_ENGAGEMENT_NOTES))) {
      if (!requestedEngagements.has(id)) {
        missing.push(id);
      } else {
        const cached = requestedEngagements.get(id)?.value;
        if (cached && state.noteEngagements.get(id) !== cached) {
          restored ??= new Map(state.noteEngagements);
          restored.set(id, cached);
        }
      }
    }
    if (restored) {state.noteEngagements = restored;}
    if (missing.length) {void hydrateNoteEngagements(roots, missing, token, { merge: true });}
  }

  function prependThreadReply(event: RawEvent): void {
    state.threadReplies = prependThreadReplyToState(state.threadReplies, event);
    state.noteEngagements = new Map(state.noteEngagements).set(event.id, ZERO_NOTE_ENGAGEMENT);
  }

  function seedEmptyEngagements(noteIds: string[]): void {
    const next = new Map<string, NoteEngagement>();
    for (const noteId of noteIds) {
      next.set(noteId, state.noteEngagements.get(noteId) ?? { ...ZERO_NOTE_ENGAGEMENT });
    }
    state.noteEngagements = next;
  }

  function seedNewEmptyEngagements(noteIds: string[]): void {
    const next = new Map(state.noteEngagements);
    for (const noteId of noteIds) {
      if (!next.has(noteId)) {
        next.set(noteId, { ...ZERO_NOTE_ENGAGEMENT });
      }
    }
    state.noteEngagements = next;
  }

  function setOptimisticLike(noteId: string): void {
    state.optimisticNoteEngagements = addOptimisticLike(state.optimisticNoteEngagements, noteId);
  }

  function clearOptimisticLike(noteId: string): void {
    state.optimisticNoteEngagements = removeOptimisticLike(state.optimisticNoteEngagements, noteId);
  }

  function syncCaughtUpOptimisticEngagements(engagements: Map<string, NoteEngagement>): void {
    state.optimisticNoteEngagements = clearCaughtUpOptimisticEngagements(
      state.optimisticNoteEngagements,
      engagements,
    );
  }

  function publicForYouTargets(notes: readonly RawEvent[], limit = FOR_YOU_RELAY_TARGET_LIMIT): string[] {
    const visibleIds = new Set(state.homeNotes.map(note => note.id));
    const targets = new Set<string>();
    for (const note of notes) {
      if (targets.size >= limit) {break;}
      if (!visibleIds.has(note.id)) {continue;}
      const id = getNoteEngagementTargetId(note);
      if (note.kind === 6 && id === note.id) {continue;}
      const target = id === note.id ? note : socialDataPlane.getEvent(id) ?? deps.getKnownNoteByRef?.(id);
      if (!target || !(DURABLE_POST_KINDS as readonly number[]).includes(target.kind)
        || !isHexEventId(id) || !socialDataPlane.isExternalEventVisible(target)
        || socialDataPlane.isPendingDelivery(id) || socialDataPlane.isPendingPersonalIndex(id)
        || state.localPostsByAuthor.get(target.pubkey)?.some(local => local.id === id)) {continue;}
      targets.add(id);
    }
    return [...targets];
  }

  async function loadForYouRelayEngagements(notes: readonly RawEvent[], signal: AbortSignal): Promise<void> {
    await waitForRoutePaint();
    if (signal.aborted || !canReadForYouRelays()) {return;}
    const targets = publicForYouTargets(notes);
    if (targets.length > 0) {await refreshForYouEngagements(targets, signal);}
  }

  // Like Iris Client, every visible For You card gets its own relay read,
  // including cards revealed by Load More or a re-rank. Reads are cached per
  // post so scrolling back does not repeat them.
  const relayEngagementReadAt = new Map<string, number>();
  const relayEngagementInFlight = new Set<string>();
  let relayEngagementController: AbortController | null = null;
  let relayEngagementTimer: ReturnType<typeof setTimeout> | undefined;
  let relayEngagementRunning = false;

  function relayEngagementDue(id: string, now: number): boolean {
    return !relayEngagementInFlight.has(id) && (relayEngagementReadAt.get(id) ?? 0) <= now;
  }

  function ensureInitialForYouRelayEngagements(notes: readonly RawEvent[], _generation: number): void {
    const forYou = state.route.kind === 'home' && ['for-you', 'popular'].includes(state.route.tab);
    if (!forYou || notes.length === 0) {
      if (!forYou) {
        relayEngagementController?.abort();
        relayEngagementController = null;
        clearTimeout(relayEngagementTimer);
        relayEngagementTimer = undefined;
      }
      return;
    }
    if (relayEngagementTimer || relayEngagementRunning) {return;}
    relayEngagementTimer = setTimeout(() => {
      relayEngagementTimer = undefined;
      void runForYouRelayEngagementReads();
    }, FOR_YOU_RELAY_DEBOUNCE_MS);
  }

  async function runForYouRelayEngagementReads(): Promise<void> {
    if (relayEngagementRunning) {return;}
    relayEngagementRunning = true;
    try {
      await waitForRoutePaint();
      while (state.route.kind === 'home' && ['for-you', 'popular'].includes(state.route.tab) && canReadForYouRelays()) {
        const now = Date.now();
        const targets = publicForYouTargets(state.homeNotes, Infinity)
          .filter(id => relayEngagementDue(id, now))
          .slice(0, FOR_YOU_RELAY_CHUNK_SIZE);
        if (targets.length === 0) {break;}
        if (!relayEngagementController || relayEngagementController.signal.aborted) {
          relayEngagementController = new AbortController();
        }
        const signal = relayEngagementController.signal;
        for (const id of targets) {relayEngagementInFlight.add(id);}
        let ok = false;
        try {
          await refreshForYouEngagements(targets, signal);
          ok = true;
        } catch {
          // Retried after a short backoff below.
        } finally {
          for (const id of targets) {
            relayEngagementInFlight.delete(id);
            if (!signal.aborted) {
              relayEngagementReadAt.set(id, Date.now() + (ok ? FOR_YOU_RELAY_TTL_MS : FOR_YOU_RELAY_RETRY_MS));
            }
          }
          while (relayEngagementReadAt.size > 2048) {
            relayEngagementReadAt.delete(relayEngagementReadAt.keys().next().value!);
          }
        }
        if (signal.aborted) {break;}
      }
    } finally {
      relayEngagementRunning = false;
    }
  }

  async function hydrateNoteEngagements(
    engagementRoots: CID | CID[],
    noteIds: string[],
    token: number,
    options: EngagementHydrationOptions = {},
  ): Promise<void> {
    if (token !== state.loadToken) {return;}
    syncHydrationScope(engagementRoots, token);
    if (!options.merge) {
      for (const [id, cached] of requestedEngagements) {
        if (!cached.complete) {requestedEngagements.delete(id);}
      }
    }
    if (!options.merge || !activeRequestController || activeRequestController.signal.aborted) {
      activeRequestController?.abort(
        new DOMException('Engagement hydration superseded', 'AbortError'),
      );
      activeRequestController = new AbortController();
    }
    const requestController = activeRequestController;
    const forYou = state.route.kind === 'home' && ['for-you', 'popular'].includes(state.route.tab);
    const requestScope = hydrationScope;
    const requestId = options.merge
      ? state.noteEngagementRequestId
      : ++state.noteEngagementRequestId;
    const isCurrent = () => (
      token === state.loadToken && requestId === state.noteEngagementRequestId
      && requestScope === hydrationScope && !requestController.signal.aborted
    );
    // Engagement is a visible-note enhancement, not a reason to scan every
    // item already present in a long retained feed. The hydrators put visible
    // ids first and request later pages as they become visible.
    const uniqueNoteIds = [...new Set(noteIds
      .map((noteId) => noteId.trim().toLowerCase())
      .filter(isHexEventId))]
      .slice(0, MAX_VISIBLE_ENGAGEMENT_NOTES);
    if (uniqueNoteIds.length === 0) {
      if (!options.merge && isCurrent()) {
        state.noteEngagements = new Map();
      }
      return;
    }
    const requestCache = requestedEngagements;
    const attempt = ++engagementReadAttempt;
    for (const id of uniqueNoteIds) {
      requestCache.set(id, { attempt, value: requestCache.get(id)?.value, complete: false });
    }
    const accounts = accountsStore.getState();
    const viewerPubkey = getCurrentActiveAccountPubkey(
      accounts.activeAccountPubkey ?? null,
      accounts.accounts,
    );
    if (!options.merge && isCurrent()) {
      state.noteEngagements = new Map(uniqueNoteIds.map((noteId) => [
        noteId,
        state.noteEngagements.get(noteId) ?? ZERO_NOTE_ENGAGEMENT,
      ]));
    }

    try {
      const pending = deps.scheduler.run(
        async (routeSignal) => {
          const signal = AbortSignal.any([routeSignal, requestController.signal]);
          // Feed/profile/thread content must be presentable before archive or
          // relay engagement reads get any main-thread time.
          await waitForRoutePaint();
          signal.throwIfAborted();
          if (!isCurrent()) {
            return { engagements: new Map<string, NoteEngagement>(), complete: false };
          }
          return await loadEngagements(
            engagementRoots,
            uniqueNoteIds,
            viewerPubkey,
            { signal, ...(forYou ? { forYouArchive: true } : {}) },
          );
        },
        { isCurrent },
      );
      const relayNotes = options.forYouRelayNotes;
      if (forYou && relayNotes?.length && canReadForYouRelays()) {
        void deps.scheduler.run(async (routeSignal) => {
          const signal = AbortSignal.any([routeSignal, requestController.signal]);
          await loadForYouRelayEngagements(relayNotes, signal);
        }, { isCurrent }).catch(() => undefined);
      }
      const result = await pending;
      if (result.status !== 'completed' || !isCurrent()) {
        return;
      }
      const { engagements, complete } = result.value;
      const next = new Map(state.noteEngagements);
      const updatedEngagements = new Map<string, NoteEngagement>();
      for (const [noteId, value] of engagements) {
        // A superseded narrow read may finish after that note's broader read.
        if (requestCache.get(noteId)?.attempt !== attempt) {continue;}
        const known = next.get(noteId);
        const combined = !complete && known ? mergeNoteEngagements(known, value) : value;
        next.set(noteId, combined);
        requestCache.set(noteId, { attempt, value: combined, complete });
        updatedEngagements.set(noteId, value);
      }
      if (updatedEngagements.size > 0) {
        state.noteEngagements = next;
        syncCaughtUpOptimisticEngagements(updatedEngagements);
      }
    } catch (error) {
      if (isCurrent()) {
        console.warn('Failed to load note engagement', error);
      }
    }
  }

  return {
    clearOptimisticLike,
    hydrateNoteEngagements,
    ensureVisibleNoteEngagements,
    ensureInitialForYouRelayEngagements,
    prependThreadReply,
    seedEmptyEngagements,
    seedNewEmptyEngagements,
    setOptimisticLike,
  };
}
