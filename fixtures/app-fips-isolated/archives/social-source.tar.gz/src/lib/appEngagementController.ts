import { nhashEncode, type CID } from '@hashtree/core';
import { accountsStore } from './accounts';
import {
  clearCaughtUpOptimisticEngagements,
} from './appDataUtils';
import { getCurrentActiveAccountPubkey } from './appAccountState';
import type { AppCombinedState } from './appState';
import { addOptimisticLike, removeOptimisticLike } from './appViewState';
import type { BoundedHydrationScheduler } from './boundedHydrationScheduler';
import { prependThreadReply as prependThreadReplyToState } from './appNoteState';
import { ZERO_NOTE_ENGAGEMENT, type NoteEngagement } from './noteEngagement';
import { loadNoteEngagements } from './nostrIndex';
import { isHexEventId, type RawEvent } from './nostr';
import { waitForNextBrowserPaint } from './asyncTiming';
import { MAX_ROUTED_ENGAGEMENT_TARGETS } from './routedEventReads';

type EngagementControllerDeps = {
  state: AppCombinedState;
  scheduler: BoundedHydrationScheduler;
  loadEngagements?: typeof loadNoteEngagements;
  waitForRoutePaint?: () => Promise<void>;
};

export const MAX_VISIBLE_ENGAGEMENT_NOTES = MAX_ROUTED_ENGAGEMENT_TARGETS;

export function createAppEngagementController(deps: EngagementControllerDeps) {
  const { state } = deps;
  const loadEngagements = deps.loadEngagements ?? loadNoteEngagements;
  const waitForRoutePaint = deps.waitForRoutePaint ?? waitForNextBrowserPaint;
  let activeRequestController: AbortController | null = null;
  let hydrationScope = '';
  let requestedEngagements = new Map<string, NoteEngagement | null>();

  function syncHydrationScope(roots: CID | CID[], token: number): void {
    const accounts = accountsStore.getState();
    const primary = state.rootNhash || (Array.isArray(roots)
      ? roots.map(nhashEncode).join(',') : nhashEncode(roots));
    const scope = [token, accounts.activeAccountPubkey ?? '', primary].join(':');
    if (scope === hydrationScope) {return;}
    hydrationScope = scope;
    requestedEngagements = new Map();
    activeRequestController?.abort();
  }

  // The rendered feed includes cached/live posts that never pass through an
  // archive feed snapshot. Hydrate those same visible targets after projection.
  function ensureVisibleNoteEngagements(roots: CID | CID[], noteIds: string[], token: number): void {
    if (token !== state.loadToken) {return;}
    syncHydrationScope(roots, token);
    const missing: string[] = [];
    let restored: Map<string, NoteEngagement> | null = null;
    for (const id of new Set(noteIds.slice(0, MAX_VISIBLE_ENGAGEMENT_NOTES))) {
      if (!requestedEngagements.has(id)) {
        missing.push(id);
      } else {
        const cached = requestedEngagements.get(id);
        if (cached && state.noteEngagements.get(id) !== cached) {
          restored ??= new Map(state.noteEngagements);
          restored.set(id, cached);
        }
      }
    }
    if (restored) {state.noteEngagements = restored;}
    if (missing.length) {void hydrateNoteEngagements(roots, missing, token, { merge: true });}
  }

  function prependThreadReply(event: RawEvent): void {
    state.threadReplies = prependThreadReplyToState(state.threadReplies, event);
    state.noteEngagements = new Map(state.noteEngagements).set(event.id, ZERO_NOTE_ENGAGEMENT);
  }

  function seedEmptyEngagements(noteIds: string[]): void {
    const next = new Map<string, NoteEngagement>();
    for (const noteId of noteIds) {
      next.set(noteId, state.noteEngagements.get(noteId) ?? { ...ZERO_NOTE_ENGAGEMENT });
    }
    state.noteEngagements = next;
  }

  function seedNewEmptyEngagements(noteIds: string[]): void {
    const next = new Map(state.noteEngagements);
    for (const noteId of noteIds) {
      if (!next.has(noteId)) {
        next.set(noteId, { ...ZERO_NOTE_ENGAGEMENT });
      }
    }
    state.noteEngagements = next;
  }

  function setOptimisticLike(noteId: string): void {
    state.optimisticNoteEngagements = addOptimisticLike(state.optimisticNoteEngagements, noteId);
  }

  function clearOptimisticLike(noteId: string): void {
    state.optimisticNoteEngagements = removeOptimisticLike(state.optimisticNoteEngagements, noteId);
  }

  function syncCaughtUpOptimisticEngagements(engagements: Map<string, NoteEngagement>): void {
    state.optimisticNoteEngagements = clearCaughtUpOptimisticEngagements(
      state.optimisticNoteEngagements,
      engagements,
    );
  }

  async function hydrateNoteEngagements(
    engagementRoots: CID | CID[],
    noteIds: string[],
    token: number,
    options: { merge?: boolean } = {},
  ): Promise<void> {
    if (token !== state.loadToken) {return;}
    syncHydrationScope(engagementRoots, token);
    if (!options.merge) {
      for (const [id, value] of requestedEngagements) {
        if (!value) {requestedEngagements.delete(id);}
      }
    }
    if (!options.merge || !activeRequestController || activeRequestController.signal.aborted) {
      activeRequestController?.abort(
        new DOMException('Engagement hydration superseded', 'AbortError'),
      );
      activeRequestController = new AbortController();
    }
    const requestController = activeRequestController;
    const requestScope = hydrationScope;
    const requestId = options.merge
      ? state.noteEngagementRequestId
      : ++state.noteEngagementRequestId;
    const isCurrent = () => (
      token === state.loadToken && requestId === state.noteEngagementRequestId
      && requestScope === hydrationScope && !requestController.signal.aborted
    );
    // Engagement is a visible-note enhancement, not a reason to scan every
    // item already present in a long retained feed. The hydrators put visible
    // ids first and request later pages as they become visible.
    const uniqueNoteIds = [...new Set(noteIds
      .map((noteId) => noteId.trim().toLowerCase())
      .filter(isHexEventId))]
      .slice(0, MAX_VISIBLE_ENGAGEMENT_NOTES);
    if (uniqueNoteIds.length === 0) {
      if (!options.merge && isCurrent()) {
        state.noteEngagements = new Map();
      }
      return;
    }
    const requestCache = requestedEngagements;
    for (const id of uniqueNoteIds) {requestCache.set(id, null);}
    const accounts = accountsStore.getState();
    const viewerPubkey = getCurrentActiveAccountPubkey(
      accounts.activeAccountPubkey ?? null,
      accounts.accounts,
    );
    if (!options.merge && isCurrent()) {
      state.noteEngagements = new Map(uniqueNoteIds.map((noteId) => [
        noteId,
        state.noteEngagements.get(noteId) ?? ZERO_NOTE_ENGAGEMENT,
      ]));
    }

    try {
      const result = await deps.scheduler.run(
        async (routeSignal) => {
          const signal = AbortSignal.any([routeSignal, requestController.signal]);
          // Feed/profile/thread content must be presentable before archive or
          // relay engagement reads get any main-thread time.
          await waitForRoutePaint();
          signal.throwIfAborted();
          if (!isCurrent()) {
            return new Map<string, NoteEngagement>();
          }
          return await loadEngagements(
            engagementRoots,
            uniqueNoteIds,
            viewerPubkey,
            { signal },
          );
        },
        { isCurrent },
      );
      if (result.status !== 'completed' || !isCurrent()) {
        return;
      }
      const next = new Map(state.noteEngagements);
      for (const noteId of uniqueNoteIds) {
        const value = result.value.get(noteId) ?? ZERO_NOTE_ENGAGEMENT;
        next.set(noteId, value);
        requestCache.set(noteId, value);
      }
      state.noteEngagements = next;
      syncCaughtUpOptimisticEngagements(result.value);
    } catch (error) {
      if (isCurrent()) {
        console.warn('Failed to load note engagement', error);
      }
    }
  }

  return {
    clearOptimisticLike,
    hydrateNoteEngagements,
    ensureVisibleNoteEngagements,
    prependThreadReply,
    seedEmptyEngagements,
    seedNewEmptyEngagements,
    setOptimisticLike,
  };
}
