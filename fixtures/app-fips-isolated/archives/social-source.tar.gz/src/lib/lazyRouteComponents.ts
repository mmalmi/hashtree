import { createRetryableDynamicImport } from './retryableDynamicImport';

export const loadAccountSheetModule = createRetryableDynamicImport(
  () => import('./components/AccountSheet.svelte'),
);

export const loadSearchPageModule = createRetryableDynamicImport(
  () => import('./components/SearchPage.svelte'),
);

export const loadSettingsPageModule = createRetryableDynamicImport(
  () => import('./components/SettingsPage.svelte'),
);

export const loadWalletPageModule = createRetryableDynamicImport(
  () => import('./components/WalletPage.svelte'),
);

/**
 * Intent prewarming must not compete with the hover/focus frame that triggered
 * it. A nested animation frame guarantees the visual state has painted before
 * module parsing or worker startup can consume the main thread.
 */
export function scheduleRoutePrewarm(work: () => void): void {
  if (typeof window === 'undefined' || typeof window.requestAnimationFrame !== 'function') {
    setTimeout(work, 0);
    return;
  }
  window.requestAnimationFrame(() => {
    window.requestAnimationFrame(work);
  });
}

export function prewarmWalletRoute(): void {
  void loadWalletPageModule().catch(() => undefined);
  void import('./walletWorkerTransport')
    .then(({ prewarmWallet }) => prewarmWallet())
    .catch(() => undefined);
}
