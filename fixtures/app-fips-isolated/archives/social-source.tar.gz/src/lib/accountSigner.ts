import type { Nip07LikeSigner } from '@iris/identity/signers';
import { finalizeEvent, type EventTemplate } from 'nostr-tools/pure';
import { getAccountSecretKey, type SocialAccount } from './accounts';
import type { RawEvent } from './nostr';

export function getNostrExtension(): Nip07LikeSigner | null {
  if (typeof window === 'undefined') {return null;}
  const extension = (window as Window & { nostr?: Nip07LikeSigner }).nostr;
  return extension && typeof extension.getPublicKey === 'function'
    && typeof extension.signEvent === 'function' ? extension : null;
}

export function canSignAccount(account: SocialAccount | null | undefined): boolean {
  if (!account) {return false;}
  if (account.method === 'nip07') {return getNostrExtension() !== null;}
  try {
    getAccountSecretKey(account);
    return true;
  } catch {
    return false;
  }
}

/** Signing never publishes or changes the outbox; rejection leaves local state intact. */
export async function signAccountEvent(account: SocialAccount, draft: EventTemplate): Promise<RawEvent> {
  if (account.method !== 'nip07') {return finalizeEvent(draft, getAccountSecretKey(account));}
  const extension = getNostrExtension();
  if (!extension) {throw new Error('Open your Nostr extension to sign this action.');}
  const { createNostrIdentitySignerFromNip07 } = await import('@iris/identity/signers');
  const expectedPubkey = account.pubkey.toLowerCase();
  const getExpectedPubkey = async () => {
    const pubkey = (await extension.getPublicKey()).toLowerCase();
    if (pubkey !== expectedPubkey) {
      throw new Error('Your extension is using a different account. Switch it back or sign in again.');
    }
    return pubkey;
  };
  const signer = createNostrIdentitySignerFromNip07({
    getPublicKey: getExpectedPubkey,
    signEvent: async (template) => {
      // Strip any object-local verification cache before the shared adapter checks it.
      const event = await extension.signEvent(template);
      return {
        id: event.id, pubkey: event.pubkey, sig: event.sig,
        kind: event.kind, content: event.content, created_at: event.created_at,
        tags: event.tags.map((tag) => [...tag]),
      };
    },
  });
  const signed = await signer.signEvent(draft);
  await getExpectedPubkey();
  return signed;
}
