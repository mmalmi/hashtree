export type AsyncIteratorRaceUpdate<T, Resolution> =
  | { type: 'item'; value: T }
  | { type: 'resolution'; value: Resolution };

/**
 * Keep forwarding progressive immutable-index values until an independent
 * lookup settles. If the stream finishes first, wait for and emit the lookup
 * result exactly once. The unfinished iterator is closed without delaying the
 * caller when the lookup wins the race.
 */
export async function* raceAsyncIteratorWithPromise<T, Resolution>(
  iterator: AsyncIterator<T>,
  resolution: Promise<Resolution>,
): AsyncGenerator<AsyncIteratorRaceUpdate<T, Resolution>, void, void> {
  const resolutionResult = resolution.then(
    (value) => ({ type: 'resolution' as const, value }),
    (error: unknown) => ({ type: 'resolution-error' as const, error }),
  );
  let iteratorCompleted = false;

  try {
    while (true) {
      const nextResult = iterator.next().then(
        (value) => ({ type: 'item' as const, value }),
        (error: unknown) => ({ type: 'item-error' as const, error }),
      );
      const first = await Promise.race([nextResult, resolutionResult]);
      if (first.type === 'resolution-error' || first.type === 'item-error') {
        throw first.error;
      }
      if (first.type === 'resolution') {
        yield first;
        return;
      }
      if (first.value.done) {
        iteratorCompleted = true;
        const settledResolution = await resolutionResult;
        if (settledResolution.type === 'resolution-error') {
          throw settledResolution.error;
        }
        yield settledResolution;
        return;
      }
      yield { type: 'item', value: first.value.value };
    }
  } finally {
    if (!iteratorCompleted) {
      void iterator.return?.().catch(() => undefined);
    }
  }
}
