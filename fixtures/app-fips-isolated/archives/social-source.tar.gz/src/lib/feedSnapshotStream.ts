import type { CID } from '@hashtree/core';
import { buildInitialHomeFeedPage } from './homeFeedPagination';
import {
  awaitWithin,
  feedIndexStreamWaitMs,
  nextIteratorWithin,
} from './feedIndexTiming';
import { isHexPubkey, type ProfileRecord, type RawEvent } from './nostr';
import type { NostrEventIndexReader } from './nostrIndexReader';
import type { FeedSnapshot } from './nostrIndexTypes';

const OPTIONAL_FEED_ROOT_GRACE_MS = 200;

export type FeedSnapshotStreamDeps = {
  getFeedProfilePubkeys: (
    viewerPubkey: string,
    feedOwnerPubkey: string,
    notes: RawEvent[],
  ) => string[];
  getReaderForRoot: (root: CID) => NostrEventIndexReader;
  getRootNhash: (root: CID) => string;
  loadRecentTextNotesByAuthors?: (
    roots: CID[],
    authors: string[],
    limit: number,
    options: { includeReplies?: boolean },
  ) => Promise<RawEvent[]>;
  shouldRoutePrimaryRoot?: (root: CID) => boolean;
  loadRecentNotes?: (
    authors: string[], includeReplies: boolean, signal: AbortSignal, onProgress: (notes: RawEvent[]) => void,
  ) => Promise<RawEvent[]>;
  loadProfilesForPubkeys: (
    root: CID,
    pubkeys: string[],
  ) => Promise<Map<string, ProfileRecord>>;
};

export async function* streamFeedSnapshotsByAuthors(
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  follows: string[],
  feedOwnerPubkey: string,
  feedAuthors: string[],
  starterMode: FeedSnapshot['starterMode'],
  options: {
    additionalRootsPromise?: Promise<CID[]>;
    includeProfiles?: boolean;
    includeReplies?: boolean;
    emitEvery?: number;
    minimumNotes?: number;
  } = {},
  deps: FeedSnapshotStreamDeps,
): AsyncGenerator<FeedSnapshot, void, void> {
  const effectiveFeedAuthors = [...new Set([
    ...feedAuthors,
    ...(isHexPubkey(feedOwnerPubkey) ? [feedOwnerPubkey] : []),
  ])];
  let latestNotes: RawEvent[] | null = null;
  let relayNotes: RawEvent[] = [];
  let iteratorCompleted = false;
  let streamedAny = false;

  if (effectiveFeedAuthors.length > 0) {
    const routedPrimary = deps.loadRecentTextNotesByAuthors
      && deps.shouldRoutePrimaryRoot?.(root) === true;
    const indexedNoteStream = routedPrimary
      ? (async function* (): AsyncGenerator<RawEvent[], void, void> {
          yield await deps.loadRecentTextNotesByAuthors!(
            [root],
            effectiveFeedAuthors,
            limit,
            { includeReplies: options.includeReplies },
          );
        })()
      : reader.streamRecentTextNotesByAuthors(effectiveFeedAuthors, limit, {
          emitEvery: options.emitEvery,
          includeReplies: options.includeReplies,
        });
    const indexedNoteIterator = indexedNoteStream[Symbol.asyncIterator]();
    const minimumNotes = options.minimumNotes === undefined
      ? limit
      : Math.min(limit, Math.max(1, options.minimumNotes));
    const relayAbort = new AbortController();
    let pendingNotes: RawEvent[] = [];
    let notifyProgress: () => void;
    const nextProgress = () => new Promise<'relay-progress'>(resolve => {
      notifyProgress = () => resolve('relay-progress');
    });
    let progressRead = nextProgress();
    let relayRead = deps.loadRecentNotes?.(effectiveFeedAuthors, options.includeReplies ?? false, relayAbort.signal, notes => {
      if (relayAbort.signal.aborted) { return; }
      pendingNotes = notes;
      notifyProgress();
    })
      .catch(() => pendingNotes)
      .then(notes => ({ type: 'relay' as const, notes }));
    const readIndex = () => (options.minimumNotes !== undefined && streamedAny
      ? indexedNoteIterator.next().then(value => ({ settled: true as const, value }))
      : nextIteratorWithin(indexedNoteIterator, feedIndexStreamWaitMs(streamedAny)))
      .then(result => ({ type: 'index' as const, result }), error => ({ type: 'index-error' as const, error }));
    let indexRead: ReturnType<typeof readIndex> | undefined = readIndex();
    let indexFailure: { error: unknown } | undefined;
    let painted = false;

    try {
      while (indexRead || relayRead) {
        const update = await Promise.race([indexRead, relayRead, relayRead && progressRead].filter(read => read !== undefined));
        if (update === 'relay-progress' || update.type === 'relay') {
          const notes = update === 'relay-progress' ? pendingNotes : update.notes;
          if (update === 'relay-progress') { progressRead = nextProgress(); }
          else { relayRead = undefined; }
          if (notes.length === relayNotes.length && notes.every((event, index) => event.id === relayNotes[index].id)) { continue; }
          relayNotes = notes;
        } else {
          indexRead = undefined;
          if (update.type === 'index-error') {
            indexFailure = { error: update.error };
            continue;
          }
          if (!update.result.settled || update.result.value.done) {
            iteratorCompleted = update.result.settled;
            continue;
          }
          streamedAny = true;
          latestNotes = update.result.value.value;
          if (latestNotes.length < minimumNotes) {
            indexRead = readIndex();
          }
        }

        // An empty source is still provisional while its peer is reading.
        // Every nonempty verified page can paint immediately.
        if (!painted && !latestNotes?.length && !relayNotes.length && (indexRead || relayRead)) {
          continue;
        }

        const page = buildInitialHomeFeedPage({
          authors: effectiveFeedAuthors,
          includeReplies: options.includeReplies ?? false,
          limit,
          mode: 'latest',
          rootPages: [{ events: latestNotes ?? [], exhausted: iteratorCompleted, root }],
          overlayEvents: relayNotes,
        });
        painted = true;
        yield {
          rootNhash: deps.getRootNhash(root),
          followCount: follows.length,
          follows,
          profiles: new Map<string, ProfileRecord>(),
          notes: page.notes,
          feedOwnerPubkey,
          usedSuggestedFeed: starterMode !== null,
          starterMode,
          continuation: page.continuation,
        };
      }
      if (indexFailure && relayNotes.length === 0) {
        throw indexFailure.error;
      }
    } finally {
      relayAbort.abort();
      if (!iteratorCompleted) {
        // An outstanding next() still uses the transport's bounded deadline;
        // return() is queued behind it rather than blocking route teardown.
        void indexedNoteIterator.return?.(undefined).catch((error) => {
          console.warn('Failed to close indexed feed stream', error);
        });
      }
    }
  } else {
    latestNotes = [];
  }

  const indexedNotes = latestNotes ?? [];
  const initialPage = buildInitialHomeFeedPage({
    authors: effectiveFeedAuthors,
    includeReplies: options.includeReplies ?? false,
    limit,
    mode: 'latest',
    rootPages: [{
      events: indexedNotes,
      exhausted: effectiveFeedAuthors.length === 0 || iteratorCompleted,
      root,
    }],
    overlayEvents: relayNotes,
  });
  let { notes, continuation } = initialPage;
  const additionalRootsResult = options.additionalRootsPromise
    ? await awaitWithin(options.additionalRootsPromise.catch((error) => {
        console.warn('Failed to resolve an additional immutable home-feed root', error);
        return [];
      }), OPTIONAL_FEED_ROOT_GRACE_MS)
    : { settled: true as const, value: [] as CID[] };
  const additionalRoots = (additionalRootsResult.settled
    ? additionalRootsResult.value
    : []).filter((candidateRoot) => (
    deps.getRootNhash(candidateRoot) !== deps.getRootNhash(root)
  ));
  if (effectiveFeedAuthors.length > 0 && additionalRoots.length > 0) {
    const additionalPages = await Promise.all(additionalRoots.map(async (candidateRoot) => {
      try {
        const events = deps.loadRecentTextNotesByAuthors
          ? await deps.loadRecentTextNotesByAuthors(
              [candidateRoot],
              effectiveFeedAuthors,
              limit,
              { includeReplies: options.includeReplies },
            )
          : await deps.getReaderForRoot(candidateRoot).getRecentTextNotesByAuthors(
              effectiveFeedAuthors,
              limit,
              { includeReplies: options.includeReplies },
            );
        return {
          events,
          exhausted: events.length < limit,
          root: candidateRoot,
        };
      } catch (error) {
        console.warn('Failed to load an additional immutable home-feed root', error);
        // Unavailable is not exhausted. Preserve this immutable root in the
        // continuation so the next explicit page request can retry it.
        return { events: [] as RawEvent[], exhausted: false, root: candidateRoot };
      }
    }));
    const mergedPage = buildInitialHomeFeedPage({
      authors: effectiveFeedAuthors,
      includeReplies: options.includeReplies ?? false,
      limit,
      mode: 'latest',
      rootPages: [{
        events: indexedNotes,
        exhausted: iteratorCompleted,
        root,
      }, ...additionalPages],
      overlayEvents: relayNotes,
    });
    notes = mergedPage.notes;
    continuation = mergedPage.continuation;
  }

  const profiles = options.includeProfiles === false
    ? new Map<string, ProfileRecord>()
    : await deps.loadProfilesForPubkeys(
        root,
        deps.getFeedProfilePubkeys(viewerPubkey, feedOwnerPubkey, notes),
      );

  if (
    options.includeProfiles !== false
    || !streamedAny
    || additionalRoots.length > 0
    || (iteratorCompleted && notes.length < limit)
  ) {
    yield {
      rootNhash: deps.getRootNhash(root),
      followCount: follows.length,
      follows,
      profiles,
      notes,
      feedOwnerPubkey,
      usedSuggestedFeed: starterMode !== null,
      starterMode,
      continuation,
    };
  }
}
