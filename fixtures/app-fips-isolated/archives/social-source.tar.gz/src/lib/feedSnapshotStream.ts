import type { CID } from '@hashtree/core';
import { buildInitialHomeFeedPage } from './homeFeedPagination';
import {
  awaitWithin,
  feedIndexStreamWaitMs,
  nextIteratorWithin,
} from './feedIndexTiming';
import { isHexPubkey, type ProfileRecord, type RawEvent } from './nostr';
import type { NostrEventIndexReader } from './nostrIndexReader';
import type { FeedSnapshot } from './nostrIndexTypes';

const OPTIONAL_FEED_ROOT_GRACE_MS = 200;

export type FeedSnapshotStreamDeps = {
  getFeedProfilePubkeys: (
    viewerPubkey: string,
    feedOwnerPubkey: string,
    notes: RawEvent[],
  ) => string[];
  getReaderForRoot: (root: CID) => NostrEventIndexReader;
  getRootNhash: (root: CID) => string;
  loadRecentTextNotesByAuthors?: (
    roots: CID[],
    authors: string[],
    limit: number,
    options: { includeReplies?: boolean },
  ) => Promise<RawEvent[]>;
  shouldRoutePrimaryRoot?: (root: CID) => boolean;
  loadProfilesForPubkeys: (
    root: CID,
    pubkeys: string[],
  ) => Promise<Map<string, ProfileRecord>>;
};

export async function* streamFeedSnapshotsByAuthors(
  root: CID,
  reader: NostrEventIndexReader,
  viewerPubkey: string,
  limit: number,
  follows: string[],
  feedOwnerPubkey: string,
  feedAuthors: string[],
  starterMode: FeedSnapshot['starterMode'],
  options: {
    additionalRootsPromise?: Promise<CID[]>;
    includeProfiles?: boolean;
    includeReplies?: boolean;
    emitEvery?: number;
    minimumNotes?: number;
  } = {},
  deps: FeedSnapshotStreamDeps,
): AsyncGenerator<FeedSnapshot, void, void> {
  const effectiveFeedAuthors = [...new Set([
    ...feedAuthors,
    ...(isHexPubkey(feedOwnerPubkey) ? [feedOwnerPubkey] : []),
  ])];
  let latestNotes: RawEvent[] | null = null;
  let iteratorCompleted = false;
  let streamedAny = false;

  if (effectiveFeedAuthors.length > 0) {
    const routedPrimary = deps.loadRecentTextNotesByAuthors
      && deps.shouldRoutePrimaryRoot?.(root) === true;
    const indexedNoteStream = routedPrimary
      ? (async function* (): AsyncGenerator<RawEvent[], void, void> {
          yield await deps.loadRecentTextNotesByAuthors!(
            [root],
            effectiveFeedAuthors,
            limit,
            { includeReplies: options.includeReplies },
          );
        })()
      : reader.streamRecentTextNotesByAuthors(effectiveFeedAuthors, limit, {
          emitEvery: options.emitEvery,
          includeReplies: options.includeReplies,
        });
    const indexedNoteIterator = indexedNoteStream[Symbol.asyncIterator]();
    const minimumNotes = options.minimumNotes === undefined
      ? limit
      : Math.min(limit, Math.max(1, options.minimumNotes));

    try {
      while (true) {
        // Initial hydration already painted a useful snapshot. Preserve this
        // read until its visible page fills; the transport owns its deadline.
        const nextNotes = options.minimumNotes !== undefined && streamedAny
          ? { settled: true as const, value: await indexedNoteIterator.next() }
          : await nextIteratorWithin(indexedNoteIterator, feedIndexStreamWaitMs(streamedAny));
        if (!nextNotes.settled) {
          break;
        }
        if (nextNotes.value.done) {
          iteratorCompleted = true;
          break;
        }

        const page = buildInitialHomeFeedPage({
          authors: effectiveFeedAuthors,
          includeReplies: options.includeReplies ?? false,
          limit,
          mode: 'latest',
          rootPages: [{ events: nextNotes.value.value, exhausted: false, root }],
        });
        streamedAny = true;
        latestNotes = page.notes;
        yield {
          rootNhash: deps.getRootNhash(root),
          followCount: follows.length,
          follows,
          profiles: new Map<string, ProfileRecord>(),
          notes: page.notes,
          feedOwnerPubkey,
          usedSuggestedFeed: starterMode !== null,
          starterMode,
          continuation: page.continuation,
        };
        if (page.notes.length >= minimumNotes) {
          // A complete visible page already has an exact, open continuation.
          // Do not hold pagination behind an iterator that may be waiting on a
          // slow immutable block after first paint.
          break;
        }
      }
    } finally {
      if (!iteratorCompleted) {
        // An outstanding next() still uses the transport's bounded deadline;
        // return() is queued behind it rather than blocking route teardown.
        void indexedNoteIterator.return?.(undefined).catch((error) => {
          console.warn('Failed to close indexed feed stream', error);
        });
      }
    }
  } else {
    latestNotes = [];
  }

  let notes = latestNotes ?? [];
  let continuation = buildInitialHomeFeedPage({
    authors: effectiveFeedAuthors,
    includeReplies: options.includeReplies ?? false,
    limit,
    mode: 'latest',
    rootPages: [{
      events: notes,
      exhausted: effectiveFeedAuthors.length === 0 || iteratorCompleted,
      root,
    }],
  }).continuation;
  const additionalRootsResult = options.additionalRootsPromise
    ? await awaitWithin(options.additionalRootsPromise.catch((error) => {
        console.warn('Failed to resolve an additional immutable home-feed root', error);
        return [];
      }), OPTIONAL_FEED_ROOT_GRACE_MS)
    : { settled: true as const, value: [] as CID[] };
  const additionalRoots = (additionalRootsResult.settled
    ? additionalRootsResult.value
    : []).filter((candidateRoot) => (
    deps.getRootNhash(candidateRoot) !== deps.getRootNhash(root)
  ));
  if (effectiveFeedAuthors.length > 0 && additionalRoots.length > 0) {
    const additionalPages = await Promise.all(additionalRoots.map(async (candidateRoot) => {
      try {
        const events = deps.loadRecentTextNotesByAuthors
          ? await deps.loadRecentTextNotesByAuthors(
              [candidateRoot],
              effectiveFeedAuthors,
              limit,
              { includeReplies: options.includeReplies },
            )
          : await deps.getReaderForRoot(candidateRoot).getRecentTextNotesByAuthors(
              effectiveFeedAuthors,
              limit,
              { includeReplies: options.includeReplies },
            );
        return {
          events,
          exhausted: events.length < limit,
          root: candidateRoot,
        };
      } catch (error) {
        console.warn('Failed to load an additional immutable home-feed root', error);
        // Unavailable is not exhausted. Preserve this immutable root in the
        // continuation so the next explicit page request can retry it.
        return { events: [] as RawEvent[], exhausted: false, root: candidateRoot };
      }
    }));
    const mergedPage = buildInitialHomeFeedPage({
      authors: effectiveFeedAuthors,
      includeReplies: options.includeReplies ?? false,
      limit,
      mode: 'latest',
      rootPages: [{
        events: notes,
        exhausted: iteratorCompleted,
        root,
      }, ...additionalPages],
    });
    notes = mergedPage.notes;
    continuation = mergedPage.continuation;
  }

  const profiles = options.includeProfiles === false
    ? new Map<string, ProfileRecord>()
    : await deps.loadProfilesForPubkeys(
        root,
        deps.getFeedProfilePubkeys(viewerPubkey, feedOwnerPubkey, notes),
      );

  if (
    options.includeProfiles !== false
    || !streamedAny
    || additionalRoots.length > 0
    || (iteratorCompleted && notes.length < limit)
  ) {
    yield {
      rootNhash: deps.getRootNhash(root),
      followCount: follows.length,
      follows,
      profiles,
      notes,
      feedOwnerPubkey,
      usedSuggestedFeed: starterMode !== null,
      starterMode,
      continuation,
    };
  }
}
