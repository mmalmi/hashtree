import { matchFilter } from 'nostr-tools/filter';
import {
  localIndexSource,
  verifyNostrEvent,
  verifyNostrEventsWith,
  type NostrEventReader,
  type NostrEvent,
  type NostrFilter,
  type NostrVerifiedEvent,
  type QueryEvent,
  type QueryOptions,
  type QueryReport,
} from 'nostr-pubsub';
import type { RawEvent } from './nostr';

const LIVE_OVERLAY_SOURCE = localIndexSource('iris-social-live-overlay');
const HEX_64 = /^[0-9a-f]{64}$/;
const MAX_SYNC_VERIFICATION_MS = 8;
const VERIFY_BATCH_SIZE = 256;

export type OverlayEventVerifier = (
  events: readonly NostrEvent[],
  signal?: AbortSignal,
) => Promise<boolean[]>;

type SocialDataPlaneEventReaderOptions = {
  /** A trusted worker boundary. Browser callers must provide this to avoid UI-thread Schnorr work. */
  verifyEvents?: OverlayEventVerifier;
};

/** Adapts the bounded, persisted SocialDataPlane overlay to the shared reader contract. */
export function createSocialDataPlaneEventReader(
  getEvents: () => readonly RawEvent[],
  getEventById?: (eventId: string) => RawEvent | null,
  options: SocialDataPlaneEventReaderOptions = {},
): NostrEventReader {
  const verifiedByRawEvent = new WeakMap<RawEvent, NostrVerifiedEvent>();
  const verifyEvents = options.verifyEvents ?? verifyEventsLocally;
  return {
    async query(filters: NostrFilter[], options: QueryOptions = {}): Promise<QueryReport> {
      validateOptions(options);
      throwIfStopped(options);
      const queryFilters = filters.length > 0 ? filters : [{}];
      const orderedCandidates = selectCandidateEvents(queryFilters, getEvents, getEventById)
        .filter((event) => queryFilters.some((filter) => matchesFilter(filter, event)))
        .sort(compareNewestFirst);
      const selectedCandidates = selectLimitedCandidates(queryFilters, orderedCandidates, options);
      const byId = new Map<string, QueryEvent>();
      const uncachedCandidates = selectedCandidates.filter((event) => !verifiedByRawEvent.has(event));
      const verificationSignal = createVerificationSignal(options);
      try {
        for (let index = 0; index < uncachedCandidates.length; index += VERIFY_BATCH_SIZE) {
          throwIfStopped(options);
          const batch = uncachedCandidates.slice(index, index + VERIFY_BATCH_SIZE);
          const admitted = await verifyNostrEventsWith(
            batch,
            async (candidates) => await verifyEvents(
              candidates,
              verificationSignal.signal,
            ),
            { signal: verificationSignal.signal },
          );
          for (let batchIndex = 0; batchIndex < batch.length; batchIndex += 1) {
            verifiedByRawEvent.set(batch[batchIndex]!, admitted[batchIndex]!);
          }
        }
      } finally {
        verificationSignal.cleanup();
      }
      for (const rawEvent of selectedCandidates) {
        const event = verifiedByRawEvent.get(rawEvent)!;
        if (!byId.has(event.id)) {
          byId.set(event.id, { event, source: LIVE_OVERLAY_SOURCE, priority: 0 });
        }
      }
      const events = [...byId.values()].sort((left, right) => (
        compareNewestFirst(left.event, right.event)
      ));
      return {
        events: options.limit === undefined ? events : events.slice(0, options.limit),
        complete: true,
      };
    },
  };
}

async function verifyEventsLocally(
  events: readonly NostrEvent[],
  options?: AbortSignal,
): Promise<boolean[]> {
  const valid: boolean[] = [];
  let syncWorkStartedAt = performance.now();
  for (const event of events) {
    if (options?.aborted) {throwIfStopped({ signal: options });}
    verifyNostrEvent(event);
    valid.push(true);
    syncWorkStartedAt = await yieldAfterVerificationBudget({ signal: options }, syncWorkStartedAt);
  }
  return valid;
}

function createVerificationSignal(options: QueryOptions): {
  signal: AbortSignal | undefined;
  cleanup(): void;
} {
  if (options.deadline === undefined) {
    return { signal: options.signal, cleanup: () => undefined };
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  options.signal?.addEventListener('abort', abort, { once: true });
  const timeout = setTimeout(abort, Math.max(0, options.deadline - Date.now()));
  return {
    signal: controller.signal,
    cleanup() {
      clearTimeout(timeout);
      options.signal?.removeEventListener('abort', abort);
    },
  };
}

function matchesFilter(filter: NostrFilter, event: RawEvent): boolean {
  if (filter.ids && !filter.ids.some((prefix) => event.id.startsWith(prefix))) {return false;}
  if (filter.authors && !filter.authors.some((prefix) => event.pubkey.startsWith(prefix))) {
    return false;
  }
  return matchFilter({ ...filter, ids: undefined, authors: undefined }, event);
}

function selectLimitedCandidates(
  filters: readonly NostrFilter[],
  orderedCandidates: readonly RawEvent[],
  options: QueryOptions,
): RawEvent[] {
  const selectedById = new Map<string, RawEvent>();
  for (const filter of filters) {
    let matched = 0;
    const filterLimit = typeof filter.limit === 'number' ? filter.limit : undefined;
    for (const event of orderedCandidates) {
      if (filterLimit !== undefined && matched >= filterLimit) {break;}
      if (!matchesFilter(filter, event)) {continue;}
      matched += 1;
      if (!selectedById.has(event.id)) {
        selectedById.set(event.id, event);
      }
    }
    throwIfStopped(options);
  }
  const selected = [...selectedById.values()].sort(compareNewestFirst);
  return options.limit === undefined ? selected : selected.slice(0, options.limit);
}

async function yieldAfterVerificationBudget(
  options: QueryOptions,
  syncWorkStartedAt: number,
): Promise<number> {
  if (performance.now() - syncWorkStartedAt < MAX_SYNC_VERIFICATION_MS) {
    return syncWorkStartedAt;
  }
  await new Promise<void>((resolve) => { setTimeout(resolve, 0); });
  throwIfStopped(options);
  return performance.now();
}

function selectCandidateEvents(
  filters: readonly NostrFilter[],
  getEvents: () => readonly RawEvent[],
  getEventById?: (eventId: string) => RawEvent | null,
): readonly RawEvent[] {
  if (!getEventById || filters.some(({ ids }) => (
    !ids || ids.length === 0 || ids.some((eventId) => !HEX_64.test(eventId))
  ))) {
    return getEvents();
  }
  const events = new Map<string, RawEvent>();
  for (const filter of filters) {
    for (const eventId of filter.ids ?? []) {
      const event = getEventById(eventId);
      if (event) {events.set(event.id, event);}
    }
  }
  return [...events.values()];
}

function validateOptions(options: QueryOptions): void {
  if (
    options.limit !== undefined
    && (!Number.isSafeInteger(options.limit) || options.limit < 0)
  ) {
    throw new RangeError('Social overlay query limit must be a non-negative safe integer');
  }
  if (options.deadline !== undefined && !Number.isFinite(options.deadline)) {
    throw new RangeError('Social overlay query deadline must be finite');
  }
}

function throwIfStopped(options: QueryOptions): void {
  if (options.signal?.aborted) {
    throw new DOMException('Social overlay query cancelled', 'AbortError');
  }
  if (options.deadline !== undefined && Date.now() >= options.deadline) {
    throw new DOMException('Social overlay query deadline exceeded', 'TimeoutError');
  }
}

function compareNewestFirst(
  left: Pick<RawEvent, 'created_at' | 'id'>,
  right: Pick<RawEvent, 'created_at' | 'id'>,
): number {
  return right.created_at - left.created_at || left.id.localeCompare(right.id);
}
