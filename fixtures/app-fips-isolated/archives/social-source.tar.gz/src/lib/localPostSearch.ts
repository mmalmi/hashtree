import type { RawEvent } from './nostr';
import { POST_SEARCH_KINDS } from './postSearchCatalogConstants';
import { parsePostSearchRoutingQueryTerms } from './postSearchTermRouting';
import {
  getVerifiedEmbeddedRepostTarget,
  needsEmbeddedRepostAdmission,
  requestEmbeddedRepostAdmission,
} from './repostPresentation';

const SUPPORTED_KINDS = new Set<number>(POST_SEARCH_KINDS);
const QUOTED_PHRASE_PATTERN = /["“]([^"”]*)["”]/gu;
const MAX_CONTENT_CHARS = 8_192;
const MAX_TITLE_CHARS = 1_024;
const MAX_HASHTAG_CHARS = 2_048;
const MAX_AUTHOR_CHARS = 1_024;
const MAX_TERMS_PER_FIELD = 512;

export type LocalPostSearchResult = {
  event: RawEvent;
  score: number;
};

export type LocalPostSearchOptions = {
  limit?: number;
  authorTextByPubkey?: ReadonlyMap<string, string>;
};

export type LocalPostSearchDocument = {
  event: RawEvent;
  normalizedText: string;
  fields: ReadonlyArray<{ weight: number; terms: ReadonlySet<string> }>;
};

/** Compact discovery rows show verified original posts, never repost JSON. */
export async function preparePostSearchSuggestions(events: readonly RawEvent[]): Promise<RawEvent[]> {
  await Promise.all(events.filter(needsEmbeddedRepostAdmission).map((event) => requestEmbeddedRepostAdmission(event)));
  const posts = new Map<string, RawEvent>();
  for (const event of events) {
    const post = event.kind === 6 ? getVerifiedEmbeddedRepostTarget(event) : event;
    if (post && SUPPORTED_KINDS.has(post.kind)) {
      posts.set(post.id, post);
    }
  }
  return [...posts.values()];
}

/**
 * Search the app's bounded, already-verified note cache synchronously. This is
 * the instant personal/live overlay; authenticated Hashtree catalogs remain
 * the complete archive search path.
 */
export function searchLocalPosts(
  events: readonly RawEvent[],
  query: string,
  options: LocalPostSearchOptions = {},
): LocalPostSearchResult[] {
  return searchLocalPostDocuments(
    buildLocalPostSearchDocuments(events, options.authorTextByPubkey),
    query,
    options.limit,
  );
}

/** Precompute bounded token projections when the note/profile cache changes. */
export function buildLocalPostSearchDocuments(
  events: readonly RawEvent[],
  authorTextByPubkey: ReadonlyMap<string, string> = new Map(),
): LocalPostSearchDocument[] {
  const seen = new Set<string>();
  const documents: LocalPostSearchDocument[] = [];
  for (const event of events) {
    if (seen.has(event.id) || !SUPPORTED_KINDS.has(event.kind)) {
      continue;
    }
    seen.add(event.id);

    const content = event.content.slice(0, MAX_CONTENT_CHARS);
    const title = tagValues(event.tags, ['subject', 'summary', 'title'])
      .join(' ')
      .slice(0, MAX_TITLE_CHARS);
    const hashtags = tagValues(event.tags, ['t'])
      .map((value) => `#${value.replace(/^#/u, '')}`)
      .join(' ')
      .slice(0, MAX_HASHTAG_CHARS);
    const author = `${event.pubkey} ${authorTextByPubkey.get(event.pubkey) ?? ''}`
      .slice(0, MAX_AUTHOR_CHARS);
    documents.push({
      event,
      normalizedText: normalizeText(`${author} ${title} ${hashtags} ${content}`),
      fields: [
        { weight: 7, terms: documentTerms(hashtags) },
        { weight: 5, terms: documentTerms(title) },
        { weight: 2.5, terms: documentTerms(author) },
        { weight: 1, terms: documentTerms(content) },
      ],
    });
  }
  return documents;
}

/** Query a precomputed projection without retokenizing cached long-form posts. */
export function searchLocalPostDocuments(
  documents: readonly LocalPostSearchDocument[],
  query: string,
  requestedLimit = 40,
): LocalPostSearchResult[] {
  const normalizedQuery = normalizeText(query).trim();
  const terms = parsePostSearchRoutingQueryTerms(normalizedQuery);
  if (normalizedQuery.length < 2 || terms.length === 0) {
    return [];
  }

  const phrases = [...normalizedQuery.matchAll(QUOTED_PHRASE_PATTERN)]
    .map((match) => normalizeText(match[1] ?? '').trim())
    .filter(Boolean);
  const limit = Math.max(1, Math.min(80, Math.trunc(requestedLimit)));
  const results: LocalPostSearchResult[] = [];

  for (const document of documents) {
    if (phrases.some((phrase) => !document.normalizedText.includes(phrase))) {
      continue;
    }
    let score = phrases.length * 10;
    let matchedTerms = 0;
    for (const term of terms) {
      let termScore = 0;
      for (const field of document.fields) {
        if (field.terms.has(term)) {
          termScore = Math.max(termScore, field.weight);
        }
      }
      if (termScore > 0) {
        matchedTerms += 1;
        score += termScore;
      }
    }
    if (matchedTerms === 0) {
      continue;
    }
    score += matchedTerms / terms.length;
    results.push({ event: document.event, score });
  }

  return results
    .sort((left, right) => (
      right.score - left.score
      || right.event.created_at - left.event.created_at
      || left.event.id.localeCompare(right.event.id)
    ))
    .slice(0, limit);
}

/** Keep authenticated catalog order, then fill unused page slots locally. */
export function mergePostSearchEvents(
  catalogEvents: readonly RawEvent[],
  localResults: readonly LocalPostSearchResult[],
  requestedLimit: number,
): RawEvent[] {
  const limit = Math.max(1, Math.min(80, Math.trunc(requestedLimit)));
  const merged = new Map<string, RawEvent>();
  for (const event of catalogEvents) {
    if (merged.size >= limit) {
      break;
    }
    merged.set(event.id, event);
  }
  for (const result of localResults) {
    if (merged.size >= limit) {
      break;
    }
    if (!merged.has(result.event.id)) {
      merged.set(result.event.id, result.event);
    }
  }
  return [...merged.values()];
}

function documentTerms(value: string): Set<string> {
  const parsed = parsePostSearchRoutingQueryTerms(value).slice(0, MAX_TERMS_PER_FIELD);
  const terms = new Set(parsed);
  for (const term of parsed) {
    if (term.startsWith('#') && term.length > 1) {
      terms.add(term.slice(1));
    }
  }
  return terms;
}

function tagValues(tags: readonly string[][], names: readonly string[]): string[] {
  const allowed = new Set(names);
  return tags
    .filter((tag) => allowed.has(tag[0]) && tag[1]?.trim())
    .map((tag) => tag[1].trim());
}

function normalizeText(value: string): string {
  return value.normalize('NFKC').toLowerCase().replace(/’/gu, "'");
}
