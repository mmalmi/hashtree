import { get, writable } from 'svelte/store';
import { generateSecretKey, getPublicKey } from 'nostr-tools/pure';
import * as nip19 from 'nostr-tools/nip19';
import { fallbackProfileNameForIdentity } from './nostr';

const STORAGE_KEY_ACCOUNTS = 'iris-social:accounts';
const STORAGE_KEY_ACTIVE_ACCOUNT = 'iris-social:active-account';

export type SocialAccountMethod = 'generated' | 'npub' | 'nsec' | 'nip07';

export type SocialAccountProfile = {
  name: string;
};

export type SocialAccount = {
  pubkey: string;
  npub: string;
  method: SocialAccountMethod;
  isPristineDefault?: boolean;
  nsec?: string;
  createdAt: number;
  updatedAt: number;
  profile: SocialAccountProfile;
};

type StoredSocialAccount = Partial<SocialAccount> & {
  profile?: Partial<SocialAccountProfile>;
};

type AccountsState = {
  accounts: SocialAccount[];
  activeAccountPubkey: string | null;
  initialized: boolean;
};

function normalizeMethod(value: unknown): SocialAccountMethod {
  return value === 'npub' || value === 'nsec' || value === 'nip07' ? value : 'generated';
}

function buildAccount(
  pubkey: string,
  method: SocialAccountMethod,
  options: {
    nsec?: string;
    isPristineDefault?: boolean;
    createdAt?: number;
    updatedAt?: number;
    profile?: Partial<SocialAccountProfile>;
  } = {},
): SocialAccount {
  const normalizedPubkey = pubkey.toLowerCase();
  const createdAt = options.createdAt ?? Date.now();
  const updatedAt = options.updatedAt ?? createdAt;

  return {
    pubkey: normalizedPubkey,
    npub: nip19.npubEncode(normalizedPubkey),
    method,
    isPristineDefault: options.isPristineDefault,
    nsec: options.nsec,
    createdAt,
    updatedAt,
    profile: {
      name: options.profile?.name?.trim() || fallbackProfileNameForIdentity(normalizedPubkey),
    },
  };
}

function validateStoredAccount(value: unknown): SocialAccount | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const candidate = value as StoredSocialAccount;
  if (typeof candidate.pubkey !== 'string' || !/^[0-9a-f]{64}$/i.test(candidate.pubkey)) {
    return null;
  }

  const storedNsec = typeof candidate.nsec === 'string' ? candidate.nsec : undefined;
  let method = normalizeMethod(candidate.method);
  let nsec = method === 'nip07' ? undefined : storedNsec;
  if (storedNsec && method !== 'nip07') {
    try {
      const decoded = nip19.decode(storedNsec);
      if (
        decoded.type !== 'nsec'
        || getPublicKey(decoded.data as Uint8Array) !== candidate.pubkey.toLowerCase()
      ) {
        nsec = undefined;
        method = 'npub';
      }
    } catch {
      nsec = undefined;
      method = 'npub';
    }
  }

  return buildAccount(candidate.pubkey, method, {
    nsec,
    isPristineDefault: typeof candidate.isPristineDefault === 'boolean'
      ? candidate.isPristineDefault
      : undefined,
    createdAt: typeof candidate.createdAt === 'number' ? candidate.createdAt : undefined,
    updatedAt: typeof candidate.updatedAt === 'number' ? candidate.updatedAt : undefined,
    profile: candidate.profile,
  });
}

function saveAccountsToStorage(accounts: SocialAccount[]): void {
  if (typeof localStorage === 'undefined') {
    return;
  }
  try {
    localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
  } catch {
    // Account state remains usable for this session when browser storage is denied.
  }
}

export function loadAccountsFromStorage(): SocialAccount[] {
  if (typeof localStorage === 'undefined') {
    return [];
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY_ACCOUNTS);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw) as unknown[];
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed
      .map((entry) => validateStoredAccount(entry))
      .filter((entry): entry is SocialAccount => Boolean(entry));
  } catch {
    return [];
  }
}

export function getActiveAccountFromStorage(): string | null {
  if (typeof localStorage === 'undefined') {
    return null;
  }
  try {
    return localStorage.getItem(STORAGE_KEY_ACTIVE_ACCOUNT);
  } catch {
    return null;
  }
}

export function saveActiveAccountToStorage(pubkey: string | null): void {
  if (typeof localStorage === 'undefined') {
    return;
  }

  try {
    if (pubkey) {
      localStorage.setItem(STORAGE_KEY_ACTIVE_ACCOUNT, pubkey);
    } else {
      localStorage.removeItem(STORAGE_KEY_ACTIVE_ACCOUNT);
    }
  } catch {
    // Account state remains usable for this session when browser storage is denied.
  }
}

function dedupeAccounts(accounts: SocialAccount[]): SocialAccount[] {
  const byPubkey = new Map<string, SocialAccount>();
  for (const account of accounts) {
    byPubkey.set(account.pubkey, account);
  }

  return [...byPubkey.values()].sort((left, right) => left.createdAt - right.createdAt);
}

function createAccountsStore() {
  const { subscribe, update, set } = writable<AccountsState>({
    accounts: [],
    activeAccountPubkey: null,
    initialized: false,
  });

  return {
    subscribe,
    set,
    update,
    getState: (): AccountsState => get(accountsStore),
  };
}

export const accountsStore = createAccountsStore();

export function createFreshAccount(
  options: { isPristineDefault?: boolean } = {},
): SocialAccount {
  const secretKey = generateSecretKey();
  const nsec = nip19.nsecEncode(secretKey);
  const pubkey = getPublicKey(secretKey);
  return buildAccount(pubkey, 'generated', {
    nsec,
    isPristineDefault: options.isPristineDefault ?? false,
  });
}

function buildImportedAccount(
  pubkey: string,
  method: SocialAccountMethod,
  options: { nsec?: string } = {},
): SocialAccount {
  const previous =
    accountsStore.getState().accounts.find((account) => account.pubkey === pubkey.toLowerCase()) ?? null;

  return buildAccount(pubkey, method, {
    nsec: options.nsec,
    isPristineDefault: false,
    createdAt: previous?.createdAt,
    profile: previous?.profile,
  });
}

export function createAccountFromInput(input: string): SocialAccount | null {
  const trimmed = input.trim();
  if (!trimmed) {
    return null;
  }

  if (/^[0-9a-f]{64}$/i.test(trimmed)) {
    return buildImportedAccount(trimmed.toLowerCase(), 'npub');
  }

  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return buildImportedAccount(decoded.data, 'npub');
    }

    if (decoded.type === 'nsec') {
      const secretKey = decoded.data as Uint8Array;
      return buildImportedAccount(getPublicKey(secretKey), 'nsec', {
        nsec: nip19.nsecEncode(secretKey),
      });
    }
  } catch {
    return null;
  }

  return null;
}

/** Return the local signing key for an account, failing closed for read-only identities. */
export function getAccountSecretKey(account: SocialAccount): Uint8Array {
  if (!account.nsec) {
    throw new Error('This account is read-only.');
  }

  try {
    const decoded = nip19.decode(account.nsec);
    if (decoded.type !== 'nsec') {
      throw new Error('This account is read-only.');
    }
    const secretKey = decoded.data as Uint8Array;
    if (getPublicKey(secretKey) !== account.pubkey.toLowerCase()) {
      throw new Error('This account signing key does not match its identity.');
    }
    return secretKey;
  } catch (error) {
    if (
      error instanceof Error
      && (
        error.message === 'This account is read-only.'
        || error.message === 'This account signing key does not match its identity.'
      )
    ) {
      throw error;
    }
    throw new Error('This account is read-only.');
  }
}

export function upsertAccount(account: SocialAccount): void {
  accountsStore.update((state) => {
    const accounts = dedupeAccounts([
      ...state.accounts.filter((entry) => entry.pubkey !== account.pubkey),
      account,
    ]);
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

export function setActiveAccount(pubkey: string | null): void {
  saveActiveAccountToStorage(pubkey);
  accountsStore.update((state) => ({ ...state, activeAccountPubkey: pubkey }));
}

export function upsertAndActivateAccount(account: SocialAccount): void {
  upsertAccount(account);
  setActiveAccount(account.pubkey);
}

export function removeAccount(pubkey: string): boolean {
  const state = accountsStore.getState();
  if (state.accounts.length <= 1) {
    return false;
  }

  const accounts = state.accounts.filter((entry) => entry.pubkey !== pubkey);
  const nextActiveAccountPubkey =
    state.activeAccountPubkey === pubkey ? (accounts[0]?.pubkey ?? null) : state.activeAccountPubkey;

  saveAccountsToStorage(accounts);
  saveActiveAccountToStorage(nextActiveAccountPubkey);
  accountsStore.set({
    accounts,
    activeAccountPubkey: nextActiveAccountPubkey,
    initialized: true,
  });
  return true;
}

export function renameAccount(pubkey: string, name: string): void {
  const normalizedName = name.trim();
  if (!normalizedName) {
    return;
  }

  accountsStore.update((state) => {
    const accounts = state.accounts.map((account) =>
      account.pubkey === pubkey
        ? {
            ...account,
            isPristineDefault: false,
            updatedAt: Date.now(),
            profile: {
              ...account.profile,
              name: normalizedName,
            },
          }
        : account,
    );
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

/** The implicit first identity stops being anonymous as soon as it signs social state. */
export function markAccountUsed(pubkey: string): void {
  accountsStore.update((state) => {
    let changed = false;
    const accounts = state.accounts.map((account) => {
      if (account.pubkey !== pubkey || account.isPristineDefault !== true) {
        return account;
      }
      changed = true;
      return {
        ...account,
        isPristineDefault: false,
        updatedAt: Date.now(),
      };
    });
    if (!changed) {
      return state;
    }
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

export function initAccountsStore(): SocialAccount {
  let storedAccounts = dedupeAccounts(loadAccountsFromStorage());
  if (
    storedAccounts.length === 1
    && storedAccounts[0]?.method === 'generated'
    && storedAccounts[0].updatedAt === storedAccounts[0].createdAt
    && storedAccounts[0].isPristineDefault === undefined
  ) {
    storedAccounts = [{ ...storedAccounts[0], isPristineDefault: true }];
    saveAccountsToStorage(storedAccounts);
  }
  const storedActivePubkey = getActiveAccountFromStorage();
  const activeAccount =
    storedAccounts.find((account) => account.pubkey === storedActivePubkey) ?? storedAccounts[0] ?? null;

  if (activeAccount) {
    accountsStore.set({
      accounts: storedAccounts,
      activeAccountPubkey: activeAccount.pubkey,
      initialized: true,
    });
    saveActiveAccountToStorage(activeAccount.pubkey);
    return activeAccount;
  }

  const freshAccount = createFreshAccount({ isPristineDefault: true });
  saveAccountsToStorage([freshAccount]);
  saveActiveAccountToStorage(freshAccount.pubkey);
  accountsStore.set({
    accounts: [freshAccount],
    activeAccountPubkey: freshAccount.pubkey,
    initialized: true,
  });
  return freshAccount;
}
