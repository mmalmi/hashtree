import type { BrowserSignerSession } from '@iris/identity/browserSigner';
import { get, writable } from 'svelte/store';
import { generateSecretKey, getPublicKey } from 'nostr-tools/pure';
import * as nip19 from 'nostr-tools/nip19';
import { fallbackProfileNameForIdentity } from './nostr';

const STORAGE_KEY_ACCOUNTS = 'iris-social:accounts';
const STORAGE_KEY_ACTIVE_ACCOUNT = 'iris-social:active-account';

export type SocialAccountMethod = 'generated' | 'npub' | 'nsec' | 'nip07' | 'nip46';

export type SocialAccountProfile = {
  name: string;
};

export type SocialAccount = {
  pubkey: string;
  npub: string;
  method: SocialAccountMethod;
  remoteSigner?: BrowserSignerSession;
  isPristineDefault?: boolean;
  nsec?: string;
  createdAt: number;
  updatedAt: number;
  profile: SocialAccountProfile;
};

type StoredSocialAccount = Partial<SocialAccount> & {
  profile?: Partial<SocialAccountProfile>;
};

type AccountsState = {
  accounts: SocialAccount[];
  activeAccountPubkey: string | null;
  initialized: boolean;
};

function normalizeMethod(value: unknown): SocialAccountMethod {
  return value === 'npub' || value === 'nsec' || value === 'nip07' || value === 'nip46' ? value : 'generated';
}

function buildAccount(
  pubkey: string,
  method: SocialAccountMethod,
  options: {
    nsec?: string;
    remoteSigner?: BrowserSignerSession;
    isPristineDefault?: boolean;
    createdAt?: number;
    updatedAt?: number;
    profile?: Partial<SocialAccountProfile>;
  } = {},
): SocialAccount {
  const normalizedPubkey = pubkey.toLowerCase();
  const createdAt = options.createdAt ?? Date.now();
  const updatedAt = options.updatedAt ?? createdAt;

  return {
    pubkey: normalizedPubkey,
    npub: nip19.npubEncode(normalizedPubkey),
    method,
    isPristineDefault: options.isPristineDefault,
    nsec: options.nsec,
    remoteSigner: options.remoteSigner,
    createdAt,
    updatedAt,
    profile: {
      name: options.profile?.name?.trim() || fallbackProfileNameForIdentity(normalizedPubkey),
    },
  };
}

function validateStoredAccount(value: unknown): SocialAccount | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const candidate = value as StoredSocialAccount;
  if (typeof candidate.pubkey !== 'string' || !/^[0-9a-f]{64}$/i.test(candidate.pubkey)) {
    return null;
  }

  const storedNsec = typeof candidate.nsec === 'string' ? candidate.nsec : undefined;
  let method = normalizeMethod(candidate.method);
  const external = method === 'nip07' || method === 'nip46';
  const remoteSigner = method === 'nip46' && candidate.remoteSigner?.pubkey === candidate.pubkey.toLowerCase()
    && typeof candidate.remoteSigner.connection === 'string' && typeof candidate.remoteSigner.clientKey === 'string'
    ? candidate.remoteSigner : undefined;
  if (method === 'nip46' && !remoteSigner) {method = 'npub';}
  let nsec = external ? undefined : storedNsec;
  if (storedNsec && !external) {
    try {
      const decoded = nip19.decode(storedNsec);
      if (
        decoded.type !== 'nsec'
        || getPublicKey(decoded.data as Uint8Array) !== candidate.pubkey.toLowerCase()
      ) {
        nsec = undefined;
        method = 'npub';
      }
    } catch {
      nsec = undefined;
      method = 'npub';
    }
  }

  return buildAccount(candidate.pubkey, method, {
    nsec,
    remoteSigner,
    isPristineDefault: typeof candidate.isPristineDefault === 'boolean'
      ? candidate.isPristineDefault
      : undefined,
    createdAt: typeof candidate.createdAt === 'number' ? candidate.createdAt : undefined,
    updatedAt: typeof candidate.updatedAt === 'number' ? candidate.updatedAt : undefined,
    profile: candidate.profile,
  });
}

function saveAccountsToStorage(accounts: SocialAccount[]): boolean {
  try {
    if (typeof localStorage === 'undefined') {return false;}
    localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
    return true;
  } catch {
    return false;
  }
}

function readStoredAccounts(): SocialAccount[] | null {
  try {
    const raw = typeof localStorage === 'undefined' ? null : localStorage.getItem(STORAGE_KEY_ACCOUNTS);
    if (raw === null) {return null;}
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {return null;}
    return parsed
      .map((entry) => validateStoredAccount(entry))
      .filter((entry): entry is SocialAccount => Boolean(entry));
  } catch {
    return null;
  }
}

export function loadAccountsFromStorage(): SocialAccount[] {
  return readStoredAccounts() ?? [];
}

export function getActiveAccountFromStorage(): string | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage.getItem(STORAGE_KEY_ACTIVE_ACCOUNT);
  } catch {
    return null;
  }
}

export function saveActiveAccountToStorage(pubkey: string | null): void {
  try {
    if (typeof localStorage === 'undefined') { return; }
    if (pubkey) {
      localStorage.setItem(STORAGE_KEY_ACTIVE_ACCOUNT, pubkey);
    } else {
      localStorage.removeItem(STORAGE_KEY_ACTIVE_ACCOUNT);
    }
  } catch {
    // Account state remains usable for this session when browser storage is denied.
  }
}

function dedupeAccounts(accounts: SocialAccount[]): SocialAccount[] {
  const byPubkey = new Map<string, SocialAccount>();
  for (const account of accounts) {
    byPubkey.set(account.pubkey, account);
  }

  return [...byPubkey.values()].sort((left, right) => left.createdAt - right.createdAt);
}

function createAccountsStore() {
  const { subscribe, update, set } = writable<AccountsState>({
    accounts: [],
    activeAccountPubkey: null,
    initialized: false,
  });

  return {
    subscribe,
    set,
    update,
    getState: (): AccountsState => get(accountsStore),
  };
}

export const accountsStore = createAccountsStore();

export function createFreshAccount({ name }: { name?: string } = {}): SocialAccount {
  const secretKey = generateSecretKey();
  const nsec = nip19.nsecEncode(secretKey);
  const pubkey = getPublicKey(secretKey);
  return buildAccount(pubkey, 'generated', {
    nsec,
    isPristineDefault: false,
    profile: { name },
  });
}

function buildImportedAccount(
  pubkey: string,
  method: SocialAccountMethod,
  options: { nsec?: string; remoteSigner?: BrowserSignerSession } = {},
): SocialAccount {
  const previous =
    accountsStore.getState().accounts.find((account) => account.pubkey === pubkey.toLowerCase()) ?? null;

  return buildAccount(pubkey, method, {
    nsec: options.nsec,
    remoteSigner: options.remoteSigner,
    isPristineDefault: false,
    createdAt: previous?.createdAt,
    profile: previous?.profile,
  });
}

export function createRemoteAccount(session: BrowserSignerSession): SocialAccount {
  return buildImportedAccount(session.pubkey, 'nip46', { remoteSigner: session });
}

export function usesExternalSigner(account: SocialAccount): boolean {
  return account.method === 'nip07' || account.method === 'nip46';
}

export function createAccountFromInput(input: string): SocialAccount | null {
  const trimmed = input.trim();
  if (!trimmed) {
    return null;
  }

  if (/^[0-9a-f]{64}$/i.test(trimmed)) {
    return buildImportedAccount(trimmed.toLowerCase(), 'npub');
  }

  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return buildImportedAccount(decoded.data, 'npub');
    }

    if (decoded.type === 'nsec') {
      const secretKey = decoded.data as Uint8Array;
      return buildImportedAccount(getPublicKey(secretKey), 'nsec', {
        nsec: nip19.nsecEncode(secretKey),
      });
    }
  } catch {
    return null;
  }

  return null;
}

/** Return the local signing key for an account, failing closed for read-only identities. */
export function getAccountSecretKey(account: SocialAccount): Uint8Array {
  if (!account.nsec) {
    throw new Error('This profile is read-only.');
  }

  try {
    const decoded = nip19.decode(account.nsec);
    if (decoded.type !== 'nsec') {
      throw new Error('This profile is read-only.');
    }
    const secretKey = decoded.data as Uint8Array;
    if (getPublicKey(secretKey) !== account.pubkey.toLowerCase()) {
      throw new Error('The signing key does not match this profile.');
    }
    return secretKey;
  } catch (error) {
    if (
      error instanceof Error
      && (
        error.message === 'This profile is read-only.'
        || error.message === 'The signing key does not match this profile.'
      )
    ) {
      throw error;
    }
    throw new Error('This profile is read-only.');
  }
}

export function upsertAccount(account: SocialAccount): void {
  accountsStore.update((state) => {
    const accounts = dedupeAccounts([
      ...(readStoredAccounts() ?? state.accounts).filter((entry) => entry.pubkey !== account.pubkey),
      account,
    ]);
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

export function setActiveAccount(pubkey: string | null): void {
  if (pubkey) { markAccountUsed(pubkey); }
  saveActiveAccountToStorage(pubkey);
  accountsStore.update((state) => ({ ...state, activeAccountPubkey: pubkey }));
}

export function upsertAndActivateAccount(account: SocialAccount): void {
  upsertAccount(account);
  setActiveAccount(account.pubkey);
}

export function isParkedDefaultAccount(account: SocialAccount): boolean {
  return account.isPristineDefault === true;
}

function retainedActiveAccount(accounts: SocialAccount[], current: string | null): string | null {
  if (!current) { return null; }
  return accounts.some((account) => account.pubkey === current && !isParkedDefaultAccount(account))
    ? current : accounts.find((account) => !isParkedDefaultAccount(account))?.pubkey ?? null;
}

export function removeAccount(pubkey: string): boolean {
  const state = accountsStore.getState();
  const latest = readStoredAccounts() ?? state.accounts;
  const accounts = latest.filter((account) => account.pubkey !== pubkey);

  if (accounts.length === latest.length && !state.accounts.some((account) => account.pubkey === pubkey)) {
    return false;
  }
  if (!saveAccountsToStorage(accounts)) {
    throw new Error('Could not remove this profile from browser storage.');
  }

  const activeAccountPubkey = retainedActiveAccount(accounts, state.activeAccountPubkey);
  saveActiveAccountToStorage(retainedActiveAccount(accounts, getActiveAccountFromStorage()));
  accountsStore.set({ accounts, activeAccountPubkey, initialized: true });
  return true;
}

export function syncStoredAccounts(event: StorageEvent): boolean {
  if (event.key !== STORAGE_KEY_ACCOUNTS || event.storageArea !== window.localStorage) {return false;}

  const current = readStoredAccounts();
  if (current === null) {return false;}
  const state = accountsStore.getState();
  const accounts = dedupeAccounts(current);
  const activeAccountPubkey = retainedActiveAccount(accounts, state.activeAccountPubkey);
  accountsStore.set({ ...state, accounts, activeAccountPubkey });
  return activeAccountPubkey !== state.activeAccountPubkey;
}

export function renameAccount(pubkey: string, name: string): void {
  const normalizedName = name.trim();
  if (!normalizedName) {
    return;
  }

  accountsStore.update((state) => {
    const accounts = (readStoredAccounts() ?? state.accounts).map((account) =>
      account.pubkey === pubkey
        ? {
            ...account,
            isPristineDefault: false,
            updatedAt: Date.now(),
            profile: {
              ...account.profile,
              name: normalizedName,
            },
          }
        : account,
    );
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

/** Record explicit selection or signing for legacy accounts that may still be pristine. */
export function markAccountUsed(pubkey: string): void {
  accountsStore.update((state) => {
    const needsUsageMark = (account: SocialAccount): boolean => account.pubkey === pubkey && (
      isParkedDefaultAccount(account) || (account.method === 'generated' && account.isPristineDefault === undefined)
    );
    if (!state.accounts.some(needsUsageMark)) {
      return state;
    }
    let changed = false;
    const accounts = (readStoredAccounts() ?? state.accounts).map((account) => {
      if (!needsUsageMark(account)) {
        return account;
      }
      changed = true;
      return {
        ...account,
        isPristineDefault: false,
        updatedAt: Date.now(),
      };
    });
    if (!changed) {
      return state;
    }
    saveAccountsToStorage(accounts);
    return { ...state, accounts };
  });
}

export function initAccountsStore(): SocialAccount | null {
  const accounts = dedupeAccounts(loadAccountsFromStorage());
  const storedActivePubkey = getActiveAccountFromStorage();
  // Keep the old key recoverable from the saved profile list after signing out.
  // Untagged older keys may have been generated by an intentional sign-up.
  const activeAccount = accounts.find((account) => (
    account.pubkey === storedActivePubkey?.toLowerCase() && !isParkedDefaultAccount(account)
  )) ?? null;
  if (storedActivePubkey && !activeAccount) {
    saveActiveAccountToStorage(null);
  }
  accountsStore.set({
    accounts,
    activeAccountPubkey: activeAccount?.pubkey ?? null,
    initialized: true,
  });
  return activeAccount;
}
