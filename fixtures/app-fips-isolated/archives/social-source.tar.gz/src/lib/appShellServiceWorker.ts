type AppShellWorker = {
  postMessage(message: unknown): void;
};

type AppShellWorkerRegistration = {
  installing: AppShellWorker | null;
  waiting: AppShellWorker | null;
  update(): Promise<unknown>;
};

type AppShellWorkerContainer = {
  register(
    scriptURL: string,
    options?: RegistrationOptions,
  ): Promise<AppShellWorkerRegistration>;
};

export type AppShellServiceWorkerOptions = {
  baseURL?: string;
  isSecureContext?: boolean;
  serviceWorker?: AppShellWorkerContainer;
};

function browserEnvironment(): AppShellServiceWorkerOptions {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') {
    return {};
  }
  return {
    baseURL: document.baseURI,
    isSecureContext: window.isSecureContext,
    serviceWorker: navigator.serviceWorker,
  };
}

/** Registers repeat-load caching without delaying application startup. */
export async function registerAppShellServiceWorker(
  overrides: AppShellServiceWorkerOptions = {},
): Promise<AppShellWorkerRegistration | undefined> {
  const environment = { ...browserEnvironment(), ...overrides };
  if (!environment.isSecureContext || !environment.baseURL || !environment.serviceWorker) {
    return undefined;
  }

  const scriptURL = new URL('service-worker.js', environment.baseURL).href;
  const scope = new URL('./', environment.baseURL).href;

  try {
    const registration = await environment.serviceWorker.register(scriptURL, {
      scope,
      updateViaCache: 'none',
    });

    // register() already starts a fresh installation. Explicitly check existing
    // registrations so a new app shell takes over on this visit, not tomorrow.
    if (!registration.installing) {
      try {
        await registration.update();
      } catch (error) {
        console.warn('Failed to update the app shell service worker', error);
      }
    }
    registration.waiting?.postMessage({ type: 'SKIP_WAITING' });
    return registration;
  } catch (error) {
    console.warn('Failed to register the app shell service worker', error);
    return undefined;
  }
}
