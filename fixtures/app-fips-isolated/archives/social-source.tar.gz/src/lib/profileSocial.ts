import type { CID } from '@hashtree/core';
import { awaitWithin } from './feedIndexTiming';
import { extractFollowPubkeys, type ProfileRecord, type RawEvent } from './nostr';
import { loadIndexedProfiles } from './profileIndex';
import { loadProfileIndexedContacts } from './profileIndexedContacts';
import {
  throwIfProfileLoadAborted,
  withProfileLoadAbort,
} from './profileLoadAbort';
import {
  applySocialGraphMetricsToProfileMap,
  loadSocialGraphProfileSocial,
} from './socialGraph';
import { loadSnapshotSocialGraphProfileSocial } from './socialGraphProfileSnapshot';
import { isSocialRelationshipCatalogConfigured } from './config';
import type { IndexedProfileRelationships } from './socialRelationshipRuntime';

const PROFILE_SOCIAL_LOOKUP_GRACE_MS = 4_000;

export type ProfileSocialSnapshot = {
  rootNhash: string;
  contactsEvent: RawEvent | null;
  follows: string[];
  followsCount: number | null;
  followers: string[];
  followersCount: number | null;
  profiles: Map<string, ProfileRecord>;
  followersTruncated: boolean;
  hasFollows: boolean;
  hasFollowers: boolean;
};

export type ProfileSocialOptions = {
  followerLimit?: number;
  /** Cached graph IDs only; profile records remain limited by the visible page. */
  snapshotFollowerLimit?: number;
  includeProfiles?: boolean;
  includeFollows?: boolean;
  includeFollowers?: boolean;
  onProgress?: (snapshot: ProfileSocialSnapshot) => void;
  signal?: AbortSignal;
};

type ProfileSocialReader = {
  getLatestEventByAuthorKind: (pubkey: string, kind: number) => Promise<RawEvent | null>;
  streamSocialGraphEvents: () => AsyncIterable<RawEvent>;
};

export type ProfileSocialLoaderDeps = {
  getReaderForRoot: (root: CID) => ProfileSocialReader;
  getRootNhash: (root: CID) => string;
  loadLatestContactsEvent: (
    roots: CID[],
    pubkey: string,
    signal?: AbortSignal,
  ) => Promise<RawEvent | null>;
  resolvePersonalRoot: (pubkey: string) => Promise<CID | null>;
  loadSocialGraphProfileSocial?: typeof loadSocialGraphProfileSocial;
  isSocialRelationshipCatalogConfigured?: () => boolean;
  loadIndexedProfileRelationships?: (
    root: CID,
    pubkey: string,
    options: {
      followerLimit: number;
      followLimit?: number;
      includeFollows?: boolean;
      includeFollowers?: boolean;
    },
  ) => Promise<IndexedProfileRelationships | null>;
};

export async function loadProfileSocialFromIndexes(
  root: CID,
  pubkey: string,
  options: ProfileSocialOptions = {},
  deps: ProfileSocialLoaderDeps,
): Promise<ProfileSocialSnapshot> {
  throwIfProfileLoadAborted(options.signal);
  const reader = deps.getReaderForRoot(root);
  const normalizedPubkey = pubkey.trim().toLowerCase();
  const followerLimit = Math.max(Math.trunc(options.followerLimit ?? 120), 1);
  const snapshotFollowerLimit = Math.min(65_536, Math.max(
    followerLimit,
    Math.trunc(options.snapshotFollowerLimit ?? followerLimit),
  ));
  const relationshipConfigured = (
    deps.isSocialRelationshipCatalogConfigured
    ?? isSocialRelationshipCatalogConfigured
  )();
  const followerResultLimit = relationshipConfigured ? followerLimit : snapshotFollowerLimit;
  let latestIndexedContactsEvent: RawEvent | null = null;
  let latestSocialGraph: Awaited<ReturnType<typeof loadSocialGraphProfileSocial>> = null;

  const buildSnapshot = (
    profiles: Map<string, ProfileRecord>,
    complete: boolean,
  ): ProfileSocialSnapshot => {
    const indexedFollows = extractFollowPubkeys(latestIndexedContactsEvent);
    const availableFollows = options.includeFollows === false
      ? []
      : latestIndexedContactsEvent
        ? indexedFollows
        : latestSocialGraph?.follows ?? [];
    const follows = availableFollows.slice(0, followerLimit);
    const followsCount = options.includeFollows === false
      ? null
      : latestIndexedContactsEvent
        ? indexedFollows.length
        : latestSocialGraph?.followsCount ?? (complete ? 0 : null);
    const availableFollowers = options.includeFollowers === false
      ? []
      : latestSocialGraph?.followers ?? [];
    const followers = availableFollowers.slice(0, followerResultLimit);
    const followersCount = options.includeFollowers === false
      ? null
      : latestSocialGraph?.followersCount ?? null;

    return {
      rootNhash: deps.getRootNhash(root),
      contactsEvent: latestIndexedContactsEvent,
      follows,
      followsCount,
      followers,
      followersCount,
      profiles,
      followersTruncated: options.includeFollowers !== false
        && (followersCount ?? followers.length) > followers.length,
      hasFollows: options.includeFollows !== false
        && (complete || Boolean(latestIndexedContactsEvent || latestSocialGraph)),
      hasFollowers: options.includeFollowers !== false
        && (complete || Boolean(latestSocialGraph)),
    };
  };
  const emitProgress = (): void => {
    if (!options.signal?.aborted) {
      options.onProgress?.(buildSnapshot(new Map(), false));
    }
  };

  const indexedContactsPromise = options.includeFollows === false
    ? Promise.resolve(null)
    : loadProfileIndexedContacts(root, normalizedPubkey, {
        ...deps,
        signal: options.signal,
      }, (event) => {
        latestIndexedContactsEvent = event;
        emitProgress();
      });
  const socialGraphPromise = options.includeFollows === false && options.includeFollowers === false
    ? Promise.resolve(null)
    : (relationshipConfigured
      ? (deps.loadIndexedProfileRelationships ?? loadIndexedRelationshipsLazily)(root, normalizedPubkey, {
          followerLimit,
          followLimit: followerLimit,
          includeFollows: options.includeFollows,
          includeFollowers: options.includeFollowers,
        })
      : deps.loadSocialGraphProfileSocial
        ? deps.loadSocialGraphProfileSocial(
            deps.getRootNhash(root),
            () => reader.streamSocialGraphEvents(),
            normalizedPubkey,
            snapshotFollowerLimit,
          )
        : loadSnapshotSocialGraphProfileSocial(
            normalizedPubkey,
            snapshotFollowerLimit,
            options.signal,
          )).then((socialGraph) => {
        latestSocialGraph = socialGraph;
        if (socialGraph) {
          emitProgress();
        }
        return socialGraph;
      }).catch((error) => {
        console.warn('Failed to load profile social graph', error);
        return null;
      });

  const [contactsResult, socialGraphResult] = await withProfileLoadAbort(
    Promise.all([
      awaitWithin(indexedContactsPromise, PROFILE_SOCIAL_LOOKUP_GRACE_MS),
      awaitWithin(socialGraphPromise, PROFILE_SOCIAL_LOOKUP_GRACE_MS),
    ]),
    options.signal,
  );
  if (contactsResult.settled) {
    latestIndexedContactsEvent = contactsResult.value;
  }
  if (socialGraphResult.settled) {
    latestSocialGraph = socialGraphResult.value;
  }
  const baseSnapshot = buildSnapshot(new Map(), true);
  const profiles = options.includeProfiles === false
    ? new Map<string, ProfileRecord>()
    : applySocialGraphMetricsToProfileMap(await loadIndexedProfiles([
        normalizedPubkey,
        ...baseSnapshot.follows,
        ...baseSnapshot.followers,
      ], { signal: options.signal }));

  throwIfProfileLoadAborted(options.signal);
  return {
    ...baseSnapshot,
    profiles,
  };
}

async function loadIndexedRelationshipsLazily(
  root: CID,
  pubkey: string,
  options: {
    followerLimit: number;
    followLimit?: number;
    includeFollows?: boolean;
    includeFollowers?: boolean;
  },
): Promise<IndexedProfileRelationships | null> {
  const { loadIndexedProfileRelationships } = await import('./socialRelationshipRuntime');
  return await loadIndexedProfileRelationships(root, pubkey, options);
}
