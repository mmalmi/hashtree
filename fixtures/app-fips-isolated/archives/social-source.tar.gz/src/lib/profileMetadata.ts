import { finalizeEvent, verifyEvent, type EventTemplate } from 'nostr-tools/pure';
import { signAccountEvent } from './accountSigner';
import { getAccountSecretKey, type SocialAccount } from './accounts';
import type { ProfileRecord, RawEvent } from './nostr';
import { isNewerReplaceableEvent } from './socialRepository';

export const PROFILE_METADATA_KIND = 0;

/**
 * Fields supported by Iris' bounded profile editor. Picture, banner, and
 * website are URL text fields; binary/file uploads live outside this core.
 */
export type EditableProfileFields = {
  displayName: string;
  about: string;
  website: string;
  picture: string;
  banner: string;
  lud16: string;
  nip05: string;
};

export type ParsedEditableProfileMetadata = {
  fields: EditableProfileFields;
  metadata: Readonly<Record<string, unknown>>;
};

const FIELD_KEYS = {
  displayName: 'display_name',
  about: 'about',
  website: 'website',
  picture: 'picture',
  banner: 'banner',
  lud16: 'lud16',
  nip05: 'nip05',
} as const satisfies Record<keyof EditableProfileFields, string>;

const EMPTY_FIELDS: EditableProfileFields = {
  displayName: '',
  about: '',
  website: '',
  picture: '',
  banner: '',
  lud16: '',
  nip05: '',
};

function normalizeHexPubkey(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }

  const normalized = value.trim().toLowerCase();
  return /^[0-9a-f]{64}$/.test(normalized) ? normalized : null;
}

function cloneEventForVerification(event: RawEvent): RawEvent {
  return {
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags.map((tag) => [...tag]),
    content: event.content,
    sig: event.sig,
  };
}

function isVerifiedProfileMetadataEvent(event: RawEvent, authorPubkey: string): boolean {
  if (!isProfileMetadataEventForAuthor(event, authorPubkey)) {
    return false;
  }

  try {
    // Verify a plain clone so a mutated object cannot retain nostr-tools'
    // cached verification marker from its previously signed payload.
    return verifyEvent(cloneEventForVerification(event));
  } catch {
    return false;
  }
}

function isProfileMetadataEventForAuthor(event: RawEvent, authorPubkey: string): boolean {
  return event.kind === PROFILE_METADATA_KIND && event.pubkey === authorPubkey;
}

function selectNewestProfileMetadataEventWhere(
  events: Iterable<RawEvent | null | undefined>,
  authorPubkey: string,
  accepts: (event: RawEvent, authorPubkey: string) => boolean,
): RawEvent | null {
  const normalizedAuthor = normalizeHexPubkey(authorPubkey);
  if (!normalizedAuthor) {
    return null;
  }

  let winner: RawEvent | null = null;
  for (const event of events) {
    if (!event || !accepts(event, normalizedAuthor)) {
      continue;
    }
    if (!winner || isNewerReplaceableEvent(event, winner)) {
      winner = event;
    }
  }
  return winner;
}

/** Select the author's valid NIP-01 profile winner. */
export function selectNewestProfileMetadataEvent(
  events: Iterable<RawEvent | null | undefined>,
  authorPubkey: string,
): RawEvent | null {
  return selectNewestProfileMetadataEventWhere(
    events,
    authorPubkey,
    isVerifiedProfileMetadataEvent,
  );
}

/**
 * Select from events already admitted by the social worker or locally signed.
 * This must only be used after that trust boundary; it deliberately performs
 * no renderer-thread signature work.
 */
export function selectNewestAdmittedProfileMetadataEvent(
  events: Iterable<RawEvent | null | undefined>,
  authorPubkey: string,
): RawEvent | null {
  return selectNewestProfileMetadataEventWhere(
    events,
    authorPubkey,
    isProfileMetadataEventForAuthor,
  );
}

/**
 * True when a parsed profile proves that a newer raw base exists but that raw
 * event has not been loaded. Editing must stop here to avoid erasing fields
 * Iris cannot preserve.
 */
export function isKnownProfileMetadataBaseUnavailable(
  profile: Pick<ProfileRecord, 'eventId' | 'createdAt'> | null | undefined,
  loadedEvent: RawEvent | null | undefined,
): boolean {
  if (!profile?.eventId) {
    return false;
  }
  if (!loadedEvent) {
    return true;
  }
  if (profile.eventId === loadedEvent.id) {
    return false;
  }
  if (profile.createdAt === null) {
    return true;
  }
  return profile.createdAt > loadedEvent.created_at
    || (
      profile.createdAt === loadedEvent.created_at
      && profile.eventId.localeCompare(loadedEvent.id) < 0
    );
}

function parseMetadataObject(content: string): Record<string, unknown> | null {
  try {
    const parsed: unknown = JSON.parse(content);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return null;
    }
    return parsed as Record<string, unknown>;
  } catch {
    return null;
  }
}

/**
 * Parse editable fields while retaining the full object for lossless updates.
 * Malformed JSON and non-object JSON fail closed instead of becoming `{}`.
 */
export function parseEditableProfileMetadata(
  content: string,
): ParsedEditableProfileMetadata | null {
  const metadata = parseMetadataObject(content);
  if (!metadata) {
    return null;
  }

  const fields = { ...EMPTY_FIELDS };
  for (const [field, key] of Object.entries(FIELD_KEYS) as Array<
    [keyof EditableProfileFields, string]
  >) {
    const value = metadata[key];
    if (typeof value === 'string') {
      fields[field] = value;
    }
  }

  return { fields, metadata };
}

/**
 * Apply string-only edits to a metadata object. Missing edit fields and all
 * non-editor metadata are preserved verbatim at the JSON-value level.
 */
export function buildProfileMetadataContent(
  baseContent: string | null | undefined,
  edits: Partial<EditableProfileFields>,
): string {
  const metadata = baseContent === null || baseContent === undefined
    ? {}
    : parseMetadataObject(baseContent);
  if (!metadata) {
    throw new Error('Cannot edit malformed or non-object profile metadata.');
  }

  const updated: Record<string, unknown> = { ...metadata };
  for (const [field, key] of Object.entries(FIELD_KEYS) as Array<
    [keyof EditableProfileFields, string]
  >) {
    const value = edits[field];
    if (value === undefined) {
      continue;
    }
    if (typeof value !== 'string') {
      throw new Error(`Profile field ${field} must be text.`);
    }
    updated[key] = value;
  }

  return JSON.stringify(updated);
}

/** Build and sign a kind-0 event without performing storage or network I/O. */
function buildProfileMetadataDraft(
  account: SocialAccount,
  edits: Partial<EditableProfileFields>,
  options: {
    baseEvent?: RawEvent | null;
    now?: number;
  } = {},
): EventTemplate {
  const normalizedAuthor = normalizeHexPubkey(account.pubkey);
  if (!normalizedAuthor) {
    throw new Error('Account has an invalid public key.');
  }

  let baseEvent: RawEvent | null = null;
  if (options.baseEvent) {
    baseEvent = selectNewestProfileMetadataEvent([options.baseEvent], normalizedAuthor);
    if (!baseEvent) {
      throw new Error('Base profile metadata event is not valid for this account.');
    }
  }

  const now = options.now ?? Math.floor(Date.now() / 1_000);
  if (!Number.isSafeInteger(now) || now < 0) {
    throw new Error('Profile metadata timestamp must be a non-negative integer.');
  }

  return {
    kind: PROFILE_METADATA_KIND,
    content: buildProfileMetadataContent(baseEvent?.content, edits),
    tags: baseEvent?.tags.map((tag) => [...tag]) ?? [],
    created_at: Math.max(now, (baseEvent?.created_at ?? -1) + 1),
  };
}

export function createProfileMetadataEvent(
  account: SocialAccount,
  edits: Partial<EditableProfileFields>,
  options: {
    baseEvent?: RawEvent | null;
    now?: number;
  } = {},
): RawEvent {
  return finalizeEvent(buildProfileMetadataDraft(account, edits, options), getAccountSecretKey(account));
}

export async function createProfileMetadataEventAsync(
  account: SocialAccount,
  edits: Partial<EditableProfileFields>,
  options: {
    baseEvent?: RawEvent | null;
    now?: number;
  } = {},
): Promise<RawEvent> {
  return signAccountEvent(account, buildProfileMetadataDraft(account, edits, options));
}
