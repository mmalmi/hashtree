import type { EventTemplate } from 'nostr-tools/pure';
import { signAccountEvent } from './accountSigner';
import { usesExternalSigner, type SocialAccount } from './accounts';
import type { RawEvent } from './nostr';

/** Background indexing must not repeatedly ask an extension for permission. */
export function createPersonalIndexSigner() {
  const permittedAccounts = new Set<string>();
  return {
    allowForPublication(account: SocialAccount): void {
      if (usesExternalSigner(account)) {permittedAccounts.add(account.pubkey);}
    },
    async sign(account: SocialAccount, draft: EventTemplate): Promise<RawEvent> {
      // Consume before awaiting approval. Startup and retries stay paused until
      // a new deliberate publication, including after a declined request.
      if (usesExternalSigner(account) && !permittedAccounts.delete(account.pubkey)) {
        throw new Error('Personal index signing is waiting for a new publication.');
      }
      return await signAccountEvent(account, draft);
    },
  };
}
