import type { FederatedPostSearchOptions } from './postSearchFederation';

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;
const DEFAULT_PER_SEGMENT_LIMIT = 64;
const MAX_PER_SEGMENT_LIMIT = 256;
const DEFAULT_MAX_PER_SEGMENT_LIMIT = 1_024;
const HARD_MAX_PER_SEGMENT_LIMIT = 4_096;
const DEFAULT_PUBLISHER_CONCURRENCY = 3;
const MAX_PUBLISHER_CONCURRENCY = 8;
const DEFAULT_SEGMENT_CONCURRENCY = 2;
const MAX_SEGMENT_CONCURRENCY = 4;
const DEFAULT_REQUEST_TIMEOUT_MS = 8_000;
const MIN_REQUEST_TIMEOUT_MS = 100;
const MAX_REQUEST_TIMEOUT_MS = 60_000;

export type NormalizedPostSearchOptions = {
  signal: AbortSignal | null;
  limit: number;
  operator: 'or' | 'and';
  authors: Set<string> | null;
  kinds: Set<number> | null;
  since: number | null;
  until: number | null;
  publisherConcurrency: number;
  segmentConcurrency: number;
  perSegmentLimit: number;
  maxPerSegmentLimit: number;
  requestTimeoutMs: number;
  onProgress: NonNullable<FederatedPostSearchOptions['onProgress']> | null;
};

export function normalizePostSearchOptions(
  options: FederatedPostSearchOptions,
): NormalizedPostSearchOptions {
  const limit = boundedInteger(options.limit, DEFAULT_LIMIT, 1, MAX_LIMIT);
  const since = optionalTimestamp(options.since, 'since');
  const until = optionalTimestamp(options.until, 'until');
  if (since !== null && until !== null && since > until) {
    throw new Error('Post search since must not be later than until');
  }
  const perSegmentLimit = Math.max(limit, boundedInteger(
    options.perSegmentLimit,
    DEFAULT_PER_SEGMENT_LIMIT,
    1,
    MAX_PER_SEGMENT_LIMIT,
  ));
  return {
    signal: options.signal ?? null,
    limit,
    operator: options.operator ?? 'or',
    authors: normalizedAuthors(options.authors),
    kinds: options.kinds?.length ? new Set(options.kinds) : null,
    since,
    until,
    publisherConcurrency: boundedInteger(
      options.publisherConcurrency,
      DEFAULT_PUBLISHER_CONCURRENCY,
      1,
      MAX_PUBLISHER_CONCURRENCY,
    ),
    segmentConcurrency: boundedInteger(
      options.segmentConcurrency,
      DEFAULT_SEGMENT_CONCURRENCY,
      1,
      MAX_SEGMENT_CONCURRENCY,
    ),
    perSegmentLimit,
    maxPerSegmentLimit: Math.max(perSegmentLimit, boundedInteger(
      options.maxPerSegmentLimit,
      DEFAULT_MAX_PER_SEGMENT_LIMIT,
      1,
      HARD_MAX_PER_SEGMENT_LIMIT,
    )),
    requestTimeoutMs: boundedInteger(
      options.requestTimeoutMs,
      DEFAULT_REQUEST_TIMEOUT_MS,
      MIN_REQUEST_TIMEOUT_MS,
      MAX_REQUEST_TIMEOUT_MS,
    ),
    onProgress: options.onProgress ?? null,
  };
}

function normalizedAuthors(authors: readonly string[] | undefined): Set<string> | null {
  if (!authors?.length) {
    return null;
  }
  return new Set(authors.map((author) => author.trim().toLowerCase()).filter(Boolean));
}

function optionalTimestamp(value: number | undefined, name: string): number | null {
  if (value === undefined) {
    return null;
  }
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`Invalid post search ${name}`);
  }
  return value;
}

function boundedInteger(
  value: number | undefined,
  fallback: number,
  min: number,
  max: number,
): number {
  if (value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  return Math.max(min, Math.min(max, Math.trunc(value)));
}
