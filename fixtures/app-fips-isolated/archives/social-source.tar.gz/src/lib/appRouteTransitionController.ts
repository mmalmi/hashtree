import { tick } from 'svelte';
import type { SocialAccount } from './accounts';
import type { FeedSnapshot } from './nostrIndex';
import type { ProfileRecord, RawEvent } from './nostr';
import {
  canonicalRoute,
  canonicalRouteHref,
  parseRouteLocation,
  routeKey,
  type Route,
} from './appRoute';
import {
  replaceRouteStackEntry,
  selectMountedRouteStackEntries,
  syncRouteStackEntries,
  trimRouteRenderCache,
  upsertRouteRenderCache,
  type MountedRouteRenderEntry,
  type RouteRenderCache,
  type RouteStackEntry,
} from './appStack';
import {
  findSiblingProfileCache,
  pruneRouteRenderCacheForScope,
  routeRenderCacheMatchesScope,
  routeRenderCacheHasVisibleContent,
  shouldReuseExactRouteStackView,
} from './appRouteState';
import { readHistoryScrollState, readStoredRouteScroll } from './appNavigation';
import { getPresentedRoute, setPresentedRoute } from './appRoutePresentation';
import { getAppScrollInteractionVersion } from './appScroll';
import type { createThreadReplyDraftStore } from './threadReplyDrafts';
import { waitForNextBrowserPaint } from './asyncTiming';
import { batchReactiveState } from './reactiveState';
import { filterProfileContentEvents, type ProfileContentSection } from './profileContent';

type ThreadReplyDraftStore = ReturnType<typeof createThreadReplyDraftStore>;

export function shouldApplyStagedProfilePaginationReset(options: {
  scheduledTransitionVersion: number;
  currentTransitionVersion: number;
  expectedRouteKey: string;
  currentRouteKey: string;
}): boolean {
  return options.scheduledTransitionVersion === options.currentTransitionVersion
    && options.expectedRouteKey === options.currentRouteKey;
}

type RouteTransitionDeps = {
  activeAccount: SocialAccount | null;
  activeFeedSourcePubkey: string | null;
  appHistoryIndex: number;
  allHomeNotes: RawEvent[];
  feed: FeedSnapshot | null;
  homeFeedSnapshotReadController: AbortController | null;
  homeNotes: RawEvent[];
  historyScrollPositions: Map<number, number>;
  mountedRenderEntries: MountedRouteRenderEntry[];
  navigationTriggeredByPopState: boolean;
  pendingScrollMode: 'top' | 'restore' | null;
  pendingScrollRestoreKey: string | null;
  pendingScrollRestoreOffset: number | null;
  rootNhash: string;
  route: Route;
  currentRouteCache: RouteRenderCache | null;
  routeRenderCache: Map<string, RouteRenderCache>;
  routeScrollPositions: Map<string, number>;
  routeStack: RouteStackEntry[];
  routeStackIndex: number;
  searchSheetOpen: boolean;
  viewerFollows: Set<string>;
  threadReplyDrafts: ThreadReplyDraftStore;
  applyPendingNavigationState: () => void;
  applySearchRoute: (route: Route) => void;
  cancelCurrentViewLoad: () => void;
  invalidateCurrentViewLoad: () => void;
  cancelPendingRouteScrollRestores: () => void;
  closeSearchSheet: (options?: { preserveQuery?: boolean }) => void;
  resetHomeFeedPagination: () => void;
  resetLiveHomeFeedBuffer: () => void;
  resetProfileFeedPagination: () => void;
  resetProfileSocialPagination: () => void;
  resetThreadReplyPagination: () => void;
  restartCurrentViewLoad: () => void;
  restorePresentedRouteScroll: (key: string, offset: number) => void;
  restoreHomeFeedSnapshot: (previousLatestFeed?: FeedSnapshot | null) => void;
  restoreLiveRouteState: (
    cache: RouteRenderCache,
    options?: {
      reuseReferences?: boolean;
      preserveProfileNotesLoading?: boolean;
    },
  ) => void;
  restoreThreadReplyDraft: (route: Route) => void;
  getSharedProfileRecord: (pubkey: string) => ProfileRecord | null;
  snapshotKnownProfileNotes: (pubkey: string) => RawEvent[];
  stripTransientQueryParams: () => void;
  warmSearchResources: () => void;
  loadAccountSheet: () => Promise<void>;
};

export function createAppRouteTransitionController(deps: RouteTransitionDeps) {
  let transitionVersion = 0;

  function findRetainedRenderEntry(nextRoute: Route): MountedRouteRenderEntry | null {
    const nextKey = routeKey(nextRoute);
    const candidate = deps.routeRenderCache.get(nextKey) ?? null;
    if (
      !candidate
      || !routeRenderCacheMatchesScope(candidate, {
        viewerPubkey: deps.activeAccount?.pubkey ?? null,
        homeFeedSourcePubkey: deps.activeFeedSourcePubkey,
      })
    ) {
      return null;
    }
    return deps.mountedRenderEntries.find((entry) => entry.key === nextKey) ?? null;
  }

  function touchRetainedRouteStack(nextRoute: Route): void {
    const nextStack = syncRouteStackEntries(
      deps.routeStack,
      deps.routeStackIndex,
      { key: routeKey(nextRoute), route: nextRoute },
    );
    // Reorder the existing array in place. This records rapid retained Back/
    // Forward touches for correct LRU eviction without publishing route state
    // or waking the mounted projection before the destination paints.
    deps.routeStack.splice(0, deps.routeStack.length, ...nextStack.entries);
    deps.routeStackIndex = nextStack.currentIndex;
  }

  function readRetainedScroll(nextKey: string, fromPopState: boolean): number {
    if (fromPopState) {
      return deps.historyScrollPositions.get(deps.appHistoryIndex)
        ?? readHistoryScrollState()
        ?? deps.routeScrollPositions.get(nextKey)
        ?? readStoredRouteScroll(nextKey)
        ?? 0;
    }
    return deps.routeScrollPositions.get(nextKey)
      ?? readStoredRouteScroll(nextKey)
      ?? 0;
  }

  function syncRouteStack(nextRoute: Route, replacedKey: string | null = null): void {
    const key = routeKey(nextRoute);
    const nextEntry = { key, route: nextRoute };
    const nextStack = replacedKey
      ? replaceRouteStackEntry(deps.routeStack, replacedKey, nextEntry)
      : syncRouteStackEntries(deps.routeStack, deps.routeStackIndex, nextEntry);
    deps.routeStack = nextStack.entries;
    deps.routeStackIndex = nextStack.currentIndex;
    deps.routeRenderCache = trimRouteRenderCache(deps.routeRenderCache, nextStack);

  }

  function applyCurrentRouteCache(nextEntry: RouteRenderCache): void {
    deps.routeRenderCache = upsertRouteRenderCache(
      deps.routeRenderCache,
      deps.routeStack,
      nextEntry,
    );
  }

  function createProfileIdentityCache(
    nextRoute: Extract<Route, { kind: 'profile' }>,
    source: RouteRenderCache,
  ): RouteRenderCache {
    const key = routeKey(nextRoute);
    const profilePubkey = nextRoute.pubkey;
    // Home, threads, search, and profile hydration all populate this one
    // canonical event cache. A profile route projects those same event objects
    // by author instead of copying content out of the route being left.
    const knownNotes = profilePubkey
      ? deps.snapshotKnownProfileNotes(profilePubkey)
      : [];
    const contentSection = (
      nextRoute.section === 'posts'
      || nextRoute.section === 'replies'
      || nextRoute.section === 'media'
    )
      ? nextRoute.section as ProfileContentSection
      : null;
    const knownProfile = profilePubkey
      ? deps.getSharedProfileRecord(profilePubkey)
      : null;
    return {
      ...source,
      key,
      route: nextRoute,
      rootNhash: deps.rootNhash,
      viewerPubkey: deps.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: deps.activeFeedSourcePubkey,
      loading: true,
      feedRequiresRefresh: false,
      feed: null,
      profiles: knownProfile && profilePubkey
        ? new Map([[profilePubkey, knownProfile]])
        : new Map(),
      noteEngagements: new Map(),
      homeNotes: [],
      homeFeedHasMore: false,
      homeFeedLoadPending: false,
      notifications: [],
      notificationsLoading: false,
      notificationsHasMore: false,
      notificationsLoadPending: false,
      profilePage: {
        rootNhash: deps.rootNhash,
        profile: knownProfile,
        // Durable pagination owns this list; already-known authored events are
        // projected independently from the canonical event cache below.
        notes: [],
      },
      profileSocial: null,
      profileSocialLoading: true,
      profileSocialLoadPending: false,
      profileNotesLoading: true,
      profileNotes: contentSection
        ? filterProfileContentEvents(knownNotes, contentSection).slice(0, 1)
        : [],
      profilePostCountLabel: '...',
      profileReplyCountLabel: '...',
      profileMediaCountLabel: '...',
      profileLikesCountLabel: '...',
      profileFeedHasMore: false,
      profileFeedLoadPending: false,
      profileNoteLimit: 1,
      currentFollows: [],
      currentFollowers: [],
      followsCountLabel: '...',
      followerCountLabel: '...',
      profilePersonalRoot: null,
      threadPage: null,
      threadLoading: false,
      threadPersonalRoot: null,
      threadRoots: [],
      threadReplyCursor: null,
      threadReplies: [],
      threadDurableRepliesHasMore: false,
      threadRepliesHasMore: false,
      threadRepliesLoadPending: false,
    };
  }

  function replaceNonCanonicalIdentifierRoute(nextRoute: Route): Route {
    if (nextRoute.kind !== 'thread' && nextRoute.kind !== 'profile') {
      return nextRoute;
    }
    const canonicalHref = canonicalRouteHref(nextRoute);
    const currentHref = `${window.location.pathname}${window.location.hash}`;
    if (currentHref !== canonicalHref) {
      window.history.replaceState(
        window.history.state,
        '',
        `${canonicalHref}${window.location.search}`,
      );
    }
    return canonicalRoute(nextRoute);
  }

  function updateRoute(
    replacedKey: string | null = null,
    options: { preserveRetainedScroll?: boolean; reusePresentedRetainedView?: boolean } = {},
  ): void {
    if (!options.preserveRetainedScroll) {
      deps.cancelPendingRouteScrollRestores();
    }
    deps.stripTransientQueryParams();
    deps.routeRenderCache = pruneRouteRenderCacheForScope(deps.routeRenderCache, {
      viewerPubkey: deps.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: deps.activeFeedSourcePubkey,
    });
    const nextRoute = replaceNonCanonicalIdentifierRoute(
      parseRouteLocation(window.location.pathname, window.location.hash),
    );
    const previousLatestFeed = deps.route.kind === 'home'
      && deps.route.tab === 'latest'
      && !deps.activeFeedSourcePubkey
      ? deps.feed
      : null;
    const nextRouteKey = routeKey(nextRoute);
    const previousRouteKey = routeKey(deps.route);
    if (nextRouteKey !== previousRouteKey) {
      deps.homeFeedSnapshotReadController?.abort();
      deps.homeFeedSnapshotReadController = null;
      deps.resetLiveHomeFeedBuffer();
    }
    const routeExistsInStack = deps.routeStack.some((entry) => entry.key === nextRouteKey);
    const currentProfileIdentity = deps.route.kind === 'profile'
      ? deps.route.pubkey ?? deps.route.npub
      : null;
    const nextProfileIdentity = nextRoute.kind === 'profile'
      ? nextRoute.pubkey ?? nextRoute.npub
      : null;
    const identityCacheSource = nextRoute.kind === 'profile'
      && !routeExistsInStack
      && nextProfileIdentity !== currentProfileIdentity
      ? deps.routeRenderCache.get(previousRouteKey) ?? deps.currentRouteCache
      : null;
    if (options.preserveRetainedScroll) {
      deps.pendingScrollMode = null;
      deps.pendingScrollRestoreKey = null;
      deps.pendingScrollRestoreOffset = null;
    } else if (deps.pendingScrollMode !== 'top' && deps.navigationTriggeredByPopState) {
      deps.pendingScrollMode = 'restore';
      deps.pendingScrollRestoreKey = nextRouteKey;
      deps.pendingScrollRestoreOffset = deps.historyScrollPositions.get(deps.appHistoryIndex)
        ?? readHistoryScrollState()
        ?? deps.routeScrollPositions.get(nextRouteKey)
        ?? readStoredRouteScroll(nextRouteKey)
        ?? 0;
    } else if (deps.pendingScrollMode !== 'top' && routeExistsInStack) {
      deps.pendingScrollMode = 'restore';
      deps.pendingScrollRestoreKey = nextRouteKey;
      deps.pendingScrollRestoreOffset = deps.routeScrollPositions.get(nextRouteKey)
        ?? readStoredRouteScroll(nextRouteKey)
        ?? 0;
    } else if (deps.pendingScrollMode !== 'top') {
      deps.pendingScrollMode = 'top';
      deps.pendingScrollRestoreKey = null;
      deps.pendingScrollRestoreOffset = null;
    }
    deps.navigationTriggeredByPopState = false;
    if (deps.route.kind === 'search' && nextRoute.kind !== 'search') {
      deps.closeSearchSheet({ preserveQuery: true });
    }
    deps.route = nextRoute;
    syncRouteStack(nextRoute, replacedKey);
    if (nextRoute.kind === 'profile' && identityCacheSource) {
      applyCurrentRouteCache(createProfileIdentityCache(nextRoute, identityCacheSource));
    }
    deps.restoreThreadReplyDraft(nextRoute);
    const scope = {
      viewerPubkey: deps.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: deps.activeFeedSourcePubkey,
    };
    const cachedCandidate = deps.routeRenderCache.get(nextRouteKey) ?? null;
    const cachedRoute = cachedCandidate && routeRenderCacheMatchesScope(cachedCandidate, scope)
      ? cachedCandidate
      : null;
    if (nextRoute.kind === 'profile' && !cachedRoute) {
      deps.resetProfileSocialPagination();
    }
    if (nextRoute.kind === 'thread' && !cachedRoute) {
      deps.resetThreadReplyPagination();
    }
    if (cachedRoute) {
      deps.restoreLiveRouteState(cachedRoute, {
        reuseReferences: options.reusePresentedRetainedView,
        preserveProfileNotesLoading: cachedRoute.profileNotesLoading,
      });
    } else {
      const siblingCandidate = findSiblingProfileCache(
        deps.routeStack,
        deps.routeRenderCache,
        nextRoute,
      );
      const sibling = siblingCandidate && routeRenderCacheMatchesScope(siblingCandidate, scope)
        ? siblingCandidate
        : null;
      if (sibling) {
        deps.restoreLiveRouteState(sibling);
      } else if (nextRoute.kind === 'home' && nextRouteKey !== previousRouteKey) {
        deps.feed = null;
        deps.allHomeNotes = [];
        deps.homeNotes = [];
        deps.restoreHomeFeedSnapshot(previousLatestFeed);
      }
    }
    const shouldReuseExactStackView = shouldReuseExactRouteStackView({
      routeExistsInStack,
      cache: cachedRoute,
      route: nextRoute,
      viewerPubkey: deps.activeAccount?.pubkey ?? null,
      viewerFollows: deps.viewerFollows,
      activeFeedSourcePubkey: deps.activeFeedSourcePubkey,
      currentRootNhash: deps.rootNhash,
    });
    const shouldPreserveExactStackView = Boolean(
      routeExistsInStack
      && cachedRoute
      && routeRenderCacheHasVisibleContent(cachedRoute),
    );
    if (deps.searchSheetOpen) {
      deps.closeSearchSheet();
    }
    if (
      nextRoute.kind === 'home'
      && !shouldPreserveExactStackView
    ) {
      deps.resetHomeFeedPagination();
    } else if (
      nextRoute.kind === 'profile'
      && ['posts', 'replies', 'media', 'likes'].includes(nextRoute.section)
      && !shouldPreserveExactStackView
      && !identityCacheSource
    ) {
      deps.resetProfileFeedPagination();
    }
    const routeStateChanged = nextRouteKey !== previousRouteKey;
    if (!shouldReuseExactStackView || routeStateChanged) {
      const resumeOrCancelViewLoad = () => {
        if (!shouldReuseExactStackView) {
          deps.restartCurrentViewLoad();
        } else {
          deps.cancelCurrentViewLoad();
        }
      };
      if (options.reusePresentedRetainedView) {
        // Retained adoption already runs after the destination paint.
        resumeOrCancelViewLoad();
      } else {
        const scheduledTransitionVersion = transitionVersion;
        void waitForNextBrowserPaint().then(() => {
          if (
            scheduledTransitionVersion === transitionVersion
            && routeKey(deps.route) === nextRouteKey
          ) {
            resumeOrCancelViewLoad();
          }
        });
      }
    }
    if (identityCacheSource) {
      // Mount the hero and one already-known canonical post in the first
      // frame. Expand the normal visible page only after that frame, keeping a
      // large/complex authored feed out of the navigation commit.
      const stagedTransitionVersion = transitionVersion;
      void waitForNextBrowserPaint().then(() => {
        if (shouldApplyStagedProfilePaginationReset({
          scheduledTransitionVersion: stagedTransitionVersion,
          currentTransitionVersion: transitionVersion,
          expectedRouteKey: nextRouteKey,
          currentRouteKey: routeKey(deps.route),
        })) {
          deps.resetProfileFeedPagination();
        }
      });
    }
    if (nextRoute.kind === 'search' || nextRoute.kind === 'accounts') {
      void waitForNextBrowserPaint().then(() => {
        if (routeKey(deps.route) !== nextRouteKey) {
          return;
        }
        if (nextRoute.kind === 'search') {
          deps.warmSearchResources();
        } else {
          void deps.loadAccountSheet();
        }
      });
    }
  }

  function handleRouteLocationChange(
    options: { fromPopState?: boolean; replaceCurrentView?: boolean } = {},
  ): void {
    const version = ++transitionVersion;
    const replacedKey = options.replaceCurrentView ? routeKey(deps.route) : null;
    const nextRoute = canonicalRoute(
      parseRouteLocation(window.location.pathname, window.location.hash),
    );
    const previousPresentedKey = routeKey(getPresentedRoute() ?? deps.route);
    const routeChangedFromLiveState = routeKey(nextRoute) !== routeKey(deps.route);
    if (routeChangedFromLiveState) {
      // Token invalidation is constant-time and prevents stale commits. Abort
      // listeners and iterator cleanup are deferred until after destination
      // paint by updateRoute below.
      deps.invalidateCurrentViewLoad();
    }
    // Global route overlays must disappear in the same commit as the card
    // switch; otherwise they cover the first frame of a retained destination.
    deps.applyPendingNavigationState();
    deps.applySearchRoute(nextRoute);
    setPresentedRoute(nextRoute);
    const retainedEntry = !replacedKey
      && (options.fromPopState || routeKey(nextRoute) !== previousPresentedKey)
      ? findRetainedRenderEntry(nextRoute)
      : null;

    if (retainedEntry) {
      // Retained cards keep their DOM and route-local state. The shared,
      // viewport-wide page scroller restores the destination's saved offset
      // immediately after the wrapper flip.
      touchRetainedRouteStack(nextRoute);
      const retainedScroll = readRetainedScroll(
        retainedEntry.key,
        Boolean(options.fromPopState),
      );
      const retainedScrollInteractionVersion = getAppScrollInteractionVersion();
      // Svelte applies the presentation-store change in its next DOM flush.
      // Restore after the destination contributes its height, but still before
      // the first paint.
      void tick().then(() => {
        if (
          version !== transitionVersion
          || getAppScrollInteractionVersion() !== retainedScrollInteractionVersion
          || routeKey(parseRouteLocation(window.location.pathname, window.location.hash))
            !== retainedEntry.key
        ) {
          return false;
        }
        deps.restorePresentedRouteScroll(retainedEntry.key, retainedScroll);
        return true;
      }).then(async (presentationIsCurrent) => {
        if (!presentationIsCurrent) {
          return;
        }
        await waitForNextBrowserPaint();
        if (
          version !== transitionVersion
          || routeKey(parseRouteLocation(window.location.pathname, window.location.hash))
            !== retainedEntry.key
        ) {
          return;
        }
        batchReactiveState(() => {
          if (options.fromPopState) {
            deps.navigationTriggeredByPopState = true;
          }
          updateRoute(null, {
            preserveRetainedScroll: true,
            reusePresentedRetainedView: true,
          });
        });
      });
      return;
    }

    batchReactiveState(() => {
      if (options.fromPopState) {
        deps.navigationTriggeredByPopState = true;
      }
      updateRoute(replacedKey);
    });
  }

  function selectMountedEntries() {
    return selectMountedRouteStackEntries(deps.routeStack, deps.routeStackIndex);
  }

  return {
    applyCurrentRouteCache,
    handleRouteLocationChange,
    replaceNonCanonicalIdentifierRoute,
    selectMountedEntries,
    syncRouteStack,
  };
}
