import {
  DEFAULT_FEED_VIEW,
  normalizeFeedView,
  type FeedView,
} from './feedView';
import { FEED_PAGE_SIZE, INITIAL_MEDIA_FEED_LIMIT } from './config';
import type { Route } from './appRoute';
import { routeKey } from './appRoute';
import type { RouteRenderCache } from './appStack';
import {
  readFeedSourcesFromStorage,
  saveFeedSourcesToStorage,
  type FeedSource,
} from './appStorage';
import { fallbackProfileNameForIdentity, normalizePubkey, type RawEvent } from './nostr';
import type { FeedSnapshot } from './nostrIndex';
import type { SocialAccount } from './accounts';
import { pruneRouteRenderCacheForScope } from './appRouteState';

const STORAGE_KEY_FEED_SOURCES = 'iris-social:feed-sources';
const STORAGE_KEY_ACTIVE_FEED_SOURCE = 'iris-social:active-feed-source';
const STORAGE_KEY_FEED_VIEW = 'iris-social:feed-view';

type FeedPreferenceDeps = {
  activeAccount: SocialAccount | null;
  activeFeedSourceId: string | null;
  allHomeNotes: RawEvent[];
  feed: FeedSnapshot | null;
  feedLimit: number;
  feedSourceError: string;
  feedSourceIdentity: string;
  feedSourceName: string;
  feedSourceSheetOpen: boolean;
  feedSources: FeedSource[];
  feedView: FeedView;
  homeFeedFetchLimit: number;
  homeNotes: RawEvent[];
  homeRefreshPending: boolean;
  loading: boolean;
  pageError: string;
  route: Route;
  routeRenderCache: Map<string, RouteRenderCache>;
  resetHomeFeedPagination: () => void;
  resetLiveHomeFeedBuffer: (rememberScreen?: boolean) => void;
  restartCurrentViewLoad: () => void;
  restartCurrentViewLoadAndWait: () => Promise<number>;
};

export function readStoredFeedView(): FeedView {
  return typeof window === 'undefined'
    ? DEFAULT_FEED_VIEW
    : normalizeFeedView(window.localStorage.getItem(STORAGE_KEY_FEED_VIEW));
}

export function createAppFeedPreferences(deps: FeedPreferenceDeps) {
  function saveActiveFeedSourceId(nextId: string | null): void {
    deps.activeFeedSourceId = nextId;
    if (typeof window === 'undefined') {
      return;
    }
    if (nextId) {
      window.localStorage.setItem(STORAGE_KEY_ACTIVE_FEED_SOURCE, nextId);
    } else {
      window.localStorage.removeItem(STORAGE_KEY_ACTIVE_FEED_SOURCE);
    }
  }

  function saveFeedSources(nextSources: FeedSource[]): void {
    deps.feedSources = nextSources;
    saveFeedSourcesToStorage(STORAGE_KEY_FEED_SOURCES, nextSources);
  }

  function handleSelectFeedView(nextView: FeedView): void {
    deps.feedView = normalizeFeedView(nextView);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY_FEED_VIEW, deps.feedView);
    }
    if (deps.feedView === 'media-grid' && deps.feedLimit < INITIAL_MEDIA_FEED_LIMIT) {
      deps.feedLimit = INITIAL_MEDIA_FEED_LIMIT;
      deps.homeFeedFetchLimit = Math.max(
        deps.homeFeedFetchLimit,
        INITIAL_MEDIA_FEED_LIMIT + FEED_PAGE_SIZE,
      );
    }
  }

  function initializeFeedSources(): void {
    const storedSources = readFeedSourcesFromStorage(STORAGE_KEY_FEED_SOURCES);
    deps.feedSources = storedSources;
    if (typeof window === 'undefined') {
      return;
    }
    const storedActiveId = window.localStorage.getItem(STORAGE_KEY_ACTIVE_FEED_SOURCE);
    deps.activeFeedSourceId = storedActiveId
      && storedSources.some((source) => source.id === storedActiveId)
      ? storedActiveId
      : null;
  }

  function restartHomeFeedForSourceChange(): void {
    const activeSourcePubkey = deps.activeFeedSourceId
      ? deps.feedSources.find((source) => source.id === deps.activeFeedSourceId)?.pubkey ?? null
      : null;
    deps.routeRenderCache = pruneRouteRenderCacheForScope(deps.routeRenderCache, {
      viewerPubkey: deps.activeAccount?.pubkey ?? null,
      homeFeedSourcePubkey: activeSourcePubkey,
    });
    if (deps.route.kind !== 'home') {
      return;
    }
    deps.resetLiveHomeFeedBuffer();
    deps.resetHomeFeedPagination();
    deps.restartCurrentViewLoad();
  }

  function openFeedSourceSheet(): void {
    deps.feedSourceError = '';
    deps.feedSourceSheetOpen = true;
  }

  function handleFeedSourceNameChange(value: string): void {
    deps.feedSourceName = value;
    deps.feedSourceError = '';
  }

  function handleFeedSourceIdentityChange(value: string): void {
    deps.feedSourceIdentity = value;
    deps.feedSourceError = '';
  }

  function selectFeedSource(id: string | null): void {
    if (id && !deps.feedSources.some((source) => source.id === id)) {
      return;
    }
    saveActiveFeedSourceId(id);
    deps.feedSourceSheetOpen = false;
    restartHomeFeedForSourceChange();
  }

  function addFeedSource(): void {
    const pubkey = normalizePubkey(deps.feedSourceIdentity);
    if (!pubkey) {
      deps.feedSourceError = 'Invalid profile.';
      return;
    }
    const nextSource: FeedSource = {
      id: pubkey,
      name: deps.feedSourceName.trim() || fallbackProfileNameForIdentity(pubkey),
      identity: deps.feedSourceIdentity.trim(),
      pubkey,
    };
    saveFeedSources([
      ...deps.feedSources.filter((source) => source.id !== nextSource.id),
      nextSource,
    ]);
    saveActiveFeedSourceId(nextSource.id);
    deps.feedSourceName = '';
    deps.feedSourceIdentity = '';
    deps.feedSourceError = '';
    deps.feedSourceSheetOpen = false;
    restartHomeFeedForSourceChange();
  }

  function removeFeedSource(id: string): void {
    saveFeedSources(deps.feedSources.filter((source) => source.id !== id));
    if (deps.activeFeedSourceId === id) {
      saveActiveFeedSourceId(null);
      restartHomeFeedForSourceChange();
    }
  }

  async function handleRefreshHome(): Promise<void> {
    if (deps.homeRefreshPending || deps.route.kind !== 'home') {
      return;
    }
    deps.homeRefreshPending = true;
    deps.pageError = '';
    deps.resetLiveHomeFeedBuffer(true);
    try {
      deps.resetHomeFeedPagination();
      if (deps.route.tab !== 'notifications') {
        const nextRouteRenderCache = new Map(deps.routeRenderCache);
        nextRouteRenderCache.delete(routeKey(deps.route));
        deps.routeRenderCache = nextRouteRenderCache;
        deps.feed = null;
        deps.allHomeNotes = [];
        deps.homeNotes = [];
        deps.loading = true;
      }
      await deps.restartCurrentViewLoadAndWait();
    } finally {
      deps.homeRefreshPending = false;
    }
  }

  return {
    addFeedSource,
    handleFeedSourceIdentityChange,
    handleFeedSourceNameChange,
    handleRefreshHome,
    handleSelectFeedView,
    initializeFeedSources,
    openFeedSourceSheet,
    removeFeedSource,
    selectFeedSource,
  };
}
