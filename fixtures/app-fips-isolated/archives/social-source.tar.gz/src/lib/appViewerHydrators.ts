import type { CID } from '@hashtree/core';
import type { ProfileRecord, RawEvent } from './nostr';
import type { NotificationItem } from './appDetailLoaders';
import { mergeNotificationItems } from './appDetailLoaders';
import {
  loadNotificationsState,
  loadViewerFollowsState,
  loadViewerGraphFollowsState,
  loadViewerMuteListState,
  loadViewerProfileMetadataState,
  resolveViewerPersonalRoot,
  searchRemoteProfiles,
} from './appViewerState';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { mergeProfileMaps } from './profileRecords';
import { profileSearchAbortReason } from './profileSearchAbort';

const PROFILE_SEARCH_TIMEOUT_MS = 5_000;
export const PROFILE_SEARCH_DROPDOWN_LIMIT = 16;
export const PROFILE_SEARCH_PAGE_LIMIT = 80;

type ViewerHydratorDeps = {
  getLoadToken: () => number;
  getSearchRequestId: () => number;
  getViewerPersonalRoot: () => CID | null;
  getAccountProfiles: () => Map<string, ProfileRecord>;
  getNotifications: () => NotificationItem[];
  getNotificationsProfiles: () => Map<string, ProfileRecord>;
  isNotificationsRoute: () => boolean;
  mergeCachedProfiles: (profiles: Map<string, ProfileRecord>) => void;
  saveNotificationsSeenAt: (nextSeenAt: number) => void;
  setViewerPersonalRoot: (nextRoot: CID | null) => void;
  setViewerContactsEvent: (event: RawEvent | null) => void;
  setViewerFollows: (follows: Set<string>) => void;
  setViewerGraphFollows: (follows: Set<string>) => void;
  setViewerMuteListEvent: (event: RawEvent | null) => void;
  setViewerProfileEvent: (event: RawEvent | null) => void;
  setViewerProfileLoading: (loading: boolean) => void;
  setSearchLoading: (loading: boolean) => void;
  setSearchRemoteProfiles: (profiles: ProfileRecord[]) => void;
  setNotificationsLoading: (loading: boolean) => void;
  setNotificationsLoadPending: (loading: boolean) => void;
  setNotificationsCursor: (cursor: RecentTextNoteCursor | null) => void;
  setNotificationsHasMore: (hasMore: boolean) => void;
  setNotifications: (items: NotificationItem[]) => void;
  setNotificationsProfiles: (profiles: Map<string, ProfileRecord>) => void;
};

export type RemoteProfileSearchRunner = (
  query: string,
  limit: number,
  signal: AbortSignal | null,
  onProgress?: (profiles: ProfileRecord[]) => void,
) => Promise<ProfileRecord[]>;

type ViewerHydratorOptions = {
  searchProfiles?: RemoteProfileSearchRunner;
  profileSearchTimeoutMs?: number;
};

export function createViewerHydrators(
  deps: ViewerHydratorDeps,
  options: ViewerHydratorOptions = {},
) {
  let profileSearchController: AbortController | null = null;
  let viewerGraphFollowsLoad: {
    root: CID | null;
    viewerPubkey: string;
    promise: Promise<Set<string>>;
  } | null = null;
  const searchProfiles = options.searchProfiles ?? searchRemoteProfiles;
  const profileSearchTimeoutMs = options.profileSearchTimeoutMs ?? PROFILE_SEARCH_TIMEOUT_MS;

  function preloadViewerGraphFollows(currentRoot: CID | null, viewerPubkey: string): Promise<Set<string>> {
    if (
      viewerGraphFollowsLoad?.root === currentRoot
      && viewerGraphFollowsLoad.viewerPubkey === viewerPubkey
    ) {
      return viewerGraphFollowsLoad.promise;
    }
    const promise = loadViewerGraphFollowsState(currentRoot, viewerPubkey);
    viewerGraphFollowsLoad = { root: currentRoot, viewerPubkey, promise };
    return promise;
  }

  return {
    cancelRemoteSearch(): void {
      profileSearchController?.abort(new DOMException('Profile search was superseded', 'AbortError'));
      profileSearchController = null;
    },

    async hydrateViewerPersonalRoot(currentRoot: CID | null, viewerPubkey: string, token: number): Promise<void> {
      try {
        const personalRoot = await resolveViewerPersonalRoot(currentRoot, viewerPubkey);
        if (token !== deps.getLoadToken()) {
          return;
        }
        deps.setViewerPersonalRoot(personalRoot);
      } catch (error) {
        console.warn('Failed to resolve viewer personal root', error);
      }
    },

    async hydrateViewerFollows(currentRoot: CID | null, viewerPubkey: string, token: number): Promise<void> {
      try {
        const nextState = await loadViewerFollowsState(
          currentRoot,
          deps.getViewerPersonalRoot(),
          viewerPubkey,
        );
        if (token !== deps.getLoadToken()) {
          return;
        }
        deps.setViewerContactsEvent(nextState.contactsEvent);
        deps.setViewerFollows(nextState.follows);
      } catch (error) {
        console.warn('Failed to hydrate viewer follows', error);
      }
    },

    async hydrateViewerGraphFollows(currentRoot: CID | null, viewerPubkey: string, token: number): Promise<void> {
      try {
        const follows = await preloadViewerGraphFollows(currentRoot, viewerPubkey);
        if (token !== deps.getLoadToken()) {
          return;
        }
        deps.setViewerGraphFollows(follows);
      } catch (error) {
        console.warn('Failed to hydrate viewer follows from the offline social graph', error);
      }
    },

    async hydrateViewerMuteList(currentRoot: CID | null, viewerPubkey: string, token: number): Promise<void> {
      try {
        const muteListEvent = await loadViewerMuteListState(
          currentRoot,
          deps.getViewerPersonalRoot(),
          viewerPubkey,
        );
        if (token !== deps.getLoadToken()) {
          return;
        }
        deps.setViewerMuteListEvent(muteListEvent);
      } catch (error) {
        console.warn('Failed to hydrate viewer mute list', error);
      }
    },

    async hydrateViewerProfile(currentRoot: CID | null, viewerPubkey: string, token: number): Promise<void> {
      deps.setViewerProfileLoading(true);
      try {
        const profileEvent = await loadViewerProfileMetadataState(
          currentRoot,
          deps.getViewerPersonalRoot(),
          viewerPubkey,
        );
        if (token !== deps.getLoadToken()) {
          return;
        }
        deps.setViewerProfileEvent(profileEvent);
      } catch (error) {
        console.warn('Failed to hydrate viewer profile metadata', error);
      } finally {
        if (token === deps.getLoadToken()) {
          deps.setViewerProfileLoading(false);
        }
      }
    },

    async hydrateRemoteSearch(
      query: string,
      requestId: number,
      limit = PROFILE_SEARCH_DROPDOWN_LIMIT,
    ): Promise<void> {
      profileSearchController?.abort(new DOMException('Profile search was superseded', 'AbortError'));
      if (!query.trim()) {
        profileSearchController = null;
        deps.setSearchLoading(false);
        deps.setSearchRemoteProfiles([]);
        return;
      }

      const controller = new AbortController();
      profileSearchController = controller;
      deps.setSearchLoading(true);
      let hasAppliedProgress = false;
      const timeoutId = setTimeout(() => {
        controller.abort(new Error('Profile search timed out'));
      }, profileSearchTimeoutMs);

      try {
        const applyProgress = (profiles: ProfileRecord[]): void => {
          if (controller.signal.aborted || requestId !== deps.getSearchRequestId()) {
            return;
          }
          hasAppliedProgress = true;
          deps.setSearchRemoteProfiles(profiles);
        };
        const results = await searchProfiles(query, limit, controller.signal, applyProgress);
        if (requestId !== deps.getSearchRequestId()) {
          return;
        }
        deps.setSearchRemoteProfiles(results);
      } catch (error) {
        if (controller.signal.aborted) {
          const reason = profileSearchAbortReason(controller.signal);
          if (requestId === deps.getSearchRequestId()
            && reason instanceof Error
            && reason.message === 'Profile search timed out') {
            console.warn('Failed to search profile index', error);
            if (!hasAppliedProgress) {
              deps.setSearchRemoteProfiles([]);
            }
          }
          return;
        }
        console.warn('Failed to search profile index', error);
        if (requestId === deps.getSearchRequestId() && !hasAppliedProgress) {
          deps.setSearchRemoteProfiles([]);
        }
      } finally {
        clearTimeout(timeoutId);
        if (profileSearchController === controller) {
          profileSearchController = null;
        }
        if (requestId === deps.getSearchRequestId()) {
          deps.setSearchLoading(false);
        }
      }
    },

    async hydrateNotifications(
      currentRoot: CID,
      viewerPubkey: string,
      token: number,
      options: {
        append?: boolean;
        before?: RecentTextNoteCursor;
        limit?: number;
      } = {},
    ): Promise<void> {
      const append = options.append === true;
      if (append) {
        deps.setNotificationsLoadPending(true);
      } else {
        deps.setNotificationsLoading(true);
      }

      try {
        const notificationData = await loadNotificationsState(
          currentRoot,
          deps.getViewerPersonalRoot(),
          viewerPubkey,
          deps.getAccountProfiles(),
          {
            before: options.before,
            includeViewerState: !append,
            limit: options.limit,
          },
        );

        if (token !== deps.getLoadToken()) {
          return;
        }

        if (!append) {
          deps.setViewerContactsEvent(notificationData.contactsEvent);
          deps.setViewerFollows(notificationData.follows);
        }
        deps.setNotifications(append
          ? mergeNotificationItems(deps.getNotifications(), notificationData.notifications)
          : notificationData.notifications);
        deps.setNotificationsProfiles(append
          ? mergeProfileMaps(deps.getNotificationsProfiles(), notificationData.profiles)
          : notificationData.profiles);
        deps.setNotificationsCursor(notificationData.cursor);
        deps.setNotificationsHasMore(notificationData.hasMore);
        deps.mergeCachedProfiles(notificationData.profiles);

        if (deps.isNotificationsRoute() && notificationData.notifications[0]) {
          deps.saveNotificationsSeenAt(notificationData.notifications[0].actorEvent.created_at);
        }
      } catch (error) {
        console.warn('Failed to hydrate notifications', error);
        if (token === deps.getLoadToken()) {
          if (!append) {
            deps.setNotifications([]);
            deps.setNotificationsProfiles(new Map());
            deps.setNotificationsCursor(null);
            deps.setNotificationsHasMore(false);
          }
        }
      } finally {
        if (token === deps.getLoadToken()) {
          deps.setNotificationsLoading(false);
          deps.setNotificationsLoadPending(false);
        }
      }
    },
  };
}
