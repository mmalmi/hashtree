import { nhashEncode, type CID, type Store } from '@hashtree/core';
import { BTree, type RankedSearchDocument, type RankedSearchFieldValue } from '@hashtree/index';

export const POST_SEARCH_TERM_ROUTING_FORMAT =
  'iris-social/ranked-post-search-term-routing@1' as const;

const ROUTING_SEPARATOR = '\0';
const TOKEN_PATTERN = /#([\p{L}\p{N}\p{M}_]+)|[\p{L}\p{N}][\p{L}\p{N}\p{M}]*(?:['’][\p{L}\p{N}\p{M}]+)*/gu;
const QUOTED_PHRASE_PATTERN = /"([^"]*)"/g;

type LexicalToken = {
  hashtag: boolean;
  term: string;
};

type SegmentRoutingInput = {
  root: CID;
  routingMappingCount: number;
  routingRoot: CID | null;
};

export async function buildPostSearchSegmentRouting(
  store: Store,
  segmentRoot: CID,
  documents: readonly RankedSearchDocument[],
  maxTokensPerField: number,
): Promise<{ root: CID | null; mappingCount: number }> {
  const terms = collectPostSearchRoutingTerms(documents, maxTokensPerField);
  const encodedSegmentRoot = nhashEncode(segmentRoot);
  const root = await new BTree(store).build(terms.map((term): [string, string] => [
    postSearchRoutingKey(term, encodedSegmentRoot),
    '',
  ]));
  return { root, mappingCount: terms.length };
}

export async function mergePostSearchSegmentRoutings(
  store: Store,
  segments: readonly SegmentRoutingInput[],
): Promise<{ root: CID | null; mappingCount: number }> {
  const seen = new Set<string>();
  let mappingCount = 0;
  for (const segment of segments) {
    const encodedRoot = nhashEncode(segment.root);
    if (seen.has(encodedRoot)) {
      throw new Error(`Duplicate post search segment root: ${encodedRoot}`);
    }
    seen.add(encodedRoot);
    validateSegmentRouting(segment);
    mappingCount = addSafeIntegers(
      mappingCount,
      segment.routingMappingCount,
      'post search routing mapping count',
    );
  }
  const index = new BTree(store);
  const root = await index.buildSortedAsync(
    mergeSortedRoutingEntries(index, segments),
  );
  if ((mappingCount === 0) !== (root === null)) {
    throw new Error('Merged post search routing coverage is inconsistent');
  }
  return { root, mappingCount };
}

/**
 * Merge already-sorted immutable segment streams in one pass. Routing keys
 * include the segment root, so distinct segments cannot legitimately collide.
 */
async function* mergeSortedRoutingEntries(
  index: BTree,
  segments: readonly SegmentRoutingInput[],
): AsyncGenerator<[string, string]> {
  const iterators = segments.map((segment) => index.entries(segment.routingRoot)[Symbol.asyncIterator]());
  const heads = await Promise.all(iterators.map(async (iterator) => await iterator.next()));
  const counts = segments.map(() => 0);
  let previousKey: string | null = null;

  while (heads.some((head) => !head.done)) {
    let nextIndex = -1;
    for (let indexPosition = 0; indexPosition < heads.length; indexPosition += 1) {
      const head = heads[indexPosition];
      if (head.done) {
        continue;
      }
      if (nextIndex < 0 || head.value[0] < heads[nextIndex].value[0]) {
        nextIndex = indexPosition;
      }
    }
    if (nextIndex < 0) {
      break;
    }
    const head = heads[nextIndex];
    if (head.done) {
      throw new Error('Missing post search routing stream head');
    }
    const [key, value] = head.value;
    if (previousKey !== null && key <= previousKey) {
      throw new Error(`Duplicate or unsorted post search routing key: ${key}`);
    }
    counts[nextIndex] = addSafeIntegers(
      counts[nextIndex],
      1,
      'post search segment routing traversal count',
    );
    previousKey = key;
    heads[nextIndex] = await iterators[nextIndex].next();
    yield [key, value];
  }

  counts.forEach((count, indexPosition) => {
    if (count !== segments[indexPosition].routingMappingCount) {
      throw new Error('Post search segment routing coverage is inconsistent');
    }
  });
}

/** Extend a verified catalog routing B-tree by only traversing appended terms. */
export async function extendPostSearchSegmentRouting(
  store: Store,
  base: { root: CID | null; mappingCount: number },
  appendedSegments: readonly SegmentRoutingInput[],
  signal?: AbortSignal,
): Promise<{ root: CID | null; mappingCount: number }> {
  if (!Number.isSafeInteger(base.mappingCount)
    || base.mappingCount < 0
    || ((base.mappingCount === 0) !== (base.root === null))) {
    throw new Error('Invalid base post search routing coverage');
  }
  const seen = new Set<string>();
  const index = new BTree(store);
  let root = base.root;
  let mappingCount = base.mappingCount;
  for (const segment of appendedSegments) {
    throwIfAborted(signal);
    const encodedRoot = nhashEncode(segment.root);
    if (seen.has(encodedRoot)) {
      throw new Error(`Duplicate appended post search segment root: ${encodedRoot}`);
    }
    seen.add(encodedRoot);
    validateSegmentRouting(segment);
    let mergedMappings = 0;
    for await (const [key, value] of index.entries(segment.routingRoot)) {
      throwIfAborted(signal);
      root = await index.insert(root, key, value);
      mergedMappings = addSafeIntegers(
        mergedMappings,
        1,
        'appended post search routing mapping count',
      );
    }
    if (mergedMappings !== segment.routingMappingCount) {
      throw new Error('Appended post search routing coverage is inconsistent');
    }
    mappingCount = addSafeIntegers(
      mappingCount,
      segment.routingMappingCount,
      'incremental post search routing mapping count',
    );
  }
  return { root, mappingCount };
}

/**
 * Collect exactly the terms that RankedSearchIndex can index for these documents.
 * Keeping this tokenizer byte-for-byte compatible with @hashtree/index is what makes
 * routing a no-false-negative optimization instead of a second search policy.
 */
export function collectPostSearchRoutingTerms(
  documents: readonly RankedSearchDocument[],
  maxTokensPerField: number,
): string[] {
  const terms = new Set<string>();
  for (const document of documents) {
    for (const value of Object.values(document.fields)) {
      collectFieldTerms(value, maxTokensPerField, terms);
    }
  }
  return [...terms].sort(compareStrings);
}

/** Parse query terms with the same hashtag and quoted-phrase semantics as ranked search. */
export function parsePostSearchRoutingQueryTerms(query: string): string[] {
  const normalizedQuery = normalizeRankedText(query).replace(/[“”]/g, '"');
  const terms: string[] = [];
  const seen = new Set<string>();
  let cursor = 0;
  QUOTED_PHRASE_PATTERN.lastIndex = 0;

  for (const match of normalizedQuery.matchAll(QUOTED_PHRASE_PATTERN)) {
    const start = match.index ?? 0;
    appendUnique(queryTerms(normalizedQuery.slice(cursor, start)), terms, seen);
    appendUnique(queryTerms(match[1] ?? ''), terms, seen);
    cursor = start + match[0].length;
  }
  appendUnique(queryTerms(normalizedQuery.slice(cursor)), terms, seen);
  return terms;
}

export function postSearchRoutingKey(term: string, segmentRoot: string): string {
  if (!term || term.includes(ROUTING_SEPARATOR) || !segmentRoot) {
    throw new Error('Invalid post-search routing key');
  }
  return `${term}${ROUTING_SEPARATOR}${segmentRoot}`;
}

export function postSearchRoutingPrefix(term: string): string {
  if (!term || term.includes(ROUTING_SEPARATOR)) {
    throw new Error('Invalid post-search routing term');
  }
  return `${term}${ROUTING_SEPARATOR}`;
}

export function parsePostSearchRoutingKey(key: string, expectedTerm: string): string | null {
  const prefix = postSearchRoutingPrefix(expectedTerm);
  if (!key.startsWith(prefix)) {
    return null;
  }
  const segmentRoot = key.slice(prefix.length);
  return segmentRoot && !segmentRoot.includes(ROUTING_SEPARATOR) ? segmentRoot : null;
}

function collectFieldTerms(
  value: RankedSearchFieldValue | undefined,
  maxTokens: number,
  terms: Set<string>,
): void {
  const values = value === undefined ? [] : typeof value === 'string' ? [value] : value;
  let length = 0;
  for (const text of values) {
    for (const token of lexicalTokens(text)) {
      if (length >= maxTokens) {
        return;
      }
      terms.add(token.term);
      if (token.hashtag) {
        terms.add(`#${token.term}`);
      }
      length += 1;
    }
  }
}

function queryTerms(text: string): string[] {
  return lexicalTokens(text).map((token) => token.hashtag ? `#${token.term}` : token.term);
}

function lexicalTokens(text: string): LexicalToken[] {
  const normalized = normalizeRankedText(text);
  const tokens: LexicalToken[] = [];
  TOKEN_PATTERN.lastIndex = 0;
  for (const match of normalized.matchAll(TOKEN_PATTERN)) {
    const hashtag = match[1] !== undefined;
    const term = hashtag ? match[1] : match[0];
    if (term) {
      tokens.push({ hashtag, term });
    }
  }
  return tokens;
}

function normalizeRankedText(text: string): string {
  return text.normalize('NFKC').toLowerCase().replace(/’/g, "'");
}

function appendUnique(source: readonly string[], target: string[], seen: Set<string>): void {
  for (const term of source) {
    if (!seen.has(term)) {
      seen.add(term);
      target.push(term);
    }
  }
}

function validateSegmentRouting(segment: SegmentRoutingInput): void {
  const mappingCount = segment.routingMappingCount;
  if (!Number.isInteger(mappingCount) || mappingCount < 0) {
    throw new Error('Invalid post search segment routing mappingCount');
  }
  if ((mappingCount === 0) !== (segment.routingRoot === null)) {
    throw new Error('Post search segment routing root and mappingCount are inconsistent');
  }
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function addSafeIntegers(left: number, right: number, name: string): number {
  const sum = left + right;
  if (!Number.isSafeInteger(sum) || sum < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return sum;
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw signal.reason ?? new DOMException('The operation was aborted', 'AbortError');
  }
}
