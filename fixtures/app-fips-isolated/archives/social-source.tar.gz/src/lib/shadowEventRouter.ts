import type { Store } from '@hashtree/core';
import {
  HashtreeNostrEventReader,
  type HashtreeNostrRootEntry,
  type HashtreeNostrRootSnapshotContext,
} from '@hashtree/nostr-pubsub';
import {
  NostrPubsubRouter,
  allowWithPriority,
  localIndexRoute,
  withRouteDataset,
  type NostrEventReader,
  type NostrFilter,
  type PubsubPolicy,
  type QueryOptions,
  type RoutedQueryReport,
  type RouteQuerySource,
} from 'nostr-pubsub';

export const IRIS_SHADOW_DURABLE_DATASET = 'iris-social:durable-hashtree';
export const IRIS_SHADOW_LIVE_DATASET = 'iris-social:live-overlay';

export type IrisShadowRootSnapshot = {
  /** Additive shared/archive partitions. Equal partition IDs are replicas. */
  shared: readonly HashtreeNostrRootEntry[];
  /** Additive personal partitions. Equal partition IDs are replicas. */
  personal: readonly HashtreeNostrRootEntry[];
};

export type IrisShadowEventRouterOptions = {
  store: Store;
  /**
   * Takes one immutable view of every relevant durable root for each query.
   * Catalog-backed callers can select a bounded subset from the copied filters.
   */
  snapshotRoots: (
    context: HashtreeNostrRootSnapshotContext,
  ) => Promise<IrisShadowRootSnapshot> | IrisShadowRootSnapshot;
  /** A local/persisted live tail, deliberately separate from durable roots. */
  liveOverlayReader: NostrEventReader;
  policy?: PubsubPolicy;
  maxConcurrentPartitions?: number;
};

const allowLocalSources: PubsubPolicy = {
  checkEvent: () => allowWithPriority(0),
  checkSource: () => allowWithPriority(0),
};

/**
 * Opt-in comparison router for migrating Iris Social reads.
 *
 * Nothing in the production feed/thread/profile path instantiates this class.
 * In particular, its fixed route set has no relay content reader. A caller may
 * query it in tests or detached telemetry without changing displayed results.
 */
export class IrisShadowEventRouter {
  private readonly router: NostrPubsubRouter;

  constructor(options: IrisShadowEventRouterOptions) {
    const durableReader = new HashtreeNostrEventReader({
      store: options.store,
      sourceId: 'iris-social-hashtree-indexes',
      roots: {
        snapshot: async (context) => {
          const snapshot = await options.snapshotRoots(context);
          return [
            ...prefixPartitions('shared', snapshot.shared),
            ...prefixPartitions('personal', snapshot.personal),
          ];
        },
      },
      maxConcurrentPartitions: options.maxConcurrentPartitions,
    });
    const routes: RouteQuerySource[] = [
      {
        route: withRouteDataset(
          localIndexRoute('iris-social-hashtree-indexes'),
          IRIS_SHADOW_DURABLE_DATASET,
        ),
        reader: durableReader,
      },
      {
        route: withRouteDataset(
          localIndexRoute('iris-social-live-overlay'),
          IRIS_SHADOW_LIVE_DATASET,
        ),
        reader: options.liveOverlayReader,
      },
    ];
    this.router = new NostrPubsubRouter({
      policy: options.policy ?? allowLocalSources,
      querySources: routes,
    });
  }

  async query(
    filters: NostrFilter[],
    options: QueryOptions = {},
  ): Promise<RoutedQueryReport> {
    return await this.router.queryWithContext(filters, { query: options });
  }
}

function prefixPartitions(
  namespace: 'shared' | 'personal',
  roots: readonly HashtreeNostrRootEntry[],
): HashtreeNostrRootEntry[] {
  return roots.map((entry) => ({
    ...entry,
    partitionId: `${namespace}:${entry.partitionId}`,
  }));
}
