type PlaybackOptions = { enabled: boolean; active: boolean; muted: boolean };

/** Autoplay only the visible video; retained routes and hidden tabs must stay quiet. */
export function videoAutoplay(video: HTMLVideoElement, initial: PlaybackOptions) {
  let options = initial;
  let visible = false;
  let started = false;
  let generation = 0;
  const sync = () => {
    const allowed = options.enabled && options.active && visible && document.visibilityState !== 'hidden';
    const current = ++generation;
    if (!allowed) {
      if (started || !options.active || document.visibilityState === 'hidden') { video.pause(); }
      started = false;
      return;
    }
    if (options.muted) { video.muted = true; }
    started = true;
    void video.play().then(() => {
      if (current !== generation && !started) { video.pause(); }
    }).catch(() => undefined);
  };
  const observer = new IntersectionObserver(entries => {
    visible = entries.some(entry => entry.isIntersecting && entry.intersectionRatio >= 0.5);
    sync();
  }, { threshold: [0, 0.5] });
  observer.observe(video);
  document.addEventListener('visibilitychange', sync);
  return {
    update(next: PlaybackOptions) { options = next; sync(); },
    destroy() {
      generation++;
      started = false;
      video.pause();
      observer.disconnect();
      document.removeEventListener('visibilitychange', sync);
    },
  };
}
