import type { NostrEvent, NostrVerifiedEvent } from 'nostr-pubsub';
import type { RawEvent } from './nostr';

type LivePublisherTransport = {
  publish(event: NostrEvent | NostrVerifiedEvent): Promise<void>;
};

/** Deduplicates detached live sends without coupling them to durable relay state. */
export class DetachedLivePublisher {
  private readonly deliveringEventIds = new Set<string>();

  publish(
    event: RawEvent,
    resolveTransport: () => Promise<LivePublisherTransport | null>,
    onFailure: () => void,
  ): void {
    const eventId = event.id.toLowerCase();
    if (this.deliveringEventIds.has(eventId)) {
      return;
    }
    this.deliveringEventIds.add(eventId);
    void resolveTransport()
      .then(async (transport) => await transport?.publish(event))
      .catch(onFailure)
      .finally(() => this.deliveringEventIds.delete(eventId));
  }
}
