import type { HashtreeWorkerClient } from '@hashtree/worker/client';
import { isSocialWorkerResponse, type SocialWorkerRequest } from '../workers/socialWorkerProtocol';
import { getConfiguredNostrRelays, getConfiguredPrivateNostrRelays } from './htreeRuntime';
import { updateRelayConnections } from './networkStatus';
import { settingsStore, normalizeRelayUrl } from './settings';

/** Attach to the worker the app already initialized. Rendering a connection
 * indicator never starts a worker, opens a socket, or sends a relay probe. */
export function attachRelayConnectionStatus(client: HashtreeWorkerClient): void {
  const requestId = 'network-socket-status';
  let last = '';
  const sync = () => {
    const urls = [...new Set([...getConfiguredNostrRelays(true), ...getConfiguredPrivateNostrRelays(true)]
      .flatMap(url => normalizeRelayUrl(url) ?? []))];
    const disabled = settingsStore.getState().network.disabledRelays ?? [];
    const policy = JSON.stringify([urls, disabled]);
    if (policy === last) { return; }
    last = policy;
    void client.postExtensionMessage({ type: 'social:observeRelayConnections', requestId, urls, disabled } satisfies SocialWorkerRequest)
      .catch(() => { last = ''; updateRelayConnections(null); });
  };
  client.onExtensionMessage(message => {
    if (isSocialWorkerResponse(message) && message.type === 'social:relayConnections' && message.requestId === requestId) {
      updateRelayConnections(message.rows);
    }
  });
  client.onExtensionError(() => { last = ''; updateRelayConnections(null); });
  settingsStore.subscribe(sync);
  window.addEventListener('pageshow', sync);
}
