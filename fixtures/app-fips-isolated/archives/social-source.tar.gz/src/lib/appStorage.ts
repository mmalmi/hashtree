import { fallbackProfileNameForIdentity, normalizePubkey } from './nostr';

export type FeedSource = {
  id: string;
  name: string;
  identity: string;
  pubkey: string;
};

export function readFeedSourcesFromStorage(storageKey: string): FeedSource[] {
  if (typeof window === 'undefined') {
    return [];
  }

  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw) as Array<Partial<FeedSource>>;
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed
      .map((entry) => {
        const pubkey = typeof entry.identity === 'string' ? normalizePubkey(entry.identity) : null;
        if (
          typeof entry.id !== 'string' ||
          typeof entry.name !== 'string' ||
          typeof entry.identity !== 'string' ||
          !pubkey
        ) {
          return null;
        }

        return {
          id: entry.id,
          name: entry.name.trim() || fallbackProfileNameForIdentity(pubkey),
          identity: entry.identity.trim(),
          pubkey,
        } satisfies FeedSource;
      })
      .filter((entry): entry is FeedSource => Boolean(entry));
  } catch {
    return [];
  }
}

export function saveFeedSourcesToStorage(storageKey: string, sources: FeedSource[]): void {
  if (typeof window === 'undefined') {
    return;
  }

  window.localStorage.setItem(storageKey, JSON.stringify(sources));
}

export function readStoredNumber(storageKey: string): number {
  if (typeof window === 'undefined') {
    return 0;
  }

  const raw = window.localStorage.getItem(storageKey);
  const next = raw ? Number.parseInt(raw, 10) : 0;
  return Number.isFinite(next) ? next : 0;
}

export function saveStoredNumber(storageKey: string, value: number): void {
  if (typeof window === 'undefined') {
    return;
  }

  window.localStorage.setItem(storageKey, `${value}`);
}
