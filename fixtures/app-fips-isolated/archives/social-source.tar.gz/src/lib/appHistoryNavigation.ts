import { tick } from 'svelte';
import type { SocialAccount } from './accounts';
import {
  getCurrentAppNavigationHref,
  getPrimaryNavigationItem,
  isPrimaryNavigationClick,
  type PrimaryNavigationItem,
} from './appNavigation';
import {
  canonicalRouteHref,
  parseRouteHref,
  parseRouteLocation,
  routeKey,
  type Route,
} from './appRoute';
import { getActiveAppRouteElement } from './appScroll';
import {
  HOME_HREF,
  accountsHref,
  homeTabHref,
  profileHref,
  profileSectionHref,
  settingsHref,
  threadHref,
  type HomeTab,
  type ProfileSection,
} from './routes';

const APP_HISTORY_INDEX_KEY = 'irisNavigationIndex';

type HistoryNavigationDeps = {
  activeAccount: SocialAccount | null;
  appHistoryIndex: number;
  pendingScrollMode: 'top' | 'restore' | null;
  pendingScrollRestoreKey: string | null;
  pendingScrollRestoreOffset: number | null;
  route: Route;
  handleActivePrimaryNavigation: (item: PrimaryNavigationItem) => boolean;
  handleRefreshHome: () => Promise<void>;
  handleRouteLocationChange: (
    options?: { fromPopState?: boolean; replaceCurrentView?: boolean },
  ) => void;
  navigateHomeBeforeCompose: () => void;
  persistCurrentRouteScrollIfNeeded: () => void;
  primeThreadPreview: (target: string) => void;
};

export function readAppHistoryIndex(state: unknown): number | null {
  if (!state || typeof state !== 'object') {
    return null;
  }
  const value = (state as Record<string, unknown>)[APP_HISTORY_INDEX_KEY];
  return Number.isSafeInteger(value) && Number(value) >= 0 ? Number(value) : null;
}

export function appHistoryState(index: number): Record<string, unknown> {
  const currentState = window.history.state;
  return {
    ...(currentState && typeof currentState === 'object' ? currentState : {}),
    [APP_HISTORY_INDEX_KEY]: index,
  };
}

export function createAppHistoryNavigation(deps: HistoryNavigationDeps) {
  function navigateToHref(nextHref: string): void {
    deps.persistCurrentRouteScrollIfNeeded();
    const nextRoute = parseRouteHref(nextHref);
    const canonicalHref = canonicalRouteHref(nextRoute);
    // A retained page is presented before its live state adopts the route.
    // Compare with the URL the user is viewing so a quick second navigation
    // cannot replace that page's history entry using the outgoing live route.
    const currentRoute = parseRouteLocation(window.location.pathname, window.location.hash);
    if (routeKey(nextRoute) === routeKey(currentRoute)
      && (nextRoute.kind !== 'search' || canonicalHref === canonicalRouteHref(currentRoute))) {
      deps.pendingScrollMode = 'top';
      deps.pendingScrollRestoreKey = null;
      deps.pendingScrollRestoreOffset = null;
      if (`${window.location.pathname}${window.location.hash}` !== canonicalHref) {
        window.history.replaceState(window.history.state, '', canonicalHref);
      }
      deps.handleRouteLocationChange();
      return;
    }
    deps.pendingScrollMode = null;
    deps.pendingScrollRestoreKey = null;
    deps.pendingScrollRestoreOffset = null;
    deps.appHistoryIndex += 1;
    const nextState = appHistoryState(deps.appHistoryIndex);
    delete nextState.irisScrollY;
    window.history.pushState(nextState, '', canonicalHref);
    deps.handleRouteLocationChange();
  }

  function navigateHome(): void {
    navigateToHref(HOME_HREF);
  }

  function navigateBack(): void {
    if (deps.appHistoryIndex > 0) {
      window.history.back();
    } else {
      navigateHome();
    }
  }

  function handleDocumentNavigationClick(event: MouseEvent): void {
    if (event.defaultPrevented || !isPrimaryNavigationClick(event)) {
      return;
    }
    const nextHref = getCurrentAppNavigationHref(event.target);
    if (!nextHref) {
      return;
    }
    event.preventDefault();
    const navigationItem = getPrimaryNavigationItem(event.target);
    if (navigationItem && deps.handleActivePrimaryNavigation(navigationItem)) {
      return;
    }
    navigateToHref(nextHref);
  }

  function handleHomeLinkClick(event: MouseEvent): void {
    if (
      event.button !== 0
      || event.metaKey
      || event.ctrlKey
      || event.shiftKey
      || event.altKey
    ) {
      return;
    }
    event.preventDefault();
    if (!deps.handleActivePrimaryNavigation('home')) {
      navigateHome();
    }
  }

  function navigateActiveProfile(): void {
    if (
      deps.activeAccount
      && !deps.handleActivePrimaryNavigation('profile')
    ) {
      navigateProfile(deps.activeAccount.pubkey);
    }
  }

  function navigateHomeTab(tab: HomeTab): void {
    const currentRoute = parseRouteLocation(window.location.pathname, window.location.hash);
    if (
      currentRoute.kind === 'home' && currentRoute.tab === tab
      && deps.route.kind === 'home' && deps.route.tab === tab
    ) {
      void deps.handleRefreshHome();
    } else {
      navigateToHref(homeTabHref(tab));
    }
  }

  function navigateProfile(pubkey: string): void {
    navigateToHref(profileHref(pubkey));
  }

  function navigateProfileSection(pubkey: string, section: ProfileSection): void {
    navigateToHref(profileSectionHref(pubkey, section));
  }

  function navigateThread(target: string): void {
    navigateToHref(threadHref(target));
    // The clicked card already owns the canonical event. Present the thread
    // route before publishing that shared event into live thread state so the
    // outgoing route cache cannot be cleared or rewritten on the input path.
    deps.primeThreadPreview(target);
  }

  function navigateSettings(): void {
    navigateToHref(settingsHref('profile'));
  }

  function replaceUsernameWithProfile(pubkey: string): void {
    window.history.replaceState(window.history.state, '', profileHref(pubkey));
    deps.handleRouteLocationChange({ replaceCurrentView: true });
  }

  function navigateAccounts(): void {
    navigateToHref(accountsHref());
  }

  function navigateCompose(): void {
    deps.navigateHomeBeforeCompose();
    void tick().then(() => {
      const composerInput = getActiveAppRouteElement()
        ?.querySelector<HTMLTextAreaElement>('[data-testid="composer-input"]');
      composerInput?.scrollIntoView({ block: 'center' });
      composerInput?.focus();
    });
  }

  return {
    handleDocumentNavigationClick,
    handleHomeLinkClick,
    navigateAccounts,
    navigateActiveProfile,
    navigateBack,
    navigateCompose,
    navigateHome,
    navigateHomeTab,
    navigateProfile,
    navigateProfileSection,
    navigateSettings,
    navigateThread,
    navigateToHref,
    replaceUsernameWithProfile,
  };
}
