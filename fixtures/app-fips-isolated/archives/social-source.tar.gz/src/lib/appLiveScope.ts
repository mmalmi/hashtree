import { getNoteEngagementTargetId } from './noteEngagement';
import type { Route } from './appRoute';
import { getForYouInteractionTargetEventId } from './forYouFeed';
import type { FeedSnapshot, NoteThreadSnapshot } from './nostrIndex';
import { getAddressableEventCoordinate, type RawEvent } from './nostr';
import type { SocialLiveScope } from './socialDataPlane';

export type CurrentLiveScopeInput = {
  route: Route;
  activePubkey: string | null;
  feed: FeedSnapshot | null;
  viewerFollows: Set<string>;
  favoritePubkeys?: string[];
  homeNotes: RawEvent[];
  profileNotes: RawEvent[];
  threadPage: NoteThreadSnapshot | null;
  threadReplies: RawEvent[];
  forYouInteractions?: RawEvent[];
};

/**
 * Builds a bounded-route live scope in priority order. Authors whose events are
 * already visible are inserted before the wider follow set so the transport's
 * author cap cannot evict live updates for the screen the user is reading.
 */
export function buildCurrentLiveScope(input: CurrentLiveScopeInput): SocialLiveScope {
  const authors = new Set<string>();
  const eventIds = new Set<string>();
  const referencedEventIds = new Set<string>();
  const addresses = new Set<string>();
  const pubkeys = new Set<string>();
  let interactionAuthors: string[] = [];
  let interactionKinds: number[] = [];
  if (input.activePubkey) {
    authors.add(input.activePubkey);
    pubkeys.add(input.activePubkey);
  }

  const addEvents = (events: Array<RawEvent | null | undefined>) => {
    for (const event of events) {
      if (!event) {
        continue;
      }
      authors.add(event.pubkey);
      eventIds.add(event.id);
      eventIds.add(getNoteEngagementTargetId(event));
      const address = getAddressableEventCoordinate(event);
      if (address) {
        addresses.add(address);
      }
    }
  };

  if (input.route.kind === 'home') {
    addEvents([...(input.feed?.notes ?? []), ...input.homeNotes]);
    for (const author of input.route.tab === 'favorites'
      ? input.favoritePubkeys ?? [] : input.feed?.follows ?? input.viewerFollows) {
      authors.add(author);
    }
    if (input.route.tab === 'for-you') {
      const rankingAuthors = input.feed?.continuation?.authors?.length
        ? input.feed.continuation.authors
        : input.feed?.follows?.length
          ? input.feed.follows
          : [...input.viewerFollows];
      interactionAuthors = [...new Set(rankingAuthors)];
      interactionKinds = [6, 7];
      for (const interaction of input.forYouInteractions ?? []) {
        const targetId = getForYouInteractionTargetEventId(interaction);
        if (targetId) {
          eventIds.add(targetId);
          referencedEventIds.add(targetId);
        }
      }
    }
  } else if (input.route.kind === 'profile') {
    if (input.route.pubkey) {
      authors.add(input.route.pubkey);
    }
    addEvents(input.profileNotes);
  } else if (input.route.kind === 'thread' && input.threadPage) {
    addEvents([
      input.threadPage.note,
      input.threadPage.root,
      input.threadPage.parent,
      ...input.threadPage.context,
      ...input.threadReplies,
    ]);
  }

  if (
    input.route.kind === 'profile'
    && input.route.section === 'likes'
    && input.route.pubkey
  ) {
    interactionAuthors = [input.route.pubkey];
    interactionKinds = [7];
  }

  return {
    authors: [...authors],
    eventIds: [...eventIds],
    referencedEventIds: [...referencedEventIds],
    addresses: [...addresses],
    pubkeys: [...pubkeys],
    interactionAuthors,
    interactionKinds,
  };
}
