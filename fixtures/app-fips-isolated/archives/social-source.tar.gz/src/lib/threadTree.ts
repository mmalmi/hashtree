import {
  getAddressableEventCoordinate,
  isHexEventId,
  isHexPubkey,
  type RawEvent,
} from './nostr';

type ThreadTargetKey = `e:${string}` | `a:${string}`;

export type ThreadReplyNode = {
  event: RawEvent;
  parentId: string | null;
  orphaned: boolean;
  children: ThreadReplyNode[];
};

export type ThreadReplyRow = {
  event: RawEvent;
  parentId: string | null;
  orphaned: boolean;
  depth: number;
  hasChildren: boolean;
};

export type ThreadReplySocialRank = {
  distance: number | null;
  followedByFriends: number | null;
};

export type ThreadReplyRanker = (event: RawEvent) => ThreadReplySocialRank;

type CandidateNode = {
  event: RawEvent;
  parentKey: ThreadTargetKey | null;
  rootKey: ThreadTargetKey | null;
  parent: CandidateNode | null;
  children: CandidateNode[];
};

function canonicalAddressCoordinate(value: string): string | null {
  const candidate = value.trim();
  const firstSeparator = candidate.indexOf(':');
  const secondSeparator = candidate.indexOf(':', firstSeparator + 1);
  if (firstSeparator <= 0 || secondSeparator <= firstSeparator + 1) {
    return null;
  }

  const kindText = candidate.slice(0, firstSeparator);
  const pubkey = candidate.slice(firstSeparator + 1, secondSeparator).toLowerCase();
  const identifier = candidate.slice(secondSeparator + 1);
  if (!/^\d+$/.test(kindText) || !isHexPubkey(pubkey)) {
    return null;
  }

  const kind = Number(kindText);
  if (!Number.isSafeInteger(kind) || kind < 0) {
    return null;
  }

  return `${kind}:${pubkey}:${identifier}`;
}

function targetKey(tagName: string, tagValue: string | undefined): ThreadTargetKey | null {
  const value = tagValue?.trim() ?? '';
  if (tagName === 'e' || tagName === 'E') {
    return isHexEventId(value) ? `e:${value.toLowerCase()}` : null;
  }
  if (tagName === 'a' || tagName === 'A') {
    const coordinate = canonicalAddressCoordinate(value);
    return coordinate ? `a:${coordinate}` : null;
  }
  return null;
}

function nip10EventTags(event: RawEvent): Array<{
  key: ThreadTargetKey;
  marker: string;
}> {
  return event.tags.flatMap((tag) => {
    if (tag[0] !== 'e') {
      return [];
    }
    const key = targetKey('e', tag[1]);
    return key ? [{ key, marker: (tag[3] ?? '').trim().toLowerCase() }] : [];
  });
}

/**
 * Resolve only the immediate reply target. Citation and mention tags are not
 * parents. NIP-22 case is significant: lowercase tags identify the parent and
 * uppercase tags identify the thread root.
 */
export function getDirectThreadParentTargetKey(event: RawEvent): ThreadTargetKey | null {
  if (event.kind === 1_111) {
    for (const tag of event.tags) {
      if (tag[0] === 'i') {
        return null;
      }
      if (tag[0] === 'e' || tag[0] === 'a') {
        return targetKey(tag[0], tag[1]);
      }
    }
    return null;
  }

  const tags = nip10EventTags(event);
  const explicitReply = tags.find((tag) => tag.marker === 'reply');
  if (explicitReply) {
    return explicitReply.key;
  }

  const hasMarkers = tags.some((tag) => tag.marker.length > 0);
  if (hasMarkers) {
    return tags.find((tag) => tag.marker === 'root')?.key ?? null;
  }

  return tags.at(-1)?.key ?? null;
}

function getThreadRootTargetKey(event: RawEvent): ThreadTargetKey | null {
  if (event.kind === 1_111) {
    for (const tag of event.tags) {
      if (tag[0] === 'I') {
        return null;
      }
      if (tag[0] === 'E' || tag[0] === 'A') {
        return targetKey(tag[0], tag[1]);
      }
    }
    return getDirectThreadParentTargetKey(event);
  }

  const tags = nip10EventTags(event);
  const explicitRoot = tags.find((tag) => tag.marker === 'root');
  if (explicitRoot) {
    return explicitRoot.key;
  }

  const hasMarkers = tags.some((tag) => tag.marker.length > 0);
  if (hasMarkers) {
    return tags.find((tag) => tag.marker === 'reply')?.key ?? null;
  }

  return tags[0]?.key ?? null;
}

function eventTargetKeys(event: RawEvent): ThreadTargetKey[] {
  const keys: ThreadTargetKey[] = [`e:${event.id.toLowerCase()}`];
  const address = getAddressableEventCoordinate(event);
  if (address) {
    const canonicalAddress = canonicalAddressCoordinate(address);
    if (canonicalAddress) {
      keys.push(`a:${canonicalAddress}`);
    }
  }
  return keys;
}

function compareOldest(left: CandidateNode, right: CandidateNode): number {
  return left.event.created_at - right.event.created_at || left.event.id.localeCompare(right.event.id);
}

function compareThreadCandidates(
  left: CandidateNode,
  right: CandidateNode,
  ranker: ThreadReplyRanker | null,
): number {
  if (ranker) {
    const leftRank = ranker(left.event);
    const rightRank = ranker(right.event);
    const leftDistance = leftRank.distance ?? Number.MAX_SAFE_INTEGER;
    const rightDistance = rightRank.distance ?? Number.MAX_SAFE_INTEGER;
    const socialOrder = leftDistance - rightDistance
      || (rightRank.followedByFriends ?? 0) - (leftRank.followedByFriends ?? 0);
    if (socialOrder !== 0) {
      return socialOrder;
    }
  }
  return compareOldest(left, right);
}

function targetValue(key: ThreadTargetKey | null): string | null {
  return key?.slice(2) ?? null;
}

function materializeNode(
  candidate: CandidateNode,
  orphaned: boolean,
  included: Set<string>,
  ranker: ThreadReplyRanker | null,
): ThreadReplyNode | null {
  if (included.has(candidate.event.id)) {
    return null;
  }
  included.add(candidate.event.id);

  const children = candidate.children
    .sort((left, right) => compareThreadCandidates(left, right, ranker))
    .flatMap((child) => {
      const materialized = materializeNode(child, false, included, ranker);
      return materialized ? [materialized] : [];
    });

  return {
    event: candidate.event,
    parentId: candidate.parent?.event.id ?? targetValue(candidate.parentKey),
    orphaned,
    children,
  };
}

/**
 * Build the visible subtree rooted at `note` from an immutable flat reply page.
 * A descendant whose parent fell outside the page remains visible as an orphan
 * only when its signed root target still proves membership in this thread.
 */
export function buildThreadReplyForest(
  note: RawEvent,
  replies: RawEvent[],
  ranker: ThreadReplyRanker | null = null,
): ThreadReplyNode[] {
  const uniqueEvents = new Map<string, RawEvent>();
  for (const event of replies) {
    if (event.id !== note.id && !uniqueEvents.has(event.id)) {
      uniqueEvents.set(event.id, event);
    }
  }

  const candidates = [...uniqueEvents.values()].map((event): CandidateNode => ({
    event,
    parentKey: getDirectThreadParentTargetKey(event),
    rootKey: getThreadRootTargetKey(event),
    parent: null,
    children: [],
  }));
  const candidateByTarget = new Map<ThreadTargetKey, CandidateNode>();
  for (const candidate of [...candidates].sort(compareOldest)) {
    for (const key of eventTargetKeys(candidate.event)) {
      if (!candidateByTarget.has(key)) {
        candidateByTarget.set(key, candidate);
      }
    }
  }

  const noteTargets = new Set(eventTargetKeys(note));
  for (const candidate of candidates) {
    const parent = candidate.parentKey ? candidateByTarget.get(candidate.parentKey) ?? null : null;
    if (parent && parent !== candidate) {
      candidate.parent = parent;
      parent.children.push(candidate);
    }
  }

  const belongsToOpenedThread = (candidate: CandidateNode): boolean => (
    candidate.rootKey !== null && noteTargets.has(candidate.rootKey)
  );
  const directRoots = candidates.filter((candidate) => (
    candidate.parentKey !== null && noteTargets.has(candidate.parentKey)
  ));
  const directRootIds = new Set(directRoots.map((candidate) => candidate.event.id));
  const pageBoundaryOrphans = candidates.filter((candidate) => (
    !candidate.parent
    && !directRootIds.has(candidate.event.id)
    && belongsToOpenedThread(candidate)
  ));
  const included = new Set<string>();
  const forest: ThreadReplyNode[] = [];

  for (const candidate of [...directRoots, ...pageBoundaryOrphans]
    .sort((left, right) => compareThreadCandidates(left, right, ranker))) {
    const node = materializeNode(candidate, !directRootIds.has(candidate.event.id), included, ranker);
    if (node) {
      if (candidate.parentKey && noteTargets.has(candidate.parentKey)) {
        node.parentId = note.id;
      }
      forest.push(node);
    }
  }

  // Invalid cycles have no natural root. If their signed root still identifies
  // this thread, break each remaining component at its deterministic oldest ID.
  for (const candidate of candidates.filter(belongsToOpenedThread)
    .sort((left, right) => compareThreadCandidates(left, right, ranker))) {
    const node = materializeNode(candidate, true, included, ranker);
    if (node) {
      forest.push(node);
    }
  }

  return forest;
}

export function flattenThreadReplyForest(
  forest: ThreadReplyNode[],
  depth = 0,
): ThreadReplyRow[] {
  return forest.flatMap((node) => [
    {
      event: node.event,
      parentId: node.parentId,
      orphaned: node.orphaned,
      depth,
      hasChildren: node.children.length > 0,
    },
    ...flattenThreadReplyForest(node.children, depth + 1),
  ]);
}

export function buildThreadReplyRows(
  note: RawEvent,
  replies: RawEvent[],
  ranker: ThreadReplyRanker | null = null,
): ThreadReplyRow[] {
  return flattenThreadReplyForest(buildThreadReplyForest(note, replies, ranker));
}
