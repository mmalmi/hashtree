import { HashTree, type CID } from '@hashtree/core';
import { SearchIndex, type SearchLinkResult, type SearchResult } from '@hashtree/index';
import {
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
  getConfiguredProfileSearchIndexRefs,
} from './config';
import { CooperativeWorkBudget } from './cooperativeWork';
import { normalizePubkey, type ProfileRecord } from './nostr';
import {
  verifyAndProjectIndexedProfileRecords,
  type IndexedProfileRecordInput,
} from './profileIndex';
import { overlayProfileRecord, preferNewerProfileRecord } from './profileRecords';
import {
  throwIfProfileSearchAborted,
  withProfileSearchAbort,
} from './profileSearchAbort';
import { profileSearchResultToProfileRecord } from './profileSearchProjection';
import { profileSearchRank, sortProfileSearchMatches } from './profileSearchRanking';
import { applySocialGraphMetrics } from './socialGraph';
import { resolveTreeTargetRoot } from './treeRef';
import { createWorkerBlockStore } from './workerBlockStore';

export { profileSearchRank, sortProfileSearchMatches };
export { mergeProfileSearchRecords } from './profileSearchRanking';
export { profileSearchResultToProfileRecord } from './profileSearchProjection';
export type { ProfileSearchRank } from './profileSearchRanking';

const PROFILE_SEARCH_PREFIX = 'p:';
const PROFILE_SEARCH_ROOT_CACHE_TTL_MS = 30_000;
const PROFILE_SEARCH_ROOT_RETRY_DELAYS_MS = [120, 360, 900];
const PROFILE_SEARCH_ROOT_CACHE_LIMIT = 32;
const MAX_PROFILE_SEARCH_CANDIDATES = 64;
const MAX_PROFILE_SEARCH_SCAN = 128;
const MAX_DEEP_PROFILE_SEARCH_CANDIDATES = 256;
const MAX_DEEP_PROFILE_SEARCH_SCAN = 512;
const MAX_PROFILE_SEARCH_FALLBACK_PROBES = 5;
const MAX_PROFILE_SEARCH_FALLBACK_CANDIDATES = 128;
const MAX_PROFILE_SEARCH_FALLBACK_CANDIDATES_PER_PROBE = 64;
const SPARSE_PROFILE_SEARCH_CANDIDATES = 4;

export type ProfileSearchCandidateOptions = {
  limit: number;
  scanLimit: number;
};

export interface ProfileSearchCandidateSource {
  search(
    root: CID | null,
    prefix: string,
    query: string,
    options: ProfileSearchCandidateOptions,
  ): Promise<SearchResult[]>;
  searchLinks(
    root: CID | null,
    prefix: string,
    query: string,
    options: ProfileSearchCandidateOptions,
  ): Promise<SearchLinkResult[]>;
}

export type ProfileSearchCandidates = {
  inline: SearchResult[];
  links: SearchLinkResult[];
};

export type ProfileSearchCandidateProgressHandler = (
  candidates: ProfileSearchCandidates,
  phase: 'exact' | 'fallback',
) => void;

export type ProfileSearchProgressHandler = (profiles: ProfileRecord[]) => void;

export type ProfileSearchSourceRunner = (
  onProgress: ProfileSearchProgressHandler,
) => Promise<ProfileRecord[]>;

type RemoteSearchContext = {
  index: SearchIndex;
  tree: HashTree;
};

let remoteSearchContext: RemoteSearchContext | null = null;
const cachedProfileSearchRoots = new Map<string, { expiresAt: number; root: CID }>();
const profileSearchRootPromises = new Map<string, Promise<CID | null>>();

function createRemoteSearchContext(): RemoteSearchContext {
  const store = createWorkerBlockStore();

  return {
    index: new SearchIndex(store),
    tree: new HashTree({ store }),
  };
}

function getRemoteSearchContext(): RemoteSearchContext {
  if (remoteSearchContext) {
    return remoteSearchContext;
  }

  remoteSearchContext = createRemoteSearchContext();
  return remoteSearchContext;
}

async function resolveProfileSearchIndexRoot(
  ref: string,
  signal: AbortSignal | null = null,
): Promise<CID | null> {
  throwIfProfileSearchAborted(signal);
  const cached = cachedProfileSearchRoots.get(ref);
  if (cached && cached.expiresAt > Date.now()) {
    cachedProfileSearchRoots.delete(ref);
    cachedProfileSearchRoots.set(ref, cached);
    return cached.root;
  }

  const pending = profileSearchRootPromises.get(ref);
  if (pending) {
    return await withProfileSearchAbort(pending, signal);
  }

  const promise = resolveTreeTargetRoot(ref, {
    resolveImmutablePath: async (root, path) => (await getRemoteSearchContext().tree.resolvePath(root, path))?.cid ?? null,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
    retryDelaysMs: PROFILE_SEARCH_ROOT_RETRY_DELAYS_MS,
  });

  profileSearchRootPromises.set(ref, promise);
  void promise.then((root) => {
    if (root) {
      cachedProfileSearchRoots.delete(ref);
      while (cachedProfileSearchRoots.size >= PROFILE_SEARCH_ROOT_CACHE_LIMIT) {
        cachedProfileSearchRoots.delete(cachedProfileSearchRoots.keys().next().value as string);
      }
      cachedProfileSearchRoots.set(ref, {
        root,
        expiresAt: Date.now() + PROFILE_SEARCH_ROOT_CACHE_TTL_MS,
      });
    }
  }).finally(() => {
    if (profileSearchRootPromises.get(ref) === promise) {
      profileSearchRootPromises.delete(ref);
    }
  }).catch(() => undefined);
  return await withProfileSearchAbort(promise, signal);
}

async function loadRemoteProfileRecordInput(
  cid: CID,
  fallbackPubkey: string,
  signal: AbortSignal | null,
): Promise<IndexedProfileRecordInput | null> {
  try {
    const bytes = await withProfileSearchAbort(
      getRemoteSearchContext().tree.readFile(cid),
      signal,
    );
    if (!bytes) {
      return null;
    }

    return { pubkey: fallbackPubkey, bytes };
  } catch {
    throwIfProfileSearchAborted(signal);
    return null;
  }
}

async function hydrateLinkedProfiles(
  results: SearchLinkResult[],
  signal: AbortSignal | null,
  onProfile: ((profile: ProfileRecord) => void) | null = null,
): Promise<ProfileRecord[]> {
  const records = (await mapConcurrent(results, 8, async (result) => {
    throwIfProfileSearchAborted(signal);
    return await loadRemoteProfileRecordInput(
      result.cid,
      result.id.toLowerCase(),
      signal,
    );
  })).filter((record): record is IndexedProfileRecordInput => record !== null);
  const workBudget = new CooperativeWorkBudget();
  const verified = await verifyAndProjectIndexedProfileRecords(records, {
    signal: signal ?? undefined,
    workBudget,
  });
  const profiles: ProfileRecord[] = [];
  for (const result of results) {
    throwIfProfileSearchAborted(signal);
    const profile = verified.get(result.id.toLowerCase()) ?? null;
    if (profile) {
      profiles.push(profile);
      if (onProfile) {
        await workBudget.run(() => onProfile(profile));
      }
    }
  }
  return profiles;
}

function normalizeProfileSearchWords(query: string): string[] {
  return query
    .normalize('NFKD')
    .replace(/\p{M}+/gu, '')
    .toLowerCase()
    .match(/[\p{L}\p{N}]+/gu) ?? [];
}

function wordPrefix(word: string, broad: boolean): string {
  const characters = [...word];
  if (characters.length <= 2) {
    return word;
  }
  const length = broad ? 2 : Math.max(3, Math.floor(characters.length / 2));
  return characters.slice(0, Math.min(length, characters.length)).join('');
}

function transposeSearchWords(words: readonly string[], offset: number): string {
  let changed = false;
  const transposed = words.map((word) => {
    const characters = [...word];
    if (
      characters.length <= offset + 1
      || characters[offset] === characters[offset + 1]
    ) {
      return word;
    }
    [characters[offset], characters[offset + 1]] = [
      characters[offset + 1]!,
      characters[offset]!,
    ];
    changed = true;
    return characters.join('');
  });
  return changed ? transposed.join(' ') : '';
}

function profileSearchFallbackQueries(query: string): string[] {
  if (normalizePubkey(query)) {
    return [];
  }

  const words = normalizeProfileSearchWords(query);
  if (words.length === 0) {
    return [];
  }

  const exact = query.trim().toLowerCase();
  const probes = [
    words.join(' '),
    transposeSearchWords(words, 0),
    transposeSearchWords(words, 1),
    words.map((word) => wordPrefix(word, false)).join(' '),
    words.map((word) => wordPrefix(word, true)).join(' '),
  ];
  return [...new Set(probes)]
    .filter((probe) => probe.length >= 2 && probe !== exact)
    .slice(0, MAX_PROFILE_SEARCH_FALLBACK_PROBES);
}

export async function retrieveProfileSearchCandidates(
  source: ProfileSearchCandidateSource,
  root: CID,
  query: string,
  limit: number,
  signal: AbortSignal | null = null,
  onProgress: ProfileSearchCandidateProgressHandler | null = null,
): Promise<ProfileSearchCandidates> {
  throwIfProfileSearchAborted(signal);
  const requestedLimit = Number.isFinite(limit)
    ? Math.max(0, Math.floor(limit))
    : MAX_PROFILE_SEARCH_CANDIDATES;
  if (requestedLimit === 0) {
    return { inline: [], links: [] };
  }

  const quickLimit = Math.min(MAX_PROFILE_SEARCH_CANDIDATES, requestedLimit * 4);
  const quickOptions = {
    limit: quickLimit,
    scanLimit: Math.min(MAX_PROFILE_SEARCH_SCAN, quickLimit * 2),
  };
  const inline = new Map<string, SearchResult>();
  const links = new Map<string, SearchLinkResult>();
  const snapshot = (): ProfileSearchCandidates => ({
    inline: sortSearchCandidates([...inline.values()]),
    links: sortSearchCandidates([...links.values()]),
  });
  const credibleCandidateCount = (): number => new Set([
    ...[...inline.values()].flatMap((candidate) => {
      const profile = profileSearchResultToProfileRecord(candidate, query);
      return profile && profileSearchRank(profile, query).textScore > 0
        ? [candidate.id.toLowerCase()]
        : [];
    }),
    ...links.keys(),
  ]).size;
  const read = async (
    kind: 'inline' | 'link',
    probe: string,
    options: ProfileSearchCandidateOptions,
    phase: 'exact' | 'fallback',
  ): Promise<{ ok: true; count: number } | { ok: false; error: unknown }> => {
    throwIfProfileSearchAborted(signal);
    try {
      const results = await withProfileSearchAbort(
        Promise.resolve().then(async () => kind === 'inline'
          ? await source.search(root, PROFILE_SEARCH_PREFIX, probe, options)
          : await source.searchLinks(root, PROFILE_SEARCH_PREFIX, probe, options)),
        signal,
      );
      throwIfProfileSearchAborted(signal);
      const boundedResults = results.slice(0, options.limit);
      const changed = kind === 'inline'
        ? mergeSearchCandidates(inline, boundedResults as SearchResult[])
        : mergeSearchCandidates(links, boundedResults as SearchLinkResult[]);
      if (changed) {
        onProgress?.(snapshot(), phase);
      }
      return { ok: true, count: boundedResults.length };
    } catch (error) {
      throwIfProfileSearchAborted(signal);
      return { ok: false, error };
    }
  };
  const readProbe = async (
    probe: string,
    options: ProfileSearchCandidateOptions,
    phase: 'exact' | 'fallback',
  ) => await Promise.all([
    read('inline', probe, options, phase),
    read('link', probe, options, phase),
  ]);

  const quickOutcomes = await readProbe(query, quickOptions, 'exact');
  if (quickOutcomes.every((outcome) => !outcome.ok)) {
    const firstFailure = quickOutcomes.find(
      (outcome): outcome is { ok: false; error: unknown } => !outcome.ok,
    );
    throw firstFailure?.error;
  }
  const sparseTarget = Math.min(requestedLimit, SPARSE_PROFILE_SEARCH_CANDIDATES);
  const saturatedKinds = (['inline', 'link'] as const).filter((_kind, index) => {
    const outcome = quickOutcomes[index];
    return outcome?.ok && outcome.count >= quickLimit;
  });
  if (saturatedKinds.length > 0) {
    const deepLimit = Math.min(
      MAX_DEEP_PROFILE_SEARCH_CANDIDATES,
      Math.max(quickLimit, requestedLimit * 16),
    );
    const deepOptions = {
      limit: deepLimit,
      scanLimit: Math.min(MAX_DEEP_PROFILE_SEARCH_SCAN, deepLimit * 2),
    };
    await Promise.all(saturatedKinds.map(async (kind) => {
      await read(kind, query, deepOptions, 'exact');
    }));
  }
  if (credibleCandidateCount() < sparseTarget) {
    const fallbackQueries = profileSearchFallbackQueries(query);
    if (fallbackQueries.length === 0) {
      return snapshot();
    }
    const fallbackReadCount = fallbackQueries.length * 2;
    const perProbeLimit = Math.min(
      MAX_PROFILE_SEARCH_FALLBACK_CANDIDATES_PER_PROBE,
      Math.max(1, Math.floor(MAX_PROFILE_SEARCH_FALLBACK_CANDIDATES / fallbackReadCount)),
    );
    const fallbackOptions = {
      limit: perProbeLimit,
      scanLimit: Math.min(MAX_PROFILE_SEARCH_SCAN, perProbeLimit * 2),
    };
    await withProfileSearchAbort(
      Promise.all(fallbackQueries.map(async (probe) => {
        await readProbe(probe, fallbackOptions, 'fallback');
      })),
      signal,
    );
  }
  return snapshot();
}

function compareSearchCandidates(
  left: SearchResult | SearchLinkResult,
  right: SearchResult | SearchLinkResult,
): number {
  return (
    right.score - left.score
    || (right.exactMatches ?? 0) - (left.exactMatches ?? 0)
    || (left.prefixDistance ?? Number.POSITIVE_INFINITY)
      - (right.prefixDistance ?? Number.POSITIVE_INFINITY)
    || left.id.localeCompare(right.id)
  );
}

function sortSearchCandidates<Result extends SearchResult | SearchLinkResult>(
  results: Result[],
): Result[] {
  return results.sort(compareSearchCandidates);
}

function mergeSearchCandidates<Result extends SearchResult | SearchLinkResult>(
  target: Map<string, Result>,
  results: readonly Result[],
): boolean {
  let changed = false;
  for (const result of results) {
    const id = result.id.toLowerCase();
    const current = target.get(id);
    if (!current || compareSearchCandidates(result, current) < 0) {
      target.set(id, result);
      changed = true;
    }
  }
  return changed;
}

async function searchProfileIndexRoot(
  root: CID,
  query: string,
  limit: number,
  signal: AbortSignal | null,
  onProgress: ProfileSearchProgressHandler | null,
): Promise<ProfileRecord[]> {
  throwIfProfileSearchAborted(signal);
  const remote = getRemoteSearchContext();
  const profiles = new Map<string, ProfileRecord>();
  const scheduledLinkIds = new Set<string>();
  const linkedHydrations: Promise<ProfileRecord[]>[] = [];

  const snapshot = (): ProfileRecord[] => sortProfileSearchMatches(
    [...profiles.values()].map((profile) => applySocialGraphMetrics(profile) ?? profile),
    query,
  ).slice(0, limit);
  const emit = (): void => {
    throwIfProfileSearchAborted(signal);
    onProgress?.(snapshot());
  };
  const mergeProfile = (profile: ProfileRecord): void => {
    const merged = preferFederatedProfileRecord(profiles.get(profile.pubkey), profile);
    if (merged) {
      profiles.set(profile.pubkey, merged);
    }
    emit();
  };
  const mergeInlineCandidates = (candidates: ProfileSearchCandidates): void => {
    for (const profile of candidates.inline
      .map((candidate) => profileSearchResultToProfileRecord(candidate, query))
      .filter((candidate): candidate is ProfileRecord => Boolean(candidate))) {
      const merged = preferFederatedProfileRecord(profiles.get(profile.pubkey), profile);
      if (merged) {
        profiles.set(profile.pubkey, merged);
      }
    }
    const nextLinks = candidates.links.filter((result) => {
      const id = result.id.toLowerCase();
      if (scheduledLinkIds.has(id)) {
        return false;
      }
      scheduledLinkIds.add(id);
      return true;
    });
    if (nextLinks.length > 0) {
      const hydration = hydrateLinkedProfiles(nextLinks, signal, mergeProfile);
      linkedHydrations.push(hydration);
      void hydration.catch(() => undefined);
    }
    emit();
  };

  const candidates = await retrieveProfileSearchCandidates(
    remote.index,
    root,
    query,
    limit,
    signal,
    (nextCandidates) => {
      mergeInlineCandidates(nextCandidates);
    },
  );

  mergeInlineCandidates(candidates);
  await withProfileSearchAbort(
    Promise.all(linkedHydrations),
    signal,
  );

  return snapshot();
}

export async function searchProfileIndex(
  query: string,
  limit = 12,
  signal: AbortSignal | null = null,
  onProgress: ProfileSearchProgressHandler | null = null,
): Promise<ProfileRecord[]> {
  throwIfProfileSearchAborted(signal);
  const trimmed = query.trim();
  if (!trimmed) {
    return [];
  }

  const refs = getConfiguredProfileSearchIndexRefs();
  // Tree resolution already refreshes a verified cached pointer in the
  // background. Forcing the same ref here returns that root again and repeats
  // every Hashtree candidate read for no-result searches.
  return await searchProfileIndexRefs(refs, trimmed, limit, signal, onProgress);
}

export async function warmProfileSearchIndex(): Promise<void> {
  await Promise.all(getConfiguredProfileSearchIndexRefs().map(async (ref) => {
    await resolveProfileSearchIndexRoot(ref);
  }));
}

export async function searchProfileIndexRefs(
  refs: readonly string[],
  query: string,
  limit: number,
  signal: AbortSignal | null,
  onProgress: ProfileSearchProgressHandler | null,
): Promise<ProfileRecord[]> {
  return await searchFederatedProfileSources(
    refs.map((ref): ProfileSearchSourceRunner => async (emit) => {
      const root = await resolveProfileSearchIndexRoot(ref, signal);
      if (!root) {
        return [];
      }
      return await searchProfileIndexRoot(
        root,
        query,
        Math.min(Math.max(limit * 2, limit), 64),
        signal,
        emit,
      );
    }),
    query,
    limit,
    signal,
    onProgress,
  );
}

export async function searchFederatedProfileSources(
  sources: readonly ProfileSearchSourceRunner[],
  query: string,
  limit: number,
  signal: AbortSignal | null = null,
  onProgress: ProfileSearchProgressHandler | null = null,
): Promise<ProfileRecord[]> {
  throwIfProfileSearchAborted(signal);
  const sourceResults = new Array<ProfileRecord[]>(sources.length).fill([]);
  const emit = (): void => {
    throwIfProfileSearchAborted(signal);
    onProgress?.(mergeFederatedProfileSearchProfiles(sourceResults, query, limit));
  };
  await withProfileSearchAbort(
    Promise.allSettled(sources.map(async (source, index) => {
      sourceResults[index] = await source((profiles) => {
        sourceResults[index] = profiles;
        emit();
      });
      emit();
    })),
    signal,
  );
  throwIfProfileSearchAborted(signal);
  return mergeFederatedProfileSearchProfiles(
    sourceResults,
    query,
    limit,
  );
}

async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input) => Promise<Output>,
): Promise<Output[]> {
  const results = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await worker(values[index]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return results;
}

export function mergeFederatedProfileSearchProfiles(
  sources: readonly (readonly ProfileRecord[])[],
  query: string,
  limit: number,
): ProfileRecord[] {
  const profiles = new Map<string, ProfileRecord>();
  for (const source of sources) {
    for (const profile of source) {
      const current = profiles.get(profile.pubkey);
      const merged = preferFederatedProfileRecord(current, profile);
      if (merged) {
        profiles.set(profile.pubkey, merged);
      }
    }
  }
  return sortProfileSearchMatches([...profiles.values()], query).slice(0, limit);
}

function preferFederatedProfileRecord(
  current: ProfileRecord | null | undefined,
  candidate: ProfileRecord,
): ProfileRecord | null {
  if (current?.eventId && !candidate.eventId) {
    const merged = overlayProfileRecord(current, candidate);
    return merged ? { ...merged, createdAt: current.createdAt } : null;
  }
  if (candidate.eventId && !current?.eventId) {
    const merged = overlayProfileRecord(candidate, current);
    return merged ? { ...merged, createdAt: candidate.createdAt } : null;
  }
  return preferNewerProfileRecord(current, candidate);
}
