import type { SocialGraph } from 'nostr-social-graph';

/** Same consensus rule as iris-client feeds, threads and notifications. */
export const SOCIAL_GRAPH_OVERMUTE_THRESHOLD = 3;
const UNREACHABLE = Number.POSITIVE_INFINITY;

export type ViewerGraphMutes = {
  viewer: string;
  /** The viewer's own mute list as the cached graph knows it. */
  muted: string[];
  /** created_at of that list, or null when the graph has none. */
  mutedAt: number | null;
  /** Users whose nearest opinions are mostly mutes, viewer's direct mutes excluded. */
  overmuted: string[];
};

export function validateViewerGraphMutesQuery(viewer: unknown): asserts viewer is string {
  if (typeof viewer !== 'string' || !/^[0-9a-f]{64}$/.test(viewer)) {
    throw new RangeError('Invalid social graph mute query');
  }
}

/** iris-client's default `maxFollowDistanceForReplies`. */
export const MAX_VISIBLE_FOLLOW_DISTANCE = 5;

/**
 * One viewer-relative reading of the shared graph, computed once per graph
 * revision: follow distances and overmute consensus, like iris-client's
 * viewer-rooted graph, without rerooting the shared instance. A viewer the
 * graph does not know yet, or who follows no one in it, reads distances from
 * the graph root so the public web of trust still decides reachability.
 */
export type ViewerGraphView = {
  viewer: string;
  /** Internal graph ID -> follow distance from the viewer (or graph root). */
  distances: ReadonlyMap<number, number>;
  /** False when `distances` fell back to the graph root. */
  rootedAtViewer: boolean;
  overmutedIds: ReadonlySet<number>;
  mutes: ViewerGraphMutes;
};

function followDistancesFrom(
  followedByUser: Map<number, Set<number>>,
  source: number,
): Map<number, number> {
  const distances = new Map<number, number>([[source, 0]]);
  const queue = [source];
  for (let head = 0; head < queue.length; head++) {
    const user = queue[head]!;
    const next = distances.get(user)! + 1;
    for (const followed of followedByUser.get(user) ?? []) {
      if (!distances.has(followed)) {
        distances.set(followed, next);
        queue.push(followed);
      }
    }
  }
  return distances;
}

/**
 * Port of iris-client's `createAlgorithmicVisibilitySnapshot`: a user is
 * overmuted when, among the closest users (by follow distance from the
 * viewer) who follow or mute them, `muters * threshold > followers`.
 */
export function viewerGraphViewFromGraph(
  graph: SocialGraph,
  viewer: string,
  threshold = SOCIAL_GRAPH_OVERMUTE_THRESHOLD,
): ViewerGraphView {
  validateViewerGraphMutesQuery(viewer);
  const { ids, followedByUser, followersByUser, mutedByUser, userMutedBy, muteListCreatedAt, str } =
    graph.getInternalData();
  const viewerId = ids.has(viewer) ? ids.id(viewer) : undefined;
  const viewerDistances = viewerId === undefined ? null : followDistancesFrom(followedByUser, viewerId);
  const root = graph.getRoot();
  const rootedAtViewer = Boolean(viewerDistances && viewerDistances.size > 1);
  const distances = rootedAtViewer && viewerDistances
    ? viewerDistances
    : ids.has(root) ? followDistancesFrom(followedByUser, ids.id(root)) : new Map<number, number>();
  if (viewerId === undefined || !viewerDistances) {
    return {
      viewer,
      distances,
      rootedAtViewer,
      overmutedIds: new Set(),
      mutes: { viewer, muted: [], mutedAt: null, overmuted: [] },
    };
  }
  const direct = mutedByUser.get(viewerId) ?? new Set<number>();

  const overmutedIds = new Set<number>();
  for (const [targetId, muterIds] of userMutedBy) {
    if (targetId === viewerId || direct.has(targetId) || muterIds.size === 0) {continue;}
    let nearest = UNREACHABLE;
    let followers = 0;
    let muters = 0;
    const record = (opinionId: number, isMute: boolean): void => {
      const distance = viewerDistances.get(opinionId) ?? UNREACHABLE;
      if (distance > nearest || distance === UNREACHABLE) {return;}
      if (distance < nearest) {
        nearest = distance;
        followers = 0;
        muters = 0;
      }
      if (isMute) {muters += 1;} else {followers += 1;}
    };
    for (const followerId of followersByUser.get(targetId) ?? []) {record(followerId, false);}
    for (const muterId of muterIds) {record(muterId, true);}
    if (nearest !== UNREACHABLE && muters * threshold > followers) {
      overmutedIds.add(targetId);
    }
  }

  return {
    viewer,
    distances,
    rootedAtViewer,
    overmutedIds,
    mutes: {
      viewer,
      muted: [...direct].map(str),
      mutedAt: muteListCreatedAt.get(viewerId) ?? null,
      overmuted: [...overmutedIds].map(str),
    },
  };
}

export function viewerGraphMutesFromGraph(
  graph: SocialGraph,
  viewer: string,
  threshold = SOCIAL_GRAPH_OVERMUTE_THRESHOLD,
): ViewerGraphMutes {
  return viewerGraphViewFromGraph(graph, viewer, threshold).mutes;
}

let cached: { graph: SocialGraph; revision: number; view: ViewerGraphView } | null = null;

/** One full pass per graph revision and viewer; repeat queries reuse it. */
export function cachedViewerGraphView(graph: SocialGraph, viewer: string, revision: number): ViewerGraphView {
  if (cached?.graph === graph && cached.revision === revision && cached.view.viewer === viewer) {
    return cached.view;
  }
  const view = viewerGraphViewFromGraph(graph, viewer);
  cached = { graph, revision, view };
  return view;
}

export function cachedViewerGraphMutes(graph: SocialGraph, viewer: string, revision: number): ViewerGraphMutes {
  return cachedViewerGraphView(graph, viewer, revision).mutes;
}
