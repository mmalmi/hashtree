import type { NostrVerifiedEvent } from 'nostr-pubsub';
import { awaitWithin } from './feedIndexTiming';
import { type ProfileRecord } from './nostr';
import { preferNewerProfileRecord } from './profileRecords';
import { projectSearchableProfileEvent } from './profileSearchIdentity';
import { profileSearchRank } from './profileSearchRanking';
import { getPublicSearchRelays } from './publicSearchRelays';
import { loadSocialGraphFrontier } from './socialGraphFrontier';
import { createWorkerRelayEventReader } from './workerRelayEventReader';

const PROFILE_RELAY_LIMIT = 96;
const PROFILE_RELAY_QUERY_MS = 3_000;
const PROFILE_RELAY_RESULT_MS = 4_000;
const GRAPH_READ_BUDGET_MS = 250;
const MIN_LEXICAL_MATCH_SCORE = 3_500;
const publicReader = createWorkerRelayEventReader({ getRelays: getPublicSearchRelays });

export type PublicPeopleSearchResult = {
  profiles: ProfileRecord[];
  preferredPubkeys: ReadonlySet<string>;
  complete: boolean;
};

function validSearchText(query: string): boolean {
  return query.length >= 2 && query.length <= 128;
}

export function canSearchPublicPeople(query: string): boolean {
  return validSearchText(query.trim()) && getPublicSearchRelays().length > 0;
}

export async function searchPublicPeople(
  query: string,
  signal: AbortSignal,
  source: Pick<typeof publicReader, 'query'> = publicReader,
  loadFrontier: () => Promise<string[]> = loadSocialGraphFrontier,
  onProgress?: (result: PublicPeopleSearchResult) => void,
): Promise<PublicPeopleSearchResult> {
  const text = query.trim();
  if (!validSearchText(text)) { return { profiles: [], preferredPubkeys: new Set(), complete: true }; }
  const cached = new Map<string, NostrVerifiedEvent>();
  let preferredPubkeys = new Set<string>();
  const frontier = awaitWithin(loadFrontier().catch(() => []), GRAPH_READ_BUDGET_MS).then(result => {
    preferredPubkeys = new Set(result.settled ? result.value : []);
  });
  const [report] = await Promise.all([
    source.query([{ kinds: [0], search: text, limit: PROFILE_RELAY_LIMIT }], {
      limit: PROFILE_RELAY_LIMIT,
      deadline: Date.now() + PROFILE_RELAY_QUERY_MS,
      signal: AbortSignal.any([signal, AbortSignal.timeout(PROFILE_RELAY_RESULT_MS)]),
      onEvents: onProgress && (batch => {
        if (signal.aborted) { return; }
        for (const event of batch) { cached.set(event.id, event); }
        onProgress(project([...cached.values()], preferredPubkeys, text, false));
      }),
    }), frontier,
  ]);
  signal.throwIfAborted();
  return project(report.events.map(({ event }) => event), preferredPubkeys, text, report.complete === true);
}

function project(
  events: NostrVerifiedEvent[], preferredPubkeys: ReadonlySet<string>, text: string, complete: boolean,
): PublicPeopleSearchResult {
  const profilesByPubkey = new Map<string, ProfileRecord>();
  for (const event of events) {
    const profile = projectSearchableProfileEvent(event);
    if (!profile) { continue; }
    // An address in a signed event remains self-asserted until DNS resolution.
    const candidate = { ...profile, nip05: null };
    const newest = preferNewerProfileRecord(profilesByPubkey.get(candidate.pubkey), candidate);
    if (newest) { profilesByPubkey.set(candidate.pubkey, newest); }
  }
  return {
    profiles: [...profilesByPubkey.values()]
      .filter((profile) => profileSearchRank(profile, text).textScore >= MIN_LEXICAL_MATCH_SCORE),
    preferredPubkeys,
    complete,
  };
}
