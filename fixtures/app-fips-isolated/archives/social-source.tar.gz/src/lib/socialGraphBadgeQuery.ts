import type { SocialGraph } from 'nostr-social-graph';
import {
  MAX_VISIBLE_FOLLOW_DISTANCE,
  viewerGraphViewFromGraph,
  type ViewerGraphView,
} from './socialGraphOvermute';

export const MAX_SOCIAL_GRAPH_BADGE_PUBKEYS = 128;
export type SocialGraphBadge = {
  pubkey: string;
  /** Follow distance from the viewer, or null when unreachable. */
  distance: number | null;
  followedByFriends: number;
  muted: boolean;
  /**
   * iris-client's `shouldHideUser`: muted, overmuted, or farther than
   * `MAX_VISIBLE_FOLLOW_DISTANCE` (unreachable included) in the web of trust.
   */
  hidden: boolean;
};

export function validateSocialGraphBadgeQuery(viewer: string, pubkeys: readonly string[]): void {
  if (!/^[0-9a-f]{64}$/.test(viewer)
    || !Array.isArray(pubkeys) || pubkeys.length > MAX_SOCIAL_GRAPH_BADGE_PUBKEYS
    || pubkeys.some((pubkey) => !/^[0-9a-f]{64}$/.test(pubkey))) {
    throw new RangeError('Invalid social graph badge query');
  }
}

/** Project viewer relationships; never reroot or recalculate the shared graph. */
export function socialGraphBadgesFromGraph(
  graph: SocialGraph,
  viewer: string,
  pubkeys: readonly string[],
  view: ViewerGraphView = viewerGraphViewFromGraph(graph, viewer),
): SocialGraphBadge[] {
  validateSocialGraphBadgeQuery(viewer, pubkeys);
  // The graph's public getters allocate IDs for unknown keys. Read-only name
  // lookups must not grow the bounded worker graph.
  const { ids, followedByUser, followersByUser, mutedByUser } = graph.getInternalData();
  const viewerId = ids.has(viewer) ? ids.id(viewer) : undefined;
  const follows = viewerId === undefined ? undefined : followedByUser.get(viewerId);
  const mutes = viewerId === undefined ? undefined : mutedByUser.get(viewerId);

  return pubkeys.map((pubkey) => {
    const target = ids.has(pubkey) ? ids.id(pubkey) : undefined;
    const followers = target === undefined ? undefined : followersByUser.get(target);
    let followedByFriends = 0;
    if (follows?.size && followers?.size) {
      const [smaller, larger] = followers.size < follows.size ? [followers, follows] : [follows, followers];
      for (const follower of smaller) {
        if (follower !== target && follower !== viewerId && larger.has(follower)) {followedByFriends += 1;}
      }
    }
    const reach = target === undefined ? undefined : view.distances.get(target);
    const distance = pubkey === viewer ? 0 : view.rootedAtViewer ? reach ?? null : null;
    const muted = target !== undefined && !!mutes?.has(target);
    const hidden = pubkey !== viewer && (
      muted
      || (target !== undefined && view.overmutedIds.has(target))
      || reach === undefined
      || reach > MAX_VISIBLE_FOLLOW_DISTANCE
    );
    return { pubkey, distance, followedByFriends, muted, hidden };
  });
}
