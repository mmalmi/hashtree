import type { SocialGraph } from 'nostr-social-graph';

export const MAX_SOCIAL_GRAPH_BADGE_PUBKEYS = 128;
export type SocialGraphBadge = {
  pubkey: string;
  distance: 0 | 1 | 2 | 3 | null;
  followedByFriends: number;
  muted: boolean;
};

export function validateSocialGraphBadgeQuery(viewer: string, pubkeys: readonly string[]): void {
  if (!/^[0-9a-f]{64}$/.test(viewer)
    || !Array.isArray(pubkeys) || pubkeys.length > MAX_SOCIAL_GRAPH_BADGE_PUBKEYS
    || pubkeys.some((pubkey) => !/^[0-9a-f]{64}$/.test(pubkey))) {
    throw new RangeError('Invalid social graph badge query');
  }
}

/** Project nearby relationships; never reroot or recalculate the shared graph. */
export function socialGraphBadgesFromGraph(
  graph: SocialGraph, viewer: string, pubkeys: readonly string[],
): SocialGraphBadge[] {
  validateSocialGraphBadgeQuery(viewer, pubkeys);
  // The graph's public getters allocate IDs for unknown keys. Read-only name
  // lookups must not grow the bounded worker graph.
  const ids = graph.getInternalData().ids;
  const follows = ids.has(viewer) ? graph.getFollowedByUser(viewer) : new Set<string>();
  const mutes = ids.has(viewer) ? graph.getMutedByUser(viewer) : new Set<string>();
  let friendsOfFriends: Set<string> | null = null;
  function isFollowedByFriendsOfFriends(pubkey: string): boolean {
    if (!ids.has(pubkey) || follows.size === 0) {return false;}
    friendsOfFriends ??= new Set([...follows].flatMap((friend) =>
      ids.has(friend) ? [...graph.getFollowedByUser(friend)] : []));
    for (const follower of graph.getFollowersByUser(pubkey)) {
      if (friendsOfFriends.has(follower)) {return true;}
    }
    return false;
  }
  return pubkeys.map((pubkey) => {
    let followedByFriends = 0;
    for (const follower of ids.has(pubkey) ? graph.getFollowersByUser(pubkey) : []) {
      if (follows.has(follower)) {followedByFriends += 1;}
    }
    return {
      pubkey,
      distance: pubkey === viewer ? 0 : follows.has(pubkey) ? 1 : followedByFriends > 0 ? 2
        : isFollowedByFriendsOfFriends(pubkey) ? 3 : null,
      followedByFriends,
      muted: mutes.has(pubkey),
    };
  });
}
