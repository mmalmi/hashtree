import type { CID } from '@hashtree/core';
import * as nip19 from 'nostr-tools/nip19';
import {
  loadEventByRef,
  loadNoteLikes,
  loadNoteReposts,
  loadNoteZaps,
  loadProfilesForPubkeys,
  type NoteDetailListKind,
} from './nostrIndex';
import {
  extractFollowPubkeys,
  isHexEventId,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import { validateZapReceipt } from './zapReceipt';
import { createEmptyNoteDetailEvents, type NoteDetailEventsByKind } from './appDataUtils';
import { mergeProfileMaps } from './profileRecords';
import {
  loadRoutedAddressedNotificationEventsPage,
  NOTIFICATION_EVENT_KINDS,
} from './notificationPagination';
import type { RecentTextNoteCursor } from './recentTextNoteCursor';
import { routedLatestEventByAuthorKind } from './routedEventReads';

export type NotificationItem = {
  id: string;
  kind: 'like' | 'mention' | 'repost' | 'reply' | 'zap';
  actorEvent: RawEvent;
  targetEvent: RawEvent | null;
  targetRef: string;
  bits?: number;
};

export type NotificationDataPage = {
  contactsEvent: RawEvent | null;
  cursor: RecentTextNoteCursor | null;
  follows: Set<string>;
  hasMore: boolean;
  notifications: NotificationItem[];
  profiles: Map<string, ProfileRecord>;
};

export const NOTE_DETAIL_PAGE_SIZE = 24;
export const NOTE_DETAIL_MAX_EVENTS = 600;
export type NoteDetailCursorByKind = Record<NoteDetailListKind, string | null>;

export type NoteDetailHasMoreByKind = Record<NoteDetailListKind, boolean>;

export type NoteDetailKindData = {
  events: RawEvent[];
  hasMore: boolean;
  nextCursor: string | null;
  profiles: Map<string, ProfileRecord>;
};

export type NoteDetailKindEventsData = Omit<NoteDetailKindData, 'profiles'>;

export function createEmptyNoteDetailHasMore(): NoteDetailHasMoreByKind {
  return { likes: false, reposts: false, zaps: false };
}

export function createNoteDetailPage(
  events: RawEvent[],
  limit: number,
): { events: RawEvent[]; hasMore: boolean } {
  const normalizedLimit = normalizeNoteDetailLimit(limit);
  return {
    events: events.slice(0, normalizedLimit),
    hasMore: events.length > normalizedLimit,
  };
}

function normalizeNoteDetailLimit(limit: number): number {
  return Number.isFinite(limit)
    ? Math.max(1, Math.min(NOTE_DETAIL_MAX_EVENTS, Math.trunc(limit)))
    : NOTE_DETAIL_PAGE_SIZE;
}

async function loadNoteDetailEventsForKind(
  roots: CID[],
  targetId: string,
  kind: NoteDetailListKind,
  limit: number,
): Promise<RawEvent[]> {
  if (kind === 'likes') {
    return await loadNoteLikes(roots, targetId, { limit });
  }
  if (kind === 'reposts') {
    return await loadNoteReposts(roots, targetId, { limit });
  }
  return await loadNoteZaps(roots, targetId, { limit });
}

function getNoteDetailActorPubkeys(
  targetId: string,
  kind: NoteDetailListKind,
  events: RawEvent[],
): string[] {
  if (kind !== 'zaps') {
    return events.map((event) => event.pubkey);
  }
  return events.flatMap((event) => {
    const validated = validateZapReceipt(event, { eventId: targetId });
    return validated ? [validated.senderPubkey] : [];
  });
}

async function loadNoteDetailProfiles(
  roots: CID[],
  actorPubkeys: string[],
  cachedProfiles: Map<string, ProfileRecord>,
): Promise<Map<string, ProfileRecord>> {
  const uniqueActorPubkeys = [...new Set(actorPubkeys)];
  const missingActorPubkeys = uniqueActorPubkeys.filter((pubkey) => !cachedProfiles.has(pubkey));
  const profileMaps = missingActorPubkeys.length === 0
    ? []
    : await Promise.all(
        roots.map(async (candidateRoot) => (
          await loadProfilesForPubkeys(candidateRoot, missingActorPubkeys)
        )),
      );
  const loadedProfiles = mergeProfileMaps(...profileMaps);
  const profiles = new Map<string, ProfileRecord>();
  for (const pubkey of uniqueActorPubkeys) {
    const profile = loadedProfiles.get(pubkey) ?? cachedProfiles.get(pubkey);
    if (profile) {
      profiles.set(pubkey, profile);
    }
  }
  return profiles;
}

export async function loadNoteDetailKindEvents(
  roots: CID[],
  target: RawEvent,
  kind: NoteDetailListKind,
  options: {
    limit?: number;
  } = {},
): Promise<NoteDetailKindEventsData> {
  const limit = normalizeNoteDetailLimit(options.limit ?? NOTE_DETAIL_PAGE_SIZE);
  const lookaheadLimit = Math.min(NOTE_DETAIL_MAX_EVENTS, limit + 1);
  const page = createNoteDetailPage(
    await loadNoteDetailEventsForKind(roots, target.id, kind, lookaheadLimit),
    limit,
  );
  return {
    ...page,
    nextCursor: null,
  };
}

export async function loadNoteDetailKindProfiles(
  roots: CID[],
  target: RawEvent,
  cachedProfiles: Map<string, ProfileRecord>,
  kind: NoteDetailListKind,
  events: RawEvent[],
): Promise<Map<string, ProfileRecord>> {
  return await loadNoteDetailProfiles(
    roots,
    getNoteDetailActorPubkeys(target.id, kind, events),
    cachedProfiles,
  );
}

export async function loadNoteDetailKindData(
  roots: CID[],
  target: RawEvent,
  cachedProfiles: Map<string, ProfileRecord>,
  kind: NoteDetailListKind,
  options: {
    limit?: number;
  } = {},
): Promise<NoteDetailKindData> {
  const loaded = await loadNoteDetailKindEvents(roots, target, kind, options);
  return {
    ...loaded,
    profiles: await loadNoteDetailKindProfiles(
      roots,
      target,
      cachedProfiles,
      kind,
      loaded.events,
    ),
  };
}

function compareNotificationItems(left: NotificationItem, right: NotificationItem): number {
  return right.actorEvent.created_at - left.actorEvent.created_at
    || left.actorEvent.id.localeCompare(right.actorEvent.id);
}

function referencesReplyTarget(event: RawEvent): boolean {
  if (event.kind === 1_111) {
    return event.tags.some((tag) => ['e', 'a', 'i'].includes(tag[0] ?? ''));
  }
  if (event.kind !== 1 && event.kind !== 20) {
    return false;
  }
  return event.tags.some((tag) => (
    tag[0] === 'e' && (tag[3] ?? '').toLowerCase() !== 'mention'
  ));
}

export function getNotificationTargetEventId(event: RawEvent): string | null {
  if (event.kind !== 6 && event.kind !== 7 && event.kind !== 16 && event.kind !== 9_735) {
    return null;
  }
  const value = [...event.tags]
    .reverse()
    .find((tag) => tag[0] === 'e' && isHexEventId(tag[1] ?? ''))?.[1];
  return value ? value.toLowerCase() : null;
}

export function getNotificationTargetReference(event: RawEvent): string | null {
  const eventId = getNotificationTargetEventId(event);
  if (eventId) {
    return eventId;
  }
  if (event.kind !== 6 && event.kind !== 7 && event.kind !== 16 && event.kind !== 9_735) {
    return null;
  }

  const coordinate = [...event.tags].reverse().find((tag) => tag[0] === 'a')?.[1] ?? '';
  const firstSeparator = coordinate.indexOf(':');
  const secondSeparator = coordinate.indexOf(':', firstSeparator + 1);
  const kind = Number(coordinate.slice(0, firstSeparator));
  const pubkey = coordinate.slice(firstSeparator + 1, secondSeparator).toLowerCase();
  const identifier = coordinate.slice(secondSeparator + 1);
  if (
    firstSeparator <= 0
    || secondSeparator <= firstSeparator + 1
    || !Number.isInteger(kind)
    || kind < 30_000
    || kind >= 40_000
    || !/^[0-9a-f]{64}$/.test(pubkey)
  ) {
    return null;
  }
  try {
    return nip19.naddrEncode({ identifier, kind, pubkey });
  } catch {
    return null;
  }
}

export function createNotificationItem(
  event: RawEvent,
  viewerPubkey: string,
  targetEvent: RawEvent | null = null,
): NotificationItem | null {
  const normalizedViewer = viewerPubkey.trim().toLowerCase();
  if (
    (event.kind !== 9_735 && event.pubkey === normalizedViewer)
    || !(NOTIFICATION_EVENT_KINDS as readonly number[]).includes(event.kind)
    || !event.tags.some((tag) => tag[0]?.toLowerCase() === 'p' && tag[1]?.toLowerCase() === normalizedViewer)
  ) {
    return null;
  }

  if (event.kind === 1 || event.kind === 20 || event.kind === 1_111 || event.kind === 30_023) {
    return {
      id: event.id,
      kind: referencesReplyTarget(event) ? 'reply' : 'mention',
      actorEvent: event,
      targetEvent: event,
      targetRef: event.id,
    };
  }

  const targetRef = targetEvent?.id ?? getNotificationTargetReference(event) ?? event.id;
  if (event.kind === 7) {
    return { id: event.id, kind: 'like', actorEvent: event, targetEvent, targetRef };
  }
  if (event.kind === 6 || event.kind === 16) {
    return { id: event.id, kind: 'repost', actorEvent: event, targetEvent, targetRef };
  }
  const targetEventId = getNotificationTargetEventId(event);
  const targetAddress = targetEventId
    ? null
    : event.tags.find((tag) => tag[0] === 'a')?.[1] ?? null;
  const validatedZap = validateZapReceipt(event, {
    eventId: targetEventId,
    address: targetAddress,
    recipientPubkey: normalizedViewer,
  });
  if (!validatedZap || validatedZap.senderPubkey === normalizedViewer) {
    return null;
  }
  return {
    id: event.id,
    kind: 'zap',
    actorEvent: validatedZap.request,
    targetEvent,
    targetRef,
    bits: validatedZap.bits,
  };
}

export function mergeNotificationItems(...itemLists: NotificationItem[][]): NotificationItem[] {
  const byId = new Map<string, NotificationItem>();
  for (const item of itemLists.flat()) {
    const existing = byId.get(item.id);
    if (!existing || (!existing.targetEvent && item.targetEvent)) {
      byId.set(item.id, item);
    }
  }
  return [...byId.values()].sort(compareNotificationItems);
}

export async function loadNoteDetailData(
  roots: CID[],
  target: RawEvent,
  cachedProfiles: Map<string, ProfileRecord>,
  options: { limit?: number } = {},
): Promise<{
  cursorsByKind: NoteDetailCursorByKind;
  eventsByKind: NoteDetailEventsByKind;
  hasMoreByKind: NoteDetailHasMoreByKind;
  profiles: Map<string, ProfileRecord>;
}> {
  const limit = normalizeNoteDetailLimit(options.limit ?? NOTE_DETAIL_PAGE_SIZE);
  const [likes, reposts, zaps] = await Promise.all([
    loadNoteDetailKindData(roots, target, cachedProfiles, 'likes', { limit }),
    loadNoteDetailKindData(roots, target, cachedProfiles, 'reposts', { limit }),
    loadNoteDetailKindData(roots, target, cachedProfiles, 'zaps', { limit }),
  ]);

  return {
    cursorsByKind: {
      likes: likes.nextCursor,
      reposts: reposts.nextCursor,
      zaps: zaps.nextCursor,
    },
    eventsByKind: {
      likes: likes.events,
      reposts: reposts.events,
      zaps: zaps.events,
    },
    hasMoreByKind: {
      likes: likes.hasMore,
      reposts: reposts.hasMore,
      zaps: zaps.hasMore,
    },
    profiles: mergeProfileMaps(likes.profiles, reposts.profiles, zaps.profiles),
  };
}

export async function loadNotificationsData(
  roots: CID[],
  viewerPubkey: string,
  cachedProfiles: Map<string, ProfileRecord>,
  options: {
    before?: RecentTextNoteCursor;
    includeViewerState?: boolean;
    limit?: number;
  } = {},
): Promise<NotificationDataPage> {
  const limit = Math.max(1, Math.trunc(options.limit ?? 48));
  const contactsCandidatesPromise = options.includeViewerState === false
    ? Promise.resolve([])
    : routedLatestEventByAuthorKind(roots, viewerPubkey, 3).then((event) => [event]);
  const notifications: NotificationItem[] = [];
  let cursor = options.before ?? null;
  let hasMore = true;

  // Self-authored addressed events and malformed interactions do not become
  // notifications. Keep advancing exact raw index pages until the requested
  // visible page is full or every immutable root is exhausted.
  while (notifications.length < limit && hasMore) {
    const addressedPage = await loadRoutedAddressedNotificationEventsPage({
      before: cursor ?? undefined,
      limit,
      roots,
      viewerPubkey,
    });
    if (addressedPage.events.length === 0) {
      hasMore = false;
      break;
    }

    const targetRefs = [...new Set(addressedPage.events
      .map(getNotificationTargetReference)
      .filter((ref): ref is string => Boolean(ref)))];
    const targets = new Map<string, RawEvent>();
    await Promise.all(targetRefs.map(async (ref) => {
      const target = await loadEventByRef(roots, ref);
      if (target) {
        targets.set(ref, target);
      }
    }));

    let filledAtIndex = -1;
    for (let index = 0; index < addressedPage.events.length; index += 1) {
      const event = addressedPage.events[index]!;
      cursor = { createdAt: event.created_at, eventId: event.id };
      const item = createNotificationItem(
        event,
        viewerPubkey,
        targets.get(getNotificationTargetReference(event) ?? '') ?? null,
      );
      if (item) {
        notifications.push(item);
      }
      if (notifications.length >= limit) {
        filledAtIndex = index;
        break;
      }
    }

    if (filledAtIndex >= 0) {
      hasMore = filledAtIndex < addressedPage.events.length - 1 || addressedPage.hasMore;
      break;
    }
    hasMore = addressedPage.hasMore;
  }

  const contactsCandidates = await contactsCandidatesPromise;
  const latestContacts = contactsCandidates[0] ?? null;
  const actorPubkeys = [...new Set(notifications.map((item) => item.actorEvent.pubkey))];
  const missingActorPubkeys = actorPubkeys.filter((pubkey) => !cachedProfiles.has(pubkey));
  const profileMaps = missingActorPubkeys.length === 0
    ? []
    : await Promise.all(
        roots.map(async (candidateRoot) => await loadProfilesForPubkeys(candidateRoot, missingActorPubkeys)),
      );
  const loadedProfiles = mergeProfileMaps(...profileMaps);
  const profiles = new Map<string, ProfileRecord>();
  for (const pubkey of actorPubkeys) {
    const profile = loadedProfiles.get(pubkey) ?? cachedProfiles.get(pubkey);
    if (profile) {
      profiles.set(pubkey, profile);
    }
  }

  return {
    notifications,
    cursor,
    hasMore,
    profiles,
    follows: new Set(extractFollowPubkeys(latestContacts)),
    contactsEvent: latestContacts,
  };
}

export function createEmptyNoteDetailData(): {
  eventsByKind: NoteDetailEventsByKind;
  hasMoreByKind: NoteDetailHasMoreByKind;
  profiles: Map<string, ProfileRecord>;
} {
  return {
    eventsByKind: createEmptyNoteDetailEvents(),
    hasMoreByKind: createEmptyNoteDetailHasMore(),
    profiles: new Map(),
  };
}
