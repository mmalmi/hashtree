import { canSignAccount, getNostrExtension } from './accountSigner';
import type { CID } from '@hashtree/core';
import {
  createAccountFromInput,
  createFreshAccount,
  accountsStore,
  removeAccount,
  setActiveAccount,
  upsertAndActivateAccount,
  type SocialAccount,
} from './accounts';

type AccountActionDeps = {
  accountImportError: string;
  accountInput: string;
  activeAccount: SocialAccount | null;
  pageError: string;
  root: CID | null;
  hydrateAccountProfiles: (root: CID) => Promise<void>;
  navigateHome: () => void;
  resetActiveAccountUiState: (nextViewerPubkey?: string | null) => void;
  restartCurrentViewLoad: () => void;
};

export function createAppAccountActions(deps: AccountActionDeps) {
  function handleAccountInput(value: string): void {
    deps.accountInput = value;
    deps.accountImportError = '';
  }

  async function handleCreateAccount(): Promise<void> {
    const account = createFreshAccount();
    upsertAndActivateAccount(account);
    deps.resetActiveAccountUiState(account.pubkey);
    deps.navigateHome();
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
  }

  async function handleExtensionLogin(): Promise<void> {
    deps.accountImportError = '';
    try {
      const extension = getNostrExtension();
      if (!extension) {throw new Error('No Nostr extension is available in this browser.');}
      const pubkey = await extension.getPublicKey();
      if (!/^[0-9a-f]{64}$/i.test(pubkey)) {throw new Error('The extension returned an invalid account.');}
      const imported = createAccountFromInput(pubkey);
      if (!imported) {throw new Error('The extension returned an invalid account.');}
      const existing = accountsStore.getState().accounts.find((account) => account.pubkey === imported.pubkey);
      const account: SocialAccount = existing?.nsec && canSignAccount(existing)
        ? existing
        : { ...imported, method: 'nip07', nsec: undefined };
      upsertAndActivateAccount(account);
      deps.resetActiveAccountUiState(account.pubkey);
      deps.navigateHome();
      if (deps.root) {await deps.hydrateAccountProfiles(deps.root);}
    } catch (error) {
      deps.accountImportError = error instanceof Error ? error.message : 'Could not connect to your Nostr extension.';
    }
  }

  async function handleImportAccount(): Promise<void> {
    const account = createAccountFromInput(deps.accountInput);
    if (!account) {
      deps.accountImportError = "That account code didn't look right.";
      return;
    }
    upsertAndActivateAccount(account);
    deps.resetActiveAccountUiState(account.pubkey);
    deps.navigateHome();
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
  }

  async function handleSwitchAccount(pubkey: string): Promise<void> {
    if (pubkey === deps.activeAccount?.pubkey) {
      return;
    }
    setActiveAccount(pubkey);
    deps.resetActiveAccountUiState(pubkey);
    deps.navigateHome();
  }

  async function handleViewAsProfile(pubkey: string): Promise<void> {
    const account = createAccountFromInput(pubkey);
    if (!account) {
      deps.pageError = "Couldn't view as this profile.";
      return;
    }
    if (account.pubkey === deps.activeAccount?.pubkey) {
      return;
    }
    upsertAndActivateAccount(account);
    deps.resetActiveAccountUiState(account.pubkey);
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
    deps.restartCurrentViewLoad();
  }

  async function handleRemoveAccount(pubkey: string): Promise<void> {
    const wasActive = pubkey === deps.activeAccount?.pubkey;
    if (!removeAccount(pubkey)) {
      return;
    }
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
    if (wasActive) {
      deps.resetActiveAccountUiState(accountsStore.getState().activeAccountPubkey);
      deps.navigateHome();
    }
  }

  function applyViewerOverride(value: string): void {
    const account = createAccountFromInput(value);
    if (account) {
      upsertAndActivateAccount(account);
    }
  }

  return {
    applyViewerOverride,
    handleAccountInput,
    handleCreateAccount,
    handleImportAccount,
    handleExtensionLogin,
    handleRemoveAccount,
    handleSwitchAccount,
    handleViewAsProfile,
  };
}
