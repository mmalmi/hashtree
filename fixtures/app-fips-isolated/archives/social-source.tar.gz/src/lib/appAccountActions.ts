import { reportAppError, type AppError } from './appError';
import { canSignAccount, getNostrExtension } from './accountSigner';
import type { CID } from '@hashtree/core';
import {
  createAccountFromInput,
  createRemoteAccount,
  createFreshAccount,
  accountsStore,
  removeAccount,
  setActiveAccount,
  upsertAndActivateAccount,
  type SocialAccount,
} from './accounts';
import { publishEvent } from './nostrPublish';
import { createProfileMetadataEvent } from './profileMetadata';

type AccountActivationOptions = { preserveRoute?: boolean; signal?: AbortSignal };

type AccountActionDeps = {
  accountImportError: string;
  accountInput: string;
  activeAccount: SocialAccount | null;
  pageError: AppError;
  root: CID | null;
  hydrateAccountProfiles: (root: CID) => Promise<void>;
  navigateHome: () => void;
  resetActiveAccountUiState: (nextViewerPubkey?: string | null) => void;
  restartCurrentViewLoad: () => void;
};

export function createAppAccountActions(deps: AccountActionDeps) {
  function handleAccountInput(value: string, pasted = false, options?: AccountActivationOptions): void {
    deps.accountInput = value;
    deps.accountImportError = '';
    void handleImportAccount(pasted, options);
  }

  function openAfterAccountActivation(pubkey: string, options?: AccountActivationOptions): void {
    deps.resetActiveAccountUiState(pubkey);
    if (options?.preserveRoute) {
      deps.restartCurrentViewLoad();
    } else {
      deps.navigateHome();
    }
  }

  async function finishSignIn(account: SocialAccount, options?: AccountActivationOptions): Promise<void> {
    upsertAndActivateAccount(account);
    openAfterAccountActivation(account.pubkey, options);
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
  }

  async function handleCreateAccount(options: AccountActivationOptions & { name?: string } = {}): Promise<void> {
    if (options.signal?.aborted) { return; }
    const name = options.name?.trim();
    const account = createFreshAccount({ name });
    const metadata = createProfileMetadataEvent(account, name ? { displayName: name } : {});
    const activation = finishSignIn(account, options);
    try {
      publishEvent(metadata);
    } catch (error) {
      deps.pageError = reportAppError('Could not save the profile details.', error, name ? [name] : []);
    }
    await activation;
  }

  async function handleRemoteLogin(signal: AbortSignal, options?: AccountActivationOptions): Promise<void> {
    if (signal.aborted || options?.signal?.aborted) { return; }
    const requestSignal = options?.signal ? AbortSignal.any([signal, options.signal]) : signal;
    deps.accountImportError = '';
    try {
      const { requestBrowserSigner } = await import('@iris/identity/browserSigner');
      if (requestSignal.aborted) { return; }
      const session = await requestBrowserSigner({ name: 'Iris Social', permissions: 'sign_event', signal: requestSignal });
      if (!session || requestSignal.aborted) {return;}
      await finishSignIn(createRemoteAccount(session), options);
    } catch {
      if (!requestSignal.aborted) {deps.accountImportError = 'Could not connect to your signer. Please try again.';}
    }
  }

  async function handleExtensionLogin(options?: AccountActivationOptions): Promise<void> {
    if (options?.signal?.aborted) { return; }
    deps.accountImportError = '';
    try {
      const extension = getNostrExtension();
      if (!extension) {throw new Error('No Nostr extension is available in this browser.');}
      const pubkey = await extension.getPublicKey();
      if (options?.signal?.aborted) { return; }
      if (!/^[0-9a-f]{64}$/i.test(pubkey)) {throw new Error('The extension returned an invalid public key.');}
      const imported = createAccountFromInput(pubkey);
      if (!imported) {throw new Error('The extension returned an invalid public key.');}
      const existing = accountsStore.getState().accounts.find((account) => account.pubkey === imported.pubkey);
      const account: SocialAccount = existing?.nsec && canSignAccount(existing)
        ? existing
        : { ...imported, method: 'nip07', nsec: undefined };
      await finishSignIn(account, options);
    } catch (error) {
      if (options?.signal?.aborted) { return; }
      deps.accountImportError = error instanceof Error ? error.message : 'Could not connect to your Nostr extension.';
    }
  }

  async function handleImportAccount(showError = true, options?: AccountActivationOptions): Promise<void> {
    if (options?.signal?.aborted) { return; }
    const input = deps.accountInput.trim();
    if (!input) {
      return;
    }
    const account = createAccountFromInput(input);
    if (!account) {
      if (showError) {
        deps.accountImportError = 'Enter a valid secret or public key.';
      }
      return;
    }
    await finishSignIn(account, options);
  }

  async function handleSwitchAccount(pubkey: string, options?: AccountActivationOptions): Promise<void> {
    if (options?.signal?.aborted || pubkey === deps.activeAccount?.pubkey) {
      return;
    }
    setActiveAccount(pubkey);
    openAfterAccountActivation(pubkey, options);
  }

  async function handleViewAsProfile(pubkey: string): Promise<void> {
    const account = createAccountFromInput(pubkey);
    if (!account) {
      deps.pageError = "Couldn't view as this profile.";
      return;
    }
    if (account.pubkey === deps.activeAccount?.pubkey) {
      return;
    }
    upsertAndActivateAccount(account);
    deps.resetActiveAccountUiState(account.pubkey);
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
    deps.restartCurrentViewLoad();
  }

  async function handleRemoveAccount(pubkey: string): Promise<void> {
    const state = accountsStore.getState();
    const profile = state.accounts.find((account) => account.pubkey === pubkey);
    if (!profile) {return;}
    const wasActive = pubkey === state.activeAccountPubkey;
    const prompt = wasActive
      ? 'Sign out of this profile on this device?'
      : 'Remove this profile from this device?';
    const message = profile.nsec ? `${prompt} You’ll need your secret key to sign in again.` : prompt;
    if (!window.confirm(message) || !removeAccount(pubkey)) {
      return;
    }
    if (wasActive) {
      deps.resetActiveAccountUiState(accountsStore.getState().activeAccountPubkey);
      deps.navigateHome();
    }
    if (deps.root) {
      await deps.hydrateAccountProfiles(deps.root);
    }
  }

  function applyViewerOverride(value: string): void {
    const account = createAccountFromInput(value);
    if (account) {
      upsertAndActivateAccount(account);
    }
  }

  return {
    applyViewerOverride,
    handleAccountInput,
    handleCreateAccount,
    handleImportAccount,
    handleRemoteLogin,
    handleExtensionLogin,
    handleRemoveAccount,
    handleSwitchAccount,
    handleViewAsProfile,
  };
}
