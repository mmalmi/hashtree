import type { CID } from '@hashtree/core';
import type { SocialAccount } from './accounts';
import type { ProfileRecord } from './nostr';
import { loadProfileRecord } from './nostrIndex';
import { mergeProfilesIntoMap } from './appProfiles';

export function getCurrentActiveAccountPubkey(
  activeAccountPubkey: string | null,
  accounts: Array<{ pubkey: string }>,
): string | null {
  return activeAccountPubkey ?? accounts[0]?.pubkey ?? null;
}

export function shouldPreferStarterFeed(
  account: SocialAccount | null,
  accountCount: number,
): boolean {
  if (!account || account.method !== 'generated') {
    return false;
  }

  const ageMs = Date.now() - account.createdAt;
  return ageMs < 60_000 && account.updatedAt === account.createdAt && accountCount === 1;
}

export async function hydrateAccountProfiles(
  currentRoot: CID,
  pubkeys: string[],
  currentProfiles: Map<string, ProfileRecord>,
): Promise<Map<string, ProfileRecord>> {
  if (pubkeys.length === 0) {
    return currentProfiles;
  }

  const snapshots = await Promise.all(
    pubkeys.map(async (pubkey) => [pubkey, await loadProfileRecord(currentRoot, pubkey)] as const),
  );
  return mergeProfilesIntoMap(
    currentProfiles,
    new Map(
      snapshots.flatMap(([pubkey, profile]) => profile ? [[pubkey, profile] as const] : []),
    ),
  );
}
