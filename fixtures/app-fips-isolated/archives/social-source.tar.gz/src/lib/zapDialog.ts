import { writable } from 'svelte/store';
import type { ProfileRecord, RawEvent } from './nostr';

export type ZapDialogInvoice = { invoice: string; amountBits: number };

export type ZapDialogRequest = {
  event: RawEvent;
  profile: ProfileRecord | null;
  /** An invoice no wallet could pay, shown for scanning instead of the form. */
  invoice: ZapDialogInvoice | null;
};

/** The note whose zap dialog is open; any engagement bar can ask for it. */
export const zapDialogRequest = writable<ZapDialogRequest | null>(null);

export function openZapDialog(
  event: RawEvent,
  profile: ProfileRecord | null,
  invoice: ZapDialogInvoice | null = null,
): void {
  zapDialogRequest.set({ event, profile, invoice });
}

export function closeZapDialog(): void {
  zapDialogRequest.set(null);
}
