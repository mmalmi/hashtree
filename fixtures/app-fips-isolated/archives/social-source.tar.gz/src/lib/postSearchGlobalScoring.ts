import { HashTree, LinkType, type CID, type Store, type TreeEntry } from '@hashtree/core';
import {
  BTree,
  RANKED_SEARCH_SEGMENT_FORMAT,
  RankedSearchIndex,
  type RankedSearchCorpusStatistics,
  type RankedSearchFieldManifest,
  type RankedSearchScoringContext,
  type RankedTermStats,
} from '@hashtree/index';
import {
  aggregateFields,
  hasCompatibleFields,
  requiredField,
} from './postSearchGlobalScoringFields';

export const POST_SEARCH_GLOBAL_SCORING_FORMAT =
  'iris-social/ranked-post-search-global-scoring@1' as const;

const POST_SEARCH_NORMALIZATION = 'NFKC-lowercase@1' as const;
const GLOBAL_SCORING_MANIFEST_ENTRY = 'manifest.json' as const;
const GLOBAL_SCORING_TERMS_ENTRY = 'terms' as const;
const MAX_GLOBAL_SCORING_MANIFEST_BYTES = 64 * 1024;
const SEGMENT_READ_CONCURRENCY = 16;

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export interface PostSearchGlobalScoringDescriptor {
  format: typeof POST_SEARCH_GLOBAL_SCORING_FORMAT;
  entry: 'global-scoring';
}

export interface PostSearchGlobalScoringManifest extends RankedSearchCorpusStatistics {
  format: typeof POST_SEARCH_GLOBAL_SCORING_FORMAT;
  normalization: typeof POST_SEARCH_NORMALIZATION;
  termCount: number;
}

export interface PostSearchGlobalScoringIndex {
  root: CID;
  termsRoot: CID | null;
  manifest: PostSearchGlobalScoringManifest;
}

type GlobalScoringExtensionOptions = {
  signal?: AbortSignal;
};

type SegmentInput = {
  root: CID;
  documentCount: number;
};

/**
 * Merge immutable segment statistics into one catalog-wide BM25F scoring index.
 * Segment term streams are already sorted, so this never retains all terms or
 * retokenizes the caller's event documents.
 */
export async function buildPostSearchGlobalScoring(
  store: Store,
  segments: readonly SegmentInput[],
  expectedFields: Readonly<Record<string, {
    boost?: number;
    lengthNormalization?: number;
  }>>,
  expectedMaxTokensPerField: number,
): Promise<PostSearchGlobalScoringIndex> {
  const index = new RankedSearchIndex(store);
  const manifests = await mapConcurrent(segments, SEGMENT_READ_CONCURRENCY, async (segment) => {
    const manifest = await index.readManifest(segment.root);
    if (manifest.format !== RANKED_SEARCH_SEGMENT_FORMAT
      || manifest.documentCount !== segment.documentCount
      || manifest.maxTokensPerField !== expectedMaxTokensPerField
      || !hasCompatibleFields(manifest.fields, expectedFields)) {
      throw new Error('Ranked segment does not match global scoring configuration');
    }
    return manifest;
  });
  const k1 = manifests[0]?.k1 ?? 1.2;
  if (manifests.some((manifest) => manifest.k1 !== k1)) {
    throw new Error('Ranked segments use inconsistent BM25 saturation parameters');
  }
  const documentCount = sumSafeIntegers(
    manifests.map((manifest) => manifest.documentCount),
    'catalog-global document count',
  );
  const fields = aggregateFields(manifests, expectedFields);
  const sources = segments.map((segment, indexPosition) => checkedTermStream(
    index.streamTermStatistics(segment.root),
    manifests[indexPosition].termCount,
    manifests[indexPosition].documentCount,
    new Set(fields.map((field) => field.name)),
  ));
  let termCount = 0;
  const mergedTerms = mergeSortedTermStatistics(sources, documentCount, () => {
    termCount = addSafeIntegers(termCount, 1, 'catalog-global term count');
  });
  const termsRoot = await new BTree(store).buildSortedAsync(mergedTerms);
  const manifest: PostSearchGlobalScoringManifest = {
    format: POST_SEARCH_GLOBAL_SCORING_FORMAT,
    normalization: POST_SEARCH_NORMALIZATION,
    documentCount,
    termCount,
    k1,
    fields,
  };
  return await writePostSearchGlobalScoring(store, manifest, termsRoot);
}

/**
 * Extend authenticated catalog-global statistics without rescanning the base
 * vocabulary. Only terms present in the immutable appended segments traverse
 * the persistent global B-tree; untouched branches are retained by CID.
 */
export async function extendPostSearchGlobalScoring(
  store: Store,
  base: PostSearchGlobalScoringIndex,
  appendedSegments: readonly SegmentInput[],
  expectedFields: Readonly<Record<string, {
    boost?: number;
    lengthNormalization?: number;
  }>>,
  expectedMaxTokensPerField: number,
  options: GlobalScoringExtensionOptions = {},
): Promise<PostSearchGlobalScoringIndex> {
  throwIfAborted(options.signal);
  if (!hasCompatibleFields(base.manifest.fields, expectedFields)) {
    throw new Error('Base global scoring fields are incompatible with appended segments');
  }
  if (appendedSegments.length === 0) {
    return base;
  }

  const index = new RankedSearchIndex(store);
  const manifests = await mapConcurrent(
    appendedSegments,
    SEGMENT_READ_CONCURRENCY,
    async (segment) => {
      throwIfAborted(options.signal);
      const manifest = await index.readManifest(segment.root);
      if (manifest.format !== RANKED_SEARCH_SEGMENT_FORMAT
        || manifest.documentCount !== segment.documentCount
        || manifest.maxTokensPerField !== expectedMaxTokensPerField
        || !hasCompatibleFields(manifest.fields, expectedFields)
        || manifest.k1 !== base.manifest.k1) {
        throw new Error('Ranked segment does not match incremental global scoring configuration');
      }
      return manifest;
    },
  );
  const documentCount = addSafeIntegers(
    base.manifest.documentCount,
    sumSafeIntegers(
      manifests.map((manifest) => manifest.documentCount),
      'appended catalog-global document count',
    ),
    'incremental catalog-global document count',
  );
  const appendedFields = aggregateFields(manifests, expectedFields);
  const fields = base.manifest.fields.map((field) => {
    const appended = requiredField(appendedFields, field.name);
    return {
      ...field,
      totalLength: addSafeIntegers(
        field.totalLength,
        appended.totalLength,
        `${field.name} incremental total length`,
      ),
      populatedDocumentCount: addSafeIntegers(
        field.populatedDocumentCount,
        appended.populatedDocumentCount,
        `${field.name} incremental populated count`,
      ),
    };
  });
  const fieldNames = new Set(fields.map((field) => field.name));
  const sources = appendedSegments.map((segment, indexPosition) => checkedTermStream(
    index.streamTermStatistics(segment.root),
    manifests[indexPosition].termCount,
    manifests[indexPosition].documentCount,
    fieldNames,
  ));
  const appendedTerms = mergeSortedTermStatistics(sources, documentCount, () => {});
  const terms = new BTree(store);
  let termsRoot = base.termsRoot;
  let termCount = base.manifest.termCount;

  for await (const [term, encodedAppended] of appendedTerms) {
    throwIfAborted(options.signal);
    const appended = parseTermStatistics(encodedAppended, fieldNames, documentCount);
    const encodedBase = await terms.get(termsRoot, term);
    const merged = encodedBase === null
      ? appended
      : mergeTermStatistics([
          parseTermStatistics(encodedBase, fieldNames, base.manifest.documentCount),
          appended,
        ], documentCount);
    termsRoot = await terms.insert(termsRoot, term, encodeTermStatistics(merged));
    if (encodedBase === null) {
      termCount = addSafeIntegers(termCount, 1, 'incremental catalog-global term count');
    }
  }

  const manifest: PostSearchGlobalScoringManifest = {
    format: POST_SEARCH_GLOBAL_SCORING_FORMAT,
    normalization: POST_SEARCH_NORMALIZATION,
    documentCount,
    termCount,
    k1: base.manifest.k1,
    fields,
  };
  return await writePostSearchGlobalScoring(store, manifest, termsRoot);
}

export async function readPostSearchGlobalScoring(
  store: Store,
  root: CID,
  expectedDocumentCount: number,
  expectedFields: Readonly<Record<string, {
    boost?: number;
    lengthNormalization?: number;
  }>>,
  signal?: AbortSignal,
): Promise<PostSearchGlobalScoringIndex> {
  const tree = new HashTree({ store });
  const entries = await tree.listDirectory(root, signal);
  const entriesByName = new Map(entries.map((entry) => [entry.name, entry]));
  const manifestEntry = entriesByName.get(GLOBAL_SCORING_MANIFEST_ENTRY);
  if (!manifestEntry || manifestEntry.type !== LinkType.File) {
    throw new Error('Missing post search global scoring manifest');
  }
  const bytes = await tree.readFile(manifestEntry.cid, {
    maxBytes: MAX_GLOBAL_SCORING_MANIFEST_BYTES,
  });
  if (!bytes) {
    throw new Error('Unreadable post search global scoring manifest');
  }
  const manifest = parseGlobalScoringManifest(
    decoder.decode(bytes),
    expectedDocumentCount,
    expectedFields,
  );
  const termsEntry = entriesByName.get(GLOBAL_SCORING_TERMS_ENTRY);
  if ((manifest.termCount === 0) !== (termsEntry === undefined)) {
    throw new Error('Post search global scoring term coverage is inconsistent');
  }
  if (termsEntry && termsEntry.type !== LinkType.Dir) {
    throw new Error('Invalid post search global scoring term index');
  }
  if (termsEntry && termsEntry.size !== manifest.termCount) {
    throw new Error('Post search global scoring term count is inconsistent');
  }
  const allowedEntries = new Set<string>([
    GLOBAL_SCORING_MANIFEST_ENTRY,
    ...(termsEntry ? [GLOBAL_SCORING_TERMS_ENTRY] : []),
  ]);
  if (entries.some((entry) => !allowedEntries.has(entry.name))) {
    throw new Error('Unexpected post search global scoring entry');
  }
  return { root, termsRoot: termsEntry?.cid ?? null, manifest };
}

/** Read exactly q query statistics directly from the authenticated global B-tree. */
export async function readPostSearchScoringContext(
  store: Store,
  scoring: PostSearchGlobalScoringIndex,
  terms: readonly string[],
): Promise<RankedSearchScoringContext> {
  const uniqueTerms = [...new Set(terms)];
  const termStatistics = new Map<string, RankedTermStats>();
  if (uniqueTerms.length > 0 && scoring.termsRoot) {
    const tree = new BTree(store);
    const rawStats = await Promise.all(uniqueTerms.map((term) => tree.get(scoring.termsRoot, term)));
    const fieldNames = new Set(scoring.manifest.fields.map((field) => field.name));
    for (let index = 0; index < uniqueTerms.length; index += 1) {
      const raw = rawStats[index];
      if (raw === null) {
        continue;
      }
      const stats = parseTermStatistics(raw, fieldNames, scoring.manifest.documentCount);
      termStatistics.set(uniqueTerms[index], stats);
    }
  }
  return {
    corpus: {
      documentCount: scoring.manifest.documentCount,
      k1: scoring.manifest.k1,
      fields: scoring.manifest.fields,
    },
    termStatistics,
  };
}

async function writePostSearchGlobalScoring(
  store: Store,
  manifest: PostSearchGlobalScoringManifest,
  termsRoot: CID | null,
): Promise<PostSearchGlobalScoringIndex> {
  if ((manifest.termCount === 0) !== (termsRoot === null)) {
    throw new Error('Incremental global scoring term coverage is inconsistent');
  }
  const tree = new HashTree({ store });
  const manifestFile = await tree.putFile(encoder.encode(JSON.stringify(manifest)));
  const entries: TreeEntry[] = [{
    name: GLOBAL_SCORING_MANIFEST_ENTRY,
    cid: manifestFile.cid,
    size: manifestFile.size,
    type: LinkType.File,
  }];
  if (termsRoot) {
    entries.push({
      name: GLOBAL_SCORING_TERMS_ENTRY,
      cid: termsRoot,
      size: manifest.termCount,
      type: LinkType.Dir,
    });
  }
  const root = (await tree.putDirectory(entries)).cid;
  return { root, termsRoot, manifest };
}

async function* checkedTermStream(
  source: AsyncIterable<[string, RankedTermStats]>,
  expectedCount: number,
  documentCount: number,
  fieldNames: ReadonlySet<string>,
): AsyncGenerator<[string, RankedTermStats]> {
  let previous: string | null = null;
  let count = 0;
  for await (const [term, stats] of source) {
    if (!term || (previous !== null && term <= previous)) {
      throw new Error('Ranked segment term statistics are not strictly sorted');
    }
    validateTermStatistics(stats, fieldNames, documentCount);
    previous = term;
    count += 1;
    yield [term, stats];
  }
  if (count !== expectedCount) {
    throw new Error(`Ranked segment yielded ${count} term statistics, expected ${expectedCount}`);
  }
}

async function* mergeSortedTermStatistics(
  sources: readonly AsyncIterable<[string, RankedTermStats]>[],
  documentCount: number,
  onTerm: () => void,
): AsyncGenerator<[string, string]> {
  const iterators = sources.map((source) => source[Symbol.asyncIterator]());
  const heads = await mapConcurrent(iterators, SEGMENT_READ_CONCURRENCY, async (iterator) =>
    await iterator.next());
  while (heads.some((head) => !head.done)) {
    let term: string | null = null;
    for (const head of heads) {
      if (!head.done && (term === null || head.value[0] < term)) {
        term = head.value[0];
      }
    }
    if (term === null) {
      break;
    }
    const statistics: RankedTermStats[] = [];
    for (let index = 0; index < heads.length; index += 1) {
      const head = heads[index];
      if (!head.done && head.value[0] === term) {
        statistics.push(head.value[1]);
        heads[index] = await iterators[index].next();
      }
    }
    const merged = mergeTermStatistics(statistics, documentCount);
    onTerm();
    yield [term, encodeTermStatistics(merged)];
  }
}

function mergeTermStatistics(
  statistics: readonly RankedTermStats[],
  documentCount: number,
): RankedTermStats {
  const fieldSetFrequencies = new Map<string, { fields: string[]; documentFrequency: number }>();
  let documentFrequency = 0;
  for (const stats of statistics) {
    documentFrequency = addSafeIntegers(
      documentFrequency,
      stats.documentFrequency,
      'catalog-global document frequency',
    );
    for (const fieldSet of stats.fieldSets) {
      const key = JSON.stringify(fieldSet.fields);
      const existing = fieldSetFrequencies.get(key);
      if (existing) {
        existing.documentFrequency = addSafeIntegers(
          existing.documentFrequency,
          fieldSet.documentFrequency,
          'catalog-global field-set frequency',
        );
      } else {
        fieldSetFrequencies.set(key, {
          fields: [...fieldSet.fields],
          documentFrequency: fieldSet.documentFrequency,
        });
      }
    }
  }
  if (documentFrequency <= 0 || documentFrequency > documentCount) {
    throw new Error('Invalid catalog-global ranked search document frequency');
  }
  return {
    documentFrequency,
    fieldSets: [...fieldSetFrequencies.entries()]
      .sort(([left], [right]) => compareStrings(left, right))
      .map(([, fieldSet]) => fieldSet),
  };
}

function parseGlobalScoringManifest(
  raw: string,
  expectedDocumentCount: number,
  expectedFields: Readonly<Record<string, {
    boost?: number;
    lengthNormalization?: number;
  }>>,
): PostSearchGlobalScoringManifest {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Invalid post search global scoring manifest JSON');
  }
  if (!isObject(value)
    || value.format !== POST_SEARCH_GLOBAL_SCORING_FORMAT
    || value.normalization !== POST_SEARCH_NORMALIZATION) {
    throw new Error('Unsupported post search global scoring format');
  }
  const documentCount = nonNegativeInteger(value.documentCount, 'global scoring documentCount');
  if (documentCount !== expectedDocumentCount) {
    throw new Error('Post search global scoring coverage does not match catalog coverage');
  }
  const k1 = positiveNumber(value.k1, 'global scoring k1');
  const termCount = nonNegativeInteger(value.termCount, 'global scoring termCount');
  if (!Array.isArray(value.fields)) {
    throw new Error('Invalid post search global scoring fields');
  }
  const fields = value.fields.map((field, index) => parseManifestField(field, index, documentCount));
  if (!hasCompatibleFields(fields, expectedFields)) {
    throw new Error('Incompatible post search global scoring fields');
  }
  return {
    format: POST_SEARCH_GLOBAL_SCORING_FORMAT,
    normalization: POST_SEARCH_NORMALIZATION,
    documentCount,
    termCount,
    k1,
    fields,
  };
}

function parseManifestField(
  value: unknown,
  index: number,
  documentCount: number,
): RankedSearchFieldManifest {
  if (!isObject(value) || typeof value.name !== 'string' || !value.name) {
    throw new Error(`Invalid global scoring field at ${index}`);
  }
  const populatedDocumentCount = nonNegativeInteger(
    value.populatedDocumentCount,
    `global scoring field ${value.name} populatedDocumentCount`,
  );
  if (populatedDocumentCount > documentCount) {
    throw new Error(`Invalid global scoring populated count for field: ${value.name}`);
  }
  return {
    name: value.name,
    boost: positiveNumber(value.boost, `global scoring field ${value.name} boost`),
    lengthNormalization: boundedNumber(
      value.lengthNormalization,
      0,
      1,
      `global scoring field ${value.name} lengthNormalization`,
    ),
    totalLength: nonNegativeInteger(value.totalLength, `global scoring field ${value.name} totalLength`),
    populatedDocumentCount,
  };
}

function encodeTermStatistics(stats: RankedTermStats): string {
  return JSON.stringify(stats);
}

function parseTermStatistics(
  raw: string,
  fieldNames: ReadonlySet<string>,
  documentCount: number,
): RankedTermStats {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Invalid post search global term statistics JSON');
  }
  if (!isObject(value)) {
    throw new Error('Invalid post search global term statistics');
  }
  const documentFrequency = positiveInteger(value.documentFrequency, 'global term documentFrequency');
  if (!Array.isArray(value.fieldSets) || value.fieldSets.length === 0) {
    throw new Error('Invalid post search global term field sets');
  }
  const fieldSets = value.fieldSets.map((item, index) => {
    if (!isObject(item)
      || !Array.isArray(item.fields)
      || item.fields.length === 0
      || item.fields.some((field) => typeof field !== 'string' || !fieldNames.has(field))) {
      throw new Error(`Invalid post search global term field set at ${index}`);
    }
    const fields = [...item.fields] as string[];
    if (new Set(fields).size !== fields.length
      || fields.some((field, fieldIndex) => fieldIndex > 0 && field <= fields[fieldIndex - 1])) {
      throw new Error(`Invalid post search global term field set at ${index}`);
    }
    return {
      fields,
      documentFrequency: positiveInteger(
        item.documentFrequency,
        `global term field set ${index} documentFrequency`,
      ),
    };
  });
  const stats = { documentFrequency, fieldSets };
  validateTermStatistics(stats, fieldNames, documentCount);
  return stats;
}

function validateTermStatistics(
  stats: RankedTermStats,
  fieldNames: ReadonlySet<string>,
  documentCount: number,
): void {
  if (!Number.isSafeInteger(stats.documentFrequency)
    || stats.documentFrequency <= 0
    || stats.documentFrequency > documentCount
    || stats.fieldSets.length === 0) {
    throw new Error('Invalid ranked search term statistics');
  }
  const seen = new Set<string>();
  let sum = 0;
  for (const fieldSet of stats.fieldSets) {
    if (!Array.isArray(fieldSet.fields)
      || fieldSet.fields.length === 0
      || fieldSet.fields.some((field, index) =>
        !fieldNames.has(field) || (index > 0 && field <= fieldSet.fields[index - 1]))
      || !Number.isSafeInteger(fieldSet.documentFrequency)
      || fieldSet.documentFrequency <= 0) {
      throw new Error('Invalid ranked search term field statistics');
    }
    const key = JSON.stringify(fieldSet.fields);
    if (seen.has(key)) {
      throw new Error('Duplicate ranked search term field set');
    }
    seen.add(key);
    sum = addSafeIntegers(sum, fieldSet.documentFrequency, 'term field-set frequency');
  }
  if (sum !== stats.documentFrequency) {
    throw new Error('Inconsistent ranked search term document frequency');
  }
}

function nonNegativeInteger(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}

function positiveInteger(value: unknown, name: string): number {
  const parsed = nonNegativeInteger(value, name);
  if (parsed === 0) {
    throw new Error(`Invalid ${name}`);
  }
  return parsed;
}

function positiveNumber(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}

function boundedNumber(value: unknown, min: number, max: number, name: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function compareStrings(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

function addSafeIntegers(left: number, right: number, name: string): number {
  const sum = left + right;
  if (!Number.isSafeInteger(sum) || sum < 0) {
    throw new Error(`Invalid ${name}`);
  }
  return sum;
}

function sumSafeIntegers(values: readonly number[], name: string): number {
  return values.reduce((sum, value) => addSafeIntegers(sum, value, name), 0);
}

async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input) => Promise<Output>,
): Promise<Output[]> {
  const results = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await worker(values[index]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return results;
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw signal.reason ?? new DOMException('The operation was aborted', 'AbortError');
  }
}
