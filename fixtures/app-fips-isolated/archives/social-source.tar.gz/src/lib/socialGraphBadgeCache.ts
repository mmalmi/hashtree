import { writable } from 'svelte/store';
import { MAX_SOCIAL_GRAPH_BADGE_PUBKEYS, type SocialGraphBadge } from './socialGraphBadgeQuery';

type BadgeQuery = (viewer: string, pubkeys: string[], signal: AbortSignal) => Promise<SocialGraphBadge[]>;

/** One deduplicated, viewer-scoped projection for mounted names. No graph enters the renderer. */
export function createSocialGraphBadgeCache(query: BadgeQuery) {
  const store = writable<ReadonlyMap<string, SocialGraphBadge>>(new Map());
  const watched = new Map<string, number>();
  let cached = new Map<string, SocialGraphBadge>();
  let viewer: string | null = null;
  let generation = 0;
  let scheduled = false;
  let controller: AbortController | null = null;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  function schedule(): void {
    if (scheduled || controller || retryTimer || !viewer || watched.size === 0) {return;}
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      void drain();
    });
  }

  async function drain(): Promise<void> {
    if (controller || !viewer || watched.size === 0) {return;}
    const request = new AbortController();
    const requestGeneration = generation;
    const requestViewer = viewer;
    controller = request;
    try {
      while (!request.signal.aborted) {
        const pubkeys = [...watched.keys()].filter((pubkey) => !cached.has(pubkey))
          .slice(0, MAX_SOCIAL_GRAPH_BADGE_PUBKEYS);
        if (pubkeys.length === 0) {break;}
        const badges = await query(requestViewer, pubkeys, request.signal);
        if (generation !== requestGeneration || request.signal.aborted) {break;}
        for (const badge of badges) {cached.set(badge.pubkey, badge);}
        // Keep unknown results too, and bound profiles retained after route changes.
        for (const pubkey of cached.keys()) {
          if (cached.size <= 1_024) {break;}
          if (!watched.has(pubkey)) {cached.delete(pubkey);}
        }
        store.set(new Map(cached));
        if (badges.length !== pubkeys.length) {break;}
      }
    } catch {
      if (!request.signal.aborted && watched.size > 0) {
        retryTimer = setTimeout(() => {
          retryTimer = null;
          schedule();
        }, 5_000);
      }
    } finally {
      if (controller === request) {controller = null;}
      if (generation !== requestGeneration || request.signal.aborted) {schedule();}
    }
  }

  function invalidate(): void {
    generation += 1;
    controller?.abort();
    if (retryTimer) {clearTimeout(retryTimer); retryTimer = null;}
    cached = new Map();
    store.set(cached);
    schedule();
  }

  return {
    subscribe: store.subscribe,
    invalidate,
    setViewer(nextViewer: string | null): void {
      if (nextViewer === viewer) {return;}
      viewer = nextViewer;
      invalidate();
    },
    watch(pubkey: string): () => void {
      if (!/^[0-9a-f]{64}$/.test(pubkey)) {return () => undefined;}
      watched.set(pubkey, (watched.get(pubkey) ?? 0) + 1);
      // A cached result is valid until explicit graph/viewer invalidation.
      if (!cached.has(pubkey)) {schedule();}
      return () => {
        const count = watched.get(pubkey) ?? 0;
        if (count > 1) {watched.set(pubkey, count - 1);} else {watched.delete(pubkey);}
        if (watched.size === 0) {
          controller?.abort();
          if (retryTimer) {clearTimeout(retryTimer); retryTimer = null;}
        }
      };
    },
  };
}
