const DEFAULT_RESTORE_DEADLINE_MS = 4_000;
const MIN_RETRY_DELAY_MS = 32;
const MAX_RETRY_DELAY_MS = 400;
const RESTORE_EPSILON_PX = 1;
const REQUIRED_STABLE_TARGET_FRAMES = 4;

export const PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE = 'data-app-scroll-restoring';

export type ProgressiveScrollRestoreOptions = {
  element: HTMLElement;
  targetOffset: number;
  shouldContinue: () => boolean;
  onSettled?: (offset: number) => void;
  deadlineMs?: number;
};

export type ProgressiveScrollRestore = {
  cancel: () => void;
  readonly active: boolean;
};

export function reachableScrollOffset(
  targetOffset: number,
  scrollHeight: number,
  clientHeight: number,
): number {
  const target = Math.max(0, targetOffset);
  const maximum = Math.max(0, scrollHeight - clientHeight);
  return Math.min(target, maximum);
}

/**
 * Restore a route after its component was evicted and must progressively
 * rebuild its height. The restore remains alive until the target is reachable
 * and stable across route-activation frames, but immediately yields to direct
 * wheel/touch/pointer/keyboard input so it never fights the user.
 */
export function restoreScrollProgressively(
  options: ProgressiveScrollRestoreOptions,
): ProgressiveScrollRestore {
  const { element } = options;
  const targetOffset = Math.max(0, options.targetOffset);
  const deadlineAt = performance.now()
    + Math.max(0, options.deadlineMs ?? DEFAULT_RESTORE_DEADLINE_MS);
  const restoreMarker = `${performance.now()}:${targetOffset}`;
  let active = true;
  let lastAppliedOffset = element.scrollTop;
  let retryDelayMs = MIN_RETRY_DELAY_MS;
  let retryTimer: number | null = null;
  let frameId: number | null = null;
  let observedContent: Element | null = null;
  let stableTargetFrames = 0;

  const resizeObserver = typeof ResizeObserver === 'undefined'
    ? null
    : new ResizeObserver(() => scheduleApply());
  const mutationObserver = typeof MutationObserver === 'undefined'
    ? null
    : new MutationObserver(() => {
        syncResizeTarget();
        scheduleApply();
      });

  function clearScheduledWork(): void {
    if (retryTimer !== null) {
      window.clearTimeout(retryTimer);
      retryTimer = null;
    }
    if (frameId !== null) {
      window.cancelAnimationFrame(frameId);
      frameId = null;
    }
  }

  function cancel(): void {
    if (!active) {
      return;
    }
    active = false;
    clearScheduledWork();
    resizeObserver?.disconnect();
    mutationObserver?.disconnect();
    if (element.getAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE) === restoreMarker) {
      element.removeAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE);
    }
    element.removeEventListener('scroll', handleScroll);
    element.removeEventListener('wheel', cancelFromUserInput);
    element.removeEventListener('touchstart', cancelFromUserInput);
    element.removeEventListener('pointerdown', cancelFromUserInput);
    element.removeEventListener('keydown', cancelFromUserInput);
  }

  function cancelFromUserInput(): void {
    cancel();
  }

  function handleScroll(): void {
    const adjustment = Math.abs(element.scrollTop - lastAppliedOffset);
    if (adjustment <= RESTORE_EPSILON_PX) {
      return;
    }
    // Browser scroll anchoring and a cold card's initial height clamp can move
    // the shared scroller by hundreds of pixels. Explicit wheel/touch/pointer/
    // keyboard listeners cancel real user input, so a bare scroll event must
    // never abort restoration based only on its distance.
    stableTargetFrames = 0;
    scheduleApply();
  }

  function syncResizeTarget(): void {
    const nextContent = element.firstElementChild;
    if (nextContent === observedContent) {
      return;
    }
    resizeObserver?.disconnect();
    observedContent = nextContent;
    if (observedContent) {
      resizeObserver?.observe(observedContent);
    }
  }

  function scheduleRetry(): void {
    if (!active || retryTimer !== null || performance.now() >= deadlineAt) {
      if (performance.now() >= deadlineAt) {
        cancel();
      }
      return;
    }
    retryTimer = window.setTimeout(() => {
      retryTimer = null;
      apply();
    }, retryDelayMs);
    retryDelayMs = Math.min(MAX_RETRY_DELAY_MS, retryDelayMs * 2);
  }

  function scheduleApply(): void {
    if (!active || frameId !== null) {
      return;
    }
    frameId = window.requestAnimationFrame(() => {
      frameId = null;
      apply();
    });
  }

  function apply(): void {
    if (!active || !options.shouldContinue() || performance.now() >= deadlineAt) {
      cancel();
      return;
    }
    const nextOffset = reachableScrollOffset(
      targetOffset,
      element.scrollHeight,
      element.clientHeight,
    );
    element.scrollTo(0, nextOffset);
    lastAppliedOffset = element.scrollTop;

    if (
      Math.abs(lastAppliedOffset - targetOffset) <= RESTORE_EPSILON_PX
      && nextOffset >= targetOffset - RESTORE_EPSILON_PX
    ) {
      stableTargetFrames += 1;
      if (stableTargetFrames >= REQUIRED_STABLE_TARGET_FRAMES) {
        options.onSettled?.(lastAppliedOffset);
        cancel();
      } else {
        scheduleApply();
      }
      return;
    }
    stableTargetFrames = 0;
    scheduleRetry();
  }

  syncResizeTarget();
  element.setAttribute(PROGRESSIVE_SCROLL_RESTORE_ATTRIBUTE, restoreMarker);
  mutationObserver?.observe(element, { childList: true, subtree: true });
  element.addEventListener('scroll', handleScroll, { passive: true });
  element.addEventListener('wheel', cancelFromUserInput, { passive: true });
  element.addEventListener('touchstart', cancelFromUserInput, { passive: true });
  element.addEventListener('pointerdown', cancelFromUserInput, { passive: true });
  element.addEventListener('keydown', cancelFromUserInput);
  apply();

  return {
    cancel,
    get active() {
      return active;
    },
  };
}
