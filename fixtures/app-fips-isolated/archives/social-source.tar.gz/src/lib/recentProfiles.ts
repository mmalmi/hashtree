import { writable } from 'svelte/store';

type RecentProfiles = { viewer: string | null; pubkeys: string[] };
type Storage = Pick<globalThis.Storage, 'getItem' | 'setItem'>;
const LIMIT = 12;
const isPubkey = (value: unknown): value is string => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value);
const storageKey = (viewer: string | null) => `iris-social:recent-searches:v1:${viewer ?? 'anonymous'}`;

/** Explicit people search selections, isolated per account and never published. */
export function createRecentProfilesStore(storage: () => Storage | undefined) {
  let initialized = false;
  let current: RecentProfiles = { viewer: null, pubkeys: [] };
  const state = writable(current);
  const set = (next: RecentProfiles) => { current = next; state.set(next); };
  const read = (viewer: string | null): string[] => {
    try {
      const value: unknown = JSON.parse(storage()?.getItem(storageKey(viewer)) ?? '[]');
      return Array.isArray(value)
        ? [...new Set(value.filter(isPubkey))].filter((pubkey) => pubkey !== viewer).slice(0, LIMIT)
        : [];
    } catch { return []; }
  };
  const save = (pubkeys: string[]) => {
    try { storage()?.setItem(storageKey(current.viewer), JSON.stringify(pubkeys)); } catch {
      // Search history still works for this session if storage is unavailable.
    }
    set({ viewer: current.viewer, pubkeys });
  };
  const setViewer = (viewer: string | null): void => {
    if (!initialized || current.viewer !== viewer) {
      initialized = true;
      set({ viewer, pubkeys: read(viewer) });
    }
  };
  return {
    subscribe: state.subscribe,
    setViewer,
    select(viewer: string | null, pubkey: string): void {
      setViewer(viewer);
      if (!isPubkey(pubkey) || pubkey === viewer || current.pubkeys[0] === pubkey) { return; }
      save([...new Set([pubkey, ...read(viewer), ...current.pubkeys])].slice(0, LIMIT));
    },
    clear(): void { save([]); },
    refresh(key: string | null): void {
      if (initialized && (key === null || key === storageKey(current.viewer))) {
        set({ viewer: current.viewer, pubkeys: read(current.viewer) });
      }
    },
  };
}

export const recentProfilesStore = createRecentProfilesStore(() => (
  typeof localStorage === 'undefined' ? undefined : localStorage
));
