export type BoundedHydrationResult<T> =
  | { status: 'completed'; value: T }
  | { status: 'cancelled' };

export type BoundedHydrationPriority = 'background' | 'foreground';

type PendingHydration<T> = {
  controller: AbortController;
  generation: number;
  isCurrent: () => boolean;
  priority: BoundedHydrationPriority;
  reject: (reason?: unknown) => void;
  resolve: (result: BoundedHydrationResult<T>) => void;
  run: (signal: AbortSignal) => Promise<T>;
};

export type BoundedHydrationScheduler = {
  cancelPending: () => void;
  dispose: () => void;
  run: <T>(
    task: (signal: AbortSignal) => Promise<T>,
    options?: {
      isCurrent?: () => boolean;
      priority?: BoundedHydrationPriority;
    },
  ) => Promise<BoundedHydrationResult<T>>;
};

export type RouteHydrationPromiseCache<T> = {
  clear: () => void;
  get: (key: string) => Promise<T> | undefined;
  track: (key: string, promise: Promise<T>) => Promise<T>;
};

const DEFAULT_CONCURRENCY = 4;
const MAX_CONCURRENCY = 8;
const CANCELLED_SETTLEMENT_BATCH_SIZE = 64;

function normalizeConcurrency(concurrency: number | undefined): number {
  if (!Number.isFinite(concurrency)) {
    return DEFAULT_CONCURRENCY;
  }
  return Math.max(1, Math.min(MAX_CONCURRENCY, Math.trunc(concurrency ?? DEFAULT_CONCURRENCY)));
}

export function createRouteHydrationPromiseCache<T>(): RouteHydrationPromiseCache<T> {
  const promises = new Map<string, { identity: symbol; promise: Promise<T> }>();
  return {
    clear() {
      promises.clear();
    },
    get(key: string) {
      return promises.get(key)?.promise;
    },
    track(key: string, promise: Promise<T>): Promise<T> {
      const identity = Symbol(key);
      const tracked = (async () => {
        try {
          return await promise;
        } finally {
          if (promises.get(key)?.identity === identity) {
            promises.delete(key);
          }
        }
      })();
      promises.set(key, { identity, promise: tracked });
      return tracked;
    },
  };
}

export function createBoundedHydrationScheduler(
  options: { concurrency?: number } = {},
): BoundedHydrationScheduler {
  const concurrency = normalizeConcurrency(options.concurrency);
  let queue: Array<PendingHydration<unknown>> = [];
  const cancelledBatches: Array<{
    tasks: Array<PendingHydration<unknown>>;
    index: number;
  }> = [];
  let cancelledSettlementScheduled = false;
  let activeCount = 0;
  const active = new Set<PendingHydration<unknown>>();
  let disposed = false;
  let generation = 0;

  function settleCancelled(task: PendingHydration<unknown>): void {
    task.resolve({ status: 'cancelled' });
  }

  function taskIsCurrent(task: PendingHydration<unknown>): boolean {
    return !disposed && task.generation === generation && task.isCurrent();
  }

  function scheduleTask(callback: () => void): void {
    setTimeout(callback, 0);
  }

  function settleCancelledBatch(): void {
    cancelledSettlementScheduled = false;
    let remaining = CANCELLED_SETTLEMENT_BATCH_SIZE;

    while (remaining > 0 && cancelledBatches.length > 0) {
      const batch = cancelledBatches[0]!;
      while (remaining > 0 && batch.index < batch.tasks.length) {
        settleCancelled(batch.tasks[batch.index++]!);
        remaining -= 1;
      }
      if (batch.index === batch.tasks.length) {
        cancelledBatches.shift();
      }
    }

    if (cancelledBatches.length > 0) {
      cancelledSettlementScheduled = true;
      scheduleTask(settleCancelledBatch);
    }
  }

  function scheduleCancelledSettlement(
    tasks: Array<PendingHydration<unknown>>,
  ): void {
    if (tasks.length === 0) {
      return;
    }
    cancelledBatches.push({ tasks, index: 0 });
    if (cancelledSettlementScheduled) {
      return;
    }
    cancelledSettlementScheduled = true;

    if (
      typeof window !== 'undefined'
      && typeof document !== 'undefined'
      && typeof window.requestAnimationFrame === 'function'
      && document.visibilityState !== 'hidden'
    ) {
      // Route cancellation runs inside the navigation input handler. Keep the
      // invalidation itself constant-time, then resolve abandoned promises only
      // after the destination has had a rendering opportunity.
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => scheduleTask(settleCancelledBatch));
      });
      return;
    }

    scheduleTask(settleCancelledBatch);
  }

  function pump(): void {
    while (activeCount < concurrency && queue.length > 0) {
      const task = queue.shift() as PendingHydration<unknown>;
      if (!taskIsCurrent(task)) {
        settleCancelled(task);
        continue;
      }

      activeCount += 1;
      active.add(task);
      void Promise.resolve()
        .then(() => task.run(task.controller.signal))
        .then((value) => {
          if (taskIsCurrent(task)) {
            task.resolve({ status: 'completed', value });
          } else {
            settleCancelled(task);
          }
        }, (error: unknown) => {
          if (taskIsCurrent(task)) {
            task.reject(error);
          } else {
            settleCancelled(task);
          }
        })
        .finally(() => {
          active.delete(task);
          activeCount -= 1;
          pump();
        });
    }
  }

  function cancelPending(): void {
    generation += 1;
    // At most MAX_CONCURRENCY tasks are active, so aborting in-flight I/O is
    // constant-time even when the detached queue contains hundreds of jobs.
    for (const task of active) {
      if (!task.controller.signal.aborted) {
        task.controller.abort(new DOMException('Route hydration cancelled', 'AbortError'));
      }
    }
    const cancelled = queue;
    queue = [];
    scheduleCancelledSettlement(cancelled);
  }

  return {
    cancelPending,
    dispose() {
      if (disposed) {
        return;
      }
      disposed = true;
      cancelPending();
    },
    run<T>(
      task: (signal: AbortSignal) => Promise<T>,
      taskOptions: {
        isCurrent?: () => boolean;
        priority?: BoundedHydrationPriority;
      } = {},
    ): Promise<BoundedHydrationResult<T>> {
      if (disposed || taskOptions.isCurrent?.() === false) {
        return Promise.resolve({ status: 'cancelled' });
      }

      return new Promise<BoundedHydrationResult<T>>((resolve, reject) => {
        const pending: PendingHydration<T> = {
          controller: new AbortController(),
          generation,
          isCurrent: taskOptions.isCurrent ?? (() => true),
          priority: taskOptions.priority ?? 'background',
          reject,
          resolve,
          run: task,
        };
        if (pending.priority === 'foreground') {
          const firstBackground = queue.findIndex((candidate) => candidate.priority === 'background');
          queue.splice(firstBackground < 0 ? queue.length : firstBackground, 0, pending as PendingHydration<unknown>);
        } else {
          queue.push(pending as PendingHydration<unknown>);
        }
        pump();
      });
    },
  };
}
