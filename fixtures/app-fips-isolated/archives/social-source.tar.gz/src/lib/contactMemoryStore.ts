import { writable } from 'svelte/store';
import {
  approveContactName, emptyContactMemory, observeContactName, setContactFavorite,
  type ContactMemory,
} from '@iris/svelte-ui/contactMemory';

export function publicContactName(profile: { displayName?: string | null; name?: string | null } | null | undefined): string | null {
  return profile?.displayName?.trim() || profile?.name?.trim() || null;
}

export type PrivateContactPatch = { favorite?: boolean; nickname?: string | null; note?: string | null };
export type AppContactMemory = ContactMemory & { nickname?: string | null; note?: string | null };
export type MemoryState = { viewer: string | null; contacts: ReadonlyMap<string, AppContactMemory> };
type Storage = Pick<globalThis.Storage, 'getItem' | 'setItem'>;
const keyFor = (viewer: string) => `iris-social:contact-memory:v1:${viewer}`;

function parseMemory(value: unknown): AppContactMemory | null {
  if (!value || typeof value !== 'object') {return null;}
  const candidate = value as AppContactMemory;
  if (!(candidate.first_seen_name === null || typeof candidate.first_seen_name === 'string')
    || !(candidate.accepted_name === null || typeof candidate.accepted_name === 'string')
    || typeof candidate.favorite !== 'boolean' || !Array.isArray(candidate.name_changes)
    || !(candidate.nickname === undefined || candidate.nickname === null || typeof candidate.nickname === 'string')
    || !(candidate.note === undefined || candidate.note === null || typeof candidate.note === 'string')
    || candidate.name_changes.some((change) => !change
      || typeof change.previous_name !== 'string'
      || typeof change.accepted_name !== 'string' || !Number.isSafeInteger(change.accepted_at_secs)
      || change.accepted_at_secs < 0)) {return null;}
  return candidate;
}

/** Private, account-scoped storage. Never added to metadata or contact-list events. */
export function createContactMemoryStore(storage: () => Storage | undefined) {
  // Profile titles read this for every visible card. Keep reads allocation-free
  // instead of briefly subscribing/unsubscribing to the Svelte store each time.
  let snapshot: MemoryState = { viewer: null, contacts: new Map() };
  let privateEdit: ((viewer: string, pubkey: string, patch: PrivateContactPatch) => Promise<void>) | null = null;
  const state = writable(snapshot);
  const setState = (next: MemoryState): void => {
    snapshot = next;
    state.set(next);
  };
  const readContacts = (viewer: string): Map<string, AppContactMemory> => {
    try {
      const parsed: unknown = JSON.parse(storage()?.getItem(keyFor(viewer)) ?? '{}');
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {return new Map();}
      return new Map(Object.entries(parsed).flatMap(([pubkey, value]) => {
        const memory = parseMemory(value);
        return /^[0-9a-f]{64}$/.test(pubkey) && memory ? [[pubkey, memory]] : [];
      }));
    } catch {return new Map();}
  };
  function write(pubkey: string, update: (memory: AppContactMemory | undefined) => AppContactMemory): void {
    const current = snapshot;
    if (!current.viewer || pubkey === current.viewer || !/^[0-9a-f]{64}$/.test(pubkey)) {return;}
    // Merge the latest persisted state so another tab's unrelated edits survive.
    const contacts = readContacts(current.viewer);
    for (const [key, value] of current.contacts) {if (!contacts.has(key)) {contacts.set(key, value);}}
    const previous = contacts.get(pubkey);
    const next = update(previous);
    if (JSON.stringify(previous) === JSON.stringify(next)) {return;}
    contacts.set(pubkey, next);
    try {storage()?.setItem(keyFor(current.viewer), JSON.stringify(Object.fromEntries(contacts)));} catch {
      // Keep session state usable when browser storage is unavailable.
    }
    setState({ viewer: current.viewer, contacts });
  }
  return {
    subscribe: state.subscribe,
    get(pubkey: string): AppContactMemory | undefined {return snapshot.contacts.get(pubkey);},
    getSnapshot(): MemoryState { return snapshot; },
    setPrivateEditHandler(handler: typeof privateEdit): void { privateEdit = handler; },
    applyPrivateFields(viewer: string, pubkey: string, patch: PrivateContactPatch): void {
      if (snapshot.viewer !== viewer) { return; }
      write(pubkey, memory => ({ ...emptyContactMemory(), ...memory, ...patch }));
    },
    setViewer(viewer: string | null): void {
      if (snapshot.viewer === viewer) {return;}
      setState({ viewer, contacts: viewer ? readContacts(viewer) : new Map() });
    },
    refresh(storageKey: string | null): void {
      const { viewer } = snapshot;
      if (viewer && (storageKey === null || storageKey === keyFor(viewer))) {
        setState({ viewer, contacts: readContacts(viewer) });
      }
    },
    remember(pubkey: string, name: string | null): void {
      const known = snapshot.contacts.get(pubkey);
      // Once both names are seeded, observing an interaction cannot change them.
      // Avoid rereading and serializing all contacts whenever a profile mounts.
      if (known && known.first_seen_name !== null && known.accepted_name !== null) {return;}
      write(pubkey, (memory) => observeContactName(memory ?? emptyContactMemory(), name));
    },
    observe(pubkey: string, name: string | null): void {
      const known = snapshot.contacts.get(pubkey);
      if (known && (known.first_seen_name === null || known.accepted_name === null)) {
        write(pubkey, (memory) => observeContactName(memory ?? emptyContactMemory(), name));
      }
    },
    async favorite(pubkey: string, name: string | null, favorite: boolean): Promise<void> {
      if (privateEdit && snapshot.viewer) {
        write(pubkey, memory => observeContactName(memory ?? emptyContactMemory(), name));
        await privateEdit(snapshot.viewer, pubkey, { favorite });
        return;
      }
      write(pubkey, (memory) => setContactFavorite(observeContactName(memory ?? emptyContactMemory(), name), favorite));
    },
    async details(pubkey: string, values: { nickname?: string | null; note?: string | null }): Promise<void> {
      const patch = {
        ...('nickname' in values ? { nickname: values.nickname?.trim() || null } : {}),
        ...('note' in values ? { note: values.note?.trim() || null } : {}),
      };
      if (privateEdit && snapshot.viewer) { await privateEdit(snapshot.viewer, pubkey, patch); return; }
      write(pubkey, memory => ({ ...emptyContactMemory(), ...memory, ...patch }));
    },
    approve(pubkey: string, expectedName: string, latestName: string | null, nowSecs: number): void {
      write(pubkey, (memory) => approveContactName(memory ?? emptyContactMemory(), expectedName, latestName, nowSecs));
    },
  };
}

export const contactMemoryStore = createContactMemoryStore(() => typeof localStorage === 'undefined' ? undefined : localStorage);
