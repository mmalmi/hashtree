import { getContext, setContext } from 'svelte';
import { readable, type Readable } from 'svelte/store';

const ROUTE_ACTIVITY_CONTEXT = Symbol('iris-route-activity');
const ALWAYS_ACTIVE = readable(true);

export function provideRouteActivity(activity: Readable<boolean>): void {
  setContext(ROUTE_ACTIVITY_CONTEXT, activity);
}

export function getRouteActivity(): Readable<boolean> {
  return getContext<Readable<boolean> | undefined>(ROUTE_ACTIVITY_CONTEXT) ?? ALWAYS_ACTIVE;
}
