import { CollectionSource } from '@hashtree/collection';
import { HashTree, type CID, type Store } from '@hashtree/core';
import {
  decodeStoredNostrEventMsgpack,
  MANIFEST_BY_AUTHOR_KIND_TIME,
  MANIFEST_BY_KIND_TIME,
  MANIFEST_BY_KIND_TIME_AUTHOR,
  MANIFEST_BY_TAG,
  NostrEventStore,
  nostrEventManifestToCollectionManifest,
  type StoredNostrEvent,
} from '@hashtree/nostr';
import { CooperativeWorkBudget } from './cooperativeWork';
import { verifyIndexedEvent, verifyIndexedEvents } from './fastEventVerification';
import { awaitWithin } from './feedIndexTiming';
import { resolveLegacyNevent } from './legacyEventResolution';
import {
  decodeNostrEventReference,
  isHexEventId,
  parseProfileEvent,
  type ProfileRecord,
  type RawEvent,
} from './nostr';
import { asVerifiedRawEvent, verifyAndAsRawEvent } from './nostrIndexEvent';
import {
  NOSTR_INDEX_INTERACTION_KINDS,
  NostrIndexReaderFeeds,
} from './nostrIndexReaderFeeds';
import { NostrIndexRecentMerge } from './nostrIndexRecentMerge';
import type { NoteDetailListKind, NostrEventIndexReaderOptions } from './nostrIndexTypes';
import {
  EMPTY_NOSTR_COLLECTION_INDEXES,
  getNostrCollectionIndexes,
  hasAnyNostrCollectionIndex,
  hasCollectionIndex,
  type NostrCollectionIndexes,
} from './nostrCollectionIndexes';
import {
  createConcurrencyLimiter,
  DEFAULT_INDEXED_EVENT_READ_CONCURRENCY,
  type ConcurrencyLimiter,
} from './orderedConcurrent';
import {
  readFallbackEventsByTag,
  readIndexedEventsByTag,
} from './threadReplyPagination';
import type {
  RecentTextNoteCursor,
  RecentTextNoteQueryOptions,
} from './recentTextNoteCursor';
import { sleep } from './asyncTiming';
import { createWorkerBlockStore } from './workerBlockStore';
import { authorFromKindTimeAuthorKey } from './recentTextNoteCursor';

const INDEX_ROOT_RETRY_DELAYS_MS = [120, 360];
const LATEST_EVENT_SCAN_LIMIT = 256;

type NostrCollectionSource = CollectionSource;

function padKind(kind: number): string {
  return kind.toString(16).padStart(8, '0');
}

function normalizeTagValue(tagName: string, tagValue: string): string {
  return tagName === 't' ? tagValue.toLowerCase() : tagValue;
}

export class NostrEventIndexReader {
  private readonly store: Store;
  private readonly tree: HashTree;
  private readonly eventStore: NostrEventStore;
  private readonly root: CID;
  private readonly indexedEventReadConcurrency: number;
  private readonly indexedEventReadLimiter: ConcurrencyLimiter;
  private readonly indexedEventDecodeBudget = new CooperativeWorkBudget();
  private readonly indexedEventVerifier: ((event: StoredNostrEvent) => boolean | Promise<boolean>) | null;
  private readonly signal: AbortSignal | null;
  private readonly useWorkerHomeFeedQuery: boolean;
  private readonly recentMerge: NostrIndexRecentMerge;
  private readonly feeds: NostrIndexReaderFeeds;
  private cachedCollectionSource: NostrCollectionSource | null = null;
  private collectionSourcePromise: Promise<NostrCollectionSource> | null = null;

  constructor(
    root: CID,
    store?: Store,
    options: NostrEventIndexReaderOptions = {},
  ) {
    this.root = root;
    this.useWorkerHomeFeedQuery = store === undefined;
    this.store = store ?? createWorkerBlockStore();
    this.tree = new HashTree({ store: this.store });
    this.eventStore = new NostrEventStore(this.store);
    this.indexedEventReadConcurrency = options.indexedEventReadConcurrency
      ?? DEFAULT_INDEXED_EVENT_READ_CONCURRENCY;
    this.indexedEventReadLimiter = createConcurrencyLimiter(this.indexedEventReadConcurrency);
    this.indexedEventVerifier = options.indexedEventVerifier ?? null;
    this.signal = options.signal ?? null;
    this.recentMerge = new NostrIndexRecentMerge({
      findFastRecentTextNote: async (source, authorSet, limit, queryOptions, isCancelled) => (
        await this.findFastRecentTextNote(source, authorSet, limit, queryOptions, isCancelled)
      ),
      getCollectionSource: async () => await this.getCollectionSource(),
      indexedEventReadConcurrency: this.indexedEventReadConcurrency,
      indexedEventReadLimiter: this.indexedEventReadLimiter,
      nextRecentNoteCursor: async (iteratorIndex, iterator, queryOptions) => (
        await this.nextRecentNoteCursor(iteratorIndex, iterator, queryOptions)
      ),
      readEvent: async (cid) => await this.readEvent(cid),
    });
    this.feeds = new NostrIndexReaderFeeds({
      eventStore: this.eventStore,
      getCollectionIndexes: async (feedOptions) => await this.getCollectionIndexes(feedOptions),
      getCollectionSource: async () => await this.getCollectionSource(),
      indexedEventReadConcurrency: this.indexedEventReadConcurrency,
      readEvent: async (cid) => await this.readEvent(cid),
      verifyStoredEvent: async (event) => await this.verifyStoredEvent(event),
      verifyStoredEvents: async (events) => await this.verifyStoredEvents(events),
      recentMerge: this.recentMerge,
      root: this.root,
      signal: this.signal,
      useWorkerHomeFeedQuery: this.useWorkerHomeFeedQuery,
    });
  }

  private async nextRecentNoteCursor(
    iteratorIndex: number,
    iterator: AsyncIterator<RawEvent>,
    options: RecentTextNoteQueryOptions,
  ): Promise<{ iteratorIndex: number; event: RawEvent } | null> {
    return await this.recentMerge.nextRecentNoteCursorDefault(iteratorIndex, iterator, options);
  }

  private async findFastRecentTextNote(
    source: NostrCollectionSource,
    authorSet: Set<string>,
    limit: number,
    options: RecentTextNoteQueryOptions,
    isCancelled: () => boolean = () => false,
  ): Promise<RawEvent | null> {
    return await this.recentMerge.findFastRecentTextNoteDefault(
      source,
      authorSet,
      limit,
      options,
      isCancelled,
    );
  }

  private async loadCollectionSourceOnce(): Promise<NostrCollectionSource> {
    return new CollectionSource(
      this.store,
      nostrEventManifestToCollectionManifest(await this.eventStore.getManifest(this.root)),
    );
  }

  private async getCollectionSource(): Promise<NostrCollectionSource> {
    if (this.cachedCollectionSource) {
      return this.cachedCollectionSource;
    }

    if (!this.collectionSourcePromise) {
      this.collectionSourcePromise = (async () => {
        let source = await this.loadCollectionSourceOnce();
        for (const delayMs of INDEX_ROOT_RETRY_DELAYS_MS) {
          if (hasAnyNostrCollectionIndex(getNostrCollectionIndexes(source))) {
            return source;
          }
          await sleep(delayMs);
          source = await this.loadCollectionSourceOnce();
        }
        return source;
      })();
    }

    const source = await this.collectionSourcePromise;
    if (hasAnyNostrCollectionIndex(getNostrCollectionIndexes(source))) {
      this.cachedCollectionSource = source;
    } else {
      this.collectionSourcePromise = null;
    }
    return source;
  }

  private async getCollectionIndexes(
    options: { timeoutMs?: number } = {},
  ): Promise<NostrCollectionIndexes> {
    try {
      if (options.timeoutMs === undefined) {
        return getNostrCollectionIndexes(await this.getCollectionSource());
      }

      const quickSource = await awaitWithin(this.getCollectionSource(), options.timeoutMs);
      return quickSource.settled
        ? getNostrCollectionIndexes(quickSource.value)
        : EMPTY_NOSTR_COLLECTION_INDEXES;
    } catch (error) {
      console.warn('Failed to load Nostr collection indexes', error);
      return EMPTY_NOSTR_COLLECTION_INDEXES;
    }
  }

  private async readEvent(cid: CID): Promise<RawEvent | null> {
    if (this.signal?.aborted) {
      return null;
    }
    const bytes = await this.tree.readFile(cid);
    if (!bytes || this.signal?.aborted) {
      return null;
    }

    try {
      const event = await this.indexedEventDecodeBudget.run(() => decodeStoredNostrEventMsgpack(bytes));
      const valid = await this.indexedEventDecodeBudget.run(() => (
        this.indexedEventVerifier?.(event) ?? verifyIndexedEvent(event)
      ));
      if (!valid || this.signal?.aborted) { return null; }
      return asVerifiedRawEvent(event);
    } catch (error) {
      console.warn('Failed to decode indexed nostr event', error);
      return null;
    }
  }

  private async verifyStoredEvent(
    event: StoredNostrEvent,
    options: { observeSocialGraph?: boolean } = {},
  ): Promise<RawEvent | null> {
    if (this.signal?.aborted) {
      return null;
    }
    if (this.indexedEventVerifier) {
      return await this.indexedEventVerifier(event) ? asVerifiedRawEvent(event, options) : null;
    }
    return await verifyAndAsRawEvent(event, options);
  }

  private async verifyStoredEvents(events: StoredNostrEvent[]): Promise<RawEvent[]> {
    if (events.length === 0 || this.signal?.aborted) {
      return [];
    }
    if (this.indexedEventVerifier) {
      const valid = await Promise.all(events.map(async (event) => await this.indexedEventVerifier!(event)));
      return events.flatMap((event, index) => (
        valid[index] ? [asVerifiedRawEvent(event)] : []
      ));
    }
    const valid = await verifyIndexedEvents(events);
    return events.flatMap((event, index) => (
      valid[index] ? [asVerifiedRawEvent(event)] : []
    ));
  }

  private async *streamEventsFromCollectionIndex(
    source: NostrCollectionSource,
    indexName: string,
    prefix: string,
    limit?: number,
  ): AsyncGenerator<RawEvent, void, void> {
    const query = limit === undefined ? { prefix } : { prefix, limit };
    for await (const { cid } of source.streamQueryIndex(indexName, query)) {
      const event = await this.readEvent(cid);
      if (event) {
        yield event;
      }
    }
  }

  private async readLatestEventFromAuthorKindIndex(
    pubkey: string,
    kind: number,
  ): Promise<RawEvent | null> {
    try {
      const source = await this.getCollectionSource();
      for await (const event of this.streamEventsFromCollectionIndex(
        source,
        MANIFEST_BY_AUTHOR_KIND_TIME,
        `${pubkey}:${padKind(kind)}:`,
        LATEST_EVENT_SCAN_LIMIT,
      )) {
        if (event.kind === kind && event.pubkey === pubkey) {
          return event;
        }
      }
    } catch (error) {
      console.warn('Failed to read latest indexed event by author and kind', error);
    }

    return null;
  }

  private async scanLatestEventByKindTimeAuthor(
    pubkey: string,
    kind: number,
  ): Promise<RawEvent | null> {
    const source = await this.getCollectionSource();
    for await (const { key, cid } of source.streamQueryIndex(MANIFEST_BY_KIND_TIME_AUTHOR, {
      prefix: `${padKind(kind)}:`,
      limit: LATEST_EVENT_SCAN_LIMIT,
    })) {
      if (authorFromKindTimeAuthorKey(key) !== pubkey) {
        continue;
      }

      const event = await this.readEvent(cid);
      if (event && event.kind === kind && event.pubkey === pubkey) {
        return event;
      }
    }

    return null;
  }

  private async scanLatestEventByKindTime(
    pubkey: string,
    kind: number,
  ): Promise<RawEvent | null> {
    const source = await this.getCollectionSource();
    for await (const event of this.streamEventsFromCollectionIndex(
      source,
      MANIFEST_BY_KIND_TIME,
      `${padKind(kind)}:`,
      LATEST_EVENT_SCAN_LIMIT,
    )) {
      if (event.kind === kind && event.pubkey === pubkey) {
        return event;
      }
    }

    return null;
  }

  async getLatestEventByAuthorKind(pubkey: string, kind: number): Promise<RawEvent | null> {
    const directEvent = await this.readLatestEventFromAuthorKindIndex(pubkey, kind);
    if (directEvent) {
      return directEvent;
    }

    const { byKindTimeAuthor, byKindTime } = await this.getCollectionIndexes();
    if (byKindTimeAuthor) {
      const indexedEvent = await this.scanLatestEventByKindTimeAuthor(pubkey, kind);
      if (indexedEvent) {
        return indexedEvent;
      }
    }

    if (byKindTime) {
      const indexedEvent = await this.scanLatestEventByKindTime(pubkey, kind);
      if (indexedEvent) {
        return indexedEvent;
      }
    }

    return null;
  }

  async getEventById(eventId: string): Promise<RawEvent | null> {
    if (!isHexEventId(eventId)) {
      return null;
    }

    const event = await this.eventStore.getById(this.root, eventId);
    return event ? await this.verifyStoredEvent(event) : null;
  }

  async getEventByRef(ref: string): Promise<RawEvent | null> {
    const trimmed = ref.trim().startsWith('nostr:') ? ref.trim().slice('nostr:'.length) : ref.trim();
    if (!trimmed) {
      return null;
    }

    if (isHexEventId(trimmed)) {
      return await this.getEventById(trimmed);
    }

    const decoded = decodeNostrEventReference(trimmed);
    if (!decoded) {
      return null;
    }

    if (decoded.type === 'note' || decoded.type === 'nevent') {
      const direct = await this.getEventById(decoded.eventId);
      if (direct) {
        return direct;
      }
      if (decoded.type === 'note') {
        return null;
      }
      return await resolveLegacyNevent({
        source: await this.getCollectionSource(), eventId: decoded.eventId, author: decoded.author, kind: decoded.kind,
        readEvent: async (cid) => await this.readEvent(cid),
        loadTaggedEvents: async (name, value, options) => await this.getRecentEventsByTag(name, value, options),
      });
    }

    const event = await this.eventStore.getParameterizedReplaceable(
      this.root,
      decoded.pubkey,
      decoded.kind,
      decoded.identifier,
    );
    return event ? await this.verifyStoredEvent(event) : null;
  }

  async getNoteReplies(
    noteId: string,
    limit = 50,
    before?: RecentTextNoteCursor,
  ): Promise<RawEvent[]> {
    return await this.getRecentEventsByTag('e', noteId, {
      before,
      kinds: [1, 1111],
      limit,
    });
  }

  async getNoteDetailEvents(
    noteId: string,
    detailKind: NoteDetailListKind,
    limit = 50,
  ): Promise<RawEvent[]> {
    const kindMap: Record<NoteDetailListKind, number[]> = {
      likes: [7],
      reposts: [6, 16],
      zaps: [9735],
    };

    return await this.getRecentEventsByTag('e', noteId, {
      kinds: kindMap[detailKind],
      limit,
    });
  }

  async getLatestProfile(pubkey: string): Promise<ProfileRecord | null> {
    return parseProfileEvent(await this.getLatestEventByAuthorKind(pubkey, 0));
  }

  async getLatestProfiles(pubkeys: string[]): Promise<Map<string, ProfileRecord>> {
    const profiles = new Map<string, ProfileRecord>();
    const uniquePubkeys = [...new Set(pubkeys)];
    const concurrency = 8;
    for (let index = 0; index < uniquePubkeys.length; index += concurrency) {
      const entries = await Promise.all(
        uniquePubkeys.slice(index, index + concurrency).map(async (pubkey) => (
          [pubkey, await this.getLatestProfile(pubkey)] as const
        )),
      );
      for (const [pubkey, profile] of entries) {
        if (profile) {
          profiles.set(pubkey, profile);
        }
      }
    }

    return profiles;
  }

  async getRecentEventsByTag(
    tagName: string,
    tagValue: string,
    options: {
      before?: RecentTextNoteCursor;
      kinds?: number[];
      limit?: number;
    } = {},
  ): Promise<RawEvent[]> {
    if (!tagName || !tagValue) {
      return [];
    }

    const normalizedName = tagName.toLowerCase(), normalizedValue = normalizeTagValue(normalizedName, tagValue);
    const requestedLimit = Math.max(options.limit ?? 50, 1);
    const source = await this.getCollectionSource();
    if (hasCollectionIndex(source, MANIFEST_BY_TAG)) {
      return await readIndexedEventsByTag({
        before: options.before,
        kinds: options.kinds,
        limit: requestedLimit,
        normalizedName,
        normalizedValue,
        readEvent: async (cid) => await this.readEvent(cid),
        source,
      });
    }

    return await readFallbackEventsByTag({
      before: options.before,
      eventStore: this.eventStore,
      kinds: options.kinds,
      limit: requestedLimit,
      normalizedName,
      normalizedValue,
      root: this.root,
      toRawEvent: async (event) => await this.verifyStoredEvent(event),
    });
  }

  async *streamSocialGraphEvents(): AsyncGenerator<RawEvent, void, void> {
    for (const kind of [3, 10000]) {
      for await (const event of this.eventStore.streamByKind(this.root, kind)) {
        const verified = await this.verifyStoredEvent(event, { observeSocialGraph: false });
        if (verified) {
          yield verified;
        }
      }
    }
  }

  streamRecentTextNotesByAuthors(
    authors: string[],
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    return this.feeds.streamRecentTextNotesByAuthors(authors, limit, options);
  }

  async getRecentTextNotes(
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    return await this.feeds.getRecentTextNotes(limit, options);
  }

  async getRecentInteractionsByAuthors(
    authors: string[],
    limit: number,
    kinds: readonly number[] = NOSTR_INDEX_INTERACTION_KINDS,
  ): Promise<RawEvent[]> {
    return await this.feeds.getRecentInteractionsByAuthors(authors, limit, kinds);
  }

  async getRecentTextNotesByAuthors(
    authors: string[],
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    return await this.feeds.getRecentTextNotesByAuthors(authors, limit, options);
  }

  async getRecentTextNotesByAuthor(
    pubkey: string,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): Promise<RawEvent[]> {
    return await this.feeds.getRecentTextNotesByAuthor(pubkey, limit, options);
  }

  streamRecentTextNotesByAuthor(
    pubkey: string,
    limit: number,
    options: RecentTextNoteQueryOptions = {},
  ): AsyncGenerator<RawEvent[], void, void> {
    return this.feeds.streamRecentTextNotesByAuthor(pubkey, limit, options);
  }
}
