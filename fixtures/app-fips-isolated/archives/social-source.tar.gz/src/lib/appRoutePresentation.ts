import { writable } from 'svelte/store';
import type { Route } from './appRoute';

const presentedRouteStore = writable<Route | null>(null);
let currentPresentedRoute: Route | null = null;

/**
 * Lightweight source of truth for the route card and chrome currently on
 * screen. It wakes only the fixed stack wrappers and shell; the larger shared
 * live-state projection adopts a retained route after that card has painted.
 */
export const presentedRoute = {
  subscribe: presentedRouteStore.subscribe,
};

export function getPresentedRoute(): Route | null {
  return currentPresentedRoute;
}

export function setPresentedRoute(route: Route): void {
  currentPresentedRoute = route;
  presentedRouteStore.set(route);
}
