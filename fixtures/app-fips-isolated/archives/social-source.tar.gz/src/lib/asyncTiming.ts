export async function sleep(ms: number): Promise<void> {
  await new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });
}

/**
 * Let state changes reach the screen before starting work for the new view.
 * Two animation frames guarantee that the browser had a rendering opportunity
 * between callbacks. A single frame followed by a timer can still start a long
 * task before the compositor presents the route on slower devices.
 */
export async function waitForNextBrowserPaint(): Promise<void> {
  if (
    typeof window === 'undefined'
    || typeof document === 'undefined'
    || typeof window.requestAnimationFrame !== 'function'
    || document.visibilityState === 'hidden'
  ) {
    await sleep(0);
    return;
  }

  await new Promise<void>((resolve) => {
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => {
        window.setTimeout(resolve, 0);
      });
    });
  });
}
