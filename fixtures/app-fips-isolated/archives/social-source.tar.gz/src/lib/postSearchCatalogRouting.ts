import { nhashEncode, type Store } from '@hashtree/core';
import { BTree } from '@hashtree/index';
import { throwIfPostSearchAborted } from './postSearchAbort';
import type { PostSearchCatalog } from './postSearchCatalog';
import {
  parsePostSearchRoutingKey,
  parsePostSearchRoutingQueryTerms,
  postSearchRoutingPrefix,
} from './postSearchTermRouting';

const MAX_ROUTED_QUERY_TERMS = 64;

export async function routePostSearchSegments(
  store: Store,
  catalog: PostSearchCatalog,
  compatibleSegments: readonly PostSearchCatalog['segments'][number][],
  query: string,
  operator: 'or' | 'and',
  signal: AbortSignal | null,
): Promise<PostSearchCatalog['segments']> {
  throwIfPostSearchAborted(signal);
  if (!catalog.routing) {
    return [...compatibleSegments];
  }
  if (!catalog.routing.root) {
    return [];
  }
  const terms = parsePostSearchRoutingQueryTerms(query);
  if (terms.length === 0) {
    return [];
  }
  if (terms.length > MAX_ROUTED_QUERY_TERMS) {
    return [...compatibleSegments];
  }

  const segmentsByRoot = new Map(catalog.segments.map((segment) => [
    nhashEncode(segment.root),
    segment,
  ]));
  const routingIndex = new BTree(store);
  const rootsByTerm: Set<string>[] = [];
  let mappingsRead = 0;
  for (const term of terms) {
    throwIfPostSearchAborted(signal);
    const roots = new Set<string>();
    const prefix = postSearchRoutingPrefix(term);
    for await (const [key] of routingIndex.prefix(catalog.routing.root, prefix)) {
      throwIfPostSearchAborted(signal);
      mappingsRead += 1;
      if (mappingsRead > catalog.routing.mappingCount) {
        throw new Error('Post search term routing exceeds its declared coverage');
      }
      const segmentRoot = parsePostSearchRoutingKey(key, term);
      if (!segmentRoot || !segmentsByRoot.has(segmentRoot)) {
        throw new Error('Post search term routing references an unknown segment');
      }
      roots.add(segmentRoot);
    }
    rootsByTerm.push(roots);
  }

  let selectedRoots: Set<string>;
  if (operator === 'and') {
    selectedRoots = new Set(rootsByTerm[0] ?? []);
    for (const roots of rootsByTerm.slice(1)) {
      for (const root of selectedRoots) {
        if (!roots.has(root)) {
          selectedRoots.delete(root);
        }
      }
    }
  } else {
    selectedRoots = new Set(rootsByTerm.flatMap((roots) => [...roots]));
  }

  return compatibleSegments.filter((segment) => selectedRoots.has(nhashEncode(segment.root)));
}
