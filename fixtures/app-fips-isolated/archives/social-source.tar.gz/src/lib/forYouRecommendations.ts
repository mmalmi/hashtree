import type { CID } from '@hashtree/core';
import type { RawEvent } from './nostr';
import type { ForYouFeedDeps } from './forYouFeed';
import { awaitWithin } from './feedIndexTiming';
import { verifyEmbeddedRepostTargets } from './repostPresentation';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';

export const FOR_YOU_INTERACTION_KINDS = [6, 7] as const;
const FOR_YOU_TARGET_LOOKUP_LIMIT = 32;
const FOR_YOU_READ_DEADLINE_MS = 4_000;
const FOR_YOU_TARGET_READ_DEADLINE_MS = 2_500;

type TargetEndorsements = {
  supporters: Set<string>;
  latestInteractionAt: number;
};

export function getForYouInteractionTargetEventId(event: RawEvent): string | null {
  if (!FOR_YOU_INTERACTION_KINDS.includes(
    event.kind as typeof FOR_YOU_INTERACTION_KINDS[number],
  ) || (event.kind === 7 && event.content.trim() === '-')) {
    return null;
  }
  return getLastValidLowercaseEventTarget(event);
}

export function collectTargetEndorsements(
  interactions: readonly RawEvent[],
  excludeEventIds?: ReadonlySet<string>,
): Map<string, TargetEndorsements> {
  const byTarget = new Map<string, TargetEndorsements>();
  for (const interaction of interactions) {
    const targetId = getForYouInteractionTargetEventId(interaction);
    if (!targetId || excludeEventIds?.has(targetId)) {
      continue;
    }
    const endorsements = byTarget.get(targetId);
    if (endorsements) {
      endorsements.supporters.add(interaction.pubkey);
      endorsements.latestInteractionAt = Math.max(endorsements.latestInteractionAt, interaction.created_at);
    } else {
      byTarget.set(targetId, {
        supporters: new Set([interaction.pubkey]),
        latestInteractionAt: interaction.created_at,
      });
    }
  }
  return byTarget;
}

export function compareTargetEndorsements(left: TargetEndorsements, right: TargetEndorsements): number {
  return right.supporters.size - left.supporters.size
    || right.latestInteractionAt - left.latestInteractionAt;
}

type Recommendations = { interactions: RawEvent[]; targets: RawEvent[] };

export async function* streamForYouRecommendations(
  root: CID,
  authors: string[],
  interactionLimit: number,
  options: { excludeEventIds?: ReadonlySet<string> },
  deps: Pick<ForYouFeedDeps, 'loadRecentInteractionsByAuthors' | 'getRecentOverlayInteractionsByAuthors'
    | 'getOverlayEventById' | 'loadEventById' | 'loadEventsByIds'>,
): AsyncGenerator<Recommendations> {
  const allowed = new Set(authors);
  const signals = new Map<string, RawEvent>();
  const bodies = new Map<string, RawEvent>();
  const requested = new Set<string>();
  const checkedWrappers = new Set<string>();
  const verifying = new Set<string>();
  let active = true;
  let openReads = 1;
  let version = 0;
  let wake: (() => void) | undefined;
  let timer: ReturnType<typeof setTimeout> | undefined;
  // Batch the worker's partial deliveries across one frame. The final report
  // can close the read but is not required to rank an already verified body.
  function notify() {
    if (!active) { return; }
    version++;
    if (wake && !timer) {
      timer = setTimeout(() => { timer = undefined; wake?.(); wake = undefined; }, 16);
    }
  }
  function acceptSignals(events: readonly RawEvent[]) {
    if (!active) { return; }
    for (const event of events) {
      if (allowed.has(event.pubkey) && !signals.has(event.id) && getForYouInteractionTargetEventId(event)) {
        signals.set(event.id, event);
        notify();
      }
    }
  }
  function acceptBodies(events: readonly RawEvent[]) {
    if (!active) { return; }
    for (const event of events) {
      if (requested.has(event.id) && !bodies.has(event.id)) { bodies.set(event.id, event); notify(); }
    }
  }
  function finished() { openReads--; notify(); }

  acceptSignals(deps.getRecentOverlayInteractionsByAuthors?.(authors, interactionLimit) ?? []);
  void awaitWithin(deps.loadRecentInteractionsByAuthors([root], authors, interactionLimit, acceptSignals)
    .catch(() => []), FOR_YOU_READ_DEADLINE_MS).then(result => {
    if (result.settled) { acceptSignals(result.value); }
  }).finally(finished);
  let deliveredVersion = -1;
  try {
    while (active) {
      const interactions = [...signals.values()];
      const ids = [...collectTargetEndorsements(interactions, options.excludeEventIds)]
        .sort(([a, left], [b, right]) => compareTargetEndorsements(left, right) || a.localeCompare(b))
        .slice(0, FOR_YOU_TARGET_LOOKUP_LIMIT).map(([id]) => id);
      const selectedIds = new Set(ids);
      for (const id of ids) {
        const cached = !bodies.has(id) && deps.getOverlayEventById?.(id);
        if (cached) { bodies.set(id, cached); }
      }
      // A repost may carry the only copy of its original. Verify selected
      // embedded bodies locally while other recommendation reads continue.
      const wrappers = interactions.filter(event => {
        if (event.kind !== 6 || !event.content || checkedWrappers.has(event.id)) { return false; }
        const target = getForYouInteractionTargetEventId(event);
        return target && selectedIds.has(target) && !bodies.has(target) && !verifying.has(target);
      });
      if (wrappers.length) {
        const targets = new Set(wrappers.map(wrapper => getForYouInteractionTargetEventId(wrapper)!));
        for (const target of targets) { verifying.add(target); }
        for (const wrapper of wrappers) { checkedWrappers.add(wrapper.id); }
        openReads++;
        void awaitWithin(verifyEmbeddedRepostTargets(wrappers).catch(() => []), FOR_YOU_TARGET_READ_DEADLINE_MS)
          .then(result => {
            if (active && result.settled) {
              for (const body of result.value) { bodies.set(body.id, body); }
            }
          }).finally(() => {
            for (const target of targets) { verifying.delete(target); }
            finished();
          });
      }
      const missing: string[] = [];
      for (const id of ids) {
        if (!bodies.has(id) && !verifying.has(id) && !requested.has(id) && requested.size < 2 * FOR_YOU_TARGET_LOOKUP_LIMIT) {
          requested.add(id);
          missing.push(id);
        }
      }
      if (missing.length > 0) {
        openReads++;
        const read = deps.loadEventsByIds
          ? deps.loadEventsByIds([root], missing, acceptBodies)
          : Promise.all(missing.map(id => awaitWithin(deps.loadEventById([root], id).catch(() => null),
              FOR_YOU_TARGET_READ_DEADLINE_MS).then(result => result.settled ? result.value : null)))
            .then(events => events.filter((event): event is RawEvent => !!event));
        void awaitWithin(read.catch(() => []), FOR_YOU_READ_DEADLINE_MS).then(result => {
          if (result.settled) { acceptBodies(result.value); }
        }).finally(finished);
      }
      const current = version;
      if (interactions.length && deliveredVersion !== current && (bodies.size || !openReads)) {
        deliveredVersion = current;
        yield { interactions, targets: [...bodies.values()] };
      }
      if (current !== version) { continue; }
      if (!openReads) { break; }
      await new Promise<void>(resolve => { wake = resolve; });
    }
  } finally {
    active = false;
    clearTimeout(timer);
  }
}
