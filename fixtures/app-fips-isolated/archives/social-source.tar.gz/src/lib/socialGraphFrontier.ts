import { isHexPubkey } from './nostr';
import {
  SOCIAL_GRAPH_FRONTIER_AUTHOR_COUNT,
  SOCIAL_GRAPH_FRONTIER_BYTES,
  SOCIAL_GRAPH_FRONTIER_SHA256,
  SOCIAL_GRAPH_FRONTIER_URL,
  SOCIAL_GRAPH_ROOT,
} from './socialGraphSnapshot.generated';

const PUBKEY_BYTES = 32;
const MAX_FRONTIER_BYTES = 512 * PUBKEY_BYTES;

let frontierPromise: Promise<string[]> | null = null;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', Uint8Array.from(bytes).buffer);
  return bytesToHex(new Uint8Array(digest));
}

export async function parseSocialGraphFrontier(bytes: Uint8Array): Promise<string[]> {
  if (
    bytes.length === 0
    || bytes.length !== SOCIAL_GRAPH_FRONTIER_BYTES
    || bytes.length > MAX_FRONTIER_BYTES
    || bytes.length % PUBKEY_BYTES !== 0
    || await sha256Hex(bytes) !== SOCIAL_GRAPH_FRONTIER_SHA256
  ) {
    return [];
  }

  const authors: string[] = [];
  for (let offset = 0; offset < bytes.length; offset += PUBKEY_BYTES) {
    const pubkey = bytesToHex(bytes.subarray(offset, offset + PUBKEY_BYTES));
    if (!isHexPubkey(pubkey)) {
      return [];
    }
    authors.push(pubkey);
  }
  const uniqueAuthors = [...new Set(authors)];
  return uniqueAuthors.length === SOCIAL_GRAPH_FRONTIER_AUTHOR_COUNT ? uniqueAuthors : [];
}

async function fetchSocialGraphFrontier(fetcher: typeof fetch): Promise<string[]> {
  try {
    const response = await fetcher(SOCIAL_GRAPH_FRONTIER_URL, { cache: 'force-cache' });
    if (!response.ok) {
      return [];
    }
    return await parseSocialGraphFrontier(new Uint8Array(await response.arrayBuffer()));
  } catch {
    return [];
  }
}

export function loadSocialGraphFrontier(fetcher: typeof fetch = fetch): Promise<string[]> {
  if (fetcher !== fetch) {
    return fetchSocialGraphFrontier(fetcher);
  }
  frontierPromise ??= fetchSocialGraphFrontier(fetcher);
  return frontierPromise;
}

export function selectSocialGraphFrontierAuthors(
  viewerPubkey: string,
  fallbackFeedOwnerPubkey: string,
  frontier: readonly string[],
): string[] {
  return [...new Set(frontier)]
    .filter((pubkey) => pubkey !== viewerPubkey && pubkey !== fallbackFeedOwnerPubkey);
}

export function selectViewerRootFrontierFollows(
  viewerPubkey: string,
  frontier: readonly string[],
): string[] | null {
  if (viewerPubkey !== SOCIAL_GRAPH_ROOT) {
    return null;
  }
  return [...new Set(frontier)].filter((pubkey) => pubkey !== viewerPubkey);
}

/** Start the tiny frontier request without awaiting the complete social graph. */
export function warmSocialGraphFrontier(): void {
  void loadSocialGraphFrontier();
}
