import type { RawEvent } from './nostr';

type SensitiveMediaEvent = Pick<RawEvent, 'content' | 'tags'>;

const NSFW_HASHTAG_PATTERN = /(?:^|[^\p{L}\p{N}_])#nsfw(?![\p{L}\p{N}_])/iu;

export function getSensitiveMediaWarning(event: SensitiveMediaEvent): string | null {
  const warningTag = event.tags.find((tag) => tag[0]?.toLowerCase() === 'content-warning');
  if (warningTag) {
    return warningTag[1]?.trim() || 'Sensitive media';
  }

  const hasNsfwTag = event.tags.some((tag) => (
    tag[0]?.toLowerCase() === 't' && tag[1]?.trim().toLowerCase() === 'nsfw'
  ));
  return hasNsfwTag || NSFW_HASHTAG_PATTERN.test(event.content) ? 'Sensitive media' : null;
}

export function isSensitiveMediaEvent(event: SensitiveMediaEvent): boolean {
  return getSensitiveMediaWarning(event) !== null;
}
