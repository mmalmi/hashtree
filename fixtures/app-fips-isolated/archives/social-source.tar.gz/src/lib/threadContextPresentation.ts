export function shouldRenderThreadContextEmbeds(
  contextIndex: number,
  contextCount: number,
): boolean {
  return Number.isInteger(contextIndex)
    && Number.isInteger(contextCount)
    && contextIndex >= 0
    && contextCount > 0
    && contextIndex === contextCount - 1;
}
