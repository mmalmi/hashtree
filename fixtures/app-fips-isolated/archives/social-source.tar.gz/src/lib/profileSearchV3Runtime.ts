import { HashTree, nhashEncode, type CID, type Store } from '@hashtree/core';
import {
  ROOT_RESOLVE_SETTLE_MS,
  ROOT_RESOLVE_TIMEOUT_MS,
  getConfiguredProfileSearchIndexRefs,
  getConfiguredProfileSearchV3IndexRef,
  getConfiguredProfileSearchV3IndexRefs,
} from './config';
import type { ProfileRecord } from './nostr';
import {
  mergeFederatedProfileSearchProfiles,
  searchProfileIndex,
  searchProfileIndexRefs,
  type ProfileSearchProgressHandler,
} from './profileSearch';
import {
  profileSearchAbortReason,
  throwIfProfileSearchAborted,
  withProfileSearchAbort,
} from './profileSearchAbort';
import { profileSearchRank } from './profileSearchRanking';
import {
  openProfileSearchV3ClientCatalog,
  type ProfileSearchV3ClientCatalog,
} from './profileSearchV3Client';
import { resolveTreeTargetRoot } from './treeRef';
import { createWorkerBlockStore } from './workerBlockStore';

const PROFILE_SEARCH_V3_ROOT_TTL_MS = 30_000;
const PROFILE_SEARCH_V3_ROOT_RETRY_DELAYS_MS = [120, 360, 900];
const PROFILE_SEARCH_V3_SOURCE_TIMEOUT_MS = 3_500;
const PROFILE_SEARCH_V3_SOURCE_CONCURRENCY = 3;
const PROFILE_SEARCH_V3_CACHE_LIMIT = 32;

export type ProfileSearchV3RootResolver = (
  ref: string,
  signal: AbortSignal | null,
) => Promise<CID | null>;

export type ProfileSearchV3RuntimeOptions = {
  store: Store;
  resolveRoot: ProfileSearchV3RootResolver;
  sourceTimeoutMs?: number;
  sourceConcurrency?: number;
};

type CachedRoot = { root: CID; expiresAt: number };
type CachedCatalog = { root: string; catalog: ProfileSearchV3ClientCatalog };

/** Browser-only v3 federation over immutable, hash-authenticated catalog blocks. */
export class ProfileSearchV3Runtime {
  private readonly sourceTimeoutMs: number;
  private readonly sourceConcurrency: number;
  private readonly roots = new Map<string, CachedRoot>();
  private readonly pendingRoots = new Map<string, Promise<CID | null>>();
  private readonly catalogs = new Map<string, CachedCatalog>();
  private readonly pendingCatalogs = new Map<string, Promise<ProfileSearchV3ClientCatalog>>();

  constructor(private readonly options: ProfileSearchV3RuntimeOptions) {
    this.sourceTimeoutMs = boundedRuntimeInteger(
      options.sourceTimeoutMs ?? PROFILE_SEARCH_V3_SOURCE_TIMEOUT_MS,
      100,
      60_000,
      'source timeout',
    );
    this.sourceConcurrency = boundedRuntimeInteger(
      options.sourceConcurrency ?? PROFILE_SEARCH_V3_SOURCE_CONCURRENCY,
      1,
      8,
      'source concurrency',
    );
  }

  async search(
    refs: readonly string[],
    query: string,
    limit: number,
    signal: AbortSignal | null = null,
    onProgress: ProfileSearchProgressHandler | null = null,
  ): Promise<ProfileRecord[]> {
    throwIfProfileSearchAborted(signal);
    const orderedRefs = [...new Set(refs.map((ref) => ref.trim()).filter(Boolean))];
    if (orderedRefs.length === 0 || !query.trim()) {return [];}
    const boundedLimit = boundedRuntimeInteger(limit, 1, 100, 'query limit');
    const sourceResults = new Array<ProfileRecord[]>(orderedRefs.length).fill([]);
    const emit = (): void => {
      if (!onProgress) {return;}
      throwIfProfileSearchAborted(signal);
      onProgress(mergeRankedSources(sourceResults, query, boundedLimit));
    };
    await mapConcurrent(orderedRefs, this.sourceConcurrency, async (ref, index) => {
      try {
        sourceResults[index] = await withChildTimeout(
          signal,
          this.sourceTimeoutMs,
          async (sourceSignal) => {
            const catalog = await this.open(ref, sourceSignal);
            if (!catalog) {return [];}
            return await catalog.search(query, boundedLimit, {
              signal: sourceSignal,
              concurrency: 4,
              onProgress: (profiles) => {
                sourceResults[index] = profiles;
                emit();
              },
            });
          },
        );
        emit();
      } catch {
        throwIfProfileSearchAborted(signal);
        // An unavailable/corrupt publisher is isolated; already verified
        // progress from other publishers remains usable.
      }
    });
    throwIfProfileSearchAborted(signal);
    return mergeRankedSources(sourceResults, query, boundedLimit);
  }

  async warm(refs: readonly string[], signal: AbortSignal | null = null): Promise<void> {
    const orderedRefs = [...new Set(refs.map((ref) => ref.trim()).filter(Boolean))];
    await mapConcurrent(orderedRefs, this.sourceConcurrency, async (ref) => {
      try {
        await withChildTimeout(signal, this.sourceTimeoutMs, async (sourceSignal) => {
          await this.open(ref, sourceSignal);
        });
      } catch {
        throwIfProfileSearchAborted(signal);
      }
    });
  }

  private async open(
    ref: string,
    signal: AbortSignal | null,
  ): Promise<ProfileSearchV3ClientCatalog | null> {
    const root = await this.resolve(ref, signal);
    if (!root) {return null;}
    const rootId = nhashEncode(root);
    const cached = lruGet(this.catalogs, ref);
    if (cached?.root === rootId) {return cached.catalog;}
    const pendingKey = `${ref}\0${rootId}`;
    const pending = this.pendingCatalogs.get(pendingKey);
    if (pending) {return await withProfileSearchAbort(pending, signal);}
    // Shared immutable opening is not owned by the first caller's cancellation.
    const created = openProfileSearchV3ClientCatalog(this.options.store, root, null);
    this.pendingCatalogs.set(pendingKey, created);
    void created.then((catalog) => {
      lruSet(this.catalogs, ref, { root: rootId, catalog }, PROFILE_SEARCH_V3_CACHE_LIMIT);
    }).finally(() => {
      if (this.pendingCatalogs.get(pendingKey) === created) {
        this.pendingCatalogs.delete(pendingKey);
      }
    }).catch(() => undefined);
    return await withProfileSearchAbort(created, signal);
  }

  private async resolve(ref: string, signal: AbortSignal | null): Promise<CID | null> {
    throwIfProfileSearchAborted(signal);
    const cached = lruGet(this.roots, ref);
    if (cached && cached.expiresAt > Date.now()) {return cached.root;}
    const pending = this.pendingRoots.get(ref);
    if (pending) {return await withProfileSearchAbort(pending, signal);}
    // The shared resolution is not owned by the first caller's cancellation.
    // Every consumer races it against its own signal/timeout below.
    const created = this.options.resolveRoot(ref, null);
    this.pendingRoots.set(ref, created);
    void created.then((root) => {
      if (root) {
        lruSet(this.roots, ref, {
          root,
          expiresAt: Date.now() + PROFILE_SEARCH_V3_ROOT_TTL_MS,
        }, PROFILE_SEARCH_V3_CACHE_LIMIT);
      }
    }).finally(() => {
      if (this.pendingRoots.get(ref) === created) {this.pendingRoots.delete(ref);}
    }).catch(() => undefined);
    return await withProfileSearchAbort(created, signal);
  }
}

const workerStore = createWorkerBlockStore();
const workerTree = new HashTree({ store: workerStore });
const browserRuntime = new ProfileSearchV3Runtime({
  store: workerStore,
  resolveRoot: async (ref) => await resolveTreeTargetRoot(ref, {
    resolveImmutablePath: async (root, path) =>
      (await workerTree.resolvePath(root, path))?.cid ?? null,
    timeoutMs: ROOT_RESOLVE_TIMEOUT_MS,
    settleMs: ROOT_RESOLVE_SETTLE_MS,
    retryDelaysMs: PROFILE_SEARCH_V3_ROOT_RETRY_DELAYS_MS,
  }),
});

export async function warmProfileSearchV3Indexes(): Promise<void> {
  await browserRuntime.warm(getConfiguredProfileSearchV3IndexRefs());
}

/** V3 and legacy readers race for instant progress; final ordering remains v3-primary. */
export async function searchProfileSearchRollout(
  query: string,
  limit: number,
  signal: AbortSignal | null = null,
  onProgress: ProfileSearchProgressHandler | null = null,
): Promise<ProfileRecord[]> {
  const v3Refs = getConfiguredProfileSearchV3IndexRefs();
  if (v3Refs.length === 0) {
    return await searchProfileIndex(query, limit, signal, onProgress);
  }
  // A primary v3 pointer is the explicit cutover signal. Plural-only refs are
  // shadow federation and continue racing the legacy catalog for comparison;
  // a primary avoids waiting on or downloading the retired search structure.
  if (getConfiguredProfileSearchV3IndexRef()) {
    return await browserRuntime.search(v3Refs, query, limit, signal, onProgress);
  }
  throwIfProfileSearchAborted(signal);
  let v3Profiles: ProfileRecord[] = [];
  let legacyProfiles: ProfileRecord[] = [];
  const emit = (): void => {
    if (!onProgress) {return;}
    throwIfProfileSearchAborted(signal);
    onProgress(mergeRolloutProfiles(v3Profiles, legacyProfiles, query, limit));
  };
  const v3 = browserRuntime.search(v3Refs, query, limit, signal, (profiles) => {
    v3Profiles = profiles;
    emit();
  }).then((profiles) => {
    v3Profiles = profiles;
    emit();
  });
  const legacy = searchProfileIndexRefs(
    getConfiguredProfileSearchIndexRefs(),
    query,
    limit,
    signal,
    (profiles) => {
      legacyProfiles = profiles;
      emit();
    },
  ).then((profiles) => {
    legacyProfiles = profiles;
    emit();
  });
  await withProfileSearchAbort(Promise.allSettled([v3, legacy]), signal);
  throwIfProfileSearchAborted(signal);
  return mergeRolloutProfiles(v3Profiles, legacyProfiles, query, limit);
}

/** Deterministic rollout merge: signed freshness, then v3/social source position. */
export function mergeRolloutProfiles(
  v3Profiles: readonly ProfileRecord[],
  legacyProfiles: readonly ProfileRecord[],
  query: string,
  limit: number,
): ProfileRecord[] {
  const merged = mergeFederatedProfileSearchProfiles(
    [v3Profiles, legacyProfiles],
    query,
    Math.max(limit, v3Profiles.length + legacyProfiles.length),
  );
  const v3Rank = new Map(v3Profiles.map((profile, index) => [profile.pubkey, index]));
  const legacyRank = new Map(legacyProfiles.map((profile, index) => [profile.pubkey, index]));
  const ranked = merged.map((profile) => ({
    profile,
    textScore: profileSearchRank(profile, query).textScore,
  }));
  return ranked.sort((left, right) => {
    const textOrder = right.textScore - left.textScore;
    if (textOrder !== 0) {return textOrder;}
    const leftV3 = v3Rank.get(left.profile.pubkey);
    const rightV3 = v3Rank.get(right.profile.pubkey);
    if (leftV3 !== undefined || rightV3 !== undefined) {
      if (leftV3 === undefined) {return 1;}
      if (rightV3 === undefined) {return -1;}
      return leftV3 - rightV3 || compareText(left.profile.pubkey, right.profile.pubkey);
    }
    return (legacyRank.get(left.profile.pubkey) ?? Number.MAX_SAFE_INTEGER)
      - (legacyRank.get(right.profile.pubkey) ?? Number.MAX_SAFE_INTEGER)
      || compareText(left.profile.pubkey, right.profile.pubkey);
  }).slice(0, limit).map(({ profile }) => profile);
}

function mergeRankedSources(
  sources: readonly (readonly ProfileRecord[])[],
  query: string,
  limit: number,
): ProfileRecord[] {
  const sourceRank = new Map<string, { source: number; rank: number }>();
  sources.forEach((profiles, source) => profiles.forEach((profile, rank) => {
    const current = sourceRank.get(profile.pubkey);
    if (!current || rank < current.rank || rank === current.rank && source < current.source) {
      sourceRank.set(profile.pubkey, { source, rank });
    }
  }));
  return mergeFederatedProfileSearchProfiles(
    sources,
    query,
    Math.max(limit, sourceRank.size),
  ).map((profile) => ({
    profile,
    textScore: profileSearchRank(profile, query).textScore,
  })).sort((left, right) => {
    const textOrder = right.textScore - left.textScore;
    if (textOrder !== 0) {return textOrder;}
    const leftRank = sourceRank.get(left.profile.pubkey)!;
    const rightRank = sourceRank.get(right.profile.pubkey)!;
    return leftRank.rank - rightRank.rank
      || leftRank.source - rightRank.source
      || compareText(left.profile.pubkey, right.profile.pubkey);
  }).slice(0, limit).map(({ profile }) => profile);
}

async function withChildTimeout<T>(
  parent: AbortSignal | null,
  timeoutMs: number,
  operation: (signal: AbortSignal) => Promise<T>,
): Promise<T> {
  throwIfProfileSearchAborted(parent);
  const controller = new AbortController();
  const abortFromParent = () => controller.abort(profileSearchAbortReason(parent));
  parent?.addEventListener('abort', abortFromParent, { once: true });
  const timer = setTimeout(() => {
    controller.abort(new DOMException('Profile-search v3 source timed out', 'TimeoutError'));
  }, timeoutMs);
  try {
    return await withProfileSearchAbort(operation(controller.signal), controller.signal);
  } finally {
    clearTimeout(timer);
    parent?.removeEventListener('abort', abortFromParent);
  }
}

async function mapConcurrent<Input, Output>(
  values: readonly Input[],
  concurrency: number,
  worker: (value: Input, index: number) => Promise<Output>,
): Promise<Output[]> {
  const output = new Array<Output>(values.length);
  let cursor = 0;
  const run = async (): Promise<void> => {
    while (cursor < values.length) {
      const index = cursor;
      cursor += 1;
      output[index] = await worker(values[index]!, index);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, values.length) }, run));
  return output;
}

function lruGet<Key, Value>(cache: Map<Key, Value>, key: Key): Value | undefined {
  const value = cache.get(key);
  if (value !== undefined) {
    cache.delete(key);
    cache.set(key, value);
  }
  return value;
}

function lruSet<Key, Value>(
  cache: Map<Key, Value>,
  key: Key,
  value: Value,
  limit: number,
): void {
  cache.delete(key);
  while (cache.size >= limit) {
    cache.delete(cache.keys().next().value as Key);
  }
  cache.set(key, value);
}

function boundedRuntimeInteger(
  value: unknown,
  minimum: number,
  maximum: number,
  label: string,
): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)
    || value < minimum || value > maximum) {
    throw new Error(`Invalid profile-search v3 ${label}`);
  }
  return value;
}

function compareText(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}
