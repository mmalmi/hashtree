import { createRetryableDynamicImport } from './retryableDynamicImport';

export const loadPrivateContactSync = createRetryableDynamicImport(
  () => import('nostr-social-graph/privateContactSyncV2'),
);
export const loadPrivateContactSyncController = createRetryableDynamicImport(
  () => import('nostr-social-graph/privateContactSyncV2Controller'),
);
