import { createConcurrencyLimiter } from './orderedConcurrent';

export const MEDIA_RESOLUTION_CONCURRENCY = 4;
export const MEDIA_RESOLUTION_TIMEOUT_MS = 15_000;

export type MediaLoadOptions<T> = {
  timeoutMs?: number;
  onLateResult?: (value: T) => void;
};

export type MediaLoadScheduler = <T>(
  task: () => Promise<T>,
  options?: MediaLoadOptions<T>,
) => Promise<T>;

export function createMediaLoadScheduler(
  concurrency = MEDIA_RESOLUTION_CONCURRENCY,
): MediaLoadScheduler {
  const limiter = createConcurrencyLimiter(concurrency);
  return <T>(task: () => Promise<T>, options: MediaLoadOptions<T> = {}): Promise<T> => (
    new Promise<T>((resolve, reject) => {
      let callerSettled = false;
      const timeoutId = setTimeout(() => {
        callerSettled = true;
        reject(new Error('Media resolution timed out'));
      }, Math.max(1, options.timeoutMs ?? MEDIA_RESOLUTION_TIMEOUT_MS));

      void limiter.run(async () => {
        if (callerSettled) {
          throw new Error('Media resolution cancelled');
        }
        return await task();
      }).then((value) => {
        clearTimeout(timeoutId);
        if (callerSettled) {
          options.onLateResult?.(value);
          return;
        }
        callerSettled = true;
        resolve(value);
      }, (error) => {
        clearTimeout(timeoutId);
        if (callerSettled) {
          return;
        }
        callerSettled = true;
        reject(error);
      });
    })
  );
}

export const scheduleMediaResolution = createMediaLoadScheduler();
