import { accountsStore } from './accounts';
import { createSocialGraphBadgeCache } from './socialGraphBadgeCache';

export const socialGraphBadges = createSocialGraphBadgeCache(async (viewer, pubkeys, signal) => {
  const { getWorkerClient } = await import('./workerClient');
  return await (await getWorkerClient()).querySocialGraphBadges(viewer, pubkeys, signal);
});
let consumers = 0;
let unsubscribeAccounts: (() => void) | null = null;

export function watchSocialGraphBadge(pubkey: string): () => void {
  consumers += 1;
  unsubscribeAccounts ??= accountsStore.subscribe(({ accounts, activeAccountPubkey, initialized }) => {
    const account = accounts.find((value) => value.pubkey === activeAccountPubkey) ?? accounts[0];
    const pristine = account?.isPristineDefault === true
      || (account?.isPristineDefault === undefined && account?.method === 'generated'
        && accounts.length === 1 && account.updatedAt === account.createdAt);
    socialGraphBadges.setViewer(initialized && account && !pristine ? account.pubkey : null);
  });
  const unwatch = socialGraphBadges.watch(pubkey);
  return () => {
    unwatch();
    consumers -= 1;
    if (consumers === 0) {unsubscribeAccounts?.(); unsubscribeAccounts = null;}
  };
}

/** Bind one component's badge interest without another route/store subscriber. */
export function createSocialGraphBadgeBinding(): (pubkey: string | null) => void {
  let watched: string | null = null;
  let unwatch: (() => void) | null = null;
  return (next) => {
    if (next === watched) {return;}
    unwatch?.();
    watched = next;
    unwatch = next ? watchSocialGraphBadge(next) : null;
  };
}
