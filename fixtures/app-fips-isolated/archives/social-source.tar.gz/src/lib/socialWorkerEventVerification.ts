import type { RawEvent } from './nostr';
import {
  MAX_SOCIAL_WORKER_VERIFICATION_BATCH_CODE_UNITS,
  MAX_SOCIAL_WORKER_VERIFICATION_EVENTS,
  measureSocialWorkerVerificationEvent,
} from '../workers/socialWorkerProtocol';

type VerifyBoundedBatch = (
  events: RawEvent[],
  signal?: AbortSignal,
) => Promise<boolean[]>;

export type VerificationScanOptions = {
  maxWorkMs?: number;
  maxScannedEvents?: number;
  now?: () => number;
  yieldControl?: () => Promise<void>;
};

const DEFAULT_MAX_SCAN_WORK_MS = 4;
const DEFAULT_MAX_SCANNED_EVENTS = 1_024;

function abortError(): DOMException {
  return new DOMException('The operation was aborted', 'AbortError');
}

function defaultNow(): number {
  return typeof performance === 'undefined' ? Date.now() : performance.now();
}

function defaultYieldControl(): Promise<void> {
  const scheduler = (
    globalThis as typeof globalThis & {
      scheduler?: { yield?: () => Promise<void> };
    }
  ).scheduler;
  if (typeof scheduler?.yield === 'function') {
    return scheduler.yield();
  }
  if (typeof MessageChannel === 'function') {
    return new Promise<void>((resolve) => {
      const channel = new MessageChannel();
      channel.port1.onmessage = () => {
        channel.port1.close();
        channel.port2.close();
        resolve();
      };
      channel.port2.postMessage(undefined);
    });
  }
  return new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });
}

/**
 * Reject malformed events locally and keep every worker postMessage below its
 * structured-clone budget while preserving one boolean per original event.
 */
export async function verifyEventsInBoundedWorkerBatches(
  events: RawEvent[],
  verifyBatch: VerifyBoundedBatch,
  signal?: AbortSignal,
  scanOptions: VerificationScanOptions = {},
): Promise<boolean[]> {
  if (signal?.aborted) {
    throw abortError();
  }
  if (!Array.isArray(events)) {
    throw new TypeError('Event verification input must be an array');
  }
  if (events.length === 0) {
    return [];
  }

  const maxWorkMs = scanOptions.maxWorkMs ?? DEFAULT_MAX_SCAN_WORK_MS;
  const maxScannedEvents = scanOptions.maxScannedEvents ?? DEFAULT_MAX_SCANNED_EVENTS;
  if (!Number.isFinite(maxWorkMs) || maxWorkMs <= 0) {
    throw new RangeError('Verification scan work budget must be positive and finite');
  }
  if (!Number.isSafeInteger(maxScannedEvents) || maxScannedEvents <= 0) {
    throw new RangeError('Verification scan event budget must be a positive safe integer');
  }
  const now = scanOptions.now ?? defaultNow;
  const yieldControl = scanOptions.yieldControl ?? defaultYieldControl;
  const validity: boolean[] = [];
  let batch: RawEvent[] = [];
  let batchIndexes: number[] = [];
  let batchCodeUnits = 0;
  let sliceStartedAt = now();
  let scannedInSlice = 0;
  const scanNeedsYield = (): boolean => {
    scannedInSlice += 1;
    if (
      scannedInSlice < maxScannedEvents
      && now() - sliceStartedAt < maxWorkMs
    ) {
      return false;
    }
    return true;
  };
  const yieldAfterScan = async (): Promise<void> => {
    await yieldControl();
    if (signal?.aborted) {
      throw abortError();
    }
    scannedInSlice = 0;
    sliceStartedAt = now();
  };
  const flush = async (): Promise<void> => {
    if (batch.length === 0) {
      return;
    }
    const verified = await verifyBatch(batch, signal);
    for (let index = 0; index < batchIndexes.length; index += 1) {
      validity[batchIndexes[index]!] = verified[index] === true;
    }
    batch = [];
    batchIndexes = [];
    batchCodeUnits = 0;
    scannedInSlice = 0;
    sliceStartedAt = now();
  };

  for (let index = 0; index < events.length; index += 1) {
    if (signal?.aborted) {
      throw abortError();
    }
    validity.push(false);
    const event = events[index]!;
    const eventCodeUnits = measureSocialWorkerVerificationEvent(event);
    if (eventCodeUnits === null) {
      if (scanNeedsYield()) {
        await yieldAfterScan();
      }
      continue;
    }
    if (
      batch.length >= MAX_SOCIAL_WORKER_VERIFICATION_EVENTS
      || (
        batch.length > 0
        && batchCodeUnits + eventCodeUnits
          > MAX_SOCIAL_WORKER_VERIFICATION_BATCH_CODE_UNITS
      )
    ) {
      await flush();
    }
    batch.push(event);
    batchIndexes.push(index);
    batchCodeUnits += eventCodeUnits;
    if (scanNeedsYield()) {
      await yieldAfterScan();
    }
  }
  await flush();
  return validity;
}
