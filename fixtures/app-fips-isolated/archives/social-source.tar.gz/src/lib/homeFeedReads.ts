import type { NostrFilter, QueryOptions, QueryReport } from 'nostr-pubsub';
import { queryBrowserAllEvents } from './browserEventReadRouter';
import { awaitWithin } from './feedIndexTiming';
import { mergeUniqueFeedNotes } from './homeFeedPagination';
import { getConfiguredNostrRelays } from './htreeRuntime';
import { isReplyEvent, type RawEvent } from './nostr';
import { DURABLE_POST_KINDS } from './recentAuthorFeedReader';
import { settingsStore } from './settings';
import type { VerifiedReadProgress } from './workerRelayEventReader';

/**
 * Home feed reads. Each is one worker nostr-pubsub query over the cache, the
 * Hashtree index and (with "Read from relays" on) the configured relays. Filters
 * stay relay-shaped: recent windows, at most 256 authors per filter and batches
 * below the transport's 32 KiB subscription limit.
 */
export type FeedRead = (filters: NostrFilter[], options: QueryOptions, onEvents?: VerifiedReadProgress) => Promise<QueryReport>;

const readAllSources: FeedRead = (filters, options, onEvents) => queryBrowserAllEvents([], filters, options, onEvents);

const RECENT_WINDOW_SECONDS = 24 * 60 * 60;
const RELAY_FEED_AUTHORS_PER_FILTER = 256;
// The built-in starter feed follows over 400 authors. Keep the request
// bounded without omitting nearly half of that feed from every refresh.
const MAX_RELAY_FEED_AUTHORS = 2 * RELAY_FEED_AUTHORS_PER_FILTER;
// The shared Nostr transport rejects a logical subscription above 32 KiB.
const MAX_RELAY_BATCH_BYTES = 32_768;
// Enough recent posts that the archive cannot outweigh them; the worker caps
// a query at 256 events.
const RELAY_FEED_EVENT_LIMIT = 240;
const RELAY_FEED_NETWORK_WINDOW_MS = 4_000;
// A worker query can return verified partial results at its network deadline.
// Leave time for its reply to reach the feed before cancelling the request.
const RELAY_FEED_RESPONSE_WINDOW_MS = RELAY_FEED_NETWORK_WINDOW_MS + 1_500;

export function isRecentHomeFeedPost(post: RawEvent, now = Date.now()): boolean {
  return post.created_at >= Math.floor(now / 1_000) - RECENT_WINDOW_SECONDS;
}

export function canReadHomeFeedFromRelays(): boolean {
  return typeof window !== 'undefined'
    && navigator.onLine
    && !document.hidden
    && settingsStore.getState().network.relayHomeFeedReads
    && getConfiguredNostrRelays().length > 0;
}

/** Measure the filters with their transmitted limits before grouping authors on a request. */
async function readAuthorPages(
  authors: string[],
  filter: NostrFilter,
  signal: AbortSignal,
  read: FeedRead,
  onPages?: (pages: RawEvent[][]) => void,
): Promise<RawEvent[][]> {
  const filters: NostrFilter[] = [];
  for (let offset = 0; offset < Math.min(authors.length, MAX_RELAY_FEED_AUTHORS); offset += RELAY_FEED_AUTHORS_PER_FILTER) {
    filters.push({ ...filter, authors: authors.slice(offset, offset + RELAY_FEED_AUTHORS_PER_FILTER), limit: RELAY_FEED_EVENT_LIMIT });
  }
  if (!filters.length) { return []; }
  const split = filters.length > 1 && new TextEncoder().encode(JSON.stringify(filters)).byteLength > MAX_RELAY_BATCH_BYTES;
  const limit = split ? Math.floor(RELAY_FEED_EVENT_LIMIT / filters.length) : RELAY_FEED_EVENT_LIMIT;
  const batches = split ? filters.map(filter => [{ ...filter, limit }]) : [filters];
  const deadline = Date.now() + RELAY_FEED_NETWORK_WINDOW_MS;
  const requestSignal = AbortSignal.any([signal, AbortSignal.timeout(RELAY_FEED_RESPONSE_WINDOW_MS)]);
  const pages = batches.map((): RawEvent[] => []);
  await Promise.allSettled(batches.map(async (batch, index) => {
    const result = await awaitWithin(read(batch, { limit, deadline, signal: requestSignal }, onPages && (events => {
      if (requestSignal.aborted) { return; }
      pages[index] = mergeUniqueFeedNotes(pages[index], [...events]).slice(0, limit);
      onPages(pages);
    })), RELAY_FEED_RESPONSE_WINDOW_MS);
    if (result.settled) {
      pages[index] = result.value.events.map(({ event }) => event);
      if (!requestSignal.aborted) { onPages?.(pages); }
    }
  }));
  signal.throwIfAborted();
  return pages;
}

export async function readRecentFeedPosts(
  authors: string[],
  includeReplies: boolean,
  signal: AbortSignal,
  read: FeedRead = readAllSources,
  onProgress?: (notes: RawEvent[]) => void,
): Promise<RawEvent[]> {
  const until = Math.floor(Date.now() / 1_000);
  const visible = (pages: RawEvent[][]) => mergeUniqueFeedNotes(...pages)
    .filter(event => includeReplies || event.kind !== 1 || !isReplyEvent(event));
  let previous: RawEvent[] = [];
  const pages = await readAuthorPages(authors, {
    kinds: [...DURABLE_POST_KINDS], since: until - RECENT_WINDOW_SECONDS, until,
  }, signal, read, onProgress && (pages => {
    const notes = visible(pages);
    if (notes.length === previous.length && notes.every((note, index) => note.id === previous[index].id)) { return; }
    previous = notes;
    onProgress(notes);
  }));
  return visible(pages);
}

const RELAY_INTERACTION_WINDOW_SECONDS = 48 * 60 * 60;
const RELAY_TARGET_ID_LIMIT = 64;
const RELAY_PAGE_WINDOW_SECONDS = 30 * 24 * 60 * 60;

/**
 * Recent reactions and reposts by the given authors, like Iris Client's
 * popularity filter. A supplied lower bound also supports ranking the newest
 * available page when every source is historical.
 */
export async function readRecentInteractions(
  authors: string[],
  signal: AbortSignal,
  read: FeedRead = readAllSources,
  since?: number,
): Promise<RawEvent[]> {
  const until = Math.floor(Date.now() / 1_000);
  const pages = await readAuthorPages(authors, {
    kinds: [6, 7], since: since ?? until - RELAY_INTERACTION_WINDOW_SECONDS, until,
  }, signal, read);
  return pages.flat();
}

/** Fetch specific posts by id. */
export async function readEventsByIds(
  ids: string[],
  signal: AbortSignal,
  read: FeedRead = readAllSources,
): Promise<RawEvent[]> {
  const wanted = [...new Set(ids)].slice(0, RELAY_TARGET_ID_LIMIT);
  if (wanted.length === 0) { return []; }
  const now = Date.now();
  const requestSignal = AbortSignal.any([signal, AbortSignal.timeout(RELAY_FEED_RESPONSE_WINDOW_MS)]);
  const result = await awaitWithin(read([{ ids: wanted, since: 0, until: Math.floor(now / 1_000) + 60, limit: wanted.length }], {
    limit: wanted.length, deadline: now + RELAY_FEED_NETWORK_WINDOW_MS, signal: requestSignal,
  }), RELAY_FEED_RESPONSE_WINDOW_MS);
  const wantedIds = new Set(wanted);
  return (result.settled ? result.value.events : []).map(({ event }) => event)
    .filter(event => wantedIds.has(event.id));
}

/** Older posts by the given authors, for paging past the archive's author stream. */
export async function readPostsBefore(
  authors: string[],
  until: number,
  signal: AbortSignal,
  read: FeedRead = readAllSources,
): Promise<RawEvent[]> {
  const pages = await readAuthorPages(authors, {
    kinds: [...DURABLE_POST_KINDS], since: Math.max(0, until - RELAY_PAGE_WINDOW_SECONDS), until,
  }, signal, read);
  return mergeUniqueFeedNotes(...pages);
}
