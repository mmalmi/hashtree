import {
  verifiedSymbol,
  verifyEvent as verifyEventWithJs,
  type Event,
} from 'nostr-tools/pure';
import {
  isProfileLoadAbort,
  throwIfProfileLoadAborted,
} from './profileLoadAbort';

let warnedAboutWorker = false;
export const MAX_INDEXED_EVENT_VERIFICATION_BATCH = 256;

function rememberVerification(event: Event, valid: boolean): boolean {
  event[verifiedSymbol] = valid;
  return valid;
}

export function verifyEventFast(event: Event): boolean {
  if (typeof event[verifiedSymbol] === 'boolean') {
    return event[verifiedSymbol];
  }
  return rememberVerification(event, verifyEventWithJs(event));
}

export async function verifyIndexedEvent(
  event: Event,
  signal?: AbortSignal,
): Promise<boolean> {
  throwIfProfileLoadAborted(signal);
  if (typeof event[verifiedSymbol] === 'boolean') {
    return event[verifiedSymbol];
  }
  if (typeof Worker === 'undefined') {
    return typeof window === 'undefined' ? verifyEventFast(event) : false;
  }

  try {
    const client = await (await import('./workerClient')).getWorkerClient();
    throwIfProfileLoadAborted(signal);
    const [valid] = await client.verifyEvents([event], signal);
    return rememberVerification(event, valid === true);
  } catch (error) {
    if (isProfileLoadAbort(error, signal)) {
      throw error;
    }
    if (!warnedAboutWorker) {
      warnedAboutWorker = true;
      console.warn('Background Nostr signature verification is unavailable; dropping the event', error);
    }
    return false;
  }
}

/** Verify an already-decoded index batch in one shared-worker request. */
export async function verifyIndexedEvents(
  events: Event[],
  signal?: AbortSignal,
): Promise<boolean[]> {
  throwIfProfileLoadAborted(signal);
  if (events.length === 0) {
    return [];
  }
  const unresolved = events.filter((event) => typeof event[verifiedSymbol] !== 'boolean');
  if (unresolved.length === 0) {
    return events.map((event) => event[verifiedSymbol] === true);
  }
  if (typeof Worker === 'undefined') {
    return typeof window === 'undefined'
      ? events.map((event) => verifyEventFast(event))
      : events.map(() => false);
  }
  try {
    const client = await (await import('./workerClient')).getWorkerClient();
    throwIfProfileLoadAborted(signal);
    for (
      let offset = 0;
      offset < unresolved.length;
      offset += MAX_INDEXED_EVENT_VERIFICATION_BATCH
    ) {
      const batch = unresolved.slice(
        offset,
        offset + MAX_INDEXED_EVENT_VERIFICATION_BATCH,
      );
      const valid = await client.verifyEvents(batch, signal);
      throwIfProfileLoadAborted(signal);
      if (valid.length !== batch.length) {
        return events.map(() => false);
      }
      for (let index = 0; index < batch.length; index += 1) {
        rememberVerification(batch[index]!, valid[index] === true);
      }
    }
    return events.map((event) => event[verifiedSymbol] === true);
  } catch (error) {
    if (isProfileLoadAbort(error, signal)) {
      throw error;
    }
    if (!warnedAboutWorker) {
      warnedAboutWorker = true;
      console.warn('Background Nostr signature verification is unavailable; dropping the event', error);
    }
    return events.map(() => false);
  }
}
