import type { RawEvent } from './nostr';
import { measureSocialGraphObservationEvent } from '../workers/socialWorkerProtocol';

/** Keep actual list updates separate from the embedded projection while a fresh seed is in flight. */
export function beginPublicDiscoveryUpdate(root: string, signal?: AbortSignal) {
  const cancel = new AbortController();
  const active = signal ? AbortSignal.any([signal, cancel.signal]) : cancel.signal;
  const observed: RawEvent[] = [];
  let codeUnits = 0;
  const ready = import('nostr-social-graph/publicGraphSync')
    .then(({loadGraphBootstrap}) => loadGraphBootstrap({root, signal: active}))
    .catch(() => null);
  return {
    ready, signal: active,
    cancel: () => cancel.abort(),
    observe(event: RawEvent) {
      if (active.aborted) {return;}
      const size = measureSocialGraphObservationEvent(event);
      // A busy session keeps its current graph if we cannot replay every arrival.
      if (size === null || observed.length >= 1024 || codeUnits + size > 2 * 1024 * 1024) {
        observed.length = 0;
        cancel.abort();
        return;
      }
      observed.push(event);
      codeUnits += size;
    },
    replay(apply: (event: RawEvent) => void) {
      active.throwIfAborted();
      for (const event of observed) {apply(event);}
    },
  };
}

export type PublicDiscoveryUpdate = ReturnType<typeof beginPublicDiscoveryUpdate>;

export function publicDiscoveryRelays(selected: readonly string[], defaults: readonly string[]) {
  const normalize = (urls: readonly string[]) => [...new Set(urls.map(url => url.replace(/\/$/, '')))].sort().join(',');
  return normalize(selected) === normalize(defaults);
}
