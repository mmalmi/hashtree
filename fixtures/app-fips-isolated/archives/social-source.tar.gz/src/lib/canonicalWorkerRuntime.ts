export type CanonicalWorkerRuntimeOptions<Client, Transport> = {
  createClient(): Client;
  initializeClient(client: Client): Promise<void>;
  attachP2P(client: Client): Promise<void>;
  createTransport(client: Client): Transport;
  onP2PError?(error: unknown): void;
};

export type CanonicalWorkerRuntime<Client, Transport> = {
  getClient(): Promise<Client>;
  getTransport(client: Client): Transport;
  currentClient(): Client | null;
};

/**
 * Owns the one worker endpoint shared by block, P2P, and extension traffic.
 *
 * Every public client accessor must enter through getClient(). P2P attachment
 * deliberately starts after worker initialization without blocking consumers;
 * it still receives the exact client captured by the shared initialization
 * promise.
 */
export function createCanonicalWorkerRuntime<Client, Transport>(
  options: CanonicalWorkerRuntimeOptions<Client, Transport>,
): CanonicalWorkerRuntime<Client, Transport> {
  let client: Client | null = null;
  let clientPromise: Promise<Client> | null = null;
  let transport: Transport | null = null;

  const getClient = async (): Promise<Client> => {
    if (client) {
      return client;
    }
    if (clientPromise) {
      return await clientPromise;
    }

    const created = options.createClient();
    const pending = (async () => {
      await options.initializeClient(created);
      client = created;
      void options.attachP2P(created).catch((error) => {
        options.onP2PError?.(error);
      });
      return created;
    })();
    clientPromise = pending;
    try {
      return await pending;
    } finally {
      if (clientPromise === pending) {
        clientPromise = null;
      }
    }
  };

  return {
    getClient,
    getTransport(expectedClient) {
      if (!client || expectedClient !== client) {
        throw new Error('Social worker transport must use the canonical worker client');
      }
      transport ??= options.createTransport(expectedClient);
      return transport;
    },
    currentClient() {
      return client;
    },
  };
}
