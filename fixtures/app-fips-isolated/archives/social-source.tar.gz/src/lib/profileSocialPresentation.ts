import { isHexPubkey } from './nostr';

export type FollowedByPresentation = {
  pubkeys: string[];
  total: number;
  followedByViewer: boolean;
};

export function sortProfileFollowers(
  followers: readonly string[],
  viewerFollows: ReadonlySet<string>,
): string[] {
  return [
    ...followers.filter((pubkey) => viewerFollows.has(pubkey)),
    ...followers.filter((pubkey) => !viewerFollows.has(pubkey)),
  ];
}

export function hasCompleteFollowerCoverage(social: {
  followers: readonly string[];
  followersCount: number | null;
  followersTruncated: boolean;
  hasFollowers: boolean;
} | null | undefined): boolean {
  return Boolean(
    social?.hasFollowers
    && social.followersCount !== null
    && !social.followersTruncated
    && social.followers.length >= social.followersCount,
  );
}

export function buildFollowedByPresentation(options: {
  viewerPubkey: string | null;
  targetPubkey: string;
  viewerFollows: ReadonlySet<string>;
  targetFollowers: readonly string[];
  graphFollowedByFriends?: readonly string[];
  totalFollowedByFriends?: number | null;
  limit?: number;
}): FollowedByPresentation {
  const viewerPubkey = options.viewerPubkey?.trim().toLowerCase() ?? null;
  const targetPubkey = options.targetPubkey.trim().toLowerCase();
  const isOwnProfile = viewerPubkey === targetPubkey;
  const limit = Number.isSafeInteger(options.limit)
    ? Math.max(0, Math.min(options.limit ?? 3, 12))
    : 3;
  const pubkeys: string[] = [];
  const seen = new Set<string>();

  const candidates: Array<readonly [string, boolean]> = [
    ...(options.graphFollowedByFriends ?? []).map((pubkey) => [pubkey, true] as const),
    ...options.targetFollowers.map((pubkey) => [pubkey, false] as const),
  ];
  for (const [candidate, graphDerived] of candidates) {
    const pubkey = candidate.trim().toLowerCase();
    if (
      !isHexPubkey(pubkey)
      || seen.has(pubkey)
      || pubkey === viewerPubkey
      || pubkey === targetPubkey
      || (!graphDerived && !options.viewerFollows.has(pubkey))
    ) {
      continue;
    }
    seen.add(pubkey);
    if (pubkeys.length < limit) {
      pubkeys.push(pubkey);
    }
  }

  const suppliedTotal = options.totalFollowedByFriends;
  const total = isOwnProfile
    ? 0
    : Math.max(
        seen.size,
        typeof suppliedTotal === 'number' && Number.isFinite(suppliedTotal)
          ? Math.max(0, Math.trunc(suppliedTotal))
          : seen.size,
      );

  return {
    pubkeys,
    total,
    followedByViewer: !isOwnProfile && options.viewerFollows.has(targetPubkey),
  };
}
