import type { StoredNostrEvent } from '@hashtree/nostr';
import type { HomeFeedContinuation } from './homeFeedPagination';
import type { ProfileRecord, RawEvent } from './nostr';

/**
 * Events returned by durable profile queries. NIP-22 comments are included on
 * profile views without broadening home/global feeds.
 */
export const DURABLE_PROFILE_POST_KINDS = [1, 6, 20, 1111, 30_023] as const;

export type NostrEventIndexReaderOptions = {
  indexedEventReadConcurrency?: number;
  indexedEventVerifier?: (event: StoredNostrEvent) => boolean | Promise<boolean>;
  signal?: AbortSignal;
};

export type NoteThreadSnapshot = {
  rootNhash: string;
  note: RawEvent | null;
  root: RawEvent | null;
  parent: RawEvent | null;
  context: RawEvent[];
};

export type NoteDetailListKind = 'likes' | 'reposts' | 'zaps';

export type FeedSnapshot = {
  rootNhash: string;
  followCount: number;
  follows: string[];
  profiles: Map<string, ProfileRecord>;
  notes: RawEvent[];
  /** Order already presented to the reader during this feed session. */
  displayOrder?: string[];
  feedOwnerPubkey: string;
  usedSuggestedFeed: boolean;
  starterMode: 'social-graph-snapshot' | 'sirius-follows' | 'sirius-posts' | null;
  continuation?: HomeFeedContinuation | null;
};
