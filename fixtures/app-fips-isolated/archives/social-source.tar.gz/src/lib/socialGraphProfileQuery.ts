import type { SocialGraph } from 'nostr-social-graph';

const HEX_PUBKEY = /^[0-9a-f]{64}$/;
const UNKNOWN_FOLLOW_DISTANCE = 1_000;

export type SocialGraphProfileSocial = {
  follows: string[];
  followsCount: number;
  followers: string[];
  followersCount: number;
};

function normalizePubkey(value: string): string | null {
  const normalized = value.trim().toLowerCase();
  return HEX_PUBKEY.test(normalized) ? normalized : null;
}

function hexPubkeysFromSet(pubkeys: Set<string>): string[] {
  return [...pubkeys].filter((pubkey) => HEX_PUBKEY.test(pubkey));
}

/** Pure bounded-at-the-caller projection shared by renderer and worker runtimes. */
export function profileSocialFromGraph(
  graph: SocialGraph,
  pubkey: string,
  followerLimit: number,
): SocialGraphProfileSocial | null {
  const normalizedPubkey = normalizePubkey(pubkey);
  if (!normalizedPubkey) {
    return null;
  }

  const follows = hexPubkeysFromSet(graph.getFollowedByUser(normalizedPubkey));
  const followers = hexPubkeysFromSet(graph.getFollowersByUser(normalizedPubkey));
  const limit = Math.max(Math.trunc(followerLimit), 1);
  const distance = graph.getFollowDistance(normalizedPubkey);
  if (distance >= UNKNOWN_FOLLOW_DISTANCE && follows.length === 0 && followers.length === 0) {
    return null;
  }

  return {
    follows: follows.slice(0, limit),
    followsCount: follows.length,
    followers: followers.slice(0, limit),
    followersCount: followers.length,
  };
}
