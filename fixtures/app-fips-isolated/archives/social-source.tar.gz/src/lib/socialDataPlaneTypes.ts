import type { NostrEvent, NostrFilter, NostrVerifiedEvent } from 'nostr-pubsub';
import type { RawEvent } from './nostr';

export type SocialLiveTransport = {
  subscribe(
    filters: NostrFilter[],
    handler: (event: NostrVerifiedEvent, sourcePeer: string) => void,
  ): { close(): void };
  /**
   * Optional coalesced delivery path. Transports should invoke this at most
   * once per bounded browser task/animation turn.
   */
  subscribeBatch?(
    filters: NostrFilter[],
    handler: (
      events: readonly NostrVerifiedEvent[],
      sourcePeers: readonly string[],
    ) => void,
  ): { close(): void };
  publish(event: NostrEvent | NostrVerifiedEvent): Promise<void>;
  /** True only after a message provider accepted this event, never local gossip. */
  publishWithReceipt?(event: NostrEvent | NostrVerifiedEvent): Promise<boolean>;
};

export type SocialDataPlaneChange = {
  /** First event retained for source compatibility with single-event consumers. */
  event: RawEvent;
  /** All events committed by the same repository projection rebuild. */
  events: readonly RawEvent[];
  origin: 'live' | 'local' | 'relay' | 'restore';
  sourcePeer: string | null;
  sourcePeers: readonly (string | null)[];
  version: number;
};

export class SocialPersistenceError extends Error {
  override readonly cause: unknown;

  constructor(message: string, cause?: unknown) {
    super(message, { cause });
    this.name = 'SocialPersistenceError';
    this.cause = cause;
  }
}

export type SocialDataPlaneOptions = {
  storage?: Storage | null;
  maxOverlayEvents?: number;
  /** Restore the best-effort live overlay after first paint instead of during module evaluation. */
  deferOverlayRestore?: boolean;
  connectLive?: () => Promise<SocialLiveTransport | null>;
  persistDebounceMs?: number;
  observeSocialGraphEvent?: (event: RawEvent) => void;
  reconnectDelaysMs?: readonly number[];
  outboxRetryDelaysMs?: readonly number[];
  personalIndexRetryDelaysMs?: readonly number[];
  publishToRelays?: (event: RawEvent) => Promise<void>;
  publishToPersonalIndex?: (event: RawEvent) => Promise<void>;
  shouldConnectLive?: () => boolean;
  onPersistenceError?: (error: SocialPersistenceError) => void;
  onlineTarget?: EventTarget | null;
  storageEventTarget?: EventTarget | null;
};

export type LiveTextNoteOptions = {
  authors?: readonly string[];
  includeReplies?: boolean;
  kinds?: readonly number[];
  limit: number;
  retainSnapshotEvents?: boolean;
};
