# Iris Social

Iris Social is an offline-first social client for Nostr. It reads durable,
verifiable history from immutable Hashtree indexes, adds live updates through
`nostr-pubsub`, and keeps useful data and pending publishes in the browser.

[Open Iris Social](https://social.iris.to)

## Highlights

- Home, following, media, and personalized feeds
- Profiles, follows, followers, threads, and long-form posts
- Profile and post search across independently published indexes
- Likes, reposts, replies, Cashu-funded NIP-57 zaps, notifications, and media uploads
- A device-local Cashu wallet with Lightning and ecash send/receive flows
- Locally cached reads and an offline publishing outbox
- No required feed or search API

Signed Nostr events remain the source records. Hashtree provides immutable
history and indexes, while the live transport supplies only recent updates.
See [HASHTREE_SOCIAL_ARCHITECTURE.md](./HASHTREE_SOCIAL_ARCHITECTURE.md) for the
data model and trust boundaries.

## Development

The project uses Node.js, pnpm, Svelte 5, TypeScript, and Vite. The lockfile
pins the published Hashtree runtime archives by integrity. Runtime v0.5.27
comes from commit `9eb201a26dd6a0a914f9a480b6a33621ca9e635e`. Its release
`SHA256SUMS` digest is `5f1c177f3cf7f0aebe8ba6eb42a4932242b1ca8fc13cf2f98a8fc67a200c877e`.
Worker 0.4.21 comes from runtime v0.5.34 at `a136e56f2b10ab91cc6cf87cca7acacb2506f1dd`.
Its archive SHA-256 is `38bbe0895ddef0aeae0734a288fe9dbd9b871ad080171eb10a06cf09023d4c22`;
the dependency guard also checks its exact SHA-512 lockfile integrity.

The canonical data worker owns the live social graph. It retains local graph
snapshots and signed follow/mute revisions in IndexedDB. Optional public relay
reads enable bounded NIP-77 catch-up on the configured relays while the page is
active and online. Account, network and page lifecycle changes cancel that work.
Only the shipped default relay configuration may use the public mobile bootstrap
or add the graph relay. Bootstrap is limited to 4 MiB and runs only when no local
graph is retained. Small personal crawls are valid; unsupported saved graphs stay
stored while an in-memory fallback supplies local queries. Verified updates pass
the worker's admission limits before changing the graph or its durable overlay.

From `iris-social`:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

The development server runs at <http://localhost:4179>. Keep `nostr-tools` aligned
with the Hashtree packages; different versions have incompatible verified-event types.

Core archive and profile catalogs have development defaults. To use other data
publishers or enable live peers, create `.env.local` and set any relevant Vite
variables:

```dotenv
VITE_FIPS_PEERS="<compressed-peer-id>"
VITE_NOSTR_EVENT_INDEX="<npub>/nostr-event-index"
VITE_PROFILE_INDEX="<npub>/profiles-by-pubkey"
VITE_PROFILE_SEARCH_INDEX="<npub>/profile-search"
VITE_POST_SEARCH_INDEX="<npub>/<tree>"
VITE_SOCIAL_RELATIONSHIP_INDEX="<npub>/<tree>"
```

Federated search also accepts comma- or space-separated references through
`VITE_PROFILE_SEARCH_INDEXES`, `VITE_PROFILE_SEARCH_V3_INDEXES`, and
`VITE_POST_SEARCH_INDEXES`.

Posts, replies, and reactions are read from the main Nostr event archive.
Verified live events are cached locally for offline use. WebRTC peers receive one background post feed for the account’s signed public follow list, in bounded batches, or the latest public posts when no list is loaded. Signed-in accounts also keep a background feed for public notifications tagged with their own key. Read-only accounts use the latest public posts. Opening a thread, profile or notification filters locally. Two capable peers use Negentropy to catch up on a warm feed and send new posts through INV/WANT. Publishing a signed public post still sends it to subscribed peers. Browsing history stays out of the peer replay store.

## Checks

```sh
pnpm lint       # ESLint
pnpm check      # Svelte and TypeScript checks
pnpm build      # production build
pnpm test:unit  # Node unit/integration tests, four workers
pnpm test:e2e   # browser end-to-end tests (build first)
pnpm test:wallet-integration # real Coco worker against a disposable local mint
pnpm test       # full validation suite
```

The suites are disjoint: register browser specs in `playwright.browser-tests.ts`;
other specs run in the unit suite automatically. Override concurrency with
`pnpm test:unit --workers=1` when measuring serial performance.

## License

Iris Social is available under the [MIT License](./LICENSE).
