# Recent-index producer verification — 15 September 2026

This finite local stage follows client commit
`5d4190424eea1933a9b5511ab0cc19d05f3215f9`. It began at 23:04:48 UTC on
14 September (02:04:48 on 15 September in Helsinki) and completed within the
60-minute limit. No production activation was attempted.

## Existing machinery and implementation boundary

The native broad-archive path already owns historical collection, durable
staging, projection and its completion watermark. Its CLI has author/event caps
and import/query commands, but the repository had no one-shot producer combining
an explicit recent window, a fresh independent index, bounded input and a
verified handoff for the optional client source.

The new command therefore reuses the existing referenced-event relay query
client, standard Hashtree event builder, replaceable-event selection and portable
filesystem store. Only `since` and `until` were added to the shared relay filter
type; its transport behavior was not changed. No new crawler service, transport,
dependency, archive gate or client feature was introduced.

## Focused verification

| Check | Result |
| --- | --- |
| Producer, existing recent-index client, existing relay resolver | 13 tests passed in 1.5 seconds |
| Type/Svelte checks | 0 errors, 0 warnings |
| ESLint | Passed, 0 warnings |
| Actual `pnpm build:recent-index` invocation | Passed in 522 ms on a three-event synthetic file |
| Retained synthetic artifact | 3 indexed events, 12 reachable blocks, 5,884 bytes |

The integration test builds a real index from a mixture of signed events and
reads it through `HashtreeNostrEventReader` into `SocialDataPlane`, the projection
used by Latest. It verifies:

- Recent posts precede a July archive note while the historical checkpoint still
  describes an unfinished 1-of-100-author backfill. The checkpoint bytes and
  historical root remain unchanged.
- Both time boundaries are inclusive; old/future events, other kinds and other
  authors are excluded.
- An author's deletion hides its target, a foreign-author deletion cannot hide
  the recent post, and the newer addressable article replaces its older version.
- Invalid signatures and altered signed payloads fail, even when the supplied
  test object originally had a cached verification symbol.
- Unique-event, raw-candidate, per-event byte and input byte limits fail closed;
  the exact one-event cap also succeeds.
- A loopback relay receives one bounded subscription with 129 authors split
  into 128/1 filters. Missing EOSE hits the deadline, closes the client and
  produces no candidate or automatic retry.
- Existing output directories and duplicate CLI output arguments are rejected;
  historical checkpoint contents are preserved.

The command independently verifies the complete selected event set in memory
and after writing the filesystem CAS. It traverses every reachable block with
missing-block rejection and filesystem hash checking before atomically writing
`candidate.json`. Existing client regression tests also retain their offline
restoration, cancellation and partial-read checks.

The initial test-first run failed because the producer module did not yet exist.
That log documents test introduction; it is not a production failure reproduction.
All relay traffic in this stage used a disposable loopback synthetic relay.
The CLI timing is a local fixture measurement, not a production throughput claim.

## Retained local evidence

Detailed, untracked artifacts live under the product repository's
`tmp/recent-index-producer-20260915/`:

- `focused.log`, `check.log`, `lint.log`, `red.log` and `help.log`.
- `cli-invocation.json` and `cli.log`, containing the exact executed local command.
- `authors.txt` and `input.json`, containing only synthetic public event data.
- `cli-candidate/candidate.json`, `events.json`, `blocks.json` and `blocks/`.

The artifacts are synthetic and must not be used for production publication.
Keep the operator instructions in [recent index operations](../recent-event-index.md)
with this verification record.

## Remaining activation owner

The index/release owner must choose real collection scope, run a fresh candidate,
verify its content, make the entire DAG available through the approved storage
path, publish a separate signed mutable root, configure
`VITE_RECENT_NOSTR_EVENT_INDEX`, and perform the normal release and public/offline
smoke checks. Historical archive publication remains gated on its own completion.
Production freshness is not resolved by this local commit alone. Continued
collection and publication cadence also remains an explicit operational decision.

No live host/service changes, production crawler runs, real-data publication,
uploads, deployment, installs, spending, external contact, tasks, subagents,
goals, schedules or monitoring loops were performed in this stage.
