# Recent posts activation — 2026-09-15

Latest previously depended on the historical index's July publication while its
backfill continued. The independent recent index is now published automatically
and enabled in the app deployed to HTTPS and Hashtree. The archive continues to
advance independently.

## Deployed build

- App revision: `0925149`.
- HTTPS: <https://social.iris.to/>.
- Hashtree site: `npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/social`.
- Immutable site root:
  `nhash1qqsqya7g32466u3zl3r62qhzcu0d36m0etlm5ndfjxed7efq6qrkv9c9yzs0slq4l3msf5qgv3uaaj6zrfv29tfay634vc28upjaecy92wwkc7ztujq`.
- Main script: `assets/index-DhMz2WL8.js`.
- Script SHA-256:
  `e36d2e7711da5cc9b4ae6392be964ecaf9e1d1dcb20cf47f0c128375541a7f50`.
- HTML SHA-256:
  `c2bb4668f3cc1eb33d3da5798edb0c8cb21cf8c704c34611264ef7430a45d06a`.

At 13:01 UTC, the HTTPS script matched the tested build byte for byte. An empty
Hashtree read store retrieved the same HTML from the immutable site root.

Keep the activation setting in subsequent production releases:

```sh
VITE_RECENT_NOSTR_EVENT_INDEX=npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/recent-posts
```

The client retries an error or an empty incomplete initial read twice, with
bounded delays. Root changes, author changes and shutdown cancel stale work.
Verified events remain in the existing local overlay and offline cache.

## Production observations

Fresh isolated Chromium contexts, measured on this development machine at
13:02 UTC; these are individual observations, not percentile benchmarks:

| Check | Result |
| --- | --- |
| First default-feed post | 3,179 ms |
| First post dated September 15 | 3,186 ms |
| First contentful paint | 188 ms |
| Fully offline reload | All eight observed feed IDs restored |
| Read-only viewer feed | A post from the past hour visible within 9,049 ms |
| Thread, profile, notifications navigation | Passed |
| Browser page errors | None |

The automatic refresh was enabled and completed multiple successful runs. The
13:01 UTC publication contained 772 verified events, with a newest event at
12:59:09 UTC. All 1,024 blocks were checked through the public read server and
retained before announcement; both configured relays acknowledged publication.
The next run starts five minutes after completion. Failed runs preserve the last
published root, and retention keeps the current and preceding successful runs.

Collection covers a rolling 24-hour bounded sample of 407 public discovery
authors. It is not a completeness claim for all Nostr authors or history. Both
historical crawler services were active with no restarts, and successive
projection checkpoints advanced during verification.

## Release checks

- Build, type checks and lint passed.
- 914 unit tests passed in 14.1 seconds.
- All 51 initial-paint and browser smoke checks passed in 2.2 minutes.
- Three peer/publication integration checks passed in 16.8 seconds.
- The transient-read regression failed before the retry change and passed
  afterward using the real Hashtree reader.

The first full browser attempt timed out in the existing scroll-stability check.
Its focused trace run passed, followed by a passing full browser run against the
unchanged build. No assertions or timeouts were relaxed. Successful build, type,
unit and peer checks were reused for the identical artifact during release.
