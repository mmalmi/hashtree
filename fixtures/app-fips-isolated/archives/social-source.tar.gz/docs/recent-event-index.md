# Recent event index (retired)

The separate recent-post index and its publisher were removed. Posts, replies,
reactions, and historical pagination use the main Nostr event archive. Verified
live events and existing cached events remain available through the local overlay.

The former publisher timer is disabled. Existing index data and publication
receipts are preserved; historical verification records describe the retired path.
