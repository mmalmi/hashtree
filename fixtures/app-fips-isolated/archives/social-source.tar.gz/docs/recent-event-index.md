# Recent event index (retired)

The separate recent-post index and its publisher were removed. Posts, replies,
reactions, and historical pagination use the main Nostr event archive. Verified
live events and existing cached events remain available through the local overlay.

The former publisher timer is disabled. Existing index data and publication
receipts are preserved; historical verification records describe the retired path.

## Main archive forward intake

Build the distance file with `census-social-graph --write-forward-authors` using
the pinned archive graph snapshot and root. Set the collector config's `graph`
object to an absolute `authorsFile` and its `sha256`. Graph intake rotates through
eligible authors, with a distinct query for kind 1 over the previous 24 hours.
Private payloads, ephemeral events, and expired arrivals are excluded.

Daily admission budgets are 64 events and 256 KiB for the root and direct
follows, 32 events and 128 KiB at distance two, 16 events and 64 KiB at distance
three, and 8 events and 32 KiB farther away. Half of each graph author's budget
is reserved for text notes. Outside-graph Market and Video discovery keeps
its existing kinds and an independent per-author budget. Reviews, other Market
events, videos, and text notes have separate queue capacity and export turns.

At a published checkpoint with no pending write, graph intake gets one forward
batch before historical work. The existing transaction, receipt, and publication
checks still apply. Complete pending legacy work before changing the pinned
collector, native writer, launcher, and publisher together. Use `migrate` with
the new inbox path and the legacy inbox after reaching the existing clean
writer boundary. The copied inbox retains seen IDs, eligible queued events,
deletion targets, and relay progress. Keep the original inbox and receipts
for recovery. Pin the graph digest in both the launcher and publisher authorities.

The retention policy reserves intake capacity for profiles, follow lists, and
public mute lists from graph authors. A dedicated relay pass checks their
latest signed version regardless of age. Updates to other replaceable or
addressable events qualify when the inbox or signed Hashtree archive contains
the same coordinate. They use no new-event count, and only positive size
growth is charged against the daily byte budget for new events. Event and
queue size bounds continue to apply.

The collector collapses updates by author, kind and address before export
while leaving an already exported batch intact until acknowledgement. Enable
this policy with the matching native writer, publisher, and the collector's
`retention` object. It binds the signed publication file, publisher, tree
name, and Hashtree block endpoint used for lookup. Migrate into a separate
inbox from either previous policy at a clean, signed checkpoint.

A signed newer encrypted mute list withdraws any earlier public version from
the published index. Keep the signed proof in the private writer inbox and
recovery files. The public tree omits encrypted material, and the historical
writer respects the private minimum version when it encounters older lists.

Use `scripts/prepare-forward-graph-cutover.py` to generate a local review packet
from the serving controls and the qualified release artifacts. The snapshot
contains `authority.json`, `launcher.json`, `publisher.json`, `legacy-config.json`,
`collector.service`, `current.json`, and `locations.json` with their installation
paths. Include the collector's qualified `tested-config.json` and
`tested-authority.json` with that snapshot.

```sh
python3 scripts/prepare-forward-graph-cutover.py "$snapshot" "$qualification" "$review" \
  --version-dir "$version_dir" --inbox-dir "$inbox_dir" --serving-sha256 "$writer_sha256"
```

Verify the preceding signed checkpoint and file digests in `plan.json` at the
clean writer boundary before installing the reviewed controls. Regenerate the
packet from a fresh snapshot if either has advanced.
