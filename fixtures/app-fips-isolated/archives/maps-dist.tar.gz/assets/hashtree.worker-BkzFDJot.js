function r(e){return new Worker(""+new URL("hashtree.worker-CF2mb7bB.js",import.meta.url).href,{type:"module",name:e==null?void 0:e.name})}export{r as default};
