# Iris Docs

Collaborative documents on Nostr and hashtree.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-docs>
Live: <https://docs.iris.to/>

## Development

```bash
pnpm install
pnpm run dev
```

## Verification

```bash
pnpm run test:unit
pnpm run test:docs:iris
node ./scripts/release-site.mjs docs --dry-run
```

## Release

```bash
pnpm run release:docs:iris
```

The release script builds once, tests the built output, publishes the built directory root to hashtree, and deploys the same directory to the `iris-docs` Cloudflare Worker target by default.
