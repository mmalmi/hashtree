# Iris Docs (deprecated)

**Iris Docs is no longer developed. Documents now live in Iris Drive: <https://drive.iris.to/>.**

In Drive a document sits next to your other files: create one with New Document, edit it from any of your devices, and write together in a shared folder. The editor source is in the `iris-drive-web` repository.

Documents made with Iris Docs are not carried over.

<https://docs.iris.to/> sends visitors to Drive. The page it serves is in `moved/`, and it is deployed with:

```bash
node ./scripts/deploy-worker-assets.mjs --script scripts/moved-worker.mjs --assets moved --name iris-docs --compatibility-date 2026-03-19 --wrangler-version 4.78.0 --route "docs.iris.to/*"
```

## The old app

The source is kept for reference. `pnpm run release:docs:iris` would put the old app back on docs.iris.to.

```bash
pnpm install
pnpm run dev
pnpm run test:unit
```
