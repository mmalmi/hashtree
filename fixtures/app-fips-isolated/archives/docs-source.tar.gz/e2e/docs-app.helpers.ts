import { expect } from './fixtures';
import { setupPageErrorHandler, disableOthersPool, configureBlossomServers, waitForAppReady, ensureLoggedIn, safeReload, flushPendingPublishes, evaluateWithRetry } from './test-utils';

export async function getOwnedTreeRootSnapshot(page: any, treeName: string) {
  const snapshot = await page.evaluate(async (targetTreeName) => {
    const { getTreeRootSync } = await import('/src/stores');
    const nostrStore = (window as any).__nostrStore;
    const npub = nostrStore?.getState?.()?.npub;
    if (!npub) return null;

    const rootCid = getTreeRootSync(npub, targetTreeName);
    if (!rootCid?.hash) return null;

    const registry = (window as any).__treeRootRegistry;
    const entry = registry?.get?.(npub, targetTreeName);

    const toHex = (bytes: Uint8Array) => Array.from(bytes)
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');

    return {
      npub,
      treeName: targetTreeName,
      visibility: entry?.visibility || 'public',
      hashHex: toHex(rootCid.hash),
      keyHex: rootCid.key ? toHex(rootCid.key) : null,
    };
  }, treeName);

  if (!snapshot) {
    throw new Error(`Could not resolve tree root snapshot for ${treeName}`);
  }

  return snapshot as {
    npub: string;
    treeName: string;
    visibility: string;
    hashHex: string;
    keyHex: string | null;
  };
}

export async function primeViewerTreeRoot(
  page: any,
  snapshot: {
    npub: string;
    treeName: string;
    visibility: string;
    hashHex: string;
    keyHex: string | null;
  },
  targetTreeName?: string
) {
  await page.evaluate(async ({ npub, treeName, visibility, hashHex, keyHex, overrideTreeName }) => {
    const { updateLocalRootCacheHex } = await import('/src/treeRootCache');
    const fromHex = (hex: string): Uint8Array => {
      const normalized = hex.trim().toLowerCase();
      if (!normalized || normalized.length % 2 !== 0) return new Uint8Array();
      const out = new Uint8Array(normalized.length / 2);
      for (let i = 0; i < out.length; i += 1) {
        const byte = Number.parseInt(normalized.slice(i * 2, i * 2 + 2), 16);
        if (Number.isNaN(byte)) return new Uint8Array();
        out[i] = byte;
      }
      return out;
    };

    const route = (window as any).__routeStore?.getState?.();
    const resolvedTreeName = overrideTreeName || route?.treeName || treeName;
    if (!resolvedTreeName) return;

    updateLocalRootCacheHex(npub, resolvedTreeName, hashHex, keyHex ?? undefined, visibility as any);

    const adapter = (window as any).__getWorkerAdapter?.() ?? (window as any).__workerAdapter;
    if (adapter?.setTreeRootCache) {
      await adapter.setTreeRootCache(
        npub,
        resolvedTreeName,
        fromHex(hashHex),
        keyHex ? fromHex(keyHex) : undefined,
        visibility,
      );
    }
  }, {
    ...snapshot,
    overrideTreeName: targetTreeName ?? null,
  });
}

export async function waitForTreeRootChange(page: any, previousRoot: string | null, timeoutMs: number = 30000) {
  await page.waitForFunction(
    () => typeof (window as any).__getTreeRoot === 'function',
    undefined,
    { timeout: 10000 }
  );
  await page.waitForFunction(
    (prev) => {
      const current = (window as any).__getTreeRoot?.();
      return !!current && current !== prev;
    },
    previousRoot,
    { timeout: timeoutMs }
  );
}

export async function waitForYjsEntry(page: any, timeoutMs: number = 60000) {
  await expect.poll(async () => {
    return evaluateWithRetry(page, async () => {
      const { getTreeRootSync } = await import('/src/stores');
      const { getTree } = await import('/src/store');
      const { getRouteSync } = await import('/src/stores/route');
      const route = getRouteSync();
      if (!route.npub || !route.treeName) return false;
      const rootCid = getTreeRootSync(route.npub, route.treeName);
      if (!rootCid) return false;
      const tree = getTree();
      const entry = await tree.resolvePath(rootCid, route.path);
      if (!entry?.cid) return false;
      const entries = await tree.listDirectory(entry.cid);
      return entries?.some((item: { name: string }) => item.name === '.yjs') ?? false;
    }, null);
  }, { timeout: timeoutMs, intervals: [1000, 2000, 3000] }).toBe(true);
}

export async function waitForDocsEditor(page: any, timeoutMs: number = 60000) {
  await ensureLoggedIn(page, Math.min(30000, timeoutMs)).catch(() => {});
  await waitForYjsEntry(page, timeoutMs).catch(() => {});
  const editor = page.locator('.ProseMirror');
  const start = Date.now();
  let reloaded = false;
  while (Date.now() - start < timeoutMs) {
    await page.evaluate(() => {
      (window as any).__reloadYjsEditors?.();
    });
    if (await editor.isVisible().catch(() => false)) {
      return;
    }
    if (!reloaded && Date.now() - start > timeoutMs / 2) {
      await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: Math.min(60000, timeoutMs) }).catch(() => {});
      await waitForAppReady(page, Math.min(60000, timeoutMs)).catch(() => {});
      await waitForYjsEntry(page, Math.min(60000, timeoutMs)).catch(() => {});
      reloaded = true;
    }
    await page.waitForTimeout(2000);
  }
  await expect(editor).toBeVisible({ timeout: 1000 });
}

export async function waitForEditorContent(
  page: any,
  expectedTexts: string[],
  timeoutMs: number = 90000
) {
  const editor = page.locator('.ProseMirror');
  const start = Date.now();
  let recovered = false;

  while (Date.now() - start < timeoutMs) {
    await page.evaluate(() => {
      (window as any).__reloadYjsEditors?.();
    }).catch(() => {});

    const text = await editor.textContent().catch(() => null);
    const normalized = text ?? '';
    if (expectedTexts.every(expected => normalized.includes(expected))) {
      return;
    }

    if (!recovered && Date.now() - start > timeoutMs / 2) {
      await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: Math.min(60000, timeoutMs) }).catch(() => {});
      await waitForAppReady(page, Math.min(60000, timeoutMs)).catch(() => {});
      await ensureLoggedIn(page, Math.min(30000, timeoutMs)).catch(() => {});
      await disableOthersPool(page).catch(() => {});
      await waitForYjsEntry(page, Math.min(60000, timeoutMs)).catch(() => {});
      await waitForDocsEditor(page, Math.min(60000, timeoutMs)).catch(() => {});
      recovered = true;
    }

    await page.waitForTimeout(2000);
  }

  const finalText = (await editor.textContent().catch(() => null)) ?? '';
  for (const expected of expectedTexts) {
    expect(finalText).toContain(expected);
  }
}

export async function waitForPersistedDocContent(
  page: any,
  treeName: string,
  expectedTexts: string[],
  timeoutMs: number = 90000
) {
  await expect.poll(async () => {
    const text = await evaluateWithRetry(page, async (targetTreeName) => {
      const { getTree } = await import('/src/store');
      const { getTreeRootSync } = await import('/src/stores');
      const { loadDocumentTextFromEntries } = await import('/src/lib/yjs');
      const nostrStore = (window as any).__nostrStore;
      const npub = nostrStore?.getState?.()?.npub;
      if (!npub) return '';

      const rootCid = getTreeRootSync(npub, targetTreeName as string);
      if (!rootCid) return '';

      const tree = getTree();
      const entries = await tree.listDirectory(rootCid);
      return loadDocumentTextFromEntries(entries);
    }, treeName);
    return expectedTexts.every(expected => text.includes(expected));
  }, { timeout: timeoutMs, intervals: [1000, 2000, 3000] }).toBe(true);
}
