import { getPublicKey, nip19 } from 'nostr-tools';
import WebSocket from 'ws';
import { startLocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { expect, test } from './fixtures';
import {
  ensureLoggedIn,
  evaluateWithRetry,
  waitForAppReady,
  waitForWorkerAdapter,
} from './test-utils';

type NostrEvent = {
  kind: number;
  pubkey: string;
  tags: string[][];
};

const FIRST_NOSTR_SECRET = new Uint8Array(32).fill(0x51);
const SECOND_NOSTR_SECRET = new Uint8Array(32).fill(0x52);
const SWITCHED_NOSTR_SECRET = new Uint8Array(32).fill(0x53);

async function fipsLinkState(page: import('@playwright/test').Page): Promise<{
  localPeerId: string;
  connectedPeerIds: string[];
}> {
  return page.evaluate(async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const stats = getDriveFipsRuntime()?.getStats();
    return {
      localPeerId: stats?.localPeerId ?? '',
      connectedPeerIds: stats?.connectedPeerIds ?? [],
    };
  });
}

async function installNostrLogin(page: import('@playwright/test').Page, secret: Uint8Array): Promise<void> {
  const nsec = nip19.nsecEncode(secret);
  await page.addInitScript((value) => {
    localStorage.setItem('hashtree:loginType', 'nsec');
    localStorage.setItem('hashtree:nsec', value);
  }, nsec);
}

async function activateNostrLogin(
  page: import('@playwright/test').Page,
  secret: Uint8Array,
): Promise<void> {
  await evaluateWithRetry(page, async (nsec) => {
    const { loginWithNsec } = await import('/src/nostr/auth.ts');
    if (!await loginWithNsec(nsec)) throw new Error('Nostr login failed');
  }, nip19.nsecEncode(secret), 5);
}

async function observeRelay(relayUrl: string, events: NostrEvent[]): Promise<WebSocket> {
  const socket = new WebSocket(relayUrl);
  await new Promise<void>((resolve, reject) => {
    socket.once('open', resolve);
    socket.once('error', reject);
  });
  socket.on('message', (raw) => {
    const message = JSON.parse(raw.toString()) as unknown[];
    if (message[0] === 'EVENT') events.push(message[2] as NostrEvent);
  });
  socket.send(JSON.stringify(['REQ', 'fips-observer', {}]));
  return socket;
}

test('Docs keeps its FIPS identity and exchanges blocks without legacy public signaling', async ({
  browser,
  page,
  relayUrl,
}) => {
  test.slow();
  const isolatedRelayUrl = `${relayUrl}/fips-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  await page.addInitScript((url) => {
    (window as typeof window & { __testRelayUrl?: string }).__testRelayUrl = url;
  }, isolatedRelayUrl);
  const seed = await startLocalFipsWebSocketSeed();
  await page.addInitScript((seedUrl) => {
    (window as Window & { __testFipsWebsocketSeedUrls?: string[] }).__testFipsWebsocketSeedUrls = [seedUrl];
  }, seed.url);
  const publishedEvents: NostrEvent[] = [];
  const observer = await observeRelay(isolatedRelayUrl, publishedEvents);

  try {
    await installNostrLogin(page, FIRST_NOSTR_SECRET);
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await ensureLoggedIn(page, 30_000);
    await activateNostrLogin(page, FIRST_NOSTR_SECRET);
    await waitForWorkerAdapter(page);

    const secondContext = await browser.newContext();
    await secondContext.addInitScript((seedUrl) => {
      (window as Window & { __testFipsWebsocketSeedUrls?: string[] }).__testFipsWebsocketSeedUrls = [seedUrl];
    }, seed.url);
    try {
      await secondContext.addInitScript((url) => {
        (window as typeof window & { __testRelayUrl?: string }).__testRelayUrl = url;
      }, isolatedRelayUrl);
      const secondNsec = nip19.nsecEncode(SECOND_NOSTR_SECRET);
      await secondContext.addInitScript((value) => {
        localStorage.setItem('hashtree:loginType', 'nsec');
        localStorage.setItem('hashtree:nsec', value);
      }, secondNsec);
      const secondPage = await secondContext.newPage();
      await secondPage.goto('/docs.html#/');
      await waitForAppReady(secondPage);
      await ensureLoggedIn(secondPage, 30_000);
      await activateNostrLogin(secondPage, SECOND_NOSTR_SECRET);
      await waitForWorkerAdapter(secondPage);

      await expect.poll(async () => Promise.all(
        [page, secondPage].map(async (candidate) => (await fipsLinkState(candidate)).localPeerId),
      ), { timeout: 60_000 }).toEqual([
        expect.stringMatching(/^(02|03)[0-9a-f]{64}$/),
        expect.stringMatching(/^(02|03)[0-9a-f]{64}$/),
      ]);
      const [firstFipsPeerId, secondFipsPeerId] = await Promise.all(
        [page, secondPage].map(async (candidate) => (await fipsLinkState(candidate)).localPeerId),
      );
      await expect.poll(async () => Promise.all(
        [
          [page, secondFipsPeerId],
          [secondPage, firstFipsPeerId],
        ].map(async ([candidate, peerId]) => (
          await fipsLinkState(candidate as import('@playwright/test').Page)
        ).connectedPeerIds.includes(peerId as string)),
      ), { timeout: 60_000 }).toEqual([true, true]);

      await expect.poll(() => publishedEvents.some((event) => event.kind === 37_195), {
        timeout: 30_000,
      }).toBe(true);
      const advert = publishedEvents.find((event) => event.kind === 37_195);
      expect(advert?.tags).toContainEqual(['d', 'fips-overlay-v1']);
      expect(advert?.tags).toContainEqual(['protocol', 'fips-overlay-v1']);
      expect(publishedEvents.some((event) => event.kind === 21_059)).toBe(false);
      expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

      const initialIdentity = await page.evaluate(async () => {
        const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
        return {
          fipsPeerId: getDriveFipsRuntime()?.getStats().localPeerId ?? '',
          nostrPubkey: (window as typeof window & {
            __nostrStore?: { getState(): { pubkey?: string } };
          }).__nostrStore?.getState().pubkey ?? '',
        };
      });
      expect(initialIdentity.fipsPeerId).toMatch(/^(02|03)[0-9a-f]{64}$/);
      expect(initialIdentity.nostrPubkey).toBe(getPublicKey(FIRST_NOSTR_SECRET));
      expect(initialIdentity.fipsPeerId.slice(2)).not.toBe(initialIdentity.nostrPubkey);

      await activateNostrLogin(page, SWITCHED_NOSTR_SECRET);
      await page.reload();
      await waitForAppReady(page);
      await ensureLoggedIn(page, 30_000);
      await waitForWorkerAdapter(page);
      await expect.poll(() => evaluateWithRetry(page, async () => {
        const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
        return {
          fipsPeerId: getDriveFipsRuntime()?.getStats().localPeerId ?? '',
          nostrPubkey: (window as typeof window & {
            __nostrStore?: { getState(): { pubkey?: string } };
          }).__nostrStore?.getState().pubkey ?? '',
        };
      }, undefined, 5), { timeout: 30_000 }).toEqual({
        fipsPeerId: initialIdentity.fipsPeerId,
        nostrPubkey: getPublicKey(SWITCHED_NOSTR_SECRET),
      });
      await expect.poll(async () => Promise.all(
        [
          [page, secondFipsPeerId],
          [secondPage, firstFipsPeerId],
        ].map(async ([candidate, peerId]) => (
          await fipsLinkState(candidate as import('@playwright/test').Page)
        ).connectedPeerIds.includes(peerId as string)),
      ), { timeout: 60_000 }).toEqual([true, true]);

      const source = await page.evaluate(async () => {
        const adapter = (window as typeof window & {
          __getWorkerAdapter?: () => {
            put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
            webrtcProxy?: unknown;
          } | null;
        }).__getWorkerAdapter?.();
        if (!adapter) throw new Error('worker adapter is not ready');
        const text = `docs-fips-block-${crypto.randomUUID()}`;
        const data = new TextEncoder().encode(text);
        const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
        if (!await adapter.put(hash, data)) throw new Error('failed to store source block');
        return {
          hashHex: Array.from(hash, (byte) => byte.toString(16).padStart(2, '0')).join(''),
          text,
          legacyProxyActive: adapter.webrtcProxy != null,
        };
      });
      expect(source.legacyProxyActive).toBe(false);

      await expect.poll(() => evaluateWithRetry(secondPage, async ({ hashHex, peerId }) => {
        const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
        const runtime = getDriveFipsRuntime();
        if (!runtime) throw new Error('FIPS provider bridge is not ready');
        const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
        return data ? new TextDecoder().decode(data) : null;
      }, { hashHex: source.hashHex, peerId: firstFipsPeerId }, 5), {
        timeout: 30_000,
      }).toBe(source.text);
      expect(publishedEvents.some((event) => event.kind === 21_059)).toBe(false);
      expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);
    } finally {
      await secondContext.close();
    }
  } finally {
    observer.close();
    await seed.close();
  }
});
