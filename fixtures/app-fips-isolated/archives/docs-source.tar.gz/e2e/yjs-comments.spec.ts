/**
 * E2E tests for Yjs document comments feature
 *
 * Tests Google Docs-style commenting on collaborative documents.
 */
import { test, expect } from './fixtures';
import { setupPageErrorHandler } from './test-utils.js';
import { createDocumentFromDocsHome, setupFreshDocsHome } from './docs-test-utils.js';

test.describe('Yjs Document Comments', () => {
  test.setTimeout(120000);

  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
    await setupFreshDocsHome(page);
  });

  test('comment button is disabled when no text selected', async ({ page }) => {
    await createDocumentFromDocsHome(page, 'comment-test');

    // Wait for editor to be visible
    const editor = page.locator('.ProseMirror');
    await expect(editor).toBeVisible({ timeout: 30000 });

    // Comment button should be disabled (no selection)
    const addCommentBtn = page.locator('button[title="Add comment (select text first)"]');
    await expect(addCommentBtn).toBeVisible({ timeout: 10000 });
    await expect(addCommentBtn).toBeDisabled();
  });

  test('comment button is enabled when text is selected', async ({ page }) => {
    await createDocumentFromDocsHome(page, 'comment-test-2');

    // Wait for editor to be visible and type some text
    const editor = page.locator('.ProseMirror');
    await expect(editor).toBeVisible({ timeout: 30000 });
    await editor.click();
    await page.keyboard.type('This is some text to comment on.');
    await page.waitForTimeout(500);

    // Select some text
    const selectAllShortcut = process.platform === 'darwin' ? 'Meta+a' : 'Control+a';
    await page.keyboard.press(selectAllShortcut);
    await page.waitForTimeout(200);

    // Comment button should now be enabled
    const addCommentBtn = page.locator('button[title="Add comment (select text first)"]');
    await expect(addCommentBtn).toBeEnabled({ timeout: 5000 });
  });

  test('comments panel toggles visibility', async ({ page }) => {
    await createDocumentFromDocsHome(page, 'panel-test');

    // Wait for editor
    const editor = page.locator('.ProseMirror');
    await expect(editor).toBeVisible({ timeout: 30000 });

    // Comments panel should be hidden initially
    const commentsPanel = page.locator('h3:has-text("Comments")');
    await expect(commentsPanel).not.toBeVisible();

    // Click toggle button to show panel
    const toggleBtn = page.locator('button[title="Toggle comments panel"]');
    await toggleBtn.click();
    await page.waitForTimeout(300);

    // Panel should now be visible
    await expect(commentsPanel).toBeVisible({ timeout: 5000 });

    // Panel should show "No comments yet" message
    await expect(page.locator('text=No comments yet')).toBeVisible();

    // Click toggle again to hide
    await toggleBtn.click();
    await page.waitForTimeout(300);
    await expect(commentsPanel).not.toBeVisible();
  });

  test('toolbar shows comment buttons', async ({ page }) => {
    await createDocumentFromDocsHome(page, 'toolbar-test');

    // Wait for editor
    const editor = page.locator('.ProseMirror');
    await expect(editor).toBeVisible({ timeout: 30000 });

    // Should have add comment button
    const addCommentBtn = page.locator('button[title="Add comment (select text first)"]');
    await expect(addCommentBtn).toBeVisible({ timeout: 10000 });

    // Should have toggle panel button
    const toggleBtn = page.locator('button[title="Toggle comments panel"]');
    await expect(toggleBtn).toBeVisible({ timeout: 5000 });
  });
});
