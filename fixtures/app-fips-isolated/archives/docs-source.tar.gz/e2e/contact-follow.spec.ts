import { test, expect } from './fixtures';
import { nip19 } from 'nostr-tools';
import { setupFreshDocsHome } from './docs-test-utils';
import { waitForAppReady, waitForRelayConnected } from './test-utils';

const existing = '11'.repeat(32);
const contact = '22'.repeat(32);
const tags = [['p', existing, 'wss://hint.invalid', 'Saved name'], ['client', 'iris-test']];
const content = '{"keep":"contact metadata"}';

test('public follow and unfollow preserve relay contact metadata through the real worker', async ({ page }) => {
  await page.goto('/docs.html#/');
  await waitForAppReady(page);
  await waitForRelayConnected(page);
  // Startup restores or creates the account after the service worker takes control.
  await page.waitForFunction(() => {
    const state = (window as any).__nostrStore?.getState();
    return state?.isLoggedIn && state.pubkey?.length === 64 && !!(window as any).__nostr?.signer;
  }, undefined, { timeout: 30_000 });
  try {
    await page.evaluate(async ({ tags, content }) => {
      const win = window as typeof window & {
        __nostr?: { signer?: unknown };
        __nostrStore?: { getState(): { pubkey?: string; isLoggedIn?: boolean } };
        __contactClientObservation?: unknown;
      };
      const beforeClient = win.__nostr;
      const beforeStore = win.__nostrStore;
      const beforeState = beforeStore?.getState();
      const beforeSignerPresent = Boolean(beforeClient?.signer);
      const { nostr } = await import('/src/nostr/client.ts');
      const { nostrStore } = await import('/src/nostr/store.ts');
      const state = nostrStore.getState();
      // Only ownership and readiness facts: no key, signed event or signer data.
      win.__contactClientObservation = {
        beforeSignerPresent,
        importedSignerPresent: Boolean(nostr.signer),
        globalSignerPresent: Boolean(win.__nostr?.signer),
        importedClientWasGlobal: nostr === beforeClient,
        importedClientIsGlobal: nostr === win.__nostr,
        importedStoreWasGlobal: nostrStore === beforeStore,
        importedStoreIsGlobal: nostrStore === win.__nostrStore,
        hadPubkey: beforeState?.pubkey?.length === 64,
        hasPubkey: state.pubkey?.length === 64,
        samePubkey: beforeState?.pubkey === state.pubkey,
        isLoggedIn: state.isLoggedIn,
        moduleRequests: performance.getEntriesByType('resource')
          .map(entry => new URL(entry.name))
          .filter(url => ['/src/nostr/client.ts', '/src/nostr/store.ts'].includes(url.pathname))
          .slice(-8).map(url => url.pathname + url.search),
      };
      await nostr.publishEvent({ kind: 3, tags, content, created_at: Math.floor(Date.now() / 1000) });
    }, { tags, content });
  } finally {
    const observation = await page.evaluate(() => {
      const win = window as typeof window & { __contactClientObservation?: unknown };
      const value = win.__contactClientObservation;
      delete win.__contactClientObservation;
      return value;
    }).catch(() => null);
    if (observation) await test.info().attach('client-ownership.json', {
      body: JSON.stringify(observation, null, 2), contentType: 'application/json',
    });
  }

  const latest = () => page.evaluate(async () => {
    const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
    const { getNostrRelayUrls } = await import('/src/nostr/client.ts');
    const { nostrStore } = await import('/src/nostr/index.ts');
    const adapter = getWorkerAdapter();
    const pubkey = nostrStore.getState().pubkey;
    if (!adapter?.queryEvents || !pubkey) throw new Error('Signed-in worker not ready');
    const result = await adapter.queryEvents([{ kinds: [3], authors: [pubkey] }], {
      cache: 'network-only', relays: getNostrRelayUrls(), deadline: Date.now() + 10_000,
    });
    const head = result.events.sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id))[0];
    return { complete: result.complete, tags: head?.tags, content: head?.content };
  });
  await expect.poll(latest).toEqual({ complete: true, tags, content });
  expect(await page.evaluate(async contact => {
    const { followPubkey } = await import('/src/stores/follows.ts');
    return followPubkey(contact);
  }, contact)).toBe(true);
  await expect.poll(latest).toEqual({ complete: true, tags: [...tags, ['p', contact]], content });
  const ownNpub = await page.evaluate(async () => {
    const { nostrStore } = await import('/src/nostr/index.ts');
    return nostrStore.getState().npub;
  });
  await page.evaluate(npub => { window.location.hash = `/${npub}/follows`; }, ownNpub);
  const badge = page.locator('[data-testid="social-distance-badge"][title="Following"]').first();
  await expect(badge).toBeVisible();
  await expect(badge).toHaveCSS('background-color', 'rgb(10, 132, 255)');
  const geometry = await badge.evaluate(element => {
    const check = element.getBoundingClientRect();
    if (!element.parentElement) throw new Error('Avatar wrapper missing');
    const avatar = element.parentElement.getBoundingClientRect();
    return { checkX: check.x + check.width / 2, checkY: check.y + check.height / 2,
      avatarX: avatar.x + avatar.width / 2, avatarY: avatar.y + avatar.height / 2 };
  });
  expect(geometry.checkX).toBeGreaterThan(geometry.avatarX);
  expect(geometry.checkY).toBeLessThan(geometry.avatarY);
  await page.evaluate(npub => { window.location.hash = `/${npub}/profile`; }, nip19.npubEncode(contact));
  const profileAvatar = page.locator('[data-testid="profile-avatar"]:visible');
  const profileHeader = profileAvatar.locator('..');
  const explanation = profileHeader.getByTestId('profile-follow-explanation');
  await expect(explanation).toContainText(/You follow them|Followed by/);
  await expect(explanation.getByTestId('social-distance-badge')).toHaveCount(1);
  await expect(profileAvatar).toBeVisible();
  await expect(profileAvatar.getByTestId('social-distance-badge')).toHaveCount(0);
  await expect(profileHeader.locator('h1').getByTestId('social-distance-badge')).toHaveCount(0);
  await expect(profileHeader.getByTestId('social-distance-badge')).toHaveCount(1);
  await page.screenshot({path:test.info().outputPath('profile-social-badge.png')});
  expect(await page.evaluate(async contact => {
    const { unfollowPubkey } = await import('/src/stores/follows.ts');
    return unfollowPubkey(contact);
  }, contact)).toBe(true);
  await expect.poll(latest).toEqual({ complete: true, tags, content });
});

test('client module re-evaluation preserves the authenticated client and store', async ({ page }) => {
  await setupFreshDocsHome(page);
  const result = await page.evaluate(async () => {
    const { nostr } = await import('/src/nostr/client.ts');
    const { nostrStore } = await import('/src/nostr/store.ts');
    const draft = { kind: 1, content: 'client ownership control', tags: [], created_at: 1 };
    const before = await nostr.signEvent(draft); // Real signer must work before the control.
    const state = nostrStore.getState();
    // A distinct Vite module URL re-evaluates the actual client module, as HMR can.
    // This proves the lifecycle invariant, not the cause of a historical failure.
    const reloaded = await import('/src/nostr/client.ts?docs-client-ownership-control');
    const win = window as typeof window & { __nostr?: unknown; __nostrStore?: unknown };
    let signedAfter = false;
    if (reloaded.nostr.signer) {
      const after = await reloaded.nostr.signEvent(draft);
      signedAfter = after.pubkey === before.pubkey;
    }
    return {
      sameClient: reloaded.nostr === nostr,
      globalClientUnchanged: win.__nostr === nostr,
      sameStore: win.__nostrStore === nostrStore,
      samePubkey: nostrStore.getState().pubkey === state.pubkey,
      signedAfter,
    };
  });
  expect(result, 'Re-evaluating the client must preserve the authenticated singleton').toEqual({
    sameClient: true, globalClientUnchanged: true, sameStore: true, samePubkey: true, signedAfter: true,
  });
});
