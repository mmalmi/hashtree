import { test, expect } from './fixtures';
import { setupPageErrorHandler, disableOthersPool, configureBlossomServers, waitForAppReady, ensureLoggedIn, safeReload, flushPendingPublishes, waitForRelayConnected } from './test-utils';
import {
  getOwnedTreeRootSnapshot,
  installDocCommitDiagnostics,
  primeViewerTreeRoot,
  waitForDocsEditor,
  waitForEditorContent,
  waitForPersistedDocContent,
  waitForTreeRootChange,
  waitForYjsEntry,
} from './docs-app.helpers';

async function getLoggedInNpub(page: any): Promise<string> {
  const npub = await page.evaluate(() => (window as any).__nostrStore?.getState?.()?.npub ?? null);
  if (!npub) throw new Error('No logged-in npub');
  return npub;
}

async function setCurrentDocEditors(page: any, treeName: string, editors: string[]) {
  await page.evaluate(async ({ targetTreeName, targetEditors }) => {
    const { getTreeRootSync } = await import('/src/stores');
    const { getTree } = await import('/src/store');
    const { autosaveIfOwn, nostrStore } = await import('/src/nostr');
    const { LinkType } = await import('/src/lib/nhash.ts');

    const state = nostrStore.getState();
    if (!state.npub) throw new Error('No logged-in npub');
    const rootCid = getTreeRootSync(state.npub, targetTreeName);
    if (!rootCid) throw new Error(`Missing root for ${targetTreeName}`);

    const tree = getTree();
    const data = new TextEncoder().encode(`${targetEditors.join('\n')}\n`);
    const { cid, size } = await tree.putFile(data);
    const newRootCid = await tree.setEntry(rootCid, [], '.yjs', cid, size, LinkType.Blob);
    autosaveIfOwn(newRootCid);
  }, { targetTreeName: treeName, targetEditors: editors });
  await flushPendingPublishes(page);
}

async function getOwnTreeHash(page: any, treeName: string): Promise<string | null> {
  return page.evaluate((targetTreeName) => {
    const npub = (window as any).__nostrStore?.getState?.()?.npub;
    const registry = (window as any).__treeRootRegistry;
    const entry = npub && registry?.get ? registry.get(npub, targetTreeName as string) : null;
    if (!entry?.hash) return null;
    return Array.from(entry.hash as Uint8Array)
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
  }, treeName);
}

async function waitForOwnTreePublished(page: any, treeName: string, previousHash: string | null = null, timeoutMs = 60000) {
  await page.waitForFunction(({ targetTreeName, previous }) => {
    const npub = (window as any).__nostrStore?.getState?.()?.npub;
    const registry = (window as any).__treeRootRegistry;
    if (!npub || !registry?.get) return false;
    const entry = registry.get(npub, targetTreeName as string);
    if (!entry?.hash || entry.dirty !== false) return false;
    if (!previous) return true;
    const current = Array.from(entry.hash as Uint8Array)
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
    return current !== previous;
  }, { targetTreeName: treeName, previous: previousHash }, { timeout: timeoutMs });
}

async function waitForEditorTextNoReload(page: any, expected: string, timeoutMs = 90000) {
  const editor = page.locator('.ProseMirror');
  await expect(editor).toBeVisible({ timeout: Math.min(timeoutMs, 30000) });
  await expect.poll(async () => {
    await page.evaluate(() => {
    }).catch(() => {});
    return (await editor.textContent().catch(() => ''))?.includes(expected) ?? false;
  }, { timeout: timeoutMs, intervals: [1000, 2000, 3000] }).toBe(true);
}

test.describe('Iris Docs App', () => {
  test.setTimeout(120000);
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  test('shows Docs header', async ({ page }) => {
    await page.goto('/docs.html#/');
    await expect(page.getByRole('banner').getByRole('link', { name: /^docs$/i })).toBeVisible({ timeout: 30000 });
  });

  test('shows New Document card after login', async ({ page }) => {
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: /New/i }).click();

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });
  });

  test('can create new document', async ({ page }) => {
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: /New/i }).click();

    const newDocCard = page.locator('[role="button"]:has-text("New Document")');
    await expect(newDocCard).toBeVisible({ timeout: 15000 });

    await page.keyboard.press('Escape');
    await newDocCard.click();

    await expect(page.getByRole('heading', { name: 'New Document' })).toBeVisible({ timeout: 30000 });

    const docName = `Test Doc ${Date.now()}`;
    await page.locator('input[placeholder="Document name..."]').fill(docName);

    await expect(page.locator('button:has-text("public")')).toBeVisible({ timeout: 30000 });

    await page.getByRole('button', { name: 'Create' }).click();

    await page.waitForURL(/\/docs\.html#\/npub.*\/docs%2FTest%20Doc/, { timeout: 15000 });

    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
  });

  test('header has Docs title', async ({ page }) => {
    await page.goto('/docs.html#/');
    await expect(page.getByRole('banner').getByRole('link', { name: /^docs$/i })).toBeVisible({ timeout: 30000 });
  });

  test('document persists after refresh and shows on home', async ({ page }) => {
    test.slow();
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: /New/i }).click();

    const newDocCard = page.locator('[role="button"]:has-text("New Document")');
    await expect(newDocCard).toBeVisible({ timeout: 15000 });

    await page.keyboard.press('Escape');
    await newDocCard.click();

    const docName = `Persist Test ${Date.now()}`;
    await page.locator('input[placeholder="Document name..."]').fill(docName);
    await page.getByRole('button', { name: 'Create' }).click();

    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });

    const editor = page.locator('.ProseMirror');
    const rootBefore = await page.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
    await editor.click();
    await editor.type('Hello persistence test!');
    await expect(editor).toContainText('Hello persistence test!', { timeout: 15000 });
    await waitForTreeRootChange(page, rootBefore, 60000);
    await flushPendingPublishes(page);

    await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: 60000 });
    await waitForAppReady(page, 60000);
    await page.waitForFunction(
      () => (window as any).__nostrStore?.getState?.().pubkey?.length === 64,
      undefined,
      { timeout: 60000 }
    );
    await page.waitForFunction(
      () => typeof (window as any).__getTreeRoot === 'function' && !!(window as any).__getTreeRoot?.(),
      undefined,
      { timeout: 60000 }
    ).catch(() => {});
    await waitForYjsEntry(page, 90000);

    await waitForDocsEditor(page, 90000);
    const editorAfterReload = page.locator('.ProseMirror');
    await expect(editorAfterReload).toBeVisible({ timeout: 60000 });
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 60000 });
    await waitForEditorContent(page, ['Hello persistence test!'], 120000);

    await page.evaluate(() => window.location.hash = '#/');

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });
    await expect(page.locator(`text=${docName}`)).toBeVisible({ timeout: 30000 });
  });

  test('can navigate from home to document and view content', async ({ page }) => {
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: /New/i }).click();

    const newDocCard = page.locator('[role="button"]:has-text("New Document")');
    await expect(newDocCard).toBeVisible({ timeout: 15000 });

    await page.keyboard.press('Escape');
    await newDocCard.click();

    const docName = `Navigate Test ${Date.now()}`;
    await page.locator('input[placeholder="Document name..."]').fill(docName);
    await page.getByRole('button', { name: 'Create' }).click();

    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    const editor = page.locator('.ProseMirror');
    const rootBefore = await page.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
    await editor.click();
    await editor.type('Content for navigation test');
    await expect(editor).toContainText('Content for navigation test', { timeout: 15000 });
    await waitForTreeRootChange(page, rootBefore, 60000);

    await page.evaluate(() => window.location.hash = '#/');

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });

    const docCard = page.locator(`text=${docName}`);
    await expect(docCard).toBeVisible({ timeout: 30000 });
    await docCard.click();

    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    await expect(page.locator('.ProseMirror')).toContainText('Content for navigation test', { timeout: 30000 });
  });

  test('edits to existing document persist after navigation and refresh', async ({ page }) => {
    test.setTimeout(240000); // Extra headroom for Yjs/editor recovery under full-suite parallel load

    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 15000 });

    await page.keyboard.press('Escape');
    await page.locator('[role="button"]:has-text("New Document")').click();

    const docName = `Edit Persist Test ${Date.now()}`;
    const treeName = `docs/${docName}`;
    const encodedDocPath = encodeURIComponent(treeName);
    await page.locator('input[placeholder="Document name..."]').fill(docName);
    await page.getByRole('button', { name: 'Create' }).click();

    await page.waitForURL(url => url.toString().includes(encodedDocPath), { timeout: 60000 });
    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    const editor = page.locator('.ProseMirror');
    const rootBeforeInitial = await page.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
    await editor.click();
    await editor.type('Initial content.');
    await expect(editor).toContainText('Initial content.', { timeout: 15000 });
    await waitForTreeRootChange(page, rootBeforeInitial, 60000);
    await flushPendingPublishes(page);
    const initialSnapshot = await getOwnedTreeRootSnapshot(page, treeName);

    await page.evaluate(() => window.location.hash = '#/');
    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });

    await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: 60000 });
    await waitForAppReady(page);
    await waitForAppReady(page);
    await ensureLoggedIn(page, 30000);
    await disableOthersPool(page);
    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });
    await primeViewerTreeRoot(page, initialSnapshot, treeName);

    const docCard = page.locator(`text=${docName}`);
    await expect(docCard).toBeVisible({ timeout: 60000 });
    await docCard.click();

    await page.waitForURL(url => url.toString().includes(encodedDocPath), { timeout: 60000 });
    await waitForDocsEditor(page, 120000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    await waitForYjsEntry(page, 120000);
    await waitForEditorContent(page, ['Initial content.'], 120000);

    const editor2 = page.locator('.ProseMirror');
    const rootBeforeAppend = await page.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
    const previousEntry = await page.evaluate((name) => {
      const nostrStore = (window as any).__nostrStore;
      const npub = nostrStore?.getState?.().npub;
      const registry = (window as any).__treeRootRegistry;
      const entry = registry?.get?.(npub, name as string);
      if (!entry) return { updatedAt: null, hashHex: null };

      const toHex = (bytes: Uint8Array) => {
        let out = '';
        for (const byte of bytes) {
          out += byte.toString(16).padStart(2, '0');
        }
        return out;
      };
      return { updatedAt: entry.updatedAt ?? null, hashHex: entry.hash ? toHex(entry.hash) : null };
    }, treeName);
    await editor2.click();
    await editor2.press('End');
    await editor2.type(' Added more content.');
    await expect(editor2).toContainText('Added more content.', { timeout: 15000 });
    await page.waitForFunction(
      (payload) => {
        const { treeName: name, previous } = payload as { treeName: string; previous: { updatedAt: number | null; hashHex: string | null } };
        const nostrStore = (window as any).__nostrStore;
        const npub = nostrStore?.getState?.().npub;
        if (!npub) return false;
        const registry = (window as any).__treeRootRegistry;
        const entry = registry?.get?.(npub, name);
        if (!entry) return false;

        const toHex = (bytes: Uint8Array) => {
          let out = '';
          for (const byte of bytes) {
            out += byte.toString(16).padStart(2, '0');
          }
          return out;
        };
        const currentHash = entry.hash ? toHex(entry.hash) : null;
        const prevHash = previous?.hashHex ?? null;
        const prevUpdatedAt = previous?.updatedAt ?? null;

        if (prevHash && currentHash && currentHash !== prevHash) {
          return entry.dirty === false;
        }
        if (prevUpdatedAt !== null && entry.updatedAt !== null && entry.updatedAt > prevUpdatedAt) {
          return entry.dirty === false;
        }
        return false;
      },
      { treeName, previous: previousEntry },
      { timeout: 60000 }
    );
    await waitForTreeRootChange(page, rootBeforeAppend, 60000);
    await flushPendingPublishes(page);
    await waitForPersistedDocContent(page, treeName, ['Initial content.', 'Added more content.'], 120000);
    const appendedSnapshot = await getOwnedTreeRootSnapshot(page, treeName);

    await page.evaluate(() => window.location.hash = '#/');
    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });
    await primeViewerTreeRoot(page, appendedSnapshot, treeName);

    const persistedDocCard = page.locator(`text=${docName}`);
    await expect(persistedDocCard).toBeVisible({ timeout: 60000 });
    await persistedDocCard.click();
    await page.waitForURL(url => url.toString().includes(encodedDocPath), { timeout: 60000 });
    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    await waitForYjsEntry(page, 90000);
    await waitForEditorContent(page, ['Initial content.', 'Added more content.'], 120000);

    await page.evaluate(() => window.location.hash = '#/');
    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });

    await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: 60000 });
    await waitForAppReady(page);
    await ensureLoggedIn(page, 30000);
    await disableOthersPool(page);
    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 30000 });
    await primeViewerTreeRoot(page, appendedSnapshot, treeName);

    const reloadedDocCard = page.locator(`text=${docName}`);
    await expect(reloadedDocCard).toBeVisible({ timeout: 60000 });
    await reloadedDocCard.click();
    await page.waitForURL(url => url.toString().includes(encodedDocPath), { timeout: 60000 });

    await waitForDocsEditor(page, 90000);
    await expect(page.locator('button[title="Bold (Ctrl+B)"]')).toBeVisible({ timeout: 30000 });
    await waitForYjsEntry(page, 90000);
    await waitForEditorContent(page, ['Initial content.', 'Added more content.'], 120000);
  });

  test('autosave keeps edits made while a previous save is committing', async ({ page }) => {
    test.setTimeout(180000);

    setupPageErrorHandler(page);
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await configureBlossomServers(page);
    await ensureLoggedIn(page, 30000);

    const docName = `Save Race ${Date.now()}`;
    const treeName = `docs/${docName}`;
    await page.locator('[role="button"]:has-text("New Document")').click();
    await page.locator('input[placeholder="Document name..."]').fill(docName);
    await page.getByRole('button', { name: 'Create' }).click();
    await waitForDocsEditor(page, 90000);

    await installDocCommitDiagnostics(page);

    await page.evaluate(() => {
      const win = window as any;
      win.__yjsSaveHookCalls = 0;
      win.__firstYjsSaveReleased = false;
      win.__yjsBeforeSaveCommit = () => {
        win.__yjsSaveHookCalls += 1;
        if (win.__yjsSaveHookCalls === 1) {
          return new Promise<void>((resolve) => {
            win.__releaseFirstYjsSave = () => {
              win.__firstYjsSaveReleased = true;
              resolve();
            };
          });
        }
        return undefined;
      };
    });

    try {
      const editor = page.locator('.ProseMirror');
      await editor.click();
      await editor.type('First autosave text.');
      await page.waitForFunction(() => (window as any).__yjsSaveHookCalls === 1, undefined, { timeout: 30000 });

      await editor.type(' Second autosave text.');
      await expect(editor).toContainText('Second autosave text.', { timeout: 15000 });

      // Give the old overlapping-save path time to start and commit a newer save
      // before the first blocked save is released.
      await page.waitForTimeout(1500);
      await page.evaluate(() => (window as any).__releaseFirstYjsSave?.());

      await waitForPersistedDocContent(
        page,
        treeName,
        ['First autosave text.', 'Second autosave text.'],
        120000
      );
    } finally {
      await page.evaluate(() => {
        const win = window as any;
        win.__docsRestoreCommitDiagnostics?.();
        delete win.__yjsBeforeSaveCommit;
        delete win.__releaseFirstYjsSave;
        delete win.__yjsSaveHookCalls;
        delete win.__firstYjsSaveReleased;
      }).catch(() => {});
    }
  });

  test('another browser can view document via shared link', async ({ browser }) => {
    test.slow();

    const context1 = await browser.newContext();
    const context2 = await browser.newContext();

    const page1 = await context1.newPage();
    const page2 = await context2.newPage();

    try {
      setupPageErrorHandler(page1);
      setupPageErrorHandler(page2);

      await page1.goto('/docs.html#/');
      await waitForAppReady(page1);
      await disableOthersPool(page1);
      await configureBlossomServers(page1);
      await ensureLoggedIn(page1);

      const newDocCard = page1.locator('[role="button"]:has-text("New Document")');
      await page1.keyboard.press('Escape');
      await expect(newDocCard).toBeVisible({ timeout: 15000 });
      await newDocCard.click();

      const docName = `Shared Doc ${Date.now()}`;
      await page1.locator('input[placeholder="Document name..."]').fill(docName);
      await page1.getByRole('button', { name: 'Create' }).click();

      await waitForDocsEditor(page1, 90000);
      const editor1 = page1.locator('.ProseMirror');
      await expect(editor1).toBeVisible({ timeout: 30000 });
      const content = `Shared content ${Date.now()}`;
      const rootBefore = await page1.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
      await editor1.click();
      await editor1.type(content);
      await expect(editor1).toContainText(content, { timeout: 15000 });
      await waitForTreeRootChange(page1, rootBefore, 60000);

      const pushButton = page1.getByRole('button', { name: 'Push to file servers' });
      await expect(pushButton).toBeVisible({ timeout: 15000 });
      await pushButton.click();

      const pushModal = page1.getByTestId('blossom-push-modal');
      await expect(pushModal).toBeVisible({ timeout: 15000 });
      await pushModal.getByTestId('start-push-btn').click();
      const doneButton = pushModal.getByRole('button', { name: 'Done' });
      await expect(doneButton).toBeVisible({ timeout: 60000 });
      await doneButton.click();
      await expect(pushModal).toBeHidden({ timeout: 15000 });

      const shareUrl = page1.url();
      expect(shareUrl).toContain('/docs.html#/');
      const treeNameMatch = shareUrl.match(/#\/npub1[0-9a-z]+\/(.+)$/);
      const treeName = treeNameMatch ? decodeURIComponent(treeNameMatch[1]) : null;
      expect(treeName).toBeTruthy();
      await page1.waitForFunction(
        (docTreeName) => {
          const nostrStore = (window as any).__nostrStore;
          const npub = nostrStore?.getState()?.npub;
          if (!npub) return false;
          const registry = (window as any).__treeRootRegistry;
          const entry = registry?.get?.(npub, docTreeName as string);
          return !!entry && entry.dirty === false;
        },
        treeName,
        { timeout: 30000 }
      );
      const sharedRoot = await getOwnedTreeRootSnapshot(page1, treeName!);

      await page2.goto('/docs.html#/');
      await waitForAppReady(page2);
      await disableOthersPool(page2);
      await configureBlossomServers(page2);
      await ensureLoggedIn(page2);

      await page2.goto(shareUrl);
      await waitForAppReady(page2);
      await disableOthersPool(page2);
      await configureBlossomServers(page2);
      await primeViewerTreeRoot(page2, sharedRoot);
      await page2.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));

      await waitForDocsEditor(page2, 120000);
      const editor2 = page2.locator('.ProseMirror');
      await expect(editor2).toBeVisible({ timeout: 60000 });
      await expect(editor2).toContainText(content, { timeout: 60000 });
    } finally {
      await context1.close();
      await context2.close();
    }
  });

  test('open editors modal updates when viewer is added as editor', async ({ browser }) => {
    test.setTimeout(240000);

    const contextA = await browser.newContext();
    const contextB = await browser.newContext();
    const pageA = await contextA.newPage();
    const pageB = await contextB.newPage();

    try {
      setupPageErrorHandler(pageA);
      setupPageErrorHandler(pageB);

      await pageA.goto('/docs.html#/');
      await waitForAppReady(pageA);
      await disableOthersPool(pageA);
      await configureBlossomServers(pageA);
      await ensureLoggedIn(pageA, 30000);
      await waitForRelayConnected(pageA, 30000);
      const npubA = await getLoggedInNpub(pageA);

      const docName = `Live Editors ${Date.now()}`;
      const treeName = `docs/${docName}`;
      const encodedTreeName = encodeURIComponent(treeName);
      await pageA.locator('[role="button"]:has-text("New Document")').click();
      await pageA.locator('input[placeholder="Document name..."]').fill(docName);
      await pageA.getByRole('button', { name: 'Create' }).click();
      await pageA.waitForURL(url => url.toString().includes(encodedTreeName), { timeout: 60000 });
      await waitForDocsEditor(pageA, 90000);
      await waitForOwnTreePublished(pageA, treeName, null, 90000);

      const initialSharedRoot = await getOwnedTreeRootSnapshot(pageA, treeName);
      const shareUrl = `${new URL(pageA.url()).origin}/docs.html#/${npubA}/${encodedTreeName}`;

      await pageB.goto('/docs.html#/');
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await ensureLoggedIn(pageB, 30000);
      await waitForRelayConnected(pageB, 30000);
      const npubB = await getLoggedInNpub(pageB);

      await pageB.goto(shareUrl);
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await primeViewerTreeRoot(pageB, initialSharedRoot);
      await pageB.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));
      await waitForDocsEditor(pageB, 90000);

      const editorsButtonB = pageB.locator('button[title="View editors"]').first();
      await expect(editorsButtonB).toBeVisible({ timeout: 30000 });
      await editorsButtonB.click();

      const modalTitleB = pageB.locator('h2:has-text("Editors")');
      await expect(modalTitleB).toBeVisible({ timeout: 30000 });
      const modalPanelB = pageB.locator('.bg-surface-1').filter({ has: modalTitleB }).last();
      await expect(modalPanelB.locator(`a[href="#/${npubA}/profile"]`)).toBeVisible({ timeout: 30000 });
      await expect(modalPanelB.locator(`a[href="#/${npubB}/profile"]`)).toHaveCount(0);

      const rootBeforeEditors = await getOwnTreeHash(pageA, treeName);
      await setCurrentDocEditors(pageA, treeName, [npubA, npubB]);
      await waitForOwnTreePublished(pageA, treeName, rootBeforeEditors, 90000);

      const updatedSharedRoot = await getOwnedTreeRootSnapshot(pageA, treeName);
      await primeViewerTreeRoot(pageB, updatedSharedRoot);
      await expect.poll(async () => {
        await pageB.evaluate(() => {
          const testWindow = window as Window & {
            __reloadYjsEditors?: () => void;
          };
          window.dispatchEvent(new HashChangeEvent('hashchange'));
          testWindow.__reloadYjsEditors?.();
        }).catch(() => {});
        return (await editorsButtonB.locator('span.rounded-full').textContent().catch(() => null))?.trim() ?? '';
      }, { timeout: 90000, intervals: [1000, 2000, 3000] }).toBe('2');
      await expect(modalPanelB.locator(`a[href="#/${npubB}/profile"]`)).toBeVisible({ timeout: 30000 });
    } finally {
      await contextA.close();
      await contextB.close();
    }
  });

  test('owner sees added editor edits in a link-private document', async ({ browser }) => {
    test.setTimeout(300000);

    const contextA = await browser.newContext();
    const contextB = await browser.newContext();
    const pageA = await contextA.newPage();
    const pageB = await contextB.newPage();

    try {
      setupPageErrorHandler(pageA);
      setupPageErrorHandler(pageB);

      await pageA.goto('/docs.html#/');
      await waitForAppReady(pageA);
      await disableOthersPool(pageA);
      await configureBlossomServers(pageA);
      await ensureLoggedIn(pageA, 30000);
      await waitForRelayConnected(pageA, 30000);
      const npubA = await getLoggedInNpub(pageA);

      const docName = `Link Private Sync ${Date.now()}`;
      const created = await pageA.evaluate(async (name) => {
        const { createDocumentTree } = await import('/src/actions/tree.ts');
        return createDocumentTree(name, 'link-visible');
      }, docName);
      expect(created.success).toBe(true);
      expect(created.npub).toBeTruthy();
      expect(created.treeName).toBeTruthy();
      expect(created.linkKey).toBeTruthy();

      const treeName = created.treeName!;
      const linkKey = created.linkKey!;
      const encodedTreeName = encodeURIComponent(treeName);
      const shareUrl = `${new URL(pageA.url()).origin}/docs.html#/${npubA}/${encodedTreeName}?k=${linkKey}`;
      await pageA.goto(shareUrl);
      await waitForAppReady(pageA);
      await waitForDocsEditor(pageA, 90000);
      await flushPendingPublishes(pageA);
      await waitForOwnTreePublished(pageA, treeName, null, 90000);

      const editorA = pageA.locator('.ProseMirror');
      const ownerSeed = `owner link seed ${Date.now()}`;
      const rootBeforeSeed = await getOwnTreeHash(pageA, treeName);
      await editorA.click();
      await editorA.type(ownerSeed);
      await expect(editorA).toContainText(ownerSeed, { timeout: 15000 });
      await waitForOwnTreePublished(pageA, treeName, rootBeforeSeed, 90000);
      await flushPendingPublishes(pageA);

      await pageB.goto('/docs.html#/');
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await ensureLoggedIn(pageB, 30000);
      await waitForRelayConnected(pageB, 30000);
      const npubB = await getLoggedInNpub(pageB);

      const rootBeforeEditors = await getOwnTreeHash(pageA, treeName);
      await setCurrentDocEditors(pageA, treeName, [npubA, npubB]);
      await waitForOwnTreePublished(pageA, treeName, rootBeforeEditors, 90000);
      await flushPendingPublishes(pageA);
      const editorsRoot = await getOwnedTreeRootSnapshot(pageA, treeName);
      await pageA.evaluate(async () => {
        const testWindow = window as Window & { __reloadYjsEditors?: () => void | Promise<void> };
        window.dispatchEvent(new HashChangeEvent('hashchange'));
        await testWindow.__reloadYjsEditors?.();
      });

      await pageB.goto(shareUrl);
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await primeViewerTreeRoot(pageB, editorsRoot);
      await pageB.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));
      await waitForDocsEditor(pageB, 90000);
      await waitForEditorTextNoReload(pageB, ownerSeed, 90000);
      await expect(pageB.getByText('Editor', { exact: true })).toBeVisible({ timeout: 90000 });

      const editorB = pageB.locator('.ProseMirror');
      const markerB = `link editor edit ${Date.now()}`;
      const rootBeforeB = await getOwnTreeHash(pageB, treeName);
      await editorB.click();
      await editorB.press('End');
      await editorB.type(` ${markerB}`);
      await expect(editorB).toContainText(markerB, { timeout: 15000 });
      await waitForOwnTreePublished(pageB, treeName, rootBeforeB, 90000);
      await flushPendingPublishes(pageB);

      await waitForEditorTextNoReload(pageA, markerB, 120000);
    } finally {
      await contextA.close();
      await contextB.close();
    }
  });

  test('two editors sync docs changes in both directions and survive reload', async ({ browser }) => {
    test.setTimeout(300000);

    const contextA = await browser.newContext();
    const contextB = await browser.newContext();
    const pageA = await contextA.newPage();
    const pageB = await contextB.newPage();

    try {
      setupPageErrorHandler(pageA);
      setupPageErrorHandler(pageB);

      await pageA.goto('/docs.html#/');
      await waitForAppReady(pageA);
      await disableOthersPool(pageA);
      await configureBlossomServers(pageA);
      await ensureLoggedIn(pageA, 30000);
      await waitForRelayConnected(pageA, 30000);

      const npubA = await getLoggedInNpub(pageA);

      const docName = `Bidirectional Sync ${Date.now()}`;
      const treeName = `docs/${docName}`;
      const encodedTreeName = encodeURIComponent(treeName);
      await pageA.locator('[role="button"]:has-text("New Document")').click();
      await pageA.locator('input[placeholder="Document name..."]').fill(docName);
      await pageA.getByRole('button', { name: 'Create' }).click();
      await pageA.waitForURL(url => url.toString().includes(encodedTreeName), { timeout: 60000 });
      await waitForDocsEditor(pageA, 90000);

      const editorA = pageA.locator('.ProseMirror');
      const ownerSeed = `owner seed ${Date.now()}`;
      const rootBeforeSeed = await pageA.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
      await editorA.click();
      await editorA.type(ownerSeed);
      await expect(editorA).toContainText(ownerSeed, { timeout: 15000 });
      await waitForTreeRootChange(pageA, rootBeforeSeed, 60000);
      await flushPendingPublishes(pageA);

      await pageB.goto('/docs.html#/');
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await ensureLoggedIn(pageB, 30000);
      await waitForRelayConnected(pageB, 30000);
      const npubB = await getLoggedInNpub(pageB);

      const rootBeforeEditors = await getOwnTreeHash(pageA, treeName);
      await setCurrentDocEditors(pageA, treeName, [npubA, npubB]);
      await waitForOwnTreePublished(pageA, treeName, rootBeforeEditors, 90000);
      const sharedRoot = await getOwnedTreeRootSnapshot(pageA, treeName);
      const shareUrl = `${new URL(pageA.url()).origin}/docs.html#/${npubA}/${encodedTreeName}`;

      await pageB.goto(shareUrl);
      await waitForAppReady(pageB);
      await disableOthersPool(pageB);
      await configureBlossomServers(pageB);
      await primeViewerTreeRoot(pageB, sharedRoot);
      await pageB.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));
      await waitForDocsEditor(pageB, 90000);
      await waitForEditorTextNoReload(pageB, ownerSeed, 90000);
      await expect(pageB.getByText('Editor', { exact: true })).toBeVisible({ timeout: 60000 });

      const editorB = pageB.locator('.ProseMirror');
      const markerB = `edit from B ${Date.now()}`;
      const rootBeforeB = await getOwnTreeHash(pageB, treeName);
      await editorB.click();
      await editorB.press('End');
      await editorB.type(` ${markerB}`);
      await expect(editorB).toContainText(markerB, { timeout: 15000 });
      await waitForOwnTreePublished(pageB, treeName, rootBeforeB, 90000);
      await flushPendingPublishes(pageB);
      await waitForEditorTextNoReload(pageA, markerB, 90000);

      const markerA = `edit from A ${Date.now()}`;
      const rootBeforeA = await getOwnTreeHash(pageA, treeName);
      await editorA.click();
      await editorA.press('End');
      await editorA.type(` ${markerA}`);
      await expect(editorA).toContainText(markerA, { timeout: 15000 });
      await waitForOwnTreePublished(pageA, treeName, rootBeforeA, 90000);
      await flushPendingPublishes(pageA);
      await waitForEditorTextNoReload(pageB, markerA, 90000);

      const latestSharedRoot = await getOwnedTreeRootSnapshot(pageA, treeName);
      await Promise.all([
        safeReload(pageA, { waitUntil: 'domcontentloaded', timeoutMs: 60000 }),
        safeReload(pageB, { waitUntil: 'domcontentloaded', timeoutMs: 60000 }),
      ]);
      await Promise.all([
        waitForAppReady(pageA, 60000),
        waitForAppReady(pageB, 60000),
      ]);
      await primeViewerTreeRoot(pageB, latestSharedRoot);
      await pageB.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));
      await Promise.all([
        waitForDocsEditor(pageA, 90000),
        waitForDocsEditor(pageB, 90000),
      ]);
      for (const expected of [ownerSeed, markerB, markerA]) {
        await waitForEditorTextNoReload(pageA, expected, 90000);
        await waitForEditorTextNoReload(pageB, expected, 90000);
      }
    } finally {
      await contextA.close();
      await contextB.close();
    }
  });

  test('New Document button shows after auto-login on refresh', async ({ page }) => {
    test.setTimeout(60000);
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    await page.getByRole('button', { name: /New/i }).click();

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 15000 });

    try {
      await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs: 60000 });
    } catch {
      await page.goto('/docs.html#/', { waitUntil: 'domcontentloaded' });
    }
    await waitForAppReady(page);

    await expect(page.locator('[role="button"]:has-text("New Document")')).toBeVisible({ timeout: 15000 });
  });

  test('editor maintains focus after auto-save in docs app', async ({ page }) => {
    await page.goto('/docs.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    await page.getByRole('button', { name: /New/i }).click();

    const newDocCard = page.locator('[role="button"]:has-text("New Document")');
    await expect(newDocCard).toBeVisible({ timeout: 15000 });

    await page.keyboard.press('Escape');
    await newDocCard.click();

    const docName = `Focus Test ${Date.now()}`;
    await page.locator('input[placeholder="Document name..."]').fill(docName);
    await page.getByRole('button', { name: 'Create' }).click();

    await waitForDocsEditor(page, 90000);
    const editor = page.locator('.ProseMirror');
    await expect(editor).toBeVisible({ timeout: 30000 });
    await editor.click();

    const rootBefore = await page.evaluate(() => (window as any).__getTreeRoot?.() ?? null);
    await page.keyboard.type('First sentence.');
    await waitForTreeRootChange(page, rootBefore, 60000);

    const hasFocus = await page.evaluate(() => {
      const active = document.activeElement;
      const editor = document.querySelector('.ProseMirror');
      return editor?.contains(active) || active === editor;
    });
    expect(hasFocus).toBe(true);

    await page.keyboard.type(' Second sentence.');

    await expect(editor).toContainText('First sentence. Second sentence.', { timeout: 30000 });
  });
});
