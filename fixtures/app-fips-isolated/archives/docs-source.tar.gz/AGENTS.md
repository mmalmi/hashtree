Keep this repo focused on the standalone Iris Docs app.

- Consume shared UI, release tooling, and Nostr helpers from immutable Iris Kit releases.
  Use a sibling checkout only for deliberate package development, never in the
  app's release manifest or lockfile.
- Before release, run `pnpm run test:unit`, `pnpm run test:docs:iris`, and `node ./scripts/release-site.mjs docs --dry-run`.
- Keep docs release scripts testing the built output before publish/deploy.
