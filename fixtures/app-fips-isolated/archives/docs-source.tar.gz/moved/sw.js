// Iris Docs moved to Iris Drive. This replaces the old app's offline worker: it
// drops the cached copy, removes itself and reloads open tabs so they follow
// the redirect instead of showing the cached app forever.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) await caches.delete(key);
    await self.registration.unregister();
    for (const client of await self.clients.matchAll({ type: 'window' })) client.navigate(client.url);
  })());
});
