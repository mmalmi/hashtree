// Iris Docs moved to Iris Drive. Every address on docs.iris.to answers with the
// page in moved/ that sends the visitor to Drive; /sw.js replaces the old app's
// offline worker so tabs that still have the old app cached follow along.
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== '/sw.js') url.pathname = '/';
    const response = await env.ASSETS.fetch(new Request(url, { headers: request.headers }));
    const headers = new Headers(response.headers);
    headers.set('cache-control', 'no-store');
    return new Response(response.body, { status: response.status, headers });
  },
};
