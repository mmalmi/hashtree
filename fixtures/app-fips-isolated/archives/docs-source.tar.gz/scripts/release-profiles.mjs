export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  docs: {
    name: 'docs',
    appName: 'Iris Docs',
    distDir: 'dist-docs',
    treeName: 'docs',
    defaultWorkerName: 'iris-docs',
    defaultRoutes: ['docs.iris.to/*'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_DOCS',
    pagesProjectEnv: 'CF_PAGES_PROJECT_DOCS',
    buildCommand: ['pnpm', 'run', 'build:docs'],
    testCommands: [
      ['node', './scripts/smoke-graph-policy.mjs', 'docs'],
      ['pnpm', 'run', 'lint'],
      ['pnpm', 'run', 'test:unit'],
      ['node', './scripts/smoke-docs-iris-portable.mjs'],
      ['pnpm', 'run', 'test:e2e:release'],
    ],
  },
};

export const releaseProfileNames = ['docs'];
