import type { TreeVisibility } from '@hashtree/core';

export interface DocsHomeItem {
  key: string;
  displayName: string;
  ownerPubkey?: string | null;
  ownerNpub?: string | null;
  treeName?: string | null;
  visibility?: TreeVisibility;
  href: string;
  timestamp: number;
  rootHashHex?: string | null;
  linkKey?: string;
}

function linkKeyFromHref(href: string): string | undefined {
  const match = href.match(/[?&]k=([^&#]+)/);
  if (!match?.[1]) return undefined;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}

function getLinkKey(doc: DocsHomeItem): string | undefined {
  return doc.linkKey ?? linkKeyFromHref(doc.href);
}

function hasLinkPrivateSignal(doc: DocsHomeItem): boolean {
  return Boolean(getLinkKey(doc)) || doc.visibility === 'link-visible';
}

function isDocsTree(doc: DocsHomeItem): doc is DocsHomeItem & { treeName: string } {
  return Boolean(doc.treeName?.startsWith('docs/'));
}

function buildLinkPrivateGroups(docs: DocsHomeItem[]) {
  const linkKeysByTree = new Map<string, Set<string>>();
  const linkVisibleTrees = new Set<string>();

  for (const doc of docs) {
    if (!isDocsTree(doc)) continue;

    const linkKey = getLinkKey(doc);
    if (linkKey) {
      let linkKeys = linkKeysByTree.get(doc.treeName);
      if (!linkKeys) {
        linkKeys = new Set<string>();
        linkKeysByTree.set(doc.treeName, linkKeys);
      }
      linkKeys.add(linkKey);
    }

    if (doc.visibility === 'link-visible') {
      linkVisibleTrees.add(doc.treeName);
    }
  }

  return { linkKeysByTree, linkVisibleTrees };
}

function dedupeKeys(
  doc: DocsHomeItem,
  groups: ReturnType<typeof buildLinkPrivateGroups>
): string[] {
  const keys: string[] = [];
  const linkKey = getLinkKey(doc);

  if (isDocsTree(doc)) {
    const knownLinkKeys = groups.linkKeysByTree.get(doc.treeName);
    if (linkKey) {
      keys.push(`link:${doc.treeName}:${linkKey}`);
    } else if (knownLinkKeys?.size === 1) {
      keys.push(`link:${doc.treeName}:${[...knownLinkKeys][0]}`);
    } else if (groups.linkVisibleTrees.has(doc.treeName)) {
      keys.push(`link-visible:${doc.treeName}`);
    }
  }

  if (doc.ownerNpub && doc.treeName) {
    keys.push(`owner:${doc.ownerNpub}/${doc.treeName}`);
  } else {
    keys.push(`href:${doc.href}`);
  }

  return keys;
}

function shouldReplaceDoc(existing: DocsHomeItem, candidate: DocsHomeItem): boolean {
  const existingHasLinkKey = Boolean(getLinkKey(existing));
  const candidateHasLinkKey = Boolean(getLinkKey(candidate));
  if (candidateHasLinkKey !== existingHasLinkKey) return candidateHasLinkKey;

  const existingHasSignal = hasLinkPrivateSignal(existing);
  const candidateHasSignal = hasLinkPrivateSignal(candidate);
  if (candidateHasSignal !== existingHasSignal) return candidateHasSignal;

  return false;
}

export function mergeDocsHomeItems(
  recentDocs: DocsHomeItem[],
  ownDocs: DocsHomeItem[],
  limit = 30
): DocsHomeItem[] {
  const docs = [...recentDocs, ...ownDocs];
  const groups = buildLinkPrivateGroups(docs);
  const seen = new Map<string, number>();
  const result: DocsHomeItem[] = [];

  for (const doc of docs) {
    const keys = dedupeKeys(doc, groups);
    const existingIndex = keys
      .map(key => seen.get(key))
      .find((index): index is number => index !== undefined);

    if (existingIndex !== undefined) {
      if (shouldReplaceDoc(result[existingIndex], doc)) {
        result[existingIndex] = doc;
      }
      continue;
    }

    const index = result.length;
    keys.forEach(key => seen.set(key, index));
    result.push(doc);
  }

  return result.slice(0, limit);
}
