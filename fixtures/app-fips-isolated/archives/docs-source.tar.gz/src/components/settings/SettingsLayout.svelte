<script lang="ts">
  import SharedSettingsLayout from '@iris/hashtree-app/SettingsLayout.svelte';
  import { currentPath, navigate } from '../../lib/router.svelte';
  import AppSettings from './AppSettings.svelte';
  import P2PSettings from './P2PSettings.svelte';
  import ServersSettings from './ServersSettings.svelte';
  import StorageSettings from './StorageSettings.svelte';
  import TransportUsageSettings from './TransportUsageSettings.svelte';
</script>

<SharedSettingsLayout
  currentPath={$currentPath}
  {navigate}
  appSettings={AppSettings}
  storageSettings={StorageSettings}
  trafficSettings={TransportUsageSettings}
  serversSettings={ServersSettings}
  p2pSettings={P2PSettings}
/>
