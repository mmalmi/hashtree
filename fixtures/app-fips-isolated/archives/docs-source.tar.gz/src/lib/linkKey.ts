/** A sharing secret is opaque, including the first byte of a 33-byte secret. */
export function isLinkKeyHex(value: string | null | undefined): value is string {
  return typeof value === 'string' && /^(?:[a-f0-9]{2}){32,33}$/i.test(value);
}
