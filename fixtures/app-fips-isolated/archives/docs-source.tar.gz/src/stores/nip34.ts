/**
 * Stores for NIP-34 Pull Requests and Issues
 */
import { writable, type Readable } from 'svelte/store';
import { KeyedEventEmitter } from '../utils/keyedEventEmitter';
import { LRUCache } from '../utils/lruCache';
import {
  fetchPullRequests,
  fetchIssues,
  type PullRequest,
  type Issue,
  type ItemStatus,
} from '../nip34';

export interface PullRequestsState {
  items: PullRequest[];
  loading: boolean;
  error: string | null;
  filter: ItemStatus | 'all';
}

export interface IssuesState {
  items: Issue[];
  loading: boolean;
  error: string | null;
  filter: ItemStatus | 'all';
}

export interface RepoTabCounts {
  pullRequests: number | null;
  issues: number | null;
  loading: boolean;
  error: string | null;
  updatedAt: number;
}

const repoTabCountsCache = new LRUCache<string, RepoTabCounts>(200);
const repoTabCountsEmitter = new KeyedEventEmitter<string, RepoTabCounts>();
const activeRepoTabCountRequests = new Map<string, Promise<void>>();

function getRepoTabCountsKey(npub: string | null, repoName: string | null): string {
  if (!npub || !repoName) {
    return '';
  }

  return `${npub}/${repoName}`;
}

function createEmptyRepoTabCountsState(loading: boolean): RepoTabCounts {
  return {
    pullRequests: null,
    issues: null,
    loading,
    error: null,
    updatedAt: 0,
  };
}

export function countRepoTabItems<T extends { status: ItemStatus }>(items: T[]): number {
  return items.reduce((count, item) => (
    item.status === 'open' || item.status === 'draft'
      ? count + 1
      : count
  ), 0);
}

export function formatRepoTabCount(count: number): string {
  return count.toLocaleString();
}

async function fetchRepoTabCounts(npub: string, repoName: string): Promise<void> {
  const cacheKey = getRepoTabCountsKey(npub, repoName);
  if (!cacheKey) {
    return;
  }

  const activeRequest = activeRepoTabCountRequests.get(cacheKey);
  if (activeRequest) {
    return activeRequest;
  }

  const request = (async () => {
    const previous = repoTabCountsCache.get(cacheKey) ?? createEmptyRepoTabCountsState(true);
    const [pullRequestsResult, issuesResult] = await Promise.allSettled([
      fetchPullRequests(npub, repoName),
      fetchIssues(npub, repoName),
    ]);

    const nextState: RepoTabCounts = {
      pullRequests: pullRequestsResult.status === 'fulfilled'
        ? countRepoTabItems(pullRequestsResult.value)
        : previous.pullRequests,
      issues: issuesResult.status === 'fulfilled'
        ? countRepoTabItems(issuesResult.value)
        : previous.issues,
      loading: false,
      error: [
        pullRequestsResult.status === 'rejected'
          ? (pullRequestsResult.reason instanceof Error ? pullRequestsResult.reason.message : 'Failed to fetch pull requests')
          : null,
        issuesResult.status === 'rejected'
          ? (issuesResult.reason instanceof Error ? issuesResult.reason.message : 'Failed to fetch issues')
          : null,
      ].filter(Boolean).join('; ') || null,
      updatedAt: Date.now(),
    };

    repoTabCountsCache.set(cacheKey, nextState);
    repoTabCountsEmitter.notify(cacheKey, nextState);
  })().finally(() => {
    activeRepoTabCountRequests.delete(cacheKey);
  });

  activeRepoTabCountRequests.set(cacheKey, request);
  return request;
}

export function refreshRepoTabCounts(npub: string | null, repoName: string | null): Promise<void> {
  if (!npub || !repoName) {
    return Promise.resolve();
  }

  return fetchRepoTabCounts(npub, repoName);
}

export function createRepoTabCountsStore(npub: string | null, repoName: string | null): Readable<RepoTabCounts> & {
  refresh: () => Promise<void>;
  destroy: () => void;
} {
  const cacheKey = getRepoTabCountsKey(npub, repoName);
  const initialState = cacheKey
    ? (repoTabCountsCache.get(cacheKey) ?? createEmptyRepoTabCountsState(true))
    : createEmptyRepoTabCountsState(false);
  const { subscribe: storeSubscribe, set } = writable<RepoTabCounts>(initialState);

  if (cacheKey && npub && repoName) {
    const unsubscribe = repoTabCountsEmitter.subscribe(cacheKey, set);
    const cached = repoTabCountsCache.get(cacheKey);
    if (cached) {
      set(cached);
    }
    void fetchRepoTabCounts(npub, repoName);

    return {
      subscribe: storeSubscribe,
      refresh: () => fetchRepoTabCounts(npub, repoName),
      destroy: unsubscribe,
    };
  }

  return {
    subscribe: storeSubscribe,
    refresh: () => Promise.resolve(),
    destroy: () => {},
  };
}

/**
 * Create a store for pull requests for a specific repo
 */
export function createPullRequestsStore(npub: string | null, repoName: string | null): Readable<PullRequestsState> & {
  refresh: () => Promise<void>;
  setFilter: (filter: ItemStatus | 'all') => void;
} {
  const { subscribe, set, update } = writable<PullRequestsState>({
    items: [],
    loading: true,
    error: null,
    filter: 'all',
  });

  async function refresh() {
    if (!npub || !repoName) {
      set({ items: [], loading: false, error: null, filter: 'all' });
      return;
    }

    update(s => ({ ...s, loading: true, error: null }));

    try {
      const prs = await fetchPullRequests(npub, repoName);
      update(s => ({ ...s, items: prs, loading: false }));
    } catch (err) {
      update(s => ({
        ...s,
        loading: false,
        error: err instanceof Error ? err.message : 'Failed to fetch pull requests',
      }));
    }
  }

  function setFilter(filter: ItemStatus | 'all') {
    update(s => ({ ...s, filter }));
  }

  // Initial fetch
  if (npub && repoName) {
    refresh();
  } else {
    set({ items: [], loading: false, error: null, filter: 'all' });
  }

  return {
    subscribe,
    refresh,
    setFilter,
  };
}

/**
 * Create a store for issues for a specific repo
 */
export function createIssuesStore(npub: string | null, repoName: string | null): Readable<IssuesState> & {
  refresh: () => Promise<void>;
  setFilter: (filter: ItemStatus | 'all') => void;
} {
  const { subscribe, set, update } = writable<IssuesState>({
    items: [],
    loading: true,
    error: null,
    filter: 'all',
  });

  async function refresh() {
    if (!npub || !repoName) {
      set({ items: [], loading: false, error: null, filter: 'all' });
      return;
    }

    update(s => ({ ...s, loading: true, error: null }));

    try {
      const issues = await fetchIssues(npub, repoName);
      update(s => ({ ...s, items: issues, loading: false }));
    } catch (err) {
      update(s => ({
        ...s,
        loading: false,
        error: err instanceof Error ? err.message : 'Failed to fetch issues',
      }));
    }
  }

  function setFilter(filter: ItemStatus | 'all') {
    update(s => ({ ...s, filter }));
  }

  // Initial fetch
  if (npub && repoName) {
    refresh();
  } else {
    set({ items: [], loading: false, error: null, filter: 'all' });
  }

  return {
    subscribe,
    refresh,
    setFilter,
  };
}

/**
 * Filter items by status
 */
export function filterByStatus<T extends { status: ItemStatus }>(
  items: T[],
  filter: ItemStatus | 'all'
): T[] {
  if (filter === 'all') return items;
  return items.filter(item => item.status === filter);
}

/**
 * Count items by status
 */
export function countByStatus<T extends { status: ItemStatus }>(items: T[]): Record<ItemStatus | 'all', number> {
  const counts: Record<ItemStatus | 'all', number> = {
    all: items.length,
    open: 0,
    merged: 0,
    closed: 0,
    draft: 0,
  };

  for (const item of items) {
    counts[item.status]++;
  }

  return counts;
}
