import { writable } from 'svelte/store';
import { type NostrEvent, nostr } from '../nostr';
import { createFollowsStore } from './follows';
import {
  getGitRepoAnnouncementOpenLink,
  type GitRepoAnnouncement,
  isNewerGitRepoAnnouncement,
  parseGitRepoAnnouncement,
} from '../lib/gitRepoAnnouncements';
import { KIND_REPO_ANNOUNCEMENT } from '../utils/constants';

export const DEFAULT_GIT_DISCOVERY_AUTHOR_LIMIT = 500;
const DEFAULT_REPO_LIMIT = 12;
export const DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_NPUB = 'npub1g53mukxnjkcmr94fhryzkqutdz2ukq4ks0gvy5af25rgmwsl4ngq43drvk';

const TEST_GIT_DISCOVERY_FALLBACK_PUBKEY = import.meta.env.VITE_TEST_GIT_DISCOVERY_FALLBACK_PUBKEY as string | undefined;
export const DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_PUBKEY =
  import.meta.env.VITE_TEST_MODE && TEST_GIT_DISCOVERY_FALLBACK_PUBKEY
    ? TEST_GIT_DISCOVERY_FALLBACK_PUBKEY
    : '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';

export interface FollowedRepoAnnouncement {
  address: string;
  ownerPubkey: string;
  ownerNpub: string;
  repoName: string;
  href: string;
  external: boolean;
  updatedAt: number;
}

export interface FollowedRepoAnnouncementsState {
  repos: FollowedRepoAnnouncement[];
  followedPubkeys: string[];
  loading: boolean;
  updatedAt: number;
}

export type GitRepoDiscoveryFollowSourceType = 'user' | 'fallback';

export interface GitRepoDiscoveryFollowSource {
  type: GitRepoDiscoveryFollowSourceType;
  pubkey: string;
  follows: string[];
}

function toFollowedRepoAnnouncement(announcement: GitRepoAnnouncement): FollowedRepoAnnouncement | null {
  const openLink = getGitRepoAnnouncementOpenLink(announcement);
  if (!openLink) {
    return null;
  }

  return {
    address: announcement.address,
    ownerPubkey: announcement.ownerPubkey,
    ownerNpub: announcement.ownerNpub,
    repoName: announcement.repoName,
    href: openLink.href,
    external: openLink.external,
    updatedAt: announcement.createdAt,
  };
}

export function selectGitRepoDiscoveryFollowSource(
  userPubkey: string,
  userFollows?: string[],
  fallbackFollows?: string[],
  fallbackPubkey = DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_PUBKEY,
): GitRepoDiscoveryFollowSource {
  if ((userFollows?.length ?? 0) > 0) {
    return {
      type: 'user',
      pubkey: userPubkey,
      follows: userFollows ?? [],
    };
  }

  return {
    type: 'fallback',
    pubkey: fallbackPubkey,
    follows: fallbackFollows ?? [],
  };
}

export function limitGitRepoDiscoveryAuthors(
  pubkeys: string[],
  userPubkey: string,
  authorLimit: number,
): string[] {
  const seen = new Set<string>();
  const limited: string[] = [];

  for (const pubkey of pubkeys) {
    if (!pubkey || pubkey.length !== 64 || pubkey === userPubkey || seen.has(pubkey)) {
      continue;
    }

    seen.add(pubkey);
    limited.push(pubkey);
    if (limited.length >= authorLimit) {
      break;
    }
  }

  return limited;
}

function buildState(
  announcementsByAddress: Map<string, GitRepoAnnouncement>,
  followedPubkeys: string[],
  repoLimit: number,
  loading: boolean,
): FollowedRepoAnnouncementsState {
  const repos = [...announcementsByAddress.values()]
    .sort((a, b) => (
      b.createdAt - a.createdAt ||
      a.ownerNpub.localeCompare(b.ownerNpub) ||
      a.repoName.localeCompare(b.repoName) ||
      a.address.localeCompare(b.address)
    ))
    .map(toFollowedRepoAnnouncement)
    .filter((repo): repo is FollowedRepoAnnouncement => !!repo)
    .slice(0, repoLimit);

  return {
    repos,
    followedPubkeys,
    loading,
    updatedAt: repos.reduce((latest, repo) => Math.max(latest, repo.updatedAt), 0),
  };
}

export function createFollowedRepoAnnouncementsStore(
  userPubkey?: string | null,
  options: { authorLimit?: number; repoLimit?: number; fallbackFollowsPubkey?: string } = {},
) {
  const authorLimit = options.authorLimit ?? DEFAULT_GIT_DISCOVERY_AUTHOR_LIMIT;
  const repoLimit = options.repoLimit ?? DEFAULT_REPO_LIMIT;
  const fallbackFollowsPubkey = options.fallbackFollowsPubkey ?? DEFAULT_GIT_DISCOVERY_FALLBACK_FOLLOWS_PUBKEY;
  const initialState: FollowedRepoAnnouncementsState = {
    repos: [],
    followedPubkeys: [],
    loading: !!userPubkey,
    updatedAt: 0,
  };
  const { subscribe, set } = writable<FollowedRepoAnnouncementsState>(initialState);

  if (!userPubkey || userPubkey.length !== 64) {
    return {
      subscribe,
      destroy: () => {},
    };
  }
  const currentUserPubkey = userPubkey;

  const announcementsByAddress = new Map<string, GitRepoAnnouncement>();
  let followedPubkeys: string[] = [];
  let authorsKey = '';
  let repoSub: { stop: () => void } | null = null;
  let destroyed = false;
  let userFollows: string[] | undefined;
  let fallbackFollows: string[] | undefined;

  function publish(loading = false): void {
    set(buildState(announcementsByAddress, followedPubkeys, repoLimit, loading));
  }

  function applyAnnouncement(announcement: GitRepoAnnouncement): void {
    if (!followedPubkeys.includes(announcement.ownerPubkey)) {
      return;
    }

    const current = announcementsByAddress.get(announcement.address);
    if (!isNewerGitRepoAnnouncement(announcement, current)) {
      return;
    }

    announcementsByAddress.set(announcement.address, announcement);
    publish(false);
  }

  function startRepoSubscription(nextFollowedPubkeys: string[]): void {
    const limitedPubkeys = limitGitRepoDiscoveryAuthors(nextFollowedPubkeys, currentUserPubkey, authorLimit);
    const nextAuthorsKey = limitedPubkeys.join(',');
    if (nextAuthorsKey === authorsKey) {
      return;
    }

    authorsKey = nextAuthorsKey;
    followedPubkeys = limitedPubkeys;
    repoSub?.stop();
    repoSub = null;
    announcementsByAddress.clear();

    if (limitedPubkeys.length === 0) {
      publish(false);
      return;
    }

    publish(true);
    const sub = nostr.subscribe(
      {
        kinds: [KIND_REPO_ANNOUNCEMENT],
        authors: limitedPubkeys,
        limit: Math.max(repoLimit * 4, 50),
      },
      { closeAfterHistory: false },
    );

    sub.on('event', (event: NostrEvent) => {
      const announcement = parseGitRepoAnnouncement(event);
      if (!announcement) {
        return;
      }

      applyAnnouncement(announcement);
    });

    sub.on('history', () => {
      if (!destroyed) {
        publish(false);
      }
    });

    repoSub = { stop: () => sub.stop() };
  }

  function refreshFollowSource(): void {
    const fallbackList = fallbackFollowsPubkey === currentUserPubkey
      ? userFollows
      : fallbackFollows;
    const source = selectGitRepoDiscoveryFollowSource(
      currentUserPubkey,
      userFollows,
      fallbackList,
      fallbackFollowsPubkey,
    );
    startRepoSubscription(source.follows);
  }

  const followsStore = createFollowsStore(currentUserPubkey);
  const unsubscribeFollows = followsStore.subscribe(value => {
    userFollows = value?.follows ?? [];
    refreshFollowSource();
  });
  const fallbackFollowsStore = fallbackFollowsPubkey && fallbackFollowsPubkey !== currentUserPubkey
    ? createFollowsStore(fallbackFollowsPubkey)
    : null;
  const unsubscribeFallbackFollows = fallbackFollowsStore?.subscribe(value => {
    fallbackFollows = value?.follows ?? [];
    refreshFollowSource();
  }) ?? (() => {});

  return {
    subscribe,
    destroy: () => {
      destroyed = true;
      unsubscribeFollows();
      unsubscribeFallbackFollows();
      followsStore.destroy();
      fallbackFollowsStore?.destroy();
      repoSub?.stop();
      repoSub = null;
    },
  };
}
