/**
 * Nostr integration for HashTree Explorer
 * Uses the shared pubsub worker for events and offline storage
 */

// Re-export TreeVisibility from hashtree lib
export type { TreeVisibility } from '@hashtree/core';

// Store exports
export {
  nostrStore,
  useNostrStore,
  type NostrState,
  type HashTreeEvent,
  type RelayStatus,
  type RelayInfo,
} from './store';

export { nostr, signEvent, createNsecSigner, createExtensionSigner } from './client';
export type { NostrEvent, NostrFilter } from './client';

// Relay management exports
export {
  updateConnectedRelayCount,
  initRelayTracking,
  normalizeRelayUrl,
} from './relays';

// Authentication exports
export {
  restoreSession,
  loginWithExtension,
  loginWithNsec,
  generateNewKey,
  createDriveProfile,
  waitForNostrExtension,
  initReadonlyBackend,
  initReadonlyWorker,
  logout,
  getSecretKey,
  getNsec,
  encrypt,
  decrypt,
} from './auth';

// Tree management exports
export {
  saveHashtree,
  publishTreeRoot,
  deleteTree,
  autosaveIfOwn,
  isOwnTree,
  parseVisibility,
  pubkeyToNpub,
  npubToPubkey,
  linkKeyUtils,
  type SaveHashtreeOptions,
} from './trees';

// Re-export stopWebRTC for backwards compatibility (actual impl is in ../store)
export { stopWebRTC } from '../store';
