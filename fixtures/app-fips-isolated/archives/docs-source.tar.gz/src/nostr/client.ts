import type { NostrIdentityEventSigner } from '@iris/identity/signers';
import { AppNostrClient } from '@iris/hashtree-app/nostr';
import {
  createNostrIdentitySignerFromNsec,
  createNostrIdentitySignerFromNip07,
} from '@iris/identity/signers';
import type { EventTemplate } from 'nostr-tools';
import { getRuntimeHtreeServerUrl, getRuntimeNostrRelays } from '../lib/htreeRuntime';
import { settingsStore } from '../stores/settings';

// Keep the client and its signer alive for the same lifetime as nostrStore,
// including module re-evaluation during development.
const existingClient = typeof window !== 'undefined'
  ? (window as Window & { __nostr?: AppNostrClient }).__nostr
  : undefined;
export const nostr = existingClient ?? new AppNostrClient();
export type { Event as NostrEvent, Filter as NostrFilter } from 'nostr-tools';
export { createNostrIdentitySignerFromNsec as createNsecSigner };

// The worker asks the active account to sign and encrypt when it has no local key.
export function getAccountProvider() {
  const signer = nostr.signer as NostrIdentityEventSigner | undefined;
  if (signer?.method !== 'nip46') return window.nostr;
  async function checkAccount<T>(request: Promise<T>) {
    const result = await request;
    if (nostr.signer !== signer) throw new Error('Account changed during signer request.');
    return result;
  }
  return {
    getPublicKey: async () => signer.getPublicKey(),
    signEvent: async (event: EventTemplate & { pubkey?: string }) => {
      if (event.pubkey && event.pubkey !== await signer.getPublicKey()) throw new Error('Account changed before signing.');
      return checkAccount(Promise.resolve(signer.signEvent(event)));
    },
    nip44: {
      encrypt: (peer: string, text: string) => checkAccount(Promise.resolve(signer.nip44Encrypt!(peer, text))),
      decrypt: (peer: string, text: string) => checkAccount(Promise.resolve(signer.nip44Decrypt!(peer, text))),
    },
  };
}

export function createExtensionSigner() {
  if (!window.nostr) throw new Error('No signing extension found.');
  return createNostrIdentitySignerFromNip07(window.nostr);
}

export function signEvent(event: EventTemplate) {
  return nostr.signEvent(event);
}

export function getNativeDaemonRelayUrl(): string | null {
  return getRuntimeHtreeServerUrl() ? getRuntimeNostrRelays([])[0] ?? null : null;
}

export function getEffectiveNostrRelayUrls(relays: string[]): string[] {
  return [...new Set(getRuntimeNostrRelays(relays).map(url => url.trim().replace(/\/+$/, '')))];
}

export function getNostrRelayUrls(): string[] {
  return getEffectiveNostrRelayUrls(settingsStore.getState().network.relays);
}

export async function configureNostrRelays(relays: string[], timeoutMs = 5000): Promise<void> {
  const { waitForWorkerAdapter } = await import('../lib/workerInit');
  const adapter = await waitForWorkerAdapter(timeoutMs);
  if (adapter) await adapter.setRelays(getEffectiveNostrRelayUrls(relays));
}

if (typeof window !== 'undefined') {
  (window as Window & { __nostr?: AppNostrClient }).__nostr = nostr;
}
