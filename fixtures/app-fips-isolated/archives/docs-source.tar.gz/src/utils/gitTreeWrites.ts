import { LinkType, type CID } from '@hashtree/core';
import { getTree } from '../store';

export async function checkoutCommit(
  rootCid: CID,
  commitSha: string,
  onProgress?: (file: string) => void
): Promise<CID> {
  const tree = getTree();

  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    throw new Error('Not a git repository');
  }

  const { checkoutWasm } = await import('./wasmGit');
  const { files, gitFiles } = await checkoutWasm(rootCid, commitSha, onProgress);

  const dirMap = new Map<string, Array<{ name: string; cid: CID; size: number; type: LinkType }>>();
  dirMap.set('', []);

  for (const file of files) {
    if (file.isDir) {
      dirMap.set(file.name, []);
    }
  }

  for (const file of files) {
    if (!file.isDir) {
      const { cid, size } = await tree.putFile(file.data);
      const parentDir = file.name.includes('/') ? file.name.substring(0, file.name.lastIndexOf('/')) : '';
      const fileName = file.name.includes('/') ? file.name.substring(file.name.lastIndexOf('/') + 1) : file.name;

      const entries = dirMap.get(parentDir);
      if (entries) {
        entries.push({ name: fileName, cid, size, type: LinkType.Blob });
      }
    }
  }

  const sortedDirs = Array.from(dirMap.keys()).sort((a, b) => b.split('/').length - a.split('/').length);

  for (const dirPath of sortedDirs) {
    if (dirPath === '') continue;

    const entries = dirMap.get(dirPath) || [];
    const { cid } = await tree.putDirectory(entries);

    const parentDir = dirPath.includes('/') ? dirPath.substring(0, dirPath.lastIndexOf('/')) : '';
    const dirName = dirPath.includes('/') ? dirPath.substring(dirPath.lastIndexOf('/') + 1) : dirPath;

    const parentEntries = dirMap.get(parentDir);
    if (parentEntries) {
      parentEntries.push({ name: dirName, cid, size: 0, type: LinkType.Dir });
    }
  }

  const rootEntries = dirMap.get('') || [];
  const gitDirMap = new Map<string, Array<{ name: string; cid: CID; size: number; type: LinkType }>>();
  gitDirMap.set('.git', []);

  for (const file of gitFiles) {
    if (file.isDir && file.name.startsWith('.git/')) {
      gitDirMap.set(file.name, []);
    }
  }

  for (const file of gitFiles) {
    if (!file.isDir && file.name.startsWith('.git/')) {
      const { cid, size } = await tree.putFile(file.data);
      const parentDir = file.name.substring(0, file.name.lastIndexOf('/'));
      const fileName = file.name.substring(file.name.lastIndexOf('/') + 1);

      const parentEntries = gitDirMap.get(parentDir);
      if (parentEntries) {
        parentEntries.push({ name: fileName, cid, size, type: LinkType.Blob });
      }
    }
  }

  const sortedGitDirs = Array.from(gitDirMap.keys())
    .filter(d => d !== '.git')
    .sort((a, b) => b.split('/').length - a.split('/').length);

  for (const dirPathName of sortedGitDirs) {
    const dirEntries = gitDirMap.get(dirPathName) || [];
    const { cid } = await tree.putDirectory(dirEntries);

    const parentDir = dirPathName.substring(0, dirPathName.lastIndexOf('/'));
    const dirName = dirPathName.substring(dirPathName.lastIndexOf('/') + 1);

    const parentEntries = gitDirMap.get(parentDir);
    if (parentEntries) {
      parentEntries.push({ name: dirName, cid, size: 0, type: LinkType.Dir });
    }
  }

  const gitEntries = gitDirMap.get('.git') || [];
  const { cid: gitCid } = await tree.putDirectory(gitEntries);
  rootEntries.push({ name: '.git', cid: gitCid, size: 0, type: LinkType.Dir });

  const { cid: finalCid } = await tree.putDirectory(rootEntries);
  return finalCid;
}

export async function applyGitChanges(
  rootCid: CID,
  gitFiles: Array<{ name: string; data: Uint8Array; isDir: boolean }>
): Promise<CID> {
  const tree = getTree();
  const dirMap = new Map<string, Array<{ name: string; cid: CID; size: number; type: LinkType }>>();
  dirMap.set('.git', []);

  const sortedDirs = gitFiles
    .filter(f => f.isDir)
    .sort((a, b) => a.name.split('/').length - b.name.split('/').length);

  for (const dir of sortedDirs) {
    dirMap.set(dir.name, []);
  }

  for (const file of gitFiles) {
    if (file.isDir) continue;

    const { cid, size } = await tree.putFile(file.data);
    const parentDir = file.name.includes('/') ? file.name.substring(0, file.name.lastIndexOf('/')) : '.git';
    const fileName = file.name.includes('/') ? file.name.substring(file.name.lastIndexOf('/') + 1) : file.name;

    const entries = dirMap.get(parentDir);
    if (entries) {
      entries.push({ name: fileName, cid, size, type: LinkType.Blob });
    }
  }

  const sortedDirKeys = Array.from(dirMap.keys()).sort((a, b) => b.split('/').length - a.split('/').length);

  for (const dirPath of sortedDirKeys) {
    if (dirPath === '.git') continue;

    const entries = dirMap.get(dirPath) || [];
    const { cid } = await tree.putDirectory(entries);

    const parentDir = dirPath.includes('/') ? dirPath.substring(0, dirPath.lastIndexOf('/')) : '.git';
    const dirName = dirPath.includes('/') ? dirPath.substring(dirPath.lastIndexOf('/') + 1) : dirPath;

    const parentEntries = dirMap.get(parentDir);
    if (parentEntries) {
      parentEntries.push({ name: dirName, cid, size: 0, type: LinkType.Dir });
    }
  }

  const gitRootEntries = dirMap.get('.git') || [];
  const { cid: newGitCid } = await tree.putDirectory(gitRootEntries);
  return tree.setEntry(rootCid, [], '.git', newGitCid, 0, LinkType.Dir);
}
