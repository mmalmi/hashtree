/**
 * Route parsing utilities
 * Parses URL hash to extract route info without needing React Router context
 */
import { getQueryParamsFromHash } from '../lib/router.svelte';
import { isNHash, isNPath, nhashDecode, npathDecode, type CID } from '@hashtree/core';
import { nip19 } from 'nostr-tools';

export interface RouteInfo {
  npub: string | null;
  treeName: string | null;
  /** CID for permalink routes (hash + optional decrypt key) */
  cid: CID | null;
  path: string[];
  /** True when viewing a permalink (nhash route) */
  isPermalink: boolean;
  /** All query params from URL - use params.get('k'), params.get('t'), etc. */
  params: URLSearchParams;
  /** Branches to compare (from ?compare=base...head or ?merge=1&base=&head=) */
  compareBranches: { base: string; head: string } | null;
}

function safeDecodeURIComponent(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

const SPECIAL_ROUTES = new Set(['settings', 'wallet', 'users']);
const USER_ROUTES = new Set(['profile', 'follows', 'followers', 'edit']);

/**
 * Parse route info from window.location.hash
 * Handles:
 * - #/npub/treeName/path/to/file
 * - #/nhash1.../path/to/file
 * - #/npub (user view)
 * - #/npub/profile
 */
export function parseRouteFromHash(hash: string): RouteInfo {
  const [path] = hash.replace(/^#\/?/, '').split('?');
  const parts = path.split('/').filter(Boolean).map(safeDecodeURIComponent);
  const params = getQueryParamsFromHash(hash);
  let compareBranches: { base: string; head: string } | null = null;
  const compare = params.get('compare');
  const mergeBase = params.get('base');
  const mergeHead = params.get('head');
  const isMergeView = params.get('merge') === '1';
  if (compare?.includes('...')) {
    const [base, head] = compare.split('...');
    if (base && head) compareBranches = { base, head };
  } else if (isMergeView && mergeBase && mergeHead) {
    compareBranches = { base: mergeBase, head: mergeHead };
  }

  const emptyParams = new URLSearchParams();

  if (parts[0] && isNHash(parts[0])) {
    try {
      const cid = nhashDecode(parts[0]);
      return { npub: null, treeName: null, cid, path: parts.slice(1), isPermalink: true, params, compareBranches };
    } catch {
      // Invalid nhash, fall through.
    }
  }

  if (parts[0] && isNPath(parts[0])) {
    try {
      const decoded = npathDecode(parts[0]);
      return {
        npub: nip19.npubEncode(decoded.pubkey),
        treeName: decoded.treeName,
        cid: null,
        path: decoded.path || [],
        isPermalink: false,
        params,
        compareBranches,
      };
    } catch {
      // Invalid npath, fall through.
    }
  }

  if (SPECIAL_ROUTES.has(parts[0] ?? '')) {
    return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams, compareBranches: null };
  }

  if (parts[0]?.startsWith('npub')) {
    const npub = parts[0];
    if (USER_ROUTES.has(parts[1] ?? '')) {
      return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams, compareBranches: null };
    }
    if (parts[1]) {
      return { npub, treeName: parts[1], cid: null, path: parts.slice(2), isPermalink: false, params, compareBranches };
    }
    return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams, compareBranches: null };
  }

  return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams, compareBranches: null };
}

export function parseRoute(): RouteInfo {
  return parseRouteFromHash(window.location.hash);
}
