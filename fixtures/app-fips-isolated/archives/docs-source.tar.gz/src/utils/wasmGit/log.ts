/**
 * Git log and history operations.
 * Public barrel kept stable while the implementation lives in focused modules.
 */
export type { CommitInfo, CommitDetails, CommitTreeEntry, DiffEntry } from './logTypes';
export { getHead } from './logHead';
export {
  resolveRevisionToCommit,
  getCommitInfo,
  getRootCommit,
  getLog,
  getCommitCount,
  getCommitCountFast,
} from './logHistory';
export { getLogWasm, getFileLastCommitsWasm } from './logWasm';
export { getFileLastCommits } from './logFileHistory';
export {
  getCommitDiffEntries,
  getDiff,
  getFileAtCommit,
  getCommitTreeEntries,
} from './logDiff';
