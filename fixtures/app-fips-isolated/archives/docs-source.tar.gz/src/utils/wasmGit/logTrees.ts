import type { CID } from '@hashtree/core';
import { getTree } from '../../store';
import { readGitObject } from './logPacks';

export function parseGitTree(content: Uint8Array): Array<{ mode: string; name: string; hash: string }> {
  const entries: Array<{ mode: string; name: string; hash: string }> = [];
  let pos = 0;

  while (pos < content.length) {
    // Find space (separates mode from name)
    let spacePos = pos;
    while (spacePos < content.length && content[spacePos] !== 0x20) spacePos++;
    const mode = new TextDecoder().decode(content.slice(pos, spacePos));

    // Find null (separates name from hash)
    let nullPos = spacePos + 1;
    while (nullPos < content.length && content[nullPos] !== 0) nullPos++;
    const name = new TextDecoder().decode(content.slice(spacePos + 1, nullPos));

    // Hash is 20 bytes after null
    const hashBytes = content.slice(nullPos + 1, nullPos + 21);
    const hash = Array.from(hashBytes).map(b => b.toString(16).padStart(2, '0')).join('');

    entries.push({ mode, name, hash });
    pos = nullPos + 21;
  }

  return entries;
}

// Tree objects are immutable, so cache parsed entry maps by tree SHA.
const treeEntriesCache = new Map<string, Map<string, { hash: string; mode: string }>>();
const treeEntriesPendingCache = new Map<string, Promise<Map<string, { hash: string; mode: string }>>>();

// Cache for individual path lookups in a tree
const treePathCache = new Map<string, Map<string, { hash: string; mode: string } | 'dir' | null>>();

export async function getTreeEntriesMap(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string
): Promise<Map<string, { hash: string; mode: string }>> {
  const cached = treeEntriesCache.get(treeSha);
  if (cached) {
    return cached;
  }

  const pending = treeEntriesPendingCache.get(treeSha);
  if (pending) {
    return pending;
  }

  const loadPromise = (async () => {
    const obj = await readGitObject(tree, gitDirCid, treeSha);
    if (!obj || obj.type !== 'tree') {
      const empty = new Map<string, { hash: string; mode: string }>();
      treeEntriesCache.set(treeSha, empty);
      return empty;
    }

    const entries = new Map<string, { hash: string; mode: string }>();
    for (const entry of parseGitTree(obj.content)) {
      entries.set(entry.name, { hash: entry.hash, mode: entry.mode });
    }
    treeEntriesCache.set(treeSha, entries);
    return entries;
  })();

  treeEntriesPendingCache.set(treeSha, loadPromise);

  try {
    return await loadPromise;
  } finally {
    treeEntriesPendingCache.delete(treeSha);
  }
}

/**
 * Get a specific entry from a git tree by path (much faster than walking entire tree)
 */
export async function getTreeEntryAtPath(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  path: string
): Promise<{ hash: string; mode: string } | 'dir' | null> {
  const pathCache = treePathCache.get(treeSha) || new Map();

  if (pathCache.has(path)) {
    return pathCache.get(path)!;
  }

  const parts = path.split('/');
  let currentSha = treeSha;

  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    const entries = await getTreeEntriesMap(tree, gitDirCid, currentSha);
    if (entries.size === 0) {
      pathCache.set(path, null);
      treePathCache.set(treeSha, pathCache);
      return null;
    }

    const entry = entries.get(part);
    if (!entry) {
      pathCache.set(path, null);
      treePathCache.set(treeSha, pathCache);
      return null;
    }

    if (i === parts.length - 1) {
      // Found the target
      const result = entry.mode === '40000' ? 'dir' : { hash: entry.hash, mode: entry.mode };
      pathCache.set(path, result);
      treePathCache.set(treeSha, pathCache);
      return result;
    }

    // Must be a directory to continue
    if (entry.mode !== '40000') {
      pathCache.set(path, null);
      treePathCache.set(treeSha, pathCache);
      return null;
    }
    currentSha = entry.hash;
  }

  pathCache.set(path, null);
  treePathCache.set(treeSha, pathCache);
  return null;
}

/**
 * Get the tree SHA for a subtree at a given path
 */
export async function getSubtreeSha(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  path: string
): Promise<string | null> {
  if (!path) return treeSha;

  const parts = path.split('/');
  let currentSha = treeSha;

  for (const part of parts) {
    const entries = await getTreeEntriesMap(tree, gitDirCid, currentSha);
    const entry = entries.get(part);
    if (!entry || entry.mode !== '40000') return null;
    currentSha = entry.hash;
  }

  return currentSha;
}

/**
 * Get last commit info for each file/directory by tracing through commit history
 * Native implementation - no wasm-git needed
 * Uses path-based lookups to avoid walking entire trees (O(depth) vs O(files) per path)
 */
