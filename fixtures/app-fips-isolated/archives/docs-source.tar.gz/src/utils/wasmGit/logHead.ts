import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { getTree } from '../../store';
import { collectLooseRefs, isFullSha, readPackedRefs, readRefSha } from './refs';

export async function getHead(
  rootCid: CID
): Promise<string | null> {
  const tree = getTree();

  // Check for .git directory
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  const fallbackHead = async (): Promise<string | null> => {
    const preferredBranches = ['main', 'master'];
    for (const branch of preferredBranches) {
      const sha = await readRefSha(tree, gitDirResult.cid, `refs/heads/${branch}`);
      if (sha) {
        return sha;
      }
    }

    const looseHeads = await collectLooseRefs(tree, gitDirResult.cid, 'refs/heads');
    for (const name of Array.from(looseHeads.keys()).sort()) {
      const sha = looseHeads.get(name);
      if (sha) {
        return sha;
      }
    }

    const packedRefs = await readPackedRefs(tree, gitDirResult.cid);
    for (const ref of ['refs/heads/main', 'refs/heads/master']) {
      const entry = packedRefs.get(ref);
      if (entry?.sha) {
        return entry.sha;
      }
    }
    for (const [ref, entry] of packedRefs.entries()) {
      if (ref.startsWith('refs/heads/') && entry.sha) {
        return entry.sha;
      }
    }

    return null;
  };

  try {
    // Read HEAD file
    const headResult = await tree.resolvePath(gitDirResult.cid, 'HEAD');
    if (!headResult || headResult.type === LinkType.Dir) {
      return await fallbackHead();
    }

    const headData = await tree.readFile(headResult.cid);
    if (!headData) {
      return await fallbackHead();
    }

    const headContent = new TextDecoder().decode(headData).trim();

    // Check if HEAD is a direct SHA (detached)
    if (isFullSha(headContent)) {
      return headContent.toLowerCase();
    }

    // HEAD is a ref like "ref: refs/heads/master"
    const refMatch = headContent.match(/^ref: (.+)$/);
    if (!refMatch) {
      return await fallbackHead();
    }

    // Resolve the ref to get commit SHA
    const refPath = refMatch[1]; // e.g., "refs/heads/master"
    const sha = await readRefSha(tree, gitDirResult.cid, refPath);
    if (sha) {
      return sha;
    }

    const packedRefs = await readPackedRefs(tree, gitDirResult.cid);
    const packedSha = packedRefs.get(refPath)?.sha ?? null;
    if (packedSha) {
      return packedSha;
    }

    return await fallbackHead();
  } catch (err) {
    console.error('[git] getHead failed:', err);
    return await fallbackHead();
  }
}
