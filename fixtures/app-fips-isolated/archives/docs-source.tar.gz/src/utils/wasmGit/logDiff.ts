import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { getTree } from '../../store';
import { getCommitInfo, resolveRevisionToCommit } from './logHistory';
import { getParsedCommitFromSha } from './logObjects';
import { readGitObject } from './logPacks';
import { getTreeEntriesMap, getTreeEntryAtPath, parseGitTree } from './logTrees';
import type { CommitTreeEntry, DiffEntry } from './logTypes';

async function collectTreeFiles(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  prefix: string,
  status: 'added' | 'deleted',
  result: DiffEntry[]
): Promise<void> {
  const entries = await getTreeEntriesMap(tree, gitDirCid, treeSha);
  const names = Array.from(entries.keys()).sort();

  for (const name of names) {
    const entry = entries.get(name)!;
    const path = prefix ? `${prefix}/${name}` : name;

    if (entry.mode === '40000') {
      await collectTreeFiles(tree, gitDirCid, entry.hash, path, status, result);
      continue;
    }

    if (status === 'added') {
      result.push({ path, status, newHash: entry.hash });
    } else {
      result.push({ path, status, oldHash: entry.hash });
    }
  }
}

async function diffTreeObjects(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  fromTreeSha: string,
  toTreeSha: string,
  prefix: string,
  result: DiffEntry[]
): Promise<void> {
  if (fromTreeSha === toTreeSha) {
    return;
  }

  const [fromEntries, toEntries] = await Promise.all([
    getTreeEntriesMap(tree, gitDirCid, fromTreeSha),
    getTreeEntriesMap(tree, gitDirCid, toTreeSha),
  ]);

  const names = Array.from(new Set([...fromEntries.keys(), ...toEntries.keys()])).sort();

  for (const name of names) {
    const fromEntry = fromEntries.get(name);
    const toEntry = toEntries.get(name);
    const path = prefix ? `${prefix}/${name}` : name;

    if (!fromEntry && toEntry) {
      if (toEntry.mode === '40000') {
        await collectTreeFiles(tree, gitDirCid, toEntry.hash, path, 'added', result);
      } else {
        result.push({ path, status: 'added', newHash: toEntry.hash });
      }
      continue;
    }

    if (fromEntry && !toEntry) {
      if (fromEntry.mode === '40000') {
        await collectTreeFiles(tree, gitDirCid, fromEntry.hash, path, 'deleted', result);
      } else {
        result.push({ path, status: 'deleted', oldHash: fromEntry.hash });
      }
      continue;
    }

    if (!fromEntry || !toEntry) {
      continue;
    }

    if (fromEntry.hash === toEntry.hash && fromEntry.mode === toEntry.mode) {
      continue;
    }

    if (fromEntry.mode === '40000' && toEntry.mode === '40000') {
      await diffTreeObjects(tree, gitDirCid, fromEntry.hash, toEntry.hash, path, result);
      continue;
    }

    if (fromEntry.mode === '40000') {
      await collectTreeFiles(tree, gitDirCid, fromEntry.hash, path, 'deleted', result);
      result.push({ path, status: 'added', newHash: toEntry.hash });
      continue;
    }

    if (toEntry.mode === '40000') {
      result.push({ path, status: 'deleted', oldHash: fromEntry.hash });
      await collectTreeFiles(tree, gitDirCid, toEntry.hash, path, 'added', result);
      continue;
    }

    result.push({
      path,
      status: 'modified',
      oldHash: fromEntry.hash,
      newHash: toEntry.hash,
    });
  }
}

export async function getCommitDiffEntries(rootCid: CID, ref: string): Promise<DiffEntry[]> {
  const htree = getTree();
  const result: DiffEntry[] = [];

  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return result;
  }

  const commit = await getCommitInfo(rootCid, ref);
  if (!commit) {
    return result;
  }

  if (!commit.parent[0]) {
    await collectTreeFiles(htree, gitDirResult.cid, commit.tree, '', 'added', result);
    result.sort((a, b) => a.path.localeCompare(b.path));
    return result;
  }

  return await getDiff(rootCid, commit.parent[0], commit.oid);
}

/**
 * Get diff between two commits
 * Native implementation - no wasm-git needed
 */
export async function getDiff(
  rootCid: CID,
  fromCommit: string,
  toCommit: string
): Promise<DiffEntry[]> {
  const htree = getTree();
  const startTime = performance.now();
  const result: DiffEntry[] = [];

  // Check for .git directory
  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return result;
  }

  try {
    const [fromSha, toSha] = await Promise.all([
      resolveRevisionToCommit(rootCid, fromCommit),
      resolveRevisionToCommit(rootCid, toCommit),
    ]);
    if (!fromSha || !toSha) return result;

    const [fromParsed, toParsed] = await Promise.all([
      getParsedCommitFromSha(htree, gitDirResult.cid, fromSha),
      getParsedCommitFromSha(htree, gitDirResult.cid, toSha),
    ]);
    if (!fromParsed || !toParsed) return result;

    await diffTreeObjects(htree, gitDirResult.cid, fromParsed.tree, toParsed.tree, '', result);

    // Sort by path for consistent output
    result.sort((a, b) => a.path.localeCompare(b.path));

    const elapsed = performance.now() - startTime;
    if (elapsed >= 50) {
      console.log(`[git perf] getDiff completed in ${elapsed.toFixed(0)} ms (files=${result.length})`);
    }

    return result;
  } catch (err) {
    console.error('[git] getDiff failed:', err);
    return result;
  }
}

/**
 * Get file content at a specific commit
 * Native implementation - no wasm-git needed
 */
export async function getFileAtCommit(
  rootCid: CID,
  commitSha: string,
  filePath: string
): Promise<Uint8Array | null> {
  const htree = getTree();

  // Check for .git directory
  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  try {
    const resolvedSha = await resolveRevisionToCommit(rootCid, commitSha);
    if (!resolvedSha) return null;

    const commit = await getParsedCommitFromSha(htree, gitDirResult.cid, resolvedSha);
    if (!commit) return null;

    const entry = await getTreeEntryAtPath(htree, gitDirResult.cid, commit.tree, filePath);
    if (!entry || entry === 'dir') return null;

    const blobObj = await readGitObject(htree, gitDirResult.cid, entry.hash);
    if (!blobObj || blobObj.type !== 'blob') return null;
    return blobObj.content;
  } catch (err) {
    console.error('[git] getFileAtCommit failed:', err);
    return null;
  }
}

function isTreeMode(mode: string): boolean {
  return mode === '40000' || mode === '040000';
}

async function collectCommitTreeEntries(
  htree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  treeSha: string,
  prefix: string,
  entries: CommitTreeEntry[]
): Promise<void> {
  const treeObj = await readGitObject(htree, gitDirCid, treeSha);
  if (!treeObj || treeObj.type !== 'tree') return;

  for (const entry of parseGitTree(treeObj.content)) {
    const entryPath = prefix ? `${prefix}/${entry.name}` : entry.name;

    if (isTreeMode(entry.mode)) {
      entries.push({ name: entryPath, data: new Uint8Array(0), isDir: true });
      await collectCommitTreeEntries(htree, gitDirCid, entry.hash, entryPath, entries);
      continue;
    }

    const blobObj = await readGitObject(htree, gitDirCid, entry.hash);
    if (!blobObj || blobObj.type !== 'blob') continue;
    entries.push({ name: entryPath, data: blobObj.content, isDir: false });
  }
}

export async function getCommitTreeEntries(rootCid: CID, ref: string): Promise<CommitTreeEntry[]> {
  const htree = getTree();

  const gitDirResult = await htree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return [];
  }

  const resolvedSha = await resolveRevisionToCommit(rootCid, ref);
  if (!resolvedSha) return [];

  const commit = await getParsedCommitFromSha(htree, gitDirResult.cid, resolvedSha);
  if (!commit) return [];

  const entries: CommitTreeEntry[] = [];
  await collectCommitTreeEntries(htree, gitDirResult.cid, commit.tree, '', entries);
  return entries;
}
