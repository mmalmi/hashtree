import type { CID } from '@hashtree/core';
import { LinkType, toHex } from '@hashtree/core';
import { getTree } from '../../store';
import type { GitObject } from './logTypes';

async function decompressZlib(data: Uint8Array): Promise<Uint8Array> {
  const ds = new DecompressionStream('deflate');
  const writer = ds.writable.getWriter();
  writer.write(data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer);
  writer.close();

  const chunks: Uint8Array[] = [];
  const reader = ds.readable.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }

  const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}

export function gitDirCacheKey(gitDirCid: CID): string {
  return gitDirCid.key ? `${toHex(gitDirCid.hash)}:${toHex(gitDirCid.key)}` : toHex(gitDirCid.hash);
}

interface PackIndexData {
  shas: string[];
  offsets: number[];
  sortedOffsets: number[];
  shaToOffset: Map<string, number>;
}

// Cache for pack indexes and pack data per git dir CID
const packIndexCache = new Map<string, Map<string, PackIndexData>>();
const packDataCache = new Map<string, Map<string, Uint8Array>>();
const gitObjectCache = new Map<string, Map<string, Promise<GitObject | null>>>();

/**
 * Load pack index file (.idx) and return the SHA -> offset mapping
 */
export async function loadPackIndex(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  idxName: string
): Promise<PackIndexData | null> {
  // Check cache first
  const cacheKey = gitDirCacheKey(gitDirCid);
  let dirCache = packIndexCache.get(cacheKey);
  if (dirCache?.has(idxName)) {
    return dirCache.get(idxName)!;
  }
  try {
    const idxResult = await tree.resolvePath(gitDirCid, `objects/pack/${idxName}`);
    if (!idxResult || idxResult.type === LinkType.Dir) {
      return null;
    }

    const idxData = await tree.readFile(idxResult.cid);
    if (!idxData) return null;

    const view = new DataView(idxData.buffer, idxData.byteOffset, idxData.byteLength);

    // Check magic number (0xff744f63 for v2)
    if (view.getUint32(0) !== 0xff744f63) {
      return null;
    }

    // Version should be 2
    if (view.getUint32(4) !== 2) {
      return null;
    }

    // Total object count is the last entry in the fanout table.
    const numObjects = view.getUint32(8 + 255 * 4);

    // SHA table starts after fanout (offset 8 + 256*4 = 1032)
    const shaOffset = 8 + 256 * 4;
    const shas: string[] = [];
    for (let i = 0; i < numObjects; i++) {
      const sha = Array.from(idxData.slice(shaOffset + i * 20, shaOffset + (i + 1) * 20))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
      shas.push(sha);
    }

    // CRC table (skip it) - numObjects * 4 bytes
    const crcOffset = shaOffset + numObjects * 20;

    // Offset table starts after CRC
    const offsetOffset = crcOffset + numObjects * 4;
    const offsets: number[] = [];
    const largeOffsetEntries: Array<{ index: number; largeIndex: number }> = [];
    for (let i = 0; i < numObjects; i++) {
      const rawOffset = view.getUint32(offsetOffset + i * 4);
      if (rawOffset & 0x80000000) {
        offsets.push(0);
        largeOffsetEntries.push({ index: i, largeIndex: rawOffset & 0x7fffffff });
      } else {
        offsets.push(rawOffset);
      }
    }

    if (largeOffsetEntries.length > 0) {
      const largeOffsetTableOffset = offsetOffset + numObjects * 4;
      for (const { index, largeIndex } of largeOffsetEntries) {
        const entryOffset = largeOffsetTableOffset + largeIndex * 8;
        if (entryOffset + 8 > idxData.byteLength) {
          return null;
        }
        const high = view.getUint32(entryOffset);
        const low = view.getUint32(entryOffset + 4);
        const fullOffset = (BigInt(high) << 32n) | BigInt(low);
        if (fullOffset > BigInt(Number.MAX_SAFE_INTEGER)) {
          return null;
        }
        offsets[index] = Number(fullOffset);
      }
    }

    // Build SHA -> offset map for fast lookups
    const shaToOffset = new Map<string, number>();
    for (let i = 0; i < shas.length; i++) {
      shaToOffset.set(shas[i], offsets[i]);
    }

    const sortedOffsets = [...offsets].sort((a, b) => a - b);

    // Cache the result
    if (!dirCache) {
      dirCache = new Map();
      packIndexCache.set(cacheKey, dirCache);
    }
    dirCache.set(idxName, { shas, offsets, sortedOffsets, shaToOffset });

    return { shas, offsets, sortedOffsets, shaToOffset };
  } catch {
    return null;
  }
}

/**
 * Load pack file data with caching
 */
export async function loadPackData(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string
): Promise<Uint8Array | null> {
  const cacheKey = gitDirCacheKey(gitDirCid);
  let dirCache = packDataCache.get(cacheKey);
  if (dirCache?.has(packName)) {
    return dirCache.get(packName)!;
  }

  const packResult = await tree.resolvePath(gitDirCid, `objects/pack/${packName}`);
  if (!packResult || packResult.type === LinkType.Dir) return null;

  const packData = await tree.readFile(packResult.cid);
  if (!packData) return null;

  // Cache the result
  if (!dirCache) {
    dirCache = new Map();
    packDataCache.set(cacheKey, dirCache);
  }
  dirCache.set(packName, packData);

  return packData;
}

// Cache for pack directory listings
const packDirCache = new Map<string, string[]>();

/**
 * Find object in pack files
 */
async function findInPack(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<{ packName: string; offset: number } | null> {
  const cacheKey = gitDirCacheKey(gitDirCid);

  // Get cached list of idx files or load it
  let idxFileNames = packDirCache.get(cacheKey);
  if (!idxFileNames) {
    const packDirResult = await tree.resolvePath(gitDirCid, 'objects/pack');
    if (!packDirResult || packDirResult.type !== LinkType.Dir) {
      return null;
    }
    const entries = await tree.listDirectory(packDirResult.cid);
    idxFileNames = entries.filter(e => e.name.endsWith('.idx')).map(e => e.name);
    packDirCache.set(cacheKey, idxFileNames);
  }

  for (const idxName of idxFileNames) {
    const idx = await loadPackIndex(tree, gitDirCid, idxName);
    if (!idx) continue;

    // Use the shaToOffset map for O(1) lookup instead of O(n) indexOf
    const offset = idx.shaToOffset.get(sha);
    if (offset !== undefined) {
      const packName = idxName.replace('.idx', '.pack');
      return { packName, offset };
    }
  }

  return null;
}

/**
 * Apply git delta instructions to a base object
 */
function applyDelta(base: Uint8Array, delta: Uint8Array): Uint8Array {
  let pos = 0;

  // Skip base size (variable length encoded, not needed for our purposes)
  let shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  // Read result size (variable length)
  let resultSize = 0;
  shift = 0;
  while (pos < delta.length) {
    const byte = delta[pos++];
    resultSize |= (byte & 0x7f) << shift;
    shift += 7;
    if (!(byte & 0x80)) break;
  }

  const result = new Uint8Array(resultSize);
  let resultPos = 0;

  while (pos < delta.length && resultPos < resultSize) {
    const cmd = delta[pos++];

    if (cmd & 0x80) {
      // Copy from base
      let copyOffset = 0;
      let copySize = 0;

      if (cmd & 0x01) copyOffset = delta[pos++];
      if (cmd & 0x02) copyOffset |= delta[pos++] << 8;
      if (cmd & 0x04) copyOffset |= delta[pos++] << 16;
      if (cmd & 0x08) copyOffset |= delta[pos++] << 24;

      if (cmd & 0x10) copySize = delta[pos++];
      if (cmd & 0x20) copySize |= delta[pos++] << 8;
      if (cmd & 0x40) copySize |= delta[pos++] << 16;

      if (copySize === 0) copySize = 0x10000;

      result.set(base.subarray(copyOffset, copyOffset + copySize), resultPos);
      resultPos += copySize;
    } else if (cmd > 0) {
      // Insert new data
      result.set(delta.subarray(pos, pos + cmd), resultPos);
      pos += cmd;
      resultPos += cmd;
    }
  }

  return result;
}

/**
 * Read object from pack file at given offset (with delta resolution)
 */
async function readFromPack(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string,
  offset: number,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  // Prevent infinite recursion
  if (depth > 50) return null;

  try {
    const packData = await loadPackData(tree, gitDirCid, packName);
    if (!packData) return null;
    const idx = await loadPackIndex(tree, gitDirCid, packName.replace('.pack', '.idx'));
    if (!idx) return null;
    return await readPackObjectAtOffset(packData, offset, idx, tree, gitDirCid, packName, depth);
  } catch {
    return null;
  }
}

function getPackObjectEnd(packData: Uint8Array, sortedOffsets: number[], offset: number): number {
  const packTrailerLength = 20;
  const packEnd = Math.max(12, packData.length - packTrailerLength);

  let lo = 0;
  let hi = sortedOffsets.length;

  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (sortedOffsets[mid] <= offset) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }

  return lo < sortedOffsets.length ? Math.min(sortedOffsets[lo], packEnd) : packEnd;
}

async function readPackObjectAtOffset(
  packData: Uint8Array,
  offset: number,
  idx: PackIndexData,
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  packName: string,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  if (depth > 50) return null;

  let pos = offset;
  let byte = packData[pos++];
  const type = (byte >> 4) & 7;
  let size = byte & 15;
  let shift = 4;

  while (byte & 0x80) {
    byte = packData[pos++];
    size |= (byte & 0x7f) << shift;
    shift += 7;
  }

  const typeNames = ['', 'commit', 'tree', 'blob', 'tag', '', 'ofs_delta', 'ref_delta'];
  const objectEnd = getPackObjectEnd(packData, idx.sortedOffsets, offset);

  if (objectEnd <= pos) {
    return null;
  }

  if (type === 6) {
    let negOffset = 0;
    byte = packData[pos++];
    negOffset = byte & 0x7f;
    while (byte & 0x80) {
      byte = packData[pos++];
      negOffset = ((negOffset + 1) << 7) | (byte & 0x7f);
    }
    const baseOffset = offset - negOffset;

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);
    const baseObj = await readPackObjectAtOffset(packData, baseOffset, idx, tree, gitDirCid, packName, depth + 1);
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  if (type === 7) {
    const baseShaBytes = packData.subarray(pos, pos + 20);
    pos += 20;
    const baseSha = Array.from(baseShaBytes).map(b => b.toString(16).padStart(2, '0')).join('');

    const compressedDelta = packData.subarray(pos, objectEnd);
    const deltaData = await decompressZlib(compressedDelta);

    const baseOffset = idx.shaToOffset.get(baseSha);
    let baseObj: { type: string; content: Uint8Array } | null = null;
    if (baseOffset !== undefined) {
      baseObj = await readPackObjectAtOffset(packData, baseOffset, idx, tree, gitDirCid, packName, depth + 1);
    } else {
      baseObj = await readGitObject(tree, gitDirCid, baseSha);
    }
    if (!baseObj) return null;

    const content = applyDelta(baseObj.content, deltaData);
    return { type: baseObj.type, content };
  }

  const compressedData = packData.subarray(pos, objectEnd);
  const decompressed = await decompressZlib(compressedData);
  return { type: typeNames[type], content: decompressed.slice(0, size) };
}

/**
 * Read and parse a git object from hashtree (loose or packed)
 * Internal version with depth tracking for delta resolution
 */
export async function readGitObjectInternal(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string,
  depth = 0
): Promise<{ type: string; content: Uint8Array } | null> {
  // Prevent infinite recursion
  if (depth > 50) return null;

  // Try loose object first: .git/objects/<sha[0:2]>/<sha[2:]>
  const objPath = `objects/${sha.slice(0, 2)}/${sha.slice(2)}`;

  try {
    const objResult = await tree.resolvePath(gitDirCid, objPath);
    if (objResult && objResult.type !== LinkType.Dir) {
      const compressedData = await tree.readFile(objResult.cid);
      if (compressedData) {
        // Decompress the object
        const decompressed = await decompressZlib(compressedData);

        // Parse: "<type> <size>\0<content>"
        const nullIndex = decompressed.indexOf(0);
        if (nullIndex !== -1) {
          const header = new TextDecoder().decode(decompressed.slice(0, nullIndex));
          const [type] = header.split(' ');
          const content = decompressed.slice(nullIndex + 1);
          return { type, content };
        }
      }
    }
  } catch {
    // Loose object not found, try pack files
  }

  // Try pack files
  const packInfo = await findInPack(tree, gitDirCid, sha);
  if (packInfo) {
    return readFromPack(tree, gitDirCid, packInfo.packName, packInfo.offset, depth);
  }

  return null;
}

/**
 * Read and parse a git object from hashtree (loose or packed)
 */
export async function readGitObject(
  tree: ReturnType<typeof getTree>,
  gitDirCid: CID,
  sha: string
): Promise<GitObject | null> {
  const cacheKey = gitDirCacheKey(gitDirCid);
  let dirCache = gitObjectCache.get(cacheKey);
  if (!dirCache) {
    dirCache = new Map();
    gitObjectCache.set(cacheKey, dirCache);
  }

  const cached = dirCache.get(sha);
  if (cached) {
    return await cached;
  }

  const pending = readGitObjectInternal(tree, gitDirCid, sha, 0);
  dirCache.set(sha, pending);
  return await pending;
}

/**
 * Parse a git commit object
 */

export function readPackObjectType(packData: Uint8Array, offset: number): number {
  const byte = packData[offset];
  return (byte >> 4) & 7;
}
