export interface CommitInfo {
  oid: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent: string[];
}

export interface GitObject {
  type: string;
  content: Uint8Array;
}

export interface ParsedCommit {
  tree: string;
  parents: string[];
  author: string;
  email: string;
  timestamp: number;
  message: string;
}

export interface ParsedTag {
  object: string;
  type: string;
}

export interface CommitDetails extends CommitInfo {
  tree: string;
}

export interface CommitTreeEntry {
  name: string;
  data: Uint8Array;
  isDir: boolean;
}

export interface DiffEntry {
  path: string;
  status: 'added' | 'deleted' | 'modified';
  oldHash?: string;
  newHash?: string;
}
