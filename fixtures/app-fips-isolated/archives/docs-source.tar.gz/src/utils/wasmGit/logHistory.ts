import type { CID } from '@hashtree/core';
import { LinkType } from '@hashtree/core';
import { getTree } from '../../store';
import { isFullSha } from './refs';
import { getHead } from './logHead';
import {
  getParsedCommitFromSha,
  resolveNamedRefToCommit,
} from './logObjects';
import {
  gitDirCacheKey,
  loadPackData,
  loadPackIndex,
  readGitObject,
  readPackObjectType,
} from './logPacks';
import type { CommitDetails, CommitInfo } from './logTypes';

export async function resolveRevisionToCommit(rootCid: CID, ref: string): Promise<string | null> {
  if (ref === 'HEAD') {
    return await getHead(rootCid);
  }

  if (isFullSha(ref)) {
    return ref.toLowerCase();
  }

  const tree = getTree();
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  const resolvedRef = await resolveNamedRefToCommit(tree, gitDirResult.cid, rootCid, ref);
  if (resolvedRef) {
    return resolvedRef;
  }

  if (/^[0-9a-f]{4,39}$/i.test(ref)) {
    const commits = await getLog(rootCid, { depth: 1000 });
    const match = commits.find((commit) => commit.oid.startsWith(ref.toLowerCase()));
    return match?.oid ?? null;
  }

  return null;
}

export async function getCommitInfo(rootCid: CID, ref: string): Promise<CommitDetails | null> {
  const tree = getTree();

  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  const sha = await resolveRevisionToCommit(rootCid, ref);
  if (!sha) {
    return null;
  }

  const parsed = await getParsedCommitFromSha(tree, gitDirResult.cid, sha);
  if (!parsed) {
    return null;
  }

  return {
    oid: sha,
    message: parsed.message,
    author: parsed.author,
    email: parsed.email,
    timestamp: parsed.timestamp,
    parent: parsed.parents,
    tree: parsed.tree,
  };
}

export async function getRootCommit(rootCid: CID): Promise<string | null> {
  const tree = getTree();
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return null;
  }

  let currentSha = await getHead(rootCid);
  if (!currentSha) {
    return null;
  }

  const visited = new Set<string>();
  while (currentSha && !visited.has(currentSha)) {
    visited.add(currentSha);

    const parsed = await getParsedCommitFromSha(tree, gitDirResult.cid, currentSha);
    if (!parsed) {
      return null;
    }

    if (parsed.parents.length === 0) {
      return currentSha;
    }

    currentSha = parsed.parents[0] || null;
  }

  return null;
}

/**
 * Get commit log by reading git objects directly from hashtree
 * No wasm-git needed - much faster for large repos
 * Uses parallel fetching for better performance
 */
export async function getLog(
  rootCid: CID,
  options?: { depth?: number }
): Promise<CommitInfo[]> {
  const startTime = performance.now();
  const tree = getTree();
  const depth = options?.depth ?? 20;

  // Check for .git directory
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return [];
  }

  try {
    // Get HEAD commit SHA
    const headSha = await getHead(rootCid);
    if (!headSha) {
      return [];
    }

    const commits: CommitInfo[] = [];
    const visited = new Set<string>();
    const queue = [headSha];
    const batchSize = 16;

    while (queue.length > 0 && commits.length < depth) {
      const batch: string[] = [];
      while (batch.length < batchSize && queue.length > 0 && commits.length + batch.length < depth) {
        const sha = queue.shift()!;
        if (!visited.has(sha)) {
          visited.add(sha);
          batch.push(sha);
        }
      }

      if (batch.length === 0) {
        break;
      }

      const parsedBatch = await Promise.all(
        batch.map(async (sha) => {
          const parsed = await getParsedCommitFromSha(tree, gitDirResult.cid, sha);
          return parsed ? { sha, parsed } : null;
        })
      );

      for (const item of parsedBatch) {
        if (!item) continue;

        commits.push({
          oid: item.sha,
          message: item.parsed.message,
          author: item.parsed.author,
          email: item.parsed.email,
          timestamp: item.parsed.timestamp,
          parent: item.parsed.parents,
        });

        for (const parent of item.parsed.parents) {
          if (!visited.has(parent)) {
            queue.push(parent);
          }
        }
      }
    }

    // Sort by timestamp (newest first)
    commits.sort((a, b) => b.timestamp - a.timestamp);

    const elapsed = performance.now() - startTime;
    if (elapsed >= 50) {
      console.log(`[git perf] getLog completed in ${elapsed.toFixed(0)} ms (depth=${depth}, commits=${commits.length})`);
    }

    return commits;
  } catch (err) {
    console.error('[git] getLog failed:', err);
    return [];
  }
}

/**
 * Fast commit count - traverses parent pointers without parsing full commit data
 */
export async function getCommitCount(
  rootCid: CID,
  options?: { maxCount?: number }
): Promise<number> {
  const tree = getTree();
  const maxCount = options?.maxCount ?? 10000;

  // Check for .git directory
  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return 0;
  }

  try {
    const headSha = await getHead(rootCid);
    if (!headSha) {
      return 0;
    }

    const visited = new Set<string>();
    const queue = [headSha];
    const BATCH_SIZE = 50;

    while (queue.length > 0 && visited.size < maxCount) {
      const batch = queue.splice(0, Math.min(BATCH_SIZE, maxCount - visited.size));
      const newShas = batch.filter(sha => !visited.has(sha));

      if (newShas.length === 0) continue;

      for (const sha of newShas) {
        visited.add(sha);
      }

      const results = await Promise.all(
        newShas.map(async (sha) => {
          const obj = await readGitObject(tree, gitDirResult.cid, sha);
          if (!obj || obj.type !== 'commit') return [];
          return extractParentShas(obj.content);
        })
      );

      for (const parents of results) {
        for (const parent of parents) {
          if (!visited.has(parent)) {
            queue.push(parent);
          }
        }
      }
    }

    return visited.size;
  } catch (err) {
    console.error('[git] getCommitCount failed:', err);
    return 0;
  }
}

/**
 * Fast parent SHA extraction - doesn't parse full commit
 */
function extractParentShas(content: Uint8Array): string[] {
  const text = new TextDecoder().decode(content);
  const parents: string[] = [];
  const lines = text.split('\n');

  for (const line of lines) {
    if (line === '') break;
    if (line.startsWith('parent ')) {
      parents.push(line.slice(7));
    }
  }

  return parents;
}

// Cache for commit counts (gitDirCid -> count)
const commitCountCache = new Map<string, number>();

/**
 * FAST commit count
 * - For pack files: scan type bytes directly (no decompression)
 * - For loose objects: walk commit graph from HEAD (only fetches commits, not all objects)
 * - Results are cached per git directory
 */
export async function getCommitCountFast(rootCid: CID): Promise<number> {
  const startTime = performance.now();
  const tree = getTree();

  const gitDirResult = await tree.resolvePath(rootCid, '.git');
  if (!gitDirResult || gitDirResult.type !== LinkType.Dir) {
    return 0;
  }

  // Check cache
  const cacheKey = gitDirCacheKey(gitDirResult.cid);
  if (commitCountCache.has(cacheKey)) {
    const cached = commitCountCache.get(cacheKey)!;
    console.log(`[git perf] getCommitCountFast cache hit: ${cached} commits`);
    return cached;
  }

  let commitCount = 0;
  let hasPackFiles = false;
  let hasLooseObjects = false;

  try {
    const objectsDirResult = await tree.resolvePath(gitDirResult.cid, 'objects');
    if (objectsDirResult && objectsDirResult.type === LinkType.Dir) {
      const objectEntries = await tree.listDirectory(objectsDirResult.cid);
      hasLooseObjects = objectEntries.some(entry =>
        entry.type === LinkType.Dir && entry.name !== 'pack' && entry.name !== 'info'
      );
    }

    // 1. Count commits in pack files (most commits are packed)
    const packDirResult = await tree.resolvePath(gitDirResult.cid, 'objects/pack');
    if (packDirResult && packDirResult.type === LinkType.Dir) {
      const entries = await tree.listDirectory(packDirResult.cid);
      const idxFiles = entries.filter(e => e.name.endsWith('.idx'));

      for (const idxFile of idxFiles) {
        hasPackFiles = true;
        const packName = idxFile.name.replace('.idx', '.pack');

        // Load index to get offsets (uses cache)
        const idx = await loadPackIndex(tree, gitDirResult.cid, idxFile.name);
        if (!idx) continue;

        // Load pack file (uses cache)
        const packData = await loadPackData(tree, gitDirResult.cid, packName);
        if (!packData) continue;

        // Scan through all offsets, reading only type bytes (no decompression!)
        for (const offset of idx.offsets) {
          const type = readPackObjectType(packData, offset);
          if (type === 1) { // 1 = commit
            commitCount++;
          }
        }
      }
    }

    // 2. For loose objects: walk commit graph from HEAD (much faster than scanning all objects)
    if (!hasPackFiles) {
      const headSha = await getHead(rootCid);
      if (headSha) {
        const visited = new Set<string>();
        const queue = [headSha];
        const BATCH_SIZE = 50;

        while (queue.length > 0) {
          const batch = queue.splice(0, Math.min(BATCH_SIZE, queue.length));
          const newShas = batch.filter(sha => !visited.has(sha));

          if (newShas.length === 0) continue;

          for (const sha of newShas) {
            visited.add(sha);
          }

          // Fetch commits in parallel
          const results = await Promise.all(
            newShas.map(async (sha) => {
              const obj = await readGitObject(tree, gitDirResult.cid, sha);
              if (!obj || obj.type !== 'commit') return [];
              return extractParentShas(obj.content);
            })
          );

          for (const parents of results) {
            for (const parent of parents) {
              if (!visited.has(parent)) {
                queue.push(parent);
              }
            }
          }
        }

        commitCount = visited.size;
      }
    } else if (hasLooseObjects || commitCount < 2) {
      // Pack-only counting misses loose commits; fall back to graph traversal when needed.
      commitCount = await getCommitCount(rootCid);
    }

    // Cache the result
    commitCountCache.set(cacheKey, commitCount);
    console.log(`[git perf] getCommitCountFast completed in ${(performance.now() - startTime).toFixed(0)} ms, count: ${commitCount}`);
    return commitCount;
  } catch (err) {
    console.error('[git] getCommitCountFast failed:', err);
    return 0;
  }
}

/**
 * Read object type from pack data at given offset (no decompression)
 * Returns: 1=commit, 2=tree, 3=blob, 4=tag, 6=ofs_delta, 7=ref_delta
 */
