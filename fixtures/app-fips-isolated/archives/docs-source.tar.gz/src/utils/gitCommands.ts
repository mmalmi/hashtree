import type { CID } from '@hashtree/core';
import { toHex } from '@hashtree/core';
import { LRUCache } from './lruCache';

const gitCommandCache = new LRUCache<string, { output: string; error?: string }>(50);
const CACHEABLE_COMMANDS = ['diff', 'diff-tree', 'show', 'log', 'cat-file', 'ls-tree', 'rev-parse'];

export interface RunGitCommandOptions {
  authorName?: string;
  authorEmail?: string;
}

export interface RunGitCommandResult {
  output: string;
  error?: string;
  gitFiles?: Array<{ name: string; data: Uint8Array; isDir: boolean }>;
}

export async function runGitCommand(
  rootCid: CID,
  command: string,
  options?: RunGitCommandOptions
): Promise<RunGitCommandResult> {
  const cmdName = command.trim().split(/\s+/)[0];
  const isCacheable = CACHEABLE_COMMANDS.includes(cmdName);

  if (isCacheable) {
    const cacheKey = `${toHex(rootCid.hash)}:${command}`;
    const cached = gitCommandCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    const { runGitCommand: runGitCommandWasm } = await import('./wasmGit');
    const result = await runGitCommandWasm(rootCid, command, options);

    if (!result.gitFiles) {
      gitCommandCache.set(cacheKey, { output: result.output, error: result.error });
    }

    return result;
  }

  const { runGitCommand: runGitCommandWasm } = await import('./wasmGit');
  return runGitCommandWasm(rootCid, command, options);
}
