import {
  KIND_ISSUE,
  KIND_PULL_REQUEST,
  KIND_TEXT_NOTE,
} from './utils/constants';
import {
  fetchEventsViaSubscribe,
  fetchLatestStatuses,
  getRepoReferenceFromTags,
  getTargetEventIdFromTags,
  parseIssueEvent,
  parsePullRequestEvent,
  type GitProfileActivityItem,
  type Issue,
  type PullRequest,
  type RepoReference,
} from './nip34';
import { npubToPubkey } from './nostr';

export async function fetchProfileGitActivity(npub: string, limit = 20): Promise<GitProfileActivityItem[]> {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) return [];

  const queryLimit = Math.max(limit * 4, 40);
  const [workEvents, commentEvents] = await Promise.all([
    fetchEventsViaSubscribe({ authors: [pubkey], kinds: [KIND_PULL_REQUEST, KIND_ISSUE], limit: queryLimit }),
    fetchEventsViaSubscribe({ authors: [pubkey], kinds: [KIND_TEXT_NOTE], limit: queryLimit * 2 }),
  ]);

  const activity: GitProfileActivityItem[] = [];
  const workItems: Array<{
    repoRef: RepoReference;
    item: PullRequest | Issue;
    type: 'pr' | 'issue';
  }> = [];

  for (const event of workEvents) {
    const repoRef = getRepoReferenceFromTags(event.tags);
    if (!repoRef) continue;

    if (event.kind === KIND_PULL_REQUEST) {
      const pr = parsePullRequestEvent(event);
      if (pr) workItems.push({ repoRef, item: pr, type: 'pr' });
      continue;
    }

    if (event.kind === KIND_ISSUE) {
      const issue = parseIssueEvent(event);
      if (issue) workItems.push({ repoRef, item: issue, type: 'issue' });
    }
  }

  const statuses = await fetchLatestStatuses(workItems.map(({ repoRef, item }) => ({
    eventId: item.eventId,
    repoOwnerPubkey: repoRef.repoOwnerPubkey,
  })));

  for (const { repoRef, item, type } of workItems) {
    if (type === 'pr') {
      const pr = item as PullRequest;
      activity.push({
        ...repoRef,
        id: pr.id,
        type: 'pr',
        title: pr.title,
        status: statuses.get(pr.eventId) ?? 'open',
        labels: pr.labels,
        branch: pr.branch,
        targetBranch: pr.targetBranch,
        created_at: pr.created_at,
      });
      continue;
    }

    const issue = item as Issue;
    activity.push({
      ...repoRef,
      id: issue.id,
      type: 'issue',
      title: issue.title,
      status: statuses.get(issue.eventId) ?? 'open',
      labels: issue.labels,
      created_at: issue.created_at,
    });
  }

  await appendProfileCommentActivity(activity, commentEvents);

  return activity
    .sort((a, b) => {
      if (b.created_at !== a.created_at) {
        return b.created_at - a.created_at;
      }
      return a.id.localeCompare(b.id);
    })
    .slice(0, limit);
}

async function appendProfileCommentActivity(activity: GitProfileActivityItem[], commentEvents: Awaited<ReturnType<typeof fetchEventsViaSubscribe>>) {
  const commentCandidates = commentEvents
    .map(event => {
      if (!event.id) return null;

      const targetEventId = getTargetEventIdFromTags(event.tags);
      const repoRef = getRepoReferenceFromTags(event.tags);
      if (!targetEventId || !repoRef) return null;

      return {
        id: event.id,
        content: event.content || '',
        created_at: event.created_at || 0,
        targetEventId,
        repoRef,
      };
    })
    .filter((candidate): candidate is NonNullable<typeof candidate> => candidate !== null);

  const targetIds = Array.from(new Set(commentCandidates.map(candidate => candidate.targetEventId)));
  const targetEvents = targetIds.length > 0
    ? await fetchEventsViaSubscribe({
      ids: targetIds,
      kinds: [KIND_PULL_REQUEST, KIND_ISSUE],
      limit: targetIds.length * 2,
    })
    : [];

  const targets = new Map<string, { targetType: 'issue' | 'pr'; targetTitle: string; repoRef: RepoReference | null }>();
  for (const event of targetEvents) {
    if (!event.id) continue;

    if (event.kind === KIND_PULL_REQUEST) {
      const pr = parsePullRequestEvent(event);
      if (!pr) continue;
      targets.set(event.id, {
        targetType: 'pr',
        targetTitle: pr.title,
        repoRef: getRepoReferenceFromTags(event.tags),
      });
      continue;
    }

    if (event.kind === KIND_ISSUE) {
      const issue = parseIssueEvent(event);
      if (!issue) continue;
      targets.set(event.id, {
        targetType: 'issue',
        targetTitle: issue.title,
        repoRef: getRepoReferenceFromTags(event.tags),
      });
    }
  }

  for (const candidate of commentCandidates) {
    const target = targets.get(candidate.targetEventId);
    if (!target) continue;

    const repoRef = candidate.repoRef || target.repoRef;
    if (!repoRef) continue;

    activity.push({
      ...repoRef,
      id: candidate.id,
      type: 'comment',
      content: candidate.content,
      targetEventId: candidate.targetEventId,
      targetType: target.targetType,
      targetTitle: target.targetTitle,
      created_at: candidate.created_at,
    });
  }
}
