
import { nostr, nostrStore, npubToPubkey } from './nostr';
import {
  isNewerGitRepoAnnouncement,
  parseGitRepoAnnouncement,
  type GitRepoAnnouncement,
} from './lib/gitRepoAnnouncements';
import { KIND_REPO_ANNOUNCEMENT } from './utils/constants';
import { buildHtreeUrl, fetchEventsViaSubscribe, publishNip34Event } from './nip34';

export async function publishRepoAnnouncement(
  repoName: string,
  options: {
    description?: string;
    webUrl?: string;
    maintainers?: string[];
    earliestUniqueCommit?: string;
    personalFork?: boolean;
    forkedFrom?: string;
  } = {}
): Promise<boolean> {
  const state = nostrStore.getState();
  if (!state.pubkey || !state.npub || !nostr.signer) return false;

  const htreeUrl = buildHtreeUrl(state.npub, repoName);

  const event = { kind: 0, created_at: Math.floor(Date.now() / 1000), content: '', tags: [] as string[][] };
  event.kind = KIND_REPO_ANNOUNCEMENT;
  event.content = '';
  event.tags = [
    ['d', repoName],
    ['name', repoName],
    ['clone', htreeUrl],
  ];

  if (options.description) event.tags.push(['description', options.description]);
  if (options.webUrl) event.tags.push(['web', options.webUrl]);
  if (options.earliestUniqueCommit) event.tags.push(['r', options.earliestUniqueCommit, 'euc']);
  if (options.personalFork) event.tags.push(['t', 'personal-fork']);
  if (options.forkedFrom) event.tags.push(['forked-from', options.forkedFrom]);

  const maintainerPubkeys = (options.maintainers || [])
    .map(maintainerNpub => npubToPubkey(maintainerNpub))
    .filter((maintainerPubkey): maintainerPubkey is string => !!maintainerPubkey);
  if (maintainerPubkeys.length > 0) {
    event.tags.push(['maintainers', ...maintainerPubkeys]);
  }

  try {
    await publishNip34Event(event);
    return true;
  } catch (e) {
    console.error('Failed to publish repo announcement:', e);
    return false;
  }
}

export async function fetchRepoAnnouncement(npub: string, repoName: string): Promise<GitRepoAnnouncement | null> {
  const pubkey = npubToPubkey(npub);
  if (!pubkey) {
    return null;
  }

  const events = await fetchEventsViaSubscribe({
    kinds: [KIND_REPO_ANNOUNCEMENT],
    authors: [pubkey],
    '#d': [repoName],
    limit: 20,
  }, 3000);

  let latest: GitRepoAnnouncement | null = null;
  for (const event of events) {
    const parsed = parseGitRepoAnnouncement(event);
    if (parsed && isNewerGitRepoAnnouncement(parsed, latest)) {
      latest = parsed;
    }
  }

  return latest;
}
