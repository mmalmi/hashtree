import { nip19 } from 'nostr-tools';

export function encodeEventId(eventId: string, relays?: string[]): string {
  try {
    return nip19.neventEncode({
      id: eventId,
      relays: relays || [],
    });
  } catch {
    try {
      return nip19.noteEncode(eventId);
    } catch {
      return eventId;
    }
  }
}

export function decodeEventId(encoded: string): string | null {
  try {
    if (encoded.startsWith('nevent')) {
      const decoded = nip19.decode(encoded);
      if (decoded.type === 'nevent') {
        return decoded.data.id;
      }
    }
    if (encoded.startsWith('note')) {
      const decoded = nip19.decode(encoded);
      if (decoded.type === 'note') {
        return decoded.data;
      }
    }
    if (/^[0-9a-f]{64}$/i.test(encoded)) {
      return encoded;
    }
    return null;
  } catch {
    return null;
  }
}
