import { describe, expect, it } from 'vitest';
import { parseRouteFromHash } from '../src/stores/route';

describe('parseRouteFromHash', () => {
  it.each(['profile', 'follows', 'followers', 'edit'])('keeps /%s outside tree context', (page) => {
    expect(parseRouteFromHash(`#/npub1owner/${page}`)).toMatchObject({
      npub: 'npub1owner',
      treeName: null,
      path: [],
    });
  });

  it('decodes tree paths and compare branches', () => {
    const route = parseRouteFromHash('#/npub1owner/docs%2Fnotes/section%201?compare=main...feature');

    expect(route.treeName).toBe('docs/notes');
    expect(route.path).toEqual(['section 1']);
    expect(route.compareBranches).toEqual({ base: 'main', head: 'feature' });
  });
});
