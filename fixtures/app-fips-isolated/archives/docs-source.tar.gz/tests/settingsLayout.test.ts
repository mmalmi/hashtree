import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const componentsRoot = path.resolve(process.cwd(), 'src', 'components');
const settingsRoot = path.join(componentsRoot, 'settings');
const sharedSettingsRoot = path.join(
  fs.realpathSync(path.resolve(process.cwd(), 'node_modules', '@iris', 'hashtree-app')),
  'src',
);
const settingsLayoutSource = fs.readFileSync(path.join(settingsRoot, 'SettingsLayout.svelte'), 'utf8');
const sharedSettingsLayoutSource = fs.readFileSync(path.join(sharedSettingsRoot, 'SettingsLayout.svelte'), 'utf8');
const appSettingsSource = fs.readFileSync(path.join(settingsRoot, 'AppSettings.svelte'), 'utf8');
const storageSettingsSource = fs.readFileSync(path.join(settingsRoot, 'StorageSettings.svelte'), 'utf8');
const serversSettingsSource = fs.readFileSync(path.join(settingsRoot, 'ServersSettings.svelte'), 'utf8');
const transportUsageSettingsSource = fs.readFileSync(path.join(settingsRoot, 'TransportUsageSettings.svelte'), 'utf8');
const p2pSettingsSource = fs.readFileSync(path.join(settingsRoot, 'P2PSettings.svelte'), 'utf8');
const connectivityIndicatorSource = fs.readFileSync(path.join(componentsRoot, 'ConnectivityIndicator.svelte'), 'utf8');
const docsRouterSource = fs.readFileSync(path.join(componentsRoot, 'Docs', 'DocsRouter.svelte'), 'utf8');
const docsAppSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'DocsApp.svelte'), 'utf8');
const sharedSettingsShortcutSource = fs.readFileSync(path.join(sharedSettingsRoot, 'SettingsShortcut.svelte'), 'utf8');

describe('shared settings layout', () => {
  it('uses the shared hashtree settings shell with local settings panels', () => {
    expect(settingsLayoutSource).toContain("from '@iris/hashtree-app/SettingsLayout.svelte'");
    expect(settingsLayoutSource).toContain('currentPath={$currentPath}');
    expect(settingsLayoutSource).toContain('{navigate}');
    expect(settingsLayoutSource).toContain('appSettings={AppSettings}');
    expect(settingsLayoutSource).toContain('storageSettings={StorageSettings}');
    expect(settingsLayoutSource).toContain('trafficSettings={TransportUsageSettings}');
    expect(settingsLayoutSource).toContain('serversSettings={ServersSettings}');
    expect(settingsLayoutSource).toContain('p2pSettings={P2PSettings}');
  });

  it('promotes network panels into top-level settings tabs', () => {
    expect(sharedSettingsLayoutSource).toContain("id: 'app'");
    expect(sharedSettingsLayoutSource).toContain("label: 'App'");
    expect(sharedSettingsLayoutSource).toContain("id: 'traffic'");
    expect(sharedSettingsLayoutSource).toContain("label: 'Traffic'");
    expect(sharedSettingsLayoutSource).toContain("id: 'servers'");
    expect(sharedSettingsLayoutSource).toContain("label: 'Servers'");
    expect(sharedSettingsLayoutSource).toContain("id: 'p2p'");
    expect(sharedSettingsLayoutSource).toContain("label: 'P2P'");
    expect(sharedSettingsLayoutSource).not.toContain("id: 'network'");
    expect(sharedSettingsLayoutSource).not.toContain("label: 'Network'");
    expect(sharedSettingsLayoutSource).not.toContain('App behavior, storage, and network configuration for this shell.');
    expect(sharedSettingsLayoutSource).not.toContain('const settingsGroups =');
    expect(sharedSettingsLayoutSource).not.toContain('const networkSections =');
    expect(sharedSettingsLayoutSource).not.toContain('mx-auto w-full max-w-md');
    expect(sharedSettingsLayoutSource).not.toContain('mx-auto w-full max-w-4xl');
    expect(sharedSettingsLayoutSource).toContain('Account tools, build info, and refresh actions');
    expect(sharedSettingsLayoutSource).toContain('Cache limits, local storage, and republish tools');
    expect(sharedSettingsLayoutSource).toContain('Transferred totals grouped by transport.');
    expect(sharedSettingsLayoutSource).toContain('Relays and Blossom endpoints.');
    expect(sharedSettingsLayoutSource).toContain('Connection pools and mesh peers.');
    expect(sharedSettingsLayoutSource).toContain('/settings/${id}');
  });

  it('keeps colored icon pills for the top-level settings navigation', () => {
    expect(sharedSettingsLayoutSource).toContain('bg-accent/12 text-accent ring-1 ring-accent/20');
    expect(sharedSettingsLayoutSource).toContain('bg-amber-500/12 text-amber-500 ring-1 ring-amber-500/20');
    expect(sharedSettingsLayoutSource).toContain('bg-sky-500/12 text-sky-500 ring-1 ring-sky-500/20');
    expect(sharedSettingsLayoutSource).toContain('bg-emerald-500/12 text-emerald-500 ring-1 ring-emerald-500/20');
    expect(sharedSettingsLayoutSource).toContain('bg-violet-500/12 text-violet-500 ring-1 ring-violet-500/20');
  });

  it('routes nested settings paths through the shared layout across app shells', () => {
    expect(docsRouterSource).toContain("{ pattern: '/settings/*', component: SettingsLayout }");
  });

  it('links app settings to the docs source repository', () => {
    expect(appSettingsSource).toContain("getCanonicalGitRepositoryUrl('iris-docs')");
    expect(appSettingsSource).toContain('<span>iris-docs</span>');
    expect(appSettingsSource).not.toContain("getCanonicalGitRepositoryUrl('hashtree')");
    expect(appSettingsSource).not.toContain('<span>hashtree</span>');
  });

  it('keeps settings reachable from the header independently of connection indicators', () => {
    expect(docsAppSource).toContain("from '@iris/hashtree-app/SettingsShortcut.svelte'");
    expect(docsAppSource).toContain('<SettingsShortcut />');
    expect(sharedSettingsShortcutSource).toContain("href = '#/settings'");
    expect(sharedSettingsShortcutSource).toContain('data-testid="header-settings-link"');
  });

  it('keeps header connectivity detailed only when the setting is enabled', () => {
    expect(p2pSettingsSource).toContain('Show connectivity in header');
    expect(p2pSettingsSource).toContain('DEFAULT_POOL_SETTINGS.showConnectivity');
    expect(connectivityIndicatorSource).toContain("from '../stores/settings'");
    expect(connectivityIndicatorSource).toContain("$settingsStore.pools.showConnectivity ?? false");
    expect(connectivityIndicatorSource).toContain('let showOfflineOnly = $derived(!showDetailedConnectivity && totalConnections === 0);');
    expect(connectivityIndicatorSource).toContain('{#if showOfflineOnly}');
    expect(connectivityIndicatorSource).toContain('>\n    offline\n  </a>');
  });

  it('puts the traffic header visibility toggle on the traffic settings page', () => {
    expect(transportUsageSettingsSource).toContain('Show in header');
    expect(transportUsageSettingsSource).toContain('data-testid="settings-show-bandwidth-toggle"');
    expect(transportUsageSettingsSource).toContain('setPoolSettings({ showBandwidth: e.currentTarget.checked })');
    expect(transportUsageSettingsSource).not.toContain('Control whether live traffic rates appear in the app header');
    expect(transportUsageSettingsSource).not.toContain('Display live upload/download rates in the header');
    expect(p2pSettingsSource).not.toContain('Show bandwidth');
    expect(p2pSettingsSource).not.toContain('setPoolSettings({ showBandwidth: e.currentTarget.checked })');
  });

  it('keeps settings pages scrollable inside the fixed app shell', () => {
    expect(docsAppSource).toContain('flex-1 flex flex-col min-h-0');
    expect(sharedSettingsLayoutSource).toContain('flex min-h-0 flex-1 flex-col overflow-hidden');
    expect(sharedSettingsLayoutSource).toContain('overflow-y-auto overscroll-contain');
    expect(sharedSettingsLayoutSource).toContain('data-scrollable');
  });

  it('maps legacy network routes onto top-level network tabs', () => {
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/storage')) return 'storage';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/traffic')) return 'traffic';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/network/traffic')) return 'traffic';");
    expect(sharedSettingsLayoutSource).toContain("if (path === '/settings/network') return 'traffic';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/app')) return 'app';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/servers')) return 'servers';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/network/servers')) return 'servers';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/p2p')) return 'p2p';");
    expect(sharedSettingsLayoutSource).toContain("if (path.startsWith('/settings/network/p2p')) return 'p2p';");
    expect(sharedSettingsLayoutSource).toContain("return DEFAULT_TAB;");
    expect(appSettingsSource).not.toContain('max-w-2xl mx-auto');
    expect(storageSettingsSource).not.toContain('max-w-2xl mx-auto');
    expect(transportUsageSettingsSource).not.toContain('max-w-2xl mx-auto');
    expect(p2pSettingsSource).not.toContain('max-w-2xl mx-auto');
  });

  it('shows embedded daemon transport and upstream relays inside one relay section', () => {
    expect(serversSettingsSource).toContain('Relays');
    expect(serversSettingsSource).toContain('Configured upstream relays');
    expect(serversSettingsSource).not.toContain('Local Transport (');
  });
});
