import { describe, expect, it } from 'vitest';
import { mergeDocsHomeItems, type DocsHomeItem } from '../src/components/Docs/docsHomeItems';

function doc(overrides: Partial<DocsHomeItem>): DocsHomeItem {
  return {
    key: overrides.href ?? '/npub1owner/docs/kekdoc',
    displayName: 'kekdoc',
    ownerNpub: 'npub1owner',
    treeName: 'docs/kekdoc',
    href: '#/npub1owner/docs%2Fkekdoc',
    timestamp: 1,
    ...overrides,
  };
}

describe('mergeDocsHomeItems', () => {
  it('collapses link-private editor mirrors into one document card', () => {
    const authorRecent = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 10,
    });
    const editorMirror = doc({
      ownerNpub: 'npub1editor',
      href: '#/npub1editor/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 0,
    });

    expect(mergeDocsHomeItems([authorRecent], [editorMirror])).toEqual([authorRecent]);
  });

  it('collapses link-private recents recorded once per editor root', () => {
    const authorRecent = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 20,
    });
    const editorRecent = doc({
      ownerNpub: 'npub1editor',
      href: '#/npub1editor/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 10,
    });

    expect(mergeDocsHomeItems([authorRecent, editorRecent], [])).toEqual([authorRecent]);
  });

  it('collapses stale no-key editor recents when a same-tree link key is known later', () => {
    const staleEditorRecent = doc({
      ownerNpub: 'npub1editor',
      href: '#/npub1editor/docs%2Fkekdoc',
      linkKey: undefined,
      timestamp: 20,
    });
    const authorRecent = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 10,
    });

    expect(mergeDocsHomeItems([staleEditorRecent, authorRecent], [])).toEqual([authorRecent]);
  });

  it('collapses same-tree stale entries when only link-visible visibility is known', () => {
    const staleRecent = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc',
      linkKey: undefined,
      visibility: undefined,
      timestamp: 20,
    });
    const ownMirror = doc({
      ownerNpub: 'npub1editor',
      href: '#/npub1editor/docs%2Fkekdoc',
      linkKey: undefined,
      visibility: 'link-visible',
      timestamp: 0,
    });

    expect(mergeDocsHomeItems([staleRecent], [ownMirror])).toEqual([ownMirror]);
  });

  it('keeps same-named link-private documents separate when link keys differ', () => {
    const first = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
    });
    const second = doc({
      ownerNpub: 'npub1other',
      href: '#/npub1other/docs%2Fkekdoc?k=def456',
      linkKey: 'def456',
    });

    expect(mergeDocsHomeItems([first, second], [])).toEqual([first, second]);
  });

  it('collapses stale own mirrors when only the author recent has the link key', () => {
    const authorRecent = doc({
      ownerNpub: 'npub1author',
      href: '#/npub1author/docs%2Fkekdoc?k=abc123',
      linkKey: 'abc123',
      timestamp: 10,
    });
    const staleOwnMirror = doc({
      ownerNpub: 'npub1editor',
      href: '#/npub1editor/docs%2Fkekdoc',
      linkKey: undefined,
      timestamp: 0,
    });

    expect(mergeDocsHomeItems([authorRecent], [staleOwnMirror])).toEqual([authorRecent]);
  });

  it('still deduplicates exact owner and tree repeats', () => {
    const latest = doc({ timestamp: 2 });
    const older = doc({ timestamp: 1 });

    expect(mergeDocsHomeItems([latest, older], [])).toEqual([latest]);
  });
});
