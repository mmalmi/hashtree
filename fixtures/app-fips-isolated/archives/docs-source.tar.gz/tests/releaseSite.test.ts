import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  parsePublishOutput,
  runAllReleases,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

describe('release-site', () => {
  const wranglerCommand = `wrangler@${wranglerVersion}`;

  it('uses the built-in Worker default for docs', () => {
    const parsed = parseArgs(['docs']);
    expect(parsed.workerName).toBe('iris-docs');
    expect(parsed.treeName).toBe('docs');
    expect(parsed.routes).toEqual(['docs.iris.to/*']);
    expect(parsed.domains).toEqual([]);
  });

  it('uses a profile-specific Worker env var without production routes or domains', () => {
    const parsed = parseArgs(['docs'], { CF_WORKER_NAME_DOCS: 'iris-docs-preview' });
    expect(parsed.workerName).toBe('iris-docs-preview');
    expect(parsed.treeName).toBe('docs');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports explicitly switching docs back to Pages', () => {
    const parsed = parseArgs(['docs', '--pages-only'], { CF_PAGES_PROJECT_DOCS: 'docs-iris-to' });
    expect(parsed.workerName).toBeUndefined();
    expect(parsed.pagesProject).toBe('docs-iris-to');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports the all profile without per-site overrides', () => {
    const parsed = parseArgs(['all', '--branch', 'main', '--skip-cloudflare']);
    expect(parsed.profileName).toBe('all');
    expect(parsed.branch).toBe('main');
    expect(parsed.skipCloudflare).toBe(true);
  });

  it('rejects single-target Worker overrides for the all profile', () => {
    expect(() => parseArgs(['all', '--worker-name', 'iris-docs'])).toThrow(
      '--worker-name is not supported with the all profile',
    );
  });

  it('supports the docs release profile', () => {
    const docs = createReleasePlan({
      profileName: 'docs',
      pagesProject: 'docs-iris-to',
      treeName: 'docs',
      skipCloudflare: false,
    });

    expect(docs.profile.distDir).toBe('dist-docs');
  });

  it('builds a Worker release plan in build-test-publish-deploy order', () => {
    const plan = createReleasePlan({
      profileName: 'docs',
      workerName: 'iris-docs',
      routes: ['docs.iris.to/*'],
      domains: [],
      treeName: 'docs',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.map((step) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-docs',
      '--name',
      'iris-docs',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--route',
      'docs.iris.to/*',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-docs',
      '--name',
      'iris-docs',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-docs',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist-docs',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('prefers a Worker deployment when both Worker and Pages targets are configured', () => {
    const plan = createReleasePlan({
      profileName: 'docs',
      workerName: 'iris-docs',
      pagesProject: 'docs-iris-to',
      treeName: 'docs',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.at(-1)?.label).toBe('Deploy Iris Docs to Cloudflare Worker');
  });

  it('builds a Pages release plan when only a Pages project is configured', () => {
    const plan = createReleasePlan({
      profileName: 'docs',
      pagesProject: 'docs-iris-to',
      treeName: 'docs',
      branch: 'main',
      skipCloudflare: false,
    });

    expect(plan.steps.at(-1)?.command).toEqual([
      'npx',
      wranglerCommand,
      'pages',
      'deploy',
      'dist-docs',
      '--project-name',
      'docs-iris-to',
      '--branch',
      'main',
    ]);
  });

  it('rejects Pages-only branch flags for Worker deployments', () => {
    expect(() =>
      createReleasePlan({
        profileName: 'docs',
        workerName: 'iris-docs',
        treeName: 'docs',
        branch: 'main',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      }),
    ).toThrow('--branch is only supported for Pages deployments');
  });

  it('stops before publish when a test step fails', async () => {
    const calls: string[] = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-2') {
        return { status: 1, stdout: '', stderr: 'smoke failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(
      runRelease(
        {
          profileName: 'docs',
          workerName: 'iris-docs',
          treeName: 'docs',
          skipCloudflare: false,
          workerCompatibilityDate: '2026-03-19',
        },
        runner,
        { buildOutputExists: () => true },
      ),
    ).rejects.toThrow('Test Iris Docs (2/5) failed with exit code 1');
    expect(calls).toEqual(['build', 'test-1', 'test-2']);
  });

  it('runs hashtree publish and Cloudflare deploy in parallel after tests', async () => {
    let activeReleaseSteps = 0;
    let maxActiveReleaseSteps = 0;
    const calls: string[] = [];
    const runner = vi.fn(async (step) => {
      calls.push(step.id);
      if (step.id === 'publish' || step.id === 'deploy') {
        activeReleaseSteps += 1;
        maxActiveReleaseSteps = Math.max(maxActiveReleaseSteps, activeReleaseSteps);
        await new Promise((resolve) => setTimeout(resolve, 10));
        activeReleaseSteps -= 1;
        if (step.id === 'publish') {
          return {
            status: 0,
            stdout: 'published: npub1example/docs\nnhash1ace',
            stderr: '',
          };
        }
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await runRelease(
      {
        profileName: 'docs',
        workerName: 'iris-docs',
        treeName: 'docs',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(calls).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'publish',
      'deploy',
    ]);
    expect(maxActiveReleaseSteps).toBe(2);
  });

  it('returns parsed hashtree and Worker target on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/docs\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'docs',
        workerName: 'iris-docs',
        treeName: 'docs',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/docs',
    });
    expect(result.workerName).toBe('iris-docs');
    expect(result.pagesProject).toBeNull();
    expect(result.pagesUrl).toBeNull();
  });

  it('returns parsed hashtree and Pages URLs on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/docs\nnhash1ace',
          stderr: '',
        };
      }
      if (step.id === 'deploy') {
        return {
          status: 0,
          stdout: 'Deploying... https://docs-iris-to.pages.dev',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'docs',
        pagesProject: 'docs-iris-to',
        treeName: 'docs',
        skipCloudflare: false,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/docs',
    });
    expect(result.pagesUrl).toBe('https://docs-iris-to.pages.dev');
  });

  it('runs all profiles sequentially', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: `published: npub1example/${step.label.split(' ')[1].toLowerCase()}\nnhash1ace`,
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runAllReleases(
      {
        profileName: 'all',
        skipCloudflare: true,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles.map((profile) => profile.profile.name)).toEqual(['docs']);
  });

  it('parses htree publish output defensively', () => {
    expect(parsePublishOutput('published: npub1foo/docs\nnhash1ace')).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/docs',
    });
    expect(
      parsePublishOutput(
        [
          '2026-03-19T21:46:47Z ERROR nostr_relay_pool::pool::internal: Impossible to send event to wss://upload.iris.to/nostr: event not published: index build failed: MissingChunk',
          'published: npub1foo/docs',
          'nhash1ace',
        ].join('\n'),
      ),
    ).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/docs',
    });
    expect(() => parsePublishOutput('published: npub1foo/docs')).toThrow(
      'Publish succeeded but no nhash was found in htree output',
    );
  });
});
