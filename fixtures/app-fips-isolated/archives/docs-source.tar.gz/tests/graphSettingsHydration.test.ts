import { afterEach, describe, expect, test, vi } from 'vitest';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';

const storage = vi.hoisted(() => ({ read: vi.fn(), write: vi.fn() }));
vi.mock('dexie', () => ({ default: class {
  version() { return { stores: () => Object.assign(this, { settings: { get: storage.read, put: storage.write } }) }; }
} }));
vi.mock('../src/lib/nativeHtree', () => ({ canUseInjectedHtreeServerUrl: () => false }));
afterEach(() => { vi.restoreAllMocks(); vi.unstubAllGlobals(); });

describe('saved graph network policy', () => {
  test.each([
    { name: 'absent row', value: undefined, expected: DEFAULT_PUBLIC_RELAYS },
    { name: 'existing row without relays', value: {}, expected: [] },
    { name: 'explicit empty list', value: { relays: [] }, expected: [] },
    { name: 'local-only relays', value: { relays: ['ws://127.0.0.1:7000'] }, expected: ['ws://127.0.0.1:7000'] },
    { name: 'custom relays', value: { relays: ['wss://custom.example'] }, expected: ['wss://custom.example'] },
    { name: 'a subset of defaults', value: { relays: DEFAULT_PUBLIC_RELAYS.slice(1) }, expected: DEFAULT_PUBLIC_RELAYS.slice(1) },
  ])('loads $name without rewriting the saved choice', async ({ value, expected }) => {
    vi.resetModules(); storage.write.mockClear();
    vi.stubGlobal('window', { location: { hostname: 'docs.iris.to' } });
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    storage.read.mockImplementation(async key => key === 'network' && value !== undefined ? { key, value } : undefined);
    const { settingsStore, waitForSettingsLoaded } = await import('../src/stores/settings');
    await waitForSettingsLoaded();
    expect(settingsStore.getState().networkLoaded).toBe(true);
    expect(settingsStore.getState().network.relays).toEqual(expected);
    expect(storage.write).not.toHaveBeenCalled();
  });

  test('a failed settings read completes startup with no public relay permission or disk write', async () => {
    vi.resetModules(); storage.write.mockClear();
    vi.spyOn(console, 'error').mockImplementation(() => {});
    storage.read.mockRejectedValue(new Error('settings database unavailable'));
    const { settingsStore, waitForSettingsLoaded } = await import('../src/stores/settings');
    await waitForSettingsLoaded();
    expect(settingsStore.getState().networkLoaded).toBe(true);
    expect(settingsStore.getState().network.relays).toEqual([]);
    expect(storage.write).not.toHaveBeenCalled();
  });
});
