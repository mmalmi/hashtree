import { describe, expect, test, vi } from 'vitest';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { shouldBootstrapPublicGraph } from '../src/lib/graphBootstrapPolicy';
import { applyProductionNetworkFallback } from '../src/stores/settingsDefaults';

vi.mock('../src/lib/nativeHtree', () => ({ canUseInjectedHtreeServerUrl: () => false }));

describe('public graph bootstrap relay policy', () => {
  test('allows only the normalized shipped relay set', () => {
    expect(shouldBootstrapPublicGraph(DEFAULT_PUBLIC_RELAYS)).toBe(true);
    expect(shouldBootstrapPublicGraph([...DEFAULT_PUBLIC_RELAYS].reverse().map(url => ` ${url.toUpperCase()}/ `))).toBe(true);
    expect(shouldBootstrapPublicGraph([...DEFAULT_PUBLIC_RELAYS, DEFAULT_PUBLIC_RELAYS[0]])).toBe(true);
  });

  test.each([
    [],
    DEFAULT_PUBLIC_RELAYS.slice(1),
    [...DEFAULT_PUBLIC_RELAYS, 'wss://custom.example'],
    [...DEFAULT_PUBLIC_RELAYS.slice(1), 'wss://custom.example'],
    ['ws://127.0.0.1:7000'],
    ['ws://localhost:7000'],
    [...DEFAULT_PUBLIC_RELAYS, 'invalid relay'],
    DEFAULT_PUBLIC_RELAYS.map(url => url.replace('wss:', 'ws:')),
    DEFAULT_PUBLIC_RELAYS.map(url => `${url}?custom=1`),
  ].map(relays => ({ relays })))('rejects non-default set $relays', ({ relays }) => {
    expect(shouldBootstrapPublicGraph(relays)).toBe(false);
  });
});


test('preserves explicit empty, local, subset and custom relays on public app hosts', () => {
  vi.stubGlobal('window', { location: { hostname: 'docs.iris.to' } });
  try {
    for (const relays of [[], ['ws://127.0.0.1:7000'], DEFAULT_PUBLIC_RELAYS.slice(1), ['wss://custom.example']]) {
      const network = { relays, blossomServers: [{ url: 'https://files.example', read: true, write: false }], negentropyEnabled: false };
      expect(applyProductionNetworkFallback(network).relays).toEqual(relays);
    }
  } finally { vi.unstubAllGlobals(); }
});
