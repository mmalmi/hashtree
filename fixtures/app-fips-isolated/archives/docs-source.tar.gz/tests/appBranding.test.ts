import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { getAppBrand, type IrisFilesAppId } from '../src/lib/appBrand';

const root = process.cwd();
const publicDir = path.join(root, 'public');

const APPS = ['docs'] as const satisfies readonly IrisFilesAppId[];

const htmlEntries: Record<IrisFilesAppId, string> = {
  docs: 'docs.html',
};

const configEntries: Record<IrisFilesAppId, string> = {
  docs: 'vite.docs.config.ts',
};

function read(relativePath: string): string {
  return fs.readFileSync(path.join(root, relativePath), 'utf8');
}

describe('iris-docs app branding', () => {
  it('defines an icon set for the docs shell', () => {
    const iconAssets = APPS.map((app) => getAppBrand(app).iconSvg);
    const pwaAssets = APPS.map((app) => getAppBrand(app).pwa192Png);

    expect(new Set(iconAssets).size).toBe(APPS.length);
    expect(new Set(pwaAssets).size).toBe(APPS.length);

    for (const app of APPS) {
      const brand = getAppBrand(app);
      expect(fs.existsSync(path.join(publicDir, brand.iconSvg))).toBe(true);
      expect(fs.existsSync(path.join(publicDir, brand.appleTouchPng))).toBe(true);
      expect(fs.existsSync(path.join(publicDir, brand.pwa192Png))).toBe(true);
      expect(fs.existsSync(path.join(publicDir, brand.pwa512Png))).toBe(true);
    }
  });

  it('points each html entry to its own favicon svg', () => {
    for (const app of APPS) {
      const source = read(htmlEntries[app]);
      const brand = getAppBrand(app);

      expect(source).toContain(`type="image/svg+xml" href="%BASE_URL%${brand.iconSvg}"`);
      expect(source).not.toContain('iris-favicon.png');
    }
  });

  it('uses product-cased browser page titles for each app shell', () => {
    for (const app of APPS) {
      const source = read(htmlEntries[app]);
      const brand = getAppBrand(app);

      expect(source).toContain(`<title>${brand.displayName}</title>`);
    }
  });

  it('keeps the shared header logo on the app name', () => {
    const source = read('src/components/Logo.svelte');

    expect(source).toContain('>{brand.label}</span>');
    expect(source).not.toContain('>iris <span');
  });

  it('uses per-app install icons in each portable build config', () => {
    for (const app of APPS) {
      const source = read(configEntries[app]);

      expect(source).toContain(`const brand = getAppBrand('${app}')`);
      expect(source).toContain('includeAssets: [brand.iconSvg, brand.appleTouchPng]');
      expect(source).toContain(`icons: getAppPwaIcons('${app}')`);
      expect(source).not.toContain("'iris-logo.png'");
    }
  });

});
