import { beforeEach, describe, expect, it, vi } from 'vitest';
import * as Y from 'yjs';
import { LinkType } from '@hashtree/core';

const mocks = vi.hoisted(() => ({
  subscribe: vi.fn(),
  tree: { resolvePath: vi.fn(), isDirectory: vi.fn(), listDirectory: vi.fn(), readFile: vi.fn() },
}));
vi.mock('../src/store', () => ({
  getTree: () => mocks.tree,
  decodeAsText: (data: Uint8Array) => new TextDecoder().decode(data),
}));
vi.mock('../src/stores/treeRoot', () => ({ subscribeToTreeRoot: mocks.subscribe, getTreeRoot: vi.fn() }));
vi.mock('../src/stores/treeRootKeys', () => ({ decryptEncryptionKey: vi.fn() }));
vi.mock('../src/TreeRootRegistry', () => ({ treeRootRegistry: { mergeKey: vi.fn() } }));
import { setupCollaboratorSubscriptions } from '../src/lib/yjs/deltaLoader';

describe('collaborator permission updates', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.subscribe.mockReturnValue(() => {});
    mocks.tree.resolvePath.mockImplementation(async cid => ({ cid }));
    mocks.tree.isDirectory.mockResolvedValue(true);
    mocks.tree.listDirectory.mockImplementation(async cid => [{ name: '.yjs', type: LinkType.Blob, cid }]);
  });

  function subscribe() {
    let collaborators = ['npub1owner'];
    const setCollaborators = vi.fn((value: string[]) => { collaborators = value; });
    const stop = setupCollaboratorSubscriptions(
      ['npub1owner', 'npub1editor'], 'doc', [], 'npub1owner', 'npub1editor',
      new Y.Doc(), () => collaborators, setCollaborators,
    );
    return { update: mocks.subscribe.mock.calls[0][2], setCollaborators, stop };
  }

  it('does not replace newer permissions with a slow older read', async () => {
    let releaseOld!: (data: Uint8Array) => void;
    const oldRead = new Promise<Uint8Array>(resolve => { releaseOld = resolve; });
    mocks.tree.readFile.mockImplementation(cid => cid.hash[0] === 1
      ? oldRead : Promise.resolve(new TextEncoder().encode('npub1owner\nnpub1editor\n')));
    const { update, setCollaborators } = subscribe();
    const old = update(new Uint8Array(32).fill(1), new Uint8Array(32));
    await vi.waitFor(() => expect(mocks.tree.readFile).toHaveBeenCalledTimes(1));
    await update(new Uint8Array(32).fill(2), new Uint8Array(32));
    releaseOld(new TextEncoder().encode('npub1owner\n'));
    await old;
    expect(setCollaborators.mock.calls).toEqual([[['npub1owner', 'npub1editor']]]);
  });

  it('does not apply permissions after unsubscribing', async () => {
    let release!: (data: Uint8Array) => void;
    mocks.tree.readFile.mockReturnValue(new Promise<Uint8Array>(resolve => { release = resolve; }));
    const { update, setCollaborators, stop } = subscribe();
    const pending = update(new Uint8Array(32).fill(1), new Uint8Array(32));
    await vi.waitFor(() => expect(mocks.tree.readFile).toHaveBeenCalledTimes(1));
    stop();
    release(new TextEncoder().encode('npub1owner\nnpub1editor\n'));
    await pending;
    expect(setCollaborators).not.toHaveBeenCalled();
  });

  it('still applies an empty editor list as a revocation', async () => {
    mocks.tree.readFile.mockResolvedValue(new Uint8Array());
    const { update, setCollaborators } = subscribe();
    await update(new Uint8Array(32).fill(1), new Uint8Array(32));
    expect(setCollaborators).toHaveBeenCalledWith([]);
  });
});
