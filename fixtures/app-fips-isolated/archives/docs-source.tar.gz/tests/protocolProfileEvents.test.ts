import { describe, expect, it } from 'vitest';
import { getPublicKey, type Event } from 'nostr-tools';
import {
  buildIrisProfileFacetAcceptanceEvent,
  buildIrisProfileRosterOpEvent,
  parseIrisProfileFacetAcceptanceEvent,
  parseIrisProfileRosterOpEvent,
} from '../src/drive/protocolProfileEvents';
import {
  KIND_IRIS_PROFILE_FACET_ACCEPTANCE,
  KIND_IRIS_PROFILE_ROSTER_OP,
} from '../src/drive/protocolTypes';

const profileId = '11111111-1111-4111-8111-111111111111';
const signerSecretKey = Uint8Array.from({ length: 32 }, (_, index) => index + 1);
const signerPubkey = getPublicKey(signerSecretKey);
const secondPubkey = '2'.repeat(64);

describe('IrisProfile NostrIdentity wire events', () => {
  it('writes roster ops as canonical NostrIdentity fact events and parses back to local shapes', () => {
    const event = buildIrisProfileRosterOpEvent({
      signerSecretKey,
      profileId,
      createdAt: 1_700_000_000,
      clientNonce: 'rotate-test',
      op: {
        op: 'rotate_key_epoch',
        epoch: 3,
        wrapped_dck: {
          [secondPubkey]: 'wrapped-for-second',
          [signerPubkey]: 'wrapped-for-signer',
        },
      },
    });

    expect(event.kind).toBe(KIND_IRIS_PROFILE_ROSTER_OP);
    expect(event.kind).toBe(7368);
    expect(event.content).toBe('');
    expect(event.tags.some((tag) => tag[0] === 'd')).toBe(false);
    expect(event.tags).toContainEqual(['secret_epoch', '3']);
    expect(event.tags).toContainEqual(['wrapped_secret', signerPubkey, 'wrapped-for-signer']);

    const parsed = parseIrisProfileRosterOpEvent(event as Event);
    expect(parsed.signer_pubkey).toBe(signerPubkey);
    expect(parsed.content).toMatchObject({
      schema: 1,
      profile_id: profileId,
      actor_pubkey: signerPubkey,
      client_nonce: 'rotate-test',
      created_at: 1_700_000_000,
      op: {
        op: 'rotate_key_epoch',
        epoch: 3,
        wrapped_dck: {
          [secondPubkey]: 'wrapped-for-second',
          [signerPubkey]: 'wrapped-for-signer',
        },
      },
    });
  });

  it('writes facet acceptances as canonical NostrIdentity fact events and parses back to local shapes', () => {
    const event = buildIrisProfileFacetAcceptanceEvent({
      signerSecretKey,
      profileId,
      acceptedAt: 1_700_000_001,
      clientNonce: 'accept-test',
      purposes: ['fips_transport', 'social_profile', 'app_key'],
      rosterOpId: 'a'.repeat(64),
    });

    expect(event.kind).toBe(KIND_IRIS_PROFILE_FACET_ACCEPTANCE);
    expect(event.kind).toBe(7368);
    expect(event.content).toBe('');
    expect(event.tags.some((tag) => tag[0] === 'd')).toBe(false);

    const parsed = parseIrisProfileFacetAcceptanceEvent(event as Event);
    expect(parsed.signer_pubkey).toBe(signerPubkey);
    expect(parsed.content).toMatchObject({
      schema: 1,
      profile_id: profileId,
      facet_pubkey: signerPubkey,
      purposes: ['app_key', 'social_profile', 'fips_transport'],
      roster_op_id: 'a'.repeat(64),
      client_nonce: 'accept-test',
      accepted_at: 1_700_000_001,
    });
  });
});
