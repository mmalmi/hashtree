import { afterEach, describe, expect, it, vi } from 'vitest';
import { createShareUrlOptions, getCanonicalGitRepositoryUrl } from '../src/lib/shareUrls';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('shareUrls', () => {
  it('replaces internal Iris child-webview origins with clean share bases', () => {
    expect(
      createShareUrlOptions(
        'docs',
        'http://tree-deadbeef.htree.localhost:21417/htree/npub1app/docs/index.html?htree_server=http%3A%2F%2F127.0.0.1%3A21417&htree_canonical=htree%3A%2F%2Fnpub1app%2Fdocs#/npub1owner/doc%252Fdemo',
      ),
    ).toEqual([
      {
        id: 'web',
        label: 'Web URL',
        url: 'https://docs.iris.to/#/npub1owner/doc%252Fdemo',
      },
      {
        id: 'htree',
        label: 'htree URL',
        url: 'htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/docs#/npub1owner/doc%252Fdemo',
      },
    ]);
  });

  it('uses the default app URLs at the app root', () => {
    expect(createShareUrlOptions('docs', 'http://localhost:5173/#/')).toEqual([
      {
        id: 'web',
        label: 'Web URL',
        url: 'https://docs.iris.to',
      },
      {
        id: 'htree',
        label: 'htree URL',
        url: 'htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/docs',
      },
    ]);
  });

  it('builds canonical iris-git repository URLs for web contexts by default', () => {
    expect(getCanonicalGitRepositoryUrl()).toBe(
      'https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-docs',
    );
    expect(getCanonicalGitRepositoryUrl('docs/app')).toBe(
      'https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/docs/app',
    );
  });

  it('uses htree repository URLs when running inside Iris native or an htree page', () => {
    vi.stubGlobal('window', {
      __HTREE_SERVER_URL__: 'http://127.0.0.1:21417',
      location: {
        protocol: 'https:',
        hostname: 'drive.iris.to',
        search: '',
      },
    });

    expect(getCanonicalGitRepositoryUrl()).toBe(
      'htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/git/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-docs',
    );

    vi.stubGlobal('window', {
      location: {
        protocol: 'htree:',
        hostname: 'self',
        search: '',
      },
    });

    expect(getCanonicalGitRepositoryUrl('docs/app')).toBe(
      'htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/git/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/docs/app',
    );
  });
});
