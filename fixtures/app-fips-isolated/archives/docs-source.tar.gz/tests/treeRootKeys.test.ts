import { describe, expect, it, vi } from 'vitest';
import { toHex } from '@hashtree/core';
import { decryptEncryptionKey } from '../src/stores/treeRootKeys';

const ownerDecrypt = vi.hoisted(() => vi.fn());
vi.mock('../src/nostr', () => ({ decrypt: ownerDecrypt }));
vi.mock('../src/refResolver', () => ({ getRefResolver: vi.fn() }));
vi.mock('../src/stores/treeRootShared', () => ({ getNostrState: () => ({ pubkey: 'owner' }) }));

describe('tree root encryption keys', () => {
  it.each(['ab'.repeat(32), '01' + 'ab'.repeat(32), '02' + 'ab'.repeat(32)])(
    'reads a supported object key without visibility metadata',
    async key => {
      const recovered = await decryptEncryptionKey(undefined, undefined, key);
      expect(recovered && toHex(recovered)).toBe(key);
    },
  );

  it('recovers a versioned key with an opaque link secret from the owner', async () => {
    ownerDecrypt.mockResolvedValue('ff'.repeat(33));
    const recovered = await decryptEncryptionKey({
      visibility: 'link-visible',
      encryptedKey: 'fd' + '54'.repeat(32),
      selfEncryptedLinkKey: 'owner-envelope',
    }, undefined, null);
    expect(recovered && toHex(recovered)).toBe('02' + 'ab'.repeat(32));
  });

  it.each(['ff'.repeat(33), 'zz'.repeat(32), 'ab'.repeat(31)])(
    'rejects invalid unmasked object keys',
    async key => {
      expect(await decryptEncryptionKey(undefined, undefined, key)).toBeUndefined();
    },
  );
});
