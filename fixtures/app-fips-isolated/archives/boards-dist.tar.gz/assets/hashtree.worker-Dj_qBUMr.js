function e(r){return new Worker(""+new URL("hashtree.worker-BR5CSHrJ.js",import.meta.url).href,{name:r==null?void 0:r.name})}export{e as default};
