function r(e){return new Worker(""+new URL("hashtree.worker-D0c9cUH2.js",import.meta.url).href,{type:"module",name:e==null?void 0:e.name})}export{r as default};
