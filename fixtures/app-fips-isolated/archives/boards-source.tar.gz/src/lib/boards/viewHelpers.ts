import { cid as makeCid, fromHex, nhashEncode, type CID } from '@hashtree/core';
import DOMPurify from 'dompurify';
import { marked } from 'marked';
import { nip19 } from 'nostr-tools';
import { getNhashFileUrl } from '../mediaUrl';
import {
  BOARD_CARD_ATTACHMENTS_SUFFIX,
  BOARD_CARD_FILE_SUFFIX,
} from './constants';
import type { BoardCard, BoardCardAttachment, BoardColumn, BoardTombstones } from './state';

export function boardDisplayName(treeName: string | null): string {
  if (!treeName) return 'Board';
  return treeName.startsWith('boards/') ? treeName.slice(7) : treeName;
}

export function cardIdFromFilename(filename: string): string {
  if (!filename.endsWith(BOARD_CARD_FILE_SUFFIX)) return filename;
  return filename.slice(0, -BOARD_CARD_FILE_SUFFIX.length);
}

export function cardAttachmentsDirName(cardId: string): string {
  return `${cardId}${BOARD_CARD_ATTACHMENTS_SUFFIX}`;
}

export function cardIdFromAttachmentsDir(dirname: string): string | null {
  if (!dirname.endsWith(BOARD_CARD_ATTACHMENTS_SUFFIX)) return null;
  return dirname.slice(0, -BOARD_CARD_ATTACHMENTS_SUFFIX.length);
}

export function sanitizeAttachmentFileName(filename: string): string {
  const clean = filename
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .replace(/[\\/]+/g, '-')
    .replace(/\s+/g, ' ')
    .trim();
  return clean || `attachment-${Date.now().toString(36)}`;
}

export function guessMimeType(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  switch (ext) {
    case 'png': return 'image/png';
    case 'jpg':
    case 'jpeg': return 'image/jpeg';
    case 'gif': return 'image/gif';
    case 'webp': return 'image/webp';
    case 'svg': return 'image/svg+xml';
    case 'pdf': return 'application/pdf';
    case 'txt': return 'text/plain';
    case 'md': return 'text/markdown';
    case 'json': return 'application/json';
    default: return 'application/octet-stream';
  }
}

export function isImageAttachment(attachment: BoardCardAttachment): boolean {
  return attachment.mimeType.startsWith('image/');
}

export function isVideoAttachment(attachment: BoardCardAttachment): boolean {
  return attachment.mimeType.startsWith('video/');
}

export function isAudioAttachment(attachment: BoardCardAttachment): boolean {
  return attachment.mimeType.startsWith('audio/');
}

export function isModalPreviewAttachment(attachment: BoardCardAttachment): boolean {
  return isImageAttachment(attachment) || isVideoAttachment(attachment) || isAudioAttachment(attachment);
}

export function isImageMimeType(mimeType: string): boolean {
  return mimeType.startsWith('image/');
}

export function formatAttachmentSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

export function formatCommentTimestamp(timestamp: number): string {
  if (!Number.isFinite(timestamp)) return '';
  return new Date(timestamp).toLocaleString();
}

export function renderMarkdown(content: string): string {
  const trimmed = content.trim();
  if (!trimmed) return '';
  try {
    return DOMPurify.sanitize(marked.parse(trimmed, { async: false }) as string);
  } catch {
    const escaped = trimmed
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
    return escaped.replaceAll('\n', '<br />');
  }
}

export function attachmentCid(attachment: BoardCardAttachment): CID | null {
  try {
    const hash = fromHex(attachment.cidHash);
    const key = attachment.cidKey ? fromHex(attachment.cidKey) : undefined;
    return makeCid(hash, key);
  } catch {
    return null;
  }
}

export function cardAttachmentUrl(attachment: BoardCardAttachment): string | null {
  const fileCid = attachmentCid(attachment);
  if (fileCid) return getNhashFileUrl(fileCid, attachment.displayName || attachment.fileName);

  const hash = attachment.cidHash?.trim();
  if (!hash) return null;
  const decryptKey = attachment.cidKey?.trim() || undefined;
  try {
    const nhash = nhashEncode({ hash, decryptKey });
    const encodedName = encodeURIComponent(attachment.displayName || attachment.fileName || 'file');
    return `/htree/${nhash}/${encodedName}`;
  } catch {
    return null;
  }
}

export function attachmentImageSrc(
  attachment: BoardCardAttachment,
  previewUrls: Record<string, string>,
): string | null {
  return previewUrls[attachment.id] || cardAttachmentUrl(attachment);
}

function addImageRetryParam(url: string, attempt: number): string {
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}img_retry=${Date.now()}-${attempt}`;
}

export function handleAttachmentImageError(event: Event, attachment: BoardCardAttachment): void {
  const image = event.currentTarget as HTMLImageElement | null;
  if (!image) return;
  const remoteUrl = cardAttachmentUrl(attachment);
  if (!remoteUrl) return;

  const currentSrc = image.getAttribute('src') || image.src || '';
  if (currentSrc.startsWith('blob:')) {
    image.dataset.retryCount = '0';
    image.src = addImageRetryParam(remoteUrl, 0);
    return;
  }

  const currentRetry = Number(image.dataset.retryCount || '0');
  if (currentRetry >= 4) return;
  const nextRetry = currentRetry + 1;
  image.dataset.retryCount = String(nextRetry);
  const retryUrl = addImageRetryParam(remoteUrl, nextRetry);
  setTimeout(() => {
    if (!image.isConnected) return;
    image.src = retryUrl;
  }, 350 * nextRetry);
}

export function npubToPubkey(npub: string): string | null {
  if (!npub) return null;
  try {
    const decoded = nip19.decode(npub);
    if (decoded.type !== 'npub') return null;
    return decoded.data as string;
  } catch {
    return null;
  }
}

export function applyCardOrder(cards: BoardCard[], orderedCardIds: string[] | undefined): BoardCard[] {
  const byId = new Map(cards.map(card => [card.id, card]));
  const used: Record<string, true> = {};
  const ordered: BoardCard[] = [];

  for (const cardId of orderedCardIds || []) {
    const card = byId.get(cardId);
    if (!card || used[card.id]) continue;
    ordered.push(card);
    used[card.id] = true;
  }

  for (const card of cards) {
    if (used[card.id]) continue;
    ordered.push(card);
  }

  return ordered;
}

export function applyColumnOrder(columns: BoardColumn[], orderedColumnIds: string[]): BoardColumn[] {
  const byId = new Map(columns.map(column => [column.id, column]));
  const used: Record<string, true> = {};
  const ordered: BoardColumn[] = [];

  for (const columnId of orderedColumnIds) {
    const column = byId.get(columnId);
    if (!column || used[column.id]) continue;
    ordered.push(column);
    used[column.id] = true;
  }

  for (const column of columns) {
    if (used[column.id]) continue;
    ordered.push(column);
  }

  return ordered;
}

export function latestTombstoneUpdatedAt(snapshot: BoardTombstones | null | undefined): number {
  let latest = 0;
  for (const entry of snapshot?.entries ?? []) {
    if (entry.updatedAt > latest) latest = entry.updatedAt;
  }
  return latest;
}
