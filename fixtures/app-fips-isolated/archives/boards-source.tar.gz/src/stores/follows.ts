/**
 * follows hook - manages follow lists and follow/unfollow actions
 * Svelte version using writable stores
 */
import { writable } from 'svelte/store';
import { rememberContact } from './contactMemory';
import { getProfileName, getProfileSync } from './profile';
import { nip19, verifyEvent } from 'nostr-tools';
import type { Event as NostrEvent } from 'nostr-tools';
import { LRUCache } from '../utils/lruCache';
import { KeyedEventEmitter } from '../utils/keyedEventEmitter';
import { nostr, nostrStore } from '../nostr';

export interface Follows {
  pubkey: string;
  follows: string[];
  followedAt: number;
}

// Cache follows lists
const followsCache = new LRUCache<string, Follows>(100);

// Event emitter for follows updates
const followsEmitter = new KeyedEventEmitter<string, Follows>();

// Track active subscriptions - kept open for live updates
const activeSubscriptions = new Map<string, { stop: () => void }>();

// The newest follow list event seen for each subscribed pubkey.
const heads = new LRUCache<string, NostrEvent>(100);
// Lists signed here: a relay still serving an older list cannot undo them.
const publishedHeads = new Map<string, NostrEvent>();
// Pubkeys whose every source has answered, so "no list" really means none exists.
const completeHistories = new Set<string>();
const probingHistories = new Set<string>();
type FollowChange = { following: boolean; name: string | null };
// Follow/unfollow choices already shown but not yet in a signed list.
const pendingChanges = new Map<string, Map<string, FollowChange>>();
// What each list signed here was built on, so it can be rebuilt if a newer
// list which existed before it turns up afterwards.
const publishedBases = new Map<string, { base: number; changes: Map<string, FollowChange> }>();
const minCreatedAt = new Map<string, number>();
// Lists which failed verification, and the accounts they were served for.
const rejectedHeadIds = new Set<string>();
const unverifiableLists = new Set<string>();

function newerHead(current: NostrEvent | null | undefined, event: NostrEvent): NostrEvent {
  return !current || event.created_at > current.created_at ||
    (event.created_at === current.created_at && event.id < current.id) ? event : current;
}

function latestHead(pubkey: string): NostrEvent | null {
  const seen = heads.get(pubkey);
  const published = publishedHeads.get(pubkey);
  return seen && published ? newerHead(seen, published) : seen ?? published ?? null;
}

function withChanges(tags: string[][], changes: Map<string, FollowChange> | undefined): string[][] {
  let next = tags;
  for (const [target, { following }] of changes ?? []) {
    const listed = next.some(tag => tag[0] === 'p' && tag[1] === target);
    if (following && !listed) next = [...next, ['p', target]];
    if (!following && listed) next = next.filter(tag => !(tag[0] === 'p' && tag[1] === target));
  }
  return next;
}

/** Show the newest list with the viewer's unpublished choices applied on top. */
function showFollows(pubkey: string): void {
  const head = latestHead(pubkey);
  const changes = pendingChanges.get(pubkey);
  if (!head && !changes?.size && !followsCache.get(pubkey)) return;
  const follows: Follows = {
    pubkey,
    follows: withChanges(head?.tags ?? [], changes).filter(tag => tag[0] === 'p' && tag[1]).map(tag => tag[1]),
    followedAt: head?.created_at ?? 0,
  };
  followsCache.set(pubkey, follows);
  followsEmitter.notify(pubkey, follows);
}

function receiveFollowEvent(pubkey: string, event: NostrEvent): void {
  if (rejectedHeadIds.has(event.id)) return;
  const published = publishedHeads.get(pubkey);
  const built = publishedBases.get(pubkey);
  if (published && built && event.id !== published.id &&
    event.created_at > built.base && event.created_at < published.created_at) {
    // A slow relay held a newer list than the one built on. Apply the same
    // choices to it instead, so that nothing it added is lost.
    let changes = pendingChanges.get(pubkey);
    if (!changes) pendingChanges.set(pubkey, changes = new Map());
    for (const [target, change] of built.changes) {
      if (!changes.has(target)) changes.set(target, change);
    }
    minCreatedAt.set(pubkey, published.created_at + 1);
    publishedHeads.delete(pubkey);
    publishedBases.delete(pubkey);
  }

  const current = heads.get(pubkey);
  const head = newerHead(current, event);
  if (head === current) return;
  heads.set(pubkey, head);
  showFollows(pubkey);
  if (pendingChanges.get(pubkey)?.size) publishPendingFollows(pubkey);
}

function receiveFollowHistory(pubkey: string, status: { complete: boolean }): void {
  if (!status.complete) return;
  completeHistories.add(pubkey);
  if (pendingChanges.get(pubkey)?.size) publishPendingFollows(pubkey);
}

/**
 * Subscribe to follows (kept open for live updates).
 * The active backend owns subscriptions and cached event delivery.
 */
function fetchFollows(pubkey: string): void {
  if (!pubkey || pubkey.length !== 64) {
    console.warn('[follows] Invalid pubkey:', pubkey);
    return;
  }

  // Already subscribed
  if (activeSubscriptions.has(pubkey)) return;

  const sub = nostr.subscribe(
    { kinds: [3], authors: [pubkey] },
    { closeAfterHistory: false } // Keep open for live updates
  );

  sub.on('event', (event: NostrEvent) => receiveFollowEvent(pubkey, event));
  sub.on('history', status => receiveFollowHistory(pubkey, status));

  activeSubscriptions.set(pubkey, { stop: () => sub.stop() });
}

/** Ask once more whether a list exists; used only while none has been seen. */
function probeFollowHistory(pubkey: string): void {
  if (probingHistories.has(pubkey)) return;
  probingHistories.add(pubkey);
  const sub = nostr.subscribe({ kinds: [3], authors: [pubkey] }, { closeAfterHistory: true });
  sub.on('event', (event: NostrEvent) => receiveFollowEvent(pubkey, event));
  sub.on('history', (status) => {
    probingHistories.delete(pubkey);
    receiveFollowHistory(pubkey, status);
  });
  sub.on('close', () => probingHistories.delete(pubkey));
}

/**
 * Create a Svelte store for a user's follows list
 */
export function createFollowsStore(pubkey?: string) {
  const pubkeyHex = pubkey?.startsWith('npub1')
    ? (() => {
        try {
          const decoded = nip19.decode(pubkey);
          return decoded.data as string;
        } catch {
          return '';
        }
      })()
    : pubkey || '';

  const { subscribe: storeSubscribe, set } = writable<Follows | undefined>(
    pubkeyHex ? followsCache.get(pubkeyHex) : undefined
  );

  if (pubkeyHex) {
    // Subscribe to updates
    const unsub = followsEmitter.subscribe(pubkeyHex, set);

    // Fetch if not cached
    const cached = followsCache.get(pubkeyHex);
    if (cached) {
      set(cached);
    } else {
      fetchFollows(pubkeyHex);
    }

    // Return store with cleanup
    return {
      subscribe: storeSubscribe,
      destroy: unsub,
    };
  }

  return {
    subscribe: storeSubscribe,
    destroy: () => {},
  };
}

/**
 * Get follows synchronously (from cache)
 */
export function getFollowsSync(pubkey?: string): Follows | undefined {
  if (!pubkey) return undefined;
  const pubkeyHex = pubkey.startsWith('npub1')
    ? (() => {
        try {
          const decoded = nip19.decode(pubkey);
          return decoded.data as string;
        } catch {
          return '';
        }
      })()
    : pubkey;
  return followsCache.get(pubkeyHex);
}

/**
 * Follow/unfollow. The choice shows at once; the new list is built from the
 * newest list seen so far, signed and published in the background. Resolves
 * true as soon as the choice is shown.
 */
export function followPubkey(targetPubkey: string): Promise<boolean> {
  return updateFollow(targetPubkey, true);
}

export function unfollowPubkey(targetPubkey: string): Promise<boolean> {
  return updateFollow(targetPubkey, false);
}

let followUpdates: Promise<unknown> = Promise.resolve();

function updateFollow(targetPubkey: string, following: boolean): Promise<boolean> {
  const pk = nostrStore.getState().pubkey;
  if (!pk || !nostr.signer || !/^[a-f0-9]{64}$/.test(targetPubkey)) return Promise.resolve(false);

  let changes = pendingChanges.get(pk);
  if (!changes) pendingChanges.set(pk, changes = new Map());
  changes.set(targetPubkey, {
    following,
    // The name seen before following is the one the viewer chose to follow.
    name: getProfileName(getProfileSync(targetPubkey), targetPubkey) ?? null,
  });
  showFollows(pk);
  fetchFollows(pk);
  publishPendingFollows(pk);
  return Promise.resolve(true);
}

/** One list is signed at a time, so each builds on the one before it. */
function publishPendingFollows(pk: string): void {
  followUpdates = followUpdates.then(() => signPendingFollows(pk)).catch((error) => {
    console.error('[follows] Could not update the public follow list:', error);
  });
}

function dropChanges(pk: string, applied: Map<string, FollowChange>): void {
  const changes = pendingChanges.get(pk);
  for (const [target, change] of applied) {
    // A choice made again while signing stays for the next list.
    if (changes?.get(target) === change) changes.delete(target);
  }
  showFollows(pk);
}

async function signPendingFollows(pk: string): Promise<void> {
  const changes = pendingChanges.get(pk);
  if (!changes?.size) return;
  const signer = nostr.signer;
  const applied = new Map(changes);
  if (nostrStore.getState().pubkey !== pk || !signer) return dropChanges(pk, applied);

  let head = latestHead(pk);
  if (head && (head.pubkey !== pk || head.kind !== 3 || !verifyEvent(head))) {
    // Never build on a list which is not provably the account's own, and do
    // not take its absence as established either.
    if (head.id) rejectedHeadIds.add(head.id);
    unverifiableLists.add(pk);
    if (heads.get(pk) === head) heads.delete(pk);
    head = publishedHeads.get(pk) ?? null;
  }
  if (!head && (!completeHistories.has(pk) || unverifiableLists.has(pk))) {
    // No list has been seen and its absence is not established: publishing now
    // could replace an existing list with this one choice. The choice stays
    // shown and is published when a list arrives or every source answers.
    if (!unverifiableLists.has(pk)) probeFollowHistory(pk);
    return;
  }

  const tags = head?.tags.map(tag => [...tag]) ?? [];
  const nextTags = withChanges(tags, applied);
  if (nextTags !== tags) {
    let event: NostrEvent;
    try {
      event = await nostr.signEvent({
        kind: 3,
        tags: nextTags,
        content: head?.content ?? '',
        created_at: Math.max(Math.floor(Date.now() / 1000), (head?.created_at ?? 0) + 1, minCreatedAt.get(pk) ?? 0),
      });
    } catch (error) {
      dropChanges(pk, applied);
      throw error;
    }
    if (nostrStore.getState().pubkey !== pk || nostr.signer !== signer ||
      event.pubkey !== pk || !verifyEvent(event)) return dropChanges(pk, applied);

    const earlier = head && head === publishedHeads.get(pk) ? publishedBases.get(pk) : undefined;
    publishedBases.set(pk, {
      base: earlier?.base ?? head?.created_at ?? 0,
      changes: new Map([...(earlier?.changes ?? []), ...applied]),
    });
    publishedHeads.set(pk, event);
    // Not awaited: the backend keeps the list and retries relays which are down.
    void nostr.publish(event).catch((error) => {
      console.error('[follows] Could not publish the follow list:', error);
      if (publishedHeads.get(pk) === event) publishedHeads.delete(pk);
      showFollows(pk);
    });
  }

  for (const [target, change] of applied) {
    if (change.following) rememberContact(pk, target, change.name);
  }
  dropChanges(pk, applied);
}

/**
 * Invalidate cache for a pubkey (force refetch)
 */
export function invalidateFollows(pubkey: string): void {
  followsCache.delete(pubkey);
  fetchFollows(pubkey);
}
