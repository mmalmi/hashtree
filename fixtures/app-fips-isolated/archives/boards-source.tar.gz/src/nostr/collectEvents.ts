import type { Event, Filter } from 'nostr-tools';
import { nostr } from './client';

/** How long relays may stay quiet after an event before a lookup answers with what it has. */
export const LOOKUP_QUIET_MS = 300;

/**
 * Events for a one-off lookup. Answers once relays go quiet after the first event,
 * so one slow or silent relay cannot hold back what the others already sent.
 */
export function collectEvents(filter: Filter | Filter[], limitMs = 5000): Promise<Event[]> {
  return new Promise(resolve => {
    const events = new Map<string, Event>();
    let quiet: ReturnType<typeof setTimeout> | undefined;
    let settled = false;
    const subscription = nostr.subscribe(filter, { closeAfterHistory: true });
    const finish = () => {
      if (settled) return;
      settled = true;
      clearTimeout(quiet);
      clearTimeout(limit);
      subscription.stop();
      resolve([...events.values()]);
    };
    const limit = setTimeout(finish, limitMs);
    subscription.on('event', event => {
      events.set(event.id, event);
      clearTimeout(quiet);
      quiet = setTimeout(finish, LOOKUP_QUIET_MS);
    });
    subscription.on('history', finish);
  });
}
