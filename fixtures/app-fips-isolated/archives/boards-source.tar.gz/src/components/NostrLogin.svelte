<script lang="ts">
  import { navigate } from '../utils/navigate';
  import { nostrStore, generateNewKey } from '../nostr';
  import { isFilesApp } from '../appType';
  import { Avatar } from './User';

  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let npub = $derived($nostrStore.npub);
  let pubkey = $derived($nostrStore.pubkey);

  function goToProfile() {
    if (!npub) return;
    navigate(`/${npub}/profile`);
  }

  async function handleGenerate() {
    await generateNewKey();
  }
</script>

{#if isLoggedIn && pubkey}
  <!-- Logged in: just show avatar that links to profile (double-click for accounts) -->
  <button
    onclick={goToProfile}
    ondblclick={() => navigate('/users')}
    class="bg-transparent border-none cursor-pointer p-0"
    title="My Profile (double-click for users)"
  >
    <Avatar pubkey={pubkey} size={36} />
  </button>
{:else if isFilesApp()}
  <button
    onclick={() => navigate('/')}
    class="btn-circle btn-ghost"
    title="Set up profile"
    aria-label="Set up profile"
  >
    <span class="i-lucide-user-plus"></span>
  </button>
{:else}
  <div class="flex flex-wrap gap-2">
    <button onclick={handleGenerate} class="btn-success text-sm">Create account</button>
    <button onclick={() => navigate('/users')} class="btn-ghost text-sm">Already have an account?</button>
  </div>
{/if}
