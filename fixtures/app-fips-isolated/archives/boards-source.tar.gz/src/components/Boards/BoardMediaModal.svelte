<script lang="ts">
  import type { BoardCardAttachment } from '../../lib/boards';
  import {
    attachmentCid,
    attachmentImageSrc,
    cardAttachmentUrl,
    handleAttachmentImageError,
    isAudioAttachment,
    isImageAttachment,
    isVideoAttachment,
  } from '../../lib/boards';
  import MediaPlayer from '../Viewer/MediaPlayer.svelte';

  interface Props {
    attachment: BoardCardAttachment | null;
    localAttachmentPreviewUrls: Record<string, string>;
    onClose: () => void;
  }

  let { attachment, localAttachmentPreviewUrls, onClose }: Props = $props();
</script>

{#if attachment}
  {@const mediaAttachmentUrl = cardAttachmentUrl(attachment)}
  {@const mediaAttachmentImageUrl = attachmentImageSrc(attachment, localAttachmentPreviewUrls)}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div class="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4" data-modal-backdrop role="dialog" tabindex="-1" aria-modal="true" aria-label="Attachment preview" onclick={onClose}>
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div class="w-full max-w-5xl bg-surface-1 border border-surface-3 rounded-lg shadow-lg p-4 space-y-3" onclick={(event) => event.stopPropagation()}>
      <div class="flex items-center justify-between gap-3">
        <h3 class="text-lg font-semibold">Attachment preview</h3>
        <div class="flex items-center gap-2">
          {#if mediaAttachmentUrl}
            <a class="btn-ghost text-sm" href={mediaAttachmentUrl} target="_blank" rel="noreferrer" title={attachment.displayName}>Open file</a>
          {/if}
          <button type="button" class="btn-circle btn-ghost" onclick={onClose} aria-label="Close attachment preview">
            <span class="i-lucide-x"></span>
          </button>
        </div>
      </div>
      <div class="bg-surface-0 border border-surface-3 rounded-lg overflow-hidden h-[70vh] min-h-72">
        {#if isImageAttachment(attachment) && mediaAttachmentImageUrl}
          <div class="h-full w-full flex items-center justify-center p-3">
            <img src={mediaAttachmentImageUrl} alt={attachment.displayName} class="max-w-full max-h-full object-contain" onerror={(event) => handleAttachmentImageError(event as Event, attachment)} />
          </div>
        {:else if isVideoAttachment(attachment)}
          {@const previewCid = attachmentCid(attachment)}
          {#if previewCid}<MediaPlayer cid={previewCid} fileName={attachment.displayName || attachment.fileName} type="video" />{:else}<div class="h-full flex items-center justify-center text-text-3 text-sm">Unable to open preview for this file.</div>{/if}
        {:else if isAudioAttachment(attachment)}
          {@const previewCid = attachmentCid(attachment)}
          {#if previewCid}<MediaPlayer cid={previewCid} fileName={attachment.displayName || attachment.fileName} type="audio" />{:else}<div class="h-full flex items-center justify-center text-text-3 text-sm">Unable to open preview for this file.</div>{/if}
        {:else}
          <div class="h-full flex items-center justify-center text-text-3 text-sm">Preview not available for this attachment.</div>
        {/if}
      </div>
    </div>
  </div>
{/if}
