<script lang="ts">
  import type { BoardCardAttachment, BoardCardComment, BoardColumn } from '../../lib/boards';
  import {
    attachmentImageSrc,
    cardAttachmentUrl,
    formatAttachmentSize,
    formatCommentTimestamp,
    handleAttachmentImageError,
    isImageAttachment,
    isModalPreviewAttachment,
    npubToPubkey,
    renderMarkdown,
  } from '../../lib/boards';
  import { shortNpub } from '../../utils/format';
  import { Avatar, Name } from '../User';

  export interface CommentDraftAttachment {
    id: string;
    displayName: string;
    previewUrl: string | null;
  }

  export interface ViewedCardState {
    column: BoardColumn;
    card: {
      id: string;
      title: string;
      description: string;
      assigneeNpubs: string[];
      attachments: BoardCardAttachment[];
      comments: BoardCardComment[];
    };
  }

  interface Props {
    open: boolean;
    state: ViewedCardState | null;
    canWrite: boolean;
    uploading: boolean;
    commentMarkdown: string;
    commentAttachments: CommentDraftAttachment[];
    commentSubmitting: boolean;
    commentError: string;
    localAttachmentPreviewUrls: Record<string, string>;
    roleLabel: (npub: string) => string;
    onClose: () => void;
    onOpenAttachmentPreview: (attachment: BoardCardAttachment) => void;
    onRemoveAttachment: (columnId: string, cardId: string, attachmentId: string) => void;
    onCommentMarkdownChange: (value: string) => void;
    onTriggerCommentAttachment: () => void;
    onSubmitComment: () => void;
    onRemoveCommentDraftAttachment: (attachmentId: string) => void;
    onAttachToCard: () => void;
    onEditCard: () => void;
    onRemoveCard: () => void;
  }

  let {
    open,
    state,
    canWrite,
    uploading,
    commentMarkdown,
    commentAttachments,
    commentSubmitting,
    commentError,
    localAttachmentPreviewUrls,
    roleLabel,
    onClose,
    onOpenAttachmentPreview,
    onRemoveAttachment,
    onCommentMarkdownChange,
    onTriggerCommentAttachment,
    onSubmitComment,
    onRemoveCommentDraftAttachment,
    onAttachToCard,
    onEditCard,
    onRemoveCard,
  }: Props = $props();
</script>

{#if open && state}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div class="fixed inset-0 z-[55] flex items-center justify-center bg-black/70 p-4" data-modal-backdrop role="dialog" tabindex="-1" aria-modal="true" aria-label="Card details" onclick={onClose}>
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div class="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-surface-1 rounded-lg shadow-lg border border-surface-3 p-5 space-y-4" onclick={(event) => event.stopPropagation()}>
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <h3 class="text-lg font-semibold break-words">{state.card.title}</h3>
          <p class="text-xs text-text-3 mt-1">in {state.column.title}</p>
        </div>
        <button type="button" class="btn-circle btn-ghost" onclick={onClose} aria-label="Close card details">
          <span class="i-lucide-x"></span>
        </button>
      </div>

      {#if state.card.description}<p class="text-sm whitespace-pre-wrap">{state.card.description}</p>{:else}<p class="text-sm text-text-3">No description.</p>{/if}

      <div class="space-y-2">
        <div class="text-sm font-medium">Assignees</div>
        {#if state.card.assigneeNpubs.length === 0}
          <p class="text-xs text-text-3">No assignees.</p>
        {:else}
          <div class="flex flex-wrap gap-2">
            {#each state.card.assigneeNpubs as assigneeNpub (assigneeNpub)}
              {@const assigneePubkey = npubToPubkey(assigneeNpub)}
              <span class="inline-flex items-center gap-1 rounded-full border border-surface-3 bg-surface-0 px-2 py-0.5 text-xs">
                {#if assigneePubkey}<Avatar pubkey={assigneePubkey} size={16} /><Name pubkey={assigneePubkey} class="truncate max-w-28" />{:else}<span class="font-mono" title={assigneeNpub}>{shortNpub(assigneeNpub)}</span>{/if}
                <span class="text-text-3">{roleLabel(assigneeNpub)}</span>
              </span>
            {/each}
          </div>
        {/if}
      </div>

      <div class="space-y-2">
        <div class="text-sm font-medium">Attachments</div>
        {#if state.card.attachments.length === 0}
          <p class="text-xs text-text-3">No attachments.</p>
        {:else}
          <div class="space-y-2">
            {#each state.card.attachments as attachment (attachment.id)}
              {@const attachmentUrl = cardAttachmentUrl(attachment)}
              {@const attachmentImageUrl = attachmentImageSrc(attachment, localAttachmentPreviewUrls)}
              <div class="rounded-md border border-surface-3 bg-surface-0 px-2 py-2 space-y-2">
                {#if isImageAttachment(attachment) && attachmentImageUrl}
                  <button type="button" class="block w-full bg-transparent border-none p-0 cursor-zoom-in" title={attachment.displayName} onclick={() => onOpenAttachmentPreview(attachment)}>
                    <img class="w-full max-h-56 object-cover rounded border border-surface-3" src={attachmentImageUrl} alt={attachment.displayName} onerror={(event) => handleAttachmentImageError(event as Event, attachment)} />
                  </button>
                {/if}
                <div class="flex items-center justify-between gap-2">
                  {#if isModalPreviewAttachment(attachment) && (attachmentUrl || attachmentImageUrl)}
                    <button type="button" class="text-xs text-accent hover:underline truncate bg-transparent border-none p-0 text-left" title={attachment.displayName} onclick={() => onOpenAttachmentPreview(attachment)}>{attachment.displayName}</button>
                  {:else if attachmentUrl}
                    <a class="text-xs text-accent hover:underline truncate" href={attachmentUrl} target="_blank" rel="noreferrer" title={attachment.displayName}>{attachment.displayName}</a>
                  {:else}
                    <span class="text-xs text-text-3 truncate">{attachment.displayName}</span>
                  {/if}
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] text-text-3">{formatAttachmentSize(attachment.size)}</span>
                    {#if canWrite}
                      <button type="button" class="btn-circle btn-ghost text-danger" title={`Remove ${attachment.displayName}`} onclick={() => onRemoveAttachment(state.column.id, state.card.id, attachment.id)}>
                        <span class="i-lucide-x text-[10px]"></span>
                      </button>
                    {/if}
                  </div>
                </div>
              </div>
            {/each}
          </div>
        {/if}
      </div>

      <div class="space-y-2">
        <div class="text-sm font-medium">Comments</div>
        {#if state.card.comments.length === 0}
          <p class="text-xs text-text-3">No comments yet.</p>
        {:else}
          <div class="space-y-2">
            {#each state.card.comments as comment (comment.id)}
              {@const commentAuthorPubkey = npubToPubkey(comment.authorNpub)}
              <article class="rounded-md border border-surface-3 bg-surface-0 p-3 space-y-2" data-testid={`board-comment-${comment.id}`}>
                <div class="flex items-center justify-between gap-2 text-[11px] text-text-3">
                  <div class="min-w-0 inline-flex items-center gap-2">
                    {#if commentAuthorPubkey}<Avatar pubkey={commentAuthorPubkey} size={18} /><Name pubkey={commentAuthorPubkey} class="text-xs text-text-2 truncate" />{:else}<span class="font-mono truncate" title={comment.authorNpub}>{shortNpub(comment.authorNpub)}</span>{/if}
                  </div>
                  <span class="shrink-0">{formatCommentTimestamp(comment.createdAt)}</span>
                </div>
                {#if comment.markdown}
                  <div class="text-sm break-words leading-relaxed [&_a]:text-accent [&_a:hover]:underline [&_code]:bg-surface-2 [&_code]:rounded [&_code]:px-1 [&_pre]:bg-surface-2 [&_pre]:rounded [&_pre]:p-2">
                    <!-- eslint-disable-next-line svelte/no-at-html-tags -- markdown is sanitized with DOMPurify in renderMarkdown -->
                    {@html renderMarkdown(comment.markdown)}
                  </div>
                {/if}
                {#if comment.attachments.length > 0}
                  <div class="grid grid-cols-2 gap-2">
                    {#each comment.attachments as commentAttachment (commentAttachment.id)}
                      {@const commentAttachmentUrl = cardAttachmentUrl(commentAttachment)}
                      {@const commentAttachmentImageUrl = attachmentImageSrc(commentAttachment, localAttachmentPreviewUrls)}
                      <div class="rounded-md border border-surface-3 bg-surface-1 p-2 space-y-1">
                        {#if isImageAttachment(commentAttachment) && commentAttachmentImageUrl}
                          <button type="button" class="block w-full bg-transparent border-none p-0 cursor-zoom-in" onclick={() => onOpenAttachmentPreview(commentAttachment)} title={commentAttachment.displayName}>
                            <img class="w-full h-20 object-cover rounded border border-surface-3" src={commentAttachmentImageUrl} alt={commentAttachment.displayName} onerror={(event) => handleAttachmentImageError(event as Event, commentAttachment)} />
                          </button>
                        {/if}
                        <div class="flex items-center justify-between gap-2">
                          {#if isModalPreviewAttachment(commentAttachment) && (commentAttachmentUrl || commentAttachmentImageUrl)}
                            <button type="button" class="text-xs text-accent hover:underline truncate bg-transparent border-none p-0 text-left" onclick={() => onOpenAttachmentPreview(commentAttachment)} title={commentAttachment.displayName}>{commentAttachment.displayName}</button>
                          {:else if commentAttachmentUrl}
                            <a class="text-xs text-accent hover:underline truncate" href={commentAttachmentUrl} target="_blank" rel="noreferrer" title={commentAttachment.displayName}>{commentAttachment.displayName}</a>
                          {:else}
                            <span class="text-xs text-text-3 truncate">{commentAttachment.displayName}</span>
                          {/if}
                          <span class="text-[10px] text-text-3 shrink-0">{formatAttachmentSize(commentAttachment.size)}</span>
                        </div>
                      </div>
                    {/each}
                  </div>
                {/if}
              </article>
            {/each}
          </div>
        {/if}
      </div>

      {#if canWrite}
        <div class="space-y-2 border-t border-surface-3 pt-3">
          <div class="relative rounded-lg border border-surface-3 bg-surface-0">
            <textarea id="board-card-comment-markdown" aria-label="Add comment" class="w-full text-sm min-h-24 rounded-lg bg-transparent px-3 py-2 pb-14 resize-y focus:outline-none focus:ring-2 focus:ring-accent/40" value={commentMarkdown} oninput={(event) => onCommentMarkdownChange((event.currentTarget as HTMLTextAreaElement).value)} placeholder="Add comment."></textarea>
            <div class="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 px-2 py-2 border-t border-surface-3 bg-surface-0/95 rounded-b-lg">
              <button type="button" class="btn-ghost" onclick={onTriggerCommentAttachment}><span class="i-lucide-paperclip mr-1"></span>Attach files</button>
              <button type="button" class="btn-primary" onclick={onSubmitComment} disabled={commentSubmitting || (!commentMarkdown.trim() && commentAttachments.length === 0)}>
                {#if commentSubmitting}<span class="i-lucide-loader-2 animate-spin mr-1"></span>{/if}
                Add comment
              </button>
            </div>
          </div>
          {#if commentAttachments.length > 0}
            <div class="flex flex-wrap gap-2">
              {#each commentAttachments as draftAttachment (draftAttachment.id)}
                <div class="rounded-md border border-surface-3 bg-surface-0 px-2 py-2 max-w-44">
                  {#if draftAttachment.previewUrl}<img class="w-full h-20 object-cover rounded border border-surface-3 mb-1" src={draftAttachment.previewUrl} alt={draftAttachment.displayName} />{/if}
                  <div class="flex items-center justify-between gap-2">
                    <span class="text-xs truncate" title={draftAttachment.displayName}>{draftAttachment.displayName}</span>
                    <button type="button" class="btn-circle btn-ghost text-danger" title={`Remove ${draftAttachment.displayName}`} onclick={() => onRemoveCommentDraftAttachment(draftAttachment.id)}>
                      <span class="i-lucide-x text-[10px]"></span>
                    </button>
                  </div>
                </div>
              {/each}
            </div>
          {/if}
          {#if commentError}<p class="text-xs text-danger">{commentError}</p>{/if}
        </div>
        <div class="flex items-center justify-end gap-2 pt-2 border-t border-surface-3">
          <button type="button" class="btn-ghost" onclick={onAttachToCard} disabled={uploading}>
            {#if uploading}<span class="i-lucide-loader-2 animate-spin mr-1"></span>{:else}<span class="i-lucide-paperclip mr-1"></span>{/if}
            Attach file
          </button>
          <button type="button" class="btn-ghost" onclick={onEditCard}><span class="i-lucide-pencil mr-1"></span>Edit card</button>
          <button type="button" class="btn-danger" onclick={onRemoveCard}><span class="i-lucide-trash-2 mr-1"></span>Delete card</button>
        </div>
      {/if}
    </div>
  </div>
{/if}
