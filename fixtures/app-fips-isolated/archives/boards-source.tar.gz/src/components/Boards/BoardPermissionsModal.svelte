<script lang="ts">
  import type { TreeVisibility } from '@hashtree/core';
  import NpubAccessModal from '../Modals/NpubAccessModal.svelte';
  import type { AccessSection, RequestAccessOptions } from '../Modals/NpubAccessModal.types';
  import VisibilityPicker from '@iris/hashtree-app/VisibilityPicker.svelte';
  import VisibilityIcon from '../VisibilityIcon.svelte';

  interface Props {
    open: boolean;
    intro: string;
    sections: AccessSection[];
    canManage: boolean;
    requestAccess: RequestAccessOptions | null;
    visibility: TreeVisibility;
    visibilityDraft: TreeVisibility;
    visibilityError: string;
    savingVisibility: boolean;
    isOwnBoard: boolean;
    validateAdd: (npub: string, role: string) => string | null;
    onAdd: (npub: string, role: string) => Promise<string | void>;
    onRemove: (role: string, npub: string) => Promise<string | void>;
    onClose: () => void;
    onVisibilityDraftChange: (value: TreeVisibility) => void;
    onUpdateVisibility: () => void;
  }

  let {
    open,
    intro,
    sections,
    canManage,
    requestAccess,
    visibility,
    visibilityDraft,
    visibilityError,
    savingVisibility,
    isOwnBoard,
    validateAdd,
    onAdd,
    onRemove,
    onClose,
    onVisibilityDraftChange,
    onUpdateVisibility,
  }: Props = $props();
</script>

<NpubAccessModal
  {open}
  onClose={onClose}
  title="Board Permissions"
  {intro}
  {sections}
  canEdit={canManage}
  {validateAdd}
  onAdd={onAdd}
  onRemove={onRemove}
  initialSectionId="writer"
  addPromptLabel="Assign role"
  requestAccess={requestAccess}
  panelClass="w-full max-w-lg mx-4"
  sectionsClass="grid grid-cols-1 gap-3 sm:grid-cols-2"
>
  {#snippet beforeSections()}
    <div class="rounded-lg border border-surface-3 bg-surface-2 px-3 py-3 space-y-3">
      <div class="flex items-center justify-between gap-3">
        <div>
          <div class="text-sm font-medium">Visibility</div>
          <p class="text-xs text-text-3 mt-1">This controls who can open the shared board link.</p>
        </div>
        <div class="inline-flex items-center gap-2 text-xs text-text-3">
          <VisibilityIcon {visibility} class="text-sm" />
          <span>{visibility}</span>
        </div>
      </div>

      {#if isOwnBoard}
        <VisibilityPicker value={visibilityDraft} onchange={onVisibilityDraftChange} />
        <div class="flex items-center justify-between gap-3">
          <p class="text-xs text-text-3">Public boards are open to everyone. Link-visible boards need the URL key. Private boards are owner-only.</p>
          <button class="btn-primary shrink-0" onclick={onUpdateVisibility} disabled={savingVisibility || visibilityDraft === visibility}>
            {#if savingVisibility}Updating...{:else if visibilityDraft === visibility}Current{:else}Update Visibility{/if}
          </button>
        </div>
        {#if visibilityError}<p class="text-xs text-danger">{visibilityError}</p>{/if}
      {:else}
        <p class="text-xs text-text-3">Only the board owner can change visibility for the shared board link.</p>
      {/if}
    </div>
  {/snippet}
</NpubAccessModal>
