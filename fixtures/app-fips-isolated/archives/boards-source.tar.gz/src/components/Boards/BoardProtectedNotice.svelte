<script lang="ts">
  import type { TreeVisibility } from '@hashtree/core';

  interface Props {
    resolvedVisibility: TreeVisibility | undefined;
    linkKey: string | null;
  }

  let { resolvedVisibility, linkKey }: Props = $props();
</script>

<div class="flex-1 flex items-center justify-center p-8">
  <div class="text-center">
    <div class="inline-flex items-center justify-center mb-4">
      {#if resolvedVisibility === 'link-visible'}
        {#if linkKey}
          <span class="i-lucide-key-round text-3xl text-danger"></span>
        {:else}
          <span class="relative inline-block shrink-0 text-3xl text-text-3">
            <span class="i-lucide-link"></span>
            <span class="i-lucide-lock absolute -bottom-0.5 -right-1.5 text-[0.6em]"></span>
          </span>
        {/if}
      {:else}
        <span class="i-lucide-lock text-3xl text-text-3"></span>
      {/if}
    </div>
    <div class="text-text-2 font-medium mb-2">
      {#if resolvedVisibility === 'link-visible'}
        {linkKey ? 'Invalid Link Key' : 'Link Required'}
      {:else}
        Private Board
      {/if}
    </div>
    <div class="text-text-3 text-sm max-w-xs mx-auto">
      {#if resolvedVisibility === 'link-visible'}
        {linkKey
          ? 'The link key provided is invalid or has expired. Ask the owner for a new link.'
          : 'This board requires a special link to access. Ask the owner for the link with the access key.'}
      {:else}
        This board is private and can only be accessed by its owner.
      {/if}
    </div>
  </div>
</div>
