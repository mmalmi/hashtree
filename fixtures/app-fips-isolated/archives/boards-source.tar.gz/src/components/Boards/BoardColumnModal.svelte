<script lang="ts">
  import Modal from '../ui/Modal.svelte';

  interface Props {
    open: boolean;
    mode: 'create' | 'edit';
    title: string;
    error: string;
    onTitleChange: (title: string) => void;
    onClose: () => void;
    onSubmit: () => void;
    onRemove: () => void;
  }

  let { open, mode, title, error, onTitleChange, onClose, onSubmit, onRemove }: Props = $props();
  let titleInputRef = $state<HTMLInputElement | null>(null);

  $effect(() => {
    if (!open || !titleInputRef) return;
    titleInputRef.focus();
    if (mode === 'edit') titleInputRef.select();
  });

  function handleSubmit(event: SubmitEvent) {
    event.preventDefault();
    onSubmit();
  }
</script>

<Modal {open} onClose={onClose} label={mode === 'create' ? 'Create Column' : 'Edit Column'} panelClass="w-full max-w-md mx-4">
  <form class="bg-surface-1 rounded-lg shadow-lg border border-surface-3 p-5 space-y-4" onsubmit={handleSubmit}>
    <div class="flex items-center justify-between">
      <h3 class="text-lg font-semibold">{mode === 'create' ? 'Create Column' : 'Edit Column'}</h3>
      <button type="button" class="btn-circle btn-ghost" onclick={onClose} aria-label="Close column dialog">
        <span class="i-lucide-x"></span>
      </button>
    </div>

    <div class="space-y-2">
      <label class="text-sm font-medium" for="board-column-title">Column title</label>
      <input
        id="board-column-title"
        class="input w-full text-sm"
        bind:this={titleInputRef}
        value={title}
        oninput={(event) => onTitleChange((event.currentTarget as HTMLInputElement).value)}
        placeholder="Backlog"
      />
      {#if error}<p class="text-xs text-danger">{error}</p>{/if}
    </div>

    <div class="flex items-center justify-between gap-2">
      {#if mode === 'edit'}
        <button type="button" class="btn-danger" aria-label="Delete column" onclick={onRemove}>
          <span class="i-lucide-trash-2 mr-1"></span>
          Delete column
        </button>
      {:else}
        <span></span>
      {/if}
      <div class="flex items-center gap-2">
        <button type="button" class="btn-ghost" onclick={onClose}>Cancel</button>
        <button type="submit" class="btn-primary">{mode === 'create' ? 'Create Column' : 'Save Column'}</button>
      </div>
    </div>
  </form>
</Modal>
