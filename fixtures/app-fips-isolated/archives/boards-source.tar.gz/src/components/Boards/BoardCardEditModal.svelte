<script lang="ts">
  import type { BoardCardAttachment } from '../../lib/boards';
  import {
    attachmentImageSrc,
    formatAttachmentSize,
    handleAttachmentImageError,
    isImageAttachment,
    npubToPubkey,
  } from '../../lib/boards';
  import { shortNpub } from '../../utils/format';
  import { Avatar, Name } from '../User';

  interface Props {
    open: boolean;
    mode: 'create' | 'edit';
    title: string;
    description: string;
    error: string;
    uploading: boolean;
    attachments: BoardCardAttachment[];
    assigneeNpubs: string[];
    boardMemberNpubs: string[];
    localAttachmentPreviewUrls: Record<string, string>;
    roleLabel: (npub: string) => string;
    onTitleChange: (value: string) => void;
    onDescriptionChange: (value: string) => void;
    onToggleAssignee: (npub: string, checked: boolean) => void;
    onAttach: () => void;
    onRemoveAttachment: (attachmentId: string) => void;
    onClose: () => void;
    onSubmit: () => void;
  }

  let {
    open,
    mode,
    title,
    description,
    error,
    uploading,
    attachments,
    assigneeNpubs,
    boardMemberNpubs,
    localAttachmentPreviewUrls,
    roleLabel,
    onTitleChange,
    onDescriptionChange,
    onToggleAssignee,
    onAttach,
    onRemoveAttachment,
    onClose,
    onSubmit,
  }: Props = $props();
  let titleInputRef = $state<HTMLInputElement | null>(null);

  $effect(() => {
    if (!open || !titleInputRef) return;
    titleInputRef.focus();
    if (mode === 'edit') titleInputRef.select();
  });

  function handleSubmit(event: SubmitEvent) {
    event.preventDefault();
    onSubmit();
  }
</script>

{#if open}
  <!-- svelte-ignore a11y_click_events_have_key_events -->
  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" data-modal-backdrop onclick={onClose}>
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div class="w-full max-w-lg mx-4" onclick={(event) => event.stopPropagation()}>
      <form class="bg-surface-1 rounded-lg shadow-lg border border-surface-3 p-5 space-y-4 max-h-[90vh] overflow-y-auto" onsubmit={handleSubmit}>
        <div class="flex items-center justify-between">
          <h3 class="text-lg font-semibold">{mode === 'create' ? 'Create Card' : 'Edit Card'}</h3>
          <button type="button" class="btn-circle btn-ghost" onclick={onClose} aria-label="Close card dialog">
            <span class="i-lucide-x"></span>
          </button>
        </div>

        <div class="space-y-2">
          <label class="text-sm font-medium" for="board-card-title">Card title</label>
          <input id="board-card-title" aria-label="Card title" class="input w-full text-sm" bind:this={titleInputRef} value={title} oninput={(event) => onTitleChange((event.currentTarget as HTMLInputElement).value)} placeholder="Task title" />
        </div>

        <div class="space-y-2">
          <label class="text-sm font-medium" for="board-card-description">Card description</label>
          <textarea id="board-card-description" aria-label="Card description" class="w-full text-sm min-h-32 rounded-lg border border-surface-3 bg-surface-0 px-3 py-2 resize-y focus:outline-none focus:ring-2 focus:ring-accent/40" value={description} oninput={(event) => onDescriptionChange((event.currentTarget as HTMLTextAreaElement).value)} placeholder="Details..."></textarea>
          {#if error}<p class="text-xs text-danger">{error}</p>{/if}
        </div>

        <div class="space-y-2">
          <div class="flex items-center justify-between gap-2">
            <div class="text-sm font-medium">Attachments</div>
            <button type="button" class="btn-ghost" onclick={onAttach} disabled={uploading}>
              {#if uploading}<span class="i-lucide-loader-2 animate-spin mr-1"></span>{:else}<span class="i-lucide-paperclip mr-1"></span>{/if}
              Attach files
            </button>
          </div>
          {#if attachments.length === 0}
            <p class="text-xs text-text-3">No attachments.</p>
          {:else}
            <div class="max-h-44 overflow-auto rounded-lg border border-surface-3 bg-surface-0 p-2 space-y-2">
              {#each attachments as draftAttachment (draftAttachment.id)}
                {@const draftPreviewUrl = attachmentImageSrc(draftAttachment, localAttachmentPreviewUrls)}
                <div class="rounded-md border border-surface-3 bg-surface-1 px-2 py-2 space-y-2">
                  {#if isImageAttachment(draftAttachment) && draftPreviewUrl}
                    <img class="w-full h-24 object-cover rounded border border-surface-3" src={draftPreviewUrl} alt={draftAttachment.displayName} onerror={(event) => handleAttachmentImageError(event as Event, draftAttachment)} />
                  {/if}
                  <div class="flex items-center justify-between gap-2">
                    <span class="text-xs truncate" title={draftAttachment.displayName}>{draftAttachment.displayName}</span>
                    <div class="flex items-center gap-2 shrink-0">
                      <span class="text-[10px] text-text-3">{formatAttachmentSize(draftAttachment.size)}</span>
                      <button type="button" class="btn-circle btn-ghost text-danger" title={`Remove ${draftAttachment.displayName}`} onclick={() => onRemoveAttachment(draftAttachment.id)}>
                        <span class="i-lucide-x text-[10px]"></span>
                      </button>
                    </div>
                  </div>
                </div>
              {/each}
            </div>
          {/if}
        </div>

        <div class="space-y-2">
          <div class="text-sm font-medium">Assignees</div>
          {#if boardMemberNpubs.length === 0}
            <p class="text-xs text-text-3">No board members available.</p>
          {:else}
            <div class="max-h-40 overflow-auto rounded-lg border border-surface-3 bg-surface-0 p-2 space-y-1">
              {#each boardMemberNpubs as memberNpub (memberNpub)}
                {@const memberPubkey = npubToPubkey(memberNpub)}
                <label class="flex items-center justify-between gap-2 px-1 py-1 rounded hover:bg-surface-2 cursor-pointer">
                  <span class="flex items-center gap-2 min-w-0">
                    <input type="checkbox" class="checkbox checkbox-xs" checked={assigneeNpubs.includes(memberNpub)} onchange={(event) => onToggleAssignee(memberNpub, (event.currentTarget as HTMLInputElement).checked)} />
                    {#if memberPubkey}
                      <Avatar pubkey={memberPubkey} size={18} />
                      <Name pubkey={memberPubkey} class="text-xs truncate" />
                    {:else}
                      <span class="text-xs font-mono truncate" title={memberNpub}>{shortNpub(memberNpub)}</span>
                    {/if}
                  </span>
                  <span class="text-[10px] text-text-3">{roleLabel(memberNpub)}</span>
                </label>
              {/each}
            </div>
          {/if}
        </div>

        <div class="flex justify-end gap-2">
          <button type="button" class="btn-ghost" onclick={onClose}>Cancel</button>
          <button type="submit" class="btn-primary">{mode === 'create' ? 'Create Card' : 'Save Card'}</button>
        </div>
      </form>
    </div>
  </div>
{/if}
