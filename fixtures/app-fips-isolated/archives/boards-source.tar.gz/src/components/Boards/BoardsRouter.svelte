<script lang="ts">
  import BoardsHome from './BoardsHome.svelte';
  import BoardView from './BoardView.svelte';
  import SettingsLayout from '../settings/SettingsLayout.svelte';
  import EditProfilePage from '../EditProfilePage.svelte';
  import UsersPage from '../UsersPage.svelte';
  import FollowsPage from '../FollowsPage.svelte';
  import FollowersPage from '../FollowersPage.svelte';
  import ProfileView from '../ProfileView.svelte';
  import { matchBoardsRoute } from './routes';

  interface Props {
    currentPath: string;
  }

  let { currentPath }: Props = $props();

  let matchedRoute = $derived(matchBoardsRoute(currentPath));
</script>

{#if matchedRoute.key === 'settings'}
  <SettingsLayout />
{:else if matchedRoute.key === 'users'}
  <UsersPage />
{:else if matchedRoute.key === 'edit-profile'}
  <EditProfilePage npub={matchedRoute.params.npub} />
{:else if matchedRoute.key === 'follows'}
  <FollowsPage npub={matchedRoute.params.npub} />
{:else if matchedRoute.key === 'followers'}
  <FollowersPage npub={matchedRoute.params.npub} />
{:else if matchedRoute.key === 'profile'}
  <ProfileView npub={matchedRoute.params.npub} />
{:else if matchedRoute.key === 'board'}
  <BoardView npub={matchedRoute.params.npub} treeName={matchedRoute.params.treeName} wild={matchedRoute.params.wild} />
{:else}
  <BoardsHome npub={matchedRoute.params.npub} />
{/if}
