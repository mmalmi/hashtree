<script lang="ts">
  import type { CID, TreeVisibility } from '@hashtree/core';
  import { toHex } from '@hashtree/core';
  import { tick } from 'svelte';
  import BoardCardDetailsModal, { type CommentDraftAttachment } from './BoardCardDetailsModal.svelte';
  import BoardCardEditModal from './BoardCardEditModal.svelte';
  import BoardColumnModal from './BoardColumnModal.svelte';
  import BoardMediaModal from './BoardMediaModal.svelte';
  import BoardPermissionsModal from './BoardPermissionsModal.svelte';
  import BoardProtectedNotice from './BoardProtectedNotice.svelte';
  import BoardWorkspace from './BoardWorkspace.svelte';
  import { open as openShareModal } from '../Modals/ShareModal.svelte';
  import type { AccessSection, RequestAccessOptions } from '../Modals/NpubAccessModal.types';
  import {
    addBoardCard,
    addBoardColumn,
    addBoardPermission,
    buildBoardVisibilityQueryString,
    buildUpdatedBoardRootCid,
    canManageBoard,
    canWriteBoard,
    createBoardId,
    createInitialBoardPermissions,
    createInitialBoardTombstones,
    isImageMimeType,
    isProtectedBoardWithoutAccess as shouldShowProtectedNotice,
    isValidNpub,
    loadBoardFromDirectory,
    loadParticipantBoardData,
    mergeBoardSnapshots,
    moveBoardCard as moveBoardCardState,
    moveBoardColumn as moveBoardColumnState,
    mutateBoardCard,
    npubToPubkey,
    removeBoardCard,
    removeBoardColumn,
    removeBoardPermission,
    resolveBoardDirectory,
    resolveBoardPublishLabels,
    resolveBoardVisibility,
    resolveBoardVisibilityLinkKey,
    sanitizeAttachmentFileName,
    updateBoardColumnTitle,
    type BoardCard,
    type BoardCardAttachment,
    type BoardDirectoryData,
    type BoardEditResult,
    type BoardPermissions,
    type BoardRole,
    type BoardState,
    type BoardTombstones,
  } from '../../lib/boards';
  import { getTree } from '../../store';
  import { linkKeyUtils, nostrStore, saveHashtree } from '../../nostr';
  import { updateLocalRootCache, getCachedVisibility } from '../../treeRootCache';
  import { treeRootRegistry } from '../../TreeRootRegistry';
  import { createTreesStore, getLinkKey, getTreeRoot, storeLinkKey, treeRootStore, routeStore, type TreeEntry } from '../../stores';
  import { onLinkKeyUpdate } from '../../stores/trees';
  import { navigate } from '../../lib/router.svelte';

  interface Props {
    npub: string;
    treeName: string;
    wild?: string;
  }

  let { npub: ownerNpub, treeName, wild = '' }: Props = $props();

  const participantLoadTimeoutMs = 1800;

  let userNpub = $derived($nostrStore.npub);
  let ownerPubkey = $derived(ownerNpub ? npubToPubkey(ownerNpub) : null);
  let boardPath = $derived(wild ? wild.split('/').filter(Boolean) : []);
  let boardPathKey = $derived(boardPath.join('/'));
  let linkKey = $derived($routeStore.params.get('k'));
  let isOwnBoard = $derived(!!userNpub && userNpub === ownerNpub);

  let treesStore = $derived(createTreesStore(ownerNpub || null));
  let trees = $state<TreeEntry[]>([]);
  let cachedVisibility = $derived<TreeVisibility | undefined>(undefined);
  let reloadNonce = $state(0);

  let board = $state<BoardState | null>(null);
  let permissions = $state<BoardPermissions | null>(null);
  let tombstones = $state<BoardTombstones>(createInitialBoardTombstones());
  let error = $state('');
  let loadingBoard = $state(false);

  let treeEntry = $derived.by(() => trees.find((entry) => entry.name === treeName));
  let visibility = $derived<TreeVisibility>(resolveBoardVisibility(treeEntry?.visibility, cachedVisibility) ?? 'public');
  let resolvedVisibility = $derived(resolveBoardVisibility(treeEntry?.visibility, cachedVisibility));
  let hasAccessKey = $derived(
    visibility === 'public' || !!$treeRootStore?.key || (visibility === 'link-visible' && !!linkKey)
  );
  let isProtectedBoardWithoutAccess = $derived(
    shouldShowProtectedNotice(isOwnBoard, hasAccessKey, resolvedVisibility)
  );
  let loading = $derived(
    !isProtectedBoardWithoutAccess
      && !error
      && (!!loadingBoard || (!board && !!ownerNpub && !!treeName))
  );

  let canManage = $derived(permissions ? canManageBoard(permissions, userNpub, ownerNpub) : false);
  let canWrite = $derived(permissions ? canWriteBoard(permissions, userNpub, ownerNpub) : false);
  let boardMemberNpubs = $derived.by(() => {
    const members = new Set<string>();
    if (ownerNpub) members.add(ownerNpub);
    for (const npub of permissions?.admins ?? []) members.add(npub);
    for (const npub of permissions?.writers ?? []) members.add(npub);
    return Array.from(members);
  });

  let savingBoard = $state(false);
  let savingPermissions = $state(false);
  let savingVisibility = $state(false);
  let visibilityDraft = $derived<TreeVisibility>(visibility);
  let visibilityError = $state('');

  let showPermissionsModal = $state(false);

  let showColumnModal = $state(false);
  let columnModalMode = $state<'create' | 'edit'>('create');
  let columnDraftTitle = $state('');
  let columnFormError = $state('');
  let editingColumnId = $state<string | null>(null);

  let showCardModal = $state(false);
  let cardModalMode = $state<'create' | 'edit'>('create');
  let cardDraftColumnId = $state<string | null>(null);
  let cardDraftCardId = $state<string | null>(null);
  let cardDraftTitle = $state('');
  let cardDraftDescription = $state('');
  let cardFormError = $state('');
  let cardDraftUploading = $state(false);
  let cardDraftAttachments = $state<BoardCardAttachment[]>([]);
  let cardDraftAssigneeNpubs = $state<string[]>([]);

  let localAttachmentPreviewUrls = $state<Record<string, string>>({});
  let uploadingCardMap = $state<Record<string, true>>({});

  let viewedColumnId = $state<string | null>(null);
  let viewedCardId = $state<string | null>(null);
  let commentDraftMarkdown = $state('');
  let commentFormError = $state('');
  let commentSubmitting = $state(false);
  let commentDraftAttachmentRecords = $state<BoardCardAttachment[]>([]);
  let commentDraftAttachments = $derived<CommentDraftAttachment[]>(
    commentDraftAttachmentRecords.map((attachment) => ({
      id: attachment.id,
      displayName: attachment.displayName,
      previewUrl: localAttachmentPreviewUrls[attachment.id] ?? null,
    }))
  );

  let cardAttachmentInputRef = $state<HTMLInputElement | undefined>();
  let attachmentInputRef = $state<HTMLInputElement | undefined>();
  let commentAttachmentInputRef = $state<HTMLInputElement | undefined>();

  let mediaAttachment = $state<BoardCardAttachment | null>(null);
  let showMediaModal = $state(false);

  let viewedCardState = $derived.by(() => {
    if (!board || !viewedColumnId || !viewedCardId) return null;
    const column = board.columns.find((item) => item.id === viewedColumnId);
    const card = column?.cards.find((item) => item.id === viewedCardId);
    return column && card ? { column, card } : null;
  });
  let showCardViewModal = $derived(!!viewedCardState);

  let permissionSections = $derived<AccessSection[]>([
    {
      id: 'admin',
      label: 'Admins',
      memberLabel: 'admin',
      npubs: permissions?.admins ?? [],
      emptyText: 'No admins yet.',
      removeTitle: 'Remove admin',
    },
    {
      id: 'writer',
      label: 'Writers',
      memberLabel: 'writer',
      npubs: permissions?.writers ?? [],
      emptyText: 'No writers yet.',
      removeTitle: 'Remove writer',
    },
  ]);
  let permissionIntro = $derived(
    canManage
      ? 'Admins can manage access. Writers can edit board content.'
      : 'Board members and access requests are listed here.'
  );
  let permissionRequestAccess = $derived<RequestAccessOptions | null>(
    canManage
      ? null
      : {
          text: 'Share your npub with an admin to request write access.',
          copyText: userNpub ?? undefined,
          displayText: userNpub ?? undefined,
        }
  );

  $effect(() => {
    cachedVisibility = ownerNpub && treeName ? getCachedVisibility(ownerNpub, treeName) : undefined;
  });

  $effect(() => {
    const store = treesStore;
    const unsubscribe = store.subscribe((value) => {
      trees = value;
    });
    return unsubscribe;
  });

  $effect(() => {
    visibilityDraft = visibility;
  });

  $effect(() => {
    const unsubscribe = treeRootRegistry.subscribeAll((key) => {
      const slashIndex = key.indexOf('/');
      if (slashIndex === -1) return;
      const changedNpub = key.slice(0, slashIndex);
      const changedTreeName = key.slice(slashIndex + 1);
      if (changedTreeName !== treeName) return;
      if (changedNpub === ownerNpub) {
        cachedVisibility = getCachedVisibility(ownerNpub, treeName);
      }
      reloadNonce += 1;
    });
    return unsubscribe;
  });

  $effect(() => {
    const unsubscribe = onLinkKeyUpdate(() => {
      reloadNonce += 1;
    });
    return unsubscribe;
  });

  $effect(() => {
    const root = $treeRootStore;
    const loadKey = [
      ownerNpub,
      treeName,
      boardPathKey,
      linkKey ?? '',
      root ? `${toHex(root.hash)}:${root.key ? toHex(root.key) : ''}` : '',
      reloadNonce,
      isProtectedBoardWithoutAccess ? 'protected' : 'open',
    ].join('|');
    void loadKey;
    void loadBoard();
  });

  $effect(() => {
    return () => {
      for (const url of Object.values(localAttachmentPreviewUrls)) {
        URL.revokeObjectURL(url);
      }
    };
  });

  $effect(() => {
    if (!showCardModal && !showCardViewModal && !showMediaModal) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      if (showMediaModal) {
        closeAttachmentPreview();
      } else if (showCardModal) {
        closeCardModal();
      } else if (showCardViewModal) {
        closeCardViewModal();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  });

  async function loadBoard(): Promise<void> {
    if (!ownerNpub || !treeName) return;

    if (isProtectedBoardWithoutAccess) {
      board = null;
      permissions = null;
      tombstones = createInitialBoardTombstones();
      error = '';
      loadingBoard = false;
      return;
    }

    loadingBoard = true;
    error = '';
    const expectedOwner = ownerNpub;
    const expectedTree = treeName;
    const expectedPath = boardPathKey;

    try {
      const ownerRoot = $treeRootStore ?? await getTreeRoot(expectedOwner, expectedTree, linkKey);
      if (!ownerRoot) {
        if (expectedOwner === ownerNpub && expectedTree === treeName && expectedPath === boardPathKey) {
          board = null;
          permissions = null;
          tombstones = createInitialBoardTombstones();
        }
        return;
      }

      const ownerData = await loadSingleBoardRoot(ownerRoot, expectedOwner, expectedTree, boardPath);
      if (!ownerData?.board) {
        throw new Error('Board data not found.');
      }

      const sourcePermissions = ownerData.permissions
        ?? createInitialBoardPermissions(ownerData.board.boardId, ownerData.board.title, expectedOwner);
      const participantNpubs = collectParticipantNpubs(sourcePermissions);
      const participantResults = await Promise.all(participantNpubs.map(async (participantNpub) => {
        const result = await loadParticipantBoardData({
          participantNpub,
          viewedNpub: expectedOwner,
          treeRoot: ownerRoot,
          treeName: expectedTree,
          boardPath,
          timeoutMs: participantLoadTimeoutMs,
          linkKey,
          ownerNpub: expectedOwner,
        });
        return result.data && result.data.board
          ? { source: participantNpub, board: result.data.board, permissions: result.data.permissions, tombstones: result.data.tombstones }
          : null;
      }));

      const merged = mergeBoardSnapshots([
        { source: expectedOwner, board: ownerData.board, permissions: sourcePermissions, tombstones: ownerData.tombstones },
        ...participantResults.filter((item): item is NonNullable<typeof item> => !!item),
      ], {
        ownerNpub: expectedOwner,
        fallbackBoardId: ownerData.board.boardId,
        fallbackTitle: ownerData.board.title,
      });

      if (expectedOwner !== ownerNpub || expectedTree !== treeName || expectedPath !== boardPathKey) return;
      board = merged.board;
      permissions = merged.permissions ?? sourcePermissions;
      tombstones = merged.tombstones;
    } catch (err) {
      if (expectedOwner !== ownerNpub || expectedTree !== treeName || expectedPath !== boardPathKey) return;
      console.error('[BoardView] Failed to load board:', err);
      error = err instanceof Error ? err.message : 'Failed to load board.';
    } finally {
      if (expectedOwner === ownerNpub && expectedTree === treeName && expectedPath === boardPathKey) {
        loadingBoard = false;
      }
    }
  }

  async function loadSingleBoardRoot(root: CID, fallbackOwnerNpub: string, fallbackTreeName: string, path: string[]): Promise<BoardDirectoryData | null> {
    const boardDir = await resolveBoardDirectory(root, path);
    if (!boardDir) return null;
    return loadBoardFromDirectory(
      boardDir,
      createBoardId(),
      fallbackTreeName.startsWith('boards/') ? fallbackTreeName.slice(7) : fallbackTreeName,
      fallbackOwnerNpub,
      fallbackOwnerNpub,
    );
  }

  function collectParticipantNpubs(sourcePermissions: BoardPermissions): string[] {
    const participants = new Set<string>();
    for (const npub of sourcePermissions.admins) participants.add(npub);
    for (const npub of sourcePermissions.writers) participants.add(npub);
    participants.delete(ownerNpub);
    return Array.from(participants);
  }

  function labelsForPublish(): string[] {
    return resolveBoardPublishLabels(treeEntry?.labels);
  }

  async function persistEdit(result: BoardEditResult): Promise<void> {
    if (!result.changed || !permissions || !userNpub || !treeName) return;
    await persistBoardState(result.board, permissions, result.tombstones);
  }

  async function persistPermissions(nextPermissions: BoardPermissions): Promise<void> {
    if (!board || !userNpub || !treeName) return;
    await persistBoardState(board, nextPermissions, tombstones);
  }

  async function persistBoardState(nextBoard: BoardState, nextPermissions: BoardPermissions, nextTombstones: BoardTombstones): Promise<void> {
    if (!userNpub || !treeName) return;
    const nextRoot = await buildUpdatedBoardRootCid({
      userNpub,
      treeName,
      boardPath,
      nextBoard,
      nextPermissions,
      nextTombstones,
    });
    if (!nextRoot) throw new Error('Could not write board root.');

    updateLocalRootCache(userNpub, treeName, nextRoot.hash, nextRoot.key, visibility, labelsForPublish());
    board = nextBoard;
    permissions = nextPermissions;
    tombstones = nextTombstones;
  }

  function markUploading(columnId: string, cardId: string, uploading: boolean): void {
    const key = `${columnId}:${cardId}`;
    if (uploading) {
      uploadingCardMap = { ...uploadingCardMap, [key]: true };
      return;
    }
    const next = { ...uploadingCardMap };
    delete next[key];
    uploadingCardMap = next;
  }

  function isUploadingCard(columnId: string, cardId: string): boolean {
    return !!uploadingCardMap[`${columnId}:${cardId}`];
  }

  function setPreviewUrl(attachmentId: string, url: string): void {
    localAttachmentPreviewUrls = { ...localAttachmentPreviewUrls, [attachmentId]: url };
  }

  function clearPreviewUrl(attachmentId: string): void {
    const url = localAttachmentPreviewUrls[attachmentId];
    if (url) URL.revokeObjectURL(url);
    const next = { ...localAttachmentPreviewUrls };
    delete next[attachmentId];
    localAttachmentPreviewUrls = next;
  }

  async function uploadAttachments(files: FileList | File[]): Promise<BoardCardAttachment[]> {
    if (!board || !permissions || !userNpub || !canWrite || error || isProtectedBoardWithoutAccess) return [];
    const result: BoardCardAttachment[] = [];
    for (const file of Array.from(files)) {
      const id = createBoardId();
      const displayName = sanitizeAttachmentFileName(file.name);
      const fileName = `${id}-${displayName}`;
      const bytes = new Uint8Array(await file.arrayBuffer());
      const { cid, size } = await getTree().putFile(bytes);
      const attachment: BoardCardAttachment = {
        id,
        fileName,
        displayName,
        mimeType: file.type || 'application/octet-stream',
        size: size || file.size,
        uploaderNpub: userNpub,
        cidHash: toHex(cid.hash),
        cidKey: cid.key ? toHex(cid.key) : undefined,
      };
      if (isImageMimeType(attachment.mimeType)) {
        setPreviewUrl(attachment.id, URL.createObjectURL(file));
      }
      result.push(attachment);
    }
    return result;
  }

  function boardMemberRoleLabel(npub: string): string {
    if (npub === ownerNpub) return 'owner';
    if (permissions?.admins.includes(npub)) return 'admin';
    if (permissions?.writers.includes(npub)) return 'writer';
    return 'member';
  }

  function handleShare(): void {
    if (!ownerNpub || !treeName || typeof window === 'undefined') return;
    const shareKey = visibility === 'link-visible'
      ? linkKey ?? getLinkKey(ownerNpub, treeName) ?? undefined
      : undefined;
    const suffix = shareKey ? `?k=${shareKey}` : '';
    openShareModal(`${window.location.href.split('#')[0]}#/${ownerNpub}/${encodeURIComponent(treeName)}${suffix}`);
  }

  function handleOpenPermissions(): void {
    visibilityDraft = visibility;
    visibilityError = '';
    showPermissionsModal = true;
  }

  function openCreateColumnModal(): void {
    columnModalMode = 'create';
    columnDraftTitle = '';
    columnFormError = '';
    editingColumnId = null;
    showColumnModal = true;
  }

  function openEditColumnModal(columnId: string, title: string): void {
    columnModalMode = 'edit';
    columnDraftTitle = title;
    columnFormError = '';
    editingColumnId = columnId;
    showColumnModal = true;
  }

  function closeColumnModal(): void {
    showColumnModal = false;
    columnFormError = '';
  }

  async function submitColumnModal(): Promise<void> {
    if (!board || !userNpub) return;
    const title = columnDraftTitle.trim();
    if (!title) {
      columnFormError = 'Enter a column title.';
      return;
    }
    savingBoard = true;
    try {
      const result = columnModalMode === 'create'
        ? addBoardColumn(board, tombstones, { actor: userNpub, columnId: createBoardId(), title })
        : updateBoardColumnTitle(board, tombstones, { actor: userNpub, columnId: editingColumnId ?? '', title });
      await persistEdit(result);
      closeColumnModal();
    } catch (err) {
      columnFormError = err instanceof Error ? err.message : 'Could not save column.';
    } finally {
      savingBoard = false;
    }
  }

  async function removeColumnFromModal(): Promise<void> {
    if (!board || !userNpub || !editingColumnId) return;
    savingBoard = true;
    try {
      await persistEdit(removeBoardColumn(board, tombstones, { actor: userNpub, columnId: editingColumnId }));
      closeColumnModal();
    } finally {
      savingBoard = false;
    }
  }

  function resetCardDraft(): void {
    cardDraftColumnId = null;
    cardDraftCardId = null;
    cardDraftTitle = '';
    cardDraftDescription = '';
    cardFormError = '';
    cardDraftUploading = false;
    cardDraftAttachments = [];
    cardDraftAssigneeNpubs = [];
  }

  function openCreateCardModal(columnId: string): void {
    resetCardDraft();
    cardModalMode = 'create';
    cardDraftColumnId = columnId;
    showCardModal = true;
  }

  function openEditCard(columnId: string, card: BoardCard): void {
    resetCardDraft();
    cardModalMode = 'edit';
    cardDraftColumnId = columnId;
    cardDraftCardId = card.id;
    cardDraftTitle = card.title;
    cardDraftDescription = card.description;
    cardDraftAttachments = card.attachments.map((attachment) => ({ ...attachment }));
    cardDraftAssigneeNpubs = [...card.assigneeNpubs];
    showCardModal = true;
  }

  function openEditCardModal(columnId: string, card: BoardCard): void {
    openEditCard(columnId, card);
  }

  function openEditViewedCard(): void {
    if (!viewedCardState) return;
    const { column, card } = viewedCardState;
    viewedColumnId = null;
    viewedCardId = null;
    openEditCard(column.id, card as BoardCard);
  }

  function closeCardModal(): void {
    showCardModal = false;
    cardFormError = '';
  }

  function toggleCardDraftAssignee(npub: string, checked: boolean): void {
    const next = new Set(cardDraftAssigneeNpubs);
    if (checked) next.add(npub);
    else next.delete(npub);
    cardDraftAssigneeNpubs = Array.from(next);
  }

  function triggerCardDraftAttachmentPicker(): void {
    cardAttachmentInputRef?.click();
  }

  async function handleCardDraftAttachmentInputChange(): Promise<void> {
    if (!cardAttachmentInputRef?.files?.length) return;
    cardDraftUploading = true;
    try {
      const uploaded = await uploadAttachments(cardAttachmentInputRef.files);
      cardDraftAttachments = [...cardDraftAttachments, ...uploaded];
    } finally {
      cardDraftUploading = false;
      if (cardAttachmentInputRef) cardAttachmentInputRef.value = '';
    }
  }

  function removeCardDraftAttachment(attachmentId: string): void {
    cardDraftAttachments = cardDraftAttachments.filter((attachment) => attachment.id !== attachmentId);
    clearPreviewUrl(attachmentId);
  }

  async function submitCardModal(): Promise<void> {
    if (!board || !userNpub || !cardDraftColumnId) return;
    const title = cardDraftTitle.trim();
    if (!title) {
      cardFormError = 'Enter a card title.';
      return;
    }
    savingBoard = true;
    try {
      const result = cardModalMode === 'create'
        ? addBoardCard(board, tombstones, {
            actor: userNpub,
            columnId: cardDraftColumnId,
            card: {
              id: createBoardId(),
              title,
              description: cardDraftDescription,
              assigneeNpubs: [...cardDraftAssigneeNpubs],
              attachments: cardDraftAttachments.map((attachment) => ({ ...attachment })),
              comments: [],
            },
          })
        : mutateBoardCard(board, tombstones, {
            actor: userNpub,
            columnId: cardDraftColumnId,
            cardId: cardDraftCardId ?? '',
            mutate(card) {
              card.title = title;
              card.description = cardDraftDescription;
              card.assigneeNpubs = [...cardDraftAssigneeNpubs];
              card.attachments = cardDraftAttachments.map((attachment) => ({ ...attachment }));
            },
          });
      await persistEdit(result);
      closeCardModal();
    } catch (err) {
      cardFormError = err instanceof Error ? err.message : 'Could not save card.';
    } finally {
      savingBoard = false;
    }
  }

  function openCardViewModal(columnId: string, cardId: string): void {
    viewedColumnId = columnId;
    viewedCardId = cardId;
    commentDraftMarkdown = '';
    commentFormError = '';
    commentDraftAttachmentRecords = [];
  }

  function closeCardViewModal(): void {
    viewedColumnId = null;
    viewedCardId = null;
    commentDraftMarkdown = '';
    commentFormError = '';
    commentDraftAttachmentRecords = [];
  }

  function openAttachmentPreview(attachment: BoardCardAttachment): void {
    mediaAttachment = attachment;
    showMediaModal = true;
  }

  function closeAttachmentPreview(): void {
    showMediaModal = false;
    mediaAttachment = null;
  }

  function triggerCommentAttachmentPicker(): void {
    commentAttachmentInputRef?.click();
  }

  async function handleCommentAttachmentInputChange(): Promise<void> {
    if (!commentAttachmentInputRef?.files?.length) return;
    const uploaded = await uploadAttachments(commentAttachmentInputRef.files);
    commentDraftAttachmentRecords = [...commentDraftAttachmentRecords, ...uploaded];
    if (commentAttachmentInputRef) commentAttachmentInputRef.value = '';
  }

  function removeCommentDraftAttachment(attachmentId: string): void {
    commentDraftAttachmentRecords = commentDraftAttachmentRecords.filter((attachment) => attachment.id !== attachmentId);
    clearPreviewUrl(attachmentId);
  }

  async function submitComment(): Promise<void> {
    if (!board || !userNpub || !viewedCardState) return;
    if (!commentDraftMarkdown.trim() && commentDraftAttachmentRecords.length === 0) return;
    commentSubmitting = true;
    commentFormError = '';
    try {
      const now = Date.now();
      const result = mutateBoardCard(board, tombstones, {
        actor: userNpub,
        columnId: viewedCardState.column.id,
        cardId: viewedCardState.card.id,
        mutate(card) {
          card.comments = [
            ...card.comments,
            {
              id: createBoardId(),
              authorNpub: userNpub,
              markdown: commentDraftMarkdown,
              createdAt: now,
              updatedAt: now,
              attachments: commentDraftAttachmentRecords.map((attachment) => ({ ...attachment })),
            },
          ];
        },
      });
      await persistEdit(result);
      commentDraftMarkdown = '';
      commentDraftAttachmentRecords = [];
    } catch (err) {
      commentFormError = err instanceof Error ? err.message : 'Could not add comment.';
    } finally {
      commentSubmitting = false;
    }
  }

  function triggerViewedCardAttachmentPicker(): void {
    attachmentInputRef?.click();
  }

  async function handleAttachmentInputChange(): Promise<void> {
    if (!attachmentInputRef?.files?.length || !viewedCardState || !board || !userNpub) return;
    markUploading(viewedCardState.column.id, viewedCardState.card.id, true);
    try {
      const uploaded = await uploadAttachments(attachmentInputRef.files);
      const result = mutateBoardCard(board, tombstones, {
        actor: userNpub,
        columnId: viewedCardState.column.id,
        cardId: viewedCardState.card.id,
        mutate(card) {
          card.attachments = [...card.attachments, ...uploaded];
        },
      });
      await persistEdit(result);
    } finally {
      markUploading(viewedCardState.column.id, viewedCardState.card.id, false);
      if (attachmentInputRef) attachmentInputRef.value = '';
    }
  }

  async function attachToViewedCard(): Promise<void> {
    triggerViewedCardAttachmentPicker();
  }

  async function removeAttachment(columnId: string, cardId: string, attachmentId: string): Promise<void> {
    if (!board || !userNpub) return;
    savingBoard = true;
    try {
      const result = mutateBoardCard(board, tombstones, {
        actor: userNpub,
        columnId,
        cardId,
        mutate(card) {
          card.attachments = card.attachments.filter((attachment) => attachment.id !== attachmentId);
          card.comments = card.comments.map((comment) => ({
            ...comment,
            attachments: comment.attachments.filter((attachment) => attachment.id !== attachmentId),
          }));
        },
      });
      await persistEdit(result);
      clearPreviewUrl(attachmentId);
    } finally {
      savingBoard = false;
    }
  }

  async function removeViewedCard(): Promise<void> {
    if (!board || !userNpub || !viewedCardState) return;
    savingBoard = true;
    try {
      await persistEdit(removeBoardCard(board, tombstones, {
        actor: userNpub,
        columnId: viewedCardState.column.id,
        cardId: viewedCardState.card.id,
      }));
      closeCardViewModal();
    } finally {
      savingBoard = false;
    }
  }

  async function moveCardToColumn(
    fromColumnId: string,
    cardId: string,
    toColumnId: string,
    beforeCardId: string | null,
    position: 'before' | 'after' | 'end',
  ): Promise<void> {
    if (!board || !userNpub) return;
    await persistEdit(moveBoardCardState(board, tombstones, {
      actor: userNpub,
      fromColumnId,
      cardId,
      toColumnId,
      beforeCardId,
      position,
    }));
  }

  async function moveColumn(fromColumnId: string, toColumnId: string, position: 'before' | 'after'): Promise<void> {
    if (!board || !userNpub) return;
    await persistEdit(moveBoardColumnState(board, tombstones, {
      actor: userNpub,
      fromColumnId,
      toColumnId,
      position,
    }));
  }

  function validatePermissionAdd(npub: string, role: string): string | null {
    if (!isValidNpub(npub)) return 'Enter a valid npub.';
    if (role !== 'admin' && role !== 'writer') return 'Choose a valid role.';
    if (permissions?.admins.includes(npub) || permissions?.writers.includes(npub)) {
      return 'This npub already has access.';
    }
    return null;
  }

  async function handleAddPermission(npub: string, role: string): Promise<string | void> {
    if (!permissions || !userNpub) return 'Could not update permissions.';
    const validation = validatePermissionAdd(npub, role);
    if (validation) return validation;
    savingPermissions = true;
    try {
      const next = addBoardPermission(permissions, role as BoardRole, npub, userNpub);
      await persistPermissions(next);
    } catch (err) {
      return err instanceof Error ? err.message : 'Could not update permissions.';
    } finally {
      savingPermissions = false;
    }
  }

  async function handleRemovePermission(role: string, npub: string): Promise<string | void> {
    if (!permissions || !userNpub) return 'Could not update permissions.';
    if (role !== 'admin' && role !== 'writer') return 'Choose a valid role.';
    savingPermissions = true;
    try {
      const next = removeBoardPermission(permissions, role as BoardRole, npub, userNpub);
      await persistPermissions(next);
    } catch (err) {
      return err instanceof Error ? err.message : 'Could not update permissions.';
    } finally {
      savingPermissions = false;
    }
  }

  async function handleUpdateVisibility(): Promise<void> {
    if (!board || !ownerNpub || !treeName || !isOwnBoard) return;
    savingVisibility = true;
    visibilityError = '';
    try {
      const root = $treeRootStore ?? await getTreeRoot(ownerNpub, treeName, linkKey);
      if (!root) throw new Error('Could not resolve board root.');
      const storedLinkKey = getLinkKey(ownerNpub, treeName);
      const nextLinkKey = resolveBoardVisibilityLinkKey(
        visibilityDraft,
        linkKey,
        storedLinkKey,
        () => linkKeyUtils.generateLinkKey(),
      );
      const result = await saveHashtree(treeName, root, {
        visibility: visibilityDraft,
        linkKey: nextLinkKey,
        labels: labelsForPublish(),
      });
      if (!result.success) throw new Error('Could not publish visibility update.');
      const finalLinkKey = result.linkKey ?? nextLinkKey;
      if (visibilityDraft === 'link-visible' && finalLinkKey) {
        await storeLinkKey(ownerNpub, treeName, finalLinkKey);
      }
      cachedVisibility = visibilityDraft;
      const query = buildBoardVisibilityQueryString($routeStore.params, visibilityDraft, finalLinkKey);
      const nextUrl = `/${ownerNpub}/${encodeURIComponent(treeName)}${query ? `?${query}` : ''}`;
      navigate(nextUrl);
      await tick();
    } catch (err) {
      visibilityError = err instanceof Error ? err.message : 'Could not update visibility.';
    } finally {
      savingVisibility = false;
    }
  }
</script>

{#if loading}
  <div class="flex-1 flex items-center justify-center text-text-3">
    <span class="i-lucide-loader-2 animate-spin mr-2"></span>
    Loading board...
  </div>
{:else if error}
  <div class="flex-1 flex items-center justify-center text-text-3 p-6">
    <p>{error}</p>
  </div>
{:else if isProtectedBoardWithoutAccess}
  <BoardProtectedNotice {resolvedVisibility} {linkKey} />
{:else if board && permissions}
  <div class="flex-1 flex flex-col min-h-0">
    <BoardWorkspace
      {board}
      {ownerNpub}
      {ownerPubkey}
      {visibility}
      {canWrite}
      {canManage}
      {savingBoard}
      {savingPermissions}
      {savingVisibility}
      {uploadingCardMap}
      {localAttachmentPreviewUrls}
      onShare={handleShare}
      onOpenPermissions={handleOpenPermissions}
      onCreateColumn={openCreateColumnModal}
      onEditColumn={openEditColumnModal}
      onCreateCard={openCreateCardModal}
      onEditCard={openEditCardModal}
      onOpenCard={openCardViewModal}
      onOpenAttachmentPreview={openAttachmentPreview}
      onMoveCard={moveCardToColumn}
      onMoveColumn={moveColumn}
    />
  </div>
{/if}

<!-- These pickers belong to the persistent modals, including during board refresh. -->
{#if board && permissions && canWrite && userNpub && !error && !isProtectedBoardWithoutAccess}
  <input bind:this={cardAttachmentInputRef} type="file" multiple class="hidden" data-testid="board-card-draft-attachment-input" onchange={handleCardDraftAttachmentInputChange} />
  <input bind:this={attachmentInputRef} type="file" multiple class="hidden" data-testid="board-attachment-input" onchange={handleAttachmentInputChange} />
  <input bind:this={commentAttachmentInputRef} type="file" multiple class="hidden" data-testid="board-comment-attachment-input" onchange={handleCommentAttachmentInputChange} />
{/if}

<BoardColumnModal
  open={showColumnModal}
  mode={columnModalMode}
  title={columnDraftTitle}
  error={columnFormError}
  onTitleChange={(value) => columnDraftTitle = value}
  onClose={closeColumnModal}
  onSubmit={submitColumnModal}
  onRemove={removeColumnFromModal}
/>

<BoardCardEditModal
  open={showCardModal}
  mode={cardModalMode}
  title={cardDraftTitle}
  description={cardDraftDescription}
  error={cardFormError}
  uploading={cardDraftUploading}
  attachments={cardDraftAttachments}
  assigneeNpubs={cardDraftAssigneeNpubs}
  {boardMemberNpubs}
  {localAttachmentPreviewUrls}
  roleLabel={boardMemberRoleLabel}
  onTitleChange={(value) => cardDraftTitle = value}
  onDescriptionChange={(value) => cardDraftDescription = value}
  onToggleAssignee={toggleCardDraftAssignee}
  onAttach={triggerCardDraftAttachmentPicker}
  onRemoveAttachment={removeCardDraftAttachment}
  onClose={closeCardModal}
  onSubmit={submitCardModal}
/>

<BoardCardDetailsModal
  open={showCardViewModal}
  state={viewedCardState}
  {canWrite}
  uploading={viewedCardState ? isUploadingCard(viewedCardState.column.id, viewedCardState.card.id) : false}
  commentMarkdown={commentDraftMarkdown}
  commentAttachments={commentDraftAttachments}
  commentSubmitting={commentSubmitting}
  commentError={commentFormError}
  {localAttachmentPreviewUrls}
  roleLabel={boardMemberRoleLabel}
  onClose={closeCardViewModal}
  onOpenAttachmentPreview={openAttachmentPreview}
  onRemoveAttachment={removeAttachment}
  onCommentMarkdownChange={(value) => commentDraftMarkdown = value}
  onTriggerCommentAttachment={triggerCommentAttachmentPicker}
  onSubmitComment={submitComment}
  onRemoveCommentDraftAttachment={removeCommentDraftAttachment}
  onAttachToCard={attachToViewedCard}
  onEditCard={openEditViewedCard}
  onRemoveCard={removeViewedCard}
/>

<BoardMediaModal
  attachment={showMediaModal ? mediaAttachment : null}
  {localAttachmentPreviewUrls}
  onClose={closeAttachmentPreview}
/>

{#if permissions}
  <BoardPermissionsModal
    open={showPermissionsModal}
    intro={permissionIntro}
    sections={permissionSections}
    {canManage}
    requestAccess={permissionRequestAccess}
    {visibility}
    {visibilityDraft}
    {visibilityError}
    {savingVisibility}
    {isOwnBoard}
    validateAdd={validatePermissionAdd}
    onAdd={handleAddPermission}
    onRemove={handleRemovePermission}
    onClose={() => showPermissionsModal = false}
    onVisibilityDraftChange={(value) => {
      visibilityDraft = value;
      visibilityError = '';
    }}
    onUpdateVisibility={handleUpdateVisibility}
  />
{/if}
