<script lang="ts">
  import type { TreeVisibility } from '@hashtree/core';
  import type { BoardCard, BoardCardAttachment, BoardState } from '../../lib/boards';
  import {
    attachmentImageSrc,
    cardAttachmentUrl,
    formatAttachmentSize,
    handleAttachmentImageError,
    isImageAttachment,
    isModalPreviewAttachment,
  } from '../../lib/boards';
  import VisibilityIcon from '../VisibilityIcon.svelte';
  import { Avatar, Name } from '../User';

  interface DragCardState {
    cardId: string;
    fromColumnId: string;
  }

  interface CardDropTarget {
    columnId: string;
    beforeCardId: string | null;
    position: 'before' | 'after' | 'end';
  }

  interface DragColumnState {
    columnId: string;
  }

  interface ColumnDropTarget {
    columnId: string;
    position: 'before' | 'after';
  }

  interface Props {
    board: BoardState;
    ownerNpub: string;
    ownerPubkey: string | null;
    visibility: TreeVisibility;
    canWrite: boolean;
    canManage: boolean;
    savingBoard: boolean;
    savingPermissions: boolean;
    savingVisibility: boolean;
    uploadingCardMap: Record<string, true>;
    localAttachmentPreviewUrls: Record<string, string>;
    onShare: () => void;
    onOpenPermissions: () => void;
    onCreateColumn: () => void;
    onEditColumn: (columnId: string, title: string) => void;
    onCreateCard: (columnId: string) => void;
    onEditCard: (columnId: string, card: BoardCard) => void;
    onOpenCard: (columnId: string, cardId: string) => void;
    onOpenAttachmentPreview: (attachment: BoardCardAttachment) => void;
    onMoveCard: (
      fromColumnId: string,
      cardId: string,
      toColumnId: string,
      beforeCardId: string | null,
      position: 'before' | 'after' | 'end',
    ) => void;
    onMoveColumn: (fromColumnId: string, toColumnId: string, position: 'before' | 'after') => void;
  }

  let {
    board,
    ownerNpub,
    ownerPubkey,
    visibility,
    canWrite,
    canManage,
    savingBoard,
    savingPermissions,
    savingVisibility,
    uploadingCardMap,
    localAttachmentPreviewUrls,
    onShare,
    onOpenPermissions,
    onCreateColumn,
    onEditColumn,
    onCreateCard,
    onEditCard,
    onOpenCard,
    onOpenAttachmentPreview,
    onMoveCard,
    onMoveColumn,
  }: Props = $props();

  let draggingCard = $state<DragCardState | null>(null);
  let cardDropTarget = $state<CardDropTarget | null>(null);
  let draggingColumn = $state<DragColumnState | null>(null);
  let columnDropTarget = $state<ColumnDropTarget | null>(null);

  function clearDragState() {
    draggingCard = null;
    cardDropTarget = null;
    draggingColumn = null;
    columnDropTarget = null;
  }

  function handleCardDragStart(event: DragEvent, columnId: string, cardId: string) {
    if (!canWrite) return;
    draggingCard = { cardId, fromColumnId: columnId };
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', JSON.stringify(draggingCard));
  }

  function resolveDragCard(event: DragEvent): DragCardState | null {
    if (draggingCard) return draggingCard;
    const payload = event.dataTransfer?.getData('text/plain');
    if (!payload) return null;
    try {
      const parsed = JSON.parse(payload) as Partial<DragCardState>;
      if (!parsed.cardId || !parsed.fromColumnId) return null;
      return { cardId: parsed.cardId, fromColumnId: parsed.fromColumnId };
    } catch {
      return null;
    }
  }

  function handleCardDragOver(event: DragEvent, columnId: string, cardId: string) {
    if (!canWrite || !resolveDragCard(event)) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const position: 'before' | 'after' = event.clientY > rect.top + rect.height / 2 ? 'after' : 'before';
    cardDropTarget = { columnId, beforeCardId: cardId, position };
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  function handleColumnDragOver(event: DragEvent, columnId: string) {
    if (!canWrite || !resolveDragCard(event)) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    cardDropTarget = { columnId, beforeCardId: null, position: 'end' };
  }

  function executeCardDrop(
    dragState: DragCardState,
    toColumnId: string,
    beforeCardId: string | null,
    position: 'before' | 'after' | 'end',
  ) {
    if (dragState.fromColumnId === toColumnId && beforeCardId === dragState.cardId) {
      clearDragState();
      return;
    }
    onMoveCard(dragState.fromColumnId, dragState.cardId, toColumnId, beforeCardId, position);
    clearDragState();
  }

  function handleCardDrop(event: DragEvent, columnId: string, cardId: string) {
    if (!canWrite) return;
    event.preventDefault();
    event.stopPropagation();
    const dragState = resolveDragCard(event);
    if (!dragState) return;
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const position: 'before' | 'after' = event.clientY > rect.top + rect.height / 2 ? 'after' : 'before';
    executeCardDrop(dragState, columnId, cardId, position);
  }

  function handleColumnDrop(event: DragEvent, columnId: string) {
    if (!canWrite) return;
    event.preventDefault();
    const dragState = resolveDragCard(event);
    if (dragState) executeCardDrop(dragState, columnId, null, 'end');
  }

  function handleColumnDragStart(event: DragEvent, columnId: string) {
    if (!canWrite || (event.target as HTMLElement).closest('[data-card-id]')) return;
    draggingColumn = { columnId };
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('application/x-board-column', columnId);
  }

  function handleColumnReorderDragOver(event: DragEvent, columnId: string) {
    if (!canWrite || !draggingColumn || draggingColumn.columnId === columnId || draggingCard) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const position: 'before' | 'after' = event.clientX > rect.left + rect.width / 2 ? 'after' : 'before';
    columnDropTarget = { columnId, position };
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  function handleColumnReorderDrop(event: DragEvent, columnId: string) {
    if (!canWrite || !draggingColumn || draggingCard) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const position: 'before' | 'after' = event.clientX > rect.left + rect.width / 2 ? 'after' : 'before';
    onMoveColumn(draggingColumn.columnId, columnId, position);
    draggingColumn = null;
    columnDropTarget = null;
  }

  function columnDropTargetClass(columnId: string): string {
    if (!columnDropTarget || columnDropTarget.columnId !== columnId) return '';
    return columnDropTarget.position === 'after'
      ? 'ring-2 ring-accent/80 ring-offset-2 ring-offset-surface-0'
      : 'ring-2 ring-emerald-500/80 ring-offset-2 ring-offset-surface-0';
  }

  function isColumnDropTarget(columnId: string): boolean {
    return !!cardDropTarget && cardDropTarget.columnId === columnId && cardDropTarget.beforeCardId === null;
  }

  function cardDropTargetClass(columnId: string, cardId: string): string {
    if (!cardDropTarget || cardDropTarget.columnId !== columnId || cardDropTarget.beforeCardId !== cardId) return '';
    return cardDropTarget.position === 'after'
      ? 'ring-2 ring-emerald-500/80 ring-offset-1 ring-offset-surface-1'
      : 'ring-2 ring-accent/80 ring-offset-1 ring-offset-surface-1';
  }

  function isUploadingCard(columnId: string, cardId: string): boolean {
    return !!uploadingCardMap[`${columnId}:${cardId}`];
  }
</script>

<div class="flex-1 flex flex-col min-h-0">
  <div class="flex items-center justify-between gap-3 px-4 py-3 border-b border-surface-3 bg-surface-0">
    <div class="min-w-0">
      {#if ownerNpub && ownerPubkey}
        <a href={`#/${ownerNpub}/profile`} aria-label="View board owner profile" data-testid="board-owner-link" class="inline-flex max-w-full items-center gap-2 no-underline text-xs text-text-3 hover:text-text-2">
          <Avatar pubkey={ownerPubkey} size={20} showBadge class="shrink-0" />
          <Name pubkey={ownerPubkey} class="min-w-0 truncate font-medium" />
        </a>
      {/if}
      <h1 class={`text-lg font-semibold truncate ${ownerPubkey ? 'mt-1' : ''}`}>{board.title}</h1>
      <div class="mt-1 flex items-center gap-2 text-xs text-text-3">
        <VisibilityIcon {visibility} class="text-xs" />
        {#if canWrite}<span class="text-success">Write access</span>{:else}<span>Read-only</span>{/if}
        {#if savingBoard || savingPermissions || savingVisibility}<span class="animate-pulse">Saving...</span>{/if}
      </div>
    </div>
    <div class="flex items-center gap-2">
      <button class="btn-circle btn-ghost" onclick={onShare} title="Share board">
        <span class="i-lucide-share-2"></span>
      </button>
      <button class="btn-ghost" onclick={onOpenPermissions} title={canManage ? 'Manage permissions' : 'View permissions'}>
        <span class="i-lucide-shield-check mr-1"></span>
        Permissions
      </button>
      {#if canWrite}
        <button class="btn-primary" onclick={onCreateColumn}>
          <span class="i-lucide-columns-2 mr-1"></span>
          Add Column
        </button>
      {/if}
    </div>
  </div>

  <div class="flex-1 overflow-auto p-4">
    <div class="flex gap-4 items-start min-h-full pb-4">
      {#each board.columns as column (column.id)}
        <section
          data-testid={`board-column-${column.title}`}
          role="group"
          aria-label={`${column.title} column`}
          draggable={canWrite}
          ondragstart={(event) => handleColumnDragStart(event as DragEvent, column.id)}
          ondragend={() => { draggingColumn = null; columnDropTarget = null; }}
          ondragover={(event) => handleColumnReorderDragOver(event as DragEvent, column.id)}
          ondrop={(event) => handleColumnReorderDrop(event as DragEvent, column.id)}
          class={`board-column-hover w-80 max-w-80 shrink-0 bg-surface-1 rounded-xl border border-surface-3 p-3 shadow-sm space-y-3 ${canWrite ? 'cursor-grab active:cursor-grabbing' : ''} ${draggingColumn?.columnId === column.id ? 'opacity-50' : ''} ${columnDropTargetClass(column.id)}`}
        >
          <div class="flex items-start justify-between gap-2">
            <div class="min-w-0">
              <h2 class="font-semibold text-sm truncate">{column.title}</h2>
              <p class="text-[11px] text-text-3 mt-1">{column.cards.length} {column.cards.length === 1 ? 'card' : 'cards'}</p>
            </div>
            {#if canWrite}
              <div class="h-8 w-8 shrink-0">
                <button class="board-column-action btn-circle btn-ghost h-8 w-8 min-h-8 min-w-8 opacity-0 pointer-events-none transition-opacity" aria-label="Edit column" title="Edit column" onclick={() => onEditColumn(column.id, column.title)}>
                  <span class="i-lucide-pencil text-sm"></span>
                </button>
              </div>
            {/if}
          </div>

          <div data-testid={`board-column-cards-${column.title}`} role="list" aria-label={`${column.title} cards`} class={`min-h-12 space-y-2 rounded-md transition-colors ${isColumnDropTarget(column.id) ? 'bg-accent/10 ring-2 ring-dashed ring-accent/60 p-2' : ''}`} ondragover={(event) => handleColumnDragOver(event as DragEvent, column.id)} ondrop={(event) => handleColumnDrop(event as DragEvent, column.id)}>
            {#if column.cards.length === 0}
              <div class="rounded-md border border-dashed border-surface-3 py-5 px-3 text-xs text-text-3 text-center">Drop cards here or add a new one.</div>
            {/if}
            {#each column.cards as card (card.id)}
              <article data-testid={`board-card-${card.title}`} data-card-id={card.id} draggable={canWrite} ondragstart={(event) => handleCardDragStart(event as DragEvent, column.id, card.id)} ondragend={clearDragState} ondragover={(event) => handleCardDragOver(event as DragEvent, column.id, card.id)} ondrop={(event) => handleCardDrop(event as DragEvent, column.id, card.id)} class={`board-card-hover bg-surface-0 border border-surface-3 rounded-lg p-3 transition-shadow ${canWrite ? 'cursor-grab active:cursor-grabbing hover:shadow-md' : ''} ${draggingCard?.cardId === card.id ? 'opacity-50' : ''} ${cardDropTargetClass(column.id, card.id)}`}>
                <div class="flex items-start gap-2">
                  <button type="button" class="min-w-0 flex-1 text-left" aria-label="Open card details" onclick={() => onOpenCard(column.id, card.id)}>
                    <h3 class="text-sm font-medium break-words">{card.title}</h3>
                    {#if card.description}<p class="text-xs text-text-3 mt-1 whitespace-pre-wrap line-clamp-3">{card.description}</p>{/if}
                  </button>
                  {#if canWrite}
                    <div class="h-8 w-8 shrink-0">
                      <button type="button" class="board-card-action btn-circle btn-ghost h-8 w-8 min-h-8 min-w-8 opacity-0 pointer-events-none transition-opacity" aria-label="Quick edit card" title="Edit card" onclick={(event) => { event.stopPropagation(); onEditCard(column.id, card); }}>
                        <span class="i-lucide-pencil text-[11px]"></span>
                      </button>
                    </div>
                  {/if}
                </div>
                {#if card.assigneeNpubs.length > 0}
                  <div class="mt-2 text-[11px] text-text-3 flex items-center gap-1">
                    <span class="i-lucide-users text-[11px]"></span>
                    <span>{card.assigneeNpubs.length} {card.assigneeNpubs.length === 1 ? 'assignee' : 'assignees'}</span>
                  </div>
                {/if}
                {#if card.attachments.length > 0}
                  <div class="mt-2 space-y-1">
                    {#each card.attachments as attachment (attachment.id)}
                      {@const attachmentUrl = cardAttachmentUrl(attachment)}
                      {@const attachmentImageUrl = attachmentImageSrc(attachment, localAttachmentPreviewUrls)}
                      <div class="rounded-md border border-surface-3 bg-surface-1 px-2 py-1.5" data-testid={`board-card-attachment-${attachment.displayName}`}>
                        {#if isImageAttachment(attachment) && attachmentImageUrl}
                          <button type="button" class="block w-full bg-transparent border-none p-0 cursor-zoom-in" title={attachment.displayName} onclick={(event) => { event.stopPropagation(); onOpenAttachmentPreview(attachment); }}>
                            <img class="w-full max-h-32 object-cover rounded border border-surface-3" src={attachmentImageUrl} alt={attachment.displayName} onerror={(event) => handleAttachmentImageError(event as Event, attachment)} />
                          </button>
                        {/if}
                        <div class="mt-1 flex items-center justify-between gap-2">
                          {#if isModalPreviewAttachment(attachment) && (attachmentUrl || attachmentImageUrl)}
                            <button type="button" class="text-xs text-accent hover:underline truncate bg-transparent border-none p-0 text-left" title={attachment.displayName} onclick={(event) => { event.stopPropagation(); onOpenAttachmentPreview(attachment); }}>{attachment.displayName}</button>
                          {:else if attachmentUrl}
                            <a class="text-xs text-accent hover:underline truncate" href={attachmentUrl} target="_blank" rel="noreferrer" title={attachment.displayName}>{attachment.displayName}</a>
                          {:else}
                            <span class="text-xs text-text-3 truncate" title={attachment.displayName}>{attachment.displayName}</span>
                          {/if}
                          <span class="text-[10px] text-text-3 shrink-0">{formatAttachmentSize(attachment.size)}</span>
                        </div>
                      </div>
                    {/each}
                  </div>
                {/if}
                {#if isUploadingCard(column.id, card.id)}
                  <div class="mt-2 text-[11px] text-text-3"><span class="i-lucide-loader-2 animate-spin mr-1"></span>Uploading...</div>
                {/if}
              </article>
            {/each}
          </div>

          {#if canWrite}
            <button class="btn-ghost w-full text-sm" onclick={() => onCreateCard(column.id)}>
              <span class="i-lucide-plus mr-1"></span>
              Add Card
            </button>
          {/if}
        </section>
      {/each}
      {#if canWrite}
        <button class="w-80 max-w-80 shrink-0 rounded-xl border border-dashed border-surface-3 text-text-2 hover:text-text-1 hover:border-accent transition-colors py-8 px-4 text-sm" onclick={onCreateColumn}>
          <span class="i-lucide-plus mr-1"></span>
          Add another column
        </button>
      {/if}
    </div>
  </div>
</div>

<style>
  .board-column-hover:hover .board-column-action,
  .board-column-hover:focus-within .board-column-action,
  .board-column-action:focus {
    opacity: 1;
    pointer-events: auto;
  }

  .board-card-hover:hover .board-card-action,
  .board-card-hover:focus-within .board-card-action,
  .board-card-action:focus {
    opacity: 1;
    pointer-events: auto;
  }
</style>
