# Iris Boards

Collaborative kanban boards on Nostr and hashtree.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-boards>
Live: <https://boards.iris.to/>

## Development

```bash
pnpm install
pnpm run dev
```

## Verification

```bash
pnpm run test:unit
pnpm run test:boards:iris
node ./scripts/release-site.mjs boards --dry-run
```

## Release

```bash
pnpm run release:boards:iris
```

The release script builds once, tests the built output, publishes the built directory root to hashtree, and deploys the same directory to the `iris-boards` Cloudflare Worker target by default.
