Keep this repo focused on the standalone Iris Boards app.

- Shared UI, release tooling, and NDK packages come from `../iris-kit`.
- Before release, run `pnpm run test:unit`, `pnpm run test:boards:iris`, and `node ./scripts/release-site.mjs boards --dry-run`.
- Keep board release scripts testing the built output before publish/deploy.
