import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  runAllReleases,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

describe('boards release-site', () => {
  it('uses the built-in Worker default and custom domain for boards', () => {
    const parsed = parseArgs(['boards']);
    expect(parsed.workerName).toBe('iris-boards');
    expect(parsed.treeName).toBe('boards');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual(['boards.iris.to']);
  });

  it('rejects profiles that are no longer part of this standalone app', () => {
    expect(() => parseArgs(['docs'])).toThrow('Unknown release profile: docs');
  });

  it('deploys the built boards output through the HTTPS redirect asset Worker', () => {
    const plan = createReleasePlan({
      profileName: 'boards',
      workerName: 'iris-boards',
      routes: [],
      domains: ['boards.iris.to'],
      treeName: 'boards',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.profile.distDir).toBe('dist-boards');
    expect(plan.steps.map((step) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.filter((step) => step.id.startsWith('test-')).map((step) => step.command)).toEqual([
      ['node', './scripts/smoke-graph-policy.mjs', 'boards'],
      ['pnpm', 'run', 'check:types'],
      ['node', './scripts/smoke-boards-iris-portable.mjs'],
      ['pnpm', 'run', 'test:unit'],
      ['pnpm', 'run', 'test:e2e'],
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-boards',
      '--name',
      'iris-boards',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--domain',
      'boards.iris.to',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-boards',
      '--name',
      'iris-boards',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-boards',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist-boards',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('stops before publish when a release test step fails', async () => {
    const calls: string[] = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-1') {
        expect(step.command).toEqual(['node', './scripts/smoke-graph-policy.mjs', 'boards']);
        return { status: 1, stdout: '', stderr: 'boards smoke failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(
      runRelease(
        {
          profileName: 'boards',
          workerName: 'iris-boards',
          treeName: 'boards',
          skipCloudflare: false,
          workerCompatibilityDate: '2026-03-19',
        },
        runner,
        { buildOutputExists: () => true },
      ),
    ).rejects.toThrow('Test Iris Boards (1/5) failed with exit code 1');
    expect(calls).toEqual(['build', 'test-1']);
  });

  it('treats all as the single boards release in this repo', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/boards\nnhash1ace',
          stderr: '',
        };
      }
      if (step.id === 'deploy') {
        return {
          status: 0,
          stdout: 'https://boards.iris.to',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runAllReleases(
      {
        profileName: 'all',
        dryRun: false,
        skipCloudflare: false,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles[0]?.profile.name).toBe('boards');
  });
});
