import { test, expect } from './fixtures';
import { waitForAppReady, ensureLoggedIn, enableOthersPool, setupPageErrorHandler, flushPendingPublishes, waitForRelayConnected } from './test-utils';
import { createBoard, parseBoardShareUrl, setupFreshBoardsViewer, waitForTreePublished } from './boards-app.helpers';

test.describe.configure({ mode: 'serial' });

test.describe('Iris Boards Access', () => {

  test('non-owner sees link-required notice instead of placeholder board without link key', async ({ page, browser }) => {
    setupPageErrorHandler(page);
    await page.goto('/boards.html#/');
    await waitForAppReady(page);
    await ensureLoggedIn(page, 30000);
    await enableOthersPool(page, 10);
    await waitForRelayConnected(page, 30000);

    const boardName = `E2E Locked Link Board ${Date.now()}`;
    const shareUrl = await createBoard(page, boardName, 'link-visible');
    expect(shareUrl).toMatch(/\?k=/);
    const { npub: ownerNpub, treeName } = parseBoardShareUrl(shareUrl);
    await waitForTreePublished(page, ownerNpub, treeName, 45000);
    await flushPendingPublishes(page);

    const protectedUrl = shareUrl.replace(/\?k=[^&]+/, '');

    const context2 = await browser.newContext();
    const page2 = await context2.newPage();
    await setupFreshBoardsViewer(page, page2, protectedUrl);

    await expect(page2.getByText('Link Required')).toBeVisible({ timeout: 30000 });
    await expect(page2.getByText('This board requires a special link to access. Ask the owner for the link with the access key.')).toBeVisible({ timeout: 30000 });
    await expect(page2.getByTestId('board-column-Todo')).toHaveCount(0);

    await context2.close();
  });

  test('non-owner sees private-board notice instead of placeholder board', async ({ page, browser }) => {
    setupPageErrorHandler(page);
    await page.goto('/boards.html#/');
    await waitForAppReady(page);
    await ensureLoggedIn(page, 30000);
    await enableOthersPool(page, 10);
    await waitForRelayConnected(page, 30000);

    const boardName = `E2E Private Locked Board ${Date.now()}`;
    const shareUrl = await createBoard(page, boardName, 'private');
    const { npub: ownerNpub, treeName } = parseBoardShareUrl(shareUrl);
    await waitForTreePublished(page, ownerNpub, treeName, 45000);
    await flushPendingPublishes(page);

    const context2 = await browser.newContext();
    const page2 = await context2.newPage();
    await setupFreshBoardsViewer(page, page2, shareUrl);

    await expect(page2.getByText('Private Board')).toBeVisible({ timeout: 30000 });
    await expect(page2.getByText('This board is private and can only be accessed by its owner.')).toBeVisible({ timeout: 30000 });
    await expect(page2.getByTestId('board-column-Todo')).toHaveCount(0);

    await context2.close();
  });
});
