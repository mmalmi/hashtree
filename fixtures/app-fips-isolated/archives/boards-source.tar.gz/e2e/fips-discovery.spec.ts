import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { WebSocketServer, type WebSocket } from 'ws';
import { expect, test } from '@playwright/test';
import { identityFromSecretKey, toHex } from '@fips/core';
import { getPublicKey, nip19 } from 'nostr-tools';
import { ensureLoggedIn, waitForAppReady } from './test-utils';

type NostrEvent = {
  id: string;
  pubkey: string;
  kind: number;
  tags: string[][];
};

let relay: WebSocketServer;
let relayUrl = '';
let seed: LocalFipsWebSocketSeed;
const publishedEvents: NostrEvent[] = [];
const subscriptions = new Map<WebSocket, Map<string, Record<string, unknown>[]>>();
const FIRST_FIPS_SECRET_HEX = `${'00'.repeat(31)}01`;
const SECOND_FIPS_SECRET_HEX = `${'00'.repeat(31)}02`;
const SWITCHED_NOSTR_SECRET = Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 3 : 0);

async function seedFipsDeviceIdentity(page: import('@playwright/test').Page, secretKeyHex: string): Promise<void> {
  await page.goto('/child-webview-test.html');
  await page.evaluate(async (secret) => {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('fips', 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains('fips-identity')) {
          request.result.createObjectStore('fips-identity');
        }
      };
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction('fips-identity', 'readwrite');
        transaction.objectStore('fips-identity').put({ secretKeyHex: secret }, 'default');
        transaction.oncomplete = () => {
          db.close();
          resolve();
        };
        transaction.onerror = () => reject(transaction.error);
      };
    });
  }, secretKeyHex);
}

async function readBrowserIdentities(page: import('@playwright/test').Page): Promise<{
  fipsPeerId: string;
  nostrPubkey: string;
}> {
  return page.evaluate(async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const nostrStore = (window as typeof window & {
      __nostrStore?: { getState?: () => { pubkey?: string } };
    }).__nostrStore;
    return {
      fipsPeerId: getDriveFipsRuntime()?.getStats().localPeerId ?? '',
      nostrPubkey: nostrStore?.getState?.().pubkey ?? '',
    };
  }).catch(() => ({ fipsPeerId: '', nostrPubkey: '' }));
}

function matchesFilter(event: NostrEvent, filter: Record<string, unknown>): boolean {
  const kinds = Array.isArray(filter.kinds) ? filter.kinds : [];
  if (kinds.length > 0 && !kinds.includes(event.kind)) return false;
  for (const [key, expected] of Object.entries(filter)) {
    if (!key.startsWith('#') || !Array.isArray(expected)) continue;
    const tagName = key.slice(1);
    if (!event.tags.some((tag) => tag[0] === tagName && expected.includes(tag[1]))) {
      return false;
    }
  }
  return true;
}
function send(socket: WebSocket, message: unknown): void {
  if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(message));
}

function publishToSubscriptions(event: NostrEvent): void {
  for (const [socket, socketSubscriptions] of subscriptions) {
    for (const [subscriptionId, filters] of socketSubscriptions) {
      if (filters.some((filter) => matchesFilter(event, filter))) {
        send(socket, ['EVENT', subscriptionId, event]);
      }
    }
  }
}

test.beforeAll(async () => {
  seed = await startLocalFipsWebSocketSeed();
  relay = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise<void>((resolve) => relay.once('listening', resolve));
  const address = relay.address();
  if (!address || typeof address === 'string') throw new Error('expected a TCP relay address');
  relayUrl = `ws://127.0.0.1:${address.port}`;

  relay.on('connection', (socket) => {
    subscriptions.set(socket, new Map());
    socket.on('message', (raw) => {
      const message = JSON.parse(raw.toString()) as unknown[];
      if (message[0] === 'EVENT') {
        const event = message[1] as NostrEvent;
        publishedEvents.push(event);
        publishToSubscriptions(event);
        send(socket, ['OK', event.id, true, '']);
        return;
      }
      if (message[0] === 'REQ') {
        const subscriptionId = `${message[1]}`;
        const filters = message.slice(2) as Record<string, unknown>[];
        subscriptions.get(socket)?.set(subscriptionId, filters);
        for (const event of publishedEvents) {
          if (filters.some((filter) => matchesFilter(event, filter))) {
            send(socket, ['EVENT', subscriptionId, event]);
          }
        }
        send(socket, ['EOSE', subscriptionId]);
        return;
      }
      if (message[0] === 'CLOSE') subscriptions.get(socket)?.delete(`${message[1]}`);
    });
    socket.on('close', () => subscriptions.delete(socket));
  });
});

test.afterAll(async () => {
  await seed.close();
  for (const socket of relay.clients) socket.terminate();
  await new Promise<void>((resolve) => relay.close(() => resolve()));
});

test('two Boards browsers discover FIPS peers and explicitly exchange blocks', async ({ browser, page }) => {
  test.slow();
  publishedEvents.length = 0;
  await page.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  await seedFipsDeviceIdentity(page, FIRST_FIPS_SECRET_HEX);
  await page.goto('/boards.html#/');
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);

  const expectedFirstPeerId = toHex((await identityFromSecretKey(
    Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 1 : 0),
  )).publicKey);
  await expect.poll(async () => (await readBrowserIdentities(page)).fipsPeerId, {
    timeout: 30_000,
  }).toBe(expectedFirstPeerId);
  const beforeAccountSwitch = await readBrowserIdentities(page);
  const switchedNsec = nip19.nsecEncode(SWITCHED_NOSTR_SECRET);
  const switchedNostrPubkey = getPublicKey(SWITCHED_NOSTR_SECRET);
  expect(await page.evaluate(async (nsec) => {
    const { loginWithNsec } = await import('/src/nostr/auth.ts');
    return loginWithNsec(nsec);
  }, switchedNsec)).toBe(true);
  await expect.poll(async () => (await readBrowserIdentities(page)).nostrPubkey).toBe(switchedNostrPubkey);
  expect((await readBrowserIdentities(page)).fipsPeerId).toBe(beforeAccountSwitch.fipsPeerId);

  await page.reload();
  await waitForAppReady(page);
  await expect.poll(async () => readBrowserIdentities(page), { timeout: 30_000 }).toEqual({
    fipsPeerId: expectedFirstPeerId,
    nostrPubkey: switchedNostrPubkey,
  });

  await expect.poll(() => publishedEvents.find((event) => event.kind === 37_195), {
    timeout: 60_000,
  }).toBeTruthy();
  const firstAdvert = publishedEvents.find((event) => event.kind === 37_195);
  const firstBrowserAdvertisers = new Set(
    publishedEvents.filter((event) => event.kind === 37_195).map((event) => event.pubkey),
  );
  expect(firstAdvert?.tags).toContainEqual(['d', 'fips-overlay-v1']);
  expect(firstAdvert?.tags).toContainEqual(['protocol', 'fips-overlay-v1']);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const secondContext = await browser.newContext();
  await secondContext.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  const secondPage = await secondContext.newPage();
  await seedFipsDeviceIdentity(secondPage, SECOND_FIPS_SECRET_HEX);
  await secondPage.goto('/boards.html#/');
  await waitForAppReady(secondPage);
  await ensureLoggedIn(secondPage, 30_000);

  const expectedSecondPeerId = toHex((await identityFromSecretKey(
    Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 2 : 0),
  )).publicKey);
  await expect.poll(async () => (await readBrowserIdentities(secondPage)).fipsPeerId, {
    timeout: 30_000,
  }).toBe(expectedSecondPeerId);
  expect(expectedSecondPeerId).not.toBe(expectedFirstPeerId);

  await expect.poll(() => publishedEvents.some((event) => (
    event.kind === 37_195 && !firstBrowserAdvertisers.has(event.pubkey)
  )), { timeout: 60_000 }).toBe(true);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  await expect.poll(async () => Promise.all([page, secondPage].map(async (candidate) => (
    candidate.evaluate(async (peerId) => {
      const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
      return getDriveFipsRuntime()?.getStats().connectedPeerIds.includes(peerId) ?? false;
    }, candidate === page ? expectedSecondPeerId : expectedFirstPeerId).catch(() => false)
  ))), { timeout: 30_000 }).toEqual([true, true]);

  const source = await page.evaluate(async () => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => {
        put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
        webrtcProxy?: unknown;
      } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');
    const text = `boards-fips-block-${crypto.randomUUID()}`;
    const data = new TextEncoder().encode(text);
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
    await adapter.put(hash, data);
    return {
      hashHex: Array.from(hash, (byte) => byte.toString(16).padStart(2, '0')).join(''),
      text,
      legacyProxyActive: adapter.webrtcProxy != null,
    };
  });
  expect(source.legacyProxyActive).toBe(false);

  const received = await secondPage.evaluate(async ({ hashHex, peerId }) => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const runtime = getDriveFipsRuntime();
    if (!runtime) throw new Error('FIPS runtime is not ready');
    const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
    return data ? new TextDecoder().decode(data) : null;
  }, { hashHex: source.hashHex, peerId: expectedFirstPeerId });
  expect(received).toBe(source.text);
  expect(await secondPage.evaluate(() => (
    (window as typeof window & {
      __getWorkerAdapter?: () => { webrtcProxy?: unknown } | null;
    }).__getWorkerAdapter?.()?.webrtcProxy != null
  ))).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  await secondContext.close();
});

declare global {
  interface Window {
    __testRelayUrl?: string;
  }
}
