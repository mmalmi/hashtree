import { expect } from './fixtures';
import type { Locator, Page } from '@playwright/test';
import { nip19 } from 'nostr-tools';
import { waitForAppReady, ensureLoggedIn, disableOthersPool, enableOthersPool, setupPageErrorHandler, flushPendingPublishes, waitForRelayConnected, useLocalRelay, configureBlossomServers } from './test-utils';

export type BoardsE2EWindow = Window & {
  __nostrStore?: {
    getState?: () => {
      pubkey?: string | null;
    };
  };
  __getWorkerAdapter?: () => TreeRootCacheAdapter | null | undefined;
  __workerAdapter?: TreeRootCacheAdapter;
  __boardLiveMarker?: string;
  __boardPermissionMarker?: string;
};

export type TreeRootCacheAdapter = {
  setTreeRootCache?: (
    npub: string,
    treeName: string,
    hash: Uint8Array,
    key?: Uint8Array,
    visibility?: 'public' | 'link-visible' | 'private'
  ) => Promise<void>;
};

export async function readNostrPubkey(page: Page): Promise<string | null> {
  return page.evaluate(() => {
    const raw = (window as BoardsE2EWindow).__nostrStore?.getState?.().pubkey ?? null;
    if (typeof raw === 'string') return raw;
    if (!raw || typeof raw !== 'object') return null;

    const candidate = raw as {
      pubkey?: unknown;
      hex?: unknown;
      value?: unknown;
      toHex?: () => string;
      toString?: () => string;
    };

    if (typeof candidate.pubkey === 'string') return candidate.pubkey;
    if (typeof candidate.hex === 'string') return candidate.hex;
    if (typeof candidate.value === 'string') return candidate.value;
    if (typeof candidate.toHex === 'function') return candidate.toHex();
    if (typeof candidate.toString === 'function') {
      const value = candidate.toString();
      if (value && value !== '[object Object]') return value;
    }
    return null;
  });
}

export async function getCurrentRootSignature(page: Page): Promise<string | null> {
  return page.evaluate(async () => {
    const { getCurrentRootCid } = await import('/src/actions/route.ts');
    const root = getCurrentRootCid();
    if (!root) return null;
    const hash = Array.from(root.hash).join(',');
    const key = root.key ? Array.from(root.key).join(',') : '';
    return `${hash}:${key}`;
  });
}

export async function getTreeRootSignature(
  page: Page,
  npub: string,
  treeName: string
): Promise<string | null> {
  return page.evaluate(async ({ targetNpub, targetTree }) => {
    const { getTreeRootSync } = await import('/src/stores/index.ts');
    const root = getTreeRootSync(targetNpub, targetTree);
    if (!root) return null;
    const hash = Array.from(root.hash).join(',');
    const key = root.key ? Array.from(root.key).join(',') : '';
    return `${hash}:${key}`;
  }, { targetNpub: npub, targetTree: treeName });
}

export async function flushBoardRootUpdate(
  page: Page,
  previousSignature: string | null,
  timeoutMs: number = 20000
): Promise<void> {
  await page.waitForFunction(async (previous) => {
    const { getCurrentRootCid } = await import('/src/actions/route.ts');
    const root = getCurrentRootCid();
    if (!root) return false;
    const hash = Array.from(root.hash).join(',');
    const key = root.key ? Array.from(root.key).join(',') : '';
    return `${hash}:${key}` !== previous;
  }, previousSignature, { timeout: timeoutMs });
  await flushPendingPublishes(page);
}

export async function flushTreeRootUpdate(
  page: Page,
  npub: string,
  treeName: string,
  previousSignature: string | null,
  timeoutMs: number = 20000
): Promise<void> {
  await page.waitForFunction(async ({ targetNpub, targetTree, previous }) => {
    const { getTreeRootSync } = await import('/src/stores/index.ts');
    const root = getTreeRootSync(targetNpub, targetTree);
    if (!root) return false;
    const hash = Array.from(root.hash).join(',');
    const key = root.key ? Array.from(root.key).join(',') : '';
    return `${hash}:${key}` !== previous;
  }, { targetNpub: npub, targetTree: treeName, previous: previousSignature }, { timeout: timeoutMs });
  await flushPendingPublishes(page);
}

export async function waitForTreePublished(page: Page, npub: string, treeName: string, timeoutMs: number = 30000): Promise<void> {
  await waitForRelayConnected(page, Math.min(timeoutMs, 15000));
  await flushPendingPublishes(page);
  await page.waitForFunction(
    ({ owner, tree }) => {
      const raw = localStorage.getItem('hashtree:localRootCache');
      if (!raw) return false;
      try {
        const data = JSON.parse(raw);
        const entry = data?.[`${owner}/${tree}`];
        return entry && entry.dirty === false;
      } catch {
        return false;
      }
    },
    { owner: npub, tree: treeName },
    { timeout: timeoutMs }
  );
}

export async function waitForTreeRoot(page: Page, npub: string, treeName: string, timeoutMs: number = 60000): Promise<void> {
  await page.evaluate(async ({ targetNpub, targetTree, timeout }) => {
    const { waitForTreeRoot } = await import('/src/stores/index.ts');
    await waitForTreeRoot(targetNpub, targetTree, timeout);
  }, { targetNpub: npub, targetTree: treeName, timeout: timeoutMs });
}

export async function waitForTreeRootHash(
  page: Page,
  npub: string,
  treeName: string,
  expectedHash: string,
  timeoutMs: number = 60000
): Promise<void> {
  await page.waitForFunction(
    async ({ targetNpub, targetTree, targetHash }) => {
      const { getTreeRootSync } = await import('/src/stores/index.ts');
      const toHex = (bytes: Uint8Array): string => Array.from(bytes)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
      const root = getTreeRootSync(targetNpub, targetTree);
      if (!root) return false;
      return toHex(root.hash) === targetHash;
    },
    { targetNpub: npub, targetTree: treeName, targetHash: expectedHash },
    { timeout: timeoutMs }
  );
}

export async function waitForTreeRootStoreHash(
  page: Page,
  expectedHash: string,
  timeoutMs: number = 60000
): Promise<void> {
  await page.waitForFunction(
    async (targetHash: string) => {
      const { treeRootStore } = await import('/src/stores/index.ts');
      const toHex = (bytes: Uint8Array): string => Array.from(bytes)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
      let root: { hash?: Uint8Array } | null = null;
      const unsub = treeRootStore.subscribe((value) => { root = value as { hash?: Uint8Array } | null; });
      unsub();
      if (!root?.hash) return false;
      return toHex(root.hash) === targetHash;
    },
    expectedHash,
    { timeout: timeoutMs }
  );
}

export async function getTreeRootHex(page: Page, npub: string, treeName: string): Promise<{ hashHex: string; keyHex: string | null }> {
  const root = await page.evaluate(async ({ targetNpub, targetTree }) => {
    const { getTreeRootSync } = await import('/src/stores/index.ts');
    const toHex = (bytes: Uint8Array): string => Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    const rootCid = getTreeRootSync(targetNpub, targetTree);
    if (!rootCid?.hash) return null;
    return {
      hashHex: toHex(rootCid.hash),
      keyHex: rootCid.key ? toHex(rootCid.key) : null,
    };
  }, { targetNpub: npub, targetTree: treeName });

  if (!root) {
    throw new Error(`Could not read tree root for ${npub}/${treeName}`);
  }
  return root;
}

export async function primeTreeRootInViewer(
  page: Page,
  npub: string,
  treeName: string,
  root: { hashHex: string; keyHex: string | null }
): Promise<void> {
  await page.evaluate(async ({ targetNpub, targetTree, hashHex, keyHex }) => {
    const { updateLocalRootCacheHex } = await import('/src/treeRootCache.ts');
    const { treeRootRegistry } = await import('/src/TreeRootRegistry.ts');
    const fromHex = (hex: string): Uint8Array => {
      const normalized = hex.trim().toLowerCase();
      if (!normalized || normalized.length % 2 !== 0) return new Uint8Array();
      const out = new Uint8Array(normalized.length / 2);
      for (let i = 0; i < out.length; i += 1) {
        const byte = Number.parseInt(normalized.slice(i * 2, i * 2 + 2), 16);
        if (Number.isNaN(byte)) return new Uint8Array();
        out[i] = byte;
      }
      return out;
    };

    updateLocalRootCacheHex(targetNpub, targetTree, hashHex, keyHex ?? undefined, 'link-visible');
    treeRootRegistry.setFromExternal(targetNpub, targetTree, fromHex(hashHex), 'prefetch', {
      key: keyHex ? fromHex(keyHex) : undefined,
      visibility: 'link-visible',
      updatedAt: Math.floor(Date.now() / 1000),
    });

    const adapter = (window as BoardsE2EWindow).__getWorkerAdapter?.() ?? (window as BoardsE2EWindow).__workerAdapter;
    if (adapter?.setTreeRootCache) {
      await adapter.setTreeRootCache(
        targetNpub,
        targetTree,
        fromHex(hashHex),
        keyHex ? fromHex(keyHex) : undefined,
        'link-visible'
      );
    }
  }, { targetNpub: npub, targetTree: treeName, hashHex: root.hashHex, keyHex: root.keyHex });
}

export async function ensureViewerTreeRoot(
  page: Page,
  npub: string,
  treeName: string,
  root: { hashHex: string; keyHex: string | null },
  timeoutMs: number = 60000
): Promise<void> {
  await waitForTreeRoot(page, npub, treeName, Math.min(timeoutMs, 30000)).catch(() => {});
  await primeTreeRootInViewer(page, npub, treeName, root);
  await page.evaluate(() => window.dispatchEvent(new HashChangeEvent('hashchange')));
  await waitForTreeRootHash(page, npub, treeName, root.hashHex, timeoutMs);
  await waitForTreeRootStoreHash(page, root.hashHex, Math.min(timeoutMs, 30000));
}

export async function gotoWithRetry(page: Page, url: string, attempts: number = 3): Promise<void> {
  let lastError: unknown = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      await page.goto(url);
      return;
    } catch (error) {
      lastError = error;
      const message = error instanceof Error ? error.message : String(error);
      if (!message.includes('ERR_CONNECTION_REFUSED') || attempt === attempts - 1) {
        throw error;
      }
      await page.waitForTimeout(1000 * (attempt + 1));
    }
  }

  throw lastError instanceof Error ? lastError : new Error(`Failed to navigate to ${url}`);
}

export function parseBoardShareUrl(shareUrl: string): { npub: string; treeName: string; linkKey: string | null } {
  const match = shareUrl.match(/#\/(npub[^/]+)\/([^?]+)(?:\?(.+))?$/);
  if (!match) {
    throw new Error(`Could not parse board share URL: ${shareUrl}`);
  }

  const params = new URLSearchParams(match[3] ?? '');
  return {
    npub: match[1],
    treeName: decodeURIComponent(match[2]),
    linkKey: params.get('k'),
  };
}

export async function setupFreshBoardsViewer(ownerPage: Page, viewerPage: Page, shareUrl?: string): Promise<void> {
  setupPageErrorHandler(viewerPage);
  await gotoWithRetry(viewerPage, '/boards.html#/');
  await waitForAppReady(viewerPage, 60000);
  await useLocalRelay(viewerPage);
  await configureBlossomServers(viewerPage);
  await ensureLoggedIn(viewerPage, 30000);
  await enableOthersPool(viewerPage, 10);
  await waitForRelayConnected(viewerPage, 30000);
  await ensureDistinctViewerIdentity(ownerPage, viewerPage);

  if (shareUrl) {
    // Identity and network settings above persist across navigation. A protected
    // route must render its access notice without another relay reconfiguration.
    await gotoWithRetry(viewerPage, shareUrl);
    await waitForAppReady(viewerPage, 60000);
  }
}

export async function createBoard(
  page: Page,
  boardName: string,
  visibility: 'public' | 'link-visible' | 'private' = 'public'
): Promise<string> {
  let workerCrashed = false;
  page.on('console', (message) => {
    if (message.type() === 'error' && message.text().includes('[WorkerAdapter] Worker crashed')) {
      workerCrashed = true;
    }
  });

  let created = false;
  for (let attempt = 0; attempt < 3 && !created; attempt += 1) {
    await openCreateBoardModal(page);
    const input = page.getByPlaceholder('Board name');
    const createButton = page.getByRole('button', { name: /^create$/i });
    try {
      await input.fill(boardName, { timeout: 5000 });
      if (visibility !== 'public') {
        await page.getByRole('button', { name: new RegExp(`^${visibility}$`, 'i') }).click();
      }
      await createButton.click();
      created = true;
    } catch {
      await page.waitForTimeout(1000);
    }
  }

  expect(created).toBe(true);
  expect(workerCrashed).toBe(false);
  await page.waitForURL(new RegExp(`/boards\\.html#\\/npub.*\\/boards%2F${encodeURIComponent(boardName)}`), { timeout: 30000 });
  await expect(page.locator(`text=${boardName}`)).toBeVisible({ timeout: 30000 });
  await expect(page.locator('text=Failed to create board.')).toHaveCount(0);
  return page.url();
}

export async function ensureDistinctViewerIdentity(ownerPage: Page, viewerPage: Page): Promise<void> {
  const ownerPubkey = await readNostrPubkey(ownerPage);
  const initialViewerPubkey = await readNostrPubkey(viewerPage);
  if (!ownerPubkey || initialViewerPubkey !== ownerPubkey) return;

  await viewerPage.evaluate(async () => {
    const { generateNewKey } = await import('/src/nostr.ts');
    await generateNewKey();
  });
  await viewerPage.waitForFunction((expectedOwnerPubkey) => {
    const raw = (window as BoardsE2EWindow).__nostrStore?.getState?.().pubkey ?? null;
    const normalize = (value: unknown): string | null => {
      if (typeof value === 'string') return value;
      if (!value || typeof value !== 'object') return null;
      const candidate = value as {
        pubkey?: unknown;
        hex?: unknown;
        value?: unknown;
        toHex?: () => string;
        toString?: () => string;
      };
      if (typeof candidate.pubkey === 'string') return candidate.pubkey;
      if (typeof candidate.hex === 'string') return candidate.hex;
      if (typeof candidate.value === 'string') return candidate.value;
      if (typeof candidate.toHex === 'function') return candidate.toHex();
      if (typeof candidate.toString === 'function') {
        const text = candidate.toString();
        if (text && text !== '[object Object]') return text;
      }
      return null;
    };
    const pubkey = normalize(raw);
    return !!pubkey && pubkey !== expectedOwnerPubkey;
  }, ownerPubkey, { timeout: 20000 });
  await waitForRelayConnected(viewerPage, 30000);
}

export async function openCreateBoardModal(page: Page, attempts: number = 3): Promise<void> {
  const heading = page.getByRole('heading', { name: 'Create Board' });
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    await page.getByRole('button', { name: /new board/i }).click();
    try {
      await expect(heading).toBeVisible({ timeout: 5000 });
      return;
    } catch (error) {
      if (attempt === attempts - 1) {
        throw error;
      }
      await page.keyboard.press('Escape').catch(() => {});
      await page.waitForTimeout(500 * (attempt + 1));
    }
  }
}

export async function addBoardPermissionEntry(
  dialog: Locator,
  npub: string,
  role: 'admin' | 'writer'
): Promise<void> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const roleSelect = dialog.getByRole('combobox');
    if (await roleSelect.count()) {
      await roleSelect.first().selectOption(role);
    }

    await dialog.getByPlaceholder('npub1...').fill(npub);

    const confirmButton = dialog.getByRole('button', { name: new RegExp(`^add ${role}$`, 'i') });
    const addButton = (await confirmButton.isVisible().catch(() => false))
      ? confirmButton
      : dialog.getByRole('button', { name: /^add$/i });

    try {
      await addButton.click({ timeout: 5000 });
      return;
    } catch (error) {
      if (attempt === 2) {
        throw error;
      }
      await expect(dialog).toBeVisible({ timeout: 5000 });
    }
  }
}

export async function waitForBoardPermissionEntry(
  page: Page,
  npub: string,
  timeoutMs: number = 60000
): Promise<void> {
  const dialog = page.getByRole('dialog', { name: 'Board Permissions' });
  const openButton = page.getByRole('button', { name: /permissions/i });
  const closeButton = dialog.getByRole('button', { name: /^close$/i }).last();
  const memberLink = dialog.locator(`a[href="#/${npub}/profile"]`);

  await page.waitForFunction(async (targetNpub) => {
    const { getCurrentRootCid } = await import('/src/actions/route.ts');
    const { getRouteSync } = await import('/src/stores/index.ts');
    const { getTree, LinkType } = await import('/src/store.ts');
    const { BOARD_PERMISSIONS_FILE } = await import('/src/lib/boards/constants.ts');
    const { parseBoardPermissions } = await import('/src/lib/boards/permissions.ts');

    const root = getCurrentRootCid();
    const route = getRouteSync();
    const ownerNpub = route.npub;
    if (!root || !ownerNpub) return false;

    const entries = await getTree().listDirectory(root);
    const permissionsEntry = entries?.find((entry) => entry.name === BOARD_PERMISSIONS_FILE && entry.type === LinkType.Blob);
    if (!permissionsEntry) return false;

    const permissionsData = await getTree().readFile(permissionsEntry.cid);
    if (!permissionsData) return false;

    const permissions = parseBoardPermissions(permissionsData, ownerNpub);
    return permissions.admins.includes(targetNpub) || permissions.writers.includes(targetNpub);
  }, npub, { timeout: timeoutMs });

  if (!(await dialog.isVisible().catch(() => false))) {
    await openButton.click();
  }

  let matched = false;
  const perAttemptTimeout = Math.max(10000, Math.floor(timeoutMs / 3));
  for (let attempt = 0; attempt < 3 && !matched; attempt += 1) {
    await expect(dialog).toBeVisible({ timeout: 10000 });
    try {
      await expect(memberLink).toHaveCount(1, { timeout: perAttemptTimeout });
      matched = true;
      break;
    } catch (error) {
      if (attempt === 2) throw error;
      await closeButton.click();
      await expect(dialog).toHaveCount(0, { timeout: 10000 });
      await page.waitForTimeout(500);
      await openButton.click();
    }
  }

  await closeButton.click();
  await expect(dialog).toHaveCount(0, { timeout: 10000 });
}
