export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  boards: {
    name: 'boards',
    appName: 'Iris Boards',
    distDir: 'dist-boards',
    treeName: 'boards',
    defaultWorkerName: 'iris-boards',
    defaultDomains: ['boards.iris.to'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_BOARDS',
    pagesProjectEnv: 'CF_PAGES_PROJECT_BOARDS',
    buildCommand: ['pnpm', 'run', 'build:boards'],
    testCommands: [
      ['node', './scripts/smoke-graph-policy.mjs', 'boards'],
      ['pnpm', 'run', 'check:types'],
      ['node', './scripts/smoke-boards-iris-portable.mjs'],
      ['pnpm', 'run', 'test:unit'],
      ['pnpm', 'run', 'test:e2e'],
    ],
  },
};

export const releaseProfileNames = ['boards'];
