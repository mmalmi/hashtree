# Changelog

## 2.6.48 - 2026-10-15

- Mention people with `@` and add emoji with `:` in direct and group chats. Mention identities survive editing, undo, and redo, including people with the same name.
- Choose whether mentions can notify in muted groups, with the preference synced privately between compatible linked devices. In browsers, muted mentions notify only while the app is running.
- Clear the matching notification when a read arrives from another device, without clearing other unread messages.
- Show readable attachment labels in chat lists and notifications, and clearer clickable links.
- Share private personal and group invitation links with reliable group admission.
- Keep linked devices signed in when an older device list arrives during reload, while honoring newer removals.
- Resume private sync after reloading a linked browser, even when devices cannot connect directly. Update the native app for the matching recovery fix.

## 2.6.46 - 2026-10-08

- Show clearer device-link errors without waiting for a timeout.
- Recover connections more reliably and keep repeated connection attempts bounded.

## 2.6.44 - 2026-10-06

- Keep the device-link code available until you approve or cancel it.
- Transfer message history through FIPS routes even when your devices cannot connect directly.
- Add routed native/browser regression coverage and a physical iPhone public-network check that verifies history survives browser reload.
- Update the approving native app to v2026.10.6.1 (iOS 2026.10.601) or later for the matching approval and history fixes.

## 2.6.43 - 2026-10-06

- Link devices even when one message server is unavailable, including message history from your other device.
- When approving from a phone or desktop app, update that app to v2026.10.6 (iOS 2026.10.600) or later to get the same fix. Updating the website alone does not update the approving app.
- Test native-to-browser linking and history transfer during server outages, and require device-link browser checks before publishing.

## 2.6.42 - 2026-10-04

- Respect the chosen message-history boundary for changes copied between your devices, including edits queued before linking.
- Remove legacy queued copies that could bypass the history choice.

## 2.6.41 - 2026-10-04

- Edit sent messages and view their edit history, or delete messages for yourself or everyone.
- Choose whether others can delete messages they sent you.
- Sync edits and deletions with compatible linked devices while preserving the chosen history boundary.

## 2.6.40 - 2026-10-04

- Process invite links promptly, clear them from the address bar, and focus the name field after dismissing the desktop app prompt.
- Deliver replies and start direct file transfers without requiring a previous message.
- Stream direct files and choose their destination on acceptance in supported browsers.
- Add a default-on “Open chat when someone joins” option to the invite view.

## 2.6.39 - 2026-10-04

- Restore peer connections after another browser reloads.
- Keep downloaded shared files available to peers after restarting the app.

## 2.6.37 - 2026-10-03

- Link devices through one approval flow, with working pasted links from current and older Iris apps.
- Choose chats and groups only or include old messages from the approving device, with progress while messages sync.
- Repair missing messages after reconnecting, preserve deletions, and keep the history choice private.
- Fix linking and sync after reopening saved groups.
- Restore linking for accounts with duplicate device lists from older apps.
- Reconnect linked devices promptly and recover messages across web and native apps.

## 2.6.36 - 2026-10-02

- Keep direct calls connected when devices start connecting to each other at the same time.
- Improve privacy when syncing favorites, nicknames, notes, device names, and muted chats.
- Update your other devices and calling contacts too. Calls to an older app may not ring while it is closed. Existing chats and linked devices stay connected.

## 2.6.35 - 2026-10-01

- Sync private favorites, nicknames, and notes between your devices and compatible Iris apps.
- Keep offline edits and clears until saved, and include private details when recovering an approved linked device.
- Retry declined signer requests only when you choose Retry sync.

## 2.6.34 - 2026-10-01

- Send multiple files directly in a chat after the recipient accepts, including between the web and native apps.
- Keep saved contact names until you approve changes, with private favorites and public follows on profiles.
- Show blue, gold, and gray checkmarks beside profile follow explanations and at the upper-right of other avatars.

## 2.6.33 - 2026-09-30

- Reduce unnecessary routing traffic and recover peer sessions reliably with the audited FIPS runtime.
- Close canceled peer connections promptly and preserve usable routes during retries.

## 2.6.32 - 2026-09-30

- Recover peer connection answers after temporary route failures with the updated shared networking runtime.
- Preserve existing accounts and offline data while updating the immutable file transport.

## 2.6.31 - 2026-09-30

- Route larger peer connection offers over paths that can carry them.
- Resume peer connections promptly after authenticated signaling recovers.
- Preserve device names in synchronization snapshots and avoid duplicate
  connection startups when device metadata changes.

## 2.6.30 - 2026-09-30

- Keep shared message-server batches within common filter limits so history
  and profile lookups are not rejected during busy sessions.

## 2.6.29 - 2026-09-30

- Replace NDK with the shared nostr-pubsub worker runtime and Hashtree event
  indexes, preserving existing secret keys and encrypted messaging sessions.
- Share encrypted attachment caches over existing FIPS connections with
  approved contacts and devices; keep private event exchange account-scoped.
- Keep conversations and pending messages available across offline reloads,
  saving outgoing messages before displaying them.
- Batch peer subscriptions and wait for stored history before completing
  lookups, including people search and device authorization.

## 2.6.25 - 2026-09-23

- Improve direct calls across different networks using STUN, while retaining
  local connections and encrypted routing through FIPS nodes.
- Start routed calls without waiting for a direct connection, and prevent a
  canceled connection attempt from replacing a working one.
- Use shared FIPS connection fixes so transport handover preserves active calls.

## 2.6.22 - 2026-09-22

- Show matching profiles even when their messaging setup is unavailable or uses
  an older format. Those results open the profile; ready accounts can open a chat.
- Clear people-search results when the query is erased, and preserve verified
  messaging availability across an immediate reload.

## 2.6.21 - 2026-09-22

- Find people from Sirius's network when an account has no follows, without
  changing its follow list. Personal follows and mutes still take precedence.
- Keep messaging-support checks running as search results arrive and fetch
  them alongside profile names for faster discovery.

## 2.6.20 - 2026-09-22

- Rank people search by social connections, hide personally muted and overmuted
  accounts, and search the shared profile index with cached results, batched
  lookups, and cancellation when the query changes.
- Restore global name search by using the active profile index and removing
  the retired service address.
- Upgrade Nostr Double Ratchet to 0.0.171 so removing group members rotates sender keys
  before the next message, while preserving recovery for missed group messages.

## 2.6.19 - 2026-09-07

- Update Hashtree to security runtime 0.5.7 with remote blob integrity checks.
- Include the verified Nostr Double Ratchet security update for encrypted messaging.

## 2.6.18 - 2026-09-05

- Find followed people and pasted user IDs with verified messaging support,
  including cached results when message servers are unavailable.
- Show published device counts and local encrypted session counts on user
  profiles, with active and older sessions available in the details.
- Keep revoked devices hidden when older device information arrives later.

## 2.6.17 - 2026-09-05

- Preserve leading Unicode byte-order marks in synced messages and reject
  malformed base64 consistently with the native app.
- Upgrade double ratchet to 0.0.167, fixing delayed messages becoming unreadable
  after encryption keys rotate or a session is restored.
- Test device-sync interoperability against explicitly selected native source,
  reuse supplied native executables in browser tests, and use the configured
  test origin for invites and notification permissions.

## 2.6.16 - 2026-07-20

- Consolidate duplicated delivery tracking, group mutations, persisted
  settings, and reactive UI state while preserving the existing messaging and
  release behavior with less runtime code.
- Default delivery receipts, read receipts, and typing indicators to off while
  keeping each available as an explicit privacy setting; apply the typing
  preference to group chats as well as direct chats.
- Upgrade the shared browser pubsub runtime to `nostr-pubsub` 0.5.1 and pass
  the compressed local FIPS identity required by its reliable TCP
  `REQ`/`INV`/`WANT`/`EVENT` transport.
- Upgrade to FIPS TypeScript runtime 0.0.29, negotiating direct FSP only with
  capable peers while retaining routed FSP compatibility with upstream FIPS
  0.4.1 and older runtimes.

## 2.6.15 - 2026-07-17

- Upgrade the shared authenticated `nostr.pubsub/1` client to immutable
  `nostr-pubsub` 0.3.1 so browser subscriptions recover after a temporarily
  unavailable FIPS route reconnects.
- Preserve explicit peer admission, bounded replay, the 65,525-byte FSP
  datagram limit, and the separate device-sync v1 transport unchanged.

## 2.6.14 - 2026-07-16

- Upgrade the browser to immutable Hashtree core 0.3.0, sharing the native
  `BlobRoute` request/result/context boundary without changing the device-sync
  port, v1 JSON variants, 64 KiB record bound, or pagination.

## 2.6.13 - 2026-07-16

- Pin the immutable FIPS TypeScript 0.0.26 runtime, preserving browser identity
  across reloads and rejecting stale handshake epochs.
- Align browser device sync with the unchanged Iris Chat 0.1.39 native v1
  protocol at canonical source `6514f424fc16b0d435a22a98081fc4569c15ad2a`
  and its real Rust process fixture.
- Carry signed Nostr events only through the shared authenticated
  `nostr.pubsub/1` transport; device-sync records remain on FIPS TCP port 7369.
