import 'fake-indexeddb/auto'
import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { writable } from 'svelte/store'
const fixture = vi.hoisted(() => ({ supported: true, requests: [] as Record<string, unknown>[], authors: new Map(), pushAuthors: new Map<string, string[]>(), invites: [] as string[], groups: [] as Array<{chatId:string;authors:string[];subscriptionAuthors:string[]}> }))
vi.mock('./identity', () => ({ identity: writable(null), nostrClient: writable({ signer: {} }) }))
vi.mock('./chatMuteControl', () => ({ sendChatMuteControl: vi.fn(async () => {}) }))
vi.mock('./groupPush',()=>({groupPushChannels:async()=>fixture.groups}))
vi.mock('./chat', () => ({ getInviteEphemeralPubkeys: () => fixture.invites }))
vi.mock('./privateChats', () => ({ getNdrRuntime: () => ({ getSessionUserRecords: () => fixture.authors, getSessionMessagePushAuthorPubkeys: (owner: string) => fixture.pushAuthors.get(owner) ?? [] }) }))
vi.mock('./notificationPermission', () => ({ getNotificationSupportError: () => null, requestNotificationPermission: async () => ({ permission: 'granted' }) }))
vi.mock('./nostrClient', () => ({ AppEvent: class { async sign() {} async toNostrEvent() { return {} } } }))
import { identity } from './identity'
import { notificationSettings } from './notificationStore'
import { subscribeToDMNotifications } from './notifications'
import { setChatMute, clearChatMutes } from './chatMuteStore'
import { clearAllData, db } from './storage'

beforeEach(() => {
  fixture.requests = []
  fixture.groups = []
  fixture.invites = []
  fixture.supported = true
  fixture.pushAuthors = new Map(['alice', 'bob'].map(owner => [owner === 'alice' ? 'a'.repeat(64) : 'b'.repeat(64), [`${owner}-current`, `${owner}-next`]]))
  fixture.authors = new Map(['alice', 'bob'].map(owner => [owner === 'alice' ? 'a'.repeat(64) : 'b'.repeat(64), { devices: new Map([['device', {
    activeSession: { state: { theirCurrentNostrPublicKey: `${owner}-current`, theirNextNostrPublicKey: `${owner}-next` } }, inactiveSessions: [],
  }]]) }]))
  identity.set({ pubkey: 'profile', displayName: null, isNip07: false })
  notificationSettings.setEnabled(false)
  vi.stubGlobal('Notification', { permission: 'granted' })
  vi.stubGlobal('navigator', { serviceWorker: { ready: Promise.resolve({ pushManager: {
    getSubscription: async () => ({ endpoint: 'https://push.invalid/device', options: {userVisibleOnly:true}, getKey: () => new ArrayBuffer(2) }),
  } }) } })
  vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
    if (url.endsWith('/info')) return new Response(JSON.stringify({ vapid_public_key: 'AQID', supports_timed_filters: fixture.supported }))
    if (init?.method === 'POST') {
      fixture.requests.push(JSON.parse(String(init.body)))
      return new Response(JSON.stringify({ id: 'messages' }))
    }
    return new Response(JSON.stringify({ messages: { filter: { kinds: [1060], authors: ['alice-current', 'bob-current'] },
      web_push_subscriptions: [{ endpoint: 'https://push.invalid/device' }], subscriber: 'profile' } }))
  }))
})
afterEach(async () => { notificationSettings.setEnabled(false); await clearChatMutes(); await clearAllData(); identity.set(null); vi.unstubAllGlobals() })

it('production subscription builder delays every muted ratchet author while retaining other chats', async () => {
  await setChatMute('a'.repeat(64), 3600)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  const filters = fixture.requests.at(-1)?.filters as Array<{ authors: string[]; since?: number }>
  expect(filters[0]).toEqual({ kinds: [1060], authors: ['bob-current', 'bob-next'] })
  expect(filters[1].authors).toEqual(['alice-current', 'alice-next'])
  expect(filters[1].since).toBeGreaterThan(Math.floor(Date.now() / 1000) + 3590)
})
it('production subscription update conservatively excludes timed authors on a legacy server', async () => {
  fixture.supported = false
  await setChatMute('a'.repeat(64), 3600)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  expect(fixture.requests.at(-1)?.filters).toEqual([{ kinds: [1060], authors: ['bob-current', 'bob-next'] }])
})
it('muting every chat replaces the old subscription with an empty author list, never a wildcard', async () => {
  await setChatMute('a'.repeat(64), 0)
  await setChatMute('b'.repeat(64), 0)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  expect(fixture.requests.at(-1)?.filter).toEqual({ kinds: [1060], authors: [] })
  expect(fixture.requests.at(-1)?.filters).toEqual([{ kinds: [1060], authors: [] }])
})

it('keeps pairwise and invite routing without revealing any shared group author',async()=>{
  fixture.groups=[{chatId:'group:open',authors:['group-open','group-own'],subscriptionAuthors:['group-open']},{chatId:'group:quiet',authors:['group-quiet'],subscriptionAuthors:['group-quiet']}]
  fixture.invites=['own-invite-key']
  fixture.authors.set('profile',{devices:new Map([['own',{activeSession:{state:{theirCurrentNostrPublicKey:'own-control'}},inactiveSessions:[]}]])})
  await setChatMute('group:quiet',0)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  const wire=JSON.stringify(fixture.requests)
  for(const shared of ['group-open','group-quiet','group-own','own-control']) expect(wire).not.toContain(shared)
  for(const routed of ['alice-current','bob-current','own-invite-key']) expect(wire).toContain(routed)
})


it('uses the ratchet privacy projection instead of exposing restored invite-linked sender keys', async () => {
  fixture.authors.get('a'.repeat(64)).devices.get('device').activeSession.state.theirCurrentNostrPublicKey = 'public-invite-key'
  fixture.pushAuthors.set('a'.repeat(64), []) // Restored unsafe session quarantined by the library.
  expect((await subscribeToDMNotifications()).success).toBe(true)
  const body = fixture.requests.at(-1)
  expect(body?.filters).toEqual([{ kinds: [1060], authors: ['bob-current', 'bob-next'] }])
  expect(JSON.stringify(body)).not.toContain('public-invite-key')
  expect(body).not.toHaveProperty('subscriber')
})

it('retains individual sessions for an unmuted group when its member direct chats are muted', async () => {
  await db.groups.put({id:'friends',name:'Friends',members:['profile','a'.repeat(64),'b'.repeat(64)],admins:['profile'],createdAt:100})
  await setChatMute('a'.repeat(64),0)
  await setChatMute('b'.repeat(64),0)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  expect(fixture.requests.at(-1)?.filters).toEqual([{kinds:[1060],authors:['alice-current','alice-next','bob-current','bob-next']}])
  await setChatMute('group:friends',0)
  expect((await subscribeToDMNotifications()).success).toBe(true)
  expect(fixture.requests.at(-1)?.filters).toEqual([{kinds:[1060],authors:[]}])
})
