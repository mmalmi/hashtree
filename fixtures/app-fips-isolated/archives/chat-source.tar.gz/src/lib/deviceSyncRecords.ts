import { authorizationEvent } from './authorizationSync'
import { privateSettingSnapshot } from './privateSettings'
import { parsePrivateEvent, type PrivateEvent } from 'nostr-social-graph/privateEvents'
import { privateEventState, validMessageRead, type MessageReadState } from './privateStateProtocol'
import { parsePrivateContactFact, type PrivateContactFact } from 'nostr-social-graph/privateContactFacts'
import { sha256 } from '@noble/hashes/sha2.js'
import { bytesToHex } from '@noble/hashes/utils.js'
import { verifyEvent, type Event } from 'nostr-tools'
import type { DeviceSyncGroup, DeviceSyncMessage } from './deviceSyncProtocol'

export type DeviceSyncScope = 'history' | 'state'
export interface DeviceSyncReaction {
  chatId: string
  id: string
  author: string
  createdAt: number
  createdAtMs?: number
  messageId: string
  emoji: string
}
export interface DeviceSyncMessageMutation {
  chatId: string
  id: string
  author: string
  createdAt: number
  createdAtMs?: number
  messageId: string
  operation: 'edit' | 'delete'
  content: string
  expiresAt?: number
}
export interface DeviceSyncGroupSettings {
  groupId: string
  id: string
  author: string
  createdAt: number
  createdAtMs?: number
  messageTtlSeconds: number | null
}
export type DeviceSyncRecord =
  | { type: 'authorization'; event: Event }
  | { type: 'privateEvent'; event: PrivateEvent }
  | { type: 'privateBlock'; event: PrivateEvent }
  | { type: 'privateNameApproval'; event: PrivateEvent }
  | { type: 'messageRead'; chatId: string; messageId: string; read: MessageReadState }
  | { type: 'privateContactFact'; fact: PrivateContactFact }
  | { type: 'message'; message: DeviceSyncMessage }
  | { type: 'reaction'; reaction: DeviceSyncReaction }
  | { type: 'messageMutation'; mutation: DeviceSyncMessageMutation }
  | { type: 'group'; group: DeviceSyncGroup }
  | { type: 'groupSettings'; settings: DeviceSyncGroupSettings }
  | { type: 'profile'; event: Event }

export function deviceSyncRecordId(record: DeviceSyncRecord): string {
  let input: unknown[]
  switch (record.type) {
    case 'authorization': case 'privateEvent': case 'privateBlock': case 'privateNameApproval': return record.event.id
    case 'messageRead': input = ['messageRead', record.chatId, record.messageId, record.read.createdAtSecs, record.read.expiresAtSecs ?? null]; break
    case 'privateContactFact': return record.fact.id
    case 'message': input = [record.message.chatId, record.message.id]; break
    case 'messageMutation': input = ['messageMutation', record.mutation.chatId, record.mutation.id]; break
    case 'reaction': input = ['reaction', record.reaction.chatId, record.reaction.id]; break
    case 'groupSettings': input = ['groupSettings', record.settings.groupId, record.settings.id]; break
    case 'profile': input = ['profile', record.event.pubkey, record.event.id]; break
    case 'group': {
      const g = record.group
      input = ['group', g.id, g.revision, g.updatedAt, g.name, g.description ?? null, g.picture ?? null,
        g.createdBy, [...new Set(g.members)].sort(), [...new Set(g.admins)].sort(), g.protocol ?? 'pairwise_fanout_v1', g.createdAt]
      break
    }
  }
  return bytesToHex(sha256(new TextEncoder().encode(JSON.stringify(input))))
}

export function deviceSyncRecordScope(record: DeviceSyncRecord): DeviceSyncScope {
  return record.type === 'message' || record.type === 'reaction' || record.type === 'messageMutation' ? 'history' : 'state'
}

export function deviceSyncRecordTime(record: DeviceSyncRecord): number {
  return record.type === 'messageMutation' ? record.mutation.createdAt : record.type === 'message' ? record.message.createdAt : record.type === 'reaction' ? record.reaction.createdAt : 0
}

export function compareControlHead(a: { createdAt: number; createdAtMs?: number; id: string }, b: { createdAt: number; createdAtMs?: number; id: string }): number {
  return (a.createdAtMs ?? a.createdAt * 1000) - (b.createdAtMs ?? b.createdAt * 1000) || (a.id < b.id ? -1 : Number(a.id > b.id))
}

const object = (value: unknown): value is Record<string, any> => !!value && typeof value === 'object' && !Array.isArray(value)
const key = (value: unknown): value is string => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value)
const id = (value: unknown): value is string => typeof value === 'string' && value.length > 0 && value.length <= 128
const time = (value: unknown): value is number => Number.isSafeInteger(value) && (value as number) >= 0
const chat = (value: unknown): value is string => key(value) || typeof value === 'string' && value.startsWith('group:') && id(value.slice(6))
const clock = (value: Record<string, any>) => time(value.createdAt) && (value.createdAtMs === undefined ||
  time(value.createdAtMs) && Math.floor(value.createdAtMs / 1000) === value.createdAt)

export function verifiedProfileEvent(value: unknown, now = Date.now()): Event | undefined {
  if (!object(value) || value.kind !== 0 || !key(value.pubkey) || !key(value.id) || !time(value.created_at) ||
    value.created_at > now / 1000 + 300 || typeof value.content !== 'string' || new TextEncoder().encode(value.content).length > 32768 ||
    typeof value.sig !== 'string' || !/^[a-f0-9]{128}$/.test(value.sig) || !Array.isArray(value.tags) ||
    value.tags.length > 256 || !value.tags.every((tag: unknown) => Array.isArray(tag) && tag.every(item => typeof item === 'string'))) return
  const event: Event = { id: value.id, pubkey: value.pubkey, kind: 0, created_at: value.created_at,
    tags: value.tags.map((tag: string[]) => [...tag]), content: value.content, sig: value.sig }
  try { if (!object(JSON.parse(event.content)) || !verifyEvent({ ...event })) return } catch { return }
  return event
}

export function parseDeviceSyncRecord(value: unknown, parsers: {
  message(value: unknown): DeviceSyncMessage
  group(value: unknown): boolean
}): DeviceSyncRecord {
  if (!object(value)) throw new Error('Invalid device sync record')
  if ((value.type === 'privateBlock' && value.event?.kind === 10454 || value.type === 'privateNameApproval' && value.event?.kind === 10455) && privateEventState(value.event)) return { type: value.type, event: parsePrivateEvent(value.event, true) }
  if (value.type === 'authorization') { const event = authorizationEvent(value.event); if (event) return { type: 'authorization', event }; throw new Error('Invalid authorization event') }
  if (value.type === 'privateEvent') { const event = parsePrivateEvent(value.event); privateSettingSnapshot(event, event.pubkey); return { type: 'privateEvent', event } }
  if (value.type === 'messageRead' && chat(value.chatId) && id(value.messageId) && validMessageRead(value.read)) return { type: 'messageRead', chatId: value.chatId, messageId: value.messageId, read: value.read }
  if (value.type === 'privateContactFact') { parsePrivateContactFact(value.fact, value.fact?.pubkey); return { type: 'privateContactFact', fact: value.fact } }
  if (value.type === 'message') return { type: 'message', message: parsers.message(value.message) }
  if (value.type === 'messageMutation') {
    const m = value.mutation
    if (object(m) && chat(m.chatId) && key(m.id) && key(m.author) && clock(m) && id(m.messageId) && m.id !== m.messageId &&
      (m.expiresAt === undefined || time(m.expiresAt)) && typeof m.content === 'string' && (m.operation === 'delete' ? m.content === '' : m.operation === 'edit' &&
        m.content.trim().length > 0 && new TextEncoder().encode(m.content).length <= 32768)) {
      return { type: 'messageMutation', mutation: { chatId: m.chatId, id: m.id, author: m.author, createdAt: m.createdAt,
        ...(m.createdAtMs !== undefined && { createdAtMs: m.createdAtMs }), messageId: m.messageId, operation: m.operation, content: m.content, ...(m.expiresAt !== undefined && { expiresAt: m.expiresAt }) } }
    }
  }
  if (value.type === 'reaction') {
    const r = value.reaction
    if (object(r) && chat(r.chatId) && key(r.id) && key(r.author) && clock(r) && id(r.messageId) && typeof r.emoji === 'string' && new TextEncoder().encode(r.emoji).length <= 256) {
      return { type: 'reaction', reaction: { chatId: r.chatId, id: r.id, author: r.author, createdAt: r.createdAt,
        ...(r.createdAtMs !== undefined && { createdAtMs: r.createdAtMs }), messageId: r.messageId, emoji: r.emoji } }
    }
  }
  if (value.type === 'group' && parsers.group(value.group)) return { type: 'group', group: value.group }
  if (value.type === 'groupSettings') {
    const s = value.settings
    if (object(s) && id(s.groupId) && key(s.id) && key(s.author) && clock(s) && (s.messageTtlSeconds === null || time(s.messageTtlSeconds) && s.messageTtlSeconds > 0)) {
      return { type: 'groupSettings', settings: { groupId: s.groupId, id: s.id, author: s.author, createdAt: s.createdAt,
        ...(s.createdAtMs !== undefined && { createdAtMs: s.createdAtMs }), messageTtlSeconds: s.messageTtlSeconds } }
    }
  }
  if (value.type === 'profile') {
    const event = verifiedProfileEvent(value.event)
    if (event) return { type: 'profile', event }
  }
  throw new Error('Invalid device sync record')
}

/** Kind 7 is plain emoji; accept the former web group JSON wrapper on ingress. */
export function reactionControl(rumor: { content: string; tags: string[][] }): { messageId: string; emoji: string } | undefined {
  const messageId = rumor.tags.find(tag => tag[0] === 'e')?.[1]
  if (!messageId) return
  let emoji = rumor.content
  if (emoji.startsWith('{')) {
    try {
      const value = JSON.parse(emoji)
      if (value?.type === 'reaction') {
        if (value.messageId !== messageId || typeof value.emoji !== 'string') return
        emoji = value.emoji
      }
    } catch { /* Plain reaction text can begin with a brace. */ }
  }
  return new TextEncoder().encode(emoji).length <= 256 ? { messageId, emoji } : undefined
}
