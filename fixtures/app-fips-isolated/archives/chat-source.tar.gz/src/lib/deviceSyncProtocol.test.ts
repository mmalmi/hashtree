// @vitest-environment node
import { describe, expect, it } from 'vitest'
import {
  DEVICE_SYNC_MAX_PACKET_BYTES,
  DEVICE_SYNC_RECORD_BATCH,
  DEVICE_SYNC_PAGE_PACKETS,
  DEVICE_SYNC_PORT,
  DeviceSyncProtocolError,
  encodeDeviceSyncPacket,
  parseDeviceSyncPacket,
  type DeviceSyncPacket,
  type DeviceSyncSnapshot,
} from './deviceSyncProtocol'

const owner = 'a'.repeat(64)
const peer = 'b'.repeat(64)

const packets: DeviceSyncPacket[] = [
  { v: 1, type: 'request', rosterAt: 42 },
  {
    v: 1,
    type: 'request',
    rosterAt: 42,
    page: { kind: 'metadata', offset: 32 },
  },
  { v: 1, type: 'resyncRequired' },
  {
    v: 1,
    type: 'pageEnd',
    rosterAt: 42,
    next: null,
  },
  {
    v: 1,
    type: 'snapshot',
    rosterAt: 42,
    chats: [],
    appKeys: [],
    groups: [],
    messages: [{
      chatId: peer,
      id: 'message-1',
      body: 'Hello, linked device 👋',
      author: owner,
      createdAt: 43,
    }],
  },
]

describe('native device-sync protocol', () => {
  it('locks the native service and page bounds', () => {
    expect(DEVICE_SYNC_PORT).toBe(7369)
    expect(DEVICE_SYNC_MAX_PACKET_BYTES).toBe(64 * 1024)
    expect(DEVICE_SYNC_RECORD_BATCH).toBe(32)
    expect(DEVICE_SYNC_PAGE_PACKETS).toBe(32)
  })

  it.each(packets)('round-trips $type packets', (packet: DeviceSyncPacket) => {
    expect(parseDeviceSyncPacket(encodeDeviceSyncPacket(packet), owner)).toEqual(packet)
  })

  it('uses the native base64 representation for message bodies', () => {
    const packet = packets.at(-1) as DeviceSyncSnapshot
    const wire = JSON.parse(new TextDecoder().decode(encodeDeviceSyncPacket(packet)))
    expect(wire.messages[0].body).toBe('SGVsbG8sIGxpbmtlZCBkZXZpY2Ug8J+Riw==')
  })

  it('accepts native group read-state rows alongside direct chat metadata', () => {
    const packet: DeviceSyncSnapshot = {
      ...packets.at(-1) as DeviceSyncSnapshot,
      chats: [{ id: peer, updatedAt: 43 }, { id: 'group:friends', updatedAt: 44 }],
    }
    expect(parseDeviceSyncPacket(encodeDeviceSyncPacket(packet), owner)).toEqual(packet)
    expect(() => parseDeviceSyncPacket(encodeDeviceSyncPacket({
      ...packet, chats: [{ id: 'group:', updatedAt: 44 }],
    }), owner)).toThrow(DeviceSyncProtocolError)
  })

  it('preserves a leading Unicode byte-order mark in a message body', () => {
    const packet = packets.at(-1) as DeviceSyncSnapshot
    const snapshot = {
      ...packet,
      messages: [{ ...packet.messages[0], body: '\uFEFFnative ↔ browser' }],
    }
    expect(parseDeviceSyncPacket(encodeDeviceSyncPacket(snapshot), owner)).toEqual(snapshot)
  })

  it.each(['YR==', 'YWJ=', 'YQ', 'YQ==\n'])('rejects noncanonical native base64 %j', (body: string) => {
    const packet = packets.at(-1) as DeviceSyncSnapshot
    const wire = { ...packet, messages: [{ ...packet.messages[0], body }] }
    expect(() => parseDeviceSyncPacket(
      new TextEncoder().encode(JSON.stringify(wire)), owner,
    )).toThrow(DeviceSyncProtocolError)
  })

  it('rejects obsolete message pagination and the removed message-only protocol', () => {
    for (const packet of [
      { v: 1, type: 'request', rosterAt: 1, page: { kind: 'messages', after: null } },
      { v: 1, type: 'historyMessages', session: 'a'.repeat(32), messages: [], requested: [] },
      { v: 1, type: 'historyPageEnd', linkAt: 1, linkId: 'a'.repeat(64) },
      { v: 1, type: 'historyOpen', session: 'a'.repeat(32), since: 0, until: 1, frame: '00' },
      { v: 1, type: 'historyOpen', scope: 'history', prefix: 'A', session: 'a'.repeat(32), since: 0, until: 1, frame: '00' },
    ]) expect(() => parseDeviceSyncPacket(new TextEncoder().encode(JSON.stringify(packet)), owner)).toThrow(DeviceSyncProtocolError)
  })
  it('treats a native null request page as the initial page', () => {
    const payload = new TextEncoder().encode('{"v":1,"type":"request","rosterAt":42,"page":null}')
    expect(parseDeviceSyncPacket(payload, owner)).toEqual({
      v: 1,
      type: 'request',
      rosterAt: 42,
    })
  })

  it('accepts an exact 64 KiB record and rejects one byte more', () => {
    const request = JSON.stringify({ v: 1, type: 'request', rosterAt: 42 })
    const exact = new TextEncoder().encode(request.padEnd(DEVICE_SYNC_MAX_PACKET_BYTES, ' '))
    expect(parseDeviceSyncPacket(exact, owner)).toEqual({ v: 1, type: 'request', rosterAt: 42 })
    expect(() => parseDeviceSyncPacket(
      new TextEncoder().encode(`${request}${' '.repeat(DEVICE_SYNC_MAX_PACKET_BYTES + 1 - request.length)}`),
      owner,
    )).toThrow(DeviceSyncProtocolError)
  })

  it.each([
    new Uint8Array([0xc3, 0x28]),
    new TextEncoder().encode('{"v":1,"type":"snapshot"'),
    new TextEncoder().encode('{"v":2,"type":"resyncRequired"}'),
    new TextEncoder().encode('{"v":1,"type":"unknown"}'),
    new TextEncoder().encode('{"v":1,"type":"request","rosterAt":1,"page":{"kind":"metadata","offset":-1}}'),
    new TextEncoder().encode(`{"v":1,"type":"snapshot","rosterAt":1,"messages":[{"chatId":"${peer}","id":"m","body":"%%%","author":"${owner}","createdAt":2}]}`),
  ])('rejects malformed protocol records without a fallback snapshot', (payload: Uint8Array) => {
    expect(() => parseDeviceSyncPacket(payload, owner)).toThrow(DeviceSyncProtocolError)
  })
})

it('preserves private contact registers in snapshots and refuses another account', async () => {
  const { createPrivateContactSync, editPrivateContact, privateContactDocuments } = await import('nostr-social-graph/privateContactSyncV2')
  const account = 'a'.repeat(64), contact = 'b'.repeat(64)
  const documents = privateContactDocuments(editPrivateContact(createPrivateContactSync(account, '1'.repeat(32)), contact, { favorite: true, note: 'Private note' }))
  const packet = { v: 1 as const, type: 'snapshot' as const, rosterAt: 100, appKeys: [], chats: [], groups: [], messages: [], privateContactsV2: documents }
  expect(parseDeviceSyncPacket(encodeDeviceSyncPacket(packet), account)).toEqual(packet)
  expect(() => parseDeviceSyncPacket(encodeDeviceSyncPacket(packet), contact)).toThrow('privateContactsV2')
})
