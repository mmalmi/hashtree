import { restoreStoredRequestAcceptance, restoreOwnReactionAcceptance } from './requestActivity'
import { loadMessageRequestDecisions } from './messageRequests'
import { receivePrivateStateControl, sendOwnReadState, applyOwnReadTag } from './privateStateControl'
import { privateHistoryAllowed, isPrivatelyBlocked } from './privateStateStore'
import { MESSAGE_EDIT_KIND, MESSAGE_DELETE_KIND, buildMessageMutation, captureMessageMutation, sendMessageMutation, editableMessage, messageMutationFields } from './messageMutations'
import type { MessageRevision } from './messageMutations'
import { withDeviceControlClock } from './deviceSyncRecordStore'
import { reactionControl } from './deviceSyncRecords'
import { captureReaction, controlClock, persistMessageWithReactions } from './deviceSyncRecordApply'
import { registerPrivateControlEvents } from './privateControlEvents'
import { sessionFromLocalInvite } from './inviteProvenance'
import { GROUP_WAKE_KIND, parseSerializedGroupRuntimeRumor } from './groupWake'
import { DEVICE_LABEL_CONTROL_KIND, receivePrivateDeviceLabel } from './privateDeviceLabels'
import { CHAT_PIN_KIND } from './chatPinSync'
import { PRIVATE_CONTACT_CONTROL_KIND, receivePrivateContactControl } from './privateContactControl'
import { receiveChatPinControl } from './chatPinControl'
import { CHAT_MUTE_KIND } from './chatMuteSync'
import { receiveChatMuteControl } from './chatMuteControl'
import { callHistoryLabel, restoredCallHistory, type CallHistory } from './callHistory'
import { directFileMessageFields, directFilePreview } from './directFileProtocol'
import { messagingDeviceList, type MessagingSupportEvent } from './messagingPeople'
import { writable, get } from 'svelte/store'
import {
  Invite,
  type OnEventMeta,
  type Rumor,
  type GroupDecryptedEvent,
  resolveSessionPubkeyToOwner as resolveSessionPubkeyToOwnerFromRecords,
  type SessionUserRecordsLike,
  REACTION_KIND,
  RECEIPT_KIND,
  CHAT_MESSAGE_KIND,
  CHAT_SETTINGS_KIND,
  TYPING_KIND,
  buildReactionRumor,
  buildReceiptRumor,
  buildTextRumor,
  buildTypingRumor,
  ensureRecipientTag,
  isTyping,
  getExpirationTimestampSeconds,
} from 'nostr-double-ratchet'
export type { Invite } from 'nostr-double-ratchet'
import { nip19 } from 'nostr-tools'
import { getPubkey, hasNip44Support, isNip07Login } from './identity'
import { devices } from './devices'
import {
  ensureDeviceRegistered,
  getNdrRuntime,
  preparePeerNdrRuntime,
  republishInvite,
  waitForNdrRuntime,
  waitForSendReadyRuntime,
} from './privateChats'
import {
  saveSession as saveSessionToDb,
  getAllSessions,
  saveMessage as saveMessageToDb,
  getMessagesForSession,
  clearAllData,
  deleteSession as deleteSessionFromDb,
  deleteMessagesForSession,
  deleteMessage as deleteMessageFromDb,
  saveInvite as saveInviteToDb,
  getAllInvites,
  deleteInvite as deleteInviteFromDb,
  updateInviteLabel as updateInviteLabelInDb,
  updateMessageStatus as updateMessageStatusInDb,
  updateMessageSentToRelays as updateMessageSentToRelaysInDb,
  updateMessageRecipientStatuses as updateMessageRecipientStatusesInDb,
  updateMessageDeliveryTrace as updateMessageDeliveryTraceInDb,
  saveProcessedEvent,
  getPendingPushEvents,
  deletePendingPushEvent,
  db,
  type StoredSession,
  type StoredMessage,
  type StoredInvite
} from './storage'
import { updateDMSubscription } from './notifications'
import { handleGroupEvent, handleGroupRosterFactRumor, receivePrivateGroupRosterFact, groups } from './groups'
import { parseReceipt, shouldAdvanceStatus, type ReceiptPayload, type MessageStatus } from './receipts'
import { receiptSettings } from './receiptSettings'
import { typingSettings } from './typingSettings'
import { setRemoteTyping, clearRemoteTyping } from './typingState'
import { expirationStore } from './expirationStore'
import { parseChatSettingsContent } from './chatSettings'
import { acceptChat, clearChat } from './messageRequests'
import { getMessageRequestPolicyContext, isChatAccepted, shouldIgnoreIncomingEvent } from './messageRequestPolicy'
import { asVerifiedPushNostrEvent } from './pushEvents'
import {
  advanceRecipientStatus,
  mergeUniqueStrings,
  onMessageRelayPublish,
  relayChannelLabel,
  type RecipientDeliveryStatus,
} from './messageRelayStatus'

export type { RecipientDeliveryStatus } from './messageRelayStatus'
import { rememberContact } from './contactMemory'
import { decodeInviteReference, type InviteRecord } from './inviteRecord'

export interface ChatMessage {
  directTransferId?: string
  call?: CallHistory
  id: string
  content: string
  originalContent?: string
  editHistory?: MessageRevision[]
  editedAt?: number
  deletedAt?: number
  timestamp: number
  isMine: boolean
  replyTo?: string  // ID of the message being replied to
  reactions?: Record<string, string[]>  // emoji -> array of pubkeys who reacted
  status?: MessageStatus
  sentToRelays?: string[]
  recipientStatuses?: Record<string, RecipientDeliveryStatus>
  deliveryChannels?: string[]
  outerEventIds?: string[]
  pendingRelayEventIds?: string[]
  senderPubkey?: string  // pubkey of sender (for group messages)
  expiresAt?: number  // Unix timestamp in seconds when message expires (NIP-40)
}

export interface ChatSession {
  id: string
  recipientPubkey: string
  mode: 'manager'
  messages: ChatMessage[]
  bootstrapOnly?: boolean
  inviteId?: string      // ID of the invite that started this chat
  inviteLabel?: string   // Label of the invite that started this chat
}

export type ChatInvite =
  | { type: 'pubkey'; pubkey: string }
  | { type: 'private'; reference: string }
  | { type: 'legacy'; invite: Invite; reference?: string }

export interface ActiveInvite {
  id: string
  invite: ChatInvite
  label?: string
  createdAt: number
  usedBy?: string[]
  unsubscribe: () => void
}

export const chats = writable<Map<string, ChatSession>>(new Map())
export const currentChat = writable<ChatSession | null>(null)
export const invites = writable<Map<string, ActiveInvite>>(new Map())
export const closeInviteOnAccept = writable(true)
let isInitialized = false
let invitesInitialized = false
let runtimePoller: ReturnType<typeof setInterval> | null = null

let runtimeSessionSubscribed = false
let runtimeSubscriptionPromise: Promise<void> | null = null
let runtimeSessionEventCleanup: (() => void) | null = null
let groupRuntimeSubscribed = false
let groupRuntimeCleanup: (() => void) | null = null
const managerChatBootstrapInFlight = new Set<string>()
const pendingAutoOpenChats = new Set<string>()
const autoOpenedChats = new Set<string>()

type SessionUserRecordEntry =
  SessionUserRecordsLike extends Map<string, infer Record> ? Record : never

function triggerAutoOpen(chatSession: ChatSession): void {
  if (autoOpenedChats.has(chatSession.id)) return
  if (inviteAcceptedCallback) {
    autoOpenedChats.add(chatSession.id)
    inviteAcceptedCallback(chatSession)
    return
  }
  pendingAutoOpenChats.add(chatSession.id)
}

function mergeChatMessages(messages: ChatMessage[]): ChatMessage[] {
  const byId = new Map<string, ChatMessage>()
  for (const message of messages) {
    const existing = byId.get(message.id)
    if (!existing || existing.timestamp <= message.timestamp) {
      byId.set(message.id, message)
    }
  }
  return Array.from(byId.values()).sort((a, b) => a.timestamp - b.timestamp)
}

async function persistCanonicalizedChat(
  previousId: string,
  canonicalChat: ChatSession
): Promise<void> {
  try {
    await saveSessionToStorage(canonicalChat)
    await Promise.all(
      canonicalChat.messages.map((message) =>
        saveMessageToStorage(canonicalChat.id, message)
      )
    )
    if (previousId !== canonicalChat.id) {
      await Promise.allSettled([
        deleteSessionFromDb(previousId),
        deleteMessagesForSession(previousId),
      ])
    }
  } catch (e) {
    console.error('[chat] Failed to persist canonicalized chat:', e)
  }
}

function canonicalizeManagerChatAlias(chatId: string, canonicalId: string): void {
  if (!chatId || !canonicalId || chatId === canonicalId) {
    return
  }

  const currentChats = get(chats)
  const aliasChat = currentChats.get(chatId)
  if (!aliasChat) {
    return
  }

  const canonicalChat = currentChats.get(canonicalId)
  const mergedChat: ChatSession = canonicalChat
    ? {
        ...canonicalChat,
        recipientPubkey: canonicalId,
        messages: mergeChatMessages([
          ...canonicalChat.messages,
          ...aliasChat.messages,
        ]),
        inviteId: canonicalChat.inviteId ?? aliasChat.inviteId,
        inviteLabel: canonicalChat.inviteLabel ?? aliasChat.inviteLabel,
      }
    : {
        ...aliasChat,
        id: canonicalId,
        recipientPubkey: canonicalId,
        messages: mergeChatMessages(aliasChat.messages),
      }

  chats.update((chatMap) => {
    chatMap.delete(chatId)
    chatMap.set(canonicalId, mergedChat)
    return chatMap
  })

  if (pendingAutoOpenChats.delete(chatId)) {
    pendingAutoOpenChats.add(canonicalId)
  }
  if (autoOpenedChats.delete(chatId)) {
    autoOpenedChats.add(canonicalId)
  }

  const current = get(currentChat)
  if (current?.id === chatId || current?.id === canonicalId) {
    currentChat.set(mergedChat)
  }

  void persistCanonicalizedChat(chatId, mergedChat)
}

function shouldSkipSelfCanonicalization(
  chatId: string,
  canonicalId: string,
  myPubkey?: string,
  authenticatedRemoteOwner?: string
): boolean {
  if (!myPubkey || canonicalId !== myPubkey || chatId === myPubkey) {
    return false
  }
  if (authenticatedRemoteOwner && chatId === authenticatedRemoteOwner) {
    return true
  }
  return !isKnownOwnDevice(chatId)
}

function canonicalizeKnownManagerChats(
  myPubkey?: string,
  authenticatedRemoteOwner?: string
): void {
  const currentChats = Array.from(get(chats).keys())
  for (const chatId of currentChats) {
    const canonicalId = resolveSessionPubkeyToOwner(chatId)
    if (shouldSkipSelfCanonicalization(chatId, canonicalId, myPubkey, authenticatedRemoteOwner)) {
      continue
    }
    if (canonicalId !== chatId) {
      canonicalizeManagerChatAlias(chatId, canonicalId)
    }
  }
}

function syncCurrentChatIfMatching(updatedSession: ChatSession): void {
  const current = get(currentChat)
  if (current?.id === updatedSession.id) {
    currentChat.set(updatedSession)
  }
}

function updateChatSession(
  sessionId: string,
  updater: (chatSession: ChatSession) => ChatSession | null
): ChatSession | null {
  let updatedSession: ChatSession | null = null

  chats.update((chatMap) => {
    const chatSession = chatMap.get(sessionId)
    if (!chatSession) {
      return chatMap
    }

    const nextSession = updater(chatSession)
    if (!nextSession) {
      return chatMap
    }

    chatMap.set(sessionId, nextSession)
    updatedSession = nextSession
    return chatMap
  })

  if (updatedSession) {
    syncCurrentChatIfMatching(updatedSession)
  }

  return updatedSession
}

function findChatSessionIdByMessageId(messageId: string): string | null {
  for (const [sessionId, chatSession] of get(chats)) {
    if (chatSession.messages.some((message) => message.id === messageId)) {
      return sessionId
    }
  }
  return null
}

function markMessageSentToRelays(messageId: string, relayUrls: string[]): void {
  const sessionId = findChatSessionIdByMessageId(messageId)
  if (!sessionId) return

  let sentToRelays: string[] | null = null
  let deliveryChannels: string[] | null = null
  const updatedSession = updateChatSession(sessionId, (latestSession) => {
    const messageIndex = latestSession.messages.findIndex((message) => message.id === messageId)
    if (messageIndex === -1) return null

    const message = latestSession.messages[messageIndex]
    const mergedRelays = mergeUniqueStrings(message.sentToRelays, relayUrls)
    const currentRelays = message.sentToRelays || []
    const mergedChannels = mergeUniqueStrings(
      message.deliveryChannels,
      relayUrls.map(relayChannelLabel)
    )
    const currentChannels = message.deliveryChannels || []
    if (
      mergedRelays.length === currentRelays.length &&
      mergedRelays.every((url, index) => url === currentRelays[index]) &&
      mergedChannels.length === currentChannels.length &&
      mergedChannels.every((channel, index) => channel === currentChannels[index])
    ) {
      return null
    }

    const updatedMessages = [...latestSession.messages]
    updatedMessages[messageIndex] = {
      ...message,
      sentToRelays: mergedRelays,
      deliveryChannels: mergedChannels,
    }
    sentToRelays = mergedRelays
    deliveryChannels = mergedChannels
    return { ...latestSession, messages: updatedMessages }
  })
  if (!updatedSession || !sentToRelays || !deliveryChannels) return

  void updateMessageSentToRelaysInDb(messageId, sentToRelays).catch((error) => {
    console.error('[chat] Failed to persist message relay publish status:', error)
  })
  void updateMessageDeliveryTraceInDb(messageId, { deliveryChannels }).catch((error) => {
    console.error('[chat] Failed to persist message delivery channels:', error)
  })
}

onMessageRelayPublish(markMessageSentToRelays)

function subscribeToNdrRuntimeEvents(): void {
  if (runtimeSessionSubscribed) return
  runtimeSessionSubscribed = true
  const durableKinds = [PRIVATE_CONTACT_CONTROL_KIND, DEVICE_LABEL_CONTROL_KIND, CHAT_MUTE_KIND, CHAT_PIN_KIND, 10454, 10455]
  const runtime = getNdrRuntime()
  const account = getPubkey()
  const stopMutations = runtime.onDurableSessionEvent([MESSAGE_EDIT_KIND, MESSAGE_DELETE_KIND], async (rumor, from, meta) => {
    if (!account || getPubkey() !== account) throw new Error('Account is not ready')
    await handleManagerEvent(rumor, from, meta)
    if (getPubkey() !== account) throw new Error('Account changed')
  })
  const stopGroupInvites = runtime.onDurableSessionEvent([10461, 10462], async (rumor, _from, meta) => {
    if (!account || getPubkey() !== account) throw new Error('Account is not ready')
    await (await import('./groupInvites')).receiveGroupInviteControl(rumor, meta)
  })
  const stopGroupRosters = runtime.onDurableSessionEvent([37368], async (rumor, _from, meta) => {
    if (!account || getPubkey() !== account) throw new Error('Account is not ready')
    await receivePrivateGroupRosterFact(rumor, meta)
    if (getPubkey() !== account) throw new Error('Account changed')
  })
  const stopDurable = registerPrivateControlEvents(runtime, {
    account, getAccount: getPubkey, getState: () => get(devices), receive: handleManagerEvent,
  })
  const stopEvents = runtime.onSessionEvent((rumor, from, meta) => {
    if (durableKinds.includes(rumor.kind) || [10461, 10462, 37368, GROUP_WAKE_KIND, MESSAGE_EDIT_KIND, MESSAGE_DELETE_KIND].includes(rumor.kind)) return
    handleManagerEvent(rumor, from, meta).catch((e) =>
      console.error('[chat] Failed to handle NdrRuntime event:', e)
    )
  })
  runtimeSessionEventCleanup = () => { stopMutations(); stopDurable(); stopEvents(); stopGroupInvites(); stopGroupRosters() }
}

function startNdrRuntimePoller(): void {
  if (!runtimePoller) {
    runtimePoller = setInterval(() => syncRuntimeChats(), 500)
    syncRuntimeChats()
  }
}

async function handleRuntimeGroupEvent(event: GroupDecryptedEvent): Promise<void> {
  const owner = getPubkey()
  if (handleGroupRosterFactRumor(event.inner)) return
  const canonical=parseSerializedGroupRuntimeRumor(event.inner.content) ?? event.inner
  const groupId=canonical.tags.find(tag=>tag[0]==='l')?.[1]
  if (groupId && !get(groups).has(groupId)) throw new Error('Waiting for group membership')
  const sender = event.senderOwnerPubkey || event.senderDevicePubkey || event.inner.pubkey
  await handleGroupEvent(event.inner, sender, {id:event.outerEventId}, event.senderDevicePubkey)
  if (!owner || getPubkey() !== owner) throw new Error('Account changed')
  if (event.outerEventId) {
    const inner = parseSerializedGroupRuntimeRumor(event.inner.content) ?? event.inner
    const groupId = inner.tags.find(tag => tag[0] === 'l')?.[1]
    if (groupId) await saveProcessedEvent({
      id:event.outerEventId,chatId:`group:${groupId}`,kind:inner.kind,content:inner.content,
      messageId:inner.id,author:sender,createdAtSecs:inner.created_at,isSelfMessage:sender === owner,timestamp:Date.now(),
    })
  }
}

export function initNdrRuntimeEvents(): Promise<void> {
  if (!groupRuntimeSubscribed) {
    const runtime = getNdrRuntime()
    const account=getPubkey()
    groupRuntimeSubscribed = true
    groupRuntimeCleanup = runtime.onGroupEvent(async (event) => {
      if (!account || getPubkey()!==account) throw new Error('Account changed')
      await handleRuntimeGroupEvent(event)
      if (getPubkey()!==account) throw new Error('Account changed')
    })
  }

  subscribeToNdrRuntimeEvents()

  if (getNdrRuntime().getState().sessionManagerReady) {
    startNdrRuntimePoller()
    return Promise.resolve()
  }

  // Runtime may still be initializing right after login. If we return early
  // we can miss the first incoming events and end up with chats that have sessions
  // but no messages. Wait for it and subscribe as soon as it's ready.
  if (!runtimeSubscriptionPromise) {
    runtimeSubscriptionPromise = waitForNdrRuntime()
      .then(() => startNdrRuntimePoller())
      .catch((e) => {
        console.error('[chat] Failed to init NdrRuntime events:', e)
        throw e
      })
      .finally(() => {
        runtimeSubscriptionPromise = null
      })
    void runtimeSubscriptionPromise.catch(() => {})
  }

  return runtimeSubscriptionPromise
}

const pushEventIngestInFlight = new Set<string>()

export async function ingestPushNostrEvent(event: unknown): Promise<boolean> {
  const verifiedEvent = asVerifiedPushNostrEvent(event)
  if (!verifiedEvent?.id) return false
  if (pushEventIngestInFlight.has(verifiedEvent.id)) return false

  pushEventIngestInFlight.add(verifiedEvent.id)
  try {
    await initNdrRuntimeEvents()
    const handled = getNdrRuntime().processReceivedEvent(
      verifiedEvent as unknown as Parameters<ReturnType<typeof getNdrRuntime>['processReceivedEvent']>[0]
    )
    await deletePendingPushEvent(verifiedEvent.id)
    if (handled) {
      updateDMSubscription()
    }
    return handled
  } catch (error) {
    console.error('[chat] Failed to ingest push Nostr event:', error)
    return false
  } finally {
    pushEventIngestInFlight.delete(verifiedEvent.id)
  }
}

export async function drainPendingPushNostrEvents(): Promise<void> {
  const pending = await getPendingPushEvents()
  for (const record of pending) {
    await ingestPushNostrEvent(record.event)
  }
}

function syncRuntimeChats(): void {
  const myPubkey = getPubkey()
  if (!myPubkey) return

  canonicalizeKnownManagerChats()

  const policyCtx = getMessageRequestPolicyContext()

  const currentChats = get(chats)
  const runtime = getNdrRuntime()
  for (const [pubkey, record] of runtime.getSessionUserRecords()) {
    if (pubkey === myPubkey) continue
    if (needsManagerUserSetup(record)) {
      void runtime.setupUser(pubkey).catch((e) =>
        console.error('[chat] Failed to refresh runtime user setup:', e)
      )
    }
    if (currentChats.has(pubkey)) continue
    // Group transport setup also creates pairwise sessions. A session alone
    // is not an instruction to put a new conversation in the inbox.
    if (!policyCtx.acceptedChats?.[pubkey]) continue
    if (policyCtx.rejectedChats?.[pubkey]) continue
    const hasSession = Array.from(record.devices?.values() ?? []).some((device) =>
      Boolean(device.activeSession) || (device.inactiveSessions?.length ?? 0) > 0
    )
    if (!hasSession) continue

    ensureManagerChat(pubkey).catch((e) =>
      console.error('[chat] Failed to sync manager chat:', e)
    )
  }
}

export function needsManagerUserSetup(record: SessionUserRecordEntry): boolean {
  const devicesMap = record.devices ?? new Map()
  const knownDeviceCount = devicesMap.size
  const appKeysDeviceCount = record.appKeys?.getAllDevices?.().length ?? 0

  if (appKeysDeviceCount > knownDeviceCount) {
    return true
  }

  return Array.from(devicesMap.values()).some(
    (device) => !device.activeSession && (device.inactiveSessions?.length ?? 0) === 0
  )
}

// Create a new invite (chat link) that can be shared privately.
export async function createInvite(): Promise<ChatInvite> {
  const pubkey = getPubkey()
  if (!pubkey) throw new Error('Not logged in')

  const runtime = await waitForNdrRuntime()
  const delegateInvite = runtime.getDelegateManager()?.getInvite()
  if (!delegateInvite) {
    throw new Error('Invite is not ready')
  }

  registerDeviceInBackground('creating invite')

  const invite = Invite.deserialize(delegateInvite.serialize())
  invite.ownerPubkey = pubkey
  return { type: 'legacy', invite }
}

export async function personalInviteRecord(invite: Invite): Promise<InviteRecord> {
  if (invite.metadataPrivacyVersion !== 2) throw new Error('Create a new invite to share.')
  const { getLocalProfile, getProfileName } = await import('./profile')
  return {
    v: 1, type: 'personal', name: (getProfileName(getLocalProfile() ?? undefined) || '').slice(0, 100),
    nonce: Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2, '0')).join(''),
    invite: { version: 2, inviter: invite.inviter, ephemeralKey: invite.inviterEphemeralPublicKey,
      sharedSecret: invite.sharedSecret, owner: invite.ownerPubkey || invite.inviter,
      ...(invite.deviceId && { deviceId: invite.deviceId }), purpose: 'chat' },
  }
}

export function inviteFromRecord(record: InviteRecord): Invite {
  return Invite.fromUrl(`https://chat.iris.to/#${encodeURIComponent(JSON.stringify(record.invite))}`)
}

export async function resolvePrivateInvite(invite: ChatInvite): Promise<InviteRecord | null> {
  if (invite.type !== 'private') return null
  const record = await (await import('./inviteRecordStore')).loadInviteRecord(invite.reference)
  if (record.expiresAt && record.expiresAt <= Math.floor(Date.now() / 1000)) throw new Error('This invite has expired.')
  return record
}

// Get the base URL for invite links
function getInviteBaseUrl(): string {
  const origin = window.location.origin
  if (origin.startsWith('http://localhost') ||
      origin.startsWith('http://127.0.0.1')) {
    return 'https://chat.iris.to'
  }
  return origin
}

// Get invite URL
export function getInviteUrl(invite: ChatInvite): string {
  if (invite.type === 'private' || (invite.type === 'legacy' && invite.reference)) {
    return `${getInviteBaseUrl()}/#/${invite.reference}`
  }
  if (invite.type === 'pubkey') {
    const url = new URL(getInviteBaseUrl())
    url.hash = `/${nip19.npubEncode(invite.pubkey)}`
    return url.toString()
  }
  return routeInviteUrl(invite.invite.getUrl(getInviteBaseUrl()))
}

function routeInviteUrl(inviteUrl: string): string {
  const url = new URL(inviteUrl)
  let payload = url.hash.startsWith('#') ? url.hash.slice(1) : url.hash
  payload = payload.replace(/^\/+/, '')
  if (!payload || payload.toLowerCase().startsWith('invite/')) {
    return url.toString()
  }
  url.hash = `/invite/${payload}`
  return url.toString()
}

function parseInviteHash(hash: string): ChatInvite | null {
  let raw = hash.startsWith('#') ? hash.slice(1) : hash
  // Some environments/libraries produce hashes like "#/npub..." (hash-routing style).
  raw = raw.replace(/^\/+/, '')
  if (raw.toLowerCase().startsWith('invite/')) {
    raw = raw.slice('invite/'.length).replace(/^\/+/, '')
  }
  if (!raw) return null
  if (raw.startsWith('nhash1')) {
    const reference = raw
    try { decodeInviteReference(reference); return { type: 'private', reference } } catch { return null }
  }

  type InvitePurpose = 'link' | 'chat'
  const parseInvitePayload = (
    payload: string
  ): { purpose?: InvitePurpose; owner?: string } | null => {
    try {
      const decoded = decodeURIComponent(payload)
      const data = JSON.parse(decoded) as Record<string, unknown>
      if (!data || typeof data !== 'object') return null
      return {
        purpose:
          data.purpose === 'link' || data.purpose === 'chat'
            ? (data.purpose as InvitePurpose)
            : undefined,
        owner:
          typeof data.owner === 'string'
            ? data.owner
            : typeof data.ownerPubkey === 'string'
              ? data.ownerPubkey
              : undefined,
      }
    } catch {
      return null
    }
  }

  const normalizeInvitePayload = (payload: string): string | null => {
    try {
      const decoded = decodeURIComponent(payload)
      const data = JSON.parse(decoded) as Record<string, unknown>
      if (!data || typeof data !== 'object') return null

      if (
        typeof data.inviterEphemeralPublicKey === 'string' &&
        typeof data.ephemeralKey !== 'string'
      ) {
        data.ephemeralKey = data.inviterEphemeralPublicKey
      }

      if (
        typeof data.inviter !== 'string' ||
        typeof data.ephemeralKey !== 'string' ||
        typeof data.sharedSecret !== 'string'
      ) {
        return null
      }

      return JSON.stringify(data)
    } catch {
      return null
    }
  }

  // NIP-19 links (npub or nprofile)
  if (raw.startsWith('npub') || raw.startsWith('nprofile')) {
    try {
      const decoded = nip19.decode(raw)
      if (decoded.type === 'npub') {
        return { type: 'pubkey', pubkey: decoded.data as string }
      }
      if (decoded.type === 'nprofile') {
        const data = decoded.data as { pubkey: string }
        return { type: 'pubkey', pubkey: data.pubkey }
      }
    } catch {
      return null
    }
  }

  // Legacy JSON invite format
  const applyPayloadMeta = (invite: Invite, payloadRaw: string) => {
    const payload = parseInvitePayload(payloadRaw)
    if (payload?.purpose) {
      invite.purpose = payload.purpose
    }
    if (payload?.owner) {
      ;(invite as Invite & { ownerPubkey?: string }).ownerPubkey = payload.owner
    }
    return invite
  }

  try {
    const url = `${getInviteBaseUrl()}#${raw}`
    const invite = Invite.fromUrl(url)
    return { type: 'legacy', invite: applyPayloadMeta(invite, raw) }
  } catch {
    const normalizedPayload = normalizeInvitePayload(raw)
    if (!normalizedPayload) return null
    try {
      const url = `${getInviteBaseUrl()}#${encodeURIComponent(normalizedPayload)}`
      const invite = Invite.fromUrl(url)
      return { type: 'legacy', invite: applyPayloadMeta(invite, raw) }
    } catch {
      return null
    }
  }
}

// Parse invite from URL hash
export function parseInviteFromHash(): ChatInvite | null {
  const hash = window.location.hash || window.location.pathname
  if (!hash || hash.length < 2) return null
  return parseInviteHash(hash)
}

// Parse invite from a pasted URL
export function parseInviteFromUrl(url: string): ChatInvite | null {
  try {
    const trimmed = url.trim()
    if (trimmed.startsWith('npub') || trimmed.startsWith('nprofile') || trimmed.startsWith('nhash1')) {
      return parseInviteHash(`#${trimmed}`)
    }
    if (trimmed.startsWith('nostr:')) {
      const raw = trimmed.replace('nostr:', '')
      return parseInviteHash(`#${raw}`)
    }
    const parsed = new URL(url)
    return parseInviteHash(parsed.hash || parsed.pathname)
  } catch {
    return null
  }
}

export function isLinkInvite(invite: ChatInvite | null | undefined): boolean {
  if (!invite || invite.type !== 'legacy') return false
  const withPurpose = invite.invite as Invite & { purpose?: string }
  return withPurpose.purpose === 'link'
}

// Serialize invite for storage
export function serializeInvite(invite: ChatInvite): string {
  if (invite.type === 'private') return JSON.stringify({ ...invite, metadataPrivacyVersion: 2 })
  if (invite.type === 'pubkey') {
    return JSON.stringify({ type: 'pubkey', pubkey: invite.pubkey })
  }
  return invite.reference ? JSON.stringify({ type: 'legacy', data: invite.invite.serialize(), reference: invite.reference }) : invite.invite.serialize()
}

// Deserialize invite from storage
export function deserializeInvite(data: string): ChatInvite {
  const parsed = JSON.parse(data)
  if (parsed?.type === 'private') {
    if (parsed.metadataPrivacyVersion !== 2) throw new Error('Create a new invite to share.')
    decodeInviteReference(parsed.reference)
    return { type: 'private', reference: parsed.reference }
  }
  if (parsed?.type === 'pubkey' && typeof parsed.pubkey === 'string') return { type: 'pubkey', pubkey: parsed.pubkey }
  const serialized = parsed?.type === 'legacy' && typeof parsed.data === 'string' ? parsed.data : data
  // Retain older issued links in storage, but do not reshare a reference to an old handshake.
  if (JSON.parse(serialized).metadataPrivacyVersion !== 2) throw new Error('Create a new invite to share.')
  return { type: 'legacy', invite: Invite.deserialize(serialized), ...(parsed.reference && { reference: parsed.reference }) }
}

// Callback for when an invite is accepted
let inviteAcceptedCallback: ((session: ChatSession) => void) | null = null

// Set callback for invite acceptance (called from App.svelte)
export function setInviteAcceptedCallback(callback: (session: ChatSession) => void): void {
  inviteAcceptedCallback = callback
  if (pendingAutoOpenChats.size === 0) return
  const chatMap = get(chats)
  for (const chatId of pendingAutoOpenChats) {
    const chatSession = chatMap.get(chatId)
    if (!chatSession) continue
    autoOpenedChats.add(chatId)
    inviteAcceptedCallback(chatSession)
  }
  pendingAutoOpenChats.clear()
}

// Create a new invite and save to storage
export async function createAndSaveInvite(label?: string): Promise<ActiveInvite> {
  const pubkey = getPubkey()
  if (!pubkey) throw new Error('Not logged in')

  const invite = await createInvite()
  if (invite.type === 'legacy') {
    const { publishInviteRecord } = await import('./inviteRecordStore')
    invite.reference = await publishInviteRecord(await personalInviteRecord(invite.invite))
  }
  if (getPubkey() !== pubkey) throw new Error('Account changed')
  const id = crypto.randomUUID()

  // Save to IndexedDB
  const storedInvite: StoredInvite = {
    id,
    inviteData: serializeInvite(invite),
    label,
    createdAt: Date.now(),
    usedBy: []
  }
  await saveInviteToDb(storedInvite)

  const unsubscribe = () => {}

  const activeInvite: ActiveInvite = {
    id,
    invite,
    label,
    createdAt: storedInvite.createdAt,
    usedBy: [],
    unsubscribe
  }

  // Add to invites store
  invites.update(i => {
    i.set(id, activeInvite)
    return i
  })

  // Update notification subscription to include this invite's ephemeral key
  updateDMSubscription()

  return activeInvite
}

// Delete a stored invite and stop listening
export async function deleteStoredInvite(id: string): Promise<void> {
  const currentInvites = get(invites)
  const activeInvite = currentInvites.get(id)

  if (activeInvite) {
    // Stop listening
    activeInvite.unsubscribe()
  }

  // Remove from store
  invites.update(i => {
    i.delete(id)
    return i
  })

  // Delete from storage
  await deleteInviteFromDb(id)

  // Update notification subscription
  updateDMSubscription()
}

// Update label on an invite
export async function updateInviteLabel(id: string, label: string): Promise<void> {
  await updateInviteLabelInDb(id, label)

  // Update in store
  invites.update(i => {
    const activeInvite = i.get(id)
    if (activeInvite) {
      i.set(id, { ...activeInvite, label })
    }
    return i
  })
}

// Load all invites from storage and start monitoring
export async function loadAndMonitorInvites(): Promise<void> {
  if (invitesInitialized) {
    return
  }

  try {
    const storedInvites = await getAllInvites()

    for (const stored of storedInvites) {
      try {
        const invite = deserializeInvite(stored.inviteData)
        if (invite.type === 'pubkey') {
          await deleteInviteFromDb(stored.id)
          continue
        }
        const unsubscribe = () => {}

        const activeInvite: ActiveInvite = {
          id: stored.id,
          invite,
          label: stored.label,
          createdAt: stored.createdAt,
          usedBy: stored.usedBy || [],
          unsubscribe
        }

        // Add to invites store
        invites.update(i => {
          i.set(stored.id, activeInvite)
          return i
        })
      } catch (e) {
        console.error('[chat] Failed to restore invite:', stored.id, e)
      }
    }

    invitesInitialized = true
  } catch (e) {
    console.error('Failed to load invites from storage:', e)
  }
}

// Get all invite ephemeral pubkeys for notifications
export function getInviteEphemeralPubkeys(): string[] {
  const currentInvites = get(invites)
  const pubkeys: string[] = []

  for (const [, activeInvite] of currentInvites) {
    if (activeInvite.invite.type === 'legacy') {
      // Get the ephemeral pubkey from the invite that responses will be sent to
      if (activeInvite.invite.invite.inviterEphemeralPublicKey) {
        pubkeys.push(activeInvite.invite.invite.inviterEphemeralPublicKey)
      }
    }
  }

  return pubkeys
}

async function isChatFromLocalInvite(chatId: string): Promise<boolean> {
  const inviteEphemeralPubkeys = new Set(getInviteEphemeralPubkeys())
  if (inviteEphemeralPubkeys.size === 0) return false

  const runtime = getNdrRuntime()
  const userRecords = runtime.getSessionUserRecords() as
    | SessionUserRecordsLike
    | undefined
  if (!userRecords) return false

  const canonicalChatId = resolveSessionPubkeyToOwner(chatId)
  const recordsToCheck = [
    userRecords.get(chatId),
    canonicalChatId !== chatId ? userRecords.get(canonicalChatId) : undefined,
  ]

  for (const record of recordsToCheck) {
    const devicesMap = record?.devices ?? new Map()
    for (const device of devicesMap.values()) {
      const sessions = [
        device.activeSession,
        ...(device.inactiveSessions ?? []),
      ].filter(Boolean)

      for (const session of sessions) {
        if (await sessionFromLocalInvite(session, inviteEphemeralPubkeys)) return true
      }
    }
  }

  return false
}

export async function startChatWithPerson(recipientPubkey: string, support: MessagingSupportEvent): Promise<ChatSession> {
  if (!messagingDeviceList(support, recipientPubkey)?.length) {
    throw new Error('This person can’t receive messages yet.')
  }
  const session = await ensureManagerChat(recipientPubkey)
  acceptChat(session.recipientPubkey)
  return session
}

async function ensureManagerChat(
  recipientPubkey: string,
  options: { bootstrap?: boolean; bootstrapOnly?: boolean } = {}
): Promise<ChatSession> {
  const { bootstrap = true } = options
  try { rememberContact(getPubkey() ?? '', recipientPubkey) } catch { /* Messaging remains available if local storage is full. */ }
  const existing = get(chats).get(recipientPubkey)
  if (existing) return existing

  const storedMessages = await getMessagesForSession(recipientPubkey)
  const messages: ChatMessage[] = storedMessages
    .filter(message => !!message.content.trim() || message.deletedAt !== undefined || !!message.call)
    .map((m) => ({
      id: m.id,
      content: m.content,
      ...messageMutationFields(m),
      timestamp: m.timestamp,
      isMine: m.isMine,
      ...(m.replyTo && { replyTo: m.replyTo }),
      reactions: m.reactions,
      status: m.status,
      ...restoredCallHistory(m.call),
      ...(m.sentToRelays && { sentToRelays: m.sentToRelays }),
      ...(m.recipientStatuses && { recipientStatuses: m.recipientStatuses }),
      ...(m.deliveryChannels && { deliveryChannels: m.deliveryChannels }),
      ...(m.outerEventIds && { outerEventIds: m.outerEventIds }),
      ...(m.pendingRelayEventIds && { pendingRelayEventIds: m.pendingRelayEventIds }),
      senderPubkey: m.senderPubkey,
      ...(m.expiresAt !== undefined && { expiresAt: m.expiresAt }),
    }))
    .sort((a, b) => a.timestamp - b.timestamp)

  const chatSession: ChatSession = {
    id: recipientPubkey,
    recipientPubkey,
    mode: 'manager',
    messages,
    ...(options.bootstrapOnly && { bootstrapOnly: true }),
  }

  chats.update((c) => {
    c.set(chatSession.id, chatSession)
    return c
  })

  await saveSessionToStorage(chatSession)
  updateDMSubscription()
  if (bootstrap) {
    bootstrapManagerChatSession(recipientPubkey)
  }

  return chatSession
}

function bootstrapManagerChatSession(recipientPubkey: string): void {
  const myPubkey = getPubkey()
  if (!recipientPubkey || recipientPubkey === myPubkey) {
    return
  }
  if (managerChatBootstrapInFlight.has(recipientPubkey)) {
    return
  }

  managerChatBootstrapInFlight.add(recipientPubkey)
  void preparePeerNdrRuntime(recipientPubkey)
    .catch((e) =>
      console.warn('[chat] Failed to bootstrap manager chat session:', recipientPubkey, e)
    )
    .finally(() => {
      managerChatBootstrapInFlight.delete(recipientPubkey)
    })
}

function resolveManagerSender(fromPubkey: string, myPubkey: string | null): string {
  if (!myPubkey) return fromPubkey
  if (fromPubkey === myPubkey) return fromPubkey

  const deviceState = get(devices)
  const isOwnDevice =
    deviceState.identityPubkey === fromPubkey ||
    deviceState.registeredDevices.some((device) => device.identityPubkey === fromPubkey)

  return isOwnDevice ? myPubkey : fromPubkey
}

function resolveSessionPubkeyToOwner(pubkey: string): string {
  if (!pubkey) return pubkey

  const userRecords = getNdrRuntime().getSessionUserRecords() as
    | SessionUserRecordsLike
    | undefined
  if (!userRecords) return pubkey
  return resolveSessionPubkeyToOwnerFromRecords(userRecords, pubkey)
}

function isKnownOwnDevice(pubkey: string): boolean {
  const deviceState = get(devices)
  const runtimeState = getNdrRuntime().getState()
  return (
    deviceState.identityPubkey === pubkey ||
    deviceState.registeredDevices.some((device) => device.identityPubkey === pubkey) ||
    runtimeState.currentDevicePubkey === pubkey ||
    (runtimeState.registeredDevices?.some((device) => device.identityPubkey === pubkey) ?? false)
  )
}

function firstPubkeyTag(rumor: Rumor): string | undefined {
  const raw = rumor.tags?.find((t: string[]) => t[0] === 'p')?.[1]?.trim()
  return raw || undefined
}

function resolvePeerTagForChat(rawPeerTag: string, myPubkey: string): string {
  const resolvedPeer = resolveSessionPubkeyToOwner(rawPeerTag)
  if (resolvedPeer && resolvedPeer !== myPubkey) {
    return resolvedPeer
  }
  return rawPeerTag
}

function resolveManagerIsFromSelf(
  rumor: Rumor,
  chatId: string,
  effectiveFromPubkey: string,
  myPubkey: string,
  meta?: OnEventMeta
): boolean {
  if (meta?.isSelf) return true
  if (meta?.senderOwnerPubkey === myPubkey) return true
  if (meta?.senderOwnerPubkey && meta.senderOwnerPubkey !== myPubkey) return false
  if (effectiveFromPubkey === myPubkey) return true
  if (rumor.pubkey === myPubkey) return true
  if (isKnownOwnDevice(rumor.pubkey)) return true

  const pTag = firstPubkeyTag(rumor)
  const resolvedPTag = pTag ? resolvePeerTagForChat(pTag, myPubkey) : undefined
  // Sender copies from another client can be surfaced via the peer user record.
  return !!resolvedPTag && resolvedPTag !== myPubkey && resolvedPTag === chatId
}

export async function handleManagerEvent(
  rumor: Rumor,
  fromPubkey: string,
  meta?: OnEventMeta
): Promise<void> {
  const myPubkey = getPubkey()
  if (!myPubkey) return

  if (rumor.kind === 10454 || rumor.kind === 10455) { await receivePrivateStateControl(rumor, meta); return }
  if (rumor.kind === DEVICE_LABEL_CONTROL_KIND) {
    await receivePrivateDeviceLabel(rumor, meta)
    return
  }
  if (rumor.kind === PRIVATE_CONTACT_CONTROL_KIND) {
    await receivePrivateContactControl(rumor, meta)
    return
  }
  if (rumor.kind === CHAT_MUTE_KIND) {
    await receiveChatMuteControl(rumor, meta)
    return
  }
  if (rumor.kind === CHAT_PIN_KIND) {
    await receiveChatPinControl(rumor, meta)
    return
  }

  // Group/session controls may also be emitted on the pairwise event stream.
  // Only direct-chat event kinds can create or update a direct conversation.
  if (![CHAT_MESSAGE_KIND, RECEIPT_KIND, REACTION_KIND, CHAT_SETTINGS_KIND,
    TYPING_KIND, MESSAGE_EDIT_KIND, MESSAGE_DELETE_KIND].includes(rumor.kind)) return

  const effectiveFromPubkey = resolveManagerSender(fromPubkey, myPubkey)
  const resolvedFromPubkey = resolveSessionPubkeyToOwner(effectiveFromPubkey)
  const authenticatedRemoteOwner =
    meta?.senderOwnerPubkey && meta.senderOwnerPubkey !== myPubkey
      ? meta.senderOwnerPubkey
      : undefined

  const groupTag = rumor.tags?.find((t: string[]) => t[0] === 'l')
  if (groupTag) {
    return
  }

  let chatId = authenticatedRemoteOwner || resolvedFromPubkey
  const senderResolvesToSelf =
    !authenticatedRemoteOwner &&
    (meta?.isSelf === true ||
      meta?.senderOwnerPubkey === myPubkey ||
      effectiveFromPubkey === myPubkey ||
      resolvedFromPubkey === myPubkey)

  if (senderResolvesToSelf) {
    const pTag = firstPubkeyTag(rumor)
    const resolvedPTag = pTag ? resolvePeerTagForChat(pTag, myPubkey) : undefined
    if (pTag && pTag !== myPubkey && resolvedPTag && resolvedPTag !== myPubkey) {
      chatId = resolvedPTag
    } else if (pTag && pTag !== myPubkey) {
      chatId = pTag
    } else {
      // Self-message (p-tag is us or missing): route to self chat
      chatId = myPubkey
    }
  }

  canonicalizeKnownManagerChats(myPubkey, authenticatedRemoteOwner)
  const canonicalFromPubkey = resolveSessionPubkeyToOwner(fromPubkey)
  if (
    canonicalFromPubkey !== fromPubkey &&
    !shouldSkipSelfCanonicalization(
      fromPubkey,
      canonicalFromPubkey,
      myPubkey,
      authenticatedRemoteOwner
    )
  ) {
    canonicalizeManagerChatAlias(fromPubkey, canonicalFromPubkey)
  }
  if (effectiveFromPubkey !== chatId) {
    const canonicalEffectiveFromPubkey = resolveSessionPubkeyToOwner(effectiveFromPubkey)
    const canonicalEffectiveChatId =
      canonicalEffectiveFromPubkey === myPubkey ? chatId : canonicalEffectiveFromPubkey
    if (
      !shouldSkipSelfCanonicalization(
        effectiveFromPubkey,
        canonicalEffectiveChatId,
        myPubkey,
        authenticatedRemoteOwner
      )
    ) {
      canonicalizeManagerChatAlias(effectiveFromPubkey, canonicalEffectiveChatId)
    }
  }

  const isFromSelf = resolveManagerIsFromSelf(
    rumor,
    chatId,
    effectiveFromPubkey,
    myPubkey,
    meta
  )

  let policyCtx = getMessageRequestPolicyContext()
  const existing = get(chats).get(chatId)
  const groupConnection = !existing && Array.from(get(groups).values()).some(group => group.members.includes(chatId))
  const acceptedLocalInvite = !isFromSelf && !policyCtx.rejectedChats?.[chatId] &&
    (!(groupConnection || groupInviteConnections.has(chatId)) || (rumor.kind === CHAT_MESSAGE_KIND && !!rumor.content.trim())) && await isChatFromLocalInvite(chatId)
  if (!existing && !acceptedLocalInvite && (rumor.kind !== CHAT_MESSAGE_KIND || !rumor.content.trim())) {
    if (isTyping(rumor) && !isFromSelf) {
      const expiresAt = getExpirationTimestampSeconds(rumor)
      if (expiresAt !== undefined && expiresAt <= Math.floor(Date.now() / 1000)) clearRemoteTyping(chatId)
      else setRemoteTyping(chatId, rumor.created_at)
    }
    return
  }
  // The authenticated invite bootstrap is sufficient; waiting for a visible
  // text message also stranded the QR screen and file-first conversations.
  if (acceptedLocalInvite) {
    acceptChat(chatId)
    policyCtx = getMessageRequestPolicyContext()
  }
  const shouldIgnore = shouldIgnoreIncomingEvent(
    existing || { recipientPubkey: chatId, messages: [] },
    isFromSelf,
    policyCtx
  )
  if (shouldIgnore) return

  if (!isFromSelf && (await isPrivatelyBlocked(myPubkey, chatId) || !await privateHistoryAllowed(myPubkey, chatId, rumor.created_at))) return
  const chatSession = await ensureManagerChat(chatId, { bootstrapOnly: !existing && (rumor.kind !== CHAT_MESSAGE_KIND || !rumor.content.trim()) })
  if (groupInviteConnections.has(chatId) && chatSession.bootstrapOnly && !chatSession.messages.length) {
    await markGroupInviteConnection(chatId)
    return
  }
  if (acceptedLocalInvite) triggerAutoOpen(chatSession)

  const isEmptyChat = (existing ? existing.messages.length : chatSession.messages.length) === 0
  const isFirstInboundMessage =
    !isFromSelf &&
    rumor.kind === CHAT_MESSAGE_KIND &&
    isEmptyChat

  if (isFirstInboundMessage) {
    if (!isChatAccepted(chatSession, policyCtx) && await isChatFromLocalInvite(chatId)) {
      acceptChat(chatSession.recipientPubkey)
      triggerAutoOpen(chatSession)
    } else if (isChatAccepted(chatSession, policyCtx)) {
      triggerAutoOpen(chatSession)
    }
    // Republish our current device invite after the first successful inbound session
    // so it is present on relays without invalidating the runtime invite-response listener.
    void republishInvite().catch((e) =>
      console.warn('[chat] republishInvite failed:', e)
    )
  }
  const outerEventId = (meta as (OnEventMeta & { outerEventId?: string }) | undefined)?.outerEventId
  const receiptAuthorPubkey = isFromSelf ? myPubkey : chatId
  if (rumor.kind === MESSAGE_EDIT_KIND || rumor.kind === MESSAGE_DELETE_KIND) {
    // Mutations must use transport-authenticated authorship, not claims in the inner event.
    const author = meta?.senderOwnerPubkey || (meta?.isSelf ? myPubkey : resolvedFromPubkey)
    await captureMessageMutation(myPubkey, chatId, rumor, author)
    for (const id of new Set([rumor.id, outerEventId].filter((id): id is string => !!id))) {
      await saveProcessedEvent({ id, kind: rumor.kind, chatId, isSelfMessage: author === myPubkey, timestamp: Date.now() })
    }
    return
  }
  await handleIncomingRumor(chatSession, rumor, isFromSelf, outerEventId, receiptAuthorPubkey)
}

// Group admission uses the same authenticated transport bootstrap as a direct
// invite. Once its purpose is known, discard only the empty automatic UI row;
// preserve the transport, explicit chats, and all message history.
const groupInviteConnections = new Set<string>()
export async function markGroupInviteConnection(peer: string): Promise<void> {
  groupInviteConnections.add(peer)
  const chat = get(chats).get(peer)
  if (!chat?.bootstrapOnly || chat.messages.length) return
  clearChat(peer)
  chats.update(value => { value.delete(peer); return value })
  if (get(currentChat)?.id === peer) currentChat.set(null)
  await deleteSessionFromDb(peer)
}

// Accept an invite and create a session
export async function acceptInvite(invite: ChatInvite): Promise<ChatSession> {
  if (invite.type === 'private') {
    const record = (await resolvePrivateInvite(invite))!
    if (record.type === 'group') throw new Error('Use this link to join the group.')
    return acceptInvite({ type: 'legacy', invite: inviteFromRecord(record) })
  }
  if (invite.type === 'pubkey') {
    const existing = get(chats).get(invite.pubkey)
    const myPubkey = getPubkey()
    const isSelfChat = !!myPubkey && invite.pubkey === myPubkey
    const requiresRuntimeReady =
      !existing &&
      !!myPubkey &&
      isSelfChat
    const runtimeReadyPromise = requiresRuntimeReady
      ? waitForNdrRuntime()
          .then(async (runtime) => {
            try {
              await runtime.setupUser(myPubkey)
            } catch (e) {
              console.warn('[chat] Failed to bootstrap self user during acceptInvite:', e)
            }
            return runtime
          })
          .catch((e) => {
            console.warn('[chat] waitForNdrRuntime failed during acceptInvite:', e)
            throw e
          })
      : null
    const chatSession = await ensureManagerChat(invite.pubkey, {
      bootstrap: isSelfChat,
    })
    // User-initiated join: treat as accepted even before sending a message.
    acceptChat(invite.pubkey)
    if (!existing && !isSelfChat) {
      void waitForSendReadyRuntime().catch((e) => {
        console.warn('[chat] Failed to pre-register device for pubkey invite:', e)
      })
    }
    if (!existing && runtimeReadyPromise) {
      await runtimeReadyPromise
    }
    return chatSession
  }

  const ownerPublicKey = invite.invite.ownerPubkey || invite.invite.inviter
  const existing = get(chats).get(ownerPublicKey)

  if (isNip07Login() && !hasNip44Support()) {
    throw new Error('NIP-07 extension does not support NIP-44')
  }

  // Registration must finish before the handshake captures its device proof.
  // An account key alone is not evidence available to the receiving device.
  const runtime = await waitForSendReadyRuntime()
  const accepted = await runtime.acceptInvite(invite.invite, { ownerPublicKey })
  const chatTarget = accepted.ownerPublicKey || ownerPublicKey
  const chatSession = await ensureManagerChat(chatTarget)
  acceptChat(chatSession.recipientPubkey)
  updateDMSubscription()
  return chatSession
}

async function handleIncomingRumor(
  chatSession: ChatSession,
  rumor: Rumor,
  isFromSelfOverride?: boolean,
  outerEventId?: string,
  receiptAuthorPubkey?: string
) {
  // This namespace belongs to local call records, never remote message IDs.
  if (rumor.id.startsWith('call:')) return
  const myPubkey = getPubkey()
  const sessionId = chatSession.id

  // Get current state from store (not the captured reference which may be stale)
  const currentChats = get(chats)
  const currentSession = currentChats.get(sessionId)
  if (!currentSession) return

  const isMine = isFromSelfOverride ?? rumor.pubkey === myPubkey

  // Route group events to group handler
  const groupTag = rumor.tags?.find((t: string[]) => t[0] === 'l')
  if (groupTag) {
    return
  }

  const processedId = rumor.id
  const saveProcessedRumor = (content?: string) => {
    const event = {
      id: processedId, messageId: rumor.id, author: receiptAuthorPubkey || rumor.pubkey, createdAtSecs: rumor.created_at,
      kind: rumor.kind,
      chatId: sessionId,
      content,
      isSelfMessage: isMine,
      timestamp: Date.now(),
    }
    saveProcessedEvent(event)
    if (outerEventId && outerEventId !== processedId) {
      saveProcessedEvent({ ...event, id: outerEventId })
    }
  }

  // Dispatch on inner event kind
  if (rumor.kind === RECEIPT_KIND) {
    // Persist content ('delivered'|'seen') so the SW push handler can render
    // the right notification text via its fast path.
    saveProcessedRumor(rumor.content)
    if (isMine && myPubkey) await applyOwnReadTag(myPubkey, sessionId, rumor)
    const receipt = parseReceipt(rumor)
    if (!receipt) return
    handleIncomingReceipt(currentSession, receipt, isMine, receiptAuthorPubkey)
    return
  }

  if (rumor.kind === REACTION_KIND) {
    saveProcessedRumor(rumor.content)
    const parsed = reactionControl(rumor)
    if (!parsed || !myPubkey) return
    const { emoji, messageId } = parsed
    void captureReaction(myPubkey, sessionId, rumor, receiptAuthorPubkey || (isMine ? myPubkey : currentSession.recipientPubkey), messageId, emoji)
      .catch(error => console.warn('[chat] Failed to save reaction:', error))
    return
  }

  if (rumor.kind === CHAT_SETTINGS_KIND) {
    saveProcessedRumor()
    const settings = parseChatSettingsContent(rumor.content)
    if (settings) {
      expirationStore.setExpiration(sessionId, settings.messageTtlSeconds)
    }
    return
  }

  if (isTyping(rumor)) {
    saveProcessedRumor()
    if (isMine) {
      return
    }
    const expiresAt = getExpirationTimestampSeconds(rumor)
    const nowSeconds = Math.floor(Date.now() / 1000)
    if (expiresAt !== undefined && expiresAt <= nowSeconds) {
      clearRemoteTyping(sessionId)
    } else {
      setRemoteTyping(sessionId, rumor.created_at)
    }
    return
  }

  // Empty kind-14 messages establish a session; they are not conversation
  // history and must not replace a real message's sidebar preview.
  if (rumor.kind !== CHAT_MESSAGE_KIND || !rumor.content.trim()) {
    saveProcessedRumor()
    return
  }

  // Incoming message clears typing indicator
  if (!isMine) {
    clearRemoteTyping(sessionId, rumor.created_at)
  }

  // Extract reply tag if present
  const replyTag = rumor.tags?.find(
    (tag: string[]) => tag[0] === 'e' && tag[3] === 'reply'
  )?.[1] || rumor.tags?.find(
    (tag: string[]) => tag[0] === 'e' && !rumor.tags?.some((t: string[]) => t[0] === 'e' && t[3] === 'root')
  )?.[1]

  // Message requests:
  // - if requests are disabled (or sender rejected), ignore all incoming events for unaccepted chats.
  // - do not send receipts for unaccepted chats.
  const policyCtx = getMessageRequestPolicyContext()
  const shouldIgnore = shouldIgnoreIncomingEvent(currentSession, isMine, policyCtx)
  if (shouldIgnore) return
  const chatAccepted = isChatAccepted(currentSession, policyCtx)

  // Auto-set delivered status for incoming messages
  const shouldAckDelivered = !isMine && get(receiptSettings).sendDeliveryReceipts && chatAccepted

  // Extract NIP-40 expiration tag
  const expiresAt = getExpirationTimestampSeconds(rumor)

  const message: ChatMessage = {
    id: processedId,
    content: rumor.content,
    ...directFileMessageFields(rumor.content),
    timestamp: controlClock(rumor).createdAtMs ?? rumor.created_at * 1000,
    isMine,
    ...(replyTag && { replyTo: replyTag }),
    ...(shouldAckDelivered && { status: 'delivered' as const }),
    deliveryChannels: ['message servers'],
    outerEventIds: [outerEventId || processedId],
    ...(expiresAt !== undefined && { expiresAt }),
  }

  if (!myPubkey) return
  const { directTransferId: _transfer, ...storedIncoming } = message
  const committed = await persistMessageWithReactions(myPubkey, { ...storedIncoming, sessionId })
  Object.assign(message, committed, { directTransferId: committed.deletedAt !== undefined ? undefined : message.directTransferId })
  saveProcessedRumor(message.content)

  // Check if message already exists
  const updatedSession = updateChatSession(sessionId, (latestSession) => {
    if (latestSession.messages.some((m) => m.id === message.id)) {
      return null
    }

    const updatedMessages = [...latestSession.messages, message].sort(
      (a, b) => a.timestamp - b.timestamp
    )
    return { ...latestSession, messages: updatedMessages }
  })
  if (!updatedSession) return
  void import('./foregroundMessageNotifications').then(({notifyForegroundMessage}) => notifyForegroundMessage(myPubkey,committed)).catch(()=>{})

  // The incoming body was committed and projected before it became visible.
  saveSessionToStorage(updatedSession)

  // Send delivered receipt
  if (shouldAckDelivered) {
    sendReceipt(updatedSession, 'delivered', [message.id])
  }

  // Update notification subscription (debounced) since keys may have rotated
  updateDMSubscription()
}

// Handle incoming receipt:
// - peer receipts advance status on our outgoing messages
// - self/own-device receipts advance status on incoming messages (cross-session unread sync)
function handleIncomingReceipt(
  chatSession: ChatSession,
  receipt: ReceiptPayload,
  isFromSelf: boolean,
  receiptAuthorPubkey?: string
) {
  const changedMessageStatuses: Array<{ messageId: string; status: MessageStatus }> = []
  const changedRecipientStatuses: Array<{
    messageId: string
    recipientStatuses: Record<string, RecipientDeliveryStatus>
  }> = []
  const updatedSession = updateChatSession(chatSession.id, (latestSession) => {
    let changed = false
    const updatedMessages = [...latestSession.messages]

    for (const messageId of receipt.messageIds) {
      const index = updatedMessages.findIndex(
        (m) => !m.call && m.id === messageId && (isFromSelf ? !m.isMine : m.isMine)
      )
      if (index === -1) continue

      const message = updatedMessages[index]
      const nextRecipientStatuses =
        !isFromSelf && receiptAuthorPubkey
          ? advanceRecipientStatus(message.recipientStatuses, receiptAuthorPubkey, receipt.type)
          : null
      const nextStatus = shouldAdvanceStatus(message.status, receipt.type)
        ? receipt.type
        : message.status
      if (!nextRecipientStatuses && nextStatus === message.status) continue

      updatedMessages[index] = {
        ...message,
        status: nextStatus,
        ...(nextRecipientStatuses && { recipientStatuses: nextRecipientStatuses }),
      }
      if (nextStatus && nextStatus !== message.status) {
        changedMessageStatuses.push({ messageId, status: nextStatus })
      }
      if (nextRecipientStatuses) {
        changedRecipientStatuses.push({
          messageId,
          recipientStatuses: nextRecipientStatuses,
        })
      }
      changed = true
    }

    if (!changed) return null
    return { ...latestSession, messages: updatedMessages }
  })
  if (!updatedSession) return

  for (const { messageId, status } of changedMessageStatuses) {
    updateMessageStatusInDb(messageId, status)
  }
  for (const { messageId, recipientStatuses } of changedRecipientStatuses) {
    updateMessageRecipientStatusesInDb(messageId, recipientStatuses)
  }
}

function getManagerRumorAuthorPubkey(): string {
  const ownerPubkey = getPubkey()?.trim()
  if (ownerPubkey) {
    return ownerPubkey
  }

  const runtimeDeviceId = getNdrRuntime().getState().currentDevicePubkey?.trim()
  if (runtimeDeviceId) {
    return runtimeDeviceId
  }

  const deviceIdentityPubkey = get(devices).identityPubkey?.trim()
  if (deviceIdentityPubkey) {
    return deviceIdentityPubkey
  }

  throw new Error('Not logged in')
}

export function buildManagerRumorOptions(recipientPubkey: string, tags: string[][] = []) {
  return {
    pubkey: getManagerRumorAuthorPubkey(),
    tags: ensureRecipientTag(tags, recipientPubkey),
  }
}

function registerDeviceInBackground(context: string): void {
  void ensureDeviceRegistered().catch((e) =>
    console.warn(`[chat] Device registration failed while ${context}:`, e)
  )
}

function sendRuntimeEvent(
  recipientPubkey: string,
  event: Partial<Rumor>,
  context: string
): void {
  // The caller renders and saves the pending message immediately. Keep network
  // setup asynchronous, but do not send an unprovable account/device claim.
  void waitForSendReadyRuntime()
    .then(async runtime => { const owner = getPubkey(); if (owner && !await isPrivatelyBlocked(owner, recipientPubkey)) await runtime.sendEvent(recipientPubkey, event) })
    .catch((e) => console.error(`[chat] Failed to ${context} via NdrRuntime:`, e))
}

// Send a receipt via the double ratchet session
function sendReceipt(chatSession: ChatSession, type: 'delivered' | 'seen', messageIds: string[]): void {
  if (messageIds.length === 0) return

  sendRuntimeEvent(
    chatSession.recipientPubkey,
    buildReceiptRumor(
      type,
      messageIds,
      buildManagerRumorOptions(chatSession.recipientPubkey)
    ),
    'send receipt'
  )
}

// Send seen receipts for incoming messages - called from ChatView
export function sendSeenReceipts(chatSession: ChatSession, messageIds: string[]): void {
  // Get current state from store
  const currentChats = get(chats)
  const currentSession = currentChats.get(chatSession.id)
  if (!currentSession) return

  // Filter to only messages we haven't already acked as seen
  const toAck = messageIds.filter(id => {
    const msg = currentSession.messages.find(m => m.id === id)
    return msg && msg.status !== 'seen'
  })
  if (toAck.length === 0) return

  const updatedSession = updateChatSession(chatSession.id, (latestSession) => ({
    ...latestSession,
    messages: latestSession.messages.map((m) => {
      if (toAck.includes(m.id)) {
        return { ...m, status: 'seen' as const }
      }
      return m
    }),
  }))
  if (!updatedSession) return

  const owner = getPubkey()
  void Promise.all(toAck.map(id => updateMessageStatusInDb(id, 'seen')))
    .then(() => owner ? sendOwnReadState(owner, chatSession.id, toAck) : undefined).catch(() => {})
  const policyCtx = getMessageRequestPolicyContext()
  if (get(receiptSettings).sendReadReceipts && isChatAccepted(updatedSession, policyCtx)) {
    const messageIds = toAck.filter(id => !updatedSession.messages.find(m => m.id === id)?.call)
    if (messageIds.length) sendReceipt(updatedSession, 'seen', messageIds)
  }
}

// Send a message
export async function sendMessage(chatSession: ChatSession, text: string, replyTo?: string, isCurrent?: () => boolean): Promise<void> {
  if (isCurrent && !isCurrent()) throw new Error('The sending device has changed. Try again.')
  const owner = getPubkey()
  if (owner && await isPrivatelyBlocked(owner, chatSession.recipientPubkey)) throw new Error('Unblock this person to send a message.')
  const tags: string[][] = []
  if (replyTo) {
    tags.push(['e', replyTo, '', 'reply'])
  }

  const rumor = buildTextRumor(
    text,
    buildManagerRumorOptions(chatSession.recipientPubkey, tags)
  )
  const messageId = rumor.id

  // Get current state from store (not the passed reference which may be stale)
  const currentChats = get(chats)
  const currentSession = currentChats.get(chatSession.id)
  if (!currentSession) return

  // Sending a message is an implicit accept for message requests.
  acceptChat(currentSession.recipientPubkey)

  // Add message optimistically - use outer event ID for service worker lookup
  const message: ChatMessage = {
    id: messageId,
    content: text,
    ...directFileMessageFields(text),
    timestamp: Date.now(),
    isMine: true,
    ...(replyTo && { replyTo }),
  }

  // A rendered pending message must survive a reload, including while offline.
  await Promise.all([saveMessageToStorage(chatSession.id, message), saveSessionToStorage(currentSession)])
  if (isCurrent && !isCurrent()) throw new Error('The sending device has changed. Try again.')
  sendRuntimeEvent(chatSession.recipientPubkey, rumor, 'send message')

  const updatedSession = updateChatSession(chatSession.id, (latestSession) => ({
    ...latestSession,
    messages: [...latestSession.messages, message],
  }))
  if (!updatedSession) return

  // Update notification subscription (debounced) since keys may have rotated
  updateDMSubscription()
}

// Send a reaction to a message
export async function sendReaction(chatSession: ChatSession, messageId: string, emoji: string): Promise<void> {
  const owner = getPubkey()
  if (!owner) return
  if (await isPrivatelyBlocked(owner, chatSession.recipientPubkey)) throw new Error('Unblock this person to react.')
  await withDeviceControlClock(owner, { chatId: chatSession.id, messageId, author: owner }, async nowMs => {
    const target = get(chats).get(chatSession.id)?.messages.find(message => message.id === messageId)
    const nextEmoji = target?.reactions?.[emoji]?.includes(owner) ? '' : emoji
    const rumor = buildReactionRumor(messageId, nextEmoji, { ...buildManagerRumorOptions(chatSession.recipientPubkey), nowMs })
    await captureReaction(owner, chatSession.id, rumor, owner, messageId, nextEmoji)
    if (getPubkey() === owner) acceptChat(chatSession.id)
    sendRuntimeEvent(chatSession.recipientPubkey, rumor, 'send reaction')
  })
}

export async function editMessage(chatSession: ChatSession, messageId: string, content: string): Promise<void> {
  await mutateMessage(chatSession, messageId, 'edit', content)
}
export async function deleteMessageForEveryone(chatSession: ChatSession, messageId: string): Promise<void> {
  await mutateMessage(chatSession, messageId, 'delete', '')
}
async function mutateMessage(chatSession: ChatSession, messageId: string, operation: 'edit' | 'delete', content: string): Promise<void> {
  const owner = getPubkey(), message = get(chats).get(chatSession.id)?.messages.find(row => row.id === messageId)
  if (!owner || !message?.isMine || message.call || message.deletedAt !== undefined || operation === 'edit' && !editableMessage(message)) throw new Error('This message cannot be changed.')
  if (await isPrivatelyBlocked(owner, chatSession.recipientPubkey)) throw new Error('Unblock this person to change a message.')
  const rumor = buildMessageMutation(owner, messageId, operation, content, ['p', chatSession.recipientPubkey], Math.max(Date.now(), (message.editedAt ?? 0) + 1), message.expiresAt)
  await sendMessageMutation(owner, chatSession.id, rumor,
    async () => {
      if (chatSession.recipientPubkey === owner) return
      await (await waitForSendReadyRuntime()).sendEvent(chatSession.recipientPubkey, rumor, undefined, { includeLocalSiblings: false })
    }, () => getPubkey() === owner)
}

// Delete a single message locally
export async function deleteMessage(sessionId: string, messageId: string): Promise<void> {
  // Get current state from store
  const currentChats = get(chats)
  const currentSession = currentChats.get(sessionId)
  if (!currentSession) return

  const updatedSession = updateChatSession(sessionId, (latestSession) => ({
    ...latestSession,
    messages: latestSession.messages.filter((m) => m.id !== messageId),
  }))
  if (!updatedSession) return

  // Delete from IndexedDB
  await deleteMessageFromDb(messageId)
}

// Leave current chat
export function leaveChat(): void {
  currentChat.set(null)
  // Clear URL hash
  history.replaceState(null, '', window.location.pathname)
}

// Delete a chat completely
export function deleteChat(chatSession: ChatSession): void {
  getNdrRuntime().deleteChat(chatSession.recipientPubkey).catch(() => {})

  // Remove from store
  chats.update(c => {
    c.delete(chatSession.id)
    return c
  })

  // Clear current chat if it's this one
  const current = get(currentChat)
  if (current?.id === chatSession.id) {
    currentChat.set(null)
  }

  // Delete from storage in background
  deleteSessionFromDb(chatSession.id)
  deleteMessagesForSession(chatSession.id)

  // Clear URL hash
  history.replaceState(null, '', window.location.pathname)
}

// Call history is authored only by the authenticated local call lifecycle.
// It is never sent as a message or accepted from a remote history payload.
export function recordCallHistory(owner: string, call: CallHistory): void {
  const chat = Array.from(get(chats).values()).find(chat => chat.recipientPubkey === owner)
  if (!chat) return
  const id = `call:${call.callId}`
  const previous = chat.messages.find(message => message.id === id)
  // Finalized history cannot be replaced by a delayed ringing/answer update.
  if (previous?.call && !previous.call.inProgress && call.inProgress) return
  const message: ChatMessage = {
    id, call, content: callHistoryLabel(call), timestamp: call.startedAt,
    isMine: call.direction === 'outgoing',
    ...(previous?.status && { status: previous.status }),
  }
  updateChatSession(chat.id, latest => ({ ...latest,
    messages: mergeChatMessages([...latest.messages.filter(item => item.id !== id), message]),
  }))
  void saveMessageToStorage(chat.id, message)
}

// Storage helpers
export async function saveSessionToStorage(chatSession: ChatSession): Promise<void> {
  try {
    const storedSession: StoredSession = {
      id: chatSession.id,
      recipientPubkey: chatSession.recipientPubkey,
      createdAt: Date.now(),
      inviteId: chatSession.inviteId,
      inviteLabel: chatSession.inviteLabel,
      bootstrapOnly: chatSession.bootstrapOnly,
      mode: 'manager',
    }
    await saveSessionToDb(storedSession)
  } catch (e) {
    console.error('Failed to save session to storage:', e)
  }
}

async function saveMessageToStorage(sessionId: string, message: ChatMessage): Promise<void> {
  try {
    // Deep clone reactions to make it IndexedDB-safe
    const reactions = message.reactions
      ? JSON.parse(JSON.stringify(message.reactions))
      : undefined

    const storedMessage: StoredMessage = {
      id: message.id,
      sessionId,
      content: message.content,
      ...messageMutationFields(message),
      timestamp: message.timestamp,
      isMine: message.isMine,
      ...(message.replyTo && { replyTo: message.replyTo }),
      reactions,
      status: message.status,
      ...(message.call && { call: message.call }),
      ...(message.sentToRelays && { sentToRelays: message.sentToRelays }),
      ...(message.recipientStatuses && { recipientStatuses: message.recipientStatuses }),
      ...(message.deliveryChannels && { deliveryChannels: message.deliveryChannels }),
      ...(message.outerEventIds && { outerEventIds: message.outerEventIds }),
      ...(message.pendingRelayEventIds && { pendingRelayEventIds: message.pendingRelayEventIds }),
      ...(message.senderPubkey && { senderPubkey: message.senderPubkey }),
      ...(message.expiresAt !== undefined && { expiresAt: message.expiresAt }),
    }
    const owner = getPubkey()
    if (owner) await persistMessageWithReactions(owner, storedMessage)
    else await saveMessageToDb(storedMessage)
  } catch (e) {
    console.error('Failed to save message to storage:', e)
  }
}

// Load chats from IndexedDB
export async function loadChatsFromStorage(): Promise<void> {
  const owner = getPubkey()
  if (owner) loadMessageRequestDecisions(owner)
  if (isInitialized) return

  try {
    const storedSessions = await getAllSessions()
    initNdrRuntimeEvents()

    for (const stored of storedSessions) {
      try {
        const storedMessages = await getMessagesForSession(stored.id)
        if (owner) for (const message of storedMessages) await restoreStoredRequestAcceptance(owner, message)
        const messages: ChatMessage[] = storedMessages
    .filter(message => !!message.content.trim() || message.deletedAt !== undefined || !!message.call)
          .map(m => ({
            id: m.id,
            content: m.content,
            ...messageMutationFields(m),
            ...directFileMessageFields(m.content),
            timestamp: m.timestamp,
            isMine: m.isMine,
            ...(m.replyTo && { replyTo: m.replyTo }),
            reactions: m.reactions,
            status: m.status,
            ...restoredCallHistory(m.call),
            ...(m.sentToRelays && { sentToRelays: m.sentToRelays }),
            ...(m.recipientStatuses && { recipientStatuses: m.recipientStatuses }),
            ...(m.deliveryChannels && { deliveryChannels: m.deliveryChannels }),
            ...(m.outerEventIds && { outerEventIds: m.outerEventIds }),
            ...(m.pendingRelayEventIds && { pendingRelayEventIds: m.pendingRelayEventIds }),
            senderPubkey: m.senderPubkey,
            ...(m.expiresAt !== undefined && { expiresAt: m.expiresAt }),
          }))
          .sort((a, b) => a.timestamp - b.timestamp)

        const chatSession: ChatSession = {
          id: stored.id,
          recipientPubkey: stored.recipientPubkey,
          mode: 'manager',
          messages,
          inviteId: stored.inviteId,
          inviteLabel: stored.inviteLabel,
          bootstrapOnly: stored.bootstrapOnly,
        }

        // Add to chats store
        chats.update(c => {
          c.set(chatSession.id, chatSession)
          return c
        })
      } catch (e) {
        console.error('Failed to restore session:', stored.id, e)
      }
    }

    canonicalizeKnownManagerChats()
    if (owner) await restoreOwnReactionAcceptance(owner)
    isInitialized = true
  } catch (e) {
    console.error('Failed to load chats from storage:', e)
  }
}

// Send a typing indicator event
export function sendTypingEvent(chatSession: ChatSession): void {
  if (!get(typingSettings).sendTypingIndicators) return

  // Don't reveal we're typing until a request is accepted.
  const policyCtx = getMessageRequestPolicyContext()
  if (!isChatAccepted(chatSession, policyCtx)) return

  sendRuntimeEvent(
    chatSession.recipientPubkey,
    buildTypingRumor(buildManagerRumorOptions(chatSession.recipientPubkey)),
    'send typing'
  )
}

// Clear all chat data (for logout)
export async function clearChatData(): Promise<void> {
  try {
    // Stop all invite listeners
    const currentInvites = get(invites)
    for (const [, activeInvite] of currentInvites) {
      activeInvite.unsubscribe()
    }

    await clearAllData()
    chats.set(new Map())
    currentChat.set(null)
    invites.set(new Map())
    isInitialized = false
    invitesInitialized = false
    runtimeSessionSubscribed = false
    runtimeSubscriptionPromise = null
    runtimeSessionEventCleanup?.()
    runtimeSessionEventCleanup = null
    groupRuntimeCleanup?.()
    groupRuntimeCleanup = null
    groupRuntimeSubscribed = false
    if (runtimePoller) {
      clearInterval(runtimePoller)
      runtimePoller = null
    }
    pendingAutoOpenChats.clear()
    autoOpenedChats.clear()
    groupInviteConnections.clear()
    pushEventIngestInFlight.clear()
  } catch (e) {
    console.error('Failed to clear chat data:', e)
  }
}
