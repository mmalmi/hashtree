/**
 * Relay Store - tracks relay configuration and connection status
 */
import { writable, derived, get } from 'svelte/store'
import type NostrClient from './nostrClient'
import { DEFAULT_RELAYS, DEFAULT_PUBLIC_RELAYS } from './defaultRelays'

export type RelayStatus = 'disconnected' | 'connecting' | 'connected'

export interface RelayState {
  relays: Set<string>
  defaults: boolean
  statuses: Map<string, RelayStatus>
  connectedCount: number
  showConnectivity: boolean
}

const RELAYS_STORAGE_KEY = 'iris-chat-relays'
const SHOW_CONNECTIVITY_KEY = 'iris-chat-show-connectivity'

// Normalize relay URL (remove trailing slash)
function normalizeRelayUrl(url: string): string {
  return url.replace(/\/$/, '')
}

export { DEFAULT_RELAYS }

export function getPublicRelays(state: Pick<RelayState, 'relays' | 'defaults'>): string[] {
  return state.defaults ? [...DEFAULT_PUBLIC_RELAYS] : [...state.relays]
}

function loadRelays(): Pick<RelayState, 'relays' | 'defaults'> {
  try {
    const stored = localStorage.getItem(RELAYS_STORAGE_KEY)
    if (stored !== null) {
      const parsed = JSON.parse(stored)
      return { relays: new Set(Array.isArray(parsed) && parsed.every(url => typeof url === 'string') ? parsed : []), defaults: false }
    }
  } catch {
    // Unknown saved policy must not silently enable public relays.
    return { relays: new Set(), defaults: false }
  }
  return { relays: new Set(DEFAULT_RELAYS), defaults: true }
}

function saveRelays(relays: Set<string>): void {
  try {
    localStorage.setItem(RELAYS_STORAGE_KEY, JSON.stringify([...relays]))
  } catch {
    // ignore
  }
}

function loadShowConnectivity(): boolean {
  try {
    const stored = localStorage.getItem(SHOW_CONNECTIVITY_KEY)
    return stored === 'true'
  } catch {
    return false
  }
}

function saveShowConnectivity(show: boolean): void {
  try {
    localStorage.setItem(SHOW_CONNECTIVITY_KEY, String(show))
  } catch {
    // ignore
  }
}

function createRelayStore() {
  const initialPolicy = loadRelays()
  const initialRelays = initialPolicy.relays
  const { subscribe, update, set } = writable<RelayState>({
    relays: initialRelays,
    defaults: initialPolicy.defaults,
    statuses: new Map([...initialRelays].map(url => [url, 'disconnected' as RelayStatus])),
    connectedCount: 0,
    showConnectivity: loadShowConnectivity(),
  })

  return {
    subscribe,

    setRelays(relays: Set<string>) {
      saveRelays(relays)
      update(state => {
        const newStatuses = new Map<string, RelayStatus>()
        for (const url of relays) {
          newStatuses.set(url, state.statuses.get(url) || 'disconnected')
        }
        return { ...state, relays, defaults: false, statuses: newStatuses }
      })
    },

    addRelay(url: string) {
      update(state => {
        if (state.relays.has(url)) return state
        const newRelays = new Set(state.relays)
        newRelays.add(url)
        saveRelays(newRelays)
        const newStatuses = new Map(state.statuses)
        newStatuses.set(url, 'disconnected')
        return { ...state, relays: newRelays, defaults: false, statuses: newStatuses }
      })
    },

    removeRelay(url: string) {
      update(state => {
        const newRelays = new Set(state.relays)
        newRelays.delete(url)
        saveRelays(newRelays)
        const newStatuses = new Map(state.statuses)
        newStatuses.delete(url)
        return { ...state, relays: newRelays, defaults: false, statuses: newStatuses }
      })
    },

    resetToDefaults() {
      const defaults = new Set(DEFAULT_RELAYS)
      try { localStorage.removeItem(RELAYS_STORAGE_KEY) } catch { /* Current selection remains usable in memory. */ }
      update(state => ({
        ...state,
        relays: defaults,
        defaults: true,
        statuses: new Map(DEFAULT_RELAYS.map(url => [url, 'disconnected' as RelayStatus])),
        connectedCount: 0,
      }))
    },

    setShowConnectivity(show: boolean) {
      saveShowConnectivity(show)
      update(state => ({ ...state, showConnectivity: show }))
    },

    updateStatuses(nostrClient: NostrClient) {
      update(state => {
        const newStatuses = new Map<string, RelayStatus>()
        let connected = 0

        // Normalize configured relay URLs for comparison
        const normalizedConfigured = new Map<string, string>()
        for (const url of state.relays) {
          normalizedConfigured.set(normalizeRelayUrl(url), url)
          newStatuses.set(url, 'disconnected')
        }

        // Update from pool - iterate over actual connected relays
        for (const relay of nostrClient.runtime.getRelayStats()) {
          const normalizedUrl = normalizeRelayUrl(relay.url)
          const configuredUrl = normalizedConfigured.get(normalizedUrl)
          if (!configuredUrl) continue

          // Read the shared runtime connection state.
          if (relay.connected) {
            newStatuses.set(configuredUrl, 'connected')
            connected++

          } else {
            newStatuses.set(configuredUrl, 'disconnected')
          }
        }

        return { ...state, statuses: newStatuses, connectedCount: connected }
      })
    },

    getState(): RelayState {
      return get({ subscribe })
    },
  }
}

export const relayStore = createRelayStore()

export const connectedRelayCount = derived(relayStore, $store => $store.connectedCount)
export const configuredRelays = derived(relayStore, $store => [...$store.relays])
