import type { MessageRevision } from './messageMutations'
// IndexedDB storage using Dexie

import type { CallHistory } from './callHistory'
import Dexie, { type Table } from 'dexie'
import { mergeUniqueStrings } from './messageRelayStatus'
import { clearDirectFileStorage } from './directFileStorage'

// Re-export serialization functions from nostr-double-ratchet
export { serializeSessionState, deserializeSessionState } from 'nostr-double-ratchet'

export interface StoredSession {
  bootstrapOnly?: boolean
  id: string
  recipientPubkey: string
  sessionState?: string // JSON-serialized session state (hex encoded by nostr-double-ratchet)
  createdAt: number
  inviteId?: string      // ID of the invite that started this chat
  inviteLabel?: string   // Label of the invite that started this chat
  mode?: 'legacy' | 'manager'
}

export interface StoredMessage {
  call?: CallHistory
  id: string
  sessionId: string
  content: string
  originalContent?: string
  editHistory?: MessageRevision[]
  editedAt?: number
  deletedAt?: number
  timestamp: number
  isMine: boolean
  replyTo?: string
  reactions?: Record<string, string[]>  // emoji -> array of pubkeys who reacted
  status?: 'delivered' | 'seen'
  sentToRelays?: string[]
  recipientStatuses?: Record<string, 'sent' | 'delivered' | 'seen'>
  deliveryChannels?: string[]
  outerEventIds?: string[]
  pendingRelayEventIds?: string[]
  senderPubkey?: string  // pubkey of sender (for group messages)
  expiresAt?: number  // Unix timestamp in seconds when message expires (NIP-40)
}

export interface StoredGroup {
  id: string
  name: string
  description?: string
  picture?: string
  members: string[]  // pubkeys of group members
  admins: string[]   // pubkeys of admins
  createdAt: number
  secret?: string     // 32-byte hex group secret for shared channel
  protocol?: 'sender_key_v1' | 'pairwise_fanout_v1'
  accepted?: boolean  // whether user has accepted the group invitation
  rosterVersion?: { revision: number; updatedAt: number; eventCreatedAt: number; eventId: string }
}

export interface StoredProfile {
  pubkey: string
  eventCreatedAt?: number
  eventId?: string
  name?: string
  display_name?: string
  username?: string
  nip05?: string
  picture?: string
  updatedAt: number
}

export interface StoredInvite {
  id: string           // unique id
  inviteData: string   // serialized invite payload (legacy or pubkey link)
  label?: string       // optional user label
  createdAt: number
  usedBy?: string[]    // pubkeys of users who accepted this invite
}

export interface ProcessedEvent {
  messageId?: string
  author?: string
  createdAtSecs?: number
  id: string           // outer event ID
  kind: number         // inner event kind (7=reaction, 15=receipt, 25=typing)
  chatId: string       // session/chat ID
  content?: string     // e.g. emoji for reactions
  isSelfMessage?: boolean
  timestamp: number
}

export interface PendingPushEvent {
  id: string
  event: unknown
  timestamp: number
}

class IrisChatDB extends Dexie {
  sessions!: Table<StoredSession, string>
  messages!: Table<StoredMessage, string>
  profiles!: Table<StoredProfile, string>
  invites!: Table<StoredInvite, string>
  processedEvents!: Table<ProcessedEvent, string>
  groups!: Table<StoredGroup, string>
  sessionManager!: Table<{ key: string; value: unknown }, string>
  pendingPushEvents!: Table<PendingPushEvent, string>

  constructor() {
    super('iris-chat')
    this.version(1).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey'
    })
    this.version(2).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey',
      invites: 'id'
    })
    this.version(3).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey',
      invites: 'id',
      processedEvents: 'id, timestamp'
    })
    this.version(4).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey',
      invites: 'id',
      processedEvents: 'id, timestamp',
      groups: 'id'
    })
    this.version(5).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey',
      invites: 'id',
      processedEvents: 'id, timestamp',
      groups: 'id',
      sessionManager: 'key'
    })
    this.version(6).stores({
      sessions: 'id',
      messages: 'id, sessionId',
      profiles: 'pubkey',
      invites: 'id',
      processedEvents: 'id, timestamp',
      groups: 'id',
      sessionManager: 'key',
      pendingPushEvents: 'id, timestamp'
    })
  }
}

export const db = new IrisChatDB()

// Session operations
export async function saveSession(session: StoredSession): Promise<void> {
  await db.sessions.put(session)
}

export async function getAllSessions(): Promise<StoredSession[]> {
  return db.sessions.toArray()
}

export async function deleteSession(id: string): Promise<void> {
  await db.sessions.delete(id)
}

// Message operations
export async function saveMessage(message: StoredMessage): Promise<void> {
  await db.messages.put(message)
}

export async function getMessagesForSession(sessionId: string): Promise<StoredMessage[]> {
  const rows = await db.messages.where('sessionId').equals(sessionId).toArray()
  const owner = (await db.sessionManager.get('v1/device-manager/owner-pubkey'))?.value
  if (typeof owner !== 'string') return rows
  const { privateHistoryAllowed, projectMessageRead } = await import('./privateStateStore')
  const filtered: StoredMessage[] = []
  for (const row of rows) if (await privateHistoryAllowed(owner, row.isMine ? owner : row.senderPubkey ?? sessionId, Math.floor(row.timestamp / 1000))) filtered.push(await projectMessageRead(owner, row))
  return filtered
}

export async function chatDeletionStates(): Promise<Array<{ id: string; deletedAt: number }>> {
  const prefix = 'history-deleted-chat:'
  return (await db.sessionManager.where('key').startsWith(prefix).toArray())
    .filter(row => Number.isSafeInteger(row.value) && (row.value as number) > 0)
    .map(row => ({ id: row.key.slice(prefix.length), deletedAt: row.value as number }))
}

export async function applyHistoryChatDeletion(sessionId: string, deletedAt: number, authorized: () => boolean = () => true): Promise<void> {
  if (!Number.isSafeInteger(deletedAt) || deletedAt <= 0 || deletedAt > Date.now() / 1000 + 300) throw new Error('Invalid chat deletion')
  const changed = await db.transaction('rw', db.messages, db.sessions, db.groups, db.sessionManager, async () => {
    if (!authorized()) throw new Error('Account changed')
    const key = `history-deleted-chat:${sessionId}`
    const previous = (await db.sessionManager.get(key))?.value as number | undefined
    const cutoff = Math.max(previous ?? 0, deletedAt)
    await db.sessionManager.put({ key, value: cutoff })
    const messages = await db.messages.where('sessionId').equals(sessionId).toArray()
    for (const message of messages) if (Math.floor(message.timestamp / 1000) <= cutoff) {
      await rememberHistoryDeletion(message)
      await db.messages.delete(message.id)
    }
    const removed = new Set(messages.filter(message => Math.floor(message.timestamp / 1000) <= cutoff).map(message => message.id))
    await purgeMessageMutationRecords(value => value.chatId === sessionId && (removed.has(value.messageId) || (value.createdAt ?? 0) <= cutoff))
    if (!messages.some(message => Math.floor(message.timestamp / 1000) > cutoff)) {
      const session = await db.sessions.get(sessionId)
      if (session && Math.floor(session.createdAt / 1000) <= cutoff) await db.sessions.delete(sessionId)
      if (sessionId.startsWith('group:')) {
        const group = await db.groups.get(sessionId.slice(6))
        if (group && (group.rosterVersion?.updatedAt ?? Math.floor(group.createdAt / 1000)) <= cutoff) await db.groups.delete(group.id)
      }
    }
    return cutoff > (previous ?? 0)
  })
  if (changed) (await import('./deviceSyncRecordStore')).deviceRecordVersion.update(n => n + 1)
}

export async function deleteMessagesForSession(sessionId: string): Promise<void> {
  const messages = await db.messages.where('sessionId').equals(sessionId).toArray()
  const cutoff = Math.max(Math.floor(Date.now() / 1000), ...messages.map(message => Math.floor(message.timestamp / 1000)))
  await applyHistoryChatDeletion(sessionId, cutoff)
}

export async function getMessageById(id: string): Promise<StoredMessage | undefined> {
  return db.messages.get(id)
}

export async function deleteMessage(id: string): Promise<void> {
  await db.transaction('rw', db.messages, db.sessionManager, async () => {
    const message = await db.messages.get(id)
    await db.sessionManager.put({ key: `history-deleted-message:${id}`, value: message
      ? { chatId: message.sessionId, id, createdAt: Math.floor(message.timestamp / 1000) } : null })
    await db.messages.delete(id)
    await purgeMessageMutationRecords(value => value.messageId === id)
  })
}

/** Purge edit plaintext together with message/chat removal and expiry. */
async function purgeMessageMutationRecords(matches: (value: { chatId: string; messageId: string; createdAt?: number; expiresAt?: number }) => boolean): Promise<void> {
  const rows = await db.sessionManager.where('key').startsWith('device-record-v1:')
    .filter(row => row.key.includes(':messageMutation:') && !!row.value && matches(row.value as { chatId: string; messageId: string })).toArray()
  await db.sessionManager.bulkDelete(rows.map(row => row.key))
  for (const row of rows) {
    const value = row.value as { chatId: string; messageId: string; id: string }
    const owner = row.key.slice('device-record-v1:'.length).split(':')[0]
    const indexKey = `message-mutation-target:${owner}:${JSON.stringify([value.chatId, value.messageId])}`
    const index = (await db.sessionManager.get(indexKey))?.value as string[] | undefined
    const remaining = index?.filter(id => id !== value.id) ?? []
    if (remaining.length) await db.sessionManager.put({ key: indexKey, value: remaining })
    else await db.sessionManager.delete(indexKey)
  }
}
export async function purgeExpiredMessageMutations(nowSeconds: number): Promise<void> {
  await db.transaction('rw', db.sessionManager, () => purgeMessageMutationRecords(value => value.expiresAt !== undefined && value.expiresAt <= nowSeconds))
}

async function rememberHistoryDeletion(message: StoredMessage): Promise<void> {
  await db.sessionManager.put({ key: `history-deleted-message:${message.id}`,
    value: { chatId: message.sessionId, id: message.id, createdAt: Math.floor(message.timestamp / 1000) } })
}

export async function* deletedHistoryRecords(): AsyncGenerator<{ chatId: string; id: string; createdAt: number }> {
  const base = 'history-deleted-message:'
  let after: string | undefined
  while (true) {
    const rows = await db.sessionManager.where('key').between(after ?? base, `${base}\uffff`, after === undefined, true).limit(256).toArray()
    for (const row of rows) if (row.value) yield row.value as { chatId: string; id: string; createdAt: number }
    if (rows.length < 256) return
    after = rows.at(-1)!.key
  }
}

export async function isHistoryChatDeleted(chatId: string, createdAt?: number): Promise<boolean> {
  const deleted = (await db.sessionManager.get(`history-deleted-chat:${chatId}`))?.value as number | undefined
  if (deleted === undefined) return false
  if (createdAt !== undefined) return createdAt <= deleted
  const session = await db.sessions.get(chatId)
  if (session && session.createdAt / 1000 > deleted) return false
  const group = chatId.startsWith('group:') ? await db.groups.get(chatId.slice(6)) : undefined
  if (group && (group.rosterVersion?.updatedAt ?? group.createdAt / 1000) > deleted) return false
  return !await db.messages.where('sessionId').equals(chatId).filter(message => Math.floor(message.timestamp / 1000) > deleted).first()
}

/** A transfer may complete only after storage contains the row or a durable suppression. */
export async function isHistoryMessageSettled(message: { id: string; chatId: string; createdAt: number; expiresAt?: number }): Promise<boolean> {
  if (message.expiresAt !== undefined && message.expiresAt <= Math.floor(Date.now() / 1000)) return true
  const stored = await db.messages.get(message.id)
  if (stored?.sessionId === message.chatId) return true
  if (await db.sessionManager.get(`history-deleted-message:${message.id}`)) return true
  const deleted = await db.sessionManager.get(`history-deleted-chat:${message.chatId}`)
  return !!deleted && message.createdAt <= (deleted.value as number)
}

/** Check deletion suppression and save in one transaction, before updating UI. */
export async function admitHistoryMessage(message: StoredMessage, authorized: () => boolean = () => true): Promise<boolean> {
  return db.transaction('rw', db.messages, db.sessionManager, async () => {
    if (!authorized() || await db.sessionManager.get(`history-deleted-message:${message.id}`)) return false
    const removedChat = await db.sessionManager.get(`history-deleted-chat:${message.sessionId}`)
    if (removedChat && Math.floor(message.timestamp / 1000) <= (removedChat.value as number)) return false
    if (await db.messages.get(message.id)) return false
    if (!authorized()) return false
    await db.messages.put(message)
    return true
  })
}

export async function updateMessageStatus(id: string, status: 'delivered' | 'seen'): Promise<void> {
  await db.messages.update(id, { status })
}

export async function updateMessageSentToRelays(
  id: string,
  relayUrls: string[]
): Promise<void> {
  const existing = await db.messages.get(id)
  const sentToRelays = mergeUniqueStrings(existing?.sentToRelays, relayUrls)
  if (sentToRelays.length === 0) return
  await db.messages.update(id, { sentToRelays })
}

export async function updateMessageRecipientStatuses(
  id: string,
  recipientStatuses: Record<string, 'sent' | 'delivered' | 'seen'>
): Promise<void> {
  const existing = await db.messages.get(id)
  await db.messages.update(id, {
    recipientStatuses: {
      ...(existing?.recipientStatuses || {}),
      ...recipientStatuses,
    },
  })
}

export async function updateMessageDeliveryTrace(
  id: string,
  trace: {
    deliveryChannels?: string[]
    outerEventIds?: string[]
    pendingRelayEventIds?: string[]
  }
): Promise<void> {
  const existing = await db.messages.get(id)
  const updates: Partial<StoredMessage> = {}
  if (trace.deliveryChannels) {
    updates.deliveryChannels = mergeUniqueStrings(existing?.deliveryChannels, trace.deliveryChannels)
  }
  if (trace.outerEventIds) {
    updates.outerEventIds = mergeUniqueStrings(existing?.outerEventIds, trace.outerEventIds)
  }
  if (trace.pendingRelayEventIds) {
    updates.pendingRelayEventIds = mergeUniqueStrings(
      existing?.pendingRelayEventIds,
      trace.pendingRelayEventIds
    )
  }
  if (Object.keys(updates).length === 0) return
  await db.messages.update(id, updates)
}

// Profile operations
export async function saveProfileToStorage(profile: StoredProfile): Promise<void> {
  await db.profiles.put(profile)
}

export async function getProfileFromStorage(pubkey: string): Promise<StoredProfile | undefined> {
  return db.profiles.get(pubkey)
}

export async function getPeopleProfilesFromStorage(pubkeys?: string[]): Promise<StoredProfile[]> {
  if (!pubkeys) return db.profiles.limit(5000).toArray()
  return (await db.profiles.bulkGet(pubkeys)).filter((profile): profile is StoredProfile => !!profile)
}

// Invite operations
export async function saveInvite(invite: StoredInvite): Promise<void> {
  await db.invites.put(invite)
}

export async function getAllInvites(): Promise<StoredInvite[]> {
  return db.invites.toArray()
}

export async function deleteInvite(id: string): Promise<void> {
  await db.invites.delete(id)
}

export async function updateInviteLabel(id: string, label: string): Promise<void> {
  await db.invites.update(id, { label })
}

export async function addInviteUsedBy(id: string, pubkey: string): Promise<void> {
  const invite = await db.invites.get(id)
  if (invite) {
    const usedBy = invite.usedBy || []
    if (!usedBy.includes(pubkey)) {
      await db.invites.update(id, { usedBy: [...usedBy, pubkey] })
    }
  }
}

// Processed event operations (for SW notification suppression)
export async function saveProcessedEvent(event: ProcessedEvent): Promise<void> {
  await db.processedEvents.put(event)
  // Prune old entries (keep last 24h)
  const cutoff = Date.now() - 24 * 60 * 60 * 1000
  await db.processedEvents.where('timestamp').below(cutoff).delete()
}

export async function getProcessedEvent(id: string): Promise<ProcessedEvent | undefined> {
  return db.processedEvents.get(id)
}

// Pending push events captured by the service worker while the app runtime is not available.
export async function savePendingPushEvent(event: PendingPushEvent): Promise<void> {
  await db.pendingPushEvents.put(event)
  const cutoff = Date.now() - 24 * 60 * 60 * 1000
  await db.pendingPushEvents.where('timestamp').below(cutoff).delete()
}

export async function getPendingPushEvents(): Promise<PendingPushEvent[]> {
  return db.pendingPushEvents.orderBy('timestamp').toArray()
}

export async function deletePendingPushEvent(id: string): Promise<void> {
  await db.pendingPushEvents.delete(id)
}

// Group operations
export async function saveGroup(group: StoredGroup): Promise<void> {
  await db.groups.put(group)
}

export async function getAllGroups(): Promise<StoredGroup[]> {
  return db.groups.toArray()
}

export async function deleteGroupFromDb(id: string): Promise<void> {
  await db.groups.delete(id)
}

// Clear all data (for logout)
export async function clearAllData(): Promise<void> {
  await Promise.all([
    clearDirectFileStorage(),
    db.sessions.clear(),
    db.messages.clear(),
    db.profiles.clear(),
    db.invites.clear(),
    db.processedEvents.clear(),
    db.groups.clear(),
    db.sessionManager.clear(),
    db.pendingPushEvents.clear()
  ])
}

// SessionManager key-value storage operations
export async function getSessionManagerValue<T = unknown>(key: string): Promise<T | undefined> {
  const record = await db.sessionManager.get(key)
  return record?.value as T | undefined
}

export async function putSessionManagerValue<T = unknown>(key: string, value: T): Promise<void> {
  await db.sessionManager.put({ key, value })
}

export async function deleteSessionManagerValue(key: string): Promise<void> {
  await db.sessionManager.delete(key)
}

export async function listSessionManagerKeys(prefix = ''): Promise<string[]> {
  return prefix
    ? db.sessionManager.where('key').startsWith(prefix).primaryKeys()
    : db.sessionManager.toCollection().primaryKeys()
}
