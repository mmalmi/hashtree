import { writable, get } from 'svelte/store'
import { verifyEvent, type Event } from 'nostr-tools'
import { AppEvent, CacheMode, type EventSubscription } from './nostrClient'
import { identity, nostrClient } from './identity'
import { followListUpdate } from './followListUpdate'

// Set of pubkeys we follow (based on kind:3 contact list).
export const following = writable<Set<string>>(new Set())
const verifiedFollowingHead = writable<Event | null>(null)
export const followingHead = { subscribe: verifiedFollowingHead.subscribe }

let sub: EventSubscription | null = null
let identityUnsub: (() => void) | null = null
let lastPubkey: string | null = null
let latestCreatedAt = 0

function stopSubscription(): void {
  try {
    sub?.stop()
  } catch {
    // ignore
  }
  sub = null
  latestCreatedAt = 0
}

function parseFollowingFromEvent(raw: Event): Set<string> {
  const next = new Set<string>()
  for (const tag of raw?.tags || []) {
    if (tag[0] === 'p' && typeof tag[1] === 'string' && tag[1].length > 0) {
      next.add(tag[1])
    }
  }
  return next
}

const FOLLOWING_CACHE_PREFIX = 'iris-chat-following:'

function applyFollowing(event: Event) {
  if (get(identity)?.pubkey !== event.pubkey || event.created_at < latestCreatedAt) return
  latestCreatedAt = event.created_at
  verifiedFollowingHead.set(event)
  following.set(parseFollowingFromEvent(event))
  try { localStorage.setItem(FOLLOWING_CACHE_PREFIX + event.pubkey, JSON.stringify(event)) } catch { /* Storage may be unavailable. */ }
}

let followingWrites: Promise<void> = Promise.resolve()
export function setPublicFollow(pubkey: string, follow: boolean): Promise<void> {
  const account = get(identity)
  if (!account?.signer) return Promise.reject(new Error('Use your main device to follow'))
  const write = followingWrites.then(async () => {
    const client = get(nostrClient)
    if (get(identity)?.pubkey !== account.pubkey) throw new Error('Account changed')
    const heads = await client.fetchEvents({ kinds: [3], authors: [account.pubkey], limit: 1 }, { cacheUsage: CacheMode.ONLY_RELAY })
    for (const item of heads) {
      const raw = item.rawEvent() as Event
      if (validFollowEvent(raw, account.pubkey)) applyFollowing(raw)
    }
    const head = get(verifiedFollowingHead)
    const draft = new AppEvent(client, followListUpdate(head, pubkey, follow, Math.floor(Date.now() / 1000)))
    await draft.sign(account.signer)
    if (get(identity)?.pubkey !== account.pubkey) throw new Error('Account changed')
    await draft.publish()
    applyFollowing(draft.rawEvent())
  })
  followingWrites = write.catch(() => {})
  return write
}
function validFollowEvent(event: Event, owner: string): boolean {
  try {
    return event?.kind === 3 && event.pubkey === owner &&
      event.created_at <= Math.floor(Date.now() / 1000) + 300 && verifyEvent(event)
  } catch { return false }
}
function cachedFollowing(owner: string): Event | undefined {
  try {
    const event = JSON.parse(localStorage.getItem(FOLLOWING_CACHE_PREFIX + owner) || 'null')
    return validFollowEvent(event, owner) ? event : undefined
  } catch { return undefined }
}

// Call once on app start. Returns a cleanup function.
export function initFollowing(): () => void {
  if (identityUnsub) return () => {}

  identityUnsub = identity.subscribe((id) => {
    const pubkey = id?.pubkey || null
    if (pubkey === lastPubkey) return
    lastPubkey = pubkey

    stopSubscription()
    following.set(new Set())
    verifiedFollowingHead.set(null)

    if (!pubkey) return

    const cached = cachedFollowing(pubkey)
    if (cached) {
      verifiedFollowingHead.set(cached)
      following.set(parseFollowingFromEvent(cached))
    }
    const client = get(nostrClient)
    latestCreatedAt = cached?.created_at ?? 0

    // Keep listening; contact list updates should take effect immediately.
    sub = client.subscribe(
      { kinds: [3], authors: [pubkey], limit: 1 },
      { closeOnEose: false }
    )

    sub.on('event', (ev: AppEvent) => {
      if (lastPubkey !== pubkey) return
      const raw = ev.rawEvent() as Event
      if (!validFollowEvent(raw, pubkey)) return
      const createdAt = raw.created_at
      if (createdAt && createdAt < latestCreatedAt) return
      applyFollowing(raw)
    })
  })

  return () => {
    identityUnsub?.()
    identityUnsub = null
    lastPubkey = null
    stopSubscription()
    following.set(new Set())
    verifiedFollowingHead.set(null)
  }
}

export function clearFollowingCache(owner: string): void {
  try { localStorage.removeItem(FOLLOWING_CACHE_PREFIX + owner) } catch { /* Storage may be unavailable. */ }
}
