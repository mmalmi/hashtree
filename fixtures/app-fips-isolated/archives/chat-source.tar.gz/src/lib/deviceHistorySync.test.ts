// @vitest-environment node
import { describe, expect, it } from 'vitest'
import { DeviceHistorySync, historyRecordId, type DeviceRecordReference } from './deviceHistorySync'
import type { DeviceSyncRecord, DeviceSyncScope } from './deviceSyncRecords'
import { encodeDeviceSyncPacket, parseDeviceSyncPacket, type DeviceHistoryPacket, type DeviceSyncMessage } from './deviceSyncProtocol'

const owner = 'a'.repeat(64)
const contact = 'b'.repeat(64)
const message = (id: string, createdAt = 100): DeviceSyncMessage => ({ chatId: contact, id, createdAt, author: owner, body: `Message ${id} ☕` })
function pair(initialA: DeviceSyncMessage[], initialB: DeviceSyncMessage[], since = 0, allowedWindow?: (since: number, until: number, linkId?: string) => boolean) {
  const a = new Map(initialA.map(message => [historyRecordId(message), message]))
  const b = new Map(initialB.map(message => [historyRecordId(message), message]))
  const tombstones = new Map<string, DeviceSyncMessage>()
  const queue: Array<{ to: 'a' | 'b'; packet: DeviceHistoryPacket }> = []
  const sent: DeviceHistoryPacket[] = []
  let authorized = true
  let now = 200_000
  const options = (local: Map<string, DeviceSyncMessage>, to: 'a' | 'b') => ({
    authorized: () => authorized, now: () => now, floor: () => since,
    allowsWindow: (_peer: string, since: number, until: number, linkId?: string) => to !== 'a' || !allowedWindow || allowedWindow(since, until, linkId),
    recordInventory: async (_scope: DeviceSyncScope, _since: number, _until: number, initiator: boolean, prefix: string) => [...local.values(), ...(initiator && to === 'b' ? tombstones.values() : [])].map(message => ({ id: historyRecordId(message), createdAt: message.createdAt })).filter(record => record.id.startsWith(prefix)),
    records: async (_scope: DeviceSyncScope, since: number, until: number, refs: DeviceRecordReference[]) => [...local.values()].filter(message => message.createdAt >= since && message.createdAt <= until && refs.some(ref => ref.id === historyRecordId(message))).map(message => ({ type: 'message' as const, message })),
    applyRecords: async (_peer: string, records: DeviceSyncRecord[]) => {
      for (const record of records) if (record.type === 'message' && !tombstones.has(historyRecordId(record.message))) local.set(historyRecordId(record.message), record.message)
      return records.length
    },
    send: async (_: string, packet: DeviceHistoryPacket) => {
      const decoded = parseDeviceSyncPacket(encodeDeviceSyncPacket(packet), owner) as DeviceHistoryPacket
      sent.push(decoded)
      queue.push({ to, packet: decoded })
    },
  })
  const first = new DeviceHistorySync(options(a, 'b'))
  const second = new DeviceHistorySync(options(b, 'a'))
  first.negotiate('b', since)
  second.negotiate('a', since)
  const drain = async () => {
    let count = 0
    while (queue.length) {
      if (++count > 2000) throw new Error('history did not converge')
      const { to, packet } = queue.shift()!
      await (to === 'a' ? first : second).receive(to === 'a' ? 'b' : 'a', packet)
    }
  }
  return { a, b, first, second, queue, sent, tombstones, drain,
    revoke: () => { authorized = false }, advance: () => { now += 121_000 } }
}

describe('encrypted device history reconciliation', () => {
  it('negotiates features from full handshake packets without copying their packet type', async () => {
    const p = pair([], [message('approved-old-message')])
    const request = { v: 1 as const, type: 'request' as const, rosterAt: 150, recordReconcile: 1 as const, privateEvents: 2 as const }
    const pageEnd = { ...request, type: 'pageEnd' as const, next: null, historySince: 0 }
    p.first.negotiate('b', 0, pageEnd)
    p.second.negotiate('a', 0, request)
    await p.first.startState('b')
    await p.first.start('b', 0, 149)
    await p.drain()
    await new Promise(resolve => setTimeout(resolve, 0))
    await p.drain()
    expect(p.sent.filter(packet => packet.type === 'historyOpen').map(packet => packet.scope)).toEqual(['state', 'history'])
    expect(p.sent.some(packet => ['request', 'pageEnd'].includes(packet.type))).toBe(false)
    expect([...p.a.values()].map(message => message.id)).toEqual(['approved-old-message'])
  })

  it('fetches only missing messages in both directions and repairs an offline gap after reconnect', async () => {
    const shared = Array.from({ length: 120 }, (_, i) => message(`shared-${i}`))
    const p = pair([...shared, message('only-a')], [...shared, message('only-b')])
    await p.first.start('b', 0)
    await p.second.start('a', 0)
    await p.drain()
    expect([...p.a.keys()].sort()).toEqual([...p.b.keys()].sort())
    expect(p.sent.filter(packet => packet.type === 'historyRecords').flatMap(packet => packet.records.flatMap(record => record.type === 'message' ? [record.message] : [])).map(message => message.id).sort()).toEqual(['only-a', 'only-b'])
    p.first.reset('b'); p.second.reset('a')
    p.b.set(historyRecordId(message('offline', 150)), message('offline', 150))
    p.first.negotiate('b', 0); p.second.negotiate('a', 0)
    p.sent.length = 0
    await p.first.start('b', 0); await p.drain()
    expect(p.a.size).toBe(123)
    expect(p.sent.filter(packet => packet.type === 'historyRecords').flatMap(packet => packet.records.flatMap(record => record.type === 'message' ? [record.message] : [])).map(message => message.id)).toEqual(['offline'])
  })

  it('keeps list-only pre-link history excluded while repairing newer messages', async () => {
    const p = pair([], [message('old', 90), message('new', 110)], 100)
    await p.first.start('b', 100); await p.drain()
    expect([...p.a.values()].map(message => message.id)).toEqual(['new'])
    p.first.reset('b'); p.second.reset('a')
    p.first.negotiate('b', 100); p.second.negotiate('a', 100)
    await p.first.start('b', 0); await p.drain()
    expect([...p.a.values()].map(message => message.id)).toEqual(['new'])
  })

  it.each([false, true])('repairs an advertised new message ahead of the local clock (queued: %s)', async (queued: boolean) => {
    const p = pair([], [message('new', 201)], 100)
    if (queued) await p.first.start('b', 100)
    p.first.observe('b', [201])
    await p.first.start('b', 100)
    await p.drain()
    await new Promise(resolve => setTimeout(resolve, 0))
    await p.drain()
    expect([...p.a.values()].map(message => message.id)).toEqual(['new'])
    expect(p.sent.filter(packet => packet.type === 'historyOpen').at(-1)).toMatchObject({ since: 100, until: 201 })
  })

  it('bounds advertised timestamps and preserves the exact approved initial window', async () => {
    const linkId = 'c'.repeat(64)
    const p = pair([], [message('old', 99), message('new', 201)], 0,
      (since, until, link) => since >= 100 || (since === 0 && until === 99 && link === linkId))
    p.first.observe('b', [201, 501, Infinity, NaN, -1, 201.5, Number.MAX_SAFE_INTEGER])
    await p.first.start('b', 0, 99, linkId)
    await p.drain()
    expect(p.sent.find(packet => packet.type === 'historyOpen')).toMatchObject({ since: 0, until: 99, linkId })
    expect([...p.a.values()].map(message => message.id)).toEqual(['old'])
    await p.first.start('b', 100)
    await p.drain()
    expect(p.sent.filter(packet => packet.type === 'historyOpen').at(-1)).toMatchObject({ since: 100, until: 201 })
    expect([...p.a.values()].map(message => message.id).sort()).toEqual(['new', 'old'])
  })

  it.each([false, true])('retains the approved initial window queued behind normal sync (later refresh: %s)', async (refresh: boolean) => {
    const linkId = 'c'.repeat(64)
    const p = pair([], [message('old', 99), message('new', 110)], 0,
      (since, until, link) => since >= 100 || (since === 0 && until === 99 && link === linkId))
    await p.first.start('b', 100, 200)
    await p.first.start('b', 0, 99, linkId)
    if (refresh) await p.first.start('b', 100, 200)
    await p.drain()
    await new Promise(resolve => setTimeout(resolve, 0))
    await p.drain()
    const opens = p.sent.filter(packet => packet.type === 'historyOpen')
    expect(opens).toHaveLength(2)
    expect(opens[1]).toMatchObject({ since: 0, until: 99, linkId })
    expect([...p.a.values()].map(message => message.id).sort()).toEqual(['new', 'old'])
  })

  it('does not request deleted IDs or revive them on later reconciliation', async () => {
    const removed = message('removed')
    const p = pair([], [removed, message('kept')])
    p.tombstones.set(historyRecordId(removed), removed)
    await p.first.start('b', 0); await p.drain()
    expect([...p.a.values()].map(message => message.id)).toEqual(['kept'])
    expect(p.sent.filter(packet => packet.type === 'historyNeed').flatMap(packet => packet.ids)).not.toContain(historyRecordId(removed))
  })

  it('does not advertise local tombstones when responding to the other device', async () => {
    const p = pair([], [])
    const removed = message('removed')
    p.tombstones.set(historyRecordId(removed), removed)
    await p.second.start('a', 0); await p.drain()
    expect(p.sent.some(packet => packet.type === 'historyNeed')).toBe(false)
    expect(p.sent.at(-1)?.type).toBe('historyDone')
  })

  it('withholds a message deleted after inventory without stalling other requests', async () => {
    const p = pair([], Array.from({ length: 40 }, (_, i) => message(`id-${i}`)))
    await p.first.start('b', 0)
    const open = p.queue.shift()!
    await p.second.receive('a', open.packet)
    p.b.clear()
    await p.drain()
    expect(p.a.size).toBe(0)
    expect(p.sent.at(-1)?.type).toBe('historyDone')
  })

  it('drops revoked and expired sessions before transfer', async () => {
    for (const action of ['revoke', 'advance'] as const) {
      const p = pair([], [message('secret')])
      await p.first.start('b', 0)
      const open = p.queue.shift()!
      await p.second.receive('a', open.packet)
      p[action]()
      await p.drain()
      expect(p.a.size).toBe(0)
      expect(p.sent.some(packet => packet.type === 'historyRecords')).toBe(false)
    }
  })

  it('rejects unrequested content and clears the poisoned session', async () => {
    const p = pair([], [message('expected')])
    await p.first.start('b', 0)
    const open = p.queue[0].packet
    await expect(p.first.receive('b', { v: 1, type: 'historyRecords', session: open.session, records: [{ type: 'message', message: message('injected') }], requested: [] })).rejects.toThrow('unsolicited')
    await p.drain()
    expect(p.a.size).toBe(0)
  })
})

it('reconciles unsigned contact facts with clears and keeps old peers on the legacy format', async () => {
  const { createPrivateContactSync, editPrivateContact, mergePrivateContactDocument, privateContactDocuments } = await import('nostr-social-graph/privateContactSyncV2')
  const { privateContactFacts, privateContactDocumentsFromFacts, storePrivateContactFacts, restorePrivateContactFacts } = await import('nostr-social-graph/privateContactFacts')
  const { deviceSyncRecordId } = await import('./deviceSyncRecords')
  for (const capable of [false, true]) {
    const states = [editPrivateContact(editPrivateContact(createPrivateContactSync(owner, '1'.repeat(32)), contact, {nickname:'Old',note:'Private note'}),contact,{nickname:null}),
      editPrivateContact(createPrivateContactSync(owner,'2'.repeat(32)),contact,{favorite:true})]
    states[0] = restorePrivateContactFacts(JSON.parse(JSON.stringify(storePrivateContactFacts(states[0]))),owner)
    const queue: Array<{to:number;packet:DeviceHistoryPacket}> = [], sent: DeviceHistoryPacket[] = []
    const records = (i:number): DeviceSyncRecord[] => privateContactFacts(privateContactDocuments(states[i])).map(fact => ({type:'privateContactFact',fact}))
    const peers = [0,1].map(i => new DeviceHistorySync({
      authorized: () => true, maxInventoryRecords:1,
      recordInventory: async (scope,_since,_until,_initiator,prefix) => scope === 'state' ? records(i).map(record => ({id:deviceSyncRecordId(record),createdAt:0,locator:{type:record.type,key:[]}})).filter(ref => ref.id.startsWith(prefix)) : [],
      records: async (_scope,_since,_until,refs) => records(i).filter(record => refs.some(ref => ref.id === deviceSyncRecordId(record))),
      applyRecords: async (_peer,incoming) => { for (const document of privateContactDocumentsFromFacts(incoming.flatMap(record => record.type === 'privateContactFact' ? [record.fact] : []),owner)) states[i] = mergePrivateContactDocument(states[i],document); return 0 },
      send: async (_peer,packet) => { const decoded = parseDeviceSyncPacket(encodeDeviceSyncPacket(packet),owner) as DeviceHistoryPacket; sent.push(decoded); queue.push({to:1-i,packet:decoded}) },
    }))
    peers[0].negotiate('b',0,capable ? {privateFacts:2} : {}); peers[1].negotiate('a',0,capable ? {privateFacts:2} : {})
    await peers[0].startState('b'); await peers[1].startState('a')
    for (let rounds=0; queue.length; rounds++) { expect(rounds).toBeLessThan(2000); const next=queue.shift()!; await peers[next.to].receive(next.to ? 'a':'b',next.packet) }
    const transferred = sent.flatMap(packet => packet.type === 'historyRecords' ? packet.records : [])
    if (capable) {
      expect(states[0].contacts).toEqual(states[1].contacts)
      expect(states[1].contacts[contact]).toMatchObject({nickname:{value:null,counter:2},note:{value:'Private note'},favorite:{value:true}})
      expect(transferred.length).toBeGreaterThan(0)
      expect(transferred.every(record => record.type !== 'privateContactFact' || !('sig' in record.fact))).toBe(true)
    } else expect(transferred).toEqual([])
  }
})
