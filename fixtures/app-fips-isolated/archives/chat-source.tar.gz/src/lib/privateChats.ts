import { parseLinkInviteInput } from './linkInvites'
import { migrateStoredPrivateContacts } from './privateContactMigration'
import { queuedCallWakeEnvelope, observeCallWakeInvite, acceptedCallWakeBootstrap } from './callPush'
import { get } from 'svelte/store'
import {
  AppEvent,
  CacheMode,
  type EventFilter,
} from './nostrClient'
import {
  AppKeys,
  Invite,
  INVITE_RESPONSE_KIND,
  NdrRuntime,
  buildAppKeysDeviceAuthorizationFilter,
  createDeviceLinkRequest,
  decryptInviteResponse,
  deterministicLinkInviteForDeviceLinkRequest,
  parseCompactDeviceLinkRequest,
  resolveAppKeysOwnerForDevice,
  type AppKeysManager,
  type CreatedDeviceLinkRequest,
  type DelegateManager,
  type DeviceEntry,
  type NdrRuntimeState,
  type NostrFetch,
  type NostrSubscribe,
  type NostrPublishContext,
  PAIRWISE_GROUP_DELIVERY_VERSION,
} from 'nostr-double-ratchet'
import {
  nostrClient,
  identity,
  getPrivkeyHex,
  getPrivkeyBytes,
  isLinkedDeviceLogin,
} from './identity'
import { devices } from './devices'
import { relayStore } from './relayStore'
import { DexieStorageAdapter } from './sessionManagerStorage'
import type { UnsignedEvent, VerifiedEvent } from 'nostr-tools'
import {
  getCurrentDeviceRegistrationLabels,
  getLinkedDeviceRegistrationLabels,
} from './deviceLabels'
import { createRuntimeSubscribe } from './runtimeSubscribe'
import { createRuntimePublish } from './runtimePublish'
import { rememberInviteResponse } from './inviteProvenance'
import { privateGroupRelayFetch, privateGroupRelaySubscribe } from './groupRelayPolicy'
import { notifyMessageRelayPublish } from './messageRelayStatus'
import { deleteSessionManagerValue, putSessionManagerValue } from './storage'
import { restoreSignerAuthorization } from './signerAuthorizationStorage'
import { initializeAuthorizedRuntime } from './privateRuntimeInitialization'

let runtime: NdrRuntime | null = null
let runtimeStorage: DexieStorageAdapter | null = null
let runtimePublication: ReturnType<typeof createRuntimePublish> | null = null
let runtimeOwnerPubkey: string | null = null
let runtimeCleanup: (() => void) | null = null
let previousRuntimeState: NdrRuntimeState | null = null
let rotateInvitePromise: Promise<void> | null = null
let linkedInviteRepublishTimer: ReturnType<typeof setTimeout> | null = null
let runtimeOwnerIdentityKeyHex: string | null = null
const readyDeviceRegistrations = new Set<string>()
let activeDeviceRegistration:
  | { ownerPubkey: string; promise: Promise<void> }
  | null = null

const APP_KEYS_FETCH_TIMEOUT_MS = 8000
const APP_KEYS_FAST_TIMEOUT_MS = 2000
const LINKED_INVITE_REPUBLISH_RETRY_MS = 1500
const DEVICE_LINK_TIMEOUT_MS = 120_000
const DEVICE_MANAGER_STORAGE_PREFIX = 'v1/device-manager'

export type DeviceLinkSession = {
  url: string
  stop: () => void
}

const persistCompactLinkRuntimeDelegate = async (
  localRequest: CreatedDeviceLinkRequest
): Promise<void> => {
  const invite = deterministicLinkInviteForDeviceLinkRequest(localRequest.request)
  await Promise.all([
    putSessionManagerValue(
      `${DEVICE_MANAGER_STORAGE_PREFIX}/identity-public-key`,
      localRequest.request.deviceAppKeyPubkey
    ),
    putSessionManagerValue(
      `${DEVICE_MANAGER_STORAGE_PREFIX}/identity-private-key`,
      Array.from(localRequest.deviceAppKeySecretKey)
    ),
    putSessionManagerValue(`${DEVICE_MANAGER_STORAGE_PREFIX}/invite`, invite.serialize()),
    deleteSessionManagerValue(`${DEVICE_MANAGER_STORAGE_PREFIX}/owner-pubkey`),
  ])
}

const registrationKey = (ownerPubkey: string, devicePubkey: string): string =>
  `${ownerPubkey}:${devicePubkey}`

const now = (): number => Math.round(Date.now() / 1000)

const stateIncludesDevice = (
  state: NdrRuntimeState,
  devicePubkey: string | null | undefined
): devicePubkey is string => {
  const normalizedDevice = devicePubkey?.trim().toLowerCase()
  if (!normalizedDevice) return false
  return state.registeredDevices.some(
    (device) => device.identityPubkey.trim().toLowerCase() === normalizedDevice
  )
}

const isSendReadyCurrentDevice = (ownerPubkey: string, state: NdrRuntimeState): boolean => {
  const devicePubkey = state.currentDevicePubkey
  return !!(
    devicePubkey &&
    stateIncludesDevice(state, devicePubkey) &&
    readyDeviceRegistrations.has(registrationKey(ownerPubkey, devicePubkey))
  )
}

const verifyCurrentDeviceOnRelay = async (
  currentRuntime: NdrRuntime,
  ownerPubkey: string,
  timeoutMs: number = APP_KEYS_FETCH_TIMEOUT_MS
): Promise<void> => {
  const devicePubkey = currentRuntime.getState().currentDevicePubkey
  if (!devicePubkey) {
    throw new Error('Current device pubkey not available')
  }

  const relayAppKeys = await AppKeys.waitFor(
    ownerPubkey,
    createRelayOnlySubscribe(getNostrClient()),
    timeoutMs
  )
  const relayIncludesDevice =
    relayAppKeys
      ?.getAllDevices()
      .some(
        (device) =>
          device.identityPubkey.trim().toLowerCase() ===
          devicePubkey.trim().toLowerCase()
      ) ?? false

  if (!relayIncludesDevice) {
    throw new Error(
      `Relay AppKeys for ${ownerPubkey} do not include current device ${devicePubkey}`
    )
  }

  await currentRuntime
    .refreshOwnAppKeysFromRelay(ownerPubkey, APP_KEYS_FAST_TIMEOUT_MS)
    .catch(() => {})
  readyDeviceRegistrations.add(registrationKey(ownerPubkey, devicePubkey))
}

const registerCurrentDeviceApproval = async (
  currentRuntime: NdrRuntime,
  ownerPubkey: string,
  labels?: Awaited<ReturnType<typeof getCurrentDeviceRegistrationLabels>>
): Promise<void> => {
  if (activeDeviceRegistration?.ownerPubkey === ownerPubkey) {
    return activeDeviceRegistration.promise
  }

  const promise = (async () => {
    const account = get(identity)
    // A key generated by this onboarding flow has no older roster to fetch.
    // Imported/restored identities still require the full registration lookup.
    const newAccount = account?.pubkey === ownerPubkey && account.freshlyGenerated &&
      !currentRuntime.getState().hasLocalAppKeys
    const prepared = await currentRuntime.prepareRegistration({
      ownerPubkey,
      timeoutMs: newAccount ? 0 : APP_KEYS_FETCH_TIMEOUT_MS,
      ...labels,
    })
    await currentRuntime.publishPreparedRegistration(prepared)
    if (newAccount) identity.update(current => current?.pubkey === ownerPubkey
      ? { ...current, freshlyGenerated: false } : current)
    // The signed approval is now installed locally and travels in the handshake.
    // Waiting for a server echo adds a full lookup timeout to the first send.
    readyDeviceRegistrations.add(registrationKey(ownerPubkey, prepared.newDeviceIdentity))
    void verifyCurrentDeviceOnRelay(currentRuntime, ownerPubkey).catch((error) => {
      console.warn('[privateChats] Device registration confirmation pending:', error)
    })
  })()

  activeDeviceRegistration = { ownerPubkey, promise }
  try {
    await promise
  } finally {
    if (activeDeviceRegistration?.promise === promise) {
      activeDeviceRegistration = null
    }
  }
}

const createSubscribe = (
  client: ReturnType<typeof getNostrClient>,
  cacheUsage: CacheMode = CacheMode.PARALLEL
): NostrSubscribe => {
  const subscribe = privateGroupRelaySubscribe(createRuntimeSubscribe(client, cacheUsage))
  return (filter, onEvent) => subscribe(filter, event => {
    observeCallWakeInvite(event)
    const owner = get(identity)?.pubkey
    if (owner) void import('./authorizationSync').then(({ saveAuthorizationEvent }) => saveAuthorizationEvent(owner, event, () => get(identity)?.pubkey === owner)).catch(error => console.warn('Could not save authorization', error))
    if (event.kind===INVITE_RESPONSE_KIND) {
      void rememberInviteResponse(event).then(()=>onEvent(event)).catch(error=>console.warn('Could not save invite routing evidence',error))
    } else onEvent(event)
  })
}

const createRelayOnlySubscribe = (
  client: ReturnType<typeof getNostrClient>
): NostrSubscribe => {
  return (filter, onEvent) => {
    const relayUrls = [...relayStore.getState().relays]
    const relayOptions = relayUrls.length > 0 ? { relayUrls } : {}
    const subscription = client.subscribe(
        filter as EventFilter,
        {
          closeOnEose: false,
          cacheUsage: CacheMode.ONLY_RELAY,
          skipOptimisticPublishEvent: true,
          sources: [],
          ...relayOptions,
        },
        false
      )
    subscription.on('event', (event) => {
      onEvent(event.rawEvent() as Parameters<typeof onEvent>[0])
    })
    subscription.start()
    return () => subscription.stop()
  }
}

const createSign = (client: ReturnType<typeof getNostrClient>) => {
  return async (event: UnsignedEvent): Promise<VerifiedEvent> => {
    const e = new AppEvent(client, event)
    await e.sign()
    return e.rawEvent() as VerifiedEvent
  }
}

const createRelayPublish = (client: ReturnType<typeof getNostrClient>) => {
  return async (event: VerifiedEvent, signal: AbortSignal, context?: NostrPublishContext) => {
    signal.throwIfAborted()
    let relayUrls = [...relayStore.getState().relays].map(url => new URL(url).toString())
    if (context) {
      // Group retries belong to the durable queue, which rechecks membership.
      const connected = new Set(client.runtime.getRelayStats().filter(relay => relay.connected).map(relay => relay.url))
      relayUrls = relayUrls.filter(url => connected.has(url))
      if (!relayUrls.length) throw new Error('No connected message server')
    }
    signal.throwIfAborted()
    const receipt = await client.runtime.publish(event, {
      relays: relayUrls, sources: ['fips'], requireAck: true, queue: false, localEcho: false,
    })
    // FIPS delivery is queued transport, never evidence of relay acceptance.
    return new Set(receipt.sources.filter(source => source.accepted && relayUrls.includes(source.id))
      .map(source => ({ url: source.id })))
  }
}

const reportPublicationError = (error: unknown) => {
  console.warn('[privateChats] Runtime event remains queued for retry:', error)
}

// Account cleanup may await storage before resetting managers. Stop old outgoing
// work as soon as identity changes so a late ACK cannot update the new account.
identity.subscribe((currentIdentity) => {
  if (currentIdentity?.pubkey !== runtimeOwnerPubkey) runtimePublication?.close()
})

const createFetch = (
  client: ReturnType<typeof getNostrClient>,
): NostrFetch => {
  return privateGroupRelayFetch(async (filter: Parameters<NostrFetch>[0]) => {
    const events = await client.fetchEvents(filter, {
      cacheUsage: CacheMode.PARALLEL,
    })
    return Array.from(events)
      .map((event) => event.rawEvent() as VerifiedEvent | undefined)
      .filter((event): event is VerifiedEvent => !!event)
      .map(event => { observeCallWakeInvite(event); return event })
  })
}

function getNostrClient() {
  return get(nostrClient)
}

const syncDevicesFromRuntime = (state: NdrRuntimeState): void => {
  if (state.currentDevicePubkey) {
    devices.setIdentityPubkey(state.currentDevicePubkey)
  }
  devices.setAppKeysManagerReady(state.appKeysManagerReady)
  devices.setSessionManagerReady(state.sessionManagerReady)
  devices.setHasLocalAppKeys(state.hasLocalAppKeys)
  devices.setRegisteredDevices(state.registeredDevices, state.lastAppKeysCreatedAt)
}

const republishInviteWithRetry = async (reason: string): Promise<void> => {
  await republishInvite()

  if (linkedInviteRepublishTimer) {
    clearTimeout(linkedInviteRepublishTimer)
  }
  linkedInviteRepublishTimer = setTimeout(() => {
    linkedInviteRepublishTimer = null
    void republishInvite().catch((e) => {
      console.warn(`[privateChats] Deferred invite republish failed (${reason}):`, e)
    })
  }, LINKED_INVITE_REPUBLISH_RETRY_MS)
}

const privateRuntimeMigration = new WeakMap<NdrRuntime, Promise<void>>()
const privateRuntimeInitialization = new WeakMap<NdrRuntime, Promise<void>>()
const initializePrivateRuntime = async (instance: NdrRuntime, owner: string) => {
  let ready = privateRuntimeInitialization.get(instance)
  if (!ready) {
    ready = (async () => {
      let migrated = privateRuntimeMigration.get(instance)
      if (!migrated) {
        migrated = (async () => {
          await migrateStoredPrivateContacts(owner)
          await instance.retireLegacyPrivateContactSync(owner)
        })()
        privateRuntimeMigration.set(instance, migrated)
        void migrated.catch(() => privateRuntimeMigration.delete(instance))
      }
      await migrated
      const authorized = () => get(identity)?.pubkey === owner && runtime === instance
      if (!authorized()) throw new Error('Account changed')
      await initializeAuthorizedRuntime(instance, owner, async () => {
        if (isLinkedDeviceLogin()) await restoreSignerAuthorization(instance, owner)
        const { restoreAuthorizationProjections } = await import('./authorizationSync')
        await restoreAuthorizationProjections(owner, authorized)
        if (!authorized()) throw new Error('Account changed')
      })
    })()
    privateRuntimeInitialization.set(instance, ready)
    void ready.catch(() => privateRuntimeInitialization.delete(instance))
  }
  await ready
  if (get(identity)?.pubkey !== owner) throw new Error('Account changed')
}

const getRuntime = (): NdrRuntime => {
  const ownerIdentityKeyHex = getPrivkeyHex()
  const ownerPubkey = get(identity)?.pubkey
  if (!ownerPubkey) throw new Error('Private messaging requires an identity')

  if (
    runtime &&
    runtimeOwnerIdentityKeyHex === ownerIdentityKeyHex &&
    runtimeOwnerPubkey === ownerPubkey
  ) {
    return runtime
  }

  runtimeStorage?.close()
  runtimeStorage = null
  runtimePublication?.close()
  runtimePublication = null
  runtimeCleanup?.()
  runtimeCleanup = null
  runtime?.close()
  runtime = null
  previousRuntimeState = null
  runtimeOwnerIdentityKeyHex = ownerIdentityKeyHex
  readyDeviceRegistrations.clear()
  activeDeviceRegistration = null

  const client = getNostrClient()
  const ownerIdentityKey = getPrivkeyBytes()
  const sign = createSign(client)
  const storage = new DexieStorageAdapter(ownerPubkey)
  runtimeStorage = storage
  const publication = createRuntimePublish({
    storage,
    owner: ownerPubkey,
    publish: createRelayPublish(client),
    subscribeConnected: onChange => relayStore.subscribe(state => onChange(
      [...state.statuses].filter(([, status]) => status === 'connected').map(([url]) => url)
    )),
    onAcceptedRelays: notifyMessageRelayPublish,
    onAcceptedEvent: acceptedCallWakeBootstrap,
    resolveContext: async innerEventId => {
      const { db } = await import('./storage')
      const message = await db.messages.get(innerEventId)
      if (!message?.isMine) return
      return message.sessionId.startsWith('group:') ? { groupId: message.sessionId.slice(6) }
        : { recipientOwnerPubkey: message.sessionId, createdAt: Math.floor(message.timestamp / 1000) }
    },
    canPublish: async context => {
      if (context.recipientOwnerPubkey) {
        const { privateDirectPublicationPolicy } = await import('./privateStateStore')
        const direct=await privateDirectPublicationPolicy(ownerPubkey, context.recipientOwnerPubkey, context.createdAt)
        if (direct !== true || !context.groupId) return direct
      }
      const { groupId } = context
      if (!groupId) return false
      const { groups, canSendToGroup } = await import('./groups')
      const { db } = await import('./storage')
      const stored = get(groups).get(groupId) ?? await db.groups.get(groupId)
      if (context.recipientOwnerPubkey && !stored?.members.includes(context.recipientOwnerPubkey)) return false
      return canSendToGroup(stored, ownerPubkey)
    },
    onError: reportPublicationError,
  })
  runtimePublication = publication
  runtimeOwnerPubkey = ownerPubkey
  if (PAIRWISE_GROUP_DELIVERY_VERSION !== 1) throw new Error('Private group delivery is required')
  runtime = new NdrRuntime({
    nostrSubscribe: createSubscribe(client),
    nostrSign: sign,
    nostrEnqueue: async (event, innerEventId, context) => {
      const { saveAuthorizationEvent } = await import('./authorizationSync')
      await saveAuthorizationEvent(ownerPubkey, event, () => get(identity)?.pubkey === ownerPubkey)
      await publication.enqueue(event, innerEventId, context)
      if (get(identity)?.pubkey === ownerPubkey) {
        void queuedCallWakeEnvelope(event, innerEventId).catch(error => console.warn('Call wake could not be sent', error))
      }
    },
    nostrPublish: async (event, innerEventId, context) => {
      const signed = 'sig' in event && event.sig
        ? event as VerifiedEvent
        : await sign(event)
      const published = await publication.publish(signed, innerEventId, context)
      const { saveAuthorizationEvent } = await import('./authorizationSync')
      await saveAuthorizationEvent(ownerPubkey, signed, () => get(identity)?.pubkey === ownerPubkey)
      return published
    },
    onPublishError: ({ error }) => reportPublicationError(error),
    nostrFetch: createFetch(client),
    storage,
    appKeysFetchTimeoutMs: APP_KEYS_FETCH_TIMEOUT_MS,
    appKeysFastTimeoutMs: APP_KEYS_FAST_TIMEOUT_MS,
    ...(ownerIdentityKey ? { ownerIdentityKey } : {}),
  })
  runtimeOwnerIdentityKeyHex = ownerIdentityKeyHex

  runtimeCleanup = runtime.onStateChange((state) => {
    const previousState = previousRuntimeState
    syncDevicesFromRuntime(state)

    if (
      isLinkedDeviceLogin() &&
      previousState &&
      !previousState.isCurrentDeviceRegistered &&
      state.isCurrentDeviceRegistered
    ) {
      void republishInviteWithRetry('linked device registration').catch((err) => {
        console.warn('[privateChats] Republish invite after linked registration failed:', err)
      })
    }

    previousRuntimeState = state
  })
  publication.start()
  return runtime
}

export function cancelDirectPublications(owner: string, recipient: string): void {
  if (runtimeOwnerPubkey === owner) runtimePublication?.cancelDirect(recipient)
}

export function cancelGroupPublications(groupId: string): void {
  runtimePublication?.cancelGroup(groupId)
}

export const getNdrRuntime = (): NdrRuntime => {
  return getRuntime()
}


export const initAppKeysManager = async (): Promise<void> => {
  await getRuntime().initAppKeysManager()
}

export const initDelegateManager = async (): Promise<void> => {
  await getRuntime().initDelegateManager()
}

export const initNdrRuntime = async (ownerPubkey: string): Promise<void> => {
  await initializePrivateRuntime(getRuntime(), ownerPubkey)
}

export const waitForNdrRuntime = async (): Promise<NdrRuntime> => {
  const currentRuntime = getRuntime()
  const ownerPubkey = currentRuntime.getState().ownerPubkey || get(identity)?.pubkey
  if (!ownerPubkey) {
    throw new Error('NdrRuntime owner not initialized')
  }
  await initializePrivateRuntime(currentRuntime, ownerPubkey)
  return currentRuntime
}

export const waitForSendReadyRuntime = async (): Promise<NdrRuntime> => {
  await ensureDeviceRegistered()
  return waitForNdrRuntime()
}

export const preparePeerNdrRuntime = async (
  recipientPubkey: string
): Promise<NdrRuntime> => {
  const owner = get(identity)?.pubkey
  if (owner && await (await import('./privateStateStore')).isPrivatelyBlocked(owner, recipientPubkey)) throw new Error('Unblock this person to send a message.')
  const currentRuntime = await waitForSendReadyRuntime()
  await currentRuntime.setupUser(recipientPubkey).catch((e) => {
    console.warn(
      '[privateChats] Failed to prepare peer runtime user setup:',
      recipientPubkey,
      e
    )
  })
  return currentRuntime
}

export const getDelegateManager = (): DelegateManager => {
  const manager = getRuntime().getDelegateManager()
  if (!manager) throw new Error('DelegateManager not initialized')
  return manager
}

export const getAppKeysManager = (): AppKeysManager => {
  const manager = getRuntime().getAppKeysManager()
  if (!manager) throw new Error('AppKeysManager not initialized')
  return manager
}

const refreshRestoredDeviceRegistration = async (
  currentRuntime: NdrRuntime,
  ownerPubkey: string
): Promise<void> => {
  const state = currentRuntime.getState()
  if (!stateIncludesDevice(state, state.currentDevicePubkey)) return

  // Cached devices can predate the current registration format. Restore
  // receiving capability on startup, without waiting for an outgoing message.
  const published = await AppKeys.waitFor(
    ownerPubkey,
    createRelayOnlySubscribe(getNostrClient()),
    APP_KEYS_FETCH_TIMEOUT_MS
  )
  if (published) {
    // An existing current roster is authoritative, including revocations.
    await currentRuntime.refreshOwnAppKeysFromRelay(ownerPubkey, APP_KEYS_FAST_TIMEOUT_MS)
    if (published.getAllDevices().some(device => device.identityPubkey === state.currentDevicePubkey)) {
      readyDeviceRegistrations.add(registrationKey(ownerPubkey, state.currentDevicePubkey))
    }
    return
  }
  const labels = await getCurrentDeviceRegistrationLabels()
  await registerCurrentDeviceApproval(currentRuntime, ownerPubkey, labels)
}

export const initMultiDevice = async (ownerPubkey: string): Promise<void> => {

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, ownerPubkey)

  let linkedDeviceAuthorized = currentRuntime.getState().isCurrentDeviceRegistered
  if (isLinkedDeviceLogin() && !linkedDeviceAuthorized) {
    try {
      await currentRuntime.refreshOwnAppKeysFromRelay(
        ownerPubkey,
        APP_KEYS_FETCH_TIMEOUT_MS
      )
      linkedDeviceAuthorized = currentRuntime.getState().isCurrentDeviceRegistered
    } catch (e) {
      console.warn('[privateChats] Linked-device AppKeys backfill failed:', e)
    }
    if (!linkedDeviceAuthorized) {
      console.warn(
        '[privateChats] Linked device is waiting for owner AppKeys authorization.'
      )
    }
  }

  try {
    if (!isLinkedDeviceLogin() || linkedDeviceAuthorized) {
      if (isLinkedDeviceLogin()) {
        await republishInviteWithRetry('linked device init')
      } else {
        await refreshRestoredDeviceRegistration(currentRuntime, ownerPubkey)
        await republishInvite()
      }
    }
  } catch (e) {
    console.warn('[privateChats] Restore device registration or invite failed:', e)
  }
}

export const hasLocalAppKeys = (): boolean => {
  return getRuntime().getState().hasLocalAppKeys
}

export const registerDevice = async (): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    throw new Error('Linked devices cannot register other devices')
  }

  const ownerPubkey = get(identity)?.pubkey
  if (!ownerPubkey) {
    throw new Error('Owner pubkey not available')
  }

  const labels = await getCurrentDeviceRegistrationLabels()

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, ownerPubkey)
  await registerCurrentDeviceApproval(currentRuntime, ownerPubkey, labels)
}

export const registerLinkedDevice = async (identityPubkey: string): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    throw new Error('Linked devices cannot register other devices')
  }

  const ownerPubkey = get(identity)?.pubkey
  if (!ownerPubkey) {
    throw new Error('Owner pubkey not available')
  }

  const labels = await getLinkedDeviceRegistrationLabels()

  await initializePrivateRuntime(getRuntime(), ownerPubkey)
  await getRuntime().registerDeviceIdentity({
    ownerPubkey,
    identityPubkey,
    timeoutMs: APP_KEYS_FETCH_TIMEOUT_MS,
    ...labels,
  })
}

export const startDeviceLink = async (
  onAccepted: (ownerPubkey: string) => void | Promise<void>
): Promise<DeviceLinkSession> => {

  const labels = await getCurrentDeviceRegistrationLabels()
  const localRequest = createDeviceLinkRequest({
    requestedAt: now(),
    ...labels,
  })
  await persistCompactLinkRuntimeDelegate(localRequest)
  const subscribe = createRelayOnlySubscribe(getNostrClient())
  let stopped = false
  let completed = false
  let timeout: ReturnType<typeof setTimeout>

  const invite = deterministicLinkInviteForDeviceLinkRequest(localRequest.request)
  let authorization: { owner: string; entries: DeviceEntry[] } | undefined
  let approver: { owner: string; device: string } | undefined
  const finish = async () => {
    if (stopped || completed || !authorization || !approver || authorization.owner !== approver.owner ||
      !authorization.entries.some(device => device.identityPubkey === approver!.device)) return
    const own = authorization.entries.find(device => device.identityPubkey === localRequest.request.deviceAppKeyPubkey)
    if (!own) return
    completed = true
    const { saveDeviceHistoryPair } = await import('./deviceHistoryPolicy')
    await saveDeviceHistoryPair(authorization.owner, own.identityPubkey, { peer: approver.device, linkAt: own.createdAt, linkId: localRequest.request.requestPubkey,
      since: null, role: 'inbound', complete: false })
    clearTimeout(timeout)
    unsubscribe()
    await onAccepted(authorization.owner)
  }
  const stopAuthorization = subscribe(
    buildAppKeysDeviceAuthorizationFilter(localRequest.request.deviceAppKeyPubkey) as EventFilter,
    async event => {
      if (stopped || completed) return
      try {
        const verified = event as unknown as VerifiedEvent
        const owner = resolveAppKeysOwnerForDevice(verified, localRequest.request.deviceAppKeyPubkey)
        if (!owner) return
        authorization = { owner, entries: AppKeys.fromEvent(verified).getAllDevices() }
        await finish()
      } catch { /* Ignore unrelated or invalid authorization. */ }
    },
  )
  const stopResponse = subscribe({ kinds: [INVITE_RESPONSE_KIND], '#p': [invite.inviterEphemeralPublicKey] } as EventFilter,
    async event => {
      if (stopped || completed) return
      try {
        const response = await decryptInviteResponse({ envelopeContent: event.content, envelopeSenderPubkey: event.pubkey,
          inviterEphemeralPrivateKey: invite.inviterEphemeralPrivateKey!, inviterPrivateKey: localRequest.deviceAppKeySecretKey,
          sharedSecret: invite.sharedSecret })
        approver = { owner: response.ownerPublicKey || response.inviteeIdentity, device: response.inviteeIdentity }
        await finish()
      } catch { /* Only an authenticated invite response can identify the approving device. */ }
    })
  const unsubscribe = () => { stopAuthorization(); stopResponse() }

  timeout = setTimeout(() => {
    stopped = true
    unsubscribe()
  }, DEVICE_LINK_TIMEOUT_MS)

  return {
    url: localRequest.code,
    stop: () => {
      stopped = true
      clearTimeout(timeout)
      unsubscribe()
    },
  }
}

export const createLinkInvite = async (): Promise<Invite> => {
  await initDelegateManager()
  return getRuntime().createLinkInvite(get(identity)?.pubkey)
}

export const buildLinkInviteUrl = (
  invite: Invite,
  root: string,
  ownerPubkey?: string
): string => {
  const data: Record<string, string | number> = {
    version: 2,
    inviter: invite.inviter,
    ephemeralKey: invite.inviterEphemeralPublicKey,
    sharedSecret: invite.sharedSecret,
    purpose: 'link',
  }
  if (ownerPubkey) {
    data.owner = ownerPubkey
  }
  const url = new URL(root)
  url.hash = `/invite/${encodeURIComponent(JSON.stringify(data))}`
  return url.toString()
}

export const listenForLinkInviteAcceptance = (
  invite: Invite,
  onAccepted: (ownerPubkey: string) => void
): (() => void) => {
  const delegateManager = getDelegateManager()
  if (!invite.inviterEphemeralPrivateKey) {
    throw new Error('Invite missing ephemeral private key')
  }

  const inviterPrivateKey = delegateManager.getIdentityKey()
  const subscribe = createSubscribe(getNostrClient())

  return subscribe(
    {
      kinds: [INVITE_RESPONSE_KIND],
      '#p': [invite.inviterEphemeralPublicKey],
    } as EventFilter,
    async (event) => {
      try {
        if (invite.maxUses && invite.usedBy.length >= invite.maxUses) {
          return
        }

        const decrypted = await decryptInviteResponse({
          envelopeContent: event.content,
          envelopeSenderPubkey: event.pubkey,
          inviterEphemeralPrivateKey: invite.inviterEphemeralPrivateKey!,
          inviterPrivateKey,
          sharedSecret: invite.sharedSecret,
        })

        invite.usedBy.push(decrypted.inviteeIdentity)
        onAccepted(decrypted.ownerPublicKey || decrypted.inviteeIdentity)
      } catch {
        // Ignore invalid responses.
      }
    }
  )
}

export const ensureDeviceRegistered = async (): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    return
  }

  const ownerPubkey =
    getRuntime().getState().ownerPubkey || get(identity)?.pubkey
  if (!ownerPubkey) {
    throw new Error('Owner pubkey not available')
  }

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, ownerPubkey)

  let state = currentRuntime.getState()
  // Existing signed authorization remains usable offline. The NDR queue keeps
  // encrypted envelopes durable; receivers still enforce their current rosters.
  // This never grants a new device or treats cache/peer traffic as relay evidence.
  if (typeof navigator !== 'undefined' && !navigator.onLine &&
    state.isCurrentDeviceRegistered && stateIncludesDevice(state, state.currentDevicePubkey)) return
  if (!isSendReadyCurrentDevice(ownerPubkey, state)) {
    if (stateIncludesDevice(state, state.currentDevicePubkey)) {
      try {
        await verifyCurrentDeviceOnRelay(
          currentRuntime,
          ownerPubkey,
          APP_KEYS_FAST_TIMEOUT_MS
        )
        state = currentRuntime.getState()
      } catch {
        readyDeviceRegistrations.delete(
          registrationKey(ownerPubkey, state.currentDevicePubkey!)
        )
      }
    }
  }

  if (!isSendReadyCurrentDevice(ownerPubkey, state)) {
    const labels = await getCurrentDeviceRegistrationLabels()
    await registerCurrentDeviceApproval(currentRuntime, ownerPubkey, labels)
  }
  void republishInvite().catch((e) => {
    console.warn('[privateChats] Invite republish after registration failed:', e)
  })
}

export const revokeDevice = async (identityPubkey: string): Promise<void> => {
  await revokeDevices([identityPubkey])
}

export const revokeDevices = async (identityPubkeys: string[]): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    throw new Error('Linked devices cannot revoke devices')
  }

  const ownerPubkey =
    getRuntime().getState().ownerPubkey || get(identity)?.pubkey
  if (!ownerPubkey) {
    throw new Error('Owner pubkey not available')
  }

  const uniquePubkeys = Array.from(
    new Set(identityPubkeys.map((pubkey) => pubkey.trim()).filter(Boolean))
  )
  if (uniquePubkeys.length === 0) return

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, ownerPubkey)

  const currentDevicePubkey = currentRuntime.getState().currentDevicePubkey
  const revocablePubkeys = uniquePubkeys.filter(
    (pubkey) => pubkey !== currentDevicePubkey
  )
  if (revocablePubkeys.length === 0) return

  const relayAppKeys = await currentRuntime.resolveBaseAppKeys(
    ownerPubkey,
    APP_KEYS_FAST_TIMEOUT_MS
  )
  const localAppKeys = currentRuntime.getAppKeysManager()?.getAppKeys()
  const baseAppKeys =
    localAppKeys &&
    localAppKeys.getAllDevices().length > relayAppKeys.getAllDevices().length
      ? localAppKeys
      : relayAppKeys
  const nextAppKeys = new AppKeys(
    baseAppKeys.getAllDevices(),
    baseAppKeys.getAllDeviceLabels()
  )
  const originalDevices = nextAppKeys.getAllDevices()
  const originalDevicePubkeys = new Set(originalDevices.map((device) => device.identityPubkey))

  for (const identityPubkey of revocablePubkeys) {
    nextAppKeys.removeDevice(identityPubkey)
  }

  const nextDevices = nextAppKeys.getAllDevices()
  if (
    nextDevices.length === originalDevices.length ||
    revocablePubkeys.every((pubkey) => !originalDevicePubkeys.has(pubkey))
  ) {
    return
  }

  await currentRuntime.publishPreparedRevocation({
    ownerPubkey,
    appKeys: nextAppKeys,
    devices: nextDevices,
    revokedIdentity: revocablePubkeys[0],
  })
}

export const startAppKeysSubscription = (ownerPubkey: string): void => {
  getRuntime().startAppKeysSubscription(ownerPubkey)
}

export const stopAppKeysSubscription = (): void => {
  runtime?.stopAppKeysSubscription()
}

export const resetManagers = (): void => {
  // In-flight roster callbacks can finish after the database is cleared.
  // Retire their storage before shutting down subscriptions and clearing data.
  runtimeStorage?.close()
  runtimeStorage = null
  if (linkedInviteRepublishTimer) {
    clearTimeout(linkedInviteRepublishTimer)
    linkedInviteRepublishTimer = null
  }
  runtimePublication?.close()
  runtimePublication = null
  runtimeCleanup?.()
  runtimeCleanup = null
  runtime?.close()
  runtime = null
  previousRuntimeState = null
  rotateInvitePromise = null
  runtimeOwnerIdentityKeyHex = null
  runtimeOwnerPubkey = null
  devices.reset()
  readyDeviceRegistrations.clear()
  activeDeviceRegistration = null
}

export const republishInvite = async (): Promise<void> => {
  await getRuntime().republishInvite()
}

export const rotateDeviceInvite = async (): Promise<void> => {
  if (rotateInvitePromise) return rotateInvitePromise

  rotateInvitePromise = (async () => {
    await getRuntime().rotateInvite()
  })().finally(() => {
    rotateInvitePromise = null
  })

  return rotateInvitePromise
}

export const getRegisteredDevices = (): DeviceEntry[] => {
  return getRuntime().getState().registeredDevices
}

export const acceptDeviceLink = async (input: string, historyChoice: import('./deviceHistoryPolicy').DeviceHistoryChoice = 'chats'): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    throw new Error('Linked devices cannot add devices')
  }

  const currentIdentity = get(identity)
  if (!currentIdentity?.pubkey) throw new Error('Sign in before linking a device.')
  const parsed = parseCompactDeviceLinkRequest(input)
  const now = Math.floor(Date.now() / 1000)
  if (parsed?.requestedAt && (parsed.requestedAt < now - 180 || parsed.requestedAt > now + 300)) throw new Error('This device link has expired. Create a new one.')
  const ndrInvite = parsed ? deterministicLinkInviteForDeviceLinkRequest(parsed) : parseLinkInviteInput(input, currentIdentity.pubkey)
  if (!ndrInvite) throw new Error('Invalid device link. Copy a new link from your other device.')
  const target = parsed?.deviceAppKeyPubkey ?? ndrInvite.inviter
  const linkId = parsed?.requestPubkey ?? ndrInvite.inviterEphemeralPublicKey

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, currentIdentity.pubkey)
  const parsedLabels = parsed as typeof parsed & { deviceLabel?: string; clientLabel?: string }
  const labels = await getLinkedDeviceRegistrationLabels({
    deviceLabel: parsedLabels?.deviceLabel,
    clientLabel: parsedLabels?.clientLabel,
  })
  const preparedRegistration = await currentRuntime.prepareRegistrationForIdentity({
    ownerPubkey: currentIdentity.pubkey,
    identityPubkey: target,
    timeoutMs: 0,
    ...labels,
  })
  const { saveDeviceHistoryPair } = await import('./deviceHistoryPolicy')
  const linkAt = preparedRegistration.devices.find(device => device.identityPubkey === target)?.createdAt
  const local = currentRuntime.getState().currentDevicePubkey
  if (!linkAt || !local) throw new Error('Device approval is not ready')
  await saveDeviceHistoryPair(currentIdentity.pubkey, local, { peer: target, linkAt, linkId,
    since: historyChoice === 'history' ? 0 : linkAt, role: 'outbound', complete: historyChoice === 'chats' })
  await currentRuntime.publishPreparedRegistration(preparedRegistration)
  await currentRuntime.acceptLinkInvite(ndrInvite, currentIdentity.pubkey)
}

export const acceptLinkInvite = async (invite: Invite): Promise<void> => {
  if (isLinkedDeviceLogin()) {
    throw new Error('Linked devices cannot accept link invites')
  }

  const currentIdentity = get(identity)
  if (!currentIdentity?.pubkey) {
    throw new Error('Owner pubkey not available')
  }
  if (invite.ownerPubkey && invite.ownerPubkey !== currentIdentity.pubkey) {
    throw new Error('Link invite is for a different account')
  }

  const currentRuntime = getRuntime()
  await initializePrivateRuntime(currentRuntime, currentIdentity.pubkey)
  await currentRuntime.acceptLinkInvite(invite, currentIdentity.pubkey)
}
