vi.mock('./privateContactMigration', () => ({ migrateStoredPrivateContacts: vi.fn(async () => {}) }))
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  owner: 'a'.repeat(64), device: 'b'.repeat(64), linked: false,
  waitFor: vi.fn(), register: vi.fn(), refresh: vi.fn(), invite: vi.fn(),
  prepare: vi.fn(),
  restoreAuthorization: vi.fn(async () => {}),
  state: {} as Record<string, unknown>,
}))
vi.mock('nostr-double-ratchet', async (original: <T>() => Promise<T>) => {
  const actual = await original<typeof import('nostr-double-ratchet')>()
  return { ...actual,
    AppKeys: class extends actual.AppKeys { static waitFor = mocks.waitFor },
    NdrRuntime: class {
      getState() { return mocks.state }
      retireLegacyPrivateContactSync = vi.fn().mockResolvedValue(undefined)
      initManagers = vi.fn().mockResolvedValue(undefined)
      initSessionManager = vi.fn().mockResolvedValue({ getKnownAppKeysSnapshots: () => [] })
      initForOwner = vi.fn().mockResolvedValue(undefined)
      prepareRegistration = mocks.prepare
      publishPreparedRegistration = mocks.register
      refreshOwnAppKeysFromRelay = mocks.refresh
      republishInvite = mocks.invite
      onStateChange() { return () => {} }
      close() {}
    },
  }
})
vi.mock('./identity', async () => {
  const { writable } = await import('svelte/store')
  return { nostrClient: writable({ pool: { connectedRelays: () => [{}] } }),
    identity: writable({ pubkey: mocks.owner }), getPrivkeyHex: () => '1'.repeat(64),
    getPrivkeyBytes: () => new Uint8Array(32).fill(1), isLinkedDeviceLogin: () => mocks.linked }
})
vi.mock('./devices', () => ({ devices: { reset: vi.fn() } }))
vi.mock('./relayStore', () => ({ relayStore: { getState: () => ({ relays: [] }) } }))
vi.mock('./sessionManagerStorage', () => ({ DexieStorageAdapter: class { close() {} } }))
vi.mock('./deviceLabels', () => ({ getCurrentDeviceRegistrationLabels: async () => ({}), getLinkedDeviceRegistrationLabels: async () => ({}) }))
vi.mock('./runtimeSubscribe', () => ({ createRuntimeSubscribe: vi.fn() }))
vi.mock('./runtimePublish', () => ({ createRuntimePublish: () => ({ start() {}, close() {}, enqueue: vi.fn(), publish: vi.fn() }) }))
vi.mock('./messageRelayStatus', () => ({ notifyMessageRelayPublish: vi.fn() }))
vi.mock('./nostrPubsubRuntime', () => ({ publishNostrPubsub: vi.fn() }))
vi.mock('./storage', () => ({ deleteSessionManagerValue: vi.fn(), putSessionManagerValue: vi.fn(), getSessionManagerValue: vi.fn(async () => undefined) }))

import { initMultiDevice, resetManagers, waitForNdrRuntime, waitForSendReadyRuntime, ensureDeviceRegistered } from './privateChats'
import { identity } from './identity'

const roster = (devices: string[]) => ({ getAllDevices: () => devices.map(identityPubkey => ({ identityPubkey, createdAt: 1 })) })

beforeEach(() => {
  vi.clearAllMocks()
  mocks.linked = false
  identity.set({ pubkey: mocks.owner, displayName: null, isNip07: false })
  mocks.state = { ownerPubkey: mocks.owner, currentDevicePubkey: mocks.device,
    registeredDevices: [{ identityPubkey: mocks.device, createdAt: 1 }], isCurrentDeviceRegistered: true }
  mocks.register.mockResolvedValue(undefined)
  mocks.prepare.mockResolvedValue({ newDeviceIdentity: mocks.device })
  mocks.refresh.mockResolvedValue(undefined)
  mocks.invite.mockResolvedValue(undefined)
})
afterEach(() => { resetManagers(); vi.restoreAllMocks() })

it.each([true, false])('only newly generated identities skip the absent roster lookup (%s)', async (freshlyGenerated: boolean) => {
  mocks.state.registeredDevices = []
  mocks.state.hasLocalAppKeys = false
  identity.update(account => ({ ...account!, freshlyGenerated }))
  mocks.waitFor.mockReturnValue(new Promise(() => {}))
  await ensureDeviceRegistered()
  expect(mocks.prepare).toHaveBeenCalledWith(expect.objectContaining({ timeoutMs: freshlyGenerated ? 0 : 8000 }))
  expect(mocks.register).toHaveBeenCalledOnce()
})

describe('restored device registration on startup', () => {
  it('republishes a cached registration missing from current server records without sending a message', async () => {
    mocks.waitFor.mockResolvedValueOnce(null).mockResolvedValueOnce(roster([mocks.device]))
    await initMultiDevice(mocks.owner)
    expect(mocks.register).toHaveBeenCalledOnce()
    expect(mocks.waitFor).toHaveBeenCalledTimes(2)
    expect(mocks.invite).toHaveBeenCalledOnce()
  })

  it('leaves an existing current registration alone', async () => {
    mocks.waitFor.mockResolvedValue(roster([mocks.device]))
    await initMultiDevice(mocks.owner)
    expect(mocks.waitFor).toHaveBeenCalledOnce()
    expect(mocks.register).not.toHaveBeenCalled()
  })

  it('does not re-register a device omitted from a current server roster', async () => {
    mocks.waitFor.mockResolvedValue(roster([]))
    await initMultiDevice(mocks.owner)
    expect(mocks.refresh).toHaveBeenCalledOnce()
    expect(mocks.register).not.toHaveBeenCalled()
  })

  it('does not register a previously unregistered device or a linked device', async () => {
    mocks.state.registeredDevices = []
    mocks.state.isCurrentDeviceRegistered = false
    await initMultiDevice(mocks.owner)
    expect(mocks.waitFor).not.toHaveBeenCalled()
    resetManagers()
    mocks.linked = true
    mocks.state.isCurrentDeviceRegistered = true
    await initMultiDevice(mocks.owner)
    expect(mocks.register).not.toHaveBeenCalled()
  })
})

it('can send after signing device approval while server confirmation is still pending', async () => {
  mocks.state.registeredDevices = []
  mocks.state.isCurrentDeviceRegistered = false
  mocks.waitFor.mockReturnValue(new Promise(() => {}))
  await Promise.race([
    waitForSendReadyRuntime(),
    new Promise((_, reject) => setTimeout(() => reject(new Error('Send waited for server confirmation')), 100)),
  ])
  expect(mocks.register).toHaveBeenCalledOnce()
})


it('keeps sending blocked when preparing the signed approval fails', async () => {
  mocks.state.registeredDevices = []
  mocks.state.isCurrentDeviceRegistered = false
  mocks.register.mockRejectedValueOnce(new Error('Signing approval failed'))
  await expect(waitForSendReadyRuntime()).rejects.toThrow('Signing approval failed')
  expect(mocks.waitFor).not.toHaveBeenCalled()
})

it('uses only an already authorized device to enqueue offline after restart', async () => {
  vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(false)
  await ensureDeviceRegistered()
  expect(mocks.register).not.toHaveBeenCalled()
  expect(mocks.waitFor).not.toHaveBeenCalled()
})
it('does not turn missing offline authorization into a grant', async () => {
  vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(false)
  mocks.state.registeredDevices = []
  mocks.state.isCurrentDeviceRegistered = false
  mocks.register.mockRejectedValue(new Error('No message server accepted authorization'))
  await expect(ensureDeviceRegistered()).rejects.toThrow('No message server accepted authorization')
})
it('keeps concurrent runtime callers behind durable authorization restoration', async () => {
  mocks.state.sessionManagerReady = true
  let finish!: () => void
  mocks.restoreAuthorization.mockReturnValueOnce(new Promise<void>(resolve => { finish = resolve }))
  let ready = false
  const first = waitForNdrRuntime().then(() => { ready = true })
  const second = waitForNdrRuntime()
  await vi.waitFor(() => expect(mocks.restoreAuthorization).toHaveBeenCalledOnce())
  expect(ready).toBe(false)
  finish()
  await Promise.all([first, second])
  expect(ready).toBe(true)
  expect(mocks.restoreAuthorization).toHaveBeenCalledOnce()
})
vi.mock('./authorizationSync', () => ({ restoreAuthorizationProjections: mocks.restoreAuthorization, saveAuthorizationEvent: async () => true }))
