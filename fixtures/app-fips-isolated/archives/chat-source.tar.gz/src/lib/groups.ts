import { parseSerializedGroupRuntimeRumor } from './groupWake'
import { acceptChat, groupRequestAccepted, loadMessageRequestDecisions, messageRequests } from './messageRequests'
import { restoreStoredRequestAcceptance, restoreOwnReactionAcceptance } from './requestActivity'
import { saveAuthorizationEvent } from './authorizationSync'
import { saveProcessedEvent } from './storage'
import { sendOwnReadState, applyOwnReadTag } from './privateStateControl'
import { privateHistoryAllowed } from './privateStateStore'
import { MESSAGE_EDIT_KIND, MESSAGE_DELETE_KIND, buildMessageMutation, captureMessageMutation, sendMessageMutation, editableMessage, messageMutationFields } from './messageMutations'
import { withDeviceControlClock } from './deviceSyncRecordStore'
import { reactionControl } from './deviceSyncRecords'
import { captureReaction, controlClock, applyGroupSettingsRecord, persistMessageWithReactions, restoreGroupSettings } from './deviceSyncRecordApply'
import { writable, get } from 'svelte/store'
import {
  buildGroupRosterFactEvent,
  CHAT_MESSAGE_KIND, CHAT_SETTINGS_KIND, REACTION_KIND, RECEIPT_KIND, TYPING_KIND,
  GROUP_ROSTER_FACT_KIND,
  GROUP_ROSTER_FACT_TYPE,
  GROUP_SENDER_KEY_DISTRIBUTION_KIND,
  isGroupRosterFactEvent,
  parseGroupRosterFactEvent,
  parseGroupRosterFactRumor,
  type GroupData,
  type GroupMetadata,
  type GroupRosterFact,
  type GroupRosterFactRumor,
  isGroupAdmin,
  createGroupData,
  validateMetadataUpdate,
  validateMetadataCreation,
  applyMetadataUpdate,
  addGroupMember as libAddMember,
  removeGroupMember as libRemoveMember,
  updateGroupData,
  addGroupAdmin as libAddAdmin,
  removeGroupAdmin as libRemoveAdmin,
  getExpirationTimestampSeconds,
} from 'nostr-double-ratchet'
import type { Rumor, OnEventMeta } from 'nostr-double-ratchet'
import { AppEvent } from './nostrClient'
import { getPubkey, identity, nostrClient } from './identity'
import { devices } from './devices'
import { chats, type ChatMessage } from './chat'
import {
  cancelGroupPublications,
  getNdrRuntime,
  waitForSendReadyRuntime,
  waitForNdrRuntime,
} from './privateChats'
import { getEventHash, type VerifiedEvent } from 'nostr-tools'
import {
  saveGroup as saveGroupToDb,
  getAllGroups,
  deleteGroupFromDb,
  saveMessage as saveMessageToDb,
  getMessagesForSession,
  deleteMessage as deleteMessageFromDb,
  deleteMessagesForSession,
  updateMessageStatus as updateMessageStatusInDb,
  updateMessageSentToRelays as updateMessageSentToRelaysInDb,
  updateMessageRecipientStatuses as updateMessageRecipientStatusesInDb,
  updateMessageDeliveryTrace as updateMessageDeliveryTraceInDb,
  type StoredGroup,
  type StoredMessage
} from './storage'
import { setRemoteTyping, clearRemoteTyping } from './typingState'
import { expirationStore } from './expirationStore'
import {
  advanceRecipientStatus,
  mergeUniqueStrings,
  onMessageRelayPublish,
  relayChannelLabel,
  type RecipientDeliveryStatus,
} from './messageRelayStatus'
import { parseReceipt, shouldAdvanceStatus, type MessageStatus, type ReceiptPayload } from './receipts'
import { receiptSettings } from './receiptSettings'
import { typingSettings } from './typingSettings'
import { parseChatSettingsContent } from './chatSettings'

export { GROUP_ROSTER_FACT_KIND, GROUP_ROSTER_FACT_TYPE }
export type Group = GroupData & Pick<StoredGroup, 'rosterVersion' | 'protocol'>

type OuterEvent = { id?: string; outerEventId?: string } | unknown
type NativeGroupSendResult = { outer: VerifiedEvent; inner: Rumor }
type GroupRosterFactCursor = Pick<GroupRosterFact, 'revision' | 'updatedAt' | 'eventCreatedAt' | 'eventId'>

export interface GroupMessage extends ChatMessage {
  senderPubkey?: string
}

export const groups = writable<Map<string, Group>>(new Map())
export const groupMessages = writable<Map<string, GroupMessage[]>>(new Map())

let requestProjectionCleanup: (() => void) | undefined
function startRequestProjection(): void {
  if (requestProjectionCleanup) return
  requestProjectionCleanup = messageRequests.subscribe(() => {
    const owner = getPubkey()
    if (!owner) return
    for (const group of get(groups).values()) {
      if (!group.members.includes(owner)) continue
      const accepted = groupRequestAccepted(owner, group.id, group.accepted)
      if (accepted === group.accepted) continue
      const updated = { ...group, accepted }
      groups.update(all => new Map(all).set(group.id, updated))
      void saveGroupState(updated)
      syncNativeGroupTransport(group.id)
    }
  })
}
export const currentGroupId = writable<string | null>(null)

// Queue for group events that arrive before the group's roster snapshot
// (e.g., message arrives before creation event due to network reordering)
const pendingGroupEvents = new Map<string, Array<{ rumor: Rumor, senderPubkey: string, senderDevicePubkey?: string, outerEventId?: string }>>()
const MAX_PENDING_PER_GROUP = 50
const PENDING_MAX_AGE_MS = 5 * 60 * 1000 // 5 minutes
const nativeGroupSendQueue = new Map<string, Promise<void>>()
const groupRosterFactCursors = new Map<string, GroupRosterFactCursor>()
const reservedRosterRevisions = new Map<string, number>()
const seenGroupRosterFactIds = new Set<string>()

function enqueueNativeGroupSend<T>(groupId: string, action: () => Promise<T>): Promise<T> {
  const previous = nativeGroupSendQueue.get(groupId) ?? Promise.resolve()
  const result = previous.catch(() => undefined).then(action)
  const settled = result.then(
    () => undefined,
    () => undefined,
  )
  nativeGroupSendQueue.set(groupId, settled)
  settled.finally(() => {
    if (nativeGroupSendQueue.get(groupId) === settled) {
      nativeGroupSendQueue.delete(groupId)
    }
  })
  return result
}

function queuePendingEvent(
  groupId: string,
  rumor: Rumor,
  senderPubkey: string,
  senderDevicePubkey?: string,
  outerEventId?: string,
): void {
  let queue = pendingGroupEvents.get(groupId)
  if (!queue) {
    queue = []
    pendingGroupEvents.set(groupId, queue)
  }
  if (queue.length < MAX_PENDING_PER_GROUP) {
    queue.push({ rumor, senderPubkey, senderDevicePubkey, outerEventId })
  }
}

function flushPendingEvents(groupId: string): void {
  const queue = pendingGroupEvents.get(groupId)
  if (!queue || queue.length === 0) return
  pendingGroupEvents.delete(groupId)

  const now = Date.now()
  for (const { rumor, senderPubkey, senderDevicePubkey, outerEventId } of queue) {
    // Skip stale events
    if (now - rumor.created_at * 1000 > PENDING_MAX_AGE_MS) continue
    // Re-dispatch through handleGroupEvent (group now exists in store)
    handleGroupEvent(rumor, senderPubkey, outerEventId ? { id: outerEventId } : undefined, senderDevicePubkey)
  }
}

function getOuterEventId(outerEvent: OuterEvent | undefined): string | undefined {
  if (!outerEvent || typeof outerEvent !== 'object') return undefined
  const candidate = outerEvent as { id?: unknown; outerEventId?: unknown }
  if (typeof candidate.id === 'string') return candidate.id
  if (typeof candidate.outerEventId === 'string') return candidate.outerEventId
  return undefined
}

function resolveOurDevicePubkey(): string | null {
  const devicePubkey = get(devices).identityPubkey?.trim()
  if (devicePubkey) return devicePubkey
  const ownerPubkey = getPubkey()?.trim()
  return ownerPubkey || null
}

export function syncNativeGroupTransport(groupId: string): void {
  const currentGroups = Array.from(get(groups).values())
  const ownerPubkey = getPubkey()?.trim()
  // Restored groups can arrive before session initialization. Calling syncGroups
  // then would recursively wait for that same group-manager initialization.
  void waitForNdrRuntime().then(runtime => runtime.syncGroups(currentGroups, ownerPubkey || undefined)).catch((error) => {
    console.warn('[groups] Failed to sync runtime groups:', groupId, error)
  })
}

function isRuntimeSessionReady(): boolean {
  const runtime = getNdrRuntime()
  return typeof runtime.getState !== 'function' || runtime.getState().sessionManagerReady
}

export const isAdmin = isGroupAdmin

export function canSendToGroup(group: Group | undefined, ownerPubkey = getPubkey()): boolean {
  return !!group && !!ownerPubkey && group.accepted !== false && group.members.includes(ownerPubkey)
}

function currentGroupForSend(groupId: string, expected?: Group): Group | undefined {
  const group = get(groups).get(groupId)
  return canSendToGroup(group) && (!expected || group === expected) ? group : undefined
}

function compareGroupRosterFactCursor(
  left: GroupRosterFactCursor,
  right: GroupRosterFactCursor,
): number {
  return left.revision - right.revision
    || left.updatedAt - right.updatedAt
    || left.eventCreatedAt - right.eventCreatedAt
    || left.eventId.localeCompare(right.eventId)
}

function rememberGroupRosterFact(groupId: string, fact: GroupRosterFactCursor): void {
  const existing = groupRosterFactCursors.get(groupId)
  if (existing && compareGroupRosterFactCursor(existing, fact) >= 0) return
  groupRosterFactCursors.set(groupId, fact)
}

export function getGroupRosterVersion(groupId: string): { revision: number; updatedAt: number } | undefined {
  const fact = groupRosterFactCursors.get(groupId)
  return fact && { revision: fact.revision, updatedAt: fact.updatedAt }
}

export function rememberSyncedGroupRosterVersion(groupId: string, revision: number, updatedAt: number): void {
  rememberGroupRosterFact(groupId, { eventId: '', revision, updatedAt, eventCreatedAt: updatedAt })
}

function shouldApplyGroupRosterFact(fact: GroupRosterFact): boolean {
  if (seenGroupRosterFactIds.has(fact.eventId)) return false
  const existing = groupRosterFactCursors.get(fact.groupId)
  // Sibling snapshots omit the signed event ID. Its absence is not evidence
  // that a conflicting fact with the same known version is newer.
  if (existing?.eventId === '' && fact.revision === existing.revision && fact.updatedAt === existing.updatedAt) return false
  return !existing || compareGroupRosterFactCursor(fact, existing) > 0
}

function nextGroupRosterRevision(groupId: string): number {
  const revision = Math.max(groupRosterFactCursors.get(groupId)?.revision ?? 0, reservedRosterRevisions.get(groupId) ?? 0) + 1
  // Reserve before asynchronous signing so concurrent changes stay ordered.
  reservedRosterRevisions.set(groupId, revision)
  return revision
}

function getGroupRosterSignerPubkey(group: Group): string | null {
  const currentIdentity = get(identity)
  const signer = get(nostrClient).signer || currentIdentity?.signer
  if (!signer) return null
  const signerPubkey = currentIdentity?.pubkey || (() => {
    try {
      return signer.pubkey
    } catch {
      return null
    }
  })()
  if (!signerPubkey || !group.admins.includes(signerPubkey)) return null
  return signerPubkey
}

async function publishGroupRosterFactSnapshot(group: Group): Promise<void> {
  const client = get(nostrClient)
  const signer = client.signer || get(identity)?.signer
  const signerPubkey = getGroupRosterSignerPubkey(group)
  if (!signer || !signerPubkey) return

  const eventCreatedAt = Math.floor(Date.now() / 1000)
  const unsigned = buildGroupRosterFactEvent(group, {
    signerPubkey,
    revision: nextGroupRosterRevision(group.id),
    createdBy: group.admins[0] || signerPubkey,
    updatedAt: eventCreatedAt,
    eventCreatedAt,
    protocol: group.protocol ?? (group.secret ? 'sender_key_v1' : 'pairwise_fanout_v1'),
  })

  const event = new AppEvent(client, unsigned)
  await event.sign(signer)
  const signed = event.rawEvent() as VerifiedEvent
  await saveAuthorizationEvent(getPubkey()!, signed)
  rememberGroupRosterFact(group.id, {
    eventId: signed.id,
    revision: Number(unsigned.tags.find((tag) => tag[0] === 'revision')?.[1] || 0),
    updatedAt: Number(unsigned.tags.find((tag) => tag[0] === 'updated_at')?.[1] || eventCreatedAt),
    eventCreatedAt: signed.created_at,
  })
  const current = get(groups).get(group.id)
  if (current) saveGroupState(current)
  // Signed membership proofs stay local and travel only through authenticated
  // private sessions, including the sender's other linked devices.
  const runtime = await waitForNdrRuntime()
  await Promise.all(group.members.map(member =>
    runtime.sendEvent(member, { kind: signed.kind, content: signed.content, tags: signed.tags,
      pubkey: signed.pubkey, created_at: signed.created_at, id: signed.id },
      undefined, { includeLocalSiblings: false })))
}

function publishGroupRosterFactSnapshotInBackground(group: Group): void {
  void publishGroupRosterFactSnapshot(group).catch((error) => {
    console.warn('[groups] Failed to publish group roster fact:', error)
  })
}

function groupMetadataFromRosterFact(fact: GroupRosterFact): GroupMetadata {
  return {
    id: fact.group.id,
    name: fact.group.name,
    members: fact.group.members,
    admins: fact.group.admins,
    ...(fact.group.description && { description: fact.group.description }),
    ...(fact.group.picture && { picture: fact.group.picture }),
  }
}

function applyGroupRosterFact(fact: GroupRosterFact): boolean {
  if (!shouldApplyGroupRosterFact(fact)) return false

  const myPubkey = getPubkey()
  if (!myPubkey) return false

  startRequestProjection()
  const metadata = groupMetadataFromRosterFact(fact)
  const existing = get(groups).get(fact.groupId)
  if (existing) {
    const result = validateMetadataUpdate(existing, metadata, fact.signerPubkey, myPubkey)
    if (result === 'reject') return false
    const updated: Group = { ...applyMetadataUpdate(existing, metadata), protocol: fact.protocol ?? existing.protocol }
    rememberGroupRosterFact(fact.groupId, fact)
    groups.update(g => { g.set(fact.groupId, updated); return g })
    saveGroupState(updated)
    if (result === 'removed') {
      clearRemoteTyping(`group:${fact.groupId}`)
      cancelGroupPublications(fact.groupId)
    }
    syncNativeGroupTransport(fact.groupId)
  } else {
    if (!validateMetadataCreation(metadata, fact.signerPubkey, myPubkey)) return false

    const group: Group = {
      ...metadata,
      protocol: fact.protocol,
      createdAt: fact.group.createdAt,
      accepted: groupRequestAccepted(myPubkey, fact.groupId, fact.signerPubkey === myPubkey),
    }
    rememberGroupRosterFact(fact.groupId, fact)
    groups.update(g => { g.set(fact.groupId, group); return g })
    groupMessages.update(gm => { if (!gm.has(fact.groupId)) gm.set(fact.groupId, []); return gm })
    saveGroupState(group)
    syncNativeGroupTransport(fact.groupId)
    flushPendingEvents(fact.groupId)
  }

  seenGroupRosterFactIds.add(fact.eventId)
  return true
}

export function handleGroupRosterFactEvent(event: VerifiedEvent): boolean {
  if (!isGroupRosterFactEvent(event)) return false

  try {
    const applied = applyGroupRosterFact(parseGroupRosterFactEvent(structuredClone(event)))
    if (applied) void saveAuthorizationEvent(getPubkey()!, event).catch(error => console.warn('Could not save group authorization', error))
    return applied
  } catch {
    return false
  }
}

export async function applySyncedGroupRosterFact(event: VerifiedEvent): Promise<void> {
  const fact = parseGroupRosterFactEvent(structuredClone(event))
  const { isHistoryChatDeleted } = await import('./storage')
  if (await isHistoryChatDeleted(`group:${fact.groupId}`, fact.updatedAt)) return
  applyGroupRosterFact(fact)
  const current = get(groups).get(fact.groupId)
  if (current) await saveGroupState(current)
}

export function handleGroupRosterFactRumor(rumor: Rumor): boolean {
  if (!isGroupRosterFactEvent(rumor)) return false

  try {
    return applyGroupRosterFact(parseGroupRosterFactRumor(rumor as GroupRosterFactRumor))
  } catch {
    return false
  }
}

export async function receivePrivateGroupRosterFact(rumor: Rumor, meta?: OnEventMeta): Promise<void> {
  const owner = getPubkey(), sender = meta?.senderOwnerPubkey
  // Native metadata is authored by its device; web metadata by its owner.
  // Both must match the identities authenticated by the pairwise session.
  if (!owner || !sender || (rumor.pubkey !== sender && rumor.pubkey !== meta?.senderDevicePubkey) || !isGroupRosterFactEvent(rumor)) return
  let fact: GroupRosterFact
  try { fact = parseGroupRosterFactRumor(rumor as GroupRosterFactRumor) } catch { return }
  if (!await privateHistoryAllowed(owner, sender, rumor.created_at) || getPubkey() !== owner) return
  // Group admin/member identities are accounts, even when the inner event was
  // authored by an authorized device. Preserve the original rumor and event ID.
  applyGroupRosterFact({ ...fact, signerPubkey: sender })
  const current = get(groups).get(fact.groupId)
  // Retry persistence even if an earlier delivery already applied this fact in
  // memory. The durable session event is acknowledged only after storage works.
  if (current) await saveGroupState(current)
}

export function initGroupRosterFactSync(): () => void {
  startRequestProjection()
  // Membership arrives through the durable private-session handler and linked
  // device history. Public roster subscriptions disclose group membership.
  return () => {}
}

function markGroupMessageSentToRelays(messageId: string, relayUrls: string[]): void {
  let relaysToPersist: string[] | null = null
  let channelsToPersist: string[] | null = null

  groupMessages.update((groupMap) => {
    for (const [groupId, messages] of groupMap) {
      const messageIndex = messages.findIndex((message) => message.id === messageId)
      if (messageIndex === -1) continue

      const message = messages[messageIndex]
      const sentToRelays = mergeUniqueStrings(message.sentToRelays, relayUrls)
      const currentRelays = message.sentToRelays || []
      const deliveryChannels = mergeUniqueStrings(
        message.deliveryChannels,
        relayUrls.map(relayChannelLabel)
      )
      const currentChannels = message.deliveryChannels || []
      if (
        sentToRelays.length === currentRelays.length &&
        sentToRelays.every((url, index) => url === currentRelays[index]) &&
        deliveryChannels.length === currentChannels.length &&
        deliveryChannels.every((channel, index) => channel === currentChannels[index])
      ) {
        return groupMap
      }

      const updatedMessages = [...messages]
      updatedMessages[messageIndex] = { ...message, sentToRelays, deliveryChannels }
      relaysToPersist = sentToRelays
      channelsToPersist = deliveryChannels
      groupMap.set(groupId, updatedMessages)
      return groupMap
    }

    return groupMap
  })

  if (!relaysToPersist) return

  void updateMessageSentToRelaysInDb(messageId, relaysToPersist).catch((error) => {
    console.error('[groups] Failed to persist group relay publish status:', error)
  })
  if (channelsToPersist) {
    void updateMessageDeliveryTraceInDb(messageId, { deliveryChannels: channelsToPersist }).catch((error) => {
      console.error('[groups] Failed to persist group delivery channels:', error)
    })
  }
}

function reconcileLocalGroupMessageId(
  groupId: string,
  localMessageId: string,
  runtimeMessageId: string,
): void {
  if (!runtimeMessageId || runtimeMessageId === localMessageId) return

  let reconciledMessage: GroupMessage | null = null
  let shouldDeleteLocalMessage = false

  groupMessages.update((groupMap) => {
    const messages = groupMap.get(groupId)
    if (!messages) return groupMap

    const localIndex = messages.findIndex((message) => message.id === localMessageId)
    if (localIndex === -1) return groupMap

    const runtimeIndex = messages.findIndex((message) => message.id === runtimeMessageId)
    const updatedMessages = [...messages]
    const localMessage = updatedMessages[localIndex]
    if (!localMessage) return groupMap

    if (runtimeIndex !== -1) {
      updatedMessages.splice(localIndex, 1)
      shouldDeleteLocalMessage = true
    } else {
      reconciledMessage = { ...localMessage, id: runtimeMessageId }
      updatedMessages[localIndex] = reconciledMessage
      shouldDeleteLocalMessage = true
    }

    groupMap.set(groupId, updatedMessages)
    return groupMap
  })

  if (reconciledMessage) {
    void saveGroupMessageToStorage(groupId, reconciledMessage)
  }
  if (shouldDeleteLocalMessage) {
    void deleteMessageFromDb(localMessageId)
  }
}

onMessageRelayPublish(markGroupMessageSentToRelays)

function buildScopedGroupRumor(
  scopeTag: string[],
  partialEvent: { content: string; kind: number; tags: string[][] },
  matchScopeValue = false,
  now = Date.now(),
): Rumor {
  const myPubkey = getPubkey()
  if (!myPubkey) {
    throw new Error('Not logged in')
  }

  const tags = [...partialEvent.tags]
  if (!tags.some((tag) =>
    tag[0] === scopeTag[0] && (!matchScopeValue || tag[1] === scopeTag[1])
  )) {
    tags.unshift(scopeTag)
  }
  if (!tags.some((t) => t[0] === 'ms')) {
    tags.push(['ms', String(now)])
  }

  const rumor: Rumor = {
    content: partialEvent.content,
    kind: partialEvent.kind,
    created_at: Math.floor(now / 1000),
    tags,
    pubkey: myPubkey,
    id: '',
  }
  rumor.id = getEventHash(rumor)
  return rumor
}


async function sendNativeGroupEvent(
  groupId: string,
  partialEvent: { content: string, kind: number, tags: string[][] },
  options?: { rumor?: Rumor },
): Promise<NativeGroupSendResult | null> {
  return enqueueNativeGroupSend(groupId, async () => {
    const runtime = getNdrRuntime()
    const groupData = currentGroupForSend(groupId)
    if (!groupData) return null

    await waitForSendReadyRuntime()
    if (!currentGroupForSend(groupId, groupData)) return null
    await runtime.upsertGroup(groupData)
    if (!currentGroupForSend(groupId, groupData)) return null
    const runtimeRumor = options?.rumor ?? buildScopedGroupRumor(['l', groupId], partialEvent)
    const result = await runtime.sendGroupEvent(groupId, {
      // Carry the canonical event inside the private group delivery envelope.
      kind: CHAT_MESSAGE_KIND,
      content: JSON.stringify(runtimeRumor),
      tags: runtimeRumor.tags,
    })
    return { outer: result.outer as unknown as VerifiedEvent, inner: runtimeRumor }
  })
}

function refreshGroupPushSubscriptions(): void {
  void import('./notifications').then(({updateDMSubscription}) => updateDMSubscription()).catch(() => {})
}

function saveGroupState(group: Group): Promise<void> {
  const storedGroup: StoredGroup = {
    id: group.id,
    name: group.name,
    members: group.members,
    admins: group.admins,
    createdAt: group.createdAt,
    ...(group.description && { description: group.description }),
    ...(group.picture && { picture: group.picture }),
    ...(group.secret && { secret: group.secret }),
    ...(group.protocol && { protocol: group.protocol }),
    accepted: group.accepted,
    rosterVersion: groupRosterFactCursors.get(group.id) ?? group.rosterVersion,
  }
  const pending = saveGroupToDb(storedGroup)
  void pending.then(refreshGroupPushSubscriptions).catch(e => console.error('[groups] Failed to save group:', e))
  return pending
}

export async function createGroup(name: string, memberPubkeys: string[]): Promise<Group> {
  const myPubkey = getPubkey()
  if (!myPubkey) throw new Error('Not logged in')

  let group: Group = createGroupData(name, myPubkey, memberPubkeys)
  try {
    await waitForSendReadyRuntime()
    group = (
      await getNdrRuntime().createGroup(name, memberPubkeys, {
        fanoutMetadata: isRuntimeSessionReady(),
      })
    ).group
  } catch (error) {
    console.warn('[groups] Falling back to local-only group creation:', error)
  }
  group.protocol = 'sender_key_v1'

  groups.update(g => {
    g.set(group.id, group)
    return g
  })
  groupMessages.update(gm => {
    gm.set(group.id, [])
    return gm
  })

  saveGroupState(group)

  publishGroupRosterFactSnapshotInBackground(group)
  syncNativeGroupTransport(group.id)

  return group
}

function mutateGroup(
  groupId: string,
  transform: (group: Group, myPubkey: string) => Group | null,
): void {
  const myPubkey = getPubkey()
  const group = get(groups).get(groupId)
  if (!myPubkey || !group || !currentGroupForSend(groupId)) return

  const updated = transform(group, myPubkey)
  if (!updated) return

  groups.update((current) => current.set(groupId, updated))
  saveGroupState(updated)
  // Our signed roster echo is deliberately deduplicated. Apply the new members
  // and rotated secret to the local transport before that echo can be ignored.
  syncNativeGroupTransport(groupId)
  publishGroupRosterFactSnapshotInBackground(updated)
}

export function addGroupMember(groupId: string, pubkey: string): void {
  // Verify we have a chat session with the new member
  if (!get(chats).has(pubkey)) return
  mutateGroup(groupId, (group, myPubkey) => libAddMember(group, pubkey, myPubkey))
}

// Admission already committed the roster and invite use in one transaction.
export async function publishAdmittedGroup(group: Group): Promise<void> {
  groups.update(current => current.set(group.id, group))
  await (await waitForNdrRuntime()).syncGroups(Array.from(get(groups).values()), getPubkey()!)
  await publishGroupRosterFactSnapshot(group)
}

export function removeGroupMember(groupId: string, pubkey: string): void {
  mutateGroup(groupId, (group, myPubkey) => libRemoveMember(group, pubkey, myPubkey))
}

export function updateGroupInfo(groupId: string, updates: { name?: string, description?: string, picture?: string }): void {
  mutateGroup(groupId, (group, myPubkey) => updateGroupData(group, updates, myPubkey))
}

export function addGroupAdmin(groupId: string, pubkey: string): void {
  mutateGroup(groupId, (group, myPubkey) => libAddAdmin(group, pubkey, myPubkey))
}

export function removeGroupAdmin(groupId: string, pubkey: string): void {
  mutateGroup(groupId, (group, myPubkey) => libRemoveAdmin(group, pubkey, myPubkey))
}

export async function sendGroupMessage(groupId: string, text: string, replyTo?: string): Promise<boolean> {
  const myPubkey = getPubkey()
  if (!myPubkey || !currentGroupForSend(groupId)) return false

  const tags: string[][] = []
  if (replyTo) {
    tags.push(['e', replyTo, '', 'reply'])
  }

  const configuredTtlSeconds = expirationStore.getExpiration(groupId)
  const normalizedTtlSeconds =
    typeof configuredTtlSeconds === 'number' &&
    Number.isFinite(configuredTtlSeconds) &&
    configuredTtlSeconds > 0
      ? Math.floor(configuredTtlSeconds)
      : undefined
  const expiresAt =
    normalizedTtlSeconds !== undefined
      ? Math.floor(Date.now() / 1000) + normalizedTtlSeconds
      : undefined

  if (expiresAt !== undefined) {
    tags.push(['expiration', String(expiresAt)])
  }

  const rumor = buildScopedGroupRumor(['l', groupId], { content: text, kind: CHAT_MESSAGE_KIND, tags })
  const message: GroupMessage = {
    id: rumor.id,
    content: text,
    timestamp: Date.now(),
    isMine: true,
    senderPubkey: myPubkey,
    ...(replyTo && { replyTo }),
    ...(expiresAt !== undefined && { expiresAt }),
  }

  // A visible outgoing message must already survive an immediate reload.
  await saveGroupMessageToStorage(groupId, message, true)
  if (getPubkey() !== myPubkey || !currentGroupForSend(groupId)) return false

  groupMessages.update(gm => {
    const msgs = gm.get(groupId) || []
    gm.set(groupId, [...msgs, message])
    return gm
  })

  void sendNativeGroupEvent(
    groupId,
    {
      content: text,
      kind: CHAT_MESSAGE_KIND,
      tags,
    },
    { rumor },
  )
    .then((result) => {
      if (result?.inner.id) {
        reconcileLocalGroupMessageId(groupId, message.id, result.inner.id)
      }
    })
    .catch((error) => {
      console.error('[groups] Failed to send group message:', error)
    })
  return true
}

export async function editGroupMessage(groupId: string, messageId: string, content: string): Promise<void> {
  await mutateGroupMessage(groupId, messageId, 'edit', content)
}
export async function deleteGroupMessageForEveryone(groupId: string, messageId: string): Promise<void> {
  await mutateGroupMessage(groupId, messageId, 'delete', '')
}
async function mutateGroupMessage(groupId: string, messageId: string, operation: 'edit' | 'delete', content: string): Promise<void> {
  const owner = getPubkey(), message = get(groupMessages).get(groupId)?.find(row => row.id === messageId)
  if (!owner || !currentGroupForSend(groupId) || !message?.isMine || message.call || message.deletedAt !== undefined || operation === 'edit' && !editableMessage(message)) throw new Error('This message cannot be changed.')
  const rumor = buildMessageMutation(owner, messageId, operation, content, ['l', groupId], Math.max(Date.now(), (message.editedAt ?? 0) + 1), message.expiresAt)
  await sendMessageMutation(owner, `group:${groupId}`, rumor, async () => {
    const queued = await sendNativeGroupEvent(groupId, rumor, { rumor })
    if (!queued) throw new Error('Could not send this message update. Try again.')
  }, () => getPubkey() === owner && !!currentGroupForSend(groupId))
}

export function sendGroupReaction(groupId: string, messageId: string, emoji: string): void {
  const owner = getPubkey()
  if (!owner || !currentGroupForSend(groupId)) return
  void withDeviceControlClock(owner, { chatId: `group:${groupId}`, messageId, author: owner }, async nowMs => {
    const target = get(groupMessages).get(groupId)?.find(message => message.id === messageId)
    const nextEmoji = target?.reactions?.[emoji]?.includes(owner) ? '' : emoji
    const rumor = buildScopedGroupRumor(['l', groupId], {
      content: nextEmoji, kind: REACTION_KIND, tags: [['e', messageId]],
    }, false, nowMs)
    await captureReaction(owner, `group:${groupId}`, rumor, owner, messageId, nextEmoji)
    if (getPubkey() === owner) acceptChat(`group:${groupId}`)
    return rumor
  }).then(rumor => sendNativeGroupEvent(groupId, rumor, { rumor }))
    .catch(error => console.error('[groups] Failed to send group reaction:', error))
}

export function sendGroupTypingEvent(groupId: string): void {
  if (!get(typingSettings).sendTypingIndicators) return

  void sendNativeGroupEvent(groupId, {
    content: 'typing',
    kind: TYPING_KIND,
    tags: [],
  }).catch((error) => {
    console.error('[groups] Failed to send group typing event:', error)
  })
}

export function sendGroupSettingsEvent(groupId: string, messageTtlSeconds: number | null): void {
  const owner = getPubkey()
  if (!owner || !currentGroupForSend(groupId)?.admins.includes(owner)) return
  void withDeviceControlClock(owner, groupId, async nowMs => {
    const rumor = buildScopedGroupRumor(['l', groupId], {
      content: JSON.stringify({ type: 'chat-settings', v: 1, messageTtlSeconds }),
      kind: CHAT_SETTINGS_KIND, tags: [],
    }, false, nowMs)
    await applyGroupSettingsRecord(owner, { ...controlClock(rumor), groupId, author: owner, messageTtlSeconds })
    return rumor
  }).then(rumor => sendNativeGroupEvent(groupId, rumor, { rumor }))
    .catch(error => console.error('[groups] Failed to send group settings event:', error))
}

const incomingGroupQueues = new Map<string, Promise<void>>()
/** Preserve arrival order across asynchronous commits, including controls before originals. */
export function handleGroupEvent(rumor: Rumor, sender: string, outer?: OuterEvent, device?: string): Promise<void> {
  const canonical = parseSerializedGroupRuntimeRumor(rumor.content) ?? rumor
  const groupId = canonical.tags.find(tag => tag[0] === 'l')?.[1]
  if (!groupId) return Promise.resolve()
  const owner = getPubkey()
  const operation = (incomingGroupQueues.get(groupId) ?? Promise.resolve()).catch(() => undefined).then(async () => {
    let delay = 1000
    while (getPubkey() === owner) {
      try { await processGroupEvent(canonical, sender, outer, device); return }
      catch (error) {
        console.warn('[groups] Could not save incoming message change; retrying:', error)
        await new Promise(resolve => setTimeout(resolve, delay))
        delay = Math.min(delay * 2, 30000)
      }
    }
  })
  incomingGroupQueues.set(groupId, operation)
  void operation.finally(() => { if (incomingGroupQueues.get(groupId) === operation) incomingGroupQueues.delete(groupId) })
  return operation
}

async function processGroupEvent(
  rumor: Rumor,
  senderPubkey: string,
  outerEvent?: OuterEvent,
  senderDevicePubkey?: string
): Promise<void> {
  rumor = parseSerializedGroupRuntimeRumor(rumor.content) ?? rumor
  const groupTag = rumor.tags?.find((t: string[]) => t[0] === 'l')
  if (!groupTag) return
  const groupId = groupTag[1]
  const outerEventId = getOuterEventId(outerEvent)

  const owner = getPubkey()
  if (owner && !await privateHistoryAllowed(owner, senderPubkey, rumor.created_at)) return
  if (owner && senderPubkey === owner && rumor.kind === RECEIPT_KIND) await applyOwnReadTag(owner, `group:${groupId}`, rumor)
  const groupExists = get(groups).has(groupId)

  if (rumor.kind === GROUP_SENDER_KEY_DISTRIBUTION_KIND) {
    refreshGroupPushSubscriptions()
    if (!groupExists) {
      // Queue event; the roster snapshot may arrive later due to network reordering.
      queuePendingEvent(groupId, rumor, senderPubkey, senderDevicePubkey, outerEventId)
    }
    return
  }

  if (!groupExists) {
    // Queue event; the roster snapshot may arrive later due to network reordering.
    if (
      rumor.kind === CHAT_MESSAGE_KIND ||
      rumor.kind === MESSAGE_EDIT_KIND ||
      rumor.kind === MESSAGE_DELETE_KIND ||
      rumor.kind === REACTION_KIND ||
      rumor.kind === RECEIPT_KIND ||
      rumor.kind === CHAT_SETTINGS_KIND
    ) {
      queuePendingEvent(groupId, rumor, senderPubkey, senderDevicePubkey, outerEventId)
    }
    return
  }

  if (rumor.kind === MESSAGE_EDIT_KIND || rumor.kind === MESSAGE_DELETE_KIND) {
    const owner = getPubkey()
    if (owner) await captureMessageMutation(owner, `group:${groupId}`, rumor, senderPubkey)
    return
  }

  if (rumor.kind === CHAT_SETTINGS_KIND) {
    if (rumor.id && getEventHash(rumor) !== rumor.id) return
    const group = get(groups).get(groupId)
    if (!group?.admins?.includes(senderPubkey)) return
    const settings = parseChatSettingsContent(rumor.content)
    if (settings) {
      const owner = getPubkey()
      if (owner) await applyGroupSettingsRecord(owner, { ...controlClock(rumor), groupId, author: senderPubkey, messageTtlSeconds: settings.messageTtlSeconds })
    }
    return
  }

  if (rumor.kind === TYPING_KIND) {
    const expiresAt = getExpirationTimestampSeconds(rumor)
    const nowSeconds = Math.floor(Date.now() / 1000)
    if (expiresAt !== undefined && expiresAt <= nowSeconds) {
      clearRemoteTyping(`group:${groupId}`)
    } else {
      setRemoteTyping(`group:${groupId}`, rumor.created_at)
    }
    return
  }

  if (rumor.kind === REACTION_KIND) {
    await handleGroupReaction(groupId, rumor, senderPubkey)
    return
  }

  if (rumor.kind === RECEIPT_KIND) {
    const receipt = parseReceipt(rumor)
    if (receipt) {
      await handleGroupReceipt(groupId, receipt, senderPubkey)
    }
    return
  }

  if (rumor.kind === CHAT_MESSAGE_KIND) {
    const myPubkey = getPubkey()
    if (!myPubkey || senderPubkey !== myPubkey) {
      clearRemoteTyping(`group:${groupId}`, rumor.created_at)
    }
    await handleGroupMessage(groupId, rumor, senderPubkey, senderDevicePubkey, outerEventId)
    return
  }
}

async function handleGroupMessage(
  groupId: string,
  rumor: Rumor,
  senderPubkey: string,
  senderDevicePubkey?: string,
  outerEventId?: string,
): Promise<void> {
  const myPubkey = getPubkey()
  const isOwnOwnerMessage = !!myPubkey && senderPubkey === myPubkey
  if (isOwnOwnerMessage) {
    const ourDevicePubkey = resolveOurDevicePubkey()
    const resolvedSenderDevicePubkey = senderDevicePubkey || rumor.pubkey
    if (ourDevicePubkey && resolvedSenderDevicePubkey === ourDevicePubkey) {
      return
    }
  }

  const replyTag = rumor.tags?.find(
    (tag: string[]) => tag[0] === 'e' && tag[3] === 'reply'
  )?.[1] || rumor.tags?.find(
    (tag: string[]) => tag[0] === 'e' && !rumor.tags?.some((t: string[]) => t[0] === 'e' && t[3] === 'root')
  )?.[1]

  const expiresAt = getExpirationTimestampSeconds(rumor)
  const group = get(groups).get(groupId)
  const shouldAckDelivered =
    !isOwnOwnerMessage &&
    group?.accepted !== false &&
    get(receiptSettings).sendDeliveryReceipts

  const message: GroupMessage = {
    id: rumor.id,
    content: rumor.content,
    timestamp: controlClock(rumor).createdAtMs ?? rumor.created_at * 1000,
    isMine: isOwnOwnerMessage,
    senderPubkey,
    ...(replyTag && { replyTo: replyTag }),
    ...(shouldAckDelivered && { status: 'delivered' as const }),
    deliveryChannels: ['message servers'],
    outerEventIds: [outerEventId || rumor.id],
    ...(expiresAt !== undefined && { expiresAt }),
  }

  if (!myPubkey) return
  const committed = await persistMessageWithReactions(myPubkey, { ...message, sessionId: `group:${groupId}` })
  Object.assign(message, committed)
  if (outerEventId) await saveProcessedEvent({id:outerEventId,messageId:rumor.id,author:senderPubkey,
    createdAtSecs:rumor.created_at,kind:rumor.kind,chatId:`group:${groupId}`,content:rumor.content,isSelfMessage:isOwnOwnerMessage,timestamp:Date.now()})

  let inserted = false
  groupMessages.update(gm => {
    const msgs = gm.get(groupId) || []
    if (msgs.some(m => m.id === message.id)) return gm
    inserted = true
    gm.set(groupId, [...msgs, message].sort((a, b) => a.timestamp - b.timestamp))
    return gm
  })

  if (inserted) void import('./foregroundMessageNotifications').then(({notifyForegroundMessage}) => notifyForegroundMessage(myPubkey,committed)).catch(()=>{})
  if (shouldAckDelivered) {
    sendGroupReceipt(groupId, 'delivered', [message.id])
  }
}

async function handleGroupReaction(groupId: string, rumor: Rumor, fromPubkey: string): Promise<void> {
  const parsed = reactionControl(rumor)
  const owner = getPubkey()
  if (!parsed || !owner) return
  const { emoji, messageId } = parsed
  await captureReaction(owner, `group:${groupId}`, rumor, fromPubkey, messageId, emoji)
}

async function handleGroupReceipt(groupId: string, receipt: ReceiptPayload, fromPubkey: string): Promise<void> {
  const myPubkey = getPubkey()
  const changedStatuses: Array<{ messageId: string; status: MessageStatus }> = []
  const changedRecipientStatuses: Array<{
    messageId: string
    recipientStatuses: Record<string, RecipientDeliveryStatus>
  }> = []

  groupMessages.update((gm) => {
    const msgs = gm.get(groupId) || []
    if (msgs.length === 0) return gm

    const updated = [...msgs]
    let changed = false

    for (const messageId of receipt.messageIds) {
      const index = updated.findIndex((message) => message.id === messageId)
      if (index === -1) continue

      const message = updated[index]
      const nextRecipientStatuses =
        message.isMine && fromPubkey !== myPubkey
          ? advanceRecipientStatus(message.recipientStatuses, fromPubkey, receipt.type)
          : null
      const nextStatus =
        !message.isMine && fromPubkey === myPubkey && shouldAdvanceStatus(message.status, receipt.type)
          ? receipt.type
          : message.status
      // Repeat the committed projection on retries: a previous storage failure
      // may have happened after the in-memory status already advanced.
      if (!message.isMine && fromPubkey===myPubkey && nextStatus) {
        changedStatuses.push({messageId,status:nextStatus})
      }
      const recipientStatuses=nextRecipientStatuses ?? message.recipientStatuses
      if (message.isMine && fromPubkey!==myPubkey && recipientStatuses) {
        changedRecipientStatuses.push({messageId,recipientStatuses})
      }
      if (!nextRecipientStatuses && nextStatus === message.status) continue

      updated[index] = {
        ...message,
        status: nextStatus,
        ...(nextRecipientStatuses && { recipientStatuses: nextRecipientStatuses }),
      }
      changed = true
    }

    if (!changed) return gm
    gm.set(groupId, updated)
    return gm
  })

  for (const { messageId, status } of changedStatuses) {
    await updateMessageStatusInDb(messageId, status)
  }
  for (const { messageId, recipientStatuses } of changedRecipientStatuses) {
    await updateMessageRecipientStatusesInDb(messageId, recipientStatuses)
  }
}

function sendGroupReceipt(groupId: string, type: MessageStatus, messageIds: string[]): void {
  const owner = getPubkey(), group = currentGroupForSend(groupId)
  if (!owner || !group || messageIds.length === 0) return
  void enqueueNativeGroupSend(groupId, async () => {
    const runtime = await waitForSendReadyRuntime()
    if (getPubkey() !== owner || !currentGroupForSend(groupId, group)) return
    const requested = new Set(messageIds), byAuthor = new Map<string, string[]>()
    for (const message of get(groupMessages).get(groupId) ?? []) {
      const author = message.senderPubkey?.toLowerCase()
      if (message.isMine || !author || author === owner || !/^[0-9a-f]{64}$/.test(author) || !requested.delete(message.id)) continue
      const ids = byAuthor.get(author) ?? []
      ids.push(message.id)
      byAuthor.set(author, ids)
    }
    if (!byAuthor.size) return
    // Sync our own devices once, separately from author delivery.
    byAuthor.set(owner, [...byAuthor.values()].flat())
    await Promise.all([...byAuthor].map(([author, ids]) => runtime.sendEvent(author,
      buildScopedGroupRumor(['p', author], {
        content: type, kind: RECEIPT_KIND, tags: [['l', groupId], ...ids.map(id => ['e', id])],
      }, true), owner, { includeLocalSiblings: false },
    )))
  }).catch((error) => {
    console.error('[groups] Failed to send group receipt:', error)
  })
}

async function saveGroupMessageToStorage(groupId: string, message: GroupMessage, throwOnError = false): Promise<void> {
  try {
    const reactions = message.reactions
      ? JSON.parse(JSON.stringify(message.reactions))
      : undefined

    const storedMessage: StoredMessage = {
      id: message.id,
      sessionId: `group:${groupId}`,
      content: message.content,
      ...messageMutationFields(message),
      timestamp: message.timestamp,
      isMine: message.isMine,
      ...(message.replyTo && { replyTo: message.replyTo }),
      reactions,
      status: message.status,
      ...(message.sentToRelays && { sentToRelays: message.sentToRelays }),
      ...(message.recipientStatuses && { recipientStatuses: message.recipientStatuses }),
      ...(message.deliveryChannels && { deliveryChannels: message.deliveryChannels }),
      ...(message.outerEventIds && { outerEventIds: message.outerEventIds }),
      ...(message.pendingRelayEventIds && { pendingRelayEventIds: message.pendingRelayEventIds }),
      senderPubkey: message.senderPubkey,
      ...(message.expiresAt !== undefined && { expiresAt: message.expiresAt }),
    }
    const owner = getPubkey()
    if (owner) await persistMessageWithReactions(owner, storedMessage)
    else await saveMessageToDb(storedMessage)
  } catch (e) {
    console.error('[groups] Failed to save message:', e)
    if (throwOnError) throw e
  }
}

export async function loadGroupsFromStorage(): Promise<void> {
  const owner = getPubkey()
  if (owner) loadMessageRequestDecisions(owner)
  startRequestProjection()
  try {
    const storedGroups = await getAllGroups()

    for (const stored of storedGroups) {
      const group: Group = {
        id: stored.id,
        name: stored.name,
        description: stored.description,
        picture: stored.picture,
        members: stored.members,
        admins: stored.admins || [],
        createdAt: stored.createdAt,
        secret: stored.secret,
        protocol: stored.protocol,
        accepted: owner ? groupRequestAccepted(owner, stored.id, stored.accepted) : stored.accepted,
        rosterVersion: stored.rosterVersion,
      }
      if (stored.rosterVersion) rememberGroupRosterFact(group.id, stored.rosterVersion)

      groups.update(g => {
        g.set(group.id, group)
        return g
      })

      const storedMessages = await getMessagesForSession(`group:${group.id}`)
      if (owner) for (const message of storedMessages) await restoreStoredRequestAcceptance(owner, message)
      const messages: GroupMessage[] = storedMessages
        .map(m => ({
          id: m.id,
          content: m.content,
          ...messageMutationFields(m),
          timestamp: m.timestamp,
          isMine: m.isMine,
          senderPubkey: m.senderPubkey,
          ...(m.replyTo && { replyTo: m.replyTo }),
          reactions: m.reactions,
          status: m.status,
          ...(m.sentToRelays && { sentToRelays: m.sentToRelays }),
          ...(m.recipientStatuses && { recipientStatuses: m.recipientStatuses }),
          ...(m.deliveryChannels && { deliveryChannels: m.deliveryChannels }),
          ...(m.outerEventIds && { outerEventIds: m.outerEventIds }),
          ...(m.pendingRelayEventIds && { pendingRelayEventIds: m.pendingRelayEventIds }),
          ...(m.expiresAt !== undefined && { expiresAt: m.expiresAt }),
        }))
        .sort((a, b) => a.timestamp - b.timestamp)

      groupMessages.update(gm => {
        gm.set(group.id, messages)
        return gm
      })

      if (owner) await restoreGroupSettings(owner, group.id)
      syncNativeGroupTransport(group.id)

      // Flush any events that arrived before this group was loaded
      flushPendingEvents(group.id)
    }
    if (owner) await restoreOwnReactionAcceptance(owner)
    initGroupRosterFactSync()
  } catch (e) {
    console.error('[groups] Failed to load groups from storage:', e)
  }
}

// Mark incoming group messages as seen locally (used for unread indicators).
export function markGroupMessagesSeen(groupId: string, messageIds: string[]): void {
  if (messageIds.length === 0) return
  const idSet = new Set(messageIds)
  const toAck: string[] = []

  groupMessages.update((gm) => {
    const msgs = gm.get(groupId) || []
    if (msgs.length === 0) return gm

    let changed = false
    const updated = msgs.map((m) => {
      if (!m.isMine && idSet.has(m.id) && m.status !== 'seen') {
        changed = true
        toAck.push(m.id)
        return { ...m, status: 'seen' as const }
      }
      return m
    })

    if (!changed) return gm
    gm.set(groupId, updated)
    return gm
  })

  const owner = getPubkey()
  if (toAck.length) void Promise.all(toAck.map(id => updateMessageStatusInDb(id, 'seen')))
    .then(() => owner ? sendOwnReadState(owner, `group:${groupId}`, toAck) : undefined).catch(() => {})
  const group = get(groups).get(groupId)
  if (toAck.length > 0 && group?.accepted !== false && get(receiptSettings).sendReadReceipts) {
    sendGroupReceipt(groupId, 'seen', toAck)
  }
}

export async function deleteGroup(groupId: string): Promise<void> {
  try {
    getNdrRuntime().removeGroup(groupId)
  } catch {
    // Ignore best-effort runtime cleanup failures.
  }

  groups.update(g => {
    g.delete(groupId)
    return g
  })
  groupMessages.update(gm => {
    gm.delete(groupId)
    return gm
  })

  const currentId = get(currentGroupId)
  if (currentId === groupId) {
    currentGroupId.set(null)
  }

  await deleteGroupFromDb(groupId)
  refreshGroupPushSubscriptions()
  await deleteMessagesForSession(`group:${groupId}`)
}

export function clearGroupData(): void {
  requestProjectionCleanup?.()
  requestProjectionCleanup = undefined
  const groupIds = Array.from(get(groups).keys())
  for (const groupId of groupIds) {
    clearRemoteTyping(`group:${groupId}`)
  }

  // Logout tears down the runtime separately. Do not recreate it after the
  // identity has been cleared or publish an empty group list to other devices.
  groupRosterFactCursors.clear()
  reservedRosterRevisions.clear()
  seenGroupRosterFactIds.clear()
  pendingGroupEvents.clear()
  groups.set(new Map())
  groupMessages.set(new Map())
  currentGroupId.set(null)
}

export function acceptGroupInvitation(groupId: string): void {
  const currentGroups = get(groups)
  const group = currentGroups.get(groupId)
  if (!group || !group.members.includes(getPubkey() || '')) return

  acceptChat(`group:${groupId}`)
  const updated: Group = { ...group, accepted: true }

  groups.update(g => {
    g.set(groupId, updated)
    return g
  })
  saveGroupState(updated)

  syncNativeGroupTransport(groupId)
}
