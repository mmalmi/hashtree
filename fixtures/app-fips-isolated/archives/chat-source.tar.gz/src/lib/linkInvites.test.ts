import { describe, it, expect } from 'vitest'
import { parseLinkInviteInput } from './linkInvites'

const OWNER = 'a'.repeat(64)
const INVITER = 'b'.repeat(64)
const EPHEMERAL = 'c'.repeat(64)
const SECRET = 'd'.repeat(64)

describe('parseLinkInviteInput', () => {
  it('does not upgrade an unversioned link through normalization', () => {
    const payload = { inviter: INVITER, inviterEphemeralPublicKey: EPHEMERAL, sharedSecret: SECRET, purpose: 'link' }
    expect(parseLinkInviteInput(JSON.stringify(payload), OWNER)).toBeNull()
    expect(parseLinkInviteInput(`https://chat.iris.to/#/invite/${encodeURIComponent(JSON.stringify(payload))}`, OWNER)).toBeNull()
  })
  it('parses a full link URL', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      ephemeralKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'link',
    }
    const url = `https://iris.to/#${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeTruthy()
    expect(invite?.inviter).toBe(INVITER)
    expect(invite?.inviterEphemeralPublicKey).toBe(EPHEMERAL)
  })

  it('parses a hash-route link URL', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      ephemeralKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'link',
      owner: OWNER,
    }
    const url = `https://chat.iris.to/#/invite/${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeTruthy()
    expect(invite?.inviter).toBe(INVITER)
    expect(invite?.inviterEphemeralPublicKey).toBe(EPHEMERAL)
  })

  it('parses raw JSON with inviterEphemeralPublicKey', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      inviterEphemeralPublicKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'link',
    }
    const raw = JSON.stringify(payload)
    const invite = parseLinkInviteInput(raw, OWNER)

    expect(invite).toBeTruthy()
    expect(invite?.inviterEphemeralPublicKey).toBe(EPHEMERAL)
  })

  it('parses link URL with inviterEphemeralPublicKey', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      inviterEphemeralPublicKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'link',
    }
    const url = `https://iris.to/#${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeTruthy()
    expect(invite?.inviterEphemeralPublicKey).toBe(EPHEMERAL)
  })

  it('parses link URL without purpose field', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      ephemeralKey: EPHEMERAL,
      sharedSecret: SECRET,
    }
    const url = `https://iris.to/#${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeTruthy()
    expect(invite?.inviterEphemeralPublicKey).toBe(EPHEMERAL)
  })

  it('rejects non-link invites', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      ephemeralKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'chat',
    }
    const url = `https://iris.to/#${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeNull()
  })

  it('rejects mismatched owner', () => {
    const payload = {
      version: 2,
      inviter: INVITER,
      ephemeralKey: EPHEMERAL,
      sharedSecret: SECRET,
      purpose: 'link',
      owner: 'e'.repeat(64),
    }
    const url = `https://iris.to/#${encodeURIComponent(JSON.stringify(payload))}`
    const invite = parseLinkInviteInput(url, OWNER)

    expect(invite).toBeNull()
  })
})
