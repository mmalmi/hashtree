<script lang="ts">
  import { resolvePrivateInvite, inviteFromRecord } from './lib/chat'
  import { requestGroupJoin, groupJoinStatus, retryGroupJoin } from './lib/groupInvites'
  import { loadChatMutes, clearChatMutes } from './lib/chatMuteStore'
  import { loadChatPins, clearChatPins } from './lib/chatPinStore'
  import { onMount } from 'svelte'
  import LoginView from './components/LoginView.svelte'
  import CallView from './components/CallView.svelte'
  import Sidebar from './components/Sidebar.svelte'
  import MainContent from './components/MainContent.svelte'
  import SettingsView from './components/SettingsView.svelte'
  import { parseSettingsRoute, settingsHref, type SettingsPage } from './lib/settingsNavigation'
  import ProfileView from './components/ProfileView.svelte'
  import NotificationPrompt from './components/NotificationPrompt.svelte'
  import InstallPrompt from './components/InstallPrompt.svelte'
  import { nativeAppChatHref } from './lib/nativeApp'
  import { identity, autoLogin, logout } from './lib/identity'
  import { notificationTarget, notificationFromHash, resolveNotificationTarget, type NotificationTarget } from './lib/notificationNavigation'
  import { clearDrafts } from './lib/drafts'
  import { clearMessageRequestDecisions } from './lib/messageRequests'
  import { expirationStore } from './lib/expirationStore'
  import { closeMediaModal } from './lib/mediaModal'
  import { acceptInvite, parseInviteFromHash, isLinkInvite, currentChat, leaveChat, loadChatsFromStorage, clearChatData, chats, loadAndMonitorInvites, setInviteAcceptedCallback, initNdrRuntimeEvents, ingestPushNostrEvent, drainPendingPushNostrEvents } from './lib/chat'
  import { startMessageExpirationCleanup, stopMessageExpirationCleanup } from './lib/messageExpirationCleanup'
  import { syncDisappearingMessagesToNdrRuntime } from './lib/disappearingMessages'
  import type { ChatSession, ChatInvite } from './lib/chat'
  import { closeInviteOnAccept } from './lib/chat'
  import { getErrorMessage } from './lib/utils'
  import { loadGroupsFromStorage, clearGroupData, groups, groupMessages, currentGroupId, type Group } from './lib/groups'
  import { get } from 'svelte/store'
  import { getDelegateManager, initMultiDevice, resetManagers } from './lib/privateChats'
  import { setAttachmentAccount } from './lib/hashtree'
  import { startDeviceSync, stopDeviceSync } from './lib/deviceSync'
  import { deviceHistoryProgress } from './lib/deviceHistoryPolicy'
  import { onCurrentDeviceRemovedFromRoster } from './lib/devices'
  import { PUSH_NOSTR_EVENT_MESSAGE } from './lib/pushEvents'
  import { initFollowing, clearFollowingCache } from './lib/following'
  import { initPeopleGraph } from './lib/peopleGraph'
  import { restoreContactNamesForNotifications } from './lib/contactMemory'
  import { startPrivateContactSync } from './lib/privateContactSync'
  import CreateGroup from './components/CreateGroup.svelte'
  import GroupChatView from './components/GroupChatView.svelte'
  import GroupDetailsView from './components/GroupDetailsView.svelte'

  // Send message to service worker
  onMount(startPrivateContactSync)

  function postToServiceWorker(message: object) {
    console.log('[app] posting to service worker:', message)
    navigator.serviceWorker?.ready.then(reg => {
      console.log('[app] service worker ready, active:', !!reg.active)
      reg.active?.postMessage(message)
    })
  }

  // View routing
  type View = 'chat' | 'settings' | 'profile' | 'createGroup' | 'groupDetails'

  // Retain the original chat destination while web onboarding consumes its hash.
  // Never persist the private invite or pass it to the downloads site.
  function currentNativeEntryHref() {
    const invite = parseInviteFromHash()
    return invite && !isLinkInvite(invite) ? nativeAppChatHref(window.location.href) : null
  }
  let nativeEntryHref = $state(currentNativeEntryHref())
  let nativeEntryIsDeviceLink = $state(isLinkInvite(parseInviteFromHash()))
  function clearNativeEntry() {
    if (nativeEntryHref) setHashSilently('')
    nativeEntryHref = null
  }
  let loggedIn = $state(false)
  let loginView = $state<{ focusName: () => Promise<void> }>()
  let pendingInvite = $state<ChatInvite | null>(parseInviteFromHash())
  let inviteTitle = $state('')
  let groupInviteEntry = $state(false)
  $effect(() => {
    const invite = pendingInvite
    if (!invite || loggedIn) return
    let cancelled = false
    void resolvePrivateInvite(invite).then(record => {
      if (cancelled || !record) return
      groupInviteEntry = record.type === 'group'
      inviteTitle = record.name ? (groupInviteEntry ? `Join ${record.name}` : `Chat with ${record.name}`) : ''
    }).catch(() => {})
    return () => { cancelled = true }
  })
  let joiningInvite = $state(false)
  let joinError = $state('')
  let joinAttempt = 0
  let initializing = $state(true)
  let selectedChat = $state<ChatSession | null>(null)
  let selectedGroupId = $state<string | null>(null)
  let currentView = $state<View>('chat')
  let settingsPage = $state<SettingsPage | null>(null)
  let profilePubkey = $state<string | null>(null)
  // Mobile: which panel to show - 'sidebar' or 'main'
  let mobileView = $state<'sidebar' | 'main'>('sidebar')
  let duplicateTab = $state(false)
  let pendingNotification = $state<NotificationTarget | null>(notificationFromHash(window.location.hash))

  // Consume links at the router, including hash-only navigation from an open
  // chat. Keep a failed invite in memory for Retry, never in browser history.
  $effect(() => {
    if (!loggedIn || initializing || !pendingInvite || isLinkInvite(pendingInvite)) return
    const invite = pendingInvite
    pendingInvite = null
    void joinFromAddress(invite)
  })

  async function joinFromAddress(invite: ChatInvite) {
    const attempt = ++joinAttempt
    const owner = get(identity)?.pubkey
    joiningInvite = true
    joinError = ''
    setHashSilently('')
    selectedChat = null
    selectedGroupId = null
    currentChat.set(null)
    currentView = 'chat'
    mobileView = 'main'
    try {
      const record = await resolvePrivateInvite(invite)
      if (record?.type === 'group') {
        const groupId = await requestGroupJoin(record)
        if (attempt === joinAttempt && get(identity)?.pubkey === owner) handleSelectGroup(groupId)
        return
      }
      const chat = await acceptInvite(record ? { type: 'legacy', invite: inviteFromRecord(record) } : invite)
      if (attempt === joinAttempt && get(identity)?.pubkey === owner) handleSelectChat(chat)
    } catch (error) {
      if (attempt === joinAttempt && get(identity)?.pubkey === owner) {
        failedInvite = invite
        joinError = getErrorMessage(error, 'Could not join chat')
      }
    } finally {
      if (attempt === joinAttempt) joiningInvite = false
    }
  }
  let failedInvite: ChatInvite | null = null

  // A notification may arrive before identity, chats, or groups have loaded.
  $effect(() => {
    const target = pendingNotification
    const owner = $identity?.pubkey
    if (!target || !loggedIn || initializing || !owner) return
    const destination = resolveNotificationTarget(target, owner, new Set($chats.keys()), new Set($groups.keys()))
    if (destination === 'pending') return
    pendingNotification = null
    if (destination === 'discard') {
      if (notificationFromHash(window.location.hash)) setHashSilently('')
      return
    }
    selectedGroupId = destination === 'group' ? target.chatId : null
    selectedChat = destination === 'chat' ? $chats.get(target.chatId)! : null
    currentChat.set(selectedChat)
    navigateTo('chat', false, selectedChat?.id, selectedGroupId ?? undefined)
    mobileView = 'main'
    postToServiceWorker({ type: 'CLEAR_NOTIFICATION', chatId: target.chatId })
  })

  let deviceRemovalLogoutRequested = false
  let deviceRemovalLogoutInProgress = false
  let deviceRemovalNotice = $state(false)

  // If a chat is deleted (e.g. rejected request), ensure we don't keep rendering it.
  $effect(() => {
    const chatId = selectedChat?.id
    if (!chatId) return
    if ($chats.has(chatId)) return
    selectedChat = null
    currentChat.set(null)
    if (currentView === 'chat') {
      mobileView = 'sidebar'
    }
  })

  // Notify service worker when chat is opened/closed
  $effect(() => {
    const chatId = selectedGroupId || selectedChat?.id || null
    postToServiceWorker({ type: 'CHAT_OPENED', chatId })
  })

  // Parse view from URL hash
  function getViewFromHash(): { view: View; profilePubkey?: string; groupId?: string; settingsPage?: SettingsPage | null } {
    const hash = window.location.hash
    const settingsRoute = parseSettingsRoute(hash)
    if (settingsRoute) return { view: 'settings', settingsPage: settingsRoute.page }
    if (hash.startsWith('#profile-')) {
      return { view: 'profile', profilePubkey: hash.slice(9) }
    }
    if (hash === '#create-group') return { view: 'createGroup' }
    if (hash.startsWith('#group-details-')) {
      return { view: 'groupDetails', groupId: hash.slice(15) }
    }
    if (hash.startsWith('#group-')) {
      return { view: 'chat', groupId: hash.slice(7) }
    }
    return { view: 'chat' }
  }

  // Update URL hash without triggering popstate
  function setHashSilently(hash: string) {
    const url = new URL(window.location.href)
    url.hash = hash
    history.replaceState(null, '', url)
  }

  // Navigate to a view with history
  function cancelPendingJoin() {
    joinAttempt++
    joiningInvite = false
    joinError = ''
    failedInvite = null
  }

  function navigateTo(view: View, push = true, pubkey?: string, groupId?: string) {
    cancelPendingJoin()
    pendingNotification = null
    clearNativeEntry()
    currentView = view
    settingsPage = null
    if (view === 'profile' && pubkey) {
      profilePubkey = pubkey
    }
    let hash = ''
    if (view === 'settings') hash = settingsHref()
    else if (view === 'profile' && pubkey) hash = `#profile-${pubkey}`
    else if (view === 'createGroup') hash = '#create-group'
    else if (view === 'groupDetails' && groupId) hash = `#group-details-${groupId}`
    else if (view === 'chat' && groupId) hash = `#group-${groupId}`
    else if (view === 'chat' && pubkey) hash = `#chat-${encodeURIComponent(pubkey)}`

    if (push) {
      history.pushState({ view, pubkey, groupId }, '', hash || window.location.pathname)
    } else {
      setHashSilently(hash)
    }
  }

  // Navigate to profile
  function navigateToProfile(pubkey: string) {
    navigateTo('profile', true, pubkey)
    mobileView = 'main'
  }

  onMount(() => {
    const handleNotificationHash = () => {
      const target = notificationFromHash(window.location.hash)
      if (target) pendingNotification = target
    }
    window.addEventListener('hashchange', handleNotificationHash)
    let cleanup: (() => void) | undefined
    const stopFollowing = initFollowing()
    const stopPeopleGraph = initPeopleGraph()
    const stopCurrentDeviceRemovalLogout = onCurrentDeviceRemovedFromRoster(() => {
      requestDeviceRemovalLogout()
    })
    cleanup = () => {
      stopFollowing()
      stopPeopleGraph()
      stopCurrentDeviceRemovalLogout()
    }

    // Run async initialization
    ;(async () => {
    // Prevent multiple tabs - encryption state can't sync between them
    // Use sessionStorage to persist tab identity across hot reloads
    let tabId = sessionStorage.getItem('iris-tab-id')
    if (!tabId) {
      tabId = Math.random().toString(36).slice(2)
      sessionStorage.setItem('iris-tab-id', tabId)
    }
    const channel = new BroadcastChannel('iris-chat-tab')
    channel.postMessage({ type: 'ping', tabId })
    channel.onmessage = (e) => {
      if (e.data?.tabId === tabId) return // Ignore own messages
      if (e.data?.type === 'ping' && !duplicateTab) {
        channel.postMessage({ type: 'pong', tabId })
      } else if (e.data?.type === 'pong') {
        duplicateTab = true
        initializing = false
      }
    }

    // Small delay to detect existing tabs
    await new Promise(r => setTimeout(r, 100))
    if (duplicateTab) return

    // Check for invite in URL hash (invite hashes start with #invite-)
    const hashInvite = parseInviteFromHash()

    // Set initial view from URL hash (only if not an invite)
    if (!hashInvite) {
      const hashState = getViewFromHash()
      currentView = hashState.view
      settingsPage = hashState.settingsPage ?? null
      if (hashState.view === 'profile' && hashState.profilePubkey) {
        profilePubkey = hashState.profilePubkey
        mobileView = 'main'
      } else if (hashState.view === 'settings') {
        mobileView = 'main'
      } else if (hashState.groupId) {
        selectedGroupId = hashState.groupId
        selectedChat = null
        currentChat.set(null)
        mobileView = 'main'
      }
    }

    // Listen for browser back/forward
    const handlePopState = () => {
      if (notificationFromHash(window.location.hash)) { handleNotificationHash(); return }
      const hashState = getViewFromHash()
      currentView = hashState.view
      settingsPage = hashState.settingsPage ?? null
      if (hashState.view === 'profile' && hashState.profilePubkey) {
        profilePubkey = hashState.profilePubkey
        mobileView = 'main'
      } else if (hashState.groupId && hashState.view === 'chat') {
        selectedGroupId = hashState.groupId
        selectedChat = null
        currentChat.set(null)
        mobileView = 'main'
      } else if (hashState.view === 'groupDetails' && hashState.groupId) {
        selectedGroupId = hashState.groupId
        mobileView = 'main'
      } else if (hashState.view === 'createGroup' || hashState.view === 'settings') {
        mobileView = 'main'
      } else {
        selectedGroupId = null
        mobileView = 'sidebar'
      }
    }
    window.addEventListener('popstate', handlePopState)

    // Listen for notification clicks from service worker
    const handleServiceWorkerMessage = (event: MessageEvent) => {
      if (event.data?.type === 'NOTIFICATION_CLICK') {
        const target = notificationTarget(event.data.target ?? event.data)
        if (target) {
          pendingNotification = target
          event.ports[0]?.postMessage({ received: true })
        }
      }
      if (event.data?.type === PUSH_NOSTR_EVENT_MESSAGE && event.data?.event && loggedIn) {
        void ingestPushNostrEvent(event.data.event)
      }
    }
    navigator.serviceWorker?.addEventListener('message', handleServiceWorkerMessage)

    // Handle GET_OPEN_CHAT queries from service worker (via MessageChannel)
    const handleGetOpenChat = (event: MessageEvent) => {
      if (event.data?.type === 'GET_OPEN_CHAT' && event.ports[0]) {
        const chatId = document.visibilityState === 'visible' ? (selectedGroupId || selectedChat?.id || null) : null
        console.log('[app] GET_OPEN_CHAT response:', chatId)
        event.ports[0].postMessage({ chatId })
      }
    }
    navigator.serviceWorker?.addEventListener('message', handleGetOpenChat)

    // Try to auto-login
    const isLoggedIn = await autoLogin()

    if (isLoggedIn) {
      const currentIdentity = get(identity)
      let multiDeviceReady: Promise<void> | null = null
      if (currentIdentity?.pubkey) {
        // Subscribe ASAP so we don't miss early incoming manager events.
        initNdrRuntimeEvents()
        multiDeviceReady = initMultiDevice(currentIdentity.pubkey)
      }

      // Load groups FIRST so group events have somewhere to land
      // (chat sessions subscribe to relays on load — group messages arriving
      //  before the groups store is populated are silently dropped)
      await loadGroupsFromStorage()

      // Load saved chats from IndexedDB (creates relay subscriptions)
      await loadChatsFromStorage()

      if (currentIdentity?.pubkey && multiDeviceReady) {
        void multiDeviceReady
          .then(() => startDeviceSync(currentIdentity.pubkey, getDelegateManager().getIdentityKey()))
          .catch((e) => console.error('[app] initMultiDevice failed:', e))
      }

      // Set callback for invite acceptance (works for both loaded and new invites)
      setInviteAcceptedCallback(handleInviteAccepted)

      // Load and monitor saved invites
      await loadAndMonitorInvites()

      // Start message expiration cleanup and sync settings
      startMessageExpirationCleanup()
      syncDisappearingMessagesToNdrRuntime().catch(() => {})
      void drainPendingPushNostrEvents()

      loggedIn = true
      void flushDeviceRemovalLogout()

      // If there's an invite in URL, show main view to handle it
      if (hashInvite) {
        mobileView = 'main'
      }


    }

    initializing = false

    // Track visibility changes to update service worker
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        if (loggedIn) void drainPendingPushNostrEvents()
        if (selectedChat) {
          postToServiceWorker({ type: 'CHAT_OPENED', chatId: selectedChat.id })
        }
      } else if (document.visibilityState === 'hidden') {
        postToServiceWorker({ type: 'CHAT_OPENED', chatId: null })
      }
    }
    document.addEventListener('visibilitychange', handleVisibilityChange)

    cleanup = () => {
      void stopDeviceSync()
      window.removeEventListener('popstate', handlePopState)
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      navigator.serviceWorker?.removeEventListener('message', handleServiceWorkerMessage)
      navigator.serviceWorker?.removeEventListener('message', handleGetOpenChat)
      stopFollowing()
      stopCurrentDeviceRemovalLogout()
    }
    })()

    return () => { window.removeEventListener('hashchange', handleNotificationHash); cleanup?.() }
  })

  async function handleLogin() {
    deviceRemovalNotice = false
    const currentIdentity = get(identity)
    let multiDeviceReady: Promise<void> | null = null
    if (currentIdentity?.pubkey) {
      // Subscribe ASAP so we don't miss early incoming manager events.
      initNdrRuntimeEvents()
      multiDeviceReady = initMultiDevice(currentIdentity.pubkey)
    }

    loggedIn = true
    void flushDeviceRemovalLogout()

    // Load groups FIRST (same reason as onMount — avoid race condition)
    await loadGroupsFromStorage()

    // Load saved chats from IndexedDB (creates relay subscriptions)
    await loadChatsFromStorage()

    if (currentIdentity?.pubkey && multiDeviceReady) {
      void multiDeviceReady
        .then(() => startDeviceSync(currentIdentity.pubkey, getDelegateManager().getIdentityKey()))
        .catch((e) => console.error('[app] initMultiDevice failed:', e))
    }

    // Set callback for invite acceptance (works for both loaded and new invites)
    setInviteAcceptedCallback(handleInviteAccepted)

    // Load and monitor saved invites
    await loadAndMonitorInvites()

    // Start message expiration cleanup and sync settings
    startMessageExpirationCleanup()
    syncDisappearingMessagesToNdrRuntime().catch(() => {})
    void drainPendingPushNostrEvents()
  }

  function handleSelectGroup(groupId: string) {
    selectedGroupId = groupId
    selectedChat = null
    currentChat.set(null)
    navigateTo('chat', true, undefined, groupId)
    mobileView = 'main'
  }

  function handleNewGroup() {
    navigateTo('createGroup')
    mobileView = 'main'
  }

  function handleGroupCreated(group: Group) {
    selectedGroupId = group.id
    selectedChat = null
    currentChat.set(null)
    navigateTo('chat', true, undefined, group.id)
    mobileView = 'main'
  }

  function handleGroupDetails() {
    if (selectedGroupId) {
      navigateTo('groupDetails', true, undefined, selectedGroupId)
    }
  }

  function handleGroupDetailsBack() {
    history.back()
  }

  function handleGroupDeleted() {
    selectedGroupId = null
    navigateTo('chat')
    mobileView = 'sidebar'
  }

  function handleInviteAccepted(chat: ChatSession) {
    // Only open automatically while the user is on the explicit New Chat screen.
    if (currentView !== 'chat' || mobileView !== 'main' || selectedChat || selectedGroupId) return
    if (!get(closeInviteOnAccept)) return
    handleSelectChat(chat)
  }

  function handleSelectChat(chat: ChatSession) {
    cancelPendingJoin()
    clearNativeEntry()
    selectedChat = chat
    currentChat.set(chat)
    selectedGroupId = null
    navigateTo('chat', true, chat.id)
    mobileView = 'main'
    // Tell service worker this chat is now open (suppresses notifications)
    postToServiceWorker({ type: 'CHAT_OPENED', chatId: chat.id })
    // Clear any existing notification for this chat
    postToServiceWorker({ type: 'CLEAR_NOTIFICATION', chatId: chat.id })
  }

  function handleChatJoined(event: CustomEvent<{ chat: ChatSession }>) {
    setHashSilently('')
    handleSelectChat(event.detail.chat)
  }

  function handleNewChat() {
    cancelPendingJoin()
    clearNativeEntry()
    selectedChat = null
    currentChat.set(null)
    selectedGroupId = null
    if (currentView !== 'chat' || window.location.hash) {
      navigateTo('chat')
    }
    mobileView = 'main'
  }

  function handleBack() {
    cancelPendingJoin()
    clearNativeEntry()
    selectedChat = null
    currentChat.set(null)
    selectedGroupId = null
    // Tell service worker no chat is open
    postToServiceWorker({ type: 'CHAT_OPENED', chatId: null })
    if (currentView !== 'chat' || window.location.hash) {
      navigateTo('chat')
    }
    mobileView = 'sidebar'
  }

  function handleSettings() {
    navigateTo('settings')
    mobileView = 'main'
  }

  function handleSettingsBack() {
    if (settingsPage !== null) {
      if (history.state?.settingsMenuParent) history.back()
      else {
        settingsPage = null
        setHashSilently(settingsHref())
      }
      return
    }
    // Also works when Settings was opened directly or restored after a reload.
    // Never send the user out of the app through an unrelated history entry.
    navigateTo('chat', false, undefined, selectedGroupId ?? undefined)
    mobileView = 'sidebar'
  }

  function handleSettingsPage(page: SettingsPage) {
    if (page === settingsPage) return
    const settingsMenuParent = settingsPage === null
    settingsPage = page
    history.pushState({ view: 'settings', settingsMenuParent }, '', settingsHref(page))
  }

  function handleProfileBack() {
    history.back()
  }

  async function handleOpenChatFromProfile(pubkey: string) {
    const account = get(identity)?.pubkey
    const chat = get(chats).get(pubkey) ?? await acceptInvite({ type: 'pubkey', pubkey })
    if (get(identity)?.pubkey !== account) return
    selectedChat = chat
    currentChat.set(chat)
    navigateTo('chat')
    mobileView = 'main'
  }

  $effect(() => { void loadChatMutes($identity?.pubkey ?? null); void loadChatPins($identity?.pubkey ?? null) })
  $effect(() => { restoreContactNamesForNotifications($identity?.pubkey ?? null) })
  $effect(() => { setAttachmentAccount($identity?.pubkey ?? null) })

  async function handleLogout() {
    cancelPendingJoin()
    const owner = get(identity)?.pubkey
    pendingNotification = null
    stopMessageExpirationCleanup()
    await clearChatMutes()
    await clearChatPins()
    await stopDeviceSync()
    leaveChat()
    clearGroupData()
    resetManagers()
    logout()
    await clearChatData()
    clearDrafts()
    closeMediaModal()
    clearMessageRequestDecisions()
    expirationStore.clear()
    if (owner) clearFollowingCache(owner)
    // Prevent a previous profile's alerts remaining after this browser signs out.
    const registration = await navigator.serviceWorker?.getRegistration().catch(() => undefined)
    await registration?.getNotifications().then(items => items.forEach(item => item.close())).catch(() => {})
    loggedIn = false
    selectedChat = null
    selectedGroupId = null
    navigateTo('chat', false)
    mobileView = 'sidebar'
  }

  function requestDeviceRemovalLogout() {
    deviceRemovalLogoutRequested = true
    void flushDeviceRemovalLogout()
  }

  async function flushDeviceRemovalLogout() {
    if (
      !deviceRemovalLogoutRequested ||
      deviceRemovalLogoutInProgress ||
      !loggedIn
    ) {
      return
    }

    deviceRemovalLogoutInProgress = true
    try {
      await handleLogout()
      deviceRemovalNotice = true
    } catch (error) {
      console.error('[app] failed to logout after current device removal:', error)
    } finally {
      deviceRemovalLogoutInProgress = false
      deviceRemovalLogoutRequested = false
    }
  }
</script>

<svelte:window onhashchange={() => {
  nativeEntryHref = currentNativeEntryHref()
  nativeEntryIsDeviceLink = isLinkInvite(parseInviteFromHash())
  pendingInvite = parseInviteFromHash()
  const settingsRoute = parseSettingsRoute(window.location.hash)
  if (settingsRoute) {
    currentView = 'settings'
    settingsPage = settingsRoute.page
    mobileView = 'main'
  }
}} />

<main class="min-h-[100dvh] h-[100dvh] bg-app text-apptext overflow-hidden">
  {#if initializing}
    <div class="h-full flex items-center justify-center">
      <div class="text-center">
        <div class="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p class="text-gray-400">Loading...</p>
      </div>
    </div>
  {:else if duplicateTab}
    <div class="h-full flex flex-col items-center justify-center p-4">
      <div class="text-center flex flex-col items-center select-none">
        <img src={`${import.meta.env.BASE_URL}iris-logo.png`} alt="Iris" class="w-16 h-16 mb-4 opacity-50" draggable="false" />
        <h1 class="text-2xl font-bold text-gray-400 mb-4">Already open in another tab</h1>
        <p class="text-gray-500 max-w-sm">
          iris chat can only run in one tab at a time to keep your encrypted messages in sync.
        </p>
      </div>
    </div>
  {:else if !loggedIn}
    <div class="h-full overflow-y-auto p-4">
      <div class="min-h-full flex flex-col items-center justify-center py-4">
        <div class="mb-8 text-center flex flex-col items-center select-none shrink-0">
          <img src={`${import.meta.env.BASE_URL}iris-logo.png`} alt="Iris" class="w-16 h-16 mb-4" draggable="false" />
          <h1 class="text-4xl font-bold">
            <span class="text-primary">iris</span> chat
          </h1>
          <p class="text-gray-400 mt-2">Secure, private messaging</p>
        </div>
        {#if deviceRemovalNotice}
          <p role="status" class="mb-6 max-w-sm text-center text-gray-400">This device was removed. Its local data has been cleared.</p>
        {/if}
        <LoginView bind:this={loginView} onlogin={handleLogin} {inviteTitle} groupInvite={groupInviteEntry} />
      </div>
    </div>
  {:else}
    <div class="h-full flex flex-col">
      <!-- Notification prompt -->
      <NotificationPrompt />
      {#if $deviceHistoryProgress}
        <div role="status" class="px-4 py-2 text-center text-sm text-gray-400" data-testid="device-history-progress">
          {#if $deviceHistoryProgress.phase === 'waiting'}
            Waiting for your other device…
          {:else}
            Syncing messages…
            {#if $deviceHistoryProgress.total !== undefined}
              <span class="ml-2">{$deviceHistoryProgress.imported} / {$deviceHistoryProgress.total}</span>
            {/if}
          {/if}
        </div>
      {/if}

      <!-- Main app layout -->
      <div class="flex flex-1 min-h-0">
        <!-- Sidebar - always visible on desktop, conditionally on mobile -->
        <div class="
          md:w-80 lg:w-96 flex-shrink-0 h-full
          {mobileView === 'sidebar' ? 'block w-full' : 'hidden'} md:block
        ">
          <Sidebar
            selectedChatId={selectedChat?.id || null}
            {selectedGroupId}
            onSelectChat={handleSelectChat}
            onSelectGroup={handleSelectGroup}
            onNewChat={handleNewChat}
            onSettings={handleSettings}
            onNavigateHome={handleBack}
          />
        </div>

        <!-- Main content - always visible on desktop, conditionally on mobile -->
        <div class="
          flex-1 flex flex-col bg-panel h-full min-h-0 min-w-0
          {mobileView === 'main' ? 'flex w-full' : 'hidden'} md:flex md:w-auto
        ">
          {#if currentView === 'settings'}
            <SettingsView page={settingsPage} onNavigate={handleSettingsPage} onBack={handleSettingsBack} onLogout={handleLogout} />
          {:else if currentView === 'profile' && profilePubkey}
            <ProfileView
              pubkey={profilePubkey}
              onBack={handleProfileBack}
              onOpenChat={handleOpenChatFromProfile}
            />
          {:else if currentView === 'createGroup'}
            <CreateGroup
              onBack={handleBack}
              onGroupCreated={handleGroupCreated}
            />
          {:else if currentView === 'groupDetails' && selectedGroupId && $groups.get(selectedGroupId)}
            <GroupDetailsView
              group={$groups.get(selectedGroupId)!}
              onBack={handleGroupDetailsBack}
              onDeleted={handleGroupDeleted}
              onViewProfile={navigateToProfile}
            />
          {:else if selectedGroupId && $groups.get(selectedGroupId)}
            <GroupChatView
              group={$groups.get(selectedGroupId)!}
              onleave={handleBack}
              showBackButton={mobileView === 'main'}
              onViewDetails={handleGroupDetails}
            />
          {:else if selectedGroupId}
            <div class="flex-1 flex flex-col items-center justify-center gap-4 p-6">
              <p role="status" class="text-gray-400">{$groupJoinStatus[selectedGroupId] || 'Waiting for the group admin to connect…'}</p>
              <button class="btn-secondary" onclick={() => { if (selectedGroupId) void retryGroupJoin(selectedGroupId).catch(error => groupJoinStatus.update(s => ({ ...s, [selectedGroupId!]: getErrorMessage(error, 'Could not join group') }))) }}>Retry</button>
            </div>
          {:else}
            {#if joiningInvite || joinError}
              <div class="flex-1 flex flex-col items-center justify-center gap-4 p-6">
                {#if joiningInvite}
                  <p role="status" class="text-gray-400">Joining chat…</p>
                {:else}
                  <p role="alert" class="text-red-400">{joinError}</p>
                  <button class="btn-primary" onclick={() => { if (failedInvite) void joinFromAddress(failedInvite) }}>Retry</button>
                {/if}
              </div>
            {:else}
              <MainContent
                chat={selectedChat}
                onChatJoined={handleChatJoined}
                onBack={handleBack}
                showBackButton={mobileView === 'main'}
                onViewProfile={navigateToProfile}
                onCreateGroup={handleNewGroup}
              />
            {/if}
          {/if}
        </div>
      </div>
    </div>
  {/if}

</main>

{#if !initializing && !duplicateTab}
  <InstallPrompt entryHref={nativeEntryHref} welcome={!loggedIn} excluded={nativeEntryIsDeviceLink} {inviteTitle}
    ondismiss={() => { void loginView?.focusName() }} />
{/if}

<CallView />
