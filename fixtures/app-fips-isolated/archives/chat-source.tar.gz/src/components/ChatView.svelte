<script lang="ts">
  import { displayMentions } from '../lib/mentions'
  import ComposerInput from './ComposerInput.svelte'
  import ChatPinButton from './ChatPinButton.svelte'
  import { onDestroy } from 'svelte'
  import { createAttachmentDraft, filesFromTransfer, hasFileData } from '../lib/attachmentDraft'
  import { createDirectFileDraft, directFileSelectionMode, formatDirectFileSize } from '../lib/directFileDraft'
  import { sendDirectFiles } from '../lib/directFiles'
  import { directFilePreview } from '../lib/directFileProtocol'
  import { sendMessage, sendReaction, sendSeenReceipts, sendTypingEvent, deleteChat, deleteMessage, editMessage, deleteMessageForEveryone, type ChatSession, type ChatMessage, currentChat, chats } from '../lib/chat'
  import { privateBlockedContacts } from '../lib/privateBlockProjection'
  import { identity } from '../lib/identity'
  import { following } from '../lib/following'
  import { messageRequests, requestDecisionsByChat, acceptChat, rejectChat } from '../lib/messageRequests'
  import { messageRequestSettings } from '../lib/messageRequestSettings'
  import { isMessageRequestChat, type MessageRequestPolicyContext } from '../lib/messageRequestPolicy'
  import { isTyping } from '../lib/typingState'
  import { createTypingThrottle } from '../lib/typingState'
  import { uploadFile, formatFileLink, isImageFile, isVideoFile } from '../lib/hashtree'
  import { getDraft, setDraft, clearDraft } from '../lib/drafts'
  import { formatDayLabel, getErrorMessage, isDifferentDay } from '../lib/utils'
  import { mediaModal, closeMediaModal } from '../lib/mediaModal'
  import { expirationStore } from '../lib/expirationStore'
  import { setDmDisappearingMessages } from '../lib/disappearingMessages'
  import { getExpirationLabel } from '../lib/expiration'
  import { buildDisappearingNotice, normalizeDisappearingTtl } from '../lib/disappearingNotice'
  import Avatar from './Avatar.svelte'
  import { startCall, callState } from '../lib/calls'
  import { callSettings } from '../lib/callSettings'
  import Name from './Name.svelte'
  import MessageBubble from './MessageBubble.svelte'
  import CallHistoryRow from './CallHistoryRow.svelte'
  import MediaModal from './MediaModal.svelte'
  import VoiceRecorder from './VoiceRecorder.svelte'
  import ChatMuteModal from './ChatMuteModal.svelte'
  import { chatMutes } from '../lib/chatMuteStore'
  import { isChatMuted } from '../lib/chatMutePolicy'
  import DisappearingMessagesModal from './DisappearingMessagesModal.svelte'
  import EmojiPicker from './EmojiPicker.svelte'
  import ContactMemory from './ContactMemory.svelte'
  import { contactMemory, rememberContact } from '../lib/contactMemory'
  import type { AcceptedNameChange } from '@iris/svelte-ui/contactMemory'

  interface Props {
    chat: ChatSession
    onleave: () => void
    showBackButton?: boolean
    onViewProfile?: (pubkey: string) => void
  }

  let { chat, onleave, showBackButton = true, onViewProfile }: Props = $props()
  let showEmojiPicker = $state(false)
  const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)

  // svelte-ignore state_referenced_locally — initial values; the $effect below handles chat switching
  let messageText = $state(getDraft(chat.id))
  let messagesContainer = $state<HTMLDivElement | null>(null)
  let inputRef = $state<HTMLTextAreaElement | null>(null)
  let fileInputRef = $state<HTMLInputElement | null>(null)
  let directFileInputRef = $state<HTMLInputElement | null>(null)
  let showAttachmentMenu = $state(false)
  let attachmentMenuRef = $state<HTMLDivElement | null>(null)
  let sendingDirectFiles = $state(false)
  let showMenu = $state(false)
  let showMuteModal = $state(false)
  const attachmentContext = () => `${$identity?.pubkey || ''}:chat:${chat.id}`
  const attachmentDraft = createAttachmentDraft({
    context: attachmentContext,
    upload: (file, progress) => uploadFile(file, progress, { staged: true }),
    canPreview: file => file.size < 10 * 1024 * 1024 && (isImageFile(file.name) || isVideoFile(file.name)),
  })
  const directFileDraft = createDirectFileDraft(attachmentContext)
  let isFileDrag = $state(false)
  let attachmentError = $state<string | null>(null)
  let uploadingAttachments = $derived($attachmentDraft.some(item => item.uploading))
  $effect(() => {
    attachmentDraft.setContext(attachmentContext())
    directFileDraft.setContext(attachmentContext())
  })
  $effect(() => {
    if (!showAttachmentMenu) return
    const close = (event: PointerEvent) => {
      if (!attachmentMenuRef?.contains(event.target as Node)) showAttachmentMenu = false
    }
    document.addEventListener('pointerdown', close)
    return () => document.removeEventListener('pointerdown', close)
  })
  let isRecordingVoice = $state(false)
  let recordingContext: string | null = null
  // svelte-ignore state_referenced_locally
  let activeChatId = $state(chat.id)
  let replyingTo = $state<ChatMessage | null>(null)
  let showDisappearingModal = $state(false)

  let currentTtl = $derived($expirationStore.expirations[chat.id])
  let disappearingNotice = $state<string | null>(null)
  let lastSeenDisappearingTtl = $state<number | null | undefined>(undefined)
  let disappearingNoticeTimer = $state<ReturnType<typeof setTimeout> | null>(null)
  let myPubkey = $derived($identity?.pubkey || null)
  let memory = $derived.by(() => { $contactMemory; return contactMemory.get(myPubkey ?? '', chat.recipientPubkey) })
  $effect(() => { if (myPubkey) { try { rememberContact(myPubkey, chat.recipientPubkey) } catch { /* Local storage can be unavailable. */ } } })

  async function handleSetDisappearing(ttlSeconds: number | null) {
    await setDmDisappearingMessages(chat.id, ttlSeconds)
  }

  let policyCtx = $derived.by((): MessageRequestPolicyContext => ({
    myPubkey: $identity?.pubkey || null,
    following: $following,
    acceptedChats: $messageRequests.acceptedChats,
    decisions: requestDecisionsByChat($identity?.pubkey ?? ''),
    rejectedChats: $messageRequests.rejectedChats,
    receiveMessageRequests: $messageRequestSettings.receiveMessageRequests,
  }))

  let effectiveChat = $derived($currentChat || chat)
  let isRequest = $derived(isMessageRequestChat(effectiveChat, policyCtx))
  let blocked = $derived(!!$identity && !!$privateBlockedContacts.get($identity.pubkey)?.has(chat.recipientPubkey))
  let attachmentAllowed = $derived(!!$identity && $chats.has(chat.id) && !blocked && !isRequest && !$messageRequests.rejectedChats[chat.recipientPubkey])
  let canAttach = $derived(attachmentAllowed && !isRecordingVoice && !sendingDirectFiles)
  $effect(() => {
    if (!attachmentAllowed) {
      attachmentDraft.clear()
      directFileDraft.clear()
      showAttachmentMenu = false
      isRecordingVoice = false
      recordingContext = null
      isFileDrag = false
    }
  })

  // Throttled typing event sender - recreated per chat
  let sendThrottledTyping = $derived(createTypingThrottle(() => sendTypingEvent(chat), 3000))

  // Send typing event when user types (imperative, not reactive)
  function handleTypingInput() {
    if (messageText.trim()) {
      sendThrottledTyping.fire()
    }
  }

  // Save draft for old chat and restore draft for new chat when switching
  $effect(() => {
    const newChatId = chat.id
    if (newChatId !== activeChatId) {
      // Save current draft for the old chat
      setDraft(activeChatId, messageText)
      // Restore draft for the new chat
      messageText = getDraft(newChatId)
      isRecordingVoice = false
      recordingContext = null
      replyingTo = null
      isFileDrag = false
      attachmentError = null
      showAttachmentMenu = false
      activeChatId = newChatId
    }
  })

  // Continuously persist draft while typing
  $effect(() => {
    setDraft(activeChatId, messageText)
  })


  function handleDelete() {
    deleteChat(chat)
    onleave()
  }

  function handleAcceptRequest() {
    acceptChat(chat.recipientPubkey)
    requestAnimationFrame(() => inputRef?.focus())
  }

  function handleRejectRequest() {
    rejectChat(chat.recipientPubkey)
    deleteChat(chat)
    onleave()
  }

  let preparingAttachments = $state(false)
  async function handleSend() {
    if (!canSend) return
    if ($directFileDraft.length) { void handleSendDirectFiles(); return }
    // Build message with attachment link if present
    let text = messageText.trim()

    for (const attachment of $attachmentDraft) {
      if (!attachment.nhash) continue
      const link = formatFileLink(attachment.nhash, attachment.file.name)
      text = text ? `${text}\n${link}` : link
    }

    if (!text) return
    const context = attachmentContext()
    preparingAttachments = true
    try {
      if (!await attachmentDraft.retain() || context !== attachmentContext()) return
    } catch { attachmentError = 'Could not save this attachment. Try adding it again.'; return }
    finally { preparingAttachments = false }

    const replyToId = replyingTo?.id
    messageText = ''
    clearDraft(chat.id)
    clearAttachment(true)
    replyingTo = null
    sendThrottledTyping.reset()

    sendMessage(chat, text, replyToId)

    requestAnimationFrame(() => inputRef?.focus())
  }

  async function handleSendDirectFiles() {
    const context = attachmentContext()
    const caption = messageText
    sendingDirectFiles = true
    attachmentError = null
    try {
      await sendDirectFiles(chat, $directFileDraft.map(item => item.file), caption.trim())
      if (context !== attachmentContext()) return
      if (messageText === caption) { messageText = ''; clearDraft(chat.id) }
      clearAttachment()
      replyingTo = null
      sendThrottledTyping.reset()
      requestAnimationFrame(() => inputRef?.focus())
    } catch (error) {
      if (context === attachmentContext()) attachmentError = getErrorMessage(error, 'Couldn’t offer files. Try again.')
    } finally { sendingDirectFiles = false }
  }

  function handleKeydown(e: KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    } else if (e.key === 'Escape') {
      showAttachmentMenu = false
      if (replyingTo) {
        replyingTo = null
      } else {
        inputRef?.blur()
      }
    }
  }

  function handleReply(message: ChatMessage) {
    replyingTo = message
    requestAnimationFrame(() => inputRef?.focus())
  }

  async function handleReact(messageId: string, emoji: string) {
    try {
      await sendReaction(chat, messageId, emoji)
    } catch (e) {
      console.error('Failed to send reaction:', e)
    }
  }

  async function handleDeleteMessage(messageId: string) {
    await deleteMessage(chat.id, messageId)
  }

  function clearAttachment(retain = false) {
    attachmentDraft.clear(retain)
    directFileDraft.clear()
    attachmentError = null
  }

  function startVoiceRecording() {
    if (!canAttach) return
    recordingContext = attachmentContext()
    isRecordingVoice = true
  }

  async function handleVoiceRecorded(file: File) {
    if (recordingContext !== attachmentContext() || !attachmentAllowed) return
    recordingContext = null
    isRecordingVoice = false
    clearAttachment()
    const context = attachmentContext()
    const completed = await attachmentDraft.add([file])
    // Keep the existing voice-send flow, but never send a removed recording,
    // another selection, or a draft opened while this recording was uploading.
    if (context === attachmentContext() && completed.length === 1 &&
        $attachmentDraft.length === 1 && $attachmentDraft[0].id === completed[0]) handleSend()
  }

  function handleVoiceCancel() { isRecordingVoice = false; recordingContext = null }

  function attachFiles(files: File[], selectedDirectly = false) {
    if (!canAttach || files.length === 0) return
    attachmentError = null
    if (directFileSelectionMode($directFileDraft.length, $attachmentDraft.length, selectedDirectly)) {
      directFileDraft.add(files)
    } else {
      void attachmentDraft.add(files)
    }
    inputRef?.focus()
  }

  function handleFileSelect(e: Event) {
    const input = e.target as HTMLInputElement
    const files = Array.from(input.files || [])
    input.value = ''
    attachFiles(files)
  }

  function handleDirectFileSelect(e: Event) {
    const input = e.target as HTMLInputElement
    const files = Array.from(input.files || [])
    input.value = ''
    // An upload draft cannot become a private direct selection after upload.
    if ($attachmentDraft.length) return
    attachFiles(files, true)
  }

  function handleDrop(e: DragEvent) {
    isFileDrag = false
    if (!hasFileData(e.dataTransfer)) {
      // Do not let a dragged web link navigate away from the unsent draft.
      if (Array.from(e.dataTransfer?.types || []).includes('text/uri-list')) e.preventDefault()
      return
    }
    e.preventDefault()
    e.stopPropagation()
    if (!canAttach) return
    const files = filesFromTransfer(e.dataTransfer)
    if (!files) { attachmentError = 'Choose files, not folders'; return }
    attachFiles(files)
  }

  function handleDragOver(e: DragEvent) {
    if (!hasFileData(e.dataTransfer)) {
      // Do not let a dragged web link navigate away from the unsent draft.
      if (Array.from(e.dataTransfer?.types || []).includes('text/uri-list')) e.preventDefault()
      return
    }
    e.preventDefault()
    if (e.dataTransfer) e.dataTransfer.dropEffect = canAttach ? 'copy' : 'none'
    isFileDrag = canAttach
  }

  function handleDragLeave(e: DragEvent) {
    if (!(e.currentTarget as HTMLElement).contains(e.relatedTarget as Node | null)) isFileDrag = false
  }

  function handlePaste(e: ClipboardEvent) {
    const files = filesFromTransfer(e.clipboardData)
    if (!files || !canAttach) return
    e.preventDefault()
    attachFiles(files)
  }

  // Cleanup preview URLs on destroy
  onDestroy(() => {
    recordingContext = null
    attachmentDraft.clear()
    directFileDraft.clear()
    if (disappearingNoticeTimer) {
      clearTimeout(disappearingNoticeTimer)
      disappearingNoticeTimer = null
    }
  })

  $effect(() => {
    const normalizedTtl = normalizeDisappearingTtl(currentTtl)
    if (lastSeenDisappearingTtl === undefined) {
      lastSeenDisappearingTtl = normalizedTtl
      return
    }
    if (lastSeenDisappearingTtl === normalizedTtl) return
    lastSeenDisappearingTtl = normalizedTtl

    disappearingNotice = buildDisappearingNotice(normalizedTtl)
    if (disappearingNoticeTimer) clearTimeout(disappearingNoticeTimer)
    disappearingNoticeTimer = setTimeout(() => {
      disappearingNotice = null
      disappearingNoticeTimer = null
    }, 3000)
  })

  // Track whether user is scrolled near the bottom
  let isAtBottom = $state(true)

  function handleMessagesScroll() {
    if (!messagesContainer) return
    const { scrollTop, scrollHeight, clientHeight } = messagesContainer
    isAtBottom = scrollHeight - scrollTop - clientHeight < 100
  }

  function scrollToBottom() {
    if (!messagesContainer) return
    messagesContainer.scrollTo({ top: messagesContainer.scrollHeight, behavior: 'smooth' })
  }

  // Auto-scroll to bottom when new messages arrive or typing indicator appears
  $effect(() => {
    if (!messagesContainer) return
    $currentChat?.messages.length
    $isTyping.get(chat.id)
    if (isAtBottom) {
      messagesContainer.scrollTop = messagesContainer.scrollHeight
    }
  })

  // Autofocus input when chat opens or changes
  $effect(() => {
    chat.id
    if (inputRef) {
      inputRef.focus()
    }
  })

  // Send seen receipts for incoming messages when chat is open
  $effect(() => {
    const msgs = $currentChat?.messages || chat.messages
    const unseenIncoming = msgs.filter(m => !m.isMine && m.status !== 'seen')
    if (unseenIncoming.length > 0) {
      sendSeenReceipts(chat, unseenIncoming.map(m => m.id))
    }
  })

  type TimelineMessage = ChatMessage & { nameChange?: AcceptedNameChange }
  let messages: TimelineMessage[] = $derived([
    ...($currentChat?.messages || chat.messages),
    ...(memory?.name_changes ?? []).map((change, index) => ({
      id: `local-name-change-${index}`, content: '', timestamp: change.accepted_at_secs * 1000,
      isMine: true, nameChange: change,
    })),
  ].sort((a, b) => a.timestamp - b.timestamp))
  // Build a map for quick reply lookups
  let messageMap = $derived(new Map(messages.map(m => [m.id, m])))

  let canSend = $derived(
    !preparingAttachments &&
    !!$identity && $chats.has(chat.id) && !blocked && !sendingDirectFiles && !$messageRequests.rejectedChats[chat.recipientPubkey] &&
    ($attachmentDraft.length + $directFileDraft.length === 0 || attachmentAllowed) &&
    !!(messageText.trim() || $attachmentDraft.length || $directFileDraft.length) &&
    $attachmentDraft.every(item => !!item.nhash && !item.uploading && !item.error)
  )
</script>

<div class="flex-1 flex flex-col min-h-0 relative" role="presentation"
  data-testid="chat-file-drop-area"
  ondragover={handleDragOver} ondragleave={handleDragLeave} ondrop={handleDrop}>
  {#if isFileDrag}
    <div data-testid="file-drop-highlight" class="absolute inset-1 z-40 rounded-xl border-2 border-solid border-primary pointer-events-none"></div>
  {/if}
  <!-- Header -->
  <header class="h-16 px-4 flex items-center gap-3 border-b border-surface-lighter flex-shrink-0 bg-panel">
    {#if showBackButton}
      <button
        class="chat-header-button"
        onclick={onleave}
        aria-label="Back"
      >
        <span class="i-carbon-arrow-left text-xl"></span>
      </button>
    {/if}

    <button
      class="flex items-center gap-3 flex-1 min-w-0 hover:opacity-80 transition-opacity"
      onclick={() => onViewProfile?.(chat.recipientPubkey)}
      disabled={!onViewProfile}
    >
      <Avatar pubkey={chat.recipientPubkey} size={40} />
      <div class="flex-1 min-w-0 text-left">
        <p class="font-medium truncate">
          {#if chat.recipientPubkey === myPubkey}Note to self{:else}<Name pubkey={chat.recipientPubkey} />{/if}
        </p>
      </div>
    </button>

    {#if !isRequest}
      {#if $callSettings.video}
        <button class="chat-header-button" aria-label="Video call" title="Video call" disabled={!!$callState && $callState.status !== 'ended'} onclick={() => startCall(chat.recipientPubkey, true)}><span class="i-carbon-video-filled text-xl"></span></button>
      {/if}
      {#if $callSettings.voice}
        <button class="chat-header-button" aria-label="Voice call" title="Voice call" disabled={!!$callState && $callState.status !== 'ended'} onclick={() => startCall(chat.recipientPubkey, false)}><span class="i-carbon-phone-filled text-xl"></span></button>
      {/if}
    {/if}

    <!-- Menu -->
    <div class="relative">
      <button
        class="p-2 rounded-full text-gray-400 hover:bg-surface-light hover:text-white transition-colors"
        onclick={() => showMenu = !showMenu}
        aria-label="Chat menu"
      >
        <span class="i-carbon-overflow-menu-horizontal text-xl"></span>
      </button>

      {#if showMenu}
        <div class="absolute right-0 top-full mt-1 w-56 bg-surface border border-surface-lighter rounded-lg shadow-xl z-50">
          <ChatPinButton chatId={chat.id} />
          <button class="btn-ghost w-full text-left flex items-center gap-2" onclick={() => { showMenu = false; showMuteModal = true }}>
            <span class="i-carbon-notification-off"></span>
            {isChatMuted($chatMutes, chat.id) ? 'Muted notifications' : 'Mute notifications'}
          </button>
          <button
            class="btn-ghost w-full text-left flex items-center gap-2"
            onclick={() => { showMenu = false; showDisappearingModal = true }}
          >
            <span class="i-carbon-time"></span>
            Disappearing messages
            {#if currentTtl}
              <span class="ml-auto text-xs text-primary">{getExpirationLabel(currentTtl)}</span>
            {/if}
          </button>
          <button
            class="btn-ghost w-full text-left text-red-400 flex items-center gap-2"
            onclick={handleDelete}
          >
            <span class="i-carbon-trash-can"></span>
            Delete chat
          </button>
        </div>
      {/if}
    </div>
  </header>

  {#if disappearingNotice}
    <div class="px-4 py-2 border-b border-surface-lighter bg-surface text-sm text-primary">
      {disappearingNotice}
    </div>
  {/if}

  {#if isRequest}
    <div class="px-4 py-3 border-b border-surface-lighter bg-surface flex items-center justify-between gap-3">
      <div class="min-w-0">
        <p class="text-sm font-medium">Message request</p>
        <p class="text-xs text-gray-400 truncate">Accept to start chatting (no receipts or typing until then)</p>
      </div>
      <div class="flex gap-2 flex-shrink-0">
        <button class="btn-primary text-sm px-3" onclick={handleAcceptRequest} data-testid="request-accept-chat">
          Accept
        </button>
        <button class="btn-ghost text-sm px-3 text-red-400" onclick={handleRejectRequest} data-testid="request-reject-chat">
          Reject
        </button>
      </div>
    </div>
  {/if}

  {#if showMenu}
    <button
      class="fixed inset-0 z-10 bg-transparent border-none cursor-default"
      onclick={() => showMenu = false}
      aria-label="Close menu"
    ></button>
  {/if}

  <!-- Messages - scrollable -->
  <div
    bind:this={messagesContainer}
    onscroll={handleMessagesScroll}
    class="flex-1 overflow-y-auto overflow-x-hidden overscroll-contain p-4 min-h-0"
  >
    <!-- Invite started system message -->
    {#if chat.inviteId}
      <div class="text-center py-2 mb-2">
        <p class="text-sm text-gray-500">
          <span class="text-primary"><Name pubkey={chat.recipientPubkey} /></span>
          started the chat via invite link{#if chat.inviteLabel} <span class="text-gray-400">"{chat.inviteLabel}"</span>{/if}
        </p>
      </div>
    {/if}

    {#if messages.length === 0}
      <div class="text-center py-8">
        <div class="i-carbon-locked text-4xl text-primary mx-auto mb-2"></div>
        <p class="text-gray-400">End-to-end encrypted</p>
        <p class="text-sm text-gray-500">Messages are secured with double ratchet encryption</p>
      </div>
    {:else}
      {#each messages as message, i (message.id)}
        {@const prevMsg = messages[i - 1]}
        {@const nextMsg = messages[i + 1]}
        {@const newDay = !prevMsg || isDifferentDay(prevMsg.timestamp, message.timestamp)}
        {@const timeGapPrev = prevMsg ? (message.timestamp - prevMsg.timestamp) > 3 * 60 * 1000 : false}
        {@const timeGapNext = nextMsg ? (nextMsg.timestamp - message.timestamp) > 3 * 60 * 1000 : false}
        {@const isFirst = !!prevMsg?.nameChange || !!prevMsg?.call || prevMsg?.isMine !== message.isMine || timeGapPrev || newDay}
        {@const isLast = !!nextMsg?.nameChange || !!nextMsg?.call || nextMsg?.isMine !== message.isMine || timeGapNext || (nextMsg && isDifferentDay(message.timestamp, nextMsg.timestamp))}
        {@const prevHasReactions = prevMsg?.reactions && Object.keys(prevMsg.reactions).length > 0}
        {@const hasReactions = message.reactions && Object.keys(message.reactions).length > 0}
        {@const replyToMessage = message.replyTo ? messageMap.get(message.replyTo) ?? null : null}
        {#if newDay}
          <div class="day-separator sticky top-0 z-10 flex justify-center py-2 pointer-events-none">
            <span class="px-3 py-1 rounded-full text-xs text-gray-400 bg-panel/60 backdrop-blur-md shadow-sm pointer-events-auto">
              {formatDayLabel(message.timestamp)}
            </span>
          </div>
        {/if}
        {#if message.nameChange}
          <p class="text-center text-xs text-gray-400 py-3 break-words" data-testid="contact-name-history">
            You approved the name change: {message.nameChange.previous_name} → {message.nameChange.accepted_name} · Only you
          </p>
        {:else if message.call}
          <CallHistoryRow call={message.call} />
        {:else}
        <MessageBubble
          {message}
          {isFirst}
          {isLast}
          {prevHasReactions}
          {hasReactions}
          {replyToMessage}
          {myPubkey}
          recipientPubkey={chat.recipientPubkey}
          onreact={handleReact}
          ondelete={handleDeleteMessage}
          onedit={(id, content) => editMessage(chat, id, content)}
          ondeleteeveryone={id => deleteMessageForEveryone(chat, id)}
          onreply={handleReply}
        />
        {/if}
      {/each}
    {/if}
    <ContactMemory pubkey={chat.recipientPubkey} compact />

    {#if $isTyping.get(chat.id)}
      <div class="flex items-end gap-2 mt-1">
        <div class="bg-surface-light rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
          <span class="typing-dot"></span>
          <span class="typing-dot" style="animation-delay: 0.15s"></span>
          <span class="typing-dot" style="animation-delay: 0.3s"></span>
        </div>
      </div>
    {/if}
  </div>

  <!-- Scroll to bottom button -->
  {#if !isAtBottom}
    <div class="relative flex-shrink-0">
      <button
        class="absolute -top-12 right-4 w-10 h-10 rounded-full bg-surface-light border border-surface-lighter shadow-lg flex items-center justify-center text-gray-300 hover:text-white hover:bg-surface transition-all z-20"
        onclick={scrollToBottom}
        aria-label="Scroll to bottom"
      >
        <span class="i-carbon-chevron-down text-xl"></span>
      </button>
    </div>
  {/if}

  <!-- Input - flex-shrink-0 keeps it at bottom -->
  <div class="border-t border-surface-lighter flex-shrink-0 bg-panel">
    <!-- Reply preview -->
    {#if replyingTo}
      <div class="px-4 pt-3 pb-1 flex items-center gap-2">
        <div class="flex-1 min-w-0 border-l-2 border-primary pl-3">
          <div class="text-xs text-primary font-semibold mb-0.5">
            {replyingTo.isMine ? 'You' : ''}
            {#if !replyingTo.isMine}
              <Name pubkey={chat.recipientPubkey} />
            {/if}
          </div>
          <div class="text-sm text-gray-400 truncate">{displayMentions(directFilePreview(replyingTo.content))}</div>
        </div>
        <button
          class="w-7 h-7 flex-shrink-0 rounded-full hover:bg-surface-light flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          onclick={() => replyingTo = null}
          aria-label="Cancel reply"
        >
          <span class="i-carbon-close text-sm"></span>
        </button>
      </div>
    {/if}

    <!-- Attachment preview -->
    {#if $directFileDraft.length}
      <div class="px-4 pt-3 pb-2">
        <p class="text-xs text-gray-400 mb-2" data-testid="direct-file-mode">{sendingDirectFiles ? 'Preparing files…' : 'Send directly'} · Keep this tab open</p>
        <div class="flex gap-3 overflow-x-auto py-1">
          {#each $directFileDraft as item (item.id)}
            <div class="flex items-center gap-2 px-3 py-2 rounded-lg bg-surface-light flex-shrink-0" data-testid="direct-file-preview">
              <span class="i-carbon-document text-xl text-gray-400" aria-hidden="true"></span>
              <div class="min-w-0">
                <div class="text-sm max-w-40 truncate">{item.file.name}</div>
                <div class="text-xs text-gray-400">{formatDirectFileSize(item.file.size)}</div>
              </div>
              <button class="p-1 rounded-full hover:bg-surface-lighter disabled:opacity-50" disabled={sendingDirectFiles}
                aria-label={`Remove ${item.file.name}`} onclick={() => directFileDraft.remove(item.id)}>
                <span class="i-carbon-close" aria-hidden="true"></span>
              </button>
            </div>
          {/each}
        </div>
      </div>
    {/if}
    {#if $attachmentDraft.length}
      <div class="px-4 pt-3 pb-2 flex gap-4 overflow-x-auto">
        {#each $attachmentDraft as pendingAttachment (pendingAttachment.id)}
        <div class="relative inline-block flex-shrink-0" data-testid="attachment-preview">
          <!-- Preview content -->
          {#if pendingAttachment.previewUrl && isImageFile(pendingAttachment.file.name)}
            <img
              src={pendingAttachment.previewUrl}
              alt={pendingAttachment.file.name}
              class="max-h-32 max-w-48 rounded-lg object-cover"
            />
          {:else if pendingAttachment.previewUrl && isVideoFile(pendingAttachment.file.name)}
            <!-- svelte-ignore a11y_media_has_caption -->
            <video
              src={pendingAttachment.previewUrl}
              class="max-h-32 max-w-48 rounded-lg object-cover"
            ></video>
          {:else}
            <!-- File icon for non-previewable files -->
            <div class="flex items-center gap-2 px-3 py-2 bg-surface-light rounded-lg">
              <span class="i-carbon-document text-xl text-gray-400"></span>
              <span class="text-sm text-gray-300 max-w-32 truncate">{pendingAttachment.file.name}</span>
            </div>
          {/if}

          <!-- Progress overlay -->
          {#if pendingAttachment.uploading}
            <div class="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center">
              <div class="text-center">
                <div class="text-white text-sm font-medium">{pendingAttachment.progress}%</div>
                <div class="w-16 h-1 bg-gray-600 rounded-full mt-1 overflow-hidden">
                  <div
                    class="h-full bg-primary transition-all duration-150"
                    style="width: {pendingAttachment.progress}%"
                  ></div>
                </div>
              </div>
            </div>
          {/if}

          <!-- Error state -->
          {#if pendingAttachment.error}
            <div class="absolute inset-0 bg-red-900/60 rounded-lg flex items-center justify-center">
              <span class="i-carbon-warning-alt text-red-400 text-xl"></span>
            </div>
          {/if}

          <!-- Remove button -->
          <button
            class="absolute -top-2 -right-2 w-6 h-6 bg-surface border border-surface-lighter rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-red-600 hover:border-red-600 transition-colors"
            onclick={() => attachmentDraft.remove(pendingAttachment.id)}
            aria-label="Remove attachment"
          >
            <span class="i-carbon-close text-sm"></span>
          </button>
        </div>
        {/each}
      </div>
    {/if}

    {#if attachmentError}
      <p role="status" class="px-4 pt-2 text-sm text-red-400">{attachmentError}</p>
    {/if}

    <!-- Input row -->
    <div
      class="p-4 pt-2 pb-[max(1rem,env(safe-area-inset-bottom))] flex gap-2 items-end"
      role="presentation"
    >
      <!-- Hidden file input -->
      <input
        bind:this={fileInputRef}
        type="file"
        multiple
        class="hidden"
        onchange={handleFileSelect}
        accept="image/*,video/*,audio/*,.pdf,.txt,.json,.md"
      />
      <input bind:this={directFileInputRef} type="file" multiple class="hidden"
        data-testid="direct-file-input" onchange={handleDirectFileSelect} />

      {#if isRecordingVoice}
        <!-- Voice recording UI -->
        <VoiceRecorder
          onrecorded={handleVoiceRecorded}
          oncancel={handleVoiceCancel}
        />
      {:else}
        <!-- Emoji picker button (desktop only) -->
        {#if !isMobile}
          <div class="relative flex-shrink-0">
            <button
              class="w-11 h-11 p-0 flex items-center justify-center flex-shrink-0 text-gray-400 hover:text-white hover:bg-surface-light rounded-full transition-colors"
              onclick={() => showEmojiPicker = !showEmojiPicker}
              aria-label="Emoji picker"
            >
              <span class="i-carbon-face-add text-xl"></span>
            </button>
            {#if showEmojiPicker}
              <EmojiPicker
                onselect={(emoji) => { messageText += emoji; inputRef?.focus() }}
                onclose={() => showEmojiPicker = false}
              />
            {/if}
          </div>
        {/if}

        <!-- Attachment button -->
        <div class="relative flex-shrink-0" bind:this={attachmentMenuRef}>
          <button
            class="w-11 h-11 p-0 flex items-center justify-center text-gray-400 hover:text-white hover:bg-surface-light rounded-full transition-colors"
            onclick={() => showAttachmentMenu = !showAttachmentMenu}
            disabled={!canAttach || uploadingAttachments}
            aria-label="Attach file" aria-expanded={showAttachmentMenu}
          >
            <span class="i-carbon-attachment text-xl"></span>
          </button>
          {#if showAttachmentMenu}
            <div data-testid="attachment-source-row"
              class="absolute bottom-full left-0 mb-2 bg-surface border border-surface-lighter rounded-lg shadow-xl z-30 flex gap-2 p-3 max-w-[calc(100vw-2rem)] overflow-x-auto sm:block sm:py-1 sm:px-0 sm:min-w-40 sm:max-w-none sm:overflow-x-visible">
              <button class="text-sm hover:bg-surface-light flex flex-col items-center gap-2 px-3 py-2 min-w-24 flex-shrink-0 rounded-lg sm:block sm:w-full sm:px-4 sm:min-w-0 sm:rounded-none sm:text-left" onclick={() => { showAttachmentMenu = false; fileInputRef?.click() }}>
                <span class="i-carbon-document text-2xl sm:hidden" aria-hidden="true"></span>Files
              </button>
              <button class="text-sm hover:bg-surface-light disabled:opacity-40 flex flex-col items-center gap-2 px-3 py-2 min-w-24 flex-shrink-0 rounded-lg whitespace-nowrap sm:block sm:w-full sm:px-4 sm:min-w-0 sm:rounded-none sm:text-left" disabled={$attachmentDraft.length > 0}
                title={$attachmentDraft.length ? 'Remove the uploaded files first' : undefined}
                onclick={() => { showAttachmentMenu = false; directFileInputRef?.click() }}>
                <span class="i-carbon-arrows-vertical text-2xl sm:hidden" aria-hidden="true"></span>Send directly
              </button>
            </div>
          {/if}
        </div>

        <ComposerInput bind:inputRef bind:value={messageText} members={[chat.recipientPubkey, ...($identity?.pubkey ? [$identity.pubkey] : [])]}
          onkeydown={handleKeydown} onpaste={handlePaste} oninput={handleTypingInput} />

        <!-- Voice/Send button -->
        {#if messageText.trim() || $attachmentDraft.length || $directFileDraft.length}
          <button
            class="btn-primary w-11 h-11 p-0 flex items-center justify-center flex-shrink-0"
            onclick={handleSend}
            disabled={!canSend}
            aria-label="Send"
          >
            <span class="i-carbon-send text-xl"></span>
          </button>
        {:else}
          <button
            class="w-11 h-11 p-0 flex items-center justify-center flex-shrink-0 text-gray-400 hover:text-white hover:bg-surface-light rounded-full transition-colors"
            onclick={startVoiceRecording}
            disabled={!canAttach || uploadingAttachments}
            aria-label="Record voice message"
          >
            <span class="i-carbon-microphone text-xl"></span>
          </button>
        {/if}
      {/if}
    </div>
  </div>
</div>

<!-- Disappearing Messages Modal -->
{#if showDisappearingModal}
  <DisappearingMessagesModal
    currentTtlSeconds={currentTtl}
    onclose={() => showDisappearingModal = false}
    onselect={handleSetDisappearing}
  />
{/if}

<!-- Media Modal -->
{#if $mediaModal.open}
  <MediaModal
    src={$mediaModal.src}
    nhash={$mediaModal.nhash}
    filename={$mediaModal.filename}
    type={$mediaModal.type}
    onclose={closeMediaModal}
  />
{/if}

<style>
  .typing-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #9ca3af;
    animation: typing-bounce 1.2s ease-in-out infinite;
  }

  @keyframes typing-bounce {
    0%, 60%, 100% {
      transform: translateY(0);
      opacity: 0.4;
    }
    30% {
      transform: translateY(-6px);
      opacity: 1;
    }
  }
</style>

{#if showMuteModal}
  <ChatMuteModal chatId={chat.id} onclose={() => showMuteModal = false} />
{/if}
