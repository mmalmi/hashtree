import { test, expect } from './fixtures'
import type { Page } from '@playwright/test'

// Helper: reload page, retrying if navigation is aborted by background activity
async function safeReload(page: Page) {
  try {
    await page.reload({ waitUntil: 'domcontentloaded' })
  } catch (e: any) {
    if (e.message?.includes('ERR_ABORTED') || e.message?.includes('frame was detached')) {
      await page.waitForTimeout(500)
      await page.reload({ waitUntil: 'domcontentloaded' })
    } else {
      throw e
    }
  }
}

test.describe('Notifications', () => {
  test.describe('Settings Page', () => {
    test('should show Settings in avatar dropdown', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Click on avatar to go to settings
      await page.getByRole('button', { name: 'Settings' }).click()

      // Should see Settings header
      await expect(page.getByRole('heading', { name: 'Settings' })).toBeVisible()
    })

    test('should navigate to Settings page', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Click on avatar to go to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Should see the selected notification page
      await expect(page).toHaveURL(/#settings\/notifications$/)

      // Should see notification section
      await expect(page.getByRole('heading', { name: 'Notifications', exact: true })).toBeVisible()

      // Should see status indicators
      await expect(page.getByText('Notification API')).toBeVisible()
      await expect(page.getByText('Permission')).toBeVisible()
      await expect(page.getByText('Service Worker')).toBeVisible()
      await expect(page.getByText('Push Subscription')).toBeVisible()
    })

    test('should navigate back from Settings', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()

      // Click back button
      await page.getByRole('button', { name: 'Back' }).click()

      // Should be back at chat list (no Settings header)
      await expect(page.getByRole('heading', { name: 'Settings' })).not.toBeVisible()
      await expect(page.getByRole('button', { name: 'New Chat' })).toBeVisible()
    })

    test('should show status indicators', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Notification API should show as Available (browsers support it)
      await expect(page.getByText('Available').first()).toBeVisible()
    })

    test('should toggle advanced section', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Advanced section should be collapsed
      await expect(page.getByText('Notification Server URL')).not.toBeVisible()

      // Click to expand
      await page.getByRole('button', { name: 'Advanced' }).click()

      // Should see server URL input
      await expect(page.getByText('Notification Server URL')).toBeVisible()
      await expect(page.locator('#server-url')).toBeVisible()
    })

    test('should persist notification settings in localStorage', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Expand advanced section
      await page.getByRole('button', { name: 'Advanced' }).click()

      // Change server URL
      await page.locator('#server-url').fill('https://custom.server.com')
      await page.locator('#server-url + button').click()

      // Reload page - settings page should still be shown (URL has #settings)
      await safeReload(page)

      // The selected settings page survives reload.
      await expect(page).toHaveURL(/#settings\/notifications$/)
      await expect(page.getByRole('heading', { name: 'Notifications', exact: true })).toBeVisible()

      // Expand advanced section again
      await page.getByRole('button', { name: 'Advanced' }).click()

      // Should have the saved URL
      await expect(page.locator('#server-url')).toHaveValue('https://custom.server.com')
    })

    test('should show permission denied status when notifications are blocked', async ({ context, page, baseURL }) => {
      await context.grantPermissions([], { origin: baseURL })
      await page.goto('/')
      expect(await page.evaluate(() => Notification.permission)).toBe('denied')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // The settings view reflects the browser's actual denied permission.
      await expect(page.getByText('Denied')).toBeVisible()
    })
  })

  test.describe('Notification Prompt', () => {
    test('should not show notification prompt when permission is denied', async ({ context, page, baseURL }) => {
      await context.grantPermissions([], { origin: baseURL })
      await page.goto('/')
      expect(await page.evaluate(() => Notification.permission)).toBe('denied')
      await page.getByRole('button', { name: 'Go' }).click()

      // Prompt should NOT be visible when permission is denied
      await expect(page.getByText('Get notified when you receive new messages')).not.toBeVisible()
    })

    test('should persist declined state in localStorage when declined via store', async ({ context, page }) => {
      // Pre-inject the declined notification state so it's set on every page load
      const notifValue = JSON.stringify({
        enabled: false,
        serverUrl: 'https://notifications.iris.to',
        declined: true
      })
      await context.addInitScript((val: string) => {
        try {
          window.localStorage.setItem('iris-chat-notifications', val)
        } catch {
          // ignore opaque origins (about:blank)
        }
      }, notifValue)

      // Login first to establish identity
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()
      await expect(page.getByRole('heading', { name: 'New Chat' })).toBeVisible()
      // Let app settle after login (avoid navigation race)
      await page.waitForTimeout(200)

      // Navigate fresh, retrying if app is mid-navigation
      try {
        await page.goto('/')
      } catch {
        await page.waitForTimeout(300)
        await page.goto('/')
      }
      await expect(page.getByRole('heading', { name: 'New Chat' })).toBeVisible()

      // Verify localStorage was persisted
      const settings = await page.evaluate(() => localStorage.getItem('iris-chat-notifications'))
      expect(settings).toBeTruthy()
      const parsed = JSON.parse(settings!)
      expect(parsed.declined).toBe(true)
    })
  })

  test.describe('Test Notification', () => {
    test('test notification button should be disabled without permission', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // A notification cannot be sent without granted permission.
      const testButton = page.getByRole('button', { name: 'Send Test Notification' })
      await expect(testButton).toBeDisabled()
    })
  })

  test.describe('Settings Toggle', () => {
    test('should show toggle in off state by default', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Toggle should be in off state (aria-checked="false")
      const toggle = page.getByRole('switch', { name: 'Toggle DM notifications' })
      await expect(toggle).toHaveAttribute('aria-checked', 'false')
    })
  })

  test.describe('Service Worker', () => {
    test('should show service worker as running', async ({ page }) => {
      await page.goto('/')
      await page.getByRole('button', { name: 'Go' }).click()

      // Navigate to Settings
      await page.getByRole('button', { name: 'Settings' }).click()
      await page.getByRole('navigation', { name: 'Settings sections' }).getByRole('link', { name: 'Notifications', exact: true }).click()

      // Service Worker should show as Running
      await expect(page.getByText('Running')).toBeVisible()
    })
  })
})
