import { test, expect } from './fixtures'
import { finalizeEvent, generateSecretKey, getPublicKey } from 'nostr-tools'
import { WebSocket } from 'ws'
import { SocialGraph } from 'nostr-social-graph'
import { mkdir } from 'node:fs/promises'

async function publish(url: string, events: ReturnType<typeof finalizeEvent>[]) {
  await new Promise<void>((resolve, reject) => {
    const socket = new WebSocket(url)
    const pending = new Set(events.map(event => event.id))
    const timer = setTimeout(() => { socket.close(); reject(new Error('Test publishing timed out')) }, 5000)
    socket.on('error', reject)
    socket.on('open', () => events.forEach(event => socket.send(JSON.stringify(['EVENT', event]))))
    socket.on('message', data => {
      const message = JSON.parse(String(data))
      if (message[0] !== 'OK') return
      pending.delete(message[1])
      if (!pending.size) { clearTimeout(timer); socket.close(); resolve() }
    })
  })
}

test('private contact memory, public follows and network warnings stay separate', async ({ page, testRelayUrl, testRelay }) => {
  test.setTimeout(90000)
  const local = generateSecretKey(), peer = generateSecretKey()
  const friend = generateSecretKey(), muter1 = generateSecretKey(), muter2 = generateSecretKey()
  const account = getPublicKey(local), person = getPublicKey(peer)
  const time = Math.floor(Date.now() / 1000) - 100
  const event = (secret: Uint8Array, kind: number, tags: string[][], content = '', offset = 0) => finalizeEvent({kind, created_at: time + offset, tags, content}, secret)
  const metadata = (name: string, offset: number) => event(peer, 0, [], JSON.stringify({name}), offset)
  const originalTags = [
    ['p', getPublicKey(friend), 'wss://example.com', 'friend'],
    ['p', getPublicKey(muter1)], ['p', getPublicKey(muter2)], ['x', 'keep-this-extension'],
  ]
  await publish(testRelayUrl, [
    metadata('Alice Original', 0),
    event(local, 3, originalTags, '{"existing":"content"}'),
    event(friend, 3, [['p', person]]),
    event(muter1, 10000, [['p', person]]), event(muter2, 10000, [['p', person]]),
  ])
  const seed = Buffer.from(await new SocialGraph(account).toBinary())
  await page.route(/\/assets\/socialGraph-.*\.bin$/, route => route.fulfill({ body: seed, contentType: 'application/octet-stream' }))
  await page.route(/https:\/\/(cdn|upload|hashtree)\.iris\.to\//, route => route.abort())
  await page.addInitScript(secret => localStorage.setItem('iris-chat-identity', secret), Buffer.from(local).toString('hex'))
  await page.goto(`/#profile-${person}`)
  await expect(page.getByRole('heading', { name: 'Alice Original', exact: true })).toBeVisible()
  const avatar = page.getByTestId('profile-avatar')
  const explanation = page.getByTestId('follow-distance')
  await expect(avatar.getByTestId('social-distance-badge')).toHaveCount(0)
  await expect(explanation.getByLabel('More mutes than follows in your network')).toBeVisible()
  const memory = () => page.evaluate(({ account, person }) => JSON.parse(localStorage.getItem(`iris-contact-memory:v1:${account}:${person}`) || 'null'), { account, person })
  expect(await memory()).toBeNull()
  await page.getByRole('button', { name: 'Start Chat', exact: true }).click()
  await expect(page.getByPlaceholder('Type a message...')).toBeVisible()
  const smallBadge = page.getByLabel('More mutes than follows in your network').first()
  await expect(smallBadge).toBeVisible()
  const smallBadgeBounds = (await smallBadge.boundingBox())!
  const smallAvatarBounds = (await smallBadge.locator('../..').locator('img').boundingBox())!
  expect(smallBadgeBounds.y + smallBadgeBounds.height / 2).toBeLessThan(smallAvatarBounds.y + smallAvatarBounds.height / 2)
  expect(smallBadgeBounds.x + smallBadgeBounds.width / 2).toBeGreaterThan(smallAvatarBounds.x + smallAvatarBounds.width / 2)
  await expect.poll(async () => (await memory())?.first_seen_name).toBe('Alice Original')
  await publish(testRelayUrl, [metadata('Alicia Updated', 10)])
  await expect(page.getByTestId('contact-name-change')).toContainText('Alice Original now goes by Alicia Updated.')
  await page.getByTestId('contact-name-change').getByRole('button', { name: 'Use this name' }).click()
  await expect(page.getByTestId('contact-name-history')).toContainText('Alice Original → Alicia Updated')
  await page.setViewportSize({width: 390, height: 844})
  await mkdir('work/contact-memory', {recursive: true})
  await page.screenshot({path: 'work/contact-memory/chat-approved-mobile.png', fullPage: true})
  await page.goto(`/#profile-${person}`)
  await expect(page.getByRole('heading', {name: 'Alicia Updated', exact: true})).toBeVisible()
  await page.getByRole('button', {name: 'Favorite', exact: true}).click()
  await expect(page.getByRole('button', {name: 'Favorited', exact: true})).toHaveAttribute('aria-pressed', 'true')
  await expect(explanation.getByLabel('More mutes than follows in your network')).toBeVisible()
  expect(testRelay.publishedEvents.filter(item => item.pubkey === account && item.kind === 3)).toHaveLength(1)
  await publish(testRelayUrl, [metadata('Alice Again', 20)])
  await expect(page.getByText('New name:', {exact: false})).toContainText('Alice Again')
  await expect(page.getByRole('heading', {name: 'Alicia Updated', exact: true})).toBeVisible()
  await page.screenshot({path: 'work/contact-memory/profile-warning-mobile.png', fullPage: true})
  await page.getByRole('button', {name: 'Use this name', exact: true}).click()
  await expect(page.getByRole('heading', {name: 'Alice Again', exact: true})).toBeVisible()
  await expect(page.getByText('First known as Alice Original')).toBeVisible()
  await page.getByRole('button', {name: 'Follow (public)', exact: true}).click()
  await expect(explanation.getByLabel('Following', {exact: true})).toBeVisible()
  const graphBadge = explanation.getByLabel('Following', {exact: true})
  await expect(graphBadge).toHaveCSS('background-color', 'rgb(10, 132, 255)')
  await expect(avatar.getByTestId('social-distance-badge')).toHaveCount(0)
  await expect(explanation).toContainText('Followed by you')
  await page.screenshot({path: 'work/contact-memory/profile-following-mobile.png', fullPage: true})
  const followHead = testRelay.publishedEvents.filter(item => item.pubkey === account && item.kind === 3).sort((a,b) => b.created_at - a.created_at)[0]
  expect(followHead.tags).toEqual([...originalTags, ['p', person]])
  expect(followHead.content).toBe('{"existing":"content"}')
  await page.getByRole('button', {name: 'Unfollow (public)', exact: true}).click()
  await expect(explanation.getByLabel('More mutes than follows in your network')).toBeVisible()
  await publish(testRelayUrl, [event(local, 10000, [['p', person]], '', 30)])
  await expect(explanation.getByLabel('Muted', {exact: true})).toBeVisible()
  await page.reload()
  await expect(page.getByRole('heading', {name: 'Alice Again', exact: true})).toBeVisible()
  expect((await memory()).name_changes).toHaveLength(2)
  expect((await memory()).favorite).toBe(true)
  await page.getByRole('button', {name: 'Open Chat', exact: true}).click()
  await expect(page.getByTestId('contact-name-history')).toHaveCount(2)
  expect(testRelay.publishedEvents.filter(item => item.pubkey === account).every(item => !item.content.includes('Alice Original') && !item.content.includes('Alicia Updated'))).toBe(true)
})

test('favorite stars update across profile and chat avatars without changing public follows', async ({ page, testRelayUrl, testRelay }, info) => {
  const local = generateSecretKey(), peer = generateSecretKey()
  const account = getPublicKey(local), person = getPublicKey(peer)
  const created_at = Math.floor(Date.now() / 1000)
  await publish(testRelayUrl, [
    finalizeEvent({ kind: 0, created_at, tags: [], content: JSON.stringify({ name: 'Alice' }) }, peer),
    finalizeEvent({ kind: 3, created_at, tags: [['p', person]], content: '' }, local),
  ])
  const seed = Buffer.from(await new SocialGraph(account).toBinary())
  await page.route(/\/assets\/socialGraph-.*\.bin$/, route => route.fulfill({ body: seed, contentType: 'application/octet-stream' }))
  await page.route(/https:\/\/(cdn|upload|hashtree)\.iris\.to\//, route => route.abort())
  await page.addInitScript(secret => localStorage.setItem('iris-chat-identity', secret), Buffer.from(local).toString('hex'))
  await page.goto(`/#profile-${person}`)
  await expect(page.getByRole('heading', { name: 'Alice', exact: true })).toBeVisible()
  const profile = page.getByTestId('profile-avatar')
  await expect(profile.getByTestId('favorite-badge')).toHaveCount(0)
  await expect(page.getByTestId('follow-distance').getByLabel('Following', { exact: true })).toBeVisible()
  await page.getByRole('button', { name: 'Start Chat', exact: true }).click()
  const header = page.getByTestId('chat-file-drop-area').locator('header')
  await expect(header.getByLabel('Following', { exact: true })).toBeVisible()
  await expect(page.getByTestId('favorite-badge')).toHaveCount(0)
  await header.getByRole('button', { name: /Alice/ }).click()
  await page.getByRole('button', { name: 'Favorite', exact: true }).click()
  await expect(profile.getByTestId('favorite-badge')).toBeVisible({ timeout: 5000 })
  await expect(profile.getByTestId('social-distance-badge')).toHaveCount(0)
  await page.getByRole('button', { name: 'Open Chat', exact: true }).click()
  await expect(page.getByTestId('favorite-badge')).toHaveCount(2)
  await expect(header.getByLabel('Following', { exact: true })).toBeVisible()
  const favorite = header.getByTestId('favorite-badge')
  const favoriteBounds = (await favorite.boundingBox())!
  const avatarBounds = (await header.getByRole('img', { name: 'Alice', exact: true }).boundingBox())!
  expect(favoriteBounds.x + favoriteBounds.width / 2).toBeLessThan(avatarBounds.x + avatarBounds.width / 2)
  expect(favoriteBounds.y + favoriteBounds.height / 2).toBeLessThan(avatarBounds.y + avatarBounds.height / 2)
  await page.screenshot({ path: info.outputPath('favorite-desktop.png'), fullPage: true })
  await page.setViewportSize({ width: 390, height: 844 })
  await expect(favorite).toBeVisible()
  await page.screenshot({ path: info.outputPath('favorite-mobile.png'), fullPage: true })
  await header.getByRole('button', { name: /Alice/ }).click()
  await page.getByRole('button', { name: 'Favorited', exact: true }).click()
  await expect(profile.getByTestId('favorite-badge')).toHaveCount(0)
  await page.getByRole('button', { name: 'Open Chat', exact: true }).click()
  await expect(page.getByTestId('favorite-badge')).toHaveCount(0)
  await expect(header.getByLabel('Following', { exact: true })).toBeVisible()
  await page.screenshot({ path: info.outputPath('not-favorite-mobile.png'), fullPage: true })
  expect(testRelay.publishedEvents.filter(event => event.pubkey === account && event.kind === 3)).toHaveLength(1)
})
