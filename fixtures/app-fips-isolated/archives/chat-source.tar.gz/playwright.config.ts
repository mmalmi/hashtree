import { defineConfig, devices } from '@playwright/test'

const port = process.env.PLAYWRIGHT_PORT ?? '4173'
const baseURL = `http://127.0.0.1:${port}`

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 1,
  workers: process.env.CI ? 1 : undefined,
  timeout: 60_000,
  reporter: 'list',
  expect: {
    timeout: 30_000,
  },
  use: {
    baseURL,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    actionTimeout: 30_000,
  },
  projects: [
    {
      name: 'chromium',
      // Exercise the full browser's headless mode; the separate shell crashes on context teardown.
      use: { ...devices['Desktop Chrome'], channel: 'chromium' },
    },
    {
      name: 'webkit-files',
      testMatch: 'direct-file-first.spec.ts',
      use: { ...devices['iPhone 13'], defaultBrowserType: 'webkit' },
    },
    {
      name: 'firefox-files',
      testMatch: 'direct-file-first.spec.ts',
      use: { ...devices['Desktop Firefox'], defaultBrowserType: 'firefox' },
    },
    {
      name: 'webkit-chat-rows',
      testMatch: 'chat-row-layout.spec.ts',
      use: { ...devices['Desktop Safari'], defaultBrowserType: 'webkit' },
    },
    {
      name: 'webkit-composer',
      testMatch: 'composer-completions.spec.ts',
      grep: /narrow touch composer/,
      use: { ...devices['iPhone 13'], defaultBrowserType: 'webkit' },
    },
    {
      name: 'webkit-notifications',
      testMatch: ['notification-permission.spec.ts', 'notification-navigation.spec.ts'],
      use: { ...devices['iPhone 13'], defaultBrowserType: 'webkit' },
    },
    {
      name: 'webkit-native-app-entry',
      testMatch: 'native-app-entry.spec.ts',
      use: { ...devices['iPhone 13'], defaultBrowserType: 'webkit' },
    },
    {
      name: 'webkit-settings',
      testMatch: 'settings-navigation.spec.ts',
      use: { ...devices['iPhone 13'], defaultBrowserType: 'webkit' },
    },
  ],
  webServer: {
    command: `pnpm run build && pnpm run preview --host 127.0.0.1 --port ${port} --strictPort`,
    url: baseURL,
    reuseExistingServer: process.env.PLAYWRIGHT_REUSE_EXISTING_SERVER === '1',
  },
})
