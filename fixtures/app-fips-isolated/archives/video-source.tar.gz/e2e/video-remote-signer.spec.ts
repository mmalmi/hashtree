import {test, expect} from "./fixtures"
import {
  finalizeEvent,
  generateSecretKey,
  getPublicKey,
  nip44,
  verifyEvent,
  type Event,
} from "nostr-tools"

test("pair once, restore the signer and publish a NIP-71 video", async ({
  page,
}) => {
  const account = generateSecretKey()
  const transport = generateSecretKey()
  const pubkey = getPublicKey(account)
  const relay = "wss://signer.invalid/"
  const link = `bunker://${getPublicKey(transport)}?relay=${encodeURIComponent(relay)}&secret=pair-once`
  const signed: Event[] = []
  const methods: string[] = []
  let pairedClient = ""
  await page.routeWebSocket(relay, (socket) => {
    let subscription = ""
    socket.onMessage((raw) => {
      const [command, value] = JSON.parse(raw.toString())
      if (command === "REQ") {
        subscription = value
        socket.send(JSON.stringify(["EOSE", value]))
      }
      if (command !== "EVENT") return
      const event = value as Event
      expect(verifyEvent(event)).toBe(true)
      const key = nip44.v2.utils.getConversationKey(transport, event.pubkey)
      const {id, method, params} = JSON.parse(nip44.v2.decrypt(event.content, key))
      methods.push(method)
      let result: string
      if (method === "connect") {
        expect(pairedClient).toBe("")
        expect(params[1]).toBe("pair-once")
        pairedClient = event.pubkey
        result = "ack"
      } else {
        expect(event.pubkey).toBe(pairedClient)
        if (method === "switch_relays") result = "null"
        else if (method === "get_public_key") result = pubkey
        else if (method === "sign_event") {
          const post = finalizeEvent(JSON.parse(params[0]), account)
          signed.push(post)
          result = JSON.stringify(post)
        } else if (method === "nip44_encrypt") {
          result = nip44.v2.encrypt(params[1], nip44.v2.utils.getConversationKey(account, params[0]))
        } else if (method === "nip44_decrypt") {
          result = nip44.v2.decrypt(params[1], nip44.v2.utils.getConversationKey(account, params[0]))
        } else throw new Error(`Unexpected signer method ${method}`)
      }
      socket.send(JSON.stringify(["OK", event.id, true, ""]))
      const response = finalizeEvent(
        {
          kind: 24133,
          created_at: Math.floor(Date.now() / 1000),
          tags: [["p", event.pubkey]],
          content: nip44.v2.encrypt(JSON.stringify({id, result}), key),
        },
        transport
      )
      socket.send(JSON.stringify(["EVENT", subscription, response]))
    })
  })
  test.slow()
  await page.goto('/video.html#/')
  await expect(page.getByRole('button', {name: 'Sign in with remote signer'})).toHaveCount(0)
  await page.goto('/video.html#/users')
  await page.getByRole('button', {name: 'Sign in with remote signer'}).click()
  await page.getByRole('dialog').screenshot({path: test.info().outputPath('signer-login.png')})
  await page.getByLabel('Signer connection link').fill(link)
  await page.getByRole('button', {name: 'Connect', exact: true}).click()
  await expect.poll(() => page.evaluate(() => localStorage.getItem('hashtree:activeAccount'))).toBe(pubkey)
  expect(await page.evaluate(() => Object.values(localStorage).some(value => value.includes('pair-once')))).toBe(false)

  await page.reload()
  await page.goto('/video.html#/create')
  await page.waitForFunction(pk => (window as any).__nostr?.signer?.getPublicKey() === pk, pubkey)
  const title = 'Remote signer upload'
  await page.locator('input[type="file"]').setInputFiles('e2e/fixtures/Big_Buck_Bunny_360_10s.webm')
  await page.getByPlaceholder(/title/i).fill(title)
  await page.getByRole('button', {name: /public/i}).first().click()
  await page.getByRole('button', {name: 'Upload Video'}).click()
  await expect(page).toHaveURL(/videos(%2F|\/)/i, {timeout: 90000})
  await expect.poll(() => signed.filter(event => event.kind === 34235 && event.tags.some(([key, value]) => key === 'title' && value === title)).length).toBe(1)
  expect(signed.every(event => event.pubkey === pubkey && verifyEvent(event))).toBe(true)
  expect(signed.some(event => event.kind === 0)).toBe(false)

  // Deliver the same two messages the hashtree worker uses for encrypted data.
  const clear = await page.evaluate(async pk => {
    const worker = (window as any).__getWorkerAdapter().worker as Worker
    function request(id: string, data: Record<string, unknown>) {
      return new Promise<string>((resolve, reject) => {
        const original = worker.postMessage
        worker.postMessage = function(message, transfer?: Transferable[]) {
          if (message.id !== id) return original.call(worker, message, transfer ?? [])
          worker.postMessage = original
          if (message.error) reject(new Error(message.error))
          else resolve(message.ciphertext ?? message.plaintext)
        }
        worker.dispatchEvent(new MessageEvent('message', {data: {...data, id}}))
      })
    }
    const ciphertext = await request('video-encrypt', {type: 'nip44Encrypt', pubkey: pk, plaintext: 'video draft'})
    return request('video-decrypt', {type: 'nip44Decrypt', pubkey: pk, ciphertext})
  }, pubkey)
  expect(clear).toBe('video draft')
  expect(methods).toContain('nip44_encrypt')
  expect(methods).toContain('nip44_decrypt')
  expect(methods.filter(method => method === 'connect')).toHaveLength(1)
})
