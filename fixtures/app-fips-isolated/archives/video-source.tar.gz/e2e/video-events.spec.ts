import path from 'path';
import { fileURLToPath } from 'url';
import { once } from 'node:events';
import { WebSocketServer } from 'ws';
import { finalizeEvent, getPublicKey, matchFilter, type Filter } from 'nostr-tools';
import { test, expect, type Page } from './fixtures';
import { setupPageErrorHandler, waitForAppReady, disableOthersPool, ensureLoggedIn, presetLocalRelayInDB } from './test-utils';
import { BOOTSTRAP_SECKEY, FOLLOW_SECKEY, FOLLOW2_SECKEY } from './nostr-test-keys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface PublishedVideo {
  npub: string;
  pubkey: string;
}

async function currentUser(page: Page): Promise<PublishedVideo> {
  return page.evaluate(() => {
    const state = (window as unknown as { __nostrStore: { getState(): { npub: string; pubkey: string } } })
      .__nostrStore.getState();
    return { npub: state.npub, pubkey: state.pubkey };
  });
}

/** Publish a NIP-71 video event for the signed-in user straight to the relay. */
async function publishVideoEvent(page: Page, video: { treeName: string; title: string; description?: string }) {
  await page.evaluate(async (input) => {
    // @ts-expect-error served by the dev server
    const { buildVideoEventTemplate } = await import('/src/lib/videoEvent.ts');
    const win = window as unknown as {
      __nostr: { publishEvent(template: unknown): Promise<unknown> };
      __nostrStore: { getState(): { npub: string } };
    };
    await win.__nostr.publishEvent(buildVideoEventTemplate({
      ownerNpub: win.__nostrStore.getState().npub,
      treeName: input.treeName,
      title: input.title,
      description: input.description,
      duration: 95,
      publishedAt: 1_765_000_000,
      videoPath: 'video.mp4',
    }));
  }, video);
}

async function indexedVideosByAuthor(page: Page, pubkey: string) {
  return page.evaluate(async (author) => {
    // @ts-expect-error served by the dev server
    const { getVideoEventsByAuthor } = await import('/src/stores/videoEvents.ts');
    return getVideoEventsByAuthor(author).map((video: { title: string; description?: string; duration?: number; treeName: string }) => ({
      title: video.title,
      description: video.description,
      duration: video.duration,
      treeName: video.treeName,
    }));
  }, pubkey);
}

test.describe('Nostr video events', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  for (const scope of ['all', 'following'] as const) {
    test(`New / ${scope} scrolls past the cached videos into relay history`, async ({ page, baseURL }, testInfo) => {
      const now = Math.floor(Date.now() / 1000) - 100;
      const followed = getPublicKey(FOLLOW_SECKEY);
      const events = Array.from({ length: 80 }, (_, index) => {
        const title = `Archive ${index}`;
        return finalizeEvent({
          kind: 21, created_at: now - index, content: title,
          tags: [['title', title], ['imeta', `url ${baseURL}/smoke-video.webm?v=${index}`, 'm video/webm']],
        }, index % 2 === 0 ? FOLLOW_SECKEY : FOLLOW2_SECKEY);
      });
      events.push(finalizeEvent({ kind: 3, created_at: now, content: '', tags: [['p', followed]] }, BOOTSTRAP_SECKEY));
      const pages: Filter[] = [];
      let historyEventsSent = 0;
      const server = new WebSocketServer({ port: 0, host: '127.0.0.1' });
      await once(server, 'listening');
      const address = server.address();
      if (!address || typeof address === 'string') throw new Error('Missing test relay port');
      const relay = `ws://127.0.0.1:${address.port}`;
      server.on('connection', socket => socket.on('message', raw => {
        const [command, id, ...filters] = JSON.parse(raw.toString());
        if (command === 'EVENT') socket.send(JSON.stringify(['OK', id.id, true, '']));
        if (command !== 'REQ') return;
        const matches = new Set(filters.flatMap((filter: Filter) => {
          const paging = filter.until !== undefined && filter.kinds?.length === 2 && filter.kinds.includes(21);
          if (paging) pages.push(filter);
          // A small recent window, including for followed-author startup requests.
          const limit = paging ? filter.limit : Math.min(12, filter.limit ?? 12);
          const selected = events.filter(event => matchFilter(filter, event)).slice(0, limit);
          if (paging) historyEventsSent += selected.length;
          return selected;
        }));
        for (const event of matches) socket.send(JSON.stringify(['EVENT', id, event]));
        socket.send(JSON.stringify(['EOSE', id]));
      }));
      try {
        await page.route('**/__paging_setup', route => route.fulfill({ contentType: 'text/html', body: '<html></html>' }));
        await page.goto('/__paging_setup');
        await presetLocalRelayInDB(page, relay);
        await page.evaluate(scope => {
          localStorage.setItem('video-feed-sort', 'new');
          localStorage.setItem('video-feed-scope', scope);
        }, scope);
        await page.goto('/video.html#/');
        const cards = page.getByTestId('video-feed').locator('h3');
        await expect(cards.first()).toHaveText('Archive 0');
        expect(pages).toHaveLength(0);
        const expected = events.filter(event => event.kind === 21 && (scope === 'all' || event.pubkey === followed))
          .map(event => event.content);
        await expect.poll(async () => {
          await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
          return cards.count();
        }, { timeout: 30_000 }).toBe(expected.length);
        expect(await cards.allTextContents()).toEqual(expected);
        expect(new Set(pages.map(filter => filter.until)).size).toBeGreaterThan(1);
        expect(pages.every(filter => scope === 'all' ? !filter.authors : filter.authors?.includes(followed))).toBe(true);
        await page.screenshot({ path: testInfo.outputPath('older-videos.png') });
        console.log(`New / ${scope}: ${expected.length} cards, ${historyEventsSent} history events across ${pages.length} relay pages`);
      } finally {
        for (const socket of server.clients) socket.terminate();
        await new Promise<void>(resolve => server.close(() => resolve()));
      }
    });
  }

  test('releases public video subscriptions away from the feed and catches up on return', async ({ page }) => {
    const clip = (title: string, created_at: number) => finalizeEvent({
      kind: 21, created_at, content: title,
      tags: [['title', title], ['imeta', `url https://example.invalid/${created_at}.mp4`, 'm video/mp4', 'dim 1920x1080']],
    }, FOLLOW_SECKEY);
    const now = Math.floor(Date.now() / 1000);
    const events = [clip('Before leaving', now - 10)];
    const server = new WebSocketServer({ port: 0, host: '127.0.0.1' });
    await once(server, 'listening');
    const address = server.address();
    if (!address || typeof address === 'string') throw new Error('Missing test relay port');
    const live = new Set<Set<string>>();
    const active = () => [...live].some(ids => ids.size > 0);
    server.on('connection', socket => {
      const ids = new Set<string>();
      live.add(ids);
      socket.on('close', () => live.delete(ids));
      socket.on('message', raw => {
        const [verb, id, ...filters] = JSON.parse(raw.toString());
        if (verb === 'CLOSE') ids.delete(id);
        if (verb !== 'REQ') return;
        const publicVideos = filters.some((f: Filter) =>
          f.kinds?.includes(21) && !f.authors && !f.ids && !Object.keys(f).some(k => k.startsWith('#')));
        if (publicVideos) ids.add(id);
        else ids.delete(id);
        for (const event of events) {
          if (filters.some((f: Filter) => matchFilter(f, event))) socket.send(JSON.stringify(['EVENT', id, event]));
        }
        socket.send(JSON.stringify(['EOSE', id]));
      });
    });
    try {
      await page.route('**/__feed_setup', route => route.fulfill({ contentType: 'text/html', body: '<html></html>' }));
      await page.goto('/__feed_setup');
      await presetLocalRelayInDB(page, `ws://127.0.0.1:${address.port}`);
      await page.goto('/video.html#/');
      const cards = page.getByTestId('video-feed');
      await expect(cards.getByText('Before leaving', { exact: true })).toBeVisible();
      await expect.poll(active).toBe(true);
      await page.evaluate(() => { location.hash = '/settings'; });
      await expect(cards).toHaveCount(0);
      await expect.poll(active).toBe(false);
      events.push(clip('While away', now));
      await page.evaluate(() => { location.hash = '/'; });
      await expect(cards.getByText('Before leaving', { exact: true })).toBeVisible();
      await expect.poll(active).toBe(true);
      await expect.poll(async () => (await indexedVideosByAuthor(page, events[0].pubkey)).map(v => v.title)).toContain('While away');
    } finally {
      for (const socket of server.clients) socket.terminate();
      await new Promise<void>(resolve => server.close(() => resolve()));
    }
  });

  test('video events from the relay drive the home feed, search and profile', async ({ page, browser }) => {
    test.slow();
    const title = `EventIndex${Date.now()} relay clip`;
    const treeName = `videos/${title}`;

    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);
    const author = await currentUser(page);

    await publishVideoEvent(page, { treeName, title, description: 'Indexed from a NIP-71 event' });

    // Home feed lists the announced video.
    const homeCard = page.locator(`a[href*="${encodeURIComponent(treeName)}"]`).filter({ hasText: title });
    await expect(homeCard.first()).toBeVisible({ timeout: 20000 });

    // Search finds it by title and by its summary text.
    const searchInput = page.locator('header input[placeholder*="Search"]');
    await expect(searchInput).toBeVisible({ timeout: 5000 });
    await searchInput.fill(title.split(' ')[0].toLowerCase());
    const dropdown = page.locator('div.absolute.top-full');
    const result = dropdown.locator('button').filter({ hasText: title });
    await expect(result).toHaveCount(1, { timeout: 15000 });
    await expect(result).toContainText('1:35');
    await searchInput.fill('');
    await page.keyboard.press('Escape');

    // A different, signed-out visitor gets the video from the relay on the author's channel.
    const visitorContext = await browser.newContext();
    const visitor = await visitorContext.newPage();
    try {
      setupPageErrorHandler(visitor);
      await visitor.goto(`/video.html#/${author.npub}/profile`);
      await waitForAppReady(visitor);
      await disableOthersPool(visitor);

      const profileCard = visitor.locator(`a[href*="${encodeURIComponent(treeName)}"]`).filter({ hasText: title });
      await expect(profileCard).toHaveCount(1, { timeout: 20000 });
      await expect.poll(() => indexedVideosByAuthor(visitor, author.pubkey), { timeout: 15000 }).toEqual([{
        title,
        description: 'Indexed from a NIP-71 event',
        duration: 95,
        treeName,
      }]);
    } finally {
      await visitorContext.close();
    }

    // The owner's deletion request removes it from the index again.
    await page.evaluate(async ({ pubkey, dTag }) => {
      // @ts-expect-error served by the dev server
      const { buildVideoEventDeletionTemplate } = await import('/src/lib/videoEvent.ts');
      const win = window as unknown as { __nostr: { publishEvent(template: unknown): Promise<unknown> } };
      await win.__nostr.publishEvent(buildVideoEventDeletionTemplate(pubkey, [dTag], Math.floor(Date.now() / 1000) + 5));
    }, { pubkey: author.pubkey, dTag: treeName });
    await expect(homeCard).toHaveCount(0, { timeout: 20000 });
  });

  test('the front page updates below the viewport and keeps visible videos still', async ({ page, baseURL }, testInfo) => {
    test.slow();
    const stamp = Date.now();
    const videoUrl = `${baseURL}/e2e/fixtures/Big_Buck_Bunny_360_10s_1MB.mp4`;

    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);

    // A regular NIP-71 video event pointing at a plain web URL, as other apps publish them.
    const publishWebVideo = (title: string, createdAt: number) => page.evaluate(async (input) => {
      const win = window as unknown as { __nostr: { publishEvent(template: unknown): Promise<unknown> } };
      await win.__nostr.publishEvent({
        kind: 21,
        created_at: input.createdAt,
        content: 'Published by another app',
        tags: [
          ['title', input.title],
          ['published_at', `${input.createdAt}`],
          // Its own URL: an author's repeat posts of one file are listed once.
          ['imeta', `url ${input.videoUrl}?clip=${encodeURIComponent(input.title)}`, 'm video/mp4', 'duration 10'],
          ['t', `Clips${input.stamp}`],
        ],
      });
    }, { title, createdAt, videoUrl, stamp });

    const controls = page.getByTestId('feed-controls');
    await controls.getByRole('button', { name: 'New' }).click();
    await expect(controls.getByRole('button', { name: 'New' })).toHaveAttribute('aria-pressed', 'true');

    const now = Math.floor(Date.now() / 1000);
    for (let index = 0; index < 13; index += 1) {
      await publishWebVideo(`WebClip${stamp} ${index}`, now - 100 - index * 10);
    }

    const feed = page.getByTestId('video-feed');
    const card = (title: string) => feed.locator('a[href^="#/v/"]').filter({ hasText: title });
    await expect(card(`WebClip${stamp} 0`).first()).toBeVisible({ timeout: 20000 });

    // Scrolling loads the rest of the list.
    await page.mouse.wheel(0, 4000);
    await expect(card(`WebClip${stamp} 12`).first()).toBeAttached({ timeout: 20000 });
    await page.mouse.wheel(0, -8000);

    const update = page.getByTestId('feed-update');
    await expect(controls).toBeInViewport();
    // Apply New explicitly so unrelated videos already received have their current order.
    await controls.getByRole('button', { name: 'Hot' }).click();
    await controls.getByRole('button', { name: 'New' }).click();
    const firstCardBefore = await feed.locator('> *').first().innerText();
    const lowerCard = card(`WebClip${stamp} 10`).first();
    await expect(lowerCard).toBeAttached();
    await expect(lowerCard).not.toBeInViewport();
    await publishWebVideo(`BelowClip${stamp}`, now - 195);
    await expect(card(`BelowClip${stamp}`).first()).toBeAttached();
    await expect.poll(() => lowerCard.evaluate((el, title) => el.previousElementSibling?.textContent?.includes(title), `BelowClip${stamp}`)).toBe(true);
    await expect(update).toBeHidden();
    await testInfo.attach('offscreen-update', { body: await page.screenshot(), contentType: 'image/png' });

    // A newer video arrives: what is on screen stays, and Update offers the fresh order.
    await publishWebVideo(`LateClip${stamp}`, now + 5);
    await expect(update).not.toHaveClass(/invisible/, { timeout: 20000 });
    expect(await feed.locator('> *').first().innerText()).toBe(firstCardBefore);

    await update.click();
    await expect(feed.locator('> *').first()).toContainText(`LateClip${stamp}`);
    await expect(update).toHaveClass(/invisible/);

    // The video plays from its web URL on its own page.
    await card(`LateClip${stamp}`).first().click();
    await page.waitForURL(/#\/v\/note1/);
    const player = page.getByTestId('external-video-player').locator('video');
    await expect(player).toHaveAttribute('src', `${videoUrl}?clip=${encodeURIComponent(`LateClip${stamp}`)}`);
    await expect.poll(() => player.evaluate((video: HTMLVideoElement) => video.readyState), { timeout: 20000 })
      .toBeGreaterThanOrEqual(1);
    await expect(page.getByRole('heading', { name: `LateClip${stamp}` })).toBeVisible();

    // It can be liked and commented on with the events other Nostr apps use.
    const like = page.getByTestId('event-like');
    await like.click();
    await expect(like).toHaveAttribute('aria-pressed', 'true');
    const comments = page.getByTestId('event-comments');
    await comments.getByLabel('Add a comment').fill(`Watched ${stamp}`);
    await comments.getByLabel('Post comment').click();
    await expect(comments.getByTestId('event-comment')).toContainText(`Watched ${stamp}`);
    const stored = await page.evaluate(async (text) => {
      const { nostr } = await import('/src/nostr');
      return await new Promise<{ kind: number; tags: string[][] } | null>((resolve) => {
        const subscription = nostr.subscribe({ kinds: [1111], limit: 20 });
        const timer = setTimeout(() => { subscription.stop(); resolve(null); }, 10000);
        subscription.on('event', (event: { kind: number; content: string; tags: string[][] }) => {
          if (event.content !== text) return;
          clearTimeout(timer);
          subscription.stop();
          resolve({ kind: event.kind, tags: event.tags });
        });
      });
    }, `Watched ${stamp}`);
    expect(stored?.kind).toBe(1111);
    expect(stored?.tags.map((tag) => tag[0])).toEqual(['E', 'K', 'P', 'e', 'k', 'p']);
    expect(stored?.tags.find((tag) => tag[0] === 'K')?.[1]).toBe('21');

    // A reply sits under the comment it answers, behind a "1 reply" toggle.
    await comments.getByTestId('comment-reply').first().click();
    await expect(comments.getByTestId('comment-replying-to')).toBeVisible();
    await comments.getByLabel('Add a comment').fill(`Reply ${stamp}`);
    await comments.getByLabel('Post comment').click();
    const thread = comments.getByTestId('comment-thread').filter({ hasText: `Watched ${stamp}` });
    await expect(thread.getByTestId('comment-replies-toggle')).toContainText('1 reply');
    await expect(thread.getByTestId('event-comment')).toHaveCount(2);
    await expect(thread).toContainText(`Reply ${stamp}`);
    await thread.getByTestId('comment-replies-toggle').click();
    await expect(thread.getByTestId('event-comment')).toHaveCount(1);
    await expect(comments.getByTestId('comment-thread')).toHaveCount(1);

    // Long comments are cut behind "Show more", and a hashtag in one opens that hashtag's page.
    const long = `${'word '.repeat(120)}end${stamp} #clips${stamp}`;
    await comments.getByLabel('Add a comment').fill(long);
    await comments.getByLabel('Post comment').click();
    const longThread = comments.getByTestId('comment-thread').filter({ hasText: 'word word word' });
    await expect(longThread.getByTestId('rich-text-toggle')).toHaveText('Show more');
    await expect(longThread).not.toContainText(`end${stamp}`);
    await longThread.getByTestId('rich-text-toggle').click();
    await expect(longThread).toContainText(`end${stamp}`);
    await expect(longThread.getByTestId('rich-text-toggle')).toHaveText('Show less');
    await longThread.getByTestId('rich-text-hashtag').click();
    await page.waitForURL(new RegExp(`#/t/clips${stamp}`));
    const tagPage = page.getByTestId('hashtag-page');
    await expect(tagPage.getByRole('heading', { name: `#clips${stamp}` })).toBeVisible();
    await expect(tagPage.locator('a[href^="#/v/"]').filter({ hasText: `LateClip${stamp}` }).first()).toBeVisible({ timeout: 20000 });
  });

  test('shorts open in their own viewer and move on with the arrow keys', async ({ page, baseURL }) => {
    test.slow();
    const stamp = Date.now();
    const videoUrl = `${baseURL}/e2e/fixtures/Big_Buck_Bunny_360_10s_1MB.mp4`;

    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);

    // Short-form NIP-71 events (kind 22) with no preview image, as some apps publish them.
    const now = Math.floor(Date.now() / 1000);
    for (const [index, name] of ['One', 'Two', 'Three'].entries()) {
      await page.evaluate(async (input) => {
        const win = window as unknown as { __nostr: { publishEvent(template: unknown): Promise<unknown> } };
        await win.__nostr.publishEvent({
          kind: 22,
          created_at: input.createdAt,
          content: `About ${input.title}`,
          tags: [['title', input.title], ['imeta', `url ${input.videoUrl}`, 'm video/mp4', 'dim 720x1280']],
        });
        // The same file posted again by its author is not listed a second time.
        if (!input.repeat) return;
        await win.__nostr.publishEvent({
          kind: 22,
          created_at: input.createdAt + 5,
          content: '',
          tags: [['title', `Repeat of ${input.title}`], ['imeta', `url ${input.videoUrl}`, 'm video/mp4', 'dim 720x1280']],
        });
      }, { title: `Short${stamp} ${name}`, createdAt: now - index * 10, videoUrl: `${videoUrl}?short=${index}`, repeat: index === 0 });
    }

    // The home page lists them in the Shorts row, not among the long videos.
    const row = page.getByTestId('shorts-row');
    const first = row.locator('a[href^="#/shorts/"]').filter({ hasText: `Short${stamp} One` });
    await expect(first).toBeVisible({ timeout: 20000 });
    await expect(row.locator('a[href^="#/shorts/"]').filter({ hasText: `Short${stamp}` })).toHaveCount(3, { timeout: 20000 });
    await expect(page.getByTestId('video-feed').locator('a').filter({ hasText: `Short${stamp}` })).toHaveCount(0);

    await first.click();
    await page.waitForURL(/#\/shorts\/note1/);
    const active = page.getByTestId('short-active');
    await expect(active).toContainText(`Short${stamp} One`);
    const player = active.locator('video');
    await expect(player).toHaveAttribute('src', `${videoUrl}?short=0`);
    await expect.poll(() => player.evaluate((video: HTMLVideoElement) => !video.paused && video.readyState >= 2), { timeout: 20000 })
      .toBe(true);
    const openedUrl = page.url();

    // The next short takes over the screen, the player and the address bar.
    await page.keyboard.press('ArrowDown');
    await expect(active).not.toContainText(`Short${stamp} One`, { timeout: 10000 });
    await expect(active).toContainText(`Short${stamp}`);
    await expect(active.locator('video')).toHaveCount(1);
    await expect.poll(() => page.url()).not.toBe(openedUrl);

    await page.keyboard.press('ArrowUp');
    await expect(active).toContainText(`Short${stamp} One`, { timeout: 10000 });

    // The caption opens to the description and closes again.
    await expect.poll(() => page.getByTestId('shorts-viewer').evaluate((viewer) => viewer.scrollTop)).toBe(0);
    const caption = page.getByTestId('short-caption');
    await expect(page.getByTestId('short-description')).toHaveCount(0);
    await caption.click();
    await expect(page.getByTestId('short-description')).toHaveText(`About Short${stamp} One`);
    await caption.click();
    await expect(page.getByTestId('short-description')).toHaveCount(0);

    // A short repeats until the viewer moves on, unless they ask for the next one to follow.
    const autoNext = page.getByTestId('shorts-auto-next');
    await expect(autoNext).toHaveAttribute('aria-pressed', 'false');
    await expect(active.locator('video')).toHaveJSProperty('loop', true);
    await autoNext.click();
    await expect(autoNext).toHaveAttribute('aria-pressed', 'true');
    await expect(active.locator('video')).toHaveJSProperty('loop', false);
    await active.locator('video').evaluate((video: HTMLVideoElement) => {
      video.currentTime = Math.max(0, video.duration - 0.5);
    });
    await expect(active).not.toContainText(`Short${stamp} One`, { timeout: 15000 });
    await expect(active).toContainText(`Short${stamp}`);
    await autoNext.click();

    // Likes and comments sit beside the short and are kept by the relay.
    const like = page.getByTestId('short-like');
    await expect(like).toBeEnabled();
    await expect(like).toHaveAttribute('aria-pressed', 'false');
    await like.click();
    await expect(like).toHaveAttribute('aria-pressed', 'true');
    await expect(page.getByTestId('short-like-count')).toHaveText('1');

    await page.getByTestId('short-comments').click();
    const panel = page.getByTestId('short-comments-panel');
    await expect(panel).toContainText('No comments yet.');
    await panel.getByLabel('Add a comment').fill(`Nice one ${stamp}`);
    await panel.getByLabel('Post comment').click();
    await expect(panel.getByTestId('event-comment')).toContainText(`Nice one ${stamp}`);
    await expect(page.getByTestId('short-comment-count')).toHaveText('1');

    // Typing in the comment box does not move the viewer, and a reload brings both back.
    const commentedUrl = page.url();
    await panel.getByLabel('Add a comment').press('ArrowDown');
    await expect.poll(() => page.url()).toBe(commentedUrl);
    await page.reload();
    await waitForAppReady(page);
    await expect(page.getByTestId('short-like')).toHaveAttribute('aria-pressed', 'true', { timeout: 20000 });
    await expect(page.getByTestId('short-like-count')).toHaveText('1');
    await expect(page.getByTestId('short-comment-count')).toHaveText('1');
    await page.getByTestId('short-comments').click();
    await expect(page.getByTestId('short-comments-panel').getByTestId('event-comment')).toContainText(`Nice one ${stamp}`);
  });

  test('a channel lists shorts and playlists published as video sets on their own', async ({ page, baseURL }) => {
    test.slow();
    const stamp = Date.now();
    const videoUrl = `${baseURL}/e2e/fixtures/Big_Buck_Bunny_360_10s_1MB.mp4`;

    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);
    const author = await currentUser(page);

    // Two long videos, a short, and a NIP-51 video set (kind 30005) naming the long ones, newest first.
    const now = Math.floor(Date.now() / 1000);
    const ids = await page.evaluate(async (input) => {
      const win = window as unknown as { __nostr: { publishEvent(template: unknown): Promise<{ id: string }> } };
      const publish = (kind: number, title: string, createdAt: number, dim: string) => win.__nostr.publishEvent({
        kind,
        created_at: createdAt,
        content: '',
        tags: [['title', title], ['imeta', `url ${input.videoUrl}?set=${encodeURIComponent(title)}`, 'm video/mp4', `dim ${dim}`]],
      });
      const first = await publish(21, `SetClip${input.stamp} First`, input.now - 20, '1280x720');
      const second = await publish(21, `SetClip${input.stamp} Second`, input.now - 10, '1280x720');
      await publish(22, `SetShort${input.stamp}`, input.now - 5, '720x1280');
      await win.__nostr.publishEvent({
        kind: 30005,
        created_at: input.now,
        content: '',
        tags: [['d', `list_${input.stamp}`], ['title', `Picks ${input.stamp}`], ['description', 'Two of mine'], ['e', second.id], ['e', first.id]],
      });
      return { first: first.id, second: second.id };
    }, { stamp, now, videoUrl });
    expect(ids.first).toMatch(/^[0-9a-f]{64}$/);

    await page.goto(`/video.html#/${author.npub}`);
    // Shorts have their own section; the long videos stay in the grid.
    const shorts = page.getByTestId('profile-shorts');
    await expect(shorts.locator('a[href^="#/shorts/"]').filter({ hasText: `SetShort${stamp}` })).toBeVisible({ timeout: 20000 });
    await expect(shorts.locator('a').filter({ hasText: `SetClip${stamp}` })).toHaveCount(0);
    await expect(page.locator('a[href^="#/v/"]').filter({ hasText: `SetClip${stamp} First` }).first()).toBeVisible();

    // The set is listed as a playlist and opens to its videos in the author's order.
    const setCard = page.getByTestId('video-set-card').filter({ hasText: `Picks ${stamp}` });
    await expect(setCard).toBeVisible({ timeout: 20000 });
    await expect(setCard).toContainText('2 videos');
    await setCard.click();
    await page.waitForURL(/#\/list\/naddr1/);
    const setPage = page.getByTestId('video-set');
    await expect(setPage.getByRole('heading', { name: `Picks ${stamp}` })).toBeVisible();
    await expect(setPage).toContainText('Two of mine');
    const members = setPage.locator('a[href^="#/v/"]').filter({ hasText: `SetClip${stamp}` });
    await expect(members).toHaveCount(2);
    await expect(members.nth(0)).toContainText('Second');
    await expect(members.nth(1)).toContainText('First');

    // A direct link works too, and Escape leaves the shorts viewer for where it was opened.
    await page.reload();
    await waitForAppReady(page);
    await expect(page.getByTestId('video-set').locator('a[href^="#/v/"]').filter({ hasText: `SetClip${stamp}` })).toHaveCount(2, { timeout: 20000 });
    await page.goto(`/video.html#/${author.npub}`);
    await page.getByTestId('profile-shorts').locator('a').filter({ hasText: `SetShort${stamp}` }).click();
    await expect(page.getByTestId('short-active')).toContainText(`SetShort${stamp}`);
    await page.keyboard.press('Escape');
    await expect(page.getByTestId('profile-shorts')).toBeVisible();
  });

  test('uploading a video announces it as a NIP-71 event', async ({ page }) => {
    test.slow();
    const title = `EventUpload${Date.now()}`;
    const treeName = `videos/${title}`;

    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page);
    const author = await currentUser(page);

    await page.keyboard.press('Escape');
    const createButton = page.locator('button:has-text("Create")');
    await expect(createButton).toBeVisible({ timeout: 15000 });
    await createButton.click();
    await page.locator('button:has-text("Upload Video")').first().click();
    await expect(page.getByRole('heading', { name: 'Upload Video' })).toBeVisible({ timeout: 10000 });

    await page.locator('input[type="file"][accept="video/*"]')
      .setInputFiles(path.join(__dirname, 'fixtures', 'Big_Buck_Bunny_360_10s_1MB.mp4'));
    await page.locator('input[placeholder="Video title"]').fill(title);
    await page.locator('.fixed button:has-text("Upload")').click();
    await page.waitForURL(/\/video\.html#\/npub.*\/videos%2F/, { timeout: 60000 });

    // The saved tree is described by an event the relay now serves for this author.
    const fetchRelayEvent = () => page.evaluate(async ({ pubkey, dTag }) => {
      const win = window as unknown as {
        __nostr: { fetchEvents(filter: unknown, timeoutMs?: number): Promise<Set<{ tags: string[][]; kind: number }>> };
      };
      const events = await win.__nostr
        .fetchEvents({ kinds: [34235], authors: [pubkey], '#d': [dTag] }, 3000)
        .catch(() => new Set<{ tags: string[][]; kind: number }>());
      const [event] = [...events];
      return event ? { kind: event.kind, tags: event.tags } : null;
    }, { pubkey: author.pubkey, dTag: treeName });
    await expect.poll(fetchRelayEvent, { timeout: 30000, intervals: [1000] }).not.toBeNull();

    const { kind, tags } = (await fetchRelayEvent())!;
    const tagValue = (name: string) => tags.find((tag) => tag[0] === name)?.[1];
    const imeta = tags.find((tag) => tag[0] === 'imeta') ?? [];
    expect(kind).toBe(34235);
    expect(tagValue('title')).toBe(title);
    expect(Number(tagValue('duration'))).toBeGreaterThan(5);
    expect(imeta).toContain(`url htree://${author.npub}/${encodeURIComponent(treeName)}/video.mp4`);
    expect(imeta).toContain('m video/mp4');
    // Thumbnail capture is best-effort in the upload dialog; when present it must be a hashtree URL.
    for (const field of imeta.filter((entry) => entry.startsWith('image '))) {
      expect(field).toMatch(/^image htree:\/\/nhash1/);
    }
  });
});
