import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { WebSocketServer, type WebSocket } from 'ws';
import { expect, test } from '@playwright/test';
import { getPublicKey, nip19 } from 'nostr-tools';
import { ensureLoggedIn, evaluateWithRetry, waitForAppReady } from './test-utils';

type FipsReloadProof = {
  reloadedEndpoint: 'first' | 'second';
  localPeerId: string;
  otherPeerId: string;
  identityRetained: boolean;
  bothConnected: boolean;
  receiverCachedBefore: boolean;
  blockHash: string;
  verifiedBytes: number;
};

async function workerHasLocalBlock(page: import('@playwright/test').Page, hashHex: string): Promise<boolean> {
  return page.evaluate(async (hex) => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => { has(hash: Uint8Array): Promise<boolean> } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');
    return adapter.has(Uint8Array.from(hex.match(/../g) ?? [], (byte) => Number.parseInt(byte, 16)));
  }, hashHex);
}

async function captureReloadProof(
  reloaded: import('@playwright/test').Page,
  other: import('@playwright/test').Page,
  localPeerId: string,
  otherPeerId: string,
  reloadedEndpoint: 'first' | 'second',
  blockHash: string,
  verifiedBytes: number,
  receiverCachedBefore: boolean,
): Promise<FipsReloadProof> {
  const [localState, otherState] = await Promise.all([fipsLinkState(reloaded), fipsLinkState(other)]);
  const proof = {
    reloadedEndpoint, localPeerId: localState.localPeerId, otherPeerId: otherState.localPeerId,
    identityRetained: localState.localPeerId === localPeerId && otherState.localPeerId === otherPeerId,
    bothConnected: localState.connectedPeerIds.includes(otherPeerId)
      && otherState.connectedPeerIds.includes(localPeerId),
    receiverCachedBefore, blockHash, verifiedBytes,
  };
  expect(proof.identityRetained).toBe(true);
  expect(proof.bothConnected).toBe(true);
  expect(proof.receiverCachedBefore).toBe(false);
  return proof;
}

async function proveReloadedFipsPeer(
  reloaded: import('@playwright/test').Page,
  other: import('@playwright/test').Page,
  localPeerId: string,
  otherPeerId: string,
  reloadedEndpoint: 'first' | 'second',
): Promise<FipsReloadProof> {
  return test.step(`recover ${reloadedEndpoint} browser and transfer a fresh peer block`, async () => {
    await reloaded.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 });
    await waitForAppReady(reloaded, 30_000);
    await expect.poll(async () => Promise.all(
      [reloaded, other].map(async candidate => (await fipsLinkState(candidate)).localPeerId),
    ), { timeout: 30_000 }).toEqual([localPeerId, otherPeerId]);
    await expect.poll(async () => {
      const [localState, otherState] = await Promise.all([fipsLinkState(reloaded), fipsLinkState(other)]);
      return [localState.connectedPeerIds.includes(otherPeerId), otherState.connectedPeerIds.includes(localPeerId)];
    }, { timeout: 60_000 }).toEqual([true, true]);

    // This nonce is created only after this endpoint has reloaded and reconnected.
    // Fetch directly through the app's FIPS provider, never its HTTP read path.
    const source = await reloaded.evaluate(async () => {
      const adapter = (window as typeof window & {
        __getWorkerAdapter?: () => {
          put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
          webrtcProxy?: unknown;
        } | null;
      }).__getWorkerAdapter?.();
      if (!adapter) throw new Error('worker adapter is not ready');
      const data = new TextEncoder().encode(`fips-reload-block-${crypto.randomUUID()}`);
      const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
      const bytes = data.byteLength; // Worker storage transfers this buffer.
      if (!await adapter.put(hash, data)) throw new Error('failed to store fresh peer block');
      return {
        hashHex: Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join(''),
        bytes, legacyProxyActive: adapter.webrtcProxy != null,
      };
    });
    expect(source.legacyProxyActive).toBe(false);
    const receiverCachedBefore = await workerHasLocalBlock(other, source.hashHex);
    expect(receiverCachedBefore).toBe(false);
    await expect.poll(() => other.evaluate(async ({ hashHex, peerId }) => {
      const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
      const runtime = getDriveFipsRuntime();
      if (!runtime) throw new Error('FIPS provider bridge is not ready');
      const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
      if (!data) return null;
      const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new Uint8Array(data).buffer));
      const receivedHash = Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('');
      return { hashMatches: receivedHash === hashHex, bytes: data.byteLength };
    }, { hashHex: source.hashHex, peerId: localPeerId }), { timeout: 30_000 })
      .toEqual({ hashMatches: true, bytes: source.bytes });
    return captureReloadProof(reloaded, other, localPeerId, otherPeerId,
      reloadedEndpoint, source.hashHex, source.bytes, receiverCachedBefore);
  }, { timeout: 180_000 });
}

async function retainReloadProof(proofs: FipsReloadProof[]): Promise<void> {
  expect(proofs.map(proof => proof.reloadedEndpoint)).toEqual(['first', 'second']);
  expect(proofs[0].localPeerId).toBe(proofs[1].otherPeerId);
  expect(proofs[1].localPeerId).toBe(proofs[0].otherPeerId);
  expect(proofs[0].localPeerId).not.toBe(proofs[1].localPeerId);
  expect(proofs[0].blockHash).not.toBe(proofs[1].blockHash);
  // Only public endpoint identities, status booleans, hashes and sizes are retained.
  console.log('FIPS_BROWSER_RELOAD_PROOF', JSON.stringify(proofs));
  await test.info().attach('fips-browser-reload-proof.json', {
    body: JSON.stringify(proofs, null, 2), contentType: 'application/json',
  });
}

type NostrEvent = {
  id: string;
  pubkey: string;
  kind: number;
  tags: string[][];
};

let relay: WebSocketServer;
let relayUrl = '';
let seed: LocalFipsWebSocketSeed;
const publishedEvents: NostrEvent[] = [];
const subscriptions = new Map<WebSocket, Map<string, Record<string, unknown>[]>>();
const FIRST_NOSTR_SECRET = new Uint8Array(32).fill(0x41);
const SECOND_NOSTR_SECRET = new Uint8Array(32).fill(0x42);
const SWITCHED_NOSTR_SECRET = new Uint8Array(32).fill(0x43);

async function fipsLinkState(page: import('@playwright/test').Page): Promise<{
  localPeerId: string;
  connectedPeerIds: string[];
}> {
  return page.evaluate(async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const stats = getDriveFipsRuntime()?.getStats();
    return {
      localPeerId: stats?.localPeerId ?? '',
      connectedPeerIds: stats?.connectedPeerIds ?? [],
    };
  });
}

async function installNostrLogin(page: import('@playwright/test').Page, secret: Uint8Array): Promise<void> {
  const nsec = nip19.nsecEncode(secret);
  await page.addInitScript((value) => {
    localStorage.setItem('hashtree:loginType', 'nsec');
    localStorage.setItem('hashtree:nsec', value);
  }, nsec);
}

async function activateNostrLogin(
  page: import('@playwright/test').Page,
  secret: Uint8Array,
): Promise<void> {
  await evaluateWithRetry(page, async (nsec) => {
    const { loginWithNsec } = await import('/src/nostr/auth.ts');
    if (!await loginWithNsec(nsec)) throw new Error('Nostr login failed');
  }, nip19.nsecEncode(secret), 5);
}

function matchesFilter(event: NostrEvent, filter: Record<string, unknown>): boolean {
  const kinds = Array.isArray(filter.kinds) ? filter.kinds : [];
  if (kinds.length > 0 && !kinds.includes(event.kind)) return false;
  for (const [key, expected] of Object.entries(filter)) {
    if (!key.startsWith('#') || !Array.isArray(expected)) continue;
    const tagName = key.slice(1);
    if (!event.tags.some((tag) => tag[0] === tagName && expected.includes(tag[1]))) {
      return false;
    }
  }
  return true;
}

function send(socket: WebSocket, message: unknown): void {
  if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(message));
}

function publishToSubscriptions(event: NostrEvent): void {
  for (const [socket, socketSubscriptions] of subscriptions) {
    for (const [subscriptionId, filters] of socketSubscriptions) {
      if (filters.some((filter) => matchesFilter(event, filter))) {
        send(socket, ['EVENT', subscriptionId, event]);
      }
    }
  }
}

test.beforeAll(async () => {
  seed = await startLocalFipsWebSocketSeed();
  relay = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise<void>((resolve) => relay.once('listening', resolve));
  const address = relay.address();
  if (!address || typeof address === 'string') throw new Error('expected a TCP relay address');
  relayUrl = `ws://127.0.0.1:${address.port}`;

  relay.on('connection', (socket) => {
    subscriptions.set(socket, new Map());
    socket.on('message', (raw) => {
      const message = JSON.parse(raw.toString()) as unknown[];
      if (message[0] === 'EVENT') {
        const event = message[1] as NostrEvent;
        publishedEvents.push(event);
        publishToSubscriptions(event);
        send(socket, ['OK', event.id, true, '']);
        return;
      }
      if (message[0] === 'REQ') {
        const subscriptionId = `${message[1]}`;
        const filters = message.slice(2) as Record<string, unknown>[];
        subscriptions.get(socket)?.set(subscriptionId, filters);
        for (const event of publishedEvents) {
          if (filters.some((filter) => matchesFilter(event, filter))) {
            send(socket, ['EVENT', subscriptionId, event]);
          }
        }
        send(socket, ['EOSE', subscriptionId]);
        return;
      }
      if (message[0] === 'CLOSE') subscriptions.get(socket)?.delete(`${message[1]}`);
    });
    socket.on('close', () => subscriptions.delete(socket));
  });
});

test.afterAll(async () => {
  await seed.close();
  for (const socket of relay.clients) socket.terminate();
  await new Promise<void>((resolve) => relay.close(() => resolve()));
});

test('two Video browsers discover FIPS peers without legacy public signaling', async ({ browser, page }) => {
  test.slow();
  test.setTimeout(test.info().timeout + 1 * 180_000); // Budget only the added reload phases.
  publishedEvents.length = 0;
  await installNostrLogin(page, FIRST_NOSTR_SECRET);
  await page.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  await page.goto('/video.html#/');
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);
  await activateNostrLogin(page, FIRST_NOSTR_SECRET);

  await expect.poll(() => publishedEvents.find((event) => event.kind === 37_195), {
    timeout: 60_000,
  }).toBeTruthy();
  const firstAdvert = publishedEvents.find((event) => event.kind === 37_195);
  const firstBrowserAdvertisers = new Set(
    publishedEvents.filter((event) => event.kind === 37_195).map((event) => event.pubkey),
  );
  expect(firstAdvert?.tags).toContainEqual(['d', 'fips-overlay-v1']);
  expect(firstAdvert?.tags).toContainEqual(['protocol', 'fips-overlay-v1']);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const secondContext = await browser.newContext();
  const secondNsec = nip19.nsecEncode(SECOND_NOSTR_SECRET);
  await secondContext.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  await secondContext.addInitScript((value) => {
    localStorage.setItem('hashtree:loginType', 'nsec');
    localStorage.setItem('hashtree:nsec', value);
  }, secondNsec);
  const secondPage = await secondContext.newPage();
  await secondPage.goto('/video.html#/');
  await waitForAppReady(secondPage);
  await ensureLoggedIn(secondPage, 30_000);
  await activateNostrLogin(secondPage, SECOND_NOSTR_SECRET);

  await expect.poll(() => publishedEvents.some((event) => (
    event.kind === 37_195 && !firstBrowserAdvertisers.has(event.pubkey)
  )), { timeout: 60_000 }).toBe(true);
  await expect.poll(async () => Promise.all(
    [page, secondPage].map(async (candidate) => (await fipsLinkState(candidate)).localPeerId),
  ), { timeout: 60_000 }).toEqual([
    expect.stringMatching(/^(02|03)[0-9a-f]{64}$/),
    expect.stringMatching(/^(02|03)[0-9a-f]{64}$/),
  ]);
  const [firstFipsPeerId, secondFipsPeerId] = await Promise.all(
    [page, secondPage].map(async (candidate) => (await fipsLinkState(candidate)).localPeerId),
  );
  await expect.poll(async () => Promise.all(
    [
      [page, secondFipsPeerId],
      [secondPage, firstFipsPeerId],
    ].map(async ([candidate, peerId]) => (
      await fipsLinkState(candidate as import('@playwright/test').Page)
    ).connectedPeerIds.includes(peerId as string)),
  ), { timeout: 60_000 }).toEqual([true, true]);
  expect(publishedEvents.some((event) => event.kind === 21_059)).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const initialFipsPubkey = firstAdvert?.pubkey ?? '';
  expect(initialFipsPubkey).toMatch(/^[0-9a-f]{64}$/);
  const initialNostrPubkey = await page.evaluate(() => (
    (window as typeof window & {
      __nostrStore?: { getState(): { pubkey?: string } };
    }).__nostrStore?.getState().pubkey ?? ''
  ));
  expect(initialNostrPubkey).toBe(getPublicKey(FIRST_NOSTR_SECRET));
  expect(initialFipsPubkey).not.toBe(initialNostrPubkey);
  const initialAdvertCount = publishedEvents.filter((event) => (
    event.kind === 37_195 && event.pubkey === initialFipsPubkey
  )).length;

  await activateNostrLogin(page, SWITCHED_NOSTR_SECRET);
  await page.reload();
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);
  await expect.poll(() => page.evaluate(() => (
    (window as typeof window & {
        __nostrStore?: { getState(): { pubkey?: string } };
    }).__nostrStore?.getState().pubkey ?? ''
  )), { timeout: 30_000 }).toBe(getPublicKey(SWITCHED_NOSTR_SECRET));
  await expect.poll(() => publishedEvents.filter((event) => (
    event.kind === 37_195 && event.pubkey === initialFipsPubkey
  )).length, { timeout: 30_000 }).toBeGreaterThan(initialAdvertCount);
  await expect.poll(async () => Promise.all(
    [
      [page, secondFipsPeerId],
      [secondPage, firstFipsPeerId],
    ].map(async ([candidate, peerId]) => (
      await fipsLinkState(candidate as import('@playwright/test').Page)
    ).connectedPeerIds.includes(peerId as string)),
  ), { timeout: 60_000 }).toEqual([true, true]);

  const source = await page.evaluate(async () => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => {
        put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
        webrtcProxy?: unknown;
      } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');
    const text = `video-fips-block-${crypto.randomUUID()}`;
    const data = new TextEncoder().encode(text);
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
    if (!await adapter.put(hash, data)) throw new Error('failed to store source block');
    return {
      hashHex: Array.from(hash, (byte) => byte.toString(16).padStart(2, '0')).join(''),
      text,
      legacyProxyActive: adapter.webrtcProxy != null,
    };
  });
  expect(source.legacyProxyActive).toBe(false);
  const firstReloadReceiverCached = await workerHasLocalBlock(secondPage, source.hashHex);
  expect(firstReloadReceiverCached).toBe(false);

  await expect.poll(() => evaluateWithRetry(secondPage, async ({ hashHex, peerId }) => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const runtime = getDriveFipsRuntime();
    if (!runtime) throw new Error('FIPS provider bridge is not ready');
    const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
    if (data) {
      const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new Uint8Array(data).buffer));
      const receivedHash = Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('');
      if (receivedHash !== hashHex) throw new Error('Fetched FIPS block hash differs');
    }
    return data ? new TextDecoder().decode(data) : null;
  }, { hashHex: source.hashHex, peerId: firstFipsPeerId }, 5), {
    timeout: 30_000,
  }).toBe(source.text);
  expect(await secondPage.evaluate(() => (
    (window as typeof window & {
      __getWorkerAdapter?: () => { webrtcProxy?: unknown } | null;
    }).__getWorkerAdapter?.()?.webrtcProxy != null
  ))).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 21_059)).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const proofs = [
    await captureReloadProof(page, secondPage, firstFipsPeerId, secondFipsPeerId,
      'first', source.hashHex, new TextEncoder().encode(source.text).byteLength, firstReloadReceiverCached),
    await proveReloadedFipsPeer(secondPage, page, secondFipsPeerId, firstFipsPeerId, 'second'),
  ];
  await retainReloadProof(proofs);
  expect(publishedEvents.some((event) => event.kind === 21_059)).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  await secondContext.close();
});

declare global {
  interface Window {
    __testRelayUrl?: string;
  }
}
