/**
 * Shared test utilities for e2e tests
 */

import { expect } from './fixtures';

/**
 * Filter out noisy errors from relays that are irrelevant to tests.
 * - rate-limited: Some relays rate-limit nostr events
 * - pow: Some relays require Proof of Work on events (e.g., "pow: 28 bits needed")
 */
export function setupPageErrorHandler(page: any) {
  page.on('pageerror', (err: Error) => {
    const msg = err.message;
    if (!msg.includes('rate-limited') && !msg.includes('pow:') && !msg.includes('bits needed')) {
      console.log('Page error:', msg);
    }
  });
}

async function waitForTestHelpers(page: any, timeoutMs: number = 60000) {
  await page.waitForFunction(
    () => (window as any).__testHelpersReady === true,
    undefined,
    { timeout: timeoutMs }
  );
}

async function waitForAppShell(page: any, timeoutMs: number = 60000) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  const startedAt = Date.now();
  let lastError: unknown;

  while (Date.now() - startedAt < timeoutMs) {
    const remainingMs = timeoutMs - (Date.now() - startedAt);
    try {
      await expect(page.locator('header').first()).toBeVisible({
        timeout: Math.min(remainingMs, 8000),
      });
      return;
    } catch (err) {
      lastError = err;
    }

    if (Date.now() - startedAt >= timeoutMs) {
      break;
    }

    const currentUrl = page.url();
    try {
      if (!currentUrl || currentUrl === 'about:blank') {
        await page.goto('/', {
          waitUntil: 'domcontentloaded',
          timeout: Math.min(timeoutMs - (Date.now() - startedAt), 15000),
        });
      } else {
        await page.reload({
          waitUntil: 'domcontentloaded',
          timeout: Math.min(timeoutMs - (Date.now() - startedAt), 15000),
        });
      }
    } catch {
      await page.waitForTimeout(500).catch(() => {});
    }
  }

  throw lastError ?? new Error('Timed out waiting for app shell');
}

export async function waitForWorkerAdapter(page: any, timeoutMs: number = 60000) {
  await page.waitForFunction(
    () => {
      const win = window as any;
      return typeof win.__getWorkerAdapter === 'function' && !!win.__getWorkerAdapter();
    },
    undefined,
    { timeout: timeoutMs }
  );
}

async function waitForOptionalWorkerAdapter(page: any, timeoutMs: number = 60000) {
  await waitForWorkerAdapter(page, Math.min(timeoutMs, 5000)).catch(() => {});
}

function isTransientNavigationError(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error);
  return [
    'net::ERR_ADDRESS_INVALID',
    'net::ERR_CONNECTION_REFUSED',
    'net::ERR_CONNECTION_RESET',
    'net::ERR_CONNECTION_CLOSED',
    'net::ERR_EMPTY_RESPONSE',
    'net::ERR_NETWORK_CHANGED',
    'Target page, context or browser has been closed',
  ].some((snippet) => message.includes(snippet));
}

function resolveNavigationRetries(url: string, retries?: number): number {
  if (typeof retries === 'number') {
    return Math.max(0, retries);
  }
  // Local e2e servers can restart transiently under heavy suite load.
  return url.startsWith('/') || /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?(?:\/|$)/.test(url) ? 30 : 2;
}

export async function evaluateWithRetry<T, R>(
  page: any,
  fn: (arg: T) => Promise<R> | R,
  arg: T,
  retries: number = 3
): Promise<R> {
  let lastError: unknown;
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      return await page.evaluate(fn, arg);
    } catch (err) {
      lastError = err;
      const message = err instanceof Error ? err.message : String(err);
      if (!message.includes('Execution context was destroyed')) {
        throw err;
      }
      await page.waitForLoadState('domcontentloaded');
      await page.waitForFunction(() => document.readyState === 'complete', { timeout: 5000 }).catch(() => {});
    }
  }
  throw lastError ?? new Error('Failed to evaluate after retries');
}

/**
 * Wait for the app to be ready (header visible).
 * Call this after page.reload() before calling disableOthersPool or configureBlossomServers.
 */
export async function waitForAppReady(page: any, timeoutMs: number = 60000) {
  await waitForAppShell(page, timeoutMs);
  await waitForTestHelpers(page, timeoutMs);
  await waitForOptionalWorkerAdapter(page, timeoutMs);
}

export async function safeGoto(
  page: any,
  url: string,
  options?: { waitUntil?: 'domcontentloaded' | 'load' | 'networkidle'; timeoutMs?: number; retries?: number; delayMs?: number }
): Promise<void> {
  const waitUntil = options?.waitUntil ?? 'domcontentloaded';
  const timeoutMs = options?.timeoutMs ?? 60000;
  const retries = resolveNavigationRetries(url, options?.retries);
  const delayMs = options?.delayMs ?? 1000;
  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      await page.goto(url, { waitUntil, timeout: timeoutMs });
      return;
    } catch (err) {
      lastError = err;
      if (attempt === retries || !isTransientNavigationError(err)) {
        break;
      }
      await page.waitForTimeout(Math.min(delayMs * (attempt + 1), 5000));
    }
  }

  throw lastError;
}

export async function gotoGitApp(page: any) {
  await safeGoto(page, '/git.html#/');
}

export async function createRepositoryInCurrentDirectory(
  page: any,
  repositoryName: string,
  timeoutMs: number = 15000
) {
  await waitForTestHelpers(page, timeoutMs);
  const routeContext = await evaluateWithRetry(page, async () => {
    const { getRouteSync } = await import('/src/stores/index.ts');
    const route = getRouteSync();
    return {
      inTree: Boolean(route.npub && route.treeName),
    };
  }, undefined);

  if (routeContext.inTree) {
    await evaluateWithRetry(page, async (name: string) => {
      const { createGitRepository } = await import('/src/actions/tree.ts');
      await createGitRepository(name);
    }, repositoryName);
    await waitForCurrentDirectoryEntries(page, [repositoryName], timeoutMs);

    const repoLink = page.locator('[data-testid="file-list"] a').filter({ hasText: repositoryName }).first();
    const repoVisible = await repoLink.isVisible().catch(() => false);
    if (!repoVisible) {
      await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs });
      await waitForAppReady(page, timeoutMs);
    }
    await expect(repoLink).toBeVisible({ timeout: timeoutMs });
    return;
  }

  await evaluateWithRetry(page, async (name: string) => {
    const { createGitRepositoryTree } = await import('/src/actions/tree.ts');
    const result = await createGitRepositoryTree(name, 'public');
    if (!result.success) {
      throw new Error(`Failed to create top-level git repository: ${name}`);
    }
  }, repositoryName);
  await page.waitForURL(new RegExp(encodeURIComponent(repositoryName)), { timeout: timeoutMs });
}

export async function createPlainFolderInCurrentDirectory(
  page: any,
  folderName: string,
  timeoutMs: number = 15000
) {
  await evaluateWithRetry(page, async (name: string) => {
    const { createFolder } = await import('/src/actions/tree.ts');
    await createFolder(name);
  }, folderName);
  await expect(page.locator('[data-testid="file-list"] a').filter({ hasText: folderName }).first()).toBeVisible({ timeout: timeoutMs });
}

export async function waitForCurrentDirectoryEntries(
  page: any,
  expectedNames: string[],
  timeoutMs: number = 15000
) {
  await waitForTestHelpers(page, timeoutMs);
  await page.waitForFunction(
    async (names: string[]) => {
      const { useCurrentDirCid } = await import('/src/stores/index.ts');
      const { getTree } = await import('/src/store.ts');
      const dirCid = useCurrentDirCid();
      if (!dirCid) return false;
      const entries = await getTree().listDirectory(dirCid);
      const entryNames = new Set(entries.map((entry: { name: string }) => entry.name));
      return names.every((name) => entryNames.has(name));
    },
    expectedNames,
    { timeout: timeoutMs }
  );
}

export async function waitForGitRepoReady(page: any, timeoutMs: number = 60000) {
  await waitForTestHelpers(page, timeoutMs);
  await page.waitForFunction(
    async () => {
      const { useCurrentDirCid } = await import('/src/stores/index.ts');
      const { isGitRepo } = await import('/src/utils/git.ts');
      const dirCid = useCurrentDirCid();
      if (!dirCid) return false;
      return await isGitRepo(dirCid);
    },
    undefined,
    { timeout: timeoutMs }
  );
}

export async function commitCurrentDirectoryChanges(
  page: any,
  message: string,
  filesToStage?: string[]
) {
  await waitForTestHelpers(page);
  await waitForOptionalWorkerAdapter(page);
  await evaluateWithRetry(page, async ({ commitMessage, stageFiles }) => {
    const { getTree, LinkType } = await import('/src/store.ts');
    const { autosaveIfOwn, nostrStore } = await import('/src/nostr.ts');
    const { commit, applyGitChanges } = await import('/src/utils/git.ts');
    const { getCurrentRootCid } = await import('/src/actions/route.ts');
    const { useCurrentDirCid, getRouteSync } = await import('/src/stores/index.ts');

    const route = getRouteSync();
    const dirCid = useCurrentDirCid();
    const treeRootCid = getCurrentRootCid();
    const nostrState = nostrStore.getState();
    if (!dirCid || !treeRootCid) throw new Error('Missing directory or tree root for git commit');

    const authorName = nostrState.profile?.display_name || nostrState.profile?.name || 'Anonymous';
    const authorEmail = nostrState.npub ? `${nostrState.npub}@nostr` : 'anonymous@hashtree';
    const result = await commit(dirCid, commitMessage, authorName, authorEmail, stageFiles);
    if (!result.success || !result.gitFiles) {
      throw new Error(result.error || 'Failed to commit');
    }

    const newDirCid = await applyGitChanges(dirCid, result.gitFiles);
    let newRootCid = newDirCid;
    if (route.path.length > 0) {
      const tree = getTree();
      const parentPath = route.path.slice(0, -1);
      const dirName = route.path[route.path.length - 1];
      newRootCid = await tree.setEntry(treeRootCid, parentPath, dirName, newDirCid, 0, LinkType.Dir);
    }

    autosaveIfOwn(newRootCid);
  }, { commitMessage: message, stageFiles: filesToStage });
}

export async function ensureGitRepoInitialized(page: any, timeoutMs: number = 30000) {
  await waitForTestHelpers(page);
  await waitForOptionalWorkerAdapter(page, timeoutMs);

  const getCurrentDirHash = async () => evaluateWithRetry(page, async () => {
    const { useCurrentDirCid } = await import('/src/stores/index.ts');
    const cid = useCurrentDirCid();
    return cid?.hash ? Array.from(cid.hash).join(',') : null;
  }, undefined).catch(() => null);

  const waitForGitDirInCurrentDirectory = async (previousDirHash: string | null, requireHashChange: boolean) => {
    await page.waitForFunction(
      async ({ prevHash, mustChange }) => {
        const { useCurrentDirCid } = await import('/src/stores/index.ts');
        const { getTree } = await import('/src/store.ts');
        const currentDirCid = useCurrentDirCid();
        if (!currentDirCid) return false;
        const currentHash = currentDirCid.hash ? Array.from(currentDirCid.hash).join(',') : null;
        if (mustChange && currentHash === prevHash) return false;
        const entries = await getTree().listDirectory(currentDirCid);
        return entries.some((entry: { name: string }) => entry.name === '.git');
      },
      { prevHash: previousDirHash, mustChange: requireHashChange },
      { timeout: timeoutMs }
    );
  };

  const previousDirHash = await getCurrentDirHash();
  const gitInitBtn = page.getByRole('button', { name: 'Git Init' });
  if (await gitInitBtn.isVisible().catch(() => false)) {
    await evaluateWithRetry(page, async () => {
      const { getTree, LinkType } = await import('/src/store.ts');
      const { autosaveIfOwn } = await import('/src/nostr.ts');
      const { initializeDirectoryAsGitRepo } = await import('/src/actions/tree.ts');
      const { getCurrentRootCid } = await import('/src/actions/route.ts');
      const { useCurrentDirCid, getRouteSync } = await import('/src/stores/index.ts');

      const route = getRouteSync();
      const dirCid = useCurrentDirCid();
      const treeRootCid = getCurrentRootCid();
      if (!dirCid || !treeRootCid) throw new Error('Missing directory or tree root for git init');

      const updatedDirCid = await initializeDirectoryAsGitRepo(dirCid);
      let newRootCid = updatedDirCid;
      if (route.path.length > 0) {
        const tree = getTree();
        const parentPath = route.path.slice(0, -1);
        const dirName = route.path[route.path.length - 1];
        newRootCid = await tree.setEntry(treeRootCid, parentPath, dirName, updatedDirCid, 0, LinkType.Dir);
      }

      autosaveIfOwn(newRootCid);
    }, undefined);
    await waitForGitDirInCurrentDirectory(previousDirHash, true);
    await safeReload(page, { waitUntil: 'domcontentloaded', timeoutMs });
    await waitForAppReady(page, timeoutMs);
    await disableOthersPool(page);
    await waitForGitDirInCurrentDirectory(null, false);
    await expect(gitInitBtn).not.toBeVisible({ timeout: timeoutMs });
  } else {
    await waitForGitDirInCurrentDirectory(previousDirHash, false);
  }

  const branchButton = page.locator('button').filter({ has: page.locator('.i-lucide-git-branch') }).first();
  await expect(branchButton).toBeVisible({ timeout: timeoutMs });
}

export async function safeReload(
  page: any,
  options?: { waitUntil?: 'domcontentloaded' | 'load' | 'networkidle'; timeoutMs?: number; retries?: number; url?: string }
): Promise<void> {
  const waitUntil = options?.waitUntil ?? 'domcontentloaded';
  const timeoutMs = options?.timeoutMs ?? 60000;
  const retries = resolveNavigationRetries(options?.url ?? page.url(), options?.retries);
  const targetUrl = options?.url ?? page.url();

  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      await page.reload({ waitUntil, timeout: timeoutMs });
      return;
    } catch {
      try {
        await safeGoto(page, targetUrl, { waitUntil, timeoutMs, retries: Math.max(0, retries - attempt - 1) });
        return;
      } catch (err) {
        if (attempt === retries - 1) {
          throw err;
        }
      }
    }
  }
}

/**
 * Wait for at least one relay connection.
 * Use this before tests that require Nostr publishes to be queryable by other users.
 */
export async function waitForRelayConnected(page: any, timeoutMs: number = 15000) {
  await waitForTestHelpers(page, timeoutMs);
  const targetRelays = await evaluateWithRetry(page, async (fallbackRelay: string) => {
    const win = window as any;
    const { settingsStore } = await import('/src/stores/settings.ts');
    const currentRelays = settingsStore.getState().network.relays ?? [];
    const testRelay = win.__testRelayUrl ?? fallbackRelay;
    const isLocalRelay = (url: string): boolean => {
      try {
        const parsed = new URL(url);
        return ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
      } catch {
        return false;
      }
    };
    const relays = testRelay && (currentRelays.length === 0 || currentRelays.every(isLocalRelay))
      ? [testRelay]
      : currentRelays;

    if (relays.length > 0) {
      settingsStore.setNetworkSettings({ relays });
    }
    return relays;
  }, getTestRelayUrl()).catch(() => [getTestRelayUrl()]);
  await page.waitForFunction(
    async (expectedRelays: string[]) => {
      const win = window as any;
      const store = win.__nostrStore;
      if (expectedRelays.length === 0 && (store?.getState?.().connectedRelays ?? 0) > 0) {
        return true;
      }

      const adapter = win.__getWorkerAdapter?.();
      if (!adapter) {
        return false;
      }

      const stats = await adapter.getRelayStats?.().catch(() => []);
      const normalizeRelay = (value: string): string => {
        try {
          return new URL(value).href;
        } catch {
          return value;
        }
      };
      const expected = new Set(expectedRelays.map(normalizeRelay));
      const connectedRelays = Array.isArray(stats)
        ? stats.filter((relay: { connected?: boolean; url?: string }) => (
            relay.connected
            && typeof relay.url === 'string'
            && (expected.size === 0 || expected.has(normalizeRelay(relay.url)))
          )).length
        : 0;
      if (connectedRelays > 0) {
        store?.setConnectedRelays?.(connectedRelays);
        return true;
      }
      return false;
    },
    targetRelays,
    { timeout: timeoutMs }
  );
}

/**
 * Ensure a user is logged in (create a new account if needed).
 */
export async function ensureLoggedIn(page: any, timeoutMs: number = 15000) {
  const hasLoggedInPubkey = () => evaluateWithRetry(page, () => {
    const nostrStore = (window as any).__nostrStore;
    return (nostrStore?.getState?.().pubkey?.length ?? 0) === 64;
  }, undefined).catch(() => false);
  const alreadyLoggedIn = await hasLoggedInPubkey();

  if (!alreadyLoggedIn) {
    await evaluateWithRetry(page, () => {
      void import('/src/nostr.ts')
        .then(({ generateNewKey }) => generateNewKey())
        .catch((err) => console.error('[test-utils] generateNewKey failed', err));
    }, undefined);
  }

  await page.waitForFunction(() => {
    const nostrStore = (window as any).__nostrStore;
    return nostrStore?.getState()?.pubkey?.length === 64;
  }, { timeout: timeoutMs });
}

/**
 * Wait for new user setup to complete and navigate to public folder.
 * New users get three default folders created (public, link, private).
 * This function waits for setup, then clicks into the public folder.
 */
export async function navigateToPublicFolder(
  page: any,
  options?: { timeoutMs?: number; requireRelay?: boolean }
) {
  const timeoutMs = options?.timeoutMs ?? 30000;
  const requireRelay = options?.requireRelay ?? true;
  const relayTimeoutMs = requireRelay ? timeoutMs : Math.min(timeoutMs, 3000);
  const waitForRelay = () => requireRelay
    ? waitForRelayConnected(page, relayTimeoutMs)
    : waitForRelayConnected(page, relayTimeoutMs).catch(() => {});
  const appPath = new URL(page.url()).pathname || '/';

  // First wait for the app to be ready - look for the Iris header
  await waitForAppReady(page, timeoutMs);
  await ensureLoggedIn(page, timeoutMs);
  await waitForRelay();

  // If we're already inside public (auto-redirect), just wait for actions and return
  const alreadyInPublic = await page.waitForFunction(() => {
    return /^#\/npub[^/]+\/public/.test(window.location.hash);
  }, { timeout: 5000 }).then(() => true).catch(() => false);
  if (alreadyInPublic) {
    const actionsButton = page.getByRole('button', { name: /New Repository|New Folder|File/i }).first();
    await expect(actionsButton).toBeVisible({ timeout: 10000 });
    return;
  }

  // Wait for the public folder link to appear in the tree list (indicates setup complete)
  // This can take a while for new users since default folders are created async
  // and published to Nostr fire-and-forget style
  const publicLink = page.getByRole('link', { name: 'public' }).first();
  const resolveLoggedInNpub = async () => {
    const storeNpub = await evaluateWithRetry(page, () => {
      const nostrStore = (window as any).__nostrStore;
      return nostrStore?.getState?.().npub ?? null;
    }, undefined).catch(() => null);
    if (storeNpub) return storeNpub;

    const publicHref = await publicLink.getAttribute('href').catch(() => null);
    const publicNpub = publicHref?.match(/#\/(npub1[^/]+)/)?.[1] ?? null;
    if (publicNpub) return publicNpub;

    return page.url().match(/npub1[a-z0-9]+/)?.[0] ?? null;
  };
  let npub = await resolveLoggedInNpub();

  if (!await publicLink.isVisible().catch(() => false)) {
    const logoLink = page.locator('header a[href="#/"]').first();
    if (await logoLink.isVisible().catch(() => false)) {
      await logoLink.click();
    }
    await page.evaluate(async (treeNpub) => {
      const npub = treeNpub;
      if (!npub) return;
      const { getLocalRootCache } = await import('/src/treeRootCache.ts');
      const { createTree } = await import('/src/actions/tree.ts');
      const defaults: Array<{ name: string; visibility: 'public' | 'link-visible' | 'private' }> = [
        { name: 'public', visibility: 'public' },
        { name: 'link', visibility: 'link-visible' },
        { name: 'private', visibility: 'private' },
      ];
      for (const { name, visibility } of defaults) {
        if (!getLocalRootCache(npub, name)) {
          await createTree(name, visibility, true);
        }
      }
    }, npub).catch(() => {});
  }

  for (let attempt = 0; attempt < 2 && !await publicLink.isVisible().catch(() => false); attempt++) {
    await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
    await waitForAppReady(page, timeoutMs);
    await waitForRelay();
    npub = npub ?? await resolveLoggedInNpub();
  }

  const publicHash = await publicLink.getAttribute('href').catch(() => null);
  const npubFromLink = publicHash?.match(/#\/(npub1[^/]+)/)?.[1] ?? null;
  let resolvedNpub = npub ?? npubFromLink;

  for (let attempt = 0; attempt < 5 && !resolvedNpub; attempt++) {
    await page.waitForTimeout(500);
    resolvedNpub = await resolveLoggedInNpub();
  }

  if (!resolvedNpub) {
    throw new Error('Failed to resolve logged-in npub for public folder navigation');
  }

  const targetHash = publicHash?.startsWith('#/') ? publicHash : `#/${resolvedNpub}/public`;
  await page.evaluate((hash) => {
    const nextHash = hash.startsWith('#') ? hash : `#${hash}`;
    if (window.location.hash === nextHash) {
      window.dispatchEvent(new HashChangeEvent('hashchange'));
      return;
    }
    window.location.hash = nextHash;
  }, targetHash).catch(() => {});
  const navigatedByHash = await page.waitForFunction(
    (hash) => window.location.hash === hash,
    targetHash,
    { timeout: 5000 }
  ).then(() => true).catch(() => false);
  if (!navigatedByHash) {
    await safeGoto(page, `${appPath}${targetHash}`, { timeoutMs, retries: 3, delayMs: 500 });
  }
  await waitForAppReady(page, timeoutMs);
  await waitForRelay();

  // Wait for navigation to complete and folder actions to be visible
  await page.waitForFunction(
    () => /^#\/npub[^/]+\/public/.test(window.location.hash),
    undefined,
    { timeout: timeoutMs }
  );
  await expect(page.getByRole('button', { name: /New Folder|File/i }).first()).toBeVisible({ timeout: Math.max(20000, timeoutMs) });
}

/**
 * Navigate to user's tree list (home/root).
 * Clicks the logo in the header which links to home.
 */
export async function goToTreeList(page: any) {
  // Click the hashtree logo to go home
  const logoLink = page.locator('header a[href="#/"]').first();
  await expect(logoLink).toBeVisible({ timeout: 30000 });
  await logoLink.click();
  await page.waitForFunction(
    () => window.location.hash === '' || window.location.hash === '#/' || window.location.hash === '#',
    { timeout: 15000 }
  );

  // Wait for tree list to be visible (list view uses the same file list container)
  await expect(page.locator('[data-testid="file-list"]').first()).toBeVisible({ timeout: 30000 });
}

/**
 * Disable the "others pool" for WebRTC connections.
 * This prevents the app from connecting to random peers from other parallel tests.
 * Use this for single-user tests that don't need WebRTC connections but might be
 * affected by incoming data from parallel test instances.
 *
 * IMPORTANT: Call this BEFORE any navigation or state changes in the test.
 */
export async function disableOthersPool(page: any) {
  await waitForAppShell(page);
  await waitForOptionalWorkerAdapter(page);
  await evaluateWithRetry(page, async () => {
    const win = window as any;
    let adapter = win.__getWorkerAdapter?.();
    if (!adapter) {
      const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
      adapter = getWorkerAdapter();
    }
    const { stopDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    await stopDriveFipsRuntime();
    adapter?.setP2PProvider?.(null);
  }, undefined);
}

/**
 * Force any pending tree publishes to complete.
 * Useful when a test needs newly created trees to be visible to another user.
 */
export async function flushPendingPublishes(page: any): Promise<void> {
  await waitForTestHelpers(page);
  await waitForWorkerAdapter(page);
  await evaluateWithRetry(page, async () => {
    const { flushPendingPublishes: flush } = await import('/src/treeRootCache.ts');
    await flush();
  }, undefined);
}

/**
 * Enable the "others pool" for WebRTC connections.
 * Use this for tests that need same-user cross-device sync (same account on two browsers).
 * In test mode, the others pool is disabled by default to prevent interference.
 *
 * @param page - Playwright page
 * @param max - Maximum number of peers (default: 10)
 *
 * IMPORTANT: Call this AFTER login but BEFORE operations that need WebRTC.
 */
export async function enableOthersPool(page: any, _max: number = 10) {
  await waitForTestHelpers(page);
  await waitForWorkerAdapter(page);
  await page.waitForFunction(async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    return getDriveFipsRuntime()?.getStats().active === true;
  }, undefined, { timeout: 30_000 });
}

/**
 * Pre-set pool settings in IndexedDB before page load/reload.
 * This ensures WebRTC initializes with correct pool limits since it starts
 * before enableOthersPool can be called.
 *
 * IMPORTANT: Call this BEFORE reload when you need others pool enabled on init.
 */
export async function presetOthersPoolInDB(page: any) {
  await page.evaluate(async () => {
    // Open without version to use current version (Dexie manages versioning)
    const request = indexedDB.open('hashtree-settings');
    await new Promise<void>((resolve, reject) => {
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        // Check if the 'settings' object store exists
        if (!db.objectStoreNames.contains('settings')) {
          db.close();
          // Need to create the object store with version upgrade
          const upgradeRequest = indexedDB.open('hashtree-settings', db.version + 1);
          upgradeRequest.onupgradeneeded = () => {
            const upgradeDb = upgradeRequest.result;
            if (!upgradeDb.objectStoreNames.contains('settings')) {
              upgradeDb.createObjectStore('settings', { keyPath: 'key' });
            }
          };
          upgradeRequest.onsuccess = () => {
            const newDb = upgradeRequest.result;
            const tx = newDb.transaction('settings', 'readwrite');
            const store = tx.objectStore('settings');
            store.put({
              key: 'pools',
              value: {
                followsMax: 20,
                followsSatisfied: 10,
                otherMax: 10,
                otherSatisfied: 2
              }
            });
            tx.oncomplete = () => {
              newDb.close();
              resolve();
            };
            tx.onerror = () => reject(tx.error);
          };
          upgradeRequest.onerror = () => reject(upgradeRequest.error);
        } else {
          const tx = db.transaction('settings', 'readwrite');
          const store = tx.objectStore('settings');
          store.put({
            key: 'pools',
            value: {
              followsMax: 20,
              followsSatisfied: 10,
              otherMax: 10,
              otherSatisfied: 2
            }
          });
          tx.oncomplete = () => {
            db.close();
            resolve();
          };
          tx.onerror = () => reject(tx.error);
        }
      };
    });
  });
}

/**
 * Pre-set network relay settings in IndexedDB before page load.
 * This ensures the worker initializes with the local relay in test runs.
 *
 * IMPORTANT: Call this BEFORE the first page navigation.
 */
export function getTestRelayUrl(): string {
  return process.env.PW_TEST_RELAY_URL || process.env.VITE_TEST_RELAY || 'ws://localhost:4736';
}

export function getTestBlossomUrl(): string {
  return process.env.PW_TEST_BLOSSOM_URL || process.env.VITE_TEST_BLOSSOM_URL || 'http://127.0.0.1:18780';
}

export function getCrosslangPort(workerIndex: number): number {
  const baseEnv = Number(process.env.CROSSLANG_BASE_PORT);
  const basePort = Number.isFinite(baseEnv) && baseEnv > 0 ? baseEnv : 19090;
  const offset = Number.isFinite(workerIndex) && workerIndex >= 0 ? workerIndex : 0;
  return basePort + offset;
}

export async function presetLocalRelayInDB(page: any, relayUrl: string = getTestRelayUrl()) {
  await page.evaluate(async (relay: string) => {
    const request = indexedDB.open('hashtree-settings');
    await new Promise<void>((resolve, reject) => {
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('settings')) {
          db.close();
          const upgradeRequest = indexedDB.open('hashtree-settings', db.version + 1);
          upgradeRequest.onupgradeneeded = () => {
            const upgradeDb = upgradeRequest.result;
            if (!upgradeDb.objectStoreNames.contains('settings')) {
              upgradeDb.createObjectStore('settings', { keyPath: 'key' });
            }
          };
          upgradeRequest.onsuccess = () => {
            const newDb = upgradeRequest.result;
            const tx = newDb.transaction('settings', 'readwrite');
            const store = tx.objectStore('settings');
            store.put({
              key: 'network',
              value: {
                relays: [relay],
                blossomServers: [],
                negentropyEnabled: false,
              },
            });
            tx.oncomplete = () => {
              newDb.close();
              resolve();
            };
            tx.onerror = () => reject(tx.error);
          };
          upgradeRequest.onerror = () => reject(upgradeRequest.error);
          return;
        }

        const tx = db.transaction('settings', 'readwrite');
        const store = tx.objectStore('settings');
        store.put({
          key: 'network',
          value: {
            relays: [relay],
            blossomServers: [],
            negentropyEnabled: false,
          },
        });
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => reject(tx.error);
      };
    });
  }, relayUrl);
}

/**
 * Pre-set production relay settings in IndexedDB before page load.
 * This ensures the worker initializes with public relays even on localhost.
 *
 * IMPORTANT: Call this BEFORE reload or initial navigation that should use production relays.
 */
export async function presetProductionRelaysInDB(page: any) {
  await page.evaluate(async () => {
    const { DEFAULT_PUBLIC_RELAYS: relays } = await import('/src/stores/settings.ts');
    const blossomServers = [
      { url: 'https://upload.iris.to', read: false, write: true },
      { url: 'https://cdn.iris.to', read: true, write: false },
    ];

    const request = indexedDB.open('hashtree-settings');
    await new Promise<void>((resolve, reject) => {
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('settings')) {
          db.close();
          const upgradeRequest = indexedDB.open('hashtree-settings', db.version + 1);
          upgradeRequest.onupgradeneeded = () => {
            const upgradeDb = upgradeRequest.result;
            if (!upgradeDb.objectStoreNames.contains('settings')) {
              upgradeDb.createObjectStore('settings', { keyPath: 'key' });
            }
          };
          upgradeRequest.onsuccess = () => {
            const newDb = upgradeRequest.result;
            const tx = newDb.transaction('settings', 'readwrite');
            const store = tx.objectStore('settings');
            store.put({
              key: 'network',
              value: {
                relays,
                blossomServers,
                negentropyEnabled: false,
              },
            });
            tx.oncomplete = () => {
              newDb.close();
              resolve();
            };
            tx.onerror = () => reject(tx.error);
          };
          upgradeRequest.onerror = () => reject(upgradeRequest.error);
          return;
        }

        const tx = db.transaction('settings', 'readwrite');
        const store = tx.objectStore('settings');
        store.put({
          key: 'network',
          value: {
            relays,
            blossomServers,
            negentropyEnabled: false,
          },
        });
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => reject(tx.error);
      };
    });
  });
}

/**
 * Configure the app to use the local test relay instead of public relays.
 * This eliminates network flakiness and rate limiting issues during tests.
 *
 * Updates both settings store (for future store creations) and the
 * existing WebRTC store (for immediate effect on current connections).
 */
export async function useLocalRelay(page: any, relayOverride?: string) {
  await waitForTestHelpers(page);
  await waitForWorkerAdapter(page);
  const localRelay = relayOverride || getTestRelayUrl();
  await evaluateWithRetry(page, async (relay) => {
    // Update settings store for future store creations
    const { settingsStore } = await import('/src/stores/settings.ts');
    settingsStore.setNetworkSettings({
      relays: [relay],
    });

    // Also update the running WebRTC store if it exists
    // Use window global which is always in sync with the app
    const store = (window as unknown as { webrtcStore?: { setRelays?: (relays: string[]) => void } }).webrtcStore;
    if (store && typeof store.setRelays === 'function') {
      store.setRelays([relay]);
    }

    // Directly update worker's relay runtime via worker adapter
    const getWorkerAdapter = (window as any).__getWorkerAdapter;
    if (getWorkerAdapter) {
      const adapter = getWorkerAdapter();
      if (adapter?.setRelays) {
        console.log('[useLocalRelay] Syncing relay to worker:', relay);
        await adapter.setRelays([relay]);
      }
    }
  }, localRelay);
}

/**
 * Configure Blossom servers for tests that need them.
 * In e2e, this points at the local hashtree Blossom server (no external HTTP).
 * Call this for tests that specifically test Blossom functionality.
 *
 * Uses a global function exposed by the settings module to avoid Vite module duplication issues.
 */
export async function configureBlossomServers(page: any, blossomUrl: string = getTestBlossomUrl()) {
  await waitForTestHelpers(page);
  await waitForOptionalWorkerAdapter(page);
  await evaluateWithRetry(page, async (url: string) => {
    const configure = (window as unknown as { __configureBlossomServers?: (servers: unknown[]) => void }).__configureBlossomServers;
    if (!configure) {
      throw new Error('__configureBlossomServers not found - settings module may not be loaded');
    }
    configure([
      { url, read: true, write: true },
    ]);
    const adapter = (window as any).__getWorkerAdapter?.() ?? (window as any).__workerAdapter;
    if (adapter?.setBlossomServers) {
      await adapter.setBlossomServers([{ url, read: true, write: true }]);
    }
  }, blossomUrl);
}

/**
 * Helper to follow a user by their npub.
 * Navigates to target's profile and clicks Follow, waiting for completion.
 * Use this to establish reliable WebRTC connections via the "follows pool".
 */
export async function followUser(page: any, targetNpub: string) {
  // Navigate to the user's profile page
  const currentUrl = new URL(page.url());
  await page.goto(`${currentUrl.origin}/#/${targetNpub}`);

  // Dismiss any modal that might intercept the follow button
  const modalBackdrop = page.locator('.fixed.inset-0').first();
  if (await modalBackdrop.isVisible().catch(() => false)) {
    await page.keyboard.press('Escape').catch(() => {});
    await modalBackdrop.waitFor({ state: 'hidden', timeout: 1000 }).catch(() => {});
    if (await modalBackdrop.isVisible().catch(() => false)) {
      const closeBtn = modalBackdrop.getByRole('button', { name: /close|cancel|back/i }).first();
      if (await closeBtn.isVisible().catch(() => false)) {
        await closeBtn.click().catch(() => {});
      } else {
        await modalBackdrop.click({ position: { x: 5, y: 5 } }).catch(() => {});
      }
    }
    await modalBackdrop.waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  }

  // Click the Follow button
  const followButton = page.getByRole('button', { name: 'Follow', exact: true });
  await expect(followButton).toBeVisible({ timeout: 5000 });
  await followButton.click();

  // Wait for follow to complete - button becomes disabled or changes to "Following" or "Unfollow"
  await expect(
    page.getByRole('button', { name: 'Following' })
      .or(page.getByRole('button', { name: 'Unfollow' }))
      .or(followButton.and(page.locator('[disabled]')))
  ).toBeVisible({ timeout: 10000 });
}

/**
 * Wait for a pubkey to be in the worker's follows set.
 * This is essential before sending WebRTC hellos - ensures the peer will be
 * classified in the "follows" pool rather than "other" pool.
 */
export async function waitForFollowInWorker(page: any, pubkeyHex: string, timeoutMs: number = 15000): Promise<boolean> {
  return page.waitForFunction(
    (pk: string) => {
      const store = (window as any).webrtcStore;
      if (!store) return false;
      // Check via internal API that exposes followsSet
      const isFollowing = store.isFollowing?.(pk);
      if (isFollowing) return true;
      // Fallback: check directly if available
      const followsSet = store.getFollowsSet?.();
      return followsSet?.has?.(pk) ?? false;
    },
    pubkeyHex,
    { timeout: timeoutMs }
  ).then(() => true).catch(() => false);
}

/**
 * Wait for WebRTC connection to be established.
 * Polls until at least one peer is connected with data channel open.
 * If targetPubkey is provided, waits for that specific peer to connect.
 * Use this after users follow each other to ensure WebRTC is ready.
 */
export async function waitForWebRTCConnection(page: any, timeoutMs: number = 15000, targetPubkey?: string): Promise<boolean> {
  return page.waitForFunction(
    async (target: string | null) => {
      const adapter = (window as unknown as { __workerAdapter?: { getPeerStats: () => Promise<Array<{ connected?: boolean; pubkey?: string }>> } }).__workerAdapter;
      if (!adapter) return false;
      try {
        const stats = await adapter.getPeerStats();
        const connected = stats.filter((p: { connected?: boolean }) => p.connected);
        if (!target) return connected.length > 0;
        return connected.some((p: { pubkey?: string }) => p.pubkey === target);
      } catch {
        return false;
      }
    },
    targetPubkey ?? null,
    { timeout: timeoutMs, polling: 500 }
  ).then(() => true).catch(() => false);
}

/**
 * Login as a test user with a given nsec.
 * Sets the nsec in localStorage and reloads the page.
 *
 * @param page - Playwright page
 * @param nsec - Nostr secret key in bech32 format (nsec1...)
 */
export async function loginAsTestUser(page: any, nsec: string) {
  await page.evaluate((secret: string) => {
    localStorage.setItem('hashtree:loginType', 'nsec');
    localStorage.setItem('hashtree:nsec', secret);
  }, nsec);
  await page.reload();
  // Wait for app to be ready after login
  await expect(page.locator('header').first()).toBeVisible({ timeout: 30000 });
  await page.waitForFunction(() => {
    const store = (window as any).__nostrStore;
    return store?.getState?.().pubkey?.length === 64;
  }, { timeout: 30000 });
}

/**
 * Create a new folder using the UI.
 * Clicks "New Folder" button, fills the name, and waits for modal to close.
 *
 * @param page - Playwright page
 * @param folderName - Name of the folder to create
 */
export async function createFolder(page: any, folderName: string) {
  await page.getByRole('button', { name: 'New Folder' }).click();
  const input = page.locator('input[placeholder="Folder name..."]');
  await input.waitFor({ timeout: 5000 });
  await input.fill(folderName);
  await page.click('button:has-text("Create")');
  await expect(page.locator('.fixed.inset-0.bg-black')).not.toBeVisible({ timeout: 10000 });
}

/**
 * Clear all browser storage (IndexedDB, localStorage, sessionStorage).
 * Use this to reset state between tests or create a fresh user.
 */
export async function clearAllStorage(page: any) {
  await page.evaluate(async () => {
    const dbs = await indexedDB.databases();
    await Promise.all(dbs.map((db) => new Promise<void>((resolve) => {
      if (!db.name) {
        resolve();
        return;
      }
      const req = indexedDB.deleteDatabase(db.name);
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
      req.onblocked = () => resolve();
    })));
    localStorage.clear();
    sessionStorage.clear();
  });
}

/**
 * Setup a fresh user by clearing all storage and reloading.
 * Combines setupPageErrorHandler, goto, clearAllStorage, reload, and waitForAppReady.
 */
export async function setupFreshUser(page: any, options?: { timeoutMs?: number }) {
  setupPageErrorHandler(page);
  await safeGoto(page, '/', { retries: 4, delayMs: 1500 });
  await clearAllStorage(page);
  await safeGoto(page, '/', { retries: 4, delayMs: 1500 });
  await waitForAppReady(page, options?.timeoutMs ?? 30000);
}

/**
 * Add a file to the tree via the tree API.
 * This is faster than using the UI for file creation in tests.
 *
 * @param page - Playwright page
 * @param routePath - Path segments to the parent directory (empty for root)
 * @param filename - Name of the file to create
 * @param content - Text content of the file
 * @returns The new root CID, or null if failed
 */
export async function addFileViaTreeAPI(page: any, routePath: string[], filename: string, content: string): Promise<string | null> {
  return page.evaluate(async ({ routePath, filename, content }: { routePath: string[], filename: string, content: string }) => {
    const { getTree, LinkType } = await import('/src/store.ts');
    const { autosaveIfOwn } = await import('/src/nostr.ts');
    const { getCurrentRootCid } = await import('/src/actions/route.ts');
    const tree = getTree();
    const rootCid = getCurrentRootCid();
    if (!rootCid) return null;
    const data = new TextEncoder().encode(content);
    const { cid: fileCid, size } = await tree.putFile(data);
    const newRootCid = await tree.setEntry(rootCid, routePath, filename, fileCid, size, LinkType.Blob);
    autosaveIfOwn(newRootCid);
    return newRootCid;
  }, { routePath, filename, content });
}

/**
 * Navigate into a folder by clicking its link in the file list.
 * Waits for the folder to appear and for navigation to complete.
 *
 * @param page - Playwright page
 * @param folderName - Name of the folder to navigate into
 */
export async function navigateIntoFolder(page: any, folderName: string) {
  const folderLink = page.locator('[data-testid="file-list"] a').filter({ hasText: folderName }).first();
  await expect(folderLink).toBeVisible({ timeout: 15000 });
  await folderLink.click();
  await page.waitForURL(new RegExp(folderName), { timeout: 10000 });
}

/**
 * Get the current directory's nhash permalink.
 * This uses the app's bundled hashtree module to avoid msgpack resolution issues.
 */
export async function getCurrentDirNhash(page: any): Promise<string | null> {
  return page.evaluate(async () => {
    const { currentDirCidStore } = await import('/src/stores/index.ts');
    const { nhashEncode } = await import('/src/lib/nhash.ts');

    let dirCid: { hash: Uint8Array; key?: Uint8Array } | null = null;
    const unsub = currentDirCidStore.subscribe((v: { hash: Uint8Array; key?: Uint8Array } | null) => { dirCid = v; });
    unsub();

    if (!dirCid) return null;
    return nhashEncode(dirCid);
  });
}
