import { test, expect } from './fixtures';
import { setupPageErrorHandler, waitForAppReady, disableOthersPool } from './test-utils';

const CATALOG_URL = 'htree://npub1catalog/videos';
const CATALOG_TITLE = `CatalogIndex${Date.now()}`;
const OWNER_NPUB = 'npub10yf7k3h3nuzpgh8qcxkrux8frd0u0cjgf8p5x65a8w7kqkw0lwdq3l5g9t';

test.describe('Video catalog index', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  test('loads a saved v2 catalog root and searches its deterministic index', async ({ page }) => {
    await page.goto('/video.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    const refreshState = await page.evaluate(async ({ url, title, ownerNpub }) => {
      window.localStorage.setItem('iris-video:catalog-url', url);
      window.localStorage.setItem('iris-video:catalog-urls', JSON.stringify([url]));
      const catalogs = await import('/src/stores/videoCatalogs.ts');
      const state = await catalogs.refreshSavedVideoCatalogs(async (requestUrl: string) => {
        const body = requestUrl.endsWith('/root.json')
          ? {
              schema: 'iris.video.catalog.v2',
              title: 'E2E Catalog',
              collections: {
                videos: { manifestPath: 'collections/videos/manifest.json' },
              },
              videos: [
                {
                  title: `${title} deterministic clip`,
                  ownerNpub,
                  treeName: `videos/${title} deterministic clip`,
                  timestamp: 1_765_000_000,
                  tags: ['catalog-index'],
                },
              ],
            }
          : {
              version: 1,
              sourceId: 'npub1catalog/videos',
              schemaVersion: 2,
              updatedAt: 1,
              itemCount: 0,
              byIdRoot: null,
              indexes: {},
            };
        return new Response(JSON.stringify(body), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        });
      });
      return {
        error: state.error,
        urls: state.urls,
        videos: state.videos.map((video) => video.title),
      };
    }, { url: CATALOG_URL, title: CATALOG_TITLE, ownerNpub: OWNER_NPUB });
    expect(refreshState.error).toBeNull();
    expect(refreshState.videos).toContain(`${CATALOG_TITLE} deterministic clip`);

    await expect(page.getByText(`${CATALOG_TITLE} deterministic clip`)).toBeVisible({ timeout: 15000 });

    const searchInput = page.locator('header input[placeholder*="Search"]');
    await expect(searchInput).toBeVisible({ timeout: 5000 });
    await searchInput.fill(CATALOG_TITLE.toLowerCase());

    const dropdown = page.locator('div.absolute.top-full');
    await expect(dropdown).toBeVisible({ timeout: 15000 });
    const catalogResult = dropdown.locator('button').filter({ hasText: CATALOG_TITLE });
    await expect(catalogResult).toHaveCount(1, { timeout: 15000 });
    await expect(catalogResult).toBeVisible({ timeout: 15000 });
    await searchInput.fill('');
    await page.keyboard.press('Escape');

    await page.goto(`/video.html#/${OWNER_NPUB}/profile`);
    await waitForAppReady(page);
    const profileVideoCard = page.locator(`a[href*="${encodeURIComponent(`videos/${CATALOG_TITLE} deterministic clip`)}"]`)
      .filter({ hasText: `${CATALOG_TITLE} deterministic clip` });
    await expect(profileVideoCard).toHaveCount(1, { timeout: 15000 });
    await expect(profileVideoCard).toBeVisible({ timeout: 15000 });
  });
});
