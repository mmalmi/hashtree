# Iris Video

Hashtree-backed decentralized video app for `video.iris.to`.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-video>
Live: <https://video.iris.to/>

Iris Video supports existing single video trees announced on Nostr and a catalog-first browse/search path. Catalogs are user-maintained roots containing `root.json`; the app stores catalog root URLs locally, loads them quickly, and searches loaded catalog entries deterministically before falling back to relay-discovered video events.

## Catalogs

Catalog root URLs should point to the directory root, not directly to `root.json`:

```text
htree://npub.../videos
https://example.test/video-catalog
```

The root should contain `root.json` with `videos`, `items`, or `entries`:

```json
{
  "schema": "iris.video.catalog.v1",
  "title": "Open Videos",
  "videos": [
    {
      "title": "Big Buck Bunny",
      "ownerNpub": "npub1...",
      "treeName": "videos/Big Buck Bunny",
      "duration": 596,
      "timestamp": 1765000000,
      "tags": ["animation"]
    }
  ]
}
```

Entries may also provide an explicit `href` or `nhash` for immutable single-video links.

### V2 Collection Catalogs

`root.json` remains compatible with v1 `videos`, `items`, or `entries`, and may also advertise a v2 collection manifest:

```json
{
  "schema": "iris.video.catalog.v2",
  "title": "Open Videos",
  "collections": {
    "videos": {
      "manifestPath": "collections/videos/manifest.json"
    }
  },
  "videos": []
}
```

The video collection manifest uses the Hashtree collection shape with a canonical by-id root plus indexes named `by-author`, `by-source-event`, `by-nhash`, `tag`, `videos`, `creators`, and `tags`. `root.json` may keep a bounded recent `videos` list for fast home-feed compatibility while the manifest carries the full searchable index.

The app queries deterministic catalog indexes before relay-discovered video events. It also builds a local deterministic collection from saved catalogs and trusted video events. Own public Iris Video events are indexed by default; followed and allowlisted authors can be enabled under `#/catalogs`.

For `video.iris.to`, a crawler-published default catalog can be configured at build/deploy time:

```bash
VITE_DEFAULT_VIDEO_CATALOG_URLS='htree://npub.../iris-video/index'
```

Multiple default roots may be comma- or newline-separated. User-saved catalogs are layered after defaults and remain removable in `#/catalogs`; default roots are shown as built-in sources.

Profile pages query loaded catalog indexes by author before relying on live tree discovery. Optional creator-owned catalog roots can be probed by setting fixed tree names:

```bash
VITE_VIDEO_AUTHOR_INDEX_TREE_NAMES='iris-video/index,videos/index'
```

Live Nostr lookup stays enabled as the safety net so existing videos remain reachable while the default crawled index catches up.

## Development

```bash
pnpm install
pnpm run dev
pnpm run build
pnpm run smoke
```

Focused checks:

```bash
pnpm run test:unit
pnpm run test:portable-build
```

Release:

```bash
pnpm run release:site
```

The release script builds the video app, runs the focused unit/config gate, smokes that exact output, runs the video e2e suite, publishes the built directory to hashtree, and then deploys the same directory to Cloudflare.
