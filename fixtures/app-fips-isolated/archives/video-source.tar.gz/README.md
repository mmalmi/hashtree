# Iris Video

Hashtree-backed decentralized video app for `video.iris.to`.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-video>
Live: <https://video.iris.to/>

Videos are hashtree trees (`videos/<title>`) announced on Nostr. Browse, search and channel pages are built from [NIP-71](https://github.com/nostr-protocol/nips/blob/master/71.md) video events fetched from relays, including web-hosted videos other apps publish; the tree root events only say where hashtree content is. A video with no video event is not listed or searchable; its owner still sees it on their own channel.

## Video events

Every public video is announced by its owner as an addressable kind `34235` event. Saving a video in the app (upload, livestream, import, playlist or metadata edit) publishes or updates it; deleting the video, or making it private, retracts it with a NIP-09 deletion request.

```json
{
  "kind": 34235,
  "content": "<summary, at most 1200 characters>",
  "tags": [
    ["d", "videos/Big Buck Bunny"],
    ["title", "Big Buck Bunny"],
    ["published_at", "1765000000"],
    ["alt", "Video: Big Buck Bunny"],
    ["duration", "596"],
    ["imeta",
      "url htree://npub1.../videos%2FBig%20Buck%20Bunny/video.mp4",
      "m video/mp4",
      "image htree://nhash1.../thumbnail.jpg",
      "duration 596.4"],
    ["r", "https://video.iris.to/#/npub1.../videos%2FBig%20Buck%20Bunny"],
    ["t", "animation"]
  ]
}
```

- The `imeta` `url` is `htree://<npub>/<encoded tree name>[/<playlist item>]/<file>` and identifies the video. An event pointing into somebody else's tree is ignored, so an author can only list their own hashtree videos. Kind `34236` (short video) is read the same way.
- Playlist items get one event each, with `d` set to `<tree name>/<item>`.

### Videos from everywhere

The app also lists video events other apps publish: kinds `34235`/`34236` and the regular kinds `21`/`22`, with web-hosted media in `imeta` (or a legacy `url` tag). Those open on `#/v/<naddr|note>` and play straight from their URL; stream playlists most browsers cannot play are skipped, and videos carrying a `content-warning` tag are left out of the feed and search.

- **Feed.** Each relay is asked for recent videos from any author, with a separate limit for each video event kind. The first page and its authors' names appear as each relay answers. A later request looks up earlier videos by up to five discovered creators outside the viewer's network. The app also fetches videos from the viewer and their follows, or from default accounts when the viewer follows few people.
- **Ranking** (`src/lib/videoRanking.ts`, same shape as the Iris Market home feed): `3 × trust + 3 × ln(1 + engagement) + freshness`, where trust comes from the author's follow distance (2.5 within one hop, 1.5 at two, 0.75 at three), engagement counts the people who liked, reposted or commented weighted by their own follow distance, and freshness halves every 14 days. Each further video by the same author and each repeated title is pushed down. A viewer who follows nobody is measured from the default account's network.
- **Selectors.** All / Following, and Hot / New / Top (most engagement). In All / Hot, after two consecutive videos from the viewer's network, the next spot goes to the highest-ranked available video from outside it.
- **New.** Scrolling to the end loads older videos from the selected relays. Each relay pages back independently. Following uses the same author filter on every page. A “Load more videos” button also works when the list fits on screen or a relay lookup needs a retry.
- **Stability.** Cards through the last visible row keep their places. Cards below the viewport update automatically, as do Shorts beyond the visible end of the strip. "Show updated videos" appears when applying the new order would move protected cards.
- **Shorts.** Short vertical clips (kinds `22`/`34236`, or portrait `dim`) have their own row and open in a full-height viewer at `#/shorts/<naddr|note>`: one clip at a time, looping, with scroll, swipe or the arrow keys to move on; Escape leaves the viewer. A button in the viewer makes the next short follow automatically instead; the choice is remembered. Shorts already played in this browser come after the ones new to the viewer, in the viewer and in the row. Tapping the caption opens the description.
- **Likes and comments** on these videos are the events other Nostr apps use: NIP-25 reactions (kind `7`) and NIP-22 comments (kind `1111`) naming the video event. Reply notes (kind `1`) answering the video are read as comments too, since many apps comment that way. Replies are grouped under the comment they answer; a reply is written in the form of what it answers (kind `1111` to a comment, kind `1` to a reply note). In the shorts viewer they sit beside the clip on a wide screen and in a sheet over its lower part on a narrow one.
- **Repeat posts and mirrors.** An author's repeat posts of the same file (same `x` hash, else the same URL) are listed once, the earliest; each still opens from its own link. A hash-named file that fails to load is tried on the other file servers the event mentions. When those fail too, the author's file-server list (kind `10063`) is looked up and their other servers are tried, for the video and for its preview image; a preview that exists nowhere is replaced by a frame of the video.
- **Playlists as video sets.** A playlist is announced as a NIP-51 video set (kind `30005`, `d` = the tree name, one `a` tag per video event, in order), the playlist format other apps read. Sets from any app are listed on their author's channel and open at `#/list/<naddr>`. The backfill script publishes the sets of existing playlists too.
- **Channels** list playlists, shorts and videos in separate sections.
- **Text.** Comments, descriptions, channel bios and shorts captions make their links, pictures, `nostr:` mentions and hashtags useful (`src/lib/richText.ts`), and long text is cut behind "Show more". A hashtag opens `#/t/<tag>`: the videos carrying it, loaded ones at once and the relays' as they arrive.
- **Up next.** Beside a video, a few more from the same author come first, then videos sharing its tags or title words, then the ranked feed; watched videos go last.
- **Images.** Thumbnails and avatars hosted on the web load through an image proxy (Settings → App → Images), so they are resized and their hosts do not see the viewer. A video with no preview image shows a frame from the video itself.
- **Search** runs over everything loaded, ranked by how well the title, tags and description match and then by the same trust and freshness. The relays are also asked (NIP-50 text search where supported, and hashtags), and their matches appear as they arrive. People are found the same way: among the profiles already loaded, plus the relays' text search (kind `0`). Text searches use short-lived connections of their own, to the configured relays that advertise NIP-50, because relays without it reject every filter sent along with a search. Nothing is indexed in hashtree.

Videos uploaded before video events existed can be announced in bulk for one account:

```bash
pnpm run events:publish -- --dry-run
VIDEO_EVENTS_PUBLISH_KEY_ALIAS=self pnpm run events:publish
```

The script reads that account's public `videos/...` trees, skips anything already announced and unchanged, and signs only with the key it is given (`VIDEO_EVENTS_PUBLISH_NSEC`, `NOSTR_SECRET_KEY`, or an alias from `~/.hashtree/keys`).

With `--mirror-from <npub>` it first gives the signing account its own copy of another account's public video trees (the same content, nothing is uploaded again) and then announces them. Tree names the signing account has already used are left alone.

## Development

```bash
pnpm install
pnpm run dev
pnpm run build
pnpm run smoke
```

Focused checks:

```bash
pnpm run test:unit
pnpm run test:portable-build
```

Release:

```bash
pnpm run release:site
```

The release script builds the video app, runs the focused unit/config gate, smokes that exact output, runs the video e2e suite, publishes the built directory to hashtree, and then deploys the same directory to Cloudflare.
