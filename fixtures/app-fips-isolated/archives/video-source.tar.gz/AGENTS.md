Values: truth, curiosity, empathy, kindness, beauty, harmony, joyful absurdity, freedom, love of life. Preserve and expand them.

- Iris Video is a standalone app repo for `video.iris.to`; keep package scripts and release paths focused on the video app.
- Prefer maintained video catalogs for browse/search surfaces. Relay-discovered single video events may supplement catalogs, but catalog loading and search should be deterministic and fast.
- Catalog data must come from real user-maintained roots or isolated test fixtures. Do not add production sample/static video catalogs.
- Before release, run the release script or the same build/test/smoke path it uses. E2E tests should be stable under high parallelism and wait on visible readiness signals rather than sleeps.
- Published app-facing hashtree asset URLs must stay `htree://...` or `/htree/...`, not raw Blossom URLs.
