import 'virtual:uno.css';
import VideoApp from './VideoApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker } from './lib/swInit';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { mergeBootstrapIndex } from './stores/searchIndex';
import { setAppType } from './appType';
import { initHtreeApi } from './lib/htreeApi';
import { installHtreeDebugCapture } from './lib/htreeDebug';
import { ensureMediaStreamingReady } from './lib/mediaStreamingSetup';

setAppType('video');
installHtreeDebugCapture();

async function init() {
  await initServiceWorker({ requireCrossOriginIsolation: true }).catch((error) => {
    console.error('[main-video] Service worker initialization failed:', error);
  });
  const htreePromise = initHtreeApi();
  const backendPromise = initReadonlyBackend();
  const sessionPromise = restoreSession();
  mount(VideoApp, {
    target: document.getElementById('app')!,
  });

  const mediaPromise = backendPromise
    .then(() => ensureMediaStreamingReady().catch(() => false))
    .catch((error) => {
      console.error('[main-video] Backend initialization failed:', error);
      return false;
    });
  sessionPromise.catch((error) => {
    console.error('[main-video] Session restore failed:', error);
  });
  htreePromise.catch((error) => {
    console.error('[main-video] htree API initialization failed:', error);
  });
  Promise.allSettled([sessionPromise, htreePromise, mediaPromise]).then(() => {
    mergeBootstrapIndex().catch(() => {});
  });
}

init().catch((error) => {
  console.error('[main-video] Startup failed:', error);
});
if (import.meta.env.DEV && import.meta.env.VITE_TEST_MODE) {
  void import('./lib/testHelpers').then(({ setupTestHelpers }) => setupTestHelpers());
}
