import 'virtual:uno.css';
import VideoApp from './VideoApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker } from './lib/swInit';
import { markHtreeReady } from './lib/htreeReady';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { setAppType } from './appType';
import { initHtreeApi } from './lib/htreeApi';
import { installHtreeDebugCapture } from './lib/htreeDebug';
import { ensureMediaStreamingReady } from './lib/mediaStreamingSetup';

setAppType('video');
installHtreeDebugCapture();

async function init() {
  // The page renders straight away. The service worker, which a first visit spends a
  // couple of seconds installing, is only needed for hashtree media: whatever shows
  // that waits for `htreeReady`, and the backend waits for the worker on its own.
  void initServiceWorker({ requireCrossOriginIsolation: true })
    .catch((error) => {
      console.error('[main-video] Service worker initialization failed:', error);
    })
    .then(markHtreeReady);
  const htreePromise = initHtreeApi();
  const sessionPromise = restoreSession();
  const backendPromise = sessionPromise.then(restored => {
    if (!restored) return initReadonlyBackend();
  });
  mount(VideoApp, {
    target: document.getElementById('app')!,
  });

  const mediaPromise = backendPromise
    .then(() => ensureMediaStreamingReady().catch(() => false))
    .catch((error) => {
      console.error('[main-video] Backend initialization failed:', error);
      return false;
    });
  sessionPromise.catch((error) => {
    console.error('[main-video] Session restore failed:', error);
  });
  htreePromise.catch((error) => {
    console.error('[main-video] htree API initialization failed:', error);
  });
  mediaPromise.catch(() => {});
}

init().catch((error) => {
  console.error('[main-video] Startup failed:', error);
});
if (import.meta.env.DEV && import.meta.env.VITE_TEST_MODE) {
  void import('./lib/testHelpers').then(({ setupTestHelpers }) => setupTestHelpers());
}
