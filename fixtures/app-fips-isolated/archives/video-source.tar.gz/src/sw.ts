/**
 * Service Worker with File Streaming Support
 *
 * Intercepts file requests and streams data from main thread:
 * - /htree/{npub}/{treeName}/{path} - Npub-based file access
 * - /htree/{nhash}/{filename} - Direct nhash access (content-addressed)
 *
 * Uses WebTorrent-style per-request MessageChannel pattern:
 * - SW creates MessageChannel for each request
 * - Posts request to all clients (windows)
 * - First client to respond wins
 * - Client streams chunks back through the port
 *
 * Routes are namespaced under /htree/ for reusability across apps.
 */

/// <reference lib="webworker" />
import { getRawHtreePath, parseImmutableHtreePath, parseMutableHtreePath } from '@hashtree/worker/htree-path';
import { matchPrecache, precache } from 'workbox-precaching';
import { shouldInterceptHtreeRequestForWorker } from './lib/swRoutePolicy';
import { getSameOriginResponseMode } from './lib/swSameOriginPolicy';
import { lookupWorkerPort, waitForWorkerPort } from './lib/swWorkerPort';
import {
  buildImmutableFileRequest,
  buildMutableFileRequest,
  type FileRequest,
} from './lib/swFileRequest';
import { createSequentialStreamWriter, type SequentialStreamWriter } from './lib/sequentialStreamWriter';

declare let self: ServiceWorkerGlobalScope;

const isTestMode = !!import.meta.env.VITE_TEST_MODE;

if (isTestMode) {
  self.addEventListener('install', (event) => {
    event.waitUntil(self.skipWaiting());
  });

  self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map(key => caches.delete(key)));
      await self.clients.claim();
    })());
  });
}

// Request counter for unique IDs
let requestId = 0;

// Worker ports for direct communication (keyed by client ID)
const workerPorts = new Map<string, MessagePort>();
const workerPortsByClientKey = new Map<string, MessagePort>();
let defaultWorkerPort: MessagePort | null = null;

// Pending requests waiting for worker responses
const pendingRequests = new Map<string, {
  resolve: (response: Response) => void;
  reject: (error: Error) => void;
  controller?: ReadableStreamDefaultController<Uint8Array>;
  stream?: ReadableStream<Uint8Array>;
  streamWriter?: SequentialStreamWriter;
  totalSize?: number;
  headers?: Record<string, string>;
  status?: number;
  onCancel?: () => void;
}>();

// Debug state (enabled per client)
const debugByClientId = new Map<string, boolean>();
const debugByClientKey = new Map<string, boolean>();
let defaultDebug = false;

function resolveDebug(clientId?: string | null, clientKey?: string | null): boolean {
  if (clientKey && debugByClientKey.get(clientKey)) return true;
  if (clientId && debugByClientId.get(clientId)) return true;
  return defaultDebug;
}

function swLog(enabled: boolean, message: string, data?: Record<string, unknown>): void {
  if (!enabled) return;
  if (data) {
    console.log(`[SW] ${message}`, data);
  } else {
    console.log(`[SW] ${message}`);
  }
}

/**
 * Handle messages from main thread (port registration)
 */
self.addEventListener('message', (event: ExtendableMessageEvent) => {
  if (event.data?.type === 'PING_WORKER_PORT') {
    const source = event.source as Client | null;
    const requestId = event.data?.requestId;
    const clientId = source?.id ?? event.data?.clientId;
    const clientKey = event.data?.clientKey as string | undefined;
    const hasPort = (clientKey && workerPortsByClientKey.has(clientKey))
      || (clientId && workerPorts.has(clientId))
      || !!defaultWorkerPort;
    if (requestId && source?.postMessage) {
      source.postMessage({ type: 'WORKER_PORT_PONG', requestId, ok: hasPort });
    }
    return;
  }
  if (event.data?.type === 'REGISTER_WORKER_PORT') {
    const port = event.data?.port ?? event.ports?.[0];
    if (!port) {
      console.warn('[SW] Worker port registration missing MessagePort');
      return;
    }
    const source = event.source as Client | null;
    const clientId = source?.id ?? event.data?.clientId;
    const clientKey = event.data?.clientKey as string | undefined;
    if (clientId) {
      workerPorts.set(clientId, port);
    } else {
      defaultWorkerPort = port;
    }
    if (clientKey) {
      workerPortsByClientKey.set(clientKey, port);
    }
    port.start?.();
    const debugEnabled = !!event.data?.debug;
    if (clientId) {
      if (debugEnabled) debugByClientId.set(clientId, true);
      else debugByClientId.delete(clientId);
    }
    if (clientKey) {
      if (debugEnabled) debugByClientKey.set(clientKey, true);
      else debugByClientKey.delete(clientKey);
    }
    if (!clientId && !clientKey && debugEnabled) {
      defaultDebug = true;
    }
    port.onmessage = handleWorkerMessage;
    console.log('[SW] Worker port registered', clientId ? `for ${clientId}` : '(default)');
    swLog(debugEnabled, 'debug:enabled', { clientId: clientId ?? null, clientKey: clientKey ?? null });
    const requestId = event.data?.requestId;
    if (requestId && source?.postMessage) {
      source.postMessage({ type: 'WORKER_PORT_READY', requestId });
    }
  }
});

/**
 * Handle messages from worker via MessagePort
 */
function handleWorkerMessage(event: MessageEvent): void {
  const msg = event.data;
  if (!msg?.requestId) return;

  const pending = pendingRequests.get(msg.requestId);
  if (!pending) return;

  switch (msg.type) {
    case 'headers': {
      // Got headers - create streaming response
      pending.totalSize = msg.totalSize;
      pending.status = msg.status || 200;
      pending.headers = msg.headers || {};

      // Create the stream for this response
      const { readable, writable } = new TransformStream<Uint8Array>();
      const writer = writable.getWriter();

      pending.streamWriter = createSequentialStreamWriter({
        writer,
        inactivityTimeoutMs: STREAM_INACTIVITY_TIMEOUT,
        timeoutMessage: 'Timed out waiting for file data',
        onTimeout: (error) => {
          pending.onCancel?.();
          console.warn('[SW] File stream timed out:', error.message);
        },
        onError: (error) => {
          pending.onCancel?.();
          console.warn('[SW] File stream failed:', error);
        },
        onClosed: () => {
          pendingRequests.delete(msg.requestId);
        },
      });

      // Build response headers
      const headers = new Headers(pending.headers);
      headers.set('Cross-Origin-Resource-Policy', 'cross-origin');
      headers.set('Cross-Origin-Embedder-Policy', 'credentialless');
      headers.set('Access-Control-Allow-Origin', '*');

      pending.resolve(new Response(readable, {
        status: pending.status,
        headers,
      }));
      break;
    }

    case 'chunk': {
      if (pending.streamWriter && msg.data) {
        const chunk = msg.data instanceof Uint8Array ? msg.data : new Uint8Array(msg.data);
        pending.streamWriter.enqueue(chunk);
      }
      break;
    }

    case 'done': {
      pending.streamWriter?.close();
      if (!pending.streamWriter) {
        pendingRequests.delete(msg.requestId);
      }
      break;
    }

    case 'error': {
      if (pending.streamWriter) {
        pending.streamWriter.abort(new Error(msg.message || 'Worker error'));
        pendingRequests.delete(msg.requestId);
        break;
      }
      const headers = new Headers({
        'Content-Type': 'text/plain; charset=utf-8',
        'Cross-Origin-Resource-Policy': 'cross-origin',
        'Cross-Origin-Embedder-Policy': 'credentialless',
        'Access-Control-Allow-Origin': '*',
      });
      pending.resolve(new Response(msg.message || 'Worker error', {
        status: typeof msg.status === 'number' ? msg.status : 500,
        headers,
      }));
      pendingRequests.delete(msg.requestId);
      break;
    }
  }
}

/**
 * Serve file via direct worker port (preferred path)
 */
function serveFileViaWorker(request: FileRequest, port: MessagePort, debug = false): Promise<Response> {
  return new Promise((resolve, reject) => {
    if (!port) {
      reject(new Error('Worker port not available for client'));
      return;
    }

    // Set timeout
    const timeout = setTimeout(() => {
      const pending = pendingRequests.get(request.requestId);
      if (pending) {
        pending.streamWriter?.dispose();
        pendingRequests.delete(request.requestId);
        swLog(debug, 'worker:timeout', { requestId: request.requestId });
        pending.onCancel?.();
        reject(new Error('Timeout waiting for worker response'));
      }
    }, PORT_TIMEOUT);

    // Clean up timeout on resolution
    const originalResolve = resolve;
    const originalReject = reject;
    const wrappedResolve = (response: Response) => {
      clearTimeout(timeout);
      originalResolve(response);
    };
    const wrappedReject = (error: Error) => {
      clearTimeout(timeout);
      originalReject(error);
    };
    pendingRequests.set(request.requestId, {
      resolve: wrappedResolve,
      reject: wrappedReject,
      onCancel: () => {
        try {
          port.postMessage({ type: 'cancelMedia', requestId: request.requestId });
        } catch {
          // The worker may already be gone; the stream cleanup still matters.
        }
      },
    });

    // Send request to worker
    swLog(debug, 'worker:request', {
      requestId: request.requestId,
      npub: request.npub ?? null,
      nhash: request.nhash ?? null,
      treeName: request.treeName ?? null,
      path: request.path,
      start: request.start,
      end: request.end ?? null,
    });
    port.postMessage(request);
  });
}

// npub pattern: npub1 followed by 58 bech32 characters
const NPUB_PATTERN = /^npub1[a-z0-9]{58}$/;

// Timeout for port responses
// Must be long enough for: tree resolution + WebRTC peer attempts + Blossom fallback
// 20s covers the worker-side root wait and keeps stale-port failures bounded.
const PORT_TIMEOUT = 20000;
const STREAM_INACTIVITY_TIMEOUT = 45000;
const PORT_REGISTRATION_WAIT_MS = 8000;
const PORT_REGISTRATION_RETRY_WAIT_MS = 3000;
const PORT_REGISTRATION_INTERVAL_MS = 50;
const HTREE_MEDIA_CACHE = 'htree-media-v1';
const MAX_CACHEABLE_HTREE_MEDIA_BYTES = 20 * 1024 * 1024;

/**
 * Guess MIME type from file path/extension
 */
function guessMimeType(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  const mimeTypes: Record<string, string> = {
    // Video
    'mp4': 'video/mp4',
    'm4v': 'video/mp4',
    'webm': 'video/webm',
    'ogg': 'video/ogg',
    'ogv': 'video/ogg',
    'mov': 'video/quicktime',
    'avi': 'video/x-msvideo',
    'mkv': 'video/x-matroska',
    // Audio
    'mp3': 'audio/mpeg',
    'wav': 'audio/wav',
    'flac': 'audio/flac',
    'm4a': 'audio/mp4',
    'aac': 'audio/aac',
    'oga': 'audio/ogg',
    // Images
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'webp': 'image/webp',
    'svg': 'image/svg+xml',
    'ico': 'image/x-icon',
    // Documents
    'pdf': 'application/pdf',
    'txt': 'text/plain',
    'md': 'text/markdown',
    'html': 'text/html',
    'htm': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
    'json': 'application/json',
    'xml': 'application/xml',
    // Archives
    'zip': 'application/zip',
    'tar': 'application/x-tar',
    'gz': 'application/gzip',
    // Code
    'ts': 'text/typescript',
    'tsx': 'text/typescript',
    'jsx': 'text/javascript',
    'py': 'text/x-python',
    'rs': 'text/x-rust',
    'go': 'text/x-go',
  };
  return mimeTypes[ext] || 'application/octet-stream';
}

interface FileResponseHeaders {
  status: number;
  headers: Record<string, string>;
  body: 'STREAM' | string | null;
  totalSize?: number;
}

/**
 * Serve file - tries worker port first, falls back to client broadcast
 */
async function getWorkerPortForClient(clientId?: string | null): Promise<MessagePort | null> {
  if (clientId && workerPorts.has(clientId)) {
    return workerPorts.get(clientId) || null;
  }
  if (clientId) {
    const client = await self.clients.get(clientId).catch(() => null);
    if (!client) {
      workerPorts.delete(clientId);
    }
  }
  return defaultWorkerPort;
}

function lookupRegisteredWorkerPort(
  clientId?: string | null,
  clientKey?: string | null,
): MessagePort | null {
  return lookupWorkerPort(
    {
      byClientId: workerPorts,
      byClientKey: workerPortsByClientKey,
      defaultPort: defaultWorkerPort,
    },
    clientId,
    clientKey,
  );
}

function dropWorkerPortRegistration(
  port: MessagePort,
  clientId?: string | null,
  clientKey?: string | null,
): void {
  if (clientKey && workerPortsByClientKey.get(clientKey) === port) {
    workerPortsByClientKey.delete(clientKey);
  }
  if (clientId && workerPorts.get(clientId) === port) {
    workerPorts.delete(clientId);
  }
  if (defaultWorkerPort === port) {
    defaultWorkerPort = null;
  }
}

// Ask page-side code to re-register its worker port. Needed after the SW is
// killed for inactivity: in-memory port maps are wiped on restart, so the next
// /htree fetch has no port to talk to. The page listens for this message and
// runs ensureMediaPortReady() again, which posts a fresh REGISTER_WORKER_PORT.
async function requestWorkerPortReconnect(
  clientId?: string | null,
  clientKey?: string | null,
  debug = false,
): Promise<void> {
  try {
    const message = { type: 'REQUEST_WORKER_PORT_RECONNECT', clientKey: clientKey ?? null };
    let posted = 0;
    if (clientId) {
      const client = await self.clients.get(clientId).catch(() => null);
      if (client) {
        client.postMessage(message);
        posted += 1;
      }
    }
    if (posted === 0) {
      const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clients) {
        client.postMessage(message);
        posted += 1;
      }
    }
    swLog(debug, 'request:reconnect-broadcast', {
      clientId: clientId ?? null,
      clientKey: clientKey ?? null,
      posted,
    });
  } catch (error) {
    console.warn('[SW] Failed to broadcast worker port reconnect:', error);
  }
}

function normalizeClientUrl(url: string): string {
  try {
    const parsed = new URL(url);
    parsed.hash = '';
    return parsed.toString();
  } catch {
    return url.split('#')[0] || url;
  }
}

async function resolveClientId(clientId?: string | null, referrer?: string | null): Promise<string | null> {
  if (clientId) return clientId;
  if (!referrer) return null;

  const target = normalizeClientUrl(referrer);
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  const match = clients.find(client => normalizeClientUrl(client.url) === target);
  return match?.id ?? null;
}

async function serveFile(
  request: FileRequest,
  clientId?: string | null,
  clientKey?: string | null,
  referrer?: string | null
): Promise<Response> {
  const resolvedClientId = await resolveClientId(clientId, referrer);
  let port = lookupRegisteredWorkerPort(resolvedClientId, clientKey)
    ?? await getWorkerPortForClient(resolvedClientId);
  const debug = resolveDebug(resolvedClientId ?? clientId ?? null, clientKey);
  swLog(debug, 'request:start', {
    requestId: request.requestId,
    npub: request.npub ?? null,
    nhash: request.nhash ?? null,
    treeName: request.treeName ?? null,
    path: request.path,
    start: request.start,
    end: request.end ?? null,
    clientId: resolvedClientId ?? clientId ?? null,
    clientKey: clientKey ?? null,
  });
  if (!port) {
    swLog(debug, 'request:wait-for-port', {
      requestId: request.requestId,
      clientId: resolvedClientId ?? clientId ?? null,
      clientKey: clientKey ?? null,
    });
    await requestWorkerPortReconnect(resolvedClientId ?? clientId, clientKey, debug);
    port = await waitForWorkerPort(
      () => lookupRegisteredWorkerPort(resolvedClientId, clientKey),
      {
        timeoutMs: PORT_REGISTRATION_WAIT_MS,
        intervalMs: PORT_REGISTRATION_INTERVAL_MS,
      },
    );
  }
  if (port) {
    try {
      return await serveFileViaWorker(request, port, debug);
    } catch (error) {
      dropWorkerPortRegistration(port, resolvedClientId, clientKey);
      console.warn('[SW] Worker path failed, falling back to clients:', error);
      swLog(debug, 'request:worker-failed', {
        requestId: request.requestId,
        error: error instanceof Error ? error.message : String(error),
      });

      await requestWorkerPortReconnect(resolvedClientId ?? clientId, clientKey, debug);
      const retriedPort = await waitForWorkerPort(
        () => lookupRegisteredWorkerPort(resolvedClientId, clientKey),
        {
          timeoutMs: PORT_REGISTRATION_RETRY_WAIT_MS,
          intervalMs: PORT_REGISTRATION_INTERVAL_MS,
        },
      );
      if (retriedPort) {
        swLog(debug, 'request:worker-retry', {
          requestId: request.requestId,
          clientId: resolvedClientId ?? clientId ?? null,
          clientKey: clientKey ?? null,
        });
        return await serveFileViaWorker(request, retriedPort, debug);
      }
    }
  } else {
    swLog(debug, 'request:no-port', { requestId: request.requestId });
  }

  // Fall back to client broadcast (legacy path)
  return serveFileViaClients(request, debug);
}

/**
 * Request file from main thread via per-request MessageChannel
 * Based on WebTorrent's worker-server.js pattern (legacy fallback)
 */
async function serveFileViaClients(request: FileRequest, debug = false): Promise<Response> {
  const clientList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

  if (clientList.length === 0) {
    swLog(debug, 'clients:none', { requestId: request.requestId });
    return new Response('No clients available', { status: 503 });
  }

  // Create MessageChannel and broadcast to all clients - first to respond wins
  const [data, port] = await new Promise<[FileResponseHeaders, MessagePort]>((resolve, reject) => {
    let resolved = false;
    const timeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        swLog(debug, 'clients:timeout', { requestId: request.requestId });
        reject(new Error('Timeout waiting for client response'));
      }
    }, PORT_TIMEOUT);

    for (const client of clientList) {
      const messageChannel = new MessageChannel();
      const { port1, port2 } = messageChannel;

      port1.onmessage = ({ data }) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          resolve([data, port1]);
        }
      };

      client.postMessage(request, [port2]);
    }
  });

  const cleanup = () => {
    port.postMessage(false); // Signal cancel
    port.onmessage = null;
  };

  // Non-streaming response
  if (data.body !== 'STREAM') {
    cleanup();
    // Add cross-origin headers for embedding in iframes (required when main page has COEP)
    const headers = new Headers(data.headers);
    headers.set('Cross-Origin-Resource-Policy', 'cross-origin');
    headers.set('Cross-Origin-Embedder-Policy', 'credentialless');
    headers.set('Access-Control-Allow-Origin', '*');
    return new Response(data.body, {
      status: data.status,
      headers,
    });
  }

  // Streaming response
  let timeoutHandle: ReturnType<typeof setTimeout> | null = null;

  let streamClosed = false;

  const stream = new ReadableStream({
    pull(controller) {
      return new Promise<void>((resolve) => {
        if (streamClosed) {
          resolve();
          return;
        }

        port.onmessage = ({ data: chunk }) => {
          if (timeoutHandle) {
            clearTimeout(timeoutHandle);
            timeoutHandle = null;
          }
          if (chunk) {
            controller.enqueue(new Uint8Array(chunk));
          } else {
            streamClosed = true;
            cleanup();
            controller.close();
          }
          resolve();
        };

        // Clear any previous timeout
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }

        // Timeout for inactive streams (Firefox doesn't support cancel)
        // When timeout fires, close the stream properly so video element knows to stop
        timeoutHandle = setTimeout(() => {
          if (!streamClosed) {
            streamClosed = true;
            cleanup();
            controller.close();
          }
          resolve();
        }, PORT_TIMEOUT);

        // Request next chunk
        port.postMessage(true);
      });
    },
    cancel() {
      streamClosed = true;
      if (timeoutHandle) clearTimeout(timeoutHandle);
      cleanup();
    },
  });

  // Add cross-origin headers for embedding in iframes (required when main page has COEP)
  const headers = new Headers(data.headers);
  // Allow sandboxed iframe origins ("null") to load scripts/styles from /htree.
  headers.set('Cross-Origin-Resource-Policy', 'cross-origin');
  headers.set('Cross-Origin-Embedder-Policy', 'credentialless');
  headers.set('Access-Control-Allow-Origin', '*');
  return new Response(stream, {
    status: data.status,
    headers,
  });
}

/**
 * Create file request for npub-based paths
 */
async function createNpubFileResponse(
  npub: string,
  treeName: string,
  filePath: string,
  rangeHeader: string | null,
  forceDownload: boolean,
  clientId?: string | null,
  clientKey?: string | null,
  referrer?: string | null
): Promise<Response> {
  const id = `file_${++requestId}`;
  const mimeType = guessMimeType(filePath || treeName);
  const request = buildMutableFileRequest({
    requestId: id,
    npub,
    treeName,
    filePath,
    rangeHeader,
    mimeType,
    forceDownload,
  });

  return serveFile(request, clientId, clientKey, referrer).catch((error) => {
    console.error('[SW] File request failed:', error);
    return new Response(`File request failed: ${error.message}`, { status: 500 });
  });
}

/**
 * Create file request for nhash-based paths (content-addressed)
 */
async function createNhashFileResponse(
  nhash: string,
  filename: string,
  rangeHeader: string | null,
  forceDownload: boolean,
  clientId?: string | null,
  clientKey?: string | null,
  referrer?: string | null
): Promise<Response> {
  const id = `file_${++requestId}`;
  const mimeType = guessMimeType(filename);
  const request = buildImmutableFileRequest({
    requestId: id,
    nhash,
    filePath: filename,
    rangeHeader,
    mimeType,
    forceDownload,
  });

  return serveFile(request, clientId, clientKey, referrer).catch((error) => {
    console.error('[SW] File request failed:', error);
    return new Response(`File request failed: ${error.message}`, { status: 500 });
  });
}

/**
 * Add COOP/COEP headers to enable SharedArrayBuffer for FFmpeg WASM
 * Uses 'credentialless' COEP mode to allow cross-origin images without CORP headers
 */
function addCrossOriginHeaders(response: Response): Response {
  // Don't modify opaque responses or redirects
  if (response.type === 'opaque' || response.type === 'opaqueredirect') {
    return response;
  }

  const newHeaders = new Headers(response.headers);
  newHeaders.set('Cross-Origin-Embedder-Policy', 'credentialless');
  newHeaders.set('Cross-Origin-Opener-Policy', 'same-origin');

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: newHeaders,
  });
}

/**
 * Add CORP header for same-origin worker/script resources.
 */
function addCORPHeader(response: Response): Response {
  if (response.type === 'opaque' || response.type === 'opaqueredirect') {
    return response;
  }

  const newHeaders = new Headers(response.headers);
  newHeaders.set('Cross-Origin-Resource-Policy', 'same-origin');
  newHeaders.set('Cross-Origin-Embedder-Policy', 'credentialless');

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: newHeaders,
  });
}

/**
 * Add CORS headers for /htree/ responses
 * Required for sandboxed iframes (opaque origin) to access resources
 */
function addCORSHeaders(response: Response): Response {
  const newHeaders = new Headers(response.headers);
  newHeaders.set('Access-Control-Allow-Origin', '*');
  newHeaders.set('Cross-Origin-Resource-Policy', 'cross-origin');

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: newHeaders,
  });
}

function getNormalizedHtreeMediaCacheRequest(request: Request): Request {
  const url = new URL(request.url);
  url.searchParams.delete('htree_c');
  url.searchParams.delete('htree_img_retry');
  return new Request(url.toString(), { method: 'GET' });
}

function isCacheableHtreeMediaRequest(request: Request): boolean {
  const url = new URL(request.url);
  return request.method === 'GET'
    && url.pathname.startsWith('/htree/')
    && !request.headers.has('Range')
    && url.searchParams.get('download') !== '1';
}

function isCacheableHtreeMediaResponse(response: Response): boolean {
  if (response.status !== 200) {
    return false;
  }

  const contentType = response.headers.get('Content-Type') ?? '';
  if (!contentType.toLowerCase().startsWith('image/')) {
    return false;
  }

  const contentLength = response.headers.get('Content-Length');
  if (!contentLength) {
    return false;
  }

  const byteLength = Number.parseInt(contentLength, 10);
  return Number.isFinite(byteLength) && byteLength <= MAX_CACHEABLE_HTREE_MEDIA_BYTES;
}

async function getCachedHtreeMedia(request: Request): Promise<Response | null> {
  if (!isCacheableHtreeMediaRequest(request)) {
    return null;
  }

  const cache = await caches.open(HTREE_MEDIA_CACHE);
  return await cache.match(getNormalizedHtreeMediaCacheRequest(request)) ?? null;
}

function cacheHtreeMedia(request: Request, response: Response, event?: ExtendableEvent): Response {
  if (!isCacheableHtreeMediaRequest(request) || !isCacheableHtreeMediaResponse(response)) {
    return response;
  }

  const cacheRequest = getNormalizedHtreeMediaCacheRequest(request);
  const cacheResponse = response.clone();
  const cachePromise = caches.open(HTREE_MEDIA_CACHE)
    .then(cache => cache.put(cacheRequest, cacheResponse))
    .catch(error => console.warn('[SW] Failed to cache /htree media response:', error));

  event?.waitUntil(cachePromise);
  if (!event) {
    void cachePromise;
  }

  return response;
}

async function serveHtreeMedia(
  request: Request,
  createResponse: () => Promise<Response>,
  preferCached: boolean,
  event?: ExtendableEvent,
): Promise<Response> {
  if (preferCached) {
    const cached = await getCachedHtreeMedia(request);
    if (cached) {
      return cached;
    }
  }

  return cacheHtreeMedia(request, await createResponse(), event);
}

async function fetchSameOriginWithCache(request: Request): Promise<Response> {
  const cached = await matchPrecache(request.url)
    ?? await caches.match(request)
    ?? (request.mode === 'navigate'
      ? await matchPrecache(new URL('index.html', self.registration.scope).href)
      : undefined);
  if (cached) {
    return cached;
  }
  return fetch(request);
}

/**
 * Intercept fetch requests
 */
self.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url);
  // Use href to preserve encoded characters (pathname auto-decodes %2F).
  const rawPath = getRawHtreePath(url);
  const pathParts = rawPath.slice(1).split('/'); // Remove leading /
  const rangeHeader = event.request.headers.get('Range');
  const clientKey = url.searchParams.get('htree_c');
  const requestDestination = event.request.destination || null;

  // Skip non-GET requests
  if (event.request.method !== 'GET') return;

  // All hashtree routes start with /htree/ - check this FIRST before navigation handling
  // Otherwise navigation requests to /htree/... get redirected to index.html
  if (pathParts[0] === 'htree') {
    if (!shouldInterceptHtreeRequestForWorker(rawPath, clientKey, rangeHeader, requestDestination)) {
      event.respondWith(
        getCachedHtreeMedia(event.request).then(cached => (
          cached ? addCORSHeaders(cached) : fetchSameOriginWithCache(event.request)
        ))
      );
      return;
    } else {
      // /htree/{nhash}/{filename} - Direct nhash access (content-addressed)
      const immutablePath = parseImmutableHtreePath(rawPath);
      if (immutablePath) {
        const { nhash, filePath } = immutablePath;
        const filename = filePath || 'file';
        const forceDownload = url.searchParams.get('download') === '1';
        event.respondWith(
          serveHtreeMedia(event.request, () => (
            createNhashFileResponse(
              nhash,
              filename,
              rangeHeader,
              forceDownload,
              event.clientId,
              clientKey,
              event.request.referrer
            )
          ), !clientKey && !rangeHeader, event).then(addCORSHeaders)
        );
        return;
      }

      // /htree/{npub}/{treeName}/{path...} - Npub-based file access
      // treeName is URL-encoded and may itself contain slashes.
      const mutablePath = parseMutableHtreePath(rawPath);
      if (mutablePath && NPUB_PATTERN.test(mutablePath.npub)) {
        const { npub, treeName, filePath } = mutablePath;
        const forceDownload = url.searchParams.get('download') === '1';
        event.respondWith(
          serveHtreeMedia(event.request, () => (
            createNpubFileResponse(
              npub,
              treeName,
              filePath,
              rangeHeader,
              forceDownload,
              event.clientId,
              clientKey,
              event.request.referrer
            )
          ), !clientKey && !rangeHeader, event).then(addCORSHeaders)
        );
        return;
      }
    }
  }

  // For same-origin requests, only navigations need synthetic COOP/COEP
  // headers. Worker and script assets also need CORP under COEP, but ordinary
  // media and fetch traffic should pass through untouched.
  if (url.origin === self.location.origin) {
    // Vite supplies COEP and CORP on its module responses. Wrapping every
    // development module in another service-worker fetch exhausts Chromium's
    // request slots when a large worker starts alongside the page.
    if (import.meta.env.DEV && /^\/(?:@(?:fs|id|vite)\/|src\/|node_modules\/)/.test(url.pathname)) return;
    const mode = getSameOriginResponseMode(event.request);
    if (mode === 'document-coi') {
      event.respondWith(
        fetch(event.request)
          .catch(() => fetchSameOriginWithCache(event.request))
          .then(addCrossOriginHeaders)
      );
      return;
    }

    if (mode === 'subresource-corp') {
      event.respondWith(fetchSameOriginWithCache(event.request).then(addCORPHeader));
      return;
    }

    event.respondWith(fetchSameOriginWithCache(event.request));
    return;
  }

  // Let workbox handle everything else (static assets, app routes)
});

// Handle service worker installation
self.addEventListener('install', () => {
  console.log('[SW] Installing...');
  self.skipWaiting();
});

// Handle service worker activation
self.addEventListener('activate', (event: ExtendableEvent) => {
  console.log('[SW] Activating...');
  event.waitUntil(self.clients.claim());
});

// Register Workbox after the custom fetch handler so same-origin worker/script
// assets can be rewrapped with the COEP/CORP headers cross-origin isolated
// pages require.
if (!isTestMode) {
  // The handler above serves precached responses with the required headers.
  precache(self.__WB_MANIFEST);
}
