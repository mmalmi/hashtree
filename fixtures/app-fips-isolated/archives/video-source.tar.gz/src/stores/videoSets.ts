/**
 * Video sets (playlists other apps can read) known so far, in memory.
 * Filled by whatever page shows a channel or opens a set; nothing waits on it.
 */
import { writable } from 'svelte/store';
import type { Event } from 'nostr-tools';
import { nostr } from '../nostr/client';
import { VIDEO_EVENT_DELETE_KIND } from '../lib/videoEvent';
import { VIDEO_SET_KIND, parseVideoSet, parseVideoSetDeletion, videoSetKey, type VideoSet } from '../lib/videoSet';

const sets = new Map<string, VideoSet>();
/** `<pubkey>:<d tag>` → time of the owner's deletion request. */
const deletedAt = new Map<string, number>();

/** Known sets, newest first. */
export const videoSetsStore = writable<VideoSet[]>([]);
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleFlush(): void {
  flushTimer ??= setTimeout(() => {
    flushTimer = null;
    videoSetsStore.set([...sets.values()].sort((a, b) => b.updatedAt - a.updatedAt || a.key.localeCompare(b.key)));
  }, 50);
}

/** Apply a set event or its owner's deletion request. Returns true when something changed. */
export function ingestVideoSetEvent(event: Pick<Event, 'kind' | 'pubkey' | 'created_at' | 'tags'>): boolean {
  if (event.kind === VIDEO_EVENT_DELETE_KIND) {
    let changed = false;
    for (const dTag of parseVideoSetDeletion(event)) {
      const id = `${event.pubkey}:${dTag}`;
      if ((deletedAt.get(id) ?? 0) < event.created_at) deletedAt.set(id, event.created_at);
      const known = sets.get(videoSetKey(event.pubkey, dTag));
      if (known && known.updatedAt <= event.created_at) {
        sets.delete(known.key);
        changed = true;
      }
    }
    if (changed) scheduleFlush();
    return changed;
  }
  const set = parseVideoSet(event);
  if (!set) return false;
  if ((deletedAt.get(`${set.ownerPubkey}:${set.dTag}`) ?? 0) >= set.updatedAt) return false;
  const known = sets.get(set.key);
  if (known && known.updatedAt >= set.updatedAt) return false;
  sets.set(set.key, set);
  scheduleFlush();
  return true;
}

export function getVideoSet(key: string): VideoSet | undefined {
  return sets.get(key);
}

/** Keep the given authors' sets coming in as relays deliver them. Returns a function that ends it. */
export function subscribeVideoSets(authors: string[]): () => void {
  if (authors.length === 0) return () => {};
  const subscription = nostr.subscribe([
    { kinds: [VIDEO_SET_KIND], authors, limit: 100 },
    { kinds: [VIDEO_EVENT_DELETE_KIND], authors, '#k': [`${VIDEO_SET_KIND}`], limit: 100 },
  ]);
  subscription.on('event', (event: Event) => { ingestVideoSetEvent(event); });
  return () => subscription.stop();
}

export function clearVideoSets(): void {
  sets.clear();
  deletedAt.clear();
  videoSetsStore.set([]);
}
