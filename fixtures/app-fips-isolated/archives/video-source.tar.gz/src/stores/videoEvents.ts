/**
 * In-memory video index built from Nostr events.
 *
 * NIP-71 video events (kinds 34235/34236 and 21/22) fetched from relays are the
 * only index: title, summary, duration and thumbnail without reading trees.
 * They come from everywhere: hashtree videos published by this app and
 * web-hosted videos published by other apps. A video without such an event is
 * not listed or searchable.
 */
import { writable } from 'svelte/store';
import type { Event, Filter } from 'nostr-tools';
import { nostr } from '../nostr/client';
import {
  ALL_VIDEO_EVENT_KINDS,
  VIDEO_EVENT_DELETE_KIND,
  npubToPubkey,
  parseVideoEvent,
  parseVideoEventDeletion,
  parseVideoEventIdDeletion,
  type VideoEventItem,
  type VideoEventLike,
  withoutRepeatPosts,
} from '../lib/videoEvent';
import type { VideoItem } from '../components/Video/types';

const eventVideos = new Map<string, VideoEventItem>();
/** `<pubkey>:<d tag>` → time of the owner's deletion request. */
const deletedAt = new Map<string, number>();
/** `<pubkey>:<event id>` of regular video events their author deleted. */
const deletedEventIds = new Set<string>();

/** Videos announced by NIP-71 events, newest first. An author's repeat posts of one file are listed once. */
export const videoEventsStore = writable<VideoItem[]>([]);
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function toFeedItem(item: VideoEventItem): VideoItem {
  return {
    key: item.key,
    title: item.title,
    description: item.description,
    duration: item.duration,
    ownerPubkey: item.ownerPubkey,
    ownerNpub: item.ownerNpub,
    treeName: item.treeName,
    videoId: item.videoId,
    thumbnailUrl: item.thumbnailUrl,
    videoPath: item.videoPath,
    videoUrls: item.videoUrls,
    tags: item.tags,
    short: item.short,
    sensitive: item.sensitive,
    visibility: 'public',
    href: item.href,
    timestamp: item.timestamp,
  };
}

function sortedEventVideos(): VideoItem[] {
  return getVideoEventsSnapshot().map(toFeedItem);
}

function flush(): void {
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = null;
  videoEventsStore.set(sortedEventVideos());
}

function scheduleFlush(): void {
  flushTimer ??= setTimeout(flush, 50);
}

/** Apply a video event or an owner's deletion request. Returns true when the index changed. */
export function ingestVideoEvent(event: VideoEventLike): boolean {
  if (event.kind === VIDEO_EVENT_DELETE_KIND) {
    let changed = false;
    for (const dTag of parseVideoEventDeletion(event)) {
      const deletionKey = `${event.pubkey}:${dTag}`;
      if ((deletedAt.get(deletionKey) ?? 0) < event.created_at) deletedAt.set(deletionKey, event.created_at);
      for (const [key, item] of eventVideos) {
        if (item.ownerPubkey === event.pubkey && item.dTag === dTag && item.updatedAt <= event.created_at) {
          eventVideos.delete(key);
          changed = true;
        }
      }
    }
    for (const id of parseVideoEventIdDeletion(event)) {
      deletedEventIds.add(`${event.pubkey}:${id}`);
      for (const [key, item] of eventVideos) {
        if (item.ownerPubkey === event.pubkey && item.eventId === id && !item.dTag) {
          eventVideos.delete(key);
          changed = true;
        }
      }
    }
    if (changed) scheduleFlush();
    return changed;
  }

  const item = parseVideoEvent(event);
  if (!item) return false;
  if (item.dTag && (deletedAt.get(`${item.ownerPubkey}:${item.dTag}`) ?? 0) >= item.updatedAt) return false;
  if (!item.dTag && deletedEventIds.has(`${item.ownerPubkey}:${item.eventId}`)) return false;
  const existing = eventVideos.get(item.key);
  if (existing && existing.updatedAt >= item.updatedAt) return false;
  eventVideos.set(item.key, item);
  scheduleFlush();
  return true;
}

/**
 * Keep the index fed with the given authors' video events as relays deliver them.
 * Nothing waits on the relays: callers render whatever is indexed so far.
 * Returns a function that ends the subscription; loaded videos stay indexed.
 * `limit` asks each relay for only the newest so many of the stored ones.
 */
export function subscribeVideoEvents(authors: string[], limit?: number): () => void {
  if (authors.length === 0) return () => {};

  const subscription = nostr.subscribe([
    { kinds: ALL_VIDEO_EVENT_KINDS, authors, ...(limit ? { limit } : {}) },
    { kinds: [VIDEO_EVENT_DELETE_KIND], authors, '#k': ALL_VIDEO_EVENT_KINDS.map(String) },
  ]);
  subscription.on('event', (event: Event) => { ingestVideoEvent(event); });
  return () => subscription.stop();
}


/** Each event format gets a share of the budget, even on a relay dominated by short clips. */
export function publicVideoFilters(perKind: number): Filter[] {
  return ALL_VIDEO_EVENT_KINDS.map((kind) => ({ kinds: [kind], limit: perKind }));
}

/**
 * Keep the index fed with recent video events from any author, whatever app
 * published them. Streams like `subscribeVideoEvents`; nothing waits on it.
 * Every event from
 * every relay is verified and stored one at a time before anything is delivered,
 * so a large window delays everything else (names, thumbnails, the video being
 * opened) by tens of seconds.
 */
export function subscribeAllVideoEvents(perKind: number): () => void {
  const subscription = nostr.subscribe(publicVideoFilters(perKind));
  subscription.on('event', (event: Event) => { ingestVideoEvent(event); });
  return () => subscription.stop();
}

/** Every indexed video with its event details, newest first. */
export function getVideoEventsSnapshot(): VideoEventItem[] {
  return withoutRepeatPosts([...eventVideos.values()])
    .sort((a, b) => b.timestamp - a.timestamp || a.key.localeCompare(b.key));
}

/** One indexed video for display, by its key. A repeat post left out of the listings still opens from its own link. */
export function getVideoItem(key: string): VideoItem | undefined {
  const item = eventVideos.get(key);
  return item ? toFeedItem(item) : undefined;
}

/** One indexed video by its key (`<npub>/<tree>...` or `event:...`). */
export function getVideoEventItem(key: string): VideoEventItem | undefined {
  return eventVideos.get(key);
}

/**
 * The indexed videos a playlist names, in its order. A reference is an event id
 * or, for an addressable event, `kind:pubkey:d`. Videos not loaded yet are left out.
 */
export function findVideosByRefs(refs: readonly string[]): VideoItem[] {
  const byRef = new Map<string, VideoEventItem>();
  for (const item of eventVideos.values()) {
    if (item.eventId) byRef.set(item.eventId, item);
    if (item.dTag && item.ownerPubkey) byRef.set(`${item.kind}:${item.ownerPubkey}:${item.dTag}`, item);
  }
  const found: VideoItem[] = [];
  const seen = new Set<string>();
  for (const ref of refs) {
    const item = byRef.get(ref);
    if (!item || seen.has(item.key)) continue;
    seen.add(item.key);
    found.push(toFeedItem(item));
  }
  return found;
}

/** Forget a deleted tree (all of its playlist items included). */
export function removeVideosByTree(ownerNpub: string, treeName: string): void {
  const matches = (item: { ownerNpub: string | null; treeName: string }) =>
    item.ownerNpub === ownerNpub && item.treeName === treeName;
  let changed = false;
  for (const [key, item] of eventVideos) {
    if (matches(item)) changed = eventVideos.delete(key) || changed;
  }
  if (changed) flush();
}

/** Event-announced videos by one author, newest first. */
export function getVideoEventsByAuthor(author: string | null | undefined, limit = 100): VideoItem[] {
  const pubkey = author?.startsWith('npub1') ? npubToPubkey(author) : author?.toLowerCase();
  if (!pubkey) return [];
  return sortedEventVideos().filter((video) => video.ownerPubkey === pubkey).slice(0, limit);
}

/** Indexed events for one tree: the video itself, or each playlist item. */
export function getVideoEventItemsForTree(ownerNpub: string, treeName: string): VideoEventItem[] {
  return [...eventVideos.values()].filter((item) => item.ownerNpub === ownerNpub && item.treeName === treeName);
}

export function clearVideoEvents(): void {
  eventVideos.clear();
  deletedAt.clear();
  deletedEventIds.clear();
  flush();
}
