/**
 * Likes and comments on the video event being watched.
 *
 * One relay request per video on screen, opened by the page that shows it and
 * stopped when it leaves. The viewer's own like or comment shows at once; the
 * relays are told in the background and never waited for.
 */
import { writable, type Readable } from 'svelte/store';
import { nostr, nostrStore } from '../nostr';
import { isColdStart, queryConfiguredRelaysDirectly } from '../nostr/directQuery';
import { getVideoEventItem } from './videoEvents';
import {
  EngagementTally,
  REACTION_KIND,
  commentTemplate,
  deletionTemplate,
  engagementFilters,
  reactionTemplate,
  type EngagementTarget,
  type EventComment,
} from '../lib/eventEngagement';

export interface EventEngagementView {
  likes: number;
  liked: boolean;
  comments: EventComment[];
}

export const NO_ENGAGEMENT: EventEngagementView = { likes: 0, liked: false, comments: [] };

export interface EventEngagementWatch extends Readable<EventEngagementView> {
  toggleLike(): Promise<void>;
  /** `parentId` names the comment being answered; without it the comment is on the video. */
  comment(text: string, parentId?: string): Promise<void>;
  stop(): void;
}

const EMIT_DELAY_MS = 50;
const DIRECT_LOOKUP_MS = 8000;

function now(): number {
  return Math.floor(Date.now() / 1000);
}

function publishInBackground(event: Parameters<typeof nostr.publish>[0]): void {
  void Promise.resolve(nostr.publish(event)).catch((error) => {
    console.warn('Failed to publish to relays:', error);
  });
}

export function watchEventEngagement(target: EngagementTarget): EventEngagementWatch {
  const tally = new EngagementTally(target);
  const store = writable<EventEngagementView>(NO_ENGAGEMENT);
  let emitTimer: ReturnType<typeof setTimeout> | null = null;

  const emit = () => {
    emitTimer = null;
    store.set({
      likes: tally.likes,
      liked: tally.likeBy(nostrStore.getState().pubkey) !== null,
      comments: tally.comments,
    });
  };
  // Stored history arrives in a burst: show it in one step.
  const scheduleEmit = () => { emitTimer ??= setTimeout(emit, EMIT_DELAY_MS); };

  const filters = engagementFilters(target);
  const subscription = filters.length > 0 ? nostr.subscribe(filters, { closeAfterHistory: false }) : null;
  subscription?.on('event', (event) => {
    if (tally.add(event)) scheduleEmit();
  });
  // Just after start the worker is seconds behind: ask the relays directly as well.
  const stopDirect = filters.length > 0 && isColdStart()
    ? queryConfiguredRelaysDirectly(filters, (event) => { if (tally.add(event)) scheduleEmit(); }, DIRECT_LOOKUP_MS)
    : null;

  return {
    subscribe: store.subscribe,

    async toggleLike() {
      const viewer = nostrStore.getState().pubkey;
      if (!viewer) return;
      const mine = tally.likeBy(viewer);
      if (mine) {
        tally.remove(mine);
        emit();
        publishInBackground(await nostr.signEvent(deletionTemplate(mine, REACTION_KIND, now())));
        return;
      }
      const event = await nostr.signEvent(reactionTemplate(target, now()));
      tally.add(event);
      emit();
      publishInBackground(event);
    },

    async comment(text: string, parentId?: string) {
      const content = text.trim();
      if (!content || !nostrStore.getState().pubkey) return;
      const parent = parentId ? tally.comments.find((entry) => entry.id === parentId) : undefined;
      const event = await nostr.signEvent(commentTemplate(target, content, now(), parent));
      tally.add(event);
      emit();
      publishInBackground(event);
    },

    stop() {
      if (emitTimer) clearTimeout(emitTimer);
      emitTimer = null;
      subscription?.stop();
      stopDirect?.();
    },
  };
}

/** Likes and comments of an indexed video, by its key; null while its event is not known. */
export function watchVideoEngagement(videoKey: string): EventEngagementWatch | null {
  const item = getVideoEventItem(videoKey);
  if (!item?.ownerPubkey) return null;
  return watchEventEngagement({
    kind: item.kind,
    pubkey: item.ownerPubkey,
    id: item.eventId,
    dTag: item.dTag || undefined,
  });
}
