/**
 * The file servers an author keeps their uploads on (their Blossom server list,
 * kind 10063). A file named by its hash is the same file on each of them, so when
 * the server an event points at is down, the video can be played from another.
 * Looked up when a video's listed copies have failed to load, straight from the
 * relays: asked through the worker on the live site, the list reached the socket
 * but was never handed to the page. Nothing waits for the answer.
 */
import { get, writable } from 'svelte/store';
import type { Event } from 'nostr-tools';
import { queryRelaysDirectly } from '../nostr/directQuery';
import { getEffectiveNostrRelays } from '../lib/runtimeNetwork';
import { settingsStore } from './settings';

const BLOB_SERVER_LIST_KIND = 10063;
const LOOKUP_MS = 8000;

/** Author pubkey → origins of their file servers, in their order of preference. */
export const blobServersStore = writable<Record<string, string[]>>({});
const requested = new Set<string>();
const newestAt = new Map<string, number>();

/** Server origins named by a kind 10063 event. */
export function parseBlobServers(tags: string[][]): string[] {
  const origins: string[] = [];
  for (const tag of tags) {
    if (tag[0] !== 'server' || typeof tag[1] !== 'string') continue;
    try {
      const url = new URL(tag[1]);
      if (url.protocol === 'https:' && !origins.includes(url.origin)) origins.push(url.origin);
    } catch {
      // Not a URL.
    }
  }
  return origins;
}

export function requestBlobServers(pubkey: string | null | undefined): void {
  if (!pubkey || requested.has(pubkey)) return;
  requested.add(pubkey);
  const relays = getEffectiveNostrRelays(get(settingsStore).network.relays);
  queryRelaysDirectly(relays, [{ kinds: [BLOB_SERVER_LIST_KIND], authors: [pubkey], limit: 1 }], (event: Event) => {
    if (event.pubkey !== pubkey || (newestAt.get(pubkey) ?? -1) >= event.created_at) return;
    newestAt.set(pubkey, event.created_at);
    const origins = parseBlobServers(event.tags);
    blobServersStore.update((known) => ({ ...known, [pubkey]: origins }));
  }, LOOKUP_MS);
}
