/**
 * Release store and helpers for git repositories.
 *
 * Releases are stored at: npub/<repoPath>/releases
 * Each release is a directory containing release.json, notes.md, and assets/.
 */
import { writable, type Readable } from 'svelte/store';
import { LinkType, type CID, type TreeEntry, type TreeVisibility } from '@hashtree/core';
import { getTree, decodeAsText } from '../store';
import { invalidateTreeRoot, subscribeToTreeRoot, waitForTreeRoot } from './treeRoot';
import { onCacheUpdate } from '../treeRootCache';
import { saveHashtree } from '../nostr';
import { getErrorMessage } from '../utils/errorMessage';
import { buildReleaseTreeName, isListedReleaseEntryName, sanitizeReleaseId } from './releaseHelpers';

export {
  buildReleaseTreeName,
  getReleaseAssetUrl,
  getReleaseAssetDownloadUrl,
  resolveReleaseAssetMarkdownLink,
  sanitizeReleaseId,
} from './releaseHelpers';

export interface ReleaseSummary {
  id: string;
  entryPath?: string;
  title: string;
  tag?: string;
  created_at: number;
  published_at?: number;
  draft?: boolean;
  draftPointer?: boolean;
  latest?: boolean;
  unpromoted?: boolean;
  prerelease?: boolean;
  commit?: string;
}

export interface ReleaseAsset {
  name: string;
  path: string;
  size: number;
  cid?: CID;
}

export interface ReleaseDetail extends ReleaseSummary {
  notes?: string;
  notesFile?: string;
  assets: ReleaseAsset[];
}

interface ReleaseAssetMeta {
  name: string;
  path: string;
  size: number;
}

interface ReleaseRecord extends ReleaseSummary {
  notes_file?: string;
  assets?: ReleaseAssetMeta[];
}

export interface ReleasesState {
  items: ReleaseSummary[];
  loading: boolean;
  error: string | null;
}

export interface ReleaseDetailState {
  item: ReleaseDetail | null;
  loading: boolean;
  error: string | null;
}

export interface SaveReleaseOptions {
  npub: string;
  repoPath: string;
  treeName?: string;
  title: string;
  tag?: string;
  commit?: string;
  notes?: string;
  draft?: boolean;
  prerelease?: boolean;
  assets?: File[];
  existingAssets?: ReleaseAsset[];
  existingIds?: string[];
  releaseId?: string;
  recordId?: string;
  createdAt?: number;
  publishedAt?: number;
  visibility?: TreeVisibility;
  linkKey?: string;
}

type ReleaseDetailFetchResult =
  | { status: 'found'; item: ReleaseDetail }
  | { status: 'missing-root' }
  | { status: 'not-found' };

interface LoadedReleaseSummary {
  summary: ReleaseSummary;
  cid: unknown;
}

interface ResolvedReleaseEntry {
  entry: Partial<TreeEntry> & { cid: CID };
  path: string;
}

function ensureUniqueReleaseId(base: string, existing: Set<string>): string {
  if (!existing.has(base)) return base;
  const suffix = Date.now().toString(36).slice(-6);
  const candidate = `${base}-${suffix}`;
  if (!existing.has(candidate)) return candidate;
  let i = 2;
  while (existing.has(`${base}-${i}`)) i += 1;
  return `${base}-${i}`;
}

function getReleaseSortTimestamp(release: ReleaseSummary): number {
  return release.published_at ?? release.created_at ?? 0;
}

function cidPartFingerprint(value: unknown): string | null {
  if (value instanceof Uint8Array) return Array.from(value).join(',');
  if (Array.isArray(value)) return value.join(',');
  if (typeof value === 'string') return value;
  return null;
}

function cidFingerprint(value: unknown): string | null {
  if (!value) return null;
  if (typeof value === 'string') return `string:${value}`;
  if (typeof value !== 'object') return null;

  const cid = value as { hash?: unknown; key?: unknown };
  const hash = cidPartFingerprint(cid.hash);
  if (!hash) return null;
  const key = cidPartFingerprint(cid.key);
  return `cid:${hash}:${key ?? ''}`;
}

function annotateReleaseStatuses(
  releases: LoadedReleaseSummary[],
  latestCid: unknown,
  latestSummary?: ReleaseSummary | null,
  draftCid?: unknown,
): ReleaseSummary[] {
  const latestFingerprint = cidFingerprint(latestCid);
  const draftFingerprint = cidFingerprint(draftCid);
  const matchingLatest = latestFingerprint
    ? releases.find(release => cidFingerprint(release.cid) === latestFingerprint)?.summary
    : null;
  const effectiveLatest = matchingLatest ?? latestSummary ?? null;
  const latestTimestamp = effectiveLatest ? getReleaseSortTimestamp(effectiveLatest) : 0;

  return releases.map(({ summary, cid }) => {
    const annotated: ReleaseSummary = { ...summary };
    const isLatest = !!latestFingerprint && cidFingerprint(cid) === latestFingerprint;
    if (isLatest) {
      annotated.latest = true;
      return annotated;
    }

    const isDraftPointer = !!draftFingerprint && cidFingerprint(cid) === draftFingerprint;
    if (isDraftPointer) {
      annotated.draft = true;
      annotated.draftPointer = true;
      return annotated;
    }

    if (
      effectiveLatest
      && !annotated.draft
      && latestTimestamp > 0
      && getReleaseSortTimestamp(annotated) > latestTimestamp
    ) {
      annotated.unpromoted = true;
    }

    return annotated;
  });
}

function parseReleaseTimestamp(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return undefined;
    const asNumber = Number(trimmed);
    if (Number.isFinite(asNumber)) return asNumber;
    const parsedMs = Date.parse(trimmed);
    if (Number.isFinite(parsedMs)) return Math.floor(parsedMs / 1000);
  }
  return undefined;
}

function parseReleaseMeta(meta: TreeEntry['meta'] | undefined, fallbackId: string): ReleaseSummary | null {
  if (!meta || typeof meta !== 'object') return null;
  const metaRecord = (meta as { release?: unknown }).release ?? meta;
  if (!metaRecord || typeof metaRecord !== 'object') return null;

  const record = metaRecord as Record<string, unknown>;
  const title = typeof record.title === 'string' ? record.title : '';
  const tag = typeof record.tag === 'string' ? record.tag : undefined;
  const commit = typeof record.commit === 'string' ? record.commit : undefined;
  const createdAt = parseReleaseTimestamp(record.created_at);
  const publishedAt = parseReleaseTimestamp(record.published_at);
  const draft = typeof record.draft === 'boolean' ? record.draft : undefined;
  const prerelease = typeof record.prerelease === 'boolean' ? record.prerelease : undefined;
  const id = typeof record.id === 'string' ? record.id : fallbackId;

  if (!title && !tag && !createdAt && !publishedAt) return null;

  return {
    id,
    title: title || tag || fallbackId,
    tag,
    commit,
    created_at: createdAt ?? publishedAt ?? 0,
    published_at: publishedAt,
    draft,
    prerelease,
  };
}

function toReleaseSummary(record: ReleaseRecord, fallbackId: string): ReleaseSummary {
  const createdAt = parseReleaseTimestamp(record.created_at);
  const publishedAt = parseReleaseTimestamp(record.published_at);
  return {
    id: record.id || fallbackId,
    title: record.title || record.tag || fallbackId,
    tag: record.tag,
    commit: record.commit,
    created_at: createdAt ?? publishedAt ?? 0,
    published_at: publishedAt,
    draft: record.draft,
    prerelease: record.prerelease,
  };
}

function withEntryPath(summary: ReleaseSummary, entryPath: string): ReleaseSummary {
  const cleanEntryPath = entryPath.trim();
  if (!cleanEntryPath || summary.id === cleanEntryPath) return summary;
  return { ...summary, entryPath: cleanEntryPath };
}

function splitReleaseEntryPath(path: string): string[] {
  return path.split('/').map(part => part.trim()).filter(Boolean);
}

async function resolveReleaseEntry(
  tree: ReturnType<typeof getTree>,
  rootCid: CID,
  entryPath: string,
): Promise<ResolvedReleaseEntry | null> {
  const segments = splitReleaseEntryPath(entryPath);
  if (segments.length === 0) return null;

  let current = rootCid;
  let resolved: ResolvedReleaseEntry | null = null;
  for (let index = 0; index < segments.length; index += 1) {
    const entries = await tree.listDirectory(current);
    const entry = entries.find(candidate => candidate.name === segments[index]);
    if (!entry?.cid) return null;
    resolved = {
      entry: entry as Partial<TreeEntry> & { cid: CID },
      path: segments.slice(0, index + 1).join('/'),
    };
    current = entry.cid;
  }

  return resolved;
}

async function findReleaseEntryByRecordId(
  tree: ReturnType<typeof getTree>,
  rootCid: CID,
  releaseId: string,
): Promise<ResolvedReleaseEntry | null> {
  const entries = await tree.listDirectory(rootCid);
  for (const entry of entries) {
    if (!isListedReleaseEntryName(entry.name)) continue;
    if (!entry.cid) continue;

    const summary = await readReleaseSummaryFromEntry(tree, entry, entry.name);
    if (summary?.id === releaseId || summary?.tag === releaseId) {
      return {
        entry: entry as Partial<TreeEntry> & { cid: CID },
        path: entry.name,
      };
    }
  }

  return null;
}

async function readReleaseRecord(tree: ReturnType<typeof getTree>, releaseCid: CID): Promise<ReleaseRecord | null> {
  const result = await tree.resolvePath(releaseCid, 'release.json');
  if (!result?.cid) return null;
  const data = await tree.readFile(result.cid);
  if (!data) return null;
  try {
    const text = new TextDecoder().decode(data);
    return JSON.parse(text) as ReleaseRecord;
  } catch {
    return null;
  }
}

async function readReleaseSummaryFromEntry(
  tree: ReturnType<typeof getTree>,
  entry: Partial<TreeEntry> & { cid?: CID },
  fallbackId: string,
): Promise<ReleaseSummary | null> {
  const metaSummary = parseReleaseMeta(entry.meta, fallbackId);
  if (metaSummary) return metaSummary;
  if (!entry.cid) return null;

  const record = await readReleaseRecord(tree, entry.cid);
  return record ? toReleaseSummary(record, fallbackId) : null;
}

async function readReleaseNotes(
  tree: ReturnType<typeof getTree>,
  releaseCid: CID,
  notesFile: string
): Promise<string | null> {
  const result = await tree.resolvePath(releaseCid, notesFile);
  if (!result?.cid) return null;
  const data = await tree.readFile(result.cid);
  if (!data) return null;
  return decodeAsText(data) ?? new TextDecoder().decode(data);
}

async function listReleaseAssets(tree: ReturnType<typeof getTree>, releaseCid: CID): Promise<ReleaseAsset[]> {
  const assetsEntry = await tree.resolvePath(releaseCid, 'assets');
  if (!assetsEntry?.cid) return [];

  let entries: TreeEntry[];
  try {
    entries = await tree.listDirectory(assetsEntry.cid);
  } catch {
    // Some imported trees misreport directory links as files even though the target CID is a
    // directory. Treat listing failure as "no assets" instead of hiding otherwise valid releases.
    return [];
  }

  return entries
    .filter(entry => entry.type !== LinkType.Dir)
    .map(entry => {
      const asset: ReleaseAsset = {
        name: entry.name,
        path: `assets/${entry.name}`,
        size: entry.size ?? 0,
      };
      if (entry.cid) asset.cid = entry.cid;
      return asset;
    });
}

async function listReleaseEntries(
  npub: string,
  repoPath: string,
  treeName?: string
): Promise<ReleaseSummary[]> {
  const releaseTreeName = treeName ?? buildReleaseTreeName(repoPath);
  const rootCid = await waitForTreeRoot(npub, releaseTreeName, 8000);
  if (!rootCid) return [];

  const tree = getTree();
  const entries = await tree.listDirectory(rootCid);
  const latestEntry = entries.find(entry => entry.name === 'latest' && entry.cid);
  const draftEntry = entries.find(entry => entry.name === 'draft' && entry.cid);
  const releases: LoadedReleaseSummary[] = [];

  for (const entry of entries) {
    if (!isListedReleaseEntryName(entry.name)) continue;
    if (!entry.cid) continue;

    const summary = await readReleaseSummaryFromEntry(tree, entry, entry.name);
    if (summary) {
      releases.push({ summary: withEntryPath(summary, entry.name), cid: entry.cid });
    }
  }

  if (draftEntry?.cid && !releases.some(release => cidFingerprint(release.cid) === cidFingerprint(draftEntry.cid))) {
    const draftSummary = await readReleaseSummaryFromEntry(tree, draftEntry, 'draft');
    if (draftSummary) {
      releases.push({ summary: withEntryPath(draftSummary, 'draft'), cid: draftEntry.cid });
    }
  }

  return annotateReleaseStatuses(releases, latestEntry?.cid, null, draftEntry?.cid)
    .sort((a, b) => getReleaseSortTimestamp(b) - getReleaseSortTimestamp(a));
}

async function fetchReleaseDetailResult(
  npub: string,
  repoPath: string,
  releaseId: string,
  treeName?: string
): Promise<ReleaseDetailFetchResult> {
  const releaseTreeName = treeName ?? buildReleaseTreeName(repoPath);
  const rootCid = await waitForTreeRoot(npub, releaseTreeName, 8000);
  if (!rootCid) return { status: 'missing-root' };

  const tree = getTree();
  const latestEntry = await resolveReleaseEntry(tree, rootCid, 'latest');
  const draftEntry = await resolveReleaseEntry(tree, rootCid, 'draft');
  let resolvedEntry = await resolveReleaseEntry(tree, rootCid, releaseId);
  if (!resolvedEntry) {
    resolvedEntry = await findReleaseEntryByRecordId(tree, rootCid, releaseId);
  }
  if (!resolvedEntry && draftEntry?.entry.cid) {
    const draftSummary = await readReleaseSummaryFromEntry(tree, draftEntry.entry, 'draft');
    if (releaseId === 'draft' || draftSummary?.id === releaseId || draftSummary?.tag === releaseId) {
      resolvedEntry = draftEntry;
    }
  }
  if (!resolvedEntry?.entry.cid) return { status: 'not-found' };

  const entry = resolvedEntry.entry;
  const record = await readReleaseRecord(tree, entry.cid);
  const entryName = resolvedEntry.path;
  const metaSummary = parseReleaseMeta(entry.meta, entryName);
  if (!record && !metaSummary) return { status: 'not-found' };
  const summary = withEntryPath(record ? toReleaseSummary(record, entryName) : (metaSummary ?? {
    id: entryName,
    title: entryName,
    created_at: 0,
  }), entryName);
  const latestSummary = latestEntry?.entry.cid && cidFingerprint(latestEntry.entry.cid) !== cidFingerprint(entry.cid)
    ? await readReleaseSummaryFromEntry(tree, latestEntry.entry, 'latest')
    : null;
  const [annotatedSummary] = annotateReleaseStatuses(
    [{ summary, cid: entry.cid }],
    latestEntry?.entry.cid,
    latestSummary,
    draftEntry?.entry.cid,
  );

  const notesFile = record?.notes_file || 'notes.md';
  const notes = await readReleaseNotes(tree, entry.cid, notesFile);
  const listedAssets = await listReleaseAssets(tree, entry.cid);
  const listedAssetsByPath = new Map(listedAssets.map(asset => [asset.path, asset]));
  const listedAssetsByName = new Map(listedAssets.map(asset => [asset.name, asset]));
  const assets = record?.assets?.length
    ? (() => {
        const merged: ReleaseAsset[] = record.assets.map(asset => {
          const listed = listedAssetsByPath.get(asset.path) ?? listedAssetsByName.get(asset.name);
          const mergedAsset: ReleaseAsset = {
            name: asset.name,
            path: asset.path,
            size: asset.size,
          };
          if (listed?.cid) mergedAsset.cid = listed.cid;
          return mergedAsset;
        });
        const seenPaths = new Set(merged.map(asset => asset.path));
        for (const listed of listedAssets) {
          if (!seenPaths.has(listed.path)) {
            merged.push(listed);
          }
        }
        return merged;
      })()
    : listedAssets;

  return {
    status: 'found',
    item: {
      ...annotatedSummary,
      notes: notes ?? undefined,
      notesFile: notes ? notesFile : undefined,
      assets,
    },
  };
}

export async function fetchReleaseDetail(
  npub: string,
  repoPath: string,
  releaseId: string,
  treeName?: string
): Promise<ReleaseDetail | null> {
  const result = await fetchReleaseDetailResult(npub, repoPath, releaseId, treeName);
  return result.status === 'found' ? result.item : null;
}

export function createReleasesStore(
  npub: string | null,
  repoPath: string | null,
  treeName?: string | null
): Readable<ReleasesState> & { refresh: () => Promise<void> } {
  const { subscribe, set, update } = writable<ReleasesState>({
    items: [],
    loading: true,
    error: null,
  });

  const releaseTreeName: string | null = treeName ?? (repoPath ? buildReleaseTreeName(repoPath) : null);
  // Sequence guards against stale refresh completions overwriting a fresher
  // result. Without this, the initial refresh and the subscription-triggered
  // refresh can race and the older one's items can land last and clobber a
  // freshly arrived listing — exactly the "Latest shows v0.3.12 after SPA
  // nav, refresh fixes it" pattern.
  let refreshSequence = 0;

  async function refresh(): Promise<void> {
    if (!npub || !repoPath) {
      set({ items: [], loading: false, error: null });
      return;
    }

    const sequence = ++refreshSequence;
    update(state => ({ ...state, loading: true, error: null }));

    try {
      const items = await listReleaseEntries(npub, repoPath, treeName ?? undefined);
      if (sequence !== refreshSequence) return;
      set({ items, loading: false, error: null });
    } catch (err) {
      if (sequence !== refreshSequence) return;
      set({ items: [], loading: false, error: getErrorMessage(err) });
    }
  }

  if (npub && repoPath) {
    void refresh();
  } else {
    set({ items: [], loading: false, error: null });
  }

  if (npub && releaseTreeName) {
    subscribeToTreeRoot(npub, releaseTreeName, () => {
      void refresh();
    });
    onCacheUpdate((owner, treeName) => {
      if (owner === npub && treeName === releaseTreeName) {
        void refresh();
      }
    });
  }

  return { subscribe, refresh };
}

export function createReleaseDetailStore(
  npub: string | null,
  repoPath: string | null,
  releaseId: string | null,
  treeName?: string | null
): Readable<ReleaseDetailState> & { refresh: () => Promise<void> } {
  const { subscribe, set, update } = writable<ReleaseDetailState>({
    item: null,
    loading: true,
    error: null,
  });

  const releaseTreeName: string | null = treeName ?? (repoPath ? buildReleaseTreeName(repoPath) : null);
  let refreshSequence = 0;
  // Once a tree-root subscription event has landed for this store, we trust
  // the resolver's view and a not-found becomes final. Until then, a
  // not-found is treated as transient — the resolver may not have caught up
  // yet and "Release not found" is premature. This is the SPA-nav case where
  // a hard refresh "fixes" things: the hard refresh just buys time for the
  // resolver to deliver a fresher root before we render anything.
  let resolverHasFiredForKey = false;
  // A cached root can be old enough to miss a freshly-published release, while
  // still causing waitForTreeRoot to resolve immediately. On the first miss,
  // force a resolver refresh before showing the terminal not-found state.
  let forcedRefreshAfterMiss = false;

  async function refresh(): Promise<void> {
    if (!npub || !repoPath || !releaseId) {
      set({ item: null, loading: false, error: null });
      return;
    }

    const sequence = ++refreshSequence;
    update(state => ({ ...state, loading: true, error: null }));

    try {
      const result = await fetchReleaseDetailResult(npub, repoPath, releaseId, treeName ?? undefined);
      if (sequence !== refreshSequence) return;

      if (result.status === 'missing-root') {
        update(state => ({
          item: state.item,
          loading: !state.item,
          error: null,
        }));
        return;
      }

      if (result.status === 'not-found') {
        if (!forcedRefreshAfterMiss && npub && releaseTreeName) {
          forcedRefreshAfterMiss = true;
          void invalidateTreeRoot(npub, releaseTreeName);
          update(state => ({
            item: state.item,
            loading: !state.item,
            error: null,
          }));
          return;
        }

        if (!resolverHasFiredForKey) {
          // Stay in loading state — the resolver subscription hasn't reported
          // a root for this tree yet. Re-run on the next subscription event.
          update(state => ({
            item: state.item,
            loading: !state.item,
            error: null,
          }));
          return;
        }
        // listDirectory waits for the release tree's directory block, so this
        // means the directory loaded and the release id genuinely isn't there.
        set({ item: null, loading: false, error: 'Release not found' });
        return;
      }

      forcedRefreshAfterMiss = false;
      set({ item: result.item, loading: false, error: null });
    } catch (err) {
      if (sequence !== refreshSequence) return;
      set({ item: null, loading: false, error: getErrorMessage(err) });
    }
  }

  if (npub && repoPath && releaseId) {
    void refresh();
  } else {
    set({ item: null, loading: false, error: null });
  }

  if (npub && releaseTreeName) {
    subscribeToTreeRoot(npub, releaseTreeName, () => {
      resolverHasFiredForKey = true;
      void refresh();
    });
    onCacheUpdate((owner, treeName) => {
      if (owner === npub && treeName === releaseTreeName) {
        void refresh();
      }
    });
  }

  return { subscribe, refresh };
}

export function isPubliclyVisibleRelease(release: ReleaseSummary): boolean {
  return !release.draft || !!release.draftPointer;
}

export async function saveRelease(options: SaveReleaseOptions): Promise<ReleaseSummary | null> {
  const title = options.title.trim();
  if (!title) return null;
  if (options.visibility === 'link-visible' && !options.linkKey) {
    throw new Error('Missing link key for link-visible release tree');
  }

  const treeName = options.treeName ?? buildReleaseTreeName(options.repoPath);
  const tree = getTree();
  const rootCid = await waitForTreeRoot(options.npub, treeName, 5000);
  const existingIds = new Set(options.existingIds ?? []);
  if (!options.releaseId && rootCid) {
    const entries = await tree.listDirectory(rootCid);
    entries.forEach(entry => existingIds.add(entry.name));
  }

  let releaseId = options.releaseId?.trim() ?? '';
  if (!releaseId) {
    const base = sanitizeReleaseId(options.tag ?? title) || `release-${Date.now()}`;
    releaseId = ensureUniqueReleaseId(base, existingIds);
  }
  const releasePathSegments = splitReleaseEntryPath(releaseId);
  if (releasePathSegments.length === 0) {
    throw new Error('Release id must not be empty');
  }
  const releaseName = releasePathSegments[releasePathSegments.length - 1];
  const releaseParentPath = releasePathSegments.slice(0, -1);
  const recordId = options.recordId?.trim() || releaseId;

  const now = Math.floor(Date.now() / 1000);
  const created_at = options.createdAt ?? now;
  const published_at = options.draft ? undefined : (options.publishedAt ?? now);

  const notes = options.notes?.trim() ?? '';
  const notesFile = notes ? 'notes.md' : undefined;
  let notesEntry: { cid: CID; size: number } | null = null;
  if (notesFile) {
    const notesBytes = new TextEncoder().encode(notes);
    notesEntry = await tree.putFile(notesBytes);
  }

  const assetMap = new Map<string, { cid: CID; size: number }>();
  const existingAssets = options.existingAssets ?? [];
  for (const asset of existingAssets) {
    if (asset.cid) {
      assetMap.set(asset.name, { cid: asset.cid, size: asset.size });
    }
  }

  for (const file of options.assets ?? []) {
    const data = new Uint8Array(await file.arrayBuffer());
    const result = await tree.putFile(data);
    assetMap.set(file.name, { cid: result.cid, size: result.size });
  }

  let assetsDirEntry: { cid: CID } | null = null;
  const assetMeta: ReleaseAssetMeta[] = [];
  if (assetMap.size > 0) {
    const assetEntries = Array.from(assetMap.entries()).map(([name, info]) => {
      assetMeta.push({ name, path: `assets/${name}`, size: info.size });
      return { name, cid: info.cid, size: info.size, type: LinkType.File };
    });
    const assetsDir = await tree.putDirectory(assetEntries);
    assetsDirEntry = { cid: assetsDir.cid };
  }

  const record: ReleaseRecord = {
    id: recordId,
    title,
    tag: options.tag?.trim() || undefined,
    commit: options.commit?.trim() || undefined,
    created_at,
    published_at,
    draft: options.draft ?? false,
    prerelease: options.prerelease ?? false,
    notes_file: notesFile,
    assets: assetMeta.length > 0 ? assetMeta : undefined,
  };

  const recordBytes = new TextEncoder().encode(JSON.stringify(record, null, 2));
  const recordEntry = await tree.putFile(recordBytes);

  const releaseEntries = [
    { name: 'release.json', cid: recordEntry.cid, size: recordEntry.size, type: LinkType.File },
  ];
  if (notesEntry) {
    releaseEntries.push({ name: notesFile!, cid: notesEntry.cid, size: notesEntry.size, type: LinkType.File });
  }
  if (assetsDirEntry) {
    releaseEntries.push({ name: 'assets', cid: assetsDirEntry.cid, size: 0, type: LinkType.Dir });
  }

  const releaseDir = await tree.putDirectory(releaseEntries);
  const meta = {
    release: toReleaseSummary(record, releaseId),
  };

  let newRootCid: CID;
  if (rootCid) {
    newRootCid = await tree.setEntry(rootCid, releaseParentPath, releaseName, releaseDir.cid, 0, LinkType.Dir, meta);
  } else {
    if (releaseParentPath.length > 0) {
      throw new Error('Cannot create a nested release path without an existing release tree');
    }
    const root = await tree.putDirectory([
      { name: releaseName, cid: releaseDir.cid, size: 0, type: LinkType.Dir, meta },
    ]);
    newRootCid = root.cid;
  }

  const visibility = options.visibility ?? 'public';
  const result = await saveHashtree(treeName, newRootCid, { visibility, linkKey: options.linkKey });
  if (!result.success) {
    throw new Error('Failed to publish release tree');
  }

  return withEntryPath(toReleaseSummary(record, releaseId), releaseId);
}

export async function deleteRelease(
  npub: string,
  repoPath: string,
  releaseId: string,
  visibility: TreeVisibility = 'public',
  linkKey?: string,
  treeName?: string
): Promise<boolean> {
  if (visibility === 'link-visible' && !linkKey) return false;
  const resolvedTreeName = treeName ?? buildReleaseTreeName(repoPath);
  const rootCid = await waitForTreeRoot(npub, resolvedTreeName, 5000);
  if (!rootCid) return false;

  const tree = getTree();
  const releasePathSegments = splitReleaseEntryPath(releaseId);
  if (releasePathSegments.length === 0) return false;
  const releaseName = releasePathSegments[releasePathSegments.length - 1];
  const releaseParentPath = releasePathSegments.slice(0, -1);
  const newRootCid = await tree.removeEntry(rootCid, releaseParentPath, releaseName);
  const result = await saveHashtree(resolvedTreeName, newRootCid, { visibility, linkKey });
  return result.success;
}
