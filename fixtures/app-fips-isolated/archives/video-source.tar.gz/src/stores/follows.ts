/**
 * follows hook - manages follow lists and follow/unfollow actions
 * Svelte version using writable stores
 */
import { writable } from 'svelte/store';
import { rememberContact } from './contactMemory';
import { getProfileName, getProfileSync } from './profile';
import { nip19, verifyEvent } from 'nostr-tools';
import type { Event as NostrEvent } from 'nostr-tools';
import { LRUCache } from '../utils/lruCache';
import { KeyedEventEmitter } from '../utils/keyedEventEmitter';
import { nostr, nostrStore } from '../nostr';

export interface Follows {
  pubkey: string;
  follows: string[];
  followedAt: number;
}

// Cache follows lists
const followsCache = new LRUCache<string, Follows>(100);

// Event emitter for follows updates
const followsEmitter = new KeyedEventEmitter<string, Follows>();

// Track active subscriptions - kept open for live updates
const activeSubscriptions = new Map<string, { stop: () => void }>();

// Newest follow list seen per subscribed author, from any relay or published here.
const heads = new Map<string, NostrEvent>();
// Authors whose stored history has been delivered in full.
const historyDone = new Set<string>();
// The signed-in user's follow/unfollow changes that are not in a published list yet.
const pendingChanges = new Map<string, Map<string, boolean>>();

function newerHead(current: NostrEvent | undefined, event: NostrEvent): NostrEvent {
  return !current || event.created_at > current.created_at ||
    (event.created_at === current.created_at && event.id < current.id) ? event : current;
}

/** The list to show: the newest one seen, with unpublished local changes on top. */
function emitList(pubkey: string): void {
  const head = heads.get(pubkey);
  let follows = head?.tags.filter(t => t[0] === 'p' && t[1]).map(t => t[1]) ?? [];
  for (const [target, following] of pendingChanges.get(pubkey) ?? []) {
    if (!following) follows = follows.filter(pk => pk !== target);
    else if (!follows.includes(target)) follows.push(target);
  }
  const list: Follows = { pubkey, follows, followedAt: head?.created_at ?? 0 };
  followsCache.set(pubkey, list);
  followsEmitter.notify(pubkey, list);
}

/**
 * Subscribe to follows (kept open for live updates).
 * The active backend owns subscriptions and cached event delivery.
 */
function fetchFollows(pubkey: string): void {
  if (!pubkey || pubkey.length !== 64) {
    console.warn('[follows] Invalid pubkey:', pubkey);
    return;
  }

  // Already subscribed
  if (activeSubscriptions.has(pubkey)) return;

  const sub = nostr.subscribe(
    { kinds: [3], authors: [pubkey] },
    { closeAfterHistory: false } // Keep open for live updates
  );

  sub.on('event', (event: NostrEvent) => {
    if (event.pubkey !== pubkey || event.kind !== 3) return;
    const current = heads.get(pubkey);
    if (newerHead(current, event) === current) return;
    heads.set(pubkey, event);
    emitList(pubkey);
    if (pendingChanges.has(pubkey)) schedulePublish(pubkey);
  });

  sub.on('history', status => {
    if (status.complete) historyDone.add(pubkey);
    if (!pendingChanges.get(pubkey)?.size) return;
    if (!status.complete && !heads.has(pubkey)) {
      followNotice.set({ pubkey, message: 'Your follow list has not been found yet. The change is kept here and sent once it is.' });
    }
    schedulePublish(pubkey);
  });

  activeSubscriptions.set(pubkey, { stop: () => sub.stop() });
}

/**
 * Create a Svelte store for a user's follows list
 */
export function createFollowsStore(pubkey?: string) {
  const pubkeyHex = pubkey?.startsWith('npub1')
    ? (() => {
        try {
          const decoded = nip19.decode(pubkey);
          return decoded.data as string;
        } catch {
          return '';
        }
      })()
    : pubkey || '';

  const { subscribe: storeSubscribe, set } = writable<Follows | undefined>(
    pubkeyHex ? followsCache.get(pubkeyHex) : undefined
  );

  if (pubkeyHex) {
    // Subscribe to updates
    const unsub = followsEmitter.subscribe(pubkeyHex, set);

    // Fetch if not cached
    const cached = followsCache.get(pubkeyHex);
    if (cached) {
      set(cached);
    } else {
      fetchFollows(pubkeyHex);
    }

    // Return store with cleanup
    return {
      subscribe: storeSubscribe,
      destroy: unsub,
    };
  }

  return {
    subscribe: storeSubscribe,
    destroy: () => {},
  };
}

/**
 * Get follows synchronously (from cache)
 */
export function getFollowsSync(pubkey?: string): Follows | undefined {
  if (!pubkey) return undefined;
  const pubkeyHex = pubkey.startsWith('npub1')
    ? (() => {
        try {
          const decoded = nip19.decode(pubkey);
          return decoded.data as string;
        } catch {
          return '';
        }
      })()
    : pubkey;
  return followsCache.get(pubkeyHex);
}

/** What went wrong with the latest follow change, for the account it belongs to. */
export const followNotice = writable<{ pubkey: string; message: string } | null>(null);

/**
 * Follow/unfollow shows at once and is published in the background. Resolves
 * true when the change was taken, without waiting for any relay.
 */
export function followPubkey(targetPubkey: string): Promise<boolean> {
  return Promise.resolve(updateFollow(targetPubkey, true));
}

export function unfollowPubkey(targetPubkey: string): Promise<boolean> {
  return Promise.resolve(updateFollow(targetPubkey, false));
}

let followUpdates: Promise<unknown> = Promise.resolve();

function updateFollow(targetPubkey: string, following: boolean): boolean {
  const pk = nostrStore.getState().pubkey;
  if (!pk || !nostr.signer || !/^[a-f0-9]{64}$/.test(targetPubkey)) return false;
  followNotice.set(null);
  const pending = pendingChanges.get(pk) ?? new Map<string, boolean>();
  pending.set(targetPubkey, following);
  pendingChanges.set(pk, pending);
  emitList(pk);
  if (following) {
    rememberContact(pk, targetPubkey, getProfileName(getProfileSync(targetPubkey), targetPubkey) ?? null);
  }
  fetchFollows(pk);
  schedulePublish(pk);
  return true;
}

function schedulePublish(pk: string): void {
  followUpdates = followUpdates.then(() => publishPending(pk)).catch(error => {
    console.error('[follows] Could not update the public follow list:', error);
    followNotice.set({ pubkey: pk, message: 'Could not update your follow list.' });
  });
}

function dropChanges(pk: string, batch: Array<[string, boolean]>): void {
  const pending = pendingChanges.get(pk);
  if (!pending) return;
  for (const [target, following] of batch) {
    if (pending.get(target) === following) pending.delete(target);
  }
  if (pending.size === 0) pendingChanges.delete(pk);
  emitList(pk);
}

/** Sign one list holding every pending change, built on the newest list seen so far. */
async function publishPending(pk: string): Promise<void> {
  const pending = pendingChanges.get(pk);
  if (!pending?.size) return;
  const signer = nostr.signer;
  if (nostrStore.getState().pubkey !== pk || !signer) {
    pendingChanges.delete(pk);
    emitList(pk);
    return;
  }
  let head = heads.get(pk);
  if (head && !verifyEvent(head)) {
    // Never build on a list we cannot trust; wait for a valid one.
    heads.delete(pk);
    historyDone.delete(pk);
    head = undefined;
    followNotice.set({ pubkey: pk, message: 'Your follow list could not be verified. The change is kept here.' });
  }
  // A list built from nothing would erase the user's follows: without any list
  // seen, wait until history has finished. The subscription calls back here.
  if (!head && !historyDone.has(pk)) return;

  const batch = [...pending];
  let tags = head?.tags.map(tag => [...tag]) ?? [];
  let changed = false;
  for (const [target, following] of batch) {
    const present = tags.some(tag => tag[0] === 'p' && tag[1] === target);
    if (present === following) continue;
    changed = true;
    if (following) tags.push(['p', target]);
    else tags = tags.filter(tag => !(tag[0] === 'p' && tag[1] === target));
  }
  if (!changed) {
    dropChanges(pk, batch);
    return;
  }

  let event: NostrEvent;
  try {
    event = await nostr.signEvent({
      kind: 3,
      tags,
      content: head?.content ?? '',
      created_at: Math.max(Math.floor(Date.now() / 1000), (head?.created_at ?? 0) + 1),
    });
    if (event.pubkey !== pk || !verifyEvent(event)) throw new Error('Signed follow list is invalid.');
  } catch (error) {
    // Nothing was signed, so nothing can be sent: show the list as it really is.
    console.error('[follows] Could not sign the follow list:', error);
    dropChanges(pk, batch);
    followNotice.set({ pubkey: pk, message: 'Could not sign your follow list. Nothing was changed.' });
    return;
  }
  if (nostrStore.getState().pubkey !== pk || nostr.signer !== signer) return;
  const current = heads.get(pk);
  if (current !== head && current && newerHead(current, event) === current) {
    // A newer list arrived while signing; build on that one instead.
    return publishPending(pk);
  }
  heads.set(pk, event);
  dropChanges(pk, batch);
  // The list is already in effect here. Sending is the backend's job and may
  // outlast a relay being down; a failure is reported, not undone.
  void Promise.resolve(nostr.publish(event)).catch(error => {
    console.error('[follows] Could not send the follow list:', error);
    followNotice.set({ pubkey: pk, message: 'Your follow list is saved here but has not been sent yet.' });
  });
}

/**
 * Invalidate cache for a pubkey (force refetch)
 */
export function invalidateFollows(pubkey: string): void {
  followsCache.delete(pubkey);
  fetchFollows(pubkey);
  if (heads.has(pubkey) || pendingChanges.has(pubkey)) emitList(pubkey);
}
