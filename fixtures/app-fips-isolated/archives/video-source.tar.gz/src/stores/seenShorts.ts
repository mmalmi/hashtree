/**
 * Shorts this browser has already played, so the viewer and the Shorts row lead
 * with ones that are new to the viewer. Kept in this browser only.
 */
const STORAGE_KEY = 'video-seen-shorts';
const MAX_SEEN = 500;

let seen: string[] | null = null;

function load(): string[] {
  if (seen) return seen;
  try {
    const stored: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]');
    seen = Array.isArray(stored) ? stored.filter((key): key is string => typeof key === 'string') : [];
  } catch {
    seen = [];
  }
  return seen;
}

/** The shorts seen up to now. A copy: a page keeps the order it opened with while more are watched. */
export function seenShortsSnapshot(): ReadonlySet<string> {
  return new Set(load());
}

export function markShortSeen(key: string): void {
  const list = load();
  if (list.includes(key)) return;
  list.push(key);
  if (list.length > MAX_SEEN) list.splice(0, list.length - MAX_SEEN);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    // Remembered for this visit only.
  }
}
