import { get, writable } from 'svelte/store';
import { MemoryStore } from '@hashtree/core';
import type { CollectionManifest, CollectionSource, Store } from '@hashtree/collection';
import { getWorkerStore } from './workerStore';
import {
  getVideoAuthorCatalogUrls,
  getVideoCatalogUrlSet,
  loadVideoCatalog,
  removeSavedVideoCatalogUrl,
  saveVideoCatalogUrl,
  searchVideoCatalogItems,
  videoCatalogItemToFeedItem,
  type VideoCatalog,
  type VideoCatalogItem,
} from '../lib/videoCatalog';
import {
  buildVideoCollection,
  createVideoCollectionSource,
  createVideoCollectionSourceId,
  mergeVideoCollectionRecords,
  queryVideoCollectionRecordsByAuthor,
  searchVideoCollectionRecords,
  videoCatalogItemToCollectionRecord,
  videoRecordFromNostrTreeEvent,
  videoRecordToCatalogItem,
  type VideoCatalogTrustScope,
  type VideoCollectionRecord,
  type VideoNostrEventLike,
} from '../lib/videoCatalogCollection';

export interface VideoCatalogsState {
  urls: string[];
  defaultUrls: string[];
  savedUrls: string[];
  catalogs: VideoCatalog[];
  records: VideoCollectionRecord[];
  videos: ReturnType<typeof videoCatalogItemToFeedItem>[];
  collectionManifest: CollectionManifest | null;
  loading: boolean;
  error: string | null;
}

const initialState: VideoCatalogsState = {
  urls: [],
  defaultUrls: [],
  savedUrls: [],
  catalogs: [],
  records: [],
  videos: [],
  collectionManifest: null,
  loading: false,
  error: null,
};

export const videoCatalogsStore = writable<VideoCatalogsState>(initialState);

const collectionStore = new MemoryStore();
interface ActiveVideoCollectionSource {
  catalogUrl: string;
  source: CollectionSource;
  store: Store;
}

let activeCollectionSources: ActiveVideoCollectionSource[] = [];
const ingestedRecordsById = new Map<string, VideoCollectionRecord>();
let rebuildSequence = 0;
let rebuildTimer: ReturnType<typeof setTimeout> | null = null;

function recordCatalogUrl(record: VideoCollectionRecord, fallback = 'iris-video:index'): string {
  return record.provenance.find((entry) => entry.catalogUrl)?.catalogUrl ?? fallback;
}

function recordsToFeedVideos(records: VideoCollectionRecord[]) {
  const seen = new Set<string>();
  const videos: ReturnType<typeof videoCatalogItemToFeedItem>[] = [];
  for (const record of records) {
    const item = videoRecordToCatalogItem(record, recordCatalogUrl(record));
    const key = item.ownerNpub && item.treeName
      ? `${item.ownerNpub}/${item.treeName}/${item.videoId ?? ''}`
      : `${item.catalogUrl}/${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    videos.push(videoCatalogItemToFeedItem(item));
  }
  return videos;
}

function catalogRecords(catalogs: VideoCatalog[]): VideoCollectionRecord[] {
  return catalogs.flatMap((catalog) => catalog.videos.map((item) => videoCatalogItemToCollectionRecord(item, {
    source: catalog.version === 2 ? 'catalog-v2' : 'catalog-v1',
  })));
}

function publishedCollectionSources(catalogs: VideoCatalog[]): ActiveVideoCollectionSource[] {
  const workerStore = getWorkerStore();
  return catalogs
    .filter((catalog): catalog is VideoCatalog & { collectionManifest: CollectionManifest } => !!catalog.collectionManifest)
    .map((catalog) => ({
      catalogUrl: catalog.sourceUrl,
      source: createVideoCollectionSource(workerStore, catalog.collectionManifest),
      store: workerStore,
    }));
}

async function rebuildCollectionForCatalogs(
  catalogs: VideoCatalog[],
  baseState: Omit<VideoCatalogsState, 'records' | 'videos' | 'collectionManifest'>,
): Promise<VideoCatalogsState> {
  const sequence = ++rebuildSequence;
  const records = [
    ...catalogRecords(catalogs),
    ...ingestedRecordsById.values(),
  ];
  const built = await buildVideoCollection(collectionStore, records, {
    sourceId: createVideoCollectionSourceId('local', 'iris-video'),
    metadata: {
      catalogUrls: baseState.urls,
      catalogCount: catalogs.length,
      ingestedRecordCount: ingestedRecordsById.size,
    },
  });

  if (sequence !== rebuildSequence) {
    return get(videoCatalogsStore);
  }

  activeCollectionSources = [
    {
      catalogUrl: 'iris-video:index',
      source: built.source,
      store: collectionStore,
    },
    ...publishedCollectionSources(catalogs),
  ];
  const nextState: VideoCatalogsState = {
    ...baseState,
    catalogs,
    records: built.records,
    videos: recordsToFeedVideos(built.records),
    collectionManifest: built.manifest,
  };
  videoCatalogsStore.set(nextState);
  return nextState;
}

async function rebuildCollectionFromCurrentState(): Promise<VideoCatalogsState> {
  const state = get(videoCatalogsStore);
  return rebuildCollectionForCatalogs(state.catalogs, {
    urls: state.urls,
    defaultUrls: state.defaultUrls,
    savedUrls: state.savedUrls,
    catalogs: state.catalogs,
    loading: state.loading,
    error: state.error,
  });
}

function scheduleCollectionRebuild(): void {
  if (rebuildTimer) clearTimeout(rebuildTimer);
  rebuildTimer = setTimeout(() => {
    rebuildTimer = null;
    void rebuildCollectionFromCurrentState();
  }, 100);
}

export async function refreshSavedVideoCatalogs(fetcher: typeof fetch = fetch): Promise<VideoCatalogsState> {
  const { defaultUrls, savedUrls, urls } = getVideoCatalogUrlSet();
  videoCatalogsStore.update((state) => ({ ...state, urls, defaultUrls, savedUrls, loading: true, error: null }));

  if (urls.length === 0) {
    return rebuildCollectionForCatalogs([], { ...initialState, urls, defaultUrls, savedUrls, loading: false });
  }

  const settled = await Promise.allSettled(urls.map((url) => loadVideoCatalog(url, fetcher)));
  const catalogs = settled
    .filter((result): result is PromiseFulfilledResult<VideoCatalog> => result.status === 'fulfilled')
    .map((result) => result.value);
  const failedCount = settled.length - catalogs.length;
  return rebuildCollectionForCatalogs(catalogs, {
    urls,
    defaultUrls,
    savedUrls,
    catalogs,
    loading: false,
    error: failedCount > 0 ? `${failedCount} video catalog${failedCount === 1 ? '' : 's'} failed to load` : null,
  });
}

export async function addVideoCatalogUrl(url: string, fetcher: typeof fetch = fetch): Promise<VideoCatalogsState> {
  saveVideoCatalogUrl(url);
  return refreshSavedVideoCatalogs(fetcher);
}

export async function removeVideoCatalogUrl(url: string, fetcher: typeof fetch = fetch): Promise<VideoCatalogsState> {
  removeSavedVideoCatalogUrl(url);
  return refreshSavedVideoCatalogs(fetcher);
}

export function getLoadedVideoCatalogItems(): VideoCatalogItem[] {
  return get(videoCatalogsStore).records.map((record) => videoRecordToCatalogItem(record, recordCatalogUrl(record)));
}

function recordsToCatalogItems(
  records: VideoCollectionRecord[],
  fallbackCatalogUrl = 'iris-video:index',
): VideoCatalogItem[] {
  return records.map((record) => videoRecordToCatalogItem(record, recordCatalogUrl(record, fallbackCatalogUrl)));
}

async function queryActiveCollectionSources(
  querySource: (entry: ActiveVideoCollectionSource) => Promise<VideoCollectionRecord[]>,
  limit: number,
): Promise<VideoCatalogItem[]> {
  const settled = await Promise.allSettled(activeCollectionSources.map(querySource));
  const recordsWithSource = settled.flatMap((result, index) => {
    if (result.status !== 'fulfilled') return [];
    const source = activeCollectionSources[index];
    return result.value.map((record) => ({ record, catalogUrl: source.catalogUrl }));
  });
  const mergedRecords = mergeVideoCollectionRecords(recordsWithSource.map(({ record }) => record));
  return mergedRecords
    .slice(0, limit)
    .map((record) => {
      const source = recordsWithSource.find((entry) => entry.record.id === record.id);
      return videoRecordToCatalogItem(record, recordCatalogUrl(record, source?.catalogUrl));
    });
}

export async function searchLoadedVideoCatalogItems(query: string, limit = 20): Promise<VideoCatalogItem[]> {
  if (!query.trim()) {
    return getLoadedVideoCatalogItems().slice(0, limit);
  }
  if (activeCollectionSources.length > 0) {
    return queryActiveCollectionSources(
      (entry) => searchVideoCollectionRecords(entry.store, entry.source, query, limit),
      limit,
    );
  }
  return searchVideoCatalogItems(getLoadedVideoCatalogItems(), query, limit);
}

export async function getLoadedVideoCatalogItemsByAuthor(options: {
  ownerPubkey?: string | null;
  ownerNpub?: string | null;
  limit?: number;
}): Promise<VideoCatalogItem[]> {
  const authors = [options.ownerPubkey, options.ownerNpub].filter((value): value is string => !!value);
  const limit = options.limit ?? 50;
  if (authors.length === 0) return [];

  if (activeCollectionSources.length > 0) {
    const results = await Promise.all(authors.map((author) => queryActiveCollectionSources(
      (entry) => queryVideoCollectionRecordsByAuthor(entry.store, entry.source, author, limit),
      limit,
    )));
    const records = mergeVideoCollectionRecords(results.flat().map((item) => videoCatalogItemToCollectionRecord(item)));
    return recordsToCatalogItems(records, 'iris-video:index').slice(0, limit);
  }

  const records = get(videoCatalogsStore).records.filter((record) => (
    (options.ownerPubkey && record.ownerPubkey === options.ownerPubkey)
    || (options.ownerNpub && record.ownerNpub === options.ownerNpub)
  ));
  return recordsToCatalogItems(mergeVideoCollectionRecords(records), 'iris-video:index').slice(0, limit);
}

export async function loadVideoAuthorCatalogItems(options: {
  ownerNpub?: string | null;
  ownerPubkey?: string | null;
  fetcher?: typeof fetch;
  limit?: number;
}): Promise<VideoCatalogItem[]> {
  const ownerNpub = options.ownerNpub ?? undefined;
  const urls = getVideoAuthorCatalogUrls(ownerNpub);
  if (urls.length === 0) return [];

  const limit = options.limit ?? 50;
  const fetcher = options.fetcher ?? fetch;
  const catalogs = (await Promise.allSettled(urls.map((url) => loadVideoCatalog(url, fetcher))))
    .filter((result): result is PromiseFulfilledResult<VideoCatalog> => result.status === 'fulfilled')
    .map((result) => result.value);
  const inlineItems = catalogs
    .flatMap((catalog) => catalog.videos)
    .filter((item) => (
      (ownerNpub && item.ownerNpub === ownerNpub)
      || (options.ownerPubkey && item.ownerPubkey === options.ownerPubkey)
    ));

  const manifestItems = (await Promise.all(catalogs
    .filter((catalog): catalog is VideoCatalog & { collectionManifest: CollectionManifest } => !!catalog.collectionManifest)
    .map(async (catalog) => {
      const workerStore = getWorkerStore();
      const source = createVideoCollectionSource(workerStore, catalog.collectionManifest);
      const records = await queryVideoCollectionRecordsByAuthor(
        workerStore,
        source,
        options.ownerPubkey ?? ownerNpub ?? '',
        limit,
      );
      return recordsToCatalogItems(records, catalog.sourceUrl);
    }))).flat();

  const records = mergeVideoCollectionRecords([...inlineItems, ...manifestItems].map((item) => videoCatalogItemToCollectionRecord(item)));
  return recordsToCatalogItems(records, urls[0]).slice(0, limit);
}

export async function ingestVideoCatalogRecord(record: VideoCollectionRecord): Promise<VideoCatalogsState> {
  const normalized = record;
  ingestedRecordsById.set(normalized.id, normalized);
  return rebuildCollectionFromCurrentState();
}

export function scheduleVideoCatalogRecordIngest(record: VideoCollectionRecord): void {
  ingestedRecordsById.set(record.id, record);
  scheduleCollectionRebuild();
}

export async function removeVideoCatalogRecords(match: {
  ownerNpub?: string | null;
  ownerPubkey?: string | null;
  treeName: string;
}): Promise<VideoCatalogsState | null> {
  let removed = false;
  for (const [id, record] of ingestedRecordsById) {
    if (record.treeName !== match.treeName) continue;
    if (match.ownerNpub && record.ownerNpub === match.ownerNpub) {
      ingestedRecordsById.delete(id);
      removed = true;
      continue;
    }
    if (match.ownerPubkey && record.ownerPubkey === match.ownerPubkey) {
      ingestedRecordsById.delete(id);
      removed = true;
    }
  }
  if (removed) {
    return rebuildCollectionFromCurrentState();
  }
  return null;
}

export function scheduleVideoCatalogRecordRemoval(match: {
  ownerNpub?: string | null;
  ownerPubkey?: string | null;
  treeName: string;
}): void {
  void removeVideoCatalogRecords(match);
}

export async function ingestVideoNostrEvent(
  event: VideoNostrEventLike,
  scope: VideoCatalogTrustScope,
): Promise<VideoCatalogsState | null> {
  const record = videoRecordFromNostrTreeEvent(event, scope);
  if (!record) return null;
  return ingestVideoCatalogRecord(record);
}

export function scheduleVideoNostrEventIngest(event: VideoNostrEventLike, scope: VideoCatalogTrustScope): void {
  const record = videoRecordFromNostrTreeEvent(event, scope);
  if (!record) return;
  scheduleVideoCatalogRecordIngest(record);
}
