/**
 * Home page state that survives component unmount for instant back-nav
 */
import type { CID } from '@hashtree/core';
import { writable } from 'svelte/store';

export interface PlaylistInfo {
  videoCount: number;
  thumbnailUrl?: string;
  videoPath?: string;
  rootCid?: CID | null;
  duration?: number;
  createdAt?: number;
  title?: string;
}

export interface RecentVideoCardInfo extends PlaylistInfo {
  rootCid?: CID | null;
}

// Resolved media for recent cards keyed by recent path.
const recentVideoCardInfoCache: Record<string, RecentVideoCardInfo> = {};
export const recentVideoCardInfoVersion = writable(0);

/** What the home feed showed, so coming back to it shows the same thing. */
export interface HomeFeedView {
  sort: 'hot' | 'new' | 'top';
  scope: 'all' | 'following';
  page: number;
  videos: string[];
  shorts: string[];
}

let homeFeedView: { viewer: string | null; view: HomeFeedView } | null = null;

export function getHomeFeedView(viewer: string | null): HomeFeedView | null {
  return homeFeedView?.viewer === viewer && homeFeedView.view.videos.length + homeFeedView.view.shorts.length > 0
    ? homeFeedView.view
    : null;
}

export function setHomeFeedView(viewer: string | null, view: HomeFeedView): void {
  homeFeedView = { viewer, view };
}

export function getRecentVideoCardInfo(key: string): RecentVideoCardInfo | undefined {
  return recentVideoCardInfoCache[key];
}

export function setRecentVideoCardInfo(key: string, info: RecentVideoCardInfo): void {
  const existing = recentVideoCardInfoCache[key];
  recentVideoCardInfoCache[key] = {
    ...(existing ?? {}),
    ...info,
    rootCid: info.rootCid ?? existing?.rootCid ?? null,
  };
  recentVideoCardInfoVersion.update((version) => version + 1);
}

export function clearRecentVideoCardInfo(key: string): void {
  delete recentVideoCardInfoCache[key];
  recentVideoCardInfoVersion.update((version) => version + 1);
}
