/**
 * The video feed: videos from everywhere, ranked for the viewer.
 *
 * One place owns what the home page and the "up next" sidebar list:
 * - recent NIP-71 video events from any author and any app, plus the full
 *   history of the viewer's own network (themselves and who they follow, or
 *   the default accounts for a viewer who follows few people);
 * - follow distances and likes/comments from the viewer's network, which the
 *   ranking in `lib/videoRanking` turns into an order.
 *
 * Everything streams in as relays deliver it; nothing here waits for a relay.
 */
import { get, writable } from 'svelte/store';
import type { Event, Filter } from 'nostr-tools';
import { nostr } from '../nostr/client';
import { searchRelays } from '../nostr/textSearch';
import { queryConfiguredRelaysDirectly } from '../nostr/directQuery';
import { nostrStore, type NostrState } from '../nostr/store';
import { createFollowsStore, getFollowsSync } from './follows';
import { getFollowDistance, setSocialGraphViewer, socialGraphStore } from '../utils/socialGraph';
import { DEFAULT_BOOTSTRAP_PUBKEY, DEFAULT_VIDEO_FEED_PUBKEYS } from '../utils/constants';
import {
  ALL_VIDEO_EVENT_KINDS,
  VIDEO_EVENT_KIND,
  VIDEO_EVENT_DELETE_KIND,
  groupPlaylistVideos,
  npubToPubkey,
  parseSearchTerms,
  videoKey,
  videoSearchRelevance,
} from '../lib/videoEvent';
import { actorTrust, mixDiscoveryVideos, rankVideos, type RankableVideo } from '../lib/videoRanking';
import { getDeletedVideoTimestamp } from './videoDeletes';
import {
  getVideoEventsSnapshot,
  ingestVideoEvent,
  publicVideoFilters,
  subscribeAllVideoEvents,
  subscribeVideoEvents,
  videoEventsStore,
} from './videoEvents';
import type { VideoItem } from '../components/Video/types';

const MIN_FOLLOWS_THRESHOLD = 5;
const MAX_NETWORK_AUTHORS = 400;
/**
 * Relays allow few subscriptions per connection (relay.ditto.pub closes the 21st),
 * so the feed holds a handful: one request per this many network authors, and
 * short-lived lookups for everything that is history rather than a live stream.
 */
const AUTHORS_PER_REQUEST = 200;
const LOOKUP_MS = 8000;
const RERANK_DELAY_MS = 300;
/** How many indexed videos have their reactions looked up, newest first. */
const ENGAGEMENT_VIDEO_LIMIT = 60;
const ENGAGEMENT_EVENT_LIMIT = 150;
/** Maximum recent history per request for the viewer, seed channels and other network authors. */
const NETWORK_VIDEO_LIMIT = 150;
/** The first request per relay: enough for the first screen and the Shorts row. */
const FIRST_PAGE_PER_KIND = 10;
const FIRST_PAGE_SEED_LIMIT = 40;
const FIRST_PAGE_DIRECT_MS = 6000;
/** The wider window of videos from everywhere, asked for with the rest of the bulk. */
const PUBLIC_HISTORY_LIMIT = 100;
const DISCOVERY_AUTHOR_LIMIT = 5;
const DISCOVERY_VIDEOS_PER_AUTHOR = 4;
const NETWORK_START_DELAY_MS = 6000;
const ENGAGEMENT_START_DELAY_MS = 10000;

export type VideoFeedSort = 'hot' | 'new' | 'top';
export type VideoFeedScope = 'all' | 'following';

export interface VideoFeedSnapshot {
  /** Long-form videos (playlists listed once), best first. */
  videos: VideoItem[];
  /** Short clips, best first. */
  shorts: VideoItem[];
}

export const videoFeedStore = writable<VideoFeedSnapshot>({ videos: [], shorts: [] });

let viewer: string | null = null;
let running = false;
let consumers = 0;
let subscriptions: Array<() => void> = [];
let stopNetworkSubscription: (() => void) | null = null;
let networkSubscribed = false;
let networkTimer: ReturnType<typeof setTimeout> | null = null;
let likedOwnersTimer: ReturnType<typeof setTimeout> | null = null;
let rerankTimer: ReturnType<typeof setTimeout> | null = null;
let engagementTimer: ReturnType<typeof setTimeout> | null = null;

/** The viewer's own network: themselves and who they follow (or the default accounts). */
const networkAuthors = new Set<string>();
export const followingHistoryFilters = writable<Filter[]>([]);
/** Video key → people who liked, reposted or commented on it. */
const engagementActors = new Map<string, Set<string>>();
const engagementRequestedIds = new Set<string>();
const eventIdToKey = new Map<string, string>();
const seenEngagementEventIds = new Set<string>();

function followDistance(pubkey: string): number {
  const distance = getFollowDistance(pubkey);
  return pubkey === viewer || networkAuthors.has(pubkey) ? Math.min(1, distance) : distance;
}

function engagementOf(video: RankableVideo): number {
  let total = 0;
  for (const actor of engagementActors.get(video.key) ?? []) {
    if (actor !== video.ownerPubkey) total += actorTrust(followDistance(actor));
  }
  return total;
}

function isListable(video: VideoItem): boolean {
  if (video.sensitive) return false;
  return !(video.ownerNpub && video.treeName && getDeletedVideoTimestamp(video.ownerNpub, video.treeName));
}

function rerank(): void {
  rerankTimer = null;
  const listable = get(videoEventsStore).filter(isListable);
  const context = { now: Math.floor(Date.now() / 1000), followDistance, engagement: engagementOf };
  videoFeedStore.set({
    videos: rankVideos(groupPlaylistVideos(listable.filter((video) => !video.short)), context),
    shorts: rankVideos(listable.filter((video) => video.short), context),
  });
}

function scheduleRerank(): void {
  rerankTimer ??= setTimeout(rerank, RERANK_DELAY_MS);
}

/** Re-order a feed snapshot for the chosen sort and scope. */
export function orderVideoFeed(videos: VideoItem[], sort: VideoFeedSort, scope: VideoFeedScope): VideoItem[] {
  const scoped = scope === 'following'
    ? videos.filter((video) => !!video.ownerPubkey && networkAuthors.has(video.ownerPubkey))
    : videos;
  if (sort === 'new') {
    return [...scoped].sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0) || a.key.localeCompare(b.key));
  }
  if (sort === 'top') {
    const score = new Map(scoped.map((video) => [video.key, engagementOf(video)]));
    // The hot order breaks ties, so "top" stays meaningful where nobody has reacted yet.
    return [...scoped].sort((a, b) => score.get(b.key)! - score.get(a.key)!);
  }
  return scope === 'all'
    ? mixDiscoveryVideos(scoped, (video) => !!video.ownerPubkey && followDistance(video.ownerPubkey) <= 1)
    : scoped;
}

// --- search -----------------------------------------------------------------

/** Search every indexed video: the best matches first, then the viewer's network, then the freshest. */
export function searchVideoFeed(query: string, limit = 20): VideoItem[] {
  const terms = parseSearchTerms(query);
  if (terms.length === 0) return [];
  const relevanceByKey = new Map<string, number>();
  const matches = get(videoEventsStore).filter((video) => {
    if (!isListable(video)) return false;
    const relevance = videoSearchRelevance(video, terms);
    if (relevance > 0) relevanceByKey.set(video.key, relevance);
    return relevance > 0;
  });
  return rankVideos(matches, {
    now: Math.floor(Date.now() / 1000),
    followDistance,
    engagement: engagementOf,
    relevance: (video) => relevanceByKey.get(video.key) ?? 0,
  }).slice(0, limit);
}

const RELAY_SEARCH_MS = 12000;
let stopRelaySearch: (() => void) | null = null;
let relaySearchQuery = '';

/**
 * Ask the relays for videos matching the query (NIP-50 text search where a
 * relay supports it, and hashtags everywhere). Matches join the index as they
 * arrive; the local search over the index is what decides the results.
 */
export function searchRelaysForVideos(query: string): void {
  const terms = parseSearchTerms(query);
  const normalized = terms.join(' ');
  if (!normalized || normalized === relaySearchQuery) return;
  stopRelaySearch?.();
  relaySearchQuery = normalized;

  // Hashtags are asked for everywhere; the text search travels separately, because
  // relays without text search reject every filter sent along with it.
  const tagged = nostr.subscribe([{ kinds: ALL_VIDEO_EVENT_KINDS, '#t': terms.slice(0, 6), limit: 100 }]);
  tagged.on('event', (event: Event) => { ingestVideoEvent(event); });
  const stopTextSearch = searchRelays(
    [{ kinds: ALL_VIDEO_EVENT_KINDS, search: normalized, limit: 50 }],
    (event) => { ingestVideoEvent(event); },
    RELAY_SEARCH_MS,
  );
  const timer = setTimeout(() => stopRelaySearch?.(), RELAY_SEARCH_MS);
  stopRelaySearch = () => {
    clearTimeout(timer);
    tagged.stop();
    stopTextSearch();
    stopRelaySearch = null;
  };
}

// --- engagement -------------------------------------------------------------

function noteEngagement(key: string, actor: string): void {
  let actors = engagementActors.get(key);
  if (!actors) engagementActors.set(key, actors = new Set());
  if (actors.has(actor)) return;
  actors.add(actor);
  scheduleRerank();
}

/** Likes and comments made in this app name the video as `npub/<encoded tree name>`. */
function videoKeyFromIdentifier(identifier: string | undefined): { key: string; ownerPubkey: string } | null {
  const match = identifier?.match(/^(npub1[a-z0-9]+)\/(.+)$/);
  if (!match) return null;
  const ownerPubkey = npubToPubkey(match[1]);
  if (!ownerPubkey) return null;
  let treeName = match[2];
  try {
    treeName = decodeURIComponent(treeName);
  } catch {
    // Keep the raw name.
  }
  return treeName.startsWith('videos/') ? { key: videoKey(match[1], treeName), ownerPubkey } : null;
}

function handleEngagementEvent(event: Event): void {
  if (!event.id || seenEngagementEventIds.has(event.id)) return;
  seenEngagementEventIds.add(event.id);
  if (event.kind === 7 && event.content.trim() === '-') return;

  const identified = videoKeyFromIdentifier(event.tags.find((tag) => tag[0] === 'i')?.[1]);
  if (identified) {
    noteEngagement(identified.key, event.pubkey);
    // A video the network liked is listed once its owner's video event is known.
    if (!networkAuthors.has(identified.ownerPubkey) && !likedOwners.has(identified.ownerPubkey)) {
      likedOwners.add(identified.ownerPubkey);
      pendingLikedOwners.push(identified.ownerPubkey);
      likedOwnersTimer ??= setTimeout(lookUpLikedOwners, 1000);
    }
    return;
  }
  for (const tag of event.tags) {
    const key = (tag[0] === 'e' || tag[0] === 'E') && tag[1] ? eventIdToKey.get(tag[1]) : undefined;
    if (key) noteEngagement(key, event.pubkey);
  }
}
const likedOwners = new Set<string>();
let pendingLikedOwners: string[] = [];

/** A history lookup: listen for a while, then give the relay its subscription slot back. */
function lookUp(filters: Filter[], onEvent: (event: Event) => void): void {
  const subscription = nostr.subscribe(filters);
  subscription.on('event', onEvent);
  let stopped = false;
  const stopLookup = () => {
    if (stopped) return;
    stopped = true;
    clearTimeout(timer);
    subscription.stop();
  };
  const timer = setTimeout(stopLookup, LOOKUP_MS);
  subscriptions.push(stopLookup);
}

function lookUpLikedOwners(): void {
  likedOwnersTimer = null;
  const owners = pendingLikedOwners.slice(0, AUTHORS_PER_REQUEST);
  pendingLikedOwners = [];
  if (owners.length > 0) lookUp([{ kinds: ALL_VIDEO_EVENT_KINDS, authors: owners, limit: NETWORK_VIDEO_LIMIT }], (event) => { ingestVideoEvent(event); });
}

/** Look up reactions, reposts and comments for the newest indexed videos not asked about yet. */
function requestEngagement(): void {
  engagementTimer = null;
  const ids: string[] = [];
  for (const video of getVideoEventsSnapshot().slice(0, ENGAGEMENT_VIDEO_LIMIT)) {
    if (!video.eventId || engagementRequestedIds.has(video.eventId)) continue;
    engagementRequestedIds.add(video.eventId);
    eventIdToKey.set(video.eventId, video.key);
    ids.push(video.eventId);
  }
  if (ids.length === 0) return;
  lookUp([{ kinds: [7, 6, 16, 1111], '#e': ids, limit: ENGAGEMENT_EVENT_LIMIT }], handleEngagementEvent);
}

// --- the viewer's own network -----------------------------------------------

/** Share the existing public history request between all four kinds and earlier videos by new creators. */
function discoveryHistoryFilters(): Filter[] {
  const byAuthor = new Map<string, number>();
  for (const video of getVideoEventsSnapshot()) {
    const author = video.ownerPubkey;
    if (!author || video.sensitive || byAuthor.has(author) || DEFAULT_VIDEO_FEED_PUBKEYS.includes(author)) continue;
    if (followDistance(author) <= 1) continue;
    byAuthor.set(author, video.updatedAt - 1);
    if (byAuthor.size === DISCOVERY_AUTHOR_LIMIT) break;
  }
  const remaining = PUBLIC_HISTORY_LIMIT - byAuthor.size * DISCOVERY_VIDEOS_PER_AUTHOR;
  return [
    ...publicVideoFilters(Math.floor(remaining / ALL_VIDEO_EVENT_KINDS.length)),
    ...Array.from(byAuthor, ([author, until]) => ({
      kinds: ALL_VIDEO_EVENT_KINDS, authors: [author], until, limit: DISCOVERY_VIDEOS_PER_AUTHOR,
    })),
  ];
}

/**
 * One merged subscription per chunk of network authors: their recent video
 * history outside the public window, their deletions, and
 * the likes and comments they made in this app. Tree roots are left to whoever
 * opens a video: fetching every followed account's roots floods the event queue.
 */
function subscribeNetwork(): void {
  networkTimer = null;
  // The first time, widen the window of videos from everywhere as well.
  if (!networkSubscribed) {
    lookUp(discoveryHistoryFilters(), (event) => { ingestVideoEvent(event); });
  }
  networkSubscribed = true;
  stopNetworkSubscription?.();
  // The feed asks for recent history. Older pages and channel views have their own lookups.
  const full = new Set([...(viewer && networkAuthors.has(viewer) ? [viewer] : []), ...DEFAULT_VIDEO_FEED_PUBKEYS]);
  const authors = [...networkAuthors].filter((author) => !full.has(author));
  const stops: Array<() => void> = [];
  const tagged = (chunk: string[]): Filter => (
    { kinds: [VIDEO_EVENT_DELETE_KIND, 17, 1111], authors: chunk, '#k': ['video', ...ALL_VIDEO_EVENT_KINDS.map(String)], limit: NETWORK_VIDEO_LIMIT }
  );
  const requests: Filter[][] = full.size > 0
    ? [[{ kinds: ALL_VIDEO_EVENT_KINDS, authors: [...full], limit: NETWORK_VIDEO_LIMIT }, tagged([...full])]]
    : [];
  for (let start = 0; start < authors.length; start += AUTHORS_PER_REQUEST) {
    const chunk = authors.slice(start, start + AUTHORS_PER_REQUEST);
    requests.push([{ kinds: ALL_VIDEO_EVENT_KINDS, authors: chunk, limit: NETWORK_VIDEO_LIMIT }, tagged(chunk)]);
  }
  for (const filters of requests) {
    const subscription = nostr.subscribe(filters);
    subscription.on('event', (event: Event) => {
      if (event.kind === 17 || event.kind === 1111) handleEngagementEvent(event);
      else ingestVideoEvent(event);
    });
    stops.push(() => subscription.stop());
  }
  stopNetworkSubscription = () => {
    for (const stopChunk of stops) stopChunk();
    stopNetworkSubscription = null;
  };
}

/** Cover authors not covered yet, so the feed widens as follow lists arrive. */
function addNetworkAuthors(authors: Iterable<string>): void {
  let added = false;
  for (const author of authors) {
    if (networkAuthors.size >= MAX_NETWORK_AUTHORS) break;
    if (!author || networkAuthors.has(author)) continue;
    networkAuthors.add(author);
    added = true;
  }
  if (!added) return;
  followingHistoryFilters.set(newVideoHistoryFilters('following'));
  // Follow lists arrive in bursts: re-subscribe once they settle instead of once per list.
  // The first time, wait a little longer: incoming events are processed strictly in order,
  // and the first page with its names and thumbnails should not queue behind this bulk.
  networkTimer ??= setTimeout(subscribeNetwork, networkSubscribed ? 250 : NETWORK_START_DELAY_MS);
  scheduleRerank();
}

function suspend(): void {
  running = false;
  for (const unsubscribe of subscriptions) unsubscribe();
  subscriptions = [];
  stopNetworkSubscription?.();
  for (const timer of [rerankTimer, engagementTimer, networkTimer, likedOwnersTimer]) {
    if (timer) clearTimeout(timer);
  }
  rerankTimer = engagementTimer = networkTimer = likedOwnersTimer = null;
}

function resetViewer(): void {
  pendingLikedOwners = [];
  networkSubscribed = false;
  networkAuthors.clear();
  followingHistoryFilters.set([]);
  likedOwners.clear();
  engagementActors.clear();
  engagementRequestedIds.clear();
  eventIdToKey.clear();
  seenEngagementEventIds.clear();
}

function start(): void {
  running = true;
  viewer = (get(nostrStore) as NostrState).pubkey ?? null;
  const knownFollows = viewer ? getFollowsSync(viewer)?.follows ?? [] : [];
  setSocialGraphViewer(viewer, knownFollows.length);

  // The first page straight from the relays, shown as each one answers, without
  // queueing behind the worker (see `directQuery`).
  subscriptions.push(queryConfiguredRelaysDirectly([
    ...publicVideoFilters(FIRST_PAGE_PER_KIND),
    { kinds: ALL_VIDEO_EVENT_KINDS, authors: DEFAULT_VIDEO_FEED_PUBKEYS, limit: FIRST_PAGE_SEED_LIMIT },
  ], (event) => { ingestVideoEvent(event); }, FIRST_PAGE_DIRECT_MS));

  // The same through the worker, which keeps them and stays subscribed for new ones:
  // the newest videos from everywhere and from the seed channels.
  subscriptions.push(subscribeAllVideoEvents(FIRST_PAGE_PER_KIND));
  subscriptions.push(subscribeVideoEvents(DEFAULT_VIDEO_FEED_PUBKEYS, FIRST_PAGE_SEED_LIMIT));
  addNetworkAuthors([...(viewer ? [viewer] : []), ...knownFollows]);

  let usingDefaults = false;
  const useDefaultAccounts = () => {
    if (usingDefaults) return;
    usingDefaults = true;
    addNetworkAuthors([DEFAULT_BOOTSTRAP_PUBKEY, ...DEFAULT_VIDEO_FEED_PUBKEYS]);
    let latestContactsAt = 0;
    const contacts = nostr.subscribe({ kinds: [3], authors: [DEFAULT_BOOTSTRAP_PUBKEY] });
    contacts.on('event', (event) => {
      if ((event.created_at || 0) < latestContactsAt) return;
      latestContactsAt = event.created_at || 0;
      addNetworkAuthors(event.tags.filter((tag) => tag[0] === 'p' && tag[1]).map((tag) => tag[1]));
    });
    subscriptions.push(() => contacts.stop());
  };

  if (viewer) {
    // The viewer's follow list may still be loading.
    const followsStore = createFollowsStore(viewer);
    const unsubscribeFollows = followsStore.subscribe((value) => {
      const follows = value?.follows ?? [];
      setSocialGraphViewer(viewer, follows.length);
      addNetworkAuthors(follows);
      // With few follows, fill the feed from the default account, its follows and the seed accounts.
      if (follows.length < MIN_FOLLOWS_THRESHOLD) useDefaultAccounts();
    });
    subscriptions.push(() => { unsubscribeFollows(); followsStore.destroy(); });
  }
  if (knownFollows.length < MIN_FOLLOWS_THRESHOLD) useDefaultAccounts();
  // On return, retained authors and rankings are already available to the view.
  if (networkAuthors.size) networkTimer ??= setTimeout(subscribeNetwork, NETWORK_START_DELAY_MS);
  if (pendingLikedOwners.length) likedOwnersTimer ??= setTimeout(lookUpLikedOwners, 1000);

  subscriptions.push(videoEventsStore.subscribe(() => {
    scheduleRerank();
    // Soon for the first page, then rarely: each lookup holds a relay subscription for a while.
    engagementTimer ??= setTimeout(requestEngagement, engagementRequestedIds.size === 0 ? ENGAGEMENT_START_DELAY_MS : 15000);
  }));
  // Follow distances fill in as the social graph does.
  subscriptions.push(socialGraphStore.subscribe(scheduleRerank));
}

function syncFeedActivity(): void {
  if (consumers && document.visibilityState !== 'hidden') {
    if (!running) start();
  } else if (running) suspend();
}

/** Share subscriptions between visible feed views, retaining the displayed feed while away. */
export function acquireVideoFeed(): () => void {
  if (++consumers === 1) document.addEventListener('visibilitychange', syncFeedActivity);
  syncFeedActivity();
  return () => {
    if (--consumers === 0) document.removeEventListener('visibilitychange', syncFeedActivity);
    syncFeedActivity();
  };
}

/** Whether an author belongs to the viewer's own network (the "Following" scope). */
export function isNetworkAuthor(pubkey: string | null | undefined): boolean {
  return !!pubkey && networkAuthors.has(pubkey);
}

/** The New grid pages long-video events. Following uses the same authors as its on-screen filter. */
export function newVideoHistoryFilters(scope: VideoFeedScope): Filter[] {
  const kinds = [VIDEO_EVENT_KIND, 21];
  if (scope === 'all') return [{ kinds }];
  const authors = [...networkAuthors].sort();
  const filters: Filter[] = [];
  for (let start = 0; start < authors.length; start += AUTHORS_PER_REQUEST) {
    filters.push({ kinds, authors: authors.slice(start, start + AUTHORS_PER_REQUEST) });
  }
  return filters;
}

nostrStore.subscribe((state: NostrState) => {
  if ((state.pubkey ?? null) === viewer) return;
  if (running) suspend();
  resetViewer();
  viewer = state.pubkey ?? null;
  videoFeedStore.set({ videos: [], shorts: [] });
  if (consumers) syncFeedActivity();
});
