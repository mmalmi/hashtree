/**
 * The list of feed videos shared by the home page and the "up next" sidebar:
 * the best of the ranked feed (stores/videoFeed), with thumbnails and durations
 * read from the tree for the few videos whose event lacks them.
 */
import { writable, get } from 'svelte/store';
import type { CID } from '@hashtree/core';
import { nostrStore, type NostrState } from '../nostr';
import { toHex } from '@hashtree/core';
import { startVideoFeed, videoFeedStore, type VideoFeedSnapshot } from './videoFeed';
import { reconcileFeed } from '../lib/feedPresentation';
import { isHtreeDebugEnabled, logHtreeDebug } from '../lib/htreeDebug';
import { detectPlaylistForCard, getCachedPlaylistInfo, shouldRefreshPlaylistCardInfo } from './playlist';
import { resolveFeedVideoRootCid, resolveFeedVideoRootCidAsync } from '../lib/videoFeedRoot';
import { onCacheUpdate } from '../treeRootCache';
import { resolveReadableThumbnailRoot, resolveReadableVideoRoot } from '../lib/readableVideoRoot';

const log = (event: string, data?: Record<string, unknown>) => {
  if (!isHtreeDebugEnabled()) return;
  logHtreeDebug(`feed:${event}`, data);
};

const FEED_MEDIA_RESOLUTION_MAX_RETRIES = 8;
const FEED_MEDIA_RESOLUTION_CONCURRENCY = 2;

const attemptedFeedMediaKeys = new Set<string>();
const cachedFeedMediaByKey = new Map<string, Partial<FeedVideo>>();
const inFlightFeedMediaKeys = new Set<string>();
const feedMediaRetryCounts = new Map<string, number>();
const feedMediaRetryTimers = new Map<string, ReturnType<typeof setTimeout>>();

export interface FeedVideo {
  /** Stable identity (`<npub>/<tree>...` or `event:...`) */
  key?: string;
  href: string;
  title: string;
  ownerPubkey: string | null;
  ownerNpub: string | null;
  treeName: string | null;
  videoId?: string;
  duration?: number;
  thumbnailUrl?: string;
  videoPath?: string;
  /** Playable web URLs of a video hosted outside hashtree */
  videoUrls?: string[];
  tags?: string[];
  /** Set when the entry stands for a whole playlist */
  videoCount?: number;
  visibility?: string;
  timestamp?: number;
  rootCid?: CID | null;
}

export const feedStore = writable<FeedVideo[]>([]);

onCacheUpdate((npub, treeName) => {
  const videos = get(feedStore);
  if (!videos.some((video) => video.ownerNpub === npub && video.treeName === treeName)) {
    return;
  }
  queueFeedVideoMediaResolution(videos);
});

function resetFeedMediaResolution(): void {
  attemptedFeedMediaKeys.clear();
  cachedFeedMediaByKey.clear();
  inFlightFeedMediaKeys.clear();
  for (const timer of feedMediaRetryTimers.values()) {
    clearTimeout(timer);
  }
  feedMediaRetryTimers.clear();
  feedMediaRetryCounts.clear();
}

function getFeedMediaResolutionKey(video: FeedVideo): string | null {
  if (!video.ownerNpub || !video.treeName) return null;
  const rootCid = resolveFeedVideoRootCid(video);
  if (!rootCid?.hash) {
    return `${video.ownerNpub}/${video.treeName}`;
  }
  return `${video.ownerNpub}/${video.treeName}/${toHex(rootCid.hash)}`;
}

function hasResolvedFeedVideoMedia(video: FeedVideo, cached?: Partial<FeedVideo>): boolean {
  const resolvedRootCid = cached?.rootCid ?? resolveFeedVideoRootCid(video);
  const resolvedThumbnailUrl = cached?.thumbnailUrl ?? video.thumbnailUrl;
  const resolvedVideoPath = cached?.videoPath ?? video.videoPath;
  const resolvedDuration = cached?.duration ?? video.duration;

  // A video event that names its thumbnail (and, for a single video, its media file) has
  // everything a card shows: the tree need not be looked up or read. Each such lookup is
  // a relay subscription, and relays allow only a few at a time.
  if (resolvedThumbnailUrl && (resolvedVideoPath || video.videoCount)) return true;
  if (typeof resolvedDuration !== 'number') return false;
  return !!resolvedRootCid && (!!resolvedThumbnailUrl || !!resolvedVideoPath);
}

function shouldResolveFeedVideoMedia(video: FeedVideo): boolean {
  if (!video.ownerNpub || !video.treeName) return false;
  const resolutionKey = getFeedMediaResolutionKey(video);
  if (!resolutionKey) return false;
  const cached = cachedFeedMediaByKey.get(resolutionKey);
  if (!cached) return true;
  return !hasResolvedFeedVideoMedia(video, cached);
}

function sameCid(a?: CID | null, b?: CID | null): boolean {
  if (!a && !b) return true;
  if (!a || !b) return false;
  return toHex(a.hash) === toHex(b.hash)
    && ((a.key && b.key && toHex(a.key) === toHex(b.key)) || (!a.key && !b.key));
}

function applyCachedFeedMedia(videos: FeedVideo[]): FeedVideo[] {
  let changed = false;
  const nextVideos = videos.map((video) => {
    const resolutionKey = getFeedMediaResolutionKey(video);
    if (!resolutionKey) return video;

    const cached = cachedFeedMediaByKey.get(resolutionKey);
    if (!cached) return video;

    const nextTitle = cached.title ?? video.title;
    const nextDuration = cached.duration ?? video.duration;
    const nextThumbnailUrl = cached.thumbnailUrl ?? video.thumbnailUrl;
    const nextVideoPath = cached.videoPath ?? video.videoPath;
    const nextRootCid = cached.rootCid ?? video.rootCid;

    if (
      nextTitle === video.title &&
      nextDuration === video.duration &&
      nextThumbnailUrl === video.thumbnailUrl &&
      nextVideoPath === video.videoPath &&
      sameCid(nextRootCid, video.rootCid)
    ) {
      return video;
    }

    changed = true;
    return {
      ...video,
      title: nextTitle,
      duration: nextDuration,
      thumbnailUrl: nextThumbnailUrl,
      videoPath: nextVideoPath,
      rootCid: nextRootCid,
    };
  });

  return changed ? nextVideos : videos;
}

export async function getFeedVideoResolvedMedia(video: FeedVideo): Promise<Partial<FeedVideo> | null> {
  const latestRootCid = await resolveFeedVideoRootCidAsync(video, 8000);
  if (!latestRootCid || !video.ownerNpub || !video.treeName) return null;

  const rootCid = await resolveReadableVideoRoot({
    rootCid: latestRootCid,
    npub: video.ownerNpub,
    treeName: video.treeName,
    videoId: video.videoId ?? null,
    priority: 'background',
  }) ?? latestRootCid;

  const cached = getCachedPlaylistInfo(video.ownerNpub, video.treeName);
  const playbackInfo = cached !== undefined && !shouldRefreshPlaylistCardInfo(cached)
    ? cached
    : await detectPlaylistForCard(rootCid, video.ownerNpub, video.treeName);
  const playbackRootCid = playbackInfo?.rootCid ?? rootCid;
  let thumbnailInfo: Partial<FeedVideo> | null = null;
  let thumbnailUrl = playbackInfo?.thumbnailUrl;

  const thumbnailRootCid = await resolveReadableThumbnailRoot({
    rootCid: playbackRootCid,
    npub: video.ownerNpub,
    treeName: video.treeName,
    videoId: video.videoId ?? null,
    priority: 'background',
  }) ?? playbackRootCid;

  if (!sameCid(thumbnailRootCid, playbackRootCid)) {
    thumbnailInfo = await detectPlaylistForCard(thumbnailRootCid, video.ownerNpub, video.treeName, {
      cacheScope: 'root',
    });
    thumbnailUrl = thumbnailInfo?.thumbnailUrl ?? thumbnailUrl;
  }

  const resolved: Partial<FeedVideo> = {};
  if (!sameCid(rootCid, video.rootCid)) {
    resolved.rootCid = rootCid;
  }
  if (!playbackInfo && !thumbnailInfo) {
    return Object.keys(resolved).length > 0 ? resolved : null;
  }

  const resolvedRootCid = playbackRootCid;
  if (!sameCid(resolvedRootCid, resolved.rootCid ?? video.rootCid)) {
    resolved.rootCid = resolvedRootCid;
  }
  if (thumbnailUrl) {
    resolved.thumbnailUrl = thumbnailUrl;
  }
  if (playbackInfo?.videoPath) {
    resolved.videoPath = playbackInfo.videoPath;
  }
  if (typeof playbackInfo?.duration === 'number') {
    resolved.duration = playbackInfo.duration;
  }
  if (typeof playbackInfo?.title === 'string' && playbackInfo.title) {
    resolved.title = playbackInfo.title;
  }

  return Object.keys(resolved).length > 0 ? resolved : null;
}

async function resolveFeedVideoMedia(video: FeedVideo): Promise<void> {
  const resolutionKey = getFeedMediaResolutionKey(video);
  if (!resolutionKey) return;
  if (!shouldResolveFeedVideoMedia(video)) return;
  if (attemptedFeedMediaKeys.has(resolutionKey) || inFlightFeedMediaKeys.has(resolutionKey)) return;

  inFlightFeedMediaKeys.add(resolutionKey);
  try {
    const resolved = await getFeedVideoResolvedMedia(video);
    if (!resolved) {
      scheduleFeedVideoMediaRetry(resolutionKey);
      return;
    }

    const nextVideo = { ...video, ...resolved };
    const nextResolutionKey = getFeedMediaResolutionKey(nextVideo) ?? resolutionKey;
    cachedFeedMediaByKey.set(resolutionKey, {
      ...cachedFeedMediaByKey.get(resolutionKey),
      ...resolved,
    });
    if (nextResolutionKey !== resolutionKey) {
      cachedFeedMediaByKey.set(nextResolutionKey, {
        ...cachedFeedMediaByKey.get(nextResolutionKey),
        ...resolved,
      });
    }
    const retryTimer = feedMediaRetryTimers.get(resolutionKey) ?? feedMediaRetryTimers.get(nextResolutionKey);
    if (retryTimer) {
      clearTimeout(retryTimer);
      feedMediaRetryTimers.delete(resolutionKey);
      feedMediaRetryTimers.delete(nextResolutionKey);
    }
    feedMediaRetryCounts.delete(resolutionKey);
    feedMediaRetryCounts.delete(nextResolutionKey);

    feedStore.update((videos) => {
      let changed = false;
      const nextVideos = videos.map((candidate) => {
        const candidateKey = getFeedMediaResolutionKey(candidate);
        if (candidateKey !== resolutionKey && candidateKey !== nextResolutionKey) {
          return candidate;
        }

        const nextTitle = resolved.title ?? candidate.title;
        const nextDuration = resolved.duration ?? candidate.duration;
        const nextThumbnailUrl = resolved.thumbnailUrl ?? candidate.thumbnailUrl;
        const nextVideoPath = resolved.videoPath ?? candidate.videoPath;
        const nextRootCid = resolved.rootCid ?? candidate.rootCid;

        if (
          nextTitle === candidate.title &&
          nextDuration === candidate.duration &&
          nextThumbnailUrl === candidate.thumbnailUrl &&
          nextVideoPath === candidate.videoPath &&
          sameCid(nextRootCid, candidate.rootCid)
        ) {
          return candidate;
        }

        changed = true;
        return {
          ...candidate,
          title: nextTitle,
          duration: nextDuration,
          thumbnailUrl: nextThumbnailUrl,
          videoPath: nextVideoPath,
          rootCid: nextRootCid,
        };
      });

      return changed ? nextVideos : videos;
    });

    if (!shouldResolveFeedVideoMedia(nextVideo)) {
      attemptedFeedMediaKeys.add(resolutionKey);
      attemptedFeedMediaKeys.add(nextResolutionKey);
    } else {
      scheduleFeedVideoMediaRetry(nextResolutionKey);
    }
  } finally {
    inFlightFeedMediaKeys.delete(resolutionKey);
  }
}

function scheduleFeedVideoMediaRetry(resolutionKey: string): void {
  if (feedMediaRetryTimers.has(resolutionKey)) return;

  const attempt = (feedMediaRetryCounts.get(resolutionKey) ?? 0) + 1;
  if (attempt > FEED_MEDIA_RESOLUTION_MAX_RETRIES) {
    return;
  }

  feedMediaRetryCounts.set(resolutionKey, attempt);
  const delayMs = 250 * (2 ** (attempt - 1));
  const timer = setTimeout(() => {
    feedMediaRetryTimers.delete(resolutionKey);
    const current = get(feedStore).find((video) => getFeedMediaResolutionKey(video) === resolutionKey);
    if (!current) return;
    if (!shouldResolveFeedVideoMedia(current)) return;
    void resolveFeedVideoMedia(current);
  }, delayMs);

  feedMediaRetryTimers.set(resolutionKey, timer);
}

function queueFeedVideoMediaResolution(videos: FeedVideo[]): void {
  const pending = videos.filter((video) => {
    const resolutionKey = getFeedMediaResolutionKey(video);
    return !!resolutionKey
      && shouldResolveFeedVideoMedia(video)
      && !feedMediaRetryTimers.has(resolutionKey)
      && !attemptedFeedMediaKeys.has(resolutionKey)
      && !inFlightFeedMediaKeys.has(resolutionKey);
  });

  // A few at a time: every lookup holds a relay subscription until its tree root arrives.
  for (const video of pending) {
    if (inFlightFeedMediaKeys.size >= FEED_MEDIA_RESOLUTION_CONCURRENCY) break;
    void resolveFeedVideoMedia(video).finally(() => queueFeedVideoMediaResolution(get(feedStore)));
  }
}

function publishFeedVideos(videos: FeedVideo[]): void {
  const hydratedVideos = applyCachedFeedMedia(videos);
  feedStore.set(hydratedVideos);
  queueFeedVideoMediaResolution(hydratedVideos);
}

/** How many of the best-ranked videos the "up next" list holds. */
const FEED_LIST_LIMIT = 60;
let shownKeys: string[] = [];
let listening = false;

/** List the ranked feed. Entries keep their place once listed, so the list never jumps. */
function publishFromFeed(snapshot: VideoFeedSnapshot): void {
  shownKeys = reconcileFeed(shownKeys, snapshot.videos.map((video) => video.key), FEED_LIST_LIMIT).shown;
  const byKey = new Map(snapshot.videos.map((video) => [video.key, video]));
  publishFeedVideos(shownKeys.flatMap((key) => {
    const video = byKey.get(key);
    return video ? [{
      key: video.key,
      href: video.href,
      title: video.title,
      ownerPubkey: video.ownerPubkey,
      ownerNpub: video.ownerNpub,
      treeName: video.treeName || null,
      videoId: video.videoId,
      duration: video.duration,
      thumbnailUrl: video.thumbnailUrl,
      videoPath: video.videoPath,
      videoUrls: video.videoUrls,
      tags: video.tags,
      videoCount: video.videoCount,
      timestamp: video.timestamp,
    }] : [];
  }));
}

/**
 * Start listing feed videos - the same ranked feed as the home page.
 * Returns at once: what is indexed is listed immediately and the rest streams in.
 */
export function fetchFeedVideos(): void {
  startVideoFeed();
  if (listening) return;
  listening = true;
  videoFeedStore.subscribe(publishFromFeed);
}

let lastPubkey: string | null = null;
nostrStore.subscribe((state: NostrState) => {
  if (state.pubkey === lastPubkey) return;
  lastPubkey = state.pubkey;
  resetFeedMediaResolution();
  shownKeys = [];
  feedStore.set([]);
  log('reset:pubkey', { pubkey: state.pubkey });
});
