/**
 * People search for the search box.
 *
 * Names come from two places, both held in memory only: profiles the app has
 * already loaded, and what the relays answer to a text search (NIP-50). The
 * relays' matches join the list as they arrive; the search itself is local
 * and never waits for them.
 */
import { writable } from 'svelte/store';
import type { Event } from 'nostr-tools';
import { searchRelays } from '../nostr/textSearch';
import { rankUsers, toUserIndexEntry, type UserIndexEntry, type UserIndexEntryInput } from '../lib/search/userIndexEntry';
import { getFollowDistance } from '../utils/socialGraph';

export type { UserIndexEntry, UserIndexEntryInput } from '../lib/search/userIndexEntry';

const MAX_KNOWN_USERS = 3000;
const RELAY_SEARCH_MS = 8000;
const RELAY_SEARCH_LIMIT = 20;

const users = new Map<string, UserIndexEntry>();

/** Changes whenever somebody new can be found. */
export const userSearchVersion = writable(0);
let versionTimer: ReturnType<typeof setTimeout> | null = null;

function bumpVersion(): void {
  versionTimer ??= setTimeout(() => {
    versionTimer = null;
    userSearchVersion.update((version) => version + 1);
  }, 200);
}

/** Make people findable by name. Entries without any name are skipped: there is nothing to match. */
export function indexUsers(entries: UserIndexEntryInput[]): void {
  let changed = false;
  for (const input of entries) {
    const entry = toUserIndexEntry(input);
    if (!entry || (!entry.name && !entry.displayName && !entry.nip05)) continue;
    const known = users.get(entry.pubkey);
    if (known && known.name === entry.name && known.displayName === entry.displayName && known.nip05 === entry.nip05) continue;
    // Re-insert so the least recently learned are the first to go.
    users.delete(entry.pubkey);
    users.set(entry.pubkey, entry);
    changed = true;
  }
  while (users.size > MAX_KNOWN_USERS) users.delete(users.keys().next().value!);
  if (changed) bumpVersion();
}

export function searchUsers(query: string, limit = 10): UserIndexEntry[] {
  return rankUsers(users.values(), query, limit, getFollowDistance);
}

let stopRelaySearch: (() => void) | null = null;
let relaySearchQuery = '';

/** Ask the relays for profiles matching the query. Relays without text search answer nothing useful, which the local search ignores. */
export function searchRelaysForUsers(query: string): void {
  const normalized = query.trim().toLowerCase();
  if (normalized.length < 2 || normalized === relaySearchQuery) return;
  stopRelaySearch?.();
  relaySearchQuery = normalized;

  const stop = searchRelays([{ kinds: [0], search: normalized, limit: RELAY_SEARCH_LIMIT }], (event: Event) => {
    try {
      const profile = JSON.parse(event.content) as { name?: string; display_name?: string; nip05?: string };
      indexUsers([{ pubkey: event.pubkey, name: profile.name, displayName: profile.display_name, nip05: profile.nip05 }]);
    } catch {
      // Not a profile.
    }
  }, RELAY_SEARCH_MS);
  stopRelaySearch = () => {
    stop();
    stopRelaySearch = null;
  };
}

export function clearUserSearch(): void {
  users.clear();
  stopRelaySearch?.();
  relaySearchQuery = '';
}
