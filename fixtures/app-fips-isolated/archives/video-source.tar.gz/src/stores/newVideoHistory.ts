import { HistoryCursor, relaySource, type NostrVerifiedEvent, type RuntimeQueryOptions, type RuntimeQueryResult } from 'nostr-pubsub';
import type { Filter } from 'nostr-tools';
import { getWorkerAdapter } from '../workerAdapter';
import { ingestVideoEvent } from './videoEvents';

const PAGE_SIZE = 24;
const MAX_BOUNDARY_SIZE = 192;
export type VideoHistoryStatus = 'ready' | 'loading' | 'retry' | 'end';
type Query = (filters: Filter[], options: RuntimeQueryOptions) => Promise<RuntimeQueryResult>;

interface RelayHistory {
  relay: string;
  cursors: HistoryCursor[];
  status: VideoHistoryStatus;
}

/** A deep archive or a slow response on one relay must not skip or stall pages on another. */
export class NewVideoHistory {
  private readonly sources: RelayHistory[];
  private readonly controller = new AbortController();

  constructor(relays: string[], filters: Filter[]) {
    const now = Math.floor(Date.now() / 1000);
    this.sources = relays.map(relay => ({
      relay,
      cursors: filters.map(filter => new HistoryCursor(relay, { ...filter, limit: PAGE_SIZE }, now, MAX_BOUNDARY_SIZE)),
      status: 'ready',
    }));
  }

  stop(): void {
    this.controller.abort();
  }

  load(onStatus: (status: VideoHistoryStatus) => void, retry: boolean): void {
    const adapter = getWorkerAdapter();
    if (!adapter?.queryEvents) {
      onStatus('retry');
      return;
    }
    const query = adapter.queryEvents.bind(adapter);
    const update = () => {
      if (this.controller.signal.aborted) return;
      const priority: VideoHistoryStatus[] = ['ready', 'loading', 'retry'];
      onStatus(priority.find(status => this.sources.some(source => source.status === status)) ?? 'end');
    };
    for (const source of this.sources) {
      if (source.status !== 'ready' && !(retry && source.status === 'retry')) continue;
      source.status = 'loading';
      void this.loadRelay(query, source).then(status => {
        source.status = status;
        update();
      });
    }
    update();
  }

  private async loadRelay(query: Query, { relay, cursors }: RelayHistory): Promise<VideoHistoryStatus> {
    const active = cursors.flatMap((cursor, index) => {
      const page = cursor.beginPage();
      return page ? [{ cursor, page, index }] : [];
    });
    if (!active.length) return 'end';

    let complete = false;
    const { signal } = this.controller;
    try {
      const result = await query(active.map(({ page }) => page.filter), {
        relays: [relay], cache: 'network-only', localEcho: false, signal, deadline: Date.now() + 8000,
      });
      if (signal.aborted) return 'end';
      const source = relaySource(relay);
      for (const event of result.events) {
        // The worker has verified these events. Observe before the index groups or drops any of them.
        for (const { cursor, page } of active) {
          cursor.observe(page.token, { event: event as NostrVerifiedEvent, source, priority: 0 });
        }
        ingestVideoEvent(event);
      }
      complete = result.complete;
    } catch {
      // A timeout or disconnect keeps the boundary for an explicit retry.
    }
    const outcomes = active.map(({ cursor, page, index }) => {
      const { status, oldest } = cursor.finishPage(page.token, complete ? 'complete' : 'partial');
      if (status === 'limited' && oldest !== undefined && oldest > 0) {
        // NIP-01 has only second precision. After the bounded tie lookup, continue to older seconds.
        cursors[index] = new HistoryCursor(relay, { ...page.filter, until: oldest - 1, limit: PAGE_SIZE }, oldest, MAX_BOUNDARY_SIZE);
        return 'advanced';
      }
      return status;
    });
    if (outcomes.includes('advanced')) return 'ready';
    return outcomes.includes('retry') ? 'retry' : 'end';
  }
}
