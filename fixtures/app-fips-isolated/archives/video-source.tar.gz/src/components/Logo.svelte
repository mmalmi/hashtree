<script lang="ts">
  import { getAppBrand, getAppBrandAssetUrl, type IrisFilesAppId } from '../lib/appBrand';

  const baseUrl = import.meta.env.BASE_URL;

  let { class: className = '', app = 'files' }: { class?: string; app?: IrisFilesAppId } = $props();
  let brand = $derived(getAppBrand(app));
  let iconUrl = $derived(getAppBrandAssetUrl(app, 'iconSvg', baseUrl));
</script>

<span class="inline-flex items-center gap-2 leading-none {className}">
  <img src={iconUrl} alt="" class="w-8 h-8 shrink-0" draggable="false" />
  <span class="font-semibold text-xl leading-none text-text-1">{brand.label}</span>
</span>
