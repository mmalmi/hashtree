<script lang="ts">
  import { settingsStore, DEFAULT_POOL_SETTINGS } from '../../stores/settings';
  import { appStore, refreshWebRTCStats } from '../../store';

  interface Props {
    embedded?: boolean;
  }

  let { embedded = false }: Props = $props();
  let poolSettings = $derived($settingsStore.pools);
  let peerList = $derived($appStore.peers.filter((peer) => peer.state === 'connected'));

  $effect(() => {
    void refreshWebRTCStats();
    const interval = window.setInterval(() => void refreshWebRTCStats(), 1_000);
    return () => window.clearInterval(interval);
  });

  function shortPeerId(peerId: string): string {
    return peerId.length > 20
      ? `${peerId.slice(0, 12)}…${peerId.slice(-8)}`
      : peerId;
  }
</script>

<div class:root-layout={!embedded} class:embedded-layout={embedded}>
  <section>
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-1">Display</h3>
    <div class="bg-surface-2 rounded divide-y divide-surface-3">
      <label class="p-3 flex items-center justify-between cursor-pointer">
        <div>
          <span class="text-sm text-text-1">Show connectivity in header</span>
          <p class="text-xs text-text-3">Otherwise the header only warns when Video is offline</p>
        </div>
        <input
          type="checkbox"
          checked={poolSettings.showConnectivity ?? DEFAULT_POOL_SETTINGS.showConnectivity}
          onchange={(event) => settingsStore.setPoolSettings({ showConnectivity: event.currentTarget.checked })}
          class="w-4 h-4 accent-accent"
        />
      </label>
    </div>
  </section>

  <section data-testid="settings-fips-peers">
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-1">
      Connected devices ({peerList.length})
    </h3>
    <p class="text-xs text-text-3 mb-3">
      Devices can share cached files directly.
    </p>

    {#if peerList.length === 0}
      <div class="bg-surface-2 rounded p-3 text-sm text-muted">No devices connected</div>
    {:else}
      <div class="bg-surface-2 rounded divide-y divide-surface-3">
        {#each peerList as peer (peer.id)}
          <div class="flex items-center gap-3 p-3" data-testid="settings-fips-peer">
            <span class="w-2 h-2 rounded-full shrink-0 bg-success"></span>
            <div class="min-w-0 flex-1">
              <div class="font-mono text-sm text-text-1 truncate" title={peer.id}>
                {shortPeerId(peer.id)}
              </div>
              <div class="text-xs text-text-3">Device ID</div>
            </div>
          </div>
        {/each}
      </div>
    {/if}
  </section>
</div>

<style>
  .root-layout {
    padding: 1rem;
    max-width: 42rem;
    margin: 0 auto;
  }

  .embedded-layout {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
  }
</style>
