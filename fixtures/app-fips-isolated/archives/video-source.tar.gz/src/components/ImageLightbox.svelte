<script lang="ts">
  /**
   * ImageLightbox - a picture shown large over the page
   * Closes on a click anywhere, or Escape.
   */
  import ProxyImg from './ProxyImg.svelte';

  interface Props {
    src: string;
    alt?: string;
    onClose: () => void;
  }

  let { src, alt = '', onClose }: Props = $props();

  function handleKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape') return;
    event.stopPropagation();
    onClose();
  }
</script>

<svelte:window onkeydowncapture={handleKeydown} />

<div
  class="fixed inset-0 z-100 flex items-center justify-center bg-black/85 p-4 cursor-zoom-out"
  role="dialog"
  aria-modal="true"
  aria-label={alt || 'Picture'}
  data-testid="image-lightbox"
>
  <button class="absolute inset-0 w-full h-full bg-transparent b-0 p-0 cursor-zoom-out" aria-label="Close" onclick={onClose}></button>
  <ProxyImg {src} {alt} width={1200} class="relative max-w-full max-h-full rounded-lg object-contain pointer-events-none" style="width: auto; height: auto; max-width: 100%; max-height: calc(100vh - 2rem);" />
  <button class="absolute top-3 right-3 btn-circle btn-ghost bg-black/50 text-white" title="Close" aria-label="Close picture" onclick={onClose}>
    <span class="i-lucide-x text-lg"></span>
  </button>
</div>
