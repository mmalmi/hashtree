<script lang="ts">
  /**
   * RichText - a comment, bio or caption: links, pictures, mentions and hashtags
   * made useful, and long text cut short behind "Show more".
   */
  import { parseRichText, truncateRichText } from '../lib/richText';
  import RichTextSegments from './RichTextSegments.svelte';

  interface Props {
    text: string;
    /** Longer text than this is cut behind "Show more". 0 shows everything. */
    maxLines?: number;
    maxChars?: number;
    images?: boolean;
    class?: string;
  }

  let { text, maxLines = 6, maxChars = 420, images = true, class: className = '' }: Props = $props();

  let expanded = $state(false);
  let cut = $derived(maxLines > 0 ? truncateRichText(text, maxLines, maxChars) : { text, truncated: false });
  let segments = $derived(parseRichText(expanded ? text : cut.text));
</script>

<p class="whitespace-pre-wrap break-words m-0 {className}" data-testid="rich-text">
  <RichTextSegments {segments} {images} />{#if cut.truncated}{#if !expanded}…{/if}
    <button
      class="bg-transparent b-0 p-0 cursor-pointer font-semibold text-text-1 hover:underline"
      data-testid="rich-text-toggle"
      onclick={(event) => { event.stopPropagation(); expanded = !expanded; }}
    >{expanded ? 'Show less' : 'Show more'}</button>
  {/if}
</p>
