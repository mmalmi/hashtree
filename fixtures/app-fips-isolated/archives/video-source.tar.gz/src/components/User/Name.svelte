<script lang="ts">
  import FavoriteStar from '@iris/svelte-ui/FavoriteStar.svelte';
  import { nostrStore } from '../../nostr';
  import { contactMemory, contactKey } from '../../stores/contactMemory';
  import SharedName from '@iris/svelte-ui/Name.svelte';
  import { createProfileStore, getProfileName } from '../../stores/profile';
  import { animalName } from '../../utils/animalName';

  interface Props {
    pubkey: string;
    class?: string;
  }

  let { pubkey, class: className = '' }: Props = $props();

  let profileStore = $derived(pubkey ? createProfileStore(pubkey) : null);
  let profile = $derived(profileStore ? $profileStore : undefined);
  let memory = $derived.by(() => {
    $contactMemory;
    return contactMemory.get($nostrStore.pubkey || '', contactKey(pubkey));
  });
  $effect(() => {
    try { contactMemory.observeKnown($nostrStore.pubkey || '', contactKey(pubkey), getProfileName(profile ?? undefined, pubkey) ?? null); }
    catch { /* Explicit profile actions report storage failures. */ }
  });
  let animal = $derived(pubkey ? animalName(pubkey) : '');
</script>

<SharedName
  {pubkey}
  {profile}
  name={memory?.accepted_name}
  fallbackName={animal}
  class={`truncate ${className}`.trim()}
  fallbackClass="italic opacity-70"
/>

<FavoriteStar favorite={memory?.favorite ?? false} />
