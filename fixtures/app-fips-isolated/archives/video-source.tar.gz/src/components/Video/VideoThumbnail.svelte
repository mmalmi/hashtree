<script lang="ts">
  /**
   * VideoThumbnail - Reusable video thumbnail with duration and progress bar
   * Used by VideoCard, FeedSidebar, PlaylistSidebar, etc.
   */
  import { htreeReady, needsHtree } from '../../lib/htreeReady';
  import { blobMirrorUrls, hasBlobUrl } from '../../lib/videoEvent';
  import { isWebUrl, webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import { blobServersStore, requestBlobServers } from '../../stores/blobServers';
  import { onDestroy } from 'svelte';
  import { SvelteSet } from 'svelte/reactivity';
  import { formatDuration } from '../../utils/format';
  import { shouldEagerLoadMediaInNativeChildRuntime } from '../../lib/nativeHtree';
  import {
    appendMediaImageRetryParam,
    getMediaImageRetryDelayMs,
    isRetryableMediaImageUrl,
    MAX_MEDIA_IMAGE_RETRIES,
  } from '../../lib/mediaImageRetry';
  import { isAudioMediaFileName } from '../../lib/playableMedia';

  const IMAGE_CANDIDATE_STALL_TIMEOUT_MS = 8000;
  /** Authors rarely list more file servers than this. */
  const MAX_MIRRORS = 6;
  const VIDEO_FALLBACK_LOAD_TIMEOUT_MS = 5000;

  interface Props {
    /**
     * The author's pubkey. When every listed image has failed and one of them is a
     * file named by its hash, the same file is tried on the author's other file servers.
     */
    mirrorOwner?: string | null;
    /** Thumbnail URL */
    src?: string | null;
    /** Additional image URLs to try when the primary thumbnail fails */
    fallbackImageUrls?: string[] | null;
    /** Exact in-tree fallback video URLs to use when no image thumbnail is available */
    fallbackVideoUrls?: string[] | null;
    /** Legacy placeholder metadata kept for component prop compatibility */
    fallbackTitle?: string | null;
    /** Legacy placeholder metadata kept for component prop compatibility */
    fallbackSubtitle?: string | null;
    /** Legacy placeholder metadata kept for component prop compatibility */
    fallbackSeed?: string | null;
    /** Milliseconds to wait before advancing from a stalled image candidate */
    imageCandidateStallTimeoutMs?: number;
    /** Video duration in seconds */
    duration?: number;
    /** Watch progress percentage (0-100) */
    progress?: number;
    /** Additional classes for the container */
    class?: string;
    /** Legacy placeholder sizing prop kept for compatibility */
    iconSize?: string;
  }

  let {
    src,
    fallbackImageUrls = null,
    fallbackVideoUrls = null,
    imageCandidateStallTimeoutMs = IMAGE_CANDIDATE_STALL_TIMEOUT_MS,
    mirrorOwner = null,
    duration,
    progress = 0,
    class: className = ''
  }: Props = $props();

  let imageError = $state(false);
  let imageLoaded = $state(false);
  let lastMediaKey = $state('');
  let retryCount = $state(0);
  let imageCandidateIndex = $state(0);
  /** The candidates that had all failed when the thumbnail gave up on images. */
  let failedImageUrls: string[] = [];
  let renderedSrc = $state<string | null>(null);
  let videoCandidateIndex = $state(0);
  let videoFailed = $state(false);
  /** The fallback video itself is the preview (its frame could not be copied out). */
  let videoShownAsPoster = $state(false);
  let fallbackVisible = $state(typeof IntersectionObserver === 'undefined');
  let capturedVideoFrameUrl = $state<string | null>(null);
  let containerEl = $state<HTMLDivElement | null>(null);
  let imageEl = $state<HTMLImageElement | null>(null);
  let retryTimer: ReturnType<typeof setTimeout> | null = null;
  let imageLoadTimer: ReturnType<typeof setTimeout> | null = null;
  let videoLoadTimer: ReturnType<typeof setTimeout> | null = null;
  let capturedFrameObjectUrl: string | null = null;
  const loadingStrategy = shouldEagerLoadMediaInNativeChildRuntime() ? 'eager' : 'lazy';

  function canUseVideoFrameFallback(url: string): boolean {
    try {
      const parsed = new URL(url, window.location.href);
      const fileName = parsed.pathname.split('/').filter(Boolean).at(-1) ?? '';
      return !isAudioMediaFileName(fileName);
    } catch {
      const fileName = url.split('?')[0]?.split('/').filter(Boolean).at(-1) ?? '';
      return !isAudioMediaFileName(fileName);
    }
  }
  // Hashtree addresses are held back until the service worker can answer them.
  const loadable = (url: string | null | undefined): url is string => !!url && ($htreeReady || !needsHtree(url));
  const resolvedImageCandidateUrls = $derived.by(() => {
    const urls = new SvelteSet<string>();
    if (loadable(src)) {
      urls.add(src);
    }
    for (const url of fallbackImageUrls ?? []) {
      if (loadable(url)) {
        urls.add(url);
      }
    }
    // Copies on the author's other file servers, once their list has been looked up.
    const servers = mirrorOwner ? $blobServersStore[mirrorOwner] : undefined;
    if (servers) {
      // One request per server: through the image proxy when it is on, else direct.
      for (const mirror of blobMirrorUrls(Array.from(urls).filter(isWebUrl), servers).slice(0, MAX_MIRRORS)) {
        urls.add(webThumbnailCandidateUrls(mirror)?.[0] ?? mirror);
      }
    }
    return Array.from(urls);
  });
  const resolvedFallbackVideoUrls = $derived.by(() => {
    const listed = (fallbackVideoUrls ?? []).filter((url): url is string => loadable(url) && canUseVideoFrameFallback(url));
    // A preview image may exist nowhere else while the video does: its copies on the
    // author's other file servers can still give a frame.
    const servers = mirrorOwner ? $blobServersStore[mirrorOwner] : undefined;
    return servers ? [...listed, ...blobMirrorUrls(listed.filter(isWebUrl), servers).slice(0, MAX_MIRRORS)] : listed;
  });
  const activeFallbackVideoUrl = $derived.by(() =>
    fallbackVisible && !capturedVideoFrameUrl
      ? resolvedFallbackVideoUrls[videoCandidateIndex] ?? null
      : null
  );

  // Reset state when the image or fallback candidates change.
  $effect.pre(() => {
    const nextMediaKey = `${resolvedImageCandidateUrls.join('|')}::${resolvedFallbackVideoUrls.join('|')}`;
    if (nextMediaKey !== lastMediaKey) {
      // Only the fallbacks changed: the image already on screen stays as it is.
      // Its <img> keeps the same src, so no new load event would ever show it again.
      if (imageLoaded && !imageError && renderedSrc !== null && renderedSrc === resolvedImageCandidateUrls[0]) {
        videoCandidateIndex = 0;
        videoFailed = false;
        lastMediaKey = nextMediaKey;
        return;
      }
      // Every image had failed and more were added to the end (copies on the author's
      // other file servers): carry on with the new ones. Starting over would set the
      // same failed address again, which loads nothing and reports nothing.
      const failed = failedImageUrls;
      if (
        imageError && failed.length > 0 && resolvedImageCandidateUrls.length > failed.length
        && failed.every((url, index) => resolvedImageCandidateUrls[index] === url)
      ) {
        clearImageLoadTimer();
        imageError = false;
        imageLoaded = false;
        retryCount = 0;
        imageCandidateIndex = failed.length;
        renderedSrc = resolvedImageCandidateUrls[failed.length] ?? null;
        failedImageUrls = [];
        // The same for the video-frame fallback: go on to the copies just added.
        if (videoFailed && videoCandidateIndex + 1 < resolvedFallbackVideoUrls.length) {
          videoCandidateIndex += 1;
          videoFailed = false;
        }
        lastMediaKey = nextMediaKey;
        return;
      }
      failedImageUrls = [];
      if (retryTimer) {
        clearTimeout(retryTimer);
        retryTimer = null;
      }
      clearImageLoadTimer();
      clearVideoLoadTimer();
      imageError = false;
      imageLoaded = false;
      retryCount = 0;
      imageCandidateIndex = 0;
      renderedSrc = resolvedImageCandidateUrls[0] ?? null;
      videoCandidateIndex = 0;
      videoFailed = false;
      videoShownAsPoster = false;
      clearCapturedVideoFrame();
      lastMediaKey = nextMediaKey;
    }
  });

  $effect(() => {
    const node = containerEl;
    if (!node) return;
    if (typeof IntersectionObserver === 'undefined') {
      fallbackVisible = true;
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        fallbackVisible = !!entry && (entry.isIntersecting || entry.intersectionRatio > 0);
      },
      { rootMargin: '200px' }
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
    };
  });

  onDestroy(() => {
    if (retryTimer) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }
    clearImageLoadTimer();
    clearVideoLoadTimer();
    clearCapturedVideoFrame();
  });

  function clearImageLoadTimer(): void {
    if (imageLoadTimer) {
      clearTimeout(imageLoadTimer);
      imageLoadTimer = null;
    }
  }

  function clearVideoLoadTimer(): void {
    if (videoLoadTimer) {
      clearTimeout(videoLoadTimer);
      videoLoadTimer = null;
    }
  }

  function clearCapturedVideoFrame(): void {
    if (capturedFrameObjectUrl) {
      URL.revokeObjectURL(capturedFrameObjectUrl);
      capturedFrameObjectUrl = null;
    }
    capturedVideoFrameUrl = null;
  }

  function stopVideo(video: HTMLVideoElement | null): void {
    if (!video) return;
    try {
      video.pause();
      video.removeAttribute('src');
      video.load();
    } catch {
      // Ignore teardown failures on detached media elements.
    }
  }

  function advanceImageCandidateOrFail(): void {
    if (retryTimer) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }
    clearImageLoadTimer();
    if (imageCandidateIndex + 1 < resolvedImageCandidateUrls.length) {
      const nextIndex = imageCandidateIndex + 1;
      imageCandidateIndex = nextIndex;
      retryCount = 0;
      imageError = false;
      imageLoaded = false;
      renderedSrc = resolvedImageCandidateUrls[nextIndex] ?? null;
      return;
    }
    imageError = true;
    imageLoaded = false;
    failedImageUrls = [...resolvedImageCandidateUrls];
    // Every listed image failed. One named by its hash may live on the author's other
    // file servers: look their list up; the copies join the candidates when it arrives.
    if (mirrorOwner && hasBlobUrl(resolvedImageCandidateUrls.filter(isWebUrl))) requestBlobServers(mirrorOwner);
  }

  function advanceVideoCandidateOrFail(): void {
    clearVideoLoadTimer();
    videoShownAsPoster = false;
    stopVideo(containerEl?.querySelector('video') ?? null);
    if (videoCandidateIndex + 1 < resolvedFallbackVideoUrls.length) {
      videoCandidateIndex += 1;
      return;
    }
    videoFailed = true;
  }

  $effect(() => {
    if (!renderedSrc || imageError || capturedVideoFrameUrl) {
      clearImageLoadTimer();
      return;
    }

    const candidate = renderedSrc;
    clearImageLoadTimer();
    imageLoadTimer = setTimeout(() => {
      if (renderedSrc !== candidate || imageError || capturedVideoFrameUrl) return;
      advanceImageCandidateOrFail();
    }, imageCandidateStallTimeoutMs);

    return () => {
      clearImageLoadTimer();
    };
  });

  $effect(() => {
    if (!activeFallbackVideoUrl || videoFailed || capturedVideoFrameUrl || videoShownAsPoster) {
      clearVideoLoadTimer();
      return;
    }

    clearVideoLoadTimer();
    const candidate = activeFallbackVideoUrl;
    videoLoadTimer = setTimeout(() => {
      if (activeFallbackVideoUrl !== candidate || videoFailed || capturedVideoFrameUrl) return;
      advanceVideoCandidateOrFail();
    }, VIDEO_FALLBACK_LOAD_TIMEOUT_MS);

    return () => {
      clearVideoLoadTimer();
    };
  });

  $effect(() => {
    const image = imageEl;
    // Also re-checked whenever the loaded flag is cleared: an image that is already
    // complete fires no further load event.
    if (!image || !renderedSrc || imageError || imageLoaded || capturedVideoFrameUrl) {
      return;
    }
    if (image.complete && image.naturalWidth > 0) {
      handleImageLoad();
    }
  });

  function handleImageLoad(): void {
    clearImageLoadTimer();
    imageLoaded = true;
    if (retryTimer) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }
  }

  function handleImageError(event: Event): void {
    clearImageLoadTimer();
    imageLoaded = false;
    const image = event.currentTarget as HTMLImageElement | null;
    const baseSrc = resolvedImageCandidateUrls[imageCandidateIndex] ?? renderedSrc ?? null;
    if (!baseSrc || !isRetryableMediaImageUrl(baseSrc) || retryCount >= MAX_MEDIA_IMAGE_RETRIES) {
      advanceImageCandidateOrFail();
      return;
    }

    const nextRetry = retryCount + 1;
    retryCount = nextRetry;
    const retryUrl = appendMediaImageRetryParam(baseSrc, nextRetry);
    const delayMs = getMediaImageRetryDelayMs(nextRetry);
    retryTimer = setTimeout(() => {
      retryTimer = null;
      if (image && !image.isConnected) return;
      imageError = false;
      imageLoaded = false;
      renderedSrc = retryUrl;
    }, delayMs);
  }

  async function captureVideoFrame(video: HTMLVideoElement): Promise<string | null> {
    if (video.videoWidth <= 0 || video.videoHeight <= 0) return null;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext('2d');
    if (!context) return null;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const blob = await new Promise<Blob | null>((resolve) => {
      canvas.toBlob((value) => resolve(value), 'image/webp', 0.8);
    });

    if (!blob) return null;
    return URL.createObjectURL(blob);
  }

  /** Videos already moved off their opening frame, which is often black. */
  const seekedVideos = new WeakSet<HTMLVideoElement>();
  const PREVIEW_FRAME_SECONDS = 1.5;

  async function handleVideoLoadedData(event: Event): Promise<void> {
    const video = event.currentTarget as HTMLVideoElement | null;
    if (!video) return;

    // Many videos fade in from black: take the preview a moment in, not at the very start.
    if (!seekedVideos.has(video) && Number.isFinite(video.duration) && video.duration > 1) {
      seekedVideos.add(video);
      video.currentTime = Math.min(PREVIEW_FRAME_SECONDS, video.duration / 4);
      return;
    }

    clearVideoLoadTimer();
    // A video on another host that does not allow reading its pixels cannot be copied
    // to an image. Its first frame is on screen already, so the element stays as the preview.
    const frameUrl = await captureVideoFrame(video).catch(() => null);
    if (!frameUrl) {
      if (video.videoWidth > 0) {
        video.pause();
        videoShownAsPoster = true;
      } else {
        stopVideo(video);
        videoFailed = true;
      }
      return;
    }
    stopVideo(video);

    clearCapturedVideoFrame();
    capturedFrameObjectUrl = frameUrl;
    capturedVideoFrameUrl = frameUrl;
    videoFailed = false;
  }

  function handleVideoError(event: Event): void {
    stopVideo(event.currentTarget as HTMLVideoElement | null);
    advanceVideoCandidateOrFail();
  }
</script>

<div bind:this={containerEl} class="relative bg-media-placeholder overflow-hidden {className}">
  {#if renderedSrc && !imageError}
    <img
      bind:this={imageEl}
      src={renderedSrc}
      alt=""
      class="absolute inset-0 w-full h-full object-cover"
      class:opacity-0={!imageLoaded}
      loading={loadingStrategy}
      onload={handleImageLoad}
      onerror={handleImageError}
    />
  {:else if capturedVideoFrameUrl}
    <img
      src={capturedVideoFrameUrl}
      alt=""
      class="absolute inset-0 w-full h-full object-cover"
      loading={loadingStrategy}
    />
  {:else if activeFallbackVideoUrl && !videoFailed}
    <video
      src={activeFallbackVideoUrl}
      muted
      playsinline
      preload="metadata"
      class="absolute inset-0 w-full h-full object-cover pointer-events-none"
      class:opacity-0={!videoShownAsPoster}
      onloadeddata={handleVideoLoadedData}
      onseeked={handleVideoLoadedData}
      onerror={handleVideoError}
    ></video>
  {/if}

  {#if (!renderedSrc || imageError || !imageLoaded) && !capturedVideoFrameUrl && !videoShownAsPoster}
    <div data-testid="media-placeholder" class="absolute inset-0 bg-media-placeholder"></div>
  {/if}

  <!-- Duration label - positioned above progress bar -->
  {#if duration}
    <div class="absolute bottom-2 right-1 bg-black/80 text-white text-[10px] px-1 rounded z-10">
      {formatDuration(duration)}
    </div>
  {/if}

  <!-- Watch progress bar -->
  {#if progress > 0}
    <div class="absolute bottom-0 left-0 right-0 h-1 bg-white/30">
      <div class="h-full bg-danger" style="width: {progress}%"></div>
    </div>
  {/if}
</div>
