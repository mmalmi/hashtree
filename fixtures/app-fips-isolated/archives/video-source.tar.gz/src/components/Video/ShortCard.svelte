<script lang="ts">
  /**
   * ShortCard - portrait card for a short, linking to the shorts viewer
   */
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import VideoThumbnail from './VideoThumbnail.svelte';
  import type { VideoItem } from './types';

  interface Props {
    video: VideoItem;
    class?: string;
  }

  let { video, class: className = '' }: Props = $props();

  let thumbnails = $derived(webThumbnailCandidateUrls(video.thumbnailUrl, 360, 640));
</script>

<a href={video.href} class="block min-w-0 no-underline {className}">
  <VideoThumbnail
    src={thumbnails?.[0] ?? video.thumbnailUrl}
    fallbackImageUrls={thumbnails?.slice(1) ?? null}
    fallbackVideoUrls={video.videoUrls?.slice(0, 1) ?? null}
    duration={video.duration}
    mirrorOwner={video.ownerPubkey}
    class="aspect-[9/16] rounded-lg"
  />
  <h3 class="mt-2 h-10 text-sm leading-5 font-medium text-text-1 line-clamp-2 break-words">{video.title}</h3>
</a>
