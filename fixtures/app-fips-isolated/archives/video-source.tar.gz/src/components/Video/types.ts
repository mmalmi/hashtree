/**
 * Video metadata stored in metadata.json within video tree
 */
export interface VideoMetadata {
  title: string;
  description?: string;
  duration?: number; // seconds
  uploadedAt?: number; // timestamp ms
  mimeType?: string;
  width?: number;
  height?: number;
  tags?: string[];
}

/**
 * Video item for display in grids/lists
 */
export interface VideoItem {
  key: string;
  title: string;
  description?: string;
  duration?: number;
  ownerPubkey: string | null;
  ownerNpub: string | null;
  treeName: string;
  /** For playlist videos: the video folder name within the playlist tree */
  videoId?: string;
  /** Root CID for playlist detection */
  rootCid?: import('@hashtree/core').CID;
  /** Preferred thumbnail URL when already resolved */
  thumbnailUrl?: string;
  /** Exact in-tree video file path when known */
  videoPath?: string;
  visibility?: string;
  href: string;
  timestamp?: number;
  /** Hashtags from the video event */
  tags?: string[];
  /** Playable web URLs, best first, for a video hosted outside hashtree */
  videoUrls?: string[];
  /** Short-form (vertical clip) video */
  short?: boolean;
  /** The author marked it with a content warning */
  sensitive?: boolean;
  /** Set when the entry stands for a whole playlist */
  videoCount?: number;
  /** Pubkey of user who reacted/commented (for social feed items) */
  reactorPubkey?: string;
}
