<script lang="ts">
  /**
   * VideoSetCard - a playlist published as a video set (NIP-51), by any app
   */
  import { toAppThumbnailUrl } from '../../lib/videoEvent';
  import type { VideoSet } from '../../lib/videoSet';
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import VideoThumbnail from './VideoThumbnail.svelte';
  import type { VideoItem } from './types';

  interface Props {
    set: VideoSet;
    /** A member video to borrow a cover from when the set names none. */
    cover?: VideoItem | null;
  }

  let { set, cover = null }: Props = $props();

  let coverUrl = $derived(set.image ?? cover?.thumbnailUrl);
  let thumbnails = $derived(webThumbnailCandidateUrls(coverUrl, 640, 360));
  let count = $derived(set.refs.length);
</script>

<a href={set.href} class="relative block no-underline group isolate" data-testid="video-set-card">
  <div class="relative aspect-video rounded-lg z-10">
    <div class="absolute -right-1 -top-1 w-full h-full bg-surface-3 rounded-lg"></div>
    <div class="absolute -right-0.5 -top-0.5 w-full h-full bg-surface-2 rounded-lg"></div>
    <div class="absolute inset-0 bg-surface-2 rounded-lg overflow-hidden">
      <VideoThumbnail
        src={thumbnails?.[0] ?? toAppThumbnailUrl(coverUrl) ?? null}
        fallbackImageUrls={thumbnails?.slice(1) ?? null}
        fallbackVideoUrls={cover?.videoUrls?.slice(0, 1) ?? null}
        fallbackTitle={set.title}
        fallbackSubtitle={`${count} video${count === 1 ? '' : 's'}`}
        fallbackSeed={set.key}
        mirrorOwner={cover?.ownerPubkey ?? set.ownerPubkey}
        class="w-full h-full"
      />
      <div class="absolute right-0 top-0 h-full w-24 bg-black/80 flex flex-col items-center justify-center">
        <span class="text-white text-lg font-medium">{count}</span>
        <span class="i-lucide-list-video text-white text-xl mt-1"></span>
      </div>
      <div class="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors"></div>
    </div>
  </div>
  <div class="pt-2 pb-1 relative z-10">
    <h3 class="text-base font-medium text-text-1 line-clamp-2 leading-tight m-0">{set.title}</h3>
    <div class="text-sm text-text-3 mt-0.5 opacity-70">{count} video{count === 1 ? '' : 's'}</div>
  </div>
</a>
