<script lang="ts">
  /**
   * FeedSidebar - "Up next" beside a video
   * More from the same author and videos on the same topic come first, then the
   * ranked feed. Watched videos go last. Once listed, entries keep their place.
   */
  import { onMount, untrack } from 'svelte';
  import { feedStore, fetchFeedVideos } from '../../stores/feedStore';
  import { toHex } from '@hashtree/core';
  import { formatTimeAgo } from '../../utils/format';
  import { Name } from '../User';
  import { getStableThumbnailCandidateUrls, getStableVideoCandidateUrls, onHtreePrefixReady } from '../../lib/mediaUrl';
  import { logHtreeDebug } from '../../lib/htreeDebug';
  import { nostrStore } from '../../nostr';
  import { recentsStore, positionCacheVersion, getVideoPosition } from '../../stores/recents';
  import VideoThumbnail from './VideoThumbnail.svelte';
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import { SvelteMap } from 'svelte/reactivity';
  import { orderRelatedVideos } from '../../lib/videoRanking';
  import { reconcileFeed } from '../../lib/feedPresentation';
  import { videoEventsStore } from '../../stores/videoEvents';


  interface Props {
    /** Current video href to exclude from feed */
    currentHref?: string;
  }

  let { currentHref }: Props = $props();

  let feedVideos = $derived($feedStore);
  let pubkey = $derived($nostrStore.pubkey);
  let htreePrefixVersion = $state(0);
  onHtreePrefixReady(() => {
    htreePrefixVersion += 1;
  });

  const ensureFeed = () => {
    if ($feedStore.length === 0) {
      logHtreeDebug('feedSidebar:fetch', { pubkey });
      fetchFeedVideos();
    }
  };

  // Fetch feed videos on mount (fetch handles bootstrap fallback if user not ready).
  onMount(() => {
    ensureFeed();
  });

  $effect(() => {
    if (pubkey) {
      ensureFeed();
    }
  });

  const LIST_LIMIT = 30;
  /** While the first results stream in, the list may still re-order itself. */
  const SETTLE_MS = 3000;

  function videoPath(video: { ownerNpub: string | null; treeName: string | null; videoId?: string }): string | null {
    if (!video.ownerNpub || !video.treeName) return null;
    return video.videoId
      ? `/${video.ownerNpub}/${video.treeName}/${video.videoId}`
      : `/${video.ownerNpub}/${video.treeName}`;
  }

  function isWatched(video: typeof feedVideos[0]): boolean {
    const path = videoPath(video);
    if (!path || !video.duration) return false;
    return getVideoPosition(path) / video.duration >= 0.95;
  }

  // What is playing: a playlist page is addressed by its tree, its items one level below.
  let current = $derived(currentHref
    ? $videoEventsStore.find(video => video.href === currentHref || video.href.startsWith(`${currentHref}/`)) ?? null
    : null);

  let relatedVideos = $derived(orderRelatedVideos(
    current,
    feedVideos.filter(video => video.href !== currentHref),
    isWatched,
  ));

  // Entries keep their place once listed; later arrivals only join below.
  let shownHrefs = $state<string[]>([]);
  let settleUntil = 0;
  $effect(() => {
    const latest = relatedVideos.map(video => video.href);
    untrack(() => {
      if (latest.length === 0) return;
      settleUntil ||= Date.now() + SETTLE_MS;
      const next = reconcileFeed(Date.now() < settleUntil ? [] : shownHrefs, latest, LIST_LIMIT).shown;
      if (next.length !== shownHrefs.length || next.some((href, index) => href !== shownHrefs[index])) shownHrefs = next;
    });
  });

  let displayVideos = $derived.by(() => {
    const byHref = new Map(relatedVideos.map(video => [video.href, video]));
    return shownHrefs.flatMap(href => byHref.get(href) ?? []);
  });

  // Build thumbnail URL for a video
  function buildThumbnailUrls(video: typeof feedVideos[0]): string[] {
    void htreePrefixVersion;
    // A video hosted outside hashtree has an ordinary web thumbnail.
    const webThumbnails = webThumbnailCandidateUrls(video.thumbnailUrl, 336, 189);
    if (webThumbnails) return webThumbnails;
    const hashPrefix = video.rootCid?.hash ? toHex(video.rootCid.hash).slice(0, 8) : undefined;
    return getStableThumbnailCandidateUrls({
      thumbnailUrl: video.thumbnailUrl,
      rootCid: video.rootCid,
      npub: video.ownerNpub,
      treeName: video.treeName,
      videoId: video.videoId || undefined,
      hashPrefix,
      preferAliasFallback: !video.thumbnailUrl,
      playlistRoot: (video.videoCount ?? 0) > 0,
    });
  }

  function buildFallbackVideoUrls(video: typeof feedVideos[0]): string[] {
    void htreePrefixVersion;
    // A web-hosted video without a preview image shows its own first frame.
    if (video.videoUrls?.length) return video.videoUrls.slice(0, 1);
    return getStableVideoCandidateUrls({
      rootCid: video.rootCid,
      npub: video.ownerNpub,
      treeName: video.treeName,
      videoId: video.videoId || undefined,
      videoPath: video.videoPath,
      includeCommonFallbacks: false,
    });
  }

  // Get recents to look up duration (feedStore doesn't have it)
  let recents = $derived($recentsStore);

  // Build a map of path -> duration from recents
  let recentsDurationMap = $derived.by(() => {
    const map = new SvelteMap<string, number>();
    for (const r of recents) {
      if (r.duration && r.duration > 0) {
        map.set(r.path, r.duration);
      }
    }
    return map;
  });

  // Helper to get duration for a video (from feedStore or recents)
  function getVideoDuration(video: typeof feedVideos[0]): number | undefined {
    if (video.duration) return video.duration;
    if (!video.ownerNpub || !video.treeName) return undefined;
    const path = video.videoId
      ? `/${video.ownerNpub}/${video.treeName}/${video.videoId}`
      : `/${video.ownerNpub}/${video.treeName}`;
    return recentsDurationMap.get(path);
  }

  // Compute progress for all videos reactively
  let videoProgress = $derived.by(() => {
    // Subscribe to position cache version for reactivity
    void $positionCacheVersion;
    const progressMap = new SvelteMap<string, number>();
    for (const video of displayVideos) {
      if (!video.ownerNpub || !video.treeName) continue;
      const path = video.videoId
        ? `/${video.ownerNpub}/${video.treeName}/${video.videoId}`
        : `/${video.ownerNpub}/${video.treeName}`;

      // Get duration from feedStore first, then fall back to recents
      const duration = video.duration || recentsDurationMap.get(path);
      if (!duration || duration <= 0) continue;

      const position = getVideoPosition(path);
      if (position <= 0) continue;
      const percent = Math.min((position / duration) * 100, 100);
      if (percent >= 1 && percent < 95) {
        progressMap.set(video.href, percent);
      }
    }
    return progressMap;
  });
</script>

<div class="px-4">
  {#if displayVideos.length > 0}
    <div class="space-y-2">
      {#each displayVideos as video (video.href)}
        {@const thumbnailUrls = buildThumbnailUrls(video)}
        {@const fallbackVideoUrls = buildFallbackVideoUrls(video)}
        {@const imageCandidateStallTimeoutMs = video.thumbnailUrl ? 8000 : 2500}
        {@const duration = getVideoDuration(video)}
        {@const progress = videoProgress.get(video.href) ?? 0}
        <a
          href={video.href}
          class="flex gap-2 group no-underline"
        >
          <!-- Thumbnail -->
          <VideoThumbnail
            src={thumbnailUrls[0] ?? null}
            fallbackImageUrls={thumbnailUrls.slice(1)}
            {fallbackVideoUrls}
            mirrorOwner={video.ownerPubkey}
            fallbackTitle={video.title}
            fallbackSeed={`${video.ownerNpub ?? ''}/${video.treeName ?? video.title}`}
            {imageCandidateStallTimeoutMs}
            {duration}
            {progress}
            class="w-42 aspect-video shrink-0 rounded"
            iconSize="text-sm"
          />

          <!-- Info -->
          <div class="flex-1 min-w-0">
            <p class="text-sm text-text-1 line-clamp-2">
              {video.title}
            </p>
            {#if video.ownerPubkey}
              <span class="text-xs text-text-3 truncate block mt-0.5">
                <Name pubkey={video.ownerPubkey} />
              </span>
            {/if}
            {#if video.videoCount}
              <span class="text-xs text-text-3 flex items-center gap-1">
                <span class="i-lucide-list-video"></span>
                {video.videoCount} videos
              </span>
            {:else if video.timestamp}
              <span class="text-xs text-text-3 block">
                {formatTimeAgo(video.timestamp)}
              </span>
            {/if}
          </div>
        </a>
      {/each}
    </div>
  {/if}
</div>
