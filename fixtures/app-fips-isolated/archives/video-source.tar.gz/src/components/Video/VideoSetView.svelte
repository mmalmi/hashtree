<script lang="ts">
  /**
   * VideoSetView - a playlist published as a video set (NIP-51 kind 30005)
   * Lists the set's videos in the author's order. The set and whichever of its
   * videos are not loaded yet are asked for once; the page fills in as they arrive.
   */
  import type { Event, Filter } from 'nostr-tools';
  import { nostr } from '../../nostr';
  import { queryConfiguredRelaysDirectly } from '../../nostr/directQuery';
  import { ALL_VIDEO_EVENT_KINDS } from '../../lib/videoEvent';
  import { VIDEO_SET_KIND, parseVideoSetRef } from '../../lib/videoSet';
  import { findVideosByRefs, ingestVideoEvent, videoEventsStore } from '../../stores/videoEvents';
  import { ingestVideoSetEvent, videoSetsStore } from '../../stores/videoSets';
  import { Avatar, FollowButton, Name } from '../User';
  import ShareButton from '../ShareButton.svelte';
  import ShortCard from './ShortCard.svelte';
  import VideoCard from './VideoCard.svelte';

  interface Props {
    /** `naddr1...` naming the set */
    setRef?: string;
  }

  let { setRef }: Props = $props();

  const LOOKUP_MS = 8000;
  /** Relays accept only so many filters in a request. */
  const MAX_MEMBER_FILTERS = 12;

  let target = $derived(parseVideoSetRef(setRef));
  let set = $derived(target ? $videoSetsStore.find((entry) => entry.key === target.key) ?? null : null);
  let known = $derived(!!set);

  // A direct link: ask the relays for the set.
  $effect(() => {
    if (!target || known) return;
    const filter = { kinds: [VIDEO_SET_KIND], authors: [target.pubkey], '#d': [target.dTag] };
    const subscription = nostr.subscribe(filter);
    subscription.on('event', (event: Event) => { ingestVideoSetEvent(event); });
    const stopDirect = queryConfiguredRelaysDirectly([filter], (event) => { ingestVideoSetEvent(event); }, LOOKUP_MS);
    const timer = setTimeout(() => subscription.stop(), LOOKUP_MS);
    return () => {
      clearTimeout(timer);
      subscription.stop();
      stopDirect();
    };
  });

  let lookupExpired = $state(false);
  $effect(() => {
    if (known) return;
    const timer = setTimeout(() => { lookupExpired = true; }, LOOKUP_MS);
    return () => clearTimeout(timer);
  });

  let videos = $derived.by(() => {
    void $videoEventsStore;
    return set ? findVideosByRefs(set.refs) : [];
  });
  let allShorts = $derived(videos.length > 0 && videos.every((video) => video.short));

  // The set's videos that are not loaded yet, asked for once per version of the set.
  let setVersion = $derived(set ? `${set.key}:${set.updatedAt}` : null);
  $effect(() => {
    if (!setVersion || !set) return;
    const loaded = new Set(findVideosByRefs(set.refs).map((video) => video.key));
    if (loaded.size === set.refs.length) return;

    const ids: string[] = [];
    const addressed = new Map<string, { kind: number; author: string; dTags: string[] }>();
    for (const ref of set.refs) {
      if (!ref.includes(':')) {
        ids.push(ref);
        continue;
      }
      const [kind, author, ...rest] = ref.split(':');
      if (!ALL_VIDEO_EVENT_KINDS.includes(Number(kind))) continue;
      const group = addressed.get(`${kind}:${author}`) ?? { kind: Number(kind), author, dTags: [] };
      group.dTags.push(rest.join(':'));
      addressed.set(`${kind}:${author}`, group);
    }
    const filters: Filter[] = [
      ...(ids.length > 0 ? [{ ids: ids.slice(0, 200) }] : []),
      ...[...addressed.values()].slice(0, MAX_MEMBER_FILTERS).map((group) => (
        { kinds: [group.kind], authors: [group.author], '#d': group.dTags.slice(0, 200) }
      )),
    ];
    if (filters.length === 0) return;
    const subscription = nostr.subscribe(filters);
    subscription.on('event', (event: Event) => { ingestVideoEvent(event); });
    const stopDirect = queryConfiguredRelaysDirectly(filters, (event) => { ingestVideoEvent(event); }, LOOKUP_MS);
    const timer = setTimeout(() => subscription.stop(), LOOKUP_MS);
    return () => {
      clearTimeout(timer);
      subscription.stop();
      stopDirect();
    };
  });
</script>

<div class="flex-1 overflow-y-auto">
  <div class="max-w-7xl mx-auto px-4 py-6" data-testid="video-set">
    {#if !target}
      <p class="text-text-3 text-center py-12">This link does not name a playlist.</p>
    {:else if set}
      <div class="mb-6">
        <h1 class="text-2xl font-semibold text-text-1 m-0 break-words">{set.title}</h1>
        <div class="flex items-center gap-3 mt-3 flex-wrap">
          <a href={`#/${set.ownerNpub}`} class="flex items-center gap-2 min-w-0 no-underline text-text-1">
            <Avatar pubkey={set.ownerPubkey} size={32} showBadge />
            <span class="text-sm font-medium truncate"><Name pubkey={set.ownerPubkey} /></span>
          </a>
          <FollowButton pubkey={set.ownerPubkey} />
          <ShareButton url={window.location.href} />
          <span class="text-sm text-text-3">{set.refs.length} video{set.refs.length === 1 ? '' : 's'}</span>
        </div>
        {#if set.description}
          <p class="text-sm text-text-2 whitespace-pre-wrap break-words mt-3 mb-0 max-w-3xl">{set.description}</p>
        {/if}
      </div>

      {#if videos.length === 0}
        <p class="text-text-3 text-center py-12">Loading videos...</p>
      {:else if allShorts}
        <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
          {#each videos as video (video.key)}
            <ShortCard {video} />
          {/each}
        </div>
      {:else}
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {#each videos as video (video.key)}
            <VideoCard
              href={video.href}
              title={video.title}
              duration={video.duration}
              ownerPubkey={video.ownerPubkey}
              ownerNpub={video.ownerNpub}
              treeName={video.treeName || null}
              videoId={video.videoId}
              thumbnailUrl={video.thumbnailUrl}
              videoPath={video.videoPath}
              videoUrls={video.videoUrls}
              timestamp={video.timestamp}
              noHover
            />
          {/each}
        </div>
      {/if}
    {:else if lookupExpired}
      <p class="text-text-3 text-center py-12">Playlist not found.</p>
    {/if}
  </div>
</div>
