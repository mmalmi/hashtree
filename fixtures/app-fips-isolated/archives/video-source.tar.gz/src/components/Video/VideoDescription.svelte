<script lang="ts">
  /**
   * VideoDescription - a video's description: links, pictures, mentions and hashtags
   * made useful, and timestamps like 00:00, 1:30, 1:30:00 that seek the video
   */
  import { getQueryParams } from '../../lib/router.svelte';
  import { parseRichText, truncateRichText } from '../../lib/richText';
  import RichTextSegments from '../RichTextSegments.svelte';

  interface Props {
    text: string;
    maxLines?: number;
    maxChars?: number;
    class?: string;
    style?: string;
    /** Optional timestamp to display at the top (formatted string like "2 days ago") */
    timestamp?: string;
  }

  let { text, maxLines = 4, maxChars = 400, class: className = '', style = '', timestamp }: Props = $props();

  /** Handle timestamp click - update URL with ?t= param */
  function handleTimestampClick(seconds: number) {
    const hash = window.location.hash;
    const qIdx = hash.indexOf('?');
    const path = qIdx !== -1 ? hash.slice(0, qIdx) : hash;
    const params = getQueryParams();
    params.set('t', seconds.toString());
    window.location.hash = `${path}?${params.toString()}`;
  }

  let expanded = $state(false);

  let cut = $derived(truncateRichText(text, maxLines, maxChars));
  let needsTruncation = $derived(cut.truncated);
  let isTruncated = $derived(!expanded && needsTruncation);
  let segments = $derived(parseRichText(expanded ? text : cut.text, { timestamps: true }));
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div
  class="{className} rounded-lg p-3 {isTruncated ? 'cursor-pointer transition-colors duration-100' : ''}"
  {style}
  onmouseenter={(e) => { if (isTruncated) e.currentTarget.style.backgroundColor = 'var(--desc-hover-color, rgba(255,255,255,0.15))'; }}
  onmouseleave={(e) => { if (isTruncated) e.currentTarget.style.backgroundColor = ''; }}
  onclick={() => { if (isTruncated) expanded = true; }}
>
  {#if timestamp}
    <p class="font-semibold text-text-1 mb-1">{timestamp}</p>
  {/if}
  <p class="whitespace-pre-wrap break-words m-0"><RichTextSegments {segments} onTimestamp={handleTimestampClick} />{#if isTruncated}...{/if}</p>
  {#if expanded && needsTruncation}
    <button
      onclick={(e) => { e.stopPropagation(); expanded = false; }}
      class="text-accent hover:underline text-sm mt-1"
    >
      Show less
    </button>
  {/if}
</div>
