<script lang="ts" module>
  // The viewer's sound choice holds from one short to the next, and across visits to the viewer.
  let preferMuted = false;

  // Repeat each short (the default, as on other short-video apps) or play through to the next one.
  const AUTO_NEXT_KEY = 'video-shorts-auto-next';
  function readAutoNext(): boolean {
    try {
      return localStorage.getItem(AUTO_NEXT_KEY) === '1';
    } catch {
      return false;
    }
  }
</script>

<script lang="ts">
  /**
   * ShortsView - full-height viewer for short vertical clips
   * One short fills the screen and plays in a loop; scrolling, swiping or the
   * arrow keys move to the next, and so does the end of the clip when the viewer
   * turned "play next automatically" on. Only the short on screen has a player,
   * and only it asks the relays for its likes and comments.
   */
  import { onMount, untrack } from 'svelte';
  import { nostr } from '../../nostr';
  import { queryConfiguredRelaysDirectly } from '../../nostr/directQuery';
  import { blobMirrorUrls, hasBlobUrl, parseExternalVideoRef } from '../../lib/videoEvent';
  import { blobServersStore, requestBlobServers } from '../../stores/blobServers';
  import { reconcileFeed, unseenFirst } from '../../lib/feedPresentation';
  import { markShortSeen, seenShortsSnapshot } from '../../stores/seenShorts';
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import { fetchFeedVideos } from '../../stores/feedStore';
  import { formatTimeAgo } from '../../utils/format';
  import { videoFeedStore } from '../../stores/videoFeed';
  import { getVideoItem, ingestVideoEvent, videoEventsStore } from '../../stores/videoEvents';
  import { NO_ENGAGEMENT, watchVideoEngagement, type EventEngagementWatch } from '../../stores/eventEngagement';
  import EventComments from './EventComments.svelte';
  import RichText from '../RichText.svelte';
  import { Avatar, FollowButton, Name } from '../User';
  import ShareButton from '../ShareButton.svelte';
  import type { VideoItem } from './types';

  interface Props {
    /** `naddr1...`, `note1...` or `nevent1...` of the short to start with; the best-ranked one when absent */
    eventRef?: string;
  }

  let { eventRef }: Props = $props();

  /** Shorts kept ahead of the one on screen, so the next is always there to scroll to. */
  const LOOKAHEAD = 5;
  /** How long a directly linked short may take to arrive before the list starts without it. */
  const START_GRACE_MS = 3000;
  /** A short counts as seen once it has been on screen this long. */
  const SEEN_AFTER_MS = 1500;
  /** A short must stay on screen this long before its likes and comments are asked for. */
  const ENGAGEMENT_DELAY_MS = 400;

  // Read once: the address bar follows the short on screen without re-opening the viewer.
  const start = untrack(() => parseExternalVideoRef(eventRef));

  onMount(fetchFeedVideos);

  let startVideo = $derived.by(() => {
    void $videoEventsStore;
    return start ? getVideoItem(start.key) ?? null : null;
  });
  let startIndexed = $derived(!!startVideo);

  // A direct link to a short that is not indexed yet: ask the relays for it.
  $effect(() => {
    if (!start || startIndexed) return;
    const filter = start.id
      ? { ids: [start.id] }
      : { kinds: [start.kind!], authors: [start.pubkey!], '#d': [start.dTag!] };
    const subscription = nostr.subscribe(filter);
    subscription.on('event', (event) => { ingestVideoEvent(event); });
    // Straight from the relays as well, so a shared link does not queue behind the worker's startup.
    const stopDirect = queryConfiguredRelaysDirectly([filter], (event) => { ingestVideoEvent(event); }, 8000);
    return () => {
      subscription.stop();
      stopDirect();
    };
  });

  let graceOver = $state(!start);
  onMount(() => {
    const timer = setTimeout(() => { graceOver = true; }, START_GRACE_MS);
    return () => clearTimeout(timer);
  });

  // The list: the short that was opened, then the ranked shorts. It only ever grows at the end.
  let keys = $state<string[]>([]);
  let activeIndex = $state(0);

  // Shorts played on earlier visits come after the ones new to this viewer.
  const seenBefore = seenShortsSnapshot();

  $effect(() => {
    const ranked = unseenFirst($videoFeedStore.shorts, (video) => seenBefore.has(video.key)).map((video) => video.key);
    const ready = startIndexed || graceOver;
    const limit = activeIndex + 1 + LOOKAHEAD;
    untrack(() => {
      if (!ready) return;
      const first = startVideo && (keys.length === 0 || keys[0] === startVideo.key) ? [startVideo.key] : [];
      const latest = [...first, ...ranked.filter((key) => key !== first[0])];
      const next = reconcileFeed(keys, latest, limit).shown;
      if (next.length !== keys.length || next.some((key, index) => key !== keys[index])) keys = next;
    });
  });

  let shorts = $derived.by(() => {
    const byKey = new Map($videoEventsStore.map((video) => [video.key, video]));
    return keys.map((key) => byKey.get(key) ?? getVideoItem(key)).filter((video): video is VideoItem => !!video);
  });
  let active = $derived(shorts[activeIndex] ?? null);

  // Fill the screen below the app header.
  let scroller = $state<HTMLDivElement | null>(null);
  let viewerHeight = $state(0);
  onMount(() => {
    const measure = () => {
      const header = document.querySelector('header');
      viewerHeight = window.innerHeight - (header?.getBoundingClientRect().height ?? 0);
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  });

  function handleScroll(): void {
    if (!scroller || viewerHeight <= 0) return;
    const index = Math.round(scroller.scrollTop / viewerHeight);
    if (index !== activeIndex && index >= 0 && index < shorts.length) activeIndex = index;
  }

  function go(delta: number): void {
    const index = Math.max(0, Math.min(shorts.length - 1, activeIndex + delta));
    scroller?.scrollTo({ top: index * viewerHeight, behavior: 'smooth' });
  }

  // Playback of the short on screen.
  let player = $state<HTMLVideoElement | null>(null);
  let muted = $state(preferMuted);
  let paused = $state(false);
  let progress = $state(0);
  let sourceIndex = $state(0);
  let warningAcceptedFor = $state<string | null>(null);

  let activeKey = $derived(active?.key ?? null);
  // A file named by its hash may live on the author's other file servers too. When the
  // copies the event lists have all failed, the author's server list is looked up and
  // those servers are tried.
  $effect(() => {
    const listed = active?.videoUrls ?? [];
    if (active?.ownerPubkey && hasBlobUrl(listed) && sourceIndex >= listed.length) requestBlobServers(active.ownerPubkey);
  });
  let sources = $derived.by(() => {
    const listed = active?.videoUrls ?? [];
    const servers = active?.ownerPubkey ? $blobServersStore[active.ownerPubkey] : undefined;
    return servers ? [...listed, ...blobMirrorUrls(listed, servers)] : listed;
  });
  let source = $derived(sources[sourceIndex] ?? null);

  // A file server that never answers would hold the player forever: after a while
  // the next copy is tried, when there is one.
  const SOURCE_TIMEOUT_MS = 8000;
  let loadedSource = $state<string | null>(null);
  $effect(() => {
    const current = source;
    if (!current || sourceIndex >= sources.length - 1) return;
    const timer = setTimeout(() => {
      if (loadedSource !== current) sourceIndex += 1;
    }, SOURCE_TIMEOUT_MS);
    return () => clearTimeout(timer);
  });
  let showWarning = $derived(!!active?.sensitive && warningAcceptedFor !== activeKey);

  $effect(() => {
    void activeKey;
    untrack(() => {
      sourceIndex = 0;
      progress = 0;
      paused = false;
    });
  });

  // The address bar names the short on screen, so sharing and reloading land on it.
  $effect(() => {
    const href = active?.href;
    if (href && window.location.hash !== href) history.replaceState(null, '', href);
  });

  $effect(() => {
    const video = player;
    if (!video || !source) return;
    video.muted = untrack(() => muted);
    video.play().catch(() => {
      // Browsers refuse sound before the viewer has touched the page: start silent instead.
      if (video.muted) return;
      muted = true;
      video.muted = true;
      video.play().catch(() => { paused = true; });
    });
  });

  function toggleMuted(): void {
    muted = !muted;
    preferMuted = muted;
    if (player) player.muted = muted;
  }

  $effect(() => {
    const key = activeKey;
    if (!key) return;
    const timer = setTimeout(() => markShortSeen(key), SEEN_AFTER_MS);
    return () => clearTimeout(timer);
  });

  // The caption opens to the full title and description when tapped.
  let captionOpen = $state(false);
  $effect(() => {
    void activeKey;
    untrack(() => {
      captionOpen = false;
      // Beside the clip the comments follow along to the next short; as a sheet
      // over it they would cover the short just scrolled to, so they close.
      if (!window.matchMedia('(min-width: 1024px)').matches) commentsOpen = false;
    });
  });

  // Likes and comments of the short on screen. Flicking past a short asks the relays nothing.
  let engagement = $state(NO_ENGAGEMENT);
  let engagementWatch = $state<EventEngagementWatch | null>(null);
  let commentsOpen = $state(false);

  $effect(() => {
    const key = activeKey;
    if (!key) return;
    let watch: EventEngagementWatch | null = null;
    let unsubscribe = () => {};
    const timer = setTimeout(() => {
      watch = watchVideoEngagement(key);
      if (!watch) return;
      engagementWatch = watch;
      unsubscribe = watch.subscribe((value) => { engagement = value; });
    }, ENGAGEMENT_DELAY_MS);
    return () => {
      clearTimeout(timer);
      unsubscribe();
      watch?.stop();
      engagementWatch = null;
      engagement = NO_ENGAGEMENT;
    };
  });

  function toggleLike(): void {
    void engagementWatch?.toggleLike().catch((error) => { console.error('Failed to like:', error); });
  }

  async function postComment(text: string, parentId?: string): Promise<void> {
    await engagementWatch?.comment(text, parentId);
  }

  let autoNext = $state(readAutoNext());

  function toggleAutoNext(): void {
    autoNext = !autoNext;
    try {
      localStorage.setItem(AUTO_NEXT_KEY, autoNext ? '1' : '0');
    } catch {
      // The choice still holds for this visit.
    }
  }

  /** Only reached with "play next" on: a looping player never ends. */
  function handleEnded(video: HTMLVideoElement): void {
    if (activeIndex < shorts.length - 1) {
      go(1);
      return;
    }
    // Nothing further to show: start this one again.
    video.currentTime = 0;
    void video.play().catch(() => { paused = true; });
  }

  function togglePlay(): void {
    if (!player) return;
    if (player.paused) {
      void player.play().catch(() => {});
      paused = false;
    } else {
      player.pause();
      paused = true;
    }
  }

  function handleKeydown(event: KeyboardEvent): void {
    const target = event.target as HTMLElement | null;
    if (event.key === 'Escape') {
      // Escape closes what is on top: the comments, else the viewer itself.
      if (commentsOpen) commentsOpen = false;
      else leaveViewer();
      return;
    }
    if (target?.closest('input, textarea, [contenteditable="true"]')) return;
    if (event.key === 'ArrowDown' || event.key === 'j') {
      event.preventDefault();
      go(1);
    } else if (event.key === 'ArrowUp' || event.key === 'k') {
      event.preventDefault();
      go(-1);
    } else if (event.key === ' ') {
      event.preventDefault();
      togglePlay();
    } else if (event.key === 'm') {
      toggleMuted();
    }
  }

  /** Back to where the viewer was opened from, or to the front page for a direct link. */
  function leaveViewer(): void {
    if (window.history.length > 1) window.history.back();
    else window.location.hash = '#/';
  }

  function shareUrl(video: VideoItem): string {
    return `${window.location.origin}${window.location.pathname}${video.href}`;
  }

  let waitingForStart = $derived(shorts.length === 0 && !graceOver);
</script>

<svelte:window onkeydown={handleKeydown} />

<div
  bind:this={scroller}
  class="shorts-scroller w-full overflow-y-auto overscroll-contain bg-surface-0"
  style:height={`${viewerHeight}px`}
  onscroll={handleScroll}
  data-testid="shorts-viewer"
>
  {#each shorts as video, index (video.key)}
    {@const isActive = index === activeIndex}
    {@const poster = webThumbnailCandidateUrls(video.thumbnailUrl, 540, 960)?.[0]}
    <section class="shorts-slot relative flex items-center justify-center px-0 sm:px-4 py-0 sm:py-3" style:height={`${viewerHeight}px`}>
      <div class="flex items-end gap-3 h-full max-w-full">
        <div
          class="relative h-full aspect-[9/16] max-w-full bg-black sm:rounded-xl overflow-hidden"
          data-testid={isActive ? 'short-active' : undefined}
        >
          {#if poster}
            <img src={poster} alt="" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />
          {/if}

          {#if isActive && showWarning}
            <div class="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center bg-black/80">
              <p class="text-white/90">The author marked this video with a content warning.</p>
              <button class="btn-primary px-4 py-2" onclick={() => { warningAcceptedFor = video.key; }}>Show video</button>
            </div>
          {:else if isActive && source}
            {#key source}
              <!-- svelte-ignore a11y_media_has_caption -->
              <video
                bind:this={player}
                class="absolute inset-0 w-full h-full object-contain bg-black"
                src={source}
                {poster}
                loop={!autoNext}
                playsinline
                onerror={() => { sourceIndex += 1; }}
                onloadedmetadata={() => { loadedSource = source; }}
                onended={(event) => handleEnded(event.currentTarget)}
                onplaying={() => { paused = false; }}
                ontimeupdate={(event) => {
                  const element = event.currentTarget;
                  progress = element.duration > 0 ? (element.currentTime / element.duration) * 100 : 0;
                }}
              ></video>
            {/key}
            <button
              class="absolute inset-0 w-full h-full bg-transparent b-0 cursor-pointer flex items-center justify-center"
              aria-label={paused ? 'Play' : 'Pause'}
              onclick={togglePlay}
            >
              {#if paused}
                <span class="i-lucide-play text-white text-5xl drop-shadow-lg"></span>
              {/if}
            </button>
          {:else if isActive}
            <div class="absolute inset-0 flex items-center justify-center px-6 text-center text-white/70">
              This video could not be played.
            </div>
          {/if}

          <!-- Title and author -->
          <div class="absolute inset-x-0 bottom-0 p-3 pr-14 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white pointer-events-none">
            <div class="flex items-center gap-2 mb-1.5 pointer-events-auto">
              {#if video.ownerPubkey}
                <a href={`#/${video.ownerNpub}`} class="flex items-center gap-2 min-w-0 no-underline text-white">
                  <Avatar pubkey={video.ownerPubkey} size={32} showBadge />
                  <span class="text-sm font-medium truncate"><Name pubkey={video.ownerPubkey} /></span>
                </a>
                {#if isActive}
                  <FollowButton pubkey={video.ownerPubkey} />
                {/if}
              {/if}
            </div>
            <div class={isActive && captionOpen ? 'max-h-[45vh] overflow-y-auto overscroll-contain pointer-events-auto' : ''}>
              <h1 class="text-sm font-medium m-0">
                <button
                  class="w-full text-left text-sm font-medium text-white bg-transparent b-0 p-0 cursor-pointer break-words pointer-events-auto {isActive && captionOpen ? '' : 'line-clamp-2'}"
                  aria-expanded={isActive && captionOpen}
                  data-testid={isActive ? 'short-caption' : undefined}
                  onclick={() => { captionOpen = !captionOpen; }}
                >{video.title}</button>
              </h1>
              {#if isActive && captionOpen}
                {#if video.description}
                  <div data-testid="short-description">
                    <RichText text={video.description} maxLines={0} images={false} class="text-sm text-white/85 mt-1.5" />
                  </div>
                {/if}
                <p class="text-xs text-white/60 m-0 mt-1.5">
                  {formatTimeAgo(video.timestamp ?? 0)}{#each video.tags ?? [] as tag (tag)}{' '}<a href={`#/t/${encodeURIComponent(tag)}`} class="text-white/80 no-underline hover:underline">#{tag}</a>{/each}
                </p>
              {/if}
            </div>
          </div>

          <!-- Likes, comments, sharing and playback -->
          {#if isActive}
            <div class="absolute right-2 bottom-3 flex flex-col items-center gap-2">
              <div class="flex flex-col items-center">
                <button
                  class={engagement.liked ? 'btn-circle btn-primary !text-red-600' : 'btn-circle btn-ghost bg-black/40 text-white'}
                  title={engagement.liked ? 'Liked' : 'Like'}
                  aria-label="Like"
                  aria-pressed={engagement.liked}
                  data-testid="short-like"
                  disabled={!engagementWatch}
                  onclick={toggleLike}
                >
                  <span class="i-lucide-heart text-lg"></span>
                </button>
                <span class="h-4 text-xs leading-4 text-white drop-shadow" data-testid="short-like-count">{engagement.likes || ''}</span>
              </div>
              <div class="flex flex-col items-center">
                <button
                  class={commentsOpen ? 'btn-circle btn-primary' : 'btn-circle btn-ghost bg-black/40 text-white'}
                  title="Comments"
                  aria-label="Comments"
                  aria-pressed={commentsOpen}
                  data-testid="short-comments"
                  onclick={() => { commentsOpen = !commentsOpen; }}
                >
                  <span class="i-lucide-message-circle text-lg"></span>
                </button>
                <span class="h-4 text-xs leading-4 text-white drop-shadow" data-testid="short-comment-count">{engagement.comments.length || ''}</span>
              </div>
              <ShareButton url={shareUrl(video)} class="bg-black/40 text-white" />
              <button
                class={autoNext ? 'btn-circle btn-primary' : 'btn-circle btn-ghost bg-black/40 text-white'}
                title={autoNext ? 'Playing the next short automatically' : 'Play the next short automatically'}
                aria-label="Play the next short automatically"
                aria-pressed={autoNext}
                data-testid="shorts-auto-next"
                onclick={toggleAutoNext}
              >
                <span class="i-lucide-chevrons-down text-lg"></span>
              </button>
              <button
                class="btn-circle btn-ghost bg-black/40 text-white"
                title={muted ? 'Turn sound on' : 'Mute'}
                aria-label={muted ? 'Turn sound on' : 'Mute'}
                onclick={toggleMuted}
              >
                <span class={muted ? 'i-lucide-volume-x text-lg' : 'i-lucide-volume-2 text-lg'}></span>
              </button>
            </div>
            <div class="absolute inset-x-0 bottom-0 h-0.5 bg-white/20">
              <div class="h-full bg-white/90" style:width={`${progress}%`}></div>
            </div>
          {/if}
        </div>

        <!-- Previous / next -->
        <div class="hidden md:flex flex-col gap-2 pb-2">
          <button
            class="btn-circle btn-ghost bg-surface-1"
            title="Previous"
            aria-label="Previous short"
            disabled={activeIndex === 0}
            onclick={() => go(-1)}
          >
            <span class="i-lucide-chevron-up text-lg"></span>
          </button>
          <button
            class="btn-circle btn-ghost bg-surface-1"
            title="Next"
            aria-label="Next short"
            disabled={activeIndex >= shorts.length - 1}
            onclick={() => go(1)}
          >
            <span class="i-lucide-chevron-down text-lg"></span>
          </button>
        </div>

        <!-- Comments: beside the short on a wide screen, a sheet over its lower part on a narrow one -->
        {#if isActive && commentsOpen}
          <!-- On a narrow screen a tap on the video above the sheet closes it -->
          <button
            class="absolute inset-0 z-10 w-full h-full bg-black/30 b-0 p-0 cursor-default lg:hidden"
            aria-label="Close comments"
            onclick={() => { commentsOpen = false; }}
          ></button>
          <div
            class="absolute inset-x-0 bottom-0 z-10 mx-auto max-w-120 h-[65%] bg-surface-1 rounded-t-2xl overflow-hidden lg:static lg:mx-0 lg:max-w-none lg:h-full lg:w-90 lg:shrink-0 lg:rounded-xl"
            data-testid="short-comments-panel"
          >
            <EventComments comments={engagement.comments} onSubmit={postComment} onClose={() => { commentsOpen = false; }} />
          </div>
        {/if}
      </div>
    </section>
  {/each}

  {#if shorts.length === 0 && !waitingForStart}
    <div class="flex items-center justify-center text-text-3" style:height={`${viewerHeight}px`}>
      No shorts yet.
    </div>
  {/if}
</div>

<style>
  .shorts-scroller {
    scroll-snap-type: y mandatory;
    scrollbar-width: none;
  }
  .shorts-scroller::-webkit-scrollbar {
    display: none;
  }
  .shorts-slot {
    scroll-snap-align: start;
    scroll-snap-stop: always;
  }
</style>
