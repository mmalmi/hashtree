<script lang="ts">
  /**
   * VideoHome - Home page for video.iris.to
   * YouTube-style home with horizontal sections and infinite feed
   */
  import { onMount, untrack } from 'svelte';
  import { SvelteMap } from 'svelte/reactivity';
  import { nip19 } from 'nostr-tools';
  import { nostrStore } from '../../nostr';
  import type { CID } from '@hashtree/core';
  import { recentsStore, clearRecentsByPrefix, type RecentItem } from '../../stores/recents';
  import { detectVideoCardInfo } from '../../stores/playlist';
  import { getTreeRootSync, waitForTreeRoot } from '../../stores/treeRoot';
  import {
    getHomeFeedView,
    setHomeFeedView,
    getRecentVideoCardInfo,
    recentVideoCardInfoVersion,
    setRecentVideoCardInfo,
    type RecentVideoCardInfo,
  } from '../../stores/homeFeedCache';
  import { toHex } from '@hashtree/core';
  import InfiniteScroll from '../InfiniteScroll.svelte';
  import { feedStore, fetchFeedVideos } from '../../stores/feedStore';
  import {
    followingHistoryFilters,
    newVideoHistoryFilters,
    orderVideoFeed,
    videoFeedStore,
    type VideoFeedScope,
    type VideoFeedSort,
  } from '../../stores/videoFeed';
  import { NewVideoHistory, type VideoHistoryStatus } from '../../stores/newVideoHistory';
  import { getEffectiveNostrRelayUrls } from '../../nostr/client';
  import { settingsStore, waitForSettingsLoaded } from '../../stores/settings';
  import { reconcileFeed, unseenFirst } from '../../lib/feedPresentation';
  import { seenShortsSnapshot } from '../../stores/seenShorts';
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import VideoThumbnail from './VideoThumbnail.svelte';
  import { getDeletedVideoTimestamp } from '../../stores/videoDeletes';
  import { resolveFeedVideoRootCid, resolveFeedVideoRootCidAsync } from '../../lib/videoFeedRoot';
  import { getStableThumbnailUrl } from '../../lib/mediaUrl';
  import { onCacheUpdate } from '../../treeRootCache';
  import { resolveReadableThumbnailRoot, resolveReadableVideoRoot } from '../../lib/readableVideoRoot';

  import VideoCard from './VideoCard.svelte';
  import ShortCard from './ShortCard.svelte';
  import PlaylistCard from './PlaylistCard.svelte';
  import type { VideoItem } from './types';

  function sameCid(a: CID | null | undefined, b: CID | null | undefined): boolean {
    if (!a && !b) return true;
    if (!a || !b) return false;
    return toHex(a.hash) === toHex(b.hash)
      && ((a.key && b.key && toHex(a.key) === toHex(b.key)) || (!a.key && !b.key));
  }

  function getRootHashHex(rootCid: CID | null | undefined): string | null {
    return rootCid?.hash ? toHex(rootCid.hash) : null;
  }

  // Get current user
  let isLoggedIn = $derived($nostrStore.isLoggedIn);

  // Delay showing "no videos" to avoid flash during initial load
  let showEmptyState = $state(false);
  let emptyStateTimer: ReturnType<typeof setTimeout> | null = null;

  // Get recents and filter to only videos, deduped by normalized href
  let recents = $derived($recentsStore);
  let recentVideos = $derived(
    recents
      .filter(r => r.treeName?.startsWith('videos/') && !(r.npub && r.treeName && getDeletedVideoTimestamp(r.npub, r.treeName)))
      .map(r => ({
        key: r.path,
        // For playlist videos (with videoId), use label; otherwise extract from treeName
        title: r.videoId ? r.label : (r.treeName ? r.treeName.slice(7) : r.label),
        ownerPubkey: r.npub ? npubToPubkey(r.npub) : null,
        ownerNpub: r.npub,
        treeName: r.treeName,
        videoId: r.videoId,
        visibility: r.visibility,
        href: buildRecentHref(r),
        timestamp: r.timestamp,
        duration: r.duration,
      } as VideoItem))
      .filter((v, i, arr) => arr.findIndex(x => x.href === v.href) === i)
      .slice(0, 10)
  );
  let recentCardInfoByKey = $state<Record<string, RecentVideoCardInfo>>({});
  let resolvedRecentCardInfoByKey = $derived.by(() => {
    void $recentVideoCardInfoVersion;
    const next: Record<string, RecentVideoCardInfo> = {};
    for (const video of recentVideos) {
      const cached = getRecentVideoCardInfo(video.key);
      const detected = recentCardInfoByKey[video.key];
      if (cached || detected) {
        next[video.key] = {
          ...(cached ?? { videoCount: 0 }),
          ...(detected ?? {}),
        };
      }
    }
    return next;
  });

  // Debounce media detection for recent videos to avoid excessive calls
  let recentDetectTimer: ReturnType<typeof setTimeout> | null = null;
  let pendingRecentVideos: VideoItem[] = [];
  const recentRetryTimers = new SvelteMap<string, ReturnType<typeof setTimeout>>();
  const recentRetryCounts = new SvelteMap<string, number>();
  const MAX_RECENT_MEDIA_RETRIES = 6;

  function clearRecentRetry(videoKey: string) {
    const timer = recentRetryTimers.get(videoKey);
    if (timer) {
      clearTimeout(timer);
      recentRetryTimers.delete(videoKey);
    }
    recentRetryCounts.delete(videoKey);
  }

  function scheduleRecentRetry(video: VideoItem) {
    if (recentRetryTimers.has(video.key)) return;
    const nextAttempt = (recentRetryCounts.get(video.key) ?? 0) + 1;
    if (nextAttempt > MAX_RECENT_MEDIA_RETRIES) return;
    recentRetryCounts.set(video.key, nextAttempt);
    const delayMs = 250 * (2 ** (nextAttempt - 1));
    const timer = setTimeout(() => {
      recentRetryTimers.delete(video.key);
      void doDetectRecentMedia([video]);
    }, delayMs);
    recentRetryTimers.set(video.key, timer);
  }

  onMount(() => {
    const unsubscribe = onCacheUpdate((npub, treeName) => {
      const pendingRecents = untrack(() => recentVideos.filter((video) =>
        video.ownerNpub === npub
        && video.treeName === treeName
        && !resolvedRecentCardInfoByKey[video.key]?.thumbnailUrl
      ));
      if (pendingRecents.length > 0) {
        void doDetectRecentMedia(pendingRecents);
      }
    });

    return () => {
      unsubscribe();
    };
  });

  function detectRecentMedia(videos: VideoItem[]) {
    const uncached = videos.filter((video) => {
      if (!video.ownerNpub || !video.treeName) return false;
      const existing = resolvedRecentCardInfoByKey[video.key];
      return !existing?.thumbnailUrl && !existing?.videoPath;
    });

    if (uncached.length === 0) {
      return;
    }

    pendingRecentVideos = [...pendingRecentVideos, ...uncached];
    if (recentDetectTimer) clearTimeout(recentDetectTimer);
    recentDetectTimer = setTimeout(() => {
      const toProcess = pendingRecentVideos;
      pendingRecentVideos = [];
      recentDetectTimer = null;
      void doDetectRecentMedia(toProcess);
    }, 100);
  }

  async function doDetectRecentMedia(videos: VideoItem[]) {
    const detectOne = async (video: VideoItem) => {
      if (!video.ownerNpub || !video.treeName) return;

      const latestRootCid = resolveFeedVideoRootCid(video)
        ?? getTreeRootSync(video.ownerNpub, video.treeName)
        ?? await resolveFeedVideoRootCidAsync(video, 3000)
        ?? await waitForTreeRoot(video.ownerNpub, video.treeName, 8000);
      if (!latestRootCid) {
        scheduleRecentRetry(video);
        return;
      }

      const rootCid = await resolveReadableVideoRoot({
        rootCid: latestRootCid,
        npub: video.ownerNpub,
        treeName: video.treeName,
        videoId: video.videoId || null,
        priority: 'background',
      }) ?? latestRootCid;

      const info = await detectVideoCardInfo(rootCid, video.ownerNpub, video.treeName, video.videoId);
      const mediaRootCid = info?.rootCid ?? rootCid;
      let thumbnailUrl = info?.thumbnailUrl;
      const thumbnailRootCid = await resolveReadableThumbnailRoot({
        rootCid: mediaRootCid,
        npub: video.ownerNpub,
        treeName: video.treeName,
        videoId: video.videoId || null,
        priority: 'background',
      }) ?? mediaRootCid;
      if (!sameCid(thumbnailRootCid, mediaRootCid)) {
        const thumbnailInfo = await detectVideoCardInfo(
          thumbnailRootCid,
          video.ownerNpub,
          video.treeName,
          video.videoId,
          { exactRoot: true },
        );
        thumbnailUrl = thumbnailInfo?.thumbnailUrl ?? thumbnailUrl;
      }
      const fallbackThumbnailUrl = getStableThumbnailUrl({
        rootCid: mediaRootCid,
        npub: video.ownerNpub,
        treeName: video.treeName,
        videoId: video.videoId || undefined,
        allowAliasFallback: true,
        playlistRoot: (info?.videoCount ?? 0) > 0,
      });
      const nextInfo: RecentVideoCardInfo = {
        ...(info ?? { videoCount: 0 }),
        rootCid: info?.rootCid ?? rootCid,
        thumbnailUrl: thumbnailUrl ?? fallbackThumbnailUrl ?? undefined,
      };

      setRecentVideoCardInfo(video.key, nextInfo);
      recentCardInfoByKey = { ...recentCardInfoByKey, [video.key]: nextInfo };
      if (nextInfo.thumbnailUrl || nextInfo.videoPath) {
        clearRecentRetry(video.key);
      } else {
        scheduleRecentRetry(video);
      }
    };

    await Promise.allSettled(videos.map(detectOne));
  }

  $effect(() => {
    detectRecentMedia(recentVideos);
  });

  // The feed: videos from everywhere, ranked for the viewer (see stores/videoFeed).
  onMount(fetchFeedVideos);

  const FEED_PAGE_SIZE = 12;
  const SHORTS_ROW_SIZE = 12;
  const SORTS: Array<{ id: VideoFeedSort; label: string }> = [
    { id: 'hot', label: 'Hot' },
    { id: 'new', label: 'New' },
    { id: 'top', label: 'Top' },
  ];
  const SCOPES: Array<{ id: VideoFeedScope; label: string }> = [
    { id: 'all', label: 'All' },
    { id: 'following', label: 'Following' },
  ];

  function readChoice<T extends string>(name: string, allowed: readonly T[], fallback: T): T {
    try {
      const stored = localStorage.getItem(name) as T | null;
      return stored && allowed.includes(stored) ? stored : fallback;
    } catch {
      return fallback;
    }
  }

  function saveChoice(name: string, value: string): void {
    try {
      localStorage.setItem(name, value);
    } catch {
      // The choice still applies for this visit.
    }
  }

  // Coming back to the page shows the feed the viewer left.
  const restored = getHomeFeedView($nostrStore.pubkey ?? null);
  let sort = $state<VideoFeedSort>(restored?.sort ?? readChoice('video-feed-sort', ['hot', 'new', 'top'], 'hot'));
  let scope = $state<VideoFeedScope>(restored?.scope ?? readChoice('video-feed-scope', ['all', 'following'], 'all'));
  let feedPage = $state(restored?.page ?? 0);
  let loadingMore = $state(false);
  let historyStatus = $state<VideoHistoryStatus>('end');
  let automaticPages = $state(0);
  let history: NewVideoHistory | undefined;
  let settingsReady = $state(false);
  let relayList = $derived($settingsStore.network.relays);
  onMount(() => { void waitForSettingsLoaded().then(() => { settingsReady = true; }); });

  $effect(() => {
    if (sort !== 'new' || !settingsReady) return;
    void $nostrStore.pubkey;
    const relays = getEffectiveNostrRelayUrls(relayList);
    const filters = scope === 'following' ? $followingHistoryFilters : newVideoHistoryFilters('all');
    const pager = new NewVideoHistory(relays, filters);
    history = pager;
    historyStatus = filters.length && relays.length ? 'ready' : 'end';
    automaticPages = 0;
    return () => {
      pager.stop();
      history = undefined;
    };
  });

  // Fresh orderings, recomputed as videos, follow distances and reactions arrive.
  let latestVideos = $derived(orderVideoFeed($videoFeedStore.videos, sort, scope));
  // Shorts already played in this browser go to the end of the row.
  const seenShorts = seenShortsSnapshot();
  let latestShorts = $derived(unseenFirst(orderVideoFeed($videoFeedStore.shorts, sort, scope), (video) => seenShorts.has(video.key)));

  // Keep the prefix through the last visible card. The rest can take the fresh order.
  let shownKeys = $state<string[]>(restored?.videos ?? []);
  let shownShortKeys = $state<string[]>(restored?.shorts ?? []);
  let pendingUpdate = $state(false);
  let grid = $state<HTMLDivElement>();
  let shortsStrip = $state<HTMLDivElement>();
  let viewportVersion = $state(0);

  function sameKeys(a: string[], b: string[]): boolean {
    return a.length === b.length && a.every((key, index) => key === b[index]);
  }

  function protectedCards(container: HTMLElement | undefined, horizontal = false): number {
    if (!container) return 0;
    const bounds = container.getBoundingClientRect();
    if (bounds.top >= window.innerHeight || (horizontal && bounds.bottom <= 0)) return 0;
    const edge = horizontal ? Math.min(bounds.right, window.innerWidth) : window.innerHeight;
    const cards = container.children;
    // Grid rows share a top edge. A partly visible row (or short) is protected in full.
    let lo = 0;
    let hi = cards.length;
    while (lo < hi) {
      const mid = Math.floor((lo + hi) / 2);
      const rect = cards[mid].getBoundingClientRect();
      if ((horizontal ? rect.left : rect.top) < edge) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  $effect.pre(() => {
    void viewportVersion;
    const limit = (feedPage + 1) * FEED_PAGE_SIZE;
    const latest = latestVideos.map((video) => video.key);
    const latestShortKeys = latestShorts.map((video) => video.key);
    untrack(() => {
      const protectedVideos = grid ? protectedCards(grid) : shownKeys.length;
      const videos = reconcileFeed(shownKeys, latest, limit, protectedVideos);
      // Inserting the very first Shorts row above a visible video would push it down.
      const holdNewRow = !shownShortKeys.length && latestShortKeys.length > 0 && protectedVideos > 0;
      const protectedShorts = shortsStrip ? protectedCards(shortsStrip, true) : shownShortKeys.length;
      const shorts = reconcileFeed(shownShortKeys, latestShortKeys, holdNewRow ? 0 : SHORTS_ROW_SIZE, protectedShorts);
      if (!sameKeys(videos.shown, shownKeys)) shownKeys = videos.shown;
      if (!sameKeys(shorts.shown, shownShortKeys)) shownShortKeys = shorts.shown;
      pendingUpdate = videos.pending || shorts.pending || holdNewRow;
    });
  });

  $effect(() => {
    setHomeFeedView($nostrStore.pubkey ?? null, { sort, scope, page: feedPage, videos: shownKeys, shorts: shownShortKeys });
  });

  onMount(() => {
    let frame = 0;
    let lastScrollY = window.scrollY;
    const onScroll = () => {
      // Request relay history only on demand, even if the first page fits the screen.
      if (sort === 'new' && window.scrollY > lastScrollY) automaticPages = 3;
      lastScrollY = window.scrollY;
      refreshViewport();
    };
    const refreshViewport = () => {
      if (!pendingUpdate || frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        viewportVersion++;
      });
    };
    refreshViewport();
    window.addEventListener('scroll', onScroll, { capture: true, passive: true });
    window.addEventListener('resize', refreshViewport);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', refreshViewport);
    };
  });

  /** Switch to the fresh ordering. Only ever runs on the viewer's request. */
  function showLatest(): void {
    feedPage = 0;
    shownKeys = latestVideos.slice(0, FEED_PAGE_SIZE).map((video) => video.key);
    shownShortKeys = latestShorts.slice(0, SHORTS_ROW_SIZE).map((video) => video.key);
    pendingUpdate = false;
  }

  function chooseSort(next: VideoFeedSort): void {
    if (next === sort) return;
    sort = next;
    saveChoice('video-feed-sort', next);
    showLatest();
  }

  function chooseScope(next: VideoFeedScope): void {
    if (next === scope) return;
    scope = next;
    saveChoice('video-feed-scope', next);
    showLatest();
  }

  function pickShown(keys: string[], latest: VideoItem[]): VideoItem[] {
    const byKey = new Map(latest.map((video) => [video.key, video]));
    return keys.map((key) => byKey.get(key)).filter((video): video is VideoItem => !!video);
  }

  let feedVideos = $derived(pickShown(shownKeys, latestVideos));
  let feedShorts = $derived(pickShown(shownShortKeys, latestShorts));

  let resolvedFeedVideoByKey = $derived.by(() => {
    const map: Record<string, (typeof $feedStore)[number]> = {};
    for (const video of $feedStore) {
      if (!video.ownerNpub || !video.treeName) continue;
      map[video.videoId ? `${video.ownerNpub}/${video.treeName}/${video.videoId}` : `${video.ownerNpub}/${video.treeName}`] = video;
    }
    return map;
  });

  function loadMoreFeed() {
    if (loadingMore) return;
    if (shownKeys.length >= latestVideos.length) {
      if (sort === 'new' && historyStatus === 'ready' && automaticPages > 0) loadOlderVideos();
      return;
    }

    loadingMore = true;
    feedPage++;
    setTimeout(() => loadingMore = false, 100);
  }

  function loadOlderVideos(retry = false): void {
    const pager = history;
    if (!pager || historyStatus === 'loading' || historyStatus === 'end') return;
    historyStatus = 'loading';
    automaticPages = Math.max(0, automaticPages - 1);
    // Make room now so the first answering relay can fill it.
    feedPage = Math.max(feedPage, Math.floor(shownKeys.length / FEED_PAGE_SIZE));
    pager.load(status => { historyStatus = status; }, retry);
  }

  // Control empty state visibility with delay
  $effect(() => {
    const hasContent = recentVideos.length > 0 || feedVideos.length > 0 || feedShorts.length > 0;

    if (hasContent) {
      // Clear timer and hide empty state immediately when content appears
      if (emptyStateTimer) {
        clearTimeout(emptyStateTimer);
        emptyStateTimer = null;
      }
      showEmptyState = false;
    } else {
      // Start timer to show empty state after delay
      if (!emptyStateTimer && !showEmptyState) {
        emptyStateTimer = setTimeout(() => {
          showEmptyState = true;
          emptyStateTimer = null;
        }, 2000);
      }
    }
  });

  function npubToPubkey(npub: string): string | null {
    try {
      const decoded = nip19.decode(npub);
      if (decoded.type === 'npub') {
        return decoded.data as string;
      }
    } catch {}
    return null;
  }

  function buildRecentHref(item: RecentItem): string {
    // Encode treeName in path: /npub/treeName -> /npub/encodedTreeName
    let encodedPath: string;
    if (item.treeName) {
      // For playlist videos, encode treeName and videoId separately
      encodedPath = item.videoId
        ? `/${item.npub}/${encodeURIComponent(item.treeName)}/${encodeURIComponent(item.videoId)}`
        : `/${item.npub}/${encodeURIComponent(item.treeName)}`;
    } else {
      encodedPath = item.path;
    }
    const base = `#${encodedPath}`;
    return item.linkKey ? `${base}?k=${item.linkKey}` : base;
  }

  </script>

<div class="flex-1">
  <div class="max-w-7xl mx-auto p-4 md:p-6">
    <!-- Recent Videos Section -->
    {#if recentVideos.length > 0}
      <section class="mb-10">
        <div class="flex items-center justify-between mb-3">
          <h2 class="text-lg font-semibold text-text-1">Recent</h2>
          <button
            class="btn-ghost text-xs"
            onclick={() => clearRecentsByPrefix('videos/')}
          >
            Clear
          </button>
        </div>
        <div class="relative -mx-4">
          <div class="flex gap-3 overflow-x-auto pb-2 px-4 scrollbar-thin">
            {#each recentVideos as video (video.href)}
              {@const recentCardInfo = resolvedRecentCardInfoByKey[video.key]}
              <div class="shrink-0 w-64 md:w-80">
                <VideoCard
                  href={video.href}
                  title={video.title}
                  duration={video.duration ?? recentCardInfo?.duration}
                  thumbnailUrl={recentCardInfo?.thumbnailUrl}
                  videoPath={recentCardInfo?.videoPath}
                  ownerPubkey={video.ownerPubkey}
                  ownerNpub={video.ownerNpub}
                  treeName={video.treeName}
                  videoId={video.videoId}
                  visibility={video.visibility}
                  rootCid={recentCardInfo?.rootCid ?? null}
                  rootHashHex={recentCardInfo?.rootCid?.hash ? toHex(recentCardInfo.rootCid.hash) : null}
                  timestamp={video.timestamp}
                  noHover
                />
              </div>
            {/each}
          </div>
          <!-- Scroll fade indicator (right side only) -->
          <div class="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-surface-0 via-surface-0/80 to-transparent"></div>
        </div>
      </section>
    {/if}

    <!-- Feed controls. Fixed height, and the Update button keeps its space, so nothing below moves. -->
    <div class="flex items-center gap-1.5 sm:gap-2 mb-4 h-9 min-w-0" data-testid="feed-controls">
      <div class="flex shrink-0 rounded-full bg-surface-1 p-0.5" role="group" aria-label="Feed">
        {#each SCOPES as option (option.id)}
          <button
            class="px-2 sm:px-3 py-1 text-sm rounded-full b-0 cursor-pointer {scope === option.id ? 'bg-surface-3 text-text-1' : 'bg-transparent text-text-3 hover:text-text-1'}"
            aria-pressed={scope === option.id}
            onclick={() => chooseScope(option.id)}
          >{option.label}</button>
        {/each}
      </div>
      <div class="flex shrink-0 rounded-full bg-surface-1 p-0.5" role="group" aria-label="Sort">
        {#each SORTS as option (option.id)}
          <button
            class="px-2 sm:px-3 py-1 text-sm rounded-full b-0 cursor-pointer {sort === option.id ? 'bg-surface-3 text-text-1' : 'bg-transparent text-text-3 hover:text-text-1'}"
            aria-pressed={sort === option.id}
            onclick={() => chooseSort(option.id)}
          >{option.label}</button>
        {/each}
      </div>
      <!-- A quiet text link with a red dot, as in the other apps: it says there is something new without shouting. -->
      <button
        class="ml-auto shrink-0 bg-transparent b-0 p-0 py-1 cursor-pointer text-sm font-semibold text-text-1 hover:text-accent flex items-center gap-1.5 {pendingUpdate ? '' : 'invisible'}"
        data-testid="feed-update"
        aria-hidden={!pendingUpdate}
        tabindex={pendingUpdate ? 0 : -1}
        title="Show the latest order"
        onclick={showLatest}
      >
        <span class="w-2 h-2 rounded-full bg-red-500 shrink-0"></span>
        <span class="hidden sm:inline">Show updated videos</span>
        <span class="sm:hidden i-lucide-arrow-up text-base" aria-label="Show updated videos"></span>
      </button>
    </div>

    <!-- Shorts -->
    {#if feedShorts.length > 0}
      <section class="mb-8" data-testid="shorts-row">
        <h2 class="text-lg font-semibold mb-3">
          <a href="#/shorts" class="text-text-1 no-underline hover:underline">Shorts</a>
        </h2>
        <div class="relative -mx-4">
          <div bind:this={shortsStrip} class="flex gap-3 overflow-x-auto pb-2 px-4 scrollbar-thin">
            {#each feedShorts as video (video.key)}
              <ShortCard {video} class="shrink-0 w-36 md:w-44" />
            {/each}
          </div>
          <div class="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-surface-0 via-surface-0/80 to-transparent"></div>
        </div>
      </section>
    {/if}

    <!-- Feed Section -->
    {#if feedVideos.length > 0}
      <section>
        <InfiniteScroll onLoadMore={loadMoreFeed} loading={loadingMore}>
          <div bind:this={grid} class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="video-feed">
            {#each feedVideos as video (video.key)}
              {@const resolvedVideo = resolvedFeedVideoByKey[video.key]}
              {#if video.videoCount}
                <PlaylistCard
                  href={video.href}
                  title={video.title}
                  videoCount={video.videoCount}
                  thumbnailUrl={getStableThumbnailUrl({
                    thumbnailUrl: video.thumbnailUrl ?? resolvedVideo?.thumbnailUrl,
                    rootCid: resolvedVideo?.rootCid ?? null,
                    npub: video.ownerNpub,
                    treeName: video.treeName,
                    allowAliasFallback: true,
                    playlistRoot: true,
                  })}
                  ownerNpub={video.ownerNpub}
                  treeName={video.treeName}
                  rootCid={resolvedVideo?.rootCid ?? null}
                  rootHashHex={getRootHashHex(resolvedVideo?.rootCid)}
                  ownerPubkey={video.ownerPubkey}
                  visibility={video.visibility}
                />
              {:else}
                <VideoCard
                  href={video.href}
                  title={video.title}
                  duration={video.duration ?? resolvedVideo?.duration}
                  thumbnailUrl={video.thumbnailUrl ?? resolvedVideo?.thumbnailUrl}
                  videoPath={video.videoPath ?? resolvedVideo?.videoPath}
                  videoUrls={video.videoUrls}
                  ownerPubkey={video.ownerPubkey}
                  ownerNpub={video.ownerNpub}
                  treeName={video.treeName || null}
                  videoId={video.videoId}
                  visibility={video.visibility}
                  rootCid={resolvedVideo?.rootCid ?? null}
                  rootHashHex={getRootHashHex(resolvedVideo?.rootCid)}
                  timestamp={video.timestamp}
                />
              {/if}
            {/each}
          </div>
        </InfiniteScroll>

        {#if loadingMore}
          <div class="flex justify-center py-4">
            <span class="i-lucide-loader-2 animate-spin text-text-3"></span>
          </div>
        {/if}
      </section>
    {/if}

    {#if sort === 'new' && historyStatus !== 'end' && shownKeys.length >= latestVideos.length}
      <div class="flex justify-center py-4">
        <button class="btn-ghost text-sm" disabled={historyStatus === 'loading'}
          onclick={() => { automaticPages = 3; loadOlderVideos(true); }}>
          {historyStatus === 'loading' ? 'Loading videos…' : 'Load more videos'}
        </button>
      </div>
    {/if}

    <!-- Empty state when no content (delayed to avoid flash) -->
    {#if showEmptyState}
      <div class="text-center py-12 text-text-3">
        <p>No videos found. {#if !isLoggedIn}Sign in to upload videos.{/if}</p>
      </div>
    {/if}
  </div>
</div>

<style>
  .scrollbar-thin::-webkit-scrollbar {
    height: 6px;
  }
  .scrollbar-thin::-webkit-scrollbar-track {
    background: transparent;
  }
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: var(--surface-3);
    border-radius: 3px;
  }
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: var(--surface-4);
  }
</style>
