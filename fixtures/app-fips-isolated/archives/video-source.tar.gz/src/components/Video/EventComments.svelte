<script lang="ts">
  /**
   * EventComments - comments on a video event, with a box to add one
   * Comments on the video are listed newest first; the replies to each sit
   * underneath it, indented, behind a "N replies" toggle. Fills the height it is
   * given: the list scrolls, the box stays at the bottom.
   */
  import { nip19 } from 'nostr-tools';
  import { SvelteSet } from 'svelte/reactivity';
  import { nostrStore } from '../../nostr';
  import { threadComments, type EventComment } from '../../lib/eventEngagement';
  import { formatTimeAgo } from '../../utils/format';
  import { Avatar, Name } from '../User';
  import RichText from '../RichText.svelte';

  interface Props {
    comments: EventComment[];
    /** `parentId` is the comment being answered, when the viewer is replying to one. */
    onSubmit: (text: string, parentId?: string) => Promise<void>;
    /** Shown as a close button when the comments sit in a panel. */
    onClose?: () => void;
  }

  let { comments, onSubmit, onClose }: Props = $props();

  let draft = $state('');
  let sending = $state(false);
  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let threads = $derived(threadComments(comments));

  // Which threads are open, and which comment the viewer is answering.
  const openThreads = new SvelteSet<string>();
  let replyingTo = $state<EventComment | null>(null);
  let inputEl = $state<HTMLInputElement | null>(null);

  function toggleThread(id: string): void {
    if (openThreads.has(id)) openThreads.delete(id);
    else openThreads.add(id);
  }

  function replyTo(comment: EventComment, threadId: string): void {
    replyingTo = comment;
    openThreads.add(threadId);
    inputEl?.focus();
  }

  async function submit(event: SubmitEvent): Promise<void> {
    event.preventDefault();
    const text = draft.trim();
    if (!text || sending) return;
    sending = true;
    try {
      await onSubmit(text, replyingTo?.id);
      draft = '';
      replyingTo = null;
    } catch (error) {
      console.error('Failed to post comment:', error);
    } finally {
      sending = false;
    }
  }
</script>

{#snippet commentRow(comment: EventComment, threadId: string, size: number)}
  {@const href = `#/${nip19.npubEncode(comment.pubkey)}`}
  <div class="flex gap-3" data-testid="event-comment">
    <a {href} class="shrink-0">
      <Avatar pubkey={comment.pubkey} {size} showBadge />
    </a>
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2">
        <a {href} class="text-sm font-medium text-text-1 hover:text-accent no-underline truncate">
          <Name pubkey={comment.pubkey} />
        </a>
        <span class="text-xs text-text-3 shrink-0">{formatTimeAgo(comment.createdAt)}</span>
      </div>
      <RichText text={comment.content} class="text-sm text-text-2 mt-0.5" />
      {#if isLoggedIn}
        <button
          class="bg-transparent b-0 p-0 mt-1 cursor-pointer text-xs font-semibold text-text-3 hover:text-text-1"
          data-testid="comment-reply"
          onclick={() => replyTo(comment, threadId)}
        >Reply</button>
      {/if}
    </div>
  </div>
{/snippet}

<div class="flex flex-col h-full min-h-0" data-testid="event-comments">
  <div class="flex items-center justify-between gap-2 px-4 py-3 shrink-0">
    <h2 class="text-base font-semibold text-text-1 m-0">
      Comments{#if comments.length > 0}<span class="text-text-3 font-normal ml-1.5">{comments.length}</span>{/if}
    </h2>
    {#if onClose}
      <button class="btn-circle btn-ghost" title="Close" aria-label="Close comments" onclick={onClose}>
        <span class="i-lucide-x text-lg"></span>
      </button>
    {/if}
  </div>

  <div class="flex-1 min-h-0 overflow-y-auto overscroll-contain px-4 pt-1">
    {#if comments.length === 0}
      <p class="text-text-3 text-sm py-6 text-center m-0">No comments yet.</p>
    {:else}
      <div class="space-y-4 pb-3">
        {#each threads as thread (thread.comment.id)}
          {@const open = openThreads.has(thread.comment.id)}
          <div data-testid="comment-thread">
            {@render commentRow(thread.comment, thread.comment.id, 32)}
            {#if thread.replies.length > 0}
              <div class="ml-11 mt-1.5">
                <button
                  class="bg-transparent b-0 p-0 cursor-pointer text-sm font-semibold text-accent flex items-center gap-1"
                  aria-expanded={open}
                  data-testid="comment-replies-toggle"
                  onclick={() => toggleThread(thread.comment.id)}
                >
                  <span class={open ? 'i-lucide-chevron-up text-base' : 'i-lucide-chevron-down text-base'}></span>
                  {thread.replies.length} {thread.replies.length === 1 ? 'reply' : 'replies'}
                </button>
                {#if open}
                  <div class="space-y-3 mt-3">
                    {#each thread.replies as reply (reply.id)}
                      {@render commentRow(reply, thread.comment.id, 24)}
                    {/each}
                  </div>
                {/if}
              </div>
            {/if}
          </div>
        {/each}
      </div>
    {/if}
  </div>

  <div class="shrink-0 px-4 py-3 b-t-1 b-t-solid b-t-surface-3">
    {#if isLoggedIn}
      {#if replyingTo}
        <div class="flex items-center gap-2 mb-2 text-xs text-text-3" data-testid="comment-replying-to">
          <span class="truncate">Replying to <Name pubkey={replyingTo.pubkey} /></span>
          <button class="bg-transparent b-0 p-0 cursor-pointer text-text-3 hover:text-text-1" aria-label="Cancel reply" onclick={() => { replyingTo = null; }}>
            <span class="i-lucide-x text-sm"></span>
          </button>
        </div>
      {/if}
      <form class="flex items-center gap-2" onsubmit={submit}>
        <input
          bind:this={inputEl}
          bind:value={draft}
          class="input flex-1 min-w-0 text-sm"
          placeholder={replyingTo ? 'Add a reply' : 'Add a comment'}
          aria-label="Add a comment"
          maxlength="2000"
        />
        <button
          type="submit"
          class="btn-circle btn-primary shrink-0"
          title="Post comment"
          aria-label="Post comment"
          disabled={!draft.trim() || sending}
        >
          <span class="i-lucide-send text-base"></span>
        </button>
      </form>
    {:else}
      <p class="text-text-3 text-sm text-center m-0">Sign in to leave a comment.</p>
    {/if}
  </div>
</div>
