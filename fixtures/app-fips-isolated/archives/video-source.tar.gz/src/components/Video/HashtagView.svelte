<script lang="ts">
  /**
   * HashtagView - videos carrying a hashtag, at #/t/<tag>
   * Lists what is already loaded at once and asks the relays for more, which
   * joins the page as it arrives. Ranked like the front page.
   */
  import type { Event } from 'nostr-tools';
  import { nostr } from '../../nostr';
  import { queryConfiguredRelaysDirectly } from '../../nostr/directQuery';
  import { ALL_VIDEO_EVENT_KINDS } from '../../lib/videoEvent';
  import { reconcileFeed } from '../../lib/feedPresentation';
  import { ingestVideoEvent, videoEventsStore } from '../../stores/videoEvents';
  import { startVideoFeed } from '../../stores/videoFeed';
  import ShortCard from './ShortCard.svelte';
  import VideoCard from './VideoCard.svelte';

  interface Props {
    tag?: string;
  }

  let { tag = '' }: Props = $props();

  const LOOKUP_MS = 8000;
  const LIST_LIMIT = 200;

  let normalized = $derived(decodeURIComponent(tag).trim().replace(/^#/, '').toLowerCase());

  $effect(() => {
    startVideoFeed();
    if (!normalized) return;
    const filter = { kinds: ALL_VIDEO_EVENT_KINDS, '#t': [normalized], limit: 100 };
    const subscription = nostr.subscribe([filter]);
    subscription.on('event', (event: Event) => { ingestVideoEvent(event); });
    const stopDirect = queryConfiguredRelaysDirectly([filter], (event) => { ingestVideoEvent(event); }, LOOKUP_MS);
    const timer = setTimeout(() => subscription.stop(), LOOKUP_MS);
    return () => {
      clearTimeout(timer);
      subscription.stop();
      stopDirect();
    };
  });

  let ranked = $derived($videoEventsStore.filter((video) => !video.sensitive && !!video.tags?.includes(normalized)));

  // What is on screen stays where it is; later arrivals are added below.
  let shownKeys = $state<string[]>([]);
  $effect(() => {
    const latest = ranked.map((video) => video.key);
    const next = reconcileFeed(shownKeys, latest, LIST_LIMIT).shown;
    if (next.length !== shownKeys.length || next.some((key, index) => key !== shownKeys[index])) shownKeys = next;
  });
  let shown = $derived.by(() => {
    const byKey = new Map(ranked.map((video) => [video.key, video]));
    return shownKeys.map((key) => byKey.get(key)).filter((video) => !!video);
  });
  let shorts = $derived(shown.filter((video) => video.short));
  let videos = $derived(shown.filter((video) => !video.short));
</script>

<div class="flex-1 overflow-y-auto">
  <div class="max-w-7xl mx-auto px-4 py-6" data-testid="hashtag-page">
    <h1 class="text-2xl font-semibold text-text-1 m-0 break-words">#{normalized}</h1>
    <p class="text-sm text-text-3 mt-1 mb-6">{shown.length} video{shown.length === 1 ? '' : 's'}</p>

    {#if shown.length === 0}
      <p class="text-text-3 text-center py-12">No videos with this hashtag yet.</p>
    {/if}

    {#if shorts.length > 0}
      <div class="mb-8">
        <h2 class="text-lg font-semibold text-text-1 mb-4">Shorts</h2>
        <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
          {#each shorts as video (video.key)}
            <ShortCard {video} />
          {/each}
        </div>
      </div>
    {/if}

    {#if videos.length > 0}
      {#if shorts.length > 0}
        <h2 class="text-lg font-semibold text-text-1 mb-4">Videos</h2>
      {/if}
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {#each videos as video (video.key)}
          <VideoCard
            href={video.href}
            title={video.title}
            duration={video.duration}
            ownerPubkey={video.ownerPubkey}
            ownerNpub={video.ownerNpub}
            treeName={video.treeName || null}
            videoId={video.videoId}
            thumbnailUrl={video.thumbnailUrl}
            videoPath={video.videoPath}
            videoUrls={video.videoUrls}
            timestamp={video.timestamp}
            noHover
          />
        {/each}
      </div>
    {/if}
  </div>
</div>
