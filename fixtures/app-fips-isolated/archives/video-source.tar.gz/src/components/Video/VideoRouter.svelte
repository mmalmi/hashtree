<script lang="ts">
  /**
   * VideoRouter - Router for the video app
   * Routes:
   * - / : Home (recent videos, followed users' videos)
   * - /settings : Settings page
   * - /users : User list (switch user)
   * - /:nhash : Permalink to video (content-addressed)
   * - /v/:eventRef : Video hosted outside hashtree (NIP-71 event from another app)
   * - /shorts, /shorts/:eventRef : Shorts viewer
   * - /list/:setRef : Playlist published as a video set (NIP-51)
   * - /t/:tag : Videos carrying a hashtag
   * - /:npub/edit : Edit profile page
   * - /:npub/profile : Profile page (alias)
   * - /:npub/follows : Following list
   * - /:npub/followers : Followers list
   * - /:npub/:treeName : Video view
   * - /:npub : Profile with videos (channel)
   */
  import { matchRoute } from '../../lib/router.svelte';
  import { htreeReady } from '../../lib/htreeReady';
  import { isNHash } from '@hashtree/core';
  import VideoHome from './VideoHome.svelte';
  import VideoProfileView from './VideoProfileView.svelte';
  import VideoView from './VideoView.svelte';
  import VideoEventView from './VideoEventView.svelte';
  import ShortsView from './ShortsView.svelte';
  import VideoSetView from './VideoSetView.svelte';
  import HashtagView from './HashtagView.svelte';
  import VideoNHashView from './VideoNHashView.svelte';
  import VideoCreate from './VideoCreate.svelte';
  import SettingsLayout from '../settings/SettingsLayout.svelte';
  import EditProfilePage from '../EditProfilePage.svelte';
  import UsersPage from '../UsersPage.svelte';
  import FollowsPage from '../FollowsPage.svelte';
  import FollowersPage from '../FollowersPage.svelte';

  const routePatterns = [
    { pattern: '/', component: VideoHome },
    { pattern: '/create', component: VideoCreate },
    { pattern: '/settings', component: SettingsLayout },
    { pattern: '/settings/*', component: SettingsLayout },
    { pattern: '/users', component: UsersPage },
    { pattern: '/v/:eventRef', component: VideoEventView },
    { pattern: '/shorts', component: ShortsView },
    { pattern: '/shorts/:eventRef', component: ShortsView },
    { pattern: '/list/:setRef', component: VideoSetView },
    { pattern: '/t/:tag', component: HashtagView },
    { pattern: '/:npub/edit', component: EditProfilePage },
    { pattern: '/:npub/profile', component: VideoProfileView },
    { pattern: '/:npub/follows', component: FollowsPage },
    { pattern: '/:npub/followers', component: FollowersPage },
    // Video routes use :treeName param to support encoded slashes in tree names
    // e.g., "videos/My Playlist" becomes "videos%2FMy%20Playlist" in URL
    { pattern: '/:npub/:treeName/*', component: VideoView },
    { pattern: '/:npub/:treeName', component: VideoView },
    { pattern: '/:npub', component: VideoProfileView },
  ];

  interface Props {
    currentPath: string;
  }

  type GenericVideoRouteMatch = {
    kind: 'generic';
    component:
      | typeof VideoHome
      | typeof VideoCreate
      | typeof SettingsLayout
      | typeof UsersPage
      | typeof EditProfilePage
      | typeof VideoProfileView
      | typeof FollowsPage
      | typeof FollowersPage
      | typeof VideoEventView
      | typeof ShortsView
      | typeof VideoSetView
      | typeof HashtagView
      | typeof VideoView;
    params: Record<string, string>;
  };

  type SnapshotVideoRouteMatch = {
    kind: 'nhash';
    params: {
      nhash: string;
      wild: string;
    };
  };

  let { currentPath }: Props = $props();

  // Match route
  let matchedRoute = $derived.by<GenericVideoRouteMatch | SnapshotVideoRouteMatch>(() => {
    // Check for nhash first (content-addressed permalink)
    const parts = currentPath.split('/').filter(Boolean);
    if (parts[0] && isNHash(parts[0])) {
      return {
        kind: 'nhash',
        params: {
          nhash: parts[0],
          wild: parts.slice(1).join('/'),
        },
      };
    }

    for (const route of routePatterns) {
      const match = matchRoute(route.pattern, currentPath);
      if (match.matched) {
        return { kind: 'generic', component: route.component, params: match.params };
      }
    }
    return { kind: 'generic', component: VideoHome, params: {} };
  });

</script>

{#key currentPath}
  {#if (matchedRoute.kind === 'nhash' || matchedRoute.component === VideoView || matchedRoute.component === VideoCreate) && !$htreeReady}
    <!-- These pages load hashtree media, which only the service worker can serve: they wait for it. -->
  {:else if matchedRoute.kind === 'nhash'}
    <VideoNHashView {...matchedRoute.params} />
  {:else if matchedRoute.component === VideoHome}
    <VideoHome />
  {:else if matchedRoute.component === VideoCreate}
    <VideoCreate />
  {:else if matchedRoute.component === SettingsLayout}
    <SettingsLayout />
  {:else if matchedRoute.component === UsersPage}
    <UsersPage />
  {:else if matchedRoute.component === EditProfilePage}
    <EditProfilePage npub={matchedRoute.params.npub} />
  {:else if matchedRoute.component === VideoProfileView}
    <VideoProfileView npub={matchedRoute.params.npub} />
  {:else if matchedRoute.component === FollowsPage}
    <FollowsPage npub={matchedRoute.params.npub} />
  {:else if matchedRoute.component === FollowersPage}
    <FollowersPage npub={matchedRoute.params.npub} />
  {:else if matchedRoute.component === VideoEventView}
    <VideoEventView eventRef={matchedRoute.params.eventRef} />
  {:else if matchedRoute.component === ShortsView}
    <ShortsView eventRef={matchedRoute.params.eventRef} />
  {:else if matchedRoute.component === VideoSetView}
    <VideoSetView setRef={matchedRoute.params.setRef} />
  {:else if matchedRoute.component === HashtagView}
    <HashtagView tag={matchedRoute.params.tag} />
  {:else if matchedRoute.component === VideoView}
    <VideoView {...matchedRoute.params} />
  {/if}
{/key}
