<script lang="ts">
  import { onMount } from 'svelte';
  import {
    addVideoCatalogUrl,
    refreshSavedVideoCatalogs,
    removeVideoCatalogUrl,
    videoCatalogsStore,
  } from '../../stores/videoCatalogs';
  import {
    getVideoCatalogIndexTrustSettings,
    saveVideoCatalogIndexTrustSettings,
  } from '../../lib/videoCatalogCollection';

  let catalogUrl = $state('');
  let busy = $state(false);
  let formError = $state<string | null>(null);
  let includeFollowed = $state(false);
  let allowlistText = $state('');

  onMount(() => {
    const settings = getVideoCatalogIndexTrustSettings();
    includeFollowed = settings.includeFollowed;
    allowlistText = settings.allowlistedPubkeys.join('\n');
    void refreshSavedVideoCatalogs();
  });

  async function addCatalog() {
    const trimmed = catalogUrl.trim();
    if (!trimmed) return;
    busy = true;
    formError = null;
    try {
      await addVideoCatalogUrl(trimmed);
      catalogUrl = '';
    } catch (error) {
      formError = error instanceof Error ? error.message : 'Catalog failed to load';
    } finally {
      busy = false;
    }
  }

  async function removeCatalog(url: string) {
    busy = true;
    formError = null;
    try {
      await removeVideoCatalogUrl(url);
    } catch (error) {
      formError = error instanceof Error ? error.message : 'Catalog failed to update';
    } finally {
      busy = false;
    }
  }

  async function refreshCatalogs() {
    busy = true;
    formError = null;
    try {
      await refreshSavedVideoCatalogs();
    } catch (error) {
      formError = error instanceof Error ? error.message : 'Catalogs failed to refresh';
    } finally {
      busy = false;
    }
  }

  function saveTrustSettings() {
    saveVideoCatalogIndexTrustSettings({
      includeFollowed,
      allowlistedPubkeys: allowlistText.split(/\s+/).map((value) => value.trim()).filter(Boolean),
    });
    const settings = getVideoCatalogIndexTrustSettings();
    includeFollowed = settings.includeFollowed;
    allowlistText = settings.allowlistedPubkeys.join('\n');
  }

  let catalogByUrl = $derived.by(() => {
    const map = new Map<string, (typeof $videoCatalogsStore.catalogs)[number]>();
    for (const catalog of $videoCatalogsStore.catalogs) {
      map.set(catalog.sourceUrl, catalog);
    }
    return map;
  });
  let defaultUrlSet = $derived(new Set($videoCatalogsStore.defaultUrls));
</script>

<div class="max-w-5xl mx-auto p-4 md:p-6">
  <div class="flex items-center justify-between gap-4 mb-5">
    <h1 class="text-2xl font-semibold text-text-1">Catalogs</h1>
    <button class="btn-ghost btn-circle" title="Refresh" onclick={refreshCatalogs} disabled={busy || $videoCatalogsStore.loading}>
      <span class="i-lucide-refresh-cw text-lg {busy || $videoCatalogsStore.loading ? 'animate-spin' : ''}"></span>
    </button>
  </div>

  <form class="flex gap-2 mb-5" onsubmit={(event) => { event.preventDefault(); void addCatalog(); }}>
    <input
      bind:value={catalogUrl}
      class="flex-1 bg-surface-1 text-text-1 rounded-lg px-3 py-2 outline-none b-1 b-solid b-surface-3 focus:b-accent"
      placeholder="htree://npub.../videos"
      disabled={busy}
    />
    <button class="btn-primary px-4 py-2 flex items-center gap-2" type="submit" disabled={busy || !catalogUrl.trim()}>
      <span class="i-lucide-plus text-lg"></span>
      <span>Add</span>
    </button>
  </form>

  {#if formError || $videoCatalogsStore.error}
    <div class="rounded-lg bg-danger/10 text-danger px-3 py-2 mb-4 text-sm">
      {formError ?? $videoCatalogsStore.error}
    </div>
  {/if}

  <section class="mb-5 rounded-lg bg-surface-1 px-4 py-3">
    <div class="flex flex-col md:flex-row md:items-center gap-3">
      <label class="flex items-center gap-2 text-sm text-text-2">
        <input
          type="checkbox"
          class="accent-accent"
          bind:checked={includeFollowed}
          onchange={saveTrustSettings}
        />
        <span>Index followed videos</span>
      </label>
      <textarea
        class="min-h-18 flex-1 bg-surface-0 text-text-1 rounded-lg px-3 py-2 outline-none b-1 b-solid b-surface-3 focus:b-accent text-sm"
        bind:value={allowlistText}
        onblur={saveTrustSettings}
        placeholder="allowlisted npub or pubkey"
      ></textarea>
    </div>
  </section>

  {#if $videoCatalogsStore.urls.length > 0}
    <div class="space-y-2">
      {#each $videoCatalogsStore.urls as url (url)}
        {@const catalog = catalogByUrl.get(url)}
        {@const isDefault = defaultUrlSet.has(url)}
        <div class="rounded-lg bg-surface-1 px-4 py-3 flex items-center gap-3">
          <div class="min-w-0 flex-1">
            <div class="font-medium text-text-1 truncate flex items-center gap-2">
              <span class="truncate">{catalog?.title ?? url}</span>
              {#if isDefault}
                <span class="text-xs text-accent bg-accent/10 rounded px-1.5 py-0.5 shrink-0">Default</span>
              {/if}
            </div>
            <div class="text-sm text-text-3 truncate">
              {catalog ? `${catalog.videos.length} video${catalog.videos.length === 1 ? '' : 's'}` : 'Not loaded'} · {url}
            </div>
          </div>
          {#if !isDefault}
            <button class="btn-ghost btn-circle shrink-0" title="Remove" onclick={() => removeCatalog(url)} disabled={busy}>
              <span class="i-lucide-trash-2 text-lg"></span>
            </button>
          {/if}
        </div>
      {/each}
    </div>
  {:else if $videoCatalogsStore.loading}
    <div class="py-10 flex justify-center text-text-3">
      <span class="i-lucide-loader-2 animate-spin text-xl"></span>
    </div>
  {:else}
    <div class="text-text-3 py-10 text-center">No catalogs</div>
  {/if}
</div>
