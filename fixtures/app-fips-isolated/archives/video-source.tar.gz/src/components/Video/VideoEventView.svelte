<script lang="ts">
  /**
   * VideoEventView - a video hosted outside hashtree
   * Another app published it as a NIP-71 video event that points at a web URL.
   */
  import { nostr } from '../../nostr';
  import { queryConfiguredRelaysDirectly } from '../../nostr/directQuery';
  import { blobMirrorUrls, hasBlobUrl, parseExternalVideoRef } from '../../lib/videoEvent';
  import { blobServersStore, requestBlobServers } from '../../stores/blobServers';
  import { webThumbnailCandidateUrls } from '../../lib/webThumbnail';
  import { getVideoItem, ingestVideoEvent, videoEventsStore } from '../../stores/videoEvents';
  import { NO_ENGAGEMENT, watchVideoEngagement, type EventEngagementWatch } from '../../stores/eventEngagement';
  import EventComments from './EventComments.svelte';
  import { formatTimeAgo } from '../../utils/format';
  import { FollowButton } from '../User';
  import ShareButton from '../ShareButton.svelte';
  import FeedSidebar from './FeedSidebar.svelte';
  import VideoDetails from './VideoDetails.svelte';

  interface Props {
    /** `naddr1...`, `note1...` or `nevent1...` naming the video event */
    eventRef?: string;
  }

  let { eventRef }: Props = $props();

  let target = $derived(parseExternalVideoRef(eventRef));
  let video = $derived.by(() => {
    void $videoEventsStore;
    return target ? getVideoItem(target.key) ?? null : null;
  });
  let indexed = $derived(!!video);

  // Not indexed yet (a direct link): ask the relays. The page fills in when the event arrives.
  $effect(() => {
    if (!target || indexed) return;
    const filter = target.id
      ? { ids: [target.id] }
      : { kinds: [target.kind!], authors: [target.pubkey!], '#d': [target.dTag!] };
    const subscription = nostr.subscribe(filter);
    subscription.on('event', (event) => { ingestVideoEvent(event); });
    // A shared link is often the first thing opened: ask the relays directly as well,
    // so the video does not queue behind the worker's startup.
    const stopDirect = queryConfiguredRelaysDirectly([filter], (event) => { ingestVideoEvent(event); }, 8000);
    return () => {
      subscription.stop();
      stopDirect();
    };
  });

  // Say so when nothing turns up, rather than leaving an empty player forever.
  let lookupExpired = $state(false);
  $effect(() => {
    if (indexed) return;
    const timer = setTimeout(() => { lookupExpired = true; }, 8000);
    return () => clearTimeout(timer);
  });

  // The event may list several copies of the file: try the next when one fails.
  let sourceIndex = $state(0);
  let warningAccepted = $state(false);
  // A file named by its hash may live on the author's other file servers too. When the
  // copies the event lists have all failed, the author's server list is looked up and
  // those servers are tried.
  $effect(() => {
    const listed = video?.videoUrls ?? [];
    if (video?.ownerPubkey && hasBlobUrl(listed) && sourceIndex >= listed.length) requestBlobServers(video.ownerPubkey);
  });
  let sources = $derived.by(() => {
    const listed = video?.videoUrls ?? [];
    const servers = video?.ownerPubkey ? $blobServersStore[video.ownerPubkey] : undefined;
    return servers ? [...listed, ...blobMirrorUrls(listed, servers)] : listed;
  });
  let source = $derived(sources[sourceIndex] ?? null);

  // A file server that never answers would hold the player forever: after a while
  // the next copy is tried, when there is one.
  const SOURCE_TIMEOUT_MS = 8000;
  let loadedSource = $state<string | null>(null);
  $effect(() => {
    const current = source;
    if (!current || sourceIndex >= sources.length - 1) return;
    const timer = setTimeout(() => {
      if (loadedSource !== current) sourceIndex += 1;
    }, SOURCE_TIMEOUT_MS);
    return () => clearTimeout(timer);
  });
  let poster = $derived(webThumbnailCandidateUrls(video?.thumbnailUrl, 1280, 720)?.[0] ?? undefined);
  let showWarning = $derived(!!video?.sensitive && !warningAccepted);

  // Likes and comments other Nostr apps can read and write too.
  let engagement = $state(NO_ENGAGEMENT);
  let engagementWatch = $state<EventEngagementWatch | null>(null);
  let videoKey = $derived(video?.key ?? null);

  $effect(() => {
    if (!videoKey) return;
    const watch = watchVideoEngagement(videoKey);
    if (!watch) return;
    engagementWatch = watch;
    const unsubscribe = watch.subscribe((value) => { engagement = value; });
    return () => {
      unsubscribe();
      watch.stop();
      engagementWatch = null;
      engagement = NO_ENGAGEMENT;
    };
  });

  function toggleLike(): void {
    void engagementWatch?.toggleLike().catch((error) => { console.error('Failed to like:', error); });
  }

  async function postComment(text: string, parentId?: string): Promise<void> {
    await engagementWatch?.comment(text, parentId);
  }
</script>

{#snippet ownerActions()}
  {#if video}
    <FollowButton pubkey={video.ownerPubkey!} />
  {/if}
{/snippet}

{#snippet pageActions()}
  <button
    class="btn-ghost p-2 flex items-center gap-1"
    class:text-accent={engagement.liked}
    title={engagement.liked ? 'Liked' : 'Like'}
    aria-label="Like"
    aria-pressed={engagement.liked}
    data-testid="event-like"
    disabled={!engagementWatch}
    onclick={toggleLike}
  >
    <span class="i-lucide-heart text-lg"></span>
    {#if engagement.likes > 0}
      <span class="text-sm">{engagement.likes}</span>
    {/if}
  </button>
  <ShareButton url={window.location.href} />
{/snippet}

<div class="flex-1 overflow-y-auto pb-4">
  <div class="flex max-w-7xl mx-auto">
    <div class="flex-1 min-w-0 lg:px-4 lg:pt-3">
      <div
        class="w-full mx-auto aspect-video max-h-[calc(100vh-180px)] bg-black lg:rounded-xl lg:overflow-hidden flex items-center justify-center"
        data-testid="external-video-player"
      >
        {#if !target}
          <p class="text-text-3">This link does not name a video.</p>
        {:else if showWarning}
          <div class="text-center px-4">
            <p class="text-text-2 mb-3">The author marked this video with a content warning.</p>
            <button class="btn-primary px-4 py-2" onclick={() => { warningAccepted = true; }}>Show video</button>
          </div>
        {:else if source}
          {#key source}
            <!-- svelte-ignore a11y_media_has_caption -->
            <video
              class="w-full h-full"
              src={source}
              {poster}
              controls
              autoplay
              playsinline
              onerror={() => { sourceIndex += 1; }}
              onloadedmetadata={() => { loadedSource = source; }}
            ></video>
          {/key}
        {:else if video}
          <p class="text-text-3">This video could not be played.</p>
        {:else if lookupExpired}
          <p class="text-text-3">Video not found.</p>
        {/if}
      </div>

      <div class="px-4 py-4">
        {#if video}
          <VideoDetails
            title={video.title}
            ownerHref={`#/${video.ownerNpub}`}
            ownerPubkey={video.ownerPubkey}
            {ownerActions}
            {pageActions}
            description={video.description ?? ''}
            descriptionTimestamp={formatTimeAgo(video.timestamp ?? 0)}
          />
          <div class="mt-6 -mx-4 b-t-1 b-t-solid b-t-surface-3">
            <EventComments comments={engagement.comments} onSubmit={postComment} />
          </div>
        {/if}
      </div>
    </div>

    <div class="w-96 shrink-0 hidden lg:block overflow-y-auto py-3">
      <FeedSidebar currentHref={video?.href} />
    </div>
  </div>

  <div class="lg:hidden pb-4">
    <FeedSidebar currentHref={video?.href} />
  </div>
</div>
