<script lang="ts">
  /**
   * RichTextSegments - text with its links, pictures, mentions, references and
   * hashtags made useful. Renders inline: wrap it in the paragraph it belongs to.
   */
  import { shortRef, type RichTextSegment } from '../lib/richText';
  import { Name } from './User';
  import ProxyImg from './ProxyImg.svelte';

  interface Props {
    segments: RichTextSegment[];
    /** Show pictures in place; otherwise they are plain links. */
    images?: boolean;
    /** Called for a timestamp in a video description. Without it timestamps are plain text. */
    onTimestamp?: (seconds: number) => void;
  }

  let { segments, images = true, onTimestamp }: Props = $props();

  function linkLabel(url: string): string {
    const label = url.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '');
    return label.length > 60 ? `${label.slice(0, 57)}…` : label;
  }

  const stop = (event: Event) => event.stopPropagation();
</script>

{#each segments as segment, index (index)}{#if segment.type === 'text'}{segment.text}{:else if segment.type === 'link' || (segment.type === 'image' && !images)}<a
      href={segment.url}
      target="_blank"
      rel="noopener noreferrer"
      class="text-accent no-underline hover:underline"
      onclick={stop}
    >{linkLabel(segment.url)}</a>{:else if segment.type === 'image'}<a
      href={segment.url}
      target="_blank"
      rel="noopener noreferrer"
      class="block my-2 w-fit max-w-full"
      data-testid="rich-text-image"
      onclick={stop}
    ><ProxyImg src={segment.url} width={800} alt="" class="block max-h-72 max-w-full rounded-lg" /></a>{:else if segment.type === 'mention'}<a
      href={`#/${segment.npub}`}
      class="inline-flex items-baseline max-w-full text-accent no-underline hover:underline"
      data-testid="rich-text-mention"
      onclick={stop}
    >@<Name pubkey={segment.pubkey} /></a>{:else if segment.type === 'event'}<a
      href={segment.href ?? `https://iris.to/${segment.bech32}`}
      target={segment.href ? undefined : '_blank'}
      rel={segment.href ? undefined : 'noopener noreferrer'}
      class="text-accent no-underline hover:underline"
      onclick={stop}
    >{shortRef(segment.bech32)}</a>{:else if segment.type === 'hashtag'}<a
      href={`#/t/${encodeURIComponent(segment.tag)}`}
      class="text-accent no-underline hover:underline"
      data-testid="rich-text-hashtag"
      onclick={stop}
    >#{segment.tag}</a>{:else if segment.type === 'timestamp'}{#if onTimestamp}<button
        class="text-accent hover:underline cursor-pointer bg-transparent b-0 p-0 font-inherit"
        onclick={(event) => { event.stopPropagation(); onTimestamp(segment.seconds); }}
      >{segment.display}</button>{:else}{segment.display}{/if}{/if}{/each}
