/**
 * Text search on relays (NIP-50).
 *
 * Several relays reject a whole request when one of its filters carries
 * `search`, and the worker sends requests made close together as one, so a
 * search sent the usual way takes unrelated lookups down with it. Text searches
 * therefore go straight to the relays (`directQuery`), and only to those of the
 * viewer's relays that say they support search (their NIP-11 document).
 * Nothing waits for any of it: matches are handed over as they arrive.
 */
import { get } from 'svelte/store';
import type { Event, Filter } from 'nostr-tools';
import { queryRelaysDirectly } from './directQuery';
import { getEffectiveNostrRelays } from '../lib/runtimeNetwork';
import { settingsStore } from '../stores/settings';

const INFO_TIMEOUT_MS = 4000;
const TEXT_SEARCH_NIP = 50;

const searchSupport = new Map<string, Promise<boolean>>();

/** `wss://host/path` → the `https://` address its NIP-11 document is served from. */
export function relayInfoUrl(relayUrl: string): string | null {
  try {
    const url = new URL(relayUrl);
    if (url.protocol !== 'wss:' && url.protocol !== 'ws:') return null;
    url.protocol = url.protocol === 'wss:' ? 'https:' : 'http:';
    return url.href;
  } catch {
    return null;
  }
}

/** Whether a relay advertises text search. Asked once per relay per visit. */
function supportsTextSearch(relayUrl: string): Promise<boolean> {
  let known = searchSupport.get(relayUrl);
  if (!known) {
    const infoUrl = relayInfoUrl(relayUrl);
    known = !infoUrl ? Promise.resolve(false) : (async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), INFO_TIMEOUT_MS);
      try {
        const response = await fetch(infoUrl, { headers: { Accept: 'application/nostr+json' }, signal: controller.signal });
        const info = await response.json() as { supported_nips?: unknown };
        return Array.isArray(info.supported_nips) && info.supported_nips.includes(TEXT_SEARCH_NIP);
      } catch {
        return false;
      } finally {
        clearTimeout(timer);
      }
    })();
    searchSupport.set(relayUrl, known);
  }
  return known;
}

/**
 * Ask the relays that support it for events matching `filters` (each carrying
 * `search`). Returns a function that ends the search.
 */
export function searchRelays(filters: Filter[], onEvent: (event: Event) => void, listenMs: number): () => void {
  let stopped = false;
  const stops: Array<() => void> = [];
  for (const relay of getEffectiveNostrRelays(get(settingsStore).network.relays)) {
    void supportsTextSearch(relay).then((supported) => {
      if (supported && !stopped) stops.push(queryRelaysDirectly([relay], filters, onEvent, listenMs));
    });
  }
  return () => {
    stopped = true;
    for (const stop of stops) stop();
  };
}
