/**
 * Image proxy utility for proxying external images through imgproxy
 * Used for avatars, banners, thumbnails and other external images
 * Based on iris-client implementation
 */
import { hmac } from '@noble/hashes/hmac.js';
import { sha256 } from '@noble/hashes/sha2.js';

export interface ImgProxyConfig {
  url: string;
  key: string;
  salt: string;
}

export interface ImgProxyOptions {
  width?: number;
  height?: number;
  /** If true, use fill mode (crop to fill); if false, use fit mode (contain) */
  square?: boolean;
}

// Default imgproxy configuration (same as iris-client)
export const DEFAULT_IMGPROXY_CONFIG: ImgProxyConfig = {
  url: 'https://imgproxy.iris.to',
  key: 'f66233cb160ea07078ff28099bfa3e3e654bc10aa4a745e12176c433d79b8996',
  salt: '5e608e60945dcd2a787e8465d76ba34149894765061d39287609fb9d776caa0c',
};

// URL-safe base64 encoding
function urlSafeBase64(bytes: Uint8Array): string {
  const binString = Array.from(bytes, (byte) => String.fromCodePoint(byte)).join('');
  return btoa(binString).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function hexToBytes(hex: string): Uint8Array {
  if (!/^(?:[0-9a-f]{2})+$/i.test(hex)) throw new Error('Image proxy key and salt must be hex');
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

function concatBytes(...arrays: Uint8Array[]): Uint8Array {
  const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const arr of arrays) {
    result.set(arr, offset);
    offset += arr.length;
  }
  return result;
}

// Sign the path using HMAC-SHA256
function signUrl(path: string, key: string, salt: string): string {
  const data = concatBytes(hexToBytes(salt), new TextEncoder().encode(path));
  return urlSafeBase64(hmac(sha256, hexToBytes(key), data));
}

// Signing is cheap but runs for every image on every render: remember the results.
const urlCache = new Map<string, string>();
const URL_CACHE_LIMIT = 2000;

/**
 * Generate a proxied image URL.
 * Signing is synchronous, so the very first render of an image already goes
 * through the proxy and its original host never sees the viewer.
 * @param originalSrc Original image URL
 * @param options Resize options
 * @param config Custom imgproxy config (optional)
 * @returns Proxied URL, or the original when it cannot or need not be proxied
 */
export function generateProxyUrl(
  originalSrc: string,
  options: ImgProxyOptions = {},
  config: ImgProxyConfig = DEFAULT_IMGPROXY_CONFIG
): string {
  // Skip if already proxied or is a data URL or blob URL
  if (
    originalSrc.startsWith(config.url) ||
    originalSrc.startsWith('data:') ||
    originalSrc.startsWith('blob:')
  ) {
    return originalSrc;
  }

  // Only web images can be fetched by the proxy
  try {
    const { protocol } = new URL(originalSrc);
    if (protocol !== 'https:' && protocol !== 'http:') return originalSrc;
  } catch {
    return originalSrc;
  }

  const cacheKey = `${config.url}:${config.key}:${originalSrc}:${options.width}:${options.height}:${options.square}`;
  const cached = urlCache.get(cacheKey);
  if (cached) return cached;

  try {
    const encodedUrl = urlSafeBase64(new TextEncoder().encode(originalSrc));

    const opts: string[] = [];
    if (options.width || options.height) {
      const resizeType = options.square ? 'fill' : 'fit';
      const w = options.width || options.height!;
      const h = options.height || options.width!;
      opts.push(`rs:${resizeType}:${w}:${h}`);
    }
    opts.push('dpr:2');

    const path = `/${opts.join('/')}/${encodedUrl}`;
    const result = `${config.url.replace(/\/+$/, '')}/${signUrl(path, config.key, config.salt)}${path}`;

    if (urlCache.size >= URL_CACHE_LIMIT) urlCache.clear();
    urlCache.set(cacheKey, result);
    return result;
  } catch (e) {
    console.error('Failed to generate proxy URL:', e);
    return originalSrc;
  }
}
