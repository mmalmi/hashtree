// Nostr Event Kinds Constants
// Based on NIPs (Nostr Implementation Possibilities)
// Only includes constants that are actually used in the codebase

const TEST_BOOTSTRAP_PUBKEY = import.meta.env.VITE_TEST_BOOTSTRAP_PUBKEY as string | undefined;
// Default content/social graph bootstrap pubkey (sirius)
export const DEFAULT_BOOTSTRAP_PUBKEY =
  import.meta.env.VITE_TEST_MODE && TEST_BOOTSTRAP_PUBKEY
    ? TEST_BOOTSTRAP_PUBKEY
    : '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';

// Seed pubkeys to populate the video feed when follows are empty (the Vidi channel).
export const DEFAULT_VIDEO_FEED_PUBKEYS = [
  'd236e8b095ce72fdfc477ffcf23ace7246160b355f857bac58c40970f4089475',
];

// NIP-01: Basic protocol
export const KIND_TEXT_NOTE = 1 // Text note

// NIP-25: Reactions
export const KIND_EXTERNAL_CONTENT_REACTION: number = 17

// NIP-57: Lightning zaps
export const KIND_ZAP_RECEIPT = 9735

// NIP-34: Git Repositories
export const KIND_REPO_ANNOUNCEMENT: number = 30617 // Repository announcement
export const KIND_PULL_REQUEST: number = 1618 // Pull request
export const KIND_ISSUE: number = 1621 // Issue (bug report, feature request)
// Status events (1630-1633)
export const KIND_STATUS_OPEN: number = 1630 // Open/default
export const KIND_STATUS_APPLIED: number = 1631 // Applied/Merged/Resolved
export const KIND_STATUS_CLOSED: number = 1632 // Closed
export const KIND_STATUS_DRAFT: number = 1633 // Draft
