/**
 * Likes and comments on a video event, the way other Nostr apps read and write them:
 * NIP-25 reactions (kind 7) and NIP-22 comments (kind 1111) that name the event.
 * Many apps answer a video with an ordinary reply note instead (kind 1, NIP-10);
 * those are read as comments too. New comments are written as kind 1111.
 * Pure: building filters and events, and tallying what arrives.
 */
import type { EventTemplate, Filter } from 'nostr-tools';

export const REACTION_KIND = 7;
export const COMMENT_KIND = 1111;
/** A text note; one that replies to the video is a comment from an app without NIP-22. */
export const NOTE_KIND = 1;
const DELETION_KIND = 5;
const LOOKUP_LIMIT = 200;

export interface EngagementTarget {
  kind: number;
  pubkey: string;
  /** Event id; an addressable event is also named by its address. */
  id?: string;
  dTag?: string;
}

export interface EventComment {
  id: string;
  pubkey: string;
  content: string;
  createdAt: number;
  /** 1111 (a NIP-22 comment) or 1 (a reply note). A reply is written the same way as what it answers. */
  kind: number;
  /** The comment this one answers; absent when it answers the video itself. */
  parentId?: string;
}

export interface CommentThread {
  comment: EventComment;
  /** Everything said underneath, oldest first, whatever it answered within the thread. */
  replies: EventComment[];
}

/**
 * Group comments the way video sites show them: comments on the video newest
 * first, each with the replies underneath it in the order they were written.
 * A reply whose parent has not arrived is listed as a comment of its own.
 */
export function threadComments(comments: readonly EventComment[]): CommentThread[] {
  const byId = new Map(comments.map((comment) => [comment.id, comment]));
  const rootOf = (comment: EventComment): EventComment => {
    let current = comment;
    const visited = new Set<string>();
    while (current.parentId && byId.has(current.parentId) && !visited.has(current.id)) {
      visited.add(current.id);
      current = byId.get(current.parentId)!;
    }
    return current;
  };
  const threads = new Map<string, CommentThread>();
  for (const comment of comments) {
    const root = rootOf(comment);
    let thread = threads.get(root.id);
    if (!thread) threads.set(root.id, thread = { comment: root, replies: [] });
    if (comment !== root) thread.replies.push(comment);
  }
  for (const thread of threads.values()) thread.replies.sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
  return [...threads.values()].sort((a, b) => b.comment.createdAt - a.comment.createdAt || a.comment.id.localeCompare(b.comment.id));
}

/** The comment an incoming comment or reply note answers, or undefined when it answers the video. */
function parentCommentId(event: IncomingEvent, target: EngagementTarget): string | undefined {
  const tags = event.tags ?? [];
  const others = tags.filter((tag) => tag[0] === 'e' && tag[1] && tag[1] !== target.id && tag[3] !== 'mention');
  if (event.kind === COMMENT_KIND) return others[0]?.[1];
  // NIP-10: the tag marked "reply" names the parent; older notes list the parent last.
  return (others.find((tag) => tag[3] === 'reply') ?? others.filter((tag) => tag[3] !== 'root').at(-1))?.[1];
}

interface IncomingEvent {
  id?: string;
  kind: number;
  pubkey: string;
  content: string;
  created_at: number;
  tags?: string[][];
}

/**
 * Whether a text note replies to the video (to it directly or within its thread),
 * rather than merely mentioning or quoting it.
 */
export function isReplyNote(event: IncomingEvent, target: EngagementTarget): boolean {
  if (event.kind !== NOTE_KIND) return false;
  const address = engagementAddress(target);
  return (event.tags ?? []).some((tag) => (
    ((tag[0] === 'e' && !!target.id && tag[1] === target.id) || (tag[0] === 'a' && !!address && tag[1] === address))
    && tag[3] !== 'mention'
  ));
}

/** `kind:pubkey:d` for an addressable event, null for a regular one. */
export function engagementAddress(target: EngagementTarget): string | null {
  const addressable = target.kind >= 30000 && target.kind < 40000;
  return addressable && target.dTag ? `${target.kind}:${target.pubkey}:${target.dTag}` : null;
}

/** One request's worth of filters: reactions and comments on the event, replies to those comments included. */
export function engagementFilters(target: EngagementTarget): Filter[] {
  const filters: Filter[] = [];
  if (target.id) {
    filters.push(
      { kinds: [REACTION_KIND, COMMENT_KIND, NOTE_KIND], '#e': [target.id], limit: LOOKUP_LIMIT },
      { kinds: [COMMENT_KIND], '#E': [target.id], limit: LOOKUP_LIMIT },
    );
  }
  const address = engagementAddress(target);
  if (address) {
    filters.push(
      { kinds: [REACTION_KIND, COMMENT_KIND, NOTE_KIND], '#a': [address], limit: LOOKUP_LIMIT },
      { kinds: [COMMENT_KIND], '#A': [address], limit: LOOKUP_LIMIT },
    );
  }
  return filters;
}

export function reactionTemplate(target: EngagementTarget, now: number): EventTemplate {
  const address = engagementAddress(target);
  return {
    kind: REACTION_KIND,
    created_at: now,
    content: '+',
    tags: [
      ...(target.id ? [['e', target.id, '', target.pubkey]] : []),
      ...(address ? [['a', address]] : []),
      ['p', target.pubkey],
      ['k', String(target.kind)],
    ],
  };
}

/**
 * A comment on the video, or a reply to one of its comments.
 *
 * On the video: a NIP-22 comment whose root (upper case) and parent (lower case)
 * are both the video. A reply to such a comment keeps the video as root and names
 * the comment as parent. A reply to a reply note is itself a reply note (NIP-10),
 * as NIP-22 comments are not used to answer kind 1 notes.
 */
export function commentTemplate(target: EngagementTarget, content: string, now: number, parent?: EventComment): EventTemplate {
  const address = engagementAddress(target);
  const kind = String(target.kind);
  if (parent?.kind === NOTE_KIND) {
    return {
      kind: NOTE_KIND,
      created_at: now,
      content,
      tags: [
        ...(target.id ? [['e', target.id, '', 'root', target.pubkey]] : []),
        ...(address ? [['a', address, '', 'root']] : []),
        ['e', parent.id, '', 'reply', parent.pubkey],
        ['p', target.pubkey],
        ...(parent.pubkey !== target.pubkey ? [['p', parent.pubkey]] : []),
      ],
    };
  }
  if (parent) {
    return {
      kind: COMMENT_KIND,
      created_at: now,
      content,
      tags: [
        ...(address ? [['A', address]] : []),
        ...(target.id ? [['E', target.id, '', target.pubkey]] : []),
        ['K', kind],
        ['P', target.pubkey],
        ['e', parent.id, '', parent.pubkey],
        ['k', String(COMMENT_KIND)],
        ['p', parent.pubkey],
      ],
    };
  }
  return {
    kind: COMMENT_KIND,
    created_at: now,
    content,
    tags: [
      ...(address ? [['A', address]] : []),
      ...(target.id ? [['E', target.id, '', target.pubkey]] : []),
      ['K', kind],
      ['P', target.pubkey],
      ...(address ? [['a', address]] : []),
      ...(target.id ? [['e', target.id, '', target.pubkey]] : []),
      ['k', kind],
      ['p', target.pubkey],
    ],
  };
}

/** Takes back one of the viewer's own events, such as a like. */
export function deletionTemplate(eventId: string, kind: number, now: number): EventTemplate {
  return { kind: DELETION_KIND, created_at: now, content: '', tags: [['e', eventId], ['k', String(kind)]] };
}

/**
 * What has arrived for one video. A person counts once: their latest reaction
 * decides, and `-` is not a like. Comments are listed newest first.
 */
export class EngagementTally {
  private readonly seen = new Set<string>();
  private readonly reactions = new Map<string, { id: string; createdAt: number; liked: boolean }>();
  private commentList: EventComment[] = [];

  /** `target` is the video: reply notes are only comments when they answer it. */
  constructor(private readonly target?: EngagementTarget) {}

  /** Returns whether anything changed. */
  add(event: IncomingEvent): boolean {
    if (!event.id || this.seen.has(event.id)) return false;
    this.seen.add(event.id);

    if (event.kind === REACTION_KIND) {
      const previous = this.reactions.get(event.pubkey);
      if (previous && previous.createdAt > event.created_at) return false;
      this.reactions.set(event.pubkey, {
        id: event.id,
        createdAt: event.created_at,
        liked: event.content.trim() !== '-',
      });
      return true;
    }
    if (event.kind === COMMENT_KIND || (this.target && isReplyNote(event, this.target))) {
      if (!event.content.trim()) return false;
      const parentId = this.target ? parentCommentId(event, this.target) : undefined;
      const comment: EventComment = {
        id: event.id,
        pubkey: event.pubkey,
        content: event.content,
        createdAt: event.created_at,
        kind: event.kind,
        ...(parentId ? { parentId } : {}),
      };
      const index = this.commentList.findIndex((entry) => entry.createdAt < comment.createdAt);
      this.commentList = index === -1
        ? [...this.commentList, comment]
        : [...this.commentList.slice(0, index), comment, ...this.commentList.slice(index)];
      return true;
    }
    return false;
  }

  /** Forget an event the viewer took back. It stays seen, so a relay repeating it changes nothing. */
  remove(eventId: string): void {
    for (const [pubkey, reaction] of this.reactions) {
      if (reaction.id === eventId) this.reactions.delete(pubkey);
    }
    this.commentList = this.commentList.filter((comment) => comment.id !== eventId);
  }

  get likes(): number {
    let count = 0;
    for (const reaction of this.reactions.values()) if (reaction.liked) count += 1;
    return count;
  }

  /** The id of this person's like, or null when they have not liked the video. */
  likeBy(pubkey: string | null | undefined): string | null {
    const reaction = pubkey ? this.reactions.get(pubkey) : undefined;
    return reaction?.liked ? reaction.id : null;
  }

  get comments(): EventComment[] {
    return this.commentList;
  }
}
