/**
 * NIP-71 video events for hashtree-backed videos.
 *
 * Every public video is announced by its owner as an addressable kind 34235
 * event whose `imeta` URL points into the owner's `videos/...` tree:
 *
 *   htree://<npub>/<encoded tree name>[/<playlist item>]/<video file>
 *
 * The tree root event stays the source of the content; the video event is the
 * index entry (title, summary, duration, thumbnail) relays can serve by author.
 */
import { nip19 } from 'nostr-tools';
import type { Event, EventTemplate } from 'nostr-tools';

/** NIP-71 addressable normal video. */
export const VIDEO_EVENT_KIND = 34235;
/** NIP-71 addressable short video; read alongside normal videos. */
export const SHORT_VIDEO_EVENT_KIND = 34236;
export const VIDEO_EVENT_KINDS: number[] = [VIDEO_EVENT_KIND, SHORT_VIDEO_EVENT_KIND];
/** NIP-71 regular (non-addressable) video kinds, published by other apps. */
export const REGULAR_VIDEO_EVENT_KINDS: number[] = [21, 22];
/** Every video kind the app reads. */
export const ALL_VIDEO_EVENT_KINDS: number[] = [...VIDEO_EVENT_KINDS, ...REGULAR_VIDEO_EVENT_KINDS];
const SHORT_VIDEO_KINDS = new Set([SHORT_VIDEO_EVENT_KIND, 22]);
export const VIDEO_EVENT_DELETE_KIND = 5;
export const VIDEO_EVENT_MAX_SUMMARY_LENGTH = 1200;
export const VIDEO_SITE_URL = 'https://video.iris.to';

const HTREE_SCHEME = 'htree://';
const HTREE_PATH = '/htree/';

const MIME_BY_EXTENSION: Record<string, string> = {
  mp4: 'video/mp4',
  m4v: 'video/mp4',
  webm: 'video/webm',
  mkv: 'video/x-matroska',
  mov: 'video/quicktime',
  avi: 'video/x-msvideo',
  ogv: 'video/ogg',
  '3gp': 'video/3gpp',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  flac: 'audio/flac',
  m4a: 'audio/mp4',
  aac: 'audio/aac',
  ogg: 'audio/ogg',
  oga: 'audio/ogg',
  opus: 'audio/opus',
};

export interface VideoEventInput {
  ownerNpub: string;
  treeName: string;
  /** Playlist item folder inside the tree. */
  videoId?: string;
  title: string;
  description?: string;
  /** Seconds. */
  duration?: number;
  /** Unix seconds of first publication. */
  publishedAt?: number;
  /** Media file name inside the video folder. */
  videoPath?: string;
  /** `htree://...` or `/htree/...` thumbnail. */
  thumbnailUrl?: string;
  width?: number;
  height?: number;
  tags?: string[];
}

export interface VideoEventItem {
  /** `<npub>/<treeName>[/<videoId>]`, or `event:<address or id>` for a video hosted elsewhere. */
  key: string;
  title: string;
  description?: string;
  duration?: number;
  /** Unix seconds: `published_at`, else the event time. */
  timestamp: number;
  /** Event `created_at`; newer replaces older. */
  updatedAt: number;
  ownerPubkey: string;
  ownerNpub: string;
  /** Empty for a video hosted outside hashtree. */
  treeName: string;
  videoId?: string;
  videoPath?: string;
  /** App-relative `/htree/...` thumbnail, or an `https://` one for a video hosted elsewhere. */
  thumbnailUrl?: string;
  /** Playable `https://` URLs, best first, for a video hosted outside hashtree. */
  videoUrls?: string[];
  /** Short-form (vertical clip) video. */
  short?: boolean;
  /** What the file is, for telling apart an author's repeat posts of one video: its hash, else its URL. */
  contentId?: string;
  /** The author marked it with a content warning. */
  sensitive?: boolean;
  tags: string[];
  href: string;
  /** Empty for regular (non-addressable) events. */
  dTag: string;
  kind: number;
  eventId?: string;
}

export type VideoEventLike = Pick<Event, 'kind' | 'pubkey' | 'created_at' | 'tags' | 'content'> & { id?: string };

function readString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function readPositiveNumber(value: unknown): number | undefined {
  const parsed = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function encodePath(segments: string[]): string {
  return segments.map((segment) => encodeURIComponent(segment)).join('/');
}

export function npubToPubkey(npub: string | null | undefined): string | null {
  if (!npub?.startsWith('npub1')) return null;
  try {
    const decoded = nip19.decode(npub);
    return decoded.type === 'npub' ? decoded.data : null;
  } catch {
    return null;
  }
}

export function pubkeyToNpub(pubkey: string | null | undefined): string | null {
  if (!pubkey || !/^[0-9a-f]{64}$/i.test(pubkey)) return null;
  try {
    return nip19.npubEncode(pubkey.toLowerCase());
  } catch {
    return null;
  }
}

export function videoKey(ownerNpub: string, treeName: string, videoId?: string | null): string {
  return videoId ? `${ownerNpub}/${treeName}/${videoId}` : `${ownerNpub}/${treeName}`;
}

export function videoEventDTag(treeName: string, videoId?: string | null): string {
  return videoId ? `${treeName}/${videoId}` : treeName;
}

export function videoHref(ownerNpub: string, treeName: string, videoId?: string | null): string {
  const base = `#/${ownerNpub}/${encodeURIComponent(treeName)}`;
  return videoId ? `${base}/${encodeURIComponent(videoId)}` : base;
}

export function videoMimeType(fileName: string | undefined): string | undefined {
  const extension = fileName?.split('.').pop()?.toLowerCase();
  return extension ? MIME_BY_EXTENSION[extension] : undefined;
}

/** `htree://npub/tree/...` URL for a file inside a video tree. */
export function videoHtreeUrl(ownerNpub: string, treeName: string, videoId?: string | null, videoPath?: string | null): string {
  const rest = [videoId, videoPath].filter((part): part is string => !!part);
  return `${HTREE_SCHEME}${ownerNpub}/${encodeURIComponent(treeName)}${rest.length ? `/${encodePath(rest)}` : ''}`;
}

/** Strip an origin or scheme down to the hashtree path (`npub.../tree/file` or `nhash.../file`). */
function htreeResourcePath(url: string | undefined): string | undefined {
  const value = readString(url);
  if (!value) return undefined;
  if (value.startsWith(HTREE_SCHEME)) return value.slice(HTREE_SCHEME.length).replace(/^\/+/, '') || undefined;
  const index = value.indexOf(HTREE_PATH);
  if (index === -1) return undefined;
  return value.slice(index + HTREE_PATH.length).split(/[?#]/)[0] || undefined;
}

/** Portable `htree://` form for publishing. */
export function toHtreeUrl(url: string | undefined): string | undefined {
  const path = htreeResourcePath(url);
  return path ? `${HTREE_SCHEME}${path}` : undefined;
}

/** App-relative `/htree/...` form for rendering. */
export function toAppHtreeUrl(url: string | undefined): string | undefined {
  const path = htreeResourcePath(url);
  return path ? `${HTREE_PATH}${path}` : undefined;
}

/**
 * App-relative URL of a hashtree thumbnail. One named by its hash alone gets an
 * image file name: the worker serves a bare hash only when the path says what
 * kind of file to expect, and then checks that the bytes really are an image.
 */
export function toAppThumbnailUrl(url: string | undefined): string | undefined {
  const appUrl = toAppHtreeUrl(url);
  return appUrl && /^\/htree\/nhash1[a-z0-9]+$/.test(appUrl) ? `${appUrl}/thumbnail.jpg` : appUrl;
}

export function parseVideoHtreeUrl(url: string | undefined): {
  ownerNpub: string;
  treeName: string;
  videoId?: string;
  videoPath?: string;
} | null {
  const path = htreeResourcePath(url);
  if (!path) return null;
  const [ownerNpub, encodedTreeName, ...rest] = path.split('/').filter(Boolean);
  if (!ownerNpub?.startsWith('npub1') || !encodedTreeName) return null;
  const treeName = safeDecode(encodedTreeName);
  if (!treeName.startsWith('videos/')) return null;
  const segments = rest.map(safeDecode);
  const videoPath = segments.pop();
  return {
    ownerNpub,
    treeName,
    ...(segments.length ? { videoId: segments.join('/') } : {}),
    ...(videoPath ? { videoPath } : {}),
  };
}

function normalizeTags(values: readonly unknown[] | undefined): string[] {
  const seen = new Set<string>();
  for (const value of values ?? []) {
    const tag = readString(value)?.toLowerCase();
    if (tag) seen.add(tag);
  }
  return [...seen];
}

function truncateSummary(value: string | undefined): string {
  const text = value?.trim() ?? '';
  return text.length > VIDEO_EVENT_MAX_SUMMARY_LENGTH ? text.slice(0, VIDEO_EVENT_MAX_SUMMARY_LENGTH).trim() : text;
}

export function buildVideoEventTemplate(input: VideoEventInput, createdAt = Math.floor(Date.now() / 1000)): EventTemplate {
  const title = input.title.trim();
  const duration = readPositiveNumber(input.duration);
  const publishedAt = readPositiveNumber(input.publishedAt);
  const thumbnailUrl = toHtreeUrl(input.thumbnailUrl);
  const mimeType = videoMimeType(input.videoPath);
  const width = readPositiveNumber(input.width);
  const height = readPositiveNumber(input.height);

  const imeta = [
    'imeta',
    `url ${videoHtreeUrl(input.ownerNpub, input.treeName, input.videoId, input.videoPath)}`,
    ...(mimeType ? [`m ${mimeType}`] : []),
    ...(width && height ? [`dim ${Math.round(width)}x${Math.round(height)}`] : []),
    ...(thumbnailUrl ? [`image ${thumbnailUrl}`] : []),
    ...(duration ? [`duration ${duration}`] : []),
  ];

  return {
    kind: VIDEO_EVENT_KIND,
    created_at: createdAt,
    content: truncateSummary(input.description),
    tags: [
      ['d', videoEventDTag(input.treeName, input.videoId)],
      ['title', title],
      ...(publishedAt ? [['published_at', `${Math.floor(publishedAt)}`]] : []),
      ['alt', `Video: ${title}`],
      ...(duration ? [['duration', `${Math.round(duration)}`]] : []),
      imeta,
      ['r', `${VIDEO_SITE_URL}/${videoHref(input.ownerNpub, input.treeName, input.videoId)}`],
      ...normalizeTags(input.tags).map((tag) => ['t', tag]),
    ],
  };
}

function imetaFields(tag: string[]): Map<string, string> {
  const fields = new Map<string, string>();
  for (const entry of tag.slice(1)) {
    const space = entry.indexOf(' ');
    if (space <= 0) continue;
    const name = entry.slice(0, space);
    if (!fields.has(name)) fields.set(name, entry.slice(space + 1).trim());
  }
  return fields;
}

const BROWSER_VIDEO_EXTENSIONS = /\.(mp4|m4v|webm|mov|ogv)$/i;
const STREAM_PLAYLIST = /\.(m3u8|mpd)$/i;

function httpUrl(value: string | undefined): string | undefined {
  const text = readString(value);
  if (!text) return undefined;
  try {
    const url = new URL(text);
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : undefined;
  } catch {
    return undefined;
  }
}

/** A file named by its hash, as Blossom servers store it: `/<sha256>[.ext]`. */
const BLOB_PATH = /^\/[0-9a-f]{64}(\.[a-z0-9]+)?$/i;

/**
 * Further places to look for hash-named files: the same path on the other file
 * servers the event mentions. A hash names the same bytes everywhere, and authors
 * commonly keep copies on several servers of which one may be down.
 */
export function blobMirrorUrls(urls: readonly string[], serverOrigins: Iterable<string>): string[] {
  const mirrors: string[] = [];
  for (const value of urls) {
    const url = new URL(value);
    if (!BLOB_PATH.test(url.pathname)) continue;
    for (const origin of serverOrigins) {
      const mirror = `${origin}${url.pathname}`;
      if (origin !== url.origin && !urls.includes(mirror) && !mirrors.includes(mirror)) mirrors.push(mirror);
    }
  }
  return mirrors;
}

/** Whether any of the URLs names a file by its hash, so copies may exist on the author's other file servers. */
export function hasBlobUrl(urls: readonly string[] | undefined): boolean {
  return !!urls?.some((value) => {
    try {
      return BLOB_PATH.test(new URL(value).pathname);
    } catch {
      return false;
    }
  });
}

/** 0 = plays in any browser, 1 = probably, -1 = a stream playlist most browsers cannot play. */
function playability(url: string, mimeType: string | undefined): number {
  const path = new URL(url).pathname;
  if (STREAM_PLAYLIST.test(path) || /mpegurl|dash\+xml/i.test(mimeType ?? '')) return -1;
  if (BROWSER_VIDEO_EXTENSIONS.test(path) || /^video\/(mp4|webm|quicktime|ogg)/i.test(mimeType ?? '')) return 0;
  return mimeType && !mimeType.startsWith('video/') ? -1 : 1;
}

/**
 * Link to a video that is not in a hashtree tree: `#/v/<naddr|note>`, or
 * `#/shorts/<naddr|note>` for a short, which opens in the shorts viewer.
 */
export function externalVideoHref(
  event: { kind: number; pubkey: string; id?: string },
  dTag: string | undefined,
  short = false,
): string | null {
  const page = short ? 'shorts' : 'v';
  try {
    if (dTag !== undefined) return `#/${page}/${nip19.naddrEncode({ kind: event.kind, pubkey: event.pubkey, identifier: dTag })}`;
    return event.id ? `#/${page}/${nip19.noteEncode(event.id)}` : null;
  } catch {
    return null;
  }
}

/** A video another app published: hosted on the web, described by `imeta` (or legacy `url`) tags. */
function parseExternalVideoEvent(event: VideoEventLike, ownerPubkey: string, ownerNpub: string): VideoEventItem | null {
  const tagValue = (name: string) => readString(event.tags.find((tag) => tag[0] === name)?.[1]);
  const addressable = VIDEO_EVENT_KINDS.includes(event.kind);
  const dTag = addressable ? tagValue('d') : undefined;
  if (addressable ? !dTag : !event.id) return null;

  const sources: Array<{ url: string; rank: number }> = [];
  const blobServers = new Set<string>();
  let fileHash: string | undefined;
  let thumbnailUrl: string | undefined;
  let duration: number | undefined;
  let portrait = false;
  const addSource = (value: string | undefined, mimeType?: string) => {
    const url = httpUrl(value);
    if (!url || sources.some((source) => source.url === url)) return;
    const rank = playability(url, mimeType);
    if (rank >= 0) sources.push({ url, rank });
  };
  for (const tag of event.tags) {
    if (tag[0] !== 'imeta') continue;
    const fields = imetaFields(tag);
    addSource(fields.get('url'), fields.get('m'));
    if (sources.length > 0 && /^[0-9a-f]{64}$/i.test(fields.get('x') ?? '')) fileHash ??= fields.get('x')!.toLowerCase();
    for (const entry of tag.slice(1)) {
      if (entry.startsWith('fallback ')) addSource(entry.slice('fallback '.length), fields.get('m'));
      const mentioned = httpUrl(entry.slice(entry.indexOf(' ') + 1));
      if (mentioned && BLOB_PATH.test(new URL(mentioned).pathname)) blobServers.add(new URL(mentioned).origin);
    }
    thumbnailUrl ??= httpUrl(fields.get('image')) ?? toAppThumbnailUrl(fields.get('image'));
    duration ??= readPositiveNumber(fields.get('duration'));
    const [width, height] = (fields.get('dim') ?? '').split('x').map(Number);
    if (width > 0 && height > width) portrait = true;
  }
  addSource(tagValue('url'), tagValue('m'));
  if (sources.length === 0) return null;
  sources.sort((a, b) => a.rank - b.rank);
  const videoUrls = sources.map((source) => source.url);
  videoUrls.push(...blobMirrorUrls(videoUrls, blobServers));
  const short = SHORT_VIDEO_KINDS.has(event.kind) || portrait;
  const href = externalVideoHref({ kind: event.kind, pubkey: ownerPubkey, id: event.id }, dTag, short);
  if (!href) return null;

  thumbnailUrl ??= httpUrl(tagValue('thumb')) ?? httpUrl(tagValue('image'));
  duration ??= readPositiveNumber(tagValue('duration'));
  const content = readString(event.content);
  const summary = tagValue('summary') ?? content;
  const title = tagValue('title')
    ?? tagValue('alt')
    ?? content?.split('\n')[0]?.slice(0, 100)
    ?? 'Untitled video';
  const createdAt = Math.floor(event.created_at ?? 0);
  const address = dTag !== undefined ? `${event.kind}:${ownerPubkey}:${dTag}` : event.id!;

  return {
    key: `event:${address}`,
    title,
    ...(summary && summary !== title ? { description: summary } : {}),
    ...(duration ? { duration } : {}),
    timestamp: Math.floor(readPositiveNumber(tagValue('published_at')) ?? createdAt),
    updatedAt: createdAt,
    ownerPubkey,
    ownerNpub,
    treeName: '',
    ...(thumbnailUrl ? { thumbnailUrl } : {}),
    videoUrls,
    contentId: fileHash ?? sources[0].url,
    ...(short ? { short: true } : {}),
    ...(event.tags.some((tag) => tag[0] === 'content-warning') ? { sensitive: true } : {}),
    tags: normalizeTags(event.tags.filter((entry) => entry[0] === 't').map((entry) => entry[1])),
    href,
    dTag: dTag ?? '',
    kind: event.kind,
    ...(event.id ? { eventId: event.id } : {}),
  };
}

/**
 * Drop an author's repeat posts of the same file, which importers leave behind
 * when they run twice. The earliest post stays: links, likes and comments made
 * so far point at it, and a later repeat does not move it.
 */
export function withoutRepeatPosts<T extends Pick<VideoEventItem, 'key' | 'ownerPubkey' | 'contentId' | 'updatedAt'>>(items: T[]): T[] {
  const first = new Map<string, T>();
  for (const item of items) {
    if (!item.contentId) continue;
    const id = `${item.ownerPubkey}:${item.contentId}`;
    const kept = first.get(id);
    if (!kept || item.updatedAt < kept.updatedAt || (item.updatedAt === kept.updatedAt && item.key < kept.key)) first.set(id, item);
  }
  return items.filter((item) => !item.contentId || first.get(`${item.ownerPubkey}:${item.contentId}`) === item);
}

/**
 * Parse a NIP-71 video event. One that points into its author's own hashtree
 * video tree becomes a tree video; one with web-hosted media becomes an external
 * video. An event pointing at somebody else's tree is ignored.
 */
export function parseVideoEvent(event: VideoEventLike): VideoEventItem | null {
  if (!ALL_VIDEO_EVENT_KINDS.includes(event.kind)) return null;
  const ownerPubkey = event.pubkey?.toLowerCase();
  const ownerNpub = pubkeyToNpub(ownerPubkey);
  if (!ownerNpub) return null;

  const tagValue = (name: string) => readString(event.tags.find((tag) => tag[0] === name)?.[1]);
  const dTag = tagValue('d');

  for (const tag of event.tags) {
    if (tag[0] !== 'imeta' || !dTag || !VIDEO_EVENT_KINDS.includes(event.kind)) continue;
    const fields = imetaFields(tag);
    const location = parseVideoHtreeUrl(fields.get('url'));
    if (!location || location.ownerNpub !== ownerNpub) continue;

    const { treeName, videoId, videoPath } = location;
    const title = tagValue('title') ?? (videoId || treeName.slice('videos/'.length));
    const createdAt = Math.floor(event.created_at ?? 0);
    return {
      key: videoKey(ownerNpub, treeName, videoId),
      title,
      ...(readString(event.content) ? { description: readString(event.content) } : {}),
      ...(readPositiveNumber(fields.get('duration') ?? tagValue('duration'))
        ? { duration: readPositiveNumber(fields.get('duration') ?? tagValue('duration')) }
        : {}),
      timestamp: Math.floor(readPositiveNumber(tagValue('published_at')) ?? createdAt),
      updatedAt: createdAt,
      ownerPubkey,
      ownerNpub,
      treeName,
      ...(videoId ? { videoId } : {}),
      ...(videoPath ? { videoPath } : {}),
      ...(toAppThumbnailUrl(fields.get('image')) ? { thumbnailUrl: toAppThumbnailUrl(fields.get('image')) } : {}),
      ...(event.tags.some((entry) => entry[0] === 'content-warning') ? { sensitive: true } : {}),
      tags: normalizeTags(event.tags.filter((entry) => entry[0] === 't').map((entry) => entry[1])),
      href: videoHref(ownerNpub, treeName, videoId),
      dTag,
      kind: event.kind,
      ...(event.id ? { eventId: event.id } : {}),
    };
  }
  return parseExternalVideoEvent(event, ownerPubkey, ownerNpub);
}

/** Decode the `<naddr|note>` (or an older `nevent`) of a `#/v/...` or `#/shorts/...` link back to what it names. */
export function parseExternalVideoRef(ref: string | undefined): { key: string; pubkey?: string; kind?: number; dTag?: string; id?: string } | null {
  try {
    const decoded = nip19.decode(ref ?? '');
    if (decoded.type === 'naddr') {
      const { kind, pubkey, identifier } = decoded.data;
      return { key: `event:${kind}:${pubkey}:${identifier}`, pubkey, kind, dTag: identifier };
    }
    if (decoded.type === 'nevent') {
      return { key: `event:${decoded.data.id}`, id: decoded.data.id, pubkey: decoded.data.author, kind: decoded.data.kind };
    }
    if (decoded.type === 'note') return { key: `event:${decoded.data}`, id: decoded.data };
  } catch {
    // Not a Nostr reference.
  }
  return null;
}

/** NIP-09 deletion request for an owner's video events. */
export function buildVideoEventDeletionTemplate(
  ownerPubkey: string,
  dTags: string[],
  createdAt = Math.floor(Date.now() / 1000),
): EventTemplate {
  return {
    kind: VIDEO_EVENT_DELETE_KIND,
    created_at: createdAt,
    content: '',
    tags: [
      ...dTags.map((dTag) => ['a', `${VIDEO_EVENT_KIND}:${ownerPubkey}:${dTag}`]),
      ['k', `${VIDEO_EVENT_KIND}`],
    ],
  };
}

/** Event ids named by a deletion request (regular, non-addressable video events). */
export function parseVideoEventIdDeletion(event: VideoEventLike): string[] {
  if (event.kind !== VIDEO_EVENT_DELETE_KIND) return [];
  return event.tags.filter((tag) => tag[0] === 'e' && /^[0-9a-f]{64}$/.test(tag[1] ?? '')).map((tag) => tag[1]);
}

/** `d` tags named by a deletion request from the videos' own author. */
export function parseVideoEventDeletion(event: VideoEventLike): string[] {
  if (event.kind !== VIDEO_EVENT_DELETE_KIND) return [];
  const dTags: string[] = [];
  for (const tag of event.tags) {
    if (tag[0] !== 'a' || !tag[1]) continue;
    const [kind, pubkey, ...rest] = tag[1].split(':');
    if (!VIDEO_EVENT_KINDS.includes(Number(kind)) || pubkey !== event.pubkey) continue;
    if (rest.length) dTags.push(rest.join(':'));
  }
  return dTags;
}

export interface GroupableVideo {
  key: string;
  title: string;
  ownerNpub: string | null;
  treeName: string;
  videoId?: string;
  href: string;
}

/**
 * List a playlist once instead of once per item. Items that share an owner and
 * tree collapse into the first of them (so pass the list newest first); that
 * entry links to the playlist and carries its item count.
 */
export function groupPlaylistVideos<T extends GroupableVideo>(videos: T[]): Array<T & { videoCount?: number }> {
  const playlistKey = (video: T) => (video.videoId && video.ownerNpub ? videoKey(video.ownerNpub, video.treeName) : null);
  const counts = new Map<string, number>();
  for (const video of videos) {
    const key = playlistKey(video);
    if (key) counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  const listed = new Set<string>();
  const result: Array<T & { videoCount?: number }> = [];
  for (const video of videos) {
    const key = playlistKey(video);
    const videoCount = key ? counts.get(key)! : 0;
    if (!key || videoCount < 2) {
      result.push(video);
    } else if (!listed.has(key)) {
      listed.add(key);
      result.push({
        ...video,
        key,
        title: video.treeName.replace(/^videos\//, ''),
        href: videoHref(video.ownerNpub!, video.treeName),
        videoCount,
        // The first item lends its thumbnail; the rest of its details are not the playlist's.
        videoId: undefined,
        videoPath: undefined,
        duration: undefined,
        description: undefined,
      });
    }
  }
  return result;
}

export interface SearchableVideo {
  title: string;
  description?: string;
  ownerNpub?: string | null;
  treeName?: string;
  videoId?: string;
  tags?: string[];
  timestamp?: number;
}

/**
 * How well a video matches the query terms, 0..1 (0 = some term matches nowhere).
 * Title matches weigh most, then tags, then the description; the whole phrase
 * in the title, a title that starts with it and an exact title rank higher still.
 */
export function videoSearchRelevance(item: SearchableVideo, terms: string[]): number {
  if (terms.length === 0) return 0;
  const title = item.title.toLowerCase();
  const tags = (item.tags ?? []).join(' ').toLowerCase();
  const body = [item.description, item.ownerNpub, item.treeName, item.videoId].filter(Boolean).join(' ').toLowerCase();
  let inTitle = 0;
  let inTags = 0;
  let inBody = 0;
  for (const term of terms) {
    const titleHit = title.includes(term);
    const tagHit = tags.includes(term);
    const bodyHit = body.includes(term);
    if (!titleHit && !tagHit && !bodyHit) return 0;
    if (titleHit) inTitle += 1;
    if (tagHit) inTags += 1;
    if (bodyHit) inBody += 1;
  }
  const phrase = terms.join(' ');
  const score = 0.65 * (inTitle / terms.length)
    + 0.2 * (inTags / terms.length)
    + 0.1 * (inBody / terms.length)
    + (title.includes(phrase) ? 0.1 : 0)
    + (title.startsWith(phrase) ? 0.1 : 0)
    + (title === phrase ? 0.1 : 0);
  return Math.min(1, score);
}

const SEARCH_STOP_WORDS = new Set([
  'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'in', 'is', 'it',
  'of', 'on', 'or', 'that', 'the', 'this', 'to', 'was', 'with',
]);

/** Query words worth matching: filler words and single characters are dropped. */
export function parseSearchTerms(query: string): string[] {
  const terms = query.toLowerCase().split(/[^\p{L}\p{N}]+/u)
    .filter((term) => term.length >= 2 && !SEARCH_STOP_WORDS.has(term));
  return [...new Set(terms)];
}

/** Deterministic substring search: every term must match; title hits rank first, then newest. */
export function searchVideoItems<T extends SearchableVideo>(items: Iterable<T>, query: string, limit = 20): T[] {
  const terms = parseSearchTerms(query);
  if (terms.length === 0) return [];

  const scored: Array<{ item: T; score: number }> = [];
  for (const item of items) {
    const score = videoSearchRelevance(item, terms);
    if (score > 0) scored.push({ item, score });
  }
  return scored
    .sort((a, b) => b.score - a.score
      || (b.item.timestamp ?? 0) - (a.item.timestamp ?? 0)
      || a.item.title.localeCompare(b.item.title))
    .slice(0, limit)
    .map((entry) => entry.item);
}
