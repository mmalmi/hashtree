/**
 * Text as people write it on Nostr, split into the pieces a page can make
 * useful: links, pictures, mentions of people, references to other events,
 * hashtags and (for video descriptions) timestamps. Pure and deterministic.
 */
import { nip19 } from 'nostr-tools';

export type RichTextSegment =
  | { type: 'text'; text: string }
  | { type: 'link'; url: string }
  | { type: 'image'; url: string }
  | { type: 'mention'; pubkey: string; npub: string }
  /** `href` is a page in this app when the reference is something it shows, else null. */
  | { type: 'event'; bech32: string; href: string | null }
  | { type: 'hashtag'; tag: string }
  | { type: 'timestamp'; display: string; seconds: number };

export interface RichTextOptions {
  /** Treat `1:23` and `1:02:03` as positions in the video being watched. */
  timestamps?: boolean;
}

const URL_PATTERN = /https?:\/\/[^\s<>"{}|\\^`[\]]+/g;
const NOSTR_REF = /(?:nostr:)?\b(npub1|nprofile1|note1|nevent1|naddr1)[023456789acdefghjklmnpqrstuvwxyz]{20,}/g;
// A hashtag starts a word and holds letters, digits or underscores, with at least one letter.
const HASHTAG = /(?<=^|[\s(])#([\p{L}\p{N}_]{1,60})/gu;
const TIMESTAMP = /(?<=^|\s)(\d{1,2}:\d{2}(?::\d{2})?)(?=\s|$)/gm;
const IMAGE_PATH = /\.(?:jpe?g|png|gif|webp|avif)$/i;
const VIDEO_KINDS = new Set([21, 22, 34235, 34236]);
const VIDEO_SET_KIND = 30005;

interface Match {
  start: number;
  end: number;
  segment: RichTextSegment;
  /** Earlier kinds win where matches overlap. */
  rank: number;
}

function timestampSeconds(value: string): number {
  return value.split(':').map(Number).reduce((total, part) => total * 60 + part, 0);
}

function nostrSegment(raw: string): RichTextSegment | null {
  const bech32 = raw.replace(/^nostr:/, '');
  try {
    const decoded = nip19.decode(bech32);
    if (decoded.type === 'npub') return { type: 'mention', pubkey: decoded.data, npub: bech32 };
    if (decoded.type === 'nprofile') return { type: 'mention', pubkey: decoded.data.pubkey, npub: nip19.npubEncode(decoded.data.pubkey) };
    if (decoded.type === 'naddr') {
      if (VIDEO_KINDS.has(decoded.data.kind)) return { type: 'event', bech32, href: `#/v/${bech32}` };
      if (decoded.data.kind === VIDEO_SET_KIND) return { type: 'event', bech32, href: `#/list/${bech32}` };
      return { type: 'event', bech32, href: null };
    }
    if (decoded.type === 'nevent') {
      return { type: 'event', bech32, href: decoded.data.kind !== undefined && VIDEO_KINDS.has(decoded.data.kind) ? `#/v/${bech32}` : null };
    }
    if (decoded.type === 'note') return { type: 'event', bech32, href: null };
  } catch {
    // Not a valid reference: left as text.
  }
  return null;
}

export function parseRichText(text: string, options: RichTextOptions = {}): RichTextSegment[] {
  const matches: Match[] = [];

  for (const match of text.matchAll(URL_PATTERN)) {
    // Punctuation that ends the sentence is not part of the address.
    const url = match[0].replace(/[.,;:!?)\]'"]+$/, '');
    let segment: RichTextSegment = { type: 'link', url };
    try {
      if (IMAGE_PATH.test(new URL(url).pathname)) segment = { type: 'image', url };
    } catch {
      continue;
    }
    matches.push({ start: match.index, end: match.index + url.length, segment, rank: 0 });
  }
  for (const match of text.matchAll(NOSTR_REF)) {
    const segment = nostrSegment(match[0]);
    if (segment) matches.push({ start: match.index, end: match.index + match[0].length, segment, rank: 1 });
  }
  for (const match of text.matchAll(HASHTAG)) {
    if (!/\p{L}/u.test(match[1])) continue;
    matches.push({ start: match.index, end: match.index + match[0].length, segment: { type: 'hashtag', tag: match[1].toLowerCase() }, rank: 2 });
  }
  if (options.timestamps) {
    for (const match of text.matchAll(TIMESTAMP)) {
      matches.push({ start: match.index, end: match.index + match[0].length, segment: { type: 'timestamp', display: match[1], seconds: timestampSeconds(match[1]) }, rank: 3 });
    }
  }

  matches.sort((a, b) => a.start - b.start || a.rank - b.rank);
  const segments: RichTextSegment[] = [];
  let cursor = 0;
  for (const match of matches) {
    if (match.start < cursor) continue;
    if (match.start > cursor) segments.push({ type: 'text', text: text.slice(cursor, match.start) });
    segments.push(match.segment);
    cursor = match.end;
  }
  if (cursor < text.length) segments.push({ type: 'text', text: text.slice(cursor) });
  return segments;
}

/**
 * The beginning of a long text, for "show more": at most `maxLines` lines and
 * `maxChars` characters, cut at a word where one is near, and never in the
 * middle of an address or reference.
 */
export function truncateRichText(text: string, maxLines: number, maxChars: number): { text: string; truncated: boolean } {
  const lines = text.split('\n');
  if (lines.length <= maxLines && text.length <= maxChars) return { text, truncated: false };
  let cut = lines.slice(0, maxLines).join('\n');
  if (cut.length > maxChars) {
    cut = cut.slice(0, maxChars);
    const lastBreak = Math.max(cut.lastIndexOf(' '), cut.lastIndexOf('\n'));
    if (lastBreak > maxChars * 0.6) cut = cut.slice(0, lastBreak);
  }
  return { text: cut.trimEnd(), truncated: true };
}

/** A short form of a long reference for display: `note1abcd…wxyz`. */
export function shortRef(bech32: string): string {
  return bech32.length > 20 ? `${bech32.slice(0, 10)}…${bech32.slice(-4)}` : bech32;
}
