/**
 * Front-page ranking for videos from everywhere.
 *
 * Same shape as the Iris Market home feed: who published it (follow distance
 * from the viewer) weighs most, then what the viewer's network did with it,
 * then how fresh it is; one author or one repeated title cannot fill the page.
 * Pure and deterministic: the same inputs always give the same order.
 */

export interface RankableVideo {
  key: string;
  title: string;
  ownerPubkey: string | null;
  /** Unix seconds. */
  timestamp?: number;
}

export interface RankingContext {
  /** Unix seconds. */
  now: number;
  /** Follow distance from the viewer's network root; 1000 when unknown. */
  followDistance: (pubkey: string) => number;
  /** Trust-weighted count of people who liked, reposted or commented. */
  engagement?: (video: RankableVideo) => number;
  /** Relevance to a search query, 0..1. When given, it outweighs everything else. */
  relevance?: (video: RankableVideo) => number;
}

const TRUST_WEIGHT = 3;
const ENGAGEMENT_WEIGHT = 3;
const SEARCH_RELEVANCE_WEIGHT = 32;
const FRESHNESS_MAX = 2.5;
const FRESHNESS_HALF_LIFE_SECONDS = 14 * 86400;
const REPEAT_TITLE_PENALTY = 3;
const AUTHOR_REPEAT_PENALTY = 1.5;
const AUTHOR_REPEAT_PENALTY_MAX = 6;

/** How much an author counts, by follow distance from the viewer. */
export function authorTrust(distance: number): number {
  if (distance <= 1) return 2.5;
  if (distance === 2) return 1.5;
  if (distance === 3) return 0.75;
  return 0;
}

/** How much one person's like, repost or comment counts, by their follow distance. */
export function actorTrust(distance: number): number {
  if (distance <= 1) return 1.4;
  if (distance === 2) return 0.5;
  if (distance === 3) return 0.2;
  return 0.05;
}

export function freshness(ageSeconds: number): number {
  return FRESHNESS_MAX * 0.5 ** (Math.max(0, ageSeconds) / FRESHNESS_HALF_LIFE_SECONDS);
}

export interface RelatableVideo {
  ownerPubkey: string | null;
  title: string;
  tags?: string[];
}

const SAME_AUTHOR_FIRST = 3;

function titleWords(title: string): Set<string> {
  return new Set(normalizedTitle(title).split(' ').filter((word) => word.length >= 4));
}

/**
 * "Up next" for the video being watched: a few more from the same author, then
 * videos that share its tags or title words, then the rest in the order given
 * (the ranked feed). Watched videos go last. Stable for equal scores.
 */
export function orderRelatedVideos<T extends RelatableVideo>(
  current: RelatableVideo | null,
  videos: T[],
  isWatched: (video: T) => boolean = () => false,
): T[] {
  const tags = new Set(current?.tags ?? []);
  const words = current ? titleWords(current.title) : new Set<string>();
  let sameAuthor = 0;
  return videos
    .map((video, index) => {
      let score = 0;
      if (current) {
        if (current.ownerPubkey && video.ownerPubkey === current.ownerPubkey) {
          sameAuthor += 1;
          score += sameAuthor <= SAME_AUTHOR_FIRST ? 3 : 0.5;
        }
        score += Math.min(3, (video.tags ?? []).filter((tag) => tags.has(tag)).length);
        score += 0.75 * Math.min(2, [...titleWords(video.title)].filter((word) => words.has(word)).length);
      }
      if (isWatched(video)) score -= 100;
      return { video, index, score };
    })
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map((entry) => entry.video);
}

function normalizedTitle(title: string): string {
  return title.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

/** In All / Hot, leave room for discovery after two consecutive videos from the viewer's network. */
export function mixDiscoveryVideos<T>(ranked: T[], inNetwork: (video: T) => boolean): T[] {
  const discovery = ranked.filter((video) => !inNetwork(video));
  if (!discovery.length) return ranked;
  const mixed: T[] = [];
  const promoted = new Set<T>();
  let nextDiscovery = 0;
  let consecutive = 0;
  for (const video of ranked) {
    if (promoted.has(video)) continue;
    mixed.push(video);
    if (video === discovery[nextDiscovery]) {
      nextDiscovery++;
      consecutive = 0;
    } else if (++consecutive === 2 && nextDiscovery < discovery.length) {
      const next = discovery[nextDiscovery++];
      mixed.push(next);
      promoted.add(next);
      consecutive = 0;
    }
  }
  return mixed;
}

export function rankVideos<T extends RankableVideo>(videos: T[], context: RankingContext): T[] {
  const byScore = (a: { video: T; score: number }, b: { video: T; score: number }) => (
    b.score - a.score
    || (b.video.timestamp ?? 0) - (a.video.timestamp ?? 0)
    || a.video.key.localeCompare(b.video.key)
  );

  const scored = videos.map((video) => {
    const trust = video.ownerPubkey ? authorTrust(context.followDistance(video.ownerPubkey)) : 0;
    const engagement = Math.log1p(Math.max(0, context.engagement?.(video) ?? 0));
    const fresh = freshness(context.now - (video.timestamp ?? 0));
    const score = context.relevance
      ? trust + SEARCH_RELEVANCE_WEIGHT * context.relevance(video) + engagement + fresh
      : TRUST_WEIGHT * trust + ENGAGEMENT_WEIGHT * engagement + fresh;
    return { video, score };
  }).sort(byScore);

  // Search results stay in order of relevance.
  if (context.relevance) return scored.map((entry) => entry.video);

  // The best copy of a title keeps its score; repeats and one author's further videos sink.
  const seenTitles = new Set<string>();
  const authorCounts = new Map<string, number>();
  for (const entry of scored) {
    const title = normalizedTitle(entry.video.title);
    if (title && seenTitles.has(title)) entry.score -= REPEAT_TITLE_PENALTY;
    seenTitles.add(title);

    const author = entry.video.ownerPubkey ?? '';
    const emitted = authorCounts.get(author) ?? 0;
    entry.score -= Math.min(AUTHOR_REPEAT_PENALTY * emitted, AUTHOR_REPEAT_PENALTY_MAX);
    authorCounts.set(author, emitted + 1);
  }

  return scored.sort(byScore).map((entry) => entry.video);
}
