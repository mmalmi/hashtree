import { cid, fromHex, objectKeyFromHex, type CID } from '@hashtree/core';

export function parseVideoRootCid(hashHex?: string, keyHex?: string): CID | null {
  if (!hashHex || !/^[0-9a-f]{64}$/i.test(hashHex)) return null;
  try {
    return cid(fromHex(hashHex), keyHex === undefined ? undefined : objectKeyFromHex(keyHex));
  } catch {
    return null;
  }
}

// A sharing secret is an opaque XOR mask. Its first byte is not a suite ID.
export function isLinkSecretHex(value: unknown): value is string {
  return typeof value === 'string' && /^(?:[0-9a-f]{2}){32,33}$/i.test(value);
}
