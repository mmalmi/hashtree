/**
 * Video playlists as other Nostr apps publish them: NIP-51 "video sets"
 * (kind 30005), an addressable list of video events with a title.
 *
 * This app's own playlists are hashtree trees; each one is also announced as
 * a set whose `d` tag is the tree name, listing the playlist's video events,
 * so other apps see it as a playlist too. Pure parsing and building.
 */
import { nip19, type EventTemplate } from 'nostr-tools';

export const VIDEO_SET_KIND = 30005;
/** NIP-09 deletion request. Kept local so scripts can load this file on its own. */
const VIDEO_EVENT_DELETE_KIND = 5;

export interface VideoSet {
  /** `set:30005:<pubkey>:<d tag>` */
  key: string;
  ownerPubkey: string;
  ownerNpub: string;
  dTag: string;
  title: string;
  description?: string;
  /** Cover image the author chose, if any. */
  image?: string;
  /** Member videos in the author's order: an event id, or `kind:pubkey:d` for an addressable event. */
  refs: string[];
  /** Unix seconds of the event (a newer one replaces an older one). */
  updatedAt: number;
  href: string;
}

interface SetEventLike {
  kind: number;
  pubkey: string;
  created_at: number;
  tags: string[][];
}

function text(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

export function videoSetKey(ownerPubkey: string, dTag: string): string {
  return `set:${VIDEO_SET_KIND}:${ownerPubkey}:${dTag}`;
}

export function videoSetHref(ownerPubkey: string, dTag: string): string {
  return `#/list/${nip19.naddrEncode({ kind: VIDEO_SET_KIND, pubkey: ownerPubkey, identifier: dTag })}`;
}

/** Parse a kind 30005 event. Sets with no title and no videos are not playlists worth listing. */
export function parseVideoSet(event: SetEventLike): VideoSet | null {
  if (event.kind !== VIDEO_SET_KIND || !/^[0-9a-f]{64}$/.test(event.pubkey)) return null;
  const tagValue = (name: string) => text(event.tags.find((tag) => tag[0] === name)?.[1]);
  const dTag = tagValue('d');
  if (!dTag) return null;

  const refs: string[] = [];
  for (const tag of event.tags) {
    const ref = text(tag[1]);
    if (!ref || refs.includes(ref)) continue;
    if (tag[0] === 'e' && /^[0-9a-f]{64}$/.test(ref)) refs.push(ref);
    else if (tag[0] === 'a' && /^\d+:[0-9a-f]{64}:.+/.test(ref)) refs.push(ref);
  }
  if (refs.length === 0) return null;

  const image = tagValue('image') ?? tagValue('thumb');
  const description = tagValue('description') ?? tagValue('summary');
  return {
    key: videoSetKey(event.pubkey, dTag),
    ownerPubkey: event.pubkey,
    ownerNpub: nip19.npubEncode(event.pubkey),
    dTag,
    title: tagValue('title') ?? tagValue('name') ?? dTag,
    ...(description ? { description } : {}),
    ...(image ? { image } : {}),
    refs,
    updatedAt: Math.floor(event.created_at ?? 0),
    href: videoSetHref(event.pubkey, dTag),
  };
}

/** Decode the `naddr` of a `#/list/...` link. */
export function parseVideoSetRef(ref: string | undefined): { key: string; pubkey: string; dTag: string } | null {
  if (!ref) return null;
  try {
    const decoded = nip19.decode(ref);
    if (decoded.type !== 'naddr' || decoded.data.kind !== VIDEO_SET_KIND) return null;
    return { key: videoSetKey(decoded.data.pubkey, decoded.data.identifier), pubkey: decoded.data.pubkey, dTag: decoded.data.identifier };
  } catch {
    return null;
  }
}

export interface VideoSetInput {
  dTag: string;
  title: string;
  description?: string;
  /** Portable cover image URL (`htree://...` or `https://...`). */
  image?: string;
  /** `kind:pubkey:d` of each video, in playlist order. */
  addresses: string[];
}

export function buildVideoSetTemplate(input: VideoSetInput, createdAt = Math.floor(Date.now() / 1000)): EventTemplate {
  return {
    kind: VIDEO_SET_KIND,
    created_at: createdAt,
    content: '',
    tags: [
      ['d', input.dTag],
      ['title', input.title],
      ...(input.description ? [['description', input.description]] : []),
      ...(input.image ? [['image', input.image]] : []),
      ...input.addresses.map((address) => ['a', address]),
    ],
  };
}

/** The owner's request to delete some of their sets. */
export function buildVideoSetDeletionTemplate(ownerPubkey: string, dTags: string[], createdAt = Math.floor(Date.now() / 1000)): EventTemplate {
  return {
    kind: VIDEO_EVENT_DELETE_KIND,
    created_at: createdAt,
    content: '',
    tags: [
      ...dTags.map((dTag) => ['a', `${VIDEO_SET_KIND}:${ownerPubkey}:${dTag}`]),
      ['k', `${VIDEO_SET_KIND}`],
    ],
  };
}

/** `d` tags of the sets a deletion request names, for its author only. */
export function parseVideoSetDeletion(event: SetEventLike): string[] {
  if (event.kind !== VIDEO_EVENT_DELETE_KIND) return [];
  const prefix = `${VIDEO_SET_KIND}:${event.pubkey}:`;
  return event.tags
    .filter((tag) => tag[0] === 'a' && typeof tag[1] === 'string' && tag[1].startsWith(prefix))
    .map((tag) => tag[1].slice(prefix.length));
}

/** Whether two sets would look the same to a reader, so an unchanged playlist is not published again. */
export function sameVideoSet(a: Pick<VideoSet, 'title' | 'description' | 'image' | 'refs'>, b: Pick<VideoSet, 'title' | 'description' | 'image' | 'refs'>): boolean {
  return a.title === b.title && a.description === b.description && a.image === b.image
    && a.refs.length === b.refs.length && a.refs.every((ref, index) => ref === b.refs[index]);
}
