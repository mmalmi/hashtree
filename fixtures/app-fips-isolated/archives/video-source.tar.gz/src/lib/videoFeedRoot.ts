import { HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import { cid, type CID } from '@hashtree/core';
import { parseVideoRootCid } from './videoRootKeys';
import { getLocalRootCache, getLocalRootKey } from '../treeRootCache';
const FEED_ROOT_CACHE_TTL_MS = 30_000;
const FEED_ROOT_MISS_CACHE_TTL_MS = 5_000;

const feedRootResolutionCache = new Map<string, {
  cid: CID | null;
  expiresAt: number;
  authoritative: boolean;
}>();
const inFlightFeedRootResolutions = new Map<string, Promise<CID | null>>();

interface ResolvedTreeRoot {
  cid: CID;
  updatedAt?: number;
  authoritative?: boolean;
}

interface ResolveFeedVideoRootOptions {
  requireAuthoritative?: boolean;
  authoritativeGraceMs?: number;
}

type FeedVideoRootSource = {
  rootCid?: CID | null;
  ownerNpub?: string | null;
  treeName?: string | null;
};

function isHexPubkey(value: string | null | undefined): value is string {
  return typeof value === 'string' && /^[0-9a-f]{64}$/i.test(value);
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T | null> {
  return Promise.race([
    promise,
    new Promise<null>((resolve) => setTimeout(() => resolve(null), timeoutMs)),
  ]);
}

function getFeedRootCacheKey(npub: string, treeName: string): string {
  return `${npub}/${treeName}`;
}

function firstNonNull<T>(promises: Array<Promise<T | null>>): Promise<T | null> {
  if (promises.length === 0) {
    return Promise.resolve(null);
  }

  return new Promise((resolve) => {
    let pending = promises.length;
    let settled = false;

    const settleNull = () => {
      pending -= 1;
      if (!settled && pending === 0) {
        settled = true;
        resolve(null);
      }
    };

    for (const promise of promises) {
      promise
        .then((value) => {
          if (settled) return;
          if (value) {
            settled = true;
            resolve(value);
            return;
          }
          settleNull();
        })
        .catch(() => {
          if (settled) return;
          settleNull();
        });
    }
  });
}

async function cacheResolvedFeedTreeRoot(
  npub: string,
  treeName: string,
  resolved: CID | null,
  updatedAt?: number,
): Promise<void> {
  const authoritative = typeof updatedAt === 'number' && Number.isFinite(updatedAt) && updatedAt > 0;
  const cacheKey = getFeedRootCacheKey(npub, treeName);
  if (!resolved || authoritative) {
    feedRootResolutionCache.set(cacheKey, {
      cid: resolved,
      expiresAt: Date.now() + (resolved ? FEED_ROOT_CACHE_TTL_MS : FEED_ROOT_MISS_CACHE_TTL_MS),
      authoritative,
    });
  } else {
    // Speculative resolver answers should not stick around and outrank the
    // authoritative replaceable-event path on subsequent loads.
    feedRootResolutionCache.delete(cacheKey);
  }
  if (!resolved) {
    return;
  }

  // Feed-root lookups can return a speculative local/ref-resolver answer that does
  // not carry event freshness. Keep that as a route-local seed, but do not
  // promote it into the shared mutable-root caches with a synthetic "now"
  // timestamp or it can outrank the actual latest tree root.
  if (!authoritative) {
    return;
  }

  try {
    const { updateSubscriptionCache } = await import('../stores/treeRoot');
    updateSubscriptionCache(`${npub}/${treeName}`, resolved.hash, resolved.key, {
      updatedAt,
      visibility: 'public',
    });
  } catch {
    // Ignore cache-persist failures; callers still get the resolved root.
  }
}

/**
 * Resolve the tree root for a feed item.
 *
 * Feed items coming from reactions/comments may not carry `rootCid` directly,
 * but the current tree root is often already available in the local cache.
 */
export function resolveFeedVideoRootCid(video: FeedVideoRootSource): CID | null {
  if (!video.ownerNpub || !video.treeName) {
    return video.rootCid ?? null;
  }

  const hash = getLocalRootCache(video.ownerNpub, video.treeName);
  if (!hash) return video.rootCid ?? null;

  const key = getLocalRootKey(video.ownerNpub, video.treeName);
  return cid(hash, key);
}

export async function resolveFeedVideoRootCidAsync(
  video: FeedVideoRootSource,
  timeoutMs = 8000,
  options: ResolveFeedVideoRootOptions = {},
): Promise<CID | null> {
  const fallbackRootCid = resolveFeedVideoRootCid(video) ?? video.rootCid ?? null;
  const cached = resolveFeedVideoRootCid(video);
  if (cached && !options.requireAuthoritative) return cached;
  if (!video.ownerNpub || !video.treeName) return fallbackRootCid;

  const ownerNpub = video.ownerNpub;
  const treeName = video.treeName;
  const cacheKey = getFeedRootCacheKey(ownerNpub, treeName);
  const cachedResult = feedRootResolutionCache.get(cacheKey);
  if (cachedResult && cachedResult.expiresAt > Date.now()) {
    if (!options.requireAuthoritative || cachedResult.authoritative) {
      return cachedResult.cid;
    }
  }
  if (cachedResult) {
    feedRootResolutionCache.delete(cacheKey);
  }

  const inFlight = inFlightFeedRootResolutions.get(cacheKey);
  if (inFlight) {
    return await inFlight;
  }

  const lookup = (async (): Promise<CID | null> => {
    let resolvedOwnerPubkey: string | null = null;
    try {
      const { npubToPubkey } = await import('../nostr');
      resolvedOwnerPubkey = npubToPubkey(ownerNpub);
    } catch {
      resolvedOwnerPubkey = null;
    }

    const resolverTask = (async (): Promise<ResolvedTreeRoot | null> => {
      try {
        const { getRefResolver } = await import('../refResolver');
        const resolver = getRefResolver();
        const resolved = await withTimeout(
          resolver.resolve(`${ownerNpub}/${treeName}`),
          timeoutMs,
        );
        return resolved ? { cid: resolved, authoritative: false } : null;
      } catch {
        return null;
      }
    })();

    const lookupTasks: Array<Promise<ResolvedTreeRoot | null>> = [resolverTask];
    const authoritativeTasks: Array<Promise<ResolvedTreeRoot | null>> = [];

    if (isHexPubkey(resolvedOwnerPubkey)) {
      const eventTask = (async (): Promise<ResolvedTreeRoot | null> => {
        try {
          const { nostr } = await import('../nostr');
          const event = await withTimeout(nostr.fetchEvent({
            kinds: [...HASHTREE_ROOT_KINDS],
            authors: [resolvedOwnerPubkey],
            '#d': [treeName],
          }), timeoutMs);
          const hashHex = event?.tags.find((tag) => tag[0] === 'hash')?.[1];
          if (!hashHex) {
            return null;
          }
          const keyHex = event.tags.find((tag) => tag[0] === 'key')?.[1];
          const root = parseVideoRootCid(hashHex, keyHex);
          if (!root) return null;
          return {
            cid: root,
            updatedAt: event.created_at,
            authoritative: true,
          };
        } catch {
          return null;
        }
      })();
      lookupTasks.push(eventTask);
      authoritativeTasks.push(eventTask);
    }

    if (options.requireAuthoritative && authoritativeTasks.length > 0) {
      const authoritativeGraceMs = Math.min(timeoutMs, Math.max(250, options.authoritativeGraceMs ?? 1500));
      const earlyAuthoritative = (await Promise.all(
        authoritativeTasks.map((task) => withTimeout(task, authoritativeGraceMs)),
      )).filter((result): result is ResolvedTreeRoot => !!result);

      const freshestAuthoritative = earlyAuthoritative
        .sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))[0];
      if (freshestAuthoritative) {
        await cacheResolvedFeedTreeRoot(
          video.ownerNpub!,
          video.treeName!,
          freshestAuthoritative.cid,
          freshestAuthoritative.updatedAt,
        );
        return freshestAuthoritative.cid;
      }

      const remainingMs = Math.max(0, timeoutMs - authoritativeGraceMs);
      const speculativeResolved = await withTimeout(resolverTask, remainingMs);
      if (speculativeResolved) {
        await cacheResolvedFeedTreeRoot(
          video.ownerNpub!,
          video.treeName!,
          speculativeResolved.cid,
          speculativeResolved.updatedAt,
        );
        return speculativeResolved.cid;
      }
    }

    try {
      const resolved = await firstNonNull(lookupTasks);
      if (resolved) {
        await cacheResolvedFeedTreeRoot(
          video.ownerNpub!,
          video.treeName!,
          resolved.cid,
          resolved.updatedAt,
        );
        return resolved.cid;
      }
    } catch {
      if (!fallbackRootCid) {
        await cacheResolvedFeedTreeRoot(video.ownerNpub!, video.treeName!, null);
      }
      return fallbackRootCid;
    }

    if (!fallbackRootCid) {
      await cacheResolvedFeedTreeRoot(video.ownerNpub!, video.treeName!, null);
    }
    return fallbackRootCid;
  })();

  inFlightFeedRootResolutions.set(cacheKey, lookup);
  try {
    return await lookup;
  } finally {
    inFlightFeedRootResolutions.delete(cacheKey);
  }
}
