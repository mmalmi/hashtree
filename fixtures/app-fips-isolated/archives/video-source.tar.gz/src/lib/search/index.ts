/**
 * Unified search service
 *
 * Aggregates results from multiple providers with deduplication and ranking.
 */

import type { SearchProvider, SearchResult, SearchOptions } from './types';
import { historyProvider, getRecentHistory } from './historyProvider';
import { videoProvider } from './videoProvider';
import { userProvider } from './userProvider';
import { appsProvider, getAppSuggestions } from './appsProvider';

export type { SearchProvider, SearchResult, SearchOptions } from './types';
export { recordHistoryVisit, getRecentHistory } from './historyProvider';

// Provider registry
const providers = new Map<string, SearchProvider>();

/** Register a search provider */
export function registerProvider(provider: SearchProvider): void {
  providers.set(provider.id, provider);
}

// Register default providers
registerProvider(historyProvider);
registerProvider(videoProvider);
registerProvider(userProvider);
registerProvider(appsProvider);

/** Deduplicate by path (keep highest score), filter and rank. */
function mergeResults(resultArrays: SearchResult[][], limit: number, minScore: number): SearchResult[] {
  const byPath = new Map<string, SearchResult>();
  for (const result of resultArrays.flat()) {
    const existing = byPath.get(result.path);
    if (!existing || result.score > existing.score) {
      byPath.set(result.path, result);
    }
  }

  return Array.from(byPath.values())
    .filter((r) => r.score >= minScore)
    // Score descending, then most recent first
    .sort((a, b) => b.score - a.score || (b.timestamp ?? 0) - (a.timestamp ?? 0))
    .slice(0, limit);
}

/**
 * Search all providers and return merged results.
 *
 * Providers answer at their own pace (some read network-backed indexes), so
 * `onUpdate` receives the merged results every time one of them finishes.
 * Callers that render results should use it instead of awaiting the slowest.
 */
export async function search(
  query: string,
  options: SearchOptions = {},
  onUpdate?: (results: SearchResult[]) => void,
): Promise<SearchResult[]> {
  const { limit = 20, sources, minScore = 0 } = options;

  // Get providers to search
  const providersToSearch = sources
    ? sources.map((id) => providers.get(id)).filter(Boolean) as SearchProvider[]
    : Array.from(providers.values()).filter((p) => p.isAvailable());

  if (providersToSearch.length === 0) {
    onUpdate?.([]);
    return [];
  }

  // Search all providers in parallel
  const perProviderLimit = Math.ceil(limit / providersToSearch.length) + 5; // Extra for dedup
  const resultArrays: SearchResult[][] = [];
  await Promise.all(
    providersToSearch.map(async (provider) => {
      let results: SearchResult[] = [];
      try {
        results = await provider.search(query, perProviderLimit);
      } catch (e) {
        console.warn(`[search] Provider ${provider.id} failed:`, e);
      }
      resultArrays.push(results);
      onUpdate?.(mergeResults(resultArrays, limit, minScore));
    })
  );

  return mergeResults(resultArrays, limit, minScore);
}

/** Get suggestions for empty query (recent history + apps) */
export async function getSuggestions(limit = 10): Promise<SearchResult[]> {
  const history = await getRecentHistory(limit);

  // If no history, show app suggestions
  if (history.length === 0) {
    return getAppSuggestions().slice(0, limit);
  }

  return history;
}
