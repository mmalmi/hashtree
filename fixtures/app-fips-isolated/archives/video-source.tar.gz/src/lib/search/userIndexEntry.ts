import { nip19 } from 'nostr-tools';

export interface UserIndexEntryInput {
  pubkey: string;
  name?: string;
  displayName?: string;
  nip05?: string;
  irisProfileId?: string;
  linkedNpubs?: string[];
  shareRecipientEvidenceJson?: string;
}

export interface UserIndexEntry extends UserIndexEntryInput {
  npub: string;
}

function encodeNpub(pubkey: string): string | null {
  try {
    return nip19.npubEncode(pubkey);
  } catch {
    return null;
  }
}

export function getUserSearchTerms(entry: UserIndexEntryInput): string[] {
  const terms: string[] = [];

  const npub = encodeNpub(entry.pubkey);
  if (npub) {
    terms.push(npub.toLowerCase());
  }

  if (entry.name) {
    const nameParts = entry.name.toLowerCase().split(/\s+/).filter(part => part.length >= 2);
    terms.push(...nameParts);
  }

  if (entry.displayName && entry.displayName !== entry.name) {
    const displayParts = entry.displayName.toLowerCase().split(/\s+/).filter(part => part.length >= 2);
    terms.push(...displayParts);
  }

  if (entry.nip05) {
    const atIndex = entry.nip05.indexOf('@');
    const username = atIndex > 0 ? entry.nip05.slice(0, atIndex) : entry.nip05;
    if (username.length >= 2) {
      terms.push(username.toLowerCase());
    }
  }

  if (entry.irisProfileId) {
    terms.push(entry.irisProfileId.toLowerCase());
  }

  for (const linkedNpub of entry.linkedNpubs ?? []) {
    terms.push(linkedNpub.toLowerCase());
  }

  return [...new Set(terms)];
}

export function toUserIndexEntry(input: UserIndexEntryInput): UserIndexEntry | null {
  const npub = encodeNpub(input.pubkey);
  if (!npub) return null;
  const text = (value: string | undefined) => (typeof value === 'string' && value.trim() ? value.trim() : undefined);
  return { ...input, name: text(input.name), displayName: text(input.displayName), nip05: text(input.nip05), npub };
}

/** How well one person matches: a whole name, the start of a word, or anywhere inside. 0 = no match. */
function userMatchScore(entry: UserIndexEntry, query: string): number {
  if (entry.npub.startsWith(query) || entry.pubkey.startsWith(query)) return 1;
  let best = 0;
  for (const value of [entry.displayName, entry.name, entry.nip05]) {
    const text = value?.toLowerCase();
    if (!text) continue;
    if (text === query || text.split('@')[0] === query) best = Math.max(best, 1);
    else if (text.startsWith(query)) best = Math.max(best, 0.8);
    else if (text.split(/[^\p{L}\p{N}]+/u).some((word) => word.startsWith(query))) best = Math.max(best, 0.6);
    else if (text.includes(query)) best = Math.max(best, 0.3);
  }
  return best;
}

/**
 * Deterministic people search: the better match first, then whoever is closer
 * to the viewer in the follow graph, then by name.
 */
export function rankUsers(
  entries: Iterable<UserIndexEntry>,
  query: string,
  limit: number,
  followDistance: (pubkey: string) => number = () => 1000,
): UserIndexEntry[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return [];
  const scored: Array<{ entry: UserIndexEntry; score: number; distance: number }> = [];
  for (const entry of entries) {
    const score = userMatchScore(entry, normalized);
    if (score > 0) scored.push({ entry, score, distance: followDistance(entry.pubkey) });
  }
  const label = (entry: UserIndexEntry) => (entry.displayName ?? entry.name ?? entry.nip05 ?? entry.npub).toLowerCase();
  return scored
    .sort((a, b) => b.score - a.score || a.distance - b.distance || label(a.entry).localeCompare(label(b.entry)) || a.entry.pubkey.localeCompare(b.entry.pubkey))
    .slice(0, limit)
    .map((item) => item.entry);
}
