/**
 * Video search provider
 *
 * Searches the in-memory index of Nostr video events, ranked for the viewer,
 * and asks the relays for more matches, which join the index as they arrive.
 */

import { searchRelaysForVideos, searchVideoFeed } from '../../stores/videoFeed';
import type { SearchProvider, SearchResult } from './types';

/** Video search provider */
export const videoProvider: SearchProvider = {
  id: 'video',
  name: 'Videos',
  priority: 5,

  isAvailable(): boolean {
    return true;
  },

  async search(query: string, limit: number): Promise<SearchResult[]> {
    searchRelaysForVideos(query);
    return searchVideoFeed(query, limit).map((video) => ({
      id: `video:${video.key}`,
      type: 'video' as const,
      label: video.title,
      sublabel: video.duration ? formatDuration(video.duration) : undefined,
      path: video.href.startsWith('#') ? video.href.slice(1) : video.href,
      score: 1,
      icon: 'i-lucide-play-circle',
      pubkey: video.ownerPubkey ?? undefined,
      timestamp: video.timestamp,
    }));
  },
};

/** Format duration in seconds to mm:ss or hh:mm:ss */
function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m}:${s.toString().padStart(2, '0')}`;
}
