import { RETIRED_RELAYS, SHARED_DEFAULT_RELAYS, VIDEO_DEFAULT_RELAYS } from './defaultRelays';

function normalizedRelay(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (!['ws:', 'wss:'].includes(url.protocol)) return null;
    return url.href.replace(/\/$/, '');
  } catch {
    return null;
  }
}

function sameSet(actual: Set<string | null>, shipped: readonly string[]): boolean {
  const expected = new Set(shipped.map(normalizedRelay));
  return actual.size === expected.size && [...expected].every(relay => actual.has(relay));
}

/**
 * Fixed public graph bootstrap is only allowed with a shipped relay set: the one
 * this app ships, or the shared Iris set. A viewer may have saved an earlier
 * shipped set, so relays that were shipped once and have since been retired do
 * not count as a difference.
 */
export function shouldBootstrapPublicGraph(relays: readonly string[]): boolean {
  const normalized = relays.map(normalizedRelay);
  if (normalized.some(relay => relay === null)) return false;
  const retired = new Set(RETIRED_RELAYS.map(normalizedRelay));
  const actual = new Set(normalized.filter(relay => !retired.has(relay)));
  return sameSet(actual, VIDEO_DEFAULT_RELAYS) || sameSet(actual, SHARED_DEFAULT_RELAYS);
}
