import {
  CollectionSource,
  CollectionWriter,
  type CollectionDefinition,
  type CollectionIndexLinkResult,
  type CollectionManifest,
  type CollectionSearchTermContext,
  type Store,
} from '@hashtree/collection';
import { cid, nhashEncode, sha256, type CID } from '@hashtree/core';
import { parseVideoRootCid } from './videoRootKeys.ts';
import { nip19 } from 'nostr-tools';
import { HASHTREE_ROOT_KIND } from '@hashtree/nostr';
import type { VideoCatalogItem } from './videoCatalog';

export const VIDEO_CATALOG_SCHEMA_V2 = 'iris.video.catalog.v2';
export const VIDEO_COLLECTION_SOURCE_SCHEMA = 'iris.video.collection.video@2';
export const VIDEO_COLLECTION_PROJECTION_SCHEMA = 'iris.video.collection.projection@2';
export const VIDEO_COLLECTION_MANIFEST_PATH = 'collections/videos/manifest.json';

export const VIDEO_COLLECTION_INDEX_BY_AUTHOR = 'by-author';
export const VIDEO_COLLECTION_INDEX_BY_SOURCE_EVENT = 'by-source-event';
export const VIDEO_COLLECTION_INDEX_BY_NHASH = 'by-nhash';
export const VIDEO_COLLECTION_INDEX_BY_TAG = 'tag';
export const VIDEO_COLLECTION_SEARCH_VIDEOS = 'videos';
export const VIDEO_COLLECTION_SEARCH_CREATORS = 'creators';
export const VIDEO_COLLECTION_SEARCH_TAGS = 'tags';

export const VIDEO_SEARCH_PREFIX_VIDEO = 'v:';
export const VIDEO_SEARCH_PREFIX_CREATOR = 'c:';
export const VIDEO_SEARCH_PREFIX_TAG = 't:';
export const VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH = 1200;

export const VIDEO_CATALOG_INDEX_FOLLOWED_KEY = 'iris-video:catalog-index-followed';
export const VIDEO_CATALOG_INDEX_ALLOWLIST_KEY = 'iris-video:catalog-index-allowlist';

export type VideoCatalogTrustScope = 'own' | 'followed' | 'allowlisted' | 'catalog' | 'relay';
export type VideoCatalogProvenanceSource = 'catalog-v1' | 'catalog-v2' | 'nostr-kind-30078' | 'nostr-kind-30064' | 'manual';

export interface VideoCatalogProvenance {
  source: VideoCatalogProvenanceSource;
  scope: VideoCatalogTrustScope;
  catalogUrl?: string;
  eventId?: string;
  authorPubkey?: string;
}

export interface VideoCollectionRecord {
  id: string;
  title: string;
  description?: string;
  duration?: number;
  timestamp?: number;
  ownerNpub?: string;
  ownerPubkey?: string;
  treeName?: string;
  videoId?: string;
  href: string;
  nhash?: string;
  thumbnailUrl?: string;
  videoPath?: string;
  tags: string[];
  sourceEvents: string[];
  provenance: VideoCatalogProvenance[];
}

export interface VideoCatalogIndexTrustSettings {
  includeFollowed: boolean;
  allowlistedPubkeys: string[];
}

export interface VideoNostrEventLike {
  kind?: number;
  id?: string;
  pubkey: string;
  created_at?: number;
  tags: string[][];
}

export interface BuiltVideoCollection {
  manifest: CollectionManifest;
  source: CollectionSource;
  records: VideoCollectionRecord[];
}

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function readString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function readNumber(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function normalizeTags(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const raw of value) {
    const tag = readString(raw)?.toLowerCase();
    if (!tag || seen.has(tag)) continue;
    seen.add(tag);
    tags.push(tag);
  }
  return tags;
}

function pubkeyToNpub(pubkey: string | undefined): string | undefined {
  if (!pubkey || !/^[0-9a-f]{64}$/i.test(pubkey)) return undefined;
  try {
    return nip19.npubEncode(pubkey);
  } catch {
    return undefined;
  }
}

function npubToPubkey(npub: string | undefined): string | undefined {
  if (!npub?.startsWith('npub1')) return undefined;
  try {
    const decoded = nip19.decode(npub);
    return decoded.type === 'npub' ? decoded.data as string : undefined;
  } catch {
    return undefined;
  }
}

function normalizePubkey(value: string | undefined): string | undefined {
  if (!value) return undefined;
  if (/^[0-9a-f]{64}$/i.test(value)) return value.toLowerCase();
  return npubToPubkey(value);
}

function normalizeNpubOrPubkey(value: string): string | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (/^[0-9a-f]{64}$/i.test(trimmed)) return trimmed.toLowerCase();
  return npubToPubkey(trimmed) ?? null;
}

function buildLogicalId(record: Omit<VideoCollectionRecord, 'id'>, fallback: string): string {
  const owner = record.ownerPubkey ?? record.ownerNpub;
  if (owner && record.treeName) {
    return [owner, record.treeName, record.videoId].filter(Boolean).join('/');
  }
  if (record.nhash) return record.nhash;
  return fallback;
}

function uniqueStrings(values: Array<string | undefined>): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const value of values) {
    const trimmed = value?.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    result.push(trimmed);
  }
  return result;
}

function stableJson(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((entry) => stableJson(entry)).join(',')}]`;
  }
  const object = value as Record<string, unknown>;
  return `{${Object.keys(object).sort().map((key) => (
    `${JSON.stringify(key)}:${stableJson(object[key])}`
  )).join(',')}}`;
}

function buildSearchTerms(text: string, context: CollectionSearchTermContext): string[] {
  return context.parseKeywords(text).slice(0, 12);
}

function truncateText(value: string | undefined, maxLength: number): string | undefined {
  if (!value) return undefined;
  return value.length > maxLength ? value.slice(0, maxLength).trim() : value;
}

function searchTextForVideo(record: VideoCollectionRecord): string {
  return [
    record.title,
    ...record.tags,
  ].filter(Boolean).join(' ');
}

function searchTextForCreator(record: VideoCollectionRecord): string {
  return [
    record.ownerNpub,
    record.ownerPubkey,
  ].filter(Boolean).join(' ');
}

function timestampKey(timestamp: number | undefined): string {
  const value = Number.isFinite(timestamp) ? Math.max(0, Math.floor(timestamp ?? 0)) : 0;
  return `${9_999_999_999 - Math.min(value, 9_999_999_999)}`.padStart(10, '0');
}

function keyPart(value: string): string {
  return value.replace(/\s+/g, ' ').trim().toLowerCase();
}

function normalizeProvenanceSource(value: unknown): VideoCatalogProvenanceSource {
  return value === 'catalog-v1'
    || value === 'catalog-v2'
    || value === 'nostr-kind-30078'
    || value === 'nostr-kind-30064'
    || value === 'manual'
    ? value
    : 'manual';
}

function normalizeTrustScope(value: unknown): VideoCatalogTrustScope {
  return value === 'own'
    || value === 'followed'
    || value === 'allowlisted'
    || value === 'catalog'
    || value === 'relay'
    ? value
    : 'catalog';
}

export function createVideoCollectionSourceId(owner = 'local', treeName = 'video-catalog'): string {
  const normalizedOwner = owner.trim() || 'local';
  const normalizedTree = treeName.trim() || 'video-catalog';
  return `${normalizedOwner}/${normalizedTree}/videos`;
}

export function createVideoCollectionDefinition(sourceId: string): CollectionDefinition<VideoCollectionRecord> {
  const searchOptions = { order: 64, minKeywordLength: 1 };
  return {
    sourceId,
    schemaVersion: 2,
    publishedSchema: {
      itemFormat: VIDEO_COLLECTION_SOURCE_SCHEMA,
      projectionFormat: VIDEO_COLLECTION_PROJECTION_SCHEMA,
    },
    schema: {
      version: 2,
      normalize: normalizeVideoCollectionRecord,
      validate: (record) => {
        if (!record.id.trim()) throw new Error('Video collection record id is required');
        if (!record.title.trim()) throw new Error('Video collection record title is required');
        if (!record.href.trim()) throw new Error('Video collection record href is required');
      },
    },
    getId: (record) => record.id,
    keyIndexes: [
      {
        name: VIDEO_COLLECTION_INDEX_BY_AUTHOR,
        keys: (record) => {
          const author = record.ownerPubkey ?? record.ownerNpub;
          return author ? [`${keyPart(author)}\t${timestampKey(record.timestamp)}\t${record.id}`] : [];
        },
      },
      {
        name: VIDEO_COLLECTION_INDEX_BY_SOURCE_EVENT,
        keys: (record) => record.sourceEvents.map((eventId) => `${keyPart(eventId)}\t${record.id}`),
      },
      {
        name: VIDEO_COLLECTION_INDEX_BY_NHASH,
        keys: (record) => record.nhash ? [`${keyPart(record.nhash)}\t${record.id}`] : [],
      },
      {
        name: VIDEO_COLLECTION_INDEX_BY_TAG,
        keys: (record) => record.tags.map((tag) => `${keyPart(tag)}\t${timestampKey(record.timestamp)}\t${record.id}`),
      },
    ],
    searchIndexes: [
      {
        name: VIDEO_COLLECTION_SEARCH_VIDEOS,
        prefix: VIDEO_SEARCH_PREFIX_VIDEO,
        options: searchOptions,
        text: searchTextForVideo,
        terms: buildSearchTerms,
      },
      {
        name: VIDEO_COLLECTION_SEARCH_CREATORS,
        prefix: VIDEO_SEARCH_PREFIX_CREATOR,
        options: searchOptions,
        entries: (record, context) => {
          const creatorId = record.ownerPubkey ?? record.ownerNpub;
          if (!creatorId) return [];
          return [{
            id: creatorId,
            cid: context.cid,
            text: searchTextForCreator(record),
          }];
        },
        terms: buildSearchTerms,
      },
      {
        name: VIDEO_COLLECTION_SEARCH_TAGS,
        prefix: VIDEO_SEARCH_PREFIX_TAG,
        options: searchOptions,
        entries: (record, context) => record.tags.map((tag) => ({
          id: tag,
          cid: context.cid,
          text: tag,
        })),
        terms: buildSearchTerms,
      },
    ],
  };
}

export function normalizeVideoCollectionRecord(value: unknown): VideoCollectionRecord {
  const input = (value && typeof value === 'object' ? value : {}) as Partial<VideoCollectionRecord>;
  const ownerPubkey = normalizePubkey(readString(input.ownerPubkey) ?? readString(input.ownerNpub));
  const ownerNpub = readString(input.ownerNpub) ?? pubkeyToNpub(ownerPubkey);
  const title = readString(input.title) ?? 'Untitled video';
  const href = readString(input.href) ?? (ownerNpub && input.treeName
    ? `#/${ownerNpub}/${encodeURIComponent(input.treeName)}`
    : '');

  const recordWithoutId: Omit<VideoCollectionRecord, 'id'> = {
    title,
    ...(truncateText(readString(input.description), VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH)
      ? { description: truncateText(readString(input.description), VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH) }
      : {}),
    ...(readNumber(input.duration) !== undefined ? { duration: readNumber(input.duration) } : {}),
    ...(readNumber(input.timestamp) !== undefined ? { timestamp: Math.floor(readNumber(input.timestamp)!) } : {}),
    ...(ownerNpub ? { ownerNpub } : {}),
    ...(ownerPubkey ? { ownerPubkey } : {}),
    ...(readString(input.treeName) ? { treeName: readString(input.treeName) } : {}),
    ...(readString(input.videoId) ? { videoId: readString(input.videoId) } : {}),
    href,
    ...(readString(input.nhash) ? { nhash: readString(input.nhash) } : {}),
    ...(readString(input.thumbnailUrl) ? { thumbnailUrl: readString(input.thumbnailUrl) } : {}),
    ...(readString(input.videoPath) ? { videoPath: readString(input.videoPath) } : {}),
    tags: normalizeTags(input.tags),
    sourceEvents: uniqueStrings(input.sourceEvents ?? []),
    provenance: Array.isArray(input.provenance)
      ? input.provenance
          .filter((entry): entry is VideoCatalogProvenance => !!entry && typeof entry === 'object')
          .map((entry) => ({
            source: normalizeProvenanceSource(entry.source),
            scope: normalizeTrustScope(entry.scope),
            ...(readString(entry.catalogUrl) ? { catalogUrl: readString(entry.catalogUrl) } : {}),
            ...(readString(entry.eventId) ? { eventId: readString(entry.eventId) } : {}),
            ...(readString(entry.authorPubkey) ? { authorPubkey: readString(entry.authorPubkey) } : {}),
          }))
      : [],
  };

  return {
    id: readString(input.id) ?? buildLogicalId(recordWithoutId, href || title),
    ...recordWithoutId,
  };
}

export function videoCatalogItemToCollectionRecord(
  item: VideoCatalogItem,
  options: { scope?: VideoCatalogTrustScope; source?: VideoCatalogProvenanceSource } = {},
): VideoCollectionRecord {
  return normalizeVideoCollectionRecord({
    id: item.id,
    title: item.title,
    description: item.description,
    duration: item.duration,
    timestamp: item.timestamp,
    ownerNpub: item.ownerNpub,
    ownerPubkey: item.ownerPubkey,
    treeName: item.treeName,
    videoId: item.videoId,
    href: item.href,
    nhash: item.nhash,
    thumbnailUrl: item.thumbnailUrl,
    videoPath: item.videoPath,
    tags: item.tags,
    provenance: [{
      source: options.source ?? 'catalog-v1',
      scope: options.scope ?? 'catalog',
      catalogUrl: item.catalogUrl,
      authorPubkey: item.ownerPubkey,
    }],
  });
}

export function videoRecordToCatalogItem(record: VideoCollectionRecord, catalogUrl: string): VideoCatalogItem {
  return {
    id: record.id,
    title: record.title,
    description: record.description,
    duration: record.duration,
    timestamp: record.timestamp,
    ownerNpub: record.ownerNpub,
    ownerPubkey: record.ownerPubkey,
    treeName: record.treeName,
    videoId: record.videoId,
    href: record.href,
    nhash: record.nhash,
    thumbnailUrl: record.thumbnailUrl,
    videoPath: record.videoPath,
    tags: record.tags,
    catalogUrl,
  };
}

export function videoRecordFromNostrTreeEvent(
  event: VideoNostrEventLike,
  scope: VideoCatalogTrustScope,
): VideoCollectionRecord | null {
  const dTag = event.tags.find((tag) => tag[0] === 'd')?.[1];
  if (!dTag?.startsWith('videos/')) return null;

  const hashTag = event.tags.find((tag) => tag[0] === 'hash')?.[1];

  const hasEncryptedKey = event.tags.some((tag) => tag[0] === 'encryptedKey');
  const hasSelfEncryptedKey = event.tags.some((tag) => tag[0] === 'selfEncryptedKey');
  if (hasEncryptedKey || hasSelfEncryptedKey) return null;

  const ownerPubkey = event.pubkey.toLowerCase();
  const ownerNpub = pubkeyToNpub(ownerPubkey);
  if (!ownerNpub) return null;

  const keyTag = event.tags.find((tag) => tag[0] === 'key')?.[1];
  const rootCid = parseVideoRootCid(hashTag, keyTag);
  if (!rootCid) return null;

  const title = dTag.slice('videos/'.length);
  return normalizeVideoCollectionRecord({
    id: event.id ? `${ownerPubkey}:${event.id}` : `${ownerPubkey}:${dTag}`,
    title,
    timestamp: event.created_at,
    ownerPubkey,
    ownerNpub,
    treeName: dTag,
    href: `#/${ownerNpub}/${encodeURIComponent(dTag)}`,
    nhash: nhashEncode(rootCid),
    sourceEvents: event.id ? [event.id] : [],
    provenance: [{
      source: event.kind === HASHTREE_ROOT_KIND ? 'nostr-kind-30064' : 'nostr-kind-30078',
      scope,
      eventId: event.id,
      authorPubkey: ownerPubkey,
    }],
  });
}

function mergeProvenance(existing: VideoCatalogProvenance[], next: VideoCatalogProvenance[]): VideoCatalogProvenance[] {
  const byKey = new Map<string, VideoCatalogProvenance>();
  for (const entry of [...existing, ...next]) {
    const key = [
      entry.source,
      entry.scope,
      entry.catalogUrl ?? '',
      entry.eventId ?? '',
      entry.authorPubkey ?? '',
    ].join('\t');
    byKey.set(key, entry);
  }
  return Array.from(byKey.values());
}

export function mergeVideoCollectionRecords(records: VideoCollectionRecord[]): VideoCollectionRecord[] {
  const byId = new Map<string, VideoCollectionRecord>();
  for (const rawRecord of records) {
    const record = normalizeVideoCollectionRecord(rawRecord);
    const existing = byId.get(record.id);
    if (!existing) {
      byId.set(record.id, record);
      continue;
    }

    const preferNext = (record.timestamp ?? 0) >= (existing.timestamp ?? 0);
    const base = preferNext ? record : existing;
    const other = preferNext ? existing : record;
    byId.set(record.id, normalizeVideoCollectionRecord({
      ...other,
      ...base,
      tags: uniqueStrings([...other.tags, ...base.tags]),
      sourceEvents: uniqueStrings([...other.sourceEvents, ...base.sourceEvents]),
      provenance: mergeProvenance(other.provenance, base.provenance),
    }));
  }

  return Array.from(byId.values()).sort((a, b) => {
    if ((b.timestamp ?? 0) !== (a.timestamp ?? 0)) return (b.timestamp ?? 0) - (a.timestamp ?? 0);
    return a.id.localeCompare(b.id);
  });
}

async function writeRecordBlob(store: Store, record: VideoCollectionRecord): Promise<CID> {
  const bytes = encoder.encode(stableJson(record));
  const hash = await sha256(bytes);
  await store.put(hash, bytes);
  return cid(hash);
}

export async function buildVideoCollection(
  store: Store,
  records: VideoCollectionRecord[],
  options: { sourceId?: string; updatedAt?: number; metadata?: Record<string, unknown> } = {},
): Promise<BuiltVideoCollection> {
  const mergedRecords = mergeVideoCollectionRecords(records);
  const sourceId = options.sourceId ?? createVideoCollectionSourceId();
  const definition = createVideoCollectionDefinition(sourceId);
  const writer = new CollectionWriter<VideoCollectionRecord>(store, definition);

  for (const record of mergedRecords) {
    const recordCid = await writeRecordBlob(store, record);
    await writer.put(record, recordCid);
  }

  const manifest = writer.manifest({
    schema: VIDEO_CATALOG_SCHEMA_V2,
    recordCount: mergedRecords.length,
    ...(options.metadata ?? {}),
  });
  if (Number.isFinite(options.updatedAt)) {
    manifest.updatedAt = Math.floor(options.updatedAt!);
  }

  return {
    manifest,
    source: new CollectionSource(store, manifest, createVideoCollectionDefinition(sourceId)),
    records: mergedRecords,
  };
}

export function createVideoCollectionSource(store: Store, manifest: CollectionManifest): CollectionSource {
  return new CollectionSource(store, manifest, createVideoCollectionDefinition(manifest.sourceId));
}

export async function readVideoCollectionRecord(store: Store, recordCid: CID): Promise<VideoCollectionRecord | null> {
  const bytes = await store.get(recordCid.hash);
  if (!bytes) return null;
  try {
    return normalizeVideoCollectionRecord(JSON.parse(decoder.decode(bytes)));
  } catch {
    return null;
  }
}

export async function videoCollectionRecordsFromLinks(
  store: Store,
  hits: Array<CollectionIndexLinkResult | { cid: CID; score?: number }>,
): Promise<VideoCollectionRecord[]> {
  const records: VideoCollectionRecord[] = [];
  const seen = new Set<string>();
  for (const hit of hits) {
    const record = await readVideoCollectionRecord(store, hit.cid);
    if (!record || seen.has(record.id)) continue;
    seen.add(record.id);
    records.push(record);
  }
  return records;
}

function authorQueryPrefixes(author: string): string[] {
  const normalized = normalizePubkey(author);
  const prefixes = uniqueStrings([
    normalized,
    author.startsWith('npub1') ? author : undefined,
  ]);
  return prefixes.map((prefix) => `${prefix}\t`);
}

export async function searchVideoCollectionRecords(
  store: Store,
  source: CollectionSource,
  query: string,
  limit = 20,
): Promise<VideoCollectionRecord[]> {
  const hits = await source.search(VIDEO_COLLECTION_SEARCH_VIDEOS, query, { limit: limit * 2 });
  const records = await videoCollectionRecordsFromLinks(store, hits);
  return records
    .sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0))
    .slice(0, limit);
}

export async function searchVideoCollectionCreators(
  store: Store,
  source: CollectionSource,
  query: string,
  limit = 20,
): Promise<VideoCollectionRecord[]> {
  const hits = await source.search(VIDEO_COLLECTION_SEARCH_CREATORS, query, { limit: limit * 2 });
  return (await videoCollectionRecordsFromLinks(store, hits)).slice(0, limit);
}

export async function searchVideoCollectionTags(
  store: Store,
  source: CollectionSource,
  query: string,
  limit = 20,
): Promise<VideoCollectionRecord[]> {
  const hits = await source.search(VIDEO_COLLECTION_SEARCH_TAGS, query, { limit: limit * 2 });
  return (await videoCollectionRecordsFromLinks(store, hits)).slice(0, limit);
}

export async function queryVideoCollectionRecordsByAuthor(
  store: Store,
  source: CollectionSource,
  author: string,
  limit = 50,
): Promise<VideoCollectionRecord[]> {
  const hits: CollectionIndexLinkResult[] = [];
  for (const prefix of authorQueryPrefixes(author)) {
    hits.push(...await source.queryIndex(VIDEO_COLLECTION_INDEX_BY_AUTHOR, {
      prefix,
      limit: limit * 2,
    }));
  }
  const records = await videoCollectionRecordsFromLinks(store, hits);
  return records
    .sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0))
    .slice(0, limit);
}

export function getVideoCatalogIndexTrustSettings(): VideoCatalogIndexTrustSettings {
  if (typeof window === 'undefined') {
    return { includeFollowed: false, allowlistedPubkeys: [] };
  }
  try {
    const includeFollowed = window.localStorage.getItem(VIDEO_CATALOG_INDEX_FOLLOWED_KEY) === '1';
    const allowlistedPubkeys = JSON.parse(window.localStorage.getItem(VIDEO_CATALOG_INDEX_ALLOWLIST_KEY) ?? '[]');
    return {
      includeFollowed,
      allowlistedPubkeys: Array.isArray(allowlistedPubkeys)
        ? uniqueStrings(allowlistedPubkeys.map((value) => normalizeNpubOrPubkey(`${value ?? ''}`) ?? undefined))
        : [],
    };
  } catch {
    return { includeFollowed: false, allowlistedPubkeys: [] };
  }
}

export function saveVideoCatalogIndexTrustSettings(settings: VideoCatalogIndexTrustSettings): void {
  if (typeof window === 'undefined') return;
  const allowlistedPubkeys = uniqueStrings(
    settings.allowlistedPubkeys.map((value) => normalizeNpubOrPubkey(value) ?? undefined),
  );
  window.localStorage.setItem(VIDEO_CATALOG_INDEX_FOLLOWED_KEY, settings.includeFollowed ? '1' : '0');
  window.localStorage.setItem(VIDEO_CATALOG_INDEX_ALLOWLIST_KEY, JSON.stringify(allowlistedPubkeys));
}

export function classifyVideoEventTrustScope(options: {
  authorPubkey: string;
  ownPubkey?: string | null;
  follows?: readonly string[];
  settings?: VideoCatalogIndexTrustSettings;
}): VideoCatalogTrustScope | null {
  const author = normalizePubkey(options.authorPubkey);
  if (!author) return null;
  const ownPubkey = normalizePubkey(options.ownPubkey ?? undefined);
  if (ownPubkey && author === ownPubkey) return 'own';

  const settings = options.settings ?? getVideoCatalogIndexTrustSettings();
  const allowlist = new Set(settings.allowlistedPubkeys.map((value) => normalizePubkey(value)).filter(Boolean));
  if (allowlist.has(author)) return 'allowlisted';

  if (settings.includeFollowed) {
    const follows = new Set((options.follows ?? []).map((value) => normalizePubkey(value)).filter(Boolean));
    if (follows.has(author)) return 'followed';
  }

  return null;
}

export function buildVideoCatalogRootPayloadV2(options: {
  title?: string;
  name?: string;
  generatedAt?: string;
  manifestPath?: string;
  videos?: unknown[];
} = {}): Record<string, unknown> {
  return {
    version: 2,
    schema: VIDEO_CATALOG_SCHEMA_V2,
    title: readString(options.title),
    name: readString(options.name),
    generatedAt: options.generatedAt ?? new Date().toISOString(),
    collections: {
      videos: {
        manifestPath: options.manifestPath ?? VIDEO_COLLECTION_MANIFEST_PATH,
      },
    },
    ...(options.videos ? { videos: options.videos } : {}),
  };
}
