/**
 * The relays the video app ships with: the shared Iris set plus Divine's relay,
 * which carries NIP-71 videos and shorts and supports text search.
 */
import { DEFAULT_PUBLIC_RELAYS, RETIRED_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';

const VIDEO_RELAYS = ['wss://relay.divine.video'];

export const SHARED_DEFAULT_RELAYS: readonly string[] = DEFAULT_PUBLIC_RELAYS;

/** Relays that were shipped once and no longer answer; a saved list may still hold them. */
export const RETIRED_RELAYS: readonly string[] = RETIRED_PUBLIC_RELAYS;

export const VIDEO_DEFAULT_RELAYS: string[] = [
  ...DEFAULT_PUBLIC_RELAYS.filter((relay) => !RETIRED_PUBLIC_RELAYS.includes(relay)),
  ...VIDEO_RELAYS,
];
