/**
 * Images hosted outside hashtree (thumbnails and posters of videos other apps
 * publish) are ordinary web images. They are fetched through the image proxy
 * chosen in settings: smaller files, and the image's host does not see the
 * viewer. The original URL is the fallback when the proxy cannot serve it, and
 * the only candidate when the proxy is switched off.
 */
import { get } from 'svelte/store';
import { DEFAULT_IMGPROXY_CONFIG, generateProxyUrl, type ImgProxyConfig } from '../utils/imgproxy';
import { settingsStore } from '../stores/settings';

export function isWebUrl(url: string | null | undefined): url is string {
  return !!url && /^https?:\/\//i.test(url);
}

/** The image proxy to use, or null when the viewer switched it off. */
export function activeImageProxy(): ImgProxyConfig | null {
  const { enabled, url, key, salt } = get(settingsStore).imgproxy;
  if (!enabled) return null;
  return url && key && salt ? { url, key, salt } : DEFAULT_IMGPROXY_CONFIG;
}

/** Candidate URLs for a web-hosted image, best first, or null when the URL is not a web URL. */
export function webThumbnailCandidateUrls(url: string | null | undefined, width = 640, height = 360): string[] | null {
  if (!isWebUrl(url)) return null;
  const proxy = activeImageProxy();
  if (!proxy) return [url];
  const proxied = generateProxyUrl(url, { width, height, square: true }, proxy);
  return proxied === url ? [url] : [proxied, url];
}
