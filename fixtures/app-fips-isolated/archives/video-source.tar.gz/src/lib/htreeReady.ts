/**
 * Whether same-origin `/htree/...` addresses can be loaded yet.
 *
 * Only the service worker can answer them, and on a first visit it takes a
 * couple of seconds to install. The app renders without waiting for it, so
 * whatever shows hashtree media holds those requests back until this turns
 * true: asked too early they would hit the web server and come back 404.
 */
import { writable } from 'svelte/store';

export const htreeReady = writable(false);

export function markHtreeReady(): void {
  htreeReady.set(true);
}

/** A same-origin hashtree address (relative, or absolute on this site). */
export function needsHtree(url: string | null | undefined): boolean {
  if (!url) return false;
  if (url.startsWith('/htree/')) return true;
  if (typeof window === 'undefined' || !url.startsWith('http')) return false;
  try {
    const parsed = new URL(url);
    return parsed.origin === window.location.origin && parsed.pathname.startsWith('/htree/');
  } catch {
    return false;
  }
}
