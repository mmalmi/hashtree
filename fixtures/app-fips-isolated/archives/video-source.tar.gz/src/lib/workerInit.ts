/**
 * Backend Initialization
 *
 * Initializes either the browser worker runtime or the native Rust-backed
 * backend, depending on the current host environment.
 */

import {
  initWorkerAdapter,
  getWorkerAdapter as getSharedBackendAdapter,
  setWorkerAdapterInstance,
  type BackendAdapter,
} from '../workerAdapter';
import { initNativeBackend } from '../nativeAdapter';
import {
  settingsStore,
  waitForSettingsLoaded,
} from '../stores/settings';
import { refreshWebRTCStats, setBlossomBandwidth } from '../store';
import { get } from 'svelte/store';
import { setupVersionCallback } from '../utils/socialGraph';
import { nostr } from '../nostr/client';
import { initRelayTracking } from '../nostr/relays';
import { getAppType } from '../appType';
import { logHtreeDebug } from './htreeDebug';
import { getRuntimeEndpoints, getRuntimeHtreeServerUrl } from './htreeRuntime';
import { getEffectiveBlossomServers, getEffectiveNostrRelays } from './runtimeNetwork';
import { treeRootRegistry } from '../TreeRootRegistry';
import { initializePublishFn } from '../treeRootCache';
import { setupMediaStreaming } from './mediaStreamingSetup';
import type { WorkerNostrFilter } from '@hashtree/core';
import { IndexedDbIdentityStore } from '@fips/browser';
import type { FipsIdentity } from '@fips/core';
import {
  IRIS_VIDEO_FIPS_IDENTITY_STORE,
  startDriveFipsRuntime,
  stopDriveFipsRuntime,
} from './driveFipsRuntime';

const isTestMode = !!import.meta.env.VITE_TEST_MODE;

/**
 * Get the active backend adapter
 */
export function getWorkerAdapter(): BackendAdapter | null {
  return getSharedBackendAdapter();
}

if (typeof window !== 'undefined') {
  (window as typeof window & { __getWorkerAdapter?: () => BackendAdapter | null }).__getWorkerAdapter = getWorkerAdapter;
}

export async function waitForWorkerAdapter(maxWaitMs = 5000): Promise<BackendAdapter | null> {
  const start = Date.now();
  let adapter = getWorkerAdapter();
  while (!adapter && Date.now() - start < maxWaitMs) {
    await new Promise(resolve => setTimeout(resolve, 50));
    adapter = getWorkerAdapter();
  }
  return adapter;
}

let initialized = false;
let initPromise: Promise<void> | null = null;
let lastBlossomServersHash = '';
let lastRelaysHash = '';
/**
 * The peer network announces itself with over a thousand events, which the worker
 * verifies one at a time ahead of anything arriving after them. On a first visit
 * that buried the first page's names and thumbnails for half a minute, so it joins
 * once the first page has had time to load. Files come from the file servers meanwhile.
 */
const PEER_NETWORK_START_DELAY_MS = isTestMode ? 0 : 8000;
let fipsStoreName: string | null = null;
let fipsRuntimeReadyFor: BackendAdapter | null = null;
let fipsDesiredKey = '';
let fipsActiveKey = '';
let fipsSyncVersion = 0;
let fipsSyncTail: Promise<void> = Promise.resolve();
let fipsRetryTimer: ReturnType<typeof setTimeout> | null = null;
let fipsRetryDelayMs = 1_000;

function clearFipsRetry(): void {
  if (fipsRetryTimer) clearTimeout(fipsRetryTimer);
  fipsRetryTimer = null;
}

function startFipsForAdapter(
  adapter: BackendAdapter,
  relays: string[],
  storeName: string,
  retry = false,
): Promise<void> {
  const desiredKey = JSON.stringify({ relays, storeName });
  if (desiredKey === fipsDesiredKey) return fipsSyncTail;
  clearFipsRetry();
  if (!retry) fipsRetryDelayMs = 1_000;
  fipsDesiredKey = desiredKey;
  const version = ++fipsSyncVersion;
  const sync = fipsSyncTail.catch(() => undefined).then(async () => {
    if (version !== fipsSyncVersion || getWorkerAdapter() !== adapter) return;
    if (desiredKey === fipsActiveKey && fipsRuntimeReadyFor === adapter) return;

    fipsRuntimeReadyFor = null;
    adapter.setP2PProvider?.(null);
    await adapter.setNostrSource?.(null);
    await stopDriveFipsRuntime();
    if (version !== fipsSyncVersion || getWorkerAdapter() !== adapter) return;

    try {
      const runtime = await startDriveFipsRuntime({
        identity: await getVideoFipsDeviceIdentity(),
        relays,
        storeName,
        log: isTestMode,
        websocketSeedUrls: isTestMode ? window.__testFipsWebsocketSeedUrls : undefined,
      });
      if (version !== fipsSyncVersion || getWorkerAdapter() !== adapter) {
        await runtime.stop();
        return;
      }
      adapter.setP2PProvider?.(runtime.getP2PProvider());
      await adapter.setNostrSource?.(runtime.getP2PProvider().nostrSource);
      fipsActiveKey = desiredKey;
      fipsRuntimeReadyFor = adapter;
      fipsRetryDelayMs = 1_000;
      console.log('[WorkerInit] FIPS runtime ready');
    } catch (error) {
      if (version !== fipsSyncVersion) return;
      fipsDesiredKey = '';
      console.warn('[WorkerInit] FIPS runtime failed to start:', error);
      const delay = fipsRetryDelayMs;
      fipsRetryDelayMs = Math.min(delay * 2, 30_000);
      fipsRetryTimer = setTimeout(() => {
        fipsRetryTimer = null;
        if (getWorkerAdapter() === adapter && fipsStoreName === storeName) {
          void startFipsForAdapter(adapter, relays, storeName, true);
        }
      }, delay);
    }
  });
  fipsSyncTail = sync;
  return sync;
}

let videoFipsDeviceIdentityPromise: Promise<FipsIdentity> | null = null;

function getVideoFipsDeviceIdentity(): Promise<FipsIdentity> {
  if (!videoFipsDeviceIdentityPromise) {
    const pending = (async () => {
      const store = new IndexedDbIdentityStore(IRIS_VIDEO_FIPS_IDENTITY_STORE);
      if (isTestMode && typeof localStorage !== 'undefined') {
        const testSecret = localStorage.getItem('iris-video:test-fips-secret-key');
        if (testSecret) await store.importNsec?.(testSecret);
      }
      return store.getOrCreateIdentity();
    })();
    const tracked = pending.catch((error) => {
      if (videoFipsDeviceIdentityPromise === tracked) {
        videoFipsDeviceIdentityPromise = null;
      }
      throw error;
    });
    videoFipsDeviceIdentityPromise = tracked;
  }
  return videoFipsDeviceIdentityPromise;
}

/**
 * Sync blossom server settings from settings store to worker.
 * Uses a hash to avoid duplicate updates.
 */
function syncBlossomServers(): void {
  const adapter = getWorkerAdapter();
  if (!adapter) return;

  const settings = get(settingsStore);
  const blossomServers = getEffectiveBlossomServers(settings.network.blossomServers);

  // Hash to avoid duplicate updates
  const serversHash = JSON.stringify(blossomServers);
  if (serversHash === lastBlossomServersHash) return;
  lastBlossomServersHash = serversHash;

  console.log('[WorkerInit] Syncing blossom servers to worker:', blossomServers.length, 'servers');
  adapter.setBlossomServers(blossomServers);
}

/**
 * Sync relay settings from settings store to worker.
 * Uses a hash to avoid duplicate updates.
 */
function syncRelays(): void {
  const adapter = getWorkerAdapter();
  if (!adapter) return;

  if (!('setRelays' in adapter)) return;

  const settings = get(settingsStore);
  const relays = getEffectiveNostrRelays(settings.network.relays);

  // Hash to avoid duplicate updates
  const relaysHash = JSON.stringify(relays);
  if (relaysHash === lastRelaysHash) return;
  lastRelaysHash = relaysHash;

  console.log('[WorkerInit] Syncing relays to worker:', relays.length, 'relays');
  void adapter.setRelays(relays).catch((error) => {
    lastRelaysHash = '';
    console.warn('[WorkerInit] Failed to sync event servers:', error);
  });
  if (fipsStoreName) void startFipsForAdapter(adapter, relays, fipsStoreName);
}

let lastStorageMaxBytesHash = '';

/**
 * Sync storage limit from settings store to worker.
 * Uses a hash to avoid duplicate updates.
 */
function syncStorageSettings(): void {
  const adapter = getWorkerAdapter();
  if (!adapter) return;

  const settings = get(settingsStore);
  const maxBytes = settings.storage.maxBytes;

  // Hash to avoid duplicate updates
  const storageHash = String(maxBytes);
  if (storageHash === lastStorageMaxBytesHash) return;
  lastStorageMaxBytesHash = storageHash;

  console.log('[WorkerInit] Syncing storage limit to worker:', Math.round(maxBytes / 1024 / 1024), 'MB');
  adapter.setStorageMaxBytes(maxBytes);
}

// Track tree root registry subscription and worker update listener
let treeRootRegistryUnsubscribe: (() => void) | null = null;
let workerTreeRootUnsubscribe: (() => void) | null = null;

/**
 * Set up bidirectional sync between tree root registry and worker.
 * - Local writes (main->worker): For worker to publish to Nostr
 * - Worker updates (worker->main): Nostr subscription results
 */
function setupTreeRootRegistryBridge(): void {
  // Clean up previous subscriptions
  if (treeRootRegistryUnsubscribe) {
    treeRootRegistryUnsubscribe();
    treeRootRegistryUnsubscribe = null;
  }
  if (workerTreeRootUnsubscribe) {
    workerTreeRootUnsubscribe();
    workerTreeRootUnsubscribe = null;
  }

  const adapter = getWorkerAdapter();
  if (!adapter) return;

  // 1. Sync local writes from main thread to worker (for publishing)
  if ('setTreeRootCache' in adapter) {
    treeRootRegistryUnsubscribe = treeRootRegistry.subscribeAll(async (key, record) => {
      // Only sync local writes - worker handles its own Nostr updates
      if (!record || record.source !== 'local-write') return;

      const slashIndex = key.indexOf('/');
      if (slashIndex <= 0) return;

      const npub = key.slice(0, slashIndex);
      const treeName = key.slice(slashIndex + 1);

      try {
        await (adapter as {
          setTreeRootCache: (
            npub: string,
            treeName: string,
            hash: Uint8Array,
            key?: Uint8Array,
            visibility?: 'public' | 'link-visible' | 'private',
            labels?: string[],
            metadata?: {
              encryptedKey?: string;
              keyId?: string;
              selfEncryptedKey?: string;
              selfEncryptedLinkKey?: string;
            }
          ) => Promise<void>;
        }).setTreeRootCache(npub, treeName, record.hash, record.key, record.visibility, record.labels, {
          encryptedKey: record.encryptedKey,
          keyId: record.keyId,
          selfEncryptedKey: record.selfEncryptedKey,
          selfEncryptedLinkKey: record.selfEncryptedLinkKey,
        });
      } catch (err) {
        console.warn('[WorkerInit] Failed to sync local write to worker:', err);
      }
    });

    // Sync existing persisted entries to worker.
    // This primes worker /htree fetches on reload even when the latest
    // cached source is "worker"/"nostr" (not only "local-write").
    for (const [key, record] of treeRootRegistry.getAllRecords()) {
      const slashIndex = key.indexOf('/');
      if (slashIndex <= 0) continue;

      const npub = key.slice(0, slashIndex);
      const treeName = key.slice(slashIndex + 1);

      (adapter as {
        setTreeRootCache: (
          npub: string,
          treeName: string,
          hash: Uint8Array,
          key?: Uint8Array,
          visibility?: 'public' | 'link-visible' | 'private',
          labels?: string[],
          metadata?: {
            encryptedKey?: string;
            keyId?: string;
            selfEncryptedKey?: string;
            selfEncryptedLinkKey?: string;
          }
        ) => Promise<void>;
      })
        .setTreeRootCache(npub, treeName, record.hash, record.key, record.visibility, record.labels, {
          encryptedKey: record.encryptedKey,
          keyId: record.keyId,
          selfEncryptedKey: record.selfEncryptedKey,
          selfEncryptedLinkKey: record.selfEncryptedLinkKey,
        })
        .catch(err => console.warn('[WorkerInit] Failed to sync initial local write to worker:', err));
    }
  }

  // 2. Listen for worker tree root updates (from Nostr subscriptions)
  if ('onTreeRootUpdate' in adapter) {
    workerTreeRootUnsubscribe = (adapter as { onTreeRootUpdate: (cb: (npub: string, treeName: string, hash: Uint8Array, updatedAt: number, options: { key?: Uint8Array; visibility: string; labels?: string[]; encryptedKey?: string; keyId?: string; selfEncryptedKey?: string; selfEncryptedLinkKey?: string }) => void) => () => void })
      .onTreeRootUpdate((npub, treeName, hash, updatedAt, options) => {
        treeRootRegistry.setFromWorker(npub, treeName, hash, updatedAt, {
          key: options.key,
          visibility: options.visibility as 'public' | 'link-visible' | 'private',
          labels: options.labels,
          encryptedKey: options.encryptedKey,
          keyId: options.keyId,
          selfEncryptedKey: options.selfEncryptedKey,
          selfEncryptedLinkKey: options.selfEncryptedLinkKey,
        });
      });
  }

  console.log('[WorkerInit] Tree root registry bridge set up (bidirectional)');
}

export interface WorkerInitIdentity {
  pubkey: string;
  nsec?: string;  // hex-encoded secret key (only for nsec login)
}

function shouldUseNativeBackend(): boolean {
  return !!getRuntimeHtreeServerUrl();
}

/**
 * Wait for service worker to be ready (needed for COOP/COEP headers)
 */
async function waitForServiceWorker(maxWaitMs?: number): Promise<boolean> {
  if (shouldUseNativeBackend()) return true;
  if (!('serviceWorker' in navigator)) return true;

  try {
    if (navigator.serviceWorker.controller) {
      return true;
    }

    const readyPromise = navigator.serviceWorker.ready.then(() => true);
    if (maxWaitMs === undefined) {
      return await readyPromise;
    }

    const timeoutPromise = new Promise<boolean>((resolve) => {
      setTimeout(() => resolve(false), maxWaitMs);
    });

    return await Promise.race([readyPromise, timeoutPromise]);
  } catch {
    return false;
  }
}

/**
 * Initialize the active hashtree backend with user identity.
 * Safe to call multiple times - only initializes once.
 */
export async function initHashtreeBackend(identity: WorkerInitIdentity): Promise<void> {
  if (initialized) return;
  if (initPromise) {
    await initPromise;
    return;
  }

  initPromise = (async () => {
    const t0 = performance.now();
    const logT = (msg: string) => console.log(`[initHashtreeBackend] ${msg}: ${Math.round(performance.now() - t0)}ms`);
    const backendMode = shouldUseNativeBackend() ? 'native' : 'worker';
    logHtreeDebug('worker:init:start', {
      appType: getAppType(),
      backend: backendMode,
    });

    try {
      // Wait for service worker to be ready before loading workers
      const appType = getAppType();
      const swWaitMs = appType === 'video' ? undefined : 500;
      const serviceWorkerPromise = waitForServiceWorker(swWaitMs).then((ready) => {
        logT(ready ? 'waitForServiceWorker done' : 'waitForServiceWorker timed out');
      });

      // Load settings before worker init so relays/blossom match persisted config.
      const settingsReady = waitForSettingsLoaded().then(() => {
        logT('waitForSettingsLoaded done');
        return true;
      });
      // A slow saved-settings read cannot grant access to public defaults.
      await Promise.all([serviceWorkerPromise, settingsReady]);

      const settings = get(settingsStore);
      const runtimeEndpoints = getRuntimeEndpoints({
        relays: settings.network.relays,
        blossomServers: settings.network.blossomServers,
      });

      const config = {
        storeName: 'hashtree-worker',
        relays: runtimeEndpoints.nostrRelays,
        blossomServers: runtimeEndpoints.blossomServers,
        pubkey: identity.pubkey,
        nsec: identity.nsec,
        ...(backendMode === 'worker' ? { p2pMode: 'external' as const, indexedEventCache: true } : {}),
      };

      // The worker starts with these: syncing the same lists again right after would
      // make it reconnect and, at times, download the social graph a second time.
      if (JSON.stringify(getEffectiveNostrRelays(settings.network.relays)) === JSON.stringify(config.relays)) {
        lastRelaysHash = JSON.stringify(config.relays);
      }
      if (JSON.stringify(getEffectiveBlossomServers(settings.network.blossomServers)) === JSON.stringify(config.blossomServers)) {
        lastBlossomServersHash = JSON.stringify(config.blossomServers);
      }

      let adapter: BackendAdapter | null = null;
      if (backendMode === 'native') {
        logT('Starting native backend');
        adapter = await initNativeBackend(config);
        setWorkerAdapterInstance(adapter);
        logT('Native backend ready');
      } else {
        const { default: HashtreeWorker } = await import('../workers/hashtree.worker?worker');
        logT('Starting web worker');
        adapter = await initWorkerAdapter(HashtreeWorker, config);
        logT('Web worker ready');
      }
      logHtreeDebug('worker:init:ready', { backend: backendMode });

      initialized = true;
      logHtreeDebug('worker:init:done', { backend: backendMode });

      // Hook shared backend callbacks and runtime bridges
      adapter = getWorkerAdapter();
      if (adapter) {
        adapter.onBlossomBandwidth((stats) => {
          setBlossomBandwidth(stats);
        });

        if (backendMode === 'worker') {
          const startPeerNetwork = () => {
            const current = getWorkerAdapter();
            if (!current) return;
            fipsStoreName = config.storeName;
            // The relay list may have changed while this waited.
            void startFipsForAdapter(current, getEffectiveNostrRelays(get(settingsStore).network.relays), config.storeName);
          };
          if (PEER_NETWORK_START_DELAY_MS > 0) setTimeout(startPeerNetwork, PEER_NETWORK_START_DELAY_MS);
          else startPeerNetwork();
        }
        nostr.setBackend({
          subscribe: (filters, onEvent, onHistory) => adapter!.subscribe(filters as unknown as WorkerNostrFilter[], onEvent, onHistory),
          unsubscribe: id => adapter!.unsubscribe(id),
          publish: event => adapter!.publish(event),
        });

        // Signal that the backend is ready for tree root subscriptions
        import('../stores/treeRoot').then(({ signalWorkerReady }) => {
          signalWorkerReady();
        });

        // Start connectivity polling ASAP after worker is ready.
        refreshWebRTCStats();
        setInterval(refreshWebRTCStats, 2000);
        initRelayTracking();
      }

      // Set up social graph version callback
      setupVersionCallback();

      // Subscribe to settings changes to keep worker in sync
      settingsStore.subscribe(() => {
        if (initialized) {
          syncBlossomServers();
          syncRelays();
          syncStorageSettings();
        }
      });

      // Initial sync of all settings to worker
      syncBlossomServers();
      syncRelays();
      syncStorageSettings();

      // Set up tree root registry bridge to sync cache to worker
      setupTreeRootRegistryBridge();

      // Initialize the publish function now that all dependencies are ready
      await initializePublishFn();

      // Set up direct SW <-> Worker communication for file streaming
      setupMediaStreaming().catch(err => {
        console.warn('[WorkerInit] Media streaming setup failed:', err);
      });
    } catch (err) {
      console.error('[WorkerInit] Failed to initialize backend:', err);
    }
  })();

  try {
    await initPromise;
  } finally {
    initPromise = null;
  }
}

/**
 * Check if the worker is initialized and ready.
 */
export function isWorkerReady(): boolean {
  return initialized && getWorkerAdapter() !== null;
}

export function isFipsRuntimeReady(): boolean {
  const adapter = getWorkerAdapter();
  return adapter !== null && fipsRuntimeReadyFor === adapter;
}

/**
 * Wait for at least one relay to be connected.
 * Returns immediately if worker is not ready or times out after maxWait ms.
 */
export async function waitForRelayConnection(maxWait = 5000): Promise<boolean> {
  const adapter = getWorkerAdapter();
  if (!adapter) return false;

  const startTime = Date.now();
  const pollInterval = 100;

  while (Date.now() - startTime < maxWait) {
    try {
      const stats = await adapter.getRelayStats();
      const connected = stats.filter(r => r.connected).length;
      if (connected > 0) {
        return true;
      }
    } catch {
      // Ignore errors, keep polling
    }
    await new Promise(resolve => setTimeout(resolve, pollInterval));
  }

  return false;
}

export async function initHashtreeWorker(identity: WorkerInitIdentity): Promise<void> {
  return initHashtreeBackend(identity);
}

export async function stopHashtreeBrowserP2P(): Promise<void> {
  fipsSyncVersion += 1;
  clearFipsRetry();
  fipsRetryDelayMs = 1_000;
  fipsStoreName = null;
  fipsDesiredKey = '';
  fipsActiveKey = '';
  fipsRuntimeReadyFor = null;
  getWorkerAdapter()?.setP2PProvider?.(null);
  await stopDriveFipsRuntime();
}
