/**
 * Read a `videos/...` tree and describe each playable video in it as a
 * NIP-71 event input. A tree is either one video folder or a playlist of them.
 *
 * Shared by the app (own uploads) and the backfill script, so it only needs a
 * tree that can list directories and read files.
 */
import { LinkType, nhashEncode, type CID } from '@hashtree/core';
import { findPlayableMediaEntry, isPlayableMediaFileName } from './playableMedia.ts';
import { decodeVideoTextFile, sanitizeVideoDescription, sanitizeVideoTitle } from './videoText.ts';
import { getInitialPlaylistItemTitle } from './videoDisplayTitle.ts';
import type { VideoEventInput } from './videoEvent.ts';

const MAX_METADATA_JSON_BYTES = 1024 * 1024;
const DEFAULT_READ_TIMEOUT_MS = 8000;
const DEFAULT_CONCURRENCY = 6;
export const DEFAULT_PLAYLIST_ITEM_LIMIT = 500;

export interface VideoTreeEntry {
  name: string;
  cid: CID;
  size?: number;
  type?: number;
  meta?: unknown;
}

export interface VideoTreeReader {
  listDirectory(cid: CID): Promise<VideoTreeEntry[] | null | undefined>;
  readFile(cid: CID): Promise<Uint8Array | null | undefined>;
}

export interface VideoTreeSource {
  ownerNpub: string;
  treeName: string;
  rootCid: CID;
  /** Fallback publication time (unix seconds), e.g. the tree root event time. */
  timestamp?: number;
}

export interface ReadVideoTreeOptions {
  readTimeoutMs?: number;
  concurrency?: number;
  /** Maximum playlist items described per tree. */
  itemLimit?: number;
}

export interface VideoTreeResult {
  kind: 'video' | 'playlist' | 'unreadable';
  inputs: VideoEventInput[];
  /** Playlist items beyond `itemLimit`. */
  skipped: number;
}

interface VideoHints {
  title?: string;
  description?: string;
  duration?: number;
  timestamp?: number;
  thumbnailUrl?: string;
  videoPath?: string;
  width?: number;
  height?: number;
  tags?: string[];
}

function readObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function readPositiveNumber(value: unknown): number | undefined {
  const parsed = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

/** yt-dlp style `YYYYMMDD`. */
function parseUploadDate(value: unknown): number | undefined {
  if (typeof value !== 'string' || !/^\d{8}$/.test(value)) return undefined;
  const time = Date.UTC(Number(value.slice(0, 4)), Number(value.slice(4, 6)) - 1, Number(value.slice(6, 8)));
  return Number.isFinite(time) ? Math.floor(time / 1000) : undefined;
}

function readEpochSeconds(value: unknown): number | undefined {
  const parsed = readPositiveNumber(value);
  if (!parsed) return parseUploadDate(value);
  return Math.floor(parsed > 10_000_000_000 ? parsed / 1000 : parsed);
}

function isThumbnailName(name: string): boolean {
  const lower = name.toLowerCase();
  return lower.startsWith('thumbnail.') || /\.(jpe?g|webp|png)$/.test(lower);
}

function fileHtreeUrl(cid: CID, fileName: string): string {
  return `htree://${nhashEncode(cid)}/${encodeURIComponent(fileName)}`;
}

function embeddedThumbnailUrl(value: unknown, entries: VideoTreeEntry[]): string | undefined {
  if (typeof value !== 'string' || !value.trim()) return undefined;
  const trimmed = value.trim();
  if (trimmed.startsWith('nhash1')) return `htree://${trimmed}`;
  if (trimmed.startsWith('htree://') || trimmed.startsWith('/htree/')) return trimmed;
  const fileName = trimmed.split('/').filter(Boolean).at(-1);
  const entry = fileName ? entries.find((candidate) => candidate.name === fileName) : undefined;
  return entry ? fileHtreeUrl(entry.cid, entry.name) : undefined;
}

function hintsFromMetadata(metadata: unknown, entries: VideoTreeEntry[] = []): VideoHints {
  const object = readObject(metadata);
  if (!object) return {};
  const tags = Array.isArray(object.tags)
    ? object.tags.filter((tag): tag is string => typeof tag === 'string' && !!tag.trim())
    : [];
  return {
    title: sanitizeVideoTitle(object.title) || undefined,
    description: sanitizeVideoDescription(object.description) || undefined,
    duration: readPositiveNumber(object.duration),
    timestamp: readEpochSeconds(object.originalDate ?? object.createdAt ?? object.upload_date ?? object.date),
    thumbnailUrl: embeddedThumbnailUrl(object.thumbnail, entries),
    width: readPositiveNumber(object.width),
    height: readPositiveNumber(object.height),
    ...(tags.length ? { tags } : {}),
  };
}

/** First defined value per field wins. */
function mergeHints(...hintsList: VideoHints[]): VideoHints {
  const merged: Record<string, unknown> = {};
  for (const hints of hintsList) {
    for (const [name, value] of Object.entries(hints)) {
      if (value !== undefined && merged[name] === undefined) merged[name] = value;
    }
  }
  return merged as VideoHints;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T | null> {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([
    promise.catch(() => null),
    new Promise<null>((resolve) => { timer = setTimeout(() => resolve(null), ms); }),
  ]).finally(() => clearTimeout(timer));
}

async function mapWithConcurrency<T, R>(values: T[], concurrency: number, mapper: (value: T) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(values.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(concurrency, values.length)) }, async () => {
    while (next < values.length) {
      const index = next++;
      results[index] = await mapper(values[index]);
    }
  }));
  return results;
}

async function listEntries(tree: VideoTreeReader, cid: CID, timeoutMs: number): Promise<VideoTreeEntry[] | null> {
  const entries = await withTimeout(tree.listDirectory(cid), timeoutMs);
  return Array.isArray(entries) ? entries.filter((entry) => entry?.cid && !!entry.name) : null;
}

async function readJson(tree: VideoTreeReader, entry: VideoTreeEntry | undefined, timeoutMs: number): Promise<unknown> {
  if (!entry || (entry.size && entry.size > MAX_METADATA_JSON_BYTES)) return null;
  const bytes = await withTimeout(tree.readFile(entry.cid), timeoutMs);
  if (!bytes?.length) return null;
  try {
    return JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    return null;
  }
}

async function readText(tree: VideoTreeReader, entry: VideoTreeEntry | undefined, timeoutMs: number): Promise<string> {
  if (!entry) return '';
  return decodeVideoTextFile(await withTimeout(tree.readFile(entry.cid), timeoutMs));
}

async function readVideoFolderHints(tree: VideoTreeReader, entries: VideoTreeEntry[], timeoutMs: number): Promise<VideoHints> {
  const byName = (name: string) => entries.find((entry) => entry.name === name);
  const playable = findPlayableMediaEntry(entries);
  const thumbnail = entries.find((entry) => isThumbnailName(entry.name));
  const [metadata, info, title, description] = await Promise.all([
    readJson(tree, byName('metadata.json'), timeoutMs),
    readJson(tree, byName('info.json'), timeoutMs),
    readText(tree, byName('title.txt'), timeoutMs),
    readText(tree, byName('description.txt'), timeoutMs),
  ]);
  return mergeHints(
    {
      videoPath: playable?.name,
      thumbnailUrl: thumbnail ? fileHtreeUrl(thumbnail.cid, thumbnail.name) : undefined,
    },
    hintsFromMetadata(playable?.meta, entries),
    hintsFromMetadata(metadata, entries),
    hintsFromMetadata(info, entries),
    { title: title || undefined, description: description || undefined },
  );
}

function toInput(source: VideoTreeSource, hints: VideoHints, fallbackTitle: string, videoId?: string): VideoEventInput {
  return {
    ownerNpub: source.ownerNpub,
    treeName: source.treeName,
    ...(videoId ? { videoId } : {}),
    title: hints.title ?? fallbackTitle,
    description: hints.description,
    duration: hints.duration,
    publishedAt: hints.timestamp ?? source.timestamp,
    videoPath: hints.videoPath,
    thumbnailUrl: hints.thumbnailUrl,
    width: hints.width,
    height: hints.height,
    tags: videoId ? [...(hints.tags ?? []), 'playlist'] : hints.tags,
  };
}

function isPlaylistItemCandidate(entry: VideoTreeEntry): boolean {
  if (typeof entry.type === 'number') return entry.type === LinkType.Dir;
  return !/\.[a-z0-9]{1,8}$/i.test(entry.name);
}

export async function readVideoEventInputs(
  tree: VideoTreeReader,
  source: VideoTreeSource,
  options: ReadVideoTreeOptions = {},
): Promise<VideoTreeResult> {
  const timeoutMs = options.readTimeoutMs ?? DEFAULT_READ_TIMEOUT_MS;
  const treeTitle = source.treeName.replace(/^videos\//, '');
  const rootEntries = await listEntries(tree, source.rootCid, timeoutMs);
  if (!rootEntries?.length) return { kind: 'unreadable', inputs: [], skipped: 0 };

  if (rootEntries.some((entry) => isPlayableMediaFileName(entry.name))) {
    const hints = await readVideoFolderHints(tree, rootEntries, timeoutMs);
    return { kind: 'video', inputs: [toInput(source, hints, treeTitle)], skipped: 0 };
  }

  const candidates = rootEntries
    .filter(isPlaylistItemCandidate)
    .sort((a, b) => a.name.localeCompare(b.name));
  const itemLimit = options.itemLimit ?? DEFAULT_PLAYLIST_ITEM_LIMIT;
  const items = await mapWithConcurrency(
    candidates.slice(0, itemLimit),
    options.concurrency ?? DEFAULT_CONCURRENCY,
    async (entry) => {
      const entries = await listEntries(tree, entry.cid, timeoutMs);
      if (!entries?.some((child) => isPlayableMediaFileName(child.name))) return null;
      const hints = mergeHints(hintsFromMetadata(entry.meta), await readVideoFolderHints(tree, entries, timeoutMs));
      return toInput(source, hints, getInitialPlaylistItemTitle(entry.name) || treeTitle, entry.name);
    },
  );

  return {
    kind: 'playlist',
    inputs: items.filter((item): item is VideoEventInput => !!item),
    skipped: Math.max(0, candidates.length - itemLimit),
  };
}
