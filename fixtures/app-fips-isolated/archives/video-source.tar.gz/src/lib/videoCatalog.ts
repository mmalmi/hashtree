import { nip19 } from 'nostr-tools';
import { getHtreePrefix } from './mediaUrl';
import type { CollectionManifest } from '@hashtree/collection';
import { nhashDecode, type CID } from '@hashtree/core';
import { VIDEO_CATALOG_SCHEMA_V2, VIDEO_COLLECTION_MANIFEST_PATH } from './videoCatalogCollection';

export const VIDEO_CATALOG_SCHEMA = 'iris.video.catalog.v1';
export const VIDEO_CATALOG_URL_KEY = 'iris-video:catalog-url';
export const VIDEO_CATALOG_URLS_KEY = 'iris-video:catalog-urls';
export const VIDEO_DEFAULT_CATALOG_URLS_ENV = 'VITE_DEFAULT_VIDEO_CATALOG_URLS';
export const VIDEO_DEFAULT_CATALOG_URL_ENV = 'VITE_DEFAULT_VIDEO_CATALOG_URL';
export const VIDEO_AUTHOR_INDEX_TREE_NAMES_ENV = 'VITE_VIDEO_AUTHOR_INDEX_TREE_NAMES';

export interface VideoCatalogEntryInput {
  id?: unknown;
  title?: unknown;
  name?: unknown;
  description?: unknown;
  duration?: unknown;
  timestamp?: unknown;
  uploadedAt?: unknown;
  createdAt?: unknown;
  ownerNpub?: unknown;
  npub?: unknown;
  owner?: unknown;
  ownerPubkey?: unknown;
  pubkey?: unknown;
  treeName?: unknown;
  tree?: unknown;
  videoId?: unknown;
  path?: unknown;
  href?: unknown;
  url?: unknown;
  nhash?: unknown;
  thumbnailUrl?: unknown;
  thumbnail?: unknown;
  videoPath?: unknown;
  tags?: unknown;
}

export interface VideoCatalogPayload {
  schema?: unknown;
  version?: unknown;
  title?: unknown;
  name?: unknown;
  generatedAt?: unknown;
  collections?: unknown;
  videos?: unknown;
  items?: unknown;
  entries?: unknown;
}

export interface VideoCatalogItem {
  id: string;
  title: string;
  description?: string;
  duration?: number;
  timestamp?: number;
  ownerNpub?: string;
  ownerPubkey?: string;
  treeName?: string;
  videoId?: string;
  href: string;
  nhash?: string;
  thumbnailUrl?: string;
  videoPath?: string;
  tags: string[];
  catalogUrl: string;
}

export interface VideoCatalog {
  sourceUrl: string;
  fetchUrl: string;
  title: string;
  generatedAt?: string;
  videos: VideoCatalogItem[];
  collectionManifest?: CollectionManifest;
  collectionManifestPath?: string;
  version: 1 | 2;
}

export interface VideoCatalogUrlSet {
  defaultUrls: string[];
  savedUrls: string[];
  urls: string[];
}

function readString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function readNumber(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function readTimestamp(input: VideoCatalogEntryInput): number | undefined {
  const value = readNumber(input.timestamp) ?? readNumber(input.uploadedAt) ?? readNumber(input.createdAt);
  if (!value) return undefined;
  return value > 9_999_999_999 ? Math.floor(value / 1000) : Math.floor(value);
}

function normalizeTags(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const tags = value
    .map((tag) => readString(tag)?.toLowerCase())
    .filter((tag): tag is string => !!tag);
  return Array.from(new Set(tags));
}

function pubkeyToNpub(pubkey: string | undefined): string | undefined {
  if (!pubkey || !/^[0-9a-f]{64}$/i.test(pubkey)) return undefined;
  try {
    return nip19.npubEncode(pubkey);
  } catch {
    return undefined;
  }
}

function npubToPubkey(npub: string | undefined): string | undefined {
  if (!npub?.startsWith('npub1')) return undefined;
  try {
    const decoded = nip19.decode(npub);
    return decoded.type === 'npub' ? decoded.data as string : undefined;
  } catch {
    return undefined;
  }
}

export function canonicalizeVideoCatalogUrl(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) return '';
  const withoutRootJson = trimmed.replace(/\/root\.json(?:\?.*)?$/i, '');
  return withoutRootJson.replace(/\/+$/, '');
}

export function normalizeVideoCatalogUrls(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  const seen = new Set<string>();
  const nextUrls: string[] = [];
  for (const value of values) {
    const url = canonicalizeVideoCatalogUrl(`${value ?? ''}`);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    nextUrls.push(url);
  }
  return nextUrls;
}

export function parseVideoCatalogUrlList(value: unknown): string[] {
  if (Array.isArray(value)) return normalizeVideoCatalogUrls(value);
  return normalizeVideoCatalogUrls(
    `${value ?? ''}`
      .split(/[\n,]+/)
      .map((entry) => entry.trim())
      .filter(Boolean),
  );
}

function readEnvValue(env: Record<string, unknown>, key: string): string {
  const value = env[key];
  return typeof value === 'string' ? value : '';
}

function defaultEnv(): Record<string, unknown> {
  return (import.meta.env ?? {}) as Record<string, unknown>;
}

export function getDefaultVideoCatalogUrls(env: Record<string, unknown> = defaultEnv()): string[] {
  return normalizeVideoCatalogUrls([
    ...parseVideoCatalogUrlList(readEnvValue(env, VIDEO_DEFAULT_CATALOG_URLS_ENV)),
    readEnvValue(env, VIDEO_DEFAULT_CATALOG_URL_ENV),
  ]);
}

export function getVideoAuthorCatalogUrls(npub: string | undefined, env: Record<string, unknown> = defaultEnv()): string[] {
  const ownerNpub = readString(npub);
  if (!ownerNpub?.startsWith('npub1')) return [];
  const treeNames = parseVideoCatalogUrlList(readEnvValue(env, VIDEO_AUTHOR_INDEX_TREE_NAMES_ENV));
  return normalizeVideoCatalogUrls(treeNames.map((treeName) => `htree://${ownerNpub}/${treeName}`));
}

export function videoCatalogFetchUrl(value: string): string {
  return videoCatalogFileFetchUrl(value, 'root.json');
}

export function videoCatalogFileFetchUrl(value: string, relativePath: string): string {
  const trimmed = value.trim();
  if (!trimmed) return '';
  const cleanPath = relativePath.split('/').map((part) => encodeURIComponent(part)).join('/');
  if (/\/root\.json(?:\?.*)?$/i.test(trimmed)) {
    return trimmed.replace(/\/root\.json(?:\?.*)?$/i, `/${cleanPath}`);
  }

  const rootUrl = canonicalizeVideoCatalogUrl(trimmed);
  if (rootUrl.startsWith('htree://')) {
    const htreePath = rootUrl.slice('htree://'.length).replace(/^\/+/, '');
    return `${getHtreePrefix()}/htree/${htreePath}/${cleanPath}`;
  }
  if (rootUrl.startsWith('/htree/')) {
    return `${rootUrl}/${cleanPath}`;
  }
  return `${rootUrl}/${cleanPath}`;
}

function buildCatalogHref(input: VideoCatalogEntryInput, ownerNpub?: string, treeName?: string, videoId?: string): string | undefined {
  const explicitHref = readString(input.href) ?? readString(input.url);
  if (explicitHref) return explicitHref.startsWith('#') ? explicitHref : `#${explicitHref}`;

  const nhash = readString(input.nhash);
  if (nhash) return `#/${nhash}`;

  if (!ownerNpub || !treeName) return undefined;
  const treePath = `/${ownerNpub}/${encodeURIComponent(treeName)}`;
  return videoId ? `#${treePath}/${encodeURIComponent(videoId)}` : `#${treePath}`;
}

export function normalizeVideoCatalogEntry(
  raw: unknown,
  catalogUrl: string,
  index = 0,
): VideoCatalogItem | null {
  if (!raw || typeof raw !== 'object') return null;
  const input = raw as VideoCatalogEntryInput;
  const title = readString(input.title) ?? readString(input.name);
  if (!title) return null;

  const ownerPubkey = readString(input.ownerPubkey) ?? readString(input.pubkey);
  const ownerNpub = readString(input.ownerNpub)
    ?? readString(input.npub)
    ?? readString(input.owner)
    ?? pubkeyToNpub(ownerPubkey);
  const resolvedOwnerPubkey = ownerPubkey ?? npubToPubkey(ownerNpub);
  const treeName = readString(input.treeName) ?? readString(input.tree);
  const videoId = readString(input.videoId) ?? readString(input.path);
  const href = buildCatalogHref(input, ownerNpub, treeName, videoId);
  if (!href) return null;

  const logicalId = [ownerNpub, treeName, videoId].filter(Boolean).join('/');
  const id = readString(input.id) ?? (logicalId || `${catalogUrl}#${index}`);

  return {
    id,
    title,
    description: readString(input.description),
    duration: readNumber(input.duration),
    timestamp: readTimestamp(input),
    ownerNpub,
    ownerPubkey: resolvedOwnerPubkey,
    treeName,
    videoId,
    href,
    nhash: readString(input.nhash),
    thumbnailUrl: readString(input.thumbnailUrl) ?? readString(input.thumbnail),
    videoPath: readString(input.videoPath),
    tags: normalizeTags(input.tags),
    catalogUrl,
  };
}

function getRawCatalogEntries(payload: VideoCatalogPayload): unknown[] {
  const candidates = [payload.videos, payload.items, payload.entries];
  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }
  return [];
}

function isCollectionManifest(value: unknown): value is CollectionManifest {
  return !!value
    && typeof value === 'object'
    && (value as CollectionManifest).version === 1
    && typeof (value as CollectionManifest).sourceId === 'string'
    && 'byIdRoot' in value
    && typeof (value as CollectionManifest).indexes === 'object';
}

function readVideoCollectionRef(payload: VideoCatalogPayload): {
  manifest?: CollectionManifest;
  manifestPath?: string;
} {
  const collections = payload.collections;
  if (!collections || typeof collections !== 'object') return {};
  const videos = (collections as { videos?: unknown }).videos;
  if (!videos || typeof videos !== 'object') return {};
  if (isCollectionManifest(videos)) return { manifest: videos };

  const manifest = (videos as { manifest?: unknown }).manifest;
  const manifestPath = readString((videos as { manifestPath?: unknown }).manifestPath);
  return {
    ...(isCollectionManifest(manifest) ? { manifest } : {}),
    ...(manifestPath ? { manifestPath } : {}),
  };
}

export function parseVideoCatalogPayload(payload: unknown, sourceUrl: string): VideoCatalog {
  if (!payload || typeof payload !== 'object') {
    throw new Error('Video catalog root must be a JSON object');
  }

  const catalogPayload = payload as VideoCatalogPayload;
  const canonicalUrl = canonicalizeVideoCatalogUrl(sourceUrl);
  const collectionRef = readVideoCollectionRef(catalogPayload);
  const version = catalogPayload.schema === VIDEO_CATALOG_SCHEMA_V2 || readNumber(catalogPayload.version) === 2
    ? 2
    : 1;
  const videos = getRawCatalogEntries(catalogPayload)
    .map((entry, index) => normalizeVideoCatalogEntry(entry, canonicalUrl, index))
    .filter((entry): entry is VideoCatalogItem => !!entry);

  return {
    sourceUrl: canonicalUrl,
    fetchUrl: videoCatalogFetchUrl(sourceUrl),
    title: readString(catalogPayload.title) ?? readString(catalogPayload.name) ?? 'Video Catalog',
    generatedAt: readString(catalogPayload.generatedAt),
    videos,
    collectionManifest: collectionRef.manifest,
    collectionManifestPath: collectionRef.manifestPath ?? (version === 2 ? VIDEO_COLLECTION_MANIFEST_PATH : undefined),
    version,
  };
}

export async function loadVideoCatalog(sourceUrl: string, fetcher: typeof fetch = fetch): Promise<VideoCatalog> {
  const fetchUrl = videoCatalogFetchUrl(sourceUrl);
  if (!fetchUrl) {
    throw new Error('Video catalog URL is required');
  }
  const response = await fetcher(fetchUrl);
  if (!response.ok) {
    throw new Error(`Video catalog failed to load: ${response.status}`);
  }
  const catalog = parseVideoCatalogPayload(await response.json(), sourceUrl);
  if (catalog.collectionManifest || !catalog.collectionManifestPath) {
    return catalog;
  }

  const manifestResponse = await fetcher(videoCatalogFileFetchUrl(sourceUrl, catalog.collectionManifestPath));
  if (!manifestResponse.ok) {
    throw new Error(`Video catalog collection manifest failed to load: ${manifestResponse.status}`);
  }
  const manifest = await manifestResponse.json();
  if (!isCollectionManifest(manifest)) {
    throw new Error('Video catalog collection manifest must be a hashtree collection manifest');
  }
  return { ...catalog, collectionManifest: manifest };
}

function getLocalStorage(): Storage | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage ?? null;
}

export function getSavedVideoCatalogUrls(): string[] {
  const storage = getLocalStorage();
  if (!storage) return [];

  try {
    const list = normalizeVideoCatalogUrls(JSON.parse(storage.getItem(VIDEO_CATALOG_URLS_KEY) ?? '[]'));
    const primary = canonicalizeVideoCatalogUrl(storage.getItem(VIDEO_CATALOG_URL_KEY) ?? '');
    const urls = primary ? [primary, ...list.filter((url) => url !== primary)] : list;
    if (urls.length > 0) {
      storage.setItem(VIDEO_CATALOG_URLS_KEY, JSON.stringify(urls));
      storage.setItem(VIDEO_CATALOG_URL_KEY, urls[0]);
    }
    return urls;
  } catch {
    return [];
  }
}

export function getVideoCatalogUrlSet(env: Record<string, unknown> = defaultEnv()): VideoCatalogUrlSet {
  const defaultUrls = getDefaultVideoCatalogUrls(env);
  const savedUrls = getSavedVideoCatalogUrls();
  return {
    defaultUrls,
    savedUrls,
    urls: normalizeVideoCatalogUrls([...defaultUrls, ...savedUrls]),
  };
}

export function saveVideoCatalogUrl(value: string): string[] {
  const storage = getLocalStorage();
  const url = canonicalizeVideoCatalogUrl(value);
  if (!storage || !url) return getSavedVideoCatalogUrls();

  const urls = [url, ...getSavedVideoCatalogUrls().filter((existing) => existing !== url)];
  storage.setItem(VIDEO_CATALOG_URL_KEY, urls[0]);
  storage.setItem(VIDEO_CATALOG_URLS_KEY, JSON.stringify(urls));
  return urls;
}

export function removeSavedVideoCatalogUrl(value: string): string[] {
  const storage = getLocalStorage();
  if (!storage) return [];
  const removeUrl = canonicalizeVideoCatalogUrl(value);
  const urls = getSavedVideoCatalogUrls().filter((url) => url !== removeUrl);
  if (urls.length === 0) {
    storage.removeItem(VIDEO_CATALOG_URL_KEY);
    storage.removeItem(VIDEO_CATALOG_URLS_KEY);
    return [];
  }
  storage.setItem(VIDEO_CATALOG_URL_KEY, urls[0]);
  storage.setItem(VIDEO_CATALOG_URLS_KEY, JSON.stringify(urls));
  return urls;
}

function searchHaystack(item: VideoCatalogItem): string {
  return [
    item.title,
    item.description,
    item.ownerNpub,
    item.treeName,
    item.videoId,
    ...item.tags,
  ].filter(Boolean).join(' ').toLowerCase();
}

function scoreCatalogItem(item: VideoCatalogItem, terms: string[]): number {
  const title = item.title.toLowerCase();
  const haystack = searchHaystack(item);
  let score = 0;
  for (const term of terms) {
    if (title === term) score += 100;
    else if (title.startsWith(term)) score += 75;
    else if (title.includes(term)) score += 50;
    else if (haystack.includes(term)) score += 20;
  }
  return score;
}

export function searchVideoCatalogItems(items: VideoCatalogItem[], query: string, limit = 20): VideoCatalogItem[] {
  const terms = query.toLowerCase().split(/\s+/).map((term) => term.trim()).filter(Boolean);
  if (terms.length === 0) return items.slice(0, limit);

  return items
    .map((item) => ({ item, score: scoreCatalogItem(item, terms) }))
    .filter((result) => result.score > 0)
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if ((b.item.timestamp ?? 0) !== (a.item.timestamp ?? 0)) {
        return (b.item.timestamp ?? 0) - (a.item.timestamp ?? 0);
      }
      return a.item.title.localeCompare(b.item.title);
    })
    .slice(0, limit)
    .map((result) => result.item);
}

export function videoCatalogItemToFeedItem(item: VideoCatalogItem) {
  let rootCid: CID | undefined;
  if (item.nhash) {
    try {
      rootCid = nhashDecode(item.nhash);
    } catch {
      rootCid = undefined;
    }
  }

  return {
    key: `catalog:${item.catalogUrl}:${item.id}`,
    title: item.title,
    description: item.description,
    duration: item.duration,
    ownerPubkey: item.ownerPubkey ?? null,
    ownerNpub: item.ownerNpub ?? null,
    treeName: item.treeName ?? '',
    videoId: item.videoId,
    thumbnailUrl: item.thumbnailUrl,
    videoPath: item.videoPath,
    visibility: 'public',
    href: item.href,
    timestamp: item.timestamp,
    rootCid,
  };
}
