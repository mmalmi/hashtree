/**
 * Keep the signed-in user's NIP-71 video events in step with their
 * `videos/...` trees. Runs after every tree save, so uploads, streams,
 * imports, playlist edits and metadata edits all publish the same way.
 */
import type { CID } from '@hashtree/core';
import type { EventTemplate } from 'nostr-tools';
import { nostr } from '../nostr/client';
import { getSecretKey } from '../nostr/auth';
import { nostrStore } from '../nostr/store';
import { getTree } from '../store';
import {
  VIDEO_EVENT_KIND,
  buildVideoEventDeletionTemplate,
  buildVideoEventTemplate,
  parseVideoEvent,
  videoEventDTag,
  type VideoEventItem,
} from './videoEvent';
import { buildVideoSetDeletionTemplate, buildVideoSetTemplate, parseVideoSet, sameVideoSet, videoSetKey } from './videoSet';
import { getVideoSet, ingestVideoSetEvent } from '../stores/videoSets';
import { readVideoEventInputs } from './videoEventTree';
import { getVideoEventItemsForTree, ingestVideoEvent } from '../stores/videoEvents';

const SYNC_DELAY_MS = 3000;
/** A signing extension asks the user per event, so old playlists are announced a few items per save. */
const PROMPTING_SIGNER_MAX_EVENTS = 5;

interface PendingSync {
  timer: ReturnType<typeof setTimeout>;
  run: () => Promise<void>;
}

const pendingSyncs = new Map<string, PendingSync>();
const runningSyncs = new Set<Promise<void>>();

function describesSameVideo(a: VideoEventItem, b: VideoEventItem): boolean {
  const projection = (item: VideoEventItem) => JSON.stringify([
    item.title, item.description, item.duration, item.timestamp, item.videoPath, item.thumbnailUrl, item.tags,
  ]);
  return projection(a) === projection(b);
}

/**
 * Sign, apply to the local index at once, then hand to the relays.
 * The relays answer in their own time; nothing here waits for them.
 */
async function publishLocally(template: EventTemplate): Promise<void> {
  const event = await nostr.signEvent(template);
  ingestVideoEvent(event);
  void nostr.publish(event).catch((error) => console.warn('[videoEvents] Relay publish failed', error));
}

async function publishDeletion(ownerPubkey: string, dTags: string[]): Promise<void> {
  if (dTags.length === 0) return;
  await publishLocally(buildVideoEventDeletionTemplate(ownerPubkey, dTags));
}

/** Like `publishLocally`, for the playlist's video set. */
async function publishSetLocally(template: EventTemplate): Promise<void> {
  const event = await nostr.signEvent(template);
  ingestVideoSetEvent(event);
  void nostr.publish(event).catch((error) => console.warn('[videoEvents] Relay publish failed', error));
}

/** Retract the video set of a tree that is no longer a public playlist. */
async function retractVideoSet(ownerPubkey: string, treeName: string): Promise<void> {
  if (!getVideoSet(videoSetKey(ownerPubkey, treeName))) return;
  await publishSetLocally(buildVideoSetDeletionTemplate(ownerPubkey, [treeName]));
}

/**
 * Publish, update or retract the video events for one of the user's trees.
 * Returns the number of events published.
 */
export async function syncVideoEvents(treeName: string, rootCid: CID, visibility: string = 'public'): Promise<number> {
  const { pubkey, npub } = nostrStore.getState();
  if (!pubkey || !npub || !nostr.signer || !treeName.startsWith('videos/')) return 0;

  const known = new Map(getVideoEventItemsForTree(npub, treeName).map((item) => [item.dTag, item]));
  if (visibility !== 'public') {
    await publishDeletion(pubkey, [...known.keys()]);
    await retractVideoSet(pubkey, treeName);
    return 0;
  }

  const result = await readVideoEventInputs(getTree(), { ownerNpub: npub, treeName, rootCid });
  if (result.kind === 'unreadable') return 0;

  const now = Math.floor(Date.now() / 1000);
  const budget = getSecretKey() ? Infinity : PROMPTING_SIGNER_MAX_EVENTS;
  // Newest first, so a just-added item is announced before older ones.
  const inputs = [...result.inputs].sort((a, b) => (b.publishedAt ?? Infinity) - (a.publishedAt ?? Infinity));
  let published = 0;
  for (const input of inputs) {
    const dTag = videoEventDTag(treeName, input.videoId);
    const existing = known.get(dTag);
    known.delete(dTag);

    const template = buildVideoEventTemplate({
      ...input,
      publishedAt: input.publishedAt ?? existing?.timestamp ?? now,
    }, Math.max(now, (existing?.updatedAt ?? 0) + 1));
    const next = parseVideoEvent({ ...template, pubkey });
    if (!next || (existing && describesSameVideo(existing, next)) || published >= budget) continue;

    await publishLocally(template);
    published += 1;
  }

  // Whatever is still listed no longer exists in the tree (e.g. a removed playlist item).
  await publishDeletion(pubkey, [...known.keys()]);

  // A playlist is also announced as a video set (NIP-51), the playlist format other
  // apps read: its videos in the tree's order, under the tree's name.
  const members = result.inputs.filter((input) => input.videoId);
  if (members.length === 0) {
    await retractVideoSet(pubkey, treeName);
  } else if (published < budget) {
    const template = buildVideoSetTemplate({
      dTag: treeName,
      title: treeName.replace(/^videos\//, ''),
      image: members.find((input) => input.thumbnailUrl)?.thumbnailUrl,
      addresses: members.map((input) => `${VIDEO_EVENT_KIND}:${pubkey}:${videoEventDTag(treeName, input.videoId)}`),
    }, now);
    const next = parseVideoSet({ ...template, pubkey });
    const current = getVideoSet(videoSetKey(pubkey, treeName));
    if (next && !(current && sameVideoSet(current, next))) {
      await publishSetLocally({ ...template, created_at: Math.max(now, (current?.updatedAt ?? 0) + 1) });
      published += 1;
    }
  }
  return published;
}

/** Sync shortly after the tree settles; rapid saves (live streams) collapse into one publish. */
export function scheduleVideoEventSync(treeName: string, rootCid: CID, visibility: string = 'public'): void {
  if (!treeName.startsWith('videos/')) return;
  const existing = pendingSyncs.get(treeName);
  if (existing) clearTimeout(existing.timer);

  const run = async () => {
    pendingSyncs.delete(treeName);
    const sync = syncVideoEvents(treeName, rootCid, visibility)
      .then(() => {}, (error) => console.warn('[videoEvents] Publish failed', treeName, error));
    runningSyncs.add(sync);
    await sync.finally(() => runningSyncs.delete(sync));
  };
  pendingSyncs.set(treeName, { timer: setTimeout(() => void run(), SYNC_DELAY_MS), run });
}

/** Retract the user's video events for a deleted tree. */
export async function deleteVideoEvents(treeName: string): Promise<void> {
  const pending = pendingSyncs.get(treeName);
  if (pending) {
    clearTimeout(pending.timer);
    pendingSyncs.delete(treeName);
  }
  const { pubkey, npub } = nostrStore.getState();
  if (!pubkey || !npub || !nostr.signer || !treeName.startsWith('videos/')) return;
  const items = getVideoEventItemsForTree(npub, treeName);
  const dTags = new Set([treeName, ...items.map((item) => item.dTag)]);
  await publishDeletion(pubkey, [...dTags]);
  // A playlist's video set goes with it, whether or not this session has seen the set.
  if (items.some((item) => item.videoId) || getVideoSet(videoSetKey(pubkey, treeName))) {
    await publishSetLocally(buildVideoSetDeletionTemplate(pubkey, [treeName]));
  }
}

/** Run scheduled syncs now and wait for them (tests, before unload). */
export async function flushVideoEventSyncs(): Promise<void> {
  const pending = [...pendingSyncs.values()];
  for (const sync of pending) clearTimeout(sync.timer);
  await Promise.all(pending.map((sync) => sync.run()));
  await Promise.all(runningSyncs);
}
