/**
 * Keep a feed still while fresher data keeps arriving.
 *
 * What is on screen keeps its place. Arrivals only fill in below it, up to the
 * number of entries the page asks for, so nothing shifts under the viewer. When
 * a fresh ordering would look different, `pending` says so and the viewer
 * decides when to switch (the "Update" button).
 */
export interface FeedPresentation {
  /** Keys in display order. */
  shown: string[];
  /** A fresh ordering would show something else in these places. */
  pending: boolean;
}

export function reconcileFeed(
  shown: readonly string[],
  latest: readonly string[],
  limit: number,
  protectedCount = shown.length,
): FeedPresentation {
  const available = new Set(latest);
  // Only the prefix through the last visible card stays put. A deletion still takes effect.
  const next = shown.slice(0, protectedCount).filter((key) => available.has(key));
  const pending = next.some((key, index) => latest[index] !== key);
  if (next.length < limit) {
    const present = new Set(next);
    for (const key of latest) {
      if (next.length >= limit) break;
      if (!present.has(key)) next.push(key);
    }
  }
  return { shown: next, pending };
}

/** The same items with the ones already seen moved to the end; both groups keep their order. */
export function unseenFirst<T>(items: readonly T[], isSeen: (item: T) => boolean): T[] {
  return [...items.filter((item) => !isSeen(item)), ...items.filter(isSeen)];
}
