#!/usr/bin/env node
/**
 * Backfill NIP-71 video events (kind 34235) for one account's public
 * `videos/...` hashtree trees.
 *
 * The app publishes these events itself whenever a video is saved. This script
 * covers videos uploaded before that, and bulk imports. It only ever signs
 * with the key it is given and only describes that key's own trees.
 *
 * `--mirror-from <npub>` first gives the signing account its own copy of
 * another account's public video trees (same content, nothing re-uploaded),
 * then announces them. Trees the signing account already has are left alone.
 *
 *   node scripts/publish-video-events.mjs --dry-run --npub npub1...
 *   VIDEO_EVENTS_PUBLISH_KEY_ALIAS=self node scripts/publish-video-events.mjs
 *   VIDEO_EVENTS_PUBLISH_KEY_ALIAS=channel node scripts/publish-video-events.mjs --mirror-from npub1...
 *
 * `--dry-run --drafts <file>` also writes the unsigned events as JSON lines, in
 * publishing order, for signing and publishing with another tool.
 */
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SimplePool, nip19 } from 'nostr-tools';
import { finalizeEvent, getPublicKey } from 'nostr-tools/pure';
import { BlossomStore, HashTree } from '@hashtree/core';
import { HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import { parseVideoRootCid } from '../src/lib/videoRootKeys.ts';
import {
  VIDEO_EVENT_KIND,
  VIDEO_EVENT_KINDS,
  buildVideoEventTemplate,
  parseVideoEvent,
  videoEventDTag,
} from '../src/lib/videoEvent.ts';
import { VIDEO_SET_KIND, buildVideoSetTemplate, parseVideoSet, sameVideoSet } from '../src/lib/videoSet.ts';
import { DEFAULT_PLAYLIST_ITEM_LIMIT, readVideoEventInputs } from '../src/lib/videoEventTree.ts';

const __filename = fileURLToPath(import.meta.url);
const appDir = path.resolve(path.dirname(__filename), '..');

// Same relays the app uses by default.
const DEFAULT_RELAYS = [
  'wss://relay.ditto.pub',
  'wss://relay.damus.io',
  'wss://relay.primal.net',
  'wss://relay.snort.social',
  'wss://temp.iris.to',
  'wss://relay.divine.video',
];
const DEFAULT_BLOSSOM_SERVERS = ['https://upload.iris.to', 'https://cdn.iris.to'];

function parseList(value, fallback = []) {
  const entries = `${value ?? ''}`.split(/[\n,]+/).map((entry) => entry.trim()).filter(Boolean);
  return entries.length > 0 ? entries : fallback;
}

function parseIntEnv(name, fallback) {
  const parsed = Number.parseInt(`${process.env[name] ?? ''}`, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function parseNostrSecret(raw) {
  const trimmed = `${raw ?? ''}`.trim();
  if (!trimmed) {
    throw new Error('Missing Nostr secret key. Set VIDEO_EVENTS_PUBLISH_NSEC, NOSTR_SECRET_KEY, or VIDEO_EVENTS_PUBLISH_KEY_ALIAS.');
  }
  if (trimmed.startsWith('nsec1')) {
    const decoded = nip19.decode(trimmed);
    if (decoded.type !== 'nsec') throw new Error('Expected an nsec private key');
    return decoded.data;
  }
  if (/^[0-9a-f]{64}$/i.test(trimmed)) return Uint8Array.from(Buffer.from(trimmed, 'hex'));
  throw new Error('Unsupported Nostr secret key format');
}

function parsePubkey(value) {
  const trimmed = `${value ?? ''}`.trim();
  if (/^[0-9a-f]{64}$/i.test(trimmed)) return trimmed.toLowerCase();
  const decoded = trimmed.startsWith('npub1') ? nip19.decode(trimmed) : null;
  if (decoded?.type !== 'npub') throw new Error('Expected an npub or hex public key');
  return decoded.data;
}

async function readNamedHtreeSecret(alias) {
  const raw = await fs.readFile(path.join(os.homedir(), '.hashtree', 'keys'), 'utf8').catch(() => '');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const [secret, lineAlias] = trimmed.split(/\s+/, 2);
    if (lineAlias === alias) return secret;
  }
  return '';
}

async function loadPublishSecret(alias) {
  return parseNostrSecret(
    process.env.VIDEO_EVENTS_PUBLISH_NSEC
      ?? process.env.NOSTR_SECRET_KEY
      ?? process.env.NOSTR_SECRET_KEY_HEX
      ?? await readNamedHtreeSecret(alias),
  );
}

function isNewer(candidate, existing) {
  if (!existing) return true;
  const delta = (candidate.created_at ?? 0) - (existing.created_at ?? 0);
  return delta > 0 || (delta === 0 && `${candidate.id}` > `${existing.id}`);
}

/** Latest `videos/...` tree root event per account and tree, deletions included. */
function latestVideoRootEvents(events) {
  const latestByTree = new Map();
  for (const event of events) {
    const treeName = event.tags.find((tag) => tag[0] === 'd')?.[1];
    if (!treeName?.startsWith('videos/')) continue;
    const key = `${event.pubkey}:${treeName}`;
    if (isNewer(event, latestByTree.get(key))) latestByTree.set(key, event);
  }
  return [...latestByTree.values()];
}

function publicRootCid(event) {
  const tagValue = (name) => event.tags.find((tag) => tag[0] === name)?.[1];
  if (event.tags.some((tag) => tag[0] === 'encryptedKey' || tag[0] === 'selfEncryptedKey')) return null;
  return parseVideoRootCid(tagValue('hash'), tagValue('key'));
}

const treeNameOf = (event) => event.tags.find((tag) => tag[0] === 'd')?.[1];

/**
 * Latest public, undeleted `videos/...` tree roots among hashtree root events.
 * Private and link-only trees are never announced.
 */
export function selectPublicVideoRoots(events) {
  const roots = [];
  for (const event of latestVideoRootEvents(events)) {
    const rootCid = publicRootCid(event);
    if (rootCid) roots.push({ treeName: treeNameOf(event), rootCid, timestamp: event.created_at ?? 0 });
  }
  return roots.sort((a, b) => a.treeName.localeCompare(b.treeName));
}

/**
 * Tree root events that give another account its own copy of the source
 * account's public video trees. Content is addressed by hash, so the copy
 * points at the same blocks. A tree name the receiving account has used
 * before (even a deleted one) is never overwritten.
 */
export function planTreeRootMirror(sourceEvents, ownerEvents) {
  const taken = new Set(latestVideoRootEvents(ownerEvents).map(treeNameOf));
  return latestVideoRootEvents(sourceEvents)
    .filter((event) => publicRootCid(event) && !taken.has(treeNameOf(event)))
    .map((event) => ({
      kind: event.kind,
      // The original time keeps the videos' dates and order.
      created_at: event.created_at,
      tags: event.tags.map((tag) => [...tag]),
      content: event.content ?? '',
    }))
    .sort((a, b) => treeNameOf(a).localeCompare(treeNameOf(b)));
}

function sameVideo(a, b) {
  const projection = (item) => JSON.stringify([
    item.title, item.description, item.duration, item.timestamp, item.videoPath, item.thumbnailUrl, item.tags,
  ]);
  return projection(a) === projection(b);
}

/**
 * Read each tree and decide which video events need publishing.
 * Already-published events that still describe the video are left alone.
 */
export async function planVideoEvents(tree, options) {
  const { ownerPubkey, roots, existingEvents = [], now = Math.floor(Date.now() / 1000) } = options;
  const ownerNpub = nip19.npubEncode(ownerPubkey);
  const existingByDTag = new Map();
  for (const event of existingEvents) {
    const item = parseVideoEvent(event);
    if (!item) continue;
    const known = existingByDTag.get(item.dTag);
    if (!known || known.updatedAt < item.updatedAt) existingByDTag.set(item.dTag, item);
  }

  // Playlists are also announced as video sets (NIP-51), the playlist format other apps read.
  const existingSets = new Map();
  for (const event of existingEvents) {
    const set = parseVideoSet(event);
    if (!set) continue;
    const known = existingSets.get(set.dTag);
    if (!known || known.updatedAt < set.updatedAt) existingSets.set(set.dTag, set);
  }

  const stats = { trees: roots.length, videos: 0, playlists: 0, unreadable: 0, unchanged: 0, skippedItems: 0, unreadableTrees: [], sets: 0 };
  const templates = [];
  for (const root of roots) {
    const { timestamp: rootTimestamp, ...source } = root;
    const result = await readVideoEventInputs(tree, { ownerNpub, ...source }, {
      readTimeoutMs: options.readTimeoutMs,
      concurrency: options.concurrency,
      itemLimit: options.itemLimit,
    });
    if (result.kind === 'unreadable') {
      stats.unreadable += 1;
      stats.unreadableTrees.push(root.treeName);
      continue;
    }
    if (result.kind === 'playlist') stats.playlists += 1;
    stats.skippedItems += result.skipped;

    for (const input of result.inputs) {
      stats.videos += 1;
      const existing = existingByDTag.get(videoEventDTag(input.treeName, input.videoId));
      // Keep the first publication time stable when the tree records none.
      const publishedAt = input.publishedAt ?? existing?.timestamp ?? rootTimestamp;
      const template = buildVideoEventTemplate({ ...input, publishedAt }, Math.max(now, (existing?.updatedAt ?? 0) + 1));
      const next = parseVideoEvent({ ...template, pubkey: ownerPubkey });
      if (!next || (existing && sameVideo(existing, next))) {
        stats.unchanged += 1;
        continue;
      }
      templates.push(template);
    }

    const members = result.kind === 'playlist' ? result.inputs.filter((input) => input.videoId) : [];
    if (members.length > 0) {
      const existingSet = existingSets.get(root.treeName);
      const setTemplate = buildVideoSetTemplate({
        dTag: root.treeName,
        title: root.treeName.replace(/^videos\//, ''),
        image: members.find((input) => input.thumbnailUrl)?.thumbnailUrl,
        addresses: members.map((input) => `${VIDEO_EVENT_KIND}:${ownerPubkey}:${videoEventDTag(root.treeName, input.videoId)}`),
      }, Math.max(now, (existingSet?.updatedAt ?? 0) + 1));
      const nextSet = parseVideoSet({ ...setTemplate, pubkey: ownerPubkey });
      if (nextSet && !(existingSet && sameVideoSet(existingSet, nextSet))) {
        stats.sets += 1;
        templates.push(setTemplate);
      }
    }
  }
  return { templates, stats };
}

async function publishToRelays(pool, relays, event, maxWait) {
  const results = await Promise.allSettled(pool.publish(relays, event, { maxWait }));
  return results.filter((result) => result.status === 'fulfilled').length;
}

async function main() {
  const dryRun = process.argv.includes('--dry-run');
  const relays = parseList(process.env.VIDEO_EVENTS_RELAYS, DEFAULT_RELAYS);
  const blossomServers = parseList(process.env.VIDEO_EVENTS_BLOSSOM_SERVERS, DEFAULT_BLOSSOM_SERVERS)
    .map((url) => ({ url, read: true, write: false }));
  const maxWait = parseIntEnv('VIDEO_EVENTS_RELAY_WAIT_MS', 8000);
  const eventLimit = parseIntEnv('VIDEO_EVENTS_EVENT_LIMIT', 1000);
  // A dry run signs nothing, so naming the account is enough.
  const npubIndex = process.argv.indexOf('--npub');
  const dryRunAccount = dryRun ? (npubIndex > -1 ? process.argv[npubIndex + 1] : process.env.VIDEO_EVENTS_NPUB) : undefined;
  const secretKey = dryRunAccount
    ? null
    : await loadPublishSecret(`${process.env.VIDEO_EVENTS_PUBLISH_KEY_ALIAS ?? 'self'}`.trim());
  const ownerPubkey = secretKey ? getPublicKey(secretKey) : parsePubkey(dryRunAccount);
  const ownerNpub = nip19.npubEncode(ownerPubkey);

  const mirrorIndex = process.argv.indexOf('--mirror-from');
  const sourcePubkey = mirrorIndex > -1 ? parsePubkey(process.argv[mirrorIndex + 1]) : ownerPubkey;
  const rootFilter = (author) => ({ kinds: [...HASHTREE_ROOT_KINDS], authors: [author], '#l': ['hashtree'], limit: eventLimit });

  const pool = new SimplePool();
  try {
    console.log(`Reading video trees and video events of ${ownerNpub} from ${relays.length} relays...`);
    const [ownerRootEvents, existingEvents, sourceRootEvents] = await Promise.all([
      pool.querySync(relays, rootFilter(ownerPubkey), { maxWait }),
      pool.querySync(relays, { kinds: [...VIDEO_EVENT_KINDS, VIDEO_SET_KIND], authors: [ownerPubkey], limit: eventLimit }, { maxWait }),
      sourcePubkey === ownerPubkey ? [] : pool.querySync(relays, rootFilter(sourcePubkey), { maxWait }),
    ]);
    let mirrorTemplates = planTreeRootMirror(sourceRootEvents, ownerRootEvents);
    const roots = selectPublicVideoRoots([
      ...ownerRootEvents,
      ...mirrorTemplates.map((template) => ({ ...template, pubkey: ownerPubkey })),
    ]);
    if (roots.length === 0) {
      console.log('No public video trees found.');
      return;
    }

    const tree = new HashTree({ store: new BlossomStore({ servers: blossomServers }) });
    const { templates, stats } = await planVideoEvents(tree, {
      ownerPubkey,
      roots,
      existingEvents,
      readTimeoutMs: parseIntEnv('VIDEO_EVENTS_READ_TIMEOUT_MS', 8000),
      concurrency: parseIntEnv('VIDEO_EVENTS_CONCURRENCY', 6),
      itemLimit: parseIntEnv('VIDEO_EVENTS_PLAYLIST_ITEM_LIMIT', DEFAULT_PLAYLIST_ITEM_LIMIT),
    });
    console.log(
      `${stats.trees} trees (${stats.playlists} playlists, ${stats.unreadable} unreadable): `
      + `${stats.videos} videos, ${stats.unchanged} already announced, ${templates.length} to publish`
      + (stats.sets ? ` (${stats.sets} playlist sets)` : '')
      + (stats.skippedItems ? `, ${stats.skippedItems} playlist items over the limit` : ''),
    );

    for (const treeName of stats.unreadableTrees) console.log(`Unreadable (blocks not found on the blob servers): ${treeName}`);

    let published = 0;
    let failed = 0;
    // A copied tree comes first, so its video events never point at a missing tree.
    mirrorTemplates = mirrorTemplates.filter((template) => !stats.unreadableTrees.includes(treeNameOf(template)));
    if (mirrorTemplates.length > 0) {
      console.log(`${mirrorTemplates.length} trees to copy from ${nip19.npubEncode(sourcePubkey)}`);
    }
    const draftsIndex = process.argv.indexOf('--drafts');
    if (dryRun && draftsIndex > -1) {
      const drafts = [...mirrorTemplates, ...templates].map((template) => JSON.stringify(template)).join('\n');
      await fs.writeFile(process.argv[draftsIndex + 1], `${drafts}\n`);
    }
    for (const template of mirrorTemplates) {
      if (dryRun) continue;
      const accepted = await publishToRelays(pool, relays, finalizeEvent(template, secretKey), maxWait);
      if (accepted === 0) {
        failed += 1;
        console.warn(`No relay accepted the tree ${treeNameOf(template)}`);
      }
    }
    for (const template of templates) {
      const title = template.tags.find((tag) => tag[0] === 'title')?.[1];
      if (dryRun) {
        console.log(`[dry-run] ${template.kind === VIDEO_SET_KIND ? 'playlist set ' : ''}${template.tags[0][1]} — ${title}`);
        continue;
      }
      const accepted = await publishToRelays(pool, relays, finalizeEvent(template, secretKey), maxWait);
      if (accepted > 0) published += 1;
      else {
        failed += 1;
        console.warn(`No relay accepted ${template.tags[0][1]}`);
      }
    }

    if (dryRun) return;
    const resultFile = process.env.VIDEO_EVENTS_RESULT_FILE
      ?? path.join(appDir, '.local', 'state', 'video-events-result.json');
    await fs.mkdir(path.dirname(resultFile), { recursive: true });
    await fs.writeFile(resultFile, `${JSON.stringify({
      generatedAt: Math.floor(Date.now() / 1000),
      npub: ownerNpub,
      mirroredTrees: mirrorTemplates.length,
      stats,
      published,
      failed,
      relays,
    }, null, 2)}\n`);
    console.log(`Published ${published} video events (${failed} failed). Result file: ${resultFile}`);
    if (failed > 0) process.exitCode = 1;
  } finally {
    pool.close(relays);
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  });
}
