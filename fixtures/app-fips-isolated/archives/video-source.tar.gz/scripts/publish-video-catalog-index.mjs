#!/usr/bin/env node
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SimplePool, nip19 } from 'nostr-tools';
import { finalizeEvent, getPublicKey } from 'nostr-tools/pure';
import { BlossomStore, HashTree, LinkType, MemoryStore, fromHex, nhashDecode, nhashEncode, toHex } from '@hashtree/core';
import { HASHTREE_ROOT_KIND, HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import { findPlayableMediaEntry, isPlayableMediaFileName } from '../src/lib/playableMedia.ts';
import { decodeVideoTextFile, sanitizeVideoDescription, sanitizeVideoTitle } from '../src/lib/videoText.ts';
import { getInitialPlaylistItemTitle } from '../src/lib/videoDisplayTitle.ts';
import {
  VIDEO_CATALOG_SCHEMA_V2,
  VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH,
  VIDEO_COLLECTION_MANIFEST_PATH,
  buildVideoCollection,
  createVideoCollectionSourceId,
  videoRecordFromNostrTreeEvent,
} from '../src/lib/videoCatalogCollection.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');

const DEFAULT_BOOTSTRAP_PUBKEY = '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';
const DEFAULT_VIDEO_FEED_PUBKEYS = [
  'feb535ca427f7ab7551adfc5fcc39132b10cbc11ce5841f05588680e94f4e71a',
];
const DEFAULT_RELAYS = [
  'wss://relay.damus.io',
  'wss://relay.primal.net',
  'wss://relay.nostr.band',
  'wss://relay.snort.social',
  'wss://temp.iris.to',
];
const DEFAULT_BLOSSOM_SERVERS = [
  { url: 'https://upload.iris.to', write: true, read: true },
  { url: 'https://cdn.iris.to', write: true, read: true },
];
const DEFAULT_PLAYLIST_READ_TIMEOUT_MS = 8000;
const DEFAULT_PLAYLIST_CONCURRENCY = 6;
const DEFAULT_PLAYLIST_ITEM_LIMIT = 5000;
const DEFAULT_UPLOAD_RETRIES = 3;
const DEFAULT_BATCH_UPLOAD_SIZE = 32;
const DEFAULT_MAX_CATALOG_BLOCK_BYTES = 25 * 1024 * 1024;
const MAX_METADATA_JSON_BYTES = 1024 * 1024;

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function parseList(value, fallback = []) {
  const entries = `${value ?? ''}`
    .split(/[\n,]+/)
    .map((entry) => entry.trim())
    .filter(Boolean);
  return entries.length > 0 ? entries : fallback;
}

function parseIntEnv(name, fallback) {
  const parsed = Number.parseInt(`${process.env[name] ?? ''}`, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function normalizePubkey(value) {
  const trimmed = `${value ?? ''}`.trim();
  if (/^[0-9a-f]{64}$/i.test(trimmed)) return trimmed.toLowerCase();
  if (!trimmed.startsWith('npub1')) return null;
  try {
    const decoded = nip19.decode(trimmed);
    return decoded.type === 'npub' ? decoded.data : null;
  } catch {
    return null;
  }
}

function parseNostrSecret(raw) {
  const trimmed = `${raw ?? ''}`.trim();
  if (!trimmed) {
    throw new Error('Missing Nostr secret key. Set VIDEO_CATALOG_PUBLISH_NSEC, NOSTR_SECRET_KEY, or VIDEO_CATALOG_PUBLISH_KEY_ALIAS.');
  }
  if (trimmed.startsWith('nsec1')) {
    const decoded = nip19.decode(trimmed);
    if (decoded.type !== 'nsec') throw new Error('Expected an nsec private key');
    return decoded.data;
  }
  if (/^[0-9a-f]{64}$/i.test(trimmed)) {
    return Uint8Array.from(Buffer.from(trimmed, 'hex'));
  }
  throw new Error('Unsupported Nostr secret key format');
}

async function readNamedHtreeSecret(alias) {
  const keysFile = path.join(os.homedir(), '.hashtree', 'keys');
  const raw = await fs.readFile(keysFile, 'utf8').catch(() => '');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const [secret, lineAlias] = trimmed.split(/\s+/, 2);
    if (lineAlias === alias) return secret;
  }
  return '';
}

async function loadPublishSecret(alias) {
  const raw = process.env.VIDEO_CATALOG_PUBLISH_NSEC
    ?? process.env.NOSTR_SECRET_KEY
    ?? process.env.NOSTR_SECRET_KEY_HEX
    ?? await readNamedHtreeSecret(alias);
  return parseNostrSecret(raw);
}

function createBlossomSigner(secretKey) {
  return async (template) => {
    const event = finalizeEvent({
      kind: template.kind,
      created_at: template.created_at,
      content: template.content,
      tags: template.tags,
    }, secretKey);
    return {
      kind: event.kind,
      created_at: event.created_at,
      content: event.content,
      tags: event.tags,
      pubkey: event.pubkey,
      id: event.id,
      sig: event.sig,
    };
  };
}

export function createBlossomAuthHeader(secretKey, hashes = []) {
  const now = Math.floor(Date.now() / 1000);
  const normalizedHashes = uniqueStrings(hashes.map((hash) => `${hash}`.toLowerCase()));
  const event = finalizeEvent({
    kind: 24242,
    created_at: now,
    content: normalizedHashes.length === 1 ? `upload ${normalizedHashes[0]}` : 'upload',
    tags: [
      ['t', 'upload'],
      ['expiration', `${now + 300}`],
      ...normalizedHashes.map((hash) => ['x', hash]),
    ],
  }, secretKey);
  return `Nostr ${Buffer.from(JSON.stringify(event), 'utf8').toString('base64')}`;
}

async function fetchLatestContacts(pool, relays, authorPubkey, maxWait) {
  const events = await pool.querySync(relays, {
    kinds: [3],
    authors: [authorPubkey],
    limit: 1,
  }, { maxWait });
  const latest = events.sort((a, b) => (b.created_at ?? 0) - (a.created_at ?? 0))[0];
  if (!latest) return [];
  return latest.tags
    .filter((tag) => tag[0] === 'p' && normalizePubkey(tag[1]))
    .map((tag) => normalizePubkey(tag[1]));
}

function chunk(values, size) {
  const chunks = [];
  for (let index = 0; index < values.length; index += size) {
    chunks.push(values.slice(index, index + size));
  }
  return chunks;
}

function eventTreeKey(event) {
  const dTag = event.tags.find((tag) => tag[0] === 'd')?.[1];
  return dTag?.startsWith('videos/') ? `${event.pubkey}:${dTag}` : null;
}

async function fetchVideoEvents(pool, relays, authors, options) {
  const latestByTree = new Map();
  for (const authorsChunk of chunk(authors, options.authorChunkSize)) {
    const events = await pool.querySync(relays, {
      kinds: [...HASHTREE_ROOT_KINDS],
      authors: authorsChunk,
      '#l': ['hashtree'],
      limit: options.limit,
    }, { maxWait: options.maxWait });

    for (const event of events) {
      const key = eventTreeKey(event);
      if (!key) continue;
      const existing = latestByTree.get(key);
      if (existing && (existing.created_at ?? 0) > (event.created_at ?? 0)) continue;
      if (existing && (existing.created_at ?? 0) === (event.created_at ?? 0) && existing.id >= event.id) continue;
      latestByTree.set(key, event);
    }
  }
  return Array.from(latestByTree.values());
}

function rootVideoEntry(record) {
  return {
    id: record.id,
    title: record.title,
    ...(record.description ? { description: record.description } : {}),
    ...(record.duration !== undefined ? { duration: record.duration } : {}),
    ...(record.timestamp !== undefined ? { timestamp: record.timestamp } : {}),
    ...(record.ownerNpub ? { ownerNpub: record.ownerNpub } : {}),
    ...(record.ownerPubkey ? { ownerPubkey: record.ownerPubkey } : {}),
    ...(record.treeName ? { treeName: record.treeName } : {}),
    ...(record.videoId ? { videoId: record.videoId } : {}),
    href: record.href,
    ...(record.nhash ? { nhash: record.nhash } : {}),
    ...(record.thumbnailUrl ? { thumbnailUrl: record.thumbnailUrl } : {}),
    ...(record.videoPath ? { videoPath: record.videoPath } : {}),
    tags: record.tags,
  };
}

function uniqueStrings(values) {
  const seen = new Set();
  const result = [];
  for (const value of values) {
    const trimmed = typeof value === 'string' ? value.trim() : '';
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    result.push(trimmed);
  }
  return result;
}

function readObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}

function readString(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function readPositiveNumber(value) {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed > 0) return parsed;
  }
  return undefined;
}

function parseUploadDate(value) {
  if (typeof value !== 'string' || !/^\d{8}$/.test(value)) return undefined;
  const year = Number.parseInt(value.slice(0, 4), 10);
  const month = Number.parseInt(value.slice(4, 6), 10) - 1;
  const day = Number.parseInt(value.slice(6, 8), 10);
  const date = new Date(Date.UTC(year, month, day));
  if (!Number.isFinite(date.getTime())) return undefined;
  return Math.floor(date.getTime() / 1000);
}

function truncateText(value, maxLength) {
  if (!value) return undefined;
  return value.length > maxLength ? value.slice(0, maxLength).trim() : value;
}

function readEpochSeconds(value) {
  const parsed = readPositiveNumber(value);
  if (!parsed) return parseUploadDate(value);
  return Math.floor(parsed > 10_000_000_000 ? parsed / 1000 : parsed);
}

function thumbnailEntryName(entry) {
  const name = readString(entry?.name)?.toLowerCase();
  if (!name) return false;
  return (
    name.startsWith('thumbnail.')
    || name.endsWith('.jpg')
    || name.endsWith('.jpeg')
    || name.endsWith('.webp')
    || name.endsWith('.png')
  );
}

function findThumbnailEntry(entries) {
  return entries.find((entry) => thumbnailEntryName(entry) && entry.cid);
}

function getEncodedNhashUrl(nhash, filename) {
  const encodedPath = filename
    ? `/${filename.split('/').filter(Boolean).map(encodeURIComponent).join('/')}`
    : '';
  return `/htree/${encodeURIComponent(nhash)}${encodedPath}`;
}

function getNhashFileUrl(fileCid, filename) {
  return getEncodedNhashUrl(nhashEncode(fileCid), filename);
}

function resolveEmbeddedThumbnailUrl(value, entries) {
  const trimmed = readString(value);
  if (!trimmed) return undefined;
  if (trimmed.startsWith('nhash1')) {
    return getEncodedNhashUrl(trimmed);
  }
  if (trimmed.startsWith('/htree/') || trimmed.startsWith('htree://')) {
    return trimmed;
  }

  const filename = trimmed.split('/').filter(Boolean).at(-1);
  if (!filename) return undefined;
  const entry = entries.find((candidate) => candidate.name === filename && candidate.cid);
  return entry?.cid ? getNhashFileUrl(entry.cid, entry.name) : undefined;
}

function hintsFromMetadataObject(metadata, entries = []) {
  const object = readObject(metadata);
  if (!object) return {};
  const description = truncateText(
    sanitizeVideoDescription(object.description),
    VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH,
  );
  return {
    ...(sanitizeVideoTitle(object.title) ? { title: sanitizeVideoTitle(object.title) } : {}),
    ...(description ? { description } : {}),
    ...(readPositiveNumber(object.duration) ? { duration: readPositiveNumber(object.duration) } : {}),
    ...(readEpochSeconds(object.originalDate ?? object.createdAt ?? object.upload_date ?? object.date)
      ? { timestamp: readEpochSeconds(object.originalDate ?? object.createdAt ?? object.upload_date ?? object.date) }
      : {}),
    ...(resolveEmbeddedThumbnailUrl(object.thumbnail, entries)
      ? { thumbnailUrl: resolveEmbeddedThumbnailUrl(object.thumbnail, entries) }
      : {}),
  };
}

function mergeHints(...hintsList) {
  const merged = {};
  for (const hints of hintsList) {
    if (!hints) continue;
    if (!merged.title && hints.title) merged.title = hints.title;
    if (!merged.description && hints.description) merged.description = hints.description;
    if (!merged.duration && hints.duration) merged.duration = hints.duration;
    if (!merged.timestamp && hints.timestamp) merged.timestamp = hints.timestamp;
    if (!merged.thumbnailUrl && hints.thumbnailUrl) merged.thumbnailUrl = hints.thumbnailUrl;
    if (!merged.videoPath && hints.videoPath) merged.videoPath = hints.videoPath;
  }
  return merged;
}

function withTimeout(promise, ms, label) {
  let timeout;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timeout = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    }),
  ]).finally(() => clearTimeout(timeout));
}

async function mapWithConcurrency(values, concurrency, mapper) {
  const results = new Array(values.length);
  let nextIndex = 0;
  const workerCount = Math.max(1, Math.min(concurrency, values.length));
  await Promise.all(Array.from({ length: workerCount }, async () => {
    while (nextIndex < values.length) {
      const currentIndex = nextIndex;
      nextIndex += 1;
      results[currentIndex] = await mapper(values[currentIndex], currentIndex);
    }
  }));
  return results;
}

async function listDirectoryEntries(tree, targetCid, timeoutMs) {
  try {
    const entries = await withTimeout(tree.listDirectory(targetCid), timeoutMs, 'listDirectory');
    return Array.isArray(entries)
      ? entries.filter((entry) => entry?.cid && readString(entry.name))
      : null;
  } catch {
    return null;
  }
}

async function readFileEntry(tree, entry, timeoutMs) {
  if (!entry?.cid) return null;
  try {
    return await withTimeout(tree.readFile(entry.cid), timeoutMs, `readFile ${entry.name}`);
  } catch {
    return null;
  }
}

async function readJsonEntry(tree, entry, timeoutMs) {
  if (!entry?.cid || (entry.size && entry.size > MAX_METADATA_JSON_BYTES)) return null;
  const bytes = await readFileEntry(tree, entry, timeoutMs);
  if (!bytes?.length) return null;
  try {
    return JSON.parse(decoder.decode(bytes));
  } catch {
    return null;
  }
}

async function readTextEntry(tree, entry, timeoutMs) {
  const bytes = await readFileEntry(tree, entry, timeoutMs);
  return decodeVideoTextFile(bytes);
}

function hasVideoFile(entries) {
  return entries.some((entry) => isPlayableMediaFileName(entry.name));
}

function hasPlaylistEntryMetadataHint(entry) {
  const meta = readObject(entry?.meta);
  if (!meta) return false;
  return !!(
    sanitizeVideoTitle(meta.title)
    || sanitizeVideoDescription(meta.description)
    || readPositiveNumber(meta.duration)
    || readEpochSeconds(meta.originalDate ?? meta.createdAt ?? meta.upload_date)
    || readString(meta.thumbnail)
  );
}

function looksLikePlaylistEntryName(name) {
  return /^video[_-]/i.test(name) || !/\.[a-z0-9]{1,8}$/i.test(name);
}

function isLikelyPlaylistVideoEntry(entry) {
  if (!entry?.cid) return false;
  if (typeof entry.type === 'number') {
    return entry.type === LinkType.Dir;
  }
  return hasPlaylistEntryMetadataHint(entry) || looksLikePlaylistEntryName(entry.name);
}

async function readVideoDirectoryHints(tree, dirCid, entries, timeoutMs) {
  const playableEntry = findPlayableMediaEntry(entries);
  const playableMetaHints = hintsFromMetadataObject(playableEntry?.meta, entries);
  const metadataEntry = entries.find((entry) => entry.name === 'metadata.json');
  const infoEntry = entries.find((entry) => entry.name === 'info.json');
  const titleEntry = entries.find((entry) => entry.name === 'title.txt');
  const descriptionEntry = entries.find((entry) => entry.name === 'description.txt');
  const thumbnailEntry = findThumbnailEntry(entries);

  const metadataHints = metadataEntry
    ? hintsFromMetadataObject(await readJsonEntry(tree, metadataEntry, timeoutMs), entries)
    : {};
  const infoHints = infoEntry
    ? hintsFromMetadataObject(await readJsonEntry(tree, infoEntry, timeoutMs), entries)
    : {};
  const title = titleEntry ? await readTextEntry(tree, titleEntry, timeoutMs) : '';
  const description = descriptionEntry ? await readTextEntry(tree, descriptionEntry, timeoutMs) : '';
  const fileThumbnail = thumbnailEntry ? getNhashFileUrl(thumbnailEntry.cid, thumbnailEntry.name) : undefined;

  return mergeHints(
    {
      ...(playableEntry ? { videoPath: playableEntry.name } : {}),
      ...(fileThumbnail ? { thumbnailUrl: fileThumbnail } : {}),
    },
    playableMetaHints,
    metadataHints,
    infoHints,
    title ? { title } : {},
    description ? { description } : {},
  );
}

function recordRootCid(record) {
  try {
    return record.nhash ? nhashDecode(record.nhash) : null;
  } catch {
    return null;
  }
}

function applyHintsToRecord(record, hints) {
  return {
    ...record,
    ...(hints.title ? { title: hints.title } : {}),
    ...(hints.description ? { description: hints.description } : {}),
    ...(hints.duration ? { duration: hints.duration } : {}),
    ...(hints.timestamp ? { timestamp: hints.timestamp } : {}),
    ...(hints.thumbnailUrl ? { thumbnailUrl: hints.thumbnailUrl } : {}),
    ...(hints.videoPath ? { videoPath: hints.videoPath } : {}),
  };
}

function childRecordFromPlaylistEntry(parent, entry, hints) {
  const entryMetaHints = hintsFromMetadataObject(entry.meta);
  const mergedHints = mergeHints(entryMetaHints, hints);
  const fallbackTitle = getInitialPlaylistItemTitle(entry.name) || parent.title || entry.name || 'Video';
  return {
    id: `${parent.id}/${entry.name}`,
    title: mergedHints.title ?? fallbackTitle,
    ...(mergedHints.description ? { description: mergedHints.description } : {}),
    ...(mergedHints.duration ? { duration: mergedHints.duration } : {}),
    timestamp: mergedHints.timestamp ?? parent.timestamp,
    ...(parent.ownerNpub ? { ownerNpub: parent.ownerNpub } : {}),
    ...(parent.ownerPubkey ? { ownerPubkey: parent.ownerPubkey } : {}),
    ...(parent.treeName ? { treeName: parent.treeName } : {}),
    videoId: entry.name,
    href: parent.ownerNpub && parent.treeName
      ? `#/${parent.ownerNpub}/${encodeURIComponent(parent.treeName)}/${encodeURIComponent(entry.name)}`
      : parent.href,
    ...(parent.nhash ? { nhash: parent.nhash } : {}),
    ...(mergedHints.thumbnailUrl ? { thumbnailUrl: mergedHints.thumbnailUrl } : {}),
    ...(mergedHints.videoPath ? { videoPath: mergedHints.videoPath } : {}),
    tags: uniqueStrings([...parent.tags, 'playlist']),
    sourceEvents: [...parent.sourceEvents],
    provenance: parent.provenance.map((entry) => ({ ...entry })),
  };
}

async function expandSingleRecordFromTree(tree, record, options, stats, claimPlaylistItem) {
  const rootCid = recordRootCid(record);
  if (!rootCid) {
    stats.missingRootCid += 1;
    return [record];
  }

  const rootEntries = await listDirectoryEntries(tree, rootCid, options.readTimeoutMs);
  if (!rootEntries?.length) {
    stats.unreadableRoots += 1;
    return [record];
  }

  if (hasVideoFile(rootEntries)) {
    stats.singleVideoRoots += 1;
    const hints = await readVideoDirectoryHints(tree, rootCid, rootEntries, options.readTimeoutMs);
    return [applyHintsToRecord(record, hints)];
  }

  stats.playlistRoots += 1;
  const parentRecord = {
    ...record,
    tags: uniqueStrings([...record.tags, 'playlist']),
  };
  const candidates = rootEntries
    .filter(isLikelyPlaylistVideoEntry)
    .sort((a, b) => a.name.localeCompare(b.name));

  const children = await mapWithConcurrency(candidates, options.concurrency, async (entry) => {
    const entryMetaHints = hintsFromMetadataObject(entry.meta);
    const subEntries = await listDirectoryEntries(tree, entry.cid, options.readTimeoutMs);
    if (!subEntries?.length) {
      if (hasPlaylistEntryMetadataHint(entry) || looksLikePlaylistEntryName(entry.name)) {
        if (!claimPlaylistItem()) {
          stats.skippedPlaylistChildren += 1;
          return null;
        }
        stats.indeterminatePlaylistChildren += 1;
        return childRecordFromPlaylistEntry(parentRecord, entry, entryMetaHints);
      }
      return null;
    }

    if (!hasVideoFile(subEntries) && !hasPlaylistEntryMetadataHint(entry)) {
      return null;
    }

    const hints = hasVideoFile(subEntries)
      ? await readVideoDirectoryHints(tree, entry.cid, subEntries, options.readTimeoutMs)
      : {};
    if (!claimPlaylistItem()) {
      stats.skippedPlaylistChildren += 1;
      return null;
    }
    stats.playlistChildren += 1;
    return childRecordFromPlaylistEntry(parentRecord, entry, hints);
  });

  return [parentRecord, ...children.filter(Boolean)];
}

export async function expandVideoRecordsFromTrees(tree, records, options = {}) {
  const readTimeoutMs = options.readTimeoutMs ?? DEFAULT_PLAYLIST_READ_TIMEOUT_MS;
  const concurrency = options.concurrency ?? DEFAULT_PLAYLIST_CONCURRENCY;
  let remainingPlaylistItems = options.itemLimit ?? DEFAULT_PLAYLIST_ITEM_LIMIT;
  const stats = {
    rootRecords: records.length,
    singleVideoRoots: 0,
    playlistRoots: 0,
    playlistChildren: 0,
    indeterminatePlaylistChildren: 0,
    skippedPlaylistChildren: 0,
    unreadableRoots: 0,
    missingRootCid: 0,
  };
  const claimPlaylistItem = () => {
    if (remainingPlaylistItems <= 0) return false;
    remainingPlaylistItems -= 1;
    return true;
  };
  const groups = await mapWithConcurrency(records, concurrency, (record) => expandSingleRecordFromTree(
    tree,
    record,
    { readTimeoutMs, concurrency },
    stats,
    claimPlaylistItem,
  ));
  return {
    records: groups.flat().sort((a, b) => {
      if ((b.timestamp ?? 0) !== (a.timestamp ?? 0)) return (b.timestamp ?? 0) - (a.timestamp ?? 0);
      return a.id.localeCompare(b.id);
    }),
    stats,
  };
}

async function putJsonFile(tree, payload) {
  const bytes = encoder.encode(`${JSON.stringify(payload, null, 2)}\n`);
  const { cid, size } = await tree.putFile(bytes, { unencrypted: true });
  return { cid, size };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function createBatchUploadPayload(entries, contentType = 'application/octet-stream') {
  return {
    blobs: entries.map(([sha256, data]) => ({
      sha256,
      content_type: contentType,
      data: Buffer.from(data).toString('base64'),
    })),
  };
}

function batchUploadUrlForServer(serverUrl) {
  return new URL('/upload/batch', serverUrl).toString();
}

async function fetchJsonWithTimeout(url, init, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    if (!response.ok) {
      throw new Error(`${response.status} ${response.statusText}: ${text.slice(0, 240)}`);
    }
    return text ? JSON.parse(text) : {};
  } finally {
    clearTimeout(timeout);
  }
}

async function uploadBatchToUrl(url, entries, options) {
  const payload = createBatchUploadPayload(entries);
  const response = await fetchJsonWithTimeout(url, {
    method: 'POST',
    headers: {
      Authorization: createBlossomAuthHeader(options.secretKey),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  }, options.timeoutMs);
  const uploaded = Number.isFinite(response.uploaded) ? response.uploaded : entries.length;
  return {
    uploaded,
    skipped: Math.max(0, entries.length - uploaded),
  };
}

async function uploadMemoryStoreBlocksInBatches(entries, totalBytes, options) {
  const batchSize = Math.max(1, options.batchSize);
  const batches = chunk(entries, batchSize);
  let uploaded = 0;
  let skipped = 0;
  let attemptFailures = 0;

  console.log(
    `Uploading ${entries.length} catalog blocks (${totalBytes} bytes) `
    + `in ${batches.length} batches to ${options.batchUploadUrls.join(', ')}...`
  );

  for (let batchIndex = 0; batchIndex < batches.length; batchIndex += 1) {
    const batch = batches[batchIndex];
    let lastError;
    let completed = false;
    const batchStartedAt = Date.now();

    for (let attempt = 1; attempt <= options.retries && !completed; attempt += 1) {
      for (const url of options.batchUploadUrls) {
        try {
          const result = await uploadBatchToUrl(url, batch, options);
          uploaded += result.uploaded;
          skipped += result.skipped;
          completed = true;
          break;
        } catch (error) {
          attemptFailures += 1;
          lastError = error;
          console.warn(
            `Catalog batch upload failed (${attempt}/${options.retries}) for batch ${batchIndex + 1}/${batches.length} `
            + `via ${url}: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      }

      if (!completed && attempt < options.retries) {
        await sleep(Math.min(1000 * (2 ** (attempt - 1)), 8000));
      }
    }

    if (!completed) {
      throw lastError ?? new Error(`Catalog batch ${batchIndex + 1}/${batches.length} failed`);
    }

    const processed = Math.min(entries.length, (batchIndex + 1) * batchSize);
    console.log(
      `Uploaded catalog batch ${batchIndex + 1}/${batches.length} in ${Date.now() - batchStartedAt}ms: `
      + `${processed}/${entries.length} blocks (${uploaded} new, ${skipped} skipped)`
    );
  }

  return { uploaded, skipped, total: entries.length, totalBytes, attemptFailures, mode: 'batch' };
}

async function uploadMemoryStoreBlocks(sourceStore, targetStore, options) {
  const entries = Array.from(sourceStore.data.entries());
  const totalBytes = entries.reduce((sum, [, data]) => sum + data.length, 0);
  if (options.batchUploadUrls?.length) {
    return uploadMemoryStoreBlocksInBatches(entries, totalBytes, options);
  }

  let uploaded = 0;
  let skipped = 0;
  let attemptFailures = 0;

  console.log(`Uploading ${entries.length} catalog blocks (${totalBytes} bytes) to Blossom...`);
  for (const [hashHex, data] of entries) {
    const hash = fromHex(hashHex);
    let lastError;
    for (let attempt = 1; attempt <= options.retries; attempt += 1) {
      try {
        const stored = await targetStore.put(hash, data, 'application/octet-stream');
        if (stored) {
          uploaded += 1;
        } else {
          skipped += 1;
        }
        break;
      } catch (error) {
        attemptFailures += 1;
        lastError = error;
        if (attempt >= options.retries) {
          throw error;
        }
        const delayMs = Math.min(1000 * (2 ** (attempt - 1)), 8000);
        console.warn(
          `Catalog block upload failed (${attempt}/${options.retries}) for ${hashHex.slice(0, 12)}: `
          + `${error instanceof Error ? error.message : String(error)}; retrying in ${delayMs}ms`
        );
        await sleep(delayMs);
      }
    }

    const completed = uploaded + skipped;
    if (completed % options.progressEvery === 0 || completed === entries.length) {
      console.log(`Uploaded catalog blocks: ${completed}/${entries.length} (${uploaded} new, ${skipped} skipped)`);
    }
    if (lastError && uploaded + skipped < entries.length) {
      await sleep(0);
    }
  }

  return { uploaded, skipped, total: entries.length, totalBytes, attemptFailures, mode: 'single' };
}

async function publishCatalogRootTree(tree, records, manifest, options) {
  const recentVideos = records.slice(0, options.recentLimit).map(rootVideoEntry);
  const rootPayload = {
    schema: VIDEO_CATALOG_SCHEMA_V2,
    version: 2,
    title: options.title,
    generatedAt: new Date(options.generatedAt * 1000).toISOString(),
    videos: recentVideos,
    collections: {
      videos: {
        manifestPath: VIDEO_COLLECTION_MANIFEST_PATH,
        recordCount: records.length,
      },
    },
  };

  const manifestFile = await putJsonFile(tree, manifest);
  const videosDir = await tree.putDirectory([
    { name: 'manifest.json', cid: manifestFile.cid, size: manifestFile.size, type: LinkType.File },
  ], { unencrypted: true });
  const collectionsDir = await tree.putDirectory([
    { name: 'videos', cid: videosDir.cid, size: videosDir.size, type: LinkType.Dir },
  ], { unencrypted: true });
  const rootFile = await putJsonFile(tree, rootPayload);
  return await tree.putDirectory([
    { name: 'root.json', cid: rootFile.cid, size: rootFile.size, type: LinkType.File },
    { name: 'collections', cid: collectionsDir.cid, size: collectionsDir.size, type: LinkType.Dir },
  ], { unencrypted: true });
}

async function publishRootEvent(pool, relays, secretKey, rootCid, options) {
  const tags = [
    ['d', options.treeName],
    ['title', options.title],
    ['l', 'hashtree'],
    ['l', 'video'],
    ['l', 'catalog'],
    ['schema', VIDEO_CATALOG_SCHEMA_V2],
    ['manifest', VIDEO_COLLECTION_MANIFEST_PATH],
    ['video_count', `${options.recordCount}`],
    ['hash', toHex(rootCid.hash)],
  ];

  const event = finalizeEvent({
    kind: HASHTREE_ROOT_KIND,
    created_at: options.generatedAt,
    tags,
    content: '',
  }, secretKey);

  const results = await Promise.allSettled(pool.publish(relays, event, { maxWait: options.maxWait }));
  const publishedTo = results.filter((result) => result.status === 'fulfilled').length;
  if (publishedTo === 0) {
    throw new Error('Failed to publish video catalog root to relays');
  }
  return { event, publishedTo };
}

async function writeResultFile(result) {
  const resultFile = process.env.VIDEO_CATALOG_RESULT_FILE
    ?? path.join(appDir, '.local', 'state', 'video-catalog-index-result.json');
  await fs.mkdir(path.dirname(resultFile), { recursive: true });
  await fs.writeFile(resultFile, `${JSON.stringify(result, null, 2)}\n`);
  return resultFile;
}

async function main() {
  const relays = parseList(process.env.VIDEO_CATALOG_RELAYS, DEFAULT_RELAYS);
  const configuredBlossomServers = parseList(process.env.VIDEO_CATALOG_BLOSSOM_SERVERS, []);
  const blossomServers = configuredBlossomServers.length > 0
    ? configuredBlossomServers.map((url) => ({ url, write: true, read: true }))
    : DEFAULT_BLOSSOM_SERVERS;
  const maxWait = parseIntEnv('VIDEO_CATALOG_RELAY_WAIT_MS', 8000);
  const eventLimit = parseIntEnv('VIDEO_CATALOG_EVENT_LIMIT', 1000);
  const recentLimit = parseIntEnv('VIDEO_CATALOG_RECENT_LIMIT', 100);
  const authorChunkSize = parseIntEnv('VIDEO_CATALOG_AUTHOR_CHUNK_SIZE', 200);
  const uploadProgressEvery = parseIntEnv('VIDEO_CATALOG_UPLOAD_PROGRESS_EVERY', 100);
  const uploadTimeoutMs = parseIntEnv('VIDEO_CATALOG_UPLOAD_TIMEOUT_MS', 30_000);
  const uploadRetries = parseIntEnv('VIDEO_CATALOG_UPLOAD_RETRIES', DEFAULT_UPLOAD_RETRIES);
  const batchUploadUrls = parseList(process.env.VIDEO_CATALOG_BATCH_UPLOAD_URLS, [])
    .map((url) => url.endsWith('/upload/batch') ? url : batchUploadUrlForServer(url));
  const batchUploadSize = Math.min(parseIntEnv('VIDEO_CATALOG_BATCH_UPLOAD_SIZE', DEFAULT_BATCH_UPLOAD_SIZE), 1024);
  const maxCatalogBlockBytes = parseIntEnv('VIDEO_CATALOG_MAX_BLOCK_BYTES', DEFAULT_MAX_CATALOG_BLOCK_BYTES);
  const playlistReadTimeoutMs = parseIntEnv('VIDEO_CATALOG_PLAYLIST_READ_TIMEOUT_MS', DEFAULT_PLAYLIST_READ_TIMEOUT_MS);
  const playlistConcurrency = parseIntEnv('VIDEO_CATALOG_PLAYLIST_CONCURRENCY', DEFAULT_PLAYLIST_CONCURRENCY);
  const playlistItemLimit = parseIntEnv('VIDEO_CATALOG_PLAYLIST_ITEM_LIMIT', DEFAULT_PLAYLIST_ITEM_LIMIT);
  const treeName = `${process.env.VIDEO_CATALOG_TREE_NAME ?? 'iris-video/index'}`.trim();
  const title = `${process.env.VIDEO_CATALOG_TITLE ?? 'Iris Video Index'}`.trim();
  const keyAlias = `${process.env.VIDEO_CATALOG_PUBLISH_KEY_ALIAS ?? 'self'}`.trim();
  const includeBootstrapFollows = process.env.VIDEO_CATALOG_INCLUDE_BOOTSTRAP_FOLLOWS !== '0';

  const pool = new SimplePool();
  try {
    const explicitAuthors = parseList(process.env.VIDEO_CATALOG_AUTHORS, [])
      .map(normalizePubkey)
      .filter(Boolean);
    const authorSet = new Set([
      DEFAULT_BOOTSTRAP_PUBKEY,
      ...DEFAULT_VIDEO_FEED_PUBKEYS,
      ...explicitAuthors,
    ]);
    if (includeBootstrapFollows) {
      for (const pubkey of await fetchLatestContacts(pool, relays, DEFAULT_BOOTSTRAP_PUBKEY, maxWait)) {
        authorSet.add(pubkey);
      }
    }

    const authors = Array.from(authorSet);
    console.log(`Fetching Iris Video events for ${authors.length} authors from ${relays.length} relays...`);
    const events = await fetchVideoEvents(pool, relays, authors, { limit: eventLimit, maxWait, authorChunkSize });
    const rootRecords = events
      .map((event) => videoRecordFromNostrTreeEvent(event, 'catalog'))
      .filter(Boolean)
      .sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0));

    if (rootRecords.length === 0) {
      throw new Error('No public Iris Video records found for the configured author scope');
    }
    console.log(`Found ${rootRecords.length} public Iris Video roots. Expanding playlist directories...`);

    const secretKey = await loadPublishSecret(keyAlias);
    const publishPubkey = getPublicKey(secretKey);
    const publishNpub = nip19.npubEncode(publishPubkey);
    const generatedAt = Math.floor(Date.now() / 1000);
    let uploadEvents = 0;
    let serverUploadFailures = 0;
    let putAttemptFailures = 0;
    const blossomStore = new BlossomStore({
      servers: blossomServers,
      signer: createBlossomSigner(secretKey),
      skipExistenceCheck: true,
      putTimeoutMs: uploadTimeoutMs,
      onUploadProgress(serverUrl, status) {
        uploadEvents += 1;
        if (status === 'failed') {
          serverUploadFailures += 1;
        }
        if (uploadEvents % uploadProgressEvery === 0 || status === 'failed') {
          console.log(`Blossom writes: ${uploadEvents} events (${serverUploadFailures} server failures), latest=${status} ${serverUrl}`);
        }
      },
      logger(entry) {
        if (!entry.success && entry.operation === 'get' && `${entry.error ?? ''}` === '404') {
          return;
        }
        if (!entry.success && (entry.operation === 'put' || entry.operation === 'get')) {
          console.warn(`Blossom ${entry.operation} failed on ${entry.server}: ${entry.error ?? 'unknown error'}`);
        }
      },
    });
    const store = {
      async put(hash, data, contentType) {
        try {
          return await blossomStore.put(hash, data, contentType);
        } catch (error) {
          putAttemptFailures += 1;
          throw error;
        }
      },
      get(hash) {
        return blossomStore.get(hash);
      },
      has(hash) {
        return blossomStore.has(hash);
      },
      delete(hash) {
        return blossomStore.delete(hash);
      },
    };
    const remoteTree = new HashTree({ store });
    const { records, stats: expansionStats } = await expandVideoRecordsFromTrees(remoteTree, rootRecords, {
      readTimeoutMs: playlistReadTimeoutMs,
      concurrency: playlistConcurrency,
      itemLimit: playlistItemLimit,
    });
    console.log(
      `Expanded ${expansionStats.rootRecords} roots into ${records.length} catalog records `
      + `(${expansionStats.singleVideoRoots} single roots, ${expansionStats.playlistRoots} playlists, `
      + `${expansionStats.playlistChildren} playlist children, `
      + `${expansionStats.indeterminatePlaylistChildren} inferred children, `
      + `${expansionStats.unreadableRoots} unreadable roots).`
    );
    console.log(`Building collection for ${records.length} public catalog records...`);

    const localStore = new MemoryStore();
    const localTree = new HashTree({ store: localStore });
    const sourceId = createVideoCollectionSourceId(publishNpub, treeName);
    const built = await buildVideoCollection(localStore, records, {
      sourceId,
      updatedAt: generatedAt,
      metadata: {
        title,
        authorCount: authors.length,
        relayCount: relays.length,
        rootRecordCount: rootRecords.length,
        playlistChildren: expansionStats.playlistChildren,
        inferredPlaylistChildren: expansionStats.indeterminatePlaylistChildren,
        scope: 'default-bootstrap-authors',
      },
    });
    const { cid: rootCid } = await publishCatalogRootTree(localTree, built.records, built.manifest, {
      title,
      generatedAt,
      recentLimit,
    });
    console.log(`Built catalog block store: ${localStore.size} blocks (${localStore.totalBytes} bytes).`);
    if (localStore.totalBytes > maxCatalogBlockBytes) {
      throw new Error(
        `Refusing to upload oversized video catalog (${localStore.totalBytes} bytes > ${maxCatalogBlockBytes} bytes). `
        + 'Trim catalog records or raise VIDEO_CATALOG_MAX_BLOCK_BYTES intentionally.'
      );
    }
    const uploadSummary = await uploadMemoryStoreBlocks(localStore, store, {
      retries: uploadRetries,
      progressEvery: uploadProgressEvery,
      batchUploadUrls,
      batchSize: batchUploadSize,
      timeoutMs: uploadTimeoutMs,
      secretKey,
    });
    const immutableUrl = `htree://${nhashEncode(rootCid)}`;
    const mutableUrl = `htree://${publishNpub}/${treeName}`;
    const { event, publishedTo } = await publishRootEvent(pool, relays, secretKey, rootCid, {
      treeName,
      title,
      generatedAt,
      recordCount: built.records.length,
      maxWait,
    });

    const result = {
      generatedAt,
      title,
      treeName,
      npub: publishNpub,
      mutableUrl,
      immutableUrl,
      eventId: event.id,
      publishedTo,
      recordCount: built.records.length,
      recentCount: Math.min(recentLimit, built.records.length),
      authorCount: authors.length,
      rootRecordCount: rootRecords.length,
      expansionStats,
      uploadSummary: { ...uploadSummary, putAttemptFailures },
      relays,
      blossomServers: blossomServers.map((server) => server.url),
    };
    const resultFile = await writeResultFile(result);

    console.log(`Published ${built.records.length} videos to ${mutableUrl}`);
    console.log(`Immutable catalog URL: ${immutableUrl}`);
    console.log(`Result file: ${resultFile}`);
  } finally {
    pool.close(relays);
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  });
}
