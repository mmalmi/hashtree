import { describe, expect, it, vi, afterEach } from 'vitest';
import { MemoryStore, encryptObject, decryptObject, nhashDecode, sha256, toHex } from '@hashtree/core';
import { isLinkSecretHex } from '../src/lib/videoRootKeys';
import {
  VIDEO_COLLECTION_INDEX_BY_AUTHOR,
  VIDEO_COLLECTION_INDEX_BY_NHASH,
  VIDEO_COLLECTION_INDEX_BY_SOURCE_EVENT,
  VIDEO_COLLECTION_INDEX_BY_TAG,
  VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH,
  VIDEO_COLLECTION_SEARCH_CREATORS,
  VIDEO_COLLECTION_SEARCH_TAGS,
  VIDEO_COLLECTION_SEARCH_VIDEOS,
  buildVideoCollection,
  classifyVideoEventTrustScope,
  getVideoCatalogIndexTrustSettings,
  normalizeVideoCollectionRecord,
  queryVideoCollectionRecordsByAuthor,
  saveVideoCatalogIndexTrustSettings,
  searchVideoCollectionCreators,
  searchVideoCollectionRecords,
  searchVideoCollectionTags,
  videoRecordFromNostrTreeEvent,
  type VideoCollectionRecord,
} from '../src/lib/videoCatalogCollection';

const OWNER_PUBKEY = 'a'.repeat(64);

function record(overrides: Partial<VideoCollectionRecord> = {}): VideoCollectionRecord {
  return {
    id: 'video-1',
    title: 'Lightning Garden Walk',
    href: '#/npub1owner/videos%2Flightning',
    ownerPubkey: OWNER_PUBKEY,
    treeName: 'videos/Lightning Garden Walk',
    nhash: 'nhash1example',
    tags: ['bitcoin', 'garden'],
    sourceEvents: ['event-1'],
    provenance: [{ source: 'catalog-v2', scope: 'catalog', catalogUrl: 'htree://npub1catalog/videos' }],
    timestamp: 100,
    ...overrides,
  };
}

function installLocalStorage() {
  const values = new Map<string, string>();
  const localStorage = {
    getItem: vi.fn((key: string) => values.get(key) ?? null),
    setItem: vi.fn((key: string, value: string) => {
      values.set(key, value);
    }),
    removeItem: vi.fn((key: string) => {
      values.delete(key);
    }),
    clear: vi.fn(() => values.clear()),
    key: vi.fn((index: number) => Array.from(values.keys())[index] ?? null),
    get length() {
      return values.size;
    },
  };
  vi.stubGlobal('window', { localStorage });
  return localStorage;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('video collection manifests', () => {
  it('builds hashtree collection roots for videos, creators, tags, and lookup indexes', async () => {
    const store = new MemoryStore();
    const built = await buildVideoCollection(store, [
      record(),
      record({
        id: 'video-2',
        title: 'Cooking With Sats',
        treeName: 'videos/Cooking With Sats',
        tags: ['food', 'bitcoin'],
        sourceEvents: ['event-2'],
        nhash: 'nhash1second',
        timestamp: 200,
      }),
    ], { sourceId: 'test/videos' });

    expect(Object.keys(built.manifest.indexes).sort()).toEqual([
      VIDEO_COLLECTION_INDEX_BY_AUTHOR,
      VIDEO_COLLECTION_INDEX_BY_NHASH,
      VIDEO_COLLECTION_INDEX_BY_SOURCE_EVENT,
      VIDEO_COLLECTION_INDEX_BY_TAG,
      VIDEO_COLLECTION_SEARCH_CREATORS,
      VIDEO_COLLECTION_SEARCH_TAGS,
      VIDEO_COLLECTION_SEARCH_VIDEOS,
    ].sort());

    await expect(searchVideoCollectionRecords(store, built.source, 'lightning', 5))
      .resolves.toMatchObject([{ id: 'video-1', title: 'Lightning Garden Walk' }]);
    await expect(searchVideoCollectionCreators(store, built.source, OWNER_PUBKEY.slice(0, 12), 5))
      .resolves.toMatchObject([{ ownerPubkey: OWNER_PUBKEY }]);
    await expect(searchVideoCollectionTags(store, built.source, 'food', 5))
      .resolves.toMatchObject([{ id: 'video-2' }]);

    await expect(built.source.queryIndex(VIDEO_COLLECTION_INDEX_BY_SOURCE_EVENT, { prefix: 'event-1\t', limit: 5 }))
      .resolves.toHaveLength(1);
    await expect(built.source.queryIndex(VIDEO_COLLECTION_INDEX_BY_AUTHOR, { prefix: `${OWNER_PUBKEY}\t`, limit: 5 }))
      .resolves.toHaveLength(2);
    await expect(built.source.queryIndex(VIDEO_COLLECTION_INDEX_BY_NHASH, { prefix: 'nhash1second\t', limit: 5 }))
      .resolves.toHaveLength(1);
    await expect(built.source.queryIndex(VIDEO_COLLECTION_INDEX_BY_TAG, { prefix: 'bitcoin\t', limit: 5 }))
      .resolves.toHaveLength(2);

    await expect(queryVideoCollectionRecordsByAuthor(store, built.source, OWNER_PUBKEY, 5))
      .resolves.toMatchObject([
        { id: 'video-2', title: 'Cooking With Sats' },
        { id: 'video-1', title: 'Lightning Garden Walk' },
      ]);
  });

  it('projects public Iris Video tree events into trusted collection records', () => {
    const event = {
      id: 'e'.repeat(64),
      pubkey: OWNER_PUBKEY,
      created_at: 123,
      tags: [
        ['d', 'videos/Sats Show'],
        ['hash', 'b'.repeat(64)],
        ['l', 'hashtree'],
      ],
    };

    expect(videoRecordFromNostrTreeEvent(event, 'own')).toMatchObject({
      id: `${OWNER_PUBKEY}:${'e'.repeat(64)}`,
      title: 'Sats Show',
      treeName: 'videos/Sats Show',
      sourceEvents: ['e'.repeat(64)],
      provenance: [{ source: 'nostr-kind-30078', scope: 'own' }],
    });

    expect(videoRecordFromNostrTreeEvent({
      ...event,
      tags: [...event.tags, ['encryptedKey', 'secret']],
    }, 'own')).toBeNull();
  });

  it.each(['legacy-chk', 'chk-v1', 'rnd-v1'] as const)('opens %s content through its catalog nhash', async mode => {
    const plaintext = new TextEncoder().encode('video root');
    const { key, ciphertext } = await encryptObject(plaintext, mode);
    const event = {
      kind: 30064, pubkey: OWNER_PUBKEY,
      tags: [['d', 'videos/Test'], ['hash', toHex(await sha256(ciphertext))], ['key', toHex(key)]],
    };
    const record = videoRecordFromNostrTreeEvent(event, 'own');
    expect(record?.provenance[0].source).toBe('nostr-kind-30064');
    const root = nhashDecode(record!.nhash!);
    expect(root.key).toEqual(key);
    await expect(decryptObject(ciphertext, root.key!)).resolves.toEqual(plaintext);
  });

  it.each(['', 'g'.repeat(64), 'ff'.repeat(33), '01'.repeat(34)])('rejects a malformed public key tag %s', key => {
    expect(videoRecordFromNostrTreeEvent({
      pubkey: OWNER_PUBKEY, tags: [['d', 'videos/Test'], ['hash', 'aa'.repeat(32)], ['key', key]],
    }, 'own')).toBeNull();
  });

  it('accepts opaque legacy and extended sharing secrets independently of object suites', () => {
    expect(isLinkSecretHex('ff'.repeat(32))).toBe(true);
    expect(isLinkSecretHex('ff'.repeat(33))).toBe(true);
    expect(isLinkSecretHex('ff'.repeat(34))).toBe(false);
    expect(isLinkSecretHex('zz'.repeat(32))).toBe(false);
  });

  it('caps long descriptions before storing or indexing records', () => {
    const normalized = normalizeVideoCollectionRecord(record({
      description: 'a'.repeat(VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH + 100),
    }));

    expect(normalized.description).toHaveLength(VIDEO_COLLECTION_MAX_DESCRIPTION_LENGTH);
  });
});

describe('video catalog trust settings', () => {
  it('indexes own events by default and only includes followed authors when enabled', () => {
    expect(classifyVideoEventTrustScope({
      authorPubkey: OWNER_PUBKEY,
      ownPubkey: OWNER_PUBKEY,
    })).toBe('own');

    expect(classifyVideoEventTrustScope({
      authorPubkey: OWNER_PUBKEY,
      ownPubkey: 'b'.repeat(64),
      follows: [OWNER_PUBKEY],
      settings: { includeFollowed: false, allowlistedPubkeys: [] },
    })).toBeNull();

    expect(classifyVideoEventTrustScope({
      authorPubkey: OWNER_PUBKEY,
      ownPubkey: 'b'.repeat(64),
      follows: [OWNER_PUBKEY],
      settings: { includeFollowed: true, allowlistedPubkeys: [] },
    })).toBe('followed');
  });

  it('normalizes allowlisted npubs and hex pubkeys in local settings', () => {
    installLocalStorage();
    saveVideoCatalogIndexTrustSettings({
      includeFollowed: true,
      allowlistedPubkeys: [OWNER_PUBKEY.toUpperCase(), 'not-a-pubkey'],
    });

    expect(getVideoCatalogIndexTrustSettings()).toEqual({
      includeFollowed: true,
      allowlistedPubkeys: [OWNER_PUBKEY],
    });
  });
});
