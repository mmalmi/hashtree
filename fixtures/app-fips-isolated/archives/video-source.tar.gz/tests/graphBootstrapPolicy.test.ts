import { describe, expect, test, vi } from 'vitest';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { shouldBootstrapPublicGraph } from '../src/lib/graphBootstrapPolicy';
import { VIDEO_DEFAULT_RELAYS } from '../src/lib/defaultRelays';

vi.mock('../src/lib/nativeHtree', () => ({ canUseInjectedHtreeServerUrl: () => false }));

describe('public graph bootstrap relay policy', () => {
  test('allows only the normalized shipped relay set', () => {
    expect(shouldBootstrapPublicGraph(DEFAULT_PUBLIC_RELAYS)).toBe(true);
    expect(shouldBootstrapPublicGraph([...DEFAULT_PUBLIC_RELAYS].reverse().map(url => ` ${url.toUpperCase()}/ `))).toBe(true);
    expect(shouldBootstrapPublicGraph([...DEFAULT_PUBLIC_RELAYS, DEFAULT_PUBLIC_RELAYS[0]])).toBe(true);
  });

  test('allows the set the video app ships: no dead relay, plus the video relay', () => {
    expect(VIDEO_DEFAULT_RELAYS).not.toContain('wss://relay.nostr.band');
    expect(VIDEO_DEFAULT_RELAYS).toContain('wss://relay.divine.video');
    expect(VIDEO_DEFAULT_RELAYS[0]).toBe('wss://relay.ditto.pub');
    expect(shouldBootstrapPublicGraph(VIDEO_DEFAULT_RELAYS)).toBe(true);
    expect(shouldBootstrapPublicGraph([...VIDEO_DEFAULT_RELAYS].reverse())).toBe(true);
    // A saved list from before a relay was retired still counts as the shipped set.
    expect(shouldBootstrapPublicGraph([...VIDEO_DEFAULT_RELAYS, 'wss://relay.nostr.band'])).toBe(true);
    expect(shouldBootstrapPublicGraph([...DEFAULT_PUBLIC_RELAYS, 'wss://relay.nostr.band'])).toBe(true);
    // Neither shipped set with something else added or removed.
    expect(shouldBootstrapPublicGraph([...VIDEO_DEFAULT_RELAYS, 'wss://custom.example'])).toBe(false);
    expect(shouldBootstrapPublicGraph(VIDEO_DEFAULT_RELAYS.slice(1))).toBe(false);
  });

  test.each([
    [],
    DEFAULT_PUBLIC_RELAYS.slice(1),
    [...DEFAULT_PUBLIC_RELAYS, 'wss://custom.example'],
    [...DEFAULT_PUBLIC_RELAYS.slice(1), 'wss://custom.example'],
    ['ws://127.0.0.1:7000'],
    ['ws://localhost:7000'],
    [...DEFAULT_PUBLIC_RELAYS, 'invalid relay'],
    DEFAULT_PUBLIC_RELAYS.map(url => url.replace('wss:', 'ws:')),
    DEFAULT_PUBLIC_RELAYS.map(url => `${url}?custom=1`),
  ].map(relays => ({ relays })))('rejects non-default set $relays', ({ relays }) => {
    expect(shouldBootstrapPublicGraph(relays)).toBe(false);
  });
});
