import { describe, expect, it, vi } from 'vitest';
import { cid, fromHex, LinkType, toHex, type CID } from '@hashtree/core';
import { nip19 } from 'nostr-tools';
import { planTreeRootMirror, planVideoEvents, selectPublicVideoRoots } from '../scripts/publish-video-events.mjs';
import { buildVideoEventTemplate } from '../src/lib/videoEvent';

const OWNER = 'a'.repeat(64);
const OWNER_NPUB = nip19.npubEncode(OWNER);
const HASH_A = '1'.repeat(64);
const HASH_B = '2'.repeat(64);

function rootEvent(treeName: string, options: { hash?: string; createdAt?: number; id?: string; extraTags?: string[][] } = {}) {
  return {
    id: options.id ?? `${treeName}-${options.createdAt ?? 100}`,
    pubkey: OWNER,
    kind: 30064,
    created_at: options.createdAt ?? 100,
    content: '',
    tags: [
      ['d', treeName],
      ['l', 'hashtree'],
      ...(options.hash === '' ? [] : [['hash', options.hash ?? HASH_A]]),
      ...(options.extraTags ?? []),
    ],
  };
}

function testCid(byte: string): CID {
  return cid(fromHex(byte.repeat(32)));
}

function fakeTree(dirs: Map<string, unknown[]>) {
  return {
    listDirectory: vi.fn(async (target: CID) => (dirs.get(toHex(target.hash)) ?? []) as never),
    readFile: vi.fn(async () => null),
  };
}

describe('selectPublicVideoRoots', () => {
  it('keeps the latest public root of each video tree', () => {
    const roots = selectPublicVideoRoots([
      rootEvent('videos/Clip', { hash: HASH_A, createdAt: 100 }),
      rootEvent('videos/Clip', { hash: HASH_B, createdAt: 200 }),
      rootEvent('videos/Another', { createdAt: 50 }),
      rootEvent('public', { createdAt: 300 }),
    ]);

    expect(roots.map((root) => [root.treeName, toHex(root.rootCid.hash), root.timestamp])).toEqual([
      ['videos/Another', HASH_A, 50],
      ['videos/Clip', HASH_B, 200],
    ]);
  });

  it('never selects private, link-only or deleted trees', () => {
    const roots = selectPublicVideoRoots([
      rootEvent('videos/Private', { extraTags: [['selfEncryptedKey', 'x']] }),
      rootEvent('videos/Link', { extraTags: [['encryptedKey', 'x']] }),
      // Was public, then deleted: the newer event without a hash wins.
      rootEvent('videos/Deleted', { createdAt: 100 }),
      rootEvent('videos/Deleted', { createdAt: 200, hash: '' }),
      // Was public, then made private.
      rootEvent('videos/WentPrivate', { createdAt: 100 }),
      rootEvent('videos/WentPrivate', { createdAt: 200, extraTags: [['selfEncryptedKey', 'x']] }),
    ]);
    expect(roots).toEqual([]);
  });
});

describe('planTreeRootMirror', () => {
  const CHANNEL = 'b'.repeat(64);

  it('copies public trees unchanged, keeping their original time', () => {
    const source = rootEvent('videos/Clip', { hash: HASH_B, createdAt: 123, extraTags: [['key', '3'.repeat(64)]] });
    expect(planTreeRootMirror([
      source,
      rootEvent('videos/Private', { extraTags: [['selfEncryptedKey', 'x']] }),
      rootEvent('videos/Deleted', { createdAt: 200, hash: '' }),
      rootEvent('public'),
    ], [])).toEqual([{ kind: source.kind, created_at: 123, tags: source.tags, content: '' }]);
  });

  it('never overwrites a tree name the receiving account has used', () => {
    const templates = planTreeRootMirror([
      rootEvent('videos/Kept'),
      rootEvent('videos/Removed'),
      rootEvent('videos/New'),
    ], [
      { ...rootEvent('videos/Kept', { hash: HASH_B }), pubkey: CHANNEL },
      { ...rootEvent('videos/Removed', { hash: '' }), pubkey: CHANNEL },
    ]);
    expect(templates.map((template) => template.tags[0][1])).toEqual(['videos/New']);
  });
});

describe('planVideoEvents', () => {
  const root = testCid('10');
  const tree = () => fakeTree(new Map([[toHex(root.hash), [
    { name: 'video.mp4', cid: testCid('11'), type: LinkType.File, meta: { title: 'Clip Title', duration: 9 } },
  ]]]));
  const roots = [{ treeName: 'videos/Clip', rootCid: root, timestamp: 1_700_000_000 }];

  it('plans an event for a video that has none', async () => {
    const { templates, stats } = await planVideoEvents(tree(), { ownerPubkey: OWNER, roots, now: 1_800_000_000 });

    expect(stats).toMatchObject({ trees: 1, videos: 1, unchanged: 0, unreadable: 0 });
    expect(templates).toHaveLength(1);
    expect(templates[0].kind).toBe(34235);
    expect(templates[0].created_at).toBe(1_800_000_000);
    expect(templates[0].tags).toContainEqual(['d', 'videos/Clip']);
    expect(templates[0].tags).toContainEqual(['title', 'Clip Title']);
    // The tree records no creation time, so the root event time is used.
    expect(templates[0].tags).toContainEqual(['published_at', '1700000000']);
  });

  it('leaves an up-to-date event alone and replaces a stale one', async () => {
    const upToDate = {
      ...buildVideoEventTemplate({
        ownerNpub: OWNER_NPUB,
        treeName: 'videos/Clip',
        title: 'Clip Title',
        duration: 9,
        publishedAt: 1_650_000_000,
        videoPath: 'video.mp4',
      }, 1_750_000_000),
      pubkey: OWNER,
    };
    const unchanged = await planVideoEvents(tree(), { ownerPubkey: OWNER, roots, existingEvents: [upToDate], now: 1_800_000_000 });
    expect(unchanged.templates).toEqual([]);
    expect(unchanged.stats.unchanged).toBe(1);

    const stale = { ...upToDate, tags: upToDate.tags.map((tag) => tag[0] === 'title' ? ['title', 'Old Title'] : tag) };
    const replaced = await planVideoEvents(tree(), { ownerPubkey: OWNER, roots, existingEvents: [stale], now: 1_700_000_000 });
    expect(replaced.templates).toHaveLength(1);
    // Newer than the event it replaces, and the original publication time is kept.
    expect(replaced.templates[0].created_at).toBe(1_750_000_001);
    expect(replaced.templates[0].tags).toContainEqual(['published_at', '1650000000']);
  });

  it('counts unreadable trees without planning anything for them', async () => {
    const { templates, stats } = await planVideoEvents(fakeTree(new Map()), { ownerPubkey: OWNER, roots });
    expect(templates).toEqual([]);
    expect(stats.unreadable).toBe(1);
    expect(stats.unreadableTrees).toEqual(['videos/Clip']);
  });
});
