import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const ensureReady = vi.fn();
const reset = vi.fn();
const isSameOriginIrisGatewayRuntime = vi.fn();

vi.mock('../src/lib/htreeDebug', () => ({
  isHtreeDebugEnabled: () => false,
  logHtreeDebug: vi.fn(),
}));

vi.mock('../src/lib/htreeRuntime', () => ({
  getHtreeRuntime: () => ({
    media: {
      ensureReady,
      reset,
    },
  }),
  isSameOriginIrisGatewayRuntime,
}));

vi.mock('../src/lib/workerInit', () => ({
  getWorkerAdapter: vi.fn(() => ({ registerMediaPort: vi.fn() })),
  waitForWorkerAdapter: vi.fn(),
}));

describe('media streaming setup', () => {
  beforeEach(() => {
    ensureReady.mockReset();
    reset.mockReset();
    isSameOriginIrisGatewayRuntime.mockReset();
    isSameOriginIrisGatewayRuntime.mockReturnValue(false);
    ensureReady.mockResolvedValue(true);
  });

  afterEach(async () => {
    const { resetMediaStreaming } = await import('../src/lib/mediaStreamingSetup');
    resetMediaStreaming();
  });

  it('treats the same-origin iris gateway as media-ready without a service worker port', async () => {
    isSameOriginIrisGatewayRuntime.mockReturnValue(true);
    const { ensureMediaStreamingReady, isMediaStreamingSetup, setupMediaStreaming } = await import('../src/lib/mediaStreamingSetup');

    await expect(ensureMediaStreamingReady()).resolves.toBe(true);
    expect(isMediaStreamingSetup()).toBe(true);
    expect(ensureReady).not.toHaveBeenCalled();

    await expect(setupMediaStreaming()).resolves.toBe(true);
    expect(ensureReady).not.toHaveBeenCalled();
  });

  it('delegates to runtime media readiness outside the iris gateway', async () => {
    const { ensureMediaStreamingReady } = await import('../src/lib/mediaStreamingSetup');

    await expect(ensureMediaStreamingReady(2, 100)).resolves.toBe(true);
    expect(ensureReady).toHaveBeenCalledWith({
      registerMediaPort: expect.any(Function),
      debug: false,
      attempts: 2,
      delayMs: 100,
    });
  });
});
