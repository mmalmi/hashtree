import { afterEach, describe, expect, it, vi } from 'vitest';
import { cid, fromHex, nhashEncode, toHex } from '@hashtree/core';
import {
  VIDEO_CATALOG_URL_KEY,
  VIDEO_CATALOG_URLS_KEY,
  canonicalizeVideoCatalogUrl,
  getDefaultVideoCatalogUrls,
  getVideoAuthorCatalogUrls,
  getVideoCatalogUrlSet,
  getSavedVideoCatalogUrls,
  loadVideoCatalog,
  parseVideoCatalogUrlList,
  parseVideoCatalogPayload,
  removeSavedVideoCatalogUrl,
  saveVideoCatalogUrl,
  searchVideoCatalogItems,
  videoCatalogFileFetchUrl,
  videoCatalogFetchUrl,
  videoCatalogItemToFeedItem,
} from '../src/lib/videoCatalog';
import { VIDEO_CATALOG_SCHEMA_V2, VIDEO_COLLECTION_MANIFEST_PATH } from '../src/lib/videoCatalogCollection';

function installLocalStorage() {
  const values = new Map<string, string>();
  const localStorage = {
    getItem: vi.fn((key: string) => values.get(key) ?? null),
    setItem: vi.fn((key: string, value: string) => {
      values.set(key, value);
    }),
    removeItem: vi.fn((key: string) => {
      values.delete(key);
    }),
    clear: vi.fn(() => values.clear()),
    key: vi.fn((index: number) => Array.from(values.keys())[index] ?? null),
    get length() {
      return values.size;
    },
  };
  vi.stubGlobal('window', { localStorage });
  return localStorage;
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe('video catalog URLs', () => {
  it('canonicalizes catalog root URLs instead of root.json files', () => {
    expect(canonicalizeVideoCatalogUrl(' htree://npub1abc/videos/root.json ')).toBe('htree://npub1abc/videos');
    expect(canonicalizeVideoCatalogUrl('https://example.test/catalog/')).toBe('https://example.test/catalog');
  });

  it('builds root.json fetch URLs for hashtree roots', () => {
    expect(videoCatalogFetchUrl('htree://npub1abc/videos')).toBe('/htree/npub1abc/videos/root.json');
    expect(videoCatalogFetchUrl('/htree/npub1abc/videos')).toBe('/htree/npub1abc/videos/root.json');
    expect(videoCatalogFetchUrl('https://example.test/catalog/root.json')).toBe('https://example.test/catalog/root.json');
    expect(videoCatalogFileFetchUrl('htree://npub1abc/videos', VIDEO_COLLECTION_MANIFEST_PATH))
      .toBe('/htree/npub1abc/videos/collections/videos/manifest.json');
  });

  it('parses deploy default and author index catalog roots', () => {
    expect(parseVideoCatalogUrlList(' htree://npub1a/videos/root.json, https://example.test/catalog/ \n htree://npub1a/videos '))
      .toEqual(['htree://npub1a/videos', 'https://example.test/catalog']);

    expect(getDefaultVideoCatalogUrls({
      VITE_DEFAULT_VIDEO_CATALOG_URLS: 'htree://npub1default/videos, https://example.test/default',
      VITE_DEFAULT_VIDEO_CATALOG_URL: 'htree://npub1default/videos',
    })).toEqual([
      'htree://npub1default/videos',
      'https://example.test/default',
    ]);

    expect(getVideoAuthorCatalogUrls('npub1author', {
      VITE_VIDEO_AUTHOR_INDEX_TREE_NAMES: 'iris-video/index, videos/index',
    })).toEqual([
      'htree://npub1author/iris-video/index',
      'htree://npub1author/videos/index',
    ]);
  });
});

describe('parseVideoCatalogPayload', () => {
  it('normalizes videos into deterministic feed items', () => {
    const rootCid = cid(fromHex('12'.repeat(32)));
    const catalog = parseVideoCatalogPayload({
      title: 'Open Videos',
      videos: [
        {
          title: 'Sats on the Beach',
          ownerNpub: 'npub10yf7k3h3nuzpgh8qcxkrux8frd0u0cjgf8p5x65a8w7kqkw0lwdq3l5g9t',
          treeName: 'videos/Sats on the Beach',
          duration: '125',
          timestamp: 1_765_000_000_123,
          href: '#/npub10yf7k3h3nuzpgh8qcxkrux8frd0u0cjgf8p5x65a8w7kqkw0lwdq3l5g9t/videos%2FSats%20on%20the%20Beach',
          nhash: nhashEncode(rootCid),
          tags: ['Bitcoin', 'Music', 'bitcoin'],
        },
      ],
    }, 'htree://npub1catalog/videos');

    expect(catalog.title).toBe('Open Videos');
    expect(catalog.videos).toHaveLength(1);
    expect(catalog.videos[0]).toMatchObject({
      title: 'Sats on the Beach',
      treeName: 'videos/Sats on the Beach',
      duration: 125,
      timestamp: 1_765_000_000,
      tags: ['bitcoin', 'music'],
      href: '#/npub10yf7k3h3nuzpgh8qcxkrux8frd0u0cjgf8p5x65a8w7kqkw0lwdq3l5g9t/videos%2FSats%20on%20the%20Beach',
    });

    expect(videoCatalogItemToFeedItem(catalog.videos[0])).toMatchObject({
      key: 'catalog:htree://npub1catalog/videos:npub10yf7k3h3nuzpgh8qcxkrux8frd0u0cjgf8p5x65a8w7kqkw0lwdq3l5g9t/videos/Sats on the Beach',
      title: 'Sats on the Beach',
      visibility: 'public',
    });
    expect(toHex(videoCatalogItemToFeedItem(catalog.videos[0]).rootCid!.hash)).toBe('12'.repeat(32));
  });

  it('accepts href-only catalog items', () => {
    const catalog = parseVideoCatalogPayload({
      items: [
        { title: 'Immutable clip', href: '#/nhash1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq9m3lx4' },
      ],
    }, 'https://example.test/video-catalog');

    expect(catalog.videos[0]).toMatchObject({
      id: 'https://example.test/video-catalog#0',
      title: 'Immutable clip',
      href: '#/nhash1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq9m3lx4',
    });
  });

  it('accepts v2 roots with inline collection manifests while keeping videos compatible', () => {
    const manifest = {
      version: 1,
      sourceId: 'npub1catalog/videos',
      schemaVersion: 2,
      updatedAt: 1,
      byIdRoot: null,
      indexes: {},
    };
    const catalog = parseVideoCatalogPayload({
      schema: VIDEO_CATALOG_SCHEMA_V2,
      collections: { videos: manifest },
      videos: [{ title: 'Indexed clip', href: '#/npub1a/videos%2Findexed' }],
    }, 'htree://npub1catalog/videos');

    expect(catalog.version).toBe(2);
    expect(catalog.collectionManifest).toBe(manifest);
    expect(catalog.videos[0].title).toBe('Indexed clip');
  });

  it('loads v2 collection manifests from the default root-relative path', async () => {
    const manifest = {
      version: 1,
      sourceId: 'npub1catalog/videos',
      schemaVersion: 2,
      updatedAt: 1,
      byIdRoot: null,
      indexes: {},
    };
    const fetcher = vi.fn(async (url: string) => ({
      ok: true,
      json: async () => url.endsWith('/root.json')
        ? {
            schema: VIDEO_CATALOG_SCHEMA_V2,
            title: 'V2 Catalog',
            collections: { videos: { manifestPath: VIDEO_COLLECTION_MANIFEST_PATH } },
          }
        : manifest,
    } as Response));

    const catalog = await loadVideoCatalog('htree://npub1catalog/videos', fetcher);

    expect(fetcher).toHaveBeenNthCalledWith(1, '/htree/npub1catalog/videos/root.json');
    expect(fetcher).toHaveBeenNthCalledWith(2, '/htree/npub1catalog/videos/collections/videos/manifest.json');
    expect(catalog.title).toBe('V2 Catalog');
    expect(catalog.collectionManifest).toEqual(manifest);
  });
});

describe('searchVideoCatalogItems', () => {
  it('ranks local catalog matches without relay queries', () => {
    const catalog = parseVideoCatalogPayload({
      videos: [
        { title: 'Cooking with Lightning', href: '#/npub1a/videos%2Fcooking', tags: ['food'] },
        { title: 'Lightning Network Notes', href: '#/npub1a/videos%2Flightning', tags: ['bitcoin'] },
        { title: 'Garden Walk', href: '#/npub1a/videos%2Fgarden', description: 'Soft rain and plants' },
      ],
    }, 'htree://npub1catalog/videos');

    const results = searchVideoCatalogItems(catalog.videos, 'lightning', 2);
    expect(results.map((item) => item.title)).toEqual([
      'Lightning Network Notes',
      'Cooking with Lightning',
    ]);
  });
});

describe('saved video catalogs', () => {
  it('maintains a primary catalog plus a deduped catalog list', () => {
    const localStorage = installLocalStorage();

    expect(saveVideoCatalogUrl('htree://npub1a/videos/root.json')).toEqual(['htree://npub1a/videos']);
    expect(saveVideoCatalogUrl('https://example.test/catalog')).toEqual([
      'https://example.test/catalog',
      'htree://npub1a/videos',
    ]);
    expect(saveVideoCatalogUrl('https://example.test/catalog/')).toEqual([
      'https://example.test/catalog',
      'htree://npub1a/videos',
    ]);

    expect(getSavedVideoCatalogUrls()).toEqual([
      'https://example.test/catalog',
      'htree://npub1a/videos',
    ]);
    expect(localStorage.setItem).toHaveBeenCalledWith(VIDEO_CATALOG_URL_KEY, 'https://example.test/catalog');
    expect(localStorage.setItem).toHaveBeenCalledWith(
      VIDEO_CATALOG_URLS_KEY,
      JSON.stringify(['https://example.test/catalog', 'htree://npub1a/videos']),
    );

    expect(removeSavedVideoCatalogUrl('https://example.test/catalog/root.json')).toEqual(['htree://npub1a/videos']);
    expect(getSavedVideoCatalogUrls()).toEqual(['htree://npub1a/videos']);
  });

  it('combines deploy default roots with user-saved roots without storing defaults', () => {
    const localStorage = installLocalStorage();
    saveVideoCatalogUrl('https://example.test/saved');

    expect(getVideoCatalogUrlSet({
      VITE_DEFAULT_VIDEO_CATALOG_URLS: 'htree://npub1default/videos, https://example.test/saved/root.json',
    })).toEqual({
      defaultUrls: ['htree://npub1default/videos', 'https://example.test/saved'],
      savedUrls: ['https://example.test/saved'],
      urls: ['htree://npub1default/videos', 'https://example.test/saved'],
    });
    expect(localStorage.setItem).not.toHaveBeenCalledWith(
      VIDEO_CATALOG_URL_KEY,
      'htree://npub1default/videos',
    );
  });
});
