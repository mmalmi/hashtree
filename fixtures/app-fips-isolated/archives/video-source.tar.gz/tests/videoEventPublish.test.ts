import { beforeEach, describe, expect, it, vi } from 'vitest';
import { cid, fromHex, LinkType, toHex, type CID } from '@hashtree/core';
import { nip19, type EventTemplate } from 'nostr-tools';

const PUBKEY = '1'.repeat(64);
const NPUB = nip19.npubEncode(PUBKEY);

const mocks = vi.hoisted(() => ({
  published: [] as Array<{ kind: number; created_at: number; tags: string[][]; content: string; pubkey: string }>,
  session: { pubkey: '' as string | null, npub: '' as string | null },
  signer: {} as object | undefined,
  secretKey: new Uint8Array(32) as Uint8Array | null,
  dirs: new Map<string, unknown[]>(),
}));

vi.mock('../src/nostr/client', () => ({
  nostr: {
    get signer() { return mocks.signer; },
    subscribe: vi.fn(),
    signEvent: vi.fn(async (template: EventTemplate) => ({ ...template, pubkey: mocks.session.pubkey ?? '' })),
    // Relays never answer in these tests: publishing must not depend on them.
    publish: vi.fn((event: (typeof mocks.published)[number]) => {
      mocks.published.push(event);
      return new Promise(() => {});
    }),
  },
}));
vi.mock('../src/nostr/store', () => ({ nostrStore: { getState: () => mocks.session } }));
vi.mock('../src/nostr/auth', () => ({ getSecretKey: () => mocks.secretKey }));
vi.mock('../src/store', () => ({
  getTree: () => ({
    listDirectory: async (target: CID) => mocks.dirs.get(toHex(target.hash)) ?? [],
    readFile: async () => null,
  }),
}));

import { deleteVideoEvents, flushVideoEventSyncs, scheduleVideoEventSync, syncVideoEvents } from '../src/lib/videoEventPublish';
import { clearVideoEvents, getVideoEventItemsForTree } from '../src/stores/videoEvents';

function testCid(byte: string): CID {
  return cid(fromHex(byte.repeat(32)));
}

function setDir(dir: CID, entries: unknown[]) {
  mocks.dirs.set(toHex(dir.hash), entries);
}

function videoFile(meta: Record<string, unknown> = {}) {
  return { name: 'video.mp4', cid: testCid('aa'), type: LinkType.File, meta: { createdAt: 1_700_000_000, ...meta } };
}

function tagValue(event: { tags: string[][] }, name: string) {
  return event.tags.find((tag) => tag[0] === name)?.[1];
}

beforeEach(() => {
  mocks.published.length = 0;
  mocks.session = { pubkey: PUBKEY, npub: NPUB };
  mocks.signer = {};
  mocks.secretKey = new Uint8Array(32);
  mocks.dirs.clear();
  clearVideoEvents();
});

describe('video event publishing', () => {
  it('announces a public video and indexes it locally', async () => {
    const root = testCid('10');
    setDir(root, [videoFile({ title: 'My Clip', duration: 12 })]);

    await expect(syncVideoEvents('videos/My Clip', root, 'public')).resolves.toBe(1);

    expect(mocks.published).toHaveLength(1);
    expect(mocks.published[0].kind).toBe(34235);
    expect(tagValue(mocks.published[0], 'd')).toBe('videos/My Clip');
    expect(tagValue(mocks.published[0], 'title')).toBe('My Clip');
    expect(tagValue(mocks.published[0], 'published_at')).toBe('1700000000');
    expect(getVideoEventItemsForTree(NPUB, 'videos/My Clip')).toHaveLength(1);
  });

  it('does not republish an unchanged video, but does publish edits with a newer timestamp', async () => {
    const root = testCid('10');
    setDir(root, [videoFile({ title: 'My Clip' })]);
    await syncVideoEvents('videos/My Clip', root, 'public');
    await expect(syncVideoEvents('videos/My Clip', root, 'public')).resolves.toBe(0);
    expect(mocks.published).toHaveLength(1);

    const edited = testCid('11');
    setDir(edited, [videoFile({ title: 'Renamed' })]);
    await expect(syncVideoEvents('videos/My Clip', edited, 'public')).resolves.toBe(1);

    expect(tagValue(mocks.published[1], 'title')).toBe('Renamed');
    expect(mocks.published[1].created_at).toBeGreaterThan(mocks.published[0].created_at - 1);
    expect(getVideoEventItemsForTree(NPUB, 'videos/My Clip')[0].title).toBe('Renamed');
  });

  it('keeps the first publication time when the tree records none', async () => {
    const root = testCid('10');
    setDir(root, [{ name: 'video.mp4', cid: testCid('aa'), type: LinkType.File, meta: { title: 'One' } }]);
    await syncVideoEvents('videos/Clip', root, 'public');
    const firstPublishedAt = tagValue(mocks.published[0], 'published_at');

    const edited = testCid('11');
    setDir(edited, [{ name: 'video.mp4', cid: testCid('aa'), type: LinkType.File, meta: { title: 'Two' } }]);
    await syncVideoEvents('videos/Clip', edited, 'public');

    expect(tagValue(mocks.published[1], 'published_at')).toBe(firstPublishedAt);
  });

  it('announces playlist items and retracts the ones removed from the tree', async () => {
    const root = testCid('20');
    const first = testCid('21');
    const second = testCid('22');
    setDir(first, [videoFile({ title: 'First' })]);
    setDir(second, [videoFile({ title: 'Second' })]);
    setDir(root, [
      { name: 'one', cid: first, type: LinkType.Dir },
      { name: 'two', cid: second, type: LinkType.Dir },
    ]);
    // Two video events, and the playlist itself as a video set other apps can read.
    await expect(syncVideoEvents('videos/Talks', root, 'public')).resolves.toBe(3);
    expect(mocks.published.filter((event) => event.kind === 34235).map((event) => tagValue(event, 'd')).sort())
      .toEqual(['videos/Talks/one', 'videos/Talks/two']);
    const set = mocks.published.at(-1)!;
    expect(set.kind).toBe(30005);
    expect(set.tags.filter((tag) => tag[0] !== 'image')).toEqual([
      ['d', 'videos/Talks'],
      ['title', 'Talks'],
      ['a', `34235:${PUBKEY}:videos/Talks/one`],
      ['a', `34235:${PUBKEY}:videos/Talks/two`],
    ]);

    const trimmed = testCid('23');
    setDir(trimmed, [{ name: 'one', cid: first, type: LinkType.Dir }]);
    // Nothing new to announce except the set, which now lists one video.
    await expect(syncVideoEvents('videos/Talks', trimmed, 'public')).resolves.toBe(1);

    const deletion = mocks.published.at(-2)!;
    expect(deletion.kind).toBe(5);
    expect(deletion.tags).toContainEqual(['a', `34235:${PUBKEY}:videos/Talks/two`]);
    const updatedSet = mocks.published.at(-1)!;
    expect(updatedSet.kind).toBe(30005);
    expect(updatedSet.tags.filter((tag) => tag[0] === 'a')).toEqual([['a', `34235:${PUBKEY}:videos/Talks/one`]]);
    expect(updatedSet.created_at).toBeGreaterThan(set.created_at);

    // The same tree again publishes nothing.
    await expect(syncVideoEvents('videos/Talks', trimmed, 'public')).resolves.toBe(0);
    expect(getVideoEventItemsForTree(NPUB, 'videos/Talks').map((item) => item.videoId)).toEqual(['one']);
  });

  it('announces a large playlist a few items per save when a signing extension would prompt for each', async () => {
    mocks.secretKey = null;
    const root = testCid('30');
    const items = Array.from({ length: 8 }, (_, index) => {
      const dir = testCid(`4${index}`);
      setDir(dir, [videoFile({ title: `Item ${index}`, createdAt: 1_700_000_000 + index })]);
      return { name: `item${index}`, cid: dir, type: LinkType.Dir };
    });
    setDir(root, items);

    await expect(syncVideoEvents('videos/Big', root, 'public')).resolves.toBe(5);
    // Newest items first, and nothing that is still unannounced is mistaken for removed.
    expect(mocks.published.map((event) => tagValue(event, 'title'))).toEqual(['Item 7', 'Item 6', 'Item 5', 'Item 4', 'Item 3']);
    expect(mocks.published.every((event) => event.kind === 34235)).toBe(true);

    // The rest, and then the playlist's video set once there is room for it.
    await expect(syncVideoEvents('videos/Big', root, 'public')).resolves.toBe(4);
    expect(mocks.published.at(-1)!.kind).toBe(30005);
    expect(mocks.published.at(-1)!.tags.filter((tag) => tag[0] === 'a')).toHaveLength(8);
    await expect(syncVideoEvents('videos/Big', root, 'public')).resolves.toBe(0);
    expect(mocks.published).toHaveLength(9);
  });

  it('never announces private or link-only videos, and retracts one that stops being public', async () => {
    const root = testCid('10');
    setDir(root, [videoFile({ title: 'Secret' })]);

    await syncVideoEvents('videos/Secret', root, 'link-visible');
    await syncVideoEvents('videos/Secret', root, 'private');
    expect(mocks.published).toHaveLength(0);

    await syncVideoEvents('videos/Secret', root, 'public');
    await syncVideoEvents('videos/Secret', root, 'private');
    expect(mocks.published.map((event) => event.kind)).toEqual([34235, 5]);
    expect(getVideoEventItemsForTree(NPUB, 'videos/Secret')).toEqual([]);
  });

  it('ignores other trees, unreadable roots and signed-out sessions', async () => {
    const root = testCid('10');
    setDir(root, [videoFile()]);

    await syncVideoEvents('public', root, 'public');
    await syncVideoEvents('videos/Missing', testCid('99'), 'public');
    mocks.signer = undefined;
    await syncVideoEvents('videos/Clip', root, 'public');
    mocks.signer = {};
    mocks.session = { pubkey: null, npub: null };
    await syncVideoEvents('videos/Clip', root, 'public');

    expect(mocks.published).toHaveLength(0);
  });

  it('collapses rapid saves of one tree into a single publish of the latest root', async () => {
    vi.useFakeTimers();
    try {
      const early = testCid('10');
      const late = testCid('11');
      setDir(early, [videoFile({ title: 'Early' })]);
      setDir(late, [videoFile({ title: 'Late' })]);

      scheduleVideoEventSync('videos/Stream', early, 'public');
      scheduleVideoEventSync('videos/Stream', late, 'public');
      await flushVideoEventSyncs();

      expect(mocks.published).toHaveLength(1);
      expect(tagValue(mocks.published[0], 'title')).toBe('Late');
    } finally {
      vi.useRealTimers();
    }
  });

  it('retracts the events of a deleted tree and cancels its pending publish', async () => {
    const root = testCid('10');
    setDir(root, [videoFile({ title: 'Gone' })]);
    await syncVideoEvents('videos/Gone', root, 'public');

    scheduleVideoEventSync('videos/Gone', root, 'public');
    await deleteVideoEvents('videos/Gone');
    await flushVideoEventSyncs();

    expect(mocks.published.map((event) => event.kind)).toEqual([34235, 5]);
    expect(mocks.published[1].tags).toContainEqual(['a', `34235:${PUBKEY}:videos/Gone`]);
    expect(getVideoEventItemsForTree(NPUB, 'videos/Gone')).toEqual([]);
  });
});
