import { beforeEach, describe, expect, it, vi } from 'vitest';
import { finalizeEvent } from 'nostr-tools';
import type { RuntimeQueryResult } from 'nostr-pubsub';
import { NewVideoHistory } from '../src/stores/newVideoHistory';

const { query, ingest } = vi.hoisted(() => ({ query: vi.fn(), ingest: vi.fn() }));
vi.mock('../src/workerAdapter', () => ({ getWorkerAdapter: () => ({ queryEvents: query }) }));
vi.mock('../src/stores/videoEvents', () => ({ ingestVideoEvent: ingest }));

const newest = finalizeEvent({ kind: 21, created_at: 150, content: 'new', tags: [] }, new Uint8Array(32).fill(7));
const older = finalizeEvent({ kind: 21, created_at: 120, content: 'older', tags: [] }, new Uint8Array(32).fill(7));
function result(events: typeof newest[], complete = true): RuntimeQueryResult {
  return { events, complete, reason: complete ? 'eose' : 'timeout', sources: [] };
}

beforeEach(() => { query.mockReset(); ingest.mockReset(); });

describe('New feed relay paging', () => {
  it('advances the answering relay while another is silent, then retries a partial page at its original boundary', async () => {
    let finishSlow!: (page: RuntimeQueryResult) => void;
    const slow = new Promise<RuntimeQueryResult>(resolve => { finishSlow = resolve; });
    query.mockResolvedValueOnce(result([newest]))
      .mockReturnValueOnce(slow).mockResolvedValueOnce(result([])).mockResolvedValueOnce(result([]));
    const pager = new NewVideoHistory(['wss://fast.test', 'wss://slow.test'], [{ kinds: [21] }]);
    const state = vi.fn();
    pager.load(state, false);
    await vi.waitFor(() => expect(state).toHaveBeenLastCalledWith('ready'));
    pager.load(state, false);
    expect(query).toHaveBeenCalledTimes(3);
    expect(query.mock.calls[2][0][0].until).toBe(newest.created_at);
    expect(query.mock.calls[2][1].relays).toEqual(['wss://fast.test']);
    finishSlow(result([older], false));
    await vi.waitFor(() => expect(state).toHaveBeenLastCalledWith('retry'));
    expect(ingest.mock.calls.map(([event]) => event.id)).toEqual([newest.id, older.id]);
    pager.load(state, true);
    expect(query.mock.calls[3][0]).toEqual(query.mock.calls[1][0]);
    await vi.waitFor(() => expect(state).toHaveBeenLastCalledWith('end'));
    pager.load(state, true);
    expect(query).toHaveBeenCalledTimes(4);
  });

  it('widens a full same-second boundary and ignores replies after the viewer leaves', async () => {
    const events = Array.from({ length: 24 }, (_, i) => finalizeEvent({
      kind: 21, created_at: 150, content: String(i), tags: [],
    }, new Uint8Array(32).fill(8)));
    query.mockResolvedValueOnce(result(events)).mockResolvedValueOnce(result(events)).mockResolvedValueOnce(result([older]));
    const pager = new NewVideoHistory(['wss://relay.test'], [{ kinds: [21] }]);
    const state = vi.fn();
    pager.load(state, false);
    await vi.waitFor(() => expect(state).toHaveBeenLastCalledWith('ready'));
    pager.load(state, false);
    await vi.waitFor(() => expect(state).toHaveBeenLastCalledWith('ready'));
    pager.load(state, false);
    expect(query.mock.calls[2][0]).toEqual([{ kinds: [21], limit: 48, until: 150 }]);
    pager.stop();
    await Promise.resolve();
    expect(ingest).not.toHaveBeenCalledWith(older);
    expect(query.mock.calls[2][1].signal.aborted).toBe(true);
  });
});
