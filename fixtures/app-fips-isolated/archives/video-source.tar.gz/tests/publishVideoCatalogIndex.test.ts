import { describe, expect, it, vi } from 'vitest';
import { cid, fromHex, LinkType, nhashEncode, toHex, type CID } from '@hashtree/core';
import { nip19 } from 'nostr-tools';
import {
  createBatchUploadPayload,
  createBlossomAuthHeader,
  expandVideoRecordsFromTrees,
} from '../scripts/publish-video-catalog-index.mjs';
import type { VideoCollectionRecord } from '../src/lib/videoCatalogCollection';

const OWNER_PUBKEY = 'a'.repeat(64);
const OWNER_NPUB = nip19.npubEncode(OWNER_PUBKEY);
const encoder = new TextEncoder();

function testCid(byte: string): CID {
  return cid(fromHex(byte.repeat(32)));
}

function cidKey(value: CID): string {
  return toHex(value.hash);
}

function record(rootCid: CID, overrides: Partial<VideoCollectionRecord> = {}): VideoCollectionRecord {
  return {
    id: `${OWNER_PUBKEY}:event-1`,
    title: 'Playlist Root',
    timestamp: 100,
    ownerPubkey: OWNER_PUBKEY,
    ownerNpub: OWNER_NPUB,
    treeName: 'videos/Playlist Root',
    href: `#/${OWNER_NPUB}/videos%2FPlaylist%20Root`,
    nhash: nhashEncode(rootCid),
    tags: [],
    sourceEvents: ['event-1'],
    provenance: [{ source: 'nostr-kind-30078', scope: 'catalog', eventId: 'event-1', authorPubkey: OWNER_PUBKEY }],
    ...overrides,
  };
}

function fakeTree(
  dirs: Map<string, unknown[]>,
  files: Map<string, Uint8Array> = new Map(),
) {
  return {
    listDirectory: vi.fn(async (target: CID) => dirs.get(cidKey(target)) ?? []),
    readFile: vi.fn(async (target: CID) => files.get(cidKey(target)) ?? null),
  };
}

describe('publish-video-catalog-index playlist expansion', () => {
  it('keeps playlist roots and indexes child video directories', async () => {
    const root = testCid('10');
    const childA = testCid('11');
    const childB = testCid('12');
    const videoA = testCid('13');
    const videoB = testCid('14');
    const thumbA = testCid('15');
    const thumbB = testCid('16');

    const tree = fakeTree(new Map([
      [cidKey(root), [
        {
          name: 'video_000001',
          cid: childA,
          type: LinkType.Dir,
          meta: {
            title: 'First Clip',
            duration: 12,
            originalDate: 1_700_000_000,
            thumbnail: nhashEncode(thumbA),
          },
        },
        { name: 'second', cid: childB, type: LinkType.Dir },
        { name: 'notes.txt', cid: testCid('17'), type: LinkType.File },
      ]],
      [cidKey(childA), [
        { name: 'video.mp4', cid: videoA, type: LinkType.File },
      ]],
      [cidKey(childB), [
        {
          name: 'video.webm',
          cid: videoB,
          type: LinkType.File,
          meta: { title: 'Second Clip', duration: 65, createdAt: 1_700_000_100 },
        },
        { name: 'thumbnail.jpg', cid: thumbB, type: LinkType.File },
      ]],
    ]));

    const result = await expandVideoRecordsFromTrees(tree, [record(root)], {
      concurrency: 2,
      readTimeoutMs: 100,
      itemLimit: 10,
    });

    expect(result.stats).toMatchObject({
      rootRecords: 1,
      playlistRoots: 1,
      playlistChildren: 2,
      unreadableRoots: 0,
    });
    expect(result.records).toHaveLength(3);

    const parent = result.records.find((entry) => entry.videoId === undefined);
    expect(parent).toMatchObject({
      title: 'Playlist Root',
      tags: ['playlist'],
      nhash: nhashEncode(root),
    });

    const first = result.records.find((entry) => entry.videoId === 'video_000001');
    expect(first).toMatchObject({
      title: 'First Clip',
      duration: 12,
      timestamp: 1_700_000_000,
      treeName: 'videos/Playlist Root',
      href: `#/${OWNER_NPUB}/videos%2FPlaylist%20Root/video_000001`,
      nhash: nhashEncode(root),
      thumbnailUrl: `/htree/${nhashEncode(thumbA)}`,
      tags: ['playlist'],
    });

    const second = result.records.find((entry) => entry.videoId === 'second');
    expect(second).toMatchObject({
      title: 'Second Clip',
      duration: 65,
      timestamp: 1_700_000_100,
      videoPath: 'video.webm',
      thumbnailUrl: `/htree/${nhashEncode(thumbB)}/thumbnail.jpg`,
    });
  });

  it('enriches single-video roots without creating child records', async () => {
    const root = testCid('20');
    const video = testCid('21');
    const thumb = testCid('22');
    const metadata = testCid('23');
    const tree = fakeTree(
      new Map([
        [cidKey(root), [
          { name: 'video.mp4', cid: video, type: LinkType.File, meta: { duration: 42 } },
          { name: 'thumbnail.png', cid: thumb, type: LinkType.File },
          { name: 'metadata.json', cid: metadata, type: LinkType.File },
        ]],
      ]),
      new Map([
        [cidKey(metadata), encoder.encode(JSON.stringify({ title: 'Single Root Video', createdAt: 1_700_000_200 }))],
      ]),
    );

    const result = await expandVideoRecordsFromTrees(tree, [record(root)], {
      concurrency: 1,
      readTimeoutMs: 100,
    });

    expect(result.stats).toMatchObject({ singleVideoRoots: 1, playlistRoots: 0 });
    expect(result.records).toHaveLength(1);
    expect(result.records[0]).toMatchObject({
      title: 'Single Root Video',
      duration: 42,
      timestamp: 1_700_000_200,
      videoPath: 'video.mp4',
      thumbnailUrl: `/htree/${nhashEncode(thumb)}/thumbnail.png`,
    });
  });
});

describe('publish-video-catalog-index batch uploads', () => {
  it('builds hashtree batch upload payloads from local store entries', () => {
    const payload = createBatchUploadPayload([
      ['11'.repeat(32), encoder.encode('one')],
      ['22'.repeat(32), encoder.encode('two')],
    ]);

    expect(payload).toEqual({
      blobs: [
        {
          sha256: '11'.repeat(32),
          content_type: 'application/octet-stream',
          data: Buffer.from('one').toString('base64'),
        },
        {
          sha256: '22'.repeat(32),
          content_type: 'application/octet-stream',
          data: Buffer.from('two').toString('base64'),
        },
      ],
    });
  });

  it('creates Blossom auth headers that authorize batched hashes', () => {
    const secretKey = new Uint8Array(32).fill(1);
    const hashes = ['AA'.repeat(32), 'bb'.repeat(32), 'AA'.repeat(32)];
    const header = createBlossomAuthHeader(secretKey, hashes);
    const [, encoded] = header.split(' ');
    const event = JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'));

    expect(header.startsWith('Nostr ')).toBe(true);
    expect(event.kind).toBe(24242);
    expect(event.tags).toContainEqual(['t', 'upload']);
    expect(event.tags).toContainEqual(['x', 'aa'.repeat(32)]);
    expect(event.tags).toContainEqual(['x', 'bb'.repeat(32)]);
    expect(event.tags.filter((tag: string[]) => tag[0] === 'x')).toHaveLength(2);
  });
});
