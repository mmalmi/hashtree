import { describe, expect, it } from 'vitest';
import { nip19 } from 'nostr-tools';
import {
  VIDEO_EVENT_KIND,
  blobMirrorUrls,
  hasBlobUrl,
  buildVideoEventDeletionTemplate,
  buildVideoEventTemplate,
  groupPlaylistVideos,
  parseExternalVideoRef,
  parseVideoEvent,
  parseVideoEventDeletion,
  parseVideoHtreeUrl,
  searchVideoItems,
  toAppHtreeUrl,
  toAppThumbnailUrl,
  toHtreeUrl,
  videoHtreeUrl,
  withoutRepeatPosts,
} from '../src/lib/videoEvent';

const PUBKEY = '1'.repeat(64);
const NPUB = nip19.npubEncode(PUBKEY);
const OTHER_NPUB = nip19.npubEncode('2'.repeat(64));

function publish(input: Parameters<typeof buildVideoEventTemplate>[0], pubkey = PUBKEY) {
  return { ...buildVideoEventTemplate(input, 1_800_000_000), pubkey, id: 'e'.repeat(64) };
}

describe('NIP-71 video events', () => {
  it('builds an addressable kind 34235 event that points into the owner tree', () => {
    const template = buildVideoEventTemplate({
      ownerNpub: NPUB,
      treeName: 'videos/Big Buck Bunny',
      title: 'Big Buck Bunny',
      description: 'A large rabbit.',
      duration: 596.4,
      publishedAt: 1_765_000_000,
      videoPath: 'video.mp4',
      thumbnailUrl: '/htree/nhash1thumb/thumbnail.jpg',
      width: 1920,
      height: 1080,
      tags: ['Animation', 'animation', 'Blender'],
    }, 1_800_000_000);

    expect(template.kind).toBe(VIDEO_EVENT_KIND);
    expect(template.content).toBe('A large rabbit.');
    expect(template.tags).toEqual([
      ['d', 'videos/Big Buck Bunny'],
      ['title', 'Big Buck Bunny'],
      ['published_at', '1765000000'],
      ['alt', 'Video: Big Buck Bunny'],
      ['duration', '596'],
      [
        'imeta',
        `url htree://${NPUB}/videos%2FBig%20Buck%20Bunny/video.mp4`,
        'm video/mp4',
        'dim 1920x1080',
        'image htree://nhash1thumb/thumbnail.jpg',
        'duration 596.4',
      ],
      ['r', `https://video.iris.to/#/${NPUB}/videos%2FBig%20Buck%20Bunny`],
      ['t', 'animation'],
      ['t', 'blender'],
    ]);
  });

  it('round-trips a single video through parse', () => {
    const item = parseVideoEvent(publish({
      ownerNpub: NPUB,
      treeName: 'videos/Big Buck Bunny',
      title: 'Big Buck Bunny',
      description: 'A large rabbit.',
      duration: 596.4,
      publishedAt: 1_765_000_000,
      videoPath: 'video.mp4',
      thumbnailUrl: 'htree://nhash1thumb/thumbnail.jpg',
      tags: ['animation'],
    }));

    expect(item).toMatchObject({
      key: `${NPUB}/videos/Big Buck Bunny`,
      title: 'Big Buck Bunny',
      description: 'A large rabbit.',
      duration: 596.4,
      timestamp: 1_765_000_000,
      updatedAt: 1_800_000_000,
      ownerPubkey: PUBKEY,
      ownerNpub: NPUB,
      treeName: 'videos/Big Buck Bunny',
      videoPath: 'video.mp4',
      thumbnailUrl: '/htree/nhash1thumb/thumbnail.jpg',
      tags: ['animation'],
      href: `#/${NPUB}/videos%2FBig%20Buck%20Bunny`,
      dTag: 'videos/Big Buck Bunny',
    });
    expect(item?.videoId).toBeUndefined();
  });

  it('keeps playlist items distinct from their tree', () => {
    const item = parseVideoEvent(publish({
      ownerNpub: NPUB,
      treeName: 'videos/Talks',
      videoId: 'Episode 1',
      title: 'Episode 1',
      videoPath: 'video.webm',
    }));

    expect(item).toMatchObject({
      key: `${NPUB}/videos/Talks/Episode 1`,
      treeName: 'videos/Talks',
      videoId: 'Episode 1',
      videoPath: 'video.webm',
      dTag: 'videos/Talks/Episode 1',
      href: `#/${NPUB}/videos%2FTalks/Episode%201`,
    });
  });

  it('falls back to created_at and the tree title when optional tags are missing', () => {
    const item = parseVideoEvent({
      kind: VIDEO_EVENT_KIND,
      pubkey: PUBKEY,
      created_at: 1_800_000_123,
      content: '',
      tags: [['d', 'x'], ['imeta', `url htree://${NPUB}/videos%2FClip/video.mp4`]],
    });
    expect(item?.title).toBe('Clip');
    expect(item?.timestamp).toBe(1_800_000_123);
    expect(item?.description).toBeUndefined();
  });

  it('ignores events that are not this author\'s hashtree videos', () => {
    const base = { kind: VIDEO_EVENT_KIND, pubkey: PUBKEY, created_at: 1, content: '' };
    // Somebody else's tree.
    expect(parseVideoEvent({ ...base, tags: [['d', 'a'], ['imeta', `url htree://${OTHER_NPUB}/videos%2FClip/video.mp4`]] })).toBeNull();
    // Not a video tree.
    expect(parseVideoEvent({ ...base, tags: [['d', 'a'], ['imeta', `url htree://${NPUB}/public/video.mp4`]] })).toBeNull();
    // No d tag, wrong kind.
    expect(parseVideoEvent({ ...base, tags: [['imeta', `url htree://${NPUB}/videos%2FClip/video.mp4`]] })).toBeNull();
    expect(parseVideoEvent({ ...base, kind: 1, tags: [['d', 'a'], ['imeta', `url htree://${NPUB}/videos%2FClip/video.mp4`]] })).toBeNull();
  });

  it('reads web-hosted videos published by other apps', () => {
    const item = parseVideoEvent({
      id: 'e'.repeat(64),
      kind: 34236,
      pubkey: PUBKEY,
      created_at: 1_800_000_000,
      content: 'A clip from somewhere else',
      tags: [
        ['d', 'clip-1'],
        ['title', 'Web Clip'],
        ['published_at', '1700000000'],
        ['imeta', 'url https://cdn.example.com/stream.m3u8', 'm application/x-mpegURL'],
        ['imeta', 'url https://cdn.example.com/abc', 'm video/mp4', 'image https://cdn.example.com/abc.jpg', 'dim 720x1280', 'duration 6.4', 'fallback https://mirror.example.com/abc.mp4'],
        ['t', 'Dance'],
      ],
    });
    expect(item).toMatchObject({
      key: `event:34236:${PUBKEY}:clip-1`,
      title: 'Web Clip',
      description: 'A clip from somewhere else',
      duration: 6.4,
      timestamp: 1_700_000_000,
      treeName: '',
      thumbnailUrl: 'https://cdn.example.com/abc.jpg',
      // The stream playlist most browsers cannot play is left out.
      videoUrls: ['https://cdn.example.com/abc', 'https://mirror.example.com/abc.mp4'],
      short: true,
      tags: ['dance'],
    });
    expect(item?.sensitive).toBeUndefined();
    // A short links to the shorts viewer.
    expect(item!.href.startsWith('#/shorts/naddr1')).toBe(true);
    expect(parseExternalVideoRef(item!.href.slice('#/shorts/'.length))).toMatchObject({
      key: item!.key, pubkey: PUBKEY, kind: 34236, dTag: 'clip-1',
    });
  });

  it('reads regular (non-addressable) video events and content warnings', () => {
    const id = 'f'.repeat(64);
    const item = parseVideoEvent({
      id,
      kind: 21,
      pubkey: PUBKEY,
      created_at: 50,
      content: 'First line is the title\nmore text',
      tags: [['url', 'https://example.com/video.mp4'], ['thumb', 'https://example.com/t.jpg'], ['content-warning', 'nsfw']],
    });
    expect(item).toMatchObject({
      key: `event:${id}`,
      title: 'First line is the title',
      dTag: '',
      thumbnailUrl: 'https://example.com/t.jpg',
      videoUrls: ['https://example.com/video.mp4'],
      sensitive: true,
    });
    expect(item?.short).toBeUndefined();
    expect(item!.href.startsWith('#/v/note1')).toBe(true);
    // Links made before the switch to the shorter form still open.
    expect(parseExternalVideoRef(nip19.neventEncode({ id, author: PUBKEY, kind: 21 }))).toMatchObject({ key: `event:${id}`, id });
    expect(parseExternalVideoRef(item!.href.slice('#/v/'.length))).toMatchObject({ key: `event:${id}`, id });
  });

  it('looks for a hash-named file on the other file servers the event mentions', () => {
    const video = 'a'.repeat(64);
    const image = 'b'.repeat(64);
    const item = parseVideoEvent({
      id: 'f'.repeat(64),
      kind: 22,
      pubkey: PUBKEY,
      created_at: 50,
      content: '',
      tags: [['imeta',
        `url https://down.example/${video}.mp4`,
        'm video/mp4',
        `image https://down.example/${image}.webp`,
        `image https://mirror.example/${image}.webp`,
        `fallback https://other.example/${video}.mp4`,
      ]],
    });
    // Declared copies first, then the same file on a server only an image named.
    expect(item?.videoUrls).toEqual([
      `https://down.example/${video}.mp4`,
      `https://other.example/${video}.mp4`,
      `https://mirror.example/${video}.mp4`,
    ]);

    // A file with an ordinary name has no copies to guess at.
    const named = parseVideoEvent({
      id: 'e'.repeat(64),
      kind: 22,
      pubkey: PUBKEY,
      created_at: 50,
      content: '',
      tags: [['imeta', 'url https://example.com/clip.mp4', `image https://mirror.example/${image}.webp`]],
    });
    expect(named?.videoUrls).toEqual(['https://example.com/clip.mp4']);
  });

  it('lists an author\'s repeat posts of one file once, keeping the earliest', () => {
    const hash = 'c'.repeat(64);
    const post = (id: string, created_at: number, pubkey = PUBKEY, url = `https://files.example/${hash}.mp4`) => parseVideoEvent({
      id: id.repeat(64),
      kind: 21,
      pubkey,
      created_at,
      content: '',
      tags: [['title', 'Same talk'], ['imeta', `url ${url}`, `x ${hash}`, 'm video/mp4']],
    })!;
    const later = post('2', 200);
    const first = post('1', 100);
    const mirrored = post('3', 300, PUBKEY, `https://other.example/${hash}.mp4`);
    const someoneElse = post('4', 50, 'd'.repeat(64));
    const plain = parseVideoEvent({
      id: '5'.repeat(64), kind: 21, pubkey: PUBKEY, created_at: 400, content: '', tags: [['url', 'https://example.com/a.mp4']],
    })!;
    expect(first.contentId).toBe(hash);
    expect(plain.contentId).toBe('https://example.com/a.mp4');
    expect(withoutRepeatPosts([later, mirrored, plain, first, someoneElse]).map((item) => item.eventId?.[0])).toEqual(['5', '1', '4']);
  });

  it('offers the author\'s other file servers for a hash-named file', async () => {
    const { parseBlobServers } = await import('../src/stores/blobServers');
    const hash = 'd'.repeat(64);
    const listed = [`https://down.example/${hash}.mp4`];
    expect(hasBlobUrl(listed)).toBe(true);
    expect(hasBlobUrl(['https://example.com/clip.mp4'])).toBe(false);
    const servers = parseBlobServers([['server', 'https://down.example/'], ['server', 'https://up.example'], ['server', 'http://plain.example'], ['server', 'nonsense'], ['r', 'https://other.example']]);
    expect(servers).toEqual(['https://down.example', 'https://up.example']);
    expect(blobMirrorUrls(listed, servers)).toEqual([`https://up.example/${hash}.mp4`]);
  });

  it('ignores events with nothing a browser can play', () => {
    const base = { id: 'a'.repeat(64), kind: 21, pubkey: PUBKEY, created_at: 1, content: '' };
    expect(parseVideoEvent({ ...base, tags: [['imeta', 'url https://example.com/live.m3u8']] })).toBeNull();
    expect(parseVideoEvent({ ...base, tags: [['imeta', 'url https://example.com/cover.jpg', 'm image/jpeg']] })).toBeNull();
    expect(parseVideoEvent({ ...base, tags: [['imeta', 'url javascript:alert(1)']] })).toBeNull();
    expect(parseVideoEvent({ ...base, tags: [] })).toBeNull();
    // A regular event needs its id to be addressed.
    expect(parseVideoEvent({ ...base, id: undefined, tags: [['url', 'https://example.com/video.mp4']] })).toBeNull();
    expect(parseExternalVideoRef('not-a-ref')).toBeNull();
  });

  it('gives a thumbnail named only by its hash an image file name', () => {
    const nhash = `nhash1${'q'.repeat(52)}`;
    expect(toAppThumbnailUrl(`htree://${nhash}`)).toBe(`/htree/${nhash}/thumbnail.jpg`);
    expect(toAppThumbnailUrl(`htree://${nhash}/cover.png`)).toBe(`/htree/${nhash}/cover.png`);
    expect(toAppThumbnailUrl(`htree://${NPUB}/videos%2FClip/thumbnail.jpg`)).toBe(`/htree/${NPUB}/videos%2FClip/thumbnail.jpg`);
    expect(toAppThumbnailUrl('https://example.com/t.jpg')).toBeUndefined();
  });

  it('drops thumbnails that are not hashtree URLs', () => {
    const item = parseVideoEvent({
      kind: VIDEO_EVENT_KIND,
      pubkey: PUBKEY,
      created_at: 1,
      content: '',
      tags: [['d', 'a'], ['imeta', `url htree://${NPUB}/videos%2FClip/video.mp4`, 'image https://tracker.example/pixel.jpg']],
    });
    expect(item?.thumbnailUrl).toBeUndefined();
  });

  it('truncates long summaries', () => {
    const template = buildVideoEventTemplate({ ownerNpub: NPUB, treeName: 'videos/Long', title: 'Long', description: 'x'.repeat(5000) });
    expect(template.content).toHaveLength(1200);
  });

  it('converts between portable and app-relative hashtree URLs', () => {
    expect(toHtreeUrl('/htree/nhash1abc/thumbnail.jpg')).toBe('htree://nhash1abc/thumbnail.jpg');
    expect(toHtreeUrl('https://video.iris.to/htree/nhash1abc/thumbnail.jpg?v=1')).toBe('htree://nhash1abc/thumbnail.jpg');
    expect(toHtreeUrl('https://example.com/thumbnail.jpg')).toBeUndefined();
    expect(toAppHtreeUrl('htree://nhash1abc/thumbnail.jpg')).toBe('/htree/nhash1abc/thumbnail.jpg');
    expect(parseVideoHtreeUrl(videoHtreeUrl(NPUB, 'videos/A/B', 'item 1', 'video.mp4'))).toEqual({
      ownerNpub: NPUB,
      treeName: 'videos/A/B',
      videoId: 'item 1',
      videoPath: 'video.mp4',
    });
  });

  it('builds and parses owner deletion requests', () => {
    const deletion = { ...buildVideoEventDeletionTemplate(PUBKEY, ['videos/A', 'videos/P/item:1'], 5), pubkey: PUBKEY };
    expect(deletion.kind).toBe(5);
    expect(deletion.tags).toEqual([
      ['a', `34235:${PUBKEY}:videos/A`],
      ['a', `34235:${PUBKEY}:videos/P/item:1`],
      ['k', '34235'],
    ]);
    expect(parseVideoEventDeletion(deletion)).toEqual(['videos/A', 'videos/P/item:1']);
    // A deletion signed by someone else names no videos of theirs.
    expect(parseVideoEventDeletion({ ...deletion, pubkey: '2'.repeat(64) })).toEqual([]);
  });
});

describe('groupPlaylistVideos', () => {
  const item = (treeName: string, videoId?: string, extra: Record<string, unknown> = {}) => ({
    key: videoId ? `npub1owner/${treeName}/${videoId}` : `npub1owner/${treeName}`,
    title: videoId ?? treeName.slice(7),
    ownerNpub: 'npub1owner',
    treeName,
    videoId,
    href: `#/npub1owner/${encodeURIComponent(treeName)}${videoId ? `/${videoId}` : ''}`,
    ...extra,
  });

  it('lists a playlist once, where its newest item was', () => {
    const listed = groupPlaylistVideos([
      item('videos/Solo'),
      item('videos/Talks', 'three', { thumbnailUrl: '/htree/nhash1x/thumbnail.jpg', duration: 30, videoPath: 'video.mp4' }),
      item('videos/Other'),
      item('videos/Talks', 'two'),
      item('videos/Talks', 'one'),
    ]);

    expect(listed.map((video) => [video.title, video.videoCount])).toEqual([
      ['Solo', undefined],
      ['Talks', 3],
      ['Other', undefined],
    ]);
    expect(listed[1]).toMatchObject({
      key: 'npub1owner/videos/Talks',
      href: '#/npub1owner/videos%2FTalks',
      thumbnailUrl: '/htree/nhash1x/thumbnail.jpg',
      videoId: undefined,
      duration: undefined,
      videoPath: undefined,
    });
  });

  it('keeps a lone playlist item and same-named trees of other owners as they are', () => {
    const lone = item('videos/Talks', 'one');
    const other = { ...item('videos/Talks', 'one'), ownerNpub: 'npub1other', key: 'npub1other/videos/Talks/one' };
    expect(groupPlaylistVideos([lone, other])).toEqual([lone, other]);
  });
});

describe('searchVideoItems', () => {
  const items = [
    { title: 'Rust for beginners', timestamp: 10, tags: ['programming'] },
    { title: 'Advanced Rust', timestamp: 30, description: 'lifetimes for experts' },
    { title: 'Cooking pasta', timestamp: 20, description: 'no rust on this pan' },
    { title: 'Rust', timestamp: 5 },
  ];

  it('ranks exact, prefix and substring title matches before other fields, then newest', () => {
    expect(searchVideoItems(items, 'rust').map((item) => item.title)).toEqual([
      'Rust',
      'Rust for beginners',
      'Advanced Rust',
      'Cooking pasta',
    ]);
  });

  it('requires every term to match', () => {
    expect(searchVideoItems(items, 'rust beginners').map((item) => item.title)).toEqual(['Rust for beginners']);
    expect(searchVideoItems(items, 'rust programming').map((item) => item.title)).toEqual(['Rust for beginners']);
    expect(searchVideoItems(items, 'rust zebra')).toEqual([]);
  });

  it('ignores filler words and punctuation in the query', () => {
    expect(searchVideoItems(items, 'the')).toEqual([]);
    expect(searchVideoItems(items, 'a')).toEqual([]);
    expect(searchVideoItems(items, 'the pasta!').map((item) => item.title)).toEqual(['Cooking pasta']);
    expect(searchVideoItems(items, 'rust-beginners').map((item) => item.title)).toEqual(['Rust for beginners']);
  });

  it('returns nothing for an empty query and honours the limit', () => {
    expect(searchVideoItems(items, '   ')).toEqual([]);
    expect(searchVideoItems(items, 'rust', 2)).toHaveLength(2);
  });
});
