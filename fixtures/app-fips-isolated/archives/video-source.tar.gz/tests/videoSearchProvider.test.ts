import { beforeEach, describe, expect, it, vi } from 'vitest';

const { searchVideosMock, searchRelaysMock } = vi.hoisted(() => ({
  searchVideosMock: vi.fn(),
  searchRelaysMock: vi.fn(),
}));

vi.mock('../src/stores/videoFeed', () => ({
  searchVideoFeed: searchVideosMock,
  searchRelaysForVideos: searchRelaysMock,
}));

import { videoProvider } from '../src/lib/search/videoProvider';

describe('videoProvider', () => {
  beforeEach(() => {
    searchVideosMock.mockReset();
  });

  it('maps indexed videos to navigable search results', async () => {
    searchVideosMock.mockReturnValue([
      {
        key: 'npub1owner/videos/My Playlist/Episode 1',
        title: 'Episode 1',
        duration: 3725,
        ownerPubkey: '2'.repeat(64),
        ownerNpub: 'npub1owner',
        treeName: 'videos/My Playlist',
        videoId: 'Episode 1',
        href: '#/npub1owner/videos%2FMy%20Playlist/Episode%201',
        timestamp: 7,
      },
    ]);

    const results = await videoProvider.search('episode', 5);

    expect(searchVideosMock).toHaveBeenCalledWith('episode', 5);
    // The relays are asked too; their matches join the index later.
    expect(searchRelaysMock).toHaveBeenCalledWith('episode');
    expect(results).toEqual([{
      id: 'video:npub1owner/videos/My Playlist/Episode 1',
      type: 'video',
      label: 'Episode 1',
      sublabel: '1:02:05',
      path: '/npub1owner/videos%2FMy%20Playlist/Episode%201',
      score: 1,
      icon: 'i-lucide-play-circle',
      pubkey: '2'.repeat(64),
      timestamp: 7,
    }]);
  });

  it('omits the duration label when it is unknown', async () => {
    searchVideosMock.mockReturnValue([
      { key: 'k', title: 'Clip', ownerPubkey: null, ownerNpub: null, treeName: 'videos/Clip', href: '#/npub1x/videos%2FClip' },
    ]);
    const [result] = await videoProvider.search('clip', 5);
    expect(result.sublabel).toBeUndefined();
    expect(result.pubkey).toBeUndefined();
  });
});
