import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { DEFAULT_IMGPROXY_CONFIG, generateProxyUrl } from '../src/utils/imgproxy';

const IMAGE = 'https://media.example.com/a b/thumb.jpg?x=1';

function expectedUrl(path: string, config = DEFAULT_IMGPROXY_CONFIG): string {
  const signature = createHmac('sha256', Buffer.from(config.key, 'hex'))
    .update(Buffer.concat([Buffer.from(config.salt, 'hex'), Buffer.from(path)]))
    .digest('base64url');
  return `${config.url}/${signature}${path}`;
}

describe('image proxy URLs', () => {
  it('signs on the first call, so an image never loads from its own host first', () => {
    const encoded = Buffer.from(IMAGE).toString('base64url');
    expect(generateProxyUrl(IMAGE, { width: 640, height: 360, square: true }))
      .toBe(expectedUrl(`/rs:fill:640:360/dpr:2/${encoded}`));
    expect(generateProxyUrl(IMAGE, { width: 80 })).toBe(expectedUrl(`/rs:fit:80:80/dpr:2/${encoded}`));
    expect(generateProxyUrl(IMAGE)).toBe(expectedUrl(`/dpr:2/${encoded}`));
  });

  it('signs for the configured proxy and does not reuse another proxy\'s URL', () => {
    const custom = { url: 'https://proxy.example.org/', key: 'aa'.repeat(32), salt: 'bb'.repeat(32) };
    const encoded = Buffer.from(IMAGE).toString('base64url');
    const viaDefault = generateProxyUrl(IMAGE, { width: 100 });
    const viaCustom = generateProxyUrl(IMAGE, { width: 100 }, custom);
    expect(viaCustom).toBe(expectedUrl(`/rs:fit:100:100/dpr:2/${encoded}`, { ...custom, url: 'https://proxy.example.org' }));
    expect(viaCustom).not.toBe(viaDefault);
  });

  it('leaves alone what the proxy cannot or need not fetch', () => {
    const proxied = generateProxyUrl(IMAGE);
    expect(generateProxyUrl(proxied)).toBe(proxied);
    for (const url of ['data:image/png;base64,AAAA', 'blob:https://x/1', '/htree/nhash1abc/thumbnail.jpg', 'htree://nhash1abc/t.jpg', 'not a url']) {
      expect(generateProxyUrl(url)).toBe(url);
    }
    // A malformed key falls back to the original rather than a broken proxy URL.
    expect(generateProxyUrl(IMAGE, {}, { url: 'https://p.example', key: 'zz', salt: 'zz' })).toBe(IMAGE);
  });
});
