import { describe, expect, it } from 'vitest';
import {
  VIDEO_SET_KIND,
  buildVideoSetDeletionTemplate,
  buildVideoSetTemplate,
  parseVideoSet,
  parseVideoSetDeletion,
  parseVideoSetRef,
  sameVideoSet,
  videoSetKey,
} from '../src/lib/videoSet';

const PUBKEY = '1'.repeat(64);
const OTHER = '2'.repeat(64);
const ID = 'a'.repeat(64);

describe('video sets (NIP-51 kind 30005)', () => {
  it('reads a set another app published: title, description and its videos in order', () => {
    const set = parseVideoSet({
      kind: VIDEO_SET_KIND,
      pubkey: PUBKEY,
      created_at: 100,
      tags: [
        ['d', 'list_1'],
        ['title', 'Cats'],
        ['description', 'all cats welcome'],
        ['playorder', 'chronological'],
        ['e', ID],
        ['a', `34236:${OTHER}:clip`],
        ['e', ID],
        ['e', 'not-an-id'],
        ['a', 'nonsense'],
      ],
    })!;
    expect(set).toMatchObject({
      key: `set:30005:${PUBKEY}:list_1`,
      dTag: 'list_1',
      title: 'Cats',
      description: 'all cats welcome',
      refs: [ID, `34236:${OTHER}:clip`],
      updatedAt: 100,
    });
    expect(set.href.startsWith('#/list/naddr1')).toBe(true);
    expect(parseVideoSetRef(set.href.slice('#/list/'.length))).toEqual({ key: set.key, pubkey: PUBKEY, dTag: 'list_1' });
    expect(parseVideoSetRef('npub1nope')).toBeNull();
  });

  it('ignores other kinds, sets without an identifier and sets without videos', () => {
    const base = { pubkey: PUBKEY, created_at: 1 };
    expect(parseVideoSet({ ...base, kind: 30004, tags: [['d', 'x'], ['e', ID]] })).toBeNull();
    expect(parseVideoSet({ ...base, kind: VIDEO_SET_KIND, tags: [['e', ID]] })).toBeNull();
    expect(parseVideoSet({ ...base, kind: VIDEO_SET_KIND, tags: [['d', 'x'], ['title', 'Empty']] })).toBeNull();
    // No title: the identifier stands in.
    expect(parseVideoSet({ ...base, kind: VIDEO_SET_KIND, tags: [['d', 'x'], ['e', ID]] })?.title).toBe('x');
  });

  it('announces a playlist as a set and round-trips it', () => {
    const template = buildVideoSetTemplate({
      dTag: 'videos/Talks',
      title: 'Talks',
      image: 'htree://nhash1abc/thumbnail.jpg',
      addresses: [`34235:${PUBKEY}:videos/Talks/one`, `34235:${PUBKEY}:videos/Talks/two`],
    }, 50);
    expect(template).toEqual({
      kind: 30005,
      created_at: 50,
      content: '',
      tags: [
        ['d', 'videos/Talks'],
        ['title', 'Talks'],
        ['image', 'htree://nhash1abc/thumbnail.jpg'],
        ['a', `34235:${PUBKEY}:videos/Talks/one`],
        ['a', `34235:${PUBKEY}:videos/Talks/two`],
      ],
    });
    const parsed = parseVideoSet({ ...template, pubkey: PUBKEY })!;
    expect(parsed.key).toBe(videoSetKey(PUBKEY, 'videos/Talks'));
    expect(sameVideoSet(parsed, parseVideoSet({ ...template, created_at: 99, pubkey: PUBKEY })!)).toBe(true);
    const reordered = buildVideoSetTemplate({ dTag: 'videos/Talks', title: 'Talks', addresses: [...parsed.refs].reverse() }, 60);
    expect(sameVideoSet(parsed, parseVideoSet({ ...reordered, pubkey: PUBKEY })!)).toBe(false);
  });

  it('lets only the owner delete their sets', () => {
    const deletion = buildVideoSetDeletionTemplate(PUBKEY, ['videos/Talks'], 70);
    expect(deletion.tags).toEqual([['a', `30005:${PUBKEY}:videos/Talks`], ['k', '30005']]);
    expect(parseVideoSetDeletion({ ...deletion, pubkey: PUBKEY })).toEqual(['videos/Talks']);
    expect(parseVideoSetDeletion({ ...deletion, pubkey: OTHER })).toEqual([]);
  });
});
