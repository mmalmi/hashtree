import { beforeEach, describe, expect, it, vi } from 'vitest';
import { get } from 'svelte/store';
import { nip19 } from 'nostr-tools';

const { subscribeMock } = vi.hoisted(() => ({ subscribeMock: vi.fn() }));
vi.mock('../src/nostr/client', () => ({ nostr: { subscribe: subscribeMock } }));

import { buildVideoEventDeletionTemplate, buildVideoEventTemplate } from '../src/lib/videoEvent';
import {
  clearVideoEvents,
  getVideoEventItemsForTree,
  getVideoEventsByAuthor,
  ingestVideoEvent,
  removeVideosByTree,
  subscribeVideoEvents,
  videoEventsStore,
} from '../src/stores/videoEvents';

const ALICE = '1'.repeat(64);
const BOB = '2'.repeat(64);
const ALICE_NPUB = nip19.npubEncode(ALICE);

function videoEvent(pubkey: string, treeName: string, options: {
  createdAt?: number;
  title?: string;
  videoId?: string;
  publishedAt?: number;
  description?: string;
} = {}) {
  return {
    ...buildVideoEventTemplate({
      ownerNpub: nip19.npubEncode(pubkey),
      treeName,
      videoId: options.videoId,
      title: options.title ?? treeName.slice('videos/'.length),
      description: options.description,
      publishedAt: options.publishedAt ?? 100,
      videoPath: 'video.mp4',
    }, options.createdAt ?? 100),
    pubkey,
  };
}

function flushedTitles(): string[] {
  vi.runAllTimers();
  return get(videoEventsStore).map((video) => video.title);
}

beforeEach(() => {
  vi.useFakeTimers();
  clearVideoEvents();
  subscribeMock.mockReset();
});

describe('video events index', () => {
  it('lists announced videos newest first', () => {
    ingestVideoEvent(videoEvent(ALICE, 'videos/Old', { publishedAt: 10 }));
    ingestVideoEvent(videoEvent(BOB, 'videos/New', { publishedAt: 30 }));
    ingestVideoEvent(videoEvent(ALICE, 'videos/Middle', { publishedAt: 20 }));

    expect(flushedTitles()).toEqual(['New', 'Middle', 'Old']);
    expect(get(videoEventsStore)[1]).toMatchObject({
      key: `${ALICE_NPUB}/videos/Middle`,
      ownerPubkey: ALICE,
      treeName: 'videos/Middle',
      href: `#/${ALICE_NPUB}/videos%2FMiddle`,
      visibility: 'public',
    });
  });

  it('keeps only the newest version of an addressable event', () => {
    expect(ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { title: 'Second', createdAt: 200 }))).toBe(true);
    expect(ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { title: 'First', createdAt: 100 }))).toBe(false);
    expect(ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { title: 'Third', createdAt: 300 }))).toBe(true);
    expect(flushedTitles()).toEqual(['Third']);
  });

  it('honours owner deletion requests and ignores replays of the deleted version', () => {
    ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { createdAt: 100 }));
    ingestVideoEvent(videoEvent(BOB, 'videos/Clip', { createdAt: 100 }));

    // Bob cannot delete Alice's video.
    ingestVideoEvent({ ...buildVideoEventDeletionTemplate(ALICE, ['videos/Clip'], 150), pubkey: BOB });
    expect(flushedTitles()).toHaveLength(2);

    expect(ingestVideoEvent({ ...buildVideoEventDeletionTemplate(ALICE, ['videos/Clip'], 150), pubkey: ALICE })).toBe(true);
    vi.runAllTimers();
    expect(get(videoEventsStore).map((video) => video.ownerPubkey)).toEqual([BOB]);

    expect(ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { createdAt: 120 }))).toBe(false);
    // Re-uploading later brings it back.
    expect(ingestVideoEvent(videoEvent(ALICE, 'videos/Clip', { createdAt: 200 }))).toBe(true);
  });

  it('removes a tree with its playlist items without touching similarly named trees', () => {
    ingestVideoEvent(videoEvent(ALICE, 'videos/Talks', { videoId: 'one' }));
    ingestVideoEvent(videoEvent(ALICE, 'videos/Talks', { videoId: 'two' }));
    ingestVideoEvent(videoEvent(ALICE, 'videos/Talks 2'));
    ingestVideoEvent(videoEvent(BOB, 'videos/Talks'));
    expect(getVideoEventItemsForTree(ALICE_NPUB, 'videos/Talks').map((item) => item.dTag).sort())
      .toEqual(['videos/Talks/one', 'videos/Talks/two']);

    removeVideosByTree(ALICE_NPUB, 'videos/Talks');

    expect(get(videoEventsStore).map((video) => `${video.ownerPubkey?.[0]}:${video.treeName}`).sort())
      .toEqual(['1:videos/Talks 2', '2:videos/Talks']);
  });

  it('filters by author', () => {
    ingestVideoEvent(videoEvent(ALICE, 'videos/A'));
    ingestVideoEvent(videoEvent(BOB, 'videos/B'));
    expect(getVideoEventsByAuthor(ALICE).map((video) => video.title)).toEqual(['A']);
    expect(getVideoEventsByAuthor(ALICE_NPUB).map((video) => video.title)).toEqual(['A']);
    expect(getVideoEventsByAuthor(null)).toEqual([]);
  });

  it('subscribes to video events and deletions for the given authors', () => {
    const handlers: Record<string, (value?: unknown) => void> = {};
    const stop = vi.fn();
    subscribeMock.mockReturnValue({
      on(name: string, handler: (value?: unknown) => void) { handlers[name] = handler; return this; },
      stop,
    });

    const unsubscribe = subscribeVideoEvents([ALICE, BOB]);

    expect(subscribeMock).toHaveBeenCalledWith([
      { kinds: [34235, 34236, 21, 22], authors: [ALICE, BOB] },
      { kinds: [5], authors: [ALICE, BOB], '#k': ['34235', '34236', '21', '22'] },
    ]);

    handlers.event(videoEvent(ALICE, 'videos/Live'));
    expect(flushedTitles()).toEqual(['Live']);

    unsubscribe();
    expect(stop).toHaveBeenCalledTimes(1);
    // Loaded videos stay available after the subscription ends.
    expect(get(videoEventsStore)).toHaveLength(1);
  });

  it('does not subscribe without authors', () => {
    subscribeVideoEvents([])();
    expect(subscribeMock).not.toHaveBeenCalled();
  });
});
