import { describe, expect, it } from 'vitest';
import { actorTrust, authorTrust, freshness, mixDiscoveryVideos, orderRelatedVideos, rankVideos } from '../src/lib/videoRanking';

const NOW = 1_800_000_000;
const DAY = 86400;
const FRIEND = 'f'.repeat(64);
const FRIEND_OF_FRIEND = 'e'.repeat(64);
const STRANGER = '0'.repeat(64);

const distances: Record<string, number> = { [FRIEND]: 1, [FRIEND_OF_FRIEND]: 2 };
const context = { now: NOW, followDistance: (pubkey: string) => distances[pubkey] ?? 1000 };

function video(key: string, ownerPubkey: string, ageDays = 0, title = key) {
  return { key, title, ownerPubkey, timestamp: NOW - ageDays * DAY };
}

describe('video ranking', () => {
  it('makes room in Hot for ranked videos outside direct follows and emits each video once', () => {
    const mix = (items: string[]) => mixDiscoveryVideos(items, (item) => item.startsWith('f'));
    expect(mix(['f1', 'f2', 'f3', 'f4', 'f5', 'a', 'b']))
      .toEqual(['f1', 'f2', 'a', 'f3', 'f4', 'b', 'f5']);
    expect(mix(['a', 'f1', 'b', 'f2', 'f3'])).toEqual(['a', 'f1', 'b', 'f2', 'f3']);
    expect(mix(['f1', 'f2', 'f3'])).toEqual(['f1', 'f2', 'f3']);
  });

  it('weighs trust by follow distance and halves freshness every two weeks', () => {
    expect([0, 1, 2, 3, 4, 1000].map(authorTrust)).toEqual([2.5, 2.5, 1.5, 0.75, 0, 0]);
    expect([1, 2, 3, 1000].map(actorTrust)).toEqual([1.4, 0.5, 0.2, 0.05]);
    expect(freshness(0)).toBe(2.5);
    expect(freshness(14 * DAY)).toBe(1.25);
    expect(freshness(-5)).toBe(2.5);
  });

  it('puts the viewer\'s network ahead of fresher videos by strangers', () => {
    const ranked = rankVideos([
      video('stranger-new', STRANGER, 0),
      video('fof-week', FRIEND_OF_FRIEND, 7),
      video('friend-old', FRIEND, 60),
    ], context);
    expect(ranked.map((entry) => entry.key)).toEqual(['friend-old', 'fof-week', 'stranger-new']);
  });

  it('lifts what the network engaged with', () => {
    const videos = [video('quiet', FRIEND_OF_FRIEND, 1), video('liked', FRIEND_OF_FRIEND, 20)];
    expect(rankVideos(videos, context).map((entry) => entry.key)).toEqual(['quiet', 'liked']);
    const engagement = (entry: { key: string }) => (entry.key === 'liked' ? 4.2 : 0);
    expect(rankVideos(videos, { ...context, engagement }).map((entry) => entry.key)).toEqual(['liked', 'quiet']);
  });

  it('keeps one author from filling the top of the page', () => {
    const ranked = rankVideos([
      video('friend-1', FRIEND, 0),
      video('friend-2', FRIEND, 1),
      video('friend-3', FRIEND, 2),
      video('fof-1', FRIEND_OF_FRIEND, 0),
    ], context);
    expect(ranked.map((entry) => entry.key)).toEqual(['friend-1', 'friend-2', 'fof-1', 'friend-3']);
  });

  it('sinks repeated titles below the best copy', () => {
    const ranked = rankVideos([
      video('copy', FRIEND_OF_FRIEND, 0, 'Same  Title!'),
      video('original', FRIEND, 5, 'same title'),
      video('other', FRIEND, 30, 'Something else'),
    ], context);
    expect(ranked.map((entry) => entry.key)).toEqual(['original', 'other', 'copy']);
  });

  it('lets search relevance outweigh trust and is stable for ties', () => {
    const relevance = (entry: { key: string }) => (entry.key === 'stranger-match' ? 1 : 0.2);
    const ranked = rankVideos([
      video('friend-weak', FRIEND, 0),
      video('stranger-match', STRANGER, 300),
    ], { ...context, relevance });
    expect(ranked.map((entry) => entry.key)).toEqual(['stranger-match', 'friend-weak']);

    const tied = [video('b', STRANGER, 1), video('a', STRANGER, 1)];
    expect(rankVideos(tied, context).map((entry) => entry.key)).toEqual(['a', 'b']);
    expect(rankVideos([...tied].reverse(), context).map((entry) => entry.key)).toEqual(['a', 'b']);
  });
});

describe('related videos', () => {
  const entry = (key: string, ownerPubkey: string, title = key, tags: string[] = []) => ({ key, ownerPubkey, title, tags });
  const current = entry('now', FRIEND, 'Mountain biking in Finland', ['biking', 'finland']);

  it('lists a few more from the same author, then the same topic, then the feed order', () => {
    const feed = [
      entry('feed-1', STRANGER),
      entry('same-tags', STRANGER, 'Trail day', ['biking', 'finland']),
      entry('author-1', FRIEND),
      entry('same-words', STRANGER, 'Biking in Finland during winter'),
      entry('author-2', FRIEND),
      entry('author-3', FRIEND),
      entry('author-4', FRIEND),
      entry('feed-2', STRANGER),
    ];
    expect(orderRelatedVideos(current, feed).map((video) => video.key)).toEqual([
      'author-1', 'author-2', 'author-3', 'same-tags', 'same-words', 'author-4', 'feed-1', 'feed-2',
    ]);
  });

  it('puts watched videos last and keeps the feed order when nothing is playing', () => {
    const feed = [entry('a', FRIEND), entry('b', STRANGER), entry('c', STRANGER)];
    expect(orderRelatedVideos(current, feed, (video) => video.key === 'a').map((video) => video.key)).toEqual(['b', 'c', 'a']);
    expect(orderRelatedVideos(null, feed).map((video) => video.key)).toEqual(['a', 'b', 'c']);
  });
});
