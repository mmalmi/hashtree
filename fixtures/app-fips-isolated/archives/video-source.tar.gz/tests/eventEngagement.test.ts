import { describe, expect, it } from 'vitest';
import {
  EngagementTally,
  commentTemplate,
  deletionTemplate,
  engagementAddress,
  engagementFilters,
  isReplyNote,
  reactionTemplate,
  threadComments,
} from '../src/lib/eventEngagement';

const AUTHOR = 'a'.repeat(64);
const ALICE = 'b'.repeat(64);
const BOB = 'c'.repeat(64);
const ID = '1'.repeat(64);

const regular = { kind: 22, pubkey: AUTHOR, id: ID };
const addressable = { kind: 34236, pubkey: AUTHOR, id: ID, dTag: 'clip' };
const ADDRESS = `34236:${AUTHOR}:clip`;

function event(id: string, kind: number, pubkey: string, content: string, created_at: number) {
  return { id, kind, pubkey, content, created_at };
}

describe('reply notes as comments', () => {
  const note = (id: string, tags: string[][], content = 'hi') => ({ id, kind: 1, pubkey: ALICE, content, created_at: 10, tags });

  it('reads a note that replies to the video, directly or within its thread, as a comment', () => {
    const tally = new EngagementTally(regular);
    expect(tally.add(note('n1', [['e', ID, 'wss://relay.example', 'root']]))).toBe(true);
    expect(tally.add(note('n2', [['e', ID, '', 'root'], ['e', 'f'.repeat(64), '', 'reply']]))).toBe(true);
    // Older apps do not mark the tag at all.
    expect(tally.add(note('n3', [['e', ID]]))).toBe(true);
    expect(tally.comments.map((comment) => comment.id).sort()).toEqual(['n1', 'n2', 'n3']);
  });

  it('leaves out notes that only mention or quote the video, or answer something else', () => {
    const tally = new EngagementTally(regular);
    expect(tally.add(note('m1', [['e', ID, '', 'mention']]))).toBe(false);
    expect(tally.add(note('q1', [['q', ID]]))).toBe(false);
    expect(tally.add(note('o1', [['e', 'f'.repeat(64), '', 'root']]))).toBe(false);
    expect(tally.comments).toEqual([]);
    expect(isReplyNote(note('a1', [['a', ADDRESS, '', 'root']]), addressable)).toBe(true);
    expect(isReplyNote(note('a2', [['a', ADDRESS, '', 'root']]), regular)).toBe(false);
  });
});

describe('comment threads', () => {
  const note = (id: string, created_at: number, tags: string[][]) => ({ id, kind: 1, pubkey: ALICE, content: id, created_at, tags });
  const comment = (id: string, created_at: number, tags: string[][]) => ({ id, kind: 1111, pubkey: BOB, content: id, created_at, tags });

  it('puts replies under the comment they answer, oldest first, with the newest comment on top', () => {
    const tally = new EngagementTally(regular);
    // A reply-note thread: a, a reply to a, and a reply to that reply.
    tally.add(note('a', 10, [['e', ID, '', 'root']]));
    tally.add(note('a2', 30, [['e', ID, '', 'root'], ['e', 'a1', '', 'reply']]));
    tally.add(note('a1', 20, [['e', ID, '', 'root'], ['e', 'a', '', 'reply']]));
    // A NIP-22 thread: b, and a reply naming b as its parent.
    tally.add(comment('b', 40, [['E', ID], ['K', '22'], ['e', ID], ['k', '22']]));
    tally.add(comment('b1', 50, [['E', ID], ['K', '22'], ['e', 'b'], ['k', '1111']]));
    // Its parent never arrived: listed on its own.
    tally.add(note('orphan', 5, [['e', ID, '', 'root'], ['e', 'missing', '', 'reply']]));

    const threads = threadComments(tally.comments);
    expect(threads.map((thread) => [thread.comment.id, thread.replies.map((reply) => reply.id)])).toEqual([
      ['b', ['b1']],
      ['a', ['a1', 'a2']],
      ['orphan', []],
    ]);
    expect(threadComments([])).toEqual([]);
  });

  it('answers a comment in the form it was written in', () => {
    const parentComment = { id: 'p'.repeat(64), pubkey: BOB, content: 'x', createdAt: 1, kind: 1111 };
    expect(commentTemplate(regular, 'me too', 100, parentComment)).toEqual({
      kind: 1111,
      created_at: 100,
      content: 'me too',
      tags: [['E', ID, '', AUTHOR], ['K', '22'], ['P', AUTHOR], ['e', parentComment.id, '', BOB], ['k', '1111'], ['p', BOB]],
    });
    // A reply note is answered with a reply note: NIP-22 comments do not answer kind 1.
    const parentNote = { ...parentComment, kind: 1 };
    expect(commentTemplate(regular, 'me too', 100, parentNote)).toEqual({
      kind: 1,
      created_at: 100,
      content: 'me too',
      tags: [['e', ID, '', 'root', AUTHOR], ['e', parentNote.id, '', 'reply', BOB], ['p', AUTHOR], ['p', BOB]],
    });
  });
});

describe('video event engagement', () => {
  it('names an addressable video by its address and a regular one by id only', () => {
    expect(engagementAddress(regular)).toBeNull();
    expect(engagementAddress(addressable)).toBe(ADDRESS);
    expect(engagementAddress({ kind: 34236, pubkey: AUTHOR })).toBeNull();
  });

  it('asks for reactions and comments in one bounded request', () => {
    expect(engagementFilters(regular)).toEqual([
      { kinds: [7, 1111, 1], '#e': [ID], limit: 200 },
      { kinds: [1111], '#E': [ID], limit: 200 },
    ]);
    expect(engagementFilters(addressable).slice(2)).toEqual([
      { kinds: [7, 1111, 1], '#a': [ADDRESS], limit: 200 },
      { kinds: [1111], '#A': [ADDRESS], limit: 200 },
    ]);
    expect(engagementFilters({ kind: 22, pubkey: AUTHOR })).toEqual([]);
  });

  it('builds reactions and comments other apps can attribute to the video', () => {
    expect(reactionTemplate(regular, 100)).toEqual({
      kind: 7,
      created_at: 100,
      content: '+',
      tags: [['e', ID, '', AUTHOR], ['p', AUTHOR], ['k', '22']],
    });
    expect(reactionTemplate(addressable, 100).tags).toEqual([
      ['e', ID, '', AUTHOR], ['a', ADDRESS], ['p', AUTHOR], ['k', '34236'],
    ]);
    expect(commentTemplate(regular, 'hello', 100)).toEqual({
      kind: 1111,
      created_at: 100,
      content: 'hello',
      tags: [['E', ID, '', AUTHOR], ['K', '22'], ['P', AUTHOR], ['e', ID, '', AUTHOR], ['k', '22'], ['p', AUTHOR]],
    });
    expect(commentTemplate(addressable, 'hello', 100).tags).toEqual([
      ['A', ADDRESS], ['E', ID, '', AUTHOR], ['K', '34236'], ['P', AUTHOR],
      ['a', ADDRESS], ['e', ID, '', AUTHOR], ['k', '34236'], ['p', AUTHOR],
    ]);
    expect(deletionTemplate('f'.repeat(64), 7, 100).tags).toEqual([['e', 'f'.repeat(64)], ['k', '7']]);
  });

  it('counts each person once by their latest reaction and ignores repeats', () => {
    const tally = new EngagementTally();
    expect(tally.add(event('r1', 7, ALICE, '+', 10))).toBe(true);
    expect(tally.add(event('r1', 7, ALICE, '+', 10))).toBe(false);
    expect(tally.add(event('r2', 7, BOB, '🔥', 11))).toBe(true);
    expect(tally.likes).toBe(2);
    expect(tally.likeBy(ALICE)).toBe('r1');

    // A later dislike replaces the like; an older reaction arriving late does not bring it back.
    tally.add(event('r3', 7, ALICE, '-', 20));
    tally.add(event('r0', 7, ALICE, '+', 5));
    expect(tally.likes).toBe(1);
    expect(tally.likeBy(ALICE)).toBeNull();
    expect(tally.likeBy(null)).toBeNull();
  });

  it('lists comments newest first and forgets what the viewer took back', () => {
    const tally = new EngagementTally();
    tally.add(event('c1', 1111, ALICE, 'first', 10));
    tally.add(event('c3', 1111, BOB, 'third', 30));
    tally.add(event('c2', 1111, ALICE, 'second', 20));
    expect(tally.add(event('c4', 1111, BOB, '   ', 40))).toBe(false);
    expect(tally.add(event('x1', 1, BOB, 'a note', 40))).toBe(false);
    expect(tally.comments.map((comment) => comment.content)).toEqual(['third', 'second', 'first']);

    tally.add(event('r1', 7, ALICE, '+', 10));
    tally.remove('r1');
    tally.remove('c2');
    expect(tally.likes).toBe(0);
    expect(tally.comments.map((comment) => comment.id)).toEqual(['c3', 'c1']);
    // The relay repeating a removed event changes nothing.
    expect(tally.add(event('r1', 7, ALICE, '+', 10))).toBe(false);
    expect(tally.likes).toBe(0);
  });
});
