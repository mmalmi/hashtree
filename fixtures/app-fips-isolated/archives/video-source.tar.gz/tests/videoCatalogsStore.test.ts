import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  getLoadedVideoCatalogItemsByAuthor,
  ingestVideoCatalogRecord,
  removeVideoCatalogRecords,
  refreshSavedVideoCatalogs,
  searchLoadedVideoCatalogItems,
} from '../src/stores/videoCatalogs';
import {
  VIDEO_CATALOG_URL_KEY,
  VIDEO_CATALOG_URLS_KEY,
} from '../src/lib/videoCatalog';
import {
  VIDEO_CATALOG_SCHEMA_V2,
  VIDEO_COLLECTION_MANIFEST_PATH,
} from '../src/lib/videoCatalogCollection';

function installLocalStorage(urls: string[]) {
  const values = new Map<string, string>([
    [VIDEO_CATALOG_URL_KEY, urls[0] ?? ''],
    [VIDEO_CATALOG_URLS_KEY, JSON.stringify(urls)],
  ]);
  const localStorage = {
    getItem: vi.fn((key: string) => values.get(key) ?? null),
    setItem: vi.fn((key: string, value: string) => {
      values.set(key, value);
    }),
    removeItem: vi.fn((key: string) => {
      values.delete(key);
    }),
    clear: vi.fn(() => values.clear()),
    key: vi.fn((index: number) => Array.from(values.keys())[index] ?? null),
    get length() {
      return values.size;
    },
  };
  vi.stubGlobal('window', { localStorage });
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe('videoCatalogsStore collection search', () => {
  it('loads deploy default catalog roots before user-saved roots', async () => {
    installLocalStorage(['https://example.test/saved']);
    vi.stubEnv('VITE_DEFAULT_VIDEO_CATALOG_URLS', 'https://example.test/default');
    const fetcher = vi.fn(async (url: string) => ({
      ok: true,
      json: async () => ({
        videos: [{
          title: url.includes('/default/') ? 'Default Indexed Clip' : 'Saved Indexed Clip',
          href: url.includes('/default/') ? '#/npub1a/videos%2Fdefault' : '#/npub1a/videos%2Fsaved',
        }],
      }),
    } as Response));

    const state = await refreshSavedVideoCatalogs(fetcher);

    expect(state.defaultUrls).toEqual(['https://example.test/default']);
    expect(state.savedUrls).toEqual(['https://example.test/saved']);
    expect(state.urls).toEqual(['https://example.test/default', 'https://example.test/saved']);
    expect(fetcher).toHaveBeenCalledWith('https://example.test/default/root.json');
    expect(fetcher).toHaveBeenCalledWith('https://example.test/saved/root.json');
    expect(state.videos.map((video) => video.title)).toEqual([
      'Default Indexed Clip',
      'Saved Indexed Clip',
    ]);
  });

  it('does not fall back to substring matching for stop words once a collection index exists', async () => {
    installLocalStorage(['https://example.test/catalog']);
    const fetcher = vi.fn(async (url: string) => ({
      ok: true,
      json: async () => url.endsWith('/root.json')
        ? {
            schema: VIDEO_CATALOG_SCHEMA_V2,
            collections: { videos: { manifestPath: VIDEO_COLLECTION_MANIFEST_PATH } },
            videos: [{ title: 'The Unique Indexed Clip', href: '#/npub1a/videos%2Funique' }],
          }
        : {
            version: 1,
            sourceId: 'test/videos',
            schemaVersion: 2,
            updatedAt: 1,
            byIdRoot: null,
            indexes: {},
          },
    } as Response));

    await refreshSavedVideoCatalogs(fetcher);

    await expect(searchLoadedVideoCatalogItems('the', 5)).resolves.toEqual([]);
    await expect(searchLoadedVideoCatalogItems('unique', 5)).resolves.toMatchObject([
      { title: 'The Unique Indexed Clip' },
    ]);
  });

  it('returns author-scoped catalog records for profile pages', async () => {
    installLocalStorage(['https://example.test/catalog']);
    const fetcher = vi.fn(async () => ({
      ok: true,
      json: async () => ({
        videos: [
          {
            title: 'Author Indexed Clip',
            ownerNpub: 'npub1author',
            ownerPubkey: 'c'.repeat(64),
            treeName: 'videos/author-indexed',
            timestamp: 200,
          },
          {
            title: 'Other Indexed Clip',
            ownerNpub: 'npub1other',
            ownerPubkey: 'd'.repeat(64),
            treeName: 'videos/other-indexed',
            timestamp: 300,
          },
        ],
      }),
    } as Response));

    await refreshSavedVideoCatalogs(fetcher);

    await expect(getLoadedVideoCatalogItemsByAuthor({
      ownerPubkey: 'c'.repeat(64),
      ownerNpub: 'npub1author',
      limit: 10,
    })).resolves.toMatchObject([
      { title: 'Author Indexed Clip', treeName: 'videos/author-indexed' },
    ]);
  });

  it('removes trusted event records when a tree delete arrives', async () => {
    installLocalStorage([]);
    await refreshSavedVideoCatalogs(async () => ({
      ok: true,
      json: async () => ({}),
    } as Response));

    await ingestVideoCatalogRecord({
      id: 'delete-record',
      title: 'Delete Me Indexed Clip',
      href: '#/npub1owner/videos%2Fdelete-me',
      ownerNpub: 'npub1owner',
      ownerPubkey: 'b'.repeat(64),
      treeName: 'videos/delete-me',
      tags: [],
      sourceEvents: ['event-delete-me'],
      provenance: [{ source: 'nostr-kind-30078', scope: 'own', authorPubkey: 'b'.repeat(64) }],
      timestamp: 123,
    });

    await expect(searchLoadedVideoCatalogItems('delete', 5)).resolves.toMatchObject([
      { title: 'Delete Me Indexed Clip' },
    ]);

    await removeVideoCatalogRecords({
      ownerPubkey: 'b'.repeat(64),
      treeName: 'videos/delete-me',
    });

    await expect(searchLoadedVideoCatalogItems('delete', 5)).resolves.toEqual([]);
  });
});
