import { beforeEach, expect, it, vi } from 'vitest';
import { finalizeEvent, getPublicKey, type Event, type EventTemplate } from 'nostr-tools';
const fixture = vi.hoisted(() => ({
  requests: [] as Array<{kinds:number[], authors:string[], handlers:Record<string,(event?:unknown)=>void>}>,
  pubkey: '',
  nostr: {signer: {} as object | undefined, subscribe: vi.fn(), signEvent: vi.fn(), publish: vi.fn()},
}));
vi.mock('../src/nostr/client', () => ({nostr: fixture.nostr}));
vi.mock('../src/nostr', () => ({nostr: fixture.nostr, nostrStore: {getState: () => ({pubkey:fixture.pubkey})}}));
import { createProfileStore, getProfileSync } from '../src/stores/profile';
import { get } from 'svelte/store';
import { followNotice, followPubkey, getFollowsSync, unfollowPubkey } from '../src/stores/follows';
import { contactMemory } from '../src/stores/contactMemory';
let secret: Uint8Array;
let sequence = 0;
const contact='b'.repeat(64), existing='c'.repeat(64);
const head = (tags:string[][],created_at=20): Event => finalizeEvent({kind:3,tags,created_at,content:'{"keep":"this"}'},secret);
const ownRequest = () => fixture.requests.find(r=>r.kinds.includes(3)&&r.authors[0]===fixture.pubkey)!;
const shown = () => getFollowsSync(fixture.pubkey)?.follows;
const signed = () => fixture.nostr.signEvent.mock.calls.map(call=>call[0]);
const settle = () => vi.waitFor(() => expect(fixture.nostr.publish).toHaveBeenCalled());
beforeEach(() => {
  vi.useRealTimers(); fixture.requests=[]; fixture.nostr.signEvent.mockReset(); fixture.nostr.publish.mockReset();
  secret=new Uint8Array(32);secret[31]=++sequence;fixture.pubkey=getPublicKey(secret);fixture.nostr.signer={};
  const values = new Map<string,string>();
  vi.stubGlobal('localStorage', {getItem:(key:string)=>values.get(key)??null,setItem:(key:string,value:string)=>values.set(key,value)});
  fixture.nostr.subscribe.mockImplementation((filter) => {
    const request={...filter,handlers:{}};fixture.requests.push(request);
    return {on:(type:string,callback:(event:unknown)=>void) => {request.handlers[type]=callback;},stop:()=>{request.handlers.close?.();}};
  });
  fixture.nostr.signEvent.mockImplementation(async (draft:EventTemplate) => finalizeEvent(draft,secret));
  fixture.nostr.publish.mockResolvedValue(undefined);
});
it('shows a follow at once, publishes on the newest list seen, and saves the name seen before follow', async () => {
  const unsubscribe=createProfileStore(contact).subscribe(()=>{});
  // Profile lookups are batched, so the request follows a moment later.
  const profile=await vi.waitFor(() => { const request=fixture.requests.find(r=>r.kinds.includes(0)); expect(request).toBeDefined(); return request!; });
  profile.handlers.event({pubkey:contact,created_at:20,content:JSON.stringify({name:'Bob'})});
  profile.handlers.event({pubkey:contact,created_at:10,content:JSON.stringify({name:'Outdated'})});
  expect(getProfileSync(contact)?.name).toBe('Bob');
  expect(await followPubkey(contact)).toBe(true);
  // Nothing has answered yet: the follow shows, and no list is signed from nothing.
  expect(shown()).toEqual([contact]);
  expect(contactMemory.get(fixture.pubkey,contact)?.accepted_name).toBe('Bob');
  await Promise.resolve();
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  const tags=[['p',existing,'wss://example.invalid','friend'],['t','music'],['client','iris']];
  const own=ownRequest();
  own.handlers.event(head(tags));
  own.handlers.event(head([['p','d'.repeat(64)]],15)); // an older list from a slow relay is ignored
  expect(shown()).toEqual([existing,contact]);
  await settle(); // published without waiting for history to finish
  expect(signed()[0]).toMatchObject({content:'{"keep":"this"}',tags:[...tags,['p',contact]]});
  expect(fixture.nostr.publish.mock.calls[0][0].tags).toEqual([...tags,['p',contact]]);
  profile.handlers.event({pubkey:contact,created_at:30,content:JSON.stringify({name:'Robert'})});
  expect(contactMemory.get(fixture.pubkey,contact)?.accepted_name).toBe('Bob');
  expect(getProfileSync(contact)?.name).toBe('Robert');
  own.handlers.event(head(tags)); // A stale relay cannot erase the locally published head.
  own.handlers.history({complete:true,reason:'eose'});
  expect(shown()).toEqual([existing,contact]);
  expect(await unfollowPubkey(contact)).toBe(true);
  expect(shown()).toEqual([existing]);
  await vi.waitFor(() => expect(fixture.nostr.publish).toHaveBeenCalledTimes(2));
  expect(signed()[1]).toMatchObject({content:'{"keep":"this"}',tags});
  expect(fixture.requests.filter(r=>r.kinds.includes(3))).toHaveLength(1);
  unsubscribe();
});
it('does not publish a list built from nothing until history has finished', async () => {
  expect(await followPubkey(contact)).toBe(true);
  const own=ownRequest();
  own.handlers.history({complete:false,reason:'unavailable'});
  await new Promise(resolve=>setTimeout(resolve,0));
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  expect(shown()).toEqual([contact]); // the change is kept, and said to be waiting
  expect(get(followNotice)?.pubkey).toBe(fixture.pubkey);
  own.handlers.event(head([['p',existing]])); // the list turns up later
  await settle();
  expect(signed()[0].tags).toEqual([['p',existing],['p',contact]]);
});
it('publishes a first list once history has finished with none', async () => {
  expect(await followPubkey(contact)).toBe(true);
  ownRequest().handlers.history({complete:true,reason:'eose'});
  await settle();
  expect(signed()[0]).toMatchObject({content:'',tags:[['p',contact]]});
  expect(get(followNotice)).toBeNull();
});
it('refuses unsigned lists and drops changes after an account change', async () => {
  expect(await followPubkey(contact)).toBe(true);
  const own=ownRequest(), first=fixture.pubkey;
  own.handlers.event({...JSON.parse(JSON.stringify(head([['p',existing]]))),sig:'invalid'});
  own.handlers.history({complete:true,reason:'eose'});
  await new Promise(resolve=>setTimeout(resolve,0));
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  fixture.pubkey='d'.repeat(64);
  own.handlers.event(head([['p',existing]],30));
  await new Promise(resolve=>setTimeout(resolve,0));
  expect(fixture.nostr.signEvent).not.toHaveBeenCalled();
  expect(getFollowsSync(first)?.follows).toEqual([existing]);
});
it('puts concurrent edits into one list and keeps the local list while relays lag', async () => {
  const other='e'.repeat(64), initial=head([['p',existing],['client','iris']]);
  void followPubkey(contact); void followPubkey(other);
  expect(shown()).toEqual([contact,other]);
  const own=ownRequest();
  own.handlers.event(initial);own.handlers.history({complete:true,reason:'eose'});
  await settle();
  expect(signed()).toHaveLength(1);
  expect(signed()[0].tags).toEqual([['p',existing],['client','iris'],['p',contact],['p',other]]);
  own.handlers.event(initial);
  expect(shown()).toEqual([existing,contact,other]);
});
it('keeps the change and reports it when sending fails', async () => {
  fixture.nostr.publish.mockRejectedValue(new Error('offline'));
  expect(await followPubkey(contact)).toBe(true);
  const own=ownRequest();
  own.handlers.event(head([['p',existing]]));
  await vi.waitFor(() => expect(get(followNotice)?.message).toContain('not been sent'));
  expect(shown()).toEqual([existing,contact]);
  // The next change builds on the unsent list, so nothing is lost.
  fixture.nostr.publish.mockResolvedValue(undefined);
  expect(await followPubkey('e'.repeat(64))).toBe(true);
  await vi.waitFor(() => expect(signed()).toHaveLength(2));
  expect(signed()[1].tags).toEqual([['p',existing],['p',contact],['p','e'.repeat(64)]]);
});
it('shows the real list again when signing is refused', async () => {
  fixture.nostr.signEvent.mockRejectedValue(new Error('refused'));
  expect(await followPubkey(contact)).toBe(true);
  ownRequest().handlers.event(head([['p',existing]]));
  await vi.waitFor(() => expect(get(followNotice)?.message).toContain('sign'));
  expect(shown()).toEqual([existing]);
  expect(fixture.nostr.publish).not.toHaveBeenCalled();
});
it('refuses when signed out or given a malformed key', async () => {
  expect(await followPubkey('nope')).toBe(false);
  fixture.nostr.signer=undefined;
  expect(await followPubkey(contact)).toBe(false);
  expect(fixture.requests.filter(r=>r.kinds.includes(3))).toHaveLength(0);
});
