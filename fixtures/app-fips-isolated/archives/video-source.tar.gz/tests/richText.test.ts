import { describe, expect, it } from 'vitest';
import { nip19 } from 'nostr-tools';
import { parseRichText, shortRef, truncateRichText } from '../src/lib/richText';

const PUBKEY = 'a'.repeat(64);
const NPUB = nip19.npubEncode(PUBKEY);

describe('rich text', () => {
  it('finds links, pictures, mentions and hashtags in a sentence', () => {
    const text = `Look https://example.com/page, a pic https://img.example/a.JPG?x=1 by nostr:${NPUB} #Music!`;
    expect(parseRichText(text)).toEqual([
      { type: 'text', text: 'Look ' },
      { type: 'link', url: 'https://example.com/page' },
      { type: 'text', text: ', a pic ' },
      { type: 'image', url: 'https://img.example/a.JPG?x=1' },
      { type: 'text', text: ' by ' },
      { type: 'mention', pubkey: PUBKEY, npub: NPUB },
      { type: 'text', text: ' ' },
      { type: 'hashtag', tag: 'music' },
      { type: 'text', text: '!' },
    ]);
  });

  it('links references to videos and playlists inside the app and leaves the rest to the reader', () => {
    const video = nip19.naddrEncode({ kind: 34235, pubkey: PUBKEY, identifier: 'clip' });
    const set = nip19.naddrEncode({ kind: 30005, pubkey: PUBKEY, identifier: 'list' });
    const article = nip19.naddrEncode({ kind: 30023, pubkey: PUBKEY, identifier: 'post' });
    const note = nip19.noteEncode('b'.repeat(64));
    const profile = nip19.nprofileEncode({ pubkey: PUBKEY });
    const segments = parseRichText(`${video} nostr:${set} ${article} ${note} ${profile}`).filter((segment) => segment.type !== 'text');
    expect(segments).toEqual([
      { type: 'event', bech32: video, href: `#/v/${video}` },
      { type: 'event', bech32: set, href: `#/list/${set}` },
      { type: 'event', bech32: article, href: null },
      { type: 'event', bech32: note, href: null },
      { type: 'mention', pubkey: PUBKEY, npub: NPUB },
    ]);
    expect(shortRef(note)).toBe(`${note.slice(0, 10)}…${note.slice(-4)}`);
  });

  it('leaves things that only look like references or hashtags as text', () => {
    expect(parseRichText('npub1notreallyakeyatallnotreallyakey')).toEqual([{ type: 'text', text: 'npub1notreallyakeyatallnotreallyakey' }]);
    expect(parseRichText('issue #123 and a#b and https://example.com/#frag')).toEqual([
      { type: 'text', text: 'issue #123 and a#b and ' },
      { type: 'link', url: 'https://example.com/#frag' },
    ]);
    expect(parseRichText('')).toEqual([]);
  });

  it('reads timestamps only where asked to', () => {
    expect(parseRichText('Intro 0:00\nTalk 1:02:03')).toEqual([{ type: 'text', text: 'Intro 0:00\nTalk 1:02:03' }]);
    expect(parseRichText('Intro 0:00\nTalk 1:02:03', { timestamps: true })).toEqual([
      { type: 'text', text: 'Intro ' },
      { type: 'timestamp', display: '0:00', seconds: 0 },
      { type: 'text', text: '\nTalk ' },
      { type: 'timestamp', display: '1:02:03', seconds: 3723 },
    ]);
  });

  it('cuts long text at a line or word for "show more"', () => {
    expect(truncateRichText('short', 4, 100)).toEqual({ text: 'short', truncated: false });
    expect(truncateRichText('a\nb\nc\nd\ne', 3, 100)).toEqual({ text: 'a\nb\nc', truncated: true });
    const long = 'word '.repeat(40).trim();
    const cut = truncateRichText(long, 10, 52);
    expect(cut.truncated).toBe(true);
    expect(cut.text).toBe('word '.repeat(10).trim());
  });
});
