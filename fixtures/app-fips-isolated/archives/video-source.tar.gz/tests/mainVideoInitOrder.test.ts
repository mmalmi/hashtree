import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mount = vi.fn();
const initServiceWorker = vi.fn();
const markHtreeReady = vi.fn();
const initReadonlyBackend = vi.fn();
const restoreSession = vi.fn();
const ensureMediaStreamingReady = vi.fn();
const initHtreeApi = vi.fn();
const setAppType = vi.fn();
const installHtreeDebugCapture = vi.fn();

async function waitForExpectation(expectation: () => void, attempts = 20): Promise<void> {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      expectation();
      return;
    } catch (error) {
      lastError = error;
      await Promise.resolve();
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  throw lastError;
}

describe('main-video init order', () => {
  beforeEach(() => {
    vi.resetModules();
    mount.mockReset();
    initServiceWorker.mockReset();
    markHtreeReady.mockReset();
    initReadonlyBackend.mockReset();
    restoreSession.mockReset();
    ensureMediaStreamingReady.mockReset();
    initHtreeApi.mockReset();
    setAppType.mockReset();
    installHtreeDebugCapture.mockReset();
    vi.stubGlobal('document', {
      getElementById: vi.fn(() => ({ id: 'app' })),
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('mounts the video app without waiting for the service worker, and opens hashtree media once it is ready', async () => {
    let resolveSw: (() => void) | null = null;
    const swReady = new Promise<void>((resolve) => {
      resolveSw = resolve;
    });

    initServiceWorker.mockReturnValue(swReady);
    initReadonlyBackend.mockResolvedValue(undefined);
    restoreSession.mockResolvedValue(undefined);
    ensureMediaStreamingReady.mockResolvedValue(true);
    initHtreeApi.mockResolvedValue(undefined);

    vi.doMock('svelte', () => ({ mount }));
    vi.doMock('../src/lib/swInit', () => ({ initServiceWorker }));
    vi.doMock('../src/lib/htreeReady', () => ({ markHtreeReady }));
    vi.doMock('../src/nostr/auth', () => ({ initReadonlyBackend, restoreSession }));
    vi.doMock('../src/lib/mediaStreamingSetup', () => ({ ensureMediaStreamingReady }));
    vi.doMock('../src/appType', () => ({ setAppType }));
    vi.doMock('../src/lib/htreeApi', () => ({ initHtreeApi }));
    vi.doMock('../src/lib/htreeDebug', () => ({ installHtreeDebugCapture }));
    vi.doMock('../src/VideoApp.svelte', () => ({ default: {} }));

    await import('../src/main-video');
    await Promise.resolve();

    expect(initServiceWorker).toHaveBeenCalledOnce();
    await waitForExpectation(() => {
      expect(mount).toHaveBeenCalledOnce();
    });
    expect(markHtreeReady).not.toHaveBeenCalled();

    resolveSw?.();

    await waitForExpectation(() => {
      expect(markHtreeReady).toHaveBeenCalledOnce();
    });
  });

  it('mounts the shell without waiting for backend media or session work', async () => {
    let resolveBackend: (() => void) | null = null;
    let resolveMedia: ((value: boolean) => void) | null = null;
    let resolveSession: ((value: boolean) => void) | null = null;

    initServiceWorker.mockResolvedValue(undefined);
    initReadonlyBackend.mockReturnValue(new Promise<void>((resolve) => {
      resolveBackend = resolve;
    }));
    ensureMediaStreamingReady.mockReturnValue(new Promise<boolean>((resolve) => {
      resolveMedia = resolve;
    }));
    restoreSession.mockReturnValue(new Promise<boolean>((resolve) => {
      resolveSession = resolve;
    }));
    initHtreeApi.mockResolvedValue(undefined);

    vi.doMock('svelte', () => ({ mount }));
    vi.doMock('../src/lib/swInit', () => ({ initServiceWorker }));
    vi.doMock('../src/lib/htreeReady', () => ({ markHtreeReady }));
    vi.doMock('../src/nostr/auth', () => ({ initReadonlyBackend, restoreSession }));
    vi.doMock('../src/lib/mediaStreamingSetup', () => ({ ensureMediaStreamingReady }));
    vi.doMock('../src/appType', () => ({ setAppType }));
    vi.doMock('../src/lib/htreeApi', () => ({ initHtreeApi }));
    vi.doMock('../src/lib/htreeDebug', () => ({ installHtreeDebugCapture }));
    vi.doMock('../src/VideoApp.svelte', () => ({ default: {} }));

    await import('../src/main-video');
    await waitForExpectation(() => {
      expect(mount).toHaveBeenCalledOnce();
    });
    expect(ensureMediaStreamingReady).not.toHaveBeenCalled();

    expect(initReadonlyBackend).not.toHaveBeenCalled();
    resolveSession?.(false);
    await waitForExpectation(() => expect(initReadonlyBackend).toHaveBeenCalledOnce());
    resolveBackend?.();
    await waitForExpectation(() => {
      expect(ensureMediaStreamingReady).toHaveBeenCalledOnce();
    });

    resolveMedia?.(true);
  });
});
