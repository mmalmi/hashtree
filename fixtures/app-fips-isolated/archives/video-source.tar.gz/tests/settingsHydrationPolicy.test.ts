import { afterEach, beforeEach, expect, test, vi } from 'vitest';
import { get } from 'svelte/store';
const io = vi.hoisted(() => ({ read: vi.fn(), put: vi.fn() }));
vi.mock('dexie', () => ({ default: class {
  settings = { get: io.read, put: io.put };
  version() { return { stores: () => { this.settings = { get: io.read, put: io.put }; } }; }
} }));
vi.mock('../src/lib/nativeHtree', () => ({ canUseInjectedHtreeServerUrl: () => false }));
beforeEach(() => {
  vi.resetModules(); io.read.mockReset(); io.put.mockReset();
  vi.stubGlobal('window', { location: { hostname: 'video.iris.to' } });
});
afterEach(() => { vi.unstubAllGlobals(); });

test.each([[], ['ws://127.0.0.1:7000'], ['wss://relay.damus.io'], ['wss://custom.example']].map(relays => ({ relays })))('preserves hydrated relay selection $relays', async ({ relays }) => {
  io.read.mockImplementation(async (key: string) => key === 'network' ? { key, value: { relays, blossomServers: [] } } : undefined);
  const settings = await import('../src/stores/settings'); await settings.waitForSettingsLoaded();
  expect(get(settings.settingsStore).network.relays).toEqual(relays); expect(io.put).not.toHaveBeenCalled();
});

test('defaults only after an absent saved row, never a failed or malformed read', async () => {
  io.read.mockResolvedValue(undefined);
  let settings = await import('../src/stores/settings'); await settings.waitForSettingsLoaded();
  expect(get(settings.settingsStore).network.relays).toEqual(settings.DEFAULT_NETWORK_SETTINGS.relays);
  expect(get(settings.settingsStore).network.relays.length).toBeGreaterThan(0);
  vi.resetModules(); io.read.mockImplementation(async (key: string) => key === 'network' ? { key, value: {} } : undefined);
  settings = await import('../src/stores/settings'); await settings.waitForSettingsLoaded();
  expect(get(settings.settingsStore).network.relays).toEqual([]);
  vi.resetModules(); io.read.mockRejectedValue(new Error('Unreadable saved settings'));
  settings = await import('../src/stores/settings'); await settings.waitForSettingsLoaded();
  expect(get(settings.settingsStore).network.relays).toEqual([]); expect(io.put).not.toHaveBeenCalled();
});

test('keeps hydration pending when a saved custom policy takes more than 500ms', async () => {
  let release!: (row: unknown) => void;
  const pending = new Promise(resolve => { release = resolve; });
  io.read.mockImplementation((key: string) => key === 'network' ? pending : Promise.resolve(undefined));
  const settings = await import('../src/stores/settings'); let ready = false;
  const hydration = settings.waitForSettingsLoaded().then(() => { ready = true; });
  await new Promise(resolve => setTimeout(resolve, 650)); expect(ready).toBe(false);
  release({ key: 'network', value: { relays: ['wss://custom.example'] } }); await hydration;
  expect(get(settings.settingsStore).network.relays).toEqual(['wss://custom.example']); expect(io.put).not.toHaveBeenCalled();
});
