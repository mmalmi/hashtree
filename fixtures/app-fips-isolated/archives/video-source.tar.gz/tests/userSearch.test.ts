import { describe, expect, it } from 'vitest';
import { nip19 } from 'nostr-tools';
import { rankUsers, toUserIndexEntry } from '../src/lib/search/userIndexEntry';

const pk = (digit: string) => digit.repeat(64);
const user = (digit: string, name?: string, displayName?: string, nip05?: string) => toUserIndexEntry({ pubkey: pk(digit), name, displayName, nip05 })!;

describe('people search', () => {
  const people = [
    user('1', 'maxwell', 'Maxwell Smart'),
    user('2', 'max'),
    user('3', 'someone', 'Mad Max'),
    user('4', 'climax'),
    user('5', undefined, undefined, 'max@example.com'),
    user('6', 'unrelated'),
  ];

  it('ranks a whole name first, then the start of a name or word, then anywhere inside', () => {
    expect(rankUsers(people, 'Max', 10).map((entry) => entry.pubkey[0])).toEqual(['2', '5', '1', '3', '4']);
    expect(rankUsers(people, '  ', 10)).toEqual([]);
    expect(rankUsers(people, 'max', 2)).toHaveLength(2);
  });

  it('puts people closer to the viewer first among equal matches', () => {
    const distance = (pubkey: string) => (pubkey === pk('5') ? 1 : 3);
    expect(rankUsers(people, 'max', 2, distance).map((entry) => entry.pubkey[0])).toEqual(['5', '2']);
  });

  it('finds people by the start of their npub or key', () => {
    const npub = nip19.npubEncode(pk('6'));
    expect(rankUsers(people, npub.slice(0, 12), 5).map((entry) => entry.pubkey[0])).toEqual(['6']);
    expect(rankUsers(people, '6666', 5).map((entry) => entry.pubkey[0])).toEqual(['6']);
  });

  it('rejects keys that are not keys and trims empty names', () => {
    expect(toUserIndexEntry({ pubkey: 'nope' })).toBeNull();
    expect(user('7', '  ').name).toBeUndefined();
  });
});

describe('relay text search', () => {
  it('finds where a relay serves its information document', async () => {
    const { relayInfoUrl } = await import('../src/nostr/textSearch');
    expect(relayInfoUrl('wss://relay.example.com')).toBe('https://relay.example.com/');
    expect(relayInfoUrl('ws://localhost:4736/w0')).toBe('http://localhost:4736/w0');
    expect(relayInfoUrl('https://not-a-relay.example')).toBeNull();
    expect(relayInfoUrl('nonsense')).toBeNull();
  });
});
