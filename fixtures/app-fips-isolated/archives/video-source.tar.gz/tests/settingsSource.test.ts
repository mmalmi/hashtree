import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const appSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'VideoApp.svelte'), 'utf8');
const sharedSettingsSource = fs.readFileSync(
  path.join(fs.realpathSync(path.resolve(process.cwd(), 'node_modules', '@iris', 'hashtree-app')), 'src', 'SettingsLayout.svelte'),
  'utf8',
);
const appSettingsSource = fs.readFileSync(
  path.resolve(process.cwd(), 'src', 'components', 'settings', 'AppSettings.svelte'),
  'utf8',
);
const shareUrlsSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'lib', 'shareUrls.ts'), 'utf8');
const transportUsageSettingsSource = fs.readFileSync(
  path.resolve(process.cwd(), 'src', 'components', 'settings', 'TransportUsageSettings.svelte'),
  'utf8',
);
const p2pSettingsSource = fs.readFileSync(
  path.resolve(process.cwd(), 'src', 'components', 'settings', 'P2PSettings.svelte'),
  'utf8',
);
const connectivityIndicatorSource = fs.readFileSync(
  path.resolve(process.cwd(), 'src', 'components', 'ConnectivityIndicator.svelte'),
  'utf8',
);

describe('settings source links', () => {
  it('links the video settings page to the video source repository', () => {
    expect(appSettingsSource).toContain("getCanonicalGitRepositoryUrl('iris-video')");
    expect(appSettingsSource).toContain('<span>iris-video</span>');
    expect(shareUrlsSource).toContain("getCanonicalGitRepositoryUrl(repoPath = 'iris-video')");
    expect(appSettingsSource).not.toContain("getCanonicalGitRepositoryUrl('hashtree')");
    expect(appSettingsSource).not.toContain('<span>hashtree</span>');
  });

  it('keeps settings reachable from the header independently of connection indicators', () => {
    expect(appSource).toContain("from '@iris/hashtree-app/SettingsShortcut.svelte'");
    expect(appSource).toContain('<SettingsShortcut />');
  });

  it('keeps header connectivity detailed only when the setting is enabled', () => {
    expect(p2pSettingsSource).toContain('Show connectivity in header');
    expect(p2pSettingsSource).toContain('DEFAULT_POOL_SETTINGS.showConnectivity');
    expect(connectivityIndicatorSource).toContain("from '../stores/settings'");
    expect(connectivityIndicatorSource).toContain("$settingsStore.pools.showConnectivity ?? false");
    expect(connectivityIndicatorSource).toContain('>\n    offline\n  </a>');
  });

  it('puts the traffic header visibility toggle on the traffic settings page', () => {
    expect(transportUsageSettingsSource).toContain('Show in header');
    expect(transportUsageSettingsSource).toContain('data-testid="settings-show-bandwidth-toggle"');
    expect(transportUsageSettingsSource).toContain('setPoolSettings({ showBandwidth: e.currentTarget.checked })');
    expect(transportUsageSettingsSource).not.toContain('Control whether live traffic rates appear in the app header');
    expect(transportUsageSettingsSource).not.toContain('Display live upload/download rates in the header');
    expect(p2pSettingsSource).not.toContain('Show bandwidth');
    expect(p2pSettingsSource).not.toContain('setPoolSettings({ showBandwidth: e.currentTarget.checked })');
  });

  it('keeps settings pages scrollable inside the fixed app shell', () => {
    expect(appSource).toContain('flex-1 flex flex-col min-h-0');
    expect(sharedSettingsSource).toContain('overflow-y-auto overscroll-contain');
    expect(sharedSettingsSource).toContain('data-scrollable');
  });
});
