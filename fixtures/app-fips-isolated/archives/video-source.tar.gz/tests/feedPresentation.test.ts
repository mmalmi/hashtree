import { describe, expect, it } from 'vitest';
import { reconcileFeed, unseenFirst } from '../src/lib/feedPresentation';

describe('feed presentation', () => {
  it('fills an empty or short page in ranked order', () => {
    expect(reconcileFeed([], ['a', 'b', 'c'], 2)).toEqual({ shown: ['a', 'b'], pending: false });
    expect(reconcileFeed(['a', 'b'], ['a', 'b', 'c', 'd'], 4)).toEqual({ shown: ['a', 'b', 'c', 'd'], pending: false });
  });

  it('never moves what is on screen: arrivals go below and an update becomes pending', () => {
    // "x" now ranks first, but the viewer is looking at a, b.
    expect(reconcileFeed(['a', 'b'], ['x', 'a', 'b', 'c'], 3)).toEqual({ shown: ['a', 'b', 'x'], pending: true });
    // A full page stays exactly as it is.
    expect(reconcileFeed(['a', 'b'], ['x', 'a', 'b'], 2)).toEqual({ shown: ['a', 'b'], pending: true });
    // A pure re-ordering is pending too.
    expect(reconcileFeed(['a', 'b'], ['b', 'a'], 2)).toEqual({ shown: ['a', 'b'], pending: true });
  });

  it('is not pending when only entries beyond the page changed', () => {
    expect(reconcileFeed(['a', 'b'], ['a', 'b', 'x', 'y'], 2)).toEqual({ shown: ['a', 'b'], pending: false });
  });

  it('replaces a loaded offscreen card without offering Update, even on a full page', () => {
    expect(reconcileFeed(['a', 'b', 'c', 'd'], ['a', 'b', 'x', 'd', 'c'], 4, 2))
      .toEqual({ shown: ['a', 'b', 'x', 'd'], pending: false });
  });

  it('updates the offscreen tail even when the visible order has a pending change', () => {
    const latest = ['x', 'b', 'a', 'd', 'c'];
    expect(reconcileFeed(['a', 'b', 'c', 'd'], latest, 4, 2))
      .toEqual({ shown: ['a', 'b', 'x', 'd'], pending: true });
    expect(reconcileFeed(['a', 'b', 'x', 'd'], latest, 4, 0))
      .toEqual({ shown: ['x', 'b', 'a', 'd'], pending: false });
  });

  it('drops entries that no longer exist and refills from below', () => {
    expect(reconcileFeed(['a', 'b', 'c'], ['a', 'c', 'd'], 3)).toEqual({ shown: ['a', 'c', 'd'], pending: false });
  });

  it('extends the page when more entries are asked for', () => {
    expect(reconcileFeed(['a', 'b'], ['a', 'b', 'c', 'd', 'e'], 4)).toEqual({ shown: ['a', 'b', 'c', 'd'], pending: false });
  });
});

describe('unseenFirst', () => {
  it('moves seen items to the end and keeps both groups in order', () => {
    const seen = new Set(['a', 'c']);
    expect(unseenFirst(['a', 'b', 'c', 'd'], (key) => seen.has(key))).toEqual(['b', 'd', 'a', 'c']);
    expect(unseenFirst(['a', 'c'], (key) => seen.has(key))).toEqual(['a', 'c']);
    expect(unseenFirst([], () => true)).toEqual([]);
  });
});
