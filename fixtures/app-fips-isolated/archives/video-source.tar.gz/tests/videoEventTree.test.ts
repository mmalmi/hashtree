import { describe, expect, it, vi } from 'vitest';
import { cid, fromHex, LinkType, nhashEncode, toHex, type CID } from '@hashtree/core';
import { nip19 } from 'nostr-tools';
import { readVideoEventInputs } from '../src/lib/videoEventTree';

const OWNER_NPUB = nip19.npubEncode('a'.repeat(64));
const encoder = new TextEncoder();

function testCid(byte: string): CID {
  return cid(fromHex(byte.repeat(32)));
}

function cidKey(value: CID): string {
  return toHex(value.hash);
}

function fakeTree(dirs: Map<string, unknown[]>, files: Map<string, Uint8Array> = new Map()) {
  return {
    listDirectory: vi.fn(async (target: CID) => (dirs.get(cidKey(target)) ?? []) as never),
    readFile: vi.fn(async (target: CID) => files.get(cidKey(target)) ?? null),
  };
}

describe('readVideoEventInputs', () => {
  it('describes a single video from its entry metadata and thumbnail file', async () => {
    const root = testCid('10');
    const thumb = testCid('12');
    const tree = fakeTree(new Map([[cidKey(root), [
      {
        name: 'video.mp4',
        cid: testCid('11'),
        type: LinkType.File,
        meta: { title: 'Meta Title', description: 'Meta description', duration: 42, createdAt: 1_700_000_000 },
      },
      { name: 'thumbnail.jpg', cid: thumb, type: LinkType.File },
    ]]]));

    const result = await readVideoEventInputs(tree, {
      ownerNpub: OWNER_NPUB,
      treeName: 'videos/Tree Title',
      rootCid: root,
      timestamp: 5,
    });

    expect(result).toEqual({
      kind: 'video',
      skipped: 0,
      inputs: [{
        ownerNpub: OWNER_NPUB,
        treeName: 'videos/Tree Title',
        title: 'Meta Title',
        description: 'Meta description',
        duration: 42,
        publishedAt: 1_700_000_000,
        videoPath: 'video.mp4',
        thumbnailUrl: `htree://${nhashEncode(thumb)}/thumbnail.jpg`,
        width: undefined,
        height: undefined,
        tags: undefined,
      }],
    });
  });

  it('falls back to metadata.json, title.txt and the tree name', async () => {
    const root = testCid('20');
    const metadata = testCid('22');
    const description = testCid('23');
    const tree = fakeTree(
      new Map([[cidKey(root), [
        { name: 'clip.webm', cid: testCid('21'), type: LinkType.File },
        { name: 'metadata.json', cid: metadata, type: LinkType.File, size: 60 },
        { name: 'description.txt', cid: description, type: LinkType.File },
      ]]]),
      new Map([
        [cidKey(metadata), encoder.encode(JSON.stringify({ duration: '12.5', createdAt: 1_700_000_000_000, tags: ['Music'] }))],
        [cidKey(description), encoder.encode('From the text file')],
      ]),
    );

    const { inputs } = await readVideoEventInputs(tree, { ownerNpub: OWNER_NPUB, treeName: 'videos/Tree Title', rootCid: root });

    expect(inputs[0]).toMatchObject({
      title: 'Tree Title',
      description: 'From the text file',
      duration: 12.5,
      // Millisecond timestamps are normalised to seconds.
      publishedAt: 1_700_000_000,
      videoPath: 'clip.webm',
      tags: ['Music'],
    });
    expect(inputs[0].thumbnailUrl).toBeUndefined();
  });

  it('describes each playable playlist item and skips everything else', async () => {
    const root = testCid('30');
    const first = testCid('31');
    const second = testCid('32');
    const notes = testCid('33');
    const thumb = testCid('36');
    const tree = fakeTree(new Map([
      [cidKey(root), [
        { name: 'video_000001', cid: first, type: LinkType.Dir, meta: { title: 'First Clip', duration: 12, originalDate: 1_700_000_000 } },
        { name: 'Second', cid: second, type: LinkType.Dir },
        { name: 'docs', cid: notes, type: LinkType.Dir },
        { name: 'readme.txt', cid: testCid('34'), type: LinkType.File },
      ]],
      [cidKey(first), [
        { name: 'video.mp4', cid: testCid('35'), type: LinkType.File },
        { name: 'thumbnail.webp', cid: thumb, type: LinkType.File },
      ]],
      [cidKey(second), [{ name: 'video.webm', cid: testCid('37'), type: LinkType.File }]],
      [cidKey(notes), [{ name: 'notes.md', cid: testCid('38'), type: LinkType.File }]],
    ]));

    const result = await readVideoEventInputs(tree, {
      ownerNpub: OWNER_NPUB,
      treeName: 'videos/Talks',
      rootCid: root,
      timestamp: 99,
    });

    expect(result.kind).toBe('playlist');
    expect(result.inputs).toHaveLength(2);
    expect(result.inputs[0]).toMatchObject({
      treeName: 'videos/Talks',
      videoId: 'Second',
      title: 'Second',
      publishedAt: 99,
      videoPath: 'video.webm',
      tags: ['playlist'],
    });
    expect(result.inputs[1]).toMatchObject({
      videoId: 'video_000001',
      title: 'First Clip',
      duration: 12,
      publishedAt: 1_700_000_000,
      videoPath: 'video.mp4',
      thumbnailUrl: `htree://${nhashEncode(thumb)}/thumbnail.webp`,
    });
  });

  it('uses the playlist title for generated item ids without their own title', async () => {
    const root = testCid('40');
    const item = testCid('41');
    const tree = fakeTree(new Map([
      [cidKey(root), [{ name: 'video_000001', cid: item, type: LinkType.Dir }]],
      [cidKey(item), [{ name: 'video.mp4', cid: testCid('42'), type: LinkType.File }]],
    ]));

    const { inputs } = await readVideoEventInputs(tree, { ownerNpub: OWNER_NPUB, treeName: 'videos/Talks', rootCid: root });
    expect(inputs[0].title).toBe('Talks');
  });

  it('caps playlist items and reports how many were left out', async () => {
    const root = testCid('50');
    const dirs = new Map<string, unknown[]>();
    const children = ['a', 'b', 'c'].map((name, index) => {
      const child = testCid(`5${index + 1}`);
      dirs.set(cidKey(child), [{ name: 'video.mp4', cid: testCid(`6${index}`), type: LinkType.File }]);
      return { name, cid: child, type: LinkType.Dir };
    });
    dirs.set(cidKey(root), children);

    const result = await readVideoEventInputs(fakeTree(dirs), {
      ownerNpub: OWNER_NPUB,
      treeName: 'videos/Many',
      rootCid: root,
    }, { itemLimit: 2 });

    expect(result.inputs.map((input) => input.videoId)).toEqual(['a', 'b']);
    expect(result.skipped).toBe(1);
  });

  it('reports unreadable roots instead of guessing', async () => {
    const tree = {
      listDirectory: vi.fn(async () => { throw new Error('missing blocks'); }),
      readFile: vi.fn(async () => null),
    };
    await expect(readVideoEventInputs(tree, {
      ownerNpub: OWNER_NPUB,
      treeName: 'videos/Gone',
      rootCid: testCid('70'),
    })).resolves.toEqual({ kind: 'unreadable', inputs: [], skipped: 0 });
  });
});
