import { beforeEach, describe, expect, it, vi } from 'vitest';

const { settings } = vi.hoisted(() => ({
  settings: { imgproxy: { enabled: true, url: '', key: '', salt: '' } },
}));

vi.mock('../src/stores/settings', () => ({
  settingsStore: {
    subscribe(run: (value: typeof settings) => void) {
      run(settings);
      return () => {};
    },
  },
}));

import { webThumbnailCandidateUrls } from '../src/lib/webThumbnail';

const IMAGE = 'https://media.example.com/thumb.jpg';

describe('web thumbnails', () => {
  beforeEach(() => {
    settings.imgproxy = { enabled: true, url: '', key: '', salt: '' };
  });

  it('fetches through the default image proxy first, with the original as fallback', () => {
    const urls = webThumbnailCandidateUrls(IMAGE)!;
    expect(urls).toHaveLength(2);
    expect(urls[0]).toMatch(/^https:\/\/imgproxy\.iris\.to\//);
    expect(urls[1]).toBe(IMAGE);
  });

  it('uses the proxy chosen in settings', () => {
    settings.imgproxy = { enabled: true, url: 'https://proxy.example.org', key: 'aa'.repeat(32), salt: 'bb'.repeat(32) };
    expect(webThumbnailCandidateUrls(IMAGE)![0]).toMatch(/^https:\/\/proxy\.example\.org\//);
  });

  it('loads the original directly when the proxy is switched off', () => {
    settings.imgproxy.enabled = false;
    expect(webThumbnailCandidateUrls(IMAGE)).toEqual([IMAGE]);
  });

  it('leaves hashtree and other non-web URLs alone', () => {
    expect(webThumbnailCandidateUrls('/htree/nhash1abc/thumbnail.jpg')).toBeNull();
    expect(webThumbnailCandidateUrls('htree://nhash1abc/thumbnail.jpg')).toBeNull();
    expect(webThumbnailCandidateUrls(undefined)).toBeNull();
  });
});
