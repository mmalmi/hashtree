import { describe, expect, it } from 'vitest';
import { generateSecretKey, getPublicKey, nip19 } from 'nostr-tools';
import {
  applyCalendarMessage,
  bookingCalendarView,
  changeMessages,
  computeBookingSlots,
  createInitialCalendarData,
  inviteNpub,
  isShownEvent,
  newLinkKey,
  parseCalendarData,
  parseCalendarMessage,
  removeCalendarEvent,
  serializeCalendarData,
  setEventRsvp,
  sharedCalendarView,
  upsertCalendarEvent,
  type CalendarData,
  type CalendarMessage,
} from '../src/lib/calendar';

const npub = () => nip19.npubEncode(getPublicKey(generateSecretKey()));
const alice = npub();
const bob = npub();
const carol = npub();

function send(data: CalendarData, from: string, message: CalendarMessage, sentAt = 5000, now = 6000) {
  // Every message crosses the wire as JSON and is parsed again.
  const parsed = parseCalendarMessage(JSON.parse(JSON.stringify(message)));
  expect(parsed).not.toBeNull();
  return applyCalendarMessage(data, from, parsed!, sentAt, now);
}

function aliceDinner() {
  return upsertCalendarEvent(createInitialCalendarData(alice, 1000), {
    title: 'Dinner',
    start: '2026-12-01T18:00',
    end: '2026-12-01T20:00',
    notes: 'Bring wine',
    guests: [{ npub: bob, status: 'needs-action' }, { npub: carol, status: 'needs-action' }],
  }, alice, 2000);
}

describe('calendar invites', () => {
  it('sends the event to every guest and lands it in their calendar awaiting an answer', () => {
    const organizer = aliceDinner();
    const dinner = organizer.events[0]!;
    const outgoing = changeMessages(undefined, dinner);
    expect(outgoing.map(item => item.to).sort()).toEqual([bob, carol].sort());

    const { data: bobs } = send(createInitialCalendarData(bob, 1000), alice, outgoing.find(item => item.to === bob)!.message);
    expect(bobs.events).toHaveLength(1);
    expect(bobs.events[0]).toMatchObject({ title: 'Dinner', organizer: alice, rsvp: 'needs-action', notes: 'Bring wine' });
  });

  it('carries answers back to the organizer and ignores older replays', () => {
    const organizer = aliceDinner();
    const dinner = organizer.events[0]!;
    const { data: invited } = send(createInitialCalendarData(bob, 1000), alice, changeMessages(undefined, dinner)[0]!.message);
    const answered = setEventRsvp(invited, dinner.id, 'accepted', bob, 3000);
    const [rsvp] = changeMessages(invited.events[0], answered.events[0]);
    expect(rsvp).toEqual({ to: alice, message: { type: 'rsvp', id: dinner.id, status: 'accepted' } });

    const accepted = send(organizer, bob, rsvp!.message, 5000).data;
    expect(accepted.events[0]!.guests!.find(guest => guest.npub === bob)?.status).toBe('accepted');

    const replayed = send(accepted, bob, { type: 'rsvp', id: dinner.id, status: 'declined' }, 4000).data;
    expect(replayed.events[0]!.guests!.find(guest => guest.npub === bob)?.status).toBe('accepted');
    expect(send(accepted, carol, { type: 'rsvp', id: 'other', status: 'declined' }).data).toBe(accepted);
  });

  it('updates and cancels invites only from their organizer and only forward in time', () => {
    const organizer = aliceDinner();
    const dinner = organizer.events[0]!;
    const message = changeMessages(undefined, dinner)[0]!.message;
    const bobs = send(createInitialCalendarData(bob, 1000), alice, message).data;

    expect(send(bobs, carol, message).data).toBe(bobs);
    expect(send(bobs, alice, message).data).toBe(bobs);

    const moved = upsertCalendarEvent(organizer, { ...dinner, title: 'Late dinner', start: '2026-12-01T20:00', end: '2026-12-01T22:00' }, alice, 9000);
    const updated = send(bobs, alice, changeMessages(dinner, moved.events[0])[0]!.message).data;
    expect(updated.events[0]!.title).toBe('Late dinner');

    const cancelled = removeCalendarEvent(moved, dinner.id, alice, 9500);
    expect(isShownEvent(cancelled.events[0]!)).toBe(false);
    const notices = changeMessages(moved.events[0], cancelled.events[0]);
    expect(notices).toHaveLength(2);
    const gone = send(updated, alice, notices[0]!.message).data;
    expect(gone.events[0]!.cancelled).toBe(true);
  });

  it('tells removed guests the event is off and keeps my private answer out of invites', () => {
    const organizer = aliceDinner();
    const dinner = organizer.events[0]!;
    const withoutCarol = upsertCalendarEvent(organizer, { ...dinner, guests: [{ npub: bob, status: 'needs-action' }] }, alice, 3000);
    const messages = changeMessages(dinner, withoutCarol.events[0]);
    const toCarol = messages.find(item => item.to === carol)!.message as Extract<CalendarMessage, { type: 'invite' }>;
    expect(toCarol.event.cancelled).toBe(true);
    expect(messages.find(item => item.to === bob)!.message).not.toHaveProperty('event.cancelled', true);
    expect(toCarol.event).not.toHaveProperty('rsvp');
  });

  it('declining an invite keeps a hidden tombstone so replays cannot bring it back', () => {
    const dinner = aliceDinner().events[0]!;
    const message = changeMessages(undefined, dinner)[0]!.message;
    const bobs = send(createInitialCalendarData(bob, 1000), alice, message).data;
    const removed = removeCalendarEvent(bobs, dinner.id, bob, 4000);
    expect(isShownEvent(removed.events[0]!)).toBe(false);
    expect(send(removed, alice, message).data).toBe(removed);
  });
});

describe('calendar booking and sharing', () => {
  const day = new Date(2026, 11, 7);
  const now = new Date(2026, 11, 1).getTime();
  const book = (start: Date, id = 'booking-1'): CalendarMessage => ({
    type: 'book', id, slug: 'meet', name: 'Bob', note: 'Hi',
    start: start.toISOString(), end: new Date(start.getTime() + 30 * 60_000).toISOString(),
  });

  it('confirms a free booking request once and invites the guest back', () => {
    const owner = createInitialCalendarData(alice, now);
    const slot = new Date(computeBookingSlots(owner, owner.bookingLinks[0]!.id, day, now)[0]!.start);
    const { data, replies } = send(owner, bob, book(slot), 5000, now);
    expect(data.events[0]).toMatchObject({ title: 'Meet: Bob', guests: [{ npub: bob, status: 'accepted' }] });
    expect(data.events[0]!.cancelled).toBeUndefined();
    expect(replies).toHaveLength(1);
    expect(computeBookingSlots(data, owner.bookingLinks[0]!.id, day, now).map(item => item.start)).not.toContain(slot.toISOString());
    expect(send(data, bob, book(slot), 5000, now).data).toBe(data);

    const guest = send(createInitialCalendarData(bob, now), alice, replies[0]!.message, 5000, now).data;
    expect(guest.events[0]).toMatchObject({ organizer: alice, rsvp: 'accepted' });
  });

  it('turns down requests for taken or unavailable slots', () => {
    const owner = createInitialCalendarData(alice, now);
    const slot = new Date(computeBookingSlots(owner, owner.bookingLinks[0]!.id, day, now)[0]!.start);
    const first = send(owner, bob, book(slot), 5000, now).data;
    const { data, replies } = send(first, carol, book(slot, 'booking-2'), 5000, now);
    expect(data.events.find(event => event.id === 'booking-2')?.cancelled).toBe(true);
    expect((replies[0]!.message as Extract<CalendarMessage, { type: 'invite' }>).event.cancelled).toBe(true);
    const midnight = send(owner, bob, book(new Date(2026, 11, 7, 0, 0)), 5000, now);
    expect(midnight.data.events[0]!.cancelled).toBe(true);
  });

  it('offers slots from the owner time zone to viewers elsewhere', () => {
    const owner = createInitialCalendarData(alice, now);
    owner.availability = { ...owner.availability, timezone: 'Pacific/Kiritimati', minimumNoticeMinutes: 0 };
    const slots = computeBookingSlots(owner, owner.bookingLinks[0]!.id, new Date(2026, 11, 8), now);
    const hours = slots.map(slot => new Intl.DateTimeFormat('en-US', { timeZone: 'Pacific/Kiritimati', hour: 'numeric', hourCycle: 'h23' }).format(new Date(slot.start)));
    expect(slots.length).toBeGreaterThan(0);
    expect(hours.every(hour => Number(hour) >= 9 && Number(hour) < 17)).toBe(true);
  });

  it('shares busy times without details, and full events without private fields', () => {
    const owner = { ...aliceDinner(), shareKey: newLinkKey(), bookingKey: newLinkKey(), sharedWith: [bob] };
    const busy = bookingCalendarView(owner, new Date(2026, 10, 20).getTime());
    expect(busy.events.map(event => event.title)).toEqual(['Busy']);
    expect(JSON.stringify(busy)).not.toContain('Bring wine');
    expect(busy.bookingKey).toBeUndefined();

    const shared = parseCalendarData(serializeCalendarData(sharedCalendarView(owner)), alice)!;
    expect(shared.events[0]!.notes).toBe('Bring wine');
    expect(shared.shareKey).toBeUndefined();
    expect(shared.sharedWith).toEqual([]);
  });

  it('subscribes to shared calendars and keeps the newest key', () => {
    const first = newLinkKey();
    const second = newLinkKey();
    const bobs = createInitialCalendarData(bob, now);
    expect(send(bobs, alice, { type: 'share', title: 'Alice' }).data.subscriptions).toEqual([]);
    const added = send(bobs, alice, { type: 'share', title: 'Alice', key: first }, 5000).data;
    const rotated = send(added, alice, { type: 'share', title: 'Alice', key: second }, 7000).data;
    expect(rotated.subscriptions).toMatchObject([{ npub: alice, key: second, title: 'Alice' }]);
    expect(send(rotated, alice, { type: 'share', title: 'Alice', key: first }, 6000).data).toBe(rotated);
    expect(send(rotated, alice, { type: 'share', title: 'Alice' }, 8000).data.subscriptions).toEqual([]);
    expect(parseCalendarData(serializeCalendarData(rotated), bob)!.subscriptions[0]!.key).toBe(second);
  });

  it('remembers withdrawals across reloads and out-of-order delivery, including before the first share', () => {
    const empty = createInitialCalendarData(bob, now);
    const grant = { type: 'share' as const, title: 'Alice', key: newLinkKey() };
    const withdraw = { type: 'share' as const, title: 'Alice' };
    for (const state of [empty, send(empty, alice, grant, 5000).data, send(empty, alice, grant, 7000).data]) {
      const revoked = send(state, alice, withdraw, 7000).data;
      const loaded = parseCalendarData(serializeCalendarData(revoked), bob)!;
      expect(send(loaded, alice, grant, 5000).data).toBe(loaded);
      expect(send(loaded, alice, grant, 7000).data).toBe(loaded);
      expect(send(loaded, alice, grant, 8000).data.subscriptions).toHaveLength(1);
      expect(JSON.stringify(bookingCalendarView(loaded, now))).not.toContain(alice);
      expect(JSON.stringify(sharedCalendarView(loaded))).not.toContain(alice);
    }
  });
});

describe('all-day events across time zones', () => {
  it('keep their calendar days when read elsewhere', () => {
    const data = upsertCalendarEvent(createInitialCalendarData(alice, 1000), {
      title: 'Holiday', start: '2026-06-15', end: '2026-06-16', allDay: true,
      guests: [{ npub: bob, status: 'needs-action' }],
    }, alice, 2000);
    const saved = JSON.parse(serializeCalendarData(data));
    expect(saved.events[0]).toMatchObject({ day: '2026-06-15', days: 2 });

    // Another zone stored a different instant for the same days; the dates win.
    saved.events[0].start = '2026-06-14T21:00:00.000Z';
    saved.events[0].end = '2026-06-16T21:00:00.000Z';
    const parsed = parseCalendarData(saved, alice)!.events[0]!;
    expect(new Date(parsed.start)).toEqual(new Date(2026, 5, 15));
    expect(new Date(parsed.end)).toEqual(new Date(2026, 5, 17));

    const invite = changeMessages(undefined, data.events[0])[0]!.message as Extract<CalendarMessage, { type: 'invite' }>;
    expect(JSON.parse(JSON.stringify(invite)).event).toMatchObject({ day: '2026-06-15', days: 2 });
  });
});

describe('invite links', () => {
  it('lets anyone holding the link answer, and tells link holders who is coming', () => {
    const key = newLinkKey();
    const organizer = upsertCalendarEvent(createInitialCalendarData(alice, 1000), {
      title: 'Party', start: '2026-12-05T19:00', end: '2026-12-05T23:00', inviteKey: key,
    }, alice, 2000);
    const party = organizer.events[0]!;
    expect(changeMessages(undefined, party).map(item => item.to)).toEqual([inviteNpub(key)]);

    const { data, replies } = send(organizer, carol, { type: 'rsvp', id: party.id, status: 'accepted', invite: key, name: 'Carol' });
    expect(data.events[0]!.guests).toMatchObject([{ npub: carol, status: 'accepted', name: 'Carol' }]);
    expect(replies.map(item => item.to)).toEqual([inviteNpub(key)]);
    expect((replies[0]!.message as Extract<CalendarMessage, { type: 'invite' }>).event.guests).toHaveLength(1);
    expect(send(organizer, bob, { type: 'rsvp', id: party.id, status: 'accepted', invite: newLinkKey() }).data).toBe(organizer);

    // Turning the link off closes it for link holders without cancelling for guests.
    const off = upsertCalendarEvent(data, { ...data.events[0]!, inviteKey: undefined }, alice, 7000);
    const notices = changeMessages(data.events[0], off.events[0]);
    expect(notices.find(item => item.to === inviteNpub(key))!.message).toHaveProperty('event.cancelled', true);
    expect(notices.find(item => item.to === carol)!.message).not.toHaveProperty('event.cancelled', true);
  });

  it('closes the link when an event is deleted before anyone answers', () => {
    const key = newLinkKey();
    const owner = upsertCalendarEvent(createInitialCalendarData(alice, 1000), {
      title: 'Party', start: '2026-12-05T19:00', end: '2026-12-05T23:00', inviteKey: key,
    }, alice, 2000);
    const party = owner.events[0]!;
    const deleted = removeCalendarEvent(owner, party.id, alice, 3000);
    const notices = changeMessages(party, deleted.events[0]);
    expect(notices).toMatchObject([{ to: inviteNpub(key), message: { event: { cancelled: true, updatedAt: 3000 } } }]);
    expect(deleted.events.filter(isShownEvent)).toEqual([]);
  });

  it('sends only the prior event to recipients removed during an edit or link rotation', () => {
    const oldKey = newLinkKey();
    const newKey = newLinkKey();
    const owner = aliceDinner();
    const before = { ...owner.events[0]!, inviteKey: oldKey };
    const after = { ...before, inviteKey: newKey, notes: 'New venue', guests: before.guests!.slice(0, 1), updatedAt: 4000 };
    const notices = changeMessages(before, after);
    for (const to of [carol, inviteNpub(oldKey)]) {
      const notice = notices.find(item => item.to === to)!.message;
      expect(notice).toMatchObject({ event: { cancelled: true, updatedAt: 4000, notes: before.notes } });
      expect(notice).not.toHaveProperty('event.inviteKey');
    }
    expect(notices.find(item => item.to === inviteNpub(newKey))!.message).toHaveProperty('event.notes', 'New venue');
  });

  it('keeps the link secret out of shared calendar copies', () => {
    const owner = upsertCalendarEvent(createInitialCalendarData(alice, 1000), {
      title: 'Party', start: '2026-12-05T19:00', end: '2026-12-05T23:00', inviteKey: newLinkKey(),
    }, alice, 2000);
    expect(sharedCalendarView(owner).events[0]!.inviteKey).toBeUndefined();
  });
});
