import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  runAllReleases,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

describe('calendar release-site', () => {
  it('uses the built-in Worker default and custom domain for calendar', () => {
    const parsed = parseArgs(['calendar']);
    expect(parsed.workerName).toBe('iris-calendar');
    expect(parsed.treeName).toBe('calendar');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual(['calendar.iris.to']);
  });

  it('rejects profiles that are no longer part of this standalone app', () => {
    expect(() => parseArgs(['docs'])).toThrow('Unknown release profile: docs');
  });

  it('deploys the built calendar output through the HTTPS redirect asset Worker', () => {
    const plan = createReleasePlan({
      profileName: 'calendar',
      workerName: 'iris-calendar',
      routes: [],
      domains: ['calendar.iris.to'],
      treeName: 'calendar',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.profile.distDir).toBe('dist-calendar');
    expect(plan.steps.map((step) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'test-6',
      'test-7',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-calendar',
      '--name',
      'iris-calendar',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--domain',
      'calendar.iris.to',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-calendar',
      '--name',
      'iris-calendar',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-calendar',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist-calendar',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('stops before publish when a release test step fails', async () => {
    const calls: string[] = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-1') {
        expect(step.command).toEqual(['node', './scripts/smoke-graph-policy.mjs', 'calendar']);
        return { status: 1, stdout: '', stderr: 'calendar tests failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(
      runRelease(
        {
          profileName: 'calendar',
          workerName: 'iris-calendar',
          treeName: 'calendar',
          skipCloudflare: false,
          workerCompatibilityDate: '2026-03-19',
        },
        runner,
        { buildOutputExists: () => true },
      ),
    ).rejects.toThrow('Test Iris Calendar (1/7) failed with exit code 1');
    expect(calls).toEqual(['build', 'test-1']);
  });

  it('treats all as the single calendar release in this repo', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/calendar\nnhash1calendar',
          stderr: '',
        };
      }
      if (step.id === 'deploy') {
        return {
          status: 0,
          stdout: 'https://calendar.iris.to',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runAllReleases(
      {
        profileName: 'all',
        dryRun: false,
        skipCloudflare: false,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles[0]?.profile.name).toBe('calendar');
  });
});
