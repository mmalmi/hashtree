import { expect, it } from 'vitest';
import { fromHex, HashTree, MemoryStore, toHex, visibilityHex } from '@hashtree/core';
import { createNativeHtreeUrl, decodeNativeResolvedRoot, mapNativeDirEntries } from '../src/nativeAdapterHelpers';
import { hashFromHex, isLinkSecretHex, recoverSharingSecret, unmaskObjectKey } from '../src/lib/hashtreeKeys';

const legacy = '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824';
const chkHash = '70b977414934faa6270f323f117d05dbcc412e9d7ba2354b4d0f88f60aad2461';
const chkBlob = 'c65308d9c8649ff1c59820d0b3a030db34ad00f92d';
const random = '02'.repeat(33);
const rndHash = '819b3a52aa2550b762399299892a6b613b7071c57d95787a1915310afd50fc7b';
const rndBlob = '000102030405060708090a0b216d8e96be582844fc3a4e2a23eecfbe1a29cd5b6b';

it.each([
  [legacy, chkHash, chkBlob],
  ['01' + legacy, chkHash, chkBlob],
  [random, rndHash, rndBlob],
])('reads the published hello fixture through directory listings and immutable URLs (%s)', async (key, hash, blob) => {
  const store = new MemoryStore();
  await store.put(hashFromHex(hash), fromHex(blob));
  const [{ cid }] = mapNativeDirEntries({ entries: [{ name: 'hello', key, hash }] });
  const url = createNativeHtreeUrl('https://example.org', cid);
  const root = decodeNativeResolvedRoot({ cid: url.split('/').pop() });
  expect(root).toEqual(cid);
  expect(new TextDecoder().decode((await new HashTree({ store }).readFile(root!))!)).toBe('hello');
});

it.each([legacy, '01' + legacy, random])('recovers both opaque sharing values for %s', async key => {
  const secret = 'fe'.repeat(key.length / 2);
  const masked = visibilityHex.encryptKeyForLink(key, secret);
  expect(recoverSharingSecret(key, masked)).toBe(secret);
  expect(toHex((await unmaskObjectKey(masked, secret))!)).toBe(key);
});

it('preserves a legacy sharing secret across CHK writes and rejects incompatible randomized updates', async () => {
  const secret = 'fa'.repeat(32);
  const masked = visibilityHex.encryptKeyForLink('01' + legacy, secret);
  expect(recoverSharingSecret('01' + legacy, masked)).toBe(secret);
  expect(toHex((await unmaskObjectKey(masked, secret))!)).toBe(legacy);
  expect(() => visibilityHex.encryptKeyForLink(random, secret)).toThrow();
});

it('rejects bad object suites, masks and hash widths while preserving opaque secrets', async () => {
  const opaque = 'fe'.repeat(33);
  expect(isLinkSecretHex(opaque)).toBe(true);
  expect(() => mapNativeDirEntries({ entries: [{ name: 'x', hash: chkHash, key: opaque }] })).toThrow();
  expect(() => mapNativeDirEntries({ entries: [{ name: 'x', hash: opaque }] })).toThrow();
  expect(await unmaskObjectKey('gg'.repeat(33), opaque)).toBeNull();
});

it('keeps randomized calendar data and unrelated files on an edit', async () => {
  const { vi } = await import('vitest');
  const tree = new HashTree({ store: new MemoryStore() });
  vi.doMock('../src/store', () => ({ getTree: () => tree }));
  vi.doMock('../src/nostr', () => ({
    saveHashtree: async () => ({ success: true }),
    useNostrStore: { getState: () => ({ npub: 'owner' }) },
  }));
  const { loadCalendarData, saveCalendarData } = await import('../src/lib/calendar/storage');
  const { createInitialCalendarData } = await import('../src/lib/calendar/model');
  const { LinkType, encryptionMode } = await import('@hashtree/core');
  const randomWriter = new HashTree({ store: tree.getStore(), encryptionMode: 'rnd-v1' });
  const body = createInitialCalendarData('owner');
  const file = await randomWriter.putFile(new TextEncoder().encode(JSON.stringify(body)));
  const note = await tree.putFile(new Uint8Array([1, 2, 3]));
  const { cid } = await tree.putDirectory([
    { name: 'calendar.json', ...file, type: LinkType.File },
    { name: 'notes', ...note, type: LinkType.File },
  ]);
  const { rootCid, success } = await saveCalendarData(body, cid);
  expect(success).toBe(true);
  const entry = await tree.resolvePath(rootCid, ['calendar.json']);
  expect(encryptionMode(entry!.cid.key!)).toBe('rnd-v1');
  expect((await tree.resolvePath(rootCid, ['notes']))?.cid).toEqual(note.cid);
  expect((await loadCalendarData({ hash: rootCid.hash, encryptionKey: rootCid.key }, 'owner')).ownerNpub).toBe('owner');
});
