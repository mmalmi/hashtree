import { beforeEach, expect, it, vi } from 'vitest';
import { objectKeyFromHex, toHex, visibilityHex } from '@hashtree/core';
import { saveHashtree } from '../src/nostr/trees';
import { unmaskObjectKey } from '../src/lib/hashtreeKeys';

const fixture = vi.hoisted(() => ({
  npub: 'owner', treeName: 'saved', params: new URLSearchParams(), stored: '',
  publish: vi.fn(), update: vi.fn(),
}));
vi.mock('../src/nostr/store', () => ({ nostrStore: { getState: () => ({ npub: 'owner', pubkey: 'aa'.repeat(32) }) } }));
vi.mock('../src/nostr/client', () => ({ nostr: {} }));
vi.mock('../src/utils/git', () => ({ isGitRepo: async () => false }));
vi.mock('../src/utils/route', () => ({ parseRoute: () => fixture }));
vi.mock('../src/treeRootCache', () => ({ updateLocalRootCache: fixture.update }));
vi.mock('../src/refResolver', () => ({ getRefResolver: () => ({ publish: fixture.publish }) }));
vi.mock('../src/stores/trees', () => ({
  getLinkKey: () => fixture.stored || null, waitForLinkKeysCache: async () => {},
}));

const hash = new Uint8Array(32);
const keyBytes = 'ab'.repeat(32);
beforeEach(() => {
  fixture.treeName = 'saved';
  fixture.params = new URLSearchParams();
  fixture.stored = '';
  fixture.publish.mockReset().mockResolvedValue({ success: true });
  fixture.update.mockClear();
});

it.each([['01', 32], ['01', 33], ['02', 33]] as const)('reuses the stored secret when publishing suite %s with a %i-byte link', async (suite, size) => {
  const secret = 'ff'.repeat(size);
  fixture.stored = secret;
  fixture.params.set('k', '98'.repeat(size));
  const root = { hash, key: objectKeyFromHex(suite + keyBytes) };
  const result = await saveHashtree('saved', root, { visibility: 'link-visible' });
  expect(result.success).toBe(true);
  const [name, updated, options] = fixture.publish.mock.calls[0];
  expect(name).toBe('owner/saved');
  expect(toHex(options.linkKey)).toBe(secret);
  const masked = visibilityHex.encryptKeyForLink(toHex(updated.key), toHex(options.linkKey));
  expect(toHex((await unmaskObjectKey(masked, secret))!)).toBe(size === 32 ? keyBytes : suite + keyBytes);
});

it('refuses to use the current URL secret for a different tree', async () => {
  fixture.treeName = 'other';
  fixture.params.set('k', 'fe'.repeat(33));
  expect((await saveHashtree('saved', { hash, key: objectKeyFromHex('02' + keyBytes) }, { visibility: 'link-visible' })).success).toBe(false);
  expect(fixture.publish).not.toHaveBeenCalled();
  expect(fixture.update).not.toHaveBeenCalled();
});

it('rejects a randomized update under a legacy link before caching or publishing', async () => {
  fixture.stored = 'ab'.repeat(32);
  await expect(saveHashtree('saved', { hash, key: objectKeyFromHex('02' + keyBytes) }, { visibility: 'link-visible' })).rejects.toThrow();
  expect(fixture.update).not.toHaveBeenCalled();
  expect(fixture.publish).not.toHaveBeenCalled();
});
