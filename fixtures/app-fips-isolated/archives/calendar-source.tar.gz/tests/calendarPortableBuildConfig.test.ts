import { mkdtemp, readFile, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { describe, expect, it } from 'vitest';
import { calendarPortableBuild, portableAssetBase, rewritePortableEntryHtml, sanitizePortableHtml } from '../portableViteConfig';

describe('calendar portable build config', () => {
  it('uses a relative asset base for calendar builds served from htree trees', () => {
    expect(portableAssetBase).toBe('./');
    expect(calendarPortableBuild.outDir).toBe('dist-calendar');
    expect(calendarPortableBuild.modulePreload).toBe(false);
  });

  it('strips module preload and crossorigin hints for htree webviews', () => {
    const sanitized = sanitizePortableHtml(`
      <script type="module" crossorigin src="./assets/main.js"></script>
      <link rel="modulepreload" crossorigin href="./assets/vendor.js">
      <link rel="stylesheet" crossorigin href="./assets/main.css">
    `);

    expect(sanitized).not.toContain('modulepreload');
    expect(sanitized).not.toContain('crossorigin');
    expect(sanitized).toContain('<script type="module" src="./assets/main.js"></script>');
    expect(sanitized).toContain('<link rel="stylesheet" href="./assets/main.css">');
  });

  it('rewrites calendar.html into sanitized index.html for htree publishing', async () => {
    const buildDir = await mkdtemp(join(tmpdir(), 'calendar-portable-build-'));
    const sourcePath = join(buildDir, 'calendar.html');
    const targetPath = join(buildDir, 'index.html');

    await writeFile(
      sourcePath,
      [
        '<!doctype html>',
        '<script type="module" crossorigin src="./assets/main.js"></script>',
        '<link rel="modulepreload" crossorigin href="./assets/vendor.js">',
        '<link rel="stylesheet" crossorigin href="./assets/main.css">',
      ].join('\n'),
      'utf8',
    );

    await rewritePortableEntryHtml(buildDir, 'calendar.html');

    const rewritten = await readFile(targetPath, 'utf8');
    expect(rewritten).toContain('<script type="module" src="./assets/main.js"></script>');
    expect(rewritten).toContain('<link rel="stylesheet" href="./assets/main.css">');
    expect(rewritten).not.toContain('modulepreload');
    expect(rewritten).not.toContain('crossorigin');
  });
});
