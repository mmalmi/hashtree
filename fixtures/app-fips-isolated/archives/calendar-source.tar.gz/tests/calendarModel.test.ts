import { describe, expect, it } from 'vitest';
import {
  addBookingLink,
  buildWeekAllDaySegments,
  buildTimedEventSegments,
  computeBookingSlots,
  createInitialCalendarData,
  dateNumberLabel,
  eventDateLabel,
  eventTimeLabel,
  eventsForDay,
  findNextBookingDate,
  formatCalendarRoute,
  applyImportedCalendarEvents,
  makeEventDraft,
  monthMatrix,
  parseCalendarFile,
  parseDateInputValue,
  parseCalendarData,
  parseCalendarViewRoute,
  removeCalendarEvent,
  serializeCalendarData,
  serializeCalendarIcs,
  toDateInputValue,
  uniqueEventsForDays,
  upsertCalendarEvent,
  updateAvailability,
  weekDays,
  yearMonths,
} from '../src/lib/calendar';

const ownerNpub = 'npub1calendarowner';

describe('calendar model', () => {
  it('formats and parses Google-style calendar view routes', () => {
    const date = new Date(2026, 5, 18);

    expect(formatCalendarRoute('week', date)).toBe('/week/2026/6/18');
    expect(formatCalendarRoute('year', date)).toBe('/year/2026');
    expect(parseCalendarViewRoute('/agenda/2026/6/18')?.view).toBe('agenda');
    expect(toDateInputValue(parseCalendarViewRoute('/agenda/2026/6/18')!.date)).toBe('2026-06-18');
    expect(parseCalendarViewRoute('/month/2026/13/1')).toBeNull();
    expect(parseCalendarViewRoute('/event/2026/6/18')).toBeNull();
  });

  it('round-trips normalized calendar data', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Planning',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
      color: 'green',
      location: 'Iris',
      recurrence: { frequency: 'weekly', interval: 2, until: '2026-07-27' },
    }, ownerNpub, 2000);

    const parsed = parseCalendarData(serializeCalendarData(saved), ownerNpub);

    expect(parsed?.ownerNpub).toBe(ownerNpub);
    expect(parsed?.events).toHaveLength(1);
    expect(parsed?.events[0]?.title).toBe('Planning');
    expect(parsed?.events[0]?.color).toBe('green');
    expect(parsed?.events[0]?.recurrence).toEqual({ frequency: 'weekly', interval: 2, until: '2026-07-27' });
    expect(parsed?.bookingLinks[0]?.slug).toBe('meet');
  });

  it('parses saved calendar JSON returned as file bytes', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Byte-backed event',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
    }, ownerNpub, 2000);

    const raw = new TextEncoder().encode(serializeCalendarData(saved));
    const parsed = parseCalendarData(raw, ownerNpub);

    expect(parsed?.events).toHaveLength(1);
    expect(parsed?.events[0]?.title).toBe('Byte-backed event');
  });

  it('removes events by id without mutating unrelated events', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'First',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
    }, ownerNpub, 1100);
    data = upsertCalendarEvent(data, {
      title: 'Second',
      start: '2026-06-15T10:00',
      end: '2026-06-15T10:30',
    }, ownerNpub, 1200);

    const removed = removeCalendarEvent(data, data.events[0]!.id, ownerNpub, 1300);

    expect(removed.events.map(event => event.title)).toEqual(['Second']);
    expect(removed.updatedAt).toBe(1300);
  });

  it('stores all-day events as local day ranges with exclusive end dates', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Away',
      start: '2026-06-15',
      end: '2026-06-17',
      allDay: true,
    }, ownerNpub, 2000);

    const event = saved.events[0]!;
    expect(event.allDay).toBe(true);
    expect(toDateInputValue(new Date(event.start))).toBe('2026-06-15');
    expect(toDateInputValue(new Date(event.end))).toBe('2026-06-18');
    expect(saved.events.map(item => item.title)).toEqual(['Away']);
  });

  it('keeps one-day all-day events on the selected date only', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Holiday',
      start: '2026-06-15',
      end: '2026-06-15',
      allDay: true,
    }, ownerNpub, 2000);

    expect(eventsForDay(saved.events, new Date('2026-06-15T12:00:00'))).toHaveLength(1);
    expect(eventsForDay(saved.events, new Date('2026-06-16T12:00:00'))).toHaveLength(0);
  });

  it('keeps timed events inside the exact local day when the query date has a time', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'Tomorrow',
      start: '2026-06-16T09:00',
      end: '2026-06-16T09:30',
    }, ownerNpub, 2000);

    expect(eventsForDay(data.events, new Date('2026-06-15T12:00:00'))).toHaveLength(0);
    expect(eventsForDay(data.events, new Date('2026-06-16T12:00:00'))).toHaveLength(1);
  });

  it('counts multi-day events once across a visible range', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Retreat',
      start: '2026-06-16',
      end: '2026-06-18',
      allDay: true,
    }, ownerNpub, 2000);

    expect(uniqueEventsForDays(saved.events, weekDays(new Date('2026-06-15T12:00:00'), 'monday')).map(event => event.title))
      .toEqual(['Retreat']);
  });

  it('expands weekly recurring events through the inclusive end date', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Standup',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
      recurrence: { frequency: 'weekly', interval: 1, until: '2026-06-29' },
    }, ownerNpub, 2000);

    expect(eventsForDay(saved.events, new Date('2026-06-15T12:00:00'))).toHaveLength(1);
    expect(eventsForDay(saved.events, new Date('2026-06-22T12:00:00'))[0]?.recurrenceSourceId).toBe(saved.events[0]!.id);
    expect(eventsForDay(saved.events, new Date('2026-06-29T12:00:00'))).toHaveLength(1);
    expect(eventsForDay(saved.events, new Date('2026-07-06T12:00:00'))).toHaveLength(0);
  });

  it('blocks booking slots on recurring event occurrences', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = updateAvailability(data, {
      ...data.availability,
      slotDurationMinutes: 30,
      minimumNoticeMinutes: 0,
      rules: data.availability.rules.map(rule => rule.weekday === 1
        ? { ...rule, enabled: true, startTime: '09:00', endTime: '10:00' }
        : { ...rule, enabled: false }),
    }, ownerNpub, 1100);
    data = upsertCalendarEvent(data, {
      title: 'Weekly busy',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
      recurrence: { frequency: 'weekly', interval: 1 },
    }, ownerNpub, 1200);

    const slots = computeBookingSlots(data, data.bookingLinks[0]!.id, new Date('2026-06-22T00:00:00'), Date.parse('2026-06-14T00:00:00Z'));

    expect(slots.map(slot => new Date(slot.start).toTimeString().slice(0, 5))).toEqual(['09:30']);
  });

  it('expands daily, monthly, and yearly recurrence options', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'Every other day',
      start: '2026-06-15T09:00',
      end: '2026-06-15T09:30',
      recurrence: { frequency: 'daily', interval: 2, until: '2026-06-19' },
    }, ownerNpub, 2000);
    data = upsertCalendarEvent(data, {
      title: 'Month end',
      start: '2026-01-31T09:00',
      end: '2026-01-31T09:30',
      recurrence: { frequency: 'monthly', interval: 1, until: '2026-03-31' },
    }, ownerNpub, 2100);
    data = upsertCalendarEvent(data, {
      title: 'Leap day',
      start: '2024-02-29T09:00',
      end: '2024-02-29T09:30',
      recurrence: { frequency: 'yearly', interval: 1, until: '2026-02-28' },
    }, ownerNpub, 2200);

    expect(eventsForDay(data.events, new Date('2026-06-17T12:00:00')).map(event => event.title)).toEqual(['Every other day']);
    expect(eventsForDay(data.events, new Date('2026-06-18T12:00:00')).map(event => event.title)).toEqual([]);
    expect(eventsForDay(data.events, new Date('2026-02-28T12:00:00')).map(event => event.title).sort()).toEqual(['Leap day', 'Month end']);
    expect(eventsForDay(data.events, new Date('2026-03-31T12:00:00')).map(event => event.title)).toEqual(['Month end']);
  });

  it('imports common iCalendar invite events with recurrence details', () => {
    const imported = parseCalendarFile(`BEGIN:VCALENDAR
VERSION:2.0
METHOD:REQUEST
BEGIN:VEVENT
UID:standup@example.com
SUMMARY:Weekly\\, Planning
DTSTART;TZID=Europe/Helsinki:20260615T090000
DTEND;TZID=Europe/Helsinki:20260615T093000
RRULE:FREQ=WEEKLY;INTERVAL=1;UNTIL=20260629
LOCATION:Iris HQ
DESCRIPTION:Bring\\nnotes
END:VEVENT
END:VCALENDAR`, 'invite.ics', 1000);

    expect(imported.format).toBe('ics');
    expect(imported.events).toHaveLength(1);
    expect(imported.events[0]?.title).toBe('Weekly, Planning');
    expect(imported.events[0]?.location).toBe('Iris HQ');
    expect(imported.events[0]?.notes).toBe('Bring\nnotes');
    expect(imported.events[0]?.recurrence).toEqual({ frequency: 'weekly', interval: 1, until: '2026-06-29' });

    const data = applyImportedCalendarEvents(createInitialCalendarData(ownerNpub, 1000), imported.events, ownerNpub, 2000);
    expect(eventsForDay(data.events, new Date('2026-06-22T12:00:00')).map(event => event.title)).toEqual(['Weekly, Planning']);
  });

  it('accepts older vCalendar file extensions when the contents are calendar events', () => {
    const imported = parseCalendarFile(`BEGIN:VCALENDAR
VERSION:1.0
BEGIN:VEVENT
UID:vcal@example.com
SUMMARY:Legacy invite
DTSTART:20260618T100000Z
DURATION:PT45M
END:VEVENT
END:VCALENDAR`, 'legacy.vcs', 1000);

    expect(imported.format).toBe('ics');
    expect(imported.events[0]?.title).toBe('Legacy invite');
    expect(new Date(imported.events[0]!.end).getTime() - new Date(imported.events[0]!.start).getTime()).toBe(45 * 60 * 1000);
  });

  it('exports calendar events as iCalendar that can be imported again', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'Portable planning',
      start: '2026-06-18T13:00',
      end: '2026-06-18T13:30',
      location: 'Iris Meet',
      notes: 'Bring agenda',
      recurrence: { frequency: 'weekly', interval: 2, until: '2026-07-16' },
    }, ownerNpub, 2000);

    const exported = serializeCalendarIcs(data.events, { calendarName: 'Iris Calendar', now: 3000 });
    const imported = parseCalendarFile(exported, 'iris-calendar.ics', 4000);

    expect(exported).toContain('BEGIN:VCALENDAR');
    expect(exported).toContain('RRULE:FREQ=WEEKLY;INTERVAL=2;UNTIL=20260716');
    expect(imported.events[0]?.title).toBe('Portable planning');
    expect(imported.events[0]?.location).toBe('Iris Meet');
    expect(imported.events[0]?.recurrence).toEqual({ frequency: 'weekly', interval: 2, until: '2026-07-16' });
    expect(new Date(imported.events[0]!.start).getTime()).toBe(new Date(data.events[0]!.start).getTime());
  });

  it('imports Google-style CSV calendar files', () => {
    const imported = parseCalendarFile(`Subject,Start Date,Start Time,End Date,End Time,All Day Event,Description,Location
"CSV Workshop","06/18/2026","1:00 PM","06/18/2026","2:15 PM","False","Bring slides","Iris Meet"`, 'google.csv', 1000);

    expect(imported.format).toBe('csv');
    expect(imported.events).toHaveLength(1);
    expect(imported.events[0]?.title).toBe('CSV Workshop');
    expect(imported.events[0]?.location).toBe('Iris Meet');
    expect(new Date(imported.events[0]!.start).getHours()).toBe(13);
    expect(new Date(imported.events[0]!.end).getMinutes()).toBe(15);
  });

  it('builds one week segment for a multi-day all-day event', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Retreat',
      start: '2026-06-16',
      end: '2026-06-18',
      allDay: true,
    }, ownerNpub, 2000);

    const segments = buildWeekAllDaySegments(
      saved.events,
      weekDays(new Date('2026-06-15T12:00:00'), 'monday')
    );

    expect(segments.map(segment => ({
      title: segment.event.title,
      startIndex: segment.startIndex,
      endIndex: segment.endIndex,
      lane: segment.lane,
    }))).toEqual([
      { title: 'Retreat', startIndex: 1, endIndex: 4, lane: 0 },
    ]);
  });

  it('places overlapping all-day week segments on separate lanes', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'Retreat',
      start: '2026-06-16',
      end: '2026-06-18',
      allDay: true,
    }, ownerNpub, 2000);
    data = upsertCalendarEvent(data, {
      title: 'Workshop',
      start: '2026-06-17',
      end: '2026-06-17',
      allDay: true,
    }, ownerNpub, 2100);
    data = upsertCalendarEvent(data, {
      title: 'Release',
      start: '2026-06-19',
      end: '2026-06-19',
      allDay: true,
    }, ownerNpub, 2200);

    const segments = buildWeekAllDaySegments(
      data.events,
      weekDays(new Date('2026-06-15T12:00:00'), 'monday')
    );

    expect(segments.map(segment => [segment.event.title, segment.startIndex, segment.endIndex, segment.lane]))
      .toEqual([
        ['Retreat', 1, 4, 0],
        ['Workshop', 2, 3, 1],
        ['Release', 4, 5, 0],
      ]);
  });

  it('places overlapping timed events on separate lanes', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = upsertCalendarEvent(data, {
      title: 'Focus',
      start: '2026-06-15T09:00',
      end: '2026-06-15T10:00',
    }, ownerNpub, 2000);
    data = upsertCalendarEvent(data, {
      title: 'Call',
      start: '2026-06-15T09:30',
      end: '2026-06-15T10:30',
    }, ownerNpub, 2100);
    data = upsertCalendarEvent(data, {
      title: 'Lunch',
      start: '2026-06-15T10:30',
      end: '2026-06-15T11:00',
    }, ownerNpub, 2200);

    expect(buildTimedEventSegments(data.events).map(segment => [
      segment.event.title,
      segment.lane,
      segment.laneCount,
    ])).toEqual([
      ['Focus', 0, 2],
      ['Call', 1, 2],
      ['Lunch', 0, 1],
      ]);
  });

  it('labels agenda all-day events without midnight times', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const saved = upsertCalendarEvent(data, {
      title: 'Away',
      start: '2026-06-15',
      end: '2026-06-17',
      allDay: true,
    }, ownerNpub, 2000);
    const event = saved.events[0]!;

    expect(eventDateLabel(event)).toContain('Jun 15');
    expect(eventDateLabel(event)).toContain('Jun 17');
    expect(eventTimeLabel(event)).toBe('All day');
  });

  it('computes booking slots from availability while excluding event conflicts and buffers', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = updateAvailability(data, {
      ...data.availability,
      slotDurationMinutes: 30,
      bufferBeforeMinutes: 15,
      bufferAfterMinutes: 15,
      minimumNoticeMinutes: 0,
      rules: data.availability.rules.map(rule => rule.weekday === 1
        ? { ...rule, enabled: true, startTime: '09:00', endTime: '11:00' }
        : { ...rule, enabled: false }),
    }, ownerNpub, 1100);
    data = upsertCalendarEvent(data, {
      title: 'Busy',
      start: '2026-06-15T09:30',
      end: '2026-06-15T10:00',
    }, ownerNpub, 1200);

    const slots = computeBookingSlots(data, data.bookingLinks[0]!.id, new Date('2026-06-15T00:00:00'), Date.parse('2026-06-14T00:00:00Z'));

    expect(slots.map(slot => new Date(slot.start).toTimeString().slice(0, 5))).toEqual(['10:30']);
  });

  it('finds the next bookable date after unavailable days', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const nextDate = findNextBookingDate(
      data,
      data.bookingLinks[0]!.id,
      new Date('2026-06-14T00:00:00'),
      Date.parse('2026-06-14T00:00:00Z'),
    );

    expect(nextDate && toDateInputValue(nextDate)).toBe('2026-06-15');
  });

  it('normalizes unsafe availability durations before slot generation', () => {
    const data = createInitialCalendarData(ownerNpub, 1000);
    const normalized = updateAvailability(data, {
      ...data.availability,
      slotDurationMinutes: 0,
      rules: data.availability.rules.map(rule => rule.weekday === 1
        ? { ...rule, enabled: true, startTime: '09:00', endTime: '09:15' }
        : { ...rule, enabled: false }),
    }, ownerNpub, 1100);

    expect(normalized.availability.slotDurationMinutes).toBe(5);
    expect(computeBookingSlots({
      ...normalized,
      availability: { ...normalized.availability, slotDurationMinutes: 0 },
    }, normalized.bookingLinks[0]!.id, new Date('2026-06-15T00:00:00'), Date.parse('2026-06-14T00:00:00Z'))).toEqual([]);
  });

  it('keeps booking link slugs unique', () => {
    let data = createInitialCalendarData(ownerNpub, 1000);
    data = addBookingLink(data, ownerNpub, 1100);

    expect(data.bookingLinks.map(link => link.slug)).toEqual(['meet', 'meet-2']);
  });

  it('computes week and year calendar ranges', () => {
    expect(weekDays(new Date('2026-06-11T12:00:00'), 'monday').map(toDateInputValue))
      .toEqual(['2026-06-08', '2026-06-09', '2026-06-10', '2026-06-11', '2026-06-12', '2026-06-13', '2026-06-14']);
    expect(weekDays(new Date('2026-06-11T12:00:00'), 'sunday').map(toDateInputValue))
      .toEqual(['2026-06-07', '2026-06-08', '2026-06-09', '2026-06-10', '2026-06-11', '2026-06-12', '2026-06-13']);
    expect(yearMonths(new Date('2026-06-11T12:00:00')).map(date => date.getMonth()))
      .toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
  });

  it('formats sidebar date chips without leading zero padding', () => {
    expect(dateNumberLabel(new Date('2026-06-08T12:00:00'))).toBe('8');
    expect(dateNumberLabel(new Date('2026-06-15T12:00:00'))).toBe('15');
  });

  it('starts date-only drafts during the workday while preserving clicked hours', () => {
    expect(makeEventDraft(new Date(2030, 5, 17, 0, 0, 0, 0)).start).toBe('2030-06-17T09:00');
    expect(makeEventDraft(new Date(2030, 5, 17, 14, 0, 0, 0)).start).toBe('2030-06-17T14:00');
  });

  it('parses date input values as local calendar days', () => {
    const parsed = parseDateInputValue('2026-06-15');

    expect(parsed?.getFullYear()).toBe(2026);
    expect(parsed?.getMonth()).toBe(5);
    expect(parsed?.getDate()).toBe(15);
    expect(parsed?.getHours()).toBe(0);
    expect(parseDateInputValue('2026-02-31')).toBeNull();
  });

  it('keeps local calendar days unique across DST transitions', () => {
    const october = monthMatrix(new Date(2026, 9, 1), 'monday').map(toDateInputValue);
    const october25Count = october.filter(day => day === '2026-10-25').length;
    const dstWeek = weekDays(new Date(2026, 9, 29), 'monday').map(toDateInputValue);

    expect(new Set(october).size).toBe(october.length);
    expect(october25Count).toBe(1);
    expect(new Set(dstWeek).size).toBe(dstWeek.length);
  });
});
