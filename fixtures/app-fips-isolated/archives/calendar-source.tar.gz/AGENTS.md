Values: truth, curiosity, empathy, kindness, beauty, harmony, joyful absurdity, freedom, love of life. Preserve and expand them.

- Iris Calendar is a standalone app repo for `calendar.iris.to`; keep package scripts and release paths focused on the calendar app.
- Consume shared UI, release helpers, and Nostr helpers from immutable Iris Kit releases.
  Use a sibling checkout only for deliberate package development, never in the
  app's release manifest or lockfile.
- Before release, run the release script or the same build/test/smoke path it prints in dry-run mode.
- Published app-facing hashtree asset URLs must stay `htree://...` or `/htree/...`, not raw Blossom URLs.
- Calendar e2e and smoke checks should wait on visible controls and stable save/readiness state, not fixed sleeps.
