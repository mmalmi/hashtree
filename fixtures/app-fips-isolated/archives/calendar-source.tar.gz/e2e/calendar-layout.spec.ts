import { test, expect, type Page } from './fixtures';
import { disableOthersPool, ensureLoggedIn, openCalendarCreateEvent, setupPageErrorHandler, waitForAppReady } from './test-utils';

async function expectNoPageHorizontalOverflow(page: Page) {
  const overflow = await page.evaluate(() => {
    const root = document.documentElement;
    const body = document.body;
    return {
      rootOverflow: root.scrollWidth - root.clientWidth,
      bodyOverflow: body.scrollWidth - body.clientWidth,
      rootScrollWidth: root.scrollWidth,
      rootClientWidth: root.clientWidth,
      bodyScrollWidth: body.scrollWidth,
      bodyClientWidth: body.clientWidth,
    };
  });

  expect(overflow.rootOverflow, JSON.stringify(overflow)).toBeLessThanOrEqual(1);
  expect(overflow.bodyOverflow, JSON.stringify(overflow)).toBeLessThanOrEqual(1);
}

async function openView(page: Page, view: 'Day' | 'Week' | 'Month' | 'Year' | 'Agenda') {
  await page.getByRole('button', { name: 'Calendar view' }).click();
  await page.getByRole('menuitemradio', { name: view }).click();
}

async function calendarShellScrollTop(page: Page) {
  return page.locator('main.calendar-shell').evaluate((shell: HTMLElement) => shell.scrollTop);
}

async function expectMobileCalendarGridFullBleed(page: Page) {
  const gridBounds = await page.getByTestId('calendar-grid').evaluate((grid: HTMLElement) => {
    const box = grid.getBoundingClientRect();
    return {
      left: box.left,
      right: box.right,
      width: box.width,
      viewportWidth: window.innerWidth,
    };
  });

  expect(gridBounds.left, JSON.stringify(gridBounds)).toBeGreaterThanOrEqual(-1);
  expect(gridBounds.left, JSON.stringify(gridBounds)).toBeLessThanOrEqual(1);
  expect(gridBounds.right, JSON.stringify(gridBounds)).toBeGreaterThanOrEqual(gridBounds.viewportWidth - 1);
  expect(gridBounds.right, JSON.stringify(gridBounds)).toBeLessThanOrEqual(gridBounds.viewportWidth + 1);
}

async function elementRect(page: Page, testId: string) {
  return page.getByTestId(testId).evaluate((element: HTMLElement) => {
    const rect = element.getBoundingClientRect();
    return {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height,
    };
  });
}

test.describe('Iris Calendar responsive layout', () => {
  test.beforeEach(async ({ page }) => {
    await page.clock.setFixedTime(new Date('2026-06-15T06:00:00+03:00'));
  });

  test('sidebar create button hover keeps the button geometry stable', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const createButton = page.getByTestId('calendar-sidebar-create-button');
    await expect(createButton).toBeVisible({ timeout: 30000 });
    const before = await elementRect(page, 'calendar-sidebar-create-button');

    await createButton.hover();
    await page.evaluate(() => new Promise<void>((resolve) => {
      requestAnimationFrame(() => requestAnimationFrame(resolve));
    }));

    const after = await elementRect(page, 'calendar-sidebar-create-button');
    expect(after.x, JSON.stringify({ before, after })).toBeCloseTo(before.x, 3);
    expect(after.y, JSON.stringify({ before, after })).toBeCloseTo(before.y, 3);
    expect(after.width, JSON.stringify({ before, after })).toBeCloseTo(before.width, 3);
    expect(after.height, JSON.stringify({ before, after })).toBeCloseTo(before.height, 3);
  });

  test('logged-in account button opens settings in the standalone calendar app', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: 'Settings' }).click();
    await expect(page).toHaveURL(/#\/settings$/);
    await expect(page.getByRole('heading', { name: 'Settings' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('settings-nav-app')).toBeVisible({ timeout: 15000 });
  });

  test('narrow calendar routes avoid page-level horizontal overflow', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByRole('link', { name: 'Calendar' })).toBeVisible({ timeout: 30000 });
    await expect(page.getByTestId('calendar-grid')).toBeVisible({ timeout: 30000 });
    await expectMobileCalendarGridFullBleed(page);
    await expectNoPageHorizontalOverflow(page);

    await page.getByRole('button', { name: '15', exact: true }).first().click();
    await openView(page, 'Day');
    await expect(page.getByTestId('calendar-day-view')).toBeVisible({ timeout: 15000 });
    await expectNoPageHorizontalOverflow(page);

    await openView(page, 'Week');
    await expect(page.getByTestId('calendar-week-view')).toBeVisible({ timeout: 15000 });
    await expectNoPageHorizontalOverflow(page);

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: 'Calendar view' })).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'Today' })).toHaveCount(0);
    await expect(page.getByTestId('calendar-sidebar-create-button')).toHaveCount(0);
    await expectNoPageHorizontalOverflow(page);
  });

  test('narrow week view scrolls the selected day into the current lane', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByTestId('calendar-grid').getByRole('button', { name: '21', exact: true }).click();
    await openView(page, 'Week');
    await expect(page.getByTestId('calendar-week-view')).toBeVisible({ timeout: 15000 });

    const scrollState = await page.getByTestId('calendar-week-scroll').evaluate((scroll: HTMLElement) => {
      const selectedHead = scroll.querySelector<HTMLElement>('.week-day-head-selected');
      const scrollBox = scroll.getBoundingClientRect();
      const selectedBox = selectedHead?.getBoundingClientRect();
      return {
        scrollLeft: scroll.scrollLeft,
        scrollLeftEdge: scrollBox.left,
        scrollRightEdge: scrollBox.right,
        selectedLeft: selectedBox?.left ?? 0,
        selectedRight: selectedBox?.right ?? 0,
      };
    });

    expect(scrollState.scrollLeft, JSON.stringify(scrollState)).toBeGreaterThan(0);
    expect(scrollState.selectedLeft, JSON.stringify(scrollState)).toBeGreaterThanOrEqual(scrollState.scrollLeftEdge - 1);
    expect(scrollState.selectedRight, JSON.stringify(scrollState)).toBeLessThanOrEqual(scrollState.scrollRightEdge + 1);
    await expectNoPageHorizontalOverflow(page);
  });

  test('narrow week view keeps partially clipped all-day labels readable', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `Conference ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByLabel('All day').check();
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-16');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-18');
    await page.getByTestId('calendar-event-save').click();

    await page.getByRole('button', { name: '18', exact: true }).first().click();
    await openView(page, 'Week');
    await expect(page.getByTestId('calendar-week-view')).toBeVisible({ timeout: 15000 });

    const labelState = await page.getByTestId('calendar-week-scroll').evaluate((scroll: HTMLElement, eventTitle: string) => {
      const event = Array.from(scroll.querySelectorAll<HTMLElement>('[data-testid="calendar-week-all-day-event"]'))
        .find(element => element.textContent?.includes(eventTitle));
      const titleElement = event?.querySelector<HTMLElement>('.week-all-day-event-title') ?? null;
      const scrollBox = scroll.getBoundingClientRect();
      const eventBox = event?.getBoundingClientRect();
      const titleBox = titleElement?.getBoundingClientRect();
      return {
        eventLeft: eventBox?.left ?? 0,
        eventRight: eventBox?.right ?? 0,
        scrollLeftEdge: scrollBox.left,
        scrollRightEdge: scrollBox.right,
        titleLeft: titleBox?.left ?? 0,
        titleRight: titleBox?.right ?? 0,
      };
    }, title);

    expect(labelState.eventLeft, JSON.stringify(labelState)).toBeLessThan(labelState.scrollLeftEdge);
    expect(labelState.eventRight, JSON.stringify(labelState)).toBeGreaterThan(labelState.scrollLeftEdge);
    expect(labelState.titleLeft, JSON.stringify(labelState)).toBeGreaterThanOrEqual(labelState.scrollLeftEdge - 1);
    expect(labelState.titleRight, JSON.stringify(labelState)).toBeLessThanOrEqual(labelState.scrollRightEdge + 1);
  });

  test('day and week views show a current time marker on today', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: 'Today' }).click();
    await openView(page, 'Day');
    await expect(page.getByTestId('calendar-day-now-line')).toBeVisible({ timeout: 15000 });
    const dayTop = await page.getByTestId('calendar-day-now-line').evaluate((line: HTMLElement) => parseFloat(line.style.top));
    expect(dayTop).toBeGreaterThanOrEqual(0);
    expect(dayTop).toBeLessThanOrEqual(100);

    await openView(page, 'Week');
    await expect(page.getByTestId('calendar-week-now-line')).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-week-now-line')).toHaveCount(1);
    const weekTop = await page.getByTestId('calendar-week-now-line').evaluate((line: HTMLElement) => parseFloat(line.style.top));
    expect(weekTop).toBeGreaterThanOrEqual(0);
    expect(weekTop).toBeLessThanOrEqual(100);
  });

  test('route changes reset calendar shell scroll', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.locator('main.calendar-shell').evaluate((shell: HTMLElement) => {
      shell.style.height = '320px';
      shell.style.overflow = 'auto';
      (shell.firstElementChild as HTMLElement | null)?.style.setProperty('min-height', '1200px');
      shell.scrollTop = 420;
    });
    await expect.poll(() => calendarShellScrollTop(page)).toBeGreaterThan(100);

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });
    await expect.poll(() => calendarShellScrollTop(page), { timeout: 10000 }).toBe(0);
  });

  test('calendar view routes restore view and date and update while navigating', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/week/2026/6/18');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('calendar-week-view')).toBeVisible({ timeout: 30000 });
    await expect(page).toHaveURL(/#\/week\/2026\/6\/18$/);

    await openView(page, 'Day');
    await expect(page.getByTestId('calendar-day-view')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('heading', { name: 'Thursday, June 18' })).toBeVisible({ timeout: 15000 });
    await expect(page).toHaveURL(/#\/day\/2026\/6\/18$/);

    await page.getByRole('button', { name: 'Next range' }).click();
    await expect(page.getByRole('heading', { name: 'Friday, June 19' })).toBeVisible({ timeout: 15000 });
    await expect(page).toHaveURL(/#\/day\/2026\/6\/19$/);

    await openView(page, 'Agenda');
    await expect(page.getByTestId('calendar-agenda-view')).toBeVisible({ timeout: 15000 });
    await expect(page).toHaveURL(/#\/agenda\/2026\/6\/19$/);

    await page.evaluate(() => { window.location.hash = '#/month/2026/7/1'; });
    await expect(page.getByTestId('calendar-grid')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('.calendar-range-title')).toHaveText('July 2026');

    await page.evaluate(() => { window.location.hash = '#/year/2027'; });
    await expect(page.getByTestId('calendar-year-view')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('.calendar-range-title')).toHaveText('2027');
  });

  test('narrow booking slot selection keeps the form usable without overflow', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });
    await page.clock.setFixedTime(new Date('2026-06-15T08:00:00+03:00'));

    await page.goto('/calendar.html#/book/meet');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('booking-date-input')).toHaveValue('2026-06-15', { timeout: 15000 });
    await expectNoPageHorizontalOverflow(page);

    await page.getByRole('button', { name: '10:00 AM - 10:30 AM' }).evaluate((button: HTMLButtonElement) => {
      button.click();
    });
    await expect(page.getByTestId('booking-confirm-form')).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('booking-guest-name-input')).toBeFocused();
    await expect(page.getByTestId('booking-book-button')).toBeVisible();
    const formBox = await page.getByTestId('booking-confirm-form').boundingBox();
    expect(formBox?.y ?? -1).toBeGreaterThanOrEqual(0);
    expect(formBox?.y ?? 844).toBeLessThan(844);
    await expectNoPageHorizontalOverflow(page);
  });

  test('narrow event editor and date picker stay usable without overflow', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await openCalendarCreateEvent(page);
    await expect(page.getByRole('dialog', { name: 'New Event' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-event-title-input')).toBeFocused();
    await expect(page.getByTestId('calendar-event-save')).toBeVisible();
    await expectNoPageHorizontalOverflow(page);

    const saveBox = await page.getByTestId('calendar-event-save').boundingBox();
    expect(saveBox?.y ?? -1).toBeGreaterThanOrEqual(0);
    expect(saveBox ? saveBox.y + saveBox.height : 845).toBeLessThanOrEqual(844);

    await page.getByRole('button', { name: 'Choose start date' }).click();
    const pickerBox = await page.getByRole('group', { name: 'Start date picker' }).boundingBox();
    expect(pickerBox?.x ?? -1).toBeGreaterThanOrEqual(0);
    expect(pickerBox ? pickerBox.x + pickerBox.width : 391).toBeLessThanOrEqual(390);
    expect(pickerBox?.y ?? -1).toBeGreaterThanOrEqual(0);
    expect(pickerBox ? pickerBox.y + pickerBox.height : 845).toBeLessThanOrEqual(844);
    await expectNoPageHorizontalOverflow(page);
  });

  test('narrow year and agenda views stay readable without overflow', async ({ page }) => {
    setupPageErrorHandler(page);
    await page.setViewportSize({ width: 390, height: 844 });

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '24h' }).click();

    const title = `Mobile Agenda ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-18');
    await page.getByTestId('calendar-event-start-time-input').fill('13:00');
    await page.getByTestId('calendar-event-end-time-input').fill('13:30');
    await page.getByRole('textbox', { name: 'Location' }).fill('Iris Meet');
    await page.getByTestId('calendar-event-save').click();

    await openView(page, 'Year');
    await expect(page.getByTestId('calendar-year-view')).toBeVisible({ timeout: 15000 });
    await expectNoPageHorizontalOverflow(page);
    await expect(page.getByRole('button', { name: 'June 18, 2026, 1 event' })).toBeVisible({ timeout: 15000 });

    await openView(page, 'Agenda');
    await expect(page.getByTestId('calendar-agenda-view')).toBeVisible({ timeout: 15000 });
    await expectNoPageHorizontalOverflow(page);

    const agendaEvent = page.getByTestId('calendar-agenda-view').getByRole('button', {
      name: new RegExp(`${title}.*Jun 18.*13:00 - 13:30.*Iris Meet`),
    });
    await expect(agendaEvent).toBeVisible({ timeout: 15000 });
    await expect(agendaEvent).toHaveText(new RegExp(`^13:00 - 13:30\\s+${title}\\s+Iris Meet$`));

    const rowLayout = await agendaEvent.evaluate((row: HTMLElement) => {
      const main = row.querySelector<HTMLElement>('.agenda-row-main');
      const time = row.querySelector<HTMLElement>('.agenda-time');
      const titleElement = row.querySelector<HTMLElement>('.agenda-title');
      const rowBox = row.getBoundingClientRect();
      const mainBox = main?.getBoundingClientRect();
      const timeBox = time?.getBoundingClientRect();
      const titleBox = titleElement?.getBoundingClientRect();
      return {
        rowLeft: rowBox.left,
        rowRight: rowBox.right,
        mainLeft: mainBox?.left ?? 0,
        mainRight: mainBox?.right ?? 0,
        timeLeft: timeBox?.left ?? 0,
        timeRight: timeBox?.right ?? 0,
        titleLeft: titleBox?.left ?? 0,
        titleRight: titleBox?.right ?? 0,
      };
    });

    expect(rowLayout.mainLeft, JSON.stringify(rowLayout)).toBeGreaterThanOrEqual(rowLayout.rowLeft - 1);
    expect(rowLayout.mainRight, JSON.stringify(rowLayout)).toBeLessThanOrEqual(rowLayout.rowRight + 1);
    expect(rowLayout.timeLeft, JSON.stringify(rowLayout)).toBeLessThan(rowLayout.titleLeft);
    expect(rowLayout.titleRight, JSON.stringify(rowLayout)).toBeLessThanOrEqual(rowLayout.rowRight + 1);
  });
});
