import { test, expect, type Page } from './fixtures';
import type { Browser } from '@playwright/test';
import { disableOthersPool, ensureLoggedIn, openCalendarCreateEvent, setupPageErrorHandler, waitForAppReady } from './test-utils';

const blossomUrl = process.env.PW_TEST_BLOSSOM_URL ?? 'http://127.0.0.1:18780';

async function openUser(browser: Browser, nsec?: string) {
  const context = await browser.newContext();
  const page = await context.newPage();
  setupPageErrorHandler(page);
  await page.goto('/calendar.html#/');
  await waitForAppReady(page);
  await disableOthersPool(page);
  await page.evaluate((url) => {
    (window as any).__configureBlossomServers([{ url, read: true, write: true }]);
  }, blossomUrl);
  await ensureLoggedIn(page, 30000);
  if (nsec) {
    // Switch the fresh device to the existing account, as the login screen does.
    await page.evaluate(async (key) => {
      const { loginWithNsec } = await import('/src/nostr.ts');
      await loginWithNsec(key);
    }, nsec);
  }
  await expect(page.getByTestId('calendar-sidebar-create-button')).toBeVisible({ timeout: 30000 });
  const npub = await page.evaluate(() => (window as any).__nostrStore.getState().npub as string);
  return { context, page, npub };
}

async function createEvent(page: Page, title: string, guest?: string) {
  await openCalendarCreateEvent(page);
  await page.getByTestId('calendar-event-title-input').fill(title);
  if (guest) {
    await page.getByRole('textbox', { name: 'Guests' }).fill(guest);
    await page.getByRole('textbox', { name: 'Guests' }).press('Enter');
    await expect(page.getByRole('list', { name: 'Guests' }).getByRole('listitem')).toHaveCount(1);
  }
  await page.getByTestId('calendar-event-save').click();
  await expect(page.getByTestId('calendar-save-status')).toHaveText('Saved', { timeout: 30000 });
}

async function searchCalendar(page: Page, text: string) {
  await page.getByRole('textbox', { name: 'Search calendar' }).fill(text);
  return page.locator('.calendar-list-row').filter({ hasText: text });
}

test.describe('Iris Calendar between people', () => {
  test.setTimeout(150000);

  test('invites a guest who answers, and the organizer sees the answer', async ({ browser }) => {
    const alice = await openUser(browser);
    const bob = await openUser(browser);

    await createEvent(alice.page, 'Dinner E2E', bob.npub);

    const invitation = bob.page.getByTestId('calendar-invitations').getByRole('button', { name: /Dinner E2E/ });
    await expect(invitation).toBeVisible({ timeout: 60000 });
    await invitation.click();
    const details = bob.page.getByTestId('event-details');
    await expect(details.getByText('Organizer')).toBeVisible();
    await details.getByRole('button', { name: 'Yes' }).click();
    await expect(bob.page.getByTestId('calendar-invitations')).toHaveCount(0);

    await expect(async () => {
      await alice.page.keyboard.press('Escape');
      await (await searchCalendar(alice.page, 'Dinner E2E')).first().click();
      await expect(alice.page.getByRole('list', { name: 'Guests' }).getByText('Going')).toBeVisible({ timeout: 2000 });
    }).toPass({ timeout: 60000 });

    await alice.context.close();
    await bob.context.close();
  });

  test('invites by link: anyone with it can answer, and everyone sees who is coming', async ({ browser }) => {
    const alice = await openUser(browser);
    const carol = await openUser(browser);

    await openCalendarCreateEvent(alice.page);
    await alice.page.getByTestId('calendar-event-title-input').fill('Link Party E2E');
    await alice.page.getByTestId('calendar-event-invite-link').click();
    await expect(alice.page.getByTestId('calendar-event-invite-link')).toHaveText(/Link copied/);
    const url = await alice.page.evaluate(() => navigator.clipboard.readText());
    expect(url).toContain(`/#/invite/${alice.npub}?k=`);
    await alice.page.getByTestId('calendar-event-save').click();
    await expect(alice.page.getByTestId('calendar-save-status')).toHaveText('Saved', { timeout: 30000 });

    await carol.page.goto(`/calendar.html${url.slice(url.indexOf('#'))}`);
    const invite = carol.page.getByTestId('invite-page');
    await expect(invite.getByText('Link Party E2E')).toBeVisible({ timeout: 60000 });
    await carol.page.getByTestId('invite-name-input').fill('Carol');
    await invite.getByRole('button', { name: 'Yes' }).click();
    await expect(carol.page.getByTestId('invite-answered')).toBeVisible();
    await expect(invite.getByText('Carol')).toBeVisible({ timeout: 60000 });
    await expect(invite.getByText('Going', { exact: true })).toBeVisible();

    await expect(async () => {
      await alice.page.keyboard.press('Escape');
      await (await searchCalendar(alice.page, 'Link Party E2E')).first().click();
      await expect(alice.page.getByRole('list', { name: 'Guests' }).getByText('Carol')).toBeVisible({ timeout: 2000 });
    }).toPass({ timeout: 60000 });

    await carol.page.getByRole('link', { name: 'Open calendar' }).click();
    await expect(carol.page.getByTestId('calendar-event-pill').or(carol.page.locator('.week-event')).filter({ hasText: 'Link Party E2E' }).first()).toBeVisible();

    await alice.context.close();
    await carol.context.close();
  });

  test('shares a calendar that the other person sees and can hide', async ({ browser }) => {
    const alice = await openUser(browser);
    const bob = await openUser(browser);

    await createEvent(alice.page, 'Shared Lunch E2E');
    await alice.page.getByRole('button', { name: 'Share calendar' }).click();
    const dialog = alice.page.getByTestId('share-calendar-dialog');
    await dialog.getByRole('textbox', { name: 'People with access' }).fill(bob.npub);
    await dialog.getByRole('textbox', { name: 'People with access' }).press('Enter');
    await expect(dialog.getByRole('listitem')).toHaveCount(1);
    await dialog.getByRole('button', { name: 'Close' }).click();
    await expect(alice.page.getByText('shared with 1')).toBeVisible();

    const toggle = bob.page.getByRole('checkbox', { name: 'Show calendar' });
    await expect(toggle).toBeVisible({ timeout: 60000 });
    await expect(bob.page.getByTestId('calendar-event-pill').filter({ hasText: 'Shared Lunch E2E' })).toBeVisible({ timeout: 60000 });
    await toggle.uncheck();
    await expect(bob.page.getByTestId('calendar-event-pill').filter({ hasText: 'Shared Lunch E2E' })).toHaveCount(0);

    await alice.context.close();
    await bob.context.close();
  });

  test('books a slot on someone else\'s booking page', async ({ browser }) => {
    const alice = await openUser(browser);
    const bob = await openUser(browser);

    await alice.page.locator('.calendar-list-row').filter({ hasText: 'Booking page' }).click();
    await expect(alice.page.getByTestId('calendar-save-status')).toHaveText(/Link copied|Saved|Saving/, { timeout: 30000 });
    const url = await alice.page.evaluate(() => navigator.clipboard.readText());
    expect(url).toContain(`/#/book/${alice.npub}/meet?k=`);

    await bob.page.goto(`/calendar.html${url.slice(url.indexOf('#'))}`);
    const slot = bob.page.locator('.slot-button').first();
    await expect(slot).toBeVisible({ timeout: 60000 });
    await slot.click();
    await bob.page.getByTestId('booking-guest-name-input').fill('Bob');
    await bob.page.getByTestId('booking-book-button').click();
    await expect(bob.page.getByTestId('booking-confirmed')).toContainText('Requested');

    await expect(async () => {
      await expect(await searchCalendar(alice.page, 'Meet: Bob')).toHaveCount(1, { timeout: 2000 });
    }).toPass({ timeout: 60000 });

    await alice.context.close();
    await bob.context.close();
  });

  test('opens the same calendar on a second device', async ({ browser }) => {
    const first = await openUser(browser);
    await createEvent(first.page, 'Second Device E2E');
    const nsec = await first.page.evaluate(async () => (await import('/src/nostr.ts')).getNsec());
    expect(nsec).toBeTruthy();

    const second = await openUser(browser, nsec!);
    expect(second.npub).toBe(first.npub);
    await expect(async () => {
      await expect(await searchCalendar(second.page, 'Second Device E2E')).toHaveCount(1, { timeout: 2000 });
    }).toPass({ timeout: 60000 });

    await first.context.close();
    await second.context.close();
  });
});
