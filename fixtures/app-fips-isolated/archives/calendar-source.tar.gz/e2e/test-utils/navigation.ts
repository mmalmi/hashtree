import { evaluateWithRetry } from './core';

/**
 * Ensure a user is logged in (create a new account if needed).
 */
export async function ensureLoggedIn(page: any, timeoutMs: number = 15000) {
  const hasLoggedInPubkey = () => evaluateWithRetry(page, () => {
    const nostrStore = (window as any).__nostrStore;
    return (nostrStore?.getState?.().pubkey?.length ?? 0) === 64;
  }, undefined).catch(() => false);
  const alreadyLoggedIn = await hasLoggedInPubkey();

  if (!alreadyLoggedIn) {
    await evaluateWithRetry(page, () => {
      void import('/src/nostr.ts')
        .then(({ generateNewKey }) => generateNewKey())
        .catch((err) => console.error('[test-utils] generateNewKey failed', err));
    }, undefined);
  }

  await page.waitForFunction(() => {
    const nostrStore = (window as any).__nostrStore;
    return nostrStore?.getState()?.pubkey?.length === 64;
  }, { timeout: timeoutMs });
}
