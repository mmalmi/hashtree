import { evaluateWithRetry, waitForAppShell, waitForOptionalWorkerAdapter, waitForTestHelpers } from './core';

/**
 * Wait for at least one relay connection.
 * Use this before tests that require Nostr publishes to be queryable by other users.
 */
export async function waitForRelayConnected(page: any, timeoutMs: number = 15000) {
  await waitForTestHelpers(page, timeoutMs);
  await evaluateWithRetry(page, async (fallbackRelay: string) => {
    const win = window as any;
    const { settingsStore } = await import('/src/stores/settings.ts');
    const currentRelays = settingsStore.getState().network.relays ?? [];
    const testRelay = win.__testRelayUrl ?? fallbackRelay;
    const isLocalRelay = (url: string): boolean => {
      try {
        const parsed = new URL(url);
        return ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
      } catch {
        return false;
      }
    };
    const relays = testRelay && (currentRelays.length === 0 || currentRelays.every(isLocalRelay))
      ? [testRelay]
      : currentRelays;

    if (relays.length > 0) {
      settingsStore.setNetworkSettings({ relays });
      const adapter = win.__getWorkerAdapter?.();
      await Promise.resolve(adapter?.setRelays?.(relays)).catch(() => {});
    }
  }, getTestRelayUrl()).catch(() => {});
  await page.waitForFunction(
    async (fallbackRelay: string) => {
      const win = window as any;
      const store = win.__nostrStore;
      if ((store?.getState?.().connectedRelays ?? 0) > 0) {
        return true;
      }

      const adapter = win.__getWorkerAdapter?.();
      if (!adapter) {
        return false;
      }

      const { settingsStore } = await import('/src/stores/settings.ts');
      const currentRelays = settingsStore.getState().network.relays ?? [];
      const testRelay = win.__testRelayUrl ?? fallbackRelay;
      const isLocalRelay = (url: string): boolean => {
        try {
          const parsed = new URL(url);
          return ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
        } catch {
          return false;
        }
      };
      const relays = testRelay && (currentRelays.length === 0 || currentRelays.every(isLocalRelay))
        ? [testRelay]
        : currentRelays;
      const relayKey = JSON.stringify(relays);
      if (relays.length > 0 && win.__lastRelayWaitTarget !== relayKey) {
        win.__lastRelayWaitTarget = relayKey;
        await Promise.resolve(adapter.setRelays?.(relays)).catch(() => {});
      }

      const stats = await adapter.getRelayStats?.().catch(() => []);
      const connectedRelays = Array.isArray(stats)
        ? stats.filter((relay: { connected?: boolean }) => relay.connected).length
        : 0;
      if (connectedRelays > 0) {
        store?.setConnectedRelays?.(connectedRelays);
        return true;
      }
      return false;
    },
    getTestRelayUrl(),
    { timeout: timeoutMs }
  );
}

/**
 * Disable FIPS peer networking for isolated single-page tests.
 * This prevents the app from connecting to peers from other parallel tests.
 * Use this for tests that don't need cross-device connections but might be
 * affected by incoming data from parallel test instances.
 *
 * IMPORTANT: Call this BEFORE any navigation or state changes in the test.
 */
export async function disableOthersPool(page: any) {
  await waitForAppShell(page);
  await waitForOptionalWorkerAdapter(page);
  await evaluateWithRetry(page, async () => {
    const win = window as any;
    let adapter = win.__getWorkerAdapter?.();
    if (!adapter) {
      const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
      adapter = getWorkerAdapter();
    }
    const { stopDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    await stopDriveFipsRuntime();
    adapter?.setP2PProvider?.(null);
  }, undefined);
}

export function getTestRelayUrl(): string {
  return process.env.PW_TEST_RELAY_URL || process.env.VITE_TEST_RELAY || 'ws://localhost:4736';
}
