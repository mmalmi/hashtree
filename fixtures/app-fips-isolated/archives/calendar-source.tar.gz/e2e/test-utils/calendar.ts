import { expect } from '../fixtures';

export async function openCalendarCreateEvent(page: any) {
  const createButton = page.getByTestId('calendar-sidebar-create-button');
  await expect(createButton).toBeVisible({ timeout: 30000 });
  await createButton.click();

  const createMenu = page.getByRole('menu', { name: 'Create calendar item' });
  await expect(createMenu).toBeVisible({ timeout: 10000 });
  await createMenu.getByRole('menuitem', { name: 'Event' }).click();
  await expect(page.getByTestId('calendar-event-title-input')).toBeFocused({ timeout: 15000 });
}
