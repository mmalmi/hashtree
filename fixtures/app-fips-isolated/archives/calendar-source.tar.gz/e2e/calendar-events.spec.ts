import { test, expect } from './fixtures';
import { disableOthersPool, ensureLoggedIn, openCalendarCreateEvent, setupPageErrorHandler, waitForAppReady } from './test-utils';

test.describe('Iris Calendar events', () => {
  test.beforeEach(async ({ page }) => {
    await page.clock.setFixedTime(new Date('2026-06-15T06:00:00+03:00'));
  });

  test('saving a future all-day event keeps the user on the event date', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('calendar-sidebar-create-button')).toBeVisible({ timeout: 30000 });

    const title = `All Day E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByRole('button', { name: 'Choose start date' }).click();
    await page.getByRole('button', { name: 'June 16, 2026' }).click();
    await page.getByLabel('All day').check();
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-18');
    await page.getByTestId('calendar-event-save').click();

    await expect(page.locator('.mini-day-selected')).toHaveText('16', { timeout: 15000 });
    await expect(page.getByText('Tuesday, Jun 16')).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-event-pill').filter({ hasText: title }).first()).toBeVisible({ timeout: 15000 });

    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Week' }).click();
    const weekAllDayEvent = page.getByTestId('calendar-week-all-day-event').filter({ hasText: title });
    await expect(weekAllDayEvent).toBeVisible({ timeout: 15000 });
    await expect(weekAllDayEvent).toHaveAttribute('style', /grid-column: 3 \/ 6/);
    const allDayRowBox = await page.getByTestId('calendar-week-all-day-row').boundingBox();
    const allDayLabelBox = await page.getByTestId('calendar-week-all-day-label').boundingBox();
    const allDayEventBox = await weekAllDayEvent.boundingBox();
    expect(allDayRowBox?.height).toBeLessThan(60);
    expect(allDayLabelBox?.y).toBeLessThan((allDayEventBox?.y ?? 0) + 20);

    await weekAllDayEvent.click();
    await expect(page.getByRole('dialog', { name: 'Edit Event' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-event-start-date-input')).toHaveValue('2026-06-16');
    await expect(page.getByTestId('calendar-event-end-date-input')).toHaveValue('2026-06-18');
  });

  test('multi-day all-day events become a single sane timed event when unchecked', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `All Day To Timed E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-16');
    await page.getByLabel('All day').check();
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-18');
    await page.getByTestId('calendar-event-save').click();

    await page.getByTestId('calendar-event-pill').filter({ hasText: title }).first().click();
    await page.getByRole('checkbox', { name: 'All day', exact: true }).uncheck();

    await expect(page.getByTestId('calendar-event-start-date-input')).toHaveValue('2026-06-16');
    await expect(page.getByTestId('calendar-event-start-time-input')).toHaveValue('09:00');
    await expect(page.getByTestId('calendar-event-end-date-input')).toHaveValue('2026-06-16');
    await expect(page.getByTestId('calendar-event-end-time-input')).toHaveValue('09:30');

    await page.getByTestId('calendar-event-save').click();
    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Day' }).click();
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${title}.*9:00 AM - 9:30 AM`) })).toBeVisible({ timeout: 15000 });
  });

  test('week grid hour cells create a timed event at the clicked hour', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Week' }).click();
    await expect(page.getByTestId('calendar-week-view')).toBeVisible({ timeout: 15000 });

    await page.getByRole('button', { name: 'Create event Wed, Jun 17 at 2 PM' }).click();
    await expect(page.getByTestId('calendar-event-title-input')).toBeFocused();
    await expect(page.getByTestId('calendar-event-start-date-input')).toHaveValue('2026-06-17');
    await expect(page.getByTestId('calendar-event-start-time-input')).toHaveValue('14:00');
    await expect(page.getByTestId('calendar-event-end-time-input')).toHaveValue('14:30');

    const title = `Week Grid E2E ${Date.now()}`;
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-save').click();

    const eventButton = page.getByTestId('calendar-week-view').getByRole('button', { name: new RegExp(`${title}.*2:00 PM - 2:30 PM`) });
    await expect(eventButton).toBeVisible({ timeout: 15000 });
  });

  test('saved timed events persist after reload', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `Reload Persist E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await expect(page.getByTestId('calendar-event-title-input')).toBeFocused();
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-19');
    await page.getByTestId('calendar-event-start-time-input').fill('15:00');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-19');
    await page.getByTestId('calendar-event-end-time-input').fill('15:30');
    await page.getByTestId('calendar-event-save').click();

    await expect(page.getByTestId('calendar-save-status')).toHaveText('Saved', { timeout: 30000 });
    await expect(page.getByTestId('calendar-event-pill').filter({ hasText: title })).toBeVisible({ timeout: 15000 });

    await page.reload({ waitUntil: 'domcontentloaded' });
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const reloadedEvent = page.getByTestId('calendar-event-pill').filter({ hasText: title });
    await expect(reloadedEvent).toBeVisible({ timeout: 30000 });
    await expect(reloadedEvent).toHaveText(`3:00 PM ${title}`);
    await expect(page.getByTestId('calendar-save-status')).toHaveCount(0);
  });

  test('weekly recurring events appear on later weeks and edit the series', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `Weekly Recurrence E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-start-time-input').fill('09:00');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-end-time-input').fill('09:30');
    await page.getByTestId('calendar-event-repeat-button').click();
    await page.getByTestId('calendar-event-repeat-option-weekly').click();
    await page.getByTestId('calendar-event-repeat-until-input').fill('2026-06-29');
    await page.getByTestId('calendar-event-save').click();

    const monthEvents = page.getByTestId('calendar-event-pill').filter({ hasText: title });
    await expect(monthEvents).toHaveCount(3, { timeout: 15000 });
    await monthEvents.nth(1).click();

    await expect(page.getByRole('dialog', { name: 'Edit Event' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-event-start-date-input')).toHaveValue('2026-06-15');
    await expect(page.getByTestId('calendar-event-repeat-button')).toContainText('Weekly');
    await expect(page.getByTestId('calendar-event-repeat-until-input')).toHaveValue('2026-06-29');
  });

  test('main toolbar omits calendar file import and export buttons', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('calendar-import-button')).toHaveCount(0);
    await expect(page.getByTestId('calendar-export-button')).toHaveCount(0);
  });

  test('time format setting can switch calendar event labels to 24-hour time', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '24h' }).click();

    const title = `24h Calendar E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-19');
    await page.getByTestId('calendar-event-start-time-input').fill('09:00');
    await page.getByTestId('calendar-event-end-time-input').fill('09:30');
    await page.getByTestId('calendar-event-save').click();

    const monthEvent = page.getByTestId('calendar-event-pill').filter({ hasText: title });
    await expect(monthEvent).toHaveText(`09:00 ${title}`, { timeout: 15000 });

    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Day' }).click();
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${title}.*09:00 - 09:30`) })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '24h', exact: true })).toHaveAttribute('aria-pressed', 'true');
    await expect(page.getByTestId('calendar-save-status')).toHaveText('Saved', { timeout: 30000 });
    await page.reload();
    await waitForAppReady(page);
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${title}.*09:00 - 09:30`) })).toBeVisible({ timeout: 15000 });
  });

  test('all-day toggle preserves timed event hours when toggled back', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `Toggle Time E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-17');
    await page.getByTestId('calendar-event-start-time-input').fill('14:00');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-17');
    await page.getByTestId('calendar-event-end-time-input').fill('15:30');

    await page.getByLabel('All day').check();
    await page.getByLabel('All day').uncheck();

    await expect(page.getByTestId('calendar-event-start-date-input')).toHaveValue('2026-06-17');
    await expect(page.getByTestId('calendar-event-start-time-input')).toHaveValue('14:00');
    await expect(page.getByTestId('calendar-event-end-date-input')).toHaveValue('2026-06-17');
    await expect(page.getByTestId('calendar-event-end-time-input')).toHaveValue('15:30');

    await page.getByTestId('calendar-event-save').click();
    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Day' }).click();
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${title}.*2:00 PM - 3:30 PM`) })).toBeVisible({ timeout: 15000 });
  });

  test('day view events can be edited and deleted', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '16', exact: true }).first().click();
    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Day' }).click();
    await expect(page.getByTestId('calendar-day-view')).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-day-all-day-cell')).toBeEmpty();

    const initialTitle = `Day Edit E2E ${Date.now()}`;
    const editedTitle = `${initialTitle} updated`;

    await page.getByTestId('calendar-day-view').getByRole('button', { name: 'Create event Tuesday, June 16 at 10 AM' }).click();
    await expect(page.getByTestId('calendar-event-title-input')).toBeFocused();
    await page.getByTestId('calendar-event-title-input').fill(initialTitle);
    await page.getByTestId('calendar-event-save').click();

    await page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${initialTitle}.*10:00 AM - 10:30 AM`) }).click();
    await page.getByTestId('calendar-event-title-input').fill(editedTitle);
    await page.getByTestId('calendar-event-start-time-input').fill('11:00');
    await page.getByTestId('calendar-event-end-time-input').fill('11:45');
    await page.getByTestId('calendar-event-save').click();

    const editedEvent = page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${editedTitle}.*11:00 AM - 11:45 AM`) });
    await expect(editedEvent).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${initialTitle}.*10:00 AM - 10:30 AM`) })).toHaveCount(0);

    await editedEvent.click();
    await page.getByRole('button', { name: 'Delete event' }).click();
    await expect(page.getByRole('dialog', { name: 'Edit Event' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Keep event' })).toBeVisible();
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(editedTitle) })).toBeVisible();
    await page.getByRole('button', { name: 'Keep event' }).click();
    await expect(page.getByRole('button', { name: 'Delete event' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Confirm delete event' })).toHaveCount(0);
    await page.getByRole('button', { name: 'Delete event' }).click();
    await page.getByRole('button', { name: 'Confirm delete event' }).click();
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(editedTitle) })).toHaveCount(0, { timeout: 15000 });
  });

  test('year and agenda views navigate back to event details', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const title = `Year Agenda E2E ${Date.now()}`;
    await openCalendarCreateEvent(page);
    const newEventDialog = page.getByRole('dialog', { name: 'New Event' });
    await expect(newEventDialog.getByText('Color')).toBeVisible({ timeout: 15000 });
    await expect(newEventDialog.getByRole('textbox', { name: 'Location' })).toHaveAttribute('placeholder', 'Add location or video call');
    await expect(newEventDialog.getByText('Notes')).toBeVisible();
    await expect(page.locator('select, input[type="date"], input[type="time"], input[type="datetime-local"]')).toHaveCount(0);
    await page.getByTestId('calendar-event-title-input').fill(title);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-18');
    await page.getByTestId('calendar-event-start-time-input').fill('13:00');
    await page.getByTestId('calendar-event-end-time-input').fill('13:30');
    await page.getByRole('textbox', { name: 'Location' }).fill('Iris Meet');
    await page.getByRole('textbox', { name: 'Notes' }).fill('Bring agenda notes');
    await page.getByTestId('calendar-event-save').click();

    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Year' }).click();
    await expect(page.getByTestId('calendar-year-view')).toBeVisible({ timeout: 15000 });

    await page.getByRole('button', { name: 'June 18, 2026, 1 event' }).click();
    await expect(page.getByTestId('calendar-day-view')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('heading', { name: 'Thursday, June 18' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-day-view').getByRole('button', { name: new RegExp(`${title}.*1:00 PM - 1:30 PM`) })).toBeVisible({ timeout: 15000 });

    await page.getByRole('button', { name: 'Calendar view' }).click();
    await page.getByRole('menuitemradio', { name: 'Agenda' }).click();
    await expect(page.getByTestId('calendar-agenda-view')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('heading', { name: 'Calendar' })).toBeVisible();
    await expect(page.locator('.calendar-range-title')).toHaveText('Agenda');
    await expect(page.getByText('Unavailable')).toHaveCount(0);
    await expect(page.getByTestId('calendar-agenda-view').getByText('Thursday, Jun 18')).toBeVisible({ timeout: 15000 });

    const agendaEvent = page.getByTestId('calendar-agenda-view').getByRole('button', { name: new RegExp(`${title}.*Jun 18.*1:00 PM - 1:30 PM.*Iris Meet`) });
    await expect(agendaEvent).toBeVisible({ timeout: 15000 });
    await expect(agendaEvent).toHaveText(new RegExp(`^1:00 PM - 1:30 PM\\s+${title}\\s+Iris Meet$`));
    await agendaEvent.click();
    await expect(page.getByRole('dialog', { name: 'Edit Event' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByTestId('calendar-event-title-input')).toHaveValue(title);
    await expect(page.getByRole('textbox', { name: 'Location' })).toHaveValue('Iris Meet');
    await expect(page.getByRole('textbox', { name: 'Notes' })).toHaveValue('Bring agenda notes');
  });
});
