import { test, expect } from './fixtures';
import { disableOthersPool, ensureLoggedIn, openCalendarCreateEvent, setupPageErrorHandler, waitForAppReady } from './test-utils';

test.describe('Iris Calendar booking links', () => {
  test.beforeEach(async ({ page }) => {
    await page.clock.setFixedTime(new Date('2026-06-15T06:00:00+03:00'));
  });

  test('summary add opens booking details and shows the new link', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('calendar-sidebar-create-button')).toBeVisible({ timeout: 30000 });

    const bookingDetails = page.locator('details').filter({ hasText: /^Booking/ });
    await expect(bookingDetails).toHaveCount(1, { timeout: 30000 });
    await expect(bookingDetails.getByText('1 link')).toBeVisible({ timeout: 30000 });

    await bookingDetails.getByRole('button', { name: 'New booking link' }).click();

    await expect.poll(() => bookingDetails.evaluate((details: HTMLDetailsElement) => details.open), {
      timeout: 10000,
    }).toBe(true);
    await expect(bookingDetails.getByText('2 links')).toBeVisible({ timeout: 10000 });
    await expect.poll(() => bookingDetails.locator('input').evaluateAll((inputs: HTMLInputElement[]) => {
      return inputs.some((input) => input.value === 'Meet 2');
    }), { timeout: 10000 }).toBe(true);

    await expect(bookingDetails.getByTestId('booking-link-card')).toHaveCount(2);
    const secondLinkCard = bookingDetails.getByTestId('booking-link-card').last();
    await expect(secondLinkCard.getByText('Title')).toBeVisible({ timeout: 10000 });
    await expect(secondLinkCard.getByText('Slug')).toBeVisible();
    await expect(secondLinkCard.getByText('Min')).toBeVisible();
    await expect(secondLinkCard.getByText('Next slots')).toBeVisible();
    await secondLinkCard.getByLabel('Booking link slug').fill('meet');
    await expect(secondLinkCard.getByLabel('Booking link slug')).toHaveValue('meet-2');
    await secondLinkCard.getByRole('button', { name: 'Copy booking link' }).click();
    await expect(secondLinkCard.getByRole('button', { name: 'Booking link copied' })).toBeVisible();
    await secondLinkCard.getByRole('button', { name: 'Open booking link' }).click();
    await expect(page).toHaveURL(/#\/book\/meet-2$/);
    await expect(page.getByRole('button', { name: 'Back to calendar' })).toBeVisible({ timeout: 15000 });
    await page.getByRole('button', { name: 'Back to calendar' }).click();
    if (!await bookingDetails.evaluate((details: HTMLDetailsElement) => details.open)) {
      await bookingDetails.locator('summary').click();
    }

    await bookingDetails.getByRole('button', { name: 'Delete booking link' }).last().click();
    await expect(bookingDetails.getByTestId('booking-link-card')).toHaveCount(2);
    await bookingDetails.getByRole('button', { name: 'Confirm delete booking link' }).click();
    await expect(bookingDetails.getByTestId('booking-link-card')).toHaveCount(1);
    await expect(bookingDetails.getByText('1 link')).toBeVisible({ timeout: 10000 });
  });

  test('edited booking link opens with the new slug and duration', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '15', exact: true }).first().click();
    const bookingDetails = page.locator('details').filter({ hasText: /^Booking/ });
    await expect(bookingDetails).toHaveCount(1, { timeout: 30000 });
    await bookingDetails.locator('summary').click();

    const bookingPanel = page.getByTestId('booking-link-panel');
    await expect(bookingPanel.getByText('9:00 AM')).toBeVisible({ timeout: 30000 });

    await bookingPanel.locator('input').first().fill('Deep Work QA');
    await bookingPanel.getByLabel('Booking link slug').fill('deep-work-qa');
    await bookingPanel.getByLabel('Booking link duration').fill('45');
    await expect(bookingPanel.getByLabel('Booking link duration')).toHaveValue('45');

    await bookingPanel.getByRole('button', { name: 'Open booking link' }).click();

    await expect(page).toHaveURL(/#\/book\/deep-work-qa$/);
    await expect(page.getByRole('heading', { name: 'Deep Work QA' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByText('45 min')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:00 AM - 9:45 AM' })).toBeVisible({ timeout: 15000 });
  });

  test('direct booking links open on the next available date', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/book/meet');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByTestId('booking-date-input')).toHaveValue('2026-06-15', { timeout: 15000 });
    await expect(page.getByText('Monday, June 15')).toBeVisible({ timeout: 15000 });
    await expect(page.getByText('16 slots')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: 'Back to calendar' })).toHaveCount(0);
    await expect(page.getByText('No slots on 2026-06-14.')).toHaveCount(0);
  });

  test('time format setting can switch booking slots to 24-hour time', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '24h' }).click();
    await page.evaluate(() => { window.location.hash = '#/book/meet'; });

    await expect(page.getByTestId('booking-date-input')).toHaveValue('2026-06-15', { timeout: 15000 });
    await expect(page.getByRole('button', { name: '09:00 - 09:30' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toHaveCount(0);
  });

  test('booking a slot creates an owner calendar event and removes the slot', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/book/meet');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByTestId('booking-date-input').fill('2026-06-15');
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });

    const slotButton = page.getByRole('button', { name: '9:00 AM - 9:30 AM' });
    await expect(slotButton).toBeVisible({ timeout: 30000 });
    await slotButton.click();

    await expect(page.getByTestId('booking-guest-name-input')).toBeFocused();
    await expect(page.getByTestId('booking-confirm-form').getByText('Name')).toBeVisible();
    await expect(page.getByTestId('booking-confirm-form').getByText('Note')).toBeVisible();
    await page.getByTestId('booking-confirm-form').getByRole('button', { name: 'Copy' }).click();
    await expect(page.getByTestId('booking-confirm-form').getByRole('button', { name: 'Copied' })).toBeVisible();
    await page.getByTestId('booking-guest-name-input').fill('Ada Lovelace');
    await page.getByRole('textbox', { name: 'Note' }).fill('Please bring the analytical engine notes');
    await page.getByTestId('booking-book-button').click();

    await expect(page.getByTestId('booking-confirmed')).toContainText('Booked', { timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toHaveCount(0, { timeout: 15000 });

    await page.evaluate(() => { window.location.hash = '#/'; });
    await expect(page.getByText('Monday, Jun 15')).toBeVisible({ timeout: 15000 });
    const bookedEvent = page.getByTestId('calendar-event-pill').filter({ hasText: 'Meet: Ada Lovelace' });
    await expect(bookedEvent).toBeVisible({ timeout: 15000 });
    await bookedEvent.click();
    await expect(page.getByRole('dialog', { name: 'Edit Event' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('textbox', { name: 'Notes' })).toHaveValue(/Booked from \/book\/meet[\s\S]*Guest: Ada Lovelace[\s\S]*Please bring the analytical engine notes/);
  });

  test('owner calendar events block overlapping booking slots', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const busyTitle = `Busy Block ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(busyTitle);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-start-time-input').fill('09:00');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-end-time-input').fill('10:00');
    await page.getByTestId('calendar-event-save').click();

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });
    await page.getByTestId('booking-date-input').fill('2026-06-15');

    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toHaveCount(0, { timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:30 AM - 10:00 AM' })).toHaveCount(0);
    await expect(page.getByRole('button', { name: '10:00 AM - 10:30 AM' })).toBeVisible({ timeout: 15000 });
  });

  test('booking buffers block adjacent slots around owner events', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const availabilityDetails = page.locator('details').filter({ hasText: /^Availability/ });
    await expect(availabilityDetails).toHaveCount(1, { timeout: 30000 });
    await availabilityDetails.locator('summary').click();
    await availabilityDetails.getByLabel('Buffer before minutes').fill('30');
    await availabilityDetails.getByLabel('Buffer after minutes').fill('30');
    await expect(availabilityDetails.getByLabel('Buffer before minutes')).toHaveValue('30');
    await expect(availabilityDetails.getByLabel('Buffer after minutes')).toHaveValue('30');

    const busyTitle = `Buffered Busy ${Date.now()}`;
    await openCalendarCreateEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(busyTitle);
    await page.getByTestId('calendar-event-start-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-start-time-input').fill('10:00');
    await page.getByTestId('calendar-event-end-date-input').fill('2026-06-15');
    await page.getByTestId('calendar-event-end-time-input').fill('10:30');
    await page.getByTestId('calendar-event-save').click();

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });
    await page.getByTestId('booking-date-input').fill('2026-06-15');

    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:30 AM - 10:00 AM' })).toHaveCount(0, { timeout: 15000 });
    await expect(page.getByRole('button', { name: '10:00 AM - 10:30 AM' })).toHaveCount(0);
    await expect(page.getByRole('button', { name: '10:30 AM - 11:00 AM' })).toHaveCount(0);
    await expect(page.getByRole('button', { name: '11:00 AM - 11:30 AM' })).toBeVisible({ timeout: 15000 });
  });

  test('minimum notice hides near-term booking slots until relaxed', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const availabilityDetails = page.locator('details').filter({ hasText: /^Availability/ });
    await expect(availabilityDetails).toHaveCount(1, { timeout: 30000 });
    await availabilityDetails.locator('summary').click();
    await availabilityDetails.getByLabel('Notice minutes').fill('525600');
    await expect(availabilityDetails.getByLabel('Notice minutes')).toHaveValue('525600');

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toBeVisible({ timeout: 15000 });
    await page.getByTestId('booking-date-input').fill('2026-06-15');
    await expect(page.getByText('No slots on 2026-06-15.')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toHaveCount(0);

    await page.getByRole('button', { name: 'Back to calendar' }).click();
    await availabilityDetails.locator('summary').click();
    await availabilityDetails.getByLabel('Notice minutes').fill('0');
    await expect(availabilityDetails.getByLabel('Notice minutes')).toHaveValue('0');

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await page.getByTestId('booking-date-input').fill('2026-06-15');
    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toBeVisible({ timeout: 15000 });
  });

  test('availability edits reshape booking slots', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await page.getByRole('button', { name: '15', exact: true }).first().click();
    const availabilityDetails = page.locator('details').filter({ hasText: /^Availability/ });
    await expect(availabilityDetails).toHaveCount(1, { timeout: 30000 });
    await availabilityDetails.locator('summary').click();
    await expect(availabilityDetails.getByText('Start')).toBeVisible({ timeout: 10000 });
    await expect(availabilityDetails.getByText('End')).toBeVisible();
    await expect(availabilityDetails.getByText('Slot length')).toBeVisible({ timeout: 10000 });
    await expect(availabilityDetails.getByText('Notice')).toBeVisible();
    await expect(availabilityDetails.getByText('Buffer before')).toBeVisible();
    await expect(availabilityDetails.getByText('Buffer after')).toBeVisible();

    await availabilityDetails.getByLabel('Mon start time').fill('10:00');
    await availabilityDetails.getByLabel('Mon end time').fill('12:00');
    await expect(availabilityDetails.getByLabel('Mon start time')).toHaveValue('10:00');
    await expect(availabilityDetails.getByLabel('Mon end time')).toHaveValue('12:00');
    await expect(page.getByText('10:00 - 12:00', { exact: true })).toBeVisible({ timeout: 15000 });

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await page.getByTestId('booking-date-input').fill('2026-06-15');

    await expect(page.getByRole('button', { name: '9:00 AM - 9:30 AM' })).toHaveCount(0, { timeout: 15000 });
    await expect(page.getByRole('button', { name: '10:00 AM - 10:30 AM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '10:30 AM - 11:00 AM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '11:00 AM - 11:30 AM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '11:30 AM - 12:00 PM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '12:00 PM - 12:30 PM' })).toHaveCount(0);

    await page.getByRole('button', { name: 'Back to calendar' }).click();
    await availabilityDetails.locator('summary').click();
    await availabilityDetails.getByLabel('Mon start time').fill('13:00');
    await expect(availabilityDetails.getByLabel('Mon start time')).toHaveValue('13:00');
    await expect(availabilityDetails.getByLabel('Mon end time')).toHaveValue('13:30');
    await expect(page.getByText('13:00 - 13:30', { exact: true })).toBeVisible({ timeout: 15000 });

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await page.getByTestId('booking-date-input').fill('2026-06-15');
    await expect(page.getByRole('button', { name: '1:00 PM - 1:30 PM' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: '1:30 PM - 2:00 PM' })).toHaveCount(0);
  });

  test('disabled booking links are not bookable by direct route', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    const bookingDetails = page.locator('details').filter({ hasText: /^Booking/ });
    await expect(bookingDetails).toHaveCount(1, { timeout: 30000 });
    await bookingDetails.locator('summary').click();

    await bookingDetails.getByLabel('Enabled').uncheck();
    await expect(bookingDetails.getByLabel('Enabled')).not.toBeChecked();

    await page.evaluate(() => { window.location.hash = '#/book/meet'; });
    await expect(page.getByRole('heading', { name: 'Booking link not found' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByText('Booking link not found.')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('heading', { name: 'Available Times' })).toHaveCount(0);
  });

  test('malformed booking link slugs show not found instead of crashing', async ({ page }) => {
    setupPageErrorHandler(page);

    await page.goto('/calendar.html#/book/%E0%A4%A');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await ensureLoggedIn(page, 30000);

    await expect(page.getByRole('heading', { name: 'Booking link not found' })).toBeVisible({ timeout: 15000 });
    await expect(page.getByText('Booking link not found.')).toBeVisible({ timeout: 15000 });
    await expect(page.getByRole('button', { name: 'Calendar view' })).toHaveCount(0);
  });
});
