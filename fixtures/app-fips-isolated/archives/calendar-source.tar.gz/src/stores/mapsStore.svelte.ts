import { writerForEntry } from '../lib/treeRewrite';
import { hashFromHex } from '../lib/hashtreeKeys';
/**
 * Maps store - manages places, annotations, and audience filter state
 */
import { cid, objectKeyFromHex, toHex, LinkType, type CID } from '@hashtree/core';
import { getTree } from '../store';
import { getRefResolver } from '../refResolver';
import { updateLocalRootCache } from '../treeRootCache';
import { nostrStore } from '../nostr';
import { getWorkerAdapter } from '../lib/workerInit';
import { searchPlaces } from './mapsSearch';
import type {
  ActivePlace,
  Annotation,
  AudienceFilter,
  MapView,
  MapsPersistedData,
  Place,
  SearchResult,
} from './mapsTypes';
export { getSearchResultKey } from './mapsSearch';
export type {
  ActivePlace,
  Annotation,
  AudienceFilter,
  MapView,
  Place,
  PlaceCategory,
  SearchResult,
} from './mapsTypes';

const MAP_VIEW_KEY = 'iris-maps-view';
const DEFAULT_CENTER: [number, number] = [20, 0]; // World view
const DEFAULT_ZOOM = 2;
const MAPS_TREE_NAME = 'maps';
const MAPS_DATA_FILE = 'maps.json';
const MAPS_DATA_VERSION = 1;
const MAPS_META_FILE = 'meta.json';
const MAPS_META_VERSION = 1;
const MAPS_ROOT_STORAGE_KEY = 'iris-maps-root:maps';

interface MapsMeta {
  version: number;
  createdAt: number;
  updatedAt: number;
  providers: string[];
}

function loadMapView(): MapView {
  try {
    const saved = localStorage.getItem(MAP_VIEW_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<MapView>;
      if (Array.isArray(parsed.center) && typeof parsed.zoom === 'number') {
        const bounds = Array.isArray(parsed.bounds) && parsed.bounds.length === 4
          ? parsed.bounds as [number, number, number, number]
          : undefined;
        return { center: parsed.center as [number, number], zoom: parsed.zoom, bounds };
      }
    }
  } catch {
    // Ignore parse errors
  }
  return { center: DEFAULT_CENTER, zoom: DEFAULT_ZOOM };
}

function saveMapView(view: MapView) {
  try {
    localStorage.setItem(MAP_VIEW_KEY, JSON.stringify(view));
  } catch {
    // Ignore storage errors
  }
}

interface MapsState {
  places: Place[];
  annotations: Annotation[];
  audienceFilter: AudienceFilter;
  selectedPlace: Place | null;
  isAddPlaceModalOpen: boolean;
  pendingPlaceLocation: { lat: number; lng: number } | null;
  mapView: MapView;
  searchQuery: string;
  searchResults: SearchResult[];
  isSearching: boolean;
  activePlace: ActivePlace | null;
}

const savedView = loadMapView();

const initialState: MapsState = {
  places: [],
  annotations: [],
  audienceFilter: 'follows',
  selectedPlace: null,
  isAddPlaceModalOpen: false,
  pendingPlaceLocation: null,
  mapView: savedView,
  searchQuery: '',
  searchResults: [],
  isSearching: false,
  activePlace: null,
};

let state = $state<MapsState>({ ...initialState });

let activeNpub: string | null = null;
let rootCid: CID | null = null;
let resolverUnsubscribe: (() => void) | null = null;
let nostrUnsubscribe: (() => void) | null = null;
let applyingRemote = false;
let persistChain: Promise<void> = Promise.resolve();

function resetLocalState() {
  state.places = [];
  state.annotations = [];
  state.selectedPlace = null;
  rootCid = null;
}

function applyRemoteData(data: MapsPersistedData) {
  applyingRemote = true;
  state.places = data.places;
  state.annotations = data.annotations;
  state.selectedPlace = null;
  applyingRemote = false;
}

function normalizePersistedData(raw: unknown): MapsPersistedData | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Partial<MapsPersistedData>;
  if (!Array.isArray(record.places) || !Array.isArray(record.annotations)) return null;
  return {
    version: typeof record.version === 'number' ? record.version : MAPS_DATA_VERSION,
    places: record.places as Place[],
    annotations: record.annotations as Annotation[],
  };
}

function getRootStorageKey(npub: string): string {
  return `${MAPS_ROOT_STORAGE_KEY}:${npub}`;
}

function loadMapsRoot(npub: string): CID | null {
  try {
    const stored = localStorage.getItem(getRootStorageKey(npub));
    if (!stored) return null;
    const parsed = JSON.parse(stored) as { hash?: string; key?: string };
    if (parsed?.hash) {
      return cid(hashFromHex(parsed.hash), parsed.key == null ? undefined : objectKeyFromHex(parsed.key));
    }
  } catch {
    // Ignore storage errors
  }
  return null;
}

function saveMapsRoot(npub: string, root: CID) {
  try {
    localStorage.setItem(
      getRootStorageKey(npub),
      JSON.stringify({ hash: toHex(root.hash), key: root.key ? toHex(root.key) : undefined })
    );
  } catch {
    // Ignore storage errors
  }
}

async function waitForWorkerReady(maxWaitMs = 5000): Promise<boolean> {
  const start = Date.now();
  while (!getWorkerAdapter()) {
    if (Date.now() - start > maxWaitMs) {
      return false;
    }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  return true;
}

let workerReadyPromise: Promise<boolean> | null = null;

async function ensureWorkerReady(maxWaitMs = 5000): Promise<boolean> {
  if (!workerReadyPromise) {
    workerReadyPromise = waitForWorkerReady(maxWaitMs);
  }
  const ready = await workerReadyPromise;
  if (!ready) {
    workerReadyPromise = null;
  }
  return ready;
}

async function ensureMapsMeta(root: CID): Promise<CID> {
  const tree = getTree();
  const existing = await tree.resolvePath(root, [MAPS_META_FILE]);
  if (existing) return root;
  const meta: MapsMeta = {
    version: MAPS_META_VERSION,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    providers: [],
  };
  const encoded = new TextEncoder().encode(JSON.stringify(meta));
  const { cid: fileCid, size } = await writerForEntry(tree, root).putFile(encoded);
  return tree.setEntry(root, [], MAPS_META_FILE, fileCid, size, LinkType.File);
}


function queueRootUpdate(action: (root: CID) => Promise<CID>): Promise<void> {
  const npub = activeNpub ?? nostrStore.getState().npub;
  if (applyingRemote || !npub) return Promise.resolve();
  activeNpub = npub;
  persistChain = persistChain.then(async () => {
    const ready = await ensureWorkerReady();
    if (!ready) return;
    const tree = getTree();
    let currentRoot = rootCid ?? loadMapsRoot(npub);
    if (!currentRoot) {
      const { cid: emptyRoot } = await tree.putDirectory([]);
      currentRoot = await ensureMapsMeta(emptyRoot);
    } else {
      currentRoot = await ensureMapsMeta(currentRoot);
    }
    const nextRoot = await action(currentRoot);
    rootCid = nextRoot;
    saveMapsRoot(npub, nextRoot);
    updateLocalRootCache(npub, MAPS_TREE_NAME, nextRoot.hash, nextRoot.key, 'public');
  }).catch(() => {});
  return persistChain;
}

async function loadMapsData(cid: CID) {
  const ready = await waitForWorkerReady();
  if (!ready) return;
  const tree = getTree();
  const entry = await tree.resolvePath(cid, [MAPS_DATA_FILE]);
  if (!entry) {
    applyRemoteData({ version: MAPS_DATA_VERSION, places: [], annotations: [] });
    return;
  }
  const data = await tree.readFile(entry.cid);
  if (!data) return;
  try {
    const decoded = new TextDecoder().decode(data);
    const parsed = JSON.parse(decoded);
    const normalized = normalizePersistedData(parsed);
    if (normalized) {
      applyRemoteData(normalized);
    }
  } catch {
    // Ignore invalid data
  }
}

function queuePersist(): Promise<void> {
  return queueRootUpdate(persistMapsData);
}

async function persistMapsData(currentRoot: CID): Promise<CID> {
  const payload: MapsPersistedData = {
    version: MAPS_DATA_VERSION,
    places: state.places,
    annotations: state.annotations,
  };
  const encoded = new TextEncoder().encode(JSON.stringify(payload));
  const tree = getTree();
  const existing = await tree.resolvePath(currentRoot, [MAPS_DATA_FILE]);
  const writer = writerForEntry(writerForEntry(tree, currentRoot), existing?.cid);
  const { cid: fileCid, size } = await writer.putFile(encoded);
  return tree.setEntry(currentRoot, [], MAPS_DATA_FILE, fileCid, size, LinkType.File);
}

function subscribeToMapsTree(npub: string) {
  if (resolverUnsubscribe) {
    resolverUnsubscribe();
    resolverUnsubscribe = null;
  }

  const resolver = getRefResolver();
  const key = `${npub}/${MAPS_TREE_NAME}`;
  resolverUnsubscribe = resolver.subscribe?.(key, (cid) => {
    if (!cid) {
      resetLocalState();
      return;
    }
    rootCid = cid;
    loadMapsData(cid).catch(() => {});
  }) ?? null;
}

function handleNostrChange() {
  const nextNpub = nostrStore.getState().npub;
  if (nextNpub === activeNpub) return;
  activeNpub = nextNpub;
  if (!activeNpub) {
    resetLocalState();
    if (resolverUnsubscribe) {
      resolverUnsubscribe();
      resolverUnsubscribe = null;
    }
    return;
  }
  const cachedRoot = loadMapsRoot(activeNpub);
  if (cachedRoot) {
    rootCid = cachedRoot;
    loadMapsData(cachedRoot).catch(() => {});
  }
  subscribeToMapsTree(activeNpub);
}

export const mapsStore = {
  get places() { return state.places; },
  get annotations() { return state.annotations; },
  get audienceFilter() { return state.audienceFilter; },
  get selectedPlace() { return state.selectedPlace; },
  get isAddPlaceModalOpen() { return state.isAddPlaceModalOpen; },
  get pendingPlaceLocation() { return state.pendingPlaceLocation; },
  get mapView() { return state.mapView; },
  get searchQuery() { return state.searchQuery; },
  get searchResults() { return state.searchResults; },
  get isSearching() { return state.isSearching; },
  get activePlace() { return state.activePlace; },
  init() {
    if (nostrUnsubscribe) return;
    handleNostrChange();
    nostrUnsubscribe = nostrStore.subscribe(() => {
      handleNostrChange();
    });
  },
  setActivePlace(place: ActivePlace | null) {
    state.activePlace = place;
  },
  destroy() {
    if (nostrUnsubscribe) {
      nostrUnsubscribe();
      nostrUnsubscribe = null;
    }
    if (resolverUnsubscribe) {
      resolverUnsubscribe();
      resolverUnsubscribe = null;
    }
  },

  setMapView(center: [number, number], zoom: number, bounds?: [number, number, number, number]) {
    state.mapView = { center, zoom, bounds };
    saveMapView(state.mapView);
  },

  async search(query: string) {
    state.searchQuery = query;
    const trimmed = query.trim();
    if (!trimmed || trimmed.length < 2) {
      state.searchResults = [];
      return;
    }

    state.isSearching = true;
    try {
      state.searchResults = await searchPlaces(trimmed, state.mapView, state.activePlace);
    } catch {
      state.searchResults = [];
    } finally {
      state.isSearching = false;
    }
  },

  clearSearch() {
    state.searchQuery = '';
    state.searchResults = [];
  },

  setAudienceFilter(filter: AudienceFilter) {
    state.audienceFilter = filter;
  },

  openAddPlaceModal() {
    state.isAddPlaceModalOpen = true;
  },

  closeAddPlaceModal() {
    state.isAddPlaceModalOpen = false;
    state.pendingPlaceLocation = null;
  },

  setPendingPlaceLocation(lat: number, lng: number) {
    state.pendingPlaceLocation = { lat, lng };
  },

  async addPlace(place: Omit<Place, 'id' | 'createdAt' | 'updatedAt'>) {
    const now = Date.now();
    const newPlace: Place = {
      ...place,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    };
    state.places = [...state.places, newPlace];
    await queuePersist();
    return newPlace;
  },

  updatePlace(id: string, updates: Partial<Omit<Place, 'id' | 'createdAt' | 'owner'>>) {
    state.places = state.places.map(p =>
      p.id === id ? { ...p, ...updates, updatedAt: Date.now() } : p
    );
    queuePersist();
  },

  deletePlace(id: string) {
    state.places = state.places.filter(p => p.id !== id);
    queuePersist();
  },

  selectPlace(place: Place | null) {
    state.selectedPlace = place;
  },

  addAnnotation(annotation: Omit<Annotation, 'id' | 'createdAt' | 'updatedAt'>) {
    const now = Date.now();
    const newAnnotation: Annotation = {
      ...annotation,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    };
    state.annotations = [...state.annotations, newAnnotation];
    queuePersist();
    return newAnnotation;
  },

  deleteAnnotation(id: string) {
    state.annotations = state.annotations.filter(a => a.id !== id);
    queuePersist();
  },

  reset() {
    state = { ...initialState };
  },
};
