import { encryptionMode, objectKeyFromHex, toHex, type Hash, type SubscribeVisibilityInfo } from '@hashtree/core';
import { isLinkSecretHex, recoverSharingSecret, unmaskObjectKey } from '../lib/hashtreeKeys';
import { getRefResolver } from '../refResolver';
import { decrypt } from '../nostr';
import { showTreeSharingSecret } from '../lib/treeSharingSecret';
import {
  getNostrState,
  type ResolverListVisibilityEntry,
} from './treeRootShared';

/**
 * Decrypt the encryption key for a tree based on visibility and available keys
 */
export async function decryptEncryptionKey(
  visibilityInfo: SubscribeVisibilityInfo | undefined,
  encryptionKey: Hash | undefined,
  linkKey: string | null
): Promise<Hash | undefined> {
  if (encryptionKey) {
    encryptionMode(encryptionKey);
    return encryptionKey;
  }

  if (!visibilityInfo) {
    // Historical links could carry a raw 32-byte CHK before visibility metadata existed.
    if (linkKey && linkKey.length === 64) {
      try {
        return objectKeyFromHex(linkKey);
      } catch (e) {
        console.debug('Could not use linkKey directly:', e);
      }
    }
    return undefined;
  }

  // Link-visible tree with linkKey from URL
  if (visibilityInfo.visibility === 'link-visible' && linkKey) {
    if (!isLinkSecretHex(linkKey)) return undefined;
    if (visibilityInfo.encryptedKey) {
      try {
        const key = await unmaskObjectKey(visibilityInfo.encryptedKey, linkKey, visibilityInfo.keyId);
        if (key) return key;
        console.warn('[decryptEncryptionKey] Key mismatch - linkKey does not decrypt encryptedKey');
      } catch (e) {
        console.error('[decryptEncryptionKey] Decryption failed:', e);
      }
    } else {
      console.warn('[decryptEncryptionKey] Link-visible tree missing encryptedKey metadata; waiting for resolver update');
    }
    return undefined;
  }

  // Link-visible tree - owner access via selfEncryptedLinkKey
  // Decrypt linkKey, then derive contentKey from encryptedKey
  if (visibilityInfo.visibility === 'link-visible' && visibilityInfo.encryptedKey && visibilityInfo.selfEncryptedLinkKey) {
    try {
      const state = getNostrState();
      if (state.pubkey) {
        const decryptedLinkKey = await decrypt(state.pubkey, visibilityInfo.selfEncryptedLinkKey);
        if (isLinkSecretHex(decryptedLinkKey)) {
          const key = await unmaskObjectKey(visibilityInfo.encryptedKey, decryptedLinkKey, visibilityInfo.keyId);
          if (key) return key;
        }
      }
    } catch (e) {
      console.debug('Could not decrypt via selfEncryptedLinkKey (not owner?):', e);
    }
  }

  // Private tree - try selfEncryptedKey (owner access)
  if (visibilityInfo.selfEncryptedKey) {
    try {
      const state = getNostrState();
      if (state.pubkey) {
        // Use centralized decrypt (works with both nsec and extension login)
        const decrypted = await decrypt(state.pubkey, visibilityInfo.selfEncryptedKey);
        return objectKeyFromHex(decrypted);
      }
    } catch (e) {
      console.debug('Could not decrypt selfEncryptedKey (not owner?):', e);
    }
  }

  return undefined;
}


/**
 * Recover linkKey for URL when owner navigates to link-visible without k= param
 * This allows easy sharing by copying URL from address bar
 */
export async function recoverLinkKeyForUrl(resolverKey: string): Promise<void> {
  const npubStr = resolverKey.split('/')[0];
  const treeName = resolverKey.split('/').slice(1).join('/');
  const resolver = getRefResolver();

  // Use list to get fresh visibility data
  const entries = await new Promise<ResolverListVisibilityEntry[] | null>((resolve) => {
    let resolved = false;

    const unsub = resolver.list?.(npubStr, (list) => {
      if (resolved) return;
      resolved = true;
      // Defer unsubscribe to avoid calling it during callback
      setTimeout(() => unsub?.(), 0);
      // list entries have 'key' field like 'npub/treeName', we need to match by treeName
      const entry = list.find(e => {
        const keyParts = e.key?.split('/');
        const entryTreeName = keyParts?.slice(1).join('/');
        return entryTreeName === treeName;
      });
      resolve(entry ? [entry as ResolverListVisibilityEntry] : null);
    });

    // Timeout after 2 seconds
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        unsub?.();
        resolve(null);
      }
    }, 2000);
  });

  if (!entries?.[0]) return;

  const { visibility, selfEncryptedLinkKey } = entries[0];
  if (visibility !== 'link-visible' || !selfEncryptedLinkKey) return;

  try {
    const state = getNostrState();
    const { nip19: nip19Mod } = await import('nostr-tools');
    const decoded = nip19Mod.decode(npubStr);
    const treePubkey = decoded.type === 'npub' ? decoded.data as string : null;

    if (state.pubkey && treePubkey && state.pubkey === treePubkey) {
      const decryptedLinkKey = await decrypt(state.pubkey, selfEncryptedLinkKey);
      showTreeSharingSecret(npubStr, treeName, decryptedLinkKey);
    }
  } catch (e) {
    console.debug('[treeRoot] Could not recover linkKey for URL:', e);
  }
}

export async function recoverMissingLinkKeyForOwner(options: {
  resolverKey: string;
  visibilityInfo?: SubscribeVisibilityInfo;
  hash: Hash;
  decryptedKey?: Hash;
}): Promise<void> {
  const { resolverKey, visibilityInfo, hash, decryptedKey } = options;
  let selfEncryptedLinkKey = visibilityInfo?.selfEncryptedLinkKey;
  let visibility = visibilityInfo?.visibility;
  let listEntries: ResolverListVisibilityEntry[] | null = null;

  if (!selfEncryptedLinkKey) {
    const npubStr = resolverKey.split('/')[0];
    const treeName = resolverKey.split('/').slice(1).join('/');
    const resolver = getRefResolver();

    listEntries = await new Promise<ResolverListVisibilityEntry[] | null>((resolve) => {
      let resolved = false;
      const unsub = resolver.list?.(npubStr, (list) => {
        if (resolved) return;
        resolved = true;
        setTimeout(() => unsub?.(), 0);
        const entry = list.find(e => {
          const keyParts = e.key?.split('/');
          const entryTreeName = keyParts?.slice(1).join('/');
          return entryTreeName === treeName;
        });
        resolve(entry ? [entry as ResolverListVisibilityEntry] : null);
      });
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          unsub?.();
          resolve(null);
        }
      }, 2000);
    });

    if (listEntries?.[0]) {
      selfEncryptedLinkKey = listEntries[0].selfEncryptedLinkKey;
      visibility = listEntries[0].visibility as typeof visibility;
    }
  }

  if (visibility !== 'link-visible') return;

  const state = getNostrState();
  const npubStr = resolverKey.split('/')[0];
  const { nip19: nip19Mod } = await import('nostr-tools');
  const decoded = nip19Mod.decode(npubStr);
  const treePubkey = decoded.type === 'npub' ? decoded.data as string : null;
  const isOwner = state.pubkey && treePubkey && state.pubkey === treePubkey;
  if (!isOwner) return;

  const treeName = resolverKey.split('/').slice(1).join('/');
  if (getNostrState().pubkey !== treePubkey) return;
  try {
    const encryptedKey = visibilityInfo?.encryptedKey ?? listEntries?.[0]?.encryptedKey;
    const selfEncryptedKey = visibilityInfo?.selfEncryptedKey ?? listEntries?.[0]?.selfEncryptedKey;
    let secret: string;
    if (selfEncryptedLinkKey) {
      secret = await decrypt(state.pubkey!, selfEncryptedLinkKey);
    } else {
      if (!encryptedKey) return;
      let contentKey = decryptedKey;
      if (selfEncryptedKey) {
        contentKey = objectKeyFromHex(await decrypt(state.pubkey!, selfEncryptedKey));
      } else if (!contentKey) {
        const { getLocalRootEntry } = await import('../treeRootCache');
        const cached = getLocalRootEntry(npubStr, treeName);
        if (cached && toHex(cached.hash) === toHex(hash)) contentKey = cached.key;
      }
      if (!contentKey) return;
      secret = recoverSharingSecret(toHex(contentKey), encryptedKey);
    }
    if (getNostrState().pubkey !== treePubkey || !isLinkSecretHex(secret)) return;
    const { storeLinkKey } = await import('./trees');
    // Cache the recovered secret for the next edit without publishing from an old read.
    await storeLinkKey(npubStr, treeName, secret);
    showTreeSharingSecret(npubStr, treeName, secret);
  } catch (error) {
    console.debug('Could not recover the owner sharing secret:', error);
  }
}
