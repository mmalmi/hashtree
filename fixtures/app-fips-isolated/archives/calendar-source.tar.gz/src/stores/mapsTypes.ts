export interface MapView {
  center: [number, number];
  zoom: number;
  bounds?: [number, number, number, number];
}

export interface MapsPersistedData {
  version: number;
  places: Place[];
  annotations: Annotation[];
}

export interface SearchResult {
  name: string;
  lat: number;
  lng: number;
  type: string;
  class: string;
  displayName: string;
  boundingBox?: [number, number, number, number];
  placeRank?: number;
  importance?: number;
  addressType?: string;
}

export interface ActivePlace {
  name: string;
  lat: number;
  lng: number;
  type?: string;
  class?: string;
  displayName?: string;
  boundingBox?: [number, number, number, number];
  placeRank?: number;
  source: 'search' | 'place';
}

export type PlaceCategory =
  | 'restaurant'
  | 'cafe'
  | 'bar'
  | 'shop'
  | 'service'
  | 'attraction'
  | 'accommodation'
  | 'transport'
  | 'other';

export interface Place {
  id: string;
  name: string;
  category: PlaceCategory;
  lat: number;
  lng: number;
  description?: string;
  contact?: string;
  hours?: string;
  tags?: string[];
  createdAt: number;
  updatedAt: number;
  owner: string;
}

export interface Annotation {
  id: string;
  type: 'point' | 'line' | 'polygon';
  coordinates: [number, number][] | [number, number];
  name?: string;
  description?: string;
  color?: string;
  createdAt: number;
  updatedAt: number;
  owner: string;
}

export type AudienceFilter = 'own' | 'follows' | 'fof';
