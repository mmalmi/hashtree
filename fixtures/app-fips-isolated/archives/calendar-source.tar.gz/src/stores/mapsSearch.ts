import type { ActivePlace, MapView, SearchResult } from './mapsTypes';

export function getSearchResultKey(result: SearchResult): string {
  const name = result.displayName || result.name;
  return `${name.toLowerCase()}-${result.lat.toFixed(5)}-${result.lng.toFixed(5)}-${result.class}-${result.type}`;
}

export async function searchPlaces(
  query: string,
  mapView: MapView,
  activePlace: ActivePlace | null,
): Promise<SearchResult[]> {
  const trimmed = query.trim();
  const normalizedQuery = normalizeSearchText(trimmed);
  const isAsciiQuery = /^[a-z0-9 ]+$/.test(normalizedQuery);
  const viewBounds = mapView.bounds;
  const origin = activePlace
    ? { lat: clampLat(activePlace.lat), lng: normalizeLng(activePlace.lng) }
    : { lat: clampLat(mapView.center[0]), lng: normalizeLng(mapView.center[1]) };
  const language = typeof navigator !== 'undefined' ? navigator.language : '';
  const languageCode = normalizeLanguage(language);

  const fetchNominatim = async (
    searchQuery = trimmed,
    languageOverride?: string,
    useLocation = true
  ) => fetchNominatimResults(searchQuery, origin, viewBounds, language, languageOverride, useLocation);

  const fetchPhoton = async (useLocation = true) => fetchPhotonResults(trimmed, origin, language, useLocation);

  let primaryResults: SearchResult[] = [];
  let fetchedNominatim = false;
  try {
    primaryResults = await fetchNominatim();
    fetchedNominatim = true;
  } catch {
    primaryResults = [];
  }

  let results = primaryResults;
  const shouldFetchPhoton = trimmed.length <= 6 || primaryResults.length < 5;
  if (shouldFetchPhoton) {
    try {
      const photonResults = await fetchPhoton();
      results = dedupeResults([...results, ...photonResults]);
    } catch {
      // Ignore photon errors
    }
  }

  const isLowQualityMatch = (result: SearchResult, score: number) => {
    if (score < 850) return true;
    if (isAddressResult(result)) return true;
    if (result.class === 'highway' || result.type === 'road') return true;
    return false;
  };

  let hasQualityMatch = results.some((result) => {
    const score = matchScore(result, normalizedQuery);
    return !isLowQualityMatch(result, score);
  });

  let usedGlobalFallback = false;
  if (!hasQualityMatch) {
    usedGlobalFallback = true;
    try {
      const globalNominatim = await fetchNominatim(trimmed, undefined, false);
      results = dedupeResults([...results, ...globalNominatim]);
    } catch {
      // Ignore global fetch errors
    }

    const shouldFetchPhotonGlobal = shouldFetchPhoton || results.length < 5;
    if (shouldFetchPhotonGlobal) {
      try {
        const globalPhoton = await fetchPhoton(false);
        results = dedupeResults([...results, ...globalPhoton]);
      } catch {
        // Ignore global photon errors
      }
    }
  }

  if (!results.some(isSettlementResult) && trimmed.length >= 5) {
    const fallbackQueries = createSettlementFallbackQueries(trimmed, normalizedQuery);
    if (fallbackQueries.length > 0) {
      try {
        const fallbackUseLocation = !usedGlobalFallback && fetchedNominatim;
        const fallbackResults = await Promise.all(
          fallbackQueries.map(queryValue => fetchNominatim(queryValue, undefined, fallbackUseLocation))
        );
        const flattened = fallbackResults.flat();
        primaryResults = dedupeResults([...primaryResults, ...flattened]);
        results = dedupeResults([...results, ...flattened]);
      } catch {
        // Ignore fallback errors
      }
    }
  }

  hasQualityMatch = results.some((result) => {
    const score = matchScore(result, normalizedQuery);
    return !isLowQualityMatch(result, score);
  });
  if (!hasQualityMatch && isAsciiQuery && languageCode !== 'en') {
    try {
      const englishResults = await fetchNominatim(trimmed, 'en', !usedGlobalFallback);
      results = dedupeResults([...results, ...englishResults]);
    } catch {
      // Ignore fallback errors
    }
  }

  return rankSearchResults(results, normalizedQuery, origin, viewBounds);
}

function normalizeSearchText(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function normalizeLanguage(value: string | undefined): string {
  if (!value) return 'en';
  const primary = value.split(',')[0]?.trim();
  if (!primary) return 'en';
  return primary.split('-')[0]?.toLowerCase() || 'en';
}

function normalizeLng(lng: number) {
  const wrapped = ((lng + 180) % 360 + 360) % 360 - 180;
  return Number.isFinite(wrapped) ? wrapped : lng;
}

function clampLat(lat: number) {
  return Math.max(-90, Math.min(90, lat));
}

async function fetchNominatimResults(
  searchQuery: string,
  origin: { lat: number; lng: number },
  viewBounds: [number, number, number, number] | undefined,
  language: string,
  languageOverride?: string,
  useLocation = true,
): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    format: 'jsonv2',
    q: searchQuery,
    limit: '50',
  });
  if (useLocation) {
    params.set('bounded', '0');
    params.set('lat', origin.lat.toString());
    params.set('lon', origin.lng.toString());
    if (viewBounds) {
      const [south, north, west, east] = viewBounds;
      params.set('viewbox', `${west},${north},${east},${south}`);
    }
  }
  const requestLanguage = languageOverride ?? language;
  if (requestLanguage) {
    params.set('accept-language', requestLanguage);
  }
  const response = await fetch(
    `https://nominatim.openstreetmap.org/search?${params.toString()}`,
    { headers: { 'User-Agent': 'IrisMaps/1.0' } }
  );
  const data = await response.json();
  return data.map((item: {
    display_name: string;
    lat: string;
    lon: string;
    type: string;
    class: string;
    name?: string;
    boundingbox?: string[];
    place_rank?: number;
    importance?: number;
    addresstype?: string;
  }) => ({
    name: item.name || item.display_name.split(',')[0],
    lat: parseFloat(item.lat),
    lng: parseFloat(item.lon),
    type: item.type,
    class: item.class,
    displayName: item.display_name,
    boundingBox: item.boundingbox ? [
      parseFloat(item.boundingbox[0]),
      parseFloat(item.boundingbox[1]),
      parseFloat(item.boundingbox[2]),
      parseFloat(item.boundingbox[3]),
    ] as [number, number, number, number] : undefined,
    placeRank: typeof item.place_rank === 'number' ? item.place_rank : undefined,
    importance: typeof item.importance === 'number' ? item.importance : undefined,
    addressType: item.addresstype,
  })) as SearchResult[];
}

async function fetchPhotonResults(
  query: string,
  origin: { lat: number; lng: number },
  language: string,
  useLocation = true,
): Promise<SearchResult[]> {
  const params = new URLSearchParams({ q: query, limit: '50' });
  if (useLocation) {
    params.set('lat', origin.lat.toString());
    params.set('lon', origin.lng.toString());
  }
  if (language) {
    const lang = language.split('-')[0]?.toLowerCase();
    if (lang === 'en' || lang === 'de' || lang === 'fr') {
      params.set('lang', lang);
    }
  }
  const response = await fetch(
    `https://photon.komoot.io/api/?${params.toString()}`,
    { headers: { 'User-Agent': 'IrisMaps/1.0' } }
  );
  const data = await response.json();
  return (data?.features ?? []).map((item: {
    geometry: { coordinates: [number, number] };
    properties: {
      name?: string;
      type?: string;
      osm_key?: string;
      city?: string;
      state?: string;
      country?: string;
      extent?: [number, number, number, number];
    };
  }) => {
    const [lng, lat] = item.geometry.coordinates;
    const name = item.properties.name ?? '';
    const parts = [name, item.properties.city, item.properties.state, item.properties.country]
      .filter(Boolean);
    const extent = item.properties.extent;
    return {
      name: name || parts[0] || 'Unknown',
      lat,
      lng,
      type: item.properties.type ?? 'place',
      class: item.properties.osm_key ?? 'place',
      displayName: parts.join(', '),
      boundingBox: extent ? [
        extent[1],
        extent[3],
        extent[0],
        extent[2],
      ] as [number, number, number, number] : undefined,
    } as SearchResult;
  });
}

function createSettlementFallbackQueries(trimmed: string, normalizedQuery: string): string[] {
  const lastChar = normalizedQuery[normalizedQuery.length - 1];
  const isVowel = ['a', 'e', 'i', 'o', 'u', 'y', 'ä', 'ö'].includes(lastChar);
  if (!isVowel) return [`${trimmed}i`];
  if (lastChar === 'e') return [`${trimmed}mi`];
  if (lastChar === 'i') return [`${trimmed}emi`];
  return [];
}

function dedupeResults(items: SearchResult[]): SearchResult[] {
  const deduped = new Map<string, SearchResult>();
  for (const item of items) {
    const key = getSearchResultKey(item);
    if (!deduped.has(key)) {
      deduped.set(key, item);
    }
  }
  return Array.from(deduped.values());
}

function distanceKm(aLat: number, aLng: number, bLat: number, bLng: number) {
  const toRad = (value: number) => value * Math.PI / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const lat1 = toRad(aLat);
  const lat2 = toRad(bLat);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const a = sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function areaKm2(box?: [number, number, number, number]) {
  if (!box) return 0;
  const [south, north, west, east] = box;
  const height = distanceKm(south, west, north, west);
  const midLat = (south + north) / 2;
  const width = distanceKm(midLat, west, midLat, east);
  return Math.max(0, height * width);
}

function isWithinBounds(lat: number, lng: number, box?: [number, number, number, number]) {
  if (!box) return false;
  const [south, north, west, east] = box;
  const withinLat = lat >= south && lat <= north;
  const withinLng = west <= east
    ? lng >= west && lng <= east
    : lng >= west || lng <= east;
  return withinLat && withinLng;
}

function isSettlementResult(result: SearchResult) {
  return result.class === 'place'
    || ['city', 'town', 'village', 'hamlet'].includes(result.type);
}

function isBoundaryResult(result: SearchResult) {
  return result.class === 'boundary' || result.type === 'administrative';
}

function isAddressResult(result: SearchResult) {
  return result.addressType === 'house'
    || result.addressType === 'building'
    || result.class === 'building'
    || result.type === 'house';
}

function isCountryResult(result: SearchResult) {
  return result.addressType === 'country'
    || (isBoundaryResult(result) && (result.placeRank ?? 99) <= 4);
}

function isRegionResult(result: SearchResult) {
  return result.addressType === 'state'
    || (isBoundaryResult(result) && (result.placeRank ?? 99) <= 8);
}

function matchScore(result: SearchResult, normalizedQuery: string) {
  const nameText = normalizeSearchText(result.name);
  const displayText = normalizeSearchText(result.displayName);
  if (!normalizedQuery) return 0;
  if (nameText === normalizedQuery) return 1000;
  if (displayText === normalizedQuery) return 950;
  if (nameText.startsWith(normalizedQuery)) return 900;
  const nameTokens = nameText.split(' ');
  const displayTokens = displayText.split(' ');
  if (nameTokens.includes(normalizedQuery) || displayTokens.includes(normalizedQuery)) return 850;
  if (nameTokens.some(token => token.startsWith(normalizedQuery))) return 780;
  if (displayTokens.some(token => token.startsWith(normalizedQuery))) return 730;
  if (displayText.startsWith(normalizedQuery)) return 700;
  if (nameText.includes(normalizedQuery)) return 620;
  if (displayText.includes(normalizedQuery)) return 520;
  return 0;
}

function rankSearchResults(
  results: SearchResult[],
  normalizedQuery: string,
  origin: { lat: number; lng: number },
  bounds?: [number, number, number, number]
): SearchResult[] {
  return results
    .map(result => {
      const distance = distanceKm(origin.lat, origin.lng, result.lat, result.lng);
      const within = isWithinBounds(result.lat, result.lng, bounds);
      const importance = result.importance ?? 0;
      const isHighway = result.class === 'highway' || result.type === 'road';
      const isBoundary = isBoundaryResult(result);
      const isSettlement = isSettlementResult(result);
      const isAddress = isAddressResult(result);
      const isCountry = isCountryResult(result);
      const match = matchScore(result, normalizedQuery);
      const queryLength = normalizedQuery.length;
      const placeRank = result.placeRank ?? 30;
      const placeRankBoost = Math.max(0, 24 - placeRank) * 12;
      const placeRankPenalty = placeRank > 26 ? (placeRank - 26) * 18 : 0;
      const cityBoost = result.type === 'city' ? 120
        : result.type === 'town' ? 60
          : result.type === 'village' ? 20
            : 0;
      const highwayPenalty = (isHighway && queryLength <= 10 && match < 850) ? 180 : 0;
      const boundaryPenalty = (isBoundary && queryLength <= 10 && match < 850) ? 60 : 0;
      const addressPenalty = (isAddress && queryLength <= 16 && match < 900) ? 260 : 0;
      const settlementBoost = (isSettlement && queryLength <= 12) ? 80 : 0;
      const area = areaKm2(result.boundingBox);
      const areaBoost = area > 0 ? Math.min(200, Math.log10(area + 1) * 18) : 0;
      const adminBoost = isCountry ? 320 : isRegionResult(result) ? 160 : 0;
      const withinBoost = within ? (match >= 850 ? 40 : 120) : 0;
      const distancePenalty = isCountry
        ? (match >= 850 ? distance / 200 : distance / 80)
        : match >= 850
          ? distance / 120
          : match >= 700
            ? distance / 30
            : distance / 12;
      const score = withinBoost
        + (importance * 60)
        + match
        + adminBoost
        + areaBoost
        + settlementBoost
        + cityBoost
        + placeRankBoost
        - distancePenalty
        - highwayPenalty
        - boundaryPenalty
        - addressPenalty
        - placeRankPenalty;
      return { result, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 10)
    .map(entry => entry.result);
}
