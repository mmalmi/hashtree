/**
 * Route store for Svelte
 * Provides route information from current URL
 */
import { writable, derived, get } from 'svelte/store';
import { getQueryParamsFromHash } from '../lib/router.svelte';
import { isNHash, isNPath, nhashDecode, npathDecode } from '@hashtree/core';
import { nip19 } from 'nostr-tools';
import type { RouteInfo } from '../utils/route';

// Store for the current hash
export const currentHash = writable<string>(window.location.hash);

function safeDecodeURIComponent(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

// Initialize hash listener
if (typeof window !== 'undefined') {
  const syncHash = () => {
    currentHash.set(window.location.hash);
  };

  window.addEventListener('hashchange', syncHash);

  // Ensure the initial hash is captured after the app is mounted.
  // This avoids missing the direct-nav hash if module load happens too early.
  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', syncHash, { once: true });
  } else {
    requestAnimationFrame(syncHash);
  }
}

/**
 * Parse route info from hash
 */
export function parseRouteFromHash(hash: string): RouteInfo {
  // Remove #/ prefix
  const hashPath = hash.replace(/^#\/?/, '');

  // Parse query params
  let path = hashPath;
  const qIdx = hashPath.indexOf('?');
  const params = getQueryParamsFromHash(hash);
  if (qIdx !== -1) {
    path = hashPath.slice(0, qIdx);
  }

  const emptyParams = new URLSearchParams();
  const parts = path.split('/').filter(Boolean).map(safeDecodeURIComponent);

  // nhash route: /nhash1.../path...
  if (parts[0] && isNHash(parts[0])) {
    try {
      const cid = nhashDecode(parts[0]);  // Returns CID with Uint8Array fields
      return { npub: null, treeName: null, cid, path: parts.slice(1), isPermalink: true, params };
    } catch {
      // Invalid nhash, fall through
    }
  }

  // npath route: /npath1...
  if (parts[0] && isNPath(parts[0])) {
    try {
      const decoded = npathDecode(parts[0]);
      const npub = nip19.npubEncode(decoded.pubkey);
      return { npub, treeName: decoded.treeName, cid: null, path: decoded.path || [], isPermalink: false, params };
    } catch {
      // Invalid npath, fall through
    }
  }

  // Special routes (no tree context)
  if (['settings', 'users'].includes(parts[0])) {
    return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
  }

  // User routes
  if (parts[0]?.startsWith('npub')) {
    const npub = parts[0];

    // Special user routes (profile, follows, edit)
    if (['profile', 'follows', 'edit'].includes(parts[1])) {
      return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
    }

    // Tree route: /npub/treeName/path...
    if (parts[1] && !['profile', 'follows', 'edit'].includes(parts[1])) {
      return { npub, treeName: parts[1], cid: null, path: parts.slice(2), isPermalink: false, params };
    }

    // User view: /npub
    return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
  }

  // Home route
  return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
}

/**
 * Derived store for route info
 */
export const routeStore = derived(currentHash, ($hash) => parseRouteFromHash($hash));

/**
 * Get current route synchronously
 */
export function getRouteSync(): RouteInfo {
  return parseRouteFromHash(get(currentHash));
}
