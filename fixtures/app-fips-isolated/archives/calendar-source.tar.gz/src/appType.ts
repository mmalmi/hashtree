/**
 * Tracks which app variant is currently running
 * Set by each main entry point (main.ts, main-docs.ts, main-maps.ts, main-boards.ts, main-calendar.ts, main-git.ts)
 */
export type AppType = 'files' | 'docs' | 'maps' | 'boards' | 'calendar' | 'git';

let currentAppType: AppType = 'files';

export function setAppType(type: AppType) {
  currentAppType = type;
}

export function getAppType(): AppType {
  return currentAppType;
}

export function isFilesApp(): boolean {
  return currentAppType === 'files';
}

export function isCalendarApp(): boolean {
  return currentAppType === 'calendar';
}

export function shouldOpenSourceCodeLinkInNewTab(): boolean {
  return currentAppType !== 'git';
}
