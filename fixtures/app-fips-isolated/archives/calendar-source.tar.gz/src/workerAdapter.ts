/**
 * Worker Adapter public entrypoint.
 * Implementation is split by API surface to keep each module small.
 */
import { WorkerAdapterSocial } from './workerAdapterSocial';
import type { WorkerAdapterConfig, WorkerConstructor } from './workerAdapterCore';

export class WorkerAdapter extends WorkerAdapterSocial {}

export type BackendAdapter = Omit<WorkerAdapter, 'setP2PProvider' | 'setNostrSource' | 'queryEvents'> & {
  setP2PProvider?: WorkerAdapter['setP2PProvider'];
  setNostrSource?: WorkerAdapter['setNostrSource'];
  queryEvents?: WorkerAdapter['queryEvents'];
};

let instance: BackendAdapter | null = null;

// Expose on window for tests to reliably access (avoids Vite module duplication issues)
declare global {
  interface Window {
    __workerAdapter?: BackendAdapter | null;
  }
}

export function getWorkerAdapter(): BackendAdapter | null {
  return instance;
}

export function setWorkerAdapterInstance(adapter: BackendAdapter | null): void {
  instance = adapter;

  if (typeof window !== 'undefined') {
    window.__workerAdapter = instance;
  }
}

export async function initWorkerAdapter(
  workerFactory: WorkerConstructor,
  config: WorkerAdapterConfig
): Promise<WorkerAdapter> {
  if (instance) {
    return instance as WorkerAdapter;
  }

  instance = new WorkerAdapter(workerFactory, config);
  await (instance as WorkerAdapter).init();

  // Expose on window for tests
  if (typeof window !== 'undefined') {
    window.__workerAdapter = instance;
  }

  return instance as WorkerAdapter;
}
