/**
 * Global type declarations for window properties
 * Used for HMR singleton patterns and test helpers
 */

import type { NostrStore } from './nostr';

declare global {
  interface Window {
    __testFipsWebsocketSeedUrls?: string[];
    // HMR singleton patterns
    __nostrStore?: NostrStore;
    __settingsStore?: unknown;
  }
}

export {};
