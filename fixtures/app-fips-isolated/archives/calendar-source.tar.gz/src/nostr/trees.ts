/**
 * Tree Publishing and Management
 */
import { linkSecretFromHex } from '../lib/hashtreeKeys';
import { nip19 } from 'nostr-tools';
import {
  encryptKeyForLink,
  toHex,
  type CID,
  type TreeVisibility,
} from '@hashtree/core';
import { nostrStore } from './store';
import { updateLocalRootCache } from '../treeRootCache';
import { findTreeSharingSecret } from '../lib/treeSharingSecret';
import { getRefResolver } from '../refResolver';
import { resolvePublishLabels } from '@iris/hashtree-app/publishLabels';

export interface SaveHashtreeOptions {
  visibility?: TreeVisibility;
  /** Sharing secret for a new link. Edits reuse the existing tree secret. */
  linkKey?: string;
  /** Additional l-tags to add (e.g., ['docs'] for document trees) */
  labels?: string[];
}

/**
 * Save/publish hashtree to relays
 * Uses the resolver's publish method which handles all visibility encryption.
 * @param name - Tree name
 * @param rootCid - Root CID (hash + optional encryption key)
 * @param options - Visibility options
 * @returns Object with success status and linkKey (for link-visible trees)
 */
export async function saveHashtree(
  name: string,
  rootCid: CID,
  options: SaveHashtreeOptions = {}
): Promise<{ success: boolean; linkKey?: string }> {
  const state = nostrStore.getState();
  if (!state.pubkey || !state.npub) return { success: false };

  const visibility = options.visibility ?? 'public';
  let linkKey: Uint8Array | undefined;
  if (visibility === 'link-visible') {
    const secret = options.linkKey ?? await findTreeSharingSecret(state.npub, name);
    if (!secret || !rootCid.key) return { success: false };
    linkKey = linkSecretFromHex(secret);
    // Reject incompatible writes before updating the cached or selected root.
    encryptKeyForLink(rootCid.key, linkKey);
  }
  const resolver = getRefResolver();

  const currentSelected = state.selectedTree;
  const selectedTreeLabels = currentSelected && currentSelected.name === name && currentSelected.pubkey === state.pubkey
    ? currentSelected.labels
    : undefined;

  const publishLabels = resolvePublishLabels({
    currentLabels: selectedTreeLabels,
    explicitLabels: options.labels,
  });

  if (nostrStore.getState().npub !== state.npub) return { success: false };

  // Optimistically update local state for offline-first behavior
  if (currentSelected && currentSelected.name === name && currentSelected.pubkey === state.pubkey) {
    nostrStore.setSelectedTree({
      ...currentSelected,
      labels: publishLabels,
      rootHash: toHex(rootCid.hash),
      rootKey: rootCid.key ? toHex(rootCid.key) : undefined,
      visibility,
      created_at: Math.floor(Date.now() / 1000),
    });
  }

  // Update treeRootCache immediately so local ops don't wait on publish
  updateLocalRootCache(state.npub, name, rootCid.hash, rootCid.key, visibility, publishLabels);

  // Use resolver to publish - it handles all visibility encryption
  const result = await resolver.publish?.(
    `${state.npub}/${name}`,
    rootCid,
    {
      visibility,
      linkKey,
      labels: publishLabels,
    }
  );

  if (!result?.success) {
    return { success: false, linkKey: result?.linkKey ? toHex(result.linkKey) : undefined };
  }

  return {
    success: true,
    linkKey: result.linkKey ? toHex(result.linkKey) : undefined,
  };
}

/**
 * Get pubkey from npub
 */
export function npubToPubkey(npubStr: string): string | null {
  try {
    const decoded = nip19.decode(npubStr);
    if (decoded.type !== 'npub') return null;
    return decoded.data as string;
  } catch {
    return null;
  }
}
