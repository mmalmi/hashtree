/**
 * Nostr integration for HashTree Explorer
 * Uses the shared pubsub worker for events and offline storage
 */

// Store exports
export {
  nostrStore,
  useNostrStore,
  type NostrState,
  type RelayStatus,
  type RelayInfo,
} from './store';

export { nostr } from './client';

// Relay management exports
export {
  updateConnectedRelayCount,
  initRelayTracking,
} from './relays';

// Authentication exports
export {
  restoreSession,
  loginWithExtension,
  loginWithRemoteSigner,
  loginWithNsec,
  generateNewKey,
  waitForNostrExtension,
  getNsec,
  encrypt,
  decrypt,
} from './auth';

// Tree management exports
export {
  saveHashtree,
} from './trees';
