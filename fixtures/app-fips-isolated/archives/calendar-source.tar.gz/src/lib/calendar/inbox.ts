import { finalizeEvent, generateSecretKey, getEventHash, getPublicKey, nip19, nip44, verifyEvent, type Event } from 'nostr-tools';
import { fromHex } from '@hashtree/core';
import { nostr } from '../../nostr/client';
import { decrypt, encrypt } from '../../nostr/auth';
import { parseCalendarMessage, type CalendarMessage, type OutgoingMessage } from './messages';
import type { CalendarEvent } from './types';

/** Calendar messages travel as NIP-59 gift wraps: only the recipient learns who sent what. */
const SEAL_KIND = 13;
const WRAP_KIND = 1059;
const MESSAGE_KIND = 30078;
const DAY_SECONDS = 24 * 60 * 60;

const seconds = () => Math.floor(Date.now() / 1000);
const randomPast = () => seconds() - Math.floor(Math.random() * 2 * DAY_SECONDS);

export interface ReceivedMessage {
  from: string;
  message: CalendarMessage;
  sentAt: number;
}

async function wrap(fromPubkey: string, { to, message }: OutgoingMessage): Promise<Event> {
  const recipient = nip19.decode(to).data as string;
  const rumor = { kind: MESSAGE_KIND, pubkey: fromPubkey, created_at: seconds(), tags: [['p', recipient]], content: JSON.stringify(message) };
  const seal = await nostr.signEvent({
    kind: SEAL_KIND,
    created_at: randomPast(),
    content: await encrypt(recipient, JSON.stringify({ ...rumor, id: getEventHash(rumor) })),
  });
  const ephemeral = generateSecretKey();
  const content = nip44.v2.encrypt(JSON.stringify(seal), nip44.v2.utils.getConversationKey(ephemeral, recipient));
  return finalizeEvent({ kind: WRAP_KIND, created_at: randomPast(), tags: [['p', recipient]], content }, ephemeral);
}

type Decrypt = (peer: string, ciphertext: string) => string | Promise<string>;

async function unwrap(event: Event, open: Decrypt = decrypt): Promise<ReceivedMessage | null> {
  const seal = JSON.parse(await open(event.pubkey, event.content)) as Event;
  if (seal.kind !== SEAL_KIND) return null;
  const rumor = JSON.parse(await open(seal.pubkey, seal.content));
  // Chat messages share this inbox; skip them before the costlier signature check.
  if (rumor?.kind !== MESSAGE_KIND || rumor.pubkey !== seal.pubkey || !verifyEvent(seal)) return null;
  const message = parseCalendarMessage(JSON.parse(rumor.content));
  return message ? { from: nip19.npubEncode(seal.pubkey), message, sentAt: rumor.created_at * 1000 } : null;
}

/** Sends without waiting for relays; delivery continues in the background worker. */
export function sendCalendarMessages(fromPubkey: string, outgoing: OutgoingMessage[]): void {
  for (const item of outgoing) {
    void wrap(fromPubkey, item)
      .then(event => nostr.publish(event))
      .catch(error => console.warn('[Calendar] could not send message', error));
  }
}

/**
 * Delivers messages addressed to `pubkey`. History before the last visit is skipped,
 * with a week of overlap: applying a message twice changes nothing.
 */
export function subscribeCalendarMessages(pubkey: string, onMessage: (received: ReceivedMessage) => void): () => void {
  const cursorKey = `iris-calendar:inbox:${pubkey}`;
  let cursor = 0;
  try {
    cursor = Number(localStorage.getItem(cursorKey)) || 0;
  } catch { /* storage unavailable: read everything */ }
  const filter = { kinds: [WRAP_KIND], '#p': [pubkey], ...(cursor ? { since: cursor - 7 * DAY_SECONDS } : {}) };
  const subscription = nostr.subscribe(filter);
  const seen = new Set<string>();
  subscription.on('event', (event) => {
    if (seen.has(event.id)) return;
    seen.add(event.id);
    void unwrap(event).then(received => received && onMessage(received), () => {});
  });
  subscription.on('history', () => {
    try {
      localStorage.setItem(cursorKey, String(seconds()));
    } catch { /* ignore */ }
  });
  return () => subscription.stop();
}

/**
 * Follows the event behind an invite link. The link's secret is a shared key pair:
 * its inbox holds the organizer's latest copy, and nobody else's. Reports null when none is found.
 */
export function watchInvite(secret: string, organizer: string, onEvent: (event: CalendarEvent | null) => void): () => void {
  const key = fromHex(secret);
  const open: Decrypt = (peer, ciphertext) => nip44.v2.decrypt(ciphertext, nip44.v2.utils.getConversationKey(key, peer));
  const subscription = nostr.subscribe({ kinds: [WRAP_KIND], '#p': [getPublicKey(key)] });
  let latest = -1;
  const opening = new Set<Promise<void>>();
  subscription.on('event', (event) => {
    const done = unwrap(event, open).then((received) => {
      if (received?.from !== organizer || received.message.type !== 'invite') return;
      const invite = received.message.event;
      if (invite.updatedAt <= latest) return;
      latest = invite.updatedAt;
      onEvent(invite);
    }, () => {}).finally(() => opening.delete(done));
    opening.add(done);
  });
  subscription.on('history', () => void Promise.all(opening).then(() => latest < 0 && onEvent(null)));
  return () => subscription.stop();
}
