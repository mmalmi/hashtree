import type { BookingLink, BookingSlot, CalendarData } from './types';
import { addLocalDays, isBusyEvent, normalizeBookingLink, normalizeSlug, randomId, startOfLocalDay, touchCalendar } from './model';
import { expandRecurringEvents } from './recurrence';

const MINUTE_MS = 60 * 1000;
const DAY_MS = 24 * 60 * MINUTE_MS;

export function addBookingLink(data: CalendarData, actor: string, now = Date.now()): CalendarData {
  const index = data.bookingLinks.length + 1;
  const title = index === 1 ? 'Meet' : `Meet ${index}`;
  const link: BookingLink = {
    id: randomId('booking'),
    slug: uniqueSlug(data.bookingLinks.map(item => item.slug), title.toLowerCase()),
    title,
    durationMinutes: data.availability.slotDurationMinutes,
    enabled: true,
    createdAt: now,
    updatedAt: now,
  };
  return touchCalendar({ ...data, bookingLinks: [...data.bookingLinks, link] }, actor, now);
}

export function updateBookingLink(
  data: CalendarData,
  linkId: string,
  patch: Partial<Pick<BookingLink, 'title' | 'slug' | 'durationMinutes' | 'enabled'>>,
  actor: string,
  now = Date.now()
): CalendarData {
  const link = data.bookingLinks.find(item => item.id === linkId);
  if (!link) return data;
  const slugs = data.bookingLinks.filter(item => item !== link).map(item => item.slug);
  const next = normalizeBookingLink({
    ...link,
    ...patch,
    title: patch.title?.trim() || link.title,
    slug: patch.slug ? uniqueSlug(slugs, patch.slug) : link.slug,
    durationMinutes: patch.durationMinutes ?? link.durationMinutes,
    updatedAt: now,
  })!;
  return touchCalendar({ ...data, bookingLinks: data.bookingLinks.map(item => item === link ? next : item) }, actor, now);
}

export function removeBookingLink(data: CalendarData, linkId: string, actor: string, now = Date.now()): CalendarData {
  const bookingLinks = data.bookingLinks.filter(link => link.id !== linkId);
  if (bookingLinks.length === data.bookingLinks.length) return data;
  return touchCalendar({ ...data, bookingLinks }, actor, now);
}

/** Slots starting on the viewer's local `date`, from availability kept in the owner's time zone. */
export function computeBookingSlots(
  data: CalendarData,
  linkId: string,
  date: Date,
  now = Date.now()
): BookingSlot[] {
  const link = data.bookingLinks.find(item => item.id === linkId);
  const { availability } = data;
  const durationMs = (link?.durationMinutes ?? 0) * MINUTE_MS;
  const stepMs = availability.slotDurationMinutes * MINUTE_MS;
  if (!link?.enabled || durationMs <= 0 || stepMs <= 0) return [];

  const dayStart = startOfLocalDay(date).getTime();
  const dayEnd = addLocalDays(startOfLocalDay(date), 1).getTime();
  const minimumStart = now + availability.minimumNoticeMinutes * MINUTE_MS;
  const bufferBeforeMs = availability.bufferBeforeMinutes * MINUTE_MS;
  const bufferAfterMs = availability.bufferAfterMinutes * MINUTE_MS;
  const busy = expandRecurringEvents(
    data.events.filter(isBusyEvent),
    new Date(dayStart - DAY_MS - bufferBeforeMs),
    new Date(dayEnd + DAY_MS + bufferAfterMs),
  ).map(event => ({
    start: new Date(event.start).getTime() - bufferBeforeMs,
    end: new Date(event.end).getTime() + bufferAfterMs,
  }));
  const slots: BookingSlot[] = [];

  // The owner's days that can overlap the viewer's day.
  for (const offset of [-1, 0, 1]) {
    const ownerDay = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate() + offset));
    const rule = availability.rules.find(item => item.weekday === ownerDay.getUTCDay() && item.enabled);
    if (!rule) continue;
    const start = zonedTime(ownerDay, rule.startTime, availability.timezone);
    const end = zonedTime(ownerDay, rule.endTime, availability.timezone);
    for (let cursor = start; cursor + durationMs <= end; cursor += stepMs) {
      const slotEnd = cursor + durationMs;
      if (cursor < dayStart || cursor >= dayEnd || cursor < minimumStart) continue;
      if (busy.some(event => overlaps(cursor, slotEnd, event.start, event.end))) continue;
      slots.push({ start: new Date(cursor).toISOString(), end: new Date(slotEnd).toISOString() });
    }
  }
  return slots;
}

const zoneFormatters = new Map<string, Intl.DateTimeFormat>();

/** The instant when clocks in `timeZone` show `time` on the UTC calendar day `day`. */
function zonedTime(day: Date, time: string, timeZone: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  const wall = Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate(), hours, minutes);
  const first = wall - zoneOffset(wall, timeZone);
  return wall - zoneOffset(first, timeZone);
}

function zoneOffset(instant: number, timeZone: string): number {
  let formatter = zoneFormatters.get(timeZone);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat('en-US', {
      timeZone, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric',
    });
    zoneFormatters.set(timeZone, formatter);
  }
  const part = Object.fromEntries(formatter.formatToParts(instant).map(({ type, value }) => [type, Number(value)]));
  const minute = Math.floor(instant / MINUTE_MS) * MINUTE_MS;
  return Date.UTC(part.year, part.month - 1, part.day, part.hour, part.minute) - minute;
}

export function findNextBookingDate(
  data: CalendarData,
  linkId: string,
  fromDate: Date,
  now = Date.now(),
  maxDays = 60,
): Date | null {
  const daysToSearch = Math.max(0, Math.floor(maxDays));
  for (let offset = 0; offset <= daysToSearch; offset += 1) {
    const candidate = addLocalDays(startOfLocalDay(fromDate), offset);
    if (computeBookingSlots(data, linkId, candidate, now).length > 0) {
      return candidate;
    }
  }
  return null;
}

function uniqueSlug(existing: readonly string[], value: string): string {
  const base = normalizeSlug(value, 'meet');
  const taken = new Set(existing);
  if (!taken.has(base)) return base;
  for (let index = 2; index < 1000; index += 1) {
    const candidate = `${base}-${index}`;
    if (!taken.has(candidate)) return candidate;
  }
  return `${base}-${Date.now().toString(36)}`;
}

function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}
