import type { CalendarColor, CalendarEvent, CalendarTimeFormat, CalendarView } from './types';

export const CALENDAR_VIEW_OPTIONS: Array<{ value: CalendarView; label: string }> = [
  { value: 'day', label: 'Day' },
  { value: 'week', label: 'Week' },
  { value: 'month', label: 'Month' },
  { value: 'year', label: 'Year' },
  { value: 'agenda', label: 'Agenda' },
];

export function monthLabel(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    month: 'long',
    year: 'numeric',
  }).format(date);
}

export function shortMonthLabel(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function dayLabel(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function addDays(date: Date, count: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + count);
}

export function viewLabel(view: CalendarView): string {
  return CALENDAR_VIEW_OPTIONS.find(option => option.value === view)?.label ?? 'Month';
}

export function dateNumberLabel(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    day: 'numeric',
  }).format(date);
}

export function monthDayLabel(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function timeOptions(timeFormat: CalendarTimeFormat, includeMinute = true): Intl.DateTimeFormatOptions {
  const options: Intl.DateTimeFormatOptions = {
    hour: 'numeric',
  };
  if (includeMinute) {
    options.minute = '2-digit';
  }
  if (timeFormat === '12h') {
    options.hour12 = true;
  } else if (timeFormat === '24h') {
    options.hourCycle = 'h23';
  }
  return options;
}

export function formatTime(value: string, timeFormat: CalendarTimeFormat = 'auto'): string {
  return new Intl.DateTimeFormat(undefined, timeOptions(timeFormat)).format(new Date(value));
}

export function formatHourLabel(hour: number, timeFormat: CalendarTimeFormat = 'auto'): string {
  return new Intl.DateTimeFormat(undefined, timeOptions(timeFormat, false)).format(new Date(2026, 0, 1, hour, 0, 0, 0));
}

export function eventTimeLabel(event: CalendarEvent, timeFormat: CalendarTimeFormat = 'auto'): string {
  if (event.allDay) return 'All day';
  return `${formatTime(event.start, timeFormat)} - ${formatTime(event.end, timeFormat)}`;
}

export function eventDateLabel(event: CalendarEvent): string {
  const start = new Date(event.start);
  const end = new Date(event.end);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return dayLabel(start);

  const displayEnd = event.allDay
    ? addDays(new Date(end.getFullYear(), end.getMonth(), end.getDate()), -1)
    : end;
  const startLabel = dayLabel(start);
  const endLabel = dayLabel(displayEnd);
  return startLabel === endLabel ? startLabel : `${startLabel} - ${endLabel}`;
}

export function eventToneClass(color: CalendarColor): string {
  return ({
    violet: 'border-l-accent bg-accent/10',
    green: 'border-l-success bg-success/10',
    blue: 'border-l-sky-500 bg-sky-500/10',
    amber: 'border-l-amber-500 bg-amber-500/10',
    rose: 'border-l-rose-500 bg-rose-500/10',
    slate: 'border-l-text-3 bg-surface-2',
  } as const)[color];
}
