import type { CalendarEvent, CalendarTimeFormat, CalendarView } from './types';

export const CALENDAR_VIEW_OPTIONS: Array<{ value: CalendarView; label: string }> = [
  { value: 'day', label: 'Day' },
  { value: 'week', label: 'Week' },
  { value: 'month', label: 'Month' },
  { value: 'year', label: 'Year' },
  { value: 'agenda', label: 'Agenda' },
];

const formatters = new Map<string, Intl.DateTimeFormat>();

/** A date formatter for the viewer's locale, built once per option set. */
export function dateFormatter(options: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  const key = JSON.stringify(options);
  let formatter = formatters.get(key);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat(undefined, options);
    formatters.set(key, formatter);
  }
  return formatter;
}

export function monthLabel(date: Date): string {
  return dateFormatter({
    month: 'long',
    year: 'numeric',
  }).format(date);
}

export function shortMonthLabel(date: Date): string {
  return dateFormatter({
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function dayLabel(date: Date): string {
  return dateFormatter({
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function addDays(date: Date, count: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + count);
}

export function dateNumberLabel(date: Date): string {
  return dateFormatter({
    day: 'numeric',
  }).format(date);
}

export function monthDayLabel(date: Date): string {
  return dateFormatter({
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function timeOptions(timeFormat: CalendarTimeFormat, includeMinute = true): Intl.DateTimeFormatOptions {
  const options: Intl.DateTimeFormatOptions = {
    hour: 'numeric',
  };
  if (includeMinute) {
    options.minute = '2-digit';
  }
  if (timeFormat === '12h') {
    options.hour12 = true;
  } else if (timeFormat === '24h') {
    options.hourCycle = 'h23';
  }
  return options;
}

export function formatTime(value: string, timeFormat: CalendarTimeFormat = 'auto'): string {
  return dateFormatter(timeOptions(timeFormat)).format(new Date(value));
}

export function formatHourLabel(hour: number, timeFormat: CalendarTimeFormat = 'auto'): string {
  return dateFormatter(timeOptions(timeFormat, false)).format(new Date(2026, 0, 1, hour, 0, 0, 0));
}

export function eventTimeLabel(event: CalendarEvent, timeFormat: CalendarTimeFormat = 'auto'): string {
  if (event.allDay) return 'All day';
  return `${formatTime(event.start, timeFormat)} - ${formatTime(event.end, timeFormat)}`;
}

export function eventDateLabel(event: CalendarEvent): string {
  const start = new Date(event.start);
  const end = new Date(event.end);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return dayLabel(start);

  const displayEnd = event.allDay
    ? addDays(new Date(end.getFullYear(), end.getMonth(), end.getDate()), -1)
    : end;
  const startLabel = dayLabel(start);
  const endLabel = dayLabel(displayEnd);
  return startLabel === endLabel ? startLabel : `${startLabel} - ${endLabel}`;
}

const EVENT_COLOR_CLASSES = {
  violet: 'border-accent bg-accent/15 text-accent',
  green: 'border-success bg-success/15 text-success',
  blue: 'border-sky-500 bg-sky-500/15 text-sky-300',
  amber: 'border-amber-500 bg-amber-500/15 text-amber-300',
  rose: 'border-rose-500 bg-rose-500/15 text-rose-300',
  slate: 'border-text-3 bg-surface-2 text-text-1',
} as const;

const EVENT_TONE_CLASSES = {
  violet: 'border-l-accent bg-accent/10',
  green: 'border-l-success bg-success/10',
  blue: 'border-l-sky-500 bg-sky-500/10',
  amber: 'border-l-amber-500 bg-amber-500/10',
  rose: 'border-l-rose-500 bg-rose-500/10',
  slate: 'border-l-text-3 bg-surface-2',
} as const;

/** Classes for event blocks on the grids. */
export function eventClass(event: CalendarEvent): string {
  return `${EVENT_COLOR_CLASSES[event.color]} ${eventStateClass(event)}`;
}

/** Classes for event rows in lists. */
export function eventToneClass(event: CalendarEvent): string {
  return `${EVENT_TONE_CLASSES[event.color]} ${eventStateClass(event)}`;
}

/** Unanswered invites look tentative; cancelled ones are struck through. */
export function eventStateClass(event: CalendarEvent): string {
  if (event.cancelled) return 'event-cancelled';
  return event.organizer && (event.rsvp === 'needs-action' || event.rsvp === 'tentative') ? 'event-pending' : '';
}
