import { fromHex, toHex } from '@hashtree/core';
import { getPublicKey, nip19 } from 'nostr-tools';
import type { CalendarData, CalendarEvent } from './types';
import { isBusyEvent, isShownEvent } from './model';
import { expandRecurringEvents } from './recurrence';

/** Copies of the calendar that others read with a link secret. */
export const SHARED_TREE_NAME = 'calendar-shared';
export const BOOKING_TREE_NAME = 'calendar-booking';
const BOOKING_WINDOW_DAYS = 120;

export function newLinkKey(): string {
  return toHex(crypto.getRandomValues(new Uint8Array(32)));
}

function publicCopy(data: CalendarData, events: CalendarEvent[]): CalendarData {
  return {
    ...data,
    events,
    bookingLinks: data.bookingLinks.filter(link => link.enabled),
    shareKey: undefined,
    sharedWith: [],
    bookingKey: undefined,
    subscriptions: [],
    shareWithdrawals: undefined,
  };
}

/** Everything people I share with may see; their own replies stay private to me. */
export function sharedCalendarView(data: CalendarData): CalendarData {
  return publicCopy(data, data.events.filter(isShownEvent).map(event => ({ ...event, rsvp: undefined, inviteKey: undefined })));
}

/** Only busy intervals, for strangers picking a booking slot. Day-aligned so it changes once a day at most. */
export function bookingCalendarView(data: CalendarData, now = Date.now()): CalendarData {
  const from = new Date(now);
  from.setHours(0, 0, 0, 0);
  const to = new Date(from.getFullYear(), from.getMonth(), from.getDate() + BOOKING_WINDOW_DAYS);
  const busy = expandRecurringEvents(data.events.filter(isBusyEvent), from, to).map((event, index) => ({
    id: `busy-${index}`,
    title: 'Busy',
    start: event.start,
    end: event.end,
    allDay: false,
    color: 'slate' as const,
    createdAt: 0,
    updatedAt: 0,
  }));
  return { ...publicCopy(data, busy), title: data.title, updatedAt: 0, updatedBy: data.ownerNpub };
}

export function bookingUrl(ownerNpub: string, slug: string, key: string): string {
  return `https://calendar.iris.to/#/book/${ownerNpub}/${encodeURIComponent(slug)}?k=${key}`;
}

/** The inbox that everyone holding an invite link reads. */
export function inviteNpub(key: string): string {
  return nip19.npubEncode(getPublicKey(fromHex(key)));
}

export function inviteUrl(organizerNpub: string, key: string): string {
  return `https://calendar.iris.to/#/invite/${organizerNpub}?k=${key}`;
}
