import { addLocalDays, sortEvents, startOfLocalDay } from './model';
import { expandRecurringEvents } from './recurrence';
import type { CalendarEvent } from './types';

export function eventsForDay(events: readonly CalendarEvent[], day: Date): CalendarEvent[] {
  const start = startOfLocalDay(day);
  return sortEvents(expandRecurringEvents(events, start, addLocalDays(start, 1)));
}

/**
 * Looks up the events on any of `days` after expanding their whole span once.
 * A view asks for dozens to hundreds of days; scanning every event per day
 * repeats the same date parsing for each cell.
 */
export function eventsByDay(
  events: readonly CalendarEvent[],
  days: readonly Date[],
): (day: Date) => CalendarEvent[] {
  const starts = [...new Set(days.map(day => startOfLocalDay(day).getTime()))].sort((a, b) => a - b);
  const ends = starts.map(start => addLocalDays(new Date(start), 1).getTime());
  const buckets = starts.map((): CalendarEvent[] => []);
  if (starts.length > 0) {
    const span = expandRecurringEvents(events, new Date(starts[0]), new Date(ends[ends.length - 1]));
    for (const event of sortEvents(span)) {
      const eventStart = new Date(event.start).getTime();
      const eventEnd = new Date(event.end).getTime();
      for (let index = 0; index < starts.length && starts[index] < eventEnd; index += 1) {
        if (ends[index] > eventStart) buckets[index].push(event);
      }
    }
  }
  const indexByStart = new Map(starts.map((start, index) => [start, index]));
  return (day) => {
    const index = indexByStart.get(startOfLocalDay(day).getTime());
    return index === undefined ? eventsForDay(events, day) : buckets[index];
  };
}
