import {
  CALENDAR_DATA_VERSION,
  type AvailabilityRule,
  type AvailabilitySettings,
  type BookingLink,
  type BookingSlot,
  type CalendarColor,
  type CalendarData,
  type CalendarTimeFormat,
  type CalendarEvent,
  type CalendarWeekday,
  type EventDraft,
} from './types';
import { expandRecurringEvents, normalizeRecurrence } from './recurrence';
const DEFAULT_COLORS: readonly CalendarColor[] = ['violet', 'green', 'blue', 'amber', 'rose', 'slate'];
const DEFAULT_SLOT_DURATION = 30;
const MINUTE_MS = 60 * 1000;
export const WEEKDAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;

function randomId(prefix: string): string {
  const suffix = typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}-${suffix}`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function textFromRaw(raw: unknown): string | null {
  if (typeof raw === 'string') return raw;
  if (raw instanceof Uint8Array) return new TextDecoder().decode(raw);
  if (raw instanceof ArrayBuffer) return new TextDecoder().decode(new Uint8Array(raw));
  if (ArrayBuffer.isView(raw)) {
    return new TextDecoder().decode(new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength));
  }
  return null;
}

function parseJsonRecord(raw: unknown): Record<string, unknown> | null {
  const text = textFromRaw(raw);
  if (text !== null) {
    try {
      const parsed = JSON.parse(text);
      return isRecord(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  return isRecord(raw) ? raw : null;
}

function normalizeString(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const trimmed = value.trim();
  return trimmed || fallback;
}

function normalizeOptionalString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function normalizeNumber(value: unknown, fallback: number, min = 0, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

function normalizeTimestamp(value: unknown, fallback = Date.now()): number {
  return normalizeNumber(value, fallback, 0);
}

function normalizeIso(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : date.toISOString();
}

function normalizeTime(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const trimmed = value.trim();
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(trimmed) ? trimmed : fallback;
}

function normalizeColor(value: unknown, fallback: CalendarColor): CalendarColor {
  return DEFAULT_COLORS.includes(value as CalendarColor) ? value as CalendarColor : fallback;
}

function normalizeWeekday(value: unknown, fallback: CalendarWeekday): CalendarWeekday {
  const normalized = normalizeNumber(value, fallback, 0, 6);
  return normalized as CalendarWeekday;
}

function currentTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

export function createDefaultAvailability(timezone = currentTimezone()): AvailabilitySettings {
  const rules: AvailabilityRule[] = [];
  for (let weekday = 0; weekday < 7; weekday += 1) {
    rules.push({
      id: `weekday-${weekday}`,
      weekday: weekday as CalendarWeekday,
      enabled: weekday >= 1 && weekday <= 5,
      startTime: '09:00',
      endTime: '17:00',
    });
  }
  return {
    timezone,
    slotDurationMinutes: DEFAULT_SLOT_DURATION,
    bufferBeforeMinutes: 0,
    bufferAfterMinutes: 0,
    minimumNoticeMinutes: 120,
    rules,
  };
}

export function createInitialCalendarData(ownerNpub: string, now = Date.now()): CalendarData {
  return {
    version: CALENDAR_DATA_VERSION,
    calendarId: randomId('calendar'),
    title: 'Calendar',
    ownerNpub,
    timezone: currentTimezone(),
    timeFormat: 'auto',
    startOfWeek: 'monday',
    events: [],
    availability: createDefaultAvailability(),
    bookingLinks: [
      {
        id: randomId('booking'),
        slug: 'meet',
        title: 'Meet',
        durationMinutes: DEFAULT_SLOT_DURATION,
        enabled: true,
        createdAt: now,
        updatedAt: now,
      },
    ],
    updatedAt: now,
    updatedBy: ownerNpub,
  };
}

function normalizeAvailability(raw: unknown, fallback: AvailabilitySettings): AvailabilitySettings {
  if (!isRecord(raw)) return fallback;
  const rulesRaw = Array.isArray(raw.rules) ? raw.rules : [];
  const fallbackRules = new Map(fallback.rules.map(rule => [rule.weekday, rule]));
  const rules = rulesRaw
    .filter(isRecord)
    .map((rule, index): AvailabilityRule => {
      const weekday = normalizeWeekday(rule.weekday, (index % 7) as CalendarWeekday);
      const fallbackRule = fallbackRules.get(weekday) ?? fallback.rules[index % fallback.rules.length];
      return {
        id: normalizeString(rule.id, fallbackRule?.id ?? `weekday-${weekday}`),
        weekday,
        enabled: typeof rule.enabled === 'boolean' ? rule.enabled : fallbackRule?.enabled ?? false,
        startTime: normalizeTime(rule.startTime, fallbackRule?.startTime ?? '09:00'),
        endTime: normalizeTime(rule.endTime, fallbackRule?.endTime ?? '17:00'),
      };
    });

  const deduped = new Map<CalendarWeekday, AvailabilityRule>();
  for (const rule of [...fallback.rules, ...rules]) {
    deduped.set(rule.weekday, rule);
  }

  return {
    timezone: normalizeString(raw.timezone, fallback.timezone),
    slotDurationMinutes: normalizeNumber(raw.slotDurationMinutes, fallback.slotDurationMinutes, 5, 480),
    bufferBeforeMinutes: normalizeNumber(raw.bufferBeforeMinutes, fallback.bufferBeforeMinutes, 0, 240),
    bufferAfterMinutes: normalizeNumber(raw.bufferAfterMinutes, fallback.bufferAfterMinutes, 0, 240),
    minimumNoticeMinutes: normalizeNumber(raw.minimumNoticeMinutes, fallback.minimumNoticeMinutes, 0, 60 * 24 * 365),
    rules: Array.from(deduped.values()).sort((a, b) => a.weekday - b.weekday),
  };
}

function normalizeEvent(raw: unknown): CalendarEvent | null {
  if (!isRecord(raw)) return null;
  const start = normalizeIso(raw.start, '');
  const end = normalizeIso(raw.end, '');
  const title = normalizeString(raw.title, '');
  if (!title || !start || !end) return null;
  const startMs = new Date(start).getTime();
  const endMs = new Date(end).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) return null;
  const createdAt = normalizeTimestamp(raw.createdAt, startMs);
  return {
    id: normalizeString(raw.id, randomId('event')),
    title,
    start,
    end: endMs > startMs ? end : new Date(startMs + 30 * MINUTE_MS).toISOString(),
    allDay: typeof raw.allDay === 'boolean' ? raw.allDay : false,
    color: normalizeColor(raw.color, 'violet'),
    location: normalizeOptionalString(raw.location),
    notes: normalizeOptionalString(raw.notes),
    recurrence: normalizeRecurrence(raw.recurrence, new Date(start)),
    createdAt,
    updatedAt: normalizeTimestamp(raw.updatedAt, createdAt),
  };
}

function normalizeBookingLink(raw: unknown, fallbackTitle = 'Meet'): BookingLink | null {
  if (!isRecord(raw)) return null;
  const title = normalizeString(raw.title, fallbackTitle);
  const slug = normalizeSlug(typeof raw.slug === 'string' ? raw.slug : '', title.toLowerCase());
  const createdAt = normalizeTimestamp(raw.createdAt);
  return {
    id: normalizeString(raw.id, randomId('booking')),
    slug,
    title,
    durationMinutes: normalizeNumber(raw.durationMinutes, DEFAULT_SLOT_DURATION, 5, 480),
    enabled: typeof raw.enabled === 'boolean' ? raw.enabled : true,
    createdAt,
    updatedAt: normalizeTimestamp(raw.updatedAt, createdAt),
  };
}

function normalizeTimeFormat(value: unknown): CalendarTimeFormat {
  return value === '12h' || value === '24h' ? value : 'auto';
}

export function parseCalendarData(raw: unknown, ownerNpub: string): CalendarData | null {
  const parsed = parseJsonRecord(raw);
  if (!parsed) return null;

  const fallback = createInitialCalendarData(ownerNpub);
  const events = Array.isArray(parsed.events)
    ? parsed.events.map(event => normalizeEvent(event)).filter((event): event is CalendarEvent => !!event)
    : [];
  const bookingLinks = Array.isArray(parsed.bookingLinks)
    ? parsed.bookingLinks.map(link => normalizeBookingLink(link)).filter((link): link is BookingLink => !!link)
    : fallback.bookingLinks;

  return {
    version: CALENDAR_DATA_VERSION,
    calendarId: normalizeString(parsed.calendarId, fallback.calendarId),
    title: normalizeString(parsed.title, fallback.title),
    ownerNpub: normalizeString(parsed.ownerNpub, ownerNpub),
    timezone: normalizeString(parsed.timezone, fallback.timezone),
    timeFormat: normalizeTimeFormat(parsed.timeFormat),
    startOfWeek: parsed.startOfWeek === 'sunday' ? 'sunday' : 'monday',
    events: sortEvents(events),
    availability: normalizeAvailability(parsed.availability, fallback.availability),
    bookingLinks,
    updatedAt: normalizeTimestamp(parsed.updatedAt, fallback.updatedAt),
    updatedBy: normalizeString(parsed.updatedBy, ownerNpub),
  };
}

export function serializeCalendarData(data: CalendarData): string {
  return `${JSON.stringify(data, null, 2)}\n`;
}

export function sortEvents(events: CalendarEvent[]): CalendarEvent[] {
  return [...events].sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
}

export function makeEventDraft(date = new Date()): EventDraft {
  const start = defaultDraftStart(date);
  const end = new Date(start.getTime() + 30 * MINUTE_MS);
  return {
    title: '',
    start: toDateTimeInputValue(start),
    end: toDateTimeInputValue(end),
    allDay: false,
    color: 'violet',
    location: '',
    notes: '',
  };
}

function defaultDraftStart(date: Date): Date {
  if (!isStartOfLocalDay(date)) return roundUpToNextHalfHour(date);

  const now = new Date();
  if (toDateInputValue(date) === toDateInputValue(now)) {
    return roundUpToNextHalfHour(now);
  }

  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 9, 0, 0, 0);
}

function isStartOfLocalDay(date: Date): boolean {
  return date.getHours() === 0
    && date.getMinutes() === 0
    && date.getSeconds() === 0
    && date.getMilliseconds() === 0;
}

export function upsertCalendarEvent(data: CalendarData, draft: EventDraft, actor: string, now = Date.now()): CalendarData {
  const title = draft.title.trim();
  if (!title) return data;
  const draftAllDay = draft.allDay ?? false;
  const start = draftAllDay ? parseDraftDate(draft.start) : new Date(draft.start);
  const end = draftAllDay ? parseDraftDate(draft.end) : new Date(draft.end);
  if (Number.isNaN(start.getTime())) return data;
  const eventStart = draftAllDay ? startOfLocalDay(start) : start;
  const safeEnd = safeDraftEnd(eventStart, end, draftAllDay);
  const existing = draft.id ? data.events.find(event => event.id === draft.id) : undefined;
  const nextEvent: CalendarEvent = {
    id: existing?.id ?? randomId('event'),
    title,
    start: eventStart.toISOString(),
    end: safeEnd.toISOString(),
    allDay: draftAllDay,
    color: draft.color ?? existing?.color ?? 'violet',
    location: draft.location?.trim() || undefined,
    notes: draft.notes?.trim() || undefined,
    recurrence: normalizeRecurrence(draft.recurrence, eventStart),
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };

  const events = existing
    ? data.events.map(event => event.id === existing.id ? nextEvent : event)
    : [...data.events, nextEvent];

  return touchCalendar({ ...data, events: sortEvents(events) }, actor, now);
}

function parseDraftDate(value: string): Date {
  return parseDateInputValue(value) ?? new Date(value);
}

function safeDraftEnd(start: Date, end: Date, allDay: boolean): Date {
  if (!allDay) {
    return !Number.isNaN(end.getTime()) && end.getTime() > start.getTime()
      ? end
      : new Date(start.getTime() + 30 * MINUTE_MS);
  }

  const inclusiveEnd = !Number.isNaN(end.getTime()) && end >= start ? startOfLocalDay(end) : start;
  return addLocalDays(inclusiveEnd, 1);
}

export function removeCalendarEvent(data: CalendarData, eventId: string, actor: string, now = Date.now()): CalendarData {
  const events = data.events.filter(event => event.id !== eventId);
  if (events.length === data.events.length) return data;
  return touchCalendar({ ...data, events }, actor, now);
}

export function updateAvailability(
  data: CalendarData,
  availability: AvailabilitySettings,
  actor: string,
  now = Date.now()
): CalendarData {
  return touchCalendar({
    ...data,
    availability: normalizeAvailability(availability, data.availability),
  }, actor, now);
}

export function addBookingLink(data: CalendarData, actor: string, now = Date.now()): CalendarData {
  const index = data.bookingLinks.length + 1;
  const title = index === 1 ? 'Meet' : `Meet ${index}`;
  const link: BookingLink = {
    id: randomId('booking'),
    slug: uniqueSlug(data.bookingLinks.map(item => item.slug), title.toLowerCase()),
    title,
    durationMinutes: data.availability.slotDurationMinutes,
    enabled: true,
    createdAt: now,
    updatedAt: now,
  };
  return touchCalendar({ ...data, bookingLinks: [...data.bookingLinks, link] }, actor, now);
}

export function updateBookingLink(
  data: CalendarData,
  linkId: string,
  patch: Partial<Pick<BookingLink, 'title' | 'slug' | 'durationMinutes' | 'enabled'>>,
  actor: string,
  now = Date.now()
): CalendarData {
  const slugs = data.bookingLinks.filter(link => link.id !== linkId).map(link => link.slug);
  let changed = false;
  const bookingLinks = data.bookingLinks.map((link) => {
    if (link.id !== linkId) return link;
    changed = true;
    const title = normalizeString(patch.title, link.title);
    return {
      ...link,
      title,
      slug: patch.slug ? uniqueSlug(slugs, patch.slug) : link.slug,
      durationMinutes: normalizeNumber(patch.durationMinutes, link.durationMinutes, 5, 480),
      enabled: typeof patch.enabled === 'boolean' ? patch.enabled : link.enabled,
      updatedAt: now,
    };
  });
  return changed ? touchCalendar({ ...data, bookingLinks }, actor, now) : data;
}

export function removeBookingLink(data: CalendarData, linkId: string, actor: string, now = Date.now()): CalendarData {
  const bookingLinks = data.bookingLinks.filter(link => link.id !== linkId);
  if (bookingLinks.length === data.bookingLinks.length) return data;
  return touchCalendar({ ...data, bookingLinks }, actor, now);
}

export function touchCalendar(data: CalendarData, actor: string, now = Date.now()): CalendarData {
  return {
    ...data,
    updatedAt: now,
    updatedBy: actor,
  };
}

export function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function addLocalDays(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

export function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDateInputValue(value: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(year, month - 1, day);
  if (
    date.getFullYear() !== year
    || date.getMonth() !== month - 1
    || date.getDate() !== day
  ) {
    return null;
  }
  return date;
}

export function toDateTimeInputValue(date: Date): string {
  const hours = `${date.getHours()}`.padStart(2, '0');
  const minutes = `${date.getMinutes()}`.padStart(2, '0');
  return `${toDateInputValue(date)}T${hours}:${minutes}`;
}

export function roundUpToNextHalfHour(date: Date): Date {
  const next = new Date(date);
  next.setSeconds(0, 0);
  const minutes = next.getMinutes();
  const extra = minutes === 0 || minutes === 30 ? 0 : minutes < 30 ? 30 - minutes : 60 - minutes;
  next.setMinutes(minutes + extra);
  return next;
}

export function monthMatrix(monthDate: Date, startOfWeek: 'monday' | 'sunday'): Date[] {
  const first = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
  const startOffset = startOfWeek === 'monday'
    ? (first.getDay() + 6) % 7
    : first.getDay();
  const start = new Date(first);
  start.setDate(first.getDate() - startOffset);
  return Array.from({ length: 42 }, (_, index) => addLocalDays(start, index));
}

export function weekDays(anchorDate: Date, startOfWeek: 'monday' | 'sunday'): Date[] {
  const anchor = startOfLocalDay(anchorDate);
  const startOffset = startOfWeek === 'monday'
    ? (anchor.getDay() + 6) % 7
    : anchor.getDay();
  const start = new Date(anchor);
  start.setDate(anchor.getDate() - startOffset);
  return Array.from({ length: 7 }, (_, index) => addLocalDays(start, index));
}

export function yearMonths(anchorDate: Date): Date[] {
  const year = anchorDate.getFullYear();
  return Array.from({ length: 12 }, (_, month) => new Date(year, month, 1));
}

export function eventsForDay(events: readonly CalendarEvent[], day: Date): CalendarEvent[] {
  const start = startOfLocalDay(day);
  return sortEvents(expandRecurringEvents(events, start, addLocalDays(start, 1)));
}

export function uniqueEventsForDays(events: readonly CalendarEvent[], days: readonly Date[]): CalendarEvent[] {
  const seen = new Set<string>();
  const unique: CalendarEvent[] = [];
  for (const day of days) {
    for (const event of eventsForDay(events, day)) {
      if (seen.has(event.id)) continue;
      seen.add(event.id);
      unique.push(event);
    }
  }
  return sortEvents(unique);
}

export function upcomingEvents(events: readonly CalendarEvent[], now = Date.now(), limit = 8): CalendarEvent[] {
  const rangeEnd = new Date(now + 366 * 24 * 60 * MINUTE_MS);
  return sortEvents(expandRecurringEvents(events, new Date(now), rangeEnd)).slice(0, limit);
}

export function computeBookingSlots(
  data: CalendarData,
  linkId: string,
  date: Date,
  now = Date.now()
): BookingSlot[] {
  const link = data.bookingLinks.find(item => item.id === linkId);
  if (!link || !link.enabled) return [];
  const day = startOfLocalDay(date);
  const weekday = day.getDay() as CalendarWeekday;
  const rule = data.availability.rules.find(item => item.weekday === weekday && item.enabled);
  if (!rule) return [];

  const start = setTimeOnDate(day, rule.startTime);
  const end = setTimeOnDate(day, rule.endTime);
  if (end <= start) return [];

  const minimumStart = now + data.availability.minimumNoticeMinutes * MINUTE_MS;
  const durationMs = link.durationMinutes * MINUTE_MS;
  const stepMs = data.availability.slotDurationMinutes * MINUTE_MS;
  if (durationMs <= 0 || stepMs <= 0) return [];

  const bufferBeforeMs = data.availability.bufferBeforeMinutes * MINUTE_MS;
  const bufferAfterMs = data.availability.bufferAfterMinutes * MINUTE_MS;
  const busy = expandRecurringEvents(data.events, new Date(start.getTime() - bufferBeforeMs), new Date(end.getTime() + bufferAfterMs)).map(event => ({
    start: new Date(event.start).getTime() - bufferBeforeMs,
    end: new Date(event.end).getTime() + bufferAfterMs,
  }));
  const slots: BookingSlot[] = [];

  for (let cursor = start.getTime(); cursor + durationMs <= end.getTime(); cursor += stepMs) {
    const slotEnd = cursor + durationMs;
    if (cursor < minimumStart) continue;
    if (busy.some(event => overlaps(cursor, slotEnd, event.start, event.end))) continue;
    slots.push({
      start: new Date(cursor).toISOString(),
      end: new Date(slotEnd).toISOString(),
    });
  }

  return slots;
}

export function findNextBookingDate(
  data: CalendarData,
  linkId: string,
  fromDate: Date,
  now = Date.now(),
  maxDays = 60,
): Date | null {
  const daysToSearch = Math.max(0, Math.floor(maxDays));
  for (let offset = 0; offset <= daysToSearch; offset += 1) {
    const candidate = addLocalDays(startOfLocalDay(fromDate), offset);
    if (computeBookingSlots(data, linkId, candidate, now).length > 0) {
      return candidate;
    }
  }
  return null;
}

export function normalizeSlug(value: string, fallback: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return slug || fallback.replace(/[^a-z0-9]+/g, '-') || 'meet';
}

function uniqueSlug(existing: readonly string[], value: string): string {
  const base = normalizeSlug(value, 'meet');
  const taken = new Set(existing);
  if (!taken.has(base)) return base;
  for (let index = 2; index < 1000; index += 1) {
    const candidate = `${base}-${index}`;
    if (!taken.has(candidate)) return candidate;
  }
  return `${base}-${Date.now().toString(36)}`;
}

function setTimeOnDate(date: Date, time: string): Date {
  const [hours, minutes] = time.split(':').map(Number);
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours, minutes, 0, 0);
}

function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}
