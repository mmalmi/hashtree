import {
  CALENDAR_DATA_VERSION,
  type AvailabilityRule,
  type AvailabilitySettings,
  type BookingLink,
  type CalendarColor,
  type CalendarData,
  type CalendarTimeFormat,
  type CalendarEvent,
  type CalendarGuest,
  type CalendarWeekday,
  type EventDraft,
  type RsvpStatus,
  type SharedCalendar,
} from './types';
import { isLinkSecretHex } from '../hashtreeKeys';
import { expandRecurringEvents, normalizeRecurrence } from './recurrence';
const DEFAULT_COLORS: readonly CalendarColor[] = ['violet', 'green', 'blue', 'amber', 'rose', 'slate'];
const DEFAULT_SLOT_DURATION = 30;
const MINUTE_MS = 60 * 1000;
export const WEEKDAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
const RSVP_STATUSES: readonly RsvpStatus[] = ['needs-action', 'accepted', 'tentative', 'declined'];

export function isNpub(value: unknown): value is string {
  return typeof value === 'string' && /^npub1[02-9ac-hj-np-z]{58}$/.test(value);
}

export function randomId(prefix: string): string {
  const suffix = typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}-${suffix}`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function textFromRaw(raw: unknown): string | null {
  if (typeof raw === 'string') return raw;
  if (raw instanceof Uint8Array) return new TextDecoder().decode(raw);
  if (raw instanceof ArrayBuffer) return new TextDecoder().decode(new Uint8Array(raw));
  if (ArrayBuffer.isView(raw)) {
    return new TextDecoder().decode(new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength));
  }
  return null;
}

function parseJsonRecord(raw: unknown): Record<string, unknown> | null {
  const text = textFromRaw(raw);
  if (text !== null) {
    try {
      const parsed = JSON.parse(text);
      return isRecord(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  return isRecord(raw) ? raw : null;
}

function normalizeString(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const trimmed = value.trim();
  return trimmed || fallback;
}

function normalizeOptionalString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function normalizeNumber(value: unknown, fallback: number, min = 0, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

function normalizeTimestamp(value: unknown, fallback = Date.now()): number {
  return normalizeNumber(value, fallback, 0);
}

function normalizeIso(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : date.toISOString();
}

function normalizeTime(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback;
  const trimmed = value.trim();
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(trimmed) ? trimmed : fallback;
}

function normalizeColor(value: unknown, fallback: CalendarColor): CalendarColor {
  return DEFAULT_COLORS.includes(value as CalendarColor) ? value as CalendarColor : fallback;
}

function normalizeWeekday(value: unknown, fallback: CalendarWeekday): CalendarWeekday {
  const normalized = normalizeNumber(value, fallback, 0, 6);
  return normalized as CalendarWeekday;
}

function currentTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

export function createDefaultAvailability(timezone = currentTimezone()): AvailabilitySettings {
  const rules: AvailabilityRule[] = [];
  for (let weekday = 0; weekday < 7; weekday += 1) {
    rules.push({
      id: `weekday-${weekday}`,
      weekday: weekday as CalendarWeekday,
      enabled: weekday >= 1 && weekday <= 5,
      startTime: '09:00',
      endTime: '17:00',
    });
  }
  return {
    timezone,
    slotDurationMinutes: DEFAULT_SLOT_DURATION,
    bufferBeforeMinutes: 0,
    bufferAfterMinutes: 0,
    minimumNoticeMinutes: 120,
    rules,
  };
}

export function createInitialCalendarData(ownerNpub: string, now = Date.now()): CalendarData {
  return {
    version: CALENDAR_DATA_VERSION,
    calendarId: randomId('calendar'),
    title: 'Calendar',
    ownerNpub,
    timezone: currentTimezone(),
    timeFormat: 'auto',
    startOfWeek: 'monday',
    events: [],
    availability: createDefaultAvailability(),
    bookingLinks: [
      {
        id: randomId('booking'),
        slug: 'meet',
        title: 'Meet',
        durationMinutes: DEFAULT_SLOT_DURATION,
        enabled: true,
        createdAt: now,
        updatedAt: now,
      },
    ],
    sharedWith: [],
    subscriptions: [],
    updatedAt: now,
    updatedBy: ownerNpub,
  };
}

function normalizeAvailability(raw: unknown, fallback: AvailabilitySettings): AvailabilitySettings {
  if (!isRecord(raw)) return fallback;
  const rulesRaw = Array.isArray(raw.rules) ? raw.rules : [];
  const fallbackRules = new Map(fallback.rules.map(rule => [rule.weekday, rule]));
  const rules = rulesRaw
    .filter(isRecord)
    .map((rule, index): AvailabilityRule => {
      const weekday = normalizeWeekday(rule.weekday, (index % 7) as CalendarWeekday);
      const fallbackRule = fallbackRules.get(weekday) ?? fallback.rules[index % fallback.rules.length];
      return {
        id: normalizeString(rule.id, fallbackRule?.id ?? `weekday-${weekday}`),
        weekday,
        enabled: typeof rule.enabled === 'boolean' ? rule.enabled : fallbackRule?.enabled ?? false,
        startTime: normalizeTime(rule.startTime, fallbackRule?.startTime ?? '09:00'),
        endTime: normalizeTime(rule.endTime, fallbackRule?.endTime ?? '17:00'),
      };
    });

  const deduped = new Map<CalendarWeekday, AvailabilityRule>();
  for (const rule of [...fallback.rules, ...rules]) {
    deduped.set(rule.weekday, rule);
  }

  return {
    timezone: validTimezone(raw.timezone) ?? fallback.timezone,
    slotDurationMinutes: normalizeNumber(raw.slotDurationMinutes, fallback.slotDurationMinutes, 5, 480),
    bufferBeforeMinutes: normalizeNumber(raw.bufferBeforeMinutes, fallback.bufferBeforeMinutes, 0, 240),
    bufferAfterMinutes: normalizeNumber(raw.bufferAfterMinutes, fallback.bufferAfterMinutes, 0, 240),
    minimumNoticeMinutes: normalizeNumber(raw.minimumNoticeMinutes, fallback.minimumNoticeMinutes, 0, 60 * 24 * 365),
    rules: Array.from(deduped.values()).sort((a, b) => a.weekday - b.weekday),
  };
}

export function normalizeEvent(raw: unknown): CalendarEvent | null {
  if (!isRecord(raw)) return null;
  const day = raw.allDay === true && typeof raw.day === 'string' ? parseDateInputValue(raw.day) : null;
  const start = day ? day.toISOString() : normalizeIso(raw.start, '');
  const end = day ? addLocalDays(day, normalizeNumber(raw.days, 1, 1, 3660)).toISOString() : normalizeIso(raw.end, '');
  const title = normalizeString(raw.title, '');
  if (!title || !start || !end) return null;
  const startMs = new Date(start).getTime();
  const endMs = new Date(end).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) return null;
  const createdAt = normalizeTimestamp(raw.createdAt, startMs);
  return {
    id: normalizeString(raw.id, randomId('event')),
    title,
    start,
    end: endMs > startMs ? end : new Date(startMs + 30 * MINUTE_MS).toISOString(),
    allDay: typeof raw.allDay === 'boolean' ? raw.allDay : false,
    color: normalizeColor(raw.color, 'violet'),
    location: normalizeOptionalString(raw.location),
    notes: normalizeOptionalString(raw.notes),
    recurrence: normalizeRecurrence(raw.recurrence, new Date(start)),
    organizer: isNpub(raw.organizer) ? raw.organizer : undefined,
    guests: normalizeGuests(raw.guests),
    rsvp: normalizeRsvp(raw.rsvp),
    cancelled: raw.cancelled === true || undefined,
    inviteKey: isLinkSecretHex(raw.inviteKey) ? raw.inviteKey : undefined,
    createdAt,
    updatedAt: normalizeTimestamp(raw.updatedAt, createdAt),
  };
}

function normalizeRsvp(value: unknown): RsvpStatus | undefined {
  return RSVP_STATUSES.includes(value as RsvpStatus) ? value as RsvpStatus : undefined;
}

export function normalizeGuests(raw: unknown): CalendarGuest[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const guests = new Map<string, CalendarGuest>();
  for (const guest of raw.filter(isRecord)) {
    if (!isNpub(guest.npub)) continue;
    const at = normalizeNumber(guest.at, 0) || undefined;
    const name = normalizeOptionalString(guest.name)?.slice(0, 80);
    guests.set(guest.npub, { npub: guest.npub, status: normalizeRsvp(guest.status) ?? 'needs-action', at, name });
  }
  return guests.size > 0 ? [...guests.values()] : undefined;
}

function normalizeSubscription(raw: unknown): SharedCalendar | null {
  if (!isRecord(raw) || !isNpub(raw.npub) || !isLinkSecretHex(raw.key)) return null;
  return {
    npub: raw.npub,
    title: normalizeString(raw.title, 'Shared calendar'),
    key: raw.key,
    color: normalizeColor(raw.color, 'blue'),
    hidden: raw.hidden === true || undefined,
    updatedAt: normalizeTimestamp(raw.updatedAt, 0),
  };
}

export function normalizeBookingLink(raw: unknown, fallbackTitle = 'Meet'): BookingLink | null {
  if (!isRecord(raw)) return null;
  const title = normalizeString(raw.title, fallbackTitle);
  const slug = normalizeSlug(typeof raw.slug === 'string' ? raw.slug : '', title.toLowerCase());
  const createdAt = normalizeTimestamp(raw.createdAt);
  return {
    id: normalizeString(raw.id, randomId('booking')),
    slug,
    title,
    durationMinutes: normalizeNumber(raw.durationMinutes, DEFAULT_SLOT_DURATION, 5, 480),
    enabled: typeof raw.enabled === 'boolean' ? raw.enabled : true,
    createdAt,
    updatedAt: normalizeTimestamp(raw.updatedAt, createdAt),
  };
}

function normalizeTimeFormat(value: unknown): CalendarTimeFormat {
  return value === '12h' || value === '24h' ? value : 'auto';
}

export function parseCalendarData(raw: unknown, ownerNpub: string): CalendarData | null {
  const parsed = parseJsonRecord(raw);
  if (!parsed) return null;

  const fallback = createInitialCalendarData(ownerNpub);
  const events = Array.isArray(parsed.events)
    ? parsed.events.map(event => normalizeEvent(event)).filter((event): event is CalendarEvent => !!event)
    : [];
  const bookingLinks = Array.isArray(parsed.bookingLinks)
    ? parsed.bookingLinks.map(link => normalizeBookingLink(link)).filter((link): link is BookingLink => !!link)
    : fallback.bookingLinks;

  return {
    version: CALENDAR_DATA_VERSION,
    calendarId: normalizeString(parsed.calendarId, fallback.calendarId),
    title: normalizeString(parsed.title, fallback.title),
    ownerNpub: normalizeString(parsed.ownerNpub, ownerNpub),
    timezone: normalizeString(parsed.timezone, fallback.timezone),
    timeFormat: normalizeTimeFormat(parsed.timeFormat),
    startOfWeek: parsed.startOfWeek === 'sunday' ? 'sunday' : 'monday',
    events: sortEvents(events),
    availability: normalizeAvailability(parsed.availability, fallback.availability),
    bookingLinks,
    shareKey: isLinkSecretHex(parsed.shareKey) ? parsed.shareKey : undefined,
    sharedWith: Array.isArray(parsed.sharedWith) ? [...new Set(parsed.sharedWith.filter(isNpub))] : [],
    bookingKey: isLinkSecretHex(parsed.bookingKey) ? parsed.bookingKey : undefined,
    subscriptions: Array.isArray(parsed.subscriptions)
      ? parsed.subscriptions.map(normalizeSubscription).filter((item): item is SharedCalendar => !!item)
      : [],
    shareWithdrawals: isRecord(parsed.shareWithdrawals)
      ? Object.fromEntries(Object.entries(parsed.shareWithdrawals).filter((entry): entry is [string, number] => {
        const [npub, at] = entry;
        return isNpub(npub) && typeof at === 'number' && Number.isSafeInteger(at) && at >= 0;
      }))
      : undefined,
    updatedAt: normalizeTimestamp(parsed.updatedAt, fallback.updatedAt),
    updatedBy: normalizeString(parsed.updatedBy, ownerNpub),
  };
}

export function serializeCalendarData(data: CalendarData): string {
  return `${JSON.stringify({ ...data, events: data.events.map(withLocalDays) }, null, 2)}\n`;
}

/** All-day events also travel as calendar dates, so they keep their days in every time zone. */
export function withLocalDays(event: CalendarEvent): CalendarEvent & { day?: string; days?: number } {
  if (!event.allDay) return event;
  const start = startOfLocalDay(new Date(event.start));
  const days = Math.round((startOfLocalDay(new Date(event.end)).getTime() - start.getTime()) / (24 * 60 * MINUTE_MS));
  return { ...event, day: toDateInputValue(start), days: Math.max(1, days) };
}

export function sortEvents(events: CalendarEvent[]): CalendarEvent[] {
  return [...events].sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
}

export function makeEventDraft(date = new Date()): EventDraft {
  const start = defaultDraftStart(date);
  const end = new Date(start.getTime() + 30 * MINUTE_MS);
  return {
    title: '',
    start: toDateTimeInputValue(start),
    end: toDateTimeInputValue(end),
    allDay: false,
    color: 'violet',
    location: '',
    notes: '',
  };
}

function defaultDraftStart(date: Date): Date {
  if (!isStartOfLocalDay(date)) return roundUpToNextHalfHour(date);

  const now = new Date();
  if (toDateInputValue(date) === toDateInputValue(now)) {
    return roundUpToNextHalfHour(now);
  }

  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 9, 0, 0, 0);
}

function isStartOfLocalDay(date: Date): boolean {
  return date.getHours() === 0
    && date.getMinutes() === 0
    && date.getSeconds() === 0
    && date.getMilliseconds() === 0;
}

export function upsertCalendarEvent(data: CalendarData, draft: EventDraft, actor: string, now = Date.now()): CalendarData {
  const title = draft.title.trim();
  if (!title) return data;
  const draftAllDay = draft.allDay ?? false;
  const start = draftAllDay ? parseDraftDate(draft.start) : new Date(draft.start);
  const end = draftAllDay ? parseDraftDate(draft.end) : new Date(draft.end);
  if (Number.isNaN(start.getTime())) return data;
  const eventStart = draftAllDay ? startOfLocalDay(start) : start;
  const safeEnd = safeDraftEnd(eventStart, end, draftAllDay);
  const existing = draft.id ? data.events.find(event => event.id === draft.id) : undefined;
  const nextEvent: CalendarEvent = {
    id: existing?.id ?? randomId('event'),
    title,
    start: eventStart.toISOString(),
    end: safeEnd.toISOString(),
    allDay: draftAllDay,
    color: draft.color ?? existing?.color ?? 'violet',
    location: draft.location?.trim() || undefined,
    notes: draft.notes?.trim() || undefined,
    recurrence: normalizeRecurrence(draft.recurrence, eventStart),
    organizer: existing?.organizer,
    guests: normalizeGuests(draft.guests ?? existing?.guests),
    rsvp: existing?.rsvp,
    inviteKey: 'inviteKey' in draft ? draft.inviteKey : existing?.inviteKey,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };

  const events = existing
    ? data.events.map(event => event.id === existing.id ? nextEvent : event)
    : [...data.events, nextEvent];

  return touchCalendar({ ...data, events: sortEvents(events) }, actor, now);
}

function parseDraftDate(value: string): Date {
  return parseDateInputValue(value) ?? new Date(value);
}

function safeDraftEnd(start: Date, end: Date, allDay: boolean): Date {
  if (!allDay) {
    return !Number.isNaN(end.getTime()) && end.getTime() > start.getTime()
      ? end
      : new Date(start.getTime() + 30 * MINUTE_MS);
  }

  const inclusiveEnd = !Number.isNaN(end.getTime()) && end >= start ? startOfLocalDay(end) : start;
  return addLocalDays(inclusiveEnd, 1);
}

/** Shared events stay behind as hidden tombstones, so replayed messages cannot bring them back. */
export function removeCalendarEvent(data: CalendarData, eventId: string, actor: string, now = Date.now()): CalendarData {
  const event = data.events.find(item => item.id === eventId);
  if (!event) return data;
  const tombstone = event.organizer
    ? { ...event, rsvp: 'declined' as const }
    : event.guests || event.inviteKey ? { ...event, cancelled: true, updatedAt: now } : null;
  const events = tombstone
    ? data.events.map(item => item === event ? tombstone : item)
    : data.events.filter(item => item !== event);
  return touchCalendar({ ...data, events }, actor, now);
}

export function setEventRsvp(data: CalendarData, eventId: string, rsvp: RsvpStatus, actor: string, now = Date.now()): CalendarData {
  const events = data.events.map(event => event.id === eventId && event.organizer ? { ...event, rsvp } : event);
  return touchCalendar({ ...data, events }, actor, now);
}

export function isBusyEvent(event: CalendarEvent): boolean {
  return isShownEvent(event) && !event.cancelled;
}

/** Declined invites and my own cancelled events are kept only as tombstones. */
export function isShownEvent(event: CalendarEvent): boolean {
  return event.rsvp !== 'declined' && !(event.cancelled && !event.organizer);
}

export function updateAvailability(
  data: CalendarData,
  availability: AvailabilitySettings,
  actor: string,
  now = Date.now()
): CalendarData {
  return touchCalendar({
    ...data,
    availability: normalizeAvailability(availability, data.availability),
  }, actor, now);
}

export function touchCalendar(data: CalendarData, actor: string, now = Date.now()): CalendarData {
  return {
    ...data,
    updatedAt: now,
    updatedBy: actor,
  };
}

export function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

export function addLocalDays(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

export function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDateInputValue(value: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(year, month - 1, day);
  if (
    date.getFullYear() !== year
    || date.getMonth() !== month - 1
    || date.getDate() !== day
  ) {
    return null;
  }
  return date;
}

export function toDateTimeInputValue(date: Date): string {
  const hours = `${date.getHours()}`.padStart(2, '0');
  const minutes = `${date.getMinutes()}`.padStart(2, '0');
  return `${toDateInputValue(date)}T${hours}:${minutes}`;
}

export function roundUpToNextHalfHour(date: Date): Date {
  const next = new Date(date);
  next.setSeconds(0, 0);
  const minutes = next.getMinutes();
  const extra = minutes === 0 || minutes === 30 ? 0 : minutes < 30 ? 30 - minutes : 60 - minutes;
  next.setMinutes(minutes + extra);
  return next;
}

export function monthMatrix(monthDate: Date, startOfWeek: 'monday' | 'sunday'): Date[] {
  const first = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
  const startOffset = startOfWeek === 'monday'
    ? (first.getDay() + 6) % 7
    : first.getDay();
  const start = new Date(first);
  start.setDate(first.getDate() - startOffset);
  return Array.from({ length: 42 }, (_, index) => addLocalDays(start, index));
}

export function weekDays(anchorDate: Date, startOfWeek: 'monday' | 'sunday'): Date[] {
  const anchor = startOfLocalDay(anchorDate);
  const startOffset = startOfWeek === 'monday'
    ? (anchor.getDay() + 6) % 7
    : anchor.getDay();
  const start = new Date(anchor);
  start.setDate(anchor.getDate() - startOffset);
  return Array.from({ length: 7 }, (_, index) => addLocalDays(start, index));
}

export function yearMonths(anchorDate: Date): Date[] {
  const year = anchorDate.getFullYear();
  return Array.from({ length: 12 }, (_, month) => new Date(year, month, 1));
}

export function upcomingEvents(events: readonly CalendarEvent[], now = Date.now(), limit = 8): CalendarEvent[] {
  const rangeEnd = new Date(now + 366 * 24 * 60 * MINUTE_MS);
  return sortEvents(expandRecurringEvents(events, new Date(now), rangeEnd)).slice(0, limit);
}

function validTimezone(value: unknown): string | undefined {
  if (typeof value !== 'string' || !value.trim()) return undefined;
  try {
    return new Intl.DateTimeFormat('en-US', { timeZone: value.trim() }).resolvedOptions().timeZone;
  } catch {
    return undefined;
  }
}

export function normalizeSlug(value: string, fallback: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return slug || fallback.replace(/[^a-z0-9]+/g, '-') || 'meet';
}
