import type { CalendarData, CalendarEvent, CalendarGuest, RsvpStatus } from './types';
import { isNpub, normalizeEvent, sortEvents, touchCalendar, withLocalDays } from './model';
import { computeBookingSlots } from './booking';
import { inviteNpub } from './sharing';
import { isLinkSecretHex } from '../hashtreeKeys';

/** What calendars tell each other inside encrypted, sealed messages. */
export type CalendarMessage =
  | { type: 'invite'; event: CalendarEvent }
  | { type: 'rsvp'; id: string; status: RsvpStatus; invite?: string; name?: string }
  | { type: 'share'; title: string; key?: string }
  | { type: 'book'; id: string; slug: string; start: string; end: string; name: string; note?: string };

export interface OutgoingMessage {
  to: string;
  message: CalendarMessage;
}

const SHARED_COLORS = ['blue', 'amber', 'rose', 'green', 'slate'] as const;

export function parseCalendarMessage(raw: unknown): CalendarMessage | null {
  if (typeof raw !== 'object' || raw === null) return null;
  const message = raw as Record<string, unknown>;
  const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
  if (message.type === 'invite') {
    const event = normalizeEvent(message.event);
    return event ? { type: 'invite', event } : null;
  }
  if (message.type === 'rsvp' && text(message.id)) {
    const status = message.status;
    return status === 'accepted' || status === 'tentative' || status === 'declined'
      ? {
        type: 'rsvp', id: text(message.id), status,
        invite: isLinkSecretHex(message.invite) ? message.invite : undefined,
        name: text(message.name).slice(0, 80) || undefined,
      }
      : null;
  }
  if (message.type === 'share') {
    return { type: 'share', title: text(message.title) || 'Shared calendar', key: isLinkSecretHex(message.key) ? message.key : undefined };
  }
  if (message.type === 'book' && text(message.id) && text(message.slug) && text(message.name)) {
    const start = new Date(text(message.start));
    const end = new Date(text(message.end));
    if (Number.isNaN(start.getTime()) || !(end > start)) return null;
    return {
      type: 'book', id: text(message.id), slug: text(message.slug), name: text(message.name).slice(0, 120),
      start: start.toISOString(), end: end.toISOString(), note: text(message.note).slice(0, 2000) || undefined,
    };
  }
  return null;
}

/** The event as guests receive it: my private fields stay home. */
function invite(event: CalendarEvent, cancelled = event.cancelled): CalendarMessage {
  const shared = { ...withLocalDays(event), cancelled: cancelled || undefined };
  for (const key of ['rsvp', 'organizer', 'calendar', 'recurrenceSourceId'] as const) delete shared[key];
  return { type: 'invite', event: shared };
}

/** Guests' inboxes, and the invite link's inbox, which link holders read. */
function inboxes(event: CalendarEvent | undefined): string[] {
  if (!event) return [];
  return [...event.guests?.map(guest => guest.npub) ?? [], ...event.inviteKey ? [inviteNpub(event.inviteKey)] : []];
}

/** Messages a saved change owes to guests or to the organizer. */
export function changeMessages(before: CalendarEvent | undefined, after: CalendarEvent | undefined): OutgoingMessage[] {
  const event = after ?? before;
  if (!event) return [];
  if (event.organizer) {
    const status = after?.rsvp;
    return status && status !== 'needs-action' && status !== before?.rsvp
      ? [{ to: event.organizer, message: { type: 'rsvp', id: event.id, status, invite: event.inviteKey } }]
      : [];
  }
  const invited = new Set(after?.cancelled ? [] : inboxes(after));
  return [...new Set([...inboxes(before), ...inboxes(after)])].map(to => {
    if (invited.has(to)) return { to, message: invite(event) };
    // A former guest or link receives a cancellation without the replacement link or the new details.
    const cancellation = { ...(before ?? event), updatedAt: event.updatedAt };
    delete cancellation.inviteKey;
    return { to, message: invite(cancellation, true) };
  });
}

/** Applies one message from `from`; returns the next calendar and any replies. */
export function applyCalendarMessage(
  data: CalendarData,
  from: string,
  message: CalendarMessage,
  sentAt: number,
  now = Date.now(),
): { data: CalendarData; replies: OutgoingMessage[] } {
  const unchanged = { data, replies: [] };
  if (!isNpub(from) || from === data.ownerNpub) return unchanged;
  const existing = 'id' in message ? data.events.find(event => event.id === message.id)
    : message.type === 'invite' ? data.events.find(event => event.id === message.event.id) : undefined;
  const withEvents = (events: CalendarEvent[]) => touchCalendar({ ...data, events: sortEvents(events) }, data.ownerNpub, now);
  const replace = (next: CalendarEvent) => existing
    ? data.events.map(event => event === existing ? next : event)
    : [...data.events, next];

  if (message.type === 'invite') {
    const incoming = message.event;
    if (existing && (existing.organizer !== from || existing.updatedAt >= incoming.updatedAt)) return unchanged;
    const mine = incoming.guests?.find(guest => guest.npub === data.ownerNpub)?.status;
    const rsvp = existing?.rsvp ?? (mine && mine !== 'needs-action' ? mine : 'needs-action');
    return { data: withEvents(replace({ ...incoming, organizer: from, rsvp })), replies: [] };
  }

  // Answers come from guests, or from anyone holding the event's invite link.
  if (message.type === 'rsvp') {
    if (!existing || existing.organizer || existing.cancelled) return unchanged;
    const guest = existing.guests?.find(item => item.npub === from);
    const viaLink = !!existing.inviteKey && message.invite === existing.inviteKey;
    if (guest ? (guest.at ?? 0) >= sentAt : !viaLink) return unchanged;
    const answer: CalendarGuest = { npub: from, status: message.status, at: sentAt, name: message.name ?? guest?.name };
    const guests = guest ? existing.guests!.map(item => item === guest ? answer : item) : [...existing.guests ?? [], answer];
    const updated = { ...existing, guests, updatedAt: now };
    // Link holders see who is coming.
    const replies = existing.inviteKey ? [{ to: inviteNpub(existing.inviteKey), message: invite(updated) }] : [];
    return { data: withEvents(replace(updated)), replies };
  }

  if (message.type === 'share') {
    const current = data.subscriptions.find(item => item.npub === from);
    const withdrawnAt = data.shareWithdrawals?.[from];
    if (withdrawnAt !== undefined && withdrawnAt >= sentAt) return unchanged;
    // Nostr timestamps have second precision. A withdrawal wins a tie with a grant.
    if (current && (current.updatedAt > sentAt || (message.key && current.updatedAt === sentAt))) return unchanged;
    const others = data.subscriptions.filter(item => item !== current);
    const color = current?.color ?? SHARED_COLORS[data.subscriptions.length % SHARED_COLORS.length];
    const subscriptions = message.key
      ? [...others, { npub: from, title: message.title, key: message.key, color, hidden: current?.hidden, updatedAt: sentAt }]
      : others;
    const shareWithdrawals = { ...data.shareWithdrawals };
    if (message.key) delete shareWithdrawals[from];
    else shareWithdrawals[from] = sentAt;
    return { data: touchCalendar({ ...data, subscriptions, shareWithdrawals }, data.ownerNpub, now), replies: [] };
  }

  // A booking request: confirm it if the slot is still free, otherwise tell the guest it was not booked.
  if (existing) return unchanged;
  const link = data.bookingLinks.find(item => item.slug === message.slug && item.enabled);
  const free = !!link && computeBookingSlots(data, link.id, new Date(message.start), now)
    .some(slot => slot.start === message.start && slot.end === message.end);
  const event: CalendarEvent = {
    id: message.id,
    title: `${link?.title ?? 'Booking'}: ${message.name}`,
    start: message.start,
    end: message.end,
    allDay: false,
    color: 'green',
    notes: message.note,
    guests: [{ npub: from, status: 'accepted', at: sentAt }],
    cancelled: free ? undefined : true,
    createdAt: now,
    updatedAt: now,
  };
  return { data: withEvents([...data.events, event]), replies: [{ to: from, message: invite(event) }] };
}
