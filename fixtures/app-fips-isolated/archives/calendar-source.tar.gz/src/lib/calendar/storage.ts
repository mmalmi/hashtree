import { cid, LinkType, type CID } from '@hashtree/core';
import { writerForEntry } from '../treeRewrite';
import { getTree } from '../../store';
import { saveHashtree, useNostrStore } from '../../nostr';
import { createTreesStore, type TreeEntry } from '../../stores/trees';
import { decryptEncryptionKey } from '../../stores/treeRootKeys';
import { CALENDAR_DATA_FILE, CALENDAR_TREE_LABEL, CALENDAR_TREE_NAME, type CalendarData } from './types';
import { createInitialCalendarData, parseCalendarData, serializeCalendarData } from './model';
import { SHARED_TREE_NAME } from './sharing';

const MAX_CALENDAR_BYTES = 16 * 1024 * 1024;

async function buildCalendarRoot(data: CalendarData, previous?: CID): Promise<CID> {
  const tree = getTree();
  const existing = previous ? await tree.resolvePath(previous, [CALENDAR_DATA_FILE]) : null;
  const writer = writerForEntry(writerForEntry(tree, previous), existing?.cid);
  const bytes = new TextEncoder().encode(serializeCalendarData(data));
  const { cid: dataCid, size } = await writer.putFile(bytes);
  const meta = { contentType: 'application/json' };
  if (previous) return tree.setEntry(previous, [], CALENDAR_DATA_FILE, dataCid, size, LinkType.File, meta);
  return (await tree.putDirectory([{ name: CALENDAR_DATA_FILE, cid: dataCid, size, type: LinkType.File, meta }])).cid;
}

/**
 * Reads a calendar root: my own with my key, or someone else's with the link secret they sent.
 * Fails instead of returning an empty calendar, so a missing key can never lead to overwriting data.
 */
export async function loadCalendarData(entry: TreeEntry, ownerNpub: string, linkKey: string | null = null): Promise<{ data: CalendarData; root: CID }> {
  const visibility = entry.visibility && {
    visibility: entry.visibility,
    encryptedKey: entry.encryptedKey,
    keyId: entry.keyId,
    selfEncryptedKey: entry.selfEncryptedKey,
    selfEncryptedLinkKey: entry.selfEncryptedLinkKey,
  };
  const key = await decryptEncryptionKey(visibility, entry.encryptionKey, linkKey);
  if (!key) throw new Error('Calendar key is not available');
  const root = cid(entry.hash, key);
  const tree = getTree();
  const file = await tree.resolvePath(root, [CALENDAR_DATA_FILE]);
  if (!file || file.type === LinkType.Dir) throw new Error('Calendar file is missing');
  const data = parseCalendarData(await tree.readFile(file.cid, { maxBytes: MAX_CALENDAR_BYTES }), ownerNpub);
  if (!data) throw new Error('Calendar file is unreadable');
  return { data, root };
}

export async function createCalendarTree(npub: string): Promise<{ data: CalendarData; root: CID }> {
  const data = createInitialCalendarData(npub);
  const root = await buildCalendarRoot(data);
  const result = await saveHashtree(CALENDAR_TREE_NAME, root, { visibility: 'private', labels: [CALENDAR_TREE_LABEL] });
  if (!result.success) throw new Error('Could not publish the calendar root');
  return { data, root };
}

export async function saveCalendarData(data: CalendarData, previous: CID): Promise<CID> {
  const root = await buildCalendarRoot(data, previous);
  if (useNostrStore.getState().npub !== data.ownerNpub) throw new Error('Account changed before saving');
  const result = await saveHashtree(CALENDAR_TREE_NAME, root, { visibility: 'private', labels: [CALENDAR_TREE_LABEL] });
  if (!result.success) throw new Error('Could not publish the calendar root');
  return root;
}

const publishedViews = new Map<string, string>();

/** Publishes a copy of the calendar that anyone holding `linkKey` can read. Unchanged copies are skipped. */
export async function publishCalendarView(name: string, data: CalendarData, linkKey: string): Promise<void> {
  const json = serializeCalendarData(data);
  const signature = `${data.ownerNpub}:${linkKey}:${json}`;
  if (publishedViews.get(name) === signature) return;
  publishedViews.set(name, signature);
  try {
    const root = await buildCalendarRoot(data);
    const result = await saveHashtree(name, root, { visibility: 'link-visible', linkKey, labels: [CALENDAR_TREE_LABEL] });
    if (!result.success) throw new Error(`Could not publish ${name}`);
  } catch (error) {
    if (publishedViews.get(name) === signature) publishedViews.delete(name);
    throw error;
  }
}

/** Follows a calendar copy published by `npub`, reading it with `linkKey` whenever it changes. */
export function watchCalendarView(
  npub: string,
  linkKey: string,
  onData: (data: CalendarData | null) => void,
  name = SHARED_TREE_NAME,
): () => void {
  let latest = '';
  return createTreesStore(npub).subscribe((entries) => {
    const entry = entries.find(item => item.name === name);
    if (!entry?.encryptedKey || entry.hashHex === latest) return;
    const hash = latest = entry.hashHex;
    loadCalendarData(entry, npub, linkKey).then(
      ({ data }) => hash === latest && onData(data),
      () => hash === latest && onData(null),
    );
  });
}
