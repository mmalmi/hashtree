import { cid, LinkType, toHex, type CID } from '@hashtree/core';
import { writerForEntry } from '../treeRewrite';
import { getTree } from '../../store';
import { saveHashtree, useNostrStore } from '../../nostr';
import {
  CALENDAR_DATA_FILE,
  CALENDAR_TREE_LABEL,
  CALENDAR_TREE_NAME,
  type CalendarData,
} from './types';
import {
  createInitialCalendarData,
  parseCalendarData,
  serializeCalendarData,
} from './model';

export interface CalendarTreeEntry {
  hash: Uint8Array;
  encryptionKey?: Uint8Array;
}

function rootCidFromEntry(entry: CalendarTreeEntry): CID {
  return cid(entry.hash, entry.encryptionKey);
}

async function buildCalendarRoot(data: CalendarData, previous?: CID): Promise<CID> {
  const tree = getTree();
  const existing = previous ? await tree.resolvePath(previous, [CALENDAR_DATA_FILE]) : null;
  const writer = writerForEntry(writerForEntry(tree, previous), existing?.cid);
  const bytes = new TextEncoder().encode(serializeCalendarData(data));
  const { cid: dataCid, size } = await writer.putFile(bytes);
  const meta = { contentType: 'application/json' };
  if (previous) return tree.setEntry(previous, [], CALENDAR_DATA_FILE, dataCid, size, LinkType.File, meta);
  return (await tree.putDirectory([{ name: CALENDAR_DATA_FILE, cid: dataCid, size, type: LinkType.File, meta }])).cid;
}

export async function loadCalendarData(entry: CalendarTreeEntry, ownerNpub: string): Promise<CalendarData> {
  const rootCid = rootCidFromEntry(entry);
  const tree = getTree();
  const resolved = await tree.resolvePath(rootCid, [CALENDAR_DATA_FILE]);
  if (!resolved || resolved.type === LinkType.Dir) {
    return createInitialCalendarData(ownerNpub);
  }

  const raw = await tree.readFile(resolved.cid, { maxBytes: 1024 * 1024 });
  return parseCalendarData(raw, ownerNpub) ?? createInitialCalendarData(ownerNpub);
}

export async function createCalendarTree(): Promise<{ success: boolean; data?: CalendarData; rootCid?: CID }> {
  const nostrState = useNostrStore.getState();
  if (!nostrState.isLoggedIn || !nostrState.npub || !nostrState.pubkey) {
    return { success: false };
  }

  const data = createInitialCalendarData(nostrState.npub);
  const rootCid = await buildCalendarRoot(data);
  useNostrStore.setSelectedTree({
    id: '',
    name: CALENDAR_TREE_NAME,
    pubkey: nostrState.pubkey,
    labels: [CALENDAR_TREE_LABEL],
    rootHash: toHex(rootCid.hash),
    rootKey: rootCid.key ? toHex(rootCid.key) : undefined,
    visibility: 'private',
    created_at: Math.floor(Date.now() / 1000),
  });

  await saveHashtree(CALENDAR_TREE_NAME, rootCid, {
    visibility: 'private',
    labels: [CALENDAR_TREE_LABEL],
  });

  return { success: true, data, rootCid };
}

export async function saveCalendarData(data: CalendarData, previous: CID): Promise<{ success: boolean; rootCid: CID }> {
  const rootCid = await buildCalendarRoot(data, previous);
  if (useNostrStore.getState().npub !== data.ownerNpub) return { success: false, rootCid };
  const result = await saveHashtree(CALENDAR_TREE_NAME, rootCid, {
    visibility: 'private',
    labels: [CALENDAR_TREE_LABEL],
  });
  return { success: result.success, rootCid };
}

export function findCalendarTreeEntry(
  entries: Array<{ name?: string; hash: Uint8Array; encryptionKey?: Uint8Array }>
): CalendarTreeEntry | null {
  const entry = entries.find(item => item.name === CALENDAR_TREE_NAME);
  if (!entry) return null;
  return {
    hash: entry.hash,
    encryptionKey: entry.encryptionKey,
  };
}
