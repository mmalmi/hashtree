import { sortEvents } from './model';
import type { CalendarEvent } from './types';

export interface TimedEventSegment {
  event: CalendarEvent;
  lane: number;
  laneCount: number;
}

function eventStartMs(event: CalendarEvent): number {
  return new Date(event.start).getTime();
}

function eventEndMs(event: CalendarEvent): number {
  return new Date(event.end).getTime();
}

function assignClusterLanes(cluster: CalendarEvent[]): TimedEventSegment[] {
  const laneEnds: number[] = [];
  const segments: TimedEventSegment[] = [];

  for (const event of cluster) {
    const start = eventStartMs(event);
    const end = eventEndMs(event);
    let lane = laneEnds.findIndex(laneEnd => laneEnd <= start);
    if (lane === -1) {
      lane = laneEnds.length;
      laneEnds.push(end);
    } else {
      laneEnds[lane] = end;
    }
    segments.push({ event, lane, laneCount: 1 });
  }

  const laneCount = Math.max(1, laneEnds.length);
  return segments.map(segment => ({ ...segment, laneCount }));
}

export function buildTimedEventSegments(events: readonly CalendarEvent[]): TimedEventSegment[] {
  const timedEvents = sortEvents(events.filter(event => !event.allDay));
  const segments: TimedEventSegment[] = [];
  let cluster: CalendarEvent[] = [];
  let clusterEnd = 0;

  for (const event of timedEvents) {
    const start = eventStartMs(event);
    const end = eventEndMs(event);
    if (cluster.length > 0 && start >= clusterEnd) {
      segments.push(...assignClusterLanes(cluster));
      cluster = [];
      clusterEnd = 0;
    }
    cluster.push(event);
    clusterEnd = Math.max(clusterEnd, end);
  }

  if (cluster.length > 0) {
    segments.push(...assignClusterLanes(cluster));
  }

  return segments;
}
