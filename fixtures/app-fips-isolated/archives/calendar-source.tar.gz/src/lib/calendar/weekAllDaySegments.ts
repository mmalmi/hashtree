import { eventsForDay } from './model';
import type { CalendarEvent } from './types';

interface WeekAllDayRange {
  event: CalendarEvent;
  startIndex: number;
  endIndex: number;
}

export interface WeekAllDaySegment extends WeekAllDayRange {
  lane: number;
}

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function nextLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
}

function rangeForDays(event: CalendarEvent, days: readonly Date[]): WeekAllDayRange | null {
  const eventStart = new Date(event.start).getTime();
  const eventEnd = new Date(event.end).getTime();
  let startIndex = -1;
  let endIndex = -1;

  for (let index = 0; index < days.length; index += 1) {
    const day = days[index];
    if (!day) continue;
    const dayStart = startOfLocalDay(day).getTime();
    const dayEnd = nextLocalDay(day).getTime();
    if (eventEnd <= dayStart || eventStart >= dayEnd) continue;
    if (startIndex === -1) startIndex = index;
    endIndex = index + 1;
  }

  return startIndex === -1 || endIndex === -1 ? null : { event, startIndex, endIndex };
}

export function buildWeekAllDaySegments(
  events: readonly CalendarEvent[],
  days: readonly Date[]
): WeekAllDaySegment[] {
  const visibleEvents: CalendarEvent[] = [];
  for (const day of days) {
    for (const event of eventsForDay(events, day)) {
      if (!event.allDay || visibleEvents.some(visibleEvent => visibleEvent.id === event.id)) continue;
      visibleEvents.push(event);
    }
  }

  const ranges = visibleEvents
    .map(event => rangeForDays(event, days))
    .filter((range): range is WeekAllDayRange => range !== null)
    .sort((a, b) => a.startIndex - b.startIndex || b.endIndex - a.endIndex || a.event.title.localeCompare(b.event.title));

  const laneEnds: number[] = [];
  return ranges.map((range) => {
    let lane = laneEnds.findIndex(endIndex => endIndex <= range.startIndex);
    if (lane === -1) {
      lane = laneEnds.length;
      laneEnds.push(range.endIndex);
    } else {
      laneEnds[lane] = range.endIndex;
    }
    return { ...range, lane };
  });
}
