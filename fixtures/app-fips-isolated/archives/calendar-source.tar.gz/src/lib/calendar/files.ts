import type { CalendarData, CalendarEvent, CalendarRecurrenceFrequency, CalendarRecurrenceRule } from './types';
import { parseDateInputValue, sortEvents, toDateInputValue, touchCalendar } from './model';
import { normalizeRecurrence } from './recurrence';

const MINUTE_MS = 60 * 1000;
const DEFAULT_DURATION_MS = 30 * MINUTE_MS;
const IMPORT_COLORS = ['blue', 'green', 'amber', 'rose', 'slate', 'violet'] as const;

interface ContentLine {
  name: string;
  params: Record<string, string>;
  value: string;
}

export interface CalendarImportResult {
  format: 'ics' | 'csv';
  events: CalendarEvent[];
  skipped: number;
}

export function parseCalendarFile(text: string, filename = '', now = Date.now()): CalendarImportResult {
  const csvLike = /\.csv$/i.test(filename) || (!/BEGIN:VCALENDAR/i.test(text) && text.trimStart().includes(','));
  return csvLike ? parseGoogleCsv(text, now) : parseIcsCalendar(text, now);
}

export function applyImportedCalendarEvents(
  data: CalendarData,
  importedEvents: readonly CalendarEvent[],
  actor: string,
  now = Date.now(),
): CalendarData {
  if (importedEvents.length === 0) return data;
  const existingById = new Map(data.events.map(event => [event.id, event]));
  const importedIds = new Set(importedEvents.map(event => event.id));
  const merged = importedEvents.map((event) => {
    const existing = existingById.get(event.id);
    return {
      ...event,
      color: existing?.color ?? event.color,
      createdAt: existing?.createdAt ?? event.createdAt,
      updatedAt: now,
    };
  });
  return touchCalendar({
    ...data,
    events: sortEvents([...data.events.filter(event => !importedIds.has(event.id)), ...merged]),
  }, actor, now);
}

export function serializeCalendarIcs(
  events: readonly CalendarEvent[],
  options: { calendarName?: string; now?: number } = {},
): string {
  const now = new Date(options.now ?? Date.now());
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Iris//Iris Calendar//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    propertyLine('X-WR-CALNAME', options.calendarName ?? 'Iris Calendar'),
  ];

  for (const event of sortEvents([...events])) {
    const start = new Date(event.start);
    const end = new Date(event.end);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) continue;
    lines.push(
      'BEGIN:VEVENT',
      propertyLine('UID', exportUid(event.id)),
      `DTSTAMP:${formatIcsUtc(now)}`,
      `CREATED:${formatIcsUtc(new Date(event.createdAt || now.getTime()))}`,
      `LAST-MODIFIED:${formatIcsUtc(new Date(event.updatedAt || now.getTime()))}`,
      propertyLine('SUMMARY', event.title),
    );
    if (event.allDay) {
      lines.push(`DTSTART;VALUE=DATE:${formatIcsLocalDate(start)}`);
      lines.push(`DTEND;VALUE=DATE:${formatIcsLocalDate(end)}`);
    } else {
      lines.push(`DTSTART:${formatIcsUtc(start)}`);
      lines.push(`DTEND:${formatIcsUtc(end)}`);
    }
    if (event.location) lines.push(propertyLine('LOCATION', event.location));
    if (event.notes) lines.push(propertyLine('DESCRIPTION', event.notes));
    const rrule = serializeRRule(event.recurrence);
    if (rrule) lines.push(rrule);
    lines.push('END:VEVENT');
  }

  lines.push('END:VCALENDAR');
  return `${lines.map(foldIcsLine).join('\r\n')}\r\n`;
}

function parseIcsCalendar(text: string, now: number): CalendarImportResult {
  const lines = unfoldedContentLines(text).map(parseContentLine).filter((line): line is ContentLine => !!line);
  const eventGroups: ContentLine[][] = [];
  let current: ContentLine[] | null = null;
  let nestedDepth = 0;

  for (const line of lines) {
    if (line.name === 'BEGIN' && line.value.toUpperCase() === 'VEVENT') {
      current = [];
      nestedDepth = 0;
      continue;
    }
    if (!current) continue;
    if (line.name === 'END' && line.value.toUpperCase() === 'VEVENT' && nestedDepth === 0) {
      eventGroups.push(current);
      current = null;
      continue;
    }
    if (line.name === 'BEGIN') {
      nestedDepth += 1;
      continue;
    }
    if (line.name === 'END') {
      nestedDepth = Math.max(0, nestedDepth - 1);
      continue;
    }
    if (nestedDepth === 0) current.push(line);
  }

  const events = eventGroups
    .map((group, index) => eventFromIcsLines(group, index, now))
    .filter((event): event is CalendarEvent => !!event);
  return { format: 'ics', events, skipped: eventGroups.length - events.length };
}

function eventFromIcsLines(lines: ContentLine[], index: number, now: number): CalendarEvent | null {
  if (valueFor(lines, 'STATUS')?.toUpperCase() === 'CANCELLED') return null;
  const startLine = lineFor(lines, 'DTSTART');
  if (!startLine) return null;
  const allDay = startLine.params.VALUE?.toUpperCase() === 'DATE' || /^\d{8}$/.test(startLine.value.trim());
  const start = parseIcsDate(startLine.value, allDay);
  if (!start) return null;
  const endLine = lineFor(lines, 'DTEND');
  const durationMs = parseIcsDuration(valueFor(lines, 'DURATION'));
  const parsedEnd = endLine ? parseIcsDate(endLine.value, allDay) : null;
  const end = parsedEnd ?? new Date(start.getTime() + (durationMs ?? (allDay ? 24 * 60 * MINUTE_MS : DEFAULT_DURATION_MS)));
  if (end <= start) return null;

  const uid = valueFor(lines, 'UID') ?? `${valueFor(lines, 'SUMMARY') ?? 'event'}:${start.toISOString()}:${index}`;
  const recurrence = parseIcsRRule(valueFor(lines, 'RRULE'), start);
  return {
    id: stableImportId(uid),
    title: unescapeIcsText(valueFor(lines, 'SUMMARY') ?? 'Untitled event'),
    start: start.toISOString(),
    end: end.toISOString(),
    allDay,
    color: IMPORT_COLORS[index % IMPORT_COLORS.length],
    location: optionalText(valueFor(lines, 'LOCATION')),
    notes: optionalText(valueFor(lines, 'DESCRIPTION')),
    recurrence,
    createdAt: parseIcsDate(valueFor(lines, 'CREATED') ?? '', false)?.getTime() ?? now,
    updatedAt: parseIcsDate(valueFor(lines, 'LAST-MODIFIED') ?? '', false)?.getTime() ?? now,
  };
}

function parseGoogleCsv(text: string, now: number): CalendarImportResult {
  const [header = [], ...rows] = parseCsv(text);
  const keys = header.map(headerKey);
  const events = rows
    .map((row, index) => eventFromCsvRow(keys, row, index, now))
    .filter((event): event is CalendarEvent => !!event);
  return { format: 'csv', events, skipped: rows.length - events.length };
}

function eventFromCsvRow(keys: string[], row: string[], index: number, now: number): CalendarEvent | null {
  const value = (name: string) => row[keys.indexOf(name)]?.trim() ?? '';
  const title = value('subject') || value('title') || value('summary') || 'Untitled event';
  const startDate = parseCsvDate(value('startdate') || value('date'));
  if (!startDate) return null;
  const startTime = parseCsvTime(value('starttime'));
  const endDate = parseCsvDate(value('enddate')) ?? startDate;
  const endTime = parseCsvTime(value('endtime'));
  const allDay = truthy(value('alldayevent')) || !startTime;
  const start = allDay ? startOfLocalDay(startDate) : setTime(startDate, startTime);
  const end = allDay
    ? addLocalDays(startOfLocalDay(endDate >= startDate ? endDate : startDate), 1)
    : safeTimedEnd(start, setTime(endDate, endTime ?? addMinutes(startTime, 30)));
  const uid = value('uid') || `csv:${title}:${start.toISOString()}:${index}`;
  return {
    id: stableImportId(uid),
    title,
    start: start.toISOString(),
    end: end.toISOString(),
    allDay,
    color: IMPORT_COLORS[index % IMPORT_COLORS.length],
    location: optionalText(value('location')),
    notes: optionalText(value('description')),
    createdAt: now,
    updatedAt: now,
  };
}

function unfoldedContentLines(text: string): string[] {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const unfolded: string[] = [];
  for (const line of lines) {
    if (/^[ \t]/.test(line) && unfolded.length > 0) {
      unfolded[unfolded.length - 1] += line.slice(1);
    } else if (line.trim()) {
      unfolded.push(line);
    }
  }
  return unfolded;
}

function parseContentLine(line: string): ContentLine | null {
  const colonIndex = line.indexOf(':');
  if (colonIndex <= 0) return null;
  const [namePart, ...paramParts] = line.slice(0, colonIndex).split(';');
  const params: Record<string, string> = {};
  for (const part of paramParts) {
    const [key, ...rest] = part.split('=');
    if (!key || rest.length === 0) continue;
    params[key.toUpperCase()] = rest.join('=').replace(/^"|"$/g, '');
  }
  return { name: namePart!.toUpperCase(), params, value: line.slice(colonIndex + 1) };
}

function lineFor(lines: ContentLine[], name: string): ContentLine | undefined {
  return lines.find(line => line.name === name);
}

function valueFor(lines: ContentLine[], name: string): string | undefined {
  return lineFor(lines, name)?.value;
}

function parseIcsDate(value: string, allDay: boolean): Date | null {
  const raw = value.trim();
  const dateOnly = /^(\d{4})(\d{2})(\d{2})$/.exec(raw);
  if (dateOnly) return new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]));
  const isoDate = allDay ? parseDateInputValue(raw) : null;
  if (isoDate) return isoDate;
  const dateTime = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})?(Z?)$/.exec(raw);
  if (!dateTime) return null;
  const [, year, month, day, hour, minute, second = '00', zulu = ''] = dateTime;
  if (zulu) {
    return new Date(Date.UTC(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second)));
  }
  return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
}

function parseIcsRRule(value: string | undefined, start: Date): CalendarRecurrenceRule | undefined {
  if (!value) return undefined;
  const parts = Object.fromEntries(value.split(';').map((part) => {
    const [key, ...rest] = part.split('=');
    return [key?.toUpperCase() ?? '', rest.join('=').toUpperCase()];
  }));
  const frequency = frequencyFromIcs(parts.FREQ);
  if (!frequency) return undefined;
  const interval = Number(parts.INTERVAL) || 1;
  const count = Math.max(0, Number(parts.COUNT) || 0);
  const untilDate = parts.UNTIL ? parseIcsDate(parts.UNTIL, /^\d{8}$/.test(parts.UNTIL)) : null;
  const until = untilDate
    ? toDateInputValue(untilDate)
    : count > 1 ? toDateInputValue(occurrenceDate(start, frequency, interval, count - 1)) : undefined;
  return normalizeRecurrence({ frequency, interval, until }, start);
}

function serializeRRule(rule: CalendarRecurrenceRule | undefined): string | null {
  const recurrence = normalizeRecurrence(rule);
  if (!recurrence) return null;
  const parts = [`FREQ=${recurrence.frequency.toUpperCase()}`];
  if (recurrence.interval > 1) parts.push(`INTERVAL=${recurrence.interval}`);
  if (recurrence.until) {
    const until = parseDateInputValue(recurrence.until);
    if (until) parts.push(`UNTIL=${formatIcsLocalDate(until)}`);
  }
  return `RRULE:${parts.join(';')}`;
}

function frequencyFromIcs(value: string | undefined): CalendarRecurrenceFrequency | undefined {
  if (value === 'DAILY') return 'daily';
  if (value === 'WEEKLY') return 'weekly';
  if (value === 'MONTHLY') return 'monthly';
  if (value === 'YEARLY') return 'yearly';
  return undefined;
}

function occurrenceDate(start: Date, frequency: CalendarRecurrenceFrequency, interval: number, index: number): Date {
  if (frequency === 'daily') return addLocalDays(start, index * interval);
  if (frequency === 'weekly') return addLocalDays(start, index * interval * 7);
  if (frequency === 'monthly') return addLocalMonths(start, index * interval);
  return addLocalMonths(start, index * interval * 12);
}

function parseIcsDuration(value: string | undefined): number | null {
  const match = /^P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/i.exec(value ?? '');
  if (!match) return null;
  const [, weeks = '0', days = '0', hours = '0', minutes = '0', seconds = '0'] = match;
  return (((Number(weeks) * 7 + Number(days)) * 24 + Number(hours)) * 60 + Number(minutes)) * MINUTE_MS
    + Number(seconds) * 1000;
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let value = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (quoted && char === '"' && next === '"') {
      value += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (!quoted && char === ',') {
      row.push(value);
      value = '';
    } else if (!quoted && (char === '\n' || char === '\r')) {
      if (char === '\r' && next === '\n') index += 1;
      row.push(value);
      if (row.some(cell => cell.trim())) rows.push(row);
      row = [];
      value = '';
    } else {
      value += char;
    }
  }
  row.push(value);
  if (row.some(cell => cell.trim())) rows.push(row);
  return rows;
}

function parseCsvDate(value: string): Date | null {
  const iso = parseDateInputValue(value);
  if (iso) return iso;
  const dotted = /^(\d{1,2})[.](\d{1,2})[.](\d{4})$/.exec(value);
  if (dotted) return validDate(Number(dotted[3]), Number(dotted[2]), Number(dotted[1]));
  const slashed = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value);
  if (!slashed) return null;
  const first = Number(slashed[1]);
  const second = Number(slashed[2]);
  return first > 12 ? validDate(Number(slashed[3]), second, first) : validDate(Number(slashed[3]), first, second);
}

function parseCsvTime(value: string): { hours: number; minutes: number } | null {
  const match = /^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?$/i.exec(value.trim());
  if (!match) return null;
  let hours = Number(match[1]);
  const minutes = Number(match[2] ?? '0');
  const meridiem = match[3]?.toUpperCase();
  if (meridiem === 'PM' && hours < 12) hours += 12;
  if (meridiem === 'AM' && hours === 12) hours = 0;
  return hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59 ? { hours, minutes } : null;
}

function validDate(year: number, month: number, day: number): Date | null {
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day ? date : null;
}

function setTime(date: Date, time: { hours: number; minutes: number }): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), time.hours, time.minutes, 0, 0);
}

function safeTimedEnd(start: Date, end: Date): Date {
  return end > start ? end : new Date(start.getTime() + DEFAULT_DURATION_MS);
}

function addMinutes(time: { hours: number; minutes: number }, count: number): { hours: number; minutes: number } {
  const date = new Date(2026, 0, 1, time.hours, time.minutes + count);
  return { hours: date.getHours(), minutes: date.getMinutes() };
}

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function addLocalDays(date: Date, count: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + count, date.getHours(), date.getMinutes());
}

function addLocalMonths(date: Date, count: number): Date {
  const target = new Date(date.getFullYear(), date.getMonth() + count, 1);
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return new Date(target.getFullYear(), target.getMonth(), Math.min(date.getDate(), lastDay), date.getHours(), date.getMinutes());
}

function stableImportId(value: string): string {
  const slug = value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 72);
  return `ics-${slug || hashString(value)}`;
}

function hashString(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function exportUid(id: string): string {
  return id.includes('@') ? id : `${id}@calendar.iris.to`;
}

function optionalText(value: string | undefined): string | undefined {
  const text = value ? unescapeIcsText(value).trim() : '';
  return text || undefined;
}

function unescapeIcsText(value: string): string {
  return value.replace(/\\[nN]/g, '\n').replace(/\\([\\;,])/g, '$1');
}

function propertyLine(name: string, value: string): string {
  return `${name}:${escapeIcsText(value)}`;
}

function escapeIcsText(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,');
}

function foldIcsLine(line: string): string {
  const chunks: string[] = [];
  for (let index = 0; index < line.length; index += 74) chunks.push(line.slice(index, index + 74));
  return chunks.join('\r\n ');
}

function formatIcsUtc(date: Date): string {
  return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}

function formatIcsLocalDate(date: Date): string {
  return toDateInputValue(date).replace(/-/g, '');
}

function headerKey(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function truthy(value: string): boolean {
  return ['1', 'true', 'yes', 'y'].includes(value.toLowerCase());
}
