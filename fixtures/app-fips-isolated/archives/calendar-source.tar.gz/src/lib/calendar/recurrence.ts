import type { CalendarEvent, CalendarRecurrenceFrequency, CalendarRecurrenceRule } from './types';

const DAY_MS = 24 * 60 * 60 * 1000;
const MAX_OCCURRENCES_PER_RANGE = 1500;
const RECURRENCE_FREQUENCIES: readonly CalendarRecurrenceFrequency[] = ['daily', 'weekly', 'monthly', 'yearly'];

export function normalizeRecurrence(raw: unknown, eventStart?: Date): CalendarRecurrenceRule | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const record = raw as Record<string, unknown>;
  if (!RECURRENCE_FREQUENCIES.includes(record.frequency as CalendarRecurrenceFrequency)) return undefined;

  const interval = normalizeInterval(record.interval);
  const until = normalizeUntil(record.until, eventStart);
  return {
    frequency: record.frequency as CalendarRecurrenceFrequency,
    interval,
    ...(until ? { until } : {}),
  };
}

export function expandRecurringEvents(
  events: readonly CalendarEvent[],
  rangeStart: Date,
  rangeEnd: Date,
): CalendarEvent[] {
  const startMs = rangeStart.getTime();
  const endMs = rangeEnd.getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) return [];

  const expanded: CalendarEvent[] = [];
  for (const event of events) {
    const recurrence = normalizeRecurrence(event.recurrence, new Date(event.start));
    if (!recurrence) {
      if (overlapsEvent(event, startMs, endMs)) expanded.push(event);
      continue;
    }
    expanded.push(...expandEvent(event, recurrence, rangeStart, rangeEnd));
  }
  return expanded;
}

function expandEvent(
  event: CalendarEvent,
  recurrence: CalendarRecurrenceRule,
  rangeStart: Date,
  rangeEnd: Date,
): CalendarEvent[] {
  const seedStart = new Date(event.start);
  const seedEnd = new Date(event.end);
  if (Number.isNaN(seedStart.getTime()) || Number.isNaN(seedEnd.getTime()) || seedEnd <= seedStart) return [];

  const rangeStartMs = rangeStart.getTime();
  const rangeEndMs = rangeEnd.getTime();
  const durationMs = seedEnd.getTime() - seedStart.getTime();
  const allDaySpan = event.allDay ? Math.max(1, localDayNumber(seedEnd) - localDayNumber(seedStart)) : 1;
  const untilEndMs = recurrence.until ? endOfLocalDay(parseDateInput(recurrence.until) ?? new Date(recurrence.until)).getTime() : Infinity;
  const occurrences: CalendarEvent[] = [];
  let index = firstOccurrenceIndex(seedStart, rangeStart, recurrence);

  for (let count = 0; count < MAX_OCCURRENCES_PER_RANGE; count += 1, index += 1) {
    const occurrenceStart = occurrenceStartAt(seedStart, recurrence, index);
    const occurrenceStartMs = occurrenceStart.getTime();
    if (occurrenceStartMs >= rangeEndMs || occurrenceStartMs > untilEndMs) break;

    const occurrenceEnd = event.allDay
      ? addLocalDays(startOfLocalDay(occurrenceStart), allDaySpan)
      : new Date(occurrenceStartMs + durationMs);
    if (occurrenceStartMs < rangeEndMs && occurrenceEnd.getTime() > rangeStartMs) {
      occurrences.push({
        ...event,
        id: `${event.id}::${occurrenceStart.toISOString()}`,
        start: occurrenceStart.toISOString(),
        end: occurrenceEnd.toISOString(),
        recurrenceSourceId: event.id,
      });
    }
  }
  return occurrences;
}

function normalizeInterval(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 1;
  return Math.min(99, Math.max(1, Math.round(value)));
}

function normalizeUntil(value: unknown, eventStart?: Date): string | undefined {
  if (typeof value !== 'string' || !value.trim()) return undefined;
  const date = parseDateInput(value.trim()) ?? new Date(value);
  if (Number.isNaN(date.getTime())) return undefined;
  if (eventStart && endOfLocalDay(date) < startOfLocalDay(eventStart)) return undefined;
  return toDateInputValue(date);
}

function overlapsEvent(event: CalendarEvent, rangeStartMs: number, rangeEndMs: number): boolean {
  const eventStart = new Date(event.start).getTime();
  const eventEnd = new Date(event.end).getTime();
  return eventStart < rangeEndMs && eventEnd > rangeStartMs;
}

function firstOccurrenceIndex(seedStart: Date, rangeStart: Date, recurrence: CalendarRecurrenceRule): number {
  if (rangeStart <= seedStart) return 0;
  if (recurrence.frequency === 'daily') {
    return Math.max(0, Math.floor((localDayNumber(rangeStart) - localDayNumber(seedStart)) / recurrence.interval) - 1);
  }
  if (recurrence.frequency === 'weekly') {
    return Math.max(0, Math.floor((localDayNumber(rangeStart) - localDayNumber(seedStart)) / (recurrence.interval * 7)) - 1);
  }
  if (recurrence.frequency === 'monthly') {
    return Math.max(0, Math.floor(monthDifference(seedStart, rangeStart) / recurrence.interval) - 1);
  }
  return Math.max(0, Math.floor((rangeStart.getFullYear() - seedStart.getFullYear()) / recurrence.interval) - 1);
}

function occurrenceStartAt(seedStart: Date, recurrence: CalendarRecurrenceRule, index: number): Date {
  if (recurrence.frequency === 'daily') return addLocalDays(seedStart, index * recurrence.interval);
  if (recurrence.frequency === 'weekly') return addLocalDays(seedStart, index * recurrence.interval * 7);
  if (recurrence.frequency === 'monthly') return addLocalMonths(seedStart, index * recurrence.interval);
  return addLocalMonths(seedStart, index * recurrence.interval * 12);
}

function addLocalDays(date: Date, days: number): Date {
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate() + days,
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
    date.getMilliseconds(),
  );
}

function addLocalMonths(date: Date, months: number): Date {
  const target = new Date(date.getFullYear(), date.getMonth() + months, 1);
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return new Date(
    target.getFullYear(),
    target.getMonth(),
    Math.min(date.getDate(), lastDay),
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
    date.getMilliseconds(),
  );
}

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function endOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59, 999);
}

function localDayNumber(date: Date): number {
  return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / DAY_MS;
}

function monthDifference(start: Date, end: Date): number {
  return (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();
}

function parseDateInput(value: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day ? date : null;
}

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}
