export const CALENDAR_DATA_VERSION = 1;
export const CALENDAR_TREE_NAME = 'calendar';
export const CALENDAR_TREE_LABEL = 'calendar';
export const CALENDAR_DATA_FILE = 'calendar.json';

export type CalendarView = 'day' | 'week' | 'month' | 'year' | 'agenda';
export type CalendarColor = 'violet' | 'green' | 'blue' | 'amber' | 'rose' | 'slate';
export type CalendarWeekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export type CalendarTimeFormat = 'auto' | '12h' | '24h';
export type CalendarRecurrenceFrequency = 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface CalendarRecurrenceRule {
  frequency: CalendarRecurrenceFrequency;
  interval: number;
  until?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  color: CalendarColor;
  location?: string;
  notes?: string;
  recurrence?: CalendarRecurrenceRule;
  recurrenceSourceId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface AvailabilityRule {
  id: string;
  weekday: CalendarWeekday;
  enabled: boolean;
  startTime: string;
  endTime: string;
}

export interface AvailabilitySettings {
  timezone: string;
  slotDurationMinutes: number;
  bufferBeforeMinutes: number;
  bufferAfterMinutes: number;
  minimumNoticeMinutes: number;
  rules: AvailabilityRule[];
}

export interface BookingLink {
  id: string;
  slug: string;
  title: string;
  durationMinutes: number;
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CalendarData {
  version: typeof CALENDAR_DATA_VERSION;
  calendarId: string;
  title: string;
  ownerNpub: string;
  timezone: string;
  timeFormat: CalendarTimeFormat;
  startOfWeek: 'monday' | 'sunday';
  events: CalendarEvent[];
  availability: AvailabilitySettings;
  bookingLinks: BookingLink[];
  updatedAt: number;
  updatedBy: string;
}

export interface EventDraft {
  id?: string;
  title: string;
  start: string;
  end: string;
  allDay?: boolean;
  color?: CalendarColor;
  location?: string;
  notes?: string;
  recurrence?: CalendarRecurrenceRule;
}

export interface BookingSlot {
  start: string;
  end: string;
}
