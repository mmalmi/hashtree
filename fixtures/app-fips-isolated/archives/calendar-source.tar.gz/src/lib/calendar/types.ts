export const CALENDAR_DATA_VERSION = 1;
export const CALENDAR_TREE_NAME = 'calendar';
export const CALENDAR_TREE_LABEL = 'calendar';
export const CALENDAR_DATA_FILE = 'calendar.json';

export type CalendarView = 'day' | 'week' | 'month' | 'year' | 'agenda';
export type CalendarColor = 'violet' | 'green' | 'blue' | 'amber' | 'rose' | 'slate';
export type CalendarWeekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export type CalendarTimeFormat = 'auto' | '12h' | '24h';
export type CalendarRecurrenceFrequency = 'daily' | 'weekly' | 'monthly' | 'yearly';
export type RsvpStatus = 'needs-action' | 'accepted' | 'tentative' | 'declined';

export interface CalendarGuest {
  npub: string;
  status: RsvpStatus;
  /** When the guest answered, so older answers cannot replace newer ones. */
  at?: number;
  /** The name a guest gave when answering through an invite link. */
  name?: string;
}

export interface CalendarRecurrenceRule {
  frequency: CalendarRecurrenceFrequency;
  interval: number;
  until?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  color: CalendarColor;
  location?: string;
  notes?: string;
  recurrence?: CalendarRecurrenceRule;
  recurrenceSourceId?: string;
  /** Who invited me; unset for my own events. */
  organizer?: string;
  guests?: CalendarGuest[];
  /** My answer to an invite. */
  rsvp?: RsvpStatus;
  cancelled?: boolean;
  /** Secret of the invite link; its key pair is the inbox that link holders read. */
  inviteKey?: string;
  /** Owner of the shared calendar this event was read from. Never saved. */
  calendar?: string;
  createdAt: number;
  updatedAt: number;
}

/** A calendar someone shared with me. */
export interface SharedCalendar {
  npub: string;
  title: string;
  key: string;
  color: CalendarColor;
  hidden?: boolean;
  updatedAt: number;
}

export interface AvailabilityRule {
  id: string;
  weekday: CalendarWeekday;
  enabled: boolean;
  startTime: string;
  endTime: string;
}

export interface AvailabilitySettings {
  timezone: string;
  slotDurationMinutes: number;
  bufferBeforeMinutes: number;
  bufferAfterMinutes: number;
  minimumNoticeMinutes: number;
  rules: AvailabilityRule[];
}

export interface BookingLink {
  id: string;
  slug: string;
  title: string;
  durationMinutes: number;
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CalendarData {
  version: typeof CALENDAR_DATA_VERSION;
  calendarId: string;
  title: string;
  ownerNpub: string;
  timezone: string;
  timeFormat: CalendarTimeFormat;
  startOfWeek: 'monday' | 'sunday';
  events: CalendarEvent[];
  availability: AvailabilitySettings;
  bookingLinks: BookingLink[];
  /** Link secret of the shared copy, and the people it was sent to. */
  shareKey?: string;
  sharedWith: string[];
  /** Link secret of the free/busy copy that booking pages read. */
  bookingKey?: string;
  subscriptions: SharedCalendar[];
  /** Last withdrawal from each owner, so replaying an old share cannot restore it. */
  shareWithdrawals?: Record<string, number>;
  updatedAt: number;
  updatedBy: string;
}

export interface EventDraft {
  id?: string;
  title: string;
  start: string;
  end: string;
  allDay?: boolean;
  color?: CalendarColor;
  location?: string;
  notes?: string;
  recurrence?: CalendarRecurrenceRule;
  guests?: CalendarGuest[];
  inviteKey?: string;
}

export interface BookingSlot {
  start: string;
  end: string;
}
