import { untrack } from 'svelte';
import { toHex, type CID } from '@hashtree/core';
import { HASHTREE_ROOT_KINDS } from '@hashtree/nostr';
import { nostr } from '../../nostr/client';
import { createTreesStore, type TreeEntry } from '../../stores/trees';
import { CALENDAR_TREE_NAME, type CalendarData, type CalendarEvent } from './types';
import { isShownEvent, sortEvents } from './model';
import { applyCalendarMessage, type OutgoingMessage } from './messages';
import { BOOKING_TREE_NAME, SHARED_TREE_NAME, bookingCalendarView, sharedCalendarView } from './sharing';
import { createCalendarTree, loadCalendarData, publishCalendarView, saveCalendarData, watchCalendarView } from './storage';
import { sendCalendarMessages, subscribeCalendarMessages, type ReceivedMessage } from './inbox';

export type CalendarPhase = 'finding' | 'missing' | 'loading' | 'ready';

/** One account's calendar: loading and saving it, its messages, and calendars shared with it. */
export class CalendarSession {
  data = $state<CalendarData | null>(null);
  shared = $state<Record<string, CalendarData | null>>({});
  phase = $state<CalendarPhase>('finding');
  saving = $state(false);
  error = $state('');
  status = $state('');

  /** My events plus visible shared calendars, as the views draw them. */
  events = $derived.by(() => {
    if (!this.data) return [];
    const own = this.data.events.filter(isShownEvent);
    const ids = new Set(own.map(event => event.id));
    const others = this.data.subscriptions.filter(item => !item.hidden).flatMap(item =>
      (this.shared[item.npub]?.events ?? [])
        .filter(event => isShownEvent(event) && !ids.has(event.id))
        .map((event): CalendarEvent => ({ ...event, id: `${item.npub}/${event.id}`, color: item.color, calendar: item.npub })));
    return others.length ? sortEvents([...own, ...others]) : own;
  });

  #entries: TreeEntry[] = [];
  #root?: CID;
  #rootHex = '';
  #revision = 0;
  #pending: { data: CalendarData; message: string } | null = null;
  #synced = $state(false);
  #inbox: ReceivedMessage[] = [];
  #views = Promise.resolve();
  #statusTimer?: ReturnType<typeof setTimeout>;
  #stopped = false;
  #ready = $derived(this.data !== null && this.#synced);
  #sharedKeys = $derived(this.data?.subscriptions.filter(item => !item.hidden).map(item => `${item.npub}:${item.key}`).join(',') ?? '');

  constructor(readonly npub: string, readonly pubkey: string) {}

  start(): () => void {
    this.#stopped = false;
    const stops = [
      createTreesStore(this.npub).subscribe(entries => this.#onEntries(entries)),
      $effect.root(() => {
        $effect(() => this.#watchShared(this.#sharedKeys));
        $effect(() => {
          if (!this.#ready) return;
          return untrack(() => subscribeCalendarMessages(this.pubkey, (received) => {
            this.#inbox.push(received);
            queueMicrotask(() => this.#applyInbox());
          }));
        });
      }),
    ];
    void this.#findOrCreate();
    return () => {
      this.#stopped = true;
      stops.forEach(stop => stop());
      clearTimeout(this.#statusTimer);
    };
  }

  /** Shows `next` at once and saves it; edits made while a save runs collapse into one save. */
  persist(next: CalendarData, message = 'Saved', outgoing: OutgoingMessage[] = []) {
    this.#revision += 1;
    this.data = next;
    sendCalendarMessages(this.pubkey, outgoing);
    this.#pending = { data: next, message };
    this.setStatus('Saving');
    if (!this.saving) void this.#store();
  }

  send(outgoing: OutgoingMessage[]) {
    sendCalendarMessages(this.pubkey, outgoing);
  }

  retry() {
    this.error = '';
    if (this.#entries.length) {
      this.#rootHex = '';
      this.#onEntries(this.#entries);
    } else {
      void this.create();
    }
  }

  async create() {
    if (this.#stopped || this.data || this.phase === 'loading') return;
    this.phase = 'loading';
    try {
      const { data, root } = await createCalendarTree(this.npub);
      if (this.data) return;
      this.#root = root;
      this.#rootHex = toHex(root.hash);
      this.data = data;
      this.phase = 'ready';
    } catch (error) {
      console.error('[Calendar] create failed', error);
      this.error = 'Could not create your calendar.';
      this.phase = 'missing';
    }
  }

  setStatus(message: string, clearAfterMs = 0) {
    clearTimeout(this.#statusTimer);
    this.status = message;
    if (message && clearAfterMs) this.#statusTimer = setTimeout(() => this.status = '', clearAfterMs);
  }

  #onEntries(entries: TreeEntry[]) {
    this.#entries = entries;
    const entry = entries.find(item => item.name === CALENDAR_TREE_NAME);
    if (!entry || entry.hashHex === this.#rootHex || this.saving) return;
    const revision = this.#revision;
    const hash = this.#rootHex = entry.hashHex;
    if (!this.data) this.phase = 'loading';
    loadCalendarData(entry, this.npub).then(({ data, root }) => {
      if (revision !== this.#revision || hash !== this.#rootHex) return;
      this.#root = root;
      this.data = data;
      this.phase = 'ready';
      this.error = '';
    }, (error) => {
      if (hash !== this.#rootHex) return;
      console.error('[Calendar] load failed', error);
      this.error = 'Could not open your calendar.';
    });
  }

  /** A new calendar is made only once a relay confirms there is none to load. */
  async #findOrCreate() {
    const filter = { kinds: [...HASHTREE_ROOT_KINDS], authors: [this.pubkey], '#d': [CALENDAR_TREE_NAME] };
    const found = await new Promise<number>((resolve) => {
      let count = 0;
      const subscription = nostr.subscribe(filter, { closeAfterHistory: true });
      const timer = setTimeout(() => {
        subscription.stop();
        resolve(count || -1);
      }, 15_000);
      subscription.on('event', () => count++);
      subscription.on('history', (status) => {
        clearTimeout(timer);
        const sources = (status as { sources?: Array<{ id?: string; complete?: boolean }> }).sources ?? [];
        resolve(count || (status.complete || sources.some(source => source.complete && source.id?.startsWith('ws')) ? 0 : -1));
      });
    });
    this.#synced = true;
    if (found === 0) return this.create();
    if (found > 0) await new Promise(resolve => setTimeout(resolve, 5000));
    if (!this.data && this.phase === 'finding') this.phase = 'missing';
  }

  async #store() {
    this.saving = true;
    let message = '';
    while (this.#pending) {
      const { data, message: next } = this.#pending;
      this.#pending = null;
      message = next;
      try {
        if (!this.#root) throw new Error('Calendar root unavailable');
        this.#root = await saveCalendarData(data, this.#root);
        this.#rootHex = toHex(this.#root.hash);
        this.error = '';
        this.#publishViews(data);
      } catch (error) {
        if (this.#pending) continue;
        console.error('[Calendar] save failed', error);
        this.error = 'Could not save your calendar.';
      }
    }
    this.saving = false;
    this.setStatus(this.error ? '' : message, 2600);
  }

  #publishViews(data: CalendarData) {
    const views: Array<[string, CalendarData, string | undefined]> = [
      [SHARED_TREE_NAME, sharedCalendarView(data), data.sharedWith.length ? data.shareKey : undefined],
      [BOOKING_TREE_NAME, bookingCalendarView(data), data.bookingLinks.some(link => link.enabled) ? data.bookingKey : undefined],
    ];
    for (const [name, view, key] of views) {
      if (!key) continue;
      this.#views = this.#views
        .then(() => publishCalendarView(name, view, key))
        .catch(error => console.warn(`[Calendar] could not publish ${name}`, error));
    }
  }

  #applyInbox() {
    if (!this.data || this.#inbox.length === 0) return;
    let next = this.data;
    const replies: OutgoingMessage[] = [];
    for (const { from, message, sentAt } of this.#inbox.splice(0)) {
      const result = applyCalendarMessage(next, from, message, sentAt);
      next = result.data;
      replies.push(...result.replies);
    }
    if (next !== this.data) this.persist(next, 'Updated', replies);
  }

  #watchShared(keys: string) {
    if (!keys) return;
    const stops = keys.split(',').map((item) => {
      const [npub, key] = item.split(':');
      return watchCalendarView(npub!, key!, (data) => {
        this.shared = { ...this.shared, [npub!]: data };
      });
    });
    return () => stops.forEach(stop => stop());
  }
}
