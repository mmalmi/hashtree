import type { CalendarView } from './types';

const routeViews = new Set<CalendarView>(['day', 'week', 'month', 'year', 'agenda']);

export interface CalendarViewRoute {
  view: CalendarView;
  date: Date;
}

function routeDate(date: Date): { year: number; month: number; day: number } {
  return {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: date.getDate(),
  };
}

function parsePositiveInteger(value: string | undefined): number | null {
  if (!value || !/^\d+$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

function parseRouteDate(yearValue: string | undefined, monthValue: string | undefined, dayValue: string | undefined): Date | null {
  const year = parsePositiveInteger(yearValue);
  const month = parsePositiveInteger(monthValue);
  const day = parsePositiveInteger(dayValue);
  if (!year || !month || !day || month > 12 || day > 31) return null;

  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day
    ? date
    : null;
}

export function formatCalendarRoute(view: CalendarView, date: Date): string {
  const { year, month, day } = routeDate(date);
  if (view === 'year') return `/year/${year}`;
  return `/${view}/${year}/${month}/${day}`;
}

export function parseCalendarViewRoute(path: string): CalendarViewRoute | null {
  const [cleanPath] = path.split(/[?#]/);
  const [, viewValue, yearValue, monthValue, dayValue] = (cleanPath || '/').split('/');
  if (!routeViews.has(viewValue as CalendarView)) return null;

  const view = viewValue as CalendarView;
  if (view === 'year' && yearValue && !monthValue && !dayValue) {
    const year = parsePositiveInteger(yearValue);
    return year ? { view, date: new Date(year, 0, 1) } : null;
  }

  const date = parseRouteDate(yearValue, monthValue, dayValue);
  return date ? { view, date } : null;
}
