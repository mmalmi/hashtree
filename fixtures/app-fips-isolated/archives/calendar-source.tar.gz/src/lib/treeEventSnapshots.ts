import { nip19 } from 'nostr-tools';
import {
  toHex,
  type CID,
} from '@hashtree/core';
import {
  compareTreeEventSnapshots as compareStoredTreeEventSnapshots,
  readTreeEventSnapshot as readStoredTreeEventSnapshot,
  resolveSnapshotRootCid,
  storeTreeEventSnapshot,
  type StoredNostrEvent,
  type TreeEventSnapshotInfo,
} from '@hashtree/nostr';
import { getTree } from '../store';

const snapshotsByTreeKey = new Map<string, TreeEventSnapshotInfo>();
const snapshotsByEventId = new Map<string, TreeEventSnapshotInfo>();
const snapshotsBySnapshotHash = new Map<string, TreeEventSnapshotInfo>();
const inFlightSnapshotReads = new Map<string, Promise<TreeEventSnapshotInfo | null>>();

export type { TreeEventSnapshotInfo };
export { resolveSnapshotRootCid };

function getSnapshotHashKey(snapshotCid: CID): string {
  return toHex(snapshotCid.hash);
}

function getTreeKey(npub: string, treeName: string): string {
  return `${npub}/${treeName}`;
}

function registerSnapshot(
  snapshot: TreeEventSnapshotInfo,
  options: { updateTreeKey?: boolean } = {},
): TreeEventSnapshotInfo {
  snapshotsByEventId.set(snapshot.event.id, snapshot);
  snapshotsBySnapshotHash.set(getSnapshotHashKey(snapshot.snapshotCid), snapshot);

  if (options.updateTreeKey !== false) {
    const treeKey = getTreeKey(snapshot.npub, snapshot.treeName);
    const existing = snapshotsByTreeKey.get(treeKey);
    if (!existing || compareStoredTreeEventSnapshots(existing, snapshot) <= 0) {
      snapshotsByTreeKey.set(treeKey, snapshot);
    }
  }

  return snapshot;
}

export async function cacheTreeEventSnapshot(event: StoredNostrEvent): Promise<TreeEventSnapshotInfo | null> {
  const existing = snapshotsByEventId.get(event.id);
  if (existing) {
    return registerSnapshot(existing, { updateTreeKey: true });
  }

  const snapshot = await storeTreeEventSnapshot(getTree(), nip19, event);
  if (!snapshot) {
    return null;
  }
  return registerSnapshot(snapshot, { updateTreeKey: true });
}

export async function readTreeEventSnapshot(snapshotCid: CID): Promise<TreeEventSnapshotInfo | null> {
  const hashKey = getSnapshotHashKey(snapshotCid);
  const cached = snapshotsBySnapshotHash.get(hashKey);
  if (cached) {
    return cached;
  }

  const inFlight = inFlightSnapshotReads.get(hashKey);
  if (inFlight) {
    return inFlight;
  }

  const lookup = (async (): Promise<TreeEventSnapshotInfo | null> => {
    try {
      const snapshot = await readStoredTreeEventSnapshot(getTree(), nip19, snapshotCid);
      if (!snapshot) {
        return null;
      }
      return registerSnapshot(snapshot, { updateTreeKey: false });
    } catch {
      return null;
    }
  })();

  inFlightSnapshotReads.set(hashKey, lookup);
  try {
    return await lookup;
  } finally {
    inFlightSnapshotReads.delete(hashKey);
  }
}
