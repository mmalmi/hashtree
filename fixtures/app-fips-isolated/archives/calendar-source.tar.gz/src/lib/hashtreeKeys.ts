import { computeKeyId, decryptKeyFromLink, encryptKeyForLink, fromHex, objectKeyFromHex, toHex } from '@hashtree/core';

/** Link secrets and XOR masks are opaque bytes: their first byte is not a suite. */
export function isLinkSecretHex(value: unknown): value is string {
  return typeof value === 'string' && /^(?:[0-9a-f]{2}){32,33}$/i.test(value);
}

export function linkSecretFromHex(value: string): Uint8Array {
  if (!isLinkSecretHex(value)) throw new Error('Invalid Hashtree link secret');
  return fromHex(value);
}

export function hashFromHex(value: string): Uint8Array {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/i.test(value)) throw new Error('Invalid Hashtree hash');
  return fromHex(value);
}

/** Older owner events wrapped the content key instead of the sharing secret. */
export function recoverSharingSecret(contentKey: string, maskedKey: string): string {
  if (!isLinkSecretHex(maskedKey)) throw new Error('Invalid Hashtree XOR mask');
  return toHex(encryptKeyForLink(objectKeyFromHex(contentKey), fromHex(maskedKey)));
}

export async function unmaskObjectKey(masked: string, secret: string, keyId?: string): Promise<Uint8Array | null> {
  // Historical AES-GCM envelopes carry a nonce and authentication tag.
  if (!isLinkSecretHex(masked) && !/^[0-9a-f]{120}$/i.test(masked)) return null;
  const bytes = linkSecretFromHex(secret);
  if (keyId !== undefined && keyId.toLowerCase() !== toHex(await computeKeyId(bytes))) return null;
  return decryptKeyFromLink(fromHex(masked), bytes);
}
