import { parseRoute } from '../utils/route';
import { isLinkSecretHex } from './hashtreeKeys';

export async function findTreeSharingSecret(npub: string, treeName: string): Promise<string | undefined> {
  const { getLinkKey, waitForLinkKeysCache } = await import('../stores/trees');
  let stored = getLinkKey(npub, treeName);
  if (!stored) {
    await waitForLinkKeysCache();
    stored = getLinkKey(npub, treeName);
  }
  if (isLinkSecretHex(stored)) return stored;

  const route = parseRoute();
  const secret = route.params.get('k');
  return route.npub === npub && route.treeName === treeName && isLinkSecretHex(secret) ? secret : undefined;
}

/** Async owner recovery may finish after navigation. Only amend the matching tree URL. */
export function showTreeSharingSecret(npub: string, treeName: string, secret: string): void {
  const route = parseRoute();
  if (!isLinkSecretHex(secret) || route.npub !== npub || route.treeName !== treeName || route.params.has('k')) return;
  const hash = window.location.hash;
  window.history.replaceState(null, '', hash + (hash.includes('?') ? '&' : '?') + 'k=' + secret);
}
