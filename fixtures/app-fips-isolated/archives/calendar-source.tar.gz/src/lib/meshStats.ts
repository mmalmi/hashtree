export type MeshPeerState = 'connected' | 'disconnected';
export type MeshPeerPool = 'follows' | 'others';
export type MeshPeerSource = 'worker' | 'daemon';
export type MeshTransport = 'webrtc' | 'bluetooth' | string;

export interface MeshPeerInfo {
  id: string;
  peerId: string;
  pubkey: string;
  state: MeshPeerState;
  pool: MeshPeerPool;
  bytesSent: number;
  bytesReceived: number;
  transport: MeshTransport;
  source: MeshPeerSource;
  signalPaths: string[];
}

export interface MeshTotals {
  totalBytesSent: number;
  totalBytesReceived: number;
}

export interface MeshHistoryCursor extends MeshTotals {
  timestamp: number;
}

export interface MeshBandwidthHistoryPoint extends MeshTotals {
  timestamp: number;
  uploadBps: number;
  downloadBps: number;
}

function readNumber(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : 0;
}

export function mergeMeshPeers(...peerLists: readonly MeshPeerInfo[][]): MeshPeerInfo[] {
  const merged = new Map<string, MeshPeerInfo>();
  for (const peers of peerLists) {
    for (const peer of peers) {
      merged.set(peer.id, peer);
    }
  }

  return Array.from(merged.values()).sort((left, right) => {
    if (left.state !== right.state) {
      return left.state === 'connected' ? -1 : 1;
    }
    if (left.pool !== right.pool) {
      return left.pool === 'follows' ? -1 : 1;
    }
    if (left.transport !== right.transport) {
      return left.transport.localeCompare(right.transport);
    }
    return left.peerId.localeCompare(right.peerId);
  });
}

export function calculateMeshTotals(peers: readonly Pick<MeshPeerInfo, 'bytesSent' | 'bytesReceived'>[]): MeshTotals {
  return peers.reduce<MeshTotals>((totals, peer) => ({
    totalBytesSent: totals.totalBytesSent + readNumber(peer.bytesSent),
    totalBytesReceived: totals.totalBytesReceived + readNumber(peer.bytesReceived),
  }), {
    totalBytesSent: 0,
    totalBytesReceived: 0,
  });
}

export function advanceMeshBandwidthHistory(
  previous: MeshHistoryCursor | null,
  history: readonly MeshBandwidthHistoryPoint[],
  totals: MeshTotals,
  timestamp: number,
  maxPoints = 60,
): {
  nextCursor: MeshHistoryCursor;
  rates: { uploadBps: number; downloadBps: number };
  history: MeshBandwidthHistoryPoint[];
} {
  const nextCursor: MeshHistoryCursor = {
    timestamp,
    totalBytesSent: totals.totalBytesSent,
    totalBytesReceived: totals.totalBytesReceived,
  };

  if (!previous || previous.timestamp <= 0 || timestamp <= previous.timestamp) {
    return {
      nextCursor,
      rates: { uploadBps: 0, downloadBps: 0 },
      history: Array.from(history).slice(-Math.max(0, maxPoints - 1)).concat({
        timestamp,
        totalBytesSent: totals.totalBytesSent,
        totalBytesReceived: totals.totalBytesReceived,
        uploadBps: 0,
        downloadBps: 0,
      }),
    };
  }

  const elapsedSeconds = Math.max((timestamp - previous.timestamp) / 1000, 0.001);
  const uploadBytes = Math.max(0, totals.totalBytesSent - previous.totalBytesSent);
  const downloadBytes = Math.max(0, totals.totalBytesReceived - previous.totalBytesReceived);
  const point: MeshBandwidthHistoryPoint = {
    timestamp,
    totalBytesSent: totals.totalBytesSent,
    totalBytesReceived: totals.totalBytesReceived,
    uploadBps: uploadBytes / elapsedSeconds,
    downloadBps: downloadBytes / elapsedSeconds,
  };

  return {
    nextCursor,
    rates: { uploadBps: point.uploadBps, downloadBps: point.downloadBps },
    history: Array.from(history).slice(-Math.max(0, maxPoints - 1)).concat(point),
  };
}
