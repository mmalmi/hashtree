/**
 * File URL Helper
 *
 * Generates URLs for streaming files through the service worker (web)
 * or native HTTP server (Tauri desktop).
 *
 * URL formats:
 * - Web:   /htree/{npub}/{treeName}/{path} or /htree/{nhash}/{filename}
 * - Tauri: http://127.0.0.1:21417/htree/{...} (same path structure, fixed port)
 */

import { logHtreeDebug } from './htreeDebug';
import {
  getRuntimeHtreeServerUrl,
  isSameOriginIrisGatewayRuntime,
} from './htreeRuntime';
import { canUseInjectedHtreeServerUrl } from './nativeHtree';

const LOCAL_PROBE_TIMEOUT_MS = 500;
const LOCAL_PROBE_INTERVAL_MS = 1000;

let cachedPrefix = '';
const prefixListeners = new Set<(prefix: string) => void>();
let localProbePromise: Promise<boolean> | null = null;
let prefixReady = false;
let prefixEpoch = 0;

function isLocalHtreePrefix(prefix: string): boolean {
  // Treat loopback URLs and local Iris gateway origins as local prefixes.
  return /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(prefix)
    || /^http:\/\/([^/]+\.)?iris\.localhost(:\d+)?$/.test(prefix);
}

function allowLocalPrefix(): boolean {
  return canUseInjectedHtreeServerUrl() || isSameOriginIrisGatewayRuntime();
}

async function probeLocalHtreeServer(baseUrl: string): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  if (localProbePromise) return localProbePromise;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LOCAL_PROBE_TIMEOUT_MS);

  localProbePromise = fetch(`${baseUrl}/htree/test`, {
    method: 'HEAD',
    signal: controller.signal,
  })
    .then(() => true)
    .catch(() => false)
    .finally(() => {
      clearTimeout(timeout);
      localProbePromise = null;
    });

  return localProbePromise;
}

function notifyPrefixReady(source: string): void {
  if (prefixReady) return;
  if (!cachedPrefix) return;
  prefixReady = true;
  prefixEpoch += 1;
  logHtreeDebug('prefix:ready', { prefix: cachedPrefix, source, epoch: prefixEpoch });
  prefixListeners.forEach((callback) => {
    try {
      callback(cachedPrefix);
    } catch (err) {
      console.warn('[mediaUrl] Failed to notify prefix listener:', err);
    }
  });
  prefixListeners.clear();
}

function updateCachedPrefix(next: string, source: string): void {
  const normalized = next.trim().replace(/\/$/, '');
  if (normalized === cachedPrefix) return;
  cachedPrefix = normalized;
  logHtreeDebug('prefix:update', { prefix: normalized, source });
}

function getHtreeServerOverride(): string | null {
  return getRuntimeHtreeServerUrl();
}

/**
 * Get the URL prefix based on runtime environment
 * - Web: "" (uses relative /htree paths, service worker intercepts)
 * - Tauri: http://127.0.0.1:21417 (fixed htree server URL)
 */
export function getHtreePrefix(): string {
  const override = getHtreeServerOverride();
  if (override && allowLocalPrefix()) {
    updateCachedPrefix(override, 'override');
    if (!prefixReady && !isLocalHtreePrefix(cachedPrefix)) {
      notifyPrefixReady('override');
    }
    return cachedPrefix;
  }
  const allowLocal = allowLocalPrefix();
  if (cachedPrefix) {
    if (!isLocalHtreePrefix(cachedPrefix) || allowLocal) {
      return cachedPrefix;
    }
    cachedPrefix = '';
    prefixReady = false;
    prefixEpoch = 0;
  }
  if (typeof window !== 'undefined' && window.htree?.htreeBaseUrl) {
    const prefix = window.htree.htreeBaseUrl;
    if (typeof prefix === 'string' && prefix.trim()) {
      const normalized = prefix.trim().replace(/\/$/, '');
      if (!isLocalHtreePrefix(normalized) || allowLocal) {
        updateCachedPrefix(normalized, 'window.htree');
        if (!prefixReady && !isLocalHtreePrefix(cachedPrefix)) {
          notifyPrefixReady('window.htree');
        }
        return cachedPrefix;
      }
    }
  }
  return '';
}

/**
 * Subscribe to prefix ready - fires when a usable prefix is confirmed.
 */
export function onHtreePrefixReady(callback: (prefix: string) => void): void {
  if (prefixReady && cachedPrefix) {
    callback(cachedPrefix);
    return;
  }
  prefixListeners.add(callback);
}

/**
 * Initialize htree prefix - waits for Tauri server to be reachable.
 */
export async function initHtreePrefix(): Promise<void> {
  if (typeof window === 'undefined') return;
  if (prefixReady) return;
  const prefix = getHtreePrefix();
  if (prefix && !isLocalHtreePrefix(prefix)) {
    notifyPrefixReady('init');
    return;
  }
  if (!allowLocalPrefix()) {
    return;
  }

  // Native app sets __HTREE_SERVER_URL__; poll until the server is reachable.
  const override = getHtreeServerOverride();
  if (!override) return;

  const start = Date.now();
  const maxWaitMs = 60000;
  const intervalMs = 100;
  const maxAttempts = Math.ceil(maxWaitMs / intervalMs);
  let lastProbeAt = 0;
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(resolve => setTimeout(resolve, intervalMs));
    const nextPrefix = getHtreePrefix();
    if (nextPrefix && !isLocalHtreePrefix(nextPrefix)) {
      notifyPrefixReady('init');
      return;
    }
    const now = Date.now();
    if (now - lastProbeAt >= LOCAL_PROBE_INTERVAL_MS) {
      lastProbeAt = now;
      const reachable = await probeLocalHtreeServer(override);
      if (reachable) {
        updateCachedPrefix(override, 'local-probe');
        notifyPrefixReady('local-probe');
        return;
      }
    }
  }
  logHtreeDebug('prefix:init-timeout', { waitedMs: Math.round(Date.now() - start) });
}
