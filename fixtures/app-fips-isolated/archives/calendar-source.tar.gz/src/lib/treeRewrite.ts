import { encryptionMode, HashTree, type CID } from '@hashtree/core';

/** Replacing file contents must preserve randomized encryption, including in mixed trees. */
export function writerForEntry(tree: HashTree, entry?: CID): HashTree {
  return entry?.key && encryptionMode(entry.key) === 'rnd-v1'
    ? new HashTree({ store: tree.getStore(), encryptionMode: 'rnd-v1' })
    : tree;
}
