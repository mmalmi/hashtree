import { LinkType, toHex, type CID, type TreeEntry } from '@hashtree/core';
import { getTree } from '../../store';
import { getTreeRoot, getTreeRootSync, waitForTreeRoot } from '../../stores';
import {
  BOARD_CARD_FILE_SUFFIX,
  BOARD_CARDS_DIR,
  BOARD_COLUMN_META_FILE,
  BOARD_COLUMNS_DIR,
  BOARD_META_FILE,
  BOARD_ORDER_FILE,
  BOARD_PERMISSIONS_FILE,
  BOARD_TOMBSTONES_FILE,
} from './constants';
import {
  createBoardId,
  createInitialBoardTombstones,
  parseBoardMeta,
  parseBoardOrder,
  parseBoardState,
  parseBoardTombstones,
  parseCardData,
  parseColumnMeta,
  serializeBoardMeta,
  serializeBoardOrder,
  serializeBoardTombstones,
  serializeCardData,
  serializeColumnMeta,
  type BoardCard,
  type BoardColumn,
  type BoardState,
  type BoardTombstones,
} from './state';
import {
  parseBoardPermissions,
  serializeBoardPermissions,
  type BoardPermissions,
} from './permissions';
import {
  applyCardOrder,
  applyColumnOrder,
  attachmentCid,
  boardDisplayName,
  cardAttachmentsDirName,
  cardIdFromAttachmentsDir,
  cardIdFromFilename,
  guessMimeType,
} from './viewHelpers';

export interface BoardDirectoryData {
  board: BoardState | null;
  permissions: BoardPermissions | null;
  tombstones: BoardTombstones;
  incomplete: boolean;
}

function sortEntriesByName(entries: TreeEntry[]): TreeEntry[] {
  return [...entries].sort((a, b) => a.name.localeCompare(b.name));
}

function findBlobEntry(entries: TreeEntry[], filename: string): TreeEntry | undefined {
  return entries.find(entry => entry.name === filename && entry.type !== LinkType.Dir);
}

function findDirEntry(entries: TreeEntry[], name: string): TreeEntry | undefined {
  return entries.find(entry => entry.name === name && entry.type === LinkType.Dir);
}

export async function resolveBoardDirectory(root: CID, boardPath: string[]): Promise<CID | null> {
  const tree = getTree();
  if (boardPath.length === 0) return root;
  const resolved = await tree.resolvePath(root, boardPath.join('/'));
  if (!resolved) return null;
  const isDir = await tree.isDirectory(resolved.cid);
  return isDir ? resolved.cid : null;
}

export async function loadBoardFromDirectory(
  dirCid: CID,
  fallbackBoardId: string,
  fallbackTitle: string,
  fallbackUpdatedBy: string,
  ownerNpub: string,
): Promise<BoardDirectoryData> {
  const tree = getTree();
  const entries = await tree.listDirectory(dirCid);
  let incomplete = false;

  const boardMetaEntry = findBlobEntry(entries, BOARD_META_FILE);
  const boardOrderEntry = findBlobEntry(entries, BOARD_ORDER_FILE);
  const permissionsEntry = findBlobEntry(entries, BOARD_PERMISSIONS_FILE);
  const tombstonesEntry = findBlobEntry(entries, BOARD_TOMBSTONES_FILE);
  const columnsDirEntry = findDirEntry(entries, BOARD_COLUMNS_DIR);

  const boardMetaData = boardMetaEntry ? await tree.readFile(boardMetaEntry.cid) : null;
  if (boardMetaEntry && boardMetaData === null) incomplete = true;
  const boardMeta = boardMetaData ? parseBoardMeta(boardMetaData, fallbackBoardId, fallbackTitle, fallbackUpdatedBy) : null;
  const legacyBoardState = boardMetaData ? parseBoardState(boardMetaData, fallbackBoardId, fallbackTitle, fallbackUpdatedBy) : null;

  const permissionsData = permissionsEntry ? await tree.readFile(permissionsEntry.cid) : null;
  if (permissionsEntry && permissionsData === null) incomplete = true;
  const parsedPermissions = permissionsData && ownerNpub ? parseBoardPermissions(permissionsData, ownerNpub) : null;

  const tombstonesData = tombstonesEntry ? await tree.readFile(tombstonesEntry.cid) : null;
  if (tombstonesEntry && tombstonesData === null) incomplete = true;
  const parsedTombstones = tombstonesData ? parseBoardTombstones(tombstonesData, fallbackUpdatedBy) : createInitialBoardTombstones();

  const boardOrderData = boardOrderEntry ? await tree.readFile(boardOrderEntry.cid) : null;
  if (boardOrderEntry && boardOrderData === null) incomplete = true;
  const boardOrder = parseBoardOrder(
    boardOrderData,
    boardMeta?.updatedAt ?? legacyBoardState?.orderUpdatedAt ?? legacyBoardState?.updatedAt ?? 0,
    boardMeta?.updatedBy ?? legacyBoardState?.orderUpdatedBy ?? legacyBoardState?.updatedBy ?? fallbackUpdatedBy,
  );

  const parsedColumns: BoardColumn[] = [];
  if (columnsDirEntry) {
    const columnEntries = sortEntriesByName(await tree.listDirectory(columnsDirEntry.cid));
    for (const columnEntry of columnEntries) {
      if (columnEntry.type !== LinkType.Dir) continue;
      const column = await loadColumn(columnEntry, boardMeta?.updatedAt ?? legacyBoardState?.updatedAt ?? 0, boardMeta?.updatedBy ?? legacyBoardState?.updatedBy ?? fallbackUpdatedBy);
      if (column) parsedColumns.push(column);
    }
  }

  const hasStructuredBoardData = !!boardMetaEntry || !!boardOrderEntry || !!columnsDirEntry;
  let parsedBoard: BoardState | null = null;
  if (hasStructuredBoardData) {
    const orderedColumns = applyColumnOrder(parsedColumns, boardOrder.columns)
      .map(column => ({ ...column, cards: applyCardOrder(column.cards, boardOrder.cardsByColumn[column.id]) }));
    parsedBoard = {
      version: 1,
      boardId: boardMeta?.boardId || parsedPermissions?.boardId || fallbackBoardId,
      title: boardMeta?.title || parsedPermissions?.title || fallbackTitle,
      columns: orderedColumns,
      updatedAt: boardMeta?.updatedAt || parsedPermissions?.updatedAt || Date.now(),
      updatedBy: boardMeta?.updatedBy || parsedPermissions?.updatedBy || fallbackUpdatedBy,
      orderUpdatedAt: boardOrder.updatedAt || boardMeta?.updatedAt || parsedPermissions?.updatedAt || Date.now(),
      orderUpdatedBy: boardOrder.updatedBy || boardMeta?.updatedBy || parsedPermissions?.updatedBy || fallbackUpdatedBy,
    };
    if (parsedBoard.columns.length === 0 && legacyBoardState?.columns.length) parsedBoard = legacyBoardState;
  } else if (legacyBoardState) {
    parsedBoard = legacyBoardState;
  }

  return { board: parsedBoard, permissions: parsedPermissions, tombstones: parsedTombstones, incomplete };
}

async function loadColumn(columnEntry: TreeEntry, fallbackUpdatedAt: number, fallbackUpdatedBy: string): Promise<BoardColumn | null> {
  const tree = getTree();
  const columnDirEntries = await tree.listDirectory(columnEntry.cid);
  const columnMetaEntry = findBlobEntry(columnDirEntries, BOARD_COLUMN_META_FILE);
  const cardsDirEntry = findDirEntry(columnDirEntries, BOARD_CARDS_DIR);
  const columnMetaData = columnMetaEntry ? await tree.readFile(columnMetaEntry.cid) : null;
  const columnMeta = columnMetaData
    ? parseColumnMeta(columnMetaData, columnEntry.name, fallbackUpdatedAt, fallbackUpdatedBy)
    : { id: columnEntry.name, title: 'Untitled Column', updatedAt: fallbackUpdatedAt, updatedBy: fallbackUpdatedBy };
  if (!columnMeta) return null;
  const cards = cardsDirEntry ? await loadCards(cardsDirEntry, columnMeta.updatedAt, columnMeta.updatedBy, fallbackUpdatedBy) : [];
  return { id: columnMeta.id, title: columnMeta.title, cards, updatedAt: columnMeta.updatedAt, updatedBy: columnMeta.updatedBy };
}

async function loadCards(cardsDirEntry: TreeEntry, fallbackUpdatedAt: number, fallbackUpdatedBy: string, fallbackUploader: string): Promise<BoardCard[]> {
  const tree = getTree();
  const cardEntries = sortEntriesByName(await tree.listDirectory(cardsDirEntry.cid));
  const attachmentDirs: Record<string, TreeEntry> = {};
  for (const entry of cardEntries) {
    if (entry.type !== LinkType.Dir) continue;
    const cardId = cardIdFromAttachmentsDir(entry.name);
    if (cardId) attachmentDirs[cardId] = entry;
  }

  const cards: BoardCard[] = [];
  for (const cardEntry of cardEntries) {
    if (cardEntry.type === LinkType.Dir || !cardEntry.name.endsWith(BOARD_CARD_FILE_SUFFIX)) continue;
    const cardData = await tree.readFile(cardEntry.cid);
    if (cardData === null) continue;
    const fallbackCardId = cardIdFromFilename(cardEntry.name);
    const card = parseCardData(cardData, fallbackCardId, fallbackUpdatedAt, fallbackUpdatedBy);
    if (!card) continue;
    await appendDirectoryAttachments(card, attachmentDirs[card.id] || attachmentDirs[fallbackCardId], fallbackUploader);
    cards.push(card);
  }
  return cards;
}

async function appendDirectoryAttachments(card: BoardCard, attachmentDir: TreeEntry | undefined, fallbackUploader: string): Promise<void> {
  if (!attachmentDir) return;
  const tree = getTree();
  const attachmentEntries = sortEntriesByName(await tree.listDirectory(attachmentDir.cid)).filter(entry => entry.type !== LinkType.Dir);
  const existingByFileName: Record<string, true> = {};
  for (const attachment of card.attachments) existingByFileName[attachment.fileName] = true;
  for (const attachmentEntry of attachmentEntries) {
    if (existingByFileName[attachmentEntry.name]) continue;
    card.attachments.push({
      id: createBoardId(),
      fileName: attachmentEntry.name,
      displayName: attachmentEntry.name,
      mimeType: guessMimeType(attachmentEntry.name),
      size: attachmentEntry.size,
      uploaderNpub: fallbackUploader,
      cidHash: toHex(attachmentEntry.cid.hash),
      cidKey: attachmentEntry.cid.key ? toHex(attachmentEntry.cid.key) : undefined,
    });
    existingByFileName[attachmentEntry.name] = true;
  }
}

export async function loadParticipantBoardData(options: {
  participantNpub: string;
  viewedNpub: string | undefined;
  treeRoot: CID | null | undefined;
  treeName: string;
  boardPath: string[];
  timeoutMs: number;
  linkKey: string | null;
  ownerNpub: string;
}): Promise<{ data: BoardDirectoryData | null; hasPendingRoot: boolean }> {
  const { participantNpub, viewedNpub, treeRoot, treeName, boardPath, timeoutMs, linkKey, ownerNpub } = options;
  let participantRoot: CID | null = null;
  if (participantNpub === viewedNpub) {
    participantRoot = treeRoot ?? null;
  } else {
    participantRoot = await getTreeRoot(participantNpub, treeName, linkKey);
    if (!participantRoot) participantRoot = await waitForTreeRoot(participantNpub, treeName, timeoutMs, linkKey);
  }
  if (!participantRoot) return { data: null, hasPendingRoot: true };
  try {
    const participantBoardDir = await resolveBoardDirectory(participantRoot, boardPath);
    if (!participantBoardDir) return { data: null, hasPendingRoot: true };
    return {
      data: await loadBoardFromDirectory(participantBoardDir, createBoardId(), boardDisplayName(treeName), participantNpub, ownerNpub),
      hasPendingRoot: false,
    };
  } catch (error) {
    console.debug('[BoardView] Pending participant board hydration', { participantNpub, treeName, error });
    return { data: null, hasPendingRoot: true };
  }
}

async function putTextFile(text: string): Promise<{ cid: CID; size: number }> {
  const data = new TextEncoder().encode(text);
  return getTree().putFile(data);
}

export async function buildBoardDirectoryCid(
  nextBoard: BoardState,
  nextPermissions: BoardPermissions,
  nextTombstones: BoardTombstones,
): Promise<CID> {
  const tree = getTree();
  const columnEntries: TreeEntry[] = [];
  for (const column of nextBoard.columns) {
    const cardEntries: TreeEntry[] = [];
    for (const card of column.cards) {
      const { cid: cardCid, size: cardSize } = await putTextFile(serializeCardData(card));
      cardEntries.push({ name: `${card.id}${BOARD_CARD_FILE_SUFFIX}`, cid: cardCid, size: cardSize, type: LinkType.Blob });
      if (card.attachments.length === 0) continue;
      const attachmentEntries = card.attachments
        .map(attachment => ({ attachment, cid: attachmentCid(attachment) }))
        .filter((entry): entry is { attachment: typeof card.attachments[number]; cid: CID } => !!entry.cid)
        .map(({ attachment, cid }) => ({ name: attachment.fileName, cid, size: attachment.size, type: LinkType.Blob }));
      if (attachmentEntries.length === 0) continue;
      const { cid: attachmentsDirCid } = await tree.putDirectory(attachmentEntries);
      cardEntries.push({ name: cardAttachmentsDirName(card.id), cid: attachmentsDirCid, size: 0, type: LinkType.Dir });
    }

    const { cid: cardsCid } = await tree.putDirectory(cardEntries);
    const { cid: columnMetaCid, size: columnMetaSize } = await putTextFile(serializeColumnMeta(column));
    const { cid: columnDirCid } = await tree.putDirectory([
      { name: BOARD_COLUMN_META_FILE, cid: columnMetaCid, size: columnMetaSize, type: LinkType.Blob },
      { name: BOARD_CARDS_DIR, cid: cardsCid, size: 0, type: LinkType.Dir },
    ]);
    columnEntries.push({ name: column.id, cid: columnDirCid, size: 0, type: LinkType.Dir });
  }

  const { cid: columnsCid } = await tree.putDirectory(columnEntries);
  const { cid: boardMetaCid, size: boardMetaSize } = await putTextFile(serializeBoardMeta(nextBoard));
  const { cid: boardOrderCid, size: boardOrderSize } = await putTextFile(serializeBoardOrder(nextBoard));
  const { cid: permissionsCid, size: permissionsSize } = await putTextFile(serializeBoardPermissions(nextPermissions));
  const { cid: tombstonesCid, size: tombstonesSize } = await putTextFile(serializeBoardTombstones(nextTombstones));
  const { cid: boardDirCid } = await tree.putDirectory([
    { name: BOARD_META_FILE, cid: boardMetaCid, size: boardMetaSize, type: LinkType.Blob },
    { name: BOARD_ORDER_FILE, cid: boardOrderCid, size: boardOrderSize, type: LinkType.Blob },
    { name: BOARD_PERMISSIONS_FILE, cid: permissionsCid, size: permissionsSize, type: LinkType.Blob },
    { name: BOARD_TOMBSTONES_FILE, cid: tombstonesCid, size: tombstonesSize, type: LinkType.Blob },
    { name: BOARD_COLUMNS_DIR, cid: columnsCid, size: 0, type: LinkType.Dir },
  ]);
  return boardDirCid;
}

export async function buildUpdatedBoardRootCid(options: {
  userNpub: string | null | undefined;
  treeName: string | null | undefined;
  boardPath: string[];
  nextBoard: BoardState;
  nextPermissions: BoardPermissions;
  nextTombstones: BoardTombstones;
}): Promise<CID | null> {
  const { userNpub, treeName, boardPath, nextBoard, nextPermissions, nextTombstones } = options;
  if (!userNpub || !treeName) return null;
  const tree = getTree();
  let rootCid = getTreeRootSync(userNpub, treeName);
  if (!rootCid) rootCid = (await tree.putDirectory([])).cid;

  for (let index = 0; index < boardPath.length; index += 1) {
    const fullPath = boardPath.slice(0, index + 1).join('/');
    if (await tree.resolvePath(rootCid, fullPath)) continue;
    rootCid = await tree.setEntry(rootCid, boardPath.slice(0, index), boardPath[index], (await tree.putDirectory([])).cid, 0, LinkType.Dir);
  }

  const boardDirCid = await buildBoardDirectoryCid(nextBoard, nextPermissions, nextTombstones);
  return boardPath.length === 0
    ? boardDirCid
    : tree.setEntry(rootCid, boardPath.slice(0, -1), boardPath[boardPath.length - 1], boardDirCid, 0, LinkType.Dir);
}
