export {
  canUseInjectedHtreeServerUrl,
  canUseSameOriginHtreeProtocolStreaming,
  getInjectedHtreeServerUrl,
  shouldPreferSameOriginHtreeRoutes,
} from '@hashtree/worker';
