export type IrisFilesAppId = 'calendar';

export interface AppBrand {
  id: IrisFilesAppId;
  label: string;
  displayName: string;
  iconSvg: string;
  appleTouchPng: string;
  pwa192Png: string;
  pwa512Png: string;
}

const APP_BRANDS: Record<IrisFilesAppId, AppBrand> = {
  calendar: {
    id: 'calendar',
    label: 'Calendar',
    displayName: 'Iris Calendar',
    iconSvg: 'iris-calendar-icon.svg',
    appleTouchPng: 'iris-calendar-icon-180.png',
    pwa192Png: 'iris-calendar-icon-192.png',
    pwa512Png: 'iris-calendar-icon-512.png',
  },
};

export function getAppBrand(app: IrisFilesAppId = 'calendar'): AppBrand {
  return APP_BRANDS[app];
}

export function getAppPwaIcons(app: IrisFilesAppId) {
  const brand = getAppBrand(app);

  return [
    {
      src: brand.pwa192Png,
      sizes: '192x192',
      type: 'image/png',
    },
    {
      src: brand.pwa512Png,
      sizes: '512x512',
      type: 'image/png',
    },
    {
      src: brand.pwa512Png,
      sizes: '512x512',
      type: 'image/png',
      purpose: 'any maskable',
    },
  ];
}
