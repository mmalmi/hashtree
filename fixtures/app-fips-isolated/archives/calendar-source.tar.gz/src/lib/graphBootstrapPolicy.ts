import { DEFAULT_PUBLIC_RELAYS, RETIRED_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';

function normalizedRelay(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (!['ws:', 'wss:'].includes(url.protocol)) return null;
    return url.href.replace(/\/$/, '');
  } catch {
    return null;
  }
}

const retired = new Set(RETIRED_PUBLIC_RELAYS.map(normalizedRelay));

/**
 * Fixed public graph bootstrap is only allowed with the shipped relay set.
 * A list saved before a default relay was retired still counts as that set.
 */
export function shouldBootstrapPublicGraph(relays: readonly string[]): boolean {
  const normalized = relays.map(normalizedRelay);
  if (normalized.some(relay => relay === null)) return false;
  const actual = new Set(normalized.filter(relay => !retired.has(relay)));
  const defaults = new Set(DEFAULT_PUBLIC_RELAYS.map(normalizedRelay));
  return actual.size === defaults.size && [...defaults].every(relay => actual.has(relay));
}
