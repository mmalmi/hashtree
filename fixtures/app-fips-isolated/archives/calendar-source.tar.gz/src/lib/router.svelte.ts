/**
 * Simple hash router for Svelte 5 using stores for reliable reactivity
 */
import { writable } from 'svelte/store';

// Get initial path from hash (without query string)
function getHashPath(): string {
  if (typeof window === 'undefined') return '/';
  const hash = window.location.hash.slice(1); // Remove #
  if (!hash && directPathIsRoutable(window.location.pathname)) {
    return window.location.pathname;
  }
  // Remove query string for path matching
  const queryIndex = hash.indexOf('?');
  return queryIndex !== -1 ? hash.slice(0, queryIndex) || '/' : hash || '/';
}

function directPathIsRoutable(pathname: string): boolean {
  return pathname === '/share' || pathname.startsWith('/share-invite/');
}

// Create writable stores
const pathStore = writable<string>(getHashPath());

// Export the stores for subscription
export const currentPath = {
  subscribe: pathStore.subscribe
};

// Initialize hashchange listener (call once from App.svelte onMount)
// Store the flag on a global to persist across HMR module reloads
const HMR_KEY = '__routerInitialized';
const globalObj = typeof globalThis !== 'undefined' ? globalThis : window;

export function initRouter() {
  if ((globalObj as Record<string, unknown>)[HMR_KEY] || typeof window === 'undefined') return;
  (globalObj as Record<string, unknown>)[HMR_KEY] = true;

  // Update stores with current hash (important for initial page load with hash)
  pathStore.set(getHashPath());

  let lastPath = getHashPath();

  window.addEventListener('hashchange', () => {
    const newPath = getHashPath();
    const pathChanged = newPath !== lastPath;
    lastPath = newPath;

    pathStore.set(newPath);

    // Scroll to top when path changes (not just query params)
    if (pathChanged) {
      window.scrollTo(0, 0);
    }
  });
}

// Navigate to a new hash route
export function navigate(path: string) {
  // Ensure path starts with /
  const normalizedPath = path.startsWith('/') ? path : '/' + path;

  // Update hash (this will trigger hashchange which updates the store)
  window.location.hash = normalizedPath;

  // Also update store directly for immediate reactivity within same tick
  pathStore.set(normalizedPath);
}

// Get current query params
export function getQueryParamsFromHash(hash: string): URLSearchParams {
  const hashValue = hash.startsWith('#') ? hash.slice(1) : hash;
  const queryIndex = hashValue.indexOf('?');
  if (queryIndex === -1) return new URLSearchParams();
  return new URLSearchParams(hashValue.slice(queryIndex + 1));
}
