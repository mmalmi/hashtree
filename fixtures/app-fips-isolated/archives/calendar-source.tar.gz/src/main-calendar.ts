import 'virtual:uno.css';
import CalendarApp from './CalendarApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker } from './lib/swInit';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { setAppType } from './appType';
import { initHtreeApi } from './lib/htreeApi';

setAppType('calendar');

async function init() {
  mount(CalendarApp, {
    target: document.getElementById('app')!,
  });
  await initServiceWorker();
  const htreePromise = initHtreeApi();
  const backendPromise = initReadonlyBackend();
  const sessionPromise = restoreSession();
  await Promise.all([backendPromise, sessionPromise]);
  await htreePromise;
}

init();
