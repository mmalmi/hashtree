<script lang="ts">
  import { onMount } from 'svelte';
  import CalendarHome from './components/Calendar/CalendarHome.svelte';
  import { currentPath, initRouter } from './lib/router.svelte';

  onMount(() => {
    initRouter();
  });

  // Settings and people pages load when first opened, so the calendar itself starts sooner.
  const userPages = {
    profile: () => import('./components/ProfileView.svelte'),
    follows: () => import('./components/FollowsPage.svelte'),
    followers: () => import('./components/FollowersPage.svelte'),
    edit: () => import('./components/EditProfilePage.svelte'),
  };

  let showSettings = $derived($currentPath === '/settings' || $currentPath.startsWith('/settings/'));
  let userRoute = $derived.by(() => {
    const match = /^\/(npub1[a-z0-9]+)(?:\/(profile|follows|followers|edit))?\/?$/.exec($currentPath);
    return match ? { npub: match[1], page: (match[2] ?? 'profile') as keyof typeof userPages } : null;
  });
</script>

<div class="h-full flex flex-col bg-surface-0">
  <div class="flex-1 flex flex-col min-h-0">
    {#if showSettings}
      {#await import('./components/settings/SettingsLayout.svelte') then { default: SettingsLayout }}
        <SettingsLayout />
      {/await}
    {:else if $currentPath === '/users'}
      {#await import('./components/UsersPage.svelte') then { default: UsersPage }}
        <UsersPage />
      {/await}
    {:else if userRoute}
      <header class="shrink-0 border-b border-surface-3 px-4 py-3">
        <a href="#/" class="text-text-1 hover:underline">Calendar</a>
      </header>
      {#await userPages[userRoute.page]() then { default: UserPage }}
        <UserPage npub={userRoute.npub} />
      {/await}
    {:else}
      <CalendarHome />
    {/if}
  </div>
</div>
