<script lang="ts">
  import { onMount } from 'svelte';
  import Toast from './components/Toast.svelte';
  import CalendarHome from './components/Calendar/CalendarHome.svelte';
  import SettingsLayout from './components/settings/SettingsLayout.svelte';
  import ProfileView from './components/ProfileView.svelte';
  import FollowsPage from './components/FollowsPage.svelte';
  import FollowersPage from './components/FollowersPage.svelte';
  import EditProfilePage from './components/EditProfilePage.svelte';
  import { currentPath, initRouter } from './lib/router.svelte';

  onMount(() => {
    initRouter();
  });

  let showSettings = $derived($currentPath === '/settings' || $currentPath.startsWith('/settings/'));
  let userRoute = $derived.by(() => {
    const match = /^\/(npub1[a-z0-9]+)(?:\/(profile|follows|followers|edit))?\/?$/.exec($currentPath);
    return match ? { npub: match[1], page: match[2] ?? 'profile' } : null;
  });
</script>

<div class="h-full flex flex-col bg-surface-0">
  <div class="flex-1 flex flex-col min-h-0">
    {#if showSettings}
      <SettingsLayout />
    {:else if userRoute}
      <header class="shrink-0 border-b border-surface-3 px-4 py-3">
        <a href="#/" class="text-text-1 hover:underline">Calendar</a>
      </header>
      {#if userRoute.page === 'follows'}
        <FollowsPage npub={userRoute.npub} />
      {:else if userRoute.page === 'followers'}
        <FollowersPage npub={userRoute.npub} />
      {:else if userRoute.page === 'edit'}
        <EditProfilePage npub={userRoute.npub} />
      {:else}
        <ProfileView npub={userRoute.npub} />
      {/if}
    {:else}
      <CalendarHome />
    {/if}
  </div>
  <Toast />
</div>
