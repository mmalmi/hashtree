/**
 * Route parsing utilities
 * Parses URL hash to extract route info without needing React Router context
 */
import { getQueryParamsFromHash } from '../lib/router.svelte';
import { nhashDecode, type CID } from '@hashtree/core';

/** Decoded CID for permalink routing */
export type RouteCid = CID;

export interface RouteInfo {
  npub: string | null;
  treeName: string | null;
  /** CID for permalink routes (hash + optional decrypt key) */
  cid: RouteCid | null;
  path: string[];
  /** True when viewing a permalink (nhash route) */
  isPermalink: boolean;
  /** All query params from URL - use params.get('k'), params.get('t'), etc. */
  params: URLSearchParams;
}

function safeDecodeURIComponent(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

/**
 * Parse route info from window.location.hash
 * Handles:
 * - #/npub/treeName/path/to/file
 * - #/nhash1.../path/to/file
 * - #/npub (user view)
 * - #/npub/profile
 */
export function parseRoute(): RouteInfo {
  // Get hash path and query params
  const fullHash = window.location.hash.slice(2); // Remove #/
  const [hashPath] = fullHash.split('?');
  const parts = hashPath.split('/').filter(Boolean).map(safeDecodeURIComponent);

  // Parse query params
  const params = getQueryParamsFromHash(window.location.hash);

  const emptyParams = new URLSearchParams();

  // nhash route: #/nhash1.../path...
  if (parts[0]?.startsWith('nhash1')) {
    // Decode nhash to extract CID (hash and optional key as Uint8Array)
    try {
      const cid = nhashDecode(parts[0]);
      return {
        npub: null,
        treeName: null,
        cid,
        path: parts.slice(1),
        isPermalink: true,
        params,
      };
    } catch {
      // Fall through if decode fails
    }
  }

  // Special routes (no tree context)
  if (['settings'].includes(parts[0])) {
    return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
  }

  // User routes
  if (parts[0]?.startsWith('npub')) {
    const npub = parts[0];

    // Special user routes (profile, follows, followers, edit)
    if (['profile', 'follows', 'followers', 'edit'].includes(parts[1])) {
      return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
    }

    // Tree route: #/npub/treeName/path...
    if (parts[1] && !['profile', 'follows', 'followers', 'edit'].includes(parts[1])) {
      return {
        npub,
        treeName: parts[1],
        cid: null,
        path: parts.slice(2),
        isPermalink: false,
        params,
      };
    }

    // User view: #/npub
    return { npub, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
  }

  // Home route
  return { npub: null, treeName: null, cid: null, path: [], isPermalink: false, params: emptyParams };
}
