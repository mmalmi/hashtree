<script lang="ts">
  import { navigate } from '../utils/navigate';
  import { nostrStore, generateNewKey } from '../nostr';
  import { isCalendarApp, isFilesApp } from '../appType';
  import { Avatar } from './User';

  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let npub = $derived($nostrStore.npub);
  let pubkey = $derived($nostrStore.pubkey);
  let accountButtonTitle = $derived(isCalendarApp() ? 'Settings' : 'My Profile (double-click for users)');

  function goToAccountDestination() {
    if (isCalendarApp()) {
      navigate('/settings');
      return;
    }
    if (!npub) return;
    navigate(`/${npub}/profile`);
  }

  function goToSecondaryAccountDestination() {
    navigate(isCalendarApp() ? '/settings' : '/users');
  }

  async function handleGenerate() {
    await generateNewKey();
  }
</script>

{#if isLoggedIn && pubkey}
  <!-- Logged in: just show avatar that links to the account destination. -->
  <button
    onclick={goToAccountDestination}
    ondblclick={goToSecondaryAccountDestination}
    class="bg-transparent border-none cursor-pointer p-0"
    title={accountButtonTitle}
    aria-label={accountButtonTitle}
  >
    <Avatar pubkey={pubkey} size={36} />
  </button>
{:else if isFilesApp()}
  <button
    onclick={() => navigate('/')}
    class="btn-circle btn-ghost"
    title="Set up profile"
    aria-label="Set up profile"
  >
    <span class="i-lucide-user-plus"></span>
  </button>
{:else}
  <div class="flex flex-wrap gap-2">
    <button onclick={handleGenerate} class="btn-success text-sm">Create account</button>
    <button onclick={() => navigate('/users')} class="btn-ghost text-sm">Already have an account?</button>
  </div>
{/if}
