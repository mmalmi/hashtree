<script lang="ts">
  import CopyButton from '@iris/svelte-ui/CopyButton.svelte';
  import { shouldOpenSourceCodeLinkInNewTab } from '../../appType';
  import { getSameOriginIrisGatewayServerUrl, normalizeRuntimeServerUrl } from '../../lib/htreeRuntime';
  import { canUseInjectedHtreeServerUrl, getInjectedHtreeServerUrl } from '../../lib/nativeHtree';
  import { getCanonicalGitRepositoryUrl } from '../../lib/shareUrls';
  import { getNsec } from '../../nostr';

  const openSourceCodeInNewTab = shouldOpenSourceCodeLinkInNewTab();
  const sourceCodeLinkTarget = openSourceCodeInNewTab ? '_blank' : '_self';
  const sourceCodeLinkRel = openSourceCodeInNewTab ? 'noopener noreferrer' : undefined;
  const hashtreeDevUrl = 'https://hashtree.cc/#/dev';
  const sourceCodeUrl = getCanonicalGitRepositoryUrl('iris-calendar');
  const localGatewayUrl = getLocalIrisDriveGatewayUrl();
  const caldavUrl = localGatewayUrl ? `${localGatewayUrl}/caldav/` : null;

  let nsec = $derived(getNsec());

  function getLocalIrisDriveGatewayUrl(): string | null {
    if (canUseInjectedHtreeServerUrl()) {
      const injected = getInjectedHtreeServerUrl();
      return injected ? normalizeRuntimeServerUrl(injected) : null;
    }
    return getSameOriginIrisGatewayServerUrl();
  }
</script>

<div class="space-y-6">
  <!-- Account (only show when logged in with nsec) -->
  {#if nsec}
    <div>
      <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
        Account
      </h3>
      <div class="bg-surface-2 rounded p-3">
        <CopyButton
          text={nsec}
          label="Copy secret key"
          copiedLabel="Copied"
          class="btn-ghost flex items-center gap-2 text-sm w-full justify-start"
          iconClass="i-lucide-key"
          copiedIconClass="i-lucide-check text-success"
          testId="copy-secret-key"
        />
      </div>
    </div>
  {/if}

  <div>
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
      Mac Calendar
    </h3>
    <div class="bg-surface-2 rounded p-3 text-sm space-y-3">
      <p class="text-text-2">
        Iris Drive exposes this private calendar to macOS and other CalDAV clients through the local gateway.
      </p>
      {#if caldavUrl}
        <CopyButton
          text={caldavUrl}
          label={caldavUrl}
          copiedLabel="Copied CalDAV URL"
          class="btn-ghost flex items-center gap-2 text-sm w-full justify-start font-mono"
          iconClass="i-lucide-calendar-sync"
          copiedIconClass="i-lucide-check text-success"
          testId="copy-caldav-url"
        />
      {:else}
        <div class="rounded bg-surface-1 p-3 text-xs text-text-2">
          Open Calendar through Iris Drive, or copy <span class="font-mono">browser_gateway.caldav_url</span> from <span class="font-mono">idrive status --json</span>.
        </div>
      {/if}
      <ol class="list-decimal space-y-1 pl-5 text-xs text-text-3">
        <li>Open macOS Calendar settings and add an Other CalDAV account.</li>
        <li>Choose Manual, paste the CalDAV URL, and use any local username and password.</li>
        <li>Keep Iris Drive running; edits sync both ways through your private calendar tree.</li>
      </ol>
    </div>
  </div>

  <!-- About -->
  <div>
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
      About
    </h3>
    <p class="text-sm text-text-2 mb-3">
      Built on
      <a
        href={hashtreeDevUrl}
        target="_blank"
        rel="noopener noreferrer"
        class="ml-1 no-underline text-text-1 hover:text-text-0"
      >
        hashtree
      </a>
    </p>
    <div class="bg-surface-2 rounded p-3 text-sm space-y-3">
      <div class="flex justify-between items-center">
        <span class="text-muted">Build</span>
        <span class="text-text-1 font-mono text-xs">
          {(() => {
            const buildTime = import.meta.env.VITE_BUILD_TIME;
            if (!buildTime || buildTime === 'undefined') return 'development';
            try {
              return new Date(buildTime).toLocaleString();
            } catch {
              return buildTime;
            }
          })()}
        </span>
      </div>
      <a
        href={sourceCodeUrl}
        target={sourceCodeLinkTarget}
        rel={sourceCodeLinkRel}
        class="btn-ghost w-full flex items-center justify-center gap-2 no-underline"
      >
        <span class="i-lucide-code text-sm"></span>
        <span>iris-calendar</span>
        <span class="text-text-3 text-xs no-underline">(source code)</span>
      </a>
      <button
        onclick={() => window.location.reload()}
        class="btn-ghost w-full flex items-center justify-center gap-2"
      >
        <span class="i-lucide-refresh-cw text-sm"></span>
        <span>Refresh App</span>
      </button>
    </div>
  </div>
</div>
