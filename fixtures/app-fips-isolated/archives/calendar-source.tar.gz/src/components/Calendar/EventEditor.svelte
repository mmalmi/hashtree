<script lang="ts">
  import { tick } from 'svelte';
  import CalendarDateField from './CalendarDateField.svelte';
  import Modal from '../ui/Modal.svelte';
  import type { CalendarColor, CalendarEvent, CalendarRecurrenceFrequency, EventDraft } from '../../lib/calendar';
  import { makeEventDraft, toDateInputValue, toDateTimeInputValue } from '../../lib/calendar';

  interface Props {
    open: boolean;
    event?: CalendarEvent | null;
    selectedDate: Date;
    startOfWeek?: 'monday' | 'sunday';
    onClose: () => void;
    onSave: (draft: EventDraft) => void;
    onDelete: (eventId: string) => void;
  }

  const colors: CalendarColor[] = ['violet', 'green', 'blue', 'amber', 'rose', 'slate'];
  const recurrenceOptions: Array<{ value: 'none' | CalendarRecurrenceFrequency; label: string }> = [
    { value: 'none', label: 'Never' },
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
    { value: 'yearly', label: 'Yearly' },
  ];
  const TIME_INPUT_PATTERN = '[0-9]{1,2}:[0-9]{2}';

  let { open, event = null, selectedDate, startOfWeek = 'monday', onClose, onSave, onDelete }: Props = $props();
  let draft = $state<EventDraft>(makeEventDraft());
  let editingId = $state<string | null>(null);
  let titleInput = $state<HTMLInputElement | null>(null);
  let confirmingDelete = $state(false);
  let lastTimedStartTime = $state('09:00');
  let lastTimedEndTime = $state('09:30');
  let repeatMenuOpen = $state(false);
  let repeatLabel = $derived(recurrenceOptions.find(option => option.value === (draft.recurrence?.frequency ?? 'none'))?.label ?? 'Never');
  let repeatUnitLabel = $derived(recurrenceUnitLabel(draft.recurrence?.frequency, draft.recurrence?.interval ?? 1));

  $effect(() => {
    if (!open) return;
    confirmingDelete = false;
    repeatMenuOpen = false;
    if (event) {
      editingId = event.id;
      const nextDraft = {
        id: event.id,
        title: event.title,
        start: event.allDay ? toDateInputValue(new Date(event.start)) : toDateTimeInputValue(new Date(event.start)),
        end: event.allDay ? allDayEndInputValue(event) : toDateTimeInputValue(new Date(event.end)),
        allDay: event.allDay,
        color: event.color,
        location: event.location ?? '',
        notes: event.notes ?? '',
        recurrence: event.recurrence,
      };
      draft = nextDraft;
      lastTimedStartTime = timePart(nextDraft.start);
      lastTimedEndTime = timePart(nextDraft.end, '09:30');
      return;
    }
    editingId = null;
    const nextDraft = makeEventDraft(selectedDate);
    draft = nextDraft;
    lastTimedStartTime = timePart(nextDraft.start);
    lastTimedEndTime = timePart(nextDraft.end, '09:30');
  });

  $effect(() => {
    if (!open) return;

    void tick().then(() => {
      if (!open) return;
      titleInput?.focus({ preventScroll: true });
      titleInput?.select();
    });
  });

  function colorClass(color: CalendarColor): string {
    return ({
      violet: 'bg-accent',
      green: 'bg-success',
      blue: 'bg-sky-500',
      amber: 'bg-amber-500',
      rose: 'bg-rose-500',
      slate: 'bg-text-2',
    } as const)[color];
  }

  function addDays(date: Date, count: number): Date {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate() + count);
  }

  function allDayEndInputValue(calendarEvent: CalendarEvent): string {
    const start = new Date(calendarEvent.start);
    const end = new Date(calendarEvent.end);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return toDateInputValue(start);
    }

    const inclusiveEnd = addDays(new Date(end.getFullYear(), end.getMonth(), end.getDate()), -1);
    return inclusiveEnd >= new Date(start.getFullYear(), start.getMonth(), start.getDate())
      ? toDateInputValue(inclusiveEnd)
      : toDateInputValue(start);
  }

  function datePart(value: string): string {
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? toDateInputValue(selectedDate) : toDateInputValue(date);
  }

  function timePart(value: string, fallback = '09:00'): string {
    const direct = /^([01]\d|2[0-3]):[0-5]\d$/.exec(value);
    if (direct) return value;
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return fallback;

    const match = /T([01]\d|2[0-3]):([0-5]\d)/.exec(value);
    if (match) return `${match[1]}:${match[2]}`;

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return fallback;
    return `${date.getHours()}`.padStart(2, '0') + ':' + `${date.getMinutes()}`.padStart(2, '0');
  }

  function normalizeTimeInput(value: string): string | null {
    const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
    if (!match) return null;

    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (hours > 23 || minutes > 59) return null;
    return `${hours}`.padStart(2, '0') + ':' + `${minutes}`.padStart(2, '0');
  }

  function composeDateTime(dateValue: string, timeValue: string): string {
    return `${dateValue}T${timeValue}`;
  }

  function ensureTimedEndAfterStart() {
    const start = new Date(draft.start);
    const end = new Date(draft.end);
    if (Number.isNaN(start.getTime()) || (!Number.isNaN(end.getTime()) && end > start)) return;
    draft.end = toDateTimeInputValue(new Date(start.getTime() + 30 * 60 * 1000));
  }

  function setAllDay(checked: boolean) {
    if (checked && !draft.allDay) {
      lastTimedStartTime = timePart(draft.start);
      lastTimedEndTime = timePart(draft.end, '09:30');
    }

    draft.allDay = checked;
    if (checked) {
      draft.start = datePart(draft.start);
      draft.end = datePart(draft.end);
      if (draft.end < draft.start) draft.end = draft.start;
      return;
    }

    const startDate = datePart(draft.start);
    draft.start = composeDateTime(startDate, lastTimedStartTime);
    draft.end = composeDateTime(startDate, lastTimedEndTime);
    ensureTimedEndAfterStart();
  }

  function updateAllDayStart(value: string) {
    draft.start = value;
    if (draft.end < draft.start) draft.end = value;
  }

  function updateAllDayEnd(value: string) {
    draft.end = value < draft.start ? draft.start : value;
  }

  function updateTimedStartDate(value: string) {
    draft.start = composeDateTime(value, timePart(draft.start));
    ensureTimedEndAfterStart();
  }

  function updateTimedEndDate(value: string) {
    draft.end = composeDateTime(value, timePart(draft.end, '09:30'));
    ensureTimedEndAfterStart();
  }

  function updateTimedStartTime(value: string) {
    const time = normalizeTimeInput(value);
    if (!time) return;
    lastTimedStartTime = time;
    draft.start = composeDateTime(datePart(draft.start), time);
    ensureTimedEndAfterStart();
  }

  function updateTimedEndTime(value: string) {
    const time = normalizeTimeInput(value);
    if (!time) return;
    lastTimedEndTime = time;
    draft.end = composeDateTime(datePart(draft.end), time);
    ensureTimedEndAfterStart();
  }

  function setRecurrenceFrequency(value: 'none' | CalendarRecurrenceFrequency) {
    repeatMenuOpen = false;
    if (value === 'none') {
      draft.recurrence = undefined;
      return;
    }
    draft.recurrence = {
      frequency: value,
      interval: draft.recurrence?.interval ?? 1,
      until: draft.recurrence?.until,
    };
  }

  function updateRecurrenceInterval(value: string) {
    if (!draft.recurrence) return;
    const interval = Math.min(99, Math.max(1, Math.round(Number(value) || 1)));
    draft.recurrence = { ...draft.recurrence, interval };
  }

  function updateRecurrenceUntil(value: string) {
    if (!draft.recurrence) return;
    const safeValue = value && value < datePart(draft.start) ? datePart(draft.start) : value;
    draft.recurrence = { ...draft.recurrence, until: safeValue || undefined };
  }

  function handleRepeatMenuFocusout(event: FocusEvent) {
    const next = event.relatedTarget as Node | null;
    if (next && event.currentTarget instanceof HTMLElement && event.currentTarget.contains(next)) return;
    repeatMenuOpen = false;
  }

  function recurrenceUnitLabel(frequency?: CalendarRecurrenceFrequency, interval = 1): string {
    if (!frequency) return '';
    const labels = {
      daily: ['day', 'days'],
      weekly: ['week', 'weeks'],
      monthly: ['month', 'months'],
      yearly: ['year', 'years'],
    } as const;
    return labels[frequency][interval === 1 ? 0 : 1];
  }

  function handleDeleteClick() {
    if (!editingId) return;
    if (!confirmingDelete) {
      confirmingDelete = true;
      return;
    }
    onDelete(editingId);
  }

  function cancelDelete() {
    confirmingDelete = false;
  }

  function handleClose() {
    confirmingDelete = false;
    repeatMenuOpen = false;
    onClose();
  }
</script>

<Modal
  open={open}
  onClose={handleClose}
  label={editingId ? 'Edit Event' : 'New Event'}
  backdropClass="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-3"
  panelClass="event-quick-editor bg-surface-1 rounded-lg shadow-lg w-full max-w-xl mx-4 border border-surface-3 overflow-hidden"
>
  <div class="event-editor-bar">
    <button class="event-editor-close" onclick={handleClose} aria-label="Close event editor">
      <span class="i-lucide-x"></span>
    </button>
  </div>

  <div class="event-editor-body space-y-4">
    <input
      class="event-title-input"
      placeholder="Add title"
      bind:this={titleInput}
      bind:value={draft.title}
      data-testid="calendar-event-title-input"
    />

    <div class="event-type-tabs" role="tablist" aria-label="Calendar item type">
      <button type="button" class="event-type-tab event-type-tab-active" role="tab" aria-selected="true">Event</button>
      <button type="button" class="event-type-tab" role="tab" aria-selected="false" disabled>Task</button>
    </div>

    <div class="event-editor-row">
      <span class="i-lucide-clock event-row-icon"></span>
      <div class="min-w-0 flex-1 space-y-3">
        <label class="inline-flex w-fit cursor-pointer items-center gap-2 text-sm text-text-2">
          <input
            type="checkbox"
            checked={draft.allDay}
            onchange={(event) => setAllDay((event.currentTarget as HTMLInputElement).checked)}
          />
          All day
        </label>

        {#if draft.allDay}
          <CalendarDateField
            label="Starts"
            ariaLabel="Start date"
            value={draft.start}
            {startOfWeek}
            testId="calendar-event-start-date-input"
            onChange={updateAllDayStart}
          />
          <CalendarDateField
            label="Ends"
            ariaLabel="End date"
            value={draft.end}
            min={draft.start}
            {startOfWeek}
            testId="calendar-event-end-date-input"
            onChange={updateAllDayEnd}
          />
        {:else}
          <div class="grid grid-cols-[minmax(0,1fr)_6.5rem] items-end gap-2">
            <CalendarDateField
              label="Starts"
              ariaLabel="Start date"
              value={datePart(draft.start)}
              {startOfWeek}
              testId="calendar-event-start-date-input"
              onChange={updateTimedStartDate}
            />
            <label class="block">
              <input
                class="input w-full"
                type="text"
                inputmode="numeric"
                autocomplete="off"
                pattern={TIME_INPUT_PATTERN}
                placeholder="09:00"
                aria-label="Start time"
                data-testid="calendar-event-start-time-input"
                value={timePart(draft.start)}
                oninput={(event) => updateTimedStartTime((event.currentTarget as HTMLInputElement).value)}
                onblur={(event) => {
                  (event.currentTarget as HTMLInputElement).value = timePart(draft.start);
                }}
              />
            </label>
          </div>
          <div class="grid grid-cols-[minmax(0,1fr)_6.5rem] items-end gap-2">
            <CalendarDateField
              label="Ends"
              ariaLabel="End date"
              value={datePart(draft.end)}
              min={datePart(draft.start)}
              {startOfWeek}
              testId="calendar-event-end-date-input"
              onChange={updateTimedEndDate}
            />
            <label class="block">
              <input
                class="input w-full"
                type="text"
                inputmode="numeric"
                autocomplete="off"
                pattern={TIME_INPUT_PATTERN}
                placeholder="09:30"
                aria-label="End time"
                data-testid="calendar-event-end-time-input"
                value={timePart(draft.end, '09:30')}
                oninput={(event) => updateTimedEndTime((event.currentTarget as HTMLInputElement).value)}
                onblur={(event) => {
                  (event.currentTarget as HTMLInputElement).value = timePart(draft.end, '09:30');
                }}
              />
            </label>
          </div>
        {/if}
      </div>
    </div>

    <div class="event-editor-row">
      <span class="i-lucide-map-pin event-row-icon"></span>
      <input
        class="input min-w-0 flex-1"
        placeholder="Add location or video call"
        aria-label="Location"
        bind:value={draft.location}
        data-testid="calendar-event-location-input"
      />
    </div>

    <div class="event-editor-row items-start">
      <span class="i-lucide-repeat event-row-icon mt-7"></span>
      <div class="grid min-w-0 flex-1 grid-cols-1 gap-3 md:grid-cols-3">
      <div class="relative space-y-1" onfocusout={handleRepeatMenuFocusout}>
        <span class="block text-xs text-text-3">Repeat</span>
        <button
          type="button"
          class="input flex w-full items-center justify-between gap-2 text-left"
          aria-haspopup="menu"
          aria-expanded={repeatMenuOpen}
          aria-label="Repeat"
          data-testid="calendar-event-repeat-button"
          onclick={() => repeatMenuOpen = !repeatMenuOpen}
        >
          <span>{repeatLabel}</span>
          <span class="i-lucide-chevron-down text-text-3"></span>
        </button>
        {#if repeatMenuOpen}
          <div class="absolute z-60 mt-1 w-full rounded-lg border border-surface-3 bg-surface-1 p-1 shadow-lg" role="menu" aria-label="Repeat options">
            {#each recurrenceOptions as option (option.value)}
              <button
                type="button"
                class="flex min-h-9 w-full items-center justify-between rounded-md px-2.5 text-left text-sm font-medium {option.value === (draft.recurrence?.frequency ?? 'none') ? 'bg-accent/12 text-text-1' : 'text-text-2 hover:bg-surface-2'}"
                role="menuitemradio"
                aria-checked={option.value === (draft.recurrence?.frequency ?? 'none')}
                data-testid={`calendar-event-repeat-option-${option.value}`}
                onclick={() => setRecurrenceFrequency(option.value)}
              >
                <span>{option.label}</span>
                {#if option.value === (draft.recurrence?.frequency ?? 'none')}
                  <span class="i-lucide-check"></span>
                {/if}
              </button>
            {/each}
          </div>
        {/if}
      </div>
      {#if draft.recurrence}
        <div class="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-2">
          <label class="space-y-1">
            <span class="block text-xs text-text-3">Every</span>
            <input
              class="input w-full"
              type="number"
              min="1"
              max="99"
              inputmode="numeric"
              aria-label="Repeat interval"
              data-testid="calendar-event-repeat-interval-input"
              value={draft.recurrence.interval}
              oninput={(event) => updateRecurrenceInterval((event.currentTarget as HTMLInputElement).value)}
              onblur={(event) => {
                (event.currentTarget as HTMLInputElement).value = String(draft.recurrence?.interval ?? 1);
              }}
            />
          </label>
          <span class="pb-2 text-sm font-medium text-text-2">{repeatUnitLabel}</span>
        </div>
        <CalendarDateField
          label="Until"
          value={draft.recurrence.until ?? ''}
          min={datePart(draft.start)}
          {startOfWeek}
          allowEmpty
          placeholder="Never"
          testId="calendar-event-repeat-until-input"
          onChange={updateRecurrenceUntil}
        />
      {/if}
      </div>
    </div>

    <div class="event-editor-row items-start">
      <span class="i-lucide-palette event-row-icon mt-1"></span>
      <div class="min-w-0 flex-1 space-y-2 pb-1">
      <div class="block text-xs text-text-3">Color</div>
      <div class="flex min-h-11 flex-wrap items-center gap-2 px-1">
        {#each colors as color (color)}
          <button
            type="button"
            class="h-7 w-7 shrink-0 rounded-full {colorClass(color)} {draft.color === color ? 'ring-2 ring-white ring-offset-2 ring-offset-surface-1' : ''}"
            aria-label={`Use ${color} color`}
            aria-pressed={draft.color === color}
            onclick={() => draft.color = color}
          ></button>
        {/each}
      </div>
      </div>
    </div>

    <label class="event-editor-row items-start">
      <span class="i-lucide-align-left event-row-icon mt-7"></span>
      <span class="min-w-0 flex-1 space-y-1">
      <span class="block text-xs text-text-3">Notes</span>
      <textarea class="textarea w-full min-h-24" placeholder="Notes" bind:value={draft.notes}></textarea>
      </span>
    </label>

  <div class="event-editor-footer flex items-center justify-between gap-2">
    <div>
      {#if editingId}
        <div class="flex items-center gap-2">
          <button class={confirmingDelete ? 'btn-danger' : 'btn-ghost'} onclick={handleDeleteClick} aria-label={confirmingDelete ? 'Confirm delete event' : 'Delete event'}>
            {confirmingDelete ? 'Confirm delete' : 'Delete'}
          </button>
          {#if confirmingDelete}
            <button class="btn-ghost" onclick={cancelDelete} aria-label="Keep event">
              Keep event
            </button>
          {/if}
        </div>
      {/if}
    </div>
    <div class="flex items-center gap-2">
      <button class="btn-ghost" onclick={handleClose}>Cancel</button>
      <button class="btn-success" disabled={!draft.title.trim()} onclick={() => onSave(draft)} data-testid="calendar-event-save">
        Save
      </button>
    </div>
  </div>
  </div>
</Modal>

<style>
  .event-editor-bar {
    min-height: 2.35rem;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0.45rem 0.7rem;
    background: rgb(var(--surface-2));
  }

  .event-editor-close {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: rgb(var(--text-2));
  }

  .event-editor-close:hover {
    background: rgb(var(--surface-3) / 0.7);
    color: rgb(var(--text-1));
  }

  .event-editor-body {
    padding: 1.15rem 1.35rem 1.1rem;
    max-height: min(78dvh, 44rem);
    overflow-y: auto;
  }

  .event-title-input {
    width: 100%;
    min-height: 3.1rem;
    border: 0;
    border-bottom: 2px solid rgb(145 109 254 / 0.72);
    background: transparent;
    color: rgb(var(--text-1));
    font-size: clamp(1.35rem, 4vw, 1.85rem);
    outline: none;
  }

  .event-title-input::placeholder {
    color: rgb(var(--text-3));
  }

  .event-type-tabs {
    display: flex;
    flex-wrap: wrap;
    gap: 0.45rem;
  }

  .event-type-tab {
    min-height: 2.15rem;
    border-radius: 8px;
    padding: 0 0.75rem;
    color: rgb(var(--text-2));
    font-size: 0.86rem;
    font-weight: 650;
  }

  .event-type-tab-active {
    background: rgb(145 109 254 / 0.22);
    color: rgb(var(--text-1));
  }

  .event-editor-row {
    display: flex;
    gap: 1rem;
    align-items: center;
    min-width: 0;
  }

  .event-row-icon {
    width: 1.25rem;
    color: rgb(var(--text-3));
    flex: 0 0 auto;
  }

  .event-editor-footer {
    border-top: 1px solid rgb(var(--surface-3) / 0.72);
    padding-top: 1rem;
  }
</style>
