<script lang="ts">
  import type { CalendarData } from '../../lib/calendar';
  import { eventsForDay, monthMatrix, toDateInputValue, WEEKDAY_LABELS } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    monthDate: Date;
    selectedDate: Date;
    onSelectDate: (date: Date) => void;
    onPreviousMonth?: () => void;
    onNextMonth?: () => void;
  }

  let { data, monthDate, selectedDate, onSelectDate, onPreviousMonth, onNextMonth }: Props = $props();

  let days = $derived(monthMatrix(monthDate, data.startOfWeek));
  let weekdayLabels = $derived(data.startOfWeek === 'monday'
    ? [...WEEKDAY_LABELS.slice(1), WEEKDAY_LABELS[0]]
    : WEEKDAY_LABELS);

  function sameDay(a: Date, b: Date): boolean {
    return toDateInputValue(a) === toDateInputValue(b);
  }

  function isAvailable(day: Date): boolean {
    return data.availability.rules.some(rule => rule.weekday === day.getDay() && rule.enabled);
  }
</script>

<section class="calendar-panel p-4 space-y-3">
  <div class="mini-month-head">
    <button class="mini-month-nav" onclick={onPreviousMonth} aria-label="Previous month" title="Previous month">
      <span class="i-lucide-chevron-left"></span>
    </button>
    <div class="truncate text-sm font-semibold text-text-1">
      {new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(monthDate)}
    </div>
    <button class="mini-month-nav" onclick={onNextMonth} aria-label="Next month" title="Next month">
      <span class="i-lucide-chevron-right"></span>
    </button>
  </div>

  <div class="grid grid-cols-7 gap-1 text-center">
    {#each weekdayLabels as label, index (index)}
      <div class="h-6 text-[10px] font-medium uppercase text-text-3 flex items-center justify-center">
        {label.slice(0, 1)}
      </div>
    {/each}
    {#each days as day (toDateInputValue(day))}
      {@const currentMonth = day.getMonth() === monthDate.getMonth()}
      {@const selected = sameDay(day, selectedDate)}
      {@const today = sameDay(day, new Date())}
      {@const eventCount = eventsForDay(data.events, day).length}
      <button
        type="button"
        class="mini-day {selected ? 'mini-day-selected' : ''} {today ? 'mini-day-today' : ''} {currentMonth ? 'text-text-2' : 'text-text-3/60'} {!isAvailable(day) ? 'mini-day-muted' : ''}"
        aria-pressed={selected}
        onclick={() => onSelectDate(new Date(day))}
      >
        <span>{day.getDate()}</span>
        {#if eventCount > 0}
          <i aria-hidden="true"></i>
        {/if}
      </button>
    {/each}
  </div>
</section>

<style>
  .mini-month-head {
    display: grid;
    grid-template-columns: 2rem minmax(0, 1fr) 2rem;
    align-items: center;
    gap: 0.35rem;
    text-align: center;
  }

  .mini-month-nav {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    transition: background-color 120ms ease, color 120ms ease, opacity 120ms ease;
  }

  .mini-month-nav:hover:not(:disabled) {
    background: rgb(var(--surface-3));
  }

  .mini-month-nav:disabled {
    opacity: 0.5;
    cursor: default;
  }

  .mini-day {
    position: relative;
    height: 2rem;
    border-radius: 999px;
    font-size: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 120ms ease, color 120ms ease, box-shadow 120ms ease;
  }

  .mini-day:hover {
    background: rgb(var(--surface-2) / 0.72);
    color: rgb(var(--text-1));
  }

  .mini-day-selected {
    background: rgb(145 109 254 / 0.18);
    color: #916dfe;
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.45);
  }

  .mini-day-today:not(.mini-day-selected) {
    color: #916dfe;
    font-weight: 700;
  }

  .mini-day-muted {
    background-image: repeating-linear-gradient(
      135deg,
      rgb(var(--surface-2) / 0.22) 0,
      rgb(var(--surface-2) / 0.22) 1px,
      transparent 1px,
      transparent 6px
    );
  }

  .mini-day i {
    position: absolute;
    width: 4px;
    height: 4px;
    border-radius: 999px;
    bottom: 4px;
    background: currentColor;
  }
</style>
