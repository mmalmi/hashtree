<script lang="ts">
  import Modal from '../ui/Modal.svelte';
  import PeopleField from './PeopleField.svelte';

  interface Props {
    people: string[];
    onChange: (people: string[]) => void;
    onClose: () => void;
  }

  let { people, onChange, onClose }: Props = $props();
</script>

<Modal open {onClose} label="Share calendar" panelClass="bg-surface-1 rounded-lg shadow-lg w-full max-w-md mx-4 border border-surface-3">
  <div class="space-y-4 p-5" data-testid="share-calendar-dialog">
    <div class="flex items-start justify-between gap-3">
      <div>
        <h2 class="text-lg font-semibold text-text-1">Share my calendar</h2>
        <p class="mt-1 text-sm text-text-2">People you add see your events, encrypted for them. Removing someone changes the key, so they stop seeing updates.</p>
      </div>
      <button class="btn-circle bg-surface-2 hover:bg-surface-3 shrink-0" onclick={onClose} aria-label="Close">
        <span class="i-lucide-x"></span>
      </button>
    </div>
    <PeopleField {people} label="People with access" {onChange} />
  </div>
</Modal>
