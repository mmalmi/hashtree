<script lang="ts">
  import type { BookingLink, CalendarData, CalendarEvent } from '../../lib/calendar';
  import { dayLabel, eventToneClass, formatTime, updateAvailability } from '../../lib/calendar';
  import AvailabilityPanel from './AvailabilityPanel.svelte';
  import BookingLinksPanel from './BookingLinksPanel.svelte';
  import CalendarListPanel from './CalendarListPanel.svelte';
  import MiniMonth from './MiniMonth.svelte';

  interface Props {
    data: CalendarData;
    viewData: CalendarData;
    monthDate: Date;
    selectedDate: Date;
    selectedDayEvents: CalendarEvent[];
    invitations: CalendarEvent[];
    shared: Record<string, CalendarData | null>;
    onSelectDate: (date: Date) => void;
    onPreviousMonth: () => void;
    onNextMonth: () => void;
    onNewEvent: () => void;
    onOpenEvent: (event: CalendarEvent) => void;
    onShare: () => void;
    onCopyBookingLink: (link: BookingLink) => void;
    onAddBookingLink: () => void;
    onRemoveBookingLink: (linkId: string) => void;
    onChange: (data: CalendarData) => void;
    onImport: (file: File) => void;
    onExport: () => void;
  }

  let {
    data, viewData, monthDate, selectedDate, selectedDayEvents, invitations, shared,
    onSelectDate, onPreviousMonth, onNextMonth, onNewEvent, onOpenEvent, onShare,
    onCopyBookingLink, onAddBookingLink, onRemoveBookingLink, onChange, onImport, onExport,
  }: Props = $props();

  let bookingOpen = $state(false);
  let createMenuOpen = $state(false);
  let enabledLinkCount = $derived(data.bookingLinks.filter(link => link.enabled).length);
  let availability = $derived.by(() => {
    const rule = data.availability.rules.find(item => item.weekday === selectedDate.getDay());
    return rule?.enabled ? `${rule.startTime} - ${rule.endTime}` : 'Unavailable';
  });

  function addBookingLink(event?: MouseEvent) {
    event?.preventDefault();
    event?.stopPropagation();
    createMenuOpen = false;
    bookingOpen = true;
    onAddBookingLink();
  }

  function handleCreateMenuFocusout(event: FocusEvent) {
    const next = event.relatedTarget as Node | null;
    if (next && event.currentTarget instanceof HTMLElement && event.currentTarget.contains(next)) return;
    createMenuOpen = false;
  }
</script>

<aside class="calendar-sidebar space-y-3">
  <div class="create-menu" onfocusout={handleCreateMenuFocusout}>
    <button
      class="create-button"
      aria-haspopup="menu"
      aria-expanded={createMenuOpen}
      onclick={() => createMenuOpen = !createMenuOpen}
      data-testid="calendar-sidebar-create-button"
    >
      <span class="create-button-icon i-lucide-plus"></span>
      <span>Create</span>
      <span class="i-lucide-chevron-down ml-auto text-sm text-text-3"></span>
    </button>
    {#if createMenuOpen}
      <div class="create-menu-list" role="menu" aria-label="Create calendar item">
        <button class="create-menu-item create-menu-item-active" role="menuitem" onclick={() => { createMenuOpen = false; onNewEvent(); }}>
          <span class="i-lucide-calendar-plus"></span>
          <span>Event</span>
        </button>
        <button class="create-menu-item" role="menuitem" onclick={() => addBookingLink()}>
          <span class="i-lucide-calendar-clock"></span>
          <span>Appointment booking</span>
        </button>
      </div>
    {/if}
  </div>

  <MiniMonth data={viewData} {monthDate} {selectedDate} {onSelectDate} {onPreviousMonth} {onNextMonth} />

  <CalendarListPanel {data} {viewData} {invitations} {shared} {onOpenEvent} {onShare} {onCopyBookingLink} {onChange} {onImport} {onExport} />

  <details class="calendar-disclosure calendar-panel" open>
    <summary>
      <span>
        <strong>{dayLabel(selectedDate)}</strong>
        <small>{availability}</small>
      </span>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body space-y-3">
      {#if selectedDayEvents.length === 0}
        <div class="day-empty">
          <span class="i-lucide-calendar text-lg"></span>
          <span>No events.</span>
        </div>
      {:else}
        <div class="space-y-2">
          {#each selectedDayEvents as event (event.id)}
            <button class="day-event w-full border-l-3 p-3 text-left {eventToneClass(event)}" onclick={() => onOpenEvent(event)}>
              <div class="flex min-w-0 items-center gap-1.5 text-sm">
                <span class="i-lucide-clock shrink-0 text-xs text-text-3"></span>
                <span class="shrink-0 text-xs text-text-3">{event.allDay ? 'All day' : formatTime(event.start, data.timeFormat)}</span>
                <span class="truncate font-medium text-text-1">{event.title}</span>
              </div>
              {#if event.location}
                <div class="mt-1 flex items-center gap-1 truncate text-xs text-text-3">
                  <span class="i-lucide-map-pin shrink-0"></span>
                  <span class="truncate">{event.location}</span>
                </div>
              {/if}
            </button>
          {/each}
        </div>
      {/if}
    </div>
  </details>

  <details class="calendar-disclosure calendar-panel">
    <summary>
      <span>
        <strong>Availability</strong>
        <small>{data.availability.timezone}</small>
      </span>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body">
      <AvailabilityPanel
        availability={data.availability}
        onChange={value => onChange(updateAvailability(data, value, data.ownerNpub))}
        embedded
      />
    </div>
  </details>

  <details class="calendar-disclosure calendar-panel" bind:open={bookingOpen}>
    <summary>
      <span>
        <strong>Booking</strong>
        <small>{enabledLinkCount === 1 ? '1 link' : `${enabledLinkCount} links`}</small>
      </span>
      <button class="summary-action" onclick={addBookingLink} aria-label="New booking link" title="New booking link">
        <span class="i-lucide-plus"></span>
      </button>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body">
      <BookingLinksPanel
        {data}
        {selectedDate}
        onRemove={onRemoveBookingLink}
        onCopy={onCopyBookingLink}
        {onChange}
      />
    </div>
  </details>
</aside>

<style>
  .calendar-sidebar { grid-area: sidebar; min-width: 0; }
  .create-menu { position: relative; width: min(10.8rem, 100%); }

  .create-button {
    box-sizing: border-box;
    height: 3.15rem;
    min-height: 3.15rem;
    width: 100%;
    border: 1px solid rgb(var(--surface-3) / 0.72);
    border-radius: 999px;
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
    display: inline-flex;
    align-items: center;
    justify-content: flex-start;
    gap: 0.75rem;
    padding: 0 1.15rem;
    font-size: 0.92rem;
    font-weight: 700;
    transition: background-color 120ms ease, border-color 120ms ease;
  }

  .create-button:hover {
    background: rgb(var(--surface-2));
    border-color: rgb(var(--surface-3));
  }

  .create-button-icon { font-size: 1.25rem; color: #916dfe; }

  .create-menu-list {
    position: absolute;
    z-index: 35;
    top: calc(100% + 0.55rem);
    left: 0;
    width: min(15.2rem, calc(100vw - 2rem));
    border: 1px solid rgb(var(--surface-3) / 0.78);
    border-radius: 8px;
    background: rgb(var(--surface-1));
    padding: 0.35rem;
    box-shadow: 0 1.1rem 2.6rem rgb(0 0 0 / 0.34);
  }

  .create-menu-item {
    min-height: 2.55rem;
    width: 100%;
    border-radius: 6px;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.35rem 0.65rem;
    color: rgb(var(--text-2));
    font-size: 0.875rem;
    font-weight: 600;
    text-align: left;
  }

  .create-menu-item:hover,
  .create-menu-item:focus-visible,
  .create-menu-item-active {
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    outline: none;
  }

  .calendar-disclosure { overflow: hidden; }

  .calendar-disclosure summary {
    list-style: none;
    min-height: 3.25rem;
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto auto;
    align-items: center;
    gap: 0.5rem;
    padding: 0.85rem 1rem;
    cursor: pointer;
  }

  .calendar-disclosure summary::-webkit-details-marker { display: none; }

  .calendar-disclosure summary strong,
  .calendar-disclosure summary small {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .calendar-disclosure summary strong {
    color: rgb(var(--text-1));
    font-size: 0.875rem;
    font-weight: 650;
  }

  .calendar-disclosure summary small {
    margin-top: 0.15rem;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
  }

  .calendar-disclosure-body {
    border-top: 1px solid rgb(var(--surface-3) / 0.72);
    padding: 1rem;
  }

  .disclosure-icon { color: rgb(var(--text-3)); transition: transform 120ms ease; }
  .calendar-disclosure[open] .disclosure-icon { transform: rotate(180deg); }

  .summary-action {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    transition: background-color 120ms ease;
  }

  .summary-action:hover { background: rgb(var(--surface-3)); }

  .day-event {
    border-radius: 8px;
    border-top: 1px solid rgb(var(--surface-3) / 0.7);
    border-right: 1px solid rgb(var(--surface-3) / 0.7);
    border-bottom: 1px solid rgb(var(--surface-3) / 0.7);
    transition: background-color 120ms ease, transform 120ms ease, border-color 120ms ease;
  }

  .day-event:hover { border-color: rgb(var(--surface-3)); transform: translateY(-1px); }

  .day-empty {
    min-height: 4rem;
    border: 1px dashed rgb(var(--surface-3));
    border-radius: 8px;
    color: rgb(var(--text-3));
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-size: 0.875rem;
  }

  @media (min-width: 1100px) {
    .calendar-sidebar {
      position: sticky;
      top: 4.65rem;
      align-self: start;
      max-height: calc(100dvh - 5rem);
      overflow-y: auto;
      padding-right: 0.1rem;
      scrollbar-width: thin;
    }
  }
</style>
