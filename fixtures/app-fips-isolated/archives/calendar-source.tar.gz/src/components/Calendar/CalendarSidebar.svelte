<script lang="ts">
  import type {
    AvailabilitySettings,
    BookingLink,
    CalendarData,
    CalendarEvent,
    CalendarTimeFormat,
  } from '../../lib/calendar';
  import {
    dayLabel,
    eventToneClass,
    formatTime,
    shortMonthLabel,
  } from '../../lib/calendar';
  import AvailabilityPanel from './AvailabilityPanel.svelte';
  import BookingLinksPanel from './BookingLinksPanel.svelte';
  import MiniMonth from './MiniMonth.svelte';

  interface Props {
    data: CalendarData;
    monthDate: Date;
    selectedDate: Date;
    selectedDayEvents: CalendarEvent[];
    totalEvents: number;
    enabledBookingLinks: BookingLink[];
    firstBookingLink: BookingLink | null;
    actor: string;
    availabilityText: string;
    onSelectDate: (date: Date) => void;
    onPreviousMonth: () => void;
    onNextMonth: () => void;
    onNewEvent: () => void;
    onCopyPrimaryBookingLink: () => void;
    onToday: () => void;
    onEditEvent: (event: CalendarEvent) => void;
    onAvailabilityChange: (availability: AvailabilitySettings) => void;
    onAddBookingLink: () => void;
    onRemoveBookingLink: (linkId: string) => void;
    onBookingDataChange: (data: CalendarData) => void;
  }

  let {
    data,
    monthDate,
    selectedDate,
    selectedDayEvents,
    totalEvents,
    enabledBookingLinks,
    firstBookingLink,
    actor,
    availabilityText,
    onSelectDate,
    onPreviousMonth,
    onNextMonth,
    onNewEvent,
    onCopyPrimaryBookingLink,
    onToday,
    onEditEvent,
    onAvailabilityChange,
    onAddBookingLink,
    onRemoveBookingLink,
    onBookingDataChange,
  }: Props = $props();

  let bookingOpen = $state(false);
  let createMenuOpen = $state(false);
  let calendarSearch = $state('');
  const timeFormatOptions: Array<{ value: CalendarTimeFormat; label: string }> = [
    { value: 'auto', label: 'Auto' },
    { value: '24h', label: '24h' },
    { value: '12h', label: '12h' },
  ];
  let searchResults = $derived(calendarSearch.trim().length === 0
    ? []
    : data.events
        .filter(event => {
          const query = calendarSearch.trim().toLowerCase();
          return [event.title, event.location, event.notes]
            .some(value => value?.toLowerCase().includes(query));
        })
        .slice(0, 5));

  function addBookingLinkFromSummary(event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    bookingOpen = true;
    onAddBookingLink();
  }

  function openEventFromCreateMenu() {
    createMenuOpen = false;
    onNewEvent();
  }

  function openBookingFromCreateMenu() {
    createMenuOpen = false;
    bookingOpen = true;
    onAddBookingLink();
  }

  function handleCreateMenuFocusout(event: FocusEvent) {
    const next = event.relatedTarget as Node | null;
    if (next && event.currentTarget instanceof HTMLElement && event.currentTarget.contains(next)) return;
    createMenuOpen = false;
  }

  function eventStartLabel(event: CalendarEvent): string {
    return event.allDay ? 'All day' : formatTime(event.start, data.timeFormat);
  }

  function eventDateLabel(event: CalendarEvent): string {
    return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(new Date(event.start));
  }

  function setTimeFormat(timeFormat: CalendarTimeFormat) {
    if (data.timeFormat === timeFormat) return;
    onBookingDataChange({ ...data, timeFormat });
  }
</script>

<aside class="calendar-sidebar space-y-3">
  <div class="create-menu" onfocusout={handleCreateMenuFocusout}>
    <button
      class="create-button"
      aria-haspopup="menu"
      aria-expanded={createMenuOpen}
      onclick={() => createMenuOpen = !createMenuOpen}
      data-testid="calendar-sidebar-create-button"
    >
      <span class="create-button-icon i-lucide-plus"></span>
      <span>Create</span>
      <span class="i-lucide-chevron-down ml-auto text-sm text-text-3"></span>
    </button>
    {#if createMenuOpen}
      <div class="create-menu-list" role="menu" aria-label="Create calendar item">
        <button class="create-menu-item create-menu-item-active" role="menuitem" onclick={openEventFromCreateMenu}>
          <span class="i-lucide-calendar-plus"></span>
          <span>Event</span>
        </button>
        <button class="create-menu-item" role="menuitem" onclick={openBookingFromCreateMenu}>
          <span class="i-lucide-calendar-clock"></span>
          <span>Appointment booking</span>
        </button>
      </div>
    {/if}
  </div>

  <MiniMonth
    {data}
    {monthDate}
    {selectedDate}
    onSelectDate={onSelectDate}
    {onPreviousMonth}
    {onNextMonth}
  />

  <section class="calendar-panel calendar-list-panel">
    <label class="calendar-search">
      <span class="i-lucide-search"></span>
      <input bind:value={calendarSearch} placeholder="Search calendar" aria-label="Search calendar" />
    </label>

    <div class="calendar-list-block">
      <div class="calendar-list-title">{shortMonthLabel(monthDate)}</div>
      <button class="calendar-list-row" type="button" onclick={onToday}>
        <span class="calendar-list-dot calendar-list-dot-primary"></span>
        <span class="calendar-list-copy">
          <strong>My calendar</strong>
          <small>{totalEvents === 1 ? '1 event' : `${totalEvents} events`}</small>
        </span>
      </button>
      <button class="calendar-list-row" type="button" onclick={onCopyPrimaryBookingLink} disabled={!firstBookingLink}>
        <span class="calendar-list-dot calendar-list-dot-booking"></span>
        <span class="calendar-list-copy">
          <strong>Bookable pages</strong>
          <small>{enabledBookingLinks.length === 1 ? '1 link' : `${enabledBookingLinks.length} links`}</small>
        </span>
        <span class="i-lucide-copy calendar-list-action"></span>
      </button>
    </div>

    {#if searchResults.length > 0}
      <div class="calendar-list-block">
        <div class="calendar-list-title">Results</div>
        {#each searchResults as event (event.id)}
          <button class="calendar-list-row" type="button" onclick={() => onEditEvent(event)}>
            <span class="calendar-list-dot calendar-list-dot-{event.color}"></span>
            <span class="calendar-list-copy">
              <strong>{event.title}</strong>
              <small>{eventDateLabel(event)} · {eventStartLabel(event)}</small>
            </span>
          </button>
        {/each}
      </div>
    {/if}

    <div class="time-format-row">
      <span>Time</span>
      <div class="time-format-control" aria-label="Time format">
        {#each timeFormatOptions as option (option.value)}
          <button
            type="button"
            class:time-format-active={data.timeFormat === option.value}
            aria-pressed={data.timeFormat === option.value}
            onclick={() => setTimeFormat(option.value)}
          >
            {option.label}
          </button>
        {/each}
      </div>
    </div>
  </section>

  <details class="calendar-disclosure calendar-panel" open>
    <summary>
      <span>
        <strong>{dayLabel(selectedDate)}</strong>
        <small>{availabilityText}</small>
      </span>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body space-y-3">
      {#if selectedDayEvents.length === 0}
        <div class="day-empty">
          <span class="i-lucide-calendar text-lg"></span>
          <span>No events.</span>
        </div>
      {:else}
        <div class="space-y-2">
          {#each selectedDayEvents as event (event.id)}
            <button class="day-event w-full border-l-3 p-3 text-left {eventToneClass(event.color)}" onclick={() => onEditEvent(event)}>
              <div class="flex min-w-0 items-center gap-1.5 text-sm">
                <span class="i-lucide-clock shrink-0 text-xs text-text-3"></span>
                <span class="shrink-0 text-xs text-text-3">{eventStartLabel(event)}</span>
                <span class="truncate font-medium text-text-1">{event.title}</span>
              </div>
              {#if event.location}
                <div class="mt-1 flex items-center gap-1 truncate text-xs text-text-3">
                  <span class="i-lucide-map-pin shrink-0"></span>
                  <span class="truncate">{event.location}</span>
                </div>
              {/if}
            </button>
          {/each}
        </div>
      {/if}
    </div>
  </details>

  <details class="calendar-disclosure calendar-panel">
    <summary>
      <span>
        <strong>Availability</strong>
        <small>{data.availability.timezone}</small>
      </span>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body">
      <AvailabilityPanel availability={data.availability} onChange={onAvailabilityChange} embedded />
    </div>
  </details>

  <details class="calendar-disclosure calendar-panel" bind:open={bookingOpen}>
    <summary>
      <span>
        <strong>Booking</strong>
        <small>{enabledBookingLinks.length === 1 ? '1 link' : `${enabledBookingLinks.length} links`}</small>
      </span>
      <button class="summary-action" onclick={addBookingLinkFromSummary} aria-label="New booking link" title="New booking link">
        <span class="i-lucide-plus"></span>
      </button>
      <span class="i-lucide-chevron-down disclosure-icon"></span>
    </summary>
    <div class="calendar-disclosure-body">
      <BookingLinksPanel
        {data}
        {selectedDate}
        {actor}
        onAdd={onAddBookingLink}
        onRemove={onRemoveBookingLink}
        onChange={onBookingDataChange}
        embedded
        showHeader={false}
      />
    </div>
  </details>
</aside>

<style>
  .calendar-sidebar { grid-area: sidebar; min-width: 0; }
  .create-menu { position: relative; width: min(10.8rem, 100%); }

  .create-button {
    box-sizing: border-box;
    height: 3.15rem;
    min-height: 3.15rem;
    width: 100%;
    border: 1px solid rgb(var(--surface-3) / 0.72);
    border-radius: 999px;
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
    display: inline-flex;
    align-items: center;
    justify-content: flex-start;
    gap: 0.75rem;
    padding: 0 1.15rem;
    font-size: 0.92rem;
    font-weight: 700;
    transition: background-color 120ms ease, border-color 120ms ease;
  }

  .create-button:hover {
    background: rgb(var(--surface-2));
    border-color: rgb(var(--surface-3));
  }

  .create-button-icon { font-size: 1.25rem; color: #916dfe; }

  .create-menu-list {
    position: absolute;
    z-index: 35;
    top: calc(100% + 0.55rem);
    left: 0;
    width: min(15.2rem, calc(100vw - 2rem));
    border: 1px solid rgb(var(--surface-3) / 0.78);
    border-radius: 8px;
    background: rgb(var(--surface-1));
    padding: 0.35rem;
    box-shadow: 0 1.1rem 2.6rem rgb(0 0 0 / 0.34);
  }

  .create-menu-item {
    min-height: 2.55rem;
    width: 100%;
    border-radius: 6px;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.35rem 0.65rem;
    color: rgb(var(--text-2));
    font-size: 0.875rem;
    font-weight: 600;
    text-align: left;
  }

  .create-menu-item:hover,
  .create-menu-item:focus-visible,
  .create-menu-item-active {
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    outline: none;
  }

  .calendar-list-panel { padding: 0.75rem; display: grid; gap: 0.75rem; }

  .calendar-search {
    min-height: 2.45rem;
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-3));
    display: flex;
    align-items: center;
    gap: 0.55rem;
    padding: 0 0.8rem;
  }

  .calendar-search input {
    min-width: 0;
    flex: 1;
    border: 0;
    outline: 0;
    background: transparent;
    color: rgb(var(--text-1));
    font-size: 0.84rem;
  }

  .calendar-search input::placeholder { color: rgb(var(--text-3)); }
  .calendar-list-block { display: grid; gap: 0.18rem; }

  .calendar-list-title {
    padding: 0 0.5rem;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
  }

  .calendar-list-row {
    min-height: 2.7rem;
    border-radius: 8px;
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    align-items: center;
    gap: 0.65rem;
    padding: 0.35rem 0.5rem;
    color: rgb(var(--text-1));
    text-align: left;
  }

  .calendar-list-row:hover:not(:disabled),
  .calendar-list-row:focus-visible {
    background: rgb(var(--surface-2));
    outline: none;
  }

  .calendar-list-row:disabled { opacity: 0.58; cursor: default; }

  .calendar-list-dot {
    width: 0.8rem;
    height: 0.8rem;
    border-radius: 3px;
    background: currentColor;
  }

  .calendar-list-dot-primary { background: #916dfe; }
  .calendar-list-dot-booking { background: rgb(var(--success)); }

  .calendar-list-dot-violet { background: #916dfe; }
  .calendar-list-dot-green { background: rgb(var(--success)); }
  .calendar-list-dot-blue { background: rgb(14 165 233); }
  .calendar-list-dot-amber { background: rgb(245 158 11); }
  .calendar-list-dot-rose { background: rgb(244 63 94); }
  .calendar-list-dot-slate { background: rgb(var(--text-3)); }

  .calendar-list-copy { min-width: 0; }

  .calendar-list-copy strong,
  .calendar-list-copy small {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .calendar-list-copy strong {
    font-size: 0.86rem;
    font-weight: 650;
  }

  .calendar-list-copy small {
    margin-top: 0.08rem;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
  }

  .calendar-list-action { color: rgb(var(--text-3)); font-size: 0.9rem; }

  .time-format-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    color: rgb(var(--text-3));
    font-size: 0.75rem;
    font-weight: 650;
    text-transform: uppercase;
  }

  .time-format-control {
    display: inline-grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    overflow: hidden;
    border-radius: 999px;
    background: rgb(var(--surface-2));
    padding: 0.18rem;
    text-transform: none;
  }

  .time-format-control button {
    min-width: 2.6rem;
    border-radius: 999px;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
    font-weight: 700;
    padding: 0.28rem 0.45rem;
  }

  .time-format-control button:hover,
  .time-format-active {
    background: rgb(var(--surface-0));
    color: rgb(var(--text-1));
  }

  .calendar-disclosure { overflow: hidden; }

  .calendar-disclosure summary {
    list-style: none;
    min-height: 3.25rem;
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto auto;
    align-items: center;
    gap: 0.5rem;
    padding: 0.85rem 1rem;
    cursor: pointer;
  }

  .calendar-disclosure summary::-webkit-details-marker { display: none; }

  .calendar-disclosure summary strong,
  .calendar-disclosure summary small {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .calendar-disclosure summary strong {
    color: rgb(var(--text-1));
    font-size: 0.875rem;
    font-weight: 650;
  }

  .calendar-disclosure summary small {
    margin-top: 0.15rem;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
  }

  .calendar-disclosure-body {
    border-top: 1px solid rgb(var(--surface-3) / 0.72);
    padding: 1rem;
  }

  .disclosure-icon { color: rgb(var(--text-3)); transition: transform 120ms ease; }
  .calendar-disclosure[open] .disclosure-icon { transform: rotate(180deg); }

  .summary-action {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    transition: background-color 120ms ease;
  }

  .summary-action:hover { background: rgb(var(--surface-3)); }

  .day-event {
    border-radius: 8px;
    border-top: 1px solid rgb(var(--surface-3) / 0.7);
    border-right: 1px solid rgb(var(--surface-3) / 0.7);
    border-bottom: 1px solid rgb(var(--surface-3) / 0.7);
    transition: background-color 120ms ease, transform 120ms ease, border-color 120ms ease;
  }

  .day-event:hover { border-color: rgb(var(--surface-3)); transform: translateY(-1px); }

  .day-empty {
    min-height: 4rem;
    border: 1px dashed rgb(var(--surface-3));
    border-radius: 8px;
    color: rgb(var(--text-3));
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-size: 0.875rem;
  }

  @media (min-width: 1100px) {
    .calendar-sidebar {
      position: sticky;
      top: 4.65rem;
      align-self: start;
      max-height: calc(100dvh - 5rem);
      overflow-y: auto;
      padding-right: 0.1rem;
      scrollbar-width: thin;
    }
  }
</style>
