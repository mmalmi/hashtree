<script lang="ts">
  import EventSummary from './EventSummary.svelte';
  import { Avatar, Name } from '../User';
  import { nostrStore } from '../../nostr';
  import { createProfileStore, getProfileName } from '../../stores/profile';
  import { watchInvite } from '../../lib/calendar/inbox';
  import { formatCalendarRoute, type CalendarEvent, type CalendarTimeFormat, type RsvpStatus } from '../../lib/calendar';

  interface Props {
    organizer: string;
    secret: string;
    /** My copy of the event, once I have answered. */
    mine?: CalendarEvent;
    timeFormat: CalendarTimeFormat;
    onAnswer: (event: CalendarEvent, status: RsvpStatus, name?: string) => void;
  }

  let { organizer, secret, mine, timeFormat, onAnswer }: Props = $props();
  let event = $state<CalendarEvent | null | undefined>(undefined);
  let name = $state('');
  let profile = $derived(createProfileStore($nostrStore.pubkey ?? undefined));
  let hasName = $derived(!!getProfileName($profile ?? undefined));
  let own = $derived(organizer === $nostrStore.npub);

  $effect(() => watchInvite(secret, organizer, next => event = next));
</script>

<section class="invite-page calendar-panel mx-auto max-w-xl space-y-5 p-5 md:p-6" data-testid="invite-page">
  <div class="text-xs font-semibold uppercase text-accent">Invitation</div>
  {#if event === undefined}
    <p class="text-sm text-text-2">Loading invite...</p>
  {:else if event === null || event.cancelled}
    <p class="text-sm text-text-2">This invite is no longer available.</p>
  {:else}
    <EventSummary
      {event}
      {timeFormat}
      owner={organizer}
      answer={mine?.rsvp}
      onAnswer={own ? undefined : status => onAnswer(event!, status, hasName ? undefined : name.trim() || undefined)}
    />
    {#if !own}
      {#if !hasName && !mine}
        <label class="block space-y-1">
          <span class="text-xs text-text-3">Your name, for the organizer</span>
          <input class="input w-full" bind:value={name} placeholder="Your name" data-testid="invite-name-input" />
        </label>
      {/if}
      <div class="flex flex-wrap items-center justify-between gap-2 text-xs text-text-3">
        <span class="flex items-center gap-2">
          Answering as
          <Avatar pubkey={$nostrStore.pubkey ?? ''} size={20} />
          <Name pubkey={$nostrStore.pubkey ?? ''} />
        </span>
        <a class="hover:underline" href="#/users">Use another account</a>
      </div>
    {/if}
    {#if mine && mine.rsvp !== 'needs-action'}
      <div class="flex items-center justify-between gap-3 rounded-lg bg-success/10 p-3 text-sm text-text-1" role="status" data-testid="invite-answered">
        <span>In your calendar.</span>
        <a class="btn-ghost" href="#{formatCalendarRoute('week', new Date(event.start))}">Open calendar</a>
      </div>
    {/if}
  {/if}
</section>
