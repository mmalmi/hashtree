<script lang="ts">
  import CalendarAgendaView from './CalendarAgendaView.svelte';
  import CalendarDayView from './CalendarDayView.svelte';
  import CalendarGrid from './CalendarGrid.svelte';
  import CalendarSidebar from './CalendarSidebar.svelte';
  import CalendarWeekView from './CalendarWeekView.svelte';
  import CalendarYearView from './CalendarYearView.svelte';
  import type {
    AvailabilitySettings,
    BookingLink,
    CalendarData,
    CalendarEvent,
    CalendarView,
  } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    view: CalendarView;
    monthDate: Date;
    selectedDate: Date;
    selectedDayEvents: CalendarEvent[];
    totalEvents: number;
    enabledBookingLinks: BookingLink[];
    firstBookingLink: BookingLink | null;
    actor: string;
    availabilityText: string;
    upcoming: CalendarEvent[];
    onSelectDate: (date: Date) => void;
    onPreviousMonth: () => void;
    onNextMonth: () => void;
    onNewEvent: (date?: Date | Event) => void;
    onCopyPrimaryBookingLink: () => void;
    onToday: () => void;
    onEditEvent: (event: CalendarEvent) => void;
    onAvailabilityChange: (availability: AvailabilitySettings) => void;
    onAddBookingLink: () => void;
    onRemoveBookingLink: (linkId: string) => void;
    onBookingDataChange: (data: CalendarData) => void;
    onSelectView: (view: CalendarView) => void;
  }

  let {
    data,
    view,
    monthDate,
    selectedDate,
    selectedDayEvents,
    totalEvents,
    enabledBookingLinks,
    firstBookingLink,
    actor,
    availabilityText,
    upcoming,
    onSelectDate,
    onPreviousMonth,
    onNextMonth,
    onNewEvent,
    onCopyPrimaryBookingLink,
    onToday,
    onEditEvent,
    onAvailabilityChange,
    onAddBookingLink,
    onRemoveBookingLink,
    onBookingDataChange,
    onSelectView,
  }: Props = $props();
</script>

<div class="calendar-workbench">
  <CalendarSidebar
    {data}
    {monthDate}
    {selectedDate}
    {selectedDayEvents}
    {totalEvents}
    {enabledBookingLinks}
    {firstBookingLink}
    {actor}
    {availabilityText}
    onSelectDate={onSelectDate}
    onPreviousMonth={onPreviousMonth}
    onNextMonth={onNextMonth}
    onNewEvent={onNewEvent}
    onCopyPrimaryBookingLink={onCopyPrimaryBookingLink}
    onToday={onToday}
    onEditEvent={onEditEvent}
    onAvailabilityChange={onAvailabilityChange}
    onAddBookingLink={onAddBookingLink}
    onRemoveBookingLink={onRemoveBookingLink}
    onBookingDataChange={onBookingDataChange}
  />

  <section class="calendar-primary min-w-0">
    {#if view === 'month'}
      <CalendarGrid
        {data}
        {monthDate}
        {selectedDate}
        onSelectDate={onSelectDate}
        onEditEvent={onEditEvent}
      />
    {:else if view === 'day'}
      <CalendarDayView
        {data}
        {selectedDate}
        onEditEvent={onEditEvent}
        onNewEvent={onNewEvent}
      />
    {:else if view === 'week'}
      <CalendarWeekView
        {data}
        {selectedDate}
        onSelectDate={onSelectDate}
        onEditEvent={onEditEvent}
        onNewEvent={onNewEvent}
      />
    {:else if view === 'year'}
      <CalendarYearView
        {data}
        {monthDate}
        {selectedDate}
        onSelectDate={onSelectDate}
        onSelectView={onSelectView}
      />
    {:else}
      <CalendarAgendaView events={upcoming} timeFormat={data.timeFormat} onEditEvent={onEditEvent} />
    {/if}
  </section>
</div>

<style>
  .calendar-workbench {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    grid-template-areas:
      "primary"
      "sidebar";
    gap: 1rem;
    align-items: start;
  }

  .calendar-primary {
    grid-area: primary;
  }

  @media (min-width: 920px) {
    .calendar-workbench {
      grid-template-columns: minmax(14.5rem, 17.25rem) minmax(0, 1fr);
      grid-template-areas: "sidebar primary";
      gap: 1.15rem;
    }
  }

  @media (min-width: 1440px) {
    .calendar-workbench {
      grid-template-columns: minmax(18rem, 21rem) minmax(0, 1fr);
    }
  }
</style>
