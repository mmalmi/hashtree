<script lang="ts">
  import { onMount, tick } from 'svelte';
  import type { CalendarData, CalendarEvent } from '../../lib/calendar';
  import {
    buildWeekAllDaySegments,
    buildTimedEventSegments,
    eventsForDay,
    formatHourLabel,
    formatTime,
    toDateInputValue,
    weekDays,
    type TimedEventSegment,
    type WeekAllDaySegment,
  } from '../../lib/calendar';
  import CalendarNowLine from './CalendarNowLine.svelte';

  interface Props {
    data: CalendarData;
    selectedDate: Date;
    onSelectDate: (date: Date) => void;
    onEditEvent: (event: CalendarEvent) => void;
    onNewEvent: (date?: Date) => void;
  }

  const HOURS = Array.from({ length: 24 }, (_, hour) => hour);
  const DAY_MINUTES = 24 * 60;
  const MINUTE_MS = 60 * 1000;

  let { data, selectedDate, onSelectDate, onEditEvent, onNewEvent }: Props = $props();
  let weekScroll = $state<HTMLElement | null>(null);
  let weekScrollLeft = $state(0);
  let weekFirstDayOffset = $state(0);
  let weekDayWidth = $state(0);
  let now = $state(new Date());
  let scrollKey = '';

  let days = $derived(weekDays(selectedDate, data.startOfWeek));
  let allDaySegments = $derived(buildWeekAllDaySegments(data.events, days));
  let allDayLaneCount = $derived(allDaySegments.reduce((max, segment) => Math.max(max, segment.lane + 1), 1));
  let nowTopPercent = $derived(((now.getHours() * 60 + now.getMinutes()) / DAY_MINUTES) * 100);

  onMount(() => {
    now = new Date();
    const timer = window.setInterval(() => {
      now = new Date();
    }, 60_000);
    return () => window.clearInterval(timer);
  });

  $effect(() => {
    const key = `${days.map(toDateInputValue).join(':')}:${toDateInputValue(selectedDate)}:${workdayStartHour()}`;
    if (key === scrollKey) return;
    scrollKey = key;
    void tick().then(() => scrollToWorkdayStart());
  });

  function sameDay(a: Date, b: Date): boolean {
    return toDateInputValue(a) === toDateInputValue(b);
  }

  function startOfDay(day: Date): Date {
    return new Date(day.getFullYear(), day.getMonth(), day.getDate());
  }

  function nextDay(day: Date): Date {
    return new Date(day.getFullYear(), day.getMonth(), day.getDate() + 1);
  }

  function isAvailable(day: Date): boolean {
    return data.availability.rules.some(rule => rule.weekday === day.getDay() && rule.enabled);
  }

  function workdayStartHour(): number {
    const enabledStarts = data.availability.rules
      .filter(rule => rule.enabled)
      .map(rule => Number(rule.startTime.split(':')[0]))
      .filter(hour => Number.isFinite(hour));
    const hour = enabledStarts.length ? Math.min(...enabledStarts) : 9;
    return Math.min(23, Math.max(0, hour));
  }

  function scrollToWorkdayStart() {
    if (!weekScroll) return;
    const firstCell = weekScroll.querySelector<HTMLElement>('.week-hour-cell');
    const cellHeight = firstCell?.getBoundingClientRect().height ?? 52;
    weekScroll.scrollTop = Math.max(0, (workdayStartHour() - 1) * cellHeight);

    const selectedIndex = days.findIndex(day => sameDay(day, selectedDate));
    const selectedHead = selectedIndex >= 0
      ? weekScroll.querySelectorAll<HTMLElement>('.week-day-head')[selectedIndex]
      : null;
    if (!selectedHead) return;

    const centeredLeft = selectedHead.offsetLeft - Math.max(0, (weekScroll.clientWidth - selectedHead.offsetWidth) / 2);
    weekScroll.scrollLeft = Math.max(0, centeredLeft);
    syncWeekScrollMetrics();
  }

  function syncWeekScrollMetrics() {
    if (!weekScroll) return;
    const firstAllDayCell = weekScroll.querySelector<HTMLElement>('.week-all-day-cell');
    weekScrollLeft = weekScroll.scrollLeft;
    weekFirstDayOffset = firstAllDayCell?.offsetLeft ?? 0;
    weekDayWidth = firstAllDayCell?.getBoundingClientRect().width ?? 0;
  }

  function eventClass(event: CalendarEvent): string {
    return ({
      violet: 'border-accent bg-accent/18 text-accent',
      green: 'border-success bg-success/18 text-success',
      blue: 'border-sky-500 bg-sky-500/18 text-sky-300',
      amber: 'border-amber-500 bg-amber-500/18 text-amber-300',
      rose: 'border-rose-500 bg-rose-500/18 text-rose-300',
      slate: 'border-text-3 bg-surface-2 text-text-1',
    } as const)[event.color];
  }

  function dayEvents(day: Date): CalendarEvent[] {
    return eventsForDay(data.events, day);
  }

  function timedEvents(day: Date): CalendarEvent[] {
    return dayEvents(day).filter(event => !event.allDay);
  }

  function timedSegments(day: Date): TimedEventSegment[] {
    return buildTimedEventSegments(timedEvents(day));
  }

  function weekdayLabel(date: Date): string {
    return new Intl.DateTimeFormat(undefined, {
      weekday: 'short',
    }).format(date);
  }

  function monthDayLabel(date: Date): string {
    return new Intl.DateTimeFormat(undefined, {
      month: 'short',
      day: 'numeric',
    }).format(date);
  }

  function hourLabel(hour: number): string {
    return formatHourLabel(hour, data.timeFormat);
  }

  function eventPositionStyle(event: CalendarEvent, day: Date): string {
    const dayStart = startOfDay(day).getTime();
    const dayEnd = nextDay(day).getTime();
    const eventStart = Math.max(new Date(event.start).getTime(), dayStart);
    const eventEnd = Math.min(new Date(event.end).getTime(), dayEnd);
    const startMinutes = Math.max(0, (eventStart - dayStart) / MINUTE_MS);
    const durationMinutes = Math.max(15, (eventEnd - eventStart) / MINUTE_MS);
    const top = Math.min(100, Math.max(0, startMinutes / DAY_MINUTES * 100));
    const height = Math.min(100 - top, durationMinutes / DAY_MINUTES * 100);
    return `top: ${top}%; height: max(1.85rem, ${height}%);`;
  }

  function timedSegmentStyle(segment: TimedEventSegment, day: Date): string {
    const gap = 0.25;
    const width = 100 / segment.laneCount;
    const left = segment.lane * width;
    return `${eventPositionStyle(segment.event, day)} left: calc(${left}% + ${gap}rem); right: calc(${100 - left - width}% + ${gap}rem);`;
  }

  function allDaySectionStyle(): string {
    return `--week-all-day-height: ${(2.7 + (allDayLaneCount - 1) * 1.55).toFixed(2)}rem;`;
  }

  function allDaySegmentStyle(segment: WeekAllDaySegment): string {
    return [
      `grid-column: ${segment.startIndex + 2} / ${segment.endIndex + 2}`,
      `margin-top: ${(0.35 + segment.lane * 1.55).toFixed(2)}rem`,
      `--week-all-day-title-offset: ${allDayTitleOffset(segment).toFixed(0)}px`,
    ].join('; ');
  }

  function allDayTitleOffset(segment: WeekAllDaySegment): number {
    if (weekDayWidth <= 0) return 0;
    const segmentLeft = weekFirstDayOffset + segment.startIndex * weekDayWidth;
    const visibleOffset = weekScrollLeft - segmentLeft + 6;
    return Math.max(0, visibleOffset);
  }

  function eventAccessibleLabel(event: CalendarEvent): string {
    return `${event.title} ${formatTime(event.start, data.timeFormat)} - ${formatTime(event.end, data.timeFormat)}`;
  }

  function hourDate(day: Date, hour: number): Date {
    return new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, 0, 0, 0);
  }

  function hourActionLabel(day: Date, hour: number): string {
    return `Create event ${weekdayLabel(day)}, ${monthDayLabel(day)} at ${hourLabel(hour)}`;
  }
</script>

<section class="week-view calendar-panel overflow-hidden" data-testid="calendar-week-view">
  <div class="week-scroll" bind:this={weekScroll} data-testid="calendar-week-scroll" onscroll={syncWeekScrollMetrics}>
    <div class="week-grid week-header">
      <div class="week-corner"></div>
      {#each days as day (toDateInputValue(day))}
        {@const selected = sameDay(day, selectedDate)}
        {@const today = sameDay(day, new Date())}
        <button
          class="week-day-head {selected ? 'week-day-head-selected' : ''}"
          onclick={() => onSelectDate(new Date(day))}
        >
          <span class="truncate text-[11px] font-semibold uppercase text-text-3">{weekdayLabel(day)}</span>
          <span class="week-day-number {today ? 'week-day-today' : ''}">{day.getDate()}</span>
          <span class="truncate text-[11px] text-text-3">{monthDayLabel(day)}</span>
        </button>
      {/each}
    </div>

    <div class="week-grid week-all-day" style={allDaySectionStyle()} data-testid="calendar-week-all-day-row">
      <div class="week-all-day-label" data-testid="calendar-week-all-day-label">All day</div>
      {#each days as day, index (toDateInputValue(day))}
        <div class={`week-all-day-cell ${!isAvailable(day) ? 'week-day-unavailable' : ''}`} style={`grid-column: ${index + 2};`}></div>
      {/each}
      {#each allDaySegments as segment (segment.event.id)}
        <button
          class="week-all-day-event border-l-2 {eventClass(segment.event)}"
          data-testid="calendar-week-all-day-event"
          style={allDaySegmentStyle(segment)}
          onclick={() => onEditEvent(segment.event)}
        >
          <span class="week-all-day-event-title">{segment.event.title}</span>
        </button>
      {/each}
    </div>

    <div class="week-grid week-body">
      <div class="week-time-gutter">
        {#each HOURS as hour (hour)}
          <div>{hourLabel(hour)}</div>
        {/each}
      </div>

      {#each days as day (toDateInputValue(day))}
        {@const selected = sameDay(day, selectedDate)}
        <div class="week-day-column {selected ? 'week-day-column-selected' : ''} {!isAvailable(day) ? 'week-day-unavailable' : ''}">
          <div class="week-hour-cells">
            {#each HOURS as hour (hour)}
              <button
                class="week-hour-cell"
                aria-label={hourActionLabel(day, hour)}
                onclick={() => onNewEvent(hourDate(day, hour))}
              ></button>
            {/each}
          </div>

          {#each timedSegments(day) as segment (segment.event.id)}
            <button
              class="week-event absolute overflow-hidden rounded-md border-l-2 px-2 py-1 text-left text-[11px] leading-tight shadow-sm {eventClass(segment.event)}"
              style={timedSegmentStyle(segment, day)}
              aria-label={eventAccessibleLabel(segment.event)}
              onclick={() => onEditEvent(segment.event)}
            >
              <span class="block truncate font-semibold">
                <span class="font-medium opacity-80">{formatTime(segment.event.start, data.timeFormat)}</span>
                {segment.event.title}
              </span>
            </button>
          {/each}
          {#if sameDay(day, now)}
            <CalendarNowLine topPercent={nowTopPercent} testId="calendar-week-now-line" />
          {/if}
        </div>
      {/each}
    </div>
  </div>
</section>

<style>
  .week-view {
    --week-hour-height: 3.25rem;
    --calendar-grid-line: rgb(var(--surface-3));
    --calendar-grid-line-soft: rgb(var(--surface-3) / 0.86);
  }

  .week-scroll {
    overflow: auto;
    max-height: min(72vh, 46rem);
  }

  .week-grid {
    display: grid;
    grid-template-columns: 3.4rem repeat(7, minmax(4.9rem, 1fr));
    min-width: 0;
  }

  @media (max-width: 720px) {
    .week-grid {
      grid-template-columns: 3.4rem repeat(7, minmax(5.7rem, 1fr));
      min-width: 43.5rem;
    }
  }

  .week-header {
    position: sticky;
    top: 0;
    z-index: 5;
    background: rgb(var(--surface-1));
    border-bottom: 1px solid var(--calendar-grid-line);
  }

  .week-corner,
  .week-day-head {
    min-height: 4.5rem;
  }

  .week-day-head {
    display: grid;
    justify-items: center;
    align-content: center;
    gap: 0.18rem;
    border-left: 1px solid var(--calendar-grid-line);
    text-align: center;
  }

  .week-day-head:hover {
    background: rgb(var(--surface-2) / 0.5);
  }

  .week-day-head-selected {
    background: rgb(145 109 254 / 0.08);
  }

  .week-day-number {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: rgb(var(--text-1));
    font-weight: 750;
  }

  .week-day-today {
    color: #916dfe;
    background: rgb(145 109 254 / 0.16);
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.38);
  }

  .week-all-day {
    --week-all-day-height: 2.7rem;
    position: sticky;
    top: 4.5rem;
    z-index: 4;
    background: rgb(var(--surface-1));
    border-bottom: 1px solid var(--calendar-grid-line);
  }

  .week-all-day-label {
    grid-column: 1;
    grid-row: 1;
    min-height: var(--week-all-day-height);
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0.5rem 0.55rem;
    color: rgb(var(--text-3));
    font-size: 0.68rem;
  }

  .week-all-day-cell {
    min-height: var(--week-all-day-height);
    border-left: 1px solid var(--calendar-grid-line);
    grid-row: 1;
  }

  .week-all-day-event {
    position: relative;
    z-index: 2;
    grid-row: 1;
    height: 1.35rem;
    margin-inline: 0.35rem;
    border-radius: 6px;
    padding: 0.18rem 0.4rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 0.68rem;
    line-height: 1.1;
    text-align: left;
  }

  .week-all-day-event-title {
    display: block;
    max-width: calc(100% - var(--week-all-day-title-offset, 0px));
    overflow: hidden;
    text-overflow: ellipsis;
    transform: translateX(var(--week-all-day-title-offset, 0px));
  }

  .week-all-day-event:hover {
    box-shadow: 0 8px 18px rgb(0 0 0 / 0.22);
  }

  .week-body {
    align-items: stretch;
  }

  .week-time-gutter {
    display: grid;
    grid-template-rows: repeat(24, var(--week-hour-height));
    color: rgb(var(--text-3));
    font-size: 0.68rem;
    text-align: right;
  }

  .week-time-gutter div {
    padding: 0.2rem 0.55rem 0 0;
    border-top: 1px solid var(--calendar-grid-line-soft);
  }

  .week-day-column {
    position: relative;
    min-height: calc(24 * var(--week-hour-height));
    border-left: 1px solid var(--calendar-grid-line);
    background-image: repeating-linear-gradient(
      to bottom,
      var(--calendar-grid-line-soft) 0,
      var(--calendar-grid-line-soft) 1px,
      transparent 1px,
      transparent var(--week-hour-height)
    );
  }

  .week-day-column-selected {
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.45);
  }

  .week-day-unavailable {
    background-color: rgb(var(--surface-0) / 0.54);
    background-image:
      repeating-linear-gradient(
        135deg,
        rgb(var(--surface-2) / 0.18) 0,
        rgb(var(--surface-2) / 0.18) 1px,
        transparent 1px,
        transparent 8px
      ),
      repeating-linear-gradient(
        to bottom,
        var(--calendar-grid-line-soft) 0,
        var(--calendar-grid-line-soft) 1px,
        transparent 1px,
        transparent var(--week-hour-height)
      );
  }

  .week-hour-cells {
    display: grid;
    grid-template-rows: repeat(24, var(--week-hour-height));
    height: 100%;
  }

  .week-hour-cell {
    min-height: var(--week-hour-height);
  }

  .week-hour-cell:hover {
    background: rgb(145 109 254 / 0.06);
  }

  .week-event {
    z-index: 2;
    backdrop-filter: blur(8px);
    transition: transform 120ms ease, box-shadow 120ms ease;
  }

  .week-event:hover {
    z-index: 3;
    transform: translateY(-1px);
    box-shadow: 0 10px 24px rgb(0 0 0 / 0.22);
  }
</style>
