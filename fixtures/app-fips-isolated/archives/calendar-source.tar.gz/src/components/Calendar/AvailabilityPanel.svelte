<script lang="ts">
  import type { AvailabilitySettings } from '../../lib/calendar';
  import { WEEKDAY_LABELS } from '../../lib/calendar';

  interface Props {
    availability: AvailabilitySettings;
    onChange: (availability: AvailabilitySettings) => void;
    embedded?: boolean;
  }

  const TIME_INPUT_PATTERN = '[0-9]{1,2}:[0-9]{2}';

  let { availability, onChange, embedded = false }: Props = $props();

  function minimumForNumber(key: 'slotDurationMinutes' | 'bufferBeforeMinutes' | 'bufferAfterMinutes' | 'minimumNoticeMinutes') {
    return key === 'slotDurationMinutes' ? 5 : 0;
  }

  function updateRule(index: number, patch: Partial<AvailabilitySettings['rules'][number]>) {
    onChange({
      ...availability,
      rules: availability.rules.map((rule, ruleIndex) => ruleIndex === index ? { ...rule, ...patch } : rule),
    });
  }

  function updateNumber(key: 'slotDurationMinutes' | 'bufferBeforeMinutes' | 'bufferAfterMinutes' | 'minimumNoticeMinutes', value: string) {
    const numberValue = Number(value);
    if (!Number.isFinite(numberValue)) return;
    onChange({
      ...availability,
      [key]: Math.max(minimumForNumber(key), Math.round(numberValue)),
    });
  }

  function normalizeTimeInput(value: string): string | null {
    const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
    if (!match) return null;

    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (hours > 23 || minutes > 59) return null;
    return `${hours}`.padStart(2, '0') + ':' + `${minutes}`.padStart(2, '0');
  }

  function minutesFromTime(value: string): number {
    const [hours = '0', minutes = '0'] = value.split(':');
    return Number(hours) * 60 + Number(minutes);
  }

  function timeFromMinutes(value: number): string {
    const clamped = Math.min(23 * 60 + 59, Math.max(0, value));
    const hours = Math.floor(clamped / 60);
    const minutes = clamped % 60;
    return `${hours}`.padStart(2, '0') + ':' + `${minutes}`.padStart(2, '0');
  }

  function normalizedTimePatch(
    rule: AvailabilitySettings['rules'][number],
    key: 'startTime' | 'endTime',
    time: string,
  ): Partial<AvailabilitySettings['rules'][number]> {
    const slotMinutes = Math.max(5, availability.slotDurationMinutes);
    const startMinutes = minutesFromTime(key === 'startTime' ? time : rule.startTime);
    const endMinutes = minutesFromTime(key === 'endTime' ? time : rule.endTime);

    if (key === 'startTime' && startMinutes >= endMinutes) {
      return { startTime: time, endTime: timeFromMinutes(startMinutes + slotMinutes) };
    }

    if (key === 'endTime' && endMinutes <= startMinutes) {
      return { startTime: timeFromMinutes(endMinutes - slotMinutes), endTime: time };
    }

    return { [key]: time };
  }

  function updateTime(index: number, key: 'startTime' | 'endTime', value: string) {
    const time = normalizeTimeInput(value);
    if (!time) return;
    const rule = availability.rules[index];
    if (!rule) return;
    updateRule(index, normalizedTimePatch(rule, key, time));
  }
</script>

<section class={embedded ? 'space-y-4' : 'calendar-panel p-4 space-y-4'}>
  {#if !embedded}
    <div class="flex items-center justify-between gap-3">
      <h2 class="text-sm font-semibold text-text-1">Availability</h2>
      <span class="timezone-chip">{availability.timezone}</span>
    </div>
  {/if}

  <div class="space-y-2">
    <div class="availability-header" aria-hidden="true">
      <span></span>
      <span>Start</span>
      <span>End</span>
    </div>
    {#each availability.rules as rule, index (rule.id)}
      <div class="availability-row {rule.enabled ? '' : 'availability-row-disabled'}">
        <label class="day-toggle">
          <input
            type="checkbox"
            checked={rule.enabled}
            onchange={(event) => updateRule(index, { enabled: (event.currentTarget as HTMLInputElement).checked })}
          />
          <span>{WEEKDAY_LABELS[rule.weekday]}</span>
        </label>
        <input
          class="input w-full"
          type="text"
          inputmode="numeric"
          autocomplete="off"
          pattern={TIME_INPUT_PATTERN}
          aria-label={`${WEEKDAY_LABELS[rule.weekday]} start time`}
          value={rule.startTime}
          disabled={!rule.enabled}
          oninput={(event) => updateTime(index, 'startTime', (event.currentTarget as HTMLInputElement).value)}
          onblur={(event) => {
            (event.currentTarget as HTMLInputElement).value = rule.startTime;
          }}
        />
        <input
          class="input w-full"
          type="text"
          inputmode="numeric"
          autocomplete="off"
          pattern={TIME_INPUT_PATTERN}
          aria-label={`${WEEKDAY_LABELS[rule.weekday]} end time`}
          value={rule.endTime}
          disabled={!rule.enabled}
          oninput={(event) => updateTime(index, 'endTime', (event.currentTarget as HTMLInputElement).value)}
          onblur={(event) => {
            (event.currentTarget as HTMLInputElement).value = rule.endTime;
          }}
        />
      </div>
    {/each}
  </div>

  <div class="grid grid-cols-2 gap-2">
    <label class="space-y-1">
      <span class="block text-xs text-text-3">Slot length</span>
      <input class="input w-full" type="number" min="5" step="5" value={availability.slotDurationMinutes} aria-label="Slot minutes" oninput={(event) => updateNumber('slotDurationMinutes', (event.currentTarget as HTMLInputElement).value)} />
    </label>
    <label class="space-y-1">
      <span class="block text-xs text-text-3">Notice</span>
      <input class="input w-full" type="number" min="0" step="15" value={availability.minimumNoticeMinutes} aria-label="Notice minutes" oninput={(event) => updateNumber('minimumNoticeMinutes', (event.currentTarget as HTMLInputElement).value)} />
    </label>
    <label class="space-y-1">
      <span class="block text-xs text-text-3">Buffer before</span>
      <input class="input w-full" type="number" min="0" step="5" value={availability.bufferBeforeMinutes} aria-label="Buffer before minutes" oninput={(event) => updateNumber('bufferBeforeMinutes', (event.currentTarget as HTMLInputElement).value)} />
    </label>
    <label class="space-y-1">
      <span class="block text-xs text-text-3">Buffer after</span>
      <input class="input w-full" type="number" min="0" step="5" value={availability.bufferAfterMinutes} aria-label="Buffer after minutes" oninput={(event) => updateNumber('bufferAfterMinutes', (event.currentTarget as HTMLInputElement).value)} />
    </label>
  </div>
</section>

<style>
  .timezone-chip {
    max-width: 11rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-3));
    padding: 0.25rem 0.55rem;
    font-size: 0.68rem;
  }

  .availability-row {
    display: grid;
    grid-template-columns: 4.35rem minmax(0, 1fr) minmax(0, 1fr);
    align-items: center;
    gap: 0.5rem;
    border-radius: 8px;
    padding: 0.25rem;
    background: rgb(var(--surface-0) / 0.45);
  }

  .availability-header {
    display: grid;
    grid-template-columns: 4.35rem minmax(0, 1fr) minmax(0, 1fr);
    gap: 0.5rem;
    padding: 0 0.25rem;
    color: rgb(var(--text-3));
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
  }

  .availability-header span:not(:first-child) {
    padding-inline: 0.6rem;
  }

  .availability-row-disabled {
    opacity: 0.58;
  }

  .day-toggle {
    display: inline-flex;
    align-items: center;
    gap: 0.42rem;
    color: rgb(var(--text-2));
    font-size: 0.8rem;
    min-width: 0;
  }

  .day-toggle input {
    width: 0.95rem;
    height: 0.95rem;
  }

  @media (max-width: 460px) {
    .availability-header {
      grid-template-columns: 1fr 1fr;
    }

    .availability-header span:first-child {
      display: none;
    }

    .availability-row {
      grid-template-columns: 1fr 1fr;
    }

    .day-toggle {
      grid-column: 1 / -1;
    }
  }
</style>
