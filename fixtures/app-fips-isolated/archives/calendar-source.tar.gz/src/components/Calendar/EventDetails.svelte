<script lang="ts">
  import Modal from '../ui/Modal.svelte';
  import EventSummary from './EventSummary.svelte';
  import type { CalendarEvent, CalendarTimeFormat, RsvpStatus } from '../../lib/calendar';

  interface Props {
    event: CalendarEvent;
    timeFormat: CalendarTimeFormat;
    onClose: () => void;
    onAnswer: (status: RsvpStatus) => void;
    onRemove: () => void;
  }

  let { event, timeFormat, onClose, onAnswer, onRemove }: Props = $props();
  let invited = $derived(!!event.organizer && !event.calendar);
</script>

<Modal open {onClose} label={event.title} panelClass="bg-surface-1 rounded-lg shadow-lg w-full max-w-md mx-4 border border-surface-3">
  <div class="relative p-5" data-testid="event-details">
    <button class="btn-circle bg-surface-2 hover:bg-surface-3 absolute right-4 top-4" onclick={onClose} aria-label="Close">
      <span class="i-lucide-x"></span>
    </button>
    <EventSummary
      {event}
      {timeFormat}
      owner={event.calendar ?? event.organizer}
      ownerLabel={event.calendar ? 'Calendar of' : 'Organizer'}
      answer={event.rsvp}
      onAnswer={invited ? onAnswer : undefined}
    />
    {#if invited && event.cancelled}
      <div class="mt-4 border-t border-surface-3 pt-4">
        <button class="btn-ghost" onclick={onRemove}>Remove from calendar</button>
      </div>
    {/if}
  </div>
</Modal>
