<script lang="ts">
  import type { CalendarEvent, CalendarTimeFormat } from '../../lib/calendar';
  import { eventDateLabel, eventTimeLabel, eventToneClass } from '../../lib/calendar';

  interface Props {
    events: CalendarEvent[];
    timeFormat: CalendarTimeFormat;
    onEditEvent: (event: CalendarEvent) => void;
  }

  let { events, timeFormat, onEditEvent }: Props = $props();

  type AgendaGroup = {
    label: string;
    events: CalendarEvent[];
  };

  let groups = $derived.by(() => {
    const grouped: AgendaGroup[] = [];
    for (const event of events) {
      const label = eventDateLabel(event);
      const last = grouped[grouped.length - 1];
      if (last?.label === label) {
        last.events.push(event);
      } else {
        grouped.push({ label, events: [event] });
      }
    }
    return grouped;
  });

  function eventAriaLabel(event: CalendarEvent): string {
    return [
      event.title,
      eventDateLabel(event),
      eventTimeLabel(event, timeFormat),
      event.location,
    ].filter(Boolean).join(' · ');
  }
</script>

<section class="calendar-panel overflow-hidden" data-testid="calendar-agenda-view">
  {#if events.length === 0}
    <div class="p-6 text-sm text-text-3">No upcoming events.</div>
  {:else}
    {#each groups as group (group.label)}
      <div class="agenda-group">
        <div class="agenda-date">{group.label}</div>
        <div class="divide-y divide-surface-3">
          {#each group.events as event (event.id)}
            <button
              class="agenda-row w-full border-l-3 p-4 text-left hover:bg-surface-2 {eventToneClass(event.color)}"
              aria-label={eventAriaLabel(event)}
              onclick={() => onEditEvent(event)}
            >
              <div class="agenda-row-main">
                <span class="agenda-time">{eventTimeLabel(event, timeFormat)}</span>
                <span class="agenda-title">{event.title}</span>
              </div>
              {#if event.location}
                <div class="mt-2 flex items-center gap-1 truncate text-xs text-text-3">
                  <span class="i-lucide-map-pin shrink-0"></span>
                  <span class="truncate">{event.location}</span>
                </div>
              {/if}
            </button>
          {/each}
        </div>
      </div>
    {/each}
  {/if}
</section>

<style>
  .agenda-group + .agenda-group {
    border-top: 1px solid rgb(var(--surface-3));
  }

  .agenda-date {
    background: rgb(var(--surface-0) / 0.48);
    color: rgb(var(--text-3));
    font-size: 0.72rem;
    font-weight: 700;
    padding: 0.75rem 1rem 0.45rem;
    text-transform: uppercase;
  }

  .agenda-row {
    transition: background-color 120ms ease, transform 120ms ease, border-color 120ms ease;
  }

  .agenda-row-main {
    display: grid;
    grid-template-columns: minmax(5rem, max-content) minmax(0, 1fr);
    align-items: baseline;
    gap: 0.75rem;
  }

  .agenda-time {
    color: rgb(var(--text-3));
    font-size: 0.84rem;
    white-space: nowrap;
  }

  .agenda-title {
    color: rgb(var(--text-1));
    font-weight: 650;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .agenda-row:hover {
    border-color: rgb(var(--surface-3));
    transform: translateY(-1px);
  }

  @media (max-width: 480px) {
    .agenda-row-main {
      grid-template-columns: minmax(4.25rem, max-content) minmax(0, 1fr);
      gap: 0.55rem;
    }

    .agenda-time {
      font-size: 0.78rem;
    }
  }
</style>
