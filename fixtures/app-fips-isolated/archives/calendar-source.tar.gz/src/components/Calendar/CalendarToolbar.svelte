<script lang="ts">
  import type { CalendarView } from '../../lib/calendar';
  import { CALENDAR_VIEW_OPTIONS } from '../../lib/calendar';
  import { appStore } from '../../store';
  import { nostrStore } from '../../nostr';
  import { settingsStore } from '../../stores/settings';
  import BandwidthIndicator from '../BandwidthIndicator.svelte';
  import ConnectivityIndicator from '../ConnectivityIndicator.svelte';
  import NostrLogin from '../NostrLogin.svelte';

  interface Props {
    title: string;
    view: CalendarView;
    saving: boolean;
    status: string;
    onPrevious: () => void;
    onNext: () => void;
    onToday: () => void;
    onSelectView: (view: CalendarView) => void;
  }

  const calendarIconUrl = `${import.meta.env.BASE_URL}iris-calendar-icon.svg`;

  let {
    title,
    view,
    saving,
    status,
    onPrevious,
    onNext,
    onToday,
    onSelectView,
  }: Props = $props();

  let viewMenuOpen = $state(false);
  let currentViewLabel = $derived(CALENDAR_VIEW_OPTIONS.find(option => option.value === view)?.label ?? 'Month');
  let showBandwidth = $derived($settingsStore.pools.showBandwidth ?? false);
  let showConnectivity = $derived($settingsStore.pools.showConnectivity ?? false);
  let totalConnections = $derived($nostrStore.connectedRelays + $appStore.peerCount);
  let showConnectivityWarning = $derived(totalConnections === 0);

  function selectView(nextView: CalendarView) {
    viewMenuOpen = false;
    onSelectView(nextView);
  }

  function handleViewMenuFocusout(event: FocusEvent) {
    const next = event.relatedTarget as Node | null;
    if (next && event.currentTarget instanceof HTMLElement && event.currentTarget.contains(next)) return;
    viewMenuOpen = false;
  }
</script>

<header class="calendar-topbar">
  <div class="calendar-topbar-main">
    <a href="#/" class="calendar-brand" aria-label="Calendar home">
      <img src={calendarIconUrl} alt="" draggable="false" />
      <h1>Calendar</h1>
    </a>

    <div class="calendar-range-nav">
      <button class="toolbar-icon-button" onclick={onPrevious} aria-label="Previous range" title="Previous range">
        <span class="i-lucide-chevron-left"></span>
      </button>
      <button class="today-button" onclick={onToday}>Today</button>
      <button class="toolbar-icon-button" onclick={onNext} aria-label="Next range" title="Next range">
        <span class="i-lucide-chevron-right"></span>
      </button>
      <div class="calendar-range-title" aria-live="polite">{title}</div>
    </div>
  </div>

  <div class="calendar-topbar-actions">
    {#if saving || status}
      <div class="text-xs text-text-3" data-testid="calendar-save-status">
        {#if saving}
          Saving
        {:else}
          {status}
        {/if}
      </div>
    {/if}

    <div class="view-menu" onfocusout={handleViewMenuFocusout}>
      <button
        type="button"
        class="view-menu-button"
        aria-haspopup="menu"
        aria-expanded={viewMenuOpen}
        aria-label="Calendar view"
        onclick={() => viewMenuOpen = !viewMenuOpen}
      >
        <span>{currentViewLabel}</span>
        <span class="i-lucide-chevron-down view-menu-icon"></span>
      </button>
      {#if viewMenuOpen}
        <div class="view-menu-list" role="menu" aria-label="Calendar views">
          {#each CALENDAR_VIEW_OPTIONS as option (option.value)}
            <button
              type="button"
              class="view-menu-item {option.value === view ? 'view-menu-item-active' : ''}"
              role="menuitemradio"
              aria-checked={option.value === view}
              onclick={() => selectView(option.value)}
            >
              <span>{option.label}</span>
              {#if option.value === view}
                <span class="i-lucide-check"></span>
              {/if}
            </button>
          {/each}
        </div>
      {/if}
    </div>

    {#if showBandwidth}
      <BandwidthIndicator />
    {/if}
    {#if showConnectivity || showConnectivityWarning}
      <ConnectivityIndicator />
    {/if}
    <NostrLogin />
  </div>
</header>

<style>
  .calendar-topbar {
    position: sticky;
    top: 0;
    z-index: 20;
    min-height: 4rem;
    margin-inline: -1rem;
    padding: 0.5rem 1rem;
    background: rgb(var(--surface-0) / 0.9);
    backdrop-filter: blur(18px);
    border-bottom: 1px solid rgb(var(--surface-3) / 0.52);
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 0.65rem 1rem;
  }

  .calendar-topbar-main,
  .calendar-topbar-actions,
  .calendar-range-nav,
  .calendar-brand {
    display: flex;
    align-items: center;
  }

  .calendar-topbar-main {
    min-width: 0;
    flex: 1 1 27rem;
    gap: 1rem;
  }

  .calendar-topbar-actions {
    flex: 0 1 auto;
    justify-content: flex-end;
    gap: 0.5rem;
  }

  .calendar-brand {
    flex: 0 0 auto;
    gap: 0.55rem;
    color: rgb(var(--text-1));
    text-decoration: none;
  }

  .calendar-brand img {
    width: 2rem;
    height: 2rem;
  }

  .calendar-brand h1 {
    color: rgb(var(--text-1));
    font-size: 1.28rem;
    font-weight: 650;
    line-height: 1;
  }

  .calendar-range-nav {
    min-width: 0;
    gap: 0.5rem;
  }

  .calendar-range-title {
    min-width: 0;
    margin-left: 0.35rem;
    color: rgb(var(--text-1));
    font-size: 1.18rem;
    font-weight: 650;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .toolbar-icon-button,
  .today-button {
    min-height: 2.45rem;
    border: 1px solid rgb(var(--surface-3) / 0.72);
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
    box-shadow: none;
    transition: background-color 120ms ease, border-color 120ms ease, transform 120ms ease;
  }

  .toolbar-icon-button {
    width: 2.45rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .today-button {
    border-radius: 999px;
    padding: 0 1rem;
    font-size: 0.875rem;
    font-weight: 650;
  }

  .toolbar-icon-button:hover,
  .today-button:hover {
    background: rgb(var(--surface-2));
    border-color: rgb(var(--surface-3));
  }

  .view-menu {
    position: relative;
    display: inline-flex;
    align-items: center;
    min-width: 7.25rem;
  }

  .view-menu-button {
    width: 100%;
    min-height: 2.45rem;
    border-radius: 999px;
    border: 1px solid rgb(var(--surface-3) / 0.72);
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
    padding: 0.35rem 2.1rem 0.35rem 0.95rem;
    font-size: 0.875rem;
    font-weight: 600;
    outline: none;
    display: inline-flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
  }

  .view-menu-button:hover {
    background: rgb(var(--surface-2));
  }

  .view-menu-button:focus-visible {
    box-shadow: 0 0 0 1px rgb(145 109 254 / 0.65);
  }

  .view-menu-icon {
    pointer-events: none;
    position: absolute;
    right: 0.75rem;
    color: rgb(var(--text-3));
    font-size: 1rem;
  }

  .view-menu-list {
    position: absolute;
    z-index: 30;
    top: calc(100% + 0.35rem);
    right: 0;
    width: 9rem;
    border-radius: 0.75rem;
    border: 1px solid rgb(var(--surface-3) / 0.76);
    background: rgb(var(--surface-1));
    padding: 0.35rem;
    box-shadow: 0 1.25rem 2.8rem rgb(0 0 0 / 0.32);
  }

  @media (min-width: 920px) {
    .calendar-topbar {
      margin-inline: -1.5rem;
      padding-inline: 1.5rem;
    }
  }

  @media (max-width: 720px) {
    .calendar-topbar-main,
    .calendar-topbar-actions {
      flex-basis: 100%;
    }

    .calendar-topbar-actions {
      justify-content: flex-start;
    }

    .calendar-range-title {
      font-size: 1rem;
    }
  }

  .view-menu-item {
    width: 100%;
    min-height: 2.1rem;
    border-radius: 0.55rem;
    color: rgb(var(--text-2));
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
    padding: 0.3rem 0.55rem;
    text-align: left;
    font-size: 0.875rem;
    font-weight: 600;
  }

  .view-menu-item:hover,
  .view-menu-item:focus-visible {
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
    outline: none;
  }

  .view-menu-item-active {
    color: rgb(167 139 250);
  }
</style>
