<script lang="ts">
  import { Avatar, Name } from '../User';
  import { npubToPubkey } from '../../nostr/trees';
  import type { CalendarEvent, CalendarTimeFormat, RsvpStatus } from '../../lib/calendar';
  import { eventDateLabel, eventTimeLabel } from '../../lib/calendar';

  interface Props {
    event: CalendarEvent;
    timeFormat: CalendarTimeFormat;
    /** Who made it: the organizer of an invite, or the owner of a shared calendar. */
    owner?: string;
    ownerLabel?: string;
    answer?: RsvpStatus;
    onAnswer?: (status: RsvpStatus) => void;
  }

  let { event, timeFormat, owner, ownerLabel = 'Organizer', answer, onAnswer }: Props = $props();
  const answers: Array<{ status: RsvpStatus; label: string }> = [
    { status: 'accepted', label: 'Yes' },
    { status: 'tentative', label: 'Maybe' },
    { status: 'declined', label: 'No' },
  ];
  const statusLabels: Record<RsvpStatus, string> = { 'needs-action': 'Invited', accepted: 'Going', tentative: 'Maybe', declined: 'Not going' };
  let ownerPubkey = $derived(owner ? npubToPubkey(owner) : null);
</script>

<div class="space-y-4">
  <div class="min-w-0">
    <h2 class="pr-10 text-xl font-semibold text-text-1 {event.cancelled ? 'line-through' : ''}">{event.title}</h2>
    <div class="mt-1 text-sm text-text-2">{eventDateLabel(event)} · {eventTimeLabel(event, timeFormat)}</div>
    {#if event.cancelled}<div class="mt-1 text-sm text-danger">Cancelled</div>{/if}
  </div>

  {#if event.location}
    <div class="flex items-center gap-2 text-sm text-text-2"><span class="i-lucide-map-pin text-text-3"></span>{event.location}</div>
  {/if}
  {#if event.notes}
    <p class="whitespace-pre-wrap text-sm text-text-2">{event.notes}</p>
  {/if}

  {#if ownerPubkey}
    <div class="space-y-2">
      <div class="text-xs font-semibold uppercase text-text-3">{ownerLabel}</div>
      <div class="flex items-center gap-2 text-sm text-text-1"><Avatar pubkey={ownerPubkey} size={28} /><Name pubkey={ownerPubkey} /></div>
    </div>
  {/if}

  {#if event.guests?.length}
    <div class="space-y-2">
      <div class="text-xs font-semibold uppercase text-text-3">Guests</div>
      {#each event.guests as guest (guest.npub)}
        {@const pubkey = npubToPubkey(guest.npub) ?? ''}
        <div class="flex items-center gap-2 text-sm text-text-1">
          <Avatar {pubkey} size={24} />
          <span class="min-w-0 flex-1 truncate">{#if guest.name}{guest.name}{:else}<Name {pubkey} />{/if}</span>
          <span class="text-xs text-text-3">{statusLabels[guest.status]}</span>
        </div>
      {/each}
    </div>
  {/if}

  {#if onAnswer && !event.cancelled}
    <div class="flex flex-wrap items-center justify-between gap-2 border-t border-surface-3 pt-4">
      <span class="text-sm text-text-2">Going?</span>
      <div class="flex gap-2" role="group" aria-label="Your answer">
        {#each answers as option (option.status)}
          <button
            class={answer === option.status ? 'btn-success' : 'btn-ghost'}
            aria-pressed={answer === option.status}
            onclick={() => onAnswer(option.status)}
          >{option.label}</button>
        {/each}
      </div>
    </div>
  {/if}
</div>
