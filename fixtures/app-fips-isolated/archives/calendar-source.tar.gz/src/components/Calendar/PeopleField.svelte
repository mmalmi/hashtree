<script lang="ts">
  import { nip19 } from 'nostr-tools';
  import { Avatar, Name } from '../User';
  import { nostrStore } from '../../nostr';
  import { createFollowsStore } from '../../stores/follows';
  import { createProfileStore, getProfileName, getProfileSync } from '../../stores/profile';
  import type { RsvpStatus } from '../../lib/calendar';

  interface Props {
    people: string[];
    statuses?: Record<string, RsvpStatus>;
    /** Names people gave when answering an invite link. */
    names?: Record<string, string>;
    label: string;
    onChange: (people: string[]) => void;
  }

  let { people, statuses = {}, names = {}, label, onChange }: Props = $props();
  const STATUS_LABELS: Record<RsvpStatus, string> = { 'needs-action': 'Invited', accepted: 'Going', tentative: 'Maybe', declined: 'Not going' };
  let query = $state('');
  let error = $state('');
  let profilesLoaded = $state(0);
  let followsStore = $derived(createFollowsStore($nostrStore.pubkey ?? undefined));
  let follows = $derived($followsStore?.follows.slice(0, 300) ?? []);
  let suggestions = $derived.by(() => {
    void profilesLoaded;
    const text = query.trim().toLowerCase();
    if (text.length < 2 || toNpub(text)) return [];
    return follows
      .filter(pubkey => getProfileName(getProfileSync(pubkey))?.toLowerCase().includes(text))
      .map(pubkey => nip19.npubEncode(pubkey))
      .filter(npub => !people.includes(npub))
      .slice(0, 5);
  });

  // Names of people I follow, so they can be found by typing.
  $effect(() => {
    const stops = follows.map(pubkey => createProfileStore(pubkey).subscribe(profile => profile && profilesLoaded++));
    return () => stops.forEach(stop => stop());
  });

  function toNpub(value: string): string | null {
    const text = value.trim().replace(/^nostr:/, '');
    try {
      if (/^[0-9a-f]{64}$/i.test(text)) return nip19.npubEncode(text.toLowerCase());
      const decoded = nip19.decode(text);
      if (decoded.type === 'npub') return nip19.npubEncode(decoded.data);
      if (decoded.type === 'nprofile') return nip19.npubEncode(decoded.data.pubkey);
    } catch { /* not a key */ }
    return null;
  }

  function add(npub: string) {
    query = '';
    error = '';
    if (npub !== $nostrStore.npub && !people.includes(npub)) onChange([...people, npub]);
  }

  function submit(event: Event) {
    event.preventDefault();
    const npub = toNpub(query) ?? suggestions[0];
    if (npub) add(npub);
    else if (query.trim()) error = 'Paste an npub, or type the name of someone you follow.';
  }

  function pubkeyOf(npub: string): string {
    return nip19.decode(npub).data as string;
  }
</script>

<div class="people-field space-y-2">
  {#if people.length}
    <ul class="space-y-1" aria-label={label}>
      {#each people as npub (npub)}
        <li class="person-row">
          <Avatar pubkey={pubkeyOf(npub)} size={28} />
          <span class="min-w-0 flex-1 truncate text-sm text-text-1">{#if names[npub]}{names[npub]}{:else}<Name pubkey={pubkeyOf(npub)} />{/if}</span>
          {#if statuses[npub]}
            <span class="person-status person-status-{statuses[npub]}">{STATUS_LABELS[statuses[npub]!]}</span>
          {/if}
          <button type="button" class="person-remove" aria-label="Remove" title="Remove" onclick={() => onChange(people.filter(item => item !== npub))}>
            <span class="i-lucide-x"></span>
          </button>
        </li>
      {/each}
    </ul>
  {/if}
  <div class="relative flex gap-2">
    <input
      class="input min-w-0 flex-1"
      placeholder="Name or npub"
      aria-label={label}
      bind:value={query}
      oninput={() => error = ''}
      onkeydown={event => event.key === 'Enter' && submit(event)}
    />
    <button type="button" class="btn-ghost" disabled={!query.trim()} onclick={submit}>Add</button>
    {#if suggestions.length}
      <div class="suggestions" role="listbox" aria-label="People you follow">
        {#each suggestions as npub (npub)}
          <button type="button" role="option" aria-selected="false" class="person-row w-full text-left" onclick={() => add(npub)}>
            <Avatar pubkey={pubkeyOf(npub)} size={24} />
            <span class="truncate text-sm"><Name pubkey={pubkeyOf(npub)} /></span>
          </button>
        {/each}
      </div>
    {/if}
  </div>
  {#if error}<div class="text-xs text-danger">{error}</div>{/if}
</div>

<style>
  .person-row {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    min-height: 2.4rem;
    border-radius: 8px;
    padding: 0.2rem 0.4rem;
  }

  .person-status {
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-2));
    font-size: 0.72rem;
    padding: 0.15rem 0.5rem;
  }

  .person-status-accepted { color: #2ba640; }
  .person-status-declined { color: #ff5a5a; }

  .person-remove {
    width: 1.8rem;
    height: 1.8rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: rgb(var(--text-3));
  }

  .person-remove:hover { background: rgb(var(--surface-3)); color: rgb(var(--text-1)); }

  .suggestions {
    position: absolute;
    z-index: 70;
    top: calc(100% + 0.3rem);
    left: 0;
    right: 0;
    border: 1px solid rgb(var(--surface-3));
    border-radius: 8px;
    background: rgb(var(--surface-1));
    padding: 0.25rem;
    box-shadow: 0 1rem 2rem rgb(0 0 0 / 0.3);
  }

  .suggestions .person-row:hover { background: rgb(var(--surface-2)); }
</style>
