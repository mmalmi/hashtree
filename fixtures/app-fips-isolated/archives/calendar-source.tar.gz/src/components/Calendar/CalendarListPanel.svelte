<script lang="ts">
  import { Name } from '../User';
  import { npubToPubkey } from '../../nostr/trees';
  import type { BookingLink, CalendarData, CalendarEvent, CalendarTimeFormat } from '../../lib/calendar';
  import { dateFormatter, formatTime } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    viewData: CalendarData;
    invitations: CalendarEvent[];
    shared: Record<string, CalendarData | null>;
    onOpenEvent: (event: CalendarEvent) => void;
    onShare: () => void;
    onCopyBookingLink: (link: BookingLink) => void;
    onChange: (data: CalendarData) => void;
    onImport: (file: File) => void;
    onExport: () => void;
  }

  let { data, viewData, invitations, shared, onOpenEvent, onShare, onCopyBookingLink, onChange, onImport, onExport }: Props = $props();
  let search = $state('');
  let fileInput = $state<HTMLInputElement | null>(null);
  const timeFormats: CalendarTimeFormat[] = ['auto', '24h', '12h'];

  let enabledLinks = $derived(data.bookingLinks.filter(link => link.enabled));
  let ownCount = $derived(data.events.filter(event => !event.cancelled && event.rsvp !== 'declined').length);
  let results = $derived.by(() => {
    const query = search.trim().toLowerCase();
    if (!query) return [];
    return viewData.events
      .filter(event => [event.title, event.location, event.notes].some(value => value?.toLowerCase().includes(query)))
      .slice(0, 6);
  });

  function count(value: number, noun: string): string {
    return `${value} ${noun}${value === 1 ? '' : 's'}`;
  }

  function when(event: CalendarEvent): string {
    const day = dateFormatter({ month: 'short', day: 'numeric' }).format(new Date(event.start));
    return `${day} · ${event.allDay ? 'All day' : formatTime(event.start, data.timeFormat)}`;
  }

  function toggle(npub: string) {
    onChange({ ...data, subscriptions: data.subscriptions.map(item => item.npub === npub ? { ...item, hidden: !item.hidden || undefined } : item) });
  }

  function pickFile(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (file) onImport(file);
  }
</script>

<section class="calendar-panel calendar-list-panel">
  <label class="calendar-search">
    <span class="i-lucide-search"></span>
    <input bind:value={search} placeholder="Search calendar" aria-label="Search calendar" />
  </label>

  {#if results.length}
    <div class="calendar-list-block">
      <div class="calendar-list-title">Results</div>
      {#each results as event (event.id)}
        <button class="calendar-list-row" type="button" onclick={() => onOpenEvent(event)}>
          <span class="calendar-list-dot calendar-list-dot-{event.color}"></span>
          <span class="calendar-list-copy"><strong>{event.title}</strong><small>{when(event)}</small></span>
        </button>
      {/each}
    </div>
  {/if}

  {#if invitations.length}
    <div class="calendar-list-block" data-testid="calendar-invitations">
      <div class="calendar-list-title">Invitations</div>
      {#each invitations as event (event.id)}
        <button class="calendar-list-row" type="button" onclick={() => onOpenEvent(event)}>
          <span class="calendar-list-dot calendar-list-dot-{event.color} calendar-list-dot-pending"></span>
          <span class="calendar-list-copy">
            <strong>{event.title}</strong>
            <small>{when(event)} · <Name pubkey={npubToPubkey(event.organizer ?? '') ?? ''} /></small>
          </span>
          <span class="i-lucide-mail calendar-list-action"></span>
        </button>
      {/each}
    </div>
  {/if}

  <div class="calendar-list-block">
    <div class="calendar-list-title">Calendars</div>
    <div class="calendar-list-row">
      <span class="calendar-list-dot calendar-list-dot-primary"></span>
      <span class="calendar-list-copy">
        <strong>My calendar</strong>
        <small>{count(ownCount, 'event')}{data.sharedWith.length ? ` · shared with ${data.sharedWith.length}` : ''}</small>
      </span>
      <button class="calendar-list-icon" type="button" onclick={onShare} aria-label="Share calendar" title="Share calendar">
        <span class="i-lucide-user-plus"></span>
      </button>
    </div>
    {#each data.subscriptions as calendar (calendar.npub)}
      {@const loaded = shared[calendar.npub]}
      <label class="calendar-list-row cursor-pointer">
        <input
          class="calendar-list-check calendar-list-check-{calendar.color}"
          type="checkbox"
          checked={!calendar.hidden}
          onchange={() => toggle(calendar.npub)}
          aria-label="Show calendar"
        />
        <span class="calendar-list-copy">
          <strong><Name pubkey={npubToPubkey(calendar.npub) ?? ''} /></strong>
          <small>{calendar.hidden ? 'Hidden' : loaded === null ? 'No access' : loaded ? count(loaded.events.length, 'event') : 'Loading'}</small>
        </span>
      </label>
    {/each}
    <button class="calendar-list-row" type="button" onclick={() => enabledLinks[0] && onCopyBookingLink(enabledLinks[0])} disabled={!enabledLinks.length}>
      <span class="calendar-list-dot calendar-list-dot-booking"></span>
      <span class="calendar-list-copy"><strong>Booking page</strong><small>{count(enabledLinks.length, 'link')}</small></span>
      <span class="i-lucide-copy calendar-list-action"></span>
    </button>
  </div>

  <div class="time-format-row">
    <span>Time</span>
    <div class="time-format-control" aria-label="Time format">
      {#each timeFormats as format (format)}
        <button
          type="button"
          class:time-format-active={data.timeFormat === format}
          aria-pressed={data.timeFormat === format}
          onclick={() => data.timeFormat !== format && onChange({ ...data, timeFormat: format })}
        >{format === 'auto' ? 'Auto' : format}</button>
      {/each}
    </div>
  </div>

  <div class="file-actions">
    <button class="btn-ghost" type="button" onclick={() => fileInput?.click()}>
      <span class="i-lucide-upload"></span>Import
    </button>
    <button class="btn-ghost" type="button" onclick={onExport}>
      <span class="i-lucide-download"></span>Export
    </button>
    <input bind:this={fileInput} class="hidden" type="file" accept=".ics,.ical,.ifb,.icalendar,.vcs,.csv,text/calendar,text/csv" onchange={pickFile} aria-label="Import calendar file" />
  </div>
</section>

<style>
  .calendar-list-panel { display: grid; gap: 0.85rem; padding: 0.85rem; }

  .calendar-search {
    min-height: 2.4rem;
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-3));
    display: flex;
    align-items: center;
    gap: 0.55rem;
    padding: 0 0.8rem;
  }

  .calendar-search input {
    min-width: 0;
    flex: 1;
    border: 0;
    outline: 0;
    background: transparent;
    color: rgb(var(--text-1));
    font-size: 0.84rem;
  }

  .calendar-search input::placeholder { color: rgb(var(--text-3)); }
  .calendar-list-block { display: grid; gap: 0.18rem; }

  .calendar-list-title {
    padding: 0 0.5rem;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
  }

  .calendar-list-row {
    min-height: 2.7rem;
    border-radius: 8px;
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    align-items: center;
    gap: 0.65rem;
    padding: 0.35rem 0.5rem;
    color: rgb(var(--text-1));
    text-align: left;
  }

  button.calendar-list-row:hover:not(:disabled),
  label.calendar-list-row:hover,
  .calendar-list-row:focus-visible {
    background: rgb(var(--surface-2));
    outline: none;
  }

  .calendar-list-row:disabled { opacity: 0.58; cursor: default; }

  .calendar-list-dot,
  .calendar-list-check {
    width: 0.8rem;
    height: 0.8rem;
    border-radius: 3px;
    background: currentColor;
  }

  .calendar-list-check {
    appearance: none;
    margin: 0;
    border: 2px solid var(--dot);
    background: transparent;
    cursor: pointer;
  }

  .calendar-list-check:checked { background: var(--dot); }
  .calendar-list-dot-pending { background: transparent !important; border: 2px dashed #916dfe; }
  .calendar-list-dot-primary, .calendar-list-dot-violet { background: #916dfe; }
  .calendar-list-dot-booking, .calendar-list-dot-green { background: #2ba640; }
  .calendar-list-dot-blue { background: rgb(14 165 233); }
  .calendar-list-dot-amber { background: rgb(245 158 11); }
  .calendar-list-dot-rose { background: rgb(244 63 94); }
  .calendar-list-dot-slate { background: rgb(var(--text-3)); }
  .calendar-list-check-violet { --dot: #916dfe; }
  .calendar-list-check-green { --dot: #2ba640; }
  .calendar-list-check-blue { --dot: rgb(14 165 233); }
  .calendar-list-check-amber { --dot: rgb(245 158 11); }
  .calendar-list-check-rose { --dot: rgb(244 63 94); }
  .calendar-list-check-slate { --dot: rgb(var(--text-3)); }
  .calendar-list-copy { min-width: 0; }

  .calendar-list-copy strong,
  .calendar-list-copy small {
    display: block;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .calendar-list-copy strong { font-size: 0.86rem; font-weight: 650; }
  .calendar-list-copy small { margin-top: 0.08rem; color: rgb(var(--text-3)); font-size: 0.72rem; }
  .calendar-list-action { color: rgb(var(--text-3)); font-size: 0.9rem; }

  .calendar-list-icon {
    width: 2rem;
    height: 2rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: rgb(var(--text-2));
  }

  .calendar-list-icon:hover { background: rgb(var(--surface-3)); color: rgb(var(--text-1)); }

  .time-format-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    color: rgb(var(--text-3));
    font-size: 0.75rem;
    font-weight: 650;
    text-transform: uppercase;
  }

  .time-format-control {
    display: inline-grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    overflow: hidden;
    border-radius: 999px;
    background: rgb(var(--surface-2));
    padding: 0.18rem;
    text-transform: none;
  }

  .time-format-control button {
    min-width: 2.6rem;
    border-radius: 999px;
    color: rgb(var(--text-3));
    font-size: 0.72rem;
    font-weight: 700;
    padding: 0.28rem 0.45rem;
  }

  .time-format-control button:hover,
  .time-format-active {
    background: rgb(var(--surface-0));
    color: rgb(var(--text-1));
  }

  .file-actions { display: flex; gap: 0.5rem; }
  .file-actions button { flex: 1; gap: 0.4rem; font-size: 0.8rem; }
</style>
