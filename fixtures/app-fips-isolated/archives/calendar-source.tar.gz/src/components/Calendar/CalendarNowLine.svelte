<script lang="ts">
  interface Props {
    topPercent: number;
    testId?: string;
  }

  let { topPercent, testId = 'calendar-now-line' }: Props = $props();
</script>

<div class="calendar-now-line" style:top={`${topPercent}%`} data-testid={testId} aria-hidden="true">
  <span class="calendar-now-dot"></span>
</div>

<style>
  .calendar-now-line {
    position: absolute;
    left: 0;
    right: 0;
    z-index: 6;
    pointer-events: none;
    border-top: 1px solid rgb(244 63 94 / 0.92);
    filter: drop-shadow(0 0 6px rgb(244 63 94 / 0.3));
  }

  .calendar-now-dot {
    position: absolute;
    left: -0.22rem;
    top: -0.23rem;
    width: 0.46rem;
    height: 0.46rem;
    border-radius: 999px;
    background: rgb(244 63 94);
    box-shadow: 0 0 0 2px rgb(var(--surface-1));
  }
</style>
