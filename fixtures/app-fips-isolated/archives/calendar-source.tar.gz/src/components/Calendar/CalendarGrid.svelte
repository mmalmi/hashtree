<script lang="ts">
  import type { CalendarData, CalendarEvent } from '../../lib/calendar';
  import { eventsForDay, formatTime, monthMatrix, toDateInputValue, WEEKDAY_LABELS } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    monthDate: Date;
    selectedDate: Date;
    onSelectDate: (date: Date) => void;
    onEditEvent: (event: CalendarEvent) => void;
  }

  let { data, monthDate, selectedDate, onSelectDate, onEditEvent }: Props = $props();

  let days = $derived(monthMatrix(monthDate, data.startOfWeek));
  let weekdayLabels = $derived(data.startOfWeek === 'monday'
    ? [...WEEKDAY_LABELS.slice(1), WEEKDAY_LABELS[0]]
    : WEEKDAY_LABELS);

  function sameDay(a: Date, b: Date): boolean {
    return toDateInputValue(a) === toDateInputValue(b);
  }

  function eventClass(event: CalendarEvent): string {
    return ({
      violet: 'border-accent bg-accent/12 text-accent',
      green: 'border-success bg-success/12 text-success',
      blue: 'border-sky-500 bg-sky-500/12 text-sky-400',
      amber: 'border-amber-500 bg-amber-500/12 text-amber-400',
      rose: 'border-rose-500 bg-rose-500/12 text-rose-400',
      slate: 'border-text-3 bg-surface-2 text-text-1',
    } as const)[event.color];
  }

  function isAvailable(day: Date): boolean {
    return data.availability.rules.some(rule => rule.weekday === day.getDay() && rule.enabled);
  }

  function eventPillLabel(event: CalendarEvent): string {
    return event.allDay ? event.title : `${formatTime(event.start, data.timeFormat)} ${event.title}`;
  }

  function eventAccessibleLabel(event: CalendarEvent, day: Date): string {
    if (event.allDay) return `${event.title} full-day ${toDateInputValue(day)}`;
    return `${event.title} ${formatTime(event.start, data.timeFormat)} - ${formatTime(event.end, data.timeFormat)}`;
  }
</script>

<div class="calendar-grid grid grid-cols-7 gap-px overflow-hidden rounded-lg border" data-testid="calendar-grid">
  {#each weekdayLabels as label, index (index)}
    <div class="calendar-grid-header h-8 sm:h-9 md:h-10 flex items-center px-2 sm:px-3 text-[11px] font-semibold uppercase text-text-3 bg-surface-1/95">
      {label}
    </div>
  {/each}

  {#each days as day (toDateInputValue(day))}
    {@const dayEvents = eventsForDay(data.events, day)}
    {@const isCurrentMonth = day.getMonth() === monthDate.getMonth()}
    {@const isSelected = sameDay(day, selectedDate)}
    {@const isToday = sameDay(day, new Date())}
    <div
      role="button"
      tabindex="0"
      class="calendar-day min-h-[5.4rem] sm:min-h-[6rem] md:min-h-[6.8rem] xl:min-h-[8.25rem] p-1.5 sm:p-2 md:p-2.5 text-left hover:bg-surface-1 focus:outline-none focus:ring-1 focus:ring-accent focus:ring-inset {isSelected ? 'calendar-day-selected' : 'bg-surface-0'} {!isCurrentMonth ? 'calendar-day-outside' : ''} {!isAvailable(day) ? 'calendar-day-unavailable' : ''}"
      aria-pressed={isSelected}
      onclick={() => onSelectDate(new Date(day))}
      onkeydown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onSelectDate(new Date(day));
        }
      }}
    >
      <div class="mb-1.5 flex items-center justify-between md:mb-2">
        <span class="day-number {isCurrentMonth ? 'text-text-2' : 'text-text-3'} {isToday ? 'today-number text-accent' : ''}">
          {day.getDate()}
        </span>
        {#if dayEvents.length > 3}
          <span class="rounded-full bg-surface-2 px-1.5 py-0.5 text-[10px] text-text-3">+{dayEvents.length - 3}</span>
        {/if}
      </div>
      <div class="space-y-1">
        {#each dayEvents.slice(0, 3) as event (event.id)}
          <button
            type="button"
            class="event-pill flex w-full items-center overflow-hidden rounded-md border-l-2 px-2 py-1.5 text-[11px] leading-tight shadow-sm {eventClass(event)}"
            data-testid="calendar-event-pill"
            aria-label={eventAccessibleLabel(event, day)}
            onclick={(eventClick) => {
              eventClick.stopPropagation();
              onEditEvent(event);
            }}
          >
            <span class="w-full truncate font-medium">{eventPillLabel(event)}</span>
          </button>
        {/each}
      </div>
    </div>
  {/each}
</div>

<style>
  .calendar-grid {
    --calendar-grid-line: rgb(var(--surface-3));
    background: var(--calendar-grid-line);
    border-color: var(--calendar-grid-line);
    isolation: isolate;
  }

  .calendar-grid-header {
    position: sticky;
    top: 0;
    z-index: 1;
  }

  .calendar-day {
    position: relative;
    transition: background-color 120ms ease, box-shadow 120ms ease, transform 120ms ease;
  }

  .calendar-day:hover {
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.18);
  }

  .calendar-day-selected {
    background: rgb(145 109 254 / 0.11);
    box-shadow: inset 0 0 0 2px rgb(145 109 254 / 0.56);
  }

  .calendar-day-outside {
    opacity: 0.58;
  }

  .calendar-day-unavailable {
    background-image: repeating-linear-gradient(
      135deg,
      rgb(var(--surface-2) / 0.18) 0,
      rgb(var(--surface-2) / 0.18) 1px,
      transparent 1px,
      transparent 8px
    );
  }

  .day-number {
    min-width: 1.45rem;
    height: 1.45rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .today-number {
    background: rgb(145 109 254);
    color: white;
  }

  .event-pill {
    backdrop-filter: blur(6px);
  }

  @media (max-width: 520px) {
    .calendar-grid {
      width: calc(100% + 2rem);
      margin-inline: -1rem;
      border-inline: 0;
      border-radius: 0;
    }

    .event-pill {
      min-height: 0.38rem;
      border-left-width: 0;
      border-radius: 999px;
      padding: 0;
      color: transparent;
    }

    .event-pill span {
      display: none;
    }
  }

  @media (min-width: 1100px) {
    .calendar-grid {
      min-height: calc(100dvh - 10.9rem);
    }

    .calendar-day {
      min-height: calc((100dvh - 13.4rem) / 6);
    }
  }
</style>
