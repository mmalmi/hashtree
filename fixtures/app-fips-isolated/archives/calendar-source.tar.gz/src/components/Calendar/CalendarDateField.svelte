<script lang="ts">
  import { monthMatrix, parseDateInputValue, toDateInputValue, WEEKDAY_LABELS } from '../../lib/calendar';

  interface Props {
    label: string;
    value: string;
    onChange: (value: string) => void;
    min?: string;
    startOfWeek?: 'monday' | 'sunday';
    testId?: string;
    ariaLabel?: string;
    allowEmpty?: boolean;
    placeholder?: string;
  }

  let {
    label,
    value,
    onChange,
    min = '',
    startOfWeek = 'monday',
    testId,
    ariaLabel = label,
    allowEmpty = false,
    placeholder = 'YYYY-MM-DD',
  }: Props = $props();

  let open = $state(false);
  let inputValue = $state('');
  let pickerMonth = $state(new Date());
  let field = $state<HTMLElement | null>(null);
  let syncedValue = $state('');

  let days = $derived(monthMatrix(pickerMonth, startOfWeek));
  let weekdayLabels = $derived(startOfWeek === 'monday'
    ? [...WEEKDAY_LABELS.slice(1), WEEKDAY_LABELS[0]]
    : WEEKDAY_LABELS);

  $effect(() => {
    if (value === syncedValue) return;
    syncedValue = value;
    inputValue = value;
    const parsed = parseDateText(value);
    if (parsed) pickerMonth = parsed;
  });

  function parseDateText(raw: string): Date | null {
    const text = raw.trim();
    const isoDate = parseDateInputValue(text);
    if (isoDate) return isoDate;

    const local = /^(\d{1,2})[.](\d{1,2})[.](\d{4})$/.exec(text);
    if (local) return parseDateInputValue(`${local[3]}-${local[2]!.padStart(2, '0')}-${local[1]!.padStart(2, '0')}`);

    const compact = /^(\d{4})(\d{2})(\d{2})$/.exec(text);
    if (compact) return parseDateInputValue(`${compact[1]}-${compact[2]}-${compact[3]}`);

    return null;
  }

  function commit(raw: string) {
    if (allowEmpty && !raw.trim()) {
      inputValue = '';
      onChange('');
      return;
    }
    const parsed = parseDateText(raw);
    if (!parsed) {
      inputValue = value;
      return;
    }

    const nextValue = toDateInputValue(parsed);
    inputValue = nextValue;
    onChange(nextValue);
  }

  function handleInput(raw: string) {
    inputValue = raw;
    if (allowEmpty && !raw.trim()) {
      onChange('');
      open = false;
      return;
    }
    const parsed = parseDateText(raw);
    if (!parsed) return;
    onChange(toDateInputValue(parsed));
    open = false;
  }

  function handleKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      event.preventDefault();
      commit(inputValue);
      open = false;
    }
    if (event.key === 'Escape') {
      open = false;
      inputValue = value;
    }
  }

  function handleFocusout() {
    window.setTimeout(() => {
      if (!field?.isConnected) return;
      if (document.activeElement instanceof Node && field.contains(document.activeElement)) return;
      commit(inputValue);
      open = false;
    }, 0);
  }

  function chooseDay(day: Date) {
    if (isDisabled(day)) return;
    const nextValue = toDateInputValue(day);
    inputValue = nextValue;
    onChange(nextValue);
    open = false;
  }

  function shiftMonth(months: number) {
    pickerMonth = new Date(pickerMonth.getFullYear(), pickerMonth.getMonth() + months, 1);
  }

  function isSelected(day: Date): boolean {
    return toDateInputValue(day) === value;
  }

  function isToday(day: Date): boolean {
    return toDateInputValue(day) === toDateInputValue(new Date());
  }

  function isDisabled(day: Date): boolean {
    return Boolean(min) && toDateInputValue(day) < min;
  }

  function fullDayLabel(day: Date): string {
    return new Intl.DateTimeFormat(undefined, {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }).format(day);
  }
</script>

<div class="date-field space-y-1" bind:this={field} onfocusout={handleFocusout}>
  <span class="block text-xs text-text-3">{label}</span>
  <div class="date-input-shell">
    <input
      class="input w-full pr-10"
      type="text"
      inputmode="numeric"
      autocomplete="off"
      {placeholder}
      aria-label={ariaLabel}
      data-testid={testId}
      value={inputValue}
      onfocus={() => open = true}
      oninput={(event) => handleInput((event.currentTarget as HTMLInputElement).value)}
      onkeydown={handleKeydown}
    />
    <button
      type="button"
      class="date-picker-button"
      aria-label={`Choose ${ariaLabel.toLowerCase()}`}
      aria-expanded={open}
      onclick={() => open = !open}
    >
      <span class="i-lucide-calendar-days"></span>
    </button>

    {#if open}
      <div class="date-popover" role="group" aria-label={`${ariaLabel} picker`}>
        <div class="date-popover-head">
          <button type="button" class="date-nav" aria-label="Previous month" onclick={() => shiftMonth(-1)}>
            <span class="i-lucide-chevron-left"></span>
          </button>
          <strong>{new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(pickerMonth)}</strong>
          <button type="button" class="date-nav" aria-label="Next month" onclick={() => shiftMonth(1)}>
            <span class="i-lucide-chevron-right"></span>
          </button>
        </div>
        <div class="date-grid">
          {#each weekdayLabels as weekday, index (index)}
            <span class="date-weekday">{weekday.slice(0, 1)}</span>
          {/each}
          {#each days as day (toDateInputValue(day))}
            {@const currentMonth = day.getMonth() === pickerMonth.getMonth()}
            <button
              type="button"
              class="date-day {isSelected(day) ? 'date-day-selected' : ''} {isToday(day) ? 'date-day-today' : ''} {currentMonth ? '' : 'date-day-muted'}"
              disabled={isDisabled(day)}
              aria-label={fullDayLabel(day)}
              onclick={() => chooseDay(day)}
            >
              {day.getDate()}
            </button>
          {/each}
        </div>
      </div>
    {/if}
  </div>
</div>

<style>
  .date-field {
    position: relative;
  }

  .date-input-shell {
    position: relative;
    display: block;
  }

  .date-picker-button {
    position: absolute;
    right: 0.25rem;
    top: 50%;
    width: 2rem;
    height: 2rem;
    transform: translateY(-50%);
    border-radius: 999px;
    color: rgb(var(--text-2));
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .date-picker-button:hover {
    color: rgb(var(--text-1));
    background: rgb(var(--surface-2));
  }

  .date-popover {
    position: absolute;
    z-index: 60;
    left: 0;
    top: calc(100% + 0.35rem);
    width: min(18rem, calc(100vw - 3rem));
    padding: 0.75rem;
    border: 1px solid rgb(var(--surface-3));
    border-radius: 8px;
    background: rgb(var(--surface-1));
    box-shadow: 0 18px 44px rgb(0 0 0 / 0.28);
  }

  .date-popover-head {
    display: grid;
    grid-template-columns: 2rem minmax(0, 1fr) 2rem;
    align-items: center;
    gap: 0.35rem;
    margin-bottom: 0.5rem;
    text-align: center;
    font-size: 0.82rem;
  }

  .date-nav,
  .date-day {
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .date-nav {
    width: 2rem;
    height: 2rem;
    color: rgb(var(--text-2));
  }

  .date-nav:hover {
    color: rgb(var(--text-1));
    background: rgb(var(--surface-2));
  }

  .date-grid {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 0.18rem;
    text-align: center;
  }

  .date-weekday {
    height: 1.5rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: rgb(var(--text-3));
    font-size: 0.62rem;
    font-weight: 700;
    text-transform: uppercase;
  }

  .date-day {
    height: 1.95rem;
    color: rgb(var(--text-2));
    font-size: 0.75rem;
  }

  .date-day:hover:not(:disabled) {
    background: rgb(var(--surface-2));
    color: rgb(var(--text-1));
  }

  .date-day-selected {
    background: rgb(145 109 254 / 0.2);
    color: #916dfe;
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.5);
  }

  .date-day-today:not(.date-day-selected) {
    color: #916dfe;
    font-weight: 750;
  }

  .date-day-muted {
    opacity: 0.45;
  }

  .date-day:disabled {
    opacity: 0.28;
    cursor: default;
  }
</style>
