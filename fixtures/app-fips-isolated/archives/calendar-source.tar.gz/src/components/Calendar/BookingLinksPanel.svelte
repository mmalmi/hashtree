<script lang="ts">
  import type { BookingLink, CalendarData } from '../../lib/calendar';
  import { computeBookingSlots, formatTime, toDateInputValue, updateBookingLink } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    selectedDate: Date;
    onRemove: (linkId: string) => void;
    onCopy: (link: BookingLink) => void;
    onChange: (data: CalendarData) => void;
  }

  let { data, selectedDate, onRemove, onCopy, onChange }: Props = $props();
  type LinkPatch = Partial<Pick<BookingLink, 'title' | 'slug' | 'durationMinutes' | 'enabled'>>;
  let confirmingDeleteId = $state<string | null>(null);
  let copiedId = $state<string | null>(null);

  function patch(link: BookingLink, changes: LinkPatch): BookingLink {
    confirmingDeleteId = null;
    const next = updateBookingLink(data, link.id, changes, data.ownerNpub);
    onChange(next);
    return next.bookingLinks.find(item => item.id === link.id) ?? link;
  }

  function copy(link: BookingLink) {
    confirmingDeleteId = null;
    onCopy(link);
    copiedId = link.id;
    setTimeout(() => copiedId === link.id && (copiedId = null), 2000);
  }

  function removeLink(link: BookingLink) {
    if (confirmingDeleteId !== link.id) {
      confirmingDeleteId = link.id;
      return;
    }
    confirmingDeleteId = null;
    onRemove(link.id);
  }
</script>

<section class="space-y-4" data-testid="booking-link-panel">
  {#if data.bookingLinks.length === 0}
    <div class="text-sm text-text-3">No booking links.</div>
  {:else}
    <div class="space-y-3">
      {#each data.bookingLinks as link (link.id)}
        {@const slots = computeBookingSlots(data, link.id, selectedDate).slice(0, 5)}
        <div class="booking-link-card space-y-3" data-testid="booking-link-card">
          <div class="flex items-end gap-2">
            <label class="min-w-0 flex-1 space-y-1">
              <span class="field-label">Title</span>
              <input
                class="input w-full"
                data-booking-field="title"
                value={link.title}
                aria-label="Booking link title"
                oninput={(event) => patch(link, { title: (event.currentTarget as HTMLInputElement).value })}
              />
            </label>
            <button
              class="btn-circle bg-surface-2 hover:bg-surface-3"
              aria-label={copiedId === link.id ? 'Booking link copied' : 'Copy booking link'}
              title="Copy booking link"
              onclick={() => copy(link)}
            >
              <span class={copiedId === link.id ? 'i-lucide-check' : 'i-lucide-copy'}></span>
            </button>
            <button class="btn-circle bg-surface-2 hover:bg-surface-3" aria-label="Open booking link" onclick={() => window.location.hash = `#/book/${encodeURIComponent(link.slug)}`}>
              <span class="i-lucide-external-link"></span>
            </button>
            <button
              class="btn-circle {confirmingDeleteId === link.id ? 'bg-danger/20 text-danger hover:bg-danger/25' : 'bg-surface-2 hover:bg-surface-3'}"
              aria-label={confirmingDeleteId === link.id ? 'Confirm delete booking link' : 'Delete booking link'}
              title={confirmingDeleteId === link.id ? 'Confirm delete booking link' : 'Delete booking link'}
              onclick={() => removeLink(link)}
            >
              <span class={confirmingDeleteId === link.id ? 'i-lucide-check' : 'i-lucide-trash-2'}></span>
            </button>
          </div>

          <div class="grid grid-cols-[1fr_5rem] gap-2">
            <label class="space-y-1">
              <span class="field-label">Slug</span>
              <input
                class="input w-full"
                data-booking-field="slug"
                value={link.slug}
                aria-label="Booking link slug"
                oninput={(event) => {
                  const input = event.currentTarget as HTMLInputElement;
                  input.value = patch(link, { slug: input.value }).slug;
                }}
              />
            </label>
            <label class="space-y-1">
              <span class="field-label">Min</span>
              <input
                class="input w-full"
                data-booking-field="duration"
                type="number"
                min="5"
                step="5"
                value={link.durationMinutes}
                aria-label="Booking link duration"
                onchange={(event) => patch(link, { durationMinutes: Number((event.currentTarget as HTMLInputElement).value) })}
              />
            </label>
          </div>

          <label class="enabled-toggle">
            <input
              data-booking-field="enabled"
              type="checkbox"
              checked={link.enabled}
              onchange={(event) => patch(link, { enabled: (event.currentTarget as HTMLInputElement).checked })}
            />
            Enabled
          </label>

          <div class="space-y-1.5">
            <div class="field-label">Next slots</div>
            {#if slots.length > 0}
              <div class="flex flex-wrap gap-1.5">
                {#each slots as slot (slot.start)}
                  <span class="slot-chip">{formatTime(slot.start, data.timeFormat)}</span>
                {/each}
              </div>
            {:else}
              <span class="text-xs text-text-3">No slots on {toDateInputValue(selectedDate)}</span>
            {/if}
          </div>
        </div>
      {/each}
    </div>
  {/if}
</section>

<style>
  .booking-link-card {
    border: 1px solid rgb(var(--surface-3) / 0.78);
    border-radius: 8px;
    background: rgb(var(--surface-0) / 0.58);
    padding: 0.75rem;
  }

  .enabled-toggle {
    width: fit-content;
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    border-radius: 999px;
    background: rgb(var(--surface-2) / 0.75);
    color: rgb(var(--text-2));
    padding: 0.32rem 0.62rem;
    font-size: 0.8rem;
  }

  .field-label {
    display: block;
    color: rgb(var(--text-3));
    font-size: 0.68rem;
    font-weight: 600;
    text-transform: uppercase;
  }

  .slot-chip {
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-2));
    padding: 0.25rem 0.55rem;
    font-size: 0.75rem;
    line-height: 1;
  }
</style>
