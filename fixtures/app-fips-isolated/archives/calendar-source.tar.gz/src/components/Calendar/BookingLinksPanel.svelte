<script lang="ts">
  import CopyButton from '@iris/svelte-ui/CopyButton.svelte';
  import type { BookingLink, CalendarData } from '../../lib/calendar';
  import { computeBookingSlots, formatTime, toDateInputValue, updateBookingLink } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    selectedDate: Date;
    actor: string;
    onAdd: () => void;
    onRemove: (linkId: string) => void;
    onChange: (data: CalendarData) => void;
    embedded?: boolean;
    showHeader?: boolean;
  }

  let { data, selectedDate, actor, onAdd, onRemove, onChange, embedded = false, showHeader = true }: Props = $props();
  type BookingLinkDraft = Pick<BookingLink, 'title' | 'slug' | 'durationMinutes' | 'enabled'>;
  let drafts = $state<Record<string, BookingLinkDraft>>({});
  let confirmingDeleteId = $state<string | null>(null);

  function bookingUrl(link: BookingLink): string {
    return `https://calendar.iris.to/#/book/${encodeURIComponent(link.slug)}`;
  }

  function draftFor(link: BookingLink): BookingLinkDraft {
    return drafts[link.id] ?? {
      title: link.title,
      slug: link.slug,
      durationMinutes: link.durationMinutes,
      enabled: link.enabled,
    };
  }

  function patchLink(link: BookingLink, patch: Partial<BookingLinkDraft>): BookingLinkDraft {
    confirmingDeleteId = null;
    const draft = { ...draftFor(link), ...patch };
    const nextData = updateBookingLink(data, link.id, draft, actor);
    const nextLink = nextData.bookingLinks.find(item => item.id === link.id);
    const nextDraft = nextLink ? {
      title: nextLink.title,
      slug: nextLink.slug,
      durationMinutes: nextLink.durationMinutes,
      enabled: nextLink.enabled,
    } : draft;
    drafts[link.id] = nextDraft;
    onChange(nextData);
    return nextDraft;
  }

  function patchSlug(link: BookingLink, input: HTMLInputElement) {
    const draft = patchLink(link, { slug: input.value });
    input.value = draft.slug;
  }

  function currentSlug(link: BookingLink): string {
    return draftFor(link).slug || link.slug;
  }

  function copyLinkText(link: BookingLink): string {
    return bookingUrl({ ...link, slug: currentSlug(link) });
  }

  function beforeCopyLink(): void {
    confirmingDeleteId = null;
  }

  function openLink(link: BookingLink) {
    confirmingDeleteId = null;
    window.location.hash = `#/book/${encodeURIComponent(currentSlug(link))}`;
  }

  function removeLink(link: BookingLink) {
    if (confirmingDeleteId !== link.id) {
      confirmingDeleteId = link.id;
      return;
    }
    confirmingDeleteId = null;
    onRemove(link.id);
  }

  function formatSlot(value: string): string {
    return formatTime(value, data.timeFormat);
  }
</script>

<section class={embedded ? 'space-y-4' : 'calendar-panel p-4 space-y-4'} data-testid="booking-link-panel">
  {#if showHeader}
    <div class="flex items-center justify-between gap-3">
      <div>
        <h2 class="text-sm font-semibold text-text-1">Booking Links</h2>
        <div class="text-xs text-text-3">{data.bookingLinks.length}</div>
      </div>
      <button class="btn-circle bg-surface-2 hover:bg-surface-3" onclick={() => { confirmingDeleteId = null; onAdd(); }} aria-label="New booking link" title="New booking link">
        <span class="i-lucide-plus"></span>
      </button>
    </div>
  {/if}

  {#if data.bookingLinks.length === 0}
    <div class="text-sm text-text-3">No booking links.</div>
  {:else}
    <div class="space-y-3">
      {#each data.bookingLinks as link (link.id)}
        {@const draft = draftFor(link)}
        {@const slots = computeBookingSlots(data, link.id, selectedDate).slice(0, 5)}
        <div class="booking-link-card space-y-3" data-testid="booking-link-card">
          <div class="flex items-end gap-2">
            <label class="min-w-0 flex-1 space-y-1">
              <span class="field-label">Title</span>
              <input
                class="input w-full"
                data-booking-field="title"
                value={draft.title}
                aria-label="Booking link title"
                oninput={(event) => patchLink(link, { title: (event.currentTarget as HTMLInputElement).value })}
              />
            </label>
            <CopyButton
              text={copyLinkText(link)}
              label=""
              copiedLabel=""
              class="btn-circle bg-surface-2 hover:bg-surface-3"
              ariaLabel="Copy booking link"
              copiedAriaLabel="Booking link copied"
              title="Copy booking link"
              copiedTitle="Copied"
              iconClass="i-lucide-copy"
              copiedIconClass="i-lucide-check"
              onBeforeCopy={beforeCopyLink}
            />
            <button class="btn-circle bg-surface-2 hover:bg-surface-3" aria-label="Open booking link" onclick={() => openLink(link)}>
              <span class="i-lucide-external-link"></span>
            </button>
            <button
              class="btn-circle {confirmingDeleteId === link.id ? 'bg-danger/20 text-danger hover:bg-danger/25' : 'bg-surface-2 hover:bg-surface-3'}"
              aria-label={confirmingDeleteId === link.id ? 'Confirm delete booking link' : 'Delete booking link'}
              title={confirmingDeleteId === link.id ? 'Confirm delete booking link' : 'Delete booking link'}
              onclick={() => removeLink(link)}
            >
              <span class={confirmingDeleteId === link.id ? 'i-lucide-check' : 'i-lucide-trash-2'}></span>
            </button>
          </div>

          <div class="grid grid-cols-[1fr_5rem] gap-2">
            <label class="space-y-1">
              <span class="field-label">Slug</span>
              <input
                class="input w-full"
                data-booking-field="slug"
                value={draft.slug}
                aria-label="Booking link slug"
                oninput={(event) => patchSlug(link, event.currentTarget as HTMLInputElement)}
              />
            </label>
            <label class="space-y-1">
              <span class="field-label">Min</span>
              <input
                class="input w-full"
                data-booking-field="duration"
                type="number"
                min="5"
                step="5"
                value={draft.durationMinutes}
                aria-label="Booking link duration"
                oninput={(event) => patchLink(link, { durationMinutes: Number((event.currentTarget as HTMLInputElement).value) })}
              />
            </label>
          </div>

          <label class="enabled-toggle">
            <input
              data-booking-field="enabled"
              type="checkbox"
              checked={draft.enabled}
              onchange={(event) => patchLink(link, { enabled: (event.currentTarget as HTMLInputElement).checked })}
            />
            Enabled
          </label>

          <div class="space-y-1.5">
            <div class="field-label">Next slots</div>
            {#if slots.length > 0}
              <div class="flex flex-wrap gap-1.5">
                {#each slots as slot (slot.start)}
                  <span class="slot-chip">{formatSlot(slot.start)}</span>
                {/each}
              </div>
            {:else}
              <span class="text-xs text-text-3">No slots on {toDateInputValue(selectedDate)}</span>
            {/if}
          </div>
        </div>
      {/each}
    </div>
  {/if}
</section>

<style>
  .booking-link-card {
    border: 1px solid rgb(var(--surface-3) / 0.78);
    border-radius: 8px;
    background: rgb(var(--surface-0) / 0.58);
    padding: 0.75rem;
  }

  .enabled-toggle {
    width: fit-content;
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    border-radius: 999px;
    background: rgb(var(--surface-2) / 0.75);
    color: rgb(var(--text-2));
    padding: 0.32rem 0.62rem;
    font-size: 0.8rem;
  }

  .field-label {
    display: block;
    color: rgb(var(--text-3));
    font-size: 0.68rem;
    font-weight: 600;
    text-transform: uppercase;
  }

  .slot-chip {
    border-radius: 999px;
    background: rgb(var(--surface-2));
    color: rgb(var(--text-2));
    padding: 0.25rem 0.55rem;
    font-size: 0.75rem;
    line-height: 1;
  }
</style>
