<script lang="ts">
  import { tick } from 'svelte';
  import CopyButton from '@iris/svelte-ui/CopyButton.svelte';
  import CalendarDateField from './CalendarDateField.svelte';
  import type { BookingSlot, CalendarData, EventDraft } from '../../lib/calendar';
  import { computeBookingSlots, findNextBookingDate, formatTime, parseDateInputValue, toDateInputValue } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    slug: string;
    selectedDate: Date;
    showBack?: boolean;
    onSelectDate: (date: Date) => void;
    onBack: () => void;
    onBookSlot: (draft: EventDraft) => void;
  }

  let { data, slug, selectedDate, showBack = true, onSelectDate, onBack, onBookSlot }: Props = $props();
  let selectedSlot = $state<BookingSlot | null>(null);
  let bookedSlot = $state<BookingSlot | null>(null);
  let guestName = $state('');
  let guestNote = $state('');
  let confirmForm = $state<HTMLElement | null>(null);
  let guestNameInput = $state<HTMLInputElement | null>(null);
  let autoSelectedSlug = $state('');

  let link = $derived(data.bookingLinks.find(item => item.slug === slug && item.enabled) ?? null);
  let slots = $derived(link ? computeBookingSlots(data, link.id, selectedDate).slice(0, 18) : []);
  let slotCountLabel = $derived(slots.length === 1 ? '1 slot' : `${slots.length} slots`);

  $effect(() => {
    if (selectedSlot && !slots.some(slot => slot.start === selectedSlot?.start)) {
      selectedSlot = null;
    }
  });

  $effect(() => {
    if (!link || autoSelectedSlug === link.slug) return;
    autoSelectedSlug = link.slug;
    if (slots.length > 0) return;

    const nextDate = findNextBookingDate(data, link.id, selectedDate);
    if (nextDate && toDateInputValue(nextDate) !== toDateInputValue(selectedDate)) {
      onSelectDate(nextDate);
    }
  });

  $effect(() => {
    if (!selectedSlot) return;
    void tick().then(() => {
      confirmForm?.scrollIntoView({ block: 'nearest' });
      guestNameInput?.focus({ preventScroll: true });
    });
  });

  function formatDay(date: Date): string {
    return new Intl.DateTimeFormat(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    }).format(date);
  }

  function formatSlot(start: string, end: string): string {
    return `${formatTime(start, data.timeFormat)} - ${formatTime(end, data.timeFormat)}`;
  }

  function handleDateChange(value: string) {
    const next = parseDateInputValue(value);
    if (next) {
      if (toDateInputValue(next) === toDateInputValue(selectedDate)) return;
      selectedSlot = null;
      bookedSlot = null;
      onSelectDate(next);
    }
  }

  function selectSlot(slot: BookingSlot) {
    selectedSlot = slot;
    bookedSlot = null;
    guestName = '';
    guestNote = '';
  }

  function selectedSlotCopyText(): string {
    if (!selectedSlot) return '';
    const title = link?.title ?? 'Meeting';
    return `${title} · ${formatDay(selectedDate)} · ${formatSlot(selectedSlot.start, selectedSlot.end)}`;
  }

  function notesForBooking(): string {
    const lines = [`Booked from /book/${slug}`, `Guest: ${guestName.trim()}`];
    if (guestNote.trim()) lines.push(guestNote.trim());
    return lines.join('\n');
  }

  function bookSelectedSlot(event: SubmitEvent) {
    event.preventDefault();
    if (!selectedSlot || !link || !guestName.trim()) return;
    const slot = selectedSlot;
    onBookSlot({
      title: `${link.title}: ${guestName.trim()}`,
      start: slot.start,
      end: slot.end,
      color: 'green',
      notes: notesForBooking(),
    });
    bookedSlot = slot;
    selectedSlot = null;
    guestName = '';
    guestNote = '';
  }
</script>

<section class="booking-page calendar-panel overflow-hidden">
  <div class="booking-topbar flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between md:p-5">
    {#if showBack}
      <button class="btn-ghost shrink-0 self-start" onclick={onBack} aria-label="Back to calendar">
        <span class="i-lucide-arrow-left mr-1"></span>
        Calendar
      </button>
    {/if}
    <div class="w-full md:w-56">
      <CalendarDateField
        label="Date"
        value={toDateInputValue(selectedDate)}
        startOfWeek={data.startOfWeek}
        testId="booking-date-input"
        onChange={handleDateChange}
      />
    </div>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-[20rem_minmax(0,1fr)]">
    <aside class="booking-meta p-5 md:p-6">
      <div class="mb-5 flex h-11 w-11 items-center justify-center rounded-lg bg-accent text-white">
        <span class="i-lucide-calendar"></span>
      </div>
      <h2 class="truncate text-2xl font-semibold text-text-1">{link?.title ?? 'Booking link not found'}</h2>
      <div class="mt-4 space-y-3 text-sm text-text-2">
        <div class="flex items-center gap-2">
          <span class="i-lucide-calendar text-text-3"></span>
          {formatDay(selectedDate)}
        </div>
        {#if link}
          <div class="flex items-center gap-2">
            <span class="i-lucide-clock text-text-3"></span>
            {link.durationMinutes} min
          </div>
        {/if}
        <div class="flex items-center gap-2">
          <span class="i-lucide-globe text-text-3"></span>
          {data.timezone}
        </div>
      </div>
    </aside>

    <div class="p-5 md:p-6">
      {#if !link}
        <div class="booking-empty">
          Booking link not found.
        </div>
      {:else}
        <div class="mb-4 flex items-center justify-between gap-3">
          <h3 class="text-sm font-semibold text-text-1">Available Times</h3>
          <span class="text-xs text-text-3">{slotCountLabel}</span>
        </div>

        {#if selectedSlot}
          <form class="selected-slot" data-testid="booking-confirm-form" bind:this={confirmForm} onsubmit={bookSelectedSlot}>
            <div class="selected-slot-summary">
              <div class="min-w-0">
                <div class="text-xs font-semibold uppercase text-text-3">Selected</div>
                <div class="truncate text-sm text-text-1">{formatSlot(selectedSlot.start, selectedSlot.end)}</div>
              </div>
              <CopyButton
                text={selectedSlotCopyText()}
                label="Copy"
                copiedLabel="Copied"
                class="btn-ghost shrink-0"
                iconClass="i-lucide-copy mr-1"
                copiedIconClass="i-lucide-check mr-1"
              />
            </div>
            <label class="space-y-1">
              <span class="block text-xs text-text-3">Name</span>
              <input
                class="input w-full"
                placeholder="Your name"
                bind:this={guestNameInput}
                bind:value={guestName}
                data-testid="booking-guest-name-input"
              />
            </label>
            <label class="space-y-1">
              <span class="block text-xs text-text-3">Note</span>
              <textarea class="textarea w-full min-h-20" placeholder="Note" bind:value={guestNote}></textarea>
            </label>
            <div class="flex justify-end">
              <button class="btn-success" type="submit" disabled={!guestName.trim()} data-testid="booking-book-button">
                Book
              </button>
            </div>
          </form>
        {:else if bookedSlot}
          <div class="booking-confirmed" role="status" data-testid="booking-confirmed">
            <span class="i-lucide-check"></span>
            <div class="min-w-0">
              <div class="text-sm font-semibold text-text-1">Booked</div>
              <div class="truncate text-xs text-text-2">{formatDay(selectedDate)} · {formatSlot(bookedSlot.start, bookedSlot.end)}</div>
            </div>
          </div>
        {/if}

        {#if slots.length === 0}
          <div class="booking-empty">
            No slots on {toDateInputValue(selectedDate)}.
          </div>
        {:else}
          <div class="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {#each slots as slot (slot.start)}
              <button
                class="slot-button text-left {selectedSlot?.start === slot.start ? 'slot-button-selected' : ''}"
                type="button"
                aria-pressed={selectedSlot?.start === slot.start}
                onclick={() => selectSlot(slot)}
              >
                {formatSlot(slot.start, slot.end)}
              </button>
            {/each}
          </div>
        {/if}
      {/if}
    </div>
  </div>
</section>

<style>
  .booking-topbar {
    border-bottom: 1px solid rgb(var(--surface-3) / 0.76);
    background: rgb(var(--surface-1) / 0.72);
  }

  .booking-meta {
    border-right: 1px solid rgb(var(--surface-3) / 0.76);
    background: rgb(var(--surface-0) / 0.4);
  }

  .slot-button {
    min-height: 2.75rem;
    border-radius: 8px;
    border: 1px solid rgb(var(--surface-3));
    background: rgb(var(--surface-0) / 0.62);
    color: rgb(var(--text-1));
    padding: 0.75rem 0.9rem;
    font-size: 0.875rem;
    transition: background-color 120ms ease, border-color 120ms ease, transform 120ms ease;
  }

  .slot-button:hover {
    border-color: #916dfe;
    background: rgb(145 109 254 / 0.12);
    transform: translateY(-1px);
  }

  .slot-button-selected {
    border-color: #916dfe;
    background: rgb(145 109 254 / 0.18);
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.44);
  }

  .selected-slot {
    margin-bottom: 1rem;
    border-radius: 8px;
    border: 1px solid rgb(145 109 254 / 0.42);
    background: rgb(145 109 254 / 0.1);
    display: grid;
    gap: 0.75rem;
    padding: 0.85rem;
  }

  .selected-slot-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
  }

  .booking-confirmed {
    margin-bottom: 1rem;
    border-radius: 8px;
    border: 1px solid rgb(34 197 94 / 0.38);
    background: rgb(34 197 94 / 0.1);
    color: rgb(74 222 128);
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.85rem;
  }

  .booking-empty {
    border: 1px dashed rgb(var(--surface-3));
    border-radius: 8px;
    color: rgb(var(--text-3));
    padding: 1rem;
    font-size: 0.875rem;
  }

  @media (max-width: 1023px) {
    .booking-meta {
      border-right: 0;
      border-bottom: 1px solid rgb(var(--surface-3) / 0.76);
    }
  }
</style>
