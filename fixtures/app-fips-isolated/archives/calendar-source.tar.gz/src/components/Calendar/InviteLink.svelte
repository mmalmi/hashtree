<script lang="ts">
  import { copyToClipboard } from '@iris/svelte-ui/clipboard';
  import { nostrStore } from '../../nostr';
  import { inviteUrl, newLinkKey } from '../../lib/calendar';

  interface Props {
    /** The link secret in the editor, and the one already saved. */
    value?: string;
    saved?: string;
    onChange: (key: string | undefined) => void;
  }

  let { value, saved, onChange }: Props = $props();
  let copied = $state(false);

  async function copy() {
    const key = value ?? newLinkKey();
    if (!value) onChange(key);
    if (!$nostrStore.npub || await copyToClipboard(inviteUrl($nostrStore.npub, key)) !== 'copied') return;
    copied = true;
    setTimeout(() => copied = false, 2000);
  }
</script>

<div class="flex min-w-0 flex-1 flex-wrap items-center gap-2">
  <button type="button" class="btn-ghost" onclick={copy} data-testid="calendar-event-invite-link">
    <span class={copied ? 'i-lucide-check' : 'i-lucide-link'}></span>
    {copied ? 'Link copied' : value ? 'Copy invite link' : 'Create invite link'}
  </button>
  {#if value}
    <button type="button" class="btn-ghost" onclick={() => onChange(undefined)}>Turn off</button>
    <span class="text-xs text-text-3">
      {value === saved ? 'Anyone with the link can see this event and answer.' : 'Save to turn the link on.'}
    </span>
  {/if}
</div>
