<script lang="ts">
  import { onMount, tick } from 'svelte';
  import type { CalendarData, CalendarEvent } from '../../lib/calendar';
  import { buildTimedEventSegments, eventsForDay, formatHourLabel, formatTime, toDateInputValue, type TimedEventSegment } from '../../lib/calendar';
  import CalendarNowLine from './CalendarNowLine.svelte';

  interface Props {
    data: CalendarData;
    selectedDate: Date;
    onEditEvent: (event: CalendarEvent) => void;
    onNewEvent: (date?: Date) => void;
  }

  const HOURS = Array.from({ length: 24 }, (_, hour) => hour);
  const DAY_MINUTES = 24 * 60;
  const MINUTE_MS = 60 * 1000;

  let { data, selectedDate, onEditEvent, onNewEvent }: Props = $props();
  let dayScroll = $state<HTMLElement | null>(null);
  let now = $state(new Date());
  let scrollKey = '';

  let dayEvents = $derived(eventsForDay(data.events, selectedDate));
  let availability = $derived(data.availability.rules.find(rule => rule.weekday === selectedDate.getDay()) ?? null);
  let allDayEvents = $derived(dayEvents.filter(event => event.allDay));
  let timedSegments = $derived(buildTimedEventSegments(dayEvents));
  let showNowLine = $derived(toDateInputValue(now) === toDateInputValue(selectedDate));
  let nowTopPercent = $derived(((now.getHours() * 60 + now.getMinutes()) / DAY_MINUTES) * 100);

  onMount(() => {
    now = new Date();
    const timer = window.setInterval(() => {
      now = new Date();
    }, 60_000);
    return () => window.clearInterval(timer);
  });

  $effect(() => {
    const key = `${toDateInputValue(selectedDate)}:${availability?.startTime ?? '09:00'}`;
    if (key === scrollKey) return;
    scrollKey = key;
    void tick().then(() => scrollToWorkdayStart());
  });

  function startOfDay(day: Date): Date {
    return new Date(day.getFullYear(), day.getMonth(), day.getDate());
  }

  function nextDay(day: Date): Date {
    return new Date(day.getFullYear(), day.getMonth(), day.getDate() + 1);
  }

  function eventClass(event: CalendarEvent): string {
    return ({
      violet: 'border-accent bg-accent/18 text-accent',
      green: 'border-success bg-success/18 text-success',
      blue: 'border-sky-500 bg-sky-500/18 text-sky-300',
      amber: 'border-amber-500 bg-amber-500/18 text-amber-300',
      rose: 'border-rose-500 bg-rose-500/18 text-rose-300',
      slate: 'border-text-3 bg-surface-2 text-text-1',
    } as const)[event.color];
  }

  function dayTitle(date: Date): string {
    return new Intl.DateTimeFormat(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    }).format(date);
  }

  function hourLabel(hour: number): string {
    return formatHourLabel(hour, data.timeFormat);
  }

  function availabilityLabel(): string {
    if (!availability?.enabled) return 'Unavailable';
    return `${availability.startTime} - ${availability.endTime}`;
  }

  function eventAccessibleLabel(event: CalendarEvent): string {
    return `${event.title} ${formatTime(event.start, data.timeFormat)} - ${formatTime(event.end, data.timeFormat)}`;
  }

  function workdayStartHour(): number {
    const [hourText] = (availability?.enabled ? availability.startTime : '09:00').split(':');
    const hour = Number(hourText);
    return Number.isFinite(hour) ? Math.min(23, Math.max(0, hour)) : 9;
  }

  function scrollToWorkdayStart() {
    if (!dayScroll) return;
    const firstCell = dayScroll.querySelector<HTMLElement>('.day-hour-cell');
    const cellHeight = firstCell?.getBoundingClientRect().height ?? 52;
    dayScroll.scrollTop = Math.max(0, (workdayStartHour() - 1) * cellHeight);
  }

  function eventPositionStyle(event: CalendarEvent): string {
    const dayStart = startOfDay(selectedDate).getTime();
    const dayEnd = nextDay(selectedDate).getTime();
    const eventStart = Math.max(new Date(event.start).getTime(), dayStart);
    const eventEnd = Math.min(new Date(event.end).getTime(), dayEnd);
    const startMinutes = Math.max(0, (eventStart - dayStart) / MINUTE_MS);
    const durationMinutes = Math.max(15, (eventEnd - eventStart) / MINUTE_MS);
    const top = Math.min(100, Math.max(0, startMinutes / DAY_MINUTES * 100));
    const height = Math.min(100 - top, durationMinutes / DAY_MINUTES * 100);
    return `top: ${top}%; height: max(1.9rem, ${height}%);`;
  }

  function timedSegmentStyle(segment: TimedEventSegment): string {
    const gap = 0.35;
    const width = 100 / segment.laneCount;
    const left = segment.lane * width;
    return `${eventPositionStyle(segment.event)} left: calc(${left}% + ${gap}rem); right: calc(${100 - left - width}% + ${gap}rem);`;
  }

  function hourDate(hour: number): Date {
    return new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), hour, 0, 0, 0);
  }

  function hourActionLabel(hour: number): string {
    return `Create event ${dayTitle(selectedDate)} at ${hourLabel(hour)}`;
  }
</script>

<section class="day-view calendar-panel overflow-hidden" data-testid="calendar-day-view">
  <div class="day-view-head flex flex-col gap-3 border-b p-4 md:flex-row md:items-center md:justify-between">
    <div class="min-w-0">
      <h3 class="truncate text-base font-semibold text-text-1">{dayTitle(selectedDate)}</h3>
      <div class="mt-1 text-xs text-text-3">{availabilityLabel()}</div>
    </div>
  </div>

  <div class="day-scroll" bind:this={dayScroll}>
    <div class="day-all-day">
      <div class="day-all-day-label">All day</div>
      <div class="day-all-day-cell" data-testid="calendar-day-all-day-cell">
        {#if allDayEvents.length > 0}
          {#each allDayEvents as event (event.id)}
            <button class="day-all-day-event border-l-2 {eventClass(event)}" onclick={() => onEditEvent(event)}>
              {event.title}
            </button>
          {/each}
        {/if}
      </div>
    </div>

    <div class="day-grid">
      <div class="day-time-gutter">
        {#each HOURS as hour (hour)}
          <div>{hourLabel(hour)}</div>
        {/each}
      </div>

      <div class="day-column">
        <div class="day-hour-cells">
          {#each HOURS as hour (hour)}
            <button class="day-hour-cell" aria-label={hourActionLabel(hour)} onclick={() => onNewEvent(hourDate(hour))}></button>
          {/each}
        </div>

        {#each timedSegments as segment (segment.event.id)}
          <button
            class="day-event absolute overflow-hidden rounded-md border-l-2 px-2 py-1 text-left text-xs leading-tight shadow-sm {eventClass(segment.event)}"
            style={timedSegmentStyle(segment)}
            aria-label={eventAccessibleLabel(segment.event)}
            onclick={() => onEditEvent(segment.event)}
          >
            <span class="block truncate font-semibold">
              <span class="font-medium opacity-80">{formatTime(segment.event.start, data.timeFormat)}</span>
              {segment.event.title}
            </span>
          </button>
        {/each}
        {#if showNowLine}
          <CalendarNowLine topPercent={nowTopPercent} testId="calendar-day-now-line" />
        {/if}
      </div>
    </div>
  </div>
</section>

<style>
  .day-view {
    --day-hour-height: 3.25rem;
    --calendar-grid-line: rgb(var(--surface-3));
    --calendar-grid-line-soft: rgb(var(--surface-3) / 0.86);
  }

  .day-view-head {
    border-color: var(--calendar-grid-line);
  }

  .day-scroll {
    overflow: auto;
    max-height: min(72vh, 46rem);
  }

  .day-all-day,
  .day-grid {
    display: grid;
    grid-template-columns: 4rem minmax(18rem, 1fr);
    min-width: 34rem;
  }

  .day-all-day {
    position: sticky;
    top: 0;
    z-index: 4;
    background: rgb(var(--surface-1));
    border-bottom: 1px solid var(--calendar-grid-line);
  }

  .day-all-day-label {
    min-height: 2.8rem;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0.5rem 0.55rem;
    color: rgb(var(--text-3));
    font-size: 0.68rem;
  }

  .day-all-day-cell {
    min-height: 2.8rem;
    border-left: 1px solid var(--calendar-grid-line);
    padding: 0.35rem;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.35rem;
  }

  .day-all-day-event {
    max-width: 18rem;
    min-height: 1.5rem;
    border-radius: 6px;
    padding: 0.2rem 0.45rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 0.72rem;
    line-height: 1.1;
    text-align: left;
  }

  .day-time-gutter {
    display: grid;
    grid-template-rows: repeat(24, var(--day-hour-height));
    color: rgb(var(--text-3));
    font-size: 0.68rem;
    text-align: right;
  }

  .day-time-gutter div {
    padding: 0.2rem 0.55rem 0 0;
    border-top: 1px solid var(--calendar-grid-line-soft);
  }

  .day-column {
    position: relative;
    min-height: calc(24 * var(--day-hour-height));
    border-left: 1px solid var(--calendar-grid-line);
    background-image: repeating-linear-gradient(
      to bottom,
      var(--calendar-grid-line-soft) 0,
      var(--calendar-grid-line-soft) 1px,
      transparent 1px,
      transparent var(--day-hour-height)
    );
  }

  .day-hour-cells {
    display: grid;
    grid-template-rows: repeat(24, var(--day-hour-height));
    height: 100%;
  }

  .day-hour-cell {
    min-height: var(--day-hour-height);
  }

  .day-hour-cell:hover {
    background: rgb(145 109 254 / 0.06);
  }

  .day-event {
    z-index: 2;
    backdrop-filter: blur(8px);
    transition: transform 120ms ease, box-shadow 120ms ease;
  }

  .day-event:hover {
    z-index: 3;
    transform: translateY(-1px);
    box-shadow: 0 10px 24px rgb(0 0 0 / 0.22);
  }
</style>
