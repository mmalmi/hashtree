<script lang="ts">
  import type { CalendarData, CalendarView } from '../../lib/calendar';
  import { eventsForDay, monthMatrix, toDateInputValue, WEEKDAY_LABELS, yearMonths } from '../../lib/calendar';

  interface Props {
    data: CalendarData;
    monthDate: Date;
    selectedDate: Date;
    onSelectDate: (date: Date) => void;
    onSelectView: (view: CalendarView) => void;
  }

  let { data, monthDate, selectedDate, onSelectDate, onSelectView }: Props = $props();

  let months = $derived(yearMonths(monthDate));
  let weekdayLabels = $derived(data.startOfWeek === 'monday'
    ? [...WEEKDAY_LABELS.slice(1), WEEKDAY_LABELS[0]]
    : WEEKDAY_LABELS);

  function sameDay(a: Date, b: Date): boolean {
    return toDateInputValue(a) === toDateInputValue(b);
  }

  function isAvailable(day: Date): boolean {
    return data.availability.rules.some(rule => rule.weekday === day.getDay() && rule.enabled);
  }

  function monthLabel(date: Date): string {
    return new Intl.DateTimeFormat(undefined, { month: 'long' }).format(date);
  }

  function fullDayLabel(date: Date, eventCount: number): string {
    const day = new Intl.DateTimeFormat(undefined, {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
    if (eventCount === 0) return day;
    return `${day}, ${eventCount === 1 ? '1 event' : `${eventCount} events`}`;
  }

  function monthKey(date: Date): string {
    return `${date.getFullYear()}-${date.getMonth()}`;
  }

  function dayKey(month: Date, day: Date): string {
    return `${monthKey(month)}-${toDateInputValue(day)}`;
  }

  function openMonth(date: Date) {
    onSelectDate(new Date(date));
    onSelectView('month');
  }

  function openDay(date: Date) {
    onSelectDate(new Date(date));
    onSelectView('day');
  }
</script>

<div class="year-view grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3" data-testid="calendar-year-view">
  {#each months as month (monthKey(month))}
    <section class="calendar-panel year-month p-3">
      <button class="mb-2 flex w-full items-center justify-between gap-2 text-left" onclick={() => openMonth(month)}>
        <h3 class="truncate text-sm font-semibold text-text-1">{monthLabel(month)}</h3>
        <span class="text-xs text-text-3">{month.getFullYear()}</span>
      </button>

      <div class="grid grid-cols-7 gap-1 text-center">
        {#each weekdayLabels as label, index (index)}
          <div class="h-5 text-[10px] font-medium uppercase text-text-3 flex items-center justify-center">
            {label.slice(0, 1)}
          </div>
        {/each}
        {#each monthMatrix(month, data.startOfWeek) as day (dayKey(month, day))}
          {@const currentMonth = day.getMonth() === month.getMonth()}
          {@const selected = sameDay(day, selectedDate)}
          {@const today = sameDay(day, new Date())}
          {@const eventCount = eventsForDay(data.events, day).length}
          <button
            type="button"
            class="year-day {selected ? 'year-day-selected' : ''} {today ? 'year-day-today' : ''} {currentMonth ? 'text-text-2' : 'text-text-3/60'} {!isAvailable(day) ? 'year-day-muted' : ''}"
            aria-pressed={selected}
            aria-label={fullDayLabel(day, eventCount)}
            onclick={() => openDay(day)}
          >
            <span>{day.getDate()}</span>
            {#if eventCount > 0}
              <i aria-hidden="true"></i>
            {/if}
          </button>
        {/each}
      </div>
    </section>
  {/each}
</div>

<style>
  .year-month {
    min-width: 0;
  }

  .year-day {
    position: relative;
    height: 1.65rem;
    border-radius: 999px;
    font-size: 0.68rem;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 120ms ease, color 120ms ease, box-shadow 120ms ease;
  }

  .year-day:hover {
    background: rgb(var(--surface-2) / 0.72);
    color: rgb(var(--text-1));
  }

  .year-day-selected {
    background: rgb(145 109 254 / 0.18);
    color: #916dfe;
    box-shadow: inset 0 0 0 1px rgb(145 109 254 / 0.45);
  }

  .year-day-today:not(.year-day-selected) {
    color: #916dfe;
    font-weight: 700;
  }

  .year-day-muted {
    background-image: repeating-linear-gradient(
      135deg,
      rgb(var(--surface-2) / 0.18) 0,
      rgb(var(--surface-2) / 0.18) 1px,
      transparent 1px,
      transparent 6px
    );
  }

  .year-day i {
    position: absolute;
    width: 3px;
    height: 3px;
    border-radius: 999px;
    bottom: 3px;
    background: currentColor;
  }
</style>
