<script lang="ts">
  import { onDestroy, onMount, tick } from 'svelte';
  import { cid, toHex, type CID } from '@hashtree/core';
  import { copyToClipboard } from '@iris/svelte-ui/clipboard';
  import CalendarToolbar from './CalendarToolbar.svelte';
  import CalendarWorkbench from './CalendarWorkbench.svelte';
  import EventEditor from './EventEditor.svelte';
  import BookingPage from './BookingPage.svelte';
  import { nostrStore } from '../../nostr';
  import { createTreesStore, type TreeEntry } from '../../stores';
  import {
    CALENDAR_TREE_NAME,
    addBookingLink,
    dayLabel,
    eventsForDay,
    loadCalendarData,
    monthDayLabel,
    monthLabel,
    parseCalendarViewRoute,
    removeBookingLink,
    removeCalendarEvent,
    saveCalendarData,
    startOfLocalDay,
    type AvailabilitySettings,
    type BookingLink,
    type CalendarData,
    type CalendarEvent,
    type CalendarView,
    type EventDraft,
    upsertCalendarEvent,
    upcomingEvents,
    updateAvailability,
    weekDays,
    createCalendarTree,
    formatCalendarRoute,
  } from '../../lib/calendar';

  const AUTO_CREATE_CALENDAR_DELAY_MS = 1500;

  let userNpub = $derived($nostrStore.npub);
  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let treesStore = $derived(createTreesStore(userNpub));
  let trees = $state<TreeEntry[]>([]);
  let treesReady = $state(false);
  let data = $state<CalendarData | null>(null);
  let selectedDate = $state(new Date());
  let monthDate = $state(new Date());
  let view = $state<CalendarView>('month');
  let loading = $state(false);
  let creating = $state(false);
  let saving = $state(false);
  let error = $state('');
  let status = $state('');
  let editorOpen = $state(false);
  let editingEvent = $state<CalendarEvent | null>(null);
  let editorDate = $state(new Date());
  let hashPath = $state('/');
  let bookingHasCalendarBack = $state(false);
  let calendarShell = $state<HTMLElement | null>(null);
  let loadedRoot: CID | undefined;
  let loadKey = '';
  let dataRevision = 0;
  let saveTail: Promise<void> = Promise.resolve();
  let autoCreateKey = '';
  let scrollResetView: CalendarView = 'month';
  let scrollResetPath = '/';
  let applyingCalendarRoute = false;
  let mounted = $state(false);
  let statusClearTimer: number | null = null;

  let calendarEntry = $derived(trees.find(tree => tree.name === CALENDAR_TREE_NAME) ?? null);
  let bookingSlug = $derived.by(() => {
    const match = hashPath.match(/^\/book\/([^/?#]+)/);
    return match ? decodeRouteSegment(match[1]) : null;
  });
  let selectedDayEvents = $derived(data ? eventsForDay(data.events, selectedDate) : []);
  let upcoming = $derived(data ? upcomingEvents(data.events) : []);
  let totalEvents = $derived(data?.events.length ?? 0);
  let enabledBookingLinks = $derived(data?.bookingLinks.filter(link => link.enabled) ?? []);
  let firstBookingLink = $derived(enabledBookingLinks[0] ?? data?.bookingLinks[0] ?? null);
  let selectedAvailability = $derived.by(() => {
    if (!data) return null;
    return data.availability.rules.find(rule => rule.weekday === selectedDate.getDay()) ?? null;
  });

  function decodeRouteSegment(value: string): string {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }

  onMount(() => {
    mounted = true;
    let hashInitialized = false;
    const syncHash = () => {
      const nextHashPath = window.location.hash.slice(1) || '/';
      const isBookingRoute = /^\/book\/[^/?#]+/.test(nextHashPath);
      const wasBookingRoute = /^\/book\/[^/?#]+/.test(hashPath);
      if (hashInitialized) {
        if (isBookingRoute && !wasBookingRoute) {
          bookingHasCalendarBack = true;
        } else if (!isBookingRoute) {
          bookingHasCalendarBack = false;
        }
      } else {
        bookingHasCalendarBack = false;
        hashInitialized = true;
      }
      hashPath = nextHashPath;
      const calendarRoute = parseCalendarViewRoute(nextHashPath);
      if (!isBookingRoute && calendarRoute) {
        applyingCalendarRoute = true;
        view = calendarRoute.view;
        selectedDate = calendarRoute.date;
        monthDate = calendarRoute.date;
        applyingCalendarRoute = false;
      }
    };
    syncHash();
    window.addEventListener('hashchange', syncHash);
    return () => window.removeEventListener('hashchange', syncHash);
  });

  onDestroy(() => {
    if (statusClearTimer) {
      window.clearTimeout(statusClearTimer);
    }
  });

  $effect(() => {
    const store = treesStore;
    treesReady = false;
    trees = [];
    const unsubscribe = store.subscribe(value => {
      trees = value;
      treesReady = true;
    });
    return unsubscribe;
  });

  $effect(() => {
    const entry = calendarEntry;
    const owner = userNpub;
    if (!mounted || !owner || !entry || saving || creating) {
      return;
    }

    const nextLoadKey = `${entry.hashHex}:${entry.encryptionKey ? 'keyed' : 'bare'}`;
    if (nextLoadKey === loadKey) return;
    const revision = dataRevision;
    let cancelled = false;
    loading = true;
    error = '';
    void loadCalendarData({
      hash: entry.hash,
      encryptionKey: entry.encryptionKey,
    }, owner)
      .then((loaded) => {
        if (cancelled || revision !== dataRevision) return;
        loadedRoot = cid(entry.hash, entry.encryptionKey);
        loadKey = nextLoadKey;
        data = loaded;
      })
      .catch((err) => {
        if (cancelled || revision !== dataRevision) return;
        console.error('[Calendar] load failed', err);
        error = 'Could not load the private calendar root.';
      })
      .finally(() => {
        if (!cancelled) loading = false;
      });
    return () => {
      cancelled = true;
      loading = false;
    };
  });

  $effect(() => {
    const owner = userNpub;
    const entry = calendarEntry;
    if (!mounted || !isLoggedIn || !owner || !treesReady || entry || data || loading || creating) {
      return;
    }

    const nextAutoCreateKey = `${owner}:${CALENDAR_TREE_NAME}`;
    if (autoCreateKey === nextAutoCreateKey) return;

    const timer = window.setTimeout(() => {
      if (!mounted || !isLoggedIn || !userNpub || calendarEntry || data || loading || creating) {
        return;
      }
      autoCreateKey = nextAutoCreateKey;
      void createDefaultCalendar();
    }, AUTO_CREATE_CALENDAR_DELAY_MS);

    return () => window.clearTimeout(timer);
  });

  $effect(() => {
    if (!mounted || view === scrollResetView) return;
    scrollResetView = view;
    void tick().then(resetCalendarScroll);
  });

  $effect(() => {
    if (!mounted || hashPath === scrollResetPath) return;
    scrollResetPath = hashPath;
    void tick().then(resetCalendarScroll);
  });

  function resetCalendarScroll() {
    calendarShell?.scrollTo({ top: 0, left: 0 });
    window.scrollTo({ top: 0, left: 0 });
  }

  function addDays(date: Date, count: number): Date {
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate() + count,
      date.getHours(),
      date.getMinutes(),
      date.getSeconds(),
      date.getMilliseconds(),
    );
  }

  function weekRangeLabel(date: Date): string {
    const days = weekDays(date, data?.startOfWeek ?? 'monday');
    return `${monthDayLabel(days[0] ?? date)} - ${monthDayLabel(days[6] ?? date)}`;
  }

  function calendarTitle(): string {
    if (view === 'day') return dayLabel(selectedDate);
    if (view === 'week') return weekRangeLabel(selectedDate);
    if (view === 'year') return `${monthDate.getFullYear()}`;
    if (view === 'agenda') return 'Agenda';
    return monthLabel(monthDate);
  }

  function availabilityLabel(): string {
    if (!selectedAvailability?.enabled) return 'Unavailable';
    return `${selectedAvailability.startTime} - ${selectedAvailability.endTime}`;
  }

  function bookingUrl(link: BookingLink): string {
    return `https://calendar.iris.to/#/book/${encodeURIComponent(link.slug)}`;
  }

  function setStatus(message: string, clearAfterMs = 0) {
    if (statusClearTimer) {
      window.clearTimeout(statusClearTimer);
      statusClearTimer = null;
    }
    status = message;
    if (message && clearAfterMs > 0) {
      statusClearTimer = window.setTimeout(() => {
        if (status === message) {
          status = '';
        }
        statusClearTimer = null;
      }, clearAfterMs);
    }
  }

  function activeRouteDate(nextView = view, nextSelectedDate = selectedDate, nextMonthDate = monthDate): Date {
    return nextView === 'month' || nextView === 'year' ? nextMonthDate : nextSelectedDate;
  }

  function writeCalendarRoute(nextView = view, nextSelectedDate = selectedDate, nextMonthDate = monthDate) {
    if (!mounted || applyingCalendarRoute || bookingSlug) return;
    const nextPath = formatCalendarRoute(nextView, activeRouteDate(nextView, nextSelectedDate, nextMonthDate));
    if (nextPath === hashPath) return;
    hashPath = nextPath;
    window.location.hash = nextPath;
  }

  function shiftCurrentView(count: number) {
    if (view === 'day') {
      selectDate(addDays(selectedDate, count));
      return;
    }

    if (view === 'week') {
      selectDate(addDays(selectedDate, count * 7));
      return;
    }

    if (view === 'year') {
      const nextMonth = new Date(monthDate.getFullYear() + count, monthDate.getMonth(), 1);
      const nextSelected = new Date(selectedDate.getFullYear() + count, selectedDate.getMonth(), selectedDate.getDate());
      monthDate = nextMonth;
      selectedDate = nextSelected;
      writeCalendarRoute(view, nextSelected, nextMonth);
      return;
    }

    const nextMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + count, 1);
    monthDate = nextMonth;
    writeCalendarRoute(view, selectedDate, nextMonth);
  }

  function shiftMiniMonth(count: number) {
    const nextMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + count, 1);
    monthDate = nextMonth;
    if (view === 'month' || view === 'year') writeCalendarRoute(view, selectedDate, nextMonth);
  }

  function selectDate(date: Date) {
    const day = startOfLocalDay(date);
    selectedDate = day;
    monthDate = day;
    writeCalendarRoute(view, day, day);
  }

  function selectView(nextView: CalendarView) {
    view = nextView;
    monthDate = selectedDate;
    writeCalendarRoute(nextView, selectedDate, selectedDate);
  }

  function selectToday() {
    selectDate(new Date());
  }

  function openNewEvent(date?: Date | Event) {
    editorDate = date instanceof Date ? date : selectedDate;
    if (date instanceof Date) {
      selectDate(date);
    }
    editingEvent = null;
    editorOpen = true;
  }

  function openEditEvent(event: CalendarEvent) {
    editingEvent = data?.events.find(item => item.id === (event.recurrenceSourceId ?? event.id)) ?? event;
    editorOpen = true;
  }

  async function copyPrimaryBookingLink() {
    if (!firstBookingLink) return;
    const result = await copyToClipboard(bookingUrl(firstBookingLink));
    if (result === 'copied') {
      setStatus('Link copied', 2200);
    }
  }

  async function persist(nextData: CalendarData, successMessage = 'Saved') {
    const revision = ++dataRevision;
    data = nextData;
    saving = true;
    setStatus('Saving');
    error = '';
    try {
      // Keep root publications in edit order while showing the latest edit immediately.
      const pending = saveTail.then(async () => {
        if (!loadedRoot || userNpub !== nextData.ownerNpub) throw new Error('Calendar root unavailable');
        const result = await saveCalendarData(nextData, loadedRoot);
        if (result.success && userNpub === nextData.ownerNpub) loadedRoot = result.rootCid;
        return result;
      });
      saveTail = pending.then(() => undefined, () => undefined);
      const result = await pending;
      if (!result.success) {
        throw new Error('saveHashtree returned success=false');
      }
      if (revision !== dataRevision) return;
      loadKey = `${toHex(result.rootCid.hash)}:${result.rootCid.key ? 'keyed' : 'bare'}`;
      setStatus(successMessage, 2600);
    } catch (err) {
      if (revision !== dataRevision) return;
      console.error('[Calendar] save failed', err);
      error = 'Could not save the calendar root.';
      setStatus('');
    } finally {
      if (revision === dataRevision) saving = false;
    }
  }

  async function createDefaultCalendar() {
    if (creating) return;
    creating = true;
    error = '';
    setStatus('Preparing');
    try {
      const result = await createCalendarTree();
      if (!result.success || !result.data) {
        error = 'Could not prepare a private calendar.';
        return;
      }
      loadedRoot = result.rootCid;
      data = result.data;
      setStatus('');
    } catch (err) {
      console.error('[Calendar] create failed', err);
      error = 'Could not prepare a private calendar.';
    } finally {
      creating = false;
    }
  }

  function handleSaveEvent(draft: EventDraft) {
    if (!data || !userNpub) return;
    const next = upsertCalendarEvent(data, draft, userNpub);
    const eventDate = new Date(draft.start);
    if (!Number.isNaN(eventDate.getTime())) {
      selectDate(eventDate);
    }
    editorOpen = false;
    editingEvent = null;
    void persist(next);
  }

  function handleDeleteEvent(eventId: string) {
    if (!data || !userNpub) return;
    editorOpen = false;
    editingEvent = null;
    void persist(removeCalendarEvent(data, eventId, userNpub));
  }

  function handleAvailabilityChange(availability: AvailabilitySettings) {
    if (!data || !userNpub) return;
    void persist(updateAvailability(data, availability, userNpub));
  }

  function handleBookingDataChange(next: CalendarData) {
    if (!userNpub) return;
    void persist({ ...next, updatedAt: Date.now(), updatedBy: userNpub });
  }

  function handleBookSlot(draft: EventDraft) {
    if (!data || !userNpub) return;
    selectDate(new Date(draft.start));
    void persist(upsertCalendarEvent(data, draft, userNpub));
  }

  function handleAddBookingLink() {
    if (!data || !userNpub) return;
    void persist(addBookingLink(data, userNpub));
  }

  function handleRemoveBookingLink(linkId: string) {
    if (!data || !userNpub) return;
    void persist(removeBookingLink(data, linkId, userNpub));
  }

  function closeBookingRoute() {
    window.location.hash = formatCalendarRoute(view, activeRouteDate());
  }
</script>

<main class="calendar-shell flex-1 overflow-auto" bind:this={calendarShell}>
  <div class="calendar-shell-inner mx-auto space-y-4">
    {#if !bookingSlug}
      <CalendarToolbar
        title={calendarTitle()}
        {view}
        {saving}
        {status}
        onPrevious={() => shiftCurrentView(-1)}
        onNext={() => shiftCurrentView(1)}
        onToday={selectToday}
        onSelectView={selectView}
      />
    {/if}

    {#if error}
      <div class="flex items-center justify-between gap-3 rounded-lg border border-danger/40 bg-danger/8 p-3 text-sm text-danger">
        <span>{error}</span>
        {#if !data}<button class="btn-ghost border border-danger/30 px-3 py-1 text-xs text-danger hover:bg-danger/10" disabled={creating} onclick={createDefaultCalendar}>{creating ? 'Retrying...' : 'Try again'}</button>{/if}
      </div>
    {/if}

    {#if !isLoggedIn}
      <div class="calendar-panel p-6 text-sm text-text-2">
        Preparing a local Iris identity...
      </div>
    {:else if loading && !data}
      <div class="calendar-panel p-6 text-sm text-text-2">
        Loading private calendar...
      </div>
    {:else if !data && !calendarEntry && !error}
      <div class="calendar-panel p-6 text-sm text-text-2">
        Preparing private calendar...
      </div>
    {:else if data && bookingSlug}
      <BookingPage
        {data}
        slug={bookingSlug}
        {selectedDate}
        showBack={bookingHasCalendarBack}
        onSelectDate={selectDate}
        onBack={closeBookingRoute}
        onBookSlot={handleBookSlot}
      />
    {:else if data}
      <CalendarWorkbench
        {data}
        {view}
        {monthDate}
        {selectedDate}
        {selectedDayEvents}
        {totalEvents}
        {enabledBookingLinks}
        {firstBookingLink}
        actor={userNpub || ''}
        availabilityText={availabilityLabel()}
        {upcoming}
        onSelectDate={selectDate}
        onPreviousMonth={() => shiftMiniMonth(-1)}
        onNextMonth={() => shiftMiniMonth(1)}
        onNewEvent={openNewEvent}
        onCopyPrimaryBookingLink={copyPrimaryBookingLink}
        onToday={selectToday}
        onEditEvent={openEditEvent}
        onAvailabilityChange={handleAvailabilityChange}
        onAddBookingLink={handleAddBookingLink}
        onRemoveBookingLink={handleRemoveBookingLink}
        onBookingDataChange={handleBookingDataChange}
        onSelectView={selectView}
      />
    {/if}
  </div>
</main>

<EventEditor
  open={editorOpen}
  event={editingEvent}
  selectedDate={editorDate}
  startOfWeek={data?.startOfWeek ?? 'monday'}
  onClose={() => {
    editorOpen = false;
    editingEvent = null;
  }}
  onSave={handleSaveEvent}
  onDelete={handleDeleteEvent}
/>

<style>
  .calendar-shell {
    background: rgb(var(--surface-0));
  }

  .calendar-shell-inner {
    max-width: 96rem;
    padding: 0.85rem 1rem 1rem;
  }

  :global(.calendar-panel) {
    border: 1px solid rgb(var(--surface-3) / 0.82);
    background: rgb(var(--surface-1) / 0.94);
    border-radius: 8px;
    box-shadow: none;
  }

  @media (min-width: 920px) {
    .calendar-shell-inner {
      padding: 0.75rem 1.5rem 1.25rem;
    }
  }

  @media (min-width: 1440px) {
    .calendar-shell-inner {
      max-width: none;
    }
  }

</style>
