<script lang="ts">
  import { onMount, tick, untrack } from 'svelte';
  import { nip19 } from 'nostr-tools';
  import { copyToClipboard } from '@iris/svelte-ui/clipboard';
  import CalendarToolbar from './CalendarToolbar.svelte';
  import CalendarSidebar from './CalendarSidebar.svelte';
  import CalendarAgendaView from './CalendarAgendaView.svelte';
  import CalendarDayView from './CalendarDayView.svelte';
  import CalendarGrid from './CalendarGrid.svelte';
  import CalendarWeekView from './CalendarWeekView.svelte';
  import CalendarYearView from './CalendarYearView.svelte';
  import EventEditor from './EventEditor.svelte';
  import EventDetails from './EventDetails.svelte';
  import ShareDialog from './ShareDialog.svelte';
  import BookingPage, { type BookingRequest } from './BookingPage.svelte';
  import InvitePage from './InvitePage.svelte';
  import { nostrStore } from '../../nostr';
  import { CalendarSession } from '../../lib/calendar/session.svelte';
  import { watchCalendarView } from '../../lib/calendar/storage';
  import {
    BOOKING_TREE_NAME,
    addBookingLink,
    applyImportedCalendarEvents,
    bookingUrl,
    changeMessages,
    dayLabel,
    eventsForDay,
    formatCalendarRoute,
    isNpub,
    isShownEvent,
    monthDayLabel,
    monthLabel,
    newLinkKey,
    parseCalendarFile,
    parseCalendarViewRoute,
    removeBookingLink,
    removeCalendarEvent,
    serializeCalendarIcs,
    setEventRsvp,
    sortEvents,
    startOfLocalDay,
    touchCalendar,
    upcomingEvents,
    upsertCalendarEvent,
    weekDays,
    type BookingLink,
    type CalendarData,
    type CalendarEvent,
    type CalendarView,
    type EventDraft,
    type OutgoingMessage,
    type RsvpStatus,
  } from '../../lib/calendar';

  let userNpub = $derived($nostrStore.npub);
  let pubkey = $derived($nostrStore.pubkey);
  // Login sets the key and npub one after the other; a session needs both of the same account.
  let session = $derived(userNpub && pubkey && nip19.npubEncode(pubkey) === userNpub ? new CalendarSession(userNpub, pubkey) : null);
  let data = $derived(session?.data ?? null);
  let viewData = $derived(data && session ? { ...data, events: session.events } : null);
  let selectedDate = $state(startOfLocalDay(new Date()));
  let monthDate = $state(startOfLocalDay(new Date()));
  let view = $state<CalendarView>('month');
  let hashPath = $state(window.location.hash.slice(1) || '/');
  let cameFromCalendar = $state(false);
  let editor = $state<{ event: CalendarEvent | null; date: Date } | null>(null);
  let details = $state<CalendarEvent | null>(null);
  let sharing = $state(false);
  let remoteBooking = $state<CalendarData | null | undefined>(undefined);
  let calendarShell = $state<HTMLElement | null>(null);

  let booking = $derived.by(() => {
    const match = /^\/book\/(?:(npub1[02-9ac-hj-np-z]{58})\/)?([^/?#]+)(?:\?(.*))?$/.exec(hashPath);
    if (!match) return null;
    const owner = match[1] ?? userNpub ?? '';
    return { owner, slug: decode(match[2]!), key: new URLSearchParams(match[3] ?? '').get('k'), own: owner === userNpub };
  });
  let bookingData = $derived(booking?.own ? data : remoteBooking);
  let invite = $derived.by(() => {
    const match = /^\/invite\/(npub1[02-9ac-hj-np-z]{58})\?(.*)$/.exec(hashPath);
    const key = new URLSearchParams(match?.[2] ?? '').get('k');
    return match && key && /^[0-9a-f]{64}$/i.test(key) ? { organizer: match[1]!, key: key.toLowerCase() } : null;
  });
  let page = $derived(booking || invite);
  let invitations = $derived(data?.events.filter(event => event.organizer && event.rsvp === 'needs-action' && !event.cancelled && new Date(event.end).getTime() > Date.now()) ?? []);
  let title = $derived.by(() => {
    if (view === 'day') return dayLabel(selectedDate);
    if (view === 'week') {
      const days = weekDays(selectedDate, data?.startOfWeek ?? 'monday');
      return `${monthDayLabel(days[0]!)} - ${monthDayLabel(days[6]!)}`;
    }
    if (view === 'year') return `${monthDate.getFullYear()}`;
    return view === 'agenda' ? 'Agenda' : monthLabel(monthDate);
  });

  function decode(value: string): string {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }

  $effect(() => {
    const current = session;
    // Starting reads calendar state; only a new account may restart it.
    return current ? untrack(() => current.start()) : undefined;
  });

  onMount(() => {
    const syncHash = () => {
      const next = window.location.hash.slice(1) || '/';
      if (!next.startsWith('/book/')) cameFromCalendar = false;
      else if (!hashPath.startsWith('/book/')) cameFromCalendar = true;
      hashPath = next;
      const route = parseCalendarViewRoute(next);
      if (!route) return;
      view = route.view;
      // A year route names no month or day: it only moves the calendar when the year changes.
      if (route.view === 'year' && route.date.getFullYear() === monthDate.getFullYear()) return;
      if (route.date.getTime() !== selectedDate.getTime()) selectedDate = route.date;
      if (route.date.getTime() !== monthDate.getTime()) monthDate = route.date;
    };
    syncHash();
    window.addEventListener('hashchange', syncHash);
    return () => window.removeEventListener('hashchange', syncHash);
  });

  $effect(() => {
    const target = booking && !booking.own && isNpub(booking.owner) && booking.key ? booking : null;
    remoteBooking = undefined;
    if (!target) return;
    return watchCalendarView(target.owner, target.key!, next => remoteBooking = next, BOOKING_TREE_NAME);
  });

  $effect(() => {
    void view;
    void (page === null);
    void tick().then(() => {
      calendarShell?.scrollTo({ top: 0, left: 0 });
      window.scrollTo({ top: 0, left: 0 });
    });
  });

  function writeRoute(nextView = view, date = nextView === 'month' || nextView === 'year' ? monthDate : selectedDate) {
    if (page) return;
    const path = formatCalendarRoute(nextView, date);
    if (path === hashPath) return;
    hashPath = path;
    window.location.hash = path;
  }

  function shiftDays(date: Date, count: number): Date {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate() + count);
  }

  function shiftView(count: number) {
    if (view === 'day' || view === 'week') return selectDate(shiftDays(selectedDate, view === 'day' ? count : count * 7));
    const months = view === 'year' ? count * 12 : count;
    monthDate = new Date(monthDate.getFullYear(), monthDate.getMonth() + months, 1);
    if (view === 'year') selectedDate = new Date(selectedDate.getFullYear() + count, selectedDate.getMonth(), selectedDate.getDate());
    writeRoute();
  }

  function shiftMiniMonth(count: number) {
    monthDate = new Date(monthDate.getFullYear(), monthDate.getMonth() + count, 1);
    if (view === 'month' || view === 'year') writeRoute();
  }

  function selectDate(date: Date) {
    selectedDate = monthDate = startOfLocalDay(date);
    writeRoute();
  }

  function selectView(nextView: CalendarView) {
    view = nextView;
    monthDate = selectedDate;
    writeRoute();
  }

  function newEvent(date?: Date) {
    if (date) selectDate(date);
    editor = { event: null, date: date ?? selectedDate };
  }

  function openEvent(event: CalendarEvent) {
    const id = event.recurrenceSourceId ?? event.id;
    const source = (event.calendar ? session?.events : data?.events)?.find(item => item.id === id) ?? event;
    if (source.calendar || source.organizer) details = source;
    else editor = { event: source, date: selectedDate };
  }

  /** Saves a change to one event and tells guests or the organizer about it. */
  function change(next: CalendarData, id: string | undefined, message: string) {
    if (!data) return;
    const before = id ? data.events.find(event => event.id === id) : undefined;
    const after = id ? next.events.find(event => event.id === id) : next.events.find(event => !data!.events.includes(event));
    session?.persist(next, message, changeMessages(before, after));
  }

  function saveEvent(draft: EventDraft) {
    if (!data || !userNpub) return;
    editor = null;
    selectDate(new Date(draft.start));
    change(upsertCalendarEvent(data, draft, userNpub), draft.id, 'Saved');
  }

  function deleteEvent(id: string) {
    if (!data || !userNpub) return;
    editor = details = null;
    change(removeCalendarEvent(data, id, userNpub), id, 'Deleted');
  }

  function answer(id: string, status: RsvpStatus) {
    if (!data || !userNpub) return;
    details = null;
    change(setEventRsvp(data, id, status, userNpub), id, 'Saved');
  }

  function update(next: CalendarData, message = 'Saved', outgoing: OutgoingMessage[] = []) {
    if (userNpub) session?.persist(touchCalendar(next, userNpub), message, outgoing);
  }

  /** Changing who can see the calendar rotates its secret when anyone loses access. */
  function setSharedWith(people: string[]) {
    if (!data) return;
    const removed = data.sharedWith.filter(npub => !people.includes(npub));
    const key = !people.length ? undefined : removed.length || !data.shareKey ? newLinkKey() : data.shareKey;
    const outgoing: OutgoingMessage[] = [
      ...people.filter(to => key !== data!.shareKey || !data!.sharedWith.includes(to))
        .map(to => ({ to, message: { type: 'share' as const, title: data!.title, key } })),
      ...removed.map(to => ({ to, message: { type: 'share' as const, title: data!.title } })),
    ];
    update({ ...data, sharedWith: people, shareKey: key }, people.length ? 'Shared' : 'Stopped sharing', outgoing);
  }

  async function copyBookingLink(link: BookingLink) {
    if (!data || !userNpub) return;
    const key = data.bookingKey ?? newLinkKey();
    if (!data.bookingKey) update({ ...data, bookingKey: key });
    if (await copyToClipboard(bookingUrl(userNpub, link.slug, key)) === 'copied') session?.setStatus('Link copied', 2200);
  }

  function book({ link, slot, name, note }: BookingRequest) {
    if (!data || !userNpub || !booking) return;
    const title = `${link.title}: ${name}`;
    if (booking.own) {
      selectDate(new Date(slot.start));
      update(upsertCalendarEvent(data, { title, start: slot.start, end: slot.end, color: 'green', notes: note }, userNpub), 'Booked');
      return;
    }
    const id = `booking-${crypto.randomUUID()}`;
    const now = Date.now();
    const event: CalendarEvent = {
      id, title, start: slot.start, end: slot.end, allDay: false, color: 'green', notes: note,
      organizer: booking.owner, rsvp: 'accepted', guests: [{ npub: userNpub, status: 'accepted' }], createdAt: now, updatedAt: now,
    };
    update({ ...data, events: sortEvents([...data.events, event]) }, 'Requested', [
      { to: booking.owner, message: { type: 'book', id, slug: link.slug, start: slot.start, end: slot.end, name, note } },
    ]);
  }

  async function importFile(file: File) {
    if (!data || !userNpub) return;
    const { events } = parseCalendarFile(await file.text(), file.name);
    update(applyImportedCalendarEvents(data, events, userNpub), events.length === 1 ? 'Imported 1 event' : `Imported ${events.length} events`);
  }

  function exportFile() {
    if (!data) return;
    const ics = serializeCalendarIcs(data.events.filter(event => isShownEvent(event) && !event.cancelled), { calendarName: data.title });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([ics], { type: 'text/calendar' }));
    link.download = 'iris-calendar.ics';
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  /** Answering an invite link adds the event to my calendar and tells the organizer. */
  function answerInvite(event: CalendarEvent, status: RsvpStatus, name?: string) {
    if (!data || !invite) return;
    const { organizer, key } = invite;
    const existing = data.events.find(item => item.id === event.id);
    if (existing && existing.organizer !== organizer) return;
    const base = existing && existing.updatedAt >= event.updatedAt ? existing : event;
    const next: CalendarEvent = { ...base, organizer, rsvp: status, inviteKey: key };
    const events = existing ? data.events.map(item => item === existing ? next : item) : sortEvents([...data.events, next]);
    update({ ...data, events }, 'Saved', [{ to: organizer, message: { type: 'rsvp', id: event.id, status, invite: key, name } }]);
  }

  function closeBooking() {
    window.location.hash = formatCalendarRoute(view, view === 'month' || view === 'year' ? monthDate : selectedDate);
  }
</script>

<main class="calendar-shell flex-1 overflow-auto" bind:this={calendarShell}>
  <div class="calendar-shell-inner mx-auto space-y-4">
    {#if !page}
      <CalendarToolbar
        {title}
        {view}
        saving={session?.saving ?? false}
        status={session?.status ?? ''}
        onPrevious={() => shiftView(-1)}
        onNext={() => shiftView(1)}
        onToday={() => selectDate(new Date())}
        onSelectView={selectView}
      />
    {/if}

    {#if session?.error}
      <div class="flex items-center justify-between gap-3 rounded-lg border border-danger/40 bg-danger/8 p-3 text-sm text-danger" role="alert">
        <span>{session.error}</span>
        <button class="btn-ghost border border-danger/30 px-3 py-1 text-xs text-danger hover:bg-danger/10" onclick={() => session?.retry()}>Try again</button>
      </div>
    {/if}

    {#if !session}
      <div class="calendar-panel p-6 text-sm text-text-2">Preparing a local Iris identity...</div>
    {:else if !data}
      <div class="calendar-panel flex items-center justify-between gap-3 p-6 text-sm text-text-2">
        <span>{session.phase === 'missing' ? 'No calendar found for this account yet.' : 'Loading your calendar...'}</span>
        {#if session.phase === 'missing'}
          <button class="btn-success" onclick={() => session?.create()}>Start a new calendar</button>
        {/if}
      </div>
    {:else if invite}
      <InvitePage
        organizer={invite.organizer}
        secret={invite.key}
        mine={data.events.find(item => item.organizer === invite!.organizer && item.inviteKey === invite!.key)}
        timeFormat={data.timeFormat}
        onAnswer={answerInvite}
      />
    {:else if booking}
      {#if bookingData}
        <BookingPage
          data={bookingData}
          slug={booking.slug}
          owner={booking.own ? undefined : booking.owner}
          {selectedDate}
          showBack={cameFromCalendar}
          onSelectDate={selectDate}
          onBack={closeBooking}
          onBook={book}
        />
      {:else}
        <div class="calendar-panel p-6 text-sm text-text-2">
          {bookingData === null || !booking.key ? 'This booking link is not available.' : 'Loading booking page...'}
        </div>
      {/if}
    {:else if viewData}
      <div class="calendar-workbench">
        <CalendarSidebar
          {data}
          {viewData}
          {monthDate}
          {selectedDate}
          {invitations}
          selectedDayEvents={eventsForDay(viewData.events, selectedDate)}
          shared={session.shared}
          onSelectDate={selectDate}
          onPreviousMonth={() => shiftMiniMonth(-1)}
          onNextMonth={() => shiftMiniMonth(1)}
          onNewEvent={() => newEvent()}
          onOpenEvent={openEvent}
          onShare={() => sharing = true}
          onCopyBookingLink={copyBookingLink}
          onAddBookingLink={() => userNpub && update(addBookingLink(data!, userNpub))}
          onRemoveBookingLink={id => userNpub && update(removeBookingLink(data!, id, userNpub))}
          onChange={next => update(next)}
          onImport={importFile}
          onExport={exportFile}
        />
        <section class="calendar-primary min-w-0">
          {#if view === 'month'}
            <CalendarGrid data={viewData} {monthDate} {selectedDate} onSelectDate={selectDate} onNewEvent={newEvent} onEditEvent={openEvent} />
          {:else if view === 'day'}
            <CalendarDayView data={viewData} {selectedDate} onEditEvent={openEvent} onNewEvent={newEvent} />
          {:else if view === 'week'}
            <CalendarWeekView data={viewData} {selectedDate} onSelectDate={selectDate} onEditEvent={openEvent} onNewEvent={newEvent} />
          {:else if view === 'year'}
            <CalendarYearView data={viewData} {monthDate} {selectedDate} onSelectDate={selectDate} onSelectView={selectView} />
          {:else}
            <CalendarAgendaView events={upcomingEvents(viewData.events)} timeFormat={data.timeFormat} onEditEvent={openEvent} />
          {/if}
        </section>
      </div>
      <button class="calendar-fab" onclick={() => newEvent()} aria-label="New event" title="New event">
        <span class="i-lucide-plus"></span>
      </button>
    {/if}
  </div>
</main>

<EventEditor
  open={!!editor}
  event={editor?.event ?? null}
  selectedDate={editor?.date ?? selectedDate}
  startOfWeek={data?.startOfWeek ?? 'monday'}
  onClose={() => editor = null}
  onSave={saveEvent}
  onDelete={deleteEvent}
/>

{#if details && data}
  <EventDetails
    event={details}
    timeFormat={data.timeFormat}
    onClose={() => details = null}
    onAnswer={status => answer(details!.id, status)}
    onRemove={() => deleteEvent(details!.id)}
  />
{/if}

{#if sharing && data}
  <ShareDialog people={data.sharedWith} onChange={setSharedWith} onClose={() => sharing = false} />
{/if}

<style>
  .calendar-shell {
    background: rgb(var(--surface-0));
  }

  .calendar-shell-inner {
    max-width: 96rem;
    padding: 0.85rem 1rem 1rem;
  }

  :global(.calendar-panel) {
    border: 1px solid rgb(var(--surface-3) / 0.82);
    background: rgb(var(--surface-1) / 0.94);
    border-radius: 8px;
    box-shadow: none;
  }

  :global(.event-pending) {
    border-style: dashed !important;
    background: transparent !important;
  }

  :global(.event-cancelled) {
    opacity: 0.6;
    text-decoration: line-through;
  }

  .calendar-workbench {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    grid-template-areas: "primary" "sidebar";
    gap: 1rem;
    align-items: start;
  }

  .calendar-primary {
    grid-area: primary;
  }

  .calendar-fab {
    position: fixed;
    right: 1rem;
    bottom: calc(1rem + env(safe-area-inset-bottom));
    z-index: 30;
    width: 3.5rem;
    height: 3.5rem;
    border-radius: 1rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #916dfe;
    color: white;
    font-size: 1.5rem;
    box-shadow: 0 0.75rem 2rem rgb(0 0 0 / 0.35);
  }

  @media (min-width: 920px) {
    .calendar-fab {
      display: none;
    }

    .calendar-shell-inner {
      padding: 0.75rem 1.5rem 1.25rem;
    }

    .calendar-workbench {
      grid-template-columns: minmax(14.5rem, 17.25rem) minmax(0, 1fr);
      grid-template-areas: "sidebar primary";
      gap: 1.15rem;
    }
  }

  @media (min-width: 1440px) {
    .calendar-shell-inner {
      max-width: none;
    }

    .calendar-workbench {
      grid-template-columns: minmax(18rem, 21rem) minmax(0, 1fr);
    }
  }
</style>
