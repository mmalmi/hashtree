import { checkRandomizedRange } from './check-randomized-range.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runPortableSmoke } from './portable-smoke-lib.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');

function nextWeekdayDateValue(daysAhead = 3) {
  const date = new Date();
  date.setDate(date.getDate() + daysAhead);
  while (date.getDay() === 0 || date.getDay() === 6) {
    date.setDate(date.getDate() + 1);
  }
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

async function selectCalendarView(page, label) {
  await page.getByRole('button', { name: 'Calendar view', exact: true }).click();
  await page.getByRole('menuitemradio', { name: label, exact: true }).click();
}

async function openNewEvent(page) {
  await page.getByTestId('calendar-sidebar-create-button').click();
  await page.getByRole('menuitem', { name: 'Event', exact: true }).click();
  await page.waitForFunction(() => document.activeElement?.getAttribute('data-testid') === 'calendar-event-title-input');
}

runPortableSmoke({
  distDir: path.join(appDir, 'dist-calendar'),
  title: 'Iris Calendar',
  appName: 'calendar',
  screenshotPath: path.join(appDir, 'test-results', 'calendar-iris-portable-smoke.png'),
  async validatePage(page) {
    const viewButton = page.getByRole('button', { name: 'Calendar view', exact: true });
    await viewButton.waitFor({ state: 'visible', timeout: 10000 });

    const createButton = page.getByTestId('calendar-sidebar-create-button');
    await createButton.waitFor({ state: 'visible', timeout: 60000 });

    if (await page.getByText('Create a private calendar', { exact: true }).count()) {
      throw new Error('Calendar should auto-create the default private calendar without a Create step.');
    }

    await checkRandomizedRange(page);
    await selectCalendarView(page, 'Week');
    await page.getByTestId('calendar-week-view').waitFor({ state: 'visible', timeout: 10000 });
    await page.getByRole('button', { name: /^Create event Wed, .+ at 2 PM$/ }).click();
    await page.waitForFunction(() => document.activeElement?.getAttribute('data-testid') === 'calendar-event-title-input');
    const weekSlotStart = await page.getByTestId('calendar-event-start-time-input').inputValue();
    if (weekSlotStart !== '14:00') {
      throw new Error(`Week slot editor opened at ${weekSlotStart}, expected a 14:00 start`);
    }
    await page.getByRole('button', { name: 'Cancel', exact: true }).click();
    await selectCalendarView(page, 'Year');
    await page.getByTestId('calendar-year-view').waitFor({ state: 'visible', timeout: 10000 });
    await selectCalendarView(page, 'Day');
    await page.getByTestId('calendar-day-view').waitFor({ state: 'visible', timeout: 10000 });
    await selectCalendarView(page, 'Agenda');
    await page.getByTestId('calendar-agenda-view').waitFor({ state: 'visible', timeout: 10000 });
    await selectCalendarView(page, 'Month');
    await page.getByTestId('calendar-grid').waitFor({ state: 'visible', timeout: 10000 });

    const eventTitle = `Smoke test event ${Date.now()}`;
    await openNewEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(eventTitle);
    await page.getByTestId('calendar-event-save').click();
    await page.getByTestId('calendar-event-pill').filter({ hasText: eventTitle }).waitFor({ state: 'visible', timeout: 30000 });
    await page.getByTestId('calendar-save-status').filter({ hasText: /Loaded|Saved/ }).waitFor({ state: 'visible', timeout: 30000 });
    await page.getByTestId('calendar-event-pill').filter({ hasText: eventTitle }).waitFor({ state: 'visible', timeout: 30000 });
    await page.reload({ waitUntil: 'load', timeout: 60000 });
    await createButton.waitFor({ state: 'visible', timeout: 60000 });
    await page.getByTestId('calendar-event-pill').filter({ hasText: eventTitle }).waitFor({ state: 'visible', timeout: 30000 });
    const allDayTitle = `Smoke all-day event ${Date.now()}`;
    await openNewEvent(page);
    await page.getByTestId('calendar-event-title-input').fill(allDayTitle);
    await page.getByRole('checkbox', { name: 'All day', exact: true }).check();
    const allDayStartInput = page.getByTestId('calendar-event-start-date-input');
    const allDayEndInput = page.getByTestId('calendar-event-end-date-input');
    await allDayStartInput.waitFor({ state: 'visible', timeout: 10000 });
    if (await page.locator('input[type="date"]').count()) {
      throw new Error('All-day editor should use the custom date field, not a native date input');
    }
    const allDayDateTimeCount = await page.locator('input[type="datetime-local"]').count();
    if (allDayDateTimeCount !== 0) {
      throw new Error(`All-day editor still showed ${allDayDateTimeCount} datetime inputs`);
    }
    const allDayDate = nextWeekdayDateValue(8);
    await allDayStartInput.fill(allDayDate);
    await allDayEndInput.fill(allDayDate);
    await page.getByTestId('calendar-event-save').click();
    await page.getByTestId('calendar-event-pill').filter({ hasText: allDayTitle }).waitFor({ state: 'visible', timeout: 30000 });
    await page.evaluate(() => {
      window.location.hash = '#/book/meet';
    });
    await page.getByRole('button', { name: 'Back to calendar', exact: true }).waitFor({ state: 'visible', timeout: 10000 });
    const bookingDate = nextWeekdayDateValue(3);
    const bookingDateInput = page.getByTestId('booking-date-input');
    await bookingDateInput.waitFor({ state: 'visible', timeout: 10000 });
    if (await page.locator('input[type="date"]').count()) {
      throw new Error('Booking page should use the custom date field, not a native date input');
    }
    await bookingDateInput.fill(bookingDate);
    await bookingDateInput.press('Enter');
    const firstSlot = page.getByRole('button', { name: '9:00 AM - 9:30 AM', exact: true });
    await firstSlot.waitFor({ state: 'visible', timeout: 10000 });
    await firstSlot.click();
    await page.getByRole('button', { name: 'Copy', exact: true }).waitFor({ state: 'visible', timeout: 10000 });
    await page.waitForFunction(() => document.activeElement?.getAttribute('data-testid') === 'booking-guest-name-input');
    await page.getByTestId('booking-guest-name-input').fill('Smoke Guest');
    await page.getByTestId('booking-book-button').click();
    await page.getByTestId('booking-confirmed').filter({ hasText: 'Booked' }).waitFor({ state: 'visible', timeout: 30000 });
    await page.waitForFunction(() => ![...document.querySelectorAll('button')]
      .some(button => button.innerText.trim() === '9:00 AM - 9:30 AM'));
    await page.getByRole('button', { name: 'Back to calendar', exact: true }).click();
    await createButton.waitFor({ state: 'visible', timeout: 10000 });
    await openNewEvent(page);
    const bookingDateStart = await page.getByTestId('calendar-event-start-time-input').inputValue();
    if (bookingDateStart !== '09:00') {
      throw new Error(`Booking date returned to an event start of ${bookingDateStart}, expected 09:00`);
    }
    await page.getByRole('button', { name: 'Cancel', exact: true }).click();
    await page.screenshot({
      path: path.join(appDir, 'test-results', 'calendar-iris-event-smoke.png'),
      fullPage: true,
    });
  },
}).catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
