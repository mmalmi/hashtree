export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  calendar: {
    name: 'calendar',
    appName: 'Iris Calendar',
    distDir: 'dist-calendar',
    treeName: 'calendar',
    defaultWorkerName: 'iris-calendar',
    defaultDomains: ['calendar.iris.to'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_CALENDAR',
    pagesProjectEnv: 'CF_PAGES_PROJECT_CALENDAR',
    buildCommand: ['pnpm', 'run', 'build:calendar'],
    testCommands: [
      ['node', './scripts/smoke-graph-policy.mjs', 'calendar'],
      ['pnpm', 'run', 'check:types'],
      ['pnpm', 'run', 'lint:calendar-size'],
      ['pnpm', 'run', 'lint'],
      ['pnpm', 'run', 'test:unit'],
      ['node', './scripts/smoke-calendar-iris-portable.mjs'],
      ['pnpm', 'run', 'test:e2e:release'],
    ],
  },
};

export const releaseProfileNames = ['calendar'];
