import { readdir, readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, '..');
const maxLines = Number.parseInt(process.env.MAX_FILE_LINES ?? '600', 10);
const extensions = new Set(['.css', '.js', '.mjs', '.svelte', '.ts', '.tsx']);
const ignoredDirectories = new Set([
  '.git',
  '.svelte-kit',
  'coverage',
  'dist',
  'node_modules',
  'playwright-report',
  'test-results',
]);
const ignoredPathPrefixes = [
  'packages/ndk/',
  'packages/ndk-cache/',
];

function isIgnoredDirectory(name) {
  return ignoredDirectories.has(name) || name.startsWith('dist-');
}

function parseTargetPaths(argv) {
  const paths = [];
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--path') {
      const value = argv[index + 1];
      if (!value) throw new Error('--path requires a value');
      paths.push(value);
      index += 1;
      continue;
    }
    paths.push(arg);
  }
  return paths;
}

async function listSourceFiles(target) {
  const stats = await stat(target);
  if (stats.isFile()) {
    return extensions.has(path.extname(target)) ? [target] : [];
  }
  if (!stats.isDirectory()) return [];

  const dir = target;
  const entries = await readdir(dir, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (isIgnoredDirectory(entry.name)) return [];
      return listSourceFiles(fullPath);
    }
    if (!entry.isFile() || !extensions.has(path.extname(entry.name))) return [];
    return [fullPath];
  }));
  return nested.flat();
}

function countLines(text) {
  if (text.length === 0) return 0;
  return text.endsWith('\n') ? text.split('\n').length - 1 : text.split('\n').length;
}

function formatViolation({ file, lineCount }) {
  return `- ${file}: ${lineCount} lines`;
}

function isIgnoredPath(file) {
  const relative = path.relative(repoRoot, file).split(path.sep).join('/');
  return ignoredPathPrefixes.some(prefix => relative.startsWith(prefix));
}

const targetArgs = parseTargetPaths(process.argv.slice(2));
const targetPaths = targetArgs.length > 0 ? targetArgs : [repoRoot];
const files = (await Promise.all(targetPaths.map(target => listSourceFiles(path.resolve(repoRoot, target)))))
  .flat()
  .sort();
const violations = [];

for (const file of files) {
  const relative = path.relative(repoRoot, file);
  if (isIgnoredPath(file)) continue;
  const lineCount = countLines(await readFile(file, 'utf8'));
  if (lineCount > maxLines) violations.push({ file: relative, lineCount });
}

if (violations.length > 0) {
  console.error(`File length check failed. Project cap is ${maxLines} lines.`);
  console.error(violations.map(formatViolation).join('\n'));
  process.exit(1);
}

console.log(`File length check passed (${files.length} files, cap ${maxLines}).`);
