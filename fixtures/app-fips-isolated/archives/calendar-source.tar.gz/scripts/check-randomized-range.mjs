import assert from 'node:assert/strict';
import { fromHex, nhashEncode } from '@hashtree/core';

// Published rnd-v1 "hello" vector from the Hashtree encryption specification.
export async function checkRandomizedRange(page) {
  const hash = '819b3a52aa2550b762399299892a6b613b7071c57d95787a1915310afd50fc7b';
  const blob = '000102030405060708090a0b216d8e96be582844fc3a4e2a23eecfbe1a29cd5b6b';
  const nhash = nhashEncode({ hash: fromHex(hash), key: fromHex('02'.repeat(33)) });
  await page.waitForFunction(() => navigator.serviceWorker.controller && window.__getWorkerAdapter?.());
  const range = await page.evaluate(async ({ hash, blob, nhash }) => {
    await window.__localStore.put(Uint8Array.from(hash), Uint8Array.from(blob));
    const response = await fetch(`/htree/${nhash}`, {
      headers: { Range: 'bytes=1-3' },
      signal: AbortSignal.timeout(15000),
    });
    return { status: response.status, range: response.headers.get('Content-Range'), text: await response.text() };
  }, { hash: [...fromHex(hash)], blob: [...fromHex(blob)], nhash });
  assert.deepEqual(range, { status: 206, range: 'bytes 1-3/5', text: 'ell' });
}
