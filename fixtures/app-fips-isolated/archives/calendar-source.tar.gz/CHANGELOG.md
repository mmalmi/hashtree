# Changelog

## 0.1.15 - 2026-11-04

- Reduce repeat transfers when peers catch up on public feeds.

## 0.1.14 - 2026-11-04

- Keep searches and the posts and profiles you open off peer connections. Public posts you publish can still reach peers.

## 0.1.13 - 2026-11-03

- Read legacy and versioned Hashtree objects and preserve existing sharing links across edits.
- Preserve the encryption of private calendar data and keep other files when saving an edit.

## 0.1.12 - 2026-10-04

- Recover peer connections after another device restarts.
- Keep downloaded files available to other devices after reloading.
- Preserve saved accounts and offline data while updating shared networking.

## 0.1.11 - 2026-10-01

- Keep peer connections and transfers working when a delayed connection offer arrives.
- Update the shared contacts library.

## 0.1.10 - 2026-10-01

- Preserve the chosen end time when an all-day event is changed to a timed event.

- Update shared peer networking to recover cleanly from rejected handshakes, malformed packets, route failures, and transport restarts.
- Use corrected routing filters, bounded route retries, and native-compatible link feedback to reduce unnecessary background traffic.

## 0.1.9 - 2026-09-30

- Recover peer connection answers after temporary route failures with the updated shared networking runtime.
- Preserve existing accounts and offline data while updating the immutable file transport.

## 0.1.8 - 2026-09-30

- Use paths with enough capacity for peer connection messages and recover authenticated peer connections sooner.
- Update shared event and file networking without changing saved accounts or offline data.
- Finish background-worker startup after a recoverable crash so peer connections restart on reload.

## 0.1.7 - 2026-09-30

- Keep subscription batches within public message server limits.

## 0.1.6 - 2026-09-30

- Replace NDK with the shared Nostr Pubsub runtime and persistent Hashtree event indexes.
- Share one browser peer node for events and cached files, preserving saved accounts and offline publication.

## 0.1.5 - 2026-09-07

- Upgrade to Hashtree runtime 0.5.7, which validates remote content hashes and
  sizes before returning or caching data.

## 0.1.4 - 2026-07-20

- Upgrade to FIPS TypeScript 0.0.29 and Hashtree FIPS transport 0.4.6 for
  direct FSP negotiation with legacy FMP fallback and authenticated WebSocket
  bootstrap before WebRTC link negotiation.

## 0.1.3 - 2026-07-16

- Pin FIPS, Hashtree, Iris Kit, and Nostr social graph to immutable releases.
- Keep browser FIPS serve-only until an explicit peer route is selected, pass
  HTL 10 through the worker bridge, preserve provider errors, and replay
  explicit route state through worker restarts and runtime resyncs.
- Remove sibling-build and vendored-FIPS coupling, share canonical profile
  protocol constants, and remove the duplicate WASM Git history path.
