import { defineConfig, type Plugin } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import UnoCSS from 'unocss/vite';
import { VitePWA } from 'vite-plugin-pwa';
import { resolve } from 'path';
import { getAppBrand, getAppPwaIcons } from './src/lib/appBrand';
import {
  calendarManualChunks,
  calendarPortableBuild,
  portableAssetBase,
  portableAssetFileNames,
  rewritePortableEntryHtml,
  sanitizePortableHtml,
  type PortableFileOps,
} from './portableViteConfig';

const outDir = calendarPortableBuild.outDir;
const brand = getAppBrand('calendar');

export const sanitizeCalendarHtml = sanitizePortableHtml;

export async function rewriteCalendarEntryHtml(
  buildDir: string,
  fileOps?: PortableFileOps,
): Promise<void> {
  await rewritePortableEntryHtml(buildDir, 'calendar.html', fileOps);
}

function calendarEntryPlugin(): Plugin {
  return {
    name: 'calendar-entry',
    configureServer(server) {
      server.middlewares.use((req, _res, next) => {
        if (req.url === '/') {
          req.url = '/calendar.html';
        }
        next();
      });
    },
    async closeBundle() {
      try {
        await rewriteCalendarEntryHtml(resolve(__dirname, outDir));
      } catch {
        // Ignore in dev mode.
      }
    },
  };
}

export default defineConfig({
  base: portableAssetBase,
  define: {
    'import.meta.env.VITE_BUILD_TIME': JSON.stringify(new Date().toISOString()),
  },
  plugins: [
    calendarEntryPlugin(),
    UnoCSS(),
    svelte(),
    VitePWA({
      registerType: 'autoUpdate',
      strategies: 'injectManifest',
      srcDir: 'src',
      filename: 'sw.ts',
      includeAssets: [brand.iconSvg, brand.appleTouchPng],
      devOptions: {
        enabled: true,
        type: 'module',
      },
      manifest: {
        name: brand.displayName,
        short_name: brand.displayName,
        description: 'Private calendar and availability on Nostr',
        theme_color: '#1a1a2e',
        background_color: '#1a1a2e',
        display: 'standalone',
        icons: getAppPwaIcons('calendar'),
      },
      injectManifest: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm}'],
        globIgnores: [],
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
      },
    }),
  ],
  root: resolve(__dirname),
  resolve: {
    alias: {
      '$lib': resolve(__dirname, 'src/lib'),
    },
  },
  build: {
    modulePreload: calendarPortableBuild.modulePreload,
    outDir,
    emptyOutDir: true,
    reportCompressedSize: true,
    chunkSizeWarningLimit: 2000,
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'calendar.html'),
      },
      onLog(level, log, handler) {
        if (log.code === 'CIRCULAR_DEPENDENCY') return;
        const message = typeof log.message === 'string' ? log.message : '';
        if (message.includes('dynamic import will not move module into another chunk')) return;
        if (message.includes('has been externalized for browser compatibility')) return;
        handler(level, log);
      },
      output: {
        assetFileNames: portableAssetFileNames,
        manualChunks: calendarManualChunks,
      },
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: ['mayhem2.iris.to', 'mayhem1.iris.to', 'mayhem3.iris.to', 'mayhem4.iris.to'],
    hmr: {
      overlay: true,
    },
  },
  optimizeDeps: {
    include: [
      '@iris/hashtree-app/nostr',
      '@iris/identity/signers',
      '@hashtree/nostr',
      'nostr-pubsub',
      '@noble/hashes/utils.js',
      '@scure/base',
      'debug',
      'nostr-tools/nip19',
      'nostr-tools/nip49',
    ],
    exclude: ['@hashtree/worker', '@hashtree/worker/relay-entry'],
  },
  assetsInclude: ['**/*.wasm'],
});
