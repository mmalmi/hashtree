# Iris Calendar

Calendar and booking flows on Nostr and hashtree.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-calendar>
Live: <https://calendar.iris.to/>

## Development

```bash
pnpm install
pnpm run dev
```

## Verification

```bash
pnpm run test:unit
pnpm run test:calendar:iris
node ./scripts/release-site.mjs all --dry-run
```

## Release

```bash
pnpm run release:calendar:iris
```

The release script builds once, tests the built output, publishes the built directory root to hashtree, and deploys the same directory to the `iris-calendar` Cloudflare Worker target by default. If build or tests fail, publish and deploy do not run.
