import { defineConfig } from '@playwright/test';

const port = process.env.CONTACTS_RUNTIME_PORT ?? '49314';
export default defineConfig({
  testDir: './tests/runtime', workers: 1, timeout: 90_000,
  use: { baseURL: `http://127.0.0.1:${port}`, trace: 'retain-on-failure' },
  webServer: {
    command: `pnpm exec vite --host 127.0.0.1 --port ${port} --strictPort`,
    url: `http://127.0.0.1:${port}`, reuseExistingServer: false,
    env: { VITE_FIPS_WEBSOCKET_SEED_URLS: process.env.VITE_FIPS_WEBSOCKET_SEED_URLS ?? 'ws://127.0.0.1:49319/fips', VITE_NOSTR_RELAYS: 'ws://127.0.0.1:49315' },
  },
});
