import { getPublicRuntime } from '../../src/lib/publicRuntime';

const opened = new Set<string>();
const ended = new Set<string>();
const inventory = new Set<string>();

export async function reconnect(peerId: string) {
  const provider = await (await getPublicRuntime()).peers;
  if (!provider) throw new Error('Missing browser peer provider');
  // Observe decoded protocol frames while both real browser peers remain running.
  const decode = TextDecoder.prototype.decode;
  TextDecoder.prototype.decode = function (input, options) {
    const text = decode.call(this, input, options);
    if (text.startsWith('["FEED-SYNC/1",') || text.startsWith('["INV",')) {
      const [operation, arg, id] = JSON.parse(text);
      if (operation === 'FEED-SYNC/1' && arg === 'open') opened.add(id);
      if (operation === 'FEED-SYNC/1' && arg === 'end') ended.add(id);
      if (operation === 'INV') inventory.add(id);
    }
    return text;
  };
  const address = { transport: 'webrtc', addr: peerId };
  await provider.webRtcTransport.close(address);
  await provider.node.connect(address);
}

export function warmFeedResult(knownId: string) {
  return {
    reconciled: [...opened].some(id => ended.has(id)),
    replayedKnownId: inventory.has(knownId),
  };
}
