import { afterEach, describe, expect, it, vi } from 'vitest';
import { SocialGraph } from 'nostr-social-graph';
import { loadGraphBootstrap, syncGraphLists } from 'nostr-social-graph/publicGraphSync';
import { loadRetainedPublicGraph, watchRetainedPublicGraph } from '../src/lib/publicGraphCache';
vi.mock('nostr-social-graph/publicGraphSync', () => ({
  loadGraphBootstrap: vi.fn(), syncGraphLists: vi.fn(async () => ({})),
}));
const root = '1'.repeat(64), friend = '2'.repeat(64);
afterEach(() => { vi.clearAllMocks(); vi.useRealTimers(); });
describe('retained public graph', () => {
  it('uses the saved revision-bearing graph without fetching or replacing it with a server snapshot', async () => {
    const graph = new SocialGraph(root);
    graph.handleEvent({ kind: 3, pubkey: root, created_at: 20, id: 'a'.repeat(64), tags: [['p', friend]], content: '', sig: '' });
    graph.handleEvent({ kind: 10000, pubkey: root, created_at: 21, id: 'b'.repeat(64), tags: [], content: '', sig: '' });
    const bytes = await graph.toBinary();
    const seed = vi.fn();
    const write = vi.fn(async () => true);
    const state = await loadRetainedPublicGraph(root, seed, { read: async () => bytes, write }, root);
    const stop = watchRetainedPublicGraph(state, { relays: ['wss://custom.test'], authors: () => [root], changed() {} });
    expect(seed).not.toHaveBeenCalled();
    expect(loadGraphBootstrap).not.toHaveBeenCalled();
    expect(state.graph.getListRevision(root, 10000)?.id).toBe('b'.repeat(64));
    expect(syncGraphLists).toHaveBeenCalledWith(expect.objectContaining({ relays: ['wss://custom.test'], authors: [root], maxBytes: 1024 * 1024 }));
    const signal = vi.mocked(syncGraphLists).mock.calls[0][0].signal;
    stop();
    expect(signal?.aborted).toBe(true);
    await vi.waitFor(() => expect(write).toHaveBeenCalled());
  });
  it('selects a fresh projected bootstrap before the historical bundle when no cache exists', async () => {
    const fresh = new SocialGraph(root);
    fresh.handleEvent({ kind: 3, pubkey: root, created_at: 20, id: 'a'.repeat(64), tags: [['p', friend]], content: '', sig: '' });
    fresh.handleEvent({ kind: 10000, pubkey: root, created_at: 21, id: 'b'.repeat(64), tags: [], content: '', sig: '' });
    fresh.markListIncomplete(root, 3); fresh.markListIncomplete(root, 10000);
    vi.mocked(loadGraphBootstrap).mockResolvedValueOnce(fresh);
    const seed = vi.fn(), write = vi.fn(async () => true);
    const state = await loadRetainedPublicGraph(root, seed, { read: async () => undefined, write }, root);
    expect(state.graph).toBe(fresh);
    expect(seed).not.toHaveBeenCalled();
    expect(state.graph.getListRevision(root, 3)?.id).toBe('a'.repeat(64));
    expect(state.graph.getListRevision(root, 10000)?.id).toBe('b'.repeat(64));
    expect(write).toHaveBeenCalled();
  });
  it('falls back to the packaged seed when the fresh bootstrap is unavailable', async () => {
    vi.mocked(loadGraphBootstrap).mockRejectedValueOnce(new Error('offline'));
    const graph = new SocialGraph(root), bytes = await graph.toBinary(), seed = vi.fn(async () => bytes);
    const state = await loadRetainedPublicGraph(root, seed, { read: async () => undefined, write: async () => true }, root);
    expect(state.restored).toBe(false);
    expect(seed).toHaveBeenCalledOnce();
  });
  it('keeps the owner current while rotating direct follows beyond the mobile author budget', async () => {
    vi.useFakeTimers();
    vi.mocked(syncGraphLists).mockResolvedValue({ completedAuthors: 500 } as Awaited<ReturnType<typeof syncGraphLists>>);
    const others = Array.from({ length: 510 }, (_, index) => (index + 10).toString(16).padStart(64, '0'));
    const graph = new SocialGraph(root);
    const state = { graph, restored: true, storage: { read: async () => undefined, write: vi.fn(async () => true) } };
    const stop = watchRetainedPublicGraph(state, { relays: ['wss://custom.test'], authors: () => [root, ...others], changed() {} });
    expect(vi.mocked(syncGraphLists).mock.calls[0][0].authors).toEqual([root, ...others.slice(0, 499)]);
    await vi.advanceTimersByTimeAsync(15 * 60 * 1000);
    expect(vi.mocked(syncGraphLists).mock.calls[1][0].authors).toEqual([root, ...others.slice(499)]);
    stop();
  });
  it('preserves unreadable cache bytes and never requests a replacement snapshot', async () => {
    const seed = await new SocialGraph(root).toBinary();
    const write = vi.fn(async () => true);
    const state = await loadRetainedPublicGraph(root, async () => seed,
      { read: async () => new Uint8Array([255, 0, 254]), write }, root);
    expect(loadGraphBootstrap).not.toHaveBeenCalled();
    const stop = watchRetainedPublicGraph(state, { relays: [], authors: () => [root], changed() {} });
    stop();
    await state.storage.write(root, seed);
    expect(write).not.toHaveBeenCalled();
  });
  it('latches a conflicting save so a later debounce or close cannot claim the changed row', async () => {
    const graph = new SocialGraph(root), bytes = await graph.toBinary();
    const write = vi.fn(async () => false);
    const state = await loadRetainedPublicGraph(root, async () => bytes,
      { read: async () => bytes, write }, root);
    expect(await state.storage.write(root, bytes)).toBe(false);
    expect(write).toHaveBeenCalledWith(root, bytes, bytes);
    const stop = watchRetainedPublicGraph(state, { relays: [], authors: () => [root], changed() {} });
    stop();
    await state.storage.write(root, bytes);
    expect(write).toHaveBeenCalledOnce();
  });

});
