import { describe, expect, it } from 'vitest';
import {
  KIND_CONTACTS,
  KIND_PROFILE,
  buildPublicContacts,
  contactIdentityIdForPubkey,
  createPrivateContact,
  decodeProfileInput,
  mergeContacts,
  parseFollowTags,
  parseProfileEvent,
  parsePrivateContactsExport,
  pubkeyToNpub,
  searchContacts,
  serializePrivateContacts,
} from '../src/lib/contacts';
import type { Event } from 'nostr-tools/core';

const owner = '1'.repeat(64);
const alice = 'a'.repeat(64);
const bob = 'b'.repeat(64);
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function event(partial: Partial<Event>): Event {
  return {
    id: '0'.repeat(64),
    sig: '0'.repeat(128),
    pubkey: owner,
    created_at: 1,
    kind: 1,
    tags: [],
    content: '',
    ...partial,
  };
}

describe('contacts model', () => {
  it('decodes npubs and hex pubkeys', () => {
    expect(decodeProfileInput(owner)).toBe(owner);
    expect(decodeProfileInput(pubkeyToNpub(alice))).toBe(alice);
    expect(decodeProfileInput('nope')).toBeNull();
  });

  it('builds public contacts from kind 3 follows and kind 0 profiles', () => {
    const followEvent = event({
      kind: KIND_CONTACTS,
      tags: [['p', alice], ['p', bob], ['p', 'bad']],
    });
    const profiles = [
      event({
        kind: KIND_PROFILE,
        pubkey: alice,
        content: JSON.stringify({ name: 'alice', display_name: 'Alice A', nip05: 'alice.test' }),
      }),
      event({
        kind: KIND_PROFILE,
        pubkey: bob,
        content: JSON.stringify({ username: 'bobby', nickname: 'Bobby Nick' }),
      }),
    ];

    expect(parseFollowTags(followEvent)).toEqual([alice, bob]);
    const contacts = buildPublicContacts(owner, followEvent, profiles);
    expect(contacts.map((contact) => contact.name)).toEqual(['Alice A', 'bobby']);
    expect(contacts[0]).toEqual(expect.objectContaining({
      id: contactIdentityIdForPubkey(alice),
      source: 'public',
      followDistance: 1,
      handle: 'alice.test',
    }));
    expect(contacts[0].id).toMatch(uuidPattern);
    expect(contacts[0].identity).toEqual(expect.objectContaining({
      id: contacts[0].id,
      attrs: expect.arrayContaining([
        expect.objectContaining({ type: 'nostr_pubkey', value: alice, source: 'public', active: true }),
        expect.objectContaining({ type: 'npub', value: pubkeyToNpub(alice), source: 'public', active: true }),
        expect.objectContaining({ type: 'name', value: 'Alice A', source: 'public', active: true }),
      ]),
    }));
    expect(buildPublicContacts(owner, followEvent, profiles)[0].id).toBe(contacts[0].id);
  });

  it('keeps username and nickname from nostr profiles as name fallbacks', () => {
    const profile = parseProfileEvent(event({
      kind: KIND_PROFILE,
      pubkey: alice,
      content: JSON.stringify({ username: 'alice_user', nickname: 'Alice Nick' }),
    }));
    expect(profile).toEqual(expect.objectContaining({
      username: 'alice_user',
      nickname: 'Alice Nick',
    }));

    const contacts = buildPublicContacts(owner, event({
      kind: KIND_CONTACTS,
      tags: [['p', alice]],
    }), [event({
      kind: KIND_PROFILE,
      pubkey: alice,
      content: JSON.stringify({ nickname: 'Only Nick' }),
    })]);
    expect(contacts[0].name).toBe('Only Nick');
  });

  it('searches and merges private contacts with public contacts', () => {
    const privateContact = createPrivateContact({
      name: 'Alice private',
      handle: pubkeyToNpub(alice),
      pubkey: alice,
      groups: ['Team', 'Team'],
      notes: 'Met at Nostr cafe',
    });
    const publicContact = buildPublicContacts(owner, event({
      kind: KIND_CONTACTS,
      tags: [['p', alice]],
    }), [event({
      kind: KIND_PROFILE,
      pubkey: alice,
      content: JSON.stringify({ name: 'Alice', about: 'Bitcoin builder at https://iris.to' }),
    })])[0];
    expect(publicContact).toEqual(expect.objectContaining({
      about: 'Bitcoin builder at https://iris.to',
      notes: '',
    }));

    const merged = mergeContacts([publicContact], [privateContact]);
    expect(merged).toHaveLength(1);
    expect(merged[0]).toEqual(expect.objectContaining({
      id: privateContact.id,
      source: 'private',
      name: 'Alice private',
      groups: ['Team'],
      about: 'Bitcoin builder at https://iris.to',
      notes: 'Met at Nostr cafe',
    }));
    expect(merged[0].id).toMatch(uuidPattern);
    expect(merged[0].identity).toEqual(expect.objectContaining({
      id: privateContact.id,
      attrs: expect.arrayContaining([
        expect.objectContaining({ type: 'name', value: 'Alice private', source: 'private' }),
        expect.objectContaining({ type: 'nostr_pubkey', value: alice }),
        expect.objectContaining({ type: 'npub', value: pubkeyToNpub(alice) }),
      ]),
    }));
    expect(searchContacts(merged, 'cafe')).toHaveLength(1);
    expect(searchContacts(merged, 'builder')).toHaveLength(1);
    expect(searchContacts(merged, privateContact.id)).toHaveLength(1);
    expect(searchContacts(merged, pubkeyToNpub(alice))).toHaveLength(1);
    expect(searchContacts(merged, alice)).toHaveLength(1);
  });

  it('round-trips private contact exports', () => {
    const contacts = [createPrivateContact({
      name: 'Local Friend',
      handle: 'local@example.test',
      email: 'friend@example.test',
      phone: '+358 12 345678',
      company: 'Iris Test Lab',
      jobTitle: 'Contact Wrangler',
      address: 'Example Street 1',
      birthday: 'June 17',
    })];
    expect(contacts[0].id).toMatch(uuidPattern);
    expect(contacts[0]).toEqual(expect.objectContaining({
      email: 'friend@example.test',
      phone: '+358 12 345678',
      company: 'Iris Test Lab',
      jobTitle: 'Contact Wrangler',
      address: 'Example Street 1',
      birthday: 'June 17',
    }));
    expect(contacts[0].identity.attrs).toEqual(expect.arrayContaining([
      expect.objectContaining({ type: 'name', value: 'Local Friend', source: 'private' }),
      expect.objectContaining({ type: 'handle', value: 'local@example.test', source: 'private' }),
    ]));
    expect(parsePrivateContactsExport(serializePrivateContacts(contacts))).toEqual(contacts);
    expect(searchContacts(contacts, 'wrangler')).toHaveLength(1);
    expect(searchContacts(contacts, contacts[0].id)).toHaveLength(1);
    expect(searchContacts(contacts, 'local@example.test')).toHaveLength(1);
    expect(() => parsePrivateContactsExport('{}')).toThrow('Unsupported contacts export');
  });

  it('migrates legacy private contacts into UUID identities', () => {
    const legacy = JSON.stringify({
      version: 1,
      exportedAt: '2026-06-15T00:00:00.000Z',
      contacts: [{
        id: 'private:123:alice',
        pubkey: alice,
        npub: pubkeyToNpub(alice),
        name: 'Legacy Alice',
        handle: 'alice.test',
        source: 'private',
        groups: ['Imported'],
        notes: 'old shape',
        updatedAt: 123,
      }],
    });

    const [contact] = parsePrivateContactsExport(legacy);
    expect(contact.id).toMatch(uuidPattern);
    expect(contact.identity).toEqual(expect.objectContaining({
      id: contact.id,
      attrs: expect.arrayContaining([
        expect.objectContaining({ type: 'name', value: 'Legacy Alice', source: 'private' }),
        expect.objectContaining({ type: 'handle', value: 'alice.test', source: 'private' }),
        expect.objectContaining({ type: 'nostr_pubkey', value: alice, source: 'private' }),
      ]),
    }));
  });
});
