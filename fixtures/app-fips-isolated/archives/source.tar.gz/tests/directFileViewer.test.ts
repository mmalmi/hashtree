import { describe, expect, it } from 'vitest';
import {
  getDirectFileViewerKind,
  getDirectFileViewerName,
} from '../src/lib/directFileViewer';

describe('direct file viewer routing', () => {
  it('classifies browser-viewable direct file routes by extension', () => {
    expect(getDirectFileViewerKind('elrond-300x237.jpg')).toBe('image');
    expect(getDirectFileViewerKind('screens/demo.WEBP')).toBe('image');
    expect(getDirectFileViewerKind('clips/video.mp4')).toBe('video');
    expect(getDirectFileViewerKind('audio/song.flac')).toBe('audio');
    expect(getDirectFileViewerKind('docs/manual.pdf')).toBe('pdf');
  });

  it('does not treat HTML app entrypoints as direct files', () => {
    expect(getDirectFileViewerKind('index.html')).toBeNull();
    expect(getDirectFileViewerKind('app.js')).toBeNull();
    expect(getDirectFileViewerKind(undefined)).toBeNull();
  });

  it('uses the decoded filename as the viewer title', () => {
    expect(getDirectFileViewerName('folder/elrond-300x237.jpg')).toBe('elrond-300x237.jpg');
    expect(getDirectFileViewerName('folder/hello%20world.png')).toBe('hello world.png');
  });
});
