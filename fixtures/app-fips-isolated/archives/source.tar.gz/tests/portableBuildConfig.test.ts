import { describe, expect, it } from 'vitest';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

async function loadConfig() {
  const configModule = await import('../vite.config');
  return configModule.default;
}

describe('iris-sites build config', () => {
  it('uses a relative asset base for isolated hosts and boot iframes', async () => {
    const config = await loadConfig();
    expect(config.base).toBe('./');
    expect(config.build?.modulePreload).toBe(false);
  });

  it('strips module preload and crossorigin hints from portable HTML output', async () => {
    const configModule = await import('../vite.config');
    const sanitized = configModule.sanitizePortableHtml(`
      <script type="module" crossorigin src="./assets/main.js"></script>
      <link rel="modulepreload" crossorigin href="./assets/vendor.js">
      <link rel="stylesheet" crossorigin href="./assets/main.css">
    `);

    expect(sanitized).not.toContain('modulepreload');
    expect(sanitized).not.toContain('crossorigin');
    expect(sanitized).toContain('<script type="module" src="./assets/main.js"></script>');
    expect(sanitized).toContain('<link rel="stylesheet" href="./assets/main.css">');
  });

  it('allows readable iris.localhost app hosts in local development', async () => {
    const config = await loadConfig();
    expect(config.server?.allowedHosts).toEqual(expect.arrayContaining([
      'iris.localhost',
      '.iris.localhost',
    ]));
  });

  it('prebundles both worker dependency graphs before the first browser action', async () => {
    const config = await loadConfig();

    expect(config.optimizeDeps?.entries).toEqual([
      'index.html',
      'src/lib/hashtreeUploadWorker.ts',
      'src/lib/relayWorkerEntry.ts',
      'src/sw.ts',
    ]);
  });

  it('declares the shared favicon in the launcher shell HTML', async () => {
    const html = await readFile(resolve(import.meta.dirname, '..', 'index.html'), 'utf8');

    expect(html).toContain('<link id="iris-sites-favicon" rel="icon" href="./favicon.svg" type="image/svg+xml" sizes="any" />');
    expect(html).toContain('<link id="iris-sites-shortcut-icon" rel="shortcut icon" href="./favicon.svg" type="image/svg+xml" />');
    expect(html).toContain('<title>Iris: The Freedom Toolkit</title>');
    expect(html).toContain('<link rel="canonical" href="https://apps.iris.to/" />');
    expect(html).toContain('<meta property="og:url" content="https://apps.iris.to/" />');
    expect(html).toContain('<meta property="og:site_name" content="Iris Sites" />');
    expect(html).toContain('<meta property="og:image" content="https://apps.iris.to/link-preview.png" />');
    expect(html).toContain('<meta property="og:image:width" content="1200" />');
    expect(html).toContain('<meta property="og:image:height" content="630" />');
    expect(html).toContain('<meta name="twitter:card" content="summary_large_image" />');
    expect(html).toContain('<meta name="twitter:image" content="https://apps.iris.to/link-preview.png" />');
    expect(html).toContain('<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />');
    expect(html).toContain('<meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)" />');
    expect(html).toContain('<meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)" />');
    expect(html).toContain('<meta name="theme-color" content="#000000" />');
    expect(html).toContain('<meta name="mobile-web-app-capable" content="yes" />');
    expect(html).toContain('<meta name="apple-mobile-web-app-capable" content="yes" />');
    expect(html).toContain('<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />');
    expect(html).toContain('<meta name="apple-mobile-web-app-title" content="Iris" />');
    expect(html).toContain('color-scheme: light dark;');
    expect(html).toContain('linear-gradient(0deg, #000000 0%, rgba(0, 0, 0, 0.92) 7%, rgba(0, 0, 0, 0) 22%)');
    expect(html).toContain('linear-gradient(180deg, #000000 0%, rgba(0, 0, 0, 0.92) 7%, rgba(0, 0, 0, 0) 22%)');
    expect(html).toContain('radial-gradient(circle at top, rgba(122, 144, 176, 0.10), transparent 32%)');
    expect(html).toContain('linear-gradient(180deg, #ffffff 0%, #fbfcff 16%, #f6f8fb 54%, #eef2f7 78%, #ffffff 100%)');
    expect(html).toContain('background-attachment: fixed;');
    expect(html).toContain('background-repeat: no-repeat;');
    expect(html).toContain('background-size: 100% 100%;');
    expect(html).toContain('min-height: 100vh;');
    expect(html).toContain('min-height: 100dvh;');
  });

  it('keeps the installed app shell aligned with the dark top gradient', async () => {
    const configSource = await readFile(resolve(import.meta.dirname, '..', 'vite.config.ts'), 'utf8');

    expect(configSource).toContain("theme_color: '#000000'");
    expect(configSource).toContain("background_color: '#000000'");
    expect(configSource).toContain("display: 'standalone'");
  });

  it('ships a 1200 by 630 social preview image', async () => {
    const image = await readFile(resolve(import.meta.dirname, '..', 'public', 'link-preview.png'));

    expect(image.subarray(0, 8).toString('hex')).toBe('89504e470d0a1a0a');
    expect(image.readUInt32BE(16)).toBe(1200);
    expect(image.readUInt32BE(20)).toBe(630);
  });

  it('ships the nostr-wasm secp256k1 asset from the runtime root', async () => {
    const wasm = await readFile(resolve(import.meta.dirname, '..', 'public', 'secp256k1.wasm'));
    const digest = createHash('sha256').update(wasm).digest('hex');

    expect(wasm.byteLength).toBeGreaterThan(200_000);
    expect(digest).toBe('a343e0db7a33da2648820b7705a659b5c84b042c581509cb18d185314f94dc0e');
  });

  it('stubs child app service workers in the portable smoke harness', async () => {
    const smokeScript = await readFile(resolve(import.meta.dirname, '..', 'scripts', 'portable-smoke.mjs'), 'utf8');

    expect(smokeScript).toContain('isLocalHtreeServiceWorkerRequest');
    expect(smokeScript).toContain('/^\\/htree\\/.+\\/sw\\.js$/');
    expect(smokeScript).toContain('Local smoke harness stub for child app service workers');
  });

  it('prevents service-worker controller reloads from racing launcher e2e actions', async () => {
    const playwrightConfig = await readFile(resolve(import.meta.dirname, '..', 'playwright.config.ts'), 'utf8');

    expect(playwrightConfig).toContain("VITE_TEST_MODE: '1'");
  });
});
