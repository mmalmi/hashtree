import { describe, expect, it } from 'vitest';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { sanitizePortableHtml } from '../vite.config';

describe('portable build config', () => {
  it('keeps the app portable for hashtree hosting', () => {
    expect(sanitizePortableHtml('<link rel="modulepreload" href="/x.js">\n<script crossorigin src="./x.js"></script>'))
      .toBe('\n<script src="./x.js"></script>');
  });

  it('declares contacts metadata and app icon', async () => {
    const html = await readFile(resolve(import.meta.dirname, '..', 'index.html'), 'utf8');
    const icon = await readFile(resolve(import.meta.dirname, '..', 'public', 'iris-contacts-icon.svg'), 'utf8');
    expect(html).toContain('<title>Iris Contacts</title>');
    expect(html).toContain('iris-contacts-icon.svg');
    expect(icon).toContain('Iris Contacts');
  });
});
