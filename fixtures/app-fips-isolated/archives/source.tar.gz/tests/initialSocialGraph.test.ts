import { describe, expect, it } from 'vitest';
import { SocialGraph as RuntimeSocialGraph, type SocialGraph as SocialGraphInstance } from 'nostr-social-graph';
import {
  buildContactsFromPubkeys,
  contactFromInitialGraphIdentityId,
  createProfileLookup,
  searchInitialGraphContacts,
  type InitialSocialGraph,
} from '../src/lib/initialSocialGraph';
import { contactIdentityIdForPubkey, pubkeyToNpub } from '../src/lib/contacts';

const owner = '1'.repeat(64);
const alice = 'a'.repeat(64);
const bob = 'b'.repeat(64);
const carol = 'c'.repeat(64);
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SocialGraph = RuntimeSocialGraph as unknown as { new(root: string): SocialGraphInstance };

function seedGraph(): InitialSocialGraph {
  const graph = new SocialGraph(owner);
  graph.addFollower(owner, alice);
  graph.addFollower(alice, bob);
  graph.addFollower(bob, owner);

  const profileByPubkey = createProfileLookup([
    [alice, 'Alice A', 'alice.test', 'img.test/alice.png'],
    [bob, 'Bob Builder', 'bob.test', 'https://img.test/bob.png'],
    [carol, 'Carol C', '', ''],
    ['bad', 'Ignored'],
  ]);
  const directContacts = buildContactsFromPubkeys(graph.getFollowedByUser(owner), graph, profileByPubkey);
  const followerContacts = buildContactsFromPubkeys(graph.getFollowersByUser(owner), graph, profileByPubkey);

  return {
    ownerPubkey: owner,
    graph,
    profileByPubkey,
    profileCount: profileByPubkey.size,
    graphSize: graph.size(),
    directContacts,
    followerContacts,
  };
}

describe('initial social graph', () => {
  it('builds direct contacts from packaged profile rows', () => {
    const initialGraph = seedGraph();

    expect(initialGraph.profileCount).toBe(3);
    expect(initialGraph.directContacts).toHaveLength(1);
    expect(initialGraph.directContacts[0]).toEqual(expect.objectContaining({
      id: contactIdentityIdForPubkey(alice),
      name: 'Alice A',
      handle: 'alice.test',
      picture: 'https://img.test/alice.png',
      followDistance: 1,
    }));
    expect(initialGraph.directContacts[0].id).toMatch(uuidPattern);
  });

  it('builds follower contacts from the reverse follow graph', () => {
    const initialGraph = seedGraph();

    expect(initialGraph.followerContacts).toHaveLength(1);
    expect(initialGraph.followerContacts[0]).toEqual(expect.objectContaining({
      id: contactIdentityIdForPubkey(bob),
      name: 'Bob Builder',
      handle: 'bob.test',
      followDistance: 2,
      followedByFriends: 1,
    }));
  });

  it('resolves known packaged profile identities by UUID', () => {
    const initialGraph = seedGraph();
    const bobIdentityId = contactIdentityIdForPubkey(bob)!;

    expect(contactFromInitialGraphIdentityId(initialGraph, bobIdentityId)).toEqual(expect.objectContaining({
      id: bobIdentityId,
      name: 'Bob Builder',
      followDistance: 2,
    }));
  });

  it('searches seeded profiles beyond the loaded contact list', () => {
    const initialGraph = seedGraph();
    const excludePubkeys = new Set(initialGraph.directContacts.flatMap((contact) => contact.pubkey ? [contact.pubkey] : []));

    const [result] = searchInitialGraphContacts(initialGraph, 'bob', { excludePubkeys });

    expect(result).toEqual(expect.objectContaining({
      name: 'Bob Builder',
      handle: 'bob.test',
      followDistance: 2,
      followedByFriends: 1,
    }));
  });

  it('accepts pasted npubs in search without requiring them in the UI', () => {
    const initialGraph = seedGraph();

    const [result] = searchInitialGraphContacts(initialGraph, pubkeyToNpub(bob));

    expect(result).toEqual(expect.objectContaining({
      name: 'Bob Builder',
      followDistance: 2,
    }));
  });

  it('accepts pasted NIP-05 identifiers in search', () => {
    const initialGraph = seedGraph();

    const [result] = searchInitialGraphContacts(initialGraph, 'bob.test');

    expect(result).toEqual(expect.objectContaining({
      name: 'Bob Builder',
      followDistance: 2,
    }));
  });

  it('does not display unknown graph distance as a thousand-hop contact', () => {
    const initialGraph = seedGraph();

    const [result] = searchInitialGraphContacts(initialGraph, 'carol');

    expect(result).toEqual(expect.objectContaining({
      name: 'Carol C',
      followDistance: null,
    }));
  });

  it('hides overmuted users from seeded search results', () => {
    const initialGraph = seedGraph();
    initialGraph.graph.handleEvent({
      id: '0'.repeat(64),
      sig: '0'.repeat(128),
      pubkey: alice,
      created_at: 2,
      kind: 10000,
      tags: [['p', carol]],
      content: '',
    }, true);

    expect(searchInitialGraphContacts(initialGraph, 'carol')).toEqual([]);
    expect(searchInitialGraphContacts(initialGraph, pubkeyToNpub(carol))).toEqual([]);
    expect(searchInitialGraphContacts(initialGraph, 'carol', { hideOvermuted: false })).toHaveLength(1);
  });
});
