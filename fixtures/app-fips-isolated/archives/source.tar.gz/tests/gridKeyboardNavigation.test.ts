import { describe, expect, it } from 'vitest';
import { getNextGridKeyboardIndex, type GridKeyboardRect } from '../src/lib/gridKeyboardNavigation';

function rect(left: number, top: number): GridKeyboardRect {
  return {
    height: 40,
    left,
    top,
    width: 40,
  };
}

describe('grid keyboard navigation', () => {
  it('moves left and right in visual order across wrapped rows', () => {
    const items = [
      rect(0, 0),
      rect(100, 0),
      rect(200, 0),
      rect(0, 100),
      rect(100, 100),
    ];

    expect(getNextGridKeyboardIndex(items, 1, 'right')).toBe(2);
    expect(getNextGridKeyboardIndex(items, 2, 'right')).toBe(3);
    expect(getNextGridKeyboardIndex(items, 3, 'left')).toBe(2);
    expect(getNextGridKeyboardIndex(items, 0, 'left')).toBe(0);
    expect(getNextGridKeyboardIndex(items, 4, 'right')).toBe(4);
  });

  it('moves up and down to the nearest card in the rendered row', () => {
    const items = [
      rect(0, 0),
      rect(100, 0),
      rect(200, 0),
      rect(80, 100),
      rect(220, 100),
    ];

    expect(getNextGridKeyboardIndex(items, 1, 'down')).toBe(3);
    expect(getNextGridKeyboardIndex(items, 2, 'down')).toBe(4);
    expect(getNextGridKeyboardIndex(items, 3, 'up')).toBe(1);
    expect(getNextGridKeyboardIndex(items, 4, 'up')).toBe(2);
  });

  it('handles one-column layouts without hardcoded row counts', () => {
    const items = [
      rect(0, 0),
      rect(0, 100),
      rect(0, 200),
    ];

    expect(getNextGridKeyboardIndex(items, 0, 'down')).toBe(1);
    expect(getNextGridKeyboardIndex(items, 1, 'down')).toBe(2);
    expect(getNextGridKeyboardIndex(items, 2, 'up')).toBe(1);
    expect(getNextGridKeyboardIndex(items, 0, 'up')).toBe(0);
  });
});
