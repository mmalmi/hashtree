import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const publicDir = join(process.cwd(), 'public');

describe('launcher icon assets', () => {
  it('uses a launcher-tile Iris rainbow pin for Maps', () => {
    const iconSvg = readFileSync(join(publicDir, 'launcher-icons', 'iris-maps-icon.svg'), 'utf8');

    expect(iconSvg).toContain('aria-label="Iris Maps"');
    expect(iconSvg).toContain('<rect width="512" height="512" rx="120" fill="#050507"/>');
    expect(iconSvg).toContain('id="iris-pin-mask"');
    expect(iconSvg).toContain('id="iris-pin-sweep"');
    expect(iconSvg).toContain('<circle cx="256" cy="224" r="115" fill="#000000"/>');
    expect(iconSvg).toContain('transform="translate(56.32 56.32) scale(.78)"');
    expect(iconSvg).not.toContain('id="iris-pin-rainbow"');
  });

  it('uses a launcher-tile Iris ring for Contacts', () => {
    const iconSvg = readFileSync(join(publicDir, 'launcher-icons', 'iris-contacts-icon.svg'), 'utf8');

    expect(iconSvg).toContain('aria-label="Iris Contacts"');
    expect(iconSvg).toContain('<rect width="512" height="512" rx="120" fill="#050507"/>');
    expect(iconSvg).toContain('id="iris-ring-mask"');
    expect(iconSvg).toContain('id="iris-ring-sweep"');
    expect(iconSvg).toContain('<circle cx="256" cy="256" r="192" fill="#ffffff"/>');
    expect(iconSvg).toContain('<circle cx="256" cy="256" r="111" fill="#000000"/>');
    expect(iconSvg).not.toContain('M82 362');
  });
});
