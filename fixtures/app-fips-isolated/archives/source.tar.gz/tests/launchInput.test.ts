import { describe, expect, it } from 'vitest';
import { nhashEncode } from '@hashtree/core';
import { parseLaunchInput } from '../src/lib/launchInput';

const VALID_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const VALID_NHASH = 'nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38';
const VALID_SNAPSHOT_NHASH = nhashEncode(new Uint8Array(32).fill(7));

describe('launcher input parsing', () => {
  it('parses a bare immutable nhash route', () => {
    expect(parseLaunchInput(VALID_NHASH)).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_NHASH,
      entryPath: 'index.html',
    });
  });

  it('parses a bare mutable npub/tree route into a tree launch', () => {
    expect(parseLaunchInput(`${VALID_NPUB}/enshittifier`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    });
  });

  it('treats additional bare mutable segments as part of the tree name', () => {
    expect(parseLaunchInput(`${VALID_NPUB}/apps/iris`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris',
      npub: VALID_NPUB,
      treeName: 'apps/iris',
      entryPath: 'index.html',
    });
  });

  it('parses launcher share URLs by their hash route', () => {
    expect(parseLaunchInput(`https://apps.iris.to/#/${VALID_NPUB}/enshittifier/index.html?menu=0`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    });
  });

  it('parses legacy sites launcher share URLs by their hash route', () => {
    expect(parseLaunchInput(`https://sites.iris.to/#/${VALID_NPUB}/enshittifier/index.html?menu=0`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    });
  });

  it('parses launcher share URLs with no slash after the hash', () => {
    expect(parseLaunchInput(`https://apps.iris.to/#${VALID_NPUB}/enshittifier/index.html`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    });
    expect(parseLaunchInput(`#${VALID_NHASH}/index.html`)).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_NHASH,
      entryPath: 'index.html',
    });
  });

  it('parses snapshot launcher share URLs by their hash route', () => {
    expect(parseLaunchInput(`https://apps.iris.to/#/${VALID_SNAPSHOT_NHASH}/index.html?snapshot=1&k=${'a'.repeat(64)}`)).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_SNAPSHOT_NHASH,
      entryPath: 'index.html',
      snapshot: true,
      snapshotLinkKey: 'a'.repeat(64),
    });
  });

  it('parses readable iris-drive app URLs by their host and path', () => {
    expect(parseLaunchInput(`http://git.${VALID_NPUB}.iris.localhost:17321/index.html#/settings`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    });
  });

  it('parses readable iris-drive app URLs with npub before the app name', () => {
    expect(parseLaunchInput(`http://${VALID_NPUB}.git.iris.localhost:17321/index.html`)).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    });
  });

  it('parses htree immutable URLs including an explicit entry path', () => {
    expect(parseLaunchInput(`htree://${VALID_NHASH}/docs/index.html`)).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_NHASH,
      entryPath: 'docs/index.html',
    });
  });

  it('parses htree snapshot URLs including snapshot query params', () => {
    expect(parseLaunchInput(`htree://${VALID_SNAPSHOT_NHASH}/index.html?snapshot=1&k=${'b'.repeat(64)}`)).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_SNAPSHOT_NHASH,
      entryPath: 'index.html',
      snapshot: true,
      snapshotLinkKey: 'b'.repeat(64),
    });
  });

  it('rejects malformed input', () => {
    expect(parseLaunchInput('')).toBeNull();
    expect(parseLaunchInput('not-a-site')).toBeNull();
    expect(parseLaunchInput(VALID_NPUB)).toBeNull();
  });
});
