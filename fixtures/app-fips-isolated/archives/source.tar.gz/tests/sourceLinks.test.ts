import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { IRIS_CONTACTS_REPOSITORY_URL, getCanonicalGitRepositoryUrl } from '../src/lib/shareUrls';

const root = process.cwd();

describe('source repository links', () => {
  it('matches Iris Git canonical repository URLs', () => {
    expect(IRIS_CONTACTS_REPOSITORY_URL).toBe(getCanonicalGitRepositoryUrl('iris-contacts'));
    expect(IRIS_CONTACTS_REPOSITORY_URL).toBe(
      'https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-contacts',
    );
  });

  it('keeps package and README source URLs aligned with settings', () => {
    const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')) as {
      repository?: string;
    };
    const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');

    expect(packageJson.repository).toBe(IRIS_CONTACTS_REPOSITORY_URL);
    expect(readme).toContain(`Source: <${IRIS_CONTACTS_REPOSITORY_URL}>`);
  });
});
