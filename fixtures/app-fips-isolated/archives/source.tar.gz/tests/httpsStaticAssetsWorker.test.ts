import { describe, expect, it, vi } from 'vitest';
import worker from '../scripts/https-static-assets-worker.mjs';

describe('HTTPS static assets Worker', () => {
  it('redirects plain HTTP requests to the same HTTPS URL', async () => {
    const response = await worker.fetch(
      new Request('http://apps.iris.to/#/app'),
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://apps.iris.to/#/app');
  });

  it('redirects the legacy sites host to the canonical apps host', async () => {
    const response = await worker.fetch(
      new Request('https://sites.iris.to/docs/?q=1#/app'),
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://apps.iris.to/docs/?q=1#/app');
  });

  it('redirects Cloudflare requests with no TLS version', async () => {
    const request = new Request('https://demo.hashtree.cc/');
    Object.defineProperty(request, 'cf', {
      value: {},
    });

    const response = await worker.fetch(
      request,
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://demo.hashtree.cc/');
  });

  it('serves HTTPS requests from static assets', async () => {
    const assetResponse = new Response('sites');
    const fetch = vi.fn().mockResolvedValue(assetResponse);

    const response = await worker.fetch(
      new Request('https://apps.iris.to/'),
      { ASSETS: { fetch } },
    );

    expect(response).toBe(assetResponse);
    expect(fetch).toHaveBeenCalledOnce();
  });

  it('serves launcher icons from the root when a nested shell resolves relative image URLs', async () => {
    const assetResponse = new Response('icon');
    const fetch = vi.fn().mockResolvedValue(assetResponse);

    const response = await worker.fetch(
      new Request('https://apps.iris.to/open-iris-apps/launcher-icons/iris-drive-icon.svg'),
      { ASSETS: { fetch } },
    );

    expect(response).toBe(assetResponse);
    expect(fetch).toHaveBeenCalledOnce();
    expect(fetch.mock.calls[0]?.[0]).toBeInstanceOf(Request);
    expect(fetch.mock.calls[0]?.[0].url).toBe('https://apps.iris.to/launcher-icons/iris-drive-icon.svg');
  });

  it('serves root shell assets when a nested shell resolves relative build URLs', async () => {
    const assetResponse = new Response('asset');
    const fetch = vi.fn().mockResolvedValue(assetResponse);

    await worker.fetch(
      new Request('https://apps.iris.to/open-iris-apps/assets/index-abc123.js?cache=1'),
      { ASSETS: { fetch } },
    );
    await worker.fetch(
      new Request('https://apps.iris.to/open-iris-apps/favicon.svg'),
      { ASSETS: { fetch } },
    );

    expect(fetch.mock.calls.map((call) => call[0].url)).toEqual([
      'https://apps.iris.to/assets/index-abc123.js?cache=1',
      'https://apps.iris.to/favicon.svg',
    ]);
  });

  it('does not rewrite child hashtree app asset requests', async () => {
    const assetResponse = new Response('child app asset');
    const fetch = vi.fn().mockResolvedValue(assetResponse);

    await worker.fetch(
      new Request('https://apps.iris.to/htree/nhash1app/launcher-icons/app.svg'),
      { ASSETS: { fetch } },
    );

    expect(fetch).toHaveBeenCalledOnce();
    expect(fetch.mock.calls[0]?.[0].url).toBe('https://apps.iris.to/htree/nhash1app/launcher-icons/app.svg');
  });
});
