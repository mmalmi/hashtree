import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../src/lib/uploadWorkerClient', () => ({
  putUploadBlocks: vi.fn(async (blocks: Array<{ hashHex: string }>) =>
    blocks.map((block) => ({
      hashHex: block.hashHex,
      nhash: `nhash-${block.hashHex}`,
    }))
  ),
}));

import {
  createSiteUploadTextFile,
  createSiteUploadDraft,
  formatSiteUploadBytes,
  getSiteUploadFilesFromDataTransfer,
  inferSiteUploadAppMetadata,
  markSiteUploadFilePath,
  publishSiteUploadDraft,
} from '../src/lib/siteUploader';
import { putUploadBlocks } from '../src/lib/uploadWorkerClient';

function fakeUploadFile(path: string, size: number, type = 'text/plain'): File {
  const name = path.split('/').filter(Boolean).at(-1) ?? 'file.txt';
  return {
    lastModified: 1,
    name,
    size,
    stream() {
      throw new Error('Preview must not read file bytes');
    },
    type,
    webkitRelativePath: path,
  } as unknown as File;
}

function realUploadFile(path: string, contents: string, type: string): File {
  const name = path.split('/').filter(Boolean).at(-1) ?? 'file.txt';
  return markSiteUploadFilePath(new File([contents], name, { type, lastModified: 1 }), path);
}

function fakeEntryFile(file: File) {
  return {
    isDirectory: false,
    isFile: true,
    name: file.name,
    file(resolve: (file: File) => void) {
      resolve(file);
    },
  };
}

function fakeEntryDirectory(name: string, entries: unknown[]) {
  let read = false;
  return {
    isDirectory: true,
    isFile: false,
    name,
    createReader() {
      return {
        readEntries(resolve: (entries: unknown[]) => void) {
          resolve(read ? [] : entries);
          read = true;
        },
      };
    },
  };
}

describe('site upload preview', () => {
  beforeEach(() => {
    vi.mocked(putUploadBlocks).mockClear();
  });

  it('creates a directory preview without reading or uploading file bytes', () => {
    const draft = createSiteUploadDraft([
      fakeUploadFile('dist/index.html', 120, 'text/html'),
      fakeUploadFile('dist/assets/app.js', 2500, 'text/javascript'),
      fakeUploadFile('dist/.DS_Store', 300),
    ]);

    expect(draft.rootName).toBe('dist');
    expect(draft.fileCount).toBe(2);
    expect(draft.totalBytes).toBe(2620);
    expect(draft.hasIndexHtml).toBe(true);
    expect(draft.entryPath).toBe('index.html');
    expect(draft.previewFiles.map((file) => file.path)).toEqual([
      'assets/app.js',
      'index.html',
    ]);
  });

  it('formats preview byte counts compactly', () => {
    expect(formatSiteUploadBytes(0)).toBe('0 B');
    expect(formatSiteUploadBytes(512)).toBe('512 B');
    expect(formatSiteUploadBytes(1536)).toBe('2 KB');
    expect(formatSiteUploadBytes(1.5 * 1024 * 1024)).toBe('1.5 MB');
  });

  it('infers app name and icon from a web manifest', async () => {
    const draft = createSiteUploadDraft([
      realUploadFile('dist/index.html', '<title>Ignored title</title>', 'text/html'),
      realUploadFile('dist/manifest.webmanifest', JSON.stringify({
        name: 'Fixture App',
        icons: [
          { src: 'icons/small.svg', sizes: '64x64', type: 'image/svg+xml' },
          { src: 'icons/app.svg', sizes: '512x512', type: 'image/svg+xml' },
        ],
      }), 'application/manifest+json'),
      realUploadFile('dist/icons/small.svg', '<svg xmlns="http://www.w3.org/2000/svg"></svg>', 'image/svg+xml'),
      realUploadFile('dist/icons/app.svg', '<svg xmlns="http://www.w3.org/2000/svg"><title>Icon</title></svg>', 'image/svg+xml'),
    ]);

    const metadata = await inferSiteUploadAppMetadata(draft);

    expect(metadata.name).toBe('Fixture App');
    expect(metadata.source).toBe('manifest');
    expect(metadata.iconPath).toBe('icons/app.svg');
    expect(metadata.icon).toMatch(/^data:image\/svg\+xml;base64,/);
  });

  it('falls back to html title and favicon metadata', async () => {
    const draft = createSiteUploadDraft([
      realUploadFile('build/index.html', `
        <html>
          <head>
            <title>HTML &amp; App</title>
            <link rel="icon" href="/favicon.svg">
          </head>
        </html>
      `, 'text/html'),
      realUploadFile('build/favicon.svg', '<svg xmlns="http://www.w3.org/2000/svg"></svg>', 'image/svg+xml'),
    ]);

    const metadata = await inferSiteUploadAppMetadata(draft);

    expect(metadata.name).toBe('HTML & App');
    expect(metadata.source).toBe('html');
    expect(metadata.iconPath).toBe('favicon.svg');
    expect(metadata.icon).toMatch(/^data:image\/svg\+xml;base64,/);
  });

  it('collects dropped directory entries before creating a preview', async () => {
    const indexFile = fakeUploadFile('index.html', 120, 'text/html');
    const assetFile = fakeUploadFile('app.js', 800, 'text/javascript');
    const droppedDirectory = fakeEntryDirectory('site', [
      fakeEntryFile(indexFile),
      fakeEntryDirectory('assets', [
        fakeEntryFile(assetFile),
      ]),
    ]);
    const files = await getSiteUploadFilesFromDataTransfer({
      files: [],
      items: [{
        kind: 'file',
        webkitGetAsEntry: () => droppedDirectory,
      }],
    } as unknown as DataTransfer);
    const draft = createSiteUploadDraft(files);

    expect(draft.rootName).toBe('site');
    expect(draft.hasIndexHtml).toBe(true);
    expect(draft.entryPath).toBe('index.html');
    expect(draft.previewFiles.map((file) => file.path)).toEqual([
      'assets/app.js',
      'index.html',
    ]);
  });

  it('turns pasted text into a shareable paste.txt file', () => {
    const draft = createSiteUploadDraft([
      createSiteUploadTextFile('<h1>Hello</h1>'),
    ]);

    expect(draft.fileCount).toBe(1);
    expect(draft.hasIndexHtml).toBe(false);
    expect(draft.entryPath).toBe('paste.txt');
    expect(draft.previewFiles[0]?.path).toBe('paste.txt');
  });

  it('shares a draft as an unsigned immutable nhash launcher link', async () => {
    const draft = createSiteUploadDraft([
      createSiteUploadTextFile('hello from paste'),
    ]);
    const progressLabels: string[] = [];

    const published = await publishSiteUploadDraft(draft, {
      currentHost: 'apps.iris.to',
      onProgress: (progress) => {
        progressLabels.push(progress.label);
      },
    });

    expect(putUploadBlocks).toHaveBeenCalled();
    expect(published.immutableNhash).toMatch(/^nhash1/);
    expect(published.launcherHref).toBe(`https://apps.iris.to/#/${published.immutableNhash}/paste.txt`);
    expect(progressLabels).toContain('Uploading hashtree blocks');
    expect(progressLabels.at(-1)).toBe('Shared');
  });
});
