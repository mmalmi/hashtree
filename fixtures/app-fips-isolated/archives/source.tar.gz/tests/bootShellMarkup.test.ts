import { describe, expect, it } from 'vitest';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import {
  IRIS_OWNER,
  IRIS_OWNER_PUBKEY,
  getLauncherProfile,
  getLauncherProfileHref,
  getLauncherPrimaryHostForSite,
  getLauncherSuggestionSite,
  getLauncherSuggestionsForOwner,
  launcherProfiles,
  launcherSuggestions,
} from '../src/lib/launcherContent';
import {
  buildHashtreeInstallOptionsHref,
  buildIrisDriveDownloadHref,
  buildSuggestedAppHref,
} from '../src/lib/siteHost';

async function loadAppSource() {
  const sources = await Promise.all([
    readFile(resolve(import.meta.dirname, '..', 'src', 'App.svelte'), 'utf8'),
    readFile(resolve(import.meta.dirname, '..', 'src', 'components', 'LauncherScreen.svelte'), 'utf8'),
    readFile(resolve(import.meta.dirname, '..', 'src', 'components', 'RuntimeMenu.svelte'), 'utf8'),
    readFile(resolve(import.meta.dirname, '..', 'src', 'styles', 'launcher.css'), 'utf8'),
    readFile(resolve(import.meta.dirname, '..', 'src', 'styles', 'theme.css'), 'utf8'),
  ]);
  return sources.join('\n');
}

function loadLauncherIconSource(fileName: string) {
  return readFile(resolve(import.meta.dirname, '..', 'public', 'launcher-icons', fileName), 'utf8');
}

describe('iris-sites launcher markup', () => {
  it('keeps searchable suggestions while showing publish instructions', async () => {
    const source = await loadAppSource();

    expect(buildHashtreeInstallOptionsHref('apps.iris.to')).toBe(
      `https://git.iris.to/#/${IRIS_OWNER}/hashtree`,
    );
    expect(buildHashtreeInstallOptionsHref('iris.localhost:17321')).toBe(
      `http://git.${IRIS_OWNER}.iris.localhost:17321/index.html#/${IRIS_OWNER}/hashtree`,
    );
    expect(buildIrisDriveDownloadHref('apps.iris.to')).toBe('https://getdrive.iris.to/');
    expect(buildIrisDriveDownloadHref('iris.localhost:17321')).toBe(
      `http://irisdrive-org-site.${IRIS_OWNER}.iris.localhost:17321/index.html`,
    );
    expect(source).toContain('{#each primaryLauncherSuggestions as suggestion (getLauncherSuggestionKey(suggestion))}');
    expect(source).toContain('Iris: The Freedom Toolkit');
    expect(source).toContain('width=device-width, initial-scale=1, viewport-fit=cover');
    expect(source).toContain('apple-mobile-web-app-status-bar-style');
    expect(source).toContain('black-translucent');
    expect(source).toContain('color-scheme: light dark;');
    expect(source).toContain('--iris-screen-background');
    expect(source).toContain('background: var(--iris-screen-background);');
    expect(source).toContain('background-attachment: fixed;');
    expect(source).toContain('background-size: 100% 100%;');
    expect(source).toContain('min-height: 100dvh;');
    expect(source).toContain('@media (prefers-color-scheme: light)');
    expect(source).not.toContain('role="search"');
    expect(source).not.toContain('placeholder="Search"');
    expect(source).not.toContain('aria-label="Search"');
    expect(source).toContain('parseLaunchInput(launchInput)');
    expect(source).toContain('bind:this={addLinkInput}');
    expect(source).not.toContain('launcherSearchInput');
    expect(source).toContain('activeSuggestionKey');
    expect(source).toContain("const ADD_SITE_CARD_KEY = 'launcher:add-site'");
    expect(source).toContain("'.launcher-tools a.suggestion[href], .launcher-tools button.suggestion:not(:disabled)'");
    expect(source).toContain('clickActiveLauncherCard()');
    expect(source).not.toContain('openLauncherSuggestion');
    expect(source).toContain('function handleLauncherWindowKeydown(event: KeyboardEvent)');
    expect(source).toContain('onkeydown={handleLauncherWindowKeydown}');
    expect(source).toContain('function handleAddPanelKeydown(event: KeyboardEvent)');
    expect(source).toContain('onkeydown={handleAddPanelKeydown}');
    expect(source).toContain('onpaste={handleAddPanelPaste}');
    expect(source).toContain('ondragover={handleLauncherDragOver}');
    expect(source).toContain('ondrop={handleLauncherDrop}');
    expect(source).toMatch(/await previewSiteUploadFiles\(files\);\s+openAddPanel\(\);/);
    expect(source).toMatch(/await previewSiteUploadText\(text\);\s+openAddPanel\(\);/);
    expect(source).toContain('class:active={activeSuggestionKey === suggestionKey}');
    expect(source).toContain('onfocusin={() => setActiveSuggestion(suggestion)}');
    expect(source).toContain('.suggestion-shell.active .suggestion');
    expect(source).not.toContain('.suggestion:hover .suggestion-media');
    expect(source).toContain('activeSuggestionKey = null;');
    expect(source).not.toContain('class="launcher-eyebrow">ALPHA</p>');
    expect(source).toContain('class="launcher-title-logo"');
    expect(source).toContain("src={launcherAsset('favicon.svg')}");
    expect(source).toContain('.launcher-title-row');
    expect(source).toContain('class="launcher-title-text"');
    expect(source).toContain('--launcher-section-gap: 32px;');
    expect(source).toContain('--launcher-section-gap: 24px;');
    expect(source).toContain('--launcher-contact-gap: 16px;');
    expect(source).toContain('padding: max(56px, env(safe-area-inset-top)) 24px max(72px, env(safe-area-inset-bottom));');
    expect(source).toContain('padding: max(16px, env(safe-area-inset-top)) 16px max(24px, env(safe-area-inset-bottom));');
    expect(source).toContain('margin-bottom: var(--launcher-section-gap);');
    expect(source).toContain('gap: var(--launcher-section-gap);');
    expect(source).toContain('.launcher-top-row:not(.has-profile)');
    expect(source).toContain('-webkit-line-clamp: 2;');
    expect(source).not.toContain('suggestionMatchesSearch');
    expect(source).toContain('getNextGridKeyboardIndex(getCardRects(cards), currentIndex, direction)');
    expect(source).not.toContain('handleLauncherSearchKeydown');
    expect(source).toContain('onkeydown={(event) => handleLauncherAppCardKeydown(event, suggestion)}');
    expect(source).toContain("event.key === 'Enter'");
    expect(source).toContain('currentCard.click()');
    expect(source).toContain('class="suggestion launch-result-card" type="button" onclick={addParsedLaunchSiteToHome}');
    expect(source).toContain('onsubmit={submitAddLink}');
    expect(source).toContain('function submitAddLink');
    expect(source).not.toContain('type="submit"');
    expect(source).not.toContain('Open a shared app or site link');
    expect(source).not.toContain('class="launcher-button"');
    expect(source).not.toContain('placeholder="Paste an Iris app or site link"');
    expect(source).toContain('aria-label="Add site, folder, files, or text"');
    expect(source).toContain('data-testid="add-site-button"');
    expect(source).toContain('class="suggestion-shell add-site-shell"');
    expect(source).toContain('class:active={activeSuggestionKey === ADD_SITE_CARD_KEY || siteUploadDragActive}');
    expect(source).toContain('data-suggestion-key={ADD_SITE_CARD_KEY}');
    expect(source).toContain('activeSuggestionKey = ADD_SITE_CARD_KEY;');
    expect(source).toContain('class="suggestion add-site-tile"');
    expect(source).toContain('onkeydown={handleLauncherAppCardKeydown}');
    expect(source).toContain('class="suggestion-media add-site-media"');
    expect(source).toContain('class="add-site-plus"');
    expect(source).toContain('cursor: pointer;');
    expect(source).toContain('createSiteUploadDraft(files)');
    expect(source).toContain('createSiteUploadTextFile(text)');
    expect(source).toContain('getSiteUploadFilesFromDataTransfer');
    expect(source).toContain('inferSiteUploadAppMetadata(draft)');
    expect(source).toContain('publishSiteUploadDraft(draft');
    expect(source).toContain('type="file"');
    expect(source).toContain('webkitdirectory');
    expect(source).toContain('data-testid="site-upload-file-input"');
    expect(source).toContain('role="dialog"');
    expect(source).toContain('tabindex="-1"');
    expect(source).toContain('class="add-site-backdrop"');
    expect(source).not.toContain('class="add-mode-control"');
    expect(source).toContain('placeholder="URL"');
    expect(source).toContain('aria-label="URL"');
    expect(source).toContain('Add by URL');
    expect(source).toContain('addUrlFormOpen');
    expect(source).toContain('onclick={chooseAddByUrl}');
    expect(source).toContain('onclick={backToAddChoices}');
    expect(source).toContain('aria-label="Back"');
    expect(source).toContain('class="add-site-back-icon"');
    expect(source).toContain("{addUrlFormOpen ? 'Add by URL' : 'Add app or site'}");
    expect(source).toContain('{:else if !siteUploadDraft}');
    expect(source).toContain('class="site-upload-source-icon"');
    expect(source).toContain('Upload folder');
    expect(source).toContain('Upload files');
    expect(source).not.toContain('Choose folder');
    expect(source).not.toContain('Choose files');
    expect(source).not.toContain('add-site-divider');
    expect(source).not.toContain('Preview text');
    expect(source).not.toContain('Paste or type text');
    expect(source).toContain('data-testid="site-upload-app-name"');
    expect(source).toContain('data-testid="site-upload-app-icon"');
    expect(source).toContain('data-testid="site-upload-confirm"');
    expect(source).toContain("{siteUploadPublishing ? 'Adding' : 'Add'}");
    expect(source).toContain('addLauncherHomeSuggestion(getLauncherHomeState(), appSuggestion)');
    expect(source).not.toContain('Link name');
    expect(source).not.toContain('siteUploadTreeName');
    expect(source).not.toContain('getSiteUploadTreeNameError');
    expect(source).not.toContain('A Nostr browser signer is required');
    expect(source).not.toContain('siteUploadPublishedHref');
    expect(source).not.toContain('Share files, text, or a site');
    expect(source).not.toContain('Browse files');
    expect(source).not.toContain('Confirm and share');
    expect(source.indexOf('class="suggestions"')).toBeLessThan(source.indexOf('class="add-site-backdrop"'));
    expect(source.indexOf('createSiteUploadDraft(files)')).toBeLessThan(source.indexOf('publishSiteUploadDraft(draft'));
    expect(source).not.toContain('<details class="publish-card">');
    expect(source).not.toContain('<span class="publish-title">Add yours</span>');
    expect(source).not.toContain('class="command-copy-button"');
    expect(source).not.toContain('Prefer Cargo, Homebrew, or manual install?');
    expect(source).not.toContain('See install options');
    expect(source).not.toContain('href={hashtreeInstallOptionsHref}');
    expect(source).not.toContain('href={irisFilesHref}');
    expect(source).not.toContain('Open Iris Drive');
    expect(source).not.toContain('Command line');
    expect(source).toContain('href={getSuggestionHref(suggestion)}');
    expect(source).toContain('role="list" aria-label="Apps"');
    expect(source).toContain('role="listitem"');
    expect(source).toContain('buildIrisDriveDownloadHref');
    expect(source).toContain('href={irisDriveDownloadHref}');
    expect(source).not.toContain('IRIS_DRIVE_RELEASE_HREF');
    expect(source).toContain('shouldShowIrisDriveDownloadPrompt');
    expect(source).toContain('{#if showOfflineDrivePrompt}');
    expect(source).toContain('class="offline-drive-row"');
    expect(source).toContain('class="offline-drive-icon"');
    expect(source).toContain('Download Iris Drive to use these apps offline');
    expect(source).toContain('If you still need a phone number or email:');
    expect(source).toContain('class="legacy-contact-section"');
    expect(source).toContain('class="legacy-contact-grid suggestions"');
    expect(source).toContain('role="list" aria-label="Phone number and email"');
    expect(source).not.toContain('iris-drive?tab=releases');
    expect(source).not.toContain('iris-drive?tab=releases&id=latest');
    expect(source.indexOf('class="suggestions"')).toBeLessThan(source.indexOf('class="offline-drive-row"'));
    expect(source.indexOf('class="offline-drive-row"')).toBeLessThan(source.indexOf('class="legacy-contact-section"'));
    expect(source.indexOf('class="legacy-contact-section"')).toBeLessThan(source.indexOf('class="site-upload-panel"'));
    expect(source).toContain('onpointerdown={(event) => handleSuggestionPointerDown(event, suggestion)}');
    expect(source).toContain('onpointermove={handleSuggestionPointerMove}');
    expect(source).toContain("window.addEventListener('touchmove', handleSuggestionTouchMove, { passive: false });");
    expect(source).toMatch(/function handleSuggestionTouchMove\(event: TouchEvent\)[\s\S]*?event\.preventDefault\(\);[\s\S]*?moveSuggestionDrag\(touch\.clientX, touch\.clientY\);/);
    expect(source).toContain('onpointerdown={handleLauncherBackdropPointerDown}');
    expect(source).toContain('ondragstart={handleSuggestionNativeDragStart}');
    expect(source).toContain('draggable="false"');
    expect(source).toContain("target.closest('.suggestion-shell') || target.closest('.home-toolbar')");
    expect(source).toContain("event.pointerType === 'mouse' && event.button !== 0");
    expect(source).not.toContain("!customizeApps || event.pointerType === 'mouse'");
    expect(source).not.toContain("event.pointerType === 'mouse' || event.button !== 0");
    expect(source).toContain('dragGhost = {');
    expect(source).toContain('let longPressShell');
    expect(source).toContain('startSuggestionDrag(event, suggestion, longPressShell)');
    expect(source).toContain('moveSuggestionDrag(event.clientX, event.clientY)');
    expect(source).toContain('<svelte:window');
    expect(source).toContain('onpointerup={handleGlobalSuggestionPointerEnd}');
    expect(source).toContain('class="suggestion-drag-ghost"');
    expect(source).toContain('class:lift={dragGhost.lift}');
    expect(source).toContain('reorderLauncherHomeSuggestion(getLauncherHomeState(), profileSuggestions, sourceKey, targetKey)');
    expect(source).toContain('{#if customizeApps}');
    expect(source).toContain('Reset');
    expect(source).toContain('Done');
    expect(source).toContain('.home-toolbar.editing');
    expect(source).toContain('border: 1px solid var(--iris-card-border);');
    expect(source).toContain('background: var(--iris-card-background);');
    expect(source).not.toContain('background: #111926;');
    expect(source).not.toContain('aria-pressed={customizeApps}');
    expect(source).not.toContain('>Edit<');
    expect(source).not.toContain('suggestion-reorder-controls');
    expect(source).toContain('redirectPrimaryHostRuntime(site)');
    expect(source).toContain("host.endsWith('.hashtree.cc')");
    expect(source).toContain('window.location.replace(`https://${primaryHost}/`)');
    expect(source).toContain('frameShowsWorkerPortFailure(siteFrame)');
    expect(source).toContain("Worker port not available");
    expect(source).toContain('frameReloadNonce += 1');
    expect(source).toContain('shouldRedirectPortalShellHost(window.location.host)');
    expect(source).toContain('isLocalDevShellHost(window.location.host)');
    expect(source).not.toContain('Add your app or site');
    expect(source).not.toContain('Decentralized CDN');
    expect(source).not.toContain('Open hashtree sites on their own origin.');
    expect(source).not.toContain('placeholder="nhash1... or npub1.../site"');
    expect(source).not.toContain('Publish your own site');
    expect(source).not.toContain('Install hashtree');
    expect(source).not.toContain('Choose an app');
    expect(source).not.toContain('Featured');
    expect(source).not.toContain('Authors');
    expect(source).not.toContain('<code>{PUBLISH_IMMUTABLE_COMMAND}</code>');
    expect(source).not.toContain('<code>l={SITE_DISCOVERY_LABEL}</code>');
    expect(source).not.toContain('Static showcase sites stay here until published sites carry a dedicated discovery tag.');
    expect(source).toContain('class="suggestion-icon"');
    expect(source).toContain('src={suggestion.icon}');
    expect(source).not.toContain('class="suggestion-blurb"');
    expect(source).not.toContain('class="suggestion-owner-row"');
    expect(source).toContain('aria-label={`Remove ${suggestion.name} from home`}');
    expect(source).not.toContain('openShareModal(getSuggestionShareHref(suggestion))');
    expect(source).not.toContain('aria-label={`More actions for ${suggestion.name}`}');
    expect(source).not.toContain('role="menuitem"');
    expect(source).not.toContain('>Share<');
    expect(source).toContain('class="suggestion-remove-button"');
    expect(source).toContain('.suggestion-shell.editing .suggestion-action-shell');
    expect(source).not.toContain('.suggestion-shell:hover:not(:focus-within):not(.editing) .suggestion-action-shell');
    expect(source).toContain('.suggestion-shell.dragging .suggestion');
    expect(source).toContain('.suggestion-drag-ghost.lift');
    expect(source).toContain('-webkit-user-drag: none;');
    expect(source).toContain('-webkit-touch-callout: none;');
    expect(source).toContain('transition-property: opacity, transform;');
    expect(source).not.toContain('transition-delay: 500ms, 500ms;');
    expect(source).toMatch(/\.suggestion-name\s*{[^}]*text-overflow: ellipsis;[^}]*white-space: nowrap;/s);
    expect(source).toContain('class="runtime-owner-row"');
    expect(source).toContain('pubkey={runtimeOwnerProfile.pubkey}');
    expect(source).toContain('href={runtimeOwnerProfileHref}');
    expect(source).toContain('class="profile-user-link"');
    expect(source).toContain('pubkey={profile.pubkey}');
    expect(source).toContain('href={getLauncherProfileHref(profile.npub)}');
    expect(source).toContain('class="direct-file-home-link"');
    expect(source).toContain('aria-label="Open Iris Sites"');
    expect(source).toContain('href={sitesHomeHref}');
    expect(source).toContain('function handleDirectFileError()');
    expect(source).toContain('onerror={handleDirectFileError}');
    expect(launcherSuggestions.map((suggestion) => suggestion.name)).toEqual([
      'Drive',
      'Chat',
      'Market',
      'Contacts',
      'Wallet',
      'Calendar',
      'Docs',
      'Meet',
      'Maps',
      'Social',
      'Groups',
      'Audio',
      'Video',
      'Boards',
      'Nostr VPN',
      'WebVM',
      'Git',
      'Quick Share',
      'silent.link',
      'ProtonMail',
    ]);
    expect(launcherSuggestions.map((suggestion) => suggestion.name)).not.toContain('MIDI Enshittifier');
    expect(launcherSuggestions.map((suggestion) => suggestion.name)).not.toContain('iris browser');
    expect(launcherSuggestions.some((suggestion) => suggestion.href === 'https://browser.iris.to/')).toBe(false);
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Chat')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-chat-site/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'iris-chat-site',
        primaryHost: 'chat.iris.to',
      }),
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Contacts')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/contacts/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'contacts',
        icon: './launcher-icons/iris-contacts-icon.svg',
        primaryHost: 'contacts.iris.to',
      }),
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Wallet')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/cashu-me/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'cashu-me',
        icon: './launcher-icons/cashu-wallet-icon.png',
        primaryHost: 'wallet.cashu.me',
      }),
    );
    const walletSuggestion = launcherSuggestions.find((suggestion) => suggestion.name === 'Wallet');
    const walletSite = walletSuggestion ? getLauncherSuggestionSite(walletSuggestion) : null;
    expect(walletSite).not.toBeNull();
    expect(getLauncherPrimaryHostForSite(walletSite)).toBe('wallet.cashu.me');
    expect(buildSuggestedAppHref(walletSite!, 'apps.iris.to', walletSuggestion!.primaryHost)).toBe('https://wallet.cashu.me/');
    expect(buildSuggestedAppHref(walletSite!, 'iris.localhost:17321', walletSuggestion!.primaryHost)).toBe(
      `http://cashu-me.${IRIS_OWNER}.iris.localhost:17321/index.html`,
    );
    expect(getLauncherPrimaryHostForSite({
      kind: 'mutable',
      siteKey: 'custom',
      title: 'Custom',
      npub: IRIS_OWNER,
      treeName: 'my-app',
      entryPath: 'index.html',
    })).toBeNull();
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Social')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-client-site/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'iris-client-site',
        primaryHost: 'social.iris.to',
      }),
    );
    const calendarSuggestion = launcherSuggestions.find((suggestion) => suggestion.name === 'Calendar');
    const calendarSite = calendarSuggestion ? getLauncherSuggestionSite(calendarSuggestion) : null;
    expect(calendarSuggestion).toEqual(expect.objectContaining({ primaryHost: 'calendar.iris.to' }));
    expect(calendarSite).not.toBeNull();
    expect(buildSuggestedAppHref(calendarSite!, 'apps.iris.to', calendarSuggestion!.primaryHost)).toBe('https://calendar.iris.to/');
    expect(buildSuggestedAppHref(calendarSite!, 'iris.localhost:17321', calendarSuggestion!.primaryHost)).toBe(
      `http://calendar.${IRIS_OWNER}.iris.localhost:17321/index.html`,
    );
    const videoSuggestion = launcherSuggestions.find((suggestion) => suggestion.name === 'Video');
    const videoSite = videoSuggestion ? getLauncherSuggestionSite(videoSuggestion) : null;
    expect(videoSuggestion).toEqual(expect.objectContaining({
      href: `#/${IRIS_OWNER}/video/index.html`,
      ownerNpub: IRIS_OWNER,
      treeName: 'video',
      icon: './launcher-icons/iris-video-icon.svg',
      primaryHost: 'video.iris.to',
    }));
    expect(videoSite).not.toBeNull();
    expect(buildSuggestedAppHref(videoSite!, 'apps.iris.to', videoSuggestion!.primaryHost)).toBe('https://video.iris.to/');
    expect(buildSuggestedAppHref(videoSite!, 'iris.localhost:17321', videoSuggestion!.primaryHost)).toBe(
      `http://video.${IRIS_OWNER}.iris.localhost:17321/index.html`,
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Nostr VPN')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/nostrvpn-org-site/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'nostrvpn-org-site',
      }),
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'WebVM')).toEqual(
      expect.objectContaining({
        href: 'https://webvm.iris.to/',
        blurb: 'Browser-hosted Linux with FIPS, Nostr VPN pairing, and Hashtree tools',
        icon: './launcher-icons/webvm-icon.ico',
        external: true,
      }),
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'Quick Share')).toEqual(
      expect.objectContaining({
        href: '#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/hashtree-cc-site/index.html',
        ownerNpub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        treeName: 'hashtree-cc-site',
        primaryHost: 'hashtree.cc',
      }),
    );
    const quickShareSuggestion = launcherSuggestions.find((suggestion) => suggestion.name === 'Quick Share');
    const quickShareSite = quickShareSuggestion ? getLauncherSuggestionSite(quickShareSuggestion) : null;
    expect(quickShareSite).not.toBeNull();
    expect(buildSuggestedAppHref(quickShareSite!, 'apps.iris.to', quickShareSuggestion!.primaryHost)).toBe('https://hashtree.cc/');
    expect(buildSuggestedAppHref(quickShareSite!, 'iris.localhost:17321', quickShareSuggestion!.primaryHost)).toBe(
      `http://hashtree-cc-site.${IRIS_OWNER}.iris.localhost:17321/index.html`,
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'silent.link')).toEqual(
      expect.objectContaining({
        href: 'https://silent.link/',
        icon: './launcher-icons/silent-link-favicon.png',
        external: true,
      }),
    );
    expect(launcherSuggestions.find((suggestion) => suggestion.name === 'ProtonMail')).toEqual(
      expect.objectContaining({
        href: 'https://proton.me/',
        icon: './launcher-icons/proton-favicon.png',
        external: true,
      }),
    );
    expect(getLauncherSuggestionSite(launcherSuggestions.find((suggestion) => suggestion.name === 'silent.link')!)).toBeNull();
    expect(getLauncherSuggestionSite(launcherSuggestions.find((suggestion) => suggestion.name === 'ProtonMail')!)).toBeNull();
    expect(getLauncherSuggestionSite(launcherSuggestions.find((suggestion) => suggestion.name === 'WebVM')!)).toBeNull();
    expect(launcherSuggestions.at(-5)?.name).toBe('WebVM');
    expect(launcherSuggestions.at(-4)?.name).toBe('Git');
    expect(launcherSuggestions.at(-3)?.name).toBe('Quick Share');
    expect(launcherSuggestions.at(-2)?.name).toBe('silent.link');
    expect(launcherSuggestions.at(-1)?.name).toBe('ProtonMail');
    expect(launcherSuggestions.every((suggestion) => suggestion.icon?.startsWith('./launcher-icons/'))).toBe(true);
    expect(launcherSuggestions.filter((suggestion) => !suggestion.external).every((suggestion) =>
      suggestion.ownerNpub && suggestion.treeName
    )).toBe(true);
    expect(launcherProfiles).toEqual([
      {
        npub: 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
        pubkey: IRIS_OWNER_PUBKEY,
        name: 'Iris',
      },
    ]);
    expect(IRIS_OWNER_PUBKEY).toBe('336f319763657d6b0e65a5b5876719e8c8dcdcf9396852be71ee26b73368b29b');
    expect(getLauncherProfileHref(launcherProfiles[0].npub)).toBe(
      '#/profile/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm',
    );
    expect(getLauncherProfile(launcherProfiles[0].npub).pubkey).toBe(IRIS_OWNER_PUBKEY);
    expect(getLauncherSuggestionsForOwner(launcherProfiles[0].npub).length).toBeGreaterThan(6);
  });

  it('keeps cohesive launcher icon treatments without stretching Meet', async () => {
    const [meetIcon, quickShareIcon] = await Promise.all([
      loadLauncherIconSource('iris-meet-icon.svg'),
      loadLauncherIconSource('hashtree-cc-favicon.svg'),
    ]);

    expect(meetIcon).toContain('linearGradient id="camera"');
    expect(meetIcon).toContain('scale(0.83)');
    expect(meetIcon).toContain('<rect width="34.8" height="33.9"');
    expect(meetIcon).not.toContain('<rect width="29" height="26"');
    expect(quickShareIcon).toContain('linearGradient id="hash"');
    expect(quickShareIcon).toContain('stop-color="#a779ff"');
    expect(quickShareIcon).toContain('stop-color="#6f3dff"');
    expect(quickShareIcon).toContain('fill="url(#hash)"');
    expect(quickShareIcon).not.toContain('stop-color="#42e8ff"');
    expect(quickShareIcon).not.toContain('stop-color="#ff4fd8"');
  });
});
