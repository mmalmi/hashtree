import { describe, expect, it } from 'vitest';
import { nhashDecode, nhashEncode, toHex } from '@hashtree/core';
import { isInternalHtreePath, resolveHostedSite } from '../src/lib/siteConfig';
import { encodeImmutableHostLabel, encodeMutableHostLabel } from '../src/lib/siteIdentity';

const VALID_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const VALID_SNAPSHOT_NHASH = nhashEncode(new Uint8Array(32).fill(7));

describe('site config resolution', () => {
  it('recognizes internal htree document paths', () => {
    expect(isInternalHtreePath('/htree/nhash1example/index.html')).toBe(true);
    expect(isInternalHtreePath('/HTREE/npub1example/sites/index.html')).toBe(true);
    expect(isInternalHtreePath('/hash/nhash1example/index.html')).toBe(false);
  });

  it('does not special-case a pretty pilot alias host', () => {
    const site = resolveHostedSite({
      host: 'enshittifier.hashtree.cc',
      hash: '',
    });

    expect(site).toBeNull();
  });

  it('supports generic immutable roots through the launcher hash fragment', () => {
    const site = resolveHostedSite({
      host: 'apps.iris.to',
      hash: '#/nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq/index.html',
    });

    expect(site).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: 'nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq',
      entryPath: 'index.html',
    });
  });

  it('accepts legacy sites host launcher links', () => {
    const site = resolveHostedSite({
      host: 'sites.iris.to',
      hash: `#/${VALID_NPUB}/audio/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    });
  });

  it('treats the vite localhost dev server as the launcher shell', () => {
    const site = resolveHostedSite({
      host: 'localhost:5178',
      hash: `#/${VALID_NPUB}/audio/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    });
  });

  it('supports signed snapshot permalinks through the launcher hash fragment', () => {
    const site = resolveHostedSite({
      host: 'apps.iris.to',
      hash: `#/${VALID_SNAPSHOT_NHASH}/index.html?snapshot=1&k=${'a'.repeat(64)}`,
    });

    expect(site).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: VALID_SNAPSHOT_NHASH,
      entryPath: 'index.html',
      snapshot: true,
      snapshotLinkKey: 'a'.repeat(64),
    });
  });

  it('supports mutable sites through the launcher hash fragment without exposing npub or tree name to the server', () => {
    const site = resolveHostedSite({
      host: 'apps.iris.to',
      hash: `#/${VALID_NPUB}/apps%2Firis/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris',
      npub: VALID_NPUB,
      treeName: 'apps/iris',
      entryPath: 'index.html',
    });
  });

  it('supports mutable routes from the iris-drive local mutable portal host', () => {
    const site = resolveHostedSite({
      host: `sites.${VALID_NPUB}.iris.localhost:17321`,
      hash: `#/${VALID_NPUB}/audio/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    });
  });

  it('accepts the explicit hash namespace form for mutable routes', () => {
    const site = resolveHostedSite({
      host: 'apps.iris.to',
      hash: '#/npub/npub1zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz/public/index.html',
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'public',
      npub: 'npub1zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz',
      treeName: 'public',
      entryPath: 'index.html',
    });
  });

  it('derives immutable runtime sites from a keyless nhash host plus a fragment key', () => {
    const fullNhash = 'nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38';
    const decoded = nhashDecode(fullNhash);

    const site = resolveHostedSite({
      host: `${encodeImmutableHostLabel(decoded.hash)}.hashtree.cc`,
      hash: `#/index.html?k=${toHex(decoded.key!)}`,
    });

    expect(site).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: fullNhash,
      entryPath: 'index.html',
    });
  });

  it('derives immutable runtime snapshot sites from a keyless nhash host plus snapshot query params', () => {
    const bareNhash = nhashEncode(new Uint8Array(32));
    const decoded = nhashDecode(bareNhash);

    const site = resolveHostedSite({
      host: `${encodeImmutableHostLabel(decoded.hash)}.hashtree.cc`,
      hash: `#/index.html?snapshot=1&k=${'b'.repeat(64)}`,
    });

    expect(site).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash: bareNhash,
      entryPath: 'index.html',
      snapshot: true,
      snapshotLinkKey: 'b'.repeat(64),
    });
  });

  it('rejects immutable runtime fragments whose nhash does not match the hostname hash', () => {
    const fullNhash = 'nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38';
    const decoded = nhashDecode(fullNhash);
    const otherHash = new Uint8Array(decoded.hash);
    otherHash[0] ^= 1;

    const site = resolveHostedSite({
      host: `${encodeImmutableHostLabel(decoded.hash)}.hashtree.cc`,
      hash: `#/${nhashEncode(otherHash)}/index.html`,
    });

    expect(site).toBeNull();
  });

  it('derives mutable runtime sites from a single-label owner-tree host plus the full fragment route', () => {
    const site = resolveHostedSite({
      host: `${encodeMutableHostLabel(VALID_NPUB, 'apps/iris')}.hashtree.cc`,
      hash: `#/${VALID_NPUB}/apps%2Firis/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris',
      npub: VALID_NPUB,
      treeName: 'apps/iris',
      entryPath: 'index.html',
    });
  });

  it('does not re-enter the runtime router for documents already served from /htree', () => {
    const site = resolveHostedSite({
      host: `${encodeMutableHostLabel(VALID_NPUB, 'sites')}.hashtree.cc`,
      pathname: `/htree/${VALID_SNAPSHOT_NHASH}/index.html`,
      hash: '',
    });

    expect(site).toBeNull();
  });

  it('derives local mutable runtime sites from the sites.iris.localhost wildcard host', () => {
    const site = resolveHostedSite({
      host: `${encodeMutableHostLabel(VALID_NPUB, 'hashtree-cc-site')}.sites.iris.localhost:5178`,
      hash: `#/${VALID_NPUB}/hashtree-cc-site/index.html?menu=0&reload=1`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'hashtree-cc-site',
      npub: VALID_NPUB,
      treeName: 'hashtree-cc-site',
      entryPath: 'index.html',
    });
  });

  it('derives readable iris-drive mutable app hosts from the hostname and path', () => {
    const site = resolveHostedSite({
      host: `git.${VALID_NPUB}.iris.localhost:5178`,
      pathname: '/index.html',
      hash: '#/',
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    });
  });

  it('accepts readable iris-drive mutable app hosts with the npub before the app name', () => {
    const site = resolveHostedSite({
      host: `${VALID_NPUB}.git.iris.localhost:5178`,
      pathname: '/index.html',
      hash: '#/',
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    });
  });

  it('keeps app hash routes separate from readable iris-drive host resolution', () => {
    const site = resolveHostedSite({
      host: `docs.${VALID_NPUB}.iris.localhost:5178`,
      pathname: '/folder%20name/index.html',
      hash: `#/${VALID_NPUB}/other/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'docs',
      npub: VALID_NPUB,
      treeName: 'docs',
      entryPath: 'folder name/index.html',
    });
  });

  it('derives readable split nhash iris-drive hosts from the hostname and path', () => {
    const nhash = nhashEncode(new Uint8Array(32).fill(9));
    const host = `${nhash.match(/.{1,63}/g)?.join('.')}.iris.localhost:5178`;

    const site = resolveHostedSite({
      host,
      pathname: '/docs/index.html',
      hash: '#/ignored-by-local-readable-hosts',
    });

    expect(site).toEqual({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Iris Site',
      nhash,
      entryPath: 'docs/index.html',
    });
  });

  it('rejects mutable runtime fragments whose npub or tree do not match the hostname', () => {
    const site = resolveHostedSite({
      host: `${encodeMutableHostLabel(VALID_NPUB, 'apps/iris')}.hashtree.cc`,
      hash: `#/${VALID_NPUB}/other/index.html`,
    });

    expect(site).toBeNull();
  });

  it('accepts mutable runtime hosts for tree names that are only present in the fragment', () => {
    const site = resolveHostedSite({
      host: `${encodeMutableHostLabel(VALID_NPUB, 'apps/iris ui')}.hashtree.cc`,
      hash: `#/${VALID_NPUB}/apps%2Firis%20ui/index.html`,
    });

    expect(site).toEqual({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris ui',
      npub: VALID_NPUB,
      treeName: 'apps/iris ui',
      entryPath: 'index.html',
    });
  });

  it('does not treat old readable mutable hosts as valid runtimes', () => {
    const site = resolveHostedSite({
      host: 'npub1xdhnr9mrv47-enshittifier-63dvmlmvh6sxd65q7aba.hashtree.cc',
      hash: `#/${VALID_NPUB}/enshittifier/index.html`,
    });

    expect(site).toBeNull();
  });
});
