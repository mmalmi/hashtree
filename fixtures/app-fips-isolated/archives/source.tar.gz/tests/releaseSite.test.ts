import { describe, expect, it } from 'vitest';
import { createReleasePlan, parseArgs, runRelease } from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

type ReleaseStep = { id: string; command: string[] };

describe('iris-sites release-site', () => {
  it('uses the built-in Worker default and production routes for sites', () => {
    const parsed = parseArgs([]);

    expect(parsed.workerName).toBe('iris-sites');
    expect(parsed.treeName).toBe('sites');
    expect(parsed.routes).toEqual([
      'apps.iris.to/*',
      'sites.iris.to/*',
      '*.hashtree.cc/*',
    ]);
  });

  it('drops production routes when a custom Worker name is used', () => {
    const parsed = parseArgs(['--worker-name', 'iris-sites-preview']);

    expect(parsed.workerName).toBe('iris-sites-preview');
    expect(parsed.routes).toEqual([]);
  });

  it('builds a Worker release plan in build-test-publish-deploy order', () => {
    const plan = createReleasePlan({
      workerName: 'iris-sites',
      treeName: 'sites',
      routes: ['apps.iris.to/*', 'sites.iris.to/*', '*.hashtree.cc/*'],
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.map((step: ReleaseStep) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.find((step: ReleaseStep) => step.id === 'test-1')?.command).toEqual([
      'node',
      './scripts/verify-htree-cli.mjs',
    ]);
    expect(plan.steps.find((step: ReleaseStep) => step.id === 'test-2')?.command).toEqual([
      'pnpm',
      'verify:dependency-lock',
    ]);
    expect(plan.steps.find((step: ReleaseStep) => step.id === 'publish')?.command).toEqual([
      'htree',
      'add',
      '.',
      '--publish',
      'sites',
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist',
      '--name',
      'iris-sites',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      '4',
      '--route',
      'apps.iris.to/*',
      '--route',
      'sites.iris.to/*',
      '--route',
      '*.hashtree.cc/*',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist',
      '--name',
      'iris-sites',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-sites',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('runs hashtree publish and Worker deploy in parallel after tests', async () => {
    let activeReleaseSteps = 0;
    let maxActiveReleaseSteps = 0;
    const calls: string[] = [];

    await runRelease(
      {
        workerName: 'iris-sites',
        treeName: 'sites',
        routes: ['apps.iris.to/*', 'sites.iris.to/*', '*.hashtree.cc/*'],
        domains: [],
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      async (step) => {
        calls.push(step.id);
        if (step.id === 'publish' || step.id === 'deploy') {
          activeReleaseSteps += 1;
          maxActiveReleaseSteps = Math.max(maxActiveReleaseSteps, activeReleaseSteps);
          await new Promise((resolve) => setTimeout(resolve, 10));
          activeReleaseSteps -= 1;
          if (step.id === 'publish') {
            return {
              status: 0,
              stdout: 'published: npub1example/sites\nnhash1ace',
              stderr: '',
            };
          }
        }
        return { status: 0, stdout: '', stderr: '' };
      },
      { buildOutputExists: () => true },
    );

    expect(calls).toEqual(['build', 'test-1', 'test-2', 'test-3', 'test-4', 'test-5', 'publish', 'deploy']);
    expect(maxActiveReleaseSteps).toBe(2);
  });
});
