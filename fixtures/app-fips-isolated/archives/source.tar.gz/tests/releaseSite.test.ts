import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

describe('release-site', () => {
  it('uses the built-in Worker default for contacts', () => {
    const parsed = parseArgs(['contacts']);
    expect(parsed.workerName).toBe('iris-contacts');
    expect(parsed.treeName).toBe('contacts');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual(['contacts.iris.to']);
  });

  it('builds a release plan in build-test-publish-deploy order', () => {
    const plan = createReleasePlan({
      profileName: 'contacts',
      workerName: 'iris-contacts',
      routes: [],
      domains: ['contacts.iris.to'],
      treeName: 'contacts',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.map((step: { id: string }) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist',
      '--name',
      'iris-contacts',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--domain',
      'contacts.iris.to',
    ]);
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist',
      '--name',
      'iris-contacts',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-contacts',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('stops before publish when tests fail', async () => {
    const calls: string[] = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-1') {
        return { status: 1, stdout: '', stderr: 'test failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(runRelease({
      profileName: 'contacts',
      workerName: 'iris-contacts',
      treeName: 'contacts',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    }, runner, { buildOutputExists: () => true })).rejects.toThrow('Test iris contacts (1/5) failed');
    expect(calls).toEqual(['build', 'test-1']);
  });
});
