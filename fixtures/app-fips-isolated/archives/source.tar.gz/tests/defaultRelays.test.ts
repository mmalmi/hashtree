import { describe, expect, it } from 'vitest';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { resolveSiteRelays } from '../src/lib/defaultRelays';

describe('public site relay policy', () => {
  it('uses the shared Ditto-first defaults only when no selection exists', () => {
    expect(resolveSiteRelays()).toEqual(DEFAULT_PUBLIC_RELAYS);
    expect(resolveSiteRelays()[0]).toBe('wss://relay.ditto.pub');
  });
  it('preserves explicit empty, subset, local and custom selections', () => {
    expect(resolveSiteRelays('')).toEqual([]);
    expect(resolveSiteRelays('  , ')).toEqual([]);
    expect(resolveSiteRelays(' wss://relay.ditto.pub ')).toEqual(['wss://relay.ditto.pub']);
    expect(resolveSiteRelays('ws://localhost:4000,wss://custom.example,ws://localhost:4000'))
      .toEqual(['ws://localhost:4000', 'wss://custom.example']);
  });
});
