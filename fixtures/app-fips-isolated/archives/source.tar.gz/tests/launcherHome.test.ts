import { describe, expect, it } from 'vitest';
import {
  IRIS_OWNER,
  getLauncherSuggestionSite,
  launcherSuggestions,
  type LauncherSuggestion,
} from '../src/lib/launcherContent';
import {
  addLauncherHomeSuggestion,
  createLauncherSuggestionFromSite,
  getLauncherSuggestionKey,
  getVisibleLauncherSuggestions,
  moveLauncherHomeSuggestion,
  parseLauncherHomeState,
  reorderLauncherHomeSuggestion,
  removeLauncherHomeSuggestion,
  serializeLauncherHomeState,
  type LauncherHomeState,
} from '../src/lib/launcherHome';

function emptyState(): LauncherHomeState {
  return {
    hiddenSuggestionKeys: [],
    customSuggestions: [],
    orderedSuggestionKeys: [],
  };
}

describe('launcher home customization', () => {
  it('hides default suggestions and restores them when they are added again', () => {
    const chat = launcherSuggestions.find((suggestion) => suggestion.name === 'Chat');
    expect(chat).toBeDefined();

    const removed = removeLauncherHomeSuggestion(emptyState(), chat!);
    expect(getVisibleLauncherSuggestions(launcherSuggestions, [], removed.hiddenSuggestionKeys).map((suggestion) => suggestion.name))
      .not.toContain('Chat');

    const restored = addLauncherHomeSuggestion(removed, chat!);
    expect(getVisibleLauncherSuggestions(
      launcherSuggestions,
      [],
      restored.hiddenSuggestionKeys,
      restored.orderedSuggestionKeys,
    ).map((suggestion) => suggestion.name).at(0))
      .toBe('Chat');
    expect(restored.customSuggestions).toEqual([]);
  });

  it('adds custom mutable sites without duplicating built-in suggestions', () => {
    const customSuggestion = createLauncherSuggestionFromSite({
      kind: 'mutable',
      siteKey: 'notes',
      title: 'Notes',
      npub: IRIS_OWNER,
      treeName: 'notes',
      entryPath: 'index.html',
    });
    expect(customSuggestion).toEqual(expect.objectContaining({
      name: 'Notes',
      href: `#/${IRIS_OWNER}/notes/index.html`,
      ownerNpub: IRIS_OWNER,
      treeName: 'notes',
    }));

    const state = addLauncherHomeSuggestion(emptyState(), customSuggestion!);
    const visibleNames = getVisibleLauncherSuggestions(
      launcherSuggestions,
      state.customSuggestions,
      state.hiddenSuggestionKeys,
      state.orderedSuggestionKeys,
    ).map((suggestion) => suggestion.name);

    expect(visibleNames.at(0)).toBe('Notes');
  });

  it('adds and restores immutable nhash apps as launcher suggestions', () => {
    const nhash = 'nhash1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqc8247j';
    const customSuggestion = createLauncherSuggestionFromSite({
      kind: 'immutable',
      siteKey: 'nhash1fixture',
      title: 'Fixture App',
      nhash,
      entryPath: 'index.html',
    });
    expect(customSuggestion).toEqual(expect.objectContaining({
      name: 'Fixture App',
      href: `#/${nhash}/index.html`,
      nhash,
      entryPath: 'index.html',
    }));

    const withIcon: LauncherSuggestion = {
      ...customSuggestion!,
      icon: 'data:image/svg+xml;base64,PHN2Zy8+',
    };
    const state = addLauncherHomeSuggestion(emptyState(), withIcon);
    const restored = parseLauncherHomeState(serializeLauncherHomeState(state));
    const site = getLauncherSuggestionSite(restored.customSuggestions[0]!);

    expect(restored.customSuggestions[0]).toEqual(withIcon);
    expect(site).toEqual(expect.objectContaining({
      kind: 'immutable',
      title: 'Fixture App',
      entryPath: 'index.html',
      nhash: withIcon.nhash,
    }));
  });

  it('does not persist generic isolated-site names for immutable links', () => {
    const nhash = 'nhash1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqc8247j';

    expect(createLauncherSuggestionFromSite({
      kind: 'immutable',
      siteKey: 'docs',
      title: 'Isolated Site',
      nhash,
      entryPath: 'docs/index.html',
    })).toEqual(expect.objectContaining({
      name: 'Docs',
      blurb: 'Docs',
    }));

    expect(createLauncherSuggestionFromSite({
      kind: 'immutable',
      siteKey: 'root',
      title: 'Isolated Site',
      nhash,
      entryPath: 'index.html',
    })).toEqual(expect.objectContaining({
      name: 'App',
      blurb: 'App',
    }));
  });

  it('preserves catalogued app names and icons when adding known sites', () => {
    const drive = launcherSuggestions.find((suggestion) => suggestion.name === 'Drive')!;
    const suggestion = createLauncherSuggestionFromSite({
      kind: 'mutable',
      siteKey: 'drive',
      title: 'drive',
      npub: IRIS_OWNER,
      treeName: 'drive',
      entryPath: 'index.html',
    });

    expect(suggestion).toEqual(drive);
    expect(suggestion?.icon).toBe('./launcher-icons/iris-drive-icon.svg');
  });

  it('moves suggestions in the visible home order', () => {
    const state = emptyState();
    const visible = getVisibleLauncherSuggestions(launcherSuggestions, [], [], []);
    const chat = visible.find((suggestion) => suggestion.name === 'Chat')!;
    const moved = moveLauncherHomeSuggestion(state, chat, visible, -1);
    const movedNames = getVisibleLauncherSuggestions(
      launcherSuggestions,
      moved.customSuggestions,
      moved.hiddenSuggestionKeys,
      moved.orderedSuggestionKeys,
    ).map((suggestion) => suggestion.name);

    expect(movedNames.slice(0, 2)).toEqual(['Chat', 'Drive']);
  });

  it('reorders suggestions by source and target keys', () => {
    const state = emptyState();
    const visible = getVisibleLauncherSuggestions(launcherSuggestions, [], [], []);
    const drive = visible.find((suggestion) => suggestion.name === 'Drive')!;
    const calendar = visible.find((suggestion) => suggestion.name === 'Calendar')!;
    const reordered = reorderLauncherHomeSuggestion(
      state,
      visible,
      getLauncherSuggestionKey(calendar),
      getLauncherSuggestionKey(drive),
    );
    const reorderedNames = getVisibleLauncherSuggestions(
      launcherSuggestions,
      reordered.customSuggestions,
      reordered.hiddenSuggestionKeys,
      reordered.orderedSuggestionKeys,
    ).map((suggestion) => suggestion.name);

    expect(reorderedNames.slice(0, 2)).toEqual(['Calendar', 'Drive']);
  });

  it('round-trips stored state while dropping malformed suggestions', () => {
    const customSuggestion: LauncherSuggestion = {
      name: 'Notes',
      href: `#/${IRIS_OWNER}/notes/index.html`,
      blurb: 'Notes',
      ownerNpub: IRIS_OWNER,
      treeName: 'notes',
    };
    const state: LauncherHomeState = {
      hiddenSuggestionKeys: [getLauncherSuggestionKey(launcherSuggestions[0])],
      customSuggestions: [customSuggestion],
      orderedSuggestionKeys: [getLauncherSuggestionKey(customSuggestion)],
    };

    expect(parseLauncherHomeState(serializeLauncherHomeState(state))).toEqual(state);
    expect(parseLauncherHomeState('not json')).toEqual(emptyState());
    expect(parseLauncherHomeState(JSON.stringify({
      hiddenSuggestionKeys: [1, 'ok'],
      customSuggestions: [{ name: 'Bad' }, customSuggestion],
      orderedSuggestionKeys: [false, 'ok'],
    }))).toEqual({
      hiddenSuggestionKeys: ['ok'],
      customSuggestions: [customSuggestion],
      orderedSuggestionKeys: ['ok'],
    });
  });
});
