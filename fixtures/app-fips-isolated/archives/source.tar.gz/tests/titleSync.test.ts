import { describe, expect, it } from 'vitest';
import { buildShellTitle, normalizeFrameTitle } from '../src/lib/titleSync';

describe('runtime title sync helpers', () => {
  it('uses Iris Site for generic or missing site titles', () => {
    expect(buildShellTitle('Isolated Site', null)).toBe('Iris Site');
    expect(buildShellTitle('Iris Site', '')).toBe('Iris Site');
    expect(buildShellTitle('', null)).toBe('Iris Site');
  });

  it('uses the isolated page title when one is available', () => {
    expect(buildShellTitle('Iris Site', '  Otuspuutarha\nBloom  ')).toBe('Otuspuutarha Bloom');
    expect(buildShellTitle('hashtree-cc-site', 'hashtree - share privately')).toBe('hashtree - share privately');
  });

  it('keeps named mutable routes readable before the page title loads', () => {
    expect(buildShellTitle('audio', null)).toBe('audio · Iris');
  });

  it('normalizes blank frame titles to null', () => {
    expect(normalizeFrameTitle(' \n\t ')).toBeNull();
  });
});
