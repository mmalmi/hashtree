import { expect, it } from 'vitest';
import { DEFAULT_PUBLIC_RELAYS, resolvePublicRelayConfig } from '../src/lib/publicRelayConfig';

it('places the added public relay inside the bounded default graph selection', () => {
  const config = resolvePublicRelayConfig(undefined);
  expect(config.relays).toEqual(DEFAULT_PUBLIC_RELAYS);
  expect(['wss://graph-relay.iris.to', ...config.relays].slice(0, 3)).toEqual([
    'wss://graph-relay.iris.to', 'wss://relay.ditto.pub', 'wss://relay.damus.io',
  ]);
  expect(config.useDefaultBootstrap).toBe(true);
});

it.each(['', ',', 'ws://127.0.0.1:1234', 'wss://custom.example', DEFAULT_PUBLIC_RELAYS.join(',')])(
  'preserves an explicit environment selection %s without fixed bootstrap', (value: string) => {
    const config = resolvePublicRelayConfig(value);
    expect(config.relays).toEqual(value.split(',').filter(Boolean));
    expect(config.useDefaultBootstrap).toBe(false);
  },
);
