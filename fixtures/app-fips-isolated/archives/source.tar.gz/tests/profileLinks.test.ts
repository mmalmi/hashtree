import { describe, expect, it } from 'vitest';
import { pubkeyToNpub, type ContactRecord } from '../src/lib/contacts';
import {
  irisChatProfileUrl,
  irisSocialProfileUrl,
} from '../src/lib/profileLinks';

const pubkey = '1'.repeat(64);
const contact = {
  npub: pubkeyToNpub(pubkey),
} as ContactRecord;

describe('profile links', () => {
  it('builds Iris social and chat URLs from contact npubs', () => {
    expect(irisSocialProfileUrl(contact)).toBe(`https://iris.to/${contact.npub}`);
    expect(irisChatProfileUrl(contact)).toBe(`https://chat.iris.to/#/${contact.npub}`);
  });
});
