import { describe, expect, it } from 'vitest';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

async function loadAppSource() {
  return readFile(resolve(import.meta.dirname, '..', 'src', 'App.svelte'), 'utf8');
}

async function loadRuntimeMenuSource() {
  return readFile(resolve(import.meta.dirname, '..', 'src', 'components', 'RuntimeMenu.svelte'), 'utf8');
}

async function loadLauncherScreenSource() {
  return readFile(resolve(import.meta.dirname, '..', 'src', 'components', 'LauncherScreen.svelte'), 'utf8');
}

async function loadShareModalSource() {
  return readFile(resolve(import.meta.dirname, '..', 'src', 'lib', 'ShareModal.svelte'), 'utf8');
}

describe('iris-sites runtime menu markup', () => {
  it('links to the launcher and source views from the runtime menu', async () => {
    const source = await loadRuntimeMenuSource();
    const appSource = await loadAppSource();

    expect(source).toMatch(/href=\{launcherHref\}>\s*apps\.iris\.to\s*<\/a>/);
    expect(source).toMatch(/class="runtime-menu-item" href=\{sourceHref\}>\s*Open in Iris Drive\s*<\/a>/);
    expect(source).not.toMatch(/class="runtime-menu-home-link" href=\{sourceHref\}/);
    expect(source).toContain('Live updates');
    expect(source).toMatch(/>\s*Show QR code\s*<\/button>/);
    expect(appSource).toContain('<ShareModal />');
    expect(source).toContain('aria-label="Copy Iris Sites link"');
  });

  it('opens external suggestions in a new tab', async () => {
    const source = await loadLauncherScreenSource();

    expect(source).toContain("target={suggestion.external ? '_blank' : undefined}");
    expect(source).toContain("rel={suggestion.external ? 'noopener noreferrer' : undefined}");
  });

  it('centers the share modal and adapts its palette to system color scheme', async () => {
    const source = await loadShareModalSource();

    expect(source).toContain('align-self: center;');
    expect(source).toContain('justify-self: center;');
    expect(source).toContain('@media (prefers-color-scheme: light)');
    expect(source).toContain('--share-modal-card-background');
    expect(source).not.toContain('Open this site elsewhere');
  });
});
