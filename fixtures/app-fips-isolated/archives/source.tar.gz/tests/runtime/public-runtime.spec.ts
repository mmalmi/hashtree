import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from '../fixtures/localFipsWebSocketSeed';
import { expect, test, type Page } from '@playwright/test';
import { WebSocketServer, type WebSocket } from 'ws';
import { finalizeEvent, getPublicKey, type Event } from 'nostr-tools';

const relayUrl = 'ws://127.0.0.1:49315';
const ownerSecret = new Uint8Array(32).fill(41);
const contactSecret = new Uint8Array(32).fill(42);
const contactPubkey = getPublicKey(contactSecret);
const profile = finalizeEvent({ kind: 0, created_at: 1_790_000_000, tags: [], content: JSON.stringify({ name: 'Retained peer contact' }) }, contactSecret);
const follows = finalizeEvent({ kind: 3, created_at: 1_790_000_000, tags: [['p', contactPubkey]], content: '' }, ownerSecret);
let relay: WebSocketServer;
let seed: LocalFipsWebSocketSeed;
let publicHistory = true;
const saved: Event[] = [profile, follows];
const interests = new Map<WebSocket, Map<string, Record<string, unknown>[]>>();

function matches(event: Event, filter: Record<string, unknown>) {
  return Object.entries(filter).every(([key, value]) => {
    if (!Array.isArray(value)) return true;
    if (key === 'kinds') return value.includes(event.kind);
    if (key === 'authors') return value.includes(event.pubkey);
    if (key === 'ids') return value.includes(event.id);
    if (key.startsWith('#')) return event.tags.some(tag => tag[0] === key.slice(1) && value.includes(tag[1]));
    return true;
  });
}
function send(socket: WebSocket, message: unknown[]) {
  if (socket.readyState === 1) socket.send(JSON.stringify(message));
}

test.beforeAll(async () => {
  seed = await startLocalFipsWebSocketSeed(49319);
  relay = new WebSocketServer({ host: '127.0.0.1', port: 49315 });
  await new Promise<void>(resolve => relay.once('listening', resolve));
  relay.on('connection', socket => {
    interests.set(socket, new Map());
    socket.on('message', raw => {
      const message = JSON.parse(raw.toString());
      if (message[0] === 'REQ') {
        const filters = message.slice(2);
        interests.get(socket)!.set(message[1], filters);
        for (const event of saved) {
          if ((!publicHistory && [0, 3].includes(event.kind)) || !filters.some((filter: Record<string, unknown>) => matches(event, filter))) continue;
          send(socket, ['EVENT', message[1], event]);
        }
        send(socket, ['EOSE', message[1]]);
      } else if (message[0] === 'EVENT') {
        const event: Event = message[1];
        if (![0, 3].includes(event.kind)) {
          saved.push(event);
          for (const [peer, subscriptions] of interests) for (const [id, filters] of subscriptions) {
            if (filters.some(filter => matches(event, filter))) send(peer, ['EVENT', id, event]);
          }
        }
        send(socket, ['OK', event.id, true, '']);
      } else if (message[0] === 'CLOSE') interests.get(socket)!.delete(message[1]);
    });
    socket.on('close', () => interests.delete(socket));
  });
});
test.afterAll(async () => {
  for (const socket of relay.clients) socket.terminate();
  await Promise.all([
    new Promise<void>(resolve => relay.close(() => resolve())),
    seed.close(),
  ]);
});

async function peer(page: Page) {
  return page.evaluate(async () => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const provider = await runtime.peers;
    return { id: provider?.localPeerId, peers: provider?.listConnectedPeerIds() ?? [] };
  });
}
async function readPeerHistory(page: Page, eventId = profile.id) {
  return page.evaluate(async ({ id }) => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const result = await runtime.events.queryEvents([{ ids: [id] }], {
      cache: 'network-only', relays: [], sources: ['fips'], deadline: Date.now() + 10_000,
    });
    return result.events.map((event: Event) => event.id);
  }, { id: eventId });
}

async function publishToPeers(page: Page, event: Event) {
  await page.evaluate(async event => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const provider = await runtime.peers;
    await provider.nostrSource.publish(event, { id: 'local-publication', type: 'local-index' });
  }, event);
}
async function warmFeedResult(page: Page, eventId: string) {
  return page.evaluate(async id => {
    const path = '/tests/fixtures/peerWire.ts';
    return (await import(path)).warmFeedResult(id);
  }, eventId);
}


async function expectPeerPair(first: Page, second: Page, firstId: string, secondId: string) {
  expect(firstId).toMatch(/^(02|03)[0-9a-f]{64}$/);
  expect(secondId).toMatch(/^(02|03)[0-9a-f]{64}$/);
  expect(firstId).not.toBe(secondId);
  await Promise.all([
    expect.poll(() => peer(first).then(state => ({ id: state.id, connected: state.peers.includes(secondId) })),
      { timeout: 45_000 }).toEqual({ id: firstId, connected: true }),
    expect.poll(() => peer(second).then(state => ({ id: state.id, connected: state.peers.includes(firstId) })),
      { timeout: 45_000 }).toEqual({ id: secondId, connected: true }),
  ]);
}

async function expectFreshPeerBlock(sender: Page, receiver: Page) {
  const block = await sender.evaluate(async () => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const text = `reloaded-contact-peer-${crypto.randomUUID()}`;
    const stored = await runtime.blobs.putBlock(new TextEncoder().encode(text), { upload: false });
    return { hash: stored.hashHex, text };
  });
  expect(await receiver.evaluate(async hash => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    return (await runtime.blobs.hasBlob(hash, { sourceIds: ['idb'] })).available;
  }, block.hash)).toBe(false);
  expect(await receiver.evaluate(async hash => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const received = await runtime.blobs.getBlob(hash);
    return { text: new TextDecoder().decode(received.data), source: received.source };
  }, block.hash)).toEqual({ text: block.text, source: 'p2p' });
}

test('viewed profiles stay local while published profiles and cached files reach peers', async ({ browser, page }) => {
  // Two new 45-second recovery phases retain the original per-peer limit.
  test.setTimeout(220_000);
  await page.context().route('https://**', route => route.abort());
  await page.context().routeWebSocket('wss://**', socket => socket.close());
  await page.goto('/');
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  const seed = await page.evaluate(async ({ owner, relay }) => {
    const path = '/src/lib/nostr.ts';
    return (await import(path)).loadPublicContacts(owner, [relay]);
  }, { owner: follows.pubkey, relay: relayUrl });
  expect(seed.contacts.some((contact: { pubkey?: string }) => contact.pubkey === contactPubkey)).toBe(true);
  const stored = await page.evaluate(async () => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    return runtime.blobs.putBlock(new TextEncoder().encode('cached people index block'), { upload: false });
  });
  const original = await peer(page);
  expect(original.id).toBeTruthy();
  publicHistory = false;

  const secondContext = await browser.newContext();
  await secondContext.route('https://**', route => route.abort());
  await secondContext.routeWebSocket('wss://**', socket => socket.close());
  const second = await secondContext.newPage();
  await second.goto('/');
  await expect.poll(async () => (await peer(second)).peers, { timeout: 45_000 }).toContain(original.id);
  expect(await readPeerHistory(second)).toEqual([]);
  const published = finalizeEvent({ kind: 0, created_at: Math.floor(Date.now() / 1000), tags: [],
    content: JSON.stringify({ name: 'Explicitly published profile' }) }, ownerSecret);
  await publishToPeers(page, published);
  await expect.poll(() => readPeerHistory(second, published.id)).toEqual([published.id]);
  expect(await second.evaluate(async (hash) => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    const block = await runtime.blobs.getBlob(hash);
    return new TextDecoder().decode(block.data);
  }, stored.hashHex)).toBe('cached people index block');

  await second.evaluate(async peerId => {
    const path = '/tests/fixtures/peerWire.ts';
    await (await import(path)).reconnect(peerId);
  }, original.id);
  const expectedWarmResult = { reconciled: true, replayedKnownId: false };
  await expect.poll(() => warmFeedResult(second, published.id), { timeout: 45_000 }).toEqual(expectedWarmResult);
  const afterReconnect = finalizeEvent({ kind: 0, created_at: published.created_at + 1, tags: [],
    content: JSON.stringify({ name: 'Published after reconnect' }) }, new Uint8Array(32).fill(43));
  await publishToPeers(page, afterReconnect);
  await expect.poll(() => readPeerHistory(second, afterReconnect.id)).toEqual([afterReconnect.id]);
  expect(await warmFeedResult(second, published.id)).toEqual(expectedWarmResult);

  const secondId = (await peer(second)).id;
  await second.reload();
  expect((await peer(second)).id).toBe(secondId);
  expect(await second.evaluate(async (id) => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    return (await runtime.events.queryEvents([{ ids: [id] }], { cache: 'cache-only' })).events.map((event: Event) => event.id);
  }, published.id)).toEqual([published.id]);
  // The existing second-browser reload must recover a live session as well as cache.
  await expectPeerPair(page, second, original.id!, secondId!);
  await expectFreshPeerBlock(second, page);
  console.log('BROWSER_PEER_RELOAD', JSON.stringify({ app: 'iris-contacts', endpoint: 'second',
    identityStable: true, bothPeersConnected: true, freshTransfer: true, source: 'p2p' }));
  await page.reload();
  await expectPeerPair(page, second, original.id!, secondId!);
  await expectFreshPeerBlock(page, second);
  console.log('BROWSER_PEER_RELOAD', JSON.stringify({ app: 'iris-contacts', endpoint: 'first',
    identityStable: true, bothPeersConnected: true, freshTransfer: true, source: 'p2p' }));
  await page.close();

  const thirdContext = await browser.newContext();
  await thirdContext.route('https://**', route => route.abort());
  await thirdContext.routeWebSocket('wss://**', socket => socket.close());
  const third = await thirdContext.newPage();
  await third.goto('/');
  await expect.poll(async () => (await peer(third)).peers, { timeout: 45_000 }).toContain(secondId);
  expect(await readPeerHistory(third)).toEqual([]);
  expect(await third.evaluate(async (hash) => {
    const path = '/src/lib/publicRuntime.ts';
    const runtime = await (await import(path)).getPublicRuntime();
    return new TextDecoder().decode((await runtime.blobs.getBlob(hash)).data);
  }, stored.hashHex)).toBe('cached people index block');
  await secondContext.close();
  await thirdContext.close();
});
