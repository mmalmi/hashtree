import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from '../fixtures/localFipsWebSocketSeed';
import { expect, test, type Page } from '@playwright/test';
import { createHash } from 'node:crypto';
import { WebSocketServer, type WebSocket } from 'ws';
import { finalizeEvent, type Event } from 'nostr-tools';

const relayUrl = 'ws://127.0.0.1:49317';
const ownerSecret = new Uint8Array(32).fill(41);
const profile = finalizeEvent({ kind: 30064, created_at: 1_790_000_000, tags: [['d', 'peer-fixture'], ['l', 'hashtree'], ['hash', createHash('sha256').update('<h1>Retained peer site</h1>').digest('hex')]], content: '' }, ownerSecret);
let relay: WebSocketServer;
let seed: LocalFipsWebSocketSeed;
let publicHistory = true;
const saved: Event[] = [profile];
const interests = new Map<WebSocket, Map<string, Record<string, unknown>[]>>();

function matches(event: Event, filter: Record<string, unknown>) {
  return Object.entries(filter).every(([key, value]) => {
    if (!Array.isArray(value)) return true;
    if (key === 'kinds') return value.includes(event.kind);
    if (key === 'authors') return value.includes(event.pubkey);
    if (key === 'ids') return value.includes(event.id);
    if (key.startsWith('#')) return event.tags.some(tag => tag[0] === key.slice(1) && value.includes(tag[1]));
    return true;
  });
}
function send(socket: WebSocket, message: unknown[]) {
  if (socket.readyState === 1) socket.send(JSON.stringify(message));
}

test.beforeAll(async () => {
  seed = await startLocalFipsWebSocketSeed(49318);
  relay = new WebSocketServer({ host: '127.0.0.1', port: 49317 });
  await new Promise<void>(resolve => relay.once('listening', resolve));
  relay.on('connection', socket => {
    interests.set(socket, new Map());
    socket.on('message', raw => {
      const message = JSON.parse(raw.toString());
      if (message[0] === 'REQ') {
        const filters = message.slice(2);
        interests.get(socket)!.set(message[1], filters);
        for (const event of saved) {
          if ((!publicHistory && [30064].includes(event.kind)) || !filters.some((filter: Record<string, unknown>) => matches(event, filter))) continue;
          send(socket, ['EVENT', message[1], event]);
        }
        send(socket, ['EOSE', message[1]]);
      } else if (message[0] === 'EVENT') {
        const event: Event = message[1];
        if (![30064].includes(event.kind)) {
          saved.push(event);
          for (const [peer, subscriptions] of interests) for (const [id, filters] of subscriptions) {
            if (filters.some(filter => matches(event, filter))) send(peer, ['EVENT', id, event]);
          }
        }
        send(socket, ['OK', event.id, true, '']);
      } else if (message[0] === 'CLOSE') interests.get(socket)!.delete(message[1]);
    });
    socket.on('close', () => interests.delete(socket));
  });
});
test.afterAll(async () => {
  for (const socket of relay.clients) socket.terminate();
  await Promise.all([
    new Promise<void>(resolve => relay.close(() => resolve())),
    seed.close(),
  ]);
});

async function peer(page: Page) {
  return page.evaluate(async () => {
    const workerPath = '/src/lib/workerClient.ts';
    const peerPath = '/src/lib/peerRuntime.ts';
    const { workerClient, initWorkerClient } = await import(workerPath);
    await initWorkerClient();
    const provider = await (await import(peerPath)).startSitePeers(workerClient, ['ws://127.0.0.1:49317']);
    return { id: provider?.localPeerId, peers: provider?.listConnectedPeerIds() ?? [] };
  });
}
async function readPeerHistory(page: Page, cache: 'network-only' | 'cache-only' = 'network-only') {
  return page.evaluate(async ({ id, cache }) => {
    const path = '/src/lib/workerClient.ts';
    const { workerClient } = await import(path);
    const result = await workerClient.queryEvents([{ ids: [id] }], {
      cache, relays: [], sources: ['fips'], deadline: Date.now() + 10_000,
    });
    return result.events.map((event: Event) => event.id);
  }, { id: profile.id, cache });
}
async function readFile(page: Page, nhash: string) {
  return page.evaluate(async (nhash) => {
    const path = '/src/lib/workerClient.ts';
    const { registerMediaPort } = await import(path);
    const channel = new MessageChannel();
    const result = new Promise<string>((resolve, reject) => {
      const chunks: Uint8Array[] = [];
      const timeout = setTimeout(() => reject(new Error('Peer file timed out')), 20_000);
      channel.port1.onmessage = ({ data }) => {
        if (data.type === 'chunk') chunks.push(data.data);
        if (data.type === 'error') { clearTimeout(timeout); reject(new Error(data.error)); }
        if (data.type === 'done') {
          clearTimeout(timeout);
          const bytes = new Uint8Array(chunks.reduce((size, chunk) => size + chunk.length, 0));
          let offset = 0;
          for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
          resolve(new TextDecoder().decode(bytes));
        }
      };
    });
    await registerMediaPort(channel.port2);
    channel.port1.postMessage({ type: 'hashtree-file', requestId: 'peer-test', nhash, path: 'index.html', start: 0, mimeType: 'text/html' });
    try { return await result; } finally { channel.port1.close(); }
  }, nhash);
}


async function expectPeerPair(first: Page, second: Page, firstId: string, secondId: string) {
  expect(firstId).toMatch(/^(02|03)[0-9a-f]{64}$/);
  expect(secondId).toMatch(/^(02|03)[0-9a-f]{64}$/);
  expect(firstId).not.toBe(secondId);
  await Promise.all([
    expect.poll(() => peer(first).then(state => ({ id: state.id, connected: state.peers.includes(secondId) })),
      { timeout: 45_000 }).toEqual({ id: firstId, connected: true }),
    expect.poll(() => peer(second).then(state => ({ id: state.id, connected: state.peers.includes(firstId) })),
      { timeout: 45_000 }).toEqual({ id: secondId, connected: true }),
  ]);
}

async function expectFreshPeerSite(sender: Page, receiver: Page) {
  const fresh = await sender.evaluate(async () => {
    const path = '/src/lib/siteUploader.ts';
    const { createSiteUploadDraft, publishSiteUploadDraft } = await import(path);
    const text = `<h1>Reloaded site peer ${crypto.randomUUID()}</h1>`;
    const file = new File([text], 'index.html', { type: 'text/html' });
    const uploaded = await publishSiteUploadDraft(createSiteUploadDraft([file]), { blossomServers: [] });
    return { nhash: uploaded.immutableNhash, text };
  });
  // Every block was created after reload in the other isolated browser store.
  // Existing HTTPS/WSS denials and the empty upload-server list exclude HTTP.
  expect(await readFile(receiver, fresh.nhash)).toBe(fresh.text);
}

test('opening a site root stays private while shared files remain available after the uploader closes', async ({ browser, page }) => {
  // Budget the two added 45-second recoveries and existing bounded file reads.
  test.setTimeout(220_000);
  await page.context().route('https://**', route => route.abort());
  await page.context().routeWebSocket('wss://**', socket => socket.close());
  await page.goto('/');
  await expect(page.getByTestId('add-site-button')).toBeVisible();
  const original = await peer(page);
  expect(original.id).toBeTruthy();
  const ids = await page.evaluate(async ({ id, relay }) => {
    const path = '/src/lib/workerClient.ts';
    const { workerClient } = await import(path);
    const result = await workerClient.queryEvents([{ ids: [id] }], { relays: [relay], sources: [], deadline: Date.now() + 5_000 });
    return result.events.map((event: Event) => event.id);
  }, { id: profile.id, relay: relayUrl });
  expect(ids).toEqual([profile.id]);
  const nhash = await page.evaluate(async () => {
    const path = '/src/lib/siteUploader.ts';
    const { createSiteUploadDraft, publishSiteUploadDraft } = await import(path);
    const html = new File(['<h1>Retained peer site</h1>'], 'index.html', { type: 'text/html' });
    const uploaded = await publishSiteUploadDraft(createSiteUploadDraft([html]), { blossomServers: [] });
    return uploaded.immutableNhash;
  });
  publicHistory = false;

  const secondContext = await browser.newContext();
  await secondContext.route('https://**', route => route.abort());
  await secondContext.routeWebSocket('wss://**', socket => socket.close());
  const second = await secondContext.newPage();
  await second.goto('/');
  await expect.poll(async () => (await peer(second)).peers, { timeout: 45_000 }).toContain(original.id);
  expect(await readPeerHistory(second)).toEqual([]);
  expect(await readFile(second, nhash)).toBe('<h1>Retained peer site</h1>');
  const secondId = (await peer(second)).id;
  await second.reload();
  expect((await peer(second)).id).toBe(secondId);
  expect(await readPeerHistory(second, 'cache-only')).toEqual([]);
  await expectPeerPair(page, second, original.id!, secondId!);
  await expectFreshPeerSite(second, page);
  console.log('BROWSER_PEER_RELOAD', JSON.stringify({ app: 'iris-sites', endpoint: 'second',
    identityStable: true, bothPeersConnected: true, freshTransfer: true, source: 'peer-file-port' }));
  await page.reload();
  await expectPeerPair(page, second, original.id!, secondId!);
  await expectFreshPeerSite(page, second);
  console.log('BROWSER_PEER_RELOAD', JSON.stringify({ app: 'iris-sites', endpoint: 'first',
    identityStable: true, bothPeersConnected: true, freshTransfer: true, source: 'peer-file-port' }));
  await page.close();

  const thirdContext = await browser.newContext();
  await thirdContext.route('https://**', route => route.abort());
  await thirdContext.routeWebSocket('wss://**', socket => socket.close());
  const third = await thirdContext.newPage();
  await third.goto('/');
  await expect.poll(async () => (await peer(third)).peers, { timeout: 45_000 }).toContain(secondId);
  expect(await readPeerHistory(third)).toEqual([]);
  expect(await readFile(third, nhash)).toBe('<h1>Retained peer site</h1>');
  await secondContext.close();
  await thirdContext.close();
});
