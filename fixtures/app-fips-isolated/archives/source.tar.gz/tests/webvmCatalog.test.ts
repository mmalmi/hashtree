import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { getLauncherSuggestionSite, launcherSuggestions } from '../src/lib/launcherContent';

describe('WebVM launcher catalog entry', () => {
  it('opens the dedicated production app with concise shipped-feature metadata', () => {
    const matches = launcherSuggestions.filter((suggestion) => suggestion.name === 'WebVM');

    expect(matches).toHaveLength(1);
    expect(matches[0]).toEqual({
      name: 'WebVM',
      href: 'https://webvm.iris.to/',
      blurb: 'Browser-hosted Linux with FIPS, Nostr VPN pairing, and Hashtree tools',
      icon: './launcher-icons/webvm-icon.ico',
      external: true,
    });
    expect(matches[0].blurb.length).toBeLessThanOrEqual(80);
    expect(getLauncherSuggestionSite(matches[0])).toBeNull();
  });

  it('ships a dedicated WebVM icon rather than borrowing another app asset', async () => {
    const icon = await readFile(resolve(import.meta.dirname, '..', 'public', 'launcher-icons', 'webvm-icon.ico'));

    expect(Array.from(icon.subarray(0, 4))).toEqual([0, 0, 1, 0]);
    expect(icon.byteLength).toBeGreaterThan(1_000);
  });
});
