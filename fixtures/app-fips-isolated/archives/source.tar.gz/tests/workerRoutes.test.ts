import { describe, expect, it } from 'vitest';
import {
  canonicalAliasPath,
  default as worker,
  shouldServeIndexFallback,
} from '../scripts/https-static-assets-worker.mjs';

const npub = 'npub1qny3tkh0acurzla8x3zy4nhrjz5zd8l9sy9jys09umwng00manysew95gx';
const uuid = '11111111-1111-4111-8111-111111111111';

describe('static assets Worker routes', () => {
  it('redirects nested contact aliases to one-segment canonical paths', () => {
    expect(canonicalAliasPath(`/profile/${npub}`)).toBe(`/${npub}`);
    expect(canonicalAliasPath(`/contact/${uuid}`)).toBe(`/${uuid}`);
  });

  it('serves the SPA shell for deep profile routes but not assets', () => {
    expect(shouldServeIndexFallback(new Request(`https://contacts.iris.to/${npub}`), new URL(`https://contacts.iris.to/${npub}`)))
      .toBe(true);
    expect(shouldServeIndexFallback(new Request('https://contacts.iris.to/assets/app.js'), new URL('https://contacts.iris.to/assets/app.js')))
      .toBe(false);
    expect(shouldServeIndexFallback(new Request('https://contacts.iris.to/manifest.webmanifest'), new URL('https://contacts.iris.to/manifest.webmanifest')))
      .toBe(false);
  });

  it('falls back to index.html for one-segment deep links', async () => {
    const paths: string[] = [];
    const env = {
      ASSETS: {
        fetch: async (request: Request) => {
          paths.push(new URL(request.url).pathname);
          return new Response('index', { status: 200 });
        },
      },
    };

    const response = await worker.fetch(new Request(`https://contacts.iris.to/${npub}`), env);
    expect(response.status).toBe(200);
    expect(await response.text()).toBe('index');
    expect(paths).toEqual(['/']);
  });
});
