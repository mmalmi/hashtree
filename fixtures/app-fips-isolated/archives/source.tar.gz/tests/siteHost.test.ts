import { describe, expect, it } from 'vitest';
import { nhashDecode, nhashEncode, toHex } from '@hashtree/core';
import {
  buildHashtreeInstallOptionsHref,
  buildIrisDriveDownloadHref,
  buildIrisGitAppHref,
  buildIrisFilesAppHref,
  buildIsolatedSiteHref,
  buildLauncherHref,
  buildPermalinkHref,
  buildSitesHomeHref,
  buildSourceHref,
  buildSuggestedAppHref,
  isLocalDevShellHost,
  isIrisLocalhostHost,
  isPortalShellHost,
  shouldRedirectPortalShellHost,
  shouldShowRuntimeMenuForHost,
  shouldShowIrisDriveDownloadPrompt,
} from '../src/lib/siteHost';
import { encodeImmutableHostLabel, encodeMutableHostLabel } from '../src/lib/siteIdentity';

const VALID_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const VALID_SNAPSHOT_NHASH = nhashEncode(new Uint8Array(32).fill(7));

describe('site host routing', () => {
  it('treats the bare sites host as the launcher shell', () => {
    expect(isPortalShellHost('apps.iris.to')).toBe(true);
    expect(isPortalShellHost('sites.iris.to')).toBe(true);
    expect(isPortalShellHost('localhost:5178')).toBe(true);
    expect(isPortalShellHost('iris.localhost:17321')).toBe(true);
    expect(isPortalShellHost(`sites.${VALID_NPUB}.iris.localhost:17321`)).toBe(true);
    expect(isPortalShellHost('sites.hashtree.cc')).toBe(false);
    expect(isPortalShellHost('enshittifier.hashtree.cc')).toBe(false);
  });

  it('builds canonical launcher URLs from the legacy sites host', () => {
    expect(buildLauncherHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    }, 'sites.iris.to')).toBe(`https://apps.iris.to/#/${VALID_NPUB}/enshittifier/index.html`);
    expect(buildSitesHomeHref('sites.iris.to')).toBe('https://apps.iris.to/');
  });

  it('keeps localhost as an inline dev shell instead of a redirecting portal', () => {
    expect(isLocalDevShellHost('localhost:5178')).toBe(true);
    expect(isLocalDevShellHost('127.0.0.1:5178')).toBe(true);
    expect(isLocalDevShellHost('apps.iris.to')).toBe(false);
    expect(isLocalDevShellHost('iris.localhost:17321')).toBe(false);
    expect(shouldRedirectPortalShellHost('localhost:5178')).toBe(false);
    expect(shouldRedirectPortalShellHost('127.0.0.1:5178')).toBe(false);
    expect(shouldRedirectPortalShellHost('apps.iris.to')).toBe(true);
    expect(shouldRedirectPortalShellHost('iris.localhost:17321')).toBe(true);
  });

  it('shows runtime menu chrome only on public isolated runtime hosts', () => {
    expect(shouldShowRuntimeMenuForHost('enshittifier.hashtree.cc')).toBe(true);
    expect(shouldShowRuntimeMenuForHost('apps.iris.to')).toBe(false);
    expect(shouldShowRuntimeMenuForHost('localhost:5178')).toBe(false);
    expect(shouldShowRuntimeMenuForHost(`audio.${VALID_NPUB}.iris.localhost:17321`)).toBe(false);
    expect(shouldShowRuntimeMenuForHost(`${VALID_NPUB}.audio.iris.localhost:17321`)).toBe(false);
    expect(shouldShowRuntimeMenuForHost('63dvmlmvh6sxd65q7abane2j23fl4e7hmub4lwdjvl6vwmzlobda.sites.iris.localhost:5178')).toBe(false);
  });

  it('detects Iris Drive localhost hosts', () => {
    expect(isIrisLocalhostHost('iris.localhost')).toBe(true);
    expect(isIrisLocalhostHost('iris.localhost:17321')).toBe(true);
    expect(isIrisLocalhostHost('sites.iris.localhost:5178')).toBe(true);
    expect(isIrisLocalhostHost(`audio.${VALID_NPUB}.iris.localhost:17321`)).toBe(true);
    expect(isIrisLocalhostHost('localhost:5178')).toBe(false);
    expect(isIrisLocalhostHost('apps.iris.to')).toBe(false);
    expect(isIrisLocalhostHost('iris.localhost.example')).toBe(false);
  });

  it('derives mutable runtime hosts from an opaque hash label', () => {
    const label = encodeMutableHostLabel(VALID_NPUB, 'enshittifier');

    expect(label).toMatch(/^[a-z2-7]{52}$/);
    expect(label).not.toContain('npub1');
    expect(label).not.toContain('enshittifier');
  });

  it('derives immutable runtime hosts from the keyless nhash so the server never sees the decrypt key', async () => {
    const nhash = 'nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38';
    const href = await buildIsolatedSiteHref({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Isolated Site',
      nhash,
      entryPath: 'index.html',
    });

    const url = new URL(href);
    const decoded = nhashDecode(nhash);
    expect(url.hostname).toBe(`${encodeImmutableHostLabel(decoded.hash)}.hashtree.cc`);
    expect(url.pathname).toBe('/');
    expect(url.hash).toBe(`#/index.html?k=${toHex(decoded.key!)}`);
    expect(url.href).not.toContain(nhashEncode(decoded.hash));
    expect(url.href).not.toContain(nhash);
  });

  it('builds launcher URLs on apps.iris.to from runtime hosts', () => {
    expect(buildLauncherHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    })).toBe(`https://apps.iris.to/#/${VALID_NPUB}/enshittifier/index.html`);
  });

  it('builds source URLs through the primary Iris Drive app host', () => {
    expect(buildSourceHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    })).toBe('https://drive.iris.to/');
  });

  it('builds hashtree install options links through Iris Git', () => {
    expect(buildIrisGitAppHref('apps.iris.to')).toBe('https://git.iris.to/');
    expect(buildHashtreeInstallOptionsHref('apps.iris.to')).toBe(
      `https://git.iris.to/#/${VALID_NPUB}/hashtree`,
    );
    expect(buildHashtreeInstallOptionsHref('iris.localhost:17321')).toBe(
      `http://git.${VALID_NPUB}.iris.localhost:17321/index.html#/${VALID_NPUB}/hashtree`,
    );
    expect(buildHashtreeInstallOptionsHref('sites.iris.localhost:5178')).toBe(
      `http://git.${VALID_NPUB}.iris.localhost:17321/index.html#/${VALID_NPUB}/hashtree`,
    );
  });

  it('builds Iris Drive download links through the Iris Drive landing site', () => {
    expect(buildIrisDriveDownloadHref('apps.iris.to')).toBe('https://getdrive.iris.to/');
    expect(buildIrisDriveDownloadHref('iris.localhost:17321')).toBe(
      `http://irisdrive-org-site.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildIrisDriveDownloadHref('sites.iris.localhost:5178')).toBe(
      `http://irisdrive-org-site.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
  });

  it('hides the Iris Drive download prompt on Iris localhost origins', () => {
    expect(shouldShowIrisDriveDownloadPrompt('apps.iris.to')).toBe(true);
    expect(shouldShowIrisDriveDownloadPrompt('localhost:5178')).toBe(true);
    expect(shouldShowIrisDriveDownloadPrompt('iris.localhost:17321')).toBe(false);
    expect(shouldShowIrisDriveDownloadPrompt('sites.iris.localhost:5178')).toBe(false);
    expect(shouldShowIrisDriveDownloadPrompt(`audio.${VALID_NPUB}.iris.localhost:17321`)).toBe(false);
  });

  it('uses primary app hosts from the production launcher', () => {
    const calendar = {
      kind: 'mutable' as const,
      siteKey: 'calendar',
      title: 'Calendar',
      npub: VALID_NPUB,
      treeName: 'calendar',
      entryPath: 'index.html',
    };
    const meet = {
      kind: 'mutable' as const,
      siteKey: 'meet',
      title: 'Meet',
      npub: VALID_NPUB,
      treeName: 'meet',
      entryPath: 'index.html',
    };
    const wallet = {
      kind: 'mutable' as const,
      siteKey: 'cashu-me',
      title: 'Wallet',
      npub: VALID_NPUB,
      treeName: 'cashu-me',
      entryPath: 'index.html',
    };

    expect(buildSuggestedAppHref(calendar, 'apps.iris.to', 'calendar.iris.to')).toBe('https://calendar.iris.to/');
    expect(buildSuggestedAppHref(meet, 'apps.iris.to', 'meet.iris.to')).toBe('https://meet.iris.to/');
    expect(buildSuggestedAppHref(wallet, 'apps.iris.to', 'wallet.cashu.me')).toBe('https://wallet.cashu.me/');
  });

  it('uses readable npub-addressed app hosts from local launchers', () => {
    const calendar = {
      kind: 'mutable' as const,
      siteKey: 'calendar',
      title: 'Calendar',
      npub: VALID_NPUB,
      treeName: 'calendar',
      entryPath: 'index.html',
    };

    expect(buildSuggestedAppHref(calendar, 'iris.localhost:17321', 'calendar.iris.to')).toBe(
      `http://calendar.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildSuggestedAppHref(calendar, 'sites.iris.localhost:5178', 'calendar.iris.to')).toBe(
      `http://calendar.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildSuggestedAppHref({
      kind: 'mutable',
      siteKey: 'cashu-me',
      title: 'Wallet',
      npub: VALID_NPUB,
      treeName: 'cashu-me',
      entryPath: 'index.html',
    }, 'iris.localhost:17321', 'wallet.cashu.me')).toBe(
      `http://cashu-me.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
  });

  it('derives mutable permalinks from the currently resolved tree root nhash', () => {
    const currentVersion = nhashDecode('nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38');

    expect(buildPermalinkHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    }, {
      hash: currentVersion.hash,
      key: currentVersion.key,
      visibility: 'public',
      snapshotNhash: VALID_SNAPSHOT_NHASH,
    })).toBe(
      `https://apps.iris.to/#/${VALID_SNAPSHOT_NHASH}/index.html?snapshot=1`,
    );
  });

  it('falls back to a plain immutable root nhash when no signed snapshot permalink is available', () => {
    const currentVersion = nhashDecode('nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38');

    expect(buildPermalinkHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    }, {
      hash: currentVersion.hash,
      key: currentVersion.key,
    })).toBe(
      'https://apps.iris.to/#/nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38/index.html',
    );
  });

  it('does not invent mutable permalinks before the current tree root is known', () => {
    expect(buildPermalinkHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'Midi',
      npub: VALID_NPUB,
      treeName: 'enshittifier',
      entryPath: 'index.html',
    })).toBeNull();
  });

  it('builds local launcher URLs from local runtime hosts', () => {
    expect(buildLauncherHref({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Pinned',
      nhash: 'nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq',
      entryPath: 'index.html',
    }, '63dvmlmvh6sxd65q7abane2j23fl4e7hmub4lwdjvl6vwmzlobda.sites.iris.localhost:5178')).toBe(
      'http://sites.iris.localhost:5178/#/nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq/index.html',
    );
  });

  it('builds local launcher URLs from readable iris-drive app hosts', () => {
    expect(buildLauncherHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    }, `git.${VALID_NPUB}.iris.localhost:17321`)).toBe(
      `http://sites.${VALID_NPUB}.iris.localhost:17321/#/${VALID_NPUB}/git/index.html`,
    );
  });

  it('builds local source URLs against the local Iris Drive app route', () => {
    expect(buildSourceHref({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Pinned',
      nhash: 'nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq',
      entryPath: 'index.html',
    }, '63dvmlmvh6sxd65q7abane2j23fl4e7hmub4lwdjvl6vwmzlobda.sites.iris.localhost:5178')).toBe(
      `http://drive.${VALID_NPUB}.iris.localhost:5178/index.html`,
    );
  });

  it('opens the readable Iris Drive app host from iris.localhost', () => {
    expect(buildIrisFilesAppHref('localhost:5178')).toBe(
      `http://localhost:5178/#/${VALID_NPUB}/drive/index.html`,
    );
    expect(buildIrisFilesAppHref('sites.iris.localhost:5178')).toBe(
      `http://drive.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildIrisFilesAppHref('iris.localhost:17321')).toBe(
      `http://drive.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildIrisFilesAppHref(`audio.${VALID_NPUB}.iris.localhost:17321`)).toBe(
      `http://drive.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
    expect(buildIrisFilesAppHref(`audio.${VALID_NPUB}.iris.localhost:5178`)).toBe(
      `http://drive.${VALID_NPUB}.iris.localhost:17321/index.html`,
    );
  });

  it('builds iris-drive local mutable app URLs from the mutable portal host', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    }, `sites.${VALID_NPUB}.iris.localhost:17321`);

    expect(href).toBe(`http://audio.${VALID_NPUB}.iris.localhost:17321/index.html`);
  });

  it('does not fall back to the sites runtime shell from Iris Drive local hosts', async () => {
    await expect(buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris',
      npub: VALID_NPUB,
      treeName: 'apps/iris',
      entryPath: 'index.html',
    }, `sites.${VALID_NPUB}.iris.localhost:17321`)).rejects.toThrow(
      'cannot be opened through the Iris Sites runtime shell',
    );
  });

  it('keeps bare vite localhost app URLs on the localhost dev shell', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    }, 'localhost:5178');

    expect(href).toBe(`http://localhost:5178/#/${VALID_NPUB}/audio/index.html`);
  });

  it('keeps bare vite localhost immutable URLs on the localhost dev shell', async () => {
    const nhash = 'nhash1qqsxyn0g6yyac8ruej7r7j80y2gx6ev5z5flu6ry5h5t3ajju5utzjs9yz7t3p2syr9n5heajlv85uwej232dk5x4zqe8d7ft67y3m5umxr55qjku38';
    const href = await buildIsolatedSiteHref({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Pinned',
      nhash,
      entryPath: 'index.html',
    }, 'localhost:5178');

    expect(href).toBe(`http://localhost:5178/#/${nhash}/index.html`);
  });

  it('builds a launcher home href for direct file viewers', () => {
    expect(buildSitesHomeHref('localhost:5178')).toBe('http://localhost:5178/');
    expect(buildSitesHomeHref('apps.iris.to')).toBe('https://apps.iris.to/');
  });

  it('opens readable local app URLs through the Iris Drive gateway from the local sites shell', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'git',
      npub: VALID_NPUB,
      treeName: 'git',
      entryPath: 'index.html',
    }, 'sites.iris.localhost:5178');

    expect(href).toBe(`http://git.${VALID_NPUB}.iris.localhost:17321/index.html`);
  });

  it('opens readable local app URLs through Iris Drive from the iris.localhost dev launcher', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'audio',
      npub: VALID_NPUB,
      treeName: 'audio',
      entryPath: 'index.html',
    }, 'iris.localhost:5178');

    expect(href).toBe(`http://audio.${VALID_NPUB}.iris.localhost:17321/index.html`);
  });

  it('opens readable local immutable app URLs through Iris Drive from the iris.localhost dev launcher', async () => {
    const nhash = 'nhash1qqsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq';
    const nhashHost = nhash.match(/.{1,63}/g)?.join('.') ?? nhash;
    const href = await buildIsolatedSiteHref({
      kind: 'immutable',
      siteKey: 'pilot',
      title: 'Pinned',
      nhash,
      entryPath: 'index.html',
    }, 'iris.localhost:5178');

    expect(href).toBe(`http://${nhashHost}.iris.localhost:17321/index.html`);
  });

  it('derives mutable runtime hosts into a single owner-tree label', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'apps/iris',
      npub: VALID_NPUB,
      treeName: 'apps/iris',
      entryPath: 'index.html',
    });

    expect(href).toBe(`https://${encodeMutableHostLabel(VALID_NPUB, 'apps/iris')}.hashtree.cc/#/${VALID_NPUB}/apps%2Firis/index.html`);
  });

  it('keeps custom mutable app launches on hashtree.cc from the production portal', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'my app',
      npub: VALID_NPUB,
      treeName: 'my-app',
      entryPath: 'index.html',
    }, 'apps.iris.to');

    expect(href).toBe(`https://${encodeMutableHostLabel(VALID_NPUB, 'my-app')}.hashtree.cc/#/${VALID_NPUB}/my-app/index.html`);
  });

  it('keeps non-DNS-safe mutable tree names in the fragment while the host stays single-label', async () => {
    const href = await buildIsolatedSiteHref({
      kind: 'mutable',
      siteKey: 'pilot',
      title: 'unsafe',
      npub: VALID_NPUB,
      treeName: 'apps/iris ui',
      entryPath: 'index.html',
    });

    expect(href).toBe(`https://${encodeMutableHostLabel(VALID_NPUB, 'apps/iris ui')}.hashtree.cc/#/${VALID_NPUB}/apps%2Firis%20ui/index.html`);
  });
});
