import { describe, expect, it } from 'vitest';
import {
  FACT_SNAPSHOT_KIND,
  buildFactSnapshotDraft,
  fact,
} from 'nostr-social-graph';
import {
  CONTACT_ATTR_PREDICATE,
  contactIdentityFromFactSnapshotDraft,
  contactIdentityToFactSnapshotDraft,
} from '../src/lib/contactFactSnapshots';
import { pubkeyToNpub, type ContactIdentity } from '../src/lib/contacts';

const subject = '6b7f5df4-1d2d-43a7-9b87-873e41a2d99a';
const pubkey = '4f355bdcb7c27f8f3e4f6c4ec8f996d45b33f2d9c93a9d5c7aa9a6e1a4e7f8aa';

describe('contact fact snapshots', () => {
  it('round-trips local contact identity attributes through unsigned snapshot drafts', () => {
    const identity: ContactIdentity = {
      id: subject,
      createdAt: 1000,
      updatedAt: 2000,
      attrs: [
        {
          type: 'name',
          value: 'Alice',
          source: 'private',
          active: true,
          addedAt: 1001,
          label: 'preferred',
        },
        {
          type: 'nostr_pubkey',
          value: pubkey,
          source: 'private',
          active: true,
          addedAt: 1002,
        },
        {
          type: 'handle',
          value: 'old@example.test',
          source: 'private',
          active: false,
          addedAt: 1003,
        },
      ],
    };

    const draft = contactIdentityToFactSnapshotDraft(identity);

    expect(draft.kind).toBe(FACT_SNAPSHOT_KIND);
    expect(draft.content).toBe('');
    expect(draft.tags).toContainEqual(['d', subject]);
    expect(draft.tags).toContainEqual(['i', subject, 'subject']);
    expect(draft.tags).toContainEqual([
      CONTACT_ATTR_PREDICATE,
      'name',
      'Alice',
      'private',
      'active',
      '1001',
      'preferred',
    ]);
    expect(draft.tags).toContainEqual(['name', 'Alice']);
    expect(draft.tags).toContainEqual(['controls', pubkey]);
    expect(draft.tags).not.toContainEqual(['handle', 'old@example.test']);

    const restored = contactIdentityFromFactSnapshotDraft(draft, { fallbackAddedAt: 999 });
    expect(restored).toEqual(expect.objectContaining({
      id: subject,
      createdAt: 1000,
      updatedAt: 2000,
    }));
    expect(restored.attrs).toHaveLength(3);
    expect(restored.attrs).toEqual(expect.arrayContaining([
      expect.objectContaining({
        type: 'name',
        value: 'Alice',
        source: 'private',
        active: true,
        addedAt: 1001,
        label: 'preferred',
      }),
      expect.objectContaining({
        type: 'nostr_pubkey',
        value: pubkey,
        source: 'private',
        active: true,
        addedAt: 1002,
      }),
      expect.objectContaining({
        type: 'handle',
        value: 'old@example.test',
        source: 'private',
        active: false,
        addedAt: 1003,
      }),
    ]));
  });

  it('imports generic profile facts as public contact attributes', () => {
    const draft = buildFactSnapshotDraft(
      subject,
      [
        fact('name', ['Alice']),
        fact('controls', [pubkey]),
        fact('picture', ['https://example.test/alice.jpg']),
      ],
      [],
      { externalIdentifiers: [pubkeyToNpub(pubkey)] },
    );

    const restored = contactIdentityFromFactSnapshotDraft(draft, {
      fallbackSource: 'public',
      fallbackAddedAt: 123,
    });

    expect(restored).toEqual(expect.objectContaining({
      id: subject,
      createdAt: 123,
      updatedAt: 123,
    }));
    expect(restored.attrs).toEqual(expect.arrayContaining([
      expect.objectContaining({ type: 'name', value: 'Alice', source: 'public', active: true }),
      expect.objectContaining({ type: 'nostr_pubkey', value: pubkey, source: 'public', active: true }),
      expect.objectContaining({
        type: 'picture',
        value: 'https://example.test/alice.jpg',
        source: 'public',
        active: true,
      }),
    ]));
  });
});
