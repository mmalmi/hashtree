import { describe, expect, it } from 'vitest';
import {
  contactIdentityIdForPubkey,
  createPrivateContact,
  profileToContact,
  pubkeyToNpub,
} from '../src/lib/contacts';
import { contactPathFor, parseContactRoute } from '../src/lib/contactRoutes';

const alice = 'a'.repeat(64);
const aliceNpub = pubkeyToNpub(alice);
const aliceIdentityId = contactIdentityIdForPubkey(alice)!;
const localId = '11111111-1111-4111-8111-111111111111';

describe('contact routes', () => {
  it('uses /new for the create contact page', () => {
    expect(parseContactRoute('/new')).toEqual({
      kind: 'create',
      canonicalPath: '/new',
    });
  });

  it('uses one-segment npub routes for public profiles', () => {
    expect(parseContactRoute(`/${aliceNpub}`)).toEqual({
      kind: 'profile',
      pubkey: alice,
      npub: aliceNpub,
      canonicalPath: `/${aliceNpub}`,
      isAlias: false,
    });
  });

  it('canonicalizes profile aliases and hex pubkeys to npubs', () => {
    expect(parseContactRoute(`/profile/${alice}`)).toEqual({
      kind: 'profile',
      pubkey: alice,
      npub: aliceNpub,
      canonicalPath: `/${aliceNpub}`,
      isAlias: true,
    });
    expect(parseContactRoute(`/contact/${aliceNpub}`)).toEqual({
      kind: 'profile',
      pubkey: alice,
      npub: aliceNpub,
      canonicalPath: `/${aliceNpub}`,
      isAlias: true,
    });
  });

  it('uses one-segment UUID routes for local contacts without public keys', () => {
    expect(parseContactRoute(`/${localId}`)).toEqual({
      kind: 'contact',
      id: localId,
      canonicalPath: `/${localId}`,
      isAlias: false,
    });
    expect(parseContactRoute(`/contact/${localId}`)).toEqual({
      kind: 'contact',
      id: localId,
      canonicalPath: `/${localId}`,
      isAlias: true,
    });
  });

  it('builds canonical UUID contact paths from contact records', () => {
    const publicContact = profileToContact(alice, undefined, null);
    const privateWithoutPubkey = createPrivateContact({ name: 'Local Friend' });
    const privateWithPubkey = createPrivateContact({ name: 'Alice', pubkey: alice });

    expect(contactPathFor(publicContact)).toBe(`/${aliceIdentityId}`);
    expect(contactPathFor(privateWithoutPubkey)).toBe(`/${privateWithoutPubkey.id}`);
    expect(contactPathFor(privateWithPubkey)).toBe(`/${privateWithPubkey.id}`);
  });
});
