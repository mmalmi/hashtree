import { expect, test } from '@playwright/test';
import { SocialGraph } from 'nostr-social-graph';

const root = '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';
const friend = '2'.repeat(64);

test('keeps a retained public graph and both revision IDs across offline reloads', async ({ page, context }) => {
  let bootstrapRequests = 0;
  await page.route('https://graph-api.iris.to/**', route => { bootstrapRequests++; return route.abort(); });
  await page.routeWebSocket(/wss:\/\//, socket => socket.close());
  await page.goto('/');
  await expect(page.locator('[data-contact-index="0"]')).toBeVisible();
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  const graph = new SocialGraph(root);
  graph.handleEvent({ kind: 3, pubkey: root, created_at: 20, id: 'a'.repeat(64), tags: [['p', friend]], content: '', sig: '' });
  graph.handleEvent({ kind: 10000, pubkey: root, created_at: 21, id: 'b'.repeat(64), tags: [], content: '', sig: '' });
  const bytes = [...await graph.toBinary()];
  await page.evaluate(async ({ root, bytes }) => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('iris-public-social-graph', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('graphs');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('graphs', 'readwrite');
      tx.objectStore('graphs').put(new Uint8Array(bytes), root);
      tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
    });
    db.close();
  }, { root, bytes });
  const beforeReload = bootstrapRequests;
  await page.reload();
  await expect(page.locator('[data-contact-index]')).toHaveCount(1);
  await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  expect(bootstrapRequests).toBe(beforeReload);
  await context.setOffline(true);
  await page.reload();
  await expect(page.locator('[data-contact-index]')).toHaveCount(1);
  const retained = await page.evaluate(async root => {
    const db = await new Promise<IDBDatabase>(resolve => {
      const request = indexedDB.open('iris-public-social-graph', 1); request.onsuccess = () => resolve(request.result);
    });
    const bytes = await new Promise<Uint8Array>(resolve => {
      const request = db.transaction('graphs').objectStore('graphs').get(root); request.onsuccess = () => resolve(request.result);
    });
    db.close(); return [...bytes];
  }, root);
  const decoded = await SocialGraph.fromBinary(root, new Uint8Array(retained));
  expect(decoded.getListRevision(root, 3)?.id).toBe('a'.repeat(64));
  expect(decoded.getListRevision(root, 10000)?.id).toBe('b'.repeat(64));
});

test('uses a fresh projected server graph on first load and retains both IDs', async ({ page }) => {
  const graph = new SocialGraph(root);
  graph.handleEvent({ kind: 3, pubkey: root, created_at: 20, id: 'c'.repeat(64), tags: [['p', friend]], content: '', sig: '' });
  graph.handleEvent({ kind: 10000, pubkey: root, created_at: 21, id: 'd'.repeat(64), tags: [], content: '', sig: '' });
  graph.markListIncomplete(root, 3); graph.markListIncomplete(root, 10000);
  const body = Buffer.from(await graph.toBinary());
  let bootstrapRequests = 0;
  await page.route('https://graph-api.iris.to/**', route => {
    bootstrapRequests++;
    return route.fulfill({ body, contentType: 'application/octet-stream', headers: {
      'x-graph-root': root, 'access-control-allow-origin': '*', 'access-control-expose-headers': 'x-graph-root',
    } });
  });
  await page.routeWebSocket(/wss:\/\//, socket => socket.close());
  await page.goto('/');
  await expect.poll(() => bootstrapRequests).toBe(1);
  await expect(page.locator('[data-contact-index]')).toHaveCount(1);
  await page.reload();
  await expect(page.locator('[data-contact-index]')).toHaveCount(1);
  expect(bootstrapRequests).toBe(1);
  const bytes = await page.evaluate(async root => {
    const db = await new Promise<IDBDatabase>(resolve => {
      const request = indexedDB.open('iris-public-social-graph', 1); request.onsuccess = () => resolve(request.result);
    });
    try { return await new Promise<number[]>(resolve => {
      const request = db.transaction('graphs').objectStore('graphs').get(root); request.onsuccess = () => resolve([...request.result]);
    }); } finally { db.close(); }
  }, root);
  const retained = await SocialGraph.fromBinary(root, new Uint8Array(bytes));
  expect(retained.getListRevision(root, 3)?.id).toBe('c'.repeat(64));
  expect(retained.getListRevision(root, 10000)?.id).toBe('d'.repeat(64));
});
