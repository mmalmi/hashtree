import { expect, test } from '@playwright/test';

const relationshipsStorageKey = 'iris-contacts:relationships:v1';
const privateContactsStorageKey = 'iris-contacts:private:v1';
const accountsStorageKey = 'iris-contacts:accounts:v1';
const activeAccountStorageKey = 'iris-contacts:active-account:v1';
const identitySessionStorageKey = 'iris-contacts:identity-session:v1';
const nostrIdentitySessionStorageKey = 'iris-contacts:nostr-identity-session:v1';
const defaultRootNpub = 'npub1g53mukxnjkcmr94fhryzkqutdz2ukq4ks0gvy5af25rgmwsl4ngq43drvk';
const routedPrivateUuid = '11111111-1111-4111-8111-111111111111';
const labeledPrivateUuid = '22222222-2222-4222-8222-222222222222';
const aboutPrivateUuid = '33333333-3333-4333-8333-333333333333';
const sampleNpub = 'npub1qny3tkh0acurzla8x3zy4nhrjz5zd8l9sy9jys09umwng00manysew95gx';
const localPictureDataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=';

test.beforeEach(async ({ page }) => {
  // These UI assertions use packaged profiles; public-graph.spec.ts covers live bootstrap.
  await page.route('https://graph-api.iris.to/**', route => route.abort());
  // Keep the real proxy URL while supplying deterministic offline image bytes.
  await page.route('https://imgproxy.iris.to/**', route => route.fulfill({
    contentType: 'image/png', body: Buffer.from(localPictureDataUrl.split(',')[1], 'base64'),
  }));
  await page.routeWebSocket(/wss:\/\//, socket => socket.close());
  await page.addInitScript((keys) => {
    for (const key of keys) window.localStorage.removeItem(key);
  }, [relationshipsStorageKey, accountsStorageKey, activeAccountStorageKey, identitySessionStorageKey, nostrIdentitySessionStorageKey]);
  await page.goto('/');
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expect(page.locator('[data-contact-index="0"]')).toBeVisible();
});

test('opens identity settings without treating the default graph root as login', async ({ page }) => {
  await page.getByRole('button', { name: 'Go to contacts home' }).hover();
  await expect.poll(async () => page.locator('.brand-home-button').evaluate((button) => (
    getComputedStyle(button).backgroundColor
  ))).toBe('rgba(0, 0, 0, 0)');

  const profileButton = page.locator('.account-actions').getByRole('button', { name: 'Sign in' });
  await expect(profileButton).toBeVisible();
  await expect(profileButton.locator('.sign-in-icon')).toBeVisible();
  await expect(profileButton.locator('.avatar')).toHaveCount(0);
  await profileButton.click();
  await expect(page).toHaveURL('/settings');
  await expect(page.getByRole('heading', { name: 'Settings' })).toBeVisible();
  await expect(page.getByText('Account, private data, and local preferences')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Account' })).toHaveClass(/active/);
  await expect(page.getByRole('button', { name: 'Private', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Public graph' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Muted' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Create identity' })).toBeVisible();
  await expect(page.getByTestId('identity-recovery-create-new-view')).toBeVisible();
  await expect(page.getByTestId('identity-create-name')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Create identity' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Create local identity' })).toHaveCount(0);
  await expect(page.getByRole('heading', { name: 'Switch account' })).toHaveCount(0);
  const sourceLink = page.getByRole('link', { name: 'iris-contacts' });
  await expect(page.getByRole('heading', { name: 'Source code' })).toBeVisible();
  await expect(sourceLink).toBeVisible();
  await expect(sourceLink).toHaveAttribute('href', 'https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-contacts');
  await expect(sourceLink).toHaveAttribute('target', '_blank');
  await expect(page.getByLabel('Public key')).toHaveCount(0);
  await expect(page.getByPlaceholder('Nostr public key')).toHaveCount(0);
  await expect(page.getByRole('heading', { name: 'Appearance' })).toHaveCount(0);
  await expect(page.getByText('Follows your system light or dark theme.')).toHaveCount(0);
  await expect(page.getByText('The selected account controls')).toHaveCount(0);
  await expect(page.getByRole('combobox')).toHaveCount(0);

  await page.getByRole('button', { name: 'Public graph' }).click();
  await expect(page.getByRole('heading', { name: 'Public graph' })).toBeVisible();
  await expect(page.getByRole('button', { name: /Iris public graph/ })).toBeVisible();
  // The owner may have a packaged display name; the account distinction is invariant.
  await expect(page.getByText('This is a public discovery and ranking lens, not a signed-in account.', { exact: true })).toBeVisible();

  await page.getByRole('button', { name: 'Account' }).click();

  const settingsLayout = await page.evaluate(() => {
    const panels = Array.from(document.querySelectorAll<HTMLElement>('.settings-content > .profile-card, .settings-content > .settings-card')).map((panel) => {
      const rect = panel.getBoundingClientRect();
      return {
        x: Math.round(rect.x),
        width: Math.round(rect.width),
      };
    });
    return {
      panelCount: panels.length,
      usesAvailableWidth: panels.every((panel) => panel.width > 320),
      hasSingleColumnStack: new Set(panels.map((panel) => panel.x)).size === 1,
    };
  });
  expect(settingsLayout).toEqual({
    panelCount: 2,
    usesAvailableWidth: true,
    hasSingleColumnStack: true,
  });

  const headerMetrics = await page.evaluate(() => {
    const icon = document.querySelector<SVGElement>('.search-icon svg')?.getBoundingClientRect();
    const input = document.querySelector<HTMLInputElement>('.global-search input');
    const settings = document.querySelector<SVGElement>('.icon-button svg')?.getBoundingClientRect();
    return {
      searchIconWidth: Math.round(icon?.width ?? 0),
      searchInputFontSize: Number.parseFloat(input ? getComputedStyle(input).fontSize : '0'),
      settingsIconWidth: Math.round(settings?.width ?? 0),
    };
  });
  expect(headerMetrics.searchIconWidth).toBeGreaterThanOrEqual(26);
  expect(headerMetrics.searchInputFontSize).toBeGreaterThanOrEqual(16);
  expect(headerMetrics.settingsIconWidth).toBeGreaterThanOrEqual(23);

  await page.getByTestId('identity-create-name').fill('Ada Contacts');
  await page.getByTestId('contacts-create-identity').click();
  await expect(page.getByLabel('Signed in identity')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Ada Contacts' })).toBeVisible();
  await expect(page.locator('.account-actions').getByRole('button', { name: 'Your identity' })).toBeVisible();
  await expect.poll(async () => page.evaluate((key) => Boolean(window.localStorage.getItem(key)), identitySessionStorageKey)).toBe(true);
  await expect.poll(async () => page.evaluate((key) => {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw).label : null;
  }, identitySessionStorageKey)).toBe('Ada Contacts');
});

test('switches public contact graph roots from settings', async ({ page }) => {
  await page.locator('.account-actions').getByRole('button', { name: 'Settings' }).click();
  await page.getByRole('button', { name: 'Public graph' }).click();
  await expect(page.getByRole('heading', { name: 'Public graph' })).toBeVisible();

  await page.getByLabel('Public key').fill('not-an-npub');
  await page.getByRole('button', { name: 'Add' }).click();
  await expect(page.getByText('Enter a valid Nostr public key.')).toBeVisible();

  await page.getByLabel('Public key').fill(sampleNpub);
  await page.getByRole('button', { name: 'Add' }).click();
  await expect(page).toHaveURL('/');
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expect(page.locator('[data-contact-index="0"]')).toBeVisible();

  await page.locator('.account-actions').getByRole('button', { name: 'Settings' }).click();
  await page.getByRole('button', { name: 'Public graph' }).click();
  const accountRows = page.locator('.account-row');
  await expect(accountRows.getByText('Current')).toBeVisible();
  await expect(accountRows.getByText('Default')).toBeVisible();
  await expect(page.getByText(sampleNpub)).toHaveCount(0);

  await accountRows.filter({ hasText: 'Default' }).locator('.account-select-button').click();
  await expect(page).toHaveURL('/');
  await expect(page.locator('[data-contact-index="0"]')).toBeVisible();
});

test('supports keyboard navigation from the contact list into detail pages', async ({ page }) => {
  await page.locator('[data-contact-index="0"]').focus();
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('[data-contact-index="1"]')).toBeFocused();

  await page.keyboard.press('Enter');
  await expect(page.getByRole('button', { name: 'Back to contacts' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Unfollow' })).toBeVisible();
  await expect(page.getByText('Following locally')).toBeVisible();
  const details = page.getByLabel('Contact details');
  await expect(details.getByText('Groups', { exact: true })).toHaveCount(0);
  await expect(details.getByText('None', { exact: true })).toHaveCount(0);
});

test('shows followed and followers lists on profile pages', async ({ page }) => {
  const sidebar = page.locator('.nav-rail');
  await expect(sidebar.getByRole('button', { name: /Followed/ })).toHaveCount(0);
  await expect(sidebar.getByRole('button', { name: /Known followers/ })).toHaveCount(0);

  await page.goto(`/${defaultRootNpub}`);
  const socialGraph = page.getByLabel('Social graph');
  await expect(socialGraph).toBeVisible();

  const followedStat = socialGraph.getByRole('button', { name: /follows/i });
  const followersStat = socialGraph.getByRole('button', { name: /known followers/i });
  const followedCount = await profileGraphStatCount(followedStat);
  const followersCount = await profileGraphStatCount(followersStat);

  expect(followedCount).toBeGreaterThan(0);
  expect(followersCount).toBeGreaterThan(0);
  await expect(socialGraph.locator('.contact-row')).toHaveCount(0);

  await followedStat.click();
  await expect(page.getByRole('heading', { name: 'Follows' })).toBeVisible();
  await expect(page.getByText(contactCountText(followedCount))).toBeVisible();
  await expect(page.locator('.profile-graph-page .contact-table')).toBeVisible();
  await expect(page.locator('.profile-graph-page .contact-row').first()).toBeVisible();
  await expect(page.locator('.profile-graph-list')).toHaveCount(0);
  await page.waitForTimeout(250);
  await expect(page.locator('.profile-graph-page')).toBeVisible();
  await page.getByRole('button', { name: 'Back to profile' }).click();
  await expect(page.getByRole('heading', { name: 'Follows' })).toHaveCount(0);

  await page.getByLabel('Social graph').getByRole('button', { name: /known followers/i }).click();
  await expect(page.getByRole('heading', { name: 'Known followers' })).toBeVisible();
  await expect(page.getByText(contactCountText(followersCount))).toBeVisible();
  await expect(page.locator('.profile-graph-page .contact-row').first()).toBeVisible();
  await page.waitForTimeout(250);
  await expect(page.locator('.profile-graph-page')).toBeVisible();

  await page.setViewportSize({ width: 390, height: 844 });
  await expectPageToFitViewport(page);
  await expect(page.locator('.profile-graph-page .contact-row').first()).toBeVisible();
  await page.locator('.profile-graph-page .contact-row').first().click();
  await expect(page.getByText('Follows you')).toHaveCount(0);
});

test('uses a dropdown for search and lazy-renders the main list', async ({ page }) => {
  await page.evaluate(({ key, uuid }) => {
    window.localStorage.setItem(key, JSON.stringify({
      version: 1,
      exportedAt: '2026-06-17T00:00:00.000Z',
      contacts: [{
        id: uuid,
        name: 'Ada Lovelace',
        handle: 'ada@example.test',
        email: 'ada@example.test',
        phone: '',
        company: '',
        jobTitle: '',
        address: '',
        birthday: '',
        source: 'private',
        groups: ['friends', 'math'],
        notes: '',
        updatedAt: 1770000000000,
        pubkey: null,
        npub: null,
        picture: '',
        followDistance: null,
        followedByFriends: 0,
      }],
    }));
  }, { key: privateContactsStorageKey, uuid: labeledPrivateUuid });
  await page.reload();
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expect(page.locator('[data-contact-index="0"]')).toBeVisible();

  await expect(page.getByText(/shown/)).toHaveCount(0);
  const contactsButton = page.locator('.nav-rail').getByRole('button', { name: /Contacts/ });
  await expect.poll(async () => navCount(contactsButton, 'Contacts')).toBeGreaterThan(20);
  const contactsCount = await navCount(contactsButton, 'Contacts');
  await expect(page.locator('.contacts-header').getByText(contactCountText(contactsCount), { exact: true })).toBeVisible();
  const initialRows = await page.locator('[data-contact-index]').count();
  expect(initialRows).toBeGreaterThan(20);
  expect(initialRows).toBeLessThanOrEqual(80);
  const table = page.getByRole('table', { name: 'Contacts table' });
  await expect(table.getByRole('columnheader')).toHaveCount(0);
  await expect(table.getByText('Name', { exact: true })).toHaveCount(0);
  await expect(table.getByText('Handle', { exact: true })).toHaveCount(0);
  await expect(table.getByText('Labels', { exact: true })).toHaveCount(0);
  await expect(table.getByText('Source', { exact: true })).toHaveCount(0);
  await expect(table.getByText('Public contact', { exact: true })).toHaveCount(0);
  await expect(table.getByText('Direct follow', { exact: true })).toHaveCount(0);
  await expect(table.getByText('None', { exact: true })).toHaveCount(0);
  const adaRow = page.locator('[data-contact-index]').filter({ hasText: 'Ada Lovelace' });
  await expect(adaRow.locator('.row-label')).toHaveText(['friends', 'math']);
  const rowLayout = await adaRow.evaluate((row) => {
    const name = row.querySelector('.name-cell')?.getBoundingClientRect();
    const labels = row.querySelector('.row-labels')?.getBoundingClientRect();
    const favorite = row.querySelector('.row-favorite-button')?.getBoundingClientRect();
    return {
      labelsAfterName: Boolean(name && labels && labels.left > name.left),
      labelsBeforeFavorite: Boolean(labels && favorite && labels.right <= favorite.left),
    };
  });
  expect(rowLayout.labelsAfterName).toBe(true);
  expect(rowLayout.labelsBeforeFavorite).toBe(true);
  const deterministicRow = page.locator('[data-contact-index]').filter({ hasText: 'DETERMINISTIC OPTIMISM' });
  await expect(deterministicRow.locator('.iris-user-row-description')).toHaveText('nvk');
  const odellRow = page.locator('[data-contact-index]').filter({ hasText: 'ODELL' });
  await expect(odellRow.locator('.iris-avatar-image')).toHaveAttribute(
    'src',
    /^https:\/\/imgproxy\.iris\.to\/.+\/rs:fill:40:40\/dpr:2\//,
  );
  await expect(odellRow.locator('[data-testid="social-distance-badge"]').first()).toBeVisible();

  await page.getByPlaceholder('Search').fill('ODELL');
  await expect(searchResult(page, 'ODELL')).toHaveCount(1);
  await expect(page.locator('.source-pill')).toHaveCount(0);
  await expect(page.locator('[data-contact-index]')).toHaveCount(initialRows);

  await page.getByPlaceholder('Search').press('Escape');
  await page.locator('.load-more-sentinel').scrollIntoViewIfNeeded();
  await expect.poll(async () => page.locator('[data-contact-index]').count()).toBeGreaterThan(initialRows);
});

test('favorites contacts locally from rows and detail pages', async ({ page }) => {
  const sidebar = page.locator('.nav-rail');
  await expect(sidebar.getByText('Labels')).toHaveCount(0);
  await expect(sidebar.getByText('Manage')).toHaveCount(0);
  await expect(sidebar.getByText(/private saved locally/)).toHaveCount(0);
  await expect(sidebar.getByText(/public loaded/)).toHaveCount(0);

  const favoritesButton = sidebar.getByRole('button', { name: /Favorites/ });
  await expect.poll(async () => navCount(favoritesButton, 'Favorites')).toBe(0);

  const odellRow = page.locator('[data-contact-index]').filter({ hasText: 'ODELL' });
  await expect(odellRow).toHaveCount(1);
  const favoriteIcon = odellRow.getByRole('button', { name: 'Add ODELL to favorites' }).locator('svg');
  await expect.poll(async () => odellRow.getByRole('button', { name: 'Add ODELL to favorites' }).evaluate((button) => (
    getComputedStyle(button).opacity
  ))).toBe('0');
  await expect.poll(async () => favoriteIcon.evaluate((icon) => getComputedStyle(icon).fill)).toBe('none');
  await odellRow.hover();
  await expect.poll(async () => odellRow.getByRole('button', { name: 'Add ODELL to favorites' }).evaluate((button) => (
    getComputedStyle(button).opacity
  ))).toBe('1');
  await odellRow.getByRole('button', { name: 'Add ODELL to favorites' }).click();
  await expect(page.getByText('Added ODELL to favorites locally.')).toBeVisible();
  await expect(page).toHaveURL(/\/$/);
  await expect.poll(async () => navCount(favoritesButton, 'Favorites')).toBe(1);

  await favoritesButton.click();
  await expect(page.getByRole('heading', { name: 'Favorites' })).toBeVisible();
  await expect(page.getByText('1 contact')).toBeVisible();
  await expect(page.locator('[data-contact-index]').filter({ hasText: 'ODELL' })).toHaveCount(1);

  await page.locator('[data-contact-index]').filter({ hasText: 'ODELL' }).focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { name: 'ODELL' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Remove from favorites' })).toBeVisible();
  const activeFavoriteIcon = page.getByRole('button', { name: 'Remove from favorites' }).locator('svg');
  await expect.poll(async () => activeFavoriteIcon.evaluate((icon) => getComputedStyle(icon).fill)).not.toBe('none');
  await page.getByRole('button', { name: 'Remove from favorites' }).click();
  await expect(page.getByText('Removed ODELL from favorites.')).toBeVisible();

  await page.getByRole('button', { name: 'Back to contacts' }).click();
  await expect(page.getByRole('heading', { name: 'Favorites' })).toBeVisible();
  await expect(page.getByText('No favorites yet.')).toBeVisible();
  await expect.poll(async () => navCount(favoritesButton, 'Favorites')).toBe(0);
});

test('creates private contacts from the main create page', async ({ page }) => {
  await page.getByRole('button', { name: 'Create contact' }).click();
  await expect(page).toHaveURL(/\/new$/);
  await expect(page.getByRole('heading', { name: 'Create contact' })).toBeVisible();
  await expect(page.getByPlaceholder('Paste exported private contacts JSON')).toHaveCount(0);
  const editor = page.getByRole('form', { name: 'Create contact' });
  await expect(editor.locator('input[placeholder], textarea[placeholder]')).toHaveCount(0);
  await expect(editor.getByLabel('Email')).toHaveAttribute('type', 'email');
  await expect(editor.getByLabel('Phone')).toHaveAttribute('type', 'tel');
  await expect(editor.getByLabel('Birthday')).toHaveAttribute('type', 'date');
  const identifierInput = editor.getByLabel('Nostr public key');
  await expect(identifierInput).toHaveAttribute('spellcheck', 'false');
  await expect(page.locator('[data-editor-icon]')).toHaveCount(9);
  await identifierInput.fill('not a key');
  await expect(page.getByText('Enter a valid Nostr public key.')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Save' })).toBeDisabled();
  await identifierInput.fill('alice@example.test');
  await expect(page.getByText('Enter a valid Nostr public key.')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Save' })).toBeDisabled();
  await identifierInput.fill(sampleNpub);
  await expect(page.getByText('Enter a valid Nostr public key.')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Save' })).toBeEnabled();
  await identifierInput.fill('');

  const fieldLayout = await page.evaluate(() => {
    const fieldRect = (labelText: string) => {
      const label = Array.from(document.querySelectorAll<HTMLLabelElement>('.editor-card label')).find((candidate) => (
        candidate.querySelector('span')?.textContent?.trim() === labelText
      ));
      return label?.querySelector('input, textarea')?.getBoundingClientRect();
    };
    const first = fieldRect('First name');
    const last = fieldRect('Last name');
    const company = fieldRect('Company');
    const editor = document.querySelector<HTMLElement>('.editor-card');
    const editorStyle = editor ? getComputedStyle(editor) : null;
    const icons = Array.from(document.querySelectorAll('.editor-field-icon svg')).map((icon) => {
      const rect = icon.getBoundingClientRect();
      return { width: Math.round(rect.width), height: Math.round(rect.height) };
    });
    return {
      firstLastSameColumn: Boolean(first && last && Math.abs(first.x - last.x) < 2 && last.y > first.y),
      lastCompanySameColumn: Boolean(last && company && Math.abs(last.x - company.x) < 2 && company.y > last.y),
      editorBackground: editorStyle?.backgroundColor,
      editorRadius: editorStyle?.borderRadius,
      icons,
    };
  });
  expect(fieldLayout.firstLastSameColumn).toBe(true);
  expect(fieldLayout.lastCompanySameColumn).toBe(true);
  expect(fieldLayout.editorBackground).toBe('rgba(0, 0, 0, 0)');
  expect(fieldLayout.editorRadius).toBe('0px');
  expect(fieldLayout.icons).toEqual(Array.from({ length: 9 }, () => ({ width: 22, height: 22 })));

  await editor.getByLabel('First name').fill('Test');
  await editor.getByLabel('Last name').fill('Best');
  await editor.getByLabel('Company').fill('Iris Test Lab');
  await editor.getByLabel('Job title').fill('Contact Wrangler');
  await editor.getByLabel('Email').fill('test@example.test');
  await editor.getByLabel('Phone').fill('+358 12 345678');
  await editor.getByLabel('Address').fill('Example Street 1');
  await editor.getByLabel('Birthday').fill('2026-06-17');
  await editor.getByLabel('Groups').fill('Friends');
  await editor.getByLabel('Notes').fill('Met at a tiny excellent test.');
  await page.getByRole('button', { name: 'Save' }).click();

  await expect(page.getByRole('heading', { name: 'Test Best' })).toBeVisible();
  const details = page.getByLabel('Contact details');
  await expect(details.getByText('test@example.test')).toBeVisible();
  await expect(details.getByText('+358 12 345678')).toBeVisible();
  await expect(details.getByText('Contact Wrangler, Iris Test Lab')).toBeVisible();
  await expect(details.getByText('Example Street 1')).toBeVisible();
  await expect(details.getByText('June 17, 2026')).toBeVisible();
  await expect(details.getByText('Friends')).toBeVisible();
  await expect(page).toHaveURL(/\/[0-9a-f-]{36}$/);
  await expect(page.getByText('Copy to form')).toHaveCount(0);
  await expect(page.getByText('Save private copy')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Edit' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Delete contact' })).toBeVisible();
  const trashIconAlignment = await page.getByRole('button', { name: 'Delete contact' }).evaluate((button) => {
    const svg = button.querySelector('svg');
    const buttonRect = button.getBoundingClientRect();
    const svgRect = svg?.getBoundingClientRect();
    return svgRect ? {
      dx: Math.abs((svgRect.left + svgRect.width / 2) - (buttonRect.left + buttonRect.width / 2)),
      dy: Math.abs((svgRect.top + svgRect.height / 2) - (buttonRect.top + buttonRect.height / 2)),
    } : { dx: 999, dy: 999 };
  });
  expect(trashIconAlignment.dx).toBeLessThan(0.5);
  expect(trashIconAlignment.dy).toBeLessThan(0.5);

  await page.getByRole('button', { name: 'Edit' }).click();
  await expect(page.getByRole('heading', { name: 'Edit contact' })).toBeVisible();
  await page.getByRole('form', { name: 'Edit contact' }).getByLabel('Job title').fill('Senior Contact Wrangler');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByRole('heading', { name: 'Test Best' })).toBeVisible();
  await expect(page.getByLabel('Contact details').getByText('Senior Contact Wrangler, Iris Test Lab')).toBeVisible();

  await page.getByRole('button', { name: 'Delete contact' }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expect(page.getByText('Removed private contact.')).toBeVisible();
});

test('links Nostr contacts to their Iris social profile', async ({ page }) => {
  await openVisibleContact(page, 'ODELL');

  const profile = page.getByLabel('Contact profile');
  await expect(profile.locator('.profile-avatar-badge')).toHaveCount(0);
  await expect(profile.locator('.profile-title-row [data-testid="social-distance-badge"]')).toHaveCount(0);
  await expect(profile.locator('.profile-handle-line')).toHaveCount(0);
  await expect(profile.getByText('NIP-05')).toHaveCount(0);
  const relationship = page.getByLabel('Profile relationship');
  await expect(relationship).toBeVisible();
  await expect(relationship.locator('[data-testid="social-distance-badge"]')).toBeVisible();
  await expect(relationship).toContainText(/Followed by|Followed by you|friends of friends/);
  const socialGraph = page.getByLabel('Social graph');
  await expect(socialGraph).toBeVisible();
  const profileContextOrder = await page.evaluate(() => {
    const stats = document.querySelector('[aria-label="Social graph"]')?.getBoundingClientRect();
    const followedBy = document.querySelector('[aria-label="Profile relationship"]')?.getBoundingClientRect();
    return stats && followedBy ? followedBy.top > stats.top : false;
  });
  expect(profileContextOrder).toBe(true);

  const socialLink = page.getByRole('link', { name: 'Iris social profile' });
  await expect(socialLink).toBeVisible();
  await expect(socialLink).toContainText('Social profile');
  await expect(socialLink).toHaveAttribute('href', /^https:\/\/iris\.to\/npub1/);
  await expect(page.getByRole('heading', { name: 'Iris' })).toHaveCount(0);
  await expect(page.getByText('Open social profile')).toHaveCount(0);
  await expect(page.getByText('Checking Iris Chat')).toHaveCount(0);
  await expect(page.getByText(/chat devices?/i)).toHaveCount(0);
});

test('opens public profiles from UUID URLs and accepts npub aliases', async ({ page }) => {
  await openVisibleContact(page, 'ODELL');

  const href = await page.getByRole('link', { name: 'Iris social profile' }).getAttribute('href');
  const npub = href ? new URL(href).pathname.slice(1) : '';
  expect(npub).toMatch(/^npub1/);
  const publicUuid = new URL(page.url()).pathname.slice(1);
  expect(publicUuid).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
  expect(publicUuid).not.toBe(npub);
  await page.evaluate(() => {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: {
        writeText: async (text: string) => {
          (window as unknown as { __copiedText?: string }).__copiedText = text;
        },
      },
    });
  });
  await page.getByRole('button', { name: 'More profile actions' }).click();
  await page.getByRole('menuitem', { name: 'Copy public key' }).click();
  await expect.poll(async () => page.evaluate(() => (
    (window as unknown as { __copiedText?: string }).__copiedText
  ))).toBe(npub);
  await expect(page.getByText('Copied public key.')).toHaveCount(0);

  await page.goto(`/${npub}`);
  await expect(page.getByRole('heading', { name: 'ODELL' })).toBeVisible();
  await expect(page).toHaveURL(new RegExp(`/${publicUuid}$`));
  await expect(page.getByRole('button', { name: 'Back to contacts' })).toBeVisible();
  await page.getByPlaceholder('Search').fill('Edward Snowden');
  await expect(searchResult(page, 'Edward Snowden')).toHaveCount(1);
  await searchResult(page, 'Edward Snowden').click();
  await expect(page.getByRole('heading', { name: 'Edward Snowden' })).toBeVisible();

  await page.getByRole('button', { name: 'Back to contacts' }).click();
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expect(page).toHaveURL(/\/$/);
  await page.getByPlaceholder('Search').fill(npub);
  await expect(searchResult(page, 'ODELL')).toHaveCount(1);
});

test('saves private notes from public profile pages', async ({ page }) => {
  await openVisibleContact(page, 'ODELL');

  const details = page.getByLabel('Contact details');
  const notesInput = details.getByLabel('Notes');
  await expect(notesInput).toHaveValue('');
  await expect(details.getByRole('button', { name: 'Save note' })).toHaveCount(0);

  await notesInput.fill('Local note for ODELL');
  await expect(details.getByText('Private in this browser')).toBeVisible();
  await expect(page.getByText('Saved private note locally.')).toHaveCount(0);
  await expect.poll(async () => page.evaluate((key) => {
    const stored = window.localStorage.getItem(key);
    if (!stored) return false;
    const parsed = JSON.parse(stored) as { contacts?: Array<{ notes?: string }> };
    return parsed.contacts?.some((contact) => contact.notes === 'Local note for ODELL') ?? false;
  }, privateContactsStorageKey)).toBe(true);

  await page.reload();
  await expect(page.getByRole('heading', { name: 'ODELL' })).toBeVisible();
  await expect(page.getByLabel('Contact details').getByLabel('Notes')).toHaveValue('Local note for ODELL');
});

test('opens local-only contacts from canonical UUID URLs', async ({ page }) => {
  await page.addInitScript(({ key, uuid, picture }) => {
    window.localStorage.setItem(key, JSON.stringify({
      version: 1,
      exportedAt: '2026-06-15T00:00:00.000Z',
      contacts: [{
        id: uuid,
        name: 'Routed Local',
        handle: 'local@example.test',
        email: 'local@example.test',
        source: 'private',
        groups: ['Route test'],
        notes: 'Local URL profile',
        updatedAt: 1770000000000,
        pubkey: null,
        npub: null,
        picture,
        followDistance: null,
        followedByFriends: 0,
      }],
    }));
  }, { key: privateContactsStorageKey, uuid: routedPrivateUuid, picture: localPictureDataUrl });

  await page.goto(`/${routedPrivateUuid}`);
  await expect(page.getByRole('heading', { name: 'Routed Local' })).toBeVisible();
  await expect(page.getByText('local@example.test')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Iris social profile' })).toHaveCount(0);
  await expect(page).toHaveURL(new RegExp(`/${routedPrivateUuid}$`));
  const photoButton = page.getByRole('button', { name: 'Open Routed Local photo' });
  await expect.poll(async () => photoButton.evaluate((button) => getComputedStyle(button).cursor)).toBe('pointer');
  await photoButton.hover();
  await expect.poll(async () => photoButton.evaluate((button) => getComputedStyle(button).boxShadow)).toBe('none');
  await expect.poll(async () => photoButton.evaluate((button) => getComputedStyle(button).transform)).toBe('none');
  await photoButton.click();
  const photoDialog = page.getByRole('dialog', { name: 'Routed Local photo' });
  await expect(photoDialog).toBeVisible();
  await expect(photoDialog.locator('img')).toHaveAttribute('src', localPictureDataUrl);
  await expect.poll(async () => photoDialog.locator('img').evaluate((image) => getComputedStyle(image).borderRadius)).toBe('0px');
  await page.keyboard.press('Escape');
  await expect(photoDialog).toHaveCount(0);

  await page.getByRole('button', { name: 'Back to contacts' }).click();
  await page.getByPlaceholder('Search').fill(routedPrivateUuid);
  await expect(searchResult(page, 'Routed Local')).toHaveCount(1);
  await page.getByPlaceholder('Search').fill('local@example.test');
  await expect(searchResult(page, 'Routed Local')).toHaveCount(1);
});

test('shows profile about in the hero separately from private notes', async ({ page }) => {
  const about = [
    'I build tiny calm tools for humans. https://example.test/about',
    'This profile about is public profile metadata, not a private note.',
    'Long enough to need a real height clamp on narrow screens and still keep URLs clickable.',
    'Another line so the collapsed view has something meaningful to hide.',
    'One more line for the show less path.',
  ].join('\n');
  await page.addInitScript(({ key, uuid, aboutText }) => {
    window.localStorage.setItem(key, JSON.stringify({
      version: 1,
      exportedAt: '2026-06-19T00:00:00.000Z',
      contacts: [{
        id: uuid,
        name: 'About Local',
        handle: 'about@example.test',
        source: 'private',
        groups: [],
        notes: 'Private reminder',
        about: aboutText,
        updatedAt: 1770000000000,
        pubkey: null,
        npub: null,
        picture: '',
        followDistance: null,
        followedByFriends: 0,
      }],
    }));
  }, { key: privateContactsStorageKey, uuid: aboutPrivateUuid, aboutText: about });

  await page.goto(`/${aboutPrivateUuid}`);
  await expect(page.getByRole('heading', { name: 'About Local' })).toBeVisible();
  const hero = page.getByLabel('Contact profile');
  await expect(hero.getByText('I build tiny calm tools for humans.')).toBeVisible();
  const aboutLink = hero.getByRole('link', { name: 'https://example.test/about' });
  await expect(aboutLink).toHaveAttribute('href', 'https://example.test/about');
  await expect(hero.getByRole('button', { name: 'show more' })).toBeVisible();

  const aboutText = page.locator('.profile-about-text');
  const collapsedMetrics = await aboutText.evaluate((element) => ({
    height: element.getBoundingClientRect().height,
    scrollHeight: element.scrollHeight,
    isClamped: element.classList.contains('clamped'),
  }));
  expect(collapsedMetrics.height).toBeLessThanOrEqual(98);
  expect(collapsedMetrics.scrollHeight).toBeGreaterThan(collapsedMetrics.height);
  expect(collapsedMetrics.isClamped).toBe(true);
  const aboutToggle = hero.getByRole('button', { name: 'show more' });
  await aboutToggle.scrollIntoViewIfNeeded();
  await aboutToggle.click({ force: true });
  await expect.poll(async () => aboutText.evaluate((element) => element.classList.contains('clamped'))).toBe(false);
  await expect(hero.getByRole('button', { name: 'show less' })).toBeVisible();

  const details = page.getByLabel('Contact details');
  const notesInput = details.getByLabel('Notes');
  await expect(notesInput).toHaveValue('Private reminder');
  await expect(details.getByText('https://example.test/about')).toHaveCount(0);
  await notesInput.fill('Private reminder, updated locally');
  await expect(details.getByRole('button', { name: 'Save note' })).toHaveCount(0);
  await expect.poll(async () => page.evaluate((key) => {
    const stored = window.localStorage.getItem(key);
    if (!stored) return false;
    const parsed = JSON.parse(stored) as { contacts?: Array<{ notes?: string }> };
    return parsed.contacts?.some((contact) => contact.notes === 'Private reminder, updated locally') ?? false;
  }, privateContactsStorageKey)).toBe(true);
  await expect(details.getByLabel('Notes')).toHaveValue('Private reminder, updated locally');
});

test('changes follow state from the profile page', async ({ page }) => {
  await openVisibleContact(page, 'ODELL');

  await page.getByRole('button', { name: 'Unfollow', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Follow', exact: true })).toBeVisible();
  await expect(page.getByText('Not following')).toBeVisible();

  await page.getByRole('button', { name: 'Follow', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Unfollow', exact: true })).toBeVisible();
  await expect(page.getByText('Following locally')).toBeVisible();
});

test('mutes profiles from the overflow menu and hides them from search', async ({ page }) => {
  await openVisibleContact(page, 'ODELL');

  await page.getByRole('button', { name: 'More profile actions' }).click();
  await page.getByRole('menuitem', { name: 'Mute' }).click();
  await expect(page.getByRole('button', { name: 'Unmute' })).toBeVisible();
  await expect(page.getByText('Muted locally', { exact: true })).toBeVisible();

  await page.getByRole('button', { name: 'Back to contacts' }).click();
  await page.getByPlaceholder('Search').fill('ODELL');
  await expect(searchResult(page, 'ODELL')).toHaveCount(0);

  await page.locator('.account-actions').getByRole('button', { name: 'Settings' }).click();
  await page.getByRole('button', { name: 'Muted' }).click();
  await expect(page.getByRole('heading', { name: 'Muted profiles' })).toBeVisible();
  await expect(page.getByText('1 hidden from contacts and search.')).toBeVisible();
  const mutedProfile = page.locator('.muted-profile-button');
  await expect(mutedProfile).toContainText('ODELL');
  await expect(mutedProfile).not.toContainText('Muted profile');
  await expect(page.locator('.muted-profile-button .iris-user-row-description')).toHaveCount(0);
  await expect(page.getByText(/^[0-9a-f]{8}\.\.\.$/i)).toHaveCount(0);

  await mutedProfile.click();
  await expect(page.getByRole('heading', { name: 'ODELL' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Unmute' })).toBeVisible();
  await page.getByRole('button', { name: 'Unmute' }).click();
  await expect(page.getByText('Unmuted ODELL locally.')).toBeVisible();
});

test('does not horizontally overflow on desktop or mobile widths', async ({ page }) => {
  await expectPageToFitViewport(page);

  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expectPageToFitViewport(page);
});

test('keeps the sticky header flush while scrolling', async ({ page }) => {
  await expectAppBarTop(page, 0);
  await page.mouse.wheel(0, 420);
  await expectAppBarTop(page, 0);

  await page.setViewportSize({ width: 390, height: 844 });
  await page.evaluate(() => window.scrollTo(0, 0));
  await expect(page.getByPlaceholder('Search')).toBeVisible();
  await expectAppBarTop(page, 0);
  await page.mouse.wheel(0, 420);
  await expectAppBarTop(page, 0);
});

async function openVisibleContact(page: import('@playwright/test').Page, name: string): Promise<void> {
  const row = page.locator('[data-contact-index]').filter({ hasText: name });
  await expect(row).toHaveCount(1);
  await row.focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { name })).toBeVisible();
}

function searchResult(page: import('@playwright/test').Page, name: string) {
  return page.locator('[data-search-result-index]').filter({ hasText: name });
}

async function navCount(button: import('@playwright/test').Locator, label: string): Promise<number> {
  const text = await button.textContent();
  const match = new RegExp(`${label}\\s+(\\d+)`).exec(text?.replace(/\s+/g, ' ').trim() ?? '');
  return match ? Number(match[1]) : 0;
}

async function profileGraphStatCount(button: import('@playwright/test').Locator): Promise<number> {
  const text = await button.textContent();
  const match = /(\d+)/.exec(text?.replace(/\s+/g, ' ').trim() ?? '');
  return match ? Number(match[1]) : 0;
}

function contactCountText(count: number): string {
  return `${count} ${count === 1 ? 'contact' : 'contacts'}`;
}

async function expectPageToFitViewport(page: import('@playwright/test').Page): Promise<void> {
  await expect.poll(async () => page.evaluate(() => (
    document.documentElement.scrollWidth - document.documentElement.clientWidth
  ))).toBeLessThanOrEqual(0);
}

async function expectAppBarTop(page: import('@playwright/test').Page, expectedTop: number): Promise<void> {
  await expect.poll(async () => page.locator('.app-bar').evaluate((header) => (
    Math.round(header.getBoundingClientRect().top)
  ))).toBe(expectedTop);
}
