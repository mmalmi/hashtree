import { expect, test } from '@playwright/test';

test('keeps the secret-key session and private contacts on an offline deep-link reload', async ({ page, context }) => {
  await page.goto('/');
  await page.locator('.account-actions').getByRole('button', { name: 'Sign in' }).click();
  await page.getByTestId('identity-create-name').fill('Offline account');
  await page.getByTestId('contacts-create-identity').click();
  await expect(page.getByLabel('Signed in identity')).toBeVisible();
  const session = await page.evaluate(() => localStorage.getItem('iris-contacts:identity-session:v1'));
  expect(session).toBeTruthy();
  await page.getByRole('button', { name: 'Go to contacts home' }).click();
  await page.getByRole('button', { name: 'Create contact' }).click();
  const form = page.getByRole('form', { name: 'Create contact' });
  await form.getByLabel('First name').fill('Private offline friend');
  await form.getByLabel('Notes').fill('Kept only on this device');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByRole('heading', { name: 'Private offline friend' })).toBeVisible();
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Private offline friend' })).toBeVisible();
  await expect(page.getByRole('textbox', { name: 'Notes', exact: true })).toHaveValue('Kept only on this device');
  expect(await page.evaluate(() => localStorage.getItem('iris-contacts:identity-session:v1'))).toBe(session);
});

test('keeps the packaged public contact graph available offline', async ({ page, context }) => {
  await page.route('https://graph-api.iris.to/**', route => route.abort());
  await page.routeWebSocket(/wss:\/\//, socket => socket.close());
  await page.goto('/');
  const firstContact = page.locator('[data-contact-index="0"]');
  await expect(firstContact).toBeVisible();
  const name = await firstContact.textContent();
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  await context.setOffline(true);
  await page.reload();
  await expect(firstContact).toHaveText(name ?? '');
  await expect(page.getByText(/Initial social graph unavailable/)).toHaveCount(0);
});
