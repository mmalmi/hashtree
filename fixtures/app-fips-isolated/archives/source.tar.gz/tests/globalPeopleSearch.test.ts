import { describe, expect, it } from 'vitest';
import {
  parseGlobalPeopleSearchEntry,
  rankGlobalPeopleSearchProfiles,
  uniqueGlobalPeopleSearchProfiles,
} from '../src/lib/globalPeopleSearch';

const alice = '1'.repeat(64);
const bob = '2'.repeat(64);

describe('global people search', () => {
  it('projects the census-backed Hashtree search entry into a contact profile', () => {
    const profile = parseGlobalPeopleSearchEntry({
      id: alice,
      score: 12,
      value: JSON.stringify({
        pubkey: alice,
        name: 'Alice Example',
        aliases: ['alice', 'Ally'],
        nip05: 'alice@example.com',
        follow_distance: 3,
        created_at: 1_721_234_567,
        event_nhash: 'nhash1ignored-by-the-search-projection',
      }),
    });

    expect(profile).toMatchObject({
      pubkey: alice,
      name: 'Alice Example',
      displayName: 'Alice Example',
      username: 'alice',
      nickname: 'Ally',
      nip05: 'alice@example.com',
    });
    expect(profile?.socialDistance).toBe(3);
    expect(profile?.createdAt).toBe(1_721_234_567);
  });

  it('rejects malformed and identity-mismatched search entries', () => {
    expect(parseGlobalPeopleSearchEntry({ id: 'bad', score: 1, value: '{}' })).toBeNull();
    expect(parseGlobalPeopleSearchEntry({
      id: bob,
      score: 1,
      value: JSON.stringify({ pubkey: alice, name: 'Mismatched identity' }),
    })).toBeNull();
  });

  it('orders lexical relevance before social distance and removes duplicate pubkeys', () => {
    const exact = parseGlobalPeopleSearchEntry({
      id: alice,
      score: 1,
      value: JSON.stringify({ pubkey: alice, name: 'Alice', follow_distance: 4, created_at: 2 }),
    })!;
    const prefix = parseGlobalPeopleSearchEntry({
      id: bob,
      score: 99,
      value: JSON.stringify({ pubkey: bob, name: 'Alice Cooper', follow_distance: 1, created_at: 3 }),
    })!;

    expect(rankGlobalPeopleSearchProfiles([prefix, exact], 'alice').map((profile) => profile.pubkey))
      .toEqual([alice, bob]);
    expect(uniqueGlobalPeopleSearchProfiles([prefix, exact, { ...exact, name: 'Older Alice' }]))
      .toHaveLength(2);
  });
});
