import { describe, expect, it } from 'vitest';
import { HashTree, LinkType, MemoryStore } from '@hashtree/core';
import fs from 'node:fs';
import path from 'node:path';

const swInitSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'lib', 'swInit.ts'), 'utf8');
const htreeRuntimeSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'lib', 'htreeRuntime.ts'), 'utf8');
const mediaStreamingSetupSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'lib', 'mediaStreamingSetup.ts'), 'utf8');
const workerClientSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'lib', 'workerClient.ts'), 'utf8');
const swSource = fs.readFileSync(path.resolve(process.cwd(), 'src', 'sw.ts'), 'utf8');
const viteConfigSource = fs.readFileSync(path.resolve(process.cwd(), 'vite.config.ts'), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(path.resolve(process.cwd(), 'package.json'), 'utf8')) as {
  dependencies?: Record<string, string>;
  pnpm?: { overrides?: Record<string, string>; patchedDependencies?: Record<string, string> };
};
const installedHashtreeRoot = path.resolve(process.cwd(), 'node_modules', '@hashtree');
const hashtreeWorkerMediaHandlerSource = fs.readFileSync(
  path.resolve(installedHashtreeRoot, 'worker', 'src', 'relay', 'mediaHandler.ts'),
  'utf8',
);
const hashtreeWorkerAppRuntimeSource = fs.readFileSync(
  path.resolve(installedHashtreeRoot, 'worker', 'src', 'app-runtime.ts'),
  'utf8',
);
const hashtreeWorkerRelayWorkerSource = fs.readFileSync(
  path.resolve(installedHashtreeRoot, 'worker', 'src', 'relay', 'worker.ts'),
  'utf8',
);
const hashtreeCoreBlossomSource = fs.readFileSync(
  path.resolve(installedHashtreeRoot, 'core', 'src', 'store', 'blossom.ts'),
  'utf8',
);

describe('service worker update policy', () => {
  it('activates waiting updates immediately on runtime hosts', () => {
    expect(viteConfigSource).toContain("registerType: 'autoUpdate'");
    expect(swInitSource).toContain('onNeedRefresh()');
    expect(swInitSource).toContain('updateSW(true);');
    expect(swSource).toContain('self.skipWaiting();');
  });

  it('reloads once when a new worker takes control so fresh assets are used', () => {
    expect(swInitSource).toContain("navigator.serviceWorker.addEventListener('controllerchange'");
    expect(swInitSource).toContain("const SW_RELOAD_KEY = 'iris-sites-sw-reload-at';");
    expect(swInitSource).toContain('const SW_RELOAD_DEDUP_MS = 5_000;');
    expect(swInitSource).toContain('shouldReloadForControllerChange()');
    expect(swInitSource).toContain('window.location.reload();');
  });

  it('falls back to explicit dev service worker registration when Workbox is slow', () => {
    expect(swInitSource).toContain("navigator.serviceWorker.register('/dev-sw.js?dev-sw'");
    expect(swInitSource).toContain("type: 'module'");
    expect(swInitSource).toContain("updateViaCache: 'none'");
    expect(swInitSource).toContain('await devRegistration.update().catch');
  });

  it('cleans test service workers once and exposes a stable controller-ready state', () => {
    expect(swInitSource).toContain("const SW_TEST_STATE_KEY = 'iris-sites-test-sw-state';");
    expect(swInitSource).toContain("sessionStorage.setItem(SW_TEST_STATE_KEY, 'cleaned');");
    expect(swInitSource).toContain("sessionStorage.setItem(SW_TEST_STATE_KEY, 'ready');");
  });

  it('does not intercept Vite dev assets on the plain localhost shell', () => {
    expect(swSource).toContain('function isPlainLocalDevShell(url: URL): boolean');
    expect(swSource).toContain("url.hostname === 'localhost'");
    expect(swSource).toContain("url.hostname === '127.0.0.1'");
    expect(swSource).toMatch(/if \(!rawPath\.startsWith\('\/htree\/'\)\) \{\s+if \(isPlainLocalDevShell\(url\)\) return;/);
  });

  it('broadcasts worker port reconnect requests beyond the fetch client', () => {
    expect(swSource).toContain("const postedClientIds = new Set<string>();");
    expect(swSource).toContain("const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });");
    expect(swSource).toContain('if (postedClientIds.has(client.id)) continue;');
    expect(swSource).not.toContain('if (posted === 0)');
  });

  it('re-registers the media worker port when the service worker asks', () => {
    expect(mediaStreamingSetupSource).toContain("data?.type !== 'REQUEST_WORKER_PORT_RECONNECT'");
    expect(mediaStreamingSetupSource).toContain('data.clientKey && data.clientKey !== getMediaClientKey()');
    expect(mediaStreamingSetupSource).toContain('void setupMediaStreaming();');
  });

  it('uses immutable Hashtree release packages instead of sibling links or patch files', () => {
    const releaseRoot =
      'https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.27';
    expect(packageJson.dependencies?.['@hashtree/core']).toBe(`${releaseRoot}/hashtree-core-0.4.0.tgz`);
    expect(packageJson.dependencies?.['@hashtree/worker']).toBe('https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.41/hashtree-worker-0.4.25.tgz');
    expect(packageJson.pnpm?.overrides?.['@hashtree/core']).toBeUndefined();
    expect(packageJson.pnpm?.overrides?.['@hashtree/worker']).toBeUndefined();
    expect(packageJson.pnpm?.patchedDependencies).toBeUndefined();
  });

  it('actively resolves mutable hashtree roots for runtime path requests', () => {
    expect(hashtreeWorkerMediaHandlerSource).toContain('resolveTreeRootNow(npub, treeName, ROOT_WAIT_TIMEOUT_MS)');
    expect(hashtreeWorkerMediaHandlerSource).toContain('const currentRoot = await waitForCachedRoot(npub, treeName);');
    expect(hashtreeWorkerMediaHandlerSource).toContain('const currentEntry = await resolveEntryWithinRoot');
    expect(hashtreeWorkerMediaHandlerSource).not.toContain('resolveEntryInFreshMutableRoots');
  });

  it('streams unknown-size worker downloads before returning a miss', () => {
    expect(hashtreeWorkerMediaHandlerSource).toContain('streamUnknownSizeSwResponse');
    expect(hashtreeWorkerMediaHandlerSource).toContain("typeof tree.readFileStream === 'function'");
    expect(hashtreeWorkerMediaHandlerSource).toContain("typeof tree.readFileRange === 'function'");
    expect(hashtreeWorkerMediaHandlerSource).toContain('sendBufferedSwResponse(requestId, fullData');
  });

  it('lists and resolves encrypted files through canonical directory fanout', async () => {
    const tree = new HashTree({ store: new MemoryStore(), maxLinks: 2 });
    const file = await tree.putFile(Uint8Array.of(42));
    const names = ['a', 'b', 'c'];
    const entries = names.map(name => ({ name, ...file, type: LinkType.File }));
    for (const unencrypted of [true, false]) {
      const root = await tree.putDirectory(entries, { unencrypted });
      expect((await tree.listDirectory(root.cid)).map(entry => entry.name)).toEqual(names);
      const child = await tree.resolvePath(root.cid, 'c');
      expect(child?.cid).toEqual(file.cid);
    }
    expect(hashtreeWorkerMediaHandlerSource).not.toContain('findEntryInChunkedDirectory');
  });

  it('uses the hashtree batch download endpoint when direct hash URL fetches fail', () => {
    expect(hashtreeCoreBlossomSource).toContain('BLOB_BATCH_DOWNLOAD_MAGIC');
    expect(hashtreeCoreBlossomSource).toContain('BLOB_BATCH_DOWNLOAD_CONTENT_TYPE');
    expect(hashtreeCoreBlossomSource).toContain('preferBatchReads?: boolean;');
    expect(hashtreeCoreBlossomSource).toContain('server.preferBatchReads ? tryBatchRead() : Promise.resolve(null)');
    expect(hashtreeCoreBlossomSource).toContain('async getFromBatchEndpoint');
    expect(hashtreeCoreBlossomSource).toContain("fetch(`${server.url}/blob/batch`");
    expect(hashtreeCoreBlossomSource).toContain('JSON.stringify({ hashes: [hashHex] })');
    expect(hashtreeCoreBlossomSource).toContain('sha256(data)');
  });

  it('falls back to direct service-worker reads for immutable hashtree paths', () => {
    expect(swSource).toContain("import { BlossomStore, HashTree, nhashDecode, type CID } from '@hashtree/core';");
    expect(swSource).toContain('function getDirectImmutableTree()');
    expect(swSource).toContain('DIRECT_IMMUTABLE_PRE_PORT_TIMEOUT_MS');
    expect(swSource).toContain('DIRECT_IMMUTABLE_FALLBACK_TIMEOUT_MS');
    expect(swSource).toContain('function runWithTimeout');
    expect(swSource).toContain('function serveViaWorkerWithDirectImmutableFallback');
    expect(swSource).toContain('Promise.race([');
    expect(swSource).toContain('tree.resolvePath(rootCid, parts, signal)');
    expect(swSource).not.toContain('findEntryInDirectChunkedDirectory');
    expect(swSource).toContain('createDirectImmutableResponse(target.nhash, filePath, request)');
    expect(swSource).toContain('shouldUseDirectImmutableFallback');
  });

  it('prefers a registered worker port before direct immutable fallback', () => {
    expect(swSource).toMatch(/let port = getPort\(clientId, clientKey\);[\s\S]*?if \(!port && target\.nhash\)/);
    expect(swSource).not.toMatch(/const requestUrl = new URL\(request\.url\);\s+if \(target\.nhash\)/);
  });

  it('awaits @hashtree/worker media port registration before rendering /htree iframes', () => {
    expect(hashtreeWorkerAppRuntimeSource).toContain('await portOptions.registerMediaPort(channel.port2, !!portOptions.debug);');
    expect(hashtreeWorkerAppRuntimeSource).toContain("data?.type === 'WORKER_PORT_READY'");
    expect(hashtreeWorkerRelayWorkerSource).toContain("case 'registerMediaPort':");
    expect(hashtreeWorkerRelayWorkerSource).toContain('registerMediaPort(msg.port, msg.debug);');
    expect(mediaStreamingSetupSource).toContain('await registerMediaPort(channel.port2);');
    expect(mediaStreamingSetupSource).toContain('const ok = await ackPromise;');
  });

  it('uses Iris blob endpoints as browser-side read fallbacks for newly published blocks', () => {
    expect(htreeRuntimeSource).toContain(
      "{ url: 'https://cdn.iris.to', read: true, write: false, preferBatchReads: true }",
    );
    expect(htreeRuntimeSource).toContain(
      "{ url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true }",
    );
    expect(workerClientSource).toContain(
      "{ url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true }",
    );
    expect(swSource).toContain(
      "{ url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true }",
    );
  });
});
