import { describe, expect, it } from 'vitest';
import { nhashEncode, toHex } from '@hashtree/core';
import { buildSiteFrameSrc } from '../src/lib/siteFrame';

const VALID_SNAPSHOT_NHASH = nhashEncode(new Uint8Array(32).fill(7));

describe('site frame src', () => {
  it('waits for runtime readiness before rendering frame paths', () => {
    const mutableSite = {
      kind: 'mutable' as const,
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: 'npub1example',
      treeName: 'enshittifier',
      entryPath: 'index.html',
    };

    expect(buildSiteFrameSrc(mutableSite, true, 'client-key', null)).toBe(
      '/htree/npub1example/enshittifier/index.html?htree_c=client-key',
    );
    expect(buildSiteFrameSrc(mutableSite, false, 'client-key', null)).toBe('');
    const hash = new Uint8Array(32).fill(1);
    const nhash = nhashEncode({ hash: toHex(hash) });
    expect(buildSiteFrameSrc(mutableSite, true, 'client-key', {
      hash,
      updatedAt: Date.now(),
      visibility: 'public',
    })).toBe(`/htree/${nhash}/index.html?htree_c=client-key`);
  });

  it('keeps non-public mutable sites on the npub/tree iframe path', () => {
    const mutableSite = {
      kind: 'mutable' as const,
      siteKey: 'pilot',
      title: 'enshittifier',
      npub: 'npub1example',
      treeName: 'enshittifier',
      entryPath: 'index.html',
    };

    expect(buildSiteFrameSrc(mutableSite, true, 'client-key', {
      hash: new Uint8Array(32).fill(2),
      updatedAt: Date.now(),
      visibility: 'link-visible',
    })).toBe('/htree/npub1example/enshittifier/index.html?htree_c=client-key');
  });

  it('renders immutable iframe src as soon as runtime is ready', () => {
    const immutableSite = {
      kind: 'immutable' as const,
      siteKey: 'pilot',
      title: 'Pinned',
      nhash: 'nhash1example',
      entryPath: 'docs/hello world.html',
    };

    expect(buildSiteFrameSrc(immutableSite, false, 'client-key', null)).toBe('');
    expect(buildSiteFrameSrc(immutableSite, true, 'client-key', null)).toBe(
      '/htree/nhash1example/docs/hello%20world.html?htree_c=client-key',
    );
    expect(buildSiteFrameSrc(immutableSite, true, 'client-key', null, 2)).toBe(
      '/htree/nhash1example/docs/hello%20world.html?htree_c=client-key&htree_r=2',
    );
  });

  it('renders snapshot iframe src with snapshot query params', () => {
    const snapshotSite = {
      kind: 'immutable' as const,
      siteKey: 'pilot',
      title: 'Pinned snapshot',
      nhash: VALID_SNAPSHOT_NHASH,
      entryPath: 'index.html',
      snapshot: true,
      snapshotLinkKey: 'a'.repeat(64),
    };

    expect(buildSiteFrameSrc(snapshotSite, true, 'client-key', null)).toBe(
      `/htree/${VALID_SNAPSHOT_NHASH}/index.html?snapshot=1&k=${'a'.repeat(64)}&htree_c=client-key`,
    );
  });
});
