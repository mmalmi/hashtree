import { defineConfig, type Plugin } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { VitePWA } from 'vite-plugin-pwa';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

export function sanitizePortableHtml(html: string): string {
  return html
    .replace(/^\s*<link rel="modulepreload".*$/gm, '')
    .replace(/\s+crossorigin(?=[\s>])/g, '');
}

function portableHtmlPlugin(): Plugin {
  return {
    name: 'portable-html',
    async closeBundle() {
      const indexPath = resolve(__dirname, 'dist', 'index.html');
      try {
        const html = await readFile(indexPath, 'utf8');
        await writeFile(indexPath, sanitizePortableHtml(html), 'utf8');
      } catch {
        // Ignore when build output does not exist.
      }
    },
  };
}

export default defineConfig({
  resolve: { dedupe: ['@fips/core', '@fips/transport-webrtc', 'nostr-pubsub', 'nostr-tools'] },
  base: './',
  plugins: [
    portableHtmlPlugin(),
    svelte(),
    VitePWA({
      registerType: 'autoUpdate',
      strategies: 'injectManifest',
      srcDir: 'src',
      filename: 'sw.ts',
      devOptions: {
        enabled: true,
        type: 'module',
      },
      manifest: {
        name: 'Iris: The Freedom Toolkit',
        short_name: 'Iris',
        description: 'Iris apps and sites. No email address, phone number, or sign-up required.',
        theme_color: '#000000',
        background_color: '#000000',
        display: 'standalone',
      },
      injectManifest: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm}'],
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
      },
    }),
  ],
  build: {
    modulePreload: false,
    reportCompressedSize: true,
    rollupOptions: {
      onLog(level, log, handler) {
        const message = typeof log.message === 'string' ? log.message : '';
        if (message.includes('Use of eval in') && message.includes('tseep')) return;
        handler(level, log);
      },
    },
  },
  server: {
    port: 5178,
    allowedHosts: [
      'apps.iris.to',
      '.apps.iris.to',
      'sites.iris.to',
      '.sites.iris.to',
      '.hashtree.cc',
      'iris.localhost',
      '.iris.localhost',
      'sites.iris.localhost',
      '.sites.iris.localhost',
    ],
  },
  optimizeDeps: {
    entries: [
      'index.html',
      'src/lib/hashtreeUploadWorker.ts',
      'src/lib/relayWorkerEntry.ts',
      'src/sw.ts',
    ],
    include: [
      '@hashtree/fips-transport/browser',
      '@hashtree/dexie',
      'nostr-pubsub',
      'workbox-window',
      '@noble/hashes/utils.js',
      '@scure/base',
      'debug',
      'nostr-tools/nip19',
      'nostr-tools/nip49',
      'tseep',
      'typescript-lru-cache',
    ],
  },
});
