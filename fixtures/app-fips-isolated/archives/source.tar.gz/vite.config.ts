import { defineConfig, type Plugin } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { VitePWA } from 'vite-plugin-pwa';

export function sanitizePortableHtml(html: string): string {
  return html
    .replace(/^\s*<link rel="modulepreload".*$/gm, '')
    .replace(/\s+crossorigin(?=[\s>])/g, '');
}

function portableHtmlPlugin(): Plugin {
  return {
    name: 'portable-html',
    apply: 'build',
    transformIndexHtml: { order: 'post', handler: sanitizePortableHtml },
  };
}

export default defineConfig({
  resolve: { dedupe: ['@fips/core', '@fips/transport-webrtc', 'nostr-pubsub', 'nostr-tools'] },
  base: './',
  plugins: [
    portableHtmlPlugin(),
    svelte(),
    VitePWA({
      registerType: 'autoUpdate',
      strategies: 'injectManifest',
      srcDir: 'src',
      filename: 'sw.ts',
      includeAssets: ['iris-contacts-icon.svg'],
      devOptions: {
        enabled: true,
        type: 'module',
      },
      manifest: {
        name: 'Iris Contacts',
        short_name: 'Contacts',
        description: 'Public and private contacts for Iris',
        theme_color: '#f7f8f5',
        background_color: '#f7f8f5',
        display: 'standalone',
        icons: [
          {
            src: 'iris-contacts-icon.svg',
            sizes: '512x512',
            type: 'image/svg+xml',
            purpose: 'any maskable',
          },
        ],
      },
      injectManifest: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm,bin}'],
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
      },
    }),
  ],
  build: {
    modulePreload: false,
    reportCompressedSize: true,
    rollupOptions: {
      onLog(level, log, handler) {
        const message = typeof log.message === 'string' ? log.message : '';
        if (message.includes('Use of eval in') && message.includes('tseep')) return;
        handler(level, log);
      },
    },
  },
  server: {
    port: 5182,
    allowedHosts: ['contacts.iris.to', '.contacts.iris.to', 'iris.localhost', '.iris.localhost'],
  },
  optimizeDeps: {
    entries: ['index.html', 'src/workers/publicEvents.worker.ts', 'src/workers/hashtree.worker.ts', 'src/sw.ts'],
    include: ['nostr-tools/nip19', '@hashtree/fips-transport/browser', 'workbox-window'],
  },
});
