import { nhashEncode, toHex } from '@hashtree/core';
import type { HostedSite } from './siteConfig';
import type { TreeRootInfo } from './workerClient';

function encodePath(path: string): string {
  return path
    .split('/')
    .filter(Boolean)
    .map((segment) => encodeURIComponent(segment))
    .join('/');
}

export function buildSiteFrameSrc(
  currentSite: HostedSite | null,
  runtimeReady: boolean,
  clientKey: string,
  currentTreeRoot: TreeRootInfo | null,
  reloadNonce = 0,
): string {
  if (!currentSite) return '';
  if (!runtimeReady) return '';
  const mutableTreeRoot = currentSite.kind === 'mutable' ? currentTreeRoot : null;

  const encodedPath = encodePath(currentSite.entryPath || 'index.html');
  if (currentSite.kind === 'immutable') {
    return buildImmutableFrameSrc(
      currentSite.nhash,
      encodedPath,
      clientKey,
      currentSite.snapshot,
      currentSite.snapshotLinkKey,
      reloadNonce,
    );
  }

  if (mutableTreeRoot?.visibility === 'public') {
    return buildImmutableFrameSrc(
      nhashEncode({
        hash: toHex(mutableTreeRoot.hash),
        decryptKey: mutableTreeRoot.key ? toHex(mutableTreeRoot.key) : undefined,
      }),
      encodedPath,
      clientKey,
      false,
      undefined,
      reloadNonce,
    );
  }

  const encodedTreeName = encodeURIComponent(currentSite.treeName);
  const params = new URLSearchParams();
  params.set('htree_c', clientKey);
  if (reloadNonce > 0) {
    params.set('htree_r', String(reloadNonce));
  }
  return `/htree/${currentSite.npub}/${encodedTreeName}/${encodedPath}?${params.toString()}`;
}

function buildImmutableFrameSrc(
  nhash: string,
  encodedPath: string,
  clientKey: string,
  snapshot = false,
  snapshotLinkKey?: string,
  reloadNonce = 0,
): string {
  const params = new URLSearchParams();
  if (snapshot) {
    params.set('snapshot', '1');
    if (snapshotLinkKey) {
      params.set('k', snapshotLinkKey);
    }
  }
  params.set('htree_c', clientKey);
  if (reloadNonce > 0) {
    params.set('htree_r', String(reloadNonce));
  }
  return `/htree/${nhash}/${encodedPath}?${params.toString()}`;
}
