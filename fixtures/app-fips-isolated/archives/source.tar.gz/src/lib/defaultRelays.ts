import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';

/** An explicitly empty deployment selection disables relay networking. */
export function resolveSiteRelays(configured?: string): string[] {
  return configured === undefined
    ? [...DEFAULT_PUBLIC_RELAYS]
    : [...new Set(configured.split(',').map(value => value.trim()).filter(Boolean))];
}

export const DEFAULT_SITE_RELAYS = resolveSiteRelays(import.meta.env.VITE_NOSTR_RELAYS);
