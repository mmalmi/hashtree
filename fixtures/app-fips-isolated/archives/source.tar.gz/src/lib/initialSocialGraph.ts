import type { SocialGraph as SocialGraphInstance } from 'nostr-social-graph';
import { loadRetainedPublicGraph, watchRetainedPublicGraph, type RetainedPublicGraph } from './publicGraphCache';
import socialGraphBinaryUrl from 'nostr-social-graph/data/socialGraph.bin?url';
import { PUBLIC_RELAY_CONFIG } from './publicRelayConfig';
import {
  contactIdentityIdForPubkey,
  decodeProfileInput,
  isHexPubkey,
  profileToContact,
  type ContactRecord,
  type ProfileRecord,
} from './contacts';

export const DEFAULT_SOCIAL_GRAPH_ROOT = '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';

type PackagedProfileRow = readonly unknown[];

export interface InitialSocialGraph {
  ownerPubkey: string;
  graph: SocialGraphInstance;
  profileByPubkey: Map<string, ProfileRecord>;
  profileCount: number;
  graphSize: ReturnType<SocialGraphInstance['size']>;
  directContacts: ContactRecord[];
  followerContacts: ContactRecord[];
}

export interface SearchInitialGraphOptions {
  excludePubkeys?: ReadonlySet<string>;
  hideOvermuted?: boolean;
  limit?: number;
  overmuteThreshold?: number;
}

const retainedGraphs = new WeakMap<SocialGraphInstance, RetainedPublicGraph>();
let graphBinaryPromise: Promise<Uint8Array> | null = null;
let profileLookupPromise: Promise<Map<string, ProfileRecord>> | null = null;

export async function loadInitialSocialGraph(ownerInput: string = DEFAULT_SOCIAL_GRAPH_ROOT): Promise<InitialSocialGraph> {
  const ownerPubkey = decodeProfileInput(ownerInput) ?? DEFAULT_SOCIAL_GRAPH_ROOT;
  const [retained, profileByPubkey] = await Promise.all([
    loadRetainedPublicGraph(ownerPubkey, loadGraphBinary, undefined, PUBLIC_RELAY_CONFIG.useDefaultBootstrap ? DEFAULT_SOCIAL_GRAPH_ROOT : undefined),
    loadProfileLookup(),
  ]);
  const { graph } = retained;
  retainedGraphs.set(graph, retained);
  const directContacts = buildContactsFromPubkeys(graph.getFollowedByUser(ownerPubkey), graph, profileByPubkey);
  const followerContacts = buildContactsFromPubkeys(graph.getFollowersByUser(ownerPubkey), graph, profileByPubkey);

  return {
    ownerPubkey,
    graph,
    profileByPubkey,
    profileCount: profileByPubkey.size,
    graphSize: graph.size(),
    directContacts,
    followerContacts,
  };
}

export function startInitialSocialGraphUpdates(
  initial: InitialSocialGraph, relays: string[], useDefaultBootstrap: boolean,
  changed: (graph: InitialSocialGraph) => void,
): () => void {
  const state = retainedGraphs.get(initial.graph);
  if (!state) return () => {};
  return watchRetainedPublicGraph(state, {
    relays: useDefaultBootstrap ? ['wss://graph-relay.iris.to', ...relays] : relays,
    authors: () => [initial.ownerPubkey, ...initial.graph.getFollowedByUser(initial.ownerPubkey)],
    changed: () => {
      initial.graphSize = initial.graph.size();
      initial.directContacts = buildContactsFromPubkeys(initial.graph.getFollowedByUser(initial.ownerPubkey), initial.graph, initial.profileByPubkey);
      initial.followerContacts = buildContactsFromPubkeys(initial.graph.getFollowersByUser(initial.ownerPubkey), initial.graph, initial.profileByPubkey);
      changed({ ...initial });
    },
  });
}

export function createProfileLookup(rows: readonly PackagedProfileRow[]): Map<string, ProfileRecord> {
  const profiles = new Map<string, ProfileRecord>();

  for (const row of rows) {
    const pubkey = readString(row[0]).toLowerCase();
    if (!isHexPubkey(pubkey)) continue;

    const name = readString(row[1]);
    const nip05 = readString(row[2]);
    const picture = normalizePictureUrl(readString(row[3]));
    const displayName = name || nip05;
    if (!displayName && !nip05) continue;

    profiles.set(pubkey, {
      pubkey,
      name,
      displayName,
      username: '',
      nickname: '',
      about: '',
      picture,
      nip05,
      website: '',
      lud16: '',
    });
  }

  return profiles;
}

export function buildContactsFromPubkeys(
  pubkeys: Iterable<string>,
  graph: SocialGraphInstance,
  profiles: ReadonlyMap<string, ProfileRecord>,
): ContactRecord[] {
  return [...pubkeys]
    .filter(isHexPubkey)
    .map((pubkey) => profileToContact(pubkey.toLowerCase(), profiles.get(pubkey.toLowerCase()), graph))
    .sort((a, b) => {
      const distanceA = a.followDistance ?? 999;
      const distanceB = b.followDistance ?? 999;
      if (distanceA !== distanceB) return distanceA - distanceB;
      if (a.followedByFriends !== b.followedByFriends) return b.followedByFriends - a.followedByFriends;
      return a.name.localeCompare(b.name);
    });
}

export function contactFromInitialGraphIdentityId(
  initialGraph: InitialSocialGraph,
  id: string,
): ContactRecord | null {
  const normalizedId = id.toLowerCase();
  for (const profile of initialGraph.profileByPubkey.values()) {
    if (contactIdentityIdForPubkey(profile.pubkey) === normalizedId) {
      return profileToContact(profile.pubkey, profile, initialGraph.graph);
    }
  }
  return null;
}

export function searchInitialGraphContacts(
  initialGraph: InitialSocialGraph,
  query: string,
  options: SearchInitialGraphOptions = {},
): ContactRecord[] {
  const hideOvermuted = options.hideOvermuted ?? true;
  const overmuteThreshold = options.overmuteThreshold ?? 1;
  const decodedPubkey = decodeProfileInput(query);
  if (decodedPubkey) {
    const profile = initialGraph.profileByPubkey.get(decodedPubkey);
    if (!profile || options.excludePubkeys?.has(decodedPubkey)) return [];
    if (hideOvermuted && isOvermuted(initialGraph.graph, decodedPubkey, overmuteThreshold)) return [];
    return [profileToContact(decodedPubkey, profile, initialGraph.graph)];
  }

  const terms = normalizeSearch(query).split(/\s+/).filter(Boolean);
  if (terms.length === 0) return [];

  const excludePubkeys = options.excludePubkeys ?? new Set<string>();
  const limit = options.limit ?? 20;
  const requirePrefix = terms.join('').length === 1;

  return [...initialGraph.profileByPubkey.values()]
    .map((profile) => {
      if (excludePubkeys.has(profile.pubkey)) return null;
      if (hideOvermuted && isOvermuted(initialGraph.graph, profile.pubkey, overmuteThreshold)) return null;
      const score = scoreProfile(profile, terms, initialGraph.graph, requirePrefix);
      return score > 0 ? { profile, score } : null;
    })
    .filter((entry): entry is { profile: ProfileRecord; score: number } => entry !== null)
    .sort((a, b) => b.score - a.score || a.profile.displayName.localeCompare(b.profile.displayName))
    .slice(0, limit)
    .map(({ profile }) => profileToContact(profile.pubkey, profile, initialGraph.graph));
}

export function isOvermuted(graph: SocialGraphInstance, pubkey: string, threshold = 1): boolean {
  if (pubkey === graph.getRoot()) return false;

  const stats = graph.stats(pubkey);
  const distances = Object.keys(stats)
    .map((distance) => Number(distance))
    .filter(Number.isFinite)
    .sort((a, b) => a - b);

  for (const distance of distances) {
    const opinion = stats[distance];
    if (!opinion || opinion.followers + opinion.muters === 0) continue;
    return opinion.muters * threshold > opinion.followers;
  }

  return false;
}

function loadGraphBinary(): Promise<Uint8Array> {
  graphBinaryPromise ??= fetch(socialGraphBinaryUrl)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Initial social graph download failed: ${response.status}`);
      }
      return response.arrayBuffer();
    })
    .then((buffer) => new Uint8Array(buffer));
  return graphBinaryPromise;
}

function loadProfileLookup(): Promise<Map<string, ProfileRecord>> {
  profileLookupPromise ??= import('nostr-social-graph/data/profileData.json')
    .then((module) => createProfileLookup(module.default as readonly PackagedProfileRow[]));
  return profileLookupPromise;
}

function scoreProfile(
  profile: ProfileRecord,
  terms: readonly string[],
  graph: SocialGraphInstance,
  requirePrefix: boolean,
): number {
  const fields = [
    profile.displayName,
    profile.name,
    profile.username,
    profile.nickname,
    profile.nip05,
    profile.pubkey,
  ].filter(Boolean);
  const normalizedFields = fields.map(normalizeSearch);

  if (!terms.every((term) => normalizedFields.some((field) => field.includes(term)))) {
    return 0;
  }

  const hasPrefix = terms.some((term) => normalizedFields.some((field) => field.startsWith(term)));
  if (requirePrefix && !hasPrefix) return 0;

  let score = 0;
  for (const term of terms) {
    if (normalizeSearch(profile.displayName).startsWith(term)) score += 8;
    else if (normalizeSearch(profile.name).startsWith(term)) score += 7;
    else if (normalizeSearch(profile.username).startsWith(term)) score += 6;
    else if (normalizeSearch(profile.nickname).startsWith(term)) score += 6;
    else if (normalizeSearch(profile.nip05).startsWith(term)) score += 5;
    else score += 1;
  }

  const distance = graph.getFollowDistance(profile.pubkey);
  if (distance < 1000) score += Math.max(0, 8 - distance);
  score += Math.min(graph.followedByFriendsCount(profile.pubkey), 20) * 0.25;
  return score;
}

function readString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function normalizeSearch(value: string): string {
  return value.trim().toLowerCase();
}

function normalizePictureUrl(value: string): string {
  if (!value) return '';
  if (/^(https?:|data:|blob:|\/)/i.test(value)) return value;
  return `https://${value}`;
}
