import { DexieStore } from '@hashtree/dexie';
import { generateSecretKey } from 'nostr-tools/pure';
import { bytesToHex } from '@noble/hashes/utils.js';
import { createBrowserHashtreeNostrProvider, supportsBrowserHashtreeFips, type BrowserHashtreeNostrProvider } from '@hashtree/fips-transport/browser';
import type { RelayWorkerClient } from '@hashtree/worker/relay-client';

export const SITE_BLOCK_STORE = 'iris-sites-worker';
export const SITE_UPLOAD_STORE = 'iris-sites-upload-worker';
let started: Promise<BrowserHashtreeNostrProvider | null> | null = null;

/** One authenticated mesh carries public roots and cached site/upload blocks. */
export function startSitePeers(worker: RelayWorkerClient, relays: string[]): Promise<BrowserHashtreeNostrProvider | null> {
  return started ??= (async () => {
    if (!supportsBrowserHashtreeFips()) return null;
    const keyName = 'iris-sites:fips-device-secret';
    let secret = localStorage.getItem(keyName);
    if (!secret || !/^[0-9a-f]{64}$/.test(secret)) {
      secret = bytesToHex(generateSecretKey());
      localStorage.setItem(keyName, secret);
    }
    const blocks = new DexieStore(SITE_BLOCK_STORE);
    const uploads = new DexieStore(SITE_UPLOAD_STORE);
    const provider = await createBrowserHashtreeNostrProvider({
      deviceSecretKey: secret, relays,
      websocketSeedUrls: import.meta.env.VITE_FIPS_WEBSOCKET_SEED_URLS?.split(',').filter(Boolean),
      localStore: {
        get: async hash => await blocks.get(hash) ?? await uploads.get(hash),
        has: async hash => await blocks.has(hash) || await uploads.has(hash),
        put: (hash, data) => blocks.put(hash, data),
        delete: hash => blocks.delete(hash),
      },
      allowedKinds: [30064, 30078],
      maxConnections: 4,
    });
    worker.setP2PProvider(provider);
    await worker.setNostrSource(provider.nostrSource);
    return provider;
  })().catch(error => { started = null; throw error; });
}
