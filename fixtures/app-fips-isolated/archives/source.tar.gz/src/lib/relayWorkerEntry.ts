import '@hashtree/worker/relay-entry';
