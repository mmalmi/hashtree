import {
  HashTree,
  LinkType,
  MemoryStore,
  cid,
  nhashEncode,
  streamUploadWithProgress,
  toHex,
  type CID,
  type DirEntry,
} from '@hashtree/core';
import type { BlossomServerConfig, RawBlockInput } from '@hashtree/worker/protocol';
import { buildLauncherHref } from './siteHost';

const SITE_UPLOAD_PREVIEW_LIMIT = 8;
const UPLOAD_BLOCK_BATCH_COUNT = 24;
const UPLOAD_BLOCK_BATCH_BYTES = 8 * 1024 * 1024;
const IGNORED_FILE_NAMES = new Set(['.DS_Store', 'Thumbs.db', 'desktop.ini']);
const markedUploadPaths = new WeakMap<File, string>();

type FileWithDirectoryPath = File & { webkitRelativePath?: string };

interface WebkitFileSystemEntry {
  isDirectory: boolean;
  isFile: boolean;
  name: string;
}

interface WebkitFileSystemFileEntry extends WebkitFileSystemEntry {
  file(
    successCallback: (file: File) => void,
    errorCallback?: (error: DOMException) => void,
  ): void;
}

interface WebkitFileSystemDirectoryEntry extends WebkitFileSystemEntry {
  createReader(): {
    readEntries(
      successCallback: (entries: WebkitFileSystemEntry[]) => void,
      errorCallback?: (error: DOMException) => void,
    ): void;
  };
}

type DataTransferItemWithEntry = DataTransferItem & {
  webkitGetAsEntry?: () => WebkitFileSystemEntry | null;
};

export interface SiteUploadFile {
  file: File;
  lastModified: number;
  path: string;
  size: number;
  type: string;
}

export interface SiteUploadDraft {
  entryPath: string;
  fileCount: number;
  files: SiteUploadFile[];
  hasIndexHtml: boolean;
  previewFiles: SiteUploadFile[];
  rootName: string;
  totalBytes: number;
}

export type SiteUploadPhase = 'building' | 'uploading' | 'done';

export interface SiteUploadProgress {
  current: number;
  currentFile?: string;
  label: string;
  phase: SiteUploadPhase;
  total: number;
}

export interface PublishedSiteUpload {
  immutableNhash: string;
  launcherHref: string;
}

export interface SiteUploadAppMetadata {
  icon?: string;
  iconPath?: string;
  name: string;
  source: 'manifest' | 'html' | 'folder';
}

export interface PublishSiteUploadOptions {
  blossomServers?: BlossomServerConfig[];
  currentHost?: string;
  onProgress?: (progress: SiteUploadProgress) => void;
}

interface DirectoryNode {
  directories: Map<string, DirectoryNode>;
  files: Map<string, SiteUploadFile>;
}

interface BuiltDirectory {
  cid: CID;
  size: number;
}

interface BuiltSiteTree {
  rootCid: CID;
  store: MemoryStore;
  tree: HashTree;
}

interface HtmlLinkMeta {
  href: string;
  rel: string;
}

interface ManifestIconLike {
  sizes?: unknown;
  src?: unknown;
  type?: unknown;
}

interface ManifestLike {
  icons?: unknown;
  name?: unknown;
  short_name?: unknown;
}

function createDirectoryNode(): DirectoryNode {
  return {
    directories: new Map(),
    files: new Map(),
  };
}

function filesFromInput(files: FileList | Iterable<File>): File[] {
  const maybeFileList = files as FileList;
  if (typeof maybeFileList.length === 'number' && typeof maybeFileList.item === 'function') {
    const result: File[] = [];
    for (let index = 0; index < maybeFileList.length; index += 1) {
      const file = maybeFileList.item(index);
      if (file) result.push(file);
    }
    return result;
  }

  return Array.from(files as Iterable<File>);
}

function splitPath(path: string): string[] {
  return path
    .replace(/\\/g, '/')
    .split('/')
    .map((part) => part.trim())
    .filter(Boolean);
}

function cleanPathParts(parts: string[]): string[] {
  return parts.filter((part) => part !== '.' && part !== '..');
}

function getCommonRoot(partsByFile: string[][]): string {
  if (partsByFile.length === 0) return '';
  const [firstRoot] = partsByFile[0];
  if (!firstRoot) return '';
  return partsByFile.every((parts) => parts[0] === firstRoot && parts.length > 1) ? firstRoot : '';
}

function getInputPath(file: File): string {
  const markedPath = markedUploadPaths.get(file);
  if (markedPath) return markedPath;
  const withDirectoryPath = file as FileWithDirectoryPath;
  return withDirectoryPath.webkitRelativePath || file.name;
}

function isIgnoredPath(parts: string[]): boolean {
  if (parts.length === 0) return true;
  const name = parts[parts.length - 1];
  return IGNORED_FILE_NAMES.has(name);
}

function siteUploadFileFromPath(file: File, path: string): SiteUploadFile {
  return {
    file,
    lastModified: file.lastModified || 0,
    path,
    size: Math.max(0, file.size),
    type: file.type || '',
  };
}

export function formatSiteUploadBytes(bytes: number): string {
  const safeBytes = Math.max(0, bytes);
  if (safeBytes < 1024) return `${safeBytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = safeBytes / 1024;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = value >= 10 || unitIndex === 0 ? 0 : 1;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
}

export function markSiteUploadFilePath(file: File, path: string): File {
  markedUploadPaths.set(file, path);
  return file;
}

export function createSiteUploadTextFile(text: string, fileName = 'paste.txt'): File {
  const type = fileName.toLowerCase().endsWith('.html') ? 'text/html' : 'text/plain';
  return markSiteUploadFilePath(new File([text], fileName, { type }), fileName);
}

function readEntryFile(entry: WebkitFileSystemFileEntry): Promise<File> {
  return new Promise((resolve, reject) => {
    entry.file(resolve, reject);
  });
}

async function readAllDirectoryEntries(entry: WebkitFileSystemDirectoryEntry): Promise<WebkitFileSystemEntry[]> {
  const reader = entry.createReader();
  const entries: WebkitFileSystemEntry[] = [];

  while (true) {
    const batch = await new Promise<WebkitFileSystemEntry[]>((resolve, reject) => {
      reader.readEntries(resolve, reject);
    });
    if (batch.length === 0) return entries;
    entries.push(...batch);
  }
}

async function collectEntryFiles(entry: WebkitFileSystemEntry, pathParts: string[]): Promise<File[]> {
  if (entry.isFile) {
    const file = await readEntryFile(entry as WebkitFileSystemFileEntry);
    return [markSiteUploadFilePath(file, [...pathParts, entry.name].join('/'))];
  }

  if (!entry.isDirectory) return [];

  const childEntries = await readAllDirectoryEntries(entry as WebkitFileSystemDirectoryEntry);
  const childFiles = await Promise.all(
    childEntries.map((childEntry) => collectEntryFiles(childEntry, [...pathParts, entry.name])),
  );
  return childFiles.flat();
}

export async function getSiteUploadFilesFromDataTransfer(dataTransfer: DataTransfer): Promise<File[]> {
  const itemFiles: File[] = [];
  const items = Array.from(dataTransfer.items ?? []) as DataTransferItemWithEntry[];

  for (const item of items) {
    if (item.kind !== 'file') continue;
    const entry = item.webkitGetAsEntry?.();
    if (entry) {
      itemFiles.push(...await collectEntryFiles(entry, []));
      continue;
    }

    const file = item.getAsFile();
    if (file) itemFiles.push(markSiteUploadFilePath(file, file.name));
  }

  if (itemFiles.length > 0) return itemFiles;
  return Array.from(dataTransfer.files ?? []).map((file) => markSiteUploadFilePath(file, file.name));
}

export function createSiteUploadDraft(files: FileList | Iterable<File>): SiteUploadDraft {
  const inputFiles = filesFromInput(files);
  const pathPartsByFile = inputFiles.map((file) => cleanPathParts(splitPath(getInputPath(file))));
  const rootName = getCommonRoot(pathPartsByFile);
  const siteFiles: SiteUploadFile[] = [];
  const usedPaths = new Set<string>();

  inputFiles.forEach((file, index) => {
    const originalParts = pathPartsByFile[index] ?? [];
    const parts = rootName ? originalParts.slice(1) : originalParts;
    const safeParts = parts.length > 0 ? parts : [file.name];
    if (isIgnoredPath(safeParts)) return;
    const path = safeParts.join('/');
    if (!path || usedPaths.has(path)) return;
    usedPaths.add(path);
    siteFiles.push(siteUploadFileFromPath(file, path));
  });

  siteFiles.sort((left, right) => left.path.localeCompare(right.path));
  if (siteFiles.length === 0) {
    throw new Error('Choose a folder with files to publish.');
  }

  const totalBytes = siteFiles.reduce((sum, file) => sum + file.size, 0);
  const firstPath = siteFiles[0]?.path ?? '';
  const indexFile = siteFiles.find((file) => file.path.toLowerCase() === 'index.html') ?? null;

  return {
    entryPath: indexFile?.path ?? firstPath,
    fileCount: siteFiles.length,
    files: siteFiles,
    hasIndexHtml: Boolean(indexFile),
    previewFiles: siteFiles.slice(0, SITE_UPLOAD_PREVIEW_LIMIT),
    rootName,
    totalBytes,
  };
}

function getPathDirectory(path: string): string {
  const parts = splitPath(path);
  parts.pop();
  return parts.join('/');
}

function normalizeUploadAssetPath(href: string, basePath: string): string | null {
  const trimmed = href.trim();
  if (!trimmed || /^(?:data|blob|https?):/i.test(trimmed)) return null;
  const withoutFragment = trimmed.split('#', 1)[0]?.split('?', 1)[0] ?? '';
  if (!withoutFragment) return null;
  const path = withoutFragment.startsWith('/')
    ? withoutFragment.slice(1)
    : [getPathDirectory(basePath), withoutFragment].filter(Boolean).join('/');
  const parts = cleanPathParts(splitPath(path));
  return parts.join('/') || null;
}

function findUploadFile(draft: SiteUploadDraft, path: string): SiteUploadFile | null {
  const normalized = cleanPathParts(splitPath(path)).join('/').toLowerCase();
  if (!normalized) return null;
  return draft.files.find((file) => file.path.toLowerCase() === normalized) ?? null;
}

function findFirstExistingUploadFile(draft: SiteUploadDraft, paths: readonly string[]): SiteUploadFile | null {
  for (const path of paths) {
    const file = findUploadFile(draft, path);
    if (file) return file;
  }
  return null;
}

function decodeHtmlText(value: string): string {
  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function extractHtmlTitle(html: string): string {
  const match = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
  return match ? decodeHtmlText(match[1] ?? '') : '';
}

function parseHtmlAttributes(source: string): Record<string, string> {
  const attributes: Record<string, string> = {};
  const attributePattern = /([^\s"'=<>`]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let match: RegExpExecArray | null;
  while ((match = attributePattern.exec(source))) {
    const name = (match[1] ?? '').toLowerCase();
    if (!name) continue;
    attributes[name] = match[2] ?? match[3] ?? match[4] ?? '';
  }
  return attributes;
}

function extractHtmlLinks(html: string): HtmlLinkMeta[] {
  const links: HtmlLinkMeta[] = [];
  const linkPattern = /<link\b([^>]*)>/gi;
  let match: RegExpExecArray | null;
  while ((match = linkPattern.exec(html))) {
    const attributes = parseHtmlAttributes(match[1] ?? '');
    if (!attributes.rel || !attributes.href) continue;
    links.push({
      href: attributes.href,
      rel: attributes.rel.toLowerCase(),
    });
  }
  return links;
}

function extensionMimeType(path: string): string {
  const lowerPath = path.toLowerCase();
  if (lowerPath.endsWith('.svg')) return 'image/svg+xml';
  if (lowerPath.endsWith('.png')) return 'image/png';
  if (lowerPath.endsWith('.jpg') || lowerPath.endsWith('.jpeg')) return 'image/jpeg';
  if (lowerPath.endsWith('.webp')) return 'image/webp';
  if (lowerPath.endsWith('.gif')) return 'image/gif';
  if (lowerPath.endsWith('.ico')) return 'image/x-icon';
  return 'application/octet-stream';
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
  }
  return btoa(binary);
}

async function readUploadText(uploadFile: SiteUploadFile | null): Promise<string> {
  if (!uploadFile) return '';
  try {
    return await uploadFile.file.text();
  } catch {
    return '';
  }
}

async function readUploadIconDataUrl(uploadFile: SiteUploadFile | null): Promise<string | undefined> {
  if (!uploadFile) return undefined;
  try {
    const bytes = new Uint8Array(await uploadFile.file.arrayBuffer());
    const mimeType = uploadFile.type || extensionMimeType(uploadFile.path);
    return `data:${mimeType};base64,${bytesToBase64(bytes)}`;
  } catch {
    return undefined;
  }
}

function getManifestName(manifest: ManifestLike): string {
  const name = typeof manifest.name === 'string' ? manifest.name.trim() : '';
  const shortName = typeof manifest.short_name === 'string' ? manifest.short_name.trim() : '';
  return name || shortName;
}

function getManifestIconArea(icon: ManifestIconLike): number {
  if (typeof icon.sizes !== 'string') return 0;
  return icon.sizes
    .split(/\s+/)
    .map((size) => {
      const match = size.match(/^(\d+)x(\d+)$/i);
      if (!match) return 0;
      return Number(match[1]) * Number(match[2]);
    })
    .reduce((max, area) => Math.max(max, area), 0);
}

function getManifestIcons(manifest: ManifestLike): ManifestIconLike[] {
  if (!Array.isArray(manifest.icons)) return [];
  return manifest.icons
    .filter((icon): icon is ManifestIconLike => Boolean(icon) && typeof icon === 'object' && typeof (icon as ManifestIconLike).src === 'string')
    .sort((left, right) => getManifestIconArea(right) - getManifestIconArea(left));
}

function parseManifestJson(text: string): ManifestLike | null {
  try {
    const parsed = JSON.parse(text) as ManifestLike;
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

async function getMetadataIconFromPaths(
  draft: SiteUploadDraft,
  iconPaths: readonly { basePath: string; href: string }[],
): Promise<{ icon?: string; iconPath?: string }> {
  for (const iconPath of iconPaths) {
    const normalizedPath = normalizeUploadAssetPath(iconPath.href, iconPath.basePath);
    const uploadFile = normalizedPath ? findUploadFile(draft, normalizedPath) : null;
    const icon = await readUploadIconDataUrl(uploadFile);
    if (icon && uploadFile) {
      return {
        icon,
        iconPath: uploadFile.path,
      };
    }
  }
  return {};
}

export async function inferSiteUploadAppMetadata(draft: SiteUploadDraft): Promise<SiteUploadAppMetadata> {
  const indexFile = findUploadFile(draft, 'index.html');
  const indexHtml = await readUploadText(indexFile);
  const htmlLinks = extractHtmlLinks(indexHtml);
  const linkedManifestPath = htmlLinks
    .find((link) => link.rel.split(/\s+/).includes('manifest'))?.href;
  const manifestFile = linkedManifestPath && indexFile
    ? findUploadFile(draft, normalizeUploadAssetPath(linkedManifestPath, indexFile.path) ?? '')
    : findFirstExistingUploadFile(draft, ['manifest.webmanifest', 'manifest.json', 'site.webmanifest']);
  const manifest = parseManifestJson(await readUploadText(manifestFile));

  if (manifest) {
    const manifestName = getManifestName(manifest);
    const manifestIcons = getManifestIcons(manifest)
      .map((icon) => ({
        basePath: manifestFile?.path ?? 'manifest.webmanifest',
        href: String(icon.src ?? ''),
      }));
    const icon = await getMetadataIconFromPaths(draft, manifestIcons);
    if (manifestName) {
      return {
        name: manifestName,
        source: 'manifest',
        ...icon,
      };
    }
  }

  const htmlTitle = extractHtmlTitle(indexHtml);
  const faviconLinks = htmlLinks
    .filter((link) => {
      const rels = link.rel.split(/\s+/);
      return rels.includes('icon') || rels.includes('shortcut') || rels.includes('apple-touch-icon');
    })
    .map((link) => ({
      basePath: indexFile?.path ?? 'index.html',
      href: link.href,
    }));
  const icon = await getMetadataIconFromPaths(draft, [
    ...faviconLinks,
    { basePath: 'index.html', href: '/favicon.svg' },
    { basePath: 'index.html', href: '/favicon.png' },
    { basePath: 'index.html', href: '/favicon.ico' },
    { basePath: 'index.html', href: '/apple-touch-icon.png' },
  ]);

  if (htmlTitle) {
    return {
      name: htmlTitle,
      source: 'html',
      ...icon,
    };
  }

  return {
    name: draft.rootName || 'App',
    source: 'folder',
    ...icon,
  };
}

function insertFile(root: DirectoryNode, uploadFile: SiteUploadFile): void {
  const parts = splitPath(uploadFile.path);
  const fileName = parts.pop();
  if (!fileName) {
    throw new Error(`Invalid file path: ${uploadFile.path}`);
  }

  let current = root;
  for (const part of parts) {
    let next = current.directories.get(part);
    if (!next) {
      next = createDirectoryNode();
      current.directories.set(part, next);
    }
    current = next;
  }

  if (current.directories.has(fileName) || current.files.has(fileName)) {
    throw new Error(`Duplicate upload path: ${uploadFile.path}`);
  }
  current.files.set(fileName, uploadFile);
}

function uploadFileMeta(uploadFile: SiteUploadFile): Record<string, unknown> | undefined {
  const meta: Record<string, unknown> = {};
  if (uploadFile.type) meta.mimeType = uploadFile.type;
  if (uploadFile.lastModified > 0) meta.lastModified = uploadFile.lastModified;
  return Object.keys(meta).length > 0 ? meta : undefined;
}

async function putUploadFile(
  tree: HashTree,
  uploadFile: SiteUploadFile,
  bytesBeforeFile: number,
  totalBytes: number,
  onProgress?: (progress: SiteUploadProgress) => void,
): Promise<BuiltDirectory> {
  const writer = tree.createStream();
  await streamUploadWithProgress(uploadFile.file, writer, {
    batchBytes: 1024 * 1024,
    onProgress(progress) {
      onProgress?.({
        current: bytesBeforeFile + progress.bytesProcessed,
        currentFile: uploadFile.path,
        label: `Preparing ${uploadFile.path}`,
        phase: 'building',
        total: totalBytes,
      });
    },
  });
  const finalized = await writer.finalize();
  writer.clear();
  return {
    cid: cid(finalized.hash, finalized.key),
    size: finalized.size,
  };
}

async function buildDirectory(
  tree: HashTree,
  node: DirectoryNode,
  draft: SiteUploadDraft,
  byteCounter: { built: number },
  onProgress?: (progress: SiteUploadProgress) => void,
): Promise<BuiltDirectory> {
  const entries: DirEntry[] = [];

  for (const [name, child] of [...node.directories.entries()].sort(([left], [right]) => left.localeCompare(right))) {
    const builtChild = await buildDirectory(tree, child, draft, byteCounter, onProgress);
    entries.push({
      name,
      cid: builtChild.cid,
      size: 0,
      type: LinkType.Dir,
    });
  }

  for (const [name, uploadFile] of [...node.files.entries()].sort(([left], [right]) => left.localeCompare(right))) {
    const builtFile = await putUploadFile(tree, uploadFile, byteCounter.built, draft.totalBytes, onProgress);
    byteCounter.built += uploadFile.size;
    entries.push({
      name,
      cid: builtFile.cid,
      size: builtFile.size,
      type: LinkType.File,
      meta: uploadFileMeta(uploadFile),
    });
  }

  const directory = await tree.putDirectory(entries);
  return {
    cid: directory.cid,
    size: directory.size,
  };
}

export async function buildSiteDirectoryTree(
  draft: SiteUploadDraft,
  onProgress?: (progress: SiteUploadProgress) => void,
): Promise<BuiltSiteTree> {
  const store = new MemoryStore();
  const tree = new HashTree({ store });
  const rootNode = createDirectoryNode();

  for (const uploadFile of draft.files) {
    insertFile(rootNode, uploadFile);
  }

  const builtRoot = await buildDirectory(tree, rootNode, draft, { built: 0 }, onProgress);
  return {
    rootCid: builtRoot.cid,
    store,
    tree,
  };
}

async function uploadBuiltSiteTreeBlocks(
  built: BuiltSiteTree,
  blossomServers: BlossomServerConfig[] | undefined,
  onProgress?: (progress: SiteUploadProgress) => void,
): Promise<void> {
  const total = built.store.size;
  let current = 0;
  let batch: RawBlockInput[] = [];
  let batchBytes = 0;
  const { putUploadBlocks } = await import('./uploadWorkerClient');

  const flush = async () => {
    if (batch.length === 0) return;
    const uploadBatch = batch;
    batch = [];
    batchBytes = 0;
    await putUploadBlocks(uploadBatch, blossomServers);
    current += uploadBatch.length;
    onProgress?.({
      current,
      label: 'Uploading hashtree blocks',
      phase: 'uploading',
      total,
    });
  };

  for await (const block of built.tree.walkBlocks(built.rootCid)) {
    batch.push({
      data: block.data,
      hashHex: toHex(block.hash),
      mimeType: 'application/octet-stream',
    });
    batchBytes += block.data.byteLength;

    if (batch.length >= UPLOAD_BLOCK_BATCH_COUNT || batchBytes >= UPLOAD_BLOCK_BATCH_BYTES) {
      await flush();
    }
  }

  await flush();
}

export async function publishSiteUploadDraft(
  draft: SiteUploadDraft,
  options: PublishSiteUploadOptions = {},
): Promise<PublishedSiteUpload> {
  const built = await buildSiteDirectoryTree(draft, options.onProgress);

  options.onProgress?.({
    current: 0,
    label: 'Uploading hashtree blocks',
    phase: 'uploading',
    total: built.store.size,
  });
  await uploadBuiltSiteTreeBlocks(
    built,
    options.blossomServers,
    options.onProgress,
  );

  options.onProgress?.({
    current: 1,
    label: 'Shared',
    phase: 'done',
    total: 1,
  });

  const immutableNhash = nhashEncode({
    hash: toHex(built.rootCid.hash),
    decryptKey: built.rootCid.key ? toHex(built.rootCid.key) : undefined,
  });
  const launcherHref = buildLauncherHref({
    kind: 'immutable',
    siteKey: 'shared-files',
    title: draft.rootName || draft.entryPath.split('/').pop() || 'Shared files',
    nhash: immutableNhash,
    entryPath: draft.entryPath || 'index.html',
  }, options.currentHost);

  return {
    immutableNhash,
    launcherHref,
  };
}
