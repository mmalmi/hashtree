import { DexieStore } from '@hashtree/dexie';
import { HashtreeWorkerClient } from '@hashtree/worker/client';
import { RelayWorkerClient } from '@hashtree/worker/relay-client';
import { generateSecretKey, getPublicKey } from 'nostr-tools/pure';
import type { NostrFilter, RuntimeQueryOptions } from 'nostr-pubsub';
import BlobWorker from '../workers/hashtree.worker.ts?worker';
import EventWorker from '../workers/publicEvents.worker.ts?worker';
import { PUBLIC_RELAY_CONFIG } from './publicRelayConfig';

export const DEFAULT_RELAYS: string[] = PUBLIC_RELAY_CONFIG.relays;
const BLOCK_STORE = 'iris-contacts-people-v1';
let runtime: ReturnType<typeof createRuntime> | null = null;

function createRuntime() {
  const storageKey = 'iris-contacts:fips-device-secret';
  let secret = localStorage.getItem(storageKey);
  if (!secret || !/^[0-9a-f]{64}$/.test(secret)) {
    secret = Array.from(generateSecretKey(), byte => byte.toString(16).padStart(2, '0')).join('');
    localStorage.setItem(storageKey, secret);
  }
  const secretBytes = Uint8Array.from(secret.match(/../g)!, byte => parseInt(byte, 16));
  // This identity belongs to the device transport, not the user's saved login.
  const events = new RelayWorkerClient(EventWorker, {
    storeName: 'iris-contacts-public-events-v1', pubkey: getPublicKey(secretBytes),
    // The account-scoped public graph has its own retained cache and catch-up.
    relays: DEFAULT_RELAYS, blossomServers: [], graphReconciliation: false,
  });
  const blobs = new HashtreeWorkerClient(BlobWorker, {
    storeName: BLOCK_STORE, storageMaxBytes: 64 * 1024 * 1024,
    relays: [], blossomServers: [{ url: 'https://cdn.iris.to', read: true, write: false }],
  });
  const ready = Promise.all([events.init(), blobs.init()]);
  const peers = ready.then(async () => {
    const { createBrowserHashtreeNostrProvider, supportsBrowserHashtreeFips } = await import('@hashtree/fips-transport/browser');
    if (!supportsBrowserHashtreeFips()) return null;
    const provider = await createBrowserHashtreeNostrProvider({
      deviceSecretKey: secret, relays: DEFAULT_RELAYS,
      websocketSeedUrls: import.meta.env.VITE_FIPS_WEBSOCKET_SEED_URLS?.split(',').filter(Boolean),
      localStore: new DexieStore(BLOCK_STORE), maxConnections: 4,
      allowedKinds: [0, 3, 30064, 30078],
    });
    blobs.setP2PProvider(provider);
    await events.setNostrSource(provider.nostrSource);
    return provider;
  }).catch(error => console.warn('Peer connections unavailable', error));
  return { events, blobs, ready, peers };
}

export async function getPublicRuntime() {
  runtime ??= createRuntime();
  await runtime.ready;
  return runtime;
}

/** Only public follow/profile/root callers use this transport; private contacts never enter it. */
export async function queryPublicEvents(filters: NostrFilter[], options: RuntimeQueryOptions = {}) {
  const { events } = await getPublicRuntime();
  return events.queryEvents(filters, { cache: 'cache-first', sources: ['fips'], ...options });
}
