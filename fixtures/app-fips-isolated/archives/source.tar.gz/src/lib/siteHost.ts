import { encryptKeyForLink, fromHex, nhashDecode, nhashEncode, toHex } from '@hashtree/core';
import { serializeHostedSiteHash, type HostedSite } from './siteConfig';
import {
  encodeImmutableHostLabel,
  encodeMutableHostLabel,
  encodePathSegments,
  normalizeHost,
} from './siteIdentity';

const PROD_PORTAL_HOST = 'apps.iris.to';
const LEGACY_PROD_PORTAL_HOST = 'sites.iris.to';
const LOCAL_PORTAL_HOST = 'sites.iris.localhost';
const LOCAL_DEV_PORTAL_HOSTS = new Set(['localhost', '127.0.0.1']);
const LOCAL_DRIVE_PORTAL_HOST = 'iris.localhost';
const LOCAL_DRIVE_GATEWAY_PORT = ':17321';
const IRIS_SITES_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const LOCAL_DRIVE_MUTABLE_PORTAL_HOST = `sites.${IRIS_SITES_OWNER}.iris.localhost`;

interface CurrentVersionLike {
  hash: Uint8Array;
  key?: Uint8Array;
  visibility?: 'public' | 'link-visible' | 'private';
  encryptedKey?: string;
  snapshotNhash?: string;
}

function resolveHostContext(currentHost?: string): {
  protocol: string;
  portalHost: string;
  runtimeSuffix: string;
  localDrivePort?: string;
  localDriveOnly?: boolean;
} {
  if (currentHost) {
    const trimmedHost = currentHost.trim();
    const normalized = normalizeHost(trimmedHost);
    if (isLocalDrivePortalHost(normalized)) {
      const port = localDriveGatewayPortSuffix(trimmedHost);
      return {
        protocol: 'http:',
        portalHost: `${LOCAL_DRIVE_MUTABLE_PORTAL_HOST}${port}`,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
        localDrivePort: port,
        localDriveOnly: true,
      };
    }
    if (normalized === LOCAL_PORTAL_HOST) {
      const port = localDriveGatewayPortSuffix(trimmedHost);
      return {
        protocol: 'http:',
        portalHost: trimmedHost,
        runtimeSuffix: trimmedHost,
        localDrivePort: port,
      };
    }
    if (isLocalDevPortalHost(normalized)) {
      const port = portSuffix(trimmedHost);
      return {
        protocol: 'http:',
        portalHost: trimmedHost,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
      };
    }
    if (normalized.endsWith(`.${LOCAL_PORTAL_HOST}`)) {
      const dotIndex = trimmedHost.indexOf('.');
      const localSuffix = dotIndex >= 0 ? trimmedHost.slice(dotIndex + 1) : LOCAL_PORTAL_HOST;
      return {
        protocol: 'http:',
        portalHost: localSuffix,
        runtimeSuffix: localSuffix,
        localDrivePort: portSuffix(trimmedHost),
      };
    }
    if (isReadableLocalIrisRuntimeHost(normalized)) {
      const port = localDriveGatewayPortSuffix(trimmedHost);
      return {
        protocol: 'http:',
        portalHost: `${LOCAL_DRIVE_MUTABLE_PORTAL_HOST}${port}`,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
        localDrivePort: port,
        localDriveOnly: true,
      };
    }
  }

  if (typeof window !== 'undefined') {
    const current = window.location.host;
    const normalized = normalizeHost(current);
    if (isLocalDrivePortalHost(normalized)) {
      const port = localDriveGatewayPortSuffix(current);
      return {
        protocol: window.location.protocol || 'http:',
        portalHost: `${LOCAL_DRIVE_MUTABLE_PORTAL_HOST}${port}`,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
        localDrivePort: port,
        localDriveOnly: true,
      };
    }
    if (normalized === LOCAL_PORTAL_HOST) {
      const port = localDriveGatewayPortSuffix(current);
      return {
        protocol: window.location.protocol || 'http:',
        portalHost: current,
        runtimeSuffix: current,
        localDrivePort: port,
      };
    }
    if (isLocalDevPortalHost(normalized)) {
      const port = portSuffix(current);
      return {
        protocol: window.location.protocol || 'http:',
        portalHost: current,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
      };
    }
    if (normalized.endsWith(`.${LOCAL_PORTAL_HOST}`)) {
      const dotIndex = current.indexOf('.');
      const localSuffix = dotIndex >= 0 ? current.slice(dotIndex + 1) : LOCAL_PORTAL_HOST;
      return {
        protocol: window.location.protocol || 'http:',
        portalHost: localSuffix,
        runtimeSuffix: localSuffix,
        localDrivePort: portSuffix(current),
      };
    }
    if (isReadableLocalIrisRuntimeHost(normalized)) {
      const port = localDriveGatewayPortSuffix(current);
      return {
        protocol: window.location.protocol || 'http:',
        portalHost: `${LOCAL_DRIVE_MUTABLE_PORTAL_HOST}${port}`,
        runtimeSuffix: `${LOCAL_PORTAL_HOST}${port}`,
        localDrivePort: port,
        localDriveOnly: true,
      };
    }
  }

  return {
    protocol: 'https:',
    portalHost: PROD_PORTAL_HOST,
    runtimeSuffix: 'hashtree.cc',
  };
}

function portSuffix(host: string): string {
  const match = host.match(/:\d+$/);
  return match ? match[0] : '';
}

function isLocalDevBuild(): boolean {
  return Boolean(import.meta.env?.DEV);
}

function localDriveGatewayPortSuffix(host: string): string {
  return isLocalDevBuild()
    ? LOCAL_DRIVE_GATEWAY_PORT
    : portSuffix(host) || LOCAL_DRIVE_GATEWAY_PORT;
}

function isLocalDrivePortalHost(host: string): boolean {
  return host === LOCAL_DRIVE_PORTAL_HOST || host === LOCAL_DRIVE_MUTABLE_PORTAL_HOST;
}

function isReadableLocalIrisRuntimeHost(host: string): boolean {
  return host.endsWith(`.${LOCAL_DRIVE_PORTAL_HOST}`)
    && !host.endsWith(`.${LOCAL_PORTAL_HOST}`)
    && !isLocalDrivePortalHost(host);
}

function isLocalIrisRuntimeHost(host: string): boolean {
  return host.endsWith(`.${LOCAL_PORTAL_HOST}`)
    || isReadableLocalIrisRuntimeHost(host);
}

function isLocalDevPortalHost(host: string): boolean {
  return LOCAL_DEV_PORTAL_HOSTS.has(host);
}

function isDnsLabel(value: string): boolean {
  return value.length > 0
    && value.length <= 63
    && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(value);
}

function splitDnsLabels(value: string): string {
  return value.match(/.{1,63}/g)?.join('.') || value;
}

function isProductionLauncherHost(currentHost?: string): boolean {
  const host = currentHost
    ?? (typeof window !== 'undefined' ? window.location.host : PROD_PORTAL_HOST);
  const normalized = normalizeHost(host);
  return normalized === PROD_PORTAL_HOST || normalized === LEGACY_PROD_PORTAL_HOST;
}

function buildLocalDriveHref(site: HostedSite, hostContext: ReturnType<typeof resolveHostContext>): string | null {
  if (hostContext.localDrivePort === undefined) return null;
  const entryPath = encodePathSegments(site.entryPath || 'index.html');
  if (site.kind === 'mutable') {
    if (!isDnsLabel(site.npub) || !isDnsLabel(site.treeName)) return null;
    return `${hostContext.protocol}//${site.treeName}.${site.npub}.iris.localhost${hostContext.localDrivePort}/${entryPath}`;
  }
  return `${hostContext.protocol}//${splitDnsLabels(site.nhash)}.iris.localhost${hostContext.localDrivePort}/${entryPath}`;
}

function serializeRuntimeHash(site: HostedSite): string {
  const entryPath = encodePathSegments(site.entryPath || 'index.html');
  if (site.kind === 'immutable') {
    const params = new URLSearchParams();
    if (site.snapshot) {
      params.set('snapshot', '1');
      if (site.snapshotLinkKey) {
        params.set('k', site.snapshotLinkKey);
      }
    } else {
      const cid = nhashDecode(site.nhash);
      if (cid.key) {
        params.set('k', toHex(cid.key));
      }
    }
    const query = params.toString();
    return `#/${entryPath}${query ? `?${query}` : ''}`;
  }
  return `#/${site.npub}/${encodeURIComponent(site.treeName)}/${entryPath}`;
}

function buildRuntimeHostPrefix(site: HostedSite): string {
  if (site.kind === 'immutable') {
    return encodeImmutableHostLabel(nhashDecode(site.nhash).hash);
  }

  return encodeMutableHostLabel(site.npub, site.treeName);
}

export function isPortalShellHost(host: string): boolean {
  const normalized = normalizeHost(host);
  return normalized === PROD_PORTAL_HOST
    || normalized === LEGACY_PROD_PORTAL_HOST
    || normalized === LOCAL_PORTAL_HOST
    || isLocalDevPortalHost(normalized)
    || isLocalDrivePortalHost(normalized);
}

export function isLocalDevShellHost(host: string): boolean {
  return isLocalDevPortalHost(normalizeHost(host));
}

export function shouldRedirectPortalShellHost(host: string): boolean {
  const normalized = normalizeHost(host);
  return isPortalShellHost(normalized) && !isLocalDevPortalHost(normalized);
}

export function shouldShowRuntimeMenuForHost(host: string): boolean {
  const normalized = normalizeHost(host);
  if (!normalized || isPortalShellHost(normalized)) {
    return false;
  }
  return !isLocalIrisRuntimeHost(normalized);
}

export function isIrisLocalhostHost(host: string): boolean {
  const normalized = normalizeHost(host);
  return normalized === LOCAL_DRIVE_PORTAL_HOST
    || normalized.endsWith(`.${LOCAL_DRIVE_PORTAL_HOST}`);
}

export function shouldShowIrisDriveDownloadPrompt(currentHost?: string): boolean {
  const host = currentHost
    ?? (typeof window !== 'undefined' ? window.location.host : '');
  return !isIrisLocalhostHost(host);
}

export async function buildIsolatedSiteHref(site: HostedSite, currentHost?: string): Promise<string> {
  if (currentHost && isLocalDevShellHost(currentHost)) {
    return buildLauncherHref(site, currentHost);
  }
  const hostContext = resolveHostContext(currentHost);
  const localDriveHref = buildLocalDriveHref(site, hostContext);
  if (localDriveHref) {
    return localDriveHref;
  }
  if (hostContext.localDriveOnly) {
    throw new Error('This local Iris Drive site cannot be opened through the Iris Sites runtime shell.');
  }
  const runtimeHostPrefix = buildRuntimeHostPrefix(site);
  return `${hostContext.protocol}//${runtimeHostPrefix}.${hostContext.runtimeSuffix}/${serializeRuntimeHash(site)}`;
}

export function buildLauncherHref(site: HostedSite, currentHost?: string): string {
  const hostContext = resolveHostContext(currentHost);
  return `${hostContext.protocol}//${hostContext.portalHost}/${serializeHostedSiteHash(site)}`;
}

export function buildSitesHomeHref(currentHost?: string): string {
  const hostContext = resolveHostContext(currentHost);
  return `${hostContext.protocol}//${hostContext.portalHost}/`;
}

export function buildSuggestedAppHref(site: HostedSite, currentHost?: string, primaryHost?: string): string {
  const hostContext = resolveHostContext(currentHost);
  const localDriveHref = buildLocalDriveHref(site, hostContext);
  if (localDriveHref) {
    return localDriveHref;
  }
  if (primaryHost && isProductionLauncherHost(currentHost)) {
    return `https://${primaryHost}/`;
  }
  return `${hostContext.protocol}//${hostContext.portalHost}/${serializeHostedSiteHash(site)}`;
}

export function buildSourceHref(site: HostedSite, currentHost?: string): string {
  return buildIrisFilesAppHref(currentHost);
}

export function buildIrisFilesAppHref(currentHost?: string): string {
  return buildSuggestedAppHref({
    kind: 'mutable',
    siteKey: 'iris-drive',
    title: 'drive',
    npub: IRIS_SITES_OWNER,
    treeName: 'drive',
    entryPath: 'index.html',
  }, currentHost, 'drive.iris.to');
}

export function buildIrisDriveDownloadHref(currentHost?: string): string {
  return buildSuggestedAppHref({
    kind: 'mutable',
    siteKey: 'irisdrive-org-site',
    title: 'Iris Drive',
    npub: IRIS_SITES_OWNER,
    treeName: 'irisdrive-org-site',
    entryPath: 'index.html',
  }, currentHost, 'getdrive.iris.to');
}

export function buildIrisGitAppHref(currentHost?: string): string {
  return buildSuggestedAppHref({
    kind: 'mutable',
    siteKey: 'iris-git',
    title: 'git',
    npub: IRIS_SITES_OWNER,
    treeName: 'git',
    entryPath: 'index.html',
  }, currentHost, 'git.iris.to');
}

export function buildHashtreeInstallOptionsHref(currentHost?: string): string {
  return `${buildIrisGitAppHref(currentHost)}#/${IRIS_SITES_OWNER}/hashtree`;
}

export function buildPermalinkHref(
  site: HostedSite,
  currentVersion?: CurrentVersionLike,
  currentHost?: string,
): string | null {
  if (site.kind === 'immutable') {
    return buildLauncherHref(site, currentHost);
  }

  if (!currentVersion) {
    return null;
  }

  const snapshotLinkKey = deriveSnapshotLinkKey(currentVersion);
  if (
    currentVersion.snapshotNhash &&
    (currentVersion.visibility !== 'link-visible' || snapshotLinkKey)
  ) {
    return buildLauncherHref({
      kind: 'immutable',
      siteKey: site.siteKey,
      title: site.title,
      entryPath: site.entryPath,
      nhash: currentVersion.snapshotNhash,
      snapshot: true,
      snapshotLinkKey: snapshotLinkKey || undefined,
    }, currentHost);
  }

  const immutableSite: HostedSite = {
    kind: 'immutable',
    siteKey: site.siteKey,
    title: site.title,
    entryPath: site.entryPath,
    nhash: nhashEncode({
      hash: toHex(currentVersion.hash),
      decryptKey: currentVersion.key ? toHex(currentVersion.key) : undefined,
    }),
  };

  return buildLauncherHref(immutableSite, currentHost);
}

function deriveSnapshotLinkKey(currentVersion: CurrentVersionLike): string | null {
  if (currentVersion.visibility !== 'link-visible') {
    return null;
  }
  if (!currentVersion.key || !currentVersion.encryptedKey) {
    return null;
  }

  try {
    return toHex(encryptKeyForLink(currentVersion.key, fromHex(currentVersion.encryptedKey)));
  } catch {
    return null;
  }
}
