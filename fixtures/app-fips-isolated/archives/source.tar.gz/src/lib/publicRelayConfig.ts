export const DEFAULT_PUBLIC_RELAYS = [
  'wss://relay.ditto.pub', 'wss://relay.damus.io', 'wss://nos.lol',
  'wss://relay.primal.net', 'wss://relay.nostr.band',
];

export function resolvePublicRelayConfig(value: string | undefined) {
  return {
    relays: value === undefined ? [...DEFAULT_PUBLIC_RELAYS] : value.split(',').filter(Boolean),
    useDefaultBootstrap: value === undefined,
  };
}

export const PUBLIC_RELAY_CONFIG = resolvePublicRelayConfig(import.meta.env.VITE_NOSTR_RELAYS);
