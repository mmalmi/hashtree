import { isNip05, queryProfile } from 'nostr-tools/nip05';
import { isHexPubkey } from './contacts';

export function normalizeNip05Identifier(value: string | null | undefined): string | null {
  const trimmed = value?.trim().toLowerCase() ?? '';
  return trimmed && isNip05(trimmed) ? trimmed : null;
}

export async function verifyNip05Identifier(pubkey: string, identifier: string): Promise<boolean> {
  const normalizedPubkey = pubkey.trim().toLowerCase();
  const normalizedIdentifier = normalizeNip05Identifier(identifier);
  if (!isHexPubkey(normalizedPubkey) || !normalizedIdentifier) return false;

  const profile = await queryProfile(normalizedIdentifier);
  return profile?.pubkey?.toLowerCase() === normalizedPubkey;
}
