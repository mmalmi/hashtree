import {
  decodeProfileInput,
  isContactIdentityId,
  pubkeyToNpub,
  type ContactRecord,
} from './contacts';

export type ContactRoute =
  | { kind: 'home'; canonicalPath: '/' }
  | { kind: 'create'; canonicalPath: '/new' }
  | { kind: 'settings'; canonicalPath: '/settings' }
  | {
      kind: 'profile';
      pubkey: string;
      npub: string;
      canonicalPath: string;
      isAlias: boolean;
    }
  | {
      kind: 'contact';
      id: string;
      canonicalPath: string;
      isAlias: boolean;
    }
  | { kind: 'unknown'; value: string; canonicalPath: '/' };

const ALIAS_SEGMENTS = new Set(['contact', 'profile']);

export function parseContactRoute(pathname: string): ContactRoute {
  const segments = routeSegments(pathname);
  if (segments.length === 0) return { kind: 'home', canonicalPath: '/' };
  if (segments.length === 1 && segments[0].toLowerCase() === 'new') {
    return { kind: 'create', canonicalPath: '/new' };
  }
  if (segments.length === 1 && segments[0].toLowerCase() === 'settings') {
    return { kind: 'settings', canonicalPath: '/settings' };
  }

  const firstSegment = segments[0].toLowerCase();
  const isAlias = ALIAS_SEGMENTS.has(firstSegment);
  const target = isAlias ? segments[1] : segments[0];
  if (!target || (isAlias && segments.length !== 2) || (!isAlias && segments.length !== 1)) {
    return { kind: 'unknown', value: segments.join('/'), canonicalPath: '/' };
  }

  const pubkey = decodeProfileInput(target);
  if (pubkey) {
    const npub = pubkeyToNpub(pubkey);
    return {
      kind: 'profile',
      pubkey,
      npub,
      canonicalPath: `/${npub}`,
      isAlias: isAlias || target !== npub,
    };
  }

  if (isContactIdentityId(target)) {
    const id = target.toLowerCase();
    return {
      kind: 'contact',
      id,
      canonicalPath: `/${id}`,
      isAlias,
    };
  }

  return { kind: 'unknown', value: segments.join('/'), canonicalPath: '/' };
}

export function contactPathFor(contact: ContactRecord): string {
  if (isContactIdentityId(contact.identity.id)) return `/${contact.identity.id.toLowerCase()}`;
  if (isContactIdentityId(contact.id)) return `/${contact.id.toLowerCase()}`;
  if (contact.pubkey) return `/${pubkeyToNpub(contact.pubkey)}`;
  return `/${contact.id}`;
}

function routeSegments(pathname: string): string[] {
  return pathname
    .split('/')
    .map((segment) => safeDecode(segment.trim()))
    .filter(Boolean);
}

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}
