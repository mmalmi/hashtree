import { registerSW } from 'virtual:pwa-register';

const SW_RELOAD_KEY = 'iris-sites-sw-reload-at';
const SW_RELOAD_DEDUP_MS = 5_000;
const SW_TEST_STATE_KEY = 'iris-sites-test-sw-state';

function shouldReloadForControllerChange(): boolean {
  const now = Date.now();
  const lastReloadAt = Number(sessionStorage.getItem(SW_RELOAD_KEY) || '0');
  if (Number.isFinite(lastReloadAt) && now - lastReloadAt < SW_RELOAD_DEDUP_MS) {
    return false;
  }
  sessionStorage.setItem(SW_RELOAD_KEY, String(now));
  return true;
}

export async function initServiceWorker(): Promise<void> {
  const isTestMode = !!import.meta.env.VITE_TEST_MODE;
  const isDevMode = !!import.meta.env.DEV;

  if (!('serviceWorker' in navigator)) {
    return;
  }

  if (isTestMode && !sessionStorage.getItem(SW_TEST_STATE_KEY)) {
    sessionStorage.setItem(SW_TEST_STATE_KEY, 'cleaned');
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map((registration) => registration.unregister().catch(() => {})));
    } catch {
      // Ignore cleanup failures in tests.
    }
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key).catch(() => {})));
    } catch {
      // Ignore cleanup failures in tests.
    }
  }

  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      if (!isTestMode) {
        updateSW(true);
      }
    },
    onRegisterError(error) {
      console.warn('[iris-sites] Service worker registration failed', error);
    },
  });

  if (isDevMode) {
    const devRegistration = await navigator.serviceWorker.register('/dev-sw.js?dev-sw', {
      scope: '/',
      type: 'module',
      updateViaCache: 'none',
    });
    await devRegistration.update().catch(() => {});
  }

  if (!navigator.serviceWorker.controller) {
    const ready = await Promise.race([
      navigator.serviceWorker.ready,
      new Promise<ServiceWorkerRegistration | null>((resolve) => setTimeout(() => resolve(null), 2000)),
    ]);

    if (!ready && isDevMode) {
      await navigator.serviceWorker.register('/dev-sw.js?dev-sw', {
        scope: '/',
        type: 'module',
        updateViaCache: 'none',
      });
      await navigator.serviceWorker.ready;
    }

    if (!navigator.serviceWorker.controller) {
      const gotController = await Promise.race([
        new Promise<boolean>((resolve) => {
          navigator.serviceWorker.addEventListener('controllerchange', () => resolve(true), { once: true });
        }),
        new Promise<boolean>((resolve) => setTimeout(() => resolve(false), 150)),
      ]);

      if (!gotController && !navigator.serviceWorker.controller) {
        window.location.reload();
        return new Promise(() => {});
      }
    }
  }

  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (shouldReloadForControllerChange()) {
      if (!isTestMode) {
        window.location.reload();
      }
    }
  }, { once: true });

  if (isTestMode) {
    sessionStorage.setItem(SW_TEST_STATE_KEY, 'ready');
  }
}
