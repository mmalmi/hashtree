const DISTRIBUTED_APP_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const GIT_WEB_APP_URL = 'https://git.iris.to';

export function getCanonicalGitRepositoryUrl(repoPath = 'iris-contacts'): string {
  const normalizedPath = repoPath
    .split('/')
    .map((segment) => segment.trim())
    .filter(Boolean)
    .join('/');
  const baseUrl = `${GIT_WEB_APP_URL}/#/${DISTRIBUTED_APP_OWNER}`;
  return normalizedPath ? `${baseUrl}/${normalizedPath}` : baseUrl;
}

export const IRIS_CONTACTS_REPOSITORY_URL = getCanonicalGitRepositoryUrl('iris-contacts');
