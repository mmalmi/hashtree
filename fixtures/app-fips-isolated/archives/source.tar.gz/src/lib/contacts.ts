import { nip19 } from 'nostr-tools';
import { SocialGraph } from 'nostr-social-graph';
import type { Event } from 'nostr-tools/core';

export const KIND_PROFILE = 0;
export const KIND_CONTACTS = 3;
export const PRIVATE_CONTACTS_STORAGE_KEY = 'iris-contacts:private:v1';

export type ContactSource = 'public' | 'private';
export type ContactIdentityAttributeType = 'name' | 'handle' | 'nostr_pubkey' | 'npub' | 'picture';

export interface ContactIdentityAttribute {
  type: ContactIdentityAttributeType;
  value: string;
  source: ContactSource;
  active: boolean;
  addedAt: number;
  label?: string;
}

// Identity is the UUID-backed person/entity. Nostr keys and handles are facets
// attached to it, not the primary identity.
export interface ContactIdentity {
  id: string;
  createdAt: number;
  updatedAt: number;
  attrs: ContactIdentityAttribute[];
}

export interface ContactSocialGraph {
  getFollowDistance(pubkey: string): number;
  followedByFriendsCount(pubkey: string): number;
}

export interface ProfileRecord {
  pubkey: string;
  name: string;
  displayName: string;
  username: string;
  nickname: string;
  about: string;
  picture: string;
  nip05: string;
  website: string;
  lud16: string;
}

export interface ContactRecord {
  id: string;
  identity: ContactIdentity;
  pubkey: string | null;
  npub: string | null;
  name: string;
  handle: string;
  email: string;
  phone: string;
  company: string;
  jobTitle: string;
  address: string;
  birthday: string;
  picture: string;
  about: string;
  source: ContactSource;
  groups: string[];
  notes: string;
  followDistance: number | null;
  followedByFriends: number;
  updatedAt: number;
}

export interface ContactsImport {
  version: 1;
  exportedAt: string;
  contacts: ContactRecord[];
}

export function isHexPubkey(value: string): boolean {
  return /^[0-9a-f]{64}$/i.test(value.trim());
}

export function pubkeyToNpub(pubkey: string): string {
  return nip19.npubEncode(pubkey.toLowerCase());
}

export function decodeProfileInput(value: string): string | null {
  const trimmed = value.trim();
  if (isHexPubkey(trimmed)) return trimmed.toLowerCase();

  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return decoded.data.toLowerCase();
    }
    if (decoded.type === 'nprofile' && decoded.data?.pubkey) {
      return decoded.data.pubkey.toLowerCase();
    }
  } catch {
    return null;
  }

  return null;
}

export function decodeNpubInput(value: string): string | null {
  const trimmed = value.trim();
  try {
    const decoded = nip19.decode(trimmed);
    if (decoded.type === 'npub' && typeof decoded.data === 'string') {
      return decoded.data.toLowerCase();
    }
  } catch {
    return null;
  }
  return null;
}

export function isContactIdentityId(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value.trim());
}

export function createContactIdentityId(): string {
  const cryptoApi = globalThis.crypto;
  if (cryptoApi && typeof cryptoApi.randomUUID === 'function') {
    return cryptoApi.randomUUID();
  }

  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = Math.floor(Math.random() * 16);
    const value = char === 'x' ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
}

export function contactIdentityIdForPubkey(pubkey: string): string | null {
  if (!isHexPubkey(pubkey)) return null;
  const chars = pubkey.trim().toLowerCase().slice(0, 32).split('');
  chars[12] = '4';
  chars[16] = ((Number.parseInt(chars[16] ?? '0', 16) & 0x3) | 0x8).toString(16);
  return [
    chars.slice(0, 8).join(''),
    chars.slice(8, 12).join(''),
    chars.slice(12, 16).join(''),
    chars.slice(16, 20).join(''),
    chars.slice(20, 32).join(''),
  ].join('-');
}

export function parseProfileEvent(event: Event | null | undefined): ProfileRecord | null {
  if (!event || event.kind !== KIND_PROFILE || !isHexPubkey(event.pubkey)) return null;

  try {
    const content = JSON.parse(event.content || '{}') as Record<string, unknown>;
    const name = readString(content.name);
    const displayName = readString(content.display_name) || readString(content.displayName);
    const username = readString(content.username);
    const nickname = readString(content.nickname);
    const nip05 = readString(content.nip05);
    const website = readString(content.website);
    const lud16 = readString(content.lud16);
    const lud06 = readString(content.lud06);

    return {
      pubkey: event.pubkey.toLowerCase(),
      name,
      displayName,
      username,
      nickname,
      about: readString(content.about),
      picture: readString(content.picture),
      nip05,
      website,
      lud16: lud16 || lud06,
    };
  } catch {
    return {
      pubkey: event.pubkey.toLowerCase(),
      name: '',
      displayName: '',
      username: '',
      nickname: '',
      about: '',
      picture: '',
      nip05: '',
      website: '',
      lud16: '',
    };
  }
}

export function parseFollowTags(event: Event | null | undefined): string[] {
  if (!event || event.kind !== KIND_CONTACTS) return [];
  const seen = new Set<string>();

  for (const tag of event.tags) {
    if (tag[0] !== 'p' || !isHexPubkey(tag[1])) continue;
    seen.add(tag[1].toLowerCase());
  }

  return [...seen];
}

export function buildPublicContacts(
  ownerPubkey: string,
  followEvent: Event | null,
  profileEvents: readonly Event[],
): ContactRecord[] {
  const profileByPubkey = new Map<string, ProfileRecord>();
  for (const event of profileEvents) {
    const profile = parseProfileEvent(event);
    if (profile) profileByPubkey.set(profile.pubkey, profile);
  }

  const graph = new SocialGraph(ownerPubkey);
  if (followEvent) {
    graph.handleEvent(followEvent, true);
  }

  return parseFollowTags(followEvent)
    .map((pubkey) => profileToContact(pubkey, profileByPubkey.get(pubkey), graph))
    .sort(compareContacts);
}

export function profileToContact(
  pubkey: string,
  profile: ProfileRecord | undefined,
  graph: ContactSocialGraph | null,
): ContactRecord {
  const now = Date.now();
  const name = contactName(pubkey, profile);
  const npub = pubkeyToNpub(pubkey);
  const handle = profile?.nip05 || profile?.lud16 || npub;
  const rawFollowDistance = graph ? graph.getFollowDistance(pubkey) : null;
  const followDistance = rawFollowDistance !== null && rawFollowDistance < 1000 ? rawFollowDistance : null;
  const identity = createContactIdentity(identityAttrsForContact({
    source: 'public',
    now,
    name,
    handle,
    pubkey,
    npub,
    picture: profile?.picture,
  }), now, contactIdentityIdForPubkey(pubkey) ?? undefined);
  return {
    id: identity.id,
    identity,
    pubkey,
    npub,
    name,
    handle,
    email: '',
    phone: '',
    company: '',
    jobTitle: '',
    address: '',
    birthday: '',
    picture: profile?.picture ?? '',
    about: profile?.about ?? '',
    source: 'public',
    groups: [],
    notes: '',
    followDistance,
    followedByFriends: graph ? graph.followedByFriendsCount(pubkey) : 0,
    updatedAt: now,
  };
}

export function createPrivateContact(input: {
  name: string;
  handle?: string;
  email?: string;
  phone?: string;
  company?: string;
  jobTitle?: string;
  address?: string;
  birthday?: string;
  notes?: string;
  groups?: string[];
  pubkey?: string | null;
}): ContactRecord {
  const pubkey = input.pubkey && isHexPubkey(input.pubkey) ? input.pubkey.toLowerCase() : null;
  const now = Date.now();
  const npub = pubkey ? pubkeyToNpub(pubkey) : null;
  const email = readString(input.email);
  const phone = readString(input.phone);
  const company = readString(input.company);
  const jobTitle = readString(input.jobTitle);
  const address = readString(input.address);
  const birthday = readString(input.birthday);
  const handle = input.handle?.trim() || email || phone || '';
  const name = input.name.trim() || email || phone || handle || 'Private contact';
  const identity = createContactIdentity(identityAttrsForContact({
    source: 'private',
    now,
    name,
    handle,
    pubkey,
    npub,
  }), now);
  return {
    id: identity.id,
    identity,
    pubkey,
    npub,
    name,
    handle,
    email,
    phone,
    company,
    jobTitle,
    address,
    birthday,
    picture: '',
    about: '',
    source: 'private',
    groups: normalizeGroups(input.groups ?? []),
    notes: input.notes ?? '',
    followDistance: null,
    followedByFriends: 0,
    updatedAt: now,
  };
}

export function searchContacts(contacts: readonly ContactRecord[], query: string): ContactRecord[] {
  const decodedPubkey = decodeProfileInput(query);
  if (decodedPubkey) {
    const npub = pubkeyToNpub(decodedPubkey);
    const exactMatches = contacts.filter((contact) => (
      contact.pubkey === decodedPubkey ||
      contact.npub === npub ||
      contact.identity.attrs.some((attr) => attr.value === decodedPubkey || attr.value === npub)
    ));
    if (exactMatches.length > 0) return exactMatches.sort(compareContacts);
  }

  const terms = normalizeSearch(query).split(/\s+/).filter(Boolean);
  if (terms.length === 0) return [...contacts].sort(compareContacts);

  return contacts
    .map((contact) => ({
      contact,
      score: scoreContact(contact, terms),
    }))
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score || compareContacts(a.contact, b.contact))
    .map((entry) => entry.contact);
}

export function mergeContacts(
  publicContacts: readonly ContactRecord[],
  privateContacts: readonly ContactRecord[],
): ContactRecord[] {
  const byPublicKey = new Map<string, number>();
  const merged: ContactRecord[] = publicContacts.map((contact, index) => {
    if (contact.pubkey) byPublicKey.set(contact.pubkey, index);
    return cloneContact(contact);
  });

  for (const privateContact of privateContacts) {
    if (privateContact.pubkey && byPublicKey.has(privateContact.pubkey)) {
      const publicIndex = byPublicKey.get(privateContact.pubkey)!;
      const publicContact = merged[publicIndex];
      const identity = mergeContactIdentities(privateContact.identity, publicContact.identity);
      merged[publicIndex] = {
        ...publicContact,
        id: identity.id,
        identity,
        source: 'private' as const,
        groups: normalizeGroups([...publicContact.groups, ...privateContact.groups]),
        notes: privateContact.notes,
        about: publicContact.about || privateContact.about,
        name: privateContact.name || publicContact.name,
        handle: privateContact.handle || publicContact.handle,
        email: privateContact.email || publicContact.email,
        phone: privateContact.phone || publicContact.phone,
        company: privateContact.company || publicContact.company,
        jobTitle: privateContact.jobTitle || publicContact.jobTitle,
        address: privateContact.address || publicContact.address,
        birthday: privateContact.birthday || publicContact.birthday,
        updatedAt: Math.max(publicContact.updatedAt, privateContact.updatedAt),
      };
    } else {
      merged.push(cloneContact(privateContact));
    }
  }

  return merged.sort(compareContacts);
}

export function serializePrivateContacts(contacts: readonly ContactRecord[]): string {
  const payload: ContactsImport = {
    version: 1,
    exportedAt: new Date().toISOString(),
    contacts: contacts.filter((contact) => contact.source === 'private'),
  };
  return JSON.stringify(payload, null, 2);
}

export function parsePrivateContactsExport(value: string): ContactRecord[] {
  const parsed = JSON.parse(value) as Partial<ContactsImport>;
  if (parsed.version !== 1 || !Array.isArray(parsed.contacts)) {
    throw new Error('Unsupported contacts export');
  }

  return parsed.contacts.flatMap((contact) => {
    const normalized = normalizeStoredContact(contact);
    return normalized ? [normalized] : [];
  });
}

export function compareContacts(a: ContactRecord, b: ContactRecord): number {
  if (a.source !== b.source) {
    return a.source === 'private' ? -1 : 1;
  }
  const distanceA = a.followDistance ?? 999;
  const distanceB = b.followDistance ?? 999;
  if (distanceA !== distanceB) return distanceA - distanceB;
  if (a.followedByFriends !== b.followedByFriends) return b.followedByFriends - a.followedByFriends;
  return a.name.localeCompare(b.name);
}

function contactName(pubkey: string, profile: ProfileRecord | undefined): string {
  const name = profile?.displayName || profile?.name || profile?.username || profile?.nickname || profile?.nip05;
  return name?.trim() || 'Public contact';
}

function normalizeStoredContact(value: unknown): ContactRecord | null {
  if (!value || typeof value !== 'object') return null;
  const contact = value as Partial<ContactRecord>;
  if (typeof contact.name !== 'string') return null;
  const source: ContactSource = 'private';
  const updatedAt = typeof contact.updatedAt === 'number' ? contact.updatedAt : Date.now();
  const pubkey = typeof contact.pubkey === 'string' && isHexPubkey(contact.pubkey) ? contact.pubkey.toLowerCase() : null;
  const npub = pubkey ? pubkeyToNpub(pubkey) : typeof contact.npub === 'string' ? contact.npub : null;
  const name = contact.name.trim() || 'Private contact';
  const handle = typeof contact.handle === 'string' ? contact.handle : '';
  const email = readString(contact.email);
  const phone = readString(contact.phone);
  const company = readString(contact.company);
  const jobTitle = readString(contact.jobTitle);
  const address = readString(contact.address);
  const birthday = readString(contact.birthday);
  const picture = typeof contact.picture === 'string' ? contact.picture : '';
  const about = readString(contact.about);
  const identity = normalizeContactIdentity(
    contact.identity,
    typeof contact.id === 'string' ? contact.id : undefined,
    source,
    updatedAt,
    { name, handle, pubkey, npub, picture },
  );
  return {
    id: identity.id,
    identity,
    pubkey,
    npub,
    name,
    handle,
    email,
    phone,
    company,
    jobTitle,
    address,
    birthday,
    picture,
    about,
    source,
    groups: normalizeGroups(Array.isArray(contact.groups) ? contact.groups : []),
    notes: typeof contact.notes === 'string' ? contact.notes : '',
    followDistance: null,
    followedByFriends: 0,
    updatedAt,
  };
}

function createContactIdentity(
  attrs: readonly ContactIdentityAttribute[],
  now: number,
  id = createContactIdentityId(),
): ContactIdentity {
  return {
    id,
    createdAt: now,
    updatedAt: now,
    attrs: normalizeIdentityAttrs(attrs, now),
  };
}

function mergeContactIdentities(primary: ContactIdentity, secondary: ContactIdentity): ContactIdentity {
  const updatedAt = Math.max(primary.updatedAt, secondary.updatedAt);
  return {
    id: primary.id,
    createdAt: Math.min(primary.createdAt, secondary.createdAt),
    updatedAt,
    attrs: normalizeIdentityAttrs([...primary.attrs, ...secondary.attrs], updatedAt),
  };
}

function cloneContact(contact: ContactRecord): ContactRecord {
  return {
    ...contact,
    groups: [...contact.groups],
    identity: {
      ...contact.identity,
      attrs: contact.identity.attrs.map((attr) => ({ ...attr })),
    },
  };
}

function normalizeContactIdentity(
  value: unknown,
  candidateId: string | undefined,
  source: ContactSource,
  now: number,
  projection: ContactIdentityAttrInput,
): ContactIdentity {
  const identity = value && typeof value === 'object' ? value as Partial<ContactIdentity> : {};
  const rawId = typeof identity.id === 'string' ? identity.id : candidateId;
  const id = rawId && isContactIdentityId(rawId) ? rawId.toLowerCase() : createContactIdentityId();
  const createdAt = typeof identity.createdAt === 'number' ? identity.createdAt : now;
  const updatedAt = typeof identity.updatedAt === 'number' ? identity.updatedAt : now;
  const attrs = [
    ...(Array.isArray(identity.attrs) ? identity.attrs : []),
    ...identityAttrsForContact({ source, now, ...projection }),
  ];

  return {
    id,
    createdAt,
    updatedAt: Math.max(updatedAt, now),
    attrs: normalizeIdentityAttrs(attrs, now),
  };
}

interface ContactIdentityAttrInput {
  name?: string;
  handle?: string;
  pubkey?: string | null;
  npub?: string | null;
  picture?: string | null;
}

function identityAttrsForContact(input: ContactIdentityAttrInput & {
  source: ContactSource;
  now: number;
}): ContactIdentityAttribute[] {
  return [
    identityAttr('name', input.name, input.source, input.now),
    identityAttr('handle', input.handle, input.source, input.now),
    identityAttr('nostr_pubkey', input.pubkey, input.source, input.now),
    identityAttr('npub', input.npub, input.source, input.now),
    identityAttr('picture', input.picture, input.source, input.now),
  ].filter((attr): attr is ContactIdentityAttribute => Boolean(attr));
}

function identityAttr(
  type: ContactIdentityAttributeType,
  value: string | null | undefined,
  source: ContactSource,
  addedAt: number,
): ContactIdentityAttribute | null {
  const normalized = normalizeIdentityAttributeValue(type, value);
  if (!normalized) return null;
  return { type, value: normalized, source, active: true, addedAt };
}

function normalizeIdentityAttrs(attrs: readonly unknown[], fallbackAddedAt: number): ContactIdentityAttribute[] {
  const normalized: ContactIdentityAttribute[] = [];
  const seen = new Set<string>();

  for (const value of attrs) {
    if (!value || typeof value !== 'object') continue;
    const attr = value as Partial<ContactIdentityAttribute>;
    const type = normalizeIdentityAttributeType(attr.type);
    const source = normalizeContactSource(attr.source);
    const attrValue = normalizeIdentityAttributeValue(type, attr.value);
    if (!type || !source || !attrValue) continue;

    const key = `${type}\0${identityAttrKeyValue(type, attrValue)}`;
    if (seen.has(key)) continue;
    seen.add(key);

    const label = typeof attr.label === 'string' ? attr.label.trim() : '';
    const normalizedAttr: ContactIdentityAttribute = {
      type,
      value: attrValue,
      source,
      active: typeof attr.active === 'boolean' ? attr.active : true,
      addedAt: typeof attr.addedAt === 'number' ? attr.addedAt : fallbackAddedAt,
    };
    if (label) normalizedAttr.label = label;
    normalized.push(normalizedAttr);
  }

  return normalized;
}

function normalizeIdentityAttributeType(value: unknown): ContactIdentityAttributeType | null {
  if (
    value === 'name' ||
    value === 'handle' ||
    value === 'nostr_pubkey' ||
    value === 'npub' ||
    value === 'picture'
  ) {
    return value;
  }
  return null;
}

function normalizeContactSource(value: unknown): ContactSource | null {
  if (value === 'public' || value === 'private') return value;
  return null;
}

function normalizeIdentityAttributeValue(
  type: ContactIdentityAttributeType | null,
  value: unknown,
): string | null {
  if (!type || typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (type === 'nostr_pubkey') {
    return isHexPubkey(trimmed) ? trimmed.toLowerCase() : null;
  }
  return trimmed;
}

function identityAttrKeyValue(type: ContactIdentityAttributeType, value: string): string {
  if (type === 'picture') return value;
  return value.toLowerCase();
}

function scoreContact(contact: ContactRecord, terms: readonly string[]): number {
  const haystack = normalizeSearch([
    contact.name,
    contact.id,
    contact.identity.id,
    contact.pubkey,
    contact.handle,
    contact.email,
    contact.phone,
    contact.company,
    contact.jobTitle,
    contact.address,
    contact.birthday,
    contact.npub,
    contact.about,
    contact.notes,
    ...contact.groups,
    ...contact.identity.attrs.map((attr) => attr.value),
  ].join(' '));
  let score = 0;

  for (const term of terms) {
    if (!haystack.includes(term)) return 0;
    if (normalizeSearch(contact.name).startsWith(term)) score += 5;
    else if (normalizeSearch(contact.handle).startsWith(term)) score += 3;
    else score += 1;
  }

  if (contact.source === 'private') score += 1;
  if (contact.followDistance === 1) score += 1;
  return score;
}

function readString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function normalizeSearch(value: string): string {
  return value.trim().toLowerCase();
}

function normalizeGroups(groups: readonly unknown[]): string[] {
  return [...new Set(groups
    .filter((group): group is string => typeof group === 'string')
    .map((group) => group.trim())
    .filter(Boolean))];
}
