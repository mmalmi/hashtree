const CLIENT_KEY_STORAGE = 'iris-sites-media-client-key';

let mediaClientKey = '';

function generateClientKey(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

function ensureClientKey(): string {
  if (mediaClientKey) return mediaClientKey;

  try {
    const existing = sessionStorage.getItem(CLIENT_KEY_STORAGE);
    if (existing) {
      mediaClientKey = existing;
      return mediaClientKey;
    }
  } catch {
    // Ignore sessionStorage failures.
  }

  mediaClientKey = generateClientKey();
  try {
    sessionStorage.setItem(CLIENT_KEY_STORAGE, mediaClientKey);
  } catch {
    // Ignore sessionStorage failures.
  }
  return mediaClientKey;
}

export function getMediaClientKey(): string {
  return ensureClientKey();
}
