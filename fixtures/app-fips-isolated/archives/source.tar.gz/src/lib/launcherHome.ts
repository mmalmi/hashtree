import {
  launcherSuggestions,
  type LauncherSuggestion,
} from './launcherContent';
import type { HostedSite } from './siteConfig';

export const LAUNCHER_HOME_STORAGE_KEY = 'iris-sites:launcher-home:v1';

export interface LauncherHomeState {
  hiddenSuggestionKeys: string[];
  customSuggestions: LauncherSuggestion[];
  orderedSuggestionKeys: string[];
}

interface StoredLauncherHomeState {
  hiddenSuggestionKeys?: unknown;
  customSuggestions?: unknown;
  orderedSuggestionKeys?: unknown;
}

const defaultSuggestionKeys = new Set(launcherSuggestions.map(getLauncherSuggestionKey));
const GENERIC_SITE_TITLES = new Set(['Isolated Site', 'Iris Site']);

function titleCaseSegment(value: string): string {
  return value
    .replace(/\.[^.]+$/, '')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function getFallbackNameForSite(site: HostedSite): string {
  if (site.kind === 'mutable') {
    return titleCaseSegment(site.treeName.split('/').filter(Boolean).at(-1) ?? site.treeName) || site.treeName || 'App';
  }

  const entryPath = site.entryPath || 'index.html';
  const parts = entryPath.split('/').filter(Boolean);
  const usefulPart = [...parts].reverse().find((part) => part.toLowerCase() !== 'index.html') ?? '';
  return titleCaseSegment(usefulPart) || 'App';
}

function getLauncherSuggestionForSite(site: HostedSite): LauncherSuggestion | null {
  return launcherSuggestions.find((suggestion) => {
    if (site.kind === 'mutable') {
      return suggestion.ownerNpub === site.npub && suggestion.treeName === site.treeName;
    }
    return suggestion.nhash === site.nhash && (suggestion.entryPath || 'index.html') === (site.entryPath || 'index.html');
  }) ?? null;
}

export function getLauncherSuggestionKey(suggestion: Pick<LauncherSuggestion, 'href' | 'ownerNpub' | 'treeName'>): string {
  if (suggestion.ownerNpub && suggestion.treeName) {
    return `${suggestion.ownerNpub}/${suggestion.treeName}`;
  }

  return suggestion.href;
}

export function createLauncherSuggestionFromSite(site: HostedSite): LauncherSuggestion | null {
  const knownSuggestion = getLauncherSuggestionForSite(site);
  if (knownSuggestion) return knownSuggestion;

  const rawTitle = site.title.trim();
  const name = rawTitle && !GENERIC_SITE_TITLES.has(rawTitle) ? rawTitle : getFallbackNameForSite(site);
  if (site.kind === 'immutable') {
    const entryPath = site.entryPath || 'index.html';
    return {
      name,
      href: `#/${site.nhash}/${entryPath}`,
      blurb: name,
      nhash: site.nhash,
      entryPath,
    };
  }

  return {
    name,
    href: `#/${site.npub}/${site.treeName}/index.html`,
    blurb: name,
    ownerNpub: site.npub,
    treeName: site.treeName,
  };
}

export function getVisibleLauncherSuggestions(
  defaultSuggestions: readonly LauncherSuggestion[],
  customSuggestions: readonly LauncherSuggestion[],
  hiddenSuggestionKeys: readonly string[],
  orderedSuggestionKeys: readonly string[] = [],
): LauncherSuggestion[] {
  const hiddenKeys = new Set(hiddenSuggestionKeys);
  const seenKeys = new Set<string>();
  const visibleByKey = new Map<string, LauncherSuggestion>();

  for (const suggestion of [...defaultSuggestions, ...customSuggestions]) {
    const key = getLauncherSuggestionKey(suggestion);
    if (hiddenKeys.has(key) || seenKeys.has(key)) continue;
    seenKeys.add(key);
    visibleByKey.set(key, suggestion);
  }

  const visibleSuggestions: LauncherSuggestion[] = [];
  for (const key of orderedSuggestionKeys) {
    const suggestion = visibleByKey.get(key);
    if (!suggestion) continue;
    visibleSuggestions.push(suggestion);
    visibleByKey.delete(key);
  }

  return [...visibleSuggestions, ...visibleByKey.values()];
}

export function addLauncherHomeSuggestion(
  state: LauncherHomeState,
  suggestion: LauncherSuggestion,
): LauncherHomeState {
  const key = getLauncherSuggestionKey(suggestion);
  const currentVisibleKeys = getVisibleLauncherSuggestions(
    launcherSuggestions,
    state.customSuggestions,
    state.hiddenSuggestionKeys,
    state.orderedSuggestionKeys,
  ).map(getLauncherSuggestionKey);

  return {
    hiddenSuggestionKeys: state.hiddenSuggestionKeys.filter((hiddenKey) => hiddenKey !== key),
    customSuggestions: defaultSuggestionKeys.has(key)
      ? state.customSuggestions.filter((customSuggestion) => getLauncherSuggestionKey(customSuggestion) !== key)
      : [
        ...state.customSuggestions.filter((customSuggestion) => getLauncherSuggestionKey(customSuggestion) !== key),
        suggestion,
      ],
    orderedSuggestionKeys: [
      key,
      ...currentVisibleKeys.filter((visibleKey) => visibleKey !== key),
    ],
  };
}

export function removeLauncherHomeSuggestion(
  state: LauncherHomeState,
  suggestion: LauncherSuggestion,
): LauncherHomeState {
  const key = getLauncherSuggestionKey(suggestion);
  return {
    hiddenSuggestionKeys: defaultSuggestionKeys.has(key)
      ? Array.from(new Set([...state.hiddenSuggestionKeys, key]))
      : state.hiddenSuggestionKeys.filter((hiddenKey) => hiddenKey !== key),
    customSuggestions: state.customSuggestions.filter(
      (customSuggestion) => getLauncherSuggestionKey(customSuggestion) !== key,
    ),
    orderedSuggestionKeys: state.orderedSuggestionKeys.filter((orderedKey) => orderedKey !== key),
  };
}

export function moveLauncherHomeSuggestion(
  state: LauncherHomeState,
  suggestion: LauncherSuggestion,
  visibleSuggestions: readonly LauncherSuggestion[],
  offset: -1 | 1,
): LauncherHomeState {
  const visibleKeys = visibleSuggestions.map(getLauncherSuggestionKey);
  const key = getLauncherSuggestionKey(suggestion);
  const currentIndex = visibleKeys.indexOf(key);
  if (currentIndex < 0) return state;

  const nextIndex = currentIndex + offset;
  if (nextIndex < 0 || nextIndex >= visibleKeys.length) return state;

  const orderedSuggestionKeys = [...visibleKeys];
  [orderedSuggestionKeys[currentIndex], orderedSuggestionKeys[nextIndex]] = [
    orderedSuggestionKeys[nextIndex],
    orderedSuggestionKeys[currentIndex],
  ];

  return {
    ...state,
    orderedSuggestionKeys,
  };
}

export function reorderLauncherHomeSuggestion(
  state: LauncherHomeState,
  visibleSuggestions: readonly LauncherSuggestion[],
  sourceKey: string,
  targetKey: string,
): LauncherHomeState {
  if (sourceKey === targetKey) return state;

  const orderedSuggestionKeys = visibleSuggestions.map(getLauncherSuggestionKey);
  const sourceIndex = orderedSuggestionKeys.indexOf(sourceKey);
  const targetIndex = orderedSuggestionKeys.indexOf(targetKey);
  if (sourceIndex < 0 || targetIndex < 0) return state;

  const [source] = orderedSuggestionKeys.splice(sourceIndex, 1);
  orderedSuggestionKeys.splice(targetIndex, 0, source);

  return {
    ...state,
    orderedSuggestionKeys,
  };
}

export function parseLauncherHomeState(value: string | null): LauncherHomeState {
  if (!value) return { hiddenSuggestionKeys: [], customSuggestions: [], orderedSuggestionKeys: [] };

  try {
    const parsed = JSON.parse(value) as StoredLauncherHomeState;
    const hiddenSuggestionKeys = Array.isArray(parsed.hiddenSuggestionKeys)
      ? parsed.hiddenSuggestionKeys.filter((key): key is string => typeof key === 'string')
      : [];
    const customSuggestions = Array.isArray(parsed.customSuggestions)
      ? parsed.customSuggestions.flatMap(parseStoredSuggestion)
      : [];
    const orderedSuggestionKeys = Array.isArray(parsed.orderedSuggestionKeys)
      ? parsed.orderedSuggestionKeys.filter((key): key is string => typeof key === 'string')
      : [];

    return { hiddenSuggestionKeys, customSuggestions, orderedSuggestionKeys };
  } catch {
    return { hiddenSuggestionKeys: [], customSuggestions: [], orderedSuggestionKeys: [] };
  }
}

export function serializeLauncherHomeState(state: LauncherHomeState): string {
  return JSON.stringify({
    hiddenSuggestionKeys: state.hiddenSuggestionKeys,
    customSuggestions: state.customSuggestions,
    orderedSuggestionKeys: state.orderedSuggestionKeys,
  });
}

function parseStoredSuggestion(value: unknown): LauncherSuggestion[] {
  if (!value || typeof value !== 'object') return [];
  const suggestion = value as Partial<Record<keyof LauncherSuggestion, unknown>>;
  if (
    typeof suggestion.name !== 'string'
    || typeof suggestion.href !== 'string'
    || typeof suggestion.blurb !== 'string'
  ) {
    return [];
  }

  return [{
    name: suggestion.name,
    href: suggestion.href,
    blurb: suggestion.blurb,
    icon: typeof suggestion.icon === 'string' ? suggestion.icon : undefined,
    nhash: typeof suggestion.nhash === 'string' ? suggestion.nhash : undefined,
    entryPath: typeof suggestion.entryPath === 'string' ? suggestion.entryPath : undefined,
    ownerNpub: typeof suggestion.ownerNpub === 'string' ? suggestion.ownerNpub : undefined,
    treeName: typeof suggestion.treeName === 'string' ? suggestion.treeName : undefined,
    primaryHost: typeof suggestion.primaryHost === 'string' ? suggestion.primaryHost : undefined,
    external: typeof suggestion.external === 'boolean' ? suggestion.external : undefined,
  }];
}
