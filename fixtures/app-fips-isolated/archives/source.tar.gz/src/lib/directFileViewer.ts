export type DirectFileViewerKind = 'image' | 'video' | 'audio' | 'pdf';

const IMAGE_EXTENSIONS = new Set(['avif', 'bmp', 'gif', 'ico', 'jpeg', 'jpg', 'png', 'svg', 'webp']);
const VIDEO_EXTENSIONS = new Set(['m4v', 'mkv', 'mov', 'mp4', 'ogv', 'webm']);
const AUDIO_EXTENSIONS = new Set(['aac', 'flac', 'm4a', 'mp3', 'oga', 'ogg', 'opus', 'wav']);

function extensionFromPath(path: string | undefined): string {
  const cleanPath = (path || '').split('?', 1)[0].split('#', 1)[0];
  const fileName = cleanPath.split('/').filter(Boolean).at(-1) || '';
  const dotIndex = fileName.lastIndexOf('.');
  return dotIndex >= 0 ? fileName.slice(dotIndex + 1).toLowerCase() : '';
}

export function getDirectFileViewerKind(path: string | undefined): DirectFileViewerKind | null {
  const extension = extensionFromPath(path);
  if (IMAGE_EXTENSIONS.has(extension)) return 'image';
  if (VIDEO_EXTENSIONS.has(extension)) return 'video';
  if (AUDIO_EXTENSIONS.has(extension)) return 'audio';
  if (extension === 'pdf') return 'pdf';
  return null;
}

export function getDirectFileViewerName(path: string | undefined): string {
  const fileName = (path || '').split('/').filter(Boolean).at(-1) || 'File';
  try {
    return decodeURIComponent(fileName);
  } catch {
    return fileName;
  }
}
