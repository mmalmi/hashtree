import { SocialGraph } from 'nostr-social-graph';
import { loadGraphBootstrap, syncGraphLists } from 'nostr-social-graph/publicGraphSync';

export interface GraphStorage {
  read(root: string): Promise<Uint8Array | undefined>;
  write(root: string, bytes: Uint8Array, expected?: Uint8Array): Promise<boolean>;
}
export interface RetainedPublicGraph {
  graph: SocialGraph;
  restored: boolean;
  storage: GraphStorage;
}

async function openCache(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('iris-public-social-graph', 1);
    let expired = false;
    const timeout = setTimeout(() => { expired = true; reject(new Error('Graph cache unavailable')); }, 1000);
    request.onupgradeneeded = () => request.result.createObjectStore('graphs');
    request.onerror = () => { clearTimeout(timeout); reject(request.error); };
    request.onsuccess = () => {
      clearTimeout(timeout);
      if (expired) request.result.close();
      else resolve(request.result);
    };
  });
}
function sameBytes(left: unknown, right: Uint8Array | undefined): boolean {
  return left === undefined && right === undefined || left instanceof Uint8Array && right instanceof Uint8Array &&
    left.length === right.length && left.every((byte, index) => byte === right[index]);
}
const graphStorage: GraphStorage = {
  async read(root) {
    const db = await openCache();
    try {
      return await new Promise((resolve, reject) => {
        const store = db.transaction('graphs').objectStore('graphs');
        const request = store.get(root), key = store.getKey(root);
        // An existing unreadable value is not an absent cache.
        key.onsuccess = () => resolve(request.result === undefined && key.result !== undefined
          ? new Uint8Array() : request.result);
        request.onerror = () => reject(request.error);
        key.onerror = () => reject(key.error);
      });
    } finally { db.close(); }
  },
  async write(root, bytes, expected) {
    const db = await openCache();
    try {
      return await new Promise<boolean>((resolve, reject) => {
        const tx = db.transaction('graphs', 'readwrite'), store = tx.objectStore('graphs');
        const request = store.get(root), key = store.getKey(root);
        let written = false;
        key.onsuccess = () => {
          if (!sameBytes(request.result, expected) || expected === undefined && key.result !== undefined) return;
          store.put(bytes, root);
          written = true;
        };
        tx.oncomplete = () => resolve(written);
        tx.onerror = tx.onabort = () => reject(tx.error);
      });
    } finally { db.close(); }
  },
};

/** Cached public lists win; fresh server data seeds new caches, with bundled data for offline fallback. */
export async function loadRetainedPublicGraph(
  root: string, seed: () => Promise<Uint8Array>, storage = graphStorage, bootstrapRoot?: string,
): Promise<RetainedPublicGraph> {
  let expected: Uint8Array | undefined, blocked = false;
  const ownedStorage: GraphStorage = {
    read: storage.read.bind(storage),
    async write(key, bytes) {
      if (blocked) return false;
      try {
        if (!await storage.write(key, bytes, expected)) { blocked = true; return false; }
        expected = bytes.slice();
        return true;
      } catch { blocked = true; return false; }
    },
  };
  try {
    expected = await storage.read(root);
    if (expected !== undefined) {
      if (!(expected instanceof Uint8Array)) throw new Error('Unreadable graph cache');
      expected = expected.slice();
      return { graph: await SocialGraph.fromBinary(root, expected), restored: true, storage: ownedStorage };
    }
  } catch { blocked = true; /* Preserve unreadable bytes and unknown storage state. */ }
  if (!blocked && bootstrapRoot) {
    try {
      const graph = await loadGraphBootstrap({ root: bootstrapRoot, signal: AbortSignal.timeout(2500) });
      await graph.setRoot(root);
      await ownedStorage.write(root, await graph.toBinary());
      return { graph, restored: true, storage: ownedStorage };
    } catch { /* Keep cold starts usable offline or when the server is slow. */ }
  }
  return { graph: await SocialGraph.fromBinary(root, await seed()), restored: false, storage: ownedStorage };
}

/** Retain public follow/mute state and its revisions; private contacts never enter this cache. */
export function watchRetainedPublicGraph(state: RetainedPublicGraph, options: {
  relays: string[];
  authors: () => string[];
  changed: () => void;
}): () => void {
  const { graph, storage } = state;
  const root = graph.getRoot();
  let stopped = false, revision = 0, authorOffset = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let saveTimer: ReturnType<typeof setTimeout> | undefined;
  let query: AbortController | undefined;
  let writes: Promise<void> = Promise.resolve();
  const persist = () => {
    writes = writes.then(async () => {
      let version: number, bytes: Uint8Array;
      do { version = revision; bytes = await graph.toBinary(); } while (version !== revision);
      await storage.write(root, bytes);
    }).catch(() => { /* Public discovery also works without persistent storage. */ });
  };
  const changed = () => {
    revision++;
    if (stopped) return;
    options.changed();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persist, 1500);
  };
  const active = () => !globalThis.document?.hidden && globalThis.navigator?.onLine !== false;
  const run = async () => {
    if (stopped || query || !active() || !options.relays.length) return;
    clearTimeout(timer);
    query = new AbortController();
    try {
      const otherAuthors = [...new Set(options.authors())].filter(author => author !== root);
      if (authorOffset >= otherAuthors.length) authorOffset = 0;
      const authors = [root, ...otherAuthors.slice(authorOffset, authorOffset + 499)];
      const result = await syncGraphLists({ graph, relays: options.relays, authors,
        signal: query.signal, maxAuthors: 500, maxBytes: 1024 * 1024,
        timeoutMs: 4000, maxDurationMs: 15000, onEvent: () => { revision++; }, onChange: changed });
      authorOffset += Math.max(0, (result.completedAuthors ?? 0) - 1);
    } catch { /* Keep the retained graph when relays are unavailable. */ }
    finally { query = undefined; if (!stopped) timer = setTimeout(run, 15 * 60 * 1000); }
  };
  const activity = () => { if (active()) void run(); else query?.abort(); };
  globalThis.addEventListener?.('online', activity);
  globalThis.document?.addEventListener('visibilitychange', activity);
  void run();
  return () => {
    stopped = true;
    query?.abort(); clearTimeout(timer); clearTimeout(saveTimer);
    globalThis.removeEventListener?.('online', activity);
    globalThis.document?.removeEventListener('visibilitychange', activity);
    persist();
  };
}
