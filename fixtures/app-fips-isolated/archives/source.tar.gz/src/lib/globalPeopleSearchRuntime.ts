import { nhashDecode, toHex, type CID, type Hash, type Store } from '@hashtree/core';
import { SearchIndex } from '@hashtree/index';
import { HashtreeWorkerClient } from '@hashtree/worker/client';
import { getPublicRuntime } from './publicRuntime';
import {
  parseGlobalPeopleSearchEntry,
  rankGlobalPeopleSearchProfiles,
  type GlobalPeopleProfile,
} from './globalPeopleSearch';

export const DEFAULT_GLOBAL_PEOPLE_SEARCH_REF =
  'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0/profile-search';

const ROOT_CACHE_TTL_MS = 30_000;

class ReadOnlyWorkerStore implements Store {
  constructor(private readonly client: HashtreeWorkerClient) {}

  async get(hash: Hash): Promise<Uint8Array | null> {
    try {
      return (await this.client.getBlob(toHex(hash))).data;
    } catch {
      return null;
    }
  }

  async has(hash: Hash): Promise<boolean> {
    return await this.get(hash) !== null;
  }

  async put(_hash: Hash, _data: Uint8Array): Promise<boolean> {
    throw new Error('Global people search is read-only');
  }

  async delete(_hash: Hash): Promise<boolean> {
    throw new Error('Global people search is read-only');
  }
}

class GlobalPeopleSearchRuntime {
  private async getIndex(): Promise<SearchIndex> {
    return new SearchIndex(new ReadOnlyWorkerStore((await getPublicRuntime()).blobs));
  }
  private cachedRoot: { root: CID; expiresAt: number } | null = null;

  async search(query: string, limit: number, signal: AbortSignal | null): Promise<GlobalPeopleProfile[]> {
    const trimmed = query.trim();
    if (trimmed.length < 2 || signal?.aborted) return [];
    const root = await this.resolveRoot(signal);
    if (!root || signal?.aborted) return [];
    const boundedLimit = Math.min(64, Math.max(1, Math.trunc(limit)));
    const results = await (await this.getIndex()).search(root, 'p:', trimmed, {
      limit: Math.min(256, boundedLimit * 8),
      scanLimit: Math.min(512, boundedLimit * 16),
    });
    if (signal?.aborted) return [];
    return rankGlobalPeopleSearchProfiles(
      results.map(parseGlobalPeopleSearchEntry).filter((profile): profile is GlobalPeopleProfile => Boolean(profile)),
      trimmed,
    ).slice(0, boundedLimit);
  }

  private async resolveRoot(signal: AbortSignal | null): Promise<CID | null> {
    if (this.cachedRoot && this.cachedRoot.expiresAt > Date.now()) return this.cachedRoot.root;
    const runtime = await getPublicRuntime();
    if (signal?.aborted) return null;
    const configured = configuredSearchRef();
    let root: CID | null = null;
    if (configured.startsWith('nhash1')) {
      root = nhashDecode(configured);
    } else {
      const slash = configured.indexOf('/');
      if (slash <= 0 || slash === configured.length - 1) return null;
      const info = await runtime.events.getTreeRootInfo(configured.slice(0, slash), configured.slice(slash + 1));
      root = info ? { hash: info.hash, ...(info.key ? { key: info.key } : {}) } : null;
    }
    if (root) this.cachedRoot = { root, expiresAt: Date.now() + ROOT_CACHE_TTL_MS };
    return root;
  }
}

function configuredSearchRef(): string {
  const configured = import.meta.env.VITE_PROFILE_SEARCH_INDEX;
  return typeof configured === 'string' && configured.trim()
    ? configured.trim()
    : DEFAULT_GLOBAL_PEOPLE_SEARCH_REF;
}

const runtime = new GlobalPeopleSearchRuntime();

export async function searchGlobalPeople(
  query: string,
  limit = 12,
  signal: AbortSignal | null = null,
): Promise<GlobalPeopleProfile[]> {
  return await runtime.search(query, limit, signal);
}
