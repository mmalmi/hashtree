import type { HostedSite } from './siteConfig';

export const IRIS_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
export const IRIS_OWNER_PUBKEY = '336f319763657d6b0e65a5b5876719e8c8dcdcf9396852be71ee26b73368b29b';
export const IRIS_DRIVE_APP_HREF = `#/${IRIS_OWNER}/drive/index.html`;
export const HASHTREE_CLI_INSTALL_COMMAND = 'curl -fsSL https://upload.iris.to/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/releases%2Fhashtree/latest/install.sh | sh';
export const HASHTREE_CLI_PUBLISH_COMMAND = 'htree add ./dist --publish my-app';

export interface LauncherProfile {
  npub: string;
  pubkey: string;
  name?: string;
  picture?: string;
}

export interface LauncherSuggestion {
  name: string;
  href: string;
  blurb: string;
  icon?: string;
  nhash?: string;
  entryPath?: string;
  ownerNpub?: string;
  treeName?: string;
  primaryHost?: string;
  external?: boolean;
}

interface MutableSuggestionOptions {
  ownerNpub?: string;
  primaryHost?: string;
}

export function launcherAsset(path: string): string {
  const base = import.meta.env.BASE_URL || './';
  if (base === '/') {
    return `./${path.replace(/^\/+/, '')}`;
  }
  const normalizedBase = base.endsWith('/') ? base : `${base}/`;
  return `${normalizedBase}${path.replace(/^\/+/, '')}`;
}

function launcherIcon(fileName: string): string {
  return launcherAsset(`launcher-icons/${fileName}`);
}

function mutableSuggestion(
  name: string,
  treeName: string,
  blurb: string,
  icon?: string,
  options: MutableSuggestionOptions = {},
): LauncherSuggestion {
  const ownerNpub = options.ownerNpub ?? IRIS_OWNER;
  return {
    name,
    href: `#/${ownerNpub}/${treeName}/index.html`,
    blurb,
    icon,
    ownerNpub,
    treeName,
    primaryHost: options.primaryHost,
  };
}

function externalSuggestion(name: string, href: string, blurb: string, icon: string): LauncherSuggestion {
  return {
    name,
    href,
    blurb,
    icon,
    external: true,
  };
}

export function getLauncherSuggestionSite(suggestion: LauncherSuggestion): HostedSite | null {
  if (suggestion.nhash) {
    return {
      kind: 'immutable',
      siteKey: suggestion.href,
      title: suggestion.name,
      nhash: suggestion.nhash,
      entryPath: suggestion.entryPath || 'index.html',
    };
  }

  if (!suggestion.ownerNpub || !suggestion.treeName) return null;
  return {
    kind: 'mutable',
    siteKey: suggestion.treeName,
    title: suggestion.name,
    npub: suggestion.ownerNpub,
    treeName: suggestion.treeName,
    entryPath: 'index.html',
  };
}

export function getLauncherPrimaryHostForSite(site: HostedSite | null): string | null {
  if (!site || site.kind !== 'mutable') return null;
  return launcherSuggestions.find((suggestion) =>
    suggestion.ownerNpub === site.npub
    && suggestion.treeName === site.treeName
    && suggestion.primaryHost
  )?.primaryHost ?? null;
}

export const launcherProfiles = [
  {
    npub: IRIS_OWNER,
    pubkey: IRIS_OWNER_PUBKEY,
    name: 'Iris',
  },
] satisfies readonly LauncherProfile[];

export const launcherSuggestions = [
  mutableSuggestion('Drive', 'drive', 'Files and folders', launcherIcon('iris-drive-icon.svg'), {
    primaryHost: 'drive.iris.to',
  }),
  mutableSuggestion('Chat', 'iris-chat-site', 'Chats and groups', launcherIcon('iris-chat-icon.png'), {
    primaryHost: 'chat.iris.to',
  }),
  mutableSuggestion('Market', 'market', 'Buy, sell and get things done', launcherIcon('iris-market-icon.svg'), {
    primaryHost: 'market.iris.to',
  }),
  mutableSuggestion('Contacts', 'contacts', 'People and address book', launcherIcon('iris-contacts-icon.svg'), {
    primaryHost: 'contacts.iris.to',
  }),
  mutableSuggestion('Wallet', 'cashu-me', 'Ecash wallet', launcherIcon('cashu-wallet-icon.png'), {
    primaryHost: 'wallet.cashu.me',
  }),
  mutableSuggestion('Calendar', 'calendar', 'Events and availability', launcherIcon('iris-calendar-icon.svg'), {
    primaryHost: 'calendar.iris.to',
  }),
  mutableSuggestion('Docs', 'docs', 'Shared documents', launcherIcon('iris-docs-icon.svg'), {
    primaryHost: 'docs.iris.to',
  }),
  mutableSuggestion('Meet', 'meet', 'Video calls', launcherIcon('iris-meet-icon.svg'), {
    primaryHost: 'meet.iris.to',
  }),
  mutableSuggestion('Maps', 'maps', 'Maps and places', launcherIcon('iris-maps-icon.svg'), {
    primaryHost: 'maps.iris.to',
  }),
  mutableSuggestion('Social', 'iris-client-site', 'Social feed', launcherIcon('iris-social-icon.png'), {
    primaryHost: 'social.iris.to',
  }),
  externalSuggestion('Groups', 'https://groups.iris.to/', 'Communities you trust', launcherIcon('iris-groups-icon.svg')),
  mutableSuggestion('Audio', 'audio', 'Music and albums', launcherIcon('iris-audio-icon.png'), {
    primaryHost: 'audio.iris.to',
  }),
  mutableSuggestion('Video', 'video', 'Videos and playlists', launcherIcon('iris-video-icon.svg'), {
    primaryHost: 'video.iris.to',
  }),
  mutableSuggestion('Boards', 'boards', 'Shared boards', launcherIcon('iris-boards-icon.svg'), {
    primaryHost: 'boards.iris.to',
  }),
  mutableSuggestion('Nostr VPN', 'nostrvpn-org-site', 'Private device networking', launcherIcon('nostr-vpn-icon.png')),
  externalSuggestion(
    'WebVM',
    'https://webvm.iris.to/',
    'Browser-hosted Linux with FIPS, Nostr VPN pairing, and Hashtree tools',
    launcherIcon('webvm-icon.ico'),
  ),
  mutableSuggestion('Git', 'git', 'Code projects', launcherIcon('iris-git-icon.svg'), {
    primaryHost: 'git.iris.to',
  }),
  mutableSuggestion('Quick Share', 'hashtree-cc-site', 'Project site', launcherIcon('hashtree-cc-favicon.svg'), {
    primaryHost: 'hashtree.cc',
  }),
  externalSuggestion('silent.link', 'https://silent.link/', 'Private mobile service', launcherIcon('silent-link-favicon.png')),
  externalSuggestion('ProtonMail', 'https://proton.me/', 'Private email', launcherIcon('proton-favicon.png')),
] satisfies readonly LauncherSuggestion[];

export function getLauncherProfileHref(npub: string): string {
  return `#/profile/${encodeURIComponent(npub)}`;
}

export function getLauncherProfile(npub: string): LauncherProfile {
  return launcherProfiles.find((profile) => profile.npub === npub) ?? {
    npub,
    pubkey: npub,
  };
}

export function getLauncherSuggestionsForOwner(npub: string): readonly LauncherSuggestion[] {
  return launcherSuggestions.filter((suggestion) => suggestion.ownerNpub === npub);
}
