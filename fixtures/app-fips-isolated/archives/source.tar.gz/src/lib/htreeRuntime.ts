import {
  createHtreeRuntime,
  type BlossomServerConfig,
  type HtreeRuntimeWorkerConfigOptions,
} from '@hashtree/worker';
import { DEFAULT_SITE_RELAYS } from './defaultRelays';

export const DEFAULT_SITE_UPLOAD_BLOSSOM_SERVERS: BlossomServerConfig[] = [
  { url: 'https://cdn.iris.to', read: true, write: false, preferBatchReads: true },
  { url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true },
  { url: 'https://blossom.primal.net', read: true, write: true },
];

const htreeRuntime = createHtreeRuntime({
  appId: 'iris-sites',
  relays: DEFAULT_SITE_RELAYS,
  blossomServers: DEFAULT_SITE_UPLOAD_BLOSSOM_SERVERS,
});

export function getRuntimeWorkerConfig(
  options: HtreeRuntimeWorkerConfigOptions = {},
) {
  return htreeRuntime.getWorkerConfig(options);
}

export function getRuntimeBlossomServers() {
  return htreeRuntime.endpoints.blossomServers;
}
