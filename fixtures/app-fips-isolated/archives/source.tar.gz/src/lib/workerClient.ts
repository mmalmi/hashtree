import type { BlossomServerConfig } from '@hashtree/worker';
import type { RelayWorkerConfig, TreeRootInfo, TreeRootUpdate } from '@hashtree/worker/relay-client';
import { RelayWorkerClient } from '@hashtree/worker/relay-client';
import { DEFAULT_SITE_RELAYS } from './defaultRelays';
import RelayWorker from './relayWorkerEntry?worker';
import { startSitePeers, SITE_BLOCK_STORE } from './peerRuntime';

const DEFAULT_PUBKEY_HEX = '336f319763657d6b0e65a5b5876719e8c8dcdcf9396852be71ee26b73368b29b';
const DEFAULT_RELAYS = DEFAULT_SITE_RELAYS;
const DEFAULT_BLOSSOM_SERVERS: BlossomServerConfig[] = [
  { url: 'https://cdn.iris.to', read: true, write: false, preferBatchReads: true },
  { url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true },
  { url: 'https://blossom.primal.net', read: true, write: true },
];

const config: RelayWorkerConfig = {
  storeName: SITE_BLOCK_STORE,
  blossomServers: DEFAULT_BLOSSOM_SERVERS,
  relays: DEFAULT_RELAYS,
  pubkey: DEFAULT_PUBKEY_HEX,
  graphReconciliation: false,
};

export const workerClient = new RelayWorkerClient(RelayWorker, config);

export type { TreeRootInfo, TreeRootUpdate };

export async function initWorkerClient(): Promise<void> {
  await workerClient.init();
  void startSitePeers(workerClient, DEFAULT_RELAYS).catch(error => console.warn('Peer connections unavailable', error));
}

export async function registerMediaPort(port: MessagePort, debug?: boolean): Promise<void> {
  await workerClient.registerMediaPort(port, debug);
}

export async function getTreeRootInfo(npub: string, treeName: string): Promise<TreeRootInfo | null> {
  return workerClient.getTreeRootInfo(npub, treeName);
}

export async function subscribeTreeRoots(pubkey: string): Promise<void> {
  await workerClient.subscribeTreeRoots(pubkey);
}

export async function unsubscribeTreeRoots(pubkey: string): Promise<void> {
  await workerClient.unsubscribeTreeRoots(pubkey);
}

export function onTreeRootUpdate(listener: (update: TreeRootUpdate) => void): () => void {
  return workerClient.onTreeRootUpdate(listener);
}
