import { nhashDecode, nhashEncode, toHex } from '@hashtree/core';
import {
  buildTreeEventSnapshotPermalink,
  normalizeTreeEventSnapshotLinkKey,
  parseTreeEventSnapshotPermalink,
  type TreeEventSnapshotPermalink,
} from '@hashtree/nostr';
import {
  decodeImmutableHostLabel,
  encodeMutableHostLabel,
  encodePathSegments,
  normalizeHost,
} from './siteIdentity';

interface HostedSiteBase {
  siteKey: string;
  title: string;
  entryPath?: string;
}

export interface ImmutableHostedSite extends HostedSiteBase {
  kind: 'immutable';
  nhash: string;
  snapshot?: boolean;
  snapshotLinkKey?: string;
}

export interface MutableHostedSite extends HostedSiteBase {
  kind: 'mutable';
  npub: string;
  treeName: string;
}

export type HostedSite = ImmutableHostedSite | MutableHostedSite;

export interface SiteLocationLike {
  host: string;
  hash?: string;
  pathname?: string;
}

export const GENERIC_SITE_TITLE = 'Iris Site';

const PROD_PORTAL_HOST = 'apps.iris.to';
const LEGACY_PROD_PORTAL_HOST = 'sites.iris.to';
const LOCAL_PORTAL_HOST = 'sites.iris.localhost';
const LOCAL_DEV_PORTAL_HOSTS = new Set(['localhost', '127.0.0.1']);
const LOCAL_DRIVE_PORTAL_HOST = 'iris.localhost';
const IRIS_SITES_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const LOCAL_DRIVE_MUTABLE_PORTAL_HOST = `sites.${IRIS_SITES_OWNER}.iris.localhost`;

function isPortalHost(host: string): boolean {
  return host === PROD_PORTAL_HOST
    || host === LEGACY_PROD_PORTAL_HOST
    || host === LOCAL_PORTAL_HOST
    || LOCAL_DEV_PORTAL_HOSTS.has(host)
    || host === LOCAL_DRIVE_PORTAL_HOST
    || host === LOCAL_DRIVE_MUTABLE_PORTAL_HOST;
}

function decodeHashRoute(hash: string | undefined): { parts: string[]; params: URLSearchParams } {
  const trimmed = (hash || '').trim();
  if (!trimmed.startsWith('#')) {
    return { parts: [], params: new URLSearchParams() };
  }

  const route = trimmed.startsWith('#/') ? trimmed.slice(2) : trimmed.slice(1);
  const [pathPart, queryPart = ''] = route.split('?', 2);
  const parts = pathPart
    .split('/')
    .filter(Boolean)
    .map((part) => {
      try {
        return decodeURIComponent(part);
      } catch {
        return part;
      }
    });

  return {
    parts,
    params: new URLSearchParams(queryPart),
  };
}

function isMaybeNhash(value: string): boolean {
  return /^nhash1[a-z0-9]+$/.test(value);
}

function isMaybeNpub(value: string): boolean {
  return /^npub1[a-z0-9]+$/.test(value);
}

function isDnsSiteLabel(value: string): boolean {
  return value.length > 0
    && value.length <= 63
    && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(value);
}

function decodePathnameEntryPath(pathname: string | undefined): string {
  const path = (pathname || '').replace(/^\/+/, '');
  if (!path) return 'index.html';

  return path
    .split('/')
    .filter(Boolean)
    .map((part) => {
      try {
        return decodeURIComponent(part);
      } catch {
        return part;
      }
    })
    .join('/') || 'index.html';
}

export function isInternalHtreePath(pathname: string | undefined): boolean {
  return /^\/+htree(?:\/|$)/i.test(pathname || '');
}

function parseReadableLocalRuntimeSite(host: string, pathname: string | undefined): HostedSite | null {
  const normalized = normalizeHost(host);
  if (!normalized || isPortalHost(normalized) || !normalized.endsWith(`.${LOCAL_DRIVE_PORTAL_HOST}`)) {
    return null;
  }

  const prefix = normalized.slice(0, -(`.${LOCAL_DRIVE_PORTAL_HOST}`.length));
  const labels = prefix.split('.').filter(Boolean);
  if (!labels.length) return null;

  const entryPath = decodePathnameEntryPath(pathname);
  const splitNhash = labels.join('');
  if (isMaybeNhash(splitNhash)) {
    try {
      nhashDecode(splitNhash);
      return createGenericImmutableSite(splitNhash, entryPath);
    } catch {
      return null;
    }
  }

  if (labels.length !== 2) {
    return null;
  }

  const [firstLabel, secondLabel] = labels;
  const [npub, treeName] = isMaybeNpub(firstLabel)
    ? [firstLabel, secondLabel]
    : [secondLabel, firstLabel];
  if (!isDnsSiteLabel(treeName) || !isDnsSiteLabel(npub) || !isMaybeNpub(npub)) {
    return null;
  }

  return createGenericMutableSite(npub, treeName, entryPath);
}

function createGenericImmutableSite(
  nhash: string,
  entryPath: string,
  options: { snapshot?: boolean; snapshotLinkKey?: string } = {},
): ImmutableHostedSite {
  return {
    kind: 'immutable',
    siteKey: 'pilot',
    title: GENERIC_SITE_TITLE,
    nhash,
    entryPath,
    ...(options.snapshot ? { snapshot: true } : {}),
    ...(options.snapshotLinkKey ? { snapshotLinkKey: options.snapshotLinkKey } : {}),
  };
}

function createGenericMutableSite(npub: string, treeName: string, entryPath: string): MutableHostedSite {
  return {
    kind: 'mutable',
    siteKey: 'pilot',
    title: treeName || GENERIC_SITE_TITLE,
    npub,
    treeName,
    entryPath,
  };
}

function createImmutableSiteFromSnapshotPermalink(
  permalink: TreeEventSnapshotPermalink,
): ImmutableHostedSite {
  return createGenericImmutableSite(
    permalink.snapshotNhash,
    permalink.path.join('/') || 'index.html',
    {
      snapshot: true,
      snapshotLinkKey: permalink.linkKey,
    },
  );
}

function parseGenericHashSite(hash: string | undefined): HostedSite | null {
  const { parts, params } = decodeHashRoute(hash);
  const snapshotPermalink = parseTreeEventSnapshotPermalink(
    `/${parts.map((part) => encodeURIComponent(part)).join('/')}${params.size > 0 ? `?${params.toString()}` : ''}`,
  );
  if (snapshotPermalink) {
    return createImmutableSiteFromSnapshotPermalink(snapshotPermalink);
  }

  if (params.get('snapshot')?.trim() === '1') {
    return null;
  }

  if (parts[0] === 'nhash' && parts[1] && isMaybeNhash(parts[1])) {
    return createGenericImmutableSite(parts[1], parts.slice(2).join('/') || 'index.html');
  }

  if (parts[0] && isMaybeNhash(parts[0])) {
    return createGenericImmutableSite(parts[0], parts.slice(1).join('/') || 'index.html');
  }

  if (parts[0] === 'npub' && parts[1] && parts[2] && isMaybeNpub(parts[1])) {
    return createGenericMutableSite(parts[1], parts[2], parts.slice(3).join('/') || 'index.html');
  }

  if (parts[0] && parts[1] && isMaybeNpub(parts[0])) {
    return createGenericMutableSite(parts[0], parts[1], parts.slice(2).join('/') || 'index.html');
  }

  return null;
}

interface RuntimeSiteHint {
  label: string;
  hash: Uint8Array;
}

function parseRuntimeSiteHint(host: string): RuntimeSiteHint | null {
  const normalized = normalizeHost(host);
  if (!normalized || isPortalHost(normalized)) {
    return null;
  }

  let prefix = '';
  if (normalized.endsWith('.hashtree.cc')) {
    prefix = normalized.slice(0, -'.hashtree.cc'.length);
  } else if (normalized.endsWith(`.${LOCAL_PORTAL_HOST}`)) {
    prefix = normalized.slice(0, -(`.${LOCAL_PORTAL_HOST}`.length));
  } else {
    return null;
  }

  const labels = prefix.split('.').filter(Boolean);
  if (!labels.length) return null;

  if (labels.length === 1) {
    const hash = decodeImmutableHostLabel(labels[0]);
    if (hash) {
      return {
        label: labels[0],
        hash,
      };
    }
  }

  return null;
}

function resolveImmutableRuntimeSite(hint: RuntimeSiteHint, hash: string | undefined): HostedSite | null {
  const bareNhash = nhashEncode(hint.hash);
  const generic = parseGenericHashSite(hash);
  if (generic?.kind === 'immutable') {
    try {
      // Runtime hosts are the security boundary. A fragment must not be able to
      // smuggle in a different immutable root under the same origin.
      if (nhashEncode(nhashDecode(generic.nhash).hash) !== bareNhash) {
        return null;
      }
    } catch {
      return null;
    }
    return generic;
  }

  const { parts, params } = decodeHashRoute(hash);
  const entryPath = parts.join('/') || 'index.html';
  const snapshot = params.get('snapshot')?.trim() === '1';
  const rawSnapshotLinkKey = params.get('k');
  const snapshotLinkKey = normalizeTreeEventSnapshotLinkKey(rawSnapshotLinkKey);

  if (snapshot) {
    if (rawSnapshotLinkKey?.trim() && !snapshotLinkKey) {
      return null;
    }
    return createGenericImmutableSite(bareNhash, entryPath, {
      snapshot: true,
      snapshotLinkKey: snapshotLinkKey || undefined,
    });
  }

  const decryptKey = params.get('k')?.trim();

  if (!decryptKey) {
    return createGenericImmutableSite(bareNhash, entryPath);
  }

  if (!/^[a-f0-9]{64}$/i.test(decryptKey)) {
    return null;
  }

  try {
    return createGenericImmutableSite(
      nhashEncode({ hash: toHex(hint.hash), decryptKey: decryptKey.toLowerCase() }),
      entryPath,
    );
  } catch {
    return null;
  }
}

function resolveMutableRuntimeSite(hint: RuntimeSiteHint, hash: string | undefined): HostedSite | null {
  const generic = parseGenericHashSite(hash);
  if (generic?.kind === 'mutable') {
    // Refuse cross-site spoofing like real-site.hashtree.cc/#/attacker/tree:
    // the fragment must reproduce the exact opaque hostname label derived
    // from the full mutable route.
    if (encodeMutableHostLabel(generic.npub, generic.treeName) !== hint.label) {
      return null;
    }
    return generic;
  }

  return null;
}

export function serializeHostedSiteHash(site: HostedSite): string {
  const entryPath = encodePathSegments(site.entryPath || 'index.html');
  if (site.kind === 'immutable') {
    if (site.snapshot) {
      return buildTreeEventSnapshotPermalink(
        {
          snapshotNhash: site.nhash,
          path: (site.entryPath || 'index.html').split('/').filter(Boolean),
          ...(site.snapshotLinkKey ? { linkKey: site.snapshotLinkKey } : {}),
        },
        { prefix: '#/' },
      );
    }
    return `#/${site.nhash}/${entryPath}`;
  }
  return `#/${site.npub}/${encodeURIComponent(site.treeName)}/${entryPath}`;
}

export function resolveHostedSite(location: SiteLocationLike): HostedSite | null {
  const normalizedHost = normalizeHost(location.host);
  if (isInternalHtreePath(location.pathname)) {
    return null;
  }

  const readableLocalSite = parseReadableLocalRuntimeSite(location.host, location.pathname);
  if (readableLocalSite) {
    return readableLocalSite;
  }

  const runtimeHint = parseRuntimeSiteHint(location.host);
  if (runtimeHint) {
    const generic = parseGenericHashSite(location.hash);
    if (generic?.kind === 'mutable') {
      return resolveMutableRuntimeSite(runtimeHint, location.hash);
    }
    return resolveImmutableRuntimeSite(runtimeHint, location.hash);
  }

  if (isPortalHost(normalizedHost)) {
    return parseGenericHashSite(location.hash);
  }

  return null;
}
