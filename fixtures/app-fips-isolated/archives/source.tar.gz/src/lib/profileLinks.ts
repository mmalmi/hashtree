import type { ContactRecord } from './contacts';

export const IRIS_SOCIAL_ORIGIN = 'https://iris.to';
export const IRIS_CHAT_ORIGIN = 'https://chat.iris.to';

export function irisSocialProfileUrl(contact: Pick<ContactRecord, 'npub'>): string | null {
  return contact.npub ? `${IRIS_SOCIAL_ORIGIN}/${contact.npub}` : null;
}

export function irisChatProfileUrl(contact: Pick<ContactRecord, 'npub'>): string | null {
  return contact.npub ? `${IRIS_CHAT_ORIGIN}/#/${contact.npub}` : null;
}
