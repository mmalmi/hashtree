import {
  buildFactSnapshotDraft,
  fact,
  parseFactSnapshotDraft,
  type Fact,
  type FactEventDraft,
  type ParsedFactSnapshotDraft,
} from 'nostr-social-graph';
import {
  decodeNpubInput,
  isContactIdentityId,
  isHexPubkey,
  pubkeyToNpub,
  type ContactIdentity,
  type ContactIdentityAttribute,
  type ContactIdentityAttributeType,
  type ContactSource,
} from './contacts';

export const CONTACT_ATTR_PREDICATE = 'contact_attr';

const CREATED_AT_PREDICATE = 'created_at';
const UPDATED_AT_PREDICATE = 'updated_at';
const ACTIVE_VALUE = 'active';
const INACTIVE_VALUE = 'inactive';

export interface ContactFactSnapshotOptions {
  heads?: string[];
}

export interface ContactFactSnapshotParseOptions {
  fallbackSource?: ContactSource;
  fallbackAddedAt?: number;
}

export function contactIdentityToFactSnapshotDraft(
  identity: ContactIdentity,
  options: ContactFactSnapshotOptions = {},
): FactEventDraft {
  const subject = normalizeContactSubject(identity.id);
  return buildFactSnapshotDraft(
    subject,
    contactIdentityToFacts(identity),
    options.heads ?? [],
    { externalIdentifiers: contactIdentityExternalIdentifiers(identity) },
  );
}

export function contactIdentityFromFactSnapshotDraft(
  draft: FactEventDraft,
  options: ContactFactSnapshotParseOptions = {},
): ContactIdentity {
  return contactIdentityFromParsedFactSnapshot(parseFactSnapshotDraft(draft), options);
}

export function contactIdentityFromParsedFactSnapshot(
  snapshot: ParsedFactSnapshotDraft,
  options: ContactFactSnapshotParseOptions = {},
): ContactIdentity {
  const id = normalizeContactSubject(snapshot.subject);
  const fallbackAddedAt = normalizeTimestamp(options.fallbackAddedAt, Date.now());
  const createdAt = factTimestamp(snapshot.facts, CREATED_AT_PREDICATE, fallbackAddedAt);
  const updatedAt = factTimestamp(snapshot.facts, UPDATED_AT_PREDICATE, Math.max(createdAt, fallbackAddedAt));
  const attrs = normalizeSnapshotAttrs(snapshot.facts, options.fallbackSource ?? 'private', fallbackAddedAt);

  return {
    id,
    createdAt,
    updatedAt: Math.max(updatedAt, createdAt),
    attrs,
  };
}

export function contactIdentityToFacts(identity: ContactIdentity): Fact[] {
  return [
    fact(CREATED_AT_PREDICATE, [timestampString(identity.createdAt)]),
    fact(UPDATED_AT_PREDICATE, [timestampString(identity.updatedAt)]),
    ...identity.attrs.flatMap((attr) => [
      contactAttrFact(attr),
      ...contactAttrProfileFacts(attr),
    ]),
  ];
}

function contactAttrFact(attr: ContactIdentityAttribute): Fact {
  const values = [
    attr.type,
    attr.value,
    attr.source,
    attr.active ? ACTIVE_VALUE : INACTIVE_VALUE,
    timestampString(attr.addedAt),
  ];
  if (attr.label?.trim()) values.push(attr.label.trim());
  return fact(CONTACT_ATTR_PREDICATE, values);
}

function contactAttrProfileFacts(attr: ContactIdentityAttribute): Fact[] {
  if (!attr.active) return [];
  if (attr.type === 'name') return [fact('name', [attr.value])];
  if (attr.type === 'handle') return [fact('handle', [attr.value])];
  if (attr.type === 'nostr_pubkey') return [fact('controls', [attr.value])];
  if (attr.type === 'npub') return [fact('npub', [attr.value])];
  if (attr.type === 'picture') return [fact('picture', [attr.value])];
  return [];
}

function normalizeSnapshotAttrs(
  facts: readonly Fact[],
  fallbackSource: ContactSource,
  fallbackAddedAt: number,
): ContactIdentityAttribute[] {
  const attrs: ContactIdentityAttribute[] = [];
  const seen = new Set<string>();

  for (const factEntry of facts) {
    if (factEntry.predicate !== CONTACT_ATTR_PREDICATE) continue;
    addAttr(attrs, seen, attrFromContactFact(factEntry, fallbackSource, fallbackAddedAt));
  }

  for (const factEntry of facts) {
    addAttr(attrs, seen, attrFromProfileFact(factEntry, fallbackSource, fallbackAddedAt));
  }

  return attrs;
}

function attrFromContactFact(
  factEntry: Fact,
  fallbackSource: ContactSource,
  fallbackAddedAt: number,
): ContactIdentityAttribute | null {
  const [rawType, rawValue, rawSource, rawActive, rawAddedAt, rawLabel] = factEntry.values;
  const type = normalizeContactAttrType(rawType);
  const value = normalizeContactAttrValue(type, rawValue);
  if (!type || !value) return null;
  const source = normalizeContactSource(rawSource) ?? fallbackSource;
  const label = typeof rawLabel === 'string' ? rawLabel.trim() : '';
  const attr: ContactIdentityAttribute = {
    type,
    value,
    source,
    active: normalizeActive(rawActive),
    addedAt: normalizeTimestamp(rawAddedAt, fallbackAddedAt),
  };
  if (label) attr.label = label;
  return attr;
}

function attrFromProfileFact(
  factEntry: Fact,
  fallbackSource: ContactSource,
  fallbackAddedAt: number,
): ContactIdentityAttribute | null {
  const value = factEntry.values[0];
  if (factEntry.predicate === 'name') {
    return profileAttr('name', value, fallbackSource, fallbackAddedAt);
  }
  if (factEntry.predicate === 'handle') {
    return profileAttr('handle', value, fallbackSource, fallbackAddedAt);
  }
  if (factEntry.predicate === 'controls') {
    return profileAttr('nostr_pubkey', value, fallbackSource, fallbackAddedAt);
  }
  if (factEntry.predicate === 'npub') {
    return profileAttr('npub', value, fallbackSource, fallbackAddedAt);
  }
  if (factEntry.predicate === 'picture') {
    return profileAttr('picture', value, fallbackSource, fallbackAddedAt);
  }
  return null;
}

function profileAttr(
  type: ContactIdentityAttributeType,
  rawValue: string | undefined,
  source: ContactSource,
  addedAt: number,
): ContactIdentityAttribute | null {
  const value = normalizeContactAttrValue(type, rawValue);
  return value ? { type, value, source, active: true, addedAt } : null;
}

function addAttr(
  attrs: ContactIdentityAttribute[],
  seen: Set<string>,
  attr: ContactIdentityAttribute | null,
): void {
  if (!attr) return;
  const key = `${attr.type}\0${attrKeyValue(attr.type, attr.value)}`;
  if (seen.has(key)) return;
  seen.add(key);
  attrs.push(attr);
}

function contactIdentityExternalIdentifiers(identity: ContactIdentity): string[] {
  const identifiers = new Set<string>();
  for (const attr of identity.attrs) {
    if (!attr.active) continue;
    if (attr.type === 'handle' || attr.type === 'npub') identifiers.add(attr.value);
  }
  return [...identifiers].sort();
}

function normalizeContactSubject(value: string): string {
  const normalized = value.trim().toLowerCase();
  if (!isContactIdentityId(normalized)) {
    throw new Error(`contact identity id must be a canonical UUIDv4: ${value}`);
  }
  return normalized;
}

function normalizeContactAttrType(value: unknown): ContactIdentityAttributeType | null {
  if (
    value === 'name' ||
    value === 'handle' ||
    value === 'nostr_pubkey' ||
    value === 'npub' ||
    value === 'picture'
  ) {
    return value;
  }
  return null;
}

function normalizeContactSource(value: unknown): ContactSource | null {
  return value === 'public' || value === 'private' ? value : null;
}

function normalizeContactAttrValue(
  type: ContactIdentityAttributeType | null,
  value: unknown,
): string | null {
  if (!type || typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (type === 'nostr_pubkey') return isHexPubkey(trimmed) ? trimmed.toLowerCase() : null;
  if (type === 'npub') {
    const pubkey = decodeNpubInput(trimmed);
    return pubkey ? pubkeyToNpub(pubkey) : null;
  }
  return trimmed;
}

function normalizeActive(value: unknown): boolean {
  if (value === INACTIVE_VALUE || value === 'false' || value === '0') return false;
  return true;
}

function normalizeTimestamp(value: unknown, fallback: number): number {
  if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value);
  if (typeof value === 'string' && value.trim()) {
    const parsed = Number.parseInt(value.trim(), 10);
    if (Number.isFinite(parsed)) return parsed;
  }
  return fallback;
}

function factTimestamp(facts: readonly Fact[], predicate: string, fallback: number): number {
  const value = facts.find((factEntry) => factEntry.predicate === predicate)?.values[0];
  return normalizeTimestamp(value, fallback);
}

function timestampString(value: number): string {
  return String(normalizeTimestamp(value, Date.now()));
}

function attrKeyValue(type: ContactIdentityAttributeType, value: string): string {
  if (type === 'picture') return value;
  return value.toLowerCase();
}
