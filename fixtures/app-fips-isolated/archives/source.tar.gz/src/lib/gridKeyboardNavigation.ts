export type GridKeyboardDirection = 'down' | 'left' | 'right' | 'up';

export interface GridKeyboardRect {
  height: number;
  left: number;
  top: number;
  width: number;
}

interface IndexedGridItem {
  centerX: number;
  centerY: number;
  index: number;
}

const ROW_TOLERANCE_PX = 8;

function toIndexedGridItems(items: readonly GridKeyboardRect[]): IndexedGridItem[] {
  return items.map((item, index) => ({
    centerX: item.left + item.width / 2,
    centerY: item.top + item.height / 2,
    index,
  }));
}

function sortVisually(items: readonly IndexedGridItem[]): IndexedGridItem[] {
  return [...items].sort((left, right) => {
    if (Math.abs(left.centerY - right.centerY) > ROW_TOLERANCE_PX) {
      return left.centerY - right.centerY;
    }
    return left.centerX - right.centerX;
  });
}

function getVisualNeighborIndex(
  items: readonly IndexedGridItem[],
  currentIndex: number,
  offset: -1 | 1,
): number {
  const visualItems = sortVisually(items);
  const visualIndex = visualItems.findIndex((item) => item.index === currentIndex);
  if (visualIndex < 0) return currentIndex;
  const nextVisualIndex = Math.min(Math.max(visualIndex + offset, 0), visualItems.length - 1);
  return visualItems[nextVisualIndex]?.index ?? currentIndex;
}

function getVerticalNeighborIndex(
  items: readonly IndexedGridItem[],
  current: IndexedGridItem,
  direction: 'down' | 'up',
): number {
  const candidates = items.filter((item) => (
    direction === 'down'
      ? item.centerY > current.centerY + ROW_TOLERANCE_PX
      : item.centerY < current.centerY - ROW_TOLERANCE_PX
  ));
  if (candidates.length === 0) return current.index;

  const nearestRowDistance = Math.min(
    ...candidates.map((item) => Math.abs(item.centerY - current.centerY)),
  );
  const nearestRowItems = candidates.filter((item) =>
    Math.abs(Math.abs(item.centerY - current.centerY) - nearestRowDistance) <= ROW_TOLERANCE_PX
  );

  return sortVisually(nearestRowItems).sort((left, right) =>
    Math.abs(left.centerX - current.centerX) - Math.abs(right.centerX - current.centerX)
  )[0]?.index ?? current.index;
}

export function getNextGridKeyboardIndex(
  items: readonly GridKeyboardRect[],
  currentIndex: number,
  direction: GridKeyboardDirection,
): number {
  if (currentIndex < 0 || currentIndex >= items.length || items.length === 0) {
    return currentIndex;
  }

  const indexedItems = toIndexedGridItems(items);
  const current = indexedItems[currentIndex];
  if (!current) return currentIndex;

  if (direction === 'left') {
    return getVisualNeighborIndex(indexedItems, currentIndex, -1);
  }
  if (direction === 'right') {
    return getVisualNeighborIndex(indexedItems, currentIndex, 1);
  }
  return getVerticalNeighborIndex(indexedItems, current, direction);
}
