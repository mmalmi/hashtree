import { GENERIC_SITE_TITLE } from './siteConfig';

const LEGACY_GENERIC_SITE_TITLE = 'Isolated Site';
const GENERIC_SHELL_TITLES = new Set([GENERIC_SITE_TITLE, LEGACY_GENERIC_SITE_TITLE]);

export function normalizeFrameTitle(title: string | null | undefined): string | null {
  const normalized = (title || '').trim().replace(/\s+/g, ' ');
  return normalized || null;
}

export function buildShellTitle(siteTitle: string | null | undefined, frameTitle: string | null | undefined): string {
  const normalizedFrameTitle = normalizeFrameTitle(frameTitle);
  if (normalizedFrameTitle) return normalizedFrameTitle;

  const normalizedSiteTitle = normalizeFrameTitle(siteTitle);
  if (!normalizedSiteTitle || GENERIC_SHELL_TITLES.has(normalizedSiteTitle)) {
    return GENERIC_SITE_TITLE;
  }

  return `${normalizedSiteTitle} · Iris`;
}

function readFrameTitle(frame: HTMLIFrameElement): string | null {
  try {
    return normalizeFrameTitle(frame.contentDocument?.title);
  } catch {
    return null;
  }
}

function syncFrameTitle(frame: HTMLIFrameElement, onTitleChange: (title: string | null) => void): void {
  onTitleChange(readFrameTitle(frame));
}

export function syncShellTitleFromFrame(
  frame: HTMLIFrameElement,
  onTitleChange: (title: string | null) => void,
): () => void {
  syncFrameTitle(frame, onTitleChange);

  try {
    const head = frame.contentDocument?.head;
    if (!head) {
      return () => {};
    }

    const observer = new MutationObserver(() => {
      syncFrameTitle(frame, onTitleChange);
    });
    observer.observe(head, {
      childList: true,
      subtree: true,
      characterData: true,
    });
    return () => observer.disconnect();
  } catch {
    return () => {};
  }
}
