import { HashtreeWorkerClient, type BlossomServerConfig } from '@hashtree/worker';
import type { RawBlockInput, StoredBlockResult } from '@hashtree/worker/protocol';
import HashtreeWorker from './hashtreeUploadWorker?worker';
import { SITE_UPLOAD_STORE } from './peerRuntime';
import { getRuntimeBlossomServers, getRuntimeWorkerConfig } from './htreeRuntime';

const CONNECTIVITY_POLL_INTERVAL_MS = 15_000;

let client: HashtreeWorkerClient | null = null;
let initPromise: Promise<HashtreeWorkerClient> | null = null;

async function ensureClient(): Promise<HashtreeWorkerClient> {
  if (client) return client;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const created = new HashtreeWorkerClient(HashtreeWorker, getRuntimeWorkerConfig({
      storeName: SITE_UPLOAD_STORE,
      connectivityProbeIntervalMs: CONNECTIVITY_POLL_INTERVAL_MS,
    }));
    await created.init();
    client = created;
    return created;
  })();

  return initPromise;
}

export async function putUploadBlocks(
  blocks: RawBlockInput[],
  blossomServers?: BlossomServerConfig[],
): Promise<StoredBlockResult[]> {
  const worker = await ensureClient();
  await worker.setBlossomServers(blossomServers ?? getRuntimeBlossomServers());
  return worker.putBlocks(blocks, { upload: true });
}
