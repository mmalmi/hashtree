import { pubkeyToNpub, type ProfileRecord } from './contacts';

export interface GlobalPeopleSearchEntry {
  id: string;
  value: string;
  score: number;
  exactMatches?: number;
  prefixDistance?: number;
}

export interface GlobalPeopleProfile extends ProfileRecord {
  createdAt: number;
  socialDistance: number | null;
  searchScore: number;
  searchAliases: string[];
}

interface StoredGlobalPeopleEntry {
  pubkey?: unknown;
  name?: unknown;
  aliases?: unknown;
  nip05?: unknown;
  picture?: unknown;
  follow_distance?: unknown;
  created_at?: unknown;
}

export function parseGlobalPeopleSearchEntry(
  result: GlobalPeopleSearchEntry,
): GlobalPeopleProfile | null {
  try {
    const stored = JSON.parse(result.value) as StoredGlobalPeopleEntry;
    const pubkey = readString(stored.pubkey).toLowerCase();
    if (!isHexPubkey(pubkey) || pubkey !== result.id.trim().toLowerCase()) return null;

    const aliases = Array.isArray(stored.aliases)
      ? stored.aliases.map(readString).filter(Boolean).slice(0, 32)
      : [];
    const name = readString(stored.name) || aliases[0] || pubkeyToNpub(pubkey);
    const followDistance = readNonNegativeInteger(stored.follow_distance);

    return {
      pubkey,
      name,
      displayName: name,
      username: aliases[0] ?? '',
      nickname: aliases[1] ?? '',
      about: '',
      picture: readString(stored.picture),
      nip05: readString(stored.nip05),
      website: '',
      lud16: '',
      createdAt: readNonNegativeInteger(stored.created_at) ?? 0,
      socialDistance: followDistance,
      searchScore: Number.isFinite(result.score) ? result.score : 0,
      searchAliases: aliases,
    };
  } catch {
    return null;
  }
}

export function uniqueGlobalPeopleSearchProfiles(
  profiles: readonly GlobalPeopleProfile[],
): GlobalPeopleProfile[] {
  const unique = new Map<string, GlobalPeopleProfile>();
  for (const profile of profiles) {
    if (!unique.has(profile.pubkey)) unique.set(profile.pubkey, profile);
  }
  return [...unique.values()];
}

export function rankGlobalPeopleSearchProfiles(
  profiles: readonly GlobalPeopleProfile[],
  query: string,
): GlobalPeopleProfile[] {
  return uniqueGlobalPeopleSearchProfiles(profiles)
    .map((profile) => ({ profile, textScore: profileTextScore(profile, query) }))
    .filter((entry) => entry.textScore > 0)
    .sort((left, right) => (
      right.textScore - left.textScore
      || (left.profile.socialDistance ?? 999) - (right.profile.socialDistance ?? 999)
      || right.profile.searchScore - left.profile.searchScore
      || right.profile.createdAt - left.profile.createdAt
      || left.profile.pubkey.localeCompare(right.profile.pubkey)
    ))
    .map(({ profile }) => profile);
}

function profileTextScore(profile: GlobalPeopleProfile, query: string): number {
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return 0;
  const identifiers = [profile.pubkey, pubkeyToNpub(profile.pubkey)].map(normalizeSearchText);
  const nip05 = [profile.nip05, profile.nip05.split('@', 1)[0] ?? ''].map(normalizeSearchText).filter(Boolean);
  const identities = [
    profile.displayName,
    profile.name,
    profile.username,
    profile.nickname,
    ...profile.searchAliases,
  ].map(normalizeSearchText).filter(Boolean);
  const fields = [...identities, ...nip05, ...identifiers];
  const queryWords = words(normalizedQuery);
  const fieldWords = [...new Set(fields.flatMap(words))];

  if (identifiers.includes(normalizedQuery)) return 14_000;
  if (nip05.includes(normalizedQuery)) return 12_000;
  if (identities.includes(normalizedQuery)) return 10_000;
  if (queryWords.length === 1 && fieldWords.includes(normalizedQuery)) return 8_500;
  if (fields.some((field) => field.startsWith(normalizedQuery))) return 7_000;
  if (queryWords.every((term) => fieldWords.some((word) => word.startsWith(term)))) return 5_500;
  if (queryWords.every((term) => fields.some((field) => field.includes(term)))) return 3_500;
  return 0;
}

function normalizeSearchText(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/\p{M}+/gu, '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/gu, ' ');
}

function words(value: string): string[] {
  return value.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
}

function readString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function readNonNegativeInteger(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
    ? Math.trunc(value)
    : null;
}

function isHexPubkey(value: string): boolean {
  return /^[0-9a-f]{64}$/.test(value);
}
