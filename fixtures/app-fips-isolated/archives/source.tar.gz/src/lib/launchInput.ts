import { parseTreeEventSnapshotPermalink } from '@hashtree/nostr';
import { GENERIC_SITE_TITLE, resolveHostedSite, type HostedSite } from './siteConfig';

const PORTAL_HOST = 'apps.iris.to';

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function parseSiteUrl(raw: string): HostedSite | null {
  try {
    const url = new URL(raw);
    const directSite = resolveHostedSite({
      host: url.host,
      hash: url.hash,
      pathname: url.pathname,
    });
    if (directSite) {
      return directSite;
    }

    if (url.hash.startsWith('#/')) {
      return resolveHostedSite({
        host: PORTAL_HOST,
        hash: url.hash,
      });
    }
  } catch {
    // Fall through to bare route parsing.
  }
  return null;
}

function parseImmutableRoute(raw: string): HostedSite | null {
  const snapshotPermalink = parseTreeEventSnapshotPermalink(raw);
  if (snapshotPermalink) {
    return {
      kind: 'immutable',
      siteKey: 'pilot',
      title: GENERIC_SITE_TITLE,
      nhash: snapshotPermalink.snapshotNhash,
      entryPath: snapshotPermalink.path.join('/') || 'index.html',
      snapshot: true,
      ...(snapshotPermalink.linkKey ? { snapshotLinkKey: snapshotPermalink.linkKey } : {}),
    };
  }
  if (raw.includes('snapshot=1')) {
    return null;
  }

  const [pathPart, queryPart = ''] = raw.split('?', 2);
  const [nhash, ...pathParts] = pathPart.split('/').filter(Boolean);
  if (!nhash) return null;

  const params = new URLSearchParams(queryPart);
  return {
    kind: 'immutable',
    siteKey: 'pilot',
    title: GENERIC_SITE_TITLE,
    nhash,
    entryPath: safeDecode(pathParts.join('/') || 'index.html'),
  };
}

function parseHtreeUrl(raw: string): HostedSite | null {
  if (!raw.startsWith('htree://')) return null;

  const target = raw.slice('htree://'.length).replace(/^\/+/, '');
  if (!target) return null;
  if (target.startsWith('nhash1')) {
    return parseImmutableRoute(target);
  }
  if (target.startsWith('npub1')) {
    const [npub, ...treeParts] = target.split('/').filter(Boolean);
    if (!npub || !treeParts.length) return null;
    const treeName = safeDecode(treeParts.join('/'));
    return {
      kind: 'mutable',
      siteKey: 'pilot',
      title: treeName || GENERIC_SITE_TITLE,
      npub,
      treeName,
      entryPath: 'index.html',
    };
  }
  return null;
}

export function parseLaunchInput(raw: string): HostedSite | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return parseSiteUrl(trimmed);
  }

  if (trimmed.startsWith('htree://')) {
    return parseHtreeUrl(trimmed);
  }

  if (trimmed.startsWith('#/')) {
    return resolveHostedSite({
      host: PORTAL_HOST,
      hash: trimmed,
    });
  }

  if (trimmed.startsWith('#nhash1') || trimmed.startsWith('#npub1')) {
    return resolveHostedSite({
      host: PORTAL_HOST,
      hash: trimmed,
    });
  }

  if (trimmed.startsWith('nhash1')) {
    return parseImmutableRoute(trimmed);
  }

  if (trimmed.startsWith('npub1')) {
    const [npub, ...treeParts] = trimmed.split('/').filter(Boolean);
    if (!npub || !treeParts.length) return null;
    const treeName = safeDecode(treeParts.join('/'));
    return {
      kind: 'mutable',
      siteKey: 'pilot',
      title: treeName || GENERIC_SITE_TITLE,
      npub,
      treeName,
      entryPath: 'index.html',
    };
  }

  return null;
}
