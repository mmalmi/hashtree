import App from './App.svelte';
import { mount } from 'svelte';
import './styles/theme.css';
import './styles/launcher.css';
import './styles/runtime.css';

async function initBackgroundServices(): Promise<void> {
  const [{ initServiceWorker }, { initWorkerClient }, { setupMediaStreaming }] = await Promise.all([
    import('./lib/swInit'),
    import('./lib/workerClient'),
    import('./lib/mediaStreamingSetup'),
  ]);
  await initServiceWorker();
  await initWorkerClient();
  await setupMediaStreaming();
}

const app = mount(App, {
  target: document.getElementById('app')!,
});

void initBackgroundServices().catch((error) => {
  console.warn('[iris-sites] Failed to start background services', error);
});

export default app;
