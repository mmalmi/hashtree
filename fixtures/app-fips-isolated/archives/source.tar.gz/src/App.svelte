<script lang="ts">
  import { onMount, tick } from 'svelte';
  import AccountSwitcher from '@iris/svelte-ui/AccountSwitcher.svelte';
  import IdentityRecoveryPanel from '@iris/svelte-ui/IdentityRecoveryPanel.svelte';
  import SocialDistanceBadge from '@iris/svelte-ui/SocialDistanceBadge.svelte';
  import UserRow from '@iris/svelte-ui/UserRow.svelte';
  import { copyToClipboard } from '@iris/svelte-ui/clipboard';
  import {
    identityBootstrapAction,
    normalizeIdentityCreateRequest,
    type IdentityBootstrapMode,
    type IdentityBootstrapSurface,
    type IdentityCreateRequest,
    type IdentityRecoveryMethod,
    type IdentityRecoveryRequest,
  } from '@iris/svelte-ui';
  import {
    coolName,
    getProfileDisplayName,
    getProfileName,
    getProfileNameCandidates,
  } from '@iris/svelte-ui/profile';
  import {
    clearNostrIdentitySession,
    createLocalNostrIdentitySession,
    loadNostrIdentitySession,
    saveNostrIdentitySession,
    type ActiveNostrIdentitySession,
  } from '@iris/identity/session';
  import {
    createNostrIdentitySignerFromNip07,
    createNostrIdentitySignerFromNsec,
    createNostrIdentitySignerFromSeedPhrase,
    type Nip07LikeSigner,
    type NostrIdentityEventSigner,
  } from '@iris/identity/signers';
  import {
    PRIVATE_CONTACTS_STORAGE_KEY,
    compareContacts,
    createPrivateContact,
    decodeNpubInput,
    decodeProfileInput,
    isContactIdentityId,
    mergeContacts,
    parsePrivateContactsExport,
    profileToContact,
    pubkeyToNpub,
    searchContacts,
    serializePrivateContacts,
    type ContactRecord,
    type ProfileRecord,
  } from './lib/contacts';
  import {
    contactPathFor,
    parseContactRoute,
    type ContactRoute,
  } from './lib/contactRoutes';
  import {
    DEFAULT_SOCIAL_GRAPH_ROOT,
    buildContactsFromPubkeys,
    contactFromInitialGraphIdentityId,
    isOvermuted,
    loadInitialSocialGraph,
    startInitialSocialGraphUpdates,
    searchInitialGraphContacts,
    type InitialSocialGraph,
  } from './lib/initialSocialGraph';
  import { loadProfilesByPubkey, DEFAULT_RELAYS } from './lib/nostr';
  import { PUBLIC_RELAY_CONFIG } from './lib/publicRelayConfig';
  import type { GlobalPeopleProfile } from './lib/globalPeopleSearch';
  import {
    irisSocialProfileUrl,
  } from './lib/profileLinks';
  import { IRIS_CONTACTS_REPOSITORY_URL } from './lib/shareUrls';

  const IRIS_OWNER_PUBKEY = DEFAULT_SOCIAL_GRAPH_ROOT;
  const INITIAL_GRAPH_LOADING_STATUS = 'Loading initial Iris social graph...';
  const ACCOUNTS_STORAGE_KEY = 'iris-contacts:accounts:v1';
  const ACTIVE_ACCOUNT_STORAGE_KEY = 'iris-contacts:active-account:v1';
  const IDENTITY_SESSION_STORAGE_KEY = 'iris-contacts:identity-session:v1';
  const NOSTR_IDENTITY_SESSION_STORAGE_KEY = 'iris-contacts:nostr-identity-session:v1';
  const RELATIONSHIPS_STORAGE_KEY = 'iris-contacts:relationships:v1';
  const LIST_PAGE_SIZE = 80;
  const SEARCH_RESULT_LIMIT = 12;
  const PROFILE_LOOKUP_BATCH_SIZE = 12;
  const PROFILE_ABOUT_COLLAPSED_HEIGHT = 96;
  const MAX_FOLLOWED_BY_FRIENDS = 3;
  const CONTACTS_IDENTITY_LOGIN_METHODS: IdentityRecoveryMethod[] = ['nip07', 'nsec', 'seed_phrase'];
  const CONTACTS_IDENTITY_BOOTSTRAP_MODE: IdentityBootstrapMode = 'prompt_on_user_view';

  type ContactView = 'contacts' | 'favorites' | 'frequent' | 'private';
  type AppMode = 'list' | 'detail' | 'profile-graph' | 'settings' | 'create';
  type ProfileGraphDirection = 'followed' | 'followers';
  type SettingsTab = 'account' | 'private' | 'public' | 'muted';

  interface StoredRelationships {
    followedPubkeys?: unknown;
    favoritePubkeys?: unknown;
    favoriteIdentityIds?: unknown;
    mutedPubkeys?: unknown;
    unfollowedPubkeys?: unknown;
  }

  interface StoredAccount {
    pubkey: string;
    addedAt: number;
  }

  interface AccountOption {
    id: string;
    name: string;
    description: string;
    picture: string | null;
    avatarKey: string;
    current: boolean;
    default: boolean;
    removable: boolean;
  }

  interface ContactsIdentitySession {
    schema: 1;
    pubkey: string;
    npub: string;
    method: 'local' | 'nsec' | 'seed_phrase' | 'nip07';
    createdAt: number;
    label?: string;
    profileId?: string;
    appKeyNpub?: string;
  }

  interface ProfileAboutPart {
    text: string;
    href: string | null;
  }

  type EditorIconName = 'person' | 'work' | 'mail' | 'phone' | 'key' | 'place' | 'cake' | 'label' | 'note' | 'trash';

  const editorIconPaths = {
    person: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4Zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4Z',
    work: 'M12 7V3H2v18h20V7H12Zm-2 12H4V5h6v14Zm10 0h-8V9h8v10Zm-6-8h2v2h-2v-2Zm0 4h2v2h-2v-2Zm4-4h2v2h-2v-2Zm0 4h2v2h-2v-2Z',
    mail: 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2Zm0 4-8 5-8-5V6l8 5 8-5v2Z',
    phone: 'M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1C10.85 21 3 13.15 3 4c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.58.11.35.03.74-.25 1.02l-2.2 2.19Z',
    key: 'M12.65 10A6 6 0 1 0 11 15.35L12.65 17H15v2h2v2h4v-4.35L16.35 12h-1.7l-2-2ZM7 12a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z',
    place: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7Zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5Z',
    cake: 'M12 6c.83 0 1.5-.67 1.5-1.5 0-.58-.29-1.1-.75-1.37L12 2l-.75 1.13c-.46.27-.75.79-.75 1.37C10.5 5.33 11.17 6 12 6Zm6 4h-5V7h-2v3H6c-1.1 0-2 .9-2 2v2h16v-2c0-1.1-.9-2-2-2ZM4 16v5h16v-5l-2 1.33L16 16l-2 1.33L12 16l-2 1.33L8 16l-2 1.33L4 16Z',
    label: 'M17.63 5.84C17.27 5.33 16.67 5 16 5H5c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h11c.67 0 1.27-.33 1.63-.84L22 12l-4.37-6.16Z',
    note: 'M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6Zm0 7V3.5L19.5 9H14ZM8 13h8v2H8v-2Zm0 4h8v2H8v-2Z',
    trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12ZM8 9h8v10H8V9Zm7.5-5-1-1h-5l-1 1H5v2h14V4h-3.5Z',
  } satisfies Record<EditorIconName, string>;

  const pendingProfilePubkeys = new Set<string>();

  let query = $state('');
  let globalSearchProfiles = $state<GlobalPeopleProfile[]>([]);
  let globalSearchBusy = $state(false);
  let globalSearchUnavailable = $state(false);
  let activeView = $state<ContactView>('contacts');
  let appMode = $state<AppMode>('list');
  let publicContacts = $state<ContactRecord[]>([]);
  let followerContacts = $state<ContactRecord[]>([]);
  let privateContacts = $state<ContactRecord[]>([]);
  let privateContactsLoaded = $state(false);
  let activeAccountPubkey = $state(IRIS_OWNER_PUBKEY);
  let savedAccounts = $state<StoredAccount[]>([]);
  let accountsLoaded = $state(false);
  let accountInput = $state('');
  let accountError = $state('');
  let identitySession = $state<ContactsIdentitySession | null>(null);
  let identitySessionLoaded = $state(false);
  let identityLoginError = $state('');
  let identityLoginBusy = $state(false);
  let identityCreateBusy = $state(false);
  let identityPromptSurface = $state<IdentityBootstrapSurface | null>(null);
  let hasNostrExtension = $state(false);
  let activeSettingsTab = $state<SettingsTab>('account');
  let followedPubkeys = $state<string[]>([]);
  let favoritePubkeys = $state<string[]>([]);
  let favoriteIdentityIds = $state<string[]>([]);
  let mutedPubkeys = $state<string[]>([]);
  let relationshipsLoaded = $state(false);
  let unfollowedPubkeys = $state<string[]>([]);
  let initialGraph = $state<InitialSocialGraph | null>(null);
  let initialGraphLoaded = $state(false);
  let relayProfilesByPubkey = $state<Record<string, ProfileRecord>>({});
  let missingProfilePubkeys = $state<string[]>([]);
  let selectedId = $state<string | null>(null);
  let openedContact = $state<ContactRecord | null>(null);
  let profileGraphDirection = $state<ProfileGraphDirection>('followed');
  let currentRoute = $state<ContactRoute>({ kind: 'home', canonicalPath: '/' });
  let routeInitialized = $state(false);
  let isContactMenuOpen = $state(false);
  let isSearchFocused = $state(false);
  let searchResultIndex = $state(0);
  let visibleContactLimit = $state(LIST_PAGE_SIZE);
  let loadMoreSentinel = $state<HTMLElement | null>(null);
  let profileAboutElement = $state<HTMLElement | null>(null);
  let isProfileAboutExpanded = $state(false);
  let isProfileAboutOverflowing = $state(false);
  let profileAboutResetKey = '';
  let isProfilePhotoModalOpen = $state(false);
  let selectedNotesDraftKey = $state('');
  let selectedNotesSavedValue = $state('');
  let selectedNotesDraft = $state('');
  let status = $state(INITIAL_GRAPH_LOADING_STATUS);
  let editingContactId = $state<string | null>(null);
  let newFirstName = $state('');
  let newLastName = $state('');
  let newHandle = $state('');
  let newCompany = $state('');
  let newJobTitle = $state('');
  let newEmail = $state('');
  let newPhone = $state('');
  let newAddress = $state('');
  let newBirthday = $state('');
  let newGroups = $state('');
  let newNotes = $state('');
  let importText = $state('');
  let graphLoadSerial = 0;
  let stopGraphUpdates: (() => void) | undefined;
  let loadedAccountPubkey = '';
  let appEntryIdentityBootstrapHandled = false;

  const followedPubkeySet = $derived(new Set(followedPubkeys));
  const favoritePubkeySet = $derived(new Set(favoritePubkeys));
  const favoriteIdentityIdSet = $derived(new Set(favoriteIdentityIds));
  const mutedPubkeySet = $derived(new Set(mutedPubkeys));
  const unfollowedPubkeySet = $derived(new Set(unfollowedPubkeys));
  const relationshipPublicContacts = $derived(
    publicContacts
      .filter((contact) => !isMutedContact(contact) && !isUnfollowedContact(contact))
      .map((contact) => relationshipAdjustedContact(contact)),
  );
  const relationshipFollowerContacts = $derived(
    followerContacts
      .filter((contact) => !isMutedContact(contact))
      .map((contact) => relationshipAdjustedContact(contact)),
  );
  const relationshipPrivateContacts = $derived(
    privateContacts.filter((contact) => !isMutedContact(contact)),
  );
  const allContacts = $derived(mergeContacts(combinedPublicGraphContacts(), relationshipPrivateContacts));
  const favoriteContacts = $derived(favoriteContactsForView());
  const visibleContacts = $derived(contactsForView(activeView));
  const listContacts = $derived(visibleContacts.slice(0, visibleContactLimit));
  const hasMoreVisibleContacts = $derived(listContacts.length < visibleContacts.length);
  const searchQuery = $derived(query.trim());
  const loadedSearchContacts = $derived(searchQuery ? searchContacts(allContacts, searchQuery) : []);
  const globalSearchContacts = $derived(
    globalSearchProfiles
      .map((profile) => globalProfileToContact(profile))
      .filter((contact) => !isMutedContact(contact) && !isUnfollowedContact(contact))
      .map((contact) => relationshipAdjustedContact(contact)),
  );
  const seededSearchContacts = $derived(
    searchQuery && initialGraph
      ? searchInitialGraphContacts(initialGraph, searchQuery, {
          excludePubkeys: excludedSearchPubkeys(allContacts),
          limit: SEARCH_RESULT_LIMIT,
        })
          .filter((contact) => !isMutedContact(contact) && !isUnfollowedContact(contact))
          .map((contact) => relationshipAdjustedContact(contact))
      : [],
  );
  const exactSearchPubkey = $derived(searchQuery ? decodeProfileInput(searchQuery) : null);
  const exactSearchContact = $derived(exactSearchPubkey ? exactSearchContactForPubkey(exactSearchPubkey) : null);
  const searchResultContacts = $derived(
    uniqueSearchContacts([
      ...loadedSearchContacts,
      ...globalSearchContacts,
      ...seededSearchContacts,
      ...(exactSearchContact ? [exactSearchContact] : []),
    ]).slice(0, SEARCH_RESULT_LIMIT),
  );
  const isSearchDropdownOpen = $derived(Boolean(searchQuery && isSearchFocused));
  const selectedContact = $derived(
    (appMode === 'detail' || appMode === 'profile-graph') && openedContact
      ? relationshipAdjustedContact(openedContact)
      : visibleContacts.find((contact) => contact.id === selectedId)
      ?? visibleContacts[0]
      ?? null,
  );
  const selectedProfileFollowedContacts = $derived(profileGraphContacts(selectedContact, 'followed'));
  const selectedProfileFollowerContacts = $derived(profileGraphContacts(selectedContact, 'followers'));
  const selectedProfileGraphContacts = $derived(
    profileGraphDirection === 'followed' ? selectedProfileFollowedContacts : selectedProfileFollowerContacts,
  );
  const profileHydrationPubkeys = $derived(unresolvedProfilePubkeys([
    ...listContacts,
    ...searchResultContacts,
    ...(selectedContact ? [selectedContact] : []),
    ...selectedProfileFollowedContacts,
    ...selectedProfileFollowerContacts,
  ]));
  const publicCount = $derived(publicContacts.length);
  const privateCount = $derived(privateContacts.length);
  const favoriteCount = $derived(favoriteContacts.length);
  const frequentCount = $derived(allContacts.filter(isFrequentContact).length);
  const mutedCount = $derived(mutedPubkeys.length);
  const loggedInPubkey = $derived(identitySession?.pubkey ?? null);
  const identityProfile = $derived(loggedInPubkey ? profileForPubkey(loggedInPubkey) ?? null : null);
  const identityName = $derived(
    loggedInPubkey
      ? getProfileDisplayName(
        identityProfile,
        loggedInPubkey,
        null,
        identitySession?.profileId ? identitySession.label ?? 'Contacts identity' : coolName(loggedInPubkey),
      )
      : 'Sign in',
  );
  const identityHandle = $derived(identityHandleLabel());
  const identityInitial = $derived((identityName || '+').charAt(0).toUpperCase());
  const showIdentityCreatePrompt = $derived(Boolean(identityPromptSurface && !identitySession));
  const identityCreatePromptTitle = $derived(
    identityPromptSurface === 'app_entry'
      ? 'Create your Contacts identity'
      : 'Create your identity',
  );
  const activeAccountLabel = $derived(accountDisplayLabel(activeAccountPubkey));
  const activeAccountHandle = $derived(accountHandleLabel(activeAccountPubkey));
  const accountOptions = $derived(accountListOptions());
  const draftContactName = $derived([newFirstName, newLastName].map((part) => part.trim()).filter(Boolean).join(' '));
  const editorTitle = $derived(editingContactId ? 'Edit contact' : 'Create contact');
  const editorSubtitle = $derived(editingContactId ? 'Private changes' : 'Private contact');
  const identifierValidationMessage = $derived(privateIdentifierValidationMessage(newHandle));
  const shouldShowStatus = $derived(Boolean(status) && (appMode === 'list' || !isAmbientLoadingStatus(status)));
  const hasPrivateContactDraft = $derived(Boolean(
    draftContactName ||
    newEmail.trim() ||
    newPhone.trim() ||
    newHandle.trim() ||
    newCompany.trim() ||
    newJobTitle.trim() ||
    newAddress.trim() ||
    newBirthday.trim() ||
    newGroups.trim() ||
    newNotes.trim(),
  ));
  const canSavePrivateContact = $derived(hasPrivateContactDraft && !identifierValidationMessage);
  const selectedSocialProfileUrl = $derived(selectedContact ? irisSocialProfileUrl(selectedContact) : null);
  const selectedNpub = $derived(selectedContact ? copyableNpub(selectedContact) : null);
  const selectedIsOwnerProfile = $derived(Boolean(loggedInPubkey && selectedContact?.pubkey === loggedInPubkey));
  const selectedProfileAbout = $derived(selectedContact ? contactAbout(selectedContact) : '');
  const selectedProfileAboutParts = $derived(linkifyProfileAbout(selectedProfileAbout));
  const isProfileAboutClamped = $derived(isProfileAboutOverflowing && !isProfileAboutExpanded);
  const selectedFollowedByFriendPubkeys = $derived(followedByFriendPubkeys(selectedContact));
  const selectedFollowedByFriendContacts = $derived(followedByContacts(selectedFollowedByFriendPubkeys));
  const selectedFollowedByFriendRemaining = $derived(Math.max(0, selectedFollowedByFriendPubkeys.length - selectedFollowedByFriendContacts.length));
  const selectedFollowsActiveAccount = $derived(followsActiveAccount(selectedContact));

  $effect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem(PRIVATE_CONTACTS_STORAGE_KEY);
    if (!stored) {
      privateContactsLoaded = true;
      return;
    }
    try {
      privateContacts = parsePrivateContactsExport(stored);
    } catch {
      privateContacts = [];
    } finally {
      privateContactsLoaded = true;
    }
  });

  $effect(() => {
    if (typeof window === 'undefined' || !privateContactsLoaded) return;
    window.localStorage.setItem(PRIVATE_CONTACTS_STORAGE_KEY, serializePrivateContacts(privateContacts));
  });

  $effect(() => {
    if (typeof window === 'undefined') return;
    const storedAccounts = window.localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    const storedActiveAccount = window.localStorage.getItem(ACTIVE_ACCOUNT_STORAGE_KEY);
    savedAccounts = parseStoredAccounts(storedAccounts);
    activeAccountPubkey = decodeProfileInput(storedActiveAccount || '') ?? IRIS_OWNER_PUBKEY;
    accountsLoaded = true;
  });

  $effect(() => {
    if (typeof window === 'undefined') return;
    identitySession = loadContactsIdentitySession(window.localStorage.getItem(IDENTITY_SESSION_STORAGE_KEY))
      ?? loadStoredNostrIdentitySession();
    hasNostrExtension = Boolean(browserNostrSigner());
    identitySessionLoaded = true;
  });

  $effect(() => {
    if (typeof window === 'undefined' || !accountsLoaded) return;
    window.localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify({
      version: 1,
      accounts: savedAccounts,
    }));
    window.localStorage.setItem(ACTIVE_ACCOUNT_STORAGE_KEY, pubkeyToNpub(activeAccountPubkey));
  });

  $effect(() => {
    if (typeof window === 'undefined' || !identitySessionLoaded) return;
    if (identitySession) {
      window.localStorage.setItem(IDENTITY_SESSION_STORAGE_KEY, JSON.stringify(identitySession));
    } else {
      window.localStorage.removeItem(IDENTITY_SESSION_STORAGE_KEY);
    }
  });

  $effect(() => {
    if (!identitySessionLoaded || !routeInitialized || appEntryIdentityBootstrapHandled) return;
    const action = identityBootstrapAction({
      mode: CONTACTS_IDENTITY_BOOTSTRAP_MODE,
      hasIdentity: Boolean(identitySession),
      surface: 'app_entry',
    });
    if (action === 'none') return;
    if (action === 'prompt' && currentRoute.kind !== 'home') return;

    appEntryIdentityBootstrapHandled = true;
    if (action === 'create') {
      void createLocalContactsIdentity();
      return;
    }
    openIdentityPrompt('app_entry');
  });

  $effect(() => {
    if (!routeInitialized || !accountsLoaded) return;
    if (loadedAccountPubkey === activeAccountPubkey) return;
    loadedAccountPubkey = activeAccountPubkey;
    publicContacts = [];
    followerContacts = [];
    initialGraph = null;
    initialGraphLoaded = false;
    if (status === INITIAL_GRAPH_LOADING_STATUS || status.startsWith('Loading contacts for ')) {
      status = loadingAccountStatus(activeAccountPubkey);
    }
    reloadInitialGraph();
  });

  $effect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem(RELATIONSHIPS_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as StoredRelationships;
        followedPubkeys = normalizePubkeyList(parsed.followedPubkeys);
        favoritePubkeys = normalizePubkeyList(parsed.favoritePubkeys);
        favoriteIdentityIds = normalizeIdentityIdList(parsed.favoriteIdentityIds);
        mutedPubkeys = normalizePubkeyList(parsed.mutedPubkeys);
        unfollowedPubkeys = normalizePubkeyList(parsed.unfollowedPubkeys);
      } catch {
        followedPubkeys = [];
        favoritePubkeys = [];
        favoriteIdentityIds = [];
        mutedPubkeys = [];
        unfollowedPubkeys = [];
      }
    }
    relationshipsLoaded = true;
  });

  $effect(() => {
    if (typeof window === 'undefined' || !relationshipsLoaded) return;
    window.localStorage.setItem(RELATIONSHIPS_STORAGE_KEY, JSON.stringify({
      followedPubkeys,
      favoritePubkeys,
      favoriteIdentityIds,
      mutedPubkeys,
      unfollowedPubkeys,
    }));
  });

  $effect(() => {
    if (typeof document === 'undefined' || typeof window === 'undefined') return;
    document.documentElement.removeAttribute('data-theme');
    window.localStorage.removeItem('iris-contacts:theme:v1');
  });

  $effect(() => {
    activeView;
    visibleContactLimit = LIST_PAGE_SIZE;
  });

  $effect(() => {
    searchQuery;
    searchResultContacts.length;
    searchResultIndex = 0;
  });

  $effect(() => {
    const nextQuery = searchQuery;
    const controller = new AbortController();
    globalSearchProfiles = [];
    globalSearchUnavailable = false;
    if (nextQuery.length < 2) {
      globalSearchBusy = false;
      return () => controller.abort();
    }

    globalSearchBusy = true;
    const timer = window.setTimeout(() => {
      void import('./lib/globalPeopleSearchRuntime')
        .then(({ searchGlobalPeople }) => searchGlobalPeople(nextQuery, SEARCH_RESULT_LIMIT, controller.signal))
        .then((profiles) => {
          if (!controller.signal.aborted && searchQuery === nextQuery) {
            globalSearchProfiles = profiles;
          }
        })
        .catch(() => {
          if (!controller.signal.aborted && searchQuery === nextQuery) {
            globalSearchUnavailable = true;
          }
        })
        .finally(() => {
          if (!controller.signal.aborted && searchQuery === nextQuery) {
            globalSearchBusy = false;
          }
        });
    }, 120);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  });

  $effect(() => {
    const nextKey = `${selectedContact?.id ?? ''}\u0000${selectedProfileAbout}`;
    if (nextKey === profileAboutResetKey) return;
    profileAboutResetKey = nextKey;
    isProfileAboutExpanded = false;
  });

  $effect(() => {
    selectedContact?.id;
    selectedContact ? contactPicture(selectedContact) : '';
    isProfilePhotoModalOpen = false;
  });

  $effect(() => {
    const key = selectedContact ? localNotesKey(selectedContact) : '';
    const notes = selectedContact?.notes ?? '';
    if (selectedNotesDraftKey !== key) {
      selectedNotesDraftKey = key;
      selectedNotesSavedValue = notes;
      selectedNotesDraft = notes;
      return;
    }
    if (selectedNotesSavedValue !== notes) {
      if (selectedNotesDraft === selectedNotesSavedValue) {
        selectedNotesDraft = notes;
      }
      selectedNotesSavedValue = notes;
    }
  });

  $effect(() => {
    profileAboutElement;
    selectedProfileAbout;
    isProfileAboutExpanded;
    void tick().then(measureProfileAboutOverflow);
  });

  $effect(() => {
    if (typeof IntersectionObserver === 'undefined' || !loadMoreSentinel) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        loadMoreVisibleContacts();
      }
    }, {
      rootMargin: '320px 0px',
    });
    observer.observe(loadMoreSentinel);
    return () => observer.disconnect();
  });

  $effect(() => {
    if (!routeInitialized) return;
    resolveCurrentRoute();
  });

  $effect(() => {
    const pubkeys = [...profileHydrationPubkeys, ...mutedPubkeys, activeAccountPubkey, loggedInPubkey]
      .filter((pubkey): pubkey is string => typeof pubkey === 'string' && needsRelayProfile(pubkey))
      .slice(0, PROFILE_LOOKUP_BATCH_SIZE);
    requestRelayProfiles(pubkeys);
  });

  onMount(() => {
    let cancelled = false;
    syncRouteFromLocation();
    routeInitialized = true;
    const handlePopstate = () => syncRouteFromLocation();
    const handleResize = () => measureProfileAboutOverflow();
    const refreshNostrExtension = () => {
      hasNostrExtension = Boolean(browserNostrSigner());
    };
    refreshNostrExtension();
    const extensionTimer = window.setTimeout(refreshNostrExtension, 1200);
    window.addEventListener('popstate', handlePopstate);
    window.addEventListener('resize', handleResize);
    return () => {
      cancelled = true;
      graphLoadSerial += 1;
      stopGraphUpdates?.();
      window.clearTimeout(extensionTimer);
      window.removeEventListener('popstate', handlePopstate);
      window.removeEventListener('resize', handleResize);
    };
  });

  function reloadInitialGraph(isCancelled: () => boolean = () => false): void {
    stopGraphUpdates?.();
    stopGraphUpdates = undefined;
    const serial = ++graphLoadSerial;
    void initializeInitialGraph(() => isCancelled() || serial !== graphLoadSerial, activeAccountPubkey);
  }

  async function initializeInitialGraph(isCancelled: () => boolean, ownerPubkey: string): Promise<void> {
    initialGraphLoaded = false;
    try {
      const graph = await loadInitialSocialGraph(ownerPubkey);
      if (isCancelled()) return;
      initialGraph = graph;
      initialGraphLoaded = true;
      followerContacts = graph.followerContacts;
      if (publicContacts.length === 0) {
        publicContacts = withLocallyFollowedContacts(graph.directContacts, graph);
        selectedId = graph.directContacts[0]?.id ?? selectedId;
      }
      if (status === INITIAL_GRAPH_LOADING_STATUS) {
        status = `Loaded ${graph.directContacts.length} contacts from the initial Iris social graph; search covers ${graph.profileCount} profiles.`;
      }
      stopGraphUpdates = startInitialSocialGraphUpdates(graph, DEFAULT_RELAYS, PUBLIC_RELAY_CONFIG.useDefaultBootstrap, updated => {
        if (isCancelled()) return;
        initialGraph = updated;
        followerContacts = updated.followerContacts;
        publicContacts = withLocallyFollowedContacts(updated.directContacts, updated);
      });
    } catch (error) {
      if (isCancelled()) return;
      initialGraphLoaded = true;
      status = error instanceof Error
        ? `Initial social graph unavailable: ${error.message}`
        : 'Initial social graph unavailable.';
    }
  }

  function syncRouteFromLocation(): void {
    if (typeof window === 'undefined') return;
    const route = parseContactRoute(window.location.pathname);
    currentRoute = route;
    if (route.kind !== 'unknown' && route.canonicalPath !== window.location.pathname) {
      setBrowserPath(route.canonicalPath, 'replace');
    }
  }

  function resolveCurrentRoute(): void {
    if (currentRoute.kind === 'home') {
      if (appMode !== 'list' || openedContact) {
        appMode = 'list';
        openedContact = null;
        isContactMenuOpen = false;
      }
      return;
    }

    if (currentRoute.kind === 'settings') {
      appMode = 'settings';
      openedContact = null;
      isContactMenuOpen = false;
      return;
    }

    if (currentRoute.kind === 'create') {
      appMode = 'create';
      openedContact = null;
      isContactMenuOpen = false;
      return;
    }

    if (appMode === 'profile-graph' && openedContact && routeMatchesContact(currentRoute, openedContact)) {
      return;
    }

    if (currentRoute.kind === 'profile') {
      const contact = contactForPubkey(currentRoute.pubkey);
      if (contact) {
        showRoutedContact(contact);
        replaceRouteWithContactPath(contact);
        return;
      }

      if (!initialGraph) {
        appMode = 'list';
        openedContact = null;
        status = 'Loading profile...';
        return;
      }

      const [graphContact] = searchInitialGraphContacts(initialGraph, currentRoute.pubkey, {
        hideOvermuted: false,
        limit: 1,
      });
      const routedContact = graphContact ?? profileToContact(
        currentRoute.pubkey,
        initialGraph.profileByPubkey.get(currentRoute.pubkey),
        initialGraph.graph,
      );
      showRoutedContact(routedContact);
      if (initialGraph.profileByPubkey.has(currentRoute.pubkey)) {
        replaceRouteWithContactPath(routedContact);
      }
      return;
    }

    if (currentRoute.kind === 'contact') {
      const contact = contactForIdentityId(currentRoute.id);
      if (contact) {
        showRoutedContact(contact);
        return;
      }

      if (!privateContactsLoaded || !initialGraphLoaded) {
        appMode = 'list';
        openedContact = null;
        status = 'Loading profile...';
        return;
      }
      appMode = 'list';
      openedContact = null;
      selectedId = null;
      status = 'Contact not found in this browser.';
      return;
    }

    appMode = 'list';
    openedContact = null;
    selectedId = null;
    status = 'Contact route not found.';
  }

  function routeMatchesContact(route: ContactRoute, contact: ContactRecord): boolean {
    if (route.kind === 'profile') return contact.pubkey === route.pubkey;
    if (route.kind === 'contact') return contact.id === route.id || contact.identity.id === route.id;
    return false;
  }

  function showRoutedContact(contact: ContactRecord): void {
    selectedId = contact.id;
    openedContact = contact;
    appMode = 'detail';
    isContactMenuOpen = false;
    if (status === 'Loading profile...') {
      status = '';
    }
  }

  function replaceRouteWithContactPath(contact: ContactRecord): void {
    if (!canResolveContactPath(contact)) return;
    setContactRoute(contact, 'replace');
  }

  function canResolveContactPath(contact: ContactRecord): boolean {
    if (!contact.pubkey) return true;
    if (allContacts.some((candidate) => candidate.id === contact.id || candidate.identity.id === contact.identity.id)) return true;
    if (privateContacts.some((candidate) => candidate.id === contact.id || candidate.identity.id === contact.identity.id)) return true;
    return Boolean(initialGraph?.profileByPubkey.has(contact.pubkey));
  }

  function contactForPubkey(pubkey: string): ContactRecord | null {
    return allContacts.find((contact) => contact.pubkey === pubkey)
      ?? privateContacts.find((contact) => contact.pubkey === pubkey)
      ?? publicContacts.find((contact) => contact.pubkey === pubkey)
      ?? followerContacts.find((contact) => contact.pubkey === pubkey)
      ?? (loggedInPubkey && pubkey === loggedInPubkey ? ownerProfileContact() : null)
      ?? (openedContact?.pubkey === pubkey ? openedContact : null);
  }

  function ownerProfileContact(): ContactRecord | null {
    if (!initialGraph || !loggedInPubkey) return null;
    return profileToContact(loggedInPubkey, identityProfile ?? undefined, initialGraph.graph);
  }

  function contactForIdentityId(id: string): ContactRecord | null {
    return allContacts.find((contact) => contact.id === id || contact.identity.id === id)
      ?? privateContacts.find((contact) => contact.id === id || contact.identity.id === id)
      ?? (initialGraph ? contactFromInitialGraphIdentityId(initialGraph, id) : null)
      ?? null;
  }

  function setBrowserPath(path: string, mode: 'push' | 'replace'): void {
    if (typeof window === 'undefined') return;
    const url = new URL(window.location.href);
    if (url.pathname === path && !url.search && !url.hash) return;
    url.pathname = path;
    url.search = '';
    url.hash = '';
    if (mode === 'replace') {
      window.history.replaceState({}, '', url);
    } else {
      window.history.pushState({}, '', url);
    }
    currentRoute = parseContactRoute(url.pathname);
  }

  function setContactRoute(contact: ContactRecord, mode: 'push' | 'replace'): void {
    setBrowserPath(contactPathFor(contact), mode);
  }

  function savePrivateContact(): void {
    if (!canSavePrivateContact) return;
    const pubkey = decodeNpubInput(newHandle) ?? null;
    const draftContact = createPrivateContact({
      name: draftContactName,
      email: newEmail,
      phone: newPhone,
      company: newCompany,
      jobTitle: newJobTitle,
      address: newAddress,
      birthday: newBirthday,
      notes: newNotes,
      groups: newGroups.split(','),
      pubkey,
    });
    const existingPrivateContact = editingContactId
      ? privateContacts.find((contact) => contact.id === editingContactId || contact.identity.id === editingContactId)
        ?? (pubkey ? privateContacts.find((contact) => contact.pubkey === pubkey) : null)
      : null;
    const contact = existingPrivateContact
      ? preserveEditedContactIdentity(draftContact, existingPrivateContact)
      : draftContact;

    privateContacts = existingPrivateContact
      ? privateContacts.map((privateContact) => privateContact.id === existingPrivateContact.id ? contact : privateContact)
      : [contact, ...privateContacts];
    editingContactId = null;
    resetPrivateContactDraft();
    status = existingPrivateContact ? 'Saved changes locally.' : 'Saved private contact locally.';
    openContact(contact);
  }

  function handleSelectedNotesInput(event: Event): void {
    autosaveSelectedNotes((event.currentTarget as HTMLTextAreaElement).value);
  }

  function autosaveSelectedNotes(nextNotes: string): void {
    selectedNotesDraft = nextNotes;
    if (!selectedContact) return;
    const notes = nextNotes;
    if (notes === selectedNotesSavedValue) return;
    const existingPrivateContact = privateContactForLocalNotes(selectedContact);
    const updatedPrivateContact = existingPrivateContact
      ? {
          ...existingPrivateContact,
          notes,
          updatedAt: Date.now(),
        }
      : privateContactFromContact(selectedContact, notes);

    privateContacts = existingPrivateContact
      ? privateContacts.map((contact) => contact.id === existingPrivateContact.id ? updatedPrivateContact : contact)
      : [updatedPrivateContact, ...privateContacts];

    const displayContact = contactWithLocalNotes(selectedContact, updatedPrivateContact);
    openedContact = displayContact;
    selectedId = displayContact.id;
    selectedNotesDraft = notes;
    selectedNotesSavedValue = notes;
    selectedNotesDraftKey = localNotesKey(displayContact);
    setContactRoute(displayContact, 'replace');
  }

  function handleCreateContactSubmit(event: SubmitEvent): void {
    event.preventDefault();
    savePrivateContact();
  }

  function preserveEditedContactIdentity(draftContact: ContactRecord, existingContact: ContactRecord): ContactRecord {
    return {
      ...draftContact,
      id: existingContact.id,
      identity: {
        ...draftContact.identity,
        id: existingContact.identity.id,
        createdAt: existingContact.identity.createdAt,
      },
    };
  }

  function privateContactForLocalNotes(contact: ContactRecord): ContactRecord | null {
    if (contact.pubkey) {
      return privateContacts.find((privateContact) => privateContact.pubkey === contact.pubkey) ?? null;
    }
    return privateContacts.find((privateContact) => (
      privateContact.id === contact.id || privateContact.identity.id === contact.identity.id
    )) ?? null;
  }

  function privateContactFromContact(contact: ContactRecord, notes: string): ContactRecord {
    return createPrivateContact({
      name: contactDisplayName(contact),
      handle: contact.handle,
      email: contact.email,
      phone: contact.phone,
      company: contact.company,
      jobTitle: contact.jobTitle,
      address: contact.address,
      birthday: contact.birthday,
      notes,
      groups: contact.groups,
      pubkey: contact.pubkey,
    });
  }

  function contactWithLocalNotes(contact: ContactRecord, privateContact: ContactRecord): ContactRecord {
    return {
      ...contact,
      id: privateContact.id,
      identity: privateContact.identity,
      source: 'private',
      groups: privateContact.groups.length ? privateContact.groups : contact.groups,
      notes: privateContact.notes,
      name: privateContact.name || contact.name,
      handle: privateContact.handle || contact.handle,
      email: privateContact.email || contact.email,
      phone: privateContact.phone || contact.phone,
      company: privateContact.company || contact.company,
      jobTitle: privateContact.jobTitle || contact.jobTitle,
      address: privateContact.address || contact.address,
      birthday: privateContact.birthday || contact.birthday,
      updatedAt: Math.max(contact.updatedAt, privateContact.updatedAt),
    };
  }

  function localNotesKey(contact: ContactRecord): string {
    return contact.pubkey ? `pubkey:${contact.pubkey}` : `identity:${contact.identity.id || contact.id}`;
  }

  function resetPrivateContactDraft(): void {
    newFirstName = '';
    newLastName = '';
    newHandle = '';
    newCompany = '';
    newJobTitle = '';
    newEmail = '';
    newPhone = '';
    newAddress = '';
    newBirthday = '';
    newGroups = '';
    newNotes = '';
  }

  function deleteSelectedContact(): void {
    if (!selectedContact) return;
    favoritePubkeys = selectedContact.pubkey ? removePubkey(favoritePubkeys, selectedContact.pubkey) : favoritePubkeys;
    favoriteIdentityIds = removeIdentityId(favoriteIdentityIds, selectedContact.identity.id);
    favoriteIdentityIds = removeIdentityId(favoriteIdentityIds, selectedContact.id);
    if (selectedContact.source === 'private') {
      privateContacts = privateContacts.filter((contact) => contact.id !== selectedContact.id);
      status = 'Removed private contact.';
    } else if (selectedContact.pubkey) {
      publicContacts = publicContacts.filter((contact) => contact.pubkey !== selectedContact.pubkey);
      status = 'Hidden public contact for this session.';
    }
    selectedId = null;
    openedContact = null;
    editingContactId = null;
    appMode = 'list';
    setBrowserPath('/', 'push');
    focusSelectedRow();
  }

  function setActiveView(view: ContactView): void {
    activeView = view;
    selectedId = null;
    openedContact = null;
    editingContactId = null;
    appMode = 'list';
    setBrowserPath('/', 'push');
  }

  function openContact(contact: ContactRecord): void {
    selectedId = contact.id;
    openedContact = contact;
    editingContactId = null;
    appMode = 'detail';
    isContactMenuOpen = false;
    setContactRoute(contact, 'push');
    setTimeout(() => document.querySelector<HTMLElement>('.contact-detail-page .back-button')?.focus(), 0);
  }

  function openProfileGraph(direction: ProfileGraphDirection): void {
    if (!selectedContact?.pubkey) return;
    openedContact = selectedContact;
    profileGraphDirection = direction;
    editingContactId = null;
    appMode = 'profile-graph';
    isContactMenuOpen = false;
    setTimeout(() => document.querySelector<HTMLElement>('.profile-graph-page .back-button')?.focus(), 0);
  }

  function openProfileDetail(): void {
    if (!openedContact) return;
    appMode = 'detail';
    isContactMenuOpen = false;
    setContactRoute(openedContact, 'replace');
    setTimeout(() => document.querySelector<HTMLElement>('.contact-detail-page .back-button')?.focus(), 0);
  }

  function openOwnerProfile(): void {
    if (!loggedInPubkey) {
      enterIdentitySurface('user_view');
      return;
    }
    editingContactId = null;
    isContactMenuOpen = false;
    activeView = 'contacts';
    const contact = ownerProfileContact();
    if (contact) {
      showRoutedContact(contact);
      setContactRoute(contact, 'push');
      return;
    }
    setBrowserPath(`/${pubkeyToNpub(loggedInPubkey)}`, 'push');
    appMode = 'list';
    openedContact = null;
    status = 'Loading profile...';
  }

  function enterIdentitySurface(surface: IdentityBootstrapSurface): void {
    const action = identityBootstrapAction({
      mode: CONTACTS_IDENTITY_BOOTSTRAP_MODE,
      hasIdentity: Boolean(loggedInPubkey),
      surface,
    });
    if (action === 'create') {
      void createLocalContactsIdentity();
      return;
    }
    if (action === 'prompt') {
      openIdentityPrompt(surface);
      return;
    }
    openSettings();
  }

  function openIdentityPrompt(surface: IdentityBootstrapSurface): void {
    identityPromptSurface = surface;
    openSettingsPanel();
    setTimeout(() => document.querySelector<HTMLInputElement>('[data-testid="identity-create-name"]')?.focus(), 0);
  }

  function openSettingsPanel(): void {
    appMode = 'settings';
    openedContact = null;
    editingContactId = null;
    isContactMenuOpen = false;
    activeSettingsTab = 'account';
    setBrowserPath('/settings', 'push');
  }

  function openSettings(): void {
    identityPromptSurface = null;
    openSettingsPanel();
  }

  function openAccountSettings(): void {
    openSettings();
    activeSettingsTab = 'public';
    setTimeout(() => document.querySelector<HTMLInputElement>('.account-switch-card input')?.focus(), 0);
  }

  function closePanel(): void {
    appMode = 'list';
    openedContact = null;
    editingContactId = null;
    identityPromptSurface = null;
    isContactMenuOpen = false;
    setBrowserPath('/', 'push');
    focusSelectedRow();
  }

  function navigateHome(): void {
    closePanel();
  }

  function openCreateContact(options: { reset?: boolean } = {}): void {
    if (options.reset ?? true) {
      resetPrivateContactDraft();
    }
    editingContactId = null;
    activeView = 'private';
    appMode = 'create';
    openedContact = null;
    isContactMenuOpen = false;
    setBrowserPath('/new', 'push');
    setTimeout(() => document.getElementById('private-contact-name')?.focus(), 0);
  }

  function openEditContact(contact: ContactRecord | null = selectedContact): void {
    if (!contact) return;
    fillPrivateContactDraft(contact);
    editingContactId = contact.id;
    activeView = 'private';
    appMode = 'create';
    openedContact = null;
    isContactMenuOpen = false;
    setBrowserPath('/new', 'push');
  }

  function fillPrivateContactDraft(contact: ContactRecord): void {
    const [firstName, ...lastNameParts] = contact.name.trim().split(/\s+/).filter(Boolean);
    newFirstName = firstName ?? '';
    newLastName = lastNameParts.join(' ');
    newHandle = contact.npub ?? '';
    newCompany = contact.company;
    newJobTitle = contact.jobTitle;
    newEmail = contact.email;
    newPhone = contact.phone;
    newAddress = contact.address;
    newBirthday = contact.birthday;
    newGroups = contact.groups.join(', ');
    newNotes = contact.notes;
  }

  function toggleFollowSelected(): void {
    if (!selectedContact?.pubkey) return;
    if (isMutedContact(selectedContact)) {
      unmutePubkey(selectedContact.pubkey);
      return;
    }
    if (isFollowingContact(selectedContact)) {
      unfollowContact(selectedContact);
    } else {
      followContact(selectedContact);
    }
  }

  function followContact(contact: ContactRecord): void {
    if (!contact.pubkey) return;
    const pubkey = contact.pubkey;
    followedPubkeys = addPubkey(followedPubkeys, pubkey);
    unfollowedPubkeys = removePubkey(unfollowedPubkeys, pubkey);
    mutedPubkeys = removePubkey(mutedPubkeys, pubkey);
    publicContacts = upsertPublicContact(publicContacts, relationshipAdjustedContact(contact));
    selectedId = contact.id;
    status = `Following ${contactDisplayName(contact)} locally. Publishing follows is not enabled yet.`;
  }

  function unfollowContact(contact: ContactRecord): void {
    if (!contact.pubkey) return;
    const pubkey = contact.pubkey;
    followedPubkeys = removePubkey(followedPubkeys, pubkey);
    unfollowedPubkeys = addPubkey(unfollowedPubkeys, pubkey);
    publicContacts = publicContacts.filter((publicContact) => publicContact.pubkey !== pubkey);
    status = `Unfollowed ${contactDisplayName(contact)} locally. Publishing follows is not enabled yet.`;
  }

  function toggleMuteSelected(): void {
    if (!selectedContact?.pubkey) return;
    if (isMutedContact(selectedContact)) {
      unmutePubkey(selectedContact.pubkey);
    } else {
      muteContact(selectedContact);
    }
    isContactMenuOpen = false;
  }

  function muteContact(contact: ContactRecord): void {
    if (!contact.pubkey) return;
    const pubkey = contact.pubkey;
    mutedPubkeys = addPubkey(mutedPubkeys, pubkey);
    followedPubkeys = removePubkey(followedPubkeys, pubkey);
    unfollowedPubkeys = addPubkey(unfollowedPubkeys, pubkey);
    status = `Muted ${contactDisplayName(contact)} locally. Publishing mutes is not enabled yet.`;
  }

  function unmutePubkey(pubkey: string): void {
    mutedPubkeys = removePubkey(mutedPubkeys, pubkey);
    unfollowedPubkeys = removePubkey(unfollowedPubkeys, pubkey);
    status = `Unmuted ${profileLabel(pubkey)} locally.`;
  }

  async function copySelectedNpub(): Promise<void> {
    if (!selectedNpub) return;
    const result = await copyToClipboard(selectedNpub);
    if (result === 'failed') {
      status = 'Clipboard is unavailable.';
    }
    isContactMenuOpen = false;
  }

  function handleSearchFocusout(event: FocusEvent): void {
    const current = event.currentTarget as HTMLElement | null;
    const next = event.relatedTarget as Node | null;
    if (current && next && current.contains(next)) return;
    isSearchFocused = false;
  }

  function handleSearchKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      query = '';
      isSearchFocused = false;
      (event.currentTarget as HTMLInputElement | null)?.blur();
      return;
    }

    if (!isSearchDropdownOpen) return;

    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      if (searchResultContacts.length === 0) return;
      const direction = event.key === 'ArrowDown' ? 1 : -1;
      searchResultIndex = (searchResultIndex + direction + searchResultContacts.length) % searchResultContacts.length;
      return;
    }

    if (event.key === 'Enter') {
      const contact = searchResultContacts[searchResultIndex];
      if (!contact) return;
      event.preventDefault();
      openSearchResult(contact);
    }
  }

  function openSearchResult(contact: ContactRecord): void {
    query = '';
    isSearchFocused = false;
    selectedId = contact.id;
    openContact(contact);
  }

  function handleContactTableKeydown(event: KeyboardEvent): void {
    if (visibleContacts.length === 0) return;
    event.stopPropagation();
    const currentIndex = contactIndexFromEvent(event) ?? selectedFilteredIndex();

    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openContact(visibleContacts[currentIndex]);
      return;
    }

    const nextIndex = nextContactIndexForKey(event.key, currentIndex);
    if (nextIndex === null) return;

    event.preventDefault();
    selectContactAtIndex(nextIndex, true);
  }

  function handleWindowKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && isProfilePhotoModalOpen) {
      event.preventDefault();
      isProfilePhotoModalOpen = false;
      return;
    }
    if (appMode !== 'detail') return;
    const target = event.target as HTMLElement | null;
    if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
    handleContactDetailKeydown(event);
  }

  function handleContactDetailKeydown(event: KeyboardEvent): void {
    const nextIndex = nextContactIndexForKey(event.key);
    if (nextIndex === null) return;

    event.preventDefault();
    selectContactAtIndex(nextIndex, false);
  }

  function nextContactIndexForKey(key: string, currentIndex = selectedFilteredIndex()): number | null {
    if (visibleContacts.length === 0) return null;

    if (key === 'ArrowDown') return Math.min(visibleContacts.length - 1, currentIndex + 1);
    if (key === 'ArrowUp') return Math.max(0, currentIndex - 1);
    if (key === 'Home') return 0;
    if (key === 'End') return visibleContacts.length - 1;
    return null;
  }

  function selectedFilteredIndex(): number {
    const selected = selectedContact;
    const index = selected ? visibleContacts.findIndex((contact) => contact.id === selected.id) : -1;
    return index >= 0 ? index : 0;
  }

  function contactIndexFromEvent(event: KeyboardEvent): number | null {
    const target = event.currentTarget as HTMLElement | null;
    const value = target?.dataset.contactIndex;
    if (!value) return null;
    const index = Number(value);
    return Number.isInteger(index) && index >= 0 ? index : null;
  }

  function selectContactAtIndex(index: number, shouldFocusRow: boolean): void {
    const contact = visibleContacts[index];
    if (!contact) return;
    selectedId = contact.id;
    ensureVisibleContactRendered(index);
    if (appMode === 'detail') {
      openedContact = contact;
      setContactRoute(contact, 'replace');
    }
    if (shouldFocusRow) focusContactRow(index);
  }

  function focusSelectedRow(): void {
    const index = selectedFilteredIndex();
    focusContactRow(index);
  }

  function focusContactRow(index: number): void {
    if (typeof document === 'undefined') return;
    setTimeout(() => {
      const active = document.activeElement as HTMLElement | null;
      if (active?.closest('input, textarea, select, a, [contenteditable="true"]')) return;
      if (active?.tagName === 'BUTTON' && !active.classList.contains('contact-row')) return;
      const row = document.querySelector<HTMLElement>(`[data-contact-index="${index}"]`);
      row?.focus();
      row?.scrollIntoView({ block: 'nearest' });
    }, 0);
  }

  function ensureVisibleContactRendered(index: number): void {
    if (index < visibleContactLimit) return;
    visibleContactLimit = Math.min(visibleContacts.length, index + 1);
  }

  function loadMoreVisibleContacts(): void {
    if (!hasMoreVisibleContacts) return;
    visibleContactLimit = Math.min(visibleContacts.length, visibleContactLimit + LIST_PAGE_SIZE);
  }

  async function exportPrivateContacts(): Promise<void> {
    const data = serializePrivateContacts(privateContacts);
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(data);
      status = 'Copied private contacts JSON.';
      return;
    }
    importText = data;
    status = 'Private contacts JSON is ready below.';
  }

  function importPrivateContacts(): void {
    try {
      privateContacts = parsePrivateContactsExport(importText);
      selectedId = privateContacts[0]?.id ?? selectedId;
      status = `Imported ${privateContacts.length} private contacts.`;
    } catch (error) {
      status = error instanceof Error ? error.message : String(error);
    }
  }

  async function signInWithRecovery(request: IdentityRecoveryRequest): Promise<void> {
    if (identityLoginBusy) return;
    identityLoginBusy = true;
    identityLoginError = '';
    try {
      const signer = recoverySigner(request);
      const pubkey = decodeProfileInput(await signer.getPublicKey());
      if (!pubkey) throw new Error('Recovered identity did not return a valid public key.');
      identitySession = {
        schema: 1,
        pubkey,
        npub: pubkeyToNpub(pubkey),
        method: request.method as ContactsIdentitySession['method'],
        createdAt: Date.now(),
      };
      savedAccounts = upsertAccount(savedAccounts, pubkey);
      switchAccount(pubkey);
      identityPromptSurface = null;
      status = 'Signed in.';
    } catch (error) {
      identityLoginError = error instanceof Error ? error.message : 'Sign in failed.';
    } finally {
      identityLoginBusy = false;
    }
  }

  function recoverySigner(request: IdentityRecoveryRequest): NostrIdentityEventSigner {
    if (request.method === 'nsec') {
      return createNostrIdentitySignerFromNsec(request.nsec ?? '');
    }
    if (request.method === 'seed_phrase') {
      return createNostrIdentitySignerFromSeedPhrase({
        seedWords: request.seedWords ?? '',
        passphrase: request.seedPassphrase,
      });
    }
    if (request.method === 'nip07') {
      const nostr = browserNostrSigner();
      if (!nostr) throw new Error('No Nostr extension found.');
      return createNostrIdentitySignerFromNip07(nostr);
    }
    throw new Error('Contacts does not support that sign-in method yet.');
  }

  async function createLocalContactsIdentity(request: IdentityCreateRequest = {}): Promise<void> {
    if (identityCreateBusy) return;
    identityCreateBusy = true;
    identityLoginError = '';
    try {
      const createRequest = normalizeIdentityCreateRequest(request);
      const label = createRequest.name ?? 'Contacts';
      const session = createLocalNostrIdentitySession({ label });
      saveNostrIdentitySession(session, { key: NOSTR_IDENTITY_SESSION_STORAGE_KEY });
      identitySession = contactsIdentitySessionFromNostrIdentity(session);
      identityPromptSurface = null;
      status = createRequest.name
        ? `Created local identity for ${createRequest.name}.`
        : 'Created local identity.';
    } catch (error) {
      identityLoginError = error instanceof Error ? error.message : 'Identity creation failed.';
    } finally {
      identityCreateBusy = false;
    }
  }

  function signOutIdentity(): void {
    identitySession = null;
    identityPromptSurface = null;
    identityLoginError = '';
    clearNostrIdentitySession({ key: NOSTR_IDENTITY_SESSION_STORAGE_KEY });
    status = 'Signed out.';
  }

  function handleIdentityMethodChange(): void {
    identityLoginError = '';
  }

  function browserNostrSigner(): Nip07LikeSigner | null {
    if (typeof window === 'undefined') return null;
    const nostr = (window as Window & { nostr?: Partial<Nip07LikeSigner> }).nostr;
    if (!nostr || typeof nostr.getPublicKey !== 'function' || typeof nostr.signEvent !== 'function') {
      return null;
    }
    return nostr as Nip07LikeSigner;
  }

  function loadContactsIdentitySession(value: string | null): ContactsIdentitySession | null {
    if (!value) return null;
    try {
      const parsed = JSON.parse(value) as Partial<ContactsIdentitySession>;
      if (!parsed || parsed.schema !== 1) return null;
      if (
        parsed.method !== 'local' &&
        parsed.method !== 'nsec' &&
        parsed.method !== 'seed_phrase' &&
        parsed.method !== 'nip07'
      ) {
        return null;
      }
      const pubkey = decodeProfileInput(parsed.pubkey ?? parsed.npub ?? '');
      if (!pubkey) return null;
      const createdAt = typeof parsed.createdAt === 'number' && Number.isFinite(parsed.createdAt)
        ? parsed.createdAt
        : Date.now();
      return {
        schema: 1,
        pubkey,
        npub: pubkeyToNpub(pubkey),
        method: parsed.method,
        createdAt,
        ...(typeof parsed.label === 'string' && parsed.label.trim() ? { label: parsed.label.trim() } : {}),
        ...(typeof parsed.profileId === 'string' && parsed.profileId ? { profileId: parsed.profileId } : {}),
        ...(typeof parsed.appKeyNpub === 'string' && parsed.appKeyNpub ? { appKeyNpub: parsed.appKeyNpub } : {}),
      };
    } catch {
      return null;
    }
  }

  function loadStoredNostrIdentitySession(): ContactsIdentitySession | null {
    try {
      const session = loadNostrIdentitySession({ key: NOSTR_IDENTITY_SESSION_STORAGE_KEY });
      return session?.status === 'active'
        ? contactsIdentitySessionFromNostrIdentity(session)
        : null;
    } catch {
      clearNostrIdentitySession({ key: NOSTR_IDENTITY_SESSION_STORAGE_KEY });
      return null;
    }
  }

  function contactsIdentitySessionFromNostrIdentity(session: ActiveNostrIdentitySession): ContactsIdentitySession {
    return {
      schema: 1,
      pubkey: session.appKeyPubkey,
      npub: session.appKeyNpub,
      method: 'local',
      createdAt: session.createdAt * 1000,
      ...(session.label?.trim() ? { label: session.label.trim() } : {}),
      profileId: session.profileId,
      appKeyNpub: session.appKeyNpub,
    };
  }

  function identityHandleLabel(): string {
    if (!identitySession) return 'No identity selected';
    const profileHandle = normalizeDisplayText(identityProfile?.nip05);
    if (profileHandle && !isEncodedPublicIdentifier(profileHandle)) return profileHandle;
    if (identitySession.profileId) return 'Local Contacts identity';
    return identityLoginMethodLabel(identitySession.method);
  }

  function identityLoginMethodLabel(method: ContactsIdentitySession['method']): string {
    if (method === 'local') return 'Local identity';
    if (method === 'nip07') return 'Nostr extension';
    if (method === 'seed_phrase') return 'Seed phrase';
    return 'Private key';
  }

  function accountDisplayLabel(pubkey: string): string {
    if (pubkey === IRIS_OWNER_PUBKEY) return 'Iris public graph';
    return getProfileDisplayName(
      profileForPubkey(pubkey),
      pubkey,
      null,
      coolName(pubkey),
    );
  }

  function accountHandleLabel(pubkey: string): string {
    const profileHandle = normalizeDisplayText(profileForPubkey(pubkey)?.nip05);
    if (profileHandle && !isEncodedPublicIdentifier(profileHandle)) return profileHandle;
    return pubkey === IRIS_OWNER_PUBKEY ? 'Anonymous discovery ranking' : 'Public graph root';
  }

  function loadingAccountStatus(pubkey: string): string {
    return `Loading contacts for ${accountDisplayLabel(pubkey)}...`;
  }

  function isAmbientLoadingStatus(value: string): boolean {
    return value === INITIAL_GRAPH_LOADING_STATUS || value.startsWith('Loading contacts for ');
  }

  function accountListOptions(): AccountOption[] {
    const pubkeys = [
      IRIS_OWNER_PUBKEY,
      activeAccountPubkey,
      ...savedAccounts.map((account) => account.pubkey),
    ];
    return [...new Set(pubkeys)]
      .filter((pubkey) => decodeProfileInput(pubkey))
      .map((pubkey) => {
        const profile = profileForPubkey(pubkey);
        const isDefault = pubkey === IRIS_OWNER_PUBKEY;
        return {
          id: pubkey,
          name: accountDisplayLabel(pubkey),
          description: accountHandleLabel(pubkey),
          picture: profile?.picture ?? null,
          avatarKey: pubkey,
          current: pubkey === activeAccountPubkey,
          default: isDefault,
          removable: !isDefault,
        };
      });
  }

  function parseStoredAccounts(value: string | null): StoredAccount[] {
    if (!value) return [];
    try {
      const parsed = JSON.parse(value) as { accounts?: unknown };
      if (!Array.isArray(parsed.accounts)) return [];
      return parsed.accounts
        .map((entry): StoredAccount | null => {
          if (!entry || typeof entry !== 'object') return null;
          const pubkey = decodeProfileInput((entry as { pubkey?: unknown }).pubkey as string);
          const addedAt = (entry as { addedAt?: unknown }).addedAt;
          if (!pubkey) return null;
          return {
            pubkey,
            addedAt: typeof addedAt === 'number' && Number.isFinite(addedAt) ? addedAt : Date.now(),
          };
        })
        .filter((entry): entry is StoredAccount => Boolean(entry));
    } catch {
      return [];
    }
  }

  function addAccountFromInput(): void {
    const pubkey = decodeProfileInput(accountInput);
    if (!pubkey) {
      accountError = 'Enter a valid Nostr public key.';
      return;
    }
    accountError = '';
    accountInput = '';
    savedAccounts = upsertAccount(savedAccounts, pubkey);
    switchAccount(pubkey);
  }

  function upsertAccount(accounts: readonly StoredAccount[], pubkey: string): StoredAccount[] {
    if (pubkey === IRIS_OWNER_PUBKEY) return accounts.filter((account) => account.pubkey !== pubkey);
    const existing = accounts.find((account) => account.pubkey === pubkey);
    return [
      { pubkey, addedAt: existing?.addedAt ?? Date.now() },
      ...accounts.filter((account) => account.pubkey !== pubkey),
    ];
  }

  function switchAccount(pubkey: string): void {
    if (!decodeProfileInput(pubkey)) return;
    activeAccountPubkey = pubkey;
    selectedId = null;
    openedContact = null;
    editingContactId = null;
    appMode = 'list';
    activeView = 'contacts';
    status = loadingAccountStatus(pubkey);
    setBrowserPath('/', 'push');
  }

  function removeAccount(pubkey: string): void {
    savedAccounts = savedAccounts.filter((account) => account.pubkey !== pubkey);
    if (activeAccountPubkey === pubkey) {
      switchAccount(IRIS_OWNER_PUBKEY);
    }
  }

  function isEncodedPublicIdentifier(value: string): boolean {
    return /^npub1/i.test(value.trim()) || /^[0-9a-f]{64}$/i.test(value.trim());
  }

  function copyableNpub(contact: Pick<ContactRecord, 'npub' | 'pubkey'>): string | null {
    if (contact.pubkey) return pubkeyToNpub(contact.pubkey);
    return contact.npub && /^npub1/i.test(contact.npub.trim()) ? contact.npub.trim() : null;
  }

  function privateIdentifierValidationMessage(value: string): string {
    const trimmed = value.trim();
    if (!trimmed || decodeNpubInput(trimmed)) return '';
    return 'Enter a valid Nostr public key.';
  }

  function contactCountLabel(count: number): string {
    return `${count} ${count === 1 ? 'contact' : 'contacts'}`;
  }

  function profileGraphTitle(direction: ProfileGraphDirection): string {
    return direction === 'followed' ? 'Follows' : 'Known followers';
  }

  function profileGraphSubtitle(contact: ContactRecord, count: number): string {
    return `${contactDisplayName(contact)} · ${contactCountLabel(count)}`;
  }

  function contactViewTitle(view: ContactView): string {
    if (view === 'favorites') return 'Favorites';
    if (view === 'private') return 'Private contacts';
    if (view === 'frequent') return 'Frequent';
    return 'Contacts';
  }

  function contactsForView(view: ContactView): ContactRecord[] {
    if (view === 'favorites') return [...favoriteContacts];
    if (view === 'private') return [...relationshipPrivateContacts];
    if (view === 'frequent') return allContacts.filter(isFrequentContact);
    return [...allContacts];
  }

  function profileGraphContacts(
    contact: ContactRecord | null,
    direction: 'followed' | 'followers',
  ): ContactRecord[] {
    if (!contact?.pubkey || !initialGraph) return [];
    const pubkeys = direction === 'followed'
      ? initialGraph.graph.getFollowedByUser(contact.pubkey)
      : initialGraph.graph.getFollowersByUser(contact.pubkey);

    return buildContactsFromPubkeys(pubkeys, initialGraph.graph, initialGraph.profileByPubkey)
      .filter((entry) => !isMutedContact(entry))
      .map((entry) => relationshipAdjustedContact(entry));
  }

  function followedByFriendPubkeys(contact: ContactRecord | null): string[] {
    if (!contact?.pubkey || !initialGraph) return [];
    return [...initialGraph.graph.followedByFriends(contact.pubkey)]
      .filter((pubkey) => !mutedPubkeySet.has(pubkey));
  }

  function followedByContacts(pubkeys: readonly string[]): ContactRecord[] {
    if (!initialGraph) return [];
    return pubkeys
      .slice(0, MAX_FOLLOWED_BY_FRIENDS)
      .map((pubkey) => contactForRelationshipPubkey(pubkey))
      .filter((contact): contact is ContactRecord => Boolean(contact));
  }

  function contactForRelationshipPubkey(pubkey: string): ContactRecord | null {
    return contactForPubkey(pubkey)
      ?? profileToContact(pubkey, profileForPubkey(pubkey), initialGraph?.graph ?? null);
  }

  function followsActiveAccount(contact: ContactRecord | null): boolean {
    if (!contact?.pubkey || !initialGraph || !loggedInPubkey || contact.pubkey === loggedInPubkey) return false;
    return initialGraph.graph.getFollowedByUser(contact.pubkey).has(loggedInPubkey);
  }

  function combinedPublicGraphContacts(): ContactRecord[] {
    const followedPubkeys = contactPubkeys(relationshipPublicContacts);
    return [
      ...relationshipPublicContacts,
      ...relationshipFollowerContacts.filter((contact) => !contact.pubkey || !followedPubkeys.has(contact.pubkey)),
    ];
  }

  function excludedSearchPubkeys(contacts: readonly ContactRecord[]): Set<string> {
    return new Set([...contactPubkeys(contacts), ...mutedPubkeys, ...unfollowedPubkeys]);
  }

  function contactPubkeys(contacts: readonly ContactRecord[]): Set<string> {
    return new Set(contacts.flatMap((contact) => contact.pubkey ? [contact.pubkey] : []));
  }

  function exactSearchContactForPubkey(pubkey: string): ContactRecord | null {
    if (mutedPubkeySet.has(pubkey) || unfollowedPubkeySet.has(pubkey)) return null;
    if (loadedSearchContacts.some((contact) => contact.pubkey === pubkey)) return null;
    if (globalSearchContacts.some((contact) => contact.pubkey === pubkey)) return null;
    if (seededSearchContacts.some((contact) => contact.pubkey === pubkey)) return null;
    if (initialGraph && isOvermuted(initialGraph.graph, pubkey)) return null;
    return relationshipAdjustedContact(profileToContact(pubkey, profileForPubkey(pubkey), initialGraph?.graph ?? null));
  }

  function uniqueSearchContacts(contacts: readonly ContactRecord[]): ContactRecord[] {
    const seen = new Set<string>();
    const unique: ContactRecord[] = [];
    for (const contact of contacts) {
      const key = contact.pubkey ?? contact.identity.id ?? contact.id;
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(contact);
    }
    return unique;
  }

  function globalProfileToContact(profile: GlobalPeopleProfile): ContactRecord {
    const contact = profileToContact(profile.pubkey, profile, initialGraph?.graph ?? null);
    return {
      ...contact,
      followDistance: contact.followDistance ?? profile.socialDistance,
      updatedAt: profile.createdAt ? profile.createdAt * 1000 : contact.updatedAt,
    };
  }

  function isFrequentContact(contact: ContactRecord): boolean {
    return contact.followDistance === 1 || contact.followedByFriends > 0;
  }

  function favoriteContactsForView(): ContactRecord[] {
    const contacts = uniqueSearchContacts([
      ...allContacts.filter((contact) => isFavoriteContact(contact)),
      ...favoritePubkeys.flatMap((pubkey) => {
        const contact = favoriteContactForPubkey(pubkey);
        return contact ? [contact] : [];
      }),
    ]);
    return contacts
      .filter((contact) => isFavoriteContact(contact) && !isMutedContact(contact))
      .map((contact) => relationshipAdjustedContact(contact))
      .sort(compareContacts);
  }

  function favoriteContactForPubkey(pubkey: string): ContactRecord | null {
    return allContacts.find((contact) => contact.pubkey === pubkey)
      ?? publicContacts.find((contact) => contact.pubkey === pubkey)
      ?? followerContacts.find((contact) => contact.pubkey === pubkey)
      ?? (loggedInPubkey && pubkey === loggedInPubkey ? ownerProfileContact() : null)
      ?? seededProfileContact(pubkey);
  }

  function seededProfileContact(pubkey: string): ContactRecord | null {
    if (!initialGraph) return null;
    const [contact] = searchInitialGraphContacts(initialGraph, pubkey, {
      hideOvermuted: false,
      limit: 1,
    });
    return contact ?? profileToContact(pubkey, initialGraph.profileByPubkey.get(pubkey), initialGraph.graph);
  }

  function formatBirthday(value: string): string {
    const trimmed = value.trim();
    const isoDate = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
    if (!isoDate) return trimmed;

    const year = Number(isoDate[1]);
    const month = Number(isoDate[2]);
    const day = Number(isoDate[3]);
    const date = new Date(year, month - 1, day);
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
      return trimmed;
    }

    return new Intl.DateTimeFormat('en', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  }

  function networkLabel(contact: ContactRecord): string {
    if (isOwnerContact(contact)) return 'Your identity';
    if (isMutedContact(contact)) return 'Muted locally';
    if (isFollowingContact(contact)) return 'Direct follow';
    if (contact.followDistance === 1) return 'Direct follow';
    if (contact.followDistance) return `${contact.followDistance} hops away`;
    if (contact.source === 'private') return 'Local only';
    return 'Public';
  }

  function followButtonLabel(contact: ContactRecord): string {
    if (isMutedContact(contact)) return 'Unmute';
    return isFollowingContact(contact) ? 'Unfollow' : 'Follow';
  }

  function favoriteButtonLabel(contact: ContactRecord): string {
    return isFavoriteContact(contact) ? 'Remove from favorites' : 'Add to favorites';
  }

  function rowFavoriteButtonLabel(contact: ContactRecord): string {
    return isFavoriteContact(contact)
      ? `Remove ${contactDisplayName(contact)} from favorites`
      : `Add ${contactDisplayName(contact)} to favorites`;
  }

  function toggleFavoriteSelected(): void {
    if (!selectedContact) return;
    toggleFavoriteContact(selectedContact);
  }

  function toggleFavoriteFromRow(contact: ContactRecord, event: MouseEvent): void {
    event.stopPropagation();
    toggleFavoriteContact(contact);
  }

  function toggleFavoriteContact(contact: ContactRecord): void {
    if (isFavoriteContact(contact)) {
      unfavoriteContact(contact);
    } else {
      favoriteContact(contact);
    }
  }

  function favoriteContact(contact: ContactRecord): void {
    if (contact.pubkey) {
      favoritePubkeys = addPubkey(favoritePubkeys, contact.pubkey);
    } else {
      favoriteIdentityIds = addIdentityId(favoriteIdentityIds, contact.identity.id);
    }
    status = `Added ${contactDisplayName(contact)} to favorites locally.`;
  }

  function unfavoriteContact(contact: ContactRecord): void {
    if (contact.pubkey) {
      favoritePubkeys = removePubkey(favoritePubkeys, contact.pubkey);
    }
    favoriteIdentityIds = removeIdentityId(removeIdentityId(favoriteIdentityIds, contact.identity.id), contact.id);
    status = `Removed ${contactDisplayName(contact)} from favorites.`;
  }

  function isFavoriteContact(contact: ContactRecord): boolean {
    return Boolean(
      (contact.pubkey && favoritePubkeySet.has(contact.pubkey)) ||
      favoriteIdentityIdSet.has(contact.identity.id) ||
      favoriteIdentityIdSet.has(contact.id),
    );
  }

  function isFollowingContact(contact: ContactRecord): boolean {
    if (!contact.pubkey || mutedPubkeySet.has(contact.pubkey) || unfollowedPubkeySet.has(contact.pubkey)) {
      return false;
    }
    return followedPubkeySet.has(contact.pubkey) || contact.followDistance === 1;
  }

  function isOwnerContact(contact: Pick<ContactRecord, 'pubkey'>): boolean {
    return Boolean(loggedInPubkey && contact.pubkey === loggedInPubkey);
  }

  function isMutedContact(contact: ContactRecord): boolean {
    return Boolean(contact.pubkey && mutedPubkeySet.has(contact.pubkey));
  }

  function isUnfollowedContact(contact: ContactRecord): boolean {
    return Boolean(contact.pubkey && unfollowedPubkeySet.has(contact.pubkey));
  }

  function relationshipAdjustedContact(contact: ContactRecord): ContactRecord {
    if (!contact.pubkey || !followedPubkeySet.has(contact.pubkey)) return contact;
    return {
      ...contact,
      followDistance: 1,
      followedByFriends: Math.max(contact.followedByFriends, 1),
    };
  }

  function withLocallyFollowedContacts(
    directContacts: readonly ContactRecord[],
    graph: InitialSocialGraph,
  ): ContactRecord[] {
    const byPubkey = new Map<string, ContactRecord>();
    for (const contact of directContacts) {
      if (contact.pubkey) byPubkey.set(contact.pubkey, contact);
    }

    for (const pubkey of followedPubkeys) {
      if (byPubkey.has(pubkey)) continue;
      const [contact] = searchInitialGraphContacts(graph, pubkey, {
        hideOvermuted: false,
        limit: 1,
      });
      if (contact) byPubkey.set(pubkey, relationshipAdjustedContact(contact));
    }

    return [...byPubkey.values()];
  }

  function upsertPublicContact(contacts: readonly ContactRecord[], contact: ContactRecord): ContactRecord[] {
    if (!contact.pubkey) return [...contacts];
    const followed = {
      ...contact,
      source: 'public' as const,
      followDistance: 1,
      followedByFriends: Math.max(contact.followedByFriends, 1),
    };
    return [followed, ...contacts.filter((existing) => existing.pubkey !== contact.pubkey)];
  }

  function unresolvedProfilePubkeys(contacts: readonly ContactRecord[]): string[] {
    const pubkeys: string[] = [];
    for (const contact of contacts) {
      if (!contact.pubkey || pubkeys.includes(contact.pubkey)) continue;
      if (needsContactRelayProfile(contact)) pubkeys.push(contact.pubkey);
    }
    return pubkeys;
  }

  function needsContactRelayProfile(contact: ContactRecord): boolean {
    if (!contact.pubkey) return false;
    if (contact.source === 'private' && contact.picture) return false;
    return needsRelayProfile(contact.pubkey);
  }

  function needsRelayProfile(pubkey: string): boolean {
    if (relayProfilesByPubkey[pubkey] || pendingProfilePubkeys.has(pubkey) || missingProfilePubkeys.includes(pubkey)) {
      return false;
    }
    const packagedProfile = initialGraph?.profileByPubkey.get(pubkey);
    return !packagedProfile || !explicitProfileName(packagedProfile) || !packagedProfile.picture;
  }

  function requestRelayProfiles(pubkeys: readonly string[]): void {
    const lookupPubkeys = [...new Set(pubkeys)].filter((pubkey) => needsRelayProfile(pubkey));
    if (lookupPubkeys.length === 0) return;

    for (const pubkey of lookupPubkeys) pendingProfilePubkeys.add(pubkey);
    void loadProfilesByPubkey(lookupPubkeys)
      .then((profiles) => {
        if (profiles.size === 0) {
          missingProfilePubkeys = [...new Set([...missingProfilePubkeys, ...lookupPubkeys])];
          return;
        }

        const nextProfiles = { ...relayProfilesByPubkey };
        for (const [pubkey, profile] of profiles) nextProfiles[pubkey] = profile;
        relayProfilesByPubkey = nextProfiles;

        const missingPubkeys = lookupPubkeys.filter((pubkey) => !profiles.has(pubkey));
        if (missingPubkeys.length) {
          missingProfilePubkeys = [...new Set([...missingProfilePubkeys, ...missingPubkeys])];
        }

        applyResolvedPublicProfiles(profiles);
      })
      .catch(() => {
        // The shared fallback identity keeps rows usable when relays are quiet.
      })
      .finally(() => {
        for (const pubkey of lookupPubkeys) pendingProfilePubkeys.delete(pubkey);
      });
  }

  function applyResolvedPublicProfiles(profiles: ReadonlyMap<string, ProfileRecord>): void {
    publicContacts = publicContacts.map((contact) => {
      const profile = contact.pubkey ? profiles.get(contact.pubkey) : undefined;
      return profile ? contactWithResolvedProfile(contact, profile) : contact;
    });
    followerContacts = followerContacts.map((contact) => {
      const profile = contact.pubkey ? profiles.get(contact.pubkey) : undefined;
      return profile ? contactWithResolvedProfile(contact, profile) : contact;
    });
    if (openedContact?.pubkey && openedContact.source === 'public') {
      const profile = profiles.get(openedContact.pubkey);
      if (profile) openedContact = contactWithResolvedProfile(openedContact, profile);
    }
  }

  function contactWithResolvedProfile(contact: ContactRecord, profile: ProfileRecord): ContactRecord {
    const resolved = profileToContact(contact.pubkey!, profile, initialGraph?.graph ?? null);
    return {
      ...resolved,
      source: contact.source,
      groups: contact.groups,
      notes: contact.notes,
      about: resolved.about || contact.about,
      followDistance: contact.followDistance ?? resolved.followDistance,
      followedByFriends: Math.max(contact.followedByFriends, resolved.followedByFriends),
      updatedAt: Math.max(contact.updatedAt, resolved.updatedAt),
    };
  }

  function contactProfile(contact: ContactRecord): ProfileRecord | undefined {
    return contact.pubkey ? profileForPubkey(contact.pubkey) : undefined;
  }

  function preferredContactName(contact: ContactRecord): string | null {
    if (contact.source === 'private' || !contact.pubkey) return contact.name;
    return isGeneratedPublicName(contact, contactProfile(contact)) ? null : contact.name;
  }

  function contactFallbackName(contact: ContactRecord): string {
    return contact.pubkey ? coolName(contact.pubkey) : contact.name;
  }

  function contactDisplayName(contact: ContactRecord): string {
    return getProfileDisplayName(
      contactProfile(contact),
      contact.pubkey,
      preferredContactName(contact),
      contactFallbackName(contact),
    );
  }

  function contactPicture(contact: ContactRecord): string {
    return contact.picture || contactProfile(contact)?.picture || '';
  }

  function contactAbout(contact: ContactRecord): string {
    return normalizeDisplayText(contact.about || contactProfile(contact)?.about);
  }

  function measureProfileAboutOverflow(): void {
    if (!profileAboutElement) {
      isProfileAboutOverflowing = false;
      return;
    }
    isProfileAboutOverflowing = profileAboutElement.scrollHeight > PROFILE_ABOUT_COLLAPSED_HEIGHT + 1;
  }

  function linkifyProfileAbout(value: string): ProfileAboutPart[] {
    const parts: ProfileAboutPart[] = [];
    const pattern = /\b((?:https?:\/\/|www\.)[^\s<>"']+)/gi;
    let lastIndex = 0;
    for (const match of value.matchAll(pattern)) {
      const rawMatch = match[0];
      const index = match.index ?? 0;
      if (index > lastIndex) {
        parts.push({ text: value.slice(lastIndex, index), href: null });
      }
      const { text, trailing } = trimTrailingUrlPunctuation(rawMatch);
      parts.push({
        text,
        href: text.startsWith('www.') ? `https://${text}` : text,
      });
      if (trailing) parts.push({ text: trailing, href: null });
      lastIndex = index + rawMatch.length;
    }
    if (lastIndex < value.length) {
      parts.push({ text: value.slice(lastIndex), href: null });
    }
    return parts.length ? parts : [{ text: value, href: null }];
  }

  function trimTrailingUrlPunctuation(value: string): { text: string; trailing: string } {
    const match = /[),.!?:;]+$/.exec(value);
    if (!match) return { text: value, trailing: '' };
    const trailing = match[0];
    return {
      text: value.slice(0, -trailing.length),
      trailing,
    };
  }

  function contactSecondaryName(contact: ContactRecord): string {
    if (!contact.pubkey) return '';
    const primary = normalizeDisplayText(contactDisplayName(contact));
    const profile = contactProfile(contact);
    const candidates = [
      ...getProfileNameCandidates(profile),
      secondaryProfileName(profile),
      isGeneratedPublicName(contact, profile) ? '' : contact.name,
    ];
    for (const candidate of candidates) {
      const value = normalizeDisplayText(candidate);
      if (value && !sameDisplayText(value, primary) && value !== 'Public contact' && !isEncodedPublicIdentifier(value)) {
        return value;
      }
    }
    return '';
  }

  function secondaryProfileName(profile: ProfileRecord | undefined): string {
    const value = normalizeDisplayText(profile?.nip05);
    if (!value || value.includes('@') || isEncodedPublicIdentifier(value)) return '';
    return value;
  }

  function normalizeDisplayText(value: unknown): string {
    return typeof value === 'string' ? value.trim() : '';
  }

  function sameDisplayText(a: string, b: string): boolean {
    return a.localeCompare(b, undefined, { sensitivity: 'accent' }) === 0;
  }

  function contactListDescription(contact: ContactRecord): string {
    return contactSecondaryName(contact);
  }

  function contactSearchDescription(contact: ContactRecord): string {
    if (contact.source !== 'private') return '';
    return contact.email || contact.phone || contact.groups.join(', ');
  }

  function profileLabel(pubkey: string): string {
    const contact = [...allContacts, selectedContact].find((candidate) => candidate?.pubkey === pubkey);
    const profile = profileForPubkey(pubkey);
    const contactName = contact ? preferredContactName(contact) : '';
    return contactName || explicitProfileName(profile) || coolName(pubkey);
  }

  function profileForPubkey(pubkey: string): ProfileRecord | undefined {
    return relayProfilesByPubkey[pubkey] ?? initialGraph?.profileByPubkey.get(pubkey);
  }

  function explicitProfileName(profile: ProfileRecord | undefined): string {
    return getProfileName(profile);
  }

  function isGeneratedPublicName(
    contact: ContactRecord | null | undefined,
    profile: ProfileRecord | undefined,
  ): boolean {
    return !contact
      || contact.name === 'Public contact'
      || Boolean(contact.source === 'public' && profile && contact.name === profile.nip05);
  }

  function mutedProfileContact(pubkey: string): ContactRecord | null {
    const contact = contactForPubkey(pubkey);
    const profile = profileForPubkey(pubkey);
    if (contact && (contact.name !== 'Public contact' || !profile)) return contact;

    return profile ? profileToContact(pubkey, profile, null) : null;
  }

  function mutedProfilePreferredName(pubkey: string): string | null {
    const contact = mutedProfileContact(pubkey);
    const profile = profileForPubkey(pubkey);
    if (isGeneratedPublicName(contact, profile)) return null;
    if (contact?.name && contact.name !== 'Public contact') return contact.name;
    return null;
  }

  function mutedProfileName(pubkey: string): string {
    return mutedProfilePreferredName(pubkey) || profileLabel(pubkey);
  }

  function mutedProfilePicture(pubkey: string): string {
    return mutedProfileContact(pubkey)?.picture ?? '';
  }

  function openMutedProfile(pubkey: string): void {
    const contact = mutedProfileContact(pubkey);
    if (contact) {
      openContact(contact);
      return;
    }
    setBrowserPath(`/${pubkeyToNpub(pubkey)}`, 'push');
  }

  function addPubkey(pubkeys: readonly string[], pubkey: string): string[] {
    return [...new Set([...pubkeys, pubkey])];
  }

  function removePubkey(pubkeys: readonly string[], pubkey: string): string[] {
    return pubkeys.filter((entry) => entry !== pubkey);
  }

  function addIdentityId(identityIds: readonly string[], identityId: string): string[] {
    return [...new Set([...identityIds, identityId.toLowerCase()])];
  }

  function removeIdentityId(identityIds: readonly string[], identityId: string): string[] {
    return identityIds.filter((entry) => entry !== identityId.toLowerCase());
  }

  function normalizePubkeyList(value: unknown): string[] {
    if (!Array.isArray(value)) return [];
    return [...new Set(value.filter((entry): entry is string => typeof entry === 'string' && decodeProfileInput(entry) !== null)
      .map((entry) => decodeProfileInput(entry))
      .filter((entry): entry is string => Boolean(entry)))];
  }

  function normalizeIdentityIdList(value: unknown): string[] {
    if (!Array.isArray(value)) return [];
    return [...new Set(value
      .filter((entry): entry is string => typeof entry === 'string' && isContactIdentityId(entry))
      .map((entry) => entry.toLowerCase()))];
  }
</script>

<svelte:head>
  <title>Iris Contacts</title>
</svelte:head>

<svelte:window onkeydown={handleWindowKeydown} />

<main class="contacts-app">
  <header class="app-bar">
    <button class="brand-group brand-home-button" type="button" onclick={navigateHome} aria-label="Go to contacts home">
      <div class="brand-mark" aria-hidden="true">
        <img src="./iris-contacts-icon.svg" alt="" />
      </div>
      <strong class="brand-title">Contacts</strong>
    </button>

    <div class="global-search-shell" onfocusin={() => isSearchFocused = true} onfocusout={handleSearchFocusout}>
      <label class="global-search" aria-label="Search people and contacts">
        <span class="search-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" focusable="false">
            <path d="M9.5 4a5.5 5.5 0 0 1 4.38 8.83l4.15 4.14-1.06 1.06-4.14-4.15A5.5 5.5 0 1 1 9.5 4Zm0 1.5a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z" />
          </svg>
        </span>
        <input
          bind:value={query}
          placeholder="Search people"
          autocomplete="off"
          aria-expanded={isSearchDropdownOpen}
          aria-controls={isSearchDropdownOpen ? 'global-search-results' : undefined}
          onkeydown={handleSearchKeydown}
          oninput={() => isSearchFocused = true}
        />
      </label>

      {#if isSearchDropdownOpen}
        <div class="search-dropdown" id="global-search-results" role="listbox" aria-label="Search results">
          {#each searchResultContacts as contact, index}
            <button
              type="button"
              class="search-result-row"
              class:active={index === searchResultIndex}
              role="option"
              aria-selected={index === searchResultIndex}
              data-search-result-index={index}
              onpointerdown={(event) => event.preventDefault()}
              onclick={() => openSearchResult(contact)}
            >
              <UserRow
                pubkey={contact.pubkey ?? ''}
                profile={contactProfile(contact)}
                name={preferredContactName(contact)}
                fallbackName={contactFallbackName(contact)}
                picture={contactPicture(contact)}
                description={contactSearchDescription(contact)}
                avatarSize={36}
                showBadge={Boolean(contact.pubkey)}
                badgeDistance={contact.followDistance}
                badgeFollowedByFriends={contact.followedByFriends}
                badgeMuted={isMutedContact(contact)}
                class="search-user-row"
              />
            </button>
          {:else}
            <p class="search-empty">
              {globalSearchBusy
                ? 'Searching public people...'
                : globalSearchUnavailable
                  ? 'Public people search is unavailable.'
                  : 'No people match.'}
            </p>
          {/each}
        </div>
      {/if}
    </div>

    <div class="account-actions">
      <button class="icon-button" type="button" aria-label="Settings" onclick={openSettings}>
        <svg class="header-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <path d="M19.43 12.98c.04-.32.07-.65.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46a.5.5 0 0 0-.61-.22l-2.49 1a7.27 7.27 0 0 0-1.69-.98l-.38-2.65A.5.5 0 0 0 14 2h-4a.5.5 0 0 0-.49.42l-.38 2.65c-.61.24-1.18.57-1.69.98l-2.49-1a.5.5 0 0 0-.61.22l-2 3.46a.5.5 0 0 0 .12.64l2.11 1.65a7.9 7.9 0 0 0 0 1.96l-2.11 1.65a.5.5 0 0 0-.12.64l2 3.46c.12.22.38.31.61.22l2.49-1c.51.41 1.08.74 1.69.98l.38 2.65c.04.24.25.42.49.42h4c.24 0 .45-.18.49-.42l.38-2.65c.61-.24 1.18-.57 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46a.5.5 0 0 0-.12-.64l-2.11-1.65ZM12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7Z" />
        </svg>
      </button>
      <button class="profile-button" type="button" onclick={openOwnerProfile} aria-label={loggedInPubkey ? 'Your identity' : 'Sign in'}>
        {#if loggedInPubkey}
          <span class="avatar mini" aria-hidden="true">
            {#if identityProfile?.picture}
              <img src={identityProfile.picture} alt="" loading="lazy" referrerpolicy="no-referrer" />
            {:else}
              {identityInitial}
            {/if}
          </span>
        {:else}
          <span class="sign-in-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" focusable="false">
              <circle cx="10" cy="8" r="3.25"></circle>
              <path d="M4.75 19c.45-3.25 2.2-5 5.25-5s4.8 1.75 5.25 5M18.5 8.5v6M15.5 11.5h6"></path>
            </svg>
          </span>
        {/if}
      </button>
    </div>
  </header>

  <div class="app-shell">
    <aside class="nav-rail" aria-label="Contacts navigation">
      <button class="create-button" type="button" onclick={() => openCreateContact()}>
        <span aria-hidden="true">+</span>
        Create contact
      </button>

      <nav>
        <button
          type="button"
          class:active={activeView === 'contacts'}
          onclick={() => setActiveView('contacts')}
        >
          <span class="nav-icon" aria-hidden="true">●</span>
          <span>Contacts</span>
          <strong>{allContacts.length}</strong>
        </button>
        <button
          type="button"
          class:active={activeView === 'favorites'}
          onclick={() => setActiveView('favorites')}
        >
          <span class="nav-icon" aria-hidden="true">★</span>
          <span>Favorites</span>
          <strong>{favoriteCount}</strong>
        </button>
        <button
          type="button"
          class:active={activeView === 'frequent'}
          onclick={() => setActiveView('frequent')}
        >
          <span class="nav-icon" aria-hidden="true">↻</span>
          <span>Frequent</span>
          <strong>{frequentCount}</strong>
        </button>
        <button
          type="button"
          class:active={activeView === 'private'}
          onclick={() => setActiveView('private')}
        >
          <span class="nav-icon" aria-hidden="true">◆</span>
          <span>Private</span>
          <strong>{privateCount}</strong>
        </button>
      </nav>

      <section class="nav-section nav-settings-section" aria-label="Settings">
        <button type="button" onclick={openSettings}>Settings</button>
      </section>
    </aside>

    <section class="content-panel" aria-label="Contacts">
      {#if appMode === 'settings'}
        <div class="settings-page">
          <div class="panel-toolbar">
            <button class="back-button" type="button" onclick={closePanel} aria-label="Back to contacts">←</button>
            <div>
              <h1>Settings</h1>
            </div>
          </div>

          <div class="settings-shell">
            <nav class="settings-tabs" aria-label="Settings sections">
              <button type="button" class:active={activeSettingsTab === 'account'} onclick={() => activeSettingsTab = 'account'}>
                Account
              </button>
              <button type="button" class:active={activeSettingsTab === 'private'} onclick={() => activeSettingsTab = 'private'}>
                Private
              </button>
              <button type="button" class:active={activeSettingsTab === 'public'} onclick={() => activeSettingsTab = 'public'}>
                Public graph
              </button>
              <button type="button" class:active={activeSettingsTab === 'muted'} onclick={() => activeSettingsTab = 'muted'}>
                Muted
              </button>
            </nav>

            <div class="settings-content">
              {#if activeSettingsTab === 'account'}
                {#if identitySession}
                  <section class="profile-card identity-card" aria-label="Signed in identity">
                    <button class="profile-card-button identity-profile-button" type="button" onclick={openOwnerProfile} aria-label={`Open ${identityName}`}>
                      <span class="avatar hero" aria-hidden="true">
                        {#if identityProfile?.picture}
                          <img src={identityProfile.picture} alt="" loading="lazy" referrerpolicy="no-referrer" />
                        {:else}
                          {identityInitial}
                        {/if}
                      </span>
                      <div>
                        <h2>{identityName}</h2>
                        <p>{identityHandle}</p>
                      </div>
                    </button>
                    <dl class="identity-session-details">
                      <div>
                        <dt>Method</dt>
                        <dd>{identityLoginMethodLabel(identitySession.method)}</dd>
                      </div>
                      <div>
                        <dt>Public key</dt>
                        <dd class="mono">{identitySession.npub}</dd>
                      </div>
                      {#if identitySession.profileId}
                        <div>
                          <dt>Identity</dt>
                          <dd class="mono">{identitySession.profileId}</dd>
                        </div>
                      {/if}
                    </dl>
                    <div class="identity-actions">
                      <button type="button" onclick={signOutIdentity}>Sign out</button>
                    </div>
                  </section>
                {:else}
                  <section class="settings-card identity-login-card" aria-label="Sign in">
                    <h2>{showIdentityCreatePrompt ? 'Create identity' : 'Sign in'}</h2>
                    <IdentityRecoveryPanel
                      methodLayout="column"
                      methods={CONTACTS_IDENTITY_LOGIN_METHODS}
                      disabled={identityLoginBusy || identityCreateBusy}
                      submitLabel="Sign in"
                      error={identityLoginError}
                      nostrAvailable={hasNostrExtension}
                      showNip46Relay={false}
                      showCreateNew={showIdentityCreatePrompt}
                      createNewTitle={identityCreatePromptTitle}
                      createNewLabel="Create identity"
                      showCreateNewName={true}
                      createNewNamePlaceholder="Optional"
                      createNewBusy={identityCreateBusy}
                      createNewDisabled={identityLoginBusy}
                      createNewTestId="contacts-create-identity"
                      onMethodChange={handleIdentityMethodChange}
                      onSubmit={signInWithRecovery}
                      onCreateNew={createLocalContactsIdentity}
                      onCreateNewBack={() => identityPromptSurface = null}
                    />
                    {#if !showIdentityCreatePrompt}
                      <div class="identity-create-row">
                        <button type="button" onclick={() => createLocalContactsIdentity()} disabled={identityLoginBusy || identityCreateBusy}>
                          {identityCreateBusy ? 'Creating...' : 'Create local identity'}
                        </button>
                      </div>
                    {/if}
                  </section>
                {/if}

                <section class="settings-card source-settings-card" aria-label="Source code">
                  <h2>Source code</h2>
                  <p>Open the public repository on Git Iris.</p>
                  <a class="settings-link" href={IRIS_CONTACTS_REPOSITORY_URL} target="_blank" rel="noreferrer">
                    iris-contacts
                  </a>
                </section>
              {:else if activeSettingsTab === 'private'}
                <section class="settings-card local-data-settings-card">
                  <h2>Private contacts</h2>
                  <p>{privateCount} saved locally in this browser.</p>
                  <button type="button" onclick={exportPrivateContacts}>Copy export JSON</button>
                  <label>
                    <span>Import JSON</span>
                    <textarea
                      class="import-text"
                      bind:value={importText}
                      placeholder="Paste exported private contacts JSON"
                    ></textarea>
                  </label>
                  <button type="button" onclick={importPrivateContacts} disabled={!importText.trim()}>
                    Import
                  </button>
                </section>
              {:else if activeSettingsTab === 'public'}
                <section class="settings-card account-switch-card" aria-label="Public graph root">
                  <h2>Public graph</h2>
                  <p>This is a public discovery and ranking lens, not a signed-in account.</p>
                  <p>{publicCount} suggested contacts; the local seed covers {initialGraph?.profileCount ?? 0} profiles and search also checks the census-backed public people index.</p>
                  <p>Selected graph: {activeAccountLabel}{activeAccountHandle ? ` · ${activeAccountHandle}` : ''}</p>
                  <AccountSwitcher
                    accounts={accountOptions}
                    inputValue={accountInput}
                    inputLabel="Public key"
                    error={accountError}
                    onInput={(value) => {
                      accountInput = value;
                      if (accountError) accountError = '';
                    }}
                    onAdd={addAccountFromInput}
                    onSelect={(account) => switchAccount(account.id)}
                    onRemove={(account) => removeAccount(account.id)}
                  />
                </section>
              {:else}
                <section class="settings-card muted-settings-card">
                  <h2>Muted profiles</h2>
                  {#if mutedPubkeys.length === 0}
                    <p>No locally muted profiles.</p>
                  {:else}
                    <p>{mutedCount} hidden from contacts and search.</p>
                    <div class="muted-list">
                      {#each mutedPubkeys as pubkey}
                        <div class="muted-row">
                          <button
                            class="muted-profile-button"
                            type="button"
                            onclick={() => openMutedProfile(pubkey)}
                            aria-label={`Open ${mutedProfileName(pubkey)}`}
                          >
                            <UserRow
                              pubkey={pubkey}
                              profile={profileForPubkey(pubkey)}
                              name={mutedProfilePreferredName(pubkey)}
                              fallbackName={coolName(pubkey)}
                              picture={mutedProfilePicture(pubkey)}
                              avatarSize={36}
                              showBadge={true}
                              badgeMuted={true}
                              class="muted-user-row"
                            />
                          </button>
                          <button type="button" onclick={() => unmutePubkey(pubkey)}>Unmute</button>
                        </div>
                      {/each}
                    </div>
                  {/if}
                </section>
              {/if}
            </div>
          </div>
        </div>
      {:else if appMode === 'create'}
        <form class="contact-editor-page" aria-label={editorTitle} onsubmit={handleCreateContactSubmit}>
          <div class="panel-toolbar">
            <div class="toolbar-leading">
              <button class="back-button" type="button" onclick={closePanel} aria-label="Back to contacts">←</button>
              <div>
                <h1>{editorTitle}</h1>
                <p>{editorSubtitle}</p>
              </div>
            </div>
            <div class="detail-toolbar-actions">
              <button
                class="primary-action"
                type="submit"
                disabled={!canSavePrivateContact}
              >
                Save
              </button>
            </div>
          </div>

          <section class="editor-intro" aria-label={editingContactId ? 'Edit contact' : 'New contact'}>
            <span class="editor-photo-placeholder" aria-hidden="true">
              <span class="editor-photo-head"></span>
              <span class="editor-photo-body"></span>
              <span class="editor-photo-add">+</span>
            </span>
            <div>
              <h1>{draftContactName || (editingContactId ? 'Edit contact' : 'New contact')}</h1>
              <p>{newEmail.trim() || newPhone.trim() || newHandle.trim() || editorSubtitle}</p>
            </div>
          </section>

          <section class="editor-card" aria-label="Contact fields">
            <div class="editor-field-row" data-editor-icon="person">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.person}></path>
                </svg>
              </span>
              <div class="editor-field-stack">
                <label>
                  <span>First name</span>
                  <input
                    id="private-contact-name"
                    type="text"
                    bind:value={newFirstName}
                    autocomplete="given-name"
                  />
                </label>

                <label>
                  <span>Last name</span>
                  <input
                    type="text"
                    bind:value={newLastName}
                    autocomplete="family-name"
                  />
                </label>
              </div>
            </div>

            <div class="editor-field-row" data-editor-icon="work">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.work}></path>
                </svg>
              </span>
              <div class="editor-field-stack">
                <label>
                  <span>Company</span>
                  <input
                    type="text"
                    bind:value={newCompany}
                    autocomplete="organization"
                  />
                </label>

                <label>
                  <span>Job title</span>
                  <input
                    type="text"
                    bind:value={newJobTitle}
                    autocomplete="organization-title"
                  />
                </label>
              </div>
            </div>

            <div class="editor-field-row" data-editor-icon="mail">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.mail}></path>
                </svg>
              </span>
              <label>
                <span>Email</span>
                <input
                  type="email"
                  inputmode="email"
                  bind:value={newEmail}
                  autocomplete="email"
                />
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="phone">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.phone}></path>
                </svg>
              </span>
              <label>
                <span>Phone</span>
                <input
                  type="tel"
                  inputmode="tel"
                  bind:value={newPhone}
                  autocomplete="tel"
                />
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="key">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.key}></path>
                </svg>
              </span>
              <label>
                <span>Nostr public key</span>
                <input
                  type="text"
                  bind:value={newHandle}
                  autocomplete="off"
                  autocapitalize="none"
                  spellcheck="false"
                  aria-invalid={identifierValidationMessage ? 'true' : undefined}
                  aria-describedby={identifierValidationMessage ? 'private-contact-identifier-error' : undefined}
                />
                {#if identifierValidationMessage}
                  <small class="field-error" id="private-contact-identifier-error">{identifierValidationMessage}</small>
                {/if}
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="place">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.place}></path>
                </svg>
              </span>
              <label>
                <span>Address</span>
                <input
                  type="text"
                  bind:value={newAddress}
                  autocomplete="street-address"
                />
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="cake">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.cake}></path>
                </svg>
              </span>
              <label>
                <span>Birthday</span>
                <input
                  type="date"
                  bind:value={newBirthday}
                  autocomplete="bday"
                />
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="label">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.label}></path>
                </svg>
              </span>
              <label>
                <span>Groups</span>
                <input
                  type="text"
                  bind:value={newGroups}
                  autocomplete="off"
                />
              </label>
            </div>

            <div class="editor-field-row" data-editor-icon="note">
              <span class="editor-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d={editorIconPaths.note}></path>
                </svg>
              </span>
              <label>
                <span>Notes</span>
                <textarea bind:value={newNotes}></textarea>
              </label>
            </div>
          </section>
        </form>
      {:else if appMode === 'detail' && selectedContact}
        <div class="contact-detail-page">
          <div class="panel-toolbar">
            <button class="back-button" type="button" onclick={closePanel} aria-label="Back to contacts">←</button>
            <div class="detail-toolbar-actions">
              {#if selectedContact.pubkey}
                <button
                  class="icon-button favorite-button"
                  class:active={isFavoriteContact(selectedContact)}
                  type="button"
                  onclick={toggleFavoriteSelected}
                  aria-label={favoriteButtonLabel(selectedContact)}
                  title={favoriteButtonLabel(selectedContact)}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27Z"></path>
                  </svg>
                </button>
                {#if !selectedIsOwnerProfile}
                  <button class="primary-action" type="button" onclick={toggleFollowSelected}>
                    {followButtonLabel(selectedContact)}
                  </button>
                {/if}
                <button type="button" onclick={() => openEditContact(selectedContact)}>Edit</button>
                {#if !selectedIsOwnerProfile}
                  <button class="icon-button" type="button" onclick={deleteSelectedContact} aria-label="Delete contact" title="Delete contact">
                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                      <path d={editorIconPaths.trash}></path>
                    </svg>
                  </button>
                {/if}
                <div class="overflow-menu">
                  <button
                    class="icon-button"
                    type="button"
                    aria-label="More profile actions"
                    aria-expanded={isContactMenuOpen}
                    onclick={() => isContactMenuOpen = !isContactMenuOpen}
                  >
                    ⋮
                  </button>
                  {#if isContactMenuOpen}
                    <div class="menu-popover" role="menu">
                      {#if !selectedIsOwnerProfile}
                        <button type="button" role="menuitem" onclick={toggleMuteSelected}>
                          {isMutedContact(selectedContact) ? 'Unmute' : 'Mute'}
                        </button>
                      {/if}
                      {#if selectedNpub}
                        <button type="button" role="menuitem" onclick={copySelectedNpub}>Copy public key</button>
                      {/if}
                    </div>
                  {/if}
                </div>
              {:else}
                <button
                  class="icon-button favorite-button"
                  class:active={isFavoriteContact(selectedContact)}
                  type="button"
                  onclick={toggleFavoriteSelected}
                  aria-label={favoriteButtonLabel(selectedContact)}
                  title={favoriteButtonLabel(selectedContact)}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27Z"></path>
                  </svg>
                </button>
                <button type="button" onclick={() => openEditContact(selectedContact)}>Edit</button>
                <button class="icon-button" type="button" onclick={deleteSelectedContact} aria-label="Delete contact" title="Delete contact">
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <path d={editorIconPaths.trash}></path>
                  </svg>
                </button>
              {/if}
            </div>
          </div>

          <section class="profile-hero" aria-label="Contact profile">
            {#if contactPicture(selectedContact)}
              <button
                class="avatar hero profile-photo-button"
                type="button"
                onclick={() => isProfilePhotoModalOpen = true}
                aria-label={`Open ${contactDisplayName(selectedContact)} photo`}
              >
                <img src={contactPicture(selectedContact)} alt="" loading="lazy" referrerpolicy="no-referrer" />
              </button>
            {:else}
              <span class="avatar hero" aria-hidden="true">
                {contactDisplayName(selectedContact).charAt(0).toUpperCase()}
              </span>
            {/if}
            <div>
              <div class="profile-title-row">
                <h1>{contactDisplayName(selectedContact)}</h1>
              </div>
              {#if selectedProfileAbout}
                <div class="profile-about" class:expanded={isProfileAboutExpanded}>
                  <p
                    class="profile-about-text"
                    class:clamped={isProfileAboutClamped}
                    bind:this={profileAboutElement}
                  >
                    {#each selectedProfileAboutParts as part}
                      {#if part.href}
                        <a href={part.href} target="_blank" rel="noreferrer">{part.text}</a>
                      {:else}
                        {part.text}
                      {/if}
                    {/each}
                  </p>
                  {#if isProfileAboutOverflowing}
                    <button
                      class="profile-about-toggle"
                      type="button"
                      onclick={() => isProfileAboutExpanded = !isProfileAboutExpanded}
                    >
                      {isProfileAboutExpanded ? 'show less' : 'show more'}
                    </button>
                  {/if}
                </div>
              {/if}
              {#if selectedContact.pubkey && initialGraph}
                <div class="profile-stats" aria-label="Social graph">
                  <button type="button" class="profile-stat-text" onclick={() => openProfileGraph('followed')}>
                    <strong>{selectedProfileFollowedContacts.length}</strong>
                    <span>follows</span>
                  </button>
                  <button type="button" class="profile-stat-text" onclick={() => openProfileGraph('followers')}>
                    <strong>{selectedProfileFollowerContacts.length}</strong>
                    <span>known followers</span>
                  </button>
                  {#if selectedFollowsActiveAccount}
                    <span class="profile-follows-you-pill">Follows you</span>
                  {/if}
                  {#if selectedIsOwnerProfile}
                    <button type="button" class="profile-account-switch-link" onclick={openAccountSettings}>
                      Public graph
                    </button>
                  {/if}
                </div>
              {/if}
              {#if selectedContact.pubkey && !selectedIsOwnerProfile && (selectedFollowedByFriendPubkeys.length > 0 || selectedContact.followDistance === 1 || selectedContact.followDistance === 3)}
                <div class="profile-relationship" aria-label="Profile relationship">
                  <SocialDistanceBadge
                    distance={selectedContact.followDistance}
                    followedByFriends={selectedFollowedByFriendPubkeys.length || selectedContact.followedByFriends}
                    muted={isMutedContact(selectedContact)}
                    size={16}
                    class="relationship-badge"
                  />
                  {#if selectedFollowedByFriendContacts.length > 0}
                    <span class="relationship-text">
                      <span>Followed by</span>
                      {#each selectedFollowedByFriendContacts as friend, index}
                        <button type="button" class="relationship-link" onclick={() => openContact(friend)}>
                          {contactDisplayName(friend)}
                        </button>{index < selectedFollowedByFriendContacts.length - 1 ? ',' : ''}
                      {/each}
                      {#if selectedFollowedByFriendRemaining > 0}
                        <span>and {selectedFollowedByFriendRemaining} others you follow</span>
                      {/if}
                    </span>
                  {:else if selectedContact.followDistance === 1}
                    <span class="relationship-text">Followed by you</span>
                  {:else if selectedContact.followDistance === 3}
                    <span class="relationship-text">Followed by friends of friends</span>
                  {/if}
                </div>
              {/if}
            </div>
          </section>

          {#if isProfilePhotoModalOpen && contactPicture(selectedContact)}
            <div
              class="profile-photo-modal-backdrop"
              role="presentation"
              onclick={(event) => {
                if (event.target === event.currentTarget) isProfilePhotoModalOpen = false;
              }}
            >
              <div
                class="profile-photo-modal"
                role="dialog"
                aria-modal="true"
                aria-label={`${contactDisplayName(selectedContact)} photo`}
                tabindex="-1"
              >
                <button
                  class="icon-button profile-photo-modal-close"
                  type="button"
                  aria-label="Close photo"
                  onclick={() => isProfilePhotoModalOpen = false}
                >
                  ×
                </button>
                <img
                  src={contactPicture(selectedContact)}
                  alt={`${contactDisplayName(selectedContact)} profile`}
                  referrerpolicy="no-referrer"
                />
              </div>
            </div>
          {/if}

          {#if selectedContact.pubkey && selectedSocialProfileUrl}
            <section class="profile-links" aria-label="Profile links">
              <div class="profile-link-list">
                <a
                  class="profile-link"
                  href={selectedSocialProfileUrl}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Iris social profile"
                >
                  <span aria-hidden="true">↗</span>
                  <strong>Social profile</strong>
                  <small>iris.to</small>
                </a>
              </div>
            </section>
          {/if}

          <section class="detail-card" aria-label="Contact details">
            <h2>Contact details</h2>
            <dl class="details-list">
              <div>
                <dt>Source</dt>
                <dd>{selectedContact.source === 'private' ? 'Private local contact' : 'Public follow list'}</dd>
              </div>
              <div>
                <dt>Network</dt>
                <dd>
                  {networkLabel(selectedContact)}
                  {#if selectedContact.followedByFriends > 0}
                    · {selectedContact.followedByFriends} followed by friends
                  {/if}
                </dd>
              </div>
              {#if selectedContact.pubkey}
                <div>
                  <dt>Relationship</dt>
                  <dd>
                    {selectedIsOwnerProfile
                      ? 'Your identity'
                      : isMutedContact(selectedContact)
                      ? 'Muted locally'
                      : isFollowingContact(selectedContact)
                        ? 'Following locally'
                        : 'Not following'}
                  </dd>
                </div>
              {/if}
              {#if selectedContact.email}
                <div>
                  <dt>Email</dt>
                  <dd>{selectedContact.email}</dd>
                </div>
              {/if}
              {#if selectedContact.phone}
                <div>
                  <dt>Phone</dt>
                  <dd>{selectedContact.phone}</dd>
                </div>
              {/if}
              {#if selectedContact.company || selectedContact.jobTitle}
                <div>
                  <dt>Work</dt>
                  <dd>{[selectedContact.jobTitle, selectedContact.company].filter(Boolean).join(', ')}</dd>
                </div>
              {/if}
              {#if selectedContact.address}
                <div>
                  <dt>Address</dt>
                  <dd>{selectedContact.address}</dd>
                </div>
              {/if}
              {#if selectedContact.birthday}
                <div>
                  <dt>Birthday</dt>
                  <dd>{formatBirthday(selectedContact.birthday)}</dd>
                </div>
              {/if}
              {#if selectedContact.groups.length}
                <div>
                  <dt>Groups</dt>
                  <dd>{selectedContact.groups.join(', ')}</dd>
                </div>
              {/if}
              <div class="notes-detail-row">
                <dt>Notes</dt>
                <dd>
                  <textarea
                    class="notes-textarea"
                    bind:value={selectedNotesDraft}
                    aria-label="Notes"
                    rows="4"
                    oninput={handleSelectedNotesInput}
                  ></textarea>
                  <div class="notes-editor-actions">
                    <small>Private in this browser</small>
                  </div>
                </dd>
              </div>
            </dl>
          </section>
        </div>
      {:else if appMode === 'profile-graph' && selectedContact}
        <div class="profile-graph-page">
          <div class="contacts-header profile-graph-header">
            <div class="toolbar-leading">
              <button class="back-button" type="button" onclick={openProfileDetail} aria-label="Back to profile">←</button>
              <div>
                <h1>{profileGraphTitle(profileGraphDirection)}</h1>
                <p>{profileGraphSubtitle(selectedContact, selectedProfileGraphContacts.length)}</p>
              </div>
            </div>
          </div>

          <div class="contact-table" role="table" aria-label={`${profileGraphTitle(profileGraphDirection)} table`}>
            {#each selectedProfileGraphContacts as graphContact, index (graphContact.pubkey ?? graphContact.id)}
              <button
                type="button"
                class="table-row contact-row"
                data-profile-graph-index={index}
                onclick={() => openContact(graphContact)}
                role="row"
              >
                <span class="name-cell" role="cell">
                  <UserRow
                    pubkey={graphContact.pubkey ?? ''}
                    profile={contactProfile(graphContact)}
                    name={preferredContactName(graphContact)}
                    fallbackName={contactFallbackName(graphContact)}
                    picture={contactPicture(graphContact)}
                    description={contactListDescription(graphContact)}
                    avatarSize={40}
                    showBadge={Boolean(graphContact.pubkey)}
                    badgeDistance={graphContact.followDistance}
                    badgeFollowedByFriends={graphContact.followedByFriends}
                    badgeMuted={isMutedContact(graphContact)}
                    class="contact-user-row"
                  />
                </span>
              </button>
            {:else}
              <p class="empty">
                {profileGraphDirection === 'followed' ? 'No followed profiles.' : 'No known followers.'}
              </p>
            {/each}
          </div>
        </div>
      {:else}
        <div class="contacts-header">
          <div>
            <h1>{contactViewTitle(activeView)}</h1>
            <p>{contactCountLabel(visibleContacts.length)}</p>
          </div>
          <div class="content-actions" aria-label="Contact actions">
            <button type="button" onclick={() => openCreateContact()}>New</button>
          </div>
        </div>

        <div class="contact-table" role="table" aria-label="Contacts table">
          {#each listContacts as contact, index}
            <div
              class="table-row contact-row"
              class:active={selectedContact?.id === contact.id}
              data-contact-index={index}
              aria-selected={selectedContact?.id === contact.id}
              tabindex={selectedContact?.id === contact.id ? 0 : -1}
              onkeydown={handleContactTableKeydown}
              onclick={() => openContact(contact)}
              role="row"
            >
              <span class="row-open-surface">
                <span class="name-cell" role="cell">
                  <UserRow
                    pubkey={contact.pubkey ?? ''}
                    profile={contactProfile(contact)}
                    name={preferredContactName(contact)}
                    fallbackName={contactFallbackName(contact)}
                    picture={contactPicture(contact)}
                    description={contactListDescription(contact)}
                    avatarSize={40}
                    showBadge={Boolean(contact.pubkey)}
                    badgeDistance={contact.followDistance}
                    badgeFollowedByFriends={contact.followedByFriends}
                    badgeMuted={isMutedContact(contact)}
                    class="contact-user-row"
                  />
                </span>
                {#if contact.groups.length}
                  <span class="row-labels" role="cell" aria-label="Labels">
                    {#each contact.groups as group}
                      <span class="row-label">{group}</span>
                    {/each}
                  </span>
                {/if}
              </span>
              <button
                class="icon-button favorite-button row-favorite-button"
                class:active={isFavoriteContact(contact)}
                type="button"
                aria-label={rowFavoriteButtonLabel(contact)}
                title={rowFavoriteButtonLabel(contact)}
                onclick={(event) => toggleFavoriteFromRow(contact, event)}
              >
                <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                  <path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27Z"></path>
                </svg>
              </button>
            </div>
          {/each}

          {#if visibleContacts.length === 0}
            <p class="empty">{activeView === 'favorites' ? 'No favorites yet.' : 'No contacts yet.'}</p>
          {:else if hasMoreVisibleContacts}
            <div class="load-more-sentinel" bind:this={loadMoreSentinel} aria-hidden="true"></div>
          {/if}
        </div>
      {/if}

      {#if shouldShowStatus}
        <footer class="status" aria-live="polite">{status}</footer>
      {/if}
    </section>
  </div>

</main>
