<script lang="ts">
  import { onMount } from 'svelte';
  import { resetShellFavicon, syncShellFaviconFromFrame } from './lib/faviconSync';
  import ShareModal from './lib/ShareModal.svelte';
  import LauncherScreen from './components/LauncherScreen.svelte';
  import RuntimeMenu from './components/RuntimeMenu.svelte';
  import {
    getLauncherProfile,
    getLauncherPrimaryHostForSite,
    launcherAsset,
    type LauncherProfile,
  } from './lib/launcherContent';
  import { classifyRuntimeUpdate } from './lib/runtimeUpdatePolicy';
  import { getDirectFileViewerKind, getDirectFileViewerName } from './lib/directFileViewer';
  import { buildSiteFrameSrc } from './lib/siteFrame';
  import { isInternalHtreePath, resolveHostedSite, type HostedSite } from './lib/siteConfig';
  import { buildShellTitle, syncShellTitleFromFrame } from './lib/titleSync';
  import {
    buildIsolatedSiteHref,
    buildLauncherHref,
    buildPermalinkHref,
    buildSitesHomeHref,
    buildSourceHref,
    isLocalDevShellHost,
    isPortalShellHost,
    shouldRedirectPortalShellHost,
    shouldShowRuntimeMenuForHost,
  } from './lib/siteHost';
  import { getMediaClientKey } from './lib/mediaClientKey';
  import type { TreeRootInfo, TreeRootUpdate } from './lib/workerClient';
  import {
    getAutoReloadStorageKey,
    isMenuHidden,
    readHashBooleanParam,
    setAutoReload as setAutoReloadParam,
    setMenuHidden,
  } from './lib/runtimeUi';

  const BOOT_STATUS_DELAY_MS = 2500;

  const initialRouteHash = typeof window === 'undefined' ? '' : window.location.hash;

  let currentSite = $state(resolveCurrentSite());
  let routeHash = $state(initialRouteHash);
  let launcherProfile = $state<LauncherProfile | null>(resolveLauncherProfileRoute(initialRouteHash));
  let runtimeReady = $state(false);
  let runtimeError = $state<string | null>(null);
  let menuHidden = $state(false);
  let autoReloadEnabled = $state(false);
  let updateAvailable = $state(false);
  let showBootStatus = $state(false);
  let iframeLoaded = $state(false);
  let directFileLoaded = $state(false);
  let directFileRetryCount = $state(0);
  let siteFrame = $state<HTMLIFrameElement | null>(null);
  let currentTreeRoot = $state<TreeRootInfo | null>(null);
  let frameReloadNonce = $state(0);
  let framePageTitle = $state<string | null>(null);
  let stopFaviconSync = () => {};
  let stopTitleSync = () => {};
  let mediaStreamingModulePromise: Promise<typeof import('./lib/mediaStreamingSetup')> | null = null;
  let workerClientModulePromise: Promise<typeof import('./lib/workerClient')> | null = null;

  function loadMediaStreamingModule(): Promise<typeof import('./lib/mediaStreamingSetup')> {
    mediaStreamingModulePromise ??= import('./lib/mediaStreamingSetup');
    return mediaStreamingModulePromise;
  }

  async function setupRuntimeMediaStreaming(): Promise<boolean> {
    const { setupMediaStreaming } = await loadMediaStreamingModule();
    return setupMediaStreaming();
  }

  function loadWorkerClientModule(): Promise<typeof import('./lib/workerClient')> {
    workerClientModulePromise ??= import('./lib/workerClient');
    return workerClientModulePromise;
  }

  function resolveCurrentSite() {
    if (typeof window === 'undefined') return null;
    return resolveHostedSite({
      host: window.location.host,
      hash: window.location.hash,
      pathname: window.location.pathname,
    });
  }

  function redirectPrimaryHostRuntime(site: ReturnType<typeof resolveCurrentSite>): boolean {
    if (!site || typeof window === 'undefined') return false;
    const host = window.location.hostname.toLowerCase();
    if (!host.endsWith('.hashtree.cc')) return false;
    const primaryHost = getLauncherPrimaryHostForSite(site);
    if (!primaryHost) return false;
    window.location.replace(`https://${primaryHost}/`);
    return true;
  }

  function decodeLauncherHashParts(hash: string | undefined): string[] {
    const trimmed = (hash || '').trim();
    if (!trimmed.startsWith('#/')) return [];
    return trimmed.slice(2).split('/').filter(Boolean).map((part) => {
      try {
        return decodeURIComponent(part);
      } catch {
        return part;
      }
    });
  }

  function isMaybeNpub(value: string | undefined): value is string {
    return !!value && /^npub1[a-z0-9]+$/.test(value);
  }

  function resolveLauncherProfileRoute(hash: string | undefined): LauncherProfile | null {
    const parts = decodeLauncherHashParts(hash);
    if (parts[0] !== 'profile' || !isMaybeNpub(parts[1])) return null;
    return getLauncherProfile(parts[1]);
  }

  function bytesToHex(bytes: Uint8Array | undefined): string {
    return bytes ? Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('') : '';
  }

  function treeRootSignature(record: Pick<TreeRootInfo, 'hash' | 'key'> | Pick<TreeRootUpdate, 'hash' | 'key'>): string {
    return `${bytesToHex(record.hash)}:${bytesToHex(record.key)}`;
  }

  function readAutoReloadPreference(): boolean {
    if (typeof window === 'undefined' || !currentSite) return false;
    const routeOverride = readHashBooleanParam(routeHash, 'reload');
    if (routeOverride !== null) {
      return routeOverride;
    }
    try {
      return window.localStorage.getItem(getAutoReloadStorageKey(currentSite)) === '1';
    } catch {
      return false;
    }
  }

  function writeAutoReloadPreference(enabled: boolean): void {
    if (typeof window === 'undefined' || !currentSite) return;
    try {
      const key = getAutoReloadStorageKey(currentSite);
      if (enabled) {
        window.localStorage.setItem(key, '1');
      } else {
        window.localStorage.removeItem(key);
      }
    } catch {
      // Ignore storage failures.
    }
  }

  function replaceHash(nextHash: string): void {
    if (typeof window === 'undefined') return;
    const nextUrl = `${window.location.pathname}${window.location.search}${nextHash}`;
    window.history.replaceState({}, '', nextUrl);
    routeHash = nextHash;
  }

  function hideRuntimeMenuForCurrentUrl(): void {
    if (typeof window === 'undefined') return;
    replaceHash(setMenuHidden(routeHash, true));
    menuHidden = true;
  }

  function buildCurrentLauncherHref(): string {
    if (!currentSite) return '';
    const baseHref = buildLauncherHref(currentSite, typeof window !== 'undefined' ? window.location.host : undefined);
    return applyUiRouteParams(baseHref, routeHash);
  }

  function applyUiRouteParams(href: string, sourceHash: string): string {
    if (!href) return href;
    const url = new URL(href, typeof window !== 'undefined' ? window.location.href : 'https://apps.iris.to/');
    let nextHash = setMenuHidden(url.hash, isMenuHidden(sourceHash));
    nextHash = setAutoReloadParam(nextHash, readHashBooleanParam(sourceHash, 'reload'));
    url.hash = nextHash;
    return url.toString();
  }

  function applyPendingUpdate(): void {
    if (typeof window === 'undefined' || !updateAvailable) return;
    updateAvailable = false;
    window.location.reload();
  }

  function stopFrameFaviconSync(): void {
    stopFaviconSync();
    stopFaviconSync = () => {};
  }

  function stopFrameTitleSync(): void {
    stopTitleSync();
    stopTitleSync = () => {};
  }

  function frameShowsWorkerPortFailure(frame: HTMLIFrameElement): boolean {
    try {
      return frame.contentDocument?.body?.textContent?.trim() === 'Worker port not available';
    } catch {
      return false;
    }
  }

  function retryFrameAfterWorkerPortFailure(): void {
    runtimeReady = false;
    iframeLoaded = false;
    void setupRuntimeMediaStreaming()
      .then((ok) => {
        if (!ok) {
          runtimeError = 'Failed to connect isolated site runtime.';
          return;
        }
        runtimeError = null;
        runtimeReady = true;
        frameReloadNonce += 1;
      })
      .catch((error) => {
        runtimeError = error instanceof Error ? error.message : String(error);
      });
  }

  function markDirectFileLoaded(): void {
    directFileLoaded = true;
    directFileRetryCount = 0;
  }

  function handleDirectFileError(): void {
    directFileLoaded = false;
    if (directFileRetryCount >= 2) {
      runtimeError = 'Failed to load file.';
      return;
    }
    directFileRetryCount += 1;
    void setupRuntimeMediaStreaming()
      .then((ok) => {
        if (!ok) {
          runtimeError = 'Failed to connect isolated file runtime.';
          return;
        }
        runtimeError = null;
        frameReloadNonce += 1;
      })
      .catch((error) => {
        runtimeError = error instanceof Error ? error.message : String(error);
      });
  }

  function handleFrameLoad(): void {
    iframeLoaded = true;
    if (typeof document === 'undefined' || !siteFrame) return;
    if (frameShowsWorkerPortFailure(siteFrame)) {
      retryFrameAfterWorkerPortFailure();
      return;
    }
    stopFrameFaviconSync();
    stopFaviconSync = syncShellFaviconFromFrame(siteFrame, document);
    stopFrameTitleSync();
    stopTitleSync = syncShellTitleFromFrame(siteFrame, (title) => {
      framePageTitle = title;
    });
  }

  function handleAutoReloadChange(checked: boolean): void {
    autoReloadEnabled = checked;
    writeAutoReloadPreference(checked);
    replaceHash(setAutoReloadParam(routeHash, checked));
  }

  const iframeSrc = $derived.by(() => {
    return buildSiteFrameSrc(currentSite, runtimeReady, getMediaClientKey(), currentTreeRoot, frameReloadNonce);
  });
  const directFileViewerKind = $derived.by(() => getDirectFileViewerKind(currentSite?.entryPath));
  const directFileViewerName = $derived.by(() => getDirectFileViewerName(currentSite?.entryPath));
  const directFileViewerSrc = $derived.by(() => directFileViewerKind ? iframeSrc : '');
  const shellTitle = $derived.by(() =>
    currentSite ? buildShellTitle(currentSite.title, framePageTitle) : 'Iris: The Freedom Toolkit'
  );

  const inPortalShell = $derived.by(() => {
    if (typeof window === 'undefined') return false;
    return (
      isInternalHtreePath(window.location.pathname)
      || isPortalShellHost(window.location.host)
    ) && !(currentSite && isLocalDevShellHost(window.location.host));
  });
  const showRuntimeChrome = $derived.by(() => {
    if (typeof window === 'undefined') return false;
    return shouldShowRuntimeMenuForHost(window.location.host);
  });

  const missingRuntimeTarget = $derived.by(() => !currentSite && !inPortalShell);
  const launcherHref = $derived.by(() => buildCurrentLauncherHref());
  const sitesHomeHref = $derived.by(() =>
    buildSitesHomeHref(typeof window !== 'undefined' ? window.location.host : undefined)
  );
  const sourceHref = $derived.by(() =>
    currentSite
      ? buildSourceHref(
          currentSite,
          typeof window !== 'undefined' ? window.location.host : undefined,
        )
      : ''
  );
  const permalinkHref = $derived.by(() =>
    currentSite
      ? buildPermalinkHref(
          currentSite,
          currentSite.kind === 'mutable' ? currentTreeRoot ?? undefined : undefined,
          typeof window !== 'undefined' ? window.location.host : undefined,
        ) || ''
      : ''
  );
  const showRuntimeMenu = $derived.by(() => Boolean(currentSite && showRuntimeChrome && !menuHidden));
  const showRuntimeFallback = $derived.by(() => Boolean(!runtimeError && showBootStatus));
  const showFrameOverlay = $derived.by(() => Boolean(!runtimeError && !iframeLoaded && !directFileViewerKind && showBootStatus));
  const showDirectFileOverlay = $derived.by(() => Boolean(!runtimeError && directFileViewerKind && !directFileLoaded && showBootStatus));

  onMount(() => {
    if (typeof document !== 'undefined') {
      resetShellFavicon(document);
    }

    const syncRoute = () => {
      const site = resolveCurrentSite();
      currentSite = site;
      if (redirectPrimaryHostRuntime(site)) return;
      routeHash = typeof window !== 'undefined' ? window.location.hash : '';
      launcherProfile = resolveLauncherProfileRoute(routeHash);
      runtimeError = null;
      menuHidden = isMenuHidden(routeHash);
      updateAvailable = false;
      currentTreeRoot = null;
      frameReloadNonce = 0;
      autoReloadEnabled = site ? readAutoReloadPreference() : false;
      if (typeof window !== 'undefined' && shouldRedirectPortalShellHost(window.location.host) && site) {
        void buildIsolatedSiteHref(site, window.location.host)
          .then((href) => {
            const nextHref = applyUiRouteParams(href, routeHash);
            if (window.location.href !== nextHref) {
              window.location.replace(nextHref);
            }
          })
          .catch((error) => {
            runtimeError = error instanceof Error ? error.message : String(error);
          });
      }
    };

    window.addEventListener('hashchange', syncRoute);

    syncRoute();

    void setupRuntimeMediaStreaming()
      .then((ok) => {
        if (!ok) {
          runtimeError = 'Failed to connect isolated site runtime.';
          return;
        }
        runtimeReady = true;
      })
      .catch((error) => {
        runtimeError = error instanceof Error ? error.message : String(error);
      });

    return () => {
      window.removeEventListener('hashchange', syncRoute);
      stopFrameFaviconSync();
      stopFrameTitleSync();
      if (typeof document !== 'undefined') {
        resetShellFavicon(document);
      }
    };
  });

  $effect(() => {
    if (!currentSite || currentSite.kind !== 'mutable' || inPortalShell || !runtimeReady) {
      updateAvailable = false;
      return;
    }

    const mutableSite = currentSite;

    let disposed = false;
    let currentSignature = '';

    const handleUpdate = (update: TreeRootUpdate) => {
      if (disposed) return;
      if (update.npub !== mutableSite.npub || update.treeName !== mutableSite.treeName) return;

      const nextSignature = treeRootSignature(update);
      const action = classifyRuntimeUpdate(currentSignature, nextSignature, autoReloadEnabled);
      currentSignature = nextSignature;
      currentTreeRoot = update;

      if (action === 'bootstrap' || action === 'ignore') return;
      if (action === 'reload' && typeof window !== 'undefined') {
        window.location.reload();
        return;
      }
      updateAvailable = true;
    };

    let detach = () => {};

    void (async () => {
      try {
        const { getTreeRootInfo, onTreeRootUpdate, subscribeTreeRoots } = await loadWorkerClientModule();
        if (disposed) return;
        detach = onTreeRootUpdate(handleUpdate);
        await subscribeTreeRoots(mutableSite.npub);
        const initial = await getTreeRootInfo(mutableSite.npub, mutableSite.treeName);
        if (!disposed && initial) {
          currentSignature = treeRootSignature(initial);
          currentTreeRoot = initial;
        }
      } catch (error) {
        if (!disposed) {
          console.warn('[iris-sites] Failed to subscribe to tree root updates', error);
        }
      }
    })();

    return () => {
      disposed = true;
      detach();
      updateAvailable = false;
      void loadWorkerClientModule()
        .then(({ unsubscribeTreeRoots }) => unsubscribeTreeRoots(mutableSite.npub))
        .catch(() => {});
    };
  });

  $effect(() => {
    void iframeSrc;
    iframeLoaded = false;
    directFileLoaded = false;
    directFileRetryCount = 0;
    framePageTitle = null;
    stopFrameFaviconSync();
    stopFrameTitleSync();
    if (typeof document !== 'undefined') {
      resetShellFavicon(document);
    }
  });

  $effect(() => {
    if (typeof window === 'undefined') {
      showBootStatus = false;
      return;
    }

    if (runtimeError) {
      showBootStatus = true;
      return;
    }

    if (inPortalShell && currentSite) {
      showBootStatus = false;
      const timeoutId = window.setTimeout(() => {
        showBootStatus = true;
      }, BOOT_STATUS_DELAY_MS);
      return () => window.clearTimeout(timeoutId);
    }

    if (currentSite && !inPortalShell && !iframeLoaded) {
      showBootStatus = false;
      const timeoutId = window.setTimeout(() => {
        showBootStatus = true;
      }, BOOT_STATUS_DELAY_MS);
      return () => window.clearTimeout(timeoutId);
    }

    showBootStatus = false;
  });
</script>

<svelte:head>
  <title>{shellTitle}</title>
  <meta name="description" content="Iris apps and sites. No email address, phone number, or sign-up required." />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-title" content="Iris" />
</svelte:head>

{#if missingRuntimeTarget}
  <main class="screen">
    <section class="card">
      <p class="eyebrow">App Link</p>
      <h1>This Iris app or site link is incomplete.</h1>
      <p class="copy">
        Open something from <code>apps.iris.to</code> or paste a shared Iris app or site link.
      </p>
    </section>
  </main>
{:else if !currentSite}
  <LauncherScreen profile={launcherProfile} />
{:else if directFileViewerKind && directFileViewerSrc}
  <main class="frame-screen direct-file-screen">
    <section class="direct-file-viewer" aria-label={directFileViewerName}>
      <header class="direct-file-header">
        <div class="direct-file-title-row">
          <a class="direct-file-home-link" href={sitesHomeHref} aria-label="Open Iris Sites">
            <img src={launcherAsset('favicon.svg')} alt="" />
          </a>
          <h1>{directFileViewerName}</h1>
        </div>
        <div class="direct-file-actions">
          <a class="direct-file-action" href={directFileViewerSrc} download={directFileViewerName}>Download</a>
          {#if sourceHref}
            <a class="direct-file-action" href={sourceHref}>Open in Iris Drive</a>
          {/if}
        </div>
      </header>
      <div class="direct-file-stage">
        {#if directFileViewerKind === 'image'}
          <img class="direct-file-image" src={directFileViewerSrc} alt={directFileViewerName} onload={markDirectFileLoaded} onerror={handleDirectFileError} />
        {:else if directFileViewerKind === 'video'}
          <video class="direct-file-media" src={directFileViewerSrc} controls onloadeddata={markDirectFileLoaded} onerror={handleDirectFileError}>
            <track kind="captions" />
          </video>
        {:else if directFileViewerKind === 'audio'}
          <audio class="direct-file-audio" src={directFileViewerSrc} controls onloadeddata={markDirectFileLoaded} onerror={handleDirectFileError}></audio>
        {:else if directFileViewerKind === 'pdf'}
          <iframe class="direct-file-pdf" src={directFileViewerSrc} title={directFileViewerName} onload={markDirectFileLoaded}></iframe>
        {/if}
      </div>
    </section>
    {#if runtimeError}
      <section class="overlay">
        <p class="eyebrow">Runtime Error</p>
        <p class="copy">{runtimeError}</p>
        {#if sourceHref}
          <a class="link" href={sourceHref}>Open in Iris Drive</a>
        {/if}
      </section>
    {:else if showDirectFileOverlay}
      <div class="loading-spinner-shell" aria-label="Loading file">
        <div class="loading-spinner"></div>
      </div>
    {/if}
  </main>
{:else if inPortalShell}
  <main class="screen">
    {#if runtimeError}
      <section class="overlay">
        <p class="eyebrow">Runtime Error</p>
        <p class="copy">{runtimeError}</p>
      </section>
    {:else if showRuntimeFallback}
      <div class="loading-spinner-shell" aria-label="Loading site">
        <div class="loading-spinner"></div>
      </div>
    {/if}
  </main>
{:else}
  <main class="frame-screen">
    {#if iframeSrc}
      <iframe
        bind:this={siteFrame}
        src={iframeSrc}
        class:site-frame-ready={iframeLoaded}
        class="site-frame"
        title={currentSite.title}
        onload={handleFrameLoad}
      ></iframe>
    {/if}

    {#if runtimeError}
      <section class="overlay">
        <p class="eyebrow">Runtime Error</p>
        <p class="copy">{runtimeError}</p>
        {#if sourceHref}
          <a class="link" href={sourceHref}>Open in Iris Drive</a>
        {/if}
      </section>
    {:else if showFrameOverlay}
      <div class="loading-spinner-shell" aria-label="Loading site">
        <div class="loading-spinner"></div>
      </div>
    {/if}
  </main>
{/if}

{#if showRuntimeMenu && currentSite}
  <RuntimeMenu
    {currentSite}
    {autoReloadEnabled}
    {updateAvailable}
    {launcherHref}
    {permalinkHref}
    {sourceHref}
    onApplyUpdate={applyPendingUpdate}
    onAutoReloadChange={handleAutoReloadChange}
    onHideMenu={hideRuntimeMenuForCurrentUrl}
  />
{/if}

<ShareModal />
