<script lang="ts">
  import { onDestroy } from 'svelte';
  import UserRow from '@iris/svelte-ui/UserRow.svelte';
  import {
    clearCopyReset,
    copyToClipboard,
    scheduleCopyReset,
    type CopyResetTimer,
  } from '@iris/svelte-ui/clipboard';
  import { open as openShareModal } from '../lib/ShareModal.svelte';
  import { getLauncherProfile, getLauncherProfileHref } from '../lib/launcherContent';
  import { buildLauncherHref } from '../lib/siteHost';
  import type { HostedSite } from '../lib/siteConfig';

  interface Props {
    currentSite: HostedSite;
    autoReloadEnabled: boolean;
    updateAvailable: boolean;
    launcherHref: string;
    permalinkHref: string;
    sourceHref: string;
    onApplyUpdate: () => void;
    onAutoReloadChange: (enabled: boolean) => void;
    onHideMenu: () => void;
  }

  let {
    currentSite,
    autoReloadEnabled,
    updateAvailable,
    launcherHref,
    permalinkHref,
    sourceHref,
    onApplyUpdate,
    onAutoReloadChange,
    onHideMenu,
  }: Props = $props();

  let runtimeMenuOpen = $state(false);
  let copyStatus = $state<'idle' | 'copied' | 'ready'>('idle');
  let copyStatusTimeoutId: CopyResetTimer = null;

  function toggleRuntimeMenu(): void {
    runtimeMenuOpen = !runtimeMenuOpen;
  }

  function buildPortalProfileHref(npub: string): string {
    const profileHash = getLauncherProfileHref(npub);
    if (typeof window === 'undefined') return profileHash;
    const url = new URL(buildLauncherHref(currentSite, window.location.host), window.location.href);
    url.hash = profileHash.slice(1);
    return url.toString();
  }

  function applyPendingUpdate(): void {
    runtimeMenuOpen = false;
    onApplyUpdate();
  }

  function hideRuntimeMenuForCurrentUrl(): void {
    runtimeMenuOpen = false;
    onHideMenu();
  }

  function showShareQr(): void {
    if (!launcherHref) return;
    runtimeMenuOpen = false;
    openShareModal(launcherHref);
  }

  function handleAutoReloadChange(event: Event): void {
    const target = event.currentTarget as HTMLInputElement | null;
    onAutoReloadChange(!!target?.checked);
  }

  async function copyShareUrl(): Promise<void> {
    if (!launcherHref || typeof window === 'undefined') return;

    clearCopyReset(copyStatusTimeoutId);
    copyStatusTimeoutId = null;

    const result = await copyToClipboard(launcherHref, { promptLabel: 'Copy share URL' });
    if (result === 'copied') {
      copyStatus = 'copied';
    } else if (result === 'prompted') {
      copyStatus = 'ready';
    } else {
      copyStatus = 'idle';
      return;
    }

    copyStatusTimeoutId = scheduleCopyReset(copyStatusTimeoutId, () => {
      copyStatus = 'idle';
      copyStatusTimeoutId = null;
    }, 1800);
  }

  const runtimeOwnerProfile = $derived.by(() =>
    currentSite.kind === 'mutable' ? getLauncherProfile(currentSite.npub) : null
  );
  const runtimeOwnerProfileHref = $derived.by(() =>
    currentSite.kind === 'mutable' ? buildPortalProfileHref(currentSite.npub) : ''
  );

  onDestroy(() => {
    clearCopyReset(copyStatusTimeoutId);
  });
</script>

<div class="runtime-menu-shell">
  {#if runtimeMenuOpen}
    <section class="runtime-menu-panel">
      <div class="runtime-menu-header">
        <div class="runtime-menu-title">{currentSite.title}</div>
        <div class="runtime-menu-links">
          <a class="runtime-menu-home-link" href={launcherHref}>apps.iris.to</a>
        </div>
      </div>

      {#if runtimeOwnerProfile && currentSite.kind === 'mutable'}
        <a class="runtime-owner-row" href={runtimeOwnerProfileHref}>
          <UserRow
            pubkey={runtimeOwnerProfile.pubkey}
            profile={runtimeOwnerProfile}
            avatarSize={32}
            class="iris-sites-user-row"
          />
        </a>
      {/if}

      {#if updateAvailable}
        <button
          class="runtime-menu-item runtime-menu-item-primary"
          type="button"
          onclick={applyPendingUpdate}
        >
          Update Now
        </button>
      {/if}

      <a class="runtime-menu-item" href={sourceHref}>Open in Iris Drive</a>

      {#if currentSite.kind === 'mutable'}
        {#if permalinkHref}
          <a class="runtime-menu-item" href={permalinkHref}>Permalink</a>
        {/if}

        <label class="runtime-menu-toggle">
          <span class="runtime-menu-toggle-label">Live updates</span>
          <input type="checkbox" checked={autoReloadEnabled} onchange={handleAutoReloadChange} />
        </label>
      {/if}

      <button class="runtime-menu-item runtime-menu-item-muted" type="button" onclick={hideRuntimeMenuForCurrentUrl}>
        Hide this menu
      </button>

      <button class="runtime-menu-item" type="button" onclick={showShareQr}>
        Show QR code
      </button>

      <button
        class="runtime-menu-link-button"
        type="button"
        onclick={copyShareUrl}
        aria-label="Copy Iris Sites link"
      >
        <span class="runtime-menu-link-text">{launcherHref}</span>
        <span class="runtime-menu-link-affordance" data-state={copyStatus}>
          {#if copyStatus === 'idle'}
            <svg
              class="runtime-menu-copy-icon"
              viewBox="0 0 16 16"
              aria-hidden="true"
              focusable="false"
            >
              <path
                d="M5.5 2.5h6a2 2 0 0 1 2 2v6h-1.5v-6a.5.5 0 0 0-.5-.5h-6zM3 5.5a2 2 0 0 1 2-2h4.5a2 2 0 0 1 2 2V10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zm2-.5a.5.5 0 0 0-.5.5V10a.5.5 0 0 0 .5.5h4.5A.5.5 0 0 0 10 10V5.5a.5.5 0 0 0-.5-.5z"
                fill="currentColor"
              ></path>
            </svg>
          {:else}
            <span class="runtime-menu-copy-label">
              {copyStatus === 'copied' ? 'Copied' : 'Ready'}
            </span>
          {/if}
        </span>
      </button>
    </section>
  {/if}

  <button
    class="runtime-menu-button"
    type="button"
    aria-expanded={runtimeMenuOpen}
    onclick={toggleRuntimeMenu}
  >
    <span>iris sites</span>
    {#if updateAvailable}
      <span class="runtime-menu-indicator"></span>
    {/if}
  </button>
</div>
