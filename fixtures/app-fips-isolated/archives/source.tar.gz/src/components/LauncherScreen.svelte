<script lang="ts">
  import { onMount } from 'svelte';
  import UserRow from '@iris/svelte-ui/UserRow.svelte';
  import {
    getLauncherProfileHref,
    getLauncherSuggestionSite,
    launcherAsset,
    launcherSuggestions,
    type LauncherProfile,
    type LauncherSuggestion,
  } from '../lib/launcherContent';
  import { parseLaunchInput } from '../lib/launchInput';
  import {
    LAUNCHER_HOME_STORAGE_KEY,
    addLauncherHomeSuggestion,
    createLauncherSuggestionFromSite,
    getLauncherSuggestionKey,
    getVisibleLauncherSuggestions,
    parseLauncherHomeState,
    reorderLauncherHomeSuggestion,
    removeLauncherHomeSuggestion,
    serializeLauncherHomeState,
  } from '../lib/launcherHome';
  import {
    buildIrisDriveDownloadHref,
    buildIsolatedSiteHref,
    buildSuggestedAppHref,
    shouldShowIrisDriveDownloadPrompt,
  } from '../lib/siteHost';
  import {
    createSiteUploadDraft,
    createSiteUploadTextFile,
    formatSiteUploadBytes,
    getSiteUploadFilesFromDataTransfer,
    inferSiteUploadAppMetadata,
    publishSiteUploadDraft,
    type SiteUploadDraft,
    type SiteUploadProgress,
  } from '../lib/siteUploader';
  import {
    getNextGridKeyboardIndex,
    type GridKeyboardDirection,
    type GridKeyboardRect,
  } from '../lib/gridKeyboardNavigation';
  import type { HostedSite } from '../lib/siteConfig';

  interface Props {
    profile: LauncherProfile | null;
  }

  interface DragGhostState {
    fallback: string;
    icon?: string;
    lift: boolean;
    name: string;
    x: number;
    y: number;
  }

  const MOBILE_EDIT_LONG_PRESS_MS = 360;
  const LONG_PRESS_MOVE_TOLERANCE_PX = 10;
  const ADD_SITE_CARD_KEY = 'launcher:add-site';
  const LEGACY_CONTACT_SUGGESTION_NAMES = new Set(['silent.link', 'ProtonMail']);

  let { profile }: Props = $props();

  let launchInput = $state('');
  let launchResultHref = $state('');
  let launchResultError = $state<string | null>(null);
  let launchResultVersion = 0;
  let launcherHomeLoaded = $state(false);
  let customizeApps = $state(false);
  let hiddenSuggestionKeys = $state<string[]>([]);
  let customSuggestions = $state<LauncherSuggestion[]>([]);
  let orderedSuggestionKeys = $state<string[]>([]);
  let draggingSuggestionKey = $state<string | null>(null);
  let dragGhost = $state<DragGhostState | null>(null);
  let addLinkInput = $state<HTMLInputElement | null>(null);
  let activeSuggestionKey = $state<string | null>(null);
  let siteUploadFolderInput = $state<HTMLInputElement | null>(null);
  let siteUploadFileInput = $state<HTMLInputElement | null>(null);
  let addPanelOpen = $state(false);
  let addUrlFormOpen = $state(false);
  let siteUploadDragActive = $state(false);
  let siteUploadDraft = $state<SiteUploadDraft | null>(null);
  let siteUploadAppName = $state('');
  let siteUploadAppIcon = $state('');
  let siteUploadAddedName = $state('');
  let siteUploadMetadataLoading = $state(false);
  let siteUploadPublishing = $state(false);
  let siteUploadError = $state<string | null>(null);
  let siteUploadProgress = $state<SiteUploadProgress | null>(null);
  let siteUploadPreviewVersion = 0;
  let longPressEditTimer: ReturnType<typeof setTimeout> | null = null;
  let longPressPointerId: number | null = null;
  let longPressStartX = 0;
  let longPressStartY = 0;
  let longPressShell: HTMLElement | null = null;
  let suppressNextSuggestionClickKey: string | null = null;

  function getSuggestionHref(suggestion: LauncherSuggestion): string {
    const site = getLauncherSuggestionSite(suggestion);
    if (!site) return suggestion.href;
    return buildSuggestedAppHref(
      site,
      typeof window !== 'undefined' ? window.location.host : undefined,
      suggestion.primaryHost,
    );
  }

  function getSuggestionForSite(site: HostedSite | null): LauncherSuggestion | null {
    if (!site) return null;
    return allKnownSuggestions.find((suggestion) => {
      if (site.kind === 'mutable') {
        return suggestion.ownerNpub === site.npub && suggestion.treeName === site.treeName;
      }
      return suggestion.nhash === site.nhash && (suggestion.entryPath || 'index.html') === (site.entryPath || 'index.html');
    }) ?? null;
  }

  function getFallbackSiteName(site: HostedSite): string {
    const formatSegment = (value: string) => value
      .replace(/\.[^.]+$/, '')
      .replace(/[-_]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, (match) => match.toUpperCase());
    if (site.kind === 'mutable') {
      return formatSegment(site.treeName.split('/').filter(Boolean).at(-1) || site.treeName) || site.treeName || 'App';
    }
    const entryPath = site.entryPath || 'index.html';
    const part = [...entryPath.split('/').filter(Boolean)]
      .reverse()
      .find((segment) => segment.toLowerCase() !== 'index.html') ?? '';
    return formatSegment(part) || 'App';
  }

  function getLaunchResultName(site: HostedSite, suggestion: LauncherSuggestion | null): string {
    if (suggestion) return suggestion.name;
    const title = site.title.trim();
    return title && title !== 'Isolated Site' && title !== 'Iris Site' ? title : getFallbackSiteName(site);
  }

  function getLaunchResultFallback(site: HostedSite, suggestion: LauncherSuggestion | null): string {
    return getLaunchResultName(site, suggestion).trim().charAt(0) || 'I';
  }

  function getLauncherAppCards(): HTMLElement[] {
    if (typeof document === 'undefined') return [];
    return Array.from(document.querySelectorAll<HTMLElement>(
      '.launcher-tools a.suggestion[href], .launcher-tools button.suggestion:not(:disabled)',
    ))
      .filter((card) => card.getClientRects().length > 0);
  }

  function getSuggestionCardKey(card: HTMLElement): string | null {
    return card.closest<HTMLElement>('.suggestion-shell')?.dataset.suggestionKey ?? null;
  }

  function getCardRects(cards: readonly HTMLElement[]): GridKeyboardRect[] {
    return cards.map((card) => {
      const rect = card.getBoundingClientRect();
      return {
        height: rect.height,
        left: rect.left,
        top: rect.top,
        width: rect.width,
      };
    });
  }

  function focusLauncherAppCard(card: HTMLElement): void {
    card.focus({ preventScroll: true });
    card.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }

  function focusLauncherAppCardAt(index: number): boolean {
    const cards = getLauncherAppCards();
    const card = cards[index];
    if (!card) return false;
    activeSuggestionKey = getSuggestionCardKey(card);
    focusLauncherAppCard(card);
    return true;
  }

  function setActiveSuggestion(suggestion: LauncherSuggestion): void {
    activeSuggestionKey = getLauncherSuggestionKey(suggestion);
  }

  function setActiveSuggestionCard(card: HTMLElement | undefined): boolean {
    if (!card) return false;
    const key = getSuggestionCardKey(card);
    if (!key) return false;
    activeSuggestionKey = key;
    card.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    return true;
  }

  function moveActiveSuggestion(direction: GridKeyboardDirection): void {
    const cards = getLauncherAppCards();
    if (cards.length === 0) return;
    const currentIndex = cards.findIndex((card) => getSuggestionCardKey(card) === activeSuggestionKey);
    if (currentIndex < 0) {
      const fallbackIndex = direction === 'left' || direction === 'up' ? cards.length - 1 : 0;
      setActiveSuggestionCard(cards[fallbackIndex]);
      return;
    }
    const nextIndex = getNextGridKeyboardIndex(getCardRects(cards), currentIndex, direction);
    setActiveSuggestionCard(cards[nextIndex]);
  }

  function clickActiveLauncherCard(): boolean {
    if (!activeSuggestionKey) return false;
    const activeCard = getLauncherAppCards()
      .find((card) => getSuggestionCardKey(card) === activeSuggestionKey);
    if (!activeCard) return false;
    activeCard.click();
    return true;
  }

  function clearAddLinkInput(): void {
    launchInput = '';
    launchResultHref = '';
    launchResultError = null;
  }

  function restoreLauncherFromHistory(event: PageTransitionEvent): void {
    if (!event.persisted) return;
    clearAddLinkInput();
    closeAddPanel();
  }

  function directionFromKey(key: string): GridKeyboardDirection | null {
    if (key === 'ArrowDown') return 'down';
    if (key === 'ArrowLeft') return 'left';
    if (key === 'ArrowRight') return 'right';
    if (key === 'ArrowUp') return 'up';
    return null;
  }

  function handleLauncherAppCardKeydown(event: KeyboardEvent, suggestion?: LauncherSuggestion): void {
    const currentCard = event.currentTarget instanceof HTMLElement ? event.currentTarget : null;
    if (!currentCard) return;

    if (event.key === 'Escape') {
      event.preventDefault();
      activeSuggestionKey = null;
      return;
    }

    if (customizeApps && suggestion) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        return;
      }

      const direction = directionFromKey(event.key);
      if (!direction) return;
      event.preventDefault();
      const offset = direction === 'left' || direction === 'up' ? -1 : 1;
      const sourceIndex = profileSuggestions.indexOf(suggestion);
      const target = profileSuggestions[sourceIndex + offset];
      if (!target) return;
      reorderSuggestionOnHome(getLauncherSuggestionKey(suggestion), getLauncherSuggestionKey(target));
      return;
    }

    if (event.key === 'Enter') {
      event.preventDefault();
      currentCard.click();
      return;
    }

    const direction = directionFromKey(event.key);
    if (!direction) return;

    const cards = getLauncherAppCards();
    const currentIndex = cards.indexOf(currentCard);
    if (currentIndex < 0) return;

    event.preventDefault();
    const nextIndex = getNextGridKeyboardIndex(getCardRects(cards), currentIndex, direction);
    focusLauncherAppCardAt(nextIndex);
  }

  function handleLauncherWindowKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape' || event.defaultPrevented) return;
    if (addPanelOpen) {
      event.preventDefault();
      closeAddPanel();
      return;
    }
    if (activeSuggestionKey) {
      event.preventDefault();
      activeSuggestionKey = null;
    }
  }

  function handleAddPanelKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape' || event.defaultPrevented) return;
    event.preventDefault();
    closeAddPanel();
  }

  function getLauncherHomeState() {
    return {
      hiddenSuggestionKeys,
      customSuggestions,
      orderedSuggestionKeys,
    };
  }

  function applyLauncherHomeState(state: ReturnType<typeof getLauncherHomeState>): void {
    hiddenSuggestionKeys = state.hiddenSuggestionKeys;
    customSuggestions = state.customSuggestions;
    orderedSuggestionKeys = state.orderedSuggestionKeys;
  }

  function removeSuggestionFromHome(suggestion: LauncherSuggestion): void {
    applyLauncherHomeState(removeLauncherHomeSuggestion(getLauncherHomeState(), suggestion));
  }

  function reorderSuggestionOnHome(sourceKey: string, targetKey: string): void {
    applyLauncherHomeState(
      reorderLauncherHomeSuggestion(getLauncherHomeState(), profileSuggestions, sourceKey, targetKey),
    );
  }

  function resetLauncherHome(): void {
    hiddenSuggestionKeys = [];
    customSuggestions = [];
    orderedSuggestionKeys = [];
    customizeApps = false;
    clearDragState();
  }

  function toggleCustomizeApps(): void {
    customizeApps = !customizeApps;
    clearDragState();
  }

  function resetSiteUpload(): void {
    siteUploadPreviewVersion += 1;
    siteUploadDraft = null;
    siteUploadAppName = '';
    siteUploadAppIcon = '';
    siteUploadAddedName = '';
    siteUploadMetadataLoading = false;
    siteUploadError = null;
    siteUploadProgress = null;
  }

  function openAddPanel(options: { reset?: boolean } = {}): void {
    addPanelOpen = true;
    activeSuggestionKey = ADD_SITE_CARD_KEY;
    if (options.reset) {
      resetSiteUpload();
      addUrlFormOpen = false;
    }
  }

  function closeAddPanel(): void {
    if (siteUploadPublishing) return;
    addPanelOpen = false;
    addUrlFormOpen = false;
    siteUploadDragActive = false;
  }

  function chooseAddByUrl(): void {
    addUrlFormOpen = true;
    siteUploadError = null;
    queueMicrotask(() => addLinkInput?.focus({ preventScroll: true }));
  }

  function backToAddChoices(): void {
    addUrlFormOpen = false;
    launchResultError = null;
  }

  function chooseSiteUploadFolder(): void {
    siteUploadFolderInput?.click();
  }

  function chooseSiteUploadFiles(): void {
    siteUploadFileInput?.click();
  }

  function getSiteUploadFallbackName(draft: SiteUploadDraft): string {
    return draft.rootName || draft.entryPath.split('/').filter(Boolean).at(-1) || 'App';
  }

  function getSiteUploadAppName(draft: SiteUploadDraft): string {
    return siteUploadAppName.trim() || getSiteUploadFallbackName(draft);
  }

  function getSiteUploadAppFallback(draft: SiteUploadDraft): string {
    return getSiteUploadAppName(draft).charAt(0) || 'A';
  }

  async function previewSiteUploadFiles(files: FileList | Iterable<File>): Promise<void> {
    siteUploadError = null;
    siteUploadProgress = null;
    siteUploadAddedName = '';
    openAddPanel();

    try {
      const previewVersion = ++siteUploadPreviewVersion;
      const draft = createSiteUploadDraft(files);
      siteUploadDraft = draft;
      siteUploadAppName = getSiteUploadFallbackName(draft);
      siteUploadAppIcon = '';
      siteUploadMetadataLoading = true;

      try {
        const metadata = await inferSiteUploadAppMetadata(draft);
        if (siteUploadPreviewVersion !== previewVersion) return;
        siteUploadAppName = metadata.name || getSiteUploadFallbackName(draft);
        siteUploadAppIcon = metadata.icon ?? '';
      } finally {
        if (siteUploadPreviewVersion === previewVersion) siteUploadMetadataLoading = false;
      }
    } catch (error) {
      siteUploadDraft = null;
      siteUploadMetadataLoading = false;
      siteUploadError = error instanceof Error ? error.message : String(error);
    }
  }

  async function handleSiteUploadInputChange(event: Event): Promise<void> {
    const input = event.currentTarget instanceof HTMLInputElement ? event.currentTarget : null;
    const files = input?.files;

    if (!files || files.length === 0) {
      return;
    }

    const selectedFiles = Array.from(files);
    try {
      await previewSiteUploadFiles(selectedFiles);
    } finally {
      if (input) input.value = '';
    }
  }

  async function previewSiteUploadText(text: string): Promise<void> {
    const trimmed = text.trim();
    if (!trimmed) {
      siteUploadError = 'Paste text or choose files first.';
      return;
    }
    await previewSiteUploadFiles([createSiteUploadTextFile(text)]);
  }

  function addParsedLaunchSiteToHome(): void {
    if (!parsedLaunchSite) return;
    const suggestion = createLauncherSuggestionFromSite(parsedLaunchSite);
    if (!suggestion) return;

    applyLauncherHomeState(addLauncherHomeSuggestion(getLauncherHomeState(), suggestion));
    customizeApps = true;
    activeSuggestionKey = getLauncherSuggestionKey(suggestion);
    launchInput = '';
    closeAddPanel();
  }

  async function handleAddPanelPaste(event: ClipboardEvent): Promise<void> {
    const clipboard = event.clipboardData;
    if (!clipboard) return;

    const files = await getSiteUploadFilesFromDataTransfer(clipboard);
    if (files.length > 0) {
      event.preventDefault();
      await previewSiteUploadFiles(files);
      return;
    }

    const text = clipboard.getData('text/plain');
    if (!text.trim()) return;
    if (parseLaunchInput(text)) {
      event.preventDefault();
      launchInput = text.trim();
      siteUploadError = null;
      siteUploadAddedName = '';
      openAddPanel();
      return;
    }

    const target = event.target;
    const isEditable = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement;
    if (isEditable && addPanelOpen) return;
    event.preventDefault();
    await previewSiteUploadText(text);
  }

  async function handleLauncherDrop(event: DragEvent): Promise<void> {
    const dataTransfer = event.dataTransfer;
    if (!dataTransfer) return;
    event.preventDefault();
    siteUploadDragActive = false;
    const files = await getSiteUploadFilesFromDataTransfer(dataTransfer);
    if (files.length > 0) {
      await previewSiteUploadFiles(files);
      openAddPanel();
      return;
    }
    const text = dataTransfer.getData('text/plain');
    if (text.trim()) {
      if (parseLaunchInput(text)) {
        launchInput = text.trim();
        openAddPanel();
        return;
      }
      await previewSiteUploadText(text);
      openAddPanel();
    }
  }

  function handleLauncherDragOver(event: DragEvent): void {
    if (!event.dataTransfer) return;
    event.preventDefault();
    siteUploadDragActive = true;
    activeSuggestionKey = ADD_SITE_CARD_KEY;
    event.dataTransfer.dropEffect = 'copy';
  }

  function handleLauncherDragLeave(event: DragEvent): void {
    if (event.currentTarget !== event.target) return;
    siteUploadDragActive = false;
  }

  function describeSiteUploadProgress(progress: SiteUploadProgress): string {
    if (progress.total <= 0) return progress.label;
    if (progress.phase === 'building') {
      return `${progress.label} ${formatSiteUploadBytes(progress.current)} / ${formatSiteUploadBytes(progress.total)}`;
    }
    if (progress.phase === 'uploading') {
      return `${progress.label} ${progress.current}/${progress.total}`;
    }
    return progress.label;
  }

  function formatSiteUploadFileCount(count: number): string {
    return `${count} ${count === 1 ? 'file' : 'files'}`;
  }

  async function confirmSiteUpload(): Promise<void> {
    if (!siteUploadDraft || siteUploadPublishing || typeof window === 'undefined') return;

    const draft = siteUploadDraft;
    const name = getSiteUploadAppName(draft);
    const icon = siteUploadAppIcon || undefined;

    siteUploadPublishing = true;
    siteUploadError = null;
    siteUploadAddedName = '';
    siteUploadProgress = {
      current: 0,
      label: 'Preparing app folder',
      phase: 'building',
      total: draft.totalBytes,
    };
    let uploadAdded = false;

    try {
      const published = await publishSiteUploadDraft(draft, {
        currentHost: window.location.host,
        onProgress: (progress) => {
          siteUploadProgress = progress;
        },
      });
      const suggestion = createLauncherSuggestionFromSite({
        kind: 'immutable',
        siteKey: published.immutableNhash,
        title: name,
        nhash: published.immutableNhash,
        entryPath: draft.entryPath || 'index.html',
      });
      if (!suggestion) throw new Error('Could not create app shortcut.');
      const appSuggestion = {
        ...suggestion,
        icon,
      };
      applyLauncherHomeState(addLauncherHomeSuggestion(getLauncherHomeState(), appSuggestion));
      activeSuggestionKey = getLauncherSuggestionKey(appSuggestion);
      siteUploadDraft = null;
      siteUploadAppName = '';
      siteUploadAppIcon = '';
      siteUploadAddedName = '';
      siteUploadProgress = null;
      uploadAdded = true;
    } catch (error) {
      siteUploadError = error instanceof Error ? error.message : String(error);
    } finally {
      siteUploadPublishing = false;
      if (uploadAdded) closeAddPanel();
    }
  }

  function submitAddLink(event: SubmitEvent): void {
    event.preventDefault();
    if (!parsedLaunchSite) {
      siteUploadError = launchInput.trim() ? 'Paste a valid htree link.' : 'Paste a link first.';
      return;
    }
    addParsedLaunchSiteToHome();
  }

  function getSuggestionShellAtPoint(clientX: number, clientY: number): HTMLElement | null {
    if (typeof document === 'undefined') return null;
    const element = document.elementFromPoint(clientX, clientY);
    return element instanceof HTMLElement ? element.closest<HTMLElement>('.suggestion-shell') : null;
  }

  function clearDragState(): void {
    draggingSuggestionKey = null;
    dragGhost = null;
  }

  function clearLongPressEditTimer(): void {
    if (longPressEditTimer) {
      clearTimeout(longPressEditTimer);
      longPressEditTimer = null;
    }
    try {
      if (longPressShell && longPressPointerId !== null && longPressShell.hasPointerCapture?.(longPressPointerId)) {
        longPressShell.releasePointerCapture(longPressPointerId);
      }
    } catch {
      // Pointer capture can disappear when the browser ends the gesture first.
    }
    longPressPointerId = null;
    longPressShell = null;
  }

  function moveSuggestionDrag(clientX: number, clientY: number): void {
    if (!customizeApps || !draggingSuggestionKey || !dragGhost) return;
    dragGhost = {
      ...dragGhost,
      x: clientX,
      y: clientY,
    };

    const targetShell = getSuggestionShellAtPoint(clientX, clientY);
    const targetKey = targetShell?.dataset.suggestionKey;
    if (!targetKey || targetKey === draggingSuggestionKey) return;

    reorderSuggestionOnHome(draggingSuggestionKey, targetKey);
  }

  function startSuggestionDrag(
    event: PointerEvent,
    suggestion: LauncherSuggestion,
    shellOverride?: HTMLElement | null,
  ): void {
    if (event.pointerType === 'mouse' && event.button !== 0) return;

    event.preventDefault();
    draggingSuggestionKey = getLauncherSuggestionKey(suggestion);
    dragGhost = {
      fallback: suggestion.name.trim().charAt(0) || 'I',
      icon: suggestion.icon,
      lift: event.pointerType !== 'mouse',
      name: suggestion.name,
      x: event.clientX,
      y: event.clientY,
    };
    const shell = shellOverride ?? (event.currentTarget instanceof HTMLElement ? event.currentTarget : null);
    shell?.setPointerCapture?.(event.pointerId);
  }

  function handleSuggestionPointerDown(event: PointerEvent, suggestion: LauncherSuggestion): void {
    const shell = event.currentTarget instanceof HTMLElement ? event.currentTarget : null;

    if (customizeApps) {
      startSuggestionDrag(event, suggestion, shell);
      return;
    }

    if (event.pointerType === 'mouse' && event.button !== 0) return;

    clearLongPressEditTimer();
    longPressPointerId = event.pointerId;
    longPressStartX = event.clientX;
    longPressStartY = event.clientY;
    longPressShell = shell;
    longPressEditTimer = setTimeout(() => {
      longPressEditTimer = null;
      customizeApps = true;
      suppressNextSuggestionClickKey = getLauncherSuggestionKey(suggestion);
      startSuggestionDrag(event, suggestion, longPressShell);
    }, MOBILE_EDIT_LONG_PRESS_MS);
  }

  function handleSuggestionPointerMove(event: PointerEvent): void {
    if (longPressPointerId === event.pointerId && !draggingSuggestionKey) {
      const moved = Math.hypot(event.clientX - longPressStartX, event.clientY - longPressStartY);
      if (moved > LONG_PRESS_MOVE_TOLERANCE_PX) {
        clearLongPressEditTimer();
      }
    }

    if (!customizeApps || !draggingSuggestionKey) return;
    event.preventDefault();
    moveSuggestionDrag(event.clientX, event.clientY);
  }

  function handleSuggestionTouchMove(event: TouchEvent): void {
    if (!customizeApps || !draggingSuggestionKey) return;

    event.preventDefault();
    const touch = event.touches[0] ?? event.changedTouches[0];
    if (!touch) return;
    moveSuggestionDrag(touch.clientX, touch.clientY);
  }

  function handleSuggestionPointerUp(event: PointerEvent): void {
    clearLongPressEditTimer();
    if (!draggingSuggestionKey) return;

    const shell = event.currentTarget instanceof HTMLElement ? event.currentTarget : null;
    shell?.releasePointerCapture?.(event.pointerId);
    clearDragState();
  }

  function handleGlobalSuggestionPointerEnd(): void {
    clearLongPressEditTimer();
    if (!draggingSuggestionKey) return;
    clearDragState();
  }

  function handleLauncherBackdropPointerDown(event: PointerEvent): void {
    if (!customizeApps || (event.pointerType === 'mouse' && event.button !== 0)) return;
    const target = event.target;
    if (
      target instanceof Element &&
      (target.closest('.suggestion-shell') || target.closest('.home-toolbar'))
    ) {
      return;
    }
    customizeApps = false;
    clearDragState();
  }

  function handleSuggestionClick(event: MouseEvent): void {
    const shell = event.currentTarget instanceof HTMLElement
      ? event.currentTarget.closest<HTMLElement>('.suggestion-shell')
      : null;
    const key = shell?.dataset.suggestionKey ?? null;
    if (customizeApps || (key && key === suppressNextSuggestionClickKey)) {
      event.preventDefault();
      suppressNextSuggestionClickKey = null;
    }
  }

  function handleSuggestionNativeDragStart(event: DragEvent): void {
    event.preventDefault();
  }

  function isLegacyContactSuggestion(suggestion: LauncherSuggestion): boolean {
    return LEGACY_CONTACT_SUGGESTION_NAMES.has(suggestion.name);
  }

  function currentWindowHost(): string | undefined {
    return typeof window !== 'undefined' ? window.location.host : undefined;
  }

  const allKnownSuggestions = $derived.by(() => [...launcherSuggestions, ...customSuggestions]);
  const profileSuggestions = $derived.by(() => {
    const suggestions = getVisibleLauncherSuggestions(
      launcherSuggestions,
      customSuggestions,
      hiddenSuggestionKeys,
      orderedSuggestionKeys,
    );
    return profile ? suggestions.filter((suggestion) => suggestion.ownerNpub === profile.npub) : suggestions;
  });
  const parsedLaunchSite = $derived.by(() => parseLaunchInput(launchInput));
  const launchResultSuggestion = $derived.by(() => getSuggestionForSite(parsedLaunchSite));
  const filteredProfileSuggestions = $derived.by(() => profileSuggestions);
  const primaryLauncherSuggestions = $derived.by(() =>
    filteredProfileSuggestions.filter((suggestion) => !isLegacyContactSuggestion(suggestion))
  );
  const legacyContactSuggestions = $derived.by(() =>
    filteredProfileSuggestions.filter(isLegacyContactSuggestion)
  );
  const irisDriveDownloadHref = $derived.by(() =>
    buildIrisDriveDownloadHref(currentWindowHost())
  );
  const showOfflineDrivePrompt = $derived.by(() =>
    shouldShowIrisDriveDownloadPrompt(currentWindowHost())
  );
  const siteUploadHiddenFileCount = $derived.by(() =>
    siteUploadDraft ? Math.max(0, siteUploadDraft.fileCount - siteUploadDraft.previewFiles.length) : 0
  );
  const siteUploadProgressPercent = $derived.by(() => {
    if (!siteUploadProgress || siteUploadProgress.total <= 0) return 0;
    return Math.max(0, Math.min(100, (siteUploadProgress.current / siteUploadProgress.total) * 100));
  });
  onMount(() => {
    if (typeof window === 'undefined') return;
    const state = parseLauncherHomeState(window.localStorage.getItem(LAUNCHER_HOME_STORAGE_KEY));
    applyLauncherHomeState(state);
    launcherHomeLoaded = true;

    window.addEventListener('pageshow', restoreLauncherFromHistory);
    window.addEventListener('touchmove', handleSuggestionTouchMove, { passive: false });
    return () => {
      window.removeEventListener('pageshow', restoreLauncherFromHistory);
      window.removeEventListener('touchmove', handleSuggestionTouchMove);
    };
  });

  $effect(() => {
    if (!launcherHomeLoaded || typeof window === 'undefined') return;
    window.localStorage.setItem(
      LAUNCHER_HOME_STORAGE_KEY,
      serializeLauncherHomeState(getLauncherHomeState()),
    );
  });

  $effect(() => {
    const visibleKeys = [
      ADD_SITE_CARD_KEY,
      ...primaryLauncherSuggestions.map((suggestion) => getLauncherSuggestionKey(suggestion)),
      ...legacyContactSuggestions.map((suggestion) => getLauncherSuggestionKey(suggestion)),
    ];

    if (customizeApps || visibleKeys.length === 0) {
      activeSuggestionKey = null;
      return;
    }

    if (activeSuggestionKey && !visibleKeys.includes(activeSuggestionKey)) {
      activeSuggestionKey = null;
    }
  });

  $effect(() => {
    const site = parsedLaunchSite;
    const version = ++launchResultVersion;
    launchResultHref = '';
    launchResultError = null;

    if (!site || typeof window === 'undefined') {
      return;
    }

    void buildIsolatedSiteHref(site, window.location.host)
      .then((href) => {
        if (version !== launchResultVersion) return;
        launchResultHref = href;
      })
      .catch((error) => {
        if (version !== launchResultVersion) return;
        launchResultError = error instanceof Error ? error.message : String(error);
      });
  });

</script>

<svelte:window
  onkeydown={handleLauncherWindowKeydown}
  onpaste={handleAddPanelPaste}
  onpointerup={handleGlobalSuggestionPointerEnd}
  onpointercancel={handleGlobalSuggestionPointerEnd}
/>

<main
  class="screen launcher-screen"
  class:dragging-upload={siteUploadDragActive}
  onpointerdown={handleLauncherBackdropPointerDown}
  ondragover={handleLauncherDragOver}
  ondragleave={handleLauncherDragLeave}
  ondrop={handleLauncherDrop}
>
  <div class="launcher-shell">
    <header class="launcher-header">
      <h1>
        <span class="launcher-title-row">
          <img
            class="launcher-title-logo"
            src={launcherAsset('favicon.svg')}
            alt=""
            aria-hidden="true"
            decoding="async"
          />
          <span class="launcher-title-text">Iris: The Freedom Toolkit</span>
        </span>
      </h1>
      <p class="launcher-subheading">No email address, phone number, or sign-up required.</p>
    </header>
    <div class="launcher-tools">
      <div class="launcher-top-row" class:has-profile={profile}>
        {#if profile}
          <a class="profile-user-link" href={getLauncherProfileHref(profile.npub)}>
            <UserRow
              pubkey={profile.pubkey}
              profile={profile}
              avatarSize={44}
              class="iris-sites-user-row profile-user-row"
            />
          </a>
        {/if}
      </div>
      {#if customizeApps}
        <div class="home-toolbar editing">
          <button class="home-action-button" type="button" onclick={resetLauncherHome}>Reset</button>
          <button class="home-action-button" type="button" onclick={toggleCustomizeApps}>Done</button>
        </div>
      {/if}
      <div class="suggestions" role="list" aria-label="Apps">
        <div
          class="suggestion-shell add-site-shell"
          role="listitem"
          class:active={activeSuggestionKey === ADD_SITE_CARD_KEY || siteUploadDragActive}
          data-suggestion-key={ADD_SITE_CARD_KEY}
          onfocusin={() => {
            activeSuggestionKey = ADD_SITE_CARD_KEY;
          }}
        >
          <button
            class="suggestion add-site-tile"
            type="button"
            aria-label="Add site, folder, files, or text"
            onclick={() => openAddPanel({ reset: true })}
            onkeydown={handleLauncherAppCardKeydown}
            disabled={siteUploadPublishing}
            data-testid="add-site-button"
          >
            <span class="suggestion-media add-site-media" aria-hidden="true">
              <span class="add-site-plus">+</span>
            </span>
            <span class="suggestion-name">Add</span>
          </button>
        </div>
        {#each primaryLauncherSuggestions as suggestion (getLauncherSuggestionKey(suggestion))}
          {@const suggestionKey = getLauncherSuggestionKey(suggestion)}
          <div
            class="suggestion-shell"
            role="listitem"
            class:editing={customizeApps}
            class:dragging={draggingSuggestionKey === suggestionKey}
            class:active={activeSuggestionKey === suggestionKey}
            data-suggestion-key={suggestionKey}
            onfocusin={() => setActiveSuggestion(suggestion)}
            onpointerdown={(event) => handleSuggestionPointerDown(event, suggestion)}
            onpointermove={handleSuggestionPointerMove}
            onpointerup={handleSuggestionPointerUp}
            onpointercancel={handleSuggestionPointerUp}
            ondragstart={handleSuggestionNativeDragStart}
          >
            <a
              class="suggestion"
              href={getSuggestionHref(suggestion)}
              aria-disabled={customizeApps}
              draggable="false"
              target={suggestion.external ? '_blank' : undefined}
              rel={suggestion.external ? 'noopener noreferrer' : undefined}
              onkeydown={(event) => handleLauncherAppCardKeydown(event, suggestion)}
              onclick={handleSuggestionClick}
            >
              <span class="suggestion-media" aria-hidden="true">
                {#if suggestion.icon}
                  <img class="suggestion-icon" src={suggestion.icon} alt="" loading="lazy" draggable="false" />
                {:else}
                  <span class="suggestion-fallback">{suggestion.name.charAt(0)}</span>
                {/if}
              </span>
              <span class="suggestion-name">{suggestion.name}</span>
            </a>
            {#if customizeApps}
              <div
                class="suggestion-action-shell"
                role="presentation"
                onpointerdown={(event) => event.stopPropagation()}
              >
                <button
                  class="suggestion-remove-button"
                  type="button"
                  aria-label={`Remove ${suggestion.name} from home`}
                  onclick={() => removeSuggestionFromHome(suggestion)}
                >
                  <svg class="suggestion-remove-mark" viewBox="0 0 12 12" aria-hidden="true">
                    <path d="M3 6h6" />
                  </svg>
                </button>
              </div>
            {/if}
          </div>
        {/each}
      </div>
      {#if showOfflineDrivePrompt}
        <a class="offline-drive-row" href={irisDriveDownloadHref} target="_blank" rel="noopener noreferrer">
          <svg class="offline-drive-icon" viewBox="0 0 20 20" aria-hidden="true">
            <path d="M10 3v8m0 0 4-4m-4 4L6 7M4 15h12" />
          </svg>
          <span>Download Iris Drive to use these apps offline</span>
        </a>
      {/if}
      {#if legacyContactSuggestions.length > 0}
        <section class="legacy-contact-section" aria-labelledby="legacy-contact-heading">
          <h2 id="legacy-contact-heading">If you still need a phone number or email:</h2>
          <div class="legacy-contact-grid suggestions" role="list" aria-label="Phone number and email">
            {#each legacyContactSuggestions as suggestion (getLauncherSuggestionKey(suggestion))}
              {@const suggestionKey = getLauncherSuggestionKey(suggestion)}
              <div
                class="suggestion-shell"
                role="listitem"
                class:editing={customizeApps}
                class:dragging={draggingSuggestionKey === suggestionKey}
                class:active={activeSuggestionKey === suggestionKey}
                data-suggestion-key={suggestionKey}
                onfocusin={() => setActiveSuggestion(suggestion)}
                onpointerdown={(event) => handleSuggestionPointerDown(event, suggestion)}
                onpointermove={handleSuggestionPointerMove}
                onpointerup={handleSuggestionPointerUp}
                onpointercancel={handleSuggestionPointerUp}
                ondragstart={handleSuggestionNativeDragStart}
              >
                <a
                  class="suggestion"
                  href={getSuggestionHref(suggestion)}
                  aria-disabled={customizeApps}
                  draggable="false"
                  target={suggestion.external ? '_blank' : undefined}
                  rel={suggestion.external ? 'noopener noreferrer' : undefined}
                  onkeydown={(event) => handleLauncherAppCardKeydown(event, suggestion)}
                  onclick={handleSuggestionClick}
                >
                  <span class="suggestion-media" aria-hidden="true">
                    {#if suggestion.icon}
                      <img class="suggestion-icon" src={suggestion.icon} alt="" loading="lazy" draggable="false" />
                    {:else}
                      <span class="suggestion-fallback">{suggestion.name.charAt(0)}</span>
                    {/if}
                  </span>
                  <span class="suggestion-name">{suggestion.name}</span>
                </a>
                {#if customizeApps}
                  <div
                    class="suggestion-action-shell"
                    role="presentation"
                    onpointerdown={(event) => event.stopPropagation()}
                  >
                    <button
                      class="suggestion-remove-button"
                      type="button"
                      aria-label={`Remove ${suggestion.name} from home`}
                      onclick={() => removeSuggestionFromHome(suggestion)}
                    >
                      <svg class="suggestion-remove-mark" viewBox="0 0 12 12" aria-hidden="true">
                        <path d="M3 6h6" />
                      </svg>
                    </button>
                  </div>
                {/if}
              </div>
            {/each}
          </div>
        </section>
      {/if}
      {#if addPanelOpen}
        <section class="add-site-backdrop" role="presentation" onclick={(event) => {
          if (event.currentTarget === event.target) closeAddPanel();
        }}>
          <div class="add-site-panel" role="dialog" aria-modal="true" aria-label="Add site" tabindex="-1" onkeydown={handleAddPanelKeydown}>
            <span class="add-site-grabber" aria-hidden="true"></span>
            <div class="add-site-header">
              {#if addUrlFormOpen}
                <button class="home-action-button add-site-back-button" type="button" onclick={backToAddChoices} aria-label="Back">
                  <svg class="add-site-back-icon" viewBox="0 0 20 20" aria-hidden="true">
                    <path d="m12 5-5 5 5 5" />
                  </svg>
                </button>
              {/if}
              <h2>{addUrlFormOpen ? 'Add by URL' : 'Add app or site'}</h2>
            </div>
            <section class="site-upload-panel" aria-label="Upload preview" onpaste={handleAddPanelPaste}>
              <input
                class="site-upload-input"
                type="file"
                multiple
                webkitdirectory
                bind:this={siteUploadFolderInput}
                disabled={siteUploadPublishing}
                aria-label="Upload folder"
                data-testid="site-upload-folder-input"
                onchange={handleSiteUploadInputChange}
              />
              <input
                class="site-upload-input"
                type="file"
                multiple
                bind:this={siteUploadFileInput}
                disabled={siteUploadPublishing}
                aria-label="Upload files"
                data-testid="site-upload-file-input"
                onchange={handleSiteUploadInputChange}
              />
              {#if addUrlFormOpen}
                <form class="launcher-form add-link-form" onsubmit={submitAddLink}>
                  <div class="add-link-row">
                    <input
                      id="site-route"
                      name="site-route"
                      class="launcher-input"
                      type="text"
                      bind:this={addLinkInput}
                      bind:value={launchInput}
                      placeholder="URL"
                      aria-label="URL"
                      autocomplete="off"
                      autocapitalize="off"
                      spellcheck="false"
                    />
                  </div>
                  {#if parsedLaunchSite && launchResultHref}
                    <div class="launch-result-row">
                      <button class="suggestion launch-result-card" type="button" onclick={addParsedLaunchSiteToHome}>
                        <span class="suggestion-media" aria-hidden="true">
                          {#if launchResultSuggestion?.icon}
                            <img class="suggestion-icon" src={launchResultSuggestion.icon} alt="" loading="lazy" />
                          {:else}
                            <span class="suggestion-fallback">{getLaunchResultFallback(parsedLaunchSite, launchResultSuggestion)}</span>
                          {/if}
                        </span>
                        <span class="suggestion-name">{getLaunchResultName(parsedLaunchSite, launchResultSuggestion)}</span>
                      </button>
                    </div>
                  {/if}
                  {#if launchResultError}
                    <p class="launcher-error">{launchResultError}</p>
                  {/if}
                </form>
              {:else if !siteUploadDraft}
                <div class="site-upload-actions site-upload-source-actions">
                  <button class="home-action-button site-upload-source-button" type="button" onclick={chooseAddByUrl} disabled={siteUploadPublishing}>
                    <svg class="site-upload-source-icon" viewBox="0 0 20 20" aria-hidden="true">
                      <path d="M7.4 10.8 6.1 12a2.6 2.6 0 0 0 3.7 3.7l1.8-1.8a2.6 2.6 0 0 0 0-3.7" />
                      <path d="M12.6 9.2 13.9 8a2.6 2.6 0 0 0-3.7-3.7L8.4 6.1a2.6 2.6 0 0 0 0 3.7" />
                      <path d="m8.8 11.2 2.4-2.4" />
                    </svg>
                    <span>Add by URL</span>
                  </button>
                  <button class="home-action-button site-upload-source-button" type="button" onclick={chooseSiteUploadFolder} disabled={siteUploadPublishing}>
                    <svg class="site-upload-source-icon" viewBox="0 0 20 20" aria-hidden="true">
                      <path d="M3 6.2c0-.66.54-1.2 1.2-1.2h4.1l1.6 1.8h5.9c.66 0 1.2.54 1.2 1.2v5.8c0 .66-.54 1.2-1.2 1.2H4.2c-.66 0-1.2-.54-1.2-1.2V6.2Z" />
                    </svg>
                    <span>Upload folder</span>
                  </button>
                  <button class="home-action-button site-upload-source-button" type="button" onclick={chooseSiteUploadFiles} disabled={siteUploadPublishing}>
                    <svg class="site-upload-source-icon" viewBox="0 0 20 20" aria-hidden="true">
                      <path d="M6 3.5h5.1L15 7.4v9.1H6V3.5Z" />
                      <path d="M11 3.7v3.9h3.8" />
                      <path d="M4 6.5v10h8" />
                    </svg>
                    <span>Upload files</span>
                  </button>
                </div>
              {/if}
              {#if siteUploadDraft}
                <div class="site-upload-preview">
                  <div class="site-upload-app-row">
                    <span class="site-upload-app-icon" aria-hidden="true" data-testid="site-upload-app-icon">
                      {#if siteUploadAppIcon}
                        <img src={siteUploadAppIcon} alt="" />
                      {:else}
                        <span>{getSiteUploadAppFallback(siteUploadDraft)}</span>
                      {/if}
                    </span>
                    <label class="site-upload-name-field">
                      <span>App name</span>
                      <input
                        type="text"
                        bind:value={siteUploadAppName}
                        aria-label="App name"
                        data-testid="site-upload-app-name"
                        disabled={siteUploadPublishing}
                      />
                    </label>
                  </div>
                  <div class="site-upload-stats" aria-label="Selected upload summary">
                    <span>{formatSiteUploadFileCount(siteUploadDraft.fileCount)}</span>
                    <span>{formatSiteUploadBytes(siteUploadDraft.totalBytes)}</span>
                    <span>opens {siteUploadDraft.entryPath}</span>
                  </div>
                  <ul class="site-upload-files" aria-label="Files to publish">
                    {#each siteUploadDraft.previewFiles as uploadFile}
                      <li>
                        <span>{uploadFile.path}</span>
                        <span>{formatSiteUploadBytes(uploadFile.size)}</span>
                      </li>
                    {/each}
                  </ul>
                  {#if siteUploadHiddenFileCount > 0}
                    <p class="site-upload-message">{siteUploadHiddenFileCount} more files</p>
                  {/if}
                  <div class="site-upload-actions">
                    <button
                      class="publish-button"
                      type="button"
                      onclick={confirmSiteUpload}
                      disabled={siteUploadPublishing || siteUploadMetadataLoading}
                      data-testid="site-upload-confirm"
                    >
                      {siteUploadPublishing ? 'Adding' : 'Add'}
                    </button>
                    <button class="home-action-button" type="button" onclick={resetSiteUpload} disabled={siteUploadPublishing}>
                      Cancel
                    </button>
                  </div>
                </div>
              {/if}
              {#if siteUploadProgress}
                <div class="site-upload-progress" aria-live="polite">
                  <p>{describeSiteUploadProgress(siteUploadProgress)}</p>
                  <div class="site-upload-progress-track" aria-hidden="true">
                    <span style={`width: ${siteUploadProgressPercent}%;`}></span>
                  </div>
                </div>
              {/if}
              {#if siteUploadAddedName}
                <p class="site-upload-message">Added {siteUploadAddedName}</p>
              {/if}
              {#if siteUploadError}
                <p class="site-upload-message site-upload-error">{siteUploadError}</p>
              {/if}
            </section>
          </div>
        </section>
      {/if}
      {#if dragGhost}
        <div
          class="suggestion-drag-ghost"
          class:lift={dragGhost.lift}
          style={`left: ${dragGhost.x}px; top: ${dragGhost.y}px;`}
          aria-hidden="true"
        >
          <span class="suggestion-media">
            {#if dragGhost.icon}
              <img class="suggestion-icon" src={dragGhost.icon} alt="" />
            {:else}
              <span class="suggestion-fallback">{dragGhost.fallback}</span>
            {/if}
          </span>
          <span class="suggestion-name">{dragGhost.name}</span>
        </div>
      {/if}
      {#if profile && profileSuggestions.length === 0}
        <p class="empty-profile-copy">No catalogued apps yet.</p>
      {/if}
    </div>
  </div>
</main>
