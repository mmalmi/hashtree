import '@hashtree/worker/entry';
