/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />

declare module 'wasm-git' {
  const createModule: (options?: Record<string, unknown>) => Promise<any>;
  export default createModule;
}
