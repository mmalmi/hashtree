/**
 * iris sites service worker
 *
 * Handles /htree/{nhash}/{filename} requests by streaming bytes from the
 * shared hashtree worker via a registered MessagePort.
 */

/// <reference lib="webworker" />
import { BlossomStore, HashTree, nhashDecode, type CID } from '@hashtree/core';
import { getRawHtreePath, parseImmutableHtreePath, parseMutableHtreePath } from '@hashtree/worker/htree-path';
import { precacheAndRoute } from 'workbox-precaching';

declare let self: ServiceWorkerGlobalScope & {
  __WB_MANIFEST: Array<unknown>;
};

const isTestMode = !!import.meta.env.VITE_TEST_MODE;
const PORT_TIMEOUT_MS = 60_000;
const DIRECT_IMMUTABLE_PRE_PORT_TIMEOUT_MS = 1_500;
const DIRECT_IMMUTABLE_FALLBACK_TIMEOUT_MS = 8_000;

if (!isTestMode) {
  precacheAndRoute(self.__WB_MANIFEST);
}

if (isTestMode) {
  self.addEventListener('install', (event) => {
    event.waitUntil(self.skipWaiting());
  });

  self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
      await self.clients.claim();
    })());
  });
}

interface HtreeFileRequest {
  type: 'hashtree-file';
  requestId: string;
  npub?: string;
  nhash?: string;
  snapshot?: boolean;
  linkKey?: string | null;
  treeName?: string;
  path: string;
  start: number;
  end?: number;
  rangeHeader?: string | null;
  mimeType: string;
  download?: boolean;
  head?: boolean;
}

interface WorkerHeadersMessage {
  type: 'headers';
  requestId: string;
  status?: number;
  headers?: Record<string, string>;
}

interface WorkerChunkMessage {
  type: 'chunk';
  requestId: string;
  data: Uint8Array;
}

interface WorkerDoneMessage {
  type: 'done';
  requestId: string;
}

interface WorkerErrorMessage {
  type: 'error';
  requestId: string;
  message?: string;
}

type WorkerMessage = WorkerHeadersMessage | WorkerChunkMessage | WorkerDoneMessage | WorkerErrorMessage;

interface PendingRequest {
  resolve: (response: Response) => void;
  reject: (error: Error) => void;
  head: boolean;
  timer: ReturnType<typeof setTimeout>;
  writer?: WritableStreamDefaultWriter<Uint8Array>;
}

interface RuntimeRequestContext {
  clientKey?: string | null;
  origin: string;
  target: {
    nhash?: string;
    npub?: string;
    treeName?: string;
  };
}

const workerPorts = new Map<string, MessagePort>();
const workerPortsByClientKey = new Map<string, MessagePort>();
const runtimeContextsByClientId = new Map<string, RuntimeRequestContext>();
const runtimeContextsByClientKey = new Map<string, RuntimeRequestContext>();
const runtimeContextsByOrigin = new Map<string, RuntimeRequestContext>();
let defaultWorkerPort: MessagePort | null = null;
const pendingRequests = new Map<string, PendingRequest>();
let requestCounter = 0;
let directImmutableTree: HashTree | null = null;

function getDirectImmutableTree(): HashTree {
  if (!directImmutableTree) {
    directImmutableTree = new HashTree({
      store: new BlossomStore({
        servers: [
          { url: 'https://cdn.iris.to', read: true, write: false, preferBatchReads: true },
          { url: 'https://upload.iris.to', read: true, write: true, preferBatchReads: true },
          { url: 'https://blossom.primal.net', read: true, write: true },
        ],
      }),
    });
  }
  return directImmutableTree;
}

function guessMimeType(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    html: 'text/html',
    css: 'text/css',
    js: 'application/javascript',
    mjs: 'application/javascript',
    json: 'application/json',
    txt: 'text/plain',
    svg: 'image/svg+xml',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    webp: 'image/webp',
    gif: 'image/gif',
    ico: 'image/x-icon',
    mp4: 'video/mp4',
    webm: 'video/webm',
    mp3: 'audio/mpeg',
    wav: 'audio/wav',
    woff: 'font/woff',
    woff2: 'font/woff2',
    ttf: 'font/ttf',
  };
  return map[ext] || 'application/octet-stream';
}

function parseRange(rangeHeader: string | null): { start: number; end?: number } {
  if (!rangeHeader) return { start: 0 };
  const match = rangeHeader.match(/bytes=(\d*)-(\d*)/);
  if (!match) return { start: 0 };
  return {
    start: match[1] ? Number.parseInt(match[1], 10) : 0,
    end: match[2] ? Number.parseInt(match[2], 10) : undefined,
  };
}

function addCORSHeaders(response: Response): Response {
  const headers = new Headers(response.headers);
  headers.set('Access-Control-Allow-Origin', '*');
  headers.set('Cross-Origin-Resource-Policy', 'cross-origin');
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

function bytesToResponseBody(bytes: Uint8Array): ArrayBuffer {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

async function runWithTimeout<T>(
  createPromise: (signal: AbortSignal) => Promise<T | null>,
  timeoutMs: number,
): Promise<T | null> {
  const controller = new AbortController();
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  const timeout = new Promise<null>((resolve) => {
    timeoutId = setTimeout(() => {
      controller.abort(new DOMException('Timed out waiting for direct hashtree read', 'TimeoutError'));
      resolve(null);
    }, timeoutMs);
  });

  try {
    return await Promise.race([
      createPromise(controller.signal).catch(() => null),
      timeout,
    ]);
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

async function resolveDirectImmutablePath(rootCid: CID, path: string, signal: AbortSignal): Promise<CID | null> {
  const parts = path.split('/').filter(Boolean);
  if (parts.length === 0) return rootCid;

  const tree = getDirectImmutableTree();
  return (await tree.resolvePath(rootCid, parts, signal).catch(() => null))?.cid ?? null;
}

async function createDirectImmutableResponse(
  nhash: string | undefined,
  filePath: string,
  request: Request,
  timeoutMs = DIRECT_IMMUTABLE_FALLBACK_TIMEOUT_MS,
): Promise<Response | null> {
  if (!nhash) return null;

  const rootCid = nhashDecode(nhash);
  if (!rootCid) return null;

  const fileCid = await runWithTimeout(
    (signal) => resolveDirectImmutablePath(rootCid, filePath, signal),
    timeoutMs,
  );
  if (!fileCid) return null;

  const tree = getDirectImmutableTree();
  const data = await runWithTimeout(() => tree.readFile(fileCid).catch(() => null), timeoutMs);
  if (!data) return null;

  const headers = new Headers({
    'Content-Type': guessMimeType(filePath),
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'public, max-age=31536000, immutable',
  });

  const rangeHeader = request.headers.get('Range');
  if (rangeHeader && request.method !== 'HEAD') {
    const range = parseRange(rangeHeader);
    const start = range.start;
    const end = Math.min(range.end ?? data.length - 1, data.length - 1);
    if (start >= data.length || end < start) {
      headers.set('Content-Range', `bytes */${data.length}`);
      return new Response(null, { status: 416, headers });
    }

    const body = data.slice(start, end + 1);
    headers.set('Content-Length', String(body.length));
    headers.set('Content-Range', `bytes ${start}-${end}/${data.length}`);
    return new Response(bytesToResponseBody(body), { status: 206, headers });
  }

  headers.set('Content-Length', String(data.length));
  return new Response(request.method === 'HEAD' ? null : bytesToResponseBody(data), { status: 200, headers });
}

async function shouldUseDirectImmutableFallback(response: Response): Promise<boolean> {
  if (response.status < 400) return false;
  const body = await response.clone().text().catch(() => '');
  return body === 'File data not found' || body.startsWith('File not found');
}

function getPort(clientId?: string | null, clientKey?: string | null): MessagePort | null {
  if (clientKey && workerPortsByClientKey.has(clientKey)) {
    return workerPortsByClientKey.get(clientKey) || null;
  }
  if (clientId && workerPorts.has(clientId)) {
    return workerPorts.get(clientId) || null;
  }
  return defaultWorkerPort;
}

const PORT_REGISTRATION_WAIT_MS = 8000;
const PORT_REGISTRATION_INTERVAL_MS = 50;

async function waitForPort(
  clientId?: string | null,
  clientKey?: string | null,
  timeoutMs = PORT_REGISTRATION_WAIT_MS,
): Promise<MessagePort | null> {
  const deadline = Date.now() + timeoutMs;
  let port = getPort(clientId, clientKey);
  if (port) return port;
  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, PORT_REGISTRATION_INTERVAL_MS));
    port = getPort(clientId, clientKey);
    if (port) return port;
  }
  return null;
}

// After SW idle-kill, the in-memory port map is wiped. Ask the page to
// re-register via the same channel the iris-files SW uses (page-side handler
// in @hashtree/worker app-runtime listens for REQUEST_WORKER_PORT_RECONNECT).
async function requestWorkerPortReconnect(
  clientId?: string | null,
  clientKey?: string | null,
): Promise<void> {
  try {
    const message = { type: 'REQUEST_WORKER_PORT_RECONNECT', clientKey: clientKey ?? null };
    const postedClientIds = new Set<string>();
    if (clientId) {
      const client = await self.clients.get(clientId).catch(() => null);
      if (client) {
        client.postMessage(message);
        postedClientIds.add(client.id);
      }
    }
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clients) {
      if (postedClientIds.has(client.id)) continue;
      client.postMessage(message);
    }
  } catch (error) {
    console.warn('[SW] Failed to broadcast worker port reconnect:', error);
  }
}

function clearPending(requestId: string): PendingRequest | undefined {
  const pending = pendingRequests.get(requestId);
  if (!pending) return undefined;
  clearTimeout(pending.timer);
  pendingRequests.delete(requestId);
  return pending;
}

function decodePathSegments(parts: string[]): string {
  return parts
    .filter(Boolean)
    .map((part) => {
      try {
        return decodeURIComponent(part);
      } catch {
        return part;
      }
    })
    .join('/');
}

function getResultingClientId(event: FetchEvent): string | undefined {
  return (event as FetchEvent & { resultingClientId?: string }).resultingClientId;
}

function rememberRuntimeContext(
  event: FetchEvent,
  url: URL,
  target: RuntimeRequestContext['target'],
): RuntimeRequestContext {
  const clientKey = url.searchParams.get('htree_c');
  const context: RuntimeRequestContext = {
    clientKey,
    origin: url.origin,
    target,
  };
  const clientIds = [
    event.clientId,
    getResultingClientId(event),
  ].filter((clientId): clientId is string => Boolean(clientId));

  for (const clientId of clientIds) {
    runtimeContextsByClientId.set(clientId, context);
  }
  if (clientKey) {
    runtimeContextsByClientKey.set(clientKey, context);
  }
  runtimeContextsByOrigin.set(url.origin, context);

  return context;
}

function getRuntimeContext(event: FetchEvent, url: URL): RuntimeRequestContext | null {
  const clientKey = url.searchParams.get('htree_c');
  if (clientKey && runtimeContextsByClientKey.has(clientKey)) {
    return runtimeContextsByClientKey.get(clientKey) || null;
  }
  if (event.clientId && runtimeContextsByClientId.has(event.clientId)) {
    return runtimeContextsByClientId.get(event.clientId) || null;
  }
  const resultingClientId = getResultingClientId(event);
  if (resultingClientId && runtimeContextsByClientId.has(resultingClientId)) {
    return runtimeContextsByClientId.get(resultingClientId) || null;
  }
  return runtimeContextsByOrigin.get(url.origin) || null;
}

function rootRelativeRuntimePath(url: URL): string | null {
  if (url.pathname === '/' || url.pathname.startsWith('/htree/')) return null;
  const path = decodePathSegments(url.pathname.split('/'));
  return path || null;
}

function isPlainLocalDevShell(url: URL): boolean {
  return (
    url.hostname === 'localhost'
    || url.hostname === '127.0.0.1'
    || url.hostname === '::1'
    || url.hostname === '[::1]'
  );
}

function handleWorkerMessage(event: MessageEvent<WorkerMessage>): void {
  const message = event.data;
  const pending = pendingRequests.get(message.requestId);
  if (!pending) return;

  switch (message.type) {
    case 'headers': {
      const headers = new Headers(message.headers || {});
      headers.set('Access-Control-Allow-Origin', '*');
      headers.set('Cross-Origin-Resource-Policy', 'cross-origin');

      if (pending.head) {
        clearPending(message.requestId);
        pending.resolve(new Response(null, {
          status: message.status || 200,
          headers,
        }));
        return;
      }

      const { readable, writable } = new TransformStream<Uint8Array>();
      pending.writer = writable.getWriter();
      pending.resolve(new Response(readable, {
        status: message.status || 200,
        headers,
      }));
      return;
    }

    case 'chunk': {
      if (!pending.writer) return;
      pending.writer.write(new Uint8Array(message.data)).catch(() => {});
      return;
    }

    case 'done': {
      const finished = clearPending(message.requestId);
      finished?.writer?.close().catch(() => {});
      return;
    }

    case 'error': {
      const failed = clearPending(message.requestId);
      failed?.writer?.abort(message.message || 'Worker error').catch(() => {});
      failed?.reject(new Error(message.message || 'Worker error'));
      return;
    }
  }
}

self.addEventListener('message', (event) => {
  if (event.data?.type === 'PING_WORKER_PORT') {
    const source = event.source as Client | null;
    const requestId = event.data?.requestId as string | undefined;
    const clientId = source?.id ?? event.data?.clientId;
    const clientKey = event.data?.clientKey as string | undefined;
    const hasPort = !!(getPort(clientId, clientKey));
    if (requestId && source?.postMessage) {
      source.postMessage({ type: 'WORKER_PORT_PONG', requestId, ok: hasPort });
    }
    return;
  }

  if (event.data?.type === 'REGISTER_WORKER_PORT') {
    const port = (event.data?.port as MessagePort | undefined) ?? event.ports?.[0];
    if (!port) return;

    const source = event.source as Client | null;
    const clientId = source?.id ?? event.data?.clientId;
    const clientKey = event.data?.clientKey as string | undefined;

    if (clientId) {
      workerPorts.set(clientId, port);
    }
    // Isolated site origins only host one runtime at a time, so keep a default
    // port for iframe documents and subresource fetches whose client ids differ
    // from the top-level launcher page that performed registration.
    defaultWorkerPort = port;
    if (clientKey) {
      workerPortsByClientKey.set(clientKey, port);
    }

    port.onmessage = handleWorkerMessage;
    port.start?.();

    const requestId = event.data?.requestId as string | undefined;
    if (requestId && source?.postMessage) {
      source.postMessage({ type: 'WORKER_PORT_READY', requestId });
    }
  }
});

async function serveViaWorker(request: HtreeFileRequest, port: MessagePort): Promise<Response> {
  return await new Promise<Response>((resolve, reject) => {
    const timer = setTimeout(() => {
      clearPending(request.requestId);
      reject(new Error('Timed out waiting for worker response'));
    }, PORT_TIMEOUT_MS);

    pendingRequests.set(request.requestId, {
      resolve,
      reject,
      head: !!request.head,
      timer,
    });

    port.postMessage(request);
  });
}

async function serveViaWorkerWithDirectImmutableFallback(
  message: HtreeFileRequest,
  port: MessagePort,
  nhash: string | undefined,
  filePath: string,
  request: Request,
): Promise<Response> {
  const workerResponse = serveViaWorker(message, port);
  if (!nhash) {
    return workerResponse;
  }

  const directResponse = createDirectImmutableResponse(nhash, filePath, request)
    .then((response) => response ? { source: 'direct' as const, response } : null);

  const firstResponse = await Promise.race([
    workerResponse.then((response) => ({ source: 'worker' as const, response })),
    directResponse,
  ]);

  if (firstResponse?.source === 'direct') {
    return firstResponse.response;
  }

  if (firstResponse?.source === 'worker') {
    if (await shouldUseDirectImmutableFallback(firstResponse.response)) {
      const direct = await directResponse;
      if (direct) return direct.response;
    }
    return firstResponse.response;
  }

  const response = await workerResponse;
  if (await shouldUseDirectImmutableFallback(response)) {
    const direct = await directResponse;
    if (direct) return direct.response;
  }
  return response;
}

async function createNhashResponse(
  target: { nhash?: string; npub?: string; treeName?: string },
  filePath: string,
  request: Request,
  clientId?: string | null,
  clientKeyOverride?: string | null,
): Promise<Response> {
  const requestUrl = new URL(request.url);
  const clientKey = clientKeyOverride ?? requestUrl.searchParams.get('htree_c');
  let port = getPort(clientId, clientKey);

  if (!port && target.nhash) {
    const directResponse = await createDirectImmutableResponse(
      target.nhash,
      filePath,
      request,
      DIRECT_IMMUTABLE_PRE_PORT_TIMEOUT_MS,
    );
    if (directResponse) return directResponse;
  }

  if (!port) {
    await requestWorkerPortReconnect(clientId, clientKey);
    port = await waitForPort(clientId, clientKey);
  }
  if (!port) {
    const directResponse = await createDirectImmutableResponse(target.nhash, filePath, request);
    if (directResponse) return directResponse;
    return new Response('Worker port not available', { status: 503 });
  }

  const range = parseRange(request.headers.get('Range'));
  const message: HtreeFileRequest = {
    type: 'hashtree-file',
    requestId: `file_${++requestCounter}`,
    npub: target.npub,
    nhash: target.nhash ?? '',
    snapshot: requestUrl.searchParams.get('snapshot') === '1',
    linkKey: requestUrl.searchParams.get('k'),
    treeName: target.treeName,
    path: filePath,
    start: range.start,
    end: range.end,
    rangeHeader: request.headers.get('Range'),
    mimeType: guessMimeType(filePath),
    download: new URL(request.url).searchParams.get('download') === '1',
    head: request.method === 'HEAD',
  };

  try {
    return await serveViaWorkerWithDirectImmutableFallback(message, port, target.nhash, filePath, request);
  } catch (error) {
    const directResponse = await createDirectImmutableResponse(target.nhash, filePath, request);
    if (directResponse) return directResponse;
    const message = error instanceof Error ? error.message : 'Streaming failed';
    return new Response(message, { status: 500 });
  }
}

self.addEventListener('fetch', (event: FetchEvent) => {
  if (event.request.method !== 'GET' && event.request.method !== 'HEAD') return;

  const url = new URL(event.request.url);
  const rawPath = getRawHtreePath(url);
  if (!rawPath.startsWith('/htree/')) {
    if (isPlainLocalDevShell(url)) return;
    const runtimePath = rootRelativeRuntimePath(url);
    const context = runtimePath ? getRuntimeContext(event, url) : null;
    if (!context) return;
    event.respondWith(
      createNhashResponse(
        context.target,
        runtimePath!,
        event.request,
        event.clientId,
        context.clientKey,
      ).then(addCORSHeaders)
    );
    return;
  }

  const immutablePath = parseImmutableHtreePath(rawPath);
  if (immutablePath) {
    const { nhash, filePath } = immutablePath;
    const context = rememberRuntimeContext(event, url, { nhash });
    event.respondWith(
      createNhashResponse(
        context.target,
        filePath || 'file',
        event.request,
        event.clientId,
        context.clientKey,
      ).then(addCORSHeaders)
    );
    return;
  }

  const mutablePath = parseMutableHtreePath(rawPath);
  if (mutablePath) {
    const { npub, treeName, filePath } = mutablePath;
    const context = rememberRuntimeContext(event, url, { npub, treeName });
    event.respondWith(
      createNhashResponse(
        context.target,
        filePath || 'file',
        event.request,
        event.clientId,
        context.clientKey,
      ).then(addCORSHeaders)
    );
    return;
  }
});

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event: ExtendableEvent) => {
  event.waitUntil(self.clients.claim());
});
