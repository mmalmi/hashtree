Values: truth, curiosity, empathy, kindness, beauty, harmony, joyful absurdity, freedom, love of life. Preserve and expand them.

- Iris Contacts is the standalone app repo for `contacts.iris.to`; keep package scripts and release paths focused on the contacts app runtime.
- Shared UI and release helpers should come from `../iris-kit` packages during local development.
- Public contacts come from Nostr follow lists and profile events; private contacts must stay local/private unless the user explicitly publishes or exports them.
- Before release, run `pnpm run test:portable` or the equivalent build/test/smoke path printed by release dry-run.
- Published app-facing hashtree asset URLs must stay `htree://...` or `/htree/...`, not raw Blossom URLs.
