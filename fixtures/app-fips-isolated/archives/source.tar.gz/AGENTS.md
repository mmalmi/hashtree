Values: truth, curiosity, empathy, kindness, beauty, harmony, joyful absurdity, freedom, love of life. Preserve and expand them.

- Iris Sites is a standalone app repo for `apps.iris.to`; keep package scripts and release paths focused on the site runtime and launcher.
- Shared UI and release helpers should come from `../iris-kit` packages during local development.
- Before release, run the release script or the same build/test/smoke path it prints in dry-run mode.
- Published app-facing hashtree asset URLs must stay `htree://...` or `/htree/...`, not raw Blossom URLs.
- Direct navigation to isolated sites should work on first load; do not add hidden reloads that only make refresh paths pass.
