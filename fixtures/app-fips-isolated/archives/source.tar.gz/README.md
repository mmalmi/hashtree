# Iris Sites

Isolated runtime and launcher for Iris web apps on `apps.iris.to`.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-sites>
Live: <https://apps.iris.to/>

Legacy `sites.iris.to` URLs are kept as redirecting aliases for compatibility.

Iris Sites is the small shell that lets published hashtree apps open by readable
URLs, profile paths, or `#/npub/tree/index.html` launcher links. The app keeps the
runtime isolated from the launcher UI, preserves direct navigation to individual
sites, and points the launcher at the current Iris app catalog.

## Development

```bash
pnpm install
pnpm run dev
```

Normal installs use checksum-pinned assets from immutable Hashtree, Iris Kit,
and social-graph releases. A sibling checkout is not required. When developing a
shared package and this app together, use a temporary local pnpm override rather
than committing workspace links to the product lockfile.

## Verification

```bash
pnpm test
pnpm run build
pnpm run test:portable
```

`test:portable` is the release gate. It builds the site, runs the focused Vitest
coverage, runs `svelte-check`, and performs the portable build smoke test.

## Release

```bash
pnpm run release:site
```

The release script builds the runtime, runs the focused portable checks, publishes the built directory root to hashtree, and deploys the same artifact to the `iris-sites` Cloudflare Worker target.

## Launcher Apps

Suggested apps are defined in `src/lib/launcherContent.ts`. The site tree is the
mutable hashtree name used by `apps.iris.to`; the source repo is the app code
when it is published on `git.iris.to`.

| App | Live URL | Site tree | Source repo |
| --- | --- | --- | --- |
| Drive | <https://drive.iris.to/> | `drive` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-drive-web> |
| Chat | <https://chat.iris.to/> | `iris-chat-site` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-chat> |
| Market | <https://market.iris.to/> | `market` | <https://github.com/irislib/iris-market> |
| Contacts | <https://contacts.iris.to/> | `contacts` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-contacts> |
| Wallet | <https://wallet.cashu.me/> | `cashu-me` | <https://github.com/cashubtc/cashu.me> |
| Calendar | <https://calendar.iris.to/> | `calendar` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-calendar> |
| Docs | <https://docs.iris.to/> | `docs` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-docs> |
| Meet | <https://meet.iris.to/> | `meet` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/meet> |
| Maps | <https://maps.iris.to/> | `maps` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-maps> |
| Social | <https://social.iris.to/> | `iris-client-site` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-client> |
| Audio | <https://audio.iris.to/> | `audio` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-audio> |
| Boards | <https://boards.iris.to/> | `boards` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-boards> |
| Nostr VPN | <https://apps.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/nostrvpn-org-site/index.html> | `nostrvpn-org-site` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/nostrvpn-org> |
| Git | <https://git.iris.to/> | `git` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-git> |
| Quick Share | <https://hashtree.cc/> | `hashtree-cc-site` | <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/hashtree-cc> |
