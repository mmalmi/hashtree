# Iris Contacts

Google-Contacts-like address book for Iris, backed by public Nostr follow lists and local private contacts.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-contacts>
Live: <https://contacts.iris.to/>

## What is here

- Standalone Svelte + Vite app in its own repo
- Public contact import from Nostr kind `3` follow lists
- Profile hydration from Nostr kind `0` metadata events
- `nostr-social-graph` ranking for follow distance and friend-follow counts
- Global people discovery from Iris Social's census-backed Hashtree search index
- Local private contacts with groups, notes, and JSON import/export
- Hashtree/Cloudflare release scripts matching the other Iris standalone apps

Private contacts intentionally stay local in this first version. The data model is a stable JSON shape so it can later move behind encrypted Nostr user lists or a private hashtree index without changing the main UI.

## Development

```bash
pnpm install
pnpm run dev
```

Normal installs use checksum-pinned Iris Kit and social-graph release archives;
they do not require sibling source checkouts.

## Verification

```bash
pnpm test
pnpm run test:portable
```

## Release

```bash
pnpm run release:site
```

The release script builds the app, runs the focused portable checks, publishes `dist/` to the `contacts` hashtree tree, and deploys the same artifact to the `iris-contacts` Cloudflare Worker custom domain for `contacts.iris.to`.
