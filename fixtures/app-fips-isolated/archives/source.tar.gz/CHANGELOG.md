# Changelog

## 0.2.10 - 2026-10-04

- Restore direct peer connections after reload and keep cached public profiles and files available from other peers.
- Update the shared file worker while preserving secret-key sessions, private contacts and offline data.

## 0.2.9 - 2026-10-01

- Keep peer connections and transfers working when a delayed connection offer arrives.

## 0.2.8 - 2026-10-01

- Update shared peer networking to recover cleanly from rejected handshakes, malformed packets, route failures, and transport restarts.
- Use corrected routing filters, bounded route retries, and native-compatible link feedback to reduce unnecessary background traffic.

## 0.2.7 - 2026-09-30

- Recover peer sessions after packet loss and retry connection replies when routes recover.

## 0.2.6 - 2026-09-30

- Route larger peer connection offers over paths that can carry them.
- Resume peer connections promptly after authenticated signaling recovers.

## 0.2.4 - 2026-09-30

- Wait for received events to finish saving before marking their history complete.
- Pin nostr-pubsub 0.5.12, Hashtree runtime 0.5.10, and Iris Kit runtime 0.2.6.

## 0.2.3 - 2026-09-30

- Share public profiles and cached people-index files through one persistent peer runtime.
- Preserve secret keys, private contacts and notes, and enable the packaged public graph offline.
- Pin nostr-pubsub 0.5.11 and Hashtree runtime 0.5.9 with verified archive checksums.

## 0.2.2 - 2026-09-07

- Update Hashtree to security runtime 0.5.7, verifying remote blob integrity before reading or caching content.

## 0.2.1 - 2026-07-19

- Preserve an expanded profile bio while unrelated social-graph data refreshes in the background.

## 0.2.0 - 2026-07-19

- Make signed-out state explicit and present the Iris graph as an anonymous discovery lens instead of an account.
- Search the census-backed public Hashtree people index while preserving local contacts and packaged graph results.
- Rank public people by text relevance, then social distance, and cache read-only index data locally.

## 0.1.1 - 2026-07-16

- Install Iris identity, shared UI, release tools, and social graph from immutable checksum-pinned releases.
- Reject mutable sibling dependencies before builds and tests.
