# Changelog

## 0.1.15 - 2026-10-01

- Keep peer connections and transfers working when a delayed connection offer arrives.

## 0.1.14 - 2026-10-01

- Update shared peer networking to recover cleanly from rejected handshakes, malformed packets, route failures, and transport restarts.
- Use corrected routing filters, bounded route retries, and native-compatible link feedback to reduce unnecessary background traffic.

## 0.1.13 - 2026-09-30

- Recover peer sessions after packet loss and retry connection replies when routes recover.

## 0.1.12 - 2026-09-30

- Route larger peer connection offers over paths that can carry them.
- Resume peer connections promptly after authenticated signaling recovers.

## 0.1.10 - 2026-09-30

- Wait for received events to finish saving before marking their history complete.
- Pin nostr-pubsub 0.5.12, Hashtree runtime 0.5.10, and Iris Kit runtime 0.2.6.

## 0.1.9 - 2026-09-30

- Share cached site files and public event history through one peer connection runtime.
- Keep uploaded content available to other peers after its original publisher leaves.
- Pin nostr-pubsub 0.5.11 and Hashtree runtime 0.5.9 with verified archive checksums.

## 0.1.8 - 2026-09-07

- Require the verified Hashtree 0.2.142 release publisher.
- Update Hashtree to security runtime 0.5.7, verifying remote blob integrity before reading or caching content.

## 0.1.7 - 2026-07-17

- Upgrade the Hashtree cleanup packages to immutable runtime 0.5.1,
  including Nostr adapter 0.2.0 and worker 0.4.1.
- Remove the legacy mesh carrier from the site runtime while preserving the
  shared adaptive `BlobRouter`, exact provider identity, HTL 10, and
  Blossom-only behavior when no provider bridge is configured.
- Pin publication to the immutable Hashtree CLI 0.2.99 artifact.

## 0.1.6 - 2026-07-16

- Upgrade to the immutable Hashtree TypeScript 0.5.0 runtime. Site reads now
  share the bounded adaptive `BlobRouter`; local writes stay explicit and
  route-free sites remain local and Blossom-only.
- Preserve frozen HTL 10 and provider identity rules without adding a
  launcher-level peer fallback.

## 0.1.5 - 2026-07-16

- Pin the immutable Hashtree worker 0.3.3 release so provider-backed reads use exact route identities while route-free sites remain local and Blossom-only.

## 0.1.4 - 2026-07-16

- Upgrade the shared Hashtree worker to 0.3.2, including durable peer-share authorization and corrected provider replacement.
- Publish sites with the installed, registry-verified Hashtree CLI instead of mutable sibling Rust source.
