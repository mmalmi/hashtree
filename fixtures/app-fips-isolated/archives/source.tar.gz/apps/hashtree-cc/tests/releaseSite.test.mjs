import test from 'node:test';
import assert from 'node:assert/strict';

import { createReleasePlan, parseArgs, parsePublishOutput, runRelease } from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';

test('uses the built-in Worker default for hashtree.cc', () => {
  const parsed = parseArgs([]);

  assert.equal(parsed.workerName, 'hashtree-cc');
  assert.equal(parsed.treeName, 'hashtree-cc-site');
  assert.deepEqual(parsed.routes, ['hashtree.cc/*']);
  assert.deepEqual(parsed.domains, []);
});

test('supports switching hashtree.cc releases back to Pages explicitly', () => {
  const parsed = parseArgs(['--pages-only'], { CF_PAGES_PROJECT_HASHTREE_CC: 'hashtree-cc' });

  assert.equal(parsed.workerName, undefined);
  assert.equal(parsed.pagesProject, 'hashtree-cc');
  assert.deepEqual(parsed.routes, []);
  assert.deepEqual(parsed.domains, []);
});

test('builds a Worker release plan in build-test-publish-deploy order', () => {
  const plan = createReleasePlan({
    workerName: 'hashtree-cc',
    treeName: 'hashtree-cc-site',
    routes: ['hashtree.cc/*'],
    domains: [],
    skipCloudflare: false,
    workerCompatibilityDate: '2026-03-19',
  });

  assert.deepEqual(
    plan.steps.map((step) => step.id),
    ['build', 'test-1', 'test-2', 'test-3', 'publish', 'deploy'],
  );
  assert.deepEqual(plan.steps.find((step) => step.id === 'test-1')?.command, [
    'node',
    './scripts/verify-htree-cli.mjs',
  ]);
  assert.deepEqual(plan.steps.at(-1)?.command, [
    'node',
    './scripts/deploy-worker-assets.mjs',
    '--script',
    'scripts/https-static-assets-worker.mjs',
    '--assets',
    'dist',
    '--name',
    'hashtree-cc',
    '--compatibility-date',
    '2026-03-19',
    '--wrangler-version',
    '4',
    '--route',
    'hashtree.cc/*',
  ]);
});

test('adds explicit routes and domains to the Worker deploy command', () => {
  const plan = createReleasePlan({
    workerName: 'hashtree-cc',
    treeName: 'hashtree-cc-site',
    routes: ['hashtree.cc/*'],
    domains: ['hashtree.cc'],
    skipCloudflare: false,
    workerCompatibilityDate: '2026-03-19',
  });

  assert.deepEqual(plan.steps.at(-1)?.command, [
    'node',
    './scripts/deploy-worker-assets.mjs',
    '--script',
    'scripts/https-static-assets-worker.mjs',
    '--assets',
    'dist',
    '--name',
    'hashtree-cc',
    '--compatibility-date',
    '2026-03-19',
    '--wrangler-version',
    '4',
    '--route',
    'hashtree.cc/*',
    '--domain',
    'hashtree.cc',
  ]);
});

test('generates a Worker Static Assets config that runs the redirect Worker first', () => {
  const options = parseWorkerAssetsArgs([
    '--script',
    'scripts/https-static-assets-worker.mjs',
    '--assets',
    'dist',
    '--name',
    'hashtree-cc',
    '--compatibility-date',
    '2026-03-19',
  ]);

  assert.deepEqual(workerAssetsConfigFor(options), {
    name: 'hashtree-cc',
    compatibility_date: '2026-03-19',
    main: 'scripts/https-static-assets-worker.mjs',
    assets: {
      directory: 'dist',
      binding: 'ASSETS',
      run_worker_first: true,
    },
  });
});

test('runs hashtree publish and Worker deploy in parallel after tests', async () => {
  let activeReleaseSteps = 0;
  let maxActiveReleaseSteps = 0;
  const calls = [];

  await runRelease(
    {
      workerName: 'hashtree-cc',
      treeName: 'hashtree-cc-site',
      routes: [],
      domains: [],
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    },
    async (step) => {
      calls.push(step.id);
      if (step.id === 'publish' || step.id === 'deploy') {
        activeReleaseSteps += 1;
        maxActiveReleaseSteps = Math.max(maxActiveReleaseSteps, activeReleaseSteps);
        await new Promise((resolve) => setTimeout(resolve, 10));
        activeReleaseSteps -= 1;
        if (step.id === 'publish') {
          return {
            status: 0,
            stdout: 'published: npub1example/hashtree-cc-site\nnhash1ace',
            stderr: '',
          };
        }
      }
      return { status: 0, stdout: '', stderr: '' };
    },
    { buildOutputExists: () => true },
  );

  assert.deepEqual(calls, ['build', 'test-1', 'test-2', 'test-3', 'publish', 'deploy']);
  assert.equal(maxActiveReleaseSteps, 2);
});

test('returns parsed hashtree publish data and Worker target on success', async () => {
  const result = await runRelease(
    {
      workerName: 'hashtree-cc',
      treeName: 'hashtree-cc-site',
      routes: [],
      domains: [],
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    },
    (step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/hashtree-cc-site\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    },
    { buildOutputExists: () => true },
  );

  assert.deepEqual(result.publish, {
    nhash: 'nhash1ace',
    publishedRef: 'npub1example/hashtree-cc-site',
  });
  assert.equal(result.workerName, 'hashtree-cc');
  assert.equal(result.pagesProject, null);
});

test('parses htree publish output defensively', () => {
  assert.deepEqual(parsePublishOutput('published: npub1foo/hashtree-cc-site\nnhash1ace'), {
    nhash: 'nhash1ace',
    publishedRef: 'npub1foo/hashtree-cc-site',
  });
  assert.throws(
    () => parsePublishOutput('published: npub1foo/hashtree-cc-site'),
    /Publish succeeded but no nhash was found in htree output/,
  );
});
