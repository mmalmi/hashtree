import { test, expect } from './fixtures';
import { createHash, randomUUID } from 'crypto';

const SETTINGS_KEY = 'hashtree-cc-settings-v1';
const relayPort = process.env.TEST_RELAY_PORT ?? '14736';

test('settings page persists storage/server settings and allows relay updates', async ({ page }) => {
  await page.goto('/');

  await expect(page.getByTestId('connectivity-indicator')).toBeVisible();
  await page.goto('/#/settings');
  await expect(page).toHaveURL(/#\/settings$/);
  await expect(page.getByTestId('settings-page')).toBeVisible();
  await expect(page.getByTestId('settings-blossom-link')).toHaveAttribute('href', 'https://github.com/hzrd149/blossom');
  await expect(page.getByTestId('settings-app-info')).toBeVisible();
  await expect(page.getByTestId('settings-app-version')).toHaveText(/\S+/);
  await expect(page.getByTestId('settings-build-time')).toHaveText(/\S+/);
  await expect(page.getByTestId('settings-refresh-app')).toBeVisible();
  await expect(page.getByTestId('settings-blossom-upload-total')).toContainText('0 B');
  await expect(page.getByTestId('settings-blossom-download-total')).toContainText('0 B');
  await expect(page.getByRole('link', { name: 'Share Privately' })).toHaveCount(0);
  await expect(page.getByRole('link', { name: 'For Developers' })).toHaveCount(0);

  const storageLimit = page.getByTestId('settings-storage-limit-mb');
  await storageLimit.fill('2048');
  await storageLimit.blur();
  await expect(storageLimit).toHaveValue('2048');

  const serverUrl = 'https://files.example.test';
  await page.getByTestId('settings-new-server').fill(serverUrl);
  await page.getByTestId('settings-add-server').click();
  await expect.poll(async () => page.evaluate(({ key, url }) => {
    const raw = window.localStorage.getItem(key);
    if (!raw) return false;
    const parsed = JSON.parse(raw) as { network?: { blossomServers?: Array<{ url?: string }> } };
    return parsed.network?.blossomServers?.some((server) => server.url === url) ?? false;
  }, { key: SETTINGS_KEY, url: serverUrl })).toBe(true);
  await expect(page.getByTestId('settings-server-item').filter({ hasText: 'files.example.test' })).toBeVisible({ timeout: 10000 });

  await page.getByTestId('settings-new-relay').fill('wss://relay.example.test');
  await page.getByTestId('settings-add-relay').click();
  await expect.poll(async () => page.evaluate((key) => {
    const raw = window.localStorage.getItem(key);
    if (!raw) return false;
    const parsed = JSON.parse(raw) as { network?: { relays?: string[] } };
    return parsed.network?.relays?.includes('wss://relay.example.test') ?? false;
  }, SETTINGS_KEY)).toBe(true);
  await expect(page.getByTestId('settings-relay-item').filter({ hasText: 'relay.example.test' })).toBeVisible({ timeout: 10000 });

  await page.goto('/#/settings');
  await expect(storageLimit).toHaveValue('2048');
  await expect(page.getByTestId('settings-server-item').filter({ hasText: 'files.example.test' })).toBeVisible();
  await expect(page.getByTestId('settings-relay-item').filter({ hasText: 'relay.example.test' })).toBeVisible();
});

test('bandwidth indicator can be enabled without triggering a render loop', async ({ page }) => {
  await page.goto('/#/settings');

  const toggle = page.getByTestId('settings-show-bandwidth-toggle');
  await expect(toggle).not.toBeChecked();
  await toggle.check();

  await expect(toggle).toBeChecked();
  await expect(page.getByTestId('bandwidth-indicator')).toBeVisible();

  await page.goto('/');
  await expect(page.getByTestId('bandwidth-indicator')).toBeVisible();
});

test('uploaded file stays viewable after reload without blossom GET fallback', async ({ page }) => {
  const fileContent = 'worker cache persistence';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');
  let getRequests = 0;

  await page.route('https://*/upload', async (route) => {
    if (route.request().method() === 'PUT') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ sha256: expectedHash, size: fileContent.length }),
      });
      return;
    }
    await route.continue();
  });

  await page.route(`https://*/${expectedHash}**`, async (route) => {
    if (route.request().method() === 'HEAD') {
      await route.fulfill({ status: 404 });
      return;
    }
    if (route.request().method() === 'GET') {
      getRequests += 1;
      await route.fulfill({
        status: 500,
        contentType: 'text/plain',
        body: 'offline',
      });
      return;
    }
    await route.continue();
  });

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'persist.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-text')).toContainText(fileContent);

  const viewerUrl = page.url();
  await page.reload();
  await expect(page).toHaveURL(viewerUrl);

  await expect(page.getByTestId('viewer-text')).toContainText(fileContent, { timeout: 10000 });
  expect(getRequests).toBe(0);
});

test('p2p module is initialized in hashtree-cc', async ({ page }) => {
  const relayUrl = `ws://localhost:${relayPort}/settings-p2p-${randomUUID()}`;
  await page.addInitScript(({ key, relay }) => {
    window.localStorage.setItem(key, JSON.stringify({ network: { relays: [relay] } }));
  }, { key: SETTINGS_KEY, relay: relayUrl });
  await page.goto('/');

  await expect.poll(async () => page.evaluate(() => {
    const state = (window as unknown as { __hashtreeCcP2P?: { started: boolean } }).__hashtreeCcP2P;
    return state?.started ?? false;
  }), { timeout: 30_000 }).toBe(true);

  const p2pState = await page.evaluate(() => {
    const state = (window as unknown as {
      __hashtreeCcP2P?: {
        started: boolean;
        peerCount: number;
        blossomBandwidth?: { totalBytesSent: number; totalBytesReceived: number };
      };
    }).__hashtreeCcP2P;
    return {
      started: state?.started ?? false,
      peerCount: state?.peerCount ?? -1,
      blossomBytesSent: state?.blossomBandwidth?.totalBytesSent ?? -1,
      blossomBytesReceived: state?.blossomBandwidth?.totalBytesReceived ?? -1,
    };
  });

  expect(p2pState.started).toBe(true);
  expect(p2pState.peerCount).toBeGreaterThanOrEqual(0);
  expect(p2pState.blossomBytesSent).toBeGreaterThanOrEqual(0);
  expect(p2pState.blossomBytesReceived).toBeGreaterThanOrEqual(0);
});

test('iris runtime uses the embedded daemon relay and blossom fallback alongside upstream servers', async ({ page }) => {
  await page.addInitScript(() => {
    (window as Window & { __HTREE_SERVER_URL__?: string }).__HTREE_SERVER_URL__ = 'http://127.0.0.1:21417';
  });

  await page.goto('/#/settings');

  await expect(page.getByTestId('settings-local-daemon-relay-item')).toContainText('127.0.0.1');
  await expect(page.getByTestId('settings-local-daemon-server-item')).toContainText('127.0.0.1:21417');
  await expect(page.getByTestId('settings-relay-item').filter({ hasText: 'relay.primal.net' })).toBeVisible();
  await expect(page.getByTestId('settings-server-item').filter({ hasText: 'upload.iris.to' })).toBeVisible();

  await expect.poll(async () => page.evaluate(() => {
    const state = (window as unknown as {
      __hashtreeCcP2P?: {
        relays?: Array<{ url: string }>;
      };
    }).__hashtreeCcP2P;
    return state?.relays?.map((relay) => relay.url) ?? [];
  })).toEqual(expect.arrayContaining([
    'ws://127.0.0.1:21417/ws',
    'wss://relay.primal.net',
  ]));
});
