import { test, expect } from './fixtures';
import { createHash } from 'crypto';
import { readFile } from 'node:fs/promises';
import { encryptionMode, nhashDecode } from '@hashtree/core';

const SAVE_WITH_ENTER = process.platform === 'darwin' ? 'Meta+Enter' : 'Control+Enter';

test('page loads with Share Privately tab active', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('drop-zone')).toBeVisible();
  await expect(page.getByText('Drop files or browse')).toBeVisible();
});

test('can switch tabs', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('drop-zone')).toBeVisible();

  await page.getByText('For Developers').click();
  await expect(page.getByText('Git without GitHub')).toBeVisible();
  await expect(page.getByTestId('drop-zone')).not.toBeVisible();

  await page.getByText('Share Privately').click();
  await expect(page.getByTestId('drop-zone')).toBeVisible();
});

test('developers tab shows git demo video player', async ({ page }) => {
  await page.goto('/');
  await page.getByText('For Developers').click();

  const video = page.getByTestId('git-demo-video');
  await expect(video).toBeVisible();
  await expect(video).toHaveAttribute('src', /\/htree\/nhash1qqsqmafutt4u7g4x7cyx0w0k84gs7txg54v7sygkm3aspld3h7ehhyg9ypzx8wcsnd63spv9d3scr4zst2s48mv0yl36lj2c02a6vlms607nkqysxg5\/htree\.mp4\?htree_c=.*htree_t=video%2Fmp4/);
  await expect(video).toHaveAttribute('controls', '');
  await expect(video).not.toHaveAttribute('autoplay', '');
  await expect.poll(async () => (await video.boundingBox())?.height ?? 0).toBeGreaterThan(150);
  await expect(page.getByTestId('git-demo-video-caption')).toHaveText('The above video is delivered and streamed via Hashtree: a decentralized CDN.');
});

test('developers tab highlights decentralized CDN resilience and economics', async ({ page }) => {
  await page.goto('/');
  await page.getByText('For Developers').click();

  await expect(page.getByRole('heading', { name: 'Decentralized CDN', exact: true })).toBeVisible();
  const cdnSectionLink = page.getByRole('link', { name: /Decentralized CDN Resilience/ });
  await expect(cdnSectionLink).toBeVisible();
  await expect(cdnSectionLink).toHaveAttribute('href', '/#/dev/decentralized-cdn');

  const section = page.getByTestId('decentralized-cdn-section');
  await expect(section).toBeVisible();
  await expect(section).toContainText('Independent from centralized CDN outages');
  await expect(section).toContainText('Costs do not increase linearly with popularity');
  await expect(section).toContainText('Popular content becomes more available with each seeder');
  await expect(section).toContainText('video.iris.to');
});

test('developers tab links FIPS and Iris Apps', async ({ page }) => {
  await page.goto('/');
  await page.getByText('For Developers').click();

  await expect(page.getByRole('link', { name: 'FIPS', exact: true }).first()).toHaveAttribute(
    'href',
    'https://github.com/jmcorgan/fips',
  );

  const callout = page.getByTestId('iris-apps-callout');
  await expect(callout).toBeVisible();
  await expect(callout).toContainText('Use and share apps and files without relying on web servers, domain names, or even internet access.');
  await expect(callout.getByRole('link', { name: 'apps.iris.to' })).toHaveAttribute('href', 'https://apps.iris.to/');
});

function mockBlossom(page: import('@playwright/test').Page, expectedHash: string, content: string | Buffer) {
  return Promise.all([
    page.route('https://*/upload', async (route) => {
      if (route.request().method() === 'PUT') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ sha256: expectedHash, size: content.length }),
        });
      } else {
        await route.continue();
      }
    }),
    page.route(`https://*/${expectedHash}**`, async (route) => {
      if (route.request().method() === 'HEAD') {
        await route.fulfill({ status: 404 });
      } else if (route.request().method() === 'GET') {
        await route.fulfill({
          status: 200,
          contentType: 'application/octet-stream',
          body: Buffer.from(content),
        });
      } else {
        await route.continue();
      }
    }),
  ]);
}

test('file upload navigates to viewer with nhash URL', async ({ page }) => {
  const fileContent = 'hello hashtree test file';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: 'test.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  // Should navigate directly to viewer after upload
  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });

  // URL has nhash and filename
  const nhash = new URL(page.url()).hash.split('/')[1];
  expect(encryptionMode(nhashDecode(nhash).key!)).toBe('chk-v1');
  expect(page.url()).toContain('/test.txt');

  // Text content is shown
  await expect(page.getByTestId('viewer-text')).toBeVisible();
  await expect(page.getByTestId('viewer-text')).toContainText('hello hashtree test file');
});

test('service worker preserves suffix byte ranges for immutable /htree files', async ({ page }) => {
  const fileName = 'range.bin';
  const fileContent = Buffer.from(Uint8Array.from({ length: 32 }, (_, index) => index));
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: fileName,
    mimeType: 'application/octet-stream',
    buffer: fileContent,
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-download')).toBeVisible();

  const nhash = await page.evaluate(() => {
    const match = window.location.hash.match(/^#\/([^/]+)\//);
    return match?.[1] ?? null;
  });
  expect(nhash).toBeTruthy();

  const response = await page.evaluate(async ({ nhash, fileName }) => {
    const encodedFileName = encodeURIComponent(fileName);
    const result = await fetch(`/htree/${nhash}/${encodedFileName}`, {
      headers: {
        Range: 'bytes=-5',
      },
    });
    return {
      status: result.status,
      acceptRanges: result.headers.get('accept-ranges'),
      contentLength: result.headers.get('content-length'),
      contentRange: result.headers.get('content-range'),
      bytes: Array.from(new Uint8Array(await result.arrayBuffer())),
    };
  }, { nhash, fileName });

  expect(response.status).toBe(206);
  expect(response.acceptRanges).toBe('bytes');
  expect(response.contentLength).toBe('5');
  expect(response.contentRange).toBe('bytes 27-31/32');
  expect(response.bytes).toEqual(Array.from(fileContent.subarray(fileContent.length - 5)));
});

test('file upload uses streaming path without File.arrayBuffer', async ({ page }) => {
  const fileContent = 'streaming upload path';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);
  await page.addInitScript(() => {
    File.prototype.arrayBuffer = function() {
      throw new Error('arrayBuffer should not be used for file upload');
    };
  });

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'streamed.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-text')).toContainText(fileContent);
});

test('uploads encrypted bytes to blossom (no plaintext body)', async ({ page }) => {
  const plaintext = `NO_PLAINTEXT_UPLOAD_${Date.now()}_${'x'.repeat(2048)}`;
  const plaintextBuffer = Buffer.from(plaintext, 'utf8');
  const plaintextHash = createHash('sha256').update(plaintextBuffer).digest('hex');
  const sentinel = Buffer.from(`NO_PLAINTEXT_UPLOAD_${Date.now()}`, 'utf8');
  const uploads: Array<{ body: Buffer; shaHeader: string; contentType: string | null }> = [];

  await page.route('https://*/upload', async (route) => {
    if (route.request().method() !== 'PUT') {
      await route.continue();
      return;
    }

    const body = route.request().postDataBuffer() ?? Buffer.alloc(0);
    const shaHeader = (await route.request().headerValue('x-sha-256')) ?? '';
    const contentType = await route.request().headerValue('content-type');

    uploads.push({ body, shaHeader, contentType });

    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ sha256: shaHeader, size: body.length }),
    });
  });

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'encrypted-check.txt',
    mimeType: 'text/plain',
    buffer: plaintextBuffer,
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect.poll(() => uploads.length).toBeGreaterThan(0);

  for (const upload of uploads) {
    const uploadedHash = createHash('sha256').update(upload.body).digest('hex');
    expect(upload.contentType ?? '').toContain('application/octet-stream');
    expect(upload.shaHeader).toBe(uploadedHash);
    expect(upload.shaHeader).not.toBe(plaintextHash);
    expect(upload.body.equals(plaintextBuffer)).toBe(false);
    expect(upload.body.includes(sentinel)).toBe(false);
  }
});

test('shows progress while saving locally when blossom uploads are disabled (1GB scenario)', async ({ page }) => {
  await page.addInitScript(() => {
    window.localStorage.setItem('hashtree-cc-settings-v1', JSON.stringify({
      network: {
        relays: ['wss://relay.primal.net'],
        blossomServers: [
          { url: 'https://cdn.iris.to', read: true, write: false },
          { url: 'https://upload.iris.to', read: false, write: false },
          { url: 'https://blossom.primal.net', read: true, write: false },
        ],
      },
      storage: {
        maxBytes: 2147483648,
      },
      ui: {
        showBandwidthIndicator: false,
      },
    }));
  });

  let blossomPutRequests = 0;
  await page.route('https://*/upload', async (route) => {
    if (route.request().method() === 'PUT') {
      blossomPutRequests += 1;
      await route.abort();
      return;
    }
    await route.continue();
  });

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'local-only-large.bin',
    mimeType: 'application/octet-stream',
    buffer: Buffer.alloc(8 * 1024 * 1024, 1),
  });

  await expect(page.getByTestId('upload-progress-toast')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('upload-progress-toast')).toContainText('local-only-large.bin');
  await expect(page.getByTestId('upload-progress-toast')).toContainText(/reading|writing|finalizing/i);

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  expect(blossomPutRequests).toBe(0);
});

test('fails closed when secure local streaming is unavailable', async ({ browser }) => {
  const context = await browser.newContext({ serviceWorkers: 'block' });
  const page = await context.newPage();
  const fileContent = 'streaming should fail closed';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');
  let htreeRequests = 0;

  try {
    await page.route('**/htree/**', async (route) => {
      htreeRequests += 1;
      await route.continue();
    });
    await mockBlossom(page, expectedHash, fileContent);

    await page.goto('/');
    await page.getByTestId('file-input').setInputFiles({
      name: 'no-sw.txt',
      mimeType: 'text/plain',
      buffer: Buffer.from(fileContent),
    });

    await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
    expect(htreeRequests).toBe(0);
  } finally {
    await context.close();
  }
});

test('viewer share modal can copy link', async ({ page, context }) => {
  const fileContent = 'copy test file';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  await mockBlossom(page, expectedHash, fileContent);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: 'copy-test.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });

  await page.getByRole('button', { name: 'Share' }).click();
  await expect(page.getByTestId('share-modal')).toBeVisible();
  await page.getByTestId('share-copy-url').click();
  const clipboardText = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboardText).toContain('nhash1');
  expect(clipboardText).toContain('/copy-test.txt');
  expect(new URL(clipboardText).searchParams.get('provider')).toMatch(/^(02|03)[0-9a-f]{64}$/);
});

test('nhash URL shows image viewer', async ({ page }) => {
  const imageBytes = await readFile(new URL('../public/screenshot-hashtree-cc.webp', import.meta.url));
  await page.addInitScript(() => localStorage.setItem('hashtree-cc-settings-v1', JSON.stringify({
    network: { relays: [], blossomServers: [] },
  })));

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'photo.webp',
    mimeType: 'image/webp',
    buffer: imageBytes,
  });

  const image = page.getByTestId('viewer-image');
  await expect(image).toHaveAttribute('src', /^\/htree\//);
  await expect.poll(() => image.evaluate((element: HTMLImageElement) =>
    element.complete && element.naturalWidth > 0 && element.naturalHeight > 0
  )).toBe(true);
  await expect(image).toBeVisible();
});

test('nhash URL shows download for unknown type', async ({ page }) => {
  const fileContent = Buffer.from('binary-stuff');
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'data.bin',
    mimeType: 'application/octet-stream',
    buffer: fileContent,
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-download')).toBeVisible();
});

test('download button requests /htree with download=1 and starts browser download', async ({ page }) => {
  const fileContent = Buffer.from('download-me-please');
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);

  await page.goto('/');
  await page.getByTestId('file-input').setInputFiles({
    name: 'download.bin',
    mimeType: 'application/octet-stream',
    buffer: fileContent,
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });

  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('download-button').click(),
  ]);

  expect(await download.failure()).toBeNull();
  expect(download.suggestedFilename()).toContain('download');
});

test('browser back returns to upload page', async ({ page }) => {
  const fileContent = 'nav test';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: 'nav.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });

  await page.goBack();
  await expect(page.getByTestId('drop-zone')).toBeVisible();
});

// --- Pastebin / Text Editor tests ---

function mockBlossomMulti(page: import('@playwright/test').Page) {
  // Mock that accepts any hash - useful when we don't know the hash ahead of time (e.g. after editing)
  return Promise.all([
    page.route('https://*/upload', async (route) => {
      if (route.request().method() === 'PUT') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ sha256: 'mock', size: 0 }),
        });
      } else {
        await route.continue();
      }
    }),
    page.route(/https:\/\/[^/]+\/[0-9a-f]{64}/, async (route) => {
      if (route.request().method() === 'HEAD') {
        await route.fulfill({ status: 404 });
      } else {
        await route.continue();
      }
    }),
  ]);
}

test('textarea and save button visible on share page', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('text-input')).toBeVisible();
  await expect(page.getByTestId('text-save')).toBeVisible();
  await expect(page.getByTestId('text-save')).toBeDisabled();
});

test('type text and save navigates to viewer with content', async ({ page }) => {
  const text = 'Hello from the pastebin!';
  const expectedHash = createHash('sha256').update(text).digest('hex');

  await mockBlossom(page, expectedHash, text);
  await page.goto('/');

  await page.getByTestId('text-input').fill(text);
  await page.getByTestId('text-save').click();

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  expect(page.url()).toContain('nhash1');
  expect(page.url()).toContain('/text.txt');
  await expect(page.getByTestId('viewer-text')).toContainText(text);
});

test('cmd/ctrl+enter saves pasted text', async ({ page }) => {
  const text = 'Shortcut save from textarea';
  const expectedHash = createHash('sha256').update(text).digest('hex');

  await mockBlossom(page, expectedHash, text);
  await page.goto('/');

  await page.getByTestId('text-input').fill(text);
  await page.getByTestId('text-input').press(SAVE_WITH_ENTER);

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-text')).toContainText(text);
});

test('edit button visible for text files in viewer', async ({ page }) => {
  const fileContent = 'editable text';
  const expectedHash = createHash('sha256').update(fileContent).digest('hex');

  await mockBlossom(page, expectedHash, fileContent);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: 'doc.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(fileContent),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('edit-button')).toBeVisible();
});

test('edit text file and save creates new nhash URL', async ({ page }) => {
  const originalText = 'original content';
  const editedText = 'edited content';
  const originalHash = createHash('sha256').update(originalText).digest('hex');
  const editedHash = createHash('sha256').update(editedText).digest('hex');

  // Mock both hashes
  await mockBlossom(page, originalHash, originalText);
  await mockBlossom(page, editedHash, editedText);
  await page.goto('/');

  // Upload original file
  await page.getByTestId('file-input').setInputFiles({
    name: 'doc.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(originalText),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  const originalUrl = page.url();

  // Enter edit mode
  await page.getByTestId('edit-button').click();
  await expect(page.getByTestId('edit-textarea')).toBeVisible();

  // Edit and save
  await page.getByTestId('edit-textarea').fill(editedText);
  await page.getByTestId('edit-save').click();

  // Should navigate to new URL
  await expect(page.getByTestId('viewer-text')).toBeVisible({ timeout: 10000 });
  await expect(page.getByTestId('viewer-text')).toContainText(editedText);
  expect(page.url()).not.toBe(originalUrl);
  expect(page.url()).toContain('nhash1');
});

test('cmd/ctrl+enter saves edited text', async ({ page }) => {
  const originalText = 'original content from shortcut test';
  const editedText = 'edited with keyboard shortcut';
  const originalHash = createHash('sha256').update(originalText).digest('hex');
  const editedHash = createHash('sha256').update(editedText).digest('hex');

  await mockBlossom(page, originalHash, originalText);
  await mockBlossom(page, editedHash, editedText);
  await page.goto('/');

  await page.getByTestId('file-input').setInputFiles({
    name: 'doc.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(originalText),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });

  await page.getByTestId('edit-button').click();
  await expect(page.getByTestId('edit-textarea')).toBeVisible();

  await page.getByTestId('edit-textarea').fill(editedText);
  await page.getByTestId('edit-textarea').press(SAVE_WITH_ENTER);

  await expect(page.getByTestId('viewer-text')).toContainText(editedText, { timeout: 10000 });
});

test('browser back after edit returns to previous nhash URL', async ({ page }) => {
  const originalText = 'before edit';
  const editedText = 'after edit';
  const originalHash = createHash('sha256').update(originalText).digest('hex');
  const editedHash = createHash('sha256').update(editedText).digest('hex');

  await mockBlossom(page, originalHash, originalText);
  await mockBlossom(page, editedHash, editedText);
  await page.goto('/');

  // Upload original
  await page.getByTestId('file-input').setInputFiles({
    name: 'note.txt',
    mimeType: 'text/plain',
    buffer: Buffer.from(originalText),
  });

  await expect(page.getByTestId('file-viewer')).toBeVisible({ timeout: 10000 });
  const originalUrl = page.url();

  // Edit and save
  await page.getByTestId('edit-button').click();
  await page.getByTestId('edit-textarea').fill(editedText);
  await page.getByTestId('edit-save').click();

  await expect(page.getByTestId('viewer-text')).toContainText(editedText, { timeout: 10000 });

  // Go back
  await page.goBack();
  await expect(page.getByTestId('viewer-text')).toContainText(originalText, { timeout: 10000 });
  expect(page.url()).toBe(originalUrl);
});
