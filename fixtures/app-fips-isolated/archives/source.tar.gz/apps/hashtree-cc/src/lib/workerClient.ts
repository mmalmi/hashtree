import { HashtreeWorkerClient } from '@hashtree/worker';
import type { BlossomBandwidthState } from '@hashtree/worker';
import type { ConnectivityState } from '@hashtree/worker';
import type { UploadProgressState } from '@hashtree/worker';
import type { WorkerP2PProvider } from '@hashtree/worker';
import { writable } from 'svelte/store';
import HashtreeWorker from './hashtreeWorkerEntry?worker';
import { settingsStore } from './settings';
import { getRuntimeBlossomServers, getRuntimeWorkerConfig } from './htreeRuntime';

const DEFAULT_CONNECTIVITY: ConnectivityState = {
  online: typeof navigator === 'undefined' ? true : navigator.onLine,
  reachableReadServers: 0,
  totalReadServers: 0,
  reachableWriteServers: 0,
  totalWriteServers: 0,
  updatedAt: Date.now(),
};

const DEFAULT_BLOSSOM_BANDWIDTH: BlossomBandwidthState = {
  totalBytesSent: 0,
  totalBytesReceived: 0,
  updatedAt: 0,
  servers: [],
};

const CONNECTIVITY_POLL_INTERVAL_MS = 15_000;

export const connectivityStore = writable<ConnectivityState>(DEFAULT_CONNECTIVITY);
export const uploadProgressStore = writable<UploadProgressState | null>(null);
export const blossomBandwidthStore = writable<BlossomBandwidthState>(DEFAULT_BLOSSOM_BANDWIDTH);

let client: HashtreeWorkerClient | null = null;
let initPromise: Promise<HashtreeWorkerClient> | null = null;
let settingsUnsubscribe: (() => void) | null = null;
let connectivityUnsubscribe: (() => void) | null = null;
let uploadProgressUnsubscribe: (() => void) | null = null;
let blossomBandwidthUnsubscribe: (() => void) | null = null;
let connectivityTimer: ReturnType<typeof setInterval> | null = null;
let clearUploadProgressTimer: ReturnType<typeof setTimeout> | null = null;
let p2pProvider: WorkerP2PProvider | null = null;

async function probeConnectivity(clientInstance: HashtreeWorkerClient): Promise<void> {
  try {
    const state = await clientInstance.probeConnectivity();
    connectivityStore.set(state);
  } catch {
    // Ignore probe errors, worker will retry.
  }
}

function syncSettingsToWorker(clientInstance: HashtreeWorkerClient): void {
  if (settingsUnsubscribe) return;
  settingsUnsubscribe = settingsStore.subscribe((settings) => {
    void clientInstance.setBlossomServers(getRuntimeBlossomServers()).catch(() => {});
    void clientInstance.setStorageMaxBytes(settings.storage.maxBytes).catch(() => {});
  });
}

function startConnectivityPolling(clientInstance: HashtreeWorkerClient): void {
  if (connectivityUnsubscribe) return;
  connectivityUnsubscribe = clientInstance.onConnectivityUpdate((state) => {
    connectivityStore.set(state);
  });

  if (!connectivityTimer) {
    void probeConnectivity(clientInstance);
    connectivityTimer = setInterval(() => {
      void probeConnectivity(clientInstance);
    }, CONNECTIVITY_POLL_INTERVAL_MS);
  }
}

function startUploadProgressUpdates(clientInstance: HashtreeWorkerClient): void {
  if (uploadProgressUnsubscribe) return;
  uploadProgressUnsubscribe = clientInstance.onUploadProgress((progress) => {
    uploadProgressStore.set(progress);

    if (clearUploadProgressTimer) {
      clearTimeout(clearUploadProgressTimer);
      clearUploadProgressTimer = null;
    }

    if (progress.complete) {
      clearUploadProgressTimer = setTimeout(() => {
        uploadProgressStore.update((current) => {
          if (!current) return current;
          return current.hashHex === progress.hashHex && current.complete ? null : current;
        });
      }, 3000);
    }
  });
}

function startBlossomBandwidthUpdates(clientInstance: HashtreeWorkerClient): void {
  if (blossomBandwidthUnsubscribe) return;
  blossomBandwidthUnsubscribe = clientInstance.onBlossomBandwidth((stats) => {
    blossomBandwidthStore.set(stats);
  });
}

async function ensureClient(): Promise<HashtreeWorkerClient> {
  if (client) return client;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const settings = settingsStore.getState();
    const created = new HashtreeWorkerClient(HashtreeWorker, getRuntimeWorkerConfig({
      storeName: 'hashtree-cc-worker',
      storageMaxBytes: settings.storage.maxBytes,
      connectivityProbeIntervalMs: CONNECTIVITY_POLL_INTERVAL_MS,
    }));
    await created.init();
    created.setP2PProvider(p2pProvider);
    syncSettingsToWorker(created);
    startConnectivityPolling(created);
    startUploadProgressUpdates(created);
    startBlossomBandwidthUpdates(created);
    client = created;
    return created;
  })();

  return initPromise;
}

export async function initWorkerClient(): Promise<void> {
  await ensureClient();
}

export async function getWorkerClient(): Promise<HashtreeWorkerClient> {
  return ensureClient();
}

export async function putBlob(
  data: Uint8Array,
  mimeType?: string,
  upload = true
): Promise<{ hashHex: string; nhash: string }> {
  const worker = await ensureClient();
  return worker.putBlob(data, mimeType, upload);
}

export async function beginPutBlobStream(
  mimeType?: string,
  upload = true
): Promise<string> {
  const worker = await ensureClient();
  return worker.beginPutBlobStream(mimeType, upload);
}

export async function appendPutBlobStream(streamId: string, chunk: Uint8Array): Promise<void> {
  const worker = await ensureClient();
  await worker.appendPutBlobStream(streamId, chunk);
}

export async function finishPutBlobStream(streamId: string): Promise<{ hashHex: string; nhash: string }> {
  const worker = await ensureClient();
  return worker.finishPutBlobStream(streamId);
}

export async function cancelPutBlobStream(streamId: string): Promise<void> {
  const worker = await ensureClient();
  await worker.cancelPutBlobStream(streamId);
}

export async function getBlobForPeer(hashHex: string): Promise<Uint8Array | null> {
  const worker = await ensureClient();
  return worker.getBlobForPeer(hashHex);
}

export async function getStorageStats(): Promise<{ items: number; bytes: number; maxBytes: number }> {
  const worker = await ensureClient();
  return worker.getStorageStats();
}

export async function registerMediaPort(port: MessagePort): Promise<void> {
  const worker = await ensureClient();
  await worker.registerMediaPort(port);
}

export function setP2PProvider(provider: WorkerP2PProvider | null): void {
  p2pProvider = provider;
  client?.setP2PProvider(provider);
}
