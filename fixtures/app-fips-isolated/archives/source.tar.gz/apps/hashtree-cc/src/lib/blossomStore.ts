import { streamUploadWithProgress } from '@hashtree/core';
import {
  appendPutBlobStream,
  beginPutBlobStream,
  cancelPutBlobStream,
  finishPutBlobStream,
  putBlob,
} from './workerClient';
import {
  beginLocalSaveProgressForFile,
  endLocalSaveProgress,
  setLocalSavePhase,
  updateLocalSaveProgress,
} from './localSaveProgress';
import { uploadHistoryStore } from './uploadHistory';

const STREAM_APPEND_BATCH_BYTES = 2 * 1024 * 1024;

/**
 * Store data in local worker cache and upload to configured Blossom servers in background.
 * Returns the nhash-based URL fragment.
 */
export async function uploadBuffer(data: Uint8Array, fileName: string, mimeType: string): Promise<string> {
  beginLocalSaveProgressForFile(data.length, fileName);
  setLocalSavePhase('finalizing');
  updateLocalSaveProgress(data.length);
  try {
    const { nhash } = await putBlob(data, mimeType);
    uploadHistoryStore.add({ nhash, fileName, size: data.length, uploadedAt: Date.now() });
    const fragment = `/${nhash}/${encodeURIComponent(fileName)}`;
    window.location.hash = fragment;
    return fragment;
  } finally {
    endLocalSaveProgress();
  }
}

export async function uploadFileStream(file: File): Promise<string> {
  beginLocalSaveProgressForFile(file.size, file.name);
  let streamId: string | null = null;
  try {
    streamId = await beginPutBlobStream(file.type || 'application/octet-stream');

    const result = await streamUploadWithProgress(
      file,
      {
        append: async (chunk: Uint8Array) => {
          if (!streamId) throw new Error('Upload stream not initialized');
          await appendPutBlobStream(streamId, chunk);
        },
        finalize: async () => {
          if (!streamId) throw new Error('Upload stream not initialized');
          return finishPutBlobStream(streamId);
        },
      },
      {
        batchBytes: STREAM_APPEND_BATCH_BYTES,
        onProgress: (progress) => {
          setLocalSavePhase(progress.phase);
          updateLocalSaveProgress(progress.bytesProcessed, progress.totalBytes);
        },
      }
    );

    const { nhash } = result;
    streamId = null;
    uploadHistoryStore.add({ nhash, fileName: file.name, size: file.size, uploadedAt: Date.now() });
    const fragment = `/${nhash}/${encodeURIComponent(file.name)}`;
    window.location.hash = fragment;
    return fragment;
  } catch (err) {
    if (streamId) {
      await cancelPutBlobStream(streamId).catch(() => {});
    }
    throw err;
  } finally {
    endLocalSaveProgress();
  }
}
