import { defineConfig } from '@playwright/test';

const port = process.env.IRIS_SITES_E2E_PORT ?? '5179';
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: './e2e',
  timeout: 30000,
  use: {
    baseURL,
  },
  webServer: {
    command: `pnpm run dev --host 127.0.0.1 --port ${port} --strictPort`,
    url: baseURL,
    reuseExistingServer: false,
    env: {
      VITE_TEST_MODE: '1',
    },
  },
});
