// @ts-nocheck
import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { chromium } from '@playwright/test';

const MIME_TYPES = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.ico', 'image/x-icon'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.mjs', 'application/javascript; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.wasm', 'application/wasm'],
  ['.webmanifest', 'application/manifest+json; charset=utf-8'],
]);

function contentTypeFor(filePath) {
  return MIME_TYPES.get(path.extname(filePath)) ?? 'application/octet-stream';
}

function safeJoin(rootDir, requestPath, entryHtml) {
  const normalized = requestPath === '/' ? `/${entryHtml}` : requestPath;
  const fullPath = path.resolve(rootDir, `.${normalized}`);
  if (!fullPath.startsWith(rootDir + path.sep) && fullPath !== path.join(rootDir, entryHtml)) {
    throw new Error(`Refusing to serve path outside root: ${requestPath}`);
  }
  return fullPath;
}

async function startServer(rootDir, entryHtml = 'index.html') {
  const server = http.createServer(async (req, res) => {
    try {
      const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1');
      const filePath = safeJoin(rootDir, decodeURIComponent(requestUrl.pathname), entryHtml);
      const body = await readFile(filePath);
      res.writeHead(200, {
        'content-type': contentTypeFor(filePath),
        'cache-control': 'no-store',
      });
      res.end(body);
    } catch (error) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(error instanceof Error ? error.message : 'not found');
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });

  const address = server.address();
  if (!address || typeof address === 'string') {
    server.close();
    throw new Error('Failed to determine portable smoke server address');
  }

  return {
    server,
    url: `http://127.0.0.1:${address.port}/${entryHtml}`,
  };
}

export async function runPortableSmoke({ distDir, title, appName, screenshotPath }) {
  const { server, url } = await startServer(distDir);
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  // Fixed image bytes preserve the production avatar URL without external I/O.
  await page.route('https://imgproxy.iris.to/**', route => route.fulfill({ contentType: 'image/png', body: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=', 'base64') }));
  const packagedGraph = await readFile(path.resolve('node_modules/nostr-social-graph/data/socialGraph.bin'));
  await page.route('https://graph-api.iris.to/**', route => route.fulfill({ body: packagedGraph, contentType: 'application/octet-stream', headers: { 'x-graph-root': '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0' } }));
  const localOrigin = new URL(url).origin;
  const consoleErrors = [];
  const localResourceErrors = [];
  const pageErrors = [];

  page.on('console', (message) => {
    if (message.type() === 'error' && !isIgnorableBrowserResourceError(message.text())) {
      consoleErrors.push(message.text());
    }
  });
  page.on('response', (response) => {
    if (response.url().startsWith(localOrigin) && response.status() >= 400) {
      localResourceErrors.push(`${response.status()} ${response.url()}`);
    }
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.stack || error.message);
  });

  try {
    const response = await page.goto(url, { waitUntil: 'load', timeout: 60000 });
    if (!response || response.status() !== 200) {
      throw new Error(`Portable build returned ${response?.status() ?? 'no response'} for ${url}`);
    }
    await page.waitForTimeout(500);
    await page.screenshot({ path: screenshotPath, fullPage: true });

    const actualTitle = await page.title();
    if (actualTitle !== title) {
      throw new Error(`Portable build loaded unexpected title "${actualTitle}"`);
    }

    await page.getByText(appName, { exact: true }).first().waitFor({ state: 'visible', timeout: 5000 });
    await page.getByPlaceholder('Search').waitFor({ state: 'visible', timeout: 5000 });

    if (pageErrors.length > 0) {
      throw new Error(`Portable build hit page errors:\n${pageErrors.join('\n')}`);
    }
    if (localResourceErrors.length > 0) {
      throw new Error(`Portable build failed to load local resources:\n${localResourceErrors.join('\n')}`);
    }
    if (consoleErrors.length > 0) {
      throw new Error(`Portable build logged console errors:\n${consoleErrors.join('\n')}`);
    }

    console.log(`Portable Iris ${appName} smoke passed: ${url}`);
    console.log(`Screenshot: ${screenshotPath}`);
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
}

function isIgnorableBrowserResourceError(text) {
  return /^Failed to load resource: the server responded with a status of 403 \(\)$/.test(text)
    || /^Failed to load resource: the server responded with a status of 404 \(\)$/.test(text)
    || /^Failed to load resource: the server responded with a status of 429 \(\)$/.test(text)
    || /^Failed to load resource: the server responded with a status of 5\d\d \(\)$/.test(text)
    || /^WebSocket connection to 'wss:\/\/[^']+' failed:/.test(text);
}
