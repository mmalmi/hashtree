// @ts-nocheck
export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  contacts: {
    name: 'contacts',
    appName: 'iris contacts',
    distDir: 'dist',
    treeName: 'contacts',
    defaultWorkerName: 'iris-contacts',
    defaultRoutes: [],
    defaultDomains: ['contacts.iris.to'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_CONTACTS',
    pagesProjectEnv: 'CF_PAGES_PROJECT_CONTACTS',
    buildCommand: ['pnpm', 'run', 'build'],
    testCommands: [
      ['pnpm', 'run', 'test:model'],
      ['pnpm', 'exec', 'svelte-check', '--tsconfig', './tsconfig.json'],
      ['pnpm', 'run', 'test:e2e:built'],
      ['node', './scripts/smoke-contacts-portable.mjs'],
      ['node', './scripts/smoke-negentropy-graph.mjs', 'contacts'],
    ],
  },
};

export const releaseProfileNames = ['contacts'];
