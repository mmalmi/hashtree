import http from 'node:http';
import path from 'node:path';
import { mkdir, readFile, readdir } from 'node:fs/promises';
import { chromium, expect } from '@playwright/test';

const appDir = path.resolve(import.meta.dirname, '..');
const distDir = path.join(appDir, 'dist');
const screenshotPath = path.join(appDir, 'test-results', 'iris-sites-portable-smoke.png');
const SAMPLE_NHASH = 'nhash1qqsxdy0lh7pgrl8r6rlefacjjvp2g6jzpupn7meljc04j05edkssjwq9yz5j5z8wfnmtwruy558t7myasvy654pj37hvynk422srdfaqs44uxaqxp28';
const SAMPLE_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const SAMPLE_TREE = 'hashtree-cc-site';
const FORBIDDEN_DIST_FILENAMES = new Set(['.DS_Store']);

const MIME_TYPES = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.ico', 'image/x-icon'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.mjs', 'application/javascript; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.txt', 'text/plain; charset=utf-8'],
  ['.webmanifest', 'application/manifest+json; charset=utf-8'],
  ['.woff', 'font/woff'],
  ['.woff2', 'font/woff2'],
]);

function contentTypeFor(filePath) {
  return MIME_TYPES.get(path.extname(filePath)) ?? 'application/octet-stream';
}

function safeJoin(rootDir, requestPath) {
  const normalizedPath = requestPath === '/' ? '/index.html' : requestPath;
  const fullPath = path.resolve(rootDir, `.${normalizedPath}`);
  if (!fullPath.startsWith(rootDir + path.sep) && fullPath !== path.join(rootDir, 'index.html')) {
    throw new Error(`Refusing to serve path outside root: ${requestPath}`);
  }
  return fullPath;
}

function isLocalHtreeServiceWorkerRequest(requestPath) {
  return /^\/htree\/.+\/sw\.js$/.test(requestPath);
}

async function assertNoForbiddenDistFiles(rootDir, currentDir = rootDir) {
  const entries = await readdir(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    const filePath = path.join(currentDir, entry.name);
    if (FORBIDDEN_DIST_FILENAMES.has(entry.name)) {
      throw new Error(`Refusing to smoke or publish forbidden dist file: ${path.relative(rootDir, filePath)}`);
    }
    if (entry.isDirectory()) {
      await assertNoForbiddenDistFiles(rootDir, filePath);
    }
  }
}

async function startServer(rootDir) {
  const server = http.createServer(async (req, res) => {
    const requestUrl = new URL(req.url ?? '/', 'http://sites.iris.localhost');
    try {
      if (isLocalHtreeServiceWorkerRequest(requestUrl.pathname)) {
        res.writeHead(200, {
          'content-type': 'application/javascript; charset=utf-8',
          'cache-control': 'no-store',
        });
        res.end('// Local smoke harness stub for child app service workers.\n');
        return;
      }

      const filePath = safeJoin(rootDir, decodeURIComponent(requestUrl.pathname));
      const body = await readFile(filePath);
      res.writeHead(200, {
        'content-type': contentTypeFor(filePath),
        'cache-control': 'no-store',
      });
      if (req.method === 'HEAD') {
        res.end();
        return;
      }
      res.end(body);
    } catch (error) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(error instanceof Error ? error.message : 'not found');
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });

  const address = server.address();
  if (!address || typeof address === 'string') {
    server.close();
    throw new Error('Failed to determine iris-sites smoke server address');
  }

  return {
    server,
    port: address.port,
  };
}

function installFakeWebSocket(context) {
  return context.addInitScript(() => {
    class FakeWebSocket extends EventTarget {
      static CONNECTING = 0;
      static OPEN = 1;
      static CLOSING = 2;
      static CLOSED = 3;

      CONNECTING = FakeWebSocket.CONNECTING;
      OPEN = FakeWebSocket.OPEN;
      CLOSING = FakeWebSocket.CLOSING;
      CLOSED = FakeWebSocket.CLOSED;
      binaryType = 'blob';
      bufferedAmount = 0;
      extensions = '';
      protocol = '';
      readyState = FakeWebSocket.CONNECTING;
      url = '';
      onopen = null;
      onclose = null;
      onerror = null;
      onmessage = null;

      constructor(url) {
        super();
        this.url = String(url);
        queueMicrotask(() => {
          this.readyState = FakeWebSocket.OPEN;
          const event = new Event('open');
          this.dispatchEvent(event);
          this.onopen?.(event);
        });
      }

      send(_data) {}

      close(code = 1000, reason = '') {
        if (this.readyState === FakeWebSocket.CLOSED) return;
        this.readyState = FakeWebSocket.CLOSED;
        const event = new CloseEvent('close', { code, reason, wasClean: true });
        this.dispatchEvent(event);
        this.onclose?.(event);
      }
    }

    Object.defineProperty(window, 'WebSocket', {
      value: FakeWebSocket,
      configurable: true,
      writable: true,
    });
    Object.defineProperty(globalThis, 'WebSocket', {
      value: FakeWebSocket,
      configurable: true,
      writable: true,
    });
  });
}

function shouldIgnoreConsoleError(text, url = '') {
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: NIP-07 extension not available')) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: NIP-44 encryption not available')) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: No connected relays available for publish')) {
    return true;
  }
  if (/^Failed to load resource: the server responded with a status of (?:404|500)\b/.test(text)) {
    try {
      return new URL(url).pathname.startsWith('/htree/');
    } catch {
      return false;
    }
  }
  return false;
}

function attachErrorCollection(page, errors) {
  page.on('pageerror', (error) => {
    errors.push(`pageerror: ${error.stack || error.message}`);
  });
  page.on('console', (message) => {
    if (message.type() === 'error') {
      const text = message.text();
      const location = message.location();
      if (shouldIgnoreConsoleError(text, location.url)) {
        return;
      }
      const suffix = location.url ? ` (${location.url}:${location.lineNumber}:${location.columnNumber})` : '';
      errors.push(`console: ${text}${suffix}`);
    }
  });
}

async function assertRuntimeShell(page, timeoutMs, { expectMenu = true } = {}) {
  const frame = page.locator('iframe.site-frame');
  try {
    await frame.waitFor({ state: 'attached', timeout: timeoutMs });
    const src = await frame.getAttribute('src', { timeout: timeoutMs });
    if (!src || !src.startsWith('/htree/')) {
      throw new Error(`Expected runtime iframe to load /htree content, got ${src ?? 'no src'}`);
    }
    const menuButton = page.locator('.runtime-menu-button');
    if (expectMenu) {
      await menuButton.waitFor({ state: 'visible', timeout: timeoutMs });
    } else if (await menuButton.count()) {
      throw new Error(`Expected runtime menu to be hidden, got ${page.url()}`);
    }
  } catch (error) {
    const frameSummaries = await Promise.all(page.frames().map(async (frame) => {
      let bodyText = '';
      try {
        if (frame !== page.mainFrame()) {
          bodyText = (await frame.locator('body').innerText({ timeout: 1000 })).slice(0, 200);
        }
      } catch {
        // Ignore frame body lookup failures in debug output.
      }
      return `${frame.url()} :: ${bodyText}`;
    }));
    const pageUrl = page.url();
    const iframeCount = await page.locator('iframe').count().catch(() => 0);
    throw new Error([
      error instanceof Error ? error.message : String(error),
      `page=${pageUrl}`,
      `iframes=${iframeCount}`,
      `frames=${frameSummaries.join(' | ')}`,
    ].join('\n'));
  }
}

function splitDnsLabels(value) {
  return value.match(/.{1,63}/g)?.join('.') ?? value;
}

function immutableRuntimeHost(nhash, port) {
  return {
    host: `http://${splitDnsLabels(nhash)}.iris.localhost:${port}`,
  };
}

function mutableRuntimeHost(npub, treeName, port) {
  return `http://${treeName}.${npub}.iris.localhost:${port}/index.html`;
}

await assertNoForbiddenDistFiles(distDir);
const { server, port } = await startServer(distDir);
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext();
const pageErrors = [];

await installFakeWebSocket(context);

try {
  await mkdir(path.dirname(screenshotPath), { recursive: true });

  const launcherPage = await context.newPage();
  attachErrorCollection(launcherPage, pageErrors);
  const launcherUrl = `http://sites.iris.localhost:${port}/`;
  const launcherResponse = await launcherPage.goto(launcherUrl, { waitUntil: 'load', timeout: 60000 });
  if (!launcherResponse || launcherResponse.status() !== 200) {
    throw new Error(`Launcher page returned ${launcherResponse?.status() ?? 'no response'} for ${launcherUrl}`);
  }
  await launcherPage.getByText('Quick Share').waitFor({ timeout: 60000 });
  await expect(launcherPage.getByRole('link', { name: 'Market', exact: true })).toBeVisible();
  await launcherPage.screenshot({ path: path.join(appDir, 'test-results', 'iris-sites-market-launcher.png'), fullPage: true });
  if (await launcherPage.getByText('MIDI Enshittifier').count()) {
    throw new Error('Removed MIDI demo is still present in launcher suggestions');
  }
  await launcherPage.locator('.suggestion', { hasText: 'Quick Share' }).click();
  await launcherPage.waitForURL(mutableRuntimeHost(SAMPLE_NPUB, SAMPLE_TREE, port), { timeout: 60000 });
  await assertRuntimeShell(launcherPage, 60000, { expectMenu: false });
  await launcherPage.goBack({ waitUntil: 'load', timeout: 60000 });
  await launcherPage.waitForURL(launcherUrl, { timeout: 60000 });
  await launcherPage.getByTestId('add-site-button').waitFor({ state: 'visible', timeout: 60000 });
  const restoredLauncherState = await launcherPage.evaluate(() => {
    return {
      addPanelCount: document.querySelectorAll('.add-site-panel').length,
      activeCount: document.querySelectorAll('.suggestion-shell.active').length,
    };
  });
  if (restoredLauncherState.addPanelCount !== 0) {
    throw new Error('Expected launcher Add panel to stay closed after back navigation');
  }
  if (restoredLauncherState.activeCount !== 0) {
    throw new Error(`Expected launcher to have no active tile after back navigation, got ${restoredLauncherState.activeCount}`);
  }

  const routeLaunchPage = await context.newPage();
  attachErrorCollection(routeLaunchPage, pageErrors);
  const routeLaunchResponse = await routeLaunchPage.goto(launcherUrl, { waitUntil: 'load', timeout: 60000 });
  if (!routeLaunchResponse || routeLaunchResponse.status() !== 200) {
    throw new Error(`Route launcher page returned ${routeLaunchResponse?.status() ?? 'no response'} for ${launcherUrl}`);
  }
  await routeLaunchPage.getByTestId('add-site-button').click();
  await routeLaunchPage.getByRole('button', { name: 'Add by URL' }).click();
  const routeLaunchInput = routeLaunchPage.locator('input[name="site-route"]');
  await routeLaunchInput.fill(`${SAMPLE_NPUB}/${SAMPLE_TREE}`);
  await routeLaunchPage.locator('.launch-result-card').click();
  await routeLaunchPage.getByRole('dialog', { name: 'Add site' }).waitFor({ state: 'hidden', timeout: 60000 });
  await routeLaunchPage.getByRole('button', { name: 'Done' }).click();
  await routeLaunchPage.locator('.suggestion', { hasText: 'Quick Share' }).click();
  await routeLaunchPage.waitForURL(mutableRuntimeHost(SAMPLE_NPUB, SAMPLE_TREE, port), { timeout: 60000 });
  await assertRuntimeShell(routeLaunchPage, 60000, { expectMenu: false });

  const genericPage = await context.newPage();
  attachErrorCollection(genericPage, pageErrors);
  const genericUrl = `http://sites.iris.localhost:${port}/#/${SAMPLE_NHASH}/index.html`;
  const genericResponse = await genericPage.goto(genericUrl, { waitUntil: 'load', timeout: 60000 });
  if (!genericResponse || genericResponse.status() !== 200) {
    throw new Error(`Generic portal boot page returned ${genericResponse?.status() ?? 'no response'} for ${genericUrl}`);
  }
  const immutableRuntime = immutableRuntimeHost(SAMPLE_NHASH, port);
  await genericPage.waitForURL(`${immutableRuntime.host}/index.html#/`, { timeout: 60000 });
  await assertRuntimeShell(genericPage, 60000, { expectMenu: false });
  const genericHref = genericPage.url();
  if (!genericHref.startsWith(immutableRuntime.host)) {
    throw new Error(`Expected split nhash runtime host, got ${genericHref}`);
  }
  if (genericHref.includes('.sites.iris.localhost')) {
    throw new Error(`Local immutable runtime used the old sites wildcard host: ${genericHref}`);
  }

  const mutablePage = await context.newPage();
  attachErrorCollection(mutablePage, pageErrors);
  const mutableRouteSuffix = '?menu=0&reload=1';
  const mutableUrl = `http://sites.iris.localhost:${port}/#/${SAMPLE_NPUB}/${SAMPLE_TREE}/index.html${mutableRouteSuffix}`;
  const mutableResponse = await mutablePage.goto(mutableUrl, { waitUntil: 'load', timeout: 60000 });
  if (!mutableResponse || mutableResponse.status() !== 200) {
    throw new Error(`Mutable portal boot page returned ${mutableResponse?.status() ?? 'no response'} for ${mutableUrl}`);
  }
  await mutablePage.waitForURL(`${mutableRuntimeHost(SAMPLE_NPUB, SAMPLE_TREE, port)}#/?menu=0&reload=1`, { timeout: 60000 });
  const mutableHref = mutablePage.url();
  if (!mutableHref.startsWith(`${mutableRuntimeHost(SAMPLE_NPUB, SAMPLE_TREE, port)}#/?menu=0&reload=1`)) {
    throw new Error(`Expected readable mutable runtime host, got ${mutableHref}`);
  }
  if (mutableHref.includes('.sites.iris.localhost')) {
    throw new Error(`Local mutable runtime used the old sites wildcard host: ${mutableHref}`);
  }
  await assertRuntimeShell(mutablePage, 60000, { expectMenu: false });

  const directImmutablePage = await context.newPage();
  attachErrorCollection(directImmutablePage, pageErrors);
  const directImmutableUrl = `${immutableRuntime.host}/index.html`;
  const directImmutableResponse = await directImmutablePage.goto(directImmutableUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
  if (!directImmutableResponse || directImmutableResponse.status() !== 200) {
    throw new Error(`Direct immutable runtime returned ${directImmutableResponse?.status() ?? 'no response'} for ${directImmutableUrl}`);
  }
  await assertRuntimeShell(directImmutablePage, 60000, { expectMenu: false });
  await genericPage.screenshot({ path: screenshotPath, fullPage: true });

  await Promise.all(context.pages().filter(page => page !== launcherPage).map(page => page.close()));
  const peerIdentity = await launcherPage.evaluate(() => localStorage.getItem('iris-sites:fips-device-secret'));
  await launcherPage.evaluate(async () => { await navigator.serviceWorker.ready; });
  await expect.poll(() => launcherPage.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  await context.setOffline(true);
  await launcherPage.reload();
  await expect(launcherPage.getByTestId('add-site-button')).toBeVisible();
  expect(await launcherPage.evaluate(() => localStorage.getItem('iris-sites:fips-device-secret'))).toBe(peerIdentity);

  if (pageErrors.length > 0) {
    throw new Error(`Iris Sites smoke hit browser errors:\n${pageErrors.join('\n')}`);
  }

  console.log(`Iris Sites portable smoke passed: ${genericUrl}`);
  console.log(`Screenshot: ${screenshotPath}`);
} finally {
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
