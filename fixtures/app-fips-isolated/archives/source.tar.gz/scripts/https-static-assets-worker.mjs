/**
 * @typedef {{ ASSETS: { fetch(request: Request): Response | Promise<Response> } }} StaticAssetsEnv
 * @typedef {Request & { cf?: { tlsVersion?: string } }} CloudflareRequest
 */

const CANONICAL_HOST = 'apps.iris.to';
const LEGACY_HOST = 'sites.iris.to';
const ROOT_ASSET_DIRECTORIES = new Set(['assets', 'launcher-icons']);
const ROOT_ASSET_FILES = new Set([
  'dev-sw.js',
  'favicon.svg',
  'link-preview.png',
  'link-preview.svg',
  'manifest.webmanifest',
  'registerSW.js',
  'secp256k1.wasm',
  'sw.js',
]);

/**
 * @param {CloudflareRequest} request
 */
function forwardedScheme(request) {
  const forwardedProto = request.headers.get('x-forwarded-proto');
  if (forwardedProto) return forwardedProto.toLowerCase();

  const visitor = request.headers.get('cf-visitor');
  if (!visitor) return '';
  try {
    const parsed = JSON.parse(visitor);
    return typeof parsed.scheme === 'string' ? parsed.scheme.toLowerCase() : '';
  } catch {
    return '';
  }
}

/**
 * @param {CloudflareRequest} request
 * @param {URL} url
 */
function shouldRedirectToHttps(request, url) {
  const scheme = forwardedScheme(request);
  if (request.cf && !request.cf.tlsVersion) {
    return true;
  }
  return scheme === 'http' || (!scheme && url.protocol === 'http:');
}

/**
 * @param {URL} url
 */
function shouldRedirectToCanonicalHost(url) {
  return url.hostname.toLowerCase() === LEGACY_HOST;
}

/**
 * @param {URL} url
 */
function getCanonicalRootAssetPath(url) {
  if (url.pathname.startsWith('/htree/')) return null;

  const parts = url.pathname.split('/').filter(Boolean);
  if (parts.length < 2) return null;

  const rootAssetDirectoryIndex = parts.findIndex((part) => ROOT_ASSET_DIRECTORIES.has(part));
  if (rootAssetDirectoryIndex > 0) {
    return `/${parts.slice(rootAssetDirectoryIndex).join('/')}`;
  }

  const fileName = parts.at(-1);
  if (fileName && ROOT_ASSET_FILES.has(fileName)) {
    return `/${fileName}`;
  }

  return null;
}

/**
 * @param {CloudflareRequest} request
 * @param {URL} url
 */
function createRootAssetRequest(request, url) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return null;

  const canonicalPath = getCanonicalRootAssetPath(url);
  if (!canonicalPath) return null;

  const assetUrl = new URL(url);
  assetUrl.pathname = canonicalPath;
  return new Request(assetUrl.toString(), request);
}

export default {
  /**
   * @param {CloudflareRequest} request
   * @param {StaticAssetsEnv} env
   */
  fetch(request, env) {
    const url = new URL(request.url);
    const redirectToHttps = shouldRedirectToHttps(request, url);
    const redirectToCanonicalHost = shouldRedirectToCanonicalHost(url);
    if (redirectToHttps || redirectToCanonicalHost) {
      url.protocol = 'https:';
      url.port = '';
      if (redirectToCanonicalHost) {
        url.hostname = CANONICAL_HOST;
      }
      return Response.redirect(url.toString(), 308);
    }

    return env.ASSETS.fetch(createRootAssetRequest(request, url) ?? request);
  },
};
