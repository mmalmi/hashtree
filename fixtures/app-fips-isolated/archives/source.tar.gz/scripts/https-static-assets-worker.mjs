// @ts-nocheck

function forwardedScheme(request) {
  const forwardedProto = request.headers.get('x-forwarded-proto');
  if (forwardedProto) return forwardedProto.toLowerCase();

  const visitor = request.headers.get('cf-visitor');
  if (!visitor) return '';
  try {
    const parsed = JSON.parse(visitor);
    return typeof parsed.scheme === 'string' ? parsed.scheme.toLowerCase() : '';
  } catch {
    return '';
  }
}

function shouldRedirectToHttps(request, url) {
  const scheme = forwardedScheme(request);
  if (request.cf && !request.cf.tlsVersion) {
    return true;
  }
  return scheme === 'http' || (!scheme && url.protocol === 'http:');
}

export function canonicalAliasPath(pathname) {
  const segments = pathname
    .split('/')
    .map((segment) => safeDecode(segment.trim()))
    .filter(Boolean);
  if (segments.length !== 2) return null;

  const [prefix, target] = segments;
  if (prefix !== 'contact' && prefix !== 'profile') return null;
  if (!isProfileRouteToken(target) && !isUuidRouteToken(target)) return null;
  return `/${target}`;
}

export function shouldServeIndexFallback(request, url) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return false;
  if (url.pathname === '/' || url.pathname === '/index.html') return false;
  if (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/htree/')) return false;
  const lastSegment = url.pathname.split('/').filter(Boolean).at(-1) ?? '';
  return !lastSegment.includes('.');
}

function isProfileRouteToken(value) {
  return /^npub1[023456789acdefghjklmnpqrstuvwxyz]+$/i.test(value)
    || /^nprofile1[023456789acdefghjklmnpqrstuvwxyz]+$/i.test(value)
    || /^[0-9a-f]{64}$/i.test(value);
}

function isUuidRouteToken(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function safeDecode(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (shouldRedirectToHttps(request, url)) {
      url.protocol = 'https:';
      url.port = '';
      return Response.redirect(url.toString(), 308);
    }

    const canonicalPath = canonicalAliasPath(url.pathname);
    if (canonicalPath && canonicalPath !== url.pathname) {
      url.pathname = canonicalPath;
      return Response.redirect(url.toString(), 308);
    }

    if (shouldServeIndexFallback(request, url)) {
      const indexUrl = new URL(request.url);
      indexUrl.pathname = '/';
      return env.ASSETS.fetch(new Request(indexUrl, request));
    }

    return env.ASSETS.fetch(request);
  },
};
