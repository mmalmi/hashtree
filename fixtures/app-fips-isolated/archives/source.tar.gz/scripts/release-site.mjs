// @ts-nocheck
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  cloneValues,
  createDefaultRunner,
  createReleasePlan as createSharedReleasePlan,
  runReleasePlan,
  usesBuiltInWorker,
} from '@iris/release-tools';
import { resolveHtreeCommand } from './hashtreePaths.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');
const defaultWorkerCompatibilityDate = '2026-03-19';
const wranglerVersion = '4';

export const releaseProfile = {
  appName: 'iris sites',
  distDir: 'dist',
  treeName: 'sites',
  defaultWorkerName: 'iris-sites',
  defaultRoutes: ['apps.iris.to/*', 'sites.iris.to/*', '*.hashtree.cc/*'],
  workerScript: 'scripts/https-static-assets-worker.mjs',
  workerNameEnv: 'CF_WORKER_NAME_SITES',
  pagesProjectEnv: 'CF_PAGES_PROJECT_SITES',
  buildCommand: ['pnpm', 'run', 'build'],
  testCommands: [
    ['node', './scripts/verify-htree-cli.mjs'],
    ['pnpm', 'verify:dependency-lock'],
    ['pnpm', 'exec', 'vitest', 'run', 'tests/siteConfig.test.ts', 'tests/siteHost.test.ts', 'tests/runtimeUi.test.ts', 'tests/runtimeUpdatePolicy.test.ts', 'tests/faviconSync.test.ts', 'tests/titleSync.test.ts', 'tests/launchInput.test.ts', 'tests/gridKeyboardNavigation.test.ts', 'tests/bootShellMarkup.test.ts', 'tests/webvmCatalog.test.ts', 'tests/runtimeMenuMarkup.test.ts', 'tests/swUpdatePolicy.test.ts', 'tests/portableBuildConfig.test.ts', 'tests/releaseSite.test.ts'],
    ['pnpm', 'exec', 'svelte-check', '--tsconfig', './tsconfig.json', '--config', './svelte.config.js'],
    ['node', './scripts/portable-smoke.mjs'],
  ],
};

function getReleaseEnv(env = process.env) {
  return env;
}

export function parseArgs(argv, env = process.env) {
  const args = [...argv].filter((arg, index) => !(arg === '--' && index === 0));
  let pagesProject;
  let workerName;
  let treeName;
  let branch;
  let dryRun = false;
  let skipCloudflare = false;
  let pagesOnly = false;
  const routes = [];
  const domains = [];
  let workerCompatibilityDate;

  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '-h' || arg === '--help') {
      return { help: true };
    }
    if (arg === '--') {
      continue;
    }
    if (arg === '--pages-project') {
      pagesProject = args.shift();
      continue;
    }
    if (arg === '--worker-name') {
      workerName = args.shift();
      continue;
    }
    if (arg === '--tree') {
      treeName = args.shift();
      continue;
    }
    if (arg === '--route') {
      routes.push(args.shift());
      continue;
    }
    if (arg === '--domain') {
      domains.push(args.shift());
      continue;
    }
    if (arg === '--branch') {
      branch = args.shift();
      continue;
    }
    if (arg === '--dry-run') {
      dryRun = true;
      continue;
    }
    if (arg === '--compatibility-date') {
      workerCompatibilityDate = args.shift();
      continue;
    }
    if (arg === '--skip-cloudflare' || arg === '--skip-pages') {
      skipCloudflare = true;
      continue;
    }
    if (arg === '--pages-only') {
      pagesOnly = true;
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  if (pagesOnly && workerName) {
    throw new Error('--pages-only is not compatible with --worker-name');
  }
  if (pagesOnly && (routes.length > 0 || domains.length > 0)) {
    throw new Error('--pages-only is not compatible with --route/--domain');
  }

  const resolvedWorkerName = pagesOnly
    ? undefined
    : workerName ?? env[releaseProfile.workerNameEnv] ?? releaseProfile.defaultWorkerName;
  const defaultRoutes = usesBuiltInWorker(releaseProfile, resolvedWorkerName)
    ? cloneValues(releaseProfile.defaultRoutes)
    : [];

  return {
    dryRun,
    skipCloudflare,
    pagesOnly,
    branch,
    treeName: treeName ?? releaseProfile.treeName,
    workerName: resolvedWorkerName,
    pagesProject: pagesProject ?? env[releaseProfile.pagesProjectEnv],
    routes: routes.length > 0 ? routes : defaultRoutes,
    domains,
    workerCompatibilityDate:
      workerCompatibilityDate ?? env.CF_WORKER_COMPATIBILITY_DATE ?? defaultWorkerCompatibilityDate,
  };
}

export function createReleasePlan(options) {
  return createSharedReleasePlan({
    appDir,
    options,
    profile: releaseProfile,
    resolveHtreeCommand,
    wranglerVersion,
  });
}

function defaultRunner(step) {
  return createDefaultRunner({ env: getReleaseEnv() })(step);
}

export async function runRelease(options, runner = defaultRunner, hooks = {}) {
  const plan = createReleasePlan(options);
  return runReleasePlan(options, plan, runner, hooks);
}

export function usage() {
  return `Usage: node ./scripts/release-site.mjs [options]

Build once, test the built output, then publish to hashtree and deploy that same
directory to Cloudflare Workers Static Assets or Cloudflare Pages in parallel.

Options:
  --worker-name <name>    Cloudflare Worker service name for static assets
  --pages-project <name>  Cloudflare Pages project name
  --tree <name>           hashtree mutable tree name override
  --route <pattern>       Worker route, for example apps.iris.to/*
  --domain <hostname>     Worker custom domain
  --branch <name>         Pages branch/preview deployment target
  --pages-only            disable the built-in/default Worker target and use Pages
  --compatibility-date    Worker compatibility date override
  --skip-cloudflare       publish to hashtree only
  --skip-pages            alias for --skip-cloudflare
  --dry-run               print planned steps without running them

Environment:
  ${releaseProfile.workerNameEnv}   Default Worker name
  ${releaseProfile.pagesProjectEnv}   Default Pages project
  CF_WORKER_COMPATIBILITY_DATE   Default compatibility date for Worker deployments
  CLOUDFLARE_API_TOKEN   Wrangler token
  CLOUDFLARE_ACCOUNT_ID   Cloudflare account id
`;
}

function printSummary(result) {
  const { profile, publish, pagesProject, pagesUrl, workerName, routes, domains } = result;
  console.log(`\n${profile.appName} release complete.`);
  console.log(`Hashtree immutable URL: htree://${publish.nhash}/index.html`);
  console.log(`Hashtree mutable URL: htree://${publish.publishedRef}`);
  if (workerName) {
    console.log(`Worker service: ${workerName}`);
  }
  for (const route of routes ?? []) {
    console.log(`Worker route: ${route}`);
  }
  for (const domain of domains ?? []) {
    console.log(`Worker domain: ${domain}`);
  }
  if (pagesProject) {
    console.log(`Pages project: ${pagesProject}`);
  }
  if (pagesUrl) {
    console.log(`Deployment URL: ${pagesUrl}`);
  }
  console.log(`Tree name: ${result.treeName}`);
}

async function main() {
  const options = parseArgs(process.argv.slice(2), getReleaseEnv());
  if (options.help) {
    console.log(usage());
    return;
  }

  if (options.dryRun) {
    const result = await runRelease(options);
    console.log(usage());
    for (const step of result.steps) {
      console.log(`${step.label}: ${step.command.join(' ')} (cwd: ${step.cwd})`);
    }
    return;
  }

  const result = await runRelease(options);
  printSummary(result);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  });
}
