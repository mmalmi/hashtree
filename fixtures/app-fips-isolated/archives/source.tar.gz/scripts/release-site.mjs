// @ts-nocheck
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  cloneValues,
  createDefaultRunner,
  createReleasePlan as createSharedReleasePlan,
  runReleasePlan,
  usesBuiltInWorker,
} from '@iris/release-tools';
import { resolveHtreeCommand } from './hashtreePaths.mjs';
import {
  defaultWorkerCompatibilityDate,
  releaseProfileNames,
  releaseProfiles,
  wranglerVersion,
} from './release-profiles.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');
const defaultRunner = createDefaultRunner();

export {
  defaultWorkerCompatibilityDate,
  releaseProfileNames,
  releaseProfiles,
  wranglerVersion,
} from './release-profiles.mjs';

export { parsePublishOutput } from '@iris/release-tools';

export function parseArgs(argv, env = process.env) {
  const args = [...argv].filter((arg, index) => !(arg === '--' && index === 0));
  const profileName = args.shift();
  if (!profileName || profileName === '-h' || profileName === '--help') {
    return { help: true };
  }

  let pagesProject;
  let workerName;
  let treeName;
  let branch;
  let dryRun = false;
  let skipCloudflare = false;
  let pagesOnly = false;
  const routes = [];
  const domains = [];
  let workerCompatibilityDate;

  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '--') continue;
    if (arg === '--pages-project') {
      pagesProject = args.shift();
      continue;
    }
    if (arg === '--worker-name') {
      workerName = args.shift();
      continue;
    }
    if (arg === '--tree') {
      treeName = args.shift();
      continue;
    }
    if (arg === '--route') {
      routes.push(args.shift());
      continue;
    }
    if (arg === '--domain') {
      domains.push(args.shift());
      continue;
    }
    if (arg === '--branch') {
      branch = args.shift();
      continue;
    }
    if (arg === '--dry-run') {
      dryRun = true;
      continue;
    }
    if (arg === '--compatibility-date') {
      workerCompatibilityDate = args.shift();
      continue;
    }
    if (arg === '--skip-cloudflare' || arg === '--skip-pages') {
      skipCloudflare = true;
      continue;
    }
    if (arg === '--pages-only') {
      pagesOnly = true;
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  const profile = releaseProfiles[profileName];
  if (!profile) {
    throw new Error(`Unknown release profile: ${profileName}`);
  }
  if (pagesOnly && workerName) {
    throw new Error('--pages-only is not compatible with --worker-name');
  }
  if (pagesOnly && (routes.length > 0 || domains.length > 0)) {
    throw new Error('--pages-only is not compatible with --route/--domain');
  }

  const resolvedWorkerName = pagesOnly
    ? undefined
    : workerName ?? env[profile.workerNameEnv] ?? profile.defaultWorkerName;
  const defaultRoutes = usesBuiltInWorker(profile, resolvedWorkerName)
    ? cloneValues(profile.defaultRoutes)
    : [];
  const defaultDomains = usesBuiltInWorker(profile, resolvedWorkerName)
    ? cloneValues(profile.defaultDomains)
    : [];

  return {
    profileName,
    dryRun,
    skipCloudflare,
    branch,
    pagesOnly,
    treeName: treeName ?? profile.treeName,
    workerName: resolvedWorkerName,
    pagesProject: pagesProject ?? env[profile.pagesProjectEnv],
    routes: routes.length > 0 ? routes : defaultRoutes,
    domains: domains.length > 0 ? domains : defaultDomains,
    workerCompatibilityDate:
      workerCompatibilityDate ?? env.CF_WORKER_COMPATIBILITY_DATE ?? defaultWorkerCompatibilityDate,
  };
}

export function createReleasePlan(options) {
  const profile = releaseProfiles[options.profileName];
  if (!profile) {
    throw new Error(`Unknown release profile: ${options.profileName}`);
  }

  return createSharedReleasePlan({
    appDir,
    options,
    profile,
    resolveHtreeCommand,
    wranglerVersion,
  });
}

export async function runRelease(options, runner = defaultRunner, hooks = {}) {
  const plan = createReleasePlan(options);
  return runReleasePlan(options, plan, runner, hooks);
}

export function usage() {
  return `Usage: node ./scripts/release-site.mjs <contacts> [options]

Build, test, publish to hashtree, and deploy to Cloudflare Workers Static Assets.

Options:
  --worker-name <name>    Cloudflare Worker service name for static assets
  --pages-project <name>  Cloudflare Pages project name
  --tree <name>           hashtree mutable tree name override
  --route <pattern>       Worker route, for example contacts.iris.to/*
  --domain <hostname>     Worker custom domain, for example contacts.iris.to
  --branch <name>         Pages branch/preview deployment target
  --pages-only            use Pages instead of the built-in Worker target
  --compatibility-date    Worker compatibility date override
  --skip-cloudflare       publish to hashtree only
  --dry-run               print planned steps without running them
`;
}

function printSummary(result) {
  if (result.dryRun) {
    console.log(`\n${result.profile.appName} release dry-run.`);
    for (const step of result.steps) {
      console.log(`${step.id}: ${step.command.join(' ')}`);
    }
    return;
  }

  const { profile, publish, workerName, routes, domains } = result;
  console.log(`\n${profile.appName} release complete.`);
  console.log(`Hashtree immutable URL: htree://${publish.nhash}/index.html`);
  console.log(`Hashtree mutable URL: htree://${publish.publishedRef}`);
  if (workerName) console.log(`Worker service: ${workerName}`);
  for (const route of routes ?? []) console.log(`Worker route: ${route}`);
  for (const domain of domains ?? []) console.log(`Worker custom domain: ${domain}`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
  } else {
    runRelease(options)
      .then(printSummary)
      .catch((error) => {
        console.error(error instanceof Error ? error.message : error);
        process.exit(1);
      });
  }
}
