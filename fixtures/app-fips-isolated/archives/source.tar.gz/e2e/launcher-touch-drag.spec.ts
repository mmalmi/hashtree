import { expect, test } from '@playwright/test';

test.use({
  hasTouch: true,
  viewport: { width: 390, height: 844 },
});

test('keeps a long-pressed launcher icon draggable through touch movement', async ({ page }) => {
  await page.addInitScript(() => window.localStorage.clear());
  await page.goto('/');
  await page.getByTestId('add-site-button').waitFor({ state: 'visible' });

  const appShells = page.locator('.suggestions .suggestion-shell:not(.add-site-shell)');
  const firstShell = appShells.nth(0);
  const secondShell = appShells.nth(1);
  const firstName = await firstShell.locator('.suggestion-name').textContent();
  const secondName = await secondShell.locator('.suggestion-name').textContent();
  const firstBox = await firstShell.boundingBox();
  const secondBox = await secondShell.boundingBox();
  expect(firstBox).not.toBeNull();
  expect(secondBox).not.toBeNull();

  const start = {
    x: firstBox!.x + firstBox!.width / 2,
    y: firstBox!.y + firstBox!.height / 2,
  };
  const target = {
    x: secondBox!.x + secondBox!.width / 2,
    y: secondBox!.y + secondBox!.height / 2,
  };

  const browserSession = await page.context().newCDPSession(page);
  await browserSession.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: start.x, y: start.y }],
  });
  await expect(page.getByRole('button', { name: 'Done' })).toBeVisible();

  await browserSession.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: target.x, y: target.y }],
  });
  await browserSession.send('Input.dispatchTouchEvent', {
    type: 'touchEnd',
    touchPoints: [],
  });

  await expect(appShells.nth(0).locator('.suggestion-name')).toHaveText(secondName ?? '');
  await expect(appShells.nth(1).locator('.suggestion-name')).toHaveText(firstName ?? '');
});
