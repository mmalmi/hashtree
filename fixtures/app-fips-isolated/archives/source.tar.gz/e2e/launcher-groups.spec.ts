import { expect, test } from '@playwright/test';

test('opens Groups from the app launcher', async ({ page }) => {
  await page.addInitScript(() => window.localStorage.clear());
  await page.context().route('https://groups.iris.to/**', (route) => route.fulfill({
    contentType: 'text/html',
    body: '<title>Iris Groups</title><h1>Groups</h1>',
  }));
  await page.goto('/');

  const groups = page.getByRole('link', { name: 'Groups', exact: true });
  await expect(groups).toBeVisible();
  await expect(groups).toHaveAttribute('href', 'https://groups.iris.to/');
  await expect.poll(() => groups.locator('img').evaluate((image: HTMLImageElement) => image.naturalWidth)).toBeGreaterThan(0);
  await page.screenshot({ path: test.info().outputPath('groups-launcher.png'), fullPage: true });

  const popupPromise = page.waitForEvent('popup');
  await groups.click();
  const popup = await popupPromise;
  await expect(popup).toHaveURL('https://groups.iris.to/');
  await expect(popup.getByRole('heading', { name: 'Groups' })).toBeVisible();
});
