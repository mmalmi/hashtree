import { expect, test, type Page } from '@playwright/test';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

async function createDistFixture(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), 'iris-sites-dist-'));
  await mkdir(join(root, 'icons'), { recursive: true });
  await mkdir(join(root, 'assets'), { recursive: true });
  await writeFile(join(root, 'index.html'), `
    <!doctype html>
    <html>
      <head>
        <title>HTML Fallback</title>
        <link rel="manifest" href="/manifest.webmanifest">
        <script type="module" src="/assets/app.js"></script>
      </head>
      <body><main id="app">Fixture App</main></body>
    </html>
  `);
  await writeFile(join(root, 'manifest.webmanifest'), JSON.stringify({
    name: 'Fixture App',
    short_name: 'Fixture',
    icons: [
      { src: 'icons/app.svg', sizes: '512x512', type: 'image/svg+xml' },
    ],
  }));
  await writeFile(join(root, 'icons', 'app.svg'), `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
      <rect width="64" height="64" rx="14" fill="#41d6c3"/>
      <path d="M16 34h32M32 16v32" stroke="#071014" stroke-width="8" stroke-linecap="round"/>
    </svg>
  `);
  await writeFile(join(root, 'assets', 'app.js'), 'document.body.dataset.fixtureApp = "ready";\n');
  return root;
}

async function mockBlossomUploads(page: Page): Promise<Array<{ bodyBytes: number; shaHeader: string }>> {
  const uploads: Array<{ bodyBytes: number; shaHeader: string }> = [];
  const blocks = new Map<string, Buffer>();
  await page.route('https://*/**', async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const blockHash = url.pathname.slice(1).replace(/\.bin$/i, '');

    if (request.method() === 'PUT' && url.pathname === '/upload') {
      const body = request.postDataBuffer() ?? Buffer.alloc(0);
      const shaHeader = await request.headerValue('x-sha-256') ?? '';
      uploads.push({ bodyBytes: body.length, shaHeader });
      if (/^[a-f0-9]{64}$/i.test(shaHeader)) {
        blocks.set(shaHeader.toLowerCase(), body);
      }
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ sha256: shaHeader, size: body.length }),
      });
      return;
    }

    if (/^[a-f0-9]{64}$/i.test(blockHash)) {
      const block = blocks.get(blockHash.toLowerCase());
      if (request.method() === 'HEAD') {
        await route.fulfill({
          status: block ? 200 : 404,
          headers: block
            ? {
                'content-length': String(block.length),
                'content-type': 'application/octet-stream',
              }
            : undefined,
        });
        return;
      }
      if (request.method() === 'GET' && block) {
        await route.fulfill({
          status: 200,
          contentType: 'application/octet-stream',
          body: block,
        });
        return;
      }
    }

    if (request.method() === 'HEAD') {
      await route.fulfill({ status: 404 });
      return;
    }

    await route.continue();
  });
  return uploads;
}

async function clearLauncherStorageOnce(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const clearKey = 'iris-sites:e2e-storage-cleared';
    if (window.sessionStorage.getItem(clearKey)) return;
    window.sessionStorage.setItem(clearKey, '1');
    window.localStorage.clear();
  });
}

async function waitForLauncherReady(page: Page): Promise<void> {
  await page.getByTestId('add-site-button').waitFor({ state: 'visible' });
  await page.waitForFunction(() => {
    return window.sessionStorage.getItem('iris-sites-test-sw-state') === 'ready';
  }, undefined, { timeout: 10_000 });
  await page.getByTestId('add-site-button').waitFor({ state: 'visible' });
}

test('previews dropped files from the launcher page', async ({ page }) => {
  await clearLauncherStorageOnce(page);
  await page.goto('/');
  await waitForLauncherReady(page);

  const dataTransfer = await page.evaluateHandle(() => {
    const transfer = new DataTransfer();
    transfer.items.add(new File(['<h1>Dropped App</h1>'], 'dropped.html', { type: 'text/html' }));
    return transfer;
  });

  await page.dispatchEvent('main', 'dragover', { dataTransfer });
  await page.dispatchEvent('main', 'drop', { dataTransfer });

  await expect(page.getByRole('dialog', { name: 'Add site' })).toBeVisible();
  await expect(page.getByTestId('site-upload-app-name')).toHaveValue('App');
  await expect(page.getByText('1 file')).toBeVisible();
  await expect(page.getByText('opens dropped.html')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Add by URL' })).toBeHidden();
  await expect(page.getByRole('button', { name: 'Upload folder' })).toBeHidden();
  await expect(page.getByRole('button', { name: 'Upload files' })).toBeHidden();
});

test('adds a dist folder as an immutable app shortcut', async ({ page }) => {
  const distDir = await createDistFixture();
  const uploads = await mockBlossomUploads(page);

  try {
    await clearLauncherStorageOnce(page);
    await page.goto('/');
    await waitForLauncherReady(page);

    await page.getByTestId('add-site-button').click();
    await page.getByTestId('site-upload-folder-input').setInputFiles(distDir);
    await expect(page.getByTestId('site-upload-app-name')).toHaveValue('Fixture App');
    await expect(page.getByTestId('site-upload-app-icon')).toBeVisible();
    await expect(page.getByText('4 files')).toBeVisible();
    await expect(page.getByText('opens index.html')).toBeVisible();

    await page.getByTestId('site-upload-confirm').click();

    await expect.poll(() => uploads.length).toBeGreaterThan(0);
    await page.waitForFunction(() => {
      const stored = window.localStorage.getItem('iris-sites:launcher-home:v1') ?? '';
      return stored.includes('"Fixture App"');
    });

    const appLink = page.getByRole('link', { name: 'Fixture App' });
    await expect(appLink).toBeVisible({ timeout: 10000 });
    await expect(page.getByRole('dialog', { name: 'Add site' })).toBeHidden();
    const href = await appLink.getAttribute('href');
    expect(href).toContain('nhash1');
    expect(href).toContain('/index.html');
    expect(uploads.every((upload) => upload.shaHeader.length === 64)).toBe(true);
    await expect(page.locator('.suggestions .suggestion-name').first()).toHaveText('Add');
    await expect(page.locator('.suggestions .suggestion-name').nth(1)).toHaveText('Fixture App');

    const stored = await page.evaluate(() => JSON.parse(
      window.localStorage.getItem('iris-sites:launcher-home:v1') ?? '{}',
    ));
    const customSuggestion = stored.customSuggestions?.find((suggestion: { name?: string }) =>
      suggestion.name === 'Fixture App'
    );
    expect(customSuggestion).toMatchObject({
      name: 'Fixture App',
      entryPath: 'index.html',
    });
    expect(customSuggestion?.nhash).toMatch(/^nhash1/);
    expect(customSuggestion?.icon).toMatch(/^data:image\/svg\+xml;base64,/);

    await appLink.click();
    await expect(page).toHaveURL(/127\.0\.0\.1:\d+\/#\/nhash1.+\/index\.html/);
    await expect(page.frameLocator('iframe').getByText('Fixture App')).toBeVisible({
      timeout: 15000,
    });
  } finally {
    await rm(distDir, { recursive: true, force: true });
  }
});
