# Changelog

## 0.1.17 - 2026-11-04

- Reduce repeat transfers when peers catch up on public feeds.

## 0.1.16 - 2026-11-04

- Keep searches and the posts and profiles you open off peer connections. Public posts you publish can still reach peers.

## 0.1.15 - 2026-11-03

- Read legacy and versioned Hashtree objects and preserve existing sharing links across edits.
- Keep saved places and list pages readable when updating a map that uses randomized encryption.

## 0.1.14 - 2026-10-04

- Recover file-sharing connections after a browser reload or temporary route failure.
- Preserve verified cached files for sharing and offline use after restarting the app.

## 0.1.13 - 2026-10-02

- Keep viewed map tiles, styles, and sprites in the existing Hashtree cache for offline use.
- Load the bundled basemap from one verified immutable revision, preserving custom dataset and gateway settings.

## 0.1.12 - 2026-10-01

- Keep peer connections and transfers working when a delayed connection offer arrives.
- Update shared contact and trust data handling.

## 0.1.11 - 2026-10-01

- Update shared peer networking to recover cleanly from rejected handshakes, malformed packets, route failures, and transport restarts.
- Use corrected routing filters, bounded route retries, and native-compatible link feedback to reduce unnecessary background traffic.

## 0.1.10 - 2026-09-30

- Recover peer connection answers after temporary route failures with the updated shared networking runtime.
- Preserve existing accounts and offline data while updating the immutable file transport.

## 0.1.9 - 2026-09-30

- Use paths with enough capacity for peer connection messages and recover authenticated peer connections sooner.
- Update shared event and file networking without changing saved accounts or offline data.
- Finish background-worker startup after a recoverable crash so peer connections restart on reload.

## 0.1.8 - 2026-09-30

- Keep subscription batches within public message server limits.

## 0.1.7 - 2026-09-30

- Restore the app and existing account when reopening offline.
- Use the shared event runtime fixes for complete history and prompt event lookups.

## 0.1.6 - 2026-09-30

- Replace NDK with the shared Nostr Pubsub runtime and persistent Hashtree event indexes.
- Share one browser peer node for events and cached files, preserving saved accounts and offline publication.

## 0.1.5 - 2026-09-07

- Upgrade to Hashtree runtime 0.5.7, which validates remote content hashes and
  sizes before returning or caching data.
- Run portable build configuration tests once per release, within the unit suite.

## 0.1.4 - 2026-07-20

- Upgrade to FIPS TypeScript 0.0.29 and Hashtree FIPS transport 0.4.6 for
  direct FSP negotiation with legacy FMP fallback and authenticated WebSocket
  bootstrap before WebRTC link negotiation.

## 0.1.3 - 2026-07-16

- Pin the browser stack to immutable FIPS, Hashtree 0.4.3, Iris Kit, and
  social-graph releases; remove vendored archives and workspace build coupling.
- Keep the standalone runtime serve/connect-only while explicit blob routes use
  HTL 10 and preserve transport failures as errors.
- Replay external provider state across worker replacement and remove legacy
  WebRTC proxy assumptions.
- Reuse shared profile protocol types and simplify Maps URL/search integration.
- Update DOMPurify, Happy DOM, and Vite to versions with a clean OSV lock scan.
