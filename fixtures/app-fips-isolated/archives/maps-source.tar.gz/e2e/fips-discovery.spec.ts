import { startLocalFipsWebSocketSeed, type LocalFipsWebSocketSeed } from './fixtures/localFipsWebSocketSeed';
import { WebSocketServer, type WebSocket } from 'ws';
import { expect, test } from '@playwright/test';
import { identityFromSecretKey, toHex } from '@fips/core';
import { getPublicKey, nip19 } from 'nostr-tools';
import { ensureLoggedIn, evaluateWithRetry, waitForAppReady } from './test-utils';

async function fipsLinkState(page: import('@playwright/test').Page): Promise<{
  localPeerId: string;
  connectedPeerIds: string[];
}> {
  return page.evaluate(async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const stats = getDriveFipsRuntime()?.getStats();
    return { localPeerId: stats?.localPeerId ?? '', connectedPeerIds: stats?.connectedPeerIds ?? [] };
  });
}

type FipsReloadProof = {
  reloadedEndpoint: 'first' | 'second';
  localPeerId: string;
  otherPeerId: string;
  identityRetained: boolean;
  bothConnected: boolean;
  receiverCachedBefore: boolean;
  blockHash: string;
  verifiedBytes: number;
};

async function workerHasLocalBlock(page: import('@playwright/test').Page, hashHex: string): Promise<boolean> {
  return page.evaluate(async (hex) => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => { has(hash: Uint8Array): Promise<boolean> } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');
    return adapter.has(Uint8Array.from(hex.match(/../g) ?? [], (byte) => Number.parseInt(byte, 16)));
  }, hashHex);
}

async function captureReloadProof(
  reloaded: import('@playwright/test').Page,
  other: import('@playwright/test').Page,
  localPeerId: string,
  otherPeerId: string,
  reloadedEndpoint: 'first' | 'second',
  blockHash: string,
  verifiedBytes: number,
  receiverCachedBefore: boolean,
): Promise<FipsReloadProof> {
  const [localState, otherState] = await Promise.all([fipsLinkState(reloaded), fipsLinkState(other)]);
  const proof = {
    reloadedEndpoint, localPeerId: localState.localPeerId, otherPeerId: otherState.localPeerId,
    identityRetained: localState.localPeerId === localPeerId && otherState.localPeerId === otherPeerId,
    bothConnected: localState.connectedPeerIds.includes(otherPeerId)
      && otherState.connectedPeerIds.includes(localPeerId),
    receiverCachedBefore, blockHash, verifiedBytes,
  };
  expect(proof.identityRetained).toBe(true);
  expect(proof.bothConnected).toBe(true);
  expect(proof.receiverCachedBefore).toBe(false);
  return proof;
}

async function proveReloadedFipsPeer(
  reloaded: import('@playwright/test').Page,
  other: import('@playwright/test').Page,
  localPeerId: string,
  otherPeerId: string,
  reloadedEndpoint: 'first' | 'second',
): Promise<FipsReloadProof> {
  return test.step(`recover ${reloadedEndpoint} browser and transfer a fresh peer block`, async () => {
    await reloaded.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 });
    await waitForAppReady(reloaded, 30_000);
    await expect.poll(async () => Promise.all(
      [reloaded, other].map(async candidate => (await fipsLinkState(candidate)).localPeerId),
    ), { timeout: 30_000 }).toEqual([localPeerId, otherPeerId]);
    await expect.poll(async () => {
      const [localState, otherState] = await Promise.all([fipsLinkState(reloaded), fipsLinkState(other)]);
      return [localState.connectedPeerIds.includes(otherPeerId), otherState.connectedPeerIds.includes(localPeerId)];
    }, { timeout: 30_000 }).toEqual([true, true]);

    // This nonce is created only after this endpoint has reloaded and reconnected.
    // Fetch directly through the app's FIPS provider, never its HTTP read path.
    const source = await reloaded.evaluate(async () => {
      const adapter = (window as typeof window & {
        __getWorkerAdapter?: () => {
          put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
          webrtcProxy?: unknown;
        } | null;
      }).__getWorkerAdapter?.();
      if (!adapter) throw new Error('worker adapter is not ready');
      const data = new TextEncoder().encode(`fips-reload-block-${crypto.randomUUID()}`);
      const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
      const bytes = data.byteLength; // Worker storage transfers this buffer.
      if (!await adapter.put(hash, data)) throw new Error('failed to store fresh peer block');
      return {
        hashHex: Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join(''),
        bytes, legacyProxyActive: adapter.webrtcProxy != null,
      };
    });
    expect(source.legacyProxyActive).toBe(false);
    const receiverCachedBefore = await workerHasLocalBlock(other, source.hashHex);
    expect(receiverCachedBefore).toBe(false);
    await expect.poll(() => other.evaluate(async ({ hashHex, peerId }) => {
      const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
      const runtime = getDriveFipsRuntime();
      if (!runtime) throw new Error('FIPS provider bridge is not ready');
      const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
      if (!data) return null;
      const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new Uint8Array(data).buffer));
      const receivedHash = Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('');
      return { hashMatches: receivedHash === hashHex, bytes: data.byteLength };
    }, { hashHex: source.hashHex, peerId: localPeerId }), { timeout: 30_000 })
      .toEqual({ hashMatches: true, bytes: source.bytes });
    return captureReloadProof(reloaded, other, localPeerId, otherPeerId,
      reloadedEndpoint, source.hashHex, source.bytes, receiverCachedBefore);
  }, { timeout: 180_000 });
}

async function retainReloadProof(proofs: FipsReloadProof[]): Promise<void> {
  expect(proofs.map(proof => proof.reloadedEndpoint)).toEqual(['first', 'second']);
  expect(proofs[0].localPeerId).toBe(proofs[1].otherPeerId);
  expect(proofs[1].localPeerId).toBe(proofs[0].otherPeerId);
  expect(proofs[0].localPeerId).not.toBe(proofs[1].localPeerId);
  expect(proofs[0].blockHash).not.toBe(proofs[1].blockHash);
  // Only public endpoint identities, status booleans, hashes and sizes are retained.
  console.log('FIPS_BROWSER_RELOAD_PROOF', JSON.stringify(proofs));
  await test.info().attach('fips-browser-reload-proof.json', {
    body: JSON.stringify(proofs, null, 2), contentType: 'application/json',
  });
}

type NostrEvent = {
  id: string;
  pubkey: string;
  kind: number;
  tags: string[][];
};

let relay: WebSocketServer;
let relayUrl = '';
let seed: LocalFipsWebSocketSeed;
const publishedEvents: NostrEvent[] = [];
const subscriptions = new Map<WebSocket, Map<string, Record<string, unknown>[]>>();
const FIRST_FIPS_SECRET_HEX = `${'00'.repeat(31)}01`;
const SECOND_FIPS_SECRET_HEX = `${'00'.repeat(31)}02`;
const SWITCHED_NOSTR_SECRET = Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 3 : 0);

async function seedFipsDeviceIdentity(page: import('@playwright/test').Page, secretKeyHex: string): Promise<void> {
  // Seed storage without starting the app or the child-webview fixture's
  // timed history navigation, which can abort the next page.goto().
  await page.route('**/fips-identity-fixture.html', route => route.fulfill({
    contentType: 'text/html',
    body: '<!doctype html><title>FIPS identity fixture</title>',
  }));
  await page.goto('/fips-identity-fixture.html');
  await page.evaluate(async (secret) => {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('fips', 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains('fips-identity')) {
          request.result.createObjectStore('fips-identity');
        }
      };
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction('fips-identity', 'readwrite');
        transaction.objectStore('fips-identity').put({ secretKeyHex: secret }, 'default');
        transaction.oncomplete = () => {
          db.close();
          resolve();
        };
        transaction.onerror = () => reject(transaction.error);
      };
    });
  }, secretKeyHex);
}

async function readBrowserIdentities(page: import('@playwright/test').Page): Promise<{
  fipsPeerId: string;
  nostrPubkey: string;
}> {
  return evaluateWithRetry(page, async () => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const nostrStore = (window as typeof window & {
      __nostrStore?: { getState?: () => { pubkey?: string } };
    }).__nostrStore;
    return {
      fipsPeerId: getDriveFipsRuntime()?.getStats().localPeerId ?? '',
      nostrPubkey: nostrStore?.getState?.().pubkey ?? '',
    };
  }, undefined);
}

function matchesFilter(event: NostrEvent, filter: Record<string, unknown>): boolean {
  const kinds = Array.isArray(filter.kinds) ? filter.kinds : [];
  if (kinds.length > 0 && !kinds.includes(event.kind)) return false;
  for (const [key, expected] of Object.entries(filter)) {
    if (!key.startsWith('#') || !Array.isArray(expected)) continue;
    const tagName = key.slice(1);
    if (!event.tags.some((tag) => tag[0] === tagName && expected.includes(tag[1]))) {
      return false;
    }
  }
  return true;
}
function send(socket: WebSocket, message: unknown): void {
  if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(message));
}

function publishToSubscriptions(event: NostrEvent): void {
  for (const [socket, socketSubscriptions] of subscriptions) {
    for (const [subscriptionId, filters] of socketSubscriptions) {
      if (filters.some((filter) => matchesFilter(event, filter))) {
        send(socket, ['EVENT', subscriptionId, event]);
      }
    }
  }
}

test.beforeAll(async () => {
  seed = await startLocalFipsWebSocketSeed();
  relay = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise<void>((resolve) => relay.once('listening', resolve));
  const address = relay.address();
  if (!address || typeof address === 'string') throw new Error('expected a TCP relay address');
  relayUrl = `ws://127.0.0.1:${address.port}`;

  relay.on('connection', (socket) => {
    subscriptions.set(socket, new Map());
    socket.on('message', (raw) => {
      const message = JSON.parse(raw.toString()) as unknown[];
      if (message[0] === 'EVENT') {
        const event = message[1] as NostrEvent;
        publishedEvents.push(event);
        publishToSubscriptions(event);
        send(socket, ['OK', event.id, true, '']);
        return;
      }
      if (message[0] === 'REQ') {
        const subscriptionId = `${message[1]}`;
        const filters = message.slice(2) as Record<string, unknown>[];
        subscriptions.get(socket)?.set(subscriptionId, filters);
        for (const event of publishedEvents) {
          if (filters.some((filter) => matchesFilter(event, filter))) {
            send(socket, ['EVENT', subscriptionId, event]);
          }
        }
        send(socket, ['EOSE', subscriptionId]);
        return;
      }
      if (message[0] === 'CLOSE') subscriptions.get(socket)?.delete(`${message[1]}`);
    });
    socket.on('close', () => subscriptions.delete(socket));
  });
});

test.afterAll(async () => {
  await seed.close();
  for (const socket of relay.clients) socket.terminate();
  await new Promise<void>((resolve) => relay.close(() => resolve()));
});

test('two Maps browsers discover FIPS peers and explicitly exchange blocks', async ({ browser, page }) => {
  test.slow();
  test.setTimeout(test.info().timeout + 2 * 180_000); // Budget only the added reload phases.
  publishedEvents.length = 0;
  await page.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  await seedFipsDeviceIdentity(page, FIRST_FIPS_SECRET_HEX);
  await page.goto('/maps.html#/');
  await waitForAppReady(page);
  await ensureLoggedIn(page, 30_000);

  const expectedFirstPeerId = toHex((await identityFromSecretKey(
    Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 1 : 0),
  )).publicKey);
  await expect.poll(async () => (await readBrowserIdentities(page)).fipsPeerId, {
    timeout: 30_000,
  }).toBe(expectedFirstPeerId);
  const beforeAccountSwitch = await readBrowserIdentities(page);
  const switchedNsec = nip19.nsecEncode(SWITCHED_NOSTR_SECRET);
  const switchedNostrPubkey = getPublicKey(SWITCHED_NOSTR_SECRET);
  expect(await page.evaluate(async (nsec) => {
    const { loginWithNsec } = await import('/src/nostr/auth.ts');
    return loginWithNsec(nsec);
  }, switchedNsec)).toBe(true);
  await expect.poll(async () => (await readBrowserIdentities(page)).nostrPubkey).toBe(switchedNostrPubkey);
  expect((await readBrowserIdentities(page)).fipsPeerId).toBe(beforeAccountSwitch.fipsPeerId);

  await page.reload({ waitUntil: 'commit' });
  await waitForAppReady(page);
  await expect.poll(async () => readBrowserIdentities(page), { timeout: 30_000 }).toEqual({
    fipsPeerId: expectedFirstPeerId,
    nostrPubkey: switchedNostrPubkey,
  });

  await expect.poll(() => publishedEvents.find((event) => event.kind === 37_195), {
    timeout: 60_000,
  }).toBeTruthy();
  const firstAdvert = publishedEvents.find((event) => event.kind === 37_195);
  const firstBrowserAdvertisers = new Set(
    publishedEvents.filter((event) => event.kind === 37_195).map((event) => event.pubkey),
  );
  expect(firstAdvert?.tags).toContainEqual(['d', 'fips-overlay-v1']);
  expect(firstAdvert?.tags).toContainEqual(['protocol', 'fips-overlay-v1']);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const secondContext = await browser.newContext();
  await secondContext.addInitScript(({ url, seedUrl }) => {
    window.__testRelayUrl = url;
    window.__testFipsWebsocketSeedUrls = [seedUrl];
  }, { url: relayUrl, seedUrl: seed.url });
  const secondPage = await secondContext.newPage();
  await seedFipsDeviceIdentity(secondPage, SECOND_FIPS_SECRET_HEX);
  await secondPage.goto('/maps.html#/');
  await waitForAppReady(secondPage);
  await ensureLoggedIn(secondPage, 30_000);

  const expectedSecondPeerId = toHex((await identityFromSecretKey(
    Uint8Array.from({ length: 32 }, (_, index) => index === 31 ? 2 : 0),
  )).publicKey);
  await expect.poll(async () => (await readBrowserIdentities(secondPage)).fipsPeerId, {
    timeout: 30_000,
  }).toBe(expectedSecondPeerId);
  expect(expectedSecondPeerId).not.toBe(expectedFirstPeerId);

  await expect.poll(() => publishedEvents.some((event) => (
    event.kind === 37_195 && !firstBrowserAdvertisers.has(event.pubkey)
  )), { timeout: 60_000 }).toBe(true);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  await expect.poll(async () => Promise.all([
    [page, expectedSecondPeerId],
    [secondPage, expectedFirstPeerId],
  ].map(async ([candidate, expectedPeerId]) => (
    (candidate as import('@playwright/test').Page).evaluate(async (peerId) => {
      const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
      return getDriveFipsRuntime()?.getStats().connectedPeerIds.includes(peerId) ?? false;
    }, expectedPeerId as string).catch(() => false)
  ))), { timeout: 30_000 }).toEqual([true, true]);

  const source = await page.evaluate(async () => {
    const adapter = (window as typeof window & {
      __getWorkerAdapter?: () => {
        put(hash: Uint8Array, data: Uint8Array): Promise<boolean>;
        webrtcProxy?: unknown;
      } | null;
    }).__getWorkerAdapter?.();
    if (!adapter) throw new Error('worker adapter is not ready');
    const text = `maps-fips-block-${crypto.randomUUID()}`;
    const data = new TextEncoder().encode(text);
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
    await adapter.put(hash, data);
    return {
      hashHex: Array.from(hash, (byte) => byte.toString(16).padStart(2, '0')).join(''),
      text,
      legacyProxyActive: adapter.webrtcProxy != null,
    };
  });
  expect(source.legacyProxyActive).toBe(false);

  const received = await secondPage.evaluate(async ({ hashHex, peerId }) => {
    const { getDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    const runtime = getDriveFipsRuntime();
    if (!runtime) throw new Error('FIPS runtime is not ready');
    const data = await runtime.getP2PProvider().fetch(hashHex, peerId, 10);
    return data ? new TextDecoder().decode(data) : null;
  }, { hashHex: source.hashHex, peerId: expectedFirstPeerId });
  expect(received).toBe(source.text);
  expect(await secondPage.evaluate(() => (
    (window as typeof window & {
      __getWorkerAdapter?: () => { webrtcProxy?: unknown } | null;
    }).__getWorkerAdapter?.()?.webrtcProxy != null
  ))).toBe(false);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  const proofs = [
    await proveReloadedFipsPeer(page, secondPage, expectedFirstPeerId, expectedSecondPeerId, 'first'),
    await proveReloadedFipsPeer(secondPage, page, expectedSecondPeerId, expectedFirstPeerId, 'second'),
  ];
  await retainReloadProof(proofs);
  expect(publishedEvents.some((event) => event.kind === 25_050)).toBe(false);

  await secondContext.close();
});

declare global {
  interface Window {
    __testRelayUrl?: string;
  }
}
