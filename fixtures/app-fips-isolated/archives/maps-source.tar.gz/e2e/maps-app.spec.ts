import { test, expect } from './fixtures';
import type { Page } from '@playwright/test';
import { setupPageErrorHandler, waitForAppReady, disableOthersPool } from './test-utils';

/**
 * Tests for maps.iris.to (Iris Maps app)
 * Tests map loading, tile rendering, and basic navigation
 */
test.describe('Iris Maps App', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  async function openAddPlaceFromContextMenu(page: Page) {
    const mapCanvas = page.locator('.maplibregl-canvas');
    await expect(mapCanvas).toBeVisible({ timeout: 30000 });
    const box = await mapCanvas.boundingBox();
    expect(box).not.toBeNull();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2, { button: 'right' });
    await page.getByTestId('map-context-add-place').click();
  }

  async function readMapCamera(page: Page): Promise<{ lat: number; lng: number; zoom: number }> {
    return page.evaluate(() => {
      const map = (window as typeof window & {
        __irisMap?: {
          getCenter?: () => { lat: number; lng: number };
          getZoom?: () => number;
        };
      }).__irisMap;
      if (!map?.getCenter || !map.getZoom) {
        throw new Error('Iris map test hook is not available');
      }
      const center = map.getCenter();
      return {
        lat: center.lat,
        lng: center.lng,
        zoom: map.getZoom(),
      };
    });
  }

  async function waitForLoadedMannerheimintieDetails(page: Page) {
    await page.waitForFunction(() => {
      const map = (window as typeof window & {
        __irisMap?: {
          isStyleLoaded?: () => boolean;
          querySourceFeatures?: (sourceId: string, options: { sourceLayer: string; validate?: boolean }) => Array<{ properties?: Record<string, unknown> }>;
        };
      }).__irisMap;
      if (!map?.isStyleLoaded?.() || !map.querySourceFeatures) return false;
      try {
        const streets = map.querySourceFeatures('openmaptiles', { sourceLayer: 'transportation_name', validate: false });
        const houses = map.querySourceFeatures('openmaptiles', { sourceLayer: 'housenumber', validate: false });
        const hasStreet = streets.some((feature) => Object.values(feature.properties ?? {})
          .some((value) => typeof value === 'string' && value.includes('Mannerheimintie')));
        const hasHouse5 = houses.some((feature) => {
          const properties = feature.properties ?? {};
          const value = properties.housenumber
            ?? properties.house_number
            ?? properties['addr:housenumber']
            ?? properties.number;
          return String(value ?? '').trim() === '5';
        });
        return hasStreet && hasHouse5;
      } catch {
        return false;
      }
    }, undefined, { timeout: 45000 });
  }

  test('shows Maps header on app routes outside the fullscreen map', async ({ page }) => {
    await page.goto('/maps.html#/settings');
    await expect(page.locator('header').getByRole('link', { name: /^maps$/i })).toBeVisible({ timeout: 30000 });
  });

  test('shows map container with MapLibre', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    await expect(page.getByTestId('map-surface')).toBeVisible({ timeout: 30000 });
    await expect(page.locator('.maplibregl-map')).toBeVisible({ timeout: 30000 });
  });

  test('map has locate and zoom controls', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    const locateControl = page.getByTestId('map-locate-control');
    await expect(locateControl).toBeVisible({ timeout: 30000 });
    await expect(locateControl.locator('.i-lucide-locate-fixed')).toBeVisible();
    await expect(page.locator('.maplibregl-ctrl-zoom-in')).toBeVisible({ timeout: 30000 });
    await expect(page.locator('.maplibregl-ctrl-zoom-out')).toBeVisible({ timeout: 30000 });
  });

  test('locate control requests browser location and centers the map', async ({ page, context }) => {
    const target = { latitude: 60.1699, longitude: 24.9384, accuracy: 40 };
    await context.grantPermissions(['geolocation']);
    await context.setGeolocation(target);
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [0, 0], zoom: 1 }));
    });

    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    await page.getByTestId('map-locate-control').click();
    await page.waitForFunction(
      ({ latitude, longitude }) => {
        const map = (window as typeof window & {
          __irisMap?: {
            getCenter?: () => { lat: number; lng: number };
          };
        }).__irisMap;
        if (!map?.getCenter) return false;
        const center = map.getCenter();
        return Math.abs(center.lat - latitude) < 0.001 && Math.abs(center.lng - longitude) < 0.001;
      },
      target,
      { timeout: 15000 }
    );

    const camera = await readMapCamera(page);
    expect(Math.abs(camera.lat - target.latitude)).toBeLessThan(0.0015);
    expect(Math.abs(camera.lng - target.longitude)).toBeLessThan(0.0015);
    expect(camera.zoom).toBeGreaterThanOrEqual(15);
  });

  test('can open Add Place modal from the map context menu', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    await openAddPlaceFromContextMenu(page);

    await expect(page.getByRole('heading', { name: 'Add Place' })).toBeVisible({ timeout: 10000 });
    await expect(page.locator('input[placeholder="Place name..."]')).toBeVisible();
    await expect(page.locator('#place-category')).toBeVisible();
  });

  test('can add a place and see marker on map', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    await openAddPlaceFromContextMenu(page);

    await expect(page.getByRole('heading', { name: 'Add Place' })).toBeVisible({ timeout: 10000 });

    const placeName = `Test Place ${Date.now()}`;
    await page.locator('input[placeholder="Place name..."]').fill(placeName);
    await page.locator('#place-category').selectOption('restaurant');
    await expect(page.locator('text=Location:')).toBeVisible({ timeout: 5000 });

    await page.getByRole('button', { name: 'Save' }).click();

    await expect(page.getByRole('heading', { name: 'Add Place' })).not.toBeVisible({ timeout: 10000 });
    await expect(page.locator('.iris-map-place-marker')).toBeVisible({ timeout: 10000 });
  });

  test('shows search input', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    // Should show search input
    await expect(page.locator('[data-testid="search-input"]')).toBeVisible({ timeout: 30000 });
  });

  test('opens a saved list view from the library row', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    await page.getByRole('button', { name: 'Open library' }).click();
    await expect(page.getByTestId('maps-library-panel')).toBeVisible({ timeout: 10000 });

    await page.getByTestId('library-list-favorites').click();

    await expect(page.getByTestId('saved-place-list-route-panel')).toBeVisible({ timeout: 10000 });
    await expect(page.getByTestId('maps-library-panel')).not.toBeVisible();
    await expect(page.getByRole('heading', { name: 'Favorites' })).toBeVisible();
  });

  test('minimizes an open left panel on mobile without closing it', async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    await page.getByRole('button', { name: 'Open library' }).click();
    const libraryPanel = page.getByTestId('maps-library-panel');
    await expect(libraryPanel).toBeVisible({ timeout: 10000 });

    await page.getByTestId('left-panel-minimize').click();
    await expect(libraryPanel).not.toBeVisible();
    const restoreButton = page.getByTestId('left-panel-restore');
    await expect(restoreButton).toBeVisible();
    await expect(restoreButton).toContainText('Library');
    await expect(page.getByTestId('map-surface')).toBeVisible();

    await restoreButton.click();
    await expect(libraryPanel).toBeVisible();
    await expect(restoreButton).not.toBeVisible();
  });

  test('search shows results dropdown', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    // Type a search query
    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('London');

    // Wait for search results to appear
    await expect(page.locator('[data-testid="search-results"]')).toBeVisible({ timeout: 10000 });

    // Should have at least one result
    await expect(page.locator('[data-testid="search-results"] button').first()).toBeVisible();
  });

  test('search suggests Stockholm for stockh', async ({ page }) => {
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [59.325, 18.07], zoom: 10 }));
    });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('stockh');

    await expect(page.locator('[data-testid="search-results"]')).toBeVisible({ timeout: 10000 });
    await expect(
      page.locator('[data-testid="search-results"] button', { hasText: 'Stockholm' }).first()
    ).toBeVisible({ timeout: 10000 });
  });

  for (const action of ['clear', 'escape', 'navigate'] as const) {
    test(`cancels a queued search on ${action}`, async ({ page }) => {
      await page.goto('/maps.html#/');
      await waitForAppReady(page);
      const clockStart = Date.now();
      await page.clock.install({ time: clockStart });
      await page.clock.pauseAt(clockStart + 10_000);
      await page.getByTestId('search-input').fill('London');
      if (action === 'clear') await page.getByRole('button', { name: 'Clear search', exact: true }).click();
      else if (action === 'escape') await page.getByTestId('search-input').press('Escape');
      else await page.evaluate(() => { window.location.hash = '#/settings'; });
      if (action === 'navigate') await expect(page.getByTestId('search-input')).not.toBeAttached();
      await page.clock.runFor(350);
      const state = await page.evaluate(async () => {
        const { mapsStore } = await import('/src/stores/mapsStore.svelte.ts');
        return { query: mapsStore.searchQuery, searching: mapsStore.isSearching, count: mapsStore.searchResults.length };
      });
      expect(state).toEqual({ query: '', searching: false, count: 0 });
      await expect(page.getByTestId('search-results')).not.toBeVisible();
    });
  }

  test('search replaces an active place and opens results', async ({ page }) => {
    test.slow();
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [59.325, 18.07], zoom: 10 }));
    });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('Helsinki');
    const results = page.locator('[data-testid="search-results"]');
    await expect(results).toBeVisible({ timeout: 15000 });
    await results.locator('button', { hasText: 'Helsinki' }).first().click();
    await expect(page.getByTestId('active-place-panel')).toContainText('Helsinki', { timeout: 10000 });

    await searchInput.click();
    await searchInput.evaluate((input: HTMLInputElement) => {
      input.value = `${input.value}stockh`;
      input.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        data: 'stockh',
        inputType: 'insertText',
      }));
    });
    await expect(searchInput).toHaveValue('stockh');
    await expect(results).toBeVisible({ timeout: 15000 });
    const stockholmResult = results.locator('button', { hasText: 'Stockholm' }).first();
    await expect(stockholmResult).toBeVisible({ timeout: 15000 });
    await expect.poll(async () => stockholmResult.evaluate((node) => {
      const rect = node.getBoundingClientRect();
      const topElement = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
      return Boolean(topElement?.closest('[data-testid="search-results"]'));
    }), { timeout: 5000 }).toBe(true);
  });

  test('search suggests visible z14 street address details', async ({ page }) => {
    test.slow();
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [60.1695, 24.9384], zoom: 17 }));
    });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);
    await page.evaluate(() => {
      const map = (window as typeof window & {
        __irisMap?: {
          jumpTo?: (options: { center: [number, number]; zoom: number }) => void;
        };
      }).__irisMap;
      map?.jumpTo?.({ center: [24.9384, 60.1695], zoom: 17 });
    });
    try {
      await waitForLoadedMannerheimintieDetails(page);
    } catch (error) {
      console.error('Address map state', await page.evaluate(() => {
        const map = (window as any).__irisMap;
        const features = (layer: string) => map?.querySourceFeatures('openmaptiles', { sourceLayer: layer, validate: false }).map((feature: any) => feature.properties);
        return { loaded: map?.isStyleLoaded(), center: map?.getCenter(), zoom: map?.getZoom(), sources: map?.getStyle()?.sources, streets: features('transportation_name'), houses: features('housenumber') };
      }));
      throw error;
    }

    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('5 mannerh');

    const results = page.locator('[data-testid="search-results"]');
    await expect(results).toBeVisible({ timeout: 15000 });
    await expect(
      results.locator('button', { hasText: 'Mannerheimintie 5' }).first()
    ).toBeVisible({ timeout: 15000 });

    await searchInput.fill('987654 mannerh');
    await page.waitForTimeout(1200);
    await expect(
      results.locator('button', { hasText: 'Mannerheimintie 987654' })
    ).toHaveCount(0);
  });

  test('short query completion suggests Rovaniemi', async ({ page }) => {
    test.slow();
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [59.325, 18.07], zoom: 10 }));
    });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('rovani');

    const results = page.locator('[data-testid="search-results"]');
    await expect(results).toBeVisible({ timeout: 15000 });
    await expect(
      page.locator('[data-testid="search-results"] button', { hasText: 'Rovaniemi' }).first()
    ).toBeVisible({ timeout: 15000 });
  });

  test('global queries surface major places from far away', async ({ page }) => {
    test.slow();
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [66.503, 25.729], zoom: 8 }));
    });
    await page.goto('/maps.html#/');
    await waitForAppReady(page);
    await disableOthersPool(page);

    const searchInput = page.locator('[data-testid="search-input"]');
    await searchInput.fill('caracas');

    const results = page.locator('[data-testid="search-results"]');
    await expect(results).toBeVisible({ timeout: 20000 });
    await expect(
      page.locator('[data-testid="search-results"] button', { hasText: 'Caracas' }).first()
    ).toBeVisible({ timeout: 20000 });

    await searchInput.fill('laos');
    await expect(results).toBeVisible({ timeout: 20000 });
    await expect(
      page.locator('[data-testid="search-results"] button', { hasText: 'Laos' }).first()
    ).toBeVisible({ timeout: 20000 });
  });

  test('map position persists after reload', async ({ page }) => {
    await page.goto('/maps.html#/');
    await waitForAppReady(page);

    await expect(page.getByTestId('map-surface')).toBeVisible({ timeout: 30000 });

    const initialZoom = await page.evaluate(() => {
      const map = (window as typeof window & { __irisMap?: { getZoom?: () => number } }).__irisMap;
      return map?.getZoom?.() ?? 0;
    });
    await page.evaluate(() => {
      const map = (window as typeof window & { __irisMap?: { zoomIn?: (options?: { duration?: number }) => void } }).__irisMap;
      map?.zoomIn?.({ duration: 0 });
    });
    await page.waitForFunction((previousZoom) => {
      const stored = localStorage.getItem('iris-maps-view');
      if (!stored) return false;
      try {
        const zoom = JSON.parse(stored).zoom;
        return typeof zoom === 'number' && zoom > previousZoom;
      } catch {
        return false;
      }
    }, initialZoom);

    // Get current zoom level from localStorage
    const savedView = await page.evaluate(() => {
      return localStorage.getItem('iris-maps-view');
    });
    expect(savedView).toBeTruthy();
    const parsedView = JSON.parse(savedView!);
    expect(parsedView.zoom).toBeGreaterThan(initialZoom);

    // Reload the page
    await page.reload();
    await waitForAppReady(page);
    await expect(page.getByTestId('map-surface')).toBeVisible({ timeout: 30000 });

    // Check that the zoom level was restored
    const restoredView = await page.evaluate(() => {
      return localStorage.getItem('iris-maps-view');
    });
    const parsedRestored = JSON.parse(restoredView!);
    expect(parsedRestored.zoom).toBe(parsedView.zoom);
  });
});
