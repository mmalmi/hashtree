import { test, expect } from './fixtures';
import {
  evaluateWithRetry,
  setupPageErrorHandler,
  waitForOptionalWorkerAdapter,
} from './test-utils/core';

async function ensureLoggedIn(page: any) {
  const profileBtn = page.locator('button[title="My Profile (double-click for users)"]');
  if (!(await profileBtn.isVisible().catch(() => false))) {
    await page.goto('/maps.html#/settings');
  }
  await page.waitForSelector('button[title="My Profile (double-click for users)"], button:has-text("New")', { timeout: 15000 });
  if (await profileBtn.isVisible().catch(() => false)) {
    await page.goto('/maps.html#/');
    return;
  }
  const newButton = page.getByRole('button', { name: 'New' });
  await newButton.click();
  await expect(profileBtn).toBeVisible({ timeout: 15000 });
  await page.goto('/maps.html#/');
}

async function disableOthersPool(page: any) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await expect(page.getByTestId('search-input')).toBeVisible({ timeout: 60000 });
  await waitForOptionalWorkerAdapter(page);
  await evaluateWithRetry(page, async () => {
    const win = window as any;
    let adapter = win.__getWorkerAdapter?.();
    if (!adapter) {
      const { getWorkerAdapter } = await import('/src/workerAdapter.ts');
      adapter = getWorkerAdapter();
    }
    const { stopDriveFipsRuntime } = await import('/src/lib/driveFipsRuntime.ts');
    await stopDriveFipsRuntime();
    adapter?.setP2PProvider?.(null);
  }, undefined);
}

async function visibleLabelPoint(page: any, labelName: string): Promise<{ x: number; y: number } | null> {
  return page.evaluate(async (name: string) => {
    const target = window as typeof window & { __irisMap?: any };
    const map = target.__irisMap;
    if (!map) return null;

    const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
    const layers = [
      'label_city',
      'label_city_capital',
      'label_town',
      'label_village',
      'label_country_1',
      'label_country_2',
      'label_country_3',
    ];

    for (let attempt = 0; attempt < 40; attempt += 1) {
      const existingLayers = layers.filter((id) => map.getLayer(id));
      const features = existingLayers.length > 0
        ? map.queryRenderedFeatures({ layers: existingLayers })
        : [];
      const feature = features.find((item: any) => (
        item.properties?.name_en === name
        || item.properties?.name === name
        || item.properties?.['name:latin'] === name
      ));
      if (feature?.geometry?.type === 'Point') {
        const point = map.project(feature.geometry.coordinates);
        const rect = map.getCanvas().getBoundingClientRect();
        for (let radius = 0; radius <= 80; radius += 8) {
          for (let dx = -radius; dx <= radius; dx += 8) {
            for (let dy = -radius; dy <= radius; dy += 8) {
              const candidate = { x: point.x + dx, y: point.y + dy };
              const hits = map.queryRenderedFeatures([
                [candidate.x - 8, candidate.y - 8],
                [candidate.x + 8, candidate.y + 8],
              ], { layers: existingLayers });
              if (hits.some((item: any) => (
                item.properties?.name_en === name
                || item.properties?.name === name
                || item.properties?.['name:latin'] === name
              ))) {
                return { x: rect.left + candidate.x, y: rect.top + candidate.y };
              }
            }
          }
        }
      }
      await wait(250);
    }

    return null;
  }, labelName);
}

async function readMapCamera(page: any): Promise<{ lat: number; lng: number; zoom: number; bearing: number; pitch: number }> {
  return page.evaluate(() => {
    const target = window as typeof window & { __irisMap?: any };
    const map = target.__irisMap;
    const center = map.getCenter();
    return {
      lat: center.lat,
      lng: center.lng,
      zoom: map.getZoom(),
      bearing: map.getBearing(),
      pitch: map.getPitch(),
    };
  });
}

async function pressMapKeyAndWaitForMove(page: any, key: string) {
  const moved = page.evaluate(() => new Promise<void>((resolve, reject) => {
    const target = window as typeof window & { __irisMap?: any };
    const map = target.__irisMap;
    const timeout = window.setTimeout(() => reject(new Error('Timed out waiting for map moveend')), 5000);
    map.once('moveend', () => {
      window.clearTimeout(timeout);
      resolve();
    });
  }));
  await page.getByTestId('map-surface').press(key);
  await moved;
}

test.describe('Iris Maps', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  test('keeps location context visible when opening and reloading a shared place', async ({ page }) => {
    const place = { name: 'Otakaari', lat: 60.18671, lng: 24.831306, type: 'road',
      displayName: 'Street', source: 'search', contextParts: ['Espoo', 'Uusimaa', 'Finland'] };
    await page.goto(`/maps.html#/?place=${encodeURIComponent(JSON.stringify(place))}`);
    await disableOthersPool(page);
    const panel = page.getByTestId('active-place-panel');
    await expect(panel).toContainText('Espoo, Uusimaa, Finland');
    await page.reload();
    await expect(panel).toContainText('Espoo, Uusimaa, Finland');
    await expect(page.getByRole('button', { name: 'Remove pin', exact: true })).toHaveCount(0);
    await page.getByRole('button', { name: 'Close place', exact: true }).click();
    await expect(panel).toBeHidden();
    await expect(page.locator('.iris-map-active-marker')).toHaveCount(0);
    await expect(page).not.toHaveURL(/place=/);
  });

  test('tracks active search place in hash and panel', async ({ page }) => {
    test.slow();

    await page.goto('/maps.html#/');
    await disableOthersPool(page);
    await ensureLoggedIn(page);
    await disableOthersPool(page);

    const input = page.getByTestId('search-input');
    await expect(input).toBeVisible({ timeout: 10000 });
    await input.fill('Helsinki');

    const results = page.getByTestId('search-results');
    await expect(results).toBeVisible({ timeout: 20000 });

    const firstResult = results.locator('button').first();
    await expect(firstResult).toBeVisible({ timeout: 20000 });
    const name = 'Helsinki';
    await firstResult.click();

    const panel = page.locator('aside');
    await expect(panel).toBeVisible({ timeout: 10000 });
    await expect(panel).toContainText(name);

    await page.waitForFunction(() => window.location.hash.includes('place='));

    await page.reload();
    await disableOthersPool(page);
    await expect(panel).toBeVisible({ timeout: 10000 });
    await expect(panel).toContainText(name);
  });

  test('opens active panel from rendered map label and copies its URL', async ({ page, context }) => {
    test.slow();

    const appOrigin = `http://localhost:${process.env.PW_APP_PORT ?? '5173'}`;
    await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: appOrigin });
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [60.1699, 24.9384], zoom: 10 }));
    });
    await page.goto('/maps.html#/');
    await disableOthersPool(page);

    await page.waitForFunction(() => {
      const target = window as typeof window & { __irisMap?: any };
      return Boolean(target.__irisMap?.isStyleLoaded?.());
    }, null, { timeout: 30000 });

    const point = await visibleLabelPoint(page, 'Helsinki');
    expect(point).not.toBeNull();

    await page.mouse.move(point!.x, point!.y);
    await expect.poll(() => page.evaluate(() => {
      const target = window as typeof window & { __irisMap?: any };
      return target.__irisMap?.getCanvas()?.style.cursor;
    })).toBe('pointer');

    await page.mouse.click(point!.x, point!.y);

    const panel = page.getByTestId('active-place-panel');
    await expect(panel).toBeVisible({ timeout: 10000 });
    await expect(panel).toContainText('Helsinki');
    await page.waitForFunction(() => window.location.hash.includes('place='));
    await page.waitForTimeout(1000);
    const clickedPlace = await page.evaluate(() => {
      const [, query = ''] = window.location.hash.split('?');
      const placeParam = new URLSearchParams(query).get('place');
      return placeParam ? JSON.parse(placeParam) as { id?: string; sourceLayer?: string } : null;
    });
    expect(clickedPlace?.id).toContain('map-label:');
    expect(clickedPlace?.sourceLayer).toBeTruthy();

    const shareButton = page.getByTestId('active-place-share');
    await shareButton.click();
    await expect(shareButton).toHaveAttribute('aria-label', 'Copied');
    await expect.poll(() => page.evaluate(() => navigator.clipboard.readText())).toContain('place=');
  });

  test('dismisses map context menu actions', async ({ page, context }) => {
    test.slow();

    const appOrigin = `http://localhost:${process.env.PW_APP_PORT ?? '5173'}`;
    await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: appOrigin });
    await page.goto('/maps.html#/');
    await disableOthersPool(page);

    await page.waitForFunction(() => {
      const target = window as typeof window & { __irisMap?: any };
      return Boolean(target.__irisMap?.isStyleLoaded?.());
    }, null, { timeout: 30000 });

    const mapCanvas = page.locator('.maplibregl-canvas');
    await expect(mapCanvas).toBeVisible({ timeout: 10000 });
    const canvasBox = await mapCanvas.boundingBox();
    expect(canvasBox).not.toBeNull();
    const clickPoint = {
      x: canvasBox!.x + canvasBox!.width / 2,
      y: canvasBox!.y + canvasBox!.height / 2,
    };

    await page.mouse.click(clickPoint.x, clickPoint.y, { button: 'right' });
    const contextMenu = page.getByTestId('map-context-menu');
    await expect(contextMenu).toBeVisible({ timeout: 10000 });
    await expect(contextMenu.locator('.i-lucide-crosshair')).toHaveCount(0);

    await page.getByTestId('map-context-share').click();
    await expect(contextMenu).toBeHidden();
    await expect(page.getByTestId('active-place-panel')).toBeVisible({ timeout: 10000 });
    await page.waitForFunction(() => window.location.hash.includes('place='));

    await page.mouse.click(clickPoint.x, clickPoint.y, { button: 'right' });
    await expect(contextMenu).toBeVisible({ timeout: 10000 });
    await page.getByTestId('map-context-add-place').click();
    await expect(contextMenu).toBeHidden();
    await expect(page.getByRole('dialog', { name: 'Add Place' })).toBeVisible({ timeout: 10000 });
  });

  test('measures distance from the map context menu', async ({ page }) => {
    await page.goto('/maps.html#/');
    await disableOthersPool(page);

    await page.waitForFunction(() => {
      const target = window as typeof window & { __irisMap?: any };
      return Boolean(target.__irisMap?.isStyleLoaded?.());
    }, null, { timeout: 30000 });

    const mapCanvas = page.locator('.maplibregl-canvas');
    await expect(mapCanvas).toBeVisible({ timeout: 10000 });
    const canvasBox = await mapCanvas.boundingBox();
    expect(canvasBox).not.toBeNull();
    const startPoint = {
      x: canvasBox!.x + canvasBox!.width / 2,
      y: canvasBox!.y + canvasBox!.height / 2,
    };

    await page.mouse.click(startPoint.x, startPoint.y, { button: 'right' });
    await page.getByTestId('map-context-measure-distance').click();

    const panel = page.getByTestId('measure-distance-panel');
    await expect(panel).toBeVisible({ timeout: 10000 });
    await expect(page.getByTestId('measure-distance-total')).toHaveText('0 m');

    await page.mouse.click(startPoint.x + 120, startPoint.y + 32);
    await expect.poll(async () => page.getByTestId('measure-distance-total').innerText()).not.toBe('0 m');

    await page.getByRole('button', { name: 'Close measure distance' }).click();
    await expect(panel).toBeHidden();
  });

  test('zooms and pans the focused map with Google-style keyboard controls', async ({ page }) => {
    await page.addInitScript(() => {
      localStorage.setItem('iris-maps-view', JSON.stringify({ center: [60.1699, 24.9384], zoom: 8 }));
    });
    await page.goto('/maps.html#/');
    await disableOthersPool(page);

    await page.waitForFunction(() => {
      const target = window as typeof window & { __irisMap?: any };
      return Boolean(target.__irisMap?.isStyleLoaded?.());
    }, null, { timeout: 30000 });

    const mapSurface = page.getByTestId('map-surface');
    await expect(mapSurface).toBeVisible({ timeout: 10000 });
    await mapSurface.focus();
    await expect(mapSurface).toBeFocused();

    const initial = await readMapCamera(page);
    await pressMapKeyAndWaitForMove(page, '+');
    const zoomed = await readMapCamera(page);
    expect(zoomed.zoom).toBeGreaterThan(initial.zoom);

    await pressMapKeyAndWaitForMove(page, 'ArrowRight');
    const panned = await readMapCamera(page);
    const smallPanLngDelta = panned.lng - zoomed.lng;
    expect(smallPanLngDelta).toBeGreaterThan(0);

    await pressMapKeyAndWaitForMove(page, 'Shift+ArrowRight');
    const largePanned = await readMapCamera(page);
    const largePanLngDelta = largePanned.lng - panned.lng;
    expect(largePanLngDelta).toBeGreaterThan(smallPanLngDelta * 2);
    expect(largePanned.bearing).toBe(initial.bearing);
    expect(largePanned.pitch).toBe(initial.pitch);

    await pressMapKeyAndWaitForMove(page, '-');
    const zoomedOut = await readMapCamera(page);
    expect(zoomedOut.zoom).toBeLessThan(zoomed.zoom);
  });
});
