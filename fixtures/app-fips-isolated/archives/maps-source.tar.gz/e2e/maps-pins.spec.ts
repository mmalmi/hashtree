import { test, expect } from './fixtures';
import { disableOthersPool, setupPageErrorHandler, useLocalRelay } from './test-utils';

async function ensureLoggedIn(page: any) {
  const profileBtn = page.locator('button[title="My Profile (double-click for users)"]');
  if (!(await profileBtn.isVisible().catch(() => false))) {
    await page.goto('/maps.html#/settings');
  }
  await page.waitForSelector('button[title="My Profile (double-click for users)"], button:has-text("New")', { timeout: 15000 });
  if (await profileBtn.isVisible().catch(() => false)) {
    await page.goto('/maps.html#/');
    return;
  }
  const newButton = page.getByRole('button', { name: 'New' });
  await newButton.click();
  await expect(profileBtn).toBeVisible({ timeout: 15000 });
  await page.goto('/maps.html#/');
}

async function openAddPlaceFromContextMenu(page: any) {
  const mapCanvas = page.locator('.maplibregl-canvas');
  await expect(mapCanvas).toBeVisible({ timeout: 30000 });
  const box = await mapCanvas.boundingBox();
  expect(box).not.toBeNull();
  await page.mouse.click(box!.x + box!.width - 80, box!.y + 140, { button: 'right' });
  await page.getByTestId('map-context-add-place').click();
}

test.describe('Iris Maps', () => {
  test.beforeEach(async ({ page }) => {
    setupPageErrorHandler(page);
  });

  test('persists map pins and their removal across reloads', async ({ page }) => {
    test.slow();

    await page.goto('/maps.html#/');
    await disableOthersPool(page);
    await useLocalRelay(page);
    await ensureLoggedIn(page);
    await disableOthersPool(page);
    await useLocalRelay(page);

    const map = page.getByTestId('map-surface');
    await expect(map).toBeVisible({ timeout: 30000 });
    await openAddPlaceFromContextMenu(page);

    const locationText = page.locator('text=Location:');
    await expect(locationText).toBeVisible({ timeout: 10000 });

    const placeName = `Test Pin ${Date.now()}`;
    await page.locator('#place-name').fill(placeName);
    await page.getByRole('button', { name: 'Save' }).click();

    const modal = page.getByRole('dialog', { name: 'Add Place' });
    await expect(modal).toBeHidden({ timeout: 10000 });

    const markers = page.locator('.iris-map-place-marker');
    await expect(markers).toHaveCount(1, { timeout: 10000 });

    await page.reload();
    await disableOthersPool(page);
    await useLocalRelay(page);

    await expect(map).toBeVisible({ timeout: 30000 });
    await expect(markers).toHaveCount(1, { timeout: 20000 });
    // A reloaded place link has source "search"; resolve the pin from this map's records.
    await expect(page.getByRole('heading', { name: placeName })).toBeVisible();
    const rootBeforeRemoval = await page.evaluate(() => Object.entries(localStorage)
      .filter(([key]) => key.startsWith('iris-maps-root:maps:')));
    await page.getByRole('button', { name: 'Remove pin', exact: true }).click();
    await expect(markers).toHaveCount(0);
    await expect(page.locator('.iris-map-active-marker')).toHaveCount(0);
    await expect(page).not.toHaveURL(/place=/);
    await page.waitForFunction((before) => before.some(([key, value]) => localStorage.getItem(key) !== value), rootBeforeRemoval);
    await page.reload();
    await expect(map).toBeVisible({ timeout: 30000 });
    await expect(markers).toHaveCount(0);

  });
});
