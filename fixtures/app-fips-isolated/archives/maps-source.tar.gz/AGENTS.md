Keep this repo focused on the standalone Iris Maps app.

- Shared UI, release tooling, and Nostr helpers come from immutable Iris Kit releases.
- Before release, run `pnpm run test:unit`, `pnpm run test:maps:iris`, and `node ./scripts/release-site.mjs maps --dry-run`.
- Keep maps release scripts testing the built output before publish/deploy.
