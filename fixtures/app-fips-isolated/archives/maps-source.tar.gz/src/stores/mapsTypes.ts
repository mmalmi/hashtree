import type { SavedPlaceListUrls } from '../lib/savedPlaceListUrls';

export interface MapView {
  center: [number, number];
  zoom: number;
  bounds?: [number, number, number, number];
}

export interface MapsPersistedData {
  version: number;
  places: Place[];
  annotations: Annotation[];
  reviews?: PlaceReview[];
  savedPlaceLists?: SavedPlaceList[];
}

export interface SearchResult {
  id?: string;
  name: string;
  lat: number;
  lng: number;
  type: string;
  class: string;
  displayName: string;
  context?: string;
  contextParts?: string[];
  contextAliases?: string[];
  aliases?: string[];
  boundingBox?: [number, number, number, number];
  placeRank?: number;
  importance?: number;
  addressType?: string;
  sourceLayer?: string;
  sourceZoom?: number;
  sourceId?: string;
  sourceTile?: [number, number];
  addressRef?: SearchAddressRef;
}

export interface SearchAddressRef {
  kind: 'street-address-points-v1';
  cid: {
    hash: string;
    key?: string;
  };
  count?: number;
  maxDistanceMeters?: number;
}

export interface SearchAddressPoint {
  n: string;
  lat: number;
  lng: number;
  confidence?: number;
  distanceMeters?: number;
  sourceZoom?: number;
  sourceTile?: [number, number];
}

export interface SearchAddressSidecar {
  version: number;
  kind: 'iris-maps-street-address-sidecar';
  streetId?: string;
  points: SearchAddressPoint[];
}

export interface PlaceDetailLink {
  label: string;
  url: string;
  kind?: 'website' | 'social' | 'payment' | 'source' | 'other';
}

export interface PlaceDetails {
  address?: string;
  description?: string;
  phone?: string;
  email?: string;
  website?: string;
  openingHours?: string;
  imageUrl?: string;
  paymentProvider?: string;
  requiredAppUrl?: string;
  verifiedAt?: string;
  links?: PlaceDetailLink[];
}

export interface ActivePlace {
  id?: string;
  name: string;
  lat: number;
  lng: number;
  type?: string;
  class?: string;
  displayName?: string;
  context?: string;
  contextParts?: string[];
  boundingBox?: [number, number, number, number];
  placeRank?: number;
  sourceLayer?: string;
  sourceZoom?: number;
  sourceId?: string;
  sourceTile?: [number, number];
  details?: PlaceDetails;
  source: 'search' | 'place';
}

export type PlaceCategory =
  | 'restaurant'
  | 'cafe'
  | 'bar'
  | 'shop'
  | 'service'
  | 'attraction'
  | 'accommodation'
  | 'transport'
  | 'other';

export interface Place {
  id: string;
  name: string;
  category: PlaceCategory;
  lat: number;
  lng: number;
  description?: string;
  contact?: string;
  hours?: string;
  tags?: string[];
  createdAt: number;
  updatedAt: number;
  owner: string;
  factEvent?: MapFactEventRecord;
}

export interface PlaceReview {
  id: string;
  placeId: string;
  rating: number;
  ratingMax: number;
  body?: string;
  lang?: string;
  media?: ReviewMedia[];
  createdAt: number;
  updatedAt: number;
  owner: string;
  factEvent?: MapFactEventRecord;
}

export type SavedPlaceListVisibility = 'private' | 'public';

export interface SavedPlaceListItem {
  key: string;
  id?: string;
  name: string;
  lat: number;
  lng: number;
  type?: string;
  class?: string;
  displayName?: string;
  context?: string;
  details?: PlaceDetails;
  source: 'search' | 'place';
  sourceLayer?: string;
  sourceId?: string;
  savedAt: number;
}

export interface SavedPlaceList {
  id: string;
  name: string;
  description?: string;
  icon: 'heart' | 'flag' | 'briefcase' | 'star' | 'bookmark' | 'map-pin';
  avatarUrl?: string;
  visibility: SavedPlaceListVisibility;
  urls?: SavedPlaceListUrls;
  places: SavedPlaceListItem[];
  itemCount?: number;
  loadedItemCount?: number;
  isSampled?: boolean;
  isViewportFiltered?: boolean;
  createdAt: number;
  updatedAt: number;
  factEvent?: MapFactEventRecord;
}

export interface ReviewMedia {
  url: string;
  mimeType: string;
  type: 'image' | 'video';
  alt?: string;
}

export interface MapFactEventRecord {
  kind: 7368;
  content: '';
  tags: string[][];
  subject: string;
  eventId?: string;
  authorPubkey?: string;
  publishedAt?: number;
  publishError?: string;
}

export interface Annotation {
  id: string;
  type: 'point' | 'line' | 'polygon';
  coordinates: [number, number][] | [number, number];
  name?: string;
  description?: string;
  color?: string;
  createdAt: number;
  updatedAt: number;
  owner: string;
}

export type AudienceFilter = 'own' | 'follows' | 'fof';
