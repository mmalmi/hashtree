import { writerForEntry } from '../lib/treeRewrite';
import { hashFromHex } from '../lib/hashtreeKeys';
/**
 * Maps store - manages places, annotations, and audience filter state
 */
import { cid, objectKeyFromHex, toHex, LinkType, type CID } from '@hashtree/core';
import { getTree } from '../store';
import { getRefResolver } from '../refResolver';
import { updateLocalRootCache } from '../treeRootCache';
import { nostr as nostrClient, nostrStore } from '../nostr';
import { getWorkerAdapter } from '../lib/workerInit';
import { loadMapView, saveMapView } from '../lib/mapView';
import { publishEvent } from '../lib/nostrPublish';
import { buildSavedPlaceListUrls, normalizeSavedPlaceListUrls } from '../lib/savedPlaceListUrls';
import {
  SAVED_PLACE_LIST_ITEMS_DIR,
  SAVED_PLACE_LIST_MANIFEST_FILE,
  SAVED_PLACE_LISTS_DIR,
  buildSavedPlaceListItemPages,
  buildSavedPlaceListManifest,
  savedPlaceListItemPageFile,
} from '../lib/savedPlaceListManifest';
import {
  buildPlaceFactEvent,
  buildReviewFactEvent,
  buildSavedPlaceListFactEvent,
  createMapEntityId,
  type MapFactEventRecord,
} from '../lib/mapFactEvents';
import { searchPlaces } from './mapsSearch';
import type {
  ActivePlace,
  Annotation,
  AudienceFilter,
  MapView,
  MapsPersistedData,
  Place,
  PlaceReview,
  SavedPlaceList,
  SavedPlaceListItem,
  SavedPlaceListVisibility,
  SearchResult,
} from './mapsTypes';
export { getSearchResultKey } from './mapsSearch';
export type {
  ActivePlace,
  Annotation,
  AudienceFilter,
  MapView,
  Place,
  PlaceCategory,
  PlaceReview,
  ReviewMedia,
  SavedPlaceList,
  SavedPlaceListItem,
  SavedPlaceListVisibility,
  SearchResult,
} from './mapsTypes';

const MAPS_TREE_NAME = 'maps';
const MAPS_DATA_FILE = 'maps.json';
const MAPS_DATA_VERSION = 3;
const MAPS_META_FILE = 'meta.json';
const MAPS_META_VERSION = 1;
const MAPS_ROOT_STORAGE_KEY = 'iris-maps-root:maps';
const SAVED_PLACE_LISTS_STORAGE_KEY = 'iris-maps-saved-place-lists';
const PUBLIC_LIST_VISIBILITY: SavedPlaceListVisibility = 'public';
const MAPS_ROOT_LABELS = ['iris-maps'];
const SAVED_PLACE_LIST_ROOT_LABEL = 'iris-maps:saved-place-list';

interface MapsMeta {
  version: number;
  createdAt: number;
  updatedAt: number;
  providers: string[];
}

interface MapsState {
  places: Place[];
  annotations: Annotation[];
  reviews: PlaceReview[];
  savedPlaceLists: SavedPlaceList[];
  audienceFilter: AudienceFilter;
  selectedPlace: Place | null;
  isAddPlaceModalOpen: boolean;
  pendingPlaceLocation: { lat: number; lng: number } | null;
  mapView: MapView;
  searchQuery: string;
  searchResults: SearchResult[];
  isSearching: boolean;
  activePlace: ActivePlace | null;
}

const savedView = loadMapView();

const initialState: MapsState = {
  places: [],
  annotations: [],
  reviews: [],
  savedPlaceLists: loadLocalSavedPlaceLists(null),
  audienceFilter: 'follows',
  selectedPlace: null,
  isAddPlaceModalOpen: false,
  pendingPlaceLocation: null,
  mapView: savedView,
  searchQuery: '',
  searchResults: [],
  isSearching: false,
  activePlace: null,
};

let state = $state<MapsState>({ ...initialState });

let activeNpub: string | null = null;
let rootCid: CID | null = null;
let resolverUnsubscribe: (() => void) | null = null;
let nostrUnsubscribe: (() => void) | null = null;
let applyingRemote = false;
let persistChain: Promise<void> = Promise.resolve();
let searchGeneration = 0;
let accountGeneration = 0;
let loadGeneration = 0;
let pendingWrites = 0;

function resetLocalState() {
  pendingWrites = 0;
  if (state.places.some(place => place.id === state.activePlace?.id)) state.activePlace = null;
  state.places = [];
  state.annotations = [];
  state.reviews = [];
  state.savedPlaceLists = withSavedPlaceListUrlsForOwner(loadLocalSavedPlaceLists(activeNpub), activeNpub);
  state.selectedPlace = null;
  rootCid = null;
}

function applyRemoteData(data: MapsPersistedData) {
  applyingRemote = true;
  state.places = data.places;
  state.annotations = data.annotations;
  state.reviews = data.reviews ?? [];
  state.savedPlaceLists = withSavedPlaceListUrlsForOwner(
    mergeSavedPlaceLists(data.savedPlaceLists ?? [], loadLocalSavedPlaceLists(activeNpub)),
    activeNpub,
  );
  state.selectedPlace = null;
  applyingRemote = false;
}

function normalizePersistedData(raw: unknown): MapsPersistedData | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Partial<MapsPersistedData>;
  if (!Array.isArray(record.places) || !Array.isArray(record.annotations)) return null;
  return {
    version: typeof record.version === 'number' ? record.version : MAPS_DATA_VERSION,
    places: record.places as Place[],
    annotations: record.annotations as Annotation[],
    reviews: Array.isArray(record.reviews) ? record.reviews as PlaceReview[] : [],
    savedPlaceLists: normalizeSavedPlaceLists(record.savedPlaceLists),
  };
}

const savedPlaceListIcons = new Set<SavedPlaceList['icon']>([
  'heart',
  'flag',
  'briefcase',
  'star',
  'bookmark',
  'map-pin',
]);

function createDefaultSavedPlaceLists(): SavedPlaceList[] {
  const now = Date.now();
  return [
    createSavedPlaceListRecord('Favorites', 'heart', 'private', now),
    createSavedPlaceListRecord('Want to go', 'flag', 'private', now + 1),
    createSavedPlaceListRecord('Travel plans', 'briefcase', 'private', now + 2),
    createSavedPlaceListRecord('Starred places', 'star', 'private', now + 3),
    createSavedPlaceListRecord('Saved places', 'bookmark', 'private', now + 4),
  ];
}

function createSavedPlaceListRecord(
  name: string,
  icon: SavedPlaceList['icon'],
  visibility: SavedPlaceListVisibility,
  timestamp = Date.now(),
): SavedPlaceList {
  return {
    id: createMapEntityId(),
    name,
    icon,
    visibility,
    places: [],
    createdAt: timestamp,
    updatedAt: timestamp,
  };
}

function canUseLocalStorage(): boolean {
  return typeof localStorage !== 'undefined'
    && typeof localStorage.getItem === 'function'
    && typeof localStorage.setItem === 'function';
}

function getSavedPlaceListsStorageKey(npub: string | null): string {
  return `${SAVED_PLACE_LISTS_STORAGE_KEY}:${npub ?? 'anonymous'}`;
}

function loadLocalSavedPlaceLists(npub: string | null): SavedPlaceList[] {
  if (!canUseLocalStorage()) return createDefaultSavedPlaceLists();
  try {
    const stored = localStorage.getItem(getSavedPlaceListsStorageKey(npub));
    if (!stored) return createDefaultSavedPlaceLists();
    const normalized = normalizeSavedPlaceLists(JSON.parse(stored));
    return normalized.length > 0 ? normalized : createDefaultSavedPlaceLists();
  } catch {
    return createDefaultSavedPlaceLists();
  }
}

function saveLocalSavedPlaceLists(npub: string | null, lists: SavedPlaceList[]) {
  if (!canUseLocalStorage()) return;
  try {
    localStorage.setItem(getSavedPlaceListsStorageKey(npub), JSON.stringify(normalizeSavedPlaceLists(lists)));
  } catch {
    // Ignore storage errors
  }
}

function normalizeSavedPlaceLists(raw: unknown): SavedPlaceList[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map(normalizeSavedPlaceList)
    .filter((list): list is SavedPlaceList => Boolean(list))
    .sort((left, right) => left.createdAt - right.createdAt || left.name.localeCompare(right.name));
}

function normalizeSavedPlaceList(raw: unknown): SavedPlaceList | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Partial<SavedPlaceList>;
  if (typeof record.id !== 'string' || !isCanonicalUuid(record.id)) return null;
  const name = typeof record.name === 'string' && record.name.trim() ? record.name.trim() : 'Saved places';
  const description = cleanOptionalText(record.description);
  const icon = record.icon && savedPlaceListIcons.has(record.icon) ? record.icon : 'bookmark';
  const avatarUrl = cleanOptionalText(record.avatarUrl);
  const visibility = record.visibility === PUBLIC_LIST_VISIBILITY ? PUBLIC_LIST_VISIBILITY : 'private';
  const createdAt = typeof record.createdAt === 'number' && Number.isFinite(record.createdAt) ? record.createdAt : Date.now();
  const updatedAt = typeof record.updatedAt === 'number' && Number.isFinite(record.updatedAt) ? record.updatedAt : createdAt;
  return {
    id: record.id,
    name,
    description,
    icon,
    avatarUrl,
    visibility,
    urls: visibility === PUBLIC_LIST_VISIBILITY ? normalizeSavedPlaceListUrls(record.urls) : undefined,
    places: normalizeSavedPlaceItems(record.places),
    createdAt,
    updatedAt,
    factEvent: record.factEvent,
  };
}

function normalizeSavedPlaceItems(raw: unknown): SavedPlaceListItem[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map(normalizeSavedPlaceItem)
    .filter((item): item is SavedPlaceListItem => Boolean(item));
}

function normalizeSavedPlaceItem(raw: unknown): SavedPlaceListItem | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Partial<SavedPlaceListItem>;
  if (typeof record.key !== 'string' || !record.key.trim()) return null;
  if (typeof record.name !== 'string' || !record.name.trim()) return null;
  if (typeof record.lat !== 'number' || !Number.isFinite(record.lat)) return null;
  if (typeof record.lng !== 'number' || !Number.isFinite(record.lng)) return null;
  return {
    key: record.key,
    id: typeof record.id === 'string' && record.id ? record.id : undefined,
    name: record.name.trim(),
    lat: record.lat,
    lng: record.lng,
    type: typeof record.type === 'string' && record.type ? record.type : undefined,
    class: typeof record.class === 'string' && record.class ? record.class : undefined,
    displayName: typeof record.displayName === 'string' && record.displayName ? record.displayName : undefined,
    context: typeof record.context === 'string' && record.context ? record.context : undefined,
    source: record.source === 'place' ? 'place' : 'search',
    sourceLayer: typeof record.sourceLayer === 'string' && record.sourceLayer ? record.sourceLayer : undefined,
    sourceId: typeof record.sourceId === 'string' && record.sourceId ? record.sourceId : undefined,
    savedAt: typeof record.savedAt === 'number' && Number.isFinite(record.savedAt) ? record.savedAt : Date.now(),
  };
}

function mergeSavedPlaceLists(remoteLists: SavedPlaceList[], localLists: SavedPlaceList[]): SavedPlaceList[] {
  const merged = new Map<string, SavedPlaceList>();
  for (const list of remoteLists) {
    if (list.visibility === PUBLIC_LIST_VISIBILITY) {
      merged.set(list.id, list);
    }
  }
  for (const list of localLists) {
    const current = merged.get(list.id);
    if (!current || list.updatedAt >= current.updatedAt || list.visibility !== PUBLIC_LIST_VISIBILITY) {
      merged.set(list.id, list);
    }
  }
  return [...merged.values()].sort((left, right) => left.createdAt - right.createdAt || left.name.localeCompare(right.name));
}

function publicSavedPlaceLists(): SavedPlaceList[] {
  return state.savedPlaceLists
    .filter((list) => list.visibility === PUBLIC_LIST_VISIBILITY)
    .map((list) => withSavedPlaceListUrls(list));
}

function isCanonicalUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value);
}

function getRootStorageKey(npub: string): string {
  return `${MAPS_ROOT_STORAGE_KEY}:${npub}`;
}

function loadMapsRoot(npub: string): CID | null {
  try {
    const stored = localStorage.getItem(getRootStorageKey(npub));
    if (!stored) return null;
    const parsed = JSON.parse(stored) as { hash?: string; key?: string };
    if (parsed?.hash) {
      return cid(hashFromHex(parsed.hash), parsed.key == null ? undefined : objectKeyFromHex(parsed.key));
    }
  } catch {
    // Ignore storage errors
  }
  return null;
}

function saveMapsRoot(npub: string, root: CID) {
  try {
    localStorage.setItem(
      getRootStorageKey(npub),
      JSON.stringify({ hash: toHex(root.hash), key: root.key ? toHex(root.key) : undefined })
    );
  } catch {
    // Ignore storage errors
  }
}

async function waitForWorkerReady(maxWaitMs = 5000): Promise<boolean> {
  const start = Date.now();
  while (!getWorkerAdapter()) {
    if (Date.now() - start > maxWaitMs) {
      return false;
    }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  return true;
}

let workerReadyPromise: Promise<boolean> | null = null;

async function ensureWorkerReady(maxWaitMs = 5000): Promise<boolean> {
  if (!workerReadyPromise) {
    workerReadyPromise = waitForWorkerReady(maxWaitMs);
  }
  const ready = await workerReadyPromise;
  if (!ready) {
    workerReadyPromise = null;
  }
  return ready;
}

async function ensureMapsMeta(root: CID): Promise<CID> {
  const tree = getTree();
  const existing = await tree.resolvePath(root, [MAPS_META_FILE]);
  if (existing) return root;
  const meta: MapsMeta = {
    version: MAPS_META_VERSION,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    providers: [],
  };
  const encoded = new TextEncoder().encode(JSON.stringify(meta));
  const { cid: fileCid, size } = await writerForEntry(tree, root).putFile(encoded);
  return tree.setEntry(root, [], MAPS_META_FILE, fileCid, size, LinkType.File);
}


function queuePersist(): Promise<void> {
  const npub = activeNpub;
  if (applyingRemote || !npub) return Promise.resolve();
  const generation = accountGeneration;
  // Capture the edit now: queued writes must never read a different account's state.
  const lists: SavedPlaceList[] = JSON.parse(JSON.stringify(publicSavedPlaceLists()));
  const payload: MapsPersistedData = {
    version: MAPS_DATA_VERSION,
    places: state.places,
    annotations: state.annotations,
    reviews: state.reviews,
    savedPlaceLists: lists.map(list => ({ ...list, places: [] })),
  };
  const encoded = new TextEncoder().encode(JSON.stringify(payload));
  loadGeneration += 1;
  pendingWrites += 1;
  persistChain = persistChain.then(async () => {
    const ready = await ensureWorkerReady();
    if (!ready || generation !== accountGeneration) return;
    const tree = getTree();
    let currentRoot = rootCid ?? loadMapsRoot(npub);
    if (!currentRoot) {
      const { cid: emptyRoot } = await tree.putDirectory([]);
      currentRoot = await ensureMapsMeta(emptyRoot);
    } else {
      currentRoot = await ensureMapsMeta(currentRoot);
    }
    if (generation !== accountGeneration) return;
    const nextRoot = await persistMapsData(currentRoot, encoded, lists);
    if (generation !== accountGeneration) return;
    loadGeneration += 1;
    rootCid = nextRoot;
    saveMapsRoot(npub, nextRoot);
    const labels = lists.length > 0 ? [...MAPS_ROOT_LABELS, SAVED_PLACE_LIST_ROOT_LABEL] : MAPS_ROOT_LABELS;
    updateLocalRootCache(npub, MAPS_TREE_NAME, nextRoot.hash, nextRoot.key, 'public', labels);
  }).catch(() => {}).finally(() => {
    if (generation === accountGeneration) pendingWrites -= 1;
  });
  return persistChain;
}

async function loadMapsData(cid: CID) {
  const generation = ++loadGeneration;
  const ready = await waitForWorkerReady();
  if (!ready || generation !== loadGeneration) return;
  const tree = getTree();
  const entry = await tree.resolvePath(cid, [MAPS_DATA_FILE]);
  if (generation !== loadGeneration) return;
  if (!entry) {
    applyRemoteData({ version: MAPS_DATA_VERSION, places: [], annotations: [] });
    return;
  }
  const data = await tree.readFile(entry.cid);
  if (!data || generation !== loadGeneration) return;
  try {
    const decoded = new TextDecoder().decode(data);
    const parsed = JSON.parse(decoded);
    const normalized = normalizePersistedData(parsed);
    if (normalized) {
      applyRemoteData(normalized);
    }
  } catch {
    // Ignore invalid data
  }
}

async function persistMapsData(currentRoot: CID, encoded: Uint8Array, lists: SavedPlaceList[]): Promise<CID> {
  const tree = getTree();
  const existing = await tree.resolvePath(currentRoot, [MAPS_DATA_FILE]);
  const writer = writerForEntry(writerForEntry(tree, currentRoot), existing?.cid);
  const { cid: fileCid, size } = await writer.putFile(encoded);
  const rootWithMapsData = await tree.setEntry(currentRoot, [], MAPS_DATA_FILE, fileCid, size, LinkType.File);
  return persistPublicSavedPlaceListDirectories(rootWithMapsData, lists);
}

async function childCids(tree: ReturnType<typeof getTree>, directory?: CID) {
  const entries = directory ? await tree.listDirectory(directory) : [];
  return new Map(entries.map(entry => [entry.name, entry.cid]));
}

async function persistPublicSavedPlaceListDirectories(currentRoot: CID, lists: SavedPlaceList[]): Promise<CID> {
  const tree = getTree();
  const previous = await tree.resolvePath(currentRoot, [SAVED_PLACE_LISTS_DIR]);
  const listsWriter = writerForEntry(writerForEntry(tree, currentRoot), previous?.cid);
  const previousLists = await childCids(tree, previous?.cid);
  const listEntries = [];
  for (const list of lists) {
    const listCid = previousLists.get(list.id);
    const listWriter = writerForEntry(listsWriter, listCid);
    const files = await childCids(tree, listCid);
    const itemsCid = files.get(SAVED_PLACE_LIST_ITEMS_DIR);
    const itemsWriter = writerForEntry(listWriter, itemsCid);
    const pages = await childCids(tree, itemsCid);
    const pageEntries = [];
    for (const [index, page] of buildSavedPlaceListItemPages(list.places).entries()) {
      const encoded = new TextEncoder().encode(JSON.stringify(page));
      const name = savedPlaceListItemPageFile(index);
      const { cid: pageCid, size } = await writerForEntry(itemsWriter, pages.get(name)).putFile(encoded);
      pageEntries.push({
        name,
        cid: pageCid,
        size,
        type: LinkType.File,
      });
    }
    const { cid: itemsDirCid } = await itemsWriter.putDirectory(pageEntries);
    const manifest = buildSavedPlaceListManifest(list, {
      labels: [...MAPS_ROOT_LABELS, SAVED_PLACE_LIST_ROOT_LABEL],
      renderingProjections: {
        dynamicGeojson: {
          kind: 'hashtree-geohash-index',
          sourceIndex: 'by-list-geohash-time',
          cluster: true,
        },
        pmtilesOverlay: null,
      },
    });
    const manifestEncoded = new TextEncoder().encode(JSON.stringify(manifest));
    const { cid: manifestCid, size: manifestSize } = await writerForEntry(listWriter, files.get(SAVED_PLACE_LIST_MANIFEST_FILE)).putFile(manifestEncoded);
    const { cid: listDirCid } = await listWriter.putDirectory([
      {
        name: SAVED_PLACE_LIST_MANIFEST_FILE,
        cid: manifestCid,
        size: manifestSize,
        type: LinkType.File,
      },
      {
        name: SAVED_PLACE_LIST_ITEMS_DIR,
        cid: itemsDirCid,
        size: 0,
        type: LinkType.Dir,
      },
    ]);
    listEntries.push({
      name: list.id,
      cid: listDirCid,
      size: 0,
      type: LinkType.Dir,
    });
  }
  const { cid: listsDirCid } = await listsWriter.putDirectory(listEntries);
  return tree.setEntry(currentRoot, [], SAVED_PLACE_LISTS_DIR, listsDirCid, 0, LinkType.Dir);
}

async function publishMapFactEvent(record: MapFactEventRecord): Promise<MapFactEventRecord> {
  const nostr = nostrStore.getState();
  if (!nostr.pubkey || !nostrClient.signer) return record;

  try {
    const event = await publishEvent({ kind: record.kind, content: record.content, tags: record.tags, created_at: Math.floor(Date.now() / 1000) });
    return {
      ...record,
      eventId: event.id,
      authorPubkey: nostr.pubkey,
      publishedAt: event.created_at ?? Math.floor(Date.now() / 1000),
      publishError: undefined,
    };
  } catch (error) {
    return {
      ...record,
      publishError: error instanceof Error ? error.message : 'Failed to publish fact event',
    };
  }
}

function savedPlaceKey(place: ActivePlace): string {
  if (place.id?.trim()) return place.id.trim();
  return `coordinate:${formatSavedCoordinate(place.lat)}:${formatSavedCoordinate(place.lng)}`;
}

function activePlaceToSavedPlaceItem(place: ActivePlace, savedAt = Date.now()): SavedPlaceListItem {
  return {
    key: savedPlaceKey(place),
    id: place.id,
    name: place.name,
    lat: place.lat,
    lng: place.lng,
    type: place.type,
    class: place.class,
    displayName: place.displayName,
    context: place.context,
    details: place.details,
    source: place.source,
    sourceLayer: place.sourceLayer,
    sourceId: place.sourceId,
    savedAt,
  };
}

function formatSavedCoordinate(value: number): string {
  const normalized = Math.abs(value) < 0.0000005 ? 0 : value;
  return normalized.toFixed(6);
}

function hasSavedPlace(list: SavedPlaceList, place: ActivePlace): boolean {
  const key = savedPlaceKey(place);
  return list.places.some((item) => item.key === key);
}

function saveSavedPlaceListsLocally() {
  saveLocalSavedPlaceLists(activeNpub, state.savedPlaceLists);
}

async function persistSavedPlaceLists() {
  saveSavedPlaceListsLocally();
  await queuePersist();
}

function activeOwnerNpub(): string | null {
  return activeNpub ?? nostrStore.getState().npub;
}

function withSavedPlaceListUrls(list: SavedPlaceList): SavedPlaceList {
  if (list.visibility !== PUBLIC_LIST_VISIBILITY) {
    return list.urls ? { ...list, urls: undefined } : list;
  }
  const ownerNpub = activeOwnerNpub();
  if (!ownerNpub) return list;
  const urls = buildSavedPlaceListUrls({
    listId: list.id,
    ownerNpub,
    treeName: MAPS_TREE_NAME,
  });
  return JSON.stringify(urls) === JSON.stringify(list.urls) ? list : { ...list, urls };
}

function withSavedPlaceListUrlsForOwner(lists: SavedPlaceList[], ownerNpub: string | null): SavedPlaceList[] {
  return lists.map((list) => {
    if (list.visibility !== PUBLIC_LIST_VISIBILITY) {
      return list.urls ? { ...list, urls: undefined } : list;
    }
    if (!ownerNpub) return list;
    const urls = buildSavedPlaceListUrls({
      listId: list.id,
      ownerNpub,
      treeName: MAPS_TREE_NAME,
    });
    return JSON.stringify(urls) === JSON.stringify(list.urls) ? list : { ...list, urls };
  });
}

async function publishSavedPlaceListIfPublic(list: SavedPlaceList): Promise<SavedPlaceList> {
  const listWithUrls = withSavedPlaceListUrls(list);
  if (list.visibility !== PUBLIC_LIST_VISIBILITY) {
    return {
      ...list,
      urls: undefined,
      factEvent: undefined,
    };
  }
  const factEvent = buildSavedPlaceListFactEvent({
    id: listWithUrls.id,
    name: listWithUrls.name,
    description: listWithUrls.description,
    avatarUrl: listWithUrls.avatarUrl,
    visibility: listWithUrls.visibility,
    urls: listWithUrls.urls,
    places: listWithUrls.places,
    createdAt: listWithUrls.createdAt,
    updatedAt: listWithUrls.updatedAt,
  });
  const publishedFactEvent = await publishMapFactEvent(factEvent);
  return {
    ...listWithUrls,
    factEvent: publishedFactEvent,
  };
}

async function republishSavedPlaceList(list: SavedPlaceList): Promise<SavedPlaceList> {
  const generation = accountGeneration;
  const published = await publishSavedPlaceListIfPublic(list);
  if (generation !== accountGeneration) return list;
  if (published.factEvent === list.factEvent) return list;
  state.savedPlaceLists = state.savedPlaceLists.map((item) => item.id === list.id ? published : item);
  await persistSavedPlaceLists();
  return published;
}

function cleanOptionalText(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function placeToActivePlace(place: Place): ActivePlace {
  return {
    id: place.id,
    name: place.name,
    lat: place.lat,
    lng: place.lng,
    type: place.category,
    class: 'place',
    displayName: place.category,
    context: place.description,
    source: 'place',
  };
}

function subscribeToMapsTree(npub: string) {
  if (resolverUnsubscribe) {
    resolverUnsubscribe();
    resolverUnsubscribe = null;
  }

  const resolver = getRefResolver();
  const key = `${npub}/${MAPS_TREE_NAME}`;
  const generation = accountGeneration;
  resolverUnsubscribe = resolver.subscribe?.(key, (cid) => {
    // A relay may still echo the previous root while a local edit is being saved.
    if (!cid || generation !== accountGeneration || pendingWrites > 0) return;
    rootCid = cid;
    loadMapsData(cid).catch(() => {});
  }) ?? null;
}

function handleNostrChange() {
  const nextNpub = nostrStore.getState().npub;
  if (nextNpub === activeNpub) return;
  accountGeneration += 1;
  loadGeneration += 1;
  activeNpub = nextNpub;
  resetLocalState();
  if (!activeNpub) {
    if (resolverUnsubscribe) {
      resolverUnsubscribe();
      resolverUnsubscribe = null;
    }
    return;
  }
  const cachedRoot = loadMapsRoot(activeNpub);
  if (cachedRoot) {
    rootCid = cachedRoot;
    loadMapsData(cachedRoot).catch(() => {});
  }
  subscribeToMapsTree(activeNpub);
}

export const mapsStore = {
  get places() { return state.places; },
  get annotations() { return state.annotations; },
  get reviews() { return state.reviews; },
  get savedPlaceLists() { return state.savedPlaceLists; },
  get audienceFilter() { return state.audienceFilter; },
  get selectedPlace() { return state.selectedPlace; },
  get isAddPlaceModalOpen() { return state.isAddPlaceModalOpen; },
  get pendingPlaceLocation() { return state.pendingPlaceLocation; },
  get mapView() { return state.mapView; },
  get searchQuery() { return state.searchQuery; },
  get searchResults() { return state.searchResults; },
  get isSearching() { return state.isSearching; },
  get activePlace() { return state.activePlace; },
  init() {
    if (nostrUnsubscribe) return;
    handleNostrChange();
    nostrUnsubscribe = nostrStore.subscribe(() => {
      handleNostrChange();
    });
  },
  setActivePlace(place: ActivePlace | null) {
    state.activePlace = place;
  },
  destroy() {
    accountGeneration += 1;
    loadGeneration += 1;
    activeNpub = null;
    resetLocalState();
    this.clearSearch();
    if (nostrUnsubscribe) {
      nostrUnsubscribe();
      nostrUnsubscribe = null;
    }
    if (resolverUnsubscribe) {
      resolverUnsubscribe();
      resolverUnsubscribe = null;
    }
  },

  setMapView(center: [number, number], zoom: number, bounds?: [number, number, number, number]) {
    state.mapView = { center, zoom, bounds };
    saveMapView(state.mapView);
  },

  async search(query: string) {
    const generation = ++searchGeneration;
    state.searchQuery = query;
    const trimmed = query.trim();
    state.searchResults = [];
    state.isSearching = false;
    if (!trimmed || trimmed.length < 2) {
      return;
    }

    state.isSearching = true;
    try {
      const results = await searchPlaces(trimmed, state.mapView, state.activePlace);
      if (generation === searchGeneration) state.searchResults = results;
    } catch {
      // A failed lookup leaves the current search empty.
    } finally {
      if (generation === searchGeneration) state.isSearching = false;
    }
  },

  clearSearch() {
    searchGeneration += 1;
    state.searchQuery = '';
    state.searchResults = [];
    state.isSearching = false;
  },

  setAudienceFilter(filter: AudienceFilter) {
    state.audienceFilter = filter;
  },

  openAddPlaceModal() {
    state.isAddPlaceModalOpen = true;
  },

  closeAddPlaceModal() {
    state.isAddPlaceModalOpen = false;
    state.pendingPlaceLocation = null;
  },

  setPendingPlaceLocation(lat: number, lng: number) {
    state.pendingPlaceLocation = { lat, lng };
  },

  async addPlace(place: Omit<Place, 'id' | 'createdAt' | 'updatedAt'>) {
    const generation = accountGeneration;
    const now = Date.now();
    const id = createMapEntityId();
    const newPlace: Place = {
      ...place,
      id,
      createdAt: now,
      updatedAt: now,
    };
    newPlace.factEvent = buildPlaceFactEvent(newPlace);
    state.places = [...state.places, newPlace];
    await queuePersist();
    if (generation !== accountGeneration) return newPlace;
    const publishedFactEvent = await publishMapFactEvent(newPlace.factEvent);
    if (generation !== accountGeneration) return newPlace;
    if (publishedFactEvent !== newPlace.factEvent) {
      state.places = state.places.map(p => p.id === id ? { ...p, factEvent: publishedFactEvent } : p);
      await queuePersist();
    }
    return newPlace;
  },

  activePlaceFromPlace(place: Place) {
    return placeToActivePlace(place);
  },

  savedPlaceKey(place: ActivePlace) {
    return savedPlaceKey(place);
  },

  isPlaceSaved(place: ActivePlace) {
    return state.savedPlaceLists.some((list) => hasSavedPlace(list, place));
  },

  isPlaceInSavedList(listId: string, place: ActivePlace) {
    const list = state.savedPlaceLists.find((item) => item.id === listId);
    return list ? hasSavedPlace(list, place) : false;
  },

  async createSavedPlaceList(input: { name: string; visibility: SavedPlaceListVisibility; icon?: SavedPlaceList['icon']; place?: ActivePlace }) {
    const generation = accountGeneration;
    const name = input.name.trim();
    if (!name) throw new Error('List name is required');
    const now = Date.now();
    const list = createSavedPlaceListRecord(name, input.icon ?? 'bookmark', input.visibility, now);
    if (input.place) {
      list.places = [activePlaceToSavedPlaceItem(input.place, now)];
    }
    state.savedPlaceLists = [...state.savedPlaceLists, list];
    await persistSavedPlaceLists();
    if (generation !== accountGeneration) return list;
    return republishSavedPlaceList(list);
  },

  async toggleSavedPlaceInList(listId: string, place: ActivePlace) {
    const generation = accountGeneration;
    const list = state.savedPlaceLists.find((item) => item.id === listId);
    if (!list) return null;
    const key = savedPlaceKey(place);
    const now = Date.now();
    const nextPlaces = list.places.some((item) => item.key === key)
      ? list.places.filter((item) => item.key !== key)
      : [...list.places, activePlaceToSavedPlaceItem(place, now)];
    const nextList: SavedPlaceList = {
      ...list,
      places: nextPlaces,
      updatedAt: now,
      urls: list.visibility === PUBLIC_LIST_VISIBILITY ? list.urls : undefined,
      factEvent: list.visibility === PUBLIC_LIST_VISIBILITY ? list.factEvent : undefined,
    };
    state.savedPlaceLists = state.savedPlaceLists.map((item) => item.id === listId ? nextList : item);
    await persistSavedPlaceLists();
    if (generation !== accountGeneration) return nextList;
    return republishSavedPlaceList(nextList);
  },

  async setSavedPlaceListVisibility(listId: string, visibility: SavedPlaceListVisibility) {
    const generation = accountGeneration;
    const list = state.savedPlaceLists.find((item) => item.id === listId);
    if (!list || list.visibility === visibility) return list ?? null;
    const nextList: SavedPlaceList = {
      ...list,
      visibility,
      updatedAt: Date.now(),
      urls: visibility === PUBLIC_LIST_VISIBILITY ? list.urls : undefined,
      factEvent: visibility === PUBLIC_LIST_VISIBILITY ? list.factEvent : undefined,
    };
    state.savedPlaceLists = state.savedPlaceLists.map((item) => item.id === listId ? nextList : item);
    await persistSavedPlaceLists();
    if (generation !== accountGeneration) return nextList;
    return republishSavedPlaceList(nextList);
  },

  updatePlace(id: string, updates: Partial<Omit<Place, 'id' | 'createdAt' | 'owner'>>) {
    state.places = state.places.map(p =>
      p.id === id ? { ...p, ...updates, updatedAt: Date.now() } : p
    );
    queuePersist();
  },

  async deletePlace(id: string) {
    const deletedPlace = state.places.find(p => p.id === id);
    if (!deletedPlace) return;
    const deletedPlaceKey = savedPlaceKey(placeToActivePlace(deletedPlace));
    if (state.activePlace?.id === id) state.activePlace = null;
    if (state.selectedPlace?.id === id) state.selectedPlace = null;
    state.places = state.places.filter(p => p.id !== id);
    state.reviews = state.reviews.filter(review => review.placeId !== id);
    state.savedPlaceLists = state.savedPlaceLists.map((list) => (
      list.places.some((item) => item.key === deletedPlaceKey)
        ? { ...list, places: list.places.filter((item) => item.key !== deletedPlaceKey), updatedAt: Date.now() }
        : list
    ));
    saveSavedPlaceListsLocally();
    await queuePersist();
  },

  selectPlace(place: Place | null) {
    state.selectedPlace = place;
  },

  addAnnotation(annotation: Omit<Annotation, 'id' | 'createdAt' | 'updatedAt'>) {
    const now = Date.now();
    const newAnnotation: Annotation = {
      ...annotation,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    };
    state.annotations = [...state.annotations, newAnnotation];
    queuePersist();
    return newAnnotation;
  },

  async addReview(review: Omit<PlaceReview, 'id' | 'createdAt' | 'updatedAt' | 'factEvent'>) {
    const generation = accountGeneration;
    const now = Date.now();
    const newReview: PlaceReview = {
      ...review,
      id: createMapEntityId(),
      createdAt: now,
      updatedAt: now,
    };
    newReview.factEvent = buildReviewFactEvent({
      ...newReview,
      reviewer: newReview.owner,
    });
    state.reviews = [...state.reviews, newReview];
    await queuePersist();
    if (generation !== accountGeneration) return newReview;
    const publishedFactEvent = await publishMapFactEvent(newReview.factEvent);
    if (generation !== accountGeneration) return newReview;
    if (publishedFactEvent !== newReview.factEvent) {
      state.reviews = state.reviews.map(item => item.id === newReview.id ? { ...item, factEvent: publishedFactEvent } : item);
      await queuePersist();
    }
    return newReview;
  },

  reviewsForPlace(placeId: string) {
    return state.reviews.filter(review => review.placeId === placeId);
  },

  deleteAnnotation(id: string) {
    state.annotations = state.annotations.filter(a => a.id !== id);
    queuePersist();
  },

  reset() {
    accountGeneration += 1;
    loadGeneration += 1;
    activeNpub = null;
    rootCid = null;
    pendingWrites = 0;
    searchGeneration += 1;
    state = { ...initialState };
  },
};
