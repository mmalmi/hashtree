import { normalizeMapSearchText as normalizeSearchText, mapSearchResultText, matchesMapSearchQuery } from '../lib/mapSearchText';
import type { ActivePlace, MapView, SearchResult } from './mapsTypes';
import { fetchMapLabels, type MapLabel } from '../lib/mapLabels';
import {
  createMapPlaceSearchSource,
  createMapSearchConfig,
  fetchMapPlaceSearchManifest,
  MAP_SEARCH_TIMEOUT_MS,
  type MapPlaceSearchSource,
} from '../lib/mapSearchIndex';

export interface MapDetailSearchRequest {
  query: string;
  addressQuery: StreetAddressQuery | null;
  origin: { lat: number; lng: number };
  bounds?: [number, number, number, number];
  streetCandidates?: SearchResult[];
}

export type MapDetailSearchProvider = (request: MapDetailSearchRequest) => SearchResult[] | Promise<SearchResult[]>;
export type MapPlaceSearchSourceProvider = () => MapPlaceSearchSource | Promise<MapPlaceSearchSource>;

let mapDetailSearchProvider: MapDetailSearchProvider | null = null;
let mapPlaceSearchSourceProvider: MapPlaceSearchSourceProvider | null = null;

export function setMapDetailSearchProvider(provider: MapDetailSearchProvider | null): () => void {
  mapDetailSearchProvider = provider;
  return () => {
    if (mapDetailSearchProvider === provider) {
      mapDetailSearchProvider = null;
    }
  };
}

export function setMapPlaceSearchSourceProvider(provider: MapPlaceSearchSourceProvider | null): () => void {
  mapPlaceSearchSourceProvider = provider;
  placeSearchSourcePromise = null;
  return () => {
    if (mapPlaceSearchSourceProvider === provider) {
      mapPlaceSearchSourceProvider = null;
      placeSearchSourcePromise = null;
    }
  };
}

export function getSearchResultKey(result: SearchResult): string {
  if (result.id) return result.id;
  const name = result.displayName || result.name;
  return `${name.toLowerCase()}-${result.lat.toFixed(5)}-${result.lng.toFixed(5)}-${result.class}-${result.type}`;
}

export async function searchPlaces(
  query: string,
  mapView: MapView,
  activePlace: ActivePlace | null,
): Promise<SearchResult[]> {
  const trimmed = query.trim();
  if (!trimmed) return [];
  const normalizedQuery = normalizeSearchText(trimmed);
  const viewBounds = mapView.bounds;
  const origin = activePlace
    ? { lat: clampLat(activePlace.lat), lng: normalizeLng(activePlace.lng) }
    : { lat: clampLat(mapView.center[0]), lng: normalizeLng(mapView.center[1]) };

  const addressQuery = parseStreetAddressQuery(trimmed);
  if (addressQuery) {
    const detailAddressResults = await searchMapDetailPlaces({ query: trimmed, addressQuery, origin, bounds: viewBounds });
    if (detailAddressResults.length > 0) {
      return rankSearchResults(dedupeSearchResults(detailAddressResults), normalizedQuery, origin, viewBounds);
    }

    const addressResults = dedupeSearchResults([
      ...await searchStreetAddress(addressQuery, normalizedQuery, origin, viewBounds),
    ]);
    if (addressResults.length > 0) {
      return rankSearchResults(addressResults, normalizedQuery, origin, viewBounds);
    }
  }

  const detailPlaces = (await searchMapDetailPlaces({ query: trimmed, addressQuery: null, origin, bounds: viewBounds }))
    .filter(result => matchesMapSearchQuery(result, trimmed));
  const indexedPlaces = await searchHashtreePlaceIndex(trimmed);
  const localPlaces = detailPlaces.filter(detail => !indexedPlaces.some(indexed => coversMapSegment(indexed, detail)));
  const matches = dedupeSearchResults([...indexedPlaces, ...localPlaces])
    .filter((result) => matchScore(result, normalizedQuery) > 0);
  return rankSearchResults(matches, normalizedQuery, origin, viewBounds);
}

function coversMapSegment(indexed: SearchResult, detail: SearchResult): boolean {
  if (!isStreetResult(indexed) || !isStreetResult(detail) || !indexed.boundingBox
    || !(indexed.contextParts?.length || indexed.context)) return false;
  const names = [indexed.name, ...(indexed.aliases ?? [])].map(normalizeSearchText);
  if (!names.includes(normalizeSearchText(detail.name))) return false;
  const [south, north, west, east] = indexed.boundingBox;
  return detail.lat >= south && detail.lat <= north && detail.lng >= west && detail.lng <= east;
}

let placeSearchSourcePromise: Promise<MapPlaceSearchSource> | null = null;
let labelIndexPromise: Promise<SearchResult[]> | null = null;

async function searchHashtreePlaceIndex(query: string): Promise<SearchResult[]> {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    const results = await Promise.race([
      loadHashtreePlaceSearchSource().then((source) => source.search(query, 50)),
      new Promise<never>((_, reject) => {
        timeout = setTimeout(() => reject(new Error('Map search index timed out')), MAP_SEARCH_TIMEOUT_MS);
      }),
    ]);
    if (results.length > 0) {
      return results;
    }
  } catch (error) {
    console.warn('[mapsSearch] Falling back to map labels:', error);
  } finally {
    clearTimeout(timeout);
  }

  const normalizedQuery = normalizeSearchText(query);
  const labelPlaces = await loadLabelIndex();
  return labelPlaces.filter((result) => matchScore(result, normalizedQuery) > 0);
}

function loadHashtreePlaceSearchSource(): Promise<MapPlaceSearchSource> {
  if (mapPlaceSearchSourceProvider) {
    return Promise.resolve(mapPlaceSearchSourceProvider());
  }
  placeSearchSourcePromise ??= fetchMapPlaceSearchManifest(createMapSearchConfig().url)
    .then(createMapPlaceSearchSource)
    .catch((error) => {
      placeSearchSourcePromise = null;
      throw error;
    });
  return placeSearchSourcePromise;
}

function loadLabelIndex(): Promise<SearchResult[]> {
  labelIndexPromise ??= (import.meta.env.VITE_MAP_LABEL_URL
    ? fetchMapLabels(import.meta.env.VITE_MAP_LABEL_URL)
    : import('../data/mapLabels.json').then((dataset) => dataset.labels as MapLabel[]))
    .then(indexMapLabels)
    .catch((error) => {
      labelIndexPromise = null;
      throw error;
    });
  return labelIndexPromise;
}

async function searchMapDetailPlaces(request: MapDetailSearchRequest): Promise<SearchResult[]> {
  if (!mapDetailSearchProvider) return [];
  try {
    return await mapDetailSearchProvider(request);
  } catch (error) {
    console.warn('[mapsSearch] Loaded map detail lookup failed:', error);
    return [];
  }
}

function dedupeSearchResults(results: SearchResult[]): SearchResult[] {
  const deduped = new Map<string, SearchResult>();
  for (const result of results) {
    const key = getSearchResultKey(result);
    const existing = deduped.get(key);
    if (!existing || (result.importance ?? 0) > (existing.importance ?? 0)) {
      deduped.set(key, result);
    }
  }
  return Array.from(deduped.values());
}

export interface StreetAddressQuery {
  houseNumber: string;
  streetQuery: string;
}

export function parseStreetAddressQuery(query: string): StreetAddressQuery | null {
  const trimmed = query.trim();
  const matches = [...trimmed.matchAll(/\b\d+[a-z]?(?:\s*[-–—−]\s*\d+[a-z]?)?\b/giu)];
  for (let index = matches.length - 1; index >= 0; index -= 1) {
    const match = matches[index];
    const houseNumber = match[0].trim();
    if (!houseNumber || houseNumber.length > 12) continue;
    const start = match.index ?? -1;
    if (start < 0) continue;
    const streetQuery = `${trimmed.slice(0, start)} ${trimmed.slice(start + match[0].length)}`
      .replace(/[,\s]+/g, ' ')
      .trim();
    if (streetQuery && /\p{L}/u.test(streetQuery)) {
      return { houseNumber, streetQuery };
    }
  }
  return null;
}

async function searchStreetAddress(
  addressQuery: StreetAddressQuery,
  normalizedFullQuery: string,
  origin: { lat: number; lng: number },
  viewBounds?: [number, number, number, number],
): Promise<SearchResult[]> {
  try {
    const source = await loadHashtreePlaceSearchSource();
    const normalizedStreetQuery = normalizeSearchText(addressQuery.streetQuery);
    const streetCandidates = (await source.search(addressQuery.streetQuery, 160))
      .filter(isStreetResult)
      .filter((result) => matchScore(result, normalizedStreetQuery) > 0);
    const rankedStreets = rankSearchResults(streetCandidates, normalizedStreetQuery, origin, viewBounds, 120);
    const resolved = await resolveRankedStreetAddresses(source, rankedStreets, addressQuery.houseNumber);
    const detailResolved = resolved.length > 0 ? [] : await searchMapDetailPlaces({
      query: `${addressQuery.houseNumber} ${addressQuery.streetQuery}`.trim(),
      addressQuery,
      origin,
      bounds: viewBounds,
      streetCandidates: rankedStreets,
    });
    return rankSearchResults([...resolved, ...detailResolved], normalizedFullQuery, origin, viewBounds);
  } catch (error) {
    console.warn('[mapsSearch] Address sidecar lookup failed:', error);
    return [];
  }
}

async function resolveRankedStreetAddresses(
  source: MapPlaceSearchSource,
  rankedStreets: SearchResult[],
  houseNumber: string,
): Promise<SearchResult[]> {
  const addressableStreets = rankedStreets
    .filter((street) => street.addressRef)
    .slice(0, 80);
  const batches = [
    addressableStreets.slice(0, 16),
    addressableStreets.slice(16),
  ].filter((batch) => batch.length > 0);

  for (const batch of batches) {
    const resolved = (await Promise.all(
      batch.map((street) => source.resolveAddress(street, houseNumber, 8)),
    )).flat();
    if (resolved.length > 0) return resolved;
  }
  return [];
}

function normalizeLng(lng: number) {
  const wrapped = ((lng + 180) % 360 + 360) % 360 - 180;
  return Number.isFinite(wrapped) ? wrapped : lng;
}

function clampLat(lat: number) {
  return Math.max(-90, Math.min(90, lat));
}

function indexMapLabels(labels: MapLabel[]): SearchResult[] {
  const deduped = new Map<string, SearchResult>();
  for (const label of labels) {
    const result = mapLabelToSearchResult(label);
    const key = getSearchResultKey(result);
    const existing = deduped.get(key);
    if (!existing || (result.importance ?? 0) > (existing.importance ?? 0)) {
      deduped.set(key, result);
    }
  }
  return Array.from(deduped.values());
}

function mapLabelToSearchResult(label: MapLabel): SearchResult {
  const isCountry = label.kind === 'country';
  const populationImportance = label.population
    ? Math.min(1, Math.log10(Math.max(10, label.population)) / 8)
    : 0;
  return {
    name: label.name,
    lat: label.lat,
    lng: label.lng,
    type: isCountry ? 'country' : 'city',
    class: isCountry ? 'boundary' : 'place',
    displayName: isCountry ? 'Country' : 'City',
    placeRank: isCountry ? 4 : 16,
    importance: isCountry ? 1 : populationImportance,
    addressType: isCountry ? 'country' : 'city',
  };
}

function distanceKm(aLat: number, aLng: number, bLat: number, bLng: number) {
  const toRad = (value: number) => value * Math.PI / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const lat1 = toRad(aLat);
  const lat2 = toRad(bLat);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const a = sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function areaKm2(box?: [number, number, number, number]) {
  if (!box) return 0;
  const [south, north, west, east] = box;
  const height = distanceKm(south, west, north, west);
  const midLat = (south + north) / 2;
  const width = distanceKm(midLat, west, midLat, east);
  return Math.max(0, height * width);
}

function isWithinBounds(lat: number, lng: number, box?: [number, number, number, number]) {
  if (!box) return false;
  const [south, north, west, east] = box;
  const withinLat = lat >= south && lat <= north;
  const withinLng = west <= east
    ? lng >= west && lng <= east
    : lng >= west || lng <= east;
  return withinLat && withinLng;
}

function isSettlementResult(result: SearchResult) {
  return result.class === 'place'
    || ['city', 'town', 'village', 'hamlet'].includes(result.type);
}

function isBoundaryResult(result: SearchResult) {
  return result.class === 'boundary' || result.type === 'administrative';
}

function isAddressResult(result: SearchResult) {
  return result.addressType === 'house'
    || result.addressType === 'building'
    || result.class === 'building'
    || result.type === 'house';
}

function isStreetResult(result: SearchResult) {
  return result.addressType === 'road'
    || result.class === 'highway'
    || result.sourceLayer === 'transportation_name';
}

function isCountryResult(result: SearchResult) {
  return result.addressType === 'country'
    || (isBoundaryResult(result) && (result.placeRank ?? 99) <= 4);
}

function isRegionResult(result: SearchResult) {
  return result.addressType === 'state'
    || (isBoundaryResult(result) && (result.placeRank ?? 99) <= 8);
}

function matchScore(result: SearchResult, normalizedQuery: string) {
  if (!normalizedQuery) return 0;
  const primaryScore = scoreSearchText(normalizeSearchText(result.name), normalizedQuery);
  const displayScore = Math.min(950, scoreSearchText(normalizeSearchText(result.displayName), normalizedQuery));
  const contextScore = Math.min(760, scoreSearchText(normalizeSearchText(result.context ?? ''), normalizedQuery));
  const aliasScore = Math.max(0, ...((result.aliases ?? [])
    .map((alias) => Math.max(0, scoreSearchText(normalizeSearchText(alias), normalizedQuery) - 35))));
  const combinedScore = scoreCombinedSearchText(result, normalizedQuery);
  return Math.max(primaryScore, displayScore, contextScore, aliasScore, combinedScore);
}

function scoreSearchText(searchText: string, normalizedQuery: string) {
  if (!searchText) return 0;
  if (searchText === normalizedQuery) return 1000;
  if (searchText.startsWith(normalizedQuery)) return 900;
  const tokens = searchText.split(' ');
  if (tokens.includes(normalizedQuery)) return 850;
  if (tokens.some(token => token.startsWith(normalizedQuery))) return 780;
  if (searchText.includes(normalizedQuery)) return 620;
  return 0;
}

function scoreCombinedSearchText(result: SearchResult, normalizedQuery: string) {
  const tokens = normalizedQuery.split(' ').filter(Boolean);
  if (tokens.length <= 1) return 0;
  const combined = mapSearchResultText(result);
  if (!combined) return 0;
  const combinedTokens = combined.split(' ');
  let matched = 0;
  let exact = 0;
  for (const token of tokens) {
    if (combinedTokens.includes(token)) {
      matched += 1;
      exact += 1;
    } else if (combinedTokens.some((candidate) => candidate.startsWith(token))) {
      matched += 1;
    }
  }
  if (matched === 0) return 0;
  if (matched === tokens.length) return exact === tokens.length ? 910 : 860;
  return 0;
}

function rankSearchResults(
  results: SearchResult[],
  normalizedQuery: string,
  origin: { lat: number; lng: number },
  bounds?: [number, number, number, number],
  limit = 10,
): SearchResult[] {
  return results
    .map(result => {
      const distance = distanceKm(origin.lat, origin.lng, result.lat, result.lng);
      const within = isWithinBounds(result.lat, result.lng, bounds);
      const importance = result.importance ?? 0;
      const isHighway = result.class === 'highway' || result.type === 'road';
      const isBoundary = isBoundaryResult(result);
      const isSettlement = isSettlementResult(result);
      const isAddress = isAddressResult(result);
      const isCountry = isCountryResult(result);
      const match = matchScore(result, normalizedQuery);
      const queryLength = normalizedQuery.length;
      const placeRank = result.placeRank ?? 30;
      const placeRankBoost = Math.max(0, 24 - placeRank) * 12;
      const placeRankPenalty = placeRank > 26 ? (placeRank - 26) * 18 : 0;
      const cityBoost = result.type === 'city' ? 120
        : result.type === 'town' ? 60
          : result.type === 'village' ? 20
            : 0;
      const highwayPenalty = (isHighway && queryLength <= 10 && match < 850) ? 180 : 0;
      const boundaryPenalty = (isBoundary && queryLength <= 10 && match < 850) ? 60 : 0;
      const addressPenalty = (isAddress && queryLength <= 16 && match < 900) ? 260 : 0;
      const settlementBoost = (isSettlement && queryLength <= 12) ? 80 : 0;
      const resultArea = areaKm2(result.boundingBox);
      const areaBoost = resultArea > 0 ? Math.min(200, Math.log10(resultArea + 1) * 18) : 0;
      const adminBoost = isCountry ? 320 : isRegionResult(result) ? 160 : 0;
      const viewportArea = areaKm2(bounds);
      const localExactViewportBoost = !isCountry && within && match >= 850 && viewportArea > 0 && viewportArea <= 2500
        ? 520
        : 0;
      const withinBoost = within ? (match >= 850 ? 40 : 120) : 0;
      const distancePenalty = isCountry
        ? (match >= 850 ? distance / 200 : distance / 80)
        : match >= 850
          ? distance / 120
          : match >= 700
            ? distance / 30
            : distance / 12;
      const score = withinBoost
        + (importance * 60)
        + match
        + adminBoost
        + areaBoost
        + localExactViewportBoost
        + settlementBoost
        + cityBoost
        + placeRankBoost
        - distancePenalty
        - highwayPenalty
        - boundaryPenalty
        - addressPenalty
        - placeRankPenalty;
      return { result, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(entry => entry.result);
}
