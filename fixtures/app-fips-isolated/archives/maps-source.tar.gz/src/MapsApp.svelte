<script lang="ts">
  /**
   * MapsApp - Map-focused app shell for maps.iris.to
   * OpenStreetMap-based maps with offline-first sync via HashTree
   */
  import { onMount } from 'svelte';
  import Logo from './components/Logo.svelte';
  import Header from './components/Header.svelte';
  import NostrLogin from './components/NostrLogin.svelte';
  import SettingsShortcut from '@iris/hashtree-app/SettingsShortcut.svelte';
  import ConnectivityIndicator from './components/ConnectivityIndicator.svelte';
  import BandwidthIndicator from './components/BandwidthIndicator.svelte';
  import { settingsStore } from './stores/settings';
  import { appStore } from './store';
  import { nostrStore } from './nostr';
  import Toast from './components/Toast.svelte';
  import { currentPath, initRouter } from './lib/router.svelte';
  import MapsRouter from './components/Maps/MapsRouter.svelte';

  // Header display settings
  let showBandwidth = $derived($settingsStore.pools.showBandwidth ?? false);
  let showConnectivity = $derived($settingsStore.pools.showConnectivity ?? false);
  let totalConnections = $derived($nostrStore.connectedRelays + $appStore.peerCount);
  let showConnectivityWarning = $derived(totalConnections === 0);

  onMount(() => {
    initRouter();
  });

  function handleLogoClick(e: MouseEvent) {
    // If already on home page, scroll to top instead of navigating
    if (window.location.hash === '#/' || window.location.hash === '' || window.location.hash === '#') {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  let currentPathValue = $derived($currentPath);
  let showFullscreenMap = $derived(currentPathValue === '/');
</script>

<div class="h-full flex flex-col bg-surface-0">
  {#if !showFullscreenMap}
    <Header>
      <div class="flex items-center shrink-0">
        <a href="#/" class="no-underline select-none" onclick={handleLogoClick}>
          <Logo app="maps" />
        </a>
      </div>
      <div class="flex-1"></div>
      <div class="flex items-center gap-2 md:gap-3 shrink-0">
        {#if showBandwidth}
          <BandwidthIndicator />
        {/if}
        {#if showConnectivity || showConnectivityWarning}
          <ConnectivityIndicator />
        {/if}
        <SettingsShortcut />
        <NostrLogin />
      </div>
    </Header>
  {/if}

  <div class="flex-1 flex flex-col min-h-0">
    <MapsRouter currentPath={$currentPath} />
  </div>

  <!-- Modals -->
  <Toast />
</div>
