/**
 * Tracks which app variant is currently running
 * Set by the app entry point.
 */
export type AppType = 'maps';

export interface FolderCreationBehavior {
  actionLabel: string;
  modalTitle: string;
  placeholder: string;
  createsGitRepo: boolean;
}

let currentAppType: AppType = 'maps';

const DEFAULT_FOLDER_CREATION_BEHAVIOR: FolderCreationBehavior = {
  actionLabel: 'New Folder',
  modalTitle: 'New Folder',
  placeholder: 'Folder name...',
  createsGitRepo: false,
};

export function setAppType(type: AppType) {
  currentAppType = type;
}

export function getAppType(): AppType {
  return currentAppType;
}

export function isFilesApp(): boolean {
  return false;
}

export function isGitApp(): boolean {
  return false;
}

export function isMapsApp(): boolean {
  return currentAppType === 'maps';
}

export function supportsDocumentFeatures(): boolean {
  return false;
}

export function supportsGitFeatures(): boolean {
  return false;
}

export function shouldAssumeGitRepoDuringDetection(): boolean {
  return false;
}

export function shouldShowGenericFileBrowser(): boolean {
  return true;
}

export function shouldOpenSourceCodeLinkInNewTab(): boolean {
  return true;
}

export function getFolderCreationBehavior(): FolderCreationBehavior {
  return DEFAULT_FOLDER_CREATION_BEHAVIOR;
}
