import 'virtual:uno.css';
import 'maplibre-gl/dist/maplibre-gl.css';
import { setWorkerUrl } from 'maplibre-gl';
import mapWorkerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?url';
import MapsApp from './MapsApp.svelte';
import { mount } from 'svelte';
import { initServiceWorker } from './lib/swInit';
import { restoreSession, initReadonlyBackend } from './nostr/auth';
import { setAppType } from './appType';
import { initHtreeApi } from './lib/htreeApi';
import { ensureMediaStreamingReady } from './lib/mediaStreamingSetup';

setAppType('maps');
setWorkerUrl(mapWorkerUrl);

async function init() {
  await initServiceWorker().catch((error) => {
    console.error('[main-maps] Service worker initialization failed:', error);
  });
  const htreePromise = initHtreeApi();
  const backendPromise = initReadonlyBackend();
  const sessionPromise = restoreSession();
  mount(MapsApp, {
    target: document.getElementById('app')!,
  });

  const mediaPromise = backendPromise
    .then(() => ensureMediaStreamingReady(3, 250).catch(() => false))
    .catch((error) => {
      console.error('[main-maps] Backend initialization failed:', error);
      return false;
    });
  sessionPromise.catch((error) => {
    console.error('[main-maps] Session restore failed:', error);
  });
  htreePromise.catch((error) => {
    console.error('[main-maps] htree API initialization failed:', error);
  });
  void Promise.allSettled([sessionPromise, htreePromise, mediaPromise]);
}

init().catch((error) => {
  console.error('[main-maps] Startup failed:', error);
});
if (import.meta.env.DEV && import.meta.env.VITE_TEST_MODE) {
  void import('./lib/testHelpers').then(({ setupTestHelpers }) => setupTestHelpers());
}
