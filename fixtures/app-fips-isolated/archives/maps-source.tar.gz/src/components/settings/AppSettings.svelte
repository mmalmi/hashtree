<script lang="ts">
  import CopyButton from '@iris/svelte-ui/CopyButton.svelte';
  import { shouldOpenSourceCodeLinkInNewTab } from '../../appType';
  import { MAP_BASEMAP_STYLE_PREFERENCES, type MapBasemapStylePreference } from '../../lib/mapStylePreference';
  import { getCanonicalGitRepositoryUrl } from '../../lib/shareUrls';
  import { getNsec } from '../../nostr';
  import { settingsStore } from '../../stores/settings';

  const openSourceCodeInNewTab = shouldOpenSourceCodeLinkInNewTab();
  const sourceCodeLinkTarget = openSourceCodeInNewTab ? '_blank' : '_self';
  const sourceCodeLinkRel = openSourceCodeInNewTab ? 'noopener noreferrer' : undefined;
  const hashtreeDevUrl = 'https://hashtree.cc/#/dev';
  const sourceCodeUrl = getCanonicalGitRepositoryUrl('iris-maps');

  let nsec = $derived(getNsec());
  let mapStylePreference = $derived($settingsStore.map.style);
  let selectedMapStyle = $derived(
    MAP_BASEMAP_STYLE_PREFERENCES.find((option) => option.id === mapStylePreference)
      ?? MAP_BASEMAP_STYLE_PREFERENCES[0],
  );

  function setMapStyle(event: Event) {
    const select = event.currentTarget as HTMLSelectElement;
    settingsStore.setMapSettings({ style: select.value as MapBasemapStylePreference });
  }
</script>

<div class="space-y-6">
  <div>
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
      Map
    </h3>
    <div class="bg-surface-2 rounded p-3 space-y-3">
      <label class="flex items-center justify-between gap-3">
        <span class="text-sm text-text-2">Style</span>
        <select
          class="bg-surface-1 text-text-1 border border-surface-3 rounded px-3 py-2 text-sm min-w-36"
          value={mapStylePreference}
          onchange={setMapStyle}
          data-testid="settings-map-style-select"
        >
          {#each MAP_BASEMAP_STYLE_PREFERENCES as option}
            <option value={option.id}>{option.label}</option>
          {/each}
        </select>
      </label>
      <p class="text-xs text-text-3">{selectedMapStyle.description}</p>
    </div>
  </div>

  <!-- Account (only show when logged in with nsec) -->
  {#if nsec}
    <div>
      <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
        Account
      </h3>
      <div class="bg-surface-2 rounded p-3">
        <CopyButton
          text={nsec}
          label="Copy secret key"
          copiedLabel="Copied"
          class="btn-ghost flex items-center gap-2 text-sm w-full justify-start"
          iconClass="i-lucide-key"
          copiedIconClass="i-lucide-check text-success"
          testId="copy-secret-key"
        />
      </div>
    </div>
  {/if}

  <!-- About -->
  <div>
    <h3 class="text-xs font-medium text-muted uppercase tracking-wide mb-3">
      About
    </h3>
    <p class="text-sm text-text-2 mb-3">
      Built on
      <a
        href={hashtreeDevUrl}
        target="_blank"
        rel="noopener noreferrer"
        class="ml-1 no-underline text-text-1 hover:text-text-0"
      >
        hashtree
      </a>
    </p>
    <div class="bg-surface-2 rounded p-3 text-sm space-y-3">
      <div class="flex justify-between items-center">
        <span class="text-muted">Build</span>
        <span class="text-text-1 font-mono text-xs">
          {(() => {
            const buildTime = import.meta.env.VITE_BUILD_TIME;
            if (!buildTime || buildTime === 'undefined') return 'development';
            try {
              return new Date(buildTime).toLocaleString();
            } catch {
              return buildTime;
            }
          })()}
        </span>
      </div>
      <a
        href={sourceCodeUrl}
        target={sourceCodeLinkTarget}
        rel={sourceCodeLinkRel}
        class="btn-ghost w-full flex items-center justify-center gap-2 no-underline"
      >
        <span class="i-lucide-code text-sm"></span>
        <span>iris-maps</span>
        <span class="text-text-3 text-xs no-underline">(source code)</span>
      </a>
      <button
        onclick={() => window.location.reload()}
        class="btn-ghost w-full flex items-center justify-center gap-2"
      >
        <span class="i-lucide-refresh-cw text-sm"></span>
        <span>Refresh App</span>
      </button>
    </div>
  </div>
</div>
