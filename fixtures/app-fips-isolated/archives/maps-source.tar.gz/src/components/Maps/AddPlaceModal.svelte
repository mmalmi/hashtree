<script lang="ts">
  import { mapsStore, type PlaceCategory } from '../../stores/mapsStore.svelte';
  import { nostrStore } from '../../nostr';
  import { setActivePlaceInHash } from '../../lib/mapsUrl';
  import { PLACE_CATEGORY_OPTIONS } from '../../lib/placeTypeIcons';

  let name = $state('');
  let category = $state<PlaceCategory>('restaurant');
  let description = $state('');
  let contact = $state('');
  let hours = $state('');
  let selectedCategoryOption = $derived(PLACE_CATEGORY_OPTIONS.find((option) => option.value === category) ?? PLACE_CATEGORY_OPTIONS[0]);

  function handleClose() {
    mapsStore.closeAddPlaceModal();
    resetForm();
  }

  function resetForm() {
    name = '';
    category = 'restaurant';
    description = '';
    contact = '';
    hours = '';
  }

  async function handleSave() {
    const location = mapsStore.pendingPlaceLocation;
    if (!name.trim() || !location) return;

    const place = await mapsStore.addPlace({
      name: name.trim(),
      category,
      lat: location.lat,
      lng: location.lng,
      description: description.trim() || undefined,
      contact: contact.trim() || undefined,
      hours: hours.trim() || undefined,
      owner: $nostrStore.npub || 'anonymous',
    });
    if (mapsStore.places.some(item => item.id === place.id)) {
      const activePlace = mapsStore.activePlaceFromPlace(place);
      mapsStore.setActivePlace(activePlace);
      setActivePlaceInHash(activePlace);
    }

    handleClose();
  }

  function handleKeydown(e: KeyboardEvent) {
    if (e.key === 'Escape') {
      handleClose();
    }
  }
</script>

<svelte:window onkeydown={handleKeydown} />

{#if mapsStore.isAddPlaceModalOpen}
  <!-- Side panel that doesn't block map interaction -->
  <div
    class="fixed left-4 top-24 z-[10001] max-h-[calc(100vh-7rem)] w-80 overflow-y-auto rounded-xl bg-surface-1/94 p-4 text-text-1 shadow-sm backdrop-blur-md"
    role="dialog"
    aria-modal="false"
    aria-labelledby="modal-title"
  >
    <div class="mb-4 flex items-center justify-between">
      <h2 id="modal-title" class="text-xl font-semibold">Add Place</h2>
      <button type="button" onclick={handleClose} class="text-text-2 hover:text-text-1" title="Close">
        <span class="i-lucide-x text-xl"></span>
      </button>
    </div>

    <div class="space-y-3">
      <div>
        <label for="place-name" class="block text-sm font-medium mb-1">Name</label>
        <input
          id="place-name"
          type="text"
          placeholder="Place name..."
          bind:value={name}
          class="w-full rounded-md border border-transparent bg-surface-2/70 px-3 py-2 text-text-1 outline-none placeholder:text-text-3 focus:bg-surface-0/90 focus:ring-2 focus:ring-accent/25"
        />
      </div>

      <div>
        <label for="place-category" class="mb-1 block text-sm font-medium">Category</label>
        <div class="relative">
          <span class="{selectedCategoryOption.iconClass} pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-lg text-accent" aria-hidden="true"></span>
          <select
            id="place-category"
            bind:value={category}
            class="h-10 w-full appearance-none rounded-md border border-transparent bg-surface-2/70 pl-10 pr-10 text-sm text-text-1 outline-none focus:bg-surface-0/90 focus:ring-2 focus:ring-accent/25"
          >
            {#each PLACE_CATEGORY_OPTIONS as cat (cat.value)}
              <option value={cat.value}>{cat.label}</option>
            {/each}
          </select>
          <span class="i-lucide-chevron-down pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-base text-text-3" aria-hidden="true"></span>
        </div>
      </div>

      <div>
        <label for="place-description" class="block text-sm font-medium mb-1">Description</label>
        <textarea
          id="place-description"
          placeholder="Optional description..."
          bind:value={description}
          rows="2"
          class="w-full resize-none rounded-md border border-transparent bg-surface-2/70 px-3 py-2 text-text-1 outline-none placeholder:text-text-3 focus:bg-surface-0/90 focus:ring-2 focus:ring-accent/25"
        ></textarea>
      </div>

      <div>
        <label for="place-contact" class="block text-sm font-medium mb-1">Contact</label>
        <input
          id="place-contact"
          type="text"
          placeholder="Phone, email, website..."
          bind:value={contact}
          class="w-full rounded-md border border-transparent bg-surface-2/70 px-3 py-2 text-text-1 outline-none placeholder:text-text-3 focus:bg-surface-0/90 focus:ring-2 focus:ring-accent/25"
        />
      </div>

      <div>
        <label for="place-hours" class="block text-sm font-medium mb-1">Hours</label>
        <input
          id="place-hours"
          type="text"
          placeholder="e.g., Mon-Fri 9am-5pm"
          bind:value={hours}
          class="w-full rounded-md border border-transparent bg-surface-2/70 px-3 py-2 text-text-1 outline-none placeholder:text-text-3 focus:bg-surface-0/90 focus:ring-2 focus:ring-accent/25"
        />
      </div>

      {#if !mapsStore.pendingPlaceLocation}
        <p class="text-sm text-text-2">Click on the map to set the location.</p>
      {:else}
        <p class="text-sm text-text-2">
          Location: {mapsStore.pendingPlaceLocation.lat.toFixed(5)}, {mapsStore.pendingPlaceLocation.lng.toFixed(5)}
        </p>
      {/if}
    </div>

    <div class="mt-4 flex justify-end gap-3">
      <button
        type="button"
        onclick={handleClose}
        class="h-9 rounded-full px-4 text-sm font-medium text-text-2 hover:bg-surface-2 hover:text-text-1"
      >
        Cancel
      </button>
      <button
        type="button"
        onclick={handleSave}
        disabled={!name.trim() || !mapsStore.pendingPlaceLocation}
        class="h-9 rounded-full bg-accent px-4 text-sm font-medium text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
      >
        Save
      </button>
    </div>
  </div>
{/if}
