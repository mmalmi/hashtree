<script lang="ts">
  import { onMount } from 'svelte';
  import { Avatar } from '../User';
  import { navigate } from '../../utils/navigate';
  import { nostrStore } from '../../nostr';

  let open = $state(false);
  let buttonRef: HTMLButtonElement | undefined = $state();
  let menuRef: HTMLDivElement | undefined = $state();
  let isLoggedIn = $derived($nostrStore.isLoggedIn);
  let pubkey = $derived($nostrStore.pubkey);

  function closeMenu() {
    open = false;
  }

  function goTo(path: string) {
    navigate(path);
    closeMenu();
  }

  onMount(() => {
    function handlePointerDown(event: PointerEvent) {
      if (!open) return;
      const target = event.target as Node | null;
      if (!target) return;
      if (buttonRef?.contains(target) || menuRef?.contains(target)) return;
      closeMenu();
    }

    function handleKeydown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        closeMenu();
      }
    }

    window.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('keydown', handleKeydown);
    return () => {
      window.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('keydown', handleKeydown);
    };
  });
</script>

<div class="relative">
  <button
    bind:this={buttonRef}
    type="button"
    class="grid place-items-center rounded-full border-0 bg-transparent p-0 text-text-1 transition-opacity hover:opacity-85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent {isLoggedIn && pubkey ? 'h-9 w-9' : 'h-10 w-10 hover:bg-surface-2'}"
    title="Account"
    aria-label="Account"
    aria-haspopup="menu"
    aria-expanded={open}
    onclick={() => {
      open = !open;
    }}
  >
    {#if isLoggedIn && pubkey}
      <Avatar {pubkey} size={36} class="!bg-white/90" />
    {:else}
      <span class="i-lucide-user text-xl text-text-2"></span>
    {/if}
  </button>

  {#if open}
    <div
      bind:this={menuRef}
      class="absolute right-0 top-[calc(100%+0.5rem)] w-56 overflow-hidden rounded-lg bg-surface-1/96 py-1 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md"
      role="menu"
    >
      <button
        type="button"
        class="flex w-full items-center gap-3 px-3 py-2 text-left text-sm text-text-1 hover:bg-surface-2"
        role="menuitem"
        onclick={() => goTo('/settings')}
      >
        <span class="i-lucide-settings text-base text-text-2"></span>
        <span>Settings</span>
      </button>
      <button
        type="button"
        class="flex w-full items-center gap-3 px-3 py-2 text-left text-sm text-text-1 hover:bg-surface-2"
        role="menuitem"
        onclick={() => goTo('/users')}
      >
        <span class="i-lucide-users text-base text-text-2"></span>
        <span>Switch user</span>
      </button>
    </div>
  {/if}
</div>
