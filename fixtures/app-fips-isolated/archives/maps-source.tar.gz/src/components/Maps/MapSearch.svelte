<script lang="ts">
  import { onMount } from 'svelte';
  import { mapsStore, getSearchResultKey } from '../../stores/mapsStore.svelte';
  import type { SearchResult } from '../../stores/mapsTypes';
  import { internalMapsRouteFromInput } from '../../lib/mapsUrl';
  import { resultDisplayLine } from '../../lib/mapSearchResultDetails';

  let {
    onSelect,
    activePlaceName = '',
    onClosePlace,
    onBack,
    onOpenLibrary,
    libraryOpen = false,
    onQueryChange,
    searchMode = 'map',
    placeholder = 'Search',
    theme = 'dark',
  }: {
    onSelect: (result: SearchResult) => void;
    activePlaceName?: string;
    onClosePlace?: () => void;
    onBack?: () => void;
    onOpenLibrary?: () => void;
    libraryOpen?: boolean;
    onQueryChange?: (query: string) => void;
    searchMode?: 'map' | 'list';
    placeholder?: string;
    theme?: 'light' | 'dark';
  } = $props();

  let inputValue = $state('');
  let selectedIndex = $state(0);
  let containerRef: HTMLDivElement | undefined = $state();
  let dropdownRef: HTMLDivElement | undefined = $state();
  let inputRef: HTMLInputElement | undefined = $state();
  let debounceTimer: ReturnType<typeof setTimeout> | null = null;

  function updateDropdownPosition() {
    if (containerRef && dropdownRef) {
      const rect = containerRef.getBoundingClientRect();
      dropdownRef.style.top = `${rect.bottom + 4}px`;
      dropdownRef.style.left = `${rect.left}px`;
      dropdownRef.style.width = `${rect.width}px`;
    }
  }

  // Portal dropdown to body to escape header's stacking context
  onMount(() => {
    if (dropdownRef) {
      document.body.appendChild(dropdownRef);
    }
    const focusTimer = window.setTimeout(() => {
      if (window.matchMedia('(min-width: 640px)').matches) {
        inputRef?.focus();
      }
    }, 0);
    return () => {
      clearTimeout(focusTimer);
      cancelSearch();
      if (dropdownRef && dropdownRef.parentNode === document.body) {
        document.body.removeChild(dropdownRef);
      }
    };
  });

  // Update position when results change
  $effect(() => {
    if (mapsStore.searchResults.length > 0 || mapsStore.isSearching) {
      updateDropdownPosition();
    }
  });

  function handleInput(e: Event) {
    let value = (e.target as HTMLInputElement).value;
    if (shouldReplaceActivePlaceValue() && value.length > activePlaceName.length && value.startsWith(activePlaceName)) {
      value = value.slice(activePlaceName.length);
      if (inputRef) {
        inputRef.value = value;
        inputRef.setSelectionRange(value.length, value.length);
      }
    }
    const internalRoute = internalMapsRouteFromInput(value);
    if (internalRoute) {
      resetInput();
      window.location.hash = internalRoute;
      return;
    }

    inputValue = value;
    scheduleSearch(value);
  }

  function scheduleSearch(value: string) {
    cancelSearch();
    selectedIndex = 0;
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      if (searchMode === 'list') {
        onQueryChange?.(value);
        return;
      }
      void mapsStore.search(value);
      updateDropdownPosition();
    }, 300);
  }

  function replaceActivePlaceValue(value: string) {
    inputValue = value;
    selectedIndex = 0;
    if (inputRef) {
      inputRef.value = value;
      inputRef.setSelectionRange(value.length, value.length);
    }
    scheduleSearch(value);
  }

  function shouldReplaceActivePlaceValue() {
    return Boolean(activePlaceName && !inputValue);
  }

  function handleSelect(result: SearchResult) {
    resetInput();
    onSelect(result);
  }

  function cancelSearch() {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = null;
    mapsStore.clearSearch();
  }

  function resetInput() {
    cancelSearch();
    inputValue = '';
    selectedIndex = 0;
  }

  function handleClear() {
    resetInput();
    onQueryChange?.('');
  }

  function handleClosePlace() {
    resetInput();
    onClosePlace?.();
  }

  function handleBack() {
    resetInput();
    onQueryChange?.('');
    onBack?.();
  }

  function handleKeydown(e: KeyboardEvent) {
    if (
      shouldReplaceActivePlaceValue()
      && e.key.length === 1
      && !e.altKey
      && !e.ctrlKey
      && !e.metaKey
    ) {
      e.preventDefault();
      replaceActivePlaceValue(e.key);
      return;
    }

    const results = mapsStore.searchResults;
    if (results.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        selectedIndex = (selectedIndex + 1) % results.length;
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        selectedIndex = (selectedIndex - 1 + results.length) % results.length;
        return;
      }
      if (e.key === 'Enter' && results[selectedIndex]) {
        e.preventDefault();
        handleSelect(results[selectedIndex]);
        return;
      }
    }
    if (e.key === 'Escape') {
      cancelSearch();
    }
  }

  function handlePaste(e: ClipboardEvent) {
    if (!shouldReplaceActivePlaceValue()) return;
    const text = e.clipboardData?.getData('text')?.trim();
    if (!text) return;
    e.preventDefault();
    replaceActivePlaceValue(text);
  }

  function handleFocus() {
    updateDropdownPosition();
    if (!inputRef || !activePlaceName || inputValue) return;
    requestAnimationFrame(() => {
      if (document.activeElement === inputRef && !inputValue && activePlaceName) {
        inputRef.select();
      }
    });
  }
</script>

<div bind:this={containerRef} class="relative w-full min-w-0" data-testid="map-search">
  <div class="flex h-12 items-center gap-2 rounded-full bg-surface-1/94 px-2 shadow-[0_2px_8px_rgb(0_0_0/0.22)] ring-1 ring-surface-3/80 backdrop-blur-md">
    {#if onBack}
      <button
        type="button"
        class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
        title="Back"
        aria-label="Back"
        onclick={handleBack}
      >
        <span class="i-lucide-arrow-left text-lg"></span>
      </button>
    {:else if onOpenLibrary}
      <button
        type="button"
        class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
        title={libraryOpen ? 'Close library' : 'Open menu'}
        aria-label={libraryOpen ? 'Close library' : 'Open library'}
        aria-expanded={libraryOpen}
        onclick={onOpenLibrary}
      >
        <span class="{libraryOpen ? 'i-lucide-panel-left-close' : 'i-lucide-menu'} text-lg"></span>
      </button>
    {/if}
    <input
      bind:this={inputRef}
    type="text"
      placeholder={placeholder}
      value={inputValue || activePlaceName}
      oninput={handleInput}
      onkeydown={handleKeydown}
      onpaste={handlePaste}
      onfocus={handleFocus}
      class="h-9 min-w-0 flex-1 bg-transparent text-base text-text-1 placeholder:text-text-3 border-none outline-none {onBack || onOpenLibrary ? '' : 'pl-3'}"
      data-testid="search-input"
    />
    {#if inputValue}
      <button
        type="button"
        onclick={handleClear}
        class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
        title="Clear"
        aria-label="Clear search"
      >
        <span class="i-lucide-x text-lg"></span>
      </button>
    {:else if activePlaceName}
      <span class="i-lucide-search text-base text-text-2 shrink-0 px-1"></span>
      <button
        type="button"
        onclick={handleClosePlace}
        class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
        title="Close"
        aria-label="Close place"
      >
        <span class="i-lucide-x text-lg"></span>
      </button>
    {:else}
      <span class="i-lucide-search text-base text-text-2 shrink-0 px-2"></span>
    {/if}
  </div>
</div>

<div
  bind:this={dropdownRef}
  class="iris-map-theme-{theme} fixed z-[10003] max-h-80 overflow-auto rounded-lg bg-surface-1/96 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md"
  class:hidden={searchMode === 'list' || (mapsStore.searchResults.length === 0 && !mapsStore.isSearching)}
  data-testid="search-results"
>
  {#if mapsStore.isSearching && inputValue}
    <div class="p-3 text-muted text-center text-sm">
      Searching...
    </div>
  {:else}
    {#each mapsStore.searchResults as result, index (getSearchResultKey(result))}
      <button
        type="button"
        onclick={() => handleSelect(result)}
        onmouseenter={() => selectedIndex = index}
        class="flex h-11 w-full items-center gap-3 px-3 text-left {index === selectedIndex ? 'bg-surface-3' : 'hover:bg-surface-2'}"
      >
        <span class="i-lucide-map-pin text-lg text-text-3 shrink-0"></span>
        <span class="min-w-0 flex-1 truncate text-sm font-medium text-text-1">{resultDisplayLine(result)}</span>
      </button>
    {/each}
  {/if}
</div>
