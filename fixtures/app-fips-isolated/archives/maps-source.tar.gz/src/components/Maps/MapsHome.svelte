<script lang="ts">
  import type { GeoJSONSourceSpecification } from 'maplibre-gl';
  type MeasureDistanceCollection = Extract<GeoJSONSourceSpecification['data'], { type: 'FeatureCollection' }>;
  import { normalizeMapSearchText as normalizeMapDetailSearchText } from '../../lib/mapSearchText';
  import { resultContextSummary } from '../../lib/mapSearchResultDetails';
  /**
   * MapsHome - Map view for maps.iris.to
   */
  import { onMount } from 'svelte';
  import * as maplibregl from 'maplibre-gl';
  import {
    type IControl,
    type LngLatBoundsLike,
    type Map as MapLibreMap,
    type MapGeoJSONFeature,
    type MapMouseEvent,
    type Marker,
    type Popup,
    type StyleSpecification,
  } from 'maplibre-gl';
  import type { Event as NostrEvent, Filter as NostrFilter } from 'nostr-tools';
  import type { CID } from '@hashtree/core';
  import { PMTiles, Protocol } from 'pmtiles';
  import MapSearch from './MapSearch.svelte';
  import MapAccountMenu from './MapAccountMenu.svelte';
  import AddPlaceModal from './AddPlaceModal.svelte';
  import ConnectivityIndicator from '../ConnectivityIndicator.svelte';
  import BandwidthIndicator from '../BandwidthIndicator.svelte';
  import { mapsStore } from '../../stores/mapsStore.svelte';
  import { setMapDetailSearchProvider, type MapDetailSearchRequest } from '../../stores/mapsSearch';
  import type { ActivePlace, Place, SavedPlaceList, SavedPlaceListVisibility, SearchResult } from '../../stores/mapsStore.svelte';
  import { currentHash } from '../../stores/route';
  import {
    parseActivePlaceFromHash,
    parseSavedPlaceListRouteFromHash,
    setActivePlaceInHash,
    type SavedPlaceListRoute,
  } from '../../lib/mapsUrl';
  import { getRefResolver, getResolverKey } from '../../refResolver';
  import { createMapBasemapConfig } from '../../lib/mapBasemap';
  import { withHtreeClientKey } from '../../lib/htreeClientKey';
  import { reviewMediaDisplayUrl } from '../../lib/reviewMedia';
  import { uploadReviewMediaFile, type ReviewMediaUploadProgress } from '../../lib/reviewMediaUpload';
  import { canPlaceHaveReviews } from '../../lib/placeReviewEligibility';
  import { buildSavedPlaceListUrls, normalizeSavedPlaceListUrls } from '../../lib/savedPlaceListUrls';
  import {
    loadSavedExternalPlaceLists,
    removeSavedExternalPlaceList,
    saveSavedExternalPlaceLists,
    savedExternalPlaceListHash,
    savedExternalPlaceListKey,
    upsertSavedExternalPlaceList,
    type SavedExternalPlaceList,
  } from '../../lib/savedExternalPlaceLists';
  import { BTCMAP_LIST_DESCRIPTION } from '../../lib/btcMapListMetadata';
  import { createPmtilesVectorTileReader, distanceToLineStringsMeters, mapFeatureNames, mapFeatureHouseNumber, searchStreetAddressInVectorTiles, type VectorTileReader } from '../../lib/mapTileAddressSearch';
  import { displayPlaceTypeLabel, placeTypeIconClass } from '../../lib/placeTypeIcons';
  import {
    SAVED_PLACE_LIST_MANIFEST_FILE,
    normalizeSavedPlaceListItems,
    normalizeSavedPlaceListManifest,
    savedPlaceListItemPageFile,
    savedPlaceListDirectoryPath,
    type SavedPlaceListManifest,
    type SavedPlaceListItemsSource,
  } from '../../lib/savedPlaceListManifest';
  import { buildSavedPlaceListSamplePageRequests } from '../../lib/savedPlaceListSampling';
  import {
    getInteractiveLabelLayerIds,
    hideAdministrativeSubdivisionLabels,
    rebalancePlaceLabelHierarchy,
    removeUnsupportedStyleImages,
    useBundledFontAlias,
  } from '../../lib/mapStyle';
  import {
    isDarkMapBasemapStyle,
    resolveMapBasemapStyle,
    type MapBasemapStylePreference,
  } from '../../lib/mapStylePreference';
  import { houseNumberMatches, normalizeHouseNumber } from '../../lib/mapSearchIndex';
  import { settingsStore, waitForSettingsLoaded } from '../../stores/settings';
  import { toast } from '../../stores/toast';
  import { appStore, getTree } from '../../store';
  import { nostr, nostrStore, pubkeyToNpub } from '../../nostr';
  import { createFollowsStore } from '../../stores/follows';
  import { FACT_OP_KIND } from '../../lib/mapFactEvents';
  import { loadDefaultSocialGraphFollowPubkeys, watchDefaultSocialGraphFollows } from '../../lib/defaultSocialGraphFollows';
  import type { PlaceDetailLink, PlaceDetails, PlaceReview, ReviewMedia, SavedPlaceListItem } from '../../stores/mapsTypes';

  interface RoutedSavedPlaceListSourceState {
    route: SavedPlaceListRoute;
    rootCid: CID;
    manifest: SavedPlaceListManifest;
    isLarge: boolean;
    overviewItems: SavedPlaceListItem[];
    pageCache: Map<number, SavedPlaceListItem[]>;
  }

  interface RoutedSavedPlaceListLoadResult {
    list: SavedPlaceList;
    sourceState: RoutedSavedPlaceListSourceState;
  }

  interface SavedPlaceViewportBounds {
    south: number;
    north: number;
    west: number;
    east: number;
  }

  type MapsLibraryTab = 'mine' | 'discover';
  type DiscoverListStatus = 'idle' | 'loading' | 'loaded' | 'error';

  interface DiscoveredSavedPlaceList {
    id: string;
    name: string;
    description?: string;
    ownerPubkey: string;
    ownerNpub: string;
    placeCount?: number;
    urls?: SavedPlaceList['urls'];
    createdAt?: number;
    updatedAt?: number;
    eventId: string;
  }

  interface MeasureDistancePoint {
    lat: number;
    lng: number;
  }

  type LoadedMapSourceFeature = MapGeoJSONFeature & {
    _x?: number;
    _y?: number;
    _z?: number;
  };

  interface LoadedStreetCandidate {
    feature: LoadedMapSourceFeature;
    result: SearchResult;
    aliases: string[];
    lines: Array<Array<[number, number]>>;
    matchScore: number;
  }

  interface LoadedHouseNumberCandidate {
    feature: LoadedMapSourceFeature;
    houseNumber: string;
    lat: number;
    lng: number;
    coordinateIndex: number;
  }

  const loadedMapSourceId = 'openmaptiles';
  const loadedStreetSourceLayer = 'transportation_name';
  const loadedHouseNumberSourceLayer = 'housenumber';
  const loadedAddressJoinRadiusMeters = 45;

  const btcMapCrawlerPubkey = 'd140d35e05529337a85ac0c9f9e46fbc7fe236ecedf7198457fe5d8fda4cf7fb';
  const btcMapCrawlerNpub = 'npub169qdxhs922fn02z6crylner0h3l7ydhvahm3npzhlewclkjv7las3mh2at';
  const btcMapSavedPlaceListId = '8b9d8384-c005-426d-974d-4141be760bff';
  const btcMapFeaturedSavedPlaceList = createBtcMapFeaturedSavedPlaceList();
  const discoverOtherAuthorPubkeys = [btcMapCrawlerPubkey];

  let mapContainer: HTMLDivElement;
  let map: MapLibreMap | null = null;
  let placeMarkers: Marker[] = [];
  let savedPlaceMarkers: Marker[] = [];
  let savedPlaceMarkerElements = new Map<string, HTMLDivElement>();
  let activePlaceMarker: Marker | null = null;
  let activeHoverPopup: Popup | null = null;
  let clearMapDetailSearchProvider: (() => void) | null = null;
  let mapReady = $state(false);
  let mapError = $state<string | null>(null);
  const basemapConfig = createMapBasemapConfig();

  let places = $derived(mapsStore.places);
  let activePlace = $derived(mapsStore.activePlace);
  let activeStoredPlace = $derived(places.find(place => place.id === activePlace?.id));
  let lastFocusedKey = '';
  let pmtilesProtocol: Protocol | null = null;
  const registeredPmtilesArchives = new Map<string, PMTiles>();
  let readBasemapVectorTile: VectorTileReader | null = null;
  let activeBasemapStylePreference: MapBasemapStylePreference | null = null;
  let pendingBasemapStylePreference: MapBasemapStylePreference | null = null;
  let basemapStyleRequestId = 0;
  let mapStylePreference = $derived($settingsStore.map.style);
  let mapChromeTheme = $derived.by((): 'light' | 'dark' => (
    isDarkMapBasemapStyle(resolveMapBasemapStyle(mapStylePreference)) ? 'dark' : 'light'
  ));
  let interactiveLabelLayerIds: string[] = [];
  let activePlaceUrlCopied = $state(false);
  let activePlaceShareTimer: ReturnType<typeof setTimeout> | null = null;
  let copiedSavedListId = $state<string | null>(null);
  let savedListCopyTimer: ReturnType<typeof setTimeout> | null = null;
  let hoveredSavedPlaceListItemKey = $state('');
  let activePlaceTab = $state<'overview' | 'reviews'>('overview');
  let lastActivePlaceTabKey = '';
  let isSaveListsPanelOpen = $state(false);
  let isLibraryPanelOpen = $state(false);
  let libraryTab = $state<MapsLibraryTab>('mine');
  let libraryOverlayListIds = $state<string[]>([]);
  let librarySelectedListId = $state<string | null>(null);
  let savedExternalPlaceLists = $state<SavedExternalPlaceList[]>(loadSavedExternalPlaceLists());
  let lastFocusedLibraryListKey = '';
  let followingDiscoveredSavedPlaceLists = $state<DiscoveredSavedPlaceList[]>([]);
  let otherDiscoveredSavedPlaceLists = $state<DiscoveredSavedPlaceList[]>([]);
  let followingDiscoveredListStatus = $state<DiscoverListStatus>('idle');
  let otherDiscoveredListStatus = $state<DiscoverListStatus>('idle');
  let followingDiscoveredListError = $state('');
  let otherDiscoveredListError = $state('');
  let isFollowingDiscoverOpen = $state(true);
  let isOtherDiscoverOpen = $state(true);
  let followsPubkeys = $state<string[]>([]);
  let defaultDiscoverFollowPubkeys = $state<string[]>([]);
  let defaultDiscoverFollowStatus = $state<DiscoverListStatus>('idle');
  let followingDiscoverRequestId = 0;
  let otherDiscoverRequestId = 0;
  let followingDiscoverActiveAuthorsKey = '';
  let otherDiscoverActiveAuthorsKey = '';
  let savedListStatus = $state<'idle' | 'saving' | 'error'>('idle');
  let routedSavedPlaceList = $state<SavedPlaceList | null>(null);
  let savedListRouteStatus = $state<'idle' | 'loading' | 'loaded' | 'error'>('idle');
  let savedListRouteError = $state('');
  let savedListRouteKey = '';
  let lastFocusedSavedListKey = '';
  let savedListRouteAbortController: AbortController | null = null;
  let savedListViewportAbortController: AbortController | null = null;
  let savedListSearchAbortController: AbortController | null = null;
  let savedListViewportRequestId = 0;
  let savedListSearchRequestId = 0;
  let savedListSearchQuery = $state('');
  let savedListSearchStatus = $state<'idle' | 'searching' | 'error'>('idle');
  let routedSavedPlaceListSource: RoutedSavedPlaceListSourceState | null = null;
  let showNewSavedListForm = $state(false);
  let newSavedListName = $state('');
  let newSavedListVisibility = $state<SavedPlaceListVisibility>('private');
  let reviewRating = $state<number | null>(null);
  let reviewBody = $state('');
  let reviewMedia = $state<ReviewMedia[]>([]);
  let reviewStatus = $state<'idle' | 'saving' | 'saved' | 'error'>('idle');
  let reviewMediaInputElement: HTMLInputElement | undefined = $state();
  let reviewMediaUpload = $state<ReviewMediaUploadProgress | null>(null);
  let reviewMediaError = $state('');
  let isReviewModalOpen = $state(false);
  let isPhotoGalleryOpen = $state(false);
  let photoGalleryIndex = $state(0);
  let isMeasureDistanceActive = $state(false);
  let measureDistancePoints = $state<MeasureDistancePoint[]>([]);
  let contextMenu = $state<{
    lat: number;
    lng: number;
    x: number;
    y: number;
  } | null>(null);
  let contextMenuElement: HTMLDivElement | undefined = $state();
  let contextMenuUrlCopied = $state(false);
  let contextMenuCopyTimer: ReturnType<typeof setTimeout> | null = null;
  let showBandwidth = $derived($settingsStore.pools.showBandwidth ?? false);
  let showConnectivity = $derived($settingsStore.pools.showConnectivity ?? false);
  let totalConnections = $derived($nostrStore.connectedRelays + $appStore.peerCount);
  let showConnectivityWarning = $derived(totalConnections === 0);
  let followsStore = $derived($nostrStore.pubkey ? createFollowsStore($nostrStore.pubkey) : null);
  let discoverFollowPubkeys = $derived(followsPubkeys.length > 0 ? followsPubkeys : defaultDiscoverFollowPubkeys);
  let discoverFollowingAuthorPubkeys = $derived(
    normalizedDiscoverAuthors(discoverFollowPubkeys)
      .filter((pubkey) => !discoverOtherAuthorPubkeys.includes(pubkey))
      .slice(0, 50)
  );
  let visibleOtherDiscoveredSavedPlaceLists = $derived.by(() => {
    const hasBtcMap = otherDiscoveredSavedPlaceLists.some((list) => list.ownerPubkey === btcMapCrawlerPubkey || list.id === btcMapSavedPlaceListId);
    return (hasBtcMap ? otherDiscoveredSavedPlaceLists : [btcMapFeaturedSavedPlaceList, ...otherDiscoveredSavedPlaceLists])
      .slice(0, 80);
  });
  let activePlaceReviews = $derived(activePlace?.id ? mapsStore.reviewsForPlace(activePlace.id) : []);
  let savedPlaceLists = $derived(mapsStore.savedPlaceLists);
  let publicSavedPlaceLists = $derived(savedPlaceLists.filter((list) => list.visibility === 'public'));
  let libraryListCount = $derived(savedPlaceLists.length + savedExternalPlaceLists.length);
  let libraryPublicListCount = $derived(publicSavedPlaceLists.length + savedExternalPlaceLists.length);
  let libraryOverlayLists = $derived(savedPlaceLists.filter((list) => libraryOverlayListIds.includes(list.id)));
  let librarySelectedList = $derived(savedPlaceLists.find((list) => list.id === librarySelectedListId) ?? libraryOverlayLists[0] ?? null);
  let visibleSavedPlaceLists = $derived(routedSavedPlaceList ? [routedSavedPlaceList] : libraryOverlayLists);
  let currentRoutedExternalPlaceList = $derived.by(() => (
    routedSavedPlaceList && routedSavedPlaceListSource
      ? createSavedExternalPlaceListFromRoute(routedSavedPlaceListSource.route, routedSavedPlaceList, routedSavedPlaceListSource.manifest)
      : null
  ));
  let isCurrentRoutedExternalPlaceListSaved = $derived(Boolean(
    currentRoutedExternalPlaceList
    && savedExternalPlaceLists.some((list) => savedExternalPlaceListKey(list) === savedExternalPlaceListKey(currentRoutedExternalPlaceList))
  ));
  let isActivePlaceInAnyList = $derived(Boolean(activePlace && mapsStore.isPlaceSaved(activePlace)));
  let reviewSummary = $derived(createReviewSummary(activePlaceReviews));
  let activePlaceDetails = $derived(activePlace?.details);
  let activePlaceContext = $derived(activePlace ? resultContextSummary(activePlace) : null);
  let activePlaceReviewPhotos = $derived(activePlaceReviews.flatMap((review) => review.media ?? []).filter((media) => media.type === 'image'));
  let activePlaceDetailPhoto = $derived(placeDetailImageMedia(activePlaceDetails?.imageUrl, activePlace?.name));
  let activePlacePhotos = $derived(uniqueImageMedia([
    ...activePlaceReviewPhotos,
    ...(activePlaceDetailPhoto ? [activePlaceDetailPhoto] : []),
  ]));
  let activePlaceHeroMedia = $derived(activePlacePhotos[0]);
  let activePlaceHeroImageUrl = $derived(activePlaceHeroMedia ? reviewMediaDisplayUrl(activePlaceHeroMedia.url) : undefined);
  let activeGalleryPhoto = $derived(activePlacePhotos[photoGalleryIndex] ?? activePlacePhotos[0]);
  let activePlaceCanHaveReviews = $derived(Boolean(activePlace && canPlaceHaveReviews(activePlace)));
  let canReviewActivePlace = $derived(Boolean(
    activePlaceCanHaveReviews
    &&
    activePlace?.id
  ));
  let isReviewMediaUploading = $derived(Boolean(reviewMediaUpload));
  let isMeasureDistanceOpen = $derived(isMeasureDistanceActive || measureDistancePoints.length > 0);
  let measureDistanceTotalMeters = $derived(calculateMeasureDistanceMeters(measureDistancePoints));
  let showingSavedListPanel = $derived(Boolean(routedSavedPlaceList || savedListRouteStatus === 'loading' || savedListRouteStatus === 'error'));
  let showingSavedListPlaceDetail = $derived(Boolean(showingSavedListPanel && activePlace));
  let showingLibraryPanel = $derived(Boolean(isLibraryPanelOpen && !activePlace && !showingSavedListPanel));
  let showingLeftPanel = $derived(Boolean((activePlace || showingSavedListPanel || showingLibraryPanel) && !mapsStore.isAddPlaceModalOpen));
  let isCompactViewport = $state(false);
  let isLeftPanelMinimized = $state(false);
  let isLeftPanelVisuallyMinimized = $derived(Boolean(showingLeftPanel && isCompactViewport && isLeftPanelMinimized));
  let isLeftPanelMapObscuring = $derived(Boolean(showingLeftPanel && !isLeftPanelVisuallyMinimized));

  const largeAreaTypes = new Set(['continent', 'country', 'state', 'region', 'province', 'county', 'administrative']);
  const largeAreaClasses = new Set(['boundary']);
  const labelHitTolerancePx = 8;
  const contextMenuWidth = 240;
  const contextMenuHeight = 204;
  const contextMenuMargin = 12;
  const measureDistanceSourceId = 'iris-map-measure-distance-source';
  const measureDistanceLineHaloLayerId = 'iris-map-measure-distance-line-halo';
  const measureDistanceLineLayerId = 'iris-map-measure-distance-line';
  const measureDistancePointHaloLayerId = 'iris-map-measure-distance-point-halo';
  const measureDistancePointLayerId = 'iris-map-measure-distance-point';
  const measureDistanceLabelLayerId = 'iris-map-measure-distance-label';
  const earthRadiusMeters = 6_371_008.8;
  const maxInitialRoutedListItems = 240;
  const maxInitialRoutedListPages = 24;
  const maxViewportRoutedListItems = 360;
  const maxSavedPlaceListSearchResults = 200;
  const savedPlaceListLargeThreshold = 2_000;
  const savedPlaceListViewportMinZoom = 4;
  const savedPlaceListViewportPageBatchSize = 6;
  const savedPlaceListSearchPageBatchSize = 8;
  const savedPlaceListRouteResolveTimeoutMs = 45_000;
  const savedPlaceListJsonMaxBytes = 8 * 1024 * 1024;
  const maxLibraryOverlayLists = 4;
  const keyboardPanStepPx = 100;
  const keyboardLargePanStepPx = 300;
  const keyboardNavigationDurationMs = 220;
  const savedPlaceListTextDecoder = new TextDecoder();

  function ensurePmtilesProtocol(): Protocol {
    if (pmtilesProtocol) return pmtilesProtocol;
    pmtilesProtocol = new Protocol();
    maplibregl.addProtocol('pmtiles', pmtilesProtocol.tile.bind(pmtilesProtocol));
    return pmtilesProtocol;
  }

  function registerPmtilesArchive(url: string): PMTiles {
    const existing = registeredPmtilesArchives.get(url);
    if (existing) return existing;
    const archive = new PMTiles(url);
    ensurePmtilesProtocol().add(archive);
    registeredPmtilesArchives.set(url, archive);
    return archive;
  }

  function absoluteUrl(url: string): string {
    if (/^https?:\/\//.test(url)) return url;
    return `${window.location.origin}${url.startsWith('/') ? '' : '/'}${url}`;
  }

  function createCircleImage(size: number, color: [number, number, number, number]) {
    const radius = (size - 1) / 2;
    const center = radius;
    const data = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        const distance = Math.hypot(x - center, y - center);
        if (distance > radius) continue;
        const edge = Math.max(0, Math.min(1, radius - distance));
        const alpha = Math.round(color[3] * Math.min(1, edge + 0.25));
        const offset = (y * size + x) * 4;
        data[offset] = color[0];
        data[offset + 1] = color[1];
        data[offset + 2] = color[2];
        data[offset + 3] = alpha;
      }
    }
    return { width: size, height: size, data };
  }

  function handleMissingStyleImage(event: { id: string }) {
    if (!map || event.id !== 'circle-11' || map.hasImage(event.id)) return;
    map.addImage(event.id, createCircleImage(11, [178, 203, 214, 230]));
  }

  function rememberInteractiveLabelLayers(style: StyleSpecification) {
    interactiveLabelLayerIds = getInteractiveLabelLayerIds(style);
  }

  function collapseAttributionControl() {
    const attributionControl = mapContainer?.querySelector('.maplibregl-ctrl-attrib');
    attributionControl?.classList.remove('maplibregl-compact-show');
    attributionControl?.removeAttribute('open');
    attributionControl
      ?.querySelector('.maplibregl-ctrl-attrib-button')
      ?.setAttribute('aria-expanded', 'false');
  }

  function markNavigationControl() {
    mapContainer
      ?.querySelector('.maplibregl-ctrl-zoom-in')
      ?.closest('.maplibregl-ctrl-group')
      ?.classList.add('iris-map-navigation-control');
  }

  function createLocateControl(): IControl {
    let container: HTMLDivElement | null = null;
    let button: HTMLButtonElement | null = null;
    return {
      onAdd() {
        container = document.createElement('div');
        container.className = 'maplibregl-ctrl maplibregl-ctrl-group iris-map-navigation-control iris-map-locate-control-group';
        button = document.createElement('button');
        button.type = 'button';
        button.className = 'iris-map-locate-control';
        button.title = 'Locate me';
        button.setAttribute('aria-label', 'Locate me');
        button.setAttribute('data-testid', 'map-locate-control');
        button.innerHTML = '<span class="i-lucide-locate-fixed iris-map-locate-icon" aria-hidden="true"></span>';
        button.addEventListener('click', handleLocateControlClick);
        container.append(button);
        return container;
      },
      onRemove() {
        button?.removeEventListener('click', handleLocateControlClick);
        container?.remove();
        button = null;
        container = null;
      },
    };
  }

  function setLocateControlBusy(isBusy: boolean) {
    const locateButton = mapContainer?.querySelector<HTMLButtonElement>('[data-testid="map-locate-control"]');
    if (!locateButton) return;
    locateButton.disabled = isBusy;
    locateButton.classList.toggle('is-locating', isBusy);
    locateButton.title = isBusy ? 'Locating...' : 'Locate me';
    locateButton.setAttribute('aria-label', isBusy ? 'Locating...' : 'Locate me');
  }

  function locationErrorMessage(error: unknown): string {
    const code = typeof error === 'object' && error !== null && 'code' in error
      ? Number((error as { code?: unknown }).code)
      : 0;
    if (code === 1) return 'Location permission was denied';
    if (code === 2) return 'Could not determine your location';
    if (code === 3) return 'Location request timed out';
    return 'Could not locate you';
  }

  function currentBrowserPosition(): Promise<GeolocationPosition> {
    const geolocation = typeof navigator === 'undefined' ? undefined : navigator.geolocation;
    if (!geolocation) {
      return Promise.reject(new Error('Geolocation is unavailable'));
    }
    return new Promise((resolve, reject) => {
      geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        maximumAge: 60_000,
        timeout: 10_000,
      });
    });
  }

  function locationZoomForAccuracy(accuracyMeters: number): number {
    if (!Number.isFinite(accuracyMeters)) return 14;
    if (accuracyMeters <= 50) return 16;
    if (accuracyMeters <= 250) return 15;
    if (accuracyMeters <= 1000) return 13;
    return 11;
  }

  async function locateBrowserPosition() {
    if (!map) return;
    setLocateControlBusy(true);
    try {
      const position = await currentBrowserPosition();
      if (!map) return;
      const { latitude, longitude, accuracy } = position.coords;
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
        throw new Error('Invalid browser location');
      }
      map.easeTo({
        center: [longitude, latitude],
        zoom: Math.min(basemapConfig.maxZoom, Math.max(map.getZoom(), locationZoomForAccuracy(accuracy))),
        duration: 650,
      });
    } catch (error) {
      toast.error(locationErrorMessage(error));
    } finally {
      setLocateControlBusy(false);
    }
  }

  function handleLocateControlClick(event: Event) {
    event.preventDefault();
    event.stopPropagation();
    void locateBrowserPosition();
  }

  function radians(value: number): number {
    return value * Math.PI / 180;
  }

  function measureDistanceSegmentMeters(from: MeasureDistancePoint, to: MeasureDistancePoint): number {
    const lat1 = radians(from.lat);
    const lat2 = radians(to.lat);
    const deltaLat = radians(to.lat - from.lat);
    const deltaLng = radians(to.lng - from.lng);
    const a = Math.sin(deltaLat / 2) ** 2
      + Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLng / 2) ** 2;
    return earthRadiusMeters * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function calculateMeasureDistanceMeters(points: MeasureDistancePoint[]): number {
    let total = 0;
    for (let index = 1; index < points.length; index += 1) {
      total += measureDistanceSegmentMeters(points[index - 1], points[index]);
    }
    return total;
  }

  function formatMeasureDistance(meters: number): string {
    if (meters < 1000) return `${Math.round(meters).toLocaleString()} m`;
    const kilometers = meters / 1000;
    const miles = meters / 1609.344;
    return `${kilometers.toFixed(kilometers >= 100 ? 1 : 2)} km (${miles.toFixed(miles >= 100 ? 1 : 2)} mi)`;
  }

  function measureDistanceMidpoint(from: MeasureDistancePoint, to: MeasureDistancePoint): MeasureDistancePoint {
    return {
      lat: (from.lat + to.lat) / 2,
      lng: (from.lng + to.lng) / 2,
    };
  }

  function createMeasureDistanceGeoJson(): MeasureDistanceCollection {
    const features: MeasureDistanceCollection['features'] = [];

    if (measureDistancePoints.length >= 2) {
      features.push({
        type: 'Feature',
        properties: { kind: 'line' },
        geometry: {
          type: 'LineString',
          coordinates: measureDistancePoints.map((point) => [point.lng, point.lat]),
        },
      });

      for (let index = 1; index < measureDistancePoints.length; index += 1) {
        const from = measureDistancePoints[index - 1];
        const to = measureDistancePoints[index];
        const midpoint = measureDistanceMidpoint(from, to);
        features.push({
          type: 'Feature',
          properties: {
            kind: 'label',
            label: formatMeasureDistance(measureDistanceSegmentMeters(from, to)),
          },
          geometry: {
            type: 'Point',
            coordinates: [midpoint.lng, midpoint.lat],
          },
        });
      }
    }

    for (const [index, point] of measureDistancePoints.entries()) {
      features.push({
        type: 'Feature',
        properties: { kind: 'point', index },
        geometry: {
          type: 'Point',
          coordinates: [point.lng, point.lat],
        },
      });
    }

    return {
      type: 'FeatureCollection',
      features,
    };
  }

  function ensureMeasureDistanceLayers() {
    if (!map || !map.isStyleLoaded()) return false;
    if (!map.getSource(measureDistanceSourceId)) {
      map.addSource(measureDistanceSourceId, {
        type: 'geojson',
        data: createMeasureDistanceGeoJson(),
      });
    }

    if (!map.getLayer(measureDistanceLineHaloLayerId)) {
      map.addLayer({
        id: measureDistanceLineHaloLayerId,
        type: 'line',
        source: measureDistanceSourceId,
        filter: ['==', ['get', 'kind'], 'line'],
        paint: {
          'line-color': '#ffffff',
          'line-width': 6,
          'line-opacity': 0.78,
        },
      });
    }

    if (!map.getLayer(measureDistanceLineLayerId)) {
      map.addLayer({
        id: measureDistanceLineLayerId,
        type: 'line',
        source: measureDistanceSourceId,
        filter: ['==', ['get', 'kind'], 'line'],
        paint: {
          'line-color': '#111827',
          'line-width': 2.25,
          'line-opacity': 0.95,
        },
      });
    }

    if (!map.getLayer(measureDistancePointHaloLayerId)) {
      map.addLayer({
        id: measureDistancePointHaloLayerId,
        type: 'circle',
        source: measureDistanceSourceId,
        filter: ['==', ['get', 'kind'], 'point'],
        paint: {
          'circle-radius': 7,
          'circle-color': '#ffffff',
          'circle-opacity': 0.92,
        },
      });
    }

    if (!map.getLayer(measureDistancePointLayerId)) {
      map.addLayer({
        id: measureDistancePointLayerId,
        type: 'circle',
        source: measureDistanceSourceId,
        filter: ['==', ['get', 'kind'], 'point'],
        paint: {
          'circle-radius': 4,
          'circle-color': '#111827',
          'circle-stroke-color': '#ffffff',
          'circle-stroke-width': 1.5,
        },
      });
    }

    if (!map.getLayer(measureDistanceLabelLayerId)) {
      map.addLayer({
        id: measureDistanceLabelLayerId,
        type: 'symbol',
        source: measureDistanceSourceId,
        filter: ['==', ['get', 'kind'], 'label'],
        layout: {
          'text-field': ['get', 'label'],
          'text-size': 12,
          'text-offset': [0, -0.9],
          'text-anchor': 'bottom',
          'text-allow-overlap': true,
        },
        paint: {
          'text-color': '#111827',
          'text-halo-color': '#ffffff',
          'text-halo-width': 2,
        },
      });
    }

    return true;
  }

  function syncMeasureDistanceOverlay() {
    if (!map || !ensureMeasureDistanceLayers()) return;
    const source = map.getSource(measureDistanceSourceId) as { setData?: (data: ReturnType<typeof createMeasureDistanceGeoJson>) => void } | undefined;
    source?.setData?.(createMeasureDistanceGeoJson());
  }

  async function loadBasemapStyle(preference: MapBasemapStylePreference): Promise<StyleSpecification> {
    const concreteStyle = resolveMapBasemapStyle(preference);
    const styleUrl = withHtreeClientKey(basemapConfig.styleUrls[concreteStyle]);
    const response = await fetch(styleUrl);
    if (!response.ok) {
      throw new Error(`Failed to load basemap style (${response.status})`);
    }

    const style = await response.json() as StyleSpecification;
    const pmtilesUrl = absoluteUrl(withHtreeClientKey(basemapConfig.pmtilesUrl));
    readBasemapVectorTile = createPmtilesVectorTileReader(registerPmtilesArchive(pmtilesUrl));
    useBundledFontAlias(style);
    removeUnsupportedStyleImages(style);
    hideAdministrativeSubdivisionLabels(style);
    rebalancePlaceLabelHierarchy(style);
    rememberInteractiveLabelLayers(style);
    style.glyphs = absoluteUrl(withHtreeClientKey(basemapConfig.glyphsUrl));
    style.sprite = absoluteUrl(withHtreeClientKey(basemapConfig.spriteUrl));
    style.sources = {
      ...style.sources,
      openmaptiles: {
        type: 'vector',
        url: `pmtiles://${pmtilesUrl}`,
        attribution: basemapConfig.attribution,
        maxzoom: basemapConfig.maxNativeZoom,
      },
    };
    delete style.sources.ne2_shaded;
    style.layers = style.layers.filter((layer) => !('source' in layer) || layer.source !== 'ne2_shaded');
    return style;
  }

  function applyBasemapStylePreference(preference: MapBasemapStylePreference) {
    if (!map) return;
    if (activeBasemapStylePreference === preference || pendingBasemapStylePreference === preference) return;

    const requestId = ++basemapStyleRequestId;
    pendingBasemapStylePreference = preference;
    void loadBasemapStyle(preference)
      .then((style) => {
        if (!map || requestId !== basemapStyleRequestId) return;
        rememberInteractiveLabelLayers(style);
        map.setStyle(style);
        activeBasemapStylePreference = preference;
        mapError = null;
      })
      .catch((error) => {
        if (requestId !== basemapStyleRequestId) return;
        console.error('[maps] failed to switch basemap style', error);
        mapError = 'Failed to load map style';
      })
      .finally(() => {
        if (requestId === basemapStyleRequestId) {
          pendingBasemapStylePreference = null;
        }
      });
  }

  function escapeHtml(value: string): string {
    return value
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function externalUrlLabel(url: string): string {
    try {
      const parsed = new URL(url);
      const host = parsed.hostname.replace(/^www\./, '');
      const path = parsed.pathname.replace(/\/$/, '');
      return `${host}${path && path !== '/' ? path : ''}`;
    } catch {
      return url;
    }
  }

  function formatDetailDate(value: string): string {
    const timestamp = Date.parse(value);
    return Number.isFinite(timestamp) ? new Date(timestamp).toISOString().slice(0, 10) : value;
  }

  function phoneHref(value: string): string {
    const normalized = value.replace(/[^\d+]/g, '');
    return normalized ? `tel:${normalized}` : `tel:${value}`;
  }

  function emailHref(value: string): string {
    return `mailto:${value}`;
  }

  function placeDetailImageMedia(url: string | undefined, placeName: string | undefined): ReviewMedia | null {
    const cleanUrl = url?.trim();
    if (!cleanUrl) return null;
    return {
      url: cleanUrl,
      type: 'image',
      mimeType: imageMimeTypeForUrl(cleanUrl),
      alt: placeName ? `${placeName} photo` : 'Place photo',
    };
  }

  function imageMimeTypeForUrl(url: string): string {
    const path = url.split(/[?#]/, 1)[0].toLowerCase();
    if (path.endsWith('.avif')) return 'image/avif';
    if (path.endsWith('.gif')) return 'image/gif';
    if (path.endsWith('.png')) return 'image/png';
    if (path.endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }

  function uniqueImageMedia(media: ReviewMedia[]): ReviewMedia[] {
    const seen = new Set<string>();
    return media.filter((item) => {
      const key = reviewMediaDisplayUrl(item.url);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function placeDetailRows(place: ActivePlace | null, details: PlaceDetails | undefined): Array<{
    icon: string;
    label: string;
    value: string;
    href?: string;
  }> {
    if (!place) return [];
    const rows: Array<{ icon: string; label: string; value: string; href?: string }> = [];
    rows.push({
      icon: 'i-lucide-map-pin',
      label: 'Coordinates',
      value: `${place.lat.toFixed(5)}, ${place.lng.toFixed(5)}`,
    });
    if (!details) {
      const context = visiblePlaceContext(place.context);
      if (context) {
        rows.push({ icon: 'i-lucide-info', label: 'Details', value: context });
      }
      return rows;
    }
    if (details.address) rows.push({ icon: 'i-lucide-map-pinned', label: 'Address', value: details.address });
    if (details.openingHours) rows.push({ icon: 'i-lucide-clock-3', label: 'Hours', value: details.openingHours });
    if (details.paymentProvider) rows.push({ icon: 'i-lucide-bitcoin', label: 'Payment', value: details.paymentProvider });
    if (details.verifiedAt) rows.push({ icon: 'i-lucide-shield-check', label: 'Verified', value: formatDetailDate(details.verifiedAt) });
    return rows;
  }

  function visiblePlaceLinks(details: PlaceDetails | undefined): PlaceDetailLink[] {
    const links = details?.links ?? [];
    const seen = new Set<string>();
    return links.filter((link) => {
      if (isOpenStreetMapPlaceLink(link)) return false;
      const key = link.url.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function isOpenStreetMapPlaceLink(link: PlaceDetailLink): boolean {
    return link.label.trim().toLowerCase() === 'openstreetmap'
      || /^https?:\/\/(?:www\.)?openstreetmap\.org\//i.test(link.url);
  }

  function visiblePlaceContext(context: string | undefined): string {
    if (!context) return '';
    return context
      .split(/\s*\|\s*/)
      .map((part) => part.trim())
      .filter((part) => part && !isOpenStreetMapContextPart(part))
      .join(' | ');
  }

  function isOpenStreetMapContextPart(part: string): boolean {
    return /^(?:node|way|relation):\d+$/i.test(part)
      || /^https?:\/\/(?:www\.)?openstreetmap\.org\//i.test(part);
  }

  function placeReviewSummary(placeId: string | undefined) {
    return createReviewSummary(placeId ? mapsStore.reviewsForPlace(placeId) : []);
  }

  function placeHeroMedia(placeId: string | undefined): ReviewMedia | undefined {
    return placeId
      ? mapsStore.reviewsForPlace(placeId).flatMap((review) => review.media ?? []).find((media) => media.type === 'image')
      : undefined;
  }

  function hoverCardHtml(input: {
    id?: string;
    name: string;
    type?: string;
    context?: string;
    lat: number;
    lng: number;
  }): string {
    const summary = placeReviewSummary(input.id);
    const photo = placeHeroMedia(input.id);
    const type = displayPlaceTypeLabel(input.type);
    const stars = [1, 2, 3, 4, 5]
      .map((rating) => `<span class="${summary.average >= rating - 0.25 ? 'iris-hover-star-filled' : 'iris-hover-star-empty'}">${summary.average >= rating - 0.25 ? '★' : '☆'}</span>`)
      .join('');
    return `
      <div class="iris-map-hover-card">
        ${photo ? `<img class="iris-map-hover-card-image" src="${escapeHtml(reviewMediaDisplayUrl(photo.url))}" alt="${escapeHtml(photo.alt ?? input.name)}" />` : ''}
        <div class="iris-map-hover-card-body">
          <div class="iris-map-hover-card-main">
            <div class="iris-map-hover-card-title">${escapeHtml(input.name)}</div>
            <div class="iris-map-hover-card-meta">
              ${summary.count ? `<span>${summary.average.toFixed(1)}</span><span class="iris-map-hover-stars">${stars}</span><span>(${summary.count})</span>` : ''}
              <span>${escapeHtml(type)}</span>
            </div>
            <div class="iris-map-hover-card-context">${escapeHtml(visiblePlaceContext(input.context) || `${input.lat.toFixed(5)}, ${input.lng.toFixed(5)}`)}</div>
          </div>
          <div class="iris-map-hover-card-actions" aria-hidden="true">
            <span class="i-lucide-bookmark"></span>
            <span class="i-lucide-share"></span>
          </div>
        </div>
      </div>
    `;
  }

  function removePlaceMarkers() {
    removeActiveHoverPopup();
    for (const marker of placeMarkers) {
      marker.remove();
    }
    placeMarkers = [];
  }

  function removeSavedPlaceMarkers() {
    removeActiveHoverPopup();
    for (const marker of savedPlaceMarkers) {
      marker.remove();
    }
    savedPlaceMarkers = [];
    savedPlaceMarkerElements = new Map();
  }

  function removeActiveHoverPopup() {
    activeHoverPopup?.remove();
    activeHoverPopup = null;
  }

  function showMarkerHoverPopup(popup: Popup, lngLat: [number, number]) {
    if (!map) return;
    if (activeHoverPopup && activeHoverPopup !== popup) {
      activeHoverPopup.remove();
    }
    activeHoverPopup = popup;
    popup.setLngLat(lngLat).addTo(map);
  }

  function hideMarkerHoverPopup(popup: Popup) {
    if (activeHoverPopup === popup) {
      activeHoverPopup = null;
    }
    popup.remove();
  }

  function createPlaceMarkerElement(place: Pick<Place, 'category'>): HTMLDivElement {
    const marker = document.createElement('div');
    marker.className = 'iris-map-place-marker';
    marker.dataset.category = place.category;
    marker.tabIndex = 0;
    return marker;
  }

  function createSavedPlaceMarkerElement(item: SavedPlaceListItem, listIndex = 0): HTMLDivElement {
    const marker = document.createElement('div');
    marker.className = 'iris-map-saved-list-marker';
    marker.dataset.savedPlaceKey = item.key;
    marker.dataset.listIndex = String(listIndex % maxLibraryOverlayLists);
    marker.tabIndex = 0;
    return marker;
  }

  function selectStoredPlace(place: Place) {
    const active = mapsStore.activePlaceFromPlace(place);
    mapsStore.setActivePlace(active);
    setActivePlaceInHash(active);
  }

  function savedPlaceItemToActivePlace(item: SavedPlaceListItem): ActivePlace {
    return {
      id: item.id,
      name: item.name,
      lat: item.lat,
      lng: item.lng,
      type: item.type,
      class: item.class,
      displayName: item.displayName,
      context: item.context,
      details: item.details,
      sourceLayer: item.sourceLayer,
      sourceId: item.sourceId,
      source: item.source,
    };
  }

  function selectSavedPlaceListItem(item: SavedPlaceListItem) {
    const active = savedPlaceItemToActivePlace(item);
    mapsStore.setActivePlace(active);
    setActivePlaceInHash(active);
  }

  function hoverSavedPlaceListItem(item: SavedPlaceListItem) {
    hoveredSavedPlaceListItemKey = item.key;
  }

  function clearHoveredSavedPlaceListItem(item: SavedPlaceListItem) {
    if (hoveredSavedPlaceListItemKey === item.key) {
      hoveredSavedPlaceListItemKey = '';
    }
  }

  function applySavedPlaceMarkerHoverState(hoveredKey = hoveredSavedPlaceListItemKey) {
    for (const [key, element] of savedPlaceMarkerElements) {
      element.classList.toggle('iris-map-saved-list-marker-hovered', Boolean(hoveredKey) && (key === hoveredKey || key.startsWith(`${hoveredKey}\0`)));
    }
  }

  function createActiveMarkerElement(): HTMLDivElement {
    const marker = document.createElement('div');
    marker.className = 'iris-map-active-marker';
    marker.tabIndex = 0;
    return marker;
  }

  function shouldShowActivePlaceMarker(place: ActivePlace): boolean {
    if (place.type && largeAreaTypes.has(place.type.toLowerCase())) {
      return false;
    }
    if (place.class && largeAreaClasses.has(place.class.toLowerCase())) {
      return false;
    }
    if (place.boundingBox) {
      const [south, north, west, east] = place.boundingBox;
      const latSpan = north - south;
      const lngSpan = Math.abs(east - west);
      return latSpan <= 20 && lngSpan <= 20;
    }
    return true;
  }

  function stringProperty(properties: Record<string, unknown>, key: string): string | undefined {
    const value = properties[key];
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
  }

  function numberProperty(properties: Record<string, unknown>, key: string): number | undefined {
    const value = properties[key];
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
  }

  function titleCase(value: string): string {
    return value
      .replace(/[_-]+/g, ' ')
      .trim()
      .replace(/\b\w/g, (char) => char.toUpperCase());
  }

  function labelFeatureName(feature: MapGeoJSONFeature): string | null {
    const properties = feature.properties ?? {};
    return stringProperty(properties, 'name_en')
      ?? stringProperty(properties, 'name')
      ?? stringProperty(properties, 'name:latin')
      ?? stringProperty(properties, 'name:nonlatin')
      ?? null;
  }

  function labelFeatureClass(feature: MapGeoJSONFeature): string {
    const sourceLayer = feature.sourceLayer ?? feature.layer.id;
    const type = labelFeatureType(feature).toLowerCase();
    if (sourceLayer === 'place' && largeAreaTypes.has(type)) return 'boundary';
    if (sourceLayer === 'place') return 'place';
    if (sourceLayer === 'transportation_name') return 'highway';
    if (sourceLayer === 'aerodrome_label') return 'aeroway';
    if (sourceLayer === 'water_name' || sourceLayer === 'waterway') return 'water';
    return sourceLayer;
  }

  function labelFeatureType(feature: MapGeoJSONFeature): string {
    const properties = feature.properties ?? {};
    return stringProperty(properties, 'class')
      ?? stringProperty(properties, 'type')
      ?? stringProperty(properties, 'subclass')
      ?? feature.sourceLayer
      ?? feature.layer.id;
  }

  function labelFeatureDisplayName(feature: MapGeoJSONFeature): string {
    const sourceLayer = feature.sourceLayer ?? '';
    if (sourceLayer === 'transportation_name') return 'Street';
    if (sourceLayer === 'aerodrome_label') return 'Airport';
    if (sourceLayer === 'water_name' || sourceLayer === 'waterway') return 'Water';
    return titleCase(labelFeatureType(feature));
  }

  function coordinatePair(value: unknown): [number, number] | null {
    if (!Array.isArray(value) || value.length < 2) return null;
    const [lng, lat] = value;
    return typeof lng === 'number' && typeof lat === 'number' ? [lng, lat] : null;
  }

  function firstCoordinateFromGeometry(geometry: MapGeoJSONFeature['geometry'] | null | undefined): [number, number] | null {
    if (!geometry) return null;
    if (geometry.type === 'Point') return coordinatePair(geometry.coordinates);
    if (geometry.type === 'MultiPoint') return coordinatePair(geometry.coordinates[0]);
    return null;
  }

  function scoreMapDetailSearchText(searchText: string, normalizedQuery: string): number {
    if (!searchText || !normalizedQuery) return 0;
    if (searchText === normalizedQuery) return 1000;
    if (searchText.startsWith(normalizedQuery)) return 900;
    const tokens = searchText.split(' ').filter(Boolean);
    if (tokens.includes(normalizedQuery)) return 850;
    if (tokens.some((token) => token.startsWith(normalizedQuery))) return 780;
    if (searchText.includes(normalizedQuery)) return 620;
    return 0;
  }

  function scoreMapDetailNames(names: string[], normalizedQuery: string): number {
    const queryTokens = normalizedQuery.split(' ').filter(Boolean);
    let best = 0;
    for (const name of names) {
      const normalizedName = normalizeMapDetailSearchText(name);
      best = Math.max(best, scoreMapDetailSearchText(normalizedName, normalizedQuery));
      if (queryTokens.length > 1) {
        const matched = queryTokens.filter((token) => scoreMapDetailSearchText(normalizedName, token) > 0).length;
        if (matched === queryTokens.length) {
          best = Math.max(best, 860);
        }
      }
    }
    return best;
  }

  function sourceFeatureId(feature: LoadedMapSourceFeature): string | undefined {
    return typeof feature.id === 'string' || typeof feature.id === 'number' ? String(feature.id) : undefined;
  }

  function sourceFeatureZoom(feature: LoadedMapSourceFeature): number | undefined {
    return typeof feature._z === 'number' && Number.isFinite(feature._z) ? feature._z : undefined;
  }

  function sourceFeatureTile(feature: LoadedMapSourceFeature): [number, number] | undefined {
    return typeof feature._x === 'number' && Number.isFinite(feature._x)
      && typeof feature._y === 'number' && Number.isFinite(feature._y)
      ? [feature._x, feature._y]
      : undefined;
  }

  function sourceFeatureLayerId(feature: LoadedMapSourceFeature): string {
    return feature.sourceLayer ?? feature.layer?.id ?? '';
  }

  function sourceFeatureType(feature: LoadedMapSourceFeature): string {
    const properties = feature.properties ?? {};
    return stringProperty(properties, 'class')
      ?? stringProperty(properties, 'type')
      ?? stringProperty(properties, 'subclass')
      ?? sourceFeatureLayerId(feature)
      ?? 'place';
  }

  function sourceFeatureDisplayName(feature: LoadedMapSourceFeature): string {
    const sourceLayer = sourceFeatureLayerId(feature);
    if (sourceLayer === loadedStreetSourceLayer) return 'Street';
    if (sourceLayer === loadedHouseNumberSourceLayer) return 'Address';
    return titleCase(sourceFeatureType(feature));
  }

  function coordinatePairsFromArray(values: unknown): Array<[number, number]> {
    if (!Array.isArray(values)) return [];
    return values
      .map(coordinatePair)
      .filter((coordinate): coordinate is [number, number] => coordinate !== null);
  }

  function lineStringsFromGeometry(geometry: MapGeoJSONFeature['geometry'] | null | undefined): Array<Array<[number, number]>> {
    if (!geometry) return [];
    if (geometry.type === 'Point') {
      const coordinate = coordinatePair(geometry.coordinates);
      return coordinate ? [[coordinate]] : [];
    }
    if (geometry.type === 'MultiPoint') {
      return coordinatePairsFromArray(geometry.coordinates).map((coordinate) => [coordinate]);
    }
    if (geometry.type === 'LineString') {
      const line = coordinatePairsFromArray(geometry.coordinates);
      return line.length > 0 ? [line] : [];
    }
    if (geometry.type === 'MultiLineString' || geometry.type === 'Polygon') {
      return (Array.isArray(geometry.coordinates) ? geometry.coordinates : [])
        .map(coordinatePairsFromArray)
        .filter((line) => line.length > 0);
    }
    if (geometry.type === 'MultiPolygon') {
      return (Array.isArray(geometry.coordinates) ? geometry.coordinates : [])
        .flatMap((polygon) => Array.isArray(polygon) ? polygon.map(coordinatePairsFromArray) : [])
        .filter((line) => line.length > 0);
    }
    if (geometry.type === 'GeometryCollection') {
      return geometry.geometries.flatMap(lineStringsFromGeometry);
    }
    return [];
  }

  function flattenLineStrings(lines: Array<Array<[number, number]>>): Array<[number, number]> {
    return lines.flatMap((line) => line);
  }

  function coordinateBounds(coordinates: Array<[number, number]>): [number, number, number, number] | undefined {
    if (coordinates.length === 0) return undefined;
    let south = Number.POSITIVE_INFINITY;
    let north = Number.NEGATIVE_INFINITY;
    let west = Number.POSITIVE_INFINITY;
    let east = Number.NEGATIVE_INFINITY;
    for (const [lng, lat] of coordinates) {
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
      south = Math.min(south, lat);
      north = Math.max(north, lat);
      west = Math.min(west, lng);
      east = Math.max(east, lng);
    }
    if (![south, north, west, east].every(Number.isFinite)) return undefined;
    return [south, north, west, east];
  }

  function coordinateCenter(coordinates: Array<[number, number]>): { lat: number; lng: number } | null {
    const bounds = coordinateBounds(coordinates);
    if (!bounds) return null;
    const [south, north, west, east] = bounds;
    return {
      lat: (south + north) / 2,
      lng: (west + east) / 2,
    };
  }

  function queryLoadedSourceFeatures(sourceLayer: string): LoadedMapSourceFeature[] {
    if (!map || !map.isStyleLoaded() || !map.getSource(loadedMapSourceId)) return [];
    try {
      return map.querySourceFeatures(loadedMapSourceId, { sourceLayer, validate: false }) as LoadedMapSourceFeature[];
    } catch (error) {
      console.warn('[maps] loaded map source feature lookup failed', error);
      return [];
    }
  }

  function loadedStreetCandidates(streetQuery: string): LoadedStreetCandidate[] {
    const normalizedQuery = normalizeMapDetailSearchText(streetQuery);
    if (normalizedQuery.length < 2) return [];

    const candidates: LoadedStreetCandidate[] = [];
    const seen = new Set<string>();
    for (const feature of queryLoadedSourceFeatures(loadedStreetSourceLayer)) {
      const names = mapFeatureNames(feature.properties ?? {});
      const primaryName = names[0];
      if (!primaryName) continue;
      const matchScore = scoreMapDetailNames(names, normalizedQuery);
      if (matchScore <= 0) continue;

      const lines = lineStringsFromGeometry(feature.geometry);
      const coordinates = flattenLineStrings(lines);
      const center = coordinateCenter(coordinates);
      if (!center) continue;
      const sourceId = sourceFeatureId(feature);
      const sourceTile = sourceFeatureTile(feature);
      const sourceZoom = sourceFeatureZoom(feature);
      const idParts = [
        sourceId ?? primaryName,
        sourceZoom ?? '',
        sourceTile?.[0] ?? '',
        sourceTile?.[1] ?? '',
        center.lat.toFixed(5),
        center.lng.toFixed(5),
      ];
      const id = `loaded-map:street:${idParts.join(':')}`;
      if (seen.has(id)) continue;
      seen.add(id);

      const boundingBox = coordinateBounds(coordinates);
      candidates.push({
        feature,
        aliases: names.slice(1, 24),
        lines,
        matchScore,
        result: {
          id,
          name: primaryName,
          aliases: names.slice(1, 24),
          lat: Number(center.lat.toFixed(6)),
          lng: Number(center.lng.toFixed(6)),
          type: sourceFeatureType(feature),
          class: 'highway',
          displayName: sourceFeatureDisplayName(feature),
          boundingBox,
          placeRank: 26,
          importance: 0.25,
          addressType: 'road',
          sourceLayer: loadedStreetSourceLayer,
          sourceZoom,
          sourceId,
          sourceTile,
        },
      });
    }

    return candidates
      .sort((left, right) => right.matchScore - left.matchScore)
      .slice(0, 24);
  }

  function loadedHouseNumberCandidates(houseNumberQuery: string): LoadedHouseNumberCandidate[] {
    const candidates: LoadedHouseNumberCandidate[] = [];
    const seen = new Set<string>();
    for (const feature of queryLoadedSourceFeatures(loadedHouseNumberSourceLayer)) {
      const houseNumber = mapFeatureHouseNumber(feature.properties ?? {});
      if (!houseNumber || !houseNumberMatches(houseNumber, houseNumberQuery)) continue;
      const coordinates = flattenLineStrings(lineStringsFromGeometry(feature.geometry));
      for (const [coordinateIndex, [lng, lat]] of coordinates.entries()) {
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
        const key = `${normalizeHouseNumber(houseNumber)}:${lat.toFixed(6)}:${lng.toFixed(6)}`;
        if (seen.has(key)) continue;
        seen.add(key);
        candidates.push({
          feature,
          houseNumber,
          lat: Number(lat.toFixed(6)),
          lng: Number(lng.toFixed(6)),
          coordinateIndex,
        });
      }
    }
    const normalizedQuery = normalizeHouseNumber(houseNumberQuery);
    return candidates.sort((left, right) => {
      const leftExact = normalizeHouseNumber(left.houseNumber) === normalizedQuery ? 1 : 0;
      const rightExact = normalizeHouseNumber(right.houseNumber) === normalizedQuery ? 1 : 0;
      return rightExact - leftExact;
    });
  }

  function loadedAddressSearchResult(
    street: LoadedStreetCandidate,
    house: LoadedHouseNumberCandidate,
    distanceMeters: number,
  ): SearchResult {
    const aliases = [
      `${house.houseNumber} ${street.result.name}`.trim(),
      ...(street.aliases ?? []).map((alias) => `${alias} ${house.houseNumber}`.trim()),
      ...(street.aliases ?? []).map((alias) => `${house.houseNumber} ${alias}`.trim()),
    ].filter((alias, index, list) => alias && list.indexOf(alias) === index).slice(0, 12);
    const sourceId = sourceFeatureId(house.feature) ?? street.result.sourceId;
    const sourceTile = sourceFeatureTile(house.feature) ?? street.result.sourceTile;
    const sourceZoom = sourceFeatureZoom(house.feature) ?? street.result.sourceZoom;
    const confidence = Math.max(0.05, 1 - (distanceMeters / loadedAddressJoinRadiusMeters));

    return {
      id: `${street.result.id}:address:${normalizeHouseNumber(house.houseNumber)}:${house.lat.toFixed(6)}:${house.lng.toFixed(6)}`,
      name: `${street.result.name} ${house.houseNumber}`.trim(),
      lat: house.lat,
      lng: house.lng,
      type: 'house',
      class: 'building',
      displayName: 'Address',
      aliases,
      placeRank: 30,
      importance: Math.min(1, Math.max(0.05, (street.result.importance ?? 0.2) + (confidence * 0.05))),
      addressType: 'house',
      sourceLayer: loadedHouseNumberSourceLayer,
      sourceZoom,
      sourceId,
      sourceTile,
    };
  }

  async function searchAddressInBasemapTiles(request: MapDetailSearchRequest): Promise<SearchResult[]> {
    if (!request.addressQuery || !request.streetCandidates?.length || !readBasemapVectorTile) return [];
    return await searchStreetAddressInVectorTiles({
      addressQuery: request.addressQuery,
      streetCandidates: request.streetCandidates,
      readTile: readBasemapVectorTile,
      sourceZoom: Math.min(14, basemapConfig.maxNativeZoom),
      streetLayer: loadedStreetSourceLayer,
      houseNumberLayer: loadedHouseNumberSourceLayer,
      maxJoinRadiusMeters: loadedAddressJoinRadiusMeters,
    });
  }

  async function searchLoadedMapDetailFeatures(request: MapDetailSearchRequest): Promise<SearchResult[]> {
    if (!map || !mapReady) return [];

    if (request.addressQuery) {
      const streets = loadedStreetCandidates(request.addressQuery.streetQuery);
      if (streets.length === 0) {
        if (request.streetCandidates?.length) {
          return await searchAddressInBasemapTiles(request);
        }
        return [];
      }

      const results: Array<{ result: SearchResult; distanceMeters: number }> = [];
      for (const house of loadedHouseNumberCandidates(request.addressQuery.houseNumber)) {
        const houseCoordinate: [number, number] = [house.lng, house.lat];
        let bestStreet: LoadedStreetCandidate | null = null;
        let bestDistanceMeters = Number.POSITIVE_INFINITY;
        for (const street of streets) {
          const distanceMeters = distanceToLineStringsMeters(houseCoordinate, street.lines);
          if (distanceMeters < bestDistanceMeters) {
            bestDistanceMeters = distanceMeters;
            bestStreet = street;
          }
        }
        if (!bestStreet || bestDistanceMeters > loadedAddressJoinRadiusMeters) continue;
        results.push({
          result: loadedAddressSearchResult(bestStreet, house, bestDistanceMeters),
          distanceMeters: bestDistanceMeters,
        });
      }
      if (results.length > 0) {
        return results
          .sort((left, right) => left.distanceMeters - right.distanceMeters)
          .map(({ result }) => result)
          .slice(0, 10);
      }
      if (request.streetCandidates?.length) {
        return await searchAddressInBasemapTiles(request);
      }
      return [];
    }

    return loadedStreetCandidates(request.query)
      .map((candidate) => candidate.result)
      .slice(0, 10);
  }

  function activePlaceFromLabelFeature(feature: MapGeoJSONFeature, event: MapMouseEvent): ActivePlace | null {
    const name = labelFeatureName(feature);
    if (!name) return null;

    const coordinate = firstCoordinateFromGeometry(feature.geometry);
    const lng = coordinate?.[0] ?? event.lngLat.lng;
    const lat = coordinate?.[1] ?? event.lngLat.lat;
    const type = labelFeatureType(feature);
    const sourceId = typeof feature.id === 'string' || typeof feature.id === 'number'
      ? String(feature.id)
      : undefined;
    const rank = numberProperty(feature.properties ?? {}, 'rank');

    return {
      id: `map-label:${feature.sourceLayer ?? feature.layer.id}:${sourceId ?? name}:${lat.toFixed(5)}:${lng.toFixed(5)}`,
      name,
      lat,
      lng,
      type,
      class: labelFeatureClass(feature),
      displayName: labelFeatureDisplayName(feature),
      placeRank: ['country', 'state', 'region', 'province'].includes(type.toLowerCase()) ? rank : undefined,
      sourceLayer: feature.sourceLayer,
      sourceZoom: typeof feature._z === 'number' ? feature._z : undefined,
      sourceId,
      source: 'search',
    };
  }

  function goToSearchResult(result: SearchResult) {
    const place: ActivePlace = {
      id: result.id,
      name: result.name,
      lat: result.lat,
      lng: result.lng,
      type: result.type,
      class: result.class,
      displayName: result.displayName,
      context: result.context,
      contextParts: result.contextParts,
      boundingBox: result.boundingBox,
      placeRank: result.placeRank,
      sourceLayer: result.sourceLayer,
      sourceZoom: result.sourceZoom,
      sourceId: result.sourceId,
      sourceTile: result.sourceTile,
      source: 'search',
    };
    mapsStore.setActivePlace(place);
    setActivePlaceInHash(place);
  }

  function selectLabelPlace(place: ActivePlace) {
    mapsStore.setActivePlace(place);
    setActivePlaceInHash(place);
  }

  function currentInteractiveLabelLayerIds(): string[] {
    if (!map) return [];
    return interactiveLabelLayerIds.filter((id) => !!map?.getLayer(id));
  }

  function firstInteractiveLabelPlace(event: MapMouseEvent): ActivePlace | null {
    if (!map) return null;
    const layerIds = currentInteractiveLabelLayerIds();
    if (layerIds.length === 0) return null;

    try {
      const hitbox: [[number, number], [number, number]] = [
        [event.point.x - labelHitTolerancePx, event.point.y - labelHitTolerancePx],
        [event.point.x + labelHitTolerancePx, event.point.y + labelHitTolerancePx],
      ];
      for (const feature of map.queryRenderedFeatures(hitbox, { layers: layerIds })) {
        const place = activePlaceFromLabelFeature(feature, event);
        if (place) return place;
      }
    } catch {
      return null;
    }
    return null;
  }

  function setMapCursor(cursor: string) {
    if (!map) return;
    map.getCanvas().style.cursor = cursor;
  }

  function handleMapMouseMove(event: MapMouseEvent) {
    if (mapsStore.isAddPlaceModalOpen) {
      setMapCursor('');
      return;
    }
    if (isMeasureDistanceActive) {
      setMapCursor('crosshair');
      return;
    }
    setMapCursor(firstInteractiveLabelPlace(event) ? 'pointer' : '');
  }

  function handleMapMouseOut() {
    setMapCursor('');
  }

  function closeContextMenu() {
    contextMenu = null;
    contextMenuUrlCopied = false;
  }

  function clampContextMenuPosition(point: { x: number; y: number }) {
    const width = mapContainer?.clientWidth ?? window.innerWidth;
    const height = mapContainer?.clientHeight ?? window.innerHeight;
    return {
      x: Math.max(contextMenuMargin, Math.min(point.x, width - contextMenuWidth - contextMenuMargin)),
      y: Math.max(contextMenuMargin, Math.min(point.y, height - contextMenuHeight - contextMenuMargin)),
    };
  }

  function formatContextCoordinate(value: number, positive: string, negative: string): string {
    const normalized = Math.abs(value) < 0.000005 ? 0 : value;
    return `${Math.abs(normalized).toFixed(5)} ${normalized >= 0 ? positive : negative}`;
  }

  function formatContextCoordinates(lat: number, lng: number): string {
    return `${formatContextCoordinate(lat, 'N', 'S')}, ${formatContextCoordinate(lng, 'E', 'W')}`;
  }

  function coordinatePlace(lat: number, lng: number): ActivePlace {
    const normalizedLat = Math.abs(lat) < 0.0000005 ? 0 : lat;
    const normalizedLng = Math.abs(lng) < 0.0000005 ? 0 : lng;
    return {
      id: `coordinate:${normalizedLat.toFixed(6)}:${normalizedLng.toFixed(6)}`,
      name: 'Dropped pin',
      lat: normalizedLat,
      lng: normalizedLng,
      type: 'coordinate',
      displayName: formatContextCoordinates(normalizedLat, normalizedLng),
      source: 'search',
    };
  }

  function handleWindowPointerDown(event: PointerEvent) {
    if (!contextMenu || event.button === 2) return;
    const target = event.target as Node | null;
    if (target && contextMenuElement?.contains(target)) return;
    closeContextMenu();
  }

  function handleWindowKeydown(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      if (isPhotoGalleryOpen) {
        closePhotoGallery();
        return;
      }
      if (isReviewModalOpen) {
        closeReviewModal();
        return;
      }
      if (isSaveListsPanelOpen) {
        isSaveListsPanelOpen = false;
        return;
      }
      if (contextMenu) {
        closeContextMenu();
        return;
      }
      if (isMeasureDistanceOpen) {
        clearMeasureDistance();
        return;
      }
      closeContextMenu();
    }
  }

  function isEditableKeyboardTarget(target: EventTarget | null): boolean {
    if (!(target instanceof HTMLElement)) return false;
    const tagName = target.tagName.toLowerCase();
    return tagName === 'input'
      || tagName === 'textarea'
      || tagName === 'select'
      || target.isContentEditable;
  }

  function keyboardZoomDirection(event: KeyboardEvent): -1 | 0 | 1 {
    if (event.key === '+' || event.key === '=' || event.code === 'NumpadAdd') return 1;
    if (event.key === '-' || event.key === '_' || event.code === 'NumpadSubtract') return -1;
    return 0;
  }

  function handleMapKeydown(event: KeyboardEvent) {
    if (!map || event.altKey || event.ctrlKey || event.metaKey || isEditableKeyboardTarget(event.target)) return;

    let panX = 0;
    let panY = 0;
    switch (event.key) {
      case 'ArrowLeft':
        panX = -1;
        break;
      case 'ArrowRight':
        panX = 1;
        break;
      case 'ArrowUp':
        panY = -1;
        break;
      case 'ArrowDown':
        panY = 1;
        break;
    }

    if (panX || panY) {
      const step = event.shiftKey ? keyboardLargePanStepPx : keyboardPanStepPx;
      event.preventDefault();
      event.stopPropagation();
      map.panBy([panX * step, panY * step], { duration: keyboardNavigationDurationMs }, { originalEvent: event });
      return;
    }

    const zoomDirection = keyboardZoomDirection(event);
    if (!zoomDirection) return;

    event.preventDefault();
    event.stopPropagation();
    const nextZoom = Math.max(
      basemapConfig.minZoom,
      Math.min(basemapConfig.maxZoom, map.getZoom() + zoomDirection),
    );
    map.easeTo({
      zoom: nextZoom,
      duration: keyboardNavigationDurationMs,
    }, { originalEvent: event });
  }

  function handleMapContextMenu(event: MapMouseEvent) {
    event.preventDefault();
    event.originalEvent.preventDefault();
    const position = clampContextMenuPosition(event.point);
    contextMenu = {
      lat: event.lngLat.lat,
      lng: event.lngLat.lng,
      x: position.x,
      y: position.y,
    };
    contextMenuUrlCopied = false;
  }

  function handleMapClick(event: MapMouseEvent) {
    closeContextMenu();
    if (isMeasureDistanceActive) {
      addMeasureDistancePoint(event.lngLat.lat, event.lngLat.lng);
      return;
    }
    if (mapsStore.isAddPlaceModalOpen) {
      mapsStore.setPendingPlaceLocation(event.lngLat.lat, event.lngLat.lng);
      return;
    }

    const place = firstInteractiveLabelPlace(event);
    if (!place) return;
    selectLabelPlace(place);
  }

  function copyText(text: string): Promise<void> {
    if (navigator.clipboard?.writeText && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }

    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    const copied = document.execCommand('copy');
    textarea.remove();
    return copied ? Promise.resolve() : Promise.reject(new Error('Copy failed'));
  }

  function activePlaceShareUrl(): string {
    if (activePlace && !parseActivePlaceFromHash(window.location.hash)) {
      setActivePlaceInHash(activePlace);
    }
    return window.location.href;
  }

  async function copyActivePlaceUrl() {
    try {
      await copyText(activePlaceShareUrl());
      activePlaceUrlCopied = true;
      if (activePlaceShareTimer) clearTimeout(activePlaceShareTimer);
      activePlaceShareTimer = setTimeout(() => {
        activePlaceUrlCopied = false;
        activePlaceShareTimer = null;
      }, 1600);
    } catch (error) {
      console.warn('[maps] failed to copy place URL', error);
    }
  }

  function savedListIconClass(icon: SavedPlaceList['icon']): string {
    switch (icon) {
      case 'heart':
        return 'i-lucide-heart';
      case 'flag':
        return 'i-lucide-flag';
      case 'briefcase':
        return 'i-lucide-briefcase';
      case 'star':
        return 'i-lucide-star';
      case 'map-pin':
        return 'i-lucide-map-pin';
      case 'bookmark':
      default:
        return 'i-lucide-bookmark';
    }
  }

  function isPlaceInSavedList(list: SavedPlaceList): boolean {
    return Boolean(activePlace && mapsStore.isPlaceInSavedList(list.id, activePlace));
  }

  async function toggleActivePlaceInSavedList(list: SavedPlaceList) {
    if (!activePlace || savedListStatus === 'saving') return;
    savedListStatus = 'saving';
    try {
      await mapsStore.toggleSavedPlaceInList(list.id, activePlace);
      savedListStatus = 'idle';
    } catch (error) {
      console.warn('[maps] failed to update saved place list', error);
      savedListStatus = 'error';
    }
  }

  async function toggleSavedListVisibility(list: SavedPlaceList) {
    if (savedListStatus === 'saving') return;
    savedListStatus = 'saving';
    const nextVisibility: SavedPlaceListVisibility = list.visibility === 'public' ? 'private' : 'public';
    try {
      await mapsStore.setSavedPlaceListVisibility(list.id, nextVisibility);
      savedListStatus = 'idle';
    } catch (error) {
      console.warn('[maps] failed to update saved place list visibility', error);
      savedListStatus = 'error';
    }
  }

  async function copySavedListUrl(list: SavedPlaceList) {
    if (!list.urls?.web) return;
    try {
      await copyText(list.urls.web);
      copiedSavedListId = list.id;
      if (savedListCopyTimer) clearTimeout(savedListCopyTimer);
      savedListCopyTimer = setTimeout(() => {
        copiedSavedListId = null;
        savedListCopyTimer = null;
      }, 1600);
    } catch (error) {
      console.warn('[maps] failed to copy saved place list URL', error);
    }
  }

  function publicListUrlTitle(list: SavedPlaceList): string {
    return list.urls?.web ? 'Copy public URL' : 'Public URL pending';
  }

  function savedListSlug(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      || 'list';
  }

  function minimizedLeftPanelTitle(): string {
    if (showingLibraryPanel) return 'Library';
    if (activePlace) return activePlace.name;
    if (routedSavedPlaceList) return routedSavedPlaceList.name;
    return 'Map panel';
  }

  function minimizedLeftPanelSubtitle(): string {
    if (showingLibraryPanel) return `${libraryListCount} lists`;
    if (showingSavedListPlaceDetail && routedSavedPlaceList) return routedSavedPlaceList.name;
    if (showingSavedListPanel) return 'Saved list';
    if (activePlace) return displayPlaceTypeLabel(activePlace.displayName ?? activePlace.type);
    return 'Tap to restore';
  }

  function minimizedLeftPanelIconClass(): string {
    if (showingLibraryPanel) return 'i-lucide-library';
    if (activePlace) return placeTypeIconClass(activePlace.type ?? activePlace.displayName);
    if (routedSavedPlaceList) return savedListIconClass(routedSavedPlaceList.icon);
    return 'i-lucide-panel-left-open';
  }

  function simpleSavedPlaceListCountText(list: SavedPlaceList): string {
    const total = list.itemCount ?? list.places.length;
    return `${total.toLocaleString()} ${total === 1 ? 'place' : 'places'}`;
  }

  function savedPlaceListMetaText(list: SavedPlaceList): string {
    return `${list.visibility === 'public' ? 'Public' : 'Private'} · ${simpleSavedPlaceListCountText(list)}`;
  }

  function savedExternalPlaceListMetaText(list: SavedExternalPlaceList): string {
    const parts = ['Public'];
    if (typeof list.placeCount === 'number') {
      parts.push(`${list.placeCount.toLocaleString()} ${list.placeCount === 1 ? 'place' : 'places'}`);
    }
    const updated = relativeSavedListTime(list.updatedAt ?? list.createdAt);
    if (updated) parts.push(updated);
    return parts.join(' · ');
  }

  function savedPlaceListToggleMetaText(list: SavedPlaceList): string {
    const parts = [list.visibility === 'public' ? 'Public' : 'Private'];
    if (list.places.length) parts.push(list.places.length.toLocaleString());
    if (list.visibility === 'public' && list.factEvent?.publishError) parts.push('Index failed');
    return parts.join(' · ');
  }

  function discoveredSavedPlaceListMetaText(list: DiscoveredSavedPlaceList): string {
    const parts: string[] = [];
    if (typeof list.placeCount === 'number') {
      parts.push(`${list.placeCount.toLocaleString()} ${list.placeCount === 1 ? 'place' : 'places'}`);
    }
    const updated = relativeSavedListTime(list.updatedAt ?? list.createdAt);
    if (updated) parts.push(updated);
    return parts.join(' · ') || 'Public list';
  }

  function relativeSavedListTime(timestampSeconds: number | undefined): string {
    if (!timestampSeconds) return '';
    const now = Math.floor(Date.now() / 1000);
    const diff = Math.max(0, now - timestampSeconds);
    const minutes = Math.floor(diff / 60);
    const hours = Math.floor(diff / 3600);
    const days = Math.floor(diff / 86400);
    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return new Date(timestampSeconds * 1000).toLocaleDateString();
  }

  function openLibraryPanel(tab: MapsLibraryTab = libraryTab) {
    closeContextMenu();
    isLibraryPanelOpen = true;
    libraryTab = tab;
    savedListStatus = 'idle';
    showNewSavedListForm = false;
    if (!librarySelectedListId && savedPlaceLists.length > 0) {
      librarySelectedListId = libraryOverlayListIds[0] ?? savedPlaceLists[0].id;
    }
  }

  function closeLibraryPanel() {
    isLibraryPanelOpen = false;
    showNewSavedListForm = false;
    savedListStatus = 'idle';
  }

  function createSavedExternalPlaceListFromRoute(
    route: SavedPlaceListRoute,
    list: SavedPlaceList,
    manifest?: SavedPlaceListManifest,
  ): SavedExternalPlaceList {
    const urls = list.urls ?? buildSavedPlaceListUrls({
      listId: route.listId,
      ownerNpub: route.ownerNpub,
      treeName: route.treeName,
    });
    return {
      id: route.listId,
      name: list.name,
      description: list.description,
      ownerNpub: route.ownerNpub,
      treeName: route.treeName,
      icon: list.icon,
      avatarUrl: list.avatarUrl,
      placeCount: list.itemCount ?? manifest?.itemCount ?? list.places.length,
      urls,
      createdAt: manifest?.createdAt ?? list.createdAt,
      updatedAt: manifest?.updatedAt ?? list.updatedAt,
      savedAt: Date.now(),
    };
  }

  function persistSavedExternalPlaceLists(nextLists: SavedExternalPlaceList[]) {
    savedExternalPlaceLists = saveSavedExternalPlaceLists(nextLists);
  }

  function toggleCurrentRoutedExternalPlaceList() {
    if (!currentRoutedExternalPlaceList) return;
    const nextLists = isCurrentRoutedExternalPlaceListSaved
      ? removeSavedExternalPlaceList(savedExternalPlaceLists, currentRoutedExternalPlaceList)
      : upsertSavedExternalPlaceList(savedExternalPlaceLists, currentRoutedExternalPlaceList);
    persistSavedExternalPlaceLists(nextLists);
  }

  function removeSavedExternalPlaceListFromLibrary(list: SavedExternalPlaceList) {
    persistSavedExternalPlaceLists(removeSavedExternalPlaceList(savedExternalPlaceLists, list));
  }

  function openSavedExternalPlaceList(list: SavedExternalPlaceList) {
    closeLibraryPanel();
    mapsStore.setActivePlace(null);
    window.location.hash = savedExternalPlaceListHash(list);
  }

  function toggleLibraryPanel() {
    if (isLibraryPanelOpen) {
      closeLibraryPanel();
      return;
    }
    openLibraryPanel('mine');
  }

  function selectLibraryTab(tab: MapsLibraryTab) {
    libraryTab = tab;
    showNewSavedListForm = false;
    savedListStatus = 'idle';
  }

  function focusLibraryList(list: SavedPlaceList) {
    if (list.places.length > 0 && mapReady && map) {
      focusSavedPlaceList(list);
    }
  }

  function openOwnSavedPlaceList(list: SavedPlaceList) {
    librarySelectedListId = list.id;
    closeLibraryPanel();
    mapsStore.setActivePlace(null);
    lastFocusedSavedListKey = '';
    abortSavedPlaceListViewportLoad();
    resetSavedPlaceListSearchState();
    routedSavedPlaceListSource = null;
    routedSavedPlaceList = list;
    savedListRouteKey = `local/${list.id}:${list.updatedAt}:${list.places.length}`;
    savedListRouteStatus = 'loaded';
    savedListRouteError = '';
    window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}#/`);
  }

  function isLibraryListOverlaid(list: SavedPlaceList): boolean {
    return libraryOverlayListIds.includes(list.id);
  }

  function toggleLibraryOverlayList(list: SavedPlaceList) {
    librarySelectedListId = list.id;
    if (isLibraryListOverlaid(list)) {
      libraryOverlayListIds = libraryOverlayListIds.filter((id) => id !== list.id);
      return;
    }
    libraryOverlayListIds = [...libraryOverlayListIds, list.id].slice(-maxLibraryOverlayLists);
    focusLibraryList(list);
  }

  function clearLibraryOverlays() {
    libraryOverlayListIds = [];
    lastFocusedLibraryListKey = '';
  }

  async function createSavedListFromLibrary() {
    if (savedListStatus === 'saving') return;
    const name = newSavedListName.trim();
    if (!name) return;
    const visibility = newSavedListVisibility;
    newSavedListName = '';
    newSavedListVisibility = 'private';
    showNewSavedListForm = false;
    savedListStatus = 'saving';
    try {
      const list = await mapsStore.createSavedPlaceList({
        name,
        visibility,
        icon: 'bookmark',
      });
      librarySelectedListId = list.id;
      savedListStatus = 'idle';
    } catch (error) {
      console.warn('[maps] failed to create saved place list', error);
      newSavedListName = name;
      newSavedListVisibility = visibility;
      showNewSavedListForm = true;
      savedListStatus = 'error';
    }
  }

  function factTagValue(event: NostrEvent, name: string): string | undefined {
    return event.tags.find((tag) => tag[0] === name && tag[1])?.[1];
  }

  function factTagInteger(event: NostrEvent, name: string): number | undefined {
    const value = factTagValue(event, name);
    if (!value) return undefined;
    const parsed = Number.parseInt(value, 10);
    return Number.isFinite(parsed) ? parsed : undefined;
  }

  function savedPlaceListSubjectId(event: NostrEvent): string | undefined {
    return event.tags.find((tag) => tag[0] === 'i' && tag[2] === 'subject' && tag[1])?.[1];
  }

  function normalizedDiscoverAuthors(pubkeys: string[]): string[] {
    return [...new Set(pubkeys)].filter((pubkey) => /^[0-9a-f]{64}$/i.test(pubkey)).map((pubkey) => pubkey.toLowerCase());
  }

  function createBtcMapFeaturedSavedPlaceList(): DiscoveredSavedPlaceList {
    return {
      id: btcMapSavedPlaceListId,
      name: 'BTC Map',
      description: BTCMAP_LIST_DESCRIPTION,
      ownerPubkey: btcMapCrawlerPubkey,
      ownerNpub: btcMapCrawlerNpub,
      urls: buildSavedPlaceListUrls({
        listId: btcMapSavedPlaceListId,
        ownerNpub: btcMapCrawlerNpub,
        treeName: 'btcmap',
      }),
      eventId: 'featured:btcmap',
    };
  }

  function discoveredSavedPlaceListFromEvent(event: NostrEvent): DiscoveredSavedPlaceList | null {
    if (factTagValue(event, 'type') !== 'saved_place_list') return null;
    if (factTagValue(event, 'visibility') !== 'public') return null;
    const id = savedPlaceListSubjectId(event);
    const name = factTagValue(event, 'name');
    if (!id || !name) return null;
    let ownerNpub: string;
    try {
      ownerNpub = pubkeyToNpub(event.pubkey);
    } catch {
      return null;
    }
    return {
      id,
      name,
      description: factTagValue(event, 'description'),
      ownerPubkey: event.pubkey,
      ownerNpub,
      placeCount: factTagInteger(event, 'place_count'),
      urls: normalizeSavedPlaceListUrls({
        web: factTagValue(event, 'web_url'),
        htree: factTagValue(event, 'htree_url'),
        data: factTagValue(event, 'data_url'),
        htreeData: factTagValue(event, 'htree_data_url'),
      }),
      createdAt: factTagInteger(event, 'created_at') ?? event.created_at,
      updatedAt: factTagInteger(event, 'updated_at') ?? event.created_at,
      eventId: event.id,
    };
  }

  function mergeDiscoveredSavedPlaceList(lists: DiscoveredSavedPlaceList[], list: DiscoveredSavedPlaceList): DiscoveredSavedPlaceList[] {
    const existingIndex = lists.findIndex((item) => item.id === list.id);
    const current = existingIndex >= 0 ? lists[existingIndex] : undefined;
    const next = current && (current.updatedAt ?? 0) > (list.updatedAt ?? 0)
      ? lists
      : existingIndex >= 0
        ? lists.map((item, index) => index === existingIndex ? list : item)
        : [...lists, list];
    return [...next]
      .sort((left, right) => (
        (right.updatedAt ?? right.createdAt ?? 0) - (left.updatedAt ?? left.createdAt ?? 0)
        || left.name.localeCompare(right.name)
      ))
      .slice(0, 80);
  }

  function upsertFollowingDiscoveredSavedPlaceList(list: DiscoveredSavedPlaceList) {
    followingDiscoveredSavedPlaceLists = mergeDiscoveredSavedPlaceList(followingDiscoveredSavedPlaceLists, list);
  }

  function upsertOtherDiscoveredSavedPlaceList(list: DiscoveredSavedPlaceList) {
    otherDiscoveredSavedPlaceLists = mergeDiscoveredSavedPlaceList(otherDiscoveredSavedPlaceLists, list);
  }

  function discoveredSavedPlaceListHash(list: DiscoveredSavedPlaceList): string {
    const webUrl = list.urls?.web;
    if (webUrl) {
      try {
        const parsed = new URL(webUrl, window.location.origin);
        if (parsed.hash) return parsed.hash;
      } catch {
        const hashIndex = webUrl.indexOf('#');
        if (hashIndex >= 0) return webUrl.slice(hashIndex);
      }
    }
    return `#/?list=${encodeURIComponent(list.id)}&owner=${encodeURIComponent(list.ownerNpub)}&tree=maps`;
  }

  function openDiscoveredSavedPlaceList(list: DiscoveredSavedPlaceList) {
    closeLibraryPanel();
    window.location.hash = discoveredSavedPlaceListHash(list);
  }

  $effect(() => {
    const relays = $settingsStore.network.relays;
    if (!$settingsStore.networkLoaded || defaultDiscoverFollowStatus !== 'loaded') return;
    return watchDefaultSocialGraphFollows(relays, pubkeys => { defaultDiscoverFollowPubkeys = pubkeys; });
  });

  function requestDefaultDiscoverFollows() {
    if (defaultDiscoverFollowStatus === 'loading' || defaultDiscoverFollowStatus === 'loaded') return;
    defaultDiscoverFollowStatus = 'loading';
    void loadDefaultSocialGraphFollowPubkeys($settingsStore.network.relays)
      .then((pubkeys) => {
        defaultDiscoverFollowPubkeys = pubkeys;
        defaultDiscoverFollowStatus = 'loaded';
      })
      .catch((error) => {
        console.warn('[maps] failed to load default discover follows', error);
        defaultDiscoverFollowPubkeys = [];
        defaultDiscoverFollowStatus = 'error';
      });
  }

  function discoverSavedPlaceListFilter(authors: string[]): NostrFilter {
    return {
      kinds: [FACT_OP_KIND],
      authors,
      '#type': ['saved_place_list'],
      '#visibility': ['public'],
      limit: 80,
    } as unknown as NostrFilter;
  }

  function discoverAuthorsKey(authors: string[]): string {
    return normalizedDiscoverAuthors(authors).join(',');
  }

  function startDiscoveredSavedPlaceListSubscription(options: {
    authors: string[];
    isCurrent: () => boolean;
    getStatus: () => DiscoverListStatus;
    setStatus: (status: DiscoverListStatus) => void;
    setError: (message: string) => void;
    upsert: (list: DiscoveredSavedPlaceList) => void;
  }): () => void {
    const { authors, isCurrent, getStatus, setStatus, setError, upsert } = options;
    const filter = discoverSavedPlaceListFilter(authors);
    let readyTimer: number | null = null;
    let subscription: ReturnType<typeof nostr.subscribe> | null = null;
    try {
      subscription = nostr.subscribe(filter, { closeAfterHistory: false });
      readyTimer = window.setTimeout(() => {
        if (isCurrent() && getStatus() === 'loading') {
          setStatus('loaded');
        }
      }, 1600);
      subscription.on('event', (event: NostrEvent) => {
        if (!isCurrent()) return;
        const list = discoveredSavedPlaceListFromEvent(event);
        if (!list) return;
        upsert(list);
        setStatus('loaded');
      });
      subscription.on('history', () => {
        if (isCurrent() && getStatus() === 'loading') {
          setStatus('loaded');
        }
      });
    } catch (error) {
      setStatus('error');
      setError(error instanceof Error ? error.message : 'Could not load public lists');
    }

    return () => {
      if (readyTimer) window.clearTimeout(readyTimer);
      subscription?.stop();
    };
  }

  function closeRoutedSavedPlaceList() {
    if (savedListRouteAbortController) {
      savedListRouteAbortController.abort();
      savedListRouteAbortController = null;
    }
    mapsStore.setActivePlace(null);
    savedListRouteKey = '';
    lastFocusedSavedListKey = '';
    abortSavedPlaceListViewportLoad();
    resetSavedPlaceListSearchState();
    routedSavedPlaceListSource = null;
    routedSavedPlaceList = null;
    savedListRouteStatus = 'idle';
    savedListRouteError = '';
    window.location.hash = '#/';
  }

  function savedPlaceListRouteKey(route: SavedPlaceListRoute): string {
    return `${route.ownerNpub}/${route.treeName}/${route.listId}`;
  }

  function routedListTreePath(route: SavedPlaceListRoute, relativePath: string): string {
    const cleanRelativePath = relativePath
      .split('/')
      .map((part) => part.trim())
      .filter(Boolean)
      .join('/');
    return `${savedPlaceListDirectoryPath(route.listId)}/${cleanRelativePath}`;
  }

  async function resolveRoutedSavedPlaceListRoot(route: SavedPlaceListRoute, signal: AbortSignal): Promise<CID> {
    const key = getResolverKey(route.ownerNpub, route.treeName);
    if (!key) throw new Error('Invalid saved-place list route');
    const resolver = getRefResolver();

    return await new Promise<CID>((resolve, reject) => {
      let settled = false;
      let unsubscribe: (() => void) | undefined;
      const cleanup = () => {
        settled = true;
        window.clearTimeout(timeout);
        signal.removeEventListener('abort', abort);
        unsubscribe?.();
      };
      const abort = () => {
        if (settled) return;
        cleanup();
        reject(new DOMException('Saved-place list load was cancelled', 'AbortError'));
      };
      const timeout = window.setTimeout(() => {
        if (settled) return;
        cleanup();
        reject(new Error('Timed out resolving saved-place list root'));
      }, savedPlaceListRouteResolveTimeoutMs);

      signal.addEventListener('abort', abort, { once: true });
      unsubscribe = resolver.subscribe(key, (rootCid) => {
        if (!rootCid || settled) return;
        cleanup();
        resolve(rootCid);
      });
    });
  }

  async function readRoutedSavedPlaceListJson(rootCid: CID, route: SavedPlaceListRoute, relativePath: string, signal: AbortSignal): Promise<unknown> {
    const tree = getTree();
    const resolved = await tree.resolvePath(rootCid, routedListTreePath(route, relativePath), signal);
    if (!resolved) {
      throw new Error(`Saved-place list file not found: ${relativePath}`);
    }
    const data = await tree.readFile(resolved.cid, { maxBytes: savedPlaceListJsonMaxBytes });
    if (!data) {
      throw new Error(`Saved-place list file could not be read: ${relativePath}`);
    }
    return JSON.parse(savedPlaceListTextDecoder.decode(data));
  }

  async function loadRoutedSavedPlaceListPage(
    rootCid: CID,
    route: SavedPlaceListRoute,
    source: SavedPlaceListItemsSource,
    pageIndex: number,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    return normalizeSavedPlaceListItems(
      await readRoutedSavedPlaceListJson(rootCid, route, `${source.dir}/${savedPlaceListItemPageFile(pageIndex)}`, signal),
    );
  }

  async function loadCachedRoutedSavedPlaceListPage(
    sourceState: RoutedSavedPlaceListSourceState,
    pageIndex: number,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    if (signal.aborted) {
      throw new DOMException('Saved-place list load was cancelled', 'AbortError');
    }
    const cached = sourceState.pageCache.get(pageIndex);
    if (cached) return cached;
    const page = await loadRoutedSavedPlaceListPage(
      sourceState.rootCid,
      sourceState.route,
      sourceState.manifest.items,
      pageIndex,
      signal,
    );
    if (!signal.aborted) {
      sourceState.pageCache.set(pageIndex, page);
    }
    return page;
  }

  async function loadSequentialRoutedSavedPlaceListItems(
    sourceState: RoutedSavedPlaceListSourceState,
    limit: number,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    const source = sourceState.manifest.items;
    const places: SavedPlaceListItem[] = [];
    const pageLimit = Math.min(
      source.pageCount,
      Math.max(1, Math.ceil(limit / source.pageSize)),
    );
    for (let index = 0; index < pageLimit && places.length < limit; index += 1) {
      const page = await loadCachedRoutedSavedPlaceListPage(sourceState, index, signal);
      places.push(...page.slice(0, limit - places.length));
    }
    return places;
  }

  async function loadSampledRoutedSavedPlaceListItems(
    sourceState: RoutedSavedPlaceListSourceState,
    limit: number,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    const source = sourceState.manifest.items;
    const requests = buildSavedPlaceListSamplePageRequests(source, {
      limit,
      maxPages: maxInitialRoutedListPages,
    });
    const pageReads = await Promise.all(requests.map(async (request) => {
      const page = await loadCachedRoutedSavedPlaceListPage(sourceState, request.pageIndex, signal);
      return request.offsets
        .map((offset) => page[offset])
        .filter((item): item is SavedPlaceListItem => Boolean(item));
    }));
    return uniqueSavedPlaceListItems(pageReads.flat()).slice(0, limit);
  }

  function uniqueSavedPlaceListItems(items: SavedPlaceListItem[]): SavedPlaceListItem[] {
    const seenKeys: string[] = [];
    const unique: SavedPlaceListItem[] = [];
    for (const item of items) {
      if (seenKeys.includes(item.key)) continue;
      seenKeys.push(item.key);
      unique.push(item);
    }
    return unique;
  }

  function createSavedPlaceListFromManifest(
    manifest: SavedPlaceListManifest,
    places: SavedPlaceListItem[],
    options: {
      isSampled?: boolean;
      isViewportFiltered?: boolean;
    } = {},
  ): SavedPlaceList {
    return {
      id: manifest.id,
      name: manifest.name,
      description: manifest.description,
      icon: manifest.icon,
      avatarUrl: manifest.avatarUrl,
      visibility: manifest.visibility,
      urls: normalizeSavedPlaceListUrls(manifest.urls),
      places,
      itemCount: manifest.itemCount,
      loadedItemCount: places.length,
      isSampled: options.isSampled,
      isViewportFiltered: options.isViewportFiltered,
      createdAt: manifest.createdAt,
      updatedAt: manifest.updatedAt,
    };
  }

  function isLargeRoutedSavedPlaceList(manifest: SavedPlaceListManifest): boolean {
    const threshold = manifest.sampling?.world?.threshold ?? savedPlaceListLargeThreshold;
    return manifest.itemCount > Math.max(0, threshold);
  }

  async function loadRoutedSavedPlaceList(route: SavedPlaceListRoute, signal: AbortSignal): Promise<RoutedSavedPlaceListLoadResult> {
    const rootCid = await resolveRoutedSavedPlaceListRoot(route, signal);
    const manifest = normalizeSavedPlaceListManifest(
      await readRoutedSavedPlaceListJson(rootCid, route, SAVED_PLACE_LIST_MANIFEST_FILE, signal),
    );
    if (!manifest || manifest.id.toLowerCase() !== route.listId) {
      throw new Error('Invalid saved-place list manifest');
    }

    const sourceState: RoutedSavedPlaceListSourceState = {
      route,
      rootCid,
      manifest,
      isLarge: isLargeRoutedSavedPlaceList(manifest),
      overviewItems: [],
      pageCache: new Map(),
    };
    const dynamicWorldSample = manifest.sampling?.world;
    const dynamicLimit = Math.min(
      maxInitialRoutedListItems,
      dynamicWorldSample?.sampleSize ?? maxInitialRoutedListItems,
    );
    const places = sourceState.isLarge
      ? await loadSampledRoutedSavedPlaceListItems(sourceState, dynamicLimit, signal)
      : await loadSequentialRoutedSavedPlaceListItems(sourceState, manifest.itemCount, signal);
    sourceState.overviewItems = places;

    return {
      list: createSavedPlaceListFromManifest(manifest, places, {
        isSampled: sourceState.isLarge,
      }),
      sourceState,
    };
  }

  function normalizeLongitude(lng: number): number {
    return ((((lng + 180) % 360) + 360) % 360) - 180;
  }

  function savedPlaceListViewportBounds(): SavedPlaceViewportBounds | null {
    if (!map) return null;
    const bounds = map.getBounds();
    return {
      south: Math.max(-90, Math.min(bounds.getSouth(), bounds.getNorth())),
      north: Math.min(90, Math.max(bounds.getSouth(), bounds.getNorth())),
      west: bounds.getWest(),
      east: bounds.getEast(),
    };
  }

  function savedPlaceListItemInBounds(item: SavedPlaceListItem, bounds: SavedPlaceViewportBounds): boolean {
    if (item.lat < bounds.south || item.lat > bounds.north) return false;
    if (bounds.east - bounds.west >= 360) return true;
    const west = normalizeLongitude(bounds.west);
    const east = normalizeLongitude(bounds.east);
    const lng = normalizeLongitude(item.lng);
    return west <= east
      ? lng >= west && lng <= east
      : lng >= west || lng <= east;
  }

  async function loadViewportRoutedSavedPlaceListItems(
    sourceState: RoutedSavedPlaceListSourceState,
    bounds: SavedPlaceViewportBounds,
    limit: number,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    const places: SavedPlaceListItem[] = [];
    const seenKeys = new Set<string>();
    const source = sourceState.manifest.items;
    for (let start = 0; start < source.pageCount && places.length < limit; start += savedPlaceListViewportPageBatchSize) {
      if (signal.aborted) {
        throw new DOMException('Saved-place list load was cancelled', 'AbortError');
      }
      const pageIndexes = Array.from(
        { length: Math.min(savedPlaceListViewportPageBatchSize, source.pageCount - start) },
        (_, offset) => start + offset,
      );
      const pages = await Promise.all(pageIndexes.map((pageIndex) => (
        loadCachedRoutedSavedPlaceListPage(sourceState, pageIndex, signal)
      )));
      for (const page of pages) {
        for (const item of page) {
          if (places.length >= limit) break;
          if (seenKeys.has(item.key) || !savedPlaceListItemInBounds(item, bounds)) continue;
          seenKeys.add(item.key);
          places.push(item);
        }
      }
    }
    return places;
  }

  function abortSavedPlaceListViewportLoad() {
    savedListViewportRequestId += 1;
    if (savedListViewportAbortController) {
      savedListViewportAbortController.abort();
      savedListViewportAbortController = null;
    }
  }

  function abortSavedPlaceListSearch() {
    savedListSearchRequestId += 1;
    if (savedListSearchAbortController) {
      savedListSearchAbortController.abort();
      savedListSearchAbortController = null;
    }
  }

  function resetSavedPlaceListSearchState() {
    abortSavedPlaceListSearch();
    savedListSearchQuery = '';
    savedListSearchStatus = 'idle';
  }

  function savedPlaceListSearchText(item: SavedPlaceListItem): string {
    return [
      item.name,
      item.displayName,
      item.type,
      visiblePlaceContext(item.context),
      item.details?.address,
      item.details?.description,
      item.details?.website,
      item.details?.phone,
      item.details?.email,
    ].filter(Boolean).join(' ').toLowerCase();
  }

  function savedPlaceListSearchScore(item: SavedPlaceListItem, query: string, terms: string[]): number {
    const name = item.name.toLowerCase();
    const type = `${item.displayName ?? ''} ${item.type ?? ''}`.toLowerCase();
    const context = `${visiblePlaceContext(item.context)} ${item.details?.address ?? ''}`.toLowerCase();
    let score = 0;
    if (name === query) score += 120;
    if (name.startsWith(query)) score += 90;
    if (name.includes(query)) score += 60;
    if (type.includes(query)) score += 25;
    if (context.includes(query)) score += 15;
    for (const term of terms) {
      if (name.includes(term)) score += 8;
      else if (type.includes(term)) score += 4;
      else if (context.includes(term)) score += 2;
    }
    return score;
  }

  async function searchRoutedSavedPlaceListItems(
    sourceState: RoutedSavedPlaceListSourceState,
    query: string,
    signal: AbortSignal,
  ): Promise<SavedPlaceListItem[]> {
    const normalizedQuery = query.trim().toLowerCase();
    const terms = normalizedQuery.split(/\s+/).filter(Boolean);
    if (!terms.length) return [];

    const matches: Array<{ item: SavedPlaceListItem; score: number }> = [];
    const seenKeys = new Set<string>();
    const source = sourceState.manifest.items;
    for (let start = 0; start < source.pageCount; start += savedPlaceListSearchPageBatchSize) {
      if (signal.aborted) {
        throw new DOMException('Saved-place list search was cancelled', 'AbortError');
      }
      const pageIndexes = Array.from(
        { length: Math.min(savedPlaceListSearchPageBatchSize, source.pageCount - start) },
        (_, offset) => start + offset,
      );
      const pages = await Promise.all(pageIndexes.map((pageIndex) => (
        loadCachedRoutedSavedPlaceListPage(sourceState, pageIndex, signal)
      )));
      for (const item of pages.flat()) {
        if (seenKeys.has(item.key)) continue;
        const haystack = savedPlaceListSearchText(item);
        if (!terms.every((term) => haystack.includes(term))) continue;
        seenKeys.add(item.key);
        matches.push({
          item,
          score: savedPlaceListSearchScore(item, normalizedQuery, terms),
        });
      }
    }

    return matches
      .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name))
      .slice(0, maxSavedPlaceListSearchResults)
      .map((match) => match.item);
  }

  function restoreRoutedSavedPlaceListFromSearch() {
    const sourceState = routedSavedPlaceListSource;
    if (!sourceState || !routedSavedPlaceList) return;
    if (sourceState.isLarge && mapReady && map && map.getZoom() >= savedPlaceListViewportMinZoom) {
      refreshRoutedSavedPlaceListForViewport();
      return;
    }
    routedSavedPlaceList = createSavedPlaceListFromManifest(sourceState.manifest, sourceState.overviewItems, {
      isSampled: sourceState.isLarge,
    });
  }

  function handleSavedPlaceListSearchQuery(query: string) {
    const sourceState = routedSavedPlaceListSource;
    savedListSearchQuery = query;
    abortSavedPlaceListSearch();
    if (!sourceState || !routedSavedPlaceList) return;

    const trimmed = query.trim();
    if (!trimmed) {
      savedListSearchStatus = 'idle';
      restoreRoutedSavedPlaceListFromSearch();
      return;
    }

    abortSavedPlaceListViewportLoad();
    const requestId = savedListSearchRequestId;
    const controller = new AbortController();
    savedListSearchAbortController = controller;
    savedListSearchStatus = 'searching';
    void searchRoutedSavedPlaceListItems(sourceState, trimmed, controller.signal)
      .then((places) => {
        if (controller.signal.aborted || requestId !== savedListSearchRequestId) return;
        routedSavedPlaceList = createSavedPlaceListFromManifest(sourceState.manifest, places);
        savedListSearchStatus = 'idle';
      })
      .catch((error) => {
        if (controller.signal.aborted) return;
        console.warn('[maps] failed to search saved place list', error);
        savedListSearchStatus = 'error';
      });
  }

  function refreshRoutedSavedPlaceListForViewport() {
    const sourceState = routedSavedPlaceListSource;
    if (!sourceState || !routedSavedPlaceList || !sourceState.isLarge || !mapReady || !map) return;
    if (savedListSearchQuery.trim()) return;
    abortSavedPlaceListViewportLoad();

    if (map.getZoom() < savedPlaceListViewportMinZoom) {
      routedSavedPlaceList = createSavedPlaceListFromManifest(sourceState.manifest, sourceState.overviewItems, {
        isSampled: true,
      });
      return;
    }

    const bounds = savedPlaceListViewportBounds();
    if (!bounds) return;
    const requestId = savedListViewportRequestId;
    const controller = new AbortController();
    savedListViewportAbortController = controller;
    void loadViewportRoutedSavedPlaceListItems(sourceState, bounds, maxViewportRoutedListItems, controller.signal)
      .then((places) => {
        if (controller.signal.aborted || requestId !== savedListViewportRequestId) return;
        routedSavedPlaceList = createSavedPlaceListFromManifest(sourceState.manifest, places, {
          isSampled: places.length < sourceState.manifest.itemCount,
          isViewportFiltered: true,
        });
      })
      .catch((error) => {
        if (controller.signal.aborted) return;
        console.warn('[maps] failed to load saved place list viewport', error);
      })
      .finally(() => {
        if (savedListViewportAbortController === controller) {
          savedListViewportAbortController = null;
        }
      });
  }

  function savedPlaceListCountText(list: SavedPlaceList): string {
    const total = list.itemCount ?? list.places.length;
    const loaded = list.loadedItemCount ?? list.places.length;
    const query = savedListSearchQuery.trim();
    if (query) {
      if (savedListSearchStatus === 'searching') return `searching ${total.toLocaleString()} places`;
      if (savedListSearchStatus === 'error') return `search failed · ${total.toLocaleString()} places`;
      return `${list.places.length.toLocaleString()} ${list.places.length === 1 ? 'match' : 'matches'} of ${total.toLocaleString()} places`;
    }
    if (list.isViewportFiltered) {
      return `showing ${loaded.toLocaleString()} in view of ${total.toLocaleString()} places`;
    }
    if (list.isSampled && total > loaded) {
      return `showing ${loaded.toLocaleString()} of ${total.toLocaleString()} places`;
    }
    return `${total.toLocaleString()} ${total === 1 ? 'place' : 'places'}`;
  }

  function syncSavedPlaceListRouteFromHash(hash: string) {
    const route = parseSavedPlaceListRouteFromHash(hash);
    if (!route) {
      if (savedListRouteAbortController) {
        savedListRouteAbortController.abort();
        savedListRouteAbortController = null;
      }
      savedListRouteKey = '';
      lastFocusedSavedListKey = '';
      abortSavedPlaceListViewportLoad();
      resetSavedPlaceListSearchState();
      routedSavedPlaceListSource = null;
      routedSavedPlaceList = null;
      savedListRouteStatus = 'idle';
      savedListRouteError = '';
      return;
    }

    const nextKey = savedPlaceListRouteKey(route);
    if (nextKey === savedListRouteKey && savedListRouteStatus !== 'error') return;
    savedListRouteAbortController?.abort();
    const controller = new AbortController();
    savedListRouteAbortController = controller;
    savedListRouteKey = nextKey;
    lastFocusedSavedListKey = '';
    abortSavedPlaceListViewportLoad();
    resetSavedPlaceListSearchState();
    routedSavedPlaceListSource = null;
    routedSavedPlaceList = null;
    savedListRouteStatus = 'loading';
    savedListRouteError = '';
    void loadRoutedSavedPlaceList(route, controller.signal)
      .then((result) => {
        if (controller.signal.aborted) return;
        routedSavedPlaceListSource = result.sourceState;
        routedSavedPlaceList = result.list;
        savedListRouteStatus = 'loaded';
        refreshRoutedSavedPlaceListForViewport();
      })
      .catch((error) => {
        if (controller.signal.aborted) return;
        console.warn('[maps] failed to load saved place list route', error);
        routedSavedPlaceListSource = null;
        routedSavedPlaceList = null;
        savedListRouteStatus = 'error';
        savedListRouteError = error instanceof Error ? error.message : 'Could not load list';
      });
  }

  async function createSavedListForActivePlace() {
    if (!activePlace || savedListStatus === 'saving') return;
    const name = newSavedListName.trim();
    if (!name) return;
    const visibility = newSavedListVisibility;
    newSavedListName = '';
    newSavedListVisibility = 'private';
    showNewSavedListForm = false;
    savedListStatus = 'saving';
    try {
      await mapsStore.createSavedPlaceList({
        name,
        visibility,
        icon: 'bookmark',
        place: activePlace,
      });
      savedListStatus = 'idle';
    } catch (error) {
      console.warn('[maps] failed to create saved place list', error);
      newSavedListName = name;
      newSavedListVisibility = visibility;
      showNewSavedListForm = true;
      savedListStatus = 'error';
    }
  }

  async function shareContextLocation() {
    if (!contextMenu) return;
    const { lat, lng } = contextMenu;
    closeContextMenu();
    const place = coordinatePlace(lat, lng);
    mapsStore.setActivePlace(place);
    setActivePlaceInHash(place);
    try {
      await copyText(window.location.href);
    } catch (error) {
      console.warn('[maps] failed to copy context location URL', error);
    }
  }

  function addMissingPlaceAtContextLocation() {
    if (!contextMenu) return;
    const { lat, lng } = contextMenu;
    closeContextMenu();
    mapsStore.setPendingPlaceLocation(lat, lng);
    mapsStore.openAddPlaceModal();
  }

  function startMeasureDistanceAtContextLocation() {
    if (!contextMenu) return;
    const point = { lat: contextMenu.lat, lng: contextMenu.lng };
    closeContextMenu();
    mapsStore.closeAddPlaceModal();
    mapsStore.setActivePlace(null);
    setActivePlaceInHash(null);
    measureDistancePoints = [point];
    isMeasureDistanceActive = true;
    syncMeasureDistanceOverlay();
  }

  function addMeasureDistancePoint(lat: number, lng: number) {
    measureDistancePoints = [...measureDistancePoints, { lat, lng }];
    syncMeasureDistanceOverlay();
  }

  function undoMeasureDistancePoint() {
    measureDistancePoints = measureDistancePoints.slice(0, -1);
    if (measureDistancePoints.length === 0) {
      isMeasureDistanceActive = false;
    }
    syncMeasureDistanceOverlay();
  }

  function clearMeasureDistance() {
    isMeasureDistanceActive = false;
    measureDistancePoints = [];
    setMapCursor('');
    syncMeasureDistanceOverlay();
  }

  async function saveActivePlaceReview() {
    if (!activePlace?.id || !canReviewActivePlace || reviewStatus === 'saving' || reviewRating === null || isReviewMediaUploading) return;
    reviewStatus = 'saving';
    const lang = navigator.language?.split('-')[0]?.toLowerCase() || undefined;
    const owner = $nostrStore.npub || 'anonymous';
    try {
      await mapsStore.addReview({
        placeId: activePlace.id,
        rating: reviewRating,
        ratingMax: 5,
        body: reviewBody.trim() || undefined,
        media: reviewMedia.length > 0 ? reviewMedia : undefined,
        lang,
        owner,
      });
      reviewBody = '';
      reviewMedia = [];
      reviewRating = null;
      reviewStatus = 'saved';
      isReviewModalOpen = false;
      window.setTimeout(() => {
        if (reviewStatus === 'saved') reviewStatus = 'idle';
      }, 1400);
    } catch (error) {
      console.warn('[maps] failed to save review', error);
      reviewStatus = 'error';
    }
  }

  async function handleReviewMediaFiles(event: Event) {
    const input = event.currentTarget as HTMLInputElement;
    const files = Array.from(input.files ?? []);
    input.value = '';
    if (files.length === 0) return;

    reviewStatus = 'idle';
    reviewMediaError = '';
    for (const file of files) {
      try {
        const uploaded = await uploadReviewMediaFile(file, (progress) => {
          reviewMediaUpload = progress;
        });
        if (!reviewMedia.some((item) => item.url === uploaded.url)) {
          reviewMedia = [...reviewMedia, uploaded];
        }
      } catch (error) {
        reviewMediaError = error instanceof Error ? error.message : 'Could not upload media';
      } finally {
        reviewMediaUpload = null;
      }
    }
  }

  function removeReviewMedia(url: string) {
    reviewMedia = reviewMedia.filter((item) => item.url !== url);
    reviewStatus = 'idle';
  }

  function openPhotoGallery(index = 0) {
    if (activePlacePhotos.length === 0) return;
    photoGalleryIndex = Math.max(0, Math.min(index, activePlacePhotos.length - 1));
    isPhotoGalleryOpen = true;
  }

  function closePhotoGallery() {
    isPhotoGalleryOpen = false;
  }

  function stepPhotoGallery(delta: number) {
    if (activePlacePhotos.length === 0) return;
    photoGalleryIndex = (photoGalleryIndex + delta + activePlacePhotos.length) % activePlacePhotos.length;
  }

  function closeActivePlace() {
    mapsStore.setActivePlace(null);
    setActivePlaceInHash(null);
  }

  function removeActivePin() {
    if (!activeStoredPlace) return;
    void mapsStore.deletePlace(activeStoredPlace.id);
    closeActivePlace();
  }

  function openReviewModal() {
    reviewStatus = 'idle';
    reviewMediaError = '';
    isReviewModalOpen = true;
  }

  function closeReviewModal() {
    if (isReviewMediaUploading || reviewStatus === 'saving') return;
    isReviewModalOpen = false;
    reviewRating = null;
    reviewBody = '';
    reviewMedia = [];
    reviewMediaError = '';
    reviewStatus = 'idle';
  }

  function createReviewSummary(reviews: PlaceReview[]) {
    const count = reviews.length;
    const counts = [0, 0, 0, 0, 0];
    let total = 0;
    for (const review of reviews) {
      const rating = Math.max(1, Math.min(5, Math.round(review.rating)));
      counts[rating - 1] += 1;
      total += review.rating;
    }
    return {
      average: count > 0 ? total / count : 0,
      count,
      counts,
    };
  }

  function fallbackPlaceZoom(place: ActivePlace): number {
    const type = place.type?.toLowerCase();
    const placeClass = place.class?.toLowerCase();
    if (type && largeAreaTypes.has(type)) {
      if (type === 'continent') return 2;
      if (type === 'country') {
        const rank = place.placeRank ?? 3;
        if (rank <= 1) return 2.5;
        if (rank <= 2) return 3;
        return 4;
      }
      if (type === 'state' || type === 'region' || type === 'province') return 5;
      return 7;
    }
    if (placeClass && largeAreaClasses.has(placeClass) && typeof place.placeRank === 'number' && place.placeRank <= 6) {
      if (place.placeRank <= 2) return 3;
      if (place.placeRank <= 4) return 4;
      return 5;
    }
    if (type === 'city') return 10;
    if (type === 'town') return 11;
    if (type === 'village') return 12;
    if (type === 'hamlet' || type === 'suburb' || type === 'neighbourhood' || type === 'quarter') return 13;
    if (type === 'airport' || placeClass === 'aeroway') return 13;
    if (type === 'ocean' || type === 'sea') return 4;
    if (type === 'lake' || type === 'reservoir') return 10;
    if (placeClass === 'water' || type === 'river' || type === 'strait' || type === 'canal') return 11;
    if (placeClass === 'highway' || place.sourceLayer === 'transportation_name') return 15;
    if (type === 'house' || type === 'building' || placeClass === 'building') return 17;
    return 14;
  }

  function focusActivePlace(place: ActivePlace) {
    if (!map) return;
    if (place.boundingBox) {
      const [south, north, west, east] = place.boundingBox;
      const bounds: LngLatBoundsLike = [[west, south], [east, north]];
      map.fitBounds(bounds, {
        maxZoom: Math.min(fallbackPlaceZoom(place), basemapConfig.maxZoom),
        padding: 32,
      });
    } else {
      map.easeTo({ center: [place.lng, place.lat], zoom: Math.min(fallbackPlaceZoom(place), basemapConfig.maxZoom) });
    }
  }

  function focusSavedPlaceList(list: SavedPlaceList) {
    if (!map || list.places.length === 0) return;
    if (list.places.length === 1) {
      const [place] = list.places;
      map.easeTo({ center: [place.lng, place.lat], zoom: Math.max(map.getZoom(), 13) });
      return;
    }
    const bounds = new maplibregl.LngLatBounds();
    for (const place of list.places) {
      bounds.extend([place.lng, place.lat]);
    }
    if (!bounds.isEmpty()) {
      map.fitBounds(bounds, {
        maxZoom: 13,
        padding: {
          top: 72,
          right: 72,
          bottom: 72,
          left: isLeftPanelMapObscuring ? 456 : 72,
        },
      });
    }
  }

  function focusSavedPlaceLists(lists: SavedPlaceList[]) {
    if (!map) return;
    const placesToFocus = lists.flatMap((list) => list.places);
    if (placesToFocus.length === 0) return;
    if (placesToFocus.length === 1) {
      const [place] = placesToFocus;
      map.easeTo({ center: [place.lng, place.lat], zoom: Math.max(map.getZoom(), 13) });
      return;
    }
    const bounds = new maplibregl.LngLatBounds();
    for (const place of placesToFocus) {
      bounds.extend([place.lng, place.lat]);
    }
    if (!bounds.isEmpty()) {
      map.fitBounds(bounds, {
        maxZoom: 13,
        padding: {
          top: 72,
          right: 72,
          bottom: 72,
          left: isLeftPanelMapObscuring ? 456 : 72,
        },
      });
    }
  }

  function syncActivePlaceFromHash(hash: string) {
    const nextPlace = parseActivePlaceFromHash(hash);
    if (!nextPlace) {
      if (mapsStore.activePlace) {
        mapsStore.setActivePlace(null);
      }
      return;
    }
    const current = mapsStore.activePlace;
    if (
      !current ||
      current.lat !== nextPlace.lat ||
      current.lng !== nextPlace.lng ||
      current.name !== nextPlace.name
    ) {
      mapsStore.setActivePlace(nextPlace);
    }
  }

  $effect(() => {
    if (!mapReady || !map) return;
    removePlaceMarkers();
    for (const place of places) {
      const element = createPlaceMarkerElement(place);
      const popup = new maplibregl.Popup({
        closeButton: false,
        closeOnClick: false,
        offset: 18,
        className: 'iris-map-place-hover-popup',
      })
        .setLngLat([place.lng, place.lat])
        .setHTML(hoverCardHtml({
          id: place.id,
          name: place.name,
          type: place.category,
          context: place.description,
          lat: place.lat,
          lng: place.lng,
        }));
      const showPopup = () => {
        showMarkerHoverPopup(popup, [place.lng, place.lat]);
      };
      const hidePopup = () => {
        hideMarkerHoverPopup(popup);
      };
      element.title = place.name;
      element.setAttribute('aria-label', `${place.name}, ${place.category}`);
      element.addEventListener('mouseenter', showPopup);
      element.addEventListener('mouseleave', hidePopup);
      element.addEventListener('focus', showPopup);
      element.addEventListener('blur', hidePopup);
      element.addEventListener('click', (event) => {
        event.stopPropagation();
        hidePopup();
        selectStoredPlace(place);
      });
      const marker = new maplibregl.Marker({
        element,
        anchor: 'bottom',
      })
        .setLngLat([place.lng, place.lat])
        .addTo(map);
      placeMarkers.push(marker);
    }
  });

  $effect(() => {
    if (!mapReady || !map) return;
    removeSavedPlaceMarkers();
    for (const [listIndex, list] of visibleSavedPlaceLists.entries()) {
      for (const item of list.places) {
        const element = createSavedPlaceMarkerElement(item, listIndex);
        const popup = new maplibregl.Popup({
          closeButton: false,
          closeOnClick: false,
          offset: 18,
          className: 'iris-map-place-hover-popup',
        })
          .setLngLat([item.lng, item.lat])
          .setHTML(hoverCardHtml({
            id: item.id,
            name: item.name,
            type: item.type ?? item.displayName,
            context: item.context,
            lat: item.lat,
            lng: item.lng,
          }));
        const showPopup = () => {
          showMarkerHoverPopup(popup, [item.lng, item.lat]);
        };
        const hidePopup = () => {
          hideMarkerHoverPopup(popup);
        };
        element.title = `${item.name} · ${list.name}`;
        element.setAttribute('aria-label', `${item.name}, ${list.name}`);
        element.addEventListener('mouseenter', showPopup);
        element.addEventListener('mouseleave', hidePopup);
        element.addEventListener('focus', showPopup);
        element.addEventListener('blur', hidePopup);
        element.addEventListener('click', (event) => {
          event.stopPropagation();
          hidePopup();
          selectSavedPlaceListItem(item);
        });
        const marker = new maplibregl.Marker({
          element,
          anchor: 'bottom',
        })
          .setLngLat([item.lng, item.lat])
          .addTo(map);
        savedPlaceMarkers.push(marker);
        savedPlaceMarkerElements.set(`${item.key}\0${list.id}`, element);
      }
    }
    applySavedPlaceMarkerHoverState();
  });

  $effect(() => {
    applySavedPlaceMarkerHoverState(hoveredSavedPlaceListItemKey);
  });

  $effect(() => {
    if (!mapReady || !map) return;
    if (activePlaceMarker) {
      removeActiveHoverPopup();
      activePlaceMarker.remove();
      activePlaceMarker = null;
    }
    if (!activePlace || !shouldShowActivePlaceMarker(activePlace)) return;
    const element = createActiveMarkerElement();
    const popup = new maplibregl.Popup({
      closeButton: false,
      closeOnClick: false,
      offset: 18,
      className: 'iris-map-place-hover-popup',
    })
      .setLngLat([activePlace.lng, activePlace.lat])
      .setHTML(hoverCardHtml({
        id: activePlace.id,
        name: activePlace.name,
        type: activePlace.type ?? activePlace.displayName,
        context: activePlace.context,
        lat: activePlace.lat,
        lng: activePlace.lng,
      }));
  const showPopup = () => {
    showMarkerHoverPopup(popup, [activePlace.lng, activePlace.lat]);
  };
  const hidePopup = () => {
    hideMarkerHoverPopup(popup);
  };
  element.title = activePlace.name;
  element.setAttribute('aria-label', activePlace.name);
  element.addEventListener('mouseenter', showPopup);
  element.addEventListener('mouseleave', hidePopup);
  element.addEventListener('focus', showPopup);
  element.addEventListener('blur', hidePopup);
    activePlaceMarker = new maplibregl.Marker({
      element,
      anchor: 'bottom',
    })
      .setLngLat([activePlace.lng, activePlace.lat])
      .addTo(map);
  });

  $effect(() => {
    if (!mapReady || !map || !activePlace) {
      lastFocusedKey = '';
      return;
    }
    const nextKey = [
      activePlace.name,
      activePlace.lat,
      activePlace.lng,
      activePlace.type,
      activePlace.class,
      activePlace.placeRank,
      activePlace.boundingBox?.join(','),
    ].join('-');
    if (nextKey === lastFocusedKey) return;
    lastFocusedKey = nextKey;
    focusActivePlace(activePlace);
  });

  $effect(() => {
    if (!mapReady || !map || !routedSavedPlaceList) {
      if (!routedSavedPlaceList) lastFocusedSavedListKey = '';
      return;
    }
    if (routedSavedPlaceList.isSampled || routedSavedPlaceList.isViewportFiltered) return;
    const key = `${routedSavedPlaceList.id}:${routedSavedPlaceList.updatedAt}`;
    if (key === lastFocusedSavedListKey) return;
    lastFocusedSavedListKey = key;
    focusSavedPlaceList(routedSavedPlaceList);
  });

  $effect(() => {
    if (!mapReady || !map || libraryOverlayLists.length === 0 || showingSavedListPanel) {
      if (libraryOverlayLists.length === 0) lastFocusedLibraryListKey = '';
      return;
    }
    const key = libraryOverlayLists
      .map((list) => `${list.id}:${list.updatedAt}:${list.places.length}`)
      .join('|');
    if (key === lastFocusedLibraryListKey) return;
    lastFocusedLibraryListKey = key;
    focusSavedPlaceLists(libraryOverlayLists);
  });

  $effect(() => {
    const validOverlayListIds = libraryOverlayListIds.filter((id) => savedPlaceLists.some((list) => list.id === id));
    if (validOverlayListIds.length !== libraryOverlayListIds.length) {
      libraryOverlayListIds = validOverlayListIds;
      lastFocusedLibraryListKey = '';
    }
    if (librarySelectedListId && !savedPlaceLists.some((list) => list.id === librarySelectedListId)) {
      librarySelectedListId = savedPlaceLists[0]?.id ?? null;
    }
    if (!librarySelectedListId && savedPlaceLists.length > 0 && isLibraryPanelOpen) {
      librarySelectedListId = savedPlaceLists[0].id;
    }
  });

  $effect(() => {
    const store = followsStore;
    if (!store) {
      followsPubkeys = [];
      return;
    }
    const unsubscribe = store.subscribe((value) => {
      followsPubkeys = value?.follows ?? [];
    });
    return () => {
      unsubscribe();
      store.destroy();
    };
  });

  $effect(() => {
    if (!isLibraryPanelOpen || libraryTab !== 'discover' || !$settingsStore.networkLoaded) return;
    if (followsPubkeys.length === 0 && defaultDiscoverFollowStatus === 'idle') {
      requestDefaultDiscoverFollows();
    }
  });

  $effect(() => {
    if (!isLibraryPanelOpen || libraryTab !== 'discover') {
      followingDiscoverActiveAuthorsKey = '';
      return;
    }
    const authors = discoverFollowingAuthorPubkeys;
    const authorsKey = discoverAuthorsKey(authors);
    if (authors.length === 0) {
      followingDiscoverActiveAuthorsKey = '';
      followingDiscoverRequestId += 1;
      followingDiscoveredListError = '';
      if (followsPubkeys.length === 0 && defaultDiscoverFollowStatus === 'loading') {
        followingDiscoveredListStatus = 'loading';
        return;
      }
      if (followsPubkeys.length === 0 && defaultDiscoverFollowStatus === 'error') {
        followingDiscoveredListStatus = 'error';
        followingDiscoveredListError = 'Could not load default follows.';
        return;
      }
      followingDiscoveredListStatus = 'idle';
      return;
    }

    if (authorsKey === followingDiscoverActiveAuthorsKey) return;
    followingDiscoverActiveAuthorsKey = authorsKey;
    followingDiscoverRequestId += 1;
    const requestId = followingDiscoverRequestId;
    followingDiscoveredListError = '';
    followingDiscoveredSavedPlaceLists = [];
    followingDiscoveredListStatus = 'loading';
    const stop = startDiscoveredSavedPlaceListSubscription({
      authors,
      isCurrent: () => requestId === followingDiscoverRequestId,
      getStatus: () => followingDiscoveredListStatus,
      setStatus: (status) => {
        followingDiscoveredListStatus = status;
      },
      setError: (message) => {
        followingDiscoveredListError = message;
      },
      upsert: upsertFollowingDiscoveredSavedPlaceList,
    });
    return () => {
      if (followingDiscoverActiveAuthorsKey === authorsKey) {
        followingDiscoverActiveAuthorsKey = '';
      }
      stop();
    };
  });

  $effect(() => {
    if (!isLibraryPanelOpen || libraryTab !== 'discover') {
      otherDiscoverActiveAuthorsKey = '';
      return;
    }
    const authors = normalizedDiscoverAuthors(discoverOtherAuthorPubkeys).slice(0, 20);
    const authorsKey = discoverAuthorsKey(authors);
    if (authors.length === 0) {
      otherDiscoverActiveAuthorsKey = '';
      otherDiscoverRequestId += 1;
      otherDiscoveredListError = '';
      otherDiscoveredListStatus = 'idle';
      return;
    }

    if (authorsKey === otherDiscoverActiveAuthorsKey) return;
    otherDiscoverActiveAuthorsKey = authorsKey;
    otherDiscoverRequestId += 1;
    const requestId = otherDiscoverRequestId;
    otherDiscoveredListError = '';
    otherDiscoveredSavedPlaceLists = [];
    otherDiscoveredListStatus = 'loading';
    const stop = startDiscoveredSavedPlaceListSubscription({
      authors,
      isCurrent: () => requestId === otherDiscoverRequestId,
      getStatus: () => otherDiscoveredListStatus,
      setStatus: (status) => {
        otherDiscoveredListStatus = status;
      },
      setError: (message) => {
        otherDiscoveredListError = message;
      },
      upsert: upsertOtherDiscoveredSavedPlaceList,
    });
    return () => {
      if (otherDiscoverActiveAuthorsKey === authorsKey) {
        otherDiscoverActiveAuthorsKey = '';
      }
      stop();
    };
  });

  $effect(() => {
    const key = activePlace ? mapsStore.savedPlaceKey(activePlace) : '';
    if (key !== lastActivePlaceTabKey) {
      activePlaceTab = 'overview';
      lastActivePlaceTabKey = key;
      closePhotoGallery();
      isSaveListsPanelOpen = false;
      showNewSavedListForm = false;
      savedListStatus = 'idle';
    }
    if (activePlaceTab === 'reviews' && !activePlaceCanHaveReviews) {
      activePlaceTab = 'overview';
    }
  });

  $effect(() => {
    if (!showingLeftPanel || !isCompactViewport) {
      isLeftPanelMinimized = false;
    }
  });

  $effect(() => {
    if (photoGalleryIndex >= activePlacePhotos.length) {
      photoGalleryIndex = Math.max(0, activePlacePhotos.length - 1);
    }
    if (activePlacePhotos.length === 0) {
      isPhotoGalleryOpen = false;
    }
  });

  $effect(() => {
    if (!mapReady || !map) return;
    applyBasemapStylePreference(mapStylePreference);
  });

  $effect(() => {
    if (!mapReady || !map) return;
    measureDistancePoints;
    isMeasureDistanceActive;
    syncMeasureDistanceOverlay();
  });

  onMount(() => {
    let cancelled = false;
    mapsStore.init();
    const compactViewportQuery = window.matchMedia('(max-width: 767px)');
    const syncCompactViewport = () => {
      isCompactViewport = compactViewportQuery.matches;
    };
    syncCompactViewport();
    compactViewportQuery.addEventListener('change', syncCompactViewport);
    syncActivePlaceFromHash(window.location.hash);
    syncSavedPlaceListRouteFromHash(window.location.hash);
    const unsubscribeHash = currentHash.subscribe((hash) => {
      syncActivePlaceFromHash(hash);
      syncSavedPlaceListRouteFromHash(hash);
    });

    async function initMap() {
      if (!mapContainer) return;
      await waitForSettingsLoaded();
      if (cancelled) return;
      const savedView = mapsStore.mapView;
      const initialStylePreference = settingsStore.getState().map.style;
      const style = await loadBasemapStyle(initialStylePreference);
      if (cancelled) return;
      activeBasemapStylePreference = initialStylePreference;

      map = new maplibregl.Map({
        container: mapContainer,
        style,
        center: [savedView.center[1], savedView.center[0]],
        zoom: savedView.zoom,
        minZoom: basemapConfig.minZoom,
        maxZoom: basemapConfig.maxZoom,
        attributionControl: false,
        keyboard: false,
      });
      if (import.meta.env.DEV) {
        (window as Window & typeof globalThis & { __irisMap?: MapLibreMap }).__irisMap = map;
      }
      clearMapDetailSearchProvider?.();
      clearMapDetailSearchProvider = setMapDetailSearchProvider(searchLoadedMapDetailFeatures);

      const resizeMap = () => {
        if (!cancelled) {
          map?.resize();
        }
      };
      requestAnimationFrame(resizeMap);
      window.setTimeout(resizeMap, 100);

      map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right');
      map.addControl(createLocateControl(), 'bottom-right');
      map.addControl(new maplibregl.AttributionControl({
        compact: true,
        customAttribution: '<a href="https://docs.overturemaps.org/attribution/">Overture Maps</a>',
      }), 'bottom-right');
      markNavigationControl();
      requestAnimationFrame(markNavigationControl);
      window.setTimeout(markNavigationControl, 100);
      requestAnimationFrame(collapseAttributionControl);
      window.setTimeout(collapseAttributionControl, 100);
      map.on('styleimagemissing', handleMissingStyleImage);

      map.on('load', () => {
        if (cancelled) return;
        resizeMap();
        collapseAttributionControl();
        mapReady = true;
        syncMeasureDistanceOverlay();
        refreshRoutedSavedPlaceListForViewport();
      });

      map.on('mousemove', handleMapMouseMove);
      map.on('mouseout', handleMapMouseOut);
      map.on('click', handleMapClick);
      map.on('contextmenu', handleMapContextMenu);
      map.on('styledata', syncMeasureDistanceOverlay);

      map.on('moveend', () => {
        if (!map) return;
        const center = map.getCenter();
        const bounds = map.getBounds();
        mapsStore.setMapView(
          [center.lat, center.lng],
          map.getZoom(),
          [bounds.getSouth(), bounds.getNorth(), bounds.getWest(), bounds.getEast()]
        );
        refreshRoutedSavedPlaceListForViewport();
      });

      map.on('error', (event) => {
        console.warn('[maps] maplibre error', event.error);
      });
    }

    void initMap().catch((error) => {
      console.error('[maps] failed to initialize basemap', error);
      mapError = 'Failed to load map data';
    });

    return () => {
      cancelled = true;
      compactViewportQuery.removeEventListener('change', syncCompactViewport);
      unsubscribeHash();
      clearMapDetailSearchProvider?.();
      clearMapDetailSearchProvider = null;
      mapsStore.destroy();
      removePlaceMarkers();
      removeSavedPlaceMarkers();
      if (activePlaceMarker) {
        activePlaceMarker.remove();
        activePlaceMarker = null;
      }
      if (savedListRouteAbortController) {
        savedListRouteAbortController.abort();
        savedListRouteAbortController = null;
      }
      abortSavedPlaceListViewportLoad();
      routedSavedPlaceListSource = null;
      if (map) {
        map.off('mousemove', handleMapMouseMove);
        map.off('mouseout', handleMapMouseOut);
        map.off('click', handleMapClick);
        map.off('contextmenu', handleMapContextMenu);
        map.off('styledata', syncMeasureDistanceOverlay);
        map.remove();
        map = null;
      }
      if (activePlaceShareTimer) {
        clearTimeout(activePlaceShareTimer);
        activePlaceShareTimer = null;
      }
      if (savedListCopyTimer) {
        clearTimeout(savedListCopyTimer);
        savedListCopyTimer = null;
      }
      if (contextMenuCopyTimer) {
        clearTimeout(contextMenuCopyTimer);
        contextMenuCopyTimer = null;
      }
      if (import.meta.env.DEV) {
        delete (window as Window & typeof globalThis & { __irisMap?: MapLibreMap }).__irisMap;
      }
      mapReady = false;
    };
  });
</script>

<svelte:window onpointerdown={handleWindowPointerDown} onkeydown={handleWindowKeydown} />

<div class="iris-map-theme-{mapChromeTheme} flex-1 relative overflow-hidden">
  <div class="absolute inset-0 bg-surface-0">
    <!-- svelte-ignore a11y_no_noninteractive_tabindex, a11y_no_noninteractive_element_interactions -->
    <div
      bind:this={mapContainer}
      class="h-full w-full"
      data-testid="map-surface"
      role="application"
      aria-busy={!mapReady}
      aria-label="Map. Use arrow keys to move, plus and minus to zoom."
      tabindex="0"
      onkeydown={handleMapKeydown}
    ></div>
  </div>
  {#if mapError}
    <div class="absolute inset-0 z-[500] grid place-items-center bg-surface-0 text-text-2">
      <p class="text-sm">{mapError}</p>
    </div>
  {/if}

  <div class="pointer-events-none absolute z-[10000] flex {showingLeftPanel ? 'bottom-0 left-0 top-0 w-[408px] max-w-[calc(100vw-4rem)] flex-col gap-0' : 'left-3 right-20 top-4 max-h-[calc(100vh-1.5rem)] flex-col gap-3 sm:left-4 sm:right-auto sm:w-[408px]'}">
    <div class="pointer-events-auto {showingLeftPanel ? 'absolute left-4 right-4 top-4 z-[1]' : ''} {isLeftPanelVisuallyMinimized ? 'hidden' : ''}">
      <MapSearch
        onSelect={goToSearchResult}
        activePlaceName={showingSavedListPanel && !showingSavedListPlaceDetail ? '' : activePlace?.name ?? ''}
        onClosePlace={closeActivePlace}
        onBack={showingLibraryPanel ? closeLibraryPanel : showingSavedListPlaceDetail ? closeActivePlace : showingSavedListPanel ? closeRoutedSavedPlaceList : undefined}
        onOpenLibrary={showingLeftPanel ? undefined : toggleLibraryPanel}
        libraryOpen={isLibraryPanelOpen}
        onQueryChange={showingSavedListPanel && !showingSavedListPlaceDetail ? handleSavedPlaceListSearchQuery : undefined}
        searchMode={showingSavedListPanel && !showingSavedListPlaceDetail ? 'list' : 'map'}
        placeholder={showingSavedListPanel && !showingSavedListPlaceDetail ? 'Search this list' : 'Search'}
        theme={mapChromeTheme}
      />
    </div>
    {#if showingLeftPanel && !isLeftPanelVisuallyMinimized}
      <button
        type="button"
        class="pointer-events-auto absolute right-3 top-[4.75rem] z-[2] grid h-9 w-9 place-items-center rounded-full bg-surface-1/96 text-text-2 shadow-lg ring-1 ring-surface-3/80 backdrop-blur-md hover:bg-surface-2 hover:text-text-1 md:hidden"
        title="Minimize panel"
        aria-label="Minimize panel"
        data-testid="left-panel-minimize"
        onclick={() => isLeftPanelMinimized = true}
      >
        <span class="i-lucide-panel-left-close text-lg"></span>
      </button>
    {/if}

    {#if showingLibraryPanel && !mapsStore.isAddPlaceModalOpen}
      <aside class="pointer-events-auto h-full w-full overflow-y-auto bg-surface-1/96 pt-20 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md {isLeftPanelVisuallyMinimized ? 'hidden' : ''}" data-testid="maps-library-panel">
        <div class="border-b border-surface-3/70 px-6 pb-4 pt-5">
          <div class="mb-4 flex items-center gap-3">
            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent/14 text-accent">
              <span class="i-lucide-library text-xl"></span>
            </span>
            <div class="min-w-0 flex-1">
              <h2 class="truncate text-xl font-medium text-text-1">Library</h2>
              <p class="mt-0.5 text-sm text-text-2">{libraryListCount} lists · {libraryPublicListCount} public</p>
            </div>
          </div>
          <div class="grid grid-cols-2 gap-1 rounded-md bg-surface-2 p-1">
            <button
              type="button"
              class="h-9 rounded text-sm font-medium {libraryTab === 'mine' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
              aria-pressed={libraryTab === 'mine'}
              onclick={() => selectLibraryTab('mine')}
            >
              My lists
            </button>
            <button
              type="button"
              class="h-9 rounded text-sm font-medium {libraryTab === 'discover' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
              aria-pressed={libraryTab === 'discover'}
              onclick={() => selectLibraryTab('discover')}
            >
              Discover
            </button>
          </div>
        </div>

        {#if libraryTab === 'mine'}
          <div class="py-2" data-testid="library-list-index">
            {#each savedPlaceLists as list (list.id)}
              <div class="flex items-center gap-1 px-3 {librarySelectedList?.id === list.id ? 'bg-surface-2/55' : 'hover:bg-surface-2/45'}">
                <button
                  type="button"
                  class="flex min-w-0 flex-1 items-center gap-3 px-3 py-3 text-left"
                  aria-current={librarySelectedList?.id === list.id ? 'true' : undefined}
                  data-testid={`library-list-${savedListSlug(list.name)}`}
                  onclick={() => openOwnSavedPlaceList(list)}
                >
                  <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent/14 text-accent">
                    <span class="{savedListIconClass(list.icon)} text-lg"></span>
                  </span>
                  <span class="min-w-0 flex-1">
                    <span class="block truncate text-sm font-medium text-text-1">{list.name}</span>
                    <span class="mt-0.5 block truncate text-xs text-text-3">{savedPlaceListMetaText(list)}</span>
                  </span>
                </button>
                <label
                  class="grid h-9 w-9 shrink-0 place-items-center rounded-full {isLibraryListOverlaid(list) ? 'text-accent' : 'text-text-2 hover:bg-surface-3/70'} {list.places.length === 0 ? 'cursor-not-allowed opacity-40' : ''}"
                  title={isLibraryListOverlaid(list) ? 'Hide from map' : 'Show on map'}
                >
                  <input
                    type="checkbox"
                    class="sr-only"
                    checked={isLibraryListOverlaid(list)}
                    disabled={list.places.length === 0}
                    aria-label={isLibraryListOverlaid(list) ? `Hide ${list.name} from map` : `Show ${list.name} on map`}
                    onchange={() => toggleLibraryOverlayList(list)}
                  />
                  <span class="grid h-5 w-5 place-items-center rounded border border-surface-3 bg-surface-0 text-transparent {isLibraryListOverlaid(list) ? 'border-accent bg-accent text-white' : ''}" aria-hidden="true">
                    <span class="i-lucide-check text-sm"></span>
                  </span>
                </label>
                {#if list.visibility === 'public'}
                  <button
                    type="button"
                    class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-3/70 hover:text-text-1 disabled:cursor-wait disabled:opacity-45"
                    title={publicListUrlTitle(list)}
                    aria-label={copiedSavedListId === list.id ? `Copied ${list.name} public URL` : `Copy ${list.name} public URL`}
                    disabled={!list.urls?.web}
                    onclick={() => copySavedListUrl(list)}
                  >
                    <span class="{copiedSavedListId === list.id ? 'i-lucide-check' : 'i-lucide-link'} text-base"></span>
                  </button>
                {/if}
              </div>
            {/each}
            {#if savedExternalPlaceLists.length}
              <div class="mt-2 border-t border-surface-3/60 pt-2" data-testid="library-saved-external-lists">
                <p class="px-6 pb-1 pt-2 text-xs font-semibold uppercase tracking-wide text-text-3">Saved public lists</p>
                {#each savedExternalPlaceLists as list (savedExternalPlaceListKey(list))}
                  <div class="flex items-center gap-1 px-3 hover:bg-surface-2/45">
                    <button
                      type="button"
                      class="flex min-w-0 flex-1 items-center gap-3 px-3 py-3 text-left"
                      data-testid={`library-saved-external-list-${savedListSlug(list.name)}`}
                      onclick={() => openSavedExternalPlaceList(list)}
                    >
                      <span class="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full bg-accent/14 text-accent">
                        {#if list.avatarUrl}
                          <img src={list.avatarUrl} alt="" class="h-full w-full object-contain bg-white p-1" loading="lazy" />
                        {:else}
                          <span class="{savedListIconClass(list.icon)} text-lg"></span>
                        {/if}
                      </span>
                      <span class="min-w-0 flex-1">
                        <span class="block truncate text-sm font-medium text-text-1">{list.name}</span>
                        <span class="mt-0.5 block truncate text-xs text-text-3">{savedExternalPlaceListMetaText(list)}</span>
                      </span>
                      <span class="i-lucide-chevron-right shrink-0 text-base text-text-3"></span>
                    </button>
                    <button
                      type="button"
                      class="grid h-9 w-9 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-3/70 hover:text-text-1"
                      title="Remove saved list"
                      aria-label={`Remove ${list.name} from My lists`}
                      data-testid={`library-remove-saved-external-list-${savedListSlug(list.name)}`}
                      onclick={() => removeSavedExternalPlaceListFromLibrary(list)}
                    >
                      <span class="i-lucide-bookmark-x text-base"></span>
                    </button>
                  </div>
                {/each}
              </div>
            {/if}
          </div>

          <div class="border-t border-surface-3/70 px-5 py-4">
            {#if showNewSavedListForm}
              <form
                class="space-y-3"
                data-testid="library-new-list-form"
                onsubmit={(event) => {
                  event.preventDefault();
                  void createSavedListFromLibrary();
                }}
              >
                <input
                  class="h-10 w-full rounded-md border border-surface-3 bg-surface-0/70 px-3 text-sm text-text-1 outline-none placeholder:text-text-3 focus:border-accent"
                  bind:value={newSavedListName}
                  placeholder="List name"
                  aria-label="List name"
                />
                <div class="grid grid-cols-2 gap-1 rounded-md bg-surface-2 p-1">
                  <button
                    type="button"
                    class="h-8 rounded text-sm font-medium {newSavedListVisibility === 'private' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
                    aria-pressed={newSavedListVisibility === 'private'}
                    onclick={() => newSavedListVisibility = 'private'}
                  >
                    Private
                  </button>
                  <button
                    type="button"
                    class="h-8 rounded text-sm font-medium {newSavedListVisibility === 'public' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
                    aria-pressed={newSavedListVisibility === 'public'}
                    onclick={() => newSavedListVisibility = 'public'}
                  >
                    Public
                  </button>
                </div>
                <div class="flex items-center justify-end gap-2">
                  <span class="mr-auto text-xs {savedListStatus === 'error' ? 'text-red-400' : 'text-text-3'}">
                    {savedListStatus === 'error' ? 'Could not save' : ''}
                  </span>
                  <button
                    type="button"
                    class="h-9 rounded-md px-3 text-sm font-medium text-text-2 hover:bg-surface-2 hover:text-text-1"
                    onclick={() => {
                      showNewSavedListForm = false;
                      newSavedListName = '';
                      newSavedListVisibility = 'private';
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    class="inline-flex h-9 items-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45"
                    disabled={!newSavedListName.trim() || savedListStatus === 'saving'}
                  >
                    {#if savedListStatus === 'saving'}
                      <span class="i-lucide-loader-circle animate-spin text-sm"></span>
                    {:else}
                      <span class="i-lucide-plus text-base"></span>
                    {/if}
                    <span>Create</span>
                  </button>
                </div>
              </form>
            {:else}
              <button
                type="button"
                class="flex h-10 w-full items-center justify-center gap-2 rounded-full bg-accent/18 text-sm font-medium text-accent hover:bg-accent/25"
                data-testid="library-new-list"
                onclick={() => {
                  showNewSavedListForm = true;
                  savedListStatus = 'idle';
                }}
              >
                <span class="i-lucide-plus text-base"></span>
                <span>New list</span>
              </button>
            {/if}
          </div>
        {:else}
          <div class="py-3" data-testid="library-discover-panel">
            <section data-testid="library-discover-following">
              <button
                type="button"
                class="mb-1 flex h-9 w-full items-center gap-2 px-6 text-left hover:bg-surface-2/60"
                aria-expanded={isFollowingDiscoverOpen}
                onclick={() => isFollowingDiscoverOpen = !isFollowingDiscoverOpen}
              >
                <span class="{isFollowingDiscoverOpen ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'} text-base text-text-3"></span>
                <h3 class="min-w-0 flex-1 truncate text-sm font-semibold text-text-1">Following</h3>
                {#if followingDiscoveredSavedPlaceLists.length}
                  <span class="text-xs text-text-3">{followingDiscoveredSavedPlaceLists.length}</span>
                {:else if followingDiscoveredListStatus === 'loading'}
                  <span class="i-lucide-loader-circle animate-spin text-base text-text-3" aria-label="Loading"></span>
                {:else if followingDiscoveredListStatus === 'error'}
                  <span class="text-xs text-red-400">Could not load</span>
                {/if}
              </button>
              {#if isFollowingDiscoverOpen}
                {#if followingDiscoveredSavedPlaceLists.length}
                  {#each followingDiscoveredSavedPlaceLists as list (list.id)}
                    <button
                      type="button"
                      class="flex w-full items-center gap-3 px-6 py-3 text-left hover:bg-surface-2/70"
                      data-testid={`discovered-list-${savedListSlug(list.name)}`}
                      onclick={() => openDiscoveredSavedPlaceList(list)}
                    >
                      <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent/14 text-accent">
                        <span class="i-lucide-globe-2 text-lg"></span>
                      </span>
                      <span class="min-w-0 flex-1">
                        <span class="block truncate text-sm font-medium text-text-1">{list.name}</span>
                        <span class="mt-0.5 block truncate text-xs text-text-3">{discoveredSavedPlaceListMetaText(list)}</span>
                      </span>
                      <span class="i-lucide-chevron-right shrink-0 text-base text-text-3"></span>
                    </button>
                  {/each}
                {:else if followingDiscoveredListStatus === 'loading'}
                  <p class="px-6 py-4 text-sm text-text-3">Listening for public lists.</p>
                {:else if followingDiscoveredListStatus === 'error'}
                  <p class="px-6 py-4 text-sm text-red-400">{followingDiscoveredListError || 'Could not load public lists.'}</p>
                {:else}
                  <p class="px-6 py-4 text-sm text-text-3">No public lists from follows.</p>
                {/if}
              {/if}
            </section>

            <section class="mt-2 border-t border-surface-3/60 pt-2" data-testid="library-discover-others">
              <button
                type="button"
                class="mb-1 flex h-9 w-full items-center gap-2 px-6 text-left hover:bg-surface-2/60"
                aria-expanded={isOtherDiscoverOpen}
                onclick={() => isOtherDiscoverOpen = !isOtherDiscoverOpen}
              >
                <span class="{isOtherDiscoverOpen ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'} text-base text-text-3"></span>
                <h3 class="min-w-0 flex-1 truncate text-sm font-semibold text-text-1">Others</h3>
                {#if visibleOtherDiscoveredSavedPlaceLists.length}
                  <span class="text-xs text-text-3">{visibleOtherDiscoveredSavedPlaceLists.length}</span>
                {:else if otherDiscoveredListStatus === 'loading'}
                  <span class="i-lucide-loader-circle animate-spin text-base text-text-3" aria-label="Loading"></span>
                {:else if otherDiscoveredListStatus === 'error'}
                  <span class="text-xs text-red-400">Limited</span>
                {/if}
              </button>
              {#if isOtherDiscoverOpen}
                {#if visibleOtherDiscoveredSavedPlaceLists.length}
                  {#each visibleOtherDiscoveredSavedPlaceLists as list (list.id)}
                    <button
                      type="button"
                      class="flex w-full items-center gap-3 px-6 py-3 text-left hover:bg-surface-2/70"
                      data-testid={`discovered-list-${savedListSlug(list.name)}`}
                      onclick={() => openDiscoveredSavedPlaceList(list)}
                    >
                      <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-amber-500/16 text-amber-600">
                        <span class="{list.id === btcMapSavedPlaceListId ? 'i-lucide-bitcoin' : 'i-lucide-globe-2'} text-lg"></span>
                      </span>
                      <span class="min-w-0 flex-1">
                        <span class="block truncate text-sm font-medium text-text-1">{list.name}</span>
                        <span class="mt-0.5 block truncate text-xs text-text-3">{discoveredSavedPlaceListMetaText(list)}</span>
                      </span>
                      <span class="i-lucide-chevron-right shrink-0 text-base text-text-3"></span>
                    </button>
                  {/each}
                {:else if otherDiscoveredListStatus === 'loading'}
                  <p class="px-6 py-4 text-sm text-text-3">Listening for public lists.</p>
                {:else if otherDiscoveredListStatus === 'error'}
                  <p class="px-6 py-4 text-sm text-red-400">{otherDiscoveredListError || 'Could not load other public lists.'}</p>
                {:else}
                  <p class="px-6 py-4 text-sm text-text-3">No other public lists loaded.</p>
                {/if}
              {/if}
            </section>
          </div>
        {/if}
      </aside>
    {:else if showingSavedListPanel && !showingSavedListPlaceDetail && !mapsStore.isAddPlaceModalOpen}
      <aside class="pointer-events-auto h-full w-full overflow-y-auto bg-surface-1/96 pt-20 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md {isLeftPanelVisuallyMinimized ? 'hidden' : ''}" data-testid="saved-place-list-route-panel">
        {#if savedListRouteStatus === 'loading'}
          <div class="px-6 py-5">
            <div class="mb-4 h-7 w-40 rounded bg-surface-2"></div>
            <div class="h-4 w-28 rounded bg-surface-2"></div>
          </div>
          <div class="border-t border-surface-3/70 px-5 py-4 text-sm text-text-2">
            <span class="inline-flex items-center gap-2">
              <span class="i-lucide-loader-circle animate-spin text-base"></span>
              Loading list
            </span>
          </div>
        {:else if savedListRouteStatus === 'error'}
          <div class="px-6 py-5">
            <h2 class="text-xl font-medium text-text-1">Saved list</h2>
            <p class="mt-2 text-sm text-red-400">{savedListRouteError || 'Could not load list'}</p>
          </div>
        {:else if routedSavedPlaceList}
          <div class="border-b border-surface-3/70 px-6 pb-4 pt-5">
            <div class="mb-3 flex items-start gap-3">
              {#if routedSavedPlaceList.avatarUrl}
                <span class="mt-1 grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full bg-white p-1 shadow-sm ring-1 ring-surface-3/80">
                  <img src={routedSavedPlaceList.avatarUrl} alt="" class="h-full w-full object-contain" loading="lazy" />
                </span>
              {:else}
                <span class="mt-1 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent/14 text-accent">
                  <span class="{savedListIconClass(routedSavedPlaceList.icon)} text-xl"></span>
                </span>
              {/if}
              <div class="min-w-0 flex-1">
                <h2 class="truncate text-xl font-medium text-text-1">{routedSavedPlaceList.name}</h2>
                <p class="mt-1 text-sm text-text-2">
                  {routedSavedPlaceList.visibility === 'public' ? 'Public' : 'Private'} · {savedPlaceListCountText(routedSavedPlaceList)}
                </p>
                {#if routedSavedPlaceList.description}
                  <p class="mt-2 text-sm leading-snug text-text-2">{routedSavedPlaceList.description}</p>
                {/if}
              </div>
            </div>
            <div class="flex flex-wrap gap-2">
              {#if currentRoutedExternalPlaceList}
                <button
                  type="button"
                  class="inline-flex h-9 items-center gap-2 rounded-full bg-accent/18 px-4 text-sm font-medium text-accent hover:bg-accent/25"
                  aria-pressed={isCurrentRoutedExternalPlaceListSaved}
                  data-testid="saved-external-list-toggle"
                  onclick={toggleCurrentRoutedExternalPlaceList}
                >
                  <span class="{isCurrentRoutedExternalPlaceListSaved ? 'i-lucide-bookmark-check' : 'i-lucide-bookmark-plus'} text-base"></span>
                  <span>{isCurrentRoutedExternalPlaceListSaved ? 'Saved' : 'Save list'}</span>
                </button>
              {/if}
              <button
                type="button"
                class="inline-flex h-9 items-center gap-2 rounded-full bg-accent/18 px-4 text-sm font-medium text-accent hover:bg-accent/25 disabled:cursor-not-allowed disabled:opacity-45"
                disabled={!routedSavedPlaceList.urls?.web}
                onclick={() => {
                  if (routedSavedPlaceList) void copySavedListUrl(routedSavedPlaceList);
                }}
              >
                <span class="{copiedSavedListId === routedSavedPlaceList.id ? 'i-lucide-check' : 'i-lucide-share-2'} text-base"></span>
                <span>{copiedSavedListId === routedSavedPlaceList.id ? 'Copied' : 'Share'}</span>
              </button>
              <button
                type="button"
                class="inline-flex h-9 items-center gap-2 rounded-full bg-accent/18 px-4 text-sm font-medium text-accent hover:bg-accent/25"
                onclick={() => mapsStore.openAddPlaceModal()}
              >
                <span class="i-lucide-plus text-base"></span>
                <span>Add a place</span>
              </button>
            </div>
          </div>

          <div class="py-3">
            {#if routedSavedPlaceList.places.length}
              {#each routedSavedPlaceList.places as item (item.key)}
                {@const context = visiblePlaceContext(item.context)}
                <button
                  type="button"
                  class="flex w-full items-center gap-3 px-6 py-3 text-left hover:bg-surface-2/70 {activePlace && mapsStore.savedPlaceKey(activePlace) === item.key ? 'bg-surface-2/70' : ''}"
                  aria-current={activePlace && mapsStore.savedPlaceKey(activePlace) === item.key ? 'true' : undefined}
                  onmouseenter={() => hoverSavedPlaceListItem(item)}
                  onmouseleave={() => clearHoveredSavedPlaceListItem(item)}
                  onfocus={() => hoverSavedPlaceListItem(item)}
                  onblur={() => clearHoveredSavedPlaceListItem(item)}
                  onclick={() => selectSavedPlaceListItem(item)}
                >
                  <span class="relative grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded bg-surface-2 text-accent">
                    {#if item.details?.imageUrl}
                      <img
                        src={item.details.imageUrl}
                        alt=""
                        class="h-full w-full object-cover"
                        loading="lazy"
                      />
                    {:else}
                      <span class="{placeTypeIconClass(item.type ?? item.displayName)} text-lg"></span>
                    {/if}
                    {#if item.details?.imageUrl}
                      <span class="absolute bottom-0.5 right-0.5 grid h-4 w-4 place-items-center rounded-full bg-surface-1/95 text-accent shadow ring-1 ring-surface-3/80">
                        <span class="{placeTypeIconClass(item.type ?? item.displayName)} text-[10px]"></span>
                      </span>
                    {/if}
                  </span>
                  <span class="min-w-0 flex-1">
                    <span class="block truncate text-sm font-medium text-text-1">{item.name}</span>
                    <span class="mt-0.5 block truncate text-xs text-text-2">
                      {item.displayName ?? displayPlaceTypeLabel(item.type)}
                      {#if context}
                        · {context}
                      {/if}
                    </span>
                  </span>
                </button>
              {/each}
            {:else}
              <p class="px-6 py-4 text-sm text-text-3">
                {savedListSearchQuery.trim()
                  ? 'No places match this search.'
                  : routedSavedPlaceList.isViewportFiltered ? 'No places in this view.' : 'No places in this list yet.'}
              </p>
            {/if}
          </div>
        {/if}
      </aside>
    {:else if activePlace && !mapsStore.isAddPlaceModalOpen}
      <aside class="pointer-events-auto h-full w-full overflow-y-auto bg-surface-1/96 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md {isLeftPanelVisuallyMinimized ? 'hidden' : ''}" data-testid="active-place-panel">
        {#if activePlaceHeroMedia}
          <button
            type="button"
            class="block h-56 w-full overflow-hidden bg-surface-2 text-left"
            aria-label="See photos"
            onclick={() => openPhotoGallery(0)}
          >
            <img src={activePlaceHeroImageUrl} alt={activePlaceHeroMedia.alt ?? activePlace.name} class="h-full w-full object-cover" />
          </button>
        {:else if activePlaceHeroImageUrl}
          <img src={activePlaceHeroImageUrl} alt={activePlace.name} class="block h-48 w-full bg-surface-2 object-cover" loading="lazy" />
        {:else}
          <div class="h-20"></div>
        {/if}
        <div class="px-5 pb-3 pt-4">
          <div class="flex items-center justify-between gap-3">
            <h2 class="truncate text-2xl font-medium text-text-1">{activePlace.name}</h2>
            {#if activeStoredPlace}
              <button
                type="button"
                class="flex shrink-0 items-center gap-1.5 rounded-lg p-2 text-sm text-text-2 hover:bg-surface-2 hover:text-text-1"
                onclick={removeActivePin}
              >
                <span class="i-lucide-trash-2" aria-hidden="true"></span>
                Remove pin
              </button>
            {/if}
          </div>
          <div class="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-text-2">
            {#if activePlaceCanHaveReviews && reviewSummary.count}
              <button
                type="button"
                class="inline-flex items-center gap-2 rounded text-left hover:text-accent"
                onclick={() => activePlaceTab = 'reviews'}
              >
                <span>{reviewSummary.average.toFixed(1)}</span>
                <span class="flex gap-0.5 font-sans text-sm leading-none tracking-normal">
                  {#each [1, 2, 3, 4, 5] as rating}
                    <span class={reviewSummary.average >= rating - 0.25 ? 'text-accent' : 'text-text-3'} aria-hidden="true">
                      {reviewSummary.average >= rating - 0.25 ? '★' : '☆'}
                    </span>
                  {/each}
                </span>
                <span>({reviewSummary.count})</span>
              </button>
            {/if}
            <span class="inline-flex items-center gap-1.5 capitalize">
              <span class="{placeTypeIconClass(activePlace.type ?? activePlace.displayName)} text-base text-accent" aria-hidden="true"></span>
              <span>{displayPlaceTypeLabel(activePlace.displayName ?? activePlace.type)}</span>
            </span>
          </div>
          {#if activePlaceContext}
            <p class="mt-1 text-sm text-text-2">{activePlaceContext}</p>
          {/if}
        </div>
        <div class="flex border-y border-surface-3/70 px-4">
          <button
            type="button"
            class="relative flex-1 px-3 py-3 text-sm font-medium {activePlaceTab === 'overview' ? 'text-accent' : 'text-text-2 hover:text-text-1'}"
            aria-current={activePlaceTab === 'overview' ? 'page' : undefined}
            onclick={() => activePlaceTab = 'overview'}
          >
            Overview
            {#if activePlaceTab === 'overview'}
              <span class="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-accent"></span>
            {/if}
          </button>
          {#if activePlaceCanHaveReviews}
            <button
              type="button"
              class="relative flex-1 px-3 py-3 text-sm font-medium {activePlaceTab === 'reviews' ? 'text-accent' : 'text-text-2 hover:text-text-1'}"
              aria-current={activePlaceTab === 'reviews' ? 'page' : undefined}
              onclick={() => activePlaceTab = 'reviews'}
            >
              Reviews
              {#if activePlaceTab === 'reviews'}
                <span class="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-accent"></span>
              {/if}
            </button>
          {/if}
        </div>

        {#if activePlaceTab === 'overview'}
          <div class="space-y-5 px-5 py-4">
            <div class="flex justify-around gap-3">
              <button
                type="button"
                class="flex min-w-20 flex-col items-center gap-2 text-sm text-text-1"
                aria-pressed={isActivePlaceInAnyList}
                aria-expanded={isSaveListsPanelOpen}
                data-testid="active-place-save"
                onclick={() => {
                  isSaveListsPanelOpen = !isSaveListsPanelOpen;
                  savedListStatus = 'idle';
                }}
              >
                <span class="grid h-10 w-10 place-items-center rounded-full bg-accent/18 text-accent">
                  <span class="{isActivePlaceInAnyList ? 'i-lucide-bookmark-check' : 'i-lucide-bookmark'} text-xl"></span>
                </span>
                <span>{isActivePlaceInAnyList ? 'Saved' : 'Save'}</span>
              </button>
              <button
                type="button"
                class="flex min-w-20 flex-col items-center gap-2 text-sm text-text-1"
                title={activePlaceUrlCopied ? 'Copied' : 'Share'}
                aria-label={activePlaceUrlCopied ? 'Copied' : 'Share'}
                data-testid="active-place-share"
                onclick={copyActivePlaceUrl}
              >
                <span class="grid h-10 w-10 place-items-center rounded-full bg-accent/18 text-accent">
                  <span class="{activePlaceUrlCopied ? 'i-lucide-check' : 'i-lucide-share'} text-xl"></span>
                </span>
                <span>{activePlaceUrlCopied ? 'Copied' : 'Share'}</span>
              </button>
              {#if canReviewActivePlace}
                <button
                  type="button"
                  class="flex min-w-20 flex-col items-center gap-2 text-sm text-text-1"
                  onclick={openReviewModal}
                >
                  <span class="grid h-10 w-10 place-items-center rounded-full bg-accent/18 text-accent">
                    <span class="i-lucide-image-plus text-xl"></span>
                  </span>
                  <span>Add photo</span>
                </button>
              {/if}
            </div>

            {#if activePlaceDetails?.website || activePlaceDetails?.phone || activePlaceDetails?.email}
              <div class="flex flex-wrap gap-2">
                {#if activePlaceDetails.website}
                  <a
                    href={activePlaceDetails.website}
                    target="_blank"
                    rel="noreferrer"
                    class="inline-flex h-10 min-w-24 items-center justify-center gap-2 rounded-full bg-surface-2 px-3 text-sm font-medium text-text-1 no-underline hover:bg-surface-3"
                  >
                    <span class="i-lucide-globe-2 text-base text-accent"></span>
                    <span class="truncate">Website</span>
                  </a>
                {/if}
                {#if activePlaceDetails.phone}
                  <a
                    href={phoneHref(activePlaceDetails.phone)}
                    class="inline-flex h-10 min-w-24 items-center justify-center gap-2 rounded-full bg-surface-2 px-3 text-sm font-medium text-text-1 no-underline hover:bg-surface-3"
                  >
                    <span class="i-lucide-phone text-base text-accent"></span>
                    <span class="truncate">Call</span>
                  </a>
                {/if}
                {#if activePlaceDetails.email}
                  <a
                    href={emailHref(activePlaceDetails.email)}
                    class="inline-flex h-10 min-w-24 items-center justify-center gap-2 rounded-full bg-surface-2 px-3 text-sm font-medium text-text-1 no-underline hover:bg-surface-3"
                  >
                    <span class="i-lucide-mail text-base text-accent"></span>
                    <span class="truncate">Email</span>
                  </a>
                {/if}
              </div>
            {/if}

            {#if isSaveListsPanelOpen}
              <div class="rounded-xl bg-surface-2/45 p-3 text-sm" data-testid="saved-place-lists-panel">
                <div class="mb-2 flex items-center gap-2 px-1">
                  <h3 class="min-w-0 flex-1 truncate text-sm font-semibold text-text-1">Save in lists</h3>
                  {#if savedListStatus === 'saving'}
                    <span class="i-lucide-loader-circle animate-spin text-base text-text-3" aria-label="Saving"></span>
                  {:else if savedListStatus === 'error'}
                    <span class="text-xs text-red-400">Could not save</span>
                  {/if}
                  <button
                    type="button"
                    class="grid h-7 w-7 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
                    title="Close"
                    aria-label="Close lists"
                    onclick={() => isSaveListsPanelOpen = false}
                  >
                    <span class="i-lucide-x text-base"></span>
                  </button>
                </div>

                <div class="space-y-1">
                  {#each savedPlaceLists as list (list.id)}
                    <div class="flex items-center gap-1 rounded-md hover:bg-surface-2/70">
                      <button
                        type="button"
                        class="flex min-w-0 flex-1 items-center gap-3 px-2 py-2 text-left"
                        aria-pressed={isPlaceInSavedList(list)}
                        data-testid={`saved-place-list-${list.name.toLowerCase().replace(/\s+/g, '-')}`}
                        onclick={() => toggleActivePlaceInSavedList(list)}
                      >
                        <span class="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-accent/14 text-accent">
                          <span class="{savedListIconClass(list.icon)} text-base"></span>
                        </span>
                        <span class="min-w-0 flex-1">
                          <span class="block truncate text-text-1">{list.name}</span>
                          <span class="block text-xs text-text-3">
                            {savedPlaceListToggleMetaText(list)}
                          </span>
                        </span>
                        <span class="grid h-6 w-6 shrink-0 place-items-center rounded-full border {isPlaceInSavedList(list) ? 'border-accent bg-accent text-white' : 'border-surface-3 text-transparent'}">
                          <span class="i-lucide-check text-sm"></span>
                        </span>
                      </button>
                      {#if list.visibility === 'public'}
                        <button
                          type="button"
                          class="grid h-8 w-8 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-3/70 hover:text-text-1 disabled:cursor-wait disabled:opacity-45"
                          title={publicListUrlTitle(list)}
                          aria-label={copiedSavedListId === list.id ? `Copied ${list.name} public URL` : `Copy ${list.name} public URL`}
                          disabled={!list.urls?.web}
                          onclick={() => copySavedListUrl(list)}
                        >
                          <span class="{copiedSavedListId === list.id ? 'i-lucide-check' : 'i-lucide-link'} text-base"></span>
                        </button>
                      {/if}
                      <button
                        type="button"
                        class="mr-1 grid h-8 w-8 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-3/70 hover:text-text-1"
                        title={list.visibility === 'public' ? 'Make private' : 'Make public'}
                        aria-label={list.visibility === 'public' ? `Make ${list.name} private` : `Make ${list.name} public`}
                        onclick={() => toggleSavedListVisibility(list)}
                      >
                        <span class="{list.visibility === 'public' ? 'i-lucide-globe-2' : 'i-lucide-lock'} text-base"></span>
                      </button>
                    </div>
                  {/each}
                </div>

                {#if showNewSavedListForm}
                  <form
                    class="mt-3 space-y-3 border-t border-surface-3/70 pt-3"
                    onsubmit={(event) => {
                      event.preventDefault();
                      void createSavedListForActivePlace();
                    }}
                  >
                    <input
                      class="h-10 w-full rounded-md border border-surface-3 bg-surface-1 px-3 text-sm text-text-1 outline-none placeholder:text-text-3 focus:border-accent"
                      bind:value={newSavedListName}
                      placeholder="List name"
                      aria-label="List name"
                    />
                    <div class="grid grid-cols-2 gap-1 rounded-md bg-surface-2 p-1">
                      <button
                        type="button"
                        class="h-8 rounded text-sm font-medium {newSavedListVisibility === 'private' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
                        aria-pressed={newSavedListVisibility === 'private'}
                        onclick={() => newSavedListVisibility = 'private'}
                      >
                        Private
                      </button>
                      <button
                        type="button"
                        class="h-8 rounded text-sm font-medium {newSavedListVisibility === 'public' ? 'bg-surface-0 text-text-1 shadow-sm' : 'text-text-2 hover:text-text-1'}"
                        aria-pressed={newSavedListVisibility === 'public'}
                        onclick={() => newSavedListVisibility = 'public'}
                      >
                        Public
                      </button>
                    </div>
                    <div class="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        class="h-9 rounded-md px-3 text-sm font-medium text-text-2 hover:bg-surface-2 hover:text-text-1"
                        onclick={() => {
                          showNewSavedListForm = false;
                          newSavedListName = '';
                          newSavedListVisibility = 'private';
                        }}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        class="inline-flex h-9 items-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45"
                        disabled={!newSavedListName.trim() || savedListStatus === 'saving'}
                      >
                        <span class="i-lucide-plus text-base"></span>
                        <span>Create</span>
                      </button>
                    </div>
                  </form>
                {:else}
                  <button
                    type="button"
                    class="mt-3 flex h-10 w-full items-center justify-center gap-2 rounded-full bg-accent/18 text-sm font-medium text-accent hover:bg-accent/25"
                    data-testid="new-saved-place-list"
                    onclick={() => {
                      showNewSavedListForm = true;
                      savedListStatus = 'idle';
                    }}
                  >
                    <span class="i-lucide-plus text-base"></span>
                    <span>New list</span>
                  </button>
                {/if}
              </div>
            {/if}

            {#if activePlaceDetails?.description}
              <section class="rounded-md bg-surface-0/70 px-4 py-3">
                <p class="text-sm leading-6 text-text-2">{activePlaceDetails.description}</p>
              </section>
            {/if}

            <div class="-mx-5 text-sm text-text-2">
              {#each placeDetailRows(activePlace, activePlaceDetails) as row}
                <div class="flex items-start gap-4 border-t border-surface-3/70 px-5 py-3">
                  <span class="{row.icon} mt-0.5 w-5 shrink-0 text-base text-accent"></span>
                  <span class="min-w-0 flex-1">
                    <span class="block text-xs text-text-3">{row.label}</span>
                    {#if row.href}
                      <a href={row.href} target="_blank" rel="noreferrer" class="block truncate text-text-2 no-underline hover:text-accent">
                        {row.value}
                      </a>
                    {:else}
                      <span class="block break-words">{row.value}</span>
                    {/if}
                  </span>
                </div>
              {/each}
              {#if visiblePlaceLinks(activePlaceDetails).length}
                <div class="border-t border-surface-3/70 px-5 py-3">
                  <div class="mb-2 flex items-center gap-4">
                    <span class="i-lucide-link w-5 text-base text-accent"></span>
                    <span class="text-xs text-text-3">Links</span>
                  </div>
                  <div class="ml-9 flex flex-wrap gap-2">
                    {#each visiblePlaceLinks(activePlaceDetails) as link (link.url)}
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noreferrer"
                        class="max-w-full truncate rounded-full bg-surface-2 px-3 py-1.5 text-xs font-medium text-text-1 no-underline hover:bg-surface-3"
                        title={link.url}
                      >
                        {link.label} · {externalUrlLabel(link.url)}
                      </a>
                    {/each}
                  </div>
                </div>
              {/if}
            </div>
          </div>
        {:else if canReviewActivePlace}
          <div class="px-5 py-4">
            <div class="mb-3 flex items-start gap-4">
              <div class="min-w-0 flex-1 space-y-1.5">
                {#each [5, 4, 3, 2, 1] as rating}
                  <div class="grid grid-cols-[0.75rem_1fr] items-center gap-2 text-xs text-text-3">
                    <span>{rating}</span>
                    <div class="h-1.5 overflow-hidden rounded-full bg-surface-3">
                      <div
                        class="h-full rounded-full bg-accent"
                        style:width={`${reviewSummary.count ? (reviewSummary.counts[rating - 1] / reviewSummary.count) * 100 : 0}%`}
                      ></div>
                    </div>
                  </div>
                {/each}
              </div>
              <div class="w-20 shrink-0 text-center">
                <div class="text-4xl leading-none text-text-1">{reviewSummary.count ? reviewSummary.average.toFixed(1) : '-'}</div>
                <div class="mt-1 flex justify-center gap-0.5 font-sans text-sm leading-none tracking-normal" aria-label={`${reviewSummary.average.toFixed(1)} stars`}>
                  {#each [1, 2, 3, 4, 5] as rating}
                    <span class={reviewSummary.average >= rating - 0.25 ? 'text-accent' : 'text-text-3'} aria-hidden="true">
                      {reviewSummary.average >= rating - 0.25 ? '★' : '☆'}
                    </span>
                  {/each}
                </div>
                <div class="mt-1 text-xs text-text-3">{reviewSummary.count} {reviewSummary.count === 1 ? 'review' : 'reviews'}</div>
              </div>
            </div>
            <button
              type="button"
              class="mx-auto mb-4 flex h-10 items-center gap-2 rounded-full bg-accent/18 px-5 text-sm font-medium text-accent hover:bg-accent/25"
              data-testid="write-review-button"
              onclick={openReviewModal}
            >
              <span class="i-lucide-image-plus text-base"></span>
              <span>Write a review</span>
            </button>
            <div class="mb-2 flex items-center justify-between gap-2 border-t border-surface-3/70 pt-3">
              <h3 class="text-sm font-semibold text-text-1">Reviews</h3>
              {#if activePlaceReviews.length}
                <span class="text-xs text-text-3">{activePlaceReviews.length}</span>
              {/if}
            </div>
            {#if activePlaceReviews.length}
              <div class="max-h-72 space-y-3 overflow-y-auto pr-1">
                {#each activePlaceReviews as review (review.id)}
                  <div class="text-xs text-text-2">
                    <div class="mb-0.5 flex items-center gap-1 text-text-1">
                      {#each Array(review.rating) as _}
                        <span class="text-xs leading-none text-accent" aria-hidden="true">★</span>
                      {/each}
                      <span class="ml-1 text-text-3">{new Date(review.createdAt).toLocaleDateString()}</span>
                    </div>
                    {#if review.body}
                      <p class="line-clamp-2">{review.body}</p>
                    {/if}
                    {#if review.media?.length}
                      <div class="mt-2 grid grid-cols-3 gap-1.5">
                        {#each review.media as media (media.url)}
                          {#if media.type === 'image'}
                            <a href={reviewMediaDisplayUrl(media.url)} target="_blank" rel="noreferrer" class="block overflow-hidden rounded bg-surface-2" title={media.url}>
                              <img src={reviewMediaDisplayUrl(media.url)} alt={media.alt ?? 'Review photo'} class="aspect-square h-full w-full object-cover" loading="lazy" />
                            </a>
                          {:else}
                            <a href={reviewMediaDisplayUrl(media.url)} target="_blank" rel="noreferrer" class="block overflow-hidden rounded bg-surface-2" title={media.url}>
                              <video src={reviewMediaDisplayUrl(media.url)} class="aspect-square h-full w-full object-cover" muted playsinline preload="metadata"></video>
                            </a>
                          {/if}
                        {/each}
                      </div>
                    {/if}
                  </div>
                {/each}
              </div>
            {:else}
              <p class="text-sm text-text-3">No reviews yet.</p>
            {/if}
          </div>
        {/if}
      </aside>
    {/if}
  </div>

  {#if isLeftPanelVisuallyMinimized}
    <button
      type="button"
      class="pointer-events-auto absolute bottom-4 left-3 z-[10002] flex max-w-[calc(100vw-5rem)] items-center gap-3 rounded-full bg-surface-1/96 py-2 pl-2 pr-4 text-left shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md"
      title={`Restore ${minimizedLeftPanelTitle()}`}
      aria-label={`Restore ${minimizedLeftPanelTitle()}`}
      data-testid="left-panel-restore"
      onclick={() => isLeftPanelMinimized = false}
    >
      <span class="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent/18 text-accent">
        <span class="{minimizedLeftPanelIconClass()} text-lg"></span>
      </span>
      <span class="min-w-0">
        <span class="block truncate text-sm font-medium text-text-1">{minimizedLeftPanelTitle()}</span>
        <span class="block truncate text-xs text-text-3">{minimizedLeftPanelSubtitle()}</span>
      </span>
      <span class="i-lucide-panel-left-open shrink-0 text-base text-text-3"></span>
    </button>
  {/if}

  <div class="pointer-events-none absolute right-3 top-4 z-[10000] flex flex-col items-end gap-3 sm:right-4">
    <div class="pointer-events-auto flex h-12 items-center gap-2">
      {#if showBandwidth}
        <div class="hidden lg:block">
          <BandwidthIndicator />
        </div>
      {/if}
      {#if showConnectivity || showConnectivityWarning}
        <ConnectivityIndicator />
      {/if}
      <MapAccountMenu />
    </div>
  </div>

  {#if libraryOverlayLists.length && !showingSavedListPanel && !isMeasureDistanceOpen}
    <div class="pointer-events-none absolute bottom-4 left-3 right-16 z-[10000] flex flex-wrap items-center gap-2 {isLeftPanelMapObscuring ? 'sm:left-[424px]' : 'sm:left-4'}">
      <div class="pointer-events-auto flex max-w-full flex-wrap items-center gap-1.5 rounded-full bg-surface-1/94 px-2 py-1.5 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md" data-testid="library-overlay-stack">
        <span class="grid h-8 w-8 shrink-0 place-items-center rounded-full text-text-2" aria-hidden="true">
          <span class="i-lucide-layers-3 text-base"></span>
        </span>
        {#each libraryOverlayLists as list, index (list.id)}
          <button
            type="button"
            class="flex h-8 max-w-44 items-center gap-1.5 rounded-full bg-surface-2 px-2.5 text-xs font-medium text-text-1 hover:bg-surface-3"
            title={list.name}
            aria-label={`Open ${list.name}`}
            onclick={() => openOwnSavedPlaceList(list)}
          >
            <span class="iris-library-layer-swatch" data-list-index={index % maxLibraryOverlayLists}></span>
            <span class="truncate">{list.name}</span>
          </button>
        {/each}
        <button
          type="button"
          class="grid h-8 w-8 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
          title="Hide all list layers"
          aria-label="Hide all list layers"
          onclick={clearLibraryOverlays}
        >
          <span class="i-lucide-x text-base"></span>
        </button>
      </div>
    </div>
  {/if}

  {#if isMeasureDistanceOpen}
    <div class="pointer-events-none absolute bottom-4 left-3 right-16 z-[10001] flex justify-center {isLeftPanelMapObscuring ? 'sm:left-[424px]' : 'sm:left-4'}">
      <div class="pointer-events-auto w-full max-w-sm rounded-xl bg-surface-1/96 p-3 text-sm text-text-1 shadow-lg ring-1 ring-surface-3/70 backdrop-blur-md" data-testid="measure-distance-panel">
        <div class="mb-2 flex items-center gap-2">
          <h2 class="min-w-0 flex-1 truncate text-sm font-semibold">Measure distance</h2>
          <button
            type="button"
            class="grid h-7 w-7 shrink-0 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
            title="Close"
            aria-label="Close measure distance"
            onclick={clearMeasureDistance}
          >
            <span class="i-lucide-x text-base"></span>
          </button>
        </div>
        <p class="mb-2 text-xs text-text-2">
          {measureDistancePoints.length < 2 ? 'Click on the map to add to your path' : `${measureDistancePoints.length} points`}
        </p>
        <div class="flex items-center gap-2">
          <span class="min-w-0 flex-1 text-text-2">Total distance</span>
          <span class="shrink-0 font-medium" data-testid="measure-distance-total">{formatMeasureDistance(measureDistanceTotalMeters)}</span>
        </div>
        <div class="mt-3 flex items-center justify-end gap-2">
          <button
            type="button"
            class="inline-flex h-8 items-center gap-1.5 rounded-full px-3 text-xs font-medium text-text-2 hover:bg-surface-2 hover:text-text-1 disabled:cursor-not-allowed disabled:opacity-40"
            disabled={measureDistancePoints.length === 0}
            onclick={undoMeasureDistancePoint}
          >
            <span class="i-lucide-undo-2 text-sm"></span>
            <span>Undo</span>
          </button>
          <button
            type="button"
            class="inline-flex h-8 items-center gap-1.5 rounded-full bg-surface-2 px-3 text-xs font-medium text-text-1 hover:bg-surface-3"
            onclick={clearMeasureDistance}
          >
            <span class="i-lucide-trash-2 text-sm text-text-2"></span>
            <span>Clear</span>
          </button>
        </div>
      </div>
    </div>
  {/if}

  {#if isPhotoGalleryOpen && activePlace && activeGalleryPhoto}
    <div
      class="absolute bottom-0 right-0 top-0 z-[10002] flex bg-black text-white {activePlace && !mapsStore.isAddPlaceModalOpen ? 'left-[408px]' : 'left-0'}"
      data-testid="photo-gallery"
    >
      <div class="hidden w-28 shrink-0 overflow-y-auto border-r border-white/10 bg-black sm:block">
        {#each activePlacePhotos as photo, index (photo.url)}
          <button
            type="button"
            class="block aspect-square w-full overflow-hidden border-l-2 {index === photoGalleryIndex ? 'border-accent opacity-100' : 'border-transparent opacity-70 hover:opacity-100'}"
            aria-label={`Photo ${index + 1}`}
            onclick={() => photoGalleryIndex = index}
          >
            <img src={reviewMediaDisplayUrl(photo.url)} alt={photo.alt ?? `${activePlace.name} photo ${index + 1}`} class="h-full w-full object-cover" />
          </button>
        {/each}
      </div>

      <div class="relative flex min-w-0 flex-1 flex-col">
        <div class="absolute left-6 right-6 top-5 z-[1] flex items-center justify-between gap-3">
          <div class="min-w-0">
            <div class="truncate text-sm font-semibold">{activePlace.name}</div>
            <div class="text-xs text-white/65">{photoGalleryIndex + 1} / {activePlacePhotos.length}</div>
          </div>
          <button
            type="button"
            class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 text-white hover:bg-white/18"
            title="Close"
            aria-label="Close photos"
            onclick={closePhotoGallery}
          >
            <span class="i-lucide-x text-lg"></span>
          </button>
        </div>

        <div class="grid min-h-0 flex-1 place-items-center px-12 py-20">
          <img
            src={reviewMediaDisplayUrl(activeGalleryPhoto.url)}
            alt={activeGalleryPhoto.alt ?? `${activePlace.name} photo`}
            class="max-h-full max-w-full object-contain"
            data-testid="photo-gallery-image"
          />
        </div>

        {#if activePlacePhotos.length > 1}
          <button
            type="button"
            class="absolute left-5 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white hover:bg-white/18"
            title="Previous photo"
            aria-label="Previous photo"
            onclick={() => stepPhotoGallery(-1)}
          >
            <span class="i-lucide-chevron-left text-xl"></span>
          </button>
          <button
            type="button"
            class="absolute right-5 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white hover:bg-white/18"
            title="Next photo"
            aria-label="Next photo"
            onclick={() => stepPhotoGallery(1)}
          >
            <span class="i-lucide-chevron-right text-xl"></span>
          </button>
        {/if}
      </div>
    </div>
  {/if}

  {#if isReviewModalOpen && activePlace && canReviewActivePlace}
    <div
      class="absolute inset-0 z-[10002] flex items-center justify-center bg-black/55 px-4 backdrop-blur-[1px]"
      role="presentation"
      onpointerdown={(event) => {
        if (event.currentTarget === event.target) closeReviewModal();
      }}
    >
      <div
        class="w-full max-w-xl rounded-lg bg-surface-1 p-6 shadow-2xl ring-1 ring-surface-3"
        role="dialog"
        aria-modal="true"
        aria-labelledby="review-modal-title"
        data-testid="review-modal"
      >
        <div class="mb-5 flex items-center justify-between gap-3">
          <h2 id="review-modal-title" class="min-w-0 flex-1 truncate text-center text-base font-medium text-text-1">{activePlace.name}</h2>
          <button
            type="button"
            class="grid h-8 w-8 place-items-center rounded-full text-text-2 hover:bg-surface-2 hover:text-text-1"
            title="Close"
            aria-label="Close"
            onclick={closeReviewModal}
          >
            <span class="i-lucide-x text-lg"></span>
          </button>
        </div>

        <div class="mb-5 flex items-center gap-3">
          <div class="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent text-base font-semibold text-white">
            {($nostrStore.npub || 'A').slice(0, 1).toUpperCase()}
          </div>
          <div class="min-w-0">
            <div class="truncate text-sm font-medium text-text-1">{$nostrStore.npub ? 'You' : 'Anonymous'}</div>
            <div class="text-xs text-text-3">Posting publicly</div>
          </div>
        </div>

        <div class="mb-5 flex justify-center gap-4" aria-label="Rating">
          {#each [1, 2, 3, 4, 5] as rating}
            <button
              type="button"
              class="grid h-10 w-10 place-items-center rounded-full text-3xl hover:bg-surface-2 hover:text-accent {reviewRating !== null && reviewRating >= rating ? 'text-accent' : 'text-text-3'}"
              aria-label={`${rating} star${rating === 1 ? '' : 's'}`}
              title={`${rating} star${rating === 1 ? '' : 's'}`}
              onclick={() => {
                reviewRating = rating;
                reviewStatus = 'idle';
              }}
            >
              {#if reviewRating !== null && reviewRating >= rating}
                <span class="leading-none" aria-hidden="true">★</span>
              {:else}
                <span class="i-lucide-star text-3xl" aria-hidden="true"></span>
              {/if}
            </button>
          {/each}
        </div>

        <textarea
          class="min-h-28 w-full resize-none rounded-md border border-surface-3 bg-surface-0/70 px-4 py-3 text-sm text-text-1 outline-none placeholder:text-text-3 focus:border-accent"
          bind:value={reviewBody}
          placeholder="Share details of your own experience at this place"
          rows="4"
          oninput={() => {
            reviewStatus = 'idle';
          }}
        ></textarea>

        <input
          bind:this={reviewMediaInputElement}
          class="hidden"
          type="file"
          accept="image/*,video/*"
          multiple
          onchange={handleReviewMediaFiles}
          aria-label="Review media files"
        />
        <button
          type="button"
          class="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-full bg-surface-2 text-sm font-medium text-text-1 hover:bg-surface-3 disabled:cursor-not-allowed disabled:opacity-50"
          disabled={isReviewMediaUploading}
          onclick={() => reviewMediaInputElement?.click()}
        >
          <span class="i-lucide-image-plus text-base"></span>
          <span>{isReviewMediaUploading ? 'Uploading media' : 'Add photos & videos'}</span>
          {#if reviewMediaUpload}
            <span class="text-xs text-text-3">
              {Math.round((reviewMediaUpload.bytes / Math.max(1, reviewMediaUpload.totalBytes)) * 100)}%
            </span>
          {/if}
        </button>

        {#if reviewMedia.length}
          <div class="mt-3 grid grid-cols-5 gap-2">
            {#each reviewMedia as media (media.url)}
              <div class="group relative overflow-hidden rounded bg-surface-2">
                {#if media.type === 'image'}
                  <img src={reviewMediaDisplayUrl(media.url)} alt={media.alt ?? 'Review photo'} class="aspect-square h-full w-full object-cover" />
                {:else}
                  <video src={reviewMediaDisplayUrl(media.url)} class="aspect-square h-full w-full object-cover" muted playsinline preload="metadata"></video>
                {/if}
                <button
                  type="button"
                  class="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/65 text-white opacity-90 hover:bg-black"
                  title="Remove"
                  aria-label="Remove media"
                  onclick={() => removeReviewMedia(media.url)}
                >
                  <span class="i-lucide-x text-sm"></span>
                </button>
              </div>
            {/each}
          </div>
        {/if}

        {#if reviewMediaError}
          <p class="mt-2 text-xs text-red-400">{reviewMediaError}</p>
        {/if}

        <div class="mt-10 flex items-center justify-end gap-3">
          <span class="mr-auto text-xs {reviewStatus === 'error' ? 'text-red-400' : 'text-text-3'}">
            {reviewStatus === 'error' ? 'Could not save' : ''}
          </span>
          <button
            type="button"
            class="h-9 rounded-md border border-surface-3 px-5 text-sm font-medium text-text-2 hover:bg-surface-2 hover:text-text-1 disabled:cursor-not-allowed disabled:opacity-50"
            disabled={reviewStatus === 'saving' || isReviewMediaUploading}
            onclick={closeReviewModal}
          >
            Cancel
          </button>
          <button
            type="button"
            class="inline-flex h-9 items-center gap-2 rounded-md bg-accent px-5 text-sm font-medium text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45"
            disabled={reviewStatus === 'saving' || reviewRating === null || isReviewMediaUploading}
            onclick={saveActivePlaceReview}
          >
            {#if reviewStatus === 'saving'}
              <span class="i-lucide-loader-circle animate-spin text-sm"></span>
            {/if}
            <span>{reviewStatus === 'saving' ? 'Posting' : 'Post'}</span>
          </button>
        </div>
      </div>
    </div>
  {/if}

  {#if contextMenu}
    <div
      bind:this={contextMenuElement}
      class="absolute z-[10001] w-60 overflow-hidden rounded-lg bg-surface-1/96 py-1 shadow-2xl ring-1 ring-surface-3/80 backdrop-blur-md"
      style:left={`${contextMenu.x}px`}
      style:top={`${contextMenu.y}px`}
      role="menu"
      tabindex="-1"
      data-testid="map-context-menu"
      oncontextmenu={(event) => event.preventDefault()}
    >
      <div class="px-3 py-2 text-left text-sm text-text-1">
        <span>{formatContextCoordinates(contextMenu.lat, contextMenu.lng)}</span>
      </div>
      <button
        type="button"
        class="flex w-full items-center gap-3 px-3 py-2 text-left text-sm text-text-1 hover:bg-surface-2"
        role="menuitem"
        data-testid="map-context-share"
        onclick={shareContextLocation}
      >
        <span class="{contextMenuUrlCopied ? 'i-lucide-check' : 'i-lucide-share'} text-base text-text-2"></span>
        <span>{contextMenuUrlCopied ? 'Copied link' : 'Share this location'}</span>
      </button>
      <button
        type="button"
        class="flex w-full items-center gap-3 px-3 py-2 text-left text-sm text-text-1 hover:bg-surface-2"
        role="menuitem"
        data-testid="map-context-measure-distance"
        onclick={startMeasureDistanceAtContextLocation}
      >
        <span class="i-lucide-ruler text-base text-text-2"></span>
        <span>Measure distance</span>
      </button>
      <button
        type="button"
        class="flex w-full items-center gap-3 px-3 py-2 text-left text-sm text-text-1 hover:bg-surface-2"
        role="menuitem"
        data-testid="map-context-add-place"
        onclick={addMissingPlaceAtContextLocation}
      >
        <span class="i-lucide-map-pin-plus text-base text-text-2"></span>
        <span>Add a missing place</span>
      </button>
    </div>
  {/if}
  <AddPlaceModal />
</div>

<style>
  :global(.iris-map-theme-light) {
    color-scheme: light;
    --surface-0: 245 245 245;
    --surface-1: 235 235 235;
    --surface-2: 221 221 221;
    --surface-3: 187 187 187;
    --text-1: 26 26 26;
    --text-2: 85 85 85;
    --text-3: 112 112 112;
  }

  :global(.iris-map-theme-dark) {
    color-scheme: dark;
    --surface-0: 15 15 15;
    --surface-1: 24 24 24;
    --surface-2: 35 35 35;
    --surface-3: 63 63 63;
    --text-1: 255 255 255;
    --text-2: 170 170 170;
    --text-3: 96 96 96;
  }

  :global(.maplibregl-map) {
    background: rgb(var(--surface-0));
    color: rgb(var(--text-1));
  }

  :global(.maplibregl-ctrl-group) {
    background: rgb(var(--surface-1)) !important;
    border: 1px solid rgb(var(--surface-3)) !important;
    box-shadow: 0 8px 20px rgb(0 0 0 / 24%) !important;
  }

  :global(.maplibregl-ctrl-group button) {
    background-color: rgb(var(--surface-1)) !important;
    color: rgb(var(--text-1)) !important;
  }

  :global(.maplibregl-ctrl-group button.iris-map-locate-control) {
    display: grid !important;
    place-items: center;
  }

  :global(.iris-map-locate-icon) {
    height: 18px;
    width: 18px;
  }

  :global(.iris-map-locate-control.is-locating .iris-map-locate-icon) {
    animation: iris-map-locate-pulse 900ms ease-in-out infinite alternate;
  }

  @keyframes iris-map-locate-pulse {
    from {
      opacity: 0.55;
      transform: scale(0.92);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  :global(.maplibregl-ctrl-group button + button) {
    border-top-color: rgb(var(--surface-3)) !important;
  }

  @media (max-width: 640px), (hover: none) and (pointer: coarse) {
    :global(.iris-map-navigation-control) {
      display: none !important;
    }
  }

  :global(.maplibregl-ctrl-attrib) {
    background: rgb(var(--surface-1) / 82%) !important;
    color: rgb(var(--text-2)) !important;
  }

  :global(.maplibregl-ctrl-attrib a) {
    color: rgb(var(--text-1)) !important;
  }

  :global(.iris-map-place-marker),
  :global(.iris-map-active-marker),
  :global(.iris-map-saved-list-marker) {
    --iris-map-pin-border: white;
    --iris-map-pin-head-radius: 11px;
    --iris-map-pin-head-size: 22px;
    --iris-map-pin-dot-radius: 4px;
    --iris-map-pin-dot-size: 8px;
    --iris-map-pin-head-top: 1px;
    position: absolute;
    width: 26px;
    height: 30px;
    background: transparent;
    border: 0;
    box-shadow: none;
    color: #ef4444;
    cursor: pointer;
  }

  :global(.iris-map-place-marker) {
    color: #ef4444;
  }

  :global(.iris-map-active-marker) {
    --iris-map-pin-head-radius: 14px;
    --iris-map-pin-head-size: 28px;
    --iris-map-pin-dot-radius: 5px;
    --iris-map-pin-dot-size: 10px;
    z-index: 4;
    width: 32px;
    height: 38px;
    color: #ef4444;
  }

  :global(.iris-map-saved-list-marker) {
    color: #ef4444;
  }

  :global(.iris-map-saved-list-marker-hovered) {
    --iris-map-pin-border: #111827;
    z-index: 5;
  }

  :global(.iris-map-place-marker::before),
  :global(.iris-map-active-marker::before),
  :global(.iris-map-saved-list-marker::before) {
    content: '';
    position: absolute;
    left: 50%;
    top: var(--iris-map-pin-head-top);
    box-sizing: border-box;
    width: var(--iris-map-pin-head-size);
    height: var(--iris-map-pin-head-size);
    z-index: 0;
    border: 2px solid var(--iris-map-pin-border);
    border-radius: 999px 999px 999px 2px;
    background: currentColor;
    transform: translateX(-50%) rotate(-45deg);
  }

  :global(.iris-map-saved-list-marker::before) {
    transform-origin: center center;
    transition:
      box-shadow 140ms ease,
      transform 140ms ease;
  }

  :global(.iris-map-saved-list-marker-hovered::before) {
    box-shadow:
      0 0 0 3px rgb(255 255 255 / 72%),
      0 10px 18px rgb(0 0 0 / 32%);
    transform: translateX(-50%) rotate(-45deg) scale(1.35);
  }

  :global(.iris-map-place-marker::after),
  :global(.iris-map-active-marker::after),
  :global(.iris-map-saved-list-marker::after) {
    content: '';
    position: absolute;
    left: 50%;
    top: calc(var(--iris-map-pin-head-top) + var(--iris-map-pin-head-radius) - var(--iris-map-pin-dot-radius));
    z-index: 1;
    width: var(--iris-map-pin-dot-size);
    height: var(--iris-map-pin-dot-size);
    border-radius: 999px;
    background: white;
    transform: translateX(-50%);
  }

  :global(.iris-map-saved-list-marker::after) {
    transform-origin: center center;
    transition: transform 140ms ease;
  }

  :global(.iris-map-saved-list-marker-hovered::after) {
    transform: translateX(-50%) scale(1.15);
  }

  .iris-library-layer-swatch {
    display: block;
    width: 0.65rem;
    height: 0.65rem;
    flex: none;
    border-radius: 999px;
    background: #ef4444;
  }

  .iris-library-layer-swatch[data-list-index='1'] {
    background: #ef4444;
  }

  .iris-library-layer-swatch[data-list-index='2'] {
    background: #ef4444;
  }

  .iris-library-layer-swatch[data-list-index='3'] {
    background: #ef4444;
  }

  :global(.maplibregl-popup-content) {
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
    border: 1px solid rgb(var(--surface-3));
    border-radius: 8px;
    box-shadow: 0 12px 28px rgb(0 0 0 / 28%);
  }

  :global(.maplibregl-popup-tip) {
    border-top-color: rgb(var(--surface-1)) !important;
  }

  :global(.iris-map-place-hover-popup) {
    pointer-events: none;
  }

  :global(.iris-map-place-hover-popup .maplibregl-popup-content) {
    width: 292px;
    overflow: hidden;
    padding: 0;
    border-radius: 10px;
  }

  :global(.iris-map-hover-card) {
    background: rgb(var(--surface-1));
    color: rgb(var(--text-1));
  }

  :global(.iris-map-hover-card-image) {
    display: block;
    width: 100%;
    height: 96px;
    object-fit: cover;
    background: rgb(var(--surface-2));
  }

  :global(.iris-map-hover-card-body) {
    display: flex;
    gap: 10px;
    padding: 12px;
  }

  :global(.iris-map-hover-card-main) {
    min-width: 0;
    flex: 1;
  }

  :global(.iris-map-hover-card-title) {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 15px;
    font-weight: 650;
    line-height: 1.25;
  }

  :global(.iris-map-hover-card-meta) {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 4px;
    color: rgb(var(--text-2));
    font-size: 12px;
    line-height: 1.2;
  }

  :global(.iris-map-hover-stars) {
    display: inline-flex;
    gap: 1px;
    font-family: sans-serif;
    font-size: 12px;
    line-height: 1;
    letter-spacing: 0;
  }

  :global(.iris-hover-star-filled) {
    color: rgb(var(--accent));
  }

  :global(.iris-hover-star-empty) {
    color: rgb(var(--text-3));
  }

  :global(.iris-map-hover-card-context) {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-top: 4px;
    color: rgb(var(--text-3));
    font-size: 12px;
  }

  :global(.iris-map-hover-card-actions) {
    display: flex;
    align-items: center;
    gap: 8px;
    color: rgb(var(--accent));
  }

  :global(.iris-map-hover-card-actions span) {
    display: grid;
    width: 34px;
    height: 34px;
    place-items: center;
    border-radius: 999px;
    background: rgb(var(--accent) / 15%);
    font-size: 17px;
  }
</style>
