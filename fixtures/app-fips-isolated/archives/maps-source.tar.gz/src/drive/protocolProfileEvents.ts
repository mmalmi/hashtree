import {
  buildNostrIdentityFacetAcceptanceEvent,
  buildNostrIdentityRosterOpEvent,
  parseNostrIdentityFacetAcceptanceEvent,
  parseNostrIdentityRosterOpEvent,
  type NostrIdentityCapabilities,
  type NostrIdentityFacet,
  type NostrIdentityFacetAcceptanceContent,
  type NostrIdentityRosterOp,
  type NostrIdentityRosterOpContent,
} from 'nostr-social-graph';
import type { Event } from 'nostr-tools';
import type {
  BuildIrisProfileFacetAcceptanceEventOptions,
  BuildIrisProfileRosterOpEventOptions,
  IrisProfileCapabilities,
  IrisProfileFacet,
  IrisProfileFacetAcceptanceContent,
  IrisProfileRosterOp,
  IrisProfileRosterOpContent,
  SignedIrisProfileFacetAcceptance,
  SignedIrisProfileRosterOp,
} from './protocolTypes';
import { normalizeRosterOp, sortPurposes } from './protocolProfileNormalize';

export function buildIrisProfileRosterOpEvent(options: BuildIrisProfileRosterOpEventOptions): Event {
  return buildNostrIdentityRosterOpEvent({
    signerSecretKey: options.signerSecretKey,
    profileId: options.profileId,
    op: irisRosterOpToNostrIdentity(normalizeRosterOp(options.op)),
    ...(options.parents !== undefined ? { parents: options.parents.slice() } : {}),
    ...(options.actorSeq !== undefined ? { actorSeq: options.actorSeq } : {}),
    ...(options.createdAt !== undefined ? { createdAt: options.createdAt } : {}),
    ...(options.clientNonce !== undefined ? { clientNonce: options.clientNonce } : {}),
  });
}

export function signIrisProfileRosterOp(
  options: BuildIrisProfileRosterOpEventOptions,
): SignedIrisProfileRosterOp {
  return parseIrisProfileRosterOpEvent(buildIrisProfileRosterOpEvent(options));
}

export function buildIrisProfileFacetAcceptanceEvent(
  options: BuildIrisProfileFacetAcceptanceEventOptions,
): Event {
  return buildNostrIdentityFacetAcceptanceEvent({
    signerSecretKey: options.signerSecretKey,
    profileId: options.profileId,
    purposes: sortPurposes(options.purposes),
    ...(options.rosterOpId !== undefined ? { rosterOpId: options.rosterOpId } : {}),
    ...(options.acceptedAt !== undefined ? { acceptedAt: options.acceptedAt } : {}),
    ...(options.clientNonce !== undefined ? { clientNonce: options.clientNonce } : {}),
  });
}

export function signIrisProfileFacetAcceptance(
  options: BuildIrisProfileFacetAcceptanceEventOptions,
): SignedIrisProfileFacetAcceptance {
  return parseIrisProfileFacetAcceptanceEvent(buildIrisProfileFacetAcceptanceEvent(options));
}

export function parseIrisProfileRosterOpEvent(event: Event): SignedIrisProfileRosterOp {
  const signed = parseNostrIdentityRosterOpEvent(event);
  return {
    op_id: signed.op_id,
    signer_pubkey: signed.signer_pubkey,
    content: nostrIdentityRosterContentToIris(signed.content),
    event_json: signed.event_json,
  };
}

export function parseIrisProfileFacetAcceptanceEvent(event: Event): SignedIrisProfileFacetAcceptance {
  const signed = parseNostrIdentityFacetAcceptanceEvent(event);
  return {
    acceptance_id: signed.acceptance_id,
    signer_pubkey: signed.signer_pubkey,
    content: nostrIdentityFacetAcceptanceContentToIris(signed.content),
    event_json: signed.event_json,
  };
}

function irisRosterOpToNostrIdentity(op: IrisProfileRosterOp): NostrIdentityRosterOp {
  if (op.op === 'add_facet') {
    return {
      op: 'add_facet',
      facet: irisFacetToNostrIdentity(op.facet),
    };
  }
  if (op.op === 'tombstone_facet') {
    return {
      op: 'tombstone_facet',
      pubkey: op.pubkey,
      ...(op.reason !== undefined ? { reason: op.reason } : {}),
    };
  }
  if (op.op === 'set_capabilities') {
    return {
      op: 'set_capabilities',
      pubkey: op.pubkey,
      capabilities: irisCapabilitiesToNostrIdentity(op.capabilities),
    };
  }
  if (op.op === 'rotate_key_epoch') {
    return {
      op: 'rotate_secret_epoch',
      epoch: op.epoch,
      ...(op.wrapped_dck !== undefined ? { wrapped_secrets: op.wrapped_dck } : {}),
    };
  }
  return {
    op: 'repair_secret_wraps',
    epoch: op.epoch,
    ...(op.wrapped_dck !== undefined ? { wrapped_secrets: op.wrapped_dck } : {}),
  };
}

function nostrIdentityRosterOpToIris(op: NostrIdentityRosterOp): IrisProfileRosterOp {
  if (op.op === 'add_facet') {
    return {
      op: 'add_facet',
      facet: nostrIdentityFacetToIris(op.facet),
    };
  }
  if (op.op === 'tombstone_facet') {
    return {
      op: 'tombstone_facet',
      pubkey: op.pubkey,
      ...(op.reason !== undefined ? { reason: op.reason } : {}),
    };
  }
  if (op.op === 'set_capabilities') {
    return {
      op: 'set_capabilities',
      pubkey: op.pubkey,
      capabilities: nostrIdentityCapabilitiesToIris(op.capabilities),
    };
  }
  if (op.op === 'rotate_secret_epoch') {
    return {
      op: 'rotate_key_epoch',
      epoch: op.epoch,
      ...(op.wrapped_secrets !== undefined ? { wrapped_dck: op.wrapped_secrets } : {}),
    };
  }
  return {
    op: 'repair_key_wraps',
    epoch: op.epoch,
    ...(op.wrapped_secrets !== undefined ? { wrapped_dck: op.wrapped_secrets } : {}),
  };
}

function irisFacetToNostrIdentity(facet: IrisProfileFacet): NostrIdentityFacet {
  return {
    pubkey: facet.pubkey,
    ...(facet.profile_id !== undefined ? { profile_id: facet.profile_id } : {}),
    ...(facet.purposes !== undefined ? { purposes: facet.purposes } : {}),
    ...(facet.capabilities !== undefined ? { capabilities: irisCapabilitiesToNostrIdentity(facet.capabilities) } : {}),
    added_at: facet.added_at,
    ...(facet.label !== undefined ? { label: facet.label } : {}),
  };
}

function nostrIdentityFacetToIris(facet: NostrIdentityFacet): IrisProfileFacet {
  return {
    pubkey: facet.pubkey,
    ...(facet.profile_id !== undefined ? { profile_id: facet.profile_id } : {}),
    ...(facet.purposes !== undefined ? { purposes: facet.purposes } : {}),
    ...(facet.capabilities !== undefined ? { capabilities: nostrIdentityCapabilitiesToIris(facet.capabilities) } : {}),
    added_at: facet.added_at,
    ...(facet.label !== undefined ? { label: facet.label } : {}),
  };
}

function irisCapabilitiesToNostrIdentity(capabilities: IrisProfileCapabilities): NostrIdentityCapabilities {
  return {
    ...(capabilities.can_write_roots ? { can_write_roots: true } : {}),
    ...(capabilities.can_admin_profile ? { can_admin_profile: true } : {}),
    ...(capabilities.can_recover_app_keys ? { can_recover_app_keys: true } : {}),
    ...(capabilities.can_receive_key_wraps ? { can_receive_secret_wraps: true } : {}),
    ...(capabilities.can_decrypt_key_epochs ? { can_decrypt_secret_epochs: true } : {}),
  };
}

function nostrIdentityCapabilitiesToIris(capabilities: NostrIdentityCapabilities): IrisProfileCapabilities {
  return {
    ...(capabilities.can_write_roots ? { can_write_roots: true } : {}),
    ...(capabilities.can_admin_profile ? { can_admin_profile: true } : {}),
    ...(capabilities.can_recover_app_keys ? { can_recover_app_keys: true } : {}),
    ...(capabilities.can_receive_secret_wraps ? { can_receive_key_wraps: true } : {}),
    ...(capabilities.can_decrypt_secret_epochs ? { can_decrypt_key_epochs: true } : {}),
  };
}

function nostrIdentityRosterContentToIris(content: NostrIdentityRosterOpContent): IrisProfileRosterOpContent {
  return {
    schema: content.schema,
    profile_id: content.profile_id,
    actor_pubkey: content.actor_pubkey,
    ...(content.actor_seq !== undefined ? { actor_seq: content.actor_seq } : {}),
    parents: content.parents ?? [],
    client_nonce: content.client_nonce,
    created_at: content.created_at,
    op: nostrIdentityRosterOpToIris(content.op),
  };
}

function nostrIdentityFacetAcceptanceContentToIris(
  content: NostrIdentityFacetAcceptanceContent,
): IrisProfileFacetAcceptanceContent {
  return {
    schema: content.schema,
    profile_id: content.profile_id,
    facet_pubkey: content.facet_pubkey,
    purposes: content.purposes,
    ...(content.roster_op_id !== undefined ? { roster_op_id: content.roster_op_id } : {}),
    client_nonce: content.client_nonce,
    accepted_at: content.accepted_at,
  };
}
