export const BTCMAP_SITE_URL = 'https://btcmap.org/';
export const BTCMAP_LIST_AVATAR_URL = 'https://btcmap.org/images/logo.svg';
export const BTCMAP_LIST_DESCRIPTION = 'Places accepting bitcoin, sourced from btcmap.org.';

export function isBtcMapSource(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  const provider = (value as { provider?: unknown }).provider;
  return typeof provider === 'string' && provider.toLowerCase() === 'btcmap';
}
