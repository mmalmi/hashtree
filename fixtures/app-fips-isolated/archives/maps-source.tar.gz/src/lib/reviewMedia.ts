import type { ReviewMedia } from '../stores/mapsTypes';

const imageMimeByExtension: Record<string, string> = {
  avif: 'image/avif',
  gif: 'image/gif',
  jpeg: 'image/jpeg',
  jpg: 'image/jpeg',
  png: 'image/png',
  svg: 'image/svg+xml',
  webp: 'image/webp',
};

const videoMimeByExtension: Record<string, string> = {
  m4v: 'video/mp4',
  mov: 'video/quicktime',
  mp4: 'video/mp4',
  ogv: 'video/ogg',
  webm: 'video/webm',
};

export function parseReviewMediaInput(input: string): ReviewMedia[] {
  const seen = new Set<string>();
  return input
    .split(/[\s,]+/)
    .map((value) => value.trim())
    .filter(Boolean)
    .map(reviewMediaFromUrl)
    .filter((item): item is ReviewMedia => Boolean(item))
    .filter((item) => {
      if (seen.has(item.url)) return false;
      seen.add(item.url);
      return true;
    });
}

export function reviewMediaFromUrl(rawUrl: string): ReviewMedia | null {
  const url = rawUrl.trim();
  if (!isHashtreeMediaUrl(url)) return null;
  const extension = mediaExtension(url);
  if (!extension) return null;
  const imageMimeType = imageMimeByExtension[extension];
  if (imageMimeType) {
    return { url, mimeType: imageMimeType, type: 'image' };
  }
  const videoMimeType = videoMimeByExtension[extension];
  if (videoMimeType) {
    return { url, mimeType: videoMimeType, type: 'video' };
  }
  return null;
}

export function reviewMediaDisplayUrl(url: string): string {
  if (url.startsWith('htree://')) {
    return `/htree/${url.slice('htree://'.length).replace(/^\/+/, '')}`;
  }
  return url;
}

function isHashtreeMediaUrl(url: string): boolean {
  return url.startsWith('htree://') || url.startsWith('/htree/');
}

function mediaExtension(url: string): string | null {
  const withoutQuery = url.split(/[?#]/, 1)[0];
  const match = /\.([a-z0-9]+)$/i.exec(withoutQuery);
  return match?.[1]?.toLowerCase() ?? null;
}
