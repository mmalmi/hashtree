import type { SavedPlaceList } from '../stores/mapsTypes';
import {
  buildSavedPlaceListUrls,
  normalizeSavedPlaceListUrls,
  type SavedPlaceListUrls,
} from './savedPlaceListUrls';

const STORAGE_KEY = 'iris-maps-saved-external-place-lists';
const STORAGE_VERSION = 1;

export interface SavedExternalPlaceList {
  id: string;
  name: string;
  description?: string;
  ownerNpub: string;
  treeName: string;
  icon: SavedPlaceList['icon'];
  avatarUrl?: string;
  placeCount?: number;
  urls?: SavedPlaceListUrls;
  createdAt?: number;
  updatedAt?: number;
  savedAt: number;
}

type SavedExternalPlaceListInput = Omit<SavedExternalPlaceList, 'savedAt'> & {
  savedAt?: number;
};

export function savedExternalPlaceListKey(input: Pick<SavedExternalPlaceList, 'id' | 'ownerNpub' | 'treeName'>): string {
  return `${input.ownerNpub}/${input.treeName}/${input.id}`;
}

export function loadSavedExternalPlaceLists(storage = browserLocalStorage()): SavedExternalPlaceList[] {
  if (!storage) return [];
  try {
    const stored = storage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored) as { version?: number; lists?: unknown };
    return normalizeSavedExternalPlaceLists(parsed?.lists);
  } catch {
    return [];
  }
}

export function saveSavedExternalPlaceLists(
  lists: SavedExternalPlaceList[],
  storage = browserLocalStorage(),
): SavedExternalPlaceList[] {
  const normalized = normalizeSavedExternalPlaceLists(lists);
  if (!storage) return normalized;
  try {
    storage.setItem(STORAGE_KEY, JSON.stringify({
      version: STORAGE_VERSION,
      lists: normalized,
    }));
  } catch {
    // Ignore local storage failures.
  }
  return normalized;
}

export function upsertSavedExternalPlaceList(
  lists: SavedExternalPlaceList[],
  input: SavedExternalPlaceListInput,
): SavedExternalPlaceList[] {
  const current = normalizeSavedExternalPlaceLists(lists);
  const normalized = normalizeSavedExternalPlaceList(input);
  if (!normalized) return current;
  const key = savedExternalPlaceListKey(normalized);
  const existing = current.find((list) => savedExternalPlaceListKey(list) === key);
  return normalizeSavedExternalPlaceLists([
    ...current.filter((list) => savedExternalPlaceListKey(list) !== key),
    {
      ...normalized,
      savedAt: existing?.savedAt ?? normalized.savedAt,
    },
  ]);
}

export function removeSavedExternalPlaceList(
  lists: SavedExternalPlaceList[],
  input: Pick<SavedExternalPlaceList, 'id' | 'ownerNpub' | 'treeName'>,
): SavedExternalPlaceList[] {
  const key = savedExternalPlaceListKey(input);
  return normalizeSavedExternalPlaceLists(lists).filter((list) => savedExternalPlaceListKey(list) !== key);
}

export function savedExternalPlaceListHash(list: SavedExternalPlaceList): string {
  return `#${(list.urls ?? buildSavedPlaceListUrls({
    listId: list.id,
    ownerNpub: list.ownerNpub,
    treeName: list.treeName,
  })).appPath}`;
}

export function normalizeSavedExternalPlaceLists(raw: unknown): SavedExternalPlaceList[] {
  if (!Array.isArray(raw)) return [];
  const lists = raw
    .map(normalizeSavedExternalPlaceList)
    .filter((list): list is SavedExternalPlaceList => Boolean(list));
  const byKey = new Map<string, SavedExternalPlaceList>();
  for (const list of lists) {
    byKey.set(savedExternalPlaceListKey(list), list);
  }
  return [...byKey.values()].sort((left, right) => (
    right.savedAt - left.savedAt
    || (right.updatedAt ?? 0) - (left.updatedAt ?? 0)
    || left.name.localeCompare(right.name)
  ));
}

function normalizeSavedExternalPlaceList(raw: unknown): SavedExternalPlaceList | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Partial<SavedExternalPlaceList>;
  if (typeof record.id !== 'string' || !isCanonicalUuid(record.id)) return null;
  const ownerNpub = cleanString(record.ownerNpub);
  if (!ownerNpub?.startsWith('npub1')) return null;
  const name = cleanString(record.name) ?? 'Public list';
  const treeName = cleanString(record.treeName) ?? 'maps';
  const icon = isSavedPlaceListIcon(record.icon) ? record.icon : 'bookmark';
  const savedAt = finiteNumber(record.savedAt) ?? Date.now();
  return {
    id: record.id.toLowerCase(),
    name,
    description: cleanString(record.description),
    ownerNpub,
    treeName,
    icon,
    avatarUrl: cleanString(record.avatarUrl),
    placeCount: finiteNumber(record.placeCount),
    urls: normalizeSavedPlaceListUrls(record.urls) ?? buildSavedPlaceListUrls({
      listId: record.id.toLowerCase(),
      ownerNpub,
      treeName,
    }),
    createdAt: finiteNumber(record.createdAt),
    updatedAt: finiteNumber(record.updatedAt),
    savedAt,
  };
}

function browserLocalStorage(): Storage | null {
  if (typeof localStorage === 'undefined') return null;
  return localStorage;
}

function isCanonicalUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}

function isSavedPlaceListIcon(value: unknown): value is SavedPlaceList['icon'] {
  return value === 'heart'
    || value === 'flag'
    || value === 'briefcase'
    || value === 'star'
    || value === 'bookmark'
    || value === 'map-pin';
}

function cleanString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function finiteNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
