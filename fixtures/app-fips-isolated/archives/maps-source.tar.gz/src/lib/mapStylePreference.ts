export const MAP_BASEMAP_STYLE_PREFERENCES = [
  {
    id: 'fiord',
    label: 'Fiord',
    description: 'Dark OpenFreeMap style',
  },
  {
    id: 'positron',
    label: 'Positron',
    description: 'Light OpenFreeMap style',
  },
  {
    id: 'liberty',
    label: 'Liberty',
    description: 'Detailed OpenFreeMap style',
  },
  {
    id: 'bright',
    label: 'Bright',
    description: 'High-contrast OpenFreeMap style',
  },
] as const;

export type MapBasemapStylePreference = typeof MAP_BASEMAP_STYLE_PREFERENCES[number]['id'];
export type ConcreteMapBasemapStyle = MapBasemapStylePreference;

const STYLE_PREFERENCE_IDS = new Set<string>(
  MAP_BASEMAP_STYLE_PREFERENCES.map((option) => option.id),
);

export const DEFAULT_MAP_BASEMAP_STYLE_PREFERENCE: MapBasemapStylePreference = 'bright';

export function normalizeMapBasemapStylePreference(value: unknown): MapBasemapStylePreference {
  return typeof value === 'string' && STYLE_PREFERENCE_IDS.has(value)
    ? value as MapBasemapStylePreference
    : DEFAULT_MAP_BASEMAP_STYLE_PREFERENCE;
}

export function resolveMapBasemapStyle(
  preference: MapBasemapStylePreference,
): ConcreteMapBasemapStyle {
  return preference;
}

export function isDarkMapBasemapStyle(style: ConcreteMapBasemapStyle): boolean {
  return style === 'fiord';
}
