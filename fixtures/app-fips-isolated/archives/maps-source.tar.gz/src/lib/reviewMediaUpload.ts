import { cid, nhashEncode, streamUploadWithProgress, videoChunker } from '@hashtree/core';
import { getTree } from '../store';
import type { ReviewMedia } from '../stores/mapsTypes';
import { reviewMediaFromUrl } from './reviewMedia';

export interface ReviewMediaUploadProgress {
  fileName: string;
  bytes: number;
  totalBytes: number;
}

export async function uploadReviewMediaFile(
  file: File,
  onProgress?: (progress: ReviewMediaUploadProgress) => void,
): Promise<ReviewMedia> {
  if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
    throw new Error('Review media must be an image or video');
  }

  const tree = getTree();
  const chunker = file.type.startsWith('video/') ? videoChunker() : undefined;
  const stream = tree.createStream({ chunker });
  const result = await streamUploadWithProgress(
    file,
    {
      append: (chunk) => stream.append(chunk),
      finalize: () => stream.finalize(),
    },
    {
      onProgress: (progress) => {
        onProgress?.({
          fileName: file.name,
          bytes: progress.bytesProcessed,
          totalBytes: file.size,
        });
      },
    },
  );
  const nhash = nhashEncode(cid(result.hash, result.key));
  const url = `htree://${nhash}/${encodeURIComponent(file.name)}`;
  const parsed = reviewMediaFromUrl(url);
  if (!parsed) {
    throw new Error('Unsupported review media file type');
  }
  return {
    ...parsed,
    mimeType: file.type || parsed.mimeType,
    alt: file.name,
  };
}
