import type { ActivePlace } from '../stores/mapsTypes';

const LARGE_AREA_TYPES = new Set([
  'administrative',
  'continent',
  'country',
  'county',
  'province',
  'region',
  'state',
]);

const BASIC_PLACE_TYPES = new Set([
  'city',
  'hamlet',
  'locality',
  'municipality',
  'neighbourhood',
  'quarter',
  'suburb',
  'town',
  'village',
]);

const LARGE_AREA_CLASSES = new Set(['boundary']);

export function canPlaceHaveReviews(place: ActivePlace): boolean {
  if (place.source === 'place') return true;

  const type = (place.type ?? '').toLowerCase();
  const placeClass = (place.class ?? '').toLowerCase();

  return !LARGE_AREA_TYPES.has(type)
    && !BASIC_PLACE_TYPES.has(type)
    && !LARGE_AREA_CLASSES.has(placeClass);
}
