export type MapLabelKind = 'country' | 'city';

export interface MapLabel {
  name: string;
  lat: number;
  lng: number;
  kind: MapLabelKind;
  minZoom: number;
  maxZoom?: number;
  population?: number;
}

export interface MapLabelDataset {
  version: number;
  kind: 'iris-maps-labels';
  labels: MapLabel[];
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function normalizeLabel(value: unknown): MapLabel | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<MapLabel>;
  if (typeof record.name !== 'string' || !record.name.trim()) return null;
  if (!isFiniteNumber(record.lat) || !isFiniteNumber(record.lng)) return null;
  if (record.kind !== 'country' && record.kind !== 'city') return null;
  if (!isFiniteNumber(record.minZoom) || record.minZoom < 0) return null;
  const label: MapLabel = {
    name: record.name.trim(),
    lat: record.lat,
    lng: record.lng,
    kind: record.kind,
    minZoom: Math.floor(record.minZoom),
  };
  if (isFiniteNumber(record.maxZoom)) label.maxZoom = Math.floor(record.maxZoom);
  if (isFiniteNumber(record.population)) label.population = record.population;
  return label;
}

export async function fetchMapLabels(url: string): Promise<MapLabel[]> {
  const response = await fetch(url, { credentials: 'omit' });
  if (!response.ok) {
    throw new Error(`Failed to load map labels: ${response.status}`);
  }
  const data = await response.json() as Partial<MapLabelDataset>;
  if (data.kind !== 'iris-maps-labels' || !Array.isArray(data.labels)) {
    throw new Error('Invalid map labels dataset');
  }
  return data.labels
    .map(normalizeLabel)
    .filter((label): label is MapLabel => label !== null);
}
