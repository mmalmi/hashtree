import type { SavedPlaceListItemsSource } from './savedPlaceListManifest';

export interface SavedPlaceListSamplePageRequest {
  pageIndex: number;
  offsets: number[];
}

export interface SavedPlaceListSamplePageRequestOptions {
  limit: number;
  maxPages?: number;
  random?: () => number;
}

export function shuffleItems<T>(items: T[], random: () => number = Math.random): T[] {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

export function randomOrdinalsAcrossRange(
  total: number,
  limit: number,
  random: () => number = Math.random,
): number[] {
  const effectiveTotal = finiteCount(total);
  const effectiveLimit = Math.min(effectiveTotal, finiteCount(limit));
  if (effectiveTotal === 0 || effectiveLimit === 0) return [];
  if (effectiveLimit >= effectiveTotal) {
    return shuffleItems(Array.from({ length: effectiveTotal }, (_, index) => index), random);
  }

  const selected = new Set<number>();
  const bucketSize = effectiveTotal / effectiveLimit;
  for (let bucket = 0; bucket < effectiveLimit; bucket += 1) {
    selected.add(Math.min(effectiveTotal - 1, Math.floor((bucket + random()) * bucketSize)));
  }

  let attempts = 0;
  const maxAttempts = Math.max(effectiveLimit * 8, 32);
  while (selected.size < effectiveLimit && attempts < maxAttempts) {
    selected.add(Math.floor(random() * effectiveTotal));
    attempts += 1;
  }

  if (selected.size < effectiveLimit) {
    const start = Math.floor(random() * effectiveTotal);
    for (let offset = 0; offset < effectiveTotal && selected.size < effectiveLimit; offset += 1) {
      selected.add((start + offset) % effectiveTotal);
    }
  }

  return shuffleItems([...selected], random);
}

export function buildSavedPlaceListSamplePageRequests(
  source: SavedPlaceListItemsSource,
  options: SavedPlaceListSamplePageRequestOptions,
): SavedPlaceListSamplePageRequest[] {
  const totalCount = finiteCount(source.totalCount);
  const pageSize = Math.max(1, finiteCount(source.pageSize));
  const pageCount = Math.max(1, Math.min(finiteCount(source.pageCount), Math.ceil(totalCount / pageSize) || 1));
  const limit = Math.min(totalCount, finiteCount(options.limit));
  if (totalCount === 0 || limit === 0) return [];

  const maxPages = Math.max(1, finiteCount(options.maxPages ?? pageCount));
  const requestCount = Math.min(pageCount, maxPages, limit);
  const random = options.random ?? Math.random;
  const pageIndexes = randomOrdinalsAcrossRange(pageCount, requestCount, random)
    .sort((left, right) => left - right);
  const requests: SavedPlaceListSamplePageRequest[] = [];
  let remaining = limit;

  for (let index = 0; index < pageIndexes.length && remaining > 0; index += 1) {
    const pageIndex = pageIndexes[index];
    const pageItemCount = itemCountForPage(totalCount, pageSize, pageIndex);
    if (pageItemCount <= 0) continue;
    const remainingPages = pageIndexes.length - index;
    const offsetLimit = Math.min(pageItemCount, Math.ceil(remaining / remainingPages));
    const offsets = randomOrdinalsAcrossRange(pageItemCount, offsetLimit, random)
      .sort((left, right) => left - right);
    requests.push({ pageIndex, offsets });
    remaining -= offsets.length;
  }

  return requests;
}

function finiteCount(value: number): number {
  return Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
}

function itemCountForPage(totalCount: number, pageSize: number, pageIndex: number): number {
  const start = pageIndex * pageSize;
  if (start >= totalCount) return 0;
  return Math.min(pageSize, totalCount - start);
}
