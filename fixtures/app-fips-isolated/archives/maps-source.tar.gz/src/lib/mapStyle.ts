import type { StyleSpecification } from 'maplibre-gl';

type MutableLayer = StyleSpecification['layers'][number] & {
  id?: string;
  type?: string;
  minzoom?: number;
  maxzoom?: number;
  filter?: unknown;
  layout?: Record<string, unknown>;
  paint?: Record<string, unknown>;
  source?: string;
  'source-layer'?: string;
};

function expressionContains(value: unknown, needle: unknown): boolean {
  if (value === needle) return true;
  if (!Array.isArray(value)) return false;
  return value.some((part) => expressionContains(part, needle));
}

function isTextSymbolLayer(layer: MutableLayer): boolean {
  return layer.type === 'symbol'
    && !!layer.layout
    && !!layer.layout['text-field'];
}

function isVisibleLayer(layer: MutableLayer): boolean {
  return layer.layout?.visibility !== 'none';
}

function isNameBackedTextLayer(layer: MutableLayer): boolean {
  const textField = layer.layout?.['text-field'];
  return expressionContains(textField, 'name')
    || expressionContains(textField, 'name_en')
    || expressionContains(textField, 'name:latin')
    || expressionContains(textField, 'name:nonlatin');
}

function isGetClassExpression(value: unknown): boolean {
  return Array.isArray(value)
    && value[0] === 'get'
    && value[1] === 'class';
}

function classLabelIncludes(value: unknown, className: string): boolean {
  return value === className
    || (Array.isArray(value) && value.includes(className));
}

function filterPositivelyMatchesClass(filter: unknown, className: string): boolean {
  if (!Array.isArray(filter) || filter.length === 0) return false;
  const operator = filter[0];

  if (operator === '==' && isGetClassExpression(filter[1])) {
    return filter[2] === className;
  }

  if (operator === 'match' && isGetClassExpression(filter[1])) {
    for (let index = 2; index < filter.length - 1; index += 2) {
      if (classLabelIncludes(filter[index], className) && filter[index + 1] === true) {
        return true;
      }
    }
    return false;
  }

  if (operator === 'all' || operator === 'any') {
    return filter.slice(1).some((part) => filterPositivelyMatchesClass(part, className));
  }

  return false;
}

function isAdminSubdivisionLabelLayer(layer: MutableLayer): boolean {
  if (!isTextSymbolLayer(layer)) return false;
  if (layer['source-layer'] !== 'place') return false;
  const id = layer.id ?? '';
  return /(^|[_-])(state|province|region|admin)([_-]|$)/i.test(id)
    || filterPositivelyMatchesClass(layer.filter, 'state');
}

function isPlaceClassLabelLayer(layer: MutableLayer, className: string): boolean {
  if (!isTextSymbolLayer(layer)) return false;
  if (layer['source-layer'] !== 'place') return false;
  const id = layer.id ?? '';
  return new RegExp(`(^|[_-])${className}([_-]|$)`, 'i').test(id)
    || filterPositivelyMatchesClass(layer.filter, className);
}

export function useBundledFontAlias(style: StyleSpecification) {
  for (const layer of style.layers as MutableLayer[]) {
    if (!('layout' in layer) || !layer.layout) continue;
    const textFont = layer.layout['text-font'];
    if (!Array.isArray(textFont)) continue;
    layer.layout['text-font'] = ['Noto%20Sans%20Regular'];
  }
}

export function removeUnsupportedStyleImages(style: StyleSpecification) {
  for (const layer of style.layers as MutableLayer[]) {
    if (!('paint' in layer) || !layer.paint) continue;
    if (layer.paint['fill-pattern'] === 'wood-pattern') {
      delete layer.paint['fill-pattern'];
    }
  }
}

export function rebalancePlaceLabelHierarchy(style: StyleSpecification) {
  for (const layer of style.layers as MutableLayer[]) {
    if (!isTextSymbolLayer(layer)) continue;
    const isContinent = isPlaceClassLabelLayer(layer, 'continent');
    const isCountry = isPlaceClassLabelLayer(layer, 'country');
    const isCity = isPlaceClassLabelLayer(layer, 'city');
    const isTown = isPlaceClassLabelLayer(layer, 'town');
    const isVillage = isPlaceClassLabelLayer(layer, 'village');
    const isSuburb = isPlaceClassLabelLayer(layer, 'suburb');
    const id = layer.id ?? '';

    if (isContinent) {
      layer.layout = {
        ...layer.layout,
        'text-size': ['interpolate', ['linear'], ['zoom'], 0, 12, 3, 14, 5, 16],
      };
      continue;
    }

    if (isCountry) {
      const isMajor = /(^|[_-])(country_1|country_major)([_-]|$)/i.test(id)
        || expressionContains(layer.filter, 1);
      layer.layout = {
        ...layer.layout,
        'text-size': isMajor
          ? ['interpolate', ['linear'], ['zoom'], 0, 12, 2, 14, 4, 17, 6, 19]
          : ['interpolate', ['linear'], ['zoom'], 0, 10, 3, 12, 6, 16],
      };
      continue;
    }

    if (isCity) {
      layer.layout = {
        ...layer.layout,
        'text-size': /(^|[_-])(city_capital|city_large)([_-]|$)/i.test(id)
          ? ['interpolate', ['linear'], ['zoom'], 0, 8, 3, 10, 5, 12, 8, 16, 11, 20]
          : ['interpolate', ['linear'], ['zoom'], 0, 7, 3, 9, 5, 11, 8, 15, 11, 18],
      };
      continue;
    }

    if (isTown || isVillage || isSuburb) {
      layer.layout = {
        ...layer.layout,
        'text-size': ['interpolate', ['linear'], ['zoom'], 5, 9, 8, 11, 12, 14],
      };
    }
  }
}

export function hideAdministrativeSubdivisionLabels(style: StyleSpecification) {
  for (const layer of style.layers as MutableLayer[]) {
    if (!isAdminSubdivisionLabelLayer(layer)) continue;
    layer.layout = {
      ...layer.layout,
      visibility: 'none',
    };
  }
}

export function getInteractiveLabelLayerIds(style: StyleSpecification): string[] {
  return (style.layers as MutableLayer[])
    .filter((layer) => {
      if (!layer.id || !isTextSymbolLayer(layer) || !isVisibleLayer(layer)) return false;
      if (layer.source && layer.source !== 'openmaptiles') return false;
      return isNameBackedTextLayer(layer);
    })
    .map((layer) => layer.id as string);
}
