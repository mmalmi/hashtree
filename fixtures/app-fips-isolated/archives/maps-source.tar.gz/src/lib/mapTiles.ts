export const DEFAULT_MAP_TILE_OWNER_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
export const DEFAULT_MAP_TILE_TREE = 'maps-tiles-overview-v2';
export const DEFAULT_MAP_TILE_PATH_PREFIX = 'tiles';
export const DEFAULT_MAP_TILE_EXTENSION = 'png';
export const DEFAULT_MAP_TILE_MAX_NATIVE_ZOOM = 6;
export const DEFAULT_MAP_TILE_MAX_ZOOM = 16;
export const DEFAULT_MAP_TILE_SIZE = 256;
export const DEFAULT_MAP_TILE_ATTRIBUTION = 'Map tiles: Natural Earth + hashtree';
export const DEFAULT_MAP_TILE_GATEWAY_BASE_URL = 'https://cdn.iris.to';
export const DEFAULT_MAP_TILE_LAYER_ID = 'lowres';
export const DEFAULT_MAP_TILE_DETAIL_TREE = '';
export const DEFAULT_MAP_TILE_DETAIL_LAYER_ID = 'helsinki-detail';
export const DEFAULT_MAP_TILE_DETAIL_MIN_ZOOM = 9;
export const DEFAULT_MAP_TILE_DETAIL_MAX_NATIVE_ZOOM = 14;
export const DEFAULT_MAP_TILE_DETAIL_MAX_ZOOM = 16;
export const DEFAULT_MAP_TILE_DETAIL_BOUNDS = '60.05,24.75,60.33,25.2';
export const DEFAULT_MAP_TILE_DETAIL_ATTRIBUTION = 'Map details: OpenStreetMap contributors + hashtree';
export const DEFAULT_MAP_TILE_TRANSPORT = 'htree';

type MapTileEnv = Record<string, string | boolean | undefined>;
type MapTileTransport = 'htree' | 'gateway';

export interface MutableHtreeTileTemplateOptions {
  npub?: string;
  treeName?: string;
  pathPrefix?: string;
  extension?: string;
  baseUrl?: string;
  htreePath?: boolean;
}

export interface MapTileConfig {
  layers: MapTileLayerConfig[];
  urlTemplate: string;
  attribution: string;
  minZoom: number;
  maxNativeZoom: number;
  maxZoom: number;
  tileSize: number;
}

export interface MapTileLayerConfig {
  id: string;
  urlTemplate: string;
  attribution: string;
  bounds?: MapTileBounds;
  minZoom: number;
  maxNativeZoom: number;
  maxZoom: number;
  tileSize: number;
}

export type MapTileBounds = [[number, number], [number, number]];

function envString(env: MapTileEnv, key: string): string | null {
  const value = env[key];
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return trimmed || null;
}

function positiveInt(value: string | null, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return fallback;
  return parsed;
}

function nonNegativeInt(value: string | null, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) return fallback;
  return parsed;
}

function parseBounds(value: string | null): MapTileBounds | undefined {
  if (!value) return undefined;
  const parts = value.split(',').map((part) => Number(part.trim()));
  if (parts.length !== 4 || parts.some((part) => !Number.isFinite(part))) {
    return undefined;
  }
  const [south, west, north, east] = parts;
  if (south < -90 || north > 90 || west < -180 || east > 180 || south > north) {
    return undefined;
  }
  return [[south, west], [north, east]];
}

function cleanPathPrefix(pathPrefix: string): string {
  return pathPrefix
    .split('/')
    .map((part) => part.trim())
    .filter(Boolean)
    .join('/');
}

function encodeTemplatePath(pathPrefix: string, extension: string): string {
  const encodedPrefix = cleanPathPrefix(pathPrefix)
    .split('/')
    .filter(Boolean)
    .map(encodeURIComponent)
    .join('/');
  const prefix = encodedPrefix ? `${encodedPrefix}/` : '';
  const cleanExtension = extension.trim().replace(/^\.+/, '') || DEFAULT_MAP_TILE_EXTENSION;
  return `${prefix}{z}/{x}/{y}.${cleanExtension}`;
}

export function buildMutableHtreeTileTemplate(options: MutableHtreeTileTemplateOptions = {}): string {
  const npub = options.npub ?? DEFAULT_MAP_TILE_OWNER_NPUB;
  const treeName = options.treeName ?? DEFAULT_MAP_TILE_TREE;
  const tilePath = encodeTemplatePath(
    options.pathPrefix ?? DEFAULT_MAP_TILE_PATH_PREFIX,
    options.extension ?? DEFAULT_MAP_TILE_EXTENSION,
  );
  const encodedTreeName = encodeURIComponent(treeName);

  if (options.htreePath) {
    return `/htree/${npub}/${encodedTreeName}/${tilePath}`;
  }

  const baseUrl = (options.baseUrl ?? DEFAULT_MAP_TILE_GATEWAY_BASE_URL).replace(/\/+$/, '');
  return `${baseUrl}/${npub}/${encodedTreeName}/${tilePath}`;
}

function normalizeLayerZooms(options: {
  minZoom: number;
  maxNativeZoom: number;
  maxZoom: number;
}) {
  const minZoom = Math.max(0, options.minZoom);
  const maxNativeZoom = Math.max(minZoom, options.maxNativeZoom);
  const maxZoom = Math.max(maxNativeZoom, options.maxZoom);
  return { minZoom, maxNativeZoom, maxZoom };
}

function buildDetailLayerTemplate(env: MapTileEnv): string | null {
  const detailTemplate = envString(env, 'VITE_MAP_TILE_DETAIL_URL_TEMPLATE');
  if (detailTemplate) return detailTemplate;

  const detailTree = envString(env, 'VITE_MAP_TILE_DETAIL_TREE') ?? DEFAULT_MAP_TILE_DETAIL_TREE;
  if (!detailTree) return null;

  return buildMutableHtreeTileTemplate({
    npub: envString(env, 'VITE_MAP_TILE_DETAIL_OWNER_NPUB')
      ?? envString(env, 'VITE_MAP_TILE_OWNER_NPUB')
      ?? DEFAULT_MAP_TILE_OWNER_NPUB,
    treeName: detailTree,
    pathPrefix: envString(env, 'VITE_MAP_TILE_DETAIL_PATH_PREFIX') ?? DEFAULT_MAP_TILE_PATH_PREFIX,
    extension: envString(env, 'VITE_MAP_TILE_DETAIL_EXTENSION') ?? DEFAULT_MAP_TILE_EXTENSION,
    baseUrl: envString(env, 'VITE_MAP_TILE_DETAIL_GATEWAY_BASE_URL')
      ?? envString(env, 'VITE_MAP_TILE_GATEWAY_BASE_URL')
      ?? DEFAULT_MAP_TILE_GATEWAY_BASE_URL,
    htreePath: getTileTransport(env) === 'htree',
  });
}

function getTileTransport(env: MapTileEnv): MapTileTransport {
  return envString(env, 'VITE_MAP_TILE_TRANSPORT') === 'gateway' ? 'gateway' : DEFAULT_MAP_TILE_TRANSPORT;
}

export function createMapTileConfig(env: MapTileEnv = import.meta.env): MapTileConfig {
  const tileTransport = getTileTransport(env);
  const urlTemplate = envString(env, 'VITE_MAP_TILE_URL_TEMPLATE') ?? buildMutableHtreeTileTemplate({
    npub: envString(env, 'VITE_MAP_TILE_OWNER_NPUB') ?? DEFAULT_MAP_TILE_OWNER_NPUB,
    treeName: envString(env, 'VITE_MAP_TILE_TREE') ?? DEFAULT_MAP_TILE_TREE,
    pathPrefix: envString(env, 'VITE_MAP_TILE_PATH_PREFIX') ?? DEFAULT_MAP_TILE_PATH_PREFIX,
    extension: envString(env, 'VITE_MAP_TILE_EXTENSION') ?? DEFAULT_MAP_TILE_EXTENSION,
    baseUrl: envString(env, 'VITE_MAP_TILE_GATEWAY_BASE_URL') ?? DEFAULT_MAP_TILE_GATEWAY_BASE_URL,
    htreePath: tileTransport === 'htree',
  });

  const maxNativeZoom = nonNegativeInt(
    envString(env, 'VITE_MAP_TILE_MAX_NATIVE_ZOOM'),
    DEFAULT_MAP_TILE_MAX_NATIVE_ZOOM,
  );
  const baseZooms = normalizeLayerZooms({
    minZoom: nonNegativeInt(envString(env, 'VITE_MAP_TILE_MIN_ZOOM'), 0),
    maxNativeZoom,
    maxZoom: nonNegativeInt(envString(env, 'VITE_MAP_TILE_MAX_ZOOM'), DEFAULT_MAP_TILE_MAX_ZOOM),
  });
  const tileSize = positiveInt(envString(env, 'VITE_MAP_TILE_SIZE'), DEFAULT_MAP_TILE_SIZE);
  const attribution = envString(env, 'VITE_MAP_TILE_ATTRIBUTION') ?? DEFAULT_MAP_TILE_ATTRIBUTION;
  const baseBounds = parseBounds(envString(env, 'VITE_MAP_TILE_BOUNDS'));

  const layers: MapTileLayerConfig[] = [{
    id: envString(env, 'VITE_MAP_TILE_LAYER_ID') ?? DEFAULT_MAP_TILE_LAYER_ID,
    urlTemplate,
    attribution,
    ...(baseBounds ? { bounds: baseBounds } : {}),
    tileSize,
    ...baseZooms,
  }];

  const detailTemplate = buildDetailLayerTemplate(env);
  if (detailTemplate) {
    const detailMaxNativeZoom = nonNegativeInt(
      envString(env, 'VITE_MAP_TILE_DETAIL_MAX_NATIVE_ZOOM'),
      DEFAULT_MAP_TILE_DETAIL_MAX_NATIVE_ZOOM,
    );
    const detailBounds = parseBounds(envString(env, 'VITE_MAP_TILE_DETAIL_BOUNDS') ?? DEFAULT_MAP_TILE_DETAIL_BOUNDS);
    layers.push({
      id: envString(env, 'VITE_MAP_TILE_DETAIL_LAYER_ID') ?? DEFAULT_MAP_TILE_DETAIL_LAYER_ID,
      urlTemplate: detailTemplate,
      attribution: envString(env, 'VITE_MAP_TILE_DETAIL_ATTRIBUTION') ?? DEFAULT_MAP_TILE_DETAIL_ATTRIBUTION,
      ...(detailBounds ? { bounds: detailBounds } : {}),
      tileSize: positiveInt(envString(env, 'VITE_MAP_TILE_DETAIL_TILE_SIZE'), tileSize),
      ...normalizeLayerZooms({
        minZoom: nonNegativeInt(envString(env, 'VITE_MAP_TILE_DETAIL_MIN_ZOOM'), DEFAULT_MAP_TILE_DETAIL_MIN_ZOOM),
        maxNativeZoom: detailMaxNativeZoom,
        maxZoom: nonNegativeInt(envString(env, 'VITE_MAP_TILE_DETAIL_MAX_ZOOM'), DEFAULT_MAP_TILE_DETAIL_MAX_ZOOM),
      }),
    });
  }

  const mapMaxZoom = Math.max(...layers.map((layer) => layer.maxZoom));
  const mapMinZoom = Math.min(...layers.map((layer) => layer.minZoom));

  return {
    layers,
    urlTemplate,
    attribution,
    minZoom: mapMinZoom,
    maxNativeZoom: baseZooms.maxNativeZoom,
    maxZoom: mapMaxZoom,
    tileSize,
  };
}
