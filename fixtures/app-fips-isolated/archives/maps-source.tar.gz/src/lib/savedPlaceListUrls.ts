import { savedPlaceListManifestPath } from './savedPlaceListManifest.ts';

export interface SavedPlaceListUrls {
  appPath: string;
  web: string;
  htree: string;
  data: string;
  htreeData: string;
}

export interface SavedPlaceListUrlInput {
  listId: string;
  ownerNpub: string;
  treeName?: string;
  dataPath?: string;
}

const DEFAULT_PUBLIC_LIST_TREE = 'maps';
const DISTRIBUTED_APP_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
const MAPS_WEB_APP_URL = 'https://maps.iris.to';
const MAPS_HTREE_APP_URL = `htree://${DISTRIBUTED_APP_OWNER}/maps`;

export function buildSavedPlaceListAppPath(input: SavedPlaceListUrlInput): string {
  const params = new URLSearchParams({
    list: input.listId,
    owner: input.ownerNpub,
    tree: input.treeName ?? DEFAULT_PUBLIC_LIST_TREE,
  });
  return `/?${params.toString()}`;
}

export function buildSavedPlaceListUrls(input: SavedPlaceListUrlInput): SavedPlaceListUrls {
  const treeName = input.treeName ?? DEFAULT_PUBLIC_LIST_TREE;
  const dataPath = input.dataPath ?? savedPlaceListManifestPath(input.listId);
  const appPath = buildSavedPlaceListAppPath({ ...input, treeName, dataPath });
  const dataQuery = new URLSearchParams({ list: input.listId }).toString();
  const encodedTreeName = encodeURIComponent(treeName);
  const encodedDataPath = encodePath(dataPath);
  return {
    appPath,
    web: `${MAPS_WEB_APP_URL}/#${appPath}`,
    htree: `${MAPS_HTREE_APP_URL}#${appPath}`,
    data: `/htree/${encodeURIComponent(input.ownerNpub)}/${encodedTreeName}/${encodedDataPath}?${dataQuery}`,
    htreeData: `htree://${input.ownerNpub}/${encodedTreeName}/${encodedDataPath}?${dataQuery}`,
  };
}

export function normalizeSavedPlaceListUrls(value: unknown): SavedPlaceListUrls | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const record = value as Partial<SavedPlaceListUrls>;
  const appPath = cleanUrlText(record.appPath);
  const web = cleanUrlText(record.web);
  const htree = cleanUrlText(record.htree);
  const data = cleanUrlText(record.data);
  const htreeData = cleanUrlText(record.htreeData);
  if (!appPath || !web || !htree || !data || !htreeData) return undefined;
  return {
    appPath,
    web,
    htree,
    data,
    htreeData,
  };
}

function encodePath(path: string): string {
  return path
    .split('/')
    .map((part) => part.trim())
    .filter(Boolean)
    .map(encodeURIComponent)
    .join('/');
}

function cleanUrlText(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}
