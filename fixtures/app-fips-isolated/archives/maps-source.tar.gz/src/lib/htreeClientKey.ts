export function getCurrentHtreeClientKey(search = currentLocationSearch()): string {
  try {
    return new URLSearchParams(search).get('htree_c')?.trim() ?? '';
  } catch {
    return '';
  }
}

export function withHtreeClientKey(url: string, clientKey = getCurrentHtreeClientKey()): string {
  const key = clientKey.trim();
  if (!key || !isSameOriginHtreeUrl(url) || hasQueryParam(url, 'htree_c')) {
    return url;
  }

  const hashIndex = url.indexOf('#');
  const beforeHash = hashIndex >= 0 ? url.slice(0, hashIndex) : url;
  const hash = hashIndex >= 0 ? url.slice(hashIndex) : '';
  const separator = beforeHash.includes('?') ? '&' : '?';
  return `${beforeHash}${separator}htree_c=${encodeURIComponent(key)}${hash}`;
}

function currentLocationSearch(): string {
  return typeof window === 'undefined' ? '' : window.location.search;
}

function hasQueryParam(url: string, param: string): boolean {
  const queryIndex = url.indexOf('?');
  if (queryIndex < 0) return false;
  const hashIndex = url.indexOf('#', queryIndex);
  const query = url.slice(queryIndex + 1, hashIndex >= 0 ? hashIndex : undefined);
  return new URLSearchParams(query).has(param);
}

function isSameOriginHtreeUrl(url: string): boolean {
  if (url.startsWith('/htree/')) return true;
  if (!/^https?:\/\//.test(url) || typeof window === 'undefined') return false;

  try {
    const parsed = new URL(url);
    return parsed.origin === window.location.origin && parsed.pathname.startsWith('/htree/');
  } catch {
    return false;
  }
}
