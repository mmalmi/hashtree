import type { ConcreteMapBasemapStyle } from './mapStylePreference';

export const DEFAULT_MAP_BASEMAP_OWNER_NPUB = 'npub1t5t66e523nppvsz2sj8yzp3dvg598x2cswsecaj0029ea5xh4gcq2c0n4h';
export const DEFAULT_MAP_BASEMAP_TREE = 'maps-openfreemap-world-z14-v1';
export const DEFAULT_MAP_BASEMAP_ROOT_NHASH = 'nhash1qqs92rt6kceh2c6avycdtuz7hq85cwe4qtpda4nnc6hlqea7qr7q37q9ypjd69kurnrr30phtdzmr55kv3sglk0ygqmxae8qulprprr054hmvf6mefu';
export const DEFAULT_MAP_BASEMAP_PMTILES_PATH = 'tiles.pmtiles';
export const DEFAULT_MAP_BASEMAP_LIGHT_STYLE_PATH = 'ofm/positron.json';
export const DEFAULT_MAP_BASEMAP_DARK_STYLE_PATH = 'ofm/fiord.json';
export const DEFAULT_MAP_BASEMAP_LIBERTY_STYLE_PATH = 'ofm/liberty.json';
export const DEFAULT_MAP_BASEMAP_BRIGHT_STYLE_PATH = 'ofm/bright.json';
export const DEFAULT_MAP_BASEMAP_GLYPHS_OWNER_NPUB = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';
export const DEFAULT_MAP_BASEMAP_GLYPHS_TREE = 'maps-openfreemap-glyphs-v1';
export const DEFAULT_MAP_BASEMAP_GLYPHS_ROOT_NHASH = 'nhash1qqs9zhlzv0azn0e5eqty7kaa5hlrhksqrrdthyj45kyhvzgvz4wk59gqdqqhk';
export const DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL = 'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf';
export const DEFAULT_MAP_BASEMAP_GLYPHS_PATH = 'ofm/{fontstack}/{range}.pbf';
export const DEFAULT_MAP_BASEMAP_GLYPHS_VERSION = '20260617';
export const DEFAULT_MAP_BASEMAP_PMTILES_VERSION = '20260618-htree';
export const DEFAULT_MAP_BASEMAP_SPRITE_PATH = 'ofm_f384/ofm';
export const DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL = 'https://cdn.iris.to';
export const DEFAULT_MAP_BASEMAP_MIN_ZOOM = 0;
export const DEFAULT_MAP_BASEMAP_MAX_NATIVE_ZOOM = 14;
export const DEFAULT_MAP_BASEMAP_MAX_ZOOM = 18;
export const DEFAULT_MAP_BASEMAP_ATTRIBUTION = 'OpenFreeMap, OpenMapTiles, OpenStreetMap contributors + hashtree';
export const DEFAULT_MAP_BASEMAP_TRANSPORT = 'htree';

type MapBasemapEnv = Record<string, string | boolean | undefined>;
type ResolvedMapBasemapTransport = 'htree' | 'gateway';

export interface MapBasemapConfig {
  ownerNpub: string;
  treeName: string;
  pmtilesUrl: string;
  lightStyleUrl: string;
  darkStyleUrl: string;
  styleUrls: Record<ConcreteMapBasemapStyle, string>;
  glyphsUrl: string;
  spriteUrl: string;
  attribution: string;
  minZoom: number;
  maxNativeZoom: number;
  maxZoom: number;
}

function envString(env: MapBasemapEnv, key: string): string | null {
  const value = env[key];
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return trimmed || null;
}

function nonNegativeInt(value: string | null, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) return fallback;
  return parsed;
}

function cleanPath(path: string): string {
  return path
    .split('/')
    .map((part) => part.trim())
    .filter(Boolean)
    .join('/');
}

function encodeDatasetPath(path: string): string {
  return cleanPath(path)
    .split('/')
    .map((part) => encodeURIComponent(part).replace(/%7B/gi, '{').replace(/%7D/gi, '}'))
    .join('/');
}

function getTransport(env: MapBasemapEnv): ResolvedMapBasemapTransport {
  return envString(env, 'VITE_MAP_BASEMAP_TRANSPORT') === 'gateway' ? 'gateway' : 'htree';
}

function getPmtilesTransport(
  env: MapBasemapEnv,
  fallback: ResolvedMapBasemapTransport,
): ResolvedMapBasemapTransport {
  const transport = envString(env, 'VITE_MAP_BASEMAP_PMTILES_TRANSPORT');
  return transport === 'htree' || transport === 'gateway' ? transport : fallback;
}

function appendQueryParam(url: string, key: string, value: string): string {
  if (!value) return url;
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
}

export function buildMutableHtreeBasemapUrl(options: {
  ownerNpub?: string;
  treeName?: string;
  path: string;
  baseUrl?: string;
  htreePath?: boolean;
}): string {
  const ownerNpub = options.ownerNpub ?? DEFAULT_MAP_BASEMAP_OWNER_NPUB;
  const rawTreeName = options.treeName ?? DEFAULT_MAP_BASEMAP_TREE;
  const treeName = encodeURIComponent(rawTreeName);
  const filePath = encodeDatasetPath(options.path);

  if (options.htreePath) {
    return `/htree/${ownerNpub}/${treeName}/${filePath}`;
  }

  const baseUrl = (options.baseUrl ?? DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL).replace(/\/+$/, '');
  return `${baseUrl}/${ownerNpub}/${treeName}/${filePath}`;
}

export function buildImmutableHtreeBasemapUrl(options: {
  nhash: string;
  path: string;
  baseUrl?: string;
  htreePath?: boolean;
}): string {
  const filePath = encodeDatasetPath(options.path);

  if (options.htreePath) {
    return `/htree/${options.nhash}/${filePath}`;
  }

  const baseUrl = (options.baseUrl ?? DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL).replace(/\/+$/, '');
  return `${baseUrl}/${options.nhash}/${filePath}`;
}

export function createMapBasemapConfig(env: MapBasemapEnv = import.meta.env): MapBasemapConfig {
  const ownerOverride = envString(env, 'VITE_MAP_BASEMAP_OWNER_NPUB');
  const treeOverride = envString(env, 'VITE_MAP_BASEMAP_TREE');
  const ownerNpub = ownerOverride ?? DEFAULT_MAP_BASEMAP_OWNER_NPUB;
  const treeName = treeOverride ?? DEFAULT_MAP_BASEMAP_TREE;
  const rootOverride = envString(env, 'VITE_MAP_BASEMAP_ROOT_NHASH');
  const rootNhash = rootOverride ?? (ownerOverride || treeOverride ? null : DEFAULT_MAP_BASEMAP_ROOT_NHASH);
  const glyphsOwnerOverride = envString(env, 'VITE_MAP_BASEMAP_GLYPHS_OWNER_NPUB');
  const glyphsTreeOverride = envString(env, 'VITE_MAP_BASEMAP_GLYPHS_TREE');
  const glyphsOwnerNpub = glyphsOwnerOverride ?? DEFAULT_MAP_BASEMAP_GLYPHS_OWNER_NPUB;
  const glyphsTreeName = glyphsTreeOverride ?? DEFAULT_MAP_BASEMAP_GLYPHS_TREE;
  const glyphsRootNhash = envString(env, 'VITE_MAP_BASEMAP_GLYPHS_ROOT_NHASH');
  const hasGlyphsDatasetOverride = !!(glyphsOwnerOverride || glyphsTreeOverride || glyphsRootNhash);
  const baseUrl = envString(env, 'VITE_MAP_BASEMAP_GATEWAY_BASE_URL') ?? DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL;
  const transport = getTransport(env);
  const htreePath = transport === 'htree';
  const pmtilesHtreePath = getPmtilesTransport(env, transport) === 'htree';

  // Pin an archive revision so ranges cannot mix updates; the worker's existing
  // block store also keeps these immutable files available after an offline reload.
  const urlFor = (path: string, viaHtree = htreePath) => rootNhash && (viaHtree || rootOverride)
    ? buildImmutableHtreeBasemapUrl({ nhash: rootNhash, path, baseUrl, htreePath: viaHtree })
    : buildMutableHtreeBasemapUrl({ ownerNpub, treeName, path, baseUrl, htreePath: viaHtree });
  const glyphsUrlFor = (path: string) => buildMutableHtreeBasemapUrl({
    ownerNpub: glyphsOwnerNpub,
    treeName: glyphsTreeName,
    path,
    baseUrl,
    htreePath,
  });
  const immutableGlyphsUrlFor = (path: string) => buildImmutableHtreeBasemapUrl({
    nhash: glyphsRootNhash ?? '',
    path,
    baseUrl,
    htreePath,
  });

  const maxNativeZoom = nonNegativeInt(
    envString(env, 'VITE_MAP_BASEMAP_MAX_NATIVE_ZOOM'),
    DEFAULT_MAP_BASEMAP_MAX_NATIVE_ZOOM,
  );
  const maxZoom = Math.max(
    maxNativeZoom,
    nonNegativeInt(envString(env, 'VITE_MAP_BASEMAP_MAX_ZOOM'), DEFAULT_MAP_BASEMAP_MAX_ZOOM),
  );

  const glyphsOverride = envString(env, 'VITE_MAP_BASEMAP_GLYPHS_URL');
  const glyphsVersion = envString(env, 'VITE_MAP_BASEMAP_GLYPHS_VERSION') ?? DEFAULT_MAP_BASEMAP_GLYPHS_VERSION;
  const pmtilesVersion = envString(env, 'VITE_MAP_BASEMAP_PMTILES_VERSION') ?? DEFAULT_MAP_BASEMAP_PMTILES_VERSION;
  const fiordStyleUrl = envString(env, 'VITE_MAP_BASEMAP_FIORD_STYLE_URL')
    ?? envString(env, 'VITE_MAP_BASEMAP_DARK_STYLE_URL')
    ?? urlFor(envString(env, 'VITE_MAP_BASEMAP_FIORD_STYLE_PATH') ?? DEFAULT_MAP_BASEMAP_DARK_STYLE_PATH);
  const positronStyleUrl = envString(env, 'VITE_MAP_BASEMAP_POSITRON_STYLE_URL')
    ?? envString(env, 'VITE_MAP_BASEMAP_LIGHT_STYLE_URL')
    ?? urlFor(envString(env, 'VITE_MAP_BASEMAP_POSITRON_STYLE_PATH') ?? DEFAULT_MAP_BASEMAP_LIGHT_STYLE_PATH);
  const libertyStyleUrl = envString(env, 'VITE_MAP_BASEMAP_LIBERTY_STYLE_URL')
    ?? urlFor(envString(env, 'VITE_MAP_BASEMAP_LIBERTY_STYLE_PATH') ?? DEFAULT_MAP_BASEMAP_LIBERTY_STYLE_PATH);
  const brightStyleUrl = envString(env, 'VITE_MAP_BASEMAP_BRIGHT_STYLE_URL')
    ?? urlFor(envString(env, 'VITE_MAP_BASEMAP_BRIGHT_STYLE_PATH') ?? DEFAULT_MAP_BASEMAP_BRIGHT_STYLE_PATH);

  return {
    ownerNpub,
    treeName,
    pmtilesUrl: envString(env, 'VITE_MAP_BASEMAP_PMTILES_URL')
      ?? appendQueryParam(
        urlFor(envString(env, 'VITE_MAP_BASEMAP_PMTILES_PATH') ?? DEFAULT_MAP_BASEMAP_PMTILES_PATH, pmtilesHtreePath),
        'v',
        pmtilesVersion,
      ),
    lightStyleUrl: positronStyleUrl,
    darkStyleUrl: fiordStyleUrl,
    styleUrls: {
      fiord: fiordStyleUrl,
      positron: positronStyleUrl,
      liberty: libertyStyleUrl,
      bright: brightStyleUrl,
    },
    glyphsUrl: glyphsOverride
      ?? appendQueryParam(
        hasGlyphsDatasetOverride
          ? glyphsRootNhash
            ? immutableGlyphsUrlFor(envString(env, 'VITE_MAP_BASEMAP_GLYPHS_PATH') ?? DEFAULT_MAP_BASEMAP_GLYPHS_PATH)
            : glyphsUrlFor(envString(env, 'VITE_MAP_BASEMAP_GLYPHS_PATH') ?? DEFAULT_MAP_BASEMAP_GLYPHS_PATH)
          : DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL,
        'v',
        glyphsVersion,
      ),
    spriteUrl: envString(env, 'VITE_MAP_BASEMAP_SPRITE_URL')
      ?? urlFor(envString(env, 'VITE_MAP_BASEMAP_SPRITE_PATH') ?? DEFAULT_MAP_BASEMAP_SPRITE_PATH),
    attribution: envString(env, 'VITE_MAP_BASEMAP_ATTRIBUTION') ?? DEFAULT_MAP_BASEMAP_ATTRIBUTION,
    minZoom: nonNegativeInt(envString(env, 'VITE_MAP_BASEMAP_MIN_ZOOM'), DEFAULT_MAP_BASEMAP_MIN_ZOOM),
    maxNativeZoom,
    maxZoom,
  };
}
