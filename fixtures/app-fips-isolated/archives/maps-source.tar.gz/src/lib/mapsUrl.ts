import type { ActivePlace, SearchResult } from '../stores/mapsStore.svelte';
import { getQueryParamsFromHash } from './router.svelte';

const MAPS_WEB_HOSTS = new Set(['maps.iris.to']);
const LOCAL_APP_HOSTS = new Set(['localhost', '127.0.0.1', '[::1]', '::1']);
const MAPS_HTREE_APP_OWNER = 'npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm';

type PlaceLike = Pick<
  ActivePlace,
  | 'id'
  | 'name'
  | 'lat'
  | 'lng'
  | 'type'
  | 'class'
  | 'displayName'
  | 'context'
  | 'contextParts'
  | 'boundingBox'
  | 'placeRank'
  | 'sourceLayer'
  | 'sourceZoom'
  | 'sourceId'
  | 'sourceTile'
  | 'details'
>;

export interface SavedPlaceListRoute {
  listId: string;
  ownerNpub: string;
  treeName: string;
}

export function internalMapsRouteFromInput(value: string, currentOrigin?: string): string | null {
  const trimmed = value.trim();
  if (!trimmed) return null;

  const directRoute = routeFromHashOrPath(trimmed);
  if (directRoute && isMapsDeepLinkRoute(directRoute)) {
    return directRoute;
  }

  const url = parseInputUrl(trimmed);
  if (!url || !isKnownMapsAppUrl(url, currentOrigin)) return null;

  if (url.hash) {
    const route = normalizeHashRoute(url.hash);
    if (route && isMapsDeepLinkRoute(route)) return route;
  }

  const route = normalizeHashRoute(`${url.pathname}${url.search}`);
  return route && isMapsDeepLinkRoute(route) ? route : null;
}

export function parseSavedPlaceListRouteFromHash(hash: string): SavedPlaceListRoute | null {
  const params = getQueryParamsFromHash(hash);
  const listId = cleanParam(params.get('list'));
  const ownerNpub = cleanParam(params.get('owner'));
  const treeName = cleanParam(params.get('tree')) ?? 'maps';
  if (!listId || !ownerNpub || !treeName) return null;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(listId)) return null;
  if (!ownerNpub.startsWith('npub1')) return null;
  return {
    listId: listId.toLowerCase(),
    ownerNpub,
    treeName,
  };
}

export function parseActivePlaceFromHash(hash: string): ActivePlace | null {
  const placeParam = getQueryParamsFromHash(hash).get('place');
  if (!placeParam) return null;
  try {
    const parsed = JSON.parse(placeParam) as PlaceLike;
    if (typeof parsed.lat !== 'number' || typeof parsed.lng !== 'number' || !parsed.name) {
      return null;
    }
    return {
      id: typeof parsed.id === 'string' ? parsed.id : undefined,
      name: parsed.name,
      lat: parsed.lat,
      lng: parsed.lng,
      type: parsed.type,
      class: parsed.class,
      displayName: parsed.displayName,
      context: typeof parsed.context === 'string' ? parsed.context : undefined,
      contextParts: Array.isArray(parsed.contextParts) ? parsed.contextParts : undefined,
      boundingBox: Array.isArray(parsed.boundingBox) && parsed.boundingBox.length === 4
        ? parsed.boundingBox
        : undefined,
      placeRank: typeof parsed.placeRank === 'number' ? parsed.placeRank : undefined,
      sourceLayer: typeof parsed.sourceLayer === 'string' ? parsed.sourceLayer : undefined,
      sourceZoom: typeof parsed.sourceZoom === 'number' ? parsed.sourceZoom : undefined,
      sourceId: typeof parsed.sourceId === 'string' ? parsed.sourceId : undefined,
      sourceTile: Array.isArray(parsed.sourceTile) && parsed.sourceTile.length === 2
        ? parsed.sourceTile
        : undefined,
      details: parsed.details,
      source: 'search',
    };
  } catch {
    return null;
  }
}

export function setActivePlaceInHash(place: SearchResult | PlaceLike | null) {
  const hash = window.location.hash.slice(1) || '/';
  const [path] = hash.split('?');
  const params = getQueryParamsFromHash(hash);
  if (place) {
    params.set('place', JSON.stringify({
      id: place.id,
      name: place.name,
      lat: place.lat,
      lng: place.lng,
      type: place.type,
      class: place.class,
      displayName: place.displayName,
      context: place.context,
      contextParts: place.contextParts,
      boundingBox: place.boundingBox,
      placeRank: place.placeRank,
      sourceLayer: place.sourceLayer,
      sourceZoom: place.sourceZoom,
      sourceId: place.sourceId,
      sourceTile: place.sourceTile,
      details: 'details' in place ? place.details : undefined,
    }));
  } else {
    params.delete('place');
  }
  const nextHash = params.toString() ? `${path}?${params.toString()}` : path;
  if (window.location.hash.slice(1) !== nextHash) {
    window.location.hash = `#${nextHash}`;
  }
}

function routeFromHashOrPath(value: string): string | null {
  if (value.startsWith('#')) return normalizeHashRoute(value);
  if (value.startsWith('/')) return normalizeHashRoute(value);
  if (value.startsWith('?')) return normalizeHashRoute(`/${value}`);
  return null;
}

function normalizeHashRoute(value: string): string | null {
  const withoutHash = value.startsWith('#') ? value.slice(1) : value;
  if (!withoutHash) return null;
  if (withoutHash.startsWith('/')) return withoutHash;
  if (withoutHash.startsWith('?')) return `/${withoutHash}`;
  return `/${withoutHash}`;
}

function isMapsDeepLinkRoute(route: string): boolean {
  const params = getQueryParamsFromHash(route);
  if (params.get('place')) return true;
  return Boolean(params.get('list') && params.get('owner'));
}

function cleanParam(value: string | null): string | null {
  const trimmed = value?.trim();
  return trimmed || null;
}

function parseInputUrl(value: string): URL | null {
  try {
    if (/^[a-z][a-z\d+.-]*:\/\//i.test(value)) {
      return new URL(value);
    }
    if (/^(?:maps\.iris\.to|localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(?:[/?#]|$)/i.test(value)) {
      return new URL(`http://${value}`);
    }
  } catch {
    return null;
  }
  return null;
}

function isKnownMapsAppUrl(url: URL, currentOrigin?: string): boolean {
  if (url.protocol === 'htree:') {
    return url.hostname === MAPS_HTREE_APP_OWNER && url.pathname.replace(/\/+$/, '') === '/maps';
  }

  if (url.protocol !== 'http:' && url.protocol !== 'https:') return false;
  if (MAPS_WEB_HOSTS.has(url.hostname)) return true;
  if (LOCAL_APP_HOSTS.has(url.hostname)) return true;

  if (!currentOrigin && typeof window !== 'undefined') {
    currentOrigin = window.location.origin;
  }
  if (!currentOrigin) return false;

  try {
    return url.origin === new URL(currentOrigin).origin;
  } catch {
    return false;
  }
}
