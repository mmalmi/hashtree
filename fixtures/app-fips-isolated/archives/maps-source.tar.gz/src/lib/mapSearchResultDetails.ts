import type { SearchResult } from '../stores/mapsTypes';
import { normalizeMapSearchText } from './mapSearchText';

const GENERIC_RESULT_LABELS = new Set([
  'address',
  'boundary',
  'building',
  'city',
  'country',
  'house',
  'place',
  'poi',
  'road',
  'state',
  'street',
]);

export function titleCase(value: string): string {
  return value
    .replace(/[_-]+/g, ' ')
    .trim()
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

export function normalizeLabel(value: string | undefined): string {
  return normalizeMapSearchText(value ?? '');
}

export function formatCoordinate(value: number, positive: string, negative: string): string {
  const direction = value >= 0 ? positive : negative;
  return `${Math.abs(value).toFixed(4)} ${direction}`;
}

export function formatCoordinates(result: SearchResult): string {
  return `${formatCoordinate(result.lat, 'N', 'S')}, ${formatCoordinate(result.lng, 'E', 'W')}`;
}

export function resultKind(result: Partial<SearchResult>): string {
  if (result.addressType === 'road') return 'Street';
  return titleCase(result.addressType || result.type || result.class || 'Place');
}

function splitDetailText(value: string | undefined): string[] {
  if (!value) return [];
  return value
    .split(/[,\u00b7]/u)
    .map((part) => part.trim())
    .filter(Boolean);
}

function addUniqueDetailPart(parts: string[], blocked: Set<string>, value: string) {
  const normalized = normalizeLabel(value);
  if (!normalized || blocked.has(normalized) || parts.some((part) => normalizeLabel(part) === normalized)) {
    return;
  }
  parts.push(value.trim());
}

function displayNameContextParts(result: Partial<SearchResult>): string[] {
  const displayName = result.displayName?.trim();
  const parts = splitDetailText(displayName);
  if (parts.length <= 1) return [];

  const first = normalizeLabel(parts[0]);
  const firstIsLabel = first === normalizeLabel(result.name)
    || first === normalizeLabel(resultKind(result))
    || GENERIC_RESULT_LABELS.has(first);
  return firstIsLabel ? parts.slice(1) : parts;
}

export function resultContextSummary(result: Partial<SearchResult>): string | null {
  const blocked = new Set([
    normalizeLabel(result.name),
    ...(result.aliases ?? []).map(normalizeLabel),
    normalizeLabel(resultKind(result)),
  ]);
  for (const label of GENERIC_RESULT_LABELS) {
    blocked.add(label);
  }

  const parts: string[] = [];
  // A city pin may lie inside a smaller municipality (London in Westminster).
  // Context parts run from local area to region to country; city labels only
  // need the broader levels, not the local area around their representative pin.
  const contextParts = result.type === 'city' || result.addressType === 'city'
    ? result.contextParts?.slice(-2) : result.contextParts;
  for (const value of [
    ...(contextParts ?? []),
    ...splitDetailText(result.context),
    ...displayNameContextParts(result),
  ]) {
    addUniqueDetailPart(parts, blocked, value);
  }

  return parts.length > 0 ? parts.slice(0, 4).join(', ') : null;
}

export function formatAlias(alias: string, result: SearchResult): string {
  if (result.addressType === 'road' && /^[A-Z]?[0-9][A-Z0-9 -]*$/i.test(alias.trim())) {
    return `Route ${alias.trim()}`;
  }
  return alias;
}

export function usefulAliases(result: SearchResult): string[] {
  const blocked = new Set([
    normalizeLabel(result.name),
    normalizeLabel(result.displayName),
    normalizeLabel(resultKind(result)),
  ]);
  const aliases: string[] = [];
  for (const alias of result.aliases ?? []) {
    const normalized = normalizeLabel(alias);
    if (!normalized || blocked.has(normalized) || aliases.some((item) => normalizeLabel(item) === normalized)) continue;
    aliases.push(formatAlias(alias, result));
    if (aliases.length >= 2) break;
  }
  return aliases;
}

export function usefulDisplayName(result: SearchResult): string | null {
  const displayName = result.displayName?.trim();
  if (!displayName) return null;

  const display = normalizeLabel(displayName);
  if (
    !display
    || display === normalizeLabel(result.name)
    || display === normalizeLabel(resultKind(result))
    || GENERIC_RESULT_LABELS.has(display)
  ) {
    return null;
  }

  const contextParts = splitDetailText(displayName);
  if (contextParts.length > 1) {
    const first = normalizeLabel(contextParts[0]);
    if (first === normalizeLabel(result.name) || first === normalizeLabel(resultKind(result)) || GENERIC_RESULT_LABELS.has(first)) {
      return null;
    }
  }

  return displayName;
}

export function resultDetails(result: SearchResult): string {
  const parts = [
    usefulDisplayName(result),
    resultContextSummary(result),
    ...usefulAliases(result),
  ].filter((part): part is string => !!part);
  if (parts.length === 0) {
    parts.push(formatCoordinates(result));
  }
  return parts.join(' · ');
}

export function resultDisplayLine(result: SearchResult): string {
  const name = result.name.trim();
  const context = resultContextSummary(result);
  if (!context) return name;
  return `${name}, ${context}`;
}
