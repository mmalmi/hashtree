export const FACT_OP_KIND = 7368;

const subjectMarker = 'subject';
const reservedTags = new Set(['d', 'e', 'i', 'p']);
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const hex64Pattern = /^[0-9a-f]{64}$/;

export interface MapFact {
  predicate: string;
  values: string[];
}

export interface MapFactEventRecord {
  kind: typeof FACT_OP_KIND;
  content: '';
  tags: string[][];
  subject: string;
  eventId?: string;
  authorPubkey?: string;
  publishedAt?: number;
  publishError?: string;
}

export interface PlaceFactInput {
  id: string;
  name: string;
  category: string;
  lat: number;
  lng: number;
  description?: string;
  contact?: string;
  hours?: string;
  createdAt: number;
  updatedAt: number;
}

export interface ReviewFactInput {
  id: string;
  placeId: string;
  reviewer: string;
  rating: number;
  ratingMax: number;
  body?: string;
  lang?: string;
  media?: ReviewMediaFactInput[];
  createdAt: number;
  updatedAt: number;
}

export interface SavedPlaceListFactInput {
  id: string;
  name: string;
  description?: string;
  avatarUrl?: string;
  visibility: 'public' | 'private';
  urls?: {
    web?: string;
    htree?: string;
    data?: string;
    htreeData?: string;
  };
  places: SavedPlaceFactInput[];
  createdAt: number;
  updatedAt: number;
}

export interface SavedPlaceFactInput {
  key: string;
  id?: string;
  type?: string;
}

export interface ReviewMediaFactInput {
  url: string;
  mimeType: string;
  alt?: string;
}

export function createMapEntityId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }

  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function mapFact(predicate: string, values: Array<string | number | undefined | null>): MapFact | null {
  const normalizedValues = values
    .map((value) => value === undefined || value === null ? '' : String(value).trim())
    .filter(Boolean);
  if (normalizedValues.length === 0) return null;
  return {
    predicate,
    values: normalizedValues,
  };
}

export function buildPlaceFactEvent(place: PlaceFactInput): MapFactEventRecord {
  const facts = compactFacts([
    mapFact('type', ['place']),
    mapFact('name', [place.name]),
    mapFact('category', [place.category]),
    mapFact('lat', [formatCoordinate(place.lat)]),
    mapFact('lng', [formatCoordinate(place.lng)]),
    mapFact('description', [place.description]),
    mapFact('contact', [place.contact]),
    mapFact('hours', [place.hours]),
    mapFact('source', ['iris-maps']),
    mapFact('source_id', [`iris-maps:place:${place.id}`]),
    mapFact('created_at', [unixSeconds(place.createdAt)]),
    mapFact('updated_at', [unixSeconds(place.updatedAt)]),
  ]);

  return buildFactEventRecord(place.id, facts, {
    externalIdentifiers: [`iris-maps:place:${place.id}`],
  });
}

export function buildReviewFactEvent(review: ReviewFactInput): MapFactEventRecord {
  const facts = compactFacts([
    mapFact('type', ['review']),
    mapFact('reviewer', [review.reviewer]),
    mapFact('review_of', [review.placeId]),
    mapFact('rating', [review.rating, review.ratingMax]),
    mapFact('body', [review.body]),
    mapFact('lang', [review.lang]),
    ...reviewMediaFacts(review.media ?? []),
    mapFact('published_at', [unixSeconds(review.createdAt)]),
    mapFact('source', ['iris-maps']),
    mapFact('source_id', [`iris-maps:review:${review.id}`]),
    mapFact('updated_at', [unixSeconds(review.updatedAt)]),
  ]);

  return buildFactEventRecord(review.id, facts, {
    externalIdentifiers: [
      `iris-maps:review:${review.id}`,
      `iris-maps:place:${review.placeId}`,
      review.reviewer,
    ],
  });
}

export function buildSavedPlaceListFactEvent(list: SavedPlaceListFactInput): MapFactEventRecord {
  const facts = compactFacts([
    mapFact('type', ['saved_place_list']),
    mapFact('name', [list.name]),
    mapFact('description', [list.description]),
    mapFact('avatar_url', [list.avatarUrl]),
    mapFact('visibility', [list.visibility]),
    mapFact('place_count', [list.places.length]),
    mapFact('web_url', [list.urls?.web]),
    mapFact('htree_url', [list.urls?.htree]),
    mapFact('data_url', [list.urls?.data]),
    mapFact('htree_data_url', [list.urls?.htreeData]),
    mapFact('source', ['iris-maps']),
    mapFact('source_id', [`iris-maps:saved-place-list:${list.id}`]),
    mapFact('created_at', [unixSeconds(list.createdAt)]),
    mapFact('updated_at', [unixSeconds(list.updatedAt)]),
  ]);

  return buildFactEventRecord(list.id, facts, {
    externalIdentifiers: [
      `iris-maps:saved-place-list:${list.id}`,
      ...list.places.map((place) => savedPlaceExternalIdentifier(place.key)),
    ],
  });
}

export function buildFactEventRecord(
  subject: string,
  facts: MapFact[],
  indexes: { externalIdentifiers?: string[] } = {},
): MapFactEventRecord {
  const normalizedSubject = normalizeUuid(subject);
  const normalizedFacts = normalizeFacts(facts);
  const externalIdentifiers = normalizeExternalIdentifiers(indexes.externalIdentifiers ?? []);
  const tags: string[][] = [['i', normalizedSubject, subjectMarker]];
  tags.push(...indexTags(normalizedSubject, normalizedFacts, externalIdentifiers));
  tags.push(...normalizedFacts.map((fact) => [fact.predicate, ...fact.values]));
  return {
    kind: FACT_OP_KIND,
    content: '',
    subject: normalizedSubject,
    tags,
  };
}

function reviewMediaFacts(media: ReviewMediaFactInput[]): MapFact[] {
  const facts: MapFact[] = [];
  for (const item of media) {
    const mediaFact = mapFact('media', [item.url, item.mimeType]);
    if (mediaFact) facts.push(mediaFact);
    const imetaValues = [
      `url ${item.url}`,
      `m ${item.mimeType}`,
      item.alt ? `alt ${item.alt}` : undefined,
    ];
    const imetaFact = mapFact('imeta', imetaValues);
    if (imetaFact) facts.push(imetaFact);
  }
  return facts;
}

function compactFacts(facts: Array<MapFact | null>): MapFact[] {
  return facts.filter((fact): fact is MapFact => Boolean(fact));
}

function normalizeFacts(facts: MapFact[]): MapFact[] {
  const seen = new Set<string>();
  return facts
    .map((fact) => {
      const predicate = normalizePredicate(fact.predicate);
      if (reservedTags.has(predicate)) throw new Error(`${predicate} is a reserved fact event tag`);
      return {
        predicate,
        values: fact.values.map(normalizeValue),
      };
    })
    .sort(compareFacts)
    .filter((fact) => {
      const key = `${fact.predicate}\0${JSON.stringify(fact.values)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizePredicate(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) throw new Error('fact predicate cannot be empty');
  if ([...trimmed].length < 2) throw new Error(`fact predicate must be at least two characters: ${trimmed}`);
  if (/\s/.test(trimmed)) throw new Error(`fact predicate cannot contain whitespace: ${trimmed}`);
  return trimmed;
}

function normalizeValue(value: string): string {
  const trimmed = value.trim();
  if (isUuid(trimmed)) return normalizeUuid(trimmed);
  if (isPubkey(trimmed)) return trimmed.toLowerCase();
  return trimmed;
}

function normalizeUuid(value: string): string {
  const trimmed = value.trim();
  const lower = trimmed.toLowerCase();
  if (!uuidPattern.test(lower) || trimmed !== lower) {
    throw new Error(`UUID must be canonical lowercase hyphenated text: ${value}`);
  }
  return lower;
}

function normalizeExternalIdentifiers(values: string[]): Set<string> {
  return new Set(values.map((value) => {
    const trimmed = value.trim();
    if (!trimmed) throw new Error('external fact identifier cannot be empty');
    if (isUuid(trimmed)) return normalizeUuid(trimmed);
    if (/\s/.test(trimmed)) throw new Error(`external fact identifier cannot contain whitespace: ${trimmed}`);
    return trimmed.toLowerCase();
  }).sort());
}

function indexTags(subject: string, facts: MapFact[], externalIdentifiers: Set<string>): string[][] {
  const uuids = new Set<string>();
  const pubkeys = new Set<string>();
  for (const fact of facts) {
    for (const value of fact.values) {
      if (isUuid(value) && value !== subject) uuids.add(value);
      else if (isPubkey(value)) pubkeys.add(value);
    }
  }
  for (const identifier of externalIdentifiers) {
    if (isUuid(identifier) && identifier !== subject) uuids.add(identifier);
  }
  return [
    ...[...uuids].sort().map((uuid) => ['i', uuid]),
    ...[...externalIdentifiers]
      .filter((identifier) => !isUuid(identifier))
      .sort()
      .map((identifier) => ['i', identifier]),
    ...[...pubkeys].sort().map((pubkey) => ['p', pubkey]),
  ];
}

function compareFacts(left: MapFact, right: MapFact): number {
  return left.predicate.localeCompare(right.predicate)
    || JSON.stringify(left.values).localeCompare(JSON.stringify(right.values));
}

function formatCoordinate(value: number): string {
  return String(Math.round(value * 1_000_000) / 1_000_000);
}

function unixSeconds(timestampMs: number): string {
  return String(Math.floor(timestampMs / 1000));
}

function savedPlaceExternalIdentifier(key: string): string {
  return `iris-maps:saved-place:${encodeURIComponent(key)}`;
}

function isUuid(value: string): boolean {
  return uuidPattern.test(value.toLowerCase());
}

function isPubkey(value: string): boolean {
  return hex64Pattern.test(value.toLowerCase());
}
