import { createAsyncCache } from './asyncCache';
import { normalizeMapSearchText as normalizeMapDetailSearchText } from './mapSearchText';
import { VectorTile, type VectorTileFeature } from '@mapbox/vector-tile';
import Protobuf from 'pbf';
import type { PMTiles } from 'pmtiles';
import type { SearchResult } from '../stores/mapsTypes';
import { houseNumberMatches, normalizeHouseNumber } from './mapSearchIndex';

export interface TileCoordinate {
  z: number;
  x: number;
  y: number;
}

export interface StreetAddressTileQuery {
  houseNumber: string;
  streetQuery: string;
}

export type VectorTileReader = (tile: TileCoordinate) => Promise<VectorTile | null>;

export interface StreetAddressVectorTileSearchOptions {
  addressQuery: StreetAddressTileQuery;
  streetCandidates: SearchResult[];
  readTile: VectorTileReader;
  sourceZoom: number;
  streetLayer?: string;
  houseNumberLayer?: string;
  maxJoinRadiusMeters?: number;
  maxStreetCandidates?: number;
  tileNeighborhoodRadius?: number;
  tileReadBatchSize?: number;
}

interface TileStreetCandidate {
  name: string;
  aliases: string[];
  lines: Array<Array<[number, number]>>;
  sourceId?: string;
  sourceTile: [number, number];
  sourceZoom: number;
}

interface TileHouseNumberCandidate {
  houseNumber: string;
  lat: number;
  lng: number;
  sourceId?: string;
  sourceTile: [number, number];
  sourceZoom: number;
}

const defaultStreetLayer = 'transportation_name';
const defaultHouseNumberLayer = 'housenumber';

export function lonLatToTile(lng: number, lat: number, z: number): TileCoordinate {
  const scale = 2 ** z;
  const latRad = lat * Math.PI / 180;
  return {
    z,
    x: Math.floor(((lng + 180) / 360) * scale),
    y: Math.floor(((1 - Math.log(Math.tan(latRad) + (1 / Math.cos(latRad))) / Math.PI) / 2) * scale),
  };
}

export function createPmtilesVectorTileReader(archive: Pick<PMTiles, 'getZxy'>): VectorTileReader {
  return createAsyncCache(async (tile: TileCoordinate) => {
    const response = await archive.getZxy(tile.z, tile.x, tile.y);
    return response?.data ? new VectorTile(new Protobuf(response.data)) : null;
  }, (tile) => `${tile.z}:${tile.x}:${tile.y}`);
}

export async function searchStreetAddressInVectorTiles(
  options: StreetAddressVectorTileSearchOptions,
): Promise<SearchResult[]> {
  const normalizedStreetQuery = normalizeMapDetailSearchText(options.addressQuery.streetQuery);
  if (normalizedStreetQuery.length < 2 || options.streetCandidates.length === 0) return [];

  const sourceZoom = Math.max(0, Math.floor(options.sourceZoom));
  const tiles = candidateTilesForStreetResults(
    options.streetCandidates,
    normalizedStreetQuery,
    sourceZoom,
    options.maxStreetCandidates ?? 40,
    options.tileNeighborhoodRadius ?? 1,
  );
  if (tiles.length === 0) return [];

  const streetLayerName = options.streetLayer ?? defaultStreetLayer;
  const houseLayerName = options.houseNumberLayer ?? defaultHouseNumberLayer;
  const readBatchSize = Math.max(1, options.tileReadBatchSize ?? 24);
  const streets: TileStreetCandidate[] = [];
  const houses: TileHouseNumberCandidate[] = [];

  for (let start = 0; start < tiles.length; start += readBatchSize) {
    const batch = tiles.slice(start, start + readBatchSize);
    const vectorTiles = await Promise.all(batch.map(async (tile) => ({
      tile,
      vectorTile: await options.readTile(tile),
    })));

    for (const { tile, vectorTile } of vectorTiles) {
      if (!vectorTile) continue;
      appendMatchingStreetFeatures(streets, vectorTile, tile, streetLayerName, normalizedStreetQuery);
      appendMatchingHouseNumberFeatures(
        houses,
        vectorTile,
        tile,
        houseLayerName,
        options.addressQuery.houseNumber,
      );
    }
  }

  if (streets.length === 0 || houses.length === 0) return [];
  return joinTileStreetAddresses(
    streets,
    houses,
    options.maxJoinRadiusMeters ?? 45,
  );
}

function candidateTilesForStreetResults(
  streetCandidates: SearchResult[],
  normalizedStreetQuery: string,
  sourceZoom: number,
  maxStreetCandidates: number,
  neighborhoodRadius: number,
): TileCoordinate[] {
  const tiles = new Map<string, TileCoordinate>();
  const scale = 2 ** sourceZoom;
  for (const street of streetCandidates.slice(0, maxStreetCandidates)) {
    if (!scoreMapDetailNames([street.name, ...(street.aliases ?? [])], normalizedStreetQuery)) continue;
    const centerTile = lonLatToTile(street.lng, street.lat, sourceZoom);
    for (let dx = -neighborhoodRadius; dx <= neighborhoodRadius; dx += 1) {
      for (let dy = -neighborhoodRadius; dy <= neighborhoodRadius; dy += 1) {
        const tile = { z: sourceZoom, x: centerTile.x + dx, y: centerTile.y + dy };
        if (tile.x < 0 || tile.y < 0 || tile.x >= scale || tile.y >= scale) continue;
        tiles.set(`${tile.z}:${tile.x}:${tile.y}`, tile);
      }
    }
  }
  return Array.from(tiles.values());
}

function appendMatchingStreetFeatures(
  streets: TileStreetCandidate[],
  vectorTile: VectorTile,
  tile: TileCoordinate,
  streetLayerName: string,
  normalizedStreetQuery: string,
) {
  const streetLayer = vectorTile.layers[streetLayerName];
  if (!streetLayer) return;

  for (let index = 0; index < streetLayer.length; index += 1) {
    const feature = streetLayer.feature(index);
    const names = mapFeatureNames(feature.properties);
    const primaryName = names[0];
    if (!primaryName || !scoreMapDetailNames(names, normalizedStreetQuery)) continue;
    const lines = vectorTileFeatureLines(feature, tile);
    if (lines.length === 0) continue;
    streets.push({
      name: primaryName,
      aliases: names.slice(1, 24),
      lines,
      sourceId: vectorTileSourceId(feature),
      sourceTile: [tile.x, tile.y],
      sourceZoom: tile.z,
    });
  }
}

function appendMatchingHouseNumberFeatures(
  houses: TileHouseNumberCandidate[],
  vectorTile: VectorTile,
  tile: TileCoordinate,
  houseLayerName: string,
  houseNumberQuery: string,
) {
  const houseLayer = vectorTile.layers[houseLayerName];
  if (!houseLayer) return;

  for (let index = 0; index < houseLayer.length; index += 1) {
    const feature = houseLayer.feature(index);
    const houseNumber = mapFeatureHouseNumber(feature.properties);
    if (!houseNumber || !houseNumberMatches(houseNumber, houseNumberQuery)) continue;
    for (const line of vectorTileFeatureLines(feature, tile)) {
      for (const [lng, lat] of line) {
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
        houses.push({
          houseNumber,
          lat: Number(lat.toFixed(6)),
          lng: Number(lng.toFixed(6)),
          sourceId: vectorTileSourceId(feature),
          sourceTile: [tile.x, tile.y],
          sourceZoom: tile.z,
        });
      }
    }
  }
}

function joinTileStreetAddresses(
  streets: TileStreetCandidate[],
  houses: TileHouseNumberCandidate[],
  maxJoinRadiusMeters: number,
): SearchResult[] {
  const results: Array<{ result: SearchResult; distanceMeters: number }> = [];
  for (const house of houses) {
    const houseCoordinate: [number, number] = [house.lng, house.lat];
    let bestStreet: TileStreetCandidate | null = null;
    let bestDistanceMeters = Number.POSITIVE_INFINITY;
    for (const street of streets) {
      const distanceMeters = distanceToLineStringsMeters(houseCoordinate, street.lines);
      if (distanceMeters < bestDistanceMeters) {
        bestDistanceMeters = distanceMeters;
        bestStreet = street;
      }
    }
    if (!bestStreet || bestDistanceMeters > maxJoinRadiusMeters) continue;
    results.push({
      result: tileAddressSearchResult(bestStreet, house, bestDistanceMeters, maxJoinRadiusMeters),
      distanceMeters: bestDistanceMeters,
    });
  }

  const deduped = new Map<string, { result: SearchResult; distanceMeters: number }>();
  for (const entry of results) {
    const key = `${entry.result.name}:${entry.result.lat.toFixed(6)}:${entry.result.lng.toFixed(6)}`;
    const existing = deduped.get(key);
    if (!existing || entry.distanceMeters < existing.distanceMeters) {
      deduped.set(key, entry);
    }
  }
  return Array.from(deduped.values())
    .sort((left, right) => left.distanceMeters - right.distanceMeters)
    .map(({ result }) => result)
    .slice(0, 10);
}

function tileAddressSearchResult(
  street: TileStreetCandidate,
  house: TileHouseNumberCandidate,
  distanceMeters: number,
  maxJoinRadiusMeters: number,
): SearchResult {
  const aliases = [
    `${house.houseNumber} ${street.name}`.trim(),
    ...street.aliases.map((alias) => `${alias} ${house.houseNumber}`.trim()),
    ...street.aliases.map((alias) => `${house.houseNumber} ${alias}`.trim()),
  ].filter((alias, index, list) => alias && list.indexOf(alias) === index).slice(0, 12);
  const confidence = Math.max(0.05, 1 - (distanceMeters / maxJoinRadiusMeters));

  return {
    id: `basemap-tile:${street.sourceZoom}:${street.sourceTile[0]}:${street.sourceTile[1]}:${street.sourceId ?? street.name}:address:${normalizeHouseNumber(house.houseNumber)}:${house.lat.toFixed(6)}:${house.lng.toFixed(6)}`,
    name: `${street.name} ${house.houseNumber}`.trim(),
    lat: house.lat,
    lng: house.lng,
    type: 'house',
    class: 'building',
    displayName: 'Address',
    aliases,
    placeRank: 30,
    importance: Math.min(1, Math.max(0.05, 0.25 + (confidence * 0.05))),
    addressType: 'house',
    sourceLayer: defaultHouseNumberLayer,
    sourceZoom: house.sourceZoom,
    sourceId: house.sourceId,
    sourceTile: house.sourceTile,
  };
}

function tilePointToLngLat(tile: TileCoordinate, x: number, y: number, extent: number): [number, number] {
  const scale = 2 ** tile.z;
  const lng = ((tile.x + (x / extent)) / scale) * 360 - 180;
  const mercatorY = Math.PI * (1 - (2 * (tile.y + (y / extent)) / scale));
  const lat = Math.atan(Math.sinh(mercatorY)) * 180 / Math.PI;
  return [lng, lat];
}

export function mapFeatureNames(properties: Record<string, unknown>): string[] {
  const names: string[] = [];
  const add = (value: unknown) => {
    if (typeof value !== 'string' && typeof value !== 'number') return;
    const text = String(value).trim();
    if (!text || text.length > 160 || names.includes(text)) return;
    names.push(text);
  };

  add(properties.name);
  add(properties.name_en);
  add(properties['name:en']);
  add(properties.name_int);
  add(properties.name_latin);
  add(properties['name:latin']);
  add(properties['name:fi']);
  add(properties['name:sv']);
  add(properties['name:nonlatin']);
  add(properties.ref);

  for (const [key, value] of Object.entries(properties)) {
    if (!key.startsWith('name')) continue;
    add(value);
    if (names.length >= 40) break;
  }

  return names;
}

function vectorTileFeatureLines(feature: VectorTileFeature, tile: TileCoordinate): Array<Array<[number, number]>> {
  try {
    return feature.loadGeometry()
      .map((line) => line.map((point) => tilePointToLngLat(tile, point.x, point.y, feature.extent)))
      .filter((line) => line.length > 0);
  } catch {
    return [];
  }
}

export function mapFeatureHouseNumber(properties: Record<string, unknown>): string {
  const value = properties.housenumber
    ?? properties.house_number
    ?? properties['addr:housenumber']
    ?? properties.number;
  if (typeof value !== 'string' && typeof value !== 'number') return '';
  const text = String(value).trim();
  return text.length <= 32 ? text : '';
}

function vectorTileSourceId(feature: VectorTileFeature): string | undefined {
  return typeof feature.id === 'number' && Number.isFinite(feature.id) ? String(feature.id) : undefined;
}

function scoreMapDetailNames(names: string[], normalizedQuery: string): number {
  if (!normalizedQuery) return 0;
  let best = 0;
  for (const name of names) {
    const normalizedName = normalizeMapDetailSearchText(name);
    if (!normalizedName) continue;
    if (normalizedName === normalizedQuery) best = Math.max(best, 1000);
    else if (normalizedName.startsWith(normalizedQuery)) best = Math.max(best, 900);
    else if (normalizedName.split(' ').some((part) => part.startsWith(normalizedQuery))) best = Math.max(best, 820);
    else if (normalizedName.includes(normalizedQuery)) best = Math.max(best, 620);
  }
  return best;
}

function squaredDistanceBetweenMeterPoints(left: { x: number; y: number }, right: { x: number; y: number }): number {
  const dx = left.x - right.x;
  const dy = left.y - right.y;
  return dx * dx + dy * dy;
}

function lngLatToLocalMeters(coordinate: [number, number], originLat: number): { x: number; y: number } {
  const metersPerDegreeLat = 111_320;
  const metersPerDegreeLng = metersPerDegreeLat * Math.max(0.05, Math.cos(originLat * Math.PI / 180));
  return {
    x: coordinate[0] * metersPerDegreeLng,
    y: coordinate[1] * metersPerDegreeLat,
  };
}

function squaredDistanceToMeterSegment(
  point: { x: number; y: number },
  start: { x: number; y: number },
  end: { x: number; y: number },
): number {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = dx * dx + dy * dy;
  if (lengthSquared === 0) return squaredDistanceBetweenMeterPoints(point, start);
  const t = Math.max(0, Math.min(1, (((point.x - start.x) * dx) + ((point.y - start.y) * dy)) / lengthSquared));
  const projected = {
    x: start.x + t * dx,
    y: start.y + t * dy,
  };
  return squaredDistanceBetweenMeterPoints(point, projected);
}

export function distanceToLineStringsMeters(coordinate: [number, number], lines: Array<Array<[number, number]>>): number {
  const originLat = coordinate[1];
  const point = lngLatToLocalMeters(coordinate, originLat);
  let best = Number.POSITIVE_INFINITY;
  for (const line of lines) {
    if (line.length === 0) continue;
    if (line.length === 1) {
      best = Math.min(best, Math.sqrt(squaredDistanceBetweenMeterPoints(point, lngLatToLocalMeters(line[0], originLat))));
      continue;
    }
    for (let index = 1; index < line.length; index += 1) {
      best = Math.min(
        best,
        Math.sqrt(squaredDistanceToMeterSegment(
          point,
          lngLatToLocalMeters(line[index - 1], originLat),
          lngLatToLocalMeters(line[index], originLat),
        )),
      );
    }
  }
  return best;
}
