import type { PlaceDetailLink, PlaceDetails, SavedPlaceList, SavedPlaceListItem } from '../stores/mapsTypes';
import { BTCMAP_LIST_AVATAR_URL, BTCMAP_LIST_DESCRIPTION, isBtcMapSource } from './btcMapListMetadata.ts';

export const SAVED_PLACE_LISTS_DIR = 'saved-place-lists';
export const SAVED_PLACE_LIST_MANIFEST_FILE = 'list.json';
export const SAVED_PLACE_LIST_ITEMS_DIR = 'items';
export const DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE = 512;
export const DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE = 240;
export const DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD = 2000;

export interface SavedPlaceListItemsSource {
  kind: 'json-page-directory';
  dir: string;
  pageSize: number;
  pageCount: number;
  totalCount: number;
}

export interface SavedPlaceListDynamicSampleSource {
  kind: 'dynamic-random-ordinal';
  source: 'items';
  sampleSize: number;
  threshold: number;
}

export interface SavedPlaceListManifestIndex {
  kind: string;
  file: string;
  projections?: string;
  itemEvents?: string;
  projectionCount?: number;
  indexes?: string[];
}

export interface SavedPlaceListManifest {
  version: 1;
  kind: 'iris-maps-saved-place-list';
  id: string;
  name: string;
  description?: string;
  icon: SavedPlaceList['icon'];
  avatarUrl?: string;
  visibility: SavedPlaceList['visibility'];
  urls?: SavedPlaceList['urls'];
  createdAt: number;
  updatedAt: number;
  itemCount: number;
  items: SavedPlaceListItemsSource;
  sampling?: {
    world?: SavedPlaceListDynamicSampleSource;
  };
  index?: SavedPlaceListManifestIndex | null;
  renderingProjections?: Record<string, unknown>;
  source?: Record<string, unknown>;
  labels?: string[];
}

export function savedPlaceListDirectoryPath(listId: string): string {
  return `${SAVED_PLACE_LISTS_DIR}/${encodeURIComponent(listId)}`;
}

export function savedPlaceListManifestPath(listId: string): string {
  return `${savedPlaceListDirectoryPath(listId)}/${SAVED_PLACE_LIST_MANIFEST_FILE}`;
}

export function savedPlaceListItemsPath(listId: string): string {
  return `${savedPlaceListDirectoryPath(listId)}/${SAVED_PLACE_LIST_ITEMS_DIR}`;
}

export function savedPlaceListItemPageFile(index: number): string {
  return `${String(Math.max(0, Math.floor(index))).padStart(6, '0')}.json`;
}

export function savedPlaceListItemPagePath(listId: string, index: number): string {
  return `${savedPlaceListItemsPath(listId)}/${savedPlaceListItemPageFile(index)}`;
}

export function buildSavedPlaceListItemPages(
  items: SavedPlaceListItem[],
  pageSize = DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE,
): SavedPlaceListItem[][] {
  const normalizedPageSize = Math.max(1, Math.floor(pageSize));
  const pages: SavedPlaceListItem[][] = [];
  for (let index = 0; index < items.length; index += normalizedPageSize) {
    pages.push(items.slice(index, index + normalizedPageSize));
  }
  return pages.length > 0 ? pages : [[]];
}

export function buildSavedPlaceListManifest(
  list: SavedPlaceList,
  options: {
    pageSize?: number;
    sampleSize?: number;
    sampleThreshold?: number;
    index?: SavedPlaceListManifestIndex | null;
    renderingProjections?: Record<string, unknown>;
    source?: Record<string, unknown>;
    labels?: string[];
  } = {},
): SavedPlaceListManifest {
  const pageSize = Math.max(1, Math.floor(options.pageSize ?? DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE));
  const sampleThreshold = Math.max(0, Math.floor(options.sampleThreshold ?? DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD));
  const sampleSize = Math.max(1, Math.floor(options.sampleSize ?? DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE));
  const shouldDescribeDynamicWorldSample = list.places.length > sampleThreshold;
  return {
    version: 1,
    kind: 'iris-maps-saved-place-list',
    id: list.id,
    name: list.name,
    description: list.description,
    icon: list.icon,
    avatarUrl: list.avatarUrl,
    visibility: list.visibility,
    urls: list.urls,
    createdAt: list.createdAt,
    updatedAt: list.updatedAt,
    itemCount: list.places.length,
    items: {
      kind: 'json-page-directory',
      dir: SAVED_PLACE_LIST_ITEMS_DIR,
      pageSize,
      pageCount: Math.max(1, Math.ceil(list.places.length / pageSize)),
      totalCount: list.places.length,
    },
    sampling: shouldDescribeDynamicWorldSample
      ? {
          world: {
            kind: 'dynamic-random-ordinal',
            source: 'items',
            sampleSize: Math.min(list.places.length, sampleSize),
            threshold: sampleThreshold,
          },
        }
      : undefined,
    index: options.index ?? null,
    renderingProjections: options.renderingProjections,
    source: options.source,
    labels: options.labels,
  };
}

export function normalizeSavedPlaceListManifest(value: unknown): SavedPlaceListManifest | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<SavedPlaceListManifest>;
  if (record.kind !== 'iris-maps-saved-place-list') return null;
  if (typeof record.id !== 'string' || !record.id) return null;
  if (typeof record.name !== 'string' || !record.name.trim()) return null;
  if (!isSavedPlaceListIcon(record.icon)) return null;
  if (record.visibility !== 'public' && record.visibility !== 'private') return null;
  if (typeof record.createdAt !== 'number' || !Number.isFinite(record.createdAt)) return null;
  if (typeof record.updatedAt !== 'number' || !Number.isFinite(record.updatedAt)) return null;
  const items = normalizeItemsSource(record.items);
  if (!items) return null;
  const sampling = normalizeSampling(record.sampling);
  const source = record.source;
  return {
    version: 1,
    kind: 'iris-maps-saved-place-list',
    id: record.id,
    name: record.name.trim(),
    description: cleanString(record.description) ?? (isBtcMapSource(source) ? BTCMAP_LIST_DESCRIPTION : undefined),
    icon: record.icon,
    avatarUrl: cleanString(record.avatarUrl) ?? (isBtcMapSource(source) ? BTCMAP_LIST_AVATAR_URL : undefined),
    visibility: record.visibility,
    urls: record.urls,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
    itemCount: typeof record.itemCount === 'number' && Number.isFinite(record.itemCount) ? record.itemCount : 0,
    items,
    sampling,
    index: record.index ?? null,
    renderingProjections: record.renderingProjections,
    source,
    labels: record.labels,
  };
}

function normalizeSampling(value: unknown): SavedPlaceListManifest['sampling'] | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const record = value as { world?: unknown };
  const world = normalizeDynamicSampleSource(record.world);
  return world ? { world } : undefined;
}

function normalizeDynamicSampleSource(value: unknown): SavedPlaceListDynamicSampleSource | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<SavedPlaceListDynamicSampleSource>;
  if (record.kind !== 'dynamic-random-ordinal') return null;
  if (record.source !== 'items') return null;
  return {
    kind: 'dynamic-random-ordinal',
    source: 'items',
    sampleSize: typeof record.sampleSize === 'number' && Number.isFinite(record.sampleSize)
      ? Math.max(1, Math.floor(record.sampleSize))
      : DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE,
    threshold: typeof record.threshold === 'number' && Number.isFinite(record.threshold)
      ? Math.max(0, Math.floor(record.threshold))
      : DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD,
  };
}

function normalizeItemsSource(value: unknown): SavedPlaceListItemsSource | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<SavedPlaceListItemsSource>;
  if (record.kind !== 'json-page-directory') return null;
  if (typeof record.dir !== 'string' || !record.dir.trim()) return null;
  const pageSize = typeof record.pageSize === 'number' && Number.isFinite(record.pageSize)
    ? Math.max(1, Math.floor(record.pageSize))
    : DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE;
  const totalCount = typeof record.totalCount === 'number' && Number.isFinite(record.totalCount)
    ? Math.max(0, Math.floor(record.totalCount))
    : 0;
  const pageCount = typeof record.pageCount === 'number' && Number.isFinite(record.pageCount)
    ? Math.max(1, Math.floor(record.pageCount))
    : Math.max(1, Math.ceil(totalCount / pageSize));
  return {
    kind: 'json-page-directory',
    dir: record.dir.trim().replace(/^\/+|\/+$/g, '') || SAVED_PLACE_LIST_ITEMS_DIR,
    pageSize,
    pageCount,
    totalCount,
  };
}

export function normalizeSavedPlaceListItems(value: unknown): SavedPlaceListItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .map(normalizeSavedPlaceListItem)
    .filter((item): item is SavedPlaceListItem => Boolean(item));
}

function normalizeSavedPlaceListItem(value: unknown): SavedPlaceListItem | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<SavedPlaceListItem>;
  if (typeof record.key !== 'string' || !record.key.trim()) return null;
  if (typeof record.name !== 'string' || !record.name.trim()) return null;
  if (typeof record.lat !== 'number' || !Number.isFinite(record.lat)) return null;
  if (typeof record.lng !== 'number' || !Number.isFinite(record.lng)) return null;
  return {
    key: record.key.trim(),
    id: typeof record.id === 'string' && record.id ? record.id : undefined,
    name: record.name.trim(),
    lat: record.lat,
    lng: record.lng,
    type: typeof record.type === 'string' && record.type ? record.type : undefined,
    class: typeof record.class === 'string' && record.class ? record.class : undefined,
    displayName: typeof record.displayName === 'string' && record.displayName ? record.displayName : undefined,
    context: typeof record.context === 'string' && record.context ? record.context : undefined,
    details: normalizePlaceDetails(record.details),
    source: record.source === 'place' ? 'place' : 'search',
    sourceLayer: typeof record.sourceLayer === 'string' && record.sourceLayer ? record.sourceLayer : undefined,
    sourceId: typeof record.sourceId === 'string' && record.sourceId ? record.sourceId : undefined,
    savedAt: typeof record.savedAt === 'number' && Number.isFinite(record.savedAt) ? record.savedAt : Date.now(),
  };
}

function normalizePlaceDetails(value: unknown): PlaceDetails | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const record = value as Partial<PlaceDetails>;
  const details: PlaceDetails = {
    address: cleanString(record.address),
    description: cleanString(record.description),
    phone: cleanString(record.phone),
    email: cleanString(record.email),
    website: cleanString(record.website),
    openingHours: cleanString(record.openingHours),
    imageUrl: cleanString(record.imageUrl),
    paymentProvider: cleanString(record.paymentProvider),
    requiredAppUrl: cleanString(record.requiredAppUrl),
    verifiedAt: cleanString(record.verifiedAt),
    links: normalizePlaceDetailLinks(record.links),
  };
  return Object.values(details).some((item) => item !== undefined) ? details : undefined;
}

function normalizePlaceDetailLinks(value: unknown): PlaceDetailLink[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const links = value
    .map((item): PlaceDetailLink | null => {
      if (!item || typeof item !== 'object') return null;
      const record = item as Partial<PlaceDetailLink>;
      const label = cleanString(record.label);
      const url = cleanString(record.url);
      if (!label || !url) return null;
      return {
        label,
        url,
        kind: record.kind === 'website'
          || record.kind === 'social'
          || record.kind === 'payment'
          || record.kind === 'source'
          || record.kind === 'other'
          ? record.kind
          : undefined,
      };
    })
    .filter((item): item is PlaceDetailLink => Boolean(item));
  return links.length > 0 ? links : undefined;
}

function cleanString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function isSavedPlaceListIcon(value: unknown): value is SavedPlaceList['icon'] {
  return value === 'heart'
    || value === 'flag'
    || value === 'briefcase'
    || value === 'star'
    || value === 'bookmark'
    || value === 'map-pin';
}
