import type { PlaceCategory } from '../stores/mapsTypes';

export interface PlaceCategoryOption {
  value: PlaceCategory;
  label: string;
  iconClass: string;
}

export const DEFAULT_PLACE_TYPE_ICON = 'i-lucide-map-pin';

export const PLACE_CATEGORY_OPTIONS: PlaceCategoryOption[] = [
  { value: 'restaurant', label: 'Restaurant', iconClass: 'i-lucide-utensils' },
  { value: 'cafe', label: 'Cafe', iconClass: 'i-lucide-coffee' },
  { value: 'bar', label: 'Bar', iconClass: 'i-lucide-beer' },
  { value: 'shop', label: 'Shop', iconClass: 'i-lucide-shopping-bag' },
  { value: 'service', label: 'Service', iconClass: 'i-lucide-wrench' },
  { value: 'attraction', label: 'Attraction', iconClass: 'i-lucide-map' },
  { value: 'accommodation', label: 'Accommodation', iconClass: 'i-lucide-bed' },
  { value: 'transport', label: 'Transport', iconClass: 'i-lucide-car' },
  { value: 'other', label: 'Other', iconClass: DEFAULT_PLACE_TYPE_ICON },
];

const exactIconByType: Record<string, string> = {
  restaurant: 'i-lucide-utensils',
  lunch_dining: 'i-lucide-utensils',
  local_pizza: 'i-lucide-utensils',
  bakery_dining: 'i-lucide-wheat',
  tapas: 'i-lucide-utensils',
  cooking: 'i-lucide-cooking-pot',
  cake: 'i-lucide-cake-slice',
  icecream: 'i-lucide-ice-cream-bowl',

  cafe: 'i-lucide-coffee',
  local_cafe: 'i-lucide-coffee',
  coffee: 'i-lucide-coffee',

  bar: 'i-lucide-beer',
  local_bar: 'i-lucide-beer',
  sports_bar: 'i-lucide-beer',
  wine_bar: 'i-lucide-wine',
  liquor: 'i-lucide-wine',
  nightlife: 'i-lucide-martini',

  shop: 'i-lucide-shopping-bag',
  storefront: 'i-lucide-store',
  local_grocery_store: 'i-lucide-shopping-cart',
  local_mall: 'i-lucide-store',
  card_giftcard: 'i-lucide-gift',
  diamond: 'i-lucide-gem',
  chair: 'i-lucide-armchair',
  home: 'i-lucide-house',
  toys: 'i-lucide-gamepad-2',

  local_atm: 'i-lucide-banknote',
  currency_exchange: 'i-lucide-circle-dollar-sign',
  attach_money: 'i-lucide-circle-dollar-sign',
  account_balance: 'i-lucide-landmark',
  balance: 'i-lucide-scale',

  local_gas_station: 'i-lucide-fuel',
  hotel: 'i-lucide-bed',
  chalet: 'i-lucide-house',
  luggage: 'i-lucide-luggage',

  content_cut: 'i-lucide-scissors',
  spa: 'i-lucide-sparkles',
  medical_services: 'i-lucide-heart-pulse',
  local_pharmacy: 'i-lucide-pill',
  dentistry: 'i-lucide-stethoscope',
  fitness_center: 'i-lucide-dumbbell',
  sports: 'i-lucide-dumbbell',

  computer: 'i-lucide-monitor',
  smartphone: 'i-lucide-smartphone',
  games: 'i-lucide-gamepad-2',
  music_note: 'i-lucide-music',
  mic: 'i-lucide-mic',
  menu_book: 'i-lucide-book-open',
  school: 'i-lucide-graduation-cap',

  car_repair: 'i-lucide-wrench',
  directions_car: 'i-lucide-car',
  local_car_wash: 'i-lucide-car',
  local_taxi: 'i-lucide-car-taxi-front',
  pedal_bike: 'i-lucide-bike',
  two_wheeler: 'i-lucide-bike',
  directions_boat: 'i-lucide-ship',
  electric_bolt: 'i-lucide-zap',

  business: 'i-lucide-briefcase',
  build: 'i-lucide-wrench',
  construction: 'i-lucide-hammer',
  engineering: 'i-lucide-cog',
  hardware: 'i-lucide-hammer',
  design_services: 'i-lucide-pencil-ruler',
  architecture: 'i-lucide-landmark',
  local_printshop: 'i-lucide-printer',
  cleaning_services: 'i-lucide-sparkles',
  local_laundry_service: 'i-lucide-washing-machine',
  hvac: 'i-lucide-wind',

  local_florist: 'i-lucide-flower-2',
  grass: 'i-lucide-leaf',
  pets: 'i-lucide-paw-print',
  palette: 'i-lucide-palette',
  colorize: 'i-lucide-palette',
  photo_camera: 'i-lucide-camera',
  tour: 'i-lucide-map',
  attractions: 'i-lucide-ferris-wheel',
  celebration: 'i-lucide-party-popper',
  visibility: 'i-lucide-eye',
  group: 'i-lucide-users',
  smoking_rooms: 'i-lucide-cigarette',
  vaping_rooms: 'i-lucide-cigarette',
};

const keywordIconGroups: Array<{ keywords: string[]; iconClass: string }> = [
  { keywords: ['restaurant', 'dining', 'pizza', 'bakery', 'food', 'sushi', 'burger', 'tapas'], iconClass: 'i-lucide-utensils' },
  { keywords: ['cafe', 'coffee'], iconClass: 'i-lucide-coffee' },
  { keywords: ['bar', 'pub', 'liquor', 'wine'], iconClass: 'i-lucide-beer' },
  { keywords: ['atm', 'bank', 'money', 'exchange', 'finance', 'cash'], iconClass: 'i-lucide-banknote' },
  { keywords: ['shop', 'store', 'mall', 'grocery', 'market', 'retail'], iconClass: 'i-lucide-shopping-bag' },
  { keywords: ['gas', 'fuel', 'charging'], iconClass: 'i-lucide-fuel' },
  { keywords: ['hotel', 'hostel', 'motel', 'accommodation', 'chalet', 'lodging'], iconClass: 'i-lucide-bed' },
  { keywords: ['medical', 'health', 'pharmacy', 'dentist', 'doctor', 'clinic'], iconClass: 'i-lucide-heart-pulse' },
  { keywords: ['spa', 'salon', 'hair', 'beauty', 'cut'], iconClass: 'i-lucide-scissors' },
  { keywords: ['computer', 'phone', 'software', 'tech', 'electronics'], iconClass: 'i-lucide-monitor' },
  { keywords: ['car', 'auto', 'taxi', 'bike', 'boat', 'transport'], iconClass: 'i-lucide-car' },
  { keywords: ['fitness', 'sport', 'gym'], iconClass: 'i-lucide-dumbbell' },
  { keywords: ['service', 'repair', 'hardware', 'construction', 'engineering'], iconClass: 'i-lucide-wrench' },
  { keywords: ['flower', 'garden', 'grass'], iconClass: 'i-lucide-flower-2' },
  { keywords: ['pet', 'animal'], iconClass: 'i-lucide-paw-print' },
  { keywords: ['photo', 'camera'], iconClass: 'i-lucide-camera' },
  { keywords: ['music', 'audio', 'mic'], iconClass: 'i-lucide-music' },
  { keywords: ['school', 'book', 'education'], iconClass: 'i-lucide-book-open' },
  { keywords: ['business', 'office', 'legal'], iconClass: 'i-lucide-briefcase' },
  { keywords: ['attraction', 'tour', 'travel'], iconClass: 'i-lucide-map' },
  { keywords: ['home', 'furniture', 'chair'], iconClass: 'i-lucide-house' },
];

export const PLACE_TYPE_ICON_CLASSES = Array.from(new Set([
  DEFAULT_PLACE_TYPE_ICON,
  ...PLACE_CATEGORY_OPTIONS.map((option) => option.iconClass),
  ...Object.values(exactIconByType),
  ...keywordIconGroups.map((group) => group.iconClass),
])).sort();

export function placeTypeIconClass(value: string | undefined | null): string {
  const key = normalizePlaceTypeKey(value);
  if (!key) return DEFAULT_PLACE_TYPE_ICON;
  const exact = exactIconByType[key];
  if (exact) return exact;
  for (const group of keywordIconGroups) {
    if (group.keywords.some((keyword) => key.includes(keyword))) {
      return group.iconClass;
    }
  }
  return DEFAULT_PLACE_TYPE_ICON;
}

export function displayPlaceTypeLabel(value: string | undefined | null): string {
  const text = value?.trim();
  if (!text) return 'Place';
  return text.replace(/[_-]+/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase());
}

export function normalizePlaceTypeKey(value: string | undefined | null): string {
  return value
    ?.trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .replace(/_+/g, '_') ?? '';
}
