import { hashFromHex } from './hashtreeKeys.ts';
import { HashTree, MemoryStore, objectKeyFromHex, toHex, type CID, type Store } from '@hashtree/core';
import { BTree } from '@hashtree/index';

export const SAVED_PLACE_MEMBERSHIP_KIND = 30368;
export const SAVED_PLACE_MEMBERSHIP_LABEL = 'iris-maps:saved-place-item';
export const IRIS_MAPS_LABEL = 'iris-maps';
export const SAVED_PLACE_LIST_LABEL = 'iris-maps:saved-place-list';
export const SAVED_PLACE_PROJECTIONS_FILE = 'saved-place-projections.jsonl';
export const SAVED_PLACE_INDEX_FILE = 'saved-place-index.json';
export const SAVED_PLACE_ITEM_EVENTS_FILE = 'saved-place-item-events.jsonl';
export const SAVED_PLACE_PROJECTION_SHARD_KIND = 'iris-maps-saved-place-projection-shard';
export const SAVED_PLACE_INDEX_KIND = 'iris-maps-saved-place-index';

const geohashAlphabet = '0123456789bcdefghjkmnpqrstuvwxyz';
const maxNostrTimestamp = 9_999_999_999;
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

export type SavedPlaceIndexName =
  | 'by-id'
  | 'by-list-time'
  | 'by-list-geohash-time'
  | 'by-list-place-key'
  | 'by-geohash-time'
  | 'by-author-list-time';

export interface SerializedCid {
  hash: string;
  key?: string;
}

export interface SavedPlaceMembershipInput {
  listId: string;
  placeKey: string;
  lat: number;
  lng: number;
  createdAt: number;
  listCoordinate?: string;
  geohashPrecision?: number;
  sourceLayer?: string;
  sourceId?: string;
}

export interface SavedPlaceMembershipEventTemplate {
  kind: typeof SAVED_PLACE_MEMBERSHIP_KIND;
  content: '';
  tags: string[][];
  created_at: number;
}

export interface SavedPlaceProjectionInput extends SavedPlaceMembershipInput {
  eventId: string;
  authorPubkey?: string;
  name?: string;
  type?: string;
}

export interface SavedPlaceItemProjection {
  version: 1;
  id: string;
  listId: string;
  placeKey: string;
  lat: number;
  lng: number;
  geohash: string;
  geohashes: string[];
  createdAt: number;
  eventId: string;
  authorPubkey?: string;
  listCoordinate?: string;
  name?: string;
  type?: string;
  sourceLayer?: string;
  sourceId?: string;
}

export interface SavedPlaceIndexEntry {
  key: string;
  projectionId: string;
}

export type SavedPlaceIndexRows = Record<SavedPlaceIndexName, SavedPlaceIndexEntry[]>;

export interface SavedPlaceProjectionIndex {
  version: 1;
  kind: typeof SAVED_PLACE_INDEX_KIND;
  projectionCount: number;
  projections: Record<string, SavedPlaceItemProjection>;
  indexes: SavedPlaceIndexRows;
}

export interface SavedPlaceProjectionShard {
  version: 1;
  kind: typeof SAVED_PLACE_PROJECTION_SHARD_KIND;
  records: SavedPlaceItemProjection[];
}

export interface SavedPlaceIndexManifest {
  version: 1;
  kind: typeof SAVED_PLACE_INDEX_KIND;
  generatedAt?: string;
  projectionCount: number;
  projectionShardCount: number;
  btreeOrder: number;
  indexRoots: Record<SavedPlaceIndexName, SerializedCid | null>;
  recordPacking: {
    kind: 'json-record-shard';
    version: 1;
    maxRecordsPerShard: number;
  };
}

export interface BuildSavedPlaceHashtreeIndexOptions {
  store?: Store;
  tree?: Pick<HashTree, 'putFile' | 'readFile'>;
  generatedAt?: string;
  btreeOrder?: number;
  maxRecordsPerShard?: number;
}

export interface BuiltSavedPlaceHashtreeIndex {
  store: Store;
  tree: Pick<HashTree, 'putFile' | 'readFile'>;
  manifest: SavedPlaceIndexManifest;
  shardCids: CID[];
}

export interface SavedPlaceBounds {
  west: number;
  south: number;
  east: number;
  north: number;
}

export interface QuerySavedPlacesByListGeohashOptions {
  listId: string;
  geohashPrefix: string;
  limit?: number;
}

export interface QuerySavedPlaceSourceOptions {
  listId: string;
  geohashPrefixes: string[];
  bounds?: SavedPlaceBounds;
  limit?: number;
  scanLimit?: number;
}

export interface SavedPlaceIndexSource {
  manifest: SavedPlaceIndexManifest;
  queryListGeohash(options: QuerySavedPlaceSourceOptions): Promise<SavedPlaceItemProjection[]>;
}

export function savedPlaceProjectionId(listId: string, placeKey: string): string {
  return `${listId}:${placeKey}`;
}

export function encodeGeohash(lat: number, lng: number, precision = 7): string {
  if (!Number.isFinite(lat) || lat < -90 || lat > 90) {
    throw new Error(`invalid geohash latitude: ${lat}`);
  }
  if (!Number.isFinite(lng) || lng < -180 || lng > 180) {
    throw new Error(`invalid geohash longitude: ${lng}`);
  }
  const targetPrecision = Math.max(1, Math.min(12, Math.floor(precision)));
  let latRange: [number, number] = [-90, 90];
  let lngRange: [number, number] = [-180, 180];
  let hash = '';
  let bit = 0;
  let char = 0;
  let evenBit = true;
  const bits = [16, 8, 4, 2, 1];

  while (hash.length < targetPrecision) {
    if (evenBit) {
      const mid = (lngRange[0] + lngRange[1]) / 2;
      if (lng >= mid) {
        char |= bits[bit];
        lngRange = [mid, lngRange[1]];
      } else {
        lngRange = [lngRange[0], mid];
      }
    } else {
      const mid = (latRange[0] + latRange[1]) / 2;
      if (lat >= mid) {
        char |= bits[bit];
        latRange = [mid, latRange[1]];
      } else {
        latRange = [latRange[0], mid];
      }
    }

    evenBit = !evenBit;
    if (bit < 4) {
      bit += 1;
    } else {
      hash += geohashAlphabet[char];
      bit = 0;
      char = 0;
    }
  }

  return hash;
}

export function geohashPrefixes(geohash: string, maxPrecision = geohash.length): string[] {
  const normalized = geohash.trim().toLowerCase();
  const limit = Math.max(1, Math.min(normalized.length, Math.floor(maxPrecision)));
  const prefixes: string[] = [];
  for (let length = 1; length <= limit; length += 1) {
    prefixes.push(normalized.slice(0, length));
  }
  return prefixes;
}

export function reverseTimestamp(createdAt: number): string {
  const timestamp = Math.max(0, Math.min(maxNostrTimestamp, Math.floor(createdAt)));
  return String(maxNostrTimestamp - timestamp).padStart(10, '0');
}

export function serializeCid(cid: CID | null | undefined): SerializedCid | null {
  if (!cid?.hash) return null;
  return {
    hash: toHex(cid.hash),
    ...(cid.key ? { key: toHex(cid.key) } : {}),
  };
}

export function deserializeCid(value: SerializedCid | null | undefined): CID | null {
  if (!value?.hash) return null;
  return {
    hash: hashFromHex(value.hash),
    ...(value.key == null ? {} : { key: objectKeyFromHex(value.key) }),
  };
}

export function cidCacheKey(cid: CID): string {
  return `${toHex(cid.hash)}:${cid.key ? toHex(cid.key) : ''}`;
}

export function buildSavedPlaceMembershipEventTemplate(input: SavedPlaceMembershipInput): SavedPlaceMembershipEventTemplate {
  const geohash = encodeGeohash(input.lat, input.lng, input.geohashPrecision ?? 7);
  const tags: string[][] = [
    ['d', savedPlaceProjectionId(input.listId, input.placeKey)],
    ['l', IRIS_MAPS_LABEL],
    ['l', SAVED_PLACE_MEMBERSHIP_LABEL],
    ['list', input.listId],
    ['i', input.placeKey],
    ['lat', formatCoordinate(input.lat)],
    ['lng', formatCoordinate(input.lng)],
    ...geohashPrefixes(geohash).map((prefix) => ['g', prefix]),
  ];
  if (input.listCoordinate) tags.push(['a', input.listCoordinate]);
  if (input.sourceLayer) tags.push(['source', input.sourceLayer]);
  if (input.sourceId) tags.push(['source_id', input.sourceId]);
  return {
    kind: SAVED_PLACE_MEMBERSHIP_KIND,
    content: '',
    tags,
    created_at: Math.floor(input.createdAt),
  };
}

export function buildSavedPlaceProjection(input: SavedPlaceProjectionInput): SavedPlaceItemProjection {
  const geohash = encodeGeohash(input.lat, input.lng, input.geohashPrecision ?? 7);
  return {
    version: 1,
    id: savedPlaceProjectionId(input.listId, input.placeKey),
    listId: input.listId,
    placeKey: input.placeKey,
    lat: input.lat,
    lng: input.lng,
    geohash,
    geohashes: geohashPrefixes(geohash),
    createdAt: Math.floor(input.createdAt),
    eventId: input.eventId,
    authorPubkey: input.authorPubkey,
    listCoordinate: input.listCoordinate,
    name: input.name,
    type: input.type,
    sourceLayer: input.sourceLayer,
    sourceId: input.sourceId,
  };
}

export function buildByListGeohashTimeKey(projection: SavedPlaceItemProjection, geohashPrefix: string): string {
  return [
    encodeIndexPart(projection.listId),
    encodeIndexPart(geohashPrefix),
    reverseTimestamp(projection.createdAt),
    encodeIndexPart(projection.eventId),
  ].join(':');
}

export function buildSavedPlaceIndexEntries(projection: SavedPlaceItemProjection): SavedPlaceIndexRows {
  const rows = emptyIndexRows();
  rows['by-id'].push({ key: encodeIndexPart(projection.id), projectionId: projection.id });
  rows['by-list-time'].push({
    key: [
      encodeIndexPart(projection.listId),
      reverseTimestamp(projection.createdAt),
      encodeIndexPart(projection.eventId),
    ].join(':'),
    projectionId: projection.id,
  });
  rows['by-list-place-key'].push({
    key: [
      encodeIndexPart(projection.listId),
      encodeIndexPart(projection.placeKey),
      reverseTimestamp(projection.createdAt),
      encodeIndexPart(projection.eventId),
    ].join(':'),
    projectionId: projection.id,
  });
  if (projection.authorPubkey) {
    rows['by-author-list-time'].push({
      key: [
        encodeIndexPart(projection.authorPubkey),
        encodeIndexPart(projection.listId),
        reverseTimestamp(projection.createdAt),
        encodeIndexPart(projection.eventId),
      ].join(':'),
      projectionId: projection.id,
    });
  }
  for (const geohash of projection.geohashes) {
    rows['by-list-geohash-time'].push({
      key: buildByListGeohashTimeKey(projection, geohash),
      projectionId: projection.id,
    });
    rows['by-geohash-time'].push({
      key: [
        encodeIndexPart(geohash),
        reverseTimestamp(projection.createdAt),
        encodeIndexPart(projection.eventId),
      ].join(':'),
      projectionId: projection.id,
    });
  }
  return rows;
}

export function buildSavedPlaceProjectionIndex(projections: SavedPlaceItemProjection[]): SavedPlaceProjectionIndex {
  const index = emptyIndexRows();
  const projectionsById: Record<string, SavedPlaceItemProjection> = {};
  for (const projection of projections) {
    projectionsById[projection.id] = projection;
    const rows = buildSavedPlaceIndexEntries(projection);
    for (const name of savedPlaceIndexNames()) {
      index[name].push(...rows[name]);
    }
  }
  for (const name of savedPlaceIndexNames()) {
    index[name].sort(compareIndexEntries);
  }
  return {
    version: 1,
    kind: SAVED_PLACE_INDEX_KIND,
    projectionCount: Object.keys(projectionsById).length,
    projections: projectionsById,
    indexes: index,
  };
}

export function querySavedPlaceIndexByListGeohash(
  index: SavedPlaceProjectionIndex,
  options: QuerySavedPlacesByListGeohashOptions,
): SavedPlaceItemProjection[] {
  const prefix = `${encodeIndexPart(options.listId)}:${encodeIndexPart(options.geohashPrefix)}:`;
  const limit = options.limit ?? Number.POSITIVE_INFINITY;
  const results: SavedPlaceItemProjection[] = [];
  for (const entry of index.indexes['by-list-geohash-time']) {
    if (!entry.key.startsWith(prefix)) continue;
    const projection = index.projections[entry.projectionId];
    if (!projection) continue;
    results.push(projection);
    if (results.length >= limit) break;
  }
  return results;
}

export async function buildSavedPlaceHashtreeIndex(
  projections: SavedPlaceItemProjection[],
  options: BuildSavedPlaceHashtreeIndexOptions = {},
): Promise<BuiltSavedPlaceHashtreeIndex> {
  const store = options.store ?? new MemoryStore();
  const tree = options.tree ?? new HashTree({ store });
  const maxRecordsPerShard = Math.max(1, Math.floor(options.maxRecordsPerShard ?? 256));
  const btreeOrder = Math.max(3, Math.floor(options.btreeOrder ?? 64));
  const btree = new BTree(store, { order: btreeOrder });
  const sortedProjections = [...projections].sort((left, right) => left.id.localeCompare(right.id));
  const linkEntries = emptyLinkEntries();
  const shardCids: CID[] = [];

  for (let index = 0; index < sortedProjections.length; index += maxRecordsPerShard) {
    const records = sortedProjections.slice(index, index + maxRecordsPerShard);
    const shard: SavedPlaceProjectionShard = {
      version: 1,
      kind: SAVED_PLACE_PROJECTION_SHARD_KIND,
      records,
    };
    const { cid } = await tree.putFile(textEncoder.encode(`${JSON.stringify(shard)}\n`));
    shardCids.push(cid);
    for (const projection of records) {
      const rows = buildSavedPlaceIndexEntries(projection);
      for (const name of savedPlaceIndexNames()) {
        for (const entry of rows[name]) {
          linkEntries[name].push([entry.key, cid]);
        }
      }
    }
  }

  const indexRoots = emptySerializedRoots();
  for (const name of savedPlaceIndexNames()) {
    indexRoots[name] = serializeCid(await btree.buildLinks(linkEntries[name]));
  }

  return {
    store,
    tree,
    manifest: {
      version: 1,
      kind: SAVED_PLACE_INDEX_KIND,
      generatedAt: options.generatedAt,
      projectionCount: sortedProjections.length,
      projectionShardCount: shardCids.length,
      btreeOrder,
      indexRoots,
      recordPacking: {
        kind: 'json-record-shard',
        version: 1,
        maxRecordsPerShard,
      },
    },
    shardCids,
  };
}

export function createSavedPlaceIndexSource(
  manifest: SavedPlaceIndexManifest,
  options: {
    store: Store;
    tree?: Pick<HashTree, 'readFile'>;
  },
): SavedPlaceIndexSource {
  const tree = options.tree ?? new HashTree({ store: options.store });
  const btree = new BTree(options.store, { order: manifest.btreeOrder || 64 });
  const byListGeohashRoot = deserializeCid(manifest.indexRoots['by-list-geohash-time']);
  const shardCache = new Map<string, Promise<Map<string, SavedPlaceItemProjection>>>();

  async function readProjectionShard(cid: CID): Promise<Map<string, SavedPlaceItemProjection>> {
    const cacheKey = cidCacheKey(cid);
    let pending = shardCache.get(cacheKey);
    if (!pending) {
      pending = Promise.resolve(tree.readFile(cid))
        .then((data) => {
          const records = new Map<string, SavedPlaceItemProjection>();
          if (!data) return records;
          const shard = JSON.parse(textDecoder.decode(data)) as Partial<SavedPlaceProjectionShard>;
          if (shard.kind !== SAVED_PLACE_PROJECTION_SHARD_KIND || !Array.isArray(shard.records)) {
            return records;
          }
          for (const record of shard.records) {
            if (isSavedPlaceProjection(record)) records.set(record.eventId, record);
          }
          return records;
        })
        .catch(() => new Map<string, SavedPlaceItemProjection>());
      shardCache.set(cacheKey, pending);
    }
    return await pending;
  }

  return {
    manifest,
    async queryListGeohash(options): Promise<SavedPlaceItemProjection[]> {
      if (!byListGeohashRoot) return [];
      const limit = Math.max(0, Math.floor(options.limit ?? 500));
      if (limit === 0) return [];
      const scanLimit = Math.max(limit, Math.floor(options.scanLimit ?? limit * 8));
      const prefixes = [...new Set(options.geohashPrefixes.map((prefix) => prefix.trim().toLowerCase()).filter(Boolean))];
      const seen = new Set<string>();
      const results: SavedPlaceItemProjection[] = [];
      let scanned = 0;

      for (const geohashPrefix of prefixes) {
        const keyPrefix = `${encodeIndexPart(options.listId)}:${encodeIndexPart(geohashPrefix)}:`;
        for await (const [key, cid] of btree.prefixLinks(byListGeohashRoot, keyPrefix)) {
          if (scanned >= scanLimit || results.length >= limit) break;
          scanned += 1;
          const parsed = parseByListGeohashTimeKey(key);
          const shard = await readProjectionShard(cid);
          const candidates = parsed?.eventId ? [shard.get(parsed.eventId)] : [...shard.values()];
          for (const candidate of candidates) {
            if (!candidate) continue;
            if (seen.has(candidate.id)) continue;
            if (candidate.listId !== options.listId) continue;
            if (!candidate.geohashes.includes(geohashPrefix) && !candidate.geohash.startsWith(geohashPrefix)) continue;
            if (options.bounds && !pointInBounds(candidate, options.bounds)) continue;
            seen.add(candidate.id);
            results.push(candidate);
            if (results.length >= limit) break;
          }
        }
        if (scanned >= scanLimit || results.length >= limit) break;
      }

      return results;
    },
  };
}

export function savedPlaceIndexNames(): SavedPlaceIndexName[] {
  return [
    'by-id',
    'by-list-time',
    'by-list-geohash-time',
    'by-list-place-key',
    'by-geohash-time',
    'by-author-list-time',
  ];
}

function emptyIndexRows(): SavedPlaceIndexRows {
  return {
    'by-id': [],
    'by-list-time': [],
    'by-list-geohash-time': [],
    'by-list-place-key': [],
    'by-geohash-time': [],
    'by-author-list-time': [],
  };
}

function emptyLinkEntries(): Record<SavedPlaceIndexName, Array<[string, CID]>> {
  return {
    'by-id': [],
    'by-list-time': [],
    'by-list-geohash-time': [],
    'by-list-place-key': [],
    'by-geohash-time': [],
    'by-author-list-time': [],
  };
}

function emptySerializedRoots(): Record<SavedPlaceIndexName, SerializedCid | null> {
  return {
    'by-id': null,
    'by-list-time': null,
    'by-list-geohash-time': null,
    'by-list-place-key': null,
    'by-geohash-time': null,
    'by-author-list-time': null,
  };
}

function compareIndexEntries(left: SavedPlaceIndexEntry, right: SavedPlaceIndexEntry): number {
  return left.key.localeCompare(right.key) || left.projectionId.localeCompare(right.projectionId);
}

function encodeIndexPart(value: string): string {
  return encodeURIComponent(value);
}

function decodeIndexPart(value: string): string {
  return decodeURIComponent(value);
}

function parseByListGeohashTimeKey(key: string): {
  listId: string;
  geohashPrefix: string;
  reverseTimestamp: string;
  eventId: string;
} | null {
  const parts = key.split(':');
  if (parts.length !== 4) return null;
  return {
    listId: decodeIndexPart(parts[0]),
    geohashPrefix: decodeIndexPart(parts[1]),
    reverseTimestamp: parts[2],
    eventId: decodeIndexPart(parts[3]),
  };
}

function formatCoordinate(value: number): string {
  return String(Math.round(value * 1_000_000) / 1_000_000);
}

function isSavedPlaceProjection(value: unknown): value is SavedPlaceItemProjection {
  if (!value || typeof value !== 'object') return false;
  const record = value as Partial<SavedPlaceItemProjection>;
  return record.version === 1
    && typeof record.id === 'string'
    && typeof record.listId === 'string'
    && typeof record.placeKey === 'string'
    && typeof record.eventId === 'string'
    && typeof record.geohash === 'string'
    && Array.isArray(record.geohashes)
    && isFiniteNumber(record.lat)
    && isFiniteNumber(record.lng)
    && isFiniteNumber(record.createdAt);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function pointInBounds(point: Pick<SavedPlaceItemProjection, 'lat' | 'lng'>, bounds: SavedPlaceBounds): boolean {
  if (point.lat < bounds.south || point.lat > bounds.north) return false;
  if (bounds.west <= bounds.east) {
    return point.lng >= bounds.west && point.lng <= bounds.east;
  }
  return point.lng >= bounds.west || point.lng <= bounds.east;
}
