import type { MapView } from '../stores/mapsTypes';

export const MAP_VIEW_STORAGE_KEY = 'iris-maps-view';
export const DEFAULT_MAP_VIEW = {
  center: [20, 0],
  zoom: 1,
} as const;

type MapViewStorage = Pick<Storage, 'getItem' | 'setItem'>;

function browserStorage(): MapViewStorage | null {
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null;
  }
}

function defaultMapView(): MapView {
  return {
    center: [DEFAULT_MAP_VIEW.center[0], DEFAULT_MAP_VIEW.center[1]],
    zoom: DEFAULT_MAP_VIEW.zoom,
  };
}

export function loadMapView(storage: MapViewStorage | null = browserStorage()): MapView {
  if (!storage) return defaultMapView();
  try {
    const saved = storage.getItem(MAP_VIEW_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<MapView>;
      if (Array.isArray(parsed.center) && typeof parsed.zoom === 'number') {
        const bounds = Array.isArray(parsed.bounds) && parsed.bounds.length === 4
          ? parsed.bounds as [number, number, number, number]
          : undefined;
        return { center: parsed.center as [number, number], zoom: parsed.zoom, bounds };
      }
    }
  } catch {
    // Ignore unavailable storage, parse errors, and malformed saved views.
  }
  return defaultMapView();
}

export function saveMapView(view: MapView, storage: MapViewStorage | null = browserStorage()) {
  if (!storage) return;
  try {
    storage.setItem(MAP_VIEW_STORAGE_KEY, JSON.stringify(view));
  } catch {
    // Ignore storage errors.
  }
}
