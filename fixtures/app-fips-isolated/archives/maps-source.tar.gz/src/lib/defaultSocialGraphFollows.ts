import socialGraphBinaryUrl from 'nostr-social-graph/data/socialGraph.bin?url';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { isTestMode } from '../stores/settingsDefaults';
import { loadRetainedPublicGraph, watchRetainedPublicGraph, type RetainedPublicGraph } from './publicGraphCache';

export const DEFAULT_SOCIAL_GRAPH_ROOT = '4523be58d395b1b196a9b8c82b038b6895cb02b683d0c253a955068dba1facd0';
let graphPromise: Promise<RetainedPublicGraph> | undefined;

function loadGraph(defaults = false): Promise<RetainedPublicGraph> {
  graphPromise ??= loadRetainedPublicGraph(DEFAULT_SOCIAL_GRAPH_ROOT, async () => {
    const response = await fetch(socialGraphBinaryUrl);
    if (!response.ok) throw new Error(`Default social graph download failed: ${response.status}`);
    return new Uint8Array(await response.arrayBuffer());
  }, undefined, defaults ? DEFAULT_SOCIAL_GRAPH_ROOT : undefined).catch(error => { graphPromise = undefined; throw error; });
  return graphPromise;
}
const follows = (state: RetainedPublicGraph) => [...state.graph.getFollowedByUser(DEFAULT_SOCIAL_GRAPH_ROOT)]
  .filter(pubkey => /^[0-9a-f]{64}$/i.test(pubkey) && !state.graph.getMutedByUser(DEFAULT_SOCIAL_GRAPH_ROOT).has(pubkey));

const normalized = (urls: readonly string[]) => [...new Set(urls.map(url => url.replace(/\/$/, '')))].sort().join(',');
const useDefaults = (relays: string[]) => !isTestMode && normalized(relays) === normalized(DEFAULT_PUBLIC_RELAYS);

export async function loadDefaultSocialGraphFollowPubkeys(relays: string[] = []): Promise<string[]> {
  return follows(await loadGraph(useDefaults(relays)));
}

export function watchDefaultSocialGraphFollows(relays: string[], changed: (pubkeys: string[]) => void): () => void {
  let stopped = false;
  let stop: (() => void) | undefined;
  const defaults = useDefaults(relays);
  void loadGraph(defaults).then(state => {
    if (stopped) return;
    stop = watchRetainedPublicGraph(state, {
      relays: defaults ? ['wss://graph-relay.iris.to', ...relays] : relays,
      authors: () => [DEFAULT_SOCIAL_GRAPH_ROOT],
      changed: () => changed(follows(state)),
    });
  }).catch(() => {});
  return () => { stopped = true; stop?.(); };
}
