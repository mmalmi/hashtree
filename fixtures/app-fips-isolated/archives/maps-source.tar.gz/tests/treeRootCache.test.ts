import { beforeEach, expect, it, vi } from 'vitest';

const account = vi.hoisted(() => ({ npub: 'alice' as string | null }));
vi.mock('../src/TreeRootRegistry', () => ({ treeRootRegistry: { setPublishFn: vi.fn() } }));
vi.mock('../src/refResolver', () => ({ getRefResolver: () => ({ publish }) }));
vi.mock('../src/nostr', () => ({ nostrStore: { getState: () => ({ npub: account.npub }) } }));
vi.mock('../src/utils/route', () => ({ parseRoute: () => ({ params: new URLSearchParams() }) }));
vi.mock('../src/stores/trees', () => ({ getLinkKey: vi.fn(), waitForLinkKeysCache: vi.fn() }));

import { initializePublishFn } from '../src/treeRootCache';
import { treeRootRegistry } from '../src/TreeRootRegistry';
import { getLinkKey, waitForLinkKeysCache } from '../src/stores/trees';
const publish = vi.fn(async () => ({ success: true }));
const record = { hash: new Uint8Array(32), visibility: 'public' as const, dirty: true, updatedAt: 1 };

beforeEach(async () => {
  vi.clearAllMocks();
  account.npub = 'alice';
  await initializePublishFn();
});
const queuedPublish = () => vi.mocked(treeRootRegistry.setPublishFn).mock.calls[0][0];

it('publishes a queued map root under its original account', async () => {
  expect(await queuedPublish()('alice', 'maps', record)).toBe(true);
  expect(publish).toHaveBeenCalledWith('alice/maps', { hash: record.hash }, expect.objectContaining({ visibility: 'public' }));
});

it.each(['bob', null])('does not publish another account’s queued map root after switching to %s', async npub => {
  account.npub = npub;
  expect(await queuedPublish()('alice', 'maps', record)).toBe(false);
  expect(publish).not.toHaveBeenCalled();
});

it('rechecks the account after waiting for a shared tree key', async () => {
  vi.mocked(getLinkKey).mockReturnValueOnce(undefined).mockReturnValueOnce('01'.repeat(32));
  vi.mocked(waitForLinkKeysCache).mockImplementationOnce(async () => { account.npub = 'bob'; });
  expect(await queuedPublish()('alice', 'maps', { ...record, visibility: 'link-visible' })).toBe(false);
  expect(publish).not.toHaveBeenCalled();
});
