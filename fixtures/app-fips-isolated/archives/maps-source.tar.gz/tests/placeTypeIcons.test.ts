import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import {
  PLACE_CATEGORY_OPTIONS,
  PLACE_TYPE_ICON_CLASSES,
  displayPlaceTypeLabel,
  normalizePlaceTypeKey,
  placeTypeIconClass,
} from '../src/lib/placeTypeIcons';

describe('place type icons', () => {
  it('covers app add-place categories with non-default icons where useful', () => {
    expect(PLACE_CATEGORY_OPTIONS.map((option) => option.value)).toEqual([
      'restaurant',
      'cafe',
      'bar',
      'shop',
      'service',
      'attraction',
      'accommodation',
      'transport',
      'other',
    ]);
    expect(placeTypeIconClass('restaurant')).toBe('i-lucide-utensils');
    expect(placeTypeIconClass('accommodation')).toBe('i-lucide-bed');
    expect(placeTypeIconClass('transport')).toBe('i-lucide-car');
  });

  it('maps common BTC Map establishment types to recognizable icons', () => {
    expect(placeTypeIconClass('storefront')).toBe('i-lucide-store');
    expect(placeTypeIconClass('local_atm')).toBe('i-lucide-banknote');
    expect(placeTypeIconClass('local_gas_station')).toBe('i-lucide-fuel');
    expect(placeTypeIconClass('local_cafe')).toBe('i-lucide-coffee');
    expect(placeTypeIconClass('content_cut')).toBe('i-lucide-scissors');
    expect(placeTypeIconClass('medical_services')).toBe('i-lucide-heart-pulse');
    expect(placeTypeIconClass('computer')).toBe('i-lucide-monitor');
    expect(placeTypeIconClass('local_florist')).toBe('i-lucide-flower-2');
  });

  it('normalizes unknown variants and keeps a useful fallback', () => {
    expect(normalizePlaceTypeKey('Local Pizza')).toBe('local_pizza');
    expect(displayPlaceTypeLabel('local_pizza')).toBe('Local Pizza');
    expect(placeTypeIconClass('bitcoin lawyer office')).toBe('i-lucide-briefcase');
    expect(placeTypeIconClass('something_new')).toBe('i-lucide-map-pin');
  });

  it('exports dynamic icon classes for the UnoCSS safelist', () => {
    const iconClasses = new Set(PLACE_TYPE_ICON_CLASSES);
    expect(iconClasses.has(placeTypeIconClass('content_cut'))).toBe(true);
    expect(iconClasses.has(placeTypeIconClass('local_grocery_store'))).toBe(true);
    expect(iconClasses.has(placeTypeIconClass('hotel'))).toBe(true);
    expect(iconClasses.has(placeTypeIconClass('directions_boat'))).toBe(true);

    const unoConfig = fs.readFileSync(new URL('../uno.config.ts', import.meta.url), 'utf8');
    expect(unoConfig).toContain('PLACE_TYPE_ICON_CLASSES');
  });
});
