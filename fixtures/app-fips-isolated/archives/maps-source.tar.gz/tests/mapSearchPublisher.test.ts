import { afterEach, expect, it, vi } from 'vitest';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import { generateSecretKey, getPublicKey, verifyEvent } from 'nostr-tools/pure';
import { nsecEncode } from 'nostr-tools/nip19';
import { loadUploadKey } from '../scripts/map-search-upload-key.mjs';
import { buildIndex, parseArgs } from '../scripts/publish-openfreemap-search-index.mjs';
import { exportRecords } from '../scripts/export-map-search-records.mjs';
import { createMapPlaceSearchSource, deserializeCid, fetchMapPlaceSearchManifest } from '../src/lib/mapSearchIndex';
import { BTree, SearchIndex } from '@hashtree/index';
import type { SearchResult } from '../src/stores/mapsTypes';
import { resultDisplayLine } from '../src/lib/mapSearchResultDetails';
import { verifiedBlockStore } from '../scripts/map-search-block-store.mjs';
import { HashTree, MemoryStore } from '@hashtree/core';
import { searchPlaces, setMapPlaceSearchSourceProvider } from '../src/stores/mapsSearch';

const directories: string[] = [];
async function directory() {
  const dir = await mkdtemp(path.join(tmpdir(), 'maps-publisher-'));
  directories.push(dir);
  return dir;
}
afterEach(async () => {
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
  await Promise.all(directories.splice(0).map(dir => rm(dir, { recursive: true, force: true })));
});

it('keeps every explicit verification query even when the list begins with the defaults', () => {
  const defaults = ['Helsinki', 'Tokyo', 'New York'];
  expect(parseArgs([]).verifyQueries).toEqual(defaults);
  const queries = [...defaults, 'Otakaari'];
  expect(parseArgs(queries.flatMap(query => ['--verify-query', query])).verifyQueries).toEqual(queries);
});

it.each(['missing', 'corrupt'])('refuses a tree with a %s descendant before it can be published', async kind => {
  const store = new MemoryStore();
  const tree = new HashTree({ store });
  const { cid, size } = await tree.putFile(new TextEncoder().encode('preserve this record'));
  const { cid: root } = await tree.putDirectory([{ name: 'record', cid, size }]);
  await store.delete(cid.hash);
  if (kind === 'corrupt') await store.put(cid.hash, new Uint8Array([1, 2, 3]));
  const checked = new HashTree({ store: verifiedBlockStore(store) });
  await expect((async () => { for await (const _block of checked.walkBlocks(root)) { /* exhaust */ } })())
    .rejects.toThrow('Missing or corrupt source block');
});

it('builds and recovers a location-scoped index without crowding out country searches', async () => {
  const dir = await directory();
  const street = { id: '999-road', name: 'Main Street', lat: 60.18, lng: 24.83,
    type: 'road', class: 'highway', displayName: 'Street',
    contextParts: ['Espoo', 'Uusimaa', 'Finland'], contextAliases: ['Suomi'], contextScopes: ['Espoo'] };
  const records = [
    ...Array.from({ length: 90 }, (_, i) => ({ ...street, id: `100-road-${String(i).padStart(3, '0')}`, contextParts: ['Helsinki', 'Finland'], contextScopes: ['Helsinki'] })),
    { ...street, id: '200-country', name: 'Finland', type: 'country', class: 'place', displayName: 'Country', contextParts: [], contextScopes: [] },
    { ...street, id: '998-road', name: 'Otakaari' }, street,
  ];
  const run = path.join(dir, 'records.jsonl');
  await writeFile(run, records.map(record => JSON.stringify({ key: record.id, quality: 0, record })).join('\n'));
  const options = parseArgs(['--out', dir, '--skip-publish']);
  const built = await buildIndex(options, { recordRuns: [run], header: {}, metadata: {}, stats: {},
    contextSource: { kind: 'administrative-boundary-context', records: records.length } });
  const source = createMapPlaceSearchSource(built.manifest, built);
  expect((await source.search('Main Street, Espoo', 10)).map(r => r.id)).toEqual([street.id]);
  expect((await source.search('Main Street Espoo', 10)).map(r => r.id)).toEqual([street.id]);
  expect((await source.search('Otakaari Espoo', 10)).map(r => r.name)).toEqual(['Otakaari']);
  expect(await source.search('Otakaari, Helsinki', 10)).toEqual([]);
  expect((await source.search('Main Street, Espoo, Suomi', 10)).map(r => r.id)).toEqual([street.id]);
  expect((await source.search('Finland', 10)).map(r => r.name)).toEqual(['Finland']);
  expect(resultDisplayLine((await source.search('Otakaari'))[0])).toBe('Otakaari, Espoo, Uusimaa, Finland');
  const clearSource = setMapPlaceSearchSourceProvider(() => source);
  try {
    const view = { center: [60.17, 24.94] as [number, number], zoom: 2 };
    for (const query of ['Otakaari, Espoo', 'Otakaari Espoo']) {
      expect((await searchPlaces(query, view, null)).map(result => result.name)).toEqual(['Otakaari']);
    }
    expect(await searchPlaces('Otakaari, Helsinki', view, null)).toEqual([]);
  } finally { clearSource(); }
  const recovered = [];
  for await (const record of exportRecords(built.manifest, built.store)) recovered.push(record);
  expect(recovered).toHaveLength(records.length);
  expect(recovered.find(r => r.id === street.id)).toMatchObject({ contextAliases: ['Suomi'], contextParts: street.contextParts });
});

it.each([8, 96, 512])('ranks a native-script city above %i incidental ferry matches', async ferryCount => {
  const dir = await directory();
  // The city and route names reproduce the retained public search failure.
  // Route punctuation indexes 東京 as a complete word; 東京都 is a prefix match.
  const city = { id: '900-city', name: '東京都', aliases: ['Tokyo'], lat: 35.676864, lng: 139.763893,
    type: 'city', class: 'place', displayName: 'City', addressType: 'city',
    placeRank: 1, importance: 0.9867, contextParts: ['Tokyo', 'Japan'], contextScopes: ['Japan'] };
  const ferries = Array.from({ length: ferryCount }, (_, i) => ({
    id: `100-ferry-${String(i).padStart(4, '0')}`, name: '東京～三宅島・御蔵島・八丈島航路',
    lat: 35.45, lng: 139.63, type: 'ferry', class: 'highway', displayName: 'Ferry',
    contextParts: ['Yokosuka', 'Kanagawa Prefecture', 'Japan'], contextScopes: ['Japan'],
  }));
  // An ordinary `city` keyword lookup is also bounded and cannot act as a
  // place-specific name index when unrelated cities fill its candidate pool.
  const otherCities = Array.from({ length: 96 }, (_, i) => ({
    ...city, id: `050-city-${String(i).padStart(4, '0')}`, name: `Other City ${i}`, aliases: [], contextParts: [],
  }));
  const records = [...otherCities, ...ferries, city];
  const run = path.join(dir, 'records.jsonl');
  await writeFile(run, records.map(record => JSON.stringify({ key: record.id, quality: 0, record })).join('\n'));
  const built = await buildIndex(parseArgs(['--out', dir, '--skip-publish', '--record-shard-size', '1']), {
    recordRuns: [run], header: {}, metadata: {}, stats: {},
    contextSource: { kind: 'administrative-boundary-context', records: records.length },
  });
  const source = createMapPlaceSearchSource(built.manifest, built);
  const view = { center: [60.17, 24.94] as [number, number], zoom: 2 };
  const scanned = new Map<string, number>();
  const prefixLinks = BTree.prototype.prefixLinks;
  vi.spyOn(BTree.prototype, 'prefixLinks').mockImplementation(async function* (root, prefix) {
    for await (const entry of prefixLinks.call(this, root, prefix)) {
      scanned.set(prefix, (scanned.get(prefix) ?? 0) + 1);
      yield entry;
    }
  });
  const readFile = vi.spyOn(built.tree, 'readFile');
  const candidates = await source.search('東京', 50);
  expect(candidates[0]).toMatchObject({ id: city.id });
  expect(candidates.filter(result => result.id === city.id)).toHaveLength(1);
  expect(candidates).toHaveLength(Math.min(50, ferryCount + 1));
  // Actual B-tree iteration includes at most one lookahead beyond the 80-posting cap.
  expect(scanned.get('n:東京')).toBe(1);
  expect(scanned.get('p:東京')).toBeLessThanOrEqual(81);
  expect(readFile.mock.calls.length).toBe(Math.min(ferryCount + 1, 81));
  expect((await source.search('東京', 1)).map(result => result.id)).toEqual([city.id]);

  // Prove that scoring already prefers the city when it reaches the ranker.
  let clearSource = setMapPlaceSearchSourceProvider(() => ({ ...source, search: async () => records }));
  try {
    expect((await searchPlaces('東京', view, null))[0]).toMatchObject({ id: city.id });
    clearSource();
    clearSource = setMapPlaceSearchSourceProvider(() => source);
    expect((await searchPlaces('Tokyo', view, null))[0]).toMatchObject({ id: city.id });
    expect((await searchPlaces('東京都', view, null))[0]).toMatchObject({ id: city.id });
    expect((await searchPlaces('東京', view, null))[0]).toMatchObject({ id: city.id });
    expect((await searchPlaces('東京, Japan', view, null))[0]).toMatchObject({ id: city.id });
  } finally {
    clearSource();
  }
}, 30_000);

async function buildSyntheticIndex(records: Array<SearchResult & { id: string }>, shardSize = 1) {
  const dir = await directory();
  const run = path.join(dir, 'records.jsonl');
  await writeFile(run, records.map(record => JSON.stringify({ key: record.id, quality: 0, record })).join('\n'));
  return buildIndex(parseArgs(['--out', dir, '--skip-publish', '--record-shard-size', String(shardSize)]), {
    recordRuns: [run], header: {}, metadata: {}, stats: {},
  });
}

it('round-trips name-only settlement and administrative postings using the original record CIDs', async () => {
  const city = { id: 'city-seoul', name: '서울특별시', aliases: ['서울', 'Seoul'], lat: 37.57, lng: 126.98,
    type: 'city', class: 'place', addressType: 'city', displayName: 'City', contextParts: ['South Korea'] };
  const boundary = { ...city, id: 'region-gyeonggi', name: '경기도', aliases: ['Gyeonggi'],
    type: 'administrative', class: 'boundary', addressType: 'state', displayName: 'Region' };
  const decoys = [
    { ...city, id: 'ferry', name: '서울～부산', aliases: ['Seoul ferry'], type: 'ferry', class: 'highway', addressType: 'road' },
    { ...city, id: 'park', name: '서울 도시공원', aliases: [], type: 'city_park', class: 'leisure', addressType: 'park' },
    { ...city, id: 'cafe', name: '서울 카페', aliases: [], type: 'city', class: 'amenity', addressType: 'cafe' },
  ];
  const town = { ...city, id: 'town', name: '서울동', aliases: [], type: 'town', addressType: 'town' };
  const records = [city, boundary, town, ...decoys];
  const built = await buildSyntheticIndex(records, 512);
  const manifest = await fetchMapPlaceSearchManifest(`data:application/json,${encodeURIComponent(JSON.stringify(built.manifest))}`);
  expect(manifest.placeNames).toEqual({ version: 1, prefix: 'n:' });
  expect(manifest.placeCount).toBe(records.length);
  expect(built.manifest.byIdEntryCount).toBe(records.length);
  const btree = new BTree(built.store, { order: 64 });
  const root = deserializeCid(manifest.searchRoot)!;
  const byIdRoot = deserializeCid(manifest.byIdRoot)!;
  let entryCount = 0;
  const names: string[] = [];
  for await (const [key, cid] of btree.verifiedLinksEntries(root)) {
    entryCount += 1;
    if (!key.startsWith('n:')) continue;
    names.push(key);
    const id = key.slice(key.indexOf(':', 2) + 1);
    expect([city.id, boundary.id, town.id]).toContain(id);
    expect(cid).toEqual(await btree.getLink(byIdRoot, id));
  }
  expect(entryCount).toBe(built.manifest.searchEntryCount);
  expect(built.manifest.searchEntryCandidates).toBe(entryCount);
  expect(names).toEqual(expect.arrayContaining(['n:서울:city-seoul', 'n:서울특별시:city-seoul', 'n:seoul:city-seoul', 'n:경기도:region-gyeonggi']));
  expect(names.some(key => /^n:(city|state|south|korea):/.test(key))).toBe(false);
  const readFile = vi.spyOn(built.tree, 'readFile');
  const source = createMapPlaceSearchSource(manifest, built);
  expect((await source.search('서울', 10)).map(result => result.id)).toEqual([city.id, town.id, 'cafe', 'ferry', 'park']);
  expect(readFile).toHaveBeenCalledTimes(1); // Distinct records in one shared shard survive; duplicate city candidates do not.
  for (const query of ['Seoul', '서울특별시']) {
    expect((await source.search(query, 1))[0]?.id).toBe(city.id);
  }
  expect((await source.search('경기', 1))[0]?.id).toBe(boundary.id);
  const clearSource = setMapPlaceSearchSourceProvider(() => source);
  try {
    for (const query of ['서울', 'Seoul', '경기']) {
      expect((await searchPlaces(query, { center: [37.57, 126.98], zoom: 2 }, null))[0]?.id)
        .toBe(query === '경기' ? boundary.id : city.id);
    }
  } finally { clearSource(); }
  const recovered = [];
  for await (const record of exportRecords(built.manifest, built.store)) recovered.push(record);
  expect(recovered.map(record => record.id).sort()).toEqual(records.map(record => record.id).sort());
});

it('retains bounded legacy search without the capability and ignores unsupported capability versions', async () => {
  const city = { id: '900-city', name: '東京都', aliases: ['Tokyo'], lat: 35.68, lng: 139.76,
    type: 'city', class: 'place', displayName: 'City' };
  const built = await buildSyntheticIndex([
    ...Array.from({ length: 96 }, (_, i) => ({ ...city, id: `100-ferry-${i}`, name: '東京～離島航路', aliases: [], type: 'ferry', class: 'highway' })),
    city,
  ]);
  for (const placeNames of [undefined, null, 'n:', {}, { version: 2, prefix: 'n:' }, { version: 1, prefix: 'p:' }]) {
    const raw = { ...built.manifest, placeNames };
    const parsed = await fetchMapPlaceSearchManifest(`data:application/json,${encodeURIComponent(JSON.stringify(raw))}`);
    expect(parsed.placeNames).toBeUndefined();
    // Direct callers and fetched manifests both reject unsupported namespaces.
    for (const manifest of [raw, parsed]) {
      const source = createMapPlaceSearchSource(manifest, built);
      const scan = vi.spyOn(SearchIndex.prototype, 'searchLinkTerms');
      expect((await source.search('Tokyo', 1))[0]?.id).toBe(city.id);
      expect((await source.search('東京', 10)).map(record => record.type)).toEqual(Array(10).fill('ferry'));
      expect(scan.mock.calls.every(call => call[1] === 'p:')).toBe(true);
      scan.mockRestore();
    }
  }
});

it('does no index work for empty queries or disabled limits and bounds a no-match lookup', async () => {
  const built = await buildSyntheticIndex([{ id: 'city', name: '서울', lat: 37.57, lng: 126.98,
    type: 'city', class: 'place', displayName: 'City' }]);
  const source = createMapPlaceSearchSource(built.manifest, built);
  const scan = vi.spyOn(SearchIndex.prototype, 'searchLinkTerms');
  const read = vi.spyOn(built.tree, 'readFile');
  for (const query of ['', '   ', '?!']) expect(await source.search(query)).toEqual([]);
  expect(await source.search('서울', 0)).toEqual([]);
  expect(await source.search('서울', -1)).toEqual([]);
  expect(scan).not.toHaveBeenCalled();
  expect(await source.search('없는도시')).toEqual([]);
  expect(scan).toHaveBeenCalledTimes(2);
  expect(read).not.toHaveBeenCalled();
  expect(await createMapPlaceSearchSource({ ...built.manifest, searchRoot: null }, built).search('서울')).toEqual([]);
});

it('reuses the configured identity across uploads and supports an explicit storage identity', async () => {
  const dir = await directory();
  const publisher = generateSecretKey();
  const storage = generateSecretKey();
  await writeFile(path.join(dir, 'keys'), nsecEncode(publisher));
  await writeFile(path.join(dir, 'storage-key'), nsecEncode(storage));
  vi.stubEnv('HTREE_CONFIG_DIR', dir);
  expect(getPublicKey(await loadUploadKey())).toBe(getPublicKey(publisher));
  expect(getPublicKey(await loadUploadKey())).toBe(getPublicKey(publisher));
  expect(getPublicKey(await loadUploadKey(path.join(dir, 'storage-key')))).toBe(getPublicKey(storage));
});

it.each(['publish-map-search-index.mjs', 'publish-openfreemap-search-index.mjs'])(
  '%s rejects invalid credentials before starting a build without leaking their contents', async script => {
    const dir = await directory();
    const keyFile = path.join(dir, 'invalid-key');
    const invalid = 'invalid-private-key-content';
    await writeFile(keyFile, invalid);
    try {
      await promisify(execFile)(process.execPath, [path.resolve('scripts', script), '--upload-key-file', keyFile, '--out', path.join(dir, 'output')]);
      throw new Error('Publisher accepted an invalid key');
    } catch (error) {
      const stderr = (error as { stderr?: string }).stderr;
      expect(stderr).toContain('Invalid upload signing key');
      expect(stderr).not.toContain(invalid);
    }
  },
);

it('uploads a real small index with the selected storage identity', async () => {
  const dir = await directory();
  const secret = generateSecretKey();
  const keyFile = path.join(dir, 'keys');
  await writeFile(keyFile, nsecEncode(secret));
  const labels = path.join(dir, 'labels.json');
  await writeFile(labels, JSON.stringify({ kind: 'iris-maps-labels', labels: [
    { name: 'Helsinki', lat: 60.17, lng: 24.94, kind: 'city' },
  ] }));
  const authors: string[] = [];
  const server = createServer(async (request, response) => {
    if (request.method !== 'PUT') { response.writeHead(404).end(); return; }
    const event = JSON.parse(Buffer.from(request.headers.authorization!.slice(6), 'base64').toString());
    if (!verifyEvent(event)) { response.writeHead(401).end(); return; }
    authors.push(event.pubkey);
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const data = Buffer.concat(chunks);
    response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({
      sha256: createHash('sha256').update(data).digest('hex'), size: data.length,
    }));
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  try {
    const { stdout } = await promisify(execFile)(process.execPath, [
      path.resolve('scripts/publish-map-search-index.mjs'), '--labels', labels,
      '--out', path.join(dir, 'output'), '--upload-key-file', keyFile,
      '--blossom-servers', url, '--blossom-write-servers', url, '--skip-ref-publish',
    ]);
    expect(JSON.parse(stdout).push.failed).toBe(0);
    expect(JSON.parse(stdout).publish).toBeNull();
    expect(authors.length).toBeGreaterThan(0);
    expect(new Set(authors)).toEqual(new Set([getPublicKey(secret)]));
    const offline = await promisify(execFile)(process.execPath, [
      path.resolve('scripts/publish-map-search-index.mjs'), '--labels', labels,
      '--out', path.join(dir, 'offline'), '--upload-key-file', path.join(dir, 'missing'), '--skip-publish',
    ]);
    expect(JSON.parse(offline.stdout).push).toBeNull();
  } finally {
    server.closeAllConnections();
    await new Promise<void>(resolve => server.close(() => resolve()));
  }
});
