import { describe, expect, it } from 'vitest';
import {
  loadSavedExternalPlaceLists,
  removeSavedExternalPlaceList,
  savedExternalPlaceListHash,
  savedExternalPlaceListKey,
  saveSavedExternalPlaceLists,
  upsertSavedExternalPlaceList,
} from '../src/lib/savedExternalPlaceLists';

const listId = '8b9d8384-c005-426d-974d-4141be760bff';
const ownerNpub = 'npub169qdxhs922fn02z6crylner0h3l7ydhvahm3npzhlewclkjv7las3mh2at';

class MemoryStorage implements Storage {
  private values = new Map<string, string>();
  length = 0;

  clear(): void {
    this.values.clear();
    this.length = 0;
  }

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  key(index: number): string | null {
    return [...this.values.keys()][index] ?? null;
  }

  removeItem(key: string): void {
    this.values.delete(key);
    this.length = this.values.size;
  }

  setItem(key: string, value: string): void {
    this.values.set(key, value);
    this.length = this.values.size;
  }
}

describe('saved external place lists', () => {
  it('persists public list references without cloning places', () => {
    const storage = new MemoryStorage();
    const saved = saveSavedExternalPlaceLists(
      upsertSavedExternalPlaceList([], {
        id: listId,
        name: 'BTC Map',
        ownerNpub,
        treeName: 'btcmap',
        icon: 'map-pin',
        placeCount: 28_412,
        savedAt: 1_716_595_200_123,
      }),
      storage,
    );

    expect(saved).toHaveLength(1);
    expect(saved[0]).toMatchObject({
      id: listId,
      name: 'BTC Map',
      ownerNpub,
      treeName: 'btcmap',
      placeCount: 28_412,
    });
    expect(saved[0]).not.toHaveProperty('places');
    expect(loadSavedExternalPlaceLists(storage)).toEqual(saved);
  });

  it('dedupes, removes, and builds route hashes by list owner', () => {
    const saved = upsertSavedExternalPlaceList(
      upsertSavedExternalPlaceList([], {
        id: listId,
        name: 'BTC Map',
        ownerNpub,
        treeName: 'btcmap',
        icon: 'bookmark',
        savedAt: 1,
      }),
      {
        id: listId,
        name: 'BTC Map refreshed',
        ownerNpub,
        treeName: 'btcmap',
        icon: 'map-pin',
        savedAt: 2,
      },
    );

    expect(saved).toHaveLength(1);
    expect(saved[0].name).toBe('BTC Map refreshed');
    expect(saved[0].savedAt).toBe(1);
    expect(savedExternalPlaceListKey(saved[0])).toBe(`${ownerNpub}/btcmap/${listId}`);
    expect(savedExternalPlaceListHash(saved[0])).toBe(`#/?list=${listId}&owner=${ownerNpub}&tree=btcmap`);
    expect(removeSavedExternalPlaceList(saved, saved[0])).toEqual([]);
  });
});
