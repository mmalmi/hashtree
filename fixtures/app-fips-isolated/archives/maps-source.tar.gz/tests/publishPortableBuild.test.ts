import { afterEach, describe, expect, it, vi } from 'vitest';
import { createPublishPlan } from '../scripts/publish-iris-build.mjs';

describe('publish-iris-build', () => {
  afterEach(() => vi.unstubAllEnvs());
  it('supports maps portable publish plans', () => {
    expect(createPublishPlan('maps')).toMatchObject({
      name: 'maps',
      appName: 'Iris Maps',
      distDir: 'dist-maps',
      treeName: 'maps',
    });
  });

  it('publishes the selected tree name from the matching dist directory', () => {
    vi.stubEnv('HTREE_BIN', '/test/bin/htree');
    const command = createPublishPlan('maps').command;
    expect(command.slice(-4)).toEqual(['add', '.', '--publish', 'maps']);

    expect(command).toEqual(['/test/bin/htree', 'add', '.', '--publish', 'maps']);

    expect(createPublishPlan('maps').distDir).toMatch(/dist-maps$/);
  });
});
