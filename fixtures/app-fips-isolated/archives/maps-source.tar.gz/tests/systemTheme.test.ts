import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const appRoot = path.resolve(process.cwd());
const unoConfigPath = path.join(appRoot, 'uno.config.ts');
const themeCssPath = path.join(appRoot, 'src/system-theme.css');
const mapsHomePath = path.join(appRoot, 'src/components/Maps/MapsHome.svelte');
const mapSearchPath = path.join(appRoot, 'src/components/Maps/MapSearch.svelte');
const addPlaceModalPath = path.join(appRoot, 'src/components/Maps/AddPlaceModal.svelte');
const defaultSocialGraphFollowsPath = path.join(appRoot, 'src/lib/defaultSocialGraphFollows.ts');
const htmlFiles = [
  'maps.html',
].map((file) => path.join(appRoot, file));

describe('system theme wiring', () => {
  it('uses CSS variables for semantic surface and text colors', () => {
    const unoConfig = fs.readFileSync(unoConfigPath, 'utf8');
    expect(unoConfig).toContain("0: 'rgb(var(--surface-0) / <alpha-value>)'");
    expect(unoConfig).toContain("1: 'rgb(var(--surface-1) / <alpha-value>)'");
    expect(unoConfig).toContain("3: 'rgb(var(--surface-3) / <alpha-value>)'");
    expect(unoConfig).toContain("1: 'rgb(var(--text-1) / <alpha-value>)'");
    expect(unoConfig).toContain("3: 'rgb(var(--text-3) / <alpha-value>)'");
  });

  it('publishes light and dark theme colors in every entry html', () => {
    const themeCss = fs.readFileSync(themeCssPath, 'utf8');
    expect(themeCss).toContain('color-scheme: light dark;');
    expect(themeCss).toContain('--surface-0: 245 245 245;');
    expect(themeCss).toContain('--surface-0: 15 15 15;');
    expect(themeCss).toContain('--map-tile-filter: none;');
    expect(themeCss).toContain('--map-tile-filter: brightness(0.72) saturate(0.78);');
    for (const htmlPath of htmlFiles) {
      const html = fs.readFileSync(htmlPath, 'utf8');
      expect(html).toContain('<meta name="theme-color" content="#0f0f0f" media="(prefers-color-scheme: dark)">');
      expect(html).toContain('<meta name="theme-color" content="#f5f5f5" media="(prefers-color-scheme: light)">');
      expect(html).toContain('<link rel="stylesheet" href="./src/system-theme.css" />');
      expect(html).not.toContain('<html lang="en" class="dark">');
    }
  });

  it('themes MapLibre surfaces through map-style color variables', () => {
    const mapsHome = fs.readFileSync(mapsHomePath, 'utf8');
    expect(mapsHome).toContain("iris-map-theme-{mapChromeTheme}");
    expect(mapsHome).toContain("isDarkMapBasemapStyle(resolveMapBasemapStyle(mapStylePreference)) ? 'dark' : 'light'");
    expect(mapsHome).toContain('.iris-map-theme-light');
    expect(mapsHome).toContain('.iris-map-theme-dark');
    expect(mapsHome).toContain('background: rgb(var(--surface-0));');
    expect(mapsHome).toContain(':global(.maplibregl-ctrl-attrib)');
    expect(mapsHome).toContain('collapseAttributionControl');
    expect(mapsHome).toContain('markNavigationControl');
    expect(mapsHome).toContain('.iris-map-navigation-control');
    expect(mapsHome).toContain('@media (max-width: 640px), (hover: none) and (pointer: coarse)');
    expect(mapsHome).toContain("classList.remove('maplibregl-compact-show')");
    expect(mapsHome).toContain('background: rgb(var(--surface-1)) !important;');
    expect(mapsHome).toContain('color: rgb(var(--text-1)) !important;');
  });

  it('keeps saved-list library overlays explicit', () => {
    const mapsHome = fs.readFileSync(mapsHomePath, 'utf8');
    const mapSearch = fs.readFileSync(mapSearchPath, 'utf8');
    expect(mapSearch).toContain('onOpenLibrary');
    expect(mapSearch).toContain("placeholder = 'Search'");
    expect(mapSearch).not.toContain('Search location');
    expect(mapSearch).toContain('i-lucide-menu');
    expect(mapSearch).not.toContain('i-lucide-library');
    expect(mapsHome).toContain('data-testid="maps-library-panel"');
    expect(mapsHome).toContain('data-testid="library-list-index"');
    expect(mapsHome).toContain('data-testid={`library-list-${savedListSlug(list.name)}`}');
    expect(mapsHome).toContain('libraryOverlayListIds');
    expect(mapsHome).toContain('maxLibraryOverlayLists = 4');
    expect(mapsHome).toContain('data-testid="library-overlay-stack"');
    expect(mapsHome).toContain('type="checkbox"');
    expect(mapsHome).toContain("title={isLibraryListOverlaid(list) ? 'Hide from map' : 'Show on map'}");
    expect(mapsHome).toContain('onclick={() => openOwnSavedPlaceList(list)}');
    expect(mapsHome).toContain('routedSavedPlaceList = list;');
    expect(mapsHome).toContain('savedPlaceListToggleMetaText(list)');
    expect(mapsHome).toContain('data-testid="map-context-measure-distance"');
    expect(mapsHome).toContain('data-testid="measure-distance-panel"');
    expect(mapsHome).toContain('calculateMeasureDistanceMeters(measureDistancePoints)');
    expect(mapsHome).toContain("const measureDistanceSourceId = 'iris-map-measure-distance-source'");
    expect(mapsHome).toContain("map.on('styledata', syncMeasureDistanceOverlay)");
    expect(mapsHome).toContain("window.matchMedia('(max-width: 767px)')");
    expect(mapsHome).toContain('let isLeftPanelVisuallyMinimized = $derived(Boolean(showingLeftPanel && isCompactViewport && isLeftPanelMinimized))');
    expect(mapsHome).toContain('let isLeftPanelMapObscuring = $derived(Boolean(showingLeftPanel && !isLeftPanelVisuallyMinimized))');
    expect(mapsHome).toContain('data-testid="left-panel-minimize"');
    expect(mapsHome).toContain('data-testid="left-panel-restore"');
    expect(mapsHome).toContain('minimizedLeftPanelTitle()');
    expect(mapsHome).toContain('left: isLeftPanelMapObscuring ? 456 : 72');
    expect(mapsHome).toContain('let canReviewActivePlace = $derived(Boolean(');
    expect(mapsHome).toContain('activePlaceCanHaveReviews');
    expect(mapsHome).not.toContain("activePlace.source === 'place' || mapsStore.places.some");
    expect(mapsHome).toContain('nostr.subscribe(filter, { closeAfterHistory: false })');
    expect(mapsHome).not.toContain('appendPlaceTypeIcon(marker, item.type ?? item.displayName)');
    expect(mapsHome).not.toContain('appendPlaceTypeIcon(marker, place.category)');
    expect(mapsHome).not.toContain('iris-map-marker-icon');
    expect(mapsHome).not.toContain("{isLibraryListOverlaid(list) ? 'i-lucide-eye-off' : 'i-lucide-map'}");
    expect(mapsHome).not.toContain('aria-label="List options"');
    expect(mapsHome).not.toContain('- {list.places.length}');
    const customMarkerRule = mapsHome.match(/:global\(\.iris-map-place-marker\),\s*:global\(\.iris-map-active-marker\),\s*:global\(\.iris-map-saved-list-marker\)\s*\{[\s\S]*?\n  \}/)?.[0] ?? '';
    expect(customMarkerRule).toContain('position: absolute;');
    expect(customMarkerRule).not.toContain('position: relative;');
    expect(customMarkerRule).toContain('--iris-map-pin-head-size: 22px;');
    expect(customMarkerRule).toContain('--iris-map-pin-dot-size: 8px;');
    expect(customMarkerRule).toContain('color: #ef4444;');
    expect(mapsHome).toContain('--iris-map-pin-head-size: 28px;');
    expect(mapsHome).toContain('--iris-map-pin-dot-size: 10px;');
    expect(mapsHome).toContain('top: calc(var(--iris-map-pin-head-top) + var(--iris-map-pin-head-radius) - var(--iris-map-pin-dot-radius));');
    expect(mapsHome).toContain('background: #ef4444;');
    expect(mapsHome).not.toContain('background: #f97316;');
    expect(mapsHome).toContain('--iris-map-pin-border: #111827;');
    expect(mapsHome).toContain('scale(1.35)');
    expect(mapsHome).not.toContain('scale(1.45)');
    expect(mapsHome).not.toContain('--iris-map-list-marker-glow');
    expect(mapsHome).not.toContain('linear-gradient(135deg, #38bdf8');
    expect(mapsHome).not.toContain('No follows loaded.');
    expect(mapsHome).toContain('requestDefaultDiscoverFollows');
    expect(mapsHome).toContain('discoverAuthorsKey(authors)');
    expect(mapsHome).toContain('followingDiscoverActiveAuthorsKey');
    expect(mapsHome).toContain('otherDiscoverActiveAuthorsKey');
    expect(mapsHome).toContain('if (authorsKey === followingDiscoverActiveAuthorsKey) return;');
    expect(mapsHome).toContain('if (authorsKey === otherDiscoverActiveAuthorsKey) return;');
    expect(mapsHome).toContain('data-testid="library-discover-following"');
    expect(mapsHome).toContain('data-testid="library-discover-others"');
    expect(mapsHome).toContain('data-testid="saved-external-list-toggle"');
    expect(mapsHome).toContain('data-testid="library-saved-external-lists"');
    expect(mapsHome).toContain('Saved public lists');
    expect(mapsHome).toContain('upsertSavedExternalPlaceList');
    expect(mapsHome).toContain('savedExternalPlaceListHash(list)');
    expect(mapsHome).toContain("return parts.join(' · ') || 'Public list';");
    expect(mapsHome).not.toContain('shortNpub');
    expect(mapsHome).not.toContain('shortNpub(list.ownerNpub)');
    expect(mapsHome).toContain("const btcMapCrawlerPubkey = 'd140d35e05529337a85ac0c9f9e46fbc7fe236ecedf7198457fe5d8fda4cf7fb'");
    expect(mapsHome).toContain("const btcMapSavedPlaceListId = '8b9d8384-c005-426d-974d-4141be760bff'");
    expect(mapsHome).toContain('BTC Map');
    expect(mapsHome).toContain('visibleOtherDiscoveredSavedPlaceLists');
    const followingHeader = mapsHome.slice(
      mapsHome.indexOf('<h3 class="min-w-0 flex-1 truncate text-sm font-semibold text-text-1">Following</h3>'),
      mapsHome.indexOf('{#if isFollowingDiscoverOpen}'),
    );
    expect(followingHeader.indexOf('followingDiscoveredSavedPlaceLists.length')).toBeLessThan(
      followingHeader.indexOf("followingDiscoveredListStatus === 'loading'"),
    );
    const othersHeader = mapsHome.slice(
      mapsHome.indexOf('<h3 class="min-w-0 flex-1 truncate text-sm font-semibold text-text-1">Others</h3>'),
      mapsHome.indexOf('{#if isOtherDiscoverOpen}'),
    );
    expect(othersHeader.indexOf('visibleOtherDiscoveredSavedPlaceLists.length')).toBeLessThan(
      othersHeader.indexOf("otherDiscoveredListStatus === 'loading'"),
    );
    expect(mapsHome).not.toContain('<h3 class="text-sm font-semibold text-text-1">About</h3>');
    expect(fs.readFileSync(defaultSocialGraphFollowsPath, 'utf8')).toContain('DEFAULT_SOCIAL_GRAPH_ROOT');
  });

  it('keeps the add-place panel on semantic map theme colors', () => {
    const mapsHome = fs.readFileSync(mapsHomePath, 'utf8');
    const addPlaceModal = fs.readFileSync(addPlaceModalPath, 'utf8');
    expect(mapsHome.indexOf('<div class="iris-map-theme-{mapChromeTheme}')).toBeLessThan(mapsHome.indexOf('<AddPlaceModal />'));
    expect(addPlaceModal).toContain('top-24');
    expect(addPlaceModal).toContain('max-h-[calc(100vh-7rem)]');
    expect(addPlaceModal).toContain('bg-surface-1/94');
    expect(addPlaceModal).toContain('shadow-sm');
    expect(addPlaceModal).toContain('text-text-1');
    expect(addPlaceModal).toContain('border-transparent');
    expect(addPlaceModal).toContain('focus:ring-accent/25');
    expect(addPlaceModal).toContain('rounded-full');
    expect(addPlaceModal).toContain('<select');
    expect(addPlaceModal).not.toContain('role="radiogroup"');
    expect(addPlaceModal).not.toContain('grid grid-cols-3');
  });
});
