import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { describe, expect, test, vi } from 'vitest';
import { WorkerAdapter } from '../src/workerAdapter';

type PostedMessage = {
  message: Record<string, unknown>;
  transfer?: Transferable[];
};

class FakeWorker {
  static latest: FakeWorker | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: ErrorEvent) => void) | null = null;
  readonly posted: PostedMessage[] = [];

  constructor() {
    FakeWorker.latest = this;
  }

  postMessage(message: Record<string, unknown>, transfer?: Transferable[]): void {
    this.posted.push({ message, transfer });
  }

  terminate(): void {}

  emit(message: Record<string, unknown>): void {
    this.onmessage?.({ data: message } as MessageEvent);
  }
}

async function initializedAdapter(relays: string[] = ['wss://relay.example']): Promise<{ adapter: WorkerAdapter; worker: FakeWorker }> {
  const adapter = new WorkerAdapter(FakeWorker as unknown as new () => Worker, {
    relays,
    pubkey: '11'.repeat(32),
  });
  const init = adapter.init();
  const worker = FakeWorker.latest;
  if (!worker) throw new Error('fake worker was not constructed');
  worker.emit({ type: 'ready' });
  await init;
  return { adapter, worker };
}

describe('WorkerAdapter external P2P bridge', () => {
  test('keeps worker provider state aligned across install and removal', async () => {
    const { adapter, worker } = await initializedAdapter();
    expect(worker.posted[0]?.message.p2pProviderEnabled).toBe(false);

    adapter.setP2PProvider({ fetch: async () => null, listPeerIds: () => [] });
    expect(worker.posted.at(-1)?.message).toMatchObject({
      type: 'setP2PProviderState',
      enabled: true,
    });

    adapter.setP2PProvider(null);
    expect(worker.posted.at(-1)?.message).toMatchObject({
      type: 'setP2PProviderState',
      enabled: false,
    });
    adapter.close();
  });

  test('restores provider state when a crashed worker is replaced', async () => {
    vi.useFakeTimers();
    try {
      const { adapter, worker } = await initializedAdapter();
      adapter.setP2PProvider({ fetch: async () => null, listPeerIds: () => [] });

      worker.onerror?.({} as ErrorEvent);
      await vi.advanceTimersByTimeAsync(1_000);

      const replacement = FakeWorker.latest;
      expect(replacement).not.toBe(worker);
      expect(replacement?.posted[0]?.message).toMatchObject({
        type: 'init',
        p2pProviderEnabled: true,
      });
      replacement?.emit({ type: 'ready' });
      adapter.close();
    } finally {
      vi.useRealTimers();
    }
  });

  test('queues provider state while a replacement worker is starting', async () => {
    vi.useFakeTimers();
    try {
      const { adapter, worker } = await initializedAdapter();
      worker.onerror?.({} as ErrorEvent);
      await vi.advanceTimersByTimeAsync(1_000);

      const replacement = FakeWorker.latest;
      expect(replacement).not.toBe(worker);
      expect(replacement?.posted[0]?.message).toMatchObject({
        type: 'init',
        p2pProviderEnabled: false,
      });

      adapter.setP2PProvider({ fetch: async () => null, listPeerIds: () => [] });
      replacement?.emit({ type: 'ready' });
      expect(replacement?.posted.at(-1)?.message).toMatchObject({
        type: 'setP2PProviderState',
        enabled: true,
      });
      adapter.close();
    } finally {
      vi.useRealTimers();
    }
  });

  test('retries an idempotent identity update after worker replacement', async () => {
    vi.useFakeTimers();
    try {
      const { adapter, worker } = await initializedAdapter();
      const update = adapter.setIdentity('22'.repeat(32), '33'.repeat(32));
      expect(worker.posted.at(-1)?.message.type).toBe('setIdentity');

      worker.onerror?.({} as ErrorEvent);
      await vi.advanceTimersByTimeAsync(1_000);

      const replacement = FakeWorker.latest;
      replacement?.emit({ type: 'ready' });
      const request = replacement?.posted.find(({ message }) => message.type === 'setIdentity');
      expect(request?.message).toMatchObject({
        type: 'setIdentity',
        pubkey: '22'.repeat(32),
        nsec: '33'.repeat(32),
      });
      replacement?.emit({ type: 'void', id: request?.message.id });
      await expect(update).resolves.toBeUndefined();
      adapter.close();
    } finally {
      vi.useRealTimers();
    }
  });

  test('returns provider bytes to a worker P2P request', async () => {
    const { adapter, worker } = await initializedAdapter();
    const fetch = vi.fn(async () => new Uint8Array([1, 2, 3]));
    adapter.setP2PProvider({ fetch, listPeerIds: () => ['peer-a'] });

    worker.emit({
      type: 'p2pFetch',
      requestId: 'fetch-1',
      hashHex: 'ab'.repeat(32),
      htl: 10,
      peerId: 'peer-a',
    });
    await vi.waitFor(() => {
      expect(worker.posted.some(({ message }) => (
        message.type === 'p2pFetchResult' && message.requestId === 'fetch-1'
      ))).toBe(true);
    });

    expect(fetch).toHaveBeenCalledWith('ab'.repeat(32), 'peer-a', 10);
    const response = worker.posted.find(({ message }) => message.type === 'p2pFetchResult');
    expect(Array.from(response?.message.data as Uint8Array)).toEqual([1, 2, 3]);
    expect(response?.transfer).toHaveLength(1);
    adapter.close();
  });

  test('returns an error when a worker fetch has no configured route', async () => {
    const { adapter, worker } = await initializedAdapter();

    worker.emit({
      type: 'p2pFetch',
      requestId: 'fetch-without-route',
      hashHex: 'cd'.repeat(32),
      htl: 10,
    });
    await vi.waitFor(() => {
      expect(worker.posted.some(({ message }) => (
        message.type === 'p2pFetchResult' && message.requestId === 'fetch-without-route'
      ))).toBe(true);
    });

    expect(worker.posted.find(({ message }) => (
      message.type === 'p2pFetchResult' && message.requestId === 'fetch-without-route'
    ))?.message).toMatchObject({
      error: 'No P2P blob route configured',
    });
    adapter.close();
  });

  test('returns the provider peer list without starting the legacy proxy', async () => {
    const { adapter, worker } = await initializedAdapter();
    adapter.setP2PProvider({ fetch: async () => null, listPeerIds: async () => ['peer-b', 'peer-a'] });

    worker.emit({ type: 'p2pPeerList', requestId: 'peers-1' });
    await vi.waitFor(() => {
      expect(worker.posted.some(({ message }) => (
        message.type === 'p2pPeerListResult' && message.requestId === 'peers-1'
      ))).toBe(true);
    });

    const response = worker.posted.find(({ message }) => message.type === 'p2pPeerListResult');
    expect(response?.message.peerIds).toEqual(['peer-b', 'peer-a']);
    expect(worker.posted.some(({ message }) => String(message.type).startsWith('rtc:'))).toBe(false);
    adapter.close();
  });
});

describe('WorkerAdapter startup recovery', () => {
  test('resolves all startup callers when the first worker crashes before ready', async () => {
    vi.useFakeTimers();
    const adapter = new WorkerAdapter(FakeWorker as unknown as new () => Worker, { relays: [] });
    try {
      const firstReady = vi.fn();
      const secondReady = vi.fn();
      void adapter.init().then(firstReady);
      const failedWorker = FakeWorker.latest!;
      failedWorker.onerror?.({ message: 'startup failed' } as ErrorEvent);
      void adapter.init().then(secondReady);
      await vi.advanceTimersByTimeAsync(1000);
      const recoveredWorker = FakeWorker.latest!;
      expect(recoveredWorker).not.toBe(failedWorker);
      expect(firstReady).not.toHaveBeenCalled();
      expect(secondReady).not.toHaveBeenCalled();
      recoveredWorker.emit({ type: 'ready' });
      await vi.advanceTimersByTimeAsync(0);
      expect(firstReady).toHaveBeenCalledOnce();
      expect(secondReady).toHaveBeenCalledOnce();
    } finally {
      adapter.close();
      vi.useRealTimers();
    }
  });

  test('new callers wait through recovery after an initialized worker crashes', async () => {
    vi.useFakeTimers();
    const { adapter, worker } = await initializedAdapter();
    try {
      worker.onerror?.({ message: 'worker failed' } as ErrorEvent);
      const readyAgain = vi.fn();
      void adapter.init().then(readyAgain);
      await vi.advanceTimersByTimeAsync(999);
      expect(readyAgain).not.toHaveBeenCalled();
      await vi.advanceTimersByTimeAsync(1);
      expect(FakeWorker.latest).not.toBe(worker);
      FakeWorker.latest!.emit({ type: 'ready' });
      await vi.advanceTimersByTimeAsync(0);
      expect(readyAgain).toHaveBeenCalledOnce();
    } finally {
      adapter.close();
      vi.useRealTimers();
    }
  });
});


describe('WorkerAdapter graph bootstrap policy', () => {
  test.each([
    { initial: [...DEFAULT_PUBLIC_RELAYS], next: ['wss://custom.example'], allowed: false },
    { initial: ['wss://custom.example'], next: [...DEFAULT_PUBLIC_RELAYS], allowed: true },
  ])('retains the updated relay policy across a pending request and worker crash: $allowed', async ({ initial, next, allowed }) => {
    vi.useFakeTimers();
    let adapter: WorkerAdapter | undefined;
    try {
      const initialized = await initializedAdapter(initial);
      adapter = initialized.adapter;
      const worker = initialized.worker;
      expect(worker.posted[0]?.message).toMatchObject({
        type: 'init', config: { relays: initial, graphBootstrap: !allowed },
      });
      const update = adapter.setRelays(next).catch(error => error);
      expect(worker.posted.at(-1)?.message).toMatchObject({
        type: 'setRelays', relays: next, graphBootstrap: allowed,
      });
      expect(worker.posted.at(-1)?.message).not.toHaveProperty('options');
      worker.onerror?.({} as ErrorEvent);
      expect(await update).toBeInstanceOf(Error);
      await vi.advanceTimersByTimeAsync(1_000);
      const replacement = FakeWorker.latest;
      expect(replacement).not.toBe(worker);
      expect(replacement?.posted[0]?.message).toMatchObject({
        type: 'init', config: { relays: next, graphBootstrap: allowed },
      });
      replacement?.emit({ type: 'ready' });
    } finally {
      adapter?.close();
      vi.useRealTimers();
    }
  });
});
