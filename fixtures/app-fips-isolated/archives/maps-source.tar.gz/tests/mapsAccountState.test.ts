import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { encryptionMode, HashTree, LinkType, MemoryStore, toHex, type CID } from '@hashtree/core';
import { npubEncode } from 'nostr-tools/nip19';
import type { Place } from '../src/stores/mapsTypes';

const account = vi.hoisted(() => ({ npub: null as string | null, listeners: new Set<() => void>() }));
vi.mock('../src/store', () => ({ getTree: vi.fn() }));
vi.mock('../src/refResolver', () => ({ getRefResolver: vi.fn() }));
vi.mock('../src/treeRootCache', () => ({ updateLocalRootCache: vi.fn() }));
vi.mock('../src/nostr', () => ({ NDKEvent: vi.fn(), ndk: {}, nostrStore: {
  getState: () => ({ npub: account.npub }),
  subscribe: (callback: () => void) => { account.listeners.add(callback); return () => account.listeners.delete(callback); },
} }));
vi.mock('../src/lib/workerInit', () => ({ getWorkerAdapter: () => ({}) }));
vi.mock('../src/lib/nostrPublish', () => ({ publishEventWithFallback: vi.fn() }));
vi.mock('../src/stores/mapsSearch', () => ({ searchPlaces: vi.fn() }));

import { mapsStore } from '../src/stores/mapsStore.svelte';
import { getTree } from '../src/store';
import { getRefResolver } from '../src/refResolver';
import { updateLocalRootCache } from '../src/treeRootCache';

const alice = npubEncode('11'.repeat(32));
const bob = npubEncode('22'.repeat(32));
const pin: Place = { id: '0f0d7613-de59-4e41-a70d-cb25764a2f1a', name: 'Test pin', category: 'restaurant',
  lat: 60.17, lng: 24.94, owner: alice, createdAt: 1, updatedAt: 1 };
let tree: HashTree;
let subscriptions: Map<string, (root: CID | null) => void>;

function switchAccount(npub: string | null) {
  account.npub = npub;
  for (const callback of account.listeners) callback();
}
async function storedRoot(places: Place[]) {
  const { cid, size } = await tree.putFile(new TextEncoder().encode(JSON.stringify({ version: 3, places, annotations: [] })));
  return (await tree.putDirectory([{ name: 'maps.json', cid, size }])).cid;
}
function cacheRoot(npub: string, root: CID) {
  localStorage.setItem(`iris-maps-root:maps:${npub}`, JSON.stringify({ hash: toHex(root.hash), key: root.key && toHex(root.key) }));
}
async function loadAccount(npub: string, root: CID, name = pin.name) {
  cacheRoot(npub, root);
  switchAccount(npub);
  mapsStore.init();
  await vi.waitFor(() => expect(mapsStore.places.map(p => p.name)).toEqual([name]));
}
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(res => { resolve = res; });
  return { promise, resolve };
}
async function flushLoads() { await new Promise(resolve => setTimeout(resolve, 0)); }

beforeEach(() => {
  mapsStore.destroy();
  mapsStore.reset();
  account.npub = null;
  mapsStore.init();
  mapsStore.destroy();
  vi.clearAllMocks();
  const storage = new Map<string, string>();
  vi.stubGlobal('localStorage', { getItem: (key: string) => storage.get(key) ?? null,
    setItem: (key: string, value: string) => storage.set(key, value) });
  tree = new HashTree({ store: new MemoryStore() });
  vi.mocked(getTree).mockReturnValue(tree as ReturnType<typeof getTree>);
  subscriptions = new Map();
  vi.mocked(getRefResolver).mockReturnValue({ subscribe: (key: string, callback: (root: CID | null) => void) => {
    subscriptions.set(key, callback);
    return () => {}; // Retain callbacks to simulate a notification already queued before unsubscribe.
  } } as ReturnType<typeof getRefResolver>);
});
afterEach(() => { mapsStore.destroy(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe('account map pins', () => {
  it('clears the previous account pins immediately when switching directly to another account', async () => {
    await loadAccount(alice, await storedRoot([pin]));
    mapsStore.setActivePlace(mapsStore.activePlaceFromPlace(pin));
    switchAccount(bob);
    expect(mapsStore.places).toEqual([]);
    expect(mapsStore.activePlace).toBeNull();
    const lists = mapsStore.savedPlaceLists;
    subscriptions.get(`${alice}/maps`)!(null);
    expect(mapsStore.savedPlaceLists).toEqual(lists);
  });

  it('ignores an old account read and callback after switching accounts', async () => {
    const oldRoot = await storedRoot([pin]);
    const newPin = { ...pin, name: 'Bob pin', owner: bob };
    const newRoot = await storedRoot([newPin]);
    const pending = deferred<Uint8Array | null>();
    const read = vi.spyOn(tree, 'readFile').mockReturnValueOnce(pending.promise);
    cacheRoot(alice, oldRoot);
    switchAccount(alice);
    mapsStore.init();
    await vi.waitFor(() => expect(read).toHaveBeenCalled());
    const oldCallback = subscriptions.get(`${alice}/maps`)!;
    await loadAccount(bob, newRoot, newPin.name);
    oldCallback(oldRoot);
    pending.resolve(new TextEncoder().encode(JSON.stringify({ places: [pin], annotations: [] })));
    await flushLoads();
    expect(mapsStore.places.map(p => p.name)).toEqual(['Bob pin']);
  });

  it('does not discard cached pins when the resolver has no root yet', async () => {
    await loadAccount(alice, await storedRoot([pin]));
    subscriptions.get(`${alice}/maps`)!(null);
    expect(mapsStore.places).toEqual([pin]);
  });

  it('does not publish an in-flight write under another account or reuse its root', async () => {
    const oldRoot = await storedRoot([pin]);
    await loadAccount(alice, oldRoot);
    const pending = deferred<Awaited<ReturnType<HashTree['putFile']>>>();
    const originalPut = tree.putFile.bind(tree);
    const put = vi.spyOn(tree, 'putFile').mockReturnValueOnce(pending.promise);
    const saving = mapsStore.addPlace({ ...pin, name: 'Alice new pin' });
    await vi.waitFor(() => expect(put).toHaveBeenCalled());
    switchAccount(bob);
    pending.resolve(await originalPut(new Uint8Array([1])));
    await saving;
    expect(updateLocalRootCache).not.toHaveBeenCalled();
    expect(mapsStore.places).toEqual([]);
    const ownPin = await mapsStore.addPlace({ ...pin, name: 'Bob new pin', owner: bob });
    expect(updateLocalRootCache).toHaveBeenCalledTimes(1);
    const [owner, , hash, key] = vi.mocked(updateLocalRootCache).mock.calls[0];
    expect(owner).toBe(bob);
    const entry = await tree.resolvePath({ hash, key }, ['maps.json']);
    const data = JSON.parse(new TextDecoder().decode((await tree.readFile(entry!.cid))!));
    expect(data.places.map((p: Place) => p.id)).toEqual([ownPin.id]);
  });

  it('does not restore a removed pin from a delayed root notification during its save', async () => {
    const root = await storedRoot([pin]);
    await loadAccount(alice, root);
    const pending = deferred<void>();
    const originalPut = tree.putFile.bind(tree);
    const put = vi.spyOn(tree, 'putFile').mockImplementationOnce(async (...args) => {
      await pending.promise;
      return originalPut(...args);
    });
    const removal = mapsStore.deletePlace(pin.id);
    await vi.waitFor(() => expect(put).toHaveBeenCalled());
    subscriptions.get(`${alice}/maps`)!(root);
    await flushLoads();
    const pinsDuringSave = [...mapsStore.places];
    pending.resolve();
    await removal;
    expect(pinsDuringSave).toEqual([]);
    expect(mapsStore.places).toEqual([]);
  });

  it('retains randomized encryption on maps.json when editing a mixed tree', async () => {
    const writer = new HashTree({ store: tree.getStore(), encryptionMode: 'rnd-v1' });
    const file = await writer.putFile(new TextEncoder().encode(JSON.stringify({ version: 3, places: [pin], annotations: [] })));
    const { cid } = await tree.putDirectory([{ name: 'maps.json', ...file, type: LinkType.File }]);
    await loadAccount(alice, cid);
    await mapsStore.deletePlace(pin.id);
    const [, , hash, key] = vi.mocked(updateLocalRootCache).mock.calls[0];
    const entry = await tree.resolvePath({ hash, key }, ['maps.json']);
    expect(encryptionMode(entry!.cid.key!)).toBe('rnd-v1');
    expect(JSON.parse(new TextDecoder().decode((await tree.readFile(entry!.cid))!)).places).toEqual([]);
  });

  it('removes an imported pin from this map and persists the removal', async () => {
    await loadAccount(bob, await storedRoot([pin]));
    mapsStore.setActivePlace({ ...mapsStore.activePlaceFromPlace(pin), source: 'search' });
    await mapsStore.deletePlace(pin.id);
    expect(mapsStore.places).toEqual([]);
    expect(mapsStore.activePlace).toBeNull();
    expect(updateLocalRootCache).toHaveBeenCalledTimes(1);
    const [, , hash, key] = vi.mocked(updateLocalRootCache).mock.calls[0];
    const entry = await tree.resolvePath({ hash, key }, ['maps.json']);
    const data = JSON.parse(new TextDecoder().decode((await tree.readFile(entry!.cid))!));
    expect(data.places).toEqual([]);
  });
});
