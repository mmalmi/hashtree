import { describe, expect, it, vi } from 'vitest';
import {
  createReleasePlan,
  parseArgs,
  parsePublishOutput,
  runAllReleases,
  runRelease,
  wranglerVersion,
} from '../scripts/release-site.mjs';
import {
  configFor as workerAssetsConfigFor,
  parseArgs as parseWorkerAssetsArgs,
} from '../scripts/deploy-worker-assets.mjs';
import {
  createPublishCommand as createLowresTilePublishCommand,
  createOutputPlan as createLowresTileOutputPlan,
  createPushCommand as createLowresTilePushCommand,
  parseArgs as parseLowresTileArgs,
  parseStoredHash as parseLowresTileStoredHash,
  tileCount as lowresTileCount,
} from '../scripts/publish-lowres-map-tiles.mjs';

describe('release-site', () => {
  it('uses the built-in Worker default for maps', () => {
    const maps = parseArgs(['maps']);

    expect(maps.workerName).toBe('iris-maps');
    expect(maps.treeName).toBe('maps');
    expect(maps.routes).toEqual(['maps.iris.to/*']);
    expect(maps.domains).toEqual([]);
  });

  it('uses the profile-specific Worker env var without production routes or domains', () => {
    const parsed = parseArgs(['maps'], { CF_WORKER_NAME_MAPS: 'iris-maps-preview' });
    expect(parsed.workerName).toBe('iris-maps-preview');
    expect(parsed.treeName).toBe('maps');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports explicitly switching maps back to Pages', () => {
    const parsed = parseArgs(['maps', '--pages-only'], { CF_PAGES_PROJECT_MAPS: 'maps-iris-to' });
    expect(parsed.workerName).toBeUndefined();
    expect(parsed.pagesProject).toBe('maps-iris-to');
    expect(parsed.routes).toEqual([]);
    expect(parsed.domains).toEqual([]);
  });

  it('supports the all profile without per-site overrides', () => {
    const parsed = parseArgs(['all', '--branch', 'main', '--skip-cloudflare']);
    expect(parsed.profileName).toBe('all');
    expect(parsed.branch).toBe('main');
    expect(parsed.skipCloudflare).toBe(true);
  });

  it('rejects single-target Worker overrides for the all profile', () => {
    expect(() => parseArgs(['all', '--worker-name', 'iris-maps'])).toThrow(
      '--worker-name is not supported with the all profile',
    );
  });

  it('supports the maps release profile', () => {
    const maps = createReleasePlan({
      profileName: 'maps',
      pagesProject: 'maps-iris-to',
      treeName: 'maps',
      skipCloudflare: false,
    });
    expect(maps.profile.distDir).toBe('dist-maps');
  });

  it('generates a Worker Static Assets config that runs the redirect Worker first', () => {
    const options = parseWorkerAssetsArgs([
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-maps',
      '--name',
      'iris-maps',
      '--compatibility-date',
      '2026-03-19',
    ]);

    expect(workerAssetsConfigFor(options)).toEqual({
      name: 'iris-maps',
      compatibility_date: '2026-03-19',
      main: 'scripts/https-static-assets-worker.mjs',
      assets: {
        directory: 'dist-maps',
        binding: 'ASSETS',
        run_worker_first: true,
      },
    });
  });

  it('builds a Worker release plan in build-test-publish-deploy order', () => {
    const plan = createReleasePlan({
      profileName: 'maps',
      workerName: 'iris-maps',
      routes: ['maps.iris.to/*'],
      domains: [],
      treeName: 'maps',
      skipCloudflare: false,
      workerCompatibilityDate: '2026-03-19',
    });

    expect(plan.steps.map((step) => step.id)).toEqual([
      'build',
      'test-1',
      'test-2',
      'test-3',
      'test-4',
      'test-5',
      'test-6',
      'publish',
      'deploy',
    ]);
    expect(plan.steps.filter((step) => step.id.startsWith('test-')).map((step) => step.command)).toEqual([
      ['pnpm', 'run', 'check:types'],
      ['pnpm', 'exec', 'vitest', 'run', 'tests/mainMapsInitOrder.test.ts', 'tests/mediaStreamingSetup.test.ts'],
      ['node', './scripts/smoke-maps-iris-portable.mjs'],
      ['node', './scripts/smoke-graph-policy.mjs', 'maps'],
      ['pnpm', 'run', 'test:unit'],
      ['pnpm', 'run', 'test:e2e:release'],
    ]);
    expect(plan.steps.at(-1)?.command).toEqual([
      'node',
      './scripts/deploy-worker-assets.mjs',
      '--script',
      'scripts/https-static-assets-worker.mjs',
      '--assets',
      'dist-maps',
      '--name',
      'iris-maps',
      '--compatibility-date',
      '2026-03-19',
      '--wrangler-version',
      wranglerVersion,
      '--route',
      'maps.iris.to/*',
    ]);
  });

  it('builds a Pages release plan when only a Pages project is configured', () => {
    const plan = createReleasePlan({
      profileName: 'maps',
      pagesProject: 'maps-iris-to',
      treeName: 'maps',
      branch: 'main',
      skipCloudflare: false,
    });

    expect(plan.steps.at(-1)?.command).toEqual([
      'npx',
      `wrangler@${wranglerVersion}`,
      'pages',
      'deploy',
      'dist-maps',
      '--project-name',
      'maps-iris-to',
      '--branch',
      'main',
    ]);
  });

  it('stops before publish when a test step fails', async () => {
    const calls = [];
    const runner = vi.fn((step) => {
      calls.push(step.id);
      if (step.id === 'test-1') {
        expect(step.command).toEqual(['pnpm', 'run', 'check:types']);
        return { status: 1, stdout: '', stderr: 'smoke failed' };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await expect(
      runRelease(
        {
          profileName: 'maps',
          workerName: 'iris-maps',
          treeName: 'maps',
          skipCloudflare: false,
          workerCompatibilityDate: '2026-03-19',
        },
        runner,
        { buildOutputExists: () => true },
      ),
    ).rejects.toThrow('Test Iris Maps (1/6) failed with exit code 1');
    expect(calls).toEqual(['build', 'test-1']);
  });

  it('runs hashtree publish and Cloudflare deploy in parallel after tests', async () => {
    let activeReleaseSteps = 0;
    let maxActiveReleaseSteps = 0;
    const calls = [];
    const runner = vi.fn(async (step) => {
      calls.push(step.id);
      if (step.id === 'publish' || step.id === 'deploy') {
        activeReleaseSteps += 1;
        maxActiveReleaseSteps = Math.max(maxActiveReleaseSteps, activeReleaseSteps);
        await new Promise((resolve) => setTimeout(resolve, 10));
        activeReleaseSteps -= 1;
        if (step.id === 'publish') {
          return {
            status: 0,
            stdout: 'published: npub1example/maps\nnhash1ace',
            stderr: '',
          };
        }
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    await runRelease(
      {
        profileName: 'maps',
        workerName: 'iris-maps',
        treeName: 'maps',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(calls).toEqual(['build', 'test-1', 'test-2', 'test-3', 'test-4', 'test-5', 'test-6', 'publish', 'deploy']);
    expect(maxActiveReleaseSteps).toBe(2);
  });

  it('returns parsed hashtree and Worker target on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/maps\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'maps',
        workerName: 'iris-maps',
        treeName: 'maps',
        skipCloudflare: false,
        workerCompatibilityDate: '2026-03-19',
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/maps',
    });
    expect(result.workerName).toBe('iris-maps');
    expect(result.pagesProject).toBeNull();
    expect(result.pagesUrl).toBeNull();
  });

  it('returns parsed hashtree and Pages URLs on success', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/maps\nnhash1ace',
          stderr: '',
        };
      }
      if (step.id === 'deploy') {
        return {
          status: 0,
          stdout: 'Deploying... https://maps-iris-to.pages.dev',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runRelease(
      {
        profileName: 'maps',
        pagesProject: 'maps-iris-to',
        treeName: 'maps',
        skipCloudflare: false,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.publish).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1example/maps',
    });
    expect(result.pagesUrl).toBe('https://maps-iris-to.pages.dev');
  });

  it('runs all profiles sequentially', async () => {
    const runner = vi.fn((step) => {
      if (step.id === 'publish') {
        return {
          status: 0,
          stdout: 'published: npub1example/maps\nnhash1ace',
          stderr: '',
        };
      }
      return { status: 0, stdout: '', stderr: '' };
    });

    const result = await runAllReleases(
      {
        profileName: 'all',
        skipCloudflare: true,
      },
      runner,
      { buildOutputExists: () => true },
    );

    expect(result.profiles).toHaveLength(1);
    expect(result.profiles.map((profile) => profile.profile.name)).toEqual(['maps']);
  });

  it('parses htree publish output defensively', () => {
    expect(parsePublishOutput('published: npub1foo/maps\nnhash1ace')).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/maps',
    });
    expect(
      parsePublishOutput(
        [
          '2026-03-19T21:46:47Z ERROR nostr_relay_pool::pool::internal: Impossible to send event to wss://upload.iris.to/nostr: event not published: index build failed: MissingChunk',
          'published: npub1foo/maps',
          'nhash1ace',
        ].join('\n'),
      ),
    ).toEqual({
      nhash: 'nhash1ace',
      publishedRef: 'npub1foo/maps',
    });
    expect(() => parsePublishOutput('published: npub1foo/maps')).toThrow(
      'Publish succeeded but no nhash was found in htree output',
    );
  });
});

describe('publish-lowres-map-tiles', () => {
  it('stages generated tile datasets outside the repo by default', () => {
    const options = parseLowresTileArgs(['--dry-run']);
    const outputPlan = createLowresTileOutputPlan(options);

    expect(outputPlan.isTemporary).toBe(true);
    expect(outputPlan.outDir).not.toContain('.maps-tiles');
  });

  it('requires an explicit output directory when publishing pre-rendered tiles', () => {
    expect(() => parseLowresTileArgs(['--skip-generate'])).toThrow(
      '--skip-generate requires --out',
    );
  });

  it('can split mutable publish from direct file-server push', () => {
    const options = parseLowresTileArgs(['--push-server', 'http://vader.nvpn:8080']);
    const publishCommand = createLowresTilePublishCommand(options, '/tmp/tiles');
    const pushCommand = createLowresTilePushCommand(
      '0'.repeat(64),
      options.pushServer,
    );

    expect(options.pushServer).toBe('http://vader.nvpn:8080');
    expect(publishCommand).toContain('--local');
    expect(publishCommand.slice(-2)).toEqual(['--publish', 'maps-tiles-overview-v2']);
    expect(pushCommand.slice(-4)).toEqual([
      'push',
      '-s',
      'http://vader.nvpn:8080',
      '0'.repeat(64),
    ]);
  });

  it('parses the stored hash needed for a split push', () => {
    expect(parseLowresTileStoredHash(`added .\n  hash:  ${'a'.repeat(64)}\n`)).toBe('a'.repeat(64));
    expect(() => parseLowresTileStoredHash('added .')).toThrow(
      'no stored hash',
    );
  });

  it('computes web mercator tile counts across zoom ranges', () => {
    expect(lowresTileCount(0, 2)).toBe(21);
    expect(lowresTileCount(0, 5)).toBe(1365);
    expect(lowresTileCount(0, 6)).toBe(5461);
  });
});
