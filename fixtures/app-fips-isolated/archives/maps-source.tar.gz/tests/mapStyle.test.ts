import { describe, expect, it } from 'vitest';
import type { StyleSpecification } from 'maplibre-gl';
import {
  getInteractiveLabelLayerIds,
  hideAdministrativeSubdivisionLabels,
  rebalancePlaceLabelHierarchy,
  removeUnsupportedStyleImages,
  useBundledFontAlias,
} from '../src/lib/mapStyle';

describe('map style helpers', () => {
  it('uses the bundled glyph font alias for text layers', () => {
    const style = {
      version: 8,
      sources: {},
      layers: [{
        id: 'place_city',
        type: 'symbol',
        layout: {
          'text-field': ['get', 'name'],
          'text-font': ['Noto Sans Regular'],
        },
      }],
    } as unknown as StyleSpecification;

    useBundledFontAlias(style);

    expect(style.layers[0]?.layout?.['text-font']).toEqual(['Noto%20Sans%20Regular']);
  });

  it('removes fill patterns that are absent from the bundled sprite', () => {
    const style = {
      version: 8,
      sources: {},
      layers: [{
        id: 'landcover_wood',
        type: 'fill',
        paint: {
          'fill-pattern': 'wood-pattern',
        },
      }],
    } as unknown as StyleSpecification;

    removeUnsupportedStyleImages(style);

    expect(style.layers[0]?.paint).toEqual({});
  });

  it('hides administrative subdivision labels without hiding countries or cities', () => {
    const style = {
      version: 8,
      sources: {},
      layers: [
        {
          id: 'place_state',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'] },
          filter: ['==', ['get', 'class'], 'state'],
        },
        {
          id: 'label_state',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'] },
          filter: ['==', ['get', 'class'], 'state'],
        },
        {
          id: 'place_country_major',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'] },
          filter: ['==', ['get', 'class'], 'country'],
        },
        {
          id: 'place_city',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'] },
          filter: ['==', ['get', 'class'], 'city'],
        },
        {
          id: 'label_other',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'] },
          filter: ['match', ['get', 'class'], ['city', 'country', 'state'], false, true],
        },
      ],
    } as unknown as StyleSpecification;

    hideAdministrativeSubdivisionLabels(style);

    expect(style.layers[0]?.layout?.visibility).toBe('none');
    expect(style.layers[1]?.layout?.visibility).toBe('none');
    expect(style.layers[2]?.layout?.visibility).toBeUndefined();
    expect(style.layers[3]?.layout?.visibility).toBeUndefined();
    expect(style.layers[4]?.layout?.visibility).toBeUndefined();
  });

  it('finds visible name-backed label layers for map interactions', () => {
    const style = {
      version: 8,
      sources: {},
      layers: [
        {
          id: 'label_city',
          type: 'symbol',
          source: 'openmaptiles',
          'source-layer': 'place',
          layout: { 'text-field': ['coalesce', ['get', 'name_en'], ['get', 'name']] },
        },
        {
          id: 'highway-shield-us-interstate',
          type: 'symbol',
          source: 'openmaptiles',
          'source-layer': 'transportation_name',
          layout: { 'text-field': ['to-string', ['get', 'ref']] },
        },
        {
          id: 'label_state',
          type: 'symbol',
          source: 'openmaptiles',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'], visibility: 'none' },
        },
      ],
    } as unknown as StyleSpecification;

    expect(getInteractiveLabelLayerIds(style)).toEqual(['label_city']);
  });

  it('keeps country labels visually above large city labels at low zoom', () => {
    const style = {
      version: 8,
      sources: {},
      layers: [
        {
          id: 'place_city_large',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'], 'text-size': 14 },
          filter: ['all', ['<=', ['get', 'rank'], 3], ['==', ['get', 'class'], 'city']],
        },
        {
          id: 'place_country_major',
          type: 'symbol',
          'source-layer': 'place',
          layout: {
            'text-field': ['get', 'name'],
            'text-size': ['interpolate', ['linear'], ['zoom'], 0, 10, 4, 14],
          },
          filter: ['all', ['<=', ['get', 'rank'], 1], ['==', ['get', 'class'], 'country']],
        },
        {
          id: 'label_other',
          type: 'symbol',
          'source-layer': 'place',
          layout: { 'text-field': ['get', 'name'], 'text-size': 9 },
          filter: ['match', ['get', 'class'], ['city', 'continent', 'country'], false, true],
        },
      ],
    } as unknown as StyleSpecification;

    rebalancePlaceLabelHierarchy(style);

    expect(style.layers[0]?.layout?.['text-size']).toEqual([
      'interpolate',
      ['linear'],
      ['zoom'],
      0,
      8,
      3,
      10,
      5,
      12,
      8,
      16,
      11,
      20,
    ]);
    expect(style.layers[1]?.layout?.['text-size']).toEqual([
      'interpolate',
      ['linear'],
      ['zoom'],
      0,
      12,
      2,
      14,
      4,
      17,
      6,
      19,
    ]);
    expect(style.layers[2]?.layout?.['text-size']).toBe(9);
  });
});
