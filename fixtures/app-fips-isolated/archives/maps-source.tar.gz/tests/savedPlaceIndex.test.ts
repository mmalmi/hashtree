import { MemoryStore } from '@hashtree/core';
import { HASHTREE_ROOT_KIND } from '@hashtree/nostr';
import { describe, expect, it } from 'vitest';
import {
  SAVED_PLACE_MEMBERSHIP_KIND,
  SAVED_PLACE_MEMBERSHIP_LABEL,
  buildByListGeohashTimeKey,
  buildSavedPlaceHashtreeIndex,
  buildSavedPlaceIndexEntries,
  buildSavedPlaceMembershipEventTemplate,
  buildSavedPlaceProjection,
  buildSavedPlaceProjectionIndex,
  createSavedPlaceIndexSource,
  encodeGeohash,
  geohashPrefixes,
  querySavedPlaceIndexByListGeohash,
} from '../src/lib/savedPlaceIndex';

const listId = '8b9d8384-c005-426d-974d-4141be760bff';
const otherListId = 'db8c03ad-89ec-4ce7-9244-b7b1a8f7c42a';
const authorPubkey = '1'.repeat(64);

describe('saved place index', () => {
  it('builds compact parameterized membership event templates', () => {
    const template = buildSavedPlaceMembershipEventTemplate({
      listId,
      placeKey: 'btcmap:place:23143',
      lat: 60.1699,
      lng: 24.9384,
      createdAt: 1_716_595_200,
      listCoordinate: `${HASHTREE_ROOT_KIND}:${authorPubkey}:btcmap`,
      sourceLayer: 'btcmap',
      sourceId: '23143',
    });

    const geohash = encodeGeohash(60.1699, 24.9384, 7);

    expect(template.kind).toBe(SAVED_PLACE_MEMBERSHIP_KIND);
    expect(template.created_at).toBe(1_716_595_200);
    expect(template.content).toBe('');
    expect(template.tags).toContainEqual(['d', `${listId}:btcmap:place:23143`]);
    expect(template.tags).toContainEqual(['l', 'iris-maps']);
    expect(template.tags).toContainEqual(['l', SAVED_PLACE_MEMBERSHIP_LABEL]);
    expect(template.tags).toContainEqual(['list', listId]);
    expect(template.tags).toContainEqual(['i', 'btcmap:place:23143']);
    expect(template.tags).toContainEqual(['a', `${HASHTREE_ROOT_KIND}:${authorPubkey}:btcmap`]);
    expect(template.tags.filter((tag) => tag[0] === 'g').map((tag) => tag[1]))
      .toEqual(geohashPrefixes(geohash));
  });

  it('generates stable compound keys for list and geohash prefix scans', () => {
    const projection = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:1',
      lat: 42.276251,
      lng: 42.702422,
      createdAt: 1_716_595_200,
      eventId: 'a'.repeat(64),
      authorPubkey,
    });

    expect(buildByListGeohashTimeKey(projection, 'u4xs')).toBe(
      `${listId}:u4xs:8283404799:${'a'.repeat(64)}`,
    );
    expect(buildSavedPlaceIndexEntries(projection)['by-list-place-key'][0].key).toBe(
      `${listId}:btcmap%3Aplace%3A1:8283404799:${'a'.repeat(64)}`,
    );
  });

  it('queries portable JSON index rows by list and geohash prefix in newest-first order', () => {
    const oldPlace = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:old',
      lat: 60.1699,
      lng: 24.9384,
      createdAt: 1_716_500_000,
      eventId: 'b'.repeat(64),
      name: 'Old cafe',
    });
    const newPlace = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:new',
      lat: 60.1701,
      lng: 24.939,
      createdAt: 1_716_600_000,
      eventId: 'a'.repeat(64),
      name: 'New cafe',
    });
    const otherListPlace = buildSavedPlaceProjection({
      listId: otherListId,
      placeKey: 'btcmap:place:other-list',
      lat: 60.1699,
      lng: 24.9384,
      createdAt: 1_716_700_000,
      eventId: 'c'.repeat(64),
      name: 'Other list cafe',
    });
    const index = buildSavedPlaceProjectionIndex([oldPlace, otherListPlace, newPlace]);
    const prefix = oldPlace.geohashes[3];

    expect(querySavedPlaceIndexByListGeohash(index, { listId, geohashPrefix: prefix })
      .map((place) => place.name)).toEqual(['New cafe', 'Old cafe']);
  });

  it('uses B-tree prefix scans over packed projection shards for viewport-style lookup', async () => {
    const helsinkiOld = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:helsinki-old',
      lat: 60.1699,
      lng: 24.9384,
      createdAt: 1_716_500_000,
      eventId: '1'.repeat(64),
      name: 'Helsinki old',
    });
    const helsinkiNew = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:helsinki-new',
      lat: 60.171,
      lng: 24.941,
      createdAt: 1_716_600_000,
      eventId: '2'.repeat(64),
      name: 'Helsinki new',
    });
    const outsideBounds = buildSavedPlaceProjection({
      listId,
      placeKey: 'btcmap:place:outside',
      lat: 60.3,
      lng: 24.8,
      createdAt: 1_716_700_000,
      eventId: '3'.repeat(64),
      name: 'Outside bounds',
    });
    const otherListPlace = buildSavedPlaceProjection({
      listId: otherListId,
      placeKey: 'btcmap:place:other-list',
      lat: 60.1699,
      lng: 24.9384,
      createdAt: 1_716_800_000,
      eventId: '4'.repeat(64),
      name: 'Other list',
    });
    const store = new MemoryStore();
    const built = await buildSavedPlaceHashtreeIndex(
      [helsinkiOld, outsideBounds, otherListPlace, helsinkiNew],
      {
        store,
        btreeOrder: 4,
        maxRecordsPerShard: 2,
        generatedAt: '2026-06-18T00:00:00Z',
      },
    );

    const source = createSavedPlaceIndexSource(built.manifest, { store, tree: built.tree });
    const results = await source.queryListGeohash({
      listId,
      geohashPrefixes: [helsinkiOld.geohashes[1]],
      bounds: {
        west: 24.9,
        south: 60.15,
        east: 25,
        north: 60.19,
      },
      limit: 10,
    });

    expect(built.manifest).toMatchObject({
      kind: 'iris-maps-saved-place-index',
      projectionCount: 4,
      projectionShardCount: 2,
      recordPacking: {
        kind: 'json-record-shard',
        maxRecordsPerShard: 2,
      },
    });
    expect(results.map((place) => place.name)).toEqual(['Helsinki new', 'Helsinki old']);
  });
});
