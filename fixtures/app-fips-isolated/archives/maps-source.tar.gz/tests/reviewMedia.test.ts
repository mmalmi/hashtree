import { describe, expect, it } from 'vitest';
import {
  parseReviewMediaInput,
  reviewMediaDisplayUrl,
  reviewMediaFromUrl,
} from '../src/lib/reviewMedia';

describe('review media', () => {
  it('accepts hashtree image and video URLs', () => {
    expect(reviewMediaFromUrl('htree://nhash1abc/photo.jpg')).toEqual({
      url: 'htree://nhash1abc/photo.jpg',
      mimeType: 'image/jpeg',
      type: 'image',
    });
    expect(reviewMediaFromUrl('/htree/nhash1abc/clip.webm')).toEqual({
      url: '/htree/nhash1abc/clip.webm',
      mimeType: 'video/webm',
      type: 'video',
    });
  });

  it('deduplicates parsed URLs and rejects non-hashtree media', () => {
    expect(parseReviewMediaInput('https://example.test/a.jpg htree://nhash1abc/a.png htree://nhash1abc/a.png')).toEqual([
      {
        url: 'htree://nhash1abc/a.png',
        mimeType: 'image/png',
        type: 'image',
      },
    ]);
  });

  it('converts htree URLs to same-origin display URLs', () => {
    expect(reviewMediaDisplayUrl('htree://nhash1abc/a.png')).toBe('/htree/nhash1abc/a.png');
    expect(reviewMediaDisplayUrl('/htree/nhash1abc/a.png')).toBe('/htree/nhash1abc/a.png');
  });
});
