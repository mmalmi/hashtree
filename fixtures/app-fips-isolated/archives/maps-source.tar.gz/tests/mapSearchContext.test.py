import importlib.util
from pathlib import Path
import unittest
import shapely

spec = importlib.util.spec_from_file_location('context', Path(__file__).parents[1] / 'scripts/enrich-map-search-context.py')
context = importlib.util.module_from_spec(spec); spec.loader.exec_module(context)

class ContextTests(unittest.TestCase):
    def setUp(self):
        self.hierarchy = [dict(division_id=k, subtype=t, name=n) for k,t,n in [
            ('fi','country','Suomi / Finland'),('region','region','Uusimaa'),
            ('espoo','locality','Espoo'),('otaniemi','locality','Otaniemi')]]
        self.divisions = {x['division_id']: dict(x, primary=x['name']) for x in self.hierarchy}
        self.divisions['fi']['name'] = 'Finland'
        self.divisions['espoo']['class'] = 'city'

    def test_prefers_city_over_neighborhood_and_retains_native_country(self):
        parts, aliases, scopes = context.context_for({'name':'Otakaari'}, self.hierarchy, self.divisions)
        self.assertEqual(parts, ['Espoo','Uusimaa','Finland'])
        self.assertEqual(aliases, ['Suomi / Finland'])
        self.assertEqual(scopes, ['Espoo'])

    def test_city_and_country_pins_do_not_inherit_smaller_areas(self):
        parts,_,_ = context.context_for({'name':'Espoo','type':'city'}, self.hierarchy, self.divisions)
        self.assertEqual(parts, ['Espoo','Uusimaa','Finland'])
        parts,_,_ = context.context_for({'name':'Finland','type':'country'}, self.hierarchy, self.divisions)
        self.assertEqual(parts, ['Finland'])

    def test_unicode_names_are_not_removed(self):
        self.assertNotEqual(context.normalize('東京'), '')
        self.assertNotEqual(context.normalize('東京'), context.normalize('京都'))

    def test_same_named_region_does_not_hide_city_or_street_context(self):
        self.divisions['region']['name'] = 'Espoo'
        parts,_,scopes = context.context_for({'name':'Espoo','type':'city'}, self.hierarchy, self.divisions)
        self.assertEqual(scopes, ['Espoo'])

    def test_city_governorate_does_not_inherit_the_district_at_its_pin(self):
        self.divisions['region']['name'] = 'Cairo'
        parts,_,scopes = context.context_for({'name':'القاهرة','aliases':['Cairo'],'type':'city'}, self.hierarchy, self.divisions)
        self.assertEqual(parts, ['Cairo','Finland'])
        self.assertEqual(scopes, [])
        parts,_,scopes = context.context_for({'name':'Finland','addressType':'road'}, self.hierarchy, self.divisions)
        self.assertEqual(scopes, ['Espoo'])

    def test_boundaries_holes_and_outside_points_are_not_nearest_city_guesses(self):
        left = shapely.Polygon([(0,0),(1,0),(1,1),(0,1)], holes=[[(.4,.4),(.6,.4),(.6,.6),(.4,.6)]])
        right = shapely.box(1,0,2,1)
        areas = context.Areas([{'geometry':g.wkb,'hierarchy':[{}]} for g in [left,right]])
        self.assertEqual(areas.match([(.2,.5),(1.01,.5),(.5,.5),(1,.5),(3,.5)]).tolist(), [0,1,-1,-1,-1])

    def test_deepest_containing_hierarchy_wins(self):
        areas = context.Areas([
            {'geometry':shapely.box(0,0,3,3).wkb,'hierarchy':[{}]},
            {'geometry':shapely.box(0,0,2,2).wkb,'hierarchy':[{},{}]},
        ])
        self.assertEqual(areas.match([(1,1)]).tolist(), [1])

if __name__ == '__main__': unittest.main()
