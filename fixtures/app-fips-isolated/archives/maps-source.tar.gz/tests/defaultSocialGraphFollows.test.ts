import { afterEach, describe, expect, it, vi } from 'vitest';
import { SocialGraph } from 'nostr-social-graph';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import { loadRetainedPublicGraph, watchRetainedPublicGraph } from '../src/lib/publicGraphCache';
import { DEFAULT_SOCIAL_GRAPH_ROOT as root, loadDefaultSocialGraphFollowPubkeys, watchDefaultSocialGraphFollows } from '../src/lib/defaultSocialGraphFollows';
vi.mock('../src/lib/publicGraphCache', () => ({ loadRetainedPublicGraph: vi.fn(), watchRetainedPublicGraph: vi.fn(() => vi.fn()) }));
const graph = new SocialGraph(root), friend = '2'.repeat(64), muted = '3'.repeat(64);
graph.addFollower(root, friend); graph.addFollower(root, muted); graph.handleEvent({ kind: 10000, pubkey: root, id: 'a'.repeat(64), created_at: 1, tags: [['p', muted]], content: '', sig: '' });
vi.mocked(loadRetainedPublicGraph).mockResolvedValue({ graph, restored: true, storage: { read: async () => undefined, write: async () => {} } });
afterEach(() => { vi.mocked(watchRetainedPublicGraph).mockClear(); });
describe('default map follow scope', () => {
  it('uses the retained follow list and excludes its public mutes', async () => {
    expect(await loadDefaultSocialGraphFollowPubkeys()).toEqual([friend]);
  });
  it('keeps custom relays and reconciles only the default public owner', async () => {
    const stop = watchDefaultSocialGraphFollows(['wss://custom.test'], vi.fn());
    await vi.waitFor(() => expect(watchRetainedPublicGraph).toHaveBeenCalled());
    const options = vi.mocked(watchRetainedPublicGraph).mock.calls[0][1];
    expect(options.relays).toEqual(['wss://custom.test']);
    expect(options.authors()).toEqual([root]);
    stop();
  });
  it('adds the graph relay only to shipped defaults and cancels a pending watcher', async () => {
    const stop = watchDefaultSocialGraphFollows(DEFAULT_PUBLIC_RELAYS.map(url => url.replace(/\/$/, '') + '/'), vi.fn());
    await vi.waitFor(() => expect(watchRetainedPublicGraph).toHaveBeenCalled());
    expect(vi.mocked(watchRetainedPublicGraph).mock.calls[0][1].relays[0]).toBe('wss://graph-relay.iris.to');
    stop();
    vi.mocked(watchRetainedPublicGraph).mockClear();
    const cancelled = watchDefaultSocialGraphFollows(DEFAULT_PUBLIC_RELAYS, vi.fn());
    cancelled();
    await Promise.resolve();
    expect(watchRetainedPublicGraph).not.toHaveBeenCalled();
  });
});
