import { describe, expect, it } from 'vitest';
import {
  FACT_OP_KIND,
  buildPlaceFactEvent,
  buildReviewFactEvent,
  buildSavedPlaceListFactEvent,
} from '../src/lib/mapFactEvents';

const placeId = '6b7f5df4-1d2d-43a7-9b87-873e41a2d99a';
const reviewId = '8ef4ad1f-6d74-4f1a-8f4e-4d7a79a78645';
const listId = 'db8c03ad-89ec-4ce7-9244-b7b1a8f7c42a';
const reviewer = 'f'.repeat(64);

describe('map fact events', () => {
  it('builds tag-only place fact ops with a UUID subject', () => {
    const event = buildPlaceFactEvent({
      id: placeId,
      name: 'Nostr Cafe',
      category: 'cafe',
      lat: 60.1699012,
      lng: 24.9384012,
      description: 'Coffee and keys',
      contact: 'https://example.test',
      hours: 'Mon-Fri 9-17',
      createdAt: 1716508800123,
      updatedAt: 1716508800123,
    });

    expect(event.kind).toBe(FACT_OP_KIND);
    expect(event.content).toBe('');
    expect(event.tags).toContainEqual(['i', placeId, 'subject']);
    expect(event.tags).toContainEqual(['i', `iris-maps:place:${placeId}`]);
    expect(event.tags).toContainEqual(['type', 'place']);
    expect(event.tags).toContainEqual(['name', 'Nostr Cafe']);
    expect(event.tags).toContainEqual(['category', 'cafe']);
    expect(event.tags).toContainEqual(['lat', '60.169901']);
    expect(event.tags).toContainEqual(['lng', '24.938401']);
    expect(event.tags).toContainEqual(['created_at', '1716508800']);
  });

  it('builds review facts that point at the reviewed place', () => {
    const event = buildReviewFactEvent({
      id: reviewId,
      placeId,
      reviewer,
      rating: 4,
      ratingMax: 5,
      body: 'Great coffee.',
      lang: 'en',
      media: [
        {
          url: 'htree://nhash1qqsgy7f0y5yrf0wlacjnft97sxqh8gyh0jzkgknr3pkveu99vl5926c9ypzu506wl7dufpszrmvk0a4wwncys3dgxevnkhy3jkfkua83lr0lkz76gk7/review.jpg',
          mimeType: 'image/jpeg',
          alt: 'Cafe counter',
        },
      ],
      createdAt: 1716508800123,
      updatedAt: 1716508800123,
    });

    expect(event.tags).toContainEqual(['i', reviewId, 'subject']);
    expect(event.tags).toContainEqual(['i', placeId]);
    expect(event.tags).toContainEqual(['p', reviewer]);
    expect(event.tags).toContainEqual(['type', 'review']);
    expect(event.tags).toContainEqual(['reviewer', reviewer]);
    expect(event.tags).toContainEqual(['review_of', placeId]);
    expect(event.tags).toContainEqual(['rating', '4', '5']);
    expect(event.tags).toContainEqual(['body', 'Great coffee.']);
    expect(event.tags).toContainEqual([
      'media',
      'htree://nhash1qqsgy7f0y5yrf0wlacjnft97sxqh8gyh0jzkgknr3pkveu99vl5926c9ypzu506wl7dufpszrmvk0a4wwncys3dgxevnkhy3jkfkua83lr0lkz76gk7/review.jpg',
      'image/jpeg',
    ]);
    expect(event.tags).toContainEqual([
      'imeta',
      'url htree://nhash1qqsgy7f0y5yrf0wlacjnft97sxqh8gyh0jzkgknr3pkveu99vl5926c9ypzu506wl7dufpszrmvk0a4wwncys3dgxevnkhy3jkfkua83lr0lkz76gk7/review.jpg',
      'm image/jpeg',
      'alt Cafe counter',
    ]);
    expect(event.tags).toContainEqual(['published_at', '1716508800']);
  });

  it('rejects non-canonical UUID subjects', () => {
    expect(() => buildPlaceFactEvent({
      id: placeId.toUpperCase(),
      name: 'Nostr Cafe',
      category: 'cafe',
      lat: 60,
      lng: 24,
      createdAt: 1,
      updatedAt: 1,
    })).toThrow(/canonical lowercase/);
  });

  it('builds compact saved place list index facts with list UUID as subject', () => {
    const event = buildSavedPlaceListFactEvent({
      id: listId,
      name: 'Taipei coffee',
      description: 'Coffee stops from friends.',
      avatarUrl: 'https://example.test/taipei-coffee.png',
      visibility: 'public',
      urls: {
        web: `https://maps.iris.to/#/?list=${listId}&owner=npub1example&tree=maps`,
        htree: `htree://npub1app/maps#/?list=${listId}&owner=npub1example&tree=maps`,
        data: `/htree/npub1example/maps/saved-place-lists/${listId}/list.json?list=${listId}`,
        htreeData: `htree://npub1example/maps/saved-place-lists/${listId}/list.json?list=${listId}`,
      },
      places: [
        {
          key: `iris-maps:place:${placeId}`,
          id: placeId,
          type: 'cafe',
        },
      ],
      createdAt: 1716508800123,
      updatedAt: 1716595200123,
    });

    expect(event.kind).toBe(FACT_OP_KIND);
    expect(event.content).toBe('');
    expect(event.tags).toContainEqual(['i', listId, 'subject']);
    expect(event.tags).toContainEqual(['i', `iris-maps:saved-place-list:${listId}`]);
    expect(event.tags).toContainEqual(['i', `iris-maps:saved-place:${encodeURIComponent(`iris-maps:place:${placeId}`).toLowerCase()}`]);
    expect(event.tags).toContainEqual(['type', 'saved_place_list']);
    expect(event.tags).toContainEqual(['name', 'Taipei coffee']);
    expect(event.tags).toContainEqual(['description', 'Coffee stops from friends.']);
    expect(event.tags).toContainEqual(['avatar_url', 'https://example.test/taipei-coffee.png']);
    expect(event.tags).toContainEqual(['visibility', 'public']);
    expect(event.tags).toContainEqual(['place_count', '1']);
    expect(event.tags).toContainEqual(['web_url', `https://maps.iris.to/#/?list=${listId}&owner=npub1example&tree=maps`]);
    expect(event.tags).toContainEqual(['data_url', `/htree/npub1example/maps/saved-place-lists/${listId}/list.json?list=${listId}`]);
    expect(event.tags).toContainEqual(['htree_data_url', `htree://npub1example/maps/saved-place-lists/${listId}/list.json?list=${listId}`]);
    expect(event.tags.find((tag) => tag[0] === 'saved_place')).toBeUndefined();
    expect(event.tags).toContainEqual(['created_at', '1716508800']);
    expect(event.tags).toContainEqual(['updated_at', '1716595200']);
  });
});
