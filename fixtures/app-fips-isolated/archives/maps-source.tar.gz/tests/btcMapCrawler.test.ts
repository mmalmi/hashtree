import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import {
  DEFAULT_RELAYS,
  DEFAULT_TREE_NAME,
  BTCMAP_LIST_AVATAR_URL,
  BTCMAP_LIST_DESCRIPTION,
  IRIS_MAPS_LABEL,
  BTCMAP_RAW_CACHE_FILE,
  BTCMAP_RAW_CACHE_META_FILE,
  HASHTREE_ROOT_KIND,
  SAVED_PLACE_LIST_ITEMS_DIR,
  SAVED_PLACE_LIST_MANIFEST_FILE,
  SAVED_PLACE_LIST_LABEL,
  buildBtcMapSavedPlaceList,
  buildHashtreeRootEventTemplate,
  buildMapsPayload,
  buildSavedPlaceListManifest,
  buildSavedPlaceListFactEvent,
  buildSavedPlaceListIndexArtifacts,
  createBtcMapPlacesUrl,
  normalizeBtcMapPlace,
  parseArgs,
  parseHtreeAddOutput,
  readBtcMapRawCache,
  writeBtcMapRawCache,
  writeCrawlerTree,
} from '../scripts/crawl-btcmap.mjs';
import { DEFAULT_PUBLIC_RELAYS } from '@iris/hashtree-app/defaultRelays';
import {
  SAVED_PLACE_INDEX_FILE,
  SAVED_PLACE_ITEM_EVENTS_FILE,
  SAVED_PLACE_PROJECTIONS_FILE,
} from '../src/lib/savedPlaceIndex';
import { buildSavedPlaceListUrls } from '../src/lib/savedPlaceListUrls';

const listId = 'db8c03ad-89ec-4ce7-9244-b7b1a8f7c42a';
const createdAt = 1_716_508_800_123;
const savedAt = 1_716_595_200_123;
const crawlerNpub = 'npub169qdxhs922fn02z6crylner0h3l7ydhvahm3npzhlewclkjv7las3mh2at';
const testDir = path.dirname(fileURLToPath(import.meta.url));
const appDir = path.resolve(testDir, '..');

describe('BTC Map crawler', () => {
  it('publishes roots to the same relays the Maps app reads', () => {
    expect(DEFAULT_RELAYS).toEqual(DEFAULT_PUBLIC_RELAYS);
  });

  it('runs directly with Node for scheduled crawls', () => {
    const result = spawnSync(process.execPath, [path.join(appDir, 'scripts', 'crawl-btcmap.mjs'), '--help'], {
      encoding: 'utf8',
    });

    expect(result.status, result.stderr).toBe(0);
    expect(result.stdout).toContain('Usage: pnpm run crawl:btcmap');
  });

  it('builds the bounded BTC Map places API URL', () => {
    const url = createBtcMapPlacesUrl({ limit: 100 });

    expect(url.origin).toBe('https://api.btcmap.org');
    expect(url.pathname).toBe('/v4/places');
    expect(url.searchParams.get('limit')).toBe('100');
    expect(url.searchParams.get('fields')).toContain('payment_provider');
  });

  it('builds chronological sync URLs for full-cache crawls', () => {
    const url = createBtcMapPlacesUrl({
      pageLimit: 1000,
      updatedSince: '1970-01-01T00:00:00Z',
      includeDeleted: true,
    });

    expect(url.searchParams.get('limit')).toBe('1000');
    expect(url.searchParams.get('updated_since')).toBe('1970-01-01T00:00:00Z');
    expect(url.searchParams.get('include_deleted')).toBe('true');
    expect(url.searchParams.get('fields')).toContain('deleted_at');
  });

  it('normalizes BTC Map merchants as Iris Maps saved-place items', () => {
    const item = normalizeBtcMapPlace({
      id: 23143,
      lat: 42.2762511,
      lon: 42.7024218,
      icon: 'hotel',
      name: 'Green Town',
      address: 'Main Street 1',
      opening_hours: 'Mo-Fr 09:00-17:00',
      verified_at: '2026-05-01T10:00:00.000Z',
      osm_id: 'node:9778525869',
      osm_url: 'https://www.openstreetmap.org/node/9778525869',
      phone: '+358 50 123 4567',
      website: 'https://example.test',
      email: 'hello@example.test',
      instagram: 'https://instagram.com/greentown',
      image: 'https://i.imgur.com/green-town.jpg',
      description: 'Bitcoin-friendly hotel.',
      comments: 2,
      payment_provider: 'coinos',
    }, savedAt);

    expect(item).toMatchObject({
      key: 'btcmap:place:23143',
      id: 'btcmap:place:23143',
      name: 'Green Town',
      lat: 42.2762511,
      lng: 42.7024218,
      type: 'hotel',
      displayName: 'Hotel',
      sourceLayer: 'btcmap',
      sourceId: '23143',
      savedAt,
    });
    expect(item?.details).toMatchObject({
      address: 'Main Street 1',
      openingHours: 'Mo-Fr 09:00-17:00',
      phone: '+358 50 123 4567',
      website: 'https://example.test/',
      email: 'hello@example.test',
      imageUrl: 'https://i.imgur.com/green-town.jpg',
      description: 'Bitcoin-friendly hotel.',
      paymentProvider: 'coinos',
    });
    expect(item?.details).not.toHaveProperty('osmId');
    expect(item?.details).not.toHaveProperty('osmUrl');
    expect(item?.details?.links).not.toContainEqual({
      label: 'OpenStreetMap',
      url: 'https://www.openstreetmap.org/node/9778525869',
      kind: 'source',
    });
    expect(item?.details?.links).toContainEqual({
      label: 'Instagram',
      url: 'https://instagram.com/greentown',
      kind: 'social',
    });
    expect(item?.context).toContain('Verified 2026-05-01');
    expect(item?.context).not.toContain('node:9778525869');
  });

  it('writes hashtree-canonical list data with compact index facts', () => {
    const state = { version: 1, listId, createdAt };
    const list = buildBtcMapSavedPlaceList([
      { id: 1, lat: 60.1, lon: 24.2, icon: 'cafe', name: 'First' },
      { id: 1, lat: 60.1, lon: 24.2, icon: 'cafe', name: 'Duplicate' },
    ], state, { now: savedAt });
    list.urls = buildSavedPlaceListUrls({
      listId,
      ownerNpub: crawlerNpub,
      treeName: DEFAULT_TREE_NAME,
    });
    list.factEvent = buildSavedPlaceListFactEvent(list);

    const manifest = buildSavedPlaceListManifest(list, {
      index: { projectionCount: 1 },
      source: { provider: 'btcmap' },
    });
    const payload = buildMapsPayload(list);

    expect(list.places).toHaveLength(1);
    expect(list.description).toBe(BTCMAP_LIST_DESCRIPTION);
    expect(list.avatarUrl).toBe(BTCMAP_LIST_AVATAR_URL);
    expect(manifest).toMatchObject({
      kind: 'iris-maps-saved-place-list',
      id: listId,
      description: BTCMAP_LIST_DESCRIPTION,
      avatarUrl: BTCMAP_LIST_AVATAR_URL,
      items: {
        kind: 'json-page-directory',
        dir: SAVED_PLACE_LIST_ITEMS_DIR,
        totalCount: 1,
      },
      itemCount: 1,
      urls: list.urls,
      source: { provider: 'btcmap' },
      labels: [IRIS_MAPS_LABEL, SAVED_PLACE_LIST_LABEL],
    });
    expect(manifest.index).toMatchObject({
      kind: 'iris-maps-saved-place-index',
      file: SAVED_PLACE_INDEX_FILE,
      projections: SAVED_PLACE_PROJECTIONS_FILE,
      itemEvents: SAVED_PLACE_ITEM_EVENTS_FILE,
      projectionCount: 1,
      indexes: expect.arrayContaining(['by-list-geohash-time', 'by-list-place-key']),
    });
    expect(manifest.urls.web).toBe(`https://maps.iris.to/#/?list=${listId}&owner=${crawlerNpub}&tree=${DEFAULT_TREE_NAME}`);
    expect(manifest.urls.htreeData).toBe(`htree://${crawlerNpub}/${DEFAULT_TREE_NAME}/saved-place-lists/${listId}/list.json?list=${listId}`);
    expect(manifest.renderingProjections).toMatchObject({
      dynamicGeojson: {
        kind: 'hashtree-geohash-index',
        sourceIndex: 'by-list-geohash-time',
      },
      pmtilesOverlay: null,
    });
    expect(buildSavedPlaceListManifest(list, {
      index: { projectionCount: 1 },
      pmtilesOverlay: {
        kind: 'pmtiles-overlay',
        url: 'overlay.pmtiles',
        sourceLayer: 'saved_places',
        minzoom: 0,
        maxzoom: 14,
      },
    }).renderingProjections.pmtilesOverlay).toMatchObject({
      kind: 'pmtiles-overlay',
      url: 'overlay.pmtiles',
      sourceLayer: 'saved_places',
    });
    expect(payload.savedPlaceLists?.[0].places).toHaveLength(0);
    expect(payload.savedPlaceLists?.[0].urls?.web).toBe(manifest.urls.web);
    expect(list.factEvent?.tags).toContainEqual(['place_count', '1']);
    expect(list.factEvent?.tags).toContainEqual(['description', BTCMAP_LIST_DESCRIPTION]);
    expect(list.factEvent?.tags).toContainEqual(['avatar_url', BTCMAP_LIST_AVATAR_URL]);
    expect(list.factEvent?.tags).toContainEqual(['web_url', manifest.urls.web]);
    expect(list.factEvent?.tags).toContainEqual(['htree_data_url', manifest.urls.htreeData]);
    expect(list.factEvent?.tags.find((tag) => tag[0] === 'saved_place')).toBeUndefined();
    expect(list.factEvent?.tags).toContainEqual(['i', 'iris-maps:saved-place:btcmap%3aplace%3a1']);
  });

  it('excludes deleted BTC Map places from the active saved list', () => {
    const state = { version: 1, listId, createdAt };
    const list = buildBtcMapSavedPlaceList([
      { id: 1, lat: 60.1, lon: 24.2, icon: 'cafe', name: 'Active' },
      { id: 2, lat: 60.2, lon: 24.3, icon: 'shop', name: 'Deleted', deleted_at: '2025-01-01T00:00:00Z' },
    ], state, { now: savedAt });

    expect(list.places.map((place) => place.name)).toEqual(['Active']);
  });

  it('writes and reads raw BTC Map cache records as JSONL', () => {
    const cacheDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-maps-btcmap-cache-'));
    const records = [
      { id: 1, updated_at: '2025-01-01T00:00:00Z', name: 'One' },
      { id: 2, updated_at: '2025-01-02T00:00:00Z', deleted_at: '2025-01-03T00:00:00Z', name: 'Two' },
    ];
    const meta = { version: 1, provider: 'btcmap', recordCount: records.length };

    writeBtcMapRawCache(cacheDir, records, meta);
    const read = readBtcMapRawCache(cacheDir);

    expect(fs.existsSync(path.join(cacheDir, BTCMAP_RAW_CACHE_FILE))).toBe(true);
    expect(fs.existsSync(path.join(cacheDir, BTCMAP_RAW_CACHE_META_FILE))).toBe(true);
    expect(read.records).toEqual(records);
    expect(read.meta).toMatchObject(meta);
  });

  it('advertises dynamic browser sampling only for large lists', () => {
    const state = { version: 1, listId, createdAt };
    const rawPlaces = Array.from({ length: 6 }, (_, index) => ({
      id: index + 1,
      lat: 60 + index / 100,
      lon: 24 + index / 100,
      icon: 'cafe',
      name: `Place ${index + 1}`,
    }));
    const list = buildBtcMapSavedPlaceList(rawPlaces, state, { now: savedAt });

    expect(buildSavedPlaceListManifest(list, {
      sampleSize: 3,
      sampleThreshold: 3,
    }).sampling?.world).toMatchObject({
      kind: 'dynamic-random-ordinal',
      source: 'items',
      sampleSize: 3,
      threshold: 3,
    });
    expect(buildSavedPlaceListManifest(list, {
      sampleSize: 3,
      sampleThreshold: 10,
    }).sampling).toBeUndefined();
  });

  it('builds item projection artifacts from saved-place membership events', () => {
    const state = { version: 1, listId, createdAt };
    const list = buildBtcMapSavedPlaceList([
      { id: 1, lat: 60.1, lon: 24.2, icon: 'cafe', name: 'First' },
    ], state, { now: savedAt });
    const itemEvents = [{
      id: 'a'.repeat(64),
      pubkey: 'b'.repeat(64),
      created_at: Math.floor(savedAt / 1000),
      kind: 30368,
      content: '',
      tags: [],
      sig: 'c'.repeat(128),
    }];

    const artifacts = buildSavedPlaceListIndexArtifacts(list, itemEvents, {
      listCoordinate: `${HASHTREE_ROOT_KIND}:${'b'.repeat(64)}:${DEFAULT_TREE_NAME}`,
    });

    expect(artifacts.itemEvents).toHaveLength(1);
    expect(artifacts.projections[0]).toMatchObject({
      id: `${listId}:btcmap:place:1`,
      listId,
      placeKey: 'btcmap:place:1',
      eventId: 'a'.repeat(64),
      authorPubkey: 'b'.repeat(64),
      listCoordinate: `${HASHTREE_ROOT_KIND}:${'b'.repeat(64)}:${DEFAULT_TREE_NAME}`,
      sourceLayer: 'btcmap',
      sourceId: '1',
    });
    expect(artifacts.index.indexes['by-list-geohash-time'].length).toBeGreaterThan(0);
  });

  it('writes only the paged list directory shape into a clean crawler tree', () => {
    const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iris-maps-btcmap-'));
    fs.writeFileSync(path.join(outDir, 'items.json'), 'stale');
    fs.writeFileSync(path.join(outDir, 'saved-place-list.json'), 'stale');

    const state = { version: 1, listId, createdAt };
    const list = buildBtcMapSavedPlaceList([
      { id: 1, lat: 60.1, lon: 24.2, icon: 'cafe', name: 'First' },
    ], state, { now: savedAt });
    list.urls = buildSavedPlaceListUrls({
      listId,
      ownerNpub: crawlerNpub,
      treeName: DEFAULT_TREE_NAME,
    });
    const manifest = buildSavedPlaceListManifest(list);

    writeCrawlerTree(
      outDir,
      list,
      buildMapsPayload(list),
      { version: 1, createdAt, updatedAt: savedAt, providers: ['btcmap'] },
      { fetchedAt: savedAt, sourceUrl: 'https://api.btcmap.org/v4/places', requestedLimit: 100, returned: 1, saved: 1 },
      manifest,
    );

    expect(fs.existsSync(path.join(outDir, 'items.json'))).toBe(false);
    expect(fs.existsSync(path.join(outDir, 'saved-place-list.json'))).toBe(false);
    expect(fs.existsSync(path.join(outDir, 'saved-place-lists', listId, SAVED_PLACE_LIST_MANIFEST_FILE))).toBe(true);
    expect(fs.existsSync(path.join(outDir, 'saved-place-lists', listId, SAVED_PLACE_LIST_ITEMS_DIR, '000000.json'))).toBe(true);
  });

  it('labels the public list root for hashtree and Iris Maps discovery', () => {
    const template = buildHashtreeRootEventTemplate({
      treeName: DEFAULT_TREE_NAME,
      hash: 'a'.repeat(64),
      key: 'b'.repeat(64),
      labels: [IRIS_MAPS_LABEL, SAVED_PLACE_LIST_LABEL],
      createdAt: 1_775_000_000,
    });

    expect(template.kind).toBe(HASHTREE_ROOT_KIND);
    expect(template.tags).toContainEqual(['d', 'btcmap']);
    expect(template.tags).toContainEqual(['l', 'hashtree']);
    expect(template.tags).toContainEqual(['l', IRIS_MAPS_LABEL]);
    expect(template.tags).toContainEqual(['l', SAVED_PLACE_LIST_LABEL]);
    expect(template.tags).toContainEqual(['hash', 'a'.repeat(64)]);
    expect(template.tags).toContainEqual(['key', 'b'.repeat(64)]);
  });

  it('parses htree add output without requiring htree to publish the root event', () => {
    expect(parseHtreeAddOutput(`
added .
  url:   nhash1abc
  drive: https://drive.iris.to/nhash1abc
  hash:  ${'a'.repeat(64)}
  key:   ${'b'.repeat(64)}
`)).toEqual({
      immutableUrl: 'nhash1abc',
      driveUrl: 'https://drive.iris.to/nhash1abc',
      hash: 'a'.repeat(64),
      key: 'b'.repeat(64),
      publishedRef: undefined,
    });
  });

  it('preserves the suite and full key from htree and rejects malformed key lines', () => {
    const key = '02' + 'aa'.repeat(32);
    expect(parseHtreeAddOutput(`  key: ${key}`).key).toBe(key);
    expect(() => parseHtreeAddOutput(`  key: ${key} extra`)).toThrow();
    expect(() => parseHtreeAddOutput(`  key: ${key}aa`)).toThrow();
    expect(() => parseHtreeAddOutput(`  key: ff${'ab'.repeat(32)}`)).toThrow();
  });

  it('defaults to a crawler-owned btcmap list root', () => {
    expect(parseArgs([], { HOME: '/tmp/home' })).toMatchObject({
      limit: 100,
      all: false,
      pageLimit: 1000,
      treeName: DEFAULT_TREE_NAME,
      listName: 'BTC Map',
      visibility: 'public',
      keyFile: '/tmp/home/.keys/iris-maps-btcmap-crawler.nsec',
      cacheDir: path.join(appDir, '.local', 'btcmap-crawler', 'cache'),
    });
  });
});
