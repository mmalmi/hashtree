import { describe, expect, it } from 'vitest';
import { shouldInterceptHtreeRequestForWorker } from '../src/lib/swRoutePolicy';

describe('service worker htree route policy', () => {
  it('lets public OpenFreeMap glyphs pass through the same-origin network proxy', () => {
    expect(shouldInterceptHtreeRequestForWorker(
      '/htree/npub1example/maps-openfreemap-world-z14-v1/ofm/Noto%20Sans%20Regular/0-255.pbf',
      null,
      null,
      'font',
    )).toBe(false);
  });

  it('keeps PMTiles range requests on the htree worker bridge', () => {
    expect(shouldInterceptHtreeRequestForWorker(
      '/htree/npub1example/maps-openfreemap-world-z14-v1/tiles.pmtiles',
      null,
      'bytes=0-16383',
      null,
    )).toBe(true);
  });

  it('keeps public OpenFreeMap style JSON on the htree worker bridge for portable builds', () => {
    expect(shouldInterceptHtreeRequestForWorker(
      '/htree/npub1example/maps-openfreemap-world-z14-v1/ofm/fiord.json',
      null,
      null,
      null,
    )).toBe(true);
  });

  it('keeps ordinary htree files on the htree worker bridge', () => {
    expect(shouldInterceptHtreeRequestForWorker(
      '/htree/npub1example/user-tree/photo.jpg',
      null,
      null,
      'image',
    )).toBe(true);
  });
});
