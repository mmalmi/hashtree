import { describe, expect, it } from 'vitest';
import { mapsPortableBuild, portableAssetBase, sanitizePortableHtml } from '../portableViteConfig';
import { isExpectedOfflineTileError } from '../scripts/portable-smoke-lib.mjs';

describe('maps portable build config', () => {
  it('uses a relative asset base for maps builds served from htree trees', () => {
    expect(portableAssetBase).toBe('./');
    expect(mapsPortableBuild.outDir).toBe('dist-maps');
    expect(mapsPortableBuild.modulePreload).toBe(false);
  });

  it('strips module preload and crossorigin hints for htree webviews', () => {
    const sanitized = sanitizePortableHtml(`
      <script type="module" crossorigin src="./assets/main.js"></script>
      <link rel="modulepreload" crossorigin href="./assets/vendor.js">
      <link rel="stylesheet" crossorigin href="./assets/main.css">
    `);

    expect(sanitized).not.toContain('modulepreload');
    expect(sanitized).not.toContain('crossorigin');
    expect(sanitized).toContain('<script type="module" src="./assets/main.js"></script>');
    expect(sanitized).toContain('<link rel="stylesheet" href="./assets/main.css">');
  });

  it('permits only remote tile fetch failures during intentional offline checks', () => {
    const origin = 'http://127.0.0.1:1234';
    const message = { offline: true, text: 'Failed to load resource: net::ERR_INTERNET_DISCONNECTED', url: 'https://cdn.iris.to/maps/tiles.pmtiles' };
    const request = { type: 'fetch', error: 'net::ERR_INTERNET_DISCONNECTED' };
    expect(isExpectedOfflineTileError(message, request, origin)).toBe(true);
    expect(isExpectedOfflineTileError({ ...message, offline: false }, request, origin)).toBe(false);
    expect(isExpectedOfflineTileError(message, { ...request, type: 'script' }, origin)).toBe(false);
    expect(isExpectedOfflineTileError({ ...message, url: `${origin}/tiles.pmtiles` }, request, origin)).toBe(false);
    expect(isExpectedOfflineTileError({ ...message, url: 'https://cdn.iris.to/app.js' }, request, origin)).toBe(false);
    expect(isExpectedOfflineTileError(message, { ...request, error: 'net::ERR_FAILED' }, origin)).toBe(false);
  });
});
