import { describe, expect, it } from 'vitest';
import {
  DEFAULT_MAP_VIEW,
  MAP_VIEW_STORAGE_KEY,
  loadMapView,
  saveMapView,
} from '../src/lib/mapView';

function memoryStorage(initial: Record<string, string> = {}) {
  const values = new Map(Object.entries(initial));
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => {
      values.set(key, value);
    },
  } as Pick<Storage, 'getItem' | 'setItem'>;
}

describe('map view persistence', () => {
  it('starts clean users at a whole-world overview instead of a specific city', () => {
    expect(loadMapView(null)).toEqual({
      center: [...DEFAULT_MAP_VIEW.center],
      zoom: DEFAULT_MAP_VIEW.zoom,
    });
    expect(DEFAULT_MAP_VIEW.zoom).toBeLessThanOrEqual(1);
  });

  it('remembers the previous viewport when storage has a valid map view', () => {
    const storage = memoryStorage({
      [MAP_VIEW_STORAGE_KEY]: JSON.stringify({
        center: [60.1699, 24.9384],
        zoom: 11,
        bounds: [60.05, 60.33, 24.75, 25.2],
      }),
    });

    expect(loadMapView(storage)).toEqual({
      center: [60.1699, 24.9384],
      zoom: 11,
      bounds: [60.05, 60.33, 24.75, 25.2],
    });
  });

  it('saves viewport changes for the next visit', () => {
    const storage = memoryStorage();

    saveMapView({ center: [35.68, 139.76], zoom: 9 }, storage);

    expect(loadMapView(storage)).toEqual({
      center: [35.68, 139.76],
      zoom: 9,
    });
  });

  it('falls back to the world view when storage is malformed', () => {
    const storage = memoryStorage({
      [MAP_VIEW_STORAGE_KEY]: '{not json',
    });

    expect(loadMapView(storage)).toEqual({
      center: [...DEFAULT_MAP_VIEW.center],
      zoom: DEFAULT_MAP_VIEW.zoom,
    });
  });
});
