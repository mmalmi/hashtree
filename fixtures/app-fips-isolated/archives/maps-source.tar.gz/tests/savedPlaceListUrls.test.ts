import { describe, expect, it } from 'vitest';
import {
  buildSavedPlaceListAppPath,
  buildSavedPlaceListUrls,
  normalizeSavedPlaceListUrls,
} from '../src/lib/savedPlaceListUrls';

const listId = '8b9d8384-c005-426d-974d-4141be760bff';
const ownerNpub = 'npub169qdxhs922fn02z6crylner0h3l7ydhvahm3npzhlewclkjv7las3mh2at';

describe('saved place list URLs', () => {
  it('builds map-share and data URLs for public lists', () => {
    const urls = buildSavedPlaceListUrls({
      listId,
      ownerNpub,
      treeName: 'btcmap',
    });

    expect(buildSavedPlaceListAppPath({ listId, ownerNpub, treeName: 'btcmap' })).toBe(
      `/?list=${listId}&owner=${ownerNpub}&tree=btcmap`,
    );
    expect(urls.web).toBe(`https://maps.iris.to/#/?list=${listId}&owner=${ownerNpub}&tree=btcmap`);
    expect(urls.htree).toBe(`htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/maps#/?list=${listId}&owner=${ownerNpub}&tree=btcmap`);
    expect(urls.data).toBe(`/htree/${ownerNpub}/btcmap/saved-place-lists/${listId}/list.json?list=${listId}`);
    expect(urls.htreeData).toBe(`htree://${ownerNpub}/btcmap/saved-place-lists/${listId}/list.json?list=${listId}`);
    expect(normalizeSavedPlaceListUrls(urls)).toEqual(urls);
  });
});
