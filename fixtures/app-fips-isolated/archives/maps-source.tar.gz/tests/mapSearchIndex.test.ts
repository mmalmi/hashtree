import { describe, expect, it, vi } from 'vitest';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { HashTree, MemoryStore, toHex, type CID } from '@hashtree/core';
import { SearchIndex } from '@hashtree/index';
import {
  buildMapSearchTerms,
  buildMutableHtreeSearchUrl,
  createMapPlaceSearchSource,
  DEFAULT_MAP_SEARCH_TREE,
  fetchMapPlaceSearchManifest,
  houseNumberMatches,
  type MapPlaceSearchManifest,
} from '../src/lib/mapSearchIndex';
import type { SearchResult } from '../src/stores/mapsTypes';

function serializeCid(cid: CID) {
  return {
    hash: toHex(cid.hash),
    ...(cid.key ? { key: toHex(cid.key) } : {}),
  };
}

describe('map search index', () => {
  it('loads a valid manifest from an origin that takes more than two seconds', async () => {
    const manifest: MapPlaceSearchManifest = {
      version: 1, kind: 'iris-maps-place-search-index', placeCount: 15303713,
      searchIndexVersion: 2, prefix: 'p:', searchRoot: null,
    };
    let responseTimer: ReturnType<typeof setTimeout> | undefined;
    const server = createServer((_request, response) => {
      responseTimer = setTimeout(() => response.end(JSON.stringify(manifest)), 2500);
    });
    server.listen(0, '127.0.0.1');
    await once(server, 'listening');
    try {
      const address = server.address();
      if (!address || typeof address === 'string') throw new Error('Missing test server address');
      expect(await fetchMapPlaceSearchManifest(`http://127.0.0.1:${address.port}/root.json`)).toMatchObject(manifest);
    } finally {
      clearTimeout(responseTimer);
      const closed = once(server, 'close');
      server.close();
      server.closeAllConnections();
      await closed;
    }
  });

  it.each(['record', 'shard', 'address'] as const)('retries a temporarily unavailable %s without caching the failure', async (kind) => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });
    const index = new SearchIndex(store, { order: 4, minKeywordLength: 1 });
    const place: SearchResult = { id: 'helsinki', name: 'Helsinki', displayName: 'City', lat: 60.17, lng: 24.94, class: 'place', type: 'city' };
    const content = kind === 'shard' ? { records: [place] }
      : kind === 'address' ? { kind: 'iris-maps-street-address-sidecar', points: [{ n: '10', lat: 60.17, lng: 24.94 }] }
        : place;
    const { cid } = await tree.putFile(new TextEncoder().encode(JSON.stringify(content)));
    const root = await index.buildLinks([['p:helsinki:helsinki', cid]]);
    const readFile = vi.fn()
      .mockResolvedValueOnce(null)
      .mockRejectedValueOnce(new Error('Offline'))
      .mockImplementation((cid: CID) => tree.readFile(cid));
    const source = createMapPlaceSearchSource({
      version: 1, kind: 'iris-maps-place-search-index', placeCount: 1, searchIndexVersion: 2,
      prefix: 'p:', searchRoot: serializeCid(root!), searchOptions: { order: 4, minKeywordLength: 1 },
      ...(kind === 'shard' ? { recordPacking: { kind: 'json-record-shard' as const } } : {}),
    }, { store, tree: { readFile } });
    const query = () => kind === 'address'
      ? source.resolveAddress({ ...place, addressRef: { kind: 'street-address-points-v1', cid: serializeCid(cid) } }, '10')
      : source.search('helsinki');

    expect(await query()).toEqual([]);
    expect(await query()).toEqual([]);
    const [first, second] = await Promise.all([query(), query()]);
    expect(first[0]?.name).toBe(kind === 'address' ? 'Helsinki 10' : 'Helsinki');
    expect(second).toEqual(first);
    await query();
    expect(readFile).toHaveBeenCalledTimes(3);
  });

  it('matches normalized house numbers and numeric ranges', () => {
    expect(houseNumberMatches('6 A', '6a')).toBe(true);
    expect(houseNumberMatches('58-60', '59')).toBe(true);
    expect(houseNumberMatches('60-58', '59')).toBe(true);
    expect(houseNumberMatches('58-60', '61')).toBe(false);
    expect(houseNumberMatches('6B', '6a')).toBe(false);
  });

  it('builds mutable hashtree URLs for the published place index', () => {
    expect(buildMutableHtreeSearchUrl({
      npub: 'npub1example',
      treeName: DEFAULT_MAP_SEARCH_TREE,
      path: 'root.json',
      htreePath: true,
    })).toBe(`/htree/npub1example/${DEFAULT_MAP_SEARCH_TREE}/root.json`);
  });

  it('uses the published tree name for public gateway search URLs', () => {
    expect(buildMutableHtreeSearchUrl({
      npub: 'npub1example',
      treeName: DEFAULT_MAP_SEARCH_TREE,
      path: 'root.json',
      baseUrl: 'https://cdn.iris.to/',
    })).toBe(`https://cdn.iris.to/npub1example/${DEFAULT_MAP_SEARCH_TREE}/root.json`);
  });

  it('searches CID-linked place records through hashtree-index', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });
    const searchIndex = new SearchIndex(store, { order: 4, minKeywordLength: 1 });
    const encoder = new TextEncoder();
    const places: Array<SearchResult & { id: string }> = [
      {
        id: 'place:helsinki:60.16990:24.93840',
        name: 'Helsinki',
        lat: 60.1699,
        lng: 24.9384,
        type: 'city',
        class: 'place',
        displayName: 'Helsinki, Uusimaa, Finland',
        placeRank: 16,
        importance: 0.72,
        addressType: 'city',
      },
      {
        id: 'place:helston:50.10100:-5.27000',
        name: 'Helston',
        lat: 50.101,
        lng: -5.27,
        type: 'city',
        class: 'place',
        displayName: 'Helston, Cornwall, United Kingdom',
        placeRank: 16,
        importance: 0.3,
        addressType: 'city',
      },
    ];

    const entries: Array<[string, CID]> = [];
    for (const place of places) {
      const { cid } = await tree.putFile(encoder.encode(`${JSON.stringify(place)}\n`));
      for (const term of buildMapSearchTerms(searchIndex, place.name)) {
        entries.push([`p:${term}:${place.id}`, cid]);
      }
    }

    const searchRoot = await searchIndex.buildLinks(entries);
    const manifest: MapPlaceSearchManifest = {
      version: 1,
      kind: 'iris-maps-place-search-index',
      placeCount: places.length,
      searchIndexVersion: 1,
      prefix: 'p:',
      searchRoot: serializeCid(searchRoot!),
      searchOptions: { order: 4, minKeywordLength: 1 },
    };

    const source = createMapPlaceSearchSource(manifest, { store, tree });
    const results = await source.search('hels', 10);

    expect(results.map((result) => result.name)).toEqual(expect.arrayContaining(['Helsinki', 'Helston']));
    expect(results.find((result) => result.name === 'Helsinki')).toMatchObject({
      name: 'Helsinki',
      displayName: 'Helsinki, Uusimaa, Finland',
      class: 'place',
    });
  });

  it('searches packed record shards through hashtree-index link ids', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });
    const searchIndex = new SearchIndex(store, { order: 4, minKeywordLength: 1 });
    const encoder = new TextEncoder();
    const places: Array<SearchResult & { id: string }> = [
      {
        id: 'road:hameentie',
        name: 'Hämeentie',
        aliases: ['Tavastvägen'],
        context: 'Kallio, Helsinki, Uusimaa, Finland',
        lat: 60.1904,
        lng: 24.962,
        type: 'primary',
        class: 'highway',
        displayName: 'Street',
        addressType: 'road',
        sourceLayer: 'transportation_name',
        sourceZoom: 13,
        sourceTile: [4662, 2368],
      },
      {
        id: 'place:helsinki',
        name: 'Helsinki',
        lat: 60.1699,
        lng: 24.9384,
        type: 'city',
        class: 'place',
        displayName: 'City',
        addressType: 'city',
      },
    ];
    const { cid: shardCid } = await tree.putFile(encoder.encode(`${JSON.stringify({
      version: 1,
      kind: 'iris-maps-search-record-shard',
      records: places,
    })}\n`));

    const entries: Array<[string, CID]> = [];
    for (const place of places) {
      for (const term of buildMapSearchTerms(searchIndex, [place.name, ...(place.aliases ?? [])].join(' '))) {
        entries.push([`p:${term}:${place.id}`, shardCid]);
      }
    }

    const searchRoot = await searchIndex.buildLinks(entries);
    const manifest: MapPlaceSearchManifest = {
      version: 1,
      kind: 'iris-maps-place-search-index',
      placeCount: places.length,
      searchIndexVersion: 2,
      prefix: 'p:',
      searchRoot: serializeCid(searchRoot!),
      searchOptions: { order: 4, minKeywordLength: 1 },
      recordPacking: {
        kind: 'json-record-shard',
        version: 1,
        maxRecordsPerShard: 256,
      },
    };

    const source = createMapPlaceSearchSource(manifest, { store, tree });

    await expect(source.search('Tavastvägen', 5)).resolves.toMatchObject([
      {
        name: 'Hämeentie',
        aliases: ['Tavastvägen'],
        context: 'Kallio, Helsinki, Uusimaa, Finland',
        class: 'highway',
        sourceLayer: 'transportation_name',
        sourceZoom: 13,
        sourceTile: [4662, 2368],
      },
    ]);
  });

  it('resolves street address sidecars into house-number results', async () => {
    const store = new MemoryStore();
    const tree = new HashTree({ store });
    const encoder = new TextEncoder();
    const addressSidecar = {
      version: 1,
      kind: 'iris-maps-street-address-sidecar',
      streetId: 'road:hameentie',
      points: [
        {
          n: '10',
          lat: 60.1905,
          lng: 24.953,
          confidence: 0.9,
          distanceMeters: 8,
          sourceZoom: 14,
          sourceTile: [9327, 4740],
        },
        {
          n: '58-60',
          lat: 60.187,
          lng: 24.971,
          confidence: 0.7,
          distanceMeters: 21,
          sourceZoom: 14,
          sourceTile: [9328, 4740],
        },
      ],
    };
    const { cid: addressCid } = await tree.putFile(encoder.encode(`${JSON.stringify(addressSidecar)}\n`));
    const street: SearchResult = {
      id: 'road:hameentie',
      name: 'Hämeentie',
      aliases: ['Tavastvägen'],
      context: 'Kallio, Helsinki, Uusimaa, Finland',
      lat: 60.1904,
      lng: 24.962,
      type: 'primary',
      class: 'highway',
      displayName: 'Street',
      addressType: 'road',
      sourceLayer: 'transportation_name',
      sourceZoom: 13,
      sourceTile: [4662, 2368],
      addressRef: {
        kind: 'street-address-points-v1',
        cid: serializeCid(addressCid),
        count: 2,
        maxDistanceMeters: 45,
      },
    };
    const manifest: MapPlaceSearchManifest = {
      version: 1,
      kind: 'iris-maps-place-search-index',
      placeCount: 1,
      searchIndexVersion: 2,
      prefix: 'p:',
      searchRoot: null,
      searchOptions: { order: 4, minKeywordLength: 1 },
    };

    const source = createMapPlaceSearchSource(manifest, { store, tree });

    await expect(source.resolveAddress(street, '10', 5)).resolves.toMatchObject([
      {
        name: 'Hämeentie 10',
        lat: 60.1905,
        lng: 24.953,
        class: 'building',
        addressType: 'house',
        sourceLayer: 'housenumber',
        sourceZoom: 14,
        sourceTile: [9327, 4740],
      },
    ]);
    expect((await source.resolveAddress(street, '59', 5))[0]).toMatchObject({
      name: 'Hämeentie 58-60',
    });
  });
});
