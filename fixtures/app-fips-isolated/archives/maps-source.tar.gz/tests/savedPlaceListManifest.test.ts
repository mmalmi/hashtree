import { describe, expect, it } from 'vitest';
import {
  DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE,
  SAVED_PLACE_LIST_ITEMS_DIR,
  buildSavedPlaceListItemPages,
  buildSavedPlaceListManifest,
  normalizeSavedPlaceListItems,
  normalizeSavedPlaceListManifest,
  savedPlaceListItemPageFile,
  savedPlaceListItemPagePath,
  savedPlaceListManifestPath,
} from '../src/lib/savedPlaceListManifest';
import type { SavedPlaceList } from '../src/stores/mapsTypes';

const baseList: SavedPlaceList = {
  id: '8b9d8384-c005-426d-974d-4141be760bff',
  name: 'BTC Map',
  description: 'Places accepting bitcoin, sourced from btcmap.org.',
  icon: 'map-pin',
  avatarUrl: 'https://btcmap.org/images/logo.svg',
  visibility: 'public',
  places: [
    {
      key: 'btcmap:place:1',
      id: 'btcmap:place:1',
      name: 'First merchant',
      lat: 60.1,
      lng: 24.2,
      type: 'cafe',
      displayName: 'Cafe',
      details: {
        address: '1 Market Street',
        website: 'https://first.example/',
        links: [{ label: 'Website', url: 'https://first.example/', kind: 'website' }],
      },
      source: 'search',
      sourceLayer: 'btcmap',
      sourceId: '1',
      savedAt: 1_716_595_200_123,
    },
    {
      key: 'btcmap:place:2',
      id: 'btcmap:place:2',
      name: 'Second merchant',
      lat: 60.2,
      lng: 24.3,
      type: 'shop',
      displayName: 'Shop',
      source: 'search',
      sourceLayer: 'btcmap',
      sourceId: '2',
      savedAt: 1_716_595_201_123,
    },
    {
      key: 'btcmap:place:3',
      id: 'btcmap:place:3',
      name: 'Third merchant',
      lat: 60.3,
      lng: 24.4,
      type: 'restaurant',
      displayName: 'Restaurant',
      source: 'search',
      sourceLayer: 'btcmap',
      sourceId: '3',
      savedAt: 1_716_595_202_123,
    },
  ],
  createdAt: 1_716_508_800_123,
  updatedAt: 1_716_595_200_123,
};

describe('saved place list manifest', () => {
  it('keeps the manifest small and points at iterable item pages', () => {
    const manifest = buildSavedPlaceListManifest(baseList, { pageSize: 2 });
    const serialized = JSON.stringify(manifest);

    expect(manifest).toMatchObject({
      kind: 'iris-maps-saved-place-list',
      id: baseList.id,
      description: baseList.description,
      avatarUrl: baseList.avatarUrl,
      itemCount: 3,
      items: {
        kind: 'json-page-directory',
        dir: SAVED_PLACE_LIST_ITEMS_DIR,
        pageSize: 2,
        pageCount: 2,
        totalCount: 3,
      },
    });
    expect(serialized).not.toContain('First merchant');
    expect(savedPlaceListManifestPath(baseList.id)).toBe(`saved-place-lists/${baseList.id}/list.json`);
    expect(savedPlaceListItemPagePath(baseList.id, 1)).toBe(`saved-place-lists/${baseList.id}/items/000001.json`);
  });

  it('splits items into stable numbered JSON pages', () => {
    const pages = buildSavedPlaceListItemPages(baseList.places, 2);

    expect(pages).toHaveLength(2);
    expect(pages[0].map((item) => item.key)).toEqual(['btcmap:place:1', 'btcmap:place:2']);
    expect(pages[1].map((item) => item.key)).toEqual(['btcmap:place:3']);
    expect(savedPlaceListItemPageFile(0)).toBe('000000.json');
    expect(savedPlaceListItemPageFile(42)).toBe('000042.json');
  });

  it('normalizes manifests and item pages for route loading', () => {
    const manifest = normalizeSavedPlaceListManifest(buildSavedPlaceListManifest(baseList));
    const items = normalizeSavedPlaceListItems(baseList.places);

    expect(manifest?.items.pageSize).toBe(DEFAULT_SAVED_PLACE_LIST_ITEM_PAGE_SIZE);
    expect(manifest?.items.pageCount).toBe(1);
    expect(manifest?.description).toBe(baseList.description);
    expect(manifest?.avatarUrl).toBe(baseList.avatarUrl);
    expect(items.map((item) => item.key)).toEqual(['btcmap:place:1', 'btcmap:place:2', 'btcmap:place:3']);
    expect(items[0].details).toMatchObject({
      address: '1 Market Street',
      website: 'https://first.example/',
      links: [{ label: 'Website', url: 'https://first.example/', kind: 'website' }],
    });
    expect(normalizeSavedPlaceListItems([{ key: 'missing coords', name: 'Nope' }])).toEqual([]);
  });

  it('fills BTC Map list branding from older source-only manifests', () => {
    const manifest = buildSavedPlaceListManifest({
      ...baseList,
      description: undefined,
      avatarUrl: undefined,
    }, {
      source: { provider: 'btcmap' },
    });

    const normalized = normalizeSavedPlaceListManifest(manifest);

    expect(normalized?.description).toBe('Places accepting bitcoin, sourced from btcmap.org.');
    expect(normalized?.avatarUrl).toBe('https://btcmap.org/images/logo.svg');
  });

  it('describes optional dynamic browser sampling for large lists', () => {
    const manifest = buildSavedPlaceListManifest(baseList, {
      sampleSize: 2,
      sampleThreshold: 2,
    });

    expect(manifest.sampling?.world).toMatchObject({
      kind: 'dynamic-random-ordinal',
      source: 'items',
      sampleSize: 2,
      threshold: 2,
    });
    expect(normalizeSavedPlaceListManifest(manifest)?.sampling?.world?.sampleSize).toBe(2);
    expect(buildSavedPlaceListManifest(baseList, {
      sampleSize: 2,
      sampleThreshold: 10,
    }).sampling).toBeUndefined();
  });
});
