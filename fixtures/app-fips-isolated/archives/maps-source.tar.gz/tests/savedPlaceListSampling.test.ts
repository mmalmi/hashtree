import { describe, expect, it } from 'vitest';
import {
  buildSavedPlaceListSamplePageRequests,
  randomOrdinalsAcrossRange,
} from '../src/lib/savedPlaceListSampling';

describe('saved place list sampling', () => {
  it('selects unique random ordinals across the whole range', () => {
    const ordinals = randomOrdinalsAcrossRange(100, 10, () => 0.5);

    expect(new Set(ordinals).size).toBe(10);
    expect([...ordinals].sort((left, right) => left - right)).toEqual([5, 15, 25, 35, 45, 55, 65, 75, 85, 95]);
  });

  it('turns a dynamic sample into bounded page reads', () => {
    const requests = buildSavedPlaceListSamplePageRequests({
      kind: 'json-page-directory',
      dir: 'items',
      pageSize: 10,
      pageCount: 10,
      totalCount: 100,
    }, {
      limit: 12,
      maxPages: 3,
      random: () => 0.5,
    });

    expect(requests.map((request) => request.pageIndex)).toEqual([1, 5, 8]);
    expect(requests.map((request) => request.offsets.length)).toEqual([4, 4, 4]);
    expect(requests.flatMap((request) => request.offsets)).toEqual([
      1, 3, 6, 8,
      1, 3, 6, 8,
      1, 3, 6, 8,
    ]);
  });
});
