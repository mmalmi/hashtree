import { describe, expect, it } from 'vitest';
import {
  DEFAULT_MAP_BASEMAP_STYLE_PREFERENCE,
  MAP_BASEMAP_STYLE_PREFERENCES,
  normalizeMapBasemapStylePreference,
  resolveMapBasemapStyle,
} from '../src/lib/mapStylePreference';

describe('map style preferences', () => {
  it('defaults to bright style selection', () => {
    expect(DEFAULT_MAP_BASEMAP_STYLE_PREFERENCE).toBe('bright');
    expect(MAP_BASEMAP_STYLE_PREFERENCES.map((option) => option.id)).toEqual([
      'fiord',
      'positron',
      'liberty',
      'bright',
    ]);
  });

  it('normalizes unknown persisted values back to bright', () => {
    expect(normalizeMapBasemapStylePreference('liberty')).toBe('liberty');
    expect(normalizeMapBasemapStylePreference('system')).toBe('bright');
    expect(normalizeMapBasemapStylePreference('unknown')).toBe('bright');
    expect(normalizeMapBasemapStylePreference(null)).toBe('bright');
  });

  it('resolves explicit style choices directly', () => {
    expect(resolveMapBasemapStyle('fiord')).toBe('fiord');
    expect(resolveMapBasemapStyle('positron')).toBe('positron');
    expect(resolveMapBasemapStyle('bright')).toBe('bright');
  });
});
