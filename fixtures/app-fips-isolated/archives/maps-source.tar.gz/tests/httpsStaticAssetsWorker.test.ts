import { afterEach, describe, expect, it, vi } from 'vitest';
import worker from '../scripts/https-static-assets-worker.mjs';

describe('HTTPS static assets Worker', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('redirects plain HTTP requests to the same HTTPS URL', async () => {
    const response = await worker.fetch(
      new Request('http://maps.iris.to/#/map/demo'),
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://maps.iris.to/#/map/demo');
  });

  it('redirects requests marked as HTTP by Cloudflare forwarding headers', async () => {
    const response = await worker.fetch(
      new Request('https://maps.iris.to/', {
        headers: { 'cf-visitor': '{"scheme":"http"}' },
      }),
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://maps.iris.to/');
  });

  it('redirects Cloudflare requests with no TLS version', async () => {
    const request = new Request('https://maps.iris.to/');
    Object.defineProperty(request, 'cf', {
      value: {},
    });

    const response = await worker.fetch(
      request,
      { ASSETS: { fetch: vi.fn() } },
    );

    expect(response.status).toBe(308);
    expect(response.headers.get('location')).toBe('https://maps.iris.to/');
  });

  it('serves HTTPS requests from static assets', async () => {
    const assetResponse = new Response('maps');
    const fetch = vi.fn().mockResolvedValue(assetResponse);

    const response = await worker.fetch(
      new Request('https://maps.iris.to/'),
      { ASSETS: { fetch } },
    );

    expect(response).toBe(assetResponse);
    expect(fetch).toHaveBeenCalledOnce();
  });

  it('proxies same-origin htree requests to the public hashtree gateway', async () => {
    const assetFetch = vi.fn();
    const upstreamResponse = new Response('glyph');
    const upstreamFetch = vi.fn().mockResolvedValue(upstreamResponse);
    vi.stubGlobal('fetch', upstreamFetch);

    const response = await worker.fetch(
      new Request('https://maps.iris.to/htree/npub1example/maps-openfreemap/ofm/Noto%20Sans%20Regular/0-255.pbf?cache=1', {
        headers: {
          range: 'bytes=0-255',
          cookie: 'private=1',
        },
      }),
      { ASSETS: { fetch: assetFetch } },
    );

    expect(response).toBe(upstreamResponse);
    expect(assetFetch).not.toHaveBeenCalled();
    expect(upstreamFetch).toHaveBeenCalledOnce();
    const forwarded = upstreamFetch.mock.calls[0][0] as Request;
    expect(forwarded.url).toBe('https://cdn.iris.to/npub1example/maps-openfreemap/ofm/Noto%20Sans%20Regular/0-255.pbf?cache=1');
    expect(forwarded.headers.get('range')).toBe('bytes=0-255');
    expect(forwarded.headers.has('cookie')).toBe(false);
  });
});
