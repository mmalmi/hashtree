import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { SearchResult } from '../src/stores/mapsTypes';

vi.mock('../src/store', () => ({ getTree: vi.fn() }));
vi.mock('../src/refResolver', () => ({ getRefResolver: vi.fn() }));
vi.mock('../src/treeRootCache', () => ({ updateLocalRootCache: vi.fn() }));
vi.mock('../src/nostr', () => ({ NDKEvent: vi.fn(), ndk: {}, nostrStore: {} }));
vi.mock('../src/lib/workerInit', () => ({ getWorkerAdapter: vi.fn() }));
vi.mock('../src/lib/nostrPublish', () => ({ publishEventWithFallback: vi.fn() }));
vi.mock('../src/stores/mapsSearch', () => ({ searchPlaces: vi.fn() }));

import { mapsStore } from '../src/stores/mapsStore.svelte';
import { searchPlaces } from '../src/stores/mapsSearch';

function deferredSearch() {
  let resolve!: (results: SearchResult[]) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<SearchResult[]>((res, rej) => { resolve = res; reject = rej; });
  vi.mocked(searchPlaces).mockReturnValueOnce(promise);
  return { resolve, reject };
}

const helsinki: SearchResult = {
  name: 'Helsinki', displayName: 'City', type: 'city', class: 'place', lat: 60.17, lng: 24.94,
};
const london = { ...helsinki, name: 'London', lat: 51.51, lng: -0.13 };

describe('map search state', () => {
  beforeEach(() => {
    mapsStore.reset();
    vi.mocked(searchPlaces).mockReset();
  });

  it('keeps the latest results when searches finish out of order', async () => {
    const first = deferredSearch();
    const second = deferredSearch();
    const oldSearch = mapsStore.search('Helsinki');
    const newSearch = mapsStore.search('London');
    second.resolve([london]);
    await newSearch;
    first.resolve([helsinki]);
    await oldSearch;
    expect(mapsStore.searchQuery).toBe('London');
    expect(mapsStore.searchResults).toEqual([london]);
    expect(mapsStore.isSearching).toBe(false);
  });

  it('keeps the loading state when an older request fails', async () => {
    const first = deferredSearch();
    const second = deferredSearch();
    const oldSearch = mapsStore.search('Helsinki');
    const newSearch = mapsStore.search('London');
    first.reject(new Error('Offline'));
    await oldSearch;
    expect(mapsStore.isSearching).toBe(true);
    second.resolve([london]);
    await newSearch;
    expect(mapsStore.searchResults).toEqual([london]);
  });

  it.each(['clear', 'short', 'destroy', 'reset'])('invalidates pending results on %s', async (action) => {
    const pending = deferredSearch();
    const search = mapsStore.search('Helsinki');
    if (action === 'short') await mapsStore.search('L');
    else if (action === 'clear') mapsStore.clearSearch();
    else if (action === 'destroy') mapsStore.destroy();
    else mapsStore.reset();
    expect(mapsStore.isSearching).toBe(false);
    pending.resolve([helsinki]);
    await search;
    expect(mapsStore.searchResults).toEqual([]);
  });
});
