import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { resultDetails, resultContextSummary, resultDisplayLine } from '../src/lib/mapSearchResultDetails';
import { parseStreetAddressQuery, searchPlaces, setMapDetailSearchProvider, setMapPlaceSearchSourceProvider } from '../src/stores/mapsSearch';
import type { MapPlaceSearchSource } from '../src/lib/mapSearchIndex';
import type { SearchResult } from '../src/stores/mapsTypes';

describe('map search', () => {
  let clearDetailProvider: (() => void) | null = null;
  let clearSourceProvider: (() => void) | null = null;

  beforeEach(() => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
      if (String(url).includes('/maps-search-openfreemap-world-z13-v1/root.json')) {
        return new Response(JSON.stringify({
          version: 1,
          kind: 'iris-maps-labels',
          labels: [],
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({
        version: 1,
        kind: 'iris-maps-labels',
        labels: [
          { name: 'Finland', lat: 64, lng: 26, kind: 'country', minZoom: 3 },
          { name: 'Helsinki', lat: 60.1699, lng: 24.9384, kind: 'city', minZoom: 6, population: 664921 },
          { name: 'Helston', lat: 50.101, lng: -5.27, kind: 'city', minZoom: 8, population: 12000 },
        ],
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }));
  });

  afterEach(() => {
    clearDetailProvider?.();
    clearDetailProvider = null;
    clearSourceProvider?.();
    clearSourceProvider = null;
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it('parses street address queries without requiring indexed house-number entries', () => {
    expect(parseStreetAddressQuery('Hämeentie 10 Helsinki')).toEqual({
      houseNumber: '10',
      streetQuery: 'Hämeentie Helsinki',
    });
    expect(parseStreetAddressQuery('10B Tavastvägen')).toEqual({
      houseNumber: '10B',
      streetQuery: 'Tavastvägen',
    });
    expect(parseStreetAddressQuery('Helsinki')).toBeNull();
  });

  it('requires every word in a location-qualified query', async () => {
    const street: SearchResult = { name: 'Otakaari', displayName: 'Street', lat: 60.18, lng: 24.83,
      type: 'road', class: 'highway', contextParts: ['Espoo', 'Uusimaa', 'Finland'] };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: { version: 1, kind: 'iris-maps-place-search-index', placeCount: 2, searchIndexVersion: 2, prefix: 'p:', searchRoot: null },
      search: async () => [street, { ...street, name: 'Espoo', type: 'city', class: 'place' }],
      resolveAddress: async () => [],
    }));
    expect(await searchPlaces('Otakaari, Espoo', { center: [60.18, 24.83], zoom: 10 }, null)).toEqual([street]);
    expect(await searchPlaces('Otakaari, Helsinki', { center: [60.18, 24.83], zoom: 10 }, null)).toEqual([]);
  });

  it('shows distinct non-Latin location labels', () => {
    expect(resultDisplayLine({ name: '中央通り', displayName: 'Street', lat: 0, lng: 0,
      type: 'road', class: 'highway', contextParts: ['東京', '日本'] })).toBe('中央通り, 東京, 日本');
  });

  it('labels cities with their broader location rather than the district at their map pin', () => {
    const city: SearchResult = { name: 'London', displayName: 'City', lat: 51.507, lng: -.128,
      type: 'city', class: 'place', contextParts: ['Westminster', 'England', 'United Kingdom'] };
    expect(resultDisplayLine(city)).toBe('London, England, United Kingdom');
    expect(resultDisplayLine({ ...city, name: 'Київ', aliases: ['Kyiv'], contextParts: ['Kyiv', 'Ukraine'] }))
      .toBe('Київ, Ukraine');
  });

  it.each(['東京', 'Київ', 'Αθήνα', 'القاهرة'])('preserves non-Latin place names when searching for %s', async (name) => {
    const place: SearchResult = { name, displayName: 'City', lat: 0, lng: 0, type: 'city', class: 'place' };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: { version: 1, kind: 'iris-maps-place-search-index', placeCount: 1, searchIndexVersion: 1, prefix: 'p:', searchRoot: null },
      search: async () => [place],
      resolveAddress: async () => [],
    }));
    expect(await searchPlaces(name, { center: [0, 0], zoom: 2 }, null)).toEqual([place]);
  });

  it('tries the hashtree index and falls back to bundled labels without another network request', async () => {
    const results = await searchPlaces('Helsinki', {
      center: [60.17, 24.94],
      zoom: 12,
      bounds: [60.05, 60.33, 24.75, 25.2],
    }, null);

    expect(results[0]).toMatchObject({
      name: 'Helsinki',
      type: 'city',
      class: 'place',
      displayName: 'City',
    });

    const calls = vi.mocked(fetch).mock.calls.map(([url]) => String(url));
    expect(calls).toHaveLength(1);
    expect(calls[0]).toContain('/htree/');
    expect(calls[0]).toContain('/maps-search-openfreemap-world-z13-v1/root.json');
    expect(calls.join('\n')).not.toContain('nominatim.openstreetmap.org');
    expect(calls.join('\n')).not.toContain('photon.komoot.io');
  });

  it('finds cities offline when the remote index never responds', async () => {
    vi.useFakeTimers();
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => new Promise(() => {}));
    const pending = searchPlaces('Tokyo', { center: [0, 0], zoom: 2 }, null);
    await vi.advanceTimersByTimeAsync(5000);
    const results = await pending;
    expect(results[0]).toMatchObject({ name: 'Tokyo', type: 'city' });
    expect(fetch).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('keeps street results when a cold index takes more than two seconds', async () => {
    vi.useFakeTimers();
    const street: SearchResult = { name: 'Hämeentie', displayName: 'Street', lat: 60.18, lng: 24.96, type: 'primary', class: 'highway' };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: { version: 1, kind: 'iris-maps-place-search-index', placeCount: 1, searchIndexVersion: 1, prefix: 'p:', searchRoot: null },
      search: () => new Promise((resolve) => setTimeout(() => resolve([street]), 2500)),
      resolveAddress: async () => [],
    }));
    const pending = searchPlaces('Hämeentie', { center: [40.75, -73.98], zoom: 12 }, null);
    await vi.advanceTimersByTimeAsync(2500);
    expect(await pending).toEqual([street]);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('ranks nearby matching streets before far-away streets with the same name', async () => {
    const closeStreet: SearchResult = {
      id: 'street:mannerheimintie:helsinki',
      name: 'Mannerheimintie',
      aliases: ['Mannerheimvägen'],
      lat: 60.1885,
      lng: 24.9176,
      type: 'primary',
      class: 'highway',
      displayName: 'Street',
      addressType: 'road',
      sourceLayer: 'transportation_name',
    };
    const farStreet: SearchResult = {
      ...closeStreet,
      id: 'street:mannerheimintie:far-away',
      lat: 63.095,
      lng: 21.616,
    };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: {
        version: 1,
        kind: 'iris-maps-place-search-index',
        placeCount: 2,
        searchIndexVersion: 1,
        prefix: 'p:',
        searchRoot: null,
      },
      async search(query: string) {
        return query === 'mannerh' ? [farStreet, closeStreet] : [];
      },
      async resolveAddress() {
        return [];
      },
    }));

    const results = await searchPlaces('mannerh', {
      center: [60.188, 24.918],
      zoom: 15,
      bounds: [60.17, 60.2, 24.89, 24.94],
    }, null);

    expect(results.map((result) => result.id).slice(0, 2)).toEqual([
      'street:mannerheimintie:helsinki',
      'street:mannerheimintie:far-away',
    ]);
  });

  it('prefers the country over a far settlement with the same exact name', async () => {
    const country: SearchResult = {
      id: 'country:finland',
      name: 'Finland',
      lat: 64,
      lng: 26,
      type: 'country',
      class: 'boundary',
      displayName: 'Country',
      placeRank: 4,
      importance: 1,
      addressType: 'country',
    };
    const village: SearchResult = {
      id: 'village:finland',
      name: 'Finland',
      lat: 39.63,
      lng: -86.11,
      type: 'village',
      class: 'place',
      displayName: 'Village',
      placeRank: 20,
      importance: 0.08,
      addressType: 'village',
    };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: {
        version: 1,
        kind: 'iris-maps-place-search-index',
        placeCount: 2,
        searchIndexVersion: 1,
        prefix: 'p:',
        searchRoot: null,
      },
      async search(query: string) {
        return query === 'Finland' ? [village, country] : [];
      },
      async resolveAddress() {
        return [];
      },
    }));

    const results = await searchPlaces('Finland', {
      center: [60.17, 24.94],
      zoom: 5,
      bounds: [58, 70, 18, 32],
    }, null);

    expect(results[0].id).toBe('country:finland');
  });

  it('lets an exact local settlement beat a country when it is inside the focused viewport', async () => {
    const country: SearchResult = {
      id: 'country:finland',
      name: 'Finland',
      lat: 64,
      lng: 26,
      type: 'country',
      class: 'boundary',
      displayName: 'Country',
      placeRank: 4,
      importance: 1,
      addressType: 'country',
    };
    const localVillage: SearchResult = {
      id: 'village:finland',
      name: 'Finland',
      lat: 39.63,
      lng: -86.11,
      type: 'village',
      class: 'place',
      displayName: 'Village',
      placeRank: 20,
      importance: 0.08,
      addressType: 'village',
    };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: {
        version: 1,
        kind: 'iris-maps-place-search-index',
        placeCount: 2,
        searchIndexVersion: 1,
        prefix: 'p:',
        searchRoot: null,
      },
      async search(query: string) {
        return query === 'Finland' ? [country, localVillage] : [];
      },
      async resolveAddress() {
        return [];
      },
    }));

    const results = await searchPlaces('Finland', {
      center: [39.63, -86.11],
      zoom: 13,
      bounds: [39.55, 39.7, -86.2, -86],
    }, null);

    expect(results[0].id).toBe('village:finland');
  });

  it('keeps loaded streets missing from the global index', async () => {
    clearDetailProvider = setMapDetailSearchProvider((request) => {
      expect(request.query).toBe('Vemmelsäärentie');
      expect(request.addressQuery).toBeNull();
      return [{
        id: 'loaded-map:street:vemmelsaarentie',
        name: 'Vemmelsäärentie',
        lat: 60.177,
        lng: 24.805,
        type: 'minor',
        class: 'highway',
        displayName: 'Street',
        addressType: 'road',
        sourceLayer: 'transportation_name',
      }];
    });

    const results = await searchPlaces('Vemmelsäärentie', {
      center: [60.177, 24.805],
      zoom: 16,
      bounds: [60.15, 60.2, 24.75, 24.86],
    }, null);

    expect(resultDisplayLine(results[0])).toBe('Vemmelsäärentie');
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it('prefers a contextual indexed street over a contextless map segment inside it', async () => {
    const street: SearchResult = { id: 'indexed-otakaari', name: 'Otakaari', displayName: 'Street',
      lat: 60.18671, lng: 24.831306, type: 'tertiary', class: 'highway', addressType: 'road',
      boundingBox: [60.183008, 60.190412, 24.827728, 24.834884], contextParts: ['Espoo', 'Uusimaa', 'Finland'] };
    clearDetailProvider = setMapDetailSearchProvider(() => [{ ...street, id: 'map-segment', contextParts: undefined, lat: 60.187 }]);
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => ({
      manifest: { version: 1, kind: 'iris-maps-place-search-index', placeCount: 1, searchIndexVersion: 2, prefix: 'p:', searchRoot: null },
      search: async () => [street], resolveAddress: async () => [],
    }));
    expect(await searchPlaces('Otakaari', { center: [60.187, 24.83], zoom: 16 }, null)).toEqual([street]);
  });

  it('uses loaded map detail results for house-number-first visible address searches', async () => {
    clearDetailProvider = setMapDetailSearchProvider((request) => {
      expect(request.query).toBe('5 mannerh');
      expect(request.addressQuery).toEqual({
        houseNumber: '5',
        streetQuery: 'mannerh',
      });
      return [{
        id: 'loaded-map:street:mannerheimintie:address:5',
        name: 'Mannerheimintie 5',
        aliases: ['5 Mannerheimintie'],
        lat: 60.1695,
        lng: 24.9384,
        type: 'house',
        class: 'building',
        displayName: 'Address',
        addressType: 'house',
        sourceLayer: 'housenumber',
      }];
    });

    const results = await searchPlaces('5 mannerh', {
      center: [60.1695, 24.9384],
      zoom: 16,
      bounds: [60.16, 60.18, 24.92, 24.95],
    }, null);

    expect(resultDisplayLine(results[0])).toBe('Mannerheimintie 5');
    expect(fetch).not.toHaveBeenCalled();
  });

  it('resolves real house numbers from later sidecar-bearing segments of long streets', async () => {
    const targetStreetId = 'mannerheimintie-segment-18';
    const streetCandidates: SearchResult[] = Array.from({ length: 24 }, (_, index) => ({
      id: `mannerheimintie-segment-${index}`,
      name: 'Mannerheimintie',
      aliases: ['Mannerheimvägen'],
      lat: 60.17,
      lng: 24.94,
      type: 'primary',
      class: 'highway',
      displayName: 'Street',
      addressType: 'road',
      sourceLayer: 'transportation_name',
      addressRef: {
        kind: 'street-address-points-v1',
        cid: { hash: `address-ref-${index}` },
      },
    }));
    const source: MapPlaceSearchSource = {
      manifest: {
        version: 1,
        kind: 'iris-maps-place-search-index',
        placeCount: streetCandidates.length,
        searchIndexVersion: 1,
        prefix: 'p:',
        searchRoot: null,
      },
      async search(query: string) {
        return query === 'mannerh' ? streetCandidates : [];
      },
      async resolveAddress(street: SearchResult, houseNumber: string) {
        if (street.id !== targetStreetId || houseNumber !== '100') return [];
        return [{
          id: `${targetStreetId}:address:100`,
          name: 'Mannerheimintie 100',
          aliases: ['100 Mannerheimintie'],
          lat: 60.18854,
          lng: 24.91761,
          type: 'house',
          class: 'building',
          displayName: 'Address',
          addressType: 'house',
          sourceLayer: 'housenumber',
        }];
      },
    };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => source);

    const results = await searchPlaces('100 mannerh', {
      center: [60.1695, 24.9384],
      zoom: 12,
      bounds: [60.15, 60.22, 24.88, 24.98],
    }, null);

    expect(resultDisplayLine(results[0])).toBe('Mannerheimintie 100');
  });

  it('uses map detail address lookup when the global street index has no sidecars', async () => {
    const streetCandidate: SearchResult = {
      id: 'mannerheimintie-no-sidecar',
      name: 'Mannerheimintie',
      aliases: ['Mannerheimvägen'],
      lat: 60.19246,
      lng: 24.909793,
      type: 'primary',
      class: 'highway',
      displayName: 'Street',
      addressType: 'road',
      sourceLayer: 'transportation_name',
    };
    const source: MapPlaceSearchSource = {
      manifest: {
        version: 1,
        kind: 'iris-maps-place-search-index',
        placeCount: 1,
        searchIndexVersion: 1,
        prefix: 'p:',
        searchRoot: null,
      },
      async search(query: string) {
        return query === 'mannerh' ? [streetCandidate] : [];
      },
      async resolveAddress() {
        throw new Error('address sidecar should not be used for contextless street records');
      },
    };
    clearSourceProvider = setMapPlaceSearchSourceProvider(() => source);
    let fallbackRequests = 0;
    clearDetailProvider = setMapDetailSearchProvider((request) => {
      if (!request.streetCandidates?.length) return [];
      fallbackRequests += 1;
      expect(request.query).toBe('100 mannerh');
      expect(request.addressQuery).toEqual({ houseNumber: '100', streetQuery: 'mannerh' });
      expect(request.streetCandidates[0]).toMatchObject({ name: 'Mannerheimintie' });
      return [{
        id: 'basemap-tile:mannerheimintie-100',
        name: 'Mannerheimintie 100',
        aliases: ['100 Mannerheimintie'],
        lat: 60.18854,
        lng: 24.91761,
        type: 'house',
        class: 'building',
        displayName: 'Address',
        addressType: 'house',
        sourceLayer: 'housenumber',
      }];
    });

    const results = await searchPlaces('100 mannerh', {
      center: [59.325, 18.07],
      zoom: 10,
      bounds: [59.1, 59.6, 17.7, 18.4],
    }, null);

    expect(fallbackRequests).toBe(1);
    expect(resultDisplayLine(results[0])).toBe('Mannerheimintie 100');
  });
});

describe('map search result details', () => {
  const streetResult: SearchResult = {
    id: 'road:hameentie',
    name: 'Hämeentie',
    aliases: ['Tavastvägen', 'E75'],
    lat: 60.1904,
    lng: 24.962,
    type: 'primary',
    class: 'highway',
    displayName: 'Street',
    addressType: 'road',
    sourceLayer: 'transportation_name',
  };

  it('shows city context for street results when the index provides context parts', () => {
    const result = {
      ...streetResult,
      contextParts: ['Kallio', 'Helsinki', 'Uusimaa', 'Finland'],
    };

    expect(resultContextSummary(result)).toBe('Kallio, Helsinki, Uusimaa, Finland');
    expect(resultDetails(result)).toContain('Helsinki');
  });

  it('extracts city context for street results from full display names', () => {
    const result = {
      ...streetResult,
      displayName: 'Hämeentie, Helsinki, Uusimaa, Finland',
    };

    expect(resultContextSummary(result)).toBe('Helsinki, Uusimaa, Finland');
    expect(resultDetails(result)).toBe('Helsinki, Uusimaa, Finland · Tavastvägen · Route E75');
    expect(resultDisplayLine(result)).toBe('Hämeentie, Helsinki, Uusimaa, Finland');
  });

  it('uses the same locality summary for non-street search results', () => {
    const result: SearchResult = {
      id: 'poi:temppeliaukio',
      name: 'Temppeliaukio Church',
      lat: 60.173,
      lng: 24.925,
      type: 'place_of_worship',
      class: 'amenity',
      displayName: 'Place Of Worship',
      addressType: 'place_of_worship',
      contextParts: ['Etu-Töölö', 'Helsinki', 'Finland'],
    };

    expect(resultDetails(result)).toBe('Etu-Töölö, Helsinki, Finland');
    expect(resultDisplayLine(result)).toBe('Temppeliaukio Church, Etu-Töölö, Helsinki, Finland');
  });

  it('does not invent area context for contextless results', () => {
    const tapiola: SearchResult = {
      id: 'area:tapiola',
      name: 'Tapiola',
      lat: 60.177,
      lng: 24.805,
      type: 'suburb',
      class: 'place',
      displayName: 'Suburb',
      addressType: 'suburb',
    };
    const poi: SearchResult = {
      id: 'poi:cafe',
      name: 'Cafe Test',
      lat: 60.171,
      lng: 24.94,
      type: 'cafe',
      class: 'amenity',
      displayName: 'Cafe',
      addressType: 'cafe',
    };

    expect(resultDisplayLine(streetResult)).toBe('Hämeentie');
    expect(resultDisplayLine(tapiola)).toBe('Tapiola');
    expect(resultDisplayLine(poi)).toBe('Cafe Test');
  });
});
