import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mount = vi.fn();
const initServiceWorker = vi.fn();
const initReadonlyBackend = vi.fn();
const restoreSession = vi.fn();
const ensureMediaStreamingReady = vi.fn();
const initHtreeApi = vi.fn();
const setAppType = vi.fn();

async function waitForExpectation(expectation: () => void, attempts = 20): Promise<void> {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      expectation();
      return;
    } catch (error) {
      lastError = error;
      await Promise.resolve();
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  throw lastError;
}

describe('main-maps init order', () => {
  beforeEach(() => {
    vi.resetModules();
    mount.mockReset();
    initServiceWorker.mockReset();
    initReadonlyBackend.mockReset();
    restoreSession.mockReset();
    ensureMediaStreamingReady.mockReset();
    initHtreeApi.mockReset();
    setAppType.mockReset();
    vi.stubGlobal('document', {
      getElementById: vi.fn(() => ({ id: 'app' })),
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('waits for the service worker before mounting the maps app', async () => {
    let resolveSw: (() => void) | null = null;
    const swReady = new Promise<void>((resolve) => {
      resolveSw = resolve;
    });

    initServiceWorker.mockReturnValue(swReady);
    initReadonlyBackend.mockResolvedValue(undefined);
    restoreSession.mockResolvedValue(undefined);
    ensureMediaStreamingReady.mockResolvedValue(true);
    initHtreeApi.mockResolvedValue(undefined);

    vi.doMock('svelte', () => ({ mount }));
    vi.doMock('../src/lib/swInit', () => ({ initServiceWorker }));
    vi.doMock('../src/nostr/auth', () => ({ initReadonlyBackend, restoreSession }));
    vi.doMock('../src/lib/mediaStreamingSetup', () => ({ ensureMediaStreamingReady }));
    vi.doMock('../src/appType', () => ({ setAppType }));
    vi.doMock('../src/lib/htreeApi', () => ({ initHtreeApi }));
    vi.doMock('../src/MapsApp.svelte', () => ({ default: {} }));

    await import('../src/main-maps');
    await Promise.resolve();

    expect(initServiceWorker).toHaveBeenCalledOnce();
    expect(mount).not.toHaveBeenCalled();

    resolveSw?.();

    await waitForExpectation(() => {
      expect(mount).toHaveBeenCalledOnce();
    });
  });

  it('mounts the shell without waiting for backend media session or htree work', async () => {
    let resolveBackend: (() => void) | null = null;
    let resolveMedia: ((value: boolean) => void) | null = null;

    initServiceWorker.mockResolvedValue(undefined);
    initReadonlyBackend.mockReturnValue(new Promise<void>((resolve) => {
      resolveBackend = resolve;
    }));
    restoreSession.mockReturnValue(new Promise<boolean>(() => {}));
    ensureMediaStreamingReady.mockReturnValue(new Promise<boolean>((resolve) => {
      resolveMedia = resolve;
    }));
    initHtreeApi.mockReturnValue(new Promise<void>(() => {}));

    vi.doMock('svelte', () => ({ mount }));
    vi.doMock('../src/lib/swInit', () => ({ initServiceWorker }));
    vi.doMock('../src/nostr/auth', () => ({ initReadonlyBackend, restoreSession }));
    vi.doMock('../src/lib/mediaStreamingSetup', () => ({ ensureMediaStreamingReady }));
    vi.doMock('../src/appType', () => ({ setAppType }));
    vi.doMock('../src/lib/htreeApi', () => ({ initHtreeApi }));
    vi.doMock('../src/MapsApp.svelte', () => ({ default: {} }));

    await import('../src/main-maps');
    await waitForExpectation(() => {
      expect(mount).toHaveBeenCalledOnce();
    });
    expect(ensureMediaStreamingReady).not.toHaveBeenCalled();

    resolveBackend?.();
    await waitForExpectation(() => {
      expect(ensureMediaStreamingReady).toHaveBeenCalledOnce();
    });

    resolveMedia?.(true);
  });
});
