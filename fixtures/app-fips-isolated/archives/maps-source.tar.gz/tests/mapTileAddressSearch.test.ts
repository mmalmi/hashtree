import { describe, expect, it, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { DEFAULT_MAP_BASEMAP_ROOT_NHASH } from '../src/lib/mapBasemap';
import {
  createPmtilesVectorTileReader,
  searchStreetAddressInVectorTiles,
} from '../src/lib/mapTileAddressSearch';
import type { SearchResult } from '../src/stores/mapsTypes';

const mannerheimintieNear100: SearchResult = {
  id: 'test:mannerheimintie:z14:near-100',
  name: 'Mannerheimintie',
  aliases: ['Mannerheimvägen'],
  lat: 60.19246,
  lng: 24.909793,
  type: 'primary',
  class: 'highway',
  displayName: 'Street',
  addressType: 'road',
  sourceLayer: 'transportation_name',
};

describe('basemap tile address search', () => {
  it('retries unavailable tiles and bounds the decoded tile cache', async () => {
    const getZxy = vi.fn()
      .mockResolvedValueOnce(undefined)
      .mockRejectedValueOnce(new Error('Offline'))
      .mockResolvedValue({ data: new Uint8Array().buffer });
    const readTile = createPmtilesVectorTileReader({ getZxy });
    const first = { z: 14, x: 9327, y: 4740 };
    expect(await readTile(first)).toBeNull();
    expect(await readTile(first)).toBeNull();
    expect(await readTile(first)).not.toBeNull();
    await readTile(first);
    expect(getZxy).toHaveBeenCalledTimes(3);
    for (let x = 0; x < 128; x += 1) await readTile({ z: 14, x, y: 4740 });
    await readTile(first);
    expect(getZxy).toHaveBeenCalledTimes(132);
  });

  it('resolves Mannerheimintie 100 from real basemap housenumber features', async () => {
    // Captured through SHA-verified Hashtree blocks from the app's immutable map.
    // Tile bytes retain the real house/street geometry without a public test request.
    const fixture = JSON.parse(readFileSync(new URL('./fixtures/mannerheimintie-z14.json', import.meta.url), 'utf8'));
    expect(fixture.source).toContain(DEFAULT_MAP_BASEMAP_ROOT_NHASH);
    const readTile = createPmtilesVectorTileReader({ async getZxy(z, x, y) {
      const tile = fixture.tiles.find((entry: { z: number; x: number; y: number }) => entry.z === z && entry.x === x && entry.y === y);
      if (!tile) return undefined;
      const bytes = Buffer.from(tile.base64, 'base64');
      expect(createHash('sha256').update(bytes).digest('hex')).toBe(tile.sha256);
      return { data: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) };
    } });

    const results = await searchStreetAddressInVectorTiles({
      addressQuery: { houseNumber: '100', streetQuery: 'mannerh' },
      streetCandidates: [mannerheimintieNear100],
      readTile,
      sourceZoom: 14,
      maxJoinRadiusMeters: 45,
    });

    expect(results[0]).toMatchObject({
      name: 'Mannerheimintie 100',
      type: 'house',
      class: 'building',
      addressType: 'house',
      sourceLayer: 'housenumber',
    });
    expect(results[0]?.lat).toBeCloseTo(60.18854, 4);
    expect(results[0]?.lng).toBeCloseTo(24.91761, 4);

    const fakeResults = await searchStreetAddressInVectorTiles({
      addressQuery: { houseNumber: '987654', streetQuery: 'mannerh' },
      streetCandidates: [mannerheimintieNear100],
      readTile,
      sourceZoom: 14,
      maxJoinRadiusMeters: 45,
    });
    expect(fakeResults).toEqual([]);
  }, 60_000);
});
