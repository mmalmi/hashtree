import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL,
  DEFAULT_MAP_BASEMAP_GLYPHS_OWNER_NPUB,
  DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL,
  DEFAULT_MAP_BASEMAP_GLYPHS_ROOT_NHASH,
  DEFAULT_MAP_BASEMAP_GLYPHS_TREE,
  DEFAULT_MAP_BASEMAP_OWNER_NPUB,
  DEFAULT_MAP_BASEMAP_PMTILES_VERSION,
  DEFAULT_MAP_BASEMAP_TREE,
  DEFAULT_MAP_BASEMAP_ROOT_NHASH,
  buildImmutableHtreeBasemapUrl,
  buildMutableHtreeBasemapUrl,
  createMapBasemapConfig,
} from '../src/lib/mapBasemap';
import {
  DEFAULT_MAP_TILE_OWNER_NPUB,
  DEFAULT_MAP_TILE_TREE,
  buildMutableHtreeTileTemplate,
  createMapTileConfig,
} from '../src/lib/mapTiles';
import { withHtreeClientKey } from '../src/lib/htreeClientKey';

const gatewayTreeSegment = (treeName: string) => encodeURIComponent(treeName);

describe('map tile config', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('defaults to one immutable Hashtree archive without an Iris Sites bridge', () => {
    const config = createMapBasemapConfig({});

    expect(config).toMatchObject({
      ownerNpub: DEFAULT_MAP_BASEMAP_OWNER_NPUB,
      treeName: DEFAULT_MAP_BASEMAP_TREE,
      pmtilesUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`,
      lightStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
      darkStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
      styleUrls: {
        fiord: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
        positron: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
        liberty: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/liberty.json`,
        bright: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/bright.json`,
      },
      glyphsUrl: `${DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL}?v=20260617`,
      spriteUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm_f384/ofm`,
      minZoom: 0,
      maxNativeZoom: 14,
      maxZoom: 18,
    });
  });

  it('uses the same immutable archive when loaded through Iris Sites', () => {
    vi.stubGlobal('window', { location: { search: '?htree_c=client-key' } });
    const config = createMapBasemapConfig({});

    expect(config).toMatchObject({
      pmtilesUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`,
      lightStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
      darkStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
      styleUrls: {
        fiord: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
        positron: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
        liberty: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/liberty.json`,
        bright: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/bright.json`,
      },
      glyphsUrl: `${DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL}?v=20260617`,
      spriteUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm_f384/ofm`,
    });
  });

  it('can explicitly use same-origin htree paths for basemap assets', () => {
    const config = createMapBasemapConfig({
      VITE_MAP_BASEMAP_TRANSPORT: 'htree',
      VITE_MAP_BASEMAP_PMTILES_TRANSPORT: 'htree',
    });

    expect(config).toMatchObject({
      pmtilesUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`,
      lightStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
      darkStyleUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
      styleUrls: {
        fiord: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/fiord.json`,
        positron: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/positron.json`,
        liberty: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/liberty.json`,
        bright: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm/bright.json`,
      },
      glyphsUrl: `${DEFAULT_MAP_BASEMAP_GLYPHS_PUBLIC_URL}?v=20260617`,
      spriteUrl: `/htree/${DEFAULT_MAP_BASEMAP_ROOT_NHASH}/ofm_f384/ofm`,
    });
  });

  it('preserves explicit gateway and archive URL overrides', () => {
    const config = createMapBasemapConfig({ VITE_MAP_BASEMAP_TRANSPORT: 'gateway' });
    expect(config.pmtilesUrl).toBe(`${DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL}/${DEFAULT_MAP_BASEMAP_OWNER_NPUB}/${DEFAULT_MAP_BASEMAP_TREE}/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`);
    const customUrl = 'https://example.test/maps.pmtiles?revision=2';
    expect(createMapBasemapConfig({ VITE_MAP_BASEMAP_PMTILES_URL: customUrl }).pmtilesUrl).toBe(customUrl);
  });

  it('keeps custom datasets separate from the bundled immutable root', () => {
    const config = createMapBasemapConfig({
      VITE_MAP_BASEMAP_OWNER_NPUB: 'npub1custom',
      VITE_MAP_BASEMAP_TREE: 'custom/maps',
    });
    expect(config.pmtilesUrl).toBe(`/htree/npub1custom/custom%2Fmaps/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`);
    expect(config.lightStyleUrl).toBe('/htree/npub1custom/custom%2Fmaps/ofm/positron.json');
  });

  it('can explicitly pin a different dataset revision', () => {
    const config = createMapBasemapConfig({ VITE_MAP_BASEMAP_ROOT_NHASH: 'nhash1custom' });
    expect(config.pmtilesUrl).toBe(`/htree/nhash1custom/tiles.pmtiles?v=${DEFAULT_MAP_BASEMAP_PMTILES_VERSION}`);
    expect(config.spriteUrl).toBe('/htree/nhash1custom/ofm_f384/ofm');
  });

  it('can build a public hashtree gateway PMTiles asset URL', () => {
    expect(buildMutableHtreeBasemapUrl({
      ownerNpub: 'npub1example',
      treeName: 'maps/openfreemap starter',
      path: 'ofm/Noto Sans Regular/0-255.pbf',
      baseUrl: 'https://cdn.iris.to/',
    })).toBe('https://cdn.iris.to/npub1example/maps%2Fopenfreemap%20starter/ofm/Noto%20Sans%20Regular/0-255.pbf');
  });

  it('can build an immutable same-origin hashtree asset URL', () => {
    expect(buildImmutableHtreeBasemapUrl({
      nhash: 'nhash1example',
      path: 'ofm/Noto Sans Regular/0-255.pbf',
      htreePath: true,
    })).toBe('/htree/nhash1example/ofm/Noto%20Sans%20Regular/0-255.pbf');
  });

  it('can override glyphs back to a mutable hashtree tree', () => {
    const config = createMapBasemapConfig({
      VITE_MAP_BASEMAP_TRANSPORT: 'htree',
      VITE_MAP_BASEMAP_GLYPHS_OWNER_NPUB: DEFAULT_MAP_BASEMAP_GLYPHS_OWNER_NPUB,
      VITE_MAP_BASEMAP_GLYPHS_TREE: DEFAULT_MAP_BASEMAP_GLYPHS_TREE,
    });

    expect(config.glyphsUrl).toBe(
      `/htree/${DEFAULT_MAP_BASEMAP_GLYPHS_OWNER_NPUB}/${DEFAULT_MAP_BASEMAP_GLYPHS_TREE}/ofm/{fontstack}/{range}.pbf?v=20260617`,
    );
  });

  it('builds a public hashtree gateway tile template without encoding Leaflet placeholders', () => {
    expect(buildMutableHtreeTileTemplate({
      npub: 'npub1example',
      treeName: 'maps/tiles lowres',
      baseUrl: 'https://cdn.iris.to/',
    })).toBe('https://cdn.iris.to/npub1example/maps%2Ftiles%20lowres/tiles/{z}/{x}/{y}.png');
  });

  it('can build same-origin service worker htree paths for native runtimes', () => {
    expect(buildMutableHtreeTileTemplate({
      npub: 'npub1example',
      treeName: 'maps-tiles-overview-v2',
      htreePath: true,
    })).toBe('/htree/npub1example/maps-tiles-overview-v2/tiles/{z}/{x}/{y}.png');
  });

  it('defaults to low-res world raster tiles without a local detail square', () => {
    const config = createMapTileConfig({});

    expect(config.urlTemplate).toBe(`/htree/${DEFAULT_MAP_TILE_OWNER_NPUB}/${DEFAULT_MAP_TILE_TREE}/tiles/{z}/{x}/{y}.png`);
    expect(config.layers).toEqual([{
      id: 'lowres',
      urlTemplate: `/htree/${DEFAULT_MAP_TILE_OWNER_NPUB}/${DEFAULT_MAP_TILE_TREE}/tiles/{z}/{x}/{y}.png`,
      attribution: 'Map tiles: Natural Earth + hashtree',
      minZoom: 0,
      maxNativeZoom: 6,
      maxZoom: 16,
      tileSize: 256,
    }]);
    expect(config.minZoom).toBe(0);
    expect(config.maxNativeZoom).toBe(6);
    expect(config.maxZoom).toBe(16);
  });

  it('can explicitly use the public hashtree gateway for tile loading', () => {
    const config = createMapTileConfig({
      VITE_MAP_TILE_TRANSPORT: 'gateway',
    });

    expect(config.urlTemplate).toBe(
      `https://cdn.iris.to/${DEFAULT_MAP_TILE_OWNER_NPUB}/${gatewayTreeSegment(DEFAULT_MAP_TILE_TREE)}/tiles/{z}/{x}/{y}.png`,
    );
  });

  it('supports environment overrides', () => {
    const config = createMapTileConfig({
      VITE_MAP_TILE_URL_TEMPLATE: '/custom/{z}/{x}/{y}.webp',
      VITE_MAP_TILE_ATTRIBUTION: 'custom attribution',
      VITE_MAP_TILE_MAX_NATIVE_ZOOM: '3',
      VITE_MAP_TILE_MAX_ZOOM: '8',
      VITE_MAP_TILE_SIZE: '512',
    });

    expect(config).toEqual({
      urlTemplate: '/custom/{z}/{x}/{y}.webp',
      attribution: 'custom attribution',
      minZoom: 0,
      maxNativeZoom: 3,
      maxZoom: 8,
      tileSize: 512,
      layers: [{
        id: 'lowres',
        urlTemplate: '/custom/{z}/{x}/{y}.webp',
        attribution: 'custom attribution',
        minZoom: 0,
        maxNativeZoom: 3,
        maxZoom: 8,
        tileSize: 512,
      }],
    });
  });

  it('can add a separate hashtree detail tile tier for on-demand zoomed loading', () => {
    const config = createMapTileConfig({
      VITE_MAP_TILE_DETAIL_TREE: 'maps-tiles-streets',
      VITE_MAP_TILE_DETAIL_MIN_ZOOM: '3',
      VITE_MAP_TILE_DETAIL_MAX_NATIVE_ZOOM: '12',
      VITE_MAP_TILE_DETAIL_MAX_ZOOM: '14',
      VITE_MAP_TILE_DETAIL_EXTENSION: 'webp',
      VITE_MAP_TILE_DETAIL_BOUNDS: '59,17,60,18',
    });

    expect(config.maxZoom).toBe(16);
    expect(config.layers).toHaveLength(2);
    expect(config.layers[0]?.maxZoom).toBe(16);
    expect(config.layers[1]).toEqual({
      id: 'helsinki-detail',
      urlTemplate: `/htree/${DEFAULT_MAP_TILE_OWNER_NPUB}/maps-tiles-streets/tiles/{z}/{x}/{y}.webp`,
      attribution: 'Map details: OpenStreetMap contributors + hashtree',
      bounds: [[59, 17], [60, 18]],
      minZoom: 3,
      maxNativeZoom: 12,
      maxZoom: 14,
      tileSize: 256,
    });
  });

  it('carries the Iris Sites htree client key on same-origin basemap assets', () => {
    expect(withHtreeClientKey(
      `/htree/${DEFAULT_MAP_BASEMAP_OWNER_NPUB}/${DEFAULT_MAP_BASEMAP_TREE}/tiles.pmtiles`,
      'client-key',
    )).toBe(
      `/htree/${DEFAULT_MAP_BASEMAP_OWNER_NPUB}/${DEFAULT_MAP_BASEMAP_TREE}/tiles.pmtiles?htree_c=client-key`,
    );
    expect(withHtreeClientKey(
      `/htree/${DEFAULT_MAP_BASEMAP_GLYPHS_ROOT_NHASH}/ofm/{fontstack}/{range}.pbf?v=20260617`,
      'client-key',
    )).toBe(
      `/htree/${DEFAULT_MAP_BASEMAP_GLYPHS_ROOT_NHASH}/ofm/{fontstack}/{range}.pbf?v=20260617&htree_c=client-key`,
    );
  });

  it('does not put loader client keys on public gateway basemap assets', () => {
    const gatewayUrl = `${DEFAULT_MAP_BASEMAP_GATEWAY_BASE_URL}/${DEFAULT_MAP_BASEMAP_OWNER_NPUB}/${DEFAULT_MAP_BASEMAP_TREE}/tiles.pmtiles`;

    expect(withHtreeClientKey(gatewayUrl, 'client-key')).toBe(gatewayUrl);
  });
});
