import { describe, expect, it } from 'vitest';
import {
  getAppType,
  isMapsApp,
  shouldOpenSourceCodeLinkInNewTab,
  shouldShowGenericFileBrowser,
  supportsDocumentFeatures,
  supportsGitFeatures,
} from '../src/appType';

describe('app capabilities', () => {
  it('keeps the maps app limited to generic non-git file features', () => {
    expect(getAppType()).toBe('maps');
    expect(isMapsApp()).toBe(true);
    expect(supportsDocumentFeatures()).toBe(false);
    expect(supportsGitFeatures()).toBe(false);
    expect(shouldShowGenericFileBrowser()).toBe(true);
    expect(shouldOpenSourceCodeLinkInNewTab()).toBe(true);
  });
});
