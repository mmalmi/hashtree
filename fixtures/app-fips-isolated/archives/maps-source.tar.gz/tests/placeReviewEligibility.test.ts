import { describe, expect, it } from 'vitest';
import { canPlaceHaveReviews } from '../src/lib/placeReviewEligibility';
import type { ActivePlace } from '../src/stores/mapsTypes';

function place(input: Partial<ActivePlace>): ActivePlace {
  return {
    id: input.id ?? 'test-place',
    name: input.name ?? 'Test place',
    lat: input.lat ?? 0,
    lng: input.lng ?? 0,
    type: input.type,
    class: input.class,
    displayName: input.displayName,
    source: input.source ?? 'search',
  };
}

describe('place review eligibility', () => {
  it('hides reviews for basic map/search places like cities and countries', () => {
    expect(canPlaceHaveReviews(place({ name: 'Helsinki', type: 'city', class: 'place' }))).toBe(false);
    expect(canPlaceHaveReviews(place({ name: 'Finland', type: 'country', class: 'boundary' }))).toBe(false);
  });

  it('keeps reviews enabled for local saved places', () => {
    expect(canPlaceHaveReviews(place({ type: 'restaurant', class: 'place', source: 'place' }))).toBe(true);
  });

  it('keeps reviews enabled for searchable POIs', () => {
    expect(canPlaceHaveReviews(place({ type: 'restaurant', class: 'amenity' }))).toBe(true);
  });
});
