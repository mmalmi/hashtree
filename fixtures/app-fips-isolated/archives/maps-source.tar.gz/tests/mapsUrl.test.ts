import { describe, expect, it } from 'vitest';
import { internalMapsRouteFromInput } from '../src/lib/mapsUrl';

const listId = '8b9d8384-c005-426d-974d-4141be760bff';
const ownerNpub = 'npub169qdxhs922fn02z6crylner0h3l7ydhvahm3npzhlewclkjv7las3mh2at';
const listRoute = `/?list=${listId}&owner=${ownerNpub}&tree=btcmap`;

describe('maps URL helpers', () => {
  it('normalizes Iris Maps public list URLs to the local hash route', () => {
    expect(internalMapsRouteFromInput(`https://maps.iris.to/#${listRoute}`)).toBe(listRoute);
    expect(internalMapsRouteFromInput(`maps.iris.to/#${listRoute}`)).toBe(listRoute);
    expect(internalMapsRouteFromInput(`#${listRoute}`)).toBe(listRoute);
    expect(internalMapsRouteFromInput(listRoute)).toBe(listRoute);
  });

  it('normalizes localhost and htree app deep links', () => {
    expect(internalMapsRouteFromInput(`http://localhost:5173/#${listRoute}`)).toBe(listRoute);
    expect(internalMapsRouteFromInput(`http://127.0.0.1:5174/#${listRoute}`)).toBe(listRoute);
    expect(internalMapsRouteFromInput(
      `htree://npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/maps#${listRoute}`,
    )).toBe(listRoute);
  });

  it('keeps ordinary searches and external URLs in the search flow', () => {
    expect(internalMapsRouteFromInput('Nuucabdirxmaan')).toBeNull();
    expect(internalMapsRouteFromInput(`https://example.com/#${listRoute}`)).toBeNull();
    expect(internalMapsRouteFromInput(`htree://${ownerNpub}/btcmap/saved-place-list.json?list=${listId}`)).toBeNull();
  });

  it('accepts active place share URLs too', () => {
    const placeRoute = '/?place=%7B%22name%22%3A%22Test%22%2C%22lat%22%3A1%2C%22lng%22%3A2%7D';
    expect(internalMapsRouteFromInput(`https://maps.iris.to/#${placeRoute}`)).toBe(placeRoute);
  });
});
