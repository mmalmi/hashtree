# Iris Maps

Offline-first maps on Nostr and hashtree.

Source: <https://git.iris.to/#/npub1xdhnr9mrv47kkrn95k6cwecearydeh8e895990n3acntwvmgk2dsdeeycm/iris-maps>
Live: <https://maps.iris.to/>

## Development

```bash
pnpm install
pnpm run dev
```

City and country search includes a bundled Natural Earth dataset so it also works
offline or when the remote search index is unavailable. Refresh it with
`pnpm run labels:natural-earth -- --out work/map-labels`.

The full street/POI index is built by `pnpm run search:openfreemap`; the smaller
Natural Earth index uses `pnpm run search:natural-earth`. Both upload using the
configured Hashtree identity (`$HTREE_CONFIG_DIR/keys`, or `~/.hashtree/keys`).
Use `--upload-key-file <path>` to select a storage identity separately from the
publisher. The storage server must trust that identity for durable owned uploads;
anonymous/public cache uploads are not sufficient for preserving a dataset.
Run large imports against the origin's local HTTP endpoint. After upload, validate
and pin the complete tree through the origin's authenticated `/api/pin-tree`
endpoint with `{ "nhash": "<published root>" }`, and retain the source block store
and `publish-result.json`. Use `--skip-ref-publish` to upload before pinning and
announcing a mutable ref. `--skip-publish` builds without reading signing keys.

Search location labels use the representative point of each record inside
[Overture territorial boundaries](https://docs.overturemaps.org/guides/divisions/),
with the published administrative hierarchy. This avoids assigning a nearby city
across a municipal border. Local boundary coverage varies: a result may have only
a region or country. A road crossing boundaries uses the context of its map pin.
The boundary data is ODbL-1.0; its release, attribution, and coverage counts are
recorded in the search manifest. No reverse-geocoding service is needed at search time.

To enrich an existing packed index without downloading the map tiles again:

```bash
node scripts/export-map-search-records.mjs <publish-result.json> <records.jsonl>
python3 -m venv <venv>
<venv>/bin/pip install duckdb==1.5.5 shapely==2.1.2
<venv>/bin/python scripts/enrich-map-search-context.py \
  --records <records.jsonl> --areas '<division_area/*.parquet>' \
  --divisions '<division/*.parquet>' --release <Overture-release> \
  --out <enriched> --expected-count <original-placeCount>
pnpm run search:openfreemap -- --build-from-record-runs \
  --record-run-dir <enriched/records> --source-manifest <original-root.json> \
  --context-source <enriched/context-source.json> --out <new-index> --skip-ref-publish
```

Download both Parquet types from the same
[Overture release](https://docs.overturemaps.org/getting-data/cloud-sources/).
Keep enrichment inputs unchanged when resuming an output directory. Export checks
every source block and preserves the record count; indexes with address sidecars
still require their original address runs. Use a separate output directory for
each rebuild and pin the new root before updating the existing search ref.
The additional city-scoped postings support `street, city` and `street city`
queries without filling a country-name search with all its streets.

New OpenFreeMap builds also advertise `placeNames: { version: 1, prefix: "n:" }`.
This optional namespace indexes only settlement and administrative-area names and
aliases, linking to the same record shards as ordinary `p:` postings. The reader
merges these candidates by record ID before limiting results, keeping city names
from being crowded out by incidental street or ferry matches. Each namespace
scans at most `max(requested limit, 80)` postings per query term (plus one iterator
lookahead); final map scoring stays unchanged. Manifests without the capability
retain ordinary search. Shipping the reader alone does not fix an existing index:
a separate index rebuild, complete-tree verification/pinning, and search-ref
activation are required, preserving location context, address sidecars, and record
counts using the rebuild process above.

## Verification

```bash
pnpm run test:unit
pnpm run test:maps:iris
node ./scripts/release-site.mjs maps --dry-run
# For boundary enrichment changes, in the build-time Python environment:
<venv>/bin/python tests/mapSearchContext.test.py
```

## Release

```bash
pnpm run release:maps:iris
```

The release script builds once, tests the built output, publishes the built directory root to hashtree, and deploys the same directory to the `iris-maps` Cloudflare Worker target by default.
