# Hashtree Map Data Plan

Iris Maps should treat public map data as separately published hashtree
datasets, not as app assets. The app only carries dataset references and loads
the files it needs for the current viewport, zoom, or search query.

## Current State

- The bundled default points at `maps-openfreemap-world-z14-v1`, a separately
  published OpenFreeMap PMTiles world basemap derived from OpenStreetMap data.
  The current archive is about 80GB and contains vector tiles from z0..z14;
  MapLibre overzooms those native vector tiles above z14 while keeping zoom
  interaction enabled to z18.
- The bundled PMTiles archive, style JSON, and sprites use the same immutable
  root through same-origin `/htree/...` URLs. The root comes from signed event
  `d9a21514580c911b9abe14974a8da1ca57895c9c701be9e54421f2ea18a42f6f`;
  its file identifier and decrypted PMTiles header match the published dataset.
  Pinning it avoids depending on relay history at startup and prevents separate
  range requests from mixing archive revisions.
- The service worker forwards PMTiles ranges to the existing Hashtree worker.
  Its persistent block cache serves previously loaded tiles, styles, and sprites
  after an offline reload. Unvisited regions still require network access, and
  normal cache eviction applies. No separate map database or range cache is used.
- `VITE_MAP_BASEMAP_ROOT_NHASH` can pin a different dataset. Custom owner/tree
  settings retain mutable lookup; explicit gateway and file-URL overrides remain
  supported. Direct gateway ranges bypass the Hashtree block cache.
- Glyphs still use the configured OpenFreeMap font endpoint and its HTTP cache.
  The older Hashtree glyph reference is currently unavailable; changing it needs
  a verified replacement dataset. Font storage is separate from the tile cache.
- Country and city overlay labels still come from `maps-labels-natural-earth-v2`
  at `labels/overview.json`, currently a compact Natural Earth country +
  populated-place dataset with stricter min-zoom thresholds. The app also caps
  visible label count per zoom and skips overlapping labels.
- Place, street, and POI search should use `maps-search-openfreemap-world-z13-v1`,
  a hashtree-index built from the same OpenFreeMap PMTiles archive as the
  basemap. Search links point at packed JSON record shards, with the result id
  selecting the exact record inside the shard.
- The OpenFreeMap PMTiles archive itself includes renderable vector label layers
  for map text, but it is not a standalone geocoder or autocomplete index.
- User-created places and annotations stay in each user's `maps` tree.

## Dataset Shape

Publish a public dataset root such as `npub.../maps-data` with a small
`manifest.json`:

```json
{
  "version": 1,
  "kind": "iris-maps-data",
  "scheme": "web-mercator",
  "basemaps": [
    {
      "id": "openfreemap-world-z14",
      "kind": "pmtiles",
      "path": "tiles.pmtiles",
      "style": "ofm/fiord.json",
      "sprites": "ofm_f384/ofm",
      "glyphs": "ofm/{fontstack}/{range}.pbf?v=20260617",
      "minZoom": 0,
      "maxNativeZoom": 14,
      "maxZoom": 18,
      "attribution": "OpenFreeMap, OpenMapTiles, OpenStreetMap contributors"
    }
  ],
  "places": {
    "records": "places/by-id/{id}.json",
    "spatialShards": "places/by-tile/{z}/{x}/{y}.json",
    "spatialZooms": [6, 9, 12],
    "searchIndex": "indexes/place-search",
    "searchPrefix": "p:"
  },
  "streets": {
    "records": "streets/by-id/{id}.json",
    "spatialShards": "streets/by-tile/{z}/{x}/{y}.json",
    "spatialZooms": [12, 14],
    "searchIndex": "indexes/street-search",
    "searchPrefix": "s:"
  }
}
```

The app builds same-origin `/htree/...` URLs from the pinned default root.
Custom datasets can use mutable roots, and explicitly configured gateways use
the same manifest paths.

## Loading Model

- PMTiles basemaps are single archive files with an internal tile directory and
  tile payload chunks. MapLibre uses the PMTiles protocol to make HTTP Range
  reads against `tiles.pmtiles`; the service worker should preserve those ranges
  and the hashtree worker should resolve, decrypt, and assemble only the needed
  bytes client-side.
- Raster or loose vector tile tiers can still be ordinary `{z}/{x}/{y}` files
  when a future dataset benefits from file-per-tile addressing.
- Place and street labels should have compact spatial shards keyed by map tile.
  On `moveend`/`zoomend`, the app computes the covering shard tiles, fetches
  only those JSON chunks, and merges them into a small in-memory cache.
- Search should query `@hashtree/index` search roots first. Search hits return
  CIDs for packed candidate record shards plus the record id encoded in the link
  key. The app loads only those shards, selects the matched records, and ranks
  them with viewport and distance boosts.
- External geocoders are not the runtime default.

## Indexing

Use `@hashtree/index` primitives for stable public indexes:

- `SearchIndex` for name lookup:
  - `p:<term>:<place-id>` -> packed record shard CID
  - `s:<term>:<street-id>` -> packed record shard CID
- `BTree` for structured spatial lookup when a directory shard is not enough:
  - `tile:<z>/<x>/<y>:<id>` -> record CID
  - `bbox:<coarse-cell>:<id>` -> record CID

For app-owned or user-owned records, prefer `@hashtree/collection`. For the
public basemap/search corpus, a crawler can build immutable `@hashtree/index`
roots directly from OSM-derived extracts and publish the resulting dataset root.

## Build Path

1. Keep map-data publishing outside the app repo and verify published manifest
   and tile bytes before accepting a mutable dataset update.
2. Treat the OpenFreeMap z0..z14 PMTiles archive as the starter whole-world
   basemap, then consider regional detail archives or higher max-zoom extracts
   when the storage budget moves beyond the first roughly 80GB world dataset.
3. Build a place/street corpus from OSM-derived extracts into stable JSON
   records, spatial shards, and `@hashtree/index` search roots.
4. Prefer a manifest that can advertise multiple PMTiles archives, such as
   `world-z9.pmtiles` plus region or zoom-band PMTiles archives, so MapLibre can
   load higher detail only when the viewport and zoom need it.

Do not bulk-download public OpenStreetMap raster tiles. Generate tiles from
extracts or publish datasets whose licenses and usage terms allow redistribution.
