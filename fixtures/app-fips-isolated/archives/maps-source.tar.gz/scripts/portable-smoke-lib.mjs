import http from 'node:http';
import { mapAssetPrelude } from './portable-map-assets.mjs';
import { createDenyProxy, assertWorkerNetworkBlocked } from './isolatedBrowser.ts';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { chromium, expect } from '@playwright/test';

const MIME_TYPES = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.ico', 'image/x-icon'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.mjs', 'application/javascript; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.wasm', 'application/wasm'],
  ['.webmanifest', 'application/manifest+json; charset=utf-8'],
]);

function contentTypeFor(filePath) {
  return MIME_TYPES.get(path.extname(filePath)) ?? 'application/octet-stream';
}

function shouldIgnoreConsoleError(text) {
  if (/^Failed to load resource: the server responded with a status of 404\b/.test(text)) {
    return true;
  }
  if (/^Failed to load resource: the server responded with a status of 416\b/.test(text)) {
    return true;
  }
  if (/^WebSocket connection to 'wss?:\/\/[^']+' failed:/.test(text)) {
    return true;
  }
  if (/^WebSocket is already in CLOSING or CLOSED state\.?$/.test(text)) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: No connected relays available for publish')) {
    return true;
  }
  if (text.startsWith('[Worker] Failed to send WebRTC signaling: Error: rate-limited:')) {
    return true;
  }
  if (text.startsWith('Failed to publish initial profile: NDKPublishError: Not enough relays received the event')) {
    return true;
  }
  return false;
}

export function isExpectedOfflineTileError(message, request, smokeOrigin) {
  if (!message.offline || request?.type !== 'fetch'
    || request.error !== 'net::ERR_INTERNET_DISCONNECTED'
    || message.text !== 'Failed to load resource: net::ERR_INTERNET_DISCONNECTED') return false;
  const url = new URL(message.url);
  return url.origin !== smokeOrigin && url.pathname.endsWith('/tiles.pmtiles');
}

function safeJoin(rootDir, requestPath, entryHtml) {
  const normalized = requestPath === '/' ? `/${entryHtml}` : requestPath;
  const fullPath = path.resolve(rootDir, `.${normalized}`);
  if (!fullPath.startsWith(rootDir + path.sep) && fullPath !== path.join(rootDir, entryHtml)) {
    throw new Error(`Refusing to serve path outside root: ${requestPath}`);
  }
  return fullPath;
}

async function startServer(rootDir, entryHtml = 'index.html') {
  const server = http.createServer(async (req, res) => {
    try {
      const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1');
      if (requestUrl.pathname === '/__boundary') { res.end('<!doctype html><title>Boundary</title>'); return; }
      const filePath = safeJoin(rootDir, decodeURIComponent(requestUrl.pathname), entryHtml);
      let body = await readFile(filePath);
      if (process.env.MAP_FIXTURE_CACHE_URL && path.extname(filePath) === '.js') {
        body = Buffer.concat([Buffer.from(mapAssetPrelude(process.env.MAP_FIXTURE_CACHE_URL)), body]);
      }
      res.writeHead(200, {
        'content-type': contentTypeFor(filePath),
        'cache-control': 'no-store',
      });
      res.end(body);
    } catch (error) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(error instanceof Error ? error.message : 'not found');
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });

  const address = server.address();
  if (!address || typeof address === 'string') {
    server.close();
    throw new Error('Failed to determine portable smoke server address');
  }

  return {
    server,
    url: `http://127.0.0.1:${address.port}/${entryHtml}#/`,
  };
}

export async function runPortableSmoke({ distDir, title, appName, screenshotPath, validatePage, validateOfflinePage, entryHtml = 'index.html' }) {
  const { server, url } = await startServer(distDir, entryHtml);
  const boundary = await createDenyProxy();
  const browser = await chromium.launch({ headless: true, proxy: { server: boundary.url, bypass: '127.0.0.1,localhost,[::1]' } });
  const context = await browser.newContext({ serviceWorkers: 'allow' });
  const page = await context.newPage();
  // A local cache keeps this offline fixture independent of public price APIs.
  await page.addInitScript(() => {
    localStorage.setItem('btc-usd-rate', JSON.stringify({ rate: 100000, timestamp: Date.now() }));
  });
  await page.goto(new URL('/__boundary', url).href);
  await assertWorkerNetworkBlocked(page, boundary);
  const documentResponses = [];
  const localResponseFailures = [];
  const pageErrors = [];
  const consoleErrors = [];
  const failedRequests = new Map();
  let offline = false;
  const goOffline = async () => { offline = true; await page.context().setOffline(true); };
  const smokeOrigin = new URL(url).origin;

  page.on('requestfailed', request => {
    failedRequests.set(request.url(), { type: request.resourceType(), error: request.failure()?.errorText });
  });

  page.on('response', (response) => {
    if (response.request().resourceType() === 'document') {
      documentResponses.push(response.url());
    }
    if (response.status() < 400) {
      return;
    }
    let responseUrl;
    try {
      responseUrl = new URL(response.url());
    } catch {
      return;
    }
    if (responseUrl.origin !== smokeOrigin) {
      return;
    }
    if (responseUrl.pathname.startsWith('/htree/')) {
      return;
    }
    localResponseFailures.push(`${response.status()} ${response.request().resourceType()} ${response.url()}`);
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.stack || error.message);
  });
  page.on('console', (message) => {
    if (message.type() === 'error') {
      const text = message.text();
      if (shouldIgnoreConsoleError(text)) {
        return;
      }
      consoleErrors.push({ text, url: message.location().url, offline });
    }
  });

  try {
    const response = await page.goto(url, { waitUntil: 'load', timeout: 60000 });
    if (!response || response.status() !== 200) {
      throw new Error(`Portable build returned ${response?.status() ?? 'no response'} for ${url}`);
    }

    await page.waitForTimeout(3000);
    await page.screenshot({ path: screenshotPath, fullPage: true });

    const actualTitle = await page.title();
    if (actualTitle !== title) {
      throw new Error(`Portable build loaded unexpected title "${actualTitle}"`);
    }

    if (documentResponses.length > 2) {
      throw new Error(`Portable build reloaded unexpectedly (${documentResponses.length} document responses)`);
    }

    if (localResponseFailures.length > 0) {
      throw new Error(`Portable build hit local asset failures:\n${localResponseFailures.join('\n')}`);
    }

    const headerText = (await page.locator('header').textContent().catch(() => '')).toLowerCase();
    const hasAppHeader = headerText.includes(appName.toLowerCase());
    const hasLogin = await page.getByRole('button', { name: /^Login$/ }).isVisible().catch(() => false);
    const hasAccountMenu = await page.getByRole('button', { name: /^Account$/ }).isVisible().catch(() => false);
    const hasMapSearch = await page.getByTestId('map-search').isVisible().catch(() => false);
    if (!hasAppHeader && !hasLogin && !hasAccountMenu && !hasMapSearch) {
      const bodyPreview = (await page.locator('body').innerText()).slice(0, 500);
      throw new Error(`Portable build did not render the ${appName} shell. Body preview: ${bodyPreview}`);
    }

    if (typeof validatePage === 'function') {
      await validatePage(page, goOffline);
    }

    const profileButton = page.getByTestId('search-input');
    await expect(profileButton).toBeVisible();
    const existingKey = await page.evaluate(() => localStorage.getItem('hashtree:nsec'));
    assert.match(existingKey ?? '', /^nsec1/);
    await page.evaluate(async () => { await navigator.serviceWorker.ready; });
    await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
    await goOffline();
    await page.reload();
    if (typeof validateOfflinePage === 'function') {
      await validateOfflinePage(page);
    }
    await page.goto(new URL('./', page.url()).href);
    await expect(profileButton).toBeVisible();
    assert.equal(await page.evaluate(() => localStorage.getItem('hashtree:nsec')), existingKey);
    if (typeof validateOfflinePage === 'function') {
      await validateOfflinePage(page);
    }

    if (pageErrors.length > 0) {
      throw new Error(`Portable build hit page errors:\n${pageErrors.join('\n')}`);
    }

    const unexpected = consoleErrors.filter(message =>
      !isExpectedOfflineTileError(message, failedRequests.get(message.url), smokeOrigin));
    if (unexpected.length > 0) {
      throw new Error(`Portable build logged console errors:\n${unexpected.map(message => `${message.text} ${message.url}`).join('\n')}`);
    }

    console.log(`Portable Iris ${appName} smoke passed: ${url}`);
    console.log(`Screenshot: ${screenshotPath}`);
  } catch (error) {
    console.error(JSON.stringify({ portableDiagnostics: { consoleErrors: consoleErrors.slice(0, 20), pageErrors, failedRequests: [...failedRequests].slice(0, 30), denied: boundary.rejected.slice(0, 30) } }));
    throw error;
  } finally {
    await browser.close();
    await boundary.close();
    await new Promise((resolve) => server.close(resolve));
  }
}
