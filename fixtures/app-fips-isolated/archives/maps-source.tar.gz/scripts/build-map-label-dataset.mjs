#!/usr/bin/env node
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const SOURCES = {
  countries: {
    url: 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_countries.geojson',
    filename: 'ne_10m_admin_0_countries.geojson',
  },
  places: {
    url: 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_populated_places_simple.geojson',
    filename: 'ne_10m_populated_places_simple.geojson',
  },
};

function parseArgs(argv) {
  const options = {
    out: path.join(os.tmpdir(), `iris-maps-labels-${Date.now()}`),
    forceDownload: false,
    bundledOut: '',
  };
  const args = [...argv];
  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '--') continue;
    if (arg === '--out') {
      options.out = args.shift();
      continue;
    }
    if (arg === '--force-download') {
      options.forceDownload = true;
      continue;
    }
    if (arg === '--bundled-out') {
      options.bundledOut = args.shift();
      if (!options.bundledOut) throw new Error('--bundled-out requires a path');
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }
  if (!options.out) throw new Error('--out requires a path');
  return options;
}

async function exists(filePath) {
  try {
    await readFile(filePath);
    return true;
  } catch {
    return false;
  }
}

async function download(url, destination, forceDownload) {
  if (!forceDownload && await exists(destination)) return;
  await mkdir(path.dirname(destination), { recursive: true });
  const response = await fetch(url, {
    headers: { 'User-Agent': 'IrisMapsLabelSeeder/0.1 (+https://maps.iris.to)' },
  });
  if (!response.ok) {
    throw new Error(`Failed to download ${url}: ${response.status}`);
  }
  const bytes = new Uint8Array(await response.arrayBuffer());
  await writeFile(destination, bytes);
}

async function sha256File(filePath) {
  const bytes = await readFile(filePath);
  return createHash('sha256').update(bytes).digest('hex');
}

async function loadGeojson(filePath) {
  return JSON.parse(await readFile(filePath, 'utf8')).features;
}

function numberValue(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function countryMinZoom(properties) {
  const rank = numberValue(properties.LABELRANK) ?? numberValue(properties.MIN_LABEL) ?? 5;
  if (rank <= 2) return 0;
  if (rank <= 3) return 2;
  if (rank <= 4) return 3;
  if (rank <= 5) return 4;
  if (rank <= 6) return 5;
  return 6;
}

function cityMinZoom(properties) {
  const sourceZoom = numberValue(properties.min_zoom);
  const population = numberValue(properties.pop_max) ?? 0;
  let populationZoom = 10;
  if (population >= 10_000_000) populationZoom = 3;
  else if (population >= 5_000_000) populationZoom = 4;
  else if (population >= 1_000_000) populationZoom = 5;
  else if (population >= 500_000) populationZoom = 6;
  else if (population >= 250_000) populationZoom = 7;
  else if (population >= 100_000) populationZoom = 8;
  else if (population >= 50_000) populationZoom = 9;
  if (sourceZoom === undefined) return populationZoom;
  return Math.max(populationZoom, Math.floor(sourceZoom));
}

function countryLabel(feature) {
  const properties = feature.properties ?? {};
  const lat = numberValue(properties.LABEL_Y);
  const lng = numberValue(properties.LABEL_X);
  const name = properties.NAME_EN || properties.NAME || properties.ADMIN;
  if (!name || lat === undefined || lng === undefined) return null;
  return {
    name,
    lat,
    lng,
    kind: 'country',
    minZoom: countryMinZoom(properties),
    maxZoom: 6,
    population: numberValue(properties.POP_EST),
  };
}

function cityLabel(feature) {
  const properties = feature.properties ?? {};
  const coordinates = feature.geometry?.type === 'Point' ? feature.geometry.coordinates : undefined;
  const lng = numberValue(properties.longitude) ?? numberValue(coordinates?.[0]);
  const lat = numberValue(properties.latitude) ?? numberValue(coordinates?.[1]);
  const name = properties.nameascii || properties.name;
  if (!name || lat === undefined || lng === undefined) return null;
  return {
    name,
    lat,
    lng,
    kind: 'city',
    minZoom: cityMinZoom(properties),
    population: numberValue(properties.pop_max),
  };
}

function labelKey(label) {
  return `${label.kind}:${label.name.toLowerCase()}:${label.lat.toFixed(4)}:${label.lng.toFixed(4)}`;
}

function dedupeLabels(labels) {
  const seen = new Set();
  const deduped = [];
  for (const label of labels) {
    const key = labelKey(label);
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(label);
  }
  return deduped;
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const outDir = path.resolve(options.out);
  const sourceDir = path.join(outDir, 'sources');
  const labelDir = path.join(outDir, 'labels');
  await mkdir(labelDir, { recursive: true });

  const sourcePaths = {};
  for (const [name, source] of Object.entries(SOURCES)) {
    const sourcePath = path.join(sourceDir, source.filename);
    await download(source.url, sourcePath, options.forceDownload);
    sourcePaths[name] = sourcePath;
  }

  const countries = await loadGeojson(sourcePaths.countries);
  const places = await loadGeojson(sourcePaths.places);
  const labels = dedupeLabels([
    ...countries.map(countryLabel).filter(Boolean),
    ...places.map(cityLabel).filter(Boolean),
  ]).sort((a, b) => (
    a.kind === b.kind
      ? a.name.localeCompare(b.name)
      : a.kind.localeCompare(b.kind)
  ));

  const sources = {};
  for (const [name, source] of Object.entries(SOURCES)) {
    sources[name] = {
      url: source.url,
      sha256: await sha256File(sourcePaths[name]),
    };
  }

  const dataset = {
    version: 1,
    kind: 'iris-maps-labels',
    generatedAt: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    attribution: 'Natural Earth public-domain map label data.',
    sources,
    labelCount: labels.length,
    labels,
  };

  const outputPath = path.join(labelDir, 'overview.json');
  await writeFile(outputPath, `${JSON.stringify(dataset, null, 2)}\n`, 'utf8');
  if (options.bundledOut) {
    await mkdir(path.dirname(path.resolve(options.bundledOut)), { recursive: true });
    await writeFile(options.bundledOut, `${JSON.stringify(dataset)}\n`, 'utf8');
  }
  await writeFile(path.join(outDir, 'manifest.json'), `${JSON.stringify({
    version: 1,
    kind: 'iris-maps-label-dataset',
    generatedAt: dataset.generatedAt,
    labelCount: labels.length,
    labels: 'labels/overview.json',
    sources,
  }, null, 2)}\n`, 'utf8');
  console.log(`Wrote ${labels.length} labels to ${outputPath}`);
  console.log(`Dataset: ${outDir}`);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
