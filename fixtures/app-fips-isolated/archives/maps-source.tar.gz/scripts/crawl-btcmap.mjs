#!/usr/bin/env node
import { objectKeyFromHex } from '@hashtree/core';
import { spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { finalizeEvent, generateSecretKey, getPublicKey, nip19, SimplePool } from 'nostr-tools';
import { HASHTREE_ROOT_KIND as CURRENT_HASHTREE_ROOT_KIND } from '@hashtree/nostr';
import { resolveHtreeCommand } from './hashtreePaths.mjs';
import {
  IRIS_MAPS_LABEL as SHARED_IRIS_MAPS_LABEL,
  SAVED_PLACE_INDEX_FILE,
  SAVED_PLACE_INDEX_KIND,
  SAVED_PLACE_ITEM_EVENTS_FILE,
  SAVED_PLACE_LIST_LABEL as SHARED_SAVED_PLACE_LIST_LABEL,
  SAVED_PLACE_MEMBERSHIP_KIND,
  SAVED_PLACE_PROJECTIONS_FILE,
  buildSavedPlaceMembershipEventTemplate,
  buildSavedPlaceProjection,
  buildSavedPlaceProjectionIndex,
  savedPlaceIndexNames,
} from '../src/lib/savedPlaceIndex.ts';
import { buildSavedPlaceListUrls } from '../src/lib/savedPlaceListUrls.ts';
import {
  BTCMAP_LIST_AVATAR_URL,
  BTCMAP_LIST_DESCRIPTION,
  BTCMAP_SITE_URL,
} from '../src/lib/btcMapListMetadata.ts';
import {
  SAVED_PLACE_LIST_MANIFEST_FILE,
  SAVED_PLACE_LIST_ITEMS_DIR,
  DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD,
  DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE,
  buildSavedPlaceListItemPages,
  buildSavedPlaceListManifest as buildSharedSavedPlaceListManifest,
  savedPlaceListDirectoryPath,
  savedPlaceListItemPageFile,
} from '../src/lib/savedPlaceListManifest.ts';

export {
  SAVED_PLACE_LIST_MANIFEST_FILE,
  SAVED_PLACE_LIST_ITEMS_DIR,
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');

export const BTCMAP_API_BASE = 'https://api.btcmap.org';
export const DEFAULT_BTCMAP_LIMIT = 100;
export const DEFAULT_BTCMAP_SYNC_PAGE_LIMIT = 1000;
export const DEFAULT_PORTABLE_INDEX_MAX_ITEMS = 5000;
export const DEFAULT_TREE_ITEM_EVENT_MAX_ITEMS = 5000;
export const DEFAULT_LIST_NAME = 'BTC Map';
export const DEFAULT_TREE_NAME = 'btcmap';
export { BTCMAP_LIST_AVATAR_URL, BTCMAP_LIST_DESCRIPTION, BTCMAP_SITE_URL };
export const BTCMAP_RAW_CACHE_FILE = 'raw-places.jsonl';
export const BTCMAP_RAW_CACHE_META_FILE = 'raw-places-meta.json';
export const MAPS_DATA_VERSION = 3;
export const MAPS_META_VERSION = 1;
export const FACT_OP_KIND = 7368;
export const HASHTREE_ROOT_KIND = CURRENT_HASHTREE_ROOT_KIND;
export const IRIS_MAPS_LABEL = SHARED_IRIS_MAPS_LABEL;
export const SAVED_PLACE_LIST_LABEL = SHARED_SAVED_PLACE_LIST_LABEL;
// Keep root publication aligned with the relays the Maps app reads.
export const DEFAULT_RELAYS = [
  'wss://relay.ditto.pub',
  'wss://relay.damus.io',
  'wss://relay.primal.net',
  'wss://relay.nostr.band',
  'wss://relay.snort.social',
  'wss://temp.iris.to',
];

const btcMapPlaceFields = [
  'id',
  'lat',
  'lon',
  'icon',
  'name',
  'address',
  'opening_hours',
  'created_at',
  'updated_at',
  'verified_at',
  'phone',
  'website',
  'twitter',
  'facebook',
  'instagram',
  'line',
  'telegram',
  'email',
  'boosted_until',
  'required_app_url',
  'image',
  'description',
  'comments',
  'deleted_at',
  'payment_provider',
];

const subjectMarker = 'subject';
const reservedTags = new Set(['d', 'e', 'i', 'p']);
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const hex64Pattern = /^[0-9a-f]{64}$/;

function defaultPaths(env = process.env) {
  const home = env.HOME || os.homedir();
  const runDir = path.join(appDir, '.local', 'btcmap-crawler');
  return {
    keyFile: path.join(home, '.keys', 'iris-maps-btcmap-crawler.nsec'),
    outDir: path.join(runDir, 'tree'),
    cacheDir: path.join(runDir, 'cache'),
    stateFile: path.join(runDir, 'state.json'),
    htreeConfigDir: path.join(runDir, 'htree-config'),
    htreeDataDir: path.join(runDir, 'htree-data'),
  };
}

export function parseArgs(argv, env = process.env) {
  const defaults = defaultPaths(env);
  const options = {
    limit: DEFAULT_BTCMAP_LIMIT,
    all: false,
    pageLimit: DEFAULT_BTCMAP_SYNC_PAGE_LIMIT,
    listName: DEFAULT_LIST_NAME,
    visibility: 'public',
    treeName: DEFAULT_TREE_NAME,
    keyFile: defaults.keyFile,
    outDir: defaults.outDir,
    cacheDir: defaults.cacheDir,
    stateFile: defaults.stateFile,
    htreeConfigDir: defaults.htreeConfigDir,
    htreeDataDir: defaults.htreeDataDir,
    apiBase: BTCMAP_API_BASE,
    relays: [...DEFAULT_RELAYS],
    publishTimeoutMs: 7_500,
    htreeBin: env.HTREE_BIN || '',
    dryRun: false,
    skipPublish: false,
    skipItemPublish: false,
    skipFactPublish: false,
    skipRootPublish: false,
    resetList: false,
    fromCache: false,
    noCache: false,
    sampleSize: DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE,
    sampleThreshold: DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD,
    portableIndexMaxItems: DEFAULT_PORTABLE_INDEX_MAX_ITEMS,
    treeItemEventMaxItems: DEFAULT_TREE_ITEM_EVENT_MAX_ITEMS,
    help: false,
  };

  const args = [...argv];
  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '--') {
      continue;
    }
    if (arg === '-h' || arg === '--help') {
      options.help = true;
      continue;
    }
    if (arg === '--limit') {
      options.limit = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--all') {
      options.all = true;
      continue;
    }
    if (arg === '--page-limit') {
      options.pageLimit = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--list-name') {
      options.listName = readValue(args, arg).trim();
      continue;
    }
    if (arg === '--visibility') {
      const value = readValue(args, arg);
      if (value !== 'public' && value !== 'private') {
        throw new Error('--visibility must be public or private');
      }
      options.visibility = value;
      continue;
    }
    if (arg === '--tree-name') {
      options.treeName = readValue(args, arg).trim();
      continue;
    }
    if (arg === '--key-file') {
      options.keyFile = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--out') {
      options.outDir = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--cache-dir') {
      options.cacheDir = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--state-file') {
      options.stateFile = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--htree-config-dir') {
      options.htreeConfigDir = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--htree-data-dir') {
      options.htreeDataDir = path.resolve(readValue(args, arg));
      continue;
    }
    if (arg === '--api-base') {
      options.apiBase = readValue(args, arg).replace(/\/+$/, '');
      continue;
    }
    if (arg === '--relay') {
      options.relays.push(readValue(args, arg));
      continue;
    }
    if (arg === '--relays') {
      options.relays = readValue(args, arg).split(',').map((relay) => relay.trim()).filter(Boolean);
      continue;
    }
    if (arg === '--publish-timeout-ms') {
      options.publishTimeoutMs = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--htree-bin') {
      options.htreeBin = readValue(args, arg);
      continue;
    }
    if (arg === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    if (arg === '--skip-publish') {
      options.skipPublish = true;
      options.skipItemPublish = true;
      options.skipFactPublish = true;
      options.skipRootPublish = true;
      continue;
    }
    if (arg === '--skip-item-publish') {
      options.skipItemPublish = true;
      continue;
    }
    if (arg === '--skip-fact-publish') {
      options.skipFactPublish = true;
      continue;
    }
    if (arg === '--skip-root-publish') {
      options.skipRootPublish = true;
      continue;
    }
    if (arg === '--reset-list') {
      options.resetList = true;
      continue;
    }
    if (arg === '--from-cache') {
      options.fromCache = true;
      continue;
    }
    if (arg === '--no-cache') {
      options.noCache = true;
      continue;
    }
    if (arg === '--sample-size') {
      options.sampleSize = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--sample-threshold') {
      options.sampleThreshold = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--portable-index-max-items') {
      options.portableIndexMaxItems = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    if (arg === '--tree-item-event-max-items') {
      options.treeItemEventMaxItems = parsePositiveInteger(readValue(args, arg), arg);
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  if (!options.listName) throw new Error('--list-name cannot be empty');
  if (!options.treeName) throw new Error('--tree-name cannot be empty');
  if (options.visibility !== 'public' && !options.dryRun && !options.skipPublish) {
    throw new Error('Publishing private saved-place list roots is not implemented yet; use --dry-run or --skip-publish');
  }
  options.relays = [...new Set(options.relays.map((relay) => relay.trim()).filter(Boolean))];
  return options;
}

function readValue(args, flag) {
  const value = args.shift();
  if (!value || value.startsWith('--')) {
    throw new Error(`${flag} requires a value`);
  }
  return value;
}

function parsePositiveInteger(value, flag) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    throw new Error(`${flag} must be a positive integer`);
  }
  return parsed;
}

export function printHelp() {
  console.log(`Usage: pnpm run crawl:btcmap -- [options]

Fetch BTC Map merchants into an Iris Maps saved-place list tree and publish it
as the crawler user's "${DEFAULT_TREE_NAME}" hashtree root.

Options:
  --limit <n>                 Places to fetch (default: ${DEFAULT_BTCMAP_LIMIT})
  --all                       Chronologically sync all BTC Map places into cache
  --page-limit <n>            Page size for --all sync (default: ${DEFAULT_BTCMAP_SYNC_PAGE_LIMIT})
  --from-cache                Build outputs from the raw cache without fetching
  --no-cache                  Do not write fetched raw BTC Map records to cache
  --cache-dir <path>          Raw BTC Map cache directory (default: .local/btcmap-crawler/cache)
  --sample-size <n>           Browser dynamic world sample size for large lists (default: ${DEFAULT_SAVED_PLACE_LIST_DYNAMIC_SAMPLE_SIZE})
  --sample-threshold <n>      Only advertise dynamic sampling above this size (default: ${DEFAULT_SAVED_PLACE_LIST_SAMPLE_THRESHOLD})
  --portable-index-max-items <n>
                              Write full JSON index only up to this item count (default: ${DEFAULT_PORTABLE_INDEX_MAX_ITEMS})
  --tree-item-event-max-items <n>
                              Bundle signed item events in tree only up to this item count (default: ${DEFAULT_TREE_ITEM_EVENT_MAX_ITEMS})
  --list-name <name>          Saved-place list name (default: "${DEFAULT_LIST_NAME}")
  --visibility <public|private>
  --tree-name <name>          Hashtree root/list name (default: "${DEFAULT_TREE_NAME}")
  --dry-run                   Fetch, write files, and sign locally without publishing
  --skip-publish              Write files but skip fact-event, root-event, and blob publishing
  --skip-item-publish         Publish the root/fact events but skip item membership events
  --skip-fact-publish         Publish the hashtree only, not the kind-${FACT_OP_KIND} event
  --skip-root-publish         Add/push blobs but skip the labeled kind-${HASHTREE_ROOT_KIND} root event
  --reset-list                Create a fresh list UUID instead of reusing crawler state
  --key-file <path>           Crawler nsec file (default: ~/.keys/iris-maps-btcmap-crawler.nsec)
  --out <path>                Tree output directory (default: .local/btcmap-crawler/tree)
  --htree-bin <path>          htree binary override
  --relays <csv>              Relays for the list fact event`);
}

export function createBtcMapPlacesUrl(options = {}) {
  const apiBase = options.apiBase ?? BTCMAP_API_BASE;
  const limit = options.limit ?? options.pageLimit ?? DEFAULT_BTCMAP_LIMIT;
  const url = new URL('/v4/places', apiBase.endsWith('/') ? apiBase : `${apiBase}/`);
  if (limit) {
    url.searchParams.set('limit', String(limit));
  }
  if (options.updatedSince) {
    url.searchParams.set('updated_since', options.updatedSince);
  }
  if (options.includeDeleted) {
    url.searchParams.set('include_deleted', 'true');
  }
  url.searchParams.set('fields', btcMapPlaceFields.join(','));
  return url;
}

export async function fetchBtcMapPlaces(options = {}) {
  if (options.fromCache) {
    return readBtcMapRawCache(options.cacheDir).records;
  }
  if (options.all) {
    const sync = await syncBtcMapPlaces(options);
    if (!options.noCache) {
      writeBtcMapRawCache(options.cacheDir, sync.records, sync.summary);
    }
    return sync.records;
  }
  const url = createBtcMapPlacesUrl(options);
  const response = await fetch(url, {
    headers: {
      accept: 'application/json',
      'user-agent': 'iris-maps-btcmap-crawler/1.0',
    },
  });
  if (!response.ok) {
    throw new Error(`BTC Map API returned ${response.status} ${response.statusText}`);
  }
  const data = await response.json();
  if (!Array.isArray(data)) {
    throw new Error('BTC Map API response was not an array');
  }
  if (!options.noCache) {
    writeBtcMapRawCache(options.cacheDir, data, {
      version: 1,
      provider: 'btcmap',
      mode: 'limited',
      fetchedAt: new Date().toISOString(),
      sourceUrl: url.toString(),
      requestedLimit: options.limit ?? DEFAULT_BTCMAP_LIMIT,
      recordCount: data.length,
      fields: btcMapPlaceFields,
    });
  }
  return data;
}

export async function syncBtcMapPlaces(options = {}) {
  const pageLimit = options.pageLimit ?? DEFAULT_BTCMAP_SYNC_PAGE_LIMIT;
  const startedAt = Date.now();
  let updatedSince = options.updatedSince ?? '1970-01-01T00:00:00Z';
  const recordsById = new Map();
  const pages = [];

  while (true) {
    const url = createBtcMapPlacesUrl({
      ...options,
      limit: pageLimit,
      updatedSince,
      includeDeleted: true,
    });
    const response = await fetch(url, {
      headers: {
        accept: 'application/json',
        'user-agent': 'iris-maps-btcmap-crawler/1.0',
      },
    });
    if (!response.ok) {
      throw new Error(`BTC Map API returned ${response.status} ${response.statusText}`);
    }
    const page = await response.json();
    if (!Array.isArray(page)) {
      throw new Error('BTC Map API response was not an array');
    }
    pages.push({
      url: url.toString(),
      count: page.length,
      updatedSince,
      firstUpdatedAt: maxUpdatedAt(page.slice(0, 1)),
      lastUpdatedAt: maxUpdatedAt(page),
    });
    for (const record of page) {
      const sourceId = normalizeSourceId(record?.id);
      if (sourceId) recordsById.set(sourceId, record);
    }
    if (page.length < pageLimit) break;
    const nextCursor = maxUpdatedAt(page);
    if (!nextCursor || Date.parse(nextCursor) <= Date.parse(updatedSince)) {
      throw new Error(`BTC Map sync cursor did not advance from ${updatedSince}`);
    }
    updatedSince = nextCursor;
  }

  const records = [...recordsById.values()].sort(compareBtcMapRecords);
  return {
    records,
    summary: {
      version: 1,
      provider: 'btcmap',
      mode: 'chronological-sync',
      fetchedAt: new Date(startedAt).toISOString(),
      completedAt: new Date().toISOString(),
      apiBase: options.apiBase ?? BTCMAP_API_BASE,
      pageLimit,
      pageCount: pages.length,
      recordCount: records.length,
      activeRecordCount: records.filter((record) => !record?.deleted_at).length,
      deletedRecordCount: records.filter((record) => record?.deleted_at).length,
      cursor: updatedSince,
      fields: btcMapPlaceFields,
      pages,
    },
  };
}

export function writeBtcMapRawCache(cacheDir, records, summary) {
  if (!cacheDir) return;
  fs.mkdirSync(cacheDir, { recursive: true });
  fs.writeFileSync(
    path.join(cacheDir, BTCMAP_RAW_CACHE_FILE),
    `${records.map((record) => JSON.stringify(record)).join('\n')}\n`,
  );
  fs.writeFileSync(
    path.join(cacheDir, BTCMAP_RAW_CACHE_META_FILE),
    `${JSON.stringify(summary, null, 2)}\n`,
  );
}

export function readBtcMapRawCache(cacheDir) {
  if (!cacheDir) throw new Error('BTC Map cache directory is required');
  const rawPath = path.join(cacheDir, BTCMAP_RAW_CACHE_FILE);
  const metaPath = path.join(cacheDir, BTCMAP_RAW_CACHE_META_FILE);
  const records = fs.readFileSync(rawPath, 'utf8')
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => JSON.parse(line));
  let meta = null;
  try {
    meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
  } catch {
    meta = null;
  }
  return { records, meta };
}

function maxUpdatedAt(records) {
  let max = '';
  for (const record of records) {
    const value = normalizeText(record?.updated_at);
    if (!value) continue;
    if (!max || Date.parse(value) > Date.parse(max)) {
      max = value;
    }
  }
  return max;
}

function compareBtcMapRecords(left, right) {
  const leftUpdated = normalizeText(left?.updated_at);
  const rightUpdated = normalizeText(right?.updated_at);
  const leftId = normalizeSourceId(left?.id);
  const rightId = normalizeSourceId(right?.id);
  const numericIdOrder = Number(leftId) - Number(rightId);
  return Date.parse(leftUpdated || '1970-01-01T00:00:00Z') - Date.parse(rightUpdated || '1970-01-01T00:00:00Z')
    || (Number.isFinite(numericIdOrder) ? numericIdOrder : 0)
    || leftId.localeCompare(rightId);
}

export function normalizeBtcMapPlace(raw, savedAt = Date.now()) {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw;
  if (normalizeText(record.deleted_at)) return null;
  const sourceId = normalizeSourceId(record.id);
  const lat = Number(record.lat);
  const lng = Number(record.lon);
  if (!sourceId || !Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;

  const type = normalizeText(record.icon) || 'merchant';
  const name = normalizeText(record.name) || `BTC Map merchant ${sourceId}`;
  const context = buildBtcMapContext(record);
  const details = buildBtcMapDetails(record);
  return {
    key: `btcmap:place:${sourceId}`,
    id: `btcmap:place:${sourceId}`,
    name,
    lat,
    lng,
    type,
    class: 'place',
    displayName: labelForType(type),
    context: context || undefined,
    details,
    source: 'search',
    sourceLayer: 'btcmap',
    sourceId,
    savedAt,
  };
}

function normalizeSourceId(value) {
  if (typeof value === 'number' && Number.isInteger(value)) return String(value);
  if (typeof value === 'string' && value.trim()) return value.trim();
  return '';
}

function normalizeText(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function buildBtcMapContext(record) {
  const parts = [
    normalizeText(record.address),
    formatVerifiedDate(record.verified_at),
    normalizeText(record.payment_provider) ? `Payment: ${normalizeText(record.payment_provider)}` : '',
    normalizeText(record.website),
  ].filter(Boolean);
  return parts.join(' | ');
}

function buildBtcMapDetails(record) {
  const imageUrl = normalizeDirectImageUrl(record.image);
  const links = buildBtcMapDetailLinks(record);
  const details = {
    address: normalizeText(record.address) || undefined,
    description: normalizeText(record.description) || undefined,
    phone: normalizeText(record.phone) || undefined,
    email: normalizeText(record.email) || undefined,
    website: normalizeWebUrl(record.website),
    openingHours: normalizeText(record.opening_hours) || undefined,
    imageUrl,
    paymentProvider: normalizeText(record.payment_provider) || undefined,
    requiredAppUrl: normalizeWebUrl(record.required_app_url),
    verifiedAt: normalizeText(record.verified_at) || undefined,
    links: links.length > 0 ? links : undefined,
  };
  return Object.values(details).some((value) => value !== undefined) ? details : undefined;
}

function buildBtcMapDetailLinks(record) {
  const links = [
    detailLink('Website', record.website, 'website'),
    detailLink('Facebook', record.facebook, 'social'),
    detailLink('Instagram', record.instagram, 'social'),
    detailLink('X', record.twitter, 'social'),
    detailLink('Telegram', record.telegram, 'social'),
    detailLink('Line', record.line, 'social'),
    detailLink('Payment app', record.required_app_url, 'payment'),
  ].filter(Boolean);
  const seen = new Set();
  return links.filter((link) => {
    const key = link.url.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function detailLink(label, value, kind) {
  const url = normalizeWebUrl(value);
  return url ? { label, url, kind } : null;
}

function normalizeWebUrl(value) {
  const text = normalizeText(value);
  if (!text) return undefined;
  try {
    const url = new URL(text);
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.toString() : undefined;
  } catch {
    return undefined;
  }
}

function normalizeDirectImageUrl(value) {
  const url = normalizeWebUrl(value);
  if (!url) return undefined;
  try {
    const parsed = new URL(url);
    return /\.(avif|gif|jpe?g|png|webp)$/i.test(parsed.pathname) ? parsed.toString() : undefined;
  } catch {
    return undefined;
  }
}

function formatVerifiedDate(value) {
  const text = normalizeText(value);
  if (!text) return '';
  const timestamp = Date.parse(text);
  if (!Number.isFinite(timestamp)) return '';
  return `Verified ${new Date(timestamp).toISOString().slice(0, 10)}`;
}

function labelForType(type) {
  const words = type.split(/[_-]+/).filter(Boolean);
  if (words.length === 0) return 'BTC Map merchant';
  return words.map((word) => `${word.slice(0, 1).toUpperCase()}${word.slice(1)}`).join(' ');
}

function uniqueSavedPlaces(items) {
  const seen = new Set();
  const unique = [];
  for (const item of items) {
    if (seen.has(item.key)) continue;
    seen.add(item.key);
    unique.push(item);
  }
  return unique;
}

export function loadCrawlerState(stateFile, resetList = false, now = Date.now()) {
  if (!resetList) {
    try {
      const parsed = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
      if (
        parsed
        && typeof parsed.listId === 'string'
        && isUuid(parsed.listId)
        && typeof parsed.createdAt === 'number'
        && Number.isFinite(parsed.createdAt)
      ) {
        return {
          version: 1,
          listId: parsed.listId,
          createdAt: parsed.createdAt,
          rootEventCreatedAt: typeof parsed.rootEventCreatedAt === 'number' && Number.isFinite(parsed.rootEventCreatedAt)
            ? parsed.rootEventCreatedAt
            : undefined,
        };
      }
    } catch {
      // Missing or invalid state creates a fresh list below.
    }
  }
  return {
    version: 1,
    listId: crypto.randomUUID(),
    createdAt: now,
  };
}

export function saveCrawlerState(stateFile, state) {
  fs.mkdirSync(path.dirname(stateFile), { recursive: true, mode: 0o700 });
  fs.writeFileSync(stateFile, `${JSON.stringify(state, null, 2)}\n`);
}

export function buildBtcMapSavedPlaceList(rawPlaces, state, options = {}) {
  const now = options.now ?? Date.now();
  const items = uniqueSavedPlaces(
    rawPlaces
      .map((place) => normalizeBtcMapPlace(place, now))
      .filter(Boolean),
  );
  const list = {
    id: state.listId,
    name: options.listName ?? DEFAULT_LIST_NAME,
    description: options.listDescription ?? BTCMAP_LIST_DESCRIPTION,
    icon: 'map-pin',
    avatarUrl: options.listAvatarUrl ?? BTCMAP_LIST_AVATAR_URL,
    visibility: options.visibility ?? 'public',
    places: items,
    createdAt: state.createdAt,
    updatedAt: now,
  };
  if (list.visibility === 'public') {
    list.factEvent = buildSavedPlaceListFactEvent(list);
  }
  return list;
}

export function buildSavedPlaceListManifest(list, options = {}) {
  const projectionCount = options.index?.projectionCount ?? list.places.length;
  return buildSharedSavedPlaceListManifest(
    {
      ...list,
      urls: list.urls ?? options.urls ?? undefined,
    },
    {
      index: {
        kind: SAVED_PLACE_INDEX_KIND,
        file: SAVED_PLACE_INDEX_FILE,
        projections: SAVED_PLACE_PROJECTIONS_FILE,
        itemEvents: options.includeItemEvents === false ? undefined : SAVED_PLACE_ITEM_EVENTS_FILE,
        projectionCount,
        indexes: [
          'by-id',
          'by-list-time',
          'by-list-geohash-time',
          'by-list-place-key',
          'by-geohash-time',
          'by-author-list-time',
        ],
      },
      renderingProjections: {
        dynamicGeojson: {
          kind: 'hashtree-geohash-index',
          index: SAVED_PLACE_INDEX_FILE,
          sourceIndex: 'by-list-geohash-time',
          cluster: true,
        },
        pmtilesOverlay: options.pmtilesOverlay ?? null,
      },
      sampleSize: options.sampleSize,
      sampleThreshold: options.sampleThreshold,
      source: options.source ?? undefined,
      labels: [IRIS_MAPS_LABEL, SAVED_PLACE_LIST_LABEL],
    },
  );
}

export function buildMapsPayload(list) {
  const listSummary = {
    ...list,
    places: [],
  };
  return {
    version: MAPS_DATA_VERSION,
    places: [],
    annotations: [],
    reviews: [],
    savedPlaceLists: list.visibility === 'public' ? [listSummary] : [],
  };
}

export function buildMapsMeta(options) {
  const now = options.now ?? Date.now();
  return {
    version: MAPS_META_VERSION,
    createdAt: options.createdAt ?? now,
    updatedAt: now,
    providers: ['btcmap'],
  };
}

export function buildSavedPlaceItemProjections(list, itemEvents, options = {}) {
  return list.places.map((place, index) => {
    const event = itemEvents[index];
    if (!event) {
      throw new Error(`Missing saved-place item event for ${place.key}`);
    }
    return buildSavedPlaceProjection({
      listId: list.id,
      placeKey: place.key,
      lat: place.lat,
      lng: place.lng,
      createdAt: event.created_at,
      eventId: event.id,
      authorPubkey: event.pubkey,
      listCoordinate: options.listCoordinate,
      name: place.name,
      type: place.type,
      sourceLayer: place.sourceLayer,
      sourceId: place.sourceId,
    });
  });
}

export function buildSavedPlaceListIndexArtifacts(list, itemEvents, options = {}) {
  const projections = buildSavedPlaceItemProjections(list, itemEvents, {
    listCoordinate: options.listCoordinate,
  });
  const portableIndexMaxItems = Number.isFinite(options.portableIndexMaxItems)
    ? Math.max(0, Math.floor(options.portableIndexMaxItems))
    : Number.POSITIVE_INFINITY;
  const hasPortableJsonIndex = projections.length <= portableIndexMaxItems;
  return {
    itemEvents: options.includeItemEvents === false ? [] : itemEvents,
    itemEventCount: itemEvents.length,
    projections,
    hasPortableJsonIndex,
    index: hasPortableJsonIndex
      ? buildSavedPlaceProjectionIndex(projections)
      : buildSavedPlaceProjectionIndexSummary(projections),
  };
}

function buildSavedPlaceProjectionIndexSummary(projections) {
  return {
    version: 1,
    kind: SAVED_PLACE_INDEX_KIND,
    projectionCount: projections.length,
    projections: {},
    indexes: Object.fromEntries(savedPlaceIndexNames().map((name) => [name, []])),
    omitted: true,
    reason: 'large-list-use-projections-and-derived-indexes',
  };
}

export function writeCrawlerTree(outDir, list, payload, meta, crawlSummary, manifest, indexArtifacts = null) {
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });
  const listDir = path.join(outDir, savedPlaceListDirectoryPath(list.id));
  const itemsDir = path.join(listDir, SAVED_PLACE_LIST_ITEMS_DIR);
  fs.mkdirSync(itemsDir, { recursive: true });
  fs.writeFileSync(path.join(listDir, SAVED_PLACE_LIST_MANIFEST_FILE), `${JSON.stringify(manifest, null, 2)}\n`);
  const pages = buildSavedPlaceListItemPages(list.places, manifest.items.pageSize);
  pages.forEach((page, index) => {
    fs.writeFileSync(path.join(itemsDir, savedPlaceListItemPageFile(index)), `${JSON.stringify(page, null, 2)}\n`);
  });
  if (indexArtifacts) {
    if (indexArtifacts.itemEvents?.length) {
      fs.writeFileSync(
        path.join(listDir, SAVED_PLACE_ITEM_EVENTS_FILE),
        `${indexArtifacts.itemEvents.map((event) => JSON.stringify(event)).join('\n')}\n`,
      );
    }
    fs.writeFileSync(
      path.join(listDir, SAVED_PLACE_PROJECTIONS_FILE),
      `${indexArtifacts.projections.map((projection) => JSON.stringify(projection)).join('\n')}\n`,
    );
    fs.writeFileSync(path.join(listDir, SAVED_PLACE_INDEX_FILE), `${JSON.stringify(indexArtifacts.index, null, 2)}\n`);
  }
  fs.writeFileSync(path.join(outDir, 'maps.json'), `${JSON.stringify(payload, null, 2)}\n`);
  fs.writeFileSync(path.join(outDir, 'meta.json'), `${JSON.stringify(meta, null, 2)}\n`);
  fs.writeFileSync(path.join(outDir, 'btcmap-crawl.json'), `${JSON.stringify(crawlSummary, null, 2)}\n`);
}

export function buildSavedPlaceListFactEvent(list) {
  const facts = compactFacts([
    mapFact('type', ['saved_place_list']),
    mapFact('name', [list.name]),
    mapFact('description', [list.description]),
    mapFact('avatar_url', [list.avatarUrl]),
    mapFact('visibility', [list.visibility]),
    mapFact('place_count', [list.places.length]),
    mapFact('web_url', [list.urls?.web]),
    mapFact('htree_url', [list.urls?.htree]),
    mapFact('data_url', [list.urls?.data]),
    mapFact('htree_data_url', [list.urls?.htreeData]),
    mapFact('source', ['iris-maps']),
    mapFact('source_id', [`iris-maps:saved-place-list:${list.id}`]),
    mapFact('created_at', [unixSeconds(list.createdAt)]),
    mapFact('updated_at', [unixSeconds(list.updatedAt)]),
  ]);

  return buildFactEventRecord(list.id, facts, {
    externalIdentifiers: [
      `iris-maps:saved-place-list:${list.id}`,
      ...list.places.map((place) => savedPlaceExternalIdentifier(place.key)),
    ],
  });
}

function mapFact(predicate, values) {
  const normalizedValues = values
    .map((value) => value === undefined || value === null ? '' : String(value).trim())
    .filter(Boolean);
  if (normalizedValues.length === 0) return null;
  return {
    predicate,
    values: normalizedValues,
  };
}

function buildFactEventRecord(subject, facts, indexes = {}) {
  const normalizedSubject = normalizeUuid(subject);
  const normalizedFacts = normalizeFacts(facts);
  const externalIdentifiers = normalizeExternalIdentifiers(indexes.externalIdentifiers ?? []);
  const tags = [['i', normalizedSubject, subjectMarker]];
  tags.push(...indexTags(normalizedSubject, normalizedFacts, externalIdentifiers));
  tags.push(...normalizedFacts.map((fact) => [fact.predicate, ...fact.values]));
  return {
    kind: FACT_OP_KIND,
    content: '',
    subject: normalizedSubject,
    tags,
  };
}

function compactFacts(facts) {
  return facts.filter(Boolean);
}

function normalizeFacts(facts) {
  const seen = new Set();
  return facts
    .map((fact) => {
      const predicate = normalizePredicate(fact.predicate);
      if (reservedTags.has(predicate)) throw new Error(`${predicate} is a reserved fact event tag`);
      return {
        predicate,
        values: fact.values.map(normalizeValue),
      };
    })
    .sort(compareFacts)
    .filter((fact) => {
      const key = `${fact.predicate}\0${JSON.stringify(fact.values)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizePredicate(value) {
  const trimmed = value.trim();
  if (!trimmed) throw new Error('fact predicate cannot be empty');
  if ([...trimmed].length < 2) throw new Error(`fact predicate must be at least two characters: ${trimmed}`);
  if (/\s/.test(trimmed)) throw new Error(`fact predicate cannot contain whitespace: ${trimmed}`);
  return trimmed;
}

function normalizeValue(value) {
  const trimmed = value.trim();
  if (isUuid(trimmed)) return normalizeUuid(trimmed);
  if (isPubkey(trimmed)) return trimmed.toLowerCase();
  return trimmed;
}

function normalizeUuid(value) {
  const trimmed = value.trim();
  const lower = trimmed.toLowerCase();
  if (!uuidPattern.test(lower) || trimmed !== lower) {
    throw new Error(`UUID must be canonical lowercase hyphenated text: ${value}`);
  }
  return lower;
}

function normalizeExternalIdentifiers(values) {
  return new Set(values.map((value) => {
    const trimmed = value.trim();
    if (!trimmed) throw new Error('external fact identifier cannot be empty');
    if (isUuid(trimmed)) return normalizeUuid(trimmed);
    if (/\s/.test(trimmed)) throw new Error(`external fact identifier cannot contain whitespace: ${trimmed}`);
    return trimmed.toLowerCase();
  }).sort());
}

function indexTags(subject, facts, externalIdentifiers) {
  const uuids = new Set();
  const pubkeys = new Set();
  for (const fact of facts) {
    for (const value of fact.values) {
      if (isUuid(value) && value !== subject) uuids.add(value);
      else if (isPubkey(value)) pubkeys.add(value);
    }
  }
  for (const identifier of externalIdentifiers) {
    if (isUuid(identifier) && identifier !== subject) uuids.add(identifier);
  }
  return [
    ...[...uuids].sort().map((uuid) => ['i', uuid]),
    ...[...externalIdentifiers]
      .filter((identifier) => !isUuid(identifier))
      .sort()
      .map((identifier) => ['i', identifier]),
    ...[...pubkeys].sort().map((pubkey) => ['p', pubkey]),
  ];
}

function compareFacts(left, right) {
  return left.predicate.localeCompare(right.predicate)
    || JSON.stringify(left.values).localeCompare(JSON.stringify(right.values));
}

function formatCoordinate(value) {
  return String(Math.round(value * 1_000_000) / 1_000_000);
}

function unixSeconds(timestampMs) {
  return String(Math.floor(timestampMs / 1000));
}

function savedPlaceExternalIdentifier(key) {
  return `iris-maps:saved-place:${encodeURIComponent(key)}`;
}

function isUuid(value) {
  return uuidPattern.test(value);
}

function isPubkey(value) {
  return hex64Pattern.test(value.toLowerCase());
}

function decodeNsec(nsec) {
  const decoded = nip19.decode(nsec.trim());
  if (decoded.type !== 'nsec' || !(decoded.data instanceof Uint8Array)) {
    throw new Error('Expected an nsec secret key');
  }
  return decoded.data;
}

export function npubFromNsec(nsec) {
  return nip19.npubEncode(getPublicKey(decodeNsec(nsec)));
}

export function pubkeyFromNsec(nsec) {
  return getPublicKey(decodeNsec(nsec));
}

export function readOrCreateCrawlerNsec(keyFile) {
  try {
    const nsec = fs.readFileSync(keyFile, 'utf8').trim();
    decodeNsec(nsec);
    try {
      fs.chmodSync(keyFile, 0o600);
    } catch {
      // Best effort.
    }
    return { nsec, created: false };
  } catch (error) {
    if (error && error.code !== 'ENOENT') {
      throw error;
    }
  }
  const nsec = nip19.nsecEncode(generateSecretKey());
  fs.mkdirSync(path.dirname(keyFile), { recursive: true, mode: 0o700 });
  fs.writeFileSync(keyFile, `${nsec}\n`, { mode: 0o600 });
  return { nsec, created: true };
}

export function signSavedPlaceItemEvents(list, nsec, options = {}) {
  const secretKey = decodeNsec(nsec);
  const createdAt = options.createdAt ?? Math.floor(Date.now() / 1000);
  return list.places.map((place) => finalizeEvent({
    ...buildSavedPlaceMembershipEventTemplate({
      listId: list.id,
      placeKey: place.key,
      lat: place.lat,
      lng: place.lng,
      createdAt,
      listCoordinate: options.listCoordinate,
      sourceLayer: place.sourceLayer,
      sourceId: place.sourceId,
    }),
  }, secretKey));
}

export async function signAndPublishFactEvent(record, nsec, options = {}) {
  const secretKey = decodeNsec(nsec);
  const event = finalizeEvent({
    kind: record.kind,
    content: record.content,
    tags: record.tags,
    created_at: options.createdAt ?? Math.floor(Date.now() / 1000),
  }, secretKey);

  const signedRecord = {
    ...record,
    eventId: event.id,
    authorPubkey: event.pubkey,
    publishedAt: event.created_at,
  };

  if (options.dryRun || options.skipPublish) {
    return {
      record: signedRecord,
      event,
      publish: {
        attempted: false,
        accepted: 0,
        failures: [],
      },
    };
  }

  const relays = options.relays?.length ? options.relays : DEFAULT_RELAYS;
  const timeoutMs = options.timeoutMs ?? 7_500;
  const publish = await publishSignedEvent(event, relays, timeoutMs);
  if (publish.accepted === 0) {
    signedRecord.publishError = `No relay accepted the kind-${record.kind} saved-place-list index event`;
  }
  return {
    record: signedRecord,
    event,
    publish,
  };
}

export async function publishSignedItemEvents(events, options = {}) {
  if (options.dryRun || options.skipPublish || events.length === 0) {
    return {
      attempted: false,
      eventCount: events.length,
      acceptedEvents: 0,
      relayAccepts: 0,
      failures: [],
    };
  }
  return publishSignedEvents(events, options.relays?.length ? options.relays : DEFAULT_RELAYS, options.timeoutMs ?? 7_500);
}

async function publishSignedEvent(event, relays, timeoutMs) {
  const pool = new SimplePool();
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), timeoutMs);
  try {
    const settled = await Promise.allSettled(pool.publish(relays, event, {
      maxWait: timeoutMs,
      abort: abort.signal,
    }));
    const failures = [];
    let accepted = 0;
    settled.forEach((result, index) => {
      const relay = relays[index];
      if (result.status === 'fulfilled' && !String(result.value).startsWith('connection failure:')) {
        accepted += 1;
      } else {
        failures.push({
          relay,
          error: result.status === 'fulfilled' ? String(result.value) : String(result.reason),
        });
      }
    });
    return {
      attempted: true,
      accepted,
      failures,
    };
  } finally {
    clearTimeout(timer);
    pool.destroy();
  }
}

async function publishSignedEvents(events, relays, timeoutMs) {
  const pool = new SimplePool();
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), timeoutMs);
  try {
    const results = await Promise.all(events.map(async (event) => {
      const settled = await Promise.allSettled(pool.publish(relays, event, {
        maxWait: timeoutMs,
        abort: abort.signal,
      }));
      const failures = [];
      let accepted = 0;
      settled.forEach((result, index) => {
        const relay = relays[index];
        if (result.status === 'fulfilled' && !String(result.value).startsWith('connection failure:')) {
          accepted += 1;
        } else {
          failures.push({
            relay,
            eventId: event.id,
            error: result.status === 'fulfilled' ? String(result.value) : String(result.reason),
          });
        }
      });
      return {
        eventId: event.id,
        accepted,
        failures,
      };
    }));
    return {
      attempted: true,
      eventCount: events.length,
      acceptedEvents: results.filter((result) => result.accepted > 0).length,
      relayAccepts: results.reduce((sum, result) => sum + result.accepted, 0),
      failures: results.flatMap((result) => result.failures),
    };
  } finally {
    clearTimeout(timer);
    pool.destroy();
  }
}

export function prepareHtreeConfig(configDir, nsec) {
  fs.mkdirSync(configDir, { recursive: true, mode: 0o700 });
  const keysPath = path.join(configDir, 'keys');
  fs.writeFileSync(keysPath, `${nsec} btcmap-crawler\n`, { mode: 0o600 });
  try {
    fs.chmodSync(keysPath, 0o600);
  } catch {
    // Best effort.
  }
}

export function createHtreeCommand(options) {
  const args = ['--data-dir', options.htreeDataDir, 'add', '.'];
  if (options.htreeLocal) args.push('--local');
  if (options.htreeBin) return [options.htreeBin, ...args];
  return resolveHtreeCommand(...args);
}

export function runHtreeAdd(options) {
  prepareHtreeConfig(options.htreeConfigDir, options.nsec);
  fs.mkdirSync(options.htreeDataDir, { recursive: true, mode: 0o700 });
  const [command, ...args] = createHtreeCommand(options);
  const result = spawnSync(command, args, {
    cwd: options.treeDir,
    env: {
      ...process.env,
      HTREE_CONFIG_DIR: options.htreeConfigDir,
      HTREE_DATA_DIR: options.htreeDataDir,
    },
    encoding: 'utf8',
    stdio: 'pipe',
    maxBuffer: 20 * 1024 * 1024,
  });
  const output = `${result.stdout ?? ''}\n${result.stderr ?? ''}`;
  if (result.status !== 0) {
    throw new Error(`htree add failed with exit code ${result.status ?? 1}\n${output.trim()}`);
  }
  const add = parseHtreeAddOutput(output);
  if (!add.hash) {
    throw new Error(`htree add did not report a root hash\n${output.trim()}`);
  }
  return {
    status: result.status,
    stdout: result.stdout ?? '',
    stderr: result.stderr ?? '',
    output,
    add,
  };
}

export function parseHtreeAddOutput(output) {
  const key = matchLine(output, /^[ \t]*key:([^\r\n]*)/mi)?.trim();
  if (key !== undefined) objectKeyFromHex(key);
  return {
    immutableUrl: matchLine(output, /^\s*url:\s+(\S+)/m),
    driveUrl: matchLine(output, /^\s*drive:\s+(\S+)/m),
    hash: matchLine(output, /^[ \t]*hash:[ \t]+([0-9a-f]{64})[ \t]*$/mi),
    key,
    publishedRef: matchLine(output, /^\s*published:\s+(\S+)/m),
  };
}

export function buildHashtreeRootEventTemplate(options) {
  const labels = ['hashtree', ...(options.labels ?? [])]
    .map((label) => label.trim())
    .filter(Boolean);
  const uniqueLabels = [...new Set(labels)];
  const tags = [
    ['d', options.treeName],
    ...uniqueLabels.map((label) => ['l', label]),
    ['hash', options.hash],
  ];
  if (options.key) {
    tags.push(['key', options.key]);
  }
  return {
    kind: HASHTREE_ROOT_KIND,
    content: '',
    tags,
    created_at: options.createdAt ?? Math.floor(Date.now() / 1000),
  };
}

export async function signAndPublishHashtreeRootEvent(options) {
  const event = finalizeEvent(buildHashtreeRootEventTemplate(options), decodeNsec(options.nsec));
  if (options.dryRun || options.skipPublish) {
    return {
      event,
      publish: {
        attempted: false,
        accepted: 0,
        failures: [],
      },
    };
  }
  const relays = options.relays?.length ? options.relays : DEFAULT_RELAYS;
  return {
    event,
    publish: await publishSignedEvent(event, relays, options.timeoutMs ?? 7_500),
  };
}

function matchLine(output, pattern) {
  const match = output.match(pattern);
  return match ? match[1] : undefined;
}

export async function runCrawler(options) {
  const startedAt = Date.now();
  const sourceUrl = options.fromCache
    ? BTCMAP_SITE_URL
    : createBtcMapPlacesUrl({
        ...options,
        limit: options.all ? options.pageLimit : options.limit,
        updatedSince: options.all ? '1970-01-01T00:00:00Z' : undefined,
        includeDeleted: options.all,
      }).toString();
  const identity = readOrCreateCrawlerNsec(options.keyFile);
  const crawlerNpub = npubFromNsec(identity.nsec);
  const crawlerPubkey = pubkeyFromNsec(identity.nsec);
  const listCoordinate = `${HASHTREE_ROOT_KIND}:${crawlerPubkey}:${options.treeName}`;
  const state = loadCrawlerState(options.stateFile, options.resetList, startedAt);
  saveCrawlerState(options.stateFile, state);

  const rawPlaces = await fetchBtcMapPlaces(options);
  const list = buildBtcMapSavedPlaceList(rawPlaces, state, {
    listName: options.listName,
    visibility: options.visibility,
    now: startedAt,
  });
  if (list.visibility === 'public') {
    list.urls = buildSavedPlaceListUrls({
      listId: list.id,
      ownerNpub: crawlerNpub,
      treeName: options.treeName,
    });
    list.factEvent = buildSavedPlaceListFactEvent(list);
  }

  const itemEvents = list.visibility === 'public'
    ? signSavedPlaceItemEvents(list, identity.nsec, {
        createdAt: Math.floor(startedAt / 1000),
        listCoordinate,
      })
    : [];
  const includeItemEventsInTree = itemEvents.length > 0 && itemEvents.length <= options.treeItemEventMaxItems;
  const indexArtifacts = buildSavedPlaceListIndexArtifacts(list, itemEvents, {
    listCoordinate,
    includeItemEvents: includeItemEventsInTree,
    portableIndexMaxItems: options.portableIndexMaxItems,
  });
  const dynamicWorldSampleSize = list.places.length > options.sampleThreshold
    ? Math.min(list.places.length, options.sampleSize)
    : 0;

  let factPublish = null;
  if (list.factEvent) {
    factPublish = await signAndPublishFactEvent(list.factEvent, identity.nsec, {
      dryRun: options.dryRun,
      skipPublish: options.skipFactPublish,
      relays: options.relays,
      timeoutMs: options.publishTimeoutMs,
      createdAt: Math.floor(startedAt / 1000),
    });
    list.factEvent = factPublish.record;
  }

  const itemPublish = await publishSignedItemEvents(itemEvents, {
    dryRun: options.dryRun,
    skipPublish: options.skipItemPublish,
    relays: options.relays,
    timeoutMs: options.publishTimeoutMs,
  });

  const meta = buildMapsMeta({ createdAt: state.createdAt, now: startedAt });
  const payload = buildMapsPayload(list);
  const crawlSummary = {
    version: 1,
    provider: 'btcmap',
    sourceUrl,
    fetchedAt: new Date(startedAt).toISOString(),
    requestedLimit: options.limit,
    all: options.all,
    pageLimit: options.pageLimit,
    fetchedCount: rawPlaces.length,
    savedCount: list.places.length,
    deletedCount: rawPlaces.filter((place) => normalizeText(place?.deleted_at)).length,
    dynamicWorldSampleSize,
    sampleThreshold: options.sampleThreshold,
    crawlerNpub,
    listId: list.id,
    listName: list.name,
    visibility: list.visibility,
    membershipKind: SAVED_PLACE_MEMBERSHIP_KIND,
    listCoordinate,
    itemEventCount: itemEvents.length,
    itemEventsBundledInTree: includeItemEventsInTree ? itemEvents.length : 0,
    itemEventsAccepted: itemPublish.acceptedEvents,
    portableJsonIndex: indexArtifacts.hasPortableJsonIndex,
    factEventId: list.factEvent?.eventId,
  };
  const manifest = buildSavedPlaceListManifest(list, {
    index: indexArtifacts.index,
    source: {
      provider: 'btcmap',
      url: BTCMAP_SITE_URL,
      apiUrl: sourceUrl,
      fetchedAt: new Date(startedAt).toISOString(),
      requestedLimit: options.all ? undefined : options.limit,
      pageLimit: options.all ? options.pageLimit : undefined,
      fetchedCount: rawPlaces.length,
    },
    sampleSize: options.sampleSize,
    sampleThreshold: options.sampleThreshold,
    includeItemEvents: includeItemEventsInTree,
  });
  writeCrawlerTree(options.outDir, list, payload, meta, crawlSummary, manifest, indexArtifacts);

  let htreeAdd = null;
  let rootPublish = null;
  if (!options.dryRun && !options.skipPublish) {
    htreeAdd = runHtreeAdd({
      treeDir: options.outDir,
      htreeBin: options.htreeBin,
      htreeConfigDir: options.htreeConfigDir,
      htreeDataDir: options.htreeDataDir,
      nsec: identity.nsec,
    });
    if (!options.skipRootPublish) {
      const rootCreatedAt = Math.max(
        Math.floor(startedAt / 1000),
        typeof state.rootEventCreatedAt === 'number' ? state.rootEventCreatedAt + 1 : 0,
      );
      rootPublish = await signAndPublishHashtreeRootEvent({
        treeName: options.treeName,
        hash: htreeAdd.add.hash,
        key: htreeAdd.add.key,
        labels: [IRIS_MAPS_LABEL, SAVED_PLACE_LIST_LABEL],
        nsec: identity.nsec,
        relays: options.relays,
        timeoutMs: options.publishTimeoutMs,
        createdAt: rootCreatedAt,
      });
      state.rootEventCreatedAt = rootPublish.event.created_at;
      saveCrawlerState(options.stateFile, state);
      if (rootPublish.publish.accepted === 0) {
        throw new Error(`No relay accepted the labeled kind-${HASHTREE_ROOT_KIND} root event for ${crawlerNpub}/${options.treeName}`);
      }
    }
  }

  return {
    sourceUrl,
    keyCreated: identity.created,
    crawlerNpub,
    state,
    list,
    payload,
    meta,
    manifest,
    crawlSummary,
    itemEvents,
    indexArtifacts,
    itemPublish,
    factPublish,
    htreeAdd,
    rootPublish,
    outDir: options.outDir,
  };
}

function printSummary(result, options) {
  console.log('BTC Map crawl complete');
  console.log(`  crawler: ${result.crawlerNpub}${result.keyCreated ? ' (new)' : ''}`);
  console.log(`  source:  ${result.sourceUrl}`);
  console.log(`  list:    ${result.list.name} (${result.list.id})`);
  console.log(`  places:  ${result.crawlSummary.savedCount}/${result.crawlSummary.fetchedCount}`);
  if (result.crawlSummary.dynamicWorldSampleSize) {
    console.log(`  sample:  up to ${result.crawlSummary.dynamicWorldSampleSize} dynamic world points in-browser`);
  }
  if (!result.crawlSummary.portableJsonIndex) {
    console.log('  index:   portable JSON index omitted for large list');
  }
  console.log(`  output:  ${result.outDir}`);
  if (result.itemPublish) {
    const publish = result.itemPublish;
    const suffix = publish.attempted
      ? `${publish.acceptedEvents}/${publish.eventCount} event${publish.eventCount === 1 ? '' : 's'} accepted`
      : 'not published';
    console.log(`  items:   kind-${SAVED_PLACE_MEMBERSHIP_KIND} (${suffix})`);
  }
  if (result.factPublish) {
    const publish = result.factPublish.publish;
    const suffix = publish.attempted
      ? `${publish.accepted} relay${publish.accepted === 1 ? '' : 's'} accepted`
      : 'not published';
    console.log(`  event:   ${result.factPublish.event.id} (${suffix})`);
  }
  if (result.htreeAdd) {
    console.log(`  root:    ${result.crawlerNpub}/${options.treeName}`);
    if (result.htreeAdd.add.immutableUrl) {
      console.log(`  url:     htree://${result.htreeAdd.add.immutableUrl}/${savedPlaceListDirectoryPath(result.list.id)}/${SAVED_PLACE_LIST_MANIFEST_FILE}`);
    }
    if (result.rootPublish) {
      console.log(`  labels:  hashtree, ${IRIS_MAPS_LABEL}, ${SAVED_PLACE_LIST_LABEL}`);
      console.log(`  root event: ${result.rootPublish.event.id} (${result.rootPublish.publish.accepted} relay${result.rootPublish.publish.accepted === 1 ? '' : 's'} accepted)`);
    } else {
      console.log('  root event: skipped');
    }
  } else if (options.dryRun) {
    console.log('  publish: dry run');
  } else if (options.skipPublish) {
    console.log('  publish: skipped');
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  try {
    const options = parseArgs(process.argv.slice(2));
    if (options.help) {
      printHelp();
      process.exit(0);
    }
    const result = await runCrawler(options);
    printSummary(result, options);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
