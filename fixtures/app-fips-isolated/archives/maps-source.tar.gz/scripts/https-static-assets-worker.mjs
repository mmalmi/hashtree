const HTREE_PROXY_ORIGIN = 'https://cdn.iris.to';

function forwardedScheme(request) {
  const forwardedProto = request.headers.get('x-forwarded-proto');
  if (forwardedProto) return forwardedProto.toLowerCase();

  const visitor = request.headers.get('cf-visitor');
  if (!visitor) return '';
  try {
    const parsed = JSON.parse(visitor);
    return typeof parsed.scheme === 'string' ? parsed.scheme.toLowerCase() : '';
  } catch {
    return '';
  }
}

function shouldRedirectToHttps(request, url) {
  const scheme = forwardedScheme(request);
  if (request.cf && !request.cf.tlsVersion) {
    return true;
  }
  return scheme === 'http' || (!scheme && url.protocol === 'http:');
}

function shouldProxyHtree(url) {
  return url.pathname === '/htree' || url.pathname.startsWith('/htree/');
}

function proxyHtreeRequest(request, url) {
  const upstreamUrl = new URL(request.url);
  upstreamUrl.protocol = 'https:';
  upstreamUrl.host = new URL(HTREE_PROXY_ORIGIN).host;
  upstreamUrl.port = '';
  upstreamUrl.pathname = url.pathname.slice('/htree'.length) || '/';

  const headers = new Headers(request.headers);
  headers.delete('cookie');
  headers.delete('host');

  return fetch(new Request(upstreamUrl.toString(), {
    method: request.method,
    headers,
    body: request.method === 'GET' || request.method === 'HEAD' ? undefined : request.body,
    redirect: 'manual',
  }));
}

export default {
  fetch(request, env) {
    const url = new URL(request.url);
    if (shouldRedirectToHttps(request, url)) {
      url.protocol = 'https:';
      url.port = '';
      return Response.redirect(url.toString(), 308);
    }

    if (shouldProxyHtree(url)) {
      return proxyHtreeRequest(request, url);
    }

    return env.ASSETS.fetch(request);
  },
};
