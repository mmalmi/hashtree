#!/usr/bin/env node
import { execFile } from 'node:child_process';
import crypto from 'node:crypto';
import { deserializeCid, FileBlockStore, verifiedBlockStore } from './map-search-block-store.mjs';
import { createReadStream } from 'node:fs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { PMTiles, ResolvedValueCache, tileIdToZxy } from 'pmtiles';
import { VectorTile } from '@mapbox/vector-tile';
import Protobuf from 'pbf';
import { finalizeEvent } from 'nostr-tools/pure';
import { loadUploadKey } from './map-search-upload-key.mjs';
import { SearchIndex, escapeKey } from '@hashtree/index';
import { BlossomStore, HashTree, LinkType, nhashEncode, toHex } from '@hashtree/core';

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const MAP_BASEMAP_OWNER_NPUB = 'npub1t5t66e523nppvsz2sj8yzp3dvg598x2cswsecaj0029ea5xh4gcq2c0n4h';
const MAP_BASEMAP_TREE = 'maps-openfreemap-world-z14-v1';
const DEFAULT_LOCAL_HASHTREE_BASE_URL = 'http://127.0.0.1:18080';
const DEFAULT_PMTILES_URL = `${DEFAULT_LOCAL_HASHTREE_BASE_URL}/${MAP_BASEMAP_OWNER_NPUB}/${MAP_BASEMAP_TREE}/tiles.pmtiles`;
const DEFAULT_OUT_DIR = path.join(os.tmpdir(), `iris-maps-openfreemap-search-${Date.now()}`);
const DEFAULT_PUBLISH_REF = 'maps-search-openfreemap-world-z13-v1';
const DEFAULT_SOURCE_ZOOMS = [0, 4, 8, 10, 13];
const DEFAULT_ADDRESS_ZOOM = 14;
const DEFAULT_ADDRESS_JOIN_RADIUS_METERS = 45;
const DEFAULT_LAYERS = [
  'aerodrome_label',
  'boundary',
  'mountain_peak',
  'park',
  'place',
  'poi',
  'transportation_name',
  'water_name',
  'waterway',
];
const SEARCH_PREFIX = 'p:';
const PLACE_NAMES_PREFIX = 'n:';
const ADMINISTRATIVE_TYPES = new Set(['continent', 'country', 'state', 'province', 'region', 'county', 'district']);
const SETTLEMENT_TYPES = new Set(['city', 'town', 'village', 'hamlet', 'municipality', 'borough', 'suburb', 'quarter', 'neighbourhood']);
const SEARCH_INDEX_VERSION = 2;
const ADDRESS_STREET_LAYER = 'transportation_name';
const ADDRESS_NUMBER_LAYER = 'housenumber';
const TEXT_ENCODER = new TextEncoder();
const TEXT_DECODER = new TextDecoder();
const BLOSSOM_AUTH_KIND = 24242;
const BATCH_UPLOAD_BINARY_CONTENT_TYPE = 'application/vnd.hashtree.blossom.batch.v1';
const BATCH_UPLOAD_HASH_LIST_AUTH_TAG = 'x-batch';
const BINARY_BATCH_UPLOAD_MAGIC = Buffer.from('HTBBV1\0\0', 'binary');
const BATCH_UPLOAD_DIGEST_PREFIX = 'hashtree-blossom-batch-v1\n';
const BATCH_UPLOAD_MAX_BLOBS = 1024;
const BATCH_UPLOAD_MAX_BYTES = 64 * 1024 * 1024;

const LAYER_WEIGHTS = {
  place: 100,
  boundary: 92,
  transportation_name: 72,
  aerodrome_label: 70,
  poi: 56,
  park: 50,
  water_name: 44,
  waterway: 38,
  mountain_peak: 34,
};

function usage() {
  return `Usage: node ./scripts/publish-openfreemap-search-index.mjs [options]

Build a hashtree-index place/street/POI search dataset from the OpenFreeMap
PMTiles archive used by Iris Maps.

Defaults use an SSH tunnel to Vader's local hashtree gateway:
  ssh -N -L 18080:127.0.0.1:8080 vader

Options:
  --pmtiles-url <url>          PMTiles URL (default: ${DEFAULT_PMTILES_URL})
  --out <dir>                  Output metadata directory (default: ${DEFAULT_OUT_DIR})
  --block-store <dir>          Disk store for generated hashtree blocks (default: <out>/blocks)
  --run-dir <dir>              Disk work dir for sorted runs (default: <out>/runs)
  --build-from-record-runs     Skip PMTiles extraction and read existing sorted record runs
  --record-run-dir <dir>       Existing sorted record runs (default: <run-dir>/records)
  --source-manifest <file>     Original root.json when rebuilding exported records
  --context-source <file>      Boundary enrichment metadata for these record runs
  --publish-ref <name>         Mutable hashtree ref (default: ${DEFAULT_PUBLISH_REF})
  --zooms <list>               Comma-separated source zooms (default: ${DEFAULT_SOURCE_ZOOMS.join(',')})
  --max-zoom <n>               Process every source zoom 0..n instead of --zooms
  --layers <list>              Comma-separated vector layers (default: named OpenMapTiles layers)
  --bounds <s,w,n,e>           Optional geographic bounds filter
  --tile-concurrency <n>       Concurrent tile reads/decodes (default: 16)
  --push-concurrency <n>       Concurrent block uploads (default: 64)
  --tile-retries <n>           Retry failed tile reads/decodes before counting an error (default: 4)
  --retry-delay-ms <n>         Base delay between tile retries (default: 250)
  --max-tile-errors <n>        Fail if final tile errors exceed this count (default: 0)
  --record-run-size <n>        Deduped record candidates per sorted run (default: 250000)
  --index-run-size <n>         Index entries per sorted run (default: 250000)
  --record-shard-size <n>      App records per hashtree shard block (default: 512)
  --address-sidecars           Build per-street z14 housenumber sidecars
  --no-address-sidecars        Disable address sidecars even when MAP_SEARCH_ADDRESS_SIDECARS=1
  --address-run-dir <dir>      Existing/generated address runs (default: <run-dir>/addresses)
  --address-zoom <n>           Source zoom for housenumber sidecars (default: ${DEFAULT_ADDRESS_ZOOM})
  --address-join-radius-meters <n>
                               Max housenumber-to-street join distance (default: ${DEFAULT_ADDRESS_JOIN_RADIUS_METERS})
  --road-bucket-zoom <n>       Road dedupe bucket zoom (default: 12)
  --feature-bucket-zoom <n>    Fallback feature dedupe bucket zoom (default: 13)
  --max-records <n>            Stop extraction after this many deduped records
  --max-tiles <n>              Stop extraction after this many selected tiles
  --progress-tiles <n>         Tile progress interval (default: 10000)
  --verify-query <query>       Query to verify; can repeat (default: Helsinki, Tokyo, New York)
  --skip-publish               Build only; do not upload or htree publish
  --skip-ref-publish           Upload blocks but do not update the mutable htree ref
  --blossom-servers <urls>     Read/write Blossom servers (default: ${DEFAULT_LOCAL_HASHTREE_BASE_URL})
  --blossom-write-servers <u>  Write-only Blossom servers (default: ${DEFAULT_LOCAL_HASHTREE_BASE_URL})
  --upload-key-file <path>    Trusted storage identity (default: configured Hashtree keys file)
  --check-existing             HEAD/has preflight before block upload
  --no-batch-upload            Use legacy single-block Blossom PUT uploads
  --batch-concurrency <n>      Concurrent batch upload requests (default: 4)
  --batch-max-blobs <n>        Max blobs per batch, <= 1024 (default: 1024)
  --batch-max-bytes <n>        Max data bytes per batch, <= 64MiB (default: 50331648)
  --batch-timeout-ms <n>       Per-batch upload timeout (default: 300000)
  --batch-retries <n>          Batch upload retry attempts (default: 6)
  -h, --help                   Show this help
`;
}

function parseArgs(argv) {
  const options = {
    pmtilesUrl: process.env.MAP_SEARCH_PMTILES_URL ?? DEFAULT_PMTILES_URL,
    out: DEFAULT_OUT_DIR,
    blockStore: '',
    runDir: '',
    buildFromRecordRuns: false,
    recordRunDir: '',
    publishRef: DEFAULT_PUBLISH_REF,
    sourceZooms: [...DEFAULT_SOURCE_ZOOMS],
    layers: [...DEFAULT_LAYERS],
    bounds: null,
    tileConcurrency: positiveInt(process.env.MAP_SEARCH_TILE_CONCURRENCY, 16),
    pushConcurrency: positiveInt(process.env.PUSH_CONCURRENCY, 64),
    tileRetries: positiveInt(process.env.MAP_SEARCH_TILE_RETRIES, 4),
    retryDelayMs: positiveInt(process.env.MAP_SEARCH_RETRY_DELAY_MS, 250),
    maxTileErrors: positiveInt(process.env.MAP_SEARCH_MAX_TILE_ERRORS, 0),
    recordRunSize: positiveInt(process.env.MAP_SEARCH_RECORD_RUN_SIZE, 250000),
    indexRunSize: positiveInt(process.env.MAP_SEARCH_INDEX_RUN_SIZE, 250000),
    recordShardSize: positiveInt(process.env.MAP_SEARCH_RECORD_SHARD_SIZE, 512),
    addressSidecars: process.env.MAP_SEARCH_ADDRESS_SIDECARS === '1',
    addressRunDir: '',
    addressZoom: positiveInt(process.env.MAP_SEARCH_ADDRESS_ZOOM, DEFAULT_ADDRESS_ZOOM),
    addressJoinRadiusMeters: positiveInt(process.env.MAP_SEARCH_ADDRESS_JOIN_RADIUS_METERS, DEFAULT_ADDRESS_JOIN_RADIUS_METERS),
    roadBucketZoom: positiveInt(process.env.MAP_SEARCH_ROAD_BUCKET_ZOOM, 12),
    featureBucketZoom: positiveInt(process.env.MAP_SEARCH_FEATURE_BUCKET_ZOOM, 13),
    maxRecords: 0,
    maxTiles: 0,
    progressTiles: positiveInt(process.env.MAP_SEARCH_PROGRESS_TILES, 10000),
    verifyQueries: argv.includes('--verify-query') ? [] : ['Helsinki', 'Tokyo', 'New York'],
    skipPublish: false,
    skipRefPublish: false,
    blossomServers: process.env.BLOSSOM_SERVERS ?? DEFAULT_LOCAL_HASHTREE_BASE_URL,
    blossomWriteServers: process.env.BLOSSOM_WRITE_SERVERS ?? DEFAULT_LOCAL_HASHTREE_BASE_URL,
    checkExisting: false,
    batchUpload: process.env.MAP_SEARCH_BATCH_UPLOAD !== '0',
    batchConcurrency: positiveInt(process.env.MAP_SEARCH_BATCH_CONCURRENCY, 4),
    batchMaxBlobs: positiveInt(process.env.MAP_SEARCH_BATCH_MAX_BLOBS, BATCH_UPLOAD_MAX_BLOBS),
    batchMaxBytes: positiveInt(process.env.MAP_SEARCH_BATCH_MAX_BYTES, 48 * 1024 * 1024),
    batchTimeoutMs: positiveInt(process.env.MAP_SEARCH_BATCH_TIMEOUT_MS, 300000),
    batchRetries: positiveInt(process.env.MAP_SEARCH_BATCH_RETRIES, 6),
    help: false,
  };

  const args = [...argv];
  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '--') {
      continue;
    } else if (arg === '-h' || arg === '--help') {
      options.help = true;
    } else if (arg === '--pmtiles-url') {
      options.pmtilesUrl = args.shift() ?? '';
    } else if (arg === '--out') {
      options.out = args.shift() ?? '';
    } else if (arg === '--block-store') {
      options.blockStore = args.shift() ?? '';
    } else if (arg === '--run-dir') {
      options.runDir = args.shift() ?? '';
    } else if (arg === '--build-from-record-runs') {
      options.buildFromRecordRuns = true;
    } else if (arg === '--record-run-dir') {
      options.recordRunDir = args.shift() ?? '';
    } else if (arg === '--source-manifest') {
      options.sourceManifest = args.shift() ?? '';
    } else if (arg === '--context-source') {
      options.contextSource = args.shift() ?? '';
    } else if (arg === '--publish-ref') {
      options.publishRef = args.shift() ?? '';
    } else if (arg === '--zooms') {
      options.sourceZooms = parseIntegerList(args.shift() ?? '');
    } else if (arg === '--max-zoom') {
      const maxZoom = positiveInt(args.shift(), -1);
      if (maxZoom < 0) throw new Error('--max-zoom requires a non-negative integer');
      options.sourceZooms = Array.from({ length: maxZoom + 1 }, (_, zoom) => zoom);
    } else if (arg === '--layers') {
      options.layers = parseStringList(args.shift() ?? '');
    } else if (arg === '--bounds' || arg === '--bbox') {
      options.bounds = parseBounds(args.shift() ?? '');
    } else if (arg === '--tile-concurrency') {
      options.tileConcurrency = positiveInt(args.shift(), options.tileConcurrency);
    } else if (arg === '--push-concurrency') {
      options.pushConcurrency = positiveInt(args.shift(), options.pushConcurrency);
    } else if (arg === '--tile-retries') {
      options.tileRetries = positiveInt(args.shift(), options.tileRetries);
    } else if (arg === '--retry-delay-ms') {
      options.retryDelayMs = positiveInt(args.shift(), options.retryDelayMs);
    } else if (arg === '--max-tile-errors') {
      options.maxTileErrors = positiveInt(args.shift(), options.maxTileErrors);
    } else if (arg === '--record-run-size') {
      options.recordRunSize = positiveInt(args.shift(), options.recordRunSize);
    } else if (arg === '--index-run-size') {
      options.indexRunSize = positiveInt(args.shift(), options.indexRunSize);
    } else if (arg === '--record-shard-size') {
      options.recordShardSize = positiveInt(args.shift(), options.recordShardSize);
    } else if (arg === '--address-sidecars') {
      options.addressSidecars = true;
    } else if (arg === '--no-address-sidecars') {
      options.addressSidecars = false;
    } else if (arg === '--address-run-dir') {
      options.addressRunDir = args.shift() ?? '';
    } else if (arg === '--address-zoom') {
      options.addressZoom = positiveInt(args.shift(), options.addressZoom);
    } else if (arg === '--address-join-radius-meters') {
      options.addressJoinRadiusMeters = positiveInt(args.shift(), options.addressJoinRadiusMeters);
    } else if (arg === '--road-bucket-zoom') {
      options.roadBucketZoom = positiveInt(args.shift(), options.roadBucketZoom);
    } else if (arg === '--feature-bucket-zoom') {
      options.featureBucketZoom = positiveInt(args.shift(), options.featureBucketZoom);
    } else if (arg === '--max-records') {
      options.maxRecords = positiveInt(args.shift(), 0);
    } else if (arg === '--max-tiles') {
      options.maxTiles = positiveInt(args.shift(), 0);
    } else if (arg === '--progress-tiles') {
      options.progressTiles = positiveInt(args.shift(), options.progressTiles);
    } else if (arg === '--verify-query') {
      const query = args.shift() ?? '';
      if (query.trim()) options.verifyQueries.push(query.trim());
    } else if (arg === '--skip-publish') {
      options.skipPublish = true;
    } else if (arg === '--skip-ref-publish') {
      options.skipRefPublish = true;
    } else if (arg === '--blossom-servers') {
      options.blossomServers = args.shift() ?? '';
    } else if (arg === '--blossom-write-servers') {
      options.blossomWriteServers = args.shift() ?? '';
    } else if (arg === '--upload-key-file') {
      options.uploadKeyFile = args.shift() ?? '';
    } else if (arg === '--check-existing') {
      options.checkExisting = true;
    } else if (arg === '--no-batch-upload') {
      options.batchUpload = false;
    } else if (arg === '--batch-concurrency') {
      options.batchConcurrency = positiveInt(args.shift(), options.batchConcurrency);
    } else if (arg === '--batch-max-blobs') {
      options.batchMaxBlobs = positiveInt(args.shift(), options.batchMaxBlobs);
    } else if (arg === '--batch-max-bytes') {
      options.batchMaxBytes = positiveInt(args.shift(), options.batchMaxBytes);
    } else if (arg === '--batch-timeout-ms') {
      options.batchTimeoutMs = positiveInt(args.shift(), options.batchTimeoutMs);
    } else if (arg === '--batch-retries') {
      options.batchRetries = positiveInt(args.shift(), options.batchRetries);
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!options.pmtilesUrl) throw new Error('--pmtiles-url is required');
  if (!options.out) throw new Error('--out is required');
  if (!options.publishRef && !options.skipPublish) throw new Error('--publish-ref is required unless --skip-publish is used');
  if (options.sourceZooms.length === 0) throw new Error('At least one source zoom is required');
  if (options.layers.length === 0) throw new Error('At least one layer is required');
  options.sourceZooms = [...new Set(options.sourceZooms)].sort((a, b) => a - b);
  options.layers = [...new Set(options.layers)];
  options.recordShardSize = Math.max(1, options.recordShardSize);
  options.addressJoinRadiusMeters = Math.max(1, options.addressJoinRadiusMeters);
  options.blockStore = options.blockStore || path.join(path.resolve(options.out), 'blocks');
  options.runDir = options.runDir || path.join(path.resolve(options.out), 'runs');
  options.recordRunDir = options.recordRunDir || path.join(options.runDir, 'records');
  options.addressRunDir = options.addressRunDir || path.join(options.runDir, 'addresses');
  options.batchConcurrency = Math.max(1, options.batchConcurrency);
  options.batchMaxBlobs = Math.max(1, Math.min(BATCH_UPLOAD_MAX_BLOBS, options.batchMaxBlobs));
  options.batchMaxBytes = Math.max(1, Math.min(BATCH_UPLOAD_MAX_BYTES, options.batchMaxBytes));
  return options;
}

function positiveInt(value, fallback) {
  const parsed = Number.parseInt(`${value ?? ''}`, 10);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : fallback;
}

function parseIntegerList(value) {
  return `${value ?? ''}`
    .split(',')
    .map((part) => Number.parseInt(part.trim(), 10))
    .filter((part) => Number.isInteger(part) && part >= 0);
}

function parseStringList(value) {
  return `${value ?? ''}`
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function parseBounds(value) {
  const parts = `${value ?? ''}`.split(',').map((part) => Number(part.trim()));
  if (parts.length !== 4 || parts.some((part) => !Number.isFinite(part))) {
    throw new Error('--bounds must be south,west,north,east');
  }
  const [south, west, north, east] = parts;
  return {
    south: Math.min(south, north),
    west,
    north: Math.max(south, north),
    east,
  };
}

function parseServerList(value) {
  return `${value ?? ''}`
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function normalizeServerUrl(url) {
  try {
    const parsed = new URL(url);
    parsed.hash = '';
    parsed.search = '';
    parsed.pathname = parsed.pathname.replace(/\/+$/, '');
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return `${url ?? ''}`.trim().replace(/\/+$/, '');
  }
}

function parseBlossomServers(readValue, writeValue) {
  const writeUrls = parseServerList(writeValue);
  const writeSet = new Set(writeUrls.map(normalizeServerUrl));
  const readServers = parseServerList(readValue).map((url) => ({
    url: normalizeServerUrl(url),
    read: true,
    write: writeSet.has(normalizeServerUrl(url)),
  }));
  const seen = new Set(readServers.map((server) => server.url));
  const writeOnlyServers = writeUrls
    .map(normalizeServerUrl)
    .filter((url) => !seen.has(url))
    .map((url) => ({ url, read: false, write: true }));
  return [...readServers, ...writeOnlyServers];
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function compareKeys(left, right) {
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

class MinHeap {
  constructor(compare) {
    this.compare = compare;
    this.items = [];
  }

  get size() {
    return this.items.length;
  }

  push(item) {
    this.items.push(item);
    this.bubbleUp(this.items.length - 1);
  }

  pop() {
    if (this.items.length === 0) return null;
    const first = this.items[0];
    const last = this.items.pop();
    if (this.items.length > 0 && last) {
      this.items[0] = last;
      this.bubbleDown(0);
    }
    return first;
  }

  bubbleUp(index) {
    let child = index;
    while (child > 0) {
      const parent = Math.floor((child - 1) / 2);
      if (this.compare(this.items[parent], this.items[child]) <= 0) break;
      [this.items[parent], this.items[child]] = [this.items[child], this.items[parent]];
      child = parent;
    }
  }

  bubbleDown(index) {
    let parent = index;
    while (true) {
      const left = parent * 2 + 1;
      const right = left + 1;
      let smallest = parent;
      if (left < this.items.length && this.compare(this.items[left], this.items[smallest]) < 0) {
        smallest = left;
      }
      if (right < this.items.length && this.compare(this.items[right], this.items[smallest]) < 0) {
        smallest = right;
      }
      if (smallest === parent) break;
      [this.items[parent], this.items[smallest]] = [this.items[smallest], this.items[parent]];
      parent = smallest;
    }
  }
}

class JsonlFileWriter {
  constructor(filePath, options = {}) {
    this.filePath = filePath;
    this.flushBytes = options.flushBytes ?? 1024 * 1024;
    this.buffer = '';
    this.handle = null;
    this.lines = 0;
  }

  async write(value) {
    if (!this.handle) {
      await fs.mkdir(path.dirname(this.filePath), { recursive: true });
      this.handle = await fs.open(this.filePath, 'w');
    }
    this.buffer += `${JSON.stringify(value)}\n`;
    this.lines += 1;
    if (this.buffer.length >= this.flushBytes) {
      await this.flush();
    }
  }

  async flush() {
    if (!this.handle || this.buffer.length === 0) return;
    const chunk = this.buffer;
    this.buffer = '';
    await this.handle.write(chunk);
  }

  async close() {
    await this.flush();
    if (this.handle) {
      await this.handle.close();
      this.handle = null;
    }
    return this.lines;
  }
}

async function* readJsonl(filePath) {
  const stream = createReadStream(filePath, { encoding: 'utf8' });
  const lines = readline.createInterface({
    input: stream,
    crlfDelay: Infinity,
  });
  try {
    for await (const line of lines) {
      const trimmed = line.trim();
      if (trimmed) yield JSON.parse(trimmed);
    }
  } finally {
    lines.close();
    stream.destroy();
  }
}

async function collectJsonlFiles(rootDir) {
  const files = [];
  async function visit(dir) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const filePath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        await visit(filePath);
      } else if (entry.isFile() && entry.name.endsWith('.jsonl')) {
        files.push(filePath);
      }
    }
  }
  await visit(rootDir);
  return files.sort((left, right) => left.localeCompare(right));
}

async function createRunCursor(filePath) {
  const iterator = readJsonl(filePath)[Symbol.asyncIterator]();
  const first = await iterator.next();
  if (first.done) return null;
  return { filePath, iterator, current: first.value };
}

async function* mergeSortedRuns(runPaths) {
  const heap = new MinHeap((left, right) => {
    const keyDelta = compareKeys(left.current.key, right.current.key);
    if (keyDelta !== 0) return keyDelta;
    return compareKeys(left.filePath, right.filePath);
  });
  for (const runPath of runPaths) {
    const cursor = await createRunCursor(runPath);
    if (cursor) heap.push(cursor);
  }

  while (heap.size > 0) {
    const cursor = heap.pop();
    yield cursor.current;
    const next = await cursor.iterator.next();
    if (!next.done) {
      cursor.current = next.value;
      heap.push(cursor);
    }
  }
}

async function* dedupeRecordRuns(runPaths) {
  for await (const entry of dedupeRecordRunEntries(runPaths)) {
    yield entry.record;
  }
}

async function* dedupeRecordRunEntries(runPaths) {
  let currentKey = null;
  let best = null;
  for await (const entry of mergeSortedRuns(runPaths)) {
    if (entry.key !== currentKey) {
      if (best?.record) yield best;
      currentKey = entry.key;
      best = entry;
    } else if ((entry.quality ?? 0) > (best?.quality ?? 0)) {
      best = entry;
    }
  }
  if (best?.record) yield best;
}

async function* dedupeLinkRuns(runPaths) {
  let currentKey = null;
  let selected = null;
  for await (const entry of mergeSortedRuns(runPaths)) {
    if (entry.key !== currentKey) {
      if (selected?.cid) {
        const cid = deserializeCid(selected.cid);
        if (cid) yield [selected.key, cid];
      }
      currentKey = entry.key;
      selected = entry;
    } else {
      selected = entry;
    }
  }
  if (selected?.cid) {
    const cid = deserializeCid(selected.cid);
    if (cid) yield [selected.key, cid];
  }
}

async function writeSortedRecordRun(runDir, records, runIndex) {
  if (records.size === 0) return null;
  const filePath = path.join(runDir, 'records', `records-${String(runIndex).padStart(6, '0')}.jsonl`);
  const writer = new JsonlFileWriter(filePath);
  const sorted = [...records.values()].sort((left, right) => compareKeys(left.key, right.key));
  for (const entry of sorted) {
    await writer.write({
      key: entry.key,
      quality: entry.quality,
      record: entry.record,
    });
  }
  const lines = await writer.close();
  return { filePath, lines };
}

async function writeSortedAddressRun(addressRunDir, addresses, runIndex) {
  if (addresses.size === 0) return null;
  const filePath = path.join(addressRunDir, `addresses-${String(runIndex).padStart(6, '0')}.jsonl`);
  const writer = new JsonlFileWriter(filePath);
  const sorted = [...addresses.values()].sort((left, right) => compareKeys(left.key, right.key));
  for (const entry of sorted) {
    await writer.write({
      key: entry.key,
      streetKey: entry.streetKey,
      point: entry.point,
    });
  }
  const lines = await writer.close();
  return { filePath, lines };
}

async function* dedupeAddressRuns(runPaths) {
  let currentKey = null;
  let selected = null;
  for await (const entry of mergeSortedRuns(runPaths)) {
    if (entry.key !== currentKey) {
      if (selected?.point) yield selected;
      currentKey = entry.key;
      selected = entry;
    } else if ((entry.point?.confidence ?? 0) > (selected?.point?.confidence ?? 0)) {
      selected = entry;
    }
  }
  if (selected?.point) yield selected;
}

async function* groupAddressRunsByStreet(runPaths) {
  let currentStreetKey = null;
  let points = [];
  for await (const entry of dedupeAddressRuns(runPaths)) {
    if (entry.streetKey !== currentStreetKey) {
      if (currentStreetKey && points.length > 0) {
        yield { streetKey: currentStreetKey, points };
      }
      currentStreetKey = entry.streetKey;
      points = [];
    }
    if (entry.point) points.push(entry.point);
  }
  if (currentStreetKey && points.length > 0) {
    yield { streetKey: currentStreetKey, points };
  }
}

class SortedLinkRunWriter {
  constructor(options) {
    this.runDir = options.runDir;
    this.label = options.label;
    this.maxEntries = options.maxEntries;
    this.entries = new Map();
    this.runPaths = [];
    this.totalEntries = 0;
    this.runIndex = 0;
  }

  async add(key, cid) {
    this.entries.set(key, serializeCid(cid));
    this.totalEntries += 1;
    if (this.entries.size >= this.maxEntries) {
      await this.flush();
    }
  }

  async flush() {
    if (this.entries.size === 0) return null;
    const filePath = path.join(this.runDir, this.label, `${this.label}-${String(this.runIndex).padStart(6, '0')}.jsonl`);
    this.runIndex += 1;
    const writer = new JsonlFileWriter(filePath);
    const sorted = [...this.entries.entries()].sort((left, right) => compareKeys(left[0], right[0]));
    this.entries.clear();
    for (const [key, cid] of sorted) {
      await writer.write({ key, cid });
    }
    const lines = await writer.close();
    this.runPaths.push(filePath);
    console.error(`wrote ${this.label} run entries=${lines} runs=${this.runPaths.length}`);
    return filePath;
  }

  async close() {
    await this.flush();
    return this.runPaths;
  }
}

async function writeLinkLeaf(tree, chunk) {
  return (await tree.putDirectory(chunk.map(([key, targetCid]) => ({
    name: escapeKey(key),
    cid: targetCid,
    size: 0,
    type: LinkType.File,
  })))).cid;
}

async function writeInternalNode(tree, chunk) {
  return (await tree.putDirectory(chunk.map((entry) => ({
    name: escapeKey(entry.firstKey),
    cid: entry.cid,
    size: 0,
    type: LinkType.Dir,
  })))).cid;
}

async function readSingleLevelEntry(filePath) {
  for await (const entry of readJsonl(filePath)) {
    return entry;
  }
  return null;
}

async function buildInternalLevel(tree, inputLevelPath, outputLevelPath, maxKeys, label, levelNumber) {
  const writer = new JsonlFileWriter(outputLevelPath);
  let chunk = [];
  let nodeCount = 0;
  for await (const entry of readJsonl(inputLevelPath)) {
    const cid = deserializeCid(entry.cid);
    if (!cid) continue;
    chunk.push({ firstKey: entry.firstKey, cid });
    if (chunk.length >= maxKeys) {
      const nodeCid = await writeInternalNode(tree, chunk);
      await writer.write({ firstKey: chunk[0].firstKey, cid: serializeCid(nodeCid) });
      nodeCount += 1;
      chunk = [];
    }
  }
  if (chunk.length > 0) {
    const nodeCid = await writeInternalNode(tree, chunk);
    await writer.write({ firstKey: chunk[0].firstKey, cid: serializeCid(nodeCid) });
    nodeCount += 1;
  }
  await writer.close();
  console.error(`built ${label} btree level=${levelNumber} nodes=${nodeCount}`);
  return { filePath: outputLevelPath, count: nodeCount };
}

async function buildLinkBTreeFromRuns(tree, runPaths, options) {
  const order = options.order ?? 64;
  const maxKeys = order - 1;
  if (runPaths.length === 0) return { root: null, count: 0 };

  const levelDir = path.join(options.runDir, `${options.label}-levels`);
  await fs.mkdir(levelDir, { recursive: true });
  const leafLevelPath = path.join(levelDir, 'level-000000.jsonl');
  const writer = new JsonlFileWriter(leafLevelPath);
  let chunk = [];
  let leafCount = 0;
  let entryCount = 0;
  for await (const [key, cid] of dedupeLinkRuns(runPaths)) {
    chunk.push([key, cid]);
    entryCount += 1;
    if (chunk.length >= maxKeys) {
      const leafCid = await writeLinkLeaf(tree, chunk);
      await writer.write({ firstKey: chunk[0][0], cid: serializeCid(leafCid) });
      leafCount += 1;
      chunk = [];
    }
    if (entryCount % 1000000 === 0) {
      console.error(`building ${options.label} btree entries=${entryCount} leaves=${leafCount}`);
    }
  }
  if (chunk.length > 0) {
    const leafCid = await writeLinkLeaf(tree, chunk);
    await writer.write({ firstKey: chunk[0][0], cid: serializeCid(leafCid) });
    leafCount += 1;
  }
  await writer.close();
  console.error(`built ${options.label} btree level=0 entries=${entryCount} leaves=${leafCount}`);

  let current = { filePath: leafLevelPath, count: leafCount };
  let level = 1;
  while (current.count > 1) {
    current = await buildInternalLevel(
      tree,
      current.filePath,
      path.join(levelDir, `level-${String(level).padStart(6, '0')}.jsonl`),
      maxKeys,
      options.label,
      level,
    );
    level += 1;
  }

  const rootEntry = await readSingleLevelEntry(current.filePath);
  return {
    root: deserializeCid(rootEntry?.cid),
    count: entryCount,
  };
}


function normalizeText(value) {
  return `${value ?? ''}`
    .toLowerCase()
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

function slugify(value) {
  return normalizeText(value)
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || 'item';
}

function titleCase(value) {
  return `${value ?? ''}`
    .replace(/[_-]+/g, ' ')
    .replace(/\w\S*/g, (part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .trim();
}

function numberValue(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function serializeCid(cid) {
  if (!cid?.hash) return null;
  return {
    hash: toHex(cid.hash),
    ...(cid.key ? { key: toHex(cid.key) } : {}),
  };
}

function tileCoordinateToLonLat(z, x, y, tileX, tileY, extent) {
  const n = 2 ** z;
  const lon = ((x + tileX / extent) / n) * 360 - 180;
  const mercatorY = Math.PI * (1 - 2 * ((y + tileY / extent) / n));
  const lat = (Math.atan(Math.sinh(mercatorY)) * 180) / Math.PI;
  return { lat, lng: lon };
}

function lonLatToTile(lng, lat, zoom) {
  const n = 2 ** zoom;
  const x = Math.floor(((lng + 180) / 360) * n);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n);
  return {
    x: Math.max(0, Math.min(n - 1, x)),
    y: Math.max(0, Math.min(n - 1, y)),
  };
}

function tileBounds(z, x, y) {
  const nw = tileCoordinateToLonLat(z, x, y, 0, 0, 1);
  const se = tileCoordinateToLonLat(z, x, y, 1, 1, 1);
  return {
    west: nw.lng,
    east: se.lng,
    north: nw.lat,
    south: se.lat,
  };
}

function intersectsBounds(a, b) {
  if (!b) return true;
  if (a.north < b.south || a.south > b.north) return false;
  if (b.west <= b.east) {
    return a.east >= b.west && a.west <= b.east;
  }
  return a.east >= b.west || a.west <= b.east;
}

function featureCenter(feature, z, x, y) {
  const [minX, minY, maxX, maxY] = feature.bbox();
  const centerX = (minX + maxX) / 2;
  const centerY = (minY + maxY) / 2;
  const center = tileCoordinateToLonLat(z, x, y, centerX, centerY, feature.extent);
  const nw = tileCoordinateToLonLat(z, x, y, minX, minY, feature.extent);
  const se = tileCoordinateToLonLat(z, x, y, maxX, maxY, feature.extent);
  return {
    ...center,
    boundingBox: [
      Math.min(nw.lat, se.lat),
      Math.max(nw.lat, se.lat),
      Math.min(nw.lng, se.lng),
      Math.max(nw.lng, se.lng),
    ],
  };
}

function featureCenterTilePoint(feature) {
  const [minX, minY, maxX, maxY] = feature.bbox();
  return {
    x: (minX + maxX) / 2,
    y: (minY + maxY) / 2,
  };
}

function geometryBounds(geometry) {
  let minX = Number.POSITIVE_INFINITY;
  let minY = Number.POSITIVE_INFINITY;
  let maxX = Number.NEGATIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  for (const line of geometry) {
    for (const point of line) {
      if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) continue;
      minX = Math.min(minX, point.x);
      minY = Math.min(minY, point.y);
      maxX = Math.max(maxX, point.x);
      maxY = Math.max(maxY, point.y);
    }
  }
  if (!Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)) {
    return null;
  }
  return { minX, minY, maxX, maxY };
}

function squaredDistanceBetweenPoints(left, right) {
  const dx = left.x - right.x;
  const dy = left.y - right.y;
  return dx * dx + dy * dy;
}

function squaredDistanceToSegment(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const segmentLengthSquared = dx * dx + dy * dy;
  if (segmentLengthSquared === 0) return squaredDistanceBetweenPoints(point, start);
  const t = Math.max(0, Math.min(1, ((point.x - start.x) * dx + (point.y - start.y) * dy) / segmentLengthSquared));
  const projected = {
    x: start.x + t * dx,
    y: start.y + t * dy,
  };
  return squaredDistanceBetweenPoints(point, projected);
}

function distanceToGeometry(point, geometry) {
  let best = Number.POSITIVE_INFINITY;
  for (const line of geometry) {
    if (line.length === 1) {
      best = Math.min(best, Math.sqrt(squaredDistanceBetweenPoints(point, line[0])));
      continue;
    }
    for (let index = 1; index < line.length; index += 1) {
      best = Math.min(best, Math.sqrt(squaredDistanceToSegment(point, line[index - 1], line[index])));
    }
  }
  return best;
}

function metersPerTileUnit(z, x, y, extent) {
  const center = tileCoordinateToLonLat(z, x, y, extent / 2, extent / 2, extent);
  const tileWidthMeters = 40075016.686 * Math.max(0.05, Math.cos(center.lat * Math.PI / 180)) / (2 ** z);
  return tileWidthMeters / extent;
}

function normalizeHouseNumber(value) {
  return `${value ?? ''}`
    .toLowerCase()
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .replace(/[–—−]/g, '-')
    .replace(/\s+/g, '')
    .trim();
}

function extractHouseNumber(properties) {
  const value = properties?.housenumber
    ?? properties?.house_number
    ?? properties?.['addr:housenumber']
    ?? properties?.number;
  if (typeof value !== 'string' && typeof value !== 'number') return '';
  const text = `${value}`.trim();
  return text.length <= 32 ? text : '';
}

function extractNames(properties) {
  const aliases = [];
  const add = (value) => {
    if (typeof value !== 'string') return;
    const trimmed = value.trim();
    if (!trimmed || trimmed.length > 160) return;
    if (!aliases.includes(trimmed)) aliases.push(trimmed);
  };

  add(properties.name);
  add(properties.name_en);
  add(properties['name:en']);
  add(properties.name_int);
  add(properties.name_latin);
  add(properties['name:latin']);
  add(properties.ref);
  add(properties.iata);
  add(properties.icao);

  for (const [key, value] of Object.entries(properties)) {
    if (key === 'name' || !key.startsWith('name')) continue;
    add(value);
    if (aliases.length >= 40) break;
  }

  return {
    primary: aliases[0] ?? '',
    aliases: aliases.slice(1, 25),
  };
}

function layerClass(layerName) {
  switch (layerName) {
    case 'transportation_name':
      return 'highway';
    case 'poi':
      return 'amenity';
    case 'park':
      return 'leisure';
    case 'water_name':
      return 'natural';
    case 'waterway':
      return 'waterway';
    case 'aerodrome_label':
      return 'aeroway';
    case 'mountain_peak':
      return 'natural';
    case 'boundary':
      return 'boundary';
    case 'place':
    default:
      return 'place';
  }
}

function displayNameFor(layerName, properties) {
  const subclass = properties.subclass || properties.class;
  switch (layerName) {
    case 'transportation_name':
      return 'Street';
    case 'poi':
      return titleCase(subclass || 'POI');
    case 'park':
      return titleCase(subclass || 'Park');
    case 'water_name':
      return titleCase(subclass || 'Water');
    case 'waterway':
      return titleCase(subclass || 'Waterway');
    case 'aerodrome_label':
      return titleCase(subclass || 'Airport');
    case 'mountain_peak':
      return 'Peak';
    case 'boundary':
      return 'Administrative Boundary';
    case 'place':
    default:
      return titleCase(subclass || 'Place');
  }
}

function addressTypeFor(layerName, properties) {
  switch (layerName) {
    case 'transportation_name':
      return 'road';
    case 'poi':
      return properties.subclass || properties.class || 'poi';
    case 'boundary':
      return properties.admin_level && Number(properties.admin_level) <= 2 ? 'country' : 'state';
    case 'aerodrome_label':
      return 'airport';
    case 'water_name':
    case 'waterway':
      return 'water';
    case 'mountain_peak':
      return 'peak';
    case 'park':
      return 'park';
    case 'place':
    default:
      return properties.class || 'place';
  }
}

function placeRankFor(layerName, properties, zoom) {
  const rank = numberValue(properties.rank);
  if (rank !== undefined) return rank;
  if (layerName === 'boundary') {
    const adminLevel = numberValue(properties.admin_level);
    if (adminLevel !== undefined) return Math.min(20, Math.max(2, adminLevel));
    return 8;
  }
  if (layerName === 'transportation_name') return 26;
  if (layerName === 'poi') return 24;
  if (layerName === 'place') return Math.max(4, Math.min(24, 18 - Math.floor(zoom / 2)));
  return 22;
}

function importanceFor(layerName, properties, zoom) {
  const weight = LAYER_WEIGHTS[layerName] ?? 20;
  const rank = numberValue(properties.rank);
  const rankBoost = rank === undefined ? 0 : Math.max(0, 20 - rank) / 24;
  return Math.max(0.02, Math.min(1, (weight / 100) * 0.72 + rankBoost * 0.2 + zoom / 120));
}

function recordIdFromKey(key) {
  return crypto.createHash('sha1').update(key).digest('hex').slice(0, 20);
}

function dedupeKeyFor(layerName, feature, record, options) {
  const normalizedName = slugify(record.name);
  if (layerName === 'transportation_name') {
    const bucket = lonLatToTile(record.lng, record.lat, options.roadBucketZoom);
    return `road:${normalizedName}:${record.type}:${options.roadBucketZoom}:${bucket.x}:${bucket.y}`;
  }
  if (feature.id !== undefined && feature.id !== null) {
    return `${layerName}:id:${feature.id}`;
  }
  const bucket = lonLatToTile(record.lng, record.lat, options.featureBucketZoom);
  return `${layerName}:name:${normalizedName}:${record.type}:${options.featureBucketZoom}:${bucket.x}:${bucket.y}`;
}

function qualityFor(layerName, record, zoom) {
  const rank = record.placeRank ?? 30;
  return (zoom * 100000) + ((LAYER_WEIGHTS[layerName] ?? 10) * 100) + ((record.importance ?? 0) * 1000) - rank;
}

function featureToRecord(layerName, feature, z, x, y, options) {
  const properties = feature.properties ?? {};
  const { primary, aliases } = extractNames(properties);
  if (!primary) return null;
  const center = featureCenter(feature, z, x, y);
  if (!Number.isFinite(center.lat) || !Number.isFinite(center.lng)) return null;

  const type = `${properties.subclass || properties.class || layerName}`.trim();
  const searchClass = layerClass(layerName);
  const placeRank = placeRankFor(layerName, properties, z);
  const record = {
    id: '',
    name: primary,
    aliases,
    lat: Number(center.lat.toFixed(6)),
    lng: Number(center.lng.toFixed(6)),
    type,
    class: searchClass,
    displayName: displayNameFor(layerName, properties),
    addressType: addressTypeFor(layerName, properties),
    placeRank,
    importance: Number(importanceFor(layerName, properties, z).toFixed(4)),
    sourceLayer: layerName,
    sourceZoom: z,
    sourceTile: [x, y],
    ...(feature.id !== undefined && feature.id !== null ? { sourceId: String(feature.id) } : {}),
  };

  if (
    center.boundingBox
    && center.boundingBox.every(Number.isFinite)
    && (Math.abs(center.boundingBox[1] - center.boundingBox[0]) > 0.0001
      || Math.abs(center.boundingBox[3] - center.boundingBox[2]) > 0.0001)
  ) {
    record.boundingBox = center.boundingBox.map((value) => Number(value.toFixed(6)));
  }

  const dedupeKey = dedupeKeyFor(layerName, feature, record, options);
  const quality = qualityFor(layerName, record, z);
  const priority = Math.max(0, 9999999 - Math.round(quality)).toString().padStart(7, '0');
  record.id = `${priority}:${layerName}:${recordIdFromKey(dedupeKey)}`;
  return {
    key: dedupeKey,
    quality,
    record,
  };
}

function streetCandidateFromFeature(feature, z, x, y, options) {
  const extracted = featureToRecord(ADDRESS_STREET_LAYER, feature, z, x, y, options);
  if (!extracted) return null;
  let geometry;
  try {
    geometry = feature.loadGeometry();
  } catch {
    return null;
  }
  const bounds = geometryBounds(geometry);
  if (!bounds) return null;
  return {
    streetKey: extracted.key,
    record: extracted.record,
    geometry,
    bounds,
    extent: feature.extent,
  };
}

function createStreetSpatialIndex(streets, joinRadiusTileUnits) {
  const cellSize = Math.max(64, Math.min(512, Math.ceil(joinRadiusTileUnits * 2)));
  const cells = new Map();
  const addCell = (cellX, cellY, street) => {
    const key = `${cellX}:${cellY}`;
    const bucket = cells.get(key);
    if (bucket) bucket.push(street);
    else cells.set(key, [street]);
  };

  for (const street of streets) {
    const minCellX = Math.floor((street.bounds.minX - joinRadiusTileUnits) / cellSize);
    const maxCellX = Math.floor((street.bounds.maxX + joinRadiusTileUnits) / cellSize);
    const minCellY = Math.floor((street.bounds.minY - joinRadiusTileUnits) / cellSize);
    const maxCellY = Math.floor((street.bounds.maxY + joinRadiusTileUnits) / cellSize);
    for (let cellX = minCellX; cellX <= maxCellX; cellX += 1) {
      for (let cellY = minCellY; cellY <= maxCellY; cellY += 1) {
        addCell(cellX, cellY, street);
      }
    }
  }

  return {
    query(point) {
      const seen = new Set();
      const candidates = [];
      const minCellX = Math.floor((point.x - joinRadiusTileUnits) / cellSize);
      const maxCellX = Math.floor((point.x + joinRadiusTileUnits) / cellSize);
      const minCellY = Math.floor((point.y - joinRadiusTileUnits) / cellSize);
      const maxCellY = Math.floor((point.y + joinRadiusTileUnits) / cellSize);
      for (let cellX = minCellX; cellX <= maxCellX; cellX += 1) {
        for (let cellY = minCellY; cellY <= maxCellY; cellY += 1) {
          for (const street of cells.get(`${cellX}:${cellY}`) ?? []) {
            if (seen.has(street)) continue;
            seen.add(street);
            candidates.push(street);
          }
        }
      }
      return candidates;
    },
  };
}

function extractAddressCandidates(vectorTile, z, x, y, options) {
  const streetLayer = vectorTile.layers[ADDRESS_STREET_LAYER];
  const numberLayer = vectorTile.layers[ADDRESS_NUMBER_LAYER];
  if (!numberLayer) {
    return { entries: [], streetFeaturesSeen: streetLayer?.length ?? 0, streetCandidates: 0, numbersSeen: 0, joined: 0, unmatched: 0 };
  }

  const streets = [];
  if (streetLayer) {
    for (let index = 0; index < streetLayer.length; index += 1) {
      const street = streetCandidateFromFeature(streetLayer.feature(index), z, x, y, options);
      if (street) streets.push(street);
    }
  }
  if (streets.length === 0) {
    return {
      entries: [],
      streetFeaturesSeen: streetLayer?.length ?? 0,
      streetCandidates: 0,
      numbersSeen: numberLayer.length,
      joined: 0,
      unmatched: numberLayer.length,
    };
  }

  const extent = streets[0]?.extent ?? 4096;
  const metersPerUnit = metersPerTileUnit(z, x, y, extent);
  const joinRadiusTileUnits = options.addressJoinRadiusMeters / Math.max(0.000001, metersPerUnit);
  const streetIndex = createStreetSpatialIndex(streets, joinRadiusTileUnits);
  const entries = [];
  let numbersSeen = 0;
  let joined = 0;
  let unmatched = 0;

  for (let index = 0; index < numberLayer.length; index += 1) {
    const feature = numberLayer.feature(index);
    numbersSeen += 1;
    const houseNumber = extractHouseNumber(feature.properties ?? {});
    const normalizedNumber = normalizeHouseNumber(houseNumber);
    if (!normalizedNumber) {
      unmatched += 1;
      continue;
    }

    const tilePoint = featureCenterTilePoint(feature);
    let bestStreet = null;
    let bestDistanceTileUnits = Number.POSITIVE_INFINITY;
    for (const street of streetIndex.query(tilePoint)) {
      const distance = distanceToGeometry(tilePoint, street.geometry);
      if (distance < bestDistanceTileUnits) {
        bestDistanceTileUnits = distance;
        bestStreet = street;
      }
    }

    const distanceMeters = bestDistanceTileUnits * metersPerUnit;
    if (!bestStreet || distanceMeters > options.addressJoinRadiusMeters) {
      unmatched += 1;
      continue;
    }

    const center = tileCoordinateToLonLat(z, x, y, tilePoint.x, tilePoint.y, feature.extent);
    const lat = Number(center.lat.toFixed(6));
    const lng = Number(center.lng.toFixed(6));
    const confidence = Number(Math.max(0.05, 1 - (distanceMeters / options.addressJoinRadiusMeters)).toFixed(4));
    entries.push({
      key: `${bestStreet.streetKey}\t${normalizedNumber}\t${lat.toFixed(6)}\t${lng.toFixed(6)}`,
      streetKey: bestStreet.streetKey,
      point: {
        n: houseNumber,
        lat,
        lng,
        confidence,
        distanceMeters: Number(distanceMeters.toFixed(2)),
        sourceZoom: z,
        sourceTile: [x, y],
      },
    });
    joined += 1;
  }

  return {
    entries,
    streetFeaturesSeen: streetLayer?.length ?? 0,
    streetCandidates: streets.length,
    numbersSeen,
    joined,
    unmatched,
  };
}

async function extractRecords(options) {
  const pmtiles = new PMTiles(options.pmtilesUrl, new ResolvedValueCache(256));
  const header = await pmtiles.getHeader();
  const metadata = await pmtiles.getMetadata().catch(() => null);
  const root = await pmtiles.cache.getDirectory(
    pmtiles.source,
    header.rootDirectoryOffset,
    header.rootDirectoryLength,
    header,
  );
  const sourceZooms = new Set(options.sourceZooms);
  const layers = new Set(options.layers);
  let recordBatch = new Map();
  let addressBatch = new Map();
  const recordRuns = [];
  const addressRuns = [];
  const stats = {
    directories: 0,
    tileEntriesSeen: 0,
    tileEntriesSelected: 0,
    tilesDecoded: 0,
    featuresSeen: 0,
    namedFeaturesSeen: 0,
    recordCandidates: 0,
    recordsBuffered: 0,
    recordsReplacedInBatch: 0,
    recordRuns: 0,
    recordsFlushed: 0,
    addressStreetFeaturesSeen: 0,
    addressStreetCandidates: 0,
    addressNumbersSeen: 0,
    addressPointsJoined: 0,
    addressPointsUnmatched: 0,
    addressRecordsBuffered: 0,
    addressRecordsReplacedInBatch: 0,
    addressRuns: 0,
    addressPointsFlushed: 0,
    tileErrors: 0,
    tileRetries: 0,
    startedAt: Date.now(),
  };
  const inFlight = new Set();
  let stopped = false;
  let recordRunIndex = 0;
  let addressRunIndex = 0;
  let recordFlushPromise = Promise.resolve();
  let addressFlushPromise = Promise.resolve();

  async function flushRecordBatch(force = false) {
    if (recordBatch.size === 0 || (!force && recordBatch.size < options.recordRunSize)) return;
    const batch = recordBatch;
    recordBatch = new Map();
    const runIndex = recordRunIndex;
    recordRunIndex += 1;
    recordFlushPromise = recordFlushPromise.then(async () => {
      const run = await writeSortedRecordRun(options.runDir, batch, runIndex);
      if (!run) return;
      recordRuns.push(run.filePath);
      stats.recordRuns += 1;
      stats.recordsFlushed += run.lines;
      console.error(`wrote record run entries=${run.lines} runs=${recordRuns.length}`);
    });
    await recordFlushPromise;
  }

  async function flushAddressBatch(force = false) {
    if (addressBatch.size === 0 || (!force && addressBatch.size < options.recordRunSize)) return;
    const batch = addressBatch;
    addressBatch = new Map();
    const runIndex = addressRunIndex;
    addressRunIndex += 1;
    addressFlushPromise = addressFlushPromise.then(async () => {
      const run = await writeSortedAddressRun(options.addressRunDir, batch, runIndex);
      if (!run) return;
      addressRuns.push(run.filePath);
      stats.addressRuns += 1;
      stats.addressPointsFlushed += run.lines;
      console.error(`wrote address run entries=${run.lines} runs=${addressRuns.length}`);
    });
    await addressFlushPromise;
  }

  async function addRecordCandidate(extracted) {
    const existing = recordBatch.get(extracted.key);
    if (!existing) {
      recordBatch.set(extracted.key, extracted);
      stats.recordsBuffered += 1;
    } else if (extracted.quality > existing.quality) {
      recordBatch.set(extracted.key, extracted);
      stats.recordsReplacedInBatch += 1;
    }
    stats.recordCandidates += 1;
    if (recordBatch.size >= options.recordRunSize) {
      await flushRecordBatch();
    }
  }

  async function addAddressCandidate(extracted) {
    const existing = addressBatch.get(extracted.key);
    if (!existing) {
      addressBatch.set(extracted.key, extracted);
      stats.addressRecordsBuffered += 1;
    } else if ((extracted.point?.confidence ?? 0) > (existing.point?.confidence ?? 0)) {
      addressBatch.set(extracted.key, extracted);
      stats.addressRecordsReplacedInBatch += 1;
    }
    if (addressBatch.size >= options.recordRunSize) {
      await flushAddressBatch();
    }
  }

  async function readVectorTile(entry) {
    let attempt = 0;
    while (true) {
      try {
        const response = await pmtiles.source.getBytes(
          header.tileDataOffset + entry.offset,
          entry.length,
          undefined,
          header.etag,
        );
        const decompressed = await pmtiles.decompress(response.data, header.tileCompression);
        return new VectorTile(new Protobuf(new Uint8Array(decompressed)));
      } catch (error) {
        if (attempt >= options.tileRetries) throw error;
        attempt += 1;
        stats.tileRetries += 1;
        await sleep(options.retryDelayMs * attempt);
      }
    }
  }

  async function processTile(entry, z, x, y) {
    try {
      const vectorTile = await readVectorTile(entry);
      stats.tilesDecoded += 1;
      if (sourceZooms.has(z)) {
        for (const layerName of layers) {
          const layer = vectorTile.layers[layerName];
          if (!layer) continue;
          for (let index = 0; index < layer.length; index += 1) {
            const feature = layer.feature(index);
            stats.featuresSeen += 1;
            const extracted = featureToRecord(layerName, feature, z, x, y, options);
            if (!extracted) continue;
            stats.namedFeaturesSeen += 1;
            await addRecordCandidate(extracted);
            if (options.maxRecords > 0 && stats.recordCandidates >= options.maxRecords) {
              stopped = true;
              return;
            }
          }
        }
      }
      if (options.addressSidecars && z === options.addressZoom) {
        const extracted = extractAddressCandidates(vectorTile, z, x, y, options);
        stats.addressStreetFeaturesSeen += extracted.streetFeaturesSeen;
        stats.addressStreetCandidates += extracted.streetCandidates;
        stats.addressNumbersSeen += extracted.numbersSeen;
        stats.addressPointsJoined += extracted.joined;
        stats.addressPointsUnmatched += extracted.unmatched;
        for (const address of extracted.entries) {
          await addAddressCandidate(address);
        }
      }
      if (options.progressTiles > 0 && stats.tilesDecoded % options.progressTiles === 0) {
        const elapsed = Math.max(1, (Date.now() - stats.startedAt) / 1000);
        console.error(
          `extract progress tiles=${stats.tilesDecoded} candidates=${stats.recordCandidates} buffer=${recordBatch.size} runs=${recordRuns.length} addressJoined=${stats.addressPointsJoined} addressRuns=${addressRuns.length} features=${stats.namedFeaturesSeen} rate=${(stats.tilesDecoded / elapsed).toFixed(1)} tiles/s`,
        );
      }
    } catch (error) {
      stats.tileErrors += 1;
      if (stats.tileErrors <= 20) {
        console.error(`tile decode failed z=${z} x=${x} y=${y}: ${error instanceof Error ? error.message : error}`);
      }
    }
  }

  async function schedule(entry, z, x, y) {
    const pending = processTile(entry, z, x, y).finally(() => inFlight.delete(pending));
    inFlight.add(pending);
    if (inFlight.size >= options.tileConcurrency) {
      await Promise.race(inFlight);
    }
  }

  for (const directoryEntry of root) {
    if (stopped) break;
    if (directoryEntry.runLength !== 0) continue;
    stats.directories += 1;
    const leaf = await pmtiles.cache.getDirectory(
      pmtiles.source,
      header.leafDirectoryOffset + directoryEntry.offset,
      directoryEntry.length,
      header,
    );
    for (const tileEntry of leaf) {
      if (stopped) break;
      if (tileEntry.runLength === 0) continue;
      stats.tileEntriesSeen += 1;
      const [z, x, y] = tileIdToZxy(tileEntry.tileId);
      if (!sourceZooms.has(z) && !(options.addressSidecars && z === options.addressZoom)) continue;
      if (!intersectsBounds(tileBounds(z, x, y), options.bounds)) continue;
      if (options.maxTiles > 0 && stats.tileEntriesSelected >= options.maxTiles) {
        stopped = true;
        break;
      }
      stats.tileEntriesSelected += 1;
      await schedule(tileEntry, z, x, y);
    }
    if (stats.directories % 100 === 0) {
      console.error(`directory progress ${stats.directories}/${root.length} selectedTiles=${stats.tileEntriesSelected} candidates=${stats.recordCandidates} buffer=${recordBatch.size} runs=${recordRuns.length} addressJoined=${stats.addressPointsJoined} addressRuns=${addressRuns.length}`);
    }
  }
  await Promise.all(inFlight);
  await flushRecordBatch(true);
  await flushAddressBatch(true);
  await recordFlushPromise;
  await addressFlushPromise;

  if (stats.tileErrors > options.maxTileErrors) {
    throw new Error(`Tile decode failures exceeded limit: ${stats.tileErrors} > ${options.maxTileErrors}`);
  }

  return {
    header,
    metadata,
    recordRuns,
    addressRuns,
    stats: {
      ...stats,
      elapsedMs: Date.now() - stats.startedAt,
    },
  };
}

async function loadExtractedRecordRuns(options) {
  const startedAt = Date.now();
  const sourceManifest = options.sourceManifest ? JSON.parse(await fs.readFile(options.sourceManifest, 'utf8')) : null;
  if (sourceManifest && (sourceManifest.kind !== 'iris-maps-place-search-index' || !sourceManifest.sourceArchive)) {
    throw new Error('Invalid original search manifest');
  }
  const pmtiles = sourceManifest ? null : new PMTiles(options.pmtilesUrl, new ResolvedValueCache(256));
  const header = sourceManifest ? { ...sourceManifest.sourceArchive, tileDataLength: sourceManifest.sourceArchive.tileBytes } : await pmtiles.getHeader();
  const metadata = sourceManifest ? { attribution: sourceManifest.attribution, osm_date: sourceManifest.osmDate } : await pmtiles.getMetadata().catch(() => null);
  const recordRuns = await collectJsonlFiles(options.recordRunDir);
  if (recordRuns.length === 0) {
    throw new Error(`No sorted record runs found in ${options.recordRunDir}`);
  }
  const addressRuns = options.addressSidecars
    ? await collectJsonlFiles(options.addressRunDir).catch((error) => {
        if (error?.code === 'ENOENT') return [];
        throw error;
      })
    : [];
  return {
    header,
    metadata,
    recordRuns,
    addressRuns,
    sourceManifest,
    stats: {
      buildFromRecordRuns: true,
      recordRuns: recordRuns.length,
      addressRuns: addressRuns.length,
      elapsedMs: Date.now() - startedAt,
    },
  };
}

function extractSingleCharacterTerms(text) {
  const terms = [];
  const seen = new Set();
  for (const rawWord of `${text ?? ''}`.split(/[^\p{L}\p{N}]+/u)) {
    const normalized = normalizeText(rawWord);
    if (normalized.length === 1 && !/^\d$/u.test(normalized) && !seen.has(normalized)) {
      seen.add(normalized);
      terms.push(normalized);
    }
  }
  return terms;
}

function buildSearchTerms(searchIndex, record, namesOnly = false) {
  const text = [
    record.name,
    ...(record.aliases ?? []),
    ...(namesOnly ? [] : [record.type, record.addressType]),
  ].filter(Boolean).join(' ');
  const terms = searchIndex.parseKeywords(text);
  const seen = new Set(terms);
  for (const term of extractSingleCharacterTerms(text)) {
    if (!seen.has(term)) {
      seen.add(term);
      terms.push(term);
    }
  }
  return terms;
}

function hasPlaceNamePostings(record) {
  const administrative = ADMINISTRATIVE_TYPES.has(record.type) || ADMINISTRATIVE_TYPES.has(record.addressType);
  return (record.class === 'place' && (administrative || SETTLEMENT_TYPES.has(record.type) || SETTLEMENT_TYPES.has(record.addressType)))
    || (record.class === 'boundary' && (administrative || record.type === 'administrative'));
}

async function buildIndex(options, extracted) {
  const contextSource = options.contextSource
    ? JSON.parse(await fs.readFile(options.contextSource, 'utf8')) : extracted.contextSource;
  if (contextSource && (contextSource.kind !== 'administrative-boundary-context' || !Number.isSafeInteger(contextSource.records))) {
    throw new Error('Invalid boundary context metadata');
  }
  await fs.mkdir(options.blockStore, { recursive: true });
  await fs.mkdir(options.runDir, { recursive: true });
  const store = new FileBlockStore(options.blockStore);
  const tree = new HashTree({ store });
  const searchIndex = new SearchIndex(store, { order: 64, minKeywordLength: 1 });
  const byIdWriter = new SortedLinkRunWriter({
    runDir: options.runDir,
    label: 'by-id',
    maxEntries: options.indexRunSize,
  });
  const searchWriter = new SortedLinkRunWriter({
    runDir: options.runDir,
    label: 'search',
    maxEntries: options.indexRunSize,
  });

  let recordCount = 0;
  let recordShardCount = 0;
  let skippedRecords = 0;
  let searchEntryCandidates = 0;
  let recordShard = [];
  let addressSidecarCount = 0;
  let addressPointCount = 0;

  const addressIterator = options.addressSidecars && extracted.addressRuns?.length
    ? groupAddressRunsByStreet(extracted.addressRuns)[Symbol.asyncIterator]()
    : null;
  let addressCursor = addressIterator ? await addressIterator.next() : null;

  async function takeAddressPoints(streetKey) {
    if (!addressIterator || !addressCursor) return [];
    while (!addressCursor.done && compareKeys(addressCursor.value.streetKey, streetKey) < 0) {
      addressCursor = await addressIterator.next();
    }
    if (!addressCursor.done && addressCursor.value.streetKey === streetKey) {
      const points = addressCursor.value.points;
      addressCursor = await addressIterator.next();
      return points;
    }
    return [];
  }

  async function flushRecordShard() {
    if (recordShard.length === 0) return;
    const shardRecords = recordShard;
    recordShard = [];
    const shardForApp = {
      version: 1,
      kind: 'iris-maps-search-record-shard',
      records: shardRecords.map(({ id, recordForApp }) => ({
        id,
        ...recordForApp,
      })),
    };
    const { cid: shardCid } = await tree.putFile(TEXT_ENCODER.encode(`${JSON.stringify(shardForApp)}\n`));
    recordShardCount += 1;
    for (const { id, record } of shardRecords) {
      await byIdWriter.add(id, shardCid);
      const scopes = contextSource ? [...new Set((record.contextScopes ?? []).map(normalizeText).filter(Boolean))] : [];
      for (const term of buildSearchTerms(searchIndex, record)) {
        await searchWriter.add(`${SEARCH_PREFIX}${term}:${id}`, shardCid);
        searchEntryCandidates += 1;
        for (const scope of scopes) {
          await searchWriter.add(`g:${scope}:${term}:${id}`, shardCid);
          searchEntryCandidates += 1;
        }
      }
      if (hasPlaceNamePostings(record)) {
        for (const term of buildSearchTerms(searchIndex, record, true)) {
          await searchWriter.add(`${PLACE_NAMES_PREFIX}${term}:${id}`, shardCid);
          searchEntryCandidates += 1;
        }
      }
    }
    if (recordShardCount % 1000 === 0) {
      console.error(`index record shards=${recordShardCount} records=${recordCount} searchEntryCandidates=${searchEntryCandidates}`);
    }
  }

  for await (const entry of dedupeRecordRunEntries(extracted.recordRuns)) {
    const record = entry.record;
    if (!record.name || !Number.isFinite(record.lat) || !Number.isFinite(record.lng)) {
      skippedRecords += 1;
      continue;
    }
    let addressRef;
    if (options.addressSidecars && record.addressType === 'road') {
      const addressPoints = await takeAddressPoints(entry.key);
      if (addressPoints.length > 0) {
        const sidecarForApp = {
          version: 1,
          kind: 'iris-maps-street-address-sidecar',
          streetId: record.id,
          sourceStreetKey: entry.key,
          points: addressPoints,
        };
        const { cid: sidecarCid } = await tree.putFile(TEXT_ENCODER.encode(`${JSON.stringify(sidecarForApp)}\n`));
        addressRef = {
          kind: 'street-address-points-v1',
          cid: serializeCid(sidecarCid),
          count: addressPoints.length,
          maxDistanceMeters: options.addressJoinRadiusMeters,
        };
        addressSidecarCount += 1;
        addressPointCount += addressPoints.length;
      }
    }
    const recordForApp = {
      id: record.id,
      name: record.name,
      lat: record.lat,
      lng: record.lng,
      type: record.type,
      class: record.class,
      displayName: record.displayName,
      ...(record.context ? { context: record.context } : {}),
      ...(record.contextParts?.length ? { contextParts: record.contextParts } : {}),
      ...(record.contextAliases?.length ? { contextAliases: record.contextAliases } : {}),
      ...(record.aliases?.length ? { aliases: record.aliases } : {}),
      ...(record.boundingBox ? { boundingBox: record.boundingBox } : {}),
      ...(record.placeRank !== undefined ? { placeRank: record.placeRank } : {}),
      ...(record.importance !== undefined ? { importance: record.importance } : {}),
      ...(record.addressType ? { addressType: record.addressType } : {}),
      ...(record.sourceLayer ? { sourceLayer: record.sourceLayer } : {}),
      ...(record.sourceZoom !== undefined ? { sourceZoom: record.sourceZoom } : {}),
      ...(record.sourceId ? { sourceId: record.sourceId } : {}),
      ...(record.sourceTile ? { sourceTile: record.sourceTile } : {}),
      ...(addressRef ? { addressRef } : {}),
    };
    recordShard.push({ id: record.id, record, recordForApp });
    recordCount += 1;
    if (recordShard.length >= options.recordShardSize) {
      await flushRecordShard();
    }
    if (recordCount % 10000 === 0) {
      console.error(`index records=${recordCount} searchEntryCandidates=${searchEntryCandidates}`);
    }
  }
  await flushRecordShard();
  for (const expected of [contextSource?.records, extracted.sourceManifest?.placeCount]) {
    if (expected !== undefined && recordCount !== expected) {
      throw new Error(`Incomplete rebuild: ${recordCount} records, expected ${expected}`);
    }
  }

  const byIdRuns = await byIdWriter.close();
  const searchRuns = await searchWriter.close();
  console.error(`building by-id btree runs=${byIdRuns.length}`);
  const byIdBuilt = await buildLinkBTreeFromRuns(tree, byIdRuns, {
    label: 'by-id',
    runDir: options.runDir,
    order: 64,
  });
  console.error(`building search btree runs=${searchRuns.length} candidates=${searchEntryCandidates}`);
  const searchBuilt = await buildLinkBTreeFromRuns(tree, searchRuns, {
    label: 'search',
    runDir: options.runDir,
    order: 64,
  });
  const generatedAt = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
  const manifest = {
    version: 1,
    kind: 'iris-maps-place-search-index',
    generatedAt,
    source: 'OpenFreeMap PMTiles generated from OpenMapTiles/OpenStreetMap data.',
    attribution: extracted.metadata?.attribution ?? 'OpenFreeMap, OpenMapTiles, OpenStreetMap contributors.',
    placeCount: recordCount,
    recordCount,
    recordShardCount,
    skippedRecordCount: skippedRecords,
    searchEntryCount: searchBuilt.count,
    searchEntryCandidates,
    byIdEntryCount: byIdBuilt.count,
    recordPacking: {
      kind: 'json-record-shard',
      version: 1,
      maxRecordsPerShard: options.recordShardSize,
    },
    searchIndexVersion: SEARCH_INDEX_VERSION,
    prefix: SEARCH_PREFIX,
    placeNames: { version: 1, prefix: PLACE_NAMES_PREFIX },
    searchRoot: serializeCid(searchBuilt.root),
    byIdRoot: serializeCid(byIdBuilt.root),
    searchOptions: { order: 64, minKeywordLength: 1 },
    ...(contextSource ? { locationContext: { ...contextSource, scopePrefix: 'g:' } } : {}),
    ...(options.addressSidecars ? {
      addressSidecars: {
        kind: 'street-address-points-v1',
        sourceLayer: ADDRESS_NUMBER_LAYER,
        streetLayer: ADDRESS_STREET_LAYER,
        sourceZoom: options.addressZoom,
        joinRadiusMeters: options.addressJoinRadiusMeters,
        sidecarCount: addressSidecarCount,
        pointCount: addressPointCount,
        runCount: extracted.addressRuns?.length ?? 0,
      },
    } : {}),
    sourceArchive: {
      pmtilesUrl: `https://cdn.iris.to/${MAP_BASEMAP_OWNER_NPUB}/${MAP_BASEMAP_TREE}/tiles.pmtiles`,
      source: `${MAP_BASEMAP_OWNER_NPUB}/${MAP_BASEMAP_TREE}/tiles.pmtiles`,
      minZoom: extracted.header.minZoom,
      maxZoom: extracted.header.maxZoom,
      tileBytes: extracted.header.tileDataLength,
    },
    sourceZooms: extracted.sourceManifest?.sourceZooms ?? options.sourceZooms,
    sourceLayers: extracted.sourceManifest?.sourceLayers ?? options.layers,
    bounds: extracted.sourceManifest ? extracted.sourceManifest.bounds : options.bounds,
    extractionStats: extracted.stats,
    osmDate: extracted.metadata?.osm_date,
  };
  const manifestBytes = TEXT_ENCODER.encode(`${JSON.stringify(manifest, null, 2)}\n`);
  const { cid: manifestCid, size: manifestSize } = await tree.putFile(manifestBytes);

  let root = (await tree.putDirectory([])).cid;
  root = await tree.setEntry(root, [], 'root.json', manifestCid, manifestSize, LinkType.Blob);
  if (searchBuilt.root) root = await tree.setEntry(root, [], '.search', searchBuilt.root, 0, LinkType.Dir);
  if (byIdBuilt.root) root = await tree.setEntry(root, [], '.by-id', byIdBuilt.root, 0, LinkType.Dir);

  return { store, tree, root, manifest, recordCount };
}

async function readVerificationRecord(tree, manifest, link) {
  const data = await tree.readFile(link.cid);
  if (!data) return null;
  const parsed = JSON.parse(TEXT_DECODER.decode(data));
  if (manifest.recordPacking?.kind !== 'json-record-shard') {
    return parsed;
  }
  if (!link.id || !Array.isArray(parsed.records)) return null;
  return parsed.records.find((record) => record?.id === link.id) ?? null;
}

async function verifyIndex({ tree, store, manifest }, queries) {
  const searchIndex = new SearchIndex(store, manifest.searchOptions);
  const searchRoot = deserializeCid(manifest.searchRoot);
  const verified = [];
  for (const query of queries) {
    const results = await searchIndex.searchLinks(searchRoot, manifest.prefix, query, {
      limit: 5,
      scanLimit: 40,
    });
    if (results.length === 0) {
      throw new Error(`Built map search index did not return results for ${query}`);
    }
    const record = await readVerificationRecord(tree, manifest, results[0]);
    if (!record?.name) {
      throw new Error(`Built map search index returned unreadable record for ${query}`);
    }
    verified.push({ query, first: record });
  }
  return verified;
}

function createBlossomStore(servers, signerSecret) {
  return new BlossomStore({
    servers,
    signer: async (template) => finalizeEvent(template, signerSecret),
  });
}

function batchUploadHashListDigest(hashHexes) {
  const hasher = crypto.createHash('sha256');
  hasher.update(BATCH_UPLOAD_DIGEST_PREFIX);
  for (const hashHex of hashHexes) {
    if (!/^[0-9a-f]{64}$/i.test(hashHex)) {
      throw new Error(`Invalid batch blob hash: ${hashHex}`);
    }
    hasher.update(Buffer.from(hashHex, 'hex'));
  }
  return hasher.digest('hex');
}

function createBatchUploadAuthHeader(hashHexes, signerSecret) {
  const now = Math.floor(Date.now() / 1000);
  const event = finalizeEvent({
    kind: BLOSSOM_AUTH_KIND,
    created_at: now,
    content: 'Upload',
    tags: [
      ['t', 'upload'],
      [BATCH_UPLOAD_HASH_LIST_AUTH_TAG, batchUploadHashListDigest(hashHexes)],
      ['expiration', String(now + 300)],
    ],
  }, signerSecret);
  return `Nostr ${Buffer.from(JSON.stringify(event), 'utf8').toString('base64')}`;
}

function encodeBinaryBatchUpload(batch) {
  const totalBytes = batch.reduce((total, block) => total + block.data.length, 0);
  const body = Buffer.allocUnsafe(BINARY_BATCH_UPLOAD_MAGIC.length + 4 + batch.length * (32 + 2 + 8) + totalBytes);
  let offset = 0;
  BINARY_BATCH_UPLOAD_MAGIC.copy(body, offset);
  offset += BINARY_BATCH_UPLOAD_MAGIC.length;
  body.writeUInt32BE(batch.length, offset);
  offset += 4;

  for (const block of batch) {
    const hashHex = toHex(block.hash);
    Buffer.from(hashHex, 'hex').copy(body, offset);
    offset += 32;
    body.writeUInt16BE(0, offset);
    offset += 2;
    body.writeBigUInt64BE(BigInt(block.data.length), offset);
    offset += 8;
    Buffer.from(block.data).copy(body, offset);
    offset += block.data.length;
  }
  return body;
}

function isRetryableUploadStatus(status) {
  return status === 408 || status === 409 || status === 425 || status === 429 || status >= 500;
}

async function postBinaryBatchUpload(serverUrl, batch, signerSecret, options) {
  const hashHexes = batch.map((block) => toHex(block.hash));
  const body = encodeBinaryBatchUpload(batch);
  const url = `${serverUrl.replace(/\/+$/, '')}/upload/batch-binary`;
  let lastError = null;

  for (let attempt = 0; attempt <= options.batchRetries; attempt += 1) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        signal: AbortSignal.timeout(options.batchTimeoutMs),
        headers: {
          Authorization: createBatchUploadAuthHeader(hashHexes, signerSecret),
          'Content-Type': BATCH_UPLOAD_BINARY_CONTENT_TYPE,
        },
        body,
      });
      if (response.status === 404 || response.status === 405 || response.status === 501) {
        throw new Error(`${serverUrl}: batch upload is not supported (${response.status})`);
      }
      if (!response.ok) {
        const reason = response.headers.get('x-reason');
        const text = await response.text().catch(() => '');
        const detail = reason || text || response.statusText;
        const error = new Error(`${serverUrl}: batch upload failed ${response.status} ${detail}`.trim());
        if (attempt < options.batchRetries && isRetryableUploadStatus(response.status)) {
          lastError = error;
          await sleep(options.retryDelayMs * (attempt + 1));
          continue;
        }
        throw error;
      }
      const parsed = await response.json();
      const accepted = Array.isArray(parsed?.blobs) ? parsed.blobs.length : batch.length;
      const uploaded = Number.isFinite(parsed?.uploaded) ? parsed.uploaded : accepted;
      return { accepted, uploaded };
    } catch (error) {
      lastError = error;
      if (attempt >= options.batchRetries) break;
      await sleep(options.retryDelayMs * (attempt + 1));
    }
  }

  throw lastError ?? new Error(`${serverUrl}: batch upload failed`);
}

async function uploadBatchToWriteServers(writeServers, batch, signerSecret, options) {
  const results = await Promise.allSettled(
    writeServers.map((server) => postBinaryBatchUpload(server.url, batch, signerSecret, options)),
  );
  const successes = results.filter((result) => result.status === 'fulfilled');
  if (successes.length === 0) {
    const first = results.find((result) => result.status === 'rejected');
    throw new Error(first?.reason instanceof Error ? first.reason.message : String(first?.reason ?? 'batch upload failed'));
  }
  return successes.reduce((best, result) => {
    if (!best || result.value.uploaded > best.uploaded) return result.value;
    return best;
  }, null);
}

async function uploadTreeBlocksBatch(tree, rootCid, blossomServers, options) {
  const writeServers = blossomServers.filter((server) => server.write);
  if (writeServers.length === 0) {
    throw new Error('No write-enabled Blossom server configured');
  }

  let processed = 0;
  let pushed = 0;
  let skipped = 0;
  let failed = 0;
  let bytes = 0;
  let batchRequests = 0;
  let nextProgress = 50000;
  const errors = [];
  const inFlight = new Set();
  const startedAt = Date.now();
  const signerSecret = options.uploadKey;

  function logProgress(force = false) {
    if (!force && processed < nextProgress) return;
    while (processed >= nextProgress) nextProgress += 50000;
    const elapsed = Math.max(1, (Date.now() - startedAt) / 1000);
    const mib = bytes / 1024 / 1024;
    console.error(`push progress blocks=${processed} pushed=${pushed} skipped=${skipped} failed=${failed} batches=${batchRequests} rate=${(processed / elapsed).toFixed(1)} blocks/s dataRate=${(mib / elapsed).toFixed(1)} MiB/s`);
  }

  async function uploadBatch(batch) {
    const batchBytes = batch.reduce((total, block) => total + block.data.length, 0);
    try {
      batchRequests += 1;
      const result = await uploadBatchToWriteServers(writeServers, batch, signerSecret, options);
      pushed += result.uploaded;
      skipped += Math.max(0, result.accepted - result.uploaded);
      bytes += batchBytes;
    } catch (error) {
      failed += batch.length;
      if (errors.length < 50) {
        errors.push({
          firstHash: toHex(batch[0].hash),
          count: batch.length,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    } finally {
      processed += batch.length;
      logProgress();
    }
  }

  async function schedule(batch) {
    const pending = uploadBatch(batch).finally(() => inFlight.delete(pending));
    inFlight.add(pending);
    if (inFlight.size >= options.batchConcurrency) {
      await Promise.race(inFlight);
    }
  }

  let batch = [];
  let batchBytes = 0;
  for await (const block of tree.walkBlocks(rootCid)) {
    const blockBytes = block.data.length;
    if (
      batch.length > 0
      && (batch.length >= options.batchMaxBlobs || batchBytes + blockBytes > options.batchMaxBytes)
    ) {
      await schedule(batch);
      batch = [];
      batchBytes = 0;
    }
    batch.push(block);
    batchBytes += blockBytes;
  }
  if (batch.length > 0) {
    await schedule(batch);
  }
  await Promise.all(inFlight);
  logProgress(true);
  return { processed, pushed, skipped, failed, bytes, errors, batchRequests };
}

async function uploadTreeBlocks(tree, rootCid, blossomStore, options) {
  let processed = 0;
  let pushed = 0;
  let skipped = 0;
  let failed = 0;
  let bytes = 0;
  const errors = [];
  const inFlight = new Set();
  const startedAt = Date.now();

  async function uploadBlock(block) {
    const hashHex = toHex(block.hash);
    try {
      if (options.checkExisting && await blossomStore.has(block.hash)) {
        skipped += 1;
      } else {
        const stored = await blossomStore.put(block.hash, block.data, 'application/octet-stream');
        if (stored === false) skipped += 1;
        else {
          pushed += 1;
          bytes += block.data.length;
        }
      }
    } catch (error) {
      failed += 1;
      if (errors.length < 50) {
        errors.push({ hash: hashHex, error: error instanceof Error ? error.message : String(error) });
      }
    } finally {
      processed += 1;
      if (processed % 1000 === 0) {
        const elapsed = Math.max(1, (Date.now() - startedAt) / 1000);
        console.error(`push progress blocks=${processed} pushed=${pushed} skipped=${skipped} failed=${failed} rate=${(processed / elapsed).toFixed(1)} blocks/s`);
      }
    }
  }

  for await (const block of tree.walkBlocks(rootCid)) {
    const pending = uploadBlock(block).finally(() => inFlight.delete(pending));
    inFlight.add(pending);
    if (inFlight.size >= options.pushConcurrency) {
      await Promise.race(inFlight);
    }
  }
  await Promise.all(inFlight);
  return { processed, pushed, skipped, failed, bytes, errors };
}

async function publishRoot(refName, rootCid) {
  const args = ['publish'];
  if (rootCid.key) args.push('--key', toHex(rootCid.key));
  args.push(refName, toHex(rootCid.hash));
  const { stdout, stderr } = await execFileAsync('htree', args, { maxBuffer: 1024 * 1024 * 4 });
  return `${stdout}${stderr}`.trim();
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return;
  }
  if (!options.skipPublish) options.uploadKey = await loadUploadKey(options.uploadKeyFile);

  const outDir = path.resolve(options.out);
  await fs.mkdir(outDir, { recursive: true });
  console.error(`PMTiles URL: ${options.pmtilesUrl}`);
  console.error(`Source zooms: ${options.sourceZooms.join(',')}`);
  console.error(`Layers: ${options.layers.join(',')}`);
  console.error(`Address sidecars: ${options.addressSidecars ? `enabled zoom=${options.addressZoom} joinRadiusMeters=${options.addressJoinRadiusMeters}` : 'disabled'}`);

  const extracted = options.buildFromRecordRuns
    ? await loadExtractedRecordRuns(options)
    : await extractRecords(options);
  console.error(`record runs=${extracted.recordRuns.length} address runs=${extracted.addressRuns?.length ?? 0} candidates=${extracted.stats.recordCandidates ?? 'existing'} elapsedMs=${extracted.stats.elapsedMs}`);
  const built = await buildIndex(options, extracted);
  const verified = await verifyIndex(built, options.verifyQueries);
  const rootNhash = nhashEncode(built.root);

  const result = {
    outputDir: outDir,
    blockStore: options.blockStore,
    runDir: options.runDir,
    recordRunDir: options.recordRunDir,
    addressRunDir: options.addressRunDir,
    publishRef: options.skipPublish || options.skipRefPublish ? null : options.publishRef,
    root: {
      hash: toHex(built.root.hash),
      key: built.root.key ? toHex(built.root.key) : undefined,
      nhash: rootNhash,
      immutableUrl: `htree://${rootNhash}/root.json`,
    },
    manifest: built.manifest,
    verified,
    push: null,
    publish: null,
  };

  await fs.writeFile(path.join(outDir, 'root.json'), `${JSON.stringify(built.manifest, null, 2)}\n`, 'utf8');
  await fs.writeFile(path.join(outDir, 'publish-result.json'), `${JSON.stringify(result, null, 2)}\n`, 'utf8');

  if (!options.skipPublish) {
    const blossomServers = parseBlossomServers(options.blossomServers, options.blossomWriteServers);
    const uploadTree = new HashTree({ store: verifiedBlockStore(built.store) });
    console.error(`Uploading index blocks to: ${blossomServers.map((server) => `${server.url}(r=${server.read},w=${server.write})`).join(', ')}`);
    result.push = options.batchUpload
      ? await uploadTreeBlocksBatch(uploadTree, built.root, blossomServers, options)
      : await uploadTreeBlocks(uploadTree, built.root, createBlossomStore(blossomServers, options.uploadKey), options);
    if (result.push.failed > 0) {
      await fs.writeFile(path.join(outDir, 'publish-result.json'), `${JSON.stringify(result, null, 2)}\n`, 'utf8');
      throw new Error(`Failed to upload ${result.push.failed} map search index blocks`);
    }
    if (!options.skipRefPublish) {
      result.publish = await publishRoot(options.publishRef, built.root);
    }
  }

  await fs.writeFile(path.join(outDir, 'publish-result.json'), `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  console.log(JSON.stringify(result, null, 2));
}

export { FileBlockStore, buildIndex, parseArgs, verifyIndex };

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.stack ?? error.message : error);
    process.exit(1);
  });
}
