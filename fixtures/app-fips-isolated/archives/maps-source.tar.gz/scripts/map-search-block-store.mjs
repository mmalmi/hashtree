import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { objectKeyFromHex, toHex } from '@hashtree/core';

export function deserializeCid(value) {
  if (value == null) return null;
  if (typeof value.hash !== 'string' || !/^[0-9a-f]{64}$/i.test(value.hash)) throw new Error('Invalid search index hash');
  return {
    hash: Buffer.from(value.hash, 'hex'),
    ...(value.key == null ? {} : { key: objectKeyFromHex(value.key) }),
  };
}

// Older tree walkers tolerate absent blocks. Exports and uploads must fail
// instead of announcing a tree whose descendants cannot be read.
export function verifiedBlockStore(source) {
  return {
    async get(hash) {
      const data = await source.get(hash);
      if (!data || crypto.createHash('sha256').update(data).digest('hex') !== toHex(hash)) {
        throw new Error(`Missing or corrupt source block ${toHex(hash)}`);
      }
      return data;
    },
  };
}

export class FileBlockStore {
  constructor(rootDir) {
    this.rootDir = rootDir;
  }

  pathFor(hash) {
    const hex = toHex(hash);
    return path.join(this.rootDir, hex.slice(0, 2), hex.slice(2, 4), hex);
  }

  async get(hash) {
    try {
      return await fs.readFile(this.pathFor(hash));
    } catch (error) {
      if (error?.code === 'ENOENT') return null;
      throw error;
    }
  }

  async put(hash, data) {
    const filePath = this.pathFor(hash);
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    try {
      await fs.access(filePath);
      return false;
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
    const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
    await fs.writeFile(tmpPath, data);
    await fs.rename(tmpPath, filePath).catch(async (error) => {
      await fs.rm(tmpPath, { force: true }).catch(() => {});
      if (error?.code === 'EEXIST') return false;
      throw error;
    });
    return true;
  }

  async has(hash) {
    try {
      await fs.access(this.pathFor(hash));
      return true;
    } catch (error) {
      if (error?.code === 'ENOENT') return false;
      throw error;
    }
  }

  async delete(hash) {
    try {
      await fs.rm(this.pathFor(hash));
      return true;
    } catch (error) {
      if (error?.code === 'ENOENT') return false;
      throw error;
    }
  }
}
