#!/usr/bin/env node
import { execFile } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { finalizeEvent } from 'nostr-tools/pure';
import { deserializeCid } from './map-search-block-store.mjs';
import { loadUploadKey } from './map-search-upload-key.mjs';
import { BTree, SearchIndex } from '@hashtree/index';
import { BlossomStore, HashTree, LinkType, MemoryStore, nhashEncode, toHex } from '@hashtree/core';

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_OUT_DIR = path.join(os.tmpdir(), `iris-maps-search-index-${Date.now()}`);
const DEFAULT_PUBLISH_REF = 'maps-search-natural-earth-v1';
const DEFAULT_BLOSSOM_SERVER_URLS = 'https://cdn.iris.to';
const DEFAULT_BLOSSOM_WRITE_SERVER_URLS = 'https://upload.iris.to';
const SEARCH_PREFIX = 'p:';
const SEARCH_INDEX_VERSION = 1;

function parseArgs(argv) {
  const options = {
    out: DEFAULT_OUT_DIR,
    labels: '',
    publishRef: DEFAULT_PUBLISH_REF,
    skipPublish: false,
    forceLabelDownload: false,
    blossomServers: process.env.BLOSSOM_SERVERS ?? DEFAULT_BLOSSOM_SERVER_URLS,
    blossomWriteServers: process.env.BLOSSOM_WRITE_SERVERS ?? DEFAULT_BLOSSOM_WRITE_SERVER_URLS,
    pushConcurrency: Math.max(1, Number.parseInt(process.env.PUSH_CONCURRENCY ?? '64', 10) || 64),
    checkExisting: false,
  };

  const args = [...argv];
  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '--out') {
      options.out = args.shift() ?? '';
      continue;
    }
    if (arg === '--labels') {
      options.labels = args.shift() ?? '';
      continue;
    }
    if (arg === '--publish-ref') {
      options.publishRef = args.shift() ?? '';
      continue;
    }
    if (arg === '--skip-publish') {
      options.skipPublish = true;
      continue;
    }
    if (arg === '--skip-ref-publish') {
      options.skipRefPublish = true;
      continue;
    }
    if (arg === '--force-label-download') {
      options.forceLabelDownload = true;
      continue;
    }
    if (arg === '--blossom-servers') {
      options.blossomServers = args.shift() ?? '';
      continue;
    }
    if (arg === '--blossom-write-servers') {
      options.blossomWriteServers = args.shift() ?? '';
      continue;
    }
    if (arg === '--upload-key-file') {
      options.uploadKeyFile = args.shift() ?? '';
      continue;
    }
    if (arg === '--push-concurrency') {
      options.pushConcurrency = Math.max(1, Number.parseInt(args.shift() ?? '', 10) || options.pushConcurrency);
      continue;
    }
    if (arg === '--check-existing') {
      options.checkExisting = true;
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  if (!options.out) throw new Error('--out requires a path');
  if (!options.publishRef && !options.skipPublish) throw new Error('--publish-ref requires a value');
  return options;
}

function parseServerList(value) {
  return `${value ?? ''}`
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function normalizeServerUrl(url) {
  try {
    const parsed = new URL(url);
    parsed.hash = '';
    parsed.search = '';
    parsed.pathname = parsed.pathname.replace(/\/+$/, '');
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return `${url ?? ''}`.trim().replace(/\/+$/, '');
  }
}

function isWriteEndpoint(url) {
  try {
    return new URL(url).hostname === 'upload.iris.to';
  } catch {
    return /\bupload\.iris\.to\b/.test(`${url ?? ''}`);
  }
}

function parseBlossomServers(readValue, writeValue) {
  const explicitWriteServerUrls = parseServerList(writeValue);
  const explicitWriteServers = new Set(explicitWriteServerUrls.map(normalizeServerUrl));
  const readServers = parseServerList(readValue).map((url) => ({
    url: normalizeServerUrl(url),
    read: true,
    write: isWriteEndpoint(url) || explicitWriteServers.has(normalizeServerUrl(url)),
  }));
  const seen = new Set(readServers.map((server) => normalizeServerUrl(server.url)));
  const writeOnlyServers = explicitWriteServerUrls
    .filter((url) => !seen.has(normalizeServerUrl(url)))
    .map((url) => ({
      url: normalizeServerUrl(url),
      read: false,
      write: true,
    }));
  return [...readServers, ...writeOnlyServers];
}

function numberValue(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function normalizeText(value) {
  return `${value ?? ''}`
    .toLowerCase()
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

function slugify(value) {
  return normalizeText(value)
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || 'place';
}

function serializeCid(cid) {
  if (!cid?.hash) return null;
  return {
    hash: toHex(cid.hash),
    ...(cid.key ? { key: toHex(cid.key) } : {}),
  };
}

function buildPlaceId(label) {
  return [
    label.kind === 'country' ? 'country' : 'place',
    slugify(label.name),
    Number(label.lat).toFixed(5),
    Number(label.lng).toFixed(5),
  ].join(':');
}

function labelToSearchResult(label) {
  const isCountry = label.kind === 'country';
  const populationImportance = label.population
    ? Math.min(1, Math.log10(Math.max(10, label.population)) / 8)
    : 0;
  return {
    id: buildPlaceId(label),
    name: label.name,
    lat: label.lat,
    lng: label.lng,
    type: isCountry ? 'country' : 'city',
    class: isCountry ? 'boundary' : 'place',
    displayName: isCountry ? 'Country' : 'City',
    placeRank: isCountry ? 4 : 16,
    importance: isCountry ? 1 : populationImportance,
    addressType: isCountry ? 'country' : 'city',
    ...(numberValue(label.population) ? { population: numberValue(label.population) } : {}),
  };
}

function extractSingleCharacterTerms(text) {
  const terms = [];
  const seen = new Set();
  for (const rawWord of `${text ?? ''}`.split(/[^\p{L}\p{N}]+/u)) {
    const normalized = normalizeText(rawWord);
    if (normalized.length === 1 && !/^\d$/u.test(normalized) && !seen.has(normalized)) {
      seen.add(normalized);
      terms.push(normalized);
    }
  }
  return terms;
}

function buildSearchTerms(searchIndex, record) {
  const text = [
    record.name,
    record.addressType === 'country' ? record.name : '',
  ].filter(Boolean).join(' ');
  const terms = searchIndex.parseKeywords(text);
  const seen = new Set(terms);
  for (const term of extractSingleCharacterTerms(text)) {
    if (!seen.has(term)) {
      seen.add(term);
      terms.push(term);
    }
  }
  return terms;
}

async function ensureLabels(options) {
  if (options.labels) {
    return path.resolve(options.labels);
  }

  const labelsOut = path.join(path.resolve(options.out), 'source-labels');
  const args = [
    path.join(__dirname, 'build-map-label-dataset.mjs'),
    '--out',
    labelsOut,
  ];
  if (options.forceLabelDownload) {
    args.push('--force-download');
  }
  await execFileAsync(process.execPath, args, { maxBuffer: 1024 * 1024 * 32 });
  return path.join(labelsOut, 'labels', 'overview.json');
}

async function loadLabels(labelsPath) {
  const dataset = JSON.parse(await readFile(labelsPath, 'utf8'));
  if (dataset.kind !== 'iris-maps-labels' || !Array.isArray(dataset.labels)) {
    throw new Error(`Invalid map label dataset: ${labelsPath}`);
  }
  return dataset;
}

async function buildIndex(labelsDataset) {
  const store = new MemoryStore();
  const tree = new HashTree({ store });
  const searchIndex = new SearchIndex(store, { order: 64, minKeywordLength: 1 });
  const byIdIndex = new BTree(store, { order: 64 });
  const encoder = new TextEncoder();
  const records = [];
  const byIdEntries = [];
  const searchEntries = [];

  const labels = labelsDataset.labels
    .map((label) => ({
      ...label,
      lat: numberValue(label.lat),
      lng: numberValue(label.lng),
    }))
    .filter((label) => label.name && Number.isFinite(label.lat) && Number.isFinite(label.lng));

  for (const label of labels) {
    const record = labelToSearchResult(label);
    const bytes = encoder.encode(`${JSON.stringify(record)}\n`);
    const { cid: recordCid } = await tree.putFile(bytes);
    records.push(record);
    byIdEntries.push([record.id, recordCid]);
    for (const term of buildSearchTerms(searchIndex, record)) {
      searchEntries.push([`${SEARCH_PREFIX}${term}:${record.id}`, recordCid]);
    }
  }

  const byIdRoot = await byIdIndex.buildLinks(byIdEntries);
  const searchRoot = await searchIndex.buildLinks(searchEntries);
  const generatedAt = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
  const manifest = {
    version: 1,
    kind: 'iris-maps-place-search-index',
    generatedAt,
    source: 'Natural Earth public-domain country and populated-place data.',
    attribution: labelsDataset.attribution ?? 'Natural Earth public-domain map label data.',
    placeCount: records.length,
    searchIndexVersion: SEARCH_INDEX_VERSION,
    prefix: SEARCH_PREFIX,
    searchRoot: serializeCid(searchRoot),
    byIdRoot: serializeCid(byIdRoot),
    searchOptions: { order: 64, minKeywordLength: 1 },
    sources: labelsDataset.sources ?? undefined,
  };
  const manifestBytes = encoder.encode(`${JSON.stringify(manifest, null, 2)}\n`);
  const { cid: manifestCid, size: manifestSize } = await tree.putFile(manifestBytes);

  let root = (await tree.putDirectory([])).cid;
  root = await tree.setEntry(root, [], 'root.json', manifestCid, manifestSize, LinkType.Blob);
  if (searchRoot) {
    root = await tree.setEntry(root, [], '.search', searchRoot, 0, LinkType.Dir);
  }
  if (byIdRoot) {
    root = await tree.setEntry(root, [], '.by-id', byIdRoot, 0, LinkType.Dir);
  }

  return { store, tree, root, manifest, records };
}

async function verifyIndex({ store, tree, manifest }) {
  const searchIndex = new SearchIndex(store, manifest.searchOptions);
  const searchRoot = deserializeCid(manifest.searchRoot);
  const results = await searchIndex.searchLinks(searchRoot, manifest.prefix, 'Helsinki', {
    limit: 5,
    scanLimit: 20,
  });
  if (results.length === 0) {
    throw new Error('Built map search index did not return Helsinki');
  }
  const data = await tree.readFile(results[0].cid);
  const record = data ? JSON.parse(new TextDecoder().decode(data)) : null;
  if (!record || record.name !== 'Helsinki') {
    throw new Error(`Built map search index returned unexpected first record: ${record?.name ?? 'null'}`);
  }
  return record;
}

async function collectBlocks(tree, rootCid) {
  const blocks = [];
  for await (const block of tree.walkBlocks(rootCid)) {
    blocks.push(block);
  }
  return blocks;
}

async function uploadBlocks(blocks, blossomStore, concurrency, options = {}) {
  let nextIndex = 0;
  let processed = 0;
  let pushed = 0;
  let skipped = 0;
  let failed = 0;
  let bytes = 0;
  const errors = [];

  async function worker() {
    while (nextIndex < blocks.length) {
      const index = nextIndex;
      nextIndex += 1;
      const block = blocks[index];
      const hashHex = toHex(block.hash);
      try {
        if (options.checkExisting === true && await blossomStore.has(block.hash)) {
          skipped += 1;
        } else {
          const stored = await blossomStore.put(block.hash, block.data, 'application/octet-stream');
          if (stored === false) {
            skipped += 1;
          } else {
            pushed += 1;
            bytes += block.data.length;
          }
        }
      } catch (error) {
        failed += 1;
        errors.push({
          hash: hashHex,
          error: error instanceof Error ? error.message : String(error),
        });
      } finally {
        processed += 1;
        if (processed === blocks.length || processed % 100 === 0) {
          console.error(`push progress ${processed}/${blocks.length} pushed=${pushed} skipped=${skipped} failed=${failed}`);
        }
      }
    }
  }

  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  return { pushed, skipped, failed, bytes, errors };
}

function createBlossomStore(servers, signerSecret) {
  return new BlossomStore({
    servers,
    signer: async (template) => finalizeEvent(template, signerSecret),
  });
}

async function publishRoot(refName, rootCid) {
  const args = ['publish'];
  if (rootCid.key) {
    args.push('--key', toHex(rootCid.key));
  }
  args.push(refName, toHex(rootCid.hash));
  const { stdout, stderr } = await execFileAsync('htree', args, { maxBuffer: 1024 * 1024 * 4 });
  return `${stdout}${stderr}`.trim();
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const uploadKey = options.skipPublish ? null : await loadUploadKey(options.uploadKeyFile);
  const outDir = path.resolve(options.out);
  await mkdir(outDir, { recursive: true });

  const labelsPath = await ensureLabels(options);
  const labelsDataset = await loadLabels(labelsPath);
  const built = await buildIndex(labelsDataset);
  const verifiedRecord = await verifyIndex(built);
  const rootNhash = nhashEncode(built.root);
  const blocks = await collectBlocks(built.tree, built.root);

  let push = null;
  let publish = null;
  if (!options.skipPublish) {
    const blossomServers = parseBlossomServers(options.blossomServers, options.blossomWriteServers);
    const blossomStore = createBlossomStore(blossomServers, uploadKey);
    push = await uploadBlocks(blocks, blossomStore, options.pushConcurrency, {
      checkExisting: options.checkExisting,
    });
    if (push.failed > 0) {
      throw new Error(`Failed to upload ${push.failed} map search index blocks`);
    }
    if (!options.skipRefPublish) publish = await publishRoot(options.publishRef, built.root);
  }

  const result = {
    labelsPath,
    outputDir: outDir,
    publishRef: options.skipPublish || options.skipRefPublish ? null : options.publishRef,
    root: {
      hash: toHex(built.root.hash),
      key: built.root.key ? toHex(built.root.key) : undefined,
      nhash: rootNhash,
      immutableUrl: `htree://${rootNhash}/root.json`,
    },
    manifest: built.manifest,
    blocks: {
      count: blocks.length,
      bytes: blocks.reduce((sum, block) => sum + block.data.length, 0),
    },
    verifiedRecord,
    push,
    publish,
  };

  await writeFile(path.join(outDir, 'root.json'), `${JSON.stringify(built.manifest, null, 2)}\n`, 'utf8');
  await writeFile(path.join(outDir, 'publish-result.json'), `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack ?? error.message : error);
  process.exit(1);
});
