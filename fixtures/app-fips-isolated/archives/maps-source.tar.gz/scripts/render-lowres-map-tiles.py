#!/usr/bin/env python3
"""Render a tiny public-domain starter basemap tile set.

The output is intentionally outside the repo by default. It is meant to be
published as a standalone hashtree dataset, not committed.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import tempfile
import urllib.request

from PIL import Image, ImageDraw


TILE_SIZE = 256
MAX_MERCATOR_LAT = 85.05112878
USER_AGENT = "IrisMapsTileSeeder/0.1 (+https://maps.iris.to)"

SOURCES = {
    "land": {
        "url": "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_land.geojson",
        "filename": "ne_110m_land.geojson",
    },
    "countries": {
        "url": "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson",
        "filename": "ne_110m_admin_0_countries.geojson",
    },
    "lakes": {
        "url": "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_lakes.geojson",
        "filename": "ne_110m_lakes.geojson",
    },
    "rivers": {
        "url": "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_rivers_lake_centerlines.geojson",
        "filename": "ne_110m_rivers_lake_centerlines.geojson",
    },
}

COLORS = {
    "ocean": "#9fc7d8",
    "land": "#eadfc4",
    "land_outline": "#cabf9f",
    "country": "#9d9374",
    "lake": "#8fc0d3",
    "river": "#6ba5bd",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default=None, help="output directory (default: temporary directory)")
    parser.add_argument("--min-zoom", type=int, default=0)
    parser.add_argument("--max-zoom", type=int, default=2)
    parser.add_argument("--scale", type=int, default=3, help="anti-alias render scale")
    parser.add_argument("--force-download", action="store_true")
    return parser.parse_args()


def fetch_source(url: str, destination: Path, force: bool) -> None:
    if destination.exists() and not force:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        destination.write_bytes(response.read())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_geojson(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)["features"]


def clamp_lat(lat: float) -> float:
    return max(-MAX_MERCATOR_LAT, min(MAX_MERCATOR_LAT, lat))


def lon_lat_to_world_px(lon: float, lat: float, zoom: int) -> tuple[float, float]:
    world_size = TILE_SIZE * (2**zoom)
    x = (lon + 180.0) / 360.0 * world_size
    sin_lat = math.sin(math.radians(clamp_lat(lat)))
    y = (0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * world_size
    return x, y


def local_point(coord: list[float], zoom: int, tile_x: int, tile_y: int, scale: int) -> tuple[float, float]:
    world_x, world_y = lon_lat_to_world_px(float(coord[0]), float(coord[1]), zoom)
    return (world_x - tile_x * TILE_SIZE) * scale, (world_y - tile_y * TILE_SIZE) * scale


def iter_polygon_rings(geometry: dict):
    kind = geometry.get("type")
    coords = geometry.get("coordinates", [])
    if kind == "Polygon":
        yield coords
    elif kind == "MultiPolygon":
        for polygon in coords:
            yield polygon


def iter_lines(geometry: dict):
    kind = geometry.get("type")
    coords = geometry.get("coordinates", [])
    if kind == "LineString":
        yield coords
    elif kind == "MultiLineString":
        for line in coords:
            yield line


def draw_polygon_layer(
    draw: ImageDraw.ImageDraw,
    features: list[dict],
    zoom: int,
    tile_x: int,
    tile_y: int,
    scale: int,
    fill: str,
    outline: str | None = None,
    hole_fill: str | None = None,
) -> None:
    width = max(1, scale)
    for feature in features:
        geometry = feature.get("geometry") or {}
        for rings in iter_polygon_rings(geometry):
            if not rings:
                continue
            exterior = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in rings[0]]
            if len(exterior) >= 3:
                draw.polygon(exterior, fill=fill)
                if outline:
                    draw.line(exterior + [exterior[0]], fill=outline, width=width)
            if hole_fill:
                for hole in rings[1:]:
                    points = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in hole]
                    if len(points) >= 3:
                        draw.polygon(points, fill=hole_fill)


def draw_polygon_outlines(
    draw: ImageDraw.ImageDraw,
    features: list[dict],
    zoom: int,
    tile_x: int,
    tile_y: int,
    scale: int,
    color: str,
) -> None:
    width = max(1, scale)
    for feature in features:
        geometry = feature.get("geometry") or {}
        for rings in iter_polygon_rings(geometry):
            if not rings:
                continue
            exterior = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in rings[0]]
            if len(exterior) >= 2:
                draw.line(exterior + [exterior[0]], fill=color, width=width)


def draw_line_layer(
    draw: ImageDraw.ImageDraw,
    features: list[dict],
    zoom: int,
    tile_x: int,
    tile_y: int,
    scale: int,
    color: str,
) -> None:
    width = max(1, round(0.75 * scale))
    for feature in features:
        geometry = feature.get("geometry") or {}
        for line in iter_lines(geometry):
            points = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in line]
            if len(points) >= 2:
                draw.line(points, fill=color, width=width)


def render_tile(layers: dict[str, list[dict]], zoom: int, tile_x: int, tile_y: int, scale: int) -> Image.Image:
    size = TILE_SIZE * scale
    image = Image.new("RGB", (size, size), COLORS["ocean"])
    draw = ImageDraw.Draw(image)
    draw_polygon_layer(
        draw,
        layers["land"],
        zoom,
        tile_x,
        tile_y,
        scale,
        fill=COLORS["land"],
        outline=COLORS["land_outline"],
        hole_fill=COLORS["ocean"],
    )
    draw_polygon_layer(
        draw,
        layers["lakes"],
        zoom,
        tile_x,
        tile_y,
        scale,
        fill=COLORS["lake"],
        outline=COLORS["river"],
    )
    draw_line_layer(draw, layers["rivers"], zoom, tile_x, tile_y, scale, COLORS["river"])
    draw_polygon_outlines(draw, layers["countries"], zoom, tile_x, tile_y, scale, COLORS["country"])
    return image.resize((TILE_SIZE, TILE_SIZE), Image.Resampling.LANCZOS)


def main() -> None:
    args = parse_args()
    if args.min_zoom < 0 or args.max_zoom < args.min_zoom:
        raise SystemExit("--max-zoom must be >= --min-zoom >= 0")
    if args.scale < 1:
        raise SystemExit("--scale must be >= 1")

    out_dir = Path(args.out) if args.out else Path(tempfile.mkdtemp(prefix="iris-maps-lowres-"))
    source_dir = out_dir / "sources"
    tiles_dir = out_dir / "tiles"
    source_files: dict[str, Path] = {}

    for name, source in SOURCES.items():
        path = source_dir / source["filename"]
        fetch_source(source["url"], path, args.force_download)
        source_files[name] = path

    layers = {name: load_geojson(path) for name, path in source_files.items()}
    rendered = 0
    for zoom in range(args.min_zoom, args.max_zoom + 1):
        count = 2**zoom
        for x in range(count):
            for y in range(count):
                tile = render_tile(layers, zoom, x, y, args.scale)
                tile_path = tiles_dir / str(zoom) / str(x) / f"{y}.png"
                tile_path.parent.mkdir(parents=True, exist_ok=True)
                tile.save(tile_path, format="PNG", optimize=True)
                rendered += 1

    source_manifest = {
        name: {
            "url": SOURCES[name]["url"],
            "sha256": sha256_file(path),
        }
        for name, path in source_files.items()
    }
    manifest = {
        "version": 1,
        "kind": "iris-maps-lowres-raster-tiles",
        "generatedAt": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "tileSize": TILE_SIZE,
        "scheme": "web-mercator",
        "format": "png",
        "minZoom": args.min_zoom,
        "maxZoom": args.max_zoom,
        "tileTemplate": "tiles/{z}/{x}/{y}.png",
        "tileCount": rendered,
        "attribution": "Natural Earth public-domain map data, rendered for Iris Maps.",
        "sources": source_manifest,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Rendered {rendered} tiles to {tiles_dir}")
    print(f"Manifest: {out_dir / 'manifest.json'}")


if __name__ == "__main__":
    main()
