import { readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { decode } from 'nostr-tools/nip19';

export async function loadUploadKey(keyFile = path.join(
  process.env.HTREE_CONFIG_DIR || path.join(os.homedir(), '.hashtree'), 'keys',
)) {
  const value = await readFile(keyFile, 'utf8');
  try {
    const decoded = decode(value.trim());
    if (decoded.type === 'nsec') return decoded.data;
  } catch {
    // Decoder errors may contain key material; never print them.
  }
  throw new Error('Invalid upload signing key; expected an nsec key file');
}
