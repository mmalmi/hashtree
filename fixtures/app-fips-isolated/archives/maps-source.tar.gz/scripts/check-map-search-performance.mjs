#!/usr/bin/env node

import { chromium } from '@playwright/test';

const DEFAULT_QUERIES = ['Helsinki', 'Tokyo', 'New York', 'Hämeentie'];
const DEFAULT_URL = `https://maps.iris.to/?v=${Date.now()}#/`;
const SEARCH_RESULTS_SELECTOR = '[data-testid="search-results"]';
const SEARCH_INPUT_SELECTOR = '[data-testid="search-input"]';

function parseArgs(argv) {
  const options = {
    url: process.env.MAPS_SEARCH_PERF_URL || DEFAULT_URL,
    queries: [...DEFAULT_QUERIES],
    coldBudgetMs: parsePositiveInt(process.env.MAPS_SEARCH_COLD_BUDGET_MS, 6000),
    warmBudgetMs: parsePositiveInt(process.env.MAPS_SEARCH_WARM_BUDGET_MS, 2500),
    headless: process.env.HEADLESS !== '0',
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = argv[i + 1];
    if (arg === '--url' && next) {
      options.url = next;
      i += 1;
    } else if (arg === '--queries' && next) {
      options.queries = next.split(',').map((query) => query.trim()).filter(Boolean);
      i += 1;
    } else if (arg === '--cold-budget-ms' && next) {
      options.coldBudgetMs = parsePositiveInt(next, options.coldBudgetMs);
      i += 1;
    } else if (arg === '--warm-budget-ms' && next) {
      options.warmBudgetMs = parsePositiveInt(next, options.warmBudgetMs);
      i += 1;
    } else if (arg === '--headed') {
      options.headless = false;
    } else if (arg === '--help' || arg === '-h') {
      printHelp();
      process.exit(0);
    } else {
      throw new Error(`Unknown or incomplete argument: ${arg}`);
    }
  }

  if (options.queries.length === 0) {
    throw new Error('At least one query is required');
  }

  return options;
}

function parsePositiveInt(value, fallback) {
  const parsed = Number.parseInt(`${value ?? ''}`, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function printHelp() {
  console.log(`Usage: pnpm run test:search:perf -- [options]

Options:
  --url <url>                App URL to probe (default: ${DEFAULT_URL})
  --queries <a,b,c>          Comma-separated queries (default: ${DEFAULT_QUERIES.join(', ')})
  --cold-budget-ms <ms>      Max first-pass query latency (default: 6000)
  --warm-budget-ms <ms>      Max repeat query latency (default: 2500)
  --headed                   Show the browser
`);
}

async function waitForPerfQuiet(page, options = {}) {
  const timeoutMs = options.timeoutMs ?? 8000;
  const settleMs = options.settleMs ?? 500;
  const deadline = Date.now() + timeoutMs;
  let stableKey = '';
  let stableSince = 0;

  while (Date.now() < deadline) {
    const pulse = await page.evaluate(() => ({
      resourceCount: performance.getEntriesByType('resource').length,
    }));
    const nextKey = `${pulse.resourceCount}`;
    if (nextKey !== stableKey) {
      stableKey = nextKey;
      stableSince = Date.now();
    } else if (Date.now() - stableSince >= settleMs) {
      return;
    }
    await page.waitForTimeout(100);
  }
}

async function resetPerfMetrics(page) {
  await page.evaluate(() => {
    performance.clearResourceTimings();
    performance.setResourceTimingBufferSize(2000);
  });
}

async function readResourceMetrics(page) {
  return await page.evaluate(() => {
    const resources = performance.getEntriesByType('resource')
      .filter((entry) => entry.name && /^https?:/iu.test(entry.name));
    const hashtreeResources = resources.filter((entry) => (
      entry.name.includes('/htree/')
      || entry.name.includes('cdn.iris.to')
      || entry.name.includes('upload.iris.to')
    ));
    const sumBytes = (entries) => entries.reduce((sum, entry) => (
      sum + Math.max(entry.transferSize || 0, entry.encodedBodySize || 0, entry.decodedBodySize || 0)
    ), 0);

    return {
      totalRequests: resources.length,
      totalTransferBytes: sumBytes(resources),
      hashtreeRequests: hashtreeResources.length,
      hashtreeTransferBytes: sumBytes(hashtreeResources),
    };
  });
}

async function probeQuery(page, query, budgetMs) {
  const input = page.locator(SEARCH_INPUT_SELECTOR);
  await resetPerfMetrics(page);
  const startedAt = Date.now();
  await input.fill(query);
  await page.locator(`${SEARCH_RESULTS_SELECTOR} button`, { hasText: query }).first().waitFor({
    state: 'visible',
    timeout: budgetMs,
  });
  const visibleMs = Date.now() - startedAt;
  await waitForPerfQuiet(page);
  const resources = await readResourceMetrics(page);
  return { query, visibleMs, ...resources };
}

async function run() {
  const options = parseArgs(process.argv.slice(2));
  const browser = await chromium.launch({ headless: options.headless });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const fallbackLogs = [];
  const pageErrors = [];

  page.on('console', (message) => {
    const text = message.text();
    if (text.includes('[mapsSearch] Falling back')) {
      fallbackLogs.push(text);
    }
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.message);
  });

  try {
    await page.goto(options.url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.locator(SEARCH_INPUT_SELECTOR).waitFor({ state: 'visible', timeout: 30000 });
    await waitForPerfQuiet(page);

    const cold = [];
    for (const query of options.queries) {
      cold.push(await probeQuery(page, query, options.coldBudgetMs));
    }

    const warm = [];
    for (const query of options.queries) {
      warm.push(await probeQuery(page, query, options.warmBudgetMs));
    }

    const report = {
      url: options.url,
      budgets: {
        coldBudgetMs: options.coldBudgetMs,
        warmBudgetMs: options.warmBudgetMs,
      },
      cold,
      warm,
      fallbackLogs,
      pageErrors,
    };
    console.log(JSON.stringify(report, null, 2));

    const coldSlow = cold.filter((result) => result.visibleMs > options.coldBudgetMs);
    const warmSlow = warm.filter((result) => result.visibleMs > options.warmBudgetMs);
    if (fallbackLogs.length > 0) {
      throw new Error(`Map search fell back instead of using hashtree-index: ${fallbackLogs.join(' | ')}`);
    }
    if (pageErrors.length > 0) {
      throw new Error(`Page errors during map search perf probe: ${pageErrors.join(' | ')}`);
    }
    if (coldSlow.length > 0 || warmSlow.length > 0) {
      throw new Error(`Search perf budget exceeded: ${JSON.stringify({ coldSlow, warmSlow })}`);
    }
  } finally {
    await browser.close();
  }
}

run().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
