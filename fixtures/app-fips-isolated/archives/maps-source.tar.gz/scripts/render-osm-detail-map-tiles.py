#!/usr/bin/env python3
"""Render a bounded OpenStreetMap detail tile set.

This intentionally renders only a configured bounding box. It avoids bulk
downloading public raster tiles and produces a standalone hashtree dataset.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import tempfile
import urllib.parse
import urllib.request

from PIL import Image, ImageDraw, ImageFont


TILE_SIZE = 256
MAX_MERCATOR_LAT = 85.05112878
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
USER_AGENT = "IrisMapsOsmDetailSeeder/0.1 (+https://maps.iris.to)"
DEFAULT_BBOX = "60.05,24.75,60.33,25.20"
LAND_FILL = "#b7b09f"
WATER_FILL = "#79aab8"
PARK_FILL = "#8baa7a"

MAJOR_ROADS = {"motorway", "trunk", "primary", "secondary"}
MID_ROADS = MAJOR_ROADS | {"tertiary", "unclassified"}
MINOR_ROADS = MID_ROADS | {"residential", "living_street", "pedestrian"}
PATH_ROADS = MINOR_ROADS | {"service", "track", "path", "footway", "cycleway", "steps"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default=None, help="output directory (default: temporary directory)")
    parser.add_argument("--bbox", default=DEFAULT_BBOX, help="south,west,north,east")
    parser.add_argument("--min-zoom", type=int, default=6)
    parser.add_argument("--max-zoom", type=int, default=14)
    parser.add_argument("--scale", type=int, default=2, help="anti-alias render scale")
    parser.add_argument("--force-download", action="store_true")
    return parser.parse_args()


def parse_bbox(value: str) -> tuple[float, float, float, float]:
    parts = [float(part.strip()) for part in value.split(",")]
    if len(parts) != 4:
        raise SystemExit("--bbox must be south,west,north,east")
    south, west, north, east = parts
    if south >= north or west >= east:
        raise SystemExit("--bbox must have south<north and west<east")
    return south, west, north, east


def clamp_lat(lat: float) -> float:
    return max(-MAX_MERCATOR_LAT, min(MAX_MERCATOR_LAT, lat))


def lon_lat_to_world_px(lon: float, lat: float, zoom: int) -> tuple[float, float]:
    world_size = TILE_SIZE * (2**zoom)
    x = (lon + 180.0) / 360.0 * world_size
    sin_lat = math.sin(math.radians(clamp_lat(lat)))
    y = (0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * world_size
    return x, y


def bbox_pixel_rect(
    bbox: tuple[float, float, float, float],
    zoom: int,
    tile_x: int,
    tile_y: int,
    scale: int,
) -> tuple[int, int, int, int]:
    south, west, north, east = bbox
    west_x, north_y = lon_lat_to_world_px(west, north, zoom)
    east_x, south_y = lon_lat_to_world_px(east, south, zoom)
    left = math.floor((min(west_x, east_x) - tile_x * TILE_SIZE) * scale)
    right = math.ceil((max(west_x, east_x) - tile_x * TILE_SIZE) * scale)
    top = math.floor((min(north_y, south_y) - tile_y * TILE_SIZE) * scale)
    bottom = math.ceil((max(north_y, south_y) - tile_y * TILE_SIZE) * scale)
    return (
        max(0, left),
        max(0, top),
        min(TILE_SIZE * scale, right),
        min(TILE_SIZE * scale, bottom),
    )


def lon_to_tile_x(lon: float, zoom: int) -> int:
    return math.floor((lon + 180.0) / 360.0 * (2**zoom))


def lat_to_tile_y(lat: float, zoom: int) -> int:
    sin_lat = math.sin(math.radians(clamp_lat(lat)))
    return math.floor((0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * (2**zoom))


def tile_x_to_lon(tile_x: int, zoom: int) -> float:
    return tile_x / (2**zoom) * 360.0 - 180.0


def tile_y_to_lat(tile_y: int, zoom: int) -> float:
    n = math.pi - 2.0 * math.pi * tile_y / (2**zoom)
    return math.degrees(math.atan(math.sinh(n)))


def tile_bounds(tile_x: int, tile_y: int, zoom: int) -> tuple[float, float, float, float]:
    west = tile_x_to_lon(tile_x, zoom)
    east = tile_x_to_lon(tile_x + 1, zoom)
    north = tile_y_to_lat(tile_y, zoom)
    south = tile_y_to_lat(tile_y + 1, zoom)
    return south, west, north, east


def local_point(coord: tuple[float, float], zoom: int, tile_x: int, tile_y: int, scale: int) -> tuple[float, float]:
    world_x, world_y = lon_lat_to_world_px(coord[0], coord[1], zoom)
    return (world_x - tile_x * TILE_SIZE) * scale, (world_y - tile_y * TILE_SIZE) * scale


def overpass_query(bbox: tuple[float, float, float, float]) -> str:
    south, west, north, east = bbox
    box = f"{south},{west},{north},{east}"
    return f"""
[out:json][timeout:180];
(
  way["highway"]({box});
  way["railway"]({box});
  way["waterway"]({box});
  way["natural"="water"]({box});
  way["water"]({box});
  way["leisure"="park"]({box});
);
out body;
>;
out skel qt;
"""


def fetch_overpass(destination: Path, bbox: tuple[float, float, float, float], force: bool) -> None:
    if destination.exists() and not force:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = urllib.parse.urlencode({"data": overpass_query(bbox)}).encode()
    request = urllib.request.Request(
        OVERPASS_URL,
        data=payload,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=240) as response:
        destination.write_bytes(response.read())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_osm(path: Path) -> tuple[dict[int, tuple[float, float]], list[dict]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    nodes: dict[int, tuple[float, float]] = {}
    ways: list[dict] = []
    for element in data.get("elements", []):
        if element.get("type") == "node":
            nodes[int(element["id"])] = (float(element["lon"]), float(element["lat"]))
        elif element.get("type") == "way":
            ways.append(element)
    return nodes, ways


def tile_range_for_bbox(bbox: tuple[float, float, float, float], zoom: int) -> tuple[range, range]:
    south, west, north, east = bbox
    max_index = 2**zoom - 1
    x0 = max(0, min(max_index, lon_to_tile_x(west, zoom)))
    x1 = max(0, min(max_index, lon_to_tile_x(east, zoom)))
    y0 = max(0, min(max_index, lat_to_tile_y(north, zoom)))
    y1 = max(0, min(max_index, lat_to_tile_y(south, zoom)))
    return range(min(x0, x1), max(x0, x1) + 1), range(min(y0, y1), max(y0, y1) + 1)


def way_coords(way: dict, nodes: dict[int, tuple[float, float]]) -> list[tuple[float, float]]:
    coords = []
    for node_id in way.get("nodes", []):
        coord = nodes.get(int(node_id))
        if coord:
            coords.append(coord)
    return coords


def prepare_ways(ways: list[dict], nodes: dict[int, tuple[float, float]]) -> list[dict]:
    prepared = []
    for way in ways:
        coords = way_coords(way, nodes)
        if len(coords) < 2:
            continue
        lons = [coord[0] for coord in coords]
        lats = [coord[1] for coord in coords]
        prepared.append({
            "tags": way.get("tags", {}),
            "coords": coords,
            "bbox": (min(lats), min(lons), max(lats), max(lons)),
        })
    return prepared


def bbox_overlaps(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    a_south, a_west, a_north, a_east = a
    b_south, b_west, b_north, b_east = b
    return a_west <= b_east and a_east >= b_west and a_south <= b_north and a_north >= b_south


def visible_road_type(highway: str, zoom: int) -> bool:
    if zoom < 9:
        return highway in MAJOR_ROADS
    if zoom < 11:
        return highway in MID_ROADS
    if zoom < 13:
        return highway in MINOR_ROADS
    return highway in PATH_ROADS


def road_style(highway: str, zoom: int, scale: int) -> tuple[str, int]:
    if highway in MAJOR_ROADS:
        return "#f6f0dc", max(scale, round((zoom - 7) * scale * 0.55))
    if highway in MID_ROADS:
        return "#ddd4b8", max(1, round((zoom - 9) * scale * 0.45))
    if highway in MINOR_ROADS:
        return "#c7bea3", max(1, round((zoom - 11) * scale * 0.35))
    return "#a9a18b", max(1, round((zoom - 12) * scale * 0.25))


def load_font(size: int) -> ImageFont.ImageFont:
    for path in (
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ):
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def line_label_position(points: list[tuple[float, float]]) -> tuple[float, float] | None:
    segments: list[tuple[float, tuple[float, float], tuple[float, float]]] = []
    total_length = 0.0
    for start, end in zip(points, points[1:]):
        length = math.hypot(end[0] - start[0], end[1] - start[1])
        if length <= 0:
            continue
        segments.append((length, start, end))
        total_length += length
    if total_length < 90:
        return None

    midpoint = total_length / 2
    walked = 0.0
    for length, start, end in segments:
        if walked + length >= midpoint:
            fraction = (midpoint - walked) / length
            return (
                start[0] + (end[0] - start[0]) * fraction,
                start[1] + (end[1] - start[1]) * fraction,
            )
        walked += length
    return None


def draw_text_with_halo(
    draw: ImageDraw.ImageDraw,
    position: tuple[float, float],
    text: str,
    font: ImageFont.ImageFont,
    fill: str,
    halo: str,
) -> None:
    x, y = position
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
        draw.text((x + dx, y + dy), text, font=font, fill=halo, anchor="mm")
    draw.text((x, y), text, font=font, fill=fill, anchor="mm")


def render_tile(
    ways: list[dict],
    bbox: tuple[float, float, float, float],
    zoom: int,
    tile_x: int,
    tile_y: int,
    scale: int,
) -> Image.Image:
    size = TILE_SIZE * scale
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    geo_bounds = tile_bounds(tile_x, tile_y, zoom)
    clip_rect = bbox_pixel_rect(bbox, zoom, tile_x, tile_y, scale)
    if clip_rect[0] >= clip_rect[2] or clip_rect[1] >= clip_rect[3]:
        return image.resize((TILE_SIZE, TILE_SIZE), Image.Resampling.LANCZOS)
    draw.rectangle(clip_rect, fill=LAND_FILL)

    for way in ways:
        if not bbox_overlaps(way["bbox"], geo_bounds):
            continue
        tags = way["tags"]
        coords = way["coords"]
        points = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in coords]
        is_closed = coords[0] == coords[-1] and len(points) >= 4

        if is_closed and (tags.get("natural") == "water" or tags.get("water")):
            draw.polygon(points, fill=WATER_FILL, outline="#4e8798")
            continue
        if is_closed and tags.get("leisure") == "park":
            draw.polygon(points, fill=PARK_FILL, outline="#708f64")
            continue
        if tags.get("waterway"):
            draw.line(points, fill="#4f91a4", width=max(1, round(scale * 0.8)))
            continue
        if tags.get("railway"):
            draw.line(points, fill="#5f5f5f", width=max(1, round(scale * 0.8)))
            continue

    for way in ways:
        if not bbox_overlaps(way["bbox"], geo_bounds):
            continue
        tags = way["tags"]
        highway = tags.get("highway")
        if not highway or not visible_road_type(highway, zoom):
            continue
        coords = way["coords"]
        points = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in coords]
        color, width = road_style(highway, zoom, scale)
        casing = max(width + scale, width + 1)
        draw.line(points, fill="#706854", width=casing, joint="curve")
        draw.line(points, fill=color, width=width, joint="curve")

    if zoom >= 13:
        font = load_font(max(9 * scale, (zoom - 5) * scale))
        drawn_labels: set[tuple[int, int, str]] = set()
        for way in ways:
            if not bbox_overlaps(way["bbox"], geo_bounds):
                continue
            tags = way["tags"]
            name = tags.get("name")
            highway = tags.get("highway")
            if not name or not highway or highway not in MID_ROADS or not visible_road_type(highway, zoom):
                continue
            points = [local_point(coord, zoom, tile_x, tile_y, scale) for coord in way["coords"]]
            position = line_label_position(points)
            if not position:
                continue
            key = (round(position[0] / 120), round(position[1] / 48), name)
            if key in drawn_labels:
                continue
            drawn_labels.add(key)
            draw_text_with_halo(draw, position, name, font, "#4f4a3f", "#d5cfbd")

    return image.resize((TILE_SIZE, TILE_SIZE), Image.Resampling.LANCZOS)


def main() -> None:
    args = parse_args()
    if args.min_zoom < 0 or args.max_zoom < args.min_zoom:
        raise SystemExit("--max-zoom must be >= --min-zoom >= 0")
    if args.scale < 1:
        raise SystemExit("--scale must be >= 1")

    bbox = parse_bbox(args.bbox)
    out_dir = Path(args.out) if args.out else Path(tempfile.mkdtemp(prefix="iris-maps-osm-detail-"))
    source_path = out_dir / "sources" / "overpass-helsinki.json"
    fetch_overpass(source_path, bbox, args.force_download)
    nodes, ways = load_osm(source_path)
    prepared_ways = prepare_ways(ways, nodes)

    tiles_dir = out_dir / "tiles"
    rendered = 0
    for zoom in range(args.min_zoom, args.max_zoom + 1):
        x_range, y_range = tile_range_for_bbox(bbox, zoom)
        for x in x_range:
            for y in y_range:
                tile = render_tile(prepared_ways, bbox, zoom, x, y, args.scale)
                tile_path = tiles_dir / str(zoom) / str(x) / f"{y}.png"
                tile_path.parent.mkdir(parents=True, exist_ok=True)
                tile.save(tile_path, format="PNG", optimize=True)
                rendered += 1

    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    manifest = {
        "version": 1,
        "kind": "iris-maps-osm-detail-raster-tiles",
        "generatedAt": generated_at,
        "tileSize": TILE_SIZE,
        "scheme": "web-mercator",
        "format": "png",
        "minZoom": args.min_zoom,
        "maxZoom": args.max_zoom,
        "tileTemplate": "tiles/{z}/{x}/{y}.png",
        "tileCount": rendered,
        "bounds": [[bbox[0], bbox[1]], [bbox[2], bbox[3]]],
        "attribution": "OpenStreetMap contributors",
        "sources": {
            "overpass": {
                "url": OVERPASS_URL,
                "sha256": sha256_file(source_path),
                "query": overpass_query(bbox),
            },
        },
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Rendered {rendered} detail tiles to {tiles_dir}")
    print(f"Manifest: {out_dir / 'manifest.json'}")


if __name__ == "__main__":
    main()
