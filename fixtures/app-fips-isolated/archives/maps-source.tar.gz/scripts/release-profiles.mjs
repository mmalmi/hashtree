export const defaultWorkerCompatibilityDate = '2026-03-19';
export const wranglerVersion = '4.78.0';

export const releaseProfiles = {
  maps: {
    name: 'maps',
    appName: 'Iris Maps',
    distDir: 'dist-maps',
    treeName: 'maps',
    defaultWorkerName: 'iris-maps',
    defaultRoutes: ['maps.iris.to/*'],
    workerScript: 'scripts/https-static-assets-worker.mjs',
    workerNameEnv: 'CF_WORKER_NAME_MAPS',
    pagesProjectEnv: 'CF_PAGES_PROJECT_MAPS',
    buildCommand: ['pnpm', 'run', 'build:maps'],
    testCommands: [
      ['pnpm', 'run', 'check:types'],
      ['pnpm', 'exec', 'vitest', 'run', 'tests/mainMapsInitOrder.test.ts', 'tests/mediaStreamingSetup.test.ts'],
      ['node', './scripts/smoke-maps-iris-portable.mjs'],
      ['node', './scripts/smoke-graph-policy.mjs', 'maps'],
      ['pnpm', 'run', 'test:unit'],
      ['pnpm', 'run', 'test:e2e:release'],
    ],
  },
};

export const releaseProfileNames = ['maps'];
