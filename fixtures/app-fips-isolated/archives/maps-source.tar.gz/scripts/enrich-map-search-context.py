#!/usr/bin/env python3
"""Enrich exported map records using Overture territorial polygons, never proximity.

Build-time dependencies: duckdb==1.5.5, shapely==2.1.2. Inputs are local
Overture division and division_area GeoParquet files from the same release.
"""
import argparse
import csv
import json
from pathlib import Path
import unicodedata

import duckdb
import numpy as np
import shapely
from shapely import STRtree

LOCAL = {'locality', 'localadmin'}
REGION = {'region', 'macroregion'}
COUNTRY = {'country', 'dependency'}
AREA_TYPES = LOCAL | REGION | COUNTRY | {'county', 'borough'}


def normalize(value):
    return ' '.join(''.join(c if c.isalnum() else ' ' for c in
        unicodedata.normalize('NFKD', value.casefold()) if not unicodedata.combining(c)).split())


def context_for(record, hierarchy, divisions):
    """Return concise, source-backed ancestors of the result's representative point."""
    chain = [divisions.get(item['division_id'], item) for item in hierarchy]
    own_names = {normalize(v) for v in [record['name'], *record.get('aliases', [])]}
    kind = record.get('addressType') or record.get('type')
    own_types = COUNTRY if kind == 'country' else REGION if kind == 'state' else (
        LOCAL | REGION | {'borough'} if kind in {'city', 'town', 'village', 'hamlet', 'suburb', 'neighbourhood'} else set())
    for i in range(len(chain) - 1, -1, -1):
        item = chain[i]
        if item['subtype'] in own_types and any(normalize(n) in own_names for n in [item['name'], item.get('primary', item['name'])]):
            chain = chain[:i + 1]
            break
    if record.get('addressType') == 'country' or record.get('type') == 'country':
        chain = [item for item in chain if item['subtype'] in COUNTRY]
    elif record.get('addressType') == 'state' or record.get('type') == 'state':
        chain = [item for item in chain if item['subtype'] in COUNTRY | REGION]
    local = [item for item in chain if item['subtype'] in LOCAL]
    city = next((item for item in reversed(local) if item.get('class') in {'city', 'town'}),
                local[0] if local else None)
    region = next((item for item in reversed(chain) if item['subtype'] in REGION), None)
    country = next((item for item in reversed(chain) if item['subtype'] in COUNTRY), None)
    if not city:
        city = next((item for item in reversed(chain) if item['subtype'] == 'county'), None)
    selected = [item for item in [city, region, country] if item]
    parts, aliases = [], []
    for item in selected:
        if item['name'] not in parts:
            parts.append(item['name'])
        primary = item.get('primary', item['name'])
        if normalize(primary) != normalize(item['name']) and primary not in aliases:
            aliases.append(primary)
    scopes = list(dict.fromkeys([city['name'], city.get('primary', city['name'])])) if city else []
    return parts, aliases, scopes


class Areas:
    def __init__(self, rows):
        self.rows = rows
        self.shapes = shapely.from_wkb([bytes(row['geometry']) for row in rows])
        invalid = ~shapely.is_valid(self.shapes)
        if invalid.any():
            self.shapes[invalid] = shapely.make_valid(self.shapes[invalid])
        shapely.prepare(self.shapes)
        self.tree = STRtree(self.shapes)
        self.sizes = shapely.area(self.shapes)

    def match(self, coordinates):
        points = shapely.points(coordinates)
        candidates = self.tree.query(points)
        result = np.full(len(points), -1, dtype=np.int64)
        if candidates.size == 0:
            return result
        points_idx, areas_idx = candidates
        inside = shapely.contains(self.shapes[areas_idx], points[points_idx])
        points_idx, areas_idx = points_idx[inside], areas_idx[inside]
        # Most detailed published hierarchy wins; polygon area only breaks ties.
        depth = np.array([len(row.get('hierarchy', [])) for row in self.rows])
        order = np.lexsort((self.sizes[areas_idx], -depth[areas_idx], points_idx))
        for index in order:
            point, area = points_idx[index], areas_idx[index]
            if result[point] == -1:
                result[point] = area
        return result


def query_rows(db, query, params):
    cursor = db.execute(query, params)
    names = [entry[0] for entry in cursor.description]
    return [dict(zip(names, row)) for row in cursor.fetchall()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--records', required=True)
    parser.add_argument('--areas', required=True)
    parser.add_argument('--divisions', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--release', required=True)
    parser.add_argument('--expected-count', required=True, type=int)
    args = parser.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    db = duckdb.connect(str(out / 'context.duckdb'))
    db.execute("SET threads=2; SET memory_limit='4GB'; SET preserve_insertion_order=true")
    if not db.execute("SELECT count(*) FROM information_schema.tables WHERE table_name='records'").fetchone()[0]:
        db.execute("""CREATE TABLE records AS SELECT json AS record,
            json_extract_string(json, '$.id') AS id,
            json_extract(json, '$.lng')::DOUBLE AS lng,
            json_extract(json, '$.lat')::DOUBLE AS lat,
            NULL::VARCHAR AS country
            FROM read_json_objects(?, format='newline_delimited')""", [args.records])
    counts = db.execute('SELECT count(*), count(DISTINCT id) FROM records').fetchone()
    if counts != (args.expected_count, args.expected_count):
        raise ValueError(f'Source record count/identity mismatch: {counts}')
    country_rows = query_rows(db, """SELECT division_id, country, geometry
        FROM read_parquet(?) WHERE is_territorial AND subtype IN ('country','dependency')""", [args.areas])
    countries = Areas(country_rows)
    assignments = out / 'countries.csv'
    if not assignments.exists():
        cursor = db.cursor().execute('SELECT rowid,lng,lat FROM records ORDER BY rowid')
        temporary = assignments.with_suffix('.partial')
        with temporary.open('w') as file:
            writer = csv.writer(file); writer.writerow(['rowid', 'country'])
            processed = 0
            while batch := cursor.fetchmany(25000):
                matches = countries.match([(row[1], row[2]) for row in batch])
                writer.writerows((row[0], country_rows[match]['country'] if match >= 0 else '')
                                 for row, match in zip(batch, matches))
                processed += len(batch)
                if processed % 250000 == 0: print(f'country lookup records={processed}', flush=True)
        temporary.rename(assignments)
    db.execute("""UPDATE records SET country=a.country FROM read_csv(?, header=true,
        columns={'rowid':'BIGINT','country':'VARCHAR'}) a WHERE records.rowid=a.rowid""", [str(assignments)])
    del countries, country_rows
    all_divisions = query_rows(db, """SELECT id, country, subtype, class,
        coalesce(names.common['en'], names.primary) AS name, names.primary AS native_name,
        hierarchies[1] AS hierarchy FROM read_parquet(?)
        WHERE subtype IN ('country','dependency','region','macroregion')""", [args.divisions])
    # Hierarchy references are resolved to readable names; keep the native name
    # as an alias so localized queries remain useful.
    base_divisions = {row['id']: {**row, 'primary': row['native_name']} for row in all_divisions}
    del all_divisions
    runs = out / 'records'; runs.mkdir(exist_ok=True)
    stats = {'records': 0, 'withCountry': 0, 'withLocality': 0, 'withContext': 0}
    locations = db.execute("SELECT coalesce(country,''),count(*) FROM records GROUP BY country ORDER BY country NULLS LAST").fetchall()
    for number, (country, total) in enumerate(locations):
        final = runs / f'records-{number:06}.jsonl'
        receipt = final.with_suffix('.receipt.json')
        if final.exists() and receipt.exists():
            for key, value in json.loads(receipt.read_text()).items(): stats[key] += value
            continue
        local_divisions = query_rows(db, """SELECT id, subtype, class,
            coalesce(names.common['en'], names.primary) AS name, names.primary AS native_name,
            hierarchies[1] AS hierarchy FROM read_parquet(?) WHERE country=? AND subtype IN
            ('country','dependency','region','macroregion','county','macrocounty','locality','localadmin','borough')""", [args.divisions, country]) if country else []
        divisions = base_divisions | {row['id']: {**row, 'primary': row['native_name']} for row in local_divisions}
        del local_divisions
        rows = query_rows(db, """SELECT division_id, country, geometry FROM read_parquet(?)
            WHERE country=? AND is_territorial AND subtype IN
            ('country','dependency','region','macroregion','county','locality','localadmin','borough')""", [args.areas, country]) if country else []
        for row in rows:
            row['hierarchy'] = divisions.get(row['division_id'], {}).get('hierarchy') or []
        areas = Areas(rows) if rows else None
        cursor = db.cursor().execute("SELECT record,lng,lat FROM records WHERE coalesce(country,'')=? ORDER BY id", [country])
        local_stats = dict.fromkeys(stats, 0)
        with final.with_suffix('.partial').open('w') as file:
            while batch := cursor.fetchmany(10000):
                matches = areas.match([(row[1], row[2]) for row in batch]) if areas else [-1] * len(batch)
                for row, match in zip(batch, matches):
                    record = json.loads(row[0])
                    if match >= 0:
                        hierarchy = rows[match]['hierarchy']
                        parts, aliases, scopes = context_for(record, hierarchy, divisions)
                        if parts: record['contextParts'] = parts; local_stats['withContext'] += 1
                        if aliases: record['contextAliases'] = aliases
                        if scopes: record['contextScopes'] = scopes
                        if any(item['subtype'] in LOCAL for item in hierarchy): local_stats['withLocality'] += 1
                    if country: local_stats['withCountry'] += 1
                    file.write(json.dumps({'key': record['id'], 'quality': 0, 'record': record}, ensure_ascii=False, separators=(',', ':')) + '\n')
                    local_stats['records'] += 1
        if local_stats['records'] != total: raise ValueError(f'Incomplete country {country}')
        final.with_suffix('.partial').rename(final)
        receipt.write_text(json.dumps(local_stats))
        for key, value in local_stats.items(): stats[key] += value
        print(json.dumps({'country': country, **local_stats}), flush=True)
        del areas, rows, divisions
    if stats['records'] != args.expected_count: raise ValueError('Incomplete enriched record set')
    metadata = {'kind': 'administrative-boundary-context', 'release': args.release,
        'source': 'https://docs.overturemaps.org/guides/divisions/', 'license': 'ODbL-1.0',
        'method': 'Representative-point containment in territorial polygons; published default hierarchy.',
        'attribution': 'Overture Maps Foundation, OpenStreetMap contributors, geoBoundaries.', **stats}
    (out / 'context-source.json').write_text(json.dumps(metadata, indent=2))
    print(json.dumps(metadata), flush=True)


if __name__ == '__main__':
    main()
