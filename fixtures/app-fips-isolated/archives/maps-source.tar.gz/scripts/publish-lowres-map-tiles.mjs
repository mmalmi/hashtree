#!/usr/bin/env node
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { parsePublishOutput } from './release-site.mjs';
import { resolveHtreeCommand } from './hashtreePaths.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');

const DEFAULT_TREE_NAME = 'maps-tiles-overview-v2';
const DEFAULT_PUBLISH_TIMEOUT_MS = 120_000;
const TEMP_DIR_PREFIX = 'iris-maps-lowres-';

function usage() {
  return `Usage: node ./scripts/publish-lowres-map-tiles.mjs [options]

Render the starter low-resolution Iris Maps tile dataset, then publish the
generated directory to a separate hashtree mutable path.

Options:
  --out <dir>       Output directory. Defaults to a temporary directory outside
                    the repo and cleans it after a successful publish.
  --tree <name>     hashtree mutable tree name (default: ${DEFAULT_TREE_NAME})
  --min-zoom <n>    First zoom to render (default: 0)
  --max-zoom <n>    Last zoom to render (default: 6)
  --keep-output     Keep the generated temporary output directory
  --skip-generate   Publish an existing output directory
  --skip-publish    Render only; do not call htree
  --push-server <url>
                    Publish the ref locally, then push blobs to this file
                    server with "htree push -s <url>" before verification
  --publish-timeout-ms <n>
                    Stop htree publish after this many ms, then verify gateway
                    availability if htree already printed a ref
  --dry-run         Print commands without running them
  -h, --help        Show this help
`;
}

function parseArgs(argv) {
  const options = {
    outDir: null,
    treeName: DEFAULT_TREE_NAME,
    minZoom: 0,
    maxZoom: 6,
    keepOutput: false,
    skipGenerate: false,
    skipPublish: false,
    pushServer: null,
    dryRun: false,
    help: false,
    publishTimeoutMs: DEFAULT_PUBLISH_TIMEOUT_MS,
  };

  const args = [...argv];
  while (args.length > 0) {
    const arg = args.shift();
    if (arg === '-h' || arg === '--help') {
      options.help = true;
      continue;
    }
    if (arg === '--out') {
      options.outDir = args.shift() ?? null;
      continue;
    }
    if (arg === '--tree') {
      options.treeName = args.shift();
      continue;
    }
    if (arg === '--min-zoom') {
      options.minZoom = Number(args.shift());
      continue;
    }
    if (arg === '--max-zoom') {
      options.maxZoom = Number(args.shift());
      continue;
    }
    if (arg === '--keep-output') {
      options.keepOutput = true;
      continue;
    }
    if (arg === '--skip-generate') {
      options.skipGenerate = true;
      continue;
    }
    if (arg === '--skip-publish' || arg === '--no-publish') {
      options.skipPublish = true;
      continue;
    }
    if (arg === '--push-server') {
      options.pushServer = args.shift() ?? null;
      continue;
    }
    if (arg === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    if (arg === '--publish-timeout-ms') {
      options.publishTimeoutMs = Number(args.shift());
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  if (options.outDir !== null && !options.outDir) {
    throw new Error('--out requires a non-empty value');
  }
  if (!options.treeName) {
    throw new Error('--tree requires a non-empty value');
  }
  if (options.pushServer !== null && !options.pushServer) {
    throw new Error('--push-server requires a non-empty value');
  }
  if (options.skipGenerate && !options.outDir) {
    throw new Error('--skip-generate requires --out so the source dataset is explicit');
  }
  if (!Number.isInteger(options.minZoom) || !Number.isInteger(options.maxZoom) || options.maxZoom < options.minZoom) {
    throw new Error('--max-zoom must be >= --min-zoom');
  }
  if (!Number.isInteger(options.publishTimeoutMs) || options.publishTimeoutMs <= 0) {
    throw new Error('--publish-timeout-ms must be a positive integer');
  }
  return options;
}

function shellQuote(command) {
  return command.map((part) => {
    if (/^[A-Za-z0-9_./:=@%+-]+$/.test(part)) return part;
    return `'${part.replace(/'/g, "'\\''")}'`;
  }).join(' ');
}

class CommandFailure extends Error {
  constructor(message, details) {
    super(message);
    this.name = 'CommandFailure';
    this.stdout = details.stdout;
    this.stderr = details.stderr;
    this.status = details.status;
    this.timedOut = details.timedOut;
  }
}

function runCommand(command, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command[0], command.slice(1), {
      cwd: options.cwd ?? appDir,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let killTimer = null;
    const timeoutTimer = options.timeoutMs
      ? setTimeout(() => {
        timedOut = true;
        child.kill('SIGINT');
        killTimer = setTimeout(() => child.kill('SIGKILL'), 3000);
      }, options.timeoutMs)
      : null;
    child.stdout.on('data', (chunk) => {
      const text = chunk.toString();
      stdout += text;
      process.stdout.write(text);
    });
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      stderr += text;
      process.stderr.write(text);
    });
    child.on('error', reject);
    child.on('close', (status) => {
      if (timeoutTimer) clearTimeout(timeoutTimer);
      if (killTimer) clearTimeout(killTimer);
      if (status === 0 && !timedOut) {
        resolve({ stdout, stderr });
      } else {
        const reason = timedOut
          ? `timed out after ${options.timeoutMs}ms`
          : `failed with exit code ${status}`;
        reject(new CommandFailure(`${shellQuote(command)} ${reason}`, {
          stdout,
          stderr,
          status,
          timedOut,
        }));
      }
    });
  });
}

function tileCount(minZoom, maxZoom) {
  let total = 0;
  for (let zoom = minZoom; zoom <= maxZoom; zoom += 1) {
    total += (2 ** zoom) ** 2;
  }
  return total;
}

function createPublishCommand(options, outDir) {
  const command = [
    'add',
    outDir,
    '--unencrypted',
  ];
  if (options.pushServer) {
    command.push('--local');
  }
  command.push('--publish', options.treeName);
  return resolveHtreeCommand(...command);
}

function createPushCommand(hash, pushServer) {
  return resolveHtreeCommand('push', '-s', pushServer, hash);
}

function createOutputPlan(options) {
  if (options.outDir) {
    return {
      outDir: path.resolve(appDir, options.outDir),
      isTemporary: false,
    };
  }

  if (options.dryRun) {
    return {
      outDir: path.join(os.tmpdir(), `${TEMP_DIR_PREFIX}<temp>`),
      isTemporary: true,
    };
  }

  return {
    outDir: fs.mkdtempSync(path.join(os.tmpdir(), TEMP_DIR_PREFIX)),
    isTemporary: true,
  };
}

function splitPublishedRef(publishedRef) {
  const slash = publishedRef.indexOf('/');
  if (slash === -1) {
    throw new Error(`Unexpected published ref: ${publishedRef}`);
  }
  return {
    npub: publishedRef.slice(0, slash),
    treeName: publishedRef.slice(slash + 1),
  };
}

function parseStoredHash(output) {
  const match = output.match(/^\s*hash:\s*([a-f0-9]{64})\s*$/im);
  if (!match) {
    throw new Error('Publish succeeded but no stored hash was found in htree output');
  }
  return match[1];
}

function printPublishedSummary({ publish, outDir, treeName, minZoom, maxZoom }) {
  const urls = buildPublishedUrls(publish);

  console.log('');
  console.log('Low-res tile publish complete.');
  console.log(`Dataset directory: ${outDir}`);
  console.log(`Tree: ${treeName}`);
  console.log(`Zooms: ${minZoom}..${maxZoom} (${tileCount(minZoom, maxZoom)} tiles)`);
  console.log(`Hashtree immutable URL: htree://${publish.nhash}`);
  console.log(`Hashtree mutable URL: htree://${publish.publishedRef}`);
  console.log(`App tile template: ${urls.mutableTileTemplate}`);
  console.log(`Service-worker tile template: ${urls.serviceWorkerTileTemplate}`);
  console.log(`Immutable tile template: ${urls.immutableTileTemplate}`);
}

function buildPublishedUrls(publish) {
  const { npub, treeName: publishedTreeName } = splitPublishedRef(publish.publishedRef);
  const encodedTreeName = encodeURIComponent(publishedTreeName);
  return {
    mutableTileTemplate: `/htree/${npub}/${encodedTreeName}/tiles/{z}/{x}/{y}.png`,
    mutableManifestUrl: `/htree/${npub}/${encodedTreeName}/manifest.json`,
    serviceWorkerTileTemplate: `/htree/${npub}/${encodedTreeName}/tiles/{z}/{x}/{y}.png`,
    immutableTileTemplate: `/htree/${publish.nhash}/tiles/{z}/{x}/{y}.png`,
  };
}

function cacheBust(url) {
  const parsed = new URL(url);
  parsed.searchParams.set('verify', `${Date.now()}`);
  return parsed.toString();
}

async function fetchBytes(url, timeoutMs = 20_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(cacheBust(url), {
      headers: {
        'Cache-Control': 'no-cache',
      },
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(`${url} returned HTTP ${response.status}`);
    }
    return Buffer.from(await response.arrayBuffer());
  } finally {
    clearTimeout(timer);
  }
}

function sha256Bytes(bytes) {
  return crypto.createHash('sha256').update(bytes).digest('hex');
}

function readLocalBytes(outDir, relativePath) {
  return fs.readFileSync(path.join(outDir, ...relativePath.split('/')));
}

async function verifyByteMatch(url, localBytes, label) {
  const remoteBytes = await fetchBytes(url);
  const localHash = sha256Bytes(localBytes);
  const remoteHash = sha256Bytes(remoteBytes);
  if (localHash !== remoteHash) {
    throw new Error(
      `${label} gateway byte mismatch: local sha256=${localHash}, remote sha256=${remoteHash}`,
    );
  }
}

async function verifyPublishedGateway(publish, { outDir, minZoom, maxZoom }) {
  const urls = buildPublishedUrls(publish);
  const manifestBytes = readLocalBytes(outDir, 'manifest.json');
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  if (manifest.minZoom !== minZoom || manifest.maxZoom !== maxZoom) {
    throw new Error(
      `local manifest zoom mismatch: expected ${minZoom}..${maxZoom}, got ${manifest.minZoom}..${manifest.maxZoom}`,
    );
  }
  const expectedTileCount = tileCount(minZoom, maxZoom);
  if (manifest.tileCount !== expectedTileCount) {
    throw new Error(`local manifest tileCount mismatch: expected ${expectedTileCount}, got ${manifest.tileCount}`);
  }

  await verifyByteMatch(urls.mutableManifestUrl, manifestBytes, 'manifest.json');

  const firstTilePath = `tiles/${minZoom}/0/0.png`;
  const firstTileUrl = urls.mutableTileTemplate
    .replace('{z}', String(minZoom))
    .replace('{x}', '0')
    .replace('{y}', '0');
  await verifyByteMatch(firstTileUrl, readLocalBytes(outDir, firstTilePath), firstTilePath);

  const maxTilePath = `tiles/${maxZoom}/0/0.png`;
  const maxTileUrl = urls.mutableTileTemplate
    .replace('{z}', String(maxZoom))
    .replace('{x}', '0')
    .replace('{y}', '0');
  await verifyByteMatch(maxTileUrl, readLocalBytes(outDir, maxTilePath), maxTilePath);
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return;
  }

  const outputPlan = createOutputPlan(options);
  const outDir = outputPlan.outDir;
  const renderCommand = [
    'python3',
    path.join(appDir, 'scripts/render-lowres-map-tiles.py'),
    '--out',
    outDir,
    '--min-zoom',
    String(options.minZoom),
    '--max-zoom',
    String(options.maxZoom),
  ];
  const publishCommand = createPublishCommand(options, outDir);

  if (!options.skipGenerate) {
    console.log(`Render command: ${shellQuote(renderCommand)}`);
    if (!options.dryRun) {
      await runCommand(renderCommand);
    }
  }

  if (!options.skipPublish) {
    if (!options.dryRun && !fs.existsSync(outDir)) {
      throw new Error(`Tile output directory not found: ${outDir}`);
    }
    console.log(`Publish command: ${shellQuote(publishCommand)}`);
    if (options.pushServer) {
      console.log(`Push server: ${options.pushServer}`);
    }
    if (!options.dryRun) {
      let result;
      try {
        result = await runCommand(publishCommand, {
          cwd: outDir,
          timeoutMs: options.publishTimeoutMs,
        });
      } catch (error) {
        const output = `${error.stdout ?? ''}\n${error.stderr ?? ''}`;
        if (!error.timedOut) {
          throw error;
        }
        console.warn(`htree publish timed out after ${options.publishTimeoutMs}ms; verifying gateway output.`);
        result = { stdout: output, stderr: '' };
      }
      const publish = parsePublishOutput(`${result.stdout}\n${result.stderr}`);
      if (options.pushServer) {
        const hash = parseStoredHash(`${result.stdout}\n${result.stderr}`);
        const pushCommand = createPushCommand(hash, options.pushServer);
        console.log(`Push command: ${shellQuote(pushCommand)}`);
        await runCommand(pushCommand, {
          cwd: outDir,
          timeoutMs: options.publishTimeoutMs,
        });
      }
      await verifyPublishedGateway(publish, {
        outDir,
        minZoom: options.minZoom,
        maxZoom: options.maxZoom,
      });
      printPublishedSummary({
        publish,
        outDir,
        treeName: options.treeName,
        minZoom: options.minZoom,
        maxZoom: options.maxZoom,
      });
    }
  }

  if (outputPlan.isTemporary && !options.keepOutput && !options.dryRun && !options.skipPublish) {
    fs.rmSync(outDir, { recursive: true, force: true });
  }

  if (options.dryRun) {
    console.log('Dry run complete.');
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

export {
  buildPublishedUrls,
  createPublishCommand,
  createOutputPlan,
  createPushCommand,
  parseArgs,
  parseStoredHash,
  tileCount,
  verifyPublishedGateway,
};
