#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { HashTree, toHex } from '@hashtree/core';
import { BTree } from '@hashtree/index';
import { deserializeCid, FileBlockStore, verifiedBlockStore } from './map-search-block-store.mjs';

// Reuse the published records when extraction runs are unavailable. No map-tile
// download is needed, and every source block is checked before decoding it.
export async function* exportRecords(manifest, source) {
  if (!manifest.byIdRoot || manifest.recordPacking?.kind !== 'json-record-shard') {
    throw new Error('Expected a packed search index with a by-id tree');
  }
  if (manifest.addressSidecars?.sidecarCount > 0) {
    throw new Error('Address sidecar datasets require their original address extraction runs');
  }
  const store = verifiedBlockStore(source);
  const tree = new HashTree({ store });
  const index = new BTree(store, manifest.searchOptions);
  const shards = new Set();
  let links = 0;
  let records = 0;
  for await (const [id, ref] of index.linksEntries(deserializeCid(manifest.byIdRoot))) {
    links += 1;
    const key = `${toHex(ref.hash)}:${ref.key ? toHex(ref.key) : ''}`;
    if (shards.has(key)) continue;
    shards.add(key);
    const bytes = await tree.readFile(ref);
    if (!bytes) throw new Error(`Unreadable record shard for ${id}`);
    const shard = JSON.parse(new TextDecoder().decode(bytes));
    if (shard.kind !== 'iris-maps-search-record-shard' || !Array.isArray(shard.records)
      || !shard.records.some(record => record.id === id)) {
      throw new Error(`Invalid record shard for ${id}`);
    }
    for (const record of shard.records) {
      if (!record.id || !record.name || !Number.isFinite(record.lat) || !Number.isFinite(record.lng)) {
        throw new Error('Invalid source record');
      }
      records += 1;
      yield record;
    }
  }
  if (links !== manifest.placeCount || records !== manifest.placeCount) {
    throw new Error(`Incomplete export: ${links} links, ${records} records, expected ${manifest.placeCount}`);
  }
}

async function main() {
  const [receiptPath, output] = process.argv.slice(2);
  if (!receiptPath || !output) throw new Error('Usage: export-map-search-records.mjs <publish-result.json> <records.jsonl>');
  const receipt = JSON.parse(await fs.readFile(receiptPath, 'utf8'));
  const temporary = `${output}.partial`;
  const handle = await fs.open(temporary, 'wx');
  let buffer = '';
  let count = 0;
  try {
    for await (const record of exportRecords(receipt.manifest, new FileBlockStore(receipt.blockStore))) {
      buffer += `${JSON.stringify(record)}\n`;
      count += 1;
      if (buffer.length >= 1024 * 1024) { await handle.write(buffer); buffer = ''; }
      if (count % 250000 === 0) console.error(`exported records=${count}`);
    }
    if (buffer) await handle.write(buffer);
  } finally {
    await handle.close();
  }
  await fs.rename(temporary, output);
  console.log(JSON.stringify({ records: count, output }));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error); process.exitCode = 1; });
}
