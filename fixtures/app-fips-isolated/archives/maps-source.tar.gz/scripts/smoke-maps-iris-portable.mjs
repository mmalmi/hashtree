import { checkRandomizedRange } from './check-randomized-range.mjs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { runPortableSmoke } from './portable-smoke-lib.mjs';
import { expect } from '@playwright/test';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appDir = path.resolve(__dirname, '..');
let tileUrl;
const cachedRanges = [];

async function rangeDigest(page, start, end) {
  const result = await page.evaluate(async ({ url, start, end }) => {
    const response = await fetch(url, {
      headers: { Range: `bytes=${start}-${end - 1}` },
      signal: AbortSignal.timeout(15000),
    });
    return {
      status: response.status,
      contentRange: response.headers.get('Content-Range'),
      bytes: Array.from(new Uint8Array(await response.arrayBuffer())),
    };
  }, { url: tileUrl, start, end });
  assert.equal(result.status, 206);
  assert.equal(result.bytes.length, end - start);
  assert.ok(result.contentRange?.startsWith(`bytes ${start}-${end - 1}/`));
  return createHash('sha256').update(Uint8Array.from(result.bytes)).digest('hex');
}

runPortableSmoke({
  distDir: path.join(appDir, 'dist-maps'),
  title: 'Iris Maps',
  appName: 'maps',
  screenshotPath: path.join(appDir, 'test-results', 'maps-iris-portable-smoke.png'),
  async validatePage(page, goOffline) {
    await expect(page.getByTestId('map-surface')).toHaveAttribute('aria-busy', 'false', { timeout: 45000 });
    tileUrl = await page.evaluate(() => performance.getEntriesByType('resource')
      .map(entry => entry.name).find(url => new URL(url).pathname.endsWith('/tiles.pmtiles')));
    assert.ok(tileUrl, 'The rendered map must load its real tile archive');
    const archive = new URL(tileUrl);
    assert.equal(archive.origin, new URL(page.url()).origin);
    assert.ok(archive.pathname.startsWith('/htree/nhash1'), 'Default tiles must use the persistent Hashtree cache');
    for (const [start, end] of [[0, 16384], [17870, 46658]]) {
      cachedRanges.push({ start, end, sha256: await rangeDigest(page, start, end) });
    }
    await checkRandomizedRange(page);
    // The installed app must find cities even if the remote index is unavailable.
    await goOffline();
    const searchStartedAt = performance.now();
    await page.getByTestId('search-input').fill('Helsinki');
    const result = page.getByTestId('search-results').getByRole('button', { name: /Helsinki/ }).first();
    await expect(result).toBeVisible({ timeout: 6000 });
    console.log(`Offline city search: ${Math.round(performance.now() - searchStartedAt)} ms`);
    await page.screenshot({ path: path.join(appDir, 'test-results', 'maps-offline-search.png') });
  },
  async validateOfflinePage(page) {
    await expect(page.getByTestId('map-surface')).toHaveAttribute('aria-busy', 'false', { timeout: 15000 });
    for (const { start, end, sha256 } of cachedRanges) {
      assert.equal(await rangeDigest(page, start, end), sha256, 'Cached tiles must survive an offline reload');
    }
    await page.screenshot({ path: path.join(appDir, 'test-results', 'maps-offline-tiles.png') });
  },
}).catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
