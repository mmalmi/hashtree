import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire('/stage/apps/social/package.json');
const {WebSocketServer}=require('ws'),{verifyEvent,matchFilters}=require('nostr-tools');
const here=path.dirname(new URL(import.meta.url).pathname),sha=b=>createHash('sha256').update(b).digest('hex');
const eventBytes=await fs.readFile(path.join(here,'events.json'));
if(sha(eventBytes)!=='f08efe233946cca4b6aa16fbf0925986d9421aab7c4ea46ee81bcb3bc41a3a3c')throw Error('Signed root fixture changed');
const snapshot=JSON.parse(eventBytes);for(const event of snapshot.events)if(!verifyEvent(event)||!matchFilters(snapshot.filters,event))throw Error('Unadmitted public fixture event');
const cache=path.join(here,'blocks');await fs.mkdir(cache,{recursive:true});const pending=new Map(),assets=new Map();
const started=Date.now();let received=0,requests=0,localEvents=0,localAuth=0;const maxBytes=128*1024*1024,perFile=4*1024*1024;
async function block(hash){
 if(!/^[a-f0-9]{64}$/.test(hash))throw Error('Invalid public block hash');
 const file=path.join(cache,hash);try{const b=await fs.readFile(file);if(b.length>perFile||sha(b)!==hash)throw Error('Retained public block integrity');assets.set(hash,{bytes:b.length,cached:true});return b;}catch(e){if(e.code!=='ENOENT')throw e;}
 throw Error('Prepared public block missing during static replay');
}
const server=createServer(async(req,res)=>{
 res.setHeader('Access-Control-Allow-Origin','*');
 const match=/^\/blocks\/([a-f0-9]{64})$/.exec(req.url??'');if(req.method!=='GET'||!match){res.writeHead(405).end();return;}
 try{const body=await block(match[1]);res.writeHead(200,{'content-type':'application/octet-stream','cache-control':'public,max-age=31536000,immutable'}).end(body);}catch(e){res.writeHead(502).end(String(e.message));}
});
server.on('connect',(_req,socket)=>socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'));
const relay=new WebSocketServer({noServer:true,maxPayload:1024*1024});
server.on('upgrade',(req,socket,head)=>{if(req.url!=='/relay'){socket.destroy();return;}relay.handleUpgrade(req,socket,head,ws=>relay.emit('connection',ws,req));});
relay.on('connection',ws=>ws.on('message',raw=>{
 if(++requests>12000){ws.close();return;}let frame;try{frame=JSON.parse(String(raw))}catch{ws.close();return;}
 if(frame[0]==='REQ'&&frame.length>=3&&frame.length<=18){const filters=frame.slice(2);for(const event of snapshot.events.filter(e=>matchFilters(filters,e)))ws.send(JSON.stringify(['EVENT',frame[1],event]));ws.send(JSON.stringify(['EOSE',frame[1]]));}
 else if(frame[0]==='NEG-OPEN')ws.send(JSON.stringify(['NEG-ERR',frame[1],'unsupported: static public fixture']));
 else if(frame[0]==='EVENT'){localEvents++;ws.send(JSON.stringify(['OK',frame[1]?.id,false,'blocked: fixture is read-only']));}
 else if(frame[0]==='AUTH'){localAuth++;ws.close(1008,'read-only fixture');}
}));
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
await fs.writeFile(path.join(here,'bridge-ready.json'),JSON.stringify({origin,pid:process.pid,started})+'\n');console.log('Public read fixture ready');
async function close(){for(const ws of relay.clients)ws.terminate();await new Promise(r=>server.close(r));await Promise.allSettled([...pending.values()]);await fs.writeFile(path.join(here,'receipt-'+started+'.json'),JSON.stringify({eventFixtureSha256:sha(eventBytes),capturedAt:snapshot.capturedAt,receivedBytes:received,elapsedMs:Date.now()-started,requests,locallyRejectedEvents:localEvents,locallyRejectedAuth:localAuth,upstreamMethods:['GET'],upstreamHost:'cdn.iris.to',forwardedHeaders:[],redirects:false,maximumBytes:maxBytes,assets:[...assets].map(([hash,value])=>({sha256:hash,...value}))},null,2)+'\n');}
const deadline=setTimeout(()=>close().then(()=>process.exit()),660000);
for(const sig of ['SIGTERM','SIGINT'])process.once(sig,()=>close().then(()=>process.exit()));
