import { once } from 'node:events';
import { createServer } from 'node:http';
import { WebSocketServer } from 'ws';
import type { BrowserContext } from '@playwright/test';
import { createNamedGraphFixture } from 'nostr-social-graph/testing/namedGraph';

/** Serve the SDK's real signed event and encrypted blocks to the built app and its workers. */
export async function serveNamedGraph(context: BrowserContext, root: string, bytes: Uint8Array) {
  const graph = await createNamedGraphFixture(root, bytes);
  const requests = { names: 0, blocks: 0, legacy: 0 };
  const server = createServer(async (req, res) => {
    const hash = /^\/([0-9a-f]{64})\.bin$/.exec(req.url ?? '')?.[1];
    const block = hash && await graph.readBlock(hash);
    if (!block) { res.writeHead(404).end(); return; }
    requests.blocks++;
    res.writeHead(200, {'Content-Type': 'application/octet-stream', 'Access-Control-Allow-Origin': '*'}).end(Buffer.from(block));
  });
  const sockets = new WebSocketServer({ server });
  sockets.on('connection', socket => socket.on('message', raw => {
    const [type, id, filter] = JSON.parse(raw.toString());
    if (type !== 'REQ') return;
    if (filter?.kinds?.includes(30064) && filter.authors?.includes(graph.event.pubkey) && filter['#d']?.includes('social-graph')) {
      requests.names++;
      socket.send(JSON.stringify(['EVENT', id, graph.event]));
    }
    socket.send(JSON.stringify(['EOSE', id]));
  }));
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('Expected loopback TCP address');
  const origin = `http://127.0.0.1:${address.port}`;
  const relay = `ws://127.0.0.1:${address.port}`;
  // Replace only the named reader's test inputs in served Javascript. This also
  // reaches dedicated workers, whose sockets are outside page-level routing.
  await context.route(/\.js(?:\?|$)/, async route => {
    const response = await route.fetch();
    const body = await response.text();
    const publisher = 'npub1yscmnnadrmvape0mvgzfx9uyl267klnhzy8znsr6ysl8wtxngpqsnx6dm0';
    const patched = body.includes(publisher) ? body.replaceAll(publisher, graph.publisher)
      .replace(/(relays\s*:\s*)\[\s*["']wss:\/\/temp\.iris\.to["']\s*,\s*["']wss:\/\/relay\.primal\.net["']\s*\]/g, `$1${JSON.stringify([relay])}`)
      .replace(/(blossomServers\s*:\s*)\[\s*["']https:\/\/cdn\.iris\.to["']\s*\]/g, `$1${JSON.stringify([origin])}`) : body;
    await route.fulfill({ response, body: patched });
  });
  await context.route('https://graph-api.iris.to/**', route => { requests.legacy++; return route.abort(); });
  return { requests, async close() {
    for (const socket of sockets.clients) socket.terminate();
    sockets.close();
    server.closeAllConnections();
    await new Promise<void>(resolve => server.close(() => resolve()));
  } };
}
