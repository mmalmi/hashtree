import { describe, expect, it } from 'vitest';
import { createProfileLookupRetry } from '../src/lib/profileLookupRetry';

const ALICE = 'a'.repeat(64);
const BOB = 'b'.repeat(64);

describe('profile lookup retry', () => {
  it('asks again for people a lookup that ran out of time did not answer for', () => {
    const retry = createProfileLookupRetry([5_000, 15_000]);
    const outcome = retry.settle([ALICE, BOB], pubkey => pubkey === ALICE, false, 1_000);
    expect(outcome).toEqual({ missing: [], retries: [{ delayMs: 5_000, pubkeys: [BOB] }] });
    expect(retry.waiting(ALICE, 1_000)).toBe(false);
    expect(retry.waiting(BOB, 5_999)).toBe(true);
    expect(retry.waiting(BOB, 6_000)).toBe(false);
  });

  it('waits longer each time and gives up after the last attempt', () => {
    const retry = createProfileLookupRetry([5_000, 15_000]);
    expect(retry.settle([BOB], () => false, false, 0).retries).toEqual([{ delayMs: 5_000, pubkeys: [BOB] }]);
    expect(retry.settle([BOB], () => false, false, 5_000).retries).toEqual([{ delayMs: 15_000, pubkeys: [BOB] }]);
    expect(retry.settle([BOB], () => false, false, 20_000)).toEqual({ missing: [BOB], retries: [] });
    expect(retry.waiting(BOB, 20_000)).toBe(false);
  });

  it('believes a complete answer at once', () => {
    const retry = createProfileLookupRetry();
    expect(retry.settle([ALICE, BOB], pubkey => pubkey === ALICE, true, 0)).toEqual({ missing: [BOB], retries: [] });
  });

  it('starts over for someone who was answered in between', () => {
    const retry = createProfileLookupRetry([5_000]);
    retry.settle([BOB], () => false, false, 0);
    retry.settle([BOB], () => true, false, 5_000);
    expect(retry.settle([BOB], () => false, false, 9_000).retries).toEqual([{ delayMs: 5_000, pubkeys: [BOB] }]);
  });
});
