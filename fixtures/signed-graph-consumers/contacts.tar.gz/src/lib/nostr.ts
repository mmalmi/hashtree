import { getPublicRuntime, queryPublicEvents, DEFAULT_RELAYS } from './publicRuntime';
export { DEFAULT_RELAYS } from './publicRuntime';
import type { Event } from 'nostr-tools/core';
import {
  KIND_CONTACTS,
  KIND_PROFILE,
  buildPublicContacts,
  decodeProfileInput,
  parseProfileEvent,
  type ContactRecord,
  type ProfileRecord,
  parseFollowTags,
} from './contacts';

export interface LoadPublicContactsResult {
  ownerPubkey: string;
  followEvent: Event | null;
  contacts: ContactRecord[];
  relayCount: number;
}

export async function loadPublicContacts(ownerInput: string, relays = DEFAULT_RELAYS): Promise<LoadPublicContactsResult> {
  const ownerPubkey = decodeProfileInput(ownerInput);
  if (!ownerPubkey) {
    throw new Error('Enter a valid Nostr public key');
  }

  const result = await queryPublicEvents([{ kinds: [KIND_CONTACTS], authors: [ownerPubkey], limit: 1 }], {
    relays, limit: 1, deadline: Date.now() + 5_000,
  });
  if (!result.events.length && !result.complete && !result.sources.some(source => source.complete && /^wss?:/.test(source.id))) {
    throw new Error('Could not finish loading public contacts. Your saved contacts are still available.');
  }
  const followEvent = result.events[0] ?? null;
  const { events: profileEvents } = await loadProfiles(relays, parseFollowTags(followEvent));
  return { ownerPubkey, followEvent, contacts: buildPublicContacts(ownerPubkey, followEvent, profileEvents), relayCount: relays.length };
}

export async function loadProfile(
  pubkeyInput: string,
  relays = DEFAULT_RELAYS,
): Promise<ProfileRecord | null> {
  const pubkey = decodeProfileInput(pubkeyInput);
  if (!pubkey) return null;

  const result = await queryPublicEvents([{ kinds: [KIND_PROFILE], authors: [pubkey], limit: 8 }], {
    relays, limit: 8, deadline: Date.now() + 2_500,
  });
  const [latest] = latestEventsByAuthor(result.events);
  return parseProfileEvent(latest) ?? null;
}

export async function loadProfilesByPubkey(
  pubkeyInputs: readonly string[],
  relays = DEFAULT_RELAYS,
): Promise<{ profiles: Map<string, ProfileRecord>; complete: boolean }> {
  const pubkeys = [...new Set(pubkeyInputs.flatMap((input) => {
    const pubkey = decodeProfileInput(input);
    return pubkey ? [pubkey] : [];
  }))];
  if (pubkeys.length === 0) return { profiles: new Map(), complete: true };

  const { events, complete } = await loadProfiles(relays, pubkeys);
  const profiles = new Map<string, ProfileRecord>();
  for (const event of events) {
    const profile = parseProfileEvent(event);
    if (profile) profiles.set(profile.pubkey, profile);
  }
  return { profiles, complete };
}

/** `complete` is false when a source ran out of time: someone without an event here may still have a profile. */
async function loadProfiles(relays: readonly string[], pubkeys: readonly string[]): Promise<{ events: Event[]; complete: boolean }> {
  const batchSize = 80;
  const batches = Array.from({ length: Math.ceil(pubkeys.length / batchSize) }, (_, index) =>
    pubkeys.slice(index * batchSize, (index + 1) * batchSize));
  // The time allowed is for the lookup itself, not for the worker to start.
  await getPublicRuntime();
  const results = await Promise.all(batches.map(authors => queryPublicEvents([
    { kinds: [KIND_PROFILE], authors, limit: authors.length },
  ], { relays, limit: authors.length, deadline: Date.now() + 4_000 })));
  return {
    events: latestEventsByAuthor(results.flatMap(result => result.events)),
    complete: results.every(result => result.complete),
  };
}

function latestEventsByAuthor(events: readonly Event[]): Event[] {
  const latest = new Map<string, Event>();
  for (const event of events) {
    const previous = latest.get(event.pubkey);
    if (!previous || event.created_at > previous.created_at) {
      latest.set(event.pubkey, event);
    }
  }
  return [...latest.values()];
}
