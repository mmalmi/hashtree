/**
 * Decides what to do with people a profile lookup did not answer for.
 *
 * A lookup ends at a deadline, and an answer that arrives after it is only
 * stored, not shown: just after start, or while the worker is busy, that is the
 * usual reason for a missing name. So unless every source reported the end of
 * what it has, an unanswered person is asked for again a few times, further
 * apart each time, before being treated as having no profile.
 */
export const PROFILE_RETRY_DELAYS_MS = [5_000, 15_000, 45_000] as const;

export interface ProfileLookupOutcome {
  /** Nobody has a profile for these: stop asking. */
  missing: string[];
  /** Ask again for these after the delay. */
  retries: Array<{ delayMs: number; pubkeys: string[] }>;
}

export function createProfileLookupRetry(delaysMs: readonly number[] = PROFILE_RETRY_DELAYS_MS) {
  const attempts = new Map<string, number>();
  const retryAt = new Map<string, number>();

  return {
    /** Whether a person is waiting for their next attempt and should not be asked for yet. */
    waiting(pubkey: string, now = Date.now()): boolean {
      return (retryAt.get(pubkey) ?? 0) > now;
    },
    settle(asked: readonly string[], answered: (pubkey: string) => boolean, complete: boolean, now = Date.now()): ProfileLookupOutcome {
      const missing: string[] = [];
      const byDelay = new Map<number, string[]>();
      for (const pubkey of asked) {
        if (answered(pubkey)) {
          attempts.delete(pubkey);
          retryAt.delete(pubkey);
          continue;
        }
        const made = attempts.get(pubkey) ?? 0;
        if (complete || made >= delaysMs.length) {
          attempts.delete(pubkey);
          retryAt.delete(pubkey);
          missing.push(pubkey);
          continue;
        }
        const delayMs = delaysMs[made];
        attempts.set(pubkey, made + 1);
        retryAt.set(pubkey, now + delayMs);
        byDelay.set(delayMs, [...(byDelay.get(delayMs) ?? []), pubkey]);
      }
      return { missing, retries: [...byDelay].map(([delayMs, pubkeys]) => ({ delayMs, pubkeys })) };
    },
  };
}
