// @vitest-environment node
import 'fake-indexeddb/auto'
import { afterEach, expect, it, vi } from 'vitest'
import { HashtreeRuntimeEventStore } from '@hashtree/nostr-pubsub'
import { finalizeEvent, generateSecretKey, getPublicKey, nip44, type VerifiedEvent } from 'nostr-tools'
import { AppKeys, Invite, Session } from 'nostr-double-ratchet'
import { TestRelay } from '../../e2e/test-relay'
import { createEventStore } from './eventStore'
import { createNostrWorkerRuntime } from './nostrWorkerRuntime'
import { callWakeEvent, sendCallWakeups, queuedCallWakeEnvelope } from './callPush'

const cleanup: Array<() => void | Promise<void>> = []
afterEach(async () => { for (const close of cleanup.splice(0).reverse()) await close() })

it('keeps private delivery and discovery off the added public route, including live settings changes', async () => {
  const publicRelay = new TestRelay(), privateRelay = new TestRelay(), selectedRelay = new TestRelay()
  const frames = new Map<TestRelay, unknown[][]>()
  for (const relay of [publicRelay, privateRelay, selectedRelay]) {
    frames.set(relay, [])
    relay.observeWire = message => frames.get(relay)!.push(message)
    await relay.start(); cleanup.push(() => relay.stop())
  }
  const owner = getPublicKey(generateSecretKey()), peer = getPublicKey(generateSecretKey())
  const runtime = createNostrWorkerRuntime(owner); cleanup.push(() => runtime.close())
  runtime.setRelayRoutes([publicRelay.url, privateRelay.url], [privateRelay.url])
  const requestKinds = (relay: TestRelay) => frames.get(relay)!.filter(frame => frame[0] === 'REQ')
    .flatMap(frame => (frame.slice(2) as Array<{ kinds?: number[] }>).flatMap(filter => filter.kinds ?? []))
  await runtime.query([{ kinds: [1060], '#p': [owner] }], { cache: 'network-only', sources: [] })
  await runtime.query([{ kinds: [37368], authors: [peer] }], { cache: 'network-only', sources: [] })
  await runtime.query([{ kinds: [0], authors: [peer] }], { cache: 'network-only', sources: [] })
  expect(requestKinds(publicRelay)).toEqual([0])
  expect(requestKinds(privateRelay)).toEqual(expect.arrayContaining([1060, 37368, 0]))
  const sealed = Session.init(getPublicKey(generateSecretKey()), generateSecretKey(), true, generateSecretKey())
    .sendEvent({ kind: 14, content: 'loopback private message' }).event
  const publicPost = finalizeEvent({ kind: 1, created_at: Math.floor(Date.now() / 1000), tags: [], content: 'loopback public post' }, generateSecretKey())
  await runtime.publish(sealed, { requireAck: true, queue: false, carrier: 'pairwise' })
  await runtime.publish(publicPost, { requireAck: true, queue: false })
  await vi.waitFor(() => expect(privateRelay.publishedEvents.map(event => event.id)).toEqual(expect.arrayContaining([sealed.id, publicPost.id])))
  await vi.waitFor(() => expect(publicRelay.publishedEvents.map(event => event.id)).toEqual([publicPost.id]))
  runtime.subscribe([{ kinds: [3] }], { onEvent() {} }, { cache: 'network-only', sources: [] })
  await vi.waitFor(() => expect(requestKinds(publicRelay)).toContain(3))
  runtime.setRelayRoutes([selectedRelay.url], [selectedRelay.url])
  await vi.waitFor(() => expect(requestKinds(selectedRelay)).toContain(3))
  await vi.waitFor(() => expect(frames.get(publicRelay)!.some(frame => frame[0] === 'CLOSE')).toBe(true))
  runtime.setRelayRoutes([], [])
  const emptyPost = finalizeEvent({ kind: 1, created_at: Math.floor(Date.now() / 1000), tags: [], content: 'must stay local' }, generateSecretKey())
  expect((await runtime.publish(emptyPost, { requireAck: true, queue: false })).sources).toEqual([])
  const emptyRead = await runtime.query([{ kinds: [3] }], { cache: 'network-only', sources: [] })
  expect(emptyRead.sources).toEqual([])
})

it('restarts the real worker queue without replaying identity-bearing call alerts or losing safe pending events', async () => {
  const relay = new TestRelay()
  await relay.start()
  cleanup.push(() => relay.stop())
  const key = generateSecretKey(), recipient = getPublicKey(generateSecretKey())
  const owner = getPublicKey(key)
  const now = Math.floor(Date.now() / 1000)
  const legacy = finalizeEvent({ kind: 21111, created_at: now, tags: [['p', recipient]],
    content: nip44.v2.encrypt(JSON.stringify({ v: 3, type: 'offer', call_id: 'old-call', video: true }),
      nip44.v2.utils.getConversationKey(key, recipient)) }, key)
  const oldMessage = finalizeEvent({ kind: 1060, created_at: now, tags: [['p', recipient]],
    content: 'opaque-existing-session-envelope' }, generateSecretKey())
  const oldBootstrap = finalizeEvent({ kind: 1059, created_at: now, tags: [['p', recipient]],
    content: 'opaque-old-invite-response' }, generateSecretKey())
  // Use a separate invite address so normal replacement does not retire it first.
  const oldInvite = finalizeEvent({ kind: 30078, created_at: now, tags: [['d', 'double-ratchet/invites/old-device']], content: '' }, key)
  const invite = finalizeEvent(Invite.createNew(owner, owner).getEvent(), key)
  const session = Session.init(getPublicKey(generateSecretKey()), generateSecretKey(), true, generateSecretKey())
  const sealed = session.sendEvent({ kind: 14, content: 'new encrypted message' }).event
  expect(sealed.tags.map(tag => tag[0])).toEqual(['v', 'header'])
  const unvouched = session.sendEvent({ kind: 14, content: 'nothing recorded where this came from' }).event
  // The shape the previous version queued: a real carrier that names its device.
  const tagged = finalizeEvent({ kind: 1060, created_at: now, content: sealed.content, tags: [...sealed.tags, ['p', recipient]] }, generateSecretKey())
  const identityWake = finalizeEvent({ kind: 21111, created_at: now, tags: [['p', recipient]],
    content: JSON.stringify({ type: 'call-wake', v: 2, events: [sealed] }) }, key)
  const wake = callWakeEvent(recipient, sealed)
  const unvouchedWake = callWakeEvent(recipient, unvouched)
  const taggedWake = finalizeEvent({ kind: 21111, created_at: now, tags: [['p', recipient]],
    content: JSON.stringify({ type: 'call-wake', v: 3, events: [tagged] }) }, generateSecretKey())
  const publicPost = finalizeEvent({ kind: 1, created_at: now, tags: [], content: 'public queued post' }, key)
  const beforeRestart = createEventStore(owner)
  const sharedGroup=finalizeEvent({kind:1060,created_at:now,content:'shared group ciphertext',tags:[['v','2'],['header','opaque']]},generateSecretKey())
  const publicGroupRoster=finalizeEvent({kind:37368,created_at:now,content:'',tags:[['type','group_roster'],['member',owner],['member',recipient]]},key)
  const quarantined = [legacy, identityWake, oldMessage, oldBootstrap, oldInvite, sharedGroup, publicGroupRoster, tagged, taggedWake]
  for (const event of [...quarantined, invite, publicPost]) {
    await beforeRestart.putPending({ event, attempts: 1, updatedAt: Date.now(), relays: [relay.url], sources: [] })
  }
  await beforeRestart.close()
  // The private lane keeps who vouched for a message envelope beside its retry row.
  // Shared group ciphertext has the same shape and nothing vouches for it.
  const privateLane = () => createEventStore(`${owner}:private-send`, 'private')
  const lane = privateLane()
  const unvouchedRows = [unvouched, unvouchedWake, tagged, taggedWake]
  for (const event of [sealed, wake, ...unvouchedRows]) {
    await lane.putPending({ event, attempts: 1, updatedAt: Date.now(), relays: [relay.url], sources: [] })
  }
  for (const event of [sealed, wake, tagged, taggedWake]) await lane.vouchPending(event.id, 'pairwise')
  await lane.close()

  // This is the same factory used by nostrWorker.ts. setRelays automatically
  // starts the shared runtime retry against the persisted production store.
  const runtime = createNostrWorkerRuntime(owner)
  cleanup.push(() => runtime.close())
  runtime.setRelays([relay.url])
  await vi.waitFor(() => {
    const sent = new Set(relay.publishedEvents.map(event => event.id))
    expect(sent).toEqual(new Set([wake.id, publicPost.id, sealed.id, invite.id]))
  }, { timeout: 5000 })
  await vi.waitFor(async () => expect(await runtime.store.listPending()).toEqual([]), { timeout: 5000 })
  // No guessed ciphertext or signed authorization is erased by this gate.
  const retained = await HashtreeRuntimeEventStore.prototype.listPending.call(runtime.store)
  expect(new Set(retained.map(entry => entry.event.id))).toEqual(new Set(quarantined.map(event => event.id)))
  const reopened = privateLane()
  expect(await reopened.listPending()).toEqual([])
  expect(new Set((await HashtreeRuntimeEventStore.prototype.listPending.call(reopened)).map(entry => entry.event.id)))
    .toEqual(new Set(unvouchedRows.map(event => event.id)))
  await reopened.close()
  for (const event of [...quarantined, ...unvouchedRows]) expect(relay.publishedEvents.some(published => published.id === event.id)).toBe(false)

  await expect(runtime.publish(legacy, { relays: [relay.url], requireAck: true, queue: false }))
    .rejects.toThrow('Old call alerts cannot be resent')
  await expect(runtime.publish(identityWake, { relays: [relay.url], requireAck: true, queue: false }))
    .rejects.toThrow('Invalid encrypted call alert')
  for (const event of [oldMessage, oldBootstrap, oldInvite]) {
    await expect(runtime.publish(event, { relays: [relay.url], requireAck: true, queue: false }))
      .rejects.toThrow('Old encrypted messages cannot be resent')
    expect(relay.publishedEvents.some(published => published.id === event.id)).toBe(false)
  }
  expect(relay.publishedEvents.some(event => event.id === legacy.id)).toBe(false)
  expect(relay.publishedEvents.some(event => event.id === identityWake.id)).toBe(false)
  for (const event of [sharedGroup,publicGroupRoster]) {
    await expect(runtime.publish(event,{relays:[relay.url],requireAck:true,queue:false})).rejects.toThrow()
    expect(relay.publishedEvents.some(published=>published.id===event.id)).toBe(false)
  }
  // Without a statement of where it came from, a message envelope is treated as group ciphertext.
  for (const queue of [true, false]) {
    await expect(runtime.publish(sharedGroup, { relays: [relay.url], queue })).rejects.toThrow('Missing encrypted message provenance')
    await expect(runtime.publish(unvouched, { relays: [relay.url], queue })).rejects.toThrow('Missing encrypted message provenance')
    await expect(runtime.publish(unvouchedWake, { relays: [relay.url], queue })).rejects.toThrow('Invalid encrypted call alert')
  }
  // A recipient is refused whatever vouches for the envelope, alone or inside a call alert.
  await expect(runtime.publish(tagged, { relays: [relay.url], requireAck: true, queue: false, carrier: 'pairwise' }))
    .rejects.toThrow('Message envelopes must not name a recipient')
  await expect(runtime.publish(taggedWake, { relays: [relay.url], requireAck: true, queue: false, carrier: 'pairwise' }))
    .rejects.toThrow('Invalid encrypted call alert')
  const extra = finalizeEvent({ kind: 1060, created_at: now, content: sealed.content, tags: [...sealed.tags, ['expiration', String(now + 60)]] }, generateSecretKey())
  await expect(runtime.publish(extra, { relays: [relay.url], requireAck: true, queue: false, carrier: 'pairwise' }))
    .rejects.toThrow('only the version and header')
  for (const event of [sharedGroup, unvouched, unvouchedWake, tagged, taggedWake, extra]) {
    expect(relay.publishedEvents.some(published => published.id === event.id)).toBe(false)
  }
  expect((await runtime.query([{ ids: [sharedGroup.id, unvouched.id, tagged.id] }], { cache: 'cache-only' })).events).toEqual([])
})

it('keeps first contact, queued messages and call delivery off identity-authenticated receiver connections', async () => {
  const relay = new TestRelay()
  relay.authRequired = true
  const wire: Array<{ message: unknown[]; connection: number }> = []
  relay.observeWire = (message, connection) => wire.push({ message, connection })
  await relay.start()
  cleanup.push(() => relay.stop())
  const key = generateSecretKey(), owner = getPublicKey(key)
  const peer = getPublicKey(generateSecretKey())
  const peerDevice = getPublicKey(generateSecretKey())
  const ownDevice = getPublicKey(generateSecretKey())
  const otherGroupMember = getPublicKey(generateSecretKey())
  const ownInvite = Invite.createNew(owner, owner)
  const peerInvite = Invite.createNew(peer, peer)
  const ownerProof = finalizeEvent(new AppKeys([{ identityPubkey: owner, createdAt: Math.floor(Date.now() / 1000) }]).getEvent({ ownerPubkey: owner }), key)
  const bootstrap = await peerInvite.accept(owner, key, owner, ownerProof)
  expect(bootstrap.event.tags.some(tag => tag[0] === 'owner-proof')).toBe(true)
  const sealed = bootstrap.session.sendEvent({ kind: 14, content: 'queued before restart' }).event
  const seal = (kind: number) => Session.init(getPublicKey(generateSecretKey()),
    generateSecretKey(), true, generateSecretKey()).sendEvent({ kind, content: 'encrypted group or sibling copy' }).event
  // One copy for an own linked device and one for another group member.
  const ownCopy = seal(21113), groupCopy = seal(21113)
  let rejectQueued = true
  relay.acceptFilter = event => {
    if (event.id === sealed.id && rejectQueued) { rejectQueued = false; return false }
    return true
  }
  let wake!: VerifiedEvent
  const invite = finalizeEvent(ownInvite.getEvent(), key)
  const pending = createEventStore(`${owner}:private-send`, 'private')
  await pending.putPending({ event: sealed, attempts: 1, updatedAt: Date.now(), relays: [relay.url], sources: [] })
  await pending.vouchPending(sealed.id, 'pairwise')
  await pending.close()

  const runtime = createNostrWorkerRuntime(owner, async (_relay, event) => finalizeEvent(event, key))
  cleanup.push(() => runtime.close())
  runtime.setRelays([relay.url])
  const receiver = runtime.subscribe([{ kinds: [1059], '#p': [ownInvite.inviterEphemeralPublicKey] }], { onEvent: () => {} })
  cleanup.push(() => receiver.close())
  const lookups = runtime.subscribe([
    { kinds: [37368], authors: [owner, peer] },
    { kinds: [30078], authors: [peer], '#l': ['double-ratchet/invites'] },
    { kinds: [37368], '#p': [peerDevice] },
    { kinds: [0, 10002, 10050], authors: [owner, peer, otherGroupMember] },
  ], { onEvent: () => {} })
  cleanup.push(() => lookups.close())
  const retried = await runtime.publish(sealed, { relays: [relay.url], queue: true, carrier: 'pairwise' })
  if (!retried.accepted) expect((await runtime.publish(sealed, { relays: [relay.url], queue: true, carrier: 'pairwise' })).accepted).toBe(true)
  await runtime.publish(invite, { relays: [relay.url], requireAck: true, queue: false })
  await runtime.publish(bootstrap.event, { relays: [relay.url], requireAck: true, queue: false })
  for (const event of [ownCopy, groupCopy]) {
    await runtime.publish(event, { relays: [relay.url], requireAck: true, queue: false, carrier: 'pairwise' })
  }
  const forbiddenHttp = vi.spyOn(globalThis, 'fetch').mockRejectedValue(new Error('Identified HTTP publication forbidden'))
  cleanup.push(() => forbiddenHttp.mockRestore())
  await sendCallWakeups(owner, [`02${peer}`], 'ab'.repeat(16), false, async event => {
    wake = event
    return runtime.publish(event, { relays: [relay.url], requireAck: true, queue: false, carrier: 'pairwise' })
  }, async rumor => {
    const envelope = bootstrap.session.sendEvent(rumor).event
    await queuedCallWakeEnvelope(envelope, rumor.id, peer)
    return rumor
  }, () => true)
  expect(forbiddenHttp).not.toHaveBeenCalled()
  await vi.waitFor(() => {
    expect(relay.publishedEvents.map(event => event.id)).toEqual(expect.arrayContaining([
      sealed.id, invite.id, bootstrap.event.id, wake.id, ownCopy.id, groupCopy.id,
    ]))
    expect(wire.some(({ message }) => message[0] === 'AUTH' && (message[1] as { pubkey: string }).pubkey === owner)).toBe(true)
    expect(new Set(wire.filter(({ message }) => message[0] === 'REQ').flatMap(({ message }) =>
      (message.slice(2) as Array<{ authors?: string[]; '#p'?: string[] }>).flatMap(filter => filter.authors ?? filter['#p'] ?? []))))
      .toEqual(new Set([ownInvite.inviterEphemeralPublicKey, owner, peer, peerDevice, otherGroupMember]))
  }, { timeout: 5000 })

  const privateIds = new Set([sealed.id, bootstrap.event.id, wake.id, ownCopy.id, groupCopy.id])
  // No message event on the wire says which device or person it is for.
  for (const event of relay.publishedEvents.filter(event => event.kind === 1060)) {
    expect(event.tags.map(tag => tag[0])).toEqual(['v', 'header'])
    for (const hidden of [owner, peer, peerDevice, ownDevice, otherGroupMember]) expect(JSON.stringify(event)).not.toContain(hidden)
  }
  expect(JSON.parse(wake.content).events.at(-1).tags.map((tag: string[]) => tag[0])).toEqual(['v', 'header'])
  const cached = await runtime.query([{ ids: [...privateIds] }], { cache: 'cache-only' })
  // Call wakes are ephemeral; retained ciphertext remains available to FIPS.
  expect(new Set(cached.events.map(event => event.id))).toEqual(new Set([...privateIds].filter(id => id !== wake.id)))
  const privateConnections = new Set(wire.filter(({ message }) => message[0] === 'EVENT' &&
    privateIds.has((message[1] as { id: string }).id)).map(({ connection }) => connection))
  expect(privateConnections.size).toBeGreaterThan(0)
  expect(new Set(wire.filter(({ message }) => message[0] === 'EVENT' &&
    (message[1] as { id: string }).id === sealed.id).map(({ connection }) => connection)).size).toBeGreaterThanOrEqual(2)
  const authenticationKeys = new Set<string>()
  for (const connection of privateConnections) {
    const frames = wire.filter(frame => frame.connection === connection).map(frame => frame.message)
    expect(frames.some(frame => frame[0] === 'REQ')).toBe(false)
    const auth = frames.filter(frame => frame[0] === 'AUTH').map(frame => frame[1] as { pubkey: string })
    expect(auth.length).toBeGreaterThan(0)
    expect(auth.every(event => ![owner, peer, ownDevice, otherGroupMember].includes(event.pubkey))).toBe(true)
    for (const key of new Set(auth.map(event => event.pubkey))) {
      expect(authenticationKeys.has(key)).toBe(false)
      authenticationKeys.add(key)
    }
    expect(frames.filter(frame => frame[0] === 'EVENT').every(frame =>
      privateIds.has((frame[1] as { id: string }).id))).toBe(true)
    // Own linked-device delivery cannot identify a neighboring peer/group send.
    expect(new Set(frames.filter(frame => frame[0] === 'EVENT').map(frame =>
      (frame[1] as { id: string }).id)).size).toBe(1)
  }
  const identityConnections = new Set(wire.filter(({ message }) => message[0] === 'AUTH' &&
    (message[1] as { pubkey: string }).pubkey === owner).map(({ connection }) => connection))
  expect([...privateConnections].every(connection => !identityConnections.has(connection))).toBe(true)
  // Profile, relay-list, device and invite lookups use the account's own
  // connection, one request per author batch, and never a sending connection.
  const discoveryFrames = wire.filter(({ message }) => message[0] === 'REQ' &&
    (message.slice(2) as Array<{ kinds?: number[] }>).some(filter => filter.kinds?.some(kind => [0, 10002, 10050, 30078, 37368].includes(kind))))
  const discoveryConnections = new Set(discoveryFrames.map(frame => frame.connection))
  expect(discoveryConnections.size).toBe(1)
  for (const connection of discoveryConnections) {
    const frames = wire.filter(frame => frame.connection === connection).map(frame => frame.message)
    expect(identityConnections.has(connection)).toBe(true)
    expect(privateConnections.has(connection)).toBe(false)
    expect(frames.some(frame => frame[0] === 'EVENT' && privateIds.has((frame[1] as { id: string }).id))).toBe(false)
  }
  const lookupFilters = discoveryFrames.flatMap(frame => frame.message.slice(2) as Array<{ kinds?: number[]; authors?: string[]; '#p'?: string[] }>)
    .filter(filter => filter.kinds?.some(kind => [0, 10002, 10050, 30078, 37368].includes(kind)))
  expect(lookupFilters).toContainEqual({ kinds: [37368], authors: [owner, peer] })
  expect(lookupFilters).toContainEqual({ kinds: [0, 10002, 10050], authors: [owner, peer, otherGroupMember] })
  expect(lookupFilters).toContainEqual({ kinds: [30078], authors: [peer], '#l': ['double-ratchet/invites'] })
  expect(lookupFilters).toContainEqual({ kinds: [37368], '#p': [peerDevice] })
})

it('reads and replays a group event on an anonymous socket and publishes it once on a separate socket', async () => {
  const relay = new TestRelay()
  relay.authRequired = true
  const frames: { connection: number; msg: unknown[] }[] = []
  relay.observeWire = (msg, connection) => frames.push({ msg, connection })
  await relay.start()
  cleanup.push(() => relay.stop())
  const account = generateSecretKey()
  const owner = getPublicKey(account)
  const runtime = createNostrWorkerRuntime(owner, async (_relay, template) => finalizeEvent(template, account))
  cleanup.push(() => runtime.close())
  runtime.setRelays([relay.url])
  const event = finalizeEvent({ kind: 1060, created_at: Math.floor(Date.now() / 1000),
    tags: [['v', '2'], ['header', 'encrypted']], content: 'ciphertext' }, generateSecretKey())
  const filter = { kinds: [1060], authors: [event.pubkey] }
  const received: string[] = []
  const sub = runtime.subscribeToGroup([filter], { onEvent: event => received.push(event.id) }, { cache: 'network-only' })
  cleanup.push(() => sub.close())
  await runtime.publish(event, { carrier: 'group-sender-key', requireAck: true, queue: false })
  await vi.waitFor(() => expect(received).toContain(event.id))
  sub.close()
  const history = await runtime.queryGroup([filter], { cache: 'network-only' })
  expect(history.events.map(value => value.id)).toContain(event.id)
  const groupReads = frames.filter(({ msg }) => msg[0] === 'REQ' && JSON.stringify(msg.slice(2)).includes(event.pubkey))
  const writes = frames.filter(({ msg }) => msg[0] === 'EVENT' && (msg[1] as VerifiedEvent).id === event.id)
  // A NIP-42 challenge can resend the identical signed event after AUTH.
  expect(new Set(writes.map(({ msg }) => (msg[1] as VerifiedEvent).id))).toEqual(new Set([event.id]))
  expect(relay.publishedEvents.map(value => value.id)).toEqual([event.id])
  expect(groupReads.length).toBeGreaterThan(0)
  for (const { connection } of [...writes, ...groupReads]) {
    const auth = frames.find(row => row.connection === connection && row.msg[0] === 'AUTH')!
    expect((auth.msg[1] as VerifiedEvent).pubkey).not.toBe(owner)
  }
  expect(groupReads.some(row => row.connection === writes[0].connection)).toBe(false)
})
