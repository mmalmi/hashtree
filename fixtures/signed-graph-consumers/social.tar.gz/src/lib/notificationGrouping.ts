import type { NotificationItem } from './appDetailLoaders';

export type NotificationGroup = {
  id: string;
  kind: NotificationItem['kind'];
  items: NotificationItem[];
  reactedPosts: NotificationItem[];
  latest: NotificationItem;
  targetEvent: NotificationItem['targetEvent'];
  targetRef: string;
  bits: number;
};

function replyTarget(item: NotificationItem): string {
  if (item.kind !== 'reply') {
    return item.targetRef;
  }
  return item.actorEvent.tags.find((tag) => ['e', 'a', 'i'].includes(tag[0] ?? ''))?.[1]
    ?? item.targetRef;
}

function compareItems(left: NotificationItem, right: NotificationItem): number {
  return right.actorEvent.created_at - left.actorEvent.created_at || left.id.localeCompare(right.id);
}

function actorDay(item: NotificationItem): string | null {
  // Items without a valid reaction target fall back to the reaction's own id.
  if (item.kind !== 'like' || item.targetRef === item.id) {return null;}
  return `actor:${item.actorEvent.pubkey}:${Math.floor(item.actorEvent.created_at / 86_400)}`;
}

export function groupNotificationItems(items: readonly NotificationItem[]): NotificationGroup[] {
  const postsByActorDay = new Map<string, Set<string>>();
  const soleActorDay = new Map<string, string | null>();
  for (const item of items) {
    const day = actorDay(item);
    if (!day) {continue;}
    const posts = postsByActorDay.get(day);
    if (posts) {posts.add(item.targetRef);}
    else {postsByActorDay.set(day, new Set([item.targetRef]));}
    if (!soleActorDay.has(item.targetRef)) {soleActorDay.set(item.targetRef, day);}
    else if (soleActorDay.get(item.targetRef) !== day) {soleActorDay.set(item.targetRef, null);}
  }
  // Leave popular posts grouped by post when splitting them would add rows.
  const bursts = new Set([...soleActorDay.values()].filter((day): day is string =>
    day !== null && postsByActorDay.get(day)!.size > 1
  ));

  const grouped = new Map<string, NotificationItem[]>();
  for (const item of [...items].sort(compareItems)) {
    const day = actorDay(item);
    const key = day && bursts.has(day) ? day : `${item.kind}:${replyTarget(item)}`;
    const candidates = grouped.get(key);
    if (candidates) {candidates.push(item);}
    else {grouped.set(key, [item]);}
  }

  return [...grouped.entries()].map(([id, candidates]) => {
    const byActor = new Map<string, NotificationItem>();
    const byPost = new Map<string, NotificationItem>();
    for (const item of candidates) {
      if (!byActor.has(item.actorEvent.pubkey)) {byActor.set(item.actorEvent.pubkey, item);}
      if (bursts.has(id) && !byPost.has(item.targetRef)) {byPost.set(item.targetRef, item);}
    }
    const groupedItems = [...byActor.values()];
    const latest = candidates[0]!;
    return {
      id,
      kind: latest.kind,
      items: groupedItems,
      reactedPosts: [...byPost.values()],
      latest,
      targetEvent: candidates.find((item) => item.targetEvent)?.targetEvent ?? null,
      targetRef: latest.targetRef,
      bits: groupedItems.reduce((sum, item) => sum + (item.bits ?? 0), 0),
    };
  }).sort((left, right) => (
    right.latest.actorEvent.created_at - left.latest.actorEvent.created_at
    || left.id.localeCompare(right.id)
  ));
}
