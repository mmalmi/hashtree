import type { RawEvent } from './nostr';
import { getLastValidLowercaseEventTarget } from './nostrEventTargets';
import { getDirectThreadParentTargetKey } from './threadTree';
import { getValidatedZapBits, validateZapReceipt } from './zapReceipt';

export const NOTE_ENGAGEMENT_EVENT_KINDS = [1, 6, 7, 16, 1_111, 9_735] as const;

export type NoteEngagement = {
  reactionCount: number;
  replyCount: number;
  repostCount: number;
  zapCount: number;
  zapBits: number;
  viewerReacted: boolean;
  reactionAuthors: readonly string[];
  replyEventIds: readonly string[];
  repostAuthors: readonly string[];
  zapPayments: readonly { key: string; millisats: number }[];
};

export const ZERO_NOTE_ENGAGEMENT: NoteEngagement = {
  reactionCount: 0,
  replyCount: 0,
  repostCount: 0,
  zapCount: 0,
  zapBits: 0,
  viewerReacted: false,
  reactionAuthors: [],
  replyEventIds: [],
  repostAuthors: [],
  zapPayments: [],
};

/** Repost cards display and count interactions on the original post. */
export function getNoteEngagementTargetId(event: RawEvent): string {
  return event.kind === 6 ? getLastValidLowercaseEventTarget(event) ?? event.id : event.id;
}

function selectNewestEventsByAuthor(events: readonly RawEvent[]): RawEvent[] {
  const byAuthor = new Map<string, RawEvent>();
  for (const event of events) {
    const existing = byAuthor.get(event.pubkey);
    if (
      !existing
      || event.created_at > existing.created_at
      || (event.created_at === existing.created_at && event.id.localeCompare(existing.id) < 0)
    ) {
      byAuthor.set(event.pubkey, event);
    }
  }
  return [...byAuthor.values()].sort((left, right) => (
    right.created_at - left.created_at || left.id.localeCompare(right.id)
  ));
}

export function selectNewestReactionsByAuthor(events: readonly RawEvent[]): RawEvent[] {
  return selectNewestEventsByAuthor(events);
}

export function getZapBits(event: RawEvent): number {
  return getValidatedZapBits(event);
}

function addZapPayment(payments: Map<string, number>, event: RawEvent, noteId: string): void {
  const zap = validateZapReceipt(event, { eventId: noteId });
  if (zap) {payments.set(zap.paymentKey, Math.min(payments.get(zap.paymentKey) ?? zap.amountMillisats, zap.amountMillisats));}
}

function summarizePayments(payments: Map<string, number>) {
  const zapPayments = [...payments].map(([key, millisats]) => ({ key, millisats }))
    .sort((left, right) => left.key.localeCompare(right.key));
  const total = zapPayments.reduce((sum, payment) => sum + BigInt(payment.millisats), 0n);
  return { zapCount: payments.size, zapBits: Number(total / 1_000n), zapPayments };
}

export function summarizeNoteEngagementEvents(
  noteId: string,
  events: readonly RawEvent[],
  viewerPubkey?: string | null,
): NoteEngagement {
  const uniqueEvents = [...new Map(events.map((event) => [event.id, event] as const)).values()];
  const normalizedNoteId = noteId.trim().toLowerCase();
  const reactions = selectNewestReactionsByAuthor(
    uniqueEvents.filter((event) => (
      event.kind === 7 && getLastValidLowercaseEventTarget(event) === normalizedNoteId
    )),
  );
  const reposts = selectNewestEventsByAuthor(
    uniqueEvents.filter((event) => (
      (event.kind === 6 || event.kind === 16)
      && getLastValidLowercaseEventTarget(event) === normalizedNoteId
    )),
  );
  const replies = uniqueEvents.filter((event) => (
    (event.kind === 1 || event.kind === 1_111)
    && getDirectThreadParentTargetKey(event) === `e:${normalizedNoteId}`
  ));
  const payments = new Map<string, number>();
  for (const event of uniqueEvents) {
    if (event.kind === 9_735) {addZapPayment(payments, event, normalizedNoteId);}
  }
  const normalizedViewerPubkey = viewerPubkey?.trim().toLowerCase() || null;

  return {
    reactionCount: reactions.length,
    replyCount: replies.length,
    repostCount: reposts.length,
    ...summarizePayments(payments),
    viewerReacted: normalizedViewerPubkey
      ? reactions.some((event) => event.pubkey === normalizedViewerPubkey)
      : false,
    reactionAuthors: reactions.map((event) => event.pubkey).sort(),
    replyEventIds: replies.map((event) => event.id).sort(),
    repostAuthors: reposts.map((event) => event.pubkey).sort(),
  };
}

export function mergeLiveNoteEngagementEvents(
  durable: Map<string, NoteEngagement>,
  liveEvents: readonly RawEvent[],
  viewerPubkey?: string | null,
): Map<string, NoteEngagement> {
  if (durable.size === 0 || liveEvents.length === 0) {
    return durable;
  }

  const eventsByTarget = new Map<string, RawEvent[]>();
  for (const event of liveEvents) {
    const directParent = getDirectThreadParentTargetKey(event);
    const target = event.kind === 1 || event.kind === 1_111
      ? directParent?.startsWith('e:') ? directParent.slice(2) : null
      : getLastValidLowercaseEventTarget(event);
    const targets = target && durable.has(target)
      ? [target]
      : [];
    for (const target of targets) {
      const events = eventsByTarget.get(target) ?? [];
      events.push(event);
      eventsByTarget.set(target, events);
    }
  }
  if (eventsByTarget.size === 0) {
    return durable;
  }

  const normalizedViewerPubkey = viewerPubkey?.trim().toLowerCase() || null;
  const merged = new Map(durable);
  for (const [noteId, events] of eventsByTarget) {
    const base = durable.get(noteId) ?? ZERO_NOTE_ENGAGEMENT;
    const reactionAuthors = new Set(base.reactionAuthors);
    const replyEventIds = new Set(base.replyEventIds);
    const repostAuthors = new Set(base.repostAuthors);
    const payments = new Map(base.zapPayments.map(({ key, millisats }) => [key, millisats]));

    for (const event of events) {
      if (event.kind === 7 && getLastValidLowercaseEventTarget(event) === noteId) {
        reactionAuthors.add(event.pubkey);
      } else if ((event.kind === 6 || event.kind === 16)
        && getLastValidLowercaseEventTarget(event) === noteId) {
        repostAuthors.add(event.pubkey);
      } else if (
        (event.kind === 1 || event.kind === 1_111)
        && getDirectThreadParentTargetKey(event) === `e:${noteId}`
      ) {
        replyEventIds.add(event.id);
      } else if (event.kind === 9_735) {
        addZapPayment(payments, event, noteId);
      }
    }

    const sortedReactionAuthors = [...reactionAuthors].sort();
    const sortedReplyEventIds = [...replyEventIds].sort();
    const sortedRepostAuthors = [...repostAuthors].sort();
    merged.set(noteId, {
      reactionCount: sortedReactionAuthors.length,
      replyCount: sortedReplyEventIds.length,
      repostCount: sortedRepostAuthors.length,
      ...summarizePayments(payments),
      viewerReacted: base.viewerReacted || Boolean(
        normalizedViewerPubkey && reactionAuthors.has(normalizedViewerPubkey)
      ),
      reactionAuthors: sortedReactionAuthors,
      replyEventIds: sortedReplyEventIds,
      repostAuthors: sortedRepostAuthors,
    });
  }
  return merged;
}

const compactStatFormatters = [0, 1].map((maximumFractionDigits) => new Intl.NumberFormat(undefined, {
  notation: 'compact',
  maximumFractionDigits,
}));

export function formatCompactStat(value: number): string {
  return compactStatFormatters[value >= 1000 ? 1 : 0]!.format(value);
}
