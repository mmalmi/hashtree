import type { SocialGraph } from 'nostr-social-graph';

export const MAX_SOCIAL_GRAPH_BADGE_PUBKEYS = 128;
export type SocialGraphBadge = {
  pubkey: string;
  distance: 0 | 1 | 2 | 3 | null;
  followedByFriends: number;
  muted: boolean;
};

export function validateSocialGraphBadgeQuery(viewer: string, pubkeys: readonly string[]): void {
  if (!/^[0-9a-f]{64}$/.test(viewer)
    || !Array.isArray(pubkeys) || pubkeys.length > MAX_SOCIAL_GRAPH_BADGE_PUBKEYS
    || pubkeys.some((pubkey) => !/^[0-9a-f]{64}$/.test(pubkey))) {
    throw new RangeError('Invalid social graph badge query');
  }
}

/** Project nearby relationships; never reroot or recalculate the shared graph. */
export function socialGraphBadgesFromGraph(
  graph: SocialGraph, viewer: string, pubkeys: readonly string[],
): SocialGraphBadge[] {
  validateSocialGraphBadgeQuery(viewer, pubkeys);
  // The graph's public getters allocate IDs for unknown keys. Read-only name
  // lookups must not grow the bounded worker graph.
  const { ids, followedByUser, followersByUser, mutedByUser } = graph.getInternalData();
  const viewerId = ids.has(viewer) ? ids.id(viewer) : undefined;
  const follows = viewerId === undefined ? undefined : followedByUser.get(viewerId);
  const mutes = viewerId === undefined ? undefined : mutedByUser.get(viewerId);
  const secondDegree = new Map<number, boolean>();

  // Only inspect paths ending at a requested profile. A shared intermediary
  // is checked once per batch, without materializing the viewer's entire network.
  function hasTwoStepPath(person: number): boolean {
    const cached = secondDegree.get(person);
    if (cached !== undefined) {return cached;}
    const parents = followersByUser.get(person);
    let found = false;
    if (follows?.size && parents?.size) {
      const [smaller, larger] = parents.size < follows.size ? [parents, follows] : [follows, parents];
      for (const parent of smaller) {
        if (larger.has(parent)) {found = true; break;}
      }
    }
    secondDegree.set(person, found);
    return found;
  }

  return pubkeys.map((pubkey) => {
    const target = ids.has(pubkey) ? ids.id(pubkey) : undefined;
    const followers = target === undefined ? undefined : followersByUser.get(target);
    let followedByFriends = 0;
    if (follows?.size && followers?.size) {
      const [smaller, larger] = followers.size < follows.size ? [followers, follows] : [follows, followers];
      for (const follower of smaller) {
        if (follower !== target && follower !== viewerId && larger.has(follower)) {followedByFriends += 1;}
      }
    }
    let distance: SocialGraphBadge['distance'] = pubkey === viewer ? 0
      : target !== undefined && follows?.has(target) ? 1 : followedByFriends ? 2 : null;
    if (distance === null && follows?.size && followers) {
      for (const follower of followers) {
        if (hasTwoStepPath(follower)) {distance = 3; break;}
      }
    }
    return { pubkey, distance, followedByFriends, muted: target !== undefined && !!mutes?.has(target) };
  });
}
