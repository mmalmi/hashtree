<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { getNostrExtension } from '../accountSigner';
  import UserRow from './UserRow.svelte';
  import type { ProfileRecord } from '../nostr';
  import type { SocialAccount } from '../accounts';
  import IrisIcon from './IrisIcon.svelte';
  import AccountKeyBackup from './AccountKeyBackup.svelte';

  export let accounts: SocialAccount[] = [];
  export let activePubkey: string | null = null;
  export let remoteProfiles: Map<string, ProfileRecord> = new Map();
  export let accountInput = '';
  export let importError = '';
  export let onCreateAccount: () => void = () => undefined;
  export let onImportAccount: () => void = () => undefined;
  export let onRemoteLogin: (signal: AbortSignal) => void | Promise<void> = () => undefined;
  export let onExtensionLogin: () => void | Promise<void> = () => undefined;
  export let onAccountInput: (value: string) => void = () => undefined;
  export let onSwitchAccount: (pubkey: string) => void = () => undefined;
  export let onRemoveAccount: (pubkey: string) => void = () => undefined;

  $: activeAccount = accounts.find((account) => account.pubkey === activePubkey) ?? null;

  let showExisting = false;
  let extensionAvailable = false;
  let extensionPending = false;
  let pairing: AbortController | null = null;
  onDestroy(() => pairing?.abort());

  async function loginWithRemoteSigner(): Promise<void> {
    if (pairing) return;
    pairing = new AbortController();
    try { await onRemoteLogin(pairing.signal); } finally { pairing = null; }
  }
  onMount(() => {
    const syncExtension = () => { extensionAvailable = getNostrExtension() !== null; };
    syncExtension();
    window.addEventListener('focus', syncExtension);
    return () => window.removeEventListener('focus', syncExtension);
  });

  async function loginWithExtension(): Promise<void> {
    if (extensionPending) return;
    extensionPending = true;
    try { await onExtensionLogin(); } finally { extensionPending = false; }
  }

  function requestAccountRemoval(account: SocialAccount): void {
    const message = account.nsec
      ? 'Remove this account from this device? You’ll need your secret key to sign in again.'
      : 'Remove this account from this device?';
    if (window.confirm(message)) onRemoveAccount(account.pubkey);
  }

  function profileForAccount(account: SocialAccount): ProfileRecord | null {
    return remoteProfiles.get(account.pubkey) ?? null;
  }
</script>

<section data-testid="account-sheet" class="grid gap-4 px-4 py-4 pb-6 sm:px-5">

  <div class="grid gap-2">
    {#each accounts as account (account.pubkey)}
      {@const active = account.pubkey === activePubkey}
      {@const profile = profileForAccount(account)}
      <div
        class={`flex items-center gap-3 rounded-[16px] border px-3 py-3 text-left transition ${
          active ? 'border-violet-300/25 bg-violet-500/10' : 'border-white/10 bg-[#090909] hover:bg-[#111111]'
        }`}
      >
        <button
          data-testid="account-item"
          type="button"
          class="min-w-0 flex-1 bg-transparent text-left"
          on:click={() => onSwitchAccount(account.pubkey)}
        >
          <UserRow
            pubkey={account.pubkey}
            {profile}
            avatarSize={44}
            titleClass="truncate text-[0.98rem] font-700 text-white"
            subtitleClass="mt-1 truncate text-[0.84rem] text-white/55"
          />
        </button>

        <div class="flex items-center gap-2">
          {#if accounts.length > 1}
            <button
              type="button"
              class="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-[#111111] text-white/65 transition hover:bg-[#1a1a1a] hover:text-white"
              on:click|stopPropagation={() => requestAccountRemoval(account)}
              aria-label="Remove account"
            >
              <IrisIcon name="trash" size={17} />
            </button>
          {/if}

          {#if active}
            <span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-violet-600 text-white">
              <IrisIcon name="check" size={18} />
            </span>
          {/if}
        </div>
      </div>
    {/each}
  </div>

  {#if activeAccount}
    <AccountKeyBackup account={activeAccount} />
  {/if}

  <div class="rounded-[18px] border border-white/10 bg-[#090909] p-3">
    {#if showExisting}
    <button type="button" class="mb-3 text-sm text-white/70" on:click={() => { showExisting = false; onAccountInput(''); }}>Back</button>
    <div class="flex gap-2">
      <input
        data-testid="account-input"
        value={accountInput}
        placeholder="Paste your account code"
        class="min-w-0 flex-1 rounded-full border border-white/10 bg-black px-4 py-3 text-[0.95rem] text-white outline-none transition placeholder:text-white/28 focus:border-violet-300/45"
        on:input={(event) => onAccountInput((event.currentTarget as HTMLInputElement).value)}
        on:keydown={(event) => event.key === 'Enter' && onImportAccount()}
      />
      <button
        data-testid="import-account"
        type="button"
        class="rounded-full border border-white/10 bg-[#111111] px-4 py-3 text-[0.92rem] font-700 text-white transition hover:bg-[#1a1a1a]"
        on:click={onImportAccount}
      >
        Add
      </button>
    </div>

    {#if importError}
      <div class="mt-2 text-[0.85rem] text-[#ffb4b4]">{importError}</div>
    {/if}

    <button
      type="button"
      disabled={Boolean(pairing)}
      class="mt-3 w-full rounded-full border border-white/10 px-4 py-3 text-sm font-700 text-white disabled:opacity-50"
      on:click={loginWithRemoteSigner}
    >Sign in with remote signer</button>

    {#if extensionAvailable}
      <button
        data-testid="extension-login"
        type="button"
        disabled={extensionPending}
        class="mt-3 w-full rounded-full bg-[var(--iris-solid)] px-4 py-3 text-sm font-700 text-[var(--iris-on-solid)] disabled:opacity-50"
        on:click={() => void loginWithExtension()}
      >{extensionPending ? 'Connecting…' : 'Sign in with Nostr extension'}</button>
    {/if}

    {:else}
    <button type="button" class="w-full rounded-full border border-white/10 px-4 py-3 text-sm font-700 text-white" on:click={() => { showExisting = true; }}>
      Already have an account?
    </button>
    <button
      data-testid="create-account"
      type="button"
      class="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/10 bg-[#111111] px-4 py-3 text-[0.94rem] font-700 text-white transition hover:bg-[#1a1a1a]"
      on:click={onCreateAccount}
    >
      <IrisIcon name="plus" size={18} />
      Create account
    </button>
    {/if}
  </div>
</section>
