import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

const releases = {
  '@fips/core': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.61/fips-core-0.0.56.tgz',
    integrity: 'sha512-vXfPsXWlXIEZFFl6K+x9YCwOhRPQr4gjw+GfWOfuyI1RW1O1tcdKQBcDbIszByNWVCt/Rs8UOAzv+k+iXNlIOQ==',
    version: '0.0.56',
  },
  '@fips/transport-webrtc': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.61/fips-transport-webrtc-0.0.60.tgz',
    integrity: 'sha512-te9hazkbDXnV4hBYX4pIX594WDY5XVClh9tZCVAm5GzE8bHyoFEAhIpyWiUpbciawaYdRLubkcar3D8A7bViYA==',
    version: '0.0.60',
  },
  '@fips/transport-websocket': {
    url: 'https://github.com/mmalmi/fips-ts/releases/download/runtime-v0.0.61/fips-transport-websocket-0.0.14.tgz',
    integrity: 'sha512-B+CUOBXuMwfDzLCnr+QfLf/MuA4wcV+36mqwH+RS0DNRYFcoGgM60MZiwcjFVCb6xzl0ZTUYe9Sla+VJ2MJBnQ==',
    version: '0.0.14',
  },
  'nostr-social-graph': {
    url: 'https://github.com/mmalmi/nostr-social-graph/releases/download/v4.2.0/nostr-social-graph-4.2.0.tgz',
    integrity: 'sha512-DUFZNJ2jGreQgqsvxvn8UwMucM48h6dvB3AyUuql2ber0pRBJA8a0R20rLqYuT2FNbfhDyQyEMQLRxQVQK0Ebg==',
    version: '4.2.0',
  },
  '@hashtree/worker': {
    url: 'https://github.com/mmalmi/hashtree/releases/download/hashtree-ts-runtime-v0.5.41/hashtree-worker-0.4.25.tgz',
    integrity: 'sha512-viUPl2JUtrfJENEWZPvaTtT5x73Pvj5EmHn7qjsTP5T01uOg0tDm7xJww3cf6x23LILi6drOh97ss0WWYq/KVA==',
    version: '0.4.25',
  },
  'nostr-pubsub': {
    url: 'https://github.com/mmalmi/nostr-pubsub/releases/download/nostr-pubsub-ts-v0.5.25/nostr-pubsub-0.5.25.tgz',
    integrity: 'sha512-IoX7MP6JqhBkxJR6LMjVF9+ow4oycuoXMyf5TUekr2fYHTR6jBQCWjdxla2ZnDtIwNQ4jla1oYO68IRGEwMs2Q==',
    version: '0.5.25',
  },
  'nostr-double-ratchet': {
    url: 'https://registry.npmjs.org/nostr-double-ratchet/-/nostr-double-ratchet-0.0.183.tgz',
    integrity: 'sha512-CPvJzniY+nItLVEQpH4jaRnmU7AMkD3kAN5yByXMgmm4MNChAk8X8HY8oJIw1riX/gW3/WKD8c+eUtSgu98DDA==',
    version: '0.0.183',
  },
};

export function verifyPrivateRuntimePins(manifest, lockfile) {
  const packages = lockfile.split('\nsnapshots:')[0];
  for (const [name, url] of Object.entries(manifest.dependencies)) {
    if (!name.startsWith('@hashtree/')) continue;
    if (manifest.pnpm?.overrides?.[name] !== url) throw new Error(`${name} override must match its release`);
    const entry = packages.split('\n\n').find(block => block.startsWith(`  '${name}@${url}':\n`));
    if (!entry?.includes(`tarball: ${url}}`) || !/resolution: \{integrity: sha512-[A-Za-z0-9+/]{86}==,/.test(entry)) {
      throw new Error(`${name} needs a SHA-512 integrity pin for its release tarball`);
    }
  }
  for (const [name, release] of Object.entries(releases)) {
    if ((manifest.dependencies?.[name] ?? manifest.devDependencies?.[name]) !== release.url) throw new Error(`${name} must use its verified immutable release`);
    const override = manifest.pnpm?.overrides?.[name];
    if (override !== undefined && override !== release.url && override !== `$${name}`) throw new Error(`${name} override must match its verified release`);
    const registry = new URL(release.url).hostname === 'registry.npmjs.org';
    const ref = `${name}@${registry ? release.version : release.url}`;
    const start = Math.max(packages.indexOf(`  '${ref}':`), packages.indexOf(`  ${ref}:`));
    const end = packages.indexOf('\n\n', start);
    const entry = start < 0 ? '' : packages.slice(start, end < 0 ? undefined : end);
    if (!entry.includes(`integrity: ${release.integrity}`)) throw new Error(`${name} lock integrity must match its verified release`);
    const entries = packages.split('\n').filter(line => line.startsWith(`  ${name}@`) || line.startsWith(`  '${name}@`));
    if (entries.length !== 1) throw new Error(`${name} must have one verified runtime instance`);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const root = new URL('../', import.meta.url);
  verifyPrivateRuntimePins(JSON.parse(await readFile(new URL('package.json', root), 'utf8')),
    await readFile(new URL('pnpm-lock.yaml', root), 'utf8'));
  console.log('Verified immutable private runtime releases and overrides');
}
